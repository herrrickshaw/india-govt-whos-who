---
doc_id: "b28bdf30d4eabe77"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 6
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "4623b3bca47fb7b9"
---

<!-- page 1 -->

ABSTRACT
Agriculture and Farmers Welfare - Appointment of Tamil Nadu State
Agricultural Marketing Board as State Level Supporter, Market
Committees as Primary Procurement Agencies and Regulated Markets as
Primary Procurement Centers for procurement of Black gram under Price
Support Scheme (PSS) during Rabi 2022-2023 - Orders - Issued.
AGRICULTURE AND FARMERS WELFARE (AP4) DEPARTMENT
0.0. (2D) No.35 Dated: 28.02.2023
சுபகிருது வருடம்‌ மாசி 16,
திருவள்ளுவர்‌ ஆண்டு 2054,
Read:
1.G.0. (2D) No.7, Agriculture and Farmers Welfare (AP4)
Department, dated 27.01.2023.
2.Tamil Nadu Government Gazette Extraordinary No.39, dated
27.01.2023.
3.From the Deputy Commissioner (MPS), Government of India,

Ministry of Agriculture and Farmers Welfare, Department of

Agriculture, Co-operation and Farmers Welfare, New Delhi,

F.No.L-15016/21/2023-MPS (FTS-123930) dated 22.02.2023 .

addressed to NAFED and other agencies with a copy marked to

Government.

4.From the Director of Agricultural Marketing and Agri Business
Letter No. MCS3/45672/22, dated 23.02.2023.
ORDER:

In the Government Order i read above, orders have been issued
notifying the implementation of Price Support Scheme (PSS) மா
procurement of 75,700 MT of Black gram in Tamil Nadu during Rabi
2022-2023 in major growing districts of Thoothukudi, Tirunelveli, Tenkasi,
Dindigul, = Thiruvannamalai, மர்மமாக, Kallakurichi, — Ariyalur,
Virudhunagar, Ramnad, Ranipet, Theni, Karur, Chengalpattu, Tiruppur,
Salem Namakkal, Thanjavur, Tiruvarur, Nagapattinam, Mayiladuthurai,
Cuddalore, Trichy and Pudukottai and the same has been published in the
Tamil Nadu Government Gazette Extraordinary No.39, dated 27.01.2023.

2. In the letter 314 read above, the Government of India has
conveyed their approval to implement the Price Support Scheme (PSS) for
Procurement of a maximum quantity of 60,203 MT of Black Gram (பாகம்‌
in the State of Tamil Nadu for Rabi 2022-23 Season strictly as per the
PSS Guidelines, 2018.

<!-- page 2 -->

3. In the letter 4** read above, the Director of Agricuitural Marketina
and Agri Business has informed that it has been programmed to procure
60,203 MT Black gram from the farmers of the 24 notified districts in the
identified 53 Regulated Market Centers from 01.04.2023 to 29,06,2023 in
Delta District and 01.03.2023 to 29.05.2023 in other Districts as detailed
below at Minimum Support Price (MSP) through National Agricultural
Cooperative Marketing Federation of India (NAFED):-

PSS - Black Gram Rabi -2022-23

sre] sens mts Flin
| 1 [Ariyaur | a [3eyankondam | 960 |
| முற 6 [Udumalaipet | 400 |
Villupuram | 8 |vilupuram | 1750 |
[9 |Vikravandi | 1750 |
9 | Kallakkurichi 11

10 | Thiruvannamalai 14 | Thiruvannamalai 480
16
17
1231080801 640 |
15 | Thoothukudi

<!-- page 3 -->

3
| 136 [Virudhunagar | 34 laruppukottaa | 0. ]
க | 32 | Sathur - i 300 ட]
17 ணணட்னா ணை | 33 | Kamuthi 4 480 |
ணை Total | 32970 |
|"!!! 01.04.20238029.06.2023
f 1 | Thanjavur | 1 [Kumbakonam | 880.
2 |Thanjavur |. 800
3 | Orthanadu | 830,
Papanasam 600
2 | Thiruvarur 5 1600
6 | Mannargudt 1600
Vaduvoor 1600
|_8 | Poonthottam 1600
| 9 | Kudavasal | 1600
3 | Nagapattinam 1750
1750
Kilvelur 1750
Mayiladuthurai Kuthalam
ன ணை ரட்ட ட!
5 Cuddalore Virudhachalam 1750
Sethiyathopu 1750
Katumannarkovil 1750
னி 1750
6 Tiruchirapalli 19 | Lagudi 800
Pudukottai | 20 | Alangudi 473
| | 26233

4. The Director of Agricultural Marketing and Agri Business has

requested the Government to issue orders for the following:

(i) To notify the Tamil Nadu State Agricultural Board as State
Level Supporter (SLS) and Marketing Committees may be
notified as Primary Procurement Agencies and Regulated
Markets may be notified as Primary Procurement Centers.

(ii) To authorize the Director of Agricultural Marketing and Agri
Business to add/delete/change the Regulated Markets within
the proposed Districts if required depending upon the arrivals.

(ili) Also to authorize the Director of Agricultural Marketing and
Agri Business to change the targets allotted to the Regulated
Markets within/jamong the proposed Districts if required
depending upon the arrivals.

<!-- page 4 -->

4

5. The Director of Agricultural Marketing and Agri Business has
therefore requested that the following clauses may be approved for
procuring Black gram from the farmers under Price Support Scheme:-

i. The State Agricultural Marketing Board at Chennai may be
notified as the State Level Supporter (SLS) with a corpus fund
allotted by the State Government.

ii. Marketing Committees may be notified as Primary
Procurement Agencies and Regulated Markets may be notifled
as Primary Procurement Centers for procuring Black gram at
MSP.

iii. Once the procurement is completed, the farmers will get
online payment from the SLS out of the corpus fund
maintained for PSS.

iv. The procured produce will be stocked in the godowns of
Central Warehousing Corporation or State Warehousing
Corporation,

v. | The procured produce could also be stocked in the godowns of
Regulated Markets and if so handling will be taken care by
SWC / CWC on rental payment to the Regulated Markets.

vi. National Agricultural Cooperative Marketing Federation of
India (NAFED) will reimburse the State Level Supporter, the
payment made to the farmers on receipt of Warehouse
Receipt (WHR).

vii. Handling charges like gunny bags, loading and unloading,
cleaning and grading, transportation etc. will be reimbursed
by NAFED based on the proposal submitted to NAFED for
finalization of the incidental charges by the SLS.

viii. The State Level Supporter shall enter an agreement with
NAFED for the procurement.

6. The Government after careful examination accept the proposal of
the Director of Agricultural Marketing and Agri Business and issue the
following orders :-

i. appoint the Tamil Nadu State Agricultural Marketing Board as
the State Level Supporter (SLS), the Market Committees
functioning in the Districts as Primary Procurement Agencies
(PPAs) and respective Regulated Markets as Primary
Procurement Centers for procuring Black gram under Price
Support Scheme subject to clauses indicated in para 5 above,

ii. the Director of Agricultural Marketing and Agri Business is
requested to procure 60,203 MT of Black gram for Rabi
2022-2023 season strictly as per PSS Guidelines from the
farmers of the 24 notified districts in the identified
53 Regulated Market Centers from 01.04.2023 to 29.06.2023
in Delta Districts and 01.03.2023 to 29.05.2023 in other
districts as indicated in para 3 above.

<!-- page 5 -->

5
if, the Director of Agricultural Marketing and Agri Business is
authorized to add/Delete/Change the Regulated markets
targets within the proposed Districts if required depending
upon the arrivals.
tv. the Director of Agricultural Marketing and Agri Business is
also authorized to change the targets allotted to the
Regulated Markets withinf/among the proposed Districts if
required depending upon the arrivals.
(BY ORDER OF THE GOVERNOR)
டே SAMAYAMOORTHY
AGRICULTURAL PRODUCTION COMMISSIONER
AND SECRETARY TO GOVERNMENT

To

The Director of Agricultural Marketing and Agri Business, Chennai-32.

The Director of Agriculture, Chennai-5.

The Director of Horticulture and Plantation Crops, Chennai-5.

The Chief Executive Officer, Tamil Nadu State Agricultural Marketing Board,
Chennai-32.

The Chief Engineer (Agricultural Engineering), Chennai-35.

The Additional Chief Secretary to Government, Cooperation, Food and
Consumer Protection Department, Chennai-9.

The Executive Director, Tamil Nadu Watershed Development Agency,
Chennai-32.

The Registrar of Cooperative Societies, Chennai-10.

The National Agricultural Cooperative Marketing Federation of India, 963,
Crescent Court, Purasawakkam High Road, Chennai-84.

The Principal Accountant General, Chennai-18.

Copy to: ்‌

The Special Personal Assistant to Hon’ble Minister for Agriculture and
Farmers Welfare, Chennai-9.

The Senior Private Secretary to Agricultural Production Commissioner and
Secretary to Government, Agriculture and Farmers Welfare
Department,Chennai-9.

The Agriculture and Farmers Welfare (AM2/OP3) Department, Chennai-9.

The Assistant Programmer, Agriculture and Farmers Welfare Department,
Chennai-9.

The Connected file No.3753669/AP4/2022 ்‌

Stock File/Spare copies.

//FORWARDED BY ORDER//
<6
a: சத
SECTION OFFICER
Soe?

<!-- page 6 -->
