---
doc_id: "3bcc061bfaeadda6"
source_url: "https://tnhealth.tn.gov.in/online_notification/notification/N26104749.pdf"
ministry: "Health and Family Welfare Department, Tamil Nadu"
title: "Authorization Committee meeting for liver and renal transplantation held at Directorate of Medical Education & Research, Chennai on 9th October 2026"
date: ""
pages: 3
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "acfdcf21d10263e0"
---

<!-- page 1 -->

K.Dis.No.76668/H&DII/4/2026 Office of the Chairman, Authorization
Committee and Directorate of Medical
படுக Education & Research, Kilpauk, Chennai-10.
: Dated:09.10.2026
Sub: Human Organ Transplantation Act 1994 - Authorization Committee Meeting for
Liver / Renal Transplantation held on 09.10.2026 — Decision of the Authorization
- ~Committee for Liver / Renal Transplantation - Forwarded for uploading in the site
of www.tnhealth.tn.gov.in.
Liver Transplantation
Name of the Name of the Name of the | Whether If Rejected,
Hospital Patient Donor Approved / Reason
Rejected )

1 Gleneagles Atowar Rahman Jahuruddin 7] nee
HealthCity y J
Perumbakam, ae? 6
Chennai 71 |

ka னி ௩ (

2 | Dr. Relalnstitute & | Najeeb Ahmed Mohammed UY 7 ()
Medical Centre, Mohammed Ali Al- | Mohammed Ali 5
Chennai Ashwal Al-Ashwal APPROVE r) 0 டி ்‌

3) Dr. Rela Institute & Farid Mahamud MD Ripon Ali ஞ்‌
Medical Centre, Bhuiyan
Chennai APPROVED
Dr. Rela Institute & Kanamarlapudi Kanamarlapudi
Medical Centre, Sridhar Rao Vaishnavi
Chennai APPROVE

5 Dr. Rela Institute & oud . he
Medical Centre, = wot Mavi ல்‌
Chennai ane is es APPROV| a
Dr. Rela Institute & Muhammed Ataur Arpita
Medical Centre, Rahman
Chennai APP ROV! |

Renal Transplantation
Name of the Name of the Name of the | Whether If Rejected,
Hospital Patient Donor Approved / Reason
Rejected

‘li Apollo Children's Koushik Singha Goutam Singha
Hospitals,

Thousand Lights, APPROVE ப
Chennai

<!-- page 2 -->

2) Apollo Hospital, Kausturi Das Mrinal Kanti Das
Greams Road,
Chennai APPROVE ட)
3 Apollo Hospital, Shaik Asma Fatima | Shaik Husana
Greams Road,
ane APPROVED
4 Apollo Speciality Md Robiul Islam Rohima Begum
Hosptials Robin
Perungudi, Chennai APPROV'! ட்‌
5 Christian Medical Preodarshika Purna | Runa Chakma
College Vellore Chakma
Ranipet Campus, APPROVE
Ranipet
Christian Medical Ravi Kumar Anant Kumar
College Vellore
Ranipet Campus, APPROV! ட
Ranipet
1 Christian Medical Nikhil Gupta Bina Devi
College’Vellore 51:11 5
Ranipet Campus,” “ 114 APPROVE
Ranipet
K.G. Hospital, .... ..| Jinnat Ara Islam Habib Mondel
Coimbatore V7] 177
APPROVED
Kovai Medical Aditya Pandit Vidya Pandit
Centre-and Hospital| Manjare Manjare
Ltd., Coimbatore APPROVED
10 | Kovai Medical Shashikant Haridas | Anjana Hari |
Centre and Hospital | Shinde Shinde
Ltd., Coimbatore APPROVE
11 | Kovai Medical Nirmala Janardhan | Mangal Dattatray
Centre.and Hospital | Ghule Ghule
Ltd., Coimbatore APPROVE
12 | The Madras Saroj Mandot Sheetal Mandot
Medical Mission ,
Mogappair, vy
Chennai APPRO v
D
4.Chairman, Authorization Committee / Director [7
of Medical Education & Research, Chennai N\ 12”
தர
0
for DME&R |

<!-- page 3 -->

2.Member of Authorization Committee / Director
of Medical and Rural Health Services, Chennai ன்‌
டட
1௦10118௩18
3.Member of Authorization Committee / Deputy ] Gp
Commissioner of Police (Headquarters), vf த
Chennai alp
4.Member of Authorization Committee / Dean, ]
Kilpauk Medical College, Chennai ॥ 2 அ இரத்‌
ரி
மல, (840. |
5.Member of Authorization Committee / Dean, நி
Stanley Medical College, Chennai ப ale
Dean, SMC.
6.Member of Authorization Committee / State
Secretary, Indian Medical Association, Gb a
Chennai ம 1 1739
for State President, IMA
7.Member of Authorization Committee and Deputy \ are
Secretary / Deputy Director of Medical ay
Education & Research (Administration), 5 ம்‌
Directorate of Medical Education & Research,
Chennai DS/DDME&R
To
The Director of Medical & Rural Health Services, Chennai.
Copy Submitted to:
The Principal Secretary to Government,
Health & Family Welfare Department.
