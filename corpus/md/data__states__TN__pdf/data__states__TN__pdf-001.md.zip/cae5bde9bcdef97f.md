---
doc_id: "cae5bde9bcdef97f"
source_url: "https://environment.tn.gov.in/assets/go/dbf553fb1ef410ef1fbd13ea3bb80678.pdf"
ministry: "Environment and Climate Change Department, Tamil Nadu"
title: "Blue Flag Beach Certification (G.O.No.89)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "073f2590a4946d04"
---

<!-- page 1 -->

,rfib-x

/s/ts*q \t\
/9f ff:t'.i ic\
\qEd{i.\Ssl

W

ABSTRACT

Environment and Climate Change - Blue Flag Beach Certification Programme
in Tamil Nadu - Announcement made in the Budget speech - Orders - Issued
ENVIRONMENT. CLIMATE CHANGE AND FOREST (EC.3I DEPARTMENT
G.O.(Msf.No" 89

Dated: 22.LO.2O2L
SlC9rr,ir<Uof- gatur@ - 2052
r9lanor orqgub, grlufl- 5

ORDER:-

The Blue Flag Prograrnme is a world renowned eco label certification for
beaches and marinas. It is operated by the International, Non-Governmental,
Non-profit Organisation - FEE (Foundation for Environmental Education),
Denmark. The Blue Flag was created in France in 1985, as a pilot scheme by
FEE and currently implemented in 49 countries. The 'Blue Flag'beach is an
Eco-tourism model aiming to provide a clean and hygienic bathing water
facility, safe and healthy environment and sustainable development of the area
for tourists / beach goers. In India the Blue Flag certification programme is
being implemented under the Beach Environment and Aesthetic Management
System (BEAMS) programme. BEAMS is an integrated coastal management
scheme conceived by the Ministry of Environment, Forest and Climate Change
(MoEF&CC), Government of India to plan sustainable tourism and healthy
coasts. This scheme is monitored by the Society of Integrated Coastal
Management (SICOM) in the Ministry of Environment, Forest and Climate
Change, Government of India.

2. In the Budget Speech 2A21-2022, tlne Government of Tamil Nadu has
made an Announcement on the floor of Tamil Nadu Legislative Assembly on
13.09.2021 that 10 beaches shall be taken up for Blue Flag certification under
the BEAMS programme.

3. Kovalam Beach, Chengalpattu was selected as the pilot beach in

Tamil Nadu for the Blue Flag Programme implemented by SICOM. Kovalam
Beach has been certified as the Blue beach in September,2O2L.

(P"r.o.)

<!-- page 2 -->

-l

t2l
4. In accordance with the said Announcement, the Beach Environment
and Aesthetic Management System (BEAMS) programme for Blue Flag
Certification shall be taken up by the Department of Environment,
Government of Tamil Nadu with following objectives:"The objective of the BEAMS programme is to abate pollution in
coastal waters & beaches, promote sustainable development of beach
amenities/facilities, protect & conserve coastal eco system & natural
resources and encourage local authorities & stakeholders to strive
and maintain high standards of cleanliness, hygiene, safety and
security for beachgoers in accordance with coastal environment
norms & regulations. This programme will pqomote beach tourism and
recreation in absolute harmony with nature.
5. The Blue Flag Beach certification progralnme in Tamil Nadu shall be
implemented at a cost of Rs.100 crores for 10 beaches.

6. The Government accord administrative sanction for 10 beaches to be
taken up under the Beach Environment and Aesthetic Management System
(BEAMS) programme in the next 5 years at a total cost of Rs.100 crores with
funding support from Tamil Nadu Pollution Control Board / Ministry of
Environment, Forest and Climate Change / Society of Integrated Coastal
Management (SICOM) / Department of Environment etc.,
(BY ORDER OF THE GOVERNOR)
SUPRIYA SAHU
PRINCIPAL SECRETARY TO GOVERNMENT
To

The Chairman, Tamil Nadu Pollution Control Board,
Chennai-32.
The Director, Department of Environment, Chennai-15.
Copy to:
The Senior Personal Assistant to Hon'ble Minister (Environment, Climate
Change and Youth Welfare & Sports Development), Chennai -9.
Finance (AHD&F) Department, Chennai-9.
The Private Sedretary to Principal Secretary to Government,
Environment, Climate Change & Forest Departmet,Chennai-9.
The Private Secretary to Special Secretary (Environment and Climate Change),
Chennai-9.
sF/ sc.

f fForwarded By Orderll

?',M6o-t
SECTION OFFICER
