---
doc_id: "21d5db4dad4eb3cf"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "efc7a78fd689bbd3"
---

<!-- page 1 -->

Copy of:
GOVERNMENT OF TAMIL NADU
ABSTRACT
PUBLIC SERVICES - Recruitment through Employment Exchanges - Order of
priority - Revised Orders - Issued.

Personnel and Administrative Reforms (Personnel - P) Department
G.O. Ms.No.188

Dated: 28th December 1976
READ:

1. G.O.Ms.No.1873, Public (Ser.I) Dated 10.8.1970
2. Government of India, Department of Personnel, New Delhi,
Memorandum No.14/21/71 Establishment (D) dated 25.12.1971.
3. G.O.Ms.No. 1299, Public (Ser.I) Dated 15.5.1972.
4. G.O.Ms.No. 2275, Public (Ser.I) Dated 5.9.1973.
5. G.O.Ms.No. 2985, Public (Ser.I) Dated 16.11.1973.
6. G.O.Ms.No. 2957, Public (Ser.G) Dated 11.9.1974.
7. G.O.Ms.No. 4052, Public (Ser.G) Dated 27.12.1974.
8. Director of Employment and Training letter No.W1/37894/72, dated
17.10.1975.
9. G.O. Ms.No. 951, Social Welfare, Dated 16.12.1975.
...
ORDER:
The priority list in regard to the provision of employment assistance
through Employment Exchange was reissued in G.O. Ms.No.1873, Public
(Services-J) dated 10.8.1970 first read above. Subsequently, additions and
deletions of certain categories of persons have been ordered in the G.Os third to
seventh read above. The Government of India in their order second read above
have given a higher priority for disabled ex-Servicemen and for the members of
the family of Defence Services Personnel killed in action. The Government have
therefore examined in consultation with Director of Employment and Training,
Madras, the question of further revising and reissuing the order of priority on the
lines of the priorities laid down by the Government of India.
2.
In supersession of the orders issued in the G.O. first read above, as
subsequently amended, the Government direct that the order of priorities in
regard to provision of employment assistance through Employment Exchanges
shall be as indicated in the annexure to this G.O.
3.
The rule of reservation shall be made applicable to all vacancies whether
they are filled by priority or non-priority category.

<!-- page 2 -->

(By Order of the Governor)
C.V. R. Panikar,
Second Secretary to Government.
// True Copy //
SUPERINTENDENT

ANNEXURE
PRIORITY FOR EMPLOYMENT THROUGH EMPLOYMENT EXCHANGES:
Group I:
i)

Disabled Ex-Servicemen
(Disabled Ex-Servicemen mean Ex-Servicemen who while serving in the
Armed Forces of the Union were disabled in operation against enemy or in
disturbed areas)

ii)

Upto two members of the family (widows/sons/daughters/next of kin) of
the enrolled personnel of the Armed Forces who were killed or disabled in
action and are totally unfit for re-employment leaving their families in
indigent circumstances and upto two members of the family
(widows/sons/daughters/next of kin) of Border Security Force Personnel
killed in action.

Group II:
i)

"Destitute Widows"
(Destitute widow means one who has neither any means by herself to live
on nor any dependent to protect her from starvation).
(Authority: G.O.Ms.No. 229, Personnel and Administrative Reforms
(Personnel-R) Department, Dated 7.4.1988.

ii)

"Intercaste Married Couple"
(Where one of the spouses belongs to SC/ST)
(Authority: G.O.Ms.No. 939, Personnel and Administrative Reforms
(Personnel-R) Department, Dated 24.9.86.

iii)

Ex-Servicemen and wives, sons and unmarried daughters of serving
military personnel.

<!-- page 3 -->

(Ex-Servicemen means a person, who after having served for any period
of time in the Defence Service (Indian Army, Indian Air Force, Indian
Navy, the Auxiliary Forces of India and the Boy's Companies) has been
discharged (except that one who has been dismissed by a competent
authority or one who has been discharged on account of mis-conduct or
inefficiency before completing six months' service shall not be treated as
Ex-Servicemen)
iv)

Indian Nationals retiring from Burma/Sri Lanka and East African Countries
of Kenya, Uganda and Tanzania due to repatriation.

v)

Members of family including members of Scheduled Castes/Scheduled
Tribe, whose lands have been acquired for Government purposes as well
as for the project of the Public Sector Undertakings subject to the
condition that preference should be given to those who are dependant for
their livelihoods primarily or wholly on the lands acquired and from among
them to members of the Scheduled Castes and Scheduled Tribes who
may be eligible for employment.

Group III:
i)

Discharged Government employees (State) as defined in the Government
of Madras letter Ms.No. 1100 Public (Services) Department, dt.
24.10.1951.

ii)

The Physically Handicapped persons viz. the blind, the deaf,
Orthopaedically handicapped persons, mentally retarded, leprosy cured
and burnt out cases etc. provided the handicap is not such as would
render the candidate unfit for efficiently discharging the duties attached to
the post.

iii)

Retrenched employees of the Census Organisation with not less than six
months' services.

iv)

The Hindi Pandits and other language Pandits who have been ousted on
account of the introduction of two Language Formula.

<!-- page 4 -->

Group IV:
i)

Person who have served in the Territorial Army or in the Lok Sahayak
Sena for more than 6 months and on their discharge revert to part time
employment in the Territorial Army or in the Lok Sahayak Sena the case
may be.

ii)

Territorial Army Personnel and Ex-Servicemen of the Auxiliary Air Force
who were embodied in the present emergency and have been disembodied after a continuous engagement of over six months.

iii)

Persons who have worked as Youth Services Corps Volunteers for a
minimum period of one year.

Group V:
Others.
// True Copy //
SUPERINTENDENT
