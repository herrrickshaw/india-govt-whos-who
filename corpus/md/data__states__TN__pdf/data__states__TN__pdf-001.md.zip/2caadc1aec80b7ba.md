---
doc_id: "2caadc1aec80b7ba"
source_url: "https://consumer.tn.gov.in/pdf/cfcp_e_160_2023.pdf"
ministry: "Civil Supplies and Consumer Protection Department, Tamil Nadu"
title: "State level Monitoring Mechanism - Direct selling Rules - G.O Ms. No 160 dated 8/12/2023"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b033e890b88e727b"
---

<!-- page 1 -->

+,#
C

0

fi 0i[ 20n

l:.
ABSTRACT
The C
1i5r Protection (Direct Selling) Rules, 2021 under the provisions
of the
Consumer Protection Act,'2019 (Central Act 35 of 2019)
Under
section
11,
Monitoring mechanism framed
Direct
selling
entities
and
Direct
sellers - Orders

issued.

co-operation, Food and consumer protection (H2) Department
G.O.(Ms) No.160

Dated A8.12.2023.
Genu6llggl orqgurb,
onf65'laoo- zZ

Slcgodr@olf elatu@.zos+
Read :
1.

Tamilnadu Government Gazette Notification No.32
under Part lll - section .l(a) dated 10.09.2022.

2.

The commissioner of civir suppries and consumer
Protection Department letter No.cA1/124g2t2a21,
dated 03.01 .2023 and 18.11.2023.

ORDER:

In the letter 2nd read above, Commissioner of Civil Supplies and
Consumer
Protection has requested the Government to frame monitoiing
as
rg: 1l of the consumer protection (Direct settins)mechanism
Rures, 2021,
and to notify in the
I
ntG

Ti_f:*,:i!?l
2'

After careful consideration, the Government have decided to accept
the
proposal of Commissioner of Civil Supplies and Consumer protection
ahd to frame
the said Rules and orders accordingly.
3.The appended Notification will be published in the Tamil Nadu Government

(p.t.o)

<!-- page 2 -->

't:

4. The Works Manager, Government Central Press is requested to send the
100 copies of the said Notification to the Additional Chief Secretary to Government,
Cooperation, Food and Consumer Protection Department, Chennai - 600 009.
(BY ORDER OF THE GOVERNOR)
K. GOPAL,
ADDITIONAL CHIEF SECRETARY TO GOVERNMENT.

To
The Works Manager,
Government Centlal Press, Chennai- 600 079.(w.e)
(for Publication in the Tamil Nadu Government
Gazette)
The Principal Secretary /Commissioner of Civil Supplies and
Consumer Protection, Chennai - 600 005.
The Registrar of Cooperative Societies, Chennai- 600 010.
The Managing Director,
Tamil Nadu Civil Supplies Corporation, Chennai :600 010
The Additional Director General of Police, Civil Supplies ClD, Chennai-35
All District Collectors.
The Tamil Development, Culture and Religious Endowments (Translation)
Department, Chennai - 9.
The Secretary to Government of lndia,
Ministry of Consumer Affairs, Food and Public Distribution,
Department of Consumer Affbirs, New Delhi - 110 001
The PersonalAssistant to Hon'ble Minister for Food and Civil Supplies,
Chennai-600 009.
The lndustries / Law Departments, Chennai- 600 009.
All Sections in Cooperation,
Food and Consumer Protection Department, Chennai- 600 009.
Stock File I Spare Copies.

// Forwarded by order ll

ii'1" \ror'
.3\t''

<!-- page 3 -->

3

APPENDIX
NOTIFICATION

WHEREAS, section 94 of the Consumer Protection Act, 2O1g (Central
Act 35 of 2A19) provides that for the purpose of preventing unfair trade practices in
e-commerce, direct selling and also to protect the interest and rights of consumers,
the Central Government may take such measures in the minner as may be
prescribed.

WHEREAS, in exercise of the powers conferred by clause (zg) of sub
section {2) of section 101 read with the said section 94 of the said Act, the Central
Government have made the Consumer Protection (Direct Selling) Rules, 2A21;

-

WHEREAS, rule 11 of the said Consumer Protection (Direct Selling) Rules,
2021 provides that for ensuring compliance of these rules by direct selling entity anci
direct sellers, every State Govbrnment shall set up a mechanism to monitor or
supervise the activities of direct sellers and direct selling entity.

NOW, THEREFORE, under the said rule 11 of the Consumer Protection
(Direct Selling) Rules, 2021, the Governor of Tarnil Nadu hereby set up the following
mechanism :MONITORING MECHANISM TO MONITOR OR SUPERVISE THE ACTIVITIES OF
DIRECT SELLING ENTIry AND DIRECT SELLERS, 2A23
These are guiding principles/mechanism for the Monitoring Authority set up by
the State Government for supervising or monitoring the activities of direct sellers and
direct selling entities as stipulated in the Consumer Protection (Direct Selling) Rules,
2021 and to strengthen the existing regulatory mechanism on direct seliing, for
preventing fraud and protecting the legitimate rights and interests of consumers.
The Nodal Department to deal with the issues related to direct selling will be the
Department of Consumer Affairs in the State.

1. Objectives of the Monitoring Authority.- The Monitoring Authority will function

with the following objectives:-

(i) To regulate the business of direct selling as per the Consumer Protection

(Direct Selling) Rules, 2021 to prevent fraud and to protect the legitimate
rights and interests of consumers;

(ii) To prohibit all forms of Pyramid Scheme or enroll/participate any person to
(iii)
(iv)
(v)

such scheme or participate in such arrangement in any manner whatsoever in
the grab of doing direct selting business;
To prohibit all forms of money circulation scheme or enroll/participate any
person to such scheme in the garb of doing direct selling business;
To prohibit all forms of unfair trade practices across all models of direct
selling;
To monitor or supeivise the activities of Direct Sellers, Direct Selling Entities
regarding compliance of the Consumer Protection Act, 2019 (Central Act 35 of
2019) and the Consumer Protection (Direct Selling) Rules, 2021.

<!-- page 4 -->

t2' composition of Monitoring Authority.- The Monitoring

the fsllowing members, namely :_

Authority shall consist oi

The Add
secretary to Government - Department of cooperation,
Food and Consumer protection.
Principat Se
Ih"
Commissioner or Commissioner, Civil Supplies and
Consumer Protection Department.
The Secretary to
any other officer nominated by him not below the rank
of
Secretary to Government.
The SgggtaV to
other officer nominated by him not below the rank of

Chairman

Nodal Officer
and Convener

The. Secretary to
Registration Department or any other officer nominated

by him not below the rank of Deputy Secietary to

Government.
The Controlle

llTllll^"-d by him not betow the r"nr, of Deputy
The Food S

i^:i:?l:l-?I him not betow the rank of Deputy
The Commiss
Department, Tamir Nadu or any other officer not berow
the rank of Joint Commissioner.
The Commissioner, S
Departinent, Tamil Nadu or any other officer not berow
the rank of Joint Commissioner.
An officer from tlre Police Department in the rant<
Additional Director General of Police dealing with
Economic offences
subject exp
9n"
Government.

3' Responsibilities of the Monitoring Authority.- The Monitoring
(i)

Authority shall,-

provide facilities for the enrolment. oj Drlgct
S_elling Entities for carrying out
their.direct selling business in the state of ramil Naiu;

provide appropriate pratform for receivinj compraints

ii)

from the
Consumers/Direct Sellers including general public againsi
thl violation of
Consumer protection (Direct SeltTng-) Rulesl iOil -OV
the oireci- Seiling

(iii)

inform respective enforcement authorities regarding the
unethical and
unlawful practice, if'any, carried out by direct -selling- entities/direci
setters

(

Entities;

(iv)

including non-compliante of monitoring mectranismTevasion
of tax laws,
noticed by the Monitoring Authority;
provide-Policy inputs to the Central Government
for appropriate modifications
in the consumer protection (Direct seiling) Rures, 2021,
i if
qr rrvr from
warranted,
' rr r!e' r

time to time;

<!-- page 5 -->

5

(v) provide awareness among law enforcement authorities, consumers, direct
sellers and the general Public and impart education and training regarding the
"Do's and Don'ts of Direct Selling" through Training lnstitutes or any such
institute recognized for the purpose by the Government of Tamil Nadu.
4. Enrolment formalities for carrying out the direct selling business in the State
of Tamil Nadu.- (1) No Direct Selling Entity or such other person shall engage in a
direct selling business in the State of Tamil Nadu unless such Entity has enrolled
with the Monitoring Authority by filing an application online in the format given in the
Annexure. The Profile of the Promoters/Directors/Partners of the applicant Direct
Selling Entity and the required permits/licenses/general and tax particulars along
with the self-declaration shall be furnished in Part A of the application and the Notary
attested affidavit shall be furnished in the prescribed format given in Part B of the
application, along with the enclosures stated in the said prescribed application form.

(2) Upon receipt of the application in the prescribed format with the required
particulars, certificates and documents, the Monitoring Authority shall,

-

(i) enroll the applicant entity in the Register maintained by it and publish the
(ii)

same in the website of Civil Supplies and Consumer Protection Department,
Tamil Nadu, or
refuse to grant enrolment if any violation of the Consumer Protection (Direct
selling) Rules, 2421 is noted prima-facie or for the non-furnishing / non-filing
of required particulars, certificates and documents :

Provided that at any time after receiving an application and before it is disposed
of, the Monitoring Authority may issue notice, in writing, demanding the applicant
entity to provide additional information or documents. Where the corrected
application or any additional information or document required is not provided within
the time specified in the said notice or any extension thereof granted by the
Monitoring Authority, the application shall be rejected.

(3) Enrolment of a direct selling entity with the Monitoring Authority would be
made purely on the basis of the particulars furnished by the Applicant in the
application which do not confer any legal right on the enrolled entity to represent
themselves as Government approved agencies. The purpose of such enrolment is
to enable the Monitoring Authority to carry out its objectives in an effective manner.
5. Powers of Monitoring Authority .- The Monitoring Authority shall be vested
with the following powers:

(i) to grant enrolment to the Direct Selling Entities upon the receipt of application
in the prescribed format along with required documents and enclosures;
(ii) to take appropriate action against the violation or non-compliance or partial
compliance of the directives of Monitoring Mechanism by any"Direct Selling
Entities/ Direct Sellers either suo motu or on the basis of any complaint
received in this regard, from any stakeholders;
(iii) to engage one or more persons from any of the enforcement departments
within this Monitoring Authority to make an inquiry in relation to the alleged
complaints and affairs of any Direct Selling Entity;
(iv) to call upon the books of accounts, registers, audited statement of Accounts,
lncome Tax' and Good and Service Tax monthly/annual returns, certified
copies of mandatory registration certificates as per the Consumer Protection

<!-- page 6 -->

6

(Direct selling) Rules, 2021 and such other documents

(v)

necessary for scrutiny
and verification.
to cancel such enrolment or black list those Direct selling
Entities violating the
regulations of the monitoring mechanism repeatedly
even after show cause
notices and warnings from thL Monitoring Auihority;
to issue show cauie notice to stop ftre" nusinesi of such non-compliances
with immediate effect;

(vi)
(vii) to refer the contravention or violation of the Consumer protection (Direct

Selling) Rules, 2021, to the Central Consume Protection
Authority or such
other Authorities as envisaged in Sections 1T to 2g of
the Consumer
Protection Act, 201g. (Central Act 35 of 2019);
(viii) to refer the contravention or violation or oiher laws and rules to
the law
Enforcement Authorities concerned under the provisions
of such Acts and
Rules;

6' Mandatory maintenance of records.- Every direct selling
entity shall maintain at
its registered office, either manually or electronically, all such
documents as are
required under any law for the time being in force, including
the following documents
or records, as may be applicable, as per rule 4 of the coisumer
irotection (Direct
selling) Rules, 2021, namely:-

(i) Certificate of tncorporation;
Memorandum of Association and Articres of Association;
Jll) Permanent
(iii)
Account Number and Tax Deduction and collection
Account
Number;
(iv) Goods and services Tax registration and Goods and services Tax
Returns;
(v) lncome Tax Returns;
(vi) Balance sheet, Audit Report
(vii) Register of direct sellers; and such other relevant reports;
(viii) certificate of rmporter-Exporter code (in case of imported goods)
(ix) License issued under the Food sgr"iv ano stanoards ACt, 2006 (central
Act 34 of 2009) for the purposes of manufacture or sale
of food items.
(x) Certificate of Registration of Trademark;
(xi) Licence. and Registration certificate issued under the Drugs and
cosmetics Act, 1940 (centrar Act 23 of 1940) ior" tii" purposes
of
manufacturer or sale of drugs, including Ayurvedic, sioona
and Unani

drugs and Homoeopathic medicines

7' Mandatory maintenance of website.-As per clause (d)
of
of the consumer Protection (Direct selling) Rules, 2021,'"u"rysub-rule (1) of rule 5
shall maintain proper and updated website with all relevant oireii setting entity
ietails of that entity,
including the documents or iecords specified in rule
4 of the said Rules, the selfdeclaration, contact information which is current and
updated,
officer, grievance redressal officer, its. m"anag"r"nt, products, details of its nodal
product information,

price and grievance redressal mechanism for-consumers.
As per clause (g) of subrule (1) of rule 5, every information provided by the direct
settrn! eniitv on its website
shall be duly certiflgo ov a cbmpany secretarv nr per sub-rut6
5, every direct selling entity shall maintain a iecord'of relevant ltoitr tn" said rute
i;fo;;ation allowing
for the identification of all direct selters who have been
delisted by the entity and
such list shall be publicly shared on its website. Similarly,
as per sub-rule (2) of the
said rule 5, every direct selling entity shall provide the iorro*ing
information on its

<!-- page 7 -->

7

website or Platform in a clear and accessible manner, which shall be
displayed
prominentty to its users, namety;registered name of the direct selling entity;
.tl registered
address of the direct seting entity and of its branches;
lil contact details,
(iii)
including e-mail addriss, fax, land line and mobile numbers of
its customer care and Grievance Redressat officers;
(iv) a ticket number for each comptaint lodged through which the complainant can
track the status of the complaint;
(v) information relating to reiurn, refund, exchange, warranty and guarantee,

delivery and shipment, modes of payment, grievance rediessal mechanism
and such other information which may be required by the consumers
to make
informed decisions;
(vi) informatiot. on- available payment methods, the security of those payment
methods, the fees or charges payable by users, the
firocedure to cancel
regular payments under those methods, charge-back opiions, if
,ny, and the
contact information of the relevant payment service prouid"r;
(vii) all mandatory licences as applicable to the Entity as well as for its products
and services;
(viii) total price of any goods or service.in single figure, along with its break-up
price showing all compulsory and voluitary-charges, including
oeiirery
charges, postage and handting charges, conveyance charges and
the
applicable tax;
(ix) provide correct and complete information at pre-purchase stage to enable
buyers to make informed purchase decisions,'and such information
shall, in
addition to.the.mandatory declarations to be provided under the l-egat
Metrology (Packaged commodities) Rules, 2o11, contain the followi"nj
information, namely:(a) the name olpurchaser and seller;
(b) description of goods or services;
(c) quantity of goods or services;
(d) the estimated derivery date of goods or services;
(e) the process of refund;
(f) guarantees or warranties applicable to such goods or services;
(g) exchange or replacement of goods in case oiit ueing defective;
and
(h) all contractual information required to be disclosed
6V or under any law
for the time being in force.

8' Scope of Direct Selling, mode of marketing, disbursement of profits or
commissions or incentives and Product Restrictions., As per clause (13)
of
section 2 of the Consumer Protection Act, 201S
lcentral Act 3'S of 201g) ,,direct
selling

means marketing, distribution and sale of'goods or provision of services
through a network of sellers, otherthan.through a permanent retail location
and as
per clause (b) of sub-rule (1) of rule 2 of the-Consumer Protection (Direct
Sellintj
Rules, 2A21, the said rules shall be applicable to all models of direct selling
and tie
main objective of framing these mechanism is to prevent fraud and pitect
the
legitimate rights and the interests of the consumers. Similarly, as per clause (7)
of
section 2 of the consumer protection Act, 2a1g, a ,,consumer,, me"n, any person
who buys any goods*or avails any services for a consideration and it includes
offline
or online transactions through electronic means or by teleshopping or direct
selling
or multi-level marketing. Therefore, the Direct Selling Entities can"adopt
Multi-level
Marketing (MLM) techniques and practices for the marketing, distribution
and sale of

<!-- page 8 -->

its goods and services through its Direct
sellers and they can disburse share of
profits or commissions or inceitives
or
such direct."tt"r, in the network
formed by them' However, such disbur."r"nt.
shall
be stricfly on the basis of the
sales or turn-over achieved by the Direct
seilers at different tevets and not on the
basis of mere recruitments.

il;r;;;ll

However, for the better understanding
of direct selling operations, a combined
reading of the relevant provisions of the
cinsumer proteitio; A;i, zolg and rules
explained above are warranted wrricrr
that the direct seling is the
marketing, distribution and sate of goods oi-se-ruices
through ,network of sellers,
any models of direct selling
;ni.n inctude! rnutti-turut marketing
:,Xft

;il;;;"r

oi*ri

"ting

Further, mere multi-level marketing companies

are not direct selling
companies as per. caluse (e) of. sub-.rule
oiirr"
s
of
iri
the
consumer protection
(Direct selling) Rules, 2021which stipulate!
inrt
Lr"rv
direct selling entity shall own,
hold or be the licensee of a traderrrk, service
mark or any other identification mark
which identifies that entity with goodt or,."ri"es,
to be sold or supplied but shall not
give commissions, bonus or inclntives
on sate oi
goods
the owner, holder or ticensee of trao;r;;k, -."ri." or services of which it is not
mark or other identification
marks.
ln addition to this, as per rule g of the consumer protection
(Direct selling)
Rules 2021, every direct setling
platforms
for sale
_usinj "-.orr"rce
comply with the requirements or-entity
proteciion (e-commerce) shall
the'cons;rr";
Rules,
2420 also in addition to consumer P.rotection
selling)
foii""t
Rules,
2021.
However,
the companies or entities indulges in pyramio
r.r',"n.r", money circulation scheme
and unfair trade practices or mil-selling of gooob
and services in the garb of doing
Direct selling business across all mode-ls ot"Jii""t
selling are stricfly prohibited from
the scope of direcl::lliry as stipulated in .trr.".
(a) and (b) of rute 10 read with
clauses (0, (g) and (i) oirule 3 of the con.rrn"i'piotectio;-(r*;;
seling) Rutes,

2021

9' Filing of periodical reports before the Monitoring
Authority after enrolment.Every direct selling entity, after enrolment,
shall furn-isn ,"portJ iritn tn" following
information and submit to tne Monitoring
Arihoritv within twenty or forty five days
from the end of each such quarter or finai"i"i
v"ri'iespectively, as the case may be.
(A) Yearly Basis:

(i) lndividual wise particulars maintained by the. direct selling

entity in respect of
their direct sellers inctuding but not timiteo-to
enrolment, termination, active
status, purchase varue, remuneration pran in
the rast
copy of GST returns, lncome Tax returns includingfinanciar yeqr;
TDS returns of the last

(ii)
year;
(iii) Any other particulars as and when found necessary
Authority

by the Monitoring

(B) Quarterty Basis:

(i) Total number of complaints received from customers within
total numbers redressed and pending status

the state and the

in tre rasiqurrt"rl

<!-- page 9 -->

9

(ii) Total number of complaints received from direct sellers within the State anci
the total numbers redressed and pending status in the last quarter;
(iii) Any other particulars as and when required by the Monitoring Authority;
10. Procedure of disposal of Complaints.- (1) The complaints received from a
direct seller or a consumer or any member of the general public will be entertained
only if such complaint is not resolved in the grievance redressal mechanism of the
Direct Selling Entity in the manrier as envisaged in sub-rule (7) of rule 5 of the
Consumer Protection (Direct Selling) Rules, 2021. ln order to resolve such
complaints or grievances, the Government shall designate officers at district level to
receive such unresolved complaints. The designated officer who received such a
complaint shall forward the same to the direct selling entity with a direction to redress
the complaint within ten days of its receipt and to intimate the complaint redressal
report to the designated officer immediately. If the designated officers do not receive
the complaint redressal report within fifteen days of its receipt by the direct selling
entity, he shallfile non-compliance report before the Monitoring Authority.

(2) Where the contents of the non-compliance report received from the

designated officer against direct selling entity or a direct seller or any other person
who is part of the network of direct selling is found to be genuine and true, the
Monitoring Authority may take such action as the Monitoring Authority deems
appropriaie as mentioned in paragraph 5 above including due intimation to the
enforcement authorities for their appropriate action as per the applicable provisions
of the relevant Acts as provided in paragraph 12 below'

(3) However, any complaint relating to violation of consumer rights or unfair
trade practices or false or misleading advertisements which are prejudicial to the

interests of consumers as a class, may be fonruarded either in writing or in electronic
mode, to any one of the authorities, namely, the District Collector or the
Commissionerof Regional Office or the Central Authority as provided in sections 17
to 23 bf the Consumer Protection Act, 2A19 (Central Act 35 of 2019).

11. Prohibition of Pyramid Scheme, Money Circulation Schemes and Unfair
Trade Practices.- (a) No direct selling entity or direct seller shall promote or indulge
in a Pyramid Scheme or enroll any person to such scheme or participate in such
arrangement in any manner whatsoever in the garb of doing direct selling business
as per clause (a) of rule 10 read with clause (i) of sub rule (1) of rule 3 of the
Consumer Protection (Direct Selling) Rules, 2021. Under Pyramid Scheme, the
substantial benefit or income is derived mainly on the basis of such enrolment or
recruitment and not on the basis of sale of products or services even if the products
or services are bundled in such schemes and packages for the purpose of name
sake. Therefore, no direct selling entity or direct seller shall enter into a scheme or
package or opportunity or participate in such arrangement in any manner for sharing
ifre OJnetits-by means of enrolment or recruitment of further subscribe to such
scheme thereby occupying a higher position for the purpose of earning more benefits
or for making quick oi eisy money out of such higher position and continue with
such succesiive enrolments or recruitments for sharing the income or benefits out of
such successive enrolments or recruitments and finally resulting in a multi-layered
network of subscribers in the garb of doing direct selling business with a sole
intention for sharing the benefits out of such successive enrolments or recruitment
irrespective of the sales volume of products or services.

<!-- page 10 -->

10

(b) No direct selling entity or direct
seller, shall
circutation scheme in any -rrnn"r
.participate in a money
whatsoev"i rn tn"

9116 oi ;;rg direct seling
business as pe]'clause
rril or *i" 10 read wiin .irrr" (f) of sub-rule (1) of rute
the consumer Protection
3 of
lbireci serringiRuL;,,162r. As per crause (c) of section
of the Prize chits and Money circutatiin
2
scn-emes loanning) Act, 1g7g (central
43 of 1978), "money circuraiion schemesi;;;;;
Act
any scheme, by whatever name
called' for the making of quick or easy
money, or foi fl.,u i".uiptLr
money or
valuable thing as thJ consideration
foi a pr*ii* to pay money, on"ny
any event or
contingency relative or applicable to
tne enrotmlnt oi members'inL tn" schemes,
whether or not such mon'uy o," ining'
;; ;;;ir;; from the ;rtr";;; money of the
members of such scheme -or perioii.rr
.ru.liiptions. uni"i ,oney circuration
scheme' the entire benefit or. ilcome
geneii[o
is
o1. derived out of the amount
collected through the successive enrolmeit,
o.
i".rritments
ano tinarry share the
benefit among the subscribers simpty
on ,..orniir participation in such
-or
schemes.
Therefore' no direct selling
direct ."ir"r" shall participate in a money
circulation scheme in any ,"rnn"iio,"
"rtity rnrrin;jh" ;refits
by means of enrorment or
recruitment of further subscribers
to such schleme anO continue *iifi ,r.n
successive
enrolments or recruitments for sharing
ftre incomelr benefits out of such
successive
enrotments or recruitment. anJ rlfarrv
a murti-rayered network of
subscribers in the garb o-f doint oireci.Jli;g
;rsiness with a sole intention for
iuccessive en-rotments or recruitments
without any
::il'lrt*ffiff:"J[""Jl::.t"n

iliil;; ,

(c) No direct selling

or direct seller shail promote or indutge
-e.ntity
in any
misleading, deceptiv" o,. ,ifri.
iiro.
pir.ti"".
in sucn arrangement or
schemes or trades in any manner
"l'prrti"iplte
whatsoever
in-tne garb,of doing direct selling
business across all models or Jit"ct
selling torln"'purpose of earning
more benefits
or for making quick or easy *on"y^ort
oi
such
prlctices
or
schemJs.
As per sub
rule (3) of rule 5 of the contrm"r'Protectionloirl.t
selling)
Rules,
zo21,no direct
selling entity shall adopt any ,nrri,
trade prrdt""-in the course of its business
othen'rrise' and shall a'oioe 6v tne.requirements
or
speciried in any taw for the time
being in force' At
(qtl ot section z
piotection Act, 2o1g
(central Act 35 of P:l9lr.yt"
2019) "unfair ti"o" practicJ' "iilr,iconsumer
*"rn, a trade practice which,
purpose of promoting the sare,
use o,. ruppiv o{ Ili'qooos or for the provision for the
of any
or unrair ;,.;;;piive practice incrudins
any orir,6
till,,ifu'j,??li.:::,#iilethod

(i) making any statement, whether orally. or in

writing or by visible
representation including by means
of electroni. r".oio which farsery
represents that the goods or services,
are or a particular
quarity, quantity, grade, comp.osition,
"-- standard,
styre"o, mooetl-'
(ii) falsely representi ,ny re-built
renovated, reconditioned
old goods as new goodr;
"".ondlhrnd,
(iii) makes a false or riisleading representation concerning
the need for, or
the usefulness of, any goodi oi."*i"".;
(iv) gives to the pubric Lny *rrranty or guarantee
of the performance,
efficacy or length of life of a prooucioriny
goods that is not based on
an adequate or proper test thereof;
(v) represents that ihe'seller or the supplier h.as a
sponsorship or approval
or affiriation which such seiler o,.,rppiier
ooes not have etc.

<!-- page 11 -->

11

(d) As per sub-rule (2) of rule 7 of the Consumer Protection (Direct Selling)
Rules, 2021, a direct selling entity or direct seller shall not.-

(i) indulge in fraudulent activities or sales and shall take reasonable steps
to ensure that participants do not indulge in false or misleading

(ii)
(iiiI

representations or any other form of fraud, coercion, harassment or
unconscionable or unlawful means ;
engage in, or cause or permit, any conduct that is misleading or likely
to mislead with regard to any material particulars relating to its direct
selling business, or to the goods or services being sold by itself or by
the direct seller;
indulge in mis-selting o{ products or seevices to consumers ,'

use, or cause or permit to be used, any fraudulent, coercive,
unconscionable or unlawful means, or cause harassment, for
promoting its direct selling business, or for sale of its goods or

(iv)

(v)
(vi)

services ;
refuse to take back spurious goods or deficient services and refund the
consideration paid for goods and services provided ;
charge any entry fee or subscription fee.

12. Action against violations or non-compliance of the directives of Monitoring
Mechanism.- (1) The violations or non-compliance or partial compliance of the
directives of Monitoring Mechanism by any Direct Selling Entities or Direct Sellers
will be treated seriously. The Monitoring Authority in such cases, either suo-motu or
on the basis of any complaint received in this regard from any stake holders, may

(i) engage one or more persons from any of the enforcement departments

within this Monitoring Authority to make an inquiry in relation to the
alleged complaints and affairs of any Direct Selling Entity;

(ii) Call upon the books of accounts, registers, audited statement of
Accounts, lncome Tax and Goods and Services Tax monthly or annual
returns, certified copies of mandatory registration certificates as per the
Consumer Protection (Direct Selling) rules, 2021 or such other
documents necessary for scrutiny and verification;
(iii) cancel such enrolment or black list those direct selling entities violating
the regulations of the monitoring mechanism repeatedly even after show
cause notices and warnings by the Monitoring Authority;
(iv) issue show cause notice to stop the business of such non-compliances
with immediate effect; and
(v) refer the matter to the Central Consumer Protection Authority or such
other Authorities as envisaged in sections 17 to 23 of the Consumer
Protection Act, 2019 (CentralAct 35 of 2019).
(2) The Monitoring Authority may, before initiating the action proposed in item
Nos. (iii) and (iv) above, may issue notice to the Direct Selling Entity and give them
an opportunity of being heard for seeking their explanation to the action so proposed.
13. Action against violation of provisions of Gonsumer Protection Act, 2019
Consumer Protection (Direct Selling) Rules, 2021 and other Laws applicable to
Direct Selling.- (1) The direct selling entities and the direct sellers have to follow the
relevant provisions'of the Consumer Protection Act, 2019 (Central Act 35 of 2019)
and the Consumer Protection (Direct Selling) Rules, 2021 including other Laws
applicable to direct selling meticulously. The compliance of the provisions and rules
of these Acts and Rules will be monitored under this Monitoring Mechanism.

<!-- page 12 -->

L2

(2) Any contravention or violation of the consumer protection
(Direct selling)
Rules, 2021 shall be dealt with the ,ppropriri" provisions
of
the consumer
Protection Act, 2019 (central Act..35 oi'zofgi including
product liability under
chapter Vl and off.ences and penalties ,nootnlpier
Vll of the said Act. However,
the violation of other laws and rules.snatt-oe-appropriately
dealt by the law
Enforcement
Authorities under the provisions of the 'rr'-r'
appropriate Acts & Rules, which
may include the

following:

(i) Violation relating to any activity leading to money circulation or pyramid
(ii)
(iii)

schemes to be dealt with by the PoliciAuthorities under prize
Chits and
Money Circulation Scheme (Banning) Act, 1g78, (Centrat
ncias of 1g7g)
including criminal case under the prdvisions of lndian penal
Code;
Violation relating
any
activity
leading
to
tr*
evasion,
to be dealt with by
the respective !o
Taxation Auihoritiei under the respective Taxation
Statutes.
Violation of any other applicable laws to be complied
by direct selling
entity as provided in the Consumer Protection (Direct Settingyirr"r,
znzi
shall be dea.lt with by the respective Authoriiies under
,".pective
=,I"n
Statutes; and

(iv) Violation relating to any activity leading to the breach of contract,

appropriate civil
.lemedy can be evoked bLfore the Court of Law having
appropriate jurisd iction.

ADDTToNAL cHrEF #.o*oJ*ky ro covERNMENr.
llTrue Copyll

1: €

Jr e-++-qrd

Section
l\.\'
b \lo*'11
t3\r"'

ffir r.r;1 ;.'.3
r'-.

<!-- page 13 -->

13

ANNEXURE
APPLIGATION FOR ENROLMENT
(See para 4)
(To be submitted by the Direct Selling Entities)
Part A

st.

Particulars

To be filled by Direct Selling
Entity

No.
1.

2.

J.
4.

COMPANY PROFILE
Name of the Direct Selling Entity
(As Registered)
CIN No. / Reg. No.
rrincipal place of Business
ADDRESS FOR COMMUNM
(i) Head Office:

(With PIN Code, e-Mail id, mobile phone,
Telephone with STD Code and Company
Website)

(ii) Branch office in Tami! Nadu
(with PIN Code, e-Mail id, mobile phone
Telephone with STD Code and Company
Website)
5.

rAX PARTICULARS OF COMPANY

(i) lncome Tax Registration No. (pAN)
(ii) lncome Tax TDS Registration.
No. (TAN)

(iii) GST Registration No. (GSTIN)
6.

Name and Contact detaits

(i) Name and contact address of il-re
Directors / partners of the Entity (With
PIN code, eMail id, mobile phone No,
and Telephone No with STD code)

(ii) Name and contact address of key

Management Personnel with their eMail
id & Mobile phone No.
(iii) Name and contact address of Nodal
Officer responsible for monitoring the
compliance of the Consumer protection
Rules, 2021 (With PIN code, g-mail id,
mobile phone No., & Telephone No.,
with STD code)
Name and address
Grievance
Redressal Officer responsible for
redressing the complaint (With PIN
code, ed/ail id, mobile phone No., &
Telephone No with STD code

iv)

of

<!-- page 14 -->

L4

Details of Consumer Grievance Redressal
mechanism as per the Consumer Protection
(Direct Selling) Rules, 2021:
8.
Total number of Direct Sellers working within
the State (as on March 31st of the previous
financial Year)
9.
Details of Products / Services Offered
(enclose product brochure with price break-up)
(i) Details of own products or service with
Trademark or Service Mark as the case
may be
(ii) Details of products or services dealt in
the capacity of holder or licensee of a
trademark or service mark or other
identification marks which identifies the
company and its products.
10. Modes of Direct Selling
(i) Marketing plan adopted:
(ii) Remuneration plan adopted:
(iii) Whether e-commerce platform adopted:
11. lnvestment in business and trading
particulars as per latest audited accounts
available, i.e.; on March 31tt of previous
financial year
(i) Crpitrl & Reserves
(ii) Current liabilities / payable
(iii) lnvestment in Fixed Assets
(iv) lnvestment in Current Assets
(v) Total sales Turnover
(vi) Total Purchases Turnover
(vii) Gross profit
lviii) Net Profit
7.

VERIFICATION

The contents of the above application are true and correct and nothing
material has been concealed by me/us there from.
Verified by me/us a1......

on this day of

Applicant
Name..
Designation......

Tel No.
E-mail:.....

Place & Date

Seal of the Company

<!-- page 15 -->

15

Part-B
(NOTARY ATTESTED AFF|DAVIT/ DECLARATTON)

I / We,

in the capacity of

... of the

company I firm declare that we
including our duly appointed Direct Sellers, shall compliant with the following:

1' lAffe shall be compliant with all the provisions of Consumer protection (Direct
Selling) Rules, 2a21 notified by the Department of Consumer Affairs,

Ministry

of Consumer Affairs, Food and Public Distribution, New Delhi, vide
Notification No.GSR ggg(E) dated 2gth December, 2021.

2' lA&e shall be compliant with all the applicable provisions of Consumer
Protection
(E- commerce ) Rules, 2[2oand the rules frarned there under as provided

in

rule 9 of consumer protection (Direct selling) Rules, 2021.

3' lA//e shall be compliant with all the applicable provisions of the Legal
Metrology Act 2009 (Act 1 of 2010) and the rules framed thereunder
provided in sub-rule 4 of rule 5 and ctause (v) of sub-rule (1)

as

of rule 7 of

Consumer Protection (Direct Selling) Rules, 2021.

4. lAl(e shall be compliant with all the applicable provisions of the Food Safety
and Standards Authority of lndia Act, 2006 (Central Act 34 of 2006) and the
rules framed there under as provided in clause

0) of rule 4 of Consumer

Protection (Direct Selling) Rules, ZOZ1.

5. lAffe shall be complaint with all the orders, circutars, notifications as may be
notified by the Department of Consumer Affairs, Government of lndia" or

by

the Department of Civil Supplies and Consumer Protection, Government of
Tamil Nadu from time to time.

6. lAffe shall set up an authorized office declared in Tamil Nadu and shail
maintain its office, either manually or electronically, all such documents /
registers / books of accounts as are required under any law for the time being

in force, as may be applicable for verification of the enforcement authorities

under this monitoring mechanism, in addition to its maintenance of such
records at its registered office as required as per rule 4 of the Consumer
rl

Protection (Direct Selling) Rules, ZOZ1.

<!-- page 16 -->

16

r'-

7. lAffe shall become a Partner in the convergence process of the Nationai-=
Consumer Helpline of the Central Government as provided in sub-rule 17 of
rule 5 of the Consumer Protection (Direct Selling) Rules, 2021.

8. lAlVe shall not promote a Pyramid Scheme or enrol any person to such
scheme or participate in such arrangement in any manner whatsoever in the

garb of doing direct selling business as provided in sub-rule (a) of rule 10 of
the Consumer Protection (Direct Selling) Rules, 2021.

9. lAffe not participate in money circulation scheme in the garb of doing direct
selling business as provided in sirb-rule (b) of rule 10 of the Consumer
Protection (Direct Selling) Rules, 2021.

10.lAffe shall not promotg any misleading, deceptive or unfair trade practices or
participate in such arrangemenUschernesltrades in any manner whatsoever in

the garb of doing direct selling business across all models of direct selling as
provide in sub-rule (3) of rule 5 read with clause (d) of sub-rule (1) of rule 2 of
the Consumer Protection (Direct selling) Rules, 2A21.

Deponent
DEPONENT VERIFICATION

The contents of the above Affidavit cum Declaration are true and correct and
nothing material has been concealed by me/us there from.
Verified by melus at

on this day of
Deponent

Name
Designation

Tel No.
E-mail

Place & Date

Notary attestation

Seal of the Company

<!-- page 17 -->

L7

List of Enclosures

1. certification made by the company secretary
regarding the veracity and
validity of the certificites and o6.r,ireni.'ffi'rouo
in the website such as
certificates, licenses, policies, declaration.
,lrJ
other
the proper conduct of Direct_seiling Lrrin".. documents required for
as per the consumer
Protection(Direct Selling)
Rules,

2' copy of acknowledgme-nt t"."ru"d2021.
trom the on-line portal

of the Department
of consumer Affairi during the course previous
of
registration
(applicable to
previously on-line registered entities.
^ copy of the latest nuoiteo
3'
financial statements (Balance sheet and profit
and
Loss
A/c with sche-dules) (previous

tinanciaf V"jrl
4' copy of (i) certificate'of incorpo.ration,
(i') Memorandum

of Association
(iii) Articre of Association of the Entity
,ni'tilieye-taws.
9opy of Cerrificate of Registiaiion ofrrrJd;:";i.
6' certificate
or
code 1in casaoi imported goods)
7
List of Board]mqo1t9r-ex-porter
of Directors Partners
address with their E-mair ids and mobire pr.,on" of the Entity with contact
ruo

!

'

I

/ o**rc

8' List of Key Management Personnel with their contact

address with their,
E-mail lds and mobile phone No.
9. Brief detairs of direct seiling scheme and compensation
pran.
10' copy of Product Brochure-witn price
or"rk:rp
required
under clause (g) of
sub-rule (2) of rule 5 of the consumer Proteciion
(Direct
selling)
Rules, 2021.
11' copy of prior written contract
to be executeJ-*iin oir".t ,"irJi" as required
under Rule 6('l) (a) of the consumer Protection'ibirect
seling) Rules. 2021.
12'copy of GsrlN, PAN and rAN or such
other registrations
'-.
necessary for the
Direct Selling
._
13' copy of License ind Registration
certificate issued under the Drugs and
Cosmetics Act, 1g4O (lf ap-plicable)
14.copy of ricense issued unoei
tq"g safety and standards Act, 2006
(Centrat Act No. 34 of 2006 (tf
applicabte).
15' Copy of operating License under
Bureau of lndian standards (Bls) Act,
2016
(lf appticable)
16'copy of Mandatory decrarations under the
Legar Metrorogy (packed
Commodities) Ry]es, ZO11 (lfapplicable)
,_
17 'copy of lncome Tax and Gdooi
and services Tax returns for the latest year;
information or documents, if ,ny, ,.-*ay
be demandeJ from time
,t"i?#.ther

,.

-

Entity.

l^i

"

ADDTT.NAL cHrEr #"o*?Hky ro covERNMENr.
ilTrue Copy//
