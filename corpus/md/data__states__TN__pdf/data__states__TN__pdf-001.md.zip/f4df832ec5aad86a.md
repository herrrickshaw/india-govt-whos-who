---
doc_id: "f4df832ec5aad86a"
source_url: "https://environment.tn.gov.in/assets/go/2b45b1f40d89ebde35b5764fc1a82c9c.pdf"
ministry: "Environment and Climate Change Department, Tamil Nadu"
title: "Climate Studio (G.O.No.22)"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "79d1cf0a559ddfbf"
---

<!-- page 1 -->

#ffiu

(fl€dik};)

"\w

ABSTRACT

Environment, Climate Change - Operation alization of the "Climate Studio and
establishment of conference hall at Center for Climate Change and Disaster
Management,' with a proposed outlay of Rs.3.45 crores - Orders - Issued.
ENVTRONMENT.CLIMATE CHANGE AND FOREST (EC2l DEPARTMENT

Dated: O3.O2.2O22

c.O.(Ms.INo.22

6lanor, ap-21

SCUo,drgorfr QaturG -2053
Read:

G"O(Ms.)No.255 Eenvironment, Climate Change & Forests (EC.2)
Department, dated 17 .O9.2019.
) G.O(Ms.)No. 10 1 Environment, Climate Change & Forests (EC"2)
Department, dated 03. 11.2021.
3. From the Director of Environment, Letter No.P4/ lB92l2Ot9,
Dated: 20.11.2021 and O 1. 12-2021.
1.

=: =::
ORDER:
The Government of Tamil Nadu has taken the initiative to set up an exclusive
Climate Change Research Center the, viz "Centre for Climate Change and

Adaptation Reiearch (renamed as Centre for Climate Change and Disaster
Management (CCCDM)) at Anna University to strengthen the understanding of
c1maG change and oui capacity to manage and adapt to it. CCCDM is engaged
in developing regional climate scenarios using Regional climate models, sectoral
impacts Lnd vulnerability assessments in water, agriculture, coastal, forest,
neattfr and urban sectors. It is also engaged in framing of suitable adaptation
strategies, based on the recommendations of the Inter-Governmental Panel on
Climaie Change (IPCC). This Centre is also updating global and local data
periodically based on continuous assessment reports of IPCC.

' 2. Tamil Nadu State Action Plan on Climate Change (TNSAPCC) has

identified Centre for Climate change and Disaster Management (CCCDM), Anna
University as the sectoral nodal agency for knowledge management in climate
change. CCCDM has provided trainings and organized workshops jointly with the
climate change cell, Department of Environment for various stake holders of line
Departments engaged in preparation of the Tamil Nadu State Action Plan on
Climate Change *itn the aim to improve the understanding and awareness of
their sectoral issues in the light of climate change and ensuring mainstreaming
of climate adaptation in Planning and Development.

<!-- page 2 -->

3. In the Government Order 1st read above, the Government of Tamil Nadu
announced setting up of a "Climate Studio" at the Centre for Climate Change and
Adaptation Research (now CCC & DM), Anna University,, in 2olg with the
objective to contribute to capacity building and knowledge management on
Climate Science and Research. The Climate Studio was set rip with the financial
support from Deutsche Gesellschaft fur Internationale Zuslmmenarbeit (GIZ)
India at Rs. 246.87 iakhs under their Climate Change Adaptation in rural areas
of India Project.
4. In the Government Order 2"d read. above, the Government have issued
orders to set up the Tamil Nadu Green Climate Company
{TNGCC), under

Section 8 of the Companies Act, 2073, to implement the thiee tey Missions of the
Government of Tamil Nadu viz, Green Tamil Nadu Mission, Tamit Nadu Wetlands
Mission and Tamil Nadu Climate Change Mission. l'he three Missions mentioned
above were announced in the Revised Budget 2O2l-22 and, shall be implemented
within a defined time frame to achieve the objectives through the Government of
Tamil Nadu involving the academia, private sectors
civil society for
""a
transitioning the State to climate friendly platforms, championing
renewable

enerS/, building sustainable and resilient infrastructure, climate resilient

agriculture, protection of forests and many other irnportant initiatives across all
the sectors of the Government.

5. Though the "climate Stud;o" was set up in 2olg with adequate

accessories, it was not operationalised for the past one and half years for vaiious
reasons. The Environment, Climate Change & Forest Department has reviewed
the functions of this studio and decided to revive it's activities and sought
pt'oposals to operationalise it. Accordingly a proposal from CCC & DM was
received through Director of Envrionment ,ride ietter 3.d cited for Rs.5.36 crore
including setting up a conference hall at Rs.37 lakhs.
6. CCCDM aims to bring together the scientific communit5r, Government
agencies, National Research Institutes and other Universities with an integrated
research program addressing the climate change issues at the local level in a1l
the Districts. Climate studio is enabled with State of Art comprehensive lab
facility to provide micro-level information on natural resources. The main
objective of the Climate Studio is to contribute to capacity building and
knowledge management on Climate Science and Research. rfre iarget groirps of
the trainees will be government officials, scientists, young researchers and other
stakeholder's. The Climate studio is one of its t i.ra established with high
performance computation facility cluster with storage and accessories for climate
modeling.

Facilities at the Climate Studio

a
o

Models and tools to assess the climate risk and vulnerability on water,
forestry, coastal, health and biodiversity.
Regional Climate Model
PRECIS
Coastal Area Management - SimCLIM- Sea Level Rise Predictions

<!-- page 3 -->

I
. Water Sector - MIKE SHE and SWAT
. Agriculture Model - DSSAT, InfoCrop
Forestry sector - Dynamic Global Vegetation Model (DGVM).
Statistical and mapping model - R, lython & ATcGIS

o
a

Objectives of the Climate Studio

. To provide updated high resolution and robust cadastral level Regional
Climate Scenario for micro ievel policy planning covering entire
Tamil Nadu.

o To do periodical assessment of Climate change Impact & Vulnerability on
Natural Resource S YtZ., Agriculture, Water reSourceS, Forest &
Bio-diversity and Coastal area management based on continuous
assessment rePorts of IPCC.

o To develop multi sectoral cadastral level spatial information using

renowned soft'uvares such as SWAT, MIKE (Water sector), Infocrop,
DSSAT (Agriculture), SImCLIM (coastal), Maxent (Forest) etc., to give a
clear idea of climate impact and damages already caused on ecosystems
and its future vulnerability on natural resources.
To disseminate knowledge to stakeholders - planners, scientific world,
NGO's and community in vernacular languages"

.

Activities of the Climate Studio

.

provide access to climate and vulnerabiiity information for evidencebased adaptation planning at National, State and local level'

o Training Programmes for assessing the climate change impact on
sectors such as Water, Agriculture, Forestry, Coastal, Urban habitation,
Health and BiodiversitY etc.

. Build scientific capacity to develop climate projections and determirle
vulnerability to support adaptation activities.
Develop a network of institutions involved in climate studies and
related research to exchange data, techniques and also to pursue
collaborative research activities.
Expected outcomes of the Climate Studio

o District /Block level climate Snapshots
o Easy access to climate information through a web portal.
...4...

<!-- page 4 -->

Periodical updation of international climate data

to provide latest

climate change information.

Brining all institutes and research centers working in ciimate related
research together to exchange data, techniques and to pursue
collaborative research activities.
Yellow page inforrnation linking all International and National scientific
commlrnity involved in climate studies.

o Building Climate expertise especially amo.rg },;cu.g people.
7. The Department of Environment has therefore requested the

Government to accept the above proposal for functioning of "Climate Studio
along with the establishment of conference hall at Center for Climate
Change and Disaster Management" with a proposed outlay of Rs.5.73 crores

funding support from Environment Management Agency of Tamil Nadu (EMAT)

8. After careful examination, the Government have decided to accept the
proposal of the Director of Environment for operationalization of "Climate
Studio and establishment of a conference hall at the Center for Climate
Change and Disaster Management" at a total cost of Rs.3,45,19,800 (Rupees
three crore forty five lakh nineteen thousand eight hundred only) for the period
from 01.01.2022 to 31.I2.2O23. The above expenditure will be met out from
Environment Management Agency of Tamii Nadu (EMAT) Fund subject to
approval by the Board.
The breakup details of the sanctioned budget is as below:

Amount in Lakhs &

Details

Crore
Technical manpower
Capacity building

1,73,76,O0O

3.

Super computer maintenance and

1,09,00,000

4.

accessories including software
Data procurement for sectors

1.

2.

5.

Contingencies
(including conslrmmates)

27,0O,OOO

13,00,000
6,00,000
3r28r76rOOO/-

Overhead charges for University

16,40,8OO

l-

@ SYo

TOTAL

3r45,19,8OO/-

....5...

<!-- page 5 -->

-5-

9. The Government also direct that construction of conference hal1 and GIS
/ Carto lab renovation shall be carried out not exceeding Rs.35 lakhs and
detailed estimates as per latest SOR be prepared before calling for tenders.
Anna University shall furnish a concept note on potential application of the
Climate studio and software (especially for the 7 vulnerable sectors) which this
Department can share with all Department's. Anna University shall furnish
quarterly returns on works completed and research undertaken. A training
module for Government officials, students and NGO will also be prepared.
10. This order issues with the concurrence of Finance Department' vide
U.O.No.259IJS(GKT) I 2021, dated t6.12.2021.
(BY ORDER OF THE GOVERNOR)

SUPRIYA SAHU
ADDITIONAL CHIEF SECRETARY TO GOVERNMENT
To

The Director of Environment, Chennai- 15.
The Chairman,
Tamil Nadu Pollution Control Board, Chennai - 32"
Copy to:The Hon'ble Chief Minister's Office, Chennai -9.
The Special/Senior Personal Assistant to the
Hon'ble Minister for Environment, Climate Change and
Youth Welfare and Sports Development,
Secretariat, Chennai - 9.
The Private Secretary to Additional Chief Secretary to Government,
Finance Department, Chennai-9.
The Private Secretary to Additional Chief Secretary to Government,
Environment, Climate Change and Forest Department, Chennai-9.
The Private Secretary to Special Secretary (Environment, Climate Change),
Environment, Climate Change and Forest Department, Chennai-9.
The Private Secretary to Additional Chief Secretary to Government,
Finance Department, Chennai-9.
Environment, Climate Change & Forest (FR.7/EC.1,EC.3) Dept.,
Secretariat, Chennai -9.
Stock File / Spare Copy

/i FORWARDED BY ORDER//

^4-".,*

^ -f
F' -<7,
>:ts
SECTION OFFICER
