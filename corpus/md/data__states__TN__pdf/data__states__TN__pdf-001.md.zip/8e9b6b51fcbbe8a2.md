---
doc_id: "8e9b6b51fcbbe8a2"
source_url: "https://consumer.tn.gov.in/pdf/service_rule.pdf"
ministry: "Civil Supplies and Consumer Protection Department, Tamil Nadu"
title: "IMPORTANT GOVERNMENT ORDERS - SERVICE RULES, PDS. ETC"
date: ""
pages: 85
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cb206ddf27e86cd4"
---

<!-- page 1 -->

INDEX
Sl.
No.

G.O. No. & Date

Subject

Page No.

SERVICE RULES
1
2
3

4

5
6

7

8
9

10

11

12

13

G.O.Ms. No. 87,Food Dept. dt:3
April 1978

rd

Public Service – Tamil Nadu Ministerial Service –
Temporary Posts in Civil Supplies Department –
Adhoc Rules
G.O.Ms.No.184,Food Dept.
Public Service – Tamil nadu General Subordinate
dt: 17th July 1978.
Service – Temporary posts of Drivers in Civil
Supplies Department – Adhoc Rules.
G.O.Ms. No. 692,Food &CP Dept.
Public Services – Tamil Nadu General Service –
Dt: 15.2.1980
Deputy Commissioner of Civil Supplies
and
Assistant Secretary to Commissioner of Civil
Supplies – Service Rules – Issued.
G.O.Ms. No. 446 Food & CP Dept.
Rules – Adhoc Rules – Framing of adhoc rules to the
Dt: 3.6.81
Post of Asst.Cmmissioner of C.S(Ins._Technical Asst
and Jr.Tech.Asst. in the Commissioner of
C.S.Department
G.O.Ms.No..139,Co.op. Food &
Public Service – Tamil nadu General Subordinate
CP(E2)Dept.dt:15.2.1993
Service – Temporary posts of Draughtsman Grade II
in CS Dept. –Adhoc rules
murhiz(epiy)vz;.136
gapw;rp
c.bgh.t.k.E.gh.Jiw
–
T.c.k.E,gh(vg;2)Jiw
fz;fhzpg;ghsh;fs;
tl;l
tHA;fy;
ehs;: 20.7.93
mYtyh;fshf
gapw;rpf;F
mDg;g[jy;
Miz btspaplg;gLfpwJ.
G.O.Ms.No. 115 Co.op.Food and
Public Service - Method of Appointment and
C.P(E2) Dept.dt:28.3.2001
qualification to the post of Deputy Commissioner
(CS) Asst.Secy/Asst.Commr.(CS) and Personal Asst.
to Asst.Commr(CS)orders issued.
G.O.Ms. No.142 Co.op.Food &
Adhoc rules – Technical Supervisor – Tech.Asst.and
CP(E2)Dept. dt:7.5.2002.
Asst.Technical Asst. amendment to Adhoc Rules –
issued
Govt.Lr.(D)No. 326/2005 Co.op.F & Establishment – Commr.of CS & CP Dept. T.S.O.
CP Dept. dt: 31.8.2005.
training for one year for the Supdt. in C.S.Dept.
Exemption requested Appeal allowed – instructions
issued- reg.
PUBLIC DISTRIBUTION SYSTEM
murhiz(epiy)vz;.90
c.bgh.t.k.E.gh.Jiw – jkpH;ehl;oy; cs;s bghJ
T.c.k.E,gh(vg;2)Jiw
kf;fs;
bjhptpf;Fk;
tpUg;gj;jpd;
mog;gilapy;
ehs;: 20.7.2010
vg;bghUSk; Btz;lhj FLk;g ml;ilfs; - tHA;Fjy;
Mizfs; btspaplg;gLfpd;wd.
murhiz(epiy)vz;.143
T.c.k.E,gh(vg;-1)Jiw
ehs;: 6.10.2010
murhiz(epiy)vz;.45
T.c.k.E,gh(gp1)Jiw
ehs;: 17.5.2011
murhiz(epiy)vz;.51
Tl;Lwt[, czt[ kwWk;
Efh;Bthh; ghJfhg;g[(o1)
j;Jiw ehs; 14.6.2011

rK}fj; jzpf;if - epahatpiyf; filfspy;
rK}f
jzpf;if
Kiwia mKy;gLj;Jjy; Mizfs;
btspaplg;gLfpd;wd
bghJ tpepBahfj;jpl;lk; - epahatpiyf; filfs; K}yk;
FLk;g ml;iljhuh;fSf;F nytr mhprp tHA;Fjy; Mizfs; btspaplg;gLfpd;wd.
rpwg;g[
bghJ
tpepBahfj;jpl;lk;
Jtuk;gUg;g[
,cSj;jk;gUg;g[, brwpt{l;lg;gl;l BfhJik kht[ kw;Wk;
brwpt{l;lg;gl;l
ghkhapy;
Mfpa
mj;jpahtrpag;
bghUl;fs;
epahatpiyf;
filfs;
K}yk;
tpepBahfpf;fg;gLtij
bjhlh;e;J
bray;gLj;Jjy;
Mizfs; btspaplg;gLfpd;wd.

1–3
4–5
6 – 12

13 – 17

18 - 19
20 - 21

22 – 23

24 –27
28 - 29

30 - 32

33 – 38
39 – 40
41 – 42

<!-- page 2 -->

ENFORCEMENT
14

murhiz(o)vz;.351
T.c.k.E,gh(n1)Jiw
ehs;: 22.9.2006.

15

murhiz(epiy)vz;.78
T.c.k.E,gh(vg;2)Jiw
ehs;: 14.3.2007

rd;khdk; - bghJ tpepBahfj;jpl;lk; - mhprp
kw;Wk; czt[ bghUl;fis flj;Jgth;fs; gw;wp
jfty; mspg;gth;fSf;F rd;khdk; tHA;Fjy;Miz btspaplg;gLfpwJ.
btFkjp – bghJ tpepBahfj;jpl;lk; - Bghyp
FLk;g
ml;ilfs;
Fwpj;J
jfty;
mspg;gth;fSf;F
btFkjp tHA;Fjy; kw;Wk;
mhprp
kw;Wk;
czt[
bghUl;fis
flj;Jgth;fisg;
gw;wp
jfty;
mspg;gth;fSf;F
tHA;fg;gLk;
btFkjpia
cah;j;jp
tHA;Fjy;
Miz
btspaplg;gLfpwJ.

43 – 45

46 – 47

CONSUMER PROTECTION
16

murhiz(epiy)vz;.210
T.c.k.E,gh(vr;2)Jiw
ehs;: 12.12.2008

17

G.O.Ms.No. 167,Co.op.F&CP
(H2) Dept. dt: 27.10.2009.
G.O.Ms.No. 168,Co.op.F&CP
(H2) Dept. dt: 27.10.2009.

18

Efh;Bthh; ghJfhg;g[ - jkpH;ehL Efh;Bthh;
ghJfhg;g[
kw;Wk;
mjpfhur;rA;fk;
(TANSSCOPE)
mikj;J khepy Efh;Bthh;
Brit
ikak;
vDk;
g[jpa
jpl;lk;
bray;gLj;Jjy;
kw;Wk;
2008-2009-k;
Mz;ow;F
ika
muR
tHA;fpa[s;s
epjp
U}.27,60,000/- xg;gspg;g[ bra;J Mizfs;
btspaplg;gLfpd;wd.
Acts and Rules – Tamil Nadu Consumer Protection
Rules, 1968-Amendment orders issued.
Consumer Protection act, 1986 – State Consumer
Protection Council /District Consumer Protection
Council – Reconstitution of – orders Issued.

48 – 52

53 – 60
61 – 75

MISCELLANEOUS
19

murhiz(epiy)vz;.480
bghJ (kWthH;t[-2)j;Jiw
ehs; 7.6.2011

kW thH;t[ Kfhk; nyA;ifj; jkpHh;fs; - jkpHf
kf;fSf;F
tHA;fg;gLk;
eyj;jpl;lA;fis
Kfhk;
thH;
nyA;ifj;
jkpHh;fSf;Fk;
tphpt[ gLj;Jjy; - Miz btspaplg;gLfpwJ

GOVERNMENT OF TAMIL NADU

76 – 80

<!-- page 3 -->

ABSTRACT
PUBLIC SERVICE - Tamilnadu Ministerial Service- Civil Supplies Department
-Certain Temporary Posts in Civil Supplies Department Adhoc Rules-Issued.
________________________________________________________________
FOOD DEPARTMENT
G.O.Ms.No.87
Dated the 3rd April 1978
Read:
Read:
1.G.O.Ms.No.449, Food dated:16.4.47
2.G.O.Ms.No.188, Food dated:2.7.75
3.G.O.Ms.No.3558, Public (Services-B) dated:1.11.75
4.From the Commissioner of Civil Supplies Lr.No.A1/67674/76 dt.
17.1.77.
5.From the Commissioner of Civil Supplies Lr.No.A1/17534/77
dated:2.5.77.
6.From the TamilnaduPublicServiceCommission,
Lr. No.8541/BA1/77 dt.23.1.78.
.......
ORDER
The following notification will be published in the Tamilnadu Government
Gazette.
NOTIFICATION
In exercise of the powers conferred by the proviso to Article 309 of the
Constitution of India, the Governor of Tamilnadu hereby makes the following rules:
The rules hereby made shall be deemed to have come into force on the
dates noted against each post.
From
1.

Godown Superintendent

17.11.64

2.

Circle Officer

07.10.65

3.

Assistant Rationing Officer

19.11.65

4.

Assistant City Supply Officer

18.12.70

5.

Supervisors

20.09.65

6.

Office Manager

07.10.65

7.

Senior Superintendent

04.03.66

8.

P.A. to Assistant Commissioner 25.4.74
-2-

<!-- page 4 -->

RULES
The General and the Special Rules applicable to the holders of the
permanent posts in the Tamilnadu Ministerial Service shall apply to the following
temporary posts sanctioned from time to time for the Civil Supplies Department
subject to the modifications specified in the following rules:

1.

Godown Superintendent

2.

Circle Officer

3.

Assistant Rationing Officer

4.

Assistant City Supply Officer

5.

Supervisors

6.

Office Manager

7.

Senior Superintendent

8.

P.A. to Assistant Commissioner(CS)

2. CONSTITUTION:
The posts shall each constitute a distinct category in the said service.
3. APPOINTMENT:
Appointment to the posts shall be made as follows:
i) By promotion from among the holders of the post of ordinary grade
Superintendent in the Civil Supplies and Consumer Protection Department or
ii) By recruitment by transfer from category of Deputy Tahsildars from the
Tamilnadu Revenue Subordinate Service if no suitable candidate is available for
promotion in Civil Supplies and Consumer Protection Department.
4. APPOINTING AUTHORITY:
The Appointing Authority for the post shall be Joint Commissioner of Civil
Supplies.
-35. QUALIFICATION:

<!-- page 5 -->

No person shall be eligible for appointment to these posts unless he has
completed two years of service as Ordinary Grade Superintendent in the Office of
the Commissioner of Civil Supplies or is an approved probationer in the category
of Deputy Tahsildar.
6.PAY:
There shall be paid to the holder of the posts mentioned in rule 1 a monthly
pay calculated in the following scale of pay:
From 17.11.64 to 1.10.70

In the Scale of Pay of Rs.250-15-400

From 2.10.70 onwards

In the scale of Pay of Rs.425-25-700

7. SAVING:
Nothing contained in these rules shall adversely affect any person
appointed to any of the posts specified in rules 1 prior to the date of the publication
of these rules in the Tamilnadu Government Gazette.
(BY ORER OF THE GOVERNOR)
K.DIRAVIAM
COMMISSIONER AND
SECRETARY TO GOVERNMENT

<!-- page 6 -->

-4GOVERNMENT OF TAMIL NADU
ABSTRACT
PUBLIC SERVICE - Tamilnadu General Subordinate Service - Civil Supplies
Department - Temporary Posts of Drivers in Civil Supplies Department - Adhoc
Rules - Issued.
- - - -- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - FOOD DEPARTMENT
G.O.Ms.No.184

Dated: 17th July 1978
Read:

1. G.O.Ms.No.449, Food dated 16.4.1947
2. From the Commissioner of Civil Supplies Lr.No.A1/27229/78/CS
dt.11.5.1978
**
**
**
ORDER:
The following notification will be published in the Tamil nadu Government
Gazette.
NOTIFICATION
In exercise of the powers conferred by the proviso to Article 309 of the
Constitution of India, the governor of Tamilnadu hereby makes the following rules:The rules hereby made shall be deemed to have come into froce on the 1st
December 1956.
RULES
The General Rules applicable to the holders of the permanent posts in the
Tamilnadu General Subordinate Service shall apply to the temporary posts of
Drivers, sanctioned from time to time for the Civil Supplies Department subject to
the modifications specified in the following rules:2. CONSTITUTION:
The post shall constitute a distinct class in the said service

<!-- page 7 -->

-53. APPOINTMENT:
Appointment to the posts shall be made by direct recruitment or by transfer
from any other class or by recruitment by transfer from any other service.
4. APPOINTING AUTHORITY: The appointing authority for the post shall be
the Assistant Secretary (Establishment) in the office of the Commissioner of Civil
Supplies and Consumer Protection
5.QUALIFICATION: No person shall be eligible for appointment to the post
unless he possesses the following qualifications specified below:a.Must not complete the age of 30 years if recruited direct.
b.Must possess a certificate of competency as driver issued by a competent authority under the Government of Tamil Nadu.
6. PROBATION: Every person appointed to the post shall from the date of
which he joins duty, be on probation for a total period of 2 years on duty within a
continuous period of 3 years.
7. PAY: There shall be paid to the holders of the posts a monthly pay
calculated in the following scale of pay:
From 1.12.1956 to 31.5.1960 Rs.30-1-45
From 1.6.1960 to 1.10.1970 Rs.70-1-80
From 2.10.1970 onwards Rs.150-4-170-5-225
8. SAVING: Nothing contained in these rules shall adversely affect any
persons appointed to the post prior to the date of publication of these rules in the
Tamilnadu Government Gazette.
(BY ORDER OF THE GOVERNOR)
K. DIRAVIAM
COMMISSIONER & SECRETARY
TO GOVERNMENT
/ True copy /

<!-- page 8 -->

-6Public Services - Tamil Nadu General Service - Civil Supplies Department Deputy Commissioner of Civil Supplies and Assistant Secretary to Commissioner
of Civil Supplies in the Civil Supplies Department - Service Rules - Issued
- - - - - - - - - -- - - - - - - --- - - -- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - FOOD & CO-OPERATION DEPARTMENT
G.O.Ms.No.692
Dated:15.2.1980
Read: 1. G.O.Ms.No.310, Food dt.17.3.1969
2. G.O.Ms.No.55, Food dt.2.3.1978
3. G.O.Ms.No.188, Food dt.22.7.1978
4. From the Commissioner of Civil Supplies
Lr.No.A2/13726/10 dated 24.4.1980
5. From the Tamil Nadu Public Service Commission
Lr.No.5473/B1/80-6 dt.29.9.1980
**

**

**

ORDER:
The following notification will be published in the Tamil Nadu Government
Gazette.
NOTIFICATION
In exercise of the powers conferred by the provision to Article 309 of the
Constitution of India, the Governor of Tamil Nadu hereby makes the following
amendments to the special rules for the Tamil Nadu General Service (Section 16
in Volume II of the Tamil Nadu Services Manual, 1969)
The amendments hereby made shall be deemed to have come into force on
the 17th March, 1969 so far as the category of Assistant Secretary to
Commissioner of Civil Supplies in concerned. So far as the category of Deputy
Commissioner of Civil Supplies is concerned, the amendments shall be deemed to
have come into force on the 2nd March, 1978.
AMENDMENTS
In the said Special Rules,
(i) in Part.I, after the entries relating to Class LXIV the following Class and
entries shall be added, namely:"Class LXV Deputy Commissioner of Civil Supplies, Civil Supplies
Department;

<!-- page 9 -->

-7Assistant Secretary to the Commissioner of Civil Supplies, Civil Supplies
Department"
(ii) in Part II after the entries relating to Class LXIV the following Class and
entries shall be added.
"Class LXV Deputy Commissioner of Civil Supplies, Civil Supplies
Department;
Assistant Secretary to the Commissioner of Civil Supplies, Civil Supplies
Department"
2. Constitution:-

This class shall consist of the following categories of officers
namely:Category (1) - Deputy Commissioner of Civil Supplies
Category (2) - Assistant Secretary to the Commissioner of
Civil Supplies

3. Appointments:- Appointment to the two categories shall be made as follows:-

(1)

Category

Methods of appointment

Deputy Commissioner
of Civil Supplies

(1) Promotion from the category of Assistant
Commissioner of Civil Supplies or Assistant
Secretary to the
Supplies

Commissioner of

Civil

or

(2) Recruitment by transfer from the Tamil
Nadu Civil Service
(2)

Assistant Secretary to
the Commissioner of
Civil Supplies

(1) Promotion from the category of Selection
Grade Superintendent in the office of the
Commissioner

of

Civil

Supplies;

or

Recruitment by transfer of the post of
Personal Assistant to the Civil Supplies;
or
(2) Recruitment by transfer from the Tamil
Nadu Civil Service
-8-

<!-- page 10 -->

4.

Qualification: (a) Age:

No person shall be eligible for appointment
to the category of Assistant Secretary to the
Commissioner of Civil Supplies if he has
completed 55 years of age and to the
category of Deputy Commissioner of Civil
Supplies if he has completed 57 years of age
on the first day of July of the year in which
the selection for appoint is made.

(b) Other qualifications:

No person shall be eligible for promotion
to the category of Deputy Commissioner
of Civil Supplies unless he has put in a
service of not less than six years as
Assistant Commissioner of Civil Supplies
or

Assistant

Secretary

to

the

Commissioner of Civil Supplies
(2) No person shall be eligible for promotion
or for recruitment by transfer from the
Tamil

Nadu

Ministerial

Service

to

the

category of Assistant Secretary to the
Commissioner of Civil Supplies unless

he

has put in a service of not less than

five

years as Selection Grade Superintendent or
Personal

Assistant

to

the

Assistant

Commissioner of Civil Supplies.
Explanation:
For the purpose of computation of the service, the services of a Selection
Grade Superintendent rendered previously as Personal Assistant to the Assistant
Commissioner of Civil Supplies and / or Senior Superintendent in the office of the
Commissioner of Civil Supplies will also be reckoned with.
5. Probation:Every person appointed to either of the categories in the class shall, from
-9-

<!-- page 11 -->

the date on which he joins duty be on probation for a total period of two years on
duty within a period of 3 years.
Provided that rules 4 and 5 shall not apply in the case of Deputy Collectors
and District Revenue Officers belonging to the Tamil Nadu Civil Service/
6. Preparation of annual list of approved candidates:
For the purpose of drawing up of the annual list of approved candidates for
appointment to the posts in the class by promotion or recruitment by transfer, the
crucial date on which the candidates should be qualified shall be the first
September of every year.
(BY ORDER OF THE GOVERNOR)
K. KRISHNAMURTHY
Commissioner & Secretary to Government.
To
The Works Manager, Government Press, Madras-1 (for publication
of the notification in the Tamil Nadu Government Gazette)
The Commissioner of Civil Supplies, Madras.5
The Personnel & Administrative Reforms (Per.P) Department,Madras.9 (4
copies)
The Personnel & Administrative Reforms (Per-C) Department
The Personnel & Administrative Reforms (Per-K) Department
The Law Department, Madras - 9
The Tamil Nadu Public Service Commission, Madras.2
All Departments of the Secretariat
SF/SCs
/forwarded / by order /
(C. THEERTHAGIRI)
SECTION OFFICER

-10-

<!-- page 12 -->

FOOD AND CO-OPERATION DEPARTMENT
Amendments to Special rules for Tamil Nadu General Service
(G.O.Ms. No. 692, Food and Co.operation 15th December 1980)
No. SRO B-625/80. In exercise of the power conferred by the proviso to
article 309 of the constitution of India the Governor of Tamil Nadu hereby makes
the following amendments to the special rules for the Tamilnadu General Service
(Section 16 in Volume II of the Tamil Nadu Service Manual, 1969).
The amendments hereby made shall be deemed to have come into force on
the 17th March 1969, so far as the category of Assistant Secretary to
Commissioner of Civil Supplies and Consumer Protection is concerned. So far as
the category of Deputy Commissioner of Civil Supplies is concerned the
amendments shall be deemed to have come into force on the 2nd March 1978.
AMENDMENTS
In the said special rules:
(i) In part I, after the entries relating to class LXIV the following Class and
entries shall be added namely;
“Class LXV Deputy Commissioner of Civil Supplies, Civil Supplies and Consumer
Protection Department.
Assistant Secretary to the Commissioner of Civil Supplies / *Assistant
Commissioner of Civil Supplies Department.
(ii) In part II after the entries relating to Class LXIV the following Class and
entries shall be added namely;
“Class LXV Deputy Commissioner of Civil Supplies, Civil Supplies and Consumer
Protection Department'.
Assistant Secretary to the Commissioner of Civil Supplies / *Assistant
Commissioner of Civil Supplies”.
2. Constitution: This Class shall consist of the following categories of Officers
namely;
Category (i) Deputy Commissioner of Civil Supplies
Category (ii) Assistant Secretary to Commissioner of Civil Supplies /
*Assistant Commissioner of Civil Supplies.
3. APPOINTMENT: Appointment to the two categories shall be made as follows:
-11-

<!-- page 13 -->

Category:

Method of Appointment

(1) Deputy Commissioner of
Civil Supplies

1) Promotion from the category of Assistant
Commissioner of Civil Supplies /** Assistant
Commissioner of Civil Supplies (Inspection) or
Assistant Secretary to Commissioner of Civil
Supplies and Consumer Protection.
2) Recruitment by transfer from the Tamil Nadu
Civil Service.

(2) Assistant Secretary to the
*Recruitment by transfer from among the
Commissioner of Civil Supplies / holders of the post of Superintendent / P.A to
*Assistant Commissioner of Civil Assistant Commissioner of Civil Supplies in the
Supplies
Civil Supplies Department.
*2. Recruitment by transfer from the Tamil
Nadu Civil Service the ratio for the appointment
from the above category shall be 2:1.
(4) QUALIFICATION :(A) Age: No Person shall be eligible for appointment to the
category of Assistant Secretary to the Commissioner of Civil Supplies / * Assistant
Commissioner of Civil Supplies and to the category of Deputy Commissioner of
Civil Supplies if he has completed *** 57 years of age on the first day of July of the
year in which the selection for appointment is made.
(b) Other Qualification:
**(1) No person shall be eligible for promotion to the category of Deputy
Commissioner of Civil Supplies unless he has put in a service of not less than six
years as Assistant Commissioner of Civil Supplies/ Assistant Commissioner of
Civil Supplies (Inspection) or Assistant Secretary to the Commissioner of Civil
Supplies and Consumer Protection.
(2) No person

shall be eligible for recruitment by transfer to th category of

Assistant Secretary

to the Commissioner of Civil Supplies and Consumer

Protection / Assistant Commissioner of Civil Supplies unless he has a put in a
service of not less than five years as Superintendent or Personal Assistant
Commissioner of Civil Supplies or in both.
(3) No person shall be eligible for promotion to the category of Assistant Secretary
to the Commissioner of Civil Supplies and Consumer Protection / Assistant
Commissioner of Civil Supplies unless

he has passed the Account Test for

subordinate Officers , Part – I.
-12-

<!-- page 14 -->

Explanation : For the purpose of computation of the service, the service of a
Selection Grade Superintendent rendered previously as Personal Assistant to the
Assistant Commissioner of Civil Supplies and / or Senior Superintendent in the
Office of the Commissioner of Civil Supplies and Consumer Protection will also be
reckoned with”.
5. PROBATION; Every person appointed to either of the categories in the class
shall, from the date on which he joins duty be on probation for a total period of two
years on duty within a continuous period of 3 years.
Provided that rules 4 and 5 shall not apply in the case of Deputy Collectors and
District Revenue Officers belonging to the Tamil Nadu Civil Service.
6. Preparation of annual list of approved candidates:
For the purpose of drawing up of the annual list of approved candidates, for
appointment to the posts in the class by promotion or recruitment by transfer, the
crucial date on which the candidate should be qualified

shall be the first

September of every year.
(BY ORDER OF THE GOVERNOR)
N.KRISHNAMURTHY
Commissioner & Secretary to Government
/True Copy/
Superintendent
*(Amendment issued in G.O.Ms. No. 1222, Food and Consumer Protection
Department Dated 30.09.1986).
** (Amendment Issued in G.O.Ms. No. 469, Food and Consumer Protection
Department Dated 29.03.1988)
*** (Amendment Issued in G.O.Ms. No. 11, Co.operation Food and Consumer
Protection Department Dated: 21.01.1997).

<!-- page 15 -->

-13GOVERNMENT OF TAMIL NADU
Abstract
Rules – Adhoc rules – Framing of adhoc rules to the post of Assistant
Commissioner of Civil Supplies ( Inspection), Technical Assistant and *Junior
Technical Assistant in the Office of the Commissioner of Civil Supplies and
Consumer Protection.
FOOD AND CO-OPERATION DEPARTMENT
G.O.Ms. No. 446
Read:

DATED; 03.06.81
1. G.O.Ms.No. 38, Food dated 4.3.80.
2. G.O.Ms. No. 161, Food dated 3.7.80.
3. From the Commissioner of Civil Supplies and
Consumer Protection Department Letter No.
A2/16992/80 dated: 12.7.80.
*****

ORDER:
The following notification will be published in the Tamil Nadu Government
Gazette.
NOTIFICATION -I
In exercise of the powers conferred by the proviso to Article 309 of the
Constitution of India, the governor of Tamil Nadu hereby makes the following rules:
2. The Rules hereby made shall be deemed to have come into force on the
1st April 1980.
RULES:
The General Rules applicable to the holders of the permanent posts in
Tamil Nadu General service shall apply to the holders of the temporary. post of
the Assistant Commissioner of Civil Supplies (Inspection)sanctioned from time to
time for the Civil Supplies and Consumer Protection Department subject to the
modifications specified in the following rules.
2. CONSTITUTUION:
The post shall constitute a distinct class in the said service.
3. APPOINTMENT:
Appointment to the post shall be made.
1. By Direct recruitment or
2. By recruitment by transfer from the category of Technical Assistant in the
Office of the Commissioner of Civil Supplies and Consumer Protection.

<!-- page 16 -->

-144. QUALIFICATION: (A) Age: - No person shall be eligible for appointment to the
post by direct recruitment, if he has complected or will complete 30 years of age on
the first day of July of the year in which the selection for appointment is made.
Provided that the age limit may be relaxed up to 40 years in respect of
persons who have 2 years previous experience in Roller Flour Milling Industry.
(B) Other Qualifications: No person shall be eligible for appointment to
the post by the method specified in column (1) of the Table below unless the
possesses the qualification specified in the corresponding entries in column (2)
thereof:
THE TABLE
Method of Appointment

Qualifications

(1) Direct Recruitment

1. M.Sc. Degree with Chemistry
/Zoology/Botany as main subject.
2. Must have obtained a Certificate or Diploma
in Flour Milling Technology.
Provided that other things being equal
preference shall be given to persons having
practical experience in the Inspection of Flour
Mills or analysis of Wheat Products.

(2) Recruitment by Transfer

Must have completed eight years of service as
Technical Assistant.

5. PROBATION : Every Person Appointed to the post of Direct recruitment shall
from the date on which he joins duty be on probation for a total period of two years
on duty within a continuous period of three years. Provided that in the case of
those appointed by recruitment by transfer the period of probation shall be one
year on duty within a continuous period of two years.
6. PAY:

There shall be paid to the holders of post a monthly pay calculated in

the scale of Rs. 750-50-1350.
7. SAVINGS: Nothing contained in these rules shall adversely affect any person
-15-

<!-- page 17 -->

appointed to the post specified in the rules prior to the date of publication of these
rules in the Tamil Nadu Government Gazette.
NOTIFICATION . II
1. The post of *JUNIOR Technical Assistant in the Civil Supplies and
Consumer Protection Department will be brought within the purview of the
Tamil Nadu Public Service Commission and classed as “Non -Technical “
and included in Group II Service for the purpose of Direct Recruitment .
Amendment to the Tamil Nadu Public Service Commission regulation will be
issued separately from Personnel and Administrative Reforms (per. M)
Department.
2. In exercise of the powers conferred by the provision to Article 309 of the
Constitution of India, the Governor of Tamil Nadu hereby makes the
following rules.
3. The rules hereby made shall be deemed to have come into force on the 1st
April 1980.
RULES:
The General Rules applicable to the holders of the permanent post in
the Tamilnadu General Subordinate Service shall apply to the holders of the
temporary post of ** Technical Supervisor Technical Assistant and * Junior
Technical Assistant sanctioned from time to time for the Civil Supplies and
Consumer Protection Department subject to the modifications specified under the
following rules.
2. CONSTITUTION : The post shall each constitute a separate category in a
distinct class in the said service
3. APPOINTMENT : Appointment to the post specified in column (1) below shall
be made by the methods specified in the corresponding entries in Column (2)
thereof.
Name of the Post

Method of Appointment

1) **Technical Supervisor

By promotion from the post of Technical
Assistant in the Civil Supplies and Consumer
Protection Department.
-16-

<!-- page 18 -->

2)Technical Assistant

By Promotion from the Post of *Junior -Technical
Assistant.

3) *Junior Technical Assistant

i) By direct recruitment (or)
ii) *** By recruitment by transfer from the
category of Assistant in the Commissioner of
Civil

Supplies

and

Consumer

Protection

Department).
4. APPOINTING AUTHORITY: The appointing Authority for the post shall be the
Commissioner of Civil Supplies and Consumer Protection.
5. QUALIFICATION :
A) AGE:

No person shall be eligibnle for appointment to the post of *Junior

Technical Assistant *** by direct recruitment if he has completed or will complete
30 years of age on the first day of July of the year in which the selection for
appointment is made.
B) Other Qualifications: No person shall be eligible for appointment to the post
specified in column (1) of the Table below unless he possess the Qualifications
specified in the corresponding entries in column (2) thereof.

THE TABLE
NAME OF THE POST

METHOD OF APPOINTMENT

1. ** Technical Supervisor ** (Must have completed not less than five years of
service as a Technical Assistant).
2. Technical Assistant

1. Must have obtained a certificate or diploma in Flour
Milling Technology

(and )

2. Must have completed Five years of service as
*Junior Technical Assistant.
3.* Junior Technical
Assistant
PROBATION:

B.Sc. Degree with Chemistry/Zoology/Botany as main
subject

*** Every person appointed to the post of * Junior Technical

Assistant by direct recruitment shall from the date on which he joins duty be on
-17probation for a total period of two years on duty within a continuous period of three

<!-- page 19 -->

years.
Provide that every person appointed to the post of *Junior Technical
Assistant by recruitment by recruitment by transfer from the category Assistant in
Commissioner of Civil Supplies and Consumer Protection Department shall from
the date on which he joins duty be on probation for a total period of one year on
duty within the continuous period of two years.
7. PAY:
There shall be paid to the holders of the post specified in column (i) of
the table below a monthly pay calculated in the scale of pay specified in the
corresponding entries in column (2) thereof.
THE TABLE
NAME OF THE POST

SCALE OF PAY

1. ** Technical Supervisor

Rs. 1045-45-1450-65-1775

2. Technical Assistant

Rs.525-25-675-30-855-35-925.

3. Junior Technical Assistant

Rs.400-15-490-20-650-225-700

9.SAVINGS: Nothing contained in these rules shall adversely affect any person
appointed to the post specified in the rules prior to the date of publication of these
rules in the Tamil Nadu Government Gazette.
*(Amendment issued in G.O.Ms. No. 202 Co.operation, Food and Consumer
Protection Department, Dated 23.04.1992).
** (Amendment issued in G.O.Ms. No. 889, Co.operation, Food and Consumer
Protection Department, Dated: 12.12.1985)
***(Amendment issued in G.O.Ms. No. 435, Co.operation, Food and Consumer
Protection Department, Dated: 24.06.1985).
(BY ORDER OF THE GOVERNOR)
N.KRISHNAMURTHY
COMMISSIONER AND SECRETARY
TO GOVERNMENT
/True Copy/
SUPERINTENDENT

-18GOVERNMENT OF TAMILNADU

<!-- page 20 -->

Abstract
Public Service – Tamil Nadu General Subordinate Service – Temporary post of
Draughtsman Grade II in civil Supplies and Consumer Protection Department –
Adhoc Rules - Issued.
CO.OPERATION , FOOD AND CONSUMER PROTECTION (E2)DEPARTMENT
G.O.(Ms)No. 139

Dated:15.2.1993
Read:

1

G.O.Ms. No. 451, Cooperation, Food and Consumer Protection Dated:
12.6.89.

2

From the Commissioner of Civil Supplies and Consumer Protection
Letter No. A1/43006/89 dated: 3.2.90.

3

From the Commissioner of Civil Supplies and Consumer Protection
Letter No. A1/73200/90Dated: 28.4.91.

ORDER:
The following Notification will be published in the Tamil Nadu Government
Gazette:NOTIFICATION
In exercise of the powers conferred

by the proviso to Article 309 of the

Constitution of India, the Governor of Tamil Nadu hereby makes the following
rules:
2. The rules hereby made shall be deemed to have come into force on the 12 th
June 1989.
RULES
The General and the Special Rules applicable to the holders of the permanent
post of senior Draughtsman

in Category -4 in Class XLIII of the Tamil Nadu

General Subordinate Service shall apply to the holder of the temporary post of
Draughtsman Grade II, sanctioned from time to time , in the Civil Supplies and
Consumer Protection Department, subject to the notifications specified in the
following rules:2. CONSTITUTION :
The post shall constitute a separate category in the said class of the said
service.
-19-

<!-- page 21 -->

3. APPOINTMENT:
Appointment to the post shall be made by transfer from Category -4 Senior
Draughtsman in Class XL III .
4. APPOINTING AUTHORITY:
The appointing authority for the post shall be the Joint Commissioner of Civil
Supplies, Madras.
5. PAY:
There shall be paid to the holder of the post monthly pay calculated in the scale
of Rs.905-45-1445-50-1545.

(BY ORDER OF THE GOVERNOR)
A.K.VENKAT SUBRAMANIAN
Secretary to Government
/true copy/

-20-

<!-- page 22 -->

jäœehL muR
RU¡f«
gæ‰Á – czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiw – czÎ¥
bghUŸ tH§fš Jiw f©fhâ¥ghs®fŸ t£l tH§fš mYty®fshf gæ‰Á¡F
mD¥òjš – Miz btëæl¥gL»wJ.
T£LwÎ , czÎ k‰W« Ef®nth® ghJfh¥ò (<2)Jiw
murhiz (ãiy)v©.136
ehŸ 20.7.93
go¡fÎ«:1.

murhiz(ãiy)v© 556 T£LwÎ, czÎ k‰W«
Ef®nth® ghJfh¥ò¤Jiw ehŸ 8.4.87.
2. Miza®, czÎ bghUŸ tH§fš k‰W« Ef®nth®
ghJfh¥ò¤Jiw foj§fŸ m1/33041/94 ehŸ 27.2.96.
3. muR foj v© 10259/<2/95-7 ehŸ 6.10.95,
-----

Miz:
gh®it 1š go¡f¥g£l murhizæš czÎ¥ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤JiwæèUªJ x›bthU M©L« 5 f©fhâ¥ghs®fis
t£l tH§fš mYty® gæ‰Á¡F mašgâæš xU M©L fhy¤Â‰F mD¥g
Mizæl¥g£lJ.
gæ‰Á¡F
mD¥g nt©oa f©fhâ¥ghs®®is
Mizahsnu nj®ªbjL¤J mD¥g nt©Lbk‹W«,vªbjªj kht£l‡¡S¡F
f©fhâ¥ghs®fis gæ‰Á¡F mD¥gyh« v‹gij Áw¥ò Mizahs® k‰W«
tUthŒ ã®thf¤Jiw Mizahs® mt®fSl‹ fyªJ KoÎ vL¡F«go czÎ¥
bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiw Mizahs® nf£L¡
bfhŸs¥g£lh®.
2. gh®it 2š go¡f¥g£l czÎ¥ bghUŸ tH§fš k‰W« Ef®nth®
ggJfh¥ò¤Jiw Áw¥ò Miza® mt®fë‹ fU¤JUit 5.10.95š jiyik¢
brayf¤Âš muR¢ bray® , czÎ¥ bghUŸ
tH§fš k‰W« Ef®nth®
ghJfh¥ò¤Jiw Áw¥ò Miza®, tUthŒ ã®thf Ïiz¢ bray® k‰W« czÎ¥
bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiw muR mYty® ey¢ r§f
cW¥Ãd®fŸ fyªJ bfh©l T£l¤Âš fyªJ ngÁaj‹ mo¥gilæš Ñœ¡f©l
MizfŸ btëæl¥gL»wJ.
(1) czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤JiwæèUªJ
f©fhâ¥ghs®fis t£l tH‡¡š gæ‰Á¡F F¿¥Ãl¥g£l 5 kht£l‡¡S¡F
mD¥òtJ bjhl.®ghf
V‰fdnt Ãw¥Ã¤ÂUªj MizfŸ Ïj‹_y« u¤J
brŒa¥gL»wJ.
(2) x›bthU M©L« t£l tH§fš gæ‰Á¡F f©fhâ¥ghs®fis
ma‰gâ¡F mD¥òtJ bjhl®ghf Miza® czÎ¥ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤Jiw mt®fns 5 kht£l§fis nj®Î brŒJ Kj‹ik
Miza® k‰W« tUthŒ ã®thf MizaUl‹ fyªjhnyhÁ¤J xU kht£l¤Â
‰F xU f©fhâ¥ghs® Åj« IªJ kht£l§fS¡F Xuh©L fhy¤Â‰F ma
‰gâæš mD¥g mÂfhukë¡f¥gL»wJ.
-21-

<!-- page 23 -->

(4) t£l tH§fš gæ‰Á¡F
kht£l§fS¡F mD¥g¥gL«
f©fhâ¥ghs®fS¡F t£l tH§fš gjé¡fhd r«gs¤Jl‹ br‹id
efU¡fhd Å£L thlif¥goÍ« efu <£L¥goÍ« tH§f¥glkh£lhJ.
(MSeç‹ Miz¥go)
kh,ÏuhK
muR¢ brayhs®
bgWe®
Miza®
czÎ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤Jiw,br‹id -5
Áw¥ò Miza® k‰W« tUthŒ ã®thf Miza®,br‹id-5
khãy fz¡fhŒÎ jiyt®,br‹id – 18
khãy fz¡fhŒÎ jiyt®(Á.V.v¥) br‹id-9.
r«gs fz¡F mYty®(»H¡F)br‹id – 5
kht£l M£Á¤ jiyt®fŸ, mid¤J kht£l«
ãÂ¤Jiw, br‹id – 9
tUthŒ¤Jiw, br‹id – 9
gâahs® k‰W« ã®thf Ó®ÂU¤j¤Jiw , br‹id – 9
// Miz¥go mD¥g¥gL»wJ//
ÃçÎ mYty®

-22-

<!-- page 24 -->

GOVERNMENT OF TAMILNADU
Abstract
Public Service – Civil Supplies and Consumer Protection Department – Method of
appointment and qualification to the post of Deputy Commissioner (Civil Supplies)
Assistant Secretary /Assistant Commissioner (Civil Supplies) and Personal
Assistant to Assistant Commissioner (Civil Supplies ) orders Issued.
CO.OPERATION , FOOD AND CONSUMER PROTECTION (E2)DEPARTMENT
G.O.(Ms)No. 115

Dated: 28.3.2001
Read:

1 Commissioner of Civil Supplies and Consumer
Protection Letter No. A1/46672/88 dt: 13.3.91.
2 Government Letter No. 37342/E2/86-39 Co.operation ,
Food and Consumer Protection Dated: 18.4.91.
3 Commissioner of Civil Supplies and Consumer
Protection Letter No. A1/46672/88 dt: 10.5.91.
4 Special Commissioner and Commissioner of Civil
Supplies and Consumer Protection Letter No. (C)
63464/90 dt: 3.8.91.
-------ORDER:
In the circumstances stated by the Special Commissioner and
Commissioner of Civil Supplies and Consumer Protection in the letters read above
and in order to provide

better promotional avenues

to the staff of the Civil

Supplies and Consumer Protection Department, which is confined only to the City
and belt areas, the Government pass the following orders:i) The post of Deputy Commissioner of Civil Supplies shall be filled up from the
District Revenue Officer only if qualified and suitable departmental personnel are
not available for promotion, without fixing any ratio.
ii) The posts of Assistant Commissioner of Civil Supplies and Assistant Secretary
to Commissioner of Civil Supplies and Consumer Protection shall be filled up from
the departmental candidates and Deputy Collectors in the Tamil Nadu Civil Service
in the ratio of 2: 1 respectively.
iii) Service qualification for Assistant Commissioner of Civil Supplies and Assistant
Secretary to Commissioner of Civil Supplies and Consumer Protection for
-23-

<!-- page 25 -->

promotion as Deputy Commissioner shall be reduced from 6 years to 2 years.
iv) Service qualification for Personal Assistant to Assistant Commissioner of Civil
Supplies for promotion as Assistant Commissioner/Assistant Secretary shall be
reduced from five years to two years.
v) The post of Assistant Secretary to Commissioner of Civil Supplies and
Consumer Protection shall be re-designated as “Assistant Commissioner” and the
post of Personal Assistant to Assistant Commissioner as “Administrative Officer”.

2. The Special Commissioner and Commissioner of Civil Supplies and Consumer
Protection is requested to send necessary proposal for amending the relevant
service rules to the Government for approval.

(BY ORDER OF THE GOVERNOR)
LAKSHMI PRANESH,
SECRETARY TO GOVERNMENT
To
The Special Commissioner and
Commissioner of Civil Supplies and
Consumer Protection, Chennai -5.
Copy to:
The Tamil Nadu Public Service Commission, Chennai -2
The Commissioner of Revenue Administation, Chennai -5.
Revenue /Public/Personnel and Administrative Reforms Departments,Chennai -9.
sfs/scs
// forwarded /by order//
Sd/
Section Officer

<!-- page 26 -->

-24GOVERNMENT OF TAMIL NADU
Adhoc Rules – Technical Supervisor – Technical Assistant and Assistant Techical
Assistant - Amendment to Adhoc Rules - Issued.
CO.OPERATION FOOD AND CONSUMER PROTECTION (E2)DEPARTMENT
G.O.Ms. No. 142

Dated: 7.5.2002.

1 G.O.Ms.No.38, Food Department, dated 4.3.1980
2 G.O.Ms. No. 446, Food and Co.operation Department, Dated:
3.6.1981.
3 G.O.Ms. No. 435, Food and Co.operation Department, Dated
24.6.1985.
4 G.O.Ms. No. 889, Food and Co.operation Department, dated
12.12.1985.
5 G.O.Ms. No. 202, Co.operation, Food and Consumer Protection
Department, dated 23.4.1992.
READ ALSO:
6 From the Commissioner of Civil Supplies and Consumer Protection
Letter No. A1/56917/84 dated 14.2.1989, 24.3.1990 and 4.2.1991.
7 From the Secretary, Tamil Nadu Public Service Commission Letter
No. 5291/RND-C2/96 dated :5.12.1996.
8 From the Commissioner of Civil Supplies and Consumer Protection
Letter No. A1/50292/94, dated11.3.1997 adn dated 17.9.1999.
--------ORDER:
The Government in their orders second to fifth read above issued
orders framing adhoc rules for the posts of Assistant Commissioner (Inspection),
Technical Supervisor, Technical Assistant and Assistant Technical Assistant in the
office of the Commissioner of Civil Supplies and Consumer Protection. One of the
qualifications prescribed in the

adhoc rules for appointment to the post of

Technical Assistant by promotion is possessing a Certificate of diploma in “Flour
Milling Technology”.
2)

The Commissioner of Civil Supplies and Consumer Protection has stated

that the Government of India rescinded the Wheat roller Flour Mills (Licensing and
Control) Order , 1967, in October 1986. As the training course of “Flour Milling
Technology” conducted by Central Food Technology Research Institute, Mysore is

-25-

<!-- page 27 -->

very expensive , the Commissioner of Civil Supplies and Consumer Protection has
suggested to substitute the training course by 'Storage
Foodgrains'. conducted

and Inspection of

by the Indian Grain Storage Institute at Hapur, Uttar

Pradesh or its field Station at Hyderabad as a qualification in the place of training
course on 'Flour Milling Technology ' for Technical Assistants and Junior Technical
Assistants. The Commissioner of Civil Supplies and consumer Protection has also
proposed the method of direct recruitment of candidate for the post of Technical
Assistant with the qualification of M.Sc.Degree in chemistry/zoology/Botany as
main subject , prescription of probation of two years on duty within a continuous
period of three years for the direct recruitment to the post of Technical Assistant,
and reduction of service qualification from five years to three years for Technical
Assistants for promotion as Technical Supervisor.
3. The Government after careful examination have decided to accpt the proposal
of the Commissioner of Civil Supplies and Consumer Protection except the
qualification of M.Sc. Degree in Chemistry / Zoology/Botany as main subject. The
Government consider B.Sc. Degree in the above discipline would be adequate.
4. The Public Service Commission was consulted in the matter and it has
suggested to bring the post of Technical Assistant under its purview in view of the
scale of pay of the post etc. and to classify the post as 'Technical' . It has also
suggested to raise the age limit from 28 to 30 years for the direct recruits to the
post of 'Technical Assistant and Assistant Technical Assistants. Accordingly, the
following Notifications will be published in the Tamil Nadu Government Gazette.:NOTIFICATION – I
In exercise of the powers conferred by the proviso to Article 309 of the
Constitution of India, the Governor of Tamil Nadu hereby makes the following
amendments to the rules published with Food and Co.operation, Notification SRO
No. 271/81 dated the 3rd June 1981 at pages 292-293 of Part III – section 1(b) of
the Tamil Nadu Government Gazette, dated the 24th June 1981 as subsequently
amended.'
2. The amendments hereby made shall come into force on the

In exercise of

the powers conferred by the proviso to Article 309 of the Constitution of India, the
Governor of Tamil Nadu hereby makes the following amendments to the rules
published with Food and Cooperation, Notification SRO No. 271/81 dated the 3rd

<!-- page 28 -->

-26June 1981 at pages 292-293 of Part III – section 1(b) of the Tamil Nadu
Government Gazette, dated the 24th June 1981 as subsequently amended.'
2. The amendments hereby made shall deemed to have come into force on the
29th September 1988.
AMENDMENT
1) In the said Rules, in rule 5, in sub – rule (b) in the Table, the entries .
“Must have obtained a certificate or diploma in Flour Milling Technology ' in item
(2) in Column (2) against, the entry Technical Assistant in Column (1) thereof, shall
be omitted.
NOTIFICATION- II
In exercise of the powers conferred by the proviso to Article 309 of the
Constitution of India, the Governor of Tamil Nadu hereby makes the following
amendments to the rules published with Food and Co.operation, Notification SRO
No. 271/81 dated the 3rd June 1981 at pages 292-293 of Part III – section 1(b) of
the Tamil Nadu Government Gazette, dated the 24th June 1981 as subsequently
amended.'
2. The amendments hereby made shall come into force on the 7th May 2002.
AMENDMENTS
1. In the said Rules, in rule 3, for the entries in column (2), against the entry'2
Technical Assistant in column (1) thereof, the following entries shall be substituted
namely:
i) By direct recruitment , or
ii) By promotion from the post of Junior Technical Assistant'
2. in rule 5 -(1) in sub – rule (a), for the expression '28 years of age ' the expression 'the age of
30 years' shall be substituted:
(2) in sub – rule (b) in the Table, for the entries, “I Technical Supervisor” and “2
Technical Assistant ' in column (2) thereof, the following entries shall , respectively,
be substituted namely: 1.Technical
Supervisor
2. Technical
Assistant

Must have completed three years of services as Technical
Assistant.
i) Must possess a degree in Science with Chemistry , Zoology or
Botany as main subject for appointment by direct recruitment.
ii) Must have completed five years of service as Junior
Technical Assistant for appointment by Promotion'.
-27-

<!-- page 29 -->

3. for rule 6, the following rules shall be substituted:
Probation:
(a) Every person appointed to the posts of Technical Assistant and Junior
Technical Assistant by direct recruitment, shall from the date on which he joins
duty, be on probation for a total period of two years on duty within a continuous
period of three years.
(b) Every person appointed to the posts of Junior Technical Assistant by
recruitment by transfer from the category of Assistant in the Civil Supplies and
Consumer Protection Department shall from the date on which, he joins duty , be
on probation , for a total period of one year on duty within a continuous period of
two years.
6A TRAINING:
Every person appointed to the post of Technical Assistant by direct recruitment
and to the post of Junior Technical Assistant by direct recruitment or by
recruitment by transfer, shall complete the long term training course in “Storage
and Inspection of Food grains' imparted by the Indian Grain Storage Institute at
Hapur, Uttarpradesh or at its field station at Hyderabad the period of Probation'
6B – Preparation of annual list of approved candidates:
i.

For the purpose of preparation of the annual list of approved candidates for
appointment to the posts of Technical Supervisor and Technical Assistant,
by promotion, the crucial date on which a candidate shall possess the
prescribed qualification shall be the first September of every year.

ii.

For the purpose of preparation of the annual list of approved candidates for
appointment to the post of Junior Technical Assistant by recruitment by
transfer, the crucial date on which the candidates shall possess the
prescribed qualification shall be the first September of every year '.
(BY ORDER OF THE GOVERNOR)
LAKSHMI PRANESH
SECRETARYTO GOVERNMENT

To
The Commissioner of Civil Supplies and
Consumer Protection, Chennai -5.
//Forwarded by Order//
SECTION OFFICER
//true copy//
Superintendent
-28-

<!-- page 30 -->

Co-operation, Food and
Consumer Protection
Department, Secretariat,
Chennai - 9.
Letter (D) No.326/2005 Dated 31.8.2005.
From
Thiru S. Ramakrishnan, IAS.,
Principal Secretary to Government
To
The Commissioner of Civil Supplies and
Consumer Protection,
Chennai - 5.
Sir,

Sub:

Establishment - Commissioner of Civil Supplies & Consumer Protection
Department - Taluk Supply Officer training for one year for the
Superintendent in Civil Supplies Department - Exemption requested Appeal allowed - instruction issued - Regarding.

Ref:

1.From the Commissioner of Civil Supplies and Consumer Protection
Proceedings No.A1/4229/2003 dated 21.11.2003.
2.Thiru R. Balakrishnan, Superintendent Appeal Petition dated 24.2.2004.
3.From the Commissioner of Civil Supplies and Consumer Protection letter No.A1/4229/2003 dated 28.9.2004.

**
**
**
I am directed to state that Thiru R. Balakrishnan and
Thiru
P.V.Sankanarayanan, Superintendents Office of the Commissioner of Civil
Supplies and Consumer Protection who have completed 2 years Tahsildar training
have requested for exemption from the Taluk Supply Officer training for promotion
as Administrative Officer in Civil Supplies and Consumer Protection Department.
The Commissioner of Civil Supplies and Consumer Protection has rejected the
representations of Thiru R. Balakrishnan and
Thiru
P.V.Sankaranarayanan Superintendents in the proceedings dated 21.11.2003
stating that the exemption from Taluk Supply Officer training cannot be given since
the Taluk Supply Officer training is the pre-requisite qualification for further
promotion as per the orders of the Government.
2. Thiru R. Balakrishnan and Thiiru P.V. Sankaranarayanan made an
appeal to the Government against the above said order.
3. In this connection I wish to point out that even though the training as
Taluk Supply Officer for a period of one year is prescribed as a pre-requisite
qualification for promotion to the post of Administrative Officer in the executive
-29-

<!-- page 31 -->

order the Adhoc rules have not yet been amended to that effect. In the Writ
Petition filed by Thiru P.S. Venkataraman - vs - the Government in Writ Petition
No.32491/2002 and in Writ Miscellaneous Petition No.47227/2002 and Writ
Miscellaneous Petition No.1457/2002 of the High Court of Madras it has been
clearly spelt out that panels for a post, should be prepared with reference to
statutory rules and not with reference to executive orders. In view of this, the
Panel of the post of Administrative Officer should be prepared with reference to
Statutory rules. Hence the question of equating the Tahsildar Training with that of
Taluk Supply Officer training or granting exemption from undergoing the Taluk
Supply Officer training for promotion to Administrative Officer does not arise.
4. In view of the above position, after careful examination the Government
have decided to allow the appeal petitions of Thiru R. Balakrishnan and Thiru
P.V.Sankaranarayanan Superintendents, Office of the Commissioner of Civil
Supplies and Consumer Protection and accordingly Commissioner of Civil
Supplies and Consumer Protection is directed to take necessary action to promote
Thiru R. Balakrishnan and Thiru P.V. Sankaranarayanan Superintendents as
Administrative Officer in their turn without insisting for Taluk Supply Officer training,
if they are otherwise eligible for such promotion.
5. Receipt of this letter may be acknowledged.
Yours faithfully,
for Principal Secretary to Government.

-30-

<!-- page 32 -->

PUBLIC DISTRIBUTION SYSTEM
RU¡f«
czÎ bghUs tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw – jäœeh£oš cŸs
bghJk¡fŸ – bjçé¡F« éU¥g¤Â‹ - mo¥gilæš v¥bghUS« nt©lhj
FL«g m£ilfŸ – tH§Fjš – MizfŸ btëæl¥gL»‹wd.
T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò (v¥2) Jiw
muR Miz (ãiy) v© 90

ehŸ-20.07.2010
Mo 4, ÂUtŸSt® M©L 2041
go¡f
1. muR Miz (ãiy) v© 209, T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò¤ Jiw,
ehŸ 18.12.2009.
2. czÎ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiw Mizahsç‹ foj
e.f.v© Ï5/16151/2009, ehŸ17.11.09.
Miz
jäœeh£oš, bghJ éãnahf¤ Â£l¤Â‹ Ñœ vªj bghUS« bgw éU¥g«
Ïšiy

vd

bjçé¡F«

m£iljhu®fS¡F

mt®fŸ

ÏU¥Ãl

Mjhukhf

ga‹gL¤J« tifæš nk‰f©l v¥bghUS« nt©lh kŠrŸ ãw “N”

FL«g

m£ilfŸ tH§f¥gL»‹wd. Ú¡fš/m£il Ïšyh/ x¥òé¥ò rh‹WfŸ bgw¥g£l
Ã‹dnu éU¥g¤Â‹ ngç‹ Ï¡FL«g m£ilfŸ tH§f¥gL»‹wd.

Ï›thW

v¥bghUS« nt©lh FL«g m£ilfŸ bgWtÂš, fhyjhkj« V‰gL»wJ vd
bjçé¡f¥g£l fU¤Â‹ mo¥gilæš,

Ï¤jifa FL«g m£il nfhU«

kDjhu®fŸ, mt®fŸ tÁ¡F« ÏU¥Ãl¤Â‰fhd Mjhu¤ij më¤jhš, mj‹
mo¥gilæš, uæšnt k‰W« flÎ¢Ó£L mYtyf§fëš éiuÎ Kiwæš (tatkal)
Jçjkhf gaz¢Ó£LfŸ k‰W« flÎ¢Ó£LfŸ tH§FtJ nghš, éiuÎ, Kiwæš
v¥bghUS« Ïšyh ÏU¥Ãl rh‹W FL«g m£ilfis (kŠrŸ ãw “N” FL«g
m£il) Ã‹tU« têKiwfis¥ Ã‹g‰¿ tH§fyh« vd czÎ¥ bghUŸ tH§fš
k‰W« Ef®nth® ghJfh¥ò¤ Jiw Mizahs® fU¤J bjçé¤JŸsh®.
1. éiuÎ Kiwæš v¥bghUS« nt©lh kŠrŸ ãw “N” FL«g m£ilfŸ

bgw éU«ònth® mj‰Fça got¤Âš é©z¥g¤Âid ó®¤Â brŒJ j
‰nghJ mt®fŸ tÁ¡F«
Mtz§fëš

ÏU¥Ãl Kftç¡F Mjhukhf Ñœ¡f©l

VnjD« x‹¿id Ïiz¤J t£l tH§fš mYty® /

cjé Mizahs® mYtyf¤Âš kDéid bfhL¤j x¥òjš bgw
nt©L«.
-31-

<!-- page 33 -->

•

th¡fhs® milahs m£il (efš)

•

flÎ Ó£L (efš)

•

t§» nrä¥ò fz¡F ò¤jf« (efš)

•

kU¤Jt fh¥Õ£L <£LWÂ milahs m£il (efš),

•

X£Le® cçk« (efš)

2. Ï›thW é©z¥g« më¤j 7 Âd§fS¡FŸ FL«g m£ilfŸ
tH§f¥gl nt©L«.
3. Ï›thW

m£il

tH§FnghJ

Ñœ¡f©l

ãgªjidfis

FL«g

m£ilæš m¢ro¤J tH§fyh«.

2.

•

Ïªj FL«g m£ilfis ga‹gL¤Â ãaha éiy m§fhofëš
m¤ÂahtÁa¥ bghU£fŸ bgw KoahJ

•

Ï¤jifa FL«g m£ilfis ÏU¥Ãl Mjhu¤Â‰fhd Mtzkhf
k£Lnk ga‹gL¤j KoÍ«

•

Ï¤jifa FL«g m£ilfis ga‹gL¤Â Ãw Ïl§fëš
m¤ÂahtÁa¥ bghU£fŸ bgw¤j¡f mçÁ/r®¡fiu éU¥g FL«g
m£ilfis bgw KoahJ

•

Ï¤jifa FL«g m£ilfis ga‹gL¤Â Ã‹d® m¤ÂahtÁa¥
bghU£fŸ bgw¤j¡f FL«g m£ilahf kh‰w ÏayhJ.

czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw Mizahsç‹

fU¤JUit muR ftdKl‹ gçÓyid brŒjJ, K‹g¤Â 2-š F¿¥Ã£LŸs
têKiwfis¥ Ã‹g‰¿ v¥bghUS« Ïšyh FL«g m£ilfŸ tH§fyh« vd muR
MizæL»wJ.

Ïªj FL«g m£ilfis òÂjhf¥ bgWtj‰F« k‰W« Áy

ne®Îfëš efš FL«g m£il bgWtj‰F« %.100 f£lzkhf brY¤j nt©L«
vdÎ« muR MizæL»wJ.

<!-- page 34 -->

3.

nkny, g¤Â 2-š cŸs Mizfis brašgL¤Jtj‰F cça elto¡iffŸ

vL¡FkhW czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw Mizahs®
nf£L¡ bfhŸs¥gL»wh®.

-324.

Ï¡nfh¥Ãid

ãÂ¤Jiwæ‹

x¤ÂirÎl‹

btëæl¥gL»wJ.

(m.rh.F.v©1252/FS/P/2010, ehŸ 31.05.2010)

(MSeç‹ Miz¥go)

°tu‹ Á§
muR Kj‹ik¢ brayhs®
bgWe®
Mizahs®,
czÎ¥ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤ Jiw, br‹id-5.
T£LwÎ¢ r§f§fë‹ gÂths®, br‹id-10
nkyh©ik Ïa¡Fe®,
jäœehL Ef®bghUŸ thâg¡ fHf«, br‹id-10
mid¤J kht£l M£Á¤ jiyt®fŸ.

efš
T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò¤ Jiw Kj‹ik¢ brayhsç‹
jå¢ bray®, br‹id-9

<!-- page 35 -->

czÎ mik¢r® mt®fë‹ Áw¥ò ne®Kf cjéahs®, br‹id-9
ãÂ¤Jiw, br‹id-9

/Miz¥go mD¥g¥gL»wJ/

ÃçÎ mYty®

-33RU¡f«

r_f¤ jâ¡if – ãahaéiy filfëš r_f jâ¡if Kiwia
mKšgL¤Jjš – MizfŸ btëæl¥gL»‹wd.
T£LwÎ , czÎ k‰W« Ef®nth® ghJfh¥ò¤(v¥1)Jiw
muR Miz (ãiy) v© 143
ehŸ 6.10.2010.
òu£lhÁ 20 ÂUtŸSt® M©L
2041
go¡f:
czÎ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiw Mizahsç‹

<!-- page 36 -->

foj e.f. v©. Ï2/10913/2010 ehŸ 4.6.2010.
Miz:18.4.2010 m‹W r£lk‹w¥ nguitæš eilbg‰w czÎ¥ bghUŸ
tH§fš k‰W« Ef®nth® ghJfh¥ò khåa¡ nfhç¡ifæ‹ nghJ kh©òäF
czÎ mik¢r® mt®fŸ Ã‹tU« m¿é¥ig btëæ£lh®,
“bghJ éãnahf¤ Â£l¤Â‹ Ñœ brašgL« ãaaaéiy m§fhofŸ
brayh¡f mYty®fŸ jâ¡if Áw¥ò MŒÎ¡FG¡fŸ jâ¡if ngh‹w
gšntW jâ¡if Kiwfshš MŒÎ brŒa¥gL»‹wd. bghJ éãnahf¤
Â£l¤Â‹
brašgh£oY«
ãahaéiy
m§fhofŸ
brašgh£oY«
btë¥gilahd Kiwia¡ bfh©L tU« tifæš ãahaéiy m§fhofë‹
gÂntLfisÍ« (fz¡FfŸ) rKjha jâ¡if¡F c£gL¤j¥gL« . Ïj‹go
x›bthU ãahaéiy m§fhoæY« »uhk¥òw§fëš M©o‰F ÏUKiw
»uhkrig
T£l¤Jl‹ ÏizªJ rKjha jâ¡if nk‰bfhŸs¥gL« . ef®òw§fëš
th®L mséš Áw¥ò¡ T£l§fŸ
el¤Â r_f jâ¡if¡F V‰ghLfŸ
brŒa¥gL«, r_f jâ¡ifæ‹ Koéš R£o¡ fh£l¥gL« FiwghLfŸ gÂÎ
brŒa¥g£L r«gªj¥g£l mYty®fS¡F elto¡iffS¡F mD¥g¥g£L .
vL¡f¥gL« elto¡iffŸ f©fhâ¡f¥gL«”.
2. ãahaéiy¡ filfS¡fhd r_f¤ jâ¡if
Kiwia mKšgL¤JtJ r«gªjkhf czÎ¥ bghUŸ tH§fš k‰W« Ef®nth®
ghJfh¥ò¤Jiw Mizahs® Ã‹tU« fU¤J¡fis bjçé¤JŸsh®.
4. »uhk
gŠrha¤Jfëš
Kjš
f£lkhf
r_f
jâ¡if
m¿Kf¥gL¤j¥gL«. ef®òw gFÂfS¡F r_f jâ¡ifia éçÎ
gL¤JtJ F¿¤J Ã‹d® gçÓè¡fyh«. gFÂ neu m‡¡hofS¡fhd
r_f jâ¡if jhŒ fil¡fhd »uhk rig/ r_f jâ¡if eilbgW«
Ïl¤Ânyna el¤j¥gl nt©L«,
5. éçthd bghJ éãnahf Â£l r_f jâ¡if¡fhd ifnaL jäêš
czÎ¥ bghUŸ tH§fš
(k‰W«) Ef®nth® ghJfh¥ò¤Jiw
Mizahsuhš jahç¡f¥g£L kht£l M£Á¤ jiyt®fŸ k‰W« fs
mYty®fS¡F
mD¥g¥gL«. r_f
jâ¡if¡fhd gæ
‰Áahs®fS¡fhd gæ‰Á Kjèš kht£l mséY« mj‹ Ã‹ t£l
mséY« el¤j¥gL«.
Kj‹ Kiwahf r_f jâ¡if Kiwia brašgL¤j Ã‹tUkhW
61.20 y£r« %ghŒ ãÂ cjé njit¥gL« vd Mizahs® bjçé¤JŸsh®.

-34t.v©

bryéd étu«

1

r_f jâ¡ifahs®fŸ v©â¡if
22,665 %.1,35,930= 1,38,000
200 jâ¡ifahs®fis bfh©l FGé
‰F xU gæ‰Á tF¥ò v‹w mo¥gilæš
gæ‰Á tF¥ò el¤j 1,36,000/200 = 680
FG¡fŸ

bryéd¤ bjhif
(%ghæš)

<!-- page 37 -->

2
3

4

xU FGé‰F gæ‰Á tF¥ò el¤j O k‰W«
xè bgU¡» bryÎ
%.2000/-(xU FGé‰F) 680 FG =13,60,000
gæ‰Á bghUŸfŸ ml§»a ifnaL
13,60,000 eg®fŸ %.20/és«gu bryÎ. g¤Âç¡if¢ brŒÂ
kht£l M£Á¤ jiytuhš btëæl¥gL«
- Rtçš t©z« mo¤J és«gu« brŒa
m§fho
x‹W¡F
%.50/v‹w
mo¥gilæš
---22,655 m§fhofŸ %.50/-=11,32,750/g¤Âç¡if és«gu« %.
5,00,000/xU gæ‰Á tF¥Ã‰F _‹W muR
mYty®fŸ mšyhj gæ‰Áahs®fS¡F
CÂa« tH§f 680 gæ‰Á tF¥òfŸ _‹W
gæ‰Áahs®fŸ %.200/bkh¤j bryÎ

%.13,60,000/%.27,20,000/-

%16,32,750/-

%.4,08,000/%.61,20,750/=61.20 y£r« %ghŒ

Ï¤Â£l¤Âid brašgL¤j ika muR 80%bryéd¤ijÍ« khãy muR 20%
bryéd¤ijÍ« V‰W¡ bfhŸs nt©L« v‹W« khãy muR mj‹ g§fhd 12.24
y£r %ghia

V‰W¡ bfhŸsÎ«

vŠÁa

bjhif 48.96 y£r« %ghia ika

muÁläUªJ bgwÎ« cça mDkÂ bg‰W tH§FkhW« czÎ bghUŸ tH§fš k
‰W« Ef®nth® ghJfh¥ò¤Jiw Mizahs® muir¡ nfhçÍŸsh®.
3.
Ïªãiyæš Ñœ¡f©l fU¤JU¡fë‹ ÛJ cça Mizfis bg‰W
tH§FkhW Mizahs® nf£L¡ bfh©LŸsh®.
m) mid¤J »uhk gŠrha¤J¡fëY« ãahaéiy¡ filfëš r_f jâ¡if
Â£l¤ij brašgL¤j cça x¥òjš.
M) r_f jâ¡if¡fhd és«gu¢ bryÎ k‰W« éê¥òz®Î

V‰gL¤Jjš

M»at‰¿‰fhd bryéd¤Âš 20% khãy muR V‰W¡ bfhŸSjš k‰W« bkh¤j
bryédkhd %.61.20 y£r¤Âš 80% ika muR V‰W¡ bfhŸs cça gçªJiu
brŒjš.
-354. nkny g¤Â 3-š cŸs Mizahsç‹ fU¤JU ftdKl‹ gçÓè¡f¥g£l Ã‹
mjid V‰W¡ bfhŸsyh« vd muR KoÎ brŒJŸsJ. mj‹go Ñœ¡f©lthW
muR MizæL»wJ.
m) mid¤J »uhk gŠrha¤JfëY« ãahaéiy filfëš r_f jâ¡if
Â£l¤ij brašgL¤j x¥òjš më¡f¥gL»wJ,
M) r_f jâ¡if¡fhd és«gu¢ bryÎ k‰W« éê¥òz®Î V‰gL¤Jjš M»at
‰¿‰fhd bkh¤j bryéd« %.61.20 Ïy£r¤Âš khãy muÁ‹ 20 rjé»jkhd
%.12,24,000/-¡F (%ghŒ g‹åu©L Ïy£r¤J ÏUg¤J eh‹fhæu« k£L«) khãy

<!-- page 38 -->

muR V‰W¡ bfhŸs x¥gë¥ò brŒJ muR MizæL»wJ.
Ï) ÛjKŸs 80 rjÅjkhd % 48.96 Ïy£r¤Âid ika muÁläUªJ bgwÎ«
gçªJiu brŒa¥gL»wJ.
5.
Ï›thiz ãÂ¤Jiwæ‹ mYtš rh®g‰w F¿¥ò v© 76/DS/RR/2010 ehs
5.10.2010š bg‰w ÏirÎl‹ btëæl¥gL»wJ.
(MSeç‹ Miz¥go)
°tu‹Á§
muR Kj‹ik brayhs®
bgWe®
Mizahs®
czÎ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤Jiw,br‹id-5(Ï)
T£LwÎ¢ r§f§fë‹ gÂths®,br‹id -10(Ï)
nkyh©ik Ïa¡Fe® , jäœehL Ef®bghUŸ thâg¡ fHf«
br‹id -10(Ï)
mid¤J kht£l M£Á¤ jiyt®fŸ (Ï)
khãy fz¡fha® (V & Ï) br‹id – 18(bgaçš)(Ï)
khãy fz¡fha® (jâ¡if) br‹id – 18(Ï)
r«gs fz¡F mYty®(»H¡F/tl¡F/bj‰F)br‹id(Ï)
kht£l fUñy« /rh® fUñy«
m«g¤ö®, jh«gu« (Ï)
efš
tUthŒ¤Jiw,br‹id -9(Ï)
ãÂ (t,br,bgh1/11/T£LwÎ czÎ k‰W« Ef®nth®
ghJfh¥ò¤Jiw,br‹id -9(Ï)
kh©òäF mik¢r®(czÎ)mt®fë‹ Áw¥ò bray®,br‹id-9(Ï)
Kj‹ik¢ brayhs®, T£LwÎ czÎ k‰W« Ef®nth®
ghJfh¥ò¤Jiw mt®fë‹ jå¢ bray®,br‹id -9 (Ï)
ÏU¥ò nfh¥ò / cÂç
// Miz¥go mD¥g¥gL»wJ//
x«/ÃçÎ mYty®

-36Ïiz¥ò
ãahaéiy¡ filfëš r_f¤ jâ¡ifia eilKiw¥gL¤JtJ F¿¤j
têKiwfŸ
i)
ãahaéiy m§fhofë‹ gÂntLfŸ M©L¡F ÏUKiw mjhtJ Mf°£
15« njÂ k‰W« #dtç 26« njÂf.š r_f jâ¡if¡F c£gL¤j¥gL«. j‰nghJ
bghJ éãnahf Â£l brašgh£oš fhz¥gL« FiwghLfis fisa r_f
jâ¡if¡fhf têKiwfŸ ml§»a ifnaL czÎ¥ bghUŸ tH§fš Jiwahš
jåna btëæl¥gL«.

<!-- page 39 -->

ii)
r_f jâ¡if el¤j¥gLtJ F¿¤J cça és«gu« brŒa¥gL«.
rKjha¤Âš cŸs bghhJ k¡fS¡F r_f jâ¡ifæ‹ nghJ Kiwahf jâ¡if
nk‰bfhŸs cça gæ‰Á më¡f¥gL«, rKjha jâ¡ifahs® bfh©l FG
mik¡f¥g£L mªj FGé‰F cça gæ‰Á më¡f¥gL«. »uhk k¡fS¡F gæ‰Á
më¡f¥gL«.
iii)
jâ¡ifahs® FGéd® »uhk rigæš »uhk k¡fŸ k‰W« Cuh£Á k‹w
cW¥Ãd®fŸ K‹åiyæš gÂÎfis jâ¡if brŒJ mt®fsJ fU¤J¡fŸ /
Mnyhridfis bjçé¥gh®fŸ. r_f jâ¡ifæ‹ nghJ »uhk rig K‹ò
it¡f¥gl nt©oa bghJ éãnahf Â£l« bjhl®òila Mtz§fS¡fhd
g£oaš bfhL¡f¥gL«, Ïªj jâ¡ifæš f©LŸs étu§fŸ r_f jâ¡if
Mu«Ã¡F« nghJ »uhk k¡fS¡F f©o¥ghf go¤J fh©Ã¡f¥gl nt©L«.
iv)
r_f jâ¡ifahs®fŸ ãahaéiy m§fhofë‹ gÂÎfis , m§fhæš
m¤ÂahtÁa bghUŸfŸ m£iljhu®fS¡F tH§F« tifæš v¥nghJ« ÏU¥ò
ÏUªJŸsjh. ÏU¥ò ÏUªj m¤ÂahtÁa bghUŸfŸ mid¤J¥ gâ eh£fëY«
m£iljhu®fS¡F mt®fŸ FL«g m£il¡F jFÂahd msÎ tH§f¥g£LŸsjh,
ngh‹w étu§fis nf£l¿ªJ FL«g m£iljhu®fë‹ gÂÎfSl‹ jâifæ‹
nghJ x¥Ãl C¡Fé¡f nt©L«. Ï›thW x¥ÃL«nghJ f©LÃo¡f¥gL« nghè
gÂÎfŸ g‰¿a étu§fis jâ¡if elto¡iffëš F¿¥Ãl nt©L«.
v)
r_f jâ¡ifæ‹ nghJ r«gªj¥g£l mYty®fë‹ gâfŸ Ã‹tUkhW:ãahaéiy m§fhoæ‹ brašghL F¿¤J r_f jâifahs®fŸ k
‰W« bghJ k¡fŸ
nf£F« nfŸéfS¡F bjëthd k‰W«
KGikahd gÂš më¡f m§fho é‰gidahs® k‰W« Ïju m§fho
gâahs®fŸ r_f jâ¡ifæ‹ nghJ »uhk rigæš ÏU¡f
nt©L«. mid¤J gÂÎfS« ehsJ njÂ tiu KGik bg‰¿U¡f
nt©L«.
bghJ éãnahf Â£l¤Â‹ Ñœ muR më¡F« nritfŸ g‰¿a
étu§fis bghJ k¡fS¡F vL¤Jiu¡f muR rh®ghf, »uhk k¡fŸ
nf£F« nfŸéfS¡F »uhk rigæš gÂš më¡f »uhk ã®thf
mYty® ÏU¡f nt©L«.
r_f jâ¡if RKfkhf eilbgwÎ«. r_f jâ¡if¡F jiyik V
‰W xU§»iz¤J tê el¤j cŸq® Cuh£Á k‹w jiyt® Cuh£Á
k‹w cW¥Ãd®fSl‹ »uhk rigæš fyeJ bfh©L tê el¤j
nt©L«. ÏWÂahf r_f jâ¡if¡fhd T£l elto¡if F¿¥ò
gÂÎ brŒjš nt©L«.
r_f jâ¡if eilbgW« nghJ kht£l M£Á¤ jiyt® kht£l
tUthŒ mYty®, T£LwÎ Ïiz gÂths®, kht£l tH§fš k‰W«

-37Ef®nth® ghJfh¥ò mYty®, KJãiy k©ly nkyhs®, Jiz
gÂths®Ï gFÂ mYty®, t£l tH§fš mYty®Ï T£LwÎ rh®
gÂths® k‰W« tUthŒ MŒths®fŸ gšntW t£l§fëš
eilbgW« r_f jâ¡ifæid gh®itæl nt©L«.
Ï›thW mYty®fŸ r_f jâ¡ifæš fyeJ bfhŸtj‰fhd cça
elto¡iffis T£LwÎ Ïiz¥ gÂths® k‰W« KJãiy k©ly
nkyhsUl‹ fyªJ MnyhÁ¤J kht§ll tH§fš k‰W« Ef®nth®
ghJfh¥ò mYty® jahç¤J kht£l M£Á¤ jiytç‹ x¥òjY¡F

<!-- page 40 -->

it¡f nt©L«, Ïªj elto¡ifæš »uhk ã®thf mYty®fŸ, jå
tUthŒ MŒths®fŸ, tUt hŒ MŒths®fŸ, k©ly Jiz
t£lh£Áa®fŸ, t£lh£Áa®fŸ M»nahU¡fhd bghW¥òfisÍ«
F¿¥Ãl nt©L«.
mYty®fŸ nkny F¿¥Ã£lthW jahç¡f¥g£l elto¡iffë‹go
xJ¡f¥g£l é»j¤Âš r_f jâ¡ifia f©fhâ¡f nt©L«,
ÏJ mYty®fisÍ«
»uhk rig cW¥Ãd®fisÍ« r_f
jâ¡ifæš nkY« M®t¤Jl‹ <Lgl tê tF¡F«.
r_f jâ¡ifæ‹ x›bthU f£l¤ÂY« (Mf°£ 15 k‰W« #dtç
26) bgw¥gL« T£l elto¡if F¿¥òfis m§fho thçahf mL¡»
xU ò¤jfkhf ij¤J mj‹ efš x‹¿id kht£l tH§fš
mYtyU¡F tH§f nt©L«.
r_f jâif T£l elto¡if F¿¥òfë‹ xU efiy
Ïz¥gÂths® / Jiz gÂths® , T£LwÎ rh® gÂths®, KJãiy
«©ly nkyhs® / gFÂ mYty® M»nahU¡F tH§» mÂš
R£o¡fh£l¥g£LŸs FiwghLfis rçbrŒJ Fiw ãt®¤Â
m¿¡ifia VG eh£fS¡FŸ
r«gªj¥g£l Cuh£Á k‹w
jiytU¡F mD¥g nt©oaJ t£l tH§fš mYtyç‹ jå¥g£l
bghW¥ghF«.
Ï›thW T£LwÎ r§f§fë‹ Ïiz¥ gÂt hs® / KJãiy k©ly
nkyhsçläUªJ bgw¥gL« Fiw ãt®¤Â m¿¡iffis bjhF¤J
mjid kht£l M£Á¤ jiytç‹ x¥òjY¡F br¥l«g® k‰W«
Ã¥utç khj¤Âš eilbgW« Ïu©lhtJ bghJ éãnahf Â£l
MŒÎ¡T£l¤Âš kht£l tH§fš k‰W« Ef®nth® ghJfh¥ò mYty®
it¡f nt©L«.
r_f jâ¡ifæ‹ nghJ bjçjé¡f¥gL« MnyhridfisÍ«
mYty®fŸ MŒÎ brŒa nt©L«, MnnhridfŸ éÂKiwfS¡F
c£g£oU¥Ã‹ kht£l M£Á¤jiyt® , kht£l tH§fš mYty® ,
t£l tH§fš mYty® mšyJ r«gªj¥g£l mYty® mjid
brašgL¤Â FiwÔ®
m¿¡ifæš mjid nr®¡f nt©L«.
nfhç¡iffnsh Fiwfnsh éÂKiwfS¡F
c£gléšiy
v‹whnyh Ïjid ãt®¤Â brŒa muR MizfŸ njit¥g£lhnyh
mt‰iw kht£l tH§fš k‰W« Ef®nth® ghJfh¥ò mYty®

-38bjhF¤J kht£l M£Á¤ jiyt® k‰W« Miza® czÎ bghUŸ
tH§fš k‰W« Ef®nth® ghJfh¥ò Jiw _ykhf muR¡F mD¥g
nt©L«.
r_f jâ¡if eilbg‰w Ïu©L eh£fS¡FŸ r_f jâ¡if
eilbg‰wJ F¿¤j m¿¡iffis bjhF¤J t£l tH§fš mYty®,
kht£l tH§fš k‰W« Ef®nth® ghJfh¥ò mYtyU¡F m¿¡if
mD¥g nt©L«. Ï›thW bgw¥gL« m¿¡iffis bjhF¤J kht£l
tH§fš k‰W« Ef®nth® ghJfh¥ò mYty®, kht£l M£Á¤

<!-- page 41 -->

jiytU¡F bjhF¥ò m¿¡ifia mD¥g nt©L«.
kht£l tH§fš k‰W« Ef®nth® ghJfh¥ò mYty® r_f jâ¡if
eilbg‰w _‹Weh£fS¡FŸ r_f jâ¡if el¤j¥g£lJ F¿¤j
m¿¡ifæid Kj‹ik bray®, T£LwÎ czÎ k‰W« Ef®nth®
ghJfh¥ò¤Jiw
k‰W«
czÎ
bghUŸ
tH§fš
Jiw
MizahsU¡F« mD¥g nt©L«.
xU Cuh£Áæš cŸs mid¤J ãahaéiy m§fhofS¡F« xnu
Ïl¤Âš tçirahf r_f jâ¡if x‹w‹Ã‹ x‹whf el¤j¥gl
nt©L«. xU m§fho¡F 30 ãäl§fS¡F Fiwahkš jâ¡if
el¤j¥gl nt©L«.
°tu©Á§
muR Kj‹ik brayhs®
//c©ik efš//
ÃçÎ mYty®

-39RU¡f«
bghJ éãnahf¤Â£l« - ãahéiy¡ filfŸ _y« FL«g m£iljhu®fS¡F
Ïytr mçÁ tH§Fjš – MizfŸ – btëæl¥gL»‹w‹.
T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò (Ã1) Jiw
muR Miz (ãiy) v© 45

ehŸ-17.05.2011

<!-- page 42 -->

Miz
bghJ éãnahf¤ Â£l¤Â‹ Ñœ j‰nghJ xU »nyh mçÁ xU %ghŒ v‹w
éiyæš FL«g cW¥Ãd®fë‹ v©â¡ifæ‹ mo¥gilæš khj« x‹W¡F
x›bthU FL«g¤Â‰F« 12 »nyh Kjš 20 »nyh tiuæš mçÁ tH§f¥g£L
tU»wJ. mªÂnahjah m‹dnah#dh Â£l¤Â‹ Ñœ (Antyodaya Anna Yojana)
FL«g m£il x‹W¡F 35 »nyh Åj« mçÁ tH§f¥g£L tU»wJ.

2.ViH vëa eL¤ju FL«g§fŸ gadilÍ« tifæš bghJ éãnahf¤
Â£l¤Â‹ Ñœ ãahaéiy¡ filfëš é‰gid brŒa¥gL« mçÁia Ïytrkhf
tH§FtJ

g‰¿

murhš

ftdKl‹

gçÓè¡f¥g£L

muR

Ã‹tUkhW

MizæL»wJ.
1. bghJ éãnahf¤ Â£l¤Âš mçÁ bgw jFÂÍŸs FL«g m£iljhu®fS¡F
mçÁ Ïytrkhf tH§f¥gL«.
2. bghJ

éãnahf¤

Â£l¤Âš

FL«g

cW¥Ãd®fë‹

v©â¡ifæ‹

mo¥gilæš khj« x‹W¡F j‰nghJ tH§f¥g£L tU« msÎfëš mçÁ
tH§f¥gL«
3. mªÂnahjah m‹dnah#dh FL«g m£iljhu®fS¡F tH§f¥g£L tU«
35 »nyh mçÁ Ïytrkhf tH§f¥gL«.
4. Ï›thizfŸ 01.06.2011 Kjš mKšgL¤j¥gL«.
3.

Ïªj Mizia všyh ãaha éiy¡filfëY« cŸs m¿é¥ò¥

gyiffëš bjëthf bghJk¡fë‹ gh®it¡F bjçÍ«go vGÂit¡f j¡f
m¿ÎiufŸ tH§FkhW Mizahs®. czÎ¥ bghUŸ tH§fš k‰W« Ef®nth®
-40ghJfh¥ò¤ Jiw, nkyh©ik Ïa¡Fe®, jäœehL Ef®bghUŸ thâg fHf« k‰W«
T£LwÎ¢ r§f§fë‹ gÂths® M»nah® nf£L¡ bfhŸs¥gL»wh®fŸ.

4. Ï›thizæ‹ fhuzkhf jäœehL Ef®bghUŸ thâg fHf¤Â‰F njit¥gL«
TLjš

czÎ

khåa¤Â‰fhd

fU¤JUéid

muR¡F

mD¥g

jäœehL

<!-- page 43 -->

Ef®bghUŸ thâg fHf¤Â‹ nkyh©ik Ïa¡Fe® nf£L¡ bfhŸs¥gL»wh®.

5.Ïªj murhiz ãÂ¤Jiwæ‹ mrh v© 1126/FS/P/2011 ehŸ 17.05.2011-š
bgw¥g£l x¤ÂirÎl‹ btëæl¥gL»wJ.

(MSeç‹ Miz¥go)

°tu‹Á§
Kj‹ik¢ brayhs®
bgWe®
Mizahs®, czÎ¥ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤ Jiw, br‹id-5
nkyh©ik Ïa¡Fe®,
jäœehL Ef®bghUŸ thâg¡ fHf«, br‹id-10
T£LwÎ¢ r§f§fë‹ gÂths®, br‹id-10
mid¤J kht£l M£Á¤jiyt®fŸ
Jiz Mizahs®fŸ, br‹id (tl¡F) (bj‰F)
czÎ¥ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤ Jiw mYtyf«
khãy fz¡fha®, br‹id-6/18/35
ãÂ¤Jiw, br‹id-9
efš
Kjyik¢r® mYtyf«, br‹id-9
ãÂaik¢r® mYtyf«, br‹id-9
czÎ¤ Jiw mik¢rç‹ KJãiy ne®Kf cjéahs®, br‹id-9
ãÂ¤ (T£LwÎ k‰W« Ef®nth® ghJfh¥ò/t.br.bgh.1) Jiw, br‹id-9
ÏU¥ò¡ nfh¥ò / cÂç¥gofŸ
/c¤juÎ¥go mD¥g¥gL»wJ/
ÃçÎ mYty®

-41-

RU¡f«
Áw¥ò bghJ éãnahf¤Â£l« - Jtu« gU¥ò, cS¤j« gU¥ò, br¿ñ£l¥g£l

<!-- page 44 -->

nfhJik khÎ k‰W« br¿ñ£l¥g£l ghkhæš M»a m¤ÂahtÁa¥ bghU£fŸ
ãahaéiy¡ filfŸ _y« éãnah»¡f¥gLtij bjhl®ªJ brašgL¤Jjš –
MizfŸ btëæl¥gL»‹wd.
T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò (o1) Jiw
muR Miz (ãiy) v© 51

ehŸ-14.06.2011
go¡f

murhiz (ãiy) v© 37, T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò¤
Jiw, ehŸ 29.03.2010.
-------Miz
btë¢rªijæš bghJ k¡fŸ m‹whl¥ ga‹gL¤J« m¤ÂahtÁa¥
bghU£fshd Jtu« gU¥ò, cS¤j« gU¥ò, ghkhæš ngh‹wt‰¿‹ éiy ca®ªJ
tUtij¡ f£L¥gL¤J« neh¡Fl‹ Ï¥bghU£fis munr jäœehL Ef®bghUŸ
thâg¡ fHf« _y« bfhŸKjš brŒJ bghJ éãnahf¤ Â£l¤Â‹ Ñœ FL«g
m£iljhu®fS¡F éãnahf« brŒa KoÎ brŒjJ. Ï¤Â£l« br‹id khefçš
14.04.2007

Kjš

brašgL¤j¥g£lJ.

kht£l§fS¡F éçÎgL¤j¥g£lJ.

Ã‹d®

01.05.2007

Kjš

Vida

btë¢rªij éiyia¡ f£L¥gL¤J«

neh¡Fl‹ Mu«Ã¡f¥g£l Ï¤Â£l« 30.08.2011 tiu Ú£o¡f¥g£lJ.
2.

jäœeh£oš bghJ éãnahf¤ Â£l¤Â‹ brašghL F¿¤J muR MŒÎ brŒJ,

Áw¥ò bghJ éãnahf¤ Â£l¤Â‹ Ñœ gU¥ò tiffŸ, rikaš v©bzŒ,
br¿ñ£l¥g£l nfhJik khÎ k‰W« krhyh bgh£ly§fŸ M»at‰iw kh‹a
éiyæš tH§F« Â£l¤ij 01.07.2011 Kjš 31.12.2011 tiu MW khj§fS¡F
Ú£o¡fyh« vd KoÎ brŒJ m›thnw MizæL»wJ.

3.

Ï›thiz ãÂ¤Jiwæ‹ m.rh.F.v© 1143/FS/P2011 ehŸ 09.06.2011/š bg‰w

x¤ÂirÎl‹ btëæl¥gL»wJ.
(MSeç‹ Miz¥go)
a¤ÔªÂueh¤ °nt‹,
muR brayhs®.
-42bgWe®
Mizahs®, czÎ¥ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤ Jiw, br‹id-5
ã®thf Ïa¡Fe®,

<!-- page 45 -->

jäœehL Ef®bghUŸ thâg¡ fHf«, br‹id-10
T£LwÎ r§f§fë‹ gÂths®, br‹id-10
Kj‹ik khãy fz¡fha®, br‹id-18
khãy fz¡fha® (jâ¡if), br‹id-18
r«gs« k‰W« fz¡F mYty®, br‹id-9
Kjyik¢rç‹ mYtyf«, br‹id-9
kh©òäF ãÂaik¢rç‹ KJãiy cjéahs®, br‹id-9
kh©òäF czÎ mik¢rç‹ KJãiy cjéahs®,
br‹id-9
efš
ãÂ¤ Jiw, br‹id-9
T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò¤ Jiw
brayhsç‹ jå¢ brayhs®, br‹id-9
ÏU¥ò¡ nfh¥ò/cÂç.
/Miz¥go mD¥g¥gL»wJ/
ÃçÎ mYty®

-43ENFORCEMENT
RU¡f«
r‹khd« - bghJ éãnahf¤Â£l« mçÁ k‰W« czÎ¥ bghU£fis
fl¤Jgt®fŸ g‰¿ jftš më¥gt®fS¡F
r‹khd« tH§Fjš – Miz

<!-- page 46 -->

btëæl¥gL»wJ.
T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò (Ï1) Jiw
muR Miz (o) v© 351

ehŸ-22.09.2006
go¡f-

Miz
jäœeh£oš ViH vëa k¡fS¡F cjÎ« tifæš bghJ éãnahf Â£l¤š
tH§f¥gL« mçÁæ‹ éiy »nyh x‹W¡F %.2/- vd ã®zæ¤J ãaha éiy¡
filfëš mçÁ éãnahf« brŒa¥gL»wJ.

Ïªj bghJ éãnahf¤ Â£l mçÁ

Ï«khãy¤ÂèUªJ m©il khãy§fS¡F fl¤j¥gLtj‹ _y« muR¡F ÏH¥ò
V‰gLtJl‹ Ï¢Óça Â£l« F¿¤j ga‹gh£oidÍ« Ó®Fiy¡f it¡»wJ.
vdnt, bghJ éãnahf¤ Â£l mçÁ k‰W« czÎ¥ bghU£fis fl¤Jgt®fŸ
F¿¤j Jšèakhf jftš bjçé¥gt®fS¡F j¡f r‹khd« më¡f më¡f muR
KoÎ brŒJŸsJ. Ïj‹ go jftè‹ mo¥gilæš ÃogL« yhç x‹W¡F jftš
bfhL¥gtU¡F %.100/- r‹khd« më¡f muR MizæL»wJ. jftš më¥gt®
bga® k‰W« Kftç ÏufÁakhf it¡f¥gL«, jftš më¥gt®fë‹ étu§fŸ
czÎ mik¢r® mYtyf«, czÎ¤ Jiw brayhs®, Kj‹ik Miza®, czÎ¥
bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw, jäœehL Ef®bghUŸ thâg¡
fHf¤ jiyt® k‰W« ã®thf Ïa¡Fe®, T£LwÎ r§f§fë‹ gÂths®, kht£l
M£Á¤ jiyt®fŸ k‰W« kht£l fhtš Jiw f©fhâ¥ghs®fŸ M»nahU¡F
bghJ éãnahf Â£l mçÁ k‰W« k©bz©bzia fl¤Jgt®fis Ão¡F«
czÎ¥ bghUŸ tH§fš mYty®fŸ bjçé¡f nt©L«.
2

.br‹id khefçš Kj‹ik Miza® k‰W« Miza® czÎ¥ bghUŸ

tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw mt®fS¡F ÏufÁa ãÂahf %.1
Ïy£rK«, všiynahu kht£l§fshd f‹åahFkç, jUbešntè, nfha«ò¤Jh®,
»UZz»ç, ntYh® M»a IªJ kht£l M£Á¤ jiyt®fS¡F jyh 1 Ïy£r«
Åj« %.5 y£rK« Ïju 24 kht£l M£Á¤ jiyt®fS¡F jyh %,50,000/- Åj«
%.12 Ïy£rK« Mf bkh¤j« %.18 Ïy£r« (%ghŒ gÂbd£L Ïy£r« k£L«) ãÂ
xJ¡ÑL brŒJ muR MizæL»wJ.
-443. nkny g¤Âš 2-š xJ¡ÑL brŒa¥g£l ÏufÁa ãÂia br‹id khefiu
bghW¤jtiu, Kj‹ik Miza® k‰W« Miza®, czÎ¥ bghUŸ tH§fš k‰W«
Ef®nth®

ghJfh¥ò¤

Jiw

ã®t»¡fyh«

vdÎ«,

Ïju

kht£l§fis¥

<!-- page 47 -->

bghW¤jtiu

mªjªj

kht£l

M£Á¤

jiyt®fŸ

ã®t»¡fyh«

vdÎ«

Mizæl¥gL»wJ.

4. nkny g¤Â -2š xJ¡L brŒa¥g£l bjhifia bg‰W mid¤J kht£l
M£Á¤ jiyt®fS¡F« j¡f m¿ÎiufSl‹ tH§f czÎ¥bghUŸ tH§fš k
‰W« Ef®nth® ghJfh¥ò¤ Jiw Kj‹ik Miza® k‰W« MizaU¡F mÂfhu«
më¡f¥gL»wJ.

5.

nkny g¤Â 2-š x¥gë¡f¥g£l bjhif nfhç¡if v© 13-š Ñœ¡f©l g¤Â

fz¡F¤ jiy¥Ã‹ Ñœ bryÎ brŒa¥gl nt©L«.
3456 – 00 Civil Supplies – 800 – Other expenditure I – Non Plan –
AG Payment of reward to the informers about the smuggling of
Public Distribution Rice and other Food Commodities -39Rewards
(DPC 3456 00 800 AG 3905)”
6.

Kj‹ik Mizahs® k‰W« Mizahs®, czÎ¥ bghUŸ tH§fš k‰W«

Ef®nth®

ghJfh¥ò¤ Jiw mt®fŸ nkny Mu«Ã¡f¥g£l òJ¡ fz¡F¤

jiy¥Ã‹ kÂ¥ÕL xU§»iz¥ò k‰W« f£L¥ghL mÂfhçahth®.

r«gªj¥g£l

r«gs¡ fz¡F mYty® / fUñy mÂfhç nkny Mu«Ã¡f¥g£l òJ¡ fz¡F¤
jiy¥Ã‰fhd gÂntLfis guhkç¡FkhW nf£L¡ bfhŸs¥gL»wh®fŸ.
7.

ÏJ òJ¥ gâ F¿¤j bryédkhF«.

nguitæš x¥òjš bgw¥gL«.

fhy¥ngh¡»š Ïj‰F r£lk‹w

x¥òjš »il¡F« tifæš Ïj‰fhd vÂ®ghuh

bryÎ ãÂæèUªJ K‹gz¤ij mDkÂ¤J MizfŸ ãÂ (t.br-1) Jiw jåahf
Ãw¥Ã¡F«.

vÂghuhj bryÎ ãÂæèUªJ K‹gz« th§Ftj‰F njitahd

é©z¥g¤ij cça got¤Âš ÏU got§fëš mD¥Ã it¡FkhW Kj‹ik
Miza® k‰W« Miza®, czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤
Jiw mt®fŸ nf£L¡ bfhŸs¥gL»wh®. nkny g¤Â 2-š x¥gë¡f¥g£l
-45bryéd¤ij ÂU¤Âa kÂ¥ÕL / Jiz kÂ¥ÕL (/RE./Supplementary Estimate)
2006-2007 š nr®¥gj‰Fça fU¤JUit j¡f jUz¤Âš muR¡F mD¥Ã
it¡FkhW Kj‹ik Miza® k‰W« Miza®, czÎ¥ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤ Jiw nf£L¡ bfhŸs¥gL»wh®.

<!-- page 48 -->

8.Ï›thiz ãÂ¤ Jiwæ‹ m.rh.v©57598/CF &CP/2006 ehŸ 20.09.2006 k‰W«
TLjš ãÂ xJ¡f¥ ngnuL v© 578 x¤ÂirÎl‹ btëæl¥gL»wJ.
(MSeç‹ Miz¥go)
v°.k¢nrªÂuehj‹,
muR¢ brayhs®
bgWe®
Kj‹ik Miza® k‰W« Miza®,
czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw,
nr¥gh¡f«, br‹id-5
T£LwÎ¢ r§f§fë‹ gÂths®, br‹id-10
ã®thf Ïa¡Fe®, jäœehL Ef®bghUŸ thâg fHf«, br‹id-10
mid¤J kht£l M£Á¤ jiyt®fŸ
mid¤J kht£l fhtš Jiw f©fhâ¥ghs®fŸ / mid¤J khefu fhtš
Miza®fŸ
khãy fz¡fha®, br‹id-18/35
khãy fz¡fha® (jâ¡if) br‹id-6
r«gs¡ fz¡F mYty® (»H¡F), br‹id -5 /r«gs¡ fz¡F mYt®, kJiu
c£gl
mid¤J kht£l fUñy mYty®fŸ
efš
Kjyik¢r® mYtyf«, br‹id-9
KJãiy ne®Kf cjéahs® kh©òäF mik¢r® (czÎ), br‹id-9
fhtš Jiw jiyy®, br‹id-4
fhtš Jiw TLjš Ïa¡Fe®, Foik¥ bghUŸ tH§fš – F‰w¥ òydhŒÎ¤ Jiw,
br‹id-35
ãÂ (T, c(k)cg)/(t.br.bgh.II) (t.br.X) Jiw, br‹id-9
T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò¤ (o) Jiw, br‹id-9
brŒÂ k‰W« R‰Wyh (brŒÂ) Jiw, br‹id-9
njÁa jftš ika«, br‹id-9 (nk‰go murhizia jäHf muR tiy¤js«
http://www.tn.gov.in –š btëæl nf£L¡bfhŸs¥gL»wJ
Ïnfh/cÂç/nfh¥Ã‰F R¤j efš
/Miz¥go mD¥g¥gL»wJ/

-46-

RU¡f«
btFkÂ

- bghJ éãnahf¤Â£l« - nghè FL«g m£ilfŸ F¿¤J jftš

<!-- page 49 -->

më¥gt®fS¡F btFkÂ tH§Fjš k‰W« mçÁ k‰W« czÎ¥ bghU£fis
fl¤Jgt®fis¥ g‰¿ jftš më¥gt®fS¡F tH§f¥gL« btFkÂia ca®¤Â
tH§Fjš – Miz btëæl¥gL»wJ.
T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò (v¥2) Jiw
muR Miz (ãiy) v© 78

ehŸ-14.03.2007
go¡fmuR Miz (o) v© 351 T£LwÎ, czÎ k‰W« Ef®nth®
ghJfh¥ò (Ï1) Jiw ehŸ-22.09.2006.

Miz
jäœeh£oš j‰nghJ Rkh® 40 y£r« nghè FL«g m£ilfŸ òH¡f¤Âš cŸsd
v‹gJ bjça tªJŸsJ.

x›bthU FL«g m£il¡F« czÎ¥ bghU£fŸ

tH§FtJ _ykhf khåakhf muR¡F tUl¤Â‰F %.1200/- bryth»wJ. nkY«
FL«g m£ilfis mo¥gilahf¡ bfh©L gšntW ey¤Â£l§fis tH§»
tUtjhY« òaš, btŸs« ngh‹w ngçl® ãfœÎfëš bghJk¡fS¡F FL«g
m£ilfë‹ mo¥gilæš cjéfŸ tH§f¥g£L tUtjhY« nghè FL«g
m£ilfëdhš muR ãÂ fârkhd msÎ éuakh»wJ.
2. ÏJ F¿¤J muR ftdkhf gçÓè¤jJ.

nghè FL«g m£ilfis

òH¡f¤ÂèUªJ Ú¡f gy elto¡iffŸ nk‰bfh©L«, mitfis K‰¿Ykhf
xê¡f Ïayéšiy. Ïªãiyæš, nghè FL«g m£ilfŸ it¤ÂU¥ngh® F¿¤J
jftš

bjçé¥gt®fS¡F

btFkÂ

më¤jhš,

nghè

FL«g

m£ilfis

btë¡bfhzuyh« v‹w fU¤J bjçé¡f¥g£lJ. Ïnj nghš czÎ¥ bghU£fŸ
fl¤Jgt®fŸ g‰¿ jftš bfhL¥gth¡S¡F j‰rka« tH§f¥gL« %.100/btFkÂia ca®¤Â %.500/- tH§fyh« v‹w fU¤J« bjçé¡f¥g£lJ.

3. Ï¡fU¤J¡fis e‹F gçÓè¤J mt‰iw V‰fyh« v‹W muR KoÎ
brŒJŸsJ. vdnt nghè FL«g m£ilfŸ F¿¤j jftè‹ngçš, m›thwhd
nghè FL«g m£ilfis g¿Kjš brŒJ u¤J brŒjÃ‹ jftš më¤jt®fS¡F,
u¤J brŒa¥g£l m£il x‹W¡F %.200/- (%ghŒ ÏUEhW k£L«) tH§fyh« v‹W
muR MizæL»wJ. mnj nghš czÎ¥ bghU£fŸ fl¤Jgt®fŸ g‰¿ jftš
bfhL¥gt®fS¡F j‰rka« tH§f¥gL« %.100/- btFkÂia ca®¤Â %.500/-47tH§fÎ« muR MizæL»wJ. jftš më¥gt® bga® k‰W« Kftç ÏufÁakhf
it¡f¥gl nt©L«.

jftš më¥gt® t£l tH§fš mYty® mšyJ kht£l

<!-- page 50 -->

tH§fš mYtyU¡F¤ jftš bjçé¡fnt©L«.
4.

muR Miz (o) v© 351 T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò (Ï1)

Jiw ehŸ 22.09.2006-š bghJ éãnahf¤Â£l mçÁ k‰W« czÎ bghU£fis
fl¤Jgt®fŸ g‰¿ jftš bfhL¥gt®fS¡F btFkÂ tH§f br‹id khefçš
Kj‹ik Miza®, czÎ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw k
‰W« mid¤J kht£l M£Á¤ jiyt®fS¡F« xJ¡ÑL brŒj ãÂiana nghè
FL«g m£il F¿¤J jftš jUgt®fS¡F btFkÂ bfhL¡f ga‹gL¤jyh«
vdÎ« muR MizæL»wJ.
5.

nkny g¤Â 4š Mizæ£lgo xJ¡ÑL brŒa¥g£l bjhifia¥ bg‰W

mid¤J kht£l M£Á¤ jiyt®fS¡F« j¡f m¿ÎiufSl‹ tH§f czÎ¥
bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw Kj‹ik Miza® k‰W«
MizaU¡F mÂfhu« më¡f¥gL»wJ.

6.

nkny g¤Â 4š x¥gë¡f¥g£l bjhif nfhç¡if v© 13š Ñœ¡f©l

fz¡F¤ jiy¥Ãš Ñœ bryÎ brŒa¥gl nt©L«.
“ 3456 – Civil Supplies – 800 – Other expenditure I –Non Plan –AG
Payment of reward to the informers about the smuggling of Public
Distribution Rice and other Food Commodities – 39- Rewards
(DPC3456 00 800 AG 3905”
7.

Ï›thiz ãÂ¤Jiwæ‹ m.rh.F.v© 14738/CP/2007 ehŸ 13.03.2007

x¤ÂirÎl‹ btëæl¥gL»wJ.
(MSeç‹ Miz¥go)
v°.k¢nrªÂuehj‹,
muR¢ brayhs®
bgWe®
Kj‹ik Miza® k‰W« Miza®,
czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw,
nr¥gh¡f«, br‹id-5
T£LwÎ¢ r§f§fë‹ gÂths®, br‹id-10
jiyt® k‰W« ã®thf Ïa¡Fe®, jäœehL Ef®bghUŸ thâg¡ fHf«,
br‹id-10
-48CONSUMER PROTECTION

RU¡f«

<!-- page 51 -->

Ef®nth® ghJfh¥ò – jäœehL Ef®nth® ghJfh¥ò k‰W« mÂfhu¢ r§f« (Tamil
Nadu State Society for Consumer Protection and Empowerment (TANSSCOPE))
mik¤J khãy Ef®nth® nrit ika« vD« òÂa Â£l« brašgL¤Jjš k‰W«
2008-2009-« M©o‰F ika muR tH§»ÍŸs ãÂ %. 27,60,000/- x¥gë¥ò brŒJ
MizfŸ btëæl¥gL»‹wd.
T£LwÎ, czÎ k‰W« Ef®nth® ghJfh¥ò (v¢2) Jiw
muR Miz (ãiy) v© 210

ehŸ-12.12.2008
r®tí¤jh fh®¤Âif-27
ÂUtŸSt®
M©L, 2039
go¡f.
1. Ïa¡Fe®, ika muR Ef®nth® étfhu«, czÎ k‰W« bghJ éãnahf
mik¢rf ne®Kf foj« vz G 120116/2007, CWF, ehŸ 03.10.2007 k‰W«
28.12.2007
2. czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiw TLjš
Mizaç‹ ne®Kf foj« vz RC v© CP3/3887/2007, ehŸ 31.10.2007
3. muR foj« v© 29593/v¢2/2007-4, ehŸ 01.02.2008
4. czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiw Mizaç‹

ne®Kf¡ foj« v© CP1/22387/2008, ehŸ 26.06.2008 k‰W« 23.09.2008
-------Miz
ika muÁ‹ Ef®nth® étfhu¤Jiw, »uhk¥òw k‰W« Ã‹j§»a gFÂfëš
cŸs Ef®nth® Fiwfis éiuªJ ãt®¤Â brŒa kh‰W V‰ghlhf ika muR
mik¤JŸs “njÁa Ef®nth® nrit ika«” ngh‹W khãy¤Âš khãy Ef®nth®
nrit ika« v‹D« òÂa ika¤ij V‰gL¤. mj‹ _y« mªjªj t£lhu
bkhêæY« M§»y¤ÂY« Ef®nthU¡F nrit brŒa Ïªj òÂa Â£l¤ij
Ñœ¡fhQ« ãgªjidfis V‰W, jäœeh£oš eilKiw¥gL¤jyh« vd ika
muR¡F gh®it 3-š go¡f¥g£l foj¤Âš bjçé¡f¥g£LŸsJ.

1. Kjš IªJ M©LfŸ nrit ika¤ij ika muR V‰W brašgL¤J«

2. nrit ika« Mu«Ã¤J 6tJ M©oèUªJ mj‹ bryÎfis khãy munr
V‰W¡ bfhŸS«.
-49-

<!-- page 52 -->

3. nrit ika¤Â‰F¤ njitahd j©Ù® k‰W« ä‹rhu trÂ ngh‹wt‰¿
‰fhd Ïju bryÎfisÍ« khãy munr V‰W¡bfhŸS«.
4. nrit ika¤ij F¿¤j éê¥òz®it V‰gL¤J« jFªj és«gu« khãy
murhš brŒa¥gL«.

5. IªJ M©LfS¡F¥ ÃwF khãy munr nrit ika¤ij V‰W bjhl®ªJ
el¤J«

Ï¤Â£l¤Â‰F njitahd ãÂæid 11tJ Iªjh©L¤ Â£l¤Â‹

Ñœ xJ¡f¥g£LŸs ãÂbahJ¡f¤ÂèUªJ vL¤J ga‹gL¤jyh«

v‹W

ika muR bjçé¤JŸsJ.
2. gh®it 2 k‰W« 4-š go¡f¥g£l foj¤Âš, czÎ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤ Jiw Mizahsh nk‰fz£ Â£l¤ij jäHf muR¡F
bryéd« VJ« V‰glhj tifæš jäœehL Ef®nth® ghJfh¥ò k‰W« mÂfhuf
r§f« (Tamil Nadu State Society for Consumer Protection and Empowerment
(TANSSCOPE)) v‹w X® mik¥ò r§ffŸ gÂÎ r£l¤Â‹ Ñœ gÂÎ brŒa¥g£L,
czÎ¥ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò Mizahs® jiyikæš xU
FG mik¤J

brašgL¤jyh« v‹W«, Ï¢nrit ika¤Âid ã®khå¥gj‰fhf

MF« bryéd¤Â‰fhf ika muR %.27,60,000/- I (%ghŒ ÏUg¤njG Ïy£r¤J
mWgjhæu« k£L«) mDkÂ¤JŸsJ v‹W«, Ï¤bjhif 16.7.2008-š khãy muR
fz¡»š tuÎ it¡f¥g£LŸsJ v‹W« bjçé¤J nk‰F¿¥Ã£LŸs jäœehL
Ef®nth® ghJfh¥ò k‰W« mÂfhu« r§f« mik¤J khãy Ef®nth® nrit ika«
brašgL¤jÎ«,

Ï¢nrit

ika¤Âid

ã®khâ¥gj‰fhf

ika

muR

mDkÂ¤JŸs %.27,60,000/-I(%ghŒ ÏUg¤njG Ïy£r¤J mWgjhæu« k£L«)
éLé¡fÎ«, Miz Ãw¥Ã¡F«goÍ« czÎ bghUŸ tH§fš k‰W« Ef®nth®
ghJfh¥ò¤Jiw . Mizahs® muR¡F fU¤JU mD¥ÃÍŸsh®.

3. czÎ bghUŸ

tH§fš

k‰Wk Ef®nth® ghJfh¥ò¤Jiw

Mizaç‹

fU¤JUit muR e‹F MuhŒªJ khãy Ef®nth® nrit ika« “ v‹D« òÂa
Â£l¤ij brašgL¤j Ñœ¡f©lthW MizæL»wJ.
1. jäœehL Ef®nth® ghJfh¥ò k‰W«

mÂfhu r§f« (TANSSCOPE) v‹w X®

mik¥Ãid Ñœ¡fhQ« bra‰FG cW¥Ãd®fis¡ bfh©L mik¡fyh«.

<!-- page 53 -->

-501

2

3

4

5

6

7

2.

Mizahs®
czÎ
bghUŸ
tH§fš
k‰W«
Ef®nth® ghJfh¥ò¤Jiw
TLjš Ïiz Miza®
czÎ
bghUŸ
tH§fš
k‰W«
Ef®nth® ghJfh¥ò¤Jiw
Jiz Miza® - 1
czÎ
bghUŸ
tH§fš
k‰W«
Ef®nth® ghJfh¥ò¤Jiw
Jiz Mizahs® -2
czÎ
bghUŸ
tH§fš
k‰W«
Ef®nth® ghJfh¥ò¤Jiw
cjé Miza®
czÎ
bghUŸ
tH§fš
k‰W«
Ef®nth® ghJfh¥ò¤Jiw
Áw¥ò TLjš Ïiz brayhs®
T£LwÎ, czÎ k‰W« Ef®nth®
ghJfh¥ò¤Jiw
Ïiz/Jiz brayhs®
ãÂ¤Jiw

jiyt®

brayhs®

Ïiz brayhs®

cW¥Ãd®

cW¥Ãd®

cW¥Ãd®

cW¥Ãd®

czÎ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤ Jiw Mizauhš

Ô®khå¡f¥g£L czÎ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiwia
rh®ªj TLjš/Ïiz/cjé Miza® mšyJ rk mÂfhu« bg‰w mYty® braš
tê mYty® gjéæš r§f¤Â‹

cW¥Ãd® brayhsuhf ÏU¡f nt©L«.

Ï

¢r§f¤Â‰F czÎ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤ JiwæèUªJ nt
‰W¥gâ

Kiwæš

xU

cjéahs®,

xU

fz¡f®

k‰W«

xU

mYtyf

cjéahs®fis ãaä¡fyh«. Ïj‰nf‰g czÎ bghUŸ tH§fš k‰W« Ef®nth®
ghJfh¥ò¤Jiwæš Ïªj 3 gâæl§fŸ Ú¡f¥gl nt©L«.
3.

khãy Ef®nth® nrit ikakhdJ eh‹F bjhiyngÁ Ïiz¥òfnshL

thu¤Â‰F IªJ eh£fŸ gfèš k£L« ntiy eh£fshf bfh©L

brašgl

nt©L«. njitahd bk‹bghUŸ k‰W« t‹bghUŸ ãgªjidfis bjëthf¡
F¿¥Ãl¥g£l x¥gªj òŸë thæyhf th§f¥gl nt©L«.
4.

Ef®nth® FiwfŸ F¿¤J Mnyhrid tH§Fgt®fŸ V‰fdnt Ef®nth®

étfhu§fëš

bjhl®òila j‹dh®t Ef®nth®

‰Wgt®fshf ÏU¡f nt©L«.

mik¥òfëš

gâah

Ïªj¥ gâ¡fhf bjhiyngÁ Ïiz¥òfisÍ«

ifahs mDgtKŸs xU Â£l nkyhsiuÍ« eh‹F

<!-- page 54 -->

-51Mnyhrf®fisÍ« j‹dh®t mik¥òfŸ më¡f nt©L«.
5.

khãy Ef®nth® nrit ika¤ij f©fhâ¤J brašgL¤J« jäœehL

Ef®nth® ghJfh¥ò k‰W« mÂfhu¢ r§f¤Âid V‰gL¤j ika muR 2008-09«
M©o‰F xJ¡»ÍŸs %.27,60,000/- I (%ghŒ ÏUg¤njG Ïy£r¤J mWgjhæu«
k£L«)

Mizahs®, czÎ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiw

mt®fS¡F x¥gë¥ò brŒJ muR MizæL»wJ.
6.

nkny g¤Â 5-š x¥gë¥ò brŒa¥g£l bryéd« Ñœ¡f©l fz¡F jiy¥Ãš

g‰W it¡f¥gl nt©L«.
2235 - r_f ghJfh¥ò« eyD«
60 Vida r_f ghJfh¥ò ey¤Â£l§fŸ
200 Vida Â£l gâfŸ – gÂbdh‹wh« Iªjh©L Â£l¥ gâfŸ
iii k¤Âa muR bghW¥ng‰git
SE jäœehL Ef®nth® ghJfh¥ò k‰W« mÂfhu¢ r§f«
09 cjé¤ bjhif
03 F¿¥Ã£l Â£l§fS¡fhd cjé¤ bjhif
(j.F.bjh 2235 60 200 SE0932)
7.

Ï¢bryéd« xU òJ¥ gâ¤Â£l« F¿¤j bryédkhF«. Ïj‰F r£l

k‹w¥ nguitæš x¥òjš Ã‹d® bgw¥gL« nk‰F¿¤j x¥òjiy vÂ®neh¡» Ï
¢bryéd« Kj‰f© vÂ®ghuh¢ bryéd ãÂæèUªJ K‹gz« bgWtj‹ _y«
nk‰bfhŸs¥gL« . K‹ gz¤ij mDkÂ¡»‹w MizfŸ ãÂ (tuÎ – bryÎ-1)
Jiwæš jåahf Ãw¥Ã¡f¥gL«. vÂ®ghuh bryéd ãÂæèUªJ K‹gz« bgw¤
njitahd é©z¥g¤ij cça got¤Âš m›turhizæ‹ efYl‹ ãÂ (tuÎ –
bryÎ -1) Jiw¡F mD¥Ã it¡FkhW czÎ bghUŸ tH§fš k‰W« Ef®nth®
ghJfh¥ò¤Jiw Mizahs® nf£L¡ bfhŸs¥gL»wh®.
bryéd¤Â‰fhd

nkY«, Ï¡TLjš

cça fU¤JUit 2008-2009-« M©o‰fhd ÏWÂ

Jiz

khåa nfhç¡ifæš nr®¥gj‰F jtwhJ cça neu¤Âš ãÂ (T.c.(k)E.gh)Jiw¡F
mD¥Ã it¡FkhW czÎ bghUŸ tH§fš k‰W« Ef®nth® ghJfh¥ò¤Jiw
Mizahs® m¿ÎW¤j¥gL»wh®.

8. nk‰ brh‹d fz¡F jiy¥Ã‰F czÎ bghUŸ tH§fš k‰W« Ef®nth®
ghJfh¥ò¤Jiw Miza® kÂ¥ÕL fz¡F neuik¥ò k‰W« f£L¥gh£L mÂfhç
Mth®, nk‰brh‹d òÂa fz¡F jiy¥Ãid bjhl§FkhW r«gªj¥g£l r«gs
fz¡F mYty® / fUñy mYty® nf£L¡ bfhŸs¥gL»wh®.

<!-- page 55 -->

-529. Ï›turhiz ãÂ¤Jiwæ‹ mYtš rh®g‰w F¿¥ò v© 75552/CF & CP.2008
ehŸ 10.12.2008 k‰W« TLjš ãÂ xJ¡f ngnuL v© 1386 (Mæu¤J K‹}‰W
v©g¤jh¿‹go) bgw¥g£l x¥òjYl‹ btëæl¥gL»wJ.
/MSeç‹ Miz¥go/
f.r©Kf«
muR brayhs®
bgWe®
Mizahs®
czÎ bghUŸ tH§fš k‰W«
Ef®nth® ghJfh¥ò¤Jiw, br‹id -9
Ïa¡Fe® , ika muR Ef®nth® étfhu«
czÎ k‰W« bghJ éãnahf mik¢rf«
Ef®nth® étfhu¤Jiw, ošè – 1
gÂths®, khãy Ef®nth® FiwÔ® Miza« ,br‹id -4
khãy fz¡fha®, br‹id – 6/8/35
Kj‹ik khãy fz¡fha®,br‹id -8/35(bgaç£l ciwæš)
r«gs fz¡F mYty®. br‹id (»H¡F) 5/9
efš
brayhs®, kh©òäF Kjyik¢r® mYtyf«,br‹id -9
KJãiy ne®Kf cjéahs® mik¢r® (ãÂ) br‹id -9
KJãiy ne®Kf cjéahs® mik¢r® (czÎ)br‹id -9
ãÂ (T.c.(k)E.gh(t.br.bgh.1)(t.br.x)Jiw br‹id -9
Ïnfh/ cÂç
/Miz¥go mD¥g¥gL»wJ/
x«/ÃçÎ mYty®

<!-- page 56 -->

-53ABSTRACT
Acts and Rules-Tamilnadu Consumer Protection Rules, 1988- Amendment
-Orders- Issued.
_________________________________________________________________
CO.OPERATION,FOOD AND CONSUMER PROTECTION (H2)DEPARTMENT
G.O.(Ms)No.167

Dated:27.10.2009
Ig;grp-10
jpUts;Sth; Mz;L-2040

Read:
From the Commissioner of Civil Supplies and Consumer Protection
Chennai.600 005 letter Rc.No.CP2/401/2008 dated:02.04.2008.
ORDER:
The appended Notification will be published in the next issue of the
Tamilnadu Government Gazette.
2. The Works Manager, Government Central Press is requested to send two
hundred copies of the Gazette in which the said Notification is published to the
Secretary to

Government,

Cooperation, Food

and

Consumer

Protection

Department,Chennai.600 009, immediately.
(BY ORDER OF THE GOVERNOR)
K.SHANMUGAM
PRINCIPAL SECRETARY TO GOVERNMENT
To
The Works Manager,Government Central Press,Chennai.79.
(for publication in the Tamil Nadu Government Gazette)
The Commissioner of Civil Supplies and Consumer Protection, Chennai.600 005.
The Registrar, State Consumer Disputes Redressal Commission, Chennai.600
004.
The President, National Consumer Disputes Redressal Commission,New Delhi.
The Secretary to Government of India, Ministry of Consumer Affairs, Food and
Public Distribution, Department of Consumer Affairs,New Delhi.
All Departments of Secretariat,Chennai.9.
The Law Department, Chennai.600 009.

<!-- page 57 -->

All District Consumer Disputes Redressal Forum
All District Collectors
The Cooperation,Food and Consumer Protection Department
Chennai.600 009.(All Sections)
//Forwarded /By Order//
SECTION OFFICER
-54APPENDIX
NOTIFICATION
In exercise of the powers conerred by sub-section (2) of section 30 of the
Consumer Protection Act, 1986 (Central Act 68 of 1986), the Governor of Tamil
Nadu hereby makes te following amendments to the Tamil Nadu Consumer
Protection Rules, 1988:AMENDMENTS
In the said Rules1. In rule 2(1) after clause (c), the following clause shall be inserted, namely:"(cc)'District Council' means the District Consumer Protection Council established
for a district under sub-section (1) of section 8A of the Act."
(2) after clause(i), the following clause shall be inserted, namely:"(ii)"State Council" means the Consumer Protection Council for the State of Tamil
Nadu established under sub-section (1) of section 7 of the Act."
2 after rule 9, the following rules shall be added, namely:"10.Composition of official and non-official members of the State Council under
clause (b) of sub-section (2)of Section 7,(1) The State Council shall consist of the following official members and non official
members under clause (b) of sub-section (2) of section 7, namely:(a) Official Members:(i)

The Secretary to Government
Cooperation,Food and Consumer Protection Department
Chennai.600 009.

(ii)

The Secretary to Government

<!-- page 58 -->

Health and Family Welfare Department
Chennai-600 009.
(iii)

The Secretary to Government
Transport Department, Chennai.600 009
-55-

(iv)

The Secretary to Government
Industries Department, Chennai.600 009.

(v)

The Secretary to Government
Housing and Urban Development Department
Chennai.600 009.

(vi)

The Secretary to Government
Municipal Administration and Water Supply Department
Chennai.600 009.

(vii)

The Secretary to Government
Higher Education Department
Chennai.600 009.

(viii)

The Secretary to Government
School Education Department,Chennai.600 009.

(ix)

The Commissioner of Civil Supplies and Consumer Protection Department,
Chepauk, Chennai.600 005.

(b) Non-official Members:(i)
Fifteen representatives from the Trade Industry and Service Sector
nominated by the Chairman.
(ii)

Twenty representatives of Voluntary Consumer Organisations nominated by
the Chairman

(iii)

Two Members of Parliament to be nominated by the State Government

(iv)

Two Members of Tamil Nadu Legislative Assembly to be nominated by the
State Government

(v)

Two Chairmen of District Panchayats to be nominated by the State
Government
(2) The term of office of the non-official members of the State Council shall

be for a period of three years.
(3) A non-official member of the State Council may, by writing under his

<!-- page 59 -->

hand and addressed to the Chairman of the State Council, resign from his
membership in the State Council. Any vacancy in the case of non-official member
caused by resignation or otherwise, shall be filled, from the persons belonging to
the same interest to which the member belonged, by the Government of Tamil
-56Nadu and such person shall hold office so long as the member whose place he fills
would have held office.
(4) The Government of Tamil Nadu may, after giving reasonable
opportunity, remove any non-official member of the State Council at any time. The
vacancy so caused shall be filed in as indicated in sub-rule(3).
11. Procedure for meeting of the State Council:The State Council shall observe the following procedure in regard to the
transaction of its business, namely:1. The meeting of the State Council shall be presided over by the Chairman in
the absence of the Chairman, the State Council shall elect a member from
among themselves to preside over that meeting of the Council.
2. Every meeting of the State Council shall be called by giving notice of not
less than ten days in writing to every member.
3. Every notice of a meeting of the State Council shall specify the place, date
and hour of the meeting and shall contain the statement of business to be
transacted thereat.
4. No proceedings of the State Council shall be invalid merely by reason of
existence of any vacancy in or any defect in the establishment of the
Council.
5. The State Council may require the presence of any officer of the
Government of Tamil Nadu or the Central Government at its meeting as
special invitee on any subject of importance to consumers.
12. Allowances to Members to attend meeting of the State Council:The State Consumer Protection Council is classified as First Class

<!-- page 60 -->

Committee. The non-official members of the Committee are permitted to avail the
Daily Allowances/Travelling Allowance for attending the meeting as per the orders
issued by the Government in Finance Department then and there. The Members
of Parliament and the Members of Legislative Assembly are eligible to draw the
-57Daily Allowance/Travelling Allowance admissible to them as per the orders issued
by the Loksabha Secretariat and the Tamil Nadu Legislative Assembly Secretariat
for attenting the Council meetings.
13.Composition of official and non-official members of the District Council
under clause (b) of sub-section (2) of section 8-A:
(1) The District Council shall consist of the following official and non-official
members under clause (b) of sub-section (2) of section 8A namely:(a) Official Members:Sl.

Name of Department

District other than Chennai

Chennai District

No.
1.

Revenue Department

2.

Civil
Supplies
and District Supply and Consumer Deputy Commissioner
Consumer
Protection Protection Officer
and
Consumer
Department
Protection
Officer(Chennai,North
and Chennai South)

3.

Cooperative Department Regional Joint Registrar
Cooperative Societies

4.

Public
Health
and Deputy Director
Preventive
Medicine
Department

Joint Director

5.

Department
Control

Joint Director of Drugs
Control

6.

Department of Medical Deputy Director
Services

Joint Director

7.

Department
Metrology

Controller
Metrology

8.

Transport Department

of

of

District Revenue Officer

Drugs Inspector of Drugs Control

Legal Inspector of Labour
Regional Transport Officer

..

of Joint Registrar(Public
Distribution System) I
& II Chennai

of

Legal

Deputy Commissioner
of
Transport

<!-- page 61 -->

Department

-589.

Industries
and Assistant Director
Commerce Department

Joint Director

10.

Police Department

Deputy
Police

11.

Municipal
Adminisgtration
Department

Regional Director

12.

Town
and
Country District Assistant Director
Planning Department

Representative
of
Chennai Metropolitan
Development
Authority

13.

Town Panchayat

Joint Director

14.

Corporation/ Municipality Corporation/Municipality

Superintendent

of Deputy Commissioner
of Police
Additional
Director,
Municipal
Administration

Assistant Director

Chennai corporation
Health Officer

Health Officer
15.

Tamilnadu
Board

Electricitty Superintendenting Engineer

16.

Tamil
Supply
Board

17.

Transport Corporation

Regional/Branch
Manager, Managing
Director
Tamilnadu
Government Chennai Metropolitan
Transport Corporation
Transport Corporation

18.

Oil Corporation

Regional Managers
Hindustan/Bharat
Corporation

19.

Bharat Sanchar Nigam District Manager
Limited

Asst.General Manager
(Public Grievances)

20.

Railways

Joint Director (Public
Grievances)

Nadu
Water Superintending Engineer
and Drainage

Regional Manager

Chief Engineer Tamil
Nadu Electricity Board
Chief
Engineer
Chennai Metropolitan
Water Supply and
Drainage Board

Indian, Chief
Regional
Oil Managers,
Indian/
Hindustan/ Bharat Oil
Corporation

<!-- page 62 -->

21.

Bureau
Standrard

of

Indian Regional Director

Deputy Chief Director

-59(b) Non-Official Members
Sl.

District Other than Chennai

Chennai District.

No.
1.

Members of Parliament and Members Members of Parliament and Members
of Tamil Nadu Legislative Assembly of of Tamil Nadu Legislative Assembly
the District.
of the District.

2.

Two representatives of Traders Two representatives of Traders
Association
nominated
by
the Association
nominated
by
the
Chairman
Chairman

3.

Four representatives of registered Four representatives of registered
Voluntary Consumer Organisation Voluntary Consumer Organisation
nominated by the Chairman
nominated by the Chairman

4.

Four representatives from the leaders ......
of the Self Help Group Blocks
Federation nominated by the Chairman

(2) The term of office of the non-official members of the District Council shall
be for a period of three years.
(3) A non-official member of the District Council may, by writing under his
hand and addressed to the Chairman of the District Council , resign from his
membership in the District Council.

Any vacancy in the case of non-official

members caused by resignation or otherwise, shall be filled from the persons
belonging to the same interests to which the member belonged and such person
shall hold office so long as the member whose place he fills would have held
office.
(4) The Government of Tamil Nadu may, after giving reasonable
opportunity, remove any non-official member of the District Council at any time.
The vacancy so created shall be filled in as indicated in sub-rule (3).

<!-- page 63 -->

14. Procedure for meeting of the District Council:The District Council shall observe the following procedure in regard to the
transaction of its business, namely-

-606. The meeting of the District Council shall be presided over by the chairman,.
In the absence of the Chairman, the District Council shall elect a member
from among themselves to preside over that meeting.
7. Every meeting of the District Council shall be called by giving notice of not
less than ten days in writing to every member.
8. Every notice of a meeting of the District Council shall specify the place,
date and hour of the meeting and shall contain the statement of business to
be transacted thereat.
9. No proceedings of the District Council shall be invalid merely by reason of
existence of any vacancy in or any defect in the establishment of the District
Council.
10. The District Council may also request the presence of any other district level
officer as a special invitee at any meeting of the District Council based on
the issue of importance to consumers from time to time.
15. Allowances to members to attend meetings of District Council:- The District
Consumer Protection Council is classified as Second Class Committee. The nonofficial

members

of

the

Committee

are

permitted

to

avail

the

Daily

Allowance/Travelling Allowance for attending the meeting as per the orders issued
by the Government in Finance Department then and there.

The Members of

Parliament and the Members of Legislative Assembly are eligible to draw the Daily
Allowance /Travelling Allowance admissible to them as per the orders issued by
the Lok Sabha Secretariat and the Tamil Nadu Legislative Assembly Secretariat
for attending the Council meeting.

<!-- page 64 -->

K.SHANMUGAM
PRINCIPAL SECRETARY TO GOVERNMENT
/true copy/
SECTION OFFICER
-61GOVERNMENT OF TAMILNADU
Abstract
Consumer Protection act, 1986 – State Consumer Protection council /District
Consumer Protection Council – Reconstitution of - orders Issued.
CO.OPERATION , FOOD AND CONSUMER PROTECTION (H2)DEPARTMENT
G.O.(Ms)No. 168

Dated: 27.10.2009
Ig;grp -10
jpUts;Sth; Mz;L - 2040
Read:

1

G.O.(Ms).No.616, Cooperation, Food and Consumer Protection
Department, dated : 5.11.1993.

2

G.O.(Ms)No. 148, Cooperation, Food and Consumer Protection
Department, dated 22.5.2002.

3

From the Commissioner of Civil Supplies and Consumer Protection
letter Rc.No. CP2/44100/2005 dated:13.4.2006, 12.3.2009 and
29.5.2009.
--------

ORDER:
In the Government Order first read above orders have been issued to
constitute the District Consumer Protection council under the Consumer Protection
Act, 1986 (Central Act 68 of 1986) to discuss all matters relating to Consumer
Protection and Public Distribution System and suggest appropriate measures for
improving the system and in the Government Orders second read above , the
State Consumer Protection Council has been established under the Consumer
Protection Act, 1986 (Central Act 68 of 1986) with effect from 5.11.1993 and
22.5.2002 respectively. In his letter 3rd read above, the Commissioner of Civil
Supplies and Consumer Protection has sent proposals to the Government for
reconstitution of the State and District Consumer Protection Council.
2.

The Government hereby order the reconstitution of the State

<!-- page 65 -->

Consumer Protection Council consisting of official and non-official members with
Hon'ble Minister for Cooperation Food and Consumer Protection as its Chairman
and Secretary to Government, Cooperation, Food and Consumer Protection
Department as its Member Secretary and the same to reconstitute the District
Consumer Protection Council consisting of official and non-official members with
-62concerned District Collector as its Chairman.
3.

The tenure of the State and District Consumer Protection Council and

District Consumer Protection Council shall be three years on and from the date of
notifying in the Tamil Nadu Government Gazette and it shall meet not less than
twice in a year at such time and place as the Chairman may decide. The object of
the Council is to promote and protect the rights of the consumers laid down in
clauses (a) to (f) of sections 6 of the Consumer Protection Act 1986 within the
State and within the District.
4.

The Government direct that the State Consumer Protection Council

reconstituted in para 2 above shall be a First Class Committee and the District
Consumer Protection Council shall be a Second Class committee for the purpose
of drawal of Travelling Allowance and Daily Allowance to the non – official
members. The Travelling allowance bills of non -official members shall be paid
from out of the State funds the commissioner of Civil Supplies

and Consumer

Protection is hereby authorized to draw an amount of Rs. 10,000/-(Rupees Ten
thousand only) as advance and make payment to non -official members in cash on
the day of meeting itself and to adjust the amount by presenting necessary
adjustment Travelling allowance bills after the meeting is over. the Government,
further delegate the above powers to draw and disburse the amount of Daily
Allowance and Travelling allowance to non – official members of the State
Consumer Protection Council to the Commissioner of Civil Supplies and consumer
Protection, Chennai – 600 005 . The District Collectors are authorized to draw and
disburse

the Travelling Allowance and Daily Allowance of the non -official

members of the District Consumer Protection Council.
5. The expenditure shall be debited to the following Head of Account:
STATE CONSUMER PROTECTION COUNCIL:

<!-- page 66 -->

3456-00 -Civil Supplies – 001 Direction and AdministrationI Non – Plan AA Headquarters -04 . Travel Expense 01 –
Tour Travelling Allowances”
(D.P.Code 3456-00-001AA 0413)

-63DISTRICT CONSUMER PROTECTION COUNCIL:
3456-00-Civil Supplies – 001 Direction and Administration
1 Non Plan AB – District Establishment -04 . Travel Expenses 01Tour Travelling Allowances (D.P.Code 3456-00-001-AB 0411).
6. The Notification I and II appended to this order shall be published in English in
the Tamil Nadu Government Gazette and in Tamil in all the District Gazettes. The
Malayalam version will also be published in the District Gazettes of Kanyakumari,
Tirunelveli and the Nilgiris Districts. Six copies of the Notifications are sent to the
Tamil Development, Religious Endowments and Information (Translation)
Department. That Department is requested to forward immediately the Tamil
and Malayalam version of the Notifications to the Works Manager, Government
Central Press, Chennai – 79 who is requested to arrange for the immediate
publication the District Gazette concerned.
7.

The Works Manager / Government Central Press, Chennai – 600 079

is requested to send two hundred copies of the English Notification each to the
Government and the Commissioner of Civil Supplies and Consumer Protection ,
Chennai – 600 005.
8.

This order issues with the concurrence of Finance Department vide

its U.O. No. 60112 CF & CP /2009 dated: 21.10.2009.
(BY ORDER OF THE GOVERNOR)
K.SHANMUGAM
PRINCIPAL SECRETARYTO GOVERNMENT
To
The Works Manager, Government Central Press, Chennai-79 (for publication in
the Extra ordinary issue of Tamil Nadu Government Gazette).
The Tamil Development Culture and Religious
Endowment(Translation)Department, Chennai-9(6 copies)
All Secretaries to Government, Chennai-9.

<!-- page 67 -->

All Departments of Secretariat, Chennai -9.
All Chief Executive Officers of Corporation and Boards,
All Heads of Departments.
The Commissioner of Civil Supplies and Consumer Protection
Department,Chennai -5
The Deputy Commissioner of Civil Supplies, (City) North /South),Chennai -5.
All District Collectors
The Registrar General High Court, Chennai -104.
-64The Secretary to Chief Minister , Chennai -9.
The Senior Personal Assistant to Minister (Food),Chennai -9.
The Accountant General , Chennai -18/6/35.
The Accountant General , Chennai – 18/6/35(by name)
The Accountant General ,(CAB)Chennai -9.
The Pay and Accounts Officer ,Chennai – 9/35/5.
The Secretary to Government,
Health and Family Welfare Department, Chennai -9.
The Secretary to Government,
Transport Department, Chennai-9.
The Secretary to Government,
Housing & Urban Development Department,Chennai -9.
The Secretary to Government,
Municipal Administration and Water Supply Department,Chennai -9.
The Secretary to Government
Energy Department, Chennai – 9.
The Secretary to Government,
Higher Education Department, Chennai -9.
The Secretary to Government
School Education Department, Chennai – 9.
The Secretary to Government,
Labour and Employment Department, Chennai -9.
The Chairman, Tamil Nadu Electricity Board, Chennai -2.
The Chairman, Tamil Nadu Pollution Control Board, Chennai.
The Chief General Manager, BSNL, Telephone House, Chennai -1
The General Manager, Southern Railway, Chennai -3.
The Zonal Manager, Life Insurance Corporation of India, Chennai -2.
The Assistant General Manager, State Level Bankers' Committee, Tamil Nadu.
Indian Overseas Bank, Central Officer(Lead Bank Department), '
763 Anna Salai, Chennai -2.
The State Level Co.ordinator,
Indian Oil Corporation , 739, Anna Salai, Chennai -2.
The Deputy Director General,
Bureau of Indian Standards, Chennai -113.
The President Indian building Employees Association,
No. 11(6), Kaza Major Road 2nd Floor, Kaza Plaza, Egmore,Chennai -8.
The President
Tamil Nadu Ornaments Merchants Association
2/10 , Raja Lane, N.S.C.Bose Road, Chennai -79.
The President , Tamil Nadu Chemists and Druggist Association,
D-36, 8th Floor , D-Block , Halls Towers, 33, Halls Road, Chennai -8.

<!-- page 68 -->

The President ,
All India LPG Distribution Federation,
No. 29,Medavakkam Tank Road, Kilpauk, Chennai =-10.
The President
Tamil Nadu Paddy & Rice Wholesale Dealers Association,
No. 2 P.A.N. Rajarathinam Salai, 6th Street, Chennai -21.
Tmt. Nirmala Desihan,
India Consumers Corporation,
-653/242. Rajendra Gadens, Vettuvankani,Chennai -41.
Tmt. Shoba Iyar,
Co.ordinator , Citizen Consumers and Civic Action Group,
9/5, 2nd Street, Padbanaba Nagar, Adyar, Chennai -20.
Thiru. A.K.Ramesh , Secretary,
Kancheepuram Consumer Welfare Association, 12-A, Deasipalayam St.,
Kancheepuram
Thiru. D.Bazurideen,
President, Consumers Protection Council
38, Periya Mazudhi St., Peranampettai, Vellore – 635 810.
. ThiruNizzamudin
President, Cuddalore District Consumers Council Federation
No. 72/7. Nethaji Road,. Manjakuppam,. Cuddalore District.
Thiru. K.Munian
Secretary Consumers Protection Council,
1-1-165 Daniel Street, Meenashi Nagar, Mathiyan kuttai, Mettur Dam,
Salem – 636 452
Thiru. S.Kuppusamy
Secretary, Tamil Nadu Consumers Protection Council
8-A, Najappan Lane, Padikattuthurai, Karur
Thiru. R.Baskaran, President,
District Consumers Protection Sangam ,
5, Kamaraj Nagar, Ariyalur. Perambalur District TN. 621 704.
Tmt. Sakunthala Sreenivasan, President ,
Trichy Consumers Council
C-1144, Kampar Street, Anna Nagar Thanoor, Trichy – 620 017.
Thiru. K.Suburayan,
Tamil Nadu Consumers Council , Namakkal.
Thiru. K.Chenniappan
President, Annur Union Consumers Protection Council
142, L A M Colony, Annur, Coimbatore District – 638 653.
Thiru. C.Adaikalam, President,
Tanjavur District Consumers Protection Council, 1300,.
Gandhiji Nagar, Najikottai Road, Thanjavur
Thiru. K.Ramesh
Secretary,
Thanjavur District Tamil Nadu Consumer Protection
Council , 40, Sivam Nagar, Pangal Road, Thiruvarur – 610 001.
Thiru. R.Kalatharan,
President,
Tamil Nadu Consumers Protection Council,
35, Chatteppar South Street,

<!-- page 69 -->

Nagapattinam District – 611 001.
Tmt. Packiyalakshmi. C
Secretary Womens' Consumer Protection Association ,
81, Alagar Nagar 5th Street, K.Pudur,
Madurai District 625 007.
Thiru. Mohamad Egiya
President,
-66Virudhunagar District Consumers Protection Association
337 , Railway Station Road, Chinnapallivasal Building
Virudunagar – 626 001.
Thiru. Latha,
Member , Pudukottai District Consumers Council 5790
Santhanapuram 4th Street, Pudukottai – 622 001.
Thiru. K.J.Mathavan,
President, Consumers Rights Protection Kazhagam,
8/130-C,Madurai Rameswaram Road, Paramakudi,
Ramanathapuram District – 623 707.
Thiru. D.A.Prabahar, President,
Tamil Nadu People Consumer Organisation ,
14, Law Chamber, District Court Complex,
Tirunelveli – 627002.
Thiru. S.Thomas,
President,
Kanyakumari Zila Consumers Protection Centre,
U.G.P. Complex 2nd Floor,
14, Padjelvelai Cap Road, Nagerkovil,
Kanyakumari District – 629 001.
Thiru. A.K.S.Vijayan, M.P.
Nagapattinam Constituency, AKS Illam, P.O.Sithamalli, Mannargudi Taluk
Thiruvarur District PIN 614 705.
Thiru.Azhagiri, M.P,.
Cuddalore Constituency
No.6-A, Old Tower Block, Nandanam,
Chennai – 600 035.
Tmt. Latha Adhiaman, M.L.A.
Thirumangalam Constituency
1/113/1, Sonai Meena Nagar, Kamatchi Nagar,
Bhagavathsingh Street, Thirumangalam.
Thiru. Videyal S.Sekar, M.L.A.
Kangeyam Constituency
4/451, Sangu Nagar, Surampatti
Erode 638 011.
Tmt. R.Kavitha Parthiban,
District Panchayat President,
78-B Nwehruji Nagar, vedachandur
Dindigul
Thiru. M.R.Rajendran,
District Panchayat President,

<!-- page 70 -->

Anna Nagar, Mathur Post,
Krishnagiri 635 203.
The Secretary
Ministry of Consumer Affairs, Food and Public Distribution Department of
Food and Public Distribution , New Delhi.
The Deputy Director General of BIS
The Secretary,
Ministry of Information and Broadcasting, Government of India,
-67Shastry Bhawan, New Delhi.
The Secretary,
Ministry of Secondary and Higher Education , Ministry of Human
Resources Development, Shastry Bhawan, New Delhi.
The Secretary
Ministry of Youth Affairs and Sports, Government of India,
shastri Bhawan, New Delhi.
Copy to:
The Finance (CF & CP/Allowances) Department, Chennai-9.
The Registrar , State Consumer Disputes Redressal Commission,Chennai -4.
The Law Department, Chennai -9.
SF/SC
//Forwarded by Order//
Sd/..
Section Officer

<!-- page 71 -->

-68APPENDIX
NOTIFICATION -I
In exercise of the powers conferred by section 7 of the Consumer
Protection act, 1986 (Central Act 68 of 1986) , the Governor of Tamil Nadu hereby
establishes, with effect on and from 27.10.2009 for a period of three years, the
Consumer Protection Councils for the State of Tamil Nadu which shall consist of
the following members:
1

The Secretary to Government,
Co.operation, Food and Consumer Protection
Department, Chennai -9.

Member Secretary

2

The Secretary to Government,
Health and Family Welfare Department,
Chennai -9.

Member

3

The Secretary to Government,
Transport Department, Chennai-9.

Member

4

The Secretary to Government,
Industries Department, Chennai-9.

Member

5

The Secretary to Government,
Housing & Urban Development Department,
Chennai -9.

Member

6

The Secretary to Government,
Municipal Administration and Water Supply
Department,Chennai -9

Member

7

The Secretary to Government,
Higher Education Department, Chennai -9

Member

8

The Secretary to Government
School Education Department, Chennai – 9.

Member

9

The Commissioner of Civil Supplies and Consumer
Protection Department,Chepauk, Chennai -5

Member

10

The Chairman, Tamil Nadu Electricity Board,
Chennai -2.

Member

11

The Chairman, Tamil Nadu Pollution Control Board,

Member

<!-- page 72 -->

Chennai.
12

Chief General Manager, Tamil Nadu Telecom Circle,
Chennai

Member

13

The General Manager, Southern Railways,
Chennai -3

Member

14

Zonal Manager, Life Insurance Corporation of India,
Chennai -2.

Member

15

Assistant General Manager, State Level Bankers'
Committee,Chennai – 600 002.

Member

16

State Level Co.ordinator,
Indian Oil Corporation , Chennai – 34.

Member

17

Deputy Director General,
Bureau of Indian Standards, Chennai -113.

Member

18

The President
Tamil Nadu Hoteliers Association, 4th floor, Mondiath
Manson, 27, Mandiath Road, Egmore,Chennai -8.

Member

19

The President,
Indian building Employees Association,
No. 11(6), Kaza Major Road 2nd Floor, Kaza Plaza,
Egmore,Chennai -8.

Member

20

The President,
South India Chambers of Commerce and Industry,
Chennai-18.

Member

21

The President
Tamil Nadu Ornaments Merchants Association
2/10 , Raja Lane, N.S.C.Bose Road, Chennai -79.

Member

22

The President ,
Tamil Nadu Chemists and Druggist Association,
D-36, 8th Floor , D-Block , Halls Towers, 33,
Halls Road, Chennai -8.

Member

23

The President ,
All India LPG Distribution Federation,
No. 29,Medavakkam Tank Road, Kilpauk,
Chennai -10.

Member

24

The President
Tamil Nadu Paddy & Rice Wholesale Dealers
Association, No. 2 P.A.N. Rajarathinam Salai, 6th
Street, Chennai -21.

Member

25

Tmt. Nirmala Desihan,
India Consumers Corporation,
3/242. Rajendra Gadens, Vettuvankani,Chennai -41

Member

26

Tmt. Shoba Iyar,
Co.ordinator , Citizen Consumers and Civic Action
Group, 9/5, 2nd Street, Padbanaba Nagar, Adyar,
Chennai -20.

Member

<!-- page 73 -->

27

Thiru. A.K.Ramesh , Secretary,
Kancheepuram Consumer Welfare Association,
12-A, Deasipalayam St., Kancheepuram

Member

28

Thiru. D.Bazurideen,
President, Consumers Protection Council
38, Periya Mazudhi St., Peranampettai,
Vellore – 635 810.

Member

29

ThiruNizzamudin
President, Cuddalore District Consumers
Council Federation , No. 72/7. Nethaji Road,.
Manjakuppam,. Cuddalore District ThiruNizzamudin

Member

30

Thiru. K.Munian
Secretary Consumers Protection Council,
1-1-165 Daniel Street, Meenashi Nagar
Mathiyan kuttai, Mettur Dam,
Salem – 636 452.

Member

31

Thiru. S.Kuppusamy
Secretary, Tamil Nadu Consumers Protection Council
8-A, Najappan Lane, Padikattuthurai, Karur.

Member

32

Thiru. R.Baskaran, President,
District Consumers Protection Sangam ,
5, Kamaraj Nagar, Ariyalur. Perambalur District
TN. 621 704.

Member

33

Tmt. Sakunthala Sreenivasan, President ,
Trichy Consumers Council
C-1144, Kampar Street, Anna Nagar Thanoor,
Trichy – 620 017.

Member

34

Thiru. K.Suburayan,
Tamil Nadu Consumers Council , Namakkal.

Member

35

Thiru. K.Chenniappan
President,
Annur Union Consumers Protection Council
42, L A M Colony, Annur,
Coimbatore District – 638 653.

Member

36

Thiru. C.Adaikalam, President,
Tanjavur District Consumers Protection Council,
1300,Gandhiji Nagar, Najikottai Road, Thanjavur .

Member

37

Thiru. K.Ramesh
Secretary,
Thanjavur District Tamil Nadu
Consumer Protection Council ,
40, Sivam Nagar, Pangal Road,
Thiruvarur – 610 001.

Member

38

Thiru. R.Kalatharan,
President,
Tamil Nadu Consumers Protection Council,

Member

<!-- page 74 -->

35, Chatteppar South Street,
Nagapattinam District – 611 001.
39

Tmt. Packiyalakshmi. C
Secretary Womens'
Consumer Protection Association ,
81, Alagar Nagar 5th Street, K.Pudur,
Madurai District 625 007.

Member

40

Thiru. Mohamad Egiya
President,
Virudhunagar District
Consumers Protection Association
337 , Railway Station Road,
Chinnapallivasal Building
Viruunagar – 626 001.

Member

41

Thiru. Latha,
Member , Pudukottai District
Consumers Council
5790, Santhanapuram 4th Street,
Pudukottai – 622 001.

Member

42

Thiru. K.J.Mathavan,
President, Consumers Rights Protection Kazhagam,
8/130-C,Madurai Rameswaram Road,
Paramakudi,
Ramanathapuram District – 623 707.

Member

43

Thiru. D.A.Prabahar, President,
Tamil Nadu People Consumer Organisation ,
14, Law Chamber, District Court Complex,
Tirunelveli – 627002.

Member

44

Thiru. S.Thomas,
President,
Kanyakumari Zila Consumers Protection Centre,
U.G.P. Complex 2nd Floor,
14, Padjelvelai Cap Road, Nagerkovil,
Kanyakumari District – 629 001.

Member

45

Thiru. A.K.S.Vijayan, M.P.
Nagapattinam Constituency, AKS Illam,
P.O.Sithamalli, Mannargudi Taluk
Thiruvarur District PIN 614 705.

Member

46

Thiru.Azhagiri, M.P,
Cuddalore Constituency
No.6-A, Old Tower Block, Nandanam,
Chennai – 600 035.

Member

47

Tmt. Latha Adhiaman, M.L.A.
Thirumangalam Constituency
1/113/1, Sonai Meena Nagar, Kamatchi Nagar,
Bhagavathsingh Street, Thirumangalam.

Member

48

Thiru. Videyal S.Sekar, M.L.A.

Member

<!-- page 75 -->

Kangeyam Constituency
4/451, Sangu Nagar, Surampatti
Erode 638 011.
49

Tmt. R.Kavitha Parthiban,
District Panchayat President,
78-B Nwehruji Nagar, vedachandur
Dindigul.

Member

50

Thiru. M.R.Rajendran,
District Panchayat President,
Anna Nagar, Mathur Post,
Krishnagiri 635 203

Member

51

Representative from Department of Consumer Affairs Member
(to be nominated by the Central Government)

52

Representative from Bureau of Indian Standards Member
(BIS)/National Test House (NTH) (from nearest office)
(to be nominated by the Central Government)

53

Representative from Department information and Member
Broadcasting (from nearest regional Office)(to be
nominated by the Central Government)

54

Representative from Department of Secondary and Member
Higher Education (from nearest regional Office) to be
nominated by the Central Government)

55

Representative from Department of Youth Affairs and Member
sports (from nearest regional office (to be nominated
by the Central Government)

<!-- page 76 -->

-73NOTIFICATION - II
In exercise of the powers conferred by section 8A of the Consumer
Protection act, 1986 (Central Act 68 of 1986), the Governor of Tamil Nadu hereby
establishes, with effect on and from 27.10.2009 for a period of three years, the
District Consumer Protection Council for every district in the State of Tamil Nadu
which shall consist of the following members: A) OFFICIAL MEMBERS:
Sl.

Name of Department

For all Districts
(Except Chennai City)

1

Revenue Department

District Revenue Officer

--

2

Co.operation,Food and
Consumer Protection
Department

District Supply and
Consumer Protection
Officer

Joint Commissioner of
Civil Supplies and
Consumer Protection
(Chennai North and
South)

3

Cooperation Department Registration of
Cooperative Societies

Joint Registrar (Public
Distribution
System)Chennai North
and South

4

Department of Public
Health and Preventive
Medicine

Joint Director

Joint Director

5

Department of Drugs
Control

Inspector of Drugs
Control

Joint Director
Department of Drugs
Control

6

Medical Services

Deputy Director

Joint Director

7

Legal Metrological
Department

Inspector of Labour

Controller of Legal
Metrological
Department

8

Department of Transport Regional Transport
Officer

Deputy Commissioner
of Transport.

9

Department of Industries Assistant Director

Joint Director

No.

For Chennai City

<!-- page 77 -->

and Commerce
10

Department of Police

Superintendent of Police Deputy Commissioner
of Police.

11

Department of Municipal
Administration
Regional director

Additional Director of
Municipal
Administration

12

Town and Country
Planning Department

District Assistant Director Representative of
Chennai Metropolitan
Development Authority,
Chennai

13

Town Panchayat

Assistant Director

14

Corporation /Municipality Health officer

Joint Director
Health Officer
Chennai Corporation

15

Tamil Nadu Electricity
Board

Superintending Engineer Chief Engineer
Tamil Nadu Electricity
Board
Chennai

16

17

Tamil Nadu Water
supply and Sewerage
Board

Superintending Engineer Chief Engineer

Transport Corporation

Divisional /Branch
Manager, Tamil Nadu
Transport Corporation

Managing Director,

Tamil Nadu Water
supply and Sewerage
Board

Chennai Metropolitan
Transport Corporation

18

Oil Corporation

Regional Manager of
India/Hindustan Barath
Oil Corporation

Chief Regional
Manager of Indian /
Hindustan/Barath Oil
Corporation.

19

Barath Sanchar Niham
Limited

District Manager

Assistant General
Manager (Public
Grievance)

20

Railways

Divisional Manager

Joint Director (Public
Grievance)

21

Bureau of Indian

Regional Director

Deputy Director

<!-- page 78 -->

Standards

General

-75Sl.No.

For all Districts
Chennai City)

(Except

For Chennai City

1

All M.L.As. and M.Ps of concerned
Districts

All M.L.As and M.Ps of Chennai
City

2

Two representatives of Traders
Association nominated by Chairman

Two representatives of Traders
Association
nominated
by
Chairman

3

Four representatives from registered Four
representatives
from
Voluntary Consumer Organisations
registered Voluntary Consumer
nominated by the Chairman
Organisations nominated by the
Chairman

4

Self Help Groups – Block Federation -leaders from four Blocks nominated
by the Chairman
K.SHANMUGAM
PRINCIPAL SECRETARY TO GOVERNMENT
// true copy//
Sd/...
SECTION OFFICER

<!-- page 79 -->

-76MISCELLANEOUS
RU¡f«
kWthœÎ – Kfh«thœ Ïy§if¤ jäH®fŸ – jäHf k¡fS¡F tH§f¥gL«
ey¤Â£l§fis Kfh« thœ Ïy§if¤ jäH®fS¡F« éçÎgL¤Jjš – Miz
btëæl¥gL»wJ.
bghJ (kWthœÎ2)¤ Jiw
muR Miz (ãiy) v© 480
ehŸ-07.06.2011
go¡f¥g£lJ:
1. muR Miz (ãiy) v© 18. r_fey« k‰W« r¤JzÎ

Â£l« (SV3) Jiw, ehŸ.21.10.2010
2. muR Miz v© 42, r_f ey« k‰W« r¤JzÎ (SW3)
ehŸ 17.05.2011 k‰W« muR Miz v© 43, r_f ey« k
‰W« r¤JzÎ Â£l« (SW3) Jiw, ehŸ 17.05.2011
3. kh©gäF Kjyik¢r® mt®fë‹ jiyikæš 30.05.2011
m‹W eilbg‰w mik¢ruit T£l¤Â‹ KoÎ
4. 03.06.2011 m‹W r£l¥nguitæš ãfœªj MSe® ciu
-------Miz
kh©òäF Kjyik¢r® mt®fë‹ jiyikæš 30.05.2011 m‹W eilbg‰w
mik¢ruit¡ T£l¤Âš jäœeh£oš cŸs Kfh«thœ Ïy§if¤ jäH®fŸ
eyD¡fhf

gšntW

KobtL¡f¥g£lJ.

Áw¥ò

ey¤Â£l§fŸ

éçth¡f«

brŒtJ

F¿¤J

03.06.2011 m‹W r£l¥nguitæš ãfœªj MSe® ciuæš

“Ïy§if¤ jäH®fŸ j§»ÍŸs Kfh«fŸ Óuik¡f¥g£L mt®fŸ jäHf¤Ânyna
bfsutkhf thH¤ njitahd mid¤J elto¡iffS« vL¡f¥gL«.

Ïe¤

Kfh«fëš jukhd ÏU¥Ãl«, FoÚ®, Rfhjhu« k‰W« kU¤Jt trÂfŸ ngh‹wit
brŒJ ju¥gL«.

Ïy§if jäœ mfÂfë‹ FHªijfŸ fšé gæy¤ njitahd

cjéfis tH§FtJl‹ mt®fŸ ntiy thŒ¥ig¥ bgWtj‰fhd Áw¥ò ntiy
thŒ¥ò¥ gæ‰ÁfŸ më¡f¥gL«.

jäœeh£oš brašgL¤j¥gL« mid¤J ey¤

Â£l§fS« Kfh«fëš j§»ÍŸs Ïy§if¤ jäH®fS¡F« Ú£o¡f¥gL«” vd

<!-- page 80 -->

m¿é¡f¥g£lJ.
2.

mj‹go éçth¡f« brŒa¥g£LŸs ey¤ Â£l§fŸ ÑnH ju¥g£LŸsd.

3.

Mjut‰w KÂnah® XŒñÂa Â£l«, Mjut‰w éjita® XŒñÂa Â£l«,

fztdhš ifél¥g£l Mjut‰w bg©fŸ XŒñÂa¤ Â£l«, Mjut‰w kh‰W¤

-77ÂwDilnah® XŒñÂa¤ Â£l« k‰W« Mjut‰w ÂUkzkhfhj bg©fŸ XŒñÂa
Â£l« Kjyhd Ïytr r_f ghJfh¥ò Â£l§fë‹ Ñœ %.1000/- XŒñÂa«
jäœeh£L k¡fS¡F tH§f¥g£L

tU»wJ.

Ïy§if jäH® Kfh«fëš

jäœeh£oš 65 taÂ‰F nk‰g£l KÂnah® 2580 eg®fS«, éjita® 2518 ngU«,
Mjut‰w bg©fŸ 182 ngU« kh‰W¤ ÂwdhëfŸ 264 ngU« tÁ¤J tU»‹wd®.
Ï¤Â£l¤ij Kfh« thœ Ïy§if jäH®fS¡F« éçÎgL¤jyh«.
4. bg© FHªij ghJfh¥ò Â£l¤Â‹ Ñœ M© FHªij Ï‹¿ Mdhš Ïu©L
bg©

FHªijfS¡F

brašgL¤j¥gL»wJ.

nkš

Ïšyhj

FL«g§fS¡F

Ïªj¤Â£l«

Ï¤Â£l¤Â‹go xU bg© FHªij k£Lnk cŸs

FL«gj¤Â‰F FHªijæ‹ bgaçš %.22,200/- it¥ÕL brŒaÎ« Ïu©L bg©
FHªijfŸ cŸs FL«g¤Âš, x›bthU FHªijæ‹ bgaçY« %,15,200/- it¥ÕL
brŒa¥g£L tU»wJ.

Ï›it¥ò¤ bjhif 20 tUl§fS¡F eÂ ãWtd§fëš

it¡f¥gLtJl‹, 5 tUl§fŸ Kotilªj Ã‹ò FHªijfS¡F khj« %.150/Åj« 20-MtJ tUl« tiu fšé r«gªj¥g£l bryé‰F tH§f¥gL»wJ.
Ï¤Â£l¤Âid Kfh« thœ Ïy§if jäH®fS¡F éçÎgL¤jyh«.
5. Kfh«thœ Ïy§if jäœ bg©fëš ijaš gæ‰Á bg‰WŸs 3778 ngU¡F
ijaš ÏaªÂu« tH§Fjš Â£l¤Â‹ _y« mt®fë‹ thœthjhu¤ij ca®¤Jtj
‰F r_f ey¤Jiwæš brašgL¤j¥g£L tU»‹w Â£l¤ij éçÎgL¤Â
Ïytrkhf ijaš ÏaªÂu« tH§fyh«. mj‰fhf MF« bryÎ %.1.13/- nfhoahF«.
6.

_tYh® Ïuhkhä®j« m«ikah® ãidÎ ÂUkz cjé Â£l¤Â‹ Ñœ j‰nghJ

Kfh« thœ Ïy§if jäH®fëš jFÂ thŒªj bg©fS¡F %.20,000/- ÂUkz
cjé V‰fdnt tH§f¥gL»wJ. gh®it 1š fhQ« murhizæ‹go Ï¤Â£l¤Â
‰F %,2.20 nfho xJ¡ÑL brŒa¥g£LŸsJ. j‰nghJ gh®it Ïu©oš
murhizfë‹go jäœeh£L k¡fS¡F tH§f¥g£L

fhQ«

tU« ÂUkz cjéia
