---
doc_id: "ac2896abe7dfc9ea"
source_url: "https://fisheries.tn.gov.in/uploads/RTIFeesRules2005.pdf"
ministry: "Fisheries Department, Tamil Nadu"
title: "RTI - Fee Rules,2005"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8a78d66e86b12612"
---

<!-- page 1 -->

Tamil Nadu Right to Information
(Fees) Rules, 2005
(Corrected up to November, 2018)
CONTENTS :

RULE
NO.
1.

Short title

2.

Definitions

3.

Fees

SUBJECT

Tamil Nadu Right to Information
(Fees) Rules, 2005
In exercise of the powers conferred by section 27 of the Right to Information
Act, 2005 (Central Act 22 of 2005), the Governor of Tamil Nadu hereby makes the
following Rules:-

1. These rules may be called the Tamil Nadu Right to Information (Fees)
Rules, 2005.
2. In these Rules, unless the context requires :(a) "Act" means the Right to Information Act, 2005 (Central Act 22 of
2005);
(b) Words and expressions used in these Rules and not defined shall
have the same meaning assigned to them in the Act
3. (a)Every application for obtaining information under sub-section (1) of
section 6 of the Act shall be accompanied by an application fee of rupees ten by
cash or by affixing court fee stamp or by postal money order or by demand draft or
bankers cheque payable in the head of account, as may be specified by the Public
Authority.
(b) For providing the information under sub-section (1) of section 7 of the
Act, fee shall be charged by way of cash against proper receipt or by demand
draft or banker's cheque payable in the head of account, as specified by Public
Authority at the following rates:-

<!-- page 2 -->

/2/
(i)

rupees two for each page (in A-4 or A-3 size paper) created or
copied,

(ii)

actual charge or cost price of a copy in larger size paper.

(iii)

actual cost or price for samples or models; and

(iv)

for inspection of records, no fee for the first hour, and a fee of
rupees five
for every one hour (or fraction thereof)
thereafter.

(c) For providing the information under sub-section (5) of section 7,
the fee shall be charged by way of cash against proper receipt or by demand
draft or banker's cheque payable in the head of account, as specified by the
Public Authority at the following rates:(i)

for information provided in diskette or floppy rupees
fifty per diskette or floppy; and

(ii)

for information provided in printed form at the price fixed
For publication or rupees two per page of
photocopy for extracts from the publication
