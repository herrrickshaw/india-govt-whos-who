---
doc_id: "5dba9d7b41f67edd"
source_url: "https://environment.tn.gov.in/assets/go/e7620bfe0a8bbc9c37fb419c74ae7a58.pdf"
ministry: "Environment and Climate Change Department, Tamil Nadu"
title: "Tamil Nadu Green Climate Company (G.O.No.101)"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c9583f7422eecc4c"
---

<!-- page 1 -->

/6'6*\
,4/HH s-\
/9f i,*IEi $\

\s.E"kti'\Jsl
\[:asfFiilty

"\w*'

ABSTRACT
Environment, Climate Change & Forests - Tamil Nadu Green Climate Company
(TNGCC), a not-for-profit body, under Sec 8 of the Companies Act, 2013 to
implement the three Missions viz., Tamil Nadu Wetlands Mission, Tamil Nadu
Climate Change Mission and Green Tamil Nadu Mission - Setting up -Orders

-

lssued.

ENVIRONMENT,CLIMATE CHANGE AND FORESTS (EC2) DEPARTMENT
G.O.(Ms.) No.101

Dated: 03.11 .2021
r9lanor, gr]u6l-tz

SlCUordr<qporfi qcir@

- 2es2

ORDER:

Hon'ble Finance Minister while presenting the Tamil Nadu Revised Budget for
the year 2021-2022, among others, made the following important announcements: -

(i) "Forests play an important role in conserving natural resources and

ecosystems and preserving environmental balance and normal
rainfall patterns. This Government will launch the Green Tamil Nadu
Mission to increase the total area.under the forest and tree cover in
Tamil Nadu to 33 per cent of the land area of the State. Under the
Mission a massive tree plantation programme of indigenous and
diverse species, in co-ordination with multiple departments, public
and private institutions will be taken up with people's participation

(ii)

(iii)

over 10 years."
Combating and mitigating the impact of climate change is a major
concern for a coastal State like Tamil Nadu" This Government will
launch the Tamil Nadu Climate Change Mission under the Hon'ble
Chief tMinister to focus on climate change adaptation and mitigation
activities with a total outlay of Rs.500 crore"
Under the leadership of the Hon'ble Chief Minister, this Government
will launch the "Tamil Nadu Wetlands Mission with the objective of
ecological restoration of wetlands in Tamil Nadu. The mission will
identify and map 100 wetlands in 5 years and restore the ecological
balance with focus on livelihood options at a cost of Rs.150 crore.

2. The above-mentioned announcements signify the intent of the Government of
Tamil Nadu in conserving and preserving the rich natural heritage of Tamil Nadu.
Given below is a brief on the objectives of each of these Missions:

a) Green Tamil Nadu Mission - Enhance the Forest and Tree cover
from the existing 23.27% to 33% through a meticulously planned tree
planting campaign over a period of 10 years.
...2..

<!-- page 2 -->

-2-

b) Tamil Nadu Wetlands Mission - Ecological restoration of wetlands

in Tamil Nadu in addition to the conservation and management of

wetlands.

c) Tamil Nadu Climate Change Mission

Focus and take action on
climate change adaptation and mitigation activities.

-

3. Climate change is one of the biggest challenges being faced today affecting
people and nature across the globe, with developing countries being most'impactedl
Most countries are becoming vulnerable to climate change with the ipeed at which it

is occurring thereby directly impacting their development path and in turn their

economic growth. Reducing the negative impact caused by climate change is of
utmost priority for countries. This can be achieved by adapting to changes by making
appropriate resilience and mitigation plans combined with suitable adJustments and
opportunities.

3.1 According to United Nations Framework Convention on Climate

Change (UNFCCC), key risks due to climate change are:

(i) Risk of death, injury, ill-health, or disrupted livelihoods
(ii) Systemic risks due to extreme weather events leading to breakdown of
infrastructure networks and critical services
(iii) Risk of mortality and morbidity during periods of extreme heat
(iv) Risk of food insecurity and the breakdown of food systems
(v) Risk of loss of rural livelihoods and income
(vi) Risk of loss of marine and coastal ecosystems
(vii) Risk of loss of terrestrial and inland water ecosystems
The Intergovernmental Panel on Climate Change (IPCC) in its Sixth
Assessment Report has provided a high level summary oflhe understanding of the
current state of the climate and has red flagged several issues relating to blimate
Change.

.

3.2 To mitigate the risks identified by the UNFCCC and in line with the paris
Agreement, efforts have been taken at the national level to reduce national
emissions and adapt to the impacts of climate change. Towards this, lndia has
submitted its Nationally Determined Contribution (NDC) which is as follows:
i. To put forward and further propagate a healthy and sustainable way of
living based on traditions and values of conservation and moderation,

ii' To adopt a climate friendly and a cleaner path than the one followed
hitherto by others at corresponding level of economic development.

iii. To reduce the emissions intensity of its GDP by 33 to 35 percent by 2030
from 2005 level.

iv. To achieve about 40 percerrt cumulative electric power installed capacity
v.

from non-fossil fuel-based energy resources by 2030 with the help oi
transfer of technology and low-cost international finance including from
Green Climate Fund (GCF).
To create an additional carbon sink of 2.5 to 3 billion tonnes of C02
equivalent through additional forest and tree cover by 2030.
. ..3...

<!-- page 3 -->

-3-

vi. To better adapt to climate change by enhancing investments in

development programmes in sectors vulnerable to climate change,
particularly agriculture, water resources, Himalayan region, coastal
regions, health, and disaster management.
vii. To mobilize domestic funds, new & additional funds from developed
countries to implement the above adaptation actions and mitigation in
view of the resource required and the resource gap.
viii. To build capacities, create domestic framework and international
architecture for quick diffusion of cutting-edge climate technology in lndia
and for joint collaborative R&D for such future technologies.

3.3

As the Second largest economy in lndia with 38 districts spread over a
total land area of 1,30,058 sq. km, Tamil Nadu is an important coastal State, with a
coastline of 1,076 km, which is often affected by the vagaries of nature. The Western
Ghats, Deccan Plateau, the Mountain ranges, forests, beaches, mangroves,
estuaries, spanning across the State include a wide range of 'biomes'that are prone
to risks posed by climate changes.

3.4

As a result of climate change, risks such as heat waves, deterioration
in agriculture, damage to infrastructure, droughts, cyclones, unseasonal rains,
floods, damage to nets & boats of fishermen, loss to assets and amenities,
deforestation, land degradation and desertification, cause direct economic impact to
the State. These not only affect the livelihood of people and cause displacement of
households but also impact the ecosystems and biodiversity. lndirect impact of
climate risks cause water borne diseases, malnutrition, loss of assets and amenities,
debt, migration, etc.

3.5

With high dependency on natural resources, Tamil Nadu is under
constant threat of climate change and its negative impact. Events in the past show
that there is a high probability of increase in climate related natural hazards, with
high frequency and intensity, which would result in a potential threat of natural
disasters directly linked to climate change. The sensitivity and vulnerability of the
State calls for State Level Climate Models to be put in place to arrive at sectoral
initiatives, that are not only climate friendly but would also help the State to
effectively plan the growth of the economy by providing an enabling environment.

3.6

Ceased of this, the Government of Tamil Nadu is crafting many
solutions to leapfrog the State to a greener, cleaner and more resilient State. Efforts
are being taken by the State to draft plans that are not merely mitigative in nature,
but which will also pave the way for the transformation of the economy underpinning
'Affordability, Sustainability and Scalability' as the key elements.

3.7

The State proposes to focus on plans based on the following areas of
intervention for successful implementation of the Missions announced in the Revised
Budget

-2021-22:

i. Sustainable Agriculture: Popularize strategies to reduce the losses in
agriculture due to extreme weather. lncrease use of micro-irrigation technologies,
harvest rainwater, strengthen crop insurance programmes, forecast disease
outbreaks and popularize indigenous variety of plants.
...4...

<!-- page 4 -->

-4-

ii. Climate resilience: lncrease productivity of crops, build ecosystems to

manage droughts, create institutional frameworks to combat climate change,
advice
and encourage farmers to adapt to climate change strategies.

iii. Water resources: Adaptation of climate change programmes in water

resources, modernize irrigation, increase water use efficiency.

iv. Forest & biodiversity: Valuation of bio resources in forest ecosystem,
increase the forest. cover through a massive afforestation programme, integrate
development of wildlife habitats, eco restoration and conservatio-n of water bodies

and canopy improvement.

v. Coastal area management: Integrate tree plantation with water

management and livelihood enhancement, assess micro-plastics in coastal areas,
protect shores, manage disasters and risks, manage coastal livelihoods and

encou rage eco-tourism.

vi. Disaster management & mitigation: Deploy big data, State database and
digital risk mapping models to combat risks, strengthen post disaster surveillance
sygJems, response systems, zonal teams and medical responses, create funds
to
mitigate disasters, encourage restoration and protection of eco-systems, map

vulnerable areas etc.

vii. Health: Increase the capacity of primary and secondary healthcare

network by improving the infrastructure of hospitals such as bed strength, laboratory,
radiology facilities etc.

viii. Technology: Provide climate smart strategies like shifting towards

renewable energy, electric vehicles and other innovative climate solutions that would
accelerate preservation of natural habitats, biodiversity, environment protection with
the objective of strengthening the economy by creating new opportunities and
protection for those who are negatively impacted.

ix. Energy Transition: Moving away from fossil fuels, industry transition by
transforming polluting.industries, green indexing of lndustries, green blnch marking,
setting up Green lndustry fora, focusing on mitigation in cities and villages U"y
introducing low emission buildings, masJ transport with focus on resilience Jor the
urban poor etc

x. Emission Reduction: ldentify effective and beneficial ways to achieve
emission reduction by promotion and adaptation of electric vehicles, Lse of natural
gas, incentives for emission reduction for faster adoption of emission reduction
technologies.
xi. Transportation: lntroduce strategies for Clean Vehicle usage such as

hybrid and electric, promote walking and bicycle tracks and other multi-modal

transport systems.

...5...

<!-- page 5 -->

-5-

4.

Above mentioned interventions would be streamlined to formulate

suitable projects to be implemented under the aegis of the three proposed missions.
The focus of the three Missions is outlined below:
4.1. Green Tamil Nadu Mission
Under this Mission, the Government of Tamil Nadu proposes to increase the
Forest and Tree Cover in the State from the present 23.8o/o (as per the lndia State of
Forest Report 2019 of the Forest Survey of lndia, Dehradun) to 33% by the year
2030-2031"

The State would achieve the above through afforestation activities on the
degraded forest landscape (about 4,500 sq.km) and tree planting activities farm
lands, fallow lands, educational institutions, temple lands, sacred groves, industrial
areas, tank foreshore, canal banks and areas under the control of Defense
establishments in Tamil Nadu. This Mission will have the following major activities;

1. Restoring degraded forest areas by undertaking tree planting and soil
moistu re conservation efforts
2. Planting tree species in farm lands with suitable agri-silviculture model

3. Planting in public lands like community lands, tank foreshore, fallow lands,
avenues, canal banks, through people's movement
4"1(a) Restoration of Degraded Forest Land.

Forest loss and degradation exacerbate local and global problems related to food
and livelihoods, clean water, fresh air and the climate. Degraded landscapes are
also more vulnerable to natural disasters and extreme weather conditions, such as
heavy rainfall, floods and landslides. Forest Land Restoration has great potential to
address these issues by enhancing landscapes in ways that ensure lasting benefits.
Benefits include better local climate regulations, improved flood and erosion control,
an increased variety and availability of food and non-food products and economic
opportunities for local people. Reducing emissions from deforestation and
degradation in the forest areas is yet another challenge in combating the adverse
impact of the Climate Change on biodiversity conservation and protection. Forest
land restoration can support climate change mitigation and adaptation, while
enhancing ecological and livelihood values for the landscape and its people.
The forest cover of the State as per the ISFR 2019 has sequestrated 216 Million
tonnes (Mt) of carbon which is 3.03% of the total carbon stock of 7,124 Mt stored in
lndia's forest cover. Therefore, through the Green Tamil Nadu Mission, the State of

Tamil Nadu has proposed to enhance the carbon sequestration potential on an
average of 8 Mt every year from the year 2024-2025 to 2030-2031 by increasing the
forest & tree cover. lt is expected that the carbon stock can be built up to about 265 270 Mt, in the year 2031 from a base year of 2019. The improvement of forest and
other resources throughforest land restoration processes can also reduce disaster
risks such as floods, droughts landslides or outbreaks of pests.
...6. "

"

<!-- page 6 -->

-6-

4.1(b) Agri-silviculture
a viable solution to enhance the green cover
and economic sustainability of the farmers.

-

Trees outside Forests plays an important role in climate change adaptation
through diversified land-use practices improving the sources of income and for
providing the buffering against weather related production losses, besides resilience
building against climate impacts in farming systems. Due to enhanced focus on the
Biodiversity Conservation and Management the "Trees outside Forests" in the form
of Agroforestry have to play a significant role in meeting out the pulp, plywood,
matchwood, dendro-biomass, requirements for the rural & urban populatibn, for
reducing deforestation and forest land degradation in future. Under this componeni,
farmers will be given quality planting materials of agro-forestry species to get
additional revenue.
a.1@) Increasing green cover on public tands

The Green Tamil Nadu Mission aims to increase green cover on public land in
period
a
of 10 years i.e., from 2020-2021 to2030-2031 on farmlands, fallow lands,

Educational lnstitutions, temple lands, sacred groves, lndustrial areas, tank
foreshore, padugai areas and areas under the contiol of Defence establishments in
Tamil Nadu. A special drive will be initiated under this Mission to increase the green
cover in public lands to the optimum level.
4.2. Tamil Nadu Climate Ghange Mission

ln line with the National Action Plan on Climate Change (NAPCC), the Tamil
Nadu State Action PIan on Climate Change (TNSAPCC) 2015-2020, was prepared
and endorsed by
Ministry of Environment, Forests and Climate Change
(MoEF&CC), Government of lndia (Gol) on 31.03.2015, defining the following sev6n
vulnerable sectors viz.,

the

. Sustainable Agriculture
2. Water Resources
3, Forests & Biodiversity
4. Coastal Area Management
5. Enhanced Energy Efficiency & Solar Mission
6. Sustainable Habitat
7. Knowledge Management
'1

Tamil Nadu State Action Plan on Climate Change 2.0 (TNSAPCC 2.0) is
under preparation with the focus on Disaster Management and Mitigation, Health,
Sustainable Development Goals and Composite Vulnerability lnlex (CVl) for
the State.
ln view of above, the Government of Tamil Nadu shall launch the Tamil Nadu
Climate Change Mission with the objective of implementing several proven strategies
in the field of Climate Change. The primary aim of the Misiion is to prepare a holistic
Climate Change Policy for Tamil Nadu incorporating policies for non-conventional
alternative sources of energy, new technologies suCh as electric or plug-in hybrid
cars, energy-efficient homes. Efforts will also be taken to implement projects with
funding under National Adaptation Fund for Climate Change (NAFCi), Green
Climate Fund (GCF) etc.
...7 ...

<!-- page 7 -->

-7-

The Mission would also promote strategies for ensuring cleaner air quality by
use of efficient public transport systems, wide-spread acceptance of CNG and
alternate fuel resources and suggest measures for mitigation of Green House
Gases.

The Mission would strive to create smarter infrastructure systems, to handle
natural disasters and recover from it. Another important focus of the Mission would
be to emphasize on gender mainstreaming in the climate related projects,
encouraging multi-disciplinary research on public health emphasizing on pandemics
and provide guidance on developing various courses and curricula in Educational
lnstitutions.
4.3. Tamil Nadu Wetlands Mission

Currently wetlands are receiving global attention due to recognition of the
several ecosystem services provided by them, driving the need for protecting,
restoring and conserving them, as they are shrinking and getting degraded.
Wetlands are inundated with water permanently or seasonally and are unique, highly
productive ecosystems where terrestrial and aquatic habitats meet. Wetlands include
mangroves, peatlands and marshes, rivers and lakes, deltas, floodplains and flooded
forests, rice-fields, and even coral reefs. They play a critical role in maintaining many
natural cycles and supporting a wide range of biodiversity. They serve as a natural
sponge against flooding and drought, protect our coastlines and help to fight climate
change" Bursting with biodiversity, wetlands arc a vital means of storing carbon.

The Ramsar Convention, an international intergovernmental treaty for
conservation of wetlands, ratified by Government of lndia in 1982, facilitates
designating wetlands of importance as Ramsar Sites. lndia is a party to this
Convention, which provides a framework for national action and international
cooperation for the sole mission of conservation and wise use of wetlands and their
resources. ln lndia, currently, 42 wetlands, with a surface area of over a million
hectares are designated as wetlands of international importance under the Ramsar
Convention.

ln Tamil Nadu, major threats to the wetlands is over-exploitation leading to
loss of ecological balance, loss of habitat for flora and fauna, soil and water salinity
along coastal wetlands, spread of invasive species and scarcity of fresh water. ln
addition, coastal wetlands bear the brunt of intense cyclones. ln many wetlands,
studies show that the water quality was unsafe for avifauna to feed and breed. Apart
from these, wide range of problems are associated with wetlands by virtue of being
fragile and vulnerable ecosystems. Further, wetlands have been extinguished at an
alarming pace with the relentless progress of industrial processes, intensive
agricultural practices etc. Practical solutions are required for the recovery of lost or
severely damaged wetland ecosystems.

Under the Tamil Nadu Wetlands Mission announced in the Revised Budget
2021-22, it is proposed to prepare an lntegrated Management Plan and undertake
ecological restoration of wetlands through a purely participatory process involving
local communities as well as all relevant stakeholders, which would be inventorized
through digital technologies.
...8. .

.

<!-- page 8 -->

-B-

5. Tamil Nadu Green Climate Company
The three important Missions announced in the Revised Budget ZO21-22,
shall be implemented within a defined time frame to achieve their underlying
objectives. lt is, therefore, critical to set out a well-defined mechanism for effiiient
implementation of these Missions to achieve desired goals.

While these Missions shall be implemented through the Department of
Environment, Climate Change and Forests, it is equally important to involve and
include the academia, private sectors and societies foi transitioning the State to

chmate friendly platforms, championing renewable energy, sustainable and resilient
infrastructure, agriculture, management and protection of forests, resilience and
adaptation to climate impacts.
Considering_
lhe above objectives the Government shall set up a new Special
Purpose vehicle (sPV), viz., "Tamil Nadu Green climate company (TNGcc);,.

6. The important objectives of the proposed Tamil Nadu Green Climate Company
are as below:

i) Planning, execution and monitoring of the State-wide Programme for the
climate change adaptation and mitigation, weflands mapping and

restoration, enhancing the forest and tree cover of the State to 33% over
the next ten years.

ii) Creating strong policy support for climate change, cutting across all
sectors of governance.

iii) Devise strategies to reduce greenhouse gas emissions, bench marking

of industries to move towards green manufacturing etc.,
iv) Promote eco-friendly technologies towards a sustainable future e.g.,

solar and wind harvesting technologies, biodegradable packaging, evehicles etc.
Develop collaborations and strengthen community engagement to build
long term commitment for a Net Zero Carbon future forlamil Nadu.
vi) Promote multi stakeholder approach to fast-track climate change action
in a synergized fashion.
vii) Use proven climate change science & technologies to create evidence
based green models for emulation and adaptation.
viii) Educate and empower local communities in management of climate
change at ground zero.
ix) Promote successful climate change adaptation and mitigation models for
replication.
Build standards for energy efficient infrastructure to save precious energy
and reduce energy consumption.
xi) create practical models for green mobirity to reduce missions.
xii) Create State-ofthe-Art monitoring mechanism for better compliance of
Environmental Standards through transparent and credible systems.
xiii) Conserve and preserve natural resources and promote their sustainable
use.
xiv) Creating a framework to bring synergy among the line Departments of
the State for initiatives for environment protection.

v)

x)

...9..

.

<!-- page 9 -->

-9-

xv) Creating a platform for integration of knowledge and experience of
National and lnternational agencies through collaboration and
partnership.
xvi) Developing a framework for capacity building of various stakeholders
(Line Departments, lnstitution Universities, Researchers, Experts,
Non-Government Organizations (NGOs) on Climate Change Adaptation
and Mitigation, wetlands, tree plantation, eco restoration etc.
7. The Tamil Nadu Green Climate Company shall setup a specialized Project
Management Unit (PMU) for coordinating and monitoring of project activities under
all the three Missions in partnership with the Tamil Nadu lnfrastructure Fund
Management Corporation Limited(TNIFMC).

/

7 "1 The composition

of the Board of the Tamil Nadu Green Climate

Company will be as follows:1"

Secretary, Environment, Climate Change and Forest
Department - Chairperson and Managing Director

2.

Secretary, Finance Department or his nominee

3.

Secretary, Energy Department

4.

Secretary, Municipal Administration and Water Supply
Department

5.

Secretary, Agriculture

and

Farmers Welfare

Department
6.

Secretary, Public Works

and Water Resources

Department
7.

Principal Chief Conservator
Forest Department

of Forests, Tamil Nadu

7.2. The Funding and shareholding pattern of the Company immediately
upon closing shall be set forth as below:

(in Rs. crores)

Shareholder

Equity

% Equity

Holding
Government of Tamil Nadu.

2.55

51

Agencies, Boards, Other Statutory
Organizations such as Tamil Nadu
Pollution Control Board

2.45

49

5.00

100

Total

The Authorised Capital of the Company shall be Rs. 5,00,00,000/(Rupees Five Crores only).
... 10...

<!-- page 10 -->

-1 0-

8. The Government accord perrnission to set up the Tamil Nadu Green

climate Gompany (TNGcc), under section B of the companies Act, 201g,

to implement the three key Missions of the Government of Tamil Nadu viz,

The Tamil Nadu Climate Change Mission, The Green Tamil Nadu Mission and the
Tamil Nadu Wetlands Mission.

9. This order issued with the concurrence of Finance Department vide its

U.O.No3337lFSlP12021 , dated 20.10.2021

.

(BY ORDER OF THE GOVERNOR)
SUPRIYA SAHU
PRINCIPAL SECRETARY TO GOVERNMENT
To
The Additional Chief Secretary to Government,
Finance Department, Secretariat, Chennai-g.
The Additional Chief Seicretary to Government,
Public Works Department, Secretariat, Chennai-g.
The Additional Chief Secretary to Government,
MunicipalAdministration and Water Supply Department, Secretariat, Chennai-g.
The Principal Secretary to Government,
Energy Department, Secretariat, Chennai -g.
The Secretary to Government,
Agriculture and Farmers welfare Department, secretariat, chennai-g.
Principal Chief Conservator of Forests,(Head of the Department) Chennai-15.
Principal Chief Conservator of Forests and Chief Wildlife Warden,Chennai-15.
Director of Environment, Chennai-1 S.
The chairman, Tamil Nadu Pollution control Board, chennai-32.
Additional Principal chief conservator of Forests iMember secretary,
Tamil Nadu State Wetland Authority, Chennai-i5.
The Accountant General, Chennai-1 8.

copv to:The Private secretary to Secretary lV to Hon'ble chief Minister,
The Hon'ble Chief Minister's Office, Chennai -g.
The Special/Senior Personal Assistant to the Hon'ble Minister(Forests), Chennai-g.
The Special/Senior Personal Assistant to the Hon'ble Minister for Environment,
climate change and Youth welfare and sports Development, chennai- 9.
The Private Secretary to Principal Secretary to Government,
Environment, climate change and Forest Department, chennai-g.
The Private secretary to special Secretary (Environment, climate Change),
Environment, climate change and Forest Department, chennai-g.
The Private secretary to Additional chief secretary to Government,
Finance Department, Chennai-9.
Finance (AHD&F/BPE) Department, Chennai-g
Environment, Climate Change and Forest (FR.6,FR.7, FR.g and EC.1)Department,
Secretariat, Chennai -9.
Stock File i Spare Copy.
//FoRWARDED By

oRDEW
>7,N0s\\gqF

JOI NT SECRETARY TdGOVERNMENT
