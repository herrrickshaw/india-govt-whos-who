---
doc_id: "9ffcdfb8bc7d396c"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 139
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fd209079c1a9b4f2"
---

<!-- page 1 -->

INFORMATION TECHNOLOGY
DEPARTMENT

DEMAND No. 31

T. MANO THANGARAJ
Minister for Information Technology

Printed by Govt. Central Press, Chennai - 600 001.

©
Government of Tamil Nadu
2021

<!-- page 2 -->

INFORMATION TECHNOLOGY
DEPARTMENT
DEMAND No. – 31
POLICY NOTE – 2021-2022
INDEX

Contents

Page
No.

I

INTRODUCTION

1-7

II

ELECTRONICS
CORPORATION OF
TAMIL NADU LIMITED
(ELCOT)

8-39

1

Introduction

2

Activities

8-39

2.1

IT Promotion and
Development

8-12

2.2

ELCOT Special Economic
Zones (ELCOSEZs)

13-26

Chapter

8

i

<!-- page 3 -->

2.2.1
2.2.2

ELCOSEZ Sholinganallur, Chennai
ELCOSEZ - Vilankurichi,
Coimbatore

13-14
15-16

2.2.3

ELCOSEZ Ilandhaikulam, Madurai

16-18

2.2.4

ELCOSEZ – Vadapalanji,
Madurai

18-20

2.2.5

2.2.6

ELCOSEZ-Navalpattu,
Tiruchirappalli
ELCOSEZGangaikondan,

20-22

22-23

Tirunelveli
2.2.7

ELCOSEZJagirammapalayam,

23-25

Salem
2.2.8

ELCOSEZViswanathapuram, Hosur

25-26

2.3

Start-up Warehouse

26-27

2.4

FinBlue - Centre of
Excellence (CoE) in
FinTech

27

ii

<!-- page 4 -->

2.5

IT-Infrastructure

27-35

2.5.1

Connectivity Services

28-30

2.5.1.1

Tamil Nadu State Wide
Area Network (TNSWAN)

28-29

2.5.1.1.1

TNSWAN Phase 2
Extension

29

2.5.1.2

Other Connectivity
Services

30

MPLS VPN Connectivity

30

2.5.1.2.1
2.5.1.2.2
2.5.1.2.3

Internet Leased Line
Connectivity
VPNoBB Connectivity

30
30

2.5.2

Hosting and Allied
Services

2.5.2.1

Tamil Nadu State Data
Centre-1 (TNSDC-1)

31

2.5.2.2

Tamil Nadu State Data
Centre-2 (TNSDC-2)

32

iii

31-33

<!-- page 5 -->

2.5.2.3

Tamil Nadu Disaster
Recovery Centre
(TNDRC)

32-33

2.5.2.4

Thamizh Megam - TN
Cloud Computing
Services

33

2.5.3

e – Security

2.5.3.1

Security Architecture for
TNSDC

2.5.3.2

Cyber Security
Architecture for
Tamil Nadu (CSA-TN)

34-35

2.6

Open Government Data

35

2.7

Aadhaar Permanent
Enrolment Centres
(PECs)

35-36

2.8

Capacity Building

36-37

2.9

Network Services

37

2.10

Procurement Services

34-35

iv

34

38-39

<!-- page 6 -->

III

DIRECTORATE OF
e- GOVERNANCE AND
TAMIL NADU
e-GOVERNANCE
AGENCY (TNeGA)

1

Introduction

40

2

Objectives

40-41

3

Technical Units

42-45

3.1

Information Technology
(IT) Cadre

42

3.2

State e-Mission Team
(SeMT)

42

3.3

Centre of Excellence in
Emerging Technologies
(CEET)

42-45

3.4

District e-Governance
Societies (DeGS)

45

4

Data Driven Governance

45-48

4.1

CM Decision Support
System

45-46

v

40-88

<!-- page 7 -->

4.2

State Family Database
(SFDB)

46-47

4.3

Tamil Nadu Geographical
Information System
(TNGIS)

47-48

5

Sustainable
Development Goals
(SDGs)

48-49

6

Government to Citizen
(G2C) services

49-71

6.1

Common Service Centres
(CSCs)

49-69

6.2

Aadhaar Permanent
Enrolment Centres

69-71

7

Ungal Thoguthiyil
Muthalamaichar (UTM)
and CM's Helpline (1100)

71-72

8

Proactive Governance

72-73

8.1

Proactive Service Delivery

72-73

9

Emerging Technologies

73-77

vi

<!-- page 8 -->

9.1

e-Paarvai : AI based
Cataract Detection
System

9.2

Face Recognition System
(FRS)

74-75

9.3

Tamil Nadu Blockchain
Backbone–
NambikkaiInaiyam

75-76

9.4

Digital Infrastructure for
Paperless e-Governance

76-77

9.4.1

e-Mail account for TN
Government Employees

76

9.4.2

e-Office

10

Capacity Building

11

Namadhu Arasu (MyGov)

12

Standardization of
Government Websites

13

Exam as a Service (EaaS)

73

76-77

vii

77
77-78
78
78-79

<!-- page 9 -->

14

IT Security Audit

15

Software Applications for
Government Departments

80-88

IV

TAMIL NADU ARASU
CABLE TV
CORPORATION
LIMITED (TACTV)

89-91

1

Introduction

89

2

Objectives

89-90

3

Arasu e-Sevai Centres

90-91

4

Aadhaar Permanent
Enrolment Centres
(PECs)

91

V

TAMIL NADU
FIBRENET
CORPORATION
LIMITED (TANFINET)

92-95

1

BharatNet

93-94

2

TamilNet

94

viii

79

<!-- page 10 -->

3

Benefits of BharatNet
Project

VI

TAMIL VIRTUAL
ACADEMY (TVA)

1

Introduction

96

2

Objectives

96-97

3

Academic Programmes

97-99

4

Tamil Digital Library

99-100

5

Tamilar
Tagavalaatruppadai

100-101

6

e-Asiriyar Project

101

7

Tamil Computing

102

8

Tamil Unicode

102

9

Outreach Initiatives

103

9.1

Kani Tamil Peravai (KTP)

103

ix

95
96-105

<!-- page 11 -->

9.2

Translation of Khan
Academy’s Educational
Videos

103

10

Monthly Lecture Series

104

11

Conferences and
Webinars

11.1

Online Faculty
Development Programme

104

11.2

International Webinar on
Technologies in Tamil
Language

105

11.3

Elocution Competition

105

11.4

International Conference
in Tamil Computing

105

VII

ICT ACADEMY OF
TAMIL NADU (ICTACT)

106-112

1

Introduction

106-107

2

Activities of ICTACT

107-112

2.1

Faculty Development

107

x

104-105

<!-- page 12 -->

2.2

Skill Development

107

2.3

Entrepreneurship
Development

108

2.4

Youth Empowerment

108-109

2.5

Research and
Publications

109-110

2.6

Digital Empowerment

110

2.7

Global Technology Forum

111

2.8

Sky Campus – Digital
Knowledge Webinar
Series for Educators

112

8

Conclusion

113-114

xi

<!-- page 13 -->

CHAPTER-I
1. INTRODUCTION
Tamil Nadu is rapidly emerging as a
power to reckon with in software industry. It
is already a leader in Software as a Service
(SaaS) and software exports due to its
inherent

advantages.

vibrant

academic

technical
robust

These

eco-system,

manpower,
connectivity,

include,

excellent

strategic
besides

a

location,

a

thriving

manufacturing eco-system. Large pool of
skilled manpower with lower attrition rates
coupled

with

cost

advantage

drive

its

competitive edge. The process of digitization
of

economy

and

adoption

of

digital

transactions has rapidly increased due to
constraints

on

physical

movements

on

account of COVID-19. These developments
present host of opportunities for the state.

1

<!-- page 14 -->

.
—
It means “to bring innovation from
countries in all four directions and work for
the growth of the Nation.”
Bharathiyar

said

this

addressing

women, but this holds true even otherwise
as we need to conquer Emerging and Deep
Technologies for creating growth and jobs.
These include Artificial Intelligence (AI), Data
Analytics,
(NLP),

Natural

Language

Processing

Augmented

Reality

(AR)/Virtual

Reality (VR), Drone Technology, Blockchain,
5G/6G Networks, Cyber Security, Quantum
Computing,

Autonomous

Cryptography,

Internet
2

of

Vehicles,
Things

(IoT)

<!-- page 15 -->

amongst others. These technologies will form
the basis of the growth of nation states in
the next decade, impart strategic advantage,
and create economic wealth and jobs.
The

Government

has

already

established a center of excellence focusing
on Artificial Intelligence, Blockchain, Data
Analytics

and

IoT.

This

is

helping

the

Government to adopt the technologies in
various

verticals

such

as

Healthcare,

Agriculture and Education. e-Paarvai, an AI
based cataract detection tool on mobile, has
recently won an award from NASSCOM for its
scalability.
Blockchain
developed
immutable

NambikkaiInaiyam,
based
for

the

and

platform,
state

to

verifiable

is

a
being

provide

an

information

platform for critical Government applications.

3

<!-- page 16 -->

As

Tamil

Nadu

economy

matures

further, the services sector will also grow
rapidly

driven

by

proliferation

of

new

products and services. This will primarily be
enabled

by

Information

Technology.

Simultaneously, entrepreneurial eco-system
in Tamil Nadu is also growing rapidly across
sectors

such

Education,

as

Healthcare,

Engineering,

Tourism,

Communications,

Transportation, Banking and FinTech through
innovations, again enabled by Information
Technology.
The state is taking efforts to kick-start
the

entrepreneurial

activity

focusing

on

Emerging Technologies. This will promote a
socially inclusive and broad-based growth
and help us achieve leadership position in
the ICT industry in the country. Tamil Nadu
is a rich source of talented human capital.
Global Capability Centres (GCCs) that thrive

4

<!-- page 17 -->

on human capital

also

present a great

opportunity for Tamil Nadu to improve its
strategic capability and move up the value
chain. Our state is well poised to capture
these opportunities and IT department shall
take all efforts to attract these companies to
Tamil Nadu.
The

state

is

improving

the

digital

infrastructure through promotion of Data
Centres and digital connectivity to the last
mile. Chennai is emerging as a Data Centre
Hub, thanks to its locational advantage,
excellent connectivity, stable and surplus
power. The prestigious BharatNet project will
connect all 12,525 village panchayats of the
state with a minimum of 1 Gbps high-speed
bandwidth using Optical Fibre Cable (OFC)
and provide triple play services to rural areas
at affordable cost.

5

<!-- page 18 -->

Tamil Nadu has been a trendsetter in
Good Governance. Information Technology is
enabling Government to listen to its citizens
and respond to their needs. Integrated and
Inclusive

Public

Management

Grievance

System

CM

Helpline

(IIPGCMS)

enables

citizens to register their petitions through
multiple channels. It has also helped in
resolving the grievances received under the
“Ungal Thoguthiyil Muthalamaichar (UTM)”
scheme.
Tamil

Nadu

aims

to

transform

governance to provide paperless, contactless
and transparent services to its citizens. The
eventual aim is to bring a paradigm change
from

focus

on

achieving

“Outputs”

to

“Outcomes” and move from “Reactive” to
“Proactive” Governance.

6

<!-- page 19 -->

Technology is merely a means to an
end. Tamil Nadu will deploy Information
Technology to make the lives of citizens
better

by

providing

SMART

(Swift,

Monitorable,

Accessible,

Responsive

and

Transparent) governance. The growth in IT
investments will propel economic growth and
prosperity.

7

<!-- page 20 -->

CHAPTER-II
ELECTRONICS CORPORATION OF
TAMIL NADU LIMITED (ELCOT)
1. INTRODUCTION
Electronics Corporation of Tamil Nadu
(ELCOT) Ltd.,

registered under Companies

Act, 1956 on 21.03.1977, is a wholly owned
Public Sector Undertaking of the Government
of Tamil Nadu constituted with the objective
of promoting electronics in the state. It has
also

played

a

pioneering

role

in

the

development of electronics sector, IT/ITeS
products / services and IT-Infrastructure in
the state.
2. ACTIVITIES
2.1 IT Promotion and Development
ELCOT has been playing a vital role to
make the state as destination of choice for

8

<!-- page 21 -->

Information Technology (IT) and Information
Technology

enabled

Service

(ITeS)

companies. This has led to investments in its
IT parks and sustained creation of the
Information Technology infrastructure. This
has accelerated the growth of IT and ITeS
sector in Tamil Nadu and this in turn had led
to

creation

of

enormous

employment

opportunities in Tamil Nadu.
ELCOT
Investment

has

a

critical

promotion,

IT

role

in

IT

infrastructure

creation and skill development. ELCOT has
contributed to the development of IT sector
in several ways. Its activities include:
•

Creation of 8 IT Special Economic Zones
(SEZs) in Chennai and in Tier-II Cities of
the state viz., Coimbatore, Madurai,
Tiruchirappalli, Salem, Tirunelveli and
Hosur.

9

<!-- page 22 -->

•

Creation of ELCOSEZs in 1588.16 acres
of land (1321.61 acres in SEZ and
266.55 acres in non-SEZ space) at an
investment of Rs.745 crore.
ELCOSEZs have enabled local firms to
integrate with global value chains and
have made significant contribution to
the

overall

growth

of

exports,

investment and employment generation
in IT/ITeS sector in the state. IT/ITeS
exports from ELCOSEZs are estimated
for the year 2020-21 at Rs.23,590 crore
and have generated direct employment
for

approximately

90,000

persons.

ELCOT will also continue to strive to
promote

electronic

through

EMC

2.0

manufacturing
(Electronics

Manufacturing Clusters) scheme.

10

<!-- page 23 -->

•

Promotional activities of Tamil Nadu as
the

best

investment

destination

for

IT/ITeS:
 Electronics Industries Association of

India

(ELCINA)

Source

India

–

Electronics Supply Chain event held
during 9th to 10th September 2020.
 Global “Yaathum Oorae” Conclave-

cum-Expo held during 29th to 31st
October 2020.
 TiE Global Summit – conference and

exhibition virtually conducted on 2nd
and 3rd September 2020 at USA.
 TiE Global Summit – Entrepreneurship

360°

held

during

8th

to

10th

December 2020.
 CII Connect series held at Chennai

from 15th to 19th September 2020, at

11

<!-- page 24 -->

Hosur on 18th December 2020 and at
Tirunelveli on 22nd December 2020.


National FinTech Event – FinTERACT
held during 27th to 29th January
2021.

 Indo-French

Investment

Conclave

Tamil Nadu -3rd edition organized by
Indo-French Chamber of Commerce
and

Industry (IFCCI) held during

11th to 12th February 2021.
•

Certification Authority under the ICT
Policy

2018

development
availing

for
of

extra

the
IT

purpose

parks

FSI

and

from

of
for
the

CMDA/DTCP.
•

Follow up of investments that were
brought to Tamil Nadu in the Global
Investors Meet (GIM).

12

<!-- page 25 -->

2.2

ELCOT Special
(ELCOSEZs)

Economic

Zones

2.2.1 ELCOSEZ- Sholinganallur, Chennai
In

Sholinganallur,

Chennai,

it

has

established an ELCOSEZ in an extent of
377.08 acres at an investment of Rs.228
crore. It has created necessary common
infrastructure and an administrative building
measuring 6,358 sq.ft.
In this ELCOSEZ, land has been leased
to the following companies:
S.
No.

Company

Land
(in acres)

1

Wipro Ltd.

80

2

HCL Pvt. Ltd.

50

3

Tech Mahindra Pvt. Ltd.

50

4

Ford Motors Pvt. Ltd.

28

5

Cognizant Technology
Solutions Pvt. Ltd.

20

13

<!-- page 26 -->

6

Sutherland Global
Services Ltd.

7

Tamil Nadu Electricity
Board
These

companies

15

have

facilities

in

a

built-up

109.31

lakh

sq.ft

and

employment

for

16
established
space

of

have

created

approximately

67,000

persons. The private companies above are in
Software

Development,

Maintenance

and

Testing, Consulting and Business Process
Outsourcing.
To meet the growing demand of quality
IT space for export oriented MSMEs and
other IT/ITeS companies in Chennai, the
construction of 2.33 lakh sq.ft Information
Technology tower at an estimated cost of
Rs.88.21 crore is in progress.

14

<!-- page 27 -->

2.2.2 ELCOSEZ- Vilankurichi, Coimbatore
In Coimbatore at Vilankurichi, it has
established an ELCOSEZ in 62 acres of land
at an investment of Rs.167 crore. ELCOT has
created

necessary

common

infrastructure

and constructed an administrative building
measuring 3,524 sq.ft.
In this ELCOSEZ, land has been leased
to the following companies:
S.No

Land
(in acres)

Company

1

WIPRO Ltd.

9.5

2

Tidel Park
Coimbatore Ltd.

9.5

These Companies have created their
facilities

by

constructing

23

lakh

sq.ft

IT building and provided employment for
13,200 persons.

15

<!-- page 28 -->

The construction of 2.66 lakh sq.ft
Information

Technology

Tower

at

an

estimated cost of Rs.114.16 crore is under
progress.
2.2.3

ELCOSEZ - Ilandhaikulam,
Madurai
In Madurai at Ilandhaikulam, it has

established an ELCOSEZ in 28.91 acres of
land at an investment of Rs.34 crore. ELCOT
has

created

infrastructure

necessary

and

has

administrative-cum-IT

common

constructed

building

an

measuring

60,205 sq.ft.
In this ELCOSEZ, land has been leased
to the following companies:
S.No

Company

1

Honeywell
Technologies Ltd.

16

Land
(in acres)
11.25

<!-- page 29 -->

2

HCL Info System Ltd.

6.75

3

Chella Software Pvt. Ltd.

2.25

4

Tamil Nadu Electricity
Board

0.58

In addition, 6000 sq.ft land has been
leased to Rebar Design & Detail Pvt. Ltd.
These private companies have created
their facilities by constructing 7.22 lakh sq.ft
IT space in this ELCOSEZ.
In the administrative-cum-IT building,
space has been allotted to the following
companies:
S.
No.

Company

Space
(in sq.ft.)

1

Galaxy Infotech

2,508

2

AMBC Technologies
Pvt. Ltd.

3,277

17

<!-- page 30 -->

3

Sai BPO Services Ltd.

15,181

4

Neeyamo Enterprises
Solutions Private Ltd.

30,103

5

CVIAC Consulting

9,136

These companies are into consulting,
application development, business process
outsourcing and digitization of data and are
providing

employment

to

around

7,200

employees.
2.2.4

ELCOSEZ – Vadapalanji, Madurai
In Madurai at Vadapalanji, ELCOT has

established an ELCOSEZ in 245.17 acres of
land at an investment of Rs.70 crore. It has
completed the common infrastructure in this
ELCOSEZ, including a road over bridge. It
has also constructed an administrative-cumIT building measuring 70,139 sq.ft.

18

<!-- page 31 -->

In this ELCOSEZ, it has leased land to
the following companies:

S.No

Company

Land
(in acres)

1

HCL

60

2

Chain-sys
Software
Exports Pvt. Ltd.

20

Pinnacle Infotech
Solutions.

10

3

In the IT Building, 59,166 sq.ft space
has been allotted to the following companies:
S.
No.

Company

Space
(in sq.ft.)

1

Neeyamo
Enterprise
Solutions Pvt. Ltd

46,968

2

Neeyamo
Works
Technologies Pvt. Ltd

11,543

3

Chain-sys
Software
Exports Pvt. Ltd.

655

19

<!-- page 32 -->

These companies are into consulting,
payroll processing and digitization of data.
2.2.5

ELCOSEZ - Navalpattu,
Tiruchirappalli
In Tiruchirappalli at Navalpattu, it has

established an ELCOSEZ in 147.61 acres with
SEZ area of 123.23 acres at an investment of
Rs.60

crore.

It

has

created

necessary

common infrastructure and has constructed
an administrative-cum-IT building measuring
59,960 sq.ft.
In this ELCOSEZ, 2 acres of land has
been allotted to iLink Multitech Solutions Pvt.
Ltd.
In the IT building, 59,960 sq.ft space is
allotted to the following companies:

20

<!-- page 33 -->

S.
No

Space
(in sq.ft)

Company

1

iLink Systems Pvt. Ltd.

6,668

2

Scientific Publishing
Company

30,250

3

Vuram Technology
Solutions Pvt. Ltd.

5,976

4

Vdart Technologies

3,643

5

Disaster Recovery Centre

5,963

6

GI Tech Gaming Co. India
Pvt. Ltd.

4,919

7

VR Della IT Services Pvt.
Ltd.

2,541

These companies are into e-Publishing,
software

development,

management
gaming

services

software

business
and

process

solutions

development

and

and
are

functioning with 1390 employees. The IT
space has been fully allotted.

21

<!-- page 34 -->

The construction of 1.16 lakh sq.ft
IT Tower is in progress at an estimated cost
of Rs.48.10 crore.
2.2.6

ELCOSEZ- Gangaikondan,
Tirunelveli
In Tirunelveli at Gangaikondan, ELCOT

has established an ELCOSEZ in 500 acres of
land with an extent of SEZ of 290 acres at an
investment of Rs.55 crore.
ELCOT has created necessary common
infrastructure

and

has

administrative-cum-IT

constructed

building

an

measuring

56,720 sq.ft. In the IT building, 5,994 sq.ft
space is allotted to Caliber Interconnect
Solutions Pvt. Ltd.
In this ELCOSEZ, 100 acres of land has
been allotted to Syntel International Pvt. Ltd.
It

has

constructed

22

2.60

lakh

sq.ft

<!-- page 35 -->

IT building and is operating with around 200
employees and providing software services.
2.2.7
In

ELCOSEZ
Salem

-

Jagirammapalayam,

Salem

at

Jagirammapalayam,

ELCOT has established an ELCOSEZ at a total
extent of 53.33 acres at an investment of
Rs.44 crore.
It

has

infrastructure

created
and

necessary

has

administrative-cum-IT

common

constructed

building

an

measuring

62,174 sq.ft.
In this ELCOSEZ, 27.87 acres of land
has been leased to the following companies:
S.
No.

Company

1

Mahima Technologies
Pvt. Ltd.

2

Vee Technologies

23

Land
(in acres)
3
9.49

<!-- page 36 -->

3

TANTRANSCO Ltd.

7.88

4

e-Mudhra Ltd.

2.5

5

Anmol Technologies Pvt.
Ltd.

1

6

FocusR Consultancy and
Technologies Pvt. Ltd.

1

7

Nuratech Consultancy
Services Pvt. Ltd.

3

In the ELCOT IT building, 37,958 sq.ft
space is allotted to the following companies :
S.
No.

Company

Space
(in Sq.ft.)

1

e-Mudhra Ltd.

2,989

2

Reveille Technologies Pvt.
Ltd.

3,704

3

Nuratech Consultancy
Services Pvt. Ltd.

3,704

4

Dilogy Solutions LLP

1,000

24

<!-- page 37 -->

5

Knowledge Lens Pvt. Ltd.

1,000

6

StinSoft Technologies Pvt.
Ltd.

989

7

Vee Technologies Pvt. Ltd.

10,562

8

Vee Imaging Solutions
Pvt. Ltd.

10,562

9

Mahima Technology Pvt.
Ltd.

3,448

These companies are operating with
approximately 614 employees.
2.2.8

ELCOSEZ-Viswanathapuram,
Hosur
In

Viswanathapuram

ELCOSEZ

has

been

at

Hosur,

an

established

in

174.47 acres of land at an investment of
Rs.85 crore.
ELCOT has created necessary common
infrastructure

and

has

25

constructed

an

<!-- page 38 -->

administrative-cum-IT

building

measuring

62,100 sq.ft.
In the IT building, 44,589 sq.ft space
has been allotted to the following companies:
S.

Space
(in sq.ft.)

Company

No
1

US Technology
International Pvt. Ltd.

21,100

2

Chandusoft Technologies
Pvt. Ltd.

10,550

3

Thendral Infotech

2,989

4

Eminentlabs Software

9,950

Pvt. Ltd.
2.3 Start-up Warehouse
ELCOT along with NASSCOM as its
knowledge

partner

has

established

a

Start-up Warehouse in 6,860 sq.ft with a
capacity of 90 seats at TIDEL Park Ltd.,

26

<!-- page 39 -->

Chennai at a cost of Rs.3.53 crore. So far, 44
Start-ups have been incubated successfully.
2.4 FinBlue - Centre of Excellence (CoE)
in FinTech
A Centre of Excellence (CoE) in FinTech
called ‘‘FinBlue’’ has been set up at Software
Technology Parks of India (STPI), Chennai
with

state

Government’s

contribution

of

Rs.5.75 crore. Necessary support, mentoring
and guidance are being provided to the
Start-ups. FinBlue is acting as the nucleus of
FinTech

activity

in

Tamil

Nadu

by

collaborating with national and international
FinTech regulatory organizations and will
promote investments into the state through
initiatives at FinBlue.
2.5 IT-Infrastructure
ELCOT is maintaining
infrastructure

services,

27

the state
which

IT
is

the

<!-- page 40 -->

backbone

for

providing

e-Governance

services to the citizens and connectivity to
the Government departments.
2.5.1 Connectivity Services
2.5.1.1 Tamil Nadu State Wide Area
Network (TNSWAN)
It is a scheme jointly started by the
central and state Governments under the
National e-Governance Plan (NeGP).
TNSWAN commenced its operations
with 708 Points of Presence (PoPs) that have
now increased to 829 PoPs. TNSWAN enables
state Government departments to access
their

applications,

services

and

servers

hosted in TNSDC in a secure manner. It is
being used by 3000+ offices of various
departments

of

the

Tamil Nadu.

28

Government

of

<!-- page 41 -->

TNSWAN
video

provides

connectivity

voice,

to

all

data

and

Government

departments, enables efficient workflow in
Government and enables delivery of services
to the citizens.
National

Knowledge

Network

(NKN)

has been integrated with TNSWAN at district
PoPs as per the guidelines of Ministry of
Electronics

and

Information

Technology

(MeitY), Government of India.
2.5.1.1.1 TNSWAN Phase-2 Extension
Government
accorded

approval

of
to

Tamil

Nadu

extend

has

TNSWAN

Phase-2 operations for a period of 3 years up
to February 2022.

29

<!-- page 42 -->

2.5.1.2 Other Connectivity Services
2.5.1.2.1 MPLS VPN Connectivity
Multi-Protocol Label Switching Virtual
Private

Network

provided
TNSWAN.

as

a

(MPLS

VPN)

redundant

ELCOT

provides

is

being

connection

to

MPLS

VPN

connectivity services to around 60 offices of
Tamil Nadu Government departments.
2.5.1.2.2

Internet Leased Line
Connectivity

Internet Leased Line connectivity is
being provided to 248 Government offices on
a dedicated basis.
2.5.1.2.3 VPNoBB Connectivity
Virtual

Private

Network

over

Broadband (VPNoBB) is a cost effective
alternative for providing Intranet access at
lower bandwidth. ELCOT provides VPNoBB
connectivity to 273 Government offices.

30

<!-- page 43 -->

2.5.2 Hosting and Allied Services
Tamil Nadu State Data Centre (TNSDC)
is

a

critical

delivery

of

infrastructure
secure

that

enables

e-services.

State

Government departments and their agencies
can host their data, applications, services
and

servers

secured

on

and

a

common,

controlled

redundant,

infrastructure

providing ease of operation, integration and
efficiency.
2.5.2.1 Tamil Nadu State Data Centre-1
(TNSDC-1)
Government

of

Tamil

Nadu

has

implemented the first ISO certified State
Data Centre (TNSDC-1) in the country and is
operational from the year 2011 with a
capacity of about 65 racks at a budget of
Rs.138 crore for a period of 12 years.

31

<!-- page 44 -->

2.5.2.2 Tamil Nadu State Data Centre-2
(TNSDC-2)
As

TNSDC-1

has

been

almost

completely utilized, TNSDC–2, the second
phase of TNSDC was established and it is
operational from the year 2020 at a budget
of Rs.74.7 crore. The Data Centre can
accommodate 195 Racks. Its modular design
supports seamless scale up.
More than 231 applications/services
are

currently

hosted

in

TNSDC-1

and

TNSDC-2.
2.5.2.3

Tamil Nadu Disaster Recovery
Centre (TNDRC)

Disaster Recovery Centre (TNDRC) has
been established at ELCOSEZ, Tiruchirappalli
and is operational from the year 2018. This
provides

business

continuity

for

various

critical e-Governance applications hosted in

32

<!-- page 45 -->

TNSDC, in the event of any breakdown or
disaster.
2.5.2.4 Thamizh Megam - TN Cloud
Computing Services
The state cloud infrastructure, trade
marked

as

“Thamizh

Megam’’,

enables

optimal sharing of system resources, with
minimal management. It is operational from
2016 at a cost of Rs.13.88 crore for a period
of 5 years.
At Thamizh Megam, Infrastructure-asa-Service (IaaS) and Platform-as-a-Service
(PaaS)

are

being

offered

and

116

applications/services are being hosted.
Enhancement of cloud infrastructure
and extension of Disaster Recovery facility is
being

implemented

at

Rs.9.98 crore.

33

a

budget

of

<!-- page 46 -->

2.5.3 e-Security
2.5.3.1 Security Architecture for TNSDC
To

ensure

data

protection

for

Government applications / services, following
high level Security Architecture Framework
has been put in place.
1. Security

Information

and

Event

Management (SIEM) tool.
2. Vulnerability Assessment & Penetration

Testing (VAPT).
These help in preventing cyber attacks
and take mitigation measures in case of
attacks.
2.5.3.2 Cyber Security Architecture for
Tamil Nadu (CSA-TN)
Cyber

Security

Architecture

for

Tamil Nadu (CSA-TN) has been established
to counter cyber-attacks in collaboration with

34

<!-- page 47 -->

Centre

for

Development

of

Advanced

Computing (C-DAC), Chennai at a cost of
Rs.21.39 crore for a period of 3 years.
2.6 Open Government Data
The Open Government Data (OGD)
portal of Tamil Nadu publishes open data of
Government departments, organizations and
public sector undertakings for the use of
public at large.
The state instance for OGD, Tamil
Nadu has been created and is operational at
https://data.tn.gov.in/.
different

datasets

Government

Currently,
pertaining

31,585
to

departments/agencies

64
have

been published at the portal.
2.7

Aadhaar Permanent Enrolment
Centres (PECs)
ELCOT is an empanelled agency of the

Unique

Identification

35

Authority

of

India

<!-- page 48 -->

(UIDAI)

to

carryout

Aadhaar

enrolment

activities in the state. It has established 227
PECs

at

Municipal

32

District

Collectorates,

11

Corporation

Headquarters,

45

Municipal Zonal Offices, 124 Municipalities,
2

Revenue

Divisional

Offices,

5

Town

Panchayats, 4 Block Development Offices
and 4 Provident Fund Offices.
The

cumulative

transactions

at

Permanent Enrolment Centres (PECs) as on
31.08.2021 are 67,52,011.
2.8 Capacity Building
ELCOT

plays

an

important

role

in

meeting the IT training needs of Government
departments. Training infrastructure facilities
have been created at ELCOT, Perungudi,
Chennai and in 12 Districts.
The training focuses on IT literacy,
developing requisite knowledge and skills for
36

<!-- page 49 -->

rolling out of e-Governance projects. So far,
1,21,378

participants

from

various

Government departments across the state
have benefited.
2.9 Network Services
ELCOT also
•

Facilitates

events

conferencing

through
for

video
various

departments.
•

Provides

specialized

network

equipment during the visit of VVIPs.
•

Supplies

and

commissions

video

conferencing system, public address
system, video walls, IVRS.
•

Maintains

Secretariat

(SECNET) 24x7.

37

Network

<!-- page 50 -->

2.10 Procurement Services
ELCOT

is

an

optional

procurement

agency for electronic hardware / software
products

for

all

departments/public

the

Government

sector

undertakings/

autonomous bodies.
ELCOT procures and supplies quality
electronic products to the departments. Even
during the COVID-19 Pandemic, ELCOT has
rendered

procurement

services

to

the

Government departments, particularly to the
Health and Family Welfare Department and
Police Department for their urgent needs.
The original equipment manufacturers
of desktop, laptop, printer and multifunction
devices have been responsive to ELCOT’s
tenders and offer competitive prices in view
of the large volumes in the rate contract
tenders. This has resulted in substantial cost

38

<!-- page 51 -->

savings compared with the market value of
the products.
During

the

procured

IT

Rs.245.15

crore

year

products
and

2020-21,

ELCOT

for

a

value

of

has

a

projected

procurement of Rs.300 crore for the year
2021-22.

39

<!-- page 52 -->

CHAPTER-III
DIRECTORATE OF e-GOVERNANCE AND
TAMIL NADU e-GOVERNANCE AGENCY
(TNeGA)
1. INTRODUCTION
The Directorate of e-Governance was
created

in

2006

and

Tamil

Nadu

e-Governance Agency (TNeGA) was created
as an autonomous Society registered under
the Tamil Nadu Societies Registration Act,
1975

to

implement

the

National

e-Governance Plan (NeGP).
2. OBJECTIVES
i)

To provide quality ICT services and
promote

innovation

in

emerging

technologies.
ii)

To help create a state wide strategic
architecture for e-Governance.
40

<!-- page 53 -->

iii)

To

support

change

management

in

digital transformation projects.
iv)

To improve competitiveness of the state
and make the state future ready.

v)

To

provide

benefits

of

Information

Technology to the citizens, firms and the
Government.
vi)

To

set

standards

for

data,

interoperability and security.
vii) To create an ecosystem of academic

institutions,

research

organizations,

start-ups, funding agencies and eminent
individuals.
viii) To

support

capacity

building

of

Government employees in Information
Technology.

41

<!-- page 54 -->

3. TECHNICAL UNITS
3.1 Information Technology (IT) Cadre
An IT Cadre has been created to meet
the IT needs of Government departments for
implementing e-Governance projects.
3.2 State e-Mission Team (SeMT)
The
funded

State

by

e-Mission

Ministry

of

Team

(SeMT)

Electronics

and

Information Technology (MeitY) enhances
the internal professional capacity, supports
in

programme

enterprise

management,

architecture

and

technology,
in

change

management.
3.3 Centre of Excellence for Emerging
Technologies (CEET)
Government
established

a

of

Centre

Tamil
of

Nadu

has

Excellence

for

Emerging Technologies (CEET) to promote

42

<!-- page 55 -->

and

build

competence

in

Emerging

Technologies such as Artificial Intelligence,
Blockchain, Data Analytics and IoT and adopt
these technologies in various Government
verticals such as Healthcare, Agriculture and
Education to improve governance and offer
enhanced services to citizens.
CEET acts as a catalyst for diffusion of
innovation in various ways:
i)

Finds low-cost scalable solutions to
Government departments.

ii) Establishes

with

and

fosters

Government

partnership
departments,

agencies, corporate entities, industry
bodies

and

academic

institutions

working in Emerging Technologies.
iii) Defines and promotes best practices

and

standards

followed

across

globe in Emerging Technologies.
43

the

<!-- page 56 -->

iv) Engages in capacity building, training

and orientation of Government officers
at various levels.
v) Reaches out to other

offering

similar,

organizations

complementary

or

supplementary technologies.
vi) Organizes development programmes,

training

courses,

conferences,

seminars, guest lectures and other
related activities.
vii) Conducts

research

and

produce

working papers, industry papers for
publishing in peer reviewed journals
and in conferences.
viii) Takes

up

development

specific
tasks

prototype
in

or

Emerging

Technologies based on the needs of
Government departments.

44

<!-- page 57 -->

ix) Evolves reuse software strategies for

asset creation and consumption by
Government departments.
3.4 District e-Governance Societies
(DeGS)
District e-Governance Societies have
been created for providing overall guidance
to e-Governance projects at the district level.
They are headed by the respective District
Collectors (except in Chennai, where the
Commissioner, Greater Chennai Corporation
is its head). DeGS gets a 5% revenue share
from the e-Sevai operations.
4. DATA DRIVEN GOVERNANCE
4.1 Chief Minister’s Decision Support
System
To monitor implementation of schemes
effectively, Chief Minister’s Decision Support
System is being designed to provide data
centric governance. It would display key
45

<!-- page 58 -->

performance

indicators

of

various

Department schemes/programs to help in
decision-making

at

strategic

level.

The

decision support system for departments
would utilize data at a much more granular
level

and

analytics

deploy

to

bottlenecks

comprehensive

monitor,
to

detect

improve

and

data
solve

efficacy

of

department.
4.2 State Family Database (SFDB)
Information Technology Department is
creating the State Family Database (SFDB)
at a cost of Rs.47.5 crore.
State
envisioned
Support

Family

Database

as

Data-Driven

a

Infrastructure

for

(SFDB)

is

Decision
improving

Governance. It will enable a single source of
truth for all beneficiaries of Government
schemes. It will complement the existing

46

<!-- page 59 -->

Department infrastructure by enabling data
harmonization and synchronization among
various departments. It would also help in
seamless delivery of Government benefits
and services to citizens and would improve
inclusiveness of Government schemes.
4.3 Tamil Nadu Geographical
Information System (TNGIS)
Tamil

Nadu

State

Spatial

Data

Infrastructure (TNSSDI) and its TNGIS portal
(www.tngis.tn.gov.in) is a one-stop source
for all geospatial data for the state of
Tamil Nadu.
29

stakeholder

departments

and

agencies are already part of this project and
358 layers of GIS information of various
departments have already been hosted.

47

<!-- page 60 -->

A modern Web-GIS framework is being
developed with reusable components for
future use.
5. SUSTAINABLE DEVELOPMENT GOALS
(SDGs)
Sustainable

Development

Goals

(SDGs) are a collection of 17 interlinked
goals designed to achieve a ‘better and more
sustainable future for all’.
An application has been developed by
TNeGA to capture the targets and associated
data of Sustainable Development Goals of all
departments.

48

<!-- page 61 -->

Table 1: SDG achievements related to
the Information Technology
Department
S.
No

Indicators

2020- 21
achievements

1

16.6.1: No. of
Government services
provided online to
citizens

130

2

16.6.1a: No. of
departments /
agencies integrated
for Mobile
governance

27

3

16.6.1b: No. of
e-Transactions on
e-Taal

41.3 crore

4

16.6.1c: No. of
operational Common
Service Centres

10,818

6. GOVERNMENT TO CITIZEN (G2C)
SERVICES
6.1 Common Service Centres (CSCs)
Tamil
(TNeGA)

Nadu

provides

e-Governance
electronic

49

Agency

services

to

<!-- page 62 -->

public through Common Service Centres and
through

Open

Citizen

Portal

(https://www.tnesevai.tn.gov.in/Citizen/Port
alLogin.aspx). The e-Sevai Centres are run
by Tamil Nadu Arasu Cable TV Corporation
Ltd.

(TACTV),

Primary

Agricultural

Co-

operative Credit Societies (PACCS), Village
Poverty

Reduction

Committees

(VPRCs),

Magalir Thittam of Tamil Nadu Corporation
for

Development

Department,

of

Village

Women,
Level

Fisheries

Entrepreneurs

(VLEs) and Cantonment Board with an aim to
deliver Government services to the citizens
near their homes.
As on 31.08.2021, there are 10,818
Common Service Centres operating in Tamil
Nadu under different agencies.

50

<!-- page 63 -->

Table 2: List of agencies that run CSC
S.
No

Agencies

No. of
Centres

1

Primary
Agricultural
Cooperative Credit Societies
(PACCS)

4,225

2

Tamil Nadu Arasu Cable TV
Corporation Ltd. (TACTV)

580

3

TACTV Franchise

1,553

4

Magalir Thittam – Tamil
Nadu
Corporation
for
Development of Women

2,386

5

Fisheries Department

153

6

Cantonment Board

3

7

Village Level Entrepreneurs
(VLEs)

1,918

TOTAL

10,818

51

<!-- page 64 -->

Table 3: List of 130 Services offered
through Arasu e-Sevai Centres
Department

Services Name
Income Certificate
Nativity Certificate
Residence Certificate
Community Certificate
First Graduate Certificate

Revenue and
Disaster
Management
Department (No.
of services – 40)

Deserted
Certificate

Woman

Income
and
Asset
certificate to Economically
Weaker Section
Family
Certificate

Migration

Unemployment Certificate
Widow Certificate
Agricultural
Certificate

Income

Certificate for Loss of
educational records due
to disasters

52

<!-- page 65 -->

No Male Child Certificate
Unmarried Certificate
Inter-caste
Certificate

Marriage

Legal Heir Certificate
Solvency Certificate
License
under
Broker’s Act

Pawn

Money Lender’s license
Other Backward
(OBC) Certificate

classes

Small/Marginal
Certificate

Farmer

e-Adangal
Temporary
license

Cracker

Issuance of Jain Minority
Certificate
Public Building license
Destitute
Certificate

53

Widow

<!-- page 66 -->

Indira Gandhi National
Old Age Pension Scheme
Indira Gandhi National
Widow Pension Scheme
Indira Gandhi National
Differently Abled Pension
Scheme
Differently abled Pension
Scheme
Destitute

Deserted

Women Pension Scheme
Unmarried

Women

Pension Scheme
Destitute Widow Pension
Scheme
Chief Minister’s Uzhavar
Paathukappu Thittam
Grievance Day Petition
Tamil Nilam - Full Field
Patta Transfer

54

<!-- page 67 -->

Tamil Nilam – Joint Patta
Transfer
Tamil

Nilam

–

Sub-

division Patta Transfer
Tamil Nilam – Extract of
A-Register
Tamil Nilam – Extract of
Chitta
Annai

Terasa

Ninaivu

Orphan

Girl

Marriage

Assistance Scheme
Chief Minister’s Girl Child
Protection Scheme-I
Chief Minister’s Girl Child
Protection
Social Welfare
and Women
Empowerment

Scheme – II
Dr. Dharmambal Ninaivu
Widow
Re-Marriage
Assistance Scheme

55

<!-- page 68 -->

Department

Dr. Muthulakshmi Reddy

(No. of services

Ninaivu

Intercaste

7)

Marriage

Assistance

Scheme
EVR

Maniammaiyar

Ninaivu Widow Daughter
Marriage

Assistance

Scheme
Moovalur

Ramamirtham

Ammaiyar

Ninaivu

Marriage

Assistance

Scheme
CSR Status
FIR Status
Police
Department (No.
of services – 9)

Online
Registration
Status viewing
Vehicle Search

56

Complaint

<!-- page 69 -->

View FIR
Download Accident Case
Document
Police Verification Service
Lost Document Report
Tamil Nadu Waqf

Ulema Pension Scheme

Board (No. of
service -1)
Health and

Pre-Registration

Family Welfare

Pregnancy (PICME)

of

Department (No.
of service – 1)
Registration

of

license

under Boilers Act
Directorate of
Boilers (No. of

Renewal of license under
Boilers Act

services – 5)

Application for Approval of
Manufacture/Erector
Boilers

57

of

<!-- page 70 -->

Application for Renewal of
Manufacture / Erector of
Boilers
Steam Test for Boilers
Collection of Non-Tax
Collection of Professional
Tax
Commissionerate
of Municipal
Administration
(No. of services
– 5)

Collection of Property Tax
Collection of Underground
Drainage Charge
Collection

of

Water

Charges
Chennai

Water and Sewerage Tax

Metropolitan
Water Supply
and Sewerage
Board (No. of
service – 1)

58

<!-- page 71 -->

Printing

of

Birth

of

Death

Certificate
Printing
Certificate
Greater Chennai
Corporation (No.
of services – 6)

Renewal of Trade license
Collection

of

Company

Tax
Collection of Professional
Tax
Collection of Property Tax
NOC for MSB compliance

Directorate of
Fire & Rescue
Services (No. of
services – 5)

NOC

for

MSB

Planning

Permission
NOC

for

Non-MSB

Planning Permission
MSB

Fire

license

Registration and Renewal

59

<!-- page 72 -->

Non-MSB

Fire

license

Registration and renewal
Tamil Nadu

Electricity bill payment

Generation and

Registration

Distribution

connection

Corporation Ltd.
(TANGEDCO)
(No. of services

Payment

of

for

new

LT

new

LT

connection

– 3)
Printing of Registration ID
Application for renewal of
Directorate of

registration

Employment &

Application

Training (No. of

updation

services – 4)

Application

for

profile

for

registration
Directorate of

Application

Drug Control

grant/renewal of license

60

for

<!-- page 73 -->

(No. of services - for
18)

sale

of

allopathic

drugs
Application

for

grant/renewal of license
for sale of homeopathic
medicines
Application

for

grant/renewal of license
for

sale

of

restricted

allopathic drugs
Application

for

grant/

renewal of license for sale
of Schedule X drugs
Application for issue of
duplicate License for sales
Grant / Renewal of license
for manufacture of Drugs
for Allopathy

61

<!-- page 74 -->

Approval

of

additional

categories of products
Grant of Test license
Change

of

Technical

Person
Grant/Renewal

of

loan

license for manufacture of
drugs – Allopathy
Grant/Renewal

of

repackaging

for

license

allopathic drugs
Grant/Renewal of license
for manufacture of drugs
– Homeopathy
Retention of license for
sale of Allopathic Drugs
Retention of license for
sale

of

allopathic drugs

62

Restricted

<!-- page 75 -->

Retention of license for
sale of Schedule X drugs
Retention of license for
Manufacture of Allopathic
Drugs
Retention of Loan License
for

Manufacture

of

Allopathic Drugs
Retention of License for
Repackaging of Allopathic
Drugs
Energy
Department (No.
of services -2)
Greater Chennai

Issuance

of

drawing

of

safety

approval
Issuance
certificate
e-challan payment

Traffic Police
(GCTP) (No. of
service – 1)

63

<!-- page 76 -->

Relief

assistance

to

marine fishermen families
during fishing ban period
Special

allowance

to

marine fishermen families
during fishing lean period
National

fishermen

Fisheries and

savings

Fishermen

scheme

Welfare

National

Fisherwomen

Savings

cum

Relief

Renewal

of

relief

assistance

to

marine

(No. of

service – 6)

cum

Relief

Scheme

fishermen families during
ban period
Renewal

of

special

allowance

to

marine

64

<!-- page 77 -->

fishermen during fishing
lean Period
Application

for

loan

Welfare of

assistance scheme

Differently Abled

Marriage

Persons

scheme

Department (No.

Maintenance allowance for

of services – 3)

differently abled person

assistance

Awarding

scholarships

under Dr. MGR Handloom
Weavers Welfare Trust
Tamil

Nadu

Directorate of

Co-operative

Handlooms (No.

Weavers

of services – 6)

Security Scheme

Handloom

Savings

Tamil
Co-operative

and

Nadu
Handloom

Weavers old age pension
scheme

65

<!-- page 78 -->

Tamil

Nadu

Co-operative
Weavers

Handloom

family

pension

scheme
Mahatma Gandhi Bunkar
Bima Yojana
Shiksha

Sahayog

Yojan

Scheme under Mahatma
Gandhi

Bunkar

Bima

Yojana
Housing and

Tamil Nadu Regulations of

Urban

Rights

Development

Responsibilities

Department (No.

Landlords

of service – 1)

Act

Transport

e-Challan payment

Department (No.
of service – 1)

66

and
and

of
Tenants

<!-- page 79 -->

Commercial

Issuance of encumbrance

Taxes and

Certificate

Registration

Issuance

Department

Copies

of

Certified

(No. of services
– 2)
Directorate of

CRS – Death Registration

Public Health

Birth Certificate

and Preventive
Medicine

Death Certificate

(No. of services 3)
Total

130

67

<!-- page 80 -->

Figure 1: Top 10 Transaction count of
e-Sevai Services

Table 4: Year wise transactions count
Jan 2016 - Aug 2021
Year
(Jan Dec)

e-Sevai
(CSC)

2016

e-Sevai
(Citizen
portal)

Total

1,02,91,198

-

1,02,91,198

2017

1,12,62,238

-

1,12,62,238

2018

1,04,11,812

1,83,304

1,05,95,116

2019

97,63,563

9,49,460

1,07,13,023

2020*

75,86,335

14,00,513

89,86,848

2021*
(Jan - Aug)

41,41,553

15,31,242

56,72,795

5,34,56,699

40,64,519

5,75,21,218

Total

*Period covered by COVID-19

68
