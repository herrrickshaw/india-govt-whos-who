---
doc_id: "cf1f19cd6bde8c53"
source_url: "https://artandculture.tn.gov.in/sites/default/files/doc_upload/G.O.%20No.%20189.pdf"
ministry: "Art and Culture Department, Tamil Nadu"
title: "Download"
date: ""
pages: 6
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "71f243514704cf8d"
---

<!-- page 1 -->

8 க 1
| |
t
| “my
ABSTRACT
Covid-19 - Sanction of ex-gratia Rs.1000/- to registered Scavengers, Fishermen,
Transgenders, Tribals, Traders, De-notified Communities, Narikuravars, Cine Workers,
Poosaries, Ulemass, Puthirai Vannan, Craker labourers, Folk Art and Culture workers in
Various welfare boards- Orders -Issued. ட னை ன ரர
Revenue and Disaster Management (014-177) Department
GO(Ms) No. 189 Dated:11.4.2020
விகாரி, பங்குனி 29
திருவள்ளுவர்‌ ஆண்டு 2051
Read:
1. G.O.Ms.No.161, Revenue and Disaster Management (DM-II) Dept.,
dated 19.03.2020. . .
2. Announcement made by the Hon’ble Chief Minister of Tamil Nadu in
Legislative Assembly on 23.03.2020.
3. G.O.Ms.No.171, Revenue and Disaster Management (DM-II) Dept.,
dated 24.03.2020.
4. G.O.Ms.No.177, Revenue and Disaster Management (DM-II) Dept.,
dated 1.4.2020.
5. G.O.Ms.No.179, Revenue and Disaster Management (DM-II) Dept.,
dated 4.04.2020,
6. G.O.Ms.No.184, Revenue and Disaster Management (DM-II) Dept.,
dated 8.04.2020.
7. G.O.Ms.No.186, Revenue and Disaster Management (DM-II) Dept.,
dated 9.04.2020.
8. From the Principal Secretary/Commissioner of Revenue
: Administration, Letter No.OC-1/563/2020, dated 8.04.2020.
**K
ORDER:
In the Government of India, Ministry of Home Affairs (Disaster
Management Division) Lr. No, 33-4/2020/NDM-1, dated 14.3.2020, it has
been informed that the Central Government keeping in view the spread of
COVID-19 Virus in India and the declaration of COVID-19 as pandemic by
the World Health Organization (WHO), by way of a special one time
dispensation, has decided to treat it as a notified disaster for the purpose of
Providing assistance under SDRF. The list of norms of assistance for
Qranned hy CamCranner

<!-- page 2 -->

2

| containment of COVID-19 Virus in India, eligible from SDRF has also been
communicated by Government of India.

்‌ 2. The Government of Tamil Nadu vide its Notification No.118 dated

14.03.2020, (G.O.Ms.No.95, Health and Family Welfare (P1) Department,

dated 13.3.2020) have declared that Corona Virus Disease (COVID-19) as a

notified disease in the State of Tamil Nadu. Further, the meeting of the Tamil

Nadu State Disaster Management Authority was conducted by the Chairman,

TNSDMA/ Hon’‘ble Chief Minister of Tamil Nadu on 9°13", 16, 19 and

20March 2020 to take stock of the situation prevailing due to the outbreak

of Covid-19 and issued instructions on containment of Covid-19.

3. During the review meeting of the 12 Coordination teams dealing
with COVID-19 on 09-04-2020 the Hon’ble Chief Minister has announced
that categories of unorganized workers and vocations falling under various
boards outside the Labour Department such as Scavengers, Fishermen,

| Transgenders, Tribals, Traders, De-notified Communities, Narikuravar, Cine
Workers, Craker labourers, Puthirai Vannan, Poosaris, workers involved in
Folk Art and Culture, Ulemas and Khadi laborers were also affected due to
the lockdown and hence has announced an ‘ex-gratia of Rs.1000/- to
alleviate their sufferings. Accordingly, the Principal Secretary/Commissioner
of Revenue Administration has requested that Rs.1000/- may be sanctioned
to 8,60,536 affected people as tabulated below:-
பை அ உ.
members
Craker labourers who were registered under
ESI Scheme :
People involved in Folk Art and Culture 37,385
Board
(6 |Poosaries Welfare Board | 33627]
[8 | Cine Workers Board உ] 21579]
[9 | Narikuravars Board __——=S~S—i 798 |
De-notified communities welfare Board
[TOTAL 8,60,536
; 4. The Principal Secretary/Commissioner of Revenue Administration
has submitted a Proposal to the State Executive Committee for passing
orders to sanction Rs,86.05 Crore from State Disaster Relief Fund so as to
Srannad hu CamCnannar

<!-- page 3 -->

i = i .1000/- to registered Scavengers, Fishermen,
ரகக கைத்‌ எவ்‌ Waders, De-notified Communities, Narikuravars,
Puthirai Vannan, Craker labourers, Cine Workers, Poosaries, Ulemass, Folk
Art and Culture ‘workers and Khadi labourers in various welfare boards who
were affected due to the 21 days of lockdown to control spread of COVID-
19. Further —the—Principal_Secretaryand_Commissioner _of _Revenue
Administration has stated that where ever the respective Boards have their
own funds, it would be met from it. For the Boards having nil funds and
Boards having insufficient funds the expenditure will be met from State
Disaster Response Fund.

5. The Government after careful examination accept the proposal of
the Principal Secretary/Commissioner of Revenue Administration to sanction
Rs.86.05 Crore (Rupees Eighty Six crores and Five lakhs only) from State
Disaster Relief Fund so as to disburse ex-gratia of Rs.1000/- to registered
Scavengers, Fishermen, Transgenders, Tribals, Traders, De-notified
Communities, Narikuravars, Tamil Nadu Puthirai Vannan Welfare Board,
Craker labourers, Cine Workers, Poosaries, Ulemass, Folk Art and Culture
workers and Khadi labourers in various welfare boards who were affected
due to the 21 days of lockdown to control spread of COVID-19 as tabulated
below:-

இற்கு Board | No. of |

| members
4,85,000
under ESI Scheme

Small traders Welfare Board 46,979

Tribal Welfare Board 45,000

People involved in Folk Art and Culture 37,385

Board

[6 _|Poosaries Welfare Board | (353,627 |

[8 _| Cine Workers Board _- 21,679

[9 _| Narikuravars Board | 13,798

9,042

3,826

3,771

[roan | 860536
Further it is ordered that where ever the respective Boards have their own
funds, it would be met from it and for the Boards having nil funds and
Boards having insufficient funds the expenditure will be met from State
Disaster Response Fund.

Qeanned hu CamCeranner

<!-- page 4 -->

| |
6. The above expenditure sanctioned in Para 5 above shaii be debited ர
to the following head of account :- |
2245 Relief on Account of Natural Calamities 80 General-800 other |
expenditure State's Expenditure-AH Disaster Preparedness |
/Preventive measures: to contain the outbreak of Corona Virus
(Covid 19) - 309 Grants-in-Aid - 09 Others
(Old DPC 2245 80 800 AH 0998)
(IFHRMS DPC 2245 80 800 AH 30909)
7. Necessary additional funds will be provided in RE/FMA 2020-21.
Pending of such funds, the Principal Secretary/ Commissioner of Revenue
Administration is authorised to draw and disburse the amount. The
expenditure shall be brought to the notice of Legislature by specific inclusion
in Supplementary Estimate 2020-21. The Principal Secretary/ Commissioner
of Revenue Administration is requested to send necessary proposal for
inclusion of this expenditure in Revised Estimate 2020-21 and also send
necessary explanatory note for inclusion of this expenditure in Final
Supplementary Estimate 2020-21 at appropriate time.
8. This order issues with the concurrence of Finance Department vide
its UO.No.1334/(FS)/P/2020, dated:11.04.2020 with additional sanction
ledger No.0007 ( SEVEN).
(By order of the Governor)
ATULYA MISRA,
ADDITIONAL CHIEF SECRETARY
To
The Principal Secretary and Commissioner of Revenue
Administration, Chepauk, Chennai-600 005. -
The Director, Disaster Management,
Tamil Nadu Disaster Risk Reduction Agency, Chepauk, Chennai-600 005.
The Additional Chief Secretary to Government, Labour and
Employment Department, Chennai -9.
To Departments of Secretariat related to the respective Boards,
Chennai-9.
The Accountant General, Chennai - 600 018.
The Pay and Accounts Officer (East/South/North),
Chennai - 600 008/600 035/600 001.
Copy to:
The Additional Chief Secretary to Government,
Finance Department, Chennai - 600 009 ்‌
The Additional Chief Secretary to Government, Home, Prohibition
and Excise Department, Chennai - 600 009.
Qranned hu CamCGranner

<!-- page 5 -->

5
The Special Personal Assistant to Hon'ble Minister for
Revenue and Disaster Management and Information
Technoiogy, Secretariat, Chennai - 600005,
The Private Secretary to Chief Secretary to Government,
Secretariat, Chennai - 600 009
The Principal Private Secretary to Additional Chief Secretary
்‌ to Government, Revenue and Disaster Management
Department, Chennai - 600 009.
The Finance (Revenue/BG-I/BG-II) Department,
Chennai -600 009, .
/Forwarded /By/ Order/
ஹி
Oo
SECTION OFFICER
Qranned hu CamGranner

<!-- page 6 -->
