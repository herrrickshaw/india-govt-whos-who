---
doc_id: "cfeb88e2652fbccb"
source_url: "https://www.drugscontrol.tn.gov.in/pdfs/guidelines_additional_technical_staff_blood_bank_storage_centre_recognised_medical_institution.pdf"
ministry: "Food Safety and Drug Administration Department, Tamil Nadu"
title: "3. Guidelines for Additional Technical Staff / Blood Bank / Blood Storage Centre /   Recognised Medical Institution"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "77b82e216fc86f44"
---

<!-- page 1 -->

CHANGE OF TECHNICAL STAFFS- BLOOD CENTRE/BLOOD STORAGE CENTRE

1. A covering letter specifying the purpose of the application, addressed to the
Director of Drugs Control, Chennai – 600 006, along with a court fee stamp
of Rs. 5/- for each licence..
2. Fee of Rs. 1,000/- per Technical Staff towards Additional Technical Staff
Endorsement and an inspection fee of Rs. 1,500/- in Blood centre Licence
and Certificate of approval to Blood storage centres. The fee shall be paid
through the Treasury Portal: https://karuvoolam.tn.gov.in/web/tnta/.
3. Authorization letter in favour of the signatory of the application.
4. Original Licence/Original Certificate of approval to Blood Storage Centre
5. Attested copies of qualification certificate, experience certificate of the new
technical staffs
6. If the Technical Staff has already been approved in any other licensed blood
centre or approved blood storage centre by this Department or any other
State Drugs Control Authority, submit the approval details.
7. Self-attested copies of the address proof, identity proof of the Technical Staff
along with their Passport size photograph
8. Self declaration of technical staffs for full time employment in the stamp paper
for the value of Rs 200
9. Appointment orders and joining letters of new technical staff, along with the
relieving order or resignation letter of the previous technical staff.
