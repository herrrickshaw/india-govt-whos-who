---
doc_id: "de0a9b0c79fcff85"
source_url: "https://labour.tn.gov.in/docs/legal-acts-rules.pdf"
ministry: "Labour Department, Tamil Nadu"
title: "Legal Metrology"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b60acc8ca03d5fa8"
---

<!-- page 1 -->

Legal Metrology Act and Rules
Sl.
No.

Name of the
Act

1

Manufacturer

Applicability

List of documents to be enclosed with the
application for Registration Certificate /
License

Manufacurer 1. Attested copy of the sale deed/House Tax/EB
of any weight Card
or
2.Rental/Mortgage/Lease agreement with NOC
from the owner
3. Partnership deed
4.Memorandum of Association approved by the
Ministry of Company affairs GOI
5.Model Approval letter from GOI
6.A copy of the approved trademark shall be
furnished at the time of submitting the application
7.GST certificate to be enclosed
8.Details and Qualification of Skilled/Unskilled
workers to be employed
9.To furnish experience certificate for at least 2
years for the items applied or Diploma in
Electronics/Electrical/ mechanical Engineering or
certificate of instrument mechanic from the ITI
10. List of Tools and test equipment
11. Blue print for building by register surveyor.

Time period
for granting
Validity of
Licence
Certifcate of
Registration
registration or
Certificate
Licence
approval time
period

As per rule of
rules formed
under this Act,
When to be
renewed RC /
Licence

Every licence As per Rule 11 of
granted or
LM (Enforcement)
renewed under Rules 2011, an
rule 11 shall
application for
remain in force renewal shall be
upto and
made not less 30
inclusive of the days before the
31st December date on which the
of the year for licence expires.
which the
licence is
granted or
renewed.
15 days

Late Fee for
renewal of Re
payable of RC

As per Rule
11(2) of LM
(Enforcement)
Rules 2011, If an
application for
renewal is not
received within
30 days, a late
fee of 100%
percent in excess
of the fee
ordinarily
payable for
getting approval
from Controller
for the period
upto 31st March.

<!-- page 2 -->

2

3

Dealer

Repairer

1. Attested copy of the sale deed/House Tax/EB
Card
2.Rental/Mortgage/Lease agreement with NOC
from the owner
3. Partnership deed
4.Memorandum of Association approved by the
Ministry of Company affairs GOI
5.Dealership letter
6.GST certificate to be enclosed

1. Attested copy of the sale deed/House Tax/EB
Card
2.Rental/Mortgage/Lease agreement with NOC
from the owner
3. Partnership deed
4.Memorandum of Association approved by the
Ministry of Company affairs GOI
5.Model Approval letter from GOI
6.GST certificate to be enclosed
7.Details and Qualification of Skilled/Unskilled
workers to be employed
9.To furnish experience certificate for at least 2
years for the items applied or Diploma in
Electronics/Electrical/ mechanical Engineering or
certificate of instrument mechanic from the ITI
10. List of Tools and test equipment
11. Blue print for building by register surveyor.

15 days

15 days

Every licence As per Rule 11 of
granted or
LM (Enforcement)
renewed under Rules 2011, an
rule 11 shall
application for
remain in force renewal shall be
upto and
made not less 30
inclusive of the days before the
31st December date on which the
of the year for licence expires.
which the
licence is
granted or
renewed.

As per Rule
11(2) of LM
(Enforcement)
Rules 2011, If an
application for
renewal is not
received within
30 days, a late
fee of 100%
percent in excess
of the fee
ordinarily
payable for
getting approval
from Controller
Every licence As per Rule 11 of for
As the
per period
Rule
granted or
LM (Enforcement) 11(2) of LM
renewed under Rules 2011, an
(Enforcement)
rule 11 shall
application for
Rules 2011, If an
remain in force renewal shall be
application for
upto and
made not less 30 renewal is not
inclusive of the days before the
received within
31st December date on which the 30 days, a late
of the year for licence expires.
fee of 100%
which the
percent in excess
licence is
of the fee
granted or
ordinarily
renewed.
payable for
getting approval
from Controller
for the period
upto 31st March.

<!-- page 3 -->

4

Packaged
Commodities
(Packers/Impor
ters)

1. GST/FSSAI/ VC/ FL / TL certificate to be
enclosed for address Proof.
2. Partnership deed.
3.Certificate of incorporation
4. Certificate of Importer and Exporter (With
Code) ( For importer only)

As per Rule 27
of TN LM(PC)
Rules 2011,
this is one time
registration. No
renewal.
7 days

-

-
