---
doc_id: "bcca69510e0f6aeb"
source_url: "https://www.drugscontrol.tn.gov.in/guidelines_procedures_grant_renewal_licence_manufacture_drugs_sale_allopathic_drugs.pdf"
ministry: "Food Safety and Drug Administration Department, Tamil Nadu"
title: "Grant of licence for manufacture of drugs for sale"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "00192d2c97e99647"
---

<!-- page 1 -->

Guidelines and Procedures for Grant of Licence for manufacture of drugs other than Medical
Devices for sale- Allopathic Drugs
Licencing Authority - The Director of Drugs Control, Chennai-600006
Documents to be submitted:
1. Covering letter addressed to the Director of Drugs Control, Chennai-600006, along with Rs.2/court fee stamp for each licence.
2. Application in Form-24 / Form-27 / Form-24F / Form-27B/ duly filled and signed by the
applicant.
a. To obtain licence for manufacture of drugs
i. other than those specified in Schedules C and C (1) and X - application in Form
24
ii. specified in Schedules C and C (1) excluding those specified in Schedule XApplication in Form 27
iii. specified in Schedule X - Application in Form 24F
iv. specified in Schedules C, C(I) and X - Application in Form 27B
3. Fees of Rs. 7500/- per licence with minimum of 10 products for each category of Schedule M
and if exceeds, an additional fees Rs. 300/- per product shall be paid through online.
4. Authorization of the signatory of the application form
5. Details of the products applied
a. List of products with composition (in quadruplicate)
b. Copies of Drugs Controller General (India)'s approvals, if required.
c. Specimen label.
d. Therapeutic justification in case of patent and proprietary medicines.
e. Method of manufacture of bulk drug along with specification of the intermediates and
the Material Safety data sheet of each and every material used during manufacture and
finished product
f. Specification and method of analysis for Raw Materials and Finished Products.
g. Brand name declaration in case of the products manufactured exclusively for the
purpose of export.
h. Stability data.
i.

Test Licences in Form 29.

j.

Consent letter from approved laboratory if applicable

6. Applicant details:

<!-- page 2 -->

a. Document relating to constitution of concerned firm/ Company/ LLP and others.
b. List of Directors/partners and their Bio-data with their residential addresses and Photo,
in case of proprietorship, bio-data with their residential addresses and Photo of
proprietor.
c. Address/ ID proof of the applicant
7. Technical Personnel Details:
a. List of manufacturing Chemists/ Analytical Chemist along with their Bio-data, Passport
size photo and photocopies of Qualification Certificate and experience certificate
b. Declaration of the manufacturing Chemist/analytical Chemist.
c. Address proof and ID proof of the manufacturing Chemist/ analytical Chemist
8. Premises details:
a. Ownership document of the premises.
b. Plan of the premises- with details of partitions, measurements - Section wise with
location of machineries
c. Rental agreement of the premises, if applicable
9. Details of Machineries/Equipments:
a. List of machineries and equipments, AHU's, and water system provided Section wise for
the manufacturing.
b. List of analytical instruments and equipments for analysis.
c. The photocopies of purchase invoices with the details like production capacity, make
etc. wherever applicable
10. In case of change of premises & change in constitution
a. Enclose original licence / Renewal Certificate if any with list of products permitted.
b. Documents related to change in constitution like sale deed, Dissolution/Reconstitution
deed, Amalgamation court order if it is Private Limited Company with board resolution
and any other document pertaining to change in constitution.
11.

Any other document/particulars which is related to the above mentioned documents to verify
the correctness of the particulars submitted by the applicant, if necessary.

Important Notes:
•

All the applications to be applied through eSevai Open portal

1 Procedure
Procedure Followed:

<!-- page 3 -->

1.
After the receipt of application, the file will be forwarded to the Assistant Director of Drugs control/
Senior Drugs Inspector/ Drugs Inspector/ Deputy Drugs Controller (India) within 5 working days, who in turn will
resubmit the application with Inspection Report and all required documents within 25 working day
2.
If the file is in complete shape, the Licence will be issued within 30 working days otherwise further
action will be taken on the file for processing again.

Process I: Application is received by Assistant Director (Zone)

<!-- page 4 -->

Drug Department – Process Flow – 4 (Manufacturing Licence)

START

Fill Application
Form

End

Applicant

Upload the supporting
documents

Receipt for
Online Payment

Download Licence

Complete Payment of
Requisite Fee & Submit
the Application

HQ - Tapal

Respond to the
Queries

Scrutnise and Forward

Director

Review the Application
and Supporting
Documents
Within 7
days

Any clarifications
required?

Yes

Raise Query

Raise Queries
Licence

No
Reject the
Application

Issue Licence

HQ Officers

Forward the Application

Review, Note
Query, &
Forward

Review, Note
Remarks, &
Recommend

Review, Note
Remarks, &
Forward

Senior Drug Inspector (SDI) / Drug
Inspector (DI) - Zone

Assistant Director (AD) - Zone

No

Yes

Review the Application and
Forward the Application to
SDI/DI

Review the Remarks and
Forward to Director
Is it a case of
Rejection?

Review Recommendation
and Forward to Director

Yes
No

Send Remarks to
AD

No
Schedule Inspection

Was the inspection
satisfactory?

Yes

Send
Recommendation
to AD

Deputy Drug Controller (DDC)
- India

Central Drug Inspector
(CDI)

Conduct Inspection
Is it a case of
Rejection?

Send Remarks to
DDC

No

Schedule Inspection

Yes
Was the inspection
satisfactory?

Send
Recommendation
to DDC

Review the Remarks and
Forward to Director
Review the
Application and
Forward to CDI

Review Recommendation
and Forward to Director

Legend
Online – Department system

SMS & Email Alert Sent to the Applicant

SMS & Email Alert Sent to the Department Official

<!-- page 5 -->

Process II: Application is received by Drug Inspector / Senior Drug Inspector (Head Office)
Drug Department – Process Flow – 4 (Manufacturing Licence)

START

Fill Application
Form

Applicant

Upload the supporting
documents

Receipt for
Online Payment

Complete Payment of
Requisite Fee & Submit
the Application

End

Respond to the
Queries

HQ Tapal

Download Licence

Scrutnise and Forward

Director

Review the Application
and Supporting
Documents
Within 7
days

Any clarifications
required?

Yes

Raise Queries
Licence

No
Reject the
Application

Raise Queries

Deputy Drug Controller (DDC)
- India

Central Drug Inspector
(CDI)

Senior Drug Inspector (SDI) / Drug
Inspector (DI) – Head Office

HQ Officers

Forward the Application

No

Review, Note
Remarks, &
Forward

Review, Note
Query, &
Forward

Is it a case of
Rejection?

Issue Licence

Review, Note
Remarks, &
Recommend

Yes

Send Remarks to
Director

No
Schedule Inspection

Yes

Was the inspection
satisfactory?

Yes

Send
Recommendation
to Director
No

Conduct Inspection
Send Remarks to
DDC

No

Schedule Inspection

Yes
Was the inspection
satisfactory?

Send
Recommendation
to DDC

Is it a case of
Rejection?

Review the Remarks and
Forward to Director
Review the
Application and
Forward to CDI

Review Recommendation
and Forward to Director

Legend
Online – Department system

SMS & Email Alert Sent to the Applicant

SMS & Email Alert Sent to the Department Official

<!-- page 6 -->

3 Fees
S. No.
1
2
3

Fee Type
Licence Fee
Inspection Fee
Additional (only for categories for which the number of products exceed 10)

Overall Processing Time:
In case of Grant of Licence: 75 days

Amount (INR)
6,000
1,500
No. of products * 300

<!-- page 7 -->

1. e)
Guidelines and Procedures for Grant of Licence for manufacture of drugs other than Medical
Devices for sale- Allopathic Drugs in Form 27D
Licencing Authority - The Director of Drugs Control, Chennai-600006
Documents to be submitted:
1.

Covering letter addressed to the Director of Drugs Control,

Chennai-600006, along with Rs.2/- court fee stamp for each licence.
2.

Application in Form 27D duly filled and signed by the applicant to obtain licence for

manufacture of Large Volume Parenterals/ Sera and Vaccines recombinant DNA (r-DNA)
derived drug excluding those specified in Schedule X
3.

Fees of Rs. 7500/- per licence as Demand draft in Favour of the
Director of Drugs Control, Chennai-6 with minimum of 10 products for
each category of Schedule M and if exceeds, an additional fees Rs. 300/per product shall be paid.

4.

Authorization of the signatory of the application form

5.

Details of the products applied
a.

List of products with composition (in quadruplicate)

b.

Copies of Drugs Controller General (India)'s approvals, if required.

c.

Specimen label.

d.

Therapeutic justification in case of patent and proprietary medicines.

e.

Method of manufacture of bulk drug along with specification
of the intermediates and the Material Safety data sheet
of each and every material used during manufacture and
finished product

f.

Specification and method of analysis for Raw Materials and
Finished Products.

g.

Brand name declaration in case of the products manufactured
exclusively for the purpose of export.

h.

Stability data.

i.

Test Licences in Form 29.

j.

Consent letter from approved laboratory if applicable

k.

A CD containing the list of products applied along with
formula in the given format.

<!-- page 8 -->

6.

Applicant details:
a.

Document relating to constitution of concerned firm/
Company/ LLP and others.

b.

List of Directors/partners and their Bio-data with their
residential addresses and Photo, in case of proprietorship,
bio-data with their residential addresses and Photo of proprietor.

c.
7.

Address/ ID proof of the applicant

Technical Personnel Details:
a.

List of manufacturing Chemists/ Analytical Chemist along with
their Bio-data, Passport size photo and photocopies of
Qualification Certificate and experience certificate

b.

Declaration of the manufacturing Chemist/analytical Chemist.

c.

Address proof and ID proof of the manufacturing Chemist/
analytical Chemist

8.

Premises details:
a.

Ownership document of the premises.

b.

Plan of the premises- with details of partitions, measurements Section wise with location of machineries

c.
9.

Rental agreement of the premises, if applicable

Details of Machineries/Equipments:
a.

List of machineries and equipments, AHU's, and water system
provided Section wise for the manufacturing.

b.

List of analytical instruments and equipments for analysis.

c.

The photocopies of purchase invoices with the details like
production capacity, make etc. wherever applicable

10.

In case of change of premises & change in constitution
a.

Enclose original licence / Renewal Certificate if any with
list of products permitted.

b.

Documents related to change in constitution like sale deed,
Dissolution/Reconstitution deed, Amalgamation court order
if it is Private Limited Company with board resolution and
any other document pertaining to change in constitution.

11.

Any other document/particulars which is related to the above
mentioned documents to verify the correctness of the particulars
submitted by the applicant, if necessary.

<!-- page 9 -->

Important Notes:
•

All the applications to be sent in,

Original to
o

The Director of Drugs Control, Tamil Nadu, 359, Anna Salai, Chennai. 600 006.

Copy to
o

The Drugs Controller General (India), Central Licence
Approving Authority Directorate General of Health Services,
Food & Drugs Administration Bhawan, Kotla Road I.T.O, New Delhi-110 002.

o

The Deputy Drugs Controller (India)South Zone, Central Drugs
Standard Control Organization, No. 26, Haddows Road, Shastri
Bhavan Annexe Chennai -600 006

Procedure Followed:
1.

The applicant has to submit the application, fees with
Documents to be submitted to the Director of Drugs Control, Chennai-6.

2.

After the receipt of application, the file will be forwarded
to the Assistant Director of Drugs control/ Senior Drugs
Inspector/ Drugs Inspector/ Deputy Drugs Controller (India)
within 5 working days, who in turn will resubmit the application
with Inspection Report and all required documents within 25 working day

3.

If the file is in complete shape, the Licence will be issued
within 30 working days otherwise further action will be taken
on the file for processing again.
