---
doc_id: "fac8bcbe5af71cfc"
source_url: "https://tnhealth.tn.gov.in/online_notification/notification/N26104757.pdf"
ministry: "Health and Family Welfare Department, Tamil Nadu"
title: "Authorization Committee meeting for liver and renal transplantation held at Directorate of Medical Education and Research, Chennai on 23rd October 2026"
date: ""
pages: 3
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "476b70afdb867652"
---

<!-- page 1 -->

K.Dis.No.97796/H&DII/4/2026 Office of the Chairman, Authorization
Committee and Directorate of Medical
ருக்‌ Education & Research, Kilpauk, Chennai-10.
cr Me Dated:23.10.2026
Sub: Human Organ Transplantation Act 1994 - Authorization Committee Meeting for
Liver / Renal Transplantation held on 23.10.2026 - Decision of the Authorization
Committee for Liver / Renal Transplantation — Forwarded for uploading in the site
of www.tnhealth.tn.gov.in.
Liver Transplantation =.) »
Name of the Name ofthe | Nameofthe | Whether If Rejected /
Hospital Patient Donor Approved / Withheld, Reason
- Rejected /
Withheld /
Absent
A Dr. Rela Institute & Mohan G Lulu G we
Medical Centre, ரி
Chennai ப்‌ ம்‌
2 Dr. Rela Institute & Fatima Said Anmed | Azzan
Medical Centre, Ba Wazir Mohammed
Chennai TA Suhail Ba 7
Wazeer APPRO ன்‌
3 | Dr. Rela Institute & | Kh Mainul Islam MdRiazul |
Medical Centre, Haque
ete APPROVE
Gem Hospital, Nayan Jyoti Bora Manika Barman
Perungudi, Chennai
Renal Transplantation
Name of the Name of the Name of the | Whether If Rejected /
Hospital Patient Donor Approved / Withheld, Reason |
Rejected / |
Withheld /
rs Absent
1 Apollo Speciality Shidratul Muntaha MD Shuja Uddin
Hospital, Sarker
Perungudi, Chennai APPROVE
2 Christian Medical Doyir Taipodia Keter Buchi
College Vellore
Ranipet Campus, APPROV ட்‌
Ranipet

<!-- page 2 -->

3 Christian Medical Manish Kumar Punam Devi
College Vellore
Ranipet Campus, =
Ranipet APPROV af
4 Christian Medical Abhishek Mangar Baiju Mangar
College Vellore
Ranipet Campus,
Ranipet
5 Christian Medical Gayatri Kumari Thama Sharma
College Vellore Sharma
Ranipet Campus,
Ranicst APPROVE
Christian Medical Believe Suchiang Rina Suchiang
College Vellore
Ranipet Campus, ட்‌
பகன்‌ APPROVE
7 Gleneagles Viraragou G Suguna [7 A Bi Y
HealthCity Wwe 844! த்த
Perumbakam, So gr
Chennai a) p றி 51 த்‌
த (2
Kovai Medical Nand Kishore Durga Devi ) Pye"
Centre and Hospital | Bagree Bagree | wl ர ம்‌
Ltd., Coimbatore, 4 as APPROV ED 7 ௬”
ர்‌ (/. [08
oa f- 1
Kovai Medical Sandeep Kumar Anita Goyal 7) / Am தி
Centre and Hospital | Goyal
Ltd., Coimbatore
வெப்ப APPROVED
10 | Kovai Medical Anuradha D Rojarani
Centre and Hospital
Ltd., Coimbatore APPROV =|
11 | Kovai Medical Dattatray Subhash | Shalan Subhash
Centre and Hospital | Vedpathak Vedpathak
Ltd., Coimbatore APPROVE!
12 | Kovai Medical Rahul Shivaji Patil Mangal Shivaji ie
Centre and Hospital Patil ர |
Ltd., Coimbatore h\ bd
2 4 ன்‌
1.Chairman, Authorization Committee / Director |” த்‌
of Medical Education & Research, Chennai ॥ி ant J
for DME&R
2.Member of Authorization Committee / Director
of Medical and Rural Health Services, Chennai [2 ய்‌
ew)
for DM&RHS ~

<!-- page 3 -->

3.Member of Authorization Committee / Deputy ௩
வப பபப of Police (Headquarters), ~ ee
ennai
நீ for DCP CRAG
4.Member of Authorization Committee / Dean,
Kilpauk Medical College, Chennai
a Dean, KMC i
5.Member of Authorization Committee / Dean,
Stanley Medical College, Chennai
forDean, SMC ட்‌ a No
6.Member of Authorization Committee / State
Secretary, Indian Medical Association, Qa ets
Chennai No]
for State President, IMA ௨௫ ௨/74
7.Member of Authorization Committee and Deputy
Secretary / Deputy Director of Medical
Education & Research (Administration), 2
Directorate of Medical Education & Research, DS/DDME&R
Chennai
To
The Director of Medical & Rural Health Services, Chennai.
Copy Submitted to
The Principal Secretary to Government,
Health & Family Welfare Department.
