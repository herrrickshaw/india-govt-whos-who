---
doc_id: "63fb1ce0ba88cca0"
source_url: "https://www.msuniv.ac.in/uploads/circular/pdfs/6a97cdc62354f8.79628818.pdf"
ministry: "Manonmaniam Sundaranar University, Tamil Nadu"
title: "Know More"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1c0dcf3812afde5e"
---

<!-- page 1 -->

MANONMANIAM SUNDARANAR UNIVERSITY

( Reaccredited with “A+” Grade (3.46) by NAAC in 4th Cycle )

ABISHEKAPATTI, TIRUNELVELI-627 012
NOMINATION

PAPER

ELECTION OF TWO MEMBERS TO THE STANDING COMMITTEE ON ACADEMIC
AFFAIRS BY PRINCIPALS OF AFFILIATED COLLEGES FROM AMONG
THEMSELVES IN ACCORDANCE WITH THE SYSTEM OF PROPORTIONAL
REPRESENTATION BY MEANS OF THE SINGLE TRANSFERABLE VOTE- 2026
Name of the Candidate
:
(Please state also the academic
degrees taken for including after
the name in the Ballot Paper)
Number of the Candidate in the
electoral roll, if any.

:

Address of the Candidate

:

------------------------------------------------------------------------------------------------Name of the Proposer
:
Number of the Proposer in the
electoral roll, if any.

:

Address of the Proposer

:

Signature of the Proposer
:
Date ............
------------------------------------------------------------------------------------------------Name of the Seconder
:
Number of the seconder in
the electoral roll, if any.

:

Address of the Seconder

:

Signature of the Seconder
:
Date.............
------------------------------------------------------------------------------------------------PTO

<!-- page 2 -->

CONSENT OF THE CANDIDATE
ELECTION OF TWO MEMBERS TO THE STANDING COMMITTEE ON ACADEMIC
AFFAIRS BY PRINCIPALS OF AFFILIATED COLLEGES FROM AMONG
THEMSELVES IN ACCORDANCE WITH THE SYSTEM OF PROPORTIONAL
REPRESENTATION BY MEANS OF THE SINGLE TRANSFERABLE VOTE.-2026
"I hereby declare that (A) I am not a member of the above authority to which I seek election;
(B) My term of office as member of the above authority, to which, I seek
election would also expire before the membership for which I am
seeking election takes effect.
And I agree to serve in the ........................................ if elected.
(C) I also further declare that the facts stated above are true to the best
of my knowledge and belief and in the event of any defects or
mistakes being found out in the aforesaid declaration of mine, my
nomination is liable to be rejected".

DATE:

Signature of the Candidate

NOTE: 1. Among (A) and (B) above, please strike out the clause which is not applicable.
2. An elector shall be eligible to subscribe either as proposer or as seconder
nomination papers, only as many time as there are vacancies but not more.
3. Every nomination shall be in writing signed by the proposer who shall be a
Principals of affiliated Colleges and seconded in writing by another Principals
of affiliated colleges called the seconder.

<!-- page 3 -->

MANONMANIAM SUNDARANAR UNIVERSITY

( Reaccredited with “A+” Grade (3.46) by NAAC in 4th Cycle )

ABISHEKAPATTI, TIRUNELVELI-627012
DECLARATION PAPER

ELECTION OF TWO MEMBERS TO THE STANDING COMMITTEE ON ACADEMIC
AFFAIRS BY PRINCIPALS OF AFFILIATED COLLEGES FROM AMONG
THEMSELVES IN ACCORDANCE WITH THE SYSTEM OF PROPORTIONAL
REPRESENTATION BY MEANS OF THE SINGLE TRANSFERABLE VOTE.- 2026
Elector's Name:
Number in the electoral roll, if any:
ELECTOR'S DECLARATION
I,
____________________________________________________________
(Name in full and designation) declare that, I am an elector for the above
election
to
the
_____________________________
by
the
__________________________________________ and have signed no other
declaration paper at the election.

Date:
Station:

Signature of the candidate
Address
