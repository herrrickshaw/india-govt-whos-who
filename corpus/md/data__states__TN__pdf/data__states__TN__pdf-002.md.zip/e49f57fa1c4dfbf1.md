---
doc_id: "e49f57fa1c4dfbf1"
source_url: "https://www.cra.tn.gov.in/cm-helpline-portal-instructions-reg.pdf"
ministry: "Commissionerate of Revenue Administration and Disaster Management, Tamil Nadu"
title: "2. CM Helpline Portal - Monitoring and Disposal of Public Grievance Petitions - Instructions for Timely and Quality Redressal - Reg"
date: ""
pages: 2
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "55677ee217bedf65"
---

<!-- page 1 -->

RC.No.RA-7(1)/ 576/2023 Commissionerate Of Revenue Administration
And Disaster Management Department,
Chepauk, Chennai - 600 005.
Dated:09.06.2026
CIRCULAR
Sub: CM Helpline Portal - Monitoring and Disposal of Public
Grievance Petitions - Instructions for Timely and
Quality Redressal - Reg.
Ref: 1. Review of Petitions received and disposed of
through the Muthalvarin Mugavari Portal during the
Period from 04.05.2026 to 25.05.2026.
2. From the Addl.Chief Secretary to Government
/Special 0௧௦) — Muthalvarin Mugavari
Department, D.O letter no.82800/Sec-
4/2026,Dated:29.05.2026
3. Government Letter No.7770/GL.1I(2)/2026-1,
Revenue and DM Departement, Dated : 29.05.2026
It is informed that all grievance petitions received from the public are
being monitored through the CM Helpline Portal. Based on the outcome of
the meeting held with the Hon'ble Chief Minister, the Additional Chief
Secretary to Government / Special Officer (FAC), Muthalvarin Mugavari
Department, in her letter has issued the following instructions for strict
compliance by all concerned officers:
1. Timely Disposal
All petitions shall be properly examined and disposed of within the
stipulated period of 30 days. Any undue delay or improper disposal noticed
during review shall be rectified immediately and appropriate corrective
action shall be taken.
2. Field Enquiry
Wherever a field enquiry is required, the same shall be conducted by
the authorized officer/staff concerned. The findings of such enquiry shall be
clearly recorded and reflected in the reply furnished to the petitioner,

<!-- page 2 -->

்‌

3. Reasoned Reply

A detailed and speaking reply shall be sent to the petitioner in all
cases, clearly indicating the reasons for acceptance or rejection of the
petition. Replies shall be comprehensive, transparent, and based on facts
and records.
4. Final Disposal

Final disposal shall be ensured in all petitions. In cases where disposal
is delayed due to reasons such as pending court cases, non-availability of
funds, requirement of Government orders, or any other valid reasons, an
interim reply shall be issued to the petitioner clearly explaining the reasons
for the delay and the present status of the petition.
5. Waitlisted Petitions

In cases where a petition is disposed of as “Waitlisted”, the seniority
number and all relevant details shall invariably be furnished in the reply to
the petitioner.

Therefore All District Collectors are requested to update all the
grievances received in all revenue offices through the same portal and
ensure strict compliance of the above instructions and also to closely
monitor the disposal of petitions under their jurisdiction so as to improve the
quality, transparency, and timeliness of grievance redressal through the CM
Helpline Portal.

Sd/- N. Muruganandam
Additional Chief Secretary /
Commissioner of Revenue Administration
To
All District Collectors.
Copy to:
The Secretary to Government,
Revenue and Disaster Management Department,
Chennai 600 009.
ns
எது poe
Assistant Commissioner - VI
| Gor Additional Chief Secretary /
Commissioner of Revenue Administration
24
92
