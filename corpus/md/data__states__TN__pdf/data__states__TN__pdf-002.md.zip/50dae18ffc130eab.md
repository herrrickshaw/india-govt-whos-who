---
doc_id: "50dae18ffc130eab"
source_url: "https://www.periyaruniversity.ac.in/Documents/2026/Tender/ten157.pdf"
ministry: "Periyar University, Tamil Nadu"
title: "View Details"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "915eabbde3eb4767"
---

<!-- page 1 -->

பெரியார்பல்கலைக்கழகம்
PERIYAR UNIVERSITY, SALEM- 636 011,TAMIL NADU
NAAC A++ Grade - State University - NIRF Rank 94 State Public University Rank 40

Phone: 0427- 2345766, 2346268, 2346269 Fax: 0427- 2345124

PU/P&D11/COE-CRE IV/Ricoh MP 2501 sp/017446/2026

Date:13-10-2026

e-Tender Notification

Online

bids

(Two

Cover

Systems)

are

invited

through

the

portal

https://tntenders.gov.in for the Repair and Servicing of a Ricoh MP 2501 sp in the Controller
Office (CRE IV) at Periyar University, Salem.

Registrar (FAC)
Tender Inviting Authority

To
The Director
Computer Centre
Periyar University
Salem – 11.

--------------- (For displaying a Tender Notice in the
Periyar University Website)
