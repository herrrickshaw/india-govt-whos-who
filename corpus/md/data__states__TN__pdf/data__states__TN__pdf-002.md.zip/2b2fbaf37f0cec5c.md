---
doc_id: "2b2fbaf37f0cec5c"
source_url: "https://arasurubber.tn.gov.in/saleofwindfalleneucalyptus.pdf"
ministry: "Arasu Rubber Corporation Limited, Tamil Nadu"
title: "Tender for sale of wind fallen eucalyptus trees in Keeriparai Division - Tender Notice"
date: ""
pages: 10
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "5fd2d7e99071a483"
---

<!-- page 1 -->

அரசு ரப்பர்‌ கழகம்‌ லிமிடெட்‌ தஆ
Zee 4 (தமிழ்நாடு Sure நிறுவணம்‌), fy
பதிவு அலுவலகம்‌, வடசேரி. தபாஸ்பெட்டி எண்‌ 75, நாகர்கோவில்‌-629001, யக)
Sse கன்ணியாகுமரி மாவட்டம்‌, தமிழ்நாடு ணை,
Arasu Rubber Corporation Limited த கன்‌
(A Government of Tamil Nadu Undertaking) Certified
Phone: (04652) 274203, 294441
Website: www.arasurubber.tn.gov.in_E-mail:arusurubber@zmail com, arasurubber.arcl@in gov in
Regd. Office : Post Box No.75, Vadasery, NAGERCOIL - 629 001. Kanyakumari District, Tamil Nadu.
GST No.: 33AAECA2671E174 CIN : U25LL0TN1984PLCO11066
C.No.D1/6918/26 Date: 12.10.2026
NOTICE FOR INVITING e- ACTION CUM e- TENDER FOR THE
SALE OF WIND FALLEN EUCALYPTUS TREES IN KEERIPARAI
DIVISION ON TONNAGE BASIS.
(Only through e-tendering mode)
Table-A
1 Name of work e-Tender cum e-Auction for the sale of Wind
fallen Eucalyptus Trees in Keeriparai Division
As indicated in Annexure - I, through online
Non — Refundable Tender Fee As indicated in Annexure - I, through online
4 | Downloading of Tendering document from From 15.10.2026 onwards
website
5 Last date and time for submission of tender 28.10.2026 up to 5.30 pm
through online
Opening of Technical Bid online 30.10.2026 — 11.30 am
Date & Time
ர்‌ Place Registered Office, Arasu Rubber Corporation,
Vadasery, Nagercoil.

<!-- page 2 -->

Date & Time for e- Auction The exact date and time for e-auction will be
intimated later to the technically qualified
Tenders by e-mail/SMS
S| Opening of Financial Bid online Date & Time | After completion of e- auction.
Documents to be uploaded by the Tenders The scanned copies of the following original
during e-submission documents should have to be submitted along
with the e-tender.
1) PAN Card
2) 0.5.1. Registration Certificate
3) LT. Return
Details of felling area ‘As indicated in the Annexure —I
Clarification to be sought for Divisional Manager, Keeriparai Division.
e-TENDER CUM உ AUCTION TERMS & CONDITIONS

1. Arasu Rubber Corporation invites online offers in two stage Two cover system
(Qualification and Financial Bid) from Contractors Right to removal of wind fallen
Eucalyptus trees in Keeriparai Division of Arasu Rubber Corporation as per terms &
conditions stated hereinafter through online Tender- cum —Auction through the official
e-Tendering Portal of Government of Tamil Nadu (tntenders.gov.in). Interested
applications having Digital Signature Certificate (DSC) issued by any agency
authorized by the Controller of Certifying Authority (CCA, Government of India).

2. The TamilNadu Transparency in Tenders Act 1998 and TamilNadu Transparency in
Tender Rules 2000 are applicable to this tender. The tenderers shall upload relevant
documents in their offer without fail.

3. The entire bidding process is divided into two stages (Stage-I and Stage-II) and will be
through e-tender cum e-auction as detailed below:

Stage - 1: e-tender
Stage — II: e-auction
The e-tender stage shall have two parts:
. Technical Bid (Part-I) and
e Financial Bid (Part-II)
4. The Contractors who are interested/ willing can participate in the e-tender cum e-
auction.

<!-- page 3 -->

|

5. DATE & TIME. The exact date and time for e-auction will be intimated later to the
technically qualified Tenderers by e-mail.

6. Contractors entering into litigation on any contract made by them shall not be allowed
to participate in any succeeding tenders or auction of Arasu Rubber Corporation, until
the litigation is settled.

7. Full tender specification can be downloaded from Arasu Rubber Corporation website
www.arasurubber.tn.gov.in https://tntenders.gov.in and submit the tender with relevant
documents. At any time after the commencement of e-tender and before the closing of
the event, Chairperson and Managing Director, Arasu Rubber Corporation may make
any changes, modifications or amendments to the tender documents and same will be
intimated to the contractor through corrigendum.

8. The rate should be quoted per tonnage basis including all related costs viz., cutting &
removal charges, etc. The tenders not submitted in the authenticated departmental form
(ie. price schedule should be submitted in BOQ format only) along with Tender Fee,
Earnest Money Deposit (EMD) on or before the due date through online will not be
taken. The tender which are in any way incomplete will not be considered. Tenders
received after due date and time will be summarily rejected. The Arasu Rubber
Corporation will not be responsible for the delay in online submission.

9. The contract is not transferable. Arasu Rubber Corporation shall not be responsible for
any technical failures / reasons, if the tenderer is not able to upload the documents
within the due date of submission. The e-tender / offer without EMD, Tender fee shall
not be accepted.

10. Tender should be submitted as per tender notification schedule in Annexure-I.The
EMD, Tender fee should be remitted as per the tender notification schedule in
Annexure-I through online. The Tender fee will not be refunded at any cause. EMD
will be refunded to the unsuccessful tenderers. EMD will not carry any interest.

11. The total No. of trees shown in the annexure-I. The tenderer, if he/she wants, shall
inspect the coupes at their own cost and expenses and satisfy themselves regarding the
numbers, condition, and quality etc. of trees before quoting the rate, No dispute will be
entertained after submitting the tender documents. The decision of the Chairperson and
Managing Director will be final in all cases

12. Tender offers submitted in any other mode, other than as mentioned above, will be
rejected.

<!-- page 4 -->

13. Participants who intend to tender/bid on behalf of another firm/person should be a
holder of duly executed specific Power of Attorney on a stamp paper of requisite value
in his favour authorizing him to do so, or the legal heir of such persons.

14. Tender submitted jointly by more than one person shall not be accepted unless such
person/persons are members of a Registered company or Firm, and the tender submitted
is on behalf of such company/firm.

15. Tenders/Bids from persons who are black listed, convicted or who are minors or who
have failed to pay Government dues or who are insolvent will not be accepted. The
Chairperson and Managing Director or the Officer authorized by him reserves absolute
authority in accepting/rejecting any tenders/bids.

16. The Chairperson and Managing Director, Arasu Rubber Corporation has the
discretionary powers to relax any of the condition (s) in the interest of the Corporation.

17. Technical bid shall be evaluated. The decision of the Chairperson and Managing
Director, Arasu Rubber Corporation on evaluation of the bids shall be final and binding
to every Tenderer.

18. The successful tenderer/bidder should execute an agreement in sufficient stamp paper
within five (5) days from the date of remittance of the advance amount to the Arasu
Rubber Corporation. The agreement will be valid for two months from the date of
execution of agreement.

19. The Contractor/tenderer/bidder shall pay the Income Tax/GST and any other levies for
the value of latex, scrap and rubber wood to the Corporation along with payment of
each installment. In turn, the Corporation will remit the entire amount collected
towards IT/GST/any other levies to the concerned authorities.

20. The sale value (inclusive of I.T, GST if any) should be remitted by the successful
Contractor/bidder.

21. The highest tender/ bidder should deposit a sum of Rs. 5,00,000/- (Rupees five lakhs)
as an advance payment into the account of the Arasu Rubber Corporation within seven
days from the date of receipt of the Confirmation order.

22. The sale value of the Eucalyptus trees removed from the site shall be adjusted against
the advance amount received.

23. When the balance amount out of the advance already remitted reaches Rs.1,00,000/- in
the Corporations account, the successful bidder/ tenderer shall remit a further sum of
Rs. 5,00,000/- as advance into the account of Arasu Rubber Corporation. The advance
amount shall be remitted without fails based on the weight of the Eucalyptus trees
proposed to be transported out of the site. The work shall be permitted to be carried out
only after the required advance amount has been remitted. If the contractor fails to make

<!-- page 5 -->

payment within stipulated time/ due date time, time will be extended up to 15 days with
penal interest of 12% of the sale value amount for every delayed day. Again, if the
contractor fails to make payment, the contractor should pay the sale amount along with
penal interest of 12% and fine amount fixed by the Chairperson and Managing Director,
Arasu Rubber Corporation. After this, if fails to make payment, the confirmation order
will be cancelled and EMD will be forfeited and wind fallen Eucalyptus trees will be
brought for the re e-Auction for sale. The contractor shall not claim for the profit if any |
received on account of such re-auction by the Arasu Rubber Corporation.

24. During the contract period, the Corporation will not entertain any complaint of loss or
damage on account of strike, flood, fire, earthquake, lightening, thunder, theft, pilferage
or other natural calamities etc. to those for which order has been issued. The
Corporation will not be liable for any compensation for loss or damage as stated above
to the contractors/bidders on the life and property of their workers at any time/place
during execution of work.

25. The Chairperson and Managing Director or any officer authorized by him has the right
to inspect the field during the contract period. They will further have the right to check
the work, loading and transport of Eucalyptus trees at any time at any place and under
all circumstances.

26. The successful tenderer/bidder should ensure that there should not be any loss or
damage, theft pilferage etc. to the latex, scrap, tree lace, cuplump or any other properties
of Arasu Rubber Corporation in non-contracted areas under any circumstances if any
complaint, theft, pilferage, etc. is proved, the entire contract will be cancelled and the
EMD along with the remitted amount will be forfeited and in addition, further action
will be taken by the Chairperson and Managing Director to recover the loss sustained
by the Corporation and levy a penalty to the Contractor.

27. There should not be any obstruction from the contractors or their workers etc. for
carrying out the normal duties of Arasu Rubber Corporation staff and workers.

28. No permanent construction/roads should be erected/formed in the contracted area.
Temporary sheds can be fixed by the contractor after obtaining necessary written
permission from the Divisional Manager by paying required fee and this temporary
sheds have to be removed by the Contractor at his expenses after the contract period is
over.

29. The members of the contractor firm/company shall enter the plantation area possessing
identity cards issued by the firm/company/the contractor himself and the
contractor/firm/company is solely responsible for any of their actions during the
contract period.

<!-- page 6 -->

30. The Eucalyptus trees shall be transported through Arasu Rubber Corporation area
between 6 A.M. to 6 P.M. only during the working days. Any work will not be allowed
on any holidays.

31. If the contractor disobeys any of the instructions on this, the Chairperson and Managing
Director, Arasu Rubber Corporation has the discretion to cancel the contract and to
conduct re-tender at their risk in addition to the forfeiture of Security Deposit and value
already paid..

32. In case of loss, if any, sustained to Arasu Rubber Corporation on account of violation
of terms and conditions, the contractor will be liable to reimburse to Arasu Rubber
Corporation Limited the amount fixed by the Chairperson and Managing Director at his
discretion.

33. The tenderer/bidder should not employ any worker/staff who are permanently
employed by the Corporation.

34. During the contract period and at the time of carrying out the work if any accident,
damage, etc. happens to the workers, agent or anybody employed by the Contractor,
the contractor will be solely held responsible.

35. After completion of contract, the contractor shall obtain a certificate for completion of
the work from the concerned Divisional Manager, after this only the release of Security
Deposit will be considered. However, Chairperson and Managing Director reserves the
right to get the completion certificate super checked and verified by himself or any
other officer authorized by him, before releasing the Security Deposit or taking further
action to recover the loss and levy penalty, if required.

36. Necessary permit will be given by the competent authority to the contractor for the
transport of wind fallen Eucalyptus trees from the area and the cost will be recovered
from the contractor. The unused permits should be surrendered immediately to the
competent authority after the felling operations are over.

37. The Contractor may transport the wind fallen Eucalyptus trees either in person or he
may authorize his agent in writing to do so. The person authorized by the contractor
shall be considered as duly accredited agent of the contractor. The specimen signature
of the authorized agent will be communicated to the concerned for identification ete.

38. The contractor should do work in the earmarked area only. Any breach of condition
will result in termination of contract.

39. The contractor is allowed to remove only the wind fallen Eucalyptus trees mentioned
in the Annexure. Any other trees, viz., boundary trees, teak trees and trees of any other

<!-- page 7 -->

species should not be felled under any circumstances. If any such irregularities are
noticed the contract will be terminated spontaneously without notice and further action
will be proceeded as deemed fit and Chairperson and Managing Director or his
authorized Officer can take further necessary action to recover loss and levy a penalty
on the contractor for causing such loss.

40. Any delay on the part of the tenderer/bidder to clear fell and transport the trees beyond
the time limit will not be accepted. Therefore, no extension of time beyond the Contract
period shall be granted in the normal course except under the circumstances that are
proved to be beyond the control of the tenderer/bidder. The Chairperson and Managing
Director may at his discretion, grant extension of time to a reasonable extent after
satisfying himself about the bonafide circumstances with fine if necessary.

41. The tenderer/bidder shall take precautions not to damage or obstruct the telegraph,
telephone or electric lines and posts during the contract period.

42. The Contractor hereby does bind himself to perform every duty and act expressed in
the conditions of the tender notice. In the case of any act or omission on the part of the
contractor, his employees and agent, which amount to a breach of the said conditions,
the successful tenderers shall have to pay on demand, by the Chairperson and Managing
Director, the loss and penalty at the discretion of the Chairperson and Managing |
Director.

43. The tenderers/bidders shall not be permitted to do any other work apart from removal
of Eucalyptus trees.

44. The Contractors who are willing to participate e-tender through online, should remit
Tender Fee +18% G.S.T as indicated in Annexure - I through online.

45. Corporation will not provide men or materials for the slaughter tapping and felling of
the trees. All the presently available cup hangers, spouts coconut shells and other
materials will be taken over by the Corporation and it cannot be given to the contractor.

46. The contractor is responsible for any illicit felling, pilferage of forest produce within
one hundred meters from the boundary/Periphery of each bit/Coupe as shown in
Annexure — I, The contractor or persons authorized by him shall not enter in any other
area of Arasu Rubber Corporation or reserve forest during the contract period.

47. The contractor should give/render the accounts before 10" of every month regarding
the weight/ quantity of Eucalyptus removed/transported by him from the coupe as well
as the quantity of rubber latex transported from the area without fail under the cover of
permit.

<!-- page 8 -->

48, In case of strike, agitations, lockouts or other factors beyond the control of the
Corporation under which the contractor is not able to work, the sale shall either be
cancelled or the period for payment of money and for removal of the materials,
the voidah shall be extended proportionately.

49. The contractor shall be present in the contract area during the contract period. In case,
he is unable to be present, he may appoint an agent approved by the Chairperson and
Managing Director, Arasu Rubber Corporation, provided the contractor shall furnish a
power of Attorney on a stamped paper of required value, in his favour to represent him
on his behalf to do any act which he was undertaken to do under the terms of the
agreement duly authorized by Notary. He or his authorized agent shall remain present
in the contract area throughout the contract period. Working in the contract area shall
not be allowed in the absence of the contractor or his approved agent.

50. No materials shall be removed from contract area unless it is covered by a transit pass,
issued in accordance with Forest Act and shall be stamped, where such stamping is
needed as per the rules in force, with the registered property mark of the contractor.
The property mark shall be got registered with competitive authority before making use
of it, on payment of the prescribed Registration fees. The above mentioned mark shall
abide by the transit rules in force in the respective states through or to which the forest
produce is sought to be exported.

51. The tenderers/Bidders shall not be permitted to do any agricultural works during the
contract period in the plantation area.

52. Should any dispute arise either in the working of the rubber plantations or with regard
to the interpretations of the terms and conditions, the decision of the Chairperson and
Managing Director, Arasu Rubber Corporation, Nagercoil shall be final and binding on
tenderer.

53. The Contractor shall at all times abide by the provisions of Tamil Nadu Forest Act,
1882, Wildlife (Protection) Act 1972 and Forest Conservation Act 1980 and the rules
and modification thereon. For any violation of any Act or Rule relating to conservation
of Forests and Wildlife, necessary action will be initiated as per Rule of Law. Further,
for any loss sustained by the Corporation, Chairperson and Managing Director shall
recover the loss and levy a penalty on the contractor. Also, the contract may be
terminated by the Chairperson and Managing Director for any violation of any of the
Conditions.

54. The Contractor shall be responsible for the damages caused to the Arasu Rubber
Corporation Roads and buildings and other allied Corporation materials etc. under the
Jurisdiction of Arasu Rubber Corporation.

<!-- page 9 -->

55. The Contractors participating in the e-auction cum e-tender is deemed to be evidence
as agreeing to all the conditions in this tender notice.
56. The Court in Nagercoil alone will have jurisdiction to deal with the legal disputes
pertaining to this contract.
Annexure —I
Girth class i 2
1' class incm ட்‌
3
ன்‌ ஐ ச
9 2 1 a a 5
4 8 ல. ot
a} Pit. | டி... | இடன்‌. 2
is) a னத்‌ eee BO
ச: 5
a |e a ந
oO
I. Division: Keeriparai Unit: Keeriparai
ESBS கிளிப்ப... Zee
BESS Seen இ; ய
இ. 1-1 111]
காக ரை எ எர
Unit: Paraliar
Basso eas அறிதி
காடா யா யாய
31 ஜா | 61-00 க |
காக உகார டா உப
J அனி... ரில
Labour 3 7
Colony
Sd/-N.SATHEESH,
Chairperson and Managing Director.
To
1) All Registered Contractor of Arasu Rubber Corporation.
2) Putta Raju,
617,18" Cross 44 main,
Opposite Bank of Baroda,
Vidyananayapuram,
Mysore, Karnataka — 570008.

<!-- page 10 -->

3) Putta Raju,
PADMA Wood Industries,
No.86, Shed No.2, Industrial Sub — Urban,
2" stage, Fort Mohalla, Mysore,
Karnataka — 570008.
Copy submitted to:
1. The Additional Chief Secretary to Government, Environment and Forests Department,
Chennai-9.
2. The Principal Chief Conservator of Forests & Head of Forest Force, Forest Head Quarters,
GuindyVelachery Main Road, Near Kannigapuram Check Post, Guindy, Chennai-32.

3. The Chairman, Arasu Rubber Corporation Ltd., Chennai.

Copy to:

1. The Conservator of Forests and Field Director, KalakadMundanthurai Tiger Reserve,

Tirunelveli.

2. The District Collector, Kanyakumari District, Nagercoil

3. The District Forest Officer & Wild life Warden, Kanyakumari Division, Nagercoil

4. All Divisional Managers, Factory Manager and Vigilance Officer to display in their notice
board for wide publicity.

5. Indian Plywood Industries Research & Training Institute (IPPRTI) HMT line Road off
Tumkur Road, PO, Yeswanthpur, Bangaluru, Karnataka 560 022 (email Id:
director@pirti.gov.in).

6. SOPMA (Sawmill Owners and Plywood Manufactures Association) City Estates,
M.C.Road, Perumbavoor, Ermakulam, Kerala - 683 542 (email):
Sopmakerala‘@gmail.com)

7. தலைவர்‌, கன்னியாகுமரி மாவட்ட மரவியாபாரிகள்‌ & மர ஆலை
உரிமையாளர்கள்‌ சங்கம்‌, 1-347 8, MS Road, கட்டையன்‌ விளை, நாகர்கோவில்‌
- 629 003.

/t.c.b.o/ ப்‌
1020 :
Senior Draughting Officer (i/c).
