---
doc_id: "b1ac3adcac1e7226"
source_url: "https://arasurubber.tn.gov.in/windfallentendernotice.pdf"
ministry: "Arasu Rubber Corporation Limited, Tamil Nadu"
title: "Tender for the sale of Wind fallen trees at Chithar Division- Tender Notice"
date: ""
pages: 5
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "3d9e2fb17929df51"
---

<!-- page 1 -->

்‌ ARASU RUBBER CORPORATION
யூ ர (A Government of Tamil Nadu Undertaking)
Chithar Division, Chithar Post 629 161.
CIN No. U25110TNI984PLCO1 1066
GST No.33AAECA2671E1Z4
Ref.No: D/1487/26 Dated:)3 .10.2026
SHORT TENDER CUM AUCTION NOTICE FOR THE RIGHT TO DISPOSAL OF
THE WIND FALLEN RUBBER TREES IN CHITHAR UNIT OF CHITHAR
DIVISION DURING 2026-2027
Seperate sealed tenders are invited from the Registered Contractors of Arasu Rubber

Corporation for the right to do for the removal of above 10 year old and below 10 years old Wind

fallen rubber trees as scheduled in the Annexure in Arasu Rubber Corporation Chithar Division “As

is where is condition". The Earnest Money Deposit for the Tender cum auction is as shown in the

Annexure (Payable through a Demand Draft drawn in favour of The Chairperson and Managing

| Director, Chithar Division, Arasu Rubber Corporation, Payable at Canara Bank Nagercoil). Sealed
tenders in the prescribed form will be received by The Divisional Manager Chithar Division at his
office up to 10.30 AM on 23.10.2026 as shown in the annexure. Tender received after due date
and time will not be considered.. Auction will be conducted on 23.10.2026 at 11.00 Am and tender
will be opened after auction by the Divisional Manager, Chithar Division or any officer authorized
by him in the presence of tenderness/bidders. If the date of tender cum auction happens to be a
holiday, the tender shall be received and opened on the next working day at the appointed time and
place after auction. If on account of unavoidable circumstances, the auction could not be conducted
another date will be given for conducting the auction. Such received Sealed Tender will be opened
only at the time of auction. The intimation of such date of auction will be dispatched at least 10
days before the date of auction. Only persons who have submitted the tender documents on or
before the due date and time will be allowed to participate in the auction. On account of such
delayed auction the Corporation will not be responsible for payment of any interest on the E.M.D
enclosed along with the tender schedule and no such claim will be entertained by the Corporation.
TENDER CUM AUCTION CONDITIONS

1. Only the Registered Contractor of Arasu Rubber Corporation are eligible to offer their
rate in the tender and to attend auction.

2. Intending tenderers will on application in writing be supplied the tender schedule on written
request and payment of cost of Tender document plus G.S.T @ 18% As scheduled in the
Annexure by Digital Payment to Divisional Manager, Chithar Division during office hours.
The tender schedule will be issued to the registered contractors of Arasu Rubber Corporation
only.

3. The tender schedule will be available for sale in the Chithar Divisional Manager's Office
during office hours on 21.10.2026 and 22.10.2026 up to 5.30 PM if the last date for sale of
tender schedule happens to be a holiday the next working day will be last date for sale of
tender schedule.

4. The total No. of wind fallen rubber trees shown in the Annexure are inclusive of elephant
damaged and broken trees if any. The tenderer should inspect the Coupes and satisfy himself

regarding the numbers before quoting the rate. No dispute will be entertained after submitting
the tender documents. The decision of the Chief Executive will be final in all cases.
Ea CE Scanned with OKEN Scanner

<!-- page 2 -->

5. Conditional tender, optional tenders will not be considered and they shall be summarily
rejected.

6. Tender submitted jointly by more than one person shall not be accepted unless such persons
are members of a registered company of Firm, and the tender submitted is on behalf of such
company /firm.

7. Tenders/ Bids from persons who are black listed, convicted or who are minors or who have
failed to pay Government dues or who are insolvent will not be accepted.

8. All correction/additions/alterations in the tender schedule should be attested with full
signature.

9. The tenderer / bidder shall at the time of submitting the tender furnish his specific address to
which all communication should be sent. Divisional Manager, or any other executive staff of
Arasu Rubber Corporation, will not be responsible for the consequences, if any
communication sent to that address is not received by him. The responsibility to receive all
communication is vested with the tenderer only.

10. Divisional Manager has the discretionary power to relax any of the condition in the interest
of the Corporation.

11. No post sale of a post tender offer will be accepted.

12. An advance amount @ Rs. 2000/- per tree for above 10 years old trees and Rs. 1000 per tree
for below 10 years old trees should be remitted by the successful contractor/bidder by Demand
Draft, Payable in favour of The Chairperson and Managing Director, Arasu Rubber
Corporation on completion of sale. If the sale value exceeds the amount of advance collected,
the excess amount should be deposited before delivery of wind fallen rubber trees.

13. The tenderer/bidder will be allowed to enter into the field for removing wind fallen trees, only
after paying the prescribed advance amount.

14. The E.M.D has to be remitted through Demand Draft drawn on Canara Bank Nagercoil in
favour of The Chairperson and Managing Director, Arasu Rubber Corporation. This should
be enclosed along with tender. Tender without E.M.D will not be considered. All tendered
can participate in the auction. The removal of wind fallen trees should be made within one
month from the date of execution of agreement.

15. The successful tenderer/bidder should execute an agreement in sufficient stamp paper within
7 days from the date of receipt of the confirmation order. “On receipt of intimation regarding
the acceptance of the tender the successful tenderer should execute necessary agreement with
the Divisional Manager, Chithar Division failing which the amount of EMD already deposited
by him will be forfeited to the Arasu Rubber Corporation, and the works done at his risk and
responsibility”.

16. The E.M.D of highest tenderer/bidder will be retained and the E.M.D of others will be
returned immediately after opening the tender. E.M.D of the successful tenderer/bidders will
be retained as Security Deposit and shall be returned after satisfactory completion of the
contract. The E.M.D/S. D does not carry any interest.

17. For belated removal of tree, the tenderer/bidder should pay Rs.50/- per day per tree. Contract
period will be allowed for only One month. The contract period will not be extended for the
belated payment period of delay in operation for any reason whatsoever.

18. The Chief Executive of Arasu Rubber Corporation has discretion to accept or reject all or any
offer received in the tender cum auction without assigning any reason whatsoever. The
tenderer/auction may also be cancelled at any time before the issue of confirmation order by
the Chief Executive of Arasu Rubber Corporation at his discretion.

C scanned with OKEN Scanner

<!-- page 3 -->

19. During the contract period the Corporation will not entertain any complaint of loss or damage
on account of strike, flood, fire, earthquake, lightning, thunder, theft, pilferage or other natural
calamities etc. to those for which order has been issued. The Corporation will not be liable
for any compensation for loss or damage as stated above to the contractor tenderer/bidders on
the life and property of their workers at any time, under any circumstances. |

20. The Divisional Manager or any officer authorized by Divisional Manager has the right to
inspect the field under contract during the contract period. They will have the right to check
the felling, loading and transport of wind fallen rubber trees at any time any place and under |
all circumstances.

21. The successful tenderer / bidder should ensure that there should not be any loss or damage,
then pilferage etc. to the latex, scrap, tree, lace, cup, lump or any other properties of Arasu
Rubber Corporation under any circumstances if any complaint, theft, pilferage, etc. is proved
the entire contract will be cancelled and the E.M.D along with value paid will be forfeited and
in addition to that legal action will be taken by Arasu Rubber Corporation.

22. There should not be any obstructions from the contractors or their workers etc. for carrying
out the normal duties of Arasu Rubber Corporation by Arasu Rubber Corporation staff and
workers.

23. Tax such as 18% of GST and 2.5% of IT will be recovered from the successful tenderer/
bidder on every load Value of Plywood, Cutends - Such Tax will not be recovered for the sale
value of Firewood Category.

24. Other than the fallen rubber trees specified, no tree/ firewood / forest produce cannot be taken
by contractors or his agent or his workers etc.

25. Stumps or standing dead trees should not be removed. Only fallen trees are allowed for
removal without any omission.

26. The Corporation will not provide men or materials for the disposal of wind fallen rubber trees.

27. No permanent or temporary construction should be erected in the contracted area.

28. The tenderer / bidder shall not be permitted to lay temporary roads that may be required for
transport of wind fallen rubber trees inside the plantations.

29. The acceptance or rejection of tender will be at the discretion of Divisional Manager only. If
the tenderer disobeys any of the instructions on this, the Divisional Manager has the discretion
to cancel the contract and to conduct retender at their risk in addition to the forfeiture of
Security Deposit and value already paid.

30. The loss if any sustained to Arasu Rubber Corporation on account of violation of rules and
conditions, the tender will be liable to reimburse to Arasu Rubber Corporation the amount
fixed by the Divisional Manager at his discretion.

31. The Corporation's staff/workers cannot participate in the tender. For any dispute arising out
of the transaction the Divisional Manager has the discretion to decide the matter and his
decision shall be final.

32. The tenderer / bidder shall not employ any worker who is engaged for work by the
Corporation.

33. The tenderer/ bidder shall not employ any person whom the Divisional Manager concerned
may object to.

34. During the contract period and at the time carrying out the work if any accident, damage, etc.
happens to the workers, agent or anybody of the Contractor or the staff of Arasu Rubber
Corporation, the Corporation will not be responsible and the contractor will be solely held
responsible.

C scanned with OKEN Scanner

<!-- page 4 -->

35. The Court in Nagercoil alone will have jurisdiction to deal with the cases/disputes pertaining
to this contract.

36. After completion of contract, the contractor will obtain a certificate of completion of the work,

37. The change in condition or introducing new conditions over and above the existing Condition
relevant to the sale will be informed to the tendered at the time of opening tender or at the
time of confirmation of sale which they shall have to adhere to.

38. The tenderer/ bidder should furnish a list containing the name of his workers with their
permanent address, father's name/husband’s name with age who will be engaged for disposal
of Wind fallen rubber trees enabling the Corporation employees to check and to prevent any
unauthorized person entering and operating in the coupe.

39. The tenderer/ bidder are not allowed to fell other than fallen rubber trees and if any fe| ling is
noticed their contract will be terminated. The tenderer/ bidder is responsible for any illicit
felling, pilferage of forest produce.

40. The conversion and stacking of wind fallen rubber trees shall be done by the tenderer/ bidder
at his own cost and under the supervision of the staff of the corporation.

41. The tenderer / bidder shall take precautions not to damage or obstruct the telephone or electric
lines and posts during the currency of the contract.

42. The tenderer/ bidder shall be responsible for all damage that may be caused to any standing
tree and other property belonging to the Corporation within the contract area by fire, illicit
felling or any other cause traceable to any act or omission on the part of the contractor his
agents or servants, such loss caused shall be paid by the Contractor, on demand by the
Divisional Manager. Besides the contract is liable to be cancelled and all the money and
deposits of the contractor are liable to be forfeited.

43. All operations required to be done under the above sale conditions shall be performed by the
contractor at his own cost and he shall not receive any payment for same.

44. The contractor or his workers should not obstruct the regular work of the plantations.

45. Only saw should be used for cutting the wind fallen rubber trees.

46. If any dispute arises either in the working of the rubber plantations or with regard to the
interpretations of the terms and conditions, the decision of the Divisional Manager shall be
final and binding on tendered.

47. Any infringement of tender notice conditions and provisions of Tamil Nadu Forest Act, and
the rules as amended from time to time will entail cancellation of sale and forfeitures of
amounts paid already.

48. The tenderer/ bidder shall be responsible for the damages caused to the Arasu Rubber
Corporation Roads and buildings and other allied Corporation materials etc. under the
jurisdiction of Arasu Rubber Corporation.

49. Empty lorry should be weighed before loading the fallen rubber trees on the nearest Weigh
Bridge and after loading of wind fallen rubber trees again weighment should be taken to know
the weight of fallen rubber trees in the same nearest Weigh Bridge.

50. All the activities including transportation of wind fallen trees will be done between 7 AM. To
6 PM. only.

51. All Stumps should be retained in the coupe itself stumps are not allowed to Transport and
cannot be taken by the Contractor. |

C scanned with OKEN Scanner

<!-- page 5 -->

Annexure
No of fall
la Coupe No ட்‌ of fallen aes து Fennel Abvance Cost of Tender form Period of
mbber: trees branches (Rs.) (Rs.) with 18% GST Contract
Chithar Unit - Above 10 Years old trees
month from
execution of
510 + 92 (GST) =
Chithar Unit - Below 10 Years old trees
கை ee கை வை
கண ச ணை ன tf நை ய
250 +45 (GST) =
TOTAL 295

S

& >
yy 2»
Chithar ion.
To
All Registered Contractors, Arasu Rubber Corporation.
Copy submitted to: ; ;
The Managing Director, Arasu Rubber Corporation, Nagercoil.

Copy to: All Divisional Managers, Factory Manager, Keeriparai Rubber Factory and
Vigilance officer Arasu Rubber Corporation Kulasekharam to display in their notice
board for wide publicity.

Copy to: —_ Notice Board at Divisional Office.

Copy to: District Forest Officer and Wild life warden, Kanyakumari Division, Nagercoil.

(6 - Scanned with OKEN Scanner
