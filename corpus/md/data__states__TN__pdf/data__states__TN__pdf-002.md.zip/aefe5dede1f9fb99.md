---
doc_id: "aefe5dede1f9fb99"
source_url: "https://www.msuniv.ac.in/uploads/circular/pdfs/teachers.pdf"
ministry: "Manonmaniam Sundaranar University, Tamil Nadu"
title: "Know More"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f538a42f4949e442"
---

<!-- page 1 -->

MANONMANIAM SUNDARANAR UNIVERSITY

(Reaccredited with “A+” Grade (3.46) by NAAC in 4th Cycle)

ABISHEKAPATTI, TIRUNELVELI-627 012
NOMINATION PAPER

ELECTION OF TWO MEMBERS TO THE SYNDICATE
BY TEACHERS OF
AFFILIATED COLLEGES, OTHER THAN PRINCIPALS, FROM AMONG
THEMSELVES WHO ARE MEMBERS OF THE SENATE, IN ACCORDANCE
WITH THE SYSTEM OF PROPORTIONALREPRESENTATION BY MEANS OF
THE SINGLE TRANSFERABLE VOTE UNDER CHAPTER IV - SEC 23(b) CLASS
II- OTHER MEMBERS SUB SECTON(2) -2026

Name of the Candidate
:
(Please state also the academic
degrees taken for including after
the name in the Ballot Paper)
Number of the Candidate in the
electoral roll, if any.

:

Address of the Candidate

:

------------------------------------------------------------------------------------------------Name of the Proposer
:
Number of the Proposer in the
electoral roll, if any.

:

Address of the Proposer

:

Signature of the Proposer
:
Date .............
------------------------------------------------------------------------------------------------Name of the Seconder
:
Number of the Seconder in
the electoral roll, if any.

:

Address of the Seconder

:

Signature of the Seconder
:
Date .............
-------------------------------------------------------------------------------------------------

PTO

<!-- page 2 -->

CONSENT OF THE CANDIDATE
BY TEACHERS OF
ELECTION OF TWO MEMBERS TO THE SYNDICATE
AFFILIATED COLLEGES, OTHER THAN PRINCIPALS, FROM AMONG
THEMSELVES WHO ARE MEMBERS OF THE SENATE, IN ACCORDANCE
WITH THE SYSTEM OF PROPORTIONALREPRESENTATION BY MEANS OF
THE SINGLE TRANSFERABLE VOTE UNDER CHAPTER IV - SEC 23(b) CLASS
II- OTHER MEMBERS SUB SECTON(2)- 2026

"I hereby declare that (A) I am not a member of the above authority to which I seek election;
(B) My term of office as member of the above authority, to which, I seek
election would also expire before the membership for which I am
seeking election takes effect.
And I agree to serve in the ........................................ if elected.
(C) I also further declare that the facts stated above are true to the best
of my knowledge and belief and in the event of any defects or
mistakes being found out in the aforesaid declaration of mine, my
nomination is liable to be rejected.
(D) I do hereby agree that disputes of any nature arising out of the
election to the Syndicate or matters connected therewith shall be
redressed by arbitration in accordance with Arbitration and
Conciliation Act 1996 as amended from time to time. Such arbitration
shall be presided over by a sole arbitrator to be nominated by the
University. The decision of the arbitrator shall be final and binding on
the parties.
DATE:

Signature of the Candidate

NOTE: 1. Among (A) and (B) above, please strike out the clause which is not applicable.
2. An elector shall be eligible to subscribe either as proposer or as seconder in
the nomination papers, only as many time as there are vacancies but not
more.
3. Every nomination shall be in writing signed by the proposer and seconder.

<!-- page 3 -->

MANONMANIAM SUNDARANAR UNIVERSITY
RE-ACCREDITED WITH ‘A+’ GRADE BY NAAC (4th Cycle)
ABISHEKAPATTI, TIRUNELVELI-627012
DECLARATION PAPER
BY TEACHERS OF
ELECTION OF TWO MEMBERS TO THE SYNDICATE
AFFILIATED COLLEGES, OTHER THAN PRINCIPALS, FROM AMONG
THEMSELVES WHO ARE MEMBERS OF THE SENATE, IN ACCORDANCE
WITH THE SYSTEM OF PROPORTIONALREPRESENTATION
BY MEANS
OF THE SINGLE TRANSFERABLE VOTE UNDER CHAPTER IV - SEC 23(b)
CLASS II- OTHER MEMBERS SUB SECTON(2)- 2026

Elector's Name:
Number in the electoral roll, if any:

ELECTOR'S DECLARATION
I, ____________________________________________________________
(Name in full and designation) declare that, I am an elector for the above election to the
_______________________ by the _______________________________________
and have signed no other declaration paper at the election.

Date:

Signature of the candidate

Station:

Address
