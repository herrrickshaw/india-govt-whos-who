---
doc_id: "a9ff2cdf9aa7adfd"
source_url: "https://b-u.ac.in/sites/b-u.ac.in/files/Recruitment/2026/nov/pro/pro_notification.pdf"
ministry: "Bharathiar University, Coimbatore, Tamil Nadu"
title: "Notification…                                         Oct    29               E-tenders are invited for the Procurement of Electronic Consumable to the Department of Electronics and Instrumentation"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "630bd7a3f42cb7d9"
---

<!-- page 1 -->

NOTIFICATION No. BU/Estt./E5/2026/PRO/16943

Date 30.10.2026

RECRUITMENT NOTIFICATION
Applications are invited for the Post of

PUBLIC RELATIONS OFFICER
-------------------------------------------------------------------------------QUALIFICATION
: As prescribed by the Syndicate of Bharathiar University.
PAY

:

Pay Level 25 (59300-217600).

AGE

:

Shall not exceed 42 years and 47 years for SC/ST on the
date of notification.

No. of Post
: 1 Post.
-------------------------------------------------------------------------------Last date for receipt of the filled in application along with
Registration fee including Application fee of Rs.600/- for General category and
Rs.300/- for OBC/SC/ST is 30.11.2026.

REGISTRAR
