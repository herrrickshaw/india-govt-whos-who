---
doc_id: "fb01c90bcfca53f9"
source_url: "https://mtcbus.tn.gov.in/asset/tenders/Tendernotice_2.pdf"
ministry: "Metropolitan Transport Corporation (Chennai) Ltd., Tamil Nadu"
title: "Tender ID No: 2026_MTC_668487_1, Ref: 00033/Proj/MTC/2025 - Procurement, Supply, Operation and Maintenance of 300 Air-Conditioned 7Metre Low Floor Electric Buses and Development of Allied Electrical and Civil Infrastructure under the Gross Cost Contract (GCC) model for Feeder Service. The Pre-Bid me"
date: ""
pages: 370
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "42306f763940e6e3"
---

<!-- page 1 -->

Request for Proposal
Through e-procurement Portal of Government of Tamil Nadu
(https://tntenders.gov.in, https://mtcbus.tn.gov.in/, https://tnidb.tn.gov.in)

REQUEST FOR PROPOSAL

For

Procurement, Supply, Operation and
Maintenance of 300 AC 7metre Low
Floor Electric Buses and Development
of Allied Electric and Civil Infrastructure
on Gross Cost Contracting
February 2026
Volume I

Request for Proposal

Volume II

Draft Concession Agreement

Issued by

No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002

<!-- page 2 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

\METROPOLITAN TRANSPORT CORPORATION (CHENNAI) LTD.
GOVERNMENT OF TAMIL NADU (GOTN) UNDERTAKING
NO.2, PALLAVAN ILLAM, PALLAVAN SALAI, CHENNAI – 600 002
Notice Inviting e-Tender
REQUEST FOR PROPOSAL (RFP) FOR PROCUREMENT, SUPPLY, OPERATION AND
MAINTENANCE OF 300 AC LOW FLOOR 7M ELECTRIC BUSES AND DEVELOPMENT OF
ALLIED ELECTRIC AND CIVIL INFRASTRUCTURE ON GCC
Metropolitan Transport Corporation (MTC) (the “Authority or MTC”) is a Government of Tamil
Nadu (GoTN) undertaking registered under Companies Act, 1956. It is entrusted with providing
city bus services in Chennai Metropolitan Area. MTC currently operates a fleet size of more than
4030 buses as of February 2026 on 671 routes and caters to more than 33.60 lakh passengers
daily handling operations through 35 depots, this includes 124 Small Buses which are being
operated as Feeder Services. MTC is planning to improve the connectivity between
unserved interior urban neighbourhoods, sub-urban railway stations, MRTS, metro
stations and for MTC’s regular services through introduction of feeder services. Hence,
MTC now invites eligible entities/firms for Procurement, Supply, Operation and Maintenance
of 300 AC Low Floor 7m Electric Buses and Development of Allied Electric and Civil
Infrastructure on GCC in Chennai. These buses will be operated as conductor-less
services with on-board fare collection system (FCS).
MTC invites Request for Proposal (RFP) in the form of bid (“Bid”) through e-procurement portal
of Government of Tamil Nadu https://tntenders.gov.in from suitable business entities and other
interested parties to be selected through an open, transparent and global competitive bidding
process.
The Bid document can be downloaded from the e-procurement portal of Tamil Nadu and website
of MTC Chennai and TNIDB from (https://tntenders.gov.in, https://mtcbus.tn.gov.in/,
https://tnidb.tn.gov.in) . The Bid security of amount as per details given in RFP in the form of
original bank guarantee shall be submitted to Managing Director, Metropolitan Transport
Corporation (Chennai) Ltd., No.2, Pallavan Illam, Pallavan Salai, Chennai – 600 002, so as to
reach on or before the timelines provided in the RFP document.
Pre-bid meeting will be held on 09.03.2026 at 15:00 hrs. IST, in the Conference Room of,
Metropolitan Transport Corporation (Chennai) Ltd., No.2, Pallavan Illam, Pallavan Salai, Chennai
– 600 002.
Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
No.2, Pallavan Illam, Pallavan Salai, Chennai – 600 002
E-mail: amprojects1.mtc@gmail.com
Phone: +91-9445039186

Page 1 of 82

<!-- page 3 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

Steps for Registration on E-Procurement Portal of Government of Tamil Nadu
1.1

The subject procurement will be done through e-tender portal. The NIT is available on the
website https://tntenders.gov.in, https://mtcbus.tn.gov.in/, https://tnidb.tn.gov.in or could be
viewed after following the link of ‘e-Tendering’ on MTC’s and TNIDB website’s
Notifications Page, i.e., https://mtcbus.tn.gov.in/, https://tnidb.tn.gov.in from where the
bidders registered with E-Procurement Portal of Government of Tamil Nadu (registration
process is explained at the Home Page) will be able to download the Tender documents
and submit their bids online through https://tntenders.gov.in only. The Tender submission,
Tender closing and opening will be done electronically and online.
Also, as per IT ACT 2000, use of Digital Signature Certificate (DSC) is mandatory for
participating in the E-tendering process. New bidders should register on the website
https://tntenders.gov.in/nicgep/app

1.2

Bidders are requested to visit “e-Tendering” section at E-Procurement Portal of
Government of Tamil Nadu website, https://tntenders.gov.in for instructions and
registration

1.3

MTC Support Telephones and e-mail id
E-mail: amprojects1.mtc@gmail.com; Phone: +91-94450 39186

Page 2 of 82

<!-- page 4 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

DATA SHEET

1.

Title of the Assignment

Procurement, Supply, Operation and Maintenance of 300
AC 7metre Low Floor Electric Buses and Development of
Allied Electric and Civil Infrastructure on Gross Cost
Contracting

2.

Contract
Authority

Metropolitan Transport Corporation (Chennai) Ltd

3.

Bid Validity Period

180 days from the Bid Due Date

4.

Tender Fee

Nil

5.

Bid Security

INR 1 , 50,00,000/- (One Crore Fifty Lakh Rupees Only) [INR
50,000/- (Fifty Thousand Rupees Only) Per Bus] to be
submitted through the Tamil Nadu Government e-Procurement
portal (TNTENDER) in the form of Electronic Bank Guarantee
(e-BG).

6.

Method ofSelection

Least Cost Based System (LCS); Per Kilometre Fee (Rs/Km)

7.

Consortium Allowed

Yes
[The maximum members in a Consortium (including Lead
member) shall be (3) three.]

Signing

All queries regarding the assignment should be addressed to:
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.,
Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email:amprojects1.mtc@gmail.com,

8.

Details for Submission of
Queries

9.

Bid Due Date

Date: 07.04.2026; Time: 16:30Hrs.

10.

Pre-Bid Meeting

Physical Pre-Bid Meeting at the venue provided in point no. 8 of
this Data Sheet.

11.

Website details

Replies to queries/clarifications/addendum/corrigendum etc.
shall be posted onthe following websites:
https://tntenders.gov.in/, https://mtcbus.tn.gov.in/,
https://tnidb.tn.gov.in

Page 3 of 82

<!-- page 5 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

DISCLAIMER
1. The information contained in this Request for Proposal document (“RFP”) or any subsequent
information, whether verbally, documentary or any other form; by or on behalf of the Authority
or any of its employees or advisers to the prospective Bidders, is provided on the terms and
conditions set out in this RFP and such other terms and conditions subject to which such
information is provided.
2. This RFP is neither an agreement nor an offer by the Authority to the prospective Bidders or
any other person. The purpose of this RFP is to provide interested parties with the information
that may be useful to them in the formulation of their Bids (the “Bid”) pursuant to this RFP.
This RFP includes statements, which reflect various assumptions and assessments arrived at
by the Authority in relation to the Project. Such assumptions, assessments and statements do
not purport to contain all the information that each Bidder may require. This RFP may not be
appropriate for all persons, and it is not possible for the Authority, its employees or advisers
to consider the objectives, technical expertise and particular needs of each party who reads
or uses this RFP. The assumptions, assessments, statements and information contained in
this RFP, may not be complete, accurate, adequate or correct. Each Bidder should, therefore,
conduct its own investigations and analysis and should check the accuracy, adequacy,
correctness, reliability and completeness of the assumptions, assessments and information
contained in this RFP and obtain independent advice from appropriate sources. For the
avoidance of doubt, in case a Bidder places reliance on any aforesaid assumptions,
assessments, statements, data and information furnished by the Authority and/or its
consultants in this RFP or any subsequent information as mentioned above including but not
limiting to any project report etc. then the same shall not in any manner bind/make liable the
Authority and/or its consultants, employees or representatives, to indemnify the Bidder in
respect of any loss/damage/costs whatsoever arising out of or in connection with such reliance
placed by the Bidder on the aforesaid assumptions, assessments, statements, data and
information.
3. Information provided in this RFP to the Bidders may be on a wide range of matters, some of
which may depend upon interpretation of law. The information given is not intended to be an
exhaustive account of statutory requirements and should not be regarded as a complete or
authoritative statement of law. The Authority accepts no responsibility for the accuracy or
otherwise for any interpretation or opinion on the law expressed herein.
4. The possession or use of this RFP in any manner contrary to any applicable law is expressly
prohibited. The Bidder shall inform themselves concerning and shall observe any applicable
legal requirements. The information does not purport to be comprehensive or to have been
independently verified. Nothing in this RFP shall be construed as legal, financial or tax advice.
5. The Bidder shall bear all its costs associated with or relating to the preparation and submission
of its Bid including but not limited to preparation, copying, postage, delivery fees, expenses
associated with any demonstrations or presentations which may be required by the Authority
or any other costs incurred in connection with or relating to its Bids. All such costs and
expenses will remain with the Bidder, and the Authority shall not be liable in any manner
whatsoever for the same or for any other costs or other expenses incurred by the Bidder in

Page 4 of 82

<!-- page 6 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

preparation or submission of the Bid, regardless of the conduct or outcome of the Selection
Process.
6. The Authority, its employees, consultants and advisers make no representation or warranty
and shall have no liability to any person including any Bidder under any law, statute, rules or
regulations or tort, principles of restitution or unjust enrichment or otherwise for any loss,
damages, cost or expense which may arise from or be incurred or suffered on account of
anything contained in this RFP including but not limited to the accuracy, adequacy,
correctness, reliability or completeness of the RFP and any assessment, assumption,
statement or information contained therein or deemed to form part of this RFP or arising in
any way in this Selection Process.
7. The Authority also accepts no liability of any nature whether resulting from negligence or
otherwise, howsoever caused, arising from reliance of any Bidder upon the statements
contained in this RFP.
8. The Authority may in its absolute discretion, but without being under any obligation to do so,
update, amend or supplement the information, assessment or assumption contained in this
RFP.
9. The issue of this RFP does not imply that the Authority is obligated to select a Bidder or to
appoint the Successful Bidder, as the case may be, for Project and the Authority reserves the
right to reject all or any of the Bids at any time without assigning any reasons whatsoever and
in case of declaration of a Successful Bidder at any time before award of the work/issuance
of LoA to the Successful Bidder.
10. The Bidders are prohibited from any form of collusion or arrangement in an attempt to influence
the selection and award process of the Bid. Giving or offering of any gift, bribe or inducement
or any attempt to any such act on behalf of the Bidder towards any officer/employee/ advisor/
representative of the Authority or to any other person in a position to influence the decision of
the Authority for showing any favour in relation to this RFP or any other contract, shall render
the Bidder to such liability/penalty as the Authority may deem proper, including but not limited
to rejection of the Bid of the Bidder and forfeiture of its Bid Security.
11. Laws of the Republic of India are applicable to this RFP.

Page 5 of 82

<!-- page 7 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

Table of Contents
1

INTRODUCTION .............................................................................................................................................. 9
1.1

Background ................................................................................................................................... 9

1.2

Scope of Bid .................................................................................................................................. 9

1.3

Brief Description of Bidding Process ........................................................................................... 10

1.4

Schedule of Bidding Process ...................................................................................................... 12

2

INSTRUCTIONS TO BIDDERS ..................................................................................................................... 13
2.1

General terms of Bidding ............................................................................................................ 13

2.2

Eligibility and Qualification Requirements of Bidders .................................................................. 17

2.3

Proprietary Data .......................................................................................................................... 22

2.4

Cost of Bidding ............................................................................................................................ 22

2.5

Verification of Information ........................................................................................................... 22

2.6

Verification and Disqualification .................................................................................................. 23

2.7

Content of the RFP document ..................................................................................................... 24

2.8

Clarifications ................................................................................................................................ 25

2.9

Amendment of RFP document .................................................................................................... 25

2.10 Format and Signing of Bid ........................................................................................................... 25
2.11 Documents comprising Technical Bid and Price Bid .................................................................. 25
2.12 Bid Due Date ............................................................................................................................... 27
2.13 Late Bids ..................................................................................................................................... 27
2.14 Procedure for e-tendering ........................................................................................................... 27
2.15 Online Opening of Bids ............................................................................................................... 28
2.16 Authority’s right to Accept or Reject the Bids ............................................................................. 28
2.17 Validity of Bid............................................................................................................................... 29
2.18 Confidentiality .............................................................................................................................. 29
2.19 Correspondence with the Bidder ................................................................................................. 29
2.20 Consultant(s) or Advisor(s).......................................................................................................... 29
2.21 Currency ...................................................................................................................................... 29
2.22 Bid Security ................................................................................................................................. 29
2.23 Performance Security .................................................................................................................. 31
3 EVALUATION METHODOLOGY........................................................................................................................... 32
3.1

Opening and Evaluation of Bids .................................................................................................. 32

3.2

Test of Responsiveness .............................................................................................................. 32

3.3

Evaluation of Technical Bids ....................................................................................................... 32

3.4

Opening and Evaluation of Price Bids......................................................................................... 33

3.5

Letter of Acceptance ................................................................................................................... 34

Page 6 of 82

<!-- page 8 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

3.6

Contacts during Bid Evaluation ................................................................................................... 34

3.7

Correspondence with Bidder ....................................................................................................... 34

4

FRAUD AND CORRUPT PRACTICES.......................................................................................................... 36

5

PRE-BID CONFERENCE ............................................................................................................................... 38

6

MISCELLANEOUS......................................................................................................................................... 39

APPENDIX 1 - COVERING LETTER CUM PROJECT UNDERTAKING ................................................................... 40
APPENDIX 2 - BID SECURITY ................................................................................................................................... 44
APPENDIX 3 - POWER OF ATTORNEY FOR SIGNING OF THE BID ..................................................................... 47
APPENDIX 4 - POWER OF ATTORNEY FOR LEAD MEMBER OF CONSORTIUM ............................................... 49
APPENDIX 5 - FORMAT FOR BIDDER’S COMPOSITION AND OWNERSHIP STRUCTURE ............................... 51
APPENDIX 6 - FORMAT FOR JOINT BIDDING AGREEMENT ................................................................................ 53
APPENDIX 7 - FORMAT FOR LETTER OF UNDERTAKING ................................................................................... 58
APPENDIX 8 – FORMAT FOR AFFIDAVIT ................................................................................................................ 60
APPENDIX 9 - FORMAT FOR FINANCIAL QUALIFICATION REQUIREMENT (MINIMUM AVERAGE ANNUAL
TURNOVER) ............................................................................................................................................................... 61
APPENDIX 10 - FORMAT FOR FINANCIAL QUALIFICATION REQUIREMENT (NETWORTH) ............................ 65
APPENDIX 10A - FORMAT FOR CERTIFICATION FOR NET WORTH FROM CHARTERED ACCOUNTANT ..... 68
APPENDIX 11- SELF CERTIFICATION FORMAT FOR TECHNICAL QUALIFICATION REQUIREMENT ............. 70
APPENDIX 11A- FORMAT OF AFFIDAVIT FOR MANUFACTURING FACILITY AND MANUFACTURING AND
SUPPLY CAPACITY ................................................................................................................................................... 71
APPENDIX 11B- FORMAT OF CERTIFICATE FROM CHARTERED ENGINEER FOR MANUFACTURING
CAPACITY .................................................................................................................................................................. 72
APPENDIX 11C- FORMAT - EXPERIENCE OF BUS MANUFACTURING AND SUPPLY ...................................... 73
APPENDIX 12 - RELATIONSHIP & DETAILS OF EQUITY SHAREHOLDING ........................................................ 74
APPENDIX 13 - SELF-DECLARATION FOR TESTING CERTIFICATE ................................................................... 76
APPENDIX 14 - CERTFICATE REGARDING DECLARATION OF INDIGENIZATION REQUIREMENT ................ 77
APPENDIX 15 - CERTFICATE REGARDING DECLARATION OF LOCAL CONTENT ........................................... 78
APPENDIX 16 - COMPLIANCE FOR LAND BORDER RESTRICTIONS ................................................................. 79
APPENDIX 17 - AFFIDAVIT FOR BID SECURITY BY ASSOCIATES...................................................................... 81

Page 7 of 82

<!-- page 9 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

ACRONYMS
AIIB
CCP
CMVR
COD
C-SUSP
DSC
EMD
GCC
GOI
GOTN
GST
H1
IBRD
INR
ITB
L1
LCS
LOA
MAAT
MTC
NIT
OEM
P-for-R
PMU
POA
RFP
SEBI
SPV
TNIDB
TOT
USD

Asian Infrastructure Investment Bank
Chennai City Partnership
Central Motor Vehicle Rules 1989
Commercial Operation Date
Chennai Sustainable Urban Services Program
Digital Signature Certificate
Earnest Money Deposit
Gross Cost Contracting
Government of India
Government of Tamil Nadu
Goods & Services Tax
Highest Price
International Bank for Reconstruction and Development
Indian National Rupees
Instructions to Bidder
Lowest Price
Least Cost Based System
Letter of Acceptance
Minimum Average Annual Turnover
Metropolitan Transportation Corporation
Notice Inviting Tender
Original Equipment Manufacturer
Program-for-Results
Program Management Unit
Power of Attorney
Request for Proposal
Securities and Exchange Board of India
Special Purpose Vehicle
Tamil Nadu Infrastructure Development Board
Transfer of Technology
United States Dollar

Page 8 of 82

<!-- page 10 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

1

Volume I: RFP Document

INTRODUCTION
1.1

Background

1.1.1

Metropolitan Transport Corporation (MTC) (hereinafter referred to as “Authority”) is a
Government of Tamil Nadu undertaking registered under Companies Act, 1956. It is entrusted
with providing city bus services in Chennai Metropolitan Area (CMA). MTC currently operates
a fleet size of 4030 buses as of February 2026 on 671 routes and caters to more than 33.60
lakh passengers daily. MTC has a total manpower of around 20,000 employees, handling
operations through 35depots.

1.1.2

Currently MTC is operating 124 small buses as feeder services. There is a need to improve the
connectivity between unserved interior urban neighbourhoods, sub-urban railway stations,
MRTS, metro stations and for MTC’s regular services. In this regard, MTC intends to operate
300 7m low floor buses under GCC model to enhance the feeder service network. These buses
will be operated as conductor-less services with on-board fare collection system (FCS).

1.1.3

The Concession Agreement sets forth the detailed terms and conditions for grant of the
Concession to the Operator, including the scope of the Operator’s services and obligations
(the “Concession”).

1.1.4

The statements and explanations contained in this RFP are intended to provide a better
understanding to the Bidders about the subject matter of this RFP and should not be construed
or interpreted as limiting in any way or manner the scope of services and obligations of the
Operator set forth in the Concession Agreement or Authority’s rights to amend, alter, change,
supplement or clarify the scope of work, the Concession to be awarded pursuant to this RFP
or the terms thereof or herein contained. Consequently, any omissions, conflicts or
contradictions in the Bidding Documents including this RFP are to be noted, interpreted and
applied appropriately to give effect to this intent, and no claims on that account shall be
entertained by the Authority.

1.2

Scope of Bid

1.2.1

The Authority wishes to seek responses to the RFP document in the form of bid (“Bid”) in terms
of Clause 1.2.4.

1.2.2

The Bids would be evaluated based on the evaluation criteria set out in this Request for
Proposal (RFP) Document (hereinafter referred to as the “Evaluation Methodology”) in order
to identify the Successful Bidder (s) for the Project. The Successful Bidder(s) would then be
required to enter into an agreement (hereinafter the “Concession Agreement”) with the
Authority as per the draft set forth in Volume II of this RFP document and perform the
obligations as stipulated therein, in respect of the Project.

1.2.3

Terms used in this RFP document which have not been defined herein shall have the meaning
ascribed thereto in the draft Concession Agreement.

1.2.4

Pursuant to the release of this RFP document, the Authority shall receive Bids, prepared, and
submitted in accordance with the terms set forth in this RFP document and other documents
to be provided to the Authority pursuant to this RFP document including annexure and appendix
thereto (collectively referred to as the “Bidding Documents”), as modified, altered, amended,
and clarified from time to time by the Authority and all Bids shall be prepared and submitted in

Page 9 of 82

<!-- page 11 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

accordance with such terms on or before the date specified in Clause 2.12.1 for submission of
Bids
1.2.5

Any condition or qualification or any other stipulation contained in the Bid not in conformity with
this RFP document shall render the Bid liable to rejection as a non-responsive Bid.

1.2.6

A Concession Agreement as per the format provided in Volume II (“Concession Agreement”)
shall be signed in terms of either Clause 2.1.18 or Clause 2.1.19. The period of Concession
Agreement and assured kms per bus per day for the e-buses is as follows:
Bus Type
7 metre AC Low Floor (400mm) Electric Bus AC

Number of
e-buses
300

Assured Kilometers
per e-bus per month
4800

Concession
Period
12 years

1.2.7 The Authority (MTC) reserves the right to increase the total number of e-buses to be
deployed as per this RFP by upto 25%. Notwithstanding anything in this RFP, such
increase in total number of e-buses shall be made either with the LOA or prior to the
execution of Concession Agreement.
1.3

Brief Description of Bidding Process

1.3.1

The Bidding Documents include the draft Concession Agreement for the Project which forms
Volume II of this RFP document. The aforesaid documents and any addenda issued after this
RFP document, will be deemed to form part of the Bidding Documents.

1.3.2

A Bidder is required to submit, along with its Bid, a Bid Security as referred to in Clause 2.22.4
(the “Bid Security”), refundable not later than 180 (one hundred and eighty) days from the Bid
Due Date, except in the case of the Successful Bidder(s) whose Bid Security shall be retained
till it has provided a Performance Security under the Concession Agreement. The Bidders will
have to provide Bid Security in the form of Bank Guarantee acceptable to the Authority. The
Bank Guarantee shall have its validity period shall not be less than 180 (one hundred and
eighty) days from the Bid Due Date, inclusive of a claim period of 60 (sixty) days, and may be
extended as may be mutually agreed between the Authority and the Bidder from time to time.
The Bid shall be summarily rejected if it is not accompanied by the Bid Security.

1.3.3

Bids are invited for the Project on the basis of lowest INR per Kilometre (hereinafter referred
to as “PK Fee/Per Kilometre Fee”) sought by the Bidder for undertaking the Project. The
Concession Period is pre-determined as provided in the draft Concession Agreement. The PK
Fee shall constitute the sole criteria for selection of the bidder.

1.3.4

The Authority intends to follow a single stage bidding process with two envelope system
(“Bidding Process”) through e-procurement portal for selection of Operator for the Project.

1.3.5

As a part of the Bidding Process interested parties (the “Bidders”) will be required to submit (i)
Technical Bids, and (ii) Price Bids as part of their bid package. (The “Bidder”, which expression
shall, unless repugnant to the context, include the members of the Consortium).

1.3.6

Bidding Process involves evaluation of Technical Bid of prospective bidder(s) in accordance
with the provisions of this RFP. At the end of this stage, the Authority shall shortlist Bidders
fulfilling the Technical Bid criteria.

Page 10 of 82

<!-- page 12 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

1.3.7

The Bidders shortlisted after the Technical Bid evaluation shall be eligible for opening and
evaluation of their Price Bids in the next stage of the Bidding Process comprising the opening
and evaluation of Price Bid (the “Price Bid”).

1.3.8

The bidder whose Price Bid will be lowest i.e. lowest PK Fee for the Project, shall be declared
as the preferred Bidder for Project (“Preferred Bidder”).

1.3.9

Any queries or request for additional information concerning this RFP document shall be
submitted by e-mail to the officer designated in Clause 2.11.4 below with identification/ title:
“Queries/ Request for Additional Information:
“RFP document for Procurement, Supply, Operation and Maintenance of 300 AC
Low Floor 7m Electric Buses and Development of Allied Electric and Civil
Infrastructure on Gross Cost Contracting”

Page 11 of 82

<!-- page 13 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

1.4
1.4.1

Volume I: RFP Document

Schedule of Bidding Process

Schedule of Bidding Process is set out below:

No

Activity Description

Date and Time (IST)

1.

Availability of Bid Documents on eprocurement portal

28.02.2026 at 15:00 hrs

2.

Last date for receiving Pre-bid queries

06.03.2026 at 17:00 hrs

3.

Pre-Bid Conference

09.03.2026 at 15:00 hrs

4.

Last date for downloading the Bid
documents from the e-procurement portal

07.04.2026 at 16:00 hrs

5.

Bid submission- Bid Due Date

07.04.2026 at 16:00 hrs

6.

Physical submission of hard copies of
documents specified in Clause 2.11.2

3 working days subsequent
to Bid due date above

7.

Opening date and time of Technical Bid

07.04.2026 at 16:30 hrs

Page 12 of 82

<!-- page 14 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

2

Volume I: RFP Document

INSTRUCTIONS TO BIDDERS
2.1

General terms of Bidding

2.1.1

No Bidder shall submit more than one Bid for the Project. A Bidder bidding individually or as a
member of a Consortium shall not be entitled to submit another bid either individually or as a
member of any Consortium, as the case may be.

2.1.2

The information on the Project is being provided only as a preliminary reference document by
way of assistance to the Bidders who are expected to carry out their own surveys, investigations
and other detailed examination of the Project before submitting their Bids.

2.1.3

Notwithstanding anything to the contrary contained in this RFP document, the detailed terms
specified in the draft Concession Agreement shall have overriding effect; provided, however,
that any conditions or obligations imposed on the Bidder hereunder shall continue to have effect
in addition to its obligations under the Concession Agreement.

2.1.4

The Bid shall be furnished in the format as per the Appendices. The amount/ numbers shall be
indicated clearly in both figures and words, in Indian Rupees, in prescribed format of Price Bid.
In the event of any discrepancy between Price Bid quoted in figures and words, lower of the two
shall be considered.

2.1.5

The Bidder shall deposit a Bid Security of the amount specified in Clause 2.22.4 in accordance
with the provisions of this RFP.

2.1.6

The Bidder shall submit a Power of Attorney as per the format at Appendix 3, authorising the
signatory of the Bid to commit the Bidder.

2.1.7

In case the Bidder is a Consortium, the Members thereof shall furnish a Power of Attorney in
favour of the Lead Member in the format at Appendix 4.

2.1.8

Any condition or qualification or any other stipulation contained in the Bid not in conformity with
this RFP document shall render the Bid liable to rejection as a non-responsive Bid.

2.1.9

The Bid and all related correspondence and documents in relation to the Bidding Process shall
be in English language. Supporting documents and printed literature furnished by the Bidder
with the Bid may be in any other language provided that they are accompanied by appropriate
authenticated and certified translations of the pertinent passages in the English language.
Supporting materials, which are not translated into English, may not be considered. For the
purpose of interpretation and evaluation of the Bid, the English language translation shall
prevail.

2.1.10 The documents including this RFP document and all attached documents, provided by Authority
are and shall remain or become the property of Authority and are transmitted to the Bidders
solely for the purpose of preparation and the submission of a Bid in accordance herewith.
Bidders are to treat all information as strictly confidential and shall not use it for any purpose
other than for preparation and submission of their Bid. The provisions of this Clause 2.1.10 shall
also apply mutatis mutandis to Bids and all other documents submitted by the Bidders, and
Authority will not return to the Bidders any Bid, document or any information provided along
therewith.
2.1.11 Any award of Concession shall be in terms of this RFP document.

Page 13 of 82

<!-- page 15 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

2.1.12 The Successful Bidder(s), if single entity, shall have the option to incorporate Special Purpose
Company in terms of Clause 2.1.18 or in case the Successful Bidder is a Consortium then such
Successful Bidder shall have to incorporate Special Purpose Company in terms of Clause
2.1.19 as the case may be, incorporated under the Indian Companies Act, 2013 (the “SPV”),
to execute the Concession Agreement and implement the Project. In case the Bidder is a
Consortium, it shall comply with the following additional requirements:
(a)

number of members in a Consortium shall not exceed 3 (three). However, none of
the members in a Consortium should be under any sort of ineligibility under the Bid
documents;

(b)

subject to the provisions of sub-clause (a) above, the Bid should contain the
information required for each member of the Consortium;

(c)

At least one of the members of the Consortium should be an original equipment
manufacturer “OEM” or its Associate and the OEM or its Associate shall be
required to fulfil the Technical Capacity criteria mentioned in clause 2.2.3 of this
RFP. Further, the OEM or its Associate shall mandatorily hold minimum 26%
shareholding in the Consortium and shall also continue to hold minimum 26% of the
subscribed and paid-up equityshare capital in the SPV created to implement the
Project till the end/expiry of the Concession Period.

(d)

members of the Consortium shall nominate one member as the lead member (the
“Lead Member”), who shall have an equity share holding of at least 51% of the paid
up and subscribed equity of the SPV. The nomination(s) shall be supported by a
Power of Attorney, as per the format at Appendix 4, signed by all the other
members of the Consortium;

(e)

the Bid should include a brief description of the roles and responsibilities of
individual members, particularly with reference to OEM, financial, technical,
operations and maintenance obligations;

(f)

an individual Bidder cannot at the same time be member of a Consortium bidding
for the Project. Further, a member of a particular Consortium cannot be member of
any other Consortium bidding for the Project;

(g)

the members of a Consortium shall form an appropriate SPV to execute the Project,
if the Project is awarded to the Consortium;

(h)

members of the Consortium shall enter into a binding Joint Bidding Agreement,
substantially in the form specified at Appendix 6 (the “Joint Bidding Agreement”)
for the purpose of making the Bid. The Joint Bidding Agreement, to be submitted
along with the Bid, shall, inter alia
i.

convey the intent to form a SPV with shareholding/ ownership equity
commitment(s) in accordance with this RFP document, which would enter
into the Concession Agreement and subsequently perform all the
obligations of the Operator in terms of the Concession Agreement, in case
the concession to undertake the Project is awarded to the Consortium;

ii.

clearly outline the proposed roles and responsibilities, if any, of each

Page 14 of 82

<!-- page 16 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

member;

(i)

iii.

commit the minimum equity stake to be held by each member;

iv.

commit that each of the members, whose experience will be evaluated for
the purposes of this RFP document, shall subscribe to 26% (twenty-six per
cent) or more of the paid up and subscribed equity of the SPV and shall
further commit that each such member shall, for a period commencing from
the commercial operation date of the Project till the expiry of the
Concession Agreement hold minimum 26% subscribed and paid-up equity
share capital in the SPV and include a statement to the effect that all
members of the Consortium , shall be liable jointly and severally for all
obligations of the Operator in relation to the Project, in accordance with the
Concession Agreement; and

except as provided under this RFP document, there shall not be any amendment to
the Joint Bidding Agreement without the prior written consent of Authority.

2.1.13 Any entity which has been barred by the Central/ State Government, or any entity controlled by
it, from participating in any project, and the bar subsists as on Bid Due Date, would not be
eligible to submit the Bid, either individually or as member of a Consortium or its Associate.
Further, Bidder including any Consortium member or its Associate should not be in the list of
Ineligible
firms
published
by
the
World
Bank,
available
on
https://www.worldbank.org/en/projects-operations/procurement/debarred-firms
any entity
which is listed as blacklisted firm/entity of World Bank would not be eligible to submit the Bid
either individually or as member of a Consortium.
2.1.14 A Bidder including any Consortium Member or Associate should, in the last 3 (three) years,
have neither failed to perform any contract, as evidenced by imposition of a penalty by an
arbitral or judicial authority or a judicial pronouncement or arbitration award against the Bidder,
Consortium Member or Associate, as the case may be, nor has been expelled from any project
or contract by any public entity nor have had any contract terminated by any public entity for
breach by such Bidder, Consortium Member or Associate. Authority would place sole reliance
on the certification provided by the Bidder in this regard in its letter comprising the Technical
Bid.
For purposes of this RFP document, Associate means, in relation to the Bidder/
Consortium Member, a person who controls, is controlled by, or is under the common
control with such Bidder/ Consortium Member (the “Associate”). As used in this definition,
the expression “control” means, with respect to a person which is a company or
corporation, the ownership, directly or indirectly, of more than 50% (fifty percent) of the
voting shares of such person, and with respect to a person which is not a company or
corporation, the power to direct the management and policies of such person by operation
of law.
It is clarified that a certificate from a qualified external auditor who audits the book of
accounts of the Bidder or the Consortium Member shall be provided to demonstrate that a
person is an Associate of the Bidder or the Consortium as the case may be.

Page 15 of 82

<!-- page 17 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

2.1.15 The following conditions shall be adhered to while submitting a Bid:
(a)

Bidders should attach clearly marked and referenced continuation sheets in the
event that the space provided in the prescribed forms in the Appendices is
insufficient. Alternatively, Bidders may format the prescribed forms making due
provision for incorporation of the requested information;

(b)

information supplied by a Bidder (or other constituent Member if the Bidder is a
Consortium) must apply to the Bidder, Member or Associate named in the Bid and
not, unless specifically requested, to other associated companies or firms;

(c)

in responding to the RFP submissions, Bidders should demonstrate their
capabilities in accordance with Clause 2.2.2 below; and

(d)

in case the Bidder is a Consortium, each Member should substantially satisfy the
RFP requirements to the extent specified herein.

2.1.16 Notwithstanding anything to the contrary contained herein, in the event that the Bid Due Date
falls within three months of the closing of the latest financial year of a Bidder, it shall ignore such
financial year for the purposes of its Bid and furnish all its information and certification with
reference to the 3 (three) years or 1 (one) year, as the case may be, preceding its latest financial
year. For the avoidance of doubt, financial year shall, for the purposes of a Bid hereunder, mean
the accounting year followed by the Applicant in the course of its normal business.
2.1.17 Capitalised terms used in this RFP document which have not been defined herein shall have
the meaning ascribed thereto in the draft Concession Agreement.
2.1.18 In case the Bidder is a single entity and is notified as the Successful Bidder under the provisions
of this RFP, it has the option of executing the Agreement and implementing the Project through
a Special Purpose Vehicle incorporated as a subsidiary Company of the Successful Bidder for
implementing the Project, with 100% direct shareholding in the SPV which has to be registered
under the Indian Companies Act, 2013, before signing of Concession Agreement. For
avoidance of doubt, it is clarified that the SPV as mentioned above should be an immediate
subsidiary of the Successful Bidder, without any intermediaries involved.
2.1.19 In case the Successful Bidder is a Consortium, it shall be mandatory to form an SPV to execute
the Concession Agreement and implement the Project. In case of the Consortium, the OEM or
its Associate shall mandatorily hold minimum 26% subscribed and paid-up equity share capital
in the SPV throughout the period of the Agreement.
2.1.20 The SPV shall at no time undertake or permit any Change in Ownership except in accordance
with the provisions of the Concession Agreement; and that the Successful Bidder (or the
Consortium members), shall hold not less than:
i.

51% (fifty-one per cent) of its subscribed and paid-up Equity on the date of the Concession
Agreement and for a period of 3 (three) years from the date of Commercial Operations
Date (COD) as defined in the draft Concession Agreement; and

ii.

Additionally, the OEM or its Associate shall continue to hold at least 26% of the subscribed
and paid-up equity shareholding in the SPV till the end/expiry of the period of the
Concession Agreement.

Page 16 of 82

<!-- page 18 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

2.2
2.2.1

Volume I: RFP Document

Eligibility and Qualification Requirements of Bidders

For determining the eligibility of Bidder the following shall apply:

(a)

The Bidder may be a single entity or a group of entities (the “Consortium”), coming together
to implement the Project. However, no Bidder applying individually or as a member of a
Consortium, as the case may be, be member of another Bidder. The term Bidder used
herein would apply to both a single entity and a Consortium.

(b)

Bidder is a Business Entity which shall be:
i.
ii.

a company incorporated under the Companies Act, 1956 or 2013, but excluding
companies covered under section 2(45) of the Companies Act, 2013; or
an entity incorporated outside India under equivalent law; or

(c)

Venture Capital Fund (VCF) /Alternate Investment Funds (AIF) are also eligible to
participate in the bidding process as a member of Consortium subject to the conditions set
out in Clause 2.2.9.

(d)

group of Business Entities and/or VCF/AIF with a formal intent to enter into a Joint Bidding
Agreement or under an existing agreement to form a Consortium. A Consortium shall be
eligible for consideration subject to the conditions set out in Clause 2.1.12.

(e)

A Bidder shall not have a conflict of interest (the “Conflict of Interest”) that affects the
Bidding Process. Any Bidder found to have a Conflict of Interest shall be disqualified. In the
event of disqualification, Authority shall be entitled to forfeit and appropriate the Bid Security
or equivalent amount from the Performance Security, as the case may be, as mutually
agreed genuine pre-estimated loss and damage likely to be suffered and incurred by the
Authority and not by way of penalty for, inter alia, the time, cost and effort of Authority,
including consideration of such Bidder’s Bid (the “Damages”), without prejudice to any
other right or remedy that may be available to Authority hereunder or otherwise. Without
limiting the generality of the above, a Bidder shall be deemed to have a Conflict of Interest
affecting the Bidding Process, if:
(i)

the Bidder, its Member or Associate (or any constituent thereof) and any other
Bidder, its Member or any Associate thereof (or any constituent thereof) have
common controlling shareholders or other ownership interest; provided that this
disqualification shall not apply in cases where the direct or indirect shareholding of
a Bidder, its Member or an Associate thereof (or any shareholder thereof having a
shareholding of not more than 25% (twenty five percent) of the paid up and
subscribed share capital; of such Bidder, Member or Associate, as the case may be)
in the other Bidder, its Member or Associate, is not more than 25% (twenty five
percent) of the subscribed and paid up equity share capital thereof; provided further
that this disqualification shall not apply to any ownership by a bank, insurance
company, pension fund or a public financial institution referred to in section 4A of the
Companies Act, 1956/2013. For the purposes of this Clause 2.2.1(e), indirect
shareholding held through one or more intermediate persons shall be computed as
follows: (aa) where any intermediary is controlled by a person through management
control or otherwise, the entire shareholding held by such controlled intermediary in
any other person (the “Subject Person”) shall be taken into account for computing

Page 17 of 82

<!-- page 19 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

the shareholding of such controlling person in the Subject Person; and (bb) subject
always to sub-clause (aa) above, where a person does not exercise control over an
intermediary, which has shareholding in the Subject Person, the computation of
indirect shareholding of such person in the Subject Person shall be undertaken on a
proportionate basis; provided, however, that no such shareholding shall be reckoned
under this sub-clause (bb) if the shareholding of such person in the intermediary is
less than 26% of the subscribed and paid up equity shareholding of such
intermediary; or

(f)

(ii)

a constituent1 of such Bidder is also a constituent of another Bidder; or

(iii)

such Bidder, its Member or any Associate thereof receives or has received any direct
or indirect subsidy, grant, concessional loan or subordinated debt from any other
Bidder, its Member or Associate, or has provided any such subsidy, grant,
concessional loan or subordinated debt to any other Bidder, its Member or any
Associate thereof; or

(iv)

such Bidder has the same legal representative for purposes of this Bid as any other
Bidder; or

(v)

such Bidder, or any Associate thereof, has a relationship with another Bidder, or any
Associate thereof, directly or through common third party/ parties, that puts either or
both of them in a position to have access to each other’s information about, or to
influence the Bid of either or each other; or

(vi)

such Bidder or any Associate thereof has participated as a consultant to the
Authority in the preparation of any documents, design or technical specifications of
the Project; or

(vii)

Such Bidder or any Associate thereof has appointed any official of the Authority,
Technical Advisors of Authority for the Project, Legal Advisors of Authority for the
Project, Financial Advisors of Authority for the Project, dealing with the Project,
within a period of 1 year from the date of award of the Project to that Bidder.

(viii)

In case a Bidder is a Consortium, then the term Bidder shall include each Member
of such Consortium.

A Bidder shall be liable for disqualification and forfeiture of Bid Security if any legal, financial
or technical adviser of Authority in relation to the Project is engaged by the Bidder, its
Members or any Associate thereof, as the case may be, in any manner for matters related
to or incidental to such Project during the Bidding Process or subsequent to the (i) issue of
the LOA or (ii) execution of the Concession Agreement. In the event any such adviser is
engaged by the Successful Bidder or Operator, as the case may be, after issue of the LOA
or execution of the Concession Agreement for matters related or incidental to the Project,
then notwithstanding anything to the contrary contained herein or in the LOA or the
Concession Agreement and without prejudice to any other right or remedy of Authority,
including the forfeiture and appropriation of the Bid Security or Performance Security, as

1 For the purpose of this clause the word “constituent” shall include Promoter, Director, Shareholder, Partner, Agent,

representative etc

Page 18 of 82

<!-- page 20 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

the case may be, which Authority may have thereunder or otherwise, the LOA or the
Concession Agreement, as the case may be, shall be liable to be terminated without
Authority being liable in any manner whatsoever to the Successful Bidder or Operator for
the same. For the avoidance of doubt, this disqualification shall not apply where such
adviser was engaged by the Bidder, its Member or Associate in the past but its assignment
expired or was terminated 6 (six) months prior to the date of issue of RFP document for the
Project. Nor will this disqualification apply where such adviser is engaged after a period of
3 (three) years from the date of commercial operation of the Project.
(g)
2.2.2

Any change in the composition of a Consortium shall not be permitted during the bidding
process.
To be eligible for this RFP document, a Bidder subject to Clause 2.2.15 shall fulfil the following
conditions of eligibility:

(A)
2.2.3

Technical Capacity:

Technical Capacity of the Bidders and or Associate as the case may be, pursuant to Clause
2.2.15 and subject to Clause 2.1.12 (h)(iv) would be evaluated on the basis of the following:
a. A Bidder / a member of Consortium shall be a registered electric bus manufacturer
having a bus manufacturing facility in India.
b. A Bidder / member of Consortium shall have manufactured and supplied to Urban
Public Transport entities in India/ Abroad2:
i.
manufactured and supplied at least 100 electric buses in at least 1(one) of the
last 5 (five) financial years prior to the Bid Due Date; or
ii.
manufactured and supplied an aggregate of at least 300 (three hundred) electric
buses in the last 5 (five) financial years prior to the Bid Due Date;
c. A Bidder / a member of Consortium shall have annual manufacturing capacity of 500
electric buses
d. The Bidder as a Bidder / a member of Consortium should have completed testing and
certification of a similar3 model homologation (100% battery operated electric bus) from
government approved testing agencies notified under Central Motor Vehicle Rules
1989 (CMVR) Section 126 as amended from time to time.
e. In case the Bidder is not able to provide type approval certificate and homologation as
required under 2.2.14 (iii) (c) then the Bidder shall have to submit Self Declaration for
Testing Certificate in terms of Appendix 13.

(B)

Financial Capacity Criteria

2.2.4 Financial Capacity of the Bidders and or Associate as the case may be, pursuant to Clause 2.2.15
and subject to Clause 2.1.12 (h)(iv) would be evaluated on the basis of the following:

a) The average annual turnover of the Bidder in the last 3 consecutive financial years
immediately preceding the Bid Due Date or the Total Fund Available for Project in the
financial year immediately preceding the Bid Due Date.
2 In case of experience outside India, relevant experience certificates shall be translated in English and apostilled by

the concerned authorities of Indian Embassy of the respective country.
3 7 (Seven metres) low Floor (400 mm) e-bus

Page 19 of 82

<!-- page 21 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

b) net worth as at the end of the most recent financial year.
2.2.5

The Bids must be accompanied by the Audited Annual Reports of the Bidder (of each Member
in case of a Consortium) for the last 3 (three) financial years, preceding the financial year in
which the Bid is made.

2.2.6

In case the annual accounts for the latest financial year are not audited and therefore the Bidder
cannot make the same available, the Bidder shall give an undertaking to this effect and the
statutory auditor shall certify the same. In such a case, the Bidder may provide the unaudited
Annual Accounts (with Schedules) for the latest financial year. In such a case, the Bidder shall
provide the Audited Annual Reports for 3 (three) years preceding the year for which the Audited
Annual Report is not being provided. Accordingly, for meeting the Average Annual Turnover
criteria, such financial years for which Audited Annual Reports provided shall be considered
for the purpose of this RFP.

2.2.7

Certificate(s) from its statutory auditors specifying the Annual Turnover during the last 3
financial years and net worth of the Bidder, as at the close of the preceding financial year as
per Appendix 10 & 11 shall be provided in support of their claim.

2.2.8

In case the Bidder is a Consortium, for the purpose of evaluation, subject to Clause 2.1.12
(h)(iv) the arithmetic sum of financial parameters criteria of Average Annual Turnover of such
members should meet the Financial Capacity and the Lead Member must satisfy a minimum
of 50% of the aforesaid criteria. Provided that each member of the Consortium shall have
positive Net Worth in the immediately preceding financial year.

2.2.9

Venture Capital Fund (VCF) /Alternate Investment Funds (AIF) are eligible to participate in the
bidding process as a member of Consortium subject to following conditions.
a) For the purpose of evaluating the Financial Capability of the VCF/ AIF towards its ability
and willingness to contribute towards the Project, following criteria shall be considered:
The Asset Management Company (AMC) /Trustee/ relevant entity having requisite
powers shall, confirm the funds available for the Project (“Total Funds Available for
Project” or say TFAP) through an undertaking that:
i. Objective of the VCF / AIF is not at variance with objective of the Project,
ii. TFAP is within the limits prescribed under Securities and Exchange Board of India
(SEBI), Foreign Investment Promotion Board (FIPB) and Government of India
guidelines for foreign direct investments and any other applicable law/ regulation in
India,
iii. TFAP does not exceed the investment parameters defined by the contributors to
the VCF/ AIF,
iv. TFAP is less than or equal to Investible Funds (Total Fund Corpus of the VCF, net
of expenditure for administration and management of the VCF) Less investments /
commitments made by VCF/ AIF as on Bid Due Date.
The aforesaid TFAP shall be supported by necessary documentary evidence
including most recent quarterly return with relevant authority.

2.2.10 For the purpose of Qualification, a Bidder would be required to demonstrate the threshold
Financial Capability measured on the criteria as listed below. The Bidder would have to satisfy
any one of the following criteria:

Page 20 of 82

<!-- page 22 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

Alternative 1

Average Annual
Turnover

The Bidder should have minimum average annual turnover of
INR 50 crore (Rupees Fifty Crore) in the last 3 consecutive
financial years immediately preceding the Bid Due Date

Alternative 2

Total
Available
Project

The Bidder should have the TFAP as defined in Clause
2.2.9(a) at the close of the preceding financial year of INR 200
crores (Rupees Two Hundred Crore)

Fund
for

2.2.11 The Bidder may demonstrate the threshold financial capacity either under Alternative 1 or under
Alternative 2 as per Clause 2.2.10 above. For avoidance of doubt, Alternative 2 is applicable
for Bidders bidding as a Consortium and the TFAP requirement is met by VCF as a member of
the Consortium.
2.2.12 The Bidder shall have positive Net Worth in the immediately preceding financial year.
2.2.13 For the purpose of this RFP, net worth (the “Net Worth”) shall mean the aggregate value of the
paid-up share capital and all reserves created out of the profits and securities premium account,
after deducting the aggregate value of the accumulated losses, deferred expenditure and
miscellaneous expenditure not written off, as per the audited balance sheet, but does not
include reserves created out of revaluation of assets, write back of depreciation and
amalgamation.
2.2.14 The Bidders shall enclose with its bid, to be submitted as per the format at Appendix 1, the
following:
(i)

Certificate(s) from its statutory auditors stating the annual turnover, during the past
3 years in respect to Clause 2.2.4 specified above. In case a particular job/ contract
has been jointly executed by the Bidder (as part of a Consortium), it should further
support its claim for the share in work done for that particular job/ contract by
producing a certificate from its statutory auditor or the client; and

(ii)

Certificate(s) from its statutory auditors specifying the net worth of the Bidder, as at
the close of the preceding financial year, and also specifying that the methodology
adopted for calculating such net worth conforms to the provisions of this Clause
2.2.14. (ii).

(iii)

Documentary evidence to demonstrate Technical Capacity
a. Self-Certification and Affidavit for having a bus manufacturing facility and
Certification of Accreditation for bus body building from Government
approved testing agencies
b. Supply agreement or purchase order or contract; demonstrating details of ebus manufactured and supplied in terms of 2.2.3 (b) providing details of
number of e-buses, year of supply and names of customers to whom
supplied.
c. Type-approval certificate and homologation certificate testing agencies
notified under Central Motor Vehicle Rules 1989 (CMVR) Section 126 as
amended from time to time.
d. To demonstrate manufacturing capacity in terms of 2.2.3 (c), certificate from
a Chartered Engineer certifying production capacity and an Affidavit in terms

Page 21 of 82

<!-- page 23 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

of Appendix 12 as a proof of manufacturing capacity available with the OEM.
e. Certification of Accreditation for bus body building from Government
approved testing agencies notified under CMVR Section 126.
2.2.15 In computing the Technical Capacity and Financial Capacity of the Bidder/Consortium
Members under Clauses 2.2.3, 2.2.4 the Technical Capacity and Financial Capacity of their
respective Associates would also be eligible hereunder.
2.3

Proprietary Data
All documents and other information supplied by the Authority or submitted by a Bidder to
the Authority shall remain or become the property of the Authority. Bidders are to treat all
information as strictly confidential and shall not use it for any purpose other than for
preparation and submission of their Bid. The Authority will not return any Bid or any
information provided along therewith.

2.4

Cost of Bidding
The Bidder shall be responsible for all of the costs associated with the preparation of their
Bids and their participation in the Bidding Process. Authority will not be responsible or in
any way liable for such costs, regardless of the conduct or outcome of the Bidding Process.

2.5

Verification of Information

2.5.1

Bidders are encouraged to submit their respective Bids after visiting the Project site and
ascertaining for themselves the site conditions, traffic, location, surroundings, climate,
availability of power, water and other utilities for construction, access to site, handling and
storage of materials, weather data, applicable laws and regulations, and any other matter
considered relevant by them. Bidders are advised to visit the site and familiarise themselves
with the Project with in the stipulated time of submission of the Bid. No extension of time is likely
to be considered for submission of Bids.

2.5.2

It shall be deemed that by submitting the Bid, the Bidder has:
(a)

made a complete and careful examination of the RFP document;

(b)

received all relevant information requested from Authority;

(c)

accepted the risk of inadequacy, error or mistake in the information provided in the
RFP document or furnished by or on behalf of Authority relating to any of the matters
referred to in Clause 2.5.1 above;

(d)

satisfied itself about all matters, things and information including matters referred to
in Clause 2.5.1 hereinabove necessary and required for submitting an informed Bid,
execution of the Project in accordance with the RFP document and performance of
all of its obligations thereunder;

(e)

acknowledged and agreed that inadequacy, lack of completeness or incorrectness
of information provided in the RFP document or ignorance of any of the matters
referred to in Clause 2.5.1 hereinabove shall not be a basis for any claim for
compensation, damages, extension of time for performance of its obligations, loss
of profits etc. from Authority, or a ground for termination of the Concession
Agreement by the Operator;

Page 22 of 82

<!-- page 24 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

2.5.3

Volume I: RFP Document

(f)

acknowledged that it does not have a Conflict of Interest;

(g)

agreed to be bound by the undertakings provided by it under and in terms hereof;

Authority shall not be liable for any omission, mistake or error in respect of any of the above or
on account of any matter or thing arising out of or concerning or relating to the RFP document
or the Bidding Process, including any error or mistake therein or in any information or data given
by Authority.

2.6

Verification and Disqualification

2.6.1

Authority reserves the right to verify all statements, information and documents submitted by
the Bidder in response to the RFP document and the Bidder shall, when so required by
Authority, make available all such information, evidence and documents as may be necessary
for such verification. Any such verification, or lack of such verification by Authority shall not
relieve the Bidder of its obligations or liabilities hereunder nor will it affect any rights of Authority
thereunder.

2.6.2

Authority reserves the right to reject any Bid and appropriate the Bid Security if:
(a)

at any time, a material misrepresentation is made or uncovered, or

(b)

the Bidder does not provide, within the time specified by Authority, the supplemental
information sought by Authority for evaluation of the Bid.

Such misrepresentation/ improper response shall lead to the disqualification of the Bidder.
If the Bidder is a Consortium, then the entire Consortium and each Member may be
disqualified/ rejected. If such disqualification/ rejection occurs after the Price Bids have been
opened and the lowest bidder gets disqualified/ rejected, then Authority reserves the right
to take any such measure as may be deemed fit in the sole discretion of Authority, including
annulment of the bidding process.
2.6.3

In case it is found during the evaluation or at any time before signing of the Concession
Agreement or after its execution and during the period of subsistence thereof, including the
Concession thereby granted by Authority, that one or more of the qualification conditions have
not been met by the Bidder, or the Bidder has made material misrepresentation or has given
any materially incorrect or false information, the Bidder shall be disqualified forthwith if not yet
appointed as the Operator either by issue of the LOA or entering into of the Concession
Agreement, and if the Successful Bidder has already been issued the LOA or has entered into
the Concession Agreement, as the case may be, the same shall, notwithstanding anything to
the contrary contained therein or in this RFP document, be liable to be terminated, by a
communication in writing by Authority to the Successful Bidder or the Operator, as the case may
be, without Authority being liable in any manner whatsoever to the Successful Bidder or
Operator. In such an event, Authority shall be entitled to forfeit and appropriate the Bid Security
or Performance Security, as the case may be, as Damages, without prejudice to any other right
or remedy that may be available to Authority under the RFP document and/ or the Concession
Agreement, or otherwise.

2.6.4

the Authority at its discretion can disqualify the Bidder without any further correspondence, as
non-responsive, if,
a.

Technical and/or price bid is not submitted online in the manner as prescribed and is

Page 23 of 82

<!-- page 25 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

not in conformity with the terms and provisions of this RFP.
b.

Price Bid submitted in physical form

c.

Bid Security do not conform to the provisions set forth in this RFP or is not submitted.

d.

The bidder engages in any fraudulent practices defined in section 4 of this RFP.

e.

Bidder is a blacklisted firm/entity listed by World Bank

f.

A bidder submits or participates in more than one bid under this RFP.

g.

Bidder is debarred or terminated or blacklisted in India by Central Govt. organization /
State Govt. organization/any Municipal Corporation / ULBs etc.

h.

The Bidder (in case of a Consortium, each member of Consortium) or any of its
Associates has had any of their contracts terminated by any central, state, or local
government or government instrumentality for breach of such contract by the Bidder or
anyof its Associates, and that such termination has not been set aside or stayed by a
competent judicial authority.

i.

The Bidder or any of its Associates has been categorized as a wilful defaulter by any
lender, in accordance with applicable laws.

j.

The Authority reserves the right to seek information and evidence from the Bidders
with respect to their continued eligibility at any time during the Bidding Process and
each Bidder undertakes to promptly provide all the information and evidence requested
by the Authority and the Bidder has failed to furnish the information and evidence
sought by the Authority.

k.

Any of the directors of the Bidder or its Associate has a criminal history or has been
convicted by any court of law for any of the offenses under any Indian laws.

l.

Any criminal proceeding is pending in any court of law in India against any of the
directors and if any such proceeding culminates into conviction.

m. Bidders may specifically note that while evaluating the Bid, if it comes to Authority’s
knowledge expressly or implied, that some Bidders may have compounded in any
manner whatsoever or otherwise joined to form an alliance resulting in distorting
competitive price discovery or delaying the processing of Bid, then the Bidders so
involved are liable to be disqualified under this Bidding Process as well as future bids
at the sole discretion of the Authority.
n.

2.7
2.7.1

In case of technical experience outside India, if the bidder fails to produce translated
relevant documents (as per Appendix 11C) apostilled by the concerned authorities of
the Indian Embassy in the respective country.

Content of the RFP document

This RFP document comprises the disclaimer set forth hereinabove, the contents as listed
below, and will additionally include any Addenda issued in accordance with Clause 2.9.
Volume I
Volume II

Request for Proposal
Draft Concession Agreement

Page 24 of 82

<!-- page 26 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

2.8

Volume I: RFP Document

Clarifications

2.8.1

Bidders requiring any clarification on the RFP document may notify Authority in writing or by email in accordance with Clause 1.3.9. They should send in their queries before the date specified
in the schedule of Bidding Process specified in Clause 1.4. Authority shall endeavour to respond
to the queries within the period specified therein, but no later than 15 (fifteen) days prior to the
Bid Due Date. All the queries and its responses will be hosted on the e-Tendering Portal without
identifying the source of queries.

2.8.2

Authority shall endeavour to respond to the questions raised or clarifications sought by the
Bidders. However, Authority reserves the right not to respond to any question or provide any
clarification, in its sole discretion, and nothing in this Clause shall be taken or read as compelling
or requiring Authority to respond to any question or to provide any clarification.

2.8.3

Authority may also on its own motion, if deemed necessary, issue interpretations and
clarifications to all Bidders. All clarifications and interpretations issued by Authority shall be
deemed to be part of the RFP document. Verbal clarifications and information given by Authority
or its employees or representatives shall not in any way or manner be binding on Authority.

2.9

Amendment of RFP document

2.9.1

At any time prior to the Bid Due Date, Authority may, for any reason, whether at its own initiative
or in response to clarifications requested by a Bidder, modify the RFP document by the issuance
of Addenda.

2.9.2

Any Addendum thus issued will be posted on the website https://tntenders.gov.in,
https://mtcbus.tn.gov.in/, https://tnidb.tn.gov.in/

2.9.3

In order to afford the Bidders a reasonable time for taking an Addendum into account, or for any
other reason, Authority may, at its own discretion, extend the Bid Due Date.

2.10

Format and Signing of Bid

2.10.1 The Bid shall provide all the information sought under this RFP document. Authority will evaluate
only those Bids that are received online in the required formats and are complete in all respects
with Bid Security, POA and Joint Bidding Agreement etc. as specified in Clause 2.11.2 are
received in hard copies.
2.10.2 The Bid shall be typed and signed in indelible ink by the authorised signatory of the Bidder. All
the alterations, omissions, additions, or any other amendments made to the Bid shall be
initialled by the person(s) signing the Bid.
2.11

Documents comprising Technical Bid and Price Bid

2.11.1 The Bidder shall submit the Technical & Price Bid online through GoTN e-procurement portal
https://tntenders.gov.in, only comprising of the following documents along with supporting
documents as appropriate:

Page 25 of 82

<!-- page 27 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

Part I: Technical Bid
Technical Bid should include the following:
i. Covering Letter in the prescribed format as in Appendix 1
ii. Bid Security in terms of Bank Guarantee as in Appendix 2
iii. Power of Attorney for single bidder for signing the Bid as per the format at Appendix 3
iv. Power of Attorney for Lead Member of the Consortium for signing the Bid as per the
format at Appendix 4
v. Format For Bidder’s Composition and Ownership Structure as set out in Appendix 5
vi. Format for Joint Bidding Agreement as in Appendix 6
vii. Format for Letter of Undertaking as in Appendix 7 (Format 1 & Format 2)
viii. Format for Affidavit as per Appendix 8
ix. Completed format of Financial Qualification Requirement of the Bidder as in
Appendix 9, 9A (MAAT) & Appendix 10, 10A (Net Worth)
x. Self-Certification format for Technical Qualification Requirement as in Appendix 11,
11A, 11B, 11C
xi. Relationship & Details of Equity Shareholding as per Appendix 12
xii. Self-Declaration for Testing Certificate as per the format in Appendix 13
xiii. Certificate Regarding Declaration of Indigenization Requirement as per the format at Appendix 14
xiv. Certificate Regarding Declaration of Local Content as per Appendix 15
xv. Certificate Regarding compliance for Land Border Restrictions as per Appendix 16
xvi. Affidavit For Bid Security by Associates as per Appendix 17
Part II: Price Bid
i.

Price Bid in the form of BoQ-Excel sheet and shall be uploaded separately on the GoTN
e tendering portal.

2.11.2 The Bidder shall submit the following documents physically in hard copy format:
(a)

Original Power of Attorney for signing the Bid as per format at Appendix 3;

(b)

if applicable, Original Power of Attorney for Lead Member of Consortium as per the
format at Appendix 4;

(c)

if applicable, Original Joint Bidding Agreement for Consortium as per the format at
Appendix 6;

(d)

if applicable, Bid Security in the form of Original Bank Guarantee;

2.11.3 The documents listed at Clause 2.11.2 shall be placed in an envelope, which shall be sealed.
The envelope shall clearly bear the following identification:
“Bid for Procurement, Supply, Operation and Maintenance of 300 AC 7metre Low
Floor Electric Buses and Development of Allied Electric and Civil Infrastructure on
Gross Cost Contracting”
and shall clearly indicate the name and address of the Bidder. In addition, the Bid Due Date
should be indicated on the right-hand top corner of the envelope.
2.11.4 The envelope shall be addressed to:

Page 26 of 82

<!-- page 28 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

ATTN. OF:
ADDRESS:
E-MAIL ID:

Volume I: RFP Document

The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd, No.2, Pallavan Illam,
Pallavan Salai, Chennai – 600 002
amprojects1.mtc@gmail.com

2.11.5 If the envelope is not sealed and marked as instructed above, Authority assumes no
responsibility for the misplacement or premature opening of the contents of the Bid and
consequent losses, if any, suffered by the Bidder.
2.11.6 Bids submitted by fax, telex, telegram, or e-mail shall not be entertained and shall be summarily
rejected.
2.12

Bid Due Date

2.12.1 Technical & Price Bid comprising of the documents listed at clause 2.11.1 of the RFP document
shall be submitted online through e-procurement portal https://tntenders.gov.in/ on or before
07.04.2026 at 16:00 hours IST (“Bid Due Date”). Documents listed at clause 2.11.2 of the RFP
document shall be physically submitted on or before 10.04.2026 (3 working days subsequent
to Bid due Date above) at the address provided in Clause 2.11.4 in the manner and form as
detailed in this RFP document.
2.13

Late Bids

2.13.1 E-procurement portal https://tntenders.gov.in/ shall not allow submission of any Bid after the
prescribed date and time at Clause 2.12.1. Physical receipt of documents listed at Clause 2.11.2
after the prescribed date and time at Clause 2.12.1 shall not be considered and the Bid shall be
summarily rejected.
2.14

Procedure for e-tendering

2.14.1 Accessing/ Purchasing of Bid documents
a. It is mandatory for all the Bidders to possess a valid Class -3 Signing and Encryption
Digital Signature Certificate (DSC) (in the name of Authorized Signatory / Firm or
Organization / Owner of the Firm or organisation) as per the provisions of Government of
India IT Act 2000 with latest amendments.
b. DSC should be in the name of the authorized signatory as authorized in Appendix III of
this RFP. It should be in corporate capacity (that is in Bidder capacity / in case of
Consortium in the Lead Member capacity, as applicable). The Bidder shall submit
document in support of DSC.
c. Digital Signature Certificates can be obtained from the authorized certifying agencies,
details of which are available in the web site https://tntenders.gov.in under the link
“Information about DSC”.
2.14.2 The Bidders are required to register themselves on the Tamil Nadu e-procurement system
portal at URL: https://tntenders.gov.in/nicgep/app and submit soft copies of their Bids
electronically using valid Digital Signature Certificates. Bidders may refer to instructions on
online bid submission available on the site at:
a. https://tntenders.gov.in/nicgep/app?page=BiddersManualKit&service=page

Page 27 of 82

<!-- page 29 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

b. https://eprocure.gov.in/cppp/hassle_free_bid_submission.pdf
2.14.3 If the firm / Consortium is already registered with e-Procurement Portal of the Authority, and
validity of registration is not expired the firm / Consortium is not required a fresh registration.
2.14.4 The complete Bid document can be viewed / downloaded by the Bidder from eProcurement
portal of the Authority URL: https://tntenders.gov.in/nicgep/app from the date mentioned in
Clause 1.4.
2.14.5 Preparation & Submission of Bids:
a. The Bidder shall submit his Bid online following the instruction appearing on the
screen. The e-Procurement portal has user manuals with detailed guidelines on
enrolment and participation in the online Bidding process. The user manuals can be
downloaded for ready reference.
b. Bid must be submitted online only through e-procurement portal of the Authority URL:
https://tntenders.gov.in/nicgep/app using the digital signature of Authorised
Representative of the Bidder.
c. It is suggested that the Bidder should submit the Bidding Documents online well in
advance of the prescribed time to avoid any delay or problem during the online
submission process. Authority shall not be held responsible for any sort of delay or the
technical difficulty faced in the submission of tenders online by the Bidders.
2.14.6 Modifications/ Withdrawal of Bid
a. The Bidder may modify its e- Bid after submission prior to the Bid Due Date. No Bid
can be modified by the Bidder on or after the Bid Due Date & Time.
b. No bid can be withdrawn once submitted.
2.15

Online Opening of Bids

2.15.1 Opening of Bids will be done through online process.
2.15.2 The Authority shall on-line open Technical Bids on 07.04.2026 at 16:30Hours IST, in the
presence of the authorized representatives of the Bidders, who choose to attend. The Authority
will subsequently examine and evaluate the Bids in accordance with the provisions of Section
3 of RFP.
2.16

Authority’s right to Accept or Reject the Bids

2.16.1 Notwithstanding anything contained in this RFP document, Authority reserves the right to
accept or reject any or all of the Bid and to annul the Bidding Process and reject all Bids, at any
time without any liability or any obligation for such acceptance, rejection or annulment, and
without assigning any reasons therefor. In the event that the Authority rejects or annuls all the
Bids, it may, in its discretion, invite all eligible Bidders to submit fresh Bids hereunder.
2.16.2 Authority reserves the right not to proceed with the Bidding Process at any time, without notice
or liability, and to reject any Bid without assigning any reasons.

Page 28 of 82

<!-- page 30 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

2.17

Volume I: RFP Document

Validity of Bid

2.17.1 Bid shall remain valid for a period of 180 days from Bid Due Date. Authority reserves the right
to reject a bid as non-responsive if such bid is valid for a period of less than bid validity period
and the Authority shall not be liable to send an intimation of any such rejection to such Bidder.
In exceptional circumstances, prior to expiry of the original bid validity period, the Authority may
request the Bidders to extend the period of validity for a specified additional period. The request
and the responses thereto shall be made in writing. A Bidder may refuse the request without
forfeiting their Bid Security. A bidder agreeing to the request will not be permitted to modify his
bid but will be required to extend the validity of his Bid Security for the period of the extension,
and in compliance with RFP terms in all respects. Subject to the specific terms of the draft
Concession Agreement, the price as per the bid shall be valid for the entire duration of the
Agreement when awarded within the bid validity period.
2.18

Confidentiality

2.18.1 Information relating to the examination, clarification, evaluation, and recommendation for the
Bidders shall not be disclosed to any person who is not officially concerned with the process or
is not a retained professional advisor advising Authority in relation to, or matters arising out of,
or concerning the Bidding Process. Authority will treat all information, submitted as part of Bid,
in confidence and will require all those who have access to such material to treat the same in
confidence. Authority may not divulge any such information unless it is directed to do so by any
statutory entity that has the power under law to require its disclosure or is to enforce or assert
any right or privilege of the statutory entity and/ or authority or as may be required by law or in
connection with any legal process.
2.19

Correspondence with the Bidder

2.19.1 Save and except as required in this RFP document, Authority shall not entertain any
correspondence with any Bidder in relation to acceptance or rejection of any Bid.
2.20

Consultant(s) or Advisor(s)

2.20.1 To assist in the examination, evaluation, and comparison of Bids, Authority may utilize the
services of consultant(s) or advisor(s).
2.20.2 No entity including the Bidders can hold and Authority shall not be bound by the opinion or
advice given by any consultant or advisor referred to in Clause 2.20.1. The final determination
as regards the Bid shall vest with Authority.
2.21

Currency

2.21.1 All prices quoted in the Bid shall be quoted in Indian National Rupee(s) (INR).
2.22

Bid Security

2.22.1 The Bidder shall furnish as part of its Bid, a Bid Security referred to in Clauses 2.22.4. The
bidder is allowed to submit the Bid security through its Associate also, along with an affidavit
as attached in Appendix 2.
2.22.2 The Bidder shall furnish as part of its Bid, a Bid Security referred to in Clauses 2.22.4 in the
form of e – Bank Guarantee issued by Nationalized bank, or a Scheduled Bank in India having
a net worth of at least Rs. 1,000 crore (Rupees One thousand crore), in favor of the Authority

Page 29 of 82

<!-- page 31 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

in the format at Appendix -2 (the “Bank Guarantee”) and having a validity period of not less
than 180 (one hundred and eighty) days from the Bid Due Date and a claim period of 30 (thirty)
days, and may be extended as may be mutually agreed between the Authority and the Bidder
from time to time..
The bidder can generate the e-BG challan through tntenders portal in the following 12 banks e-BGs
in e-procurement portal (https://tntenders.gov.in).
1. Bank of Baroda
2. Canara Bank
3. HDFC Bank
4. ICICI Bank
5. Indian Bank
6. Indian Overseas Bank
7. Karur Vysya Bank
8. Punjab National Bank
9. State Bank of India
10. Union Bank of India
11. City Union Bank
12. IDFC First Bank
2.22.3 Any Bid not accompanied by the Bid Security shall be summarily rejected by the Authority as
non-responsive.
2.22.4 The Bid Security details are provided in the table below:
Bus Type
7 metre Low Floor (400mm AC e-Buses

No. of Buses
300

Bid Security
Rs. 1.5 crores.

No Interest will be payable by the Authority on the Bid Security.
2.22.5 Save and except as provided in Clauses 1.3.2, the Bid Security of unsuccessful Bidders will be
returned by the Authority, without any interest, as promptly as possible on acceptance of the
Bid of the Successful Bidder or when the Bidding process is cancelled by the Authority, and in
any case within 180 (one hundred and eighty) days from the Bid Due Date.
2.22.6 The Successful Bidder’s Bid Security will be returned, without any interest, upon the Operator
signing the Concession Agreement and furnishing the Performance Security in accordance with
the provisions thereof.
2.22.7 The Authority shall be entitled to forfeit and appropriate the Bid Security as Damages inter alia
in any of the events specified in Clause 2.22.8 herein below. The Bidder, by submitting its Bid
pursuant to this RFP, shall be deemed to have acknowledged and confirmed that the Authority
will suffer loss and damage on account of withdrawal of its Bid or for any other default by the
Bidder during the period of Bid validity as specified in this RFP. No relaxation of any kind on Bid
Security shall be given to any Bidder.
2.22.8 The Bid Security shall be forfeited as Damages without prejudice to any other right or remedy
that may be available to the Authority under the Bidding Documents and/or under the
Concession Agreement, or otherwise, under the following conditions:

Page 30 of 82

<!-- page 32 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

(d)

2.23

Volume I: RFP Document

(a)

If a Bidder engages in a corrupt practice, fraudulent practice, coercive practice,
undesirable practice or restrictive practice as specified in Section 4 of this RFP;

(b)

If a Bidder withdraws its Bid during the period of Bid validity as specified in this RFP
and as extended by mutual consent of the respective Bidder(s) and the Authority;

(c)

In the case of Successful Bidder, if it fails within the specified time limit:
i)

to sign and return the duplicate copy of LOA;

ii)

to sign the Concession Agreement within the period prescribed thereof in the
LOA; or

iii)

to furnish the Performance Security within the period prescribed thereof in the
LOA;

In case the Successful Bidder, having signed the Concession Agreement, commits any
breach thereof prior to furnishing the Performance Security, if applicable.

Performance Security

2.23.1 The Successful Bidder shall for the performance of its obligations, furnish Performance
Security in terms of Article 9 of the draft Concession Agreement. The amount of the
Performance Security to be furnished shall be Rs. 2 Lakh (Rupees Two Lakh) per Bus.
For illustration:
Number of buses procured

300

Performance Security per bus

Rs. 2 Lakh per bus

Performance Security for the total buses procured

300 × Rs. 2 Lakh = Rs. 6 Crore

Page 31 of 82

<!-- page 33 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

3

Volume I: RFP Document

EVALUATION METHODOLOGY
3.1

Opening and Evaluation of Bids

3.1.1

The Authority shall open online Technical Bids received through the e-procurement portal of
GoTN, at the time and the date specified in the RFP, at the place specified in RFP and in the
presence of the Bidders who choose to attend.

3.1.2

The following information shall be announced at the Bid opening and recorded:
a) Bidders’ names; and
b) Particulars of the Bid Security.

3.1.3

The Authority will subsequently examine and evaluate Technical Bid in accordance with the
provisions set out hereunder in this RFP.

3.2
3.2.1

Test of Responsiveness

Prior to evaluation of Bids, Authority shall determine whether each Bid is responsive to the
requirements of the RFP document. The Bid shall be considered responsive only if:
(a) it is received as per format at Appendix 1.
(b) it is received by the Bid Due Date including any extension thereof pursuant to Clause
2.9.3;
(c) it is signed, sealed, and marked as stipulated in Clause 2.10.2;
(d) it is accompanied by the Power(s) of Attorney as specified in Appendix 3 and in the
case of a Consortium, the Power of Attorney as specified in Appendix 4;
(e) it contains all the information as requested in this RFP Document (in formats as those
specified);
(f) it contains certificates from its statutory auditors in the formats specified at Appendix
9 and Appendix 10 of the RFP Document;
(g) it is accompanied by the Joint Bidding Agreement (for Consortium), specific to the
Project, as stipulated in Clause 2.1.12(g);
(h) it is accompanied by the Bid Security as specified in Appendix 2;
(i) it does not contain any condition or qualification;
(j) physical copy of the documents mentioned in Clause 2.11.2 are submitted by the Bid
Due Date or as per the requirements of this RFP; and
(k) it is not non-responsive in terms hereof.

3.2.2

Authority reserves the right to reject any Bid which is non-responsive and no request for
alteration, modification, substitution, or withdrawal shall be entertained by Authority in respect
of such Bid.

3.3
3.3.1

Evaluation of Technical Bids

The Technical Bids as submitted by the Bidders shall be checked for eligibility, technical
capacity, financial capability, bid security and other such compliances with the requirements of
the RFP Document. The Authority reserves the right to reject the Bid of a Bidder without
opening the Price Bid, if Bid is non responsive in terms of Clause 3.2.1.

Page 32 of 82

<!-- page 34 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

3.3.2

The Authority will get the Bid Security verified from the issuing bank and after due verification,
the Authority will evaluate the Technical Bids of the Bidders for their compliance provided in
Clause 3.3.1.

3.3.3

Based on evaluation of Technical Bids, the Authority would release a list of Bidders who meet
the qualification criteria set out in this RFP Document for the Project. A list of such aforesaid
Bidders shall be prepared, and such Bidders shall be informed that their Bid has been
shortlisted for opening of the Price Bid (“Shortlisted Bidders”).

3.3.4

The Authority shall intimate a date for opening of Price Bids to all the Shortlisted Bidders
through e-procurement portal of GoTN and invite them for opening of the Price Bids.
Attendance to such opening of Price Bids is not mandatory. However, the Authority shall not
entertain any claim of whatsoever nature in case a Bidder does not attend the meeting for
opening of Price Bids of Shortlisted Bidders.

3.4

Opening and Evaluation of Price Bids

3.4.1

Authority shall inform the venue and time of online opening of Price Bids to all Shortlisted
Bidders through e-procurement portal and/ or e-mail. Authority shall open the Price Bids online
on the date and the time to be informed in this clause in the presence of the authorised
representatives of the Bidders who may choose to attend. Authority shall prepare a record of
opening of Price Bids.

3.4.2

Price Bid of the Shortlisted Bidders shall be opened online. The Price Bid of the Bidders for the
Project would be evaluated based on payment to be made by the Authority to Bidder in terms
of the Concession Agreement i.e., PK Fee quoted by the Bidder in its Price Bid.

3.4.3

The Bidder quoting the lowest PK Fee, payable by the Authority to the Bidder, shall be declared
as the Preferred Bidder (“Preferred Bidder”).

3.4.4

In case of the Price Bid of the Preferred Bidder is found seriously imbalanced by Authority in
relation to its Internal Estimate or Industry Practice, the Authority shall be entitled to solicit, at
its discretion, detailed price analysis for any or all items specified in Price Bid, from the
Preferred Bidder and/or all Bidders to demonstrate the internal consistency of those prices.
“Internal Estimate” shall mean per km rate prepared by Authority through its internal
estimates. “Good Industry Practice” shall mean the use of cost that would reasonably and
ordinarily be expected from a skilled and experienced bus operator engaged in city bus
operations of electric buses anywhere in India.
In case of the Price Bid of the Preferred Bidder, which is unrealistically lower or
unrealistically higher than internal estimate or market rate or Good Industry Practice and
which could not be substantiated satisfactorily by the bidder then provisions of Clause 3.4.5
shall apply.

3.4.5

The Authority may either choose to accept the Bid of the Preferred Bidder or invite him for
negotiations.

3.4.6

In the event that two or more Bidders have quoted the same Price Bid (“Tie Bidders”) the
Authority shall identify the lowest Bidder by adopting the following approach:
a. The Tie Bidders shall be asked to provide their best and final offer of the Price Bid

Page 33 of 82

<!-- page 35 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

through e-procurement portal of GoTN and the Tie Bidder quoting the lowest PK Fee
shall be declared as the Preferred Bidder.
b. In case, a tie still persists after the procedure contained in clause 3.4.6 (a), the Authority
shall repeat the process as specified in clause 3.4.6 (a) until such tie is resolved and a
Preferred Bidder is identified.
3.4.7

Deleted.

3.4.8

Upon acceptance of the Bid of the Preferred Bidder with or without negotiations, the Authority
shall declare the Preferred Bidder as the Successful Bidder(s) (the “Successful Bidder(s)”).

3.5

Letter of Acceptance

3.5.1

After the opening of Price Bid, the Authority shall notify the Successful Bidder(s) as confirmed
in writing by registered/speed post/email that their bid has been accepted. This letter
(hereinafter called “Letter of Acceptance”) shall name the amount (i.e PK Fee) which the
Authority will pay to the Successful Bidders in consideration obligations set forth in the
Concession Agreement.

3.5.2

The Letter of Acceptance (the “LOA”) shall be issued, in duplicate, by Authority to the
Successful Bidders and the Successful Bidders shall, within 7 (seven) days of the receipt of the
LOA, sign and return the duplicate copy of the LOA in acknowledgement thereof. In the event
the duplicate copy of the LOA duly signed by any or both of the Successful Bidders is not
received within the stipulated date, Authority may, unless it consents to extension of time for
submission thereof, appropriate the Bid Security of such Bidder as Damages on account of
failure of the Successful Bidder to acknowledge the LOA.

3.5.3

After acknowledgement of the LOA as aforesaid by the Successful Bidders, it shall cause to
execute the Concession Agreement within the period prescribed in LOA and submit the
Performance Security in accordance with the draft Concession Agreement. The Successful
Bidder shall not be entitled to seek any deviation, modification or amendment in the draft
Concession Agreement. In the event any or both of the Successful Bidders do not execute the
Concession Agreement or the Performance Guarantee is not submitted in accordance with the
draft Concession Agreement, Authority may, unless it consents to extension of time for
submission thereof, appropriate the Bid Security of such Bidder as Damages on account of
failure of the Successful Bidder to sign the Concession Agreement and/or submit the
Performance Guarantee as the case may be.

3.6
3.6.1

Bids shall be deemed to be under consideration immediately after they are opened and until
such time the Authority makes official intimation of award/ rejection to the Bidders. While the
Bids are under consideration, Bidders and/ or their representatives or other interested parties
are advised to refrain, save and except as required under the Bidding Documents, from
contacting by any means, the Authority and/ or their employees/ representatives on matters
related to the Bids under consideration.

3.7
3.7.1

Contacts during Bid Evaluation

Correspondence with Bidder

Save and except as provided in this RFP document, the Authority shall not entertain any
correspondence with any Bidder in relation to the acceptance or rejection of any Bid.

Page 34 of 82

<!-- page 36 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

3.7.2

Any information contained in the Bid shall not in any way be construed as binding on the
Authority, its agents, successors or assigns, but shall be binding against the Bidder if the Project
is subsequently awarded to it on the basis of such information.

3.7.3

The Authority reserves the right not to proceed with the Bidding Process at any time without
notice or liability and to reject any or all Bid(s) without assigning any reasons.

Page 35 of 82

<!-- page 37 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

4

Volume I: RFP Document

FRAUD AND CORRUPT PRACTICES

4.1

The Bidders and their respective officers, employees, agents, and advisers shall observe the
highest standard of ethics during the Bidding Process and subsequent to the issue of the LOA
and during the subsistence of the Concession Agreement. Notwithstanding anything to the
contrary contained herein, or in the LOA or the Concession Agreement, Authority may reject
the Bid, withdraw the LOA, or terminate the Concession Agreement, as the case may be,
without being liable in any manner whatsoever to the Bidder or Operator, as the case may be,
if it determines that the Bidder or Operator, as the case may be, has, directly or indirectly or
through an agent, engaged in corrupt practice, fraudulent practice, coercive practice,
undesirable practice or restrictive practice in the Bidding Process. In such an event, Authority
shall be entitled to forfeit and appropriate the Bid Security or Performance Security, as the
case may be, as Damages, without prejudice to any other right or remedy that may be
available to Authority under the RFP document and/ or the Concession Agreement, or
otherwise.

4.2

Without prejudice to the rights of Authority under Clause 4.1 hereinabove and the rights and
remedies which Authority may have under the LOA or the Concession Agreement, or
otherwise if a Bidder or Operator, as the case may be, is found by Authority to have directly
or indirectly or through an agent, engaged or indulged in any corrupt practice, fraudulent
practice, coercive practice, undesirable practice or restrictive practice during the Bidding
Process, or after the issue of the LOA or the execution of the Concession Agreement, such
Bidder or Operator shall not be eligible to participate in any tender or RFQ/RFP/RFP issued
by Authority during a period of 2 (two) years from the date such Bidder or Operator, as the
case may be, is found by Authority to have directly or indirectly or through an agent, engaged
or indulged in any corrupt practice, fraudulent practice, coercive practice, undesirable practice
or restrictive practices, as the case may be.

4.3

For the purposes of this Section 4, the following terms shall have the meaning hereinafter
respectively assigned to them:
(a) “corrupt practice” means (i) the offering, giving, receiving, or soliciting, directly or
indirectly, of anything of value to influence the actions of any person connected with
the Bidding Process (for avoidance of doubt, offering of employment to, or employing,
or engaging in any manner whatsoever, directly or indirectly, any official of Authority
who is or has been associated in any manner, directly or indirectly, with the Bidding
Process or the LOA or has dealt with matters concerning the Concession Agreement
or arising therefrom, before or after the execution thereof, at any time prior to the expiry
of one year from the date such official resigns or retires from or otherwise ceases to be
in the service of Authority , shall be deemed to constitute influencing the actions of a
person connected with the Bidding Process); or (ii) save and except as permitted under
Clause 2.2.1(f), engaging in any manner whatsoever, whether during the Bidding
Process or after the issue of the LOA or after the execution of the Concession
Agreement, as the case may be, any person in respect of any matter relating to the
Project or the LOA or the Concession Agreement, who at any time has been or is a

Page 36 of 82

<!-- page 38 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

legal, financial or technical adviser of Authority in relation to any matter concerning the
Project;
(b) “fraudulent practice” means a misrepresentation or omission of facts or suppression
of facts or disclosure of incomplete facts, in order to influence the Bidding Process;
(c) “coercive practice” means impairing or harming or threatening to impair or harm,
directly or indirectly, any person or property to influence any person’s participation or
action in the Bidding Process;
(d) “undesirable practice” means (i) establishing contact with any person connected with
or employed or engaged by Authority with the objective of canvassing, lobbying or in
any manner influencing or attempting to influence the Bidding Process; or (ii) having a
Conflict of Interest; and
(e) “restrictive practice” means forming a cartel or arriving at any understanding or
arrangement among Bidders with the objective of restricting or manipulating a full and
fair competition in the Bidding Process.

Page 37 of 82

<!-- page 39 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

5

Volume I: RFP Document

PRE-BID CONFERENCE
5.1

Pre-Bid conference of the Bidders shall be convened at the designated date, time, and
place. A maximum of two representatives of prospective Bidders shall be allowed to
participate on production of authority letter from the Bidder.

5.2

During the course of Pre-Bid conference(s), the Bidders will be free to seek clarifications
and make suggestions for consideration of Authority. Authority shall endeavour to provide
clarifications and such further information as it may, in its sole discretion, consider
appropriate for facilitating a fair, transparent, and competitive Bidding Process.

Page 38 of 82

<!-- page 40 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

6

Volume I: RFP Document

MISCELLANEOUS
6.1

The Bidding Process shall be governed by, and construed in accordance with, the laws of
India and the Courts at Tamil Nadu shall have exclusive jurisdiction over all disputes arising
under, pursuant to and/ or in connection with the Bidding Process.

6.2

Authority, in its sole discretion and without incurring any obligation or liability, reserves the
right, at any time, to:
(a)

suspend and/ or cancel the Bidding Process and/ or amend and/ or supplement the
Bidding Process or modify the dates or other terms and conditions relating thereto;

(b)

consult with any Bidder in order to receive clarification or further information;

(c)

retain any information and/ or evidence submitted to Authority by, on behalf of, and/
or in relation to any Bidder; and/ or

(d)

independently verify, disqualify, reject and/ or accept any and all submissions or
other information and/ or evidence submitted by or on behalf of any Bidder.

6.3

It shall be deemed that by submitting the Bid, the Bidder agrees and releases Authority, its
employees, agents and advisers, irrevocably, unconditionally, fully and finally from any and
all liability for claims, losses, damages, costs, expenses or liabilities in any way related to
or arising from the exercise of any rights and/ or performance of any obligations hereunder
and the RFP document, pursuant hereto, and/ or in connection with the Bidding Process,
to the fullest extent permitted by applicable law, and waives any and all rights and/ or claims
it may have in this respect, whether actual or contingent, whether present or in future.

6.4

Bidders/Suppliers/Contractors/Consultants are required to comply with the applicable
Guidelines (available at the following link): https://ppfdocuments.azureedge.net/3682.pdf.

Page 39 of 82

<!-- page 41 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 1 - COVERING LETTER CUM PROJECT UNDERTAKING
(The covering letter should be on the Letter Head of the Bidder/ Lead Member of the
Consortium)

Date:

…………………………………

To,
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com

Subject: Request for Proposal for Procurement, Supply, Operation and Maintenance of 300
AC 7metre Low Floor Electric Buses and Development of Allied Electric and Civil
Infrastructure on Gross Cost Contracting for The Metropolitan Transport Corporation
(Chennai) Ltd (“Project”).

Dear Sir/Madam,
We have read and understood the Request for Proposal (RFP) Document in respectof the
Project provided to us by The Metropolitan Transport Corporation (Chennai) Ltd (MTC),
Chennai. We hereby submit our Bid for the captioned project.
1.

We are enclosing and submitting herewith our Bid with the details as per the requirements
of the RFP Document, for your evaluation and consideration.

2.

The Bid is unconditional and unqualified.

3.

All information provided in the Bid and in the Appendices is true and correct.

4.

The statement made herein are for the express purpose of qualifying as a Bidder for the
aforesaid Project.

5.

I/ We shall make available to MTC, any additional information it may find necessary or
require to clarify, supplement, or authenticate the Bid.

6.

I/ We acknowledge the right of the MTC to reject our Bid without assigning any reason or
otherwise.

7.

We certify that in the last three years, we/ any of the Consortium Members have neither
failed to perform on any contract, as evidenced by imposition of a penalty or a judicial
pronouncement or arbitration award, nor been expelled from any project or contract nor
have had any contract terminated for breach on our part.
Page 40 of 82

<!-- page 42 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

8.

Volume I: RFP Document

I/ We declare that:
(a) I/ We have examined and have no reservations to the Bidding Documents, including
the Addendum issued by the MTC.
(b) I/ We do not have any conflict of interest in accordance with Clause 2.2.1(e) of the RFP
document;
(c) I/We have not directly or indirectly or through an agent engaged or indulged in any
corrupt practice, fraudulent practice, coercive practice, undesirable practice or
restrictive practice, asdefined in Section 4 of the RFP Document, in respect of any
tender or request for proposal issued by or any agreement entered into with the MTC
orany other public sector enterprise or any government, Central or State; and
(d) I/ We hereby certify that I/we have taken steps to ensure that in conformity with the
provisionsof Section 4 of the RFP Document, no person acting for us or on our behalf
has engaged or will engage in any corrupt practice, fraudulent practice, coercive
practice, undesirable practice or restrictive practice.

9.

I/ We understand that you may cancel the Bidding Process at any time and that you are
neither bound to accept any Bid that you may receive nor to invite the Bidders to submit
Bids for the Project, without incurring any liability to the Bidders, in accordance with
Clause 2.16 of the RFP Document.

10. I/We declare that we satisfy and meet the requirements as specified in the RFP Document
and eligible to submit a Bid in accordance with the terms of this RFP Document.
11. I/ We declare that we/ any Member of the Consortium are/ is not a Member of any [other]
Consortium submitting a Bid for the Project.
12. I/ We certify that we have not been convicted by a Court of Law or indicted or adverse
orders passed by a regulatory authority in any matter which could cast a doubt on our ability
to undertakethe Project or which relates to a grave offence that outrages the moral sense
of the community.
13. I/ We further certify that in regard to matters relating to security and integrity of the India, we
havenot been charge-sheeted by any agency of the Government or convicted by a Court
of Law for anyoffence committed by us.
14. I/ We certify that no investigation by a regulatory authority is pending either against us or
againstour CEO or any of our Directors or any shareholder holding not less 10% of our
issued and subscribe equity share capital.
15. I/ We undertake that in case due to any change in facts or circumstances during the
Bidding Process, we are attracted by the provisions of disqualification, we shall intimate
the MTC of the same immediately.
16. We acknowledge that all members shall continue to hold the minimum shareholding of
the Operator Equity Capital under and in accordance with the provisions of the
Concession Agreement. We further agree and acknowledge that the aforesaid obligation
shall be in addition to the obligations contained in the Concession Agreement in respect
of Change in Ownership. We further acknowledge and agree that in the event such
change in control occurs after signing of the Concession Agreement which is contrary to
the terms therein, it would, notwithstanding anything to the contrary contained in the
Page 41 of 82

<!-- page 43 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

Agreement, be deemed a breach thereof, and the Concession Agreement shall be liable
to be terminated without the MTC being liableto us in any manner whatsoever.
17. We acknowledge and agree that in the event of a change in composition of our Consortium
during the Bidding Process, the same shall be a basis for disqualification of our
Consortium by the MTC forthwith.
18. We understand that the Consortium shall incorporate itself as a Company under the
Indian Companies Act, 2013 such prior to execution of the Concession Agreement.
19. I/We hereby irrevocably waive any right which we may have at any stage at law or
howsoever otherwise arising or accruing to challenge or question any decision taken by
the MTC in connection with the selection of the Bidder, or in connection with the Bidding
Process itself, in respect of the above mentioned Project and the terms and
implementation thereof.
20. In the event of my/ our being declared as the Successful Bidder, I/We agree to enter into
a Concession Agreement in accordance with the draft that has been provided to me/us
prior to the Bid Due Date. We agree not to seek any changes in the aforesaid draft and
agree to abide bythe same.
21. I/We have studied all the Bidding Documents carefully and also surveyed the (Project and
other matters mentioned in the Bidding Documents including in Clause 2.11.1 and 2.11.2
of the RFP Document). We understand that except to the extent as expressly set forth in
the Concession Agreement, we shall have no claim, right or title arising out of any
documents or information provided to us by the MTC or in respect of any matter arising
out of or concerning or relating to the Bidding Process including the award of concession.
22. The PK Fee has been quoted by me/us after taking into consideration all the terms and
conditions stated in the RFP Document, draft Concession Agreement, our own estimates
of costs and after a careful assessment of the Project and all the conditions that may affect
the Bid.
23. I/We confirm our having submitted the Bid Security of ___________________ (specify
Bid Security amount) to the MTC in accordance with the RFP Document. The Bid Security
in the form of a Bank Guarantee is attached.
24. I/We agree and understand that the Bid is subject to the provisions of the Bidding
Documents. In no case, I/We shall have any claim or right of whatsoever nature if the
Project / Concession is not awarded to me/us or our Bid is not opened.
25. I/We agree and undertake to abide by all the terms and conditions of the Bidding
Documents including the RFP Document.
26. I/We agree to keep and confirm that our Bid is valid for 180 days from Bid Due Date and
till the signing of the Concession Agreement in accordance with the terms of the RFP if
selected as Preferred Bidder
27. We hereby agree and undertake that notwithstanding any qualifications or conditions,
whether implied or otherwise, contained in our Bid we hereby represent and confirm that
our Bid is unqualified and unconditional in all respects and we agree to the terms of the
Draft ConcessionAgreement, a draft of which also forms a part of the RFP Document
provided to us.
Page 42 of 82

<!-- page 44 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

28. I/ We hereby submit our Bid as indicated in Price Bid for undertaking the aforesaid Project
in accordance with the RFP Document.
29. I/ We undertake that we have not mentioned the Price Bid i.e. the PK Fee, anywhere in
the Technical Bid. I/ We also undertake that in the case I/We have mentioned the same,
my/ our Bid will be rejected.
30. I/We shall undertake that we abide by all the applicable laws of India.

Dated this ……………………..Day of …………………., 20…...
Name of the Bidder
Signature of the Authorised Person
Name of the Authorised Person

…………………………………………….
…………………………………………….

Note:
 On the Letterhead of the Bidder or Lead Member of Consortium.
 To be signed by the lead member, in case of a Consortium.

Page 43 of 82

<!-- page 45 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 2 - BID SECURITY
Format of Bank Guarantee
(To be stamped in accordance with Stamp Act, if any, of the country of the issuing Bank)

Bank Guarantee No. ………………………………
Date ………………………………………………

To,
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com

Dear Sir(s),
B.G. No.

dated

.

This Deed of Guarantee executed at ——————— by
_ (Name of Bank) having its
Head/Registered office at
(hereinafter referred to as the
“Guarantor”) which expression shall unless it be repugnant to the subject or context thereof
include its, successors and assigns;
In favour of Managing Director, Metropolitan Transport Corporation (Chennai) Ltd. (hereinafter
referred to as the “MTC”), having its office at Managing Director, No.2, Pallavan Illam, Pallavan
Salai, Chennai – 600 002 , which expression shall unless it be repugnant to the subject or context
thereof include its, successors and assigns;
WHEREAS
A. M/s
, a company duly incorporated under the provisions of the
Companies Act, 2013, having its registered office at
(hereinafter referred to as the
“Bidder”) which expression shall unless it be repugnant to the subject or context thereof
include its/their executors, administrators, successors and assigns, has/have bid for Request
for Proposal for Procurement, Supply, Operation and Maintenance of 300 AC 7metre Low
Floor Electric Buses and Development of Allied Electric and Civil Infrastructure on Gross Cost
Contracting for The Metropolitan Transport Corporation (Chennai) Ltd (herein after referred
to as the “Project”).
B. In terms of Clause 2.22.4 of Volume I of the Request for Proposal Document dated ———
issued in respect of the Project (hereinafter referred to as the “RFP Document”) the Bidder
is required to furnish to MTC, Chennai an unconditional and irrevocable Bank Guarantee for
Page 44 of 82

<!-- page 46 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

an amount of Rs. (Rupees Only) (type appropriate amount) as Bid Security.
C. The Guarantor has at the request of the Bidder and for valid consideration agreed to provide
such Bank Guarantee being these presents:
NOW THEREFORE THIS DEED WITNESSETH AS FOLLOWS:
a. The Guarantor, as primary obligor shall, without demur, pay to MTC, Chennai an amount not
exceeding Rs.______ (Rupees __________________Only) (type appropriate amount),
within five (5) days of receipt of a written demand from MTC, Chennai calling upon the
Guarantor to pay the said amount and stating that the Bid Securityprovided by the Bidder has
been forfeited in terms of Clause 2.22.7 of Volume I of the RFP Document.
b. Any such demand made on the Guarantor by MTC shall be conclusive and absolute as
regards the forfeiture of Bid Security and the amount due and payable by the Guarantor under
this Guarantee.
c. The above payment shall be made without any reference to the Bidder or any other person
and irrespective of whether the claim of MTC is disputed by the Bidder or not.
d. This Guarantee shall be unconditional and irrevocable and remain in full force for a period of
180 days or for such extended period as may be mutually agreed between MTC and the
Bidder and shall continue to be enforceable till all amounts under this Guarantee are paid.
e. The Guarantee shall not be affected by any change in the constitution or winding up of the
Bidder/the Guarantor or any absorption, merger or amalgamation of the Bidder/the Guarantor
with any other person.
f.

In order to give full effect to this Guarantee, MTC shall be entitled to treat the Guarantor as
the principal debtor. The obligations of the Guarantor shallnot be affected by any variations in
the terms and conditions of the RFP Document or other documents or by extension of time
of performance of any obligations granted to the Bidder or postponement/non
exercise/delayed exercise of any of its rights by MTC against the Bidder or any indulgence
shown by MTC to the Bidder. and. the Guarantor shall not be relieved from its obligations
under this Bank Guarantee on account of any such variation, extension,postponement, nonexercise, delayed exercise or omission on the part of MTC or any indulgence by MTC to the
Bidder to give such matter or thing whatsoever which under the law relating to sureties would
butfor this provision have effect of so relieving the Guarantor.

g. The Guarantor has power to issue this Guarantee and discharge the obligations contemplated
herein, the undersigned is duly authorised to execute this Guarantee pursuantto the power
granted under ——————.
IN WITNESS WHEREOF THE GUARANTOR HAS SET ITS HANDS HEREUNTO ON THE
DAY, MONTH AND YEAR FIRST HEREINABOVE WRITTEN.

Signed and Delivered by ——————Page 45 of 82

<!-- page 47 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Bank by the hand of Mr.——————its ——————— and authorised official.

Page 46 of 82

Volume I: RFP Document

<!-- page 48 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 3 - POWER OF ATTORNEY FOR SIGNING OF THE BID
(To be on non-judicial stamp paper of appropriate value as per Stamp Act relevant to place of
execution duly attested by notary public)

Know all men by these presents, We........................................................... (name and address
of the registered office of the Bidder) do hereby constitute, appoint and authorize
Mr./Ms……………………………………………… (name and residential address) who is presently
employed with us and holding the position of ............................................... as our attorney, to do
in our name and on our behalf, all such acts, deeds and things necessary in connection with or
incidental to our Bid for Request for Proposal for Procurement, Supply, Operation and
Maintenance of 300 AC 7metre Low Floor Electric Buses and Development of Allied
Electric and Civil Infrastructure on Gross Cost Contracting for The Metropolitan Transport
Corporation (Chennai) Ltd (“Project”), including signing and submission of all documents
related to the Bid, including, undertakings, letters, certificates, acceptances, clarifications,
guarantees, etc., making representations to the Metropolitan Transport Corporation (Chennai)
Ltd (MTC), and providing information / responses to the MTC, representing us in all matters
before the MTC including negotiations, and generally dealing with the MTC in all matters in
connection with our Bid for the said Project till the completion of the bidding process in
accordance with the RFP.
We hereby agree to ratify all acts, deeds and things lawfully done by our said attorney pursuant
to this Power of Attorney and that all acts, deeds and things done by our aforesaid attorney shall
and shall always be deemed to have been done by us.
All the terms used herein but not defined shall have the meaning ascribed to such terms under
the RFP.

For
_____________________________________
[Insert name of the Bidder on whose behalf PoA is executed]

…………………..
(Signature)
(Name, Title and Address)

Accepted

………..………… (Signature of the Attorney)
(Name, Title and Address of the Attorney)
Notes:
Page 47 of 82

<!-- page 49 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

1. To be executed by Bidder or the Lead Member (in the case of a Bidding Consortium), as
the case maybe.
2. The mode of execution of the Power of Attorney should be in accordance with the
procedure, if any, laid down by the applicable law and the charter documents of the
executant(s) and when it is so required, the same should be under common seal of the
executant affixed in accordance with the applicable procedure.
3. Also, wherever required, the executant(s) should submit for verification the extract of the
charter documents and documents such as a Board resolution / power of attorney, in
favour of the Person executing this power of attorney for delegation of power hereunder
on behalf of the executant(s).

Page 48 of 82

<!-- page 50 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 4 - POWER OF ATTORNEY FOR LEAD MEMBER OF CONSORTIUM
TO BE PROVIDED BY ALL THE MEMBERS OF THE CONSORTIUM IN FAVOUR OF
THE LEAD MEMBER
(To be on non-judicial stamp paper of appropriate value as per Stamp Act relevant to place
of execution)
Whereas the Government of Tamil Nadu (“GOTN”) has invited bids from interested parties
for Procurement, Supply, Operation and Maintenance of 300 AC 7metre Low Floor
Electric Buses and Development of Allied Electric and Civil Infrastructure on Gross
Cost Contracting for The Metropolitan Transport Corporation (Chennai) Ltd (the
“Project”),
Whereas the members of the Consortium are interested in bidding for the Project and
implementing theProject in accordance with the terms and conditions of the Request for
Proposal (RFP) Document and other connected documents in respect of the Project, and
Whereas, it is necessary under the RFP Document for the members of the Consortium to
designate the Lead Member with all necessary power and authority to do for and on behalf
of the Consortium, allacts, deeds and things as may be necessary in connection with the
Consortium’s bid for the Project who,acting jointly, would have all necessary power and
authority to do all acts, deeds and things on behalf of the Consortium, as may be necessary
in connection the Consortium’s bid for the Project.
NOW THIS POWER OF ATTORNEY WITNESSETH THAT.
We, M/s. ……………… (Lead Member), and M/s ....................... …….
(the
respective
names and addresses of the registered office) do hereby designate M/s._______ being
one of the members of the Consortium, as the Lead Member of the Consortium, to do on
behalf of the Consortium,all or any of the acts, deeds or things necessary or incidental to
the Consortium’s bid for the Project, including submission of Bid, participating in
conferences, responding to queries, attending negotiations submission of information/
documents and generally to represent the Consortium in all its dealings with GoTN, any
other Government Agency or any person, in connection with the Project until culminationof
the process of bidding and thereafter till the Concession Agreement is entered into with
GoTN.
We hereby agree to ratify all acts, deeds and things lawfully done by Lead Member, our
said attorney pursuant to this Power of Attorney and that all acts’ deeds and things done
by our aforesaid attorney shall and shall always be deemed to have been done by
us/Consortium.
Dated this the ……Day of .......... 20…
…………………………………
(Executants)
Note: The mode of execution of the Power of Attorney should be in accordance with the
procedure, if any, laid down by the applicable law and the charter documents of the
Page 49 of 82

<!-- page 51 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

executant(s)and when it is so required the same should be under common seal affixed in
accordance with the required procedure

Page 50 of 82

<!-- page 52 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 5 - FORMAT FOR BIDDER’S COMPOSITION AND OWNERSHIP STRUCTURE

1. Corporate Details: Please provide the following information for the Bidder. If the Bidder
is a Consortium, please provide this information for each Member including the Lead
Member:
a) Company’s Name, Address, and Nationality:
………………………………………………

Name:

Address: …………………………………………………………………………………………………
…………………………………………………………………………………………………
Website Address: ………………………………………………
Country of Origin: ………………………………………………
b) Year Organized: ………………………………………………
c) Company's Business Activities: ………………………………………………
d) Status as a Bidder:
i. Bidder
ii. Lead Member of the Bidding Consortium
iii. Member of the Bidding
Consortium Note: tick the
applicable serial number
e) Company's Local Address in India (if applicable):
………………………………………………….
………………………………………………….
………………………………………………….
f)

Name of the Authorized Signatory: .............................................

g) Telephone Number: ……………………………………………….
h) Email Address: ……………………………………………….
i)

Telefax Number: ……………………………………………….

j)

Please provide the following documents:
i.

Copy of the Memorandum and Articles of Association and certificate of
incorporation or other equivalent organizational document (as applicable),
including their amendments, certified by the Company Secretary as Attachment 1 for Bidder / each Member of Consortium including Lead Member.

2. Details of Ownership Structure:
Equity holding of Bidder/ each Member of Bidding Consortium including Lead Member
owning 10% or more of total paid up equity.

Page 51 of 82

<!-- page 53 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

Name of the Bidder / Consortium Member....... Status of equity holding as on
…………………………
Name of the Equity
Holder

Type and No. of
Shares owned

Extent of Voting Control (%)

Notes:
i. The above table is to be filled in separately for each Consortium Member.
ii. Status of equity holding should be provided not earlier than thirty (30) days prior to Bid Due Date.

For and on behalf of Bidder / Lead
M/s………………………………………………….

Member

………………………………….. (Signature of authorized
representative)
Name:
……………………………………………………
Designation: ………………………………………………

(Stamp) ……………………………..

Date:
……………………………
Place: ……………………………

Page 52 of 82

of

the

Bidding

Consortium

<!-- page 54 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 6 - FORMAT FOR JOINT BIDDING AGREEMENT
(To be on non-judicial stamp paper of appropriate value as per Stamp Act)

THIS JOINT BIDDING AGREEMENT executed on this....................... day of two thousand..................
between M/s................................................................,
a company incorporated under the laws of
...................................... and having its Registered Office at (hereinafter called the "Party 1”, which
expression shall include its successors, executors and permitted assigns) and M/s a
Company
incorporated under the laws of
and having its Registered Office at
...................................(hereinafter called the "Party 2", which expression shall include its successors,
executors and permitted assigns) and for the purpose of submitting the Bid, executing the Project (in
case of award) and entering into other Agreement(s) as specified in the RFP (hereinafter referred to
as “Agreements”) as may be entered into with the Metropolitan Transport Corporation (Chennai)
Limited (MTC).
WHEREAS, the MTC had invited Bid in response to RFP issued to…(insert the name of purchaser of
Request for Proposal for Procurement, Supply, Operation and Maintenance of 300 AC 7metre Low
Floor Electric Buses and Development of Allied Electric and Civil Infrastructure on GCC for The
Metropolitan Transport Corporation (Chennai) Ltd (“Project”).
AND WHEREAS, Clause 2.1.12(h) of the RFP document stipulates that the Bidders qualifying on the
strength of a Consortium will have to submit a legally enforceable Joint Bidding Agreement in a format
specified in the RFP document wherein the Consortium Members have to commit equity of a specific
percentage in the Project.
AND WHEREAS, Clause 2.1.12(h) of the RFP document also stipulates that the Consortium shall
provide along with the Bid, a Joint Bidding Agreement as per prescribed format whereby the
Consortium Members undertake to be liable for raising the required funds for its respective equity
investment commitment as specified in Joint Bidding Agreement.
NOW THEREFORE, THIS INDENTURE WITNESSTH AS UNDER:
In consideration of the above premises and agreement all the parties in this Consortium do hereby
mutually agree as follows:
1. In consideration of the selection of the Consortium as the successful bidder by the MTC, we the
Members of the Consortium and parties to the Joint Bidding Agreement do hereby unequivocally
agree that M/s. ........................................................... (Insert name of the Lead Member), shall act
as the Lead Member as defined in the RFP for self and agent for and on behalf of, ..................,
.............., ...................................................................... (the names of all the other Members of the
Consortium to be filled in here).
2. The Lead Member is hereby authorized by the Members of Consortium and parties to the Joint
Bidding Agreement to bind the Consortium and receive instructions for and on behalf of the
Members.
3. Notwithstanding anything contrary contained in this Joint Bidding Agreement, the Lead Member
shall always be liable for the equity investment obligations of all the Consortium Members, i.e., for
both its own equity contribution as well as the equity contribution of other Members.
Page 53 of 82

<!-- page 55 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

4. The Lead Member shall be liable and responsible for ensuring the individual and collective
commitment of each of the Members of the Consortium in discharging all their respective equity
obligations. Each Consortium Member further undertakes to be individually liable for the
performance of its part of the obligations without in any way limiting the scope of collective liability
envisaged in this agreement.
5. Subject to the terms of this agreement, the share of each Member of the Consortium in the “issued
equity share capital of the SPV” shall be in the following proportion: (if applicable)

Name

Percentage
of
equity
holding in the Project

Party 1

……….

Party 2

……….

Party 3

……….

Total

100%

[Note: The percentage equity holding for any Consortium Member in the Project cannot
be zero in the above table]
6. The Lead Member shall inter alia undertake full responsibility for liaising with lenders and mobilizing
debt resources for the Project and achieving financial closure.
7. In case of any breach of any of the equity investment commitment by any of the Consortium
Members, the Lead Member shall be liable for the consequences thereof.
8. Except as specified in the Agreement, it is agreed that sharing of responsibilities as aforesaid and
equity investment obligations thereto shall not in any way be a limitation of responsibility of the Lead
Member under these presents.
9. It is further specifically agreed that the financial liability for equity contribution of Lead Member shall,
not be limited in any way so as to restrict or limit its liabilities. The Lead Member shall be liable
irrespective of their scope of work or financial commitments.
10. It is expressly understood and agreed between the Members that the responsibilities and
obligations of each of the Members shall be as delineated as annexed hereto as Attachment - I to
this Joint Bidding Agreement, forming integral part of this agreement. It is further agreed by the
Members that the above sharing of responsibilities and obligations shall not in any way be a
limitation of joint and several responsibilities and liabilities of the Members, with regards to all
matters relating to the Project.
11. That the Parties shall be jointly and severally liable for the execution of the Project in accordance
with the terms of the Concession Agreement to be executed on award of the Project.
12. It is clearly agreed that the Lead Member shall ensure performance under the Agreements and if
one or more Consortium Members fail to perform its /their respective obligations under the
Agreement(s), the same shall be deemed to be a default by all the Consortium Members.
Page 54 of 82

<!-- page 56 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

13. This Joint Bidding Agreement shall be construed and interpreted in accordance with the Laws of
India and courts at Chennai alone shall have the exclusive jurisdiction in all matters relating thereto
and arising there under.
14. It is hereby agreed that the Lead Member shall furnish the bid security, on behalf of the Consortium
Members.
15. It is hereby agreed that in case of selection of Consortium as the Successful Bidder, the parties to
this Joint Bidding Agreement do hereby agree that they shall furnish the Performance security in
favor of the Authority, as stipulated in the RFP and Concession Agreement.
16. It is further expressly agreed that the Joint Bidding Agreement shall be irrevocable and shall form
an integral part of the RFP document and shall remain valid till the execution of the Concession
Agreement, unless expressly agreed to the contrary by the MTC.
17. It is hereby agreed that in case of selection of Consortium as the Successful Bidder, the members
of the Consortium shall form an SPV (Project Implementing Entity) to execute the Concession
Agreement and implement the Project. The OEM or its Associate whose technical capacity has
been used to fulfil the Technical Qualification Criteria shall mandatorily hold minimum 26%
subscribed and paid-up equity share capital in the SPV, throughout the period of the Agreement.
18. The Lead Member is authorized and shall be fully responsible for the accuracy and veracity of the
representations and information submitted by the Consortium Members respectively from time to
time in response to the RFP and for the purposes of the Project.
19. It is hereby expressly agreed between the parties to this Joint Bidding Agreement that neither party
shall assign or delegate its rights, duties or obligations under this agreement except with the prior
written consent of the MTC.
THIS JOINT BIDDING AGREEMENT:
a) has been duly executed and delivered on behalf of each party hereto and constitutes the legal,
valid, binding and enforceable obligation of each such party, sets forth the entire understanding
of the parties hereto with respect to the subject matter hereof;
b) may not be amended or modified except in writing signed by each of the parties and with prior
written consent of the MTC.

IN WITNESS WHEREOF, the parties to the Joint Bidding Agreement have, through their
authorized representatives, executed these present on the Day, Month and Year first mentioned
above.

For and on behalf of Consortium Member 1 (Party 1)
M/s………………………….

....................................................
(Signature of authorized signatory)
Page 55 of 82

<!-- page 57 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Name:
………………………….
Designation:...........………………..
Place: ……………………………..
Date: ………………………………
For and on behalf of Consortium Member 2 (Party 2)
M/s………………………….

....................................................
(Signature of authorized signatory)
Name: ……………………………
Designation:………………………
Place:……………………………….
Date:………………………………...

Attested:………………………………..
(Signature) (Notary Public)

Place:……………………….
Date: ……………………….

Page 56 of 82

Volume I: RFP Document

<!-- page 58 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

Attachment - I to the Joint Bidding Agreement

Name of the Consortium
Member

Responsibilities
Agreement

under

Party 1

Party 2

Party 3

Page 57 of 82

the

Joint

Bidding

<!-- page 59 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 7 - FORMAT FOR LETTER OF UNDERTAKING
(To be on non-judicial stamp paper of appropriate value as per Stamp Act)
[To be executed by the Associate Supported by Board Resolution* and submitted by the Bidder along
with the Bid, in case Bidder is relying on the strength of its Associate for meeting the stipulated
Financial/Technical Qualification]
Ref.: NIT/Bid Document No.:
Our Reference No ..........................................

Date: ......................

Bidder's Name and Address:
To,
___________
___________
___________

Dear Sir/Madam,
1.

We, M/s (Name of the Associate) declare that we are the associate of M/s (Name of the
Bidder) and have controlling interest therein. M/s.
(Name of the Bidder) proposes to submit
the bid for Procurement, Supply, Operation and Maintenance of 300 AC 7metre Low Floor Electric
Buses and Development of Allied Electric and Civil Infrastructure on Gross Cost Contracting for
The Metropolitan Transport Corporation (Chennai) Ltd. under RFP reference no..........................
dated. and have sought strength and support from us for meeting the stipulated Financial Capacity
as per Clause 2.2.4 of the RFP and its subsequent amendment.

2.

We hereby undertake that we hereby pledge our unconditional & irrevocable financial support for
the execution of the said Project to M/s …….. (Name of the Bidder), for the execution of the Project,
in case they are notified as the Successful Bidder under the provisions of the RFP. We further agree
that this undertaking shall be without prejudice to the various liabilities that M/s (Name of Bidder)
would be required to undertake in terms of the Agreement including the Performance Security as
well as other obligations of M/s (Name of the Bidder).

3.

This undertaking is irrevocable and unconditional and shall remain in force till the successful
execution and performance of the entire Agreement and/or till it is discharged by MTC.

Page 58 of 82

<!-- page 60 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

Witness:

Yours faithfully,
(1)

...................................

(Signature of Authorized Signatory) on behalf of the Associate Name &
Designation ...............................

(Seal of Holding Company)

*Note: Bidder may strike off point no. 4 above, if board meeting could not be scheduled before bid
submission date. The undertaking may be signed by the Chairman of the Board of the Associate.

Page 59 of 82

<!-- page 61 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 8 – FORMAT FOR AFFIDAVIT
(To be on non-judicial stamp paper of appropriate value as per Stamp Act)

We [including any of our Associate and Consortium Member], hereby declare that as on Bid
Due Date:
a. the Bidder & any of its Associate including any Consortium Member, their directors or
key personnel have not been barred or included in the blacklist by any government agency
or authority in India, the government of the jurisdiction of the Bidder or Members where
they are incorporated or the jurisdiction of their principal place of business, or by any
international financial institution such as the World Bank Group, Asian Development
Bank, African Development Bank, Inter- American Development Bank, Asian
Infrastructure Investment Bank etc. or the United Nations or any of its agencies.
b. the Bidder & any of its Associate including any Consortium Member & any of its Associate
or their directors have not been convicted of any offence in India or abroad.
c. We further declare that following investigations are pending / no investigation is pending
[strike off whichever is not applicable] against us [including any of our Consortium
Member or Associate or Parent] or CEO or any of our directors/ manager/key managerial
personnel of the Applicant /Consortium Member or their Associate.
d. We further undertake to inform the MTC of any such matter as mentioned above on its
occurrence after the date of this affidavit till the Effective Date.
e. We undertake that, in case, any information provided in relation to this affidavit is found
incorrect at any time hereafter, our Bid / LoA / concession agreement (if executed) would
stand rejected / recalled / terminated, as the case may be.

…………………………………….
Signature and Name of the authorized signatory of the Bidder / Lead Member of the
Bidding Consortium

…..................................(Signature of Notary Public)

Place:

…………………………

Date:

…………………………

Note: In case any investigation is pending against the Applicant, including any Consortium
Member or Associate, or CEO or any of the directors/ manager/key managerial personnel
of the Applicant /Consortium /Member or their Associate, full details of such investigation
including the name of the investigating agency, the charge/offence for which the investigation
has been launched, name and designation of persons against whom the investigation has
been launched and other relevant information should be disclosed under this affidavit.
Page 60 of 82

<!-- page 62 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 9 - FORMAT FOR FINANCIAL QUALIFICATION REQUIREMENT (MINIMUM AVERAGE
ANNUAL TURNOVER)
On the Letterhead of the Bidder/Lead Member of Consortium
To,
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com
Sub: Bid for Request for Procurement, Supply, Operation and Maintenance of 300 AC 7metre
Low Floor Electric Buses and Development of Allied Electric and Civil Infrastructure on Gross
Cost Contracting for The Metropolitan Transport Corporation (Chennai) Ltd
Dear Sir/Madam,
1.

[Note: Applicable in case of Bidder]

We certify that the (Name of Bidder/Associate had a Minimum Average Annual Turnover
(MAAT) INR Crore computed as per provisions of the RFP based on unconsolidated audited
annual accounts, calculated as an average turnover of the last 3 years, as mentioned in Clause
2.2.10 of the RFP.

Name
of
Bidder/Associate

Relationship
withBidder

Financial Year

MAAT (Rs. Crore)

MAAT (Average of 3 years)

** The column for “Relationship with Bidder” is to be filled in only in case financial
capability of Associate has been used for meeting Qualification Requirements.
2.

[Note: Applicable in case of Consortium]

Page 61 of 82

<!-- page 63 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

We certify that the (Name of Bidder/ Associate) had Minimum Average Annual Turnover
(MAAT) INR Crore computed as per provisions of the RFP based on unconsolidated audited
annual accounts, calculated as an average turnover of the last 3 years, as mentioned in the
RFP.

Name
of
Consortium
Member

Equity Commitment in
theProject (%)

1

2

Financial Year

MAAT of Member
(Rs. Crore)

3 (As per
tablebelow)

1. ……………
2. ……………
..
MAAT (Average of 3 years)
The above certificate is to be provided separately by each Member of the Consortium
Member – I (Lead Member)
[Note: Similar particulars for each Member of the Consortium is to be furnished, duly certified
by theMember’s Statutory Auditors]
i. Name of Member: ............................................
ii. Total MAAT: Rs _________ Crore
iii. Percentage of equity commitment for the Project by the Member:%

Name
of
Bidder/Associate

Relationship
withBidder**

Financial Year

MAAT (Average of 3 years)

Page 62 of 82

MAAT (Rs. Crore)

<!-- page 64 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

** The column for “Relationship with Member of Consortium” is to be filled in only in case the
financial capability of Associate has been used for meeting Qualification Requirements;

Yours faithfully
………………………………………
(Signature and name of the authorized signatory of the Bidder/each member of the
Consortium andStamp)

Name : ………………………………….
Date : ………………………………….
Place : ………………………………….

Notes:
1. Audited consolidated annual accounts of the Bidder may be used for the purpose of financial
criteria provided the Bidder has at least 26% equity in each company whose accounts are
merged in the audited consolidated accounts and provided further that the financial
capability of such companies (of which accounts are being merged in the consolidated
accounts) shall not be considered again for the purpose of evaluation of the Bid.
2. In case Bidder or a Member of Consortium takes recourse to its Associate for meeting
technical / financial requirements, then the financial years considered for such purpose
should be same for the Bidder / Member of Consortium and their respective Associate.

Page 63 of 82

<!-- page 65 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

Appendix 9A
{On Statutory Auditor’s Letterhead}
[In case of Consortium, all members should provide MAAT Certificate]

This is to certify that the Minimum Annual Average Turnover (MAAT) furnished by
____________________ for last 3 Financial Years, preceding bid due date, is as detailed below
and as furnished in the enclosed statement of accounts, is verified by us and found correct.

Turnover
In case of Single Bidder:
Financial
Year
Turnover

In case of consortium:
Financial Year
Lead MemberTurnover
Second MemberTurnover
Third MemberTurnover

CHARTERED ACCOUNTANT:
(Signature with Seal)
My Membership No:
Address:

Page 64 of 82

<!-- page 66 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 10 - FORMAT FOR FINANCIAL QUALIFICATION REQUIREMENT (NETWORTH)

To,
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com

Sub: Bid for Request for Proposal for Procurement, Supply, Operation and Maintenance
of 300 AC 7metre Low Floor Electric Buses and Development of Allied Electric and Civil
Infrastructure on Gross Cost Contracting for The Metropolitan Transport Corporation
(Chennai) Ltd.
Dear Sir/Madam,
1.

[Note: Applicable in case of Bidder]

We certify that the (Name of Bidder /Associate had a Net worth of Rs _ _ _ _ _ _ _ Crore
computed as per provisions of the RFP based on unconsolidated audited annual accounts
(refer Note-2 below), as provided in Clause 2.2.4 of the RFP, as on Bid Due Date. Also, the
Net worth positive in the financial year preceding the Bid Due Date.

Name of
Associate

Bidder/

Relationship
with Bidder*

Financial Year

Net
worth
(Rs. Crore)**

* The column for “Relationship with Bidder” is to be filled in only in case financial capability of
Associate has been used for meeting Qualification Requirements.
**The net worth of last 3 years to be provided in the table
2.

[Note: Applicable in case of Consortium]

We certify that the (Name of Bidder/ Associate) had a minimum Net worth of Rs. …….. Crore
computed as per instructions in the RFP and based on unconsolidated audited annual
accounts (refer Note-2 below) as provided in Clause 7.1 of the RFP, as on
days prior to Bid
Due Date. Also, the Net worth positive in the financial year preceding the Bid Due Date.
Page 65 of 82

<!-- page 67 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Name of
Consortiu
m Member

Equity
Commitment
in the Project
(%)

Financial Year

Volume I: RFP Document

Net worth
of Member
(Rs.

Whether the
Member’s Net
worth is positive

Crore)*
Yes / No

1.
……………

Yes / No

2.
……………
..

Yes / No

The above certificate is to be provided separately by each Member of the Consortium
*The net worth of last financial year is to be provided in the table

Member – I (Lead Member)
[Note: Similar particulars for each Member of the Consortium is to be furnished, duly certified by
the Member’s Statutory Auditors]
............................................

i.

Name of Member:

ii.

Total Net worth requirement: Rs

iii.

Percentage of equity commitment for the Project by the Member:%

Name
of
Associate

Crore

Bidder/ Relationship with Financial Year
Bidder**

Net worth
(Rs. Crore)

** The column for “Relationship with Member of Consortium” is to be filled in only in case the
financial capability of Associate has been used for meeting Qualification Requirements;

Yours faithfully

Page 66 of 82

<!-- page 68 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

………………………………………
(Signature and name of the authorized signatory of the Bidder/each member of the Consortium
and Stamp)

Name : ………………………………….
Date : ………………………………….
Place : ………………………………….

1. Along with the above format, in a separate sheet, please provide details of computation of
Net worth of last financial year duly certified by Statutory Auditor.
2. Audited consolidated annual accounts of the Bidder may be used for the purpose of financial
criteria provided the Bidder has at least 26% equity in each company whose accounts are
merged in the audited consolidated accounts and provided further that the financial
capability of such companies (of which accounts are being merged in the consolidated
accounts) shall not be considered again for the purpose of evaluation of the Bid.
3. In case Bidder or a Member of Consortium takes recourse to its Associate for meeting
technical / financial requirements, then the financial years considered for such purpose
should be same for the Bidder / Member of Consortium and their respective Associate.

Page 67 of 82

<!-- page 69 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 10A - FORMAT FOR CERTIFICATION FOR NET WORTH FROM CHARTERED
ACCOUNTANT
(To be uploaded by the Bidder In case of consortium, by each partner as appropriate to demonstrate
that they meet the requirements on the letterhead of the Chartered Accountant)
Date:
To,
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com
Subject: Bid for Request for Proposal for Procurement, Supply, Operation and Maintenance of
300 AC 7metre Low Floor Electric Buses and Development of Allied Electric and Civil
Infrastructure on Gross Cost Contracting for The Metropolitan Transport Corporation (Chennai)
Ltd.
Dear Sir/Madam,
We have examined the books of accounts and other relevant records of <<Bidder / consortium Partner
Name along with registered address>>. On the basis of such examination and according to the
information and explanation given to us, and to the best of our knowledge & belief, we hereby certify
that the Networth of the bidder for the last financial year is positive.

In case of Single Bidder:
Financial Year
Net Worth

In case of consortium:
Financial Year
Lead Member- Net Worth
Second Member- Net Worth
Third Member Net Worth

(Signature of the Chartered Accountant) Name:
Designation:
My Membership No:
Page 68 of 82

<!-- page 70 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Date:
Company Seal
Address:

Page 69 of 82

Volume I: RFP Document

<!-- page 71 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 11- SELF CERTIFICATION FORMAT FOR TECHNICAL QUALIFICATION REQUIREMENT

To,
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
Address: No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com
Sub: Bid for Request for Proposal for Procurement, Supply, Operation and Maintenance
of 300 AC 7metre Low Floor Electric Buses and Development of Allied Electric and Civil
Infrastructure on Gross Cost Contracting for The Metropolitan Transport Corporation
(Chennai) Ltd.

Dear Sir/Madam,

We certify that M/s. ............... (Insert name of Bidder/ Associate) meets the Technical
Capacity stipulated in Clause 2.2.3 of the RFP, which is as follows:
a.
b.

manufactured and supplied at least 100 electric buses in at least 1(one) of the last 5 (five)
financial years prior to the Bid Due Date; or
manufactured and supplied an aggregate of at least 300 (three hundred) electric buses in the
last 5 (five) financial years prior to the Bid Due Date;
Strike out whichever is not applicable

[Below para to be included only in case the technical capacity of Associate is being used for
meeting the technical qualification criteria]
We further certify that the (Insert name of Bidder/ Associate) whose technical capability has
been used for meeting the technical qualification criteria qualifies as a Associate of the Bidder,
as per the provisions of the RFP.

Page 70 of 82

<!-- page 72 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 11A- FORMAT OF AFFIDAVIT FOR MANUFACTURING FACILITY AND MANUFACTURING
AND SUPPLY CAPACITY
(To be on non-judicial stamp paper of appropriate value as per Stamp Act)

This is to certify that _________________________ (name of the Bidder/consortium member)
has ____________________________________ (specify details of the bus manufacturing
facility) for the purpose manufacturing and supply of Battery Electric Buses
AND
We have the Supply Capacity in terms of Clause 2.2.3(c) this RFP in terms of specifications and
standards as provided in the draft Concession Agreement of Nos.____ units in a year.

(Signature of the Authorised Signatory)
Name:
Designation:

Instructions:
a. This certificate should be signed by an authorised signatory of the Bidder/ Member of
the Consortium (OEM) / Authorised signatory of the Associate (OEM) of the Power of
Attorney in favour of such authorised signatory shall have to be submitted.

Page 71 of 82

<!-- page 73 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

APPENDIX 11B- FORMAT
MANUFACTURING CAPACITY

OF

CERTIFICATE

FROM

Volume I: RFP Document

CHARTERED

ENGINEER

(To be on the Letter Head of the Chartered Engineer)
This is to certify that _________________________ (name of the Bidder/consortium member)
has the Supply Capacity in terms of Clause 2.2.3(c) this RFP in terms of specifications and
standards as provided in the draft Concession Agreement of Nos.____ units in a year.

(Signature of the Chartered Engineer)
Name:
Designation:

Page 72 of 82

FOR

<!-- page 74 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 11C- FORMAT - EXPERIENCE OF BUS MANUFACTURING AND SUPPLY
(On the Letter Head of the Bidder/Member of Consortium)

a. Details may be given for all types of electric Buses supplied by Bidder to Urban Public
Transport entities in India/ abroad in past five years.
b. Details are to be furnished for the supplies made by the Bidder in five years
S.No Contract4 placed Contract
(full
name
& No. & Date
Address of client)

Description
And Date of Completion Documentary
Quantity of Buses of Delivery (As per Evidence (Purchase
Ordered
Contract)
Order / Bus Purchase
Agreement/ work
Completion
certificate) *

1

2

3

4

5

6

*: i. Copy of the documentary evidences, signed by the Authorised Signatory shall be attached.
ii. In case of experience outside India, relevant experience certificates shall be translated in English
and apostilled by the concerned authorities of Indian Embassy of the respective country.
signature and seal of the bidder/consortium member/Associate (supplying the buses)

4 Contract refers to either Supply Agreement/Purchase Order/Supply Contract

Page 73 of 82

<!-- page 75 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 12 - RELATIONSHIP & DETAILS OF EQUITY SHAREHOLDING
[To be filled by Bidder / each Member of the Bidding Consortium including Lead
Member if credentials of Associates have been used by them]
To
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com

Sub: Bid for Request for Proposal for Procurement, Supply, Operation and Maintenance
of 300 AC 7metre Low Floor Electric Buses and Development of Allied Electric and Civil
Infrastructure on Gross Cost Contracting for The Metropolitan Transport Corporation
(Chennai) Ltd.
Dear Sir/Madam,

We certify that M/s. .............. (insert name of the Bidder / Consortium Members) have
considered the technical and financial capability of its Associate, for the purpose of meeting
Qualification Requirements as per the instructions provided in the RFP. The name of
Associate, nature of relationship(s) with such Associate and details of equity holding are as
follows:

Name of Company Type of credentials
whose
credentials considered
(technical and / or
considered
financial)

Relationship
with Details of equity
Bidder / Consortium shareholding
(refer
notes
Member (Associate)
below)

Company 1
…………….
…………….
…………….
……………..

Page 74 of 82

<!-- page 76 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

NOTES:
i.

In case of Parent, the equity holding of the Parent in the Bidder / Member of the
Bidding Consortium, including the Lead Member of the Consortium, need to be
specified.

ii.

In case of Associate under direct control of Bidder, the equity holding of the Bidder /
Member of the Bidding Consortium, including the Lead Member of the Consortium in the
Associate, needs to be specified.

iii. In case of Associate under common control of Parent, the equity holding of the Parent in the
Associate of the Bidder / Member of the Bidding Consortium, including the Lead Member of
the Consortium, needs to be specified.
iv. Relationship of Associate with Bidder / Member of Consortium to be on the date which
falls between 7 to 15 days, prior to the Bid Due Date.

Yours faithfully

………………………………
(Signature and name of the authorized signatory of the Company and stamp)

Name: …………………………
Date: …………………………
Place: …………………………

……………………………………
(Signature and Stamp of statutory Auditors of Bidder / each Member of Bidding Consortium)

Name: ……………………………..
Date: ……………………………..
Place: ……………………………..
Date: ……………………………..

Page 75 of 82

<!-- page 77 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

Volume I: RFP Document

APPENDIX 13 - SELF-DECLARATION FOR TESTING CERTIFICATE
(to be submitted by OEM, whether he is a bidder or a member of consortium)
(To be submitted on OEM’s letter head)

To
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com

Sub: For providing testing certificate at the time of delivery

Ref: ----------------------------------------------------------

Dear Sir/Madam,

We hereby confirm and declare that we, M/s <<Name >, <<Address>.> (name of
OEM) will provide the bus type approval certificate (CMVR certificate), homologation
certificate for at least one 7 metres Low Floor (400mm) AC Electric Bus (100% battery
operated) from the designated testing centre in India. i.e., ARAI/ICAT/CIRT/ VRDE
prior to the delivery of first Lot Vehicle as per the Concession Agreement.

Thanking You.

Yours faithfully,

Signature
Printed
NameDesignationSeal......

Page 76 of 82

<!-- page 78 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on GCC

APPENDIX 14 - CERTFICATE
REQUIREMENT

REGARDING

Volume I: RFP Document

DECLARATION

OF

INDIGENIZATION

(to be submitted by OEM, whether he is a bidder or a member of consortium)
(To be submitted on OEM’s letter head)
To
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
Address: No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com,
Sub: Declaration of Indigenization requirement
Ref: NIT/Bid Document No:
............................................................................................................

Dear Sir/Madam,
This is to certify that products and services offered for the Project (RFQP Ref.

) by M/s.

(name of OEM), are in compliance with the following requirement of the subject
notification and details mentioned below:
Phased Manufacturing Program (PMP) guidelines issued by Ministry of Heavy Industries (MHI)
notified on 1st October 2021; F.No. 7(06)/2019-NAB-II(Auto) (20307) or as updated/applicable
from time to time along with any latest guidelines issued by MHI on PMP for Electric Vehicle (eBuses) as applicable on the date of delivery of buses.
Final certificates complying above, as applicable, shall be submitted at the time of delivery of
buses.
Thanking You
Yours faithfully,

Signature (Authorised Signatory of the Bidder/ Associate (OEM)/Statutory Auditor/ Cost Auditor/
Practicing CA – As applicable)

…………………………………
Printed
Name…………………………….
…………………………

Seal………………………

Date…………….
Place………………………
Page 77 of 82

UDIN

No

<!-- page 79 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on Gross Cost Contracting (GCC)

Volume I: RFP Document

APPENDIX 15 - CERTFICATE REGARDING DECLARATION OF LOCAL CONTENT
[On the Letter Head of Bidder/Consortium Member]

To
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com

Sub: Compliance of Minimum Local Content Requirement as mentioned in Ministry of Commerce
and Industry Trade and order no. P-45021/2/2017-PP(BE-II) dated 04th June 2020
Ref: RFP No: …………………………………………

Dear Sir/Madam,
This is to certify that following is the local content percentage ......................................... being
offered under
the Project (RFP No.
) by M/s (Name of OEM) are in compliance with
Ministry of Commerce and Industry order no: P-45021/2/2017-PP(BE-II) dated 04th June 2020
and the bidder shall strictly abide by all provisions of the subject notification.

Sr. No

Item/s

Percentage of Local Content

1

Thanking You,
Yours faithfully,
Signature (Authorised Signatory of the Bidder/ Associate (OEM)/Statutory Auditor/ Cost Auditor/
Practicing CA – As applicable)
…………………………………………
Printed
Name…………………………….
…………………………

Seal………………………

Date…………….
Place………………………

Page 78 of 82

UDIN

No

<!-- page 80 -->

Procurement, Supply, Operation and Maintenance of 300 AC
7metre Low Floor Electric Buses and Development of Allied Electric
and Civil Infrastructure on Gross Cost Contracting (GCC)

Volume I: RFP Document

APPENDIX 16 - COMPLIANCE FOR LAND BORDER RESTRICTIONS
Declaration regarding “Restrictions on procurement from a Bidder of a
country which shares aland border with India”
(To be submitted on Bidder’s Letter Head)
To
The Managing Director
Metropolitan Transport Corporation (Chennai) Ltd.
No.2, Pallavan Illam, Pallavan Salai,
Chennai – 600 002
Email: amprojects1.mtc@gmail.com
Dear Sir/Madam,
With

reference

to

our

bid

proposal

for

participation

in

RFP

Ref:

_______dated,_____I/we hereby confirm that, I/We have read the G.O.Ms No.
343, dated 18th September 2020 issued by the Finance [Salaries] Department
regarding restrictions on procurement from a bidder of a country which shares a
land border with India, on sub-contracting to contractors and on transfer of
technology from such countries “Restriction on Public procurement from bidders
of certain countries under Rule 144(xi) of General Financial Rules (GFRs)amended by Government of India – adopted by the State Government under
Tamil Nadu Transparency in Tenders Act, 1998.”
I/We certify that we/our OEM/suppliers/Consortium member/suppliers/subcontractors are/is not fromsuch a country and we will not sub-contract any work
to a contractor from such countries unless such contractor is registered with the
Competent Authority.
AND
“I/We certify that we/our OEM/suppliers/Consortium member/suppliers/subcontractors are/is not from such a country having Transfer of Technology (ToT)
arrangement requiring registration with theCompetent Authority.
OR

Page 79 of 82
