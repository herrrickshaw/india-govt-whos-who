---
doc_id: "fad0ec14def7f3ec"
source_url: "https://www.dge.tn.gov.in/docs/hsesslc/HSE_mar19_pvt_tatkal_210119.pdf"
ministry: "Directorate of Government Examinations, Tamil Nadu"
title: "HSE First and Second Year -March 2019 - Tatkal - Private Application Notification"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7c88770b7f072ad3"
---

<!-- page 1 -->

muR¤ nj®ÎfŸ Ïa¡ff«, br‹id-6
nkšãiy Kjyh« M©L k‰W« Ïu©lh« M©L bghJ¤ nj®ÎfŸ, kh®¢ 2019
“Áw¥ò mDkÂ Â£l¤Â‹” Ñœ jå¤nj®t®fëläUªJ é©z¥g§fŸ
tunt‰wš F¿¤j brŒÂ¡ F¿¥ò
kh®¢ 2019, nkšãiy Kjyh« M©L k‰W« Ïu©lh« M©L bghJ¤
nj®btGj nj®Î¤Jiwahš m¿é¡f¥g£l eh£fS¡FŸ M‹-iyåš
é©z¥Ã¡f¤ jt¿, j‰nghJ é©z¥Ã¡f éU«ò« jå¤nj®t®fëläUªJ
Áw¥ò mDkÂ Â£l¤Â‹ Ñœ M‹-iyåš é©z¥g§fŸ tunt‰f¥gL»‹wd.
M‹-iyåš é©z¥Ã¡f nt©oa njÂfŸ
jå¤nj®t®fŸ M‹-iyåš é©z¥Ã¥gj‰fhf x›bthU fšé
kht£l¤ÂY« muR¤ nj®Î¤ Jiw nrit ika« mik¡f¥g£LŸsJ.
jå¤nj®t®fŸ jh§fŸ vªj fšé kht£l¤ÂèUªJ é©z¥Ã¡»wh®fnsh,
mªj kht£l¤Âš mik¡f¥g£LŸs muR¤ nj®Î¤ Jiw nrit
ika¤Â‰F
21.01.2019 Kjš 22.01.2019 tiuæyhd eh£fëš neçš br‹W M‹-iyåš
é©z¥Ã¡f nt©L«.
fšé kht£l thçahf mik¡f¥g£LŸs muR¤ nj®Î¤ Jiw nrit
ika§fë‹ étu¤ij www.dge.tn.gov.in v‹w Ïizajs¤Âš m¿ªJ¡
bfhŸsyh«.
nkšãiy Kjyh« M©L nj®btGj é©z¥Ã¡f jFÂahdt®fŸ
1. kh®¢ 2018-š el¤j¥g£l nkšãiy Kjyh« M©L bghJ¤ nj®btGÂ
nj®¢Á bgwhj jå¤nj®t®fŸ (H tif), nj®¢Á¥ bgwhj ghl§fëš
Û©L« nj®btGj é©z¥Ã¡fyh«.
2. g¤jh« tF¥ò bghJ¤ nj®Î mšyJ mj‰F Ïizahd nj®éš nj®¢Á
bg‰W (kht£l¡ fšé mYty® thæyhf bg‰w Ïiz¢rh‹¿jœ
(Equivalence Certificate) rk®Ã¡f¥gl nt©L«) Xuh©L ÏilbtëÍ«
01.03.2019 m‹W 15 ½ taJ« ó®¤Â milªjt®fŸ k£Lnk “neuo¤
jå¤nj®t®fshf” (HP tifæd®) nj®btGj é©z¥Ã¡fyh«.
nkšãiy Ïu©lhkh©L nj®btGj é©z¥Ã¡f jFÂahdt®fŸ
1. kh®¢ 2018-š Ï¤Jiwahš el¤j¥g£l nkšãiy Kjyhkh©L bghJ¤
nj®éid neuo¤ jå¤nj®tuhf vGÂ nj®¢Á¥ bg‰w / bgwhj nj®t®fŸ
midtU«, kh®¢ 2019 nkšãiy Ïu©lhkh©L bghJ¤nj®btGj
é©z¥Ã¡fyh«.
2..

<!-- page 2 -->

..2..
2. giHa eilKiwæ‹go (x›bthU ghl¤Â‰F« 200 kÂ¥bg©fŸ Åj«
bkh¤j«
1200
kÂ¥bg©fS¡F)
nkšãiy
Ïu©lhkh©L
bghJ¤nj®btGÂ nj®¢Á bgwhnjh®, nj®¢Á bgwhj ghl§fëš
nj®btGj é©z¥Ã¡fyh«.
K¡»a¡ F¿¥ò:• V‰fdnt giHa eilKiwæ‹go (x›bthU ghl¤Â‰F« 200
kÂ¥bg©fŸ Åj« bkh¤j« 1200 kÂ¥bg©fS¡F) nkšãiy
Ïu©lhkh©L bghJ¤nj®btGÂ nj®¢Á bgwhnjh®
k‰W«
é©z¥Ã¤J tUifòçahnjh®, nj®¢Á bgwhj ghl§fëš giHa
eilKiwæ‹go (bkh¤j« 1200 kÂ¥bg©fS¡F) nj®btGj
#]‹ 2019 gUt« k£Lnk ÏWÂ thŒ¥ghF«.
nj®Î¡ f£lz«, M‹-iy‹ gÂÎ¡ f£lz étu« k‰W« brY¤J« éj« :
1.

V‰fdnt nkšãiy
Kjyhkh©L /
Ïu©lhkh©L bghJ¤
nj®btGÂ njhšéÍ‰w
ghl§fëš nj®btGJ«
jå¤nj®t®fŸ

2. nkšãiy Kjyhkh©L
mšyJ Ïu©lhkh©L
nj®éid Kj‹ Kiwahf
vGjÎŸs jå¤nj®t®fŸ

X›bthU
ghl¤Â‰F« M‹-iy‹ gÂÎ¡
%.50/Åj«
nj®Î¡ f£lz« %.50/f£lzK«,
mjDl‹
Ïju¡ f£lzkhf %35/-«
brY¤j nt©L«.

nj®Î¡ f£lz« %.150/Ïju¡ f£lz« %.35/bkh¤j« %.185/-

M‹-iy‹ gÂÎ¡
f£lz« %.50/-

Ït‰Wl‹ TLjyhf Áw¥ò mDkÂ f£lzkhf %.1000/-I gzkhf
nj®Î¤ Jiw nrit ika¤Âš brY¤j nt©L«.

muR¤

jå¤nj®t®fŸ brY¤j nt©oa nj®Î¡ f£lz¤ bjhif Registration
Slip –š F¿¥Ãl¥g£oU¡F«.

..3..

<!-- page 3 -->

..3..

muR¤ nj®Î¤ Jiw nrit ika¤Âš rk®¥Ã¡f nt©oa Mtz§fŸ
nkšãiy Kjyhkh©L (+1) nj®btGj é©z¥Ã¡F« jå¤nj®t®fŸ nrit
ika¤Âš (Service Centre) rk®¥Ã¡f nt©oa Mtz§fŸ
V‰fdnt +1 nj®btGÂ
njhšéÍ‰nwh®

Kj‹ Kiwahf +1 nj®btGJnth®

1.

cça nj®Î¡ f£lz«
+ 1.
Áw¥ò f£lz« %.1000/- +
M‹-iy‹ gÂÎ f£lz«
%.50/- M»at‰iw nrit
ika§fëš (Service Centre)
gzkhf¢ brY¤j nt©L«.

cça nj®Î¡ f£lz«
+ Áw¥ò f£lz«
%.1000/- + M‹-iy‹ gÂÎ f£lz« %.50/M»at‰iw nrit ika§fëš (Service
Centre) gzkhf¢ brY¤j nt©L«.

2.

Ïizajs«
gÂéw¡f« 2. g¤jh« tF¥ò nj®éš nj®¢Á bg‰wj‰fhd
brŒa¥g£l
V‰fdnt +1
mrš kÂ¥bg© rh‹¿jœ.
nj®btGÂaj‰fhd
(mšyJ)
kÂ¥bg©
g£oaš
(Statement of Marks) efš.
g¤jh« tF¥Ã‰F Ïizahd nj®éš nj®¢Á
bg‰wj‰fhd
mrš
rh‹¿jœ
k‰W«
m¢rh‹¿jœ
g¤jh«
tF¥Ã‰F
ÏizahdjJjh‹
v‹gj‰fhd
Ïiz¢rh‹¿jœ
(Equivalence
Certificate)
M»at‰iw f£lhakhf rk®¥Ã¡f nt©L«.

3. ---

3. gŸë kh‰W¢ rh‹¿jê‹ mrš

4. ---

4. Ïl¥bga®Î rh‹¿jœ mrš
(btë khãy¤ nj®t®fŸ k£L«)

..4..

<!-- page 4 -->

..4..

nkšãiy Ïu©lhkh©L (+2) nj®btGj é©z¥Ã¡F« jå¤nj®t®fŸ nrit
ika¤Âš (Service Centre) rk®¥Ã¡f nt©oa Mtz§fŸ
V‰fdnt +2 nj®btGÂ
njhšéÍ‰nwh®
1.

cça nj®Î¡ f£lz«
+ 1.
Áw¥ò f£lz« %.1000/- +
M‹-iy‹ gÂÎ f£lz«
%.50/- M»at‰iw nrit
ika§fëš (Service Centre)
gzkhf¢ brY¤j nt©L«.

òÂa eilKiwæ‹go (600 kÂ¥bg©fŸ) +2
nj®btGJnth®
cça nj®Î¡ f£lz«
+ Áw¥ò f£lz«
%.1000/- + M‹-iy‹ gÂÎ f£lz« %.50/M»at‰iw nrit ika§fëš (Service
Centre) gzkhf¢ brY¤j nt©L«.

2. ÏJtiu vGÂa nkšãiy 2. Ïizajs« _y« gÂéw¡f« brŒa¥g£l
Ïu©lh«
M©L
nkšãiy Kjyhkh©L (+1) nj®btGÂ bg‰w
nj®ÎfS¡fhd kÂ¥bg©
kÂ¥bg© g£oaš (Statement of Marks) efš.
rh‹¿jœfë‹ efš
3. nj®btGj
njitahd 3.
tUif¥ gÂÎ cŸsJ v‹gJ
bjhl®ghf gŸë¤ jiyik
MÁçaçl« bg‰w jFÂ¢
rh‹¿jœ (gŸë khztuhf
nj®btGj
gÂÎ
brŒJ
nj®btGjhjt®fS¡F
k£L«).

---

4. brŒKiw
4.
kÂ¥bg©fS¡fhd
Mtz« (brŒKiw ml§»a
ghl§fis¤ nj®btGJnth®
k£L«)

---

..5..

<!-- page 5 -->

..5..
nj®Î¡Tl mDkÂ¢ Ó£LfŸ éãnahf«
nj®Î¡ Tl mDkÂ¢ Ó£LfŸ Ïizajs¤Âš gÂéw¡f« brŒJ bfhŸs
nt©L«. gÂéw¡f« brŒa nt©oa eh£fŸ Ã‹d® m¿é¡f¥gL«.
Ïizajs¤Âš btëæl¥g£l m¿Îiufë‹go (nj®Î¡ f£lz étu«
jé®¤J) taJ tu«ò, fšé¤ jFÂ k‰W« ghl§fŸ tif¥ghL m¿ªJ mj‹go
é©z¥Ã¡f nt©L«.
jå¤nj®t®fS¡F¤
j‰nghJ
tH§f¥gL«
mDkÂ
K‰¿Y«
j‰fhèfkhdJ vdÎ«, jå¤nj®t®fë‹ é©z¥g« k‰W« jFÂ F¿¤J MŒÎ
brŒa¥g£l Ã‹dnu nj®Î KoÎfŸ btëæl¥gL« vdÎ« m¿é¡f¥gL»wJ.

x«./Ïa¡Fe®
br‹id-600 006
ehŸ: 09.01.2019
