---
doc_id: "df4b9ff41d7e90fc"
source_url: "https://annamalaiuniversity.ac.in/adm/downloads/2024-25/147-GO-05-05-2023.pdf"
ministry: "Annamalai University, Tamil Nadu"
title: "Reservation Policy"
date: ""
pages: 12
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "51ff3fc6be14a74c"
---

<!-- page 1 -->

1077
Ky 22 Q
ABSTRACT
Collegiate Education - Guidelines for Admission of students to UG/PG Courses in
Government / Government Aided / Self-financing Colleges of Arts and Science for
the Academic year 2023-24 - Orders - Issued.
Higher Education (G1) Department
G.O.(D)No.147 Dated 05.05.2023
சோபகிருது வருடம்‌, சித்திரை -22
திருவள்ளுவர்‌ ஆண்டு, 2054.
Read:—
1. G.O. (Ms) No.77, Higher Education (G1) Department, dated
18.07.2020.
2. G.O. (1D) No.161, Higher Education (G1) Department, dated
14.06.2022.
3. From the Director Collegiate Education Letter No.9096/M1/2023,
dated 04.05.2023.
ORDER:-

In the Government order first read above, orders have been issued to
introduce online registration of application for Tamil Nadu Government Arts and
Science Colleges Admission (TNGASA) from the academic year 2020-21.

2. In the Government order second read above, guidelines for admission
of students to UG/PG Courses in Government / Government Aided / University
Constituent/Self-financing Colleges of Arts and Science for the Academic year
2022-23 were issued.

3. In the letter third read above, the Director of Collegiate Education has
stated that a Committee headed by the Director of Collegiate Education comprising
of Joint Director (Finance), Joint Director (Planning & Development), Assistant
Director (self-financing colleges), Directorate of Collegiate Education and Principals
of various colleges was constituted for framing of guidelines for admission of
students to UG/PG Courses in Government / Government Aided / Self Financing
colleges of Arts and Science in Tamil Nadu for the academic year 2023-24 and has
requested the Government to issue necessary orders on the guidelines for
admission of students to UG/PG Courses in Government /Government Aided / Self-
Financing Colleges of Arts and Science in Tamil Nadu for the Academic year
2023-24.

2

<!-- page 2 -->

-2-.

4. The Government after careful examination approve the guidelines for
admission of students to UG/PG courses in Government / Government Aided/ Self-
Financing colleges of Arts and Science in Tamil Nadu, for the academic year 2023-24
annexed to this order and direct that the said guidelines be followed strictly.

(By Order of the Governor)
D. Karthikeyan
Principal Secretary to Government
To
The Director of Collegiate Education (FAC), Chennai-15.
All Regional Joint Directors of Collegiate Education.
[through Director of Collegiate Education (FAC)]
Copy to:-
All Sections in Higher Education Department, Chennai-9.
The Special Personal Assistant to Hon’ble Minister (Higher Education), Chennai-9.
The Personal Assistant to Principal Secretary to Government,
Higher Education Department, Chennai-9.
Sf/Sc.
Clean Copy (C.No.1803/G1/2023)
// Forwarded / By Order //
Section Officer
YY
o

<!-- page 3 -->

ANNEXURE
PROCEDURE FOR ADMISSION TO UG/PG COURSES IN
ARTS AND SCIENCE COLLEGES 2023-24
1. The procedure given in this communication is applicable to all the Government /

Government Aided / Self Financing Arts and Science Colleges in Tamil Nadu.

These are to be observed both in letter and spirit. Where otherwise stated these

procedure for admission to UG/PG courses are common for both.

2. The fee structure for various courses should be exhibited transparently in the
prospectus and to be uploaded in www.tngasa.in.

3. The Principal of the college and the admission committee will be responsible for
any violations in this regard.

4. Admission Committee is to be broadened to include senior teaching faculty,

number to be specified as either 3 or 4.

5. Implementation of Rules of Reservation should be followed strictly for each
course separately.

6. Admissions for aided course are to be conducted before admissions for each self
financing courses.

7. a) The applications must be made only in online mode.

b) The choices of colleges and courses, should be opted by the candidates at the
time of Registration.

௦) Filled in application should contain atleast one contact number through which
all communication should be sent.

8. Documents to be scanned and uploaded as per instructions in the web portal:

a) Qualifying Examination Mark Sheet / Provisional Marksheet.

b) Community Certificate (wherever applicable)

c) Certificate of proof when admission is sought under Differently Abled/ Sports
Quota/ NCC/Ex-Servicemen etc.

d) Transfer Certificate

e) Eligibility certificate for students from other States/ Boards / Universities.

f) As per Government letter No. 4527/G1/2003, dated 17.10.2003, admission
may be accorded purely on merit basis on production of Identity Card issued
by the concerned HQ Tahsildars in respect of students seeking admission
from Sri Lankan Tamil refugee camp and those who were not enrolled in
refugee camps may be admitted on production of VISA and Passport on merit
basis.

Original Certificates are to be produced at the time of admission only. However, if

a candidate fails to produce the relevant certificates in original, at the time of
admission, the admission shall be cancelled at any point of time.
1

<!-- page 4 -->

9. The online application fee is Rs.48/- and Registration fee is Rs.2/- for every 5
colleges applied. There is no application fee for SC/ST candidates but
Registration fee of Rs.2/- is to be paid for every block of five colleges.

10.The Registration of application for Government Arts and Science Colleges will
commence on 08.05.2023 and closed on 19.05.2023

11. _Age limit:

The upper age limit for admission to UG courses will be 21 (twenty one) years as
on 15 July 2023. However, a relaxation of 5 years is permitted for differently abled
candidates as per G.O.(Ms).No. 239, S.W. dated 3-9-93. SC/SCA/ST/BC/BCM/MBC/
DNC and women candidates may be allowed the age relaxation of 3 years beyond
21 years for the admission into UG Courses.

The above age limit should be strictly followed and no student should be
admitted above the age limit and no age relaxation will be granted by Government. If
the Colleges fail to adhere to the above instructions, severe action wil be taken
against the concerned college.

12. Admission Committee for UG and PG courses:

The Admission Committee is common for both UG and PG courses and it
should include the following members apart from Principal.
(i) Two Senior most staff members.
(ii) | A Senior most co-opted staff member belonging to SC/ST, one for UG
and one for PG.

13. Documents to be maintained

The following Registers and other related documents pertaining to students’
admission should be maintained and preserved by the colleges:

a) List of Applications received within the last date prescribed

b) Rank list should be signed by the members of the Selection Committee.

c) Rank list have to be displayed in the College Website.

d) Minutes of Selection Committee meeting.

e) Admission Register

f) Communication with the University/ Director of Collegiate Education related
to admission

g) Copies of all letters to the University/ Director of Collegiate Education making
requisition for increase in seats and letters from the University permitting
increase.

h) The colleges shall maintain registers regarding the applications received from
SC/SCA/ST/MBC/DNC/BC/BCM students who have been selected for
admission and the number of such candidates admitted in each course.

2;

<!-- page 5 -->

14. Rule of Reservation :

The admission shall be made purely on the basis of Merit subject to the rule of
reservation of the Government of Tamil Nadu. .

1) 31% for Open Competition (OC)

2) 26.5% for Backward Classes (BC) other than BC Muslims and
3.5% for Backward Classes Muslims.

3) 20% for Most Backward classes (MBC) and Denotified Communities (DNC)

4) 15% for Scheduled Castes (SC) and 3 % for SCA.

5) 1% for Scheduled Tribes (ST).

The rule of reservation will apply to :

a) 100% of seats in Government Colleges.

b) 50% of seats in the case of Aided minority colleges.

c) 90% of seats in the cases of Aided Non minority colleges.

d) 50% of seats in the Self-financing courses offered by the Aided Colleges.

e) 50% of seats in the cases of Self-financing Colleges

f) In respect of both Aided Courses and Unaided Courses in Minority Colleges,

50% of seats shall be filled by students belonging to minority concerned and

the balance 50% of the seats shall be filled by following the rule of

reservation.

However, wherever number of applications from minority communities is less
than 50% of total seats, the remaining minority quota shall be filled up following the
rule of reservation. Tamil Nadu native candidates alone will be considered for
communal reservation. Other State candidates will be considered under “Open
Competition”.

15. Muslim girls should not be denied admission into Colleges in their
neighbourhoods on the ground that they should seek admission only in their own
minority institutions as per Government Letter No.231/G1/98-5, dated: 5-12-2000.

16. Preparation of Rank-List for UG Courses:

For admission to Under Graduate courses (UG) a candidate must have
passed the Higher Secondary Examinations of Tamil Nadu or an examination
(like the CBSE) recognised by the Universities as equivalent thereto. Admission
should be made based on the +2 marks only.

The Rank-list will be out of 400 marks comprising a subject-component of 400
and admission to Government / Government Aided / Self Financing Colleges
order of merit / rank list against the priority of choices recorded by applicants.

(a) Rank list should be prepared based on the marks obtained by the students in
the subject component out of total 400 marks under Part III in Higher Secondary
examination held in the current Academic Year. Eligibility of students for admission
to UG Courses in the colleges shall be as per the eligibility norms and guidelines of
the Universities concerned. Apportionment of seats for each course with different
streams (80% Academic / 20% Vocational) and also Apportionment of seats among
students who have studied different subjects in the Higher Secondary (+2) shall be
made as per the existing norms. For the students passed Higher Secondary (+2)
prior to 2018-19 the marks can be converted to current stream. i.e to 400, instead of
800.

3

<!-- page 6 -->

(0) If more than one allied is offered for a particular major subject, 50% of the
seats shall be given to each allied.
SOME ILLUSTRATIONS ARE GIVEN BELOW
Group-! தொகுப்பு - | கட்டாயம்‌ படித்திருக்க வேண்டிய பாடங்கள்‌
(கணிதம்‌, இயற்பியல்‌, வேதியியல்‌
கணிதம்‌ பயின்ற மாணவர்களுக்கு மட்டும்‌)
Mathematies | Ranking based on marks in ன சயம்‌ கணிதம்‌ பமின்றிருக்க வேண்டும்‌.
_ ‘ பகுதி 111 மொத்த மதிப்பெண்‌ 400-க்கு Should have studied Mathematics.
இயற்பியல்‌ பெறப்பட்ட மதிப்பெண்கள்‌
2 Physics அடிப்படையில்‌ தரப்பட்டியல்‌.
Ranking based on marks in Part 111
ட்‌ ்‌ it of 400
புள்ளிபியல்‌ பதத [ம] மொத்த மதிப்பெண்‌ 400-க்கு 812/4 have studied Mathematics ம
3 Statistics பெறப்பட்ட மதிப்பெண்கள்‌ \Statistics or Business Mathematics
அடிப்படையில்‌ தரப்பட்டியல்‌.
(Group-II தொகுப்பு - 11
4 தாவரவியல்‌ (தாவரவியல்‌, விலங்கியல்‌, உயிரியியல்‌,
Botany, வேதியியல்‌ பயின்ற
Plant Biology &Plant ] மாணவர்களுக்காக)
Biotechnology ர்வ
Ranki ‘ks in Part III out
5 விலங்கியல்‌ BOO. | வேதியியல்‌ கட்டாயம்‌ பமின்றிருக்க வேண்டும்‌
Zoology, பகுதி 111 மொத்த மதிப்பெண்‌ 400-க்கு Should have studied Chemistry
Advanced Zoology & | பெறப்பட்ட மதிப்பெண்கள்‌
Biotechnology அடிப்படையில்‌ தரப்பட்டியல்‌.
உயிர்‌ வேதியியல்‌
Bio Chemistry
7 வேதியியல்‌ Ranking based on marks in Part Ill |Should have studied Chemistry &
Chemistry out of 400 Mathematics
பகுதி Ill மொத்த மதிப்பெண்‌ 400-க்கு Pos ufuc, ———_ ssomflgtb கட்டாயம்‌
பெறப்பட்ட மதிப்பெண்கள்‌ டித்திருக்க வேண்டும்‌.
அடிப்படையில்‌ தரப்பட்டியல்‌ (0)
Should have studied Chemistry &
Biological Sciences
மவதியியல்‌, உயிரியல்‌ கட்டாயம்‌
படித்திருக்க வேண்டும்‌.
(௦பழ-।!॥ தொகுப்பு-।!
Ranking based on marks in Part Ill |Should have studied Physics &
Electronic Science [out of 400 Mathematics
BES பகுதி Ill மொத்த மதிப்பெண்‌ 400-56 இயற்பியல்‌, கணிதம்‌ கட்டாயம்‌
பெறப்பட்ட மதிப்பெண்கள்‌ டித்திருக்க வேண்டும்‌.
அடிப்படையில்‌ தரப்பட்டியல்‌
4

<!-- page 7 -->

Group-lV தொகுப்பு-!/
(வியமைப்பியல்‌ Ranking based on marks in Part Ill 1 Should have studied Physics &
[Geology out of 400 Chemistry
பகுதி Ill மொத்த மதிப்பெண்‌ 400-க்கு | இயற்பியல்‌, “வேதியியல்‌ கட்டாயம்‌
பெறப்பட்ட மதிப்பெண்கள்‌ அடிப்படையில்‌ படித்திருக்க வேண்டும்‌.
தரப்பட்டியல்‌
10 |Geography Ranking based on marks in Part Ill [Preference should be given for 90% of
lseats subject concerned studied
lout of 400
பகுதி Il மொத்த மதிப்பெண்‌ 400-க்கு te a i seals for pale wno Sone
பெறப்பட்ட மதிப்பெண்கள்‌, அடிப்படையில்‌ Biucieg oiney science subjects and score
Ist” igucd 8 ல்‌
11 8) Computer Science (8/0 based on marks in Part III Should have studied Mathematics
8) Computer lout of 400 2/3 of seats reserved for students who
Application பகுதி Ill மொத்த மதிப்பெண்‌ 400-க்கு | have studied Computer science as a
௦) Information சறப்பட்ட மதிப்பெண்கள்‌ அடிப்படையில்‌ | 50066 in plus two and 1/3 of seats are
தரப்பட்டியல்‌
Technology for students who have not studied
computer science in plus two.
ID) Computer Should have studied Computer Science
Application Hearing
Impaired
12 |Home Science Ranking based on marks in 80% for students who have
Nutrition & Dietetics Part Ill out of 400 studied Chemistry with Biology or Home
பகுதி || மொத்த மதிப்பெண்‌ 400-க்கு | Science.
பெறப்பட்ட மதிப்பெண்கள்‌ அடிப்படையில்‌ | 20% for vocational stream students who
தரப்பட்டியல்‌
have studied Biology or Home Science.
13 |Microbiology Ranking based on marks in Part III For general stream only. 80% 10
out of 400 students who have studied (Botany and
பகுதி Ill மொத்த மதிப்பெண்‌ 400-க்கு | Zoology) or Microbiology subjects. 20%
பெறப்பட்ட மதிப்பெண்கள்‌ அடிப்படையில்‌ | reserved for Biology
தரப்பட்டியல்‌
students for Vocational stream only.
14 |B.A. Economic /History| Ranking based on marks in Part Ill
Political Sci tof 400 a) 80% for students who have
00027) Selence our studied concerned subject
பகுதி || மொத்த மதிப்பெண்‌ 400-க்கு b) 10% for students who have
பெறப்பட்ட மதிப்பெண்கள்‌ அடிப்படையில்‌. studied other subjects.
தரப்பட்டியல்‌ c) 10% for Vocational Stream
5

<!-- page 8 -->

15./B.A. Other than Ranking based on marks in வர ஐ) Preference should be given to
language ॥॥ out of 400 subject concerned studied
'குதி।॥மொத்தமதிப்பெண்‌ b) 20% reserved for vocational stream
100-க்கு பெறப்பட்ட
மதிப்பெண்கள்‌ அடிப்படையில்‌
தரப்பட்டியல்‌
16 |B.Com General & Ranking based on marks in Part III should have studied Commerce
IB.Com Corporate out of 400 and Accountancy in HSC
ISecretaryship பகுதி Ill மொத்த மதிப்பெண்‌ 400-86 | 20% reserved for commerce
பெறப்பட்ட மதிப்பெண்கள்‌ அடிப்படையில்‌
தரப்பட்டியல்‌' vocational stream
17 |BBM / BBA Ranking based on marks in Part |#) 80% for students who have studied
Commerce and Accountancy
III out of 400 b) 10 % for students who have studied
பகுதி ll மொத்த மதிப்பெண்‌ 400- other subjects and meritorious
க்கு பெறப்பட்ட மதிப்பெண்கள்‌ | c) 10 % for commerce vocational
அடிப்படையில்‌ தரப்பட்டியல்‌ stream.
For UG _ courses | Ranking based on marks in Part | Should have passed any group in
other than above | Ill out of 400 HSC.
mentioned courses. | பகுதி Ill மொத்த மதிப்பெண்‌ 400-|As per the norms of concerned
க்கு பெறப்பட்ட மதிப்பெண்கள்‌ | Universities.
அடிப்படையில்‌ தரப்பட்டியல்‌
des LATERAL ENTRY (UG COMMERCE DEGREE)
As per the orders issued in G.O.(Ms) No. 203 Higher Education (B1) Department
Dated: 26.10.2021, the students qualified with the Diploma in Commercial Practice /
Diploma in Modern Office Practice [ 10+3(SSLC and Diploma) / 10+2+2(SSLC,
HSC and Diploma )] are eligible for admission into lateral entry of all branches of
UG Commerce Degree Programmes including Corporate Secretaryship offered by
all State Universities in Tamil Nadu ( Government / Government Aided /
Autonomous / Self Financing Colleges) from the academic year 2022-23.
Hence, the above lateral entry students shall be admitted following the
guidelines mentioned below:-

i) An additional intake of 10% of seats should be created in the colleges for the
lateral entry admission to direct second year in the above courses exclusively
for the Diploma Students.

ii) The Students who have not studied Part-| Language should complete the
paper during the course of Degree programmes.

iii) The Lateral entry students are eligible for classification of Grade / Class for
award of UG Commerce Degree Programmes from the academic year
2022-23.

6

<!-- page 9 -->

18. All eligible applications should be ranked strictly according to the decreasing
order of total marks. In case, more than one candidate secures the same
marks, such candidates shall be ranked as follows:

a) The candidates who have passed the examination in the first attempt.
b) If both the candidates have passed in the first attempt ranking should be
done by the registration number.

19. As far as Arts subjects i.e. English / Tamil / Telugu and other languages are
concerned, the order of preference shall be as follows:

i) Candidates who have applied for the language and studied that language at
the plus two level under Part Ill, the ranking shall be based on marks in that
language.

ii) After exhausting all applications under category (i) applications of other
candidates may be ranked on the basis of the marks secured in Part | and
Part ॥ as the case may be.

20. Admission is subject to verification of marks certificate by the Director of
Government Examinations competent authority. If the mark certificate is found
to be bogus, admission will be cancelled and criminal action will also be taken.

21. The selection of candidates for admission into the various courses and
medium of instructions shall be made from out of the rank list strictly
according to the Government rules of reservation.

22. For Government/ Government Aided/ Self Financing Colleges, intimations of
provisional selection should be sent to the candidates through electronic
media by mail/SMS. The provisional selection list in respect of Govt. Colleges
should be displayed in the web portal www.tngasa.in and in respect of
Government / Aided/Self Financing Colleges the provisional selection list is to
be displayed in the respective college websites.

23. The Principal on the basis of the selection made by the Selection
Committee, shall make the admissions. The selection committee is
responsible for the entire admission. Hence, they should follow the
admission norms scrupulously.

However, the overall responsibility will rest with the Principal only.

In Government / Government Aided / Self Financing Colleges where degree
courses are taught through English and Tamil Medium, if seats in one medium
are filled up, candidates may be considered for the other medium provided all the
candidates who have applied for the particular medium have been considered for
admission.

24. For Supplementary candidates

With regard to supplementary candidates, eligible for admission, separate
notification will be put up in the web portal www.tngasa.in or by the respective
Government Colleges.

3 7

<!-- page 10 -->

25. Procedure for selection/admission under Open Competition Quota:

i. Only online applications alone will be considered for admission.

ii. Candidates are selected / admitted under Open Competition Quota on the
basis of merit from the Rank-List irrespective of the community to which a
candidate belongs. If any seat falls vacant in the open quota, after making
admission of candidates, such vacancies in open competition should
always be filled by merit only from the Rank-List irrespective of community
and irrespective of the fact that some of them have already been selected /
admitted under BC/BCM/MBC/DNC/SC/SCA/ST Quota. The procedure
implies that BC/MBC/DNC/SC/SCA/ST candidates already admitted
should not be left out of consideration for filling up the vacancies in the
open competition, if they are eligible to be selected under Open
Competition according to merit.

ii. | SC/SCA/ST/MBC/DNC/BC/BCM candidates selected under the open
quota as per merit from the Rank-List are not to be taken into account
against the reserved quota.

iv. The foreign students who are willing to pursue arts and science courses
shall be admitted under the open quota only, subject to eligibility norms of
the concerned university /Board.

v. Merit list should be updated on dynamic basis.

26. Procedure for selection / admission under reserved quota for SC/SCA/

ST/MBC/DNC/BC/BCM:

After filling up the vacancies in the open competition quota as aforesaid, the
vacancies SC/SCA/ST/MBC/DNC/BC/BCM quota must be filled by candidates
from the respective communities only according to merit from the Rank List.

27. Procedure for Differently Abled quota:
a) Out of the quota of 19% (15% SC, 3% SCA and 1% ST) reserved for SC/ST,

5 out of every 100 seats shall be reserved for Differently Abled persons

belonging to SC and ST.

b) Out of the quota for 50% (26.5% BC, 3.5% for BCM and 20% MBC) reserved
for Backward Classes, Most Backward Classes and Denotified Communities,

5 out of every 100 vacancies/seats shall be reserved for Differently Abled

persons belongs to BC, MBC and DNC.

c) Out of the quota of 31% intended for open competition 5 out of every 100

seats shall be reserved for Differently Abled in general.

28. Quota for Ex-servicemen / Tamil students of Andaman and Nicobar:

a) Six seats in Under Graduate courses shall be reserved for the children of Ex-

servicemen of Tamil Nadu Origin. (G.O.Ms.No.281, Hr.Edn.(D1),

dated 26-6-98)

8
