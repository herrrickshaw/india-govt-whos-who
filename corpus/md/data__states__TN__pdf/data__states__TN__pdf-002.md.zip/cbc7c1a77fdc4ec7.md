---
doc_id: "cbc7c1a77fdc4ec7"
source_url: "https://b-u.ac.in/sites/b-u.ac.in/files/Recruitment/2026/nov/dean/dean_cdc_notification.pdf"
ministry: "Bharathiar University, Coimbatore, Tamil Nadu"
title: "…                                         Nov    1               Applications are invited for the Post of PROGRAMME CO-ORDINATOR, NSS"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2bf2ebc2df297b9b"
---

<!-- page 1 -->

Notification No. B.U./Estt./E5/2026/D-CDC/16941

Date : 30.10.2026

RECRUITMENT NOTIFICATION
Applications are invited for the Post of

DEAN, COLLEGE DEVELOPMENT COUNCIL
------------------------------------------------------------------------------------QUALIFICATION : As prescribed by the Syndicate of Bharathiar University.
REVISED PAY

: Professor Scale of Pay

AGE

: Should have completed 52 years but not exceed 57 years on the date of
Notification of advertisement.

No. of Post : 1 Post.
------------------------------------------------------------------------------------Last date for receipt of the filled in application along with Registration fee
including Application fee of Rs.600/- for General category and Rs.300/- for OBC/SC/ST
is 30.11.2026.

REGISTRAR
