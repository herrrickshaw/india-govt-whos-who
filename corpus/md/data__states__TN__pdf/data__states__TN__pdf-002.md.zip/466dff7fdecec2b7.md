---
doc_id: "466dff7fdecec2b7"
source_url: "https://www.dge.tn.gov.in/docs/go_list/DYSLEXIA/G.O-Ms.No.54.pdf"
ministry: "Directorate of Government Examinations, Tamil Nadu"
title: "Framing of guideline for Scribe Appointment"
date: ""
pages: 3
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "9cd92936820fc370"
---

<!-- page 1 -->

ன்‌ த ஆதல்‌ aa
ar ஆ கபில
z Ve ஜில்‌,
Vat via ) “நீ ea
| 2 A ‘ e .. NN, =, a
N Son 5 SS ABSTRACT
School Educat = le of Government Examinations, Chennai — Higher
Secondary 78500 Ic. Examinations: Framing of guidelines. to be adopted for me
. «= Scribe appointment as per the directions of the Hon’bie High Court of Madras—
Orders Issued. - _ _
School Education GE(1) Department ~ -
6.0. (Ms) No.54 Dated: 29.02.2016.
திருவள்ளுவர்‌ ஆண்டு, 2047
மன்மத வருடம்‌, மாசி,17
Read:-
1. G.O(Ms)No.28,Schoo! Education (V1 } Department, dated 10.2.2010.

2. G.O(Ms)No.268, School Eduéation (91) Department, dated 19.1 0.2012.

3. From the Director of Government Examinations, letter No.023396/H2s 2016,
dated 26.02.2016, .
: ORDER:-

In the Government Orders first and second read above orders were issued to
permit concessions to the 6 Categories of differently abled candidates, who appear
for SSLC/Higher Secondary Public Examinations oA requisition and also
appointment of Scribes to assist differently. abled candidates for writing public
examinations are usually made by the Director of Government Exarainations based
on the recommendations. of Chief Educational Officers andi District Educational
Officers. ்‌

2. in the letter third read above, the Director of Government Examinations
has requested to frame guidelines to be adopted for appointment of Scribes as per
the directions of Hon'ble High Court of Madras in W.P.. No.5383/2015 dated
28.01.2016 and the recommendations made by the State Commissioner for the
Differently Abled.

3. The Government after careful examination of the proposal of the Director of
Government Examinations accept it and issue the following guidelines to adopt while
appointing the Scribes in the Government Public Examinations. (SSLC/HSC)

1) A Scribe should fulfill the role of a reader, scribe and / or prompter
॥) Prior to the examination, the co-ordinator should provide an opportunity for the
candidate and the corresponding scribe to practice working together.

<!-- page 2 -->

Il) The candidate must take the examination in a Separate room. The dictated
response of the candidate must not be overheard by other candidates.
14) Because the examination 15 taken in a separate room, an invigilator must be
present in addition to the scribe. This is to ensure the Proper canduct of the டட
vs... -@Xamination, - no questions arise regarding the appropriateness of the
assistance.
V) The Scribe Must:- ர ரர 7
a) Transcribe the candidate's responses verbatim.
b) Draw all visual material (for example, diagrams, maps and graphs}
according te the exact instructions of the candidate.
9) Should not offer information. that may be used to answer questions,
Including advice on, () whieh questions to answer, (i) when ta move on to
another question or, (ili) order in whieh questions should be answered.
Vi) The Scribe may:-
a) Read back answers at the Fequest of the candidate.
இ) After or delete answers at the request of the candidate,
Vil) A candidate’s answer to a multiple choice paper may be recorded in a form that
is Most convenient to the candida’ didaté and scribe. “However. the candidate's answers
must be submitted for marking on a multiple ehéice answer Sheet, tegardless of haw
they are initially recorded,
(Instead, the Director of Government Examinations ean appoint Supervisors to wately
the scribes activities in the ratio 1:1:1 (1 Candidate:1 Scribe-1 Supervisor) in case of
்‌ blind candidates).
Vill) The scribe must be. familiar with the terminology used the subject but, whenever
Possible, should not be Candidate’s: own téacher for the subject being exainined, .
| :
09 Conversation between the candidates and the scribe must be confined to’ ensure
that the candidate’s responses are transcribed correctly. There must be ne
discussion about the examihation paper or the. Candidate's answer,
X) The scribe must not act aS 8 prompt, unless there Has been @ prior decision by
the school to use. a Prompter as ar assessment arrangement for the candidate.
In such circumstances, the Scribe must be made aware of the rules governing
the use of Prompter.
Xl) A prior interaction between the scribe and Student could be arranged officially at
least a day before the examination.
201) Scribes in some Cases do not understand the accent of the Visually impaired
student. Hence respective scribes and Visually impaired students must be allowed to
practice working together to remove any communication obstacles.
200) In all other situations, if time elapses during the examination when the Candidate ;
is not responding to the examiriation paper, no action should be taken by the scribe, ்‌
unless the candidate is ill or distressed and then the invigilator should be notified, ்‌

<!-- page 3 -->

பெ பயிப்விமல்‌ fiat can be impiemenied b Directorate of Sehoo!
. AS ie டம பய] of #ducational Research and Training:-
ர்‌ A Pool of scribes should be created separately for the School
. Education Department.
2. However, while appointing scribes, depending upon the candidate’s
choice of subject, instead of appointing subject experts, qualified
coc as eo ட scribes for a pool of interdependent subjects may be appointed. ~
3. 1181280875 appointed as a scribe, let there be fixation of qualification
ரா for such teacher along with adequate training, sfilt assessment by the
state.
4. The main subjects and allied subjects be grouped and sorted so that
scribes can be picked from the poof of scribes classified subject wise
(For example, a Chemistry teacher can be a scribe for a Maths
examination but not otherwise)
5. Legibility of hand writing may be tested by way of tests during training
phase of scribes, in order to avoid scribes who are having illegible
handwriting as it downgrades the system drastically.
6. Physical Fitness of a scribe is of Paramount importance, Steps are to
be taken to ensure only physically fit scribes, with no disability marring
their eyesight, hearing ability and writing ability should be appointed
and trained.
ர்‌. Immediate steps should be taken for creating 8 pool of scribes. and to
give training before end of this month, i.e. February 2016.
. 5. The Director of School Education, Director of State Council of
Educational Research and Training and all the Chief Educational Officérs/District
Educational Officers are requested to follow the above recommendations while
appointing the scribes. .
(By Order of the Governor)
D.Sabitha,
Principal Secretary to Government
To
The Director of Government Examination,
Chennai-6
The Director of School Education, Chennai-6
The Director of Elementary Education, Chennai-6
The Director of Matriculation, Chennai-6
The Director of State Council of Educational Research and Training, Chennai-6
Copy to
The State Commissioner for the Differently Abled, Chennai-78,
Forwarded by Order//
a on
Under Secretary to Government. ம்‌
“ட ஸ்டம்‌ sy Ak augneryak hank
ரிஷ்‌ oy Op MDA KG Uy Ane Manag a பதக்க கபட
ட . 9 கன்டம்‌ மனி்கும்‌ ac Cue மே - Nar:
Ptepled 6k y- aie
Gas - படம
{hey 39 (fro.
Wins Csitem Bwdte. :
