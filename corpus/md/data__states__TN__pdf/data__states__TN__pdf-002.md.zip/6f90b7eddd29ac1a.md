---
doc_id: "6f90b7eddd29ac1a"
source_url: "https://b-u.ac.in/sites/b-u.ac.in/files/Recruitment/2026/nov/nss/nss_notification.pdf"
ministry: "Bharathiar University, Coimbatore, Tamil Nadu"
title: "Notification…                                         Nov    1               Applications are invited for the Post of Public Relations Officer"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6248aa09c65a60f6"
---

<!-- page 1 -->

------------------------------------------------------------------------------------------------------------------------------Notification No. BU/Estt./E5/2026/NSS/16942

Date 30.10.2026

RECRUITMENT NOTIFICATION
Applications are invited for the Post of

PROGRAMME CO-ORDINATOR, NSS
---------------------------------------------------------------------------------QUALIFICATION : As prescribed by the NSS Manual/UGC, Government of India.
PAY

:

Associate Professor Scale of Pay.

AGE

: Not more than 50 years of age at the time of selection as
Programme Co-ordinator

No. of Post
: 1 Post.
---------------------------------------------------------------------------------Last date for receipt of the filled in application along with Registration fee
including Application fee of Rs.600/- for General category and Rs.300/- for OBC/SC/ST
is 30.11.2026.
REGISTRAR
