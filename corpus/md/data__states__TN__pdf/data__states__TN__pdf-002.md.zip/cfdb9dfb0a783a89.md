---
doc_id: "cfdb9dfb0a783a89"
source_url: "https://tcp.tn.gov.in/uat/storage/app/document/J6F3u1GYp86cq1XZJogTFqpzSCF1cdWDMLO3AIVQ.pdf"
ministry: "Directorate of Town and Country Planning, Tamil Nadu"
title: "Notification"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b2b973a1b58d7d47"
---

<!-- page 1 -->

DIRECTORATE OF TOWN AND COUNTRY PLANNING
2nd ,3rd and 4th floor C&E Market Road,
Koyambedu, Chennai 600107.
REQUEST FOR EXPRESSION OF INTEREST (REOI)
(Individual Selection)
The Directorate of Town and Country Planning (DTCP) is inviting applications from eligible
individuals/experts to express their interest in providing services for the Master Plan Unit (MPU)
of DTCP. The selected individual/expert will be responsible for coordinating, reviewing, and
monitoring the preparation of Master Plans.
Sl.No

Name of Position

1
2
3

Deputy Team Leader
GIS Expert
Senior Urban Planner

4
5
6

Post Graduate
Urban Planner

7
8
9

No. of Post
2
2
4

Associate Planner Grade-I

6

Associate Planner Grade-II

6

Assistant Planner Grade-I

6

Assistant Planner Grade-II

6

Junior Urban Planner
Graduate Urban
Planner
Technical Assistant
Total Vacancies

2
1
35

The detailed REOI and Terms of Reference is available in the website https://tcp.tn.gov.in/ Last date for submission of an Expression of Interest (EOI) on contract basis is 21.08.2025 at
5.00 pm. The EOI shall be sent to the Director of Town and Country Planning, DTCP, 2nd ,3rd and
4th floor C&E Market Road, Koyambedu, Chennai 600107, Tamil Nadu, India, by registered post or
by e-mail:dtcpprocurement@gmail.com.
Any further Corrigendum or Amendment shall be notified in this website only. Candidates
shall regularly visit the website to keep themselves updated.
(Sd/-) B. Ganesan
Director of Town and Country Planning
//Forwarded by order//
Joint Director,
Directorate of Town and Country Planning
