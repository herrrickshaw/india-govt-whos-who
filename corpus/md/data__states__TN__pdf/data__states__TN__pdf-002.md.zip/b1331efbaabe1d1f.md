---
doc_id: "b1331efbaabe1d1f"
source_url: "https://b-u.ac.in/sites/b-u.ac.in/files/Tenders/2026/10/2764-28.pdf"
ministry: "Bharathiar University, Coimbatore, Tamil Nadu"
title: "Download Tender Notification"
date: ""
pages: 1
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "726a10c8580795c6"
---

<!-- page 1 -->

AX ப ட ட ்‌
(fa) பாரதியார்‌ பல்கலைக்கழகம்‌
Se BHARATHIAR UNIVERSITY
COIMBATORE - 641 046, TAMILNADU, INDIA
State University ee Ranked 21* among Indian Universities by MoE-NIRF
e-TENDER NOTICE
E-Tender Notice No:C7/CRTD/Electronics/CMRG/2764/2026 Dt:28.10.2026
Online bids are invited through Tamil Nadu Government e-procurement portal website
www.tntenders.gov.in mm Tenders by Organization ச்ஷ்‌ Higher Education for the Purchase
“Electronic Consumable” for the Department of Electronics and Instrumentation,
Bharathiar University, Coimbatore.
The Tender documents can be downloaded from 28.10.2026. Bid submission will
be started on 28.10.2026 @ 4.00pm and will be closed on 12.11.2026 @3.00pm.
ட REG TRAR
Copy to:
1. The Head of the Department, Dept of Electronic and Instrumentation, BU.
2. The Finance Officer, BU.
3. Dr.J.Vijayakumar, Associate Professor & PI, CMRG, Dept of Electronics and
Instrumentation,
4. The In-charge, Centre for Internet and Website Services, BU — with a request to host
the above in the University website.
