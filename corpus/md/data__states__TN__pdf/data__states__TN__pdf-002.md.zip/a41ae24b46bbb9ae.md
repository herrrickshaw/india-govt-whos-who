---
doc_id: "a41ae24b46bbb9ae"
source_url: "https://www.motherteresawomenuniv.ac.in/images/notifications/files/02:22:22pmForm.pdf"
ministry: "Mother Teresa Women's University, Kodaikanal, Tamil Nadu"
title: "Mphil Arrear Examination Form"
date: ""
pages: 4
method: "tesseract:tam+eng"
script: "TAMIL"
needs_ocr: false
sha1: "79aaa07631f8800c"
---

<!-- page 1 -->

“ஆ. Mother Teresa Women's University
KODAIKANAL - 624 101. ட்‌
3
WY) அன்னை ஒதரசா மகளிர்‌ பல்கலைக்கழகம்‌
SS கொடைக்கானல்‌ - 624 101.
FORM OF APPLICATION FOR M.PHIL DEGREE EXAMINATION
Obuaiwied பட்டத்‌ தேர்விற்குரிய விண்ணப்பப்‌ படிவம்‌
UNIVERSITY DEPARTMENTS & AFFILIATED COLLEGES (PART TIME / FULL TIME)
; பல்கலைக்‌ கழகத்‌ துறைகள்‌ மற்றும்‌ இணைப்புக்‌ கல்லூரிகள்‌ (பகுதி நேரம / முழு நேரம)
Tobe filled in by the office Reg. “a E யர்‌
a ed in by the can ‘ Signature of the |
வன Candidate |
itt Gai மாணவரது கைஓயாபபம |
5 4 aa Space for photograph |
பல்‌. ய்‌ Attesting Officer ]
இ
ல வலை டைவ இ
த சர Name of the Mother / prs இ os
| 6. _Name and Occupation of Father or Guar இ.
7. Address to which all communications are to be sent :
8. Phone No. தொலைபேசி எண்‌. a ம்‌.
9. The year in which the candidate was _ இ
Registered for M.Phil Degree ஆ oa
10. selected for E
the NPI Dares Exerination வவ a |

<!-- page 2 -->

——— குளு] பா்‌
42. Whether your Supervisor has been recognized: Yes / No
by the University (Proof Needed) ae
13. Paper(s) for which the candidate is now appearing :
'&ப்போது மாணவர்‌ எழுதவிருக்கும்‌ பாடத்தாள்களின்‌ விபரம்‌:
Part - | - Written Examination Part - |! (To be Written in Block Letters)
பகுதி - | - எழுத்துத்‌ தேர்வு பகுதி - || (பெரிய எழுத்தில்‌ தெளிவாக எழுதுக.)
Paper -| Area Paper :
தாள்‌ - | பகுதித்தாள்‌ :
Paper - II
தாள்‌ - | Title of the Dissertation:
Paper - Ill
தாள்‌ - II
14. Incase of part - time students, details about the previous examination attended must be
given below :
இதற்கு முன்னதாகவே இித்தேர்வுகளை எழுதியிருக்கும்‌ மாணவராயின்‌ அவரால்‌ இந்தப்‌ பகுதி கட்டாயம்‌ பூர்த்தி
ட்டுக்‌
Mark Results (State Whether
| Subjects Centre Reg. No. | Secured Passed or Failed)
பப்ப டங்‌ ள்‌ $ண்டு ்‌்‌। மையம்‌. பதிவு எண்‌ பெற்ற. தேர்வு முடிவு (தேர்ச்சி பெற்றாரா?
ததவ டன... மதிப்பெண்‌ | பெறவில்லையா? என்று குறிப்பிடுக)
கத
ர்‌
— ன — “7
re of the candidate
ss Is |

<!-- page 3 -->

aN {To be filled in by the Office only |
EY) Matin: Gerd வது
21 020282 Momen's University
மன 7 KODAIKANAL - 624 102.
3

<!-- page 4 -->

7
%
INSTRUCTIONS TO CANDIDATES
ரி Tees
NOTE: 1. Rs. 500/- will be charged fornot bringing the Hall Ticket to the Examination Hall.
25 As soon as candidates have finished writing their answers and wish to give the answer
books or at the end of the period prescribed for the particular examination, each student
should stand up and remain standing until one of the Superintendents come to the
candidate and receive the answer book from the candidate.
3. A copy of the instructions to candidates is enclosed.
4. Candidates must satisfy the Chief Superintendent as to th eir identity. The certificate of
Identity taken by them must contain their signatures. பத்த oe ec
pe.
4
