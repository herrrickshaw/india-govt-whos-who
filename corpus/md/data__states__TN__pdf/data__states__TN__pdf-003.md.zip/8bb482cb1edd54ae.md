---
doc_id: "8bb482cb1edd54ae"
source_url: "https://tnpcb.gov.in/PDF/Updates/Tenders/RFQShoppingproced9326.pdf"
ministry: "Tamil Nadu Pollution Control Board (TNPCB), Tamil Nadu"
title: "RFQ for Procurement of Non-consultancy service for 'Collection, Removal and Transportation of floating debris/solid waste from the Floating Trash Boom installed in the Adyar River in Chennai district, Tamil Nadu'.  More"
date: ""
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9588afd17190530b"
---

<!-- page 1 -->

W-5

PROCUREMENT OF
NON CONSULTANCY SERVICE
THROUGH
REQUEST FOR QUOTATION
(RFQ)/SHOPPING PROCEDURES
(Lump sum and percentage rate tender)
(Two-Envelope with e-Procurement)
(For Contracts valued less than the equivalent of US $ 100,000 each)

March 2026

<!-- page 2 -->

REQUEST FOR QUOTATIONS
Procurement of Non Consultancy Service under RFQ/Shopping Procedures
E-Procurement Notice
(Two-Envelope with e-Procurement Bidding Process)
Project: Tamil Nadu Sustainably Harnessing Ocean Resources and Blue Economy
(TNSHORE)
Contract title: Collection, Removal and Transportation of floating debris/solid
waste from the Floating Trash Boom Barrier installed in the Adyar River in Chennai,
Tamil Nadu.
RFQ No: IN-TNPCB-539520-NC-RFQ
Date: 03.03.2026
Applicable Procurement Guidelines/Regulations Date: September 2025
1.

Government of India has received/has applied for/intends to apply for financing from
the World Bank towards Tamil Nadu Sustainably Harnessing Ocean Resources and
Blue Economy (TNSHORE) Project and intends to apply part of the proceeds of this
credit to eligible payments under the contract for which this request for quotations is
issued. The Tamil Nadu Pollution Control Board (TNPCB) invites quotations
electronically from eligible bidders for performing of the following Non-consultancy
service.
Brief Description of the Service

Period of Completion

Collection, Removal and Transportation of floating 01 Year
debris/solid waste from the Floating Trash Boom
Barrier installed in the Adyar River in Chennai,
Tamil Nadu.
2.

This e-Procurement notice includes the following documents1 to facilitate preparation
and submission of quotations, criteria for qualification, evaluation, and for award of
contract; and relevant forms to be filled by the bidders. Implementing Agency has not
issued a separate RFQ document for this purchase. The e-Procurement notice
including the various documents and forms to be filled etc. can be downloaded free of
cost by logging on to the website https://tntenders.gov.in . The bidders would be
required to register in the website which is free of cost.
i.
ii.
iii.
iv.
v.
vi.
vii.
viii.

Employer Requirement;
Other Details;
Detailed Bill of Quantities, with estimated rates and prices;
Specifications;
Instructions to Bidders;
Qualification Information;
Format for Submission of Quotation;
Criteria for Evaluation and Award of Contract;

<!-- page 3 -->

ix.
x.

Relevant Forms; and
Draft Contract Agreement format which will be used for finalizing the
agreement for this Contract.

3.

For submission of Quotation, the Bidder is required to have Digital Signature
Certificate (DSC) from one of the Certifying Authorities authorized by Government of
India for issuing DSC. Bidders can see the list of licensed CA’s from the link
(www.cca.gov.in). Bidders who have not obtained the user ID and password for
participating in e-procurement in this Project, may obtain the same from the website:
https://tntenders.gov.in and https://tnpcb.gov.in/

4.

Deleted

5.

Quotations, both Technical Part and Financial Part shall be submitted on
https://tntenders.gov.in on or before 15.00 hours on 20.03.2026. Any quotation or
modifications to quotation received outside e-procurement system will not be
considered. The electronic bidding system would not allow late submission of
quotations. The ‘Technical Part’ of the Quotations will be opened online on
20.03.2026 at 15.30 hours, this can also be viewed by the bidders online. The
electronic summary of quotation opening of technical part will be generated and
uploaded online.

6.

If the implementing agency’s office happens to be closed on the date of opening of the
Quotations as specified, the ‘Technical Part’ of the Quotations will be opened on the
next working day at the same time. The Financial Parts of the Quotations shall remain
unopened in the e-procurement system, until the subsequent online opening, following
the evaluation of the Technical Parts of the Quotations.

7.

Other details can be seen in the RFQ document. The implementing agency shall not be
held liable for any delays due to system failure beyond its control. A Bidder requiring
any clarification of the RFQ document may notify the Implementing agency online or
may visit the office of the implementing agency at the address given below.

Sd/-xxxx
Chairperson,
Tamil Nadu Pollution Control Board,
No.76, Mount Salai,
Guindy, Chennai – 600032
Tel No. 044-22353134-139
Email: pwmsec@tnpcb.gov.in

<!-- page 4 -->

Instructions to Bidders
SECTION - A
1.

Scope of Service
The Tamil Nadu Pollution Control Board invites quotations for the non-consultancy
service as detailed in the table given below
Brief Description
of the Service
Collection, Removal and Transportation of
floating debris/solid waste from the Floating
Trash Boom Barrier installed in the Adyar
River in Chennai, Tamil Nadu.

Period of Completion
01 year

The successful bidder will be expected to complete the service by the intended
completion date specified above.
2.

Qualification of the bidder

2.1.

Qualification Information to be provided by the Bidder: the bidder shall provide
information on his qualification which shall include:-

2.2.

(a)

Total monetary value of service performed by him for each year of the last 2
years;

(b)

List of non-con (similar to the service described in Para 1) completed
satisfactorily as a prime contractor during the last 2 years, enclosing
certificates from the respective Employers in support of experience claimed
along with the Employers’ contact numbers;

(c)

Report on his financial standing, along with last 2 years’ financial
statements/Profit and Loss Statements; and

(d)

Details of any litigation, during the last 2 years in which the bidder is involved,
the parties concerned, and disputed amount or award in each case(Give details
of both completed and pending cases).

Qualification Criteria: to qualify for award of the contract the bidder:(a)

Should have satisfactorily completed as a prime contractor at least one similar
service of value not less than Rs.24,00,000/- in the last three years;

(b)

Deleted

<!-- page 5 -->

(c)

Deleted

3.

Eligibility – Conflict of Interest: A Bidder shall not have conflict of interest as
defined in the Bank’s Procurement Regulations/ Guidelines and should not have been
(i) temporarily suspended or debarred by the World Bank Group in compliance with the
Bank’s Anti-Corruption Guidelines and its Sanctions Framework.

4.

Clarifications & Amendments: If the Employer receives any request for clarification
of this RFQ document, it will upload its response together with any amendment to this
document, on the e-procurement portal for information of all Bidders. Bidders should
check on the e-procurement system, for any amendments to this RFQ document.

5.

Quotation Prices
a) The quotation shall be for the whole service as described in the Bill of quantities,
drawings and technical specifications. Corrections, if any, in the quotation shall be
carried out by editing the information before electronic submission on eProcurement Portal.
b)

All duties, taxes and other levies payable by the contractor under the contract
shall be included in the total price.

c)

The rates quoted by the bidder shall be fixed for the duration of the contract
and shall not be subject to adjustment on any account.

d)

The rates should be quoted in Indian Rupees only.

6.

Preparation of Quotations

6.1

The bidder is advised to visit the location of service at his own expense and obtain all
information that may be necessary for preparing the quotation.

6.2

Each bidder shall submit only one quotation. Bidders shall not contact other Bidders
on matters relating to this quotation.

6.3

The quotation shall comprise two Parts, namely the Technical Part and the Financial
Part. Both Parts shall be submitted online simultaneously.

6.4

The Technical Part of Quotation shall comprise the following:
(a)
(b)
(c)
(d)

Letter of Quotation – Technical Part as per Format given in Section B;
Authorization: Power of Attorney of signatory of Quotation (Paragraph 1.1 of
Qualification Information);
Annual Turnover: Confirmation showing Annual Turnover in service
provided of similar nature in the last three financial years. [ITB Clause 2.1 (a)];
Qualifications:

<!-- page 6 -->

(i)

(e)

Qualification information and supporting documents relating to similar
nature of service performed and payments received. (ITB Clause 2.1 (b)
and paragraph 1.3 of Qualification Information);
(ii) Details of proposed sub-contractors; (Paragraph 1.4 of Qualification
Information); and
(iii) Other details listed in Paragraphs 1.6 and 1.7 of the Qualification
Information Form;
Complete address and contact details of the Bidder having the following
information:
Name of Firm
Address for communication
Telephone No(s): Office
Mobile No.
Facsimile (FAX) No.
Electronic Mail Identification (E-mail ID)

(f)

6.5

The Technical Part of Quotation shall not include any financial information
related to the Quotation price. Where material financial information related to
the Quotation price is contained in the Technical Part of Quotation, the
Quotation shall be declared non-responsive.

The Financial Part of Quotation shall comprise the following:
(a)
(b)

Letter of Quotation - Financial Part;
Priced Bill of Quantities: (using the BOQ uploaded with the RFQ document)
wherein the rates shall be entered online.

6.6

Signing of Quotations: The name and position held by each person signing the
quotation and related documents must be typed or printed below the signature.

6.7

Deadline for Submission of Quotations: Quotations must be uploaded online no later
than the deadline for submission of quotations viz. time 15.00 (hours) and date
20.03.2026 as per server time. A Bidder may modify its Quotation any number of
times by using the appropriate option on the e-Procurement Portal, before the deadline
for submission of Quotations.

6.8

Validity of Quotation: Quotation shall remain valid for a period not less than 45 days
after the deadline date specified for submission.

7.

Quotation Submission:
(a) The Letter of Quotation – Technical Part, and Letter of Quotation – Financial
Part shall be filled, signed and scanned copies shall be uploaded along with the
Priced Bill of Quantities that shall be entered using the Forms available online,
without any alterations. All blank spaces shall be filled in with the information
requested. Scanned copies of all other documents shall also be uploaded on the eprocurement website.

<!-- page 7 -->

(b)

8.

9.

All documents are required to be signed digitally by the Bidder. The System
generates a Unique QuotationIdentification Number, time stamped as per server
time, as an acknowledgement for Quotationsubmission.Detailed guidelines for
viewing and submission of Quotations online are given in the website.

Online Opening and Evaluation of Technical Parts of Quotations: The ‘Technical
Part’ of the Quotations will be opened online on the specified date and time. This can
also be viewed by the bidders online, and electronic summary of quotation opening of
technical part will be generated and uploaded online. The Financial Parts of the
Quotations shall remain unopened in the e-procurement system, until the subsequent
online opening, following the evaluation of the Technical Parts of the Quotations.
(a)

The Employer shall examine the technical part of the quotation to determine
whether the quotation (a) has been properly signed (Clause 6.6); (b) meets the
eligibility criteria (Clause 3); (c) is substantially responsive to the requirements of
the RFQ document; and (d) meets the qualification criteria specified in ITB
Clause 2.

(b)

Only Quotations that are both substantially responsive to the RFQ document, and
meet all Qualification Criteria shall qualify for opening of the Financial Parts of
their Quotations at the second online opening.

(c)

Employer shall notify in writing those Bidders who have failed to meet the
Qualification Criteria or whose Quotations were considered non-responsive to the
requirements in the RFQ document, advising them that their Technical Part of
Quotation failed to meet the requirements of the RFQ document; and that their
Financial Part of the Quotation shall not be opened.

(d)

Simultaneously Employer shall notify in writing those Bidders whose Technical
Parts of Quotations have been evaluated as substantially responsive and meeting
the Qualification Criteria that their Quotation has been evaluated as substantially
responsive to the RFQ document and that their Financial Part of Quotation will be
opened online at 15.30 hours on 20.03.2026.

Online Opening and Evaluation of Financial Parts of Quotations: The ‘Financial
Part’ of the Quotations will be opened online on the specified date and time. This can
also be viewed by the bidders online, and electronic summary of quotation opening of
financial part will be generated and uploaded online.
(a)

The Employer shall examine and confirm that Letter of Quotation – Financial Part
and Priced Bill of Quantities are in accordance with the requirements specified in
the RFQ document. If any of these documents or information is missing, the offer
shall be rejected.

(b)

During the evaluation of Financial Parts of Quotation, the substantial
responsiveness of the Quotations will be further determined with respect to those

<!-- page 8 -->

RFQ conditions that were not examined in evaluation of Technical Parts of
Quotations.
10.

Award of contract
The Employer will award the contract to the bidder whose quotation has been
determined to be substantially responsive and who has offered the lowest evaluated
quotation price and who meets the specified qualification criteria.

10.1

Notwithstanding the above, the Employer reserves the right to accept or reject any
quotations and to cancel the bidding process and reject all quotations at any time prior
to the award of contract.

10.2

The bidder whose quotation is accepted will be notified of the award of contract by the
Employer prior to expiration of the quotation validity period.

11.

Performance Security
Within 15 days of receiving letter of acceptance, the successful bidder shall deliver to
the Chairperson, Tamil Nadu Pollution Control Board (TNPCB) the performance
security (either a bank guarantee or a bank draft in favour of the Employer) for an
amount equivalent of 3 % of the contract price. The Performance Security shall be
valid till the expiry of the period of maintenance of the service, specified in Clause
12.Failure of the successful Bidder to furnish performance security and to sign the
agreement within the period stipulated shall constitute sufficient grounds for
annulment of award and debarring the bidder from participation in bidding for service
by the Employer for a period of one year, in which case the Employer may make the
award to the next lowest evaluated bidder or seek quotations afresh.

12.

Period of Maintenance:
The “Period of Maintenance” for the service is twelve months from the date of
taking over possession or one full monsoon season whichever occurs later.
During the period of maintenance, the contractor will be responsible for
rectifying any defects in service free of cost to the Employer.

13.

Supply of all required materials including cement and steel as per the specifications
(ISI certification marked goods wherever available) shall be the responsibility of the
contractor. Tamil Nadu Pollution Control Board (TNPCB) will not issue any
material/equipment.
.......................

<!-- page 9 -->

SECTION - B
1.

Format for Qualification Information.

2.

Format for Submission of Quotation.

3.

Format of Letter of Acceptance.

<!-- page 10 -->

QUALIFICATION INFORMATION
1

For Individual Bidders

1.1

Principal place of business:

______________________________

Power of attorney of signatory of Quotation.
[Attach copy]
1.2

Total value of Non-consulting
20___
____________________
service performed in the last 20___
____________________
three years (in Rs. Lakhs)
20___
____________________

1.3

Service provided as prime contractor/consultant (in the same name) on service of a
similar nature over the last three years.

Project
Name

Name of
Employer

Description of
service

Contract
No.

Value of
contract
(Rs.Lakhs)

Date of
issue of
work
order

Stipulated
period of
completion

Actual
date of
compl
etion*

Remarks
explaining
reasons
for delay
and
assignmen
t
completed

Existing commitments and on-going services:
Description
of Service

Place &
State

Contract No.
& Date

(1)

(2)

(3)

Value of
Contract
(Rs.
Lakhs)
(4)

Stipulated
period of
completion
(5)

Value of service*
remaining to be
completed
(Rs. Lakhs)
(6)

Anticipated
date of
completion
(7)

*
Enclose a certificate from the Engineer concerned for completion as well as value of
pending services.

<!-- page 11 -->

1.4

Proposed subcontracts and firms involved.
Sections of the
Service

Value of Subcontract

Sub-contractor
(name & address)

Experience in
similar work

*

*
*
*
*
*
*

*
*
*
*
*
*

*

*
*

*
*

1.5

Evidence of access to financial resources to meet the requirements of working capital:
cash in hand, lines of credit, etc. List them below and attach copies of support
documents.

1.6

Name, address, and telephone, telex, and fax numbers of the Bidders’ bankers who
may provide references if contacted by the Employer.

1.7

Information on litigation history in which the Bidder is involved.
Name of Agreement Name & Contract
Cause of Amount
the work number/date address of Value in dispute
Disputed
Employer Rs

Remarks
showing
present
status

<!-- page 12 -->

Letter of Quotation–Technical Part
The Bidder must prepare the Letter of Quotation on stationery with its letterhead clearly showing the Bidder’s
complete name and address. The italicized text is for Bidder’s guidance in preparing these forms and shall be
deleted from the final products.

Description of the Non-Consulting service*: ………………………………………
RFQ No.: ……………………..[insert identification]
Our Reference: No.............................. Dated..........................
To:(Employer’s name and address)
Subject

: ....................................................................
.............................................................................................

Reference

: Letter No....................................dated......................from...................

Sir,
1. We, the undersigned, hereby submit our Quotation in two parts, namely:
(a) Technical Part; and
(b) Financial Part
2. In submitting our Quotation, we make the following declarations:
(a)

No reservations: We have examined and have no reservations to the RFQ document;

(b)

Conformity: We offer to perform the subject service in conformity with the RFQ
document and in accordance with the Period of Completion specified in Section A.;

(c)

Quotation Validity Period: Our Quotation shall be valid for the period of 45 days,
from the deadline fixed for the Quotation submission;

(d)

Eligibility: We meet the eligibility requirements and have no conflict of interest, we are
not participating in more than one quotation in this bidding process, and we have not
been temporarily suspended or debarred by the World Bank.

(e) Fraud and Corruption: We hereby certify that we have taken steps to ensure that no
person acting for us or on our behalf will engage in any type of corrupt, fraudulent,
collusive, coercive, or obstructive practices.
(f) ESHS/GBV Compliance: We hereby undertake to comply with (i) the applicable Laws/
Rules/ Regulations for protection of environment, public health and safety; (ii) the
regulatory authority conditions (if any) attached to any permits or approvals for the
project; and (iii) the Management Strategies and Implementation Plan (MSIP) to manage
the Environmental, Social (including sexual exploitation and abuse (SEA) and gender

<!-- page 13 -->

based violence (GBV)), Health and Safety (ESHS) risks, and ESHS Code of Conduct, (if
any prescribed by the Employer ), that will apply to us, our employees and all
subcontractors.
Yours faithfully,
Authorized Signature

:

Date: ______________

Name & Title of Signatory : _____________________________________________
In the capacity of [insert legal capacity of person signing the Letter of Quotation]
Name of Bidder
: _____________________________________________
Address
: _____________________________________________
Dated on ____________ day of __________________, _______ [insert date of signing]
*
**

To be filled in by the Employer before issue of the Letter of Invitation.
To be filled in by the Bidder, together with his particulars and date of submission at
the bottom of this Form.

<!-- page 14 -->

Letter of Quotation–Financial Part
The Bidder must prepare the Letter of Quotation on stationery with its letterhead clearly showing the Bidder’s
complete name and address. The italicized text is for Bidder’s guidance in preparing these forms and shall be
deleted from the final products.

Description of the Non-Consulting Service*: ………………………………………
RFQ No.: …………………… [insert identification]
Our Reference: No.............................. Dated..........................
To:
(Employer’s name and address)
Subject:...................................................................................................
Sir,
1.

We, the undersigned, hereby submit the second part of our Quotation, the Financial Part
including the Quotation Price and Bill of Quantities. In submitting our Financial Part we
make the following additional declarations:

(a) Validity: Our Quotation shall be valid for the period of 45 days from the deadline fixed
for the Quotation submission;
(b) Quotation Price: The total price of our Quotation including any unconditional discounts,
offered in accordance with the Conditions of Contract is at ......... percentage above /
below the estimated rates, i.e., for a total Contract Price of –
Rs.** _________________________________________________ [in figures]
Rs. _________________________________________________ [in words];
(c) Commissions, gratuities and fees: We have paid, or will pay the following
commissions, gratuities, or fees with respect to the Bidding process or execution of the
Contract: [insert complete name of each Recipient, its full address, the reason for which
each commission or gratuity was paid and the amount and currency of each such
commission or gratuity. If none has been paid or is to be paid, indicate “none.”]
Yours faithfully,
Authorized Signature
Name & Title of Signatory _____________________________________________
In the capacity of [insert legal capacity of person signing the Letter of Quotation]

<!-- page 15 -->

Name of Bidder _____________________________________________
Address _____________________________________________
Dated on ____________ day of __________________, _______ [insert date of signing]

To be filled in by the Employer before issue of the Letter of Invitation.
**
To be filled in by the Bidder, together with his particulars and date of submission at
the bottom of this Form.

<!-- page 16 -->

LETTER OF ACCEPTANCE
CUM NOTICE TO PROCEED WITH THE NON CONSULTING SERVICE
(LETTERHEAD OF THE EMPLOYER)
Dated: ____________________________
To:

_________________________________ [Name and address of the Contractor]
_________________________________
_________________________________
_________________________________
_________________________________

Dear Sirs,
This is to notify you that your quotation dated ____________________ for execution
of the _____________________________________________________________ for the
contract price of Rupees __________________________________________ [amount in
words and figures], is hereby accepted by us.
You are hereby requested to furnish performance security for an amount of Rs.
____________________ (equivalent to 3% of the contract price) within 15 days of the receipt
of the letter. The Performance Security in the form of Bank guarantee or a Bank draft in
favour of.......................... (Employer) shall be valid till the expiry of the period of
maintenance i.e. upto ______________________. Failure to furnish the Performance
Security will entail cancellation of the award of contract.
You are also requested to sign the agreement form and proceed with the work not later
than ____________________________ under the instructions of the Engineer,
____________________________ and ensure its completion within the contract period.
With the issuance of this acceptance letter and your furnishing the required
Performance Security, the contract, for the above said work, stands concluded.
Yours faithfully,

Authorized Signature
Name and title of Signatory of Employer

0

<!-- page 17 -->

Draft Contract Agreement form for
Non-Consulting Service through National Shopping
ARTICLES OF CONTRACT AGREEMENT
1.
This deed of agreement is made in the form of agreement on ________ day
_______________
month
____________
20___,
between
the
_____________________________ (Employer) or his authorized representative (hereinafter
referred to as the first party) and _____________________ (Name of the Contractor), S/O
_______________ resident of ______________ (hereinafter referred to as the second party),
to perform the non consulting service __________________________ (hereinafter referred to
as Non Consulting Service) on the following terms and conditions.
2.

Contract Price

The total Contract Price for the service (hereinafter referred to as the “total price”) is
Rs. ____ as reflected in Annexure - 1.
3.1

Payments under its contract:

Payments to the second party for the service will be released by the first party in the
following manner:-

On signing of agreement

:

10% of total cost, as interest free
advance against receipt of an
unconditional bank guarantee from
the Contractor for an equivalent
amount valid up to the Intended
Completion Date, in the format
attached.

First Quarter (03 months)

:

25% of the total cost

Second Quarter (06 months)

:

25% of the total cost

Third Quarter (09 months)

:

20% of the total cost

Fourth Quarter (12 months)

:

20% of the total cost

On Completion of

3.2

Payments at each stage will be made by the first party:

1

<!-- page 18 -->

4.

(a)

on the second party submitting an invoice for an equivalent amount;

(b)

on certification of the invoice (except for the first installment) by the engineer
nominated by the first party with respect to quality/quantity of service
performed in the format in Annexure - 2; and

(c)

upon proper and justified utilization of at least 50 % of the previous installment
and 100 % of any prior installment.

(d)

Payments shall be adjusted for deductions for advance payments, recoveries if
any in terms of the contract, and taxes at source, as applicable under the law.

(e)

The advance (if availed by the contractor) shall be repaid with percentage
deductions from the interim payments, commencing with the next Interim
Payment at the rate of 20 percent of the amounts of all Interim Payment
Certificates until the advance has been repaid, provided that the advance shall
be completely repaid prior to the expiry of the Intended Completion Date. The
Bank Guarantee shall remain effective until the advance payment has been
fully repaid.

Notice by Contractor to Engineer
The second party, on the service reaching each stage of milestone, issue a notice to the
first party or the Engineer nominated by the first party (who is responsible for
supervising the contractor, administering the contract, certifying the payments due to
the contractor, issuing and valuing variations to the contract, awarding extensions of
time etc.), to visit the site for certification of stage completion. Within 15 days of the
receipt of such notice, the first party or the engineer nominated by it, will ensure issue
of stage completion certificate after due verification.

5.

Completion time
The service should be completed in 01 Year (12 months) from the date of this
Agreement. In exceptional circumstances, the time period stated in this clause may be
extended in writing by mutual consent of both the parties.

6.

If any of the compensation events mentioned below would prevent the work being
completed by the intended completion date, the first party will decide on the intended
completion date being extended by a suitable period:
a)

The first party does not give access to the site or a part thereof by the agreed
period.

b)

The first party orders a delay or does not issue completed drawings,
specifications or instructions for execution of the work on time.

2

<!-- page 19 -->

7.

c)

Ground conditions are substantially more adverse than could reasonably have
been assumed before issue of letter of acceptance and from information
provided to second party or from visual inspection of the site.

d)

Payments due to the second party are delayed without reason.

e)

Certification for stage completion of the work is delayed unreasonably.

Any willful delay on the part of the second party in completing the service within the
stipulated period will render him liable to pay liquidated damages @ Rs. 3000/- per
day will be deducted from payments due to him. The first party may cancel the
contract and take recourse to such other action as deemed appropriate once the total
amount of liquidated damages exceeds 3 % of the contract amount.
(Note: The amount of liquidated damages per day should be determined between 0.05
to 0.1% of the contract value of the service per day and indicated here).

8.

Duties and responsibilities of the first party

8.1

The first party shall be responsible for providing regular and frequent supervision and
guidance to the second party for carrying out the service as per
specifications/Employer requirements. This will include written guidelines and regular
site visit of the authorized personnel of the first party, for checking quality of service
to ensure that it is as per the norms.

8.2

Deleted

8.3

Possession of the site will be handed over to the second party within 10 days of
signing of the agreement.

8.4

The Engineer or such other person as may be authorized by the first party shall hold
meeting once in a month where the second party or his representative at site will
submit the latest information including progress report and difficulties if any, in the
performance of the service. The whole team may jointly inspect the site on a particular
day to take stock of activities.

8.5

The Engineer shall record his observations/instructions at the time of his site visit in a
site register maintained by the second party. The second party will carry out the
instructions and promptly rectify any deviations pointed out by the engineer. If the
deviations are not rectified, within the time specified in the Engineer’s notice, the first
party as well as the engineer nominated by it, may instruct stoppage or suspension of
the service. It shall thereupon be open to the first party or the engineer to have the
deviations rectified at the cost of the second party.

9.

Duties and responsibilities of the second party

3

<!-- page 20 -->

9.1

10.

The second party shall:
a)

take up the works and arrange for its completion within the time period
stipulated in Clause 5;

b)

employ suitable skilled persons to carry out the services;

c)

regularly supervise and monitor the progress of service;

d)

abide by the technical suggestions/direction of supervisory personnel including
engineers etc. regarding this service;

e)

be responsible for bringing any discrepancy to the notice of the representative
of the first party and seek necessary clarification:

f)

ensure that the service is carried out in accordance with specifications,
drawings and within the total of the contract amount without any cost
escalation;

g)

keep the first party informed about the progress of service;

h)

be responsible for all security and watch and ward arrangements at site till
handing over of the building to the first party; and

i)

maintain necessary insurance against loss of materials/cash, etc. or workman
disability compensation claims of the personnel deployed on the services as
well as third party claims.

j)

Pay all duties, taxes and other levies payable by consultant/agency as per law
under the contract (First party will effect deduction (TDS) from running bills in
respect of such taxes as may be imposed under the law).

Variations / Extra Items
The services shall be carried out by the second party in accordance with the approved
drawings and specifications. However, if, on account of site conditions or any other
factors, variations are considered necessary, the following procedure shall be
followed:a)

The second party shall provide the Engineer with a quotation for carrying out
the Variation when requested to do so by the Engineer. The Engineer shall
assess the quotation, which shall be given within seven days of the request
before the Variation is ordered.

b)

If the quotation given by the second party is unreasonable, the Engineer may
order the Variation and make a change to the Contract Price which shall be

4

<!-- page 21 -->

based on Engineer’s own forecast of the effects of the Variation on the
Contractor’s costs.
c)
11.

The second party shall not be entitled to additional payment for costs which
could have been avoided by giving early warning.

Securities
The Performance Security (Bank Guarantee from a Nationalized or Scheduled Bank in
India in the format attached) shall be provided to the Employer no later than the date
specified in the Letter of Acceptance and shall be issued in an amount and form and by
a bank or surety acceptable to the Employer. The Performance Security shall be valid
until a date 28 days from the date of issue of the Certificate of Completion in the case
of a Bank Guarantee.

12.

Termination

12.1

The Employer may terminate the Contract if the other party causes a fundamental
breach of the Contract.

12.2

Fundamental breaches of Contract include, but shall not be limited to the following:
(a)

the contractor stops service for 28 days and the stoppage has not been
authorized by the Engineer;

(b)

the Contractor has become bankrupt or goes into liquidation other than for a
reconstruction or amalgamation;

(c)

the Engineer gives Notice that failure to correct a particular Defect is a
fundamental breach of Contract and the Contractor fails to correct it within a
reasonable period of time determined by the Engineer;

(d)

the Contractor does not maintain a security which is required;

(e)

the Contractor has delayed the completion of the Services by the number of
days for which the maximum amount of liquidated damages can be paid, as
defined in the Clause 7 of this agreement

12.3

Notwithstanding the above, the Employer may terminate the Contract for convenience.

12.4

If the Contract is terminated the Contractor shall stop service immediately, make the
Site safe and secure, and leave the Site as soon as reasonably possible.

13.

Payment upon Termination

13.1

If the Contract is terminated because of a fundamental breach of Contract by the
Contractor, the Engineer shall issue a certificate for the value of the service done less
advance payments received up to the date of the issue of the certificate, less other

5

<!-- page 22 -->

recoveries due in terms of the contract, less taxes due to be deducted at source as per
applicable law.
13.2

If the Contract is terminated at the Employer’s convenience, the Engineer shall issue a
certificate for the value of the service done, the reasonable cost of removal of
Equipment, repatriation of the Contractor’s personnel employed solely on the
Services, and the Contractor’s costs of protecting and securing the Services and less
advance payments received up to the date of the certificate, less other recoveries due in
terms of the contract and less taxes due to be deducted at source as per applicable law.

14.

Dispute settlement
If over the services, any dispute arises between the two parties, relating to any aspects
of this Agreement, the parties shall first attempt to settle the dispute through mutual
and amicable consultation.
In the event of agreement not being reached, the matter will be referred for arbitration
by a Sole Arbitrator not below the level of retired Superintending Engineer, PWD to
be appointed by the first party. The Arbitration will be conducted in accordance with
the Arbitration and Conciliation Act, 1996. The decision of the Arbitrator shall be
final and binding on both the parties. The Arbitrator shall give his award/decision
within 60 days of start of proceedings.

The Priced Bill of Quantities (Annexure 1), Format of Certificate (Annexure 2) and
Specification and Drawings (Annexure 3) are attached.

Signed and delivered by Sri. ________________________ ______________ for and on
behalf of the Contractor
In the presence of the Witness:
i)
ii)
SIGNATURE
Signed and delivered by Sri __________________ Deputy Executive Engineer/Executive
Engineer/Superintending Engineer ___________________________ of ______________ for
an on behalf of the Government.
In the presence of the Witness:
i)
ii)

SIGNATURE

6

<!-- page 23 -->

Annexure I
BILL OF QUANTITIES
S.No.

Description of
Service

Qty.

Unit

Estimated Cost2
In figure
(Rs.)

1

Collection of
Waste,
Manpower,
Logistics,
Processing cost,
Miscellaneous.

LS*

Amount

In Words

LS*

Gross Total Estimated Cost: Rs
Legend:
*LS = Lumpsum
We agree to perform the services in accordance with the approved drawings and technical
specifications at ............ percentage above/below the estimated rates, i.e., for a total Contract
Price of Rs. ...........(amount in figures) (Rs. ........... amount in words).
Signature of Contractor
(Where there is a discrepancy between the amount in figures and words, the amount in
words will prevail)

2

To be filled by the Implementing Agency

7

<!-- page 24 -->

Annexure - 2

Format of certificate
Certified that the services upto -------------------------------------------------- stage(as
defined in Clause 3.1 of the Agreement) in respect of service provided for ------------------------------------ at ----------------------------------- have been performed satisfactorily in accordance
with the terms and conditions of the agreement and as per approved drawings and technical
specifications.

Signature
Name & Designation
(Official address)
Place:
Date:

Office seal

8

<!-- page 25 -->

Annexure 3
Specification and Drawings
Floating Trash Boom (Adyar River)
Waste Accumulation
Waste Retrieval (Manual/Mechanical)
Primary Segregation at Source (Plastics, Organics, Mixed Debris)
Weighing & Documentation
Loading into Transport Vehicles
Transfer / Temporary Storage (Optional)
Transportation to MCC/MRF
Receiving & Inspection at MCC/MRF
Secondary Segregation & Processing
Recycling / Treatment / Final Disposal

9

<!-- page 26 -->

BANK GUARANTEE FOR ADVANCE PAYMENT
To:

__________________________________________ [name of Employer]
__________________________________________ [address of Employer]
___________________________________________[name of Contract]

Gentlemen:
In accordance with the provisions of the Conditions of Contract, sub-clause 3.1 of the
above-mentioned Contract, ________________________________ [name and address of
Contractor] (hereinafter called "the Contractor") shall deposit with ________________________ [name of Employer] a bank guarantee to guarantee his proper and faithful
performance under the said Clause of the Contract in an amount of _____________ [amount
of guarantee]1_________________________________ [in words].
We, the ____________________ [bank or financial institution], as instructed by the
Contractor, agree unconditionally and irrevocably to guarantee as primary obligator and not as
Surety merely, the payment to ____________________ [name of Employer] on his first
demand without whatsoever right of objection on our part and without his first claim to the
Contractor, in the amount not exceeding ____________________ [amount of guarantee]3
__________________________________ [in words].
We further agree that no change or addition to or other modification of the terms of the
Contract or of Services to be performed thereunder or of any of the Contract documents which
may be made between _____________________ [name of Employer] and the Contractor,
shall in any way release us from any liability under this guarantee, and we hereby waive
notice of any such change, addition or modification.
This guarantee shall remain valid and in full effect from the date of the advance
payment under the Contract until _________________________ [name of Employer] receives
full repayment of the same amount from the Contractor.
Yours truly,
Signature and seal: _______________________________
Name of Bank/Financial Institution: _________________
Address: _______________________________________
Date: ____________________

3

An amount shall be inserted by the bank or financial institution representing the amount of the Advance
Payment, and denominated in Indian Rupees.

10

<!-- page 27 -->

PERFORMANCE BANK GUARANTEE
(To be given from a nationalized or scheduled bank in India)

To:

______________________________________________ [name of Employer]
_________________________________________ [address of Employer]

WHEREAS _________________________ [name and address of Contractor]
(hereinafter called "the Contractor") has undertaken, in pursuance of Contract No. _____
dated ________________ to perform __________________________ [name of Contract and
brief description of Services] (hereinafter called "the Contract");
AND WHEREAS it has been stipulated by you in the said Contract that the Contractor
shall furnish you with a Bank Guarantee by a recognized bank for the sum specified therein as
security for compliance with his obligations in accordance with the Contract;
AND WHEREAS we have agreed to give the Contractor such a Bank Guarantee;
NOW THEREFORE we hereby affirm that we are the Guarantor and responsible to
you, on behalf of the Contractor, up to a total of ____________________ [amount of
guarantee]1___________________________ [in words], such sum being payable in the types
and proportions of currencies in which the Contract Price is payable, and we undertake to pay
you, upon your first written demand and without cavil or argument, any sum or sums within
the limits of ____________________ [amount of guarantee]1 as aforesaid without your
needing to prove or to show grounds or reasons for your demand for the sum specified therein.
We hereby waive the necessity of your demanding the said debt from the Contractor
before presenting us with the demand.
We further agree that no change or addition to or other modification of the terms of the
Contract or of the Services to be performed there under or of any of the Contract documents
which may be made between you and the Contractor shall in any way release us from any
liability under this guarantee, and we hereby waive notice of any such change, addition or
modification.
This guarantee shall be valid until 28 days from the date of expiry of the Defects
Liability Period.
Signature and seal of the guarantor _____________________________
Name of Bank ____________________________________________
Address ____________________________________________
Date ____________________________________________

11
