---
doc_id: "b6adfbb25f79a07c"
source_url: "https://www.shrc.tn.gov.in/assets/pdf/OA_Examination_150923.pdf"
ministry: "State Human Rights Commission, Tamil Nadu"
title: "Written Examination for the post of Office Assistant - Instructions"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f94f3dabea4a1ed3"
---

<!-- page 1 -->

STATE HUMAN RIGHTS COMMISSION TAMIL NADU
Written Examination for the post of Office Assistant
Date of Examination: 23.09.2023
Reporting Time: on 23.09.2023 at 10.30 a.m in the Examination Centre
and grace time is granted till 10.45. a.m and no candidate will be allowed to
enter the examination centre after 10.45 a.m
Duration of the Examination: 1 hour and 30 minutes from 11.00 a.m to 12.30 p.m
Number of questions 75 and each question carries 1 mark and no negative mark
would be awarded for the wrong answer
Total Marks for Written Examination: 75

Examination Number :
Instructions to the Candidates:
1. The Candidate should write their Examination Number using blue or black ball
point pen in the column given for writing their examination number in each and
every page.
2. The Candidate should write only their Examination Number in the column
provided for writing their Examination Number in each and every page and they
should not write their name or make any mark or symbol in any of the page, so
as to reveal their identity and if any such violation is noted, the answer paper of
the candidate stands invalid and no mark will be awarded to the candidate.
3. For each question, four options (A, B, C, D) are given as answers. The candidate
can choose their answer and put a tick mark (✓) in the box provided against
A or B or C or D using blue or black ball point pen.
4. If more than one answer is marked for one Question by the candidate, either by
striking of one answer or by marking two or more answers, it would be
considered as invalid and no mark will be awarded to such answer.

<!-- page 2 -->

khãy kåj cçikfŸ Miza« jäœehL
mYtyf cjéahs® gâ¡fhd vG¤J¤nj®Î
nj®Î ehŸ : 23.09.2023
m¿¡if neu«: 23.09.2023 m‹W fhiy 10.30 kâ¡F nj®Î ika¤Âš m¿¡if brŒant©L«,
nkY« fhiy 10.45 kâtiu fUiz neu« tH§f¥g£LŸsJ, fhiy 10,45 kâ¡F nkš tU« é©z¥gjhu®
nj®Î ika¤Â‰FŸ mDkÂ¡f¥glkh£lh®.
nj®Î¡fhd fhymtfhr« : fhiy 11.00 kâ Kjš kÂa« 12.30 kâ tiu 1 kâ neu« 30 ãäl§fŸ

bk¤j« 75 édh¡fŸ nf£f¥gL«, x›bthU édhé‰F« xU kÂ¥bg© tH§f¥gL«.
jtwhd éil¡F kÂ¥bg© Fiw¡f¥glkh£lhJ
vG¤J¤nj®Î¡fhd bkh¤j kÂ¥bg©: 75

nj®Î v©:

é©z¥gjhu®fS¡fhd m¿ÎiufŸ
1. é©z¥gjhu® j§fSila nj®Î v©iz, nj®Î v© vGj bfhL¡f¥g£LŸs
f£l¤Â‰FŸ Úy« mšyJ fU¥ò ghšghæ‹£ ngdh bfh©L mid¤J g¡f§fëY«
vGj nt©L«.
2. é©z¥gjhu® j§fSila nj®Î v©iz k£Lnk, mid¤J g¡f§fëY« nj®Î
v© vGj bfhL¡f¥g£LŸs f£l¤Â‰FŸ vGjnt©L«, é©z¥gjhu®
mt®fSila bgaiunah mšyJ mt®fë‹ milahs¤ij btë¥gL¤J« éjkhf
VjhtJ F¿p£ilnah mšyJ Á‹d¤ijnah, vªj g¡f¤ÂY« vGj¡TlhJ, m¥go
xU éÂÛwš f©l¿a¥g£lhš
é©z¥gjhuç‹ éil¤jhŸ bršyhjjhf
fUj¥g£L, mt‰¿‰F kÂ¥bg© tH§f¥glkh£lhJ.
3. X›bthU édhé‰F« A, B, C, D v‹W eh‹F gÂšfŸ ÏU¡F«, é©z¥gjhu®
rçahd gÂiy nj®bjL¤J Úy« mšyJ fU¥ò ghšghæ‹£ ngdhit¡ bfh©L,
A or B or C or D ¡F K‹ò cŸs f£l¤Âš o¡ F¿pL (✓) brŒant©L«.
4. é©z¥gjhu® xU nfŸé¡F x‹W¡F nk‰g£l gÂiy, mo¤njh mšyJ Ïu©L
mšyJ mj‰F nk‰g£l gÂiy F¿æ£oUªjhš mit bršyhjjhf fUj¥g£L
mt‰¿‰F kÂ¥bg© vJÎ« tH§f¥glkh£lhJ.
