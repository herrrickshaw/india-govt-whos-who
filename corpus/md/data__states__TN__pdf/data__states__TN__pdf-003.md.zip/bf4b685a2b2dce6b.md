---
doc_id: "bf4b685a2b2dce6b"
source_url: "https://www.tnsic.gov.in/pdf/guidelines/Fees_RTI_English.pdf"
ministry: "Tamil Nadu Information Commission, Tamil Nadu"
title: "RTI Fees - Summary - English"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2efb65d8aae3e4c2"
---

<!-- page 1 -->

FEES TO BE PAID UNDER RTI IN TAMIL NADU
Rule

Item

Fees to be paid

Mode of payment

Under Tamil Nadu Right to Information (Fees) Rules, 2005
3(a)

Fees to be paid along with Rs. 10/application

Cash, or
Postal Money order, or
Court fee stamp, or
Demand draft,
or Banker’s Cheque

For information provided under 7(1) of RTI Act
3(b)(i)
Supply of copies of documents
Rs.2/- per page of
A4 or A3 size
paper
3(b)(ii)
Actual charge or
cost price of a
copy of larger size
paper
3(b)(iii) Supply of samples or models
Actual cost
or
price
3(b)(iv) Inspection of records
No fee for first Cash, or
Demand draft, or
one hour.
Rs.5/- per hour (or Banker’s Cheque
fraction thereof)
thereafter
For information provided under Sec 7(5) of RTI Act
3(c)(i)
Supply in Diskette or Floppy
Rs.50/per
diskette or floppy
3(c)(ii) For priced publications
Price fixed for
publication, or
Rs 2 per page of
photocopy
for
extracts

Madras High Court Right to Information (Regulation of Fee and Cost)
Rules 2007
3

Fees to be paid along with Rs.10/application

Cash, or
Court Fee stamp, or
Treasury Chalan, or
Demand Draft, or
Postal Order
in favour of PIO, High
Court, Madras / Madurai

<!-- page 2 -->

For information under 7(1) and 7(5) of RTI Act
4(a)
For copies of order / decree/ To be obtained as per procedure for getting
Proviso judgment / documents on judicial certified copies under Appellate Side / Original
side under the control of the High Side Rules or Civil / Criminal Rules of Practice.
Court or Subordinate Courts
Will not be issued under RTI Act
4(a)
Copies of records except order / Rs.100/Cash, or
decree/ judgment / documents on If actual cost is Court Fee stamp, or
the judicial side
more, it would be Treasury Chalan, or
intimated
Demand Draft, or
Postal Order
4(b)
Information in the form of Rs.50/-per
diskette or floppy
diskette or floppy in favour of PIO High Court,
Madras / Madurai

Tamil Nadu Legislative Assembly Secretariat Right to Information (Fees)
Rules 2006
3(a)

Fees to be paid along with Rs.10/application

Cash, or
Court fee stamp, or
Demand draft, or
Banker’s Cheque

For information provided under 7(1) of RTI Act
3(b)(i)
Supply of copies of documents
Rs 2 per page of
A4 or A3 size
paper
3(b)(ii)
Actual charge or
cost price of a Cash, or
copy of larger size Demand draft, or
Banker’s Cheque
paper
3(b)(iii) Supply of samples or models
Actual cost
3(b)(iv) Inspection of records
No fee for first
one hour.
Rs.5/- per hour (or
fraction thereof)
thereafter
Note: 1. Head of Account into which Public Information Officer must remit fees received:

“0070. Other Administrative Services – 60 Other Services 118 Receipts under Right to Information Act, 2005 AA – Collection of fees under Right to Information (Fees) Rules 2005”
(DPC 0070 60 118 AA 0005)
2. The applicant may also remit the fee under the above head of account through
Treasury/ Pay and Accounts Office/ State Bank of India /Reserve Bank of India and
produce the chalan to the Public Information Officer as an evidence for having remitted
the fee.
