---
doc_id: "de17fa3afec6b509"
source_url: "https://tcp.tn.gov.in/storage/app/document/ewksKGjWlzpgy6Gd0oOhvQgYcrA4fkggG86CzdNg.pdf"
ministry: "Directorate of Town and Country Planning, Tamil Nadu"
title: "Circular - buildings dated 14.6.2010"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "52707cf0cca1157d"
---

<!-- page 1 -->

ef® Cuik¥ò Ïa¡Fe® mt®fë‹ brašKiw Miz
807 m©zhrhiy . br‹id 600 002
K‹åiy: ÂU g§f{ Fkh® g‹rš. Ï.M.g.
e.f.v©.9862/10Ãv1
bghUŸ :

go¡f :

ehŸ : 14.6.2010

ef® Cuik¥ò – 2010 -11 M« M©o‹ m¿é¥òfŸ -mÂfhu
g»®Î - cŸsh£ÁfS¡F Â£l mDkÂ tH§f TLjš
mÂfhu« tH§Fjš (Amendment) – r«gªjkhf.
1) ef® Cuik¥ò Ïa¡Fe® mt®fë‹ R‰w¿¡if v©.
41474/93o1 ehŸ 24.09.93
2) Ï›tYty mÂfhu g»®Î R‰w¿¡if v©.260/2008Ãv1 ,
ehŸ 05.02.2009
3) Å£L trÂ k‰W« ef®òw ts®¢Á¤ Jiwæ‹ 2010-11 M«
M©o‹ kh‹a nfhç¡if Ûjhd m¿é¥òfŸ
4) Ï›tYtyf brašKiw Miz Ïnj v©.
ehŸ 25.05.10
---

c¤juÎ:
gh®it 4-š f©LŸs brašKiw Mizæš br‹id bgUef® gFÂ
Ú§fyhf jäHf¤Â‹ Vida gFÂfëš eh‹F FoæU¥òfŸ mšyJ 4000
rJu mo¡FŸ f£l¥gL« FoæU¥ò f£ol§fS¡F« 2000 rJu mo¡FŸ
f£l¥gL« tâf f£ol§fS¡F« Â£l mDkÂ tH§f cŸsh£Á
mik¥òfS¡F mÂfhu« tH§F« Miz tH§f¥g£lÂš Ñœ¡f©l
ÂU¤j§fŸ brŒJ Miz tH§f¥gL»wJ.
gh®it 1-š fh© Ï›tYtyf R‰w¿¡ifæš cŸq® Â£l
FGk§fŸ k‰W« òJef®
ts®¢Á FGk§fë‹ f£L¥gh£oš cŸs
mid¤J cŸsh£ÁfS¡F éÂfS¡F c£g£L Â£l mDkÂ tH§F«
mÂfhu« Ñœfh© tifæš tH§f¥g£LŸsJ.
t.
f£ol
bkh¤j
FoæU¥ò
bkh¤j
f£ol
v©
ga‹ghL
js§fŸ
v©â¡if js¥gu¥ò tif¥ghL
1
FoæU¥ò
jiujs« +
1
200rJu
jå¤j
Kjšjs«
Û£l®
f£ol«
2
tâf
jiujs«
100 rJu
jå¤j
f£ol«
Û£l®
f£ol«

<!-- page 2 -->

/ 2 /

gh®it 3-š R£oa 2010-2011 M« M©o‹ Å£LtrÂ k‰W« ef®òw
ts®¢Á¤ Jiwæ‹ khåa¡ nfhç¡ifæ‹ Ûjhd m¿é¥Ãš Ñœ¡fh©
tifæš bjçé¡f¥g£LŸsJ.
“br‹id bgUef® gFÂ Ú§fyhf jäHf¤Â‹ vida gFÂfëš
eh‹F FoæU¥òfŸ mšyJ 4000 rJu mo¡FŸ f£l¥gL« f£ol§fS¡F
Â£l mDkÂ tH§f cŸsh£Á mik¥òfS¡F mÂfhu« tH§f¥gL«”.
nk‰go m¿é¥Ãid¤ bjhl®ªJ cŸq® Â£l FGk« k‰W« òJef®
ts®¢Á¡ FGk§fë‹ f£L¥gh£oš cŸs mid¤J cŸsh£ÁfS¡F«
ef® Cuik¥ò¢ r£l« 1971 ÃçÎ 49-‹ Ñœ Â£l mDkÂ (Technical
clearance) tH§fÎ«, Ãw gFÂfëš ml§F« cŸsh£Áfëš bjhêš E£g
mDkÂ tH§fÎ« Ñœ¡f©lthW mÂfhu« g»®ªjë¡f¥gL»wJ.
t.
f£ol
v© ga‹ghL
1
FoæU¥ò

bkh¤j
FoæU¥ò
bkh¤j
f£ol
js§fŸ
v©â¡if js¥gu¥ò tif¥ghL
jiujs« +
eh‹F
4000
jå¤j
Ïu©L js§fŸ
rJu mo
f£ol«
2
tâf
jiujs« + Kjš
2000
jå¤j
f£ol«
js«
rJu mo
f£ol«
nk‰go cŸsh£Áfshš tH§f¥gL« Â£l mDkÂ k‰w« bjhêš
E£g mDkÂ kid x¥òjYl‹ (Site approval) Ñœ¡fh© mid¤J
ãgªjidfisÍ« ãiwÎ brŒj Ã‹dnu tH§f¥glš nt©L«.
(1) éÂfŸ
(m) khefuh£Á/ efuh£Á/ng%uh£ÁfŸ
1) jäœehL kht£l efuh£Á f£ol éÂ 1972
2) ÂU¤Âa f£ol éÂ 1942 (kJiu khefuh£Á k£L«)
3) KGik¤ Â£l ãy cgnahf«
4) éçÎ mÃéU¤Â Â£l« Â£l éÂ
5) kid¥ÃçÎ ãgªjidfŸ
6) br‹id bgUef®ts®¢Á¡ FGk f£L¥gh£L éÂ
(ÂU¢Á, kJiu, nry«, nfhit, ÂUbešntè k‰W«
khkšyòu« cŸq® Â£l¡ FGk§fŸ)
M) Cuh£ÁfŸ
1) jäœehL Cuh£Á f£ol éÂ 1997
2) KGik¤ Â£l ãy cgnahf«
3) éçÎ mÃéU¤Â Â£l« Â£l éÂ
4) kid¥ÃçÎ ãgªjidfŸ

<!-- page 3 -->

/ 3 /

(Ï) mDkÂa‰w kid¥Ãçéš v›éj kid x¥òjnyh, f£ol
mDkÂnah mDkÂ¡f TlhJ.
<) nk‰go mÂfhu tu«ò k‰W« gu¥Ã‰FŸ mDkÂ tH§f¥g£L,
mnj kidæš TLjš f£ol« f£l é©z¥g« bgw¥go‹
g»®ªjë¡f¥g£l mÂfhu gu¥Ã‰FŸ ÏU¥ÃD« cŸsh£Áahš mDkÂ
tH§f ÏayhJ. m›thW bgw¥gL« é©z¥g§fŸ cŸq® Â£l¡
FGk mYtyf¤Â‰F / k©ly Jiz Ïa¡Fe® mYtyf¤Â‰F
rk®¥Ã¡f¥gl nt©L«.
(2) mÃéU¤Â f£lz«
T£L cŸq® Â£l¡ FGk«/ òJef® ts®¢Á¡ FGk¤Âš mikÍ«
cŸsh£Áfëš mªjªj cŸq® Â£l¡ FGk¤jhš ã®zæ¡f¥g£l
mÃéU¤Â f£lz¤Âid
tiunthiy _y« kDjhuçl« bg‰W
mªjªj cŸq® Â£l¡ FGk¤Â‰F mD¥Ã it¤jš nt©L«.
(3) e‹åiy tç:kid x¥òjš tH§F« bghGJ mj‰Fça
bjhif %,300/- I
Ñœ¡f©l jiy¥Ãš brY¤j¥g£L mj‹ mrš uÓJ cW¥Ãd® bray®/
k©ly Jiz Ïa¡Feçl« x¥gil¡f¥glš nt©L«.
fz¡F¤ jiy¥ò:
0217- Urban Development 03 IDSMT 800other Receipts – AA.
Director of Town Planning I Collecion of payments for services
rendered (0217-03-800-AA – 0102)
Ïjid k©ly Jiz Ïa¡Fe®/ cW¥Ãd®
mD¥g¥g£L fUñy x¥òjš brŒjš nt©L«.

bray® mt®fS¡F

(4) cŸf£lik¥ò k‰W« mo¥gil trÂ¡ f£lz«;(Infrastructure and Basic amenities Charges)
Áw¥ò f£ol§fŸ k‰W« mid¤J tifahd tâf f£ol§fŸ
M»at‰¿‰F murhiz v©,161 Å£L trÂ k‰W« ef®òw ts®¢Á¤
Jiw ehŸ 09.09.2009 ‹ Ñœ cŸf£lik¥ò k‰W« trÂ¡ f£lz«
Ñœ¡f©lthW tNè¡f¥glš nt©L«.

<!-- page 4 -->

/ 4 /

br§fšg£L
k©ly«
1r.Û %.

nfhit,Â
U¥ó®,
F¿¢Á
1r.Û %.

gykho f£ol« Ïšyhj k‰w f£ol§fŸ:
tâf f£ol«, jftš bjhêš E£g f£ol«.
bjhF¥ò f£ol« k‰w« Áw¥ò¡ f£ol«

250

190

125

ãWtd f£ol« (Institution Building)

100

75

50

bjhêšf£ol« (Industrial Building)

150

112.50

Ãw gFÂ
1 r.Û. %.

75
nk‰go f£lz¤Âid nkny f©l murhizæ‹go
r«gªj¥g£l cŸsh£Á
fz¡»£L kDjhuU¡F nf£ò (Demand)
tH§fš nt©L«.
nk‰go f£lz« kDjhuuhš neuoahf Ñœ¡fh© muR¤
jiy¥Ãš kht£l fUñy¤Âš brY¤j¥gl nt©L«.
fz¡F¤ jiy¥ò:
0217- Urban Development - 60 Urban Development - Scheme -800 –
Other Receipts under Infrastructure and Basic Amenities charges DPC
- 0217-60-800-AH – 003)
nkY« mrš brY¤J¢ Ó£L x¥Õ£L mYtyuhd r«gªj¥g£l
k©ly Jiz Ïa¡Fe® / cŸq® Â£l¡ FGk cW¥Ãd® brayU¡F
mD¥g¥g£L mtuhš x¥ÕL brŒa¥gL«.
k©ly Jiz Ïa¡Fe® / cŸq® Â£l¡ FGk cW¥Ãd®
bray® kht£l f%ñy¤Jl‹ x¥Ã£L khj« xUKiw x¥Ã£L
m¿¡ifæid (reconciliation statement) ef® Cuik¥ò Ïa¡ff¤Â‰F
mD¥g nt©L«. nkY« brY¤J¢ Ó£oš nk‰go bjhif cça fz¡F¤
jiy¥Ãš tuÎ it¡f¥glš nt©L«. mÂš VnjD« jtWfŸ mšyJ
khWjš ÏU¥Ã‹ k©ly Jiz Ïa¡Fe®/ cŸq® Â£l¡ FGk
cW¥Ãd® bray® kht£l f%ñy¤Âš x¥Ã£L cça fz¡»š rçf£l
(reconciliation) tuÎ it¡f elto¡if nk‰bfhŸsš nt©L«. k©ly
Jiz Ïa¡Fe® j§fŸ všiyæš cŸs Cuh£Áfis neuoahf MŒÎ
brŒJ
mo¥gil k‰W«
trÂ¡ f£lz« tNè¥gJ r«gªjkhf
f©fhâ¤J jiyik mYtyf¤Â‰F m›t¥nghJ m¿¡if
rk®¥Ã¤jš nt©L«.

<!-- page 5 -->

/ 5 /

k©ly Jiz Ïa¡Fe® j§fŸ Ñœ cŸs mid¤J
cŸsh£ÁfisÍ« MŒÎ brŒJ MŒÎ m¿¡if tUl« xUKiw ef®
Cuik¥ò Ïa¡FeU¡F mD¥òjš nt©L«.
kiyæl gFÂ, (Hill Area) fl‰fiu f£L¥gh£L gFÂ (costal
Regulation Zone) M»aitfS¡F nk‰go mÂfhu g»®Î bghUªjhJ.
nk‰go mÂfhu g»®Î 01.06.2010 èUªJ mKY¡F tU»wJ.
nk‰go cŸsh£ÁfS¡F tH§f¥gL« mÂfhu g»®Î kht£l
M£Á¤ jiyt®, r«gªj¥g£l kht£l ã®thf« (kht£l Cuf ts®¢Á
mYty®, kht£l ng%uh£Á mYty®) M»nahuhš f©fhâ¡f¥glš
nt©L«, nkY«. nk‰go mÂfhu g»®éid kht£l M£Á¤ jiyt®fŸ
Ï¤Jl‹ Ïiz¡f¥g£l got¤Â‹go ehëjœfëš bghJk¡fŸ
m¿Í«t©z« ÃuRu« brŒÂlš nt©L«.
nk‰go R‰w¿¡if bg‰W¡ bfh©lik¡F x¥òif¢ rh‹W
mD¥òkhW nf£L¡ bfhŸs¥gL»wJ.
x«/- g§f{ Fkh® g‹rš
ef® Cuik¥ò Ïa¡Fe®
bgWe®
1. mid¤J kht£l M£Áa®fŸ
2. mid¤J cW¥Ãd® bray®fŸ. mid¤J T£L cŸq® Â£l¡
FGk§fŸ / òJef® ts®¢Á¡ FGk§fŸ.
3. mid¤J k©ly Jiz Ïa¡Fe®fŸ
4. mid¤J khefuh£Á (br‹id Ú§fyhf) Miza®fŸ
5. TLjš Ïa¡Fe®fŸ(bgh), Ïiz Ïa¡Fe®fŸ, cjé Ïa¡Fe®fŸ ,
jiyik m Ytyf«.
efš rk®¥Ã¡f¥gL»wJ:
1) muR bray®, Å£L trÂ k‰W« ef®òw ts®¢Á¤ Jiw,
br‹id-9
2) muR bray®, efuh£Á ã®thf« k‰W« FoÚ® tH§fš Jiw,
br‹id -9
/Miz¥go/ mD¥g¥gL»wJ /

f©fhâ¥ghs®

<!-- page 6 -->

/ 6 /

g¤Âçif btëpL
Å£L trÂ k‰W« ef®òw ts®¢Á¤ Jiwæ‹ 2010-11M« M©o‰fhd
khåa nfhç¡if Ûjhd m¿é¥òfëš “br‹id bgUef® gFÂ Ú§fyhf
jäHf¤Â‹ Vida gFÂfëš eh‹F FoæU¥òfŸ mšyJ 4000 rJu
mo¡FŸ f£l¥gL« f£ol§fS¡F Â£l mDkÂ tH§f cŸsh£Á
mik¥òfS¡F mÂfhu x¥gil¥ò (Delegation of Powers) tH§f¥gL«” vd
bjçé¡f¥g£LŸsJ.
nk‰fh© m¿é¥Ãid¤ bjhl®ªJ, ef® Cuik¥ò Ïa¡Feç‹
brayhiz v©.9862/10ÃV1, ehŸ 25.05.10‹go cŸq® Â£l¡
FGk«/òJef® ts®¢Á¡ FGk¤Â‹ Ñœ cŸs mid¤J cŸsh£ÁfS¡F«
ef® Cuik¥ò r£l« 1971 ÃçÎ 49‹ Ñœ Â£l mDkÂÍ«, Ãw KGik¤Â£l«
m¿é¡f¥glhj gFÂfëš (Local Body is under un-Notified of Master Plan)
mikÍ« cŸsh£Áfëš bjhêš E£g mDkÂÍ« mid¤J éÂfS¡F
c£g£L (jäœehL kht£l efuh£Á f£ol éÂ 1972, jäœehL Cuh£Á f£ol
éÂ 1997 KGik¤ Â£l éÂ éçÎ mÃéU¤Â Â£l éÂ kid¥ÃçÎ
ãgªjidfŸ) r«gªj¥g£l cŸsh£ÁfŸ 01.06.2010 Kjš Ñœ¡f©lthW
kid
x¥òjYl‹
Toa
f£ol
mDkÂ
tH§F«
mÂfhu«
g»®ªjë¡f¥gL»wJ.
1.

4 FoæU¥òfS¡FŸ k‰W« 4000 rJu mo¡F äfhkš f£l¥gL«
jiu k‰W« Ïu©L js§fŸ bfh©l f£ol§fŸ

2.

2000 rJu mo¡FŸ f£l¥gL« jiu¤js« k‰W« Kjš js«
bfh©l tâf f£ol«

3.

nk‰go f£ol§fS¡F kid x¥òjš

4.

mDkÂa‰w kid¥Ãçéš v›éj
mDkÂnah mDkÂ¡f¡ TlhJ.

kid

x¥òjnyh,

f£ol

5.
nk‰go mÂfhu tu«ò k‰W« gu¥Ã‰FŸ mDkÂ tH§f¥g£L , mnj
kidæš TLjš f£ol« f£l é©z¥g« bgw¥go‹
g»®ªjë¡f¥g£l
mÂfhu gu¥Ã‰FŸ ÏU¥ÃD« cŸsh£Áahš
mDkÂ tH§f ÏayhJ.
m›thW bgw¥gL« é©z¥g§fŸ cŸq® Â£l¡ FGk mYtyf¤Â‰F /
k©ly Jiz Ïa¡Fe® mYtyf¤Â‰F rk®¥Ã¡f¥gl nt©L«.

kht£l M£Áa®
