---
doc_id: "eedf6baa8202dc4a"
source_url: "https://www.tnmsc.tn.gov.in/linkfiles/news_events/N2610572.pdf"
ministry: "Tamil Nadu Medical Services Corporation Limited (TNMSC), Tamil Nadu"
title: "Willingness called for to match the L1 rates for Online tender for the Supply of Essential Drugs and Medicines to TNMSC Limited under rate contract system for one year from the date of acceptance"
date: ""
pages: 63
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e33661dbc66c17f1"
---

<!-- page 1 -->

TAMIL NADU MEDICAL SERVICES CORPORATION LIMITED
(A Government of Tamilnadu Undertaking)
No. 417, PANTHEON ROAD, EGMORE, CHENNAI – 600 008.
ISO 9001:2008 Certified Organisation
Phone : 044-28191890, 28190259

Ref.No.e-004/M(P)/DRUG/TNMSC/2026

Date : 29.10.2026

To
The Tenderers (As per list)

Sirs,
Sub : TNMSC Limited - Online tender for the Supply of Essential Drugs and
Medicines to TNMSC Limited under rate contract system for one year
from the date of acceptance - Willingness called for to match the L1
rates - Communication Sent – Reg.
Ref : Tender Ref. No. e-004/M(P)/DRUG/TNMSC/2026, Dt. 03.03.2026
 
We herewith enclose the approved L1 rates for the supply of Essential Drugs
and Medicines to TNMSC Limited under rate contract system for one year from the
date of acceptance for which your firms have also quoted the rates. You may please
indicate your willingness to match these rates for corresponding product(s) on or before
04.11.2026 at 5.00 PM to TNMSC Limited to proceed further process.

Sd/Manager (Purchase)
Encl : List of Product(s) with approved L1 Rate.

<!-- page 2 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate
Name of the Tenderer : M/s.Abbott India Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 987
Ursodeoxycholic Acid Tablets IP - 150mg
50 X 10 Tabs
1,516.63
2 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Accent Pharmaceuticals and Diagnostics
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 525
Norethistrone Tablets IP - 5mg
50 X 10 Tabs
267.63
2 1007
Tranexamic Acid Tablets IP - 500mg
10 X 10 Tabs
309.00
3 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Acme Life Tech LLP
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 77
Dexamethasone Tablets IP - 0.5mg
50 X 10 Tabs
72.48
2 390
Bisacodyl Tablets IP - 5mg
50 X 10 Tabs
142.80
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Aculife Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 42
Ciprofloxacin Injection IP - 200mg
100ml FFS/BFS
8.90
2 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
3 140
Plasma Expander Infusion
500ml Bottle
178.00
4 172
Metronidazole Injection IP - 5mg/ml
100ml FFS/BFS
8.24
5 176
Adrenaline Injection IP - 1mg/ml
1ml Ampoule
2.81
6 212
Sterile Water for Injection IP - 10ml
10ml Ampoule
1.42
7 340
Mannitol Injection IP - 20% W/V
350ml Bottle
59.90
8 511
Atracurium Besylate Injection IP 2.5ml Ampoule
15.95
9 562
Sodium Chloride Injection IP - 0.9gm
500ml FFS/BFS
15.30
10 563
Sodium Chloride and Dextrose Injection
500ml FFS/BFS
16.83
11 567
Compound Sodium Lactate Injection IP
500ml FFS/BFS
15.65
12 568
Dextrose Injection IP - 5%
500ml FFS/BFS
17.33
13 706
Dextrose Injection IP - 25%
100ml FFS / BFS
11.40
14 714
Propofol Injection IP - 10mg/ml
10ml Vial
18.20
15 753
Ondansetron Injection IP - 2mg/ml
4ml Vial /
3.28

Page 1

<!-- page 3 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Aculife Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------16 825
Iron Sucrose Injection USP
5ml Amber
6.85
17 853
Sodium Chloride Injection IP - 0.9% W/V
100ml FFS/BFS
8.55
18 994
Paracetamol Infusion IP - 1000mg/100ml
100ml FFS/BFS
14.75
19 1006
Tranaxemic Acid Injection IP - 500mg/5ml 5ml Vial /
6.66
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Admac Life Sciences
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 293
Doxorubicin Injection IP - 10mg/5ml
5ml Vial
49.00
2 797
Paclitaxel Injection IP - 100mg/16.7ml
Vial
148.50
3 980
Letrozole Tablets IP - 2.5mg
50 X 10 Tabs
260.00
4 998
Imatinib Mesylate Tablets IP - 400mg
10 X 10 Tabs
1,249.85
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Adroit Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 16
Calcium Lactate Tablets IP - 300mg
10 X 10 Tabs
15.38
2 18
Vitamin B Complex Tablets Prophylactic
50 X 10 Tabs
59.59
3 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
4 199
Surgical Spirit IP - 500ml
500ml Bottle
51.90
5 200
Formaldehyde Solution BP - 450ml
450ml Bottle
45.40
6 302
Trihexyphenidyl Hydrochloride Tablets IP 50 X 10 Tabs
54.54
7 342
Povidone Iodine Solution IP - 5% W/V
500ml Bottle
58.50
8 383
Hydrogen Peroxide Solution (20 Vol) IP
1 Litre Bottle
38.10
9 387
Domperidone Tablets IP - 10mg
50 X 10 Tabs
67.28
10 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
11 492
Cetrimide Cream IP - 0.5%
25gms Tube
5.90
12 566
Silver Sulphadiazine Cream IP - 1% W/W
50gms Tube
71.91
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Affigenix Biosolutions Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 208
Anti 'D' Rh Blood Grouping Serum IP
10ml Vial
109.90
2 805
Anti AB Blood Grouping Serum - 10ml Vial 10ml Vial
74.85

Page 2

<!-- page 4 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Albino Lifesciences Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 797
Paclitaxel Injection IP - 100mg/16.7ml
Vial
148.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Alencure Biotech Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 229
Cephalexin Capsules IP - 250mg
10 X 10 Caps
167.69
2 592
Dispersible Amoxycillin Tablets IP 50 X 10 Tabs
284.15
3 776
Cefixime Tablets IP - 400mg
10 X 10 Tabs
497.84
4 818
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
444.50
5 819
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
371.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Algen Health Care Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 179
Carbamazepine Tablets IP - 200mg
50 X 10 Tabs
453.90
2 292
Azathioprine Tablets IP - 50mg
50 X 10 Tabs
395.00
3 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
4 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
5 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
6 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
7 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
8 757
Tacrolimus Capsules IP - 1mg
50 X 10 Caps
1,745.00
9 796
Olanzapine Tablets IP - 5mg
50 X 10 Tabs
104.75
10 813
Sitagliptin 50mg and Metformin
10 X 10 Tabs
77.00
11 826
Labetalol Tablets IP - 100mg
50 X 10 Tabs
496.90
12 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
13 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
14 980
Letrozole Tablets IP - 2.5mg
50 X 10 Tabs
260.00
15 992
Pregabalin Capsules IP - 75mg
50 X 10 Caps
244.40
16 1017
Baclofen Tablets IP - 10mg
50 X 10 Tabs
159.50
17 1033
Dapagliflozin Tablets - 10mg
50 X 10 Tabs
228.89
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 3

<!-- page 5 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Alkem Laboratories Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 994
Paracetamol Infusion IP - 1000mg/100ml
100ml FFS/BFS
14.75
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Allianz Bioscience Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 1004
Pre and Pro Biotic Capsules - DS
10 X 10 Caps
1,027.00
2 1031
Pre and Pro Biotic Granules for Oral
50ml PET/Glass
78.53
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Alpa Laboratories Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 12
Theophylline and Etofylline Injection
2ml Ampoule
2.39
2 17
Cyanocobalamin Injection IP - 1000mcg
1ml Ampoule
2.22
3 26
Gentamycin Eye Drops IP - 0.3%
5ml HDPE
4.13
4 46
Gentamicin Injection IP - 80mg/2ml
2ml Ampoule
2.72
5 75
Dexamethasone Sodium Phosphate Injection 2ml Vial /
2.10
6 76
Hydrocortisone Sodium Succinate
Vial
6.80
7 112
Frusemide Injection IP - 10mg/ml (IM/IV
2ml Ampoule
1.48
8 124
Lignocaine Hydrochloride Gel IP - 2% W/V 30gms Tube
7.18
9 158
Metoclopramide Injection IP - 5mg/ml (IM 2ml Ampoule
2.21
10 159
Ranitidine Hydrochloride Injection IP 2ml Ampoule
1.75
11 183
Diazepam Injection IP - 5mg/ml
2ml Ampoule
3.30
12 196
Pheniramine Maleate Injection IP 2ml Ampoule
1.89
13 224
Amikacin Sulphate Injection IP - 50mg/ml 2ml Vial /
4.57
14 310
Lignocaine Hydrochloride Injection IP 30ml Vial
7.59
15 376
Betamethasone Valerate Ointment IP 15gms Tube
7.18
16 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
17 458
Dicyclomine Hydrochloride Injection IP - 2ml Ampoule
2.12
18 495
Diclofenac Sodium Injection IP - 25mg/ml 3ml Ampoule
1.90
19 510
Diclofenac Gel IP
25gms Tube
4.73
20 523
Ciprofloxacin Eye Drops IP - 0.3% (Eye / 5ml HDPE
3.93
21 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
22 711
Methyl Prednisolone Sodium Succinate for Vial
49.21
23 751
Ondansetron Injection IP - 2mg/ml
2ml Ampoule
1.27
24 753
Ondansetron Injection IP - 2mg/ml
4ml Vial /
3.28
25 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
26 988
Vancomycin Intravenous Infusion IP Vial
33.33

Page 4

<!-- page 6 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Amar Products
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 3
Paracetamol Paediatric Syrup IP
60ml PET/Glass
7.97
2 4
Co-Trimoxazole Oral Suspension IP
50ml Pet /
8.99
3 70
Lysol IP (Cresol with Soap Solution)
5 Ltrs Plastic
830.90
4 199
Surgical Spirit IP - 500ml
500ml Bottle
51.90
5 342
Povidone Iodine Solution IP - 5% W/V
500ml Bottle
58.50
6 377
Gamma Benzene Hexachloride Application
100ml Plastic
19.71
7 383
Hydrogen Peroxide Solution (20 Vol) IP
1 Litre Bottle
38.10
8 510
Diclofenac Gel IP
25gms Tube
4.73
9 566
Silver Sulphadiazine Cream IP - 1% W/W
50gms Tube
71.91
10 571
Liquid Paraffin IP (Heavy) - 500ml
500ml Bottle
118.18
11 576
Compound Benzoic Acid Ointment IP
15gms Tube
6.94
12 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
13 830
Calamine Lotion IP
100ml Plastic
21.78
14 834
Liquid Paraffin IP - 60ml Bottle
60ml Plastic
15.41
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Anon Pharmaceuticals
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
2 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
3 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
4 910
Ciprofloxacin Tablets IP - 250mg
10 X 10 Tabs
72.02
5 979
Lactulose Solution USP
200ml PET/Glass
69.49
6 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Apco Pharma Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
2 189
Amitriptyline Tablets IP - 25mg
50 X 10 Tabs
95.95
3 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
4 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
5 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
6 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
7 987
Ursodeoxycholic Acid Tablets IP - 150mg
50 X 10 Tabs
1,516.63

Page 5

<!-- page 7 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Apco Pharma Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------8 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
9 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Appasamy Ocular Devices (P) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 348
Bupivacaine Injection IP - 0.5% W/V
20ml Vial
12.24
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Astam Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
2 818
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
444.50
3 819
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
371.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Aura Lifecare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
2 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
3 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
4 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
5 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
6 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
7 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Bajaj Healthcare Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 292
Azathioprine Tablets IP - 50mg
50 X 10 Tabs
395.00

Page 6

<!-- page 8 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Bajaj Healthcare Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------2 813
Sitagliptin 50mg and Metformin
10 X 10 Tabs
77.00
3 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
4 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
5 857
Hydroxy Chloroquine Tablets IP - 200mg
50 X 10 Tabs
965.60
6 875
Sitagliptin Phosphate Tablets IP - 50mg
50 X 10 Tabs
288.50
7 876
Sitagliptin Phosphate Tablets IP - 100mg 50 X 10 Tabs
415.00
8 932
Hyoscine Butyl Bromide Tablets IP - 10mg 50 X 10 Tabs
715.00
9 1016
Ticagrelor Tablets IP - 90mg
10 X 14 Tabs
339.99
10 1023
Linagliptin Tablets - 5mg
50 X 10 Tabs
288.90
11 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Beryl Drugs Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 563
Sodium Chloride and Dextrose Injection
500ml FFS/BFS
16.83
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Bharat Serums and Vaccines Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 462
Carboprost Tromethamine Injection IP
1ml
32.40
2 809
Rabies Antiserum IP
5ml Vial
338.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Biocon Biologics Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 322
Human Insulin Soluble (Neutral) IP - 40
10ml Vial
81.80
2 323
Human Insulin Isophane IP - 40 IU/ml
10ml Vial
86.87
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 7

<!-- page 9 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Bioconic Remedies
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
2 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
3 149
Ascorbic Acid Tablet IP - 100mg
50 X 10 Tabs
63.63
4 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
5 189
Amitriptyline Tablets IP - 25mg
50 X 10 Tabs
95.95
6 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
7 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
8 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
9 510
Diclofenac Gel IP
25gms Tube
4.73
10 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
11 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
12 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
13 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
14 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
15 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
16 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
17 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
18 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Biodeal Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
2 813
Sitagliptin 50mg and Metformin
10 X 10 Tabs
77.00
3 982
Linezolid Tablets IP - 600mg
10 X 10 Tabs
398.90
4 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
5 1007
Tranexamic Acid Tablets IP - 500mg
10 X 10 Tabs
309.00
6 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Biogenetic Drugs (P) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 3
Paracetamol Paediatric Syrup IP
60ml PET/Glass
7.97
3 5
Co-Trimoxazole Tablets IP
10 X 10 Tabs
70.20
4 160
Ranitidine Hydrochloride Tablets IP 50 X 10 Tabs
213.50
5 837
Calcium Carbonate and Vitamin D3 Tablets 10 X 10 Tabs
22.90
6 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78

Page 8

<!-- page 10 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Biogenetic Drugs (P) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------7 1032
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
54.95
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Biolab Diagnostics (I) Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 208
Anti 'D' Rh Blood Grouping Serum IP
10ml Vial
109.90
2 209
Anti A Blood Grouping Serum IP
10ml Vial
55.69
3 210
Anti B Blood Grouping Serum IP
10ml Vial
56.67
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Biological E Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 325
Snake Venom Anti Serum IP (Freeze Dried) Vial
550.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Brassica Pharma Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 767
Dinoprostone Gel
Pre-Filled
96.96
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Bruck Pharma Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 293
Doxorubicin Injection IP - 10mg/5ml
5ml Vial
49.00
2 783
Doxorubicin Hydrochloride Injection IP
25ml Vial
154.99
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 9

<!-- page 11 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.CMG Biotech Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 98
Diltiazem Hydrochloride Tablets IP 50 X 10 Tabs
169.40
2 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
3 259
Enalapril Maleate Tablets IP - 2.5mg
50 X 10 Tabs
86.85
4 292
Azathioprine Tablets IP - 50mg
50 X 10 Tabs
395.00
5 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
6 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
7 531
Chlordiazepoxide Tablets IP - 10mg
50 X 10 Tabs
171.00
8 591
Acenocoumarol Tablets IP (Nicoumalone) - 50 X 10 Tabs
290.45
9 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
10 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
11 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
12 757
Tacrolimus Capsules IP - 1mg
50 X 10 Caps
1,745.00
13 786
Gliclazide Tablets IP - 40mg
50 X 10 Tabs
235.00
14 812
Entecavir Tablets IP - 0.5mg
3 X 10 Tabs /
75.40
15 813
Sitagliptin 50mg and Metformin
10 X 10 Tabs
77.00
16 838
Tacrolimus Capsules IP - 0.5mg
50 X 10 Caps
1,010.00
17 857
Hydroxy Chloroquine Tablets IP - 200mg
50 X 10 Tabs
965.60
18 872
Gabapentin Capsules IP - 100mg
10 X 10 Caps
46.99
19 876
Sitagliptin Phosphate Tablets IP - 100mg 50 X 10 Tabs
415.00
20 910
Ciprofloxacin Tablets IP - 250mg
10 X 10 Tabs
72.02
21 982
Linezolid Tablets IP - 600mg
10 X 10 Tabs
398.90
22 987
Ursodeoxycholic Acid Tablets IP - 150mg
50 X 10 Tabs
1,516.63
23 992
Pregabalin Capsules IP - 75mg
50 X 10 Caps
244.40
24 997
Clobazam Tablets IP - 5mg
50 X 10 Tabs
195.00
25 1000
Mycophenolate Sodium Tablets - 360mg
10 X 10 Tabs
488.88
26 1005
Quetiapine Tablets IP - 50mg
50 X 10 Tabs
176.75
27 1010
Gabapentin Tablets IP - 300mg
10 X 10 Tabs
87.87
28 1011
Sodium Bicarbonate Tablets USP - 500mg
10 X 10 Tabs
35.62
29 1017
Baclofen Tablets IP - 10mg
50 X 10 Tabs
159.50
30 1022
Clozapine Tablets IP - 100mg
50 X 10 Tabs
535.00
31 1028
Tamsulosin Hydrochloride Prolonged
50 X 10 Caps
361.14
32 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
33 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
34 1055
Betahistine Hydrochloride Tablets IP 50 X 10 Tabs
130.45
35 1061
Escitalopram Tablets IP - 10mg
50 X 10 Tabs
155.00
36 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Cadila Pharmaceuticals Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39

Page 10

<!-- page 12 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Cadila Pharmaceuticals Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------3 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
4 259
Enalapril Maleate Tablets IP - 2.5mg
50 X 10 Tabs
86.85
5 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
6 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
7 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
8 825
Iron Sucrose Injection USP
5ml Amber
6.85
9 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
10 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
11 877
Streptokinase Injection IP - 15 Lacs
Vial
646.00
12 979
Lactulose Solution USP
200ml PET/Glass
69.49
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Candour Pharmaceuticals
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 3
Paracetamol Paediatric Syrup IP
60ml PET/Glass
7.97
2 4
Co-Trimoxazole Oral Suspension IP
50ml Pet /
8.99
3 5
Co-Trimoxazole Tablets IP
10 X 10 Tabs
70.20
4 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
5 24
Glibenclamide Tablets IP - 5mg
50 X 10 Tabs
46.80
6 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
7 55
Erythromycin Stearate Tablets IP - 250mg 10 X 10 Tabs
242.37
8 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
9 77
Dexamethasone Tablets IP - 0.5mg
50 X 10 Tabs
72.48
10 79
Prednisolone Tablets IP - 5mg
50 X 10 Tabs
112.29
11 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00
12 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
13 110
Propranolol Tablets IP - 40mg
50 X 10 Tabs
90.90
14 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
15 149
Ascorbic Acid Tablet IP - 100mg
50 X 10 Tabs
63.63
16 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
17 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
18 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
19 169
Glipizide Tablets IP - 5mg
50 X 10 Tabs
86.15
20 179
Carbamazepine Tablets IP - 200mg
50 X 10 Tabs
453.90
21 180
Phenytoin Sodium Tablets IP - 100mg
HDPE Bottle of
26.84
22 189
Amitriptyline Tablets IP - 25mg
50 X 10 Tabs
95.95
23 193
Chlorpheniramine Maleate Tablets IP 50 X 10 Tabs
38.55
24 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
25 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
26 292
Azathioprine Tablets IP - 50mg
50 X 10 Tabs
395.00
27 356
Metronidazole Benzoate Oral Suspension
60ml Bottle
14.10
28 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50

Page 11

<!-- page 13 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Candour Pharmaceuticals
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------29 387
Domperidone Tablets IP - 10mg
50 X 10 Tabs
67.28
30 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
31 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
32 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
33 492
Cetrimide Cream IP - 0.5%
25gms Tube
5.90
34 493
Zinc Cream IP - 32%
25gms Tube
7.25
35 510
Diclofenac Gel IP
25gms Tube
4.73
36 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
37 529
Risperidone Tablets IP - 2mg
50 X 10 Tabs
79.80
38 570
Pheniramine Maleate Syrup - 15mg/5ml
10ml Bottle
8.85
39 576
Compound Benzoic Acid Ointment IP
15gms Tube
6.94
40 578
Potassium Chloride Oral Solution USP 200ml Amber
20.67
41 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
42 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
43 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
44 716
Co-Trimoxazole Tablets IP
50 X 10 Tabs
194.00
45 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
46 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
47 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
48 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
49 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
50 796
Olanzapine Tablets IP - 5mg
50 X 10 Tabs
104.75
51 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
52 826
Labetalol Tablets IP - 100mg
50 X 10 Tabs
496.90
53 837
Calcium Carbonate and Vitamin D3 Tablets 10 X 10 Tabs
22.90
54 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
55 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
56 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
57 987
Ursodeoxycholic Acid Tablets IP - 150mg
50 X 10 Tabs
1,516.63
58 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
59 1034
Dextromethorphan Hydrobromide and
60ml PET/Glass
10.20
60 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
61 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Carewell Steuart Pharma Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 16
Calcium Lactate Tablets IP - 300mg
10 X 10 Tabs
15.38
3 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
4 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
5 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00

Page 12

<!-- page 14 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Carewell Steuart Pharma Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------6 106
Frusemide Tablets IP - 40mg
50 X 10 Tabs
119.95
7 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
8 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
9 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
10 169
Glipizide Tablets IP - 5mg
50 X 10 Tabs
86.15
11 179
Carbamazepine Tablets IP - 200mg
50 X 10 Tabs
453.90
12 180
Phenytoin Sodium Tablets IP - 100mg
HDPE Bottle of
26.84
13 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
14 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
15 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
16 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
17 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
18 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
19 777
Aluminium Hydroxide and Magnesium
10 X 10 Tabs
17.38
20 837
Calcium Carbonate and Vitamin D3 Tablets 10 X 10 Tabs
22.90
21 867
Paracetamol Tablets IP - 650mg
10 X 10 Tabs
39.49
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Chiron Behring Vaccines Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 724
Rabies Vaccine Human (Cell Culture) IP
1ml Vial with
238.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Cipco Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 3
Paracetamol Paediatric Syrup IP
60ml PET/Glass
7.97
2 4
Co-Trimoxazole Oral Suspension IP
50ml Pet /
8.99
3 5
Co-Trimoxazole Tablets IP
10 X 10 Tabs
70.20
4 18
Vitamin B Complex Tablets Prophylactic
50 X 10 Tabs
59.59
5 55
Erythromycin Stearate Tablets IP - 250mg 10 X 10 Tabs
242.37
6 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
7 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
8 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
9 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
10 193
Chlorpheniramine Maleate Tablets IP 50 X 10 Tabs
38.55
11 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
12 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
13 331
Polyvitamin Tablets Prophylactic NFI
50 X 10 Tabs
167.40

Page 13

<!-- page 15 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Cipco Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------14 450
Chloroquine Phosphate Tablets IP - 250mg 10 X 10 Tabs
90.00
15 496
Ferrous Sulphate with Folic Acid Tablets 50 X 10 Tabs
45.00
16 497
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
64.00
17 716
Co-Trimoxazole Tablets IP
50 X 10 Tabs
194.00
18 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
19 836
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
47.20
20 837
Calcium Carbonate and Vitamin D3 Tablets 10 X 10 Tabs
22.90
21 842
Chlorthalidone Tablets IP - 6.25mg
50 X 10 Tabs
114.15
22 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
23 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
24 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
25 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
26 867
Paracetamol Tablets IP - 650mg
10 X 10 Tabs
39.49
27 875
Sitagliptin Phosphate Tablets IP - 50mg
50 X 10 Tabs
288.50
28 1008
IFA - WIFS Tablets (Blue)
50 X 15 Tabs
142.00
29 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
30 1032
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
54.95
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Cipla Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 808
Salbutamol Nebulizer Solution BP 15ml Bottle
8.13
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Concord Biotech Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
2 1000
Mycophenolate Sodium Tablets - 360mg
10 X 10 Tabs
488.88
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Concord Drugs Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
2 18
Vitamin B Complex Tablets Prophylactic
50 X 10 Tabs
59.59

Page 14

<!-- page 16 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Concord Drugs Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------3 24
Glibenclamide Tablets IP - 5mg
50 X 10 Tabs
46.80
4 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
5 79
Prednisolone Tablets IP - 5mg
50 X 10 Tabs
112.29
6 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00
7 98
Diltiazem Hydrochloride Tablets IP 50 X 10 Tabs
169.40
8 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
9 110
Propranolol Tablets IP - 40mg
50 X 10 Tabs
90.90
10 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
11 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
12 189
Amitriptyline Tablets IP - 25mg
50 X 10 Tabs
95.95
13 193
Chlorpheniramine Maleate Tablets IP 50 X 10 Tabs
38.55
14 229
Cephalexin Capsules IP - 250mg
10 X 10 Caps
167.69
15 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
16 302
Trihexyphenidyl Hydrochloride Tablets IP 50 X 10 Tabs
54.54
17 356
Metronidazole Benzoate Oral Suspension
60ml Bottle
14.10
18 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
19 450
Chloroquine Phosphate Tablets IP - 250mg 10 X 10 Tabs
90.00
20 464
Alprazolam Tablets IP - 0.5mg
50 X 10 Tabs
70.70
21 479
Albendazole Oral Suspension IP 10ml Amber
8.64
22 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
23 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
24 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
25 592
Dispersible Amoxycillin Tablets IP 50 X 10 Tabs
284.15
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Consern Pharma Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 182
Sodium Valporate Gastro Resistant
50 X 10 Tabs
368.90
2 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
3 796
Olanzapine Tablets IP - 5mg
50 X 10 Tabs
104.75
4 849
Lorazepam Tablets IP - 2mg
50 X 10 Tabs
160.50
5 850
Clozapine Tablets IP - 50mg
10 X 10 Tabs
74.90
6 997
Clobazam Tablets IP - 5mg
50 X 10 Tabs
195.00
7 1017
Baclofen Tablets IP - 10mg
50 X 10 Tabs
159.50
8 1022
Clozapine Tablets IP - 100mg
50 X 10 Tabs
535.00
9 1038
Sodium Valproate and Valproic Acid
10 X 10 Tabs
113.10
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 15

<!-- page 17 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Cotec Healthcare Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
2 18
Vitamin B Complex Tablets Prophylactic
50 X 10 Tabs
59.59
3 26
Gentamycin Eye Drops IP - 0.3%
5ml HDPE
4.13
4 37
Ampicillin Sodium Injection IP - 500mg
Vial
6.82
5 40
Cefotaxime Sodium Injection IP - 250mg
Vial
6.96
6 46
Gentamicin Injection IP - 80mg/2ml
2ml Ampoule
2.72
7 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
8 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
9 76
Hydrocortisone Sodium Succinate
Vial
6.80
10 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
11 90
Theophylline and Etofylline Prolonged
50 X 10 Tabs
148.45
12 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00
13 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
14 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
15 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
16 158
Metoclopramide Injection IP - 5mg/ml (IM 2ml Ampoule
2.21
17 160
Ranitidine Hydrochloride Tablets IP 50 X 10 Tabs
213.50
18 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
19 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
20 179
Carbamazepine Tablets IP - 200mg
50 X 10 Tabs
453.90
21 193
Chlorpheniramine Maleate Tablets IP 50 X 10 Tabs
38.55
22 199
Surgical Spirit IP - 500ml
500ml Bottle
51.90
23 224
Amikacin Sulphate Injection IP - 50mg/ml 2ml Vial /
4.57
24 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
25 229
Cephalexin Capsules IP - 250mg
10 X 10 Caps
167.69
26 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
27 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
28 331
Polyvitamin Tablets Prophylactic NFI
50 X 10 Tabs
167.40
29 359
Acyclovir Dispersible Tablets IP - 200mg 50 X 10 Tabs
645.00
30 387
Domperidone Tablets IP - 10mg
50 X 10 Tabs
67.28
31 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
32 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
33 466
Multivitamin Drops
15ml Glass /
8.39
34 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
35 493
Zinc Cream IP - 32%
25gms Tube
7.25
36 495
Diclofenac Sodium Injection IP - 25mg/ml 3ml Ampoule
1.90
37 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
38 510
Diclofenac Gel IP
25gms Tube
4.73
39 512
Bupivacaine Hydrochloride in Dextrose
4ml Ampoule
6.48
40 514
Iohexol Injection USP - 350mg/ml
50ml Glass /
484.29
41 523
Ciprofloxacin Eye Drops IP - 0.3% (Eye / 5ml HDPE
3.93
42 525
Norethistrone Tablets IP - 5mg
50 X 10 Tabs
267.63
43 576
Compound Benzoic Acid Ointment IP
15gms Tube
6.94
44 578
Potassium Chloride Oral Solution USP 200ml Amber
20.67
45 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
46 591
Acenocoumarol Tablets IP (Nicoumalone) - 50 X 10 Tabs
290.45

Page 16

<!-- page 18 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Cotec Healthcare Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------47 592
Dispersible Amoxycillin Tablets IP 50 X 10 Tabs
284.15
48 712
Nifedipine Sustained Release Tablets IP
50 X 10 Tabs
107.00
49 728
Zinc Sulphate Tablets BP
50 X 10 Tabs
84.10
50 749
Meropenem Injection IP - 500mg
Vial
31.69
51 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
52 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
53 757
Tacrolimus Capsules IP - 1mg
50 X 10 Caps
1,745.00
54 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
55 776
Cefixime Tablets IP - 400mg
10 X 10 Tabs
497.84
56 777
Aluminium Hydroxide and Magnesium
10 X 10 Tabs
17.38
57 778
Cefoperazone and Sulbactum for Injection Vial
15.40
58 798
Piperacillin and Tazobactum Injection IP Vial
43.21
59 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
60 818
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
444.50
61 819
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
371.50
62 820
Amoxycillin and Potassium Clavulanate
Vial
22.95
63 825
Iron Sucrose Injection USP
5ml Amber
6.85
64 826
Labetalol Tablets IP - 100mg
50 X 10 Tabs
496.90
65 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
66 842
Chlorthalidone Tablets IP - 6.25mg
50 X 10 Tabs
114.15
67 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
68 897
Amoxycillin Capsules IP - 500mg
10 X 10 Caps
151.66
69 979
Lactulose Solution USP
200ml PET/Glass
69.49
70 984
Pantoprazole For Injection - 40mg
Vial
4.93
71 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
72 1010
Gabapentin Tablets IP - 300mg
10 X 10 Tabs
87.87
73 1011
Sodium Bicarbonate Tablets USP - 500mg
10 X 10 Tabs
35.62
74 1016
Ticagrelor Tablets IP - 90mg
10 X 14 Tabs
339.99
75 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
76 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
77 1059
Cefotaxime Sodium Injection - 500mg
Vial
9.08
78 1060
Ceftriaxone Injection IP - 500mg
Vial
9.30
79 1085
Vitamin D3 Drops
15ml HDPE
6.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Curetech Skincare
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
2 510
Diclofenac Gel IP
25gms Tube
4.73
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 17

<!-- page 19 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.DJ Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 172
Metronidazole Injection IP - 5mg/ml
100ml FFS/BFS
8.24
2 562
Sodium Chloride Injection IP - 0.9gm
500ml FFS/BFS
15.30
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Daffodills Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
2 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Dr Miltons Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 24
Glibenclamide Tablets IP - 5mg
50 X 10 Tabs
46.80
2 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
3 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
4 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
5 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
6 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
7 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
8 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
9 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
10 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
11 837
Calcium Carbonate and Vitamin D3 Tablets 10 X 10 Tabs
22.90
12 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
13 910
Ciprofloxacin Tablets IP - 250mg
10 X 10 Tabs
72.02
14 1010
Gabapentin Tablets IP - 300mg
10 X 10 Tabs
87.87
15 1055
Betahistine Hydrochloride Tablets IP 50 X 10 Tabs
130.45
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Dueful Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 26
Gentamycin Eye Drops IP - 0.3%
5ml HDPE
4.13
2 76
Hydrocortisone Sodium Succinate
Vial
6.80
3 159
Ranitidine Hydrochloride Injection IP 2ml Ampoule
1.75

Page 18

<!-- page 20 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Dueful Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------4 224
Amikacin Sulphate Injection IP - 50mg/ml 2ml Vial /
4.57
5 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
6 495
Diclofenac Sodium Injection IP - 25mg/ml 3ml Ampoule
1.90
7 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
8 523
Ciprofloxacin Eye Drops IP - 0.3% (Eye / 5ml HDPE
3.93
9 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
10 984
Pantoprazole For Injection - 40mg
Vial
4.93
11 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Eamon Drugs Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Emcure Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
2 872
Gabapentin Capsules IP - 100mg
10 X 10 Caps
46.99
3 1000
Mycophenolate Sodium Tablets - 360mg
10 X 10 Tabs
488.88
4 1010
Gabapentin Tablets IP - 300mg
10 X 10 Tabs
87.87
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Eris Lifesciences Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 1019
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
105.00
2 1020
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
155.00
3 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 19

<!-- page 21 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Eurokem Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 5
Co-Trimoxazole Tablets IP
10 X 10 Tabs
70.20
2 18
Vitamin B Complex Tablets Prophylactic
50 X 10 Tabs
59.59
3 24
Glibenclamide Tablets IP - 5mg
50 X 10 Tabs
46.80
4 86
Isosorbide Dinitrate Tablets IP - 5mg
50 X 10 Tabs
71.90
5 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00
6 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
7 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
8 149
Ascorbic Acid Tablet IP - 100mg
50 X 10 Tabs
63.63
9 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
10 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
11 180
Phenytoin Sodium Tablets IP - 100mg
HDPE Bottle of
26.84
12 193
Chlorpheniramine Maleate Tablets IP 50 X 10 Tabs
38.55
13 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
14 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
15 302
Trihexyphenidyl Hydrochloride Tablets IP 50 X 10 Tabs
54.54
16 368
Levodopa and Carbidopa Tablets IP
50 X 10 Tabs
725.00
17 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
18 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
19 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
20 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
21 723
Aspirin Gasto-Resistant Tablets IP 50 X 10 Tabs
154.99
22 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
23 826
Labetalol Tablets IP - 100mg
50 X 10 Tabs
496.90
24 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
25 867
Paracetamol Tablets IP - 650mg
10 X 10 Tabs
39.49
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Exemed Pharmaceuticals
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
2 875
Sitagliptin Phosphate Tablets IP - 50mg
50 X 10 Tabs
288.50
3 1016
Ticagrelor Tablets IP - 90mg
10 X 14 Tabs
339.99
4 1023
Linagliptin Tablets - 5mg
50 X 10 Tabs
288.90
5 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
6 1033
Dapagliflozin Tablets - 10mg
50 X 10 Tabs
228.89
7 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
8 1070
Linagliptin + Metformin Tablets
10 X 10 Tabs
68.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 20

<!-- page 22 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Francis Remedies (India) Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 159
Ranitidine Hydrochloride Injection IP 2ml Ampoule
1.75
2 751
Ondansetron Injection IP - 2mg/ml
2ml Ampoule
1.27
3 984
Pantoprazole For Injection - 40mg
Vial
4.93
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Genetek Lifesciences Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
2 176
Adrenaline Injection IP - 1mg/ml
1ml Ampoule
2.81
3 177
Atropine Sulphate Injection IP 1ml Ampoule
1.96
4 212
Sterile Water for Injection IP - 10ml
10ml Ampoule
1.42
5 219
Sodium Bicarbonate Injection IP - 7.5%
10ml Ampoule
6.15
6 514
Iohexol Injection USP - 350mg/ml
50ml Glass /
484.29
7 581
Magnesium Sulphate Injection IP 2ml Ampoule
2.60
8 714
Propofol Injection IP - 10mg/ml
10ml Vial
18.20
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Geno Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Glowria Lifecare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 342
Povidone Iodine Solution IP - 5% W/V
500ml Bottle
58.50
2 454
Povidone Iodine Cleaning Solution USP 500ml Bottle
107.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Gnosis Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
-------------------------------------------------------------------------------------

Page 21

<!-- page 23 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Gnosis Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 182
Sodium Valporate Gastro Resistant
50 X 10 Tabs
368.90
2 510
Diclofenac Gel IP
25gms Tube
4.73
3 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
4 1083
Trypsin and Chymotrypsin Tablets 10 X 10 Tabs
41.35
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Haseeb Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 212
Sterile Water for Injection IP - 10ml
10ml Ampoule
1.42
2 562
Sodium Chloride Injection IP - 0.9gm
500ml FFS/BFS
15.30
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Heal (India) Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
3 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
4 721
Prazosin Hydrochloride Tablets IP - 2mg
50 X 10 Tabs
461.21
5 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
6 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
7 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
8 813
Sitagliptin 50mg and Metformin
10 X 10 Tabs
77.00
9 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
10 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
11 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
12 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
13 875
Sitagliptin Phosphate Tablets IP - 50mg
50 X 10 Tabs
288.50
14 876
Sitagliptin Phosphate Tablets IP - 100mg 50 X 10 Tabs
415.00
15 952
Ofloxacin Tablets - 200mg
50 X 10 Tabs
409.99
16 992
Pregabalin Capsules IP - 75mg
50 X 10 Caps
244.40
17 1027
S(-) Metoprolol Succinate Extended
50 X 10 Tabs
1,888.50
18 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
19 1033
Dapagliflozin Tablets - 10mg
50 X 10 Tabs
228.89
20 1034
Dextromethorphan Hydrobromide and
60ml PET/Glass
10.20
21 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
22 1041
Pre and Probiotic Capsules
10 X 10 Caps
128.99
23 1042
Pre and Pro Biotic Capsules - DS
10 X 10 Caps
115.00

Page 22

<!-- page 24 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Healers Lab (Unit-II)
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
2 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
3 510
Diclofenac Gel IP
25gms Tube
4.73
4 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
5 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
6 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
7 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
8 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
9 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
10 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
11 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
12 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
13 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
14 952
Ofloxacin Tablets - 200mg
50 X 10 Tabs
409.99
15 990
Metoprolol Succinate (Extended Release)
50 X 10 Tabs
196.90
16 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
17 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
18 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Hetero Healthcare Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 300
Tamoxifen Citrate Tablets IP - 10mg
50 X 10 Tabs
340.54
2 812
Entecavir Tablets IP - 0.5mg
3 X 10 Tabs /
75.40
3 980
Letrozole Tablets IP - 2.5mg
50 X 10 Tabs
260.00
4 982
Linezolid Tablets IP - 600mg
10 X 10 Tabs
398.90
5 998
Imatinib Mesylate Tablets IP - 400mg
10 X 10 Tabs
1,249.85
6 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Himalaya Life Line (India) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 342
Povidone Iodine Solution IP - 5% W/V
500ml Bottle
58.50
2 454
Povidone Iodine Cleaning Solution USP 500ml Bottle
107.00

Page 23

<!-- page 25 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Hindustan Laboratories Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 5
Co-Trimoxazole Tablets IP
10 X 10 Tabs
70.20
2 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
3 18
Vitamin B Complex Tablets Prophylactic
50 X 10 Tabs
59.59
4 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
5 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
6 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00
7 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
8 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
9 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
10 169
Glipizide Tablets IP - 5mg
50 X 10 Tabs
86.15
11 199
Surgical Spirit IP - 500ml
500ml Bottle
51.90
12 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
13 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
14 331
Polyvitamin Tablets Prophylactic NFI
50 X 10 Tabs
167.40
15 342
Povidone Iodine Solution IP - 5% W/V
500ml Bottle
58.50
16 387
Domperidone Tablets IP - 10mg
50 X 10 Tabs
67.28
17 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
18 454
Povidone Iodine Cleaning Solution USP 500ml Bottle
107.00
19 466
Multivitamin Drops
15ml Glass /
8.39
20 497
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
64.00
21 510
Diclofenac Gel IP
25gms Tube
4.73
22 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
23 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
24 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
25 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
26 723
Aspirin Gasto-Resistant Tablets IP 50 X 10 Tabs
154.99
27 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
28 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
29 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
30 836
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
47.20
31 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
32 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
33 1008
IFA - WIFS Tablets (Blue)
50 X 15 Tabs
142.00
34 1032
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
54.95
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Horizon Bioceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90

Page 24

<!-- page 26 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Horizon Bioceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------2 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
3 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
4 794
Misoprostol Tablets IP - 200mcg
50 X 10 Tabs
474.00
5 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
6 952
Ofloxacin Tablets - 200mg
50 X 10 Tabs
409.99
7 953
Ofloxacin Tablets IP - 400mg
10 X 10 Tabs
132.00
8 1080
Tadalafil Tablets - 20mg
50 X 10 Tabs
394.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Indian Immunologicals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 724
Rabies Vaccine Human (Cell Culture) IP
1ml Vial with
238.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Infunex Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 562
Sodium Chloride Injection IP - 0.9gm
500ml FFS/BFS
15.30
2 567
Compound Sodium Lactate Injection IP
500ml FFS/BFS
15.65
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Jodas Expoim Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
2 722
Gadobutorol Injection - 1.0 mmol/ml
10ml Vial /
924.95
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Johnson and Smith Co
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 70
Lysol IP (Cresol with Soap Solution)
5 Ltrs Plastic
830.90
2 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00

Page 25

<!-- page 27 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Johnson and Smith Co
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------3 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
4 377
Gamma Benzene Hexachloride Application
100ml Plastic
19.71
5 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
6 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
7 571
Liquid Paraffin IP (Heavy) - 500ml
500ml Bottle
118.18
8 576
Compound Benzoic Acid Ointment IP
15gms Tube
6.94
9 834
Liquid Paraffin IP - 60ml Bottle
60ml Plastic
15.41
10 837
Calcium Carbonate and Vitamin D3 Tablets 10 X 10 Tabs
22.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Khandelwal Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 300
Tamoxifen Citrate Tablets IP - 10mg
50 X 10 Tabs
340.54
2 597
Etoposide Concentrate Injection IP 5ml Vial
88.00
3 980
Letrozole Tablets IP - 2.5mg
50 X 10 Tabs
260.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Kniss Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 3
Paracetamol Paediatric Syrup IP
60ml PET/Glass
7.97
3 18
Vitamin B Complex Tablets Prophylactic
50 X 10 Tabs
59.59
4 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
5 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
6 229
Cephalexin Capsules IP - 250mg
10 X 10 Caps
167.69
7 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
8 331
Polyvitamin Tablets Prophylactic NFI
50 X 10 Tabs
167.40
9 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
10 776
Cefixime Tablets IP - 400mg
10 X 10 Tabs
497.84
11 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Krishna Pharma
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
-------------------------------------------------------------------------------------

Page 26

<!-- page 28 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Krishna Pharma
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 70
Lysol IP (Cresol with Soap Solution)
5 Ltrs Plastic
830.90
2 199
Surgical Spirit IP - 500ml
500ml Bottle
51.90
3 377
Gamma Benzene Hexachloride Application
100ml Plastic
19.71
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Life Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 159
Ranitidine Hydrochloride Injection IP 2ml Ampoule
1.75
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Linux Life Sciences Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 110
Propranolol Tablets IP - 40mg
50 X 10 Tabs
90.90
2 189
Amitriptyline Tablets IP - 25mg
50 X 10 Tabs
95.95
3 302
Trihexyphenidyl Hydrochloride Tablets IP 50 X 10 Tabs
54.54
4 747
Clonazepam Tablets IP - 0.5mg
50 X 10 Tabs
87.70
5 800
Rabeprazole Tablets IP - 20mg
50 X 10 Tabs
394.00
6 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
7 896
Amitriptyline Tablets IP - 10mg
50 X 10 Tabs
107.00
8 1005
Quetiapine Tablets IP - 50mg
50 X 10 Tabs
176.75
9 1020
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
155.00
10 1061
Escitalopram Tablets IP - 10mg
50 X 10 Tabs
155.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Lupin Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 1026
S(-) Metoprolol Succinate Extended
50 X 10 Tabs
1,244.00
2 1027
S(-) Metoprolol Succinate Extended
50 X 10 Tabs
1,888.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 27

<!-- page 29 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.MJ Biopharma Private Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 322
Human Insulin Soluble (Neutral) IP - 40
10ml Vial
81.80
2 749
Meropenem Injection IP - 500mg
Vial
31.69
3 816
Biphasic Isophane Insulin Injection IP
10ml Vial
82.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Maan Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 3
Paracetamol Paediatric Syrup IP
60ml PET/Glass
7.97
3 37
Ampicillin Sodium Injection IP - 500mg
Vial
6.82
4 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
5 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
6 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
7 749
Meropenem Injection IP - 500mg
Vial
31.69
8 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
9 778
Cefoperazone and Sulbactum for Injection Vial
15.40
10 798
Piperacillin and Tazobactum Injection IP Vial
43.21
11 818
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
444.50
12 819
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
371.50
13 820
Amoxycillin and Potassium Clavulanate
Vial
22.95
14 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
15 984
Pantoprazole For Injection - 40mg
Vial
4.93
16 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
17 1059
Cefotaxime Sodium Injection - 500mg
Vial
9.08
18 1060
Ceftriaxone Injection IP - 500mg
Vial
9.30
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Macleods Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 591
Acenocoumarol Tablets IP (Nicoumalone) - 50 X 10 Tabs
290.45
2 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
3 749
Meropenem Injection IP - 500mg
Vial
31.69
4 798
Piperacillin and Tazobactum Injection IP Vial
43.21
5 818
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
444.50
6 819
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
371.50
7 937
Levothyroxine Tablets IP - 100mcg
Plastic/Amber
31.15
8 939
Levothyroxine Tablets IP - 50mcg
Plastic/Amber
32.10
9 952
Ofloxacin Tablets - 200mg
50 X 10 Tabs
409.99

Page 28

<!-- page 30 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Macleods Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------10 1007
Tranexamic Acid Tablets IP - 500mg
10 X 10 Tabs
309.00
11 1033
Dapagliflozin Tablets - 10mg
50 X 10 Tabs
228.89
12 1063
Formeterol and Budesonide Rotacap
30 Capsules
22.30
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Macsur Pharmaa India Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 997
Clobazam Tablets IP - 5mg
50 X 10 Tabs
195.00
2 1019
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
105.00
3 1020
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
155.00
4 1038
Sodium Valproate and Valproic Acid
10 X 10 Tabs
113.10
5 1063
Formeterol and Budesonide Rotacap
30 Capsules
22.30
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Mahendra Labs Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 179
Carbamazepine Tablets IP - 200mg
50 X 10 Tabs
453.90
2 187
Chlorpromazine Hydrochloride Tablets IP
50 X 10 Tabs
446.50
3 188
Imipramine Tablets IP - 25mg
50 X 10 Tabs
188.10
4 286
Lithium Carbonate Tablets IP - 300mg
10 X 10 Tabs
154.13
5 527
Chlorpromazine Hydrochloride Tablets IP
50 X 10 Tabs
326.14
6 529
Risperidone Tablets IP - 2mg
50 X 10 Tabs
79.80
7 1061
Escitalopram Tablets IP - 10mg
50 X 10 Tabs
155.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Mankind Pharma Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
2 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
3 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
4 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
5 751
Ondansetron Injection IP - 2mg/ml
2ml Ampoule
1.27
6 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
7 757
Tacrolimus Capsules IP - 1mg
50 X 10 Caps
1,745.00

Page 29

<!-- page 31 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Mankind Pharma Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------8 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
9 838
Tacrolimus Capsules IP - 0.5mg
50 X 10 Caps
1,010.00
10 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
11 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
12 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
13 902
Azithromycin Oral Suspension IP 30ml HDPE
25.86
14 922
Drotaverine Hydrochloride Tablets IP 50 X 10 Tabs
244.99
15 952
Ofloxacin Tablets - 200mg
50 X 10 Tabs
409.99
16 953
Ofloxacin Tablets IP - 400mg
10 X 10 Tabs
132.00
17 954
Ondansetron Oral Solution IP - 2mg/5ml
30ml PET/Glass
10.46
18 986
Tramadol Hydrochloride Injection 2ml Ampoule
2.48
19 1006
Tranaxemic Acid Injection IP - 500mg/5ml 5ml Vial /
6.66
20 1013
Gabapentin and Methylcobalamin Tablets
10 X 10 Tabs
119.84
21 1034
Dextromethorphan Hydrobromide and
60ml PET/Glass
10.20
22 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Marc Laboratories Ltd (Unit-III)
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
2 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
3 224
Amikacin Sulphate Injection IP - 50mg/ml 2ml Vial /
4.57
4 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
5 229
Cephalexin Capsules IP - 250mg
10 X 10 Caps
167.69
6 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
7 495
Diclofenac Sodium Injection IP - 25mg/ml 3ml Ampoule
1.90
8 749
Meropenem Injection IP - 500mg
Vial
31.69
9 751
Ondansetron Injection IP - 2mg/ml
2ml Ampoule
1.27
10 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
11 778
Cefoperazone and Sulbactum for Injection Vial
15.40
12 798
Piperacillin and Tazobactum Injection IP Vial
43.21
13 818
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
444.50
14 820
Amoxycillin and Potassium Clavulanate
Vial
22.95
15 825
Iron Sucrose Injection USP
5ml Amber
6.85
16 897
Amoxycillin Capsules IP - 500mg
10 X 10 Caps
151.66
17 984
Pantoprazole For Injection - 40mg
Vial
4.93
18 988
Vancomycin Intravenous Infusion IP Vial
33.33
19 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 30

<!-- page 32 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Marc Lifesciences Sikkim
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Mascot Health Series Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
2 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
3 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
4 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
5 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
6 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
7 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
8 872
Gabapentin Capsules IP - 100mg
10 X 10 Caps
46.99
9 982
Linezolid Tablets IP - 600mg
10 X 10 Tabs
398.90
10 992
Pregabalin Capsules IP - 75mg
50 X 10 Caps
244.40
11 1000
Mycophenolate Sodium Tablets - 360mg
10 X 10 Tabs
488.88
12 1005
Quetiapine Tablets IP - 50mg
50 X 10 Tabs
176.75
13 1016
Ticagrelor Tablets IP - 90mg
10 X 14 Tabs
339.99
14 1023
Linagliptin Tablets - 5mg
50 X 10 Tabs
288.90
15 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
16 1033
Dapagliflozin Tablets - 10mg
50 X 10 Tabs
228.89
17 1070
Linagliptin + Metformin Tablets
10 X 10 Tabs
68.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Medico Remedies Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 5
Co-Trimoxazole Tablets IP
10 X 10 Tabs
70.20
2 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
3 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
4 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
5 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
6 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
7 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
8 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 31

<!-- page 33 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Medioint Lifescience Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 124
Lignocaine Hydrochloride Gel IP - 2% W/V 30gms Tube
7.18
2 510
Diclofenac Gel IP
25gms Tube
4.73
3 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
4 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Medipol Pharmaceuticals India Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 70
Lysol IP (Cresol with Soap Solution)
5 Ltrs Plastic
830.90
2 77
Dexamethasone Tablets IP - 0.5mg
50 X 10 Tabs
72.48
3 110
Propranolol Tablets IP - 40mg
50 X 10 Tabs
90.90
4 180
Phenytoin Sodium Tablets IP - 100mg
HDPE Bottle of
26.84
5 182
Sodium Valporate Gastro Resistant
50 X 10 Tabs
368.90
6 187
Chlorpromazine Hydrochloride Tablets IP
50 X 10 Tabs
446.50
7 188
Imipramine Tablets IP - 25mg
50 X 10 Tabs
188.10
8 199
Surgical Spirit IP - 500ml
500ml Bottle
51.90
9 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
10 390
Bisacodyl Tablets IP - 5mg
50 X 10 Tabs
142.80
11 448
Diethylcarbamazine Citrate Tablets IP 50 X 10 Tabs
117.00
12 464
Alprazolam Tablets IP - 0.5mg
50 X 10 Tabs
70.70
13 493
Zinc Cream IP - 32%
25gms Tube
7.25
14 527
Chlorpromazine Hydrochloride Tablets IP
50 X 10 Tabs
326.14
15 529
Risperidone Tablets IP - 2mg
50 X 10 Tabs
79.80
16 574
Liquid Antacid
60ml PET/Glass
9.09
17 578
Potassium Chloride Oral Solution USP 200ml Amber
20.67
18 757
Tacrolimus Capsules IP - 1mg
50 X 10 Caps
1,745.00
19 767
Dinoprostone Gel
Pre-Filled
96.96
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Medopharm
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
2 179
Carbamazepine Tablets IP - 200mg
50 X 10 Tabs
453.90
3 180
Phenytoin Sodium Tablets IP - 100mg
HDPE Bottle of
26.84
4 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
5 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50

Page 32

<!-- page 34 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Medopharm Private Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 52
Cloxacillin Capsules IP - 250mg
10 X 10 Caps
133.04
2 58
Phenoxy Methyl Penicillin Potassium
10 X 10 Tabs
193.20
3 592
Dispersible Amoxycillin Tablets IP 50 X 10 Tabs
284.15
4 771
Dispersible Amoxycillin and Potassium
10 X 10 Tabs
184.00
5 818
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
444.50
6 819
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
371.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Medsource Ozone Biomedicals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 209
Anti A Blood Grouping Serum IP
10ml Vial
55.69
2 210
Anti B Blood Grouping Serum IP
10ml Vial
56.67
3 805
Anti AB Blood Grouping Serum - 10ml Vial 10ml Vial
74.85
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Micron Pharmaceuticals
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 21
Diazepam Tablets IP - 5mg
50 X 10 Tabs
98.14
2 286
Lithium Carbonate Tablets IP - 300mg
10 X 10 Tabs
154.13
3 292
Azathioprine Tablets IP - 50mg
50 X 10 Tabs
395.00
4 302
Trihexyphenidyl Hydrochloride Tablets IP 50 X 10 Tabs
54.54
5 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
6 570
Pheniramine Maleate Syrup - 15mg/5ml
10ml Bottle
8.85
7 571
Liquid Paraffin IP (Heavy) - 500ml
500ml Bottle
118.18
8 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
9 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
10 776
Cefixime Tablets IP - 400mg
10 X 10 Tabs
497.84
11 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
12 897
Amoxycillin Capsules IP - 500mg
10 X 10 Caps
151.66
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 33

<!-- page 35 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Micropure Parenterals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
2 224
Amikacin Sulphate Injection IP - 50mg/ml 2ml Vial /
4.57
3 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Nandani Medical Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 12
Theophylline and Etofylline Injection
2ml Ampoule
2.39
2 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
3 84
Menadione Sodium Bisulphate Injection IP 1ml Ampoule
2.23
4 141
Vitamin B Complex Injection NFI 1979
10ml Vial
6.90
5 157
Pentazocine Lactate Injection IP 1ml Ampoule
5.72
6 159
Ranitidine Hydrochloride Injection IP 2ml Ampoule
1.75
7 174
Oxytocin Injection IP - 5 IU/ml
1ml Ampoule
3.85
8 176
Adrenaline Injection IP - 1mg/ml
1ml Ampoule
2.81
9 177
Atropine Sulphate Injection IP 1ml Ampoule
1.96
10 183
Diazepam Injection IP - 5mg/ml
2ml Ampoule
3.30
11 219
Sodium Bicarbonate Injection IP - 7.5%
10ml Ampoule
6.15
12 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
13 310
Lignocaine Hydrochloride Injection IP 30ml Vial
7.59
14 351
Paracetamol Injection - 150mg/ml
2ml Ampoule
2.40
15 495
Diclofenac Sodium Injection IP - 25mg/ml 3ml Ampoule
1.90
16 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
17 511
Atracurium Besylate Injection IP 2.5ml Ampoule
15.95
18 519
Ceftrioxone Injection IP - 250mg/Vial
Vial
6.10
19 751
Ondansetron Injection IP - 2mg/ml
2ml Ampoule
1.27
20 778
Cefoperazone and Sulbactum for Injection Vial
15.40
21 825
Iron Sucrose Injection USP
5ml Amber
6.85
22 986
Tramadol Hydrochloride Injection 2ml Ampoule
2.48
23 1006
Tranaxemic Acid Injection IP - 500mg/5ml 5ml Vial /
6.66
24 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
25 1059
Cefotaxime Sodium Injection - 500mg
Vial
9.08
26 1060
Ceftriaxone Injection IP - 500mg
Vial
9.30
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Nanz Medscience Pharma (P) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 342
Povidone Iodine Solution IP - 5% W/V
500ml Bottle
58.50

Page 34

<!-- page 36 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Nanz Medscience Pharma (P) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------2 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
3 454
Povidone Iodine Cleaning Solution USP 500ml Bottle
107.00
4 510
Diclofenac Gel IP
25gms Tube
4.73
5 576
Compound Benzoic Acid Ointment IP
15gms Tube
6.94
6 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Naprod Life Sciences Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 597
Etoposide Concentrate Injection IP 5ml Vial
88.00
2 714
Propofol Injection IP - 10mg/ml
10ml Vial
18.20
3 774
Carboplatin Injection IP - 10mg/ml
45ml Vial
2,190.00
4 797
Paclitaxel Injection IP - 100mg/16.7ml
Vial
148.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Navron Pharma Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
2 79
Prednisolone Tablets IP - 5mg
50 X 10 Tabs
112.29
3 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
4 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
5 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
6 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Nem Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 77
Dexamethasone Tablets IP - 0.5mg
50 X 10 Tabs
72.48
2 79
Prednisolone Tablets IP - 5mg
50 X 10 Tabs
112.29
3 95
Digoxin Tablets IP - 0.25mg
50 X 10 Tabs
155.00
4 106
Frusemide Tablets IP - 40mg
50 X 10 Tabs
119.95
5 107
Methyldopa Tablets IP - 250mg
10 X 10 Tabs
250.00
6 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
7 183
Diazepam Injection IP - 5mg/ml
2ml Ampoule
3.30

Page 35

<!-- page 37 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Nem Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------8 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
9 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
10 510
Diclofenac Gel IP
25gms Tube
4.73
11 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
12 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Nest Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 24
Glibenclamide Tablets IP - 5mg
50 X 10 Tabs
46.80
3 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
4 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
5 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
6 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
7 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Nestor Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
2 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
3 836
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
47.20
4 1008
IFA - WIFS Tablets (Blue)
50 X 15 Tabs
142.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Nexgenrx Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
2 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
3 871
Acetylcysteine Tablets BP - 600mg
10 X 10 Tabs
166.87
4 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
5 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
6 1055
Betahistine Hydrochloride Tablets IP 50 X 10 Tabs
130.45

Page 36

<!-- page 38 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Nixi Laboratories Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 176
Adrenaline Injection IP - 1mg/ml
1ml Ampoule
2.81
2 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
3 988
Vancomycin Intravenous Infusion IP Vial
33.33
4 1006
Tranaxemic Acid Injection IP - 500mg/5ml 5ml Vial /
6.66
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Orchid Medlife Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 169
Glipizide Tablets IP - 5mg
50 X 10 Tabs
86.15
2 390
Bisacodyl Tablets IP - 5mg
50 X 10 Tabs
142.80
3 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
4 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
5 1033
Dapagliflozin Tablets - 10mg
50 X 10 Tabs
228.89
6 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
7 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Ornate Labs Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 79
Prednisolone Tablets IP - 5mg
50 X 10 Tabs
112.29
2 190
Haloperidol Tablets IP - 1.5mg
50 X 10 Tabs
68.00
3 191
Haloperidol Tablets IP - 5mg
50 X 10 Tabs
92.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Pentagon Labs Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 42
Ciprofloxacin Injection IP - 200mg
100ml FFS/BFS
8.90
2 140
Plasma Expander Infusion
500ml Bottle
178.00
3 172
Metronidazole Injection IP - 5mg/ml
100ml FFS/BFS
8.24
4 340
Mannitol Injection IP - 20% W/V
350ml Bottle
59.90
5 562
Sodium Chloride Injection IP - 0.9gm
500ml FFS/BFS
15.30

Page 37

<!-- page 39 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Pentagon Labs Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------6 563
Sodium Chloride and Dextrose Injection
500ml FFS/BFS
16.83
7 567
Compound Sodium Lactate Injection IP
500ml FFS/BFS
15.65
8 568
Dextrose Injection IP - 5%
500ml FFS/BFS
17.33
9 572
Dextrose Injection IP - 10%
500ml FFS/BFS
23.05
10 706
Dextrose Injection IP - 25%
100ml FFS / BFS
11.40
11 828
Sodium Chloride Injection BP - 3gm/100ml 100ml FFS/BFS
13.21
12 853
Sodium Chloride Injection IP - 0.9% W/V
100ml FFS/BFS
8.55
13 994
Paracetamol Infusion IP - 1000mg/100ml
100ml FFS/BFS
14.75
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Pharose Remedies Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
2 24
Glibenclamide Tablets IP - 5mg
50 X 10 Tabs
46.80
3 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
4 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
5 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
6 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
7 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
8 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
9 259
Enalapril Maleate Tablets IP - 2.5mg
50 X 10 Tabs
86.85
10 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
11 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
12 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
13 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
14 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
15 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
16 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
17 1000
Mycophenolate Sodium Tablets - 360mg
10 X 10 Tabs
488.88
18 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Pilco Healtcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 493
Zinc Cream IP - 32%
25gms Tube
7.25
2 510
Diclofenac Gel IP
25gms Tube
4.73
3 576
Compound Benzoic Acid Ointment IP
15gms Tube
6.94
4 925
Fusidic Acid Cream IP - 2% W/W
10gms Tube
14.61

Page 38

<!-- page 40 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Pondchy Lab
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 70
Lysol IP (Cresol with Soap Solution)
5 Ltrs Plastic
830.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Pulse Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
2 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
3 987
Ursodeoxycholic Acid Tablets IP - 150mg
50 X 10 Tabs
1,516.63
4 990
Metoprolol Succinate (Extended Release)
50 X 10 Tabs
196.90
5 1023
Linagliptin Tablets - 5mg
50 X 10 Tabs
288.90
6 1028
Tamsulosin Hydrochloride Prolonged
50 X 10 Caps
361.14
7 1033
Dapagliflozin Tablets - 10mg
50 X 10 Tabs
228.89
8 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
9 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Puniska Injectables Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 42
Ciprofloxacin Injection IP - 200mg
100ml FFS/BFS
8.90
2 172
Metronidazole Injection IP - 5mg/ml
100ml FFS/BFS
8.24
3 562
Sodium Chloride Injection IP - 0.9gm
500ml FFS/BFS
15.30
4 563
Sodium Chloride and Dextrose Injection
500ml FFS/BFS
16.83
5 564
Multiple Electrolytes and Dextrose
500ml FFS/BFS
23.50
6 567
Compound Sodium Lactate Injection IP
500ml FFS/BFS
15.65
7 568
Dextrose Injection IP - 5%
500ml FFS/BFS
17.33
8 572
Dextrose Injection IP - 10%
500ml FFS/BFS
23.05
9 706
Dextrose Injection IP - 25%
100ml FFS / BFS
11.40
10 853
Sodium Chloride Injection IP - 0.9% W/V
100ml FFS/BFS
8.55
11 994
Paracetamol Infusion IP - 1000mg/100ml
100ml FFS/BFS
14.75
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 39

<!-- page 41 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Quasar Labs Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 189
Amitriptyline Tablets IP - 25mg
50 X 10 Tabs
95.95
2 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
3 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
4 747
Clonazepam Tablets IP - 0.5mg
50 X 10 Tabs
87.70
5 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
6 796
Olanzapine Tablets IP - 5mg
50 X 10 Tabs
104.75
7 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
8 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
9 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
10 867
Paracetamol Tablets IP - 650mg
10 X 10 Tabs
39.49
11 987
Ursodeoxycholic Acid Tablets IP - 150mg
50 X 10 Tabs
1,516.63
12 990
Metoprolol Succinate (Extended Release)
50 X 10 Tabs
196.90
13 997
Clobazam Tablets IP - 5mg
50 X 10 Tabs
195.00
14 1005
Quetiapine Tablets IP - 50mg
50 X 10 Tabs
176.75
15 1019
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
105.00
16 1020
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
155.00
17 1025
Olanzapine Tablets IP - 2.5mg
50 X 10 Tabs
105.00
18 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
19 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
20 1038
Sodium Valproate and Valproic Acid
10 X 10 Tabs
113.10
21 1055
Betahistine Hydrochloride Tablets IP 50 X 10 Tabs
130.45
22 1061
Escitalopram Tablets IP - 10mg
50 X 10 Tabs
155.00
23 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.RPG Life Sciences Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 482
Cyclosporine Capsules IP - 50mg
10 X 5 Caps
380.20
2 1000
Mycophenolate Sodium Tablets - 360mg
10 X 10 Tabs
488.88
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Raman and Weil Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 342
Povidone Iodine Solution IP - 5% W/V
500ml Bottle
58.50
2 454
Povidone Iodine Cleaning Solution USP 500ml Bottle
107.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 40

<!-- page 42 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Ray Life Sciences Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 75
Dexamethasone Sodium Phosphate Injection 2ml Vial /
2.10
2 159
Ranitidine Hydrochloride Injection IP 2ml Ampoule
1.75
3 310
Lignocaine Hydrochloride Injection IP 30ml Vial
7.59
4 345
Promethazine Hydrochloride Injection IP
2ml Ampoule
2.56
5 351
Paracetamol Injection - 150mg/ml
2ml Ampoule
2.40
6 905
Betamethasone Injection IP - 4mg/ml
1ml Ampoule
4.33
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Regent Ajanta Biotech
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
2 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
3 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
4 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
5 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
6 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
7 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
8 826
Labetalol Tablets IP - 100mg
50 X 10 Tabs
496.90
9 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
10 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
11 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
12 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Relief Biotech Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
2 16
Calcium Lactate Tablets IP - 300mg
10 X 10 Tabs
15.38
3 18
Vitamin B Complex Tablets Prophylactic
50 X 10 Tabs
59.59
4 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
5 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
6 79
Prednisolone Tablets IP - 5mg
50 X 10 Tabs
112.29
7 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00
8 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
9 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
10 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
11 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
12 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38

Page 41

<!-- page 43 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Relief Biotech Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------13 169
Glipizide Tablets IP - 5mg
50 X 10 Tabs
86.15
14 179
Carbamazepine Tablets IP - 200mg
50 X 10 Tabs
453.90
15 193
Chlorpheniramine Maleate Tablets IP 50 X 10 Tabs
38.55
16 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
17 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
18 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
19 387
Domperidone Tablets IP - 10mg
50 X 10 Tabs
67.28
20 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
21 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
22 497
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
64.00
23 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
24 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
25 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
26 728
Zinc Sulphate Tablets BP
50 X 10 Tabs
84.10
27 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
28 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
29 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
30 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
31 837
Calcium Carbonate and Vitamin D3 Tablets 10 X 10 Tabs
22.90
32 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
33 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
34 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
35 867
Paracetamol Tablets IP - 650mg
10 X 10 Tabs
39.49
36 987
Ursodeoxycholic Acid Tablets IP - 150mg
50 X 10 Tabs
1,516.63
37 1007
Tranexamic Acid Tablets IP - 500mg
10 X 10 Tabs
309.00
38 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
39 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Renowed Life Sciences
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
2 982
Linezolid Tablets IP - 600mg
10 X 10 Tabs
398.90
3 1028
Tamsulosin Hydrochloride Prolonged
50 X 10 Caps
361.14
4 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 42

<!-- page 44 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Rivpra Formulation Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
2 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
3 574
Liquid Antacid
60ml PET/Glass
9.09
4 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
5 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
6 818
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
444.50
7 819
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
371.50
8 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
9 979
Lactulose Solution USP
200ml PET/Glass
69.49
10 1000
Mycophenolate Sodium Tablets - 360mg
10 X 10 Tabs
488.88
11 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Saar Biotech Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 479
Albendazole Oral Suspension IP 10ml Amber
8.64
2 510
Diclofenac Gel IP
25gms Tube
4.73
3 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
4 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
5 1085
Vitamin D3 Drops
15ml HDPE
6.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Safecon Lifesciences
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 531
Chlordiazepoxide Tablets IP - 10mg
50 X 10 Tabs
171.00
2 871
Acetylcysteine Tablets BP - 600mg
10 X 10 Tabs
166.87
3 876
Sitagliptin Phosphate Tablets IP - 100mg 50 X 10 Tabs
415.00
4 1061
Escitalopram Tablets IP - 10mg
50 X 10 Tabs
155.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Sai Mirra Innopharm Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
2 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15

Page 43

<!-- page 45 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Sai Mirra Innopharm Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------3 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
4 812
Entecavir Tablets IP - 0.5mg
3 X 10 Tabs /
75.40
5 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Sai Parenterals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
2 229
Cephalexin Capsules IP - 250mg
10 X 10 Caps
167.69
3 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
4 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
5 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Saintlife Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 24
Glibenclamide Tablets IP - 5mg
50 X 10 Tabs
46.80
2 106
Frusemide Tablets IP - 40mg
50 X 10 Tabs
119.95
3 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
4 169
Glipizide Tablets IP - 5mg
50 X 10 Tabs
86.15
5 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
6 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
7 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
8 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
9 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
10 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
11 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
12 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
13 796
Olanzapine Tablets IP - 5mg
50 X 10 Tabs
104.75
14 842
Chlorthalidone Tablets IP - 6.25mg
50 X 10 Tabs
114.15
15 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 44

<!-- page 46 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Samarth Life Sciences Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
2 94
Sterile Dopamine Concentrate IP 5ml Ampoule
8.70
3 703
Amiodarone Sterile Concentrate Injection 3ml Ampoule
9.75
4 797
Paclitaxel Injection IP - 100mg/16.7ml
Vial
148.50
5 1006
Tranaxemic Acid Injection IP - 500mg/5ml 5ml Vial /
6.66
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Sanolet Lifecare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
2 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
3 519
Ceftrioxone Injection IP - 250mg/Vial
Vial
6.10
4 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
5 1060
Ceftriaxone Injection IP - 500mg
Vial
9.30
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Sara Pharmaceuticals
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 17
Cyanocobalamin Injection IP - 1000mcg
1ml Ampoule
2.22
2 46
Gentamicin Injection IP - 80mg/2ml
2ml Ampoule
2.72
3 75
Dexamethasone Sodium Phosphate Injection 2ml Vial /
2.10
4 88
Aminophylline Injection IP - 25mg/ml
10ml Ampoule
6.32
5 94
Sterile Dopamine Concentrate IP 5ml Ampoule
8.70
6 112
Frusemide Injection IP - 10mg/ml (IM/IV
2ml Ampoule
1.48
7 158
Metoclopramide Injection IP - 5mg/ml (IM 2ml Ampoule
2.21
8 159
Ranitidine Hydrochloride Injection IP 2ml Ampoule
1.75
9 177
Atropine Sulphate Injection IP 1ml Ampoule
1.96
10 196
Pheniramine Maleate Injection IP 2ml Ampoule
1.89
11 219
Sodium Bicarbonate Injection IP - 7.5%
10ml Ampoule
6.15
12 310
Lignocaine Hydrochloride Injection IP 30ml Vial
7.59
13 345
Promethazine Hydrochloride Injection IP
2ml Ampoule
2.56
14 351
Paracetamol Injection - 150mg/ml
2ml Ampoule
2.40
15 352
Phenytoin Sodium Injection USP 2ml Ampoule
3.34
16 373
Ephedrine Hydrochloride Injection BP 1ml Ampoule
16.10
17 458
Dicyclomine Hydrochloride Injection IP - 2ml Ampoule
2.12
18 495
Diclofenac Sodium Injection IP - 25mg/ml 3ml Ampoule
1.90
19 581
Magnesium Sulphate Injection IP 2ml Ampoule
2.60

Page 45

<!-- page 47 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Sarthak Biotech Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
3 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
4 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
5 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
6 979
Lactulose Solution USP
200ml PET/Glass
69.49
7 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
8 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Serum Institute of India Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 839
Adsorbed Diphtheria and Tetanus Vaccine
10 Doses Vial
99.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Shaimil Laboratories
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
2 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
3 752
Ondansetron Tablets IP - 4mg
50 X 10 Tabs
90.00
4 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
5 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
6 952
Ofloxacin Tablets - 200mg
50 X 10 Tabs
409.99
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Shamshree Life Sciences Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
2 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
3 519
Ceftrioxone Injection IP - 250mg/Vial
Vial
6.10
4 749
Meropenem Injection IP - 500mg
Vial
31.69

Page 46

<!-- page 48 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Shamshree Life Sciences Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------5 778
Cefoperazone and Sulbactum for Injection Vial
15.40
6 798
Piperacillin and Tazobactum Injection IP Vial
43.21
7 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
8 1059
Cefotaxime Sodium Injection - 500mg
Vial
9.08
9 1060
Ceftriaxone Injection IP - 500mg
Vial
9.30
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Shree Krishna Keshav Laboratories Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 42
Ciprofloxacin Injection IP - 200mg
100ml FFS/BFS
8.90
2 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
3 172
Metronidazole Injection IP - 5mg/ml
100ml FFS/BFS
8.24
4 244
Peritonial Dialysis Solution IP
1000ml Bottle
39.50
5 514
Iohexol Injection USP - 350mg/ml
50ml Glass /
484.29
6 562
Sodium Chloride Injection IP - 0.9gm
500ml FFS/BFS
15.30
7 567
Compound Sodium Lactate Injection IP
500ml FFS/BFS
15.65
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Sotac Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Sotac Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 47

<!-- page 49 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Spectrum Formulation Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 191
Haloperidol Tablets IP - 5mg
50 X 10 Tabs
92.50
2 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
3 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
4 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
5 842
Chlorthalidone Tablets IP - 6.25mg
50 X 10 Tabs
114.15
6 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
7 871
Acetylcysteine Tablets BP - 600mg
10 X 10 Tabs
166.87
8 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
9 1019
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
105.00
10 1038
Sodium Valproate and Valproic Acid
10 X 10 Tabs
113.10
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Standard Pharmaceuticals Limited
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
3 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
4 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00
5 160
Ranitidine Hydrochloride Tablets IP 50 X 10 Tabs
213.50
6 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
7 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
8 497
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
64.00
9 592
Dispersible Amoxycillin Tablets IP 50 X 10 Tabs
284.15
10 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
11 819
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
371.50
12 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
13 897
Amoxycillin Capsules IP - 500mg
10 X 10 Caps
151.66
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Stanex Drugs and Chemicals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 48

<!-- page 50 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Stivaph Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 193
Chlorpheniramine Maleate Tablets IP 50 X 10 Tabs
38.55
2 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
3 574
Liquid Antacid
60ml PET/Glass
9.09
4 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
5 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
6 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
7 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
8 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
9 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
10 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Sudarshan Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
2 16
Calcium Lactate Tablets IP - 300mg
10 X 10 Tabs
15.38
3 55
Erythromycin Stearate Tablets IP - 250mg 10 X 10 Tabs
242.37
4 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
5 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00
6 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
7 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
8 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
9 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
10 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
11 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
12 387
Domperidone Tablets IP - 10mg
50 X 10 Tabs
67.28
13 497
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
64.00
14 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
15 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
16 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
17 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
18 836
Ferrous Sulphate and Folic Acid Tablets
50 X 10 Tabs
47.20
19 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
20 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
21 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
22 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
23 946
Metronidazole Tablets IP - 400mg
10 X 10 Tabs
65.00
24 952
Ofloxacin Tablets - 200mg
50 X 10 Tabs
409.99
25 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 49

<!-- page 51 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Super Formulations (P) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 5
Co-Trimoxazole Tablets IP
10 X 10 Tabs
70.20
2 24
Glibenclamide Tablets IP - 5mg
50 X 10 Tabs
46.80
3 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
4 91
Salbutamol Sulphate Tablets IP - 4mg
50 X 10 Tabs
55.00
5 104
Atenolol Tablets IP - 50mg
50 X 14 Tabs
97.50
6 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
7 149
Ascorbic Acid Tablet IP - 100mg
50 X 10 Tabs
63.63
8 160
Ranitidine Hydrochloride Tablets IP 50 X 10 Tabs
213.50
9 164
Dicyclomine Hydrochloride Tablets IP 10 X 10 Tabs
10.72
10 179
Carbamazepine Tablets IP - 200mg
50 X 10 Tabs
453.90
11 180
Phenytoin Sodium Tablets IP - 100mg
HDPE Bottle of
26.84
12 193
Chlorpheniramine Maleate Tablets IP 50 X 10 Tabs
38.55
13 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
14 259
Enalapril Maleate Tablets IP - 2.5mg
50 X 10 Tabs
86.85
15 376
Betamethasone Valerate Ointment IP 15gms Tube
7.18
16 442
Cetirizine Tablets IP - 10mg
50 X 10 Tabs
49.00
17 450
Chloroquine Phosphate Tablets IP - 250mg 10 X 10 Tabs
90.00
18 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
19 492
Cetrimide Cream IP - 0.5%
25gms Tube
5.90
20 510
Diclofenac Gel IP
25gms Tube
4.73
21 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
22 529
Risperidone Tablets IP - 2mg
50 X 10 Tabs
79.80
23 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
24 716
Co-Trimoxazole Tablets IP
50 X 10 Tabs
194.00
25 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
26 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
27 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
28 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
29 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
30 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Supermax Drugs and Pharmaceuticals (P) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
2 757
Tacrolimus Capsules IP - 1mg
50 X 10 Caps
1,745.00
3 812
Entecavir Tablets IP - 0.5mg
3 X 10 Tabs /
75.40
4 838
Tacrolimus Capsules IP - 0.5mg
50 X 10 Caps
1,010.00
5 1000
Mycophenolate Sodium Tablets - 360mg
10 X 10 Tabs
488.88
6 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00

Page 50

<!-- page 52 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Swiss Parenterals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 94
Sterile Dopamine Concentrate IP 5ml Ampoule
8.70
2 348
Bupivacaine Injection IP - 0.5% W/V
20ml Vial
12.24
3 352
Phenytoin Sodium Injection USP 2ml Ampoule
3.34
4 512
Bupivacaine Hydrochloride in Dextrose
4ml Ampoule
6.48
5 749
Meropenem Injection IP - 500mg
Vial
31.69
6 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
7 820
Amoxycillin and Potassium Clavulanate
Vial
22.95
8 825
Iron Sucrose Injection USP
5ml Amber
6.85
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Synmedic Laboratories
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 106
Frusemide Tablets IP - 40mg
50 X 10 Tabs
119.95
2 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
3 510
Diclofenac Gel IP
25gms Tube
4.73
4 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
5 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
6 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
7 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
8 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
9 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
10 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
11 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Synokem Pharmaceuticals Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
2 826
Labetalol Tablets IP - 100mg
50 X 10 Tabs
496.90
3 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
4 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
5 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
6 1083
Trypsin and Chymotrypsin Tablets 10 X 10 Tabs
41.35

Page 51

<!-- page 53 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Systochem Laboratories Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 26
Gentamycin Eye Drops IP - 0.3%
5ml HDPE
4.13
2 37
Ampicillin Sodium Injection IP - 500mg
Vial
6.82
3 46
Gentamicin Injection IP - 80mg/2ml
2ml Ampoule
2.72
4 75
Dexamethasone Sodium Phosphate Injection 2ml Vial /
2.10
5 76
Hydrocortisone Sodium Succinate
Vial
6.80
6 124
Lignocaine Hydrochloride Gel IP - 2% W/V 30gms Tube
7.18
7 174
Oxytocin Injection IP - 5 IU/ml
1ml Ampoule
3.85
8 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
9 351
Paracetamol Injection - 150mg/ml
2ml Ampoule
2.40
10 352
Phenytoin Sodium Injection USP 2ml Ampoule
3.34
11 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
12 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
13 511
Atracurium Besylate Injection IP 2.5ml Ampoule
15.95
14 523
Ciprofloxacin Eye Drops IP - 0.3% (Eye / 5ml HDPE
3.93
15 751
Ondansetron Injection IP - 2mg/ml
2ml Ampoule
1.27
16 820
Amoxycillin and Potassium Clavulanate
Vial
22.95
17 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
18 1006
Tranaxemic Acid Injection IP - 500mg/5ml 5ml Vial /
6.66
19 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.T Walkers Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
2 84
Menadione Sodium Bisulphate Injection IP 1ml Ampoule
2.23
3 176
Adrenaline Injection IP - 1mg/ml
1ml Ampoule
2.81
4 310
Lignocaine Hydrochloride Injection IP 30ml Vial
7.59
5 581
Magnesium Sulphate Injection IP 2ml Ampoule
2.60
6 600
Midazolam Injection IP - 1mg/ml
5ml Vial
8.14
7 825
Iron Sucrose Injection USP
5ml Amber
6.85
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Tablets (India) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 119
Neostigmine Injection IP - 0.5mg/ml
1ml Ampoule
3.19

Page 52

<!-- page 54 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Tablets (India) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------2 978
Probiotic Capsules
10 Capsules in
497.50
3 996
Ambroxol Hydrochloride and
10 X 10 Tabs
209.00
4 1024
Choline with Amino Acids and Vitamins
10 X 10 Tabs
550.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Tas Med India Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 95
Digoxin Tablets IP - 0.25mg
50 X 10 Tabs
155.00
2 189
Amitriptyline Tablets IP - 25mg
50 X 10 Tabs
95.95
3 191
Haloperidol Tablets IP - 5mg
50 X 10 Tabs
92.50
4 254
Indomethacin Capsules IP - 25mg
10 X 10 Caps
48.00
5 292
Azathioprine Tablets IP - 50mg
50 X 10 Tabs
395.00
6 302
Trihexyphenidyl Hydrochloride Tablets IP 50 X 10 Tabs
54.54
7 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
8 756
Losartan Potassium Tablets IP - 50mg
50 X 10 Tabs
190.65
9 796
Olanzapine Tablets IP - 5mg
50 X 10 Tabs
104.75
10 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
11 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
12 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
13 875
Sitagliptin Phosphate Tablets IP - 50mg
50 X 10 Tabs
288.50
14 896
Amitriptyline Tablets IP - 10mg
50 X 10 Tabs
107.00
15 987
Ursodeoxycholic Acid Tablets IP - 150mg
50 X 10 Tabs
1,516.63
16 1010
Gabapentin Tablets IP - 300mg
10 X 10 Tabs
87.87
17 1013
Gabapentin and Methylcobalamin Tablets
10 X 10 Tabs
119.84
18 1019
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
105.00
19 1020
Divalproex Extended Release Tablets IP - 10 X 10 Tabs
155.00
20 1025
Olanzapine Tablets IP - 2.5mg
50 X 10 Tabs
105.00
21 1028
Tamsulosin Hydrochloride Prolonged
50 X 10 Caps
361.14
22 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
23 1033
Dapagliflozin Tablets - 10mg
50 X 10 Tabs
228.89
24 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
25 1038
Sodium Valproate and Valproic Acid
10 X 10 Tabs
113.10
26 1061
Escitalopram Tablets IP - 10mg
50 X 10 Tabs
155.00
27 1062
Flunarizine Tablets - 10mg
50 X 10 Tabs
150.00
28 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 53

<!-- page 55 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Therdose Pharma Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 797
Paclitaxel Injection IP - 100mg/16.7ml
Vial
148.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Ultra Drugs Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
2 778
Cefoperazone and Sulbactum for Injection Vial
15.40
3 798
Piperacillin and Tazobactum Injection IP Vial
43.21
4 818
Amoxycillin and Potassium Clavulanate
10 X 10 Tabs
444.50
5 820
Amoxycillin and Potassium Clavulanate
Vial
22.95
6 988
Vancomycin Intravenous Infusion IP Vial
33.33
7 1006
Tranaxemic Acid Injection IP - 500mg/5ml 5ml Vial /
6.66
8 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Unicure (India) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 5
Co-Trimoxazole Tablets IP
10 X 10 Tabs
70.20
3 16
Calcium Lactate Tablets IP - 300mg
10 X 10 Tabs
15.38
4 22
Phenobarbitone Tablets IP - 30mg
50 X 10 Tabs
215.82
5 36
ORS Powder IP
Sachets/Pouches
2.16
6 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
7 53
Doxycycline Capsules IP - 100mg
50 X 10 Caps
429.15
8 55
Erythromycin Stearate Tablets IP - 250mg 10 X 10 Tabs
242.37
9 70
Lysol IP (Cresol with Soap Solution)
5 Ltrs Plastic
830.90
10 77
Dexamethasone Tablets IP - 0.5mg
50 X 10 Tabs
72.48
11 79
Prednisolone Tablets IP - 5mg
50 X 10 Tabs
112.29
12 90
Theophylline and Etofylline Prolonged
50 X 10 Tabs
148.45
13 95
Digoxin Tablets IP - 0.25mg
50 X 10 Tabs
155.00
14 101
Verapamil Hydrochloride Tablets IP 50 X 10 Tabs
210.00
15 106
Frusemide Tablets IP - 40mg
50 X 10 Tabs
119.95
16 107
Methyldopa Tablets IP - 250mg
10 X 10 Tabs
250.00
17 110
Propranolol Tablets IP - 40mg
50 X 10 Tabs
90.90
18 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
19 149
Ascorbic Acid Tablet IP - 100mg
50 X 10 Tabs
63.63
20 152
Folic Acid Tablets IP - 5mg
50 X 10 Tabs
49.25
21 160
Ranitidine Hydrochloride Tablets IP 50 X 10 Tabs
213.50

Page 54

<!-- page 56 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Unicure (India) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------22 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
23 169
Glipizide Tablets IP - 5mg
50 X 10 Tabs
86.15
24 179
Carbamazepine Tablets IP - 200mg
50 X 10 Tabs
453.90
25 189
Amitriptyline Tablets IP - 25mg
50 X 10 Tabs
95.95
26 190
Haloperidol Tablets IP - 1.5mg
50 X 10 Tabs
68.00
27 191
Haloperidol Tablets IP - 5mg
50 X 10 Tabs
92.50
28 229
Cephalexin Capsules IP - 250mg
10 X 10 Caps
167.69
29 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
30 254
Indomethacin Capsules IP - 25mg
10 X 10 Caps
48.00
31 292
Azathioprine Tablets IP - 50mg
50 X 10 Tabs
395.00
32 302
Trihexyphenidyl Hydrochloride Tablets IP 50 X 10 Tabs
54.54
33 331
Polyvitamin Tablets Prophylactic NFI
50 X 10 Tabs
167.40
34 342
Povidone Iodine Solution IP - 5% W/V
500ml Bottle
58.50
35 359
Acyclovir Dispersible Tablets IP - 200mg 50 X 10 Tabs
645.00
36 368
Levodopa and Carbidopa Tablets IP
50 X 10 Tabs
725.00
37 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
38 390
Bisacodyl Tablets IP - 5mg
50 X 10 Tabs
142.80
39 437
Phenoxymethyl Penicillin Potassium
50 X 10 Tabs
1,557.50
40 450
Chloroquine Phosphate Tablets IP - 250mg 10 X 10 Tabs
90.00
41 454
Povidone Iodine Cleaning Solution USP 500ml Bottle
107.00
42 528
Fluoxetine Capsules IP - 20mg
50 X 10 Caps
176.00
43 529
Risperidone Tablets IP - 2mg
50 X 10 Tabs
79.80
44 531
Chlordiazepoxide Tablets IP - 10mg
50 X 10 Tabs
171.00
45 565
Strong Cetrimide Solution BP
200ml Bottle
57.28
46 570
Pheniramine Maleate Syrup - 15mg/5ml
10ml Bottle
8.85
47 574
Liquid Antacid
60ml PET/Glass
9.09
48 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
49 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
50 712
Nifedipine Sustained Release Tablets IP
50 X 10 Tabs
107.00
51 721
Prazosin Hydrochloride Tablets IP - 2mg
50 X 10 Tabs
461.21
52 735
Amlodipine Tablets IP - 5mg
50 X 10 Tabs
48.40
53 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
54 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
55 750
Mycophenolate Mofetil Tablets IP - 500mg 10 X 10 Tabs
485.00
56 754
Aceclofenac Tablets IP - 100mg
50 X 10 Tabs
103.94
57 757
Tacrolimus Capsules IP - 1mg
50 X 10 Caps
1,745.00
58 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
59 776
Cefixime Tablets IP - 400mg
10 X 10 Tabs
497.84
60 777
Aluminium Hydroxide and Magnesium
10 X 10 Tabs
17.38
61 795
Mecobalamin Tablets IP - 500mcg
50 X 10 Tabs
108.00
62 796
Olanzapine Tablets IP - 5mg
50 X 10 Tabs
104.75
63 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
64 812
Entecavir Tablets IP - 0.5mg
3 X 10 Tabs /
75.40
65 813
Sitagliptin 50mg and Metformin
10 X 10 Tabs
77.00
66 826
Labetalol Tablets IP - 100mg
50 X 10 Tabs
496.90
67 830
Calamine Lotion IP
100ml Plastic
21.78

Page 55

<!-- page 57 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Unicure (India) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------68 834
Liquid Paraffin IP - 60ml Bottle
60ml Plastic
15.41
69 838
Tacrolimus Capsules IP - 0.5mg
50 X 10 Caps
1,010.00
70 841
Albendazole Tablets IP - 400mg
10 X 10 Tabs
101.78
71 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
72 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
73 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
74 849
Lorazepam Tablets IP - 2mg
50 X 10 Tabs
160.50
75 850
Clozapine Tablets IP - 50mg
10 X 10 Tabs
74.90
76 867
Paracetamol Tablets IP - 650mg
10 X 10 Tabs
39.49
77 872
Gabapentin Capsules IP - 100mg
10 X 10 Caps
46.99
78 876
Sitagliptin Phosphate Tablets IP - 100mg 50 X 10 Tabs
415.00
79 897
Amoxycillin Capsules IP - 500mg
10 X 10 Caps
151.66
80 898
Amoxycillin Oral Suspension IP 60ml HDPE
12.58
81 920
Domperidone Suspension IP - 1mg/ml
30ml PET/Glass
8.19
82 922
Drotaverine Hydrochloride Tablets IP 50 X 10 Tabs
244.99
83 925
Fusidic Acid Cream IP - 2% W/W
10gms Tube
14.61
84 928
Hydrochlorothiazide Tablets IP - 12.5mg
50 X 10 Tabs
119.99
85 932
Hyoscine Butyl Bromide Tablets IP - 10mg 50 X 10 Tabs
715.00
86 952
Ofloxacin Tablets - 200mg
50 X 10 Tabs
409.99
87 953
Ofloxacin Tablets IP - 400mg
10 X 10 Tabs
132.00
88 954
Ondansetron Oral Solution IP - 2mg/5ml
30ml PET/Glass
10.46
89 969
Sodium Valproate Oral Solution IP 100ml PET/Glass
24.61
90 976
Cefixime Tablets IP - 200mg
50 X 10 Tabs
1,301.70
91 980
Letrozole Tablets IP - 2.5mg
50 X 10 Tabs
260.00
92 982
Linezolid Tablets IP - 600mg
10 X 10 Tabs
398.90
93 992
Pregabalin Capsules IP - 75mg
50 X 10 Caps
244.40
94 996
Ambroxol Hydrochloride and
10 X 10 Tabs
209.00
95 997
Clobazam Tablets IP - 5mg
50 X 10 Tabs
195.00
96 1002
Mupirocin Ointment IP - 2% W/W
5gms Tube
8.25
97 1007
Tranexamic Acid Tablets IP - 500mg
10 X 10 Tabs
309.00
98 1009
Tamsulosin Hydrochloride and Dutasteride 50 X 10 Tabs
214.00
99 1013
Gabapentin and Methylcobalamin Tablets
10 X 10 Tabs
119.84
100 1016
Ticagrelor Tablets IP - 90mg
10 X 14 Tabs
339.99
101 1025
Olanzapine Tablets IP - 2.5mg
50 X 10 Tabs
105.00
102 1026
S(-) Metoprolol Succinate Extended
50 X 10 Tabs
1,244.00
103 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
104 1034
Dextromethorphan Hydrobromide and
60ml PET/Glass
10.20
105 1036
Levetiracetam Tablets IP - 500mg
10 X 10 Tabs
141.00
106 1037
Montelukast Sodium and Levocetirizine
50 X 10 Tabs
309.99
107 1039
Omeprazole IP + Domperidone IP (As
50 X 10 Caps
481.30
108 1041
Pre and Probiotic Capsules
10 X 10 Caps
128.99
109 1042
Pre and Pro Biotic Capsules - DS
10 X 10 Caps
115.00
110 1055
Betahistine Hydrochloride Tablets IP 50 X 10 Tabs
130.45
111 1061
Escitalopram Tablets IP - 10mg
50 X 10 Tabs
155.00
112 1066
Levocetrizine Tablets IP - 10mg
50 X 10 Tabs
80.95
113 1071
Nitroglycerin Controlled Release Tablets 1 X 30 Tabs
14.00

Page 56

<!-- page 58 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Unicure (India) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------114 1083
Trypsin and Chymotrypsin Tablets 10 X 10 Tabs
41.35
115 1084
Ursodeoxycholic Acid Tablets IP - 300mg
10 X 10 Tabs
583.90
116 1085
Vitamin D3 Drops
15ml HDPE
6.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Unijules Life Sciences Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 384
Glutaral Disinfectant Solution USP - NF
5 Litres Can
245.00
2 514
Iohexol Injection USP - 350mg/ml
50ml Glass /
484.29
3 722
Gadobutorol Injection - 1.0 mmol/ml
10ml Vial /
924.95
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Unilab Chemicals and Pharmaceuticals (P) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 70
Lysol IP (Cresol with Soap Solution)
5 Ltrs Plastic
830.90
2 384
Glutaral Disinfectant Solution USP - NF
5 Litres Can
245.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.United Biotech Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 76
Hydrocortisone Sodium Succinate
Vial
6.80
2 94
Sterile Dopamine Concentrate IP 5ml Ampoule
8.70
3 293
Doxorubicin Injection IP - 10mg/5ml
5ml Vial
49.00
4 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
5 597
Etoposide Concentrate Injection IP 5ml Vial
88.00
6 711
Methyl Prednisolone Sodium Succinate for Vial
49.21
7 749
Meropenem Injection IP - 500mg
Vial
31.69
8 778
Cefoperazone and Sulbactum for Injection Vial
15.40
9 783
Doxorubicin Hydrochloride Injection IP
25ml Vial
154.99
10 797
Paclitaxel Injection IP - 100mg/16.7ml
Vial
148.50
11 798
Piperacillin and Tazobactum Injection IP Vial
43.21
12 820
Amoxycillin and Potassium Clavulanate
Vial
22.95
13 988
Vancomycin Intravenous Infusion IP Vial
33.33
14 1003
Acetylcysteine Injection BP - 200mg/ml
5ml Ampoules
19.50

Page 57

<!-- page 59 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.United Biotech Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------15 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Vee Excel Drugs and Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 385
Spironolactone Tablets IP - 25mg
50 X 10 Tabs
304.50
2 708
Fluconazole Tablets IP - 150mg
50 X 10 Tabs
493.40
3 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
4 776
Cefixime Tablets IP - 400mg
10 X 10 Tabs
497.84
5 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
6 1083
Trypsin and Chymotrypsin Tablets 10 X 10 Tabs
41.35
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Venus Remedies Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
2 749
Meropenem Injection IP - 500mg
Vial
31.69
3 755
Amikacin Sulphate Injection IP 2ml Vial /
13.12
4 797
Paclitaxel Injection IP - 100mg/16.7ml
Vial
148.50
5 825
Iron Sucrose Injection USP
5ml Amber
6.85
6 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Vinayak Manutrade (P) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 383
Hydrogen Peroxide Solution (20 Vol) IP
1 Litre Bottle
38.10
2 963
Potassium Permanganate (Pure) Crystals
500gms HDPE
145.30
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 58

<!-- page 60 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Vins Bioproducts Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 325
Snake Venom Anti Serum IP (Freeze Dried) Vial
550.00
2 585
Snake Venum Anti Serum IP (Liquid Form)
10ml Vial
379.00
3 809
Rabies Antiserum IP
5ml Vial
338.50
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Vital Healthcare Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
2 174
Oxytocin Injection IP - 5 IU/ml
1ml Ampoule
3.85
3 352
Phenytoin Sodium Injection USP 2ml Ampoule
3.34
4 511
Atracurium Besylate Injection IP 2.5ml Ampoule
15.95
5 600
Midazolam Injection IP - 1mg/ml
5ml Vial
8.14
6 711
Methyl Prednisolone Sodium Succinate for Vial
49.21
7 714
Propofol Injection IP - 10mg/ml
10ml Vial
18.20
8 988
Vancomycin Intravenous Infusion IP Vial
33.33
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Vivek Pharmaceuticals Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 5
Co-Trimoxazole Tablets IP
10 X 10 Tabs
70.20
2 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
3 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
4 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
5 510
Diclofenac Gel IP
25gms Tube
4.73
6 576
Compound Benzoic Acid Ointment IP
15gms Tube
6.94
7 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
8 704
Atorvastatin Tablets IP - 10mg
50 X 10 Tabs
97.15
9 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Vivek Pharmachem (India) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 3
Paracetamol Paediatric Syrup IP
60ml PET/Glass
7.97
2 4
Co-Trimoxazole Oral Suspension IP
50ml Pet /
8.99

Page 59

<!-- page 61 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Vivek Pharmachem (India) Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------3 37
Ampicillin Sodium Injection IP - 500mg
Vial
6.82
4 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
5 76
Hydrocortisone Sodium Succinate
Vial
6.80
6 160
Ranitidine Hydrochloride Tablets IP 50 X 10 Tabs
213.50
7 229
Cephalexin Capsules IP - 250mg
10 X 10 Caps
167.69
8 231
Ciprofloxacin Tablets IP - 500mg
10 X 10 Tabs
123.40
9 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
10 749
Meropenem Injection IP - 500mg
Vial
31.69
11 778
Cefoperazone and Sulbactum for Injection Vial
15.40
12 798
Piperacillin and Tazobactum Injection IP Vial
43.21
13 820
Amoxycillin and Potassium Clavulanate
Vial
22.95
14 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
15 867
Paracetamol Tablets IP - 650mg
10 X 10 Tabs
39.49
16 897
Amoxycillin Capsules IP - 500mg
10 X 10 Caps
151.66
17 984
Pantoprazole For Injection - 40mg
Vial
4.93
18 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Windlas Biotech Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 842
Chlorthalidone Tablets IP - 6.25mg
50 X 10 Tabs
114.15
2 844
Telmisartan Tablets IP - 20mg
50 X 10 Tabs
115.89
3 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
4 846
Vildagliptin Tablets - IP 50mg
50 X 10 Tabs
194.90
5 979
Lactulose Solution USP
200ml PET/Glass
69.49
6 992
Pregabalin Capsules IP - 75mg
50 X 10 Caps
244.40
7 1010
Gabapentin Tablets IP - 300mg
10 X 10 Tabs
87.87
8 1013
Gabapentin and Methylcobalamin Tablets
10 X 10 Tabs
119.84
9 1023
Linagliptin Tablets - 5mg
50 X 10 Tabs
288.90
10 1030
Vildagliptin 50mg and Metformin
10 X 10 Tabs
68.95
11 1033
Dapagliflozin Tablets - 10mg
50 X 10 Tabs
228.89
12 1055
Betahistine Hydrochloride Tablets IP 50 X 10 Tabs
130.45
13 1070
Linagliptin + Metformin Tablets
10 X 10 Tabs
68.90
14 1071
Nitroglycerin Controlled Release Tablets 1 X 30 Tabs
14.00
15 1083
Trypsin and Chymotrypsin Tablets 10 X 10 Tabs
41.35
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 60

<!-- page 62 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

Name of the Tenderer : M/s.Wings Biotech LLP
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 2
Paracetamol Tablets IP - 500mg
10 X 10 Tabs
35.00
2 7
Metronidazole Tablets IP - 200mg
50 X 10 Tabs
169.90
3 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
4 57
Norfloxacin Tablets IP - 400mg
10 X 10 Tabs
144.00
5 114
Ibuprofen Tablets IP - 200mg
50 X 10 Tabs
115.00
6 160
Ranitidine Hydrochloride Tablets IP 50 X 10 Tabs
213.50
7 168
Metformin Hydrochloride Sustained
10 X 10 Tabs
31.38
8 252
Diclofenac Sodium Tablets IP - 50mg
50 X 10 Tabs
74.65
9 377
Gamma Benzene Hexachloride Application
100ml Plastic
19.71
10 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
11 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
12 589
Glimepiride Tablets IP - 1mg
50 X 10 Tabs
49.45
13 592
Dispersible Amoxycillin Tablets IP 50 X 10 Tabs
284.15
14 746
Azithromycin Tablets IP - 250mg
10 X 10 Tabs
398.50
15 748
Clopidogrel Tablets IP - 75mg
50 X 10 Tabs
295.00
16 760
Pantoprazole Sodium Tablets IP - 40mg
50 X 10 Tabs
220.00
17 810
Metoprolol Succinate Extended-Release
50 X 10 Tabs
128.90
18 837
Calcium Carbonate and Vitamin D3 Tablets 10 X 10 Tabs
22.90
19 845
Telmisartan Tablets IP - 40mg
50 X 10 Tabs
158.85
20 861
Azithromycin Tablets IP - 500mg
10 X 10 Tabs
764.00
21 979
Lactulose Solution USP
200ml PET/Glass
69.49
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Wipro Ge Healthcare Pvt Ltd (New Delhi)
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 514
Iohexol Injection USP - 350mg/ml
50ml Glass /
484.29
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Yeluri Formulations Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 50
Amoxycillin Capsules IP - 250mg
10 X 10 Caps
82.50
2 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
3 749
Meropenem Injection IP - 500mg
Vial
31.69
4 798
Piperacillin and Tazobactum Injection IP Vial
43.21
5 897
Amoxycillin Capsules IP - 500mg
10 X 10 Caps
151.66
6 1040
Cefoperazone and Sulbactum for Injection Vial
21.21

Page 61

<!-- page 63 -->

Annexure
Online Tender for the Supply of Essential Drugs and Medicines to TNMSC Limited
under rate contract system for one year from the date of acceptance
Tender Ref.No. e-004/M(P)/DRUG/TNMSC/2026, Dated. 03.03.2026
List of Products with Approved L1 Rate

------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Zazen Pharma Pvt Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 75
Dexamethasone Sodium Phosphate Injection 2ml Vial /
2.10
2 82
Heparin Sodium Injection IP - 5000 IU/ml 5ml Vial
54.19
3 226
Cefotaxime Sodium Injection IP - 1000mg
Vial
12.39
4 310
Lignocaine Hydrochloride Injection IP 30ml Vial
7.59
5 504
Ceftriaxone Injection IP - 1000mg/Vial
Vial
12.75
6 749
Meropenem Injection IP - 500mg
Vial
31.69
7 751
Ondansetron Injection IP - 2mg/ml
2ml Ampoule
1.27
8 798
Piperacillin and Tazobactum Injection IP Vial
43.21
9 1040
Cefoperazone and Sulbactum for Injection Vial
21.21
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.
Name of the Tenderer : M/s.Zenith Drugs Ltd
------------------------------------------------------------------------------------Sl.
Drug Code / Name of the Drug
Unit
L1 Rate to be
Matched(*)
------------------------------------------------------------------------------------1 4
Co-Trimoxazole Oral Suspension IP
50ml Pet /
8.99
2 36
ORS Powder IP
Sachets/Pouches
2.16
3 342
Povidone Iodine Solution IP - 5% W/V
500ml Bottle
58.50
4 449
Clotrimazole Cream IP - 2%
15gms Tube
5.26
5 488
Omeprazole Capsules IP - 20mg
10 X 10 Caps
29.90
6 492
Cetrimide Cream IP - 0.5%
25gms Tube
5.90
7 493
Zinc Cream IP - 32%
25gms Tube
7.25
8 510
Diclofenac Gel IP
25gms Tube
4.73
9 576
Compound Benzoic Acid Ointment IP
15gms Tube
6.94
10 587
Povidone Iodine Ointment USP - 5% W/W
15gms Tube
6.78
------------------------------------------------------------------------------------* L1 Rates are Exclusive of GST.

Page 62
