---
doc_id: "930adefa62d3ddfb"
source_url: "https://annamalaiuniversity.ac.in/download/tenders/tender_30jan19_document.pdf"
ministry: "Annamalai University, Tamil Nadu"
title: "Download Tender Document"
date: ""
pages: 25
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6d866193694e962a"
---

<!-- page 1 -->

1
Tender Conditions and procedure to be abided by the tenderers
1.

INTRODUCTION
1.1. This tender is for procurement of the following equipments for
Annamalai University, Annamalainagar, Chidambaram, India.
No.

File No.

Description

1.

GUCC/DST PURSE
II/Tender 2/01/2018

Direct Metal Laser Sintering (DMLS) System

2.

GUCC/DST PURSE
II/Tender 2/02/2018

Lead shield – Alpha and Gamma Spectrometer

The specification for the above mentioned equipments is given in Schedule A
(Page No. 22 & 25)
1.2. Applicability of Tamil Nadu Transparency in Tenders Act and
Rules: This tender will be governed by the Tamil Nadu Transparency in
Tenders Act 1998 and Rules 2000 as amended from time to time.
2. ELIGIBILITY CRITERIA
2.1. A tenderer will be eligible for tendering only if he satisfies the

eligibility

criteria as given below:
a) A

tenderer

should

manufacturing

be

license

a

manufacturer

from

the

possessing

competent

a

authority

valid
for

manufacturing the items quoted and should have at least three
years’ experience. (Documentary evidence to be furnished)
b) The manufacturer should be an ISO:9001 / Equivalent certified
company. Documentary evidence should be enclosed.
c) Authorized Dealer / Distributor / Supplier can also bid with
authorization from the Manufacturer. (Documentary evidence to be
furnished). A manufacturer shall not authorize more than one dealer
/ distributor for participating in this tender.
d) In

case

a

tenderer

is

participating

as

an

authorized

Dealer/Distributor/Supplier the manufacturer of the item should
satisfy the conditions mentioned at (a) and (b) above.

<!-- page 2 -->

2
e) The tenderer should have a Tamil Nadu Value Added Tax Registration
/ Central Sales Tax Registration. Copy of the Registration Certificate
should be enclosed.
f) The Tenderer should be an Income Tax assesse. (Return filed should
be enclosed)
2.2. The tenderer should not have been blacklisted or debarred from
participating in tenders by any Central / State Government agencies or
autonomous bodies or universities/ institutions. (An undertaking to this
effect should be furnished)
2.3. The tenderer submitting their offer must have supplied similar items to
other Universities or institutions or Government agencies. Copies of such
order must be enclosed this tender document.
3. COST OF TENDERING
The Tenderer shall bear all costs associated with the preparation and
submission of this Tender and the tender inviting authority will in no way be
responsible or liable for these costs.
3.1 Cost of Tender Document:
The Tender document can be obtained from “The Registrar, Annamalai
University”. The cost of the tender document is `. 2100/-. The demand draft
should be in favour of “The Registrar, Annamalai University” payable at
Annamalainagar or Chidambaram.
The Tenderer may also download the Tender Document from the
University Web Site (annamalaiuniversity.au.in) at free of cost.
4. GENERAL INSTRUCTIONS
4.1. The tenderers are requested to go through the instructions, terms and
conditions and specifications given in the tender. Failure to furnish all
required information in every aspect will be at the tenderer’s risk and may
result in the rejection of the tender.
For any queries tenderer may contact Registrar, Annamalai University,
Annamalainagar, Chidambaram – 608 002. Tamil Nadu, INDIA.

<!-- page 3 -->

3
4.2. Clarification on the tender
A prospective tenderer requiring any clarification on the tender may
request the Office of the Registrar, Annamalai University by a letter or by
fax. Registrar, Annamalai University will respond in writing to any request
for clarification in the tender.
4.3.

Amendments to the Tender
i.

Tender Inviting Authority may amend the tender wherever it is felt
that such an amendment is absolutely necessary.

ii.

Amendment

to

tender

may

also

be

given

in

response

to

clarifications by prospective tenderers and it is solely the discretion
of the Tender Inviting Authority. Any amendment to the tender will
be uploaded on the website www.annamalaiuniversity.ac.in. It is
the responsibility of the tenderer to verify the amendments if
any and get the amendment documents before the submission
of the tender provided no such change could be effected 48
hours prior to the time fixed for opening of the tender.
4.4. The Tender document is not transferable under any circumstances
5. EARNEST MONEY DEPOSIT (EMD)
5.1. The tenderer should furnish Earnest Money Deposit (EMD) 1% of the
total cost along with the tender by way of Demand Draft/Bankers
cheque obtained from any Nationalized/ Scheduled Bank and drawn in
favour

of

“The

Registrar,

Annamalai

University”

payable

at

considered

as

Annamalainagar or Chidambaram.
5.2.

Any

tender

without

required

EMD

will

be

NON-RESPONSIVE and will be SUMMARILY REJECTED.
5.3. The Tender Inviting Authority will arrange to refund the Earnest Money
Deposit to the unsuccessful tenderers after publishing the list of
successful tenderers, within a reasonable time.
5.4. No interest will be paid on the EMD.
5.5. The EMD is liable to be forfeited if:

<!-- page 4 -->

4
i. The Tenderer withdraws his tender at any stage after the last date and
time fixed for submitting the tender.
ii. The Tenderer on becoming successful, fails to furnish the required
security deposit or sign the agreement, within the stipulated time limit.
6. PERFORMANCE SECURITY :
i.

Successful tenderer has to furnish Security Deposit equivalent to 5% of the
tendered value either in form of Demand Draft drawn in favour of “Registrar,
Annamalai University” or in form of irrevocable bank guarantee obtained from
any Nationalized/Scheduled bank.

ii.

The EMD of the Successful Bidder will be adjusted towards Security Deposit
(SD). Security Deposit will be released only after the expiry of the warranty
period as mentioned in clause 8.5.

7.

SUBMISSION OF TENDER:
7.1. Due Date for Tender Submission
i.

The tender document duly filled in, signed on all pages can be
submitted in sealed cover to the Registrar, Annamalai University at
his office upto 3.00 PM on 30.01.2019 as per the procedure laid
down herein. The tender can be submitted on all working days upto
the above closing date. In the event of this day being declared as a
holiday, the tenders can be submitted up to 3.00 P.M. on the following
working day.

ii.

The tender inviting authority will not be held responsible for any delay
in the receipt of the Bank Draft or any delay in the receipt of the
document by the tenderer including loss of the document in transit or
delay in obtaining any document / certificate or on any other account.
No extension of the date and time for the submission of the
documents will be given for any such delay.

iii.

The tender inviting authority may extend the due date for submission
of tender by issuing an amendment in which case all the rights and
obligations of the Tender Inviting Authority and the Tenderers
previously subject to the original due date for submission will then be
subject to the new date for submission.

<!-- page 5 -->

5
iv.

Any tender received by the Tender Inviting Authority after the due
date and time will not be considered and will be returned to the
tenderer.

7.2. Procedure for Submission of Tender
i. Tenderers are advised to go through the tender documents and
understand all the provisions and stipulations contained therein before
submitting the tender.
ii. The tender shall be submitted as per the procedures and requirements
stipulated herein.
iii. Tender submitted by fax will not be accepted and will be summarily
rejected.
iv. The Commercial bid should be neatly typed. Hand written offers will be
rejected. Any deviation in the offer shall lead to rejection.
v. The tenderer who are supplying imported material, must be
registered

with

the

Competent

Authority/Department

of

the

Government of India.
vi. The purchaser shall not be responsible for any postal delay in receipt of
the offer.

Any bid received by the Purchaser which does not fulfil the

desired terms and conditions shall be rejected out rightly and no
communication in this regard shall be sent. Delayed/Late bids will not be
accepted, at any circumstances.
vii. All the bids will be opened in the presence of bidders representatives, who,
chose to attend the same as per the date and time specified in the Tender
Document.
viii. This tender is based on two-cover systems i.e. Technical bid and
price bid. Therefore the tender shall be submitted in two parts viz. Cover
A and Cover B.

Each part shall be placed in an independent sealed

envelope and shall be super scribed as follows
Cover-A

:

“TENDER

“TECHNICAL BID COVER”
FOR

SUPPLY

ANNAMALAI UNIVERSITY”
TENDER NUMBER:

OF

____________

EQUIPMENT

TO

<!-- page 6 -->

6
Cover-B

:

“PRICE BID COVER”

“TENDER FOR SUPPLY OF _____________________ EQUIPMENT TO
ANNAMALAI UNIVERSITY”
TENDER NUMBER:
ix.

The contents of each of the two covers shall be as described in
the subsequent clauses.

For all other references, these covers

will be referred to briefly as “Technical Bid Cover” and “Price Bid
Cover”.
Both the covers i.e. Cover-A and Cover-B, shall be placed inside
an outer cover and shall be super scribed as follows:
“TENDER FOR
EQUIPMENT”

SUPPLY

OF

__________________________________

TENDER NUMBER:
x.

The sealed tender envelope shall be addressed to
The Registrar,
Annamalai University,
Annamalainagar,
Chidambaram-608 002, Tamil Nadu, India

xi.

The tender envelope shall carry the name and address of the Tenderer
prominently with Phone No. / email ID / and FAX No.

xii.

The Technical Bid Cover (Cover-A) shall contain the following as per the
sequence indicated below.

1.

Earnest Money Deposit (EMD) of as per clause-5 of the Tender
document.

2.

Application form for supply of equipment as per Appendix-1 (Page
No.15)

3.

Documentary evidence for payment of income tax (latest income tax
return should be furnished)

4.

Letter of Tender as per Appendix-2 (Page No.17)

5.

Documentary evidence for registration under Tamil Nadu Value Added
Tax / Central Sales Tax.

6.

Documentary evidence for ISO:9001 / equivalent certified company

7.

A copy of Manufacturing license/Registration Certificate

8.

Authorization
from
Manufacturer
Dealers/Distributors/Supplier

9.

Documentary

evidence

of

supplying

in

case

similar

of
items

Authorized
to

other

<!-- page 7 -->

7
Universities/Institutions/Govt. agencies.
10.

In addition to the above any document or certificates etc., mentioned
anywhere in the tender document shall also be a part of the technical
tender requirements.

xiii.

The PRICE BID COVER (Cover-B) shall contain the Price Bid as per the
format given in Appendix-3 (Page No.19).
The tenderer shall not carry out any alteration in the format prescribed
for Price Bid. The tenderer shall not enclose any other document or
statement that will influence the price.

In such an event, the tender

inviting authority shall summarily reject the tender.
7.3. Signing of the Tender
The tender shall be signed by a person or persons duly authorized to
sign on behalf of the Tenderer. All pages of the tender shall be signed by the
person or persons signing the tender. The tenderer shall enclose a certified
copy of the power of attorney authorizing the signatory or signatories to sign
the tender document. This certification shall be from the Managing Director
or the Legal Manager of the firm.
The tender shall contain no alterations or additions, except those to
comply with instructions issued by the Tender Inviting Authority, or as
necessary to correct errors made by the tenderer, in which case such
corrections shall be signed by the person or persons signing the tender.
All the pages in the tender document should be signed by the
tenderer, after filling the prices in figures & words.
8. GENERAL TERMS AND CONDITIONS
8.1. DELIVERY SCHEDULE:
The Price Quoted should be FOR CHIDAMBARAM
i.

Materials

should

be

door

delivered

at

Annamalai

University,

Annamalainagar, Chidambaram, Tamilnadu.
ii.

Delivery must be made within a period of 45 days from the issue the
order either directly or through their dealer network unless otherwise
specified.

<!-- page 8 -->

8
iii.

If the supplier fails to deliver the equipment ordered within the
allotted delivery period as specified above, the Purchaser may procure
goods or services similar to those un-delivered upon such terms and
in such manner as it deems appropriate from any other firm at the
risk and cost of the supplier.

8.2 PAYMENT TERMS:
i.

Payment will be made within 30 days from the date of delivery,
installations, commissioning and demonstration of the equipment and
acceptance by concerned Department/ Section.

ii.

Payment shall be made by Cheque or such other mode/ electronic
fund transfer offered by the Bank.

8.3 Taxes& Duties :
i.

As per Govt. Notification No.10/97-CE dated 1st March 1997,
Annamalai University, Chidambaram is exempted from Excise Duty
for SCIENTIFIC / TECHNICAL INSTRUMENTS WHICH ARE USED
FOR RESEARCH PURPOSE ONLY. The University shall provide all the
documents under this notification to enab le supplier to clear the
goods without payment of excise duty, whenever required. Supplier
should state clearly that this certificate is required.

ii.

As per Govt. of India Notification 51/96 Customs dated 23rd July
1996, Annamalai University, Chidambaram is exempted from Custom
duty for all research equipment. The University shall provide all the
documents under this notification to enable supplier to clear the
goods without payment of Custom duty, whenever required. Supplier
should state clearly that this certificate is required.

iii.

GST may be charged as applicable. Any statutory variation will be
paid to supplier on documentary evidence. Supplier should clearly
indicate the percentage of GST applicable.

iv.

Clearing forwarding charges should also be mentioned

<!-- page 9 -->

9
8.4 Loss, Damage & shortage :
Annamalai University shall not be responsible for any loss, damages
and shortage during transit. Payment shall be made for the material
received in good condition only.
8.5

Warranty
The equipment supplied under the contract shall carry a warranty for

at least Two years. Supplier shall extend free maintenance service during
the warranty period.
8.6 Commissioning and Demonstration
The Supplier shall be responsible for commissioning of the equipment.
Supplier should also arrange for demonstration of the equipment to the Staff
of the University.
8.7

Annual Maintenance
The University reserves the right to entrust Annual Maintenance of the

equipment supplied under this tender to the concerned supplier. Therefore
the tenderer shall mention the annual maintenance charges AMC/SMC in
the price schedule. Tenderer should also give a brief write up about the
services to be covered under Annual Maintenance charges quoted by him.
8.8 General:
The acceptance of the offer will rest with the Annamalai University who
reserves the right to reject/accept partially or wholly the tenders received,
without assigning any reason.
i.

Mere submission of tender/ proposal does not imply acceptance of the
same at this end and the firms will be finalised only after meeting the
laid down qualifying parameters for which decision of the Tender
Inviting Authority / Tender Accepting Authority shall be final and
binding on the parties.

ii.

Printed terms and conditions of the applicant on their quotation
Form/ Literature/ Letter etc. if any, will not be binding on the
University.

<!-- page 10 -->

10
8.9 Liquidated Damages :
Timely delivery is essence of the contract and hence should any
consignment be delayed, liquidated damages at the rate 0.5% of the value of
the delayed consignment, for each week or part there of shall be levied and
recovered subject to maximum of 5% of total order value.
8.10 Acceptance / Rejection:
The Tender Accepting Authority reserves the right to accept a
quotation in part or in full or to reject all quotations or any of the quotations
received, for non-compliance of any of the above items, conditions or
instructions or for any other reason without assigning any reason thereof.
9.1. TENDER OPENING
i.

Tender will be opened in the presence of the tenderers or their
authorized representative who choose to be present and the tender
scrutiny committee at 4.00 P.M. on 30.01.2019. The representative
of tenderer who attend the tender opening must produce their
identification proof and authorization letter from the companies /
tenderer.

ii.

In the event of the specified date of Tender opening being declared a
holiday, the tenders will be opened at the same time on the next
working day.

iii.

Cover-A containing “Technical Bid” shall be opened first.

iv.

On opening the tender, the details such as name of the tenderer,
address, EMD details, etc., will be read out.

v.

Tenders found without the EMD or with an invalid EMD or insufficient
EMD, will be summarily rejected. Unopened tenders will be returned
to such tenderers.

vi.

On verifying the EMD, the Technical bids will be examined to decide
their service suitability for the said work. Tenderers whose Technical
bids are not found acceptable will be advised of the same and their
sealed covers containing the respective Financial Bids will not be

<!-- page 11 -->

11
opened. Their EMD will also be returned to them.
vii.

Price bids of only those tenderers whose Technical bids are
substantively responsive, will be opened.

9.2. Process to be Confidential
i.

Information relating to the examination, clarification, evaluation and
comparison of tenders and recommendations for the award of contract
shall not be disclosed to tenderers or any other persons not officially
concerned with such process until the award to the successful
tenderer has been announced.

ii.

Any effort by a tenderer to influence the tender accepting
authority, scrutiny / evaluation committee or its members in the
processing of tenders or award decisions may result in the
rejection of his tender.

9.3. Criteria for Technical Evaluation
(Evaluation of Technical Bid)
i.

The tender accepting authority will determine whether the tenderer
has fulfilled all the tender conditions as stipulated in the tender
document and whether the tender is substantially responsive or not.

ii.

A responsive tender is one which conforms to all the terms, conditions
and specifications of the tender documents without material deviation
or reservation. A material deviation or reservation is one:
a)

Which affects in any substantial way the scope, quality or
performance of the contract.

b) Which is a substantial way is inconsistent with the Tender
conditions,

the

tender

accepting

authority’s

rights

or

the

Tenderers obligations under the Contract, or
c)

Whose rectification would affect unfairly the competitive position
of other Tenderers presenting substantively responsive Tenders.

iii.

Tenderers who have not fulfilled the tender conditions shall be a nonresponsive tender and will not be taken up for further evaluation and

<!-- page 12 -->

12
Price Bid opening.
iv.

To assist the examination, evaluation and comparison of Tenders, the
tender accepting authority may at its discretion, ask any tenderer for
clarification on his Tender. The request for clarification and the
response shall be in writing or by fax but no change in the substance
of the Tender shall be so sought, offered, or permitted

v.

When a tender fails to be responsive, it will be rejected by the tender
accepting authority and may not subsequently be made responsive by
correction or addition / withdrawal of the non-conforming deviation or
reservation.

9.4. Price Bid Opening and Evaluation of Price Bid
i) The Tender inviting Authority will then proceed with opening of Cover-B,
i.e., “PRICE BID COVER” of those tenderers whose technical bid has been
found substantively responsive.

The opening of the “Price Bid cover”

will be done in the presence of those tenderers or their representatives
who choose to be present. The Tender Inviting Authority will inform such
tenderers in advance about the acceptance of their technical tender and
the date and time of opening of the “Price Bid Cover”.
ii. The tender will be evaluated based on the prices offered by the tenders
for the concerned equipments.
iii. The tender who has bid the lowest evaluated price will be determined
considering the following factors:a) the quoted price shall be corrected for arithmetical errors;
b) in cases of discrepancy between the prices quoted in words and in
figures, lower of the two shall be considered;
iv. The evaluation shall include all central duties such as customs duty and
central excise duty and sales tax as a part of the price, as details below
a) In evaluation of the price of an imported item, the price has to be
determined inclusive of the customs duty;
b) In evaluation of the price of articles which are subject to excise
duty, the price has to be determined inclusive of such excise duty.

<!-- page 13 -->

13
c) In a tender where all the tenderers are from within the State of
Tamil Nadu, or where all the tenderers are from outside the State
of Tamil Nadu, the (Value Added Tax) shall be included for the
evaluation of the price; and
d) In a tender where the tenderers are both from the State of Tamil
Nadu as well as from outside the State of Tamil Nadu, [the Value
Added Tax levied under Tamil Nadu Value Added Tax Act, 2006
(Tamil Nadu Act 32 of 2006)] shall be excluded for the evaluation
of the price.)
v.

Annual Maintenance charges will not be included while evaluating
the tender.

10. AWARD OF TENDER
10.1. The award of the tender shall be made strictly in accordance with the
“Tamil Nadu Transparency in Tenders Act 1998 and Rules 2000 and
no deviation will be made.
10.2. Notwithstanding anything that is said herein, the Tender Accepting
Authority reserves the right to accept or reject any tender or all
tenders, and to cancel the tendering process and reject all tenders, at
any time prior to the award of tender, without thereby incurring any
liability to the affected tenderer or tenderers or any obligation to
inform the affected tenderer or tenderers on the grounds for the
tender accepting authority’s action.
11. NOTIFICATION OF AWARD
11.1 The tenderer whose tender has been accepted will be notified by the
Tender Accepting Authority, in writing.
11.2. Upon furnishing the security deposit by the successful tenderer or
tenderers and upon signing the Agreement (Appendix-4), the EMD will be
returned to the unsuccessful tenderer within a reasonable time period.

<!-- page 14 -->

14
12. DISPUTES AND JURISDICTION:
Any legal disputes arising out of any breach of contract pertaining to this
tender process shall be settled in the court of competent jurisdiction located
within the town of Chidambaram in Tamil Nadu.
13. ACKNOWLEDGEMENT:
It is hereby acknowledged that we have gone through all the conditions
mentioned above and we agree to abide by them.

Date:

Signature of Tenderer

Place:

Official seal and address

<!-- page 15 -->

15
Appendix-1
APPLICATION FORM FOR SUPPLY OF ____________ EQUIPMENT
S.NO. VENDOR DETAILS
1

Name and Address of the
Manufacturer/Firm/Vendor (with
Telephone /fax/Mobile /email
address)
Phone Number
Fax
E-Mail
Contact Person Name
Mobile Number

2

Name and Address of the Local
Authorized Dealer/Distributors/
Supplier
Phone Number
FAX
E-Mail
Contact Person Name
Mobile Number

3

GST No / TIN No. of the
Firm/Dealer (copy to be enclosed)

4

PAN
No.
of
the
(Copy to be attached)

5

EMD (DD No., Date & Amount
and issuing Bank)

6

Name
of
the
University/
Government Institutes who have
purchased similar equipments
from your concern (attach copies)

Dealer

<!-- page 16 -->

16

7. Declaration by the tenderer.
i.) We hereby declare that all the particulars given in this application are true
and complete to the best of our knowledge and belief and we will produce
all the relevant documents promptly, if necessary or as and when asked
for by Annamalai University, Chidambaram. We understand that
information provided by us will serve as Prequalification Criteria for
supply of equipments under this tender and in the event of any
information being found false or incorrect or ineligibility being detected
even after the award of Contract, Our contract may be cancelled and all
our

claims

may

be

forfeited

by

the

Annamalai

University,

Annamalainagar. We have read and understood all the terms and
conditions of the tender and we fully agree to it.
ii.) We also declare that we will not sell our products at a lesser price to other
parties than those supplied to Annamalai University and in the event of
happening of such situation, we will be bound to refund the difference
and our contract may also be cancelled at the discretion of Annamalai
University.
iii.) We also undertake that all the terms such as Product Range, Price,
Discount, Delivery/other charges, Terms of Payment and also the
name/s of the Dealer/ Distributor will remain unchanged during the
contract period and no alteration will be done without the approval of
Annamalai University.

Date :

Signature

:

Place :

Name

:

Designation

:

Seal of the firm

:

<!-- page 17 -->

17

Appendix – 2
TENDER FOR SUPPLY OF _____________ EQUIPMENT TO
ANNAMALAI UNIVERSITY
LETTER OF TENDER
To
The Registrar,
Annamalai University,
Annamalai Nagar,
Chidambaram – 608 002.
Sir,
Sub: Tender for Supply of _____________ Equipment.
*****
1)

I / We, the undersigned do hereby tender and undertake to Supply of

___________ equipment to Annamalai University in strict accordance with
and subject to the terms and conditions set forth or mentioned in the
Tender documents and appendices.
2)

I / We have gone through the instructions in the tender and carefully read

all the conditions of tender and agree to abide by all the conditions mentioned
there in.
3)

I / We hereby state that I/we have remitted ________________ (Rupees … …

… … … … … … … … … … … … … … … … … … … … … … … … … only) in the
form of Demand Draft/Bankers Cheque No. ____________ Dated : _________________
drawn

on

_________________________________________

Bank

___________________________________________________ Branch, in favour of the
Registrar, Annamalai University as Earnest Money Deposit and agree to have it
forfeited to the Annamalai University in case of my / our failure to supply the
equipment.
4)

I / We hereby certify that the price offered is final and I / We will not come

forward for any revision or alteration in rates quoted subsequently due to hike in
prices or any other reasons. However I/we are aware of the university’s right to
negotiate the discount rate while evaluating the tender.
5)

I / We confirm that our Tender is in conformity with the technical

specifications and commercial terms & conditions as stipulated in the Tender

<!-- page 18 -->

18
Document and without any deviations whatsoever. I am / We are aware that our
Tender is liable for disqualification in the event of technical and commercial
deviations observed by the Tender Accepting Authority at a later date during the
process of evaluation of our Tender.
6)

I / We further declare that the information and documents furnished in the

Tender submitted by us are correct and genuine.

I am / we are aware of the

Tender Inviting Authority’s right to forfeit the Earnest Money Deposit and / or
Security Deposit and blacklisting me / us if, any information furnished by us
proved to be false at the time of inspection and not complying with the tender
conditions.
7)

I / We state that I / We have not been blacklisted or debarred from

participating in tenders by any Central / State Government agencies or
autonomous bodies or universities / institutions.
8)

In the event of my / our tender becoming successful, I / We undertake and

agree to forward to the Registrar, Annamalai University in ten (10) days, after the
notification of the acceptance of this tender has been received by us.
9)

We undertake and agree that we will not withdraw this Tender during the

period that will be required for intimation of acceptance or non-acceptance as
stipulated in clause 10 of the Tender document. If I / we do so withdraw, I / we
shall forfeit the Earnest Money Deposit to Annamalai University. I / We agree to
execute at our cost the Agreement in ten (10) days after the notification of the
acceptance of our Tender has been received by us. In the event of our failing to
make the Security Deposit or to execute the Agreement in the said manner, the
Earnest Money Deposit accompanying this Tender shall be forfeited to the
Annamalai University and this concluded Contract shall in such case be
considered as having been cancelled or terminated and I / we agree to be liable,
irrespective of the forfeiture aforesaid for all damages, losses, costs, charges and
expenses arising from or by reason of such failure and arrangements.
As witness our hand this..............day of................of 2016.
Signature of the Tenderer

:

Name & Address

:

Company Seal

:

<!-- page 19 -->

19
Appendix-3
PRICE BID
1

Price
(Both in figure and
words) in Rs.
%

2

GST

Amount in Rs.
Total Amount in Rs.

Important Note:
1. The price quoted above shall be inclusive of all taxes and charge except GST.
2. GST shall be mentioned separately.
3. FOR; Destination as given in the purchase order.

Other Information to be provided:
1.

Warranty period in years

2.

Annual maintenance charges (applicable after expiry of warranty
period)

3.

After First expiry year of the warranty

4.

After second year of the warranty

5.

After third year of the warranty

6.

After fourth year of the warranty

7.

After fifth year of the warranty

Signature:
Name:
Designation:
Seal of the firm:

<!-- page 20 -->

20
Appendix – 4
FORMAT OF CONTRACT AGREEMENT
THIS AGREEMENT made on the ………… day of …………. 2016 between The
Registrar, Annamalai University, Annamalainagar, Chidambaram – 608 002.
(Herein after “the Purchaser”) of the one part and ……………….…………….. (Name
of Supplier) of …………..

(Address of the Supplier) (herein after called “the

Supplier) of the other part:
WHEREAS the Purchaser is desirous of procuring _______________ equipment
as per the tender reference No…………………. and has accepted a bid by the
Supplier for the above said equipment price offered by the Supplier is
Rs.___________________(Rupees in words … … … … … … … … … … … … … … … …
… … … … … … … … … … … … … … … …)

NOW THIS AGREEMENT WITNESSETH AS FOLLOWS:
1. In this Agreement words and expressions shall have the same meanings as
are respectively assigned to them in the Conditions of Tender referred to,
and they shall be deemed to form and be read and construed as part of this
agreement.
2. The following documents shall be deemed to form, be read and construed as
part of this Agreement, viz;
a) The letter of Acceptance issued by the purchaser.
b) The Notice Inviting Tender.
c) The supplier’s bid including enclosures, appendixes, documents, Price
Catalogue etc.
d) The Tender Document including various Terms and Conditions.
e) Any other document listed in the Tender document.
3. In consideration of the payments to be made by the Purchaser to the
Supplier within thirty (30) days from the date of delivery and acceptance by
concerned department/ section.
4. The warranty period is ___________ years.

<!-- page 21 -->

21
5.
The AMC/SMC for the subsequent year after the warranty period will be as
follows.

After First expiry year of the warranty
After second year of the warranty
After third year of the warranty
After fourth year of the warranty
After fifth year of the warranty

IN WITNESS whereof the parties here to have caused this Agreement to be
executed in accordance with their respective laws the day and year first above
written.

Signed, Sealed and Delivered by the Said ……………………….. (For the Purchaser)
in the presence of ………………
Signature
Name Address
Signed, Sealed and Delivered by the Said ……………………….. (For the Supplier) in
the presence of ………………
Signature
Name Address
Signed, Sealed and Delivered by the Said ……………………….. (For the Purchaser)
in the presence of ………………
Signature
Name Address

<!-- page 22 -->

22
SPECIFICATIONS
----------------------------------------------------------------------------------------------------Tender No. GUCC/DST PURSE II/TENDER2/01/2018-19
TECHNICAL SPECIFICATIONS OF DIRECT METAL LASER SINTERING (DMLS)
SYSTEM
Specification
Description
General Specs to ➢ Digital Manufacturing system of latest specifications to
meet
deliver metal prototypes and Tooling using additive
fabrication technique. The process should be able to
sinter / melt metal powder and should be free from non
metallic binders.
➢ All parts which are integral of the machine should be CE
certified. Information should be clearly stated in technical
bid on locally purchased items.
➢ Machine quoted should have options to upgrade both with
reactive and non reactive material for currently available
material and also for future materials
Size of prototype
100 mm x 100 mm x 100 mm (x,y,z)
Reservoir Volume 110 mm x 200 mm
Technology used

Laser Sintering technology with atleast 200W Yb-Fibre laser
from IPG within built N2 generator and a supply for Argon
gas.
of Reactive and Non Reactive Materials;
Capable of running in R&D mode to facilitate working on any
can AM powder

Materials
Prototype
machine
handle
Inert Gas System

Machine should have in built N2 generator, and Argon
bottles.
Mechanical
➢ The mechanical properties of build shall be near to
properties of built
original material standard properties. Key properties are
material
yield strength, UTS, % elongation, hardness, density etc
➢ Also the building method should incorporate a rotated
exposure method inorder to get homogenous part property
and also to avoid job crashes and errors. Degree of
rotation should be mentioned in the technical document.
➢ Complete data sheet should be provided of the laser
sintering part properties
Accuracy
+ 20 to 50 micrometer
achievable
Repeatability
x = 15 μm; y = 15 μm; z = 15 μm
achievable
Minimum
Layer 20-50 microns
thickness
Minimum
wall 0.3 to 0.4 mm
thickness possible
Safety

Argon sensor and Oxygen sensor. Material default jobs

<!-- page 23 -->

23
requirements
Extraction Unit
Training needs

should be able to predict the correct inert atmosphere
For both Reactive and Non Reactive Materials
5 days of training (excluding installation and commission
days)
Technical support Complete Trained Technical Support team from the
extent
and manufacturer in India. To provide the resume of the support
convenience
staff in India in the format provided in the tender with a copy
of his certification to support the metal machines.
Essential spares
Maintenance parts needed should be provided for 2 years
with the manufacturer service person to provide service every
6 months for 2 years.
Laser Warranty
At least 2 years from the supplier
Materials to be
25 kg of SS powder;
supplied along
10 kg of Ti alloy powder;
with the system
10 kg of Ni alloy powder
The system
• Sand Blaster
should be
• Sieving System
supplied with all
• Wet Separator
the necessary
• Building Platform Steel
following
• Building Platform CoCr
accessories
• Building Platform Aluminium
• Building Platform Titatnium
• Building Platform Ni alloy
• Clamping Bolts and Tools
• Powder preparation van
• Main Filters
• Prefilters
• Powder separator
• Powder Recyling Unit
• Silicon Lips : 10 nos.
• Collecting Bottle
• Breathing Mask (2 Nos.)
• Fire Proof Gloves (4 Nos.)
• Not Flammable Laboratory Coat (2 Nos.)
Software Features Since metal parts needs support beyond a certain angle
different supporting methods like Angle support, Gap
support , Volume support and teeth support are needed for
freedom of part orientation and production to build every
kind of geometry and for faster data preparation. All these
supports details and advantages should be demonstrated
during the technical evaluations
Also the data software should have the following
informations which should be demonstrated by the vendor
during technical evaluation.
Calculation of time – Build platform position- collector
position – platform temperature – Exposure area- recoating
time- Oxygen concentration- Argon hold / fill details- laser
status – laser position monitoring- machine maintenance
status- scanner referencing position and repeatability –
report all changes during job for QA- Mileage counter of
recoater axis- job quality report- part quality report- also in

<!-- page 24 -->

24
case of errors / warnings , identification of which parts could
be affected should be indicated- provide statistical reports on
errors and material changes.
The process software should be able to have the following
-Laser Power Monitoring system to check the laser power for
every nth layer and reporting option of the laser quality via a
QC software
-Reference point calibration for building on performs.
All these software features and advantages should be
demonstrated by the vendor to the technical committee
during technical evaluation.
Manufacturer’s
-Own office in India atleast for 3 years
credentials
-Should have atleast 5 metal machines of the same model
installed in India/Abroad with reference to be provided
-Support for this model available in India
-Stock of the spares in India. stock list to be attached
-Technical Helpline Support in India to be mentioned
-Should provide the credentials of the installed machines
from the customers
OEM / vendor The OEM should be a company which provides the total
credentials
solution by having R&D, Development and Production of
system, software, materials, process and Quality controls.
-Machine supplied should have factory certificate issued as
per ISO 9001 standards. Sample factory certificate should be
attached with the technical bid.
-manufacturer should be able to provide test reports of
materials processed on atleast 10 consecutively produced
metal machines on the mechanical properties like modulus
of elasticity, yield strength, Tensile strength, elongation at
break and density of the core. Sample report to be attached
with the technical bid.
Mill test certificates duly signed by the vendor should be
attached for the powders supplied along with the machine.
Sample Mill test certificate should be attached with the
technical bid
Productivity
- The machine should have an option where within the same
feature
layer itself it should intelligently switch from a smaller focus
to a larger focus area based on the geometry in order to
provide high quality parts in faster time.
Usage of 3rd party The vendor should supply the necessary R&D open source
material options
code software license which can be readily used to develop
parameters for 3rd materials and this open source code
license acts as a platform for 3rd party materials usage of the
machine.
Desirable
As Annamalai University plans to use this system for R&D
Features of the purposes and conduct research on 3D Metal Printing we
System
would be looking on a variety of metal powders including
development of composite metal powders and new metal
powders. The system should be self sufficient and should
have slicing, support generation and machine monitoring
software supplied along with the system

<!-- page 25 -->

25
Tender No. GUCC/DST PURSE II/TENDER2/02/2018-19
SPECIFICATION OF LEAD SHIELD WITH STAND FOR CANBERRA HpGe vertical
detector for Gamma ray spectrometer.
The radiation protection chamber is required for the Gamma ray HpGe vertical detector of Canberra
make.
Chamber height. 635mm; chamber diameter 508mm; Shield Material: outer jacket -9.5mm thick
with low carbon steel material. Bulk shield-10cm thick with low background lead material. Graded
Lining with 1mm tin and 1.6mm copper. The floor of the shield with 12.1cm diameter hold to
accommodate flanged or slimline cryostats and with a door having lever-actuated to prevent
radiation entry. Total weight can be around 1000kg. A stand to hold the above unit with a height of
30inch.
The supplier must extend the support for the installation of the detector and completion of the work.
