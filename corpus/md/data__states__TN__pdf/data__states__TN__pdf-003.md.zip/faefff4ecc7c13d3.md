---
doc_id: "faefff4ecc7c13d3"
source_url: "https://tnmsc.tn.gov.in/linkfiles/tender_notifications/NF1741.pdf"
ministry: "Tamil Nadu Medical Services Corporation Limited (TNMSC), Tamil Nadu"
title: "Download"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "47e3f66fb70a1e9b"
---

<!-- page 1 -->

SI. No

1
2
3
4
1

Tender no. E930/CATH/RC/TNMSC/ENGG/2023, dt.22.02.2023
Sch.1 PTCA guide wire (Work horse or regular) regular length
Name of the firm
Unit Price w/o tax
GST
(Rs)
Imported
M/s. Boston Scientific India Pvt. Ltd.
M/s. Alto Medical Systems (P) Ltd
M/s. 3G Medical Systems
M/s. Davey Pharma and Surgicals
Indigenous
M/s. Trans Healthcare India Pvt Ltd

2340.00

12

2980.00
4100.00
4200.00

12
12
12

3825.00

12

Sch. 2 - PTCA guide wire (speciality wires)
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. Davey Pharma and Surgicals
3600.00
12
2
M/s. Alto Medical Systems (P) Ltd
3990.00
12
Sch. 3 - PTCA guide wire (work horse or regular) Exchange length.
SI. No Name of the firm
Unit Price w/o tax
(Rs)
1
2
3
1

SI. No

1
2
3
4
5
6

1
2

Imported
M/s.3G Medical Systems
M/s. Davey Pharma and Surgicals
M/s. Alto Medical Systems (P) Ltd
Indigenous
M/s. Trans Healtchare India Pvt Ltd

4100.00
4200.00
6990.00

12
12
12

3825.00

12

Sch. 4- Coronary angioplasty balloon dilation catheter.
Name of the firm
Unit Price w/o tax
(Rs)
Imported
M/s. Alto Medical Systems (P) Ltd
3990.00
12
M/s. Davey Pharma and Surgicals
4450.00
12
M/s. 3G Medical Systems Model: NC
4800.00
12
TADPOLE
M/s. 3G Medical Systems Model: HOPER 4800.00
12
M/s. Boston Scientific India Pvt. Ltd.
Model: MAVERICK 2
M/s. Trans Healthcare India Pvt Ltd Model:SIMPASS
Indigenous
M/s. Sahajanand Laser Technology Ltd.
Model:Vector
M/s. Sahajanand Laser Technology Ltd.
Model:Vector NC

4990.00

12

5365.00

12

2767.86

12

2767.86

12

<!-- page 2 -->

3

M/s. M/s.Relisys Medical Devices Limited 2950.00

12

4

4203.00

12

5

M/s. Trans Healthcare India Pvt Ltd
Optima SC/ NC
M/s.3G Medical Systems VALISTA NC

4750.00

12

6

M/s.3G Medical Systems VALISTA SC

4750.00

12

7

M/s.Sahajanand Medical Technologies
5100.00
Limited
Sch. 5 - Puncture needle
Name of the firm
Unit Price w/o tax
(Rs)

SI. No

1
2
3
4
5

SI. No

1
2
3
1
2
3

SI. No

1
2
3
4

Indigenous
M/s. M C Dalal and Co
M/s. 3G Medical Systems
M/s. Relisys Medical Devices Limited
M/s. Trans Healthcare India Pvt Ltd
Model: Trans Needle
M/s. Trans Healthcare India Pvt Ltd
Model: Stake Introducer Needle

27.00
39.00
40.00

12
12
12

80.00

12

102.00

12

Sch. 6- Percutaneous introducer kit- Femoral
Name of the firm
Unit Price w/o tax
(Rs)
Imported
M/s. 3G Medical Systems
570.00
M/s. Sahajanand Medical Technologies
650.00
Pvt Ltd
M/s. Davey Pharma and Surgicals
800.00
Indigenous
M/s. M C Dalal and Co
350.00
M/s. Trans Healthcare India Pvt Ltd
580.00
Make: Edges
M/s. Trans Healthcare India Pvt Ltd
769.00
Make: Translumina
Sch. 7- Percutaneous introducer kit- Radial
Name of the firm
Unit Price w/o tax
(Rs)
Imported
M/s.3G Medical Systems Model: Shoccin 795.00
M/s. Sahajanand Medical Technologies
Limited
M/s.3G Medical Systems Model:
BRILLIANT
M/s. Davey Pharma and Surgicals
Indigenous

12

12
12
12
12
12
12

12

840.00

12

975.00

12

1250.00

12

<!-- page 3 -->

1
2
3

SI. No

M/s. M C Dalal and Co
500.00
M/s. Trans Healthcare India Pvt Ltd
580.00
Make:Edges
M/s. Trans Healthcare India Pvt Ltd
986.00
Make: Translumina
Sch. 8- Percutaneous introducer kit- long sheath
Name of the firm
Unit Price w/o tax
(Rs)

12
12
12

1

Imported
M/s. 3G Medical Systems
1300.00
M/s. Sahajanand Medical Technologies
1800.00
Pvt Ltd
M/s. Davey Pharma and Surgicals
3500.00
Indigenous
M/s. M C Dalal and Co
2300.00
Sch. 9- PTCA – Y connector kit
Name of the firm
Unit Price w/o tax
(Rs)
Imported
M/s. 3G Medical Systems Make: LEPU
498.00

12

2

M/s. Alto Medical Systems (P) Ltd.

580.00

12

3

M/s. Davey Pharma and Surgicals
Indigenous
M/s. M C Dalal and Co
M/s. Relisys Medical Devices Limited

950.00

12

400.00
450.00

12
12

1
2
3
1
SI. No

1
2
3

12
12
12
12

1
2

M/s.3G Medical Systems Model: YSATIS 498.00
(Push Click)
M/s. 3G Medical Systems Model: YSATIS 498.00
(Screw Type)
M/s. Trans Healthcare India Pvt Ltd
540.00
Make: Edges
M/s. Trans Healthcare India Pvt Ltd
653.00
Make: Translumina
Sch. 10- 3 way manifolds
Name of the firm
Unit Price w/o tax
(Rs)
Imported
M/s. 3G Medical Systems
190.00
M/s. Trans Healthcare India Pvt Ltd
840.00
Make: Topcorporation, Japan
Indigenous
M/s.M C Dalal and Co
150.00
M/s. Relisys Medical Devices Limited
200.00

12
12

3

M/s. 3G Medical Systems

12

4
5
6

SI. No

1
2

250.00

12
12
12
12

12
12

<!-- page 4 -->

4

SI. No

1
2

M/s. Trans Healthcare India Pvt Ltd
300.00
Make: Translumina
Sch. 11- High pressure catheter connecting tubing
Name of the firm
Unit Price w/o tax
(Rs)
Indigenous
M/s. M C Dalal and Co
150.00
M/s. Trans Health Care India Private
350.00
Limited Make: P.N.Enterprises

12

12
12

3

M/s. Trans Healthcare India Pvt Ltd
435.00
12
Make: Edges
Sch. 12- Extension tubing with 3 way cock for connecting catheter
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Indigenous
1
M/s. M C Dalal and Co
25.00
12
2
M/s. Trans Healthcare India Pvt Ltd
48.00
12
Make: Edges
3
M/s. Trans Health Care India Private
51.00
12
Limited Make: P.N.Enterprises
SI. No

1
1
2
3

Sch. 13- High pressure inflation device
Name of the firm
Unit Price w/o tax
(Rs)
Imported
M/s. 3G Medical Systems
1400.00
Indigenous
M/s. Relisys Medical Devices Limited
900.00

12
12

900.00
1305.00

12
12

4

M/s. M C Dalal and Co
M/s. Trans Healthcare India Pvt Ltd
Make: Edges
M/s. 3G Medical Systems - Hybrid Type

1400.00

12

5

M/s. 3G Medical Systems - Gun Type

1400.00

12

6

M/s. Trans Healthcare India Pvt Ltd
1509.00
Make: Translumina
Sch. 14- Thrombus aspiration catheters
Name of the firm
Unit Price w/o tax
(Rs)
Indigenous
M/s. M C Dalal and Co
13000.00
M/s. Trans Healthcare India Pvt Ltd
18125.00

SI. No

1
2
3

12

12
12

M/s. 3G Medical Systems
21750.00
12
Sch. 15- Coronary angiogram diagnostic wire- hydrophilic

<!-- page 5 -->

SI. No

1
1
2

SI. No

1
1
2

Name of the firm

Unit Price w/o tax
(Rs)

Imported
M/s. 3G Medical Systems
930.00
12
Indigenous
M/s. Trans Healthcare India Pvt Ltd
1089.00
12
Make: Edges
M/s. Trans Healthcare India Pvt Ltd
1117.00
12
Make: Translumina
Sch. 16- Coronary angiogram diagnostic wire- PTFE coated
Name of the firm
Unit Price w/o tax
(Rs)
Imported
M/s. Davey Pharma and Surgicals
600.00
12
Indigenous
M/s. M C Dalal and Co
160.00
12
M/s. Trans Healthcare India Pvt Ltd
435.00
12

Sch. 17- Coronary angiogram diagnostic wire- Exchange length
Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. Davey Pharma and Surgicals
1100.00
12
Indigenous
1
M/s. 3G Medical Systems
350.00
12
2
M/s. Trans Healthcare India Pvt Ltd
1820.00
12
Make: Rivarp
3
M/s. Trans Healthcare India Pvt Ltd
1842.00
12
Make: Translumina
Sch. 18- Coronary diagnostic catheters- various sizes and shapes
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. Sahajanand Medical Technologies
850.00
12
Limited
Indigenous
1
M/s.M C Dalal and Co
500.00
12
2
M/s. Relisys Medical Devices
750.00
12
3
M/s. 3G Medical Systems
750.00
12
4
M/s. Trans Health Care India Private
1072.00
12
Limited Make: Translumina
SI. No

Sch. 19- Coronary diagnostic catheters- Radial- various sizes and shapes
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. Sahajanand Medical Technologies
880.00
12
Pvt Ltd
Indigenous
1
M/s. M C Dalal and Co
750.00
12

<!-- page 6 -->

2

M/s. Relisys Medical Devices Limited

3
4

M/s. 3G Medical Systems
900.00
12
M/s. Trans Healthcare India Pvt Ltd
1102.00
12
Make: Translumina
M/s. Trans Healthcare India Pvt Ltd
1625.00
12
Make: Rivarp
Sch. 20- Temporary pacemaker lead
Name of the firm
Unit Price w/o tax
(Rs)
M/s. M C Dalal and Co
2250.00
12
Sch. 22- Coronary guiding catheters- Femoral and radial.
Name of the firm
Unit Price w/o tax
(Rs)
Imported
M/s.Boston Scientific India Pvt. Ltd.
2350.00
12

5

SI. No
1
SI. No

1
2

1
2

SI. No

1
2

M/s. Sahajanand Medical Technologies
Limited
Indigenous
M/s. Relisys Medical Devices Limited

2
3
4
5
6
7
8

SI. No

12

3100.00

12

2500.00

12

M/s. Trans Healthcare India Pvt Ltd
3480.00
12
Make: Translumina
Sch. 23- New Generation Coronary Drug Eluting Stents
Name of the firm
Unit Price w/o tax
(Rs)
Imported
M/s.Boston Scientific India Pvt. Ltd.
10800.00
5
M/s. Davey Pharma and Surgicals
Indigenous
M/s. Sahajanand Laser Technology Ltd.
Model Neohexa
M/s. Trans Healthcare India Pvt Ltd

1

750.00

22500.00

5

7238.10

5

7790.00

5

M/s. Relisys Medical Devices Limited

7950.00

5

M/s.Sahajanand Medical Technologies
Limited
M/s. Alto Medical Systems (P) Ltd.

8100.00

5

8100.00

5

M/s.3G Medical Systems
8200.00
Model: STENOFLEX
M/s.3G Medical Systems
8200.00
Model: TRACKMASTER
M/s. Sahajanand Laser Technology Ltd. 9800.00
Model Everpro
Sch. 24- Atrial Septal Defect Closure Device
Name of the firm
Unit Price w/o tax
(Rs)

5
5
5

<!-- page 7 -->

Imported
M/s. 3G Medical Systems
37220.00
5
M/s.Davey Pharma and Surgicals
47500.00
5
Sch. 25- ASD Delivery System (Sheath with cable and Loader)
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. 3G Medical Systems
12000.00
12
2
M/s.Davey Pharma and Surgicals
20000.00
12
Sch. 26- VENTRICULAR SEPTAL DEFECT CLOSURE DEVICE – PERI MEMBRANOUS
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. 3G Medical Systems
43200.00
5
Sch. 28- Ventricular Septal Defect closure Device - Muscular
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. 3G Medical Systems
43200.00
5
2
M/s. Davey Pharma and Surgicals
65000.00
5
Indigenous
1
M/s. Trans Health Care India Private
47600.00
5
Limited
Sch. 29- Post Infarct Ventricular Septal rupture Closure devices
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. Davey Pharma and Surgicals
65000.00
5
Sch. 30- Patent Ductus arteriosus (PDA) Occluder
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. 3G Medical Systems
23400.00
5
2
M/s. Davey Pharma and Surgicals
30500.00
5
Indigenous
1
M/s. Trans Health Care India Private
27300.00
5
Limited
Sch. 31- PDA/VSD Delivery sheath with cable and loader
SI. No Name of the firm
Unit Price w/o tax
(Rs)
Imported
1
M/s. 3G Medical Systems
13000.00
12
2
M/s. Davey Pharma and Surgicals
20000.00
12
Indigenous
1
M/s. Trans Health Care India Private
18200.00
12
Limited
Sch. 32- Delivery cable (5 fr and 6 fr) used for ASD'/PDA'/VSD device delivery
SI. No Name of the firm
Unit Price w/o tax
(Rs)
1
2

<!-- page 8 -->

1

SI. No

1

SI. No

1

Indigenous
M/s. Trans Health Care India Private
7700.00
Limited
Sch. 35- PTMC Balloons
Name of the firm
Unit Price w/o tax
(Rs)
Indigenous
M/s. Trans Health Care India Private
39200.00
Limited
Sch. 36- Accessories for PTMC Balloons
Name of the firm
Unit Price w/o tax
(Rs)
Indigenous
M/s. Trans Health Care India Private
55900.00
Limited

5

12

12
