---
doc_id: "80bcceafaca99759"
source_url: "https://www.scd.tn.gov.in/tender/tender_computers_printers.pdf"
ministry: "Directorate for Welfare of the Differently Abled, Tamil Nadu"
title: "Download"
date: ""
pages: 3
method: "tesseract:tam+eng"
script: "TAMIL"
needs_ocr: false
sha1: "fd4d436b5b6ba5c2"
---

<!-- page 1 -->

Se
தமிழ்நாடு அரசு
மாற்றுத்திறனாளிகள்‌ நல ஆணையரகம்‌,
க,லேடி வெலிங்டன்‌ கல்லூரி வளாகம்‌, காமராஜர்சாலை,சென்னை . 600 005.
hS.61681.3733/2_2_- NflayRIGHTS, 2025 நாள்‌ :07. 012026
மாற்றுத்திறனாளிகளுக்கான உரிமைகள்‌ (8810117$5) திட்டத்தின்‌ கீழ்‌, 17 உட்கோட்டங்களில்‌
செயல்பட உள்ள ஓரிட சேவை மையத்திற்கான அலுவலக கணினி மற்றும்‌ அச்சுப்பொறி
பொருட்கள்‌ கொள்முதல்‌ செய்ய விலைப்புள்ளி விவரங்கள்‌ கோருவது தொடர்பாக,
விண்ணப்பதாரர்களிடமிருந்து விண்ணப்பங்கள்‌ வரவேற்கப்படுகிறது. அதன்‌ விவரம்‌ கீழ்க்கண்டவாறு
தெரிவிக்கபடுகிறது.
ப்பந்தப்புள்ளி
= பவ வழ அறல்‌ கண்வ
| எண்‌ பணியின்‌ விவரம்‌ செய்யப்பட்டநா pan புள்ளிமுறை
or
| 17உட்கோட்டங்களில்‌
(கரூர்‌, சிவகங்கை, தேனி,
திருவாரூர்‌,
4 செங்கல்பட்டு,
'இராணிபேட்டை |
கள்ளக்குறிச்சி மற்றும்‌ g A
திருப்பத்தூர்‌) ஆகிய 8 9 3
| மாவட்டங்களில்‌ 08.01.2026 09.02.2026 09.02.2026 3 g
செயல்பட உள்ள ஓரிட க்‌ g
சேவைமையத்திற்கான ய்‌ &
அலுவலக கணினி ட்‌
மற்றும்‌ அச்சுப்பொறி
பொருட்கள்‌
கொள்முதல்‌ செய்தல்‌
தொடர்பாக
\
ஜா. டி டண ர்‌ =

<!-- page 2 -->

விண்ணப்பங்களை, 6 - procurement portal மூலமாக http:tntenders.gov.in என்ற
வலைதளத்தில்‌ பதிவேற்றம்‌ செய்யவேண்டும்‌
விண்ணப்பங்களை ஏற்பது 7 நிராகரிப்பது தொடர்பாக, திட்ட இயக்குநர்‌ (RIGHTS)
மாற்றுத்திறனாளிகள்‌ நல ஆணையர்‌ அவர்களின்‌ தீர்ப்பே இறுதியானது.
ஒம்‌.
திட்ட இயக்குநர்‌ (Rights) /
மாற்றுத்திறனாளிகள்‌ நல ஆணையர்‌
/ஆணைப்படி //
cers 95
a உதவி use
og"

<!-- page 3 -->

Se’
GOVERNMENT OF TAMIL NADU
COMMISSIONERATE FOR WELFARE OF THE DIFFERENTLY ABLED
5, LADY WILLINGDON COLLEGE CAMPUS, KAMARAJAR SALAI, CHENNAI-600 005.
TENDER NOTICE

Roc.No.3733/A&A/RIGHTS/2025 Dated: 07.01.2026
Bids are invited from eligible bidders for the supply of Computers & Printers for 17 sub divisional
OSC’s across the districts of through e-procurement portal. Details are given below.

S.No Details of the Tender Date of Bid Last date to Date of Mode of
document submit the bid Opening Tender
download

Supply of Computers & 25
ட்- ¢
1 Printers for 17 Sub 08.01.2026 | 09.02.2026 | 09.02.2026 as £3
38
divisional OSC’s ge°
Bids are to be uploaded through e-procurement portal http://tntenders.gov.in
Commissioner for Welfare of the Differently Abled, Chennai-600 005 reserves the right
to accept or reject the tenders without assigning any reason.
Sd/-
Project Director - RIGHTS /
Commissioner for Welfare of the Differently Abled
/By Order/
கு
cre oe
Assistant Director
விவி
