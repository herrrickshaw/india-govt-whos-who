---
doc_id: "dedc175b847cb1cf"
source_url: "https://mtcbus.tn.gov.in/asset/tenders/220FLMCcorrigendum3.pdf"
ministry: "Metropolitan Transport Corporation (Chennai) Ltd., Tamil Nadu"
title: "Tender ID. No. 2026_MTC_668581_1, Ref: RFP No. 00056Proj/MTC/2025 - Corrigendum III - e-tender floated on 28.02.2026 for the Procurement, Supply, Operation & Maintenance of 220 (150Nos of 5Mtr & 70Nos of 7Mtr) Nos of Low Floor Electric Buses and Development of Allied, Electric and Civil Infrastructu"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "97a1e14f2e9276f0"
---

<!-- page 1 -->

METROPOLITAN TRANSPORT CORPORATION (CHENNAI) LTD.,
CORRIGENDUM - III (DATE EXTENSION)
Tender Ref: RFP No. 00056/Proj/MTC/2025
Tender ID. No. 2026_MTC_668581_1

Due to administrative reasons, the e-tender for Procurement, Supply,
Operation & Maintenance of 220 Nos of AC Low Floor (70 Nos – 7m & 150
Nos – 5m) Electric Buses and Development of Allied, Electric and Civil
Infrastructure under Gross Cost Contract (GCC) Model for CMRL First and
Last Mile Connectivity (FLMC) Services has been extended the date for
Submission of Bid End and Opening of e-tender documents in the portal.
The revised schedule is furnished as detailed below:
Clause

As given in Corrigendum - II

To Read as

4. Last date for downloading the
Bid documents from the eof procurement portal: 28.04.2026 at
16.00Hrs.

4. Last date for downloading the
Bid documents from the eprocurement portal: 15.05.2026
at 16.00Hrs.

1.4.1: Schedule of 5. Bid submission-Bid Due Date:
Bidding Process is 28.04.2026, at 16.00Hrs.
set out below
7. Opening date and time of
Technical
Bid: 28.04.2026 at
Page No:12
16.30Hrs.

5. Bid submission-Bid Due Date:
15.05.2026, at 16.00Hrs.

1. Introduction
1.4:
Schedule
Bidding Process

2. Instructions to
Bidders
2.12- Bid Due Date

Page No:29

7. Opening date and time of
Technical Bid: 15.05.2026 at
16.30Hrs.

On or before 15.05.2026 at
On or before 28.04.2026 at
16.00Hrs.
16.00Hrs.
Documents shall be physically
Documents shall be physically
submitted
on
or
before
submitted on or before 02.05.2026.
18.05.2026.

Page No:3

9. Bid Due Date: 28.04.2026; Time: 9. Bid Due Date: 15.05.2026;
16:00Hrs.
Time: 16:00Hrs.

2.15Online
Opening of Bids

on 28.04.2026 at 16.30Hrs.

DATA SHEET

Page No:30

on 15.05.2026 at 16.30Hrs.

Managing Director
