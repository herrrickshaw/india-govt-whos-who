---
doc_id: "5f21bc9ef7c94daf"
source_url: "https://www.tniuscbe.org/download/go/go2241.pdf"
ministry: "Tamil Nadu Institute of Urban Studies (TNIUS), Coimbatore, Tamil Nadu"
title: ""
date: ""
pages: 4
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "ea7490fdb9e5394a"
---

<!-- page 1 -->

ABSTRACT
Municipal Administration and Water Supply Department - Construction of
new bus stands with the financial assistance from Infrastructure and
Amenities Fund in Tiruppur and Hosur Corporations; and Guddalur (T),
Ariyalur, Vadalur, Vedaranyam, Melur, Pattukottai, Colachel and Pollachi
Municipalities - Administrative Sanction - Accorded - Orders Issued.
Municipal Administration & Water Supply (MA.IV) Department
6.0.(145) No.173 Dated 08.12.2022
சுபகிருது வருடம்‌, கார்த்திகை-22
திருவள்ளுவர்‌ ஆண்டு - 2053
Read:-
1. Letter No.8041/UD4(1)/2022-4, Housing and Urban
Development Department, dated:25.07.2022.
2. From the Director of Municipal Administration, Letter
Roc.No.11112/2022/TP-2, dated:03.11.2022.
ORDER:

The Director of Municipal Administration in his letter 278 read above
has stated that the Hon’ble Minister for Municipal Administration during
the budget session 2022-2023 has announced on the floor of the
Legislative Assembly that new bus stands will be constructed in certain
Corporations and Municipalities. Based on the above announcement, the
Director of Municipal Administration has sent proposal to Government for
Construction of bus stands under Infrastructure and Amenities fund. The
19" State Infrastructure Amenities Promotion Committee vide letter first
read above, has approved to provide 50% of the estimated cost for the
construction of new bus stands from Infrastructure and Amenities fund as
grant.

2. The Director of Municipal Administration has informed that the
financial tie-up for the balance amount required for construction of bus
stands has been made by dovetailing funds from various other schemes.
Since bus stands are mostly located in high footfall area, it has been
decided to fund the public toilet component by utilising funds under
Swachh Bharat Mission 2.0.. Likewise, the commensurate cost towards

<!-- page 2 -->

2 *
components like compound wall will be met from the 15" Finance
Commission untied grant. The cost for construction of shops will be met
out of the amount to be collected by pre-auction of the shops and the
works like two wheeler parking shed will be met out by the respective
Urban Local Bodies from their own revenue. The financial tie-up has
been made based on the annual income of the Urban Local Bodies, their
previous liabilities and expected income etc.

3. The Director of Municipal Administration has also stated that the
estimate cost, concept plan and financial plan has been prepared for the
following 10 Urban Local Bodies. The details of fund tie up are as
furnished in the table below.

(Rs. in crore) |
|
| Estimate (..., A =
Name ofthe: Costas Estimate | Fund tie up arrangements
SI. | Urban Local | placed in cok Infra | = | Pre
No. Body IRA ட்‌ | structure 15 = Capital
Committee | 2'tived | & SBM | FC மல்‌ ண்ட Grant
| [Aanertles 2.0 | grant shops Fund
| | fund
Municipal Corporations
Municipalities |
| |
நனி Vedaranyam 4:00 | 4.00 | 2.00 | 0.30 0.50 ன்‌
நட ணு வட பவ சண வவ |
Ese ட்‌ |
Total 120.80 | 115.37 57.05 3.21 | 20.22 |17.52 | 10.00
4. The Director of Municipal Administration has requested the
Government to accord administrative sanction for the construction of new
bus stands in 2 municipal corporations and 8 municipalities with the
financial assistance from Infrastructure and Amenities Fund, Swachh
Bharat Mission 2.0., 15 Finance Commission Grant, Urban Local
Bodies contribution, anticipated income from pre-auction of shops and
Capital Grant Fund as mentioned in the table at paragraph 3 above.

<!-- page 3 -->

5 3

5. The Government after careful examination of the proposal of the
Director of Municipal Administration have decided to accord administrative
sanction for the construction of new bus stands at Tiruppur and Hosur
Municipal Corporations; and Guddalur (T), Ariyalur, Vadalur, Vedaranyam,
Melur, Pattukottai, Colachel and Pollachi Municipalities, at a total project
of Rs.115.37 crore with the fund tie up arrangements given in the table at
paragraph 3 above.

6. The Director of Municipal Administration (DMA) is directed to
obtain the approval of the respective project sanctioning committees for
utilising funds under Swachh Bharat Mission 2.0. and Capital Grant
Fund (CGF). The Director of Municipal Administration is also directed to
inform the revised allocation from Infrastructure and Amenities Fund to
the Infrastructure and Amenities Committee.

7. This order issues with the concurrence of Finance Department
vide its U.O. No.4291/FS/P/2022, dated:11.11.2022.

(BY ORDER OF THE GOVERNOR)
SHIV DAS MEENA
ADDITIONAL CHIEF SECRETARY TO GOVERNMENT

To

The Director of Municipal Administration, Chennai -600 028.

The Commissioners of Corporations and Municipalities concerned.
(through Director of Municipal Administration)

/ the Regional Director of Municipal Administration concerned.
(through Director of Municipal Administration)

The Housing & Urban Development Department, Chennai-600 009.

The Finance Department, Chennai-600 009.

Copy to

The Hon’ble Chief Minister’s office, Chennai-600 009.
(C.No.18056/MA-IV(2)/2022)

The Senior Personal Assistant to Hon’ble Minister
(Municipal Administration), Chennai -600 009.

The Senior Personal Assistant to Hon’ble Minister
(Housing & Urban Development), Chennai -600 009.

The Senior Personal Assistant to Hon'ble Minister
(Finance, Human Resource Management), Chennai -600 009.

The Private Secretary to Chief Secretary to Government,

Chennai- 600 009.

The Private Secretary to Additional Chief Secretary to Government,
Municipal Administration and Water Supply Department,
Chennai- 600 009.

The Private Secretary to Additional Chief Secretary to Government,
Finance Department, Chennai- 600 009.

<!-- page 4 -->

ட்‌ a

The Private Secretary to Principal Secretary to Government,

Housing & Urban Development Department,

Chennai- 600 009.
The Municipal Administration and Water Supply (OP-II) Department,

Chennai- 600 009.
Stock file / Spare copies.

//FORWARDED BY ORDER//
ie
beak
