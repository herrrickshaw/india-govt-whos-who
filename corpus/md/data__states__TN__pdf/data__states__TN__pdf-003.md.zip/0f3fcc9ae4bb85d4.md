---
doc_id: "0f3fcc9ae4bb85d4"
source_url: "https://tnpcb.gov.in/PDF/Updates/Whats_New/Circular_liquidfuel15326.pdf"
ministry: "Tamil Nadu Pollution Control Board (TNPCB), Tamil Nadu"
title: "Temporary approval for use of liquid fuel in view of the disruption in gas supply to the industries.  More"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "218b0fc27f38f19f"
---

<!-- page 1 -->

Tamil Nadu Pollution Control Board
Circular
Sub: TNPCB - Temporary approval for use of liquid fuel such as kerosine, High
Speed Diesel (HSD), Furnace Oil, Refuse Derived Fuel (RDF) and biomass
in view of the disruption in gas supply to industries due to geopolitical
tensions – Reg.
Currently, the ongoing war-like situation in East Asia (Middle East) and
geopolitical tensions have led to a major disruption in gas supply at the international
level, which is likely to have an adverse impact on the production in industries in the
State.
In order to maintain the efficiency of the industries in the State and ensure that
economic activities do not come to a standstill, the Board issues the following
temporary instructions:
Industries in which gas-based utilities are currently operating, due to lack of
gas, they are permitted to use fuel such as kerosine, High Speed Diesel (HSD),
Furnace Oil, Refuse Derived Fuel (RDF) and Biomass etc., for which the industries
are not required to obtain separate Consent to Operate of TNPCB. But the Board have
to be informed in detail the name of the Utilities, capacity, name and quantity of fuels
utilized.
This circular will be in force for a period of three months from the date of issue
and after one month, the Board will review the situation and issue appropriate
directions.

Member Secretary
Tamil Nadu Pollution Control Board
