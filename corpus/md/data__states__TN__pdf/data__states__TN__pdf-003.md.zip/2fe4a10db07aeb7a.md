---
doc_id: "2fe4a10db07aeb7a"
source_url: "http://tnau.ac.in/site/wp-content/uploads/2026/02/Solar_Website.pdf"
ministry: "Tamil Nadu Agricultural University (TNAU), Tamil Nadu"
title: "Tender for purchase of Solar panels for Irrigation and Sprayer to the Director, Agro Climate Research Centre (ACRC), Directorate of Crop Management (DCM), Tamil Nadu Agricultural University (TNAU), Coimbatore – 641 003. Last Date: 3.00 PM on 27.02.2026"
date: ""
pages: 42
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "de1940f157075d38"
---

<!-- page 1 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003

Telephone

: 0422-6611316

E-mail

: directorscms@tnau.ac.in

Tender invited for of the purchase of “Solar panels for Irrigation and Sprayer” to the
Agro Climate Research Centre (ACRC), Directorate of Crop Management (DCM), Tamil
Nadu Agricultural University (TNAU), Coimbatore – 641 003.

Bid reference

: No. DCM/ACRC/ DST- CoE/Solar panels/2026 dt.
12.02.2026

Pre-bid meeting

: 18.02.2026 at 3.30 PM

Last date for receipt of tenders : 27.02.2026, 3.00 PM
Time and date of opening of
technical bids

: 27.02.2026, 4.00 PM

Place of opening of bids

: Office of the Director,
Directorate of Crop Management
Tamil Nadu Agricultural University
Coimbatore – 641 003

Address for communication and : The Director
submission of bids
Directorate of Crop Management
Tamil Nadu Agricultural University
Coimbatore – 641 003

1

<!-- page 2 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003

This page intentionally left Blank

2

<!-- page 3 -->

<!-- page 4 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003

This page intentionally left Blank

4

<!-- page 5 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION II
Instructions to Bidders
Table of Clauses
Clause No.
Topic Number
A. Introduction
1.
Eligible Bidders
2.
Cost of Bidding
B. Bidding Documents
3.
Contents of Bidding, Documents
4.
Clarification of Bidding Documents
5.
Amendment of Bidding Documents
C. Preparation of Bids
6.
Language of Bid
7.
Documents Comprising the Bid
8.
Bid Form
9.
Bid Prices
10.
Bid Currencies
11.
Documents Establishing Bidder’s Eligibility and Qualifications
12.
Documents Establishing Goods Conformity to Bid Documents
13.
Bid Security
14.
Period of Validity of Bids
15.
Format and Signing of Bid
D. Submission of Bids
16.
Sealing and Marking of Bids
17.
Deadline for Submission of Bids
18.
Late Bids
19.
Modification and withdrawal of Bids
E. Bid Opening and Evaluation
20.
Opening of Bids
21.
Clarification of Bids
22.
Preliminary Examination
23.
Evaluation and Comparison of Bids
24.
Contacting the Purchaser
F. Award of Contract
25.
Post-qualification
26.
Award Criteria
27.
Purchaser’s Right to Vary Quantities at Time of Award
28.
Purchaser’s Right to Accept any Bid and to Reject any or all Bids
29.
Notification of Award
30.
Signing of Contract
31.
Performance Security

5

<!-- page 6 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION II: Instruction to Bidders (ITB)
A. INTRODUCTION
1.
1.1
1.2

1.3

2.
2.1

Eligible Bidders
Manufacturers or their authorized representatives are eligible to participate in
this tender.
Bidders should not be associated, or have been associated in the past, directly or
indirectly, with a firm or any of its affiliates which have been engaged by the
Purchaser to provide consulting services for the preparation of the design,
specifications, and other documents to be used for the procurement of the goods to
be purchased under this Invitation of Bids.
Government-owned enterprise may participate only if they are legally and
financially autonomous, if they operate under commercial law, and if they are not a
dependent agency of the purchaser.
Cost of Bidding
The Bidder shall bear all costs associated with the preparation and submission of its
bid and The Director, Directorate of Crop Management, TNAU, Coimbatore –
641003 hereinafter referred to as “the Purchaser”, will in no case be responsible or
liable for these costs, regardless of the conduct or outcome of the bidding process.

B. BIDDING DOCUMENTS
3.
3.1

Contents of Bidding Documents
The goods required, bidding procedures and contract terms are prescribed in the
Bidding documents.
In addition to the Invitation for Bids, the Bidding Documents include:
a. Instruction to Bidders (ITB)
b. General Conditions of Contract (GCC)
c. Special Conditions of Contract (SCC)
d. Schedule of Requirements;
e. Technical Specifications / Qualification criteria;
f. Bid Form and Price Schedules;
g. Bid Security form
h. Contract Form;
i. Performance Security Form;
j. Performance statement
k. Manufacturer’s Authorization Form and
l. Bank Guarantee for Advance Payment Form

3.2

The Bidder is expected to examine all instructions, forms, terms and specifications
in the Bidding Documents. Failure to furnish all information required by the
Bidding Documents or submission of a bid not substantially responsive to the
Bidding Documents in every respect will be at the Bidder’s risk and may result in
rejection of its bid.

6

<!-- page 7 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003

4.
4.1

Clarification of Bidding Documents
A prospective Bidder requiring any clarification of the Bidding Documents may
notify the Purchaser in writing or by telex or cable at the Purchaser’s mailing
address indicated in the Invitation for Bids. The Purchaser will respond in writing
to any request for clarification of the Bidding Documents which it receives not later
than 7 days prior to the deadline for submission of bids prescribed by the Purchaser.
Written copies of the Purchaser’s response (including an explanation of the query
but without identifying the source of inquiry) will be sent to all prospective Bidders
which have received the bidding documents.

5.
5.1

Amendment of Bidding Documents
At any time prior to the deadline for submission of bids, the Purchaser may, for any
reason, whether at its own initiative or in response to a clarification requested by a
prospective bidder, modify the Bidding Documents by an amendment.
All prospective bidders who have received the Bidding Documents will be
notified of the amendment in writing or by cable and will be binding on them.
In order to allow prospective bidders reasonable time in which to take the
amendment into account in preparing their bid, the Purchaser may, at its discretion,
extend the deadline for the submission of bids.

5.2
5.3

C. PREPARATION OF BIDS
6.
6.1
6.2

Language of Bid
The Bid prepared by the bidder and all correspondence and documents relating
to the bid exchanged by the Bidder and the Purchaser, shall be written in the
English language.
Supporting documents and printed literature furnished by the Bidder may be written
in another language provided they are accompanied by an accurate translation of the
relevant passages in the English language in which case, for purposes of
interpretation of the Bid, the English translation shall govern.

7. Documents Comprising the Bid
7.1
The bid prepared by the Bidder shall comprise the following components:
a) Bid Form and Price Schedule completed in accordance with ITB Clauses 8, 9 and
10;
b) documentary evidence established in accordance with ITB Clause 11 that the Bidder
is eligible to bid and is qualified to perform the contract if its bid is accepted;
c) documentary evidence established in accordance with ITB Clause 12 that the goods
and ancillary services to be supplied by the Bidder shall confirm to the Bidding
Documents; and
d) Bid Security furnished in accordance with ITB Clause 13.
8.
8.1

Bid Form
The Bidder shall complete the Bid Form and the appropriate Price Schedule
furnished in the bidding documents, indicating for the goods to be supplied, a
brief description of the goods, their country of origin, quantity and prices.

7

<!-- page 8 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003

9.
9.1

Bid Prices
The Bidder shall indicate on the Price Schedule the unit prices and total Bid
prices of the goods it proposes to supply under the Contract.
9.2
Prices indicated on the Price Schedule shall be entered separately in the
following manner:
(i)
The price of the goods, quoted ex-factory, ex-show-room, ex-warehouse, or off theshelf, or delivered, as applicable, including all duties and sales and other taxes
already paid or payable:
a) On components and raw material use in the manufacture or assembly of the goods
quoted ex-factory; or
b) on the previously imported goods of foreign origin quoted ex-showroom, exwarehouse or off-the-shelf.
(ii)
any purchaser-country sales and other taxes which will be payable on the
goods if this contract is awarded;
(iii) charges for inland transportation, insurance and other local costs
incidental to delivery of the goods to their final destination; and
(iv)
the cost of incidental services listed in Clause 7 of the Special Conditions
of Contract.
9.3
The Bidders separation of the price components in accordance with ITB Clause 9.2
above will be solely for the purpose of facilitating the comparison of bids by the
Purchaser and will not in any way limit the Purchaser’s right to contract on any of
the terms offered.
9.4
Fixed price: Prices quoted by the Bidder shall be fixed during the Bidder’s
performance of the contract and not subject to variation on any account. A bid
submitted with an adjustable price quotation will be treated as non-responsive
and rejected, pursuant to ITB Clause 22.
10.
10.1

Bid Currencies
Prices shall be quoted in Indian Rupees/ Foreign currency

11.
11.1

Documents establishing bidder’s eligibility and qualifications
Pursuant to ITB Clause 7, the bidder shall furnish, as part of its bid, documents
establishing the bidder’s eligibility to bid and its qualifications to perform the
Contract if its bid is accepted.
The documentary evidence of the Bidder’s qualifications to perform the Contract
if its bid is accepted, shall establish to the Purchaser’s satisfactions.
that, in the case of a Bidder offering to supply goods under the contract which the
Bidder did not manufacture or otherwise produce, the Bidder has been duly
authorised (as per authorization form in Section XII) by the goods manufacturer or
produce to supply the goods in India.
that the bidder has the financial, technical and production capability necessary to
perform the Contract and meets the criteria outlined in the qualification requirements
specified in Section VI-A. To this end, all bids submitted shall include the following
information:
(i)
The legal status, place of registration and principle place of business of the
company or firm or partnership, etc;
(ii)
Details of experience and past performance of the bidder on equipment
offered and on those of similar nature within the past 10 years and details of

11.2
(a)

(b)

8

<!-- page 9 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
current contracts in hand and other commitments (suggested proforma given
in Section XI)
12. Documents establishing goods conformity to bidding documents
12.1 Pursuant to ITB Clause 7, the Bidder shall furnish, as part of its bid, documents
establishing the conformity to the bidding documents of all goods and services
which the bidder proposes to supply under the contract.
12.2 The documentary evidence of conformity of the goods and services to the
bidding documents may be in the form of literature, drawings and data and shall
consist of:
(a)
a detailed description of the essential technical and performance characteristics of
the goods;
(b)
a list giving full particulars, including available sources and current prices, of all
spare parts, special tools, etc., necessary for the proper and continued functioning of
the goods for a period of three years, following commencement of the goods used
by the Purchaser; and
(c)
an item-by-item commentary on the Purchaser’s Technical Specifications
demonstrating substantial responsiveness of the goods and services to those
specifications or a statement of deviations and exceptions to the provisions of the
Technical Specifications.
12.3 For the purpose of the commentary to be furnished pursuant to ITB Clause 12.2
© above, the Bidder shall note that standards for workmanship, material and
equipment and references to brand names or catalogue numbers designated by
the Purchaser in its Technical Specifications are intended to be descriptive only
and not restrictive. The Bidder may substitute alternative standards, brand
names and/or catalogue numbers in its bid, provided that it demonstrates to the
Purchaser’s satisfaction that the substitutes are substantially equivalent or
superior to those designated in the Technical Specifications.
13.
13.1
13.2
13.3

13.4
13.5
13.6
13.7

Bid Security
Pursuant to ITB Clause 7, the Bidder shall furnish, as part of its bid, bid security for
the amount as indicated in Section V schedule of requirements.
The bid security is required to protect the Purchaser against risk of Bidders conduct
which would warrant the security’s forfeiture, pursuant to ITB Clause 13.7.
The bid security shall be in Indian Rupees and shall be in one of the following
forms:
a. A Bank Guarantee or an irrevocable letter of credit issued by a nationalized
/scheduled bank located in India, in the form provided in the bidding document or
any other form acceptable to the purchaser and valid for 45 days beyond the validity
of the bid; or
b. A demand draft on any scheduled / nationalized bank in favour The Professor
and Head, Agro Climate Research Centre, TNAU, Coimbatore – 641003.
Any bid not secured in accordance with ITB Clauses 13.1 and 13.3 above will be
rejected by the Purchaser as non-responsive, pursuant to ITB Clause 22.
Unsuccessful bidders bid security will be discharged/returned as promptly as
possible but not later than 30 days after the expiry of the period of bid validity
prescribed by the Purchaser, pursuant to ITB Clause 14.
The successful bidder’s bid security will be discharged upon the bidders signing the
contract, pursuant to ITB Clause 30, and furnishing the security, pursuant to ITB
Clause 31.
The bid security may be forfeited:
9

<!-- page 10 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
(a)
(b)

14.
14.1
14.2

15.
15.1
15.2

15.3

If a bidder withdraws its bid during the period of bid validity specified by
the Bidder on the Bid form;
(or)
In case of a successful bidder, if the bidder fails:
(i)
to sign the contract in accordance with ITB Clause 30; or
(ii)
to furnish performance security in accordance with ITB Clause 31.

Period of Validity of Bids
Bids shall remain valid for 90 days after the date of bid opening prescribed by
the Purchaser, pursuant to ITB Clause 17. A bid valid for a shorter period may be
rejected by the Purchaser as non-responsive.
In exceptional circumstances, the Purchaser may solicit the bidders’ consent to an
extension of the period of validity. The request and the responses thereto shall be
made in writing (or by cable or telex). The bid security provided under ITB Clause
13 shall be suitably extended. A bidder may refuse the request without forfeiting its
bid security. A bidder granting the request is not required or permitted to modify its
bid.
Format and Signing of Bid
The bidder shall prepare two copies of the bid clearly marking each “Original
Bid” and “Copy Bid” as appropriate. In the event of any discrepancy between
them, the original shall govern.
The original and all copies of the bid shall be typed or written in indelible ink
and shall be signed by the Bidder or a person or persons duly authorized to bind
the Bidder to the Contract. The letter of Authorization shall be indicated by
written power-of-attorney accompanying the bid. All pages of the bid, except for
unamended printed literature, shall be initialled by the person or persons signing
the bid.
Any interlineations, erasures or overwriting shall be valid only if they are
initialled by the person or persons signing the bid.

D.

SUBMISSION OF BIDS

16.
16.1

Sealing and Marking of Bids
The bidders shall seal the original and a copy of the bid in separate inner
envelopes duly marking the envelopes as “Original Bid" and “Copy Bid". He/she
shall then place these two inner envelopes in an outer envelope. This has to be
done for both technical and price bid individually.
The inner envelope and outer envelopes and the cover shall be:
(a) Addressed to the Purchaser at the following address:
The Director, Directorate of Crop Management, TNAU, Coimbatore – 641003

16.2

(b) Bear the project name “DCM – ACRC - DST-CoE- Solar panels for Irrigation
and Sprayer”, the invitation for bids (IFB) number and the words “Do not open
before 04.00 PM on 27.02.2026”.
16.3

The inner envelopes shall indicate the name and address of the bidder to enable
the bid to be returned unopened in case it is declared “late”.
10

<!-- page 11 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
16.4
16.5
17.
17.1

17.2

18.
18.1

If the cover containing the outer envelope is not sealed and marked as required
by ITB Clause 16.2, the Purchaser will assume no responsibility for the bid’s
misplacement or premature opening.
Telex, cable or facsimile bids will be rejected.
Deadline for Submission of Bids
Bids must be received by the Purchaser at the address specified under ITB Clause
16.2 not later than the time and date specified in the Invitation of Bids (Section I).
In the event of the specified date for the submission of bids being declared a holiday
for the Purchaser, the bids will be received up to the appointed time on the next
working day.
The Purchaser may, at its discretion, extend this deadline for submission of bids by
amending the bid documents in accordance with ITB Clause 5, in which case all
rights and obligations of the purchasers and bidders previously subject to the
deadline will thereafter be subject to the deadline as extended.
Late Bids
Any bid received by the Purchaser after the deadline for submission of bids
prescribed by the Purchaser, pursuant to ITB Clause 17, will be rejected and/or
returned unopened to the Bidder.

19.
19.1

Modification and Withdrawal of Bids
The bidder may modify or withdraw its bid after the bid’s submission, provided
that written notice of the modification or withdrawal is received by the
Purchaser prior to the deadline prescribed for submission of bids.
19.2 The bidder’s modification or withdrawal notice shall be prepared, sealed, marked
and dispatched in accordance with the provisions of ITB Clause 16. A
withdrawal notice may also be sent by telex or cable but followed by a signed
confirmation copy, post marked not later than the deadline for submission of
bids.
19.3 No bid may be modified subsequent to the deadline for submission of bids.
19.4 No bid may be withdrawn in the interval between the deadline for submission of
bids and the expiration of the period of bid validity specified by the bidder on
the bid form. Withdrawal of a bid during this interval may result in the bidders
forfeiture of its bid security, pursuant to Clause 13.7
E.
20.
20.1

Bid Opening and Evaluation
Opening of Bids by Purchaser
The Purchaser will open only all bids, in the presence of bidder's representatives
who choose to attend, at 4.00 PM on 27.02.2026 at the following location:
The Director
O/o Directorate of Crop Management
TNAU, Coimbatore – 641003.
The bidder’s representatives who are present shall sign a register evidencing their
attendance. In the event of the specified date of bid opening being declared a holiday
for the Purchaser, the bids shall be opened at the appointed time and location on the
next working day.
11

<!-- page 12 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
20.2

20.3
20.4
21.
21.1

22.
22.1

22.2

22.3
22.4

22.5
23.
23.1

The bidders names, modifications, bid withdrawals and the presence or absence
of the requisite bid security and such other details as the Purchaser, at its
discretion, may consider appropriate will be announced at the opening. No bid
shall be rejected at bid opening, except for late bids, which shall be returned
un opened to the bidder pursuant to ITB Clause 18.
The Purchaser will prepare minutes of the bid opening.
The “Price Bid” (Cover B) will be opened after evaluation of “Technical bids”
(Cover A) and the date and time will be intimated to bidders whose bids are
responsive and who are selected by the Purchaser.
Clarification of Bids
During evaluation of bids, the Purchaser may, at its discretion, ask the bidder for
clarification of its bid. The request for clarification and the response shall be in
writing. Unless the purchaser asks for change in price due to the clarifications sought
the bidder is not permitted to alter the price furnished in the “Price bid” “Cover
B”. The change in price shall be submitted in a separately sealed covers with
marking in the cover “supplemental price bid” before opening of the “original
price bid”.
Preliminary Examination
The Purchaser will examine the bids to determine whether they are complete,
whether any computational errors have been made, whether required sureties
have been furnished, whether the documents have been properly signed, and
whether the bids are generally in order. Bids from Representatives, without
proper authorization from the manufacturer as per Section XII, shall be treated as
non-responsive.
Arithmetical errors will be rectified on the following basis. If there is a discrepancy
between the unit price and the total price that is obtained by multiplying the unit
price and quantity, the unit price shall prevail and the total price shall be corrected.
If the supplier does not accept the correction of errors, its bid will be rejected. If
there is a discrepancy between words and figures, the amount in words will prevail.
The Purchaser may waive any minor informality or non-conformity or
irregularity in a bid which does not constitute a material deviation, provided
such a waiver does not prejudice or affect the relative ranking of any bidder.
Prior to the detailed evaluation, pursuant to Clause ITB 23, the Purchaser will
determine the substantial responsiveness of each bid to the bidding documents.
For purposes of these clauses a substantially responsive bid is one which
conforms to all the terms and conditions of the bidding documents without
material deviations. Deviations from or objections or reservations to critical
provisions such as those concerning Performance Security (GCC Clause 6).
Warranty (GCC Clause 14), Force Majeure (GCC Clause 24), Applicable law
(GCC Clause 29) and Taxes and Duties (GCC Clause 31) will be deemed to be
material deviation. The purchaser’s determination of bids responsiveness is to
be based on the contents of the bid itself without recourse to extrinsic evidence.
A bid determined as not substantially responsive will be rejected by the
Purchaser and may not subsequently be made responsive by the bidder by
correction of non-conformity.
Evaluation and Comparison of Bids
The Purchaser will evaluate and compare bids previously determined to be
substantially responsive, pursuant to ITB Clause 22.
12

<!-- page 13 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
23.2 The purchasers evaluation of a bid will take into account, in addition to the bid
price (exfactory/ ex-warehouse/off-the-shelf price of the goods offered from
within India, such price to include all costs as well as duties and taxes paid or
payable on components and raw material incorporated or to be incorporated in
the goods, and excise duty on the finished goods, if payable) and price of
incidental services, the following factors, in the manner and to the extent
indicated in ITB Clause 23.3 and in the technical specifications:
(a) i) cost of inland transportation, insurance and other costs within India incidental
to the delivery of goods to their final destination;
ii) The annual maintenance contract for a period of 3 years subsequent
to comprehensive warranty for a period of three years
(b)
delivery schedule offered in the bid;
(c)
deviations in payment schedule from that specified in the special
conditions of contract
(d)
the availability in India of spare parts and after-sales services for the
equipment offered in the bid.
23.3 Pursuant to ITB Clause 23.2 the following evaluation methods will be applied:
(a)
Evaluation and comparison of tenders will be done taking in to consideration
the cost of AMC for a period of 3 years after the comprehensive warranty for
a period of three years as specified at clause 23.2 (a) (ii).
(b)
Inland transportation, ex-factory/ from port-of-entry, insurance and
incidentals.
(i)
Inland transportation, insurance and other incidentals, for delivery
of goods to the project site as stated in ITB Clause 9.2 (iii).
The above costs will also be added to the bid price.
(c) Delivery schedule:
The Purchaser desires to have delivery of the goods covered under the
invitation, at the time specified in the schedule of requirements. The estimated time
of the arrival of the goods at the project site should be calculated for each bid after
allowing for reasonable transportation time. Treating the bid offering the scheduled
time of arrival as the base, a delivery “adjustment” will be calculated for other bids
at 2% of the ex-factory price for each month of delay beyond the base and this will
be added to the bid price for evaluation. No credit will be given to earlier deliveries
and bids offering delivery beyond 2 months of stipulated delivery will be treated as
unresponsive.
(d) Deviation in Payment Schedule:
The special conditions of contract indicate the payment schedule offered by
the Purchaser. If a bid deviates from the schedule and if such deviation is considered
acceptable to the Purchaser, the bid will be evaluated by calculating interest earned
for any earlier payments involved in the terms outlined in the bid as compared to
those stipulated in this invitation at a rate of 12% per annum.
(e) Spare parts and after sales service facilities in India:
The cost of the Purchaser of establishing the minimum service facilities and
parts inventories, as outlined elsewhere in the bid invitation, if quoted separately,
shall be added to the bid price.
(f) Annual Maintenance Contract (AMC):
i. The Purchaser desires to have separately annual maintenance
contract for a period of 3 years after the expiry, clearly indicating year
wise maintenance charges. Bids without these charges will be
13

<!-- page 14 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
considered as non-responsive. The right to enter in to AMC lies with
the University.
ii. Any major repair pointed out by the Purchaser shall be rectified by the
Supplier from the date of intimation within a period of 3 calendar days
and commission the equipment to the satisfaction of the Purchaser.
24.
24.1
24.2

Contacting the purchaser
Subject to ITB Clause 21, no bidder shall contact the Purchaser on any matter
relating to its bid, from the time of bid opening to the time the contract is
awarded.
Any effort by a bidder to influence the Purchaser in the Purchaser’s bid
evaluation, bid comparison or contract award decisions may result in rejection
of the bidders bid.

F. AWARD OF CONTRACT
25.
25.1

25.2

25.3

26.
26.1

27.
27.1
28.
28.1

29.
29.1

Post Qualification
In the absence of pre-qualification, the Purchaser will determine to its satisfaction
whether the bidder that is selected as having submitted the lowest evaluated
responsive bid meets the criteria specified in ITB Clause 11.2 (b) and is qualified to
perform the contract satisfactorily.
The determination will take into account the bidders financial, technical and
production capabilities. It will be based upon an examination of the
documentary evidence of the bidders qualifications submitted by the bidder,
pursuant to ITB Clause 11 as well as such other information as the Purchaser
deems necessary and appropriate.
An affirmative determination will be a prerequisite for award of the contract to
the bidder. A negative determination will result in rejection of the bidders bid, in
which event the Purchaser will proceed to the next lowest evaluated bid to
make a similar determination of that bidder’s capability to perform
satisfactorily.
Award Criteria
Subject to ITB Clause 28, the Purchaser will award the contract to the successful
bidder whose bid has been determined to be substantially responsive and has
been determined as the lowest evaluated bid, provided further that the bidder is
determined to be qualified to perform the contract satisfactorily.
Purchaser’s right to vary quantities at time of award
The Purchaser reserves the right at the time of award of contract to increase or
decrease the quantity of goods and services originally specified in the schedule
of requirements without any change in unit price or other terms and conditions.
Purchaser’s right to accept any bid and to reject any or all bids
The Purchaser reserves the right to accept or reject any bid, and to annul the
bidding process and reject all bids at any time prior to award of contract, without
thereby incurring any liability to the affected bidder or bidders or any obligation
to inform the affected bidder or bidders of the grounds for the purchasers action.
Notification of Award
Prior to the expiration of the period of bid validity, the Purchaser will notify
the successful bidder in writing by registered letter or by cable or telex, to be
confirmed, that its bid had been accepted.
14

<!-- page 15 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
29.2
29.3

The notification of award will constitute the formation of the contract.
Upon the successful bidders furnishing of performance security pursuant to ITB
Clause 31, the Purchaser will promptly notify each unsuccessful bidder and will
discharge its bid security, pursuant to ITB Clause 13.

30.
30.1

Signing of Contract
At the same time as the Purchaser notifies the successful bidder that its bid has
been accepted, the Purchaser will send the bidder the contract form provided in
the bidding documents, incorporating all agreements between the parties.
Within 15 days of receipt of notification of award, the successful bidder shall sign
and date the contract and return it to the Purchaser.
Performance Security
Within 15 days of the receipt of notification of award from the Purchaser, the
successful bidder shall furnish the performance security in accordance with the
conditions of contract, in the performance security form provided in the bidding
documents or in another form acceptable to the Purchaser.
Failure of the successful bidder to comply with the requirement of ITB Clause 30
or ITB Clause 31 shall constitute sufficient grounds for the annulment of the
award and forfeiture of the bid security, in which event the Purchaser may make
the award to the next lowest evaluated bidder or call for new bids.

30.2
31.
31.1

31.2

15

<!-- page 16 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003

SECTION III:
General Conditions of Contract
Table of Clauses
Clause no. Topic number
1.
Definitions
2.
Application
3.
Standards
4.
Use of Contract Documents and Information
5.
Patent Rights
6.
Performance Security
7.
Inspection and Tests
8.
Packing
9.
Delivery and Documents
10.
Insurance
11.
Transportation
12.
Incidental Services
13.
Spare Parts
14.
Comprehensive Warranty
15.
Payment
16.
Prices
17.
Change Orders
18.
Contract Amendments
19.
Assignment
20.
Subcontracts
21.
Delays in Supplier’s Performance
22.
Liquidated Damages
23.
Termination for Default
24.
Force Majeure
25.
Termination by Insolvency
26.
Termination for Convenience
27.
Resolution of Disputes
28.
Governing Language
29.
Applicable Law
30.
Notice
31.
Taxes and Duties
32.
Training / Capacity Building

16

<!-- page 17 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
General Conditions of Contract
1.
1.1

Definitions
In this contract the following terms shall be interpreted as indicated:

a) “The Contract” means the agreement entered into between the Purchaser and the
Supplier as recorded in the Contract Form signed by the parties, including all the
attachments and appendices thereto and all documents incorporated by reference
therein;
b) “The Contract Price” means the price payable to the Supplier under the Contract for
the full and proper performance of its contractual obligations;
c) “The Goods” means all the equipment, machinery, and/or other materials which the
Supplier is required to supply to the Purchaser under the Contract;
d) “Services” means services ancillary to the supply of the Goods, such as
transportation and insurance, and other incidental services, such as installation,
commissioning, provision of technical assistance, training and other obligations of
the Supplier covered under the contract;
e) “GCC” means the General Conditions of Contract contained in this section.
f) “SCC” means the Special Conditions of Contract.
g) “The Purchaser” means the Organization purchasing the Goods, as named in SCC;
h) “The Supplier” means the individual or firm supplying the Goods under this
Contract;
i) “The Project Site”, where applicable means the place or places named in SCC.
j) “Day” means calendar day.
k) Delivery period means the period applicable upto completion of supply, installation,
testing and commissioning of the equipment by the “Supplier” at the Project site
and accepted by the “Purchaser”
2.
Application
2.1
These General Conditions shall apply to the extent that they are not superseded by
provisions in other parts of the Contract.
3.
3.1

Standards
The Goods supplied under this Contract shall conform to the standards mentioned
in the Technical Specifications, and, when no applicable standard is mentioned, to
the authoritative standard appropriate to the Goods country or origin and such
standards shall be the latest issued by the concerned institution.

4.
4.1

Use of Contract Documents and Information
The Supplier shall not, without the Purchaser’s prior written consent, disclose the
Contract, or any provision thereof, or any specification, plan, drawing, pattern,
sample or information furnished by or on behalf of the Purchaser in connection
therewith, to any person other than a person employed by the Supplier in
performance of the Contract. Disclosure to any such employed person shall be made
in confidence and shall extend only so far as may be necessary for purposes of such
performance.
The Supplier shall not, without the Purchaser’s prior written consent, make use of
any document or information enumerated in GCC Clause 4.1 except for purposes of
performing the Contract.
Any document, other than the Contract itself, enumerated in GCC clause 4.1 shall
remain the property of the Purchaser and shall be returned (in all copies) to the

4.2
4.3

17

<!-- page 18 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
Purchaser on completion of the supplier’s performance under the Contract if so
required by the Purchaser.
5.
5.1

Patent Rights
The Supplier shall indemnify the Purchaser against all third-party claims of
infringement of patent, trademark or industrial design rights arising from use of the
Goods or any part thereof in India.

6. Performance Security
6.1
Within 15 days after the Supplier’s receipt of notification of award of the Contract,
the Supplier shall furnish performance security to the Purchaser in the amount
specified in the Special Conditions of Contract.
6.2
The proceeds of the performance security shall be payable to the Purchaser as
compensation for any loss resulting from the Supplier’s failure to complete its
obligations under the Contract.
6.3
The Performance Security shall be denominated in Indian Rupees and shall be in
one of the following forms:
(a)
A Bank guarantee issued by a nationalized/ scheduled bank located in India and in
the form provided in the bidding Documents or any other form acceptable to the
Purchaser; or
(b)
A demand draft.
6.4
The performance security will be discharged by the Purchaser and returned to the
Supplier not later than 30 days following the date of completion of the Supplier’s
performance obligations, including any warranty obligations, unless specified
otherwise in SCC
7.
Inspection and Tests
7.1
The Purchaser or its representative shall have the right to inspect and/or to test the
Goods to confirm their conformity to the Contract at no extra cost of the Purchaser.
The Special conditions of Contract and/or the Technical Specifications shall specify
what inspections and tests the Purchaser requires and where they are to be
conducted. The Purchaser shall notify the Supplier in writing of the identity of any
representatives retained for these purposes.
7.2
The inspections and test may be conducted on the premises of the Supplier or its
subcontractor(s), at point of delivery and/or at the Goods final destination. Where
conducted on the premises of the Supplier or its subcontractor(s), all reasonable
facilities and assistance including access to drawings and production data - shall be
furnished to the inspectors at no charge to the Purchaser.
7.3
Should any inspected or tested Goods fail to conform to the specifications, the
Purchaser may reject them and the Supplier shall either replace the rejected Goods
or make all alternations necessary to meet specification requirements free of cost to
the Purchaser.
7.4
The Purchasers right to inspect, test and, where necessary, reject the Goods’ arrival
in at site shall in no way be limited or waived by reason of the Goods having
previously been inspected, tested and passed by the Purchaser or its representative
prior to the Goods dispatched.
7.5
Nothing in GCC Clause 7 shall in any way release the Supplier from any warranty
or other obligations under this Contract.
8.0
Packing
8.1
The Supplier shall provide such packing of the Goods as is required to prevent their
damage or deterioration during transit to their final destination as indicated in the
18

<!-- page 19 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003

8.2

9.
9.1

Contract. The packing shall be sufficient to withstand, without limitation, rough
handling during transit and exposure to extreme temperatures, salt and precipitation
during transit and open storage. Packing case size and weights shall take into
consideration, Where appropriate, the remoteness of the Goods final destination and
the absence of heavy handling facilities at all points in transit.
The packing, marking and documentation within and outside the packages shall
comply strictly with such special requirements as shall be provided for in the
Contract including additional requirements, if any, specified in SCC and in any
subsequent instructions ordered by the Purchaser.
Delivery and Documents
Delivery of the Goods shall be made by the Supplier in accordance with the terms
specified by the Purchaser in the Notification of Award. The details of dispatching
and/or other documents to be furnished by the supplier are specified in SCC.

10.
10.1

Insurance
The Goods Supplied under the Contract shall be fully insured in Indian Rupees
against the loss or damage incidental to manufacture or acquisition, transportation,
storage and delivery in the manner specified in the Special Conditions of Contract.

11.
11.1

Transportation
Where the Supplier is required under the Contract to transport the Goods to a
specified place of destination within the India defined as Project site, transport to
such place of destination in India insurance, as shall be specified in the Contract,
shall be arranged by the Supplier, and the related cost shall be included in the
Contract Price.

12.
12.1

Incidental Services
The supplier may be required to provide any or all of the following services,
including additional services, if any, specified in SCC:
Performance or supervision of the on-site assembly and/or start-up of the supplied
Goods;
furnishing of tools required for assembly and/or maintenance of the supplied Goods;
furnishing of detailed operations and maintenance manual for each appropriate unit
of supplied Goods.
performance or supervision or maintenance and/or repair of the supplied Goods, for
a period of time agreed by the parties, provided that this service shall not relieve the
Supplier of any warranty obligations under this Contract; and
training of the Purchaser’s Personnel, at the Supplier’s plant and/or on-site, in
assembly, start-up, operation, maintenance and/or repair of the supplied Goods.
Prices charged by the Supplier for incidental services, if not included in the contract
Price of the Goods, shall be agreed upon in advance by the parties and shall not
exceed the prevailing rates charged to other parties by the Supplier for similar
services.

(a)
(b)
(c)
(d)
(e)
12.2

13.
13.1

Spare Parts
As specified in the Special Conditions of Contract, the Supplier may be required to
provide any or all of the following materials and notifications and information
pertaining to spare parts manufactured or distributed by the Supplier:
(a) Such spare parts as the Purchaser may elect to purchase from the Supplier,
(i) providing that this election shall not relieve the Supplier of any warranty
19

<!-- page 20 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003

14.
14.1

14.2
14.3
14.4
14.5

15.
15.1
15.2

15.3
15.4
16.
16.1

(ii) obligations under the Contract; and
(b) In the event of termination of production of the spare parts:
(i) advance notification to the Purchaser of the pending termination, in
sufficient time to permit the Purchaser to procure needed
requirements; and
(ii) following such termination, furnishing at no cost to the Purchaser, the
blueprints, drawings and specifications of the spare parts, if and when
requested.
Comprehensive Warranty
The Supplier warrants that the Goods supplied under this Contract are new, unused,
of the most recent or current models and incorporate all recent improvements in
design and materials unless provided otherwise in the Contract. The supplier further
warrants that the Goods supplied under this Contract shall have no defect arising
from design, materials or workmanship (except when the design and/or material is
required by the Purchaser’s specifications) or from any act or omission of the
Supplier, that may develop
under normal use of the supplied Goods in conditions obtaining in the country of
final destination.
The comprehensive warranty shall remain valid for three years from the date of
commissioning of system.
The Purchaser shall promptly notify the supplier in writing of any claims arising
under this warranty.
Upon receipt of such notice, the Supplier shall, within the period specified in SCC
and with all reasonable speed, repair or replace the defective Goods or parts thereof,
without cost to the Purchaser.
If the Supplier, having been notified, fails to remedy the defect(s) within the period
specified in SCC within a reasonable period, the Purchaser may proceed to take
such remedial action as may be necessary, at the Supplier’s risk and expense and
without prejudice to any other rights which the Purchaser may have against the
Supplier under the contract.
Payment
The method and conditions of payment to be made to the Supplier under the Contract
shall be specified in the Special Conditions of Contract.
The Suppliers request(s) for payment shall be made to the Purchaser in writing,
accompanied by an invoice describing, as appropriate, the Goods delivered and after
satisfying supply, installing, demonstration & training to staffs, submitted pursuant
to GCC Clause 9, and upon fulfillment of other obligations stipulated in the contract.
Payment shall be made promptly by the Purchaser but in no case later than sixty
(60) days after submission of the invoice / claim by the Supplier from the date of
Commissioning of system.
Payment shall be made in Indian Rupees /through LC
Prices
Prices charged by the Supplier for Goods delivered and Services performed under
the Contract shall not vary from the prices quoted by the Supplier in its bid, with the
exception of any prices adjustments authorized in the special Conditions of Contract
or in the Purchaser’s request for bid validity extensions, as the case may be.
20

<!-- page 21 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
17.
17.1

Change Orders
The Purchaser may at any time by written order given to the Supplier pursuant to
GCC Clause 30, make changes within the general scope of the Contract in any one
or more of the following:
a) drawings, designs or specifications, where Goods to be furnished under the Contract
are to be specifically manufactured for the Purchaser;
b) the method of shipping or packing
c) the place of delivery; or
d) the services to be provided by the Supplier.
17.2 If any such changes causes an increase or decrease in the cost of, or the time required
for, the Supplier’s performance of any provisions under the Contract, an equitable
adjustment shall be made in the Contract Price or delivery schedule, or both, and the
Contract shall accordingly be amended. Any claims by the Supplier for adjustment
under this clause must be asserted within thirty (30) days from the date of the
Supplier’s receipt of the Purchaser’s change order.
18.
18.1

Contract Amendments
Subject to GCC Clause 17, no variation in or modification of the terms of the
Contract shall be made except by written amendment signed by the parties.

19.
19.1

Assignment
The Supplier shall not assign, in whole or in part, its obligations to perform under
the contract, except with the Purchaser’s prior written consent.

20.
20.1

Subcontracts
The supplier shall notify the Purchaser in writing of all subcontracts awarded under
the contract if not already specified in his bid. Such notification, in his original bid
or later, shall not relieve the Supplier from any liability or obligation under the
contract.

21.
21.1

Delays in the Supplier’s Performance
Delivery of the Goods and performance of the Services shall be made by the Supplier
in accordance with the time schedule specified by the Purchaser in its Schedule of
Requirements.
If at any time during the performance of the Contract, the Supplier or its
subcontractor(s) should encounter conditions impending timely delivery of the
goods and performance of the Services, the Supplier shall promptly notify the
Purchaser in writing of the fact of the delay, its likely duration and its cause(s). As
soon as practicable after receipt of the Supplier’s notice, the Purchaser shall
evaluate the situation and may at its discretion extend the Supplier’s time for
performance with or without liquidated damages, in which case the extension shall
be ratified by the parties by amendment of the Contract.
Except as provided under GCC Clause 24, a delay by the Supplier in the performance
of its delivery obligation shall render the supplier liable to the imposition of
liquidated damages pursuant to GCC Clause 22, unless any extension of time is
agreed upon pursuant to GCC clause 21.2 without the application of liquidated
damages.

21.2

21.3

21

<!-- page 22 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
22.
22.1

Liquidated Damages
Subject to GCC Clause 24, if the Supplier fails to deliver any or all of the Goods or
to perform the Services within the period(s) specified in the Contract, the Purchaser
shall, without prejudice to its other remedies under the Contract, deduct from the
Contract Price, as liquidated damages, a sum equivalent to the percentage specified
in SCC of the delivered price of the delayed Goods or unperformed Services for each
week or part thereof of delay until actual delivery or performance, up to a maximum
deduction of the percentage specified in the SCC. Once the maximum is reached,
the Purchaser may consider termination of the Contract pursuant to GCC Clause
23.

23.
23.1

Termination by Default
The Purchaser may, without prejudice to any other remedy for breach of contract,
by written notice of default sent to the supplier, terminate the Contract in whole or
part;
if the Supplier fails to deliver any or all of the goods within the time period(s)
specified in the Contract, or within any extension thereof granted by the Purchaser
pursuant to clause 21; or
if the Supplier fails to perform any other obligation(s) under the Contract.
In the event the Purchaser terminates the Contract in whole or in part, pursuant to
GCC Clause 23.1, the Purchaser may procure, upon such terms and in such manner
as it deems appropriate, Goods or Services similar to those undelivered, and the
Supplier shall be liable to the Purchaser for any excess costs for such similar Goods.
However, the Supplier shall continue the performance of the Contract to the extent
not terminated.

(a)
(b)
23.2

24. Force Majeure
24.1 Notwithstanding the provisions of GCC Clauses 21, 22, 23, the Supplier shall not be
liable for forfeiture of its performance security, liquidation damages or termination
for default, if and to the extent that, its delay in performance or other failure to
perform its obligations under the Contract is the result of an event of Force Majeure.
24.2 For purposes of this Clause “Force Majeure” means an event beyond the control of
the Supplier and not involving the Supplier’s fault or negligence and not foreseeable.
Such events may include, but are not limited to, acts of the Purchaser either in its
sovereign or contractual capacity, wars or revolutions, fires, floods, epidemics,
quarantine restrictions and freight embargoes.
24.3 If a Force Majeure situation arises, the Supplier shall promptly notify the Purchaser
in writing of such conditions and the cause thereof. Unless otherwise directed by the
Purchaser in writing, the Supplier shall continue to perform its obligations under
the Contract as far as is reasonably practical, and shall seek all reasonable alternative
means for performance not prevented by the force majeure event.
25.
25.1

Termination for Insolvency
The Purchaser may at any time terminate the Contract by giving written notice to
the Supplier, if the Supplier becomes bankrupt or otherwise insolvent. In this event,
termination will be without compensation to the Supplier, provided that such
termination will not prejudice or affect any right of action or remedy which has
accrued or will accrue thereafter to the Purchaser.
22

<!-- page 23 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
26.
26.1

Termination for Convenience
The Purchaser, may by written notice sent to the Supplier, may terminate the
Contract, in whole or in part, at any time for its convenience. The notice of
termination shall specify that termination is for the Purchaser’s convenience, the
extent to which performance of work under the Contract is terminated, and the date
upon which such termination becomes effective.

27.
27.1

Resolution of Disputes
The Purchaser and the supplier shall make every effort to resolve amicably by direct
informal negotiation any disagreement or dispute arising between them under or in
connection with the Contract.
If, after thirty (30) days from the commencement of such informal negotiations, the
Purchaser and the Supplier have been unable to resolve amicably a Contract dispute,
either party may require that the dispute be referred for resolution to the formal
mechanisms specified in the Special Conditions of Contract. These mechanisms may
include, but or not limited to, conciliation mediated by a third Party, adjudication in
an agreed national forum, and national arbitration.

27.2

28.
28.1

Governing Language
The contract shall be written in English language. Subject to Clause 29, English
language version of the Contract shall govern its interpretation. All correspondence
and documents pertaining to the Contract which are exchanged by the parties shall
be written in the same language.

29.
29.1
30.
30.1

Applicable Law
The Contract shall be interpreted in accordance with the laws of the Union of India.
Notice
Any notice given by one party to the other pursuant to this Contract shall be sent to
other party in writing or by cable, telex and confirmed in writing to the other Party’s
address specified in Special Conditions of Contract.
A notice shall be effective when delivered or on the notice’s effective date,
whichever is later.

30.2

31.
Taxes and Duties
31.1. Suppliers shall be entirely responsible for all taxes, duties, license fees, octroi, road
permits, etc., incurred until delivery of the contracted Goods to the Purchaser.
However, Sales tax (not surcharge in lieu of Sales tax) in respect of the transaction
between the Purchaser and the Supplier shall be payable extra, if so stipulated in
the Notification of Award.
32. Training / Capacity Building
32.1 Suppliers have to provide hands-on-exposure on the maintenance & functional
operation of the equipment “Solar panels for Irrigation and Sprayer” to the technical
persons working in the scheme/TNAU.

23

<!-- page 24 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION IV
Special Conditions of Contract
Table of Clauses
(The corresponding Clause number of the General Conditions is in parentheses)
Clause no.

Topic number

1.

Definitions (Clause 1)

2.

Performance Security (Clause 6)

3.

Inspection and Tests (Clause 7)

4.

Packing (Clause 8)

5.

Delivery and Documents (Clause 9)

6.

Insurance (Clause 10)

7.

Incidental Services (Clause 12)

8.

Spare Parts (Clause 13)

9.

Comprehensive Warranty (Clause 14)

10.

Payment (Clause 15)

11.

Prices (Clause 16)

12.

Sub Contract (Clause 20)

13.

Liquidated Damages (Clause 22)

14.

Resolution of Disputes (Clause 27)

15.

Notices (Clause 30)

16.

Annual Maintenance Contract

17.

Enclosures to Bid

24

<!-- page 25 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION IV
Special Conditions of Contract
The following Special Conditions of Contract shall supplement the General Conditions of
Contract. Whenever there is a conflict, the provisions herein shall prevail over those in the
General Conditions of contract. The Corresponding clause number of the General
Conditions is indicated in parentheses.
1.

Definitions (GCC Clause 1)
(a) The Purchaser is The Director, Directorate of Crop Management, TNAU,
Coimbatore – 641003
(b) The Supplier is....................................................
(c) Project site is the place(s) mentioned in the Schedule of Requirements

2.
2.1

Performance Security (GCC Clause 6)
Substitute Clause 6.1 of GCC by the following:
Within 15 days after the Supplier’s receipt of Notification of Award, the Supplier
shall furnish performance Security to the Purchaser for an amount of 5% of the
total bill of cost for a period of three years (up to the comprehensive warranty
period)
Substitute Clause 6.3 (b) of GCC by the following:
A cashier’s cheque or banker’s certified cheque or crossed demand draft or pay order
drawn in favour of the Purchaser.
Substitute Clause 6.4 of the GCC by the following:
The Performance Security will be discharged by the Purchaser and returned to the
Supplier not later than 2 years following the date of completion of the Supplier’s
performance obligations, including the warranty obligations, under the Contract.
Add Clause 6.5 to the GCC of the following:
In the event of any contract amendment, the supplier shall, within 15 days of receipt
of such amendment, furnish the amendment to the Performance Security, rendering
the same valid for the duration of the Contract, as amended for further period of two
years thereafter.

2.2
2.3

2.4

3.

Inspection and Tests (GCC Clause 7)
The following inspection procedures and tests are required by the Purchaser;
a)
The supplier shall get each equipment inspected in manufacturer’s works and
submit a test certificate and also guarantee/warranty certificate that the
equipment conforms to laid down specifications.
b)
The Purchaser or its representative shall inspect and/or test any or all the
equipment to confirm their conformity to the Contract specifications, prior
to despatch from the manufacturer’s premises. Such inspection and clearance
will not prejudice the right of the consignee to inspect and test the equipment
on receipt at destination.
“Samples of all materials to be used for construction need to be submitted by the
supplier. The quality of the materials will be inspected by the Engineers of the
University at different stages of the construction. This should be explicitly
mentioned in the Technical bid by the Tenderer”.

25

<!-- page 26 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
c)

4.

5.

If the equipment fails to meet the laid down specifications the supplier shall
take immediate steps to remedy the deficiency or replace the defective
equipment to the satisfaction of the Purchaser.

Packing (GCC Clause 8)
Add as Clause 8.3 of the GCC the following:
Packing Instruction: The Supplier will be required to mark separate packages for
each consignee. Each package will be marked on three sides with proper
paint/indelible ink, the following:
i. Project
ii. Contract No.
iii. Supplier’s Name
iv. Packing list reference number
Delivery and Documents (GCC Clause 9)
Upon delivery of the Goods, the Supplier shall notify the Purchaser and the
Insurance Company by cable or Telex or fax the full details of shipment including
the Contract number, railway receipt number and date, description of Goods,
quantity, names of the consignee etc.
The Supplier shall mail the following documents to the Purchaser, with a copy to
the Insurance Company.
(i)
Three Copies of Supplier invoice showing Goods description, quantity, unit
price, total amount;
(ii)
Railway receipt/acknowledgment of receipt of goods from the Consignee(s)
(iii) Insurance Certificate;
(iv)
Manufacturer’s/ Supplier’s warranty and test Certificate;
(v)
Inspection Certificate issued by the nominated inspection agency, and the
Supplier’s factory inspection report;
The above documents shall be received by the Purchaser before arrival of Goods
(except where the Goods have been delivered directly to the Consignee with all
documents) and, if not received, the supplier will be responsible for any consequent
expenses.

6.

Insurance (GCC Clause 10)
For delivery of goods at site, the insurance shall be obtained by the Supplier in an
amount equal to 110% of the value of the goods from “Warehouse to Warehouse”
(Final destinations) on “All Risks” basis including War Risks and Strike.

7.

Incidental Service (GCC Clause 12)
The following services covered under Clause 12 shall be furnished and the cost shall
be included in the contract price:
(a)
Unloading, safe storage and handling of consignment of site.
(b)
On site assembly if any of the supplied goods, installation, testing
and commissioning of the equipment.
(c)
Furnishing of detailed operations and maintenance manual for each
appropriate unit of supplied Goods;
Spare parts (GCC Clause 13)
Add as Clause 13.2 to the GCC the following:
Supplier shall carry sufficient inventories to assure prompt replacement of defective
parts immediately during the guarantee as well as maintenance period covered under
comprehensive maintenance contract.
26

8.

<!-- page 27 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
9.

Comprehensive Warranty (GCC Clause 14)
The Supplier shall, in addition, comply with the performance and/ or consumption
guarantees specified under the contract. If for reasons attributable to the Supplier,
these guarantees are not attained in whole or in part, the Supplier shall at its
discretion either:
(a)
make such changes, modifications, and/or additions to the Goods or any part
thereof as may be necessary in order to attain the contractual guarantees
specified in the Contract at its own cost and expense and to carry out further
performance tests in accordance with SCC 3:

10.

Payment (GCC Clause 15)
Payment for Goods and Services shall be made in Indian Rupees /Foreign currency
after satisfactory supply, installation, demonstration and training to staffs.

11.

Prices (GCC Clause 16)
Substitute Clause 16.1 of the GCC with the following:
Prices payable to the Supplier as stated in the Contract shall not be subject to
adjustment during performance of the Contract.

12.

Sub-Contract (Clause 20)
Add at the end of sub-clause 20.1 the following:
Sub-contract shall be only for bought-out items and sub-assemblies.

13.
13.1

Liquidated Damages (GCC Clause 22)
For delays:
Substitute GCC Clause 22.1 by the following
Subject to Clause 24, if the Supplier fails to deliver any or all of the Goods or
perform of services within the time period(s) specified in the Contract, the
Purchaser shall without prejudice to its other remedies under the Contract, deduct
from the Contract Price, as liquidated damages, a sum equivalent to 0.5 percent of
the delivered price of the delayed Goods or unperformed Services for each week of
delay or part thereof until actual delivery or performance, up to a maximum
deduction of 10 percent of the delayed Goods or Services contract price. Once the
maximum is reached, the Purchaser may consider termination of the Contract.

14.

Resolution of Disputes (GCC Clause 27)
Add as GCC Clauses 27.3 and 27.4 the following:
27.3 The dispute resolution mechanism to be applied pursuant to GCC Clause 27
shall be as follows:
(a) In the case of a dispute or difference arising between the Purchaser and a
Supplier relating to any matter arising out of or connected with this agreement,
such dispute or difference shall be settled in accordance with the Arbitration and
Conciliation Act 1996 the Arbitral Tribunal shall consist of 3 Arbitrator, one
each to be nominated by the Purchaser and the supplier. The third Arbitrator
shall be chosen by the two Arbitrators so appointed by the parties and shall act
as Presiding Arbitrator. In case of failure of the two Arbitrator appointed by the
parties to reach upon a consensus within a period of 30 days from the
appointment of the Arbitrator appointed subsequently, the Presiding Arbitrator
shall be appointed by the President of Institute of Engineers (India).
27.4 The venue of arbitration shall be the place from where the Contract is
issued (ie.) Coimbatore.
27

<!-- page 28 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
15.

Notices (clause 30)
For the purpose of all notices, the following shall be the address of the Purchaser
and Supplier.
Purchaser: The Director, Directorate of Crop Management, TNAU,
Coimbatore – 641003
Supplier: (To be filled in at the time of Contract signature)

16.
16.1

16.2
16.3

Annual Maintenance Contract (AMC):
Any major repair pointed out by the Purchaser shall be rectified by the Supplier
from the date of intimation within a period of 3 calendar days and commission the
equipment to the satisfaction of the Purchaser. Failing which the Purchaser has a
right to levy a penalty on the Supplier a sum of Rs.5000/- per day or part thereof for
each equipment until the equipments are repaired and commissioned to the
satisfaction of the Purchaser.
The Supplier shall indicate clearly the free guarantee maintenance of the whole
system supplied by the Supplier and the same should not be less than 1 year.
The Supplier shall also indicate separately AMC of the entire system for 3 years
subsequent to comprehensive warranty period and shall clearly indicate year
wise maintenance cost.

17.
17.1

Enclosures to Bid:
Technical bid (Cover A):
Technical Bid shall include the duly filled up Tender documents along with
a)
Bid Security
b)
Duly attested copy of License if any, approved by the concerned Licensing
Authority.
c)
For Importers Photocopy of License renewed upto date.
d)
Documentary evidence of constitution of firm such as Memorandum of
Articles, Partnership Deed, etc., with details of Name, Address, Tel. No., Fax
No., E-mail Address of firm and the Managing Director / Partner / Proprietor.
e)
Authorization of senior responsible officer of the Company to transact
business.
f)
Annual turnover statement for last three years certified by the Auditor.
g)
Copies of Balance Sheet and Profit & Loss Account for three years certified
by the Auditors.
h)
I.T. Clearance Certificate as on latest.
i)
Qualification Criteria – Section VI-A
j)
Performance Statement - Section XI
k)
Manufacturer’s Authorization Form - Section XII
l)
Technical literature and other documents in support of the goods / services.
m)
Any deviations
n)
List of items quoted (without prices)

17.2

Price Bid (Cover B):
Price bid shall include
a)
Duly filled in Price Schedule - Section VII
Please note that the Bidder run the risk of his bid being rejected if the Price
Schedule contains any conditions.
28

<!-- page 29 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION V
Schedule of Requirements
Sl.
No.

Brief
Description

Quantity

1.

Solar panels for
Irrigation and
Sprayer

1 Unit
(Should be fixed in 3 demo
locations)

Period of
completion

Bid
Security
(Rs.)

Within 15 days
from the date of
issue of supply
order

10,200/-

Place of Delivery:
Sl. No.
1.

Place
Agro Climate Research Centre,
Directorate of Crop Management,
TNAU, Coimbatore – 641003

29

Qty
1 Unit
(Should be fixed in 3 demo locations)

<!-- page 30 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION VI - A
Technical Specifications for the supply of “Solar panels for Irrigation and Sprayer”
Technical Specification
Quantity
1. Supply, installation, testing, and commissioning of a 5 HP solar
pumping power plant with a minimum system capacity of 7.2 kWp
using 600 Wp bifacial TOPCon solar PV modules compliant with IEC 1 Unit
(Should be
61215 and IEC 61730 standards.
2. Pump drive have Input max. DC voltage: 800 V, Starting/Minimum fixed in 03
voltage: 480 V, Nominal Voltage: 600 V; Current rating: 22A-25A; demo
Drive KW rating: 7.5 kW; VFD frequency: 50 Hz; Operating locations)
Frequency: 0-50 Hz.
3. Suitable lightening arrester for the proposed PV system shall be
provided.
4. The system shall suitable for operating submersible or centrifugal
pumps.
5. A hot-dip galvanized GI module mounting structure with all required
clamps, fasteners, and accessories shall be provided, designed to
withstand a minimum wind load of 150 km/hr.
6. Solar grade electrical protection shall include a 1000 VDC, 16A DC
MCB and a drive enclosure box with minimum IP54 protection.
7. The scope shall include UV resistant 4 sq.mm solar DC cables (10
meters) with proper color coding and two maintenance-free earthing
systems ensuring earth resistance below 5 ohms.
8. Transportation of all materials to site, complete mechanical
installation, electrical wiring, terminations, earthing, testing, and
commissioning shall be included.
9. The system shall operate independently of grid power, and all supplied
materials shall be new, unused, and compliant with applicable
IEC/IS/MNRE standards
10. This system shall be installed in three demo locations across Tamil
Nadu
11. Solar operated sprayer for three demo locations with following
specifications shall be supplied, i.e. Solar panel rating: 10 Watts, 058A, Charge controller: 12V/260 Watts, Battery: 12V, 7.2 AH, Pump:
72 Lph, Sprayer tank capacity: 16 litters
Note:
1. A detailed compliance statement should be provided for each Sl. No. of the
technical specifications given in Section VI – A. Tenders should be submitted in two
bid system i.e. technical bid and price bid. Price bid shall be opened in the presence of
those firms who have qualified in technical bid.
2. Bidder should have completed 03 supplies of “Solar panels for Irrigation and Sprayer”,
value not less than 20 lakh each (Documentary evidence should be enclosed)
30

<!-- page 31 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
3. Annual financial turnover of bidder for last three years (Copy of IT statement, Balance
sheet, P/L duly attached by CA).
4. All the drawings provided in this tender document are for illustrative purpose only. The
tender documents should have detailed drawings of Solar panels for Irrigation and
Sprayer
5. Full technical specifications including complete details of all material used for the
construction such as make, model, quality, size/thickness, weight etc. should be given
in the technical bid. The technical details mentioned in the technical bid submitted
should not be a mere reproduction of specification mentioned in the tender
schedule.
6. The quality of the supplied items will be inspected by the Engineers of the University
7. List of clients should be enclosed for reference so that our technical committee could
visit the sites.

31

<!-- page 32 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION VI-B
Qualification Criteria
(Referred to in Clause 11.2 of ITB)
a)

The bidder or the manufacturer whose product is offered by the authorized
Representative must have manufactured and supplied similar equipment of the type
specified in the Schedule of Requirements up to at least 30% (rounding off to nearest
whole number) of the quantity offered in any one of the last five calendar years and
should be satisfactorily functioning with no adverse report for at least two years on
the date of bid opening.

b)

The bidder should furnish the information on past supplies and satisfactory
performance in the Proforma given under Section - XI.

c)

Bidders shall invariably furnish documentary evidence (Client’s Certificate) in
support of the satisfactory operation of the equipment as specified above.

d)

The Bidder shall furnish data to support that he has the financial and production
capacity to perform the contract and complete the supplies within the stipulated
delivery period.

32

<!-- page 33 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION VII
Bid Form and Price Schedules
Contract No..............
To:
The Director, Directorate of Crop Management, TNAU, Coimbatore – 641003
Gentlemen,
Having examined the Bidding Documents including Addenda Nos......................, the receipt
of which is hereby duly acknowledged, we, the undersigned, offer to supply and
deliver..............................................……………………………… (Description of Goods
and Services) in conformity with the said Bidding Documents for the sum of
..............................
………………………………………………………………………………………………
…………………………………………………………(Total Bid amount in Words and
Figures) or such other sums as may be ascertained in accordance with the Schedule of Prices
attached herewith and made part of this bid.
We undertake, if our bid is accepted, to deliver the goods in accordance with the delivery
schedule specified in the Schedule of Requirements.
If our bid is accepted, we will obtain the guarantee of a bank in a sum equivalent to 5% of
the Contract Price for the due performance of the Contract, in the form prescribed by the
Purchaser.
We agree to abide by this bid for a period of .................................(Number) days from the
date fixed for bid opening under Clause 20 of the Instruction to Bidders and it shall remain
binding upon us and may be accepted at any time before the expiration of that period.
Until a formal contract is prepared and executed, this bid, together with your written
acceptance thereof and your notification of award, shall constitute a binding Contract
between us.
We understand that you are not bound to accept the lowest or any bid you may receive.
Dated this................. day of ...................... 2026
Signature: .........................................
(In the Capacity of): .........................................
Duly authorized to sign bid for and on behalf of
..........................................................................

33

<!-- page 34 -->

3
4

1.

2.

3.

Item Description

Country of origin

Quantity & Unit
(a)
(b)

Unit price (6) (Rs. In words)

Name of the item

Annual Maintenance Contract for 5 years / year
(After Comprehensive warranty period of 3 years)

Name of the item

Customs duty payable if any (Rs.)

34
(e)

7
8

Sales and other taxes
payable if contract is
awarded

(d)

6

Total price per
schedule for delivery
at final destination 4
x6

5
PRICE FOR EACH UNIT

Unit price
(a+b+c+d+e)

Incidental
services as listed
in clause 7 of
SCC

(c)

Inland
transportation,
insurance and
incidental costs
incidental to
delivery

Packing &
forwarding

Excise duty, if
any

2

Ex-factory / Exwarehouse / Exshowroom off-the
shelf

1

Schedule No.

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
PRICE SCHEDULE

<!-- page 35 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
Note:
(a) In case of discrepancy between unit price and total price, the unit price shall prevail.
(b) This price schedule should be placed in separate sealed cover “Cover B”

Place

:

Signature of the bidder

Date

:

Name
Business Address

35

<!-- page 36 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION VIII
Bid Security Form
Whereas
………..........................................................................................................................1(hereinaft
er called "the Bidder") has submitted its bid dated .............................................. (date of
submission of bid) for the supply of
…………………………………………………………………………....................................
.........................................................................................................................................................
...................... (name and/or description of the goods) (Hereinafter called "the Bid").
KNOW ALL PEOPLE by these presents that WE ......................................................................
(name of bank) of .................................................. (name of country), having our registered
office
at
………………………………………………………………………………………………
……………………………..
.........................................................................................................................................................
................................ (address of bank) (hereinafter called "the Bank"), are bound unto
The Director, Directorate of Crop Management, TNAU, Coimbatore – 641 003
(hereinafter
called
"the
Purchaser")
the
sum
of
___________________________________________ for which payment will truly to be made
to the said Purchaser, the Bank binds itself, its successors, and assigns by these presents.
Sealed with the Common Seal of the said Bank this ________day of _________ 20 _______.
THE CONDITIONS of this obligation are:
1.
If the Bidder
a)
withdraws its Bid during the period of bid validity specified by the Bidder on
the Bid Form; or
b)
does not accept the correction of errors in accordance with the ITB; or
2.

If the Bidder, having been notified of the acceptance of its bid by the Purchaser during
the period of bid validity:
a)
fails or refuses to execute the Contract Form if required; or
b)
fails or refuses to furnish the performance security, in a accordance with the
Instruction to Bidders;

We undertake to pay the Purchaser up to the above amount upon receipt of its first written
demand, without the Purchaser having to substantiate its demand, provided that in its demand
the Purchaser will note that the amount claimed by it is due to it, owing to the occurrence of
one or both of the two conditions, specifying the occurred condition or conditions.
This guarantee will remain in force up to and including forty five (45) days after the period of
the bid validity, and any demand in respect thereof should reach the Bank not later than the
above date.
(Signature of the Bank)
1. Name of Bidder

36

<!-- page 37 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003

SECTION IX
Contract Form
THIS AGREEMENT is made on the .............. day of ................, 2026 between The
Director, Directorate of Crop Management, TNAU, Coimbatore – 641003 represented
by
the
Director,
(hereinafter
“the
Purchaser”)
of
one
part
and
.................................................................................................................................................
...........................................................................................................................................(Na
me and address of Supplier) (hereinafter “the Supplier”), represented
by……………………………………………………………………………………………
……………………………………….(Name of the authorized signatory and designation),
aged
……………
years,
residing
at
………………………………………………………………………………………………
………………………………………………………………………………………………
…………………………………………………………………………………..(Full
Residential Address of the signatory) of the other part:
WHEREAS the Purchaser is desirous that certain Goods and ancillary services should be
provided by the Supplier, viz., ............................................................................ (Brief
Description of Goods and Services) and .................................................... has accepted a
bid by the Supplier for the supply of those goods and services in the sum of
..............................................................................................................................................(
Contract Price in Words and Figures) (hereinafter “the Contract Price”).
NOW THIS AGREEMENT WITNESSETH AS FOLLOWS:
1.
In this Agreement words and expressions shall have the same meanings as are
respectively assigned to them in the Conditions of Contract referred to.
2.
The following documents shall be deemed to form and be read and constructed as
part of this Agreement, viz.:
(a)
the Bid Form and Price Schedule submitted by the Bidder;
(b)
the Schedule of Requirements;
(c)
the Technical Specifications;
(d)
the General Conditions of Contract;
(e)
the Special Conditions of Contract; and
(f)
the Purchaser’s Notification of Award
3.
In consideration of the payments to be made by the Purchaser to the Supplier as
hereinafter mentioned, the Supplier hereby covenants with the Purchaser to provide
the Goods and Services and to remedy defects therein in conformity in all respects
with the provisions of the Contract.
4.
The Purchaser hereby covenants to pay the Supplier in consideration of the
provision of the Goods and Services and the remedying of defects therein, the
Contract Price or such other sum as may become payable under the provisions of the
Contract at the times and in the manner prescribed by the Contract.

37

<!-- page 38 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
Brief particulars of the goods and services which shall be supported / provided by the
supplier are:
S.
No.

Brief description of
item to be supplied

Quantity to
be supplied

Unit
Price

Total
amount
(=3x4)

1

2

3

4

5

Sales tax
and other
taxes
payable
6

Total Value: 5 + 6
Delivery Schedule:
IN WITNESS whereof the parties hereto have caused this Agreement to be executed in
accordance with their respective laws the day and year first above written.
Signed, Sealed and Delivered by the said ......................................... (For the Purchaser)
in the presence of ...................................................
Signed, Sealed and Delivered by the
said ...........................................(For the Supplier) (Signature, Name, Designation and
Address with office seal)
in the presence of ....................................................
1.

(Signature Name and Address of Witness)

2.

(Signature Name and Address of Witness)

38

<!-- page 39 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION X
Performance Security Form
To:
The Director, Directorate of Crop Management, TNAU, Coimbatore – 641003 (Name
of Purchaser)
WHEREAS
......................................................................................................................(Name of the
Supplier) herein called “the Supplier” has undertaken, in pursuance of Contract
No................
dated,
................
to
supply
.................................................................................................................................................
............................................ (Description of Goods and Services) hereinafter called “the
Contract”.
AND WHEREAS it has been stipulated by you in the said Contract that the Supplier shall
furnish you with a Bank Guarantee by a recognized bank for the sum specified therein as
security for compliance with the Supplier’s performance obligations in accordance with the
Contract.
AND WHEREAS we have agreed to give the Supplier a Guarantee
THEREFORE WE hereby affirm that we are Guarantors and responsible to you, on behalf
of
the
Supplier,
upto
a
total
of
.................................................................................................................................................
....(Amount of the Guarantee in Words and Figures) and we undertake to pay you, upon your
first written demand declaring the Supplier to be in default under the Contract and without
cavil
or
argument,
any
sum
or
sums
within
the
limit
of
..............................................................................................................................................
(Amount of Guarantee) as aforesaid, without your needing to prove or to show grounds or
reasons for your demand or the sum specified therein.
This guarantee is valid until the .............. day of .................. 2026.
Signature and Seal of Guarantors
Date .................. 2026
Address :
............................................
............................................
............................................
(Please see Clause 11.2(b) (ii) of Instructions to Bidders)

39

<!-- page 40 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION XI
Proforma for Performance Statement (for a period of last five years)
Bid No.
Name of the Firm:

Order
placed by
(Full
Address of
Purchaser)
(1)

Has the
equipment
Remarks
been
Order Description
indicating satisfactorily
No.
and
Value
Date of
reasons functioning?
and Quantity of
of
Completion
for late
(Attach a
Dated
ordered
order of delivery
delivery,
certificate
(2)
equipment
if any
from the
Purchaser/
Consignee)
As per
Actual
Contract

Signature and Seal of the Bidder ...................................................................

40

<!-- page 41 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
SECTION XII
Manufacturer’s Authorisation Form
(Please see Clause 11.2(a) of Instructions to Bidders)
No..................... dated ......................
To
The Director, Directorate of Crop Management, TNAU, Coimbatore – 641003
Dear Sir,
IFB No.________________________________
We ________________ who are established and reputable manufacturers of
___________________ having factories at ______________ and ______________ do
hereby authorise M/s._________________ (Name and address of Representative) to submit
a bid, and subsequently negotiate and sign the contract with you against the above IFB NO.
No company or firm or individual other than M/s.___________________ are authorized to
bid, negotiate and conclude the contract in regard to this business against this specific IFB.
We hereby extend our full guarantee and warranty as per Clause 14 of the General
Conditions of Contract for the goods offered for supply against this invitation for bid by the
above firm.
Yours faithfully,
(Name)
for and on behalf of M/s.____________
(Name of manufacturers)
Note: This letter of authority should be on the letterhead of the manufacturing concern and
should be signed by a person competent and having the power of attorney to bind the
manufacturer.

41

<!-- page 42 -->

TAMIL NADU AGRICULTURAL UNIVERSITY
Directorate of Crop Management, Coimbatore – 641 003
BANK GUARANTEE FOR ADVANCE PAYMENT
To
The Director, Directorate of Crop Management, TNAU, Coimbatore – 641003
................................................................... (Name of Contract)
Gentlemen,
In accordance with the provisions of the Special Conditions of Contract which augment
Clause
15
of
the
General
Conditions
of
Contract
.................................................................................................................................................
...........................................................................................................................................(Na
me and Address of Supplier) (hereinafter called "the supplier) shall deposit with The
Director, Directorate of Crop Management, TNAU, Coimbatore – 641003 a Bank
Guarantee to Guarantee his proper and faithful performance under the said Clause of the
Contract in an amount of ......................................................................................... (amount
of Guarantee 3) ...................................................................................................... (in words).
We, the ......................................................................................................................(Bank or
Financial institution), as instructed by the supplier, agree unconditionally and irrevocably
to guarantee as primary obligator and not as Surety merely, the payment to The Director,
Directorate of Crop Management, TNAU, Coimbatore – 641003
on his first demand without whatsoever right of objection on our part and without his first
claim
to
the
Supplier,
in
the
amount
not
exceeding
..................................................................................................
(amount of Guarantee 2) ................................................ (in words).
We further agree that no change or addition to or other modification of the terms of the
Contract to be performed there under of any of the Contract documents which may be made
between The Director, Directorate of Crop Management, TNAU, Coimbatore – 641003
and the Supplier, shall in any way release us from any liability under this guarantee, and we
hereby waive notice of any such change, addition or modification.
This guarantee shall remain valid and in full effect from the date of the advance payment
received under the Contract until The Director, Directorate of Crop Management,
TNAU, Coimbatore – 641003 receives full repayment of the same amount from the
Supplier.
Yours truly,
Signature & Seal
: ..........................................................
Name of Bank / financial Institutions
: ..........................................................
Address
: ..........................................................
Date
: ..........................................................
An amount is to be inserted by the Bank or Financial Institution representing the amount of
the Advance Payment, and denominated either in the currency of the Advance Payment as
specified in the Contract, or in a freely convertible currency acceptable to the purchase.

42
