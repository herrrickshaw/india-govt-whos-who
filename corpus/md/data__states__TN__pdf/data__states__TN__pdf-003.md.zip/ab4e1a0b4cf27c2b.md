---
doc_id: "ab4e1a0b4cf27c2b"
source_url: "https://tnpesu.org/upload/NCTE/Sanctioned-Programmes.pdf"
ministry: "Tamil Nadu Physical Education and Sports University, Chennai, Tamil Nadu"
title: "Sanctioned Programmes with Intake"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5e855c8b10b2f138"
---

<!-- page 1 -->

Tamil Nadu Physical Education and Sports University
Department of Physical Education
S.No

1
2
3
4

Sanctioned Programmes

Annual Intake

B.P.Ed I Year

100

B.P.Ed II Year

100

M.P.Ed I Year

40

M.P.Ed II Year

40
