---
doc_id: "0831db56fddd4fcb"
source_url: "https://tncdw.org/frontend/guideline/CMBFS_-SOP_tamil_21.04.23.pdf"
ministry: "Tamil Nadu Corporation for Development of Women (TNCDW), Tamil Nadu"
title: ""
date: ""
pages: 15
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a96901509f40e601"
---

<!-- page 1 -->

(CMBFS)
$ %&:

()*+
,
110
0 1
23 - 56 $7 $&8 (1
5 5
+7)
6)
+:;
<=+
:>+
- ?6 7) > 8
&@ $&8 8
=
PLF / ALF / SHG
5?
GH I
@$
$J,K
L$ ..

+H7): 1.
2.

N(.7466/SW4-1/2022-3, I
VJ
X

3.

$G

V

@L,
:> 7$
WH

,

()*+

LW L 8

4.

()*+
WH
6 & X &.28.06.2022

5.

[
X
27.07.2022.

6.

2023-24=
W
LW L 8

7.
G\

03.06.2022.

G\

8L

W L &
1
6 & X &.03.06.2022.

5Y = V

@L W L 8
, K

1

$
` V
,
WH07) X & 20.03.2023

W@0
Wa
19.04.2023.

L 8

X &.16.06.2022

;

Y

V

V

G.O.No.43, X &
()*+
X & 17.04.2023

********
()*+
L W L @
6 I
2022 W \
,
110
0 1
23 5I6 =?
%>
=
;
1
6
% =+
G
W6d7
$&8 8
1
5 5
+7)
6 $1a
L <=+ W
,K I
7 $L 15
X
8a e
:> 7$J N \ WH0= 7$ J&@K.
W \
()*+
L W L @
G
?6 7)
G\
X L7) > 8
> 7$ J&@K.

I

$
+

[
J
\
,
&, 346 ?6
?6

X

G\
f%>?
g6 h &

8L
, K
7)
G
G\ 963 $&8
> 7$ J&@K.

[
,
*3X J
8L
16
> 8
(17
> &) W6d7 $&8 8

7) > 8
G
I L;
J= 7$ J&@ ?6
g6 h 8
(346)
= +i
I L
Y 7$ J&@ d
0=+i= &/g6 h
W@0
V
7)/ $+ W@0
V
7)
@
L;
\7j L 8
I
@7 $
$J,
GI$ K&@
V > 8
e=
,
$J, 7$ J
%? K. 27.07.2022 W \
81 7$ J&@ W6d 5
1 $
$ L
5
k
e
7)-I & II+H7j 7$ J&@ WH \,
@
( 7$ =
7j 7$K
@ j $GH e
7)-II e
$
n 7$ J&@
@
e,
$J
?6 7)
$&8 8
$1a
+:;
<=+
:>?
, e,
,
h 7$
$J,
WH \, 7$ J&@K.

<!-- page 2 -->

?6
o

2023-2024 5
5(J=
G\ X L) > 8
&@ W
,
p0

)

e=

0

(J

p
q;

+7)

,

&@ 30,122 W6d

,

p 0

6 $ =+

, G+ r.500 I

$

$J, 7$

18
`

fK=2J

s

&@ 30 516,K 122 W6d,
q;

e,

+7)
0

r$ Y

6 $1a

+7)

$\

1

%

f

L &$

X

e,

0 5(J

= 7 $&8 8

18 e

$J, 7$J . e;
fK=2J

&@K. f

Y 7$ J&@K.

,

*3X

= 7 $&8 <=+

L & $

“

I

$
`
WH07j
,K
= 7 $&8
L <=+
$J, $J
0= 7$ J&@K.

IX = , G+

+7)
t

1

%

(

2022-2024 0

$J, J

500

Y 7$ J&@K”.

,

G

Y7) &
$
`
WH07j $ , CMBFS (
,
) ?6
g6 h & / I$r6 h 8
1
5 5
+7)
&@ W6d
= 7$&8,
XJ
,
L
G\ I
7 $&8 8 e,
$J, $
&@K.
e,
,
23 ?6 7) > 8
&@ 56 $ $&8 8
$1a d L 14,21,873
+:;
&
$
L.
I a ,
?6 ) > 8
g6 h
W@0
V
7$ /$+ W@0
V
7$
7$ J
+i
I L
Y 7$
g6 h W@0
V
7) / $+ W@0
V
7) /
8L d
0=+i=
@
L;
8L
$&8
>
@
L ?7$K
+:;
<=+
,
G\ $
\
I$
$u1a vJ$J L &.
?6

g6

h W@0

•

/I$r6

J
,
= +i W

h W@0
8

,
h 7$
= 7$ I (J .

= +i (Core Committee)

(SOP) +H7j 7$ J&@
$
$J,
g6 h / I$r6

h W@0

• g6 h
,
L/ I$r6 h X L
L, $&8,
$&8 I
(
+i0
L G\ W
f% j6
, g6
V
7) / $+
W@0
V
7j
f% Wa
j6
\7j 6 =
(
= +i W
= 7$ I (J .
• $&81
•
W
g6

; 7$
,K ?6
h/ I$r6

• e
W 7$
1
7$ G

5h

L e=+i0

f%>?

7$ @6

> 8
5 h,
L W L 8
W@0
$+
G\
X L)
W@0
$+
h W@0
+i W
= 7$ I (J .
= +i SHG/PLF/ALF 5?
G
WI
,
e
e\
Y I (J .

I L
G

Y K
V ,

f%

5h
h W@0
5?I

$J

L.
8

8a

,

$
?6

x

L,
6

<!-- page 3 -->

•

$J
W
K
= V
t&@,
= +i
L / I$r6 h X L
:> 7$ I (J .

,K
V
W
K
8L d
0= +i
W
K yI x f%
5?
G\& I *7)
I L
Y 7$J
,
g6 h
,
L,
V , G
fK=2J
YK

• I L;
J= 7$
,
*
,
L / I$r6 h X L
e
, G
+ zL yG
I
I (J .
•
N{0

7j6I
G\
e L$ J* H
f%>?
;K

•

,
%7$

Wx

I$
6
|
= 7$ = V

6

&@

0@=+
L
\
+ zL e

?6
$J, 7$

> 8
,K
I (J .

I L

&, $:> &,
7$J
e > 8

•

W>2 = 7$
= +i
t
( u,

e%7$
g6 h
Y
I (J . I a
7jn%;K
:> 7$

Y 7$ J&@ e > 8
L <=+ :>? SHG/PLF /ALF

, G
W h, $%7), N(
7 $ %
@ X
@
>? W
= 7$
I (J . 5
K.

• W h, h\ |
I$
& I
I (J .
W6d 5
1
:> 7$J
6
G\ W@0

/ *

Y, h\ |
$\
G+ g6
6 =
X

Y H &, $ , 6> &,
g6 h
,

8
\
I (J .

Y K

J
6

&,
,
&

h

G\

@L
:> 7$

$
, :> 7$J

0

• W6

N(-43
e
7) II e
$ , $
n 7$ J&@ W>2 = 7$
8
x0
W 7$
1 $&8 8
5 I
X
8a
:>+
= +i
\
Y 7$
I (J . I a ,
L 8
0%7$,
W 7$
1
x0
+H7j 7$ J&@
0
:>?
.

•

SHG/PLF/ALF
( H 7$
,
0,
Wa
g6
3
(J
67$ J,
I (J .
•
$

$

yI x
\ / fi>?
/
I J
$; 7$
6 @L h Wa
L( .g) / (
L / IXL
0 @L( ,K
) G\
e =+XL, *3X J
6 e =
(
e = I
(
W +)
, G+=
5 h L W L @
X
=
NJ= 7$

W
,K V
> 8
Y 7$ I (J .

B) SHG/PLF/ ALF q I L

Y

X

G

=

& e G

|

&@ $ I

&

e,
,
23 $&8= +:;
<=+
=+ $u1
PLF / ALF (
x
8L d
0=+i)
\7j L &
JI I G
I (J .
8L d
0=+i/ g6 h / $+
W@0
V
\7j L & 23= (
$;
@ j $GH I L
Y 7$ I (J :

SHG /
&@
7)

<!-- page 4 -->

1)
*3X J
g6
Wx$ &@ SHG/PLF /ALF2) I L;
h7j

3
6 e = ,
\7j 6 e%,

+
; $
I (J .

J= 7$J SHG/PLF/ALF \7j L WI ?6
(J h7$ 6 e%= I (J .

g6

[

h1 /X L7)

0 0 =+ - g6 h/I$r6
yK
e
N \
8=+ $
,
L; d
0= +i/ PLF/ALF=+
Y 7$ I (J .

h

3)
+i
\7j
I (J ;

G+ I L
Y 7$
I$ K
/W 7$

7$ G+

4) d

0=+i

5) SHG

\7j

7)

\7j

L+

+:;

; $

~6 G\
0= +i e

8L d
K a

9) e,
WK

$&81

$ =

8L d
WH

10 5

+7)

6 $ , %=

$:>+ 1
?6
| 8 5

> 8
+7)

10 5
+7)
6
6
K $ , %=

0=+i
\7j L & > &
"
, %= I (J .

Y 7$
8L d
0=+i I$ K
G\
,
,
( %= I (J ;

„L

$J, J
G
,
„L

10) $&8= +:;
SHG/PLF/ALF =+&,
$u G\
G+

8
3

$

e

@

e%7j
( %=
$J,K
G+ +i I$ K

SHG/PLF/ALF
7$ I
$

\7j L 8
0%7$
Y %= I (J ;

N(u=
1
W 7$
\7j L & 1/2/3
8L
$1Gh W87$ G
I L;

G\

0=
$GH%=

I (J .

0=+i \7j L &
; 3 5(J 8
$G
1 H
a, 1%7$ 6 e%= I (J ;

,
L$

C) $1Gh

I$

+

$+ 1

= +i +
SHG/PLF/ALF
JI , I \ g6 h/I$r6 h
=+ $u1
fK=2J

& WI

0,

Y 7$
8L d
V
"Android
$

8) I L
I (J
[
,

\
7$

I (J .
7$ >
,
$1
8L d
I (J .
6) I L
t

$

L &

\ 5(J &

G\

1
I L
Y 7$
e; ,
,
23
J= 7$ I (J .

7)

, G
Wx
:> 7$ J&@
@
7$ G+
L
,
W>2 = 7$
G
$1Gh \
> &
,
&@ (
g6
@L h $1Gh \
,
g6
@L h $1Gh
\
[
*3X J
8L X
I $ J
\
,
f7)
:> 7$
$1Gh W
1 $
I L
Y 7$
8L d
0=+i
\7j L <=+
G
$1Gh
e6(J X
& $1Gh
:> 7$J . I a ,
8L d
0=+i
\7j L <=
2 X & $1Gh1 , 13
&
G\

$ K

7$

7 $ K

7) Wa

6

7$ G+ 1½ X
@ j

½ X & $1Ght

< ,
$GH

G\ d
7$K

:> 7$J . I a

6
L$
$ I J & $

<!-- page 5 -->

Y

G\ $6
,
L$
$1Gh :> 7$J . f%
, G+ 3
8L
0= +i
\7j L <=+ I G k $1Gh1
e,
56 j=+
25.05.2023=+& $1Gh1
,
, 01.06.2023G
J= 7$ J&@
6> <=+
15.05.2023e6(
J= 7$
6> <=+ $1Gh1
,
0= 7$ J&@K.

d
I L;
I L;
D)

=V ,

1) WI

$&8

2) WI

I L

@ ,
7$ G

Y

e%=+
e
I L

/
Y

3) I L;
J= 7$
,
*
N(
Y
I$
G\
7$ G
I *7)
1
(W
6
:> 7$ I (J .
4) g6

h /I$r6

K )

h $+

6

7) I

$ K

W

K MGNREG

I G

&@7$

,K

f%>?

I G

&@7$J

5) ?6

g6

I$r6

h 5?I

yG

I

$&8=

6

8

,K

/

&@ + zL e

7j

1

V

( ,K
I$r6
I a

I (J

) 5?I
h, 5

),

h 7) Wa

W@0
8L X

$

h/I$r6

7)

*3X J

L &

K )

6

L(?.g) /

I

7)=

Wa

(‰L

L,

1

I (J .

@L, ( ,K
Wa
n

L;
e\ 7 $

h $+

8

e =+XL,
0

W

;K&@ $&8 8

*3X J

g6

3

0,

Wa

L (VJ

),

L &, K

$

&@ $&8

$&8 @ N
*3X J

=

6

@L h Wa

L

@ g6

@L h, K

,

( H;K/
8L I

6

$

$ L=
J

I (J .

\

G\

N(u=

1

.

N(u=

$ L= 7$J K

7$J,K K
\

6

W@0 ,

e =+XL,

W

@L h Wa

K g6

;K 0$6 $

$&8 8

J

H

Wa

K )K7j,

6

0,

%=+ Wx7$

I

G\

0,

:>

6 0 L X ,K

$&8 &

h f

)

K

= I (J .

G\

(

L 8

(

1

IXL

L e

$ = 7$

G\

W

$>+:

5 h
(

W@0

= V > 8

0, K
0=

$iK

L (?.g.) g6

,K $iK$ L7) W

h $+

|

6

@L h Wa

$iKz=

= +i
1n%;K

G\

h / I$r6
L

[

,

6;K

0$6,

G\

e =

1

K I \ N;

@L h

@0

$&8=

,

W

$u

0, K

e =

, g6 , K

g6
3

0@=+
,
| ,
Y H &,
$ , 6> &
5?
GH
)
$; 7$
g6 h
,

= V , G+ yI x

I (J . I a

g6

6 / *
7$ G
I$

8

7$

e =+XL,

L

.

$&8
@ , x& W
7 $G\&@ d
0=+i
W
K
V
W
K ?6
g6 h I
W
K WI ?6 ,
@ , G+ W%
1 $
$J, 7$
I \ yI x
e%7j
+i
7$ G
e
I L
Y
.

$&8

W

V ,

,

$&8 <=+ I
L

Y 7$J .

L 8
$ , 6> 8

0

*3X J

<!-- page 6 -->

i

L 8

N(u=

0 I

, G

I

W h *

.

ii eKI$

$&8 8

g6

e =+XL,

10=+ +

*3X J

6,

h

W

$

J

5

1

$

,K, 10 =+

10=+

?=

e

L

I (J ,

I a

$ \7$ @L

@=

( H;K

e;

/I$r6

h 8

:>

I (J .

vJ$J,

,

. $1Gh

,
:> 7$

•
e
@

:>+

\

G+
,

\7j

G\

$

L

L N(u=

L &

&@ $&8=+

$&8 &

?6

&@ $&8t
d

0=

W L 8

e%=+

?6

L <=+
7$ >

N(u=

10=+ +

$G

f% d

8

0

$

e > &
e%;

0=+i

a ,

\7j

L

L &.

fK=2J

23 vJ$J SHG/PLF/ALF,
8:15 u=+&
= I (J .
$ , 6> &
+:;

1I I

5 h L

1

h

+i

Y

5

3

/I$r6

56 $

.

G+ vJ$J, 7$J

IX6

W@0

GHa

<=+

6:00

u=+

L, 7$

e%=

I (J

8.30

8.50 =+& ‹

I (J .

, $ , 6>
@ d,
YK
Œ\ 0 @0=
,I L
Y 7$
,
0 J
8I
I (J .

• N{0
$
•

I (J .

j6,I

W

>+

I G

,K $&8

|
W; 7 $&8=+

•

e

L 8

,

61

Y

8

@,

$ ;K

, G+

5 h LW L 8

,
>?,

61

I (

~67 $+

•
$u

$ ;K

|

&@ $&8 <

$

5?

(

e G

K

7$ G+

+i

0= +i

,

I (

\

+

G\

F)

>

h W@0

L & W

=

$

$ , 6> I@

8L d

@=

+i

, 6 0

I

I (J .

+

W@0

|

/ I$r6

$ \7$ @6

&@ $&81
0 I

iv.

W@0

V

W7$&81

06 e 6

8L I

5 h LW L 8
iii $&81

e%;

G\ yG$
e%=
H j ) $ , 6>
@ ~Y

7$ G+
0=+i \7j

L &

7
$ %
Y , &

9.30AM=+& $&8 ‹:a=+ N{0
d
0= +i \7j L & W7$&8

X

+ d,

& W
K
Y H
@$
$J, 7$ =V

7$ G+
Y 7$
@
K.

) ,
I (J .
, %=

d

• $&8=
0, K
:> 7$
)&8 0$6,
$ , $&8 8
%
) t
L 8 N(u=
G\ d
0= +i
7 $ \7$ @6
$6
= 7$J
%
$ 0 $
L 8
N(u=
1
W 7$
1a , $&8=
0, K
1
5I
, W
K
$; 7$
$&81
h L
5I
1 $ t
6
N(u=
1
= 7$
I (J .
G)
$ , 6> & G\
N
t :>+
G
&

<!-- page 7 -->

• ?6 ) ,
:>+
G+ I
[ X
G\

&@ $&8
7$J
8L

,
N
K

+:;
<=+
t, WJ7) G\ $ , 6> <=
:> 7$J .

,K

• 0
$J, 7$
> <=+
e =+XL,
*3X J
8L I
\
G\
$; 7$
5 h L $
&@ >?=
=?
X
G\
8L
K
1n%;K
0J0= 7$J .
•
N
j

56 j= 7J f%
t e
7)
@ g6 h W@0
$GH
&
Y
, W; ;
:>?
5 h 6
; 7$
0J0= 7$ I (J .

• $&8

> <=+ e6(J N
N
t :>+
\

$

J
[

6, G+
I6
$ , 6> & /
V
7)
X
7
$&8
> <=+
IX6,
g6 h W@0
V
7) <=+

t hn( L
, G+

@ N{0
L

e L$ J*
Lj

H :>?
Wx7$7$

I (J .
H)

8

•
\
$ %
N(
$ %

$ %

&

G\

Y H &

>+

G

&

a=+7 $
$J, 7$J
$ %
& X
6
FSSAI
$G 7$
K N
\ 7$J, 7$
e%= I (J .
6 G
j
&
NK
a=+
$
$J, =V K.
f%
$
$J,
•(J
$
$J,
V K.
a=+7 $
$J, 7$J
7
& 6
,
7$
W@0 $ t e%= I (J .

•

=+

$ %
@
W h, 7), N(
Y, L=
6 G\ $%7) I$
=?
$ %
@ *3X J Ž L $ %&
u$= :
[
JI
&
Y
I (J . &<L $ %
@
&
Y
V K. j
L *3X J
Ž L $ %&
u$=
: , G+
$ %
&
&
5
:>+
G+
) IXL
0 @L ( ,K
)
G\
6 @L h Wa
L
( .g) 5?I L
6,
V
I
5Y
YK W
j
I6
*3X J
Ž L $ %&
u$= : ,
&
Y 7$ I (J .
•
[ 7 $ %
@
I K
6 , I @ 6 , 6 , I * , $ h7$%7), h 7)
*@ Y,
J+, *@+, h\ | > & I$
I
$J
$ %
@ e
$
@L, V J
>
/
V J
>
G\
$ K 0 I
=
&
[
:> 7$ I (J .
• GI$ K&@
,
$ I
W 7$
1 $
0$6,
e%7) $ I
vJ$J, 7$J SHG/PLF/ALF

,

,K
W
7$ @6
$
$J, 7$J
$
Y
W
7 $ \7$ @I6 $ \7$
L.

$6

= 7$J e%7)
7
$ %
8
$6
7$ G+

• I L;
J= 7$
SHG/PLF/ALF
, ,
%>
, I 6 ,
% @=?:>+, $
$
u, = 8,
>
, $
*@ Y I$
Y H
@
&•L ;
1
e%;K
>
W
K $&8 W
K g6 h/I$r h1
&@
$ K
$+ 1
?6
g6 h/I$r6 h1
[
&@
Y H, I
W
,K
Y H
@ $1
J, $6
,K W= Y H
@$
$J, I (J .
•

$ L/?
YK W

=+ $
6,

$J, 7$J
Y H
$ L= I (J .

@

a=+ $

$J,K

d,

<!-- page 8 -->

• W; ;
,
Y H

g6 h / I$r6 h 8I I
&@
$ K
,
23 $
$J,
= 8, $
*@ Y, ,
@0
,K, 0 @0,K $
$J, I (J .

• d
$6

0= +i
d,

7$K

?6

\7j

L &
u;K d

6

=+
I$ K
G\
$
\7j L &
1
7j & G\
t
/ ALF [
% , G+ f%
7j & G\
I)

G\

7) g

, G

L

,

I$

=+
I$ K,
I (J .

e%=

•

$+ 1
%>

d,

\
I$ K
d
0= +i
@ Wu K
; 7$
PLF
t
& :> 7$ I (J .
1= 7$J

1) 56 $ $&8= +:;
<=+ e,
,
23 e
,K f% +:;
=+
$ %
& G\
Y H & :>+
G+ 5+
0 ,
1
SHG/PLF/ALF-G+
0J0, J I$ K 11.08.2022 I
1
Roc.No17570/
,
-2/2021 e
[ X
G\
8L
,K
1 e =+ 6
81 7$ J&@
@
j $GH WH \, 7$ J&@K.
2) f% +:;
1
=?G+ 0J0= 7$J .

=

N

$ %&

r.1.25 ‘

PLF/ALF

3) W h,
;
W h, $%7),
L=
6,
7)
G\
N(
Y I$
[ 7 $ %
<=
0 ,
1
IXL
0 @L ( ,K
,
6
@L h Wa
L ( .g) 5?I 6
=? 7$ J W G
1
(
I
@L, Ž L $ %&
u$= : , G+ 6 , I K
6
I *
I$
$ %
<=
1
e
$
@L V J
> , G+ $
n W 7$
1 0J0= 7$ I (J .

)
,

4)
7$ >
$+
& /
?6
W
56 $ $&8 +:;
8
N(u=
G\
W 7$
1
f%
, G+ I L;
J= 7$
W6 > ,
„L |= 7$J .

K
87 $+
8
&@
> 8
e%7j
5?
GH
SHG/PLF/ALF=
7’

5)

0= +i

7’
,
=? 0J0= 7$J .

6) $&8 8

K

; 7$

L N(u=

10=+

$ =”

:>

e L <=+

7$’

:> 7$J .
J) $&8 I
(

+i

•
N(u=
+i i

,
= ( H
$ \7$ + .

•
6 u
V ,

=V
6 d
;K

+

f% d

:> 7$J
G\

d

$&8

23 $
G+ $&8,

e%;
0=+i

G+7 $

0 I

L vJ$J, 7$J
=

L.
J

&

0%7$ &@ +:;
8
5h L G\ $&8 I

$&81
@ , G+& W
0= +i0 6
= yG$ J
Y I (J .

>?=

, W; 7 $&8=+ “
\7j

5h

\7j

; %;

,
5.30
7$ G+ yK

(

u
G

<!-- page 9 -->

•

8.30

( u,
\7j
I (J .

yK
e%7

u=+,
d:Gh
1
$
5h

>?
9 u=+&
$&8 5h L W
K $&8 I
L G\ $&8 I
(
+i

t
(
\

6
+i
Y

•
7
$ %
& W
K
= 7$
,
G\
$
$J, I
W
K ‘
= 7$ 0
N $
$&8,
h L/$&8
I
(
+i
\ 7$J,K K
( u7)
I G
&@7$
I (J . I a
+:;
<=+
$
\
$&8
h L W
K $&8 I
(
+i
\7j L %h,K
\
Y
I (J . f{
% X < f% $
n
@ NJ,K
= I (J .
• +:;
<=+ 0 I ?= 7$J
0
6
G\
I $J,
j –
WH=
1
$&8 I
0= +i \7j L <=+ W8= 7$ I (J .
K) W>2

= 7$

&

G\

0

(

W@
+i

5?

G
8L d

W@ :

• 27.07.2022 I
1
G.O N(.43 e
&@ W6
G\
[ X
G\
8L
,
K
e =+X6
0= 7$
0
8 $
W>2 = 7$
8
W
1 $
= 7$
I (J . eK
L$
5 h L W L @
5
j 7j= 7$ I (J .
,
,
23 50 ?6
W h, 6
, I K
6 , I *
W
K h\
| > & G\
, j + 150 ?6
200 ?6
:> 7$ I (J . $%7) 15 ?6
G\
, j +
Y H <
60 ?6
$ L f% +:;
=+ N
W@0
:> 7$
I (J .
&8=?:
8 e|7) I
t
60 ?6
G\ 100 ?6
Y H ?
$
7$ I (J . W
,K
6> 8a
&@ W
,K7 $&8 8a 5
I
X
8a +:;
<=+
,K :> I (J .
• e =+XL SW&WE Lr.No17570/NMP-2/2021,
W 7$
1
$1Gh1
I$ K
J= 7$
g
,K&@ G\
W@ [ 7 $ %
150 ?6
(
, j +)
0
SHG

11.08.2022 WH \, n
W
1 $
8
t
f% +:;
=+
( 7$
:> I (J .

• W
W 7$
1
x0 h\

h\

L)

G\
6> 8
&@
5 h
LW L 8
| > 8 W 7$
1

I

| 7

$ %
8
e%7)
8 $ e6(J X
&
e%=
.

[

• I L;
I$ K

J= 7$
[

• 2
I G

3
G+

&

• +:;
SHG

8
e%=

SHG/PLF/ALF,
,
=
( %=

,
I (J .

> <=+ W L 8
e
7) W
K I$ K

$ K 7), G\
I (J .

X

; 7

,

23 $u & I G

&@

$ \7j
$u &
e%7) e%= I (J .
(J

$J

X $

<!-- page 10 -->

• W6 > ,
e%;K
$\
I ( 1%; a ,
$u
SHG/PLF/ALF I G
&@ I (J .

M)

(

u7)

•

G\

yG$
Y

G

$J,K K
h & K
I
(
e =+XL ,
,K VJ
e =+XL G\ e
L @ 5Y I G
&@7$ J

5 h L G\
e =+XL *3X J
g6
0 e =+XL (g6 h &) /
Wa
L (I$r6 h &),
IXL
0 @L( ,K
) 5?I 6
6,
3 X
&
$&8
> 8 5Y
Y 7$ I (J .
5 h

•
0,
$&8 8
WH=

6

Wa

*= 7$J
(
$&8
> 8 5Y

0,
Y 7$

\

@L,
6
f%>?
g6 h/I$r6 h 8
&@7$ J
0
6
e =+XL G\
(

e7$u

@

(

u=

6, G+

6 e =
>
@

$ %
8
G\
(
@L V J
I (J .

N) e,

\ WJ=+ W

W@0
• e=+i0G+
@L h
,

(

u7$ G

V

[

G
f J
) e%7$ L.

3
$&8
0=

@L ( ,K
)
7
=? $>+ ?,
:
G\ e
7 $
a,K
\
Y

G\

$J,K
(

g6
[
@

•
5 h
IXL
0
0 I
,
f J
,
( u7j
I
@L *3X J Ž L $ %&
u$=
>
5?I %=+
IX6,
$

=

,

7$ @L &
G\
&@ $&8 <=+ W =
G\
W
W@
+H,
0,
Wa
L 8

$ \7$ @6

,

e,
L(VJ

0$6,

,

0

/

I (J .

5 h L G\
e =+XL, *3X J
G\
e =+XL,
g6
@L h
( u=
,
$ J
@ N8 =
,
%,K
W@0
™W7 +i % = 7$J .
W@0
Wa

6 e =
5 h

Wa
L &
I (J .

G\ e 6 WI
+ 1
Wa
L @
L
@ 5Y
I G
&@7$ J W
5 h
L7j= I (J .

•

•

3

L &

•
6
e =
I
f%>?
7$ @L & ?6
L
@ 5Y
I G
0$6,
WH=
L7j= I (J .
• CRP (P&C) X &I

Y 7$
1

W@0 5
L g6
@L h
*3X J
8L I $ J \
e =+XL &, g6
@L h, K
> & ( u= 7$J .

•

•
10-15

L
,

7˜J
,

G\ g6
G\ W
5?I 6

a , j
0

7)

+i
6

5 h
e =+XL *3X J

L

G\
g6

e =+XL
3
6 e =

g6
,

<!-- page 11 -->

5 h
IXL
0 @L ( ,K
),
[
% Y Wa
L,
0 e =+XL(I$r6 h &), e
(
I
@L, Ž L $ %&
u$= :
G\
Wa
L &,
\7j 6 e%7$L.
•
f%>?

5 h
7$ @6

6 W@0

W@0
h &), (
@L 5?I

e =+XL, *3X J
$ J & +H,K

•
6
e%7$ L.

0

@L h Wa

g6
5 h

+i

• g6

h / I$r6
,
$J .

h W@0 e,
,
h 7$

$J,
67)

6

,

5h L e; = +i0
$u G\ L.

+i0

,

,

I (J .

= +i0

f%>?

7$ @6

23 W
= 7$ J&@
+i,
$J,K
G
( u7)= +i

f%>?

7$ @6

e%;K,

,

7˜J

•

I G k
W6
1
$J,K
7jJ
G
1
W 7$
G\ e\
[
7˜J
Y 7$J .
O.

W@0

3
6 e = ,
WH=
L7j=

L (?.g.)

h W@0

[

)

6

> ,
@L h

+i0
6
@L h
Wa
L,
0,
Wa
L,
h L,
=? I 0 ,
L
6 W@0
+i0
\7j L @ e%7$L.

g6

• $&81
$

@L ( ,K

L,

+i

•
e{
6
Wa
L(I$r6
6e = I
•

IXL
e%7$ L.

X ,K
Wa
$
@L, V J
$; 7$

, G

W 7$
1
[ X
G\
=
J7) I G

[ 7 $ %

8

,

h 7$
8L
,K
K
1
&@7$ J 3
67) j6
&

&

1. Lr.N(.17570/NMP-2/2021 dt.11.08.2022 e
e =+XL [ X
G\
8L
, K
5
0= 7$
W@0 $ f% +:;
=+ I
7$J W h,
7), N(
Y, $%7), (K 6 $%7))
G\
L=
6 5?
[ 7
$ %
8
0$6,
K
6
@L h Wa
L ( ,K
)-5
L
Y 7$ J
5 h L W L 8
8 $ IXL
0 @L
( ,K
)
1
*3X J Ž L $ %&
u$= :, G+
&
5
:> 7$ J
$; 7$
$&8
> <=+
,
:>+
I$
$ %
& :>?1%7$
\
Y I (J .
2. 6 , I K
6 , I @ 6 , I *
( 6*@ Y), *@+, J+,
;
h 7)
*@ Y,
XY I$
j
8
7
$ %
8
W@0
+:;
8
N(u=
=+ yG $
7˜J
= 7$ J, e
$
@L, V J
> , G+
:> 7$ J
0
=
&[
:> 7$ I (J
G\
7$ G+ I L
Y 7$ J&@ SHG / PLF W
0
=
8 e%;K
$G\=
&@ I (J
G\
e6(J
&
<=+ ,
(
I
@L,

<!-- page 12 -->

*3X J Ž L $ %&
u$= :
5?
GH
e%;K
67 $\
5 h,
LW L 8
P. $ I J

@ $6

1.

@

7

$6

$ %

2. SHG / PLF/ALF

,

4.

L

%

$ I J

5. $

6

G\

N(u=

&/ e%7) $

7. W

5Y

yK
+7$

G\

$ I J &

G

$ I J.

$ I J

$ I J(

$ %

&)

+H7) & $ I J.

0
d

9 I$I6J &

0 6> & e6›K

6. [ 7 $ %

0

%

$ I J

L 8

9.

j

& e%7) $ I J ($ , 6> &)
%

8. X

8

, G
= 7$J ;

3.

8

$
@L, V J
> > &
W 7$
1
1
1
:> 7$J .

,
,

SHG/PLF/ALF 5

G\ e
0
7$

G\

&•L

$ %&

&

Y

+H7) $ I J

d
0= +i= & / PLF/ALF &
e =+XL, [ X
G\
8L
W h 7$ J SHG/PLF/ALF <=+ 0 I

$ I J
K
?= 7$J .

@ $6
,
$ I J & fI6

1%7)
[ 7 $ %
& W
K
1
yI x
+
$ J
( H 7$
, ,K
,
X
=
I G
& K I$
6 @L h
Wa
L( .g),
Wa
L (I$r6 h &) [
$&81
GV
7
$ \7$ @L SHG/PLF/ALF
\7j L •K I
X
=
I G
& K
5 h
IXL
0 @L ( ,K
) /
e =+XL, *3X J
g6
3
6e =
/
5 h L 5?I
) 68= 7$J .
Q.

,

1.

W

7)

,

8L
,K
I $ J
\
,
e;
>?, Ž>
2.
e

5 h L
;K
$J
,
, G
I (J .
3.

, G

I

$J, I
e =+XL, [ X
G\
0J0= 7$J
I
(
e =+ L, *3X J
8L
L ?= 7$J
()*+
$ =
>?
=?
6
= 7$J .

G\

e =+XL *3X J
g6
1 ,
5 h 6
()*+
fI6 >?1 j6,I
| >?=

3
=+

6 e =
> 7$

(
e =+XL,
*3X J
8L I $ J
\
W L @
> <=+
0J0= 7$J , (
I
@L, *3X J Ž L $ %&
u$=
:
G\
e
$
@L, V J
> ,
:> 7$
W
,K
[ 7 $ %
<=
0 ,
G\
[ 7 $ %&
0 I
0
7$
W 7$
1
0J0= 7$ I (J .

<!-- page 13 -->

4. e =+XL [ X
G\
8L
, K
G\ I
(
e =+XL,
*3X J
8L
I $ J
\
5?I
WH \, n $
[ 7 $ %
<=
=
, j +, &•L
Y H &/
$ %
&
&
Y
G
0 ,
G\
7’
:>+
G
PLF/ALF
=? 0J0= 7$J . PLF/ALF W G\=
6 = 7$ I
$6
7$K
& G\
60
$
Y K
6
e6›K
@t $6
= 7$ I (J .
5. PLF/ALF
W L 8
6.
\7j

=?G+ 0J0= 7$J
>?=
=?G+ IX6

Y H/
L/$&8

7

7. N; f% ‹3
IX6 $
$
L,
L

(

,K
>? $

0
>?=

1a g6 h W@0
&I G
&@=V K.

G\

, K
u,

$ %
8
$ \7$ @

7

W

$J,K

< RTGS [
I
W
K
G
[
I
0J0= 7$J .
K d
=?G+ 0J0= 7$J .
/$+

f%>?

V

7) &

K

W@0
0J07$ G+ e =+XL, [ X
G\
8L
W L I@ $ \7$ + . e 6 K
& e,
,
f%>?
,
,
G\ W6d=+ WH=
L7j,
5?
G\=+7 $ \7$ + .

g6 h7 $+
@7 $ \,
, ?6
g6 h f H > &, I
(
e =+XL,
5?I L $ \7$ K
e,
,
t

G\
\

W@0

0=+i

=+

K

g6 h & / I$r6
*3X J
8L I
$J,K L.

h &
$ J

&:

()*+
,
,
e 6 $ I \ j
K
<
e
;K, f%>?
,K
$J, 7$J . j K
@
$&8=
0 K
, *3X J Ž L $ %&
u$= : , V J
>
G\ g6
@L h, K
I$
K
& e,
,
$
$J,
=? $>+
?=?
. e,
,
[
$
$\
L &
L$
W
,K
0 6>
@t
$&8=
0,K
W8=
I (J .
,
$J,K
$&8 I
(
+i
=? $>+ ?=+
G\ e
I
01
h 7) Wa
L
W@0
f%>?
7$ @6
$J .
W@0 ,
=
0 Wa
L,
0 Wa
L,
W; ;
6> &, (
> & G\
> 8
0 Wa
L
5?I L e,
,
= ( u,K
h 7)
$
$ \7)
?7$L.
$

57 [
e;

(

u,

:

,
$J,K
j6, I
( u7$ G
TNeGA 5
= 7$
"
$ 57 CMBFS" % = 7$J . ?6
g6 h &
/I$r6 h 8
&@ $&8
>
@7 $ \,
, 5( 6 YJ
$a
$&8
7 $ \7$ @6
SHG
\7j L,
>+
,
,K
,
G\
$
\
G\
NJ,K=
(
+:;
8
N(u=
I$
0 6>
@ )
7$ > <
ŸI I = [
$ I G
Y 7$ I (J . e
yI x
yG$
, N
=
Y
6 W@0
:> 7$J . e,
,
h 7)
$J,
W@0

<!-- page 14 -->

Wa
*

L &,
k G\

*

W@0
kW

Wa
$

"CMBFS-Mobile App" e
8a
$ J

@

L & vJ$J, 7$ J&@
&
1
$ I G
$ J, '56 $ '
( u,
h ;

$&81
GV
,
$ \7$ @6
e6(J )
7$ > <
0$6>
@ W6
L
$ I G
Y
G+ $1Ght
:> 7$J .

L. )&8 0$6> &
Y 7$J .

e\ '
%0

6 W
&@K.

,K

d
0= +i
\7j L
1= 7$ J&@ IX6, G+&

6:
e6,
+

$ J

G\

$&8 &, 17

$&8

L 8

I

$&8 e

G

I
=+

, g
=? K.

,K

,
963 g6 h f H
56 $
G\ 16
> 8
&@ 346 ?6
g6 h 8
$J, 7$J? K.
,
,
0= +i
\7j L 8
$>I G),
vJ$ J
G\
Y
W L 8
WL7$u7)
L
W
,K
> & I$
G
$ 6
7$J? K.
$J,
[
$&8 8
= L 8

6> &

$J,K
d
+:;
<=+ I
$,
&, [ g
,
%
W
,K&@K.

eI h ;
$ J G\
G
,
,
0
= ,
7$J K
$&8 8 ?6
W@0
+i
% =+
, d
0= +i / g6 h W@0
/ $+ W@0
V
7)
8 6 I L
Y
, W L <=+
$1Gh G\
I $ J W
Y
, oCMBFS Mobile Appp
1
0$6>
@ $ I G
Y
5?
GH
1
56 $ $&8 8
$1a
L
@
) t , 5I6 =?
,
$ 7j
h ;K
0@>+
+:;
@
:
Y K
pg
,K
+
$
+:;
@
(
p
GH
,
$J, 7$ J ( u= 7$ J %? K.

<!-- page 15 -->

0J0= 7$J

[

&

e =+XL
G\
8L

X

I
*3X J

(
8L I

K

e =+XL
$ J \

5 h,
e =+XL *3X J
g6
5 h
IXL
0

&)

W h,
G\

&
&

6

,I

K

(e

$

Y H &
N

g6 h W@0
/ $+ W@0
V
7)
( Y H & 8
$ %
&, N
t
g= ,
)

, W h, $%7), L=
N(
Y( (
I

*3X J Ž L

$ %
7

L
3
6e =
@L ( ,K
)

e
$
@L
V J
> > &
(
$ %
&)

(
I
@L
*3X J Ž L $ %&
u$ :
(
$ %

.

t, g= ,

$ %&

6

u$

,I *

@L V J

8
(

:

6,
@L

)

G\

j
> > &)

$ %

&,

&<L

&

(PLF- SHG)

7)

)
