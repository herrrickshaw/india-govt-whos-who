---
doc_id: "1aa30b27ad3f8ddf"
source_url: "https://tnpcb.gov.in/PDF/Updates/Tenders/RFPOCMMS_271026.pdf"
ministry: "Tamil Nadu Pollution Control Board (TNPCB), Tamil Nadu"
title: "Selection of Consultancy Firm to Provide Project Management Support, Functional and Technical Study, Preparation of Functional Requirements Specifications (FRS) and Preparation of System Integrator Tender Documents for the Revamping and Integration of Tamil Nadu Pollution Control Board's Online Cons"
date: ""
pages: 45
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b0b0428befe561ad"
---

<!-- page 1 -->

REQUEST FOR PROPOSAL (RFP)

FOR

Selection of Consultancy Firm to Provide Project Management
Support, Functional and Technical Study, Preparation of Functional
Requirements Specifications (FRS) and Preparation of System
Integrator Tender Documents for the Revamping and Integration of
Tamil Nadu Pollution Control Board’s Online Consent Management
& Monitoring System (OCMMS)

RFP Ref No. TNPCB/4483/2026-ITW-1/2026, dt 22.10.2026

Tamil Nadu Pollution Control Board
No 76, Mount Salai, Guindy,
Chennai-600 032, email: tnpcb-chn@gov.in

October-2026

<!-- page 2 -->

BID DATA SHEET
Sl.

Particular

No.
1

Name of Assignment

Details

Selection of Consultancy Firm to Provide Project Management
Support, Functional and Technical Study, Preparation of Functional
Requirements Specifications (FRS) and Preparation of System
Integrator Tender Documents for the Revamping and Integration of
Tamil Nadu Pollution Control Board’s Online Consent Management
& Monitoring System (OCMMS)

2

Procuring Entity

Tamil Nadu Pollution Control Board (TNPCB)

3

Mode of Tender

Open RFP / e-Procurement

4

Form of Contract

Consultancy Services - QCBS

5

Number of Covers

Two Cover System: (i) Technical / Pre-Qualification Proposal; (ii)
Financial Proposal

6

Tender Fee

Rs. 10,000

7

EMD / Bid Security

Rs. 1,80,000

8

Pre-Bid Meeting

03.11.2026

9

Last Date for Addendum

06.11.2026

10

Bid Submission Deadline 16.11.2026, 2:00 PM

11

Opening of Technical

16.11.2026, 3:00 PM

Proposal
12

Technical Presentation

To be intimated to eligible bidders

13

Minimum Technical

70 out of 100

Score
14

QCBS Weightage

Technical 80: Financial 20

15

Bid Validity

180 days from bid due date

16

Performance Security

5% of contract value / as applicable

17

Contract Period

8 months from the issue of Work Order

18

Proposal Language

English

19

Submission Portal

Tamil Nadu e-Procurement Portal / as notified in the Tender Notice

<!-- page 3 -->

Sl.
No.
20

Particular

Contact

Details

The Member Secretary, TNPCB, 76, Mount Salai, Guindy,
Chennai - 600 032,
Email: itwing@tnpcb.gov.in
Mobile: 8056042179, 8925891934

<!-- page 4 -->

IMPORTANT NOTICE

This tender procedure is governed by the Tamil Nadu Transparency in Tenders Act,
1998 read with Tamil Nadu Transparency in Tender Rules, 2000 as amended from time to
time. In case of any conflict between the terms and conditions in the tender document and the
Tamil Nadu Transparency in Tenders Act, 1998, the Tamil Nadu Transparency in Tender Act,
1998, read with Tamil Nadu Transparency in Tender Rules 2000 shall prevail.

<!-- page 5 -->

DISCLAIMER
The information contained in this Request for Proposal document (“RFP”) or subsequently provided
to Bidder (s), whether verbally or in documentary or any other form by or on behalf of the Member
Secretary, TNPCB, or any of their employees or advisors, is provided to Bidder (s) on the terms and
conditions set out in this RFP and such other terms and conditions subject to which such
information is provided.
This RFP is not an agreement and is neither an offer nor invitation by the MEMBER SECRETARY,
TNPCB, to the prospective Bidders or any other person. The purpose of this RFP is to provide
interested parties with information that may be useful to them in preparing their technical proposals
and financial offers pursuant to this RFP.
This RFP includes statements, which reflect various assumptions and assessments arrived at by
the MEMBER SECRETARY, TNPCB, in relation to the Assignment. Such assumptions,
assessments and statements do not purport to contain all the information that each Bidder may
require. This RFP may not be appropriate for all persons, and it is not possible for the MEMBER
SECRETARY, TNPCB, its employees or advisors to consider the investment objectives, financial
situation and particular needs of each party who reads or uses this RFP. The assumptions,
assessments, statements, and information contained in this RFP may not be complete, accurate,
adequate or correct. Each Bidder should, therefore, conduct its own investigations and analysis and
should check the accuracy, adequacy, correctness, reliability and completeness of the assumptions,
assessments, statements, and information contained in this RFP and obtains independent advice
from appropriate sources. Information provided in this RFP to the Bidder (s) is on a wide range of
matters, some of which depends upon interpretation of law. The information given is not an
exhaustive account of statutory requirements and should not be regarded as a complete or
authoritative statement of law. THE MEMBER SECRETARY, TNPCB, accepts no responsibility for
the accuracy or otherwise for any interpretation or opinion on law expressed herein.
THE MEMBER SECRETARY, TNPCB, its employees and advisors make no representation or
warranty and shall have no liability to any person, including any Bidder or Bidders under any law,
statute, rules or regulations or tort, principles of restitution or unjust enrichment or otherwise for any
loss, damages, cost or expense which may arise form or be incurred or suffered on account of
anything contained in this RFP or otherwise, including the accuracy, adequacy, correctness,
completeness or reliability of the RFP and any assessment, assumption, statement or information
contained therein or deemed to form part of this RFP or arising in any way in this Bid State. THE
MEMBER SECRETARY, TNPCB also accepts no liability of any nature whether resulting from
negligence or otherwise howsoever caused arising from reliance of any Bidder upon the statements
contained in this RFP. THE MEMBER SECRETARY, TNPCB, may in its absolute discretion, but
without being under any obligation to do so, update, amend or supplement the information,
assessment or assumptions contained in this RFP. The issue of this RFP does not imply that THE
MEMBER SECRETARY, TNPCB, is bound to select a Bidder or to appoint the Selected Bidder, an

<!-- page 6 -->

Authorized manufacturer for the Assignment and THE MEMBER SECRETARY, TNPCB reserves
the right to reject all or any of the Bidders or Proposals without assigning any reason whatsoever.

The Bidder shall bear all its costs associated with or relating to the preparation and submission of
its Proposal including but not limited to preparation, copying, postage, delivery fees, expenses
associated with any demonstrations or presentations which may be required by THE MEMBER
SECRETARY, TNPCB, or any other costs incurred in connection with or relating to its Proposal. All
such costs and expenses will remain with the Bidder.

<!-- page 7 -->

Table of Contents
1. NOTICE INVITING REQUEST FOR PROPOSAL ..........................................................................................9
2. DEFINITIONS AND ABBREVIATIONS ................................................................................................................9
3. BACKGROUND AND PROJECT CONTEXT ................................................................................................. 10
4. OBJECTIVES OF THE ASSIGNMENT ............................................................................................................. 10
5. TNPCB INPUTS TO THE CONSULTANT ....................................................................................................... 11
6. DETAILED SCOPE OF WORK ............................................................................................................................. 12
6.1 As-Is Study of Existing OCMMS .................................................................................................................... 12
6.2 Gap Analysis Study .............................................................................................................................................. 12
6.3 Regulatory Alignment and Automated Checks / Validations ........................................................... 13
6.4 Application Forms and Statutory Forms .................................................................................................... 13
6.5 Benchmarking of GPCB, MSPCB and Other SPCB/PCC Systems ............................................ 13
6.6 Integration with OLGPRS, OLMMS, LIMS, OCEMS, GIS and Other Systems ..................... 13
6.7 Single Sign-On and Unified Access ............................................................................................................. 14
6.8 Data Cleansing and De-duplication ............................................................................................................. 14
6.9 Data Migration and Database Management............................................................................................ 15
6.10 Automated Consent Fee Calculation ........................................................................................................ 15
6.11 Technical Architecture and Non-Functional Requirements........................................................... 16
6.12 Preparation of FRS ............................................................................................................................................ 16
6.13 Preparation of System Integrator RFP / Tender Documents ....................................................... 16
6.14 Support During System Integrator Procurement ................................................................................ 17
6.15 Project Management and Implementation Support till Go-Live................................................... 17
7. MILESTONES AND INDICATIVE TIMELINE ................................................................................................. 18
8. CONSULTANT TEAM AND KEY PERSONNEL .......................................................................................... 19
9. ELIGIBILITY / PRE-QUALIFICATION CRITERIA ........................................................................................ 21
10. CONFLICT OF INTEREST AND INDEPENDENCE ................................................................................ 24
11. PROPOSAL SUBMISSION REQUIREMENTS .......................................................................................... 24
11.1 Cover 1 - Technical / Pre-Qualification Proposal ............................................................................... 24
11.2 Cover 2 - Financial Proposal ........................................................................................................................ 24
12. TECHNICAL EVALUATION ................................................................................................................................. 24
13. TECHNICAL PRESENTATION........................................................................................................................... 26
14. FINANCIAL PROPOSAL AND QCBS EVALUATION ............................................................................. 26
15. FINANCIAL BID STRUCTURE ........................................................................................................................... 27
16. PROPOSED PAYMENT MILESTONES ........................................................................................................ 27
17. PERFORMANCE SECURITY ............................................................................................................................. 28
18. CONTRACT PERIOD AND DEPLOYMENT ................................................................................................ 28
19. GOVERNANCE AND REPORTING ................................................................................................................. 28
20. CONFIDENTIALITY, SYSTEM ACCESS AND DATA SECURITY ................................................... 29

<!-- page 8 -->

21. INTELLECTUAL PROPERTY AND OWNERSHIP OF DELIVERABLES ..................................... 29
22. DELAY, NON-PERFORMANCE AND LIQUIDATED DAMAGES ..................................................... 29
23. CHANGE CONTROL ............................................................................................................................................... 29
24. TERMINATION............................................................................................................................................................ 29
25. FORCE MAJEURE ................................................................................................................................................... 30
26. DISPUTE RESOLUTION AND JURISDICTION ........................................................................................ 30
27. GENERAL BID CONDITIONS............................................................................................................................. 30
28. ANNEXURES / PROPOSAL FORMS ............................................................................................................. 30
ANNEXURE A - LETTER OF PROPOSAL........................................................................................................... 31
ANNEXURE B - BIDDER PROFILE ......................................................................................................................... 32
ANNEXURE C - ELIGIBILITY COMPLIANCE..................................................................................................... 33
ANNEXURE D1 - Similar Government / e-Governance Assignment Experience ............................. 34
ANNEXURE D2 - Data Migration Experience ..................................................................................................... 34
ANNEXURE E - TEAM COMPOSITION ................................................................................................................ 35
ANNEXURE F - FORMAT FOR CV OF KEY PERSONNEL ....................................................................... 36
ANNEXURE G – APPROACH AND METHODOLOGY ............................................................................................... 37
ANNEXURE H - WORK PLAN AND STAFFING SCHEDULE.................................................................... 41
ANNEXURE I - BLACKLISTING / DEBARMENT DECLARATION .......................................................... 42
ANNEXURE J - CONFLICT OF INTEREST DECLARATION ..................................................................... 43
ANNEXURE K - FINANCIAL PROPOSAL FORMAT ...................................................................................... 44
ANNEXURE L - INDICATIVE MONTHLY PMC REPORT CONTENTS ................................................ 45
Table 1: Milestone and Indicative Timeline ..............................................................................18
Table 2: Consultant Team and Key Personnel.........................................................................20
Table 3: Eligibility/ Pre-Qualification Criteria ............................................................................22
Table 4: Technical Evaluation ..................................................................................................25
Table 5: Financial Bid ..............................................................................................................27
Table 6: Payment Milestones ..................................................................................................27

<!-- page 9 -->

1. NOTICE INVITING REQUEST FOR PROPOSAL
Tamil Nadu Pollution Control Board (TNPCB) invites proposals from eligible and experienced
consultancy firms/agencies for selection of a Consultant to undertake the functional and technical
study, Business Process Re-engineering, benchmarking, preparation of Functional Requirement
Specification (FRS), preparation of the Request for Proposal/tender documents for selection of a
System

Integrator,

assistance

during

System

Integrator

procurement,

and

project

management/technical supervision of implementation of the revamped Online Consent Management
and Monitoring System (OCMMS) until successful Go-Live.
The selection of the Consultant is proposed to be undertaken through a Quality and Cost Based
Selection (QCBS) process under a two-cover system, subject to the applicable provisions of the
Tamil Nadu Transparency in Tenders Act, 1998, the Rules made thereunder, as amended from time
to time, and other applicable Government instructions.
Interested bidders shall submit their Technical and Financial Proposals in the formats prescribed in
this RFP within the stipulated date and time online through the websitewww.tntenders.gov.in
2. DEFINITIONS AND ABBREVIATIONS
Term

Meaning

Board / TNPCB

Tamil Nadu Pollution Control Board

BPR

Business Process Re-engineering

Consultant

The consultancy firm selected under this RFP

FRS

Functional Requirement Specification

GIS

Geographic Information System

Go-Live

Production deployment and acceptance of the revamped OCMMS by
TNPCB after completion of the prescribed readiness criteria

LIMS

Laboratory Information Management System

OCEMS

Online Continuous Emission Monitoring System

OCMMS

Online Consent Management and Monitoring System

OLGPRS

Online Grievance Petition Redressal System

OLMMS

Online Legal Monitoring and Management System

QCBS

Quality and Cost Based Selection

RFP

Request for Proposal

SI

System Integrator to be selected subsequently for development and

<!-- page 10 -->

Term

Meaning
implementation of the revamped system

UAT

User Acceptance Testing

3. BACKGROUND AND PROJECT CONTEXT
TNPCB is using the Online Consent Management and Monitoring System (OCMMS) since 2015 for
online processing of Consent and Authorization-related applications and associated regulatory
functions. The existing OCMMS was developed using Groovy-based technology and has been in
operation for more than a decade.
Over time, regulatory requirements, industry categorization, application volumes, Board workflows,
digital services, data requirements and technological expectations have evolved substantially.
TNPCB therefore proposes to comprehensively revamp the existing OCMMS into a modern, scalable,
secure, integrated, user-friendly and data-driven regulatory platform.
The proposed exercise is not intended as a mere technology migration. It shall include
comprehensive study and redesign, wherever required, of the application forms, fields, workflows,
validations, Consent and Authorization processing, inspections, e-Noting, regulatory/enforcement
proceedings, reports, dashboards, database structures, integrations, system administration, user
interfaces and data migration arrangements.
The revamped OCMMS is envisaged as the principal regulatory application of TNPCB and shall
provide seamless integration/data exchange with other Board applications, including OLGPRS,
OLMMS, LIMS, OCEMS and GIS, along with other existing/future applications and external
Government/regulatory systems wherever required.
4. OBJECTIVES OF THE ASSIGNMENT
1. To undertake an independent and comprehensive As-Is study of the existing OCMMS and related
digital applications of TNPCB.
2. To review the module-wise workflows, forms, fields, validations and proposed requirements
prepared by TNPCB and refine/improve them through detailed study and consultation.
3. To undertake Business Process Re-engineering to simplify processing, reduce repetitive data
entry, improve transparency, automate validations and improve user experience.
4. To benchmark the proposed TNPCB system with the OCMMS/digital regulatory system of the
Gujarat Pollution Control Board (GPCB) and Maharashtra State Pollution Control Board (MSPCB)
as a priority reference, and also study suitable systems implemented by other SPCBs/PCCs.
5. To integrate OLGPRS, OLMMS, LIMS, OCEMS, GIS and other identified systems with the
revamped OCMMS, including implementation of Single Sign-On (SSO), centralized role-based
access and a unified interface/dashboard for accessing the relevant activities and information of
the connected systems through OCMMS.

<!-- page 11 -->

6. To establish a unified Single Sign-On (SSO) and integrated user-access framework for OCMMS
and the connected TNPCB applications, so that authorized users can access OCMMS, OLMMS,
OLGPRS, LIMS, OCEMS, GIS and other integrated modules through a single set of credentials
and, based on their role and authorization, view and access the relevant activities, information
and functionalities of the connected systems through the OCMMS interface without requiring
separate logins.
7. To prepare and oversee a comprehensive data cleansing, de-duplication, migration and
integration strategy for complete migration of legacy data from the existing OCMMS to the
revamped OCMMS, including identification and removal/merging of duplicate records, data
cleansing, field mapping, validation, reconciliation, preservation of historical records and
migration/linking/synchronization of relevant data from OLGPRS, OLMMS, LIMS, OCEMS, GIS
and other identified systems without loss or duplication of valid data.
8. To design and define an automated Consent Fee Calculator within the revamped OCMMS, so
that the applicable Consent fee is calculated automatically based on the relevant category,
classification, capital investment, validity period, type of application and other applicable fee
criteria/rules, thereby minimizing manual calculation and ensuring uniformity and accuracy.
9. To define the complete functional, technical, integration, security, database, data migration and
non-functional requirements for the revamped OCMMS.
10. To prepare comprehensive FRS, system architecture, data migration strategy and other technical
specifications.
11. To prepare the complete RFP/tender package for selection of a System Integrator for
development, migration, integration, implementation, testing, deployment and support of the
revamped OCMMS.
12. To assist TNPCB during the System Integrator procurement process.
13. To act as TNPCB’s technical/project management consultant after selection of the System
Integrator and supervise/monitor implementation against the approved RFP, FRS, contract,
milestones and Service Level requirements until successful Go-Live.
5. TNPCB INPUTS TO THE CONSULTANT
TNPCB will provide the selected Consultant with the available requirement of functional flows,
application forms, fields, validations, processing stages, Consent and Authorization workflows, eNoting requirements, enforcement workflows, dashboards, reports, administrative requirements,
integration requirements and other proposed functional/technical requirements.
These materials shall constitute a base input for the assignment and shall not be treated as final
specifications. The Consultant shall independently evaluate their completeness, feasibility,
interoperability, security, scalability and usability, identify gaps/redundancies and recommend
improvements in consultation with TNPCB.

<!-- page 12 -->

TNPCB shall also provide reasonable access, subject to security and confidentiality requirements, to
relevant systems, documents, test environments, sample data, officers/users and technical personnel
necessary for performance of the assignment.
6. DETAILED SCOPE OF WORK
6.1 As-Is Study of Existing OCMMS
The Consultant shall undertake a detailed functional and technical study of the existing OCMMS from
both Industry/User and Board/Engineer perspectives. The study shall cover, inter alia:
a. Industry registration, authentication and login; user profile and establishment details;
b. Consent to Establish (CTE), Consent to Operate (CTO), Renewal of Consent Order (RCO),
expansion/revision/extension and other applicable Consent processes;
c. Waste Management Authorization modules and statutory returns;
d. District Office, Zonal Office and Board Office processing flows;
e. scrutiny, inspection, return/retrieval/resubmission, approval and issue of orders;
f.

e-Noting and movement of files/notes between officers;

g. Letters Show Cause Notices, Directions, Revocation and other regulatory/enforcement
proceedings;
h. Consent fee payment, fee calculation and transaction reconciliation requirements;
i.

Admin Login, office/designation/post/role mapping, jurisdiction management and system
administration;

j.

Industry Summary, dashboards, MIS and report formats;

k. Annual Returns and other statutory reporting requirements;
l.

email/SMS/system-generated communications;

m. database architecture, master data, document storage and audit history; and
n. other functionalities identified during the study.
6.2 Gap Analysis Study
The Consultant shall review TNPCB’s existing module/flow documents and carry out a detailed gap
analysis to identify functional, process and usability improvements. Based on the findings, the
Consultant shall refine and redesign the proposed system with simple, modern, intuitive and userfriendly pages/screens, while ensuring consistency across modules. The review shall include a
comprehensive page-wise, field-wise and workflow-wise examination of the proposed system.
a. Validate completeness and regulatory/technical feasibility of each module and workflow;
b. identify missing functions, duplications, redundant fields and avoidable processing steps;
c. refine application forms, officer screens, dashboards, reports, alerts and administrative controls;
d. recommend suitable auto-population, master-data controls and dropdown-based inputs;
e. recommend rule-engine/automated checks and validations wherever feasible;
f.

identify interoperability and integration requirements;

g. identify requirements for data quality, auditability, traceability and user experience;

<!-- page 13 -->

h. prepare finalized To-Be workflows and obtain TNPCB approval before finalizing FRS.
6.3 Regulatory Alignment and Automated Checks / Validations
The Consultant shall ensure that the proposed system is aligned with the applicable Acts, Rules,
Waste Management Rules, statutory forms, Government Orders, Board Proceedings, revised
categorization of industries and subsequent amendments, power delegations, siting criteria,
standards, guidelines, Consent/Authorization requirements, statutory timelines and other applicable
regulatory provisions.
For each proposed automated check/validation, the Consultant shall clearly specify the field/data
element, validation logic, regulatory reference, source of data, conditions/exceptions, user-facing
message and stage of workflow at which the validation shall operate.
6.4 Application Forms and Statutory Forms
The Consultant shall review the application and statutory forms relating to Consent under the Water
(Prevention and Control of Pollution) Act, 1974 and the Air (Prevention and Control of Pollution) Act,
1981 with reference to the applicable Rules and prescribed forms. Authorization applications, returns
and other statutory forms shall similarly be reviewed with reference to the respective Waste
Management Rules under the Environment (Protection) Act 1986. The digital forms shall capture
statutory requirements while minimizing repetitive or unnecessary data entry.
6.5 Benchmarking of GPCB, MSPCB and Other SPCB/PCC Systems
Particular priority shall be given to detailed study of the OCMMS/digital regulatory system
implemented by the GPCB, MSPCB, to the extent information and access are available. The
Consultant shall also study relevant systems implemented by other SPCBs/PCCs.
The

benchmarking

shall

examine,

as

applicable,

registration,

application

forms,

Consent/Authorization processing, consolidated applications, validations, inspections, e-Noting,
regulatory proceedings, administrative controls, dashboards, reports, GIS and other integrations,
architecture, database/data-management approaches and user experience.
The Consultant shall prepare a comparative assessment identifying the feature, source State/SPCB,
advantages, limitations, suitability for TNPCB and recommendation for adoption/adaptation. No
feature shall be recommended merely because it exists in another State; applicability to TNPCB’s
statutory and operational context shall be established.
6.6 Integration with OLGPRS, OLMMS, LIMS, OCEMS, GIS and Other Systems
The Consultant shall define functional and technical requirements for integration/data exchange with
OLGPRS, OLMMS, LIMS, OCEMS, GIS, other TNPCB databases/applications and relevant external
Government/regulatory systems.
For each integration, the Consultant shall define source and destination systems, data elements,
workflow

stage,

purpose,

frequency/synchronization

mechanism,

APIs/interfaces,

authentication/authorization, master-data ownership, audit trail, error handling, logging, security and
fallback requirements.

<!-- page 14 -->

The architecture shall, as far as practicable, avoid data silos and repeated capture of information
already available within TNPCB systems.
6.7 Single Sign-On and Unified Access
The Consultant shall study and define the requirements for implementation of a Single Sign-On
(SSO) mechanism across OCMMS and the other identified TNPCB applications, including OLMMS,
OLGPRS, LIMS, OCEMS, GIS and other systems, so as to eliminate the requirement for separate
login credentials for each application.
The revamped OCMMS shall, to the extent technically feasible, function as the single entry
point/unified portal for authorized TNPCB users, wherein, upon login to OCMMS, the user shall be
able to access the relevant modules, activities, alerts, pendency, records and functionalities available
in the connected applications based on the user's office, designation, role, jurisdiction and access
privileges.
The Consultant shall examine and define:
a. a common authentication and identity-management framework;
b. Single Sign-On across OCMMS, OLMMS, OLGPRS, LIMS, OCEMS, GIS and other
identified applications;
c. centralized user, role and access management;
d. mapping of users based on office, designation, post, jurisdiction and assigned role;
e. role-based access to the connected applications/modules;
f.

a unified dashboard within OCMMS displaying relevant information, pendency, alerts and
activities from the integrated systems;

g. seamless navigation between OCMMS and the connected modules without requiring
repeated authentication;
h. synchronization of user profiles, roles and access privileges across the integrated
systems;
i.

security, session management, authentication, authorization and audit-trail requirements
for SSO;

j.

migration/mapping of existing user accounts and credentials, wherever required; and

k. appropriate architecture for integrating the existing applications into the unified OCMMS
environment.
The Consultant shall also examine whether the functionalities of the existing applications are to be
integrated within the revamped OCMMS, accessed as interconnected modules through SSO, or
suitably consolidated, and shall recommend the most appropriate architecture considering security,
maintainability, interoperability and user experience.
6.8 Data Cleansing and De-duplication
The Consultant shall undertake a detailed assessment of the existing OCMMS database to identify
duplicate, incomplete, inconsistent and erroneous records prior to migration. The Consultant shall
define, oversee and validate the implementation of a comprehensive data cleansing and de-

<!-- page 15 -->

duplication methodology, in coordination with TNPCB and the System Integrator, including
identification of duplicate industry records, matching criteria, validation rules, master-record selection,
merging of duplicate records, preservation of historical information and treatment of exceptional
cases.
The Consultant shall ensure that de-duplication and cleansing are completed prior to/following
migration, as applicable, so that the revamped OCMMS contains clean, consistent, accurate and nonduplicated master and transactional data. Appropriate reconciliation, audit trail and verification
mechanisms shall also be prescribed to ensure that no valid historical data is lost during the
cleansing and de-duplication process.
6.9 Data Migration and Database Management
Complete and accurate migration of legacy OCMMS data to the revamped system shall be treated as
a critical project requirement. The Consultant shall assess the existing OCMMS and related
databases and prepare a detailed data migration and synchronization strategy.
a. Inventory of all legacy databases, schemas, masters, documents and historical records;
b. field-level source-to-target mapping and transformation rules;
c. data quality assessment, cleansing, deduplication and validation;
d. migration of historical applications, processing history, Consent Orders, Authorizations,
documents and audit records;
e. database synchronization during transition and cut-over;
f.

reconciliation and acceptance criteria for completeness/accuracy;

g. migration rehearsal, rollback, backup and recovery mechanisms;
h. audit trail for migrated data; and
i.

linkage/integration of relevant OLGPRS, OLMMS, LIMS, OCEMS, GIS and other
databases with the new platform.

6.10 Automated Consent Fee Calculation
The Consultant shall study the existing Consent fee calculation methodology followed by TNPCB and
define the requirements for an automated Consent Fee Calculator to be incorporated in the revamped
OCMMS.
The fee calculator shall automatically determine the applicable Consent fee based on the relevant
parameters and fee rules applicable to the particular application, including, wherever applicable,
industry category/classification, capital investment, type of Consent application, validity period,
expansion/revision/renewal requirements and other parameters prescribed by TNPCB.
The Consultant shall:
a. identify all fee-calculation rules and dependencies;
b. prepare the detailed calculation logic and formulae;
c.

map the calculation with applicable Government Orders, Board Proceedings and fee schedules;

d. provide for automatic recalculation where relevant application parameters are modified;

<!-- page 16 -->

e. provide appropriate validation/error messages;
f.

provide for display of the fee breakup to the applicant and Board officials;

g. ensure auditability of the fee calculation; and
h. provide for configurable fee rates/rules through the Admin module, wherever feasible, so that

future changes can be incorporated without source-code modification.
6.11 Technical Architecture and Non-Functional Requirements
The Consultant shall define appropriate vendor-neutral and technology-neutral requirements, to the
extent practicable, covering application architecture, database architecture, modularity, APIs,
interoperability, scalability, performance, high availability, audit trails, role-based access control,
cyber security, data security, privacy, logging, monitoring, backup, disaster recovery, business
continuity, accessibility, responsiveness, deployment, hosting, environment segregation, source-code
management, version control and other non-functional requirements.
6.12 Preparation of FRS
The Consultant shall prepare comprehensive FRS document based on the approved To-Be system.
The documents shall unambiguously define every module, workflow, role, field, form, validation,
report, dashboard, integration, interface, data requirement, security requirement, non-functional
requirement and acceptance criterion necessary for development by the System Integrator.
The FRS shall include suitable process maps, use cases/user stories, role matrices, screen/field
specifications, validation matrices, report catalogue, interface catalogue, data dictionary, integration
requirements and traceability between TNPCB requirements and System Integrator deliverables.
6.13 Preparation of System Integrator RFP / Tender Documents
The Consultant shall prepare a complete, procurement-ready RFP/tender package for selection of the
System Integrator. The package shall include, inter alia:
a. detailed scope of work and technical specifications;
b. FRS and approved architecture/integration requirements;
c. data migration and database requirements;
d. infrastructure/hosting and cybersecurity requirements;
e. testing and acceptance requirements;
f.

implementation methodology, deliverables, milestones and schedule;

g. manpower/team requirements;
h. qualification, pre-qualification and technical evaluation criteria;
i.

financial bid structure and evaluation methodology;

j.

payment milestones;

k. SLAs, KPIs, penalties/liquidated damages and acceptance criteria;
l.

training, documentation and knowledge-transfer requirements;

m. source-code, intellectual property, escrow/repository, handover and exit-management
requirements;

<!-- page 17 -->

n. warranty, support and Operation & Maintenance requirements; and
o. contractual clauses required for successful implementation.
6.14 Support During System Integrator Procurement
The Consultant shall support TNPCB during the SI procurement process, including preparation of
responses to pre-bid queries, corrigenda/amendment inputs, participation in pre-bid discussions,
technical

clarifications,

bid

compliance

review,

technical

evaluation

support,

presentations/demonstrations, technical evaluation reports and other procurement-stage assistance
required by TNPCB. Final procurement decisions shall remain with TNPCB.
6.15 Project Management and Implementation Support till Go-Live
The Consultant’s engagement shall continue after selection of the System Integrator. The Consultant
shall act as TNPCB’s technical/project management consultant and shall monitor implementation
against the approved RFP, FRS, SI proposal, contract, project plan, milestones and SLAs until
successful Go-Live.
a. Review the SI’s project plan, architecture, detailed design, module designs, workflows, forms,
UI/UX and technical documents.
b. Ensure development is carried out in accordance with the approved RFP, FRS and contractual
requirements.
c. Monitor milestones, schedules, dependencies, risks, deliverables and resource deployment.
d. Conduct/coordinate periodic review meetings and maintain issue, risk, action and decision
trackers.
e. Review SI deliverables and recommend acceptance/rework to TNPCB.
f.

Oversee and verify integrations with OLGPRS, OLMMS, LIMS, OCEMS, GIS and other identified
systems.

g. Oversee legacy-data migration, reconciliation, validation and synchronization.
h. Verify implementation of automated checks, validations, dashboards, reports and workflow
requirements.
i.

Review test strategy, test plans, test cases and results covering functional, integration,
performance, security and regression testing.

j.

Assist TNPCB in User Acceptance Testing and maintain requirement-to-test traceability.

k. Monitor closure of defects, observations and non-compliances.
l.

Review training plans, user manuals, administrator manuals, technical documentation and
knowledge transfer.

m. Review deployment, cut-over and rollback plans and production readiness.
n. Carry out Go-Live Readiness Assessment and provide a formal recommendation to TNPCB. Final
approval for Go-Live shall rest with TNPCB.

<!-- page 18 -->

7. MILESTONES AND INDICATIVE TIMELINE
The Consultant shall carry out the assignment in a time-bound manner in accordance with the
milestones indicated below. “T” shall denote the date of commencement of the consultancy services
as specified in the Work Order/Agreement.
The timelines prescribed for Phase-I activities, including study of the existing systems, requirement
finalization, benchmarking, BPR, preparation of FRS and preparation of the System Integrator
RFP/Tender Document, shall be adhered to by the Consultant.
The timelines relating to System Integrator procurement and Phase-II implementation/PMC support
shall depend on the tendering, selection and implementation schedule of the System Integrator. The
Consultant shall continue to provide the required support during these stages until successful Go-Live
of the revamped OCMMS.
Table 1: Milestone and Indicative Timeline
S No.

MILESTONE

Indicative Due
Date

PHASE - I
1

Inception Report, detailed work plan and stakeholder consultation plan

T + 1 week

2

As-Is Study, application/database assessment and Gap Analysis

T + 2 weeks

3

GPCB and other SPCB/PCC Benchmarking Report

T + 3 weeks

4

BPR recommendations and approved To-Be workflows/framework

T + 4 weeks

5

Draft FRS, integration architecture, data migration strategy and non-

T + 5 weeks

functional requirements
6

Final FRS and technical specifications after TNPCB comments

T + 6 weeks

7

Draft SI RFP/Tender Document and cost-estimation framework

T + 7 weeks

8

Final SI RFP/Tender Document after TNPCB approval/comments

T + 8 weeks

PHASE - II
9

SI procurement support

From SI RFP
issue until
award/contract
execution

10

Implementation/PMC support

From SI
commencemen
t until

<!-- page 19 -->

S No.

MILESTONE

Indicative Due
Date
successful GoLive

11

Go-Live Readiness Assessment and Final Consultancy Report

At Go-Live

TNPCB will require interim presentations, working papers, module-wise reviews and revised versions
of deliverables without additional cost where such revisions are necessary to incorporate comments
or ensure completeness of the assignment.
8. CONSULTANT TEAM AND KEY PERSONNEL
The Bidder shall propose the Key Personnel specified below for carrying out the assignment. Each
proposed Key Personnel shall satisfy the minimum educational qualification, total experience and
specific experience requirements prescribed in this RFP. The qualifications, relevant experience and
competence of the proposed Key Personnel shall also be considered as part of the Technical
Evaluation under Section 12.
All Key Personnel proposed for the assignment shall be regular employees/on the payroll of the
Bidder for a minimum period of six (6) months as on the last date of bid submission. Documentary
evidence confirming the employment status of the proposed personnel shall be furnished as part of
the Technical Proposal.
NIRF Ranking Requirement: The institution from which the proposed Key Personnel has obtained the
prescribed qualifying degree shall have been ranked within the Top 100 institutions as per the
National Institutional Ranking Framework (NIRF), Ministry of Education, Government of India, in any
one of the years 2023, 2024 or 2025.
The Bidder shall furnish documentary evidence of the educational qualification of each proposed Key
Personnel along with proof of the corresponding NIRF ranking of the institution.
The proposed Key Personnel shall possess adequate knowledge and experience relevant to their
assigned roles and shall work in close coordination with TNPCB throughout the consultancy
assignment.

<!-- page 20 -->

Table 2: Consultant Team and Key Personnel
S.No

Specific
Role

Minimum qualification

Total experience

experience
required

1.

Team Leader

B.E./B.Tech/MCA in IT/CS

15 years

Led

at

least

2

from top 100 Engineering

Similar Assignments

Colleges or top 50

as Team Leader /

universities in NIRF (2025,

Project

2024, 2023)

including

RFP

preparation

and

Director,

PMC
2.

Solution /

B.E./B.Tech/MCA from top

12 years

Designed at least 2

Technical

100 Engineering Colleges

large web-based e-

Architect

or top 50 universities in

Governance

NIRF (2025, 2024, 2023)

enterprise

or

applications with API
integration

and

legacy
modernisation
3.

Functional / BPR B.E./B.Tech/MCA from top

12 years

At

least

/ e-Governance

100 Engineering Colleges

assignments

Expert

or top 50 universities in

involving

NIRF (2025, 2024, 2023)

functional

2
BPR,

requirement
analysis/FRS
workflow
for

and

redesign

Government/e-

Governance
applications
4.

Data Architect

B.E./B.Tech/MCA/M.Sc

10 years

Led at least 2 large

and Migration

from top 100 Engineering

legacy

Lead (Data

Colleges or top 50

migration

Engineer)

universities in NIRF (2025,

architecture

2024, 2023)

assignments

data
or

data

(RDBMS, ETL, data
quality, master data,
reconciliation)

<!-- page 21 -->

S.No

Specific
Role

Minimum qualification

Total experience

experience
required

5.

AI/ML Engineer

B.E./B.Tech/MCA/M.Sc

10 years, of which 4

Delivered at least 2

(AI and

from top 100 Engineering

years in AI/ML

production

Automation

Colleges or top 50

rules-engine

Lead)

universities in NIRF (2025,

document-

2024, 2023)

intelligence

AI/ML,
or

(OCR/NLP)
solutions

for

validation,

scrutiny

or

risk

scoring;

knowledge

of

explainability

and

responsible AI

The Bidder shall propose an appropriate deployment schedule for the Key Personnel commensurate
with the activities and deliverables under each phase of the assignment. All Key Personnel need not
necessarily be deployed on a full-time basis throughout the entire contract period; however, the
Bidder shall ensure their availability in TNPCB’s Corporate Office, Guindy, Chennai, at all stages
where their respective expertise is required.
The Team Leader / Project Director shall remain responsible for the assignment throughout the
contract period and shall ensure coordination among all experts and timely delivery of the
assignment.
The Bidder shall furnish, as part of the Technical Proposal, a phase-wise staffing and person-month
deployment plan for each Key Personnel. The deployment proposed in the Technical Proposal shall
be binding on the selected Consultant, subject to modifications approved by TNPCB.
TNPCB may require the concerned Key Personnel to participate in meetings, technical reviews,
presentations, System Integrator evaluation, design reviews, testing, UAT, data migration, security
reviews and Go-Live readiness assessments, as applicable to their respective areas of expertise.
The Consultant shall ensure continuity of key personnel. Replacement of key personnel after award
shall require prior written approval of TNPCB and shall be permitted only with personnel having equal
or superior qualifications/experience, subject to contractual provisions.
9. ELIGIBILITY / PRE-QUALIFICATION CRITERIA
The Bidder shall satisfy all the eligibility and pre-qualification criteria specified below as on the last
date for submission of bids. The criteria are mandatory and shall be evaluated on a Pass/Fail basis.

<!-- page 22 -->

Only those Bidders who meet all the eligibility/pre-qualification requirements and submit the
prescribed documentary evidence shall be considered for further Technical Evaluation.
The Bidder shall submit documentary proof in support of each criterion along with the Technical
Proposal. TNPCB reserves the right to verify the credentials and supporting documents submitted by
the Bidder directly with the concerned client organizations/authorities. Failure to meet any of the
mandatory eligibility criteria or failure to furnish adequate supporting documents may render the bid
liable for rejection.
Table 3: Eligibility/ Pre-Qualification Criteria
Sl. No.
1

Criterion
Legal Status

Requirement

Evidence

Bidder shall be a

Registration /

company/LLP/partnership/other eligible legal

incorporation

entity registered in India. No Joint venture/

documents

tie-ups allowed.
2

3

4

Years of

Minimum 10 years in IT/e-

Certificate/organizat

Operation

Governance/technology consulting.

ion profile

Financial Capacity

Average annual turnover from consulting/IT

Audited

services of at least Rs. 10 crores during the

statements

last 3 financial years.

certificate

financial
/

CA

orders

/

Similar

The Bidder shall have completed/ongoing at Work

Government / e-

least one assignment during the last 10 contracts

Governance

years

Assignment

Government Department, PSU, Statutory certificates

Experience

Body

for
or

a

Central

Government

Government/State completion or client
Agency

involving

study/revamping/modernization

of

a

Government portal or large e-Governance
application. The assignment shall include
substantial

experience

in

As-Is

study,

Business Process Re-engineering (BPR),
preparation

of

functional/technical

requirements, preparation of RFP/tender
documents

for

Integrator,

system

selection

of

a

integration

System
planning,

legacy data/database migration planning and
project

management/implementation

monitoring of the System Integrator.
5

Data Migration

/

The Bidder shall have experience in at least Supporting

<!-- page 23 -->

Sl. No.

Criterion
Experience

Requirement
one

large

Evidence

IT/e-Governance

involving

migration

assignment documents

of

legacy

application/database data to a new or
revamped system, including source-to-target
mapping,

data

cleansing,

validation,

reconciliation, historical data migration and
migration verification.
6

NICSI

The Bidder shall, as on the last date of bid Supporting

Empanelment

submission, be a valid NICSI empaneled documents
agency under the Consulting & Strategy
service category relevant to the scope of this
assignment.

7

Blacklisting

Bidder shall not be blacklisted/debarred by Self-declaration
any

Central/State

Government

Department/PSU/Statutory Body.
8

Conflict of Interest

Bidder
conflicts

and

its

and

affiliates
shall

shall

comply

disclose Declaration
with

SI

participation restrictions specified in this
RFP.
9

Tax Registration

Valid PAN, GST and other applicable

Certificates

registrations.
Other conditions:
a. The Bidder has not been blacklisted by any government authority in any jurisdiction to undertake
its business operations.
b. No insolvency/ bankruptcy proceedings have been initiated against the Bidder.
c. The Bidder has not been subject to an administrative sanction in the past 5 years for fraud,
corruption or for any other offense committed during a procurement process or performance of a
contract.
d. The Bidder has never failed to fulfil its obligations under any agreement it may have entered into,
nor its contractual term has been terminated on account of quality of services rendered.
e. The Bidder undertakes that there is no conflict of interest that may be likely to impact its
obligations while submitting its Bid or fulfilling subsequent terms of agreement in furtherance of
this RFP.
f.

The Bidders agree to submit Bids in format annexed as Annexure - K along with requisite
documents/ information along with declarations in the format annexed as Annexures - I & J to
ensure compliance with the Eligibility Criteria.

<!-- page 24 -->

g. No other information including any financial quotes or details are to be shared in the Technical Bid
failing which the Bid shall stand cancelled.
10. CONFLICT OF INTEREST AND INDEPENDENCE
The Consultant will prepare the functional/technical specifications and the procurement documents
for the System Integrator and will subsequently supervise/monitor the System Integrator. Accordingly,
the selected Consultant shall maintain independence and avoid actual or potential conflicts of
interest.
The selected Consultant, its parent/subsidiary/affiliate entities and personnel materially involved in
this

assignment

shall

not

participate

as

the

System

Integrator

or

as

a

consortium

member/subcontractor/key implementation partner of the selected SI for the same project. Any
existing or potential conflict shall be disclosed immediately.
11. PROPOSAL SUBMISSION REQUIREMENTS
11.1 Cover 1 - Technical / Pre-Qualification Proposal
1. Letter of Proposal as per Annexure A;
2. Bidder profile and legal documents as per Annexure B;
3. Eligibility compliance statement and supporting evidence as per Annexure C;
4. similar assignment details as per Annexure D1 and Annexure D2;
5. Government/e-Governance project experience as per Annexure D;
6. proposed team composition and CVs as per Annexure F;
7. Approach & Methodology as per Annexure G;
8. work plan, schedule and staffing plan as per Annexure H;
9. presentation deck;
10. declarations/undertakings required under this RFP as per Annexure I and J; and
11. EMD/Bid Security and tender-fee proof, as applicable.
The Technical Proposal shall be properly indexed and paginated, and all documents, forms,
supporting credentials and annexures shall be arranged and submitted in the same sequence as
prescribed above. The Bidder shall provide a detailed index indicating the section/document name
and corresponding page number for ease of verification and evaluation. The Technical Proposal shall
not contain any financial information. Inclusion of price information in the Technical Proposal may
render the bid liable for rejection.
11.2 Cover 2 - Financial Proposal
The Financial Proposal shall be submitted only in the prescribed BOQ on the e-Procurement portal.
Prices shall be quoted in Indian Rupees and shall clearly indicate applicable taxes as required by the
bid format.
12. TECHNICAL EVALUATION
Only Bidders who satisfy all the mandatory Eligibility / Pre-Qualification Criteria specified in this RFP
under Section 9, shall be taken up for Technical Evaluation.

<!-- page 25 -->

The Technical Proposals of the qualified Bidders shall be evaluated for a maximum of 100 marks
based on the criteria specified below, covering the Bidder’s relevant experience, proposed Key
Personnel, Approach and Methodology, and Technical Presentation/Interaction.
The evaluation shall be based on the information, documents and supporting evidence submitted
along with the Technical Proposal and the Technical Presentation made before the Committee
constituted by TNPCB. TNPCB may seek clarifications or additional supporting information, wherever
necessary, without permitting any material alteration of the Technical Proposal.
Marks shall be awarded only where the Bidder has submitted adequate documentary evidence
demonstrating compliance with the respective evaluation criterion. Claims not supported by
appropriate documentary evidence may not be considered for scoring.
The minimum qualifying technical score shall be 70 marks out of 100. Only the Financial Proposals of
Bidders who obtain the prescribed minimum technical score shall be opened and considered for
further evaluation under the Quality and Cost Based Selection (QCBS) methodology specified in this
RFP.
Table 4: Technical Evaluation
Ref.

Evaluation Criterion

Max. Marks

A

Firm Experience and Similar Assignments

20

A1

Similar Government / e-Governance Assignment Experience (As per
Sl.no 4. of Table 3 in Section 9)

10

3 or more qualifying assignments

10

2 qualifying assignments

8

1 qualifying assignment

5

Legacy Data Cleansing, De-duplication and Migration Experience (As
per Sl.no 5. of Table 3 in Section 9)

10

3 or more qualifying assignments

10

2 qualifying assignments

8

1 qualifying assignment

5

B

Key Personnel and Team Composition

25

B1

Team Leader / Project Director

5

B2

Functional / BPR / e-Governance Expert

5

B3

Solution / Technical Architect

5

B4

Data Architect & Migration Lead

5

B5

AI/ML Engineer (AI and Automation Lead)

5

C

Approach and Methodology

35

C1

As-Is Study, To-Be Process, BPR and refinement of TNPCB-proposed 4

A2

<!-- page 26 -->

Ref.

Evaluation Criterion

Max. Marks

workflows/forms/requirements
C2

GPCB/MSPCB/other SPCB benchmarking methodology

4

C3

Integration architecture including OLGPRS, OLMMS, LIMS, OCEMS, 7
GIS, SSO, unified access and role management

C4

Data cleansing, de-duplication, legacy data migration, synchronization 7
and reconciliation methodology

C5

Automated validations, regulatory checks and data-quality methodology 7
using AI technology and automated consent fee calculation

C6

FRS, technical requirement specifications, SI-RFP preparation and 6
implementation/PMC methodology till Go-Live

D

Technical Presentation / Interaction

20

TOTAL

100

The minimum technical qualifying score shall be 70 marks out of 100. Financial Proposals of only
technically qualified bidders shall be opened.
13. TECHNICAL PRESENTATION
Technically responsive bidders shall be required to make a Technical Presentation before a
Committee constituted by TNPCB. The presentation shall comprehensively cover the Approach and
Methodology submitted by the bidder under Annexure G, including all the proposed methodologies,
strategies, work plans, staffing arrangements and implementation approaches forming part of the
Technical Proposal.
The bidder shall specifically present its understanding of the assignment, As-Is study methodology,
review and refinement of TNPCB requirements, BPR and To-Be process design, GPCB/other SPCB
benchmarking approach, regulatory validations, integration and SSO architecture, data cleansing and
de-duplication, legacy data migration, FRS and technical requirement preparation, SI-RFP
preparation, SI procurement support, implementation supervision till Go-Live, quality assurance, risk
management, governance and deployment of key personnel.
The presentation shall be consistent with and shall form part of the bidder’s submitted Technical
Proposal. Any material deviation from the Approach and Methodology submitted in the Technical
Proposal shall not be considered during evaluation.
14. FINANCIAL PROPOSAL AND QCBS EVALUATION
The Financial Proposal shall be evaluated in accordance with the QCBS methodology specified
below, subject to confirmation of the weightages before issue of the RFP.
For financial evaluation, the lowest evaluated financial proposal (Fm) shall receive a Financial Score
(Sf) of 100. Other proposals shall be scored as: Sf = 100 x Fm / F, where F is the evaluated price of
the proposal under consideration.

<!-- page 27 -->

The normalized Technical Score (St) and Financial Score (Sf) shall be combined using the approved
QCBS weights. For a Technical:Financial weightage of 80:20, the Combined Score (S) shall be: S =
0.80 x St + 0.20 x Sf.
The bidder achieving the highest Combined Score shall be ranked first, subject to due diligence,
approval and applicable procurement rules. In the event of a tie, the bidder with the higher Technical
Score shall rank higher unless otherwise prescribed by applicable rules.
15. FINANCIAL BID STRUCTURE
The Bidder shall submit the Financial Proposal in the format specified below, quoting the applicable
fees for each component of the assignment.
Table 5: Financial Bid
Item
A

Component
As-Is study, benchmarking, BPR, To-Be framework, FRS,

Price Basis
Lump Sum

architecture, integration and data-migration specifications
(Phase – I)
B

Preparation/finalization of SI RFP/tender package and SI

Lump Sum

procurement support up to award (Phase – I)
C

Implementation/PMC support after SI commencement until

Monthly professional fee

Go-Live (Phase – II)
D

Total Evaluated Financial Proposal

A + B + (C monthly rate x
assumed evaluation
months), exclusive/inclusive
of taxes as specified in BOQ.
Assumed evaluation months
shall not exceed 6 months.

The Bidder shall quote the professional fee and applicable GST separately in the prescribed BOQ.
16. PROPOSED PAYMENT MILESTONES
The final payment schedule shall be linked to acceptance of deliverables. An indicative structure is
provided below for internal finalization:
Table 6: Payment Milestones
Sl. No.

Indicative
Payment

Milestone

1

Acceptance of Inception Report

5%

2

Approval of To-Be/BPR framework

20%

<!-- page 28 -->

Sl. No.

Indicative
Payment

Milestone

3

Acceptance of Final FRS, architecture, integration and data 10%
migration documents

4

Acceptance of Final SI RFP/Tender Package

30%

5

Completion of SI procurement support up to award/contract
signing

20%

6

Implementation/PMC support

10%

7

Go-Live

5%

No payment shall be due merely upon submission of a deliverable. Payment shall become due only
after acceptance/approval by TNPCB in accordance with the Contract.
17. PERFORMANCE SECURITY
The successful bidder shall furnish Performance Security of 5% of the contract value, in the form and
validity prescribed by TNPCB and applicable procurement rules, within the period specified in the
Letter of Award/Contract.
18. CONTRACT PERIOD AND DEPLOYMENT
The initial period of engagement of the Consultant shall be eight (8) months from the date specified in
the Letter of Award/Agreement. The engagement shall cover the stages of Study → Requirement
Finalization and BPR → Finalization of To-Be Processes → FRS and Technical Specifications → SI
RFP Preparation → SI Procurement and Selection → SI Solution Design and Development →
Integration → Data Cleansing and Migration → Testing → User Acceptance Testing (UAT) →
Deployment and Go-Live.
The Consultant shall remain responsible for providing the required technical and project management
support until successful Go-Live of the revamped OCMMS and submission and acceptance of the
Final Consultancy Report.
19. GOVERNANCE AND REPORTING
The Consultant shall work under the direction of TNPCB and shall coordinate with the
Committee/Working Group/nodal officers nominated by TNPCB. The Consultant shall maintain a
structured governance framework including weekly/fortnightly progress reporting as directed, meeting
minutes, requirement trackers, risk register, issue log, action tracker, decision log, deliverable register
and requirement traceability matrix.
All significant recommendations, scope changes and technical decisions shall be documented and
submitted for TNPCB approval. The Consultant shall not independently alter approved project scope
or commit TNPCB to any commercial/contractual position.

<!-- page 29 -->

20. CONFIDENTIALITY, SYSTEM ACCESS AND DATA SECURITY
The Consultant may be provided access to TNPCB systems, test logins, technical documents,
databases, sample records and other information necessary for the assignment. Such access shall
be strictly need-based and subject to TNPCB approval.
1. All information accessed during the assignment shall be treated as confidential and used solely for
the purposes of the assignment.
2. Credentials provided by TNPCB shall not be shared with any unauthorized person.
3. The Consultant shall implement appropriate security safeguards and comply with TNPCB security
instructions.
4. No TNPCB data shall be copied, transferred, hosted or processed outside approved environments
without prior written approval.
5. Any actual or suspected security incident shall be reported immediately to TNPCB.
6. Confidentiality obligations shall survive completion/termination of the Contract.
21. INTELLECTUAL PROPERTY AND OWNERSHIP OF DELIVERABLES
All reports, workflows, requirement documents, FRS, data models, integration specifications,
migration strategies, diagrams, tender documents, evaluation templates, monitoring reports and other
deliverables specifically prepared under the Contract shall vest in TNPCB upon payment/acceptance,
subject to the detailed Contract provisions. Pre-existing proprietary tools/materials of the Consultant,
if any, shall be identified in the proposal and shall not restrict TNPCB’s use of the project
deliverables.
22. DELAY, NON-PERFORMANCE AND LIQUIDATED DAMAGES
The Consultant shall adhere to the approved project schedule. Delay attributable to the Consultant
may attract liquidated damages/penalties at the rate and ceiling specified in the final Contract. Delay
attributable to TNPCB, the System Integrator, force majeure or approved change requests shall be
dealt with through documented schedule adjustments.
23. CHANGE CONTROL
Any material change to approved scope, deliverables, timelines, staffing or commercial terms shall be
processed through a documented change-control mechanism and shall require prior written approval
of TNPCB/competent authority. The Consultant shall assess the functional, technical, schedule and
cost impact of proposed changes before approval.
24. TERMINATION
TNPCB may terminate the Contract for default, material breach, persistent non-performance, conflict
of interest, confidentiality/security breach, insolvency or other grounds specified in the Contract, after
following the prescribed procedure. Termination for convenience, if permitted, and consequences of
termination shall be specified in the final Contract.

<!-- page 30 -->

25. FORCE MAJEURE
Force majeure shall be governed by the provisions of the final Contract. The affected party shall
promptly notify the other party and take reasonable steps to mitigate the effect of the event.
26. DISPUTE RESOLUTION AND JURISDICTION
Dispute resolution, arbitration if applicable, governing law and jurisdiction shall be specified in the
final Contract. The procurement and Contract shall be governed by applicable laws of India and the
State of Tamil Nadu. Courts at Chennai shall have jurisdiction, subject to the finalized contractual
provisions.
27. GENERAL BID CONDITIONS
1. The bidder shall submit a complete proposal in the prescribed formats.
2. Bids received after the deadline or through modes not permitted by the tender notice shall be dealt
with in accordance with applicable e-procurement rules.
3. TNPCB may seek clarifications without permitting material alteration of the bid.
4. Misrepresentation, suppression of material facts or submission of forged documents may result in
rejection, forfeiture of security and other action under applicable rules.
5. TNPCB reserves the right to verify credentials directly with client organizations.
6. The selected Consultant shall comply with applicable laws, taxes, labour requirements and
professional obligations.
7. No consortium/sub-consultant arrangement shall be permitted except as expressly allowed in the
final RFP. Any proposed specialist sub-consultant shall require prior disclosure and approval.
8. The Consultant shall not assign the Contract without prior written approval of TNPCB.
9. TNPCB may require the successful bidder to enter into a formal agreement containing detailed
terms consistent with this RFP and accepted proposal.
28. ANNEXURES / PROPOSAL FORMS
The Bidder shall be required to furnish documents/ information (including those stated in Annexures
(A-L), previous work orders and assignment completion reports, CVs of the proposed team members,
etc.) in support of each evaluation parameter for the purpose of validation of the Bids submitted under
this RFP. The TNPCB may ask for any other documents/ information if needed during evaluation of
Bids. Acceptance of any document/ Bid does not mean acceptance of the offer of the Bidder or the
selection of the Bidder as Consultant under this RFP.

<!-- page 31 -->

ANNEXURE A - LETTER OF PROPOSAL
To
The Member Secretary
Tamil Nadu Pollution Control Board
76, Mount Salai, Guindy, Chennai - 600 032

Sub: Proposal for Selection of Consultancy Firm to Provide Project Management Support, Functional and
Technical Study, Preparation of Functional Requirements Specifications (FRS) and Preparation of System
Integrator Tender Documents for the Revamping and Integration of Tamil Nadu Pollution Control Board’s
Online Consent Management & Monitoring System (OCMMS) - Reg.

Sir/Madam,

Having examined the RFP and all addenda/corrigenda, we hereby submit our proposal for the above
consultancy assignment. We confirm that the information furnished is true and complete, that our
proposal shall remain valid for the prescribed period, and that we shall comply with the terms of the RFP
and Contract if selected.
We confirm that no financial information has been included in the Technical Proposal and that we have
disclosed all actual/potential conflicts of interest.

Yours faithfully,
Authorized Signatory

Name:
Designation:
Bidder:
Date:

<!-- page 32 -->

ANNEXURE B - BIDDER PROFILE
Sl. No.

Particular

1

Legal Name of Bidder

2

Registered Office Address

3

Year of Incorporation/Registration

4

Legal Status

5

PAN

6

GSTIN

7

Authorized Signatory

8

Contact Person

9

Email / Phone

10

Website

11

Number of Employees /
Consultants

12

Key Practice Areas

Bidder Response

<!-- page 33 -->

ANNEXURE C - ELIGIBILITY COMPLIANCE
Sl.
No.

Criterion

Compliance (As per the
Requirement specified in
Table 3 of Section 9)

1

Legal Status

Yes/No

2

Years of Operation

Yes/No

3

Financial Capacity

Yes/No

4

Similar Government / eGovernance Assignment
Experience

Yes/No

5

Data Migration Experience

Yes/No

6

NICSI Empanelment

Yes/No

7

Blacklisting Declaration

Yes/No

8

Conflict of Interest Declaration

Yes/No

9

Tax Registrations

Yes/No

Reference to
Supporting Document

<!-- page 34 -->

ANNEXURE D1 - Similar Government / e-Governance Assignment Experience
Sl.
No.

Client

Assignment

Scope / Relevance

Contract
Value

Period

Evidence

Period

Evidence

1
2
3
ANNEXURE D2 - Data Migration Experience
Sl.
No.
1
2
3

Client

Assignment

Scope / Relevance

Contract
Value

<!-- page 35 -->

ANNEXURE E - TEAM COMPOSITION
Sl.
No.
1
2
3
4
5

Name

Proposed Role

Qualification / Experience

Indicative
Deployment

<!-- page 36 -->

ANNEXURE F - FORMAT FOR CV OF KEY PERSONNEL
Sl. No.

Particular

1

Name

2

Proposed Position

3

Educational Qualification

4

Professional Certifications

5

Total Experience

6

Relevant Experience

7

Current Employer/Position

8

Relevant Assignments

9

Role in Proposed Assignment

10

Availability / Deployment

Details

<!-- page 37 -->

ANNEXURE G – APPROACH AND METHODOLOGY
The Bidder shall submit a concise but comprehensive technical note explaining its proposed
approach and methodology for undertaking the assignment. The technical note shall cover, at a
minimum, the following:
1. Understanding of TNPCB’s Existing OCMMS and Revamping Objectives:
Understanding of the existing OCMMS, associated applications, current challenges, TNPCB’s
proposed requirements and the objectives of the proposed revamping exercise.
2. As-Is Study and Stakeholder Consultation Methodology:
Proposed methodology for detailed study of the existing OCMMS and connected systems from
both Industry/User and Board/Engineer perspectives, including stakeholder consultations and
documentation of existing workflows, forms, fields, processing stages and system functionalities.
3. Business Process Re-engineering (BPR) and To-Be Process Design:
Methodology for simplification and redesign of processes, reduction of repetitive data entry, autopopulation of available data, workflow optimization, improvement of transparency and user
experience, and preparation of finalized To-Be processes.
4. Regulatory Alignment and Automated Validation Methodology:
Approach for identifying and incorporating automated checks and validations using recent AI
technologies based on applicable Acts, Rules, Waste Management Rules, statutory forms,
Government Orders, Board Proceedings, revised industry categorization, siting criteria,
standards, guidelines, timelines and other regulatory requirements.
5. Benchmarking of GPCB and Other SPCB/PCC Systems:
Methodology for detailed study of the OCMMS/digital regulatory system implemented by the
Gujarat Pollution Control Board as the priority reference, along with suitable systems
implemented by other SPCBs/PCCs, and identification of features/best practices suitable for
adoption by TNPCB.
6. System Integration, Single Sign-On and Unified Access Architecture:
Proposed approach for integration of OCMMS with OLGPRS, OLMMS, LIMS, OCEMS, GIS and
other identified systems, including:
a. API/data-exchange architecture;

<!-- page 38 -->

b. Single Sign-On (SSO);
c. centralized identity and access management;
d. role-based access;
e. unified OCMMS dashboard/access point;
f.

synchronization of user roles and privileges; and

g. seamless access to relevant activities and information of connected systems without
separate logins.
7. Data Cleansing and De-duplication Methodology:
Approach for assessment of the existing OCMMS database to identify duplicate, incomplete,
inconsistent and erroneous records, including duplicate-detection criteria, data matching, masterrecord

selection,

merging/de-duplication,

preservation

of

historical

records,

validation,

reconciliation and audit trail.
8. Legacy Data Migration, Database Integration and Synchronization:
Approach Methodology for complete migration of legacy OCMMS data to the revamped OCMMS,
including source-to-target mapping, transformation, cleansing, validation, reconciliation, migration
testing, rollback, historical data preservation and verification. The approach shall also cover
migration/linking/synchronization of relevant data from OLGPRS, OLMMS, LIMS, OCEMS, GIS
and other identified databases.
9. Automatic Consent Fee calculation:
The Bidder shall describe its methodology for studying the existing Consent fee structure and for
designing an Automated Consent Fee Calculator in the revamped OCMMS. The proposed
methodology shall provide for automatic calculation of Arrear Consent Fee, Current Consent Fee
and Advance Consent Fee based on the applicable Gross Fixed Assets (GFA) of the industry, the
number of years of Consent validity applied for / applicable, industry category/classification, type
of Consent application and other relevant fee rules prescribed by TNPCB. The methodology shall
also cover mapping of applicable Government Orders, Board Proceedings and fee schedules;
automatic determination of the applicable fee slab; year-wise fee computation; automatic
recalculation whenever relevant parameters such as GFA or validity period are modified; display
of a clear breakup of arrear, current and advance fees to the applicant and Board officials; audit
trail of the calculation; and provision for configurable fee rates/slabs through the Admin module to
accommodate future revisions without source-code modification.
10. Functional Requirement Specification and Technical Requirement Preparation:
Methodology for preparation of the comprehensive Functional Requirement Specification (FRS)
and associated technical requirement documents, including workflows, roles, forms, fields,

<!-- page 39 -->

business rules, validation matrices, report catalogue, interface catalogue, data dictionary,
integration

requirements,

security

requirements,

migration

requirements,

non-functional

requirements and acceptance criteria.
11. Technical Architecture, Security and Non-Functional Requirements:
Approach for defining system architecture, interoperability, scalability, performance, API
architecture, authentication, authorization, cybersecurity, audit logs, data security, backup,
disaster recovery, business continuity, hosting/deployment and other non-functional requirements.
12. System Integrator RFP/Tender Preparation Methodology:
Methodology for preparation of the complete procurement-ready RFP/tender package for
selection of the System Integrator, including eligibility criteria, technical specifications, evaluation
methodology, deliverables, milestones, payment terms, SLAs, acceptance criteria, testing
requirements, data migration requirements, security requirements, contractual conditions and
O&M/support requirements.
13. System Integrator Procurement Support Approach:
Proposed methodology for supporting TNPCB during the SI procurement process, including prebid

clarifications,

technical

responses,

bid

evaluation,

compliance

assessment,

presentations/demonstrations and technical evaluation reporting.
14. Project Management and Implementation Supervision Methodology till Go-Live:
Approach for monitoring and supervising the System Integrator after award, including review of:
a. project plan;
b. detailed solution architecture;
c. SRS prepared by the System Integrator;
d. module designs and workflows;
e. integrations and SSO;
f.

data cleansing and migration;

g. automated validations;
h. security implementation;
i.

testing and UAT;

j.

defects/non-compliances;

k. training and documentation;
l.

deployment and cut-over; and

m. Go-Live readiness.

<!-- page 40 -->

15. Quality Assurance, Requirement Traceability and Acceptance Methodology:
Approach for ensuring traceability of TNPCB requirements from FRS through SI SRS,
development, testing and final acceptance, including requirement traceability matrix, deliverable
reviews, quality checks and acceptance criteria.
16. Project Governance, Risk Management and Change Control:
Proposed governance framework, reporting mechanism, review meetings, issue/risk/action
tracking, escalation mechanism, change-control methodology and coordination with TNPCB and
the System Integrator.
17. Staffing and Phase-wise Deployment Methodology:
Proposed deployment of the Team Leader and Key Personnel across the study, FRS/RFP
preparation, SI procurement and implementation phases, including person-month deployment at
TNPCB Corporate Office, Guindy, Chennai and availability of specialist experts at critical stages.

<!-- page 41 -->

ANNEXURE H - WORK PLAN AND STAFFING SCHEDULE
Sl.
No.
1
2
3
4
5

Activity / Deliverable

Start

Finish

Key Personnel

<!-- page 42 -->

ANNEXURE I - BLACKLISTING / DEBARMENT DECLARATION
We hereby declare that the bidder is not blacklisted/debarred as on the bid due date by any Central
Government/State Government Department, PSU or statutory body, except as specifically disclosed
below:
We understand that any false declaration may result in rejection/termination and other action under
applicable rules.
Authorized Signatory:

Date:

<!-- page 43 -->

ANNEXURE J - CONFLICT OF INTEREST DECLARATION
We have reviewed the conflict-of-interest requirements of the RFP and disclose the following
actual/potential conflicts, if any:
We undertake to immediately disclose any conflict arising during the assignment and to comply with
TNPCB’s directions for mitigation.
Authorized Signatory:

Date:

<!-- page 44 -->

ANNEXURE K - FINANCIAL PROPOSAL FORMAT
Financial Proposal shall be submitted only through the prescribed financial bid/BOQ on the eProcurement portal. The structure below is indicative and shall be aligned with the final BOQ.
Item
A

Component
As-Is study, benchmarking, BPR, To-Be framework, FRS,

Price Basis
Lump Sum

architecture, integration and data-migration specifications
(Phase – I)
B

Preparation/finalization of SI RFP/tender package and SI

Lump Sum

procurement support up to award (Phase – I)
C

Implementation/PMC support after SI commencement until

Monthly professional fee

Go-Live (Phase – II)
D

Total Evaluated Financial Proposal

A + B + (C monthly rate x
assumed evaluation
months), exclusive/inclusive
of taxes as specified in BOQ.
Assumed evaluation months
shall not exceed 6 months.

Taxes shall be quoted/treated as specified in the e-Procurement BOQ and Bid Data Sheet. In case of
discrepancy, the e-Procurement financial bid shall prevail.

<!-- page 45 -->

ANNEXURE L - INDICATIVE MONTHLY PMC REPORT CONTENTS
•

Executive summary and overall project status;

•

progress against approved baseline schedule and milestones;

•

deliverables submitted/reviewed/accepted/rejected;

•

requirement compliance and traceability status;

•

integration status;

•

data migration status and reconciliation results;

•

quality/testing/UAT status;

•

security/compliance status;

•

open issues, risks, decisions and actions;

•

delays/dependencies and corrective action;

•

SLA/KPI status, where applicable;

•

planned activities for next reporting period; and

•

matters requiring TNPCB decision/approval.
