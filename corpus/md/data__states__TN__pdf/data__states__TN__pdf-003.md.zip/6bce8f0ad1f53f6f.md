---
doc_id: "6bce8f0ad1f53f6f"
source_url: "https://tncdw.org/frontend/guideline/National_Gender_Campaign__PPT.pdf"
ministry: "Tamil Nadu Corporation for Development of Women (TNCDW), Tamil Nadu"
title: ""
date: ""
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3f6e4c0052259d43"
---

<!-- page 1 -->

National Gender Campaign
Addressing Gender based Violence
Deendayal Antyodaya Yojana-National
Rural Livelihood Mission (DAY-NRLM)
Ministry of Rural Development

<!-- page 2 -->

Campaign Brief
Annual Campaign: Gender based discrimination broad theme, each year specific theme
to be identified

Period: 25th November (International Day for Elimination of Violence Against Women)23rd December 2022
Scope: Community Led National Level Campaign - All States and UTs
Launch: Proposed launch by the Hon. President of India on 25 th Nov’22 | Online and
offline participation by States and line ministries | Inauguration of 75 GRCs in 12 States
Implementation: Bouquet of activities for all States and Line Departments. Select
mandatory activities to be conducted at Community Level

Target Group: Community, FLWs, Line departments, PRIs, CSOs

<!-- page 3 -->

Community
Led-State
Facilitated

Partnership
&
Collaboration

GOAL
Advancing the agency and rights of
women and gender-diverse
individuals, by addressing structural
barriers for dignified living
with no fear and discrimination and
violence based on their gender and
intersectional identities

Strategy

Monitoring
and
Evaluation

DAY-NRLM

Communication

Documentation

<!-- page 4 -->

STAKEHOLDERS
Line Ministries and Department-MWCD, MoHA, MoTA,
MoSJE, MHFW, NLSA, MoPR, NCTP, NULM, NCW, MoE,
MIB, DoEPWD

Community
Institutions

Extended Community-Men, Boys, Girls, Elderly and
Gender Diverse Individuals
Panchayati Raj and Urban local body Members- Elected
Women Representatives etc.

CSO Partners- UNICEF, IWWAGE, PCI, PRADAN, TRIF,
C3, CHAITANYA-WISE, other State Level Organizations

<!-- page 5 -->

Activities

National:
1. Launching the Campaign by involving all stakeholders
2. Inauguration of 75 GRCs
3. National level consultative meeting on Gender campaign with line ministries to
gain their commitment.
4. Press briefings/Video bytes/Media articles/success stories
5. Campaign closing (online panel discussion) by involving stakeholders and
partners
6. Amplification of messaging through mass media

<!-- page 6 -->

State:
1.
2.
3.
4.

5.
6.
7.

Consultative workshop on addressing gender-based violence by engaging multiple
stakeholders including line departments and development partners
Publishing of success stories, and case studies/Press briefings/Video bytes
Generating awareness on ICC and POSH through posters and orientation of staff with
WCD support
Engaging media to initiate conversations on Gender-based violence, share positive
examples of gender champions and allies (such as men, boys and community leaders)
(photos from campaign activities can be shared with media persons on WhatsApp)
Capturing case stories and testimonials from field emerging during campaign (including
men, boys and community leaders)
Insight sharing meeting with all participating line departments as closing activity
Engaging -celebrities, CSO partners, MLAs, social leaders, lawyers, etc for special
interviews through various media platforms

<!-- page 7 -->

District:
1. Launch and popularize articles, case stories, hoardings, posters, AV on Ending GBV.
2. Generating awareness on ICC and POSH through posters and orientations with support of
WCD
3. Consultative workshop on addressing gender-based violence engaging multiple
stakeholders including line departments and development partners
4. Engaging district-level influencers -celebrities, CSO partners, MLAs, social leaders,
lawyers, etc for special interviews through various media platforms
5. Document campaign process

Block:
1. Awareness generation through posters on POSH and ICC
2. Facilitate interface between women and legal service providers DLSAs and Paralegals

3. Public gathering by women and FLW, line departments PRI, EWR etc. on raising voice
against gender-based violence
4. Miking of slogans on need to come together

<!-- page 8 -->

CLF:
1.
2.
3.
4.
5.
6.

Rally as per week wise themes
CLF meeting on the need to address gender-based violence (Discussions on the week wise three themes)
Movie Shows
Miking of slogans on need to speak up against GBV
Celebrating and felicitating Gender Champions (people with experience of working on gender and individuals
willing to share experiences)
Action Plan for post campaign follow up activities

VO:
1.
2.
3.
4.
5.
6.
7.

VO Aam Sabha on the need to address gender-based violence (Discussion on three themes) (Include men
and boys)
Rally as per week wise themes
Film Screening
Community Interface (women, men, girls and boys and other gender identities conversing on ending GBV)
Wall writing
Experience sharing in public meeting, small groups, and forums by willing individuals on tackling issues of
violence
Night walk with candles

<!-- page 9 -->

SHG:
1. Mandatory meetings with discussions around addressing gender-based violence
2. Pledge taking on acting on issues of violence
3. Rangoli
GP:
1. Gender Forum for interface with line departments and women

<!-- page 10 -->

Sl. No

Campaign Activities

1

Sensitization of staff on responding to cases of gender based violence at all levels

2

Awareness generation with community on access to schemes and services regarding gender based
violence

3

Training of frontline workers on understanding gender based violence

4

Orientation of staff on POSH and ICC at all level

5

Collaborative participation in all campaign activities organized by SRLMs

<!-- page 11 -->

Line Ministries: Proposed Interventions

<!-- page 12 -->

Ministry of Information and Broadcasting

At the National and state level with the help of PIB/DD/AIR/RNUs, Press Clubs and various
print and media houses

1. Provide Comprehensive Media Plan for the month
2. PIB to release curtain raiser on the themes, key messages, initiatives, programmes etc. as per
inputs provided by M/o RD to ensure mass awareness
3. Disseminate all approved content in regional media in different languages harnessing
print/electronic/digital media.
4. Conversations with SHG leaders and Community Institutions of DAY-NRLM in Community /
Regional/ National Radio
5. Streaming of films on Gender-based violence and Women empowerment in DD

<!-- page 13 -->

Contd..

1. Disseminate films Radio jingles/ audio spots etc. on women empowerment,
gender, prevention of violence against women and girls,
2. Publish articles on stories of resilience in leading national newspapers / prominent
newspapers in English, Hindi and regional languages.
3. Facilitate outdoor publicity through banners and posters
4. Spot Coverage in news bulletins by DD News, AIR and Regional News Units
5. Social Media Campaign on preventing gender-based violence to be launched
6. During the entire period of the campaign, talk shows, programmes, articles,
poems, etc may be published/organised regularly with the help of various Print
and Media Houses.

<!-- page 14 -->

Ministry of Education

1.
2.
3.

4.
5.
6.
7.
8.
9.

Schools and Community level
All schools can organise a special assembly on the issue where senior teacher or eminent
personality from their alumni (if possible, then women) network may be called for giving the talk.
Children may also be asked to write essay on the issue of GBV, Child marriage, child labour, etc.
Special film show on the issue may be organised for the children followed by debate and cultural
show on the theme.
Students can take out rally/Prabhat feri within their village/ ward/ block on gender-based
violence
Bal Mela and special drive may be organised to call the drop out and left out children back to the
school
Conduct Workshop with the girl children and SMC to understand the common factors around the
drop-out rates and what can be done to address it.
School shall organise special sessions on child rights, ‘bad touch-good touch’, POCSO Act
Child Helpline Numbers shall be shared through posters and wall paintings.
Special Discussion with the Women groups to explain the role in controlling the dropout rate and
about Right to Education.

<!-- page 15 -->

Contd..

1.
2.

3.
4.
5.

National and State level Activities
Participate in the State and national level consultation workshops
Instruct all the education and academic institutions of the country to participate in the launch event
on 25th Nov and plan some activities around the issues of GBV during the campaign period and share
with the DAY-NRLM.
Issues necessary instructions to the staff at every level to participate in the launch event and also
proactively in the entire campaign activities.
Share the campaign plan with the DAY-NRLM by 14th Nov.
Report the activities in the campaign related MIS Portal

Block and District level activities
1. Issue the instructions to the Staff, teachers and SMCs to participate in the launch event on 25th
November and thereafter in the campaign activity along with the community institutions.
2. Organise sessions on Child Rights, RTE and POCSO with the community institutions of DAY-NRLM in
their meetings
3. Seeking the help with Bal Mitra Thana, Child Welfare Committee (CWC) and Integrated Child
Protection Committees and organise their interface with the school children

<!-- page 16 -->

MoRD (MGNREGA and DDU-GKY)

1. Orient the MGNREGA wage seekers on GBV, Gender Equality, Asset creation and
POSH Act-2013
2. Issuing guidelines to all MGNREGA, PMAGY and DDUGKY staff, FLWs and PIAs to
participate in launch event and all gender campaign activities
3. Orienting all officials, FLWs and PIAs on Gender equality, GBV and POSH
4. Orient the PIAs on gender equality and GBV.
5. Introduce about the POSH in all the skill training and Form ICCs in all the training
institute
6. Report about the gender campaign activities in the Campaign Portal

<!-- page 17 -->

Ministry of Women Child Development
Proposed activities at SHG, VO, CLF and Village level
1. Participation of Adolescent Girl’s Groups in village level activities
2. Create awareness among SHGs, VOs, CLFs and other women from community on GBV
and process of filing Domestic Incident Report (DIR), One Stop Centres, CWC, Women
Helplines and Prevention of Sexual Harassment (POSH)

Proposed activities at District and Block level
1. Issuing guidelines to officials and Front line workers to participate in Gender campaign and
launch event through web cast
2. Create awareness on Gender Resource Centres (GRCs) promoted by DAY-NRLM and
linking with One Stop Centres (OSCs)
3. Conduct workshop on role of SHGs and their federations and GRC in POSH for Local
Complaints Committees (LCCs), officials and FLWs
4. Distribution of IEC materials (women helpline, Child Helpline, POSH, DV and other issues
related to VAW) to Communities and SRLM.
5. Data entry of Gender campaign activities

<!-- page 18 -->

Ministry of Health and Family Welfare
Proposed activities at SHG, VO, CLF and Village level
1. Create awareness on GBV, particularly IPV; the health consequences of violence; legal
rights and services available
2. Training to Medical Officers and ANMs in PHCs on first-line treatment to women who may
access services for violence related problems
3. Disseminate information about the Mental Health and helpline
Proposed activities at District and Block level
1. Issue guidelines to all officials, ANMs and ASHAs to participate in launch event through
web cast, in all gender campaign related activities and gender forums
2. Orienting all officials, ANMs and ASHAs on GRCs and role of SHGs and their federations in
POSH
3. Participate in the District and block level orientation and sensitization meetings to be
organised as part of Campaign.
4. Ensure the establishment of ICCs under POSH in the PHCs/CHCs
5. Data entry of gender related activities

<!-- page 19 -->

Ministry of Home Affairs
Proposed activities at SHG, VO, CLF and Village level
1. Participation of Station House Officers in Gender Forums and gender training.
2. Training SHGs and their federations on women’s rights under CrPC
3. SHOs showing their solidarity towards women in an oath taking ceremony.

Proposed activities at District and Block level
1. Issuing guidelines to police stations and beat officers to participate in launch event, all
gender campaign activities and gender forum meetings at GP and block level
2. Orienting all officials and Beat officers on GRCs and role of SHGs and their federations
in POSH
3. Participate in the District and block level orientation meetings
4. Organise interface with all the SHOs and Gender CRPs at the district level to ensure
mutual cooperation.
5. Ensure Posters related to campaign is pasted in all thanas and Ops
6. Data entry of gender campaign activities

<!-- page 20 -->

National Legal Service Authority
Proposed activities at SHG, VO, CLF and Village level
1. Organise legal awareness camps on GBV during village and SHGs and their
federations meetings.
2. Instruct Para Legal Volunteers (PLVs) to Participate in Gender Forums at GP and
Block level
Proposed activities at District and Block level
1. Issue guidelines to all DLSA officials, PLVs and empanelled Lawyers to participate in
launch event through web cast and in all gender campaign related activities
2. Orienting all officials and PLVs on GRCs and role of SHGs and their federations in
POSH
3. Issue guidelines to PLVs and Empanelled lawyers to participate in GP level Gender
Forum and Block level Gender Forums and provide support to GRCs
4. Distribute IEC materials related to GBV and gender based discrimination related laws
and Acts
5. Data entry of gender campaign related activities

<!-- page 21 -->

Ministry of Panchayati Raj
Proposed activities at SHG, VO, CLF and Village level
1. Organise discussions, rallies and night walks on GBV like witch-hunting practices,
human trafficking etc
2. Create awareness on Gender equality and GBV and role of PRIs in addressing GBV
3. Create awareness on GBV to all wage seekers
4. Participate in Gender Forums promoted by DAY-NRLM as part of Gender strategy

Proposed activities at District and Block level
1. Issue guidelines to all PRI members and officials to participate in launch event through
web cast and in all gender campaign related activities
2. Conduct orientation to all DOPR staff and PRIs on their role in the campaign
3. Orienting DOPR staff on GBV and POSH
4. Issue instructions to all PRIs to participate in GP and Block level Gender Forums
5. Distribute appropriate IEC and BCC materials till the Panchayat level
6. Data entry of Gender campaign activities

<!-- page 22 -->

Ministry of Tribal Affairs
Proposed activities at SHG, VO, CLF and Village level
1. Organise rallies and night walks on GBV
2. Organise camps for providing legal assistance
3. Organise trainings to tribal leaders on GBVs and relevant laws and Acts.
4. Orient SHG Federations on FRA and asset creation in the name of women
5. Van Dhan Vikas Kendras (VDVKs) also to carry out the activities related to the
campaign at their level
Proposed activities at District and Block level
1. Issue guidelines to all PRI members and officials to participate in launch event through
web cast and in all gender campaign related activities
2. Orienting DOPR staff on GBV and POSH
3. Distribute appropriate IEC and BCC materials till the Panchayat level
4. Data entry of Gender campaign activities

<!-- page 23 -->

Ministry of Social Justice and Empowerment
Proposed activities at SHG, VO, CLF and Village level
1. Mobilise marginalised sections to participate in gender campaign
2. Sensitize and share IEC materials with Community Institutions on Elderly, PwD, and
Transgenders issues
Proposed activities at District and Block level
1. Issue guidelines to all officials, CSO and PIAs partners to participate in launch event
through web cast and in all gender campaign related activities
2. Orienting all Social welfare department staff on GBV and POSH
3. Distribution of IEC materials related to Drug abuse, Elderly, PwD, Transgender
community, and SC welfare schemes to the Community Institutions of DAY-NRLM
4. Data entry of Gender campaign activities
National Council for Transgender Persons (NCTP)
1. Council is encouraged participate at the national level collective workshops organised by DAYNRLM
2. Council may plan consultative workshops on rights and entitlements of Transgender persons at
national/state/district level
3. Involve NISD for training and capacity building of community institutions and Staff on social
issues

<!-- page 24 -->

Ministry of Urban Affairs and Housing
Proposed activities at SHG, VO, WLF and Slum and Town level
1. Conduct Campaign Activities meant for SHGs, its federations and Community
level in the Urban areas as well as indicated under DAY-NRLM activities
2. Develop action plan for addressing the issues of GBV through community
institutions
Proposed activities at District and Block level
1. Roll out the campaign activities meant for the district and block level in the urban
areas as well
2. Issuing guidelines to all Officials and urban local bodies to participate in launch
event, all gender campaign activities
3. Orienting all officials and urban local bodies and role of SHGs and their federations
in POSH
4. Orient the transgender, Sex Worker, Domestic Workers, migrant workers network
on the GBV
5. Distribution of IEC material and Data entry of gender activities

<!-- page 25 -->

Ministry of Rural Development
Proposed activities at SHG, VO,WLF and Slum and Town level
1. Orient the MGNREGA wage seekers on GBV, Gender Equality, Asset creation
and POSH

Proposed activities at District and Block level
1. Issuing guidelines to all MGNREGA and DDUGKY staff, FLWs and PIAs to
participate in launch event and all gender campaign activities
2. Orienting all officials, FLWs and PIAs on Gender equality, GBV and POSH
3. Orient the PIAs on gender equality and GBV.
4. Introduce about the POSH in all the skill training
5. Form ICCs in all the training institute
6. Data entry of gender campaign activities

<!-- page 26 -->

National Commission for Women
Proposed activities
1. Participate in National and State level consultation meetings and workshop
related to the campaign
2. Coordinate with all the departments to ensure the roll out of POSH Act

<!-- page 27 -->

THANK YOU
