---
doc_id: "dd76a9af38edae56"
source_url: "http://tnau.ac.in/site/wp-content/uploads/2026/01/SERSTENDERDOC.pdf"
ministry: "Tamil Nadu Agricultural University (TNAU), Tamil Nadu"
title: "e-TENDER FOR THE SUPPLY OF SURFACE ENHANCED RAMAN SPECTROSCOPY (SERS) for the Professor and Head, Dept. of Agricultural Entomology, Centre for Plant Protection Studies, Tamil Nadu Agricultural University, Coimbatore – 641 003. Last Date: 13.02.2026"
date: ""
pages: 29
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ac38a8ddef0ea7ed"
---

<!-- page 1 -->

1

Tamil Nadu Agricultural University
Centre for Plant Protection Studies
Department of Agricultural Entomology
Coimbatore
e- TENDER FOR THE SUPPLY OF SURFACE ENHANCED RAMAN

SPECTROSCOPY (SERS)
Tender No. E3/SERS/GoTN-SSERA/2025-26 Dated: 27.01.2026

Publishing Date

: 29.01.2026, 2.00 PM

Document download/Sale Start Date

: 29.01.2026, 5.00 PM

Pre-Bid Meeting Date

: 02.02.2026, 11.00 AM

Bid Submission Start Date

: 02.02.2026, 05.00 PM

Bid Submission Closing Date

: 13.02.2026, 11.00 AM

Bid Opening Date

: 13.02.2026, 02.00 PM

Director
Centre for Plant Protection Studies
Tamil Nadu Agricultural University
Coimbatore

<!-- page 2 -->

2

Tamil Nadu Agricultural University
Centre for Plant Protection Studies
Department of Agricultural Entomology
Coimbatore
TABLE OF CONTENTS
S. No.

Description

Page No.

1.

Introduction

3

2.

e-Tender Notification

4

3.

Eligibility Criteria

5

4.

Cost of Tendering

6

5.

Availability of Tender Document

6

6.

General Instructions

6

7.

Earnest Money Deposit

7

8.

Tender Price and Contract Requirements

8

9.

Tender Validity

8

10.

Signing of Tender

9

11.

Tender Submission

9

12.

Procedure for Tender Submission

9

13.

Tender Opening

10

14.

Process to be Confidential

10

15.

Procedure for Tender Evaluation

11

16.

Price Bid Opening

12

17.

Criteria for Price Bid Evaluation

12

18.

Award of Tender

12

19.

Notification of Award

13

20.

Security Deposit

13

21.

Signing the Agreement

13

22.

Delivery

14

23.

Payment and Mode of Payment

14

24.

Warranties and Penalties

14

25.

Termination of Contract

15

26.

Special Conditions

15, 16

27.

Appendices 1 to 10

17 to 28

28.

Abbreviations

29

<!-- page 3 -->

3

1. INTRODUCTION
The Department of Agricultural Entomology, Tamil Nadu Agricultural University,
Coimbatore proposes to procure, New Surface Enhanced Raman Spectroscopy by
following procedures in accordance with the Tamil Nadu Transparency intenders Act 1998
and Rules 2000, 2012 as amended from time to time by the Government of Tamil Nadu. The
supply of New Surface Enhanced Raman Spectroscopy for the year 2025 - 2026 is
proposed to be purchased from the reputed manufacturer /distributors for item as indicated in
the table 1.
1.1. This consolidated tender document is for the supply of New SERS for the Department of
Agricultural Entomology, Tamil Nadu Agricultural University, as given below:-.
Table. 1

Sl.
No

Name of the Items

Approximate
Quantity
(in Nos.)

Earnest Money
Deposit to be
Paid (in Rs.)

4

5,00,000

Surface Enhanced Raman
1.

Spectroscopy with accessories

For all further references the items mentioned above will be referred briefly as New
SERS. The detailed specifications are mentioned in Appendix - 8. e-tender should be
submitted as per procedure laid down here in.
1.2. Applicability of Tamil Nadu Transparency in tenders Act and Rules:
This tender will be governed by the Tamil Nadu Transparency in Tenders Act 1998 and
Rules 2000 and Rule 2012 as amended from time to time.

<!-- page 4 -->

<!-- page 5 -->

5

3. ELIGIBILITY CRITERIA
3.1. Eligibility criteria for Tendering
A tenderer will be eligible for tendering provided he should be a Manufacturer/Authorised
dealer and has the sound technical experience; financial standing and proven successful track
record and he should satisfy all the stipulated eligibility criteria.
3.2. Eligibility Criteria


A tenderer will be eligible for tendering only if he satisfies the eligibility criteria as given
below:



If the tenderer is a Manufacturer/Authorised dealer/ Supplier, should possess valid
manufacturing license/ authorization from the competent authority for manufacturing the
items quoted.



The tenderer should have the capacity to supply New SERS within 45 days on receipt of
supply order.



The Tenderer should have a GST Registration and Income Tax PAN Copy. Copy of the
Registration Certificate and Latest GST filing certificate should be uploaded.



Tenderer from outside the state should have valid proof for having a GST registered local
stock point in Tamil Nadu.



The tenderer should not have been black listed or debarred from participating intenders by
any Central/State Government agencies or autonomous bodies or Universities/Institutions.



EMD Original or MSME certificate should be submitted if EMD exemption availed.

Financial Standing


The tenderer will be evaluated for financial standing on the basis of the Average Annual
turn over and Net Worth as per Appendix 4.



The Tenderer should be an Income Tax Assesse and (three years Income tax returns filed
should be uploaded. i.e., for the Assessment Years (2022-23, 2023-24, 2024-25).



The average Annual Turn over of the tenderer shall be calculated from the Audited Annual
Balance sheets and Profit and Loss statements for the last three preceding financial years
2022-23, 2023-24 and 2024-25 (GSTR Form-9 should be uploaded).



The net worth of the tenderer will be calculated based on the latest Audited Annual Balance
sheet and Profit and Loss Statement. The minimum Net Worth of the Tenderer should be
more than 25 % of this tender value.

<!-- page 6 -->

6

4.

COST OF TENDERING

The Tenderer shall bear all costs associated with the preparation and submission of this Tender
and the Tender Accepting Authority will in no case be responsible or liable for these costs.
4.1. TENDER DOCUMENT CONTENTS
This Tender document is for the supply of New SERS for Tamil Nadu Agricultural University
during the year 2025 -26 under Two Bid tender transparency act system.
PART A -Technical Bid
PART B - Price Bid
The Tender document contains appendices, conditions, specifications, and schedule of technical
information.
5.

AVAILABILITY OF TENDER DOCUMENT
The tender document shall be downloaded from the Government website

https://tntenders.gov.in at free of cost.
The tender document duly filled in, signed and stamped on all pages shall be
uploaded in the portal in accordance with clause 14 of this tender document.
6.

GENERAL INSTRUCTIONS
The tenderers are requested to go through the instructions, terms and conditions and
specifications given in the tender. Failure to furnish required information in every aspect
will be at the tenderer’s risk and may result in the rejection of the tender.
6.1.

Tenderer to Check Tender Documents:

The Tenderer should check all specifications shown in the tender documents and obtain his own
information on all matters which may in any way affect this tender as no claim for extras
for any alleged ignorance in

respect here of shall be entertained. The

documents/certificates etc., mentioned anywhere in this tender document including the
Check List, wherever applicable shall be a part of this tender and the tenderer shall
upload the same in the Technical Bid Cover.
6.2.

Pre-Bid Meeting:

There will be a Pre-bid meeting on 02.02.2026 by 11.00 AM at the Department of
Agricultural Entomology, TNAU, Coimbatore during which the prospective tenderer
can get clarifications about the tender. The tenderers shall send their queries in writing,
if any so as to reach the office of the Director (CPPS), TNAU, on the day of the pre-bid
meeting date.
Non-attending of Pre-bid meeting is not a disqualification.
6.3.


Amendments to the Tender:
The Director (CPPS), TNAU, Coimbatore may amend the tender

<!-- page 7 -->

7

Where ever it is felt that such an amendment is absolutely necessary.


Amendment to the tender may also be given in response to queries raised by
prospective tenderer(s) and it is solely the discretion of the Director (CPPS), TNAU



Any amendment to the tender will be uploaded in the website https://tntenders.gov.in.
Further it will also be shown under title namely latest corrigendum in the Portal. It is
the responsibility of the tenderer to verify the amendments if any and download the
amendment documents before the submission of the tender provided no such change
could be effected 48 hours prior to the time fixed for opening of the tender.

6.4.
6.5.

The Tender document is not transferable under any circumstances.

Each tenderer is eligible to submit only one tender. Any deviations to these Criteria may
result in rejection of the tender.

7.

Earnest Money Deposit (EMD)

7.1.

Each tender must be accompanied by the Earnest Money Deposit (EMD) paid through
online mode for the value as detailed below. No interest will be paid for the EMD by the
Department of Agricultural Entomology, TNAU (Enclose EMD details).
S. No

1.

7.2.

Name of the Items

Approximate
Quantity (in No)

Earnest Money
Deposit to be paid
(in Rs.)

Surface Enhanced Raman
Spectroscopy with accessories

4

5,00,000/-

The Department of Agricultural Entomology, TNAU will arrange to refund the EMD to the
unsuccessful tenderers after publishing the list of successful tenderers, within a reasonable time.

7.3.

Registered Domestic Small Scale Industrial units are exempted from payment of EMD for
the product range mentioned in the respective certificate, provided that, only those products
covered under the certificate will be exempted for EMD; provided also that, only to the firms
which participate in tender as a manufacturer.

7.4.

To avail exemption from payment of EMD, the tenderer has to submit a valid
SSI/NSIC/MSME certificate.
7.5.

The EMD amount may be forfeited if:
a)

The Tenderer withdraws his tender at any stage after the last date and time fixed
for submitting the tender.

b)

In case of a successful tenderer, if he fails to furnish the required security deposit
or sign the agreement, within the stipulated time limit.

<!-- page 8 -->

8

8.

TENDER PRICE AND CONTRACT REQUIREMENTS

8.1.

Tenderers are required to fill up the rate quoted and other details in the Price Bid- BOQ.
8.2.

8.3.

Tenderer shall not make any changes in the Price Bid–BOQ format.

All purchase taxes, duties on purchases, entry tax and any other taxes and duties and levies
on purchases, if any shall be included in the price but exclusive of GST. If GST is levied, it
should be specifically mentioned with the prevailing percentage (%) of GST.

8.4.

The rate should be Freight on Road (F.O.R) destination and should be inclusive of all
applicable taxes, inclusive of packing, transporting and charge either by rail or by road, to
the destination, loading and unloading charges etc.

8.5.

Rates should be quoted only for item specified in the tender document. The item quoted
should conform to the specifications mentioned in the schedule (Appendix 7).

8.6.

The tenderer shall fill up and sign the Letter of Tender (Appendix - 5) and all schedules etc.
which are included in the tender documents.

8.7.

Tenderers shall submit their tenders in accordance with the specifications of the tender
documents only. Alternatives will not be considered.


The prices shall be firm and fixed during the entire currency of the contract and till
completion of all contractual obligations. Any extension in time granted by the Tender
Accepting Authority to the completion schedule shall be subject to the condition and
there shall be no additional financial implication to the Director (CPPS), TNAU.

8.8.

The purchaser shall not be responsible for any change in the tax rate during the contract
period.

8.9.

The rates quoted in the tender should be valid for the period of one year from the date of
acceptance of the Tender i.e. Dates of execution of agreement. Tenderer should be in a
position to supply the SERS during this period.

9.
9.1.

TENDER VALIDITY
Tenders shall remain valid for a period of 180 days from the due date of submission of the
Tender.

9.2.

In exceptional circumstances, prior to expiry of the initial time limit as indicated in above,
the Tender Accepting Authority may request the Tenderer to extend the period of validity
for a specified additional period. The request and the Tenderers responses shall be made in
writing or by fax. A Tenderer may refuse the request without forfeiting his Earnest Money
Deposit. A Tenderer agreeing to the request will not be permitted to modify his Tender.
However, he shall extend the validity of the Earnest Money Deposit for the period of the
extension.

<!-- page 9 -->

9

10.

SIGNING OF TENDER
The tender shall be digitally signed by a person or persons duly authorized to sign on
behalf of the Tenderer. The tenderer shall upload a certified copy of the Power of
Attorney authorizing the signatory or signatories to sign the tender document. This
certification shall be from the Managing Director or the authorized Person by the firm.

The tender shall contain no alterations or additions, except those to comply with instructions
issued by the Director (CPPS), TNAU, Coimbatore, or as necessary to correct errors
made by the tenderer, in which case such corrections shall be digitally signed by the
person or persons signing the tender.
11.

TENDER SUBMISSION

Due Date for Tender Submission: Tender document shall be uploaded in the portal upto
11.00 AM on 13.02.2026.
12.

PROCEDURE FOR SUBMISSION OF TENDER
i.

Tenderers are advised to go through the tender documents and understand all the
provisions and stipulations contained therein before submitting the tender.

ii.

The tender shall be submitted exactly as per the procedures and requirements
stipulated here in.

iii.

The tender must be submitted so as to be received within the stipulated date and time
as per clause 13.

iv.

The tender shall be submitted in two bid system as follows:
Technical Bid

: Capability to supply SERS with the Tender details

Price Bid or BOQ

: Price Quotation or Bill of Quantity

Last Date and Time
For Uploading of Tender

: 13.02.2026 11.00 AM

v. The Technical Bid shall contain the following as per the sequence indicated below.
1.

Covering Letter and Check list as per Appendix-1

2.

Certified Power of Attorney authorizing representative(s)of the firm
To sign the Tender and all subsequent communication.
Copy of the SSI of Tamil Nadu State or NSIC or MSME Certificate

3.

In case of Small Scale units (Manufacturer) availing exemption from
Payment of EMD.

4.

Declaration as per Appendix-2

<!-- page 10 -->

10

5.

Evidence of relevant experience as per Appendix-3 and as per Clause 3.2
of the tender document and Invoices copies.
Evidence for Financial Standing as per Appendix-4 and a copy of Audited

6.

Balance sheets and Profit and Loss statements for the last three financial
Years as per clause 3.3(i) and (ii) of the tender Document.

7.

Income Tax filing for the Assessment Year 2022-23, 2023-24, 2024-25 as
per clause 3.2 of the tender document.

8.

GST Registration Certificate and Latest GST Filing certificate as per
3.2 of the tender document.

9.

Letter of Tender as per Appendix - 5
Declaration by the Tenderer that his tender is without any technical deviations

10.

in the letter format as per Appendix-6 and enclose documents as per clause 3
(eligibility criteria) of the Tender document.

11.

Documents establishing the fact that Tenderer is an Authorized agent of the
original manufacturer(s).

14.

Confirmation of technical specifications and terms and conditions as per
Appendix-7 as mentioned in Appendix-8.

15.

Notarized undertaking from Tenderer as per Appendix-9.
A blank copy of the Tender document including appendices with all pages

16.

duly signed by the authorized signatory of the Tenderer and stamped with the
company seal as a proof of having read, understood and accepted the tender
conditions(without filling the document).

13. TENDER OPENING
13.1. Tender Opening: The authorized representatives of the Tender Accepting Authority will
open the Tender at 2.00 PM on 13.02.2026.
13.2. The Technical Bid shall be opened first.

14. PROCESS TO BE CONFIDENTIAL

14.1. Information relating to the examination, clarification, evaluation and comparison of tenders
and recommendations for the award of contract shall not be disclosed to tenderers or any
other persons not officially concerned with such process until the award to the successful
tenderer has been announced.
14.2.

Any effort by a tenderer to influence the Tender Accepting Authority, scrutiny

<!-- page 11 -->

11

/ evaluation committee or its members in the processing of tenders or award decisions
may result in the rejection of his tender.
15. PROCEDURE FOR TENDER EVALUATION
15.1. After opening the tenders, the Tender Accepting Authority will determine whether the
tenderer has fulfilled all the conditions as stipulated under clause 14.1 of this tender
document viz., the EMD paid through online via e-tender portal, the various appendices
required to be submitted with the Tender, and other documents as called for shall be
uploaded in the Portal.
15.2. The Tender Accepting Authority will then proceed with the evaluation of those tenders
which have not been rejected as per clause 17.1.
15.3. Before proceeding with the detailed evaluation, the Tender Accepting Authority will
determine whether the Tender is substantially responsive or not. A responsive tender is one
which conforms to all the terms, conditions and specifications of the tender documents
without material deviation or reservation. A material deviation or reservation is one:
a) Which affects in any substantial way the scope, quality or performance of the works.
b) Which in a substantial way is inconsistent with the Tender Documents, the Tender

Accepting Authority's rights or the Tenderer’s obligations under the Contract, or
c) Whose rectification would affect unfairly the competitive position of other

Tenderers presenting substantially responsive Tenders.
15.4. Tenderers who have not fulfilled the tender conditions shall be a non-responsive tender and
will not be taken up for further evaluation and Price bid opening.
15.5. To assist the examination, evaluation and comparison of Tenders, the Tender Accepting
Authority may at his discretion, ask any tenderer for clarification on his Tender. The request
for clarification and the response shall be in writing or by fax but no change in the substance
of the Tender shall be sought, offered, or permitted.
15.6. If a Tender fails to be responsive, it will be rejected by the Tender Accepting Authority and
may not subsequently be made responsive by correction or/ withdrawal of the nonconfirming deviation or reservation.
15.7. The purchaser reserves the right to verify the availability of infrastructure facilities to
ascertain the ability of the tenderer to supply quality material at any time and the purchaser
also reserves the right to reject the tender of any tenderer based on the inspection report of
the authorized representative.

<!-- page 12 -->

12

16. PRICE BID OPENING
16.1. The Tender accepting Authority will then proceed with opening of “Price Bid –BOQ” of
those tenderers whose technical tender have been found substantially responsive in all
aspects and fulfill all the tender conditions. The opening of the “Price Bid -BOQ” will be
done in the Portal. The Tender Accepting Authority will inform the responsive Tenderers
through the Portal about the acceptance of their technical tender.
16.2. The “Price Bid – BOQ” will be opened on the stipulated date and time, which will be fixed
and communicated through the Portal after the completion of technical evaluation.
17. CRITERIA FOR PRICE BID EVALUATION
17.1. In price bid evaluation the following procedures will be adopted.
a) The Price should be quoted in the Bill of Quantity (BOQ). The BOQ format should

not be altered.
b) The Evaluation shall include GST and all other central duties such as customs duty

and central excise duty and sales tax if any as a part of the price.
c) The Tender Accepting Authority may carry out negotiation with lowest tenderer (L1)

as per evaluation.
d) The Tender Accepting Authority reserves the right to ask other tenderers to match the

L1 price if required, according to the Tamil Nadu Transparency in Tenders Rules
2000 and 2012.
18. AWARD OF TENDER
18.1. The award of the tender shall be made strictly in accordance with the “Tamil Nadu
Transparency in Tenders Act 1998 Rules 2000 and Rules 2012” and no deviation will be
made.
18.2. The Director, CPPS, TNAU, Coimbatore has the right to accept any tender and to reject any
or all tenders.
18.3. Not withstanding anything that is said herein, the Tender Accepting Authority reserves the
right to accept or reject any tender, and to cancel the tendering process and reject all tenders,
at any time prior to the award of tender, without thereby incurring any liability to the
affected tenderer(s) or any obligation to inform the affected tenderer(s) on the grounds for
the tender accepting authority’s action.
18.4. The Tender Accepting Authority reserves the right to split up the items into convenient
portions and all of them to different contractors and to increase or decrease any of the
quantities mentioned in the tender document to the extent of 25% as per the Tamil Nadu
Transparency in Tenders Act 1998 Rules 2000 and Rules 2012.

<!-- page 13 -->

13

19. NOTIFICATION OF AWARD
19.1. The tenderer whose tender has been accepted will be notified by the Tender Accepting
Authority, in writing will be uploaded in the Portal.

19.2. Notification of award will constitute the formation of rate contract, subject only to the
furnishing of Security Deposit in accordance with the provisions of clause 20 of this tender
document and signing of the agreement as per clause 21 of this tender document.
19.3. Upon furnishing the security deposit by the successful tenderer(s) and upon signing the
Agreement, the EMD of the unsuccessful tenderers will be returned within a reasonable time
period.
20. SECURITY DEPOSIT
20.1. The successful Tenderer will be required to furnish Security Deposit of 5% of the total
tender value within 7 working days from the date of receipt of the communication intimating
the acceptance of tender. This deposit should be in the form of either Demand Draft drawn
in favour of The Professor & Head, Department of Agricultural Entomology, TNAU,
Coimbatore or in the form of an Irrevocable Bank Guarantee in the format enclosed
(Appendix 10) for a period of one year from the date of furnishing the guarantee and a
period of another 3 months to exercise upon the said guarantee.
20.2. If the successful tenderer fails to remit the Security Deposit within the above said period, the
Earnest Money Deposit paid by him will be forfeited to the Department of Agricultural
Entomology, TNAU, Coimbatore and his tender will be held void and the Tender Inviting
Authority shall continue the process with other responsive tenderer as per the Tamil Nadu
Transparency in Tenders Act 1998 Rules 2000 and Rules 2012. The Director, CPPS, TNAU,
Coimbatore also reserves the right to take any other action as deemed necessary against such
tenderer.
20.3. No Interest will be paid by Department of Agricultural Entomology, TNAU, Coimbatore
on the Security Deposit.
21. SIGNING THE AGREEMENT
21.1. The successful tenderer shall execute an agreement (three copies) on a Non-Judicial stamp
paper to the value of Rs.100/-embodying the terms and conditions of the tender within 7
days from the date of acceptance of the tender.
21.2. If the agreement mentioned in clause 21.1 above is not executed in the prescribed period the
Earnest Money Deposit and Security Deposit of the tenderer are liable to be forfeited to
Department of Agricultural Entomology, TNAU, Coimbatore.
21.3. In case of successful tenderer being the SSI, if the agreement mentioned in clause 21.1

<!-- page 14 -->

14

above is not executed in the prescribed period, the approval granted accepting the tender will
become null and void.
21.4. The successful tenderer, if fails to execute the agreement within the stipulated period, he will
also be liable for all damages arising there from such default including the cost of
conducting fresh tenders and the increase in rates if any, in the subsequent tender and shall
compensate for all losses sustained by the University in this regard.
21.5. The rate of the contract is valid for a period of one year from the date of execution of
agreement.
22. DELIVERY
22.1. The tenderer should deliver the SERS at the destination as per the supply orders within 45
days from the date of receipt of Supply order without penalty. Any delay in supply will not
be entertained and acceptable
22.2. While supplying through the authorized distributors, the Tenderer is responsible for
fulfillment of all the tender conditions.
23.PAYMENT AND MODE OF PAYMENT
23.1. The Professor and Head, Department of Agricultural Entomology, TNAU, Coimbatore
shall be the Consignee to receive the item in the Supply Order. The address of the
Professor and Head, Department of Agricultural Entomology, TNAU, Coimbatore shall be
clearly mentioned.
23.2. The Supplier should raise the invoice in triplicate in the name of the Professor and Head,
Department of Agricultural Entomology, TNAU, Coimbatore.
23.3. Payment shall be made to the firm by the Consignee after the receipt of the purchase
item and after due verification and testing for quality and quantity and in accordance
with specification mentioned in the Tender.
23.4. No payment will be made against Lorry Receipt /Rail Receipt or through Bank for the
consignment by the University.
23.5. No mobilization advance or any sort of advance payment request shall be considered.
23.6. Any request or condition on the mode of payment other than the conditions mentioned
in the Clauses 23.1 to 23.5 shall be considered as disqualification and the tender will be
rejected summarily.
24. WARRANTIES & PENALTIES:
24.1. The supply of SERS shall be completed within 45 days from the date of receiving the
Supply Order. The Director (CPPS), TNAU shall have the power to impose penalty for
belated supply.
th

th

24.2. For the New SERS delivered between 46 day and 60 day, a penalty of 1% of the total

<!-- page 15 -->

15
st

th

amount of the bill, 61 to 70 day, a penalty of 2% of the total amount of the bill will be
st

imposed. No delivery shall be effected after the 71 day of receipt of indent. Consignment
delivered after 71th day of receipt of indent will not be accepted and the indent shall lapse
automatically. The decision of the Director (CPPS), TNAU will be final in this regard.
24.3. Further, in the event of supply not effected within stipulated time or supply of materials as
per the specification and quality not met, the Director (CPPS) reserves the right to initiate
any other action, as deemed fit, such as to debar the supplier from participating in future
tenders and/or blacklist for non-compliance of the contract.
24.4. The Director (CPPS) reserves the right to decide whether the Security Deposit should be
forfeited for non-fulfillment of the contract or for belated dispatches.
24.5. The Director (CPPS) reserves the right to waive or alter any of the conditions depending
on exigencies within the framework of the Tamil Nadu Transparency in Tenders Act 1998,
Rules 2000 and Rules 2012.
25. TERMINATION OF CONTRACT
25.1.
Termination for Default:
 The Purchaser may, without prejudice to any other remedy for breach of contract, by
written notice of default with a notice period of 15 days, sent to the Supplier, terminate
the contract in whole or part,
•
If the Supplier fails to deliver any or all of the goods within the time period(s)
specified in the Contract, or
•
If the Supplier fails to perform any of the obligation (s) under the contract; or if the
Supplier, in the judgment of the Purchaser, has engaged in fraudulent and corrupt
practices in competing for or in executing the contract.


In the event the Purchaser terminates the contract in whole or in part, the Purchaser
may procure, upon such terms and in such manner as it deems appropriate, the goods
and services similar to those delivered and the Supplier shall be liable to the Purchaser
for any additional costs for such similar goods. However, the Supplier shall continue

the performance of the contract to the extent not terminated.
25.2.
Termination for Convenience:
The Purchaser may issue notice, with a notice period of 15 days sent to the Supplier, and
may terminate the Contract, in whole or in part, at any time for its convenience. The notice
of termination shall specify that termination is for the Purchaser’s convenience, the extent
to which performance of work under the contract is terminated, and the date upon which
such termination becomes effective.
26.

SPECIAL CONDITIONS

26.1. Adducing reasons like breakdown of machinery in the factories, power cut if any
enforced by power utilities, strikes, non-availability of technical grade materials for
manufacture, for not accepting orders when placed or for delays if any in actual supplies
or any other reason will not be entertained. Non-fulfillment of the contract on any

<!-- page 16 -->

<!-- page 17 -->

17

Tamil Nadu Agricultural University
Coimbatore
APPENDIX-1–CHECKLIST
Tender for the supply of New SERS
(Please mention Yes or No as the case may be for each item below). Have you enclosed the
following?
1. Covering Letter and Check list as per Appendix-1
Yes/No
2.

Certified Power of Attorney authorizing a representative(s) of the firm
to sign the Tender and all subsequent communication

Yes/No

3.

Declaration as per Appendix-2.

Yes/No

4.

The Proof of Payment of EMD through tntenders portal or the
SSI/NSIC/MSME Certificate in case of Small Scale units availing
Exemption from payment of EMD.

Yes/No

Evidence of relevant experience as per Appendix- 3 along with

Yes/No

5.

-

The Invoices or

-

The Testimonials from any one Client for the last three
preceding years 2022-2023, 2023-2024 and 2024-2025.

Evidence for Financial Standing as per Appendix-4 along with
6.

-

Audited Balance Sheets and Profit & Loss Statements;

-

The Net worth Certificate separately duly signed by
charted accountant;

Yes/No

-

7.
8.
9.
10.
11.
12.

Income Tax Returns for the last three financial years i.e.
2022-23, 2023-2024 and 2024-2025
The Solvency Letter from the bank to fulfill this requirement of
confirming his tender capacity.
The relevant valid GST Registration certificate and Latest GST Filing
Certificate.
Letter of Tender as per Appendix-5
Declaration by the Tenderer that his tender is without any technical and
commercial deviations in the letter format as per Appendix-6

Yes/No
Yes/No
Yes/No
Yes/No

Notarized Undertaking from the Tenderer as per Appendix-9

Yes/No

A Blank copy of the Tender document including appendices with all pages
duly singed by the authorized signatory of the Tenderer and stamped with
the company seal as a proof of having read, understood and accepted the
Tender conditions.(without filling the document)

Yes/No

Place

:

Signature of Authorized Signatory

Date

:

Name

:

Designation

:

Company Seal

<!-- page 18 -->

18

APPENDIX – 2
DECLARATION
SUPPLY OF ............................................................................ (Specify Item)
CERTIFICATE (To be submitted along with the tender)
1) I/We.........................have gone through the instructions in the tender and agree to abide
by all the conditions mentioned therein.
2) I/We.........................hereby have remitted Rs.........

(Rupees .................................... only) as Earnest Money Deposit in online mode via eTender portal.
3) I/We hereby certify that the prices tendered by me/us is to the best of my/our

knowledge and belief, are not more than the price which is permissible for me
/us to charge a private purchaser for the same items and description of goods under
the provisions of any law in force.
4) I/We hereby certify that the rates quoted in this tender is final and I/We will not come

forward for any revision or alteration in rates quoted subsequently due to hike in prices
or any other reasons.
5) I/We hereby accept to forfeit the Earnest Money Deposit in the event of withdrawal of

tender by me/ us subsequent to opening of the tender or in case of my/our failure to
undertake the contract for the items accepted by the Tender Accepting Authority,
Tamil Nadu Agricultural University, Coimbatore.
Place

:

Signature of Authorized Signatory

Date

:

Name

:

Designation

:

Company Seal

WITNESS SIGNATURE :
Name
Address

:
:

<!-- page 19 -->

19

APPENDIX - 3
Manufacturing and sale experience of the Manufacturer/Authorized Agent
/Distributor
REFERENCE LIST OF CONTRACTS TO ESTABLISH THE CAPACITY TO
SUPPLY

Financial
Year*

Qty Sold
/ Supplied

Customer details

Invoice
No. and
date

Value of the
supply
Rs. In lakh

*During any one of the last three financial years
Contact Official of the Department/ Organization with whom the contract was executed
Name and
:
Address

Phone No.

:

(Copies of Invoices should be attached).
Place

:

Date

:

Signature of Authorized Signatory
Name

:

Designation

:

Company Seal

<!-- page 20 -->

20

APPENDIX - 4
1. Name of the Firm

FINANCIAL CAPABILITY
:

2. Address of the Registered Office

:

3. Address of the Office of
Communication

:

4. Address of the Manufacturing Unit

:

5. Net Worth of the Firm (2024-25)

:

6. Annual Turn Over of the preceding three years:

Year

Annual Turn Over (In Lakh Rs.)

1) 2022-2023

:

2) 2023-2024

:

3) 2024-2025

:

Average of the above three years :

Place :
Date

:

Signature of Authorized Signatory
Name

:

Designation

:

Company Seal
Attachments to be submitted along with this Appendix:
i. Annual Audit Balance Sheets and Profit and Loss statements for the last three financial
years 2022-23,2023-24 and 2024-25 with UDIN.
ii. Online statement of GST filing for the latest month should be enclosed.
iii. Worksheet on the Net worth of the Firm. (for Net Worth: Capital Cost, Reserve & Surplus
alone will be considered)

<!-- page 21 -->

21

APPENDIX - 5
LETTER OF TENDER
To
The Director (CPPS), TNAU,
Coimbatore-3

Madam,
Subject: Tender for the supply of............................................. (Specify the item)
I/We, the undersigned do hereby tender and undertake to perform, provide, execute all
the works, materials, matters and things described or intimated in the various schedules here
to annexed and the specifications thereto (which have been produced to and carefully
examined by us) in strict accordance with and subject to the terms, provisions and conditions
setforth or mentioned in the said schedules, specifications at the rates given and as stated in
the price schedule.
I/We hereby have remitted Rs.
(Rupees
only) to the Professor & Head, Department of Agricultural
Entomology, TNAU, Coimbatore, as a guarantee for the due fulfillment of our tender[EMD]
via online mode and if successful, undertake and agree to forward to the Director(CPPS),
TNAU, fifteen days after the notification of the acceptance by the Director (CPPS), TNAU of
this Tender has been received by us, the Security Deposit as demanded in the form and
manner required as security for the due fulfillment of our Contract.
We undertake and agree that we will not withdraw this Tender during the period that
will be required for Intimation of Acceptance or Non-Acceptance as stipulated in clause 19 of
the Tender document such period to date from the last date by which Tenders are due to be
submitted to the Director (CPPS), TNAU. If we do so withdraw, we shall forfeit the Earnest
Money Deposit to the Professor & Head, Department of Agricultural Entomology, TNAU,
Coimbatore-3. We further undertake to produce the certificate of Sales Tax verification in
original from the Commercial Tax Department and agree to execute at our cost the Agreement
in(15) fifteen days after the notification of the acceptance of our Tender has been received by
us. In the event of our failing to make the Security Deposit or to execute the Agreement in the
said manner, the sum of Rs ............................................................................................. (Rupees
…………………………………………………….. only) accompanying this Tender shall be
forfeited to the Professor & Head, Department of Agricultural Entomology, TNAU,
Coimbatore and this concluded Contract shall in such case be considered as having been
cancelled or terminated and we agree to be liable irrespective of the forfeiture aforesaid for all
damages, losses, costs, charges and expenses arising from or by reason of such failure and
arrangements.
As witness our hand this..............day of ...................... of 2025.
Place

:

Date

:

Signature of Authorized Signatory
Name

:

Designation

:

Company Seal

<!-- page 22 -->

22

APPENDIX - 6
FORM OF LETTER CONFIRMING AGREEMENT WITH TECHNICAL
AND COMMERCIAL TERMS & CONDITIONS OF THE TENDER
To
The Director (CPPS),
TNAU, Coimbatore-3

Sir,
Subject: Tender for supply of ............................................................... (Specify the item)
We have examined the Tender document, the receipt of which is hereby
acknowledged.
We have submitted our Tender ref................Dated.............for the supply
of.........................................................as per the specifications and terms and
conditions of the Tender Document.
We confirm that our Tender is in conformity with the technical specifications and
commercial terms & conditions as stipulated in the Tender Document and without any
deviations whatsoever. We are aware that our Tender is liable for disqualification in the event
of technical and commercial deviations are observed by the Tender Accepting Authority at a
later date during the process of evaluation of our Tender.
Thanking you and assuring you of our best services always.
Place :
Date

:

Signature of Authorized Signatory
Name

:

Designation

:

Company Seal

<!-- page 23 -->

23

APPENDIX - 7
SCHEDULE OF CONFIRMATION OF TECHNICAL INFORMATION
. ...................................................................(Specify the item)
(Tenderer is to complete this schedule and submit it with the tender)

Name of the Material

Specifications with capacity

(The specification should confirm as per the specifications mentioned in Appendix 8).

Place :
Date

:

Signature of Authorized Signatory
Name

:

Designation

:

Company Seal

<!-- page 24 -->

24

APPENDIX–8
SPECIFICATION OF SERS
The system should be suitable for the analysis of pesticide residues in selected vegetables,
fruits, spices and rice and have user-friendly software with the following specifications.
Item
Hardware

Specification


Size: 46.2 cm(L) X 34.0 cm(W) X 17.0cm (H)；Weight: 11
kgs Box: rugged box with Waterproof, shockproof and
dustproof Power: Input: 12.6 VDC/Output: 12.6-10.8 VDC;
9800mAh Operating temperature range: 10oC ~ 45oC



Measurement: direct incident focusing beam with SERS
substrate



Sensitivity: Signal count of Si-wafer (520 cm-1 large than
20000counts

Raman Spectrometer



Laser wavelength 785nm；f-number : f/1.3 Wavenumber
range : 300~1800 cm-1



Stability: after laser beam stable(30s), variation of laser
power< 3%

Interface software



Resolution < 10 cm-1(slit size: 50μl x 2mm)



Integration time 50ms- 3 mins



Power AC : 100240VAC 50/60Hz



The operating software should provide user to handle the
inspection procedure step by step.



User could link to cloud system to search the database,
analysis, and print the output result.



Library should support detection of pesticides, heavy metals
and antibiotics

Air Extracting
Concentration



Fan Motor：12V 1.71A with 4pin



Power adaptor: AC 110-240V to DC 12V 1000mA
Stand：15×22×29 cm S107 verticalst and



Straw：65 mm aluminum straw

<!-- page 25 -->

25

Surface Enhanced



Holder：40 hole acrylic type holder



Broader enhanced wavelength range (from 532nm to

Raman Scattering
Substrate

1064nm)


High enhanced factor (>107) for most adsorbed molecules



Good uniformity and excellent reproducibility



Material: Silver with gold coating



Excitation wavelengths : 532nm, 633nm, 785 nm, 1064nm



Spot size > 5μm ; power density: 2mW/10μm



SERS cartridges or substrates supplied should reach the end
user with sufficient validity.

Warranty/license



SERS Substrate number required - 6000 numbers



SERS powder numbers required - 6000 numbers



SERS-enabled Raman spectrometers integrated with spectral
library software with a 3-year license

Others



Transport, training and demonstration should be free of cost



Customization of pesticide detection levels in fruits,
vegetables, and other matrices as per FSSAI MRL or EU
MRL.



Electronic note book may be supplied along with the
instrument



The Grating selection in the range of 600–1200 grooves/mm
shall be considered for spectral resolution and wavelength
accuracy of SERS Systems

Confirmation of specifications: The vendor should provide the original data sheet to confirm
the specifications.

<!-- page 26 -->

26

APPENDIX– 9
NOTARIZED UNDERTAKING
[To be produced in original]
I / We M/s…………………..represented by its Proprietor/Managing Partner
/Managing Director having its Registered Office at ……………………… and its Production,
Sales Premises at ………………………….. do declare that I / We have carefully read all the
conditions of tender In Ref ............................................... for the year 2025-26 floated by the
Director (CPPS), TNAU, Coimbatore and accepts all conditions of the Tender. I /We declare
that we possess a valid license
Manufacturing of........................................The manufacturing License issued by the
Competent Authority is enclosed with this Declaration.
I am / we are aware of the Tender Inviting Authority’s right to forfeit the Earnest
Money Deposit and / or Security Deposit and blacklisting me/us if, any information furnished
by us proved to be false at the time of inspection and not complying with the tender
conditions.

Place :
Date

:

Signature of Authorized Signatory
Name

:

Designation

:

Company Seal

To be attested by the Notary.

<!-- page 27 -->

27

APPENDIX–10
Bank Guarantee Format
(To be executed in Rs.100/-Stamp Paper)
To
The Professor & Head
Department of Agricultural Entomology,
TNAU, Coimbatore-3
Bank Guarantee No:
Amount of Guarantee:
Guarantee covers from:
Last date for lodgment of claim:
The Deed of Guarantee executed by. ............................................... (Banker Name
................................................................................................................................... & Address)
Having Head Office at ................................................................................................ (Address)
(hereinafter referred to as “the beneficiary”) for an amount not exceeding
Rs....................../- (Rupees ....................................................................................................only)
As per the request of M/s...............................................................................................having its
Office Address at ................................................................................ (hereinafter referred to as
“the Supplier”) against Letter of Acceptance Reference ....................dated.....................of The
Director (CPPS), TNAU, Coimbatore.
This guarantee is issued subject to the condition that the liability of the Bank
under this guarantee is limited to a maximum Rs.
/-(Rupees
only) and the guarantee shall remain in full force up to months from the date of Bank
Guarantee and cannot
be invoked otherwise by a written demand or claim by the beneficiary under the Guarantee
served on the Bank before
months from the date of Bank
Guarantee.
AND WHEREAS it has been stipulated by you in the said ORDER that the
Supplier shall furnish you with a Bank Guarantee by a Scheduled/Nationalized Bank for the
sum specified therein as security for compliance with the Supplier’s performance obligations
for a period in accordance with the contract.
AND WHEREAS we have agreed to give the Supplier a Guarantee.
THEREFORE,
we
(Banker’s
address)
....................................................................................................................... , here by affirm
that we are guarantors and responsible to you on behalf of the supplier up to total of Rs.
/- (Rupees. ............................................................................... only) and
we undertake unconditionally to pay you, upon your first written demand declaring the
Supplier to be in default under the contract and without any demur, cavil or argument, any

<!-- page 28 -->

28

sum or sums within the limit of Rs
/-(Rupees
only) as aforesaid, without your
needing to prove or show grounds or reasons for your demand or the sum specified therein.
We will pay the guaranteed amount not withstanding any objection or dispute
whatsoever raised by the supplier.
This Guarantee is valid until .......................months from the date of bank guarantee.
Notwithstanding any thing contained herein.
Our liability under this guarantee shall not exceed Rs.
/(Rupees...................................................only). This Bank Guarantee shall be valid up to
months from the date of Bank Guarantee and we are liable to pay the guaranteed
amount
or
any
part
the
reofunderthisBankGuaranteeonlyandonlyifyouserveuponusawrittenclaimordemandonorbefo
re
.
In witness where of the Bank, through its authorized Officer, has set its, hand and
stamp on this.........................................at
.

Witness: (Signature)
(Name in Block Letters)

<!-- page 29 -->

29

ABBREVIATION USED IN THE TENDER DOCUMENT

ABBREVIATION

EXPANSION

GST

Goods and services Taxes

CGST

Central Goods and services Taxes

SGST

State Goods and services Taxes

EMD

Earnest Money

SSI

Small Scale Industries

NSIC

National Small Industries Corporation

MSME

Micro, Small and Medium Enterprises

F.O.R.

Freight on Road

LR

Lorry Receipt

RR

Rail Receipt

DD

Demand Draft

NSC

National Saving Certificate

UDIN

Unique Document Identification Number

HSN

Harmonized System Nomenclature

Portal

https://tntenders.gov.in

Tender Accepting Authority
Tender Inviting Authority
Supplier

Purchaser

BOQ

Deposit

TNAU, Coimbatore
Director(CPPS), TNAU, Coimbatore
The successful tenderer whose tender
has been accepted.
The Professor & Head,
Department of Agricultural
Entomology, TNAU,
Coimbatore-3
Bill Of Quantity
