---
doc_id: "2a2eccec4ceca9a4"
source_url: "https://tnidb.tn.gov.in/media/tender_documents/-Advertisement_-_TA-_Sector_Experts-__final.pdf"
ministry: "Tamil Nadu Infrastructure Development Board, Tamil Nadu"
title: "Job Description and Application Format"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "135522a32d17f671"
---

<!-- page 1 -->

TAMIL NADU INFRASTRUCTURE DEVELOPMENT BOARD
INVITATION OF APPLICATIONS FOR THE POSTS OF EXPERTS/ANALYSTS BY
INDIVIDUAL APPLICANTS
1. About Tamil Nadu Infrastructure Development Board
The Tamil Nadu Infrastructure Development Board set up under the Tamil Nadu Infrastructure
Development Act, 2012 is the nodal agency for infrastructure development in the State of Tamil
Nadu. TNIDB plays a critical role in infrastructure development in the State by facilitating project
development in a seamless, efficient, and transparent manner. The TNID Act along with the Rules
and Regulations thereof provides TNIDB with the necessary administrative authority and lay down
a clear framework of processes and procedures to:


Create an enabling and facilitative environment



Identify, prioritise, and implement infrastructure projects



Enable private sector participation where feasible

More about TNIDB can be found at www.tnidb.tn.gov.in
The Government of Tamil Nadu has identified Public Private Partnerships (PPPs) to support
infrastructure development in the State. The Tamil Nadu Infrastructure Development Board
(TNIDB) is the nodal agency for development of PPP projects in the State. The TNIDB, housed
in the Finance Department, promote, develop, structure and approve PPP projects undertaken by
the State Government agencies. To support TNIDB in the delivery of PPP projects, the Board
intends to engage the following result-oriented professionals with proven domain expertise in the
relevant sectors.
S.
No.
1

Position

Job Description

Energy a) Review
projects/proposals a) A Master’s degree in
submitted by departments and
management, engineering or
state-owned entities involved
finance.
the preparation, development, b) Post qualification, at least 8
To support TNIDB
and implementation of PPP
years of relevant PPP
and the Department
projects.
experience in energy projects
in delivering PPP b) Assist in the review of DFRs
– such as planning, design,
and assist in the preparation of
and feasibility studies as well
Expert
Sector

–

Educational Qualifications and
Experience

1

<!-- page 2 -->

projects
in
Energy Sector

2

the

Expert – Municipal
Services – Water
and
Wastewater
Sector
To support TNIDB
and the Department
in delivering PPP
projects
in
the
Municipal
Sector
with a focus on
water
and
wastewater

3

Project Analysts

bid documents
as have a sound knowledge of
c) Assist in the selection of
energy technologies.
consultants to develop the c) A sound knowledge in the
projects
field of project financial
d) Assist TNIDB/procuring entity
analysis, risk allocation,
in the bid management process
tariffs,
and
tools
for
e) Coordinate with the consultants
infrastructure development on
in developing PPP projects
PPP basis.
f) Appraise and structure the d) Proven
experience
of
project
to
enhance
its
structuring PPP projects in the
bankability.
energy sector is preferable
g) Coordinate market sounding e) Experience in procurement of
exercises for the projects
PPP
projects
in
the
h) Support TNIDB/Department in
infrastructure sector. Specific
PPP
procurement
related
experience in the energy
matters
sector would be preferable.
f) Excellent written and verbal
communication
skills in
English.
a) Review
projects/proposals a) A Master’s degree in
submitted by departments and
management, engineering or
state-owned entities involved
finance.
the preparation, development, b) At least 8 years of postand implementation of PPP
qualification relevant PPP
projects.
experience in municipal
b) Assist in the selection of
projects. Experience in the
consultants to develop the
water and wastewater sector
projects
will be preferable.
c) Assist in the preparation of bid c) A sound knowledge in the
documents
field of project financial
d) Assist TNIDB/procuring entity
analysis and tools for
in the bid management process
infrastructure development
e) Coordinate
with
the
on PPP basis.
consultants in developing PPP d) Proven
experience
of
projects
structuring PPP projects in
f) Appraise and structure the
the municipal sector
project
to
enhance
its e) Experience in procurement
bankability.
of PPP projects in the
g) Coordinate market sounding
municipal sector. Specific
exercises for the projects
experience in the water and
h) Support TNIDB/Department in
wastewater
would
be
PPP procurement related
preferable.
matters
f) Excellent written and verbal
communication skills in
English.
a) Assist the experts at TNIDB in
a) A master’s degree in
the review of projects/
management, preferably in
proposals
submitted
by
Finance.
departments.
b) At least 3 years of
b) Prepare financial models for
experience in financial
PPP projects
analysis of infrastructure

2

<!-- page 3 -->

c) Prepare TORs for the selection
of transaction advisors
d) Assist in the selection of
consultants to develop the
projects
e) Assist TNIDB/procuring entity
in the bid management process
f) Coordinate with the consultants
in developing PPP projects

c)

d)

e)

projects.
A sound knowledge in the
preparation of feasibility
studies, financial models is
essential.
Experience of structuring
PPP projects may be
desirable
Excellent written and verbal
communication skills in
English.

2. REMUNERATION:
Remuneration would be based on similar roles in other public organizations.
3. MODE OF SUBMISSION:
All applications shall be sent by email to soinfra.findpt@tn.gov.in, fininfracell@gmail.com and through
post to the undermentioned address in the prescribed format.
The Chief Executive Officer,
Tamil Nadu Infrastructure Development Board,
3rd Floor, Tower-II CMDA Building
Egmore, Chennai – 600 008

3

<!-- page 4 -->

APPLICATION FORM FOR SECTOR EXPERT/ANALYST (TNIDB)

I.

APPLICATION DETAILS

POSITION
APPLIED FOR
1.
INCLUDING JOB
CODE
2.

:

EXPECTED
:
REMUNERATION
(Mention expected consolidated monthly
remuneration in Indian Rupees)

3.

CURRENTLY
EMPLOYED

: Indicate Yes/ No _________________

4.

NOTICE PERIOD
FOR JOINING

:

II.

APPLICANT DETAILS

1.

NAME OF THE
APPLICANT
FATHER/
HUSBAND’S
NAME
DATE OF
BIRTH

2.
3.

Affix recent
passport size
photograph
which should be
signed across

(Mention notice period in months)

:
:
:

4.

NATIONALITY :

5.

GENDER

:

6.

PAN NO

:

DD/MM/YYYY

4

<!-- page 5 -->

7.

PERMANENT
ADDRESS

:
(Mention Full address with State & Pin code)

8.

9.
10.

PRESENT
ADDRESS

:

TELEPHONE
NO

:

MOBILE NO

:

(Mention Full address with State & Pin code)
(Mention Residence Number with STD Code)

Month &
Board/
Course/
Year
University/
Specialisation From To
Institution

11.

EDUCATIONAL
QUALIFICATIO
NS

:

(Mention in the order of recency)
12.
13.
14.

MEMBERSHIP
OF
:
PROFESSIONAL
ASSOCIATIONS
OTHER
:
TRAINING
COUNTRIES OF
WORK
:
EXPERIENCE

5

% Marks
obtained
/
CGPA

<!-- page 6 -->

Language

15.

LANGUAGES
KNOWN

:

6

Speaking

Reading

Writing

<!-- page 7 -->

III.

EMPLOYMENT RECORD (in order of recency)

Name of Employer

Period of Service

Designation*

From

Total Experience (in Years and Months)

To

Length of relevant
service as on
Application Date
Years
Months

Years

Months

Total Experience in the relevant area (as per Advertisement in Years and
Months)
Years
Months
* Please provide separate descriptions of activities performed for each of the previous employment,
mentioning roles & responsibilities, achievements, highlights etc.

7

<!-- page 8 -->

IV.

PROJECT EXPERIENCE

Name of Assignment
or Project:
Sector
Year
Location
Client
Employer
Main Project Features
Total Project Cost
Activities Performed
Name of Assignment
ii.
or Project:
Sector
Year
Location
Client
Employer
Main Project Features
Total Project Cost
Activities Performed

i.

:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:

(Mention all relevant projects undertaken by the Applicant. Attach
separate sheets for each additional project)
You are also requested to provide two professional references.
For each reference, please provide the following information:




Name of the reference
Current designation and organisation
Email ID and contact number of the reference.

8
