---
doc_id: "8c2edfb995fe62ae"
source_url: "https://gstchennai.gov.in/images/pdf/tenders/Tender_Coimbatore_05092024.pdf"
ministry: "Office of the Principal Chief Commissioner of GST & Central Excise Tamil Nadu & Puducherry Zone, Puducherry"
title: "Click here for Detail"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "512d01b2f823b164"
---

<!-- page 1 -->

TENDER NOTICE
Office of the Principal Commissioner of GST & Central
Excise,

Coimbatore

invites

bids

(e-tender)

from

eligible

premise Owners for providing Office accommodation for Goods
and Service Tax Appellate (GSTAT), Coimbatore on rent for
the period from 01.11.2024 to 31.10.2028. The Tender
document viz., Qualifying bid and Financial bid along with the
scope of work, terms and conditions can be downloaded from
the Official website of GEM Portal https://gem.gov.in/ BID NO.
GEM/2024/B/5364781.
The bids are to be submitted online through GEM Portal
https://gem.gov.in/
ONLY ONLINE BIDS WILL BE ACCEPTED
BID END DATE: 26.09.2024 18.00 HRS
Sd/Place: Coimbatore

C.MOHAN GOPU
ADDITIONAL COMMISSIONER

Contact:
Shri. P. Kannabiran, Superintendent (PRO) (Mobile No. 9443005115)
Shri. S.Murugesan, Superintendent (Mobile No. 99442358445)
