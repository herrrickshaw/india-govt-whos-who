---
doc_id: "607ed2eb8f0ae4da"
source_url: "https://law.py.gov.in/docs/GO.34_2025.pdf"
ministry: "Law Department, Puducherry"
title: "Repatriation of Dr. L.S. Sathiyamurthy, Secretary (Law), Puducherry [G.O. dated 05.06.2025]"
date: ""
pages: 1
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "4454c55e5e9271fd"
---

<!-- page 1 -->

GOVERNMENT OF PUDUCHERRY
ABSTRACT
Public Services - Repatriation of Dr. ட,5, Sathiyamurthy, Secretary (Law), Puducherry-
Orders - Issued.
DEPARTMENT OF PERSONNEL AND ADMINISTRATIVE REFORMS
(PERSONNEL WING)
ப வ
G.O.Ms. No.34 Puducherry, dt: 05.06.2025
READ: D.O. Lr. No.18/2025-Con.B2 dated 23.05.2025 of the
Registrar General, High Court, Madras.
-00000-
ORDER:

In pursuance of the communication read above, the Lieutenant Governor,
Puducherry is pleased to repatriate Dr.L.S. Sathiyamurthy, District Judge of Tamil Nadu
State Judicial Service, presently on deputation as Secretary (Law), Government of
Puducherry, to his parent service i.e., Tamil Nadu State Judicial Service, with effect from
the afternoon of 06.06.2025.

/ By Order of the Lieutenant Governor/
Dr. SHARAT CHAUHAN
CHIEF SECRETARY TO GOVERNMENT

To -

Dr.L.S. Sathiyamurthy, Secretary (Law), Puducherry

Copy to: :

1. The Registrar General, High Court of Madras, Chennai.

2. The Commissioner-cum-Secretaries/ Secretaries to Govt, Puducherry.

3. The Chief Judge, Puducherry.

4, The Secretary to Lieutenant Governor, Puducherry.

5. The OSD to Chief Minister / Home Minister / PWD Minister, Puducherry.

6. The PS to Chief Minister/Speaker / all Ministers/ P.A. to Dy. Speaker, Puducherry.

7. All Secretariat Departments / Heads of Departments.

8. The Joint Secretary to Govt. (Estt.), Chief Secretariat, Puducherry.

9. The Under Secretary (Law), Chief Secretariat, Puducherry.
10. The Collector, Puducherry/ Karaikal; Regional Administrator, Mahe/ Yanam.
11. The Principal Accountant General (Civil Audit), Tamil Nadu & Pdy, Chennai-18.
12. The Dy. Accountant General, (Civil Audit) Pondy Branch, DAT Complex, Puducherry.
13. The Director of Accounts & Treasuries, Puducherry.
14, The Director of Information & Publicity, Puducherry.
15. The Private Secretary to Chief Secretary, Puducherry. yon
16. Stock file / G.O / C.R.B. wc ஞீ

io *
eo
(V. JAISANKAR)
UNDER SECRETARY TO GOVERNMENT
