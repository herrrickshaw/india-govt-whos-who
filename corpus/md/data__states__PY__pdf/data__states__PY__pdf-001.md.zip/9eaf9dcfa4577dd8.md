---
doc_id: "9eaf9dcfa4577dd8"
source_url: "https://dit.py.gov.in/sites/default/files/gigw3.pdf"
ministry: "Information Technology Department, Puducherry"
title: "Government Websites - Guidelines"
date: ""
pages: 121
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e964e98691de8762"
---

<!-- page 1 -->

3.0
GUIDELINES FOR INDIAN GOVERNMENT WEBSITES AND APPS

<!-- page 2 -->

3.0

<!-- page 3 -->

01

Introduction

7

02

Scope and Objective

12

2.1 : Conformity to guidelines

CONTENTS

2.2 : How to use GIGW

03

New features
3.1 : Structure
3.2 : Quality
3.3 : Accessibility
3.4 : Cybersecurity
3.5 : Lifecycle management
3.6 : Risk factors and their mitigation

04

Focus Areas
4.1 : Quality

4.2 : Accessibility
4.3 : Cybersecurity
4.4 : Lifecycle management

05

Guidelines
5.1 : Quality: Guidelines and attributes
5.2 : Accessibility: Guidelines and attributes
5.3 : Cybersecurity: Guidelines and attributes
5.4: Lifecycle management: Guidelines and attributes

Annexure I
Committee composition

Annexure II
Matrix for checking conformity

Annexure III
Important terms

Annexure IV
Role of Web Information Manager

13
13
16
17
18
19
20
21
24
25
27
29
32
47
80
92
99
100
116
119

<!-- page 4 -->

<!-- page 5 -->

GUIDELINES FOR INDIAN GOVERNMENT
WEBSITES AND APPS



Introduction

<!-- page 6 -->

<!-- page 7 -->

1. Introduction

Introduction

1.0

I

n recent years, digital technologies have
increasingly contributed to economic
growth and citizen empowerment.
These technologies have become
ubiquitous in everyday life and enable
people to access various services from the
comfort of their homes. Government has
established web presence through multiple
websites, web portals, web applications and
mobile apps that offer information and services
to the public. However, inconsistency in
conventions, layout standards, navigation
strategies and technologies adopted can
reduce the effectiveness of websites/apps.
In this context, the National Informatics Centre

(NIC) formulated the Guidelines for Indian
Government Websites (GIGW) in the year 2009.
GIGW aims to ensure quality and accessibility of
government guidelines, by offering guidance
on desirable practices covering the entire
lifecycle of websites, web portals and web
applications, right from conceptualisation and
design to their development, maintenance and
management.
The
Department
of
Administrative Reforms and Public Grievances
made the same a part of the Central Secretariat
Manual of Office Procedure.
The second version of GIGW (GIGW 2.0) was
developed in 2019, taking into account
feedback from and consultations with industry,
7

<!-- page 8 -->

1. Introduction

society and government organisations. GIGW
2.0 took note of the standards evolved by
international bodies like the world-wide web
consortium (W3C) and advancements in
technology. It also included guidance on mobile
apps.
This version is the third version of GIGW (GIGW
3.0). While the earlier versions were formulated
in-house with external inputs, GIGW 3.0 has
been formulated jointly with Standardisation
Testing and Quality Certification (STQC)
Directorate of the Ministry of Electronics and
Information Technology and Indian Computer
Emergency Response Team (CERT-In), so that
the experience of conformity with GIGW
gathered by the STQC Directorate auditors and
the cybersecurity experience and knowledge of
CERT-In also inform the GIGW. As in earlier
versions, GIGW 3.0 too has also been formulated
in association with industry and experts.
The key thrust of GIGW 3.0 is on offering specific
guidance to government organisations on how
to improve the user interface and user
experience (UI and UX), by incorporating
features such as intuitive page loading (using AI
and analytics) based on user journey and user
profile,
using
state-of-the-art
content
management system (CMS), user-centric
information architecture (IA), centralised
monitoring dashboard to identify and provide
alerts on non-conformity and technical
enablement of all content creators and
publishers.
GIGW 3.0 also significantly enhances the
guidance on the accessibility and usability of
mobile apps, especially by offering specific

guidance to government organisations on how
to leverage public digital infrastructure devised
for whole-of-government delivery of services,
benefits and information. These cover aspects
such as API level integration for use of
integration with social media, India Portal,
DigiLocker, Aadhaar-based identity, single
sign-on, data sharing in open formats on the
government’s data platform, government’s
scheme discovery platform, government’s
citizen engagement platform MyGov, AI-based
Indian language translation tools, seamless
content/data access across web-based
solutions of government organisations. GIGW
3.0 offers upgraded guidelines on accessibility
of websites and apps, with a view to make
access to cyberspace more inclusive. In view of
incorporation of comprehensive guidance in
this version on apps as well (in addition to
websites), this version is titled “Guidelines for
Indian Government Websites and Apps”.
However, since the acronym GIGW gained wide
currency, the acronym has been retained, with
the letter “W” being signifying “Websites and
Apps”.
A chapter on cybersecurity, formulated by
CERT-In, has also been incorporated so that
GIGW can serve as a single point of reference on
all the relevant aspects — quality, accessibility
and security — relating to websites, web
portals, web applications and mobile apps.
Since cybersecurity requirements undergo
continuous evolution in light of emerging
threat
scenarios,
threat
vectors
and
technologies, CERT-In continuously issues
updated guidance and advisories to address the

8

<!-- page 9 -->

1. Introduction

same. Such guidance and advisories issued by
CERT-In from time to time should be treated as
updates to the guidance contained in the
chapter on cybersecurity and any assessments
or audit carried out with reference to GIGW 3.0
should also be cognizant of the same. Further,
while government organisations may continue
to establish conformity with GIGW 3.0 by
obtaining Certified Quality Website (CQW)
certification from the STQC Directorate, the
certification of cybersecurity aspects by STQC
may be done on the basis of the “safe to host”
certificate issued by the cybersecurity auditors
empanelled by CERT-In/STQC or the auditors of
STQC or NIC.
To make the guidelines more readily usable,
which entity/person has a role in implementing
a particular guideline has been identified in
every guideline. Thus, each guideline specifies
whether the same is to be acted upon by the
government organisation concerned or the
developer or the evaluators.
The effectiveness of GIGW 3.0 in enhancing ease
of living through various web-based initiatives
of the government would depend on their
effective implementation in letter and spirit by

all government organisations and their
implementation and evaluation partners.
Government organisations are expected to
carefully assess their existing websites, web
portals, web applications and mobile apps
against GIGW 3.0, identify areas requiring
improvement, draw up time bound
implementation plans to achieve conformity
with GIGW 3.0 and obtain CQW certification
from the STQC Directorate. Similarly, websites,
web portals, web applications and mobile apps
that are at the design or implementation stage
may also be reviewed to ensure that their
design, architecture, development and scope of
audit conform to GIGW 3.0 and requisite
approvals, resources etc. are tied up to ensure
this.
While GIGW embodies general guidance for
government websites, web portals, web
applications and mobile apps, particular
website/app use cases may require adoption of
higher norms and specific technologies.
Government organisations may keep this in
mind while formulating their design,
architecture and scope and may consult NIC in
case they desire technical advice in the matter.

9

<!-- page 10 -->

GUIDELINES FOR INDIAN GOVERNMENT
WEBSITES AND APPS



Scope
and

objective

<!-- page 11 -->

2 Scope and objective
2.1 Conformity to guidelines
2.2 How to use GIGW

<!-- page 12 -->

2. Scope and objective

Scope and objective

T
Central

his

document

2.0
government solutions in the Indian web space.

recommends

policies and guidelines for Indian
Government

websites

These guidelines address common issues and

and

Applications at any organisational

practical

level

and

Government

Governments

challenges

that

government

belonging

to

both

organisations face during development and

as

as

State

management of their websites/apps. The

well

(including

guidelines

district

aim

to

organisations

making

websites/apps

websites/apps conform to a consistently high

user-centric, more user-friendly and secure.

standard. This is expected to enhance the trust

Conformity with these guidelines will ensure a

level

high degree of consistency and uniformity in

government

the content coverage, presentation security

services online.

government

and accessibility and promote excellence in

12

of

the

ensuring

government

administrations and local governments) for
Indian

in

assist

citizens

information

while
and

that

their

accessing
availing

of

<!-- page 13 -->

2. Scope and objective

Conformity to guidelines

2.1

These guidelines have been framed with the objective to make the government websites/apps
conform to the essential prerequisites of the UUU trilogy of usability, user-centricity and universal
accessibility.
These guidelines are based on international standards, including ISO 23026, W3C’s Web Content
Accessibility Guidelines (WCAG 2.1) Rights of Persons with Disabilities Act, 2016, as well as the
Information Technology Act, 2000. Further, the long-standing experience of the authors in the
design, development and management of government websites/apps as well as their knowledge of
the ground realities and challenges faced by government organisations in developing and
managing their websites/apps, have helped signiﬁcantly in drafting these guidelines.
These guidelines also form the basis for obtaining the Website Quality Certiﬁcation from the STQC
Directorate.
Details
of
the
certiﬁcation
https://www.stqc.gov.in/website-quality-certiﬁcation-0.

scheme

are

available

at

These guidelines are being circulated amongst all Indian government organisations at all levels
(Central, State and district/local). These should be followed and implemented on priority so that
the overall aim of making all Indian government websites/apps citizen-focused and user-friendly
may be realised.

How to use GIGW 3.0

2.2

Government organisations are expected to read, understand and implement these guidelines on all
of their web-based initiatives. In other words, all the websites/apps owned by government
organisations must comply with these guidelines. It is recommended that browser-based intranet
applications should also follow these guidelines. Depending upon their speciﬁc requirements,
government organisations may draw up short-term and long-term timebound implementation
plans for achieving conformity with these guidelines.

13

<!-- page 14 -->

GUIDELINES FOR INDIAN GOVERNMENT
WEBSITES AND APPS



New
features
of GIGW 3.0

<!-- page 15 -->

3 New features of GIGW 3.0
3.1

Structure

3.2 Quality
3.3 Accessibility
3.4 Cybersecurity
3.5 Lifecycle management
3.6 Risk factors and their mitigation

<!-- page 16 -->

3. New features of GIGW 3.0

T

he new version of the guidelines has several enhancements to make it more user
centric, accessible, secure and at par with the global best practices and latest
technological benchmarks. This version was reorganised to ease adoption and
implementation and ensure wider conformity with GIGW. The following major
enhancements have been included in the current version.

Structure

3.1

The new version of the guidelines is structured so as to reduce ambiguity and provide clarity on the
roles and responsibilities of the implementers. The guidelines are structured under the following
heads:
(a) Statement: Requirement or checkpoint to

respective WIM nominated by the organisation.

meet the particular guideline.

(d) Developer action: Speciﬁc tasks and

(b) Beneﬁts: Positive outcomes achieved by

actions a developer is responsible for in order

following the requirements, such as improving

to comply with the guidelines and ensure the

user experience, accessibility, security and

website/app meets the desired standards of

trust-building with citizens.

quality, usability and effectiveness.

(c) Government organisation action: Actions

(e) Evaluator action: Refers to testing of the

pertaining

website/app manually or with automated tools

to

the

owner

government

to verify conformity with this checkpoint.

organisation. These will be undertaken by the

16

<!-- page 17 -->

3. New features of GIGW 3.0

Quality

3.2

T

he key thrust of GIGW 3.0 is on
enhancing user interface and user
experience (UI and UX) of
websites/apps
and
the
implementation of user-centric
information architecture (IA) to ease the user
journey and provide content as per the user
profile. To ensure the quality of content
throughout the lifecycle of the website, GIGW
guides on the provisioning of a centralised
monitoring dashboard to identify the issues and
provide alerts on non-conformity. Content

creators must also be supported with the right
tools and technologies for accessible content
creation.
GIGW 3.0 stresses on API level integration with
platforms like India Portal, DigiLocker,
Aadhaar-based identity, single sign-on, data
and citizen engagement platforms, language
translation tools to enable seamless content
and data flow among the different web
initiatives of government organisations. Social
media integration also needs to be ensured.

17

<!-- page 18 -->

3. New features of GIGW 3.0

Accessibility

A

3.3

ccessibility guidelines for web

disabilities, users with low vision and users with

content have been formulated by

disabilities on mobile devices.

W3C and are known as the web
content accessibility guidelines

GIGW 3.0 has been upgraded to include these

(WCAG). GIGW 2.0 was compliant

additional

requirements

to

ensure

that

with version 2.0 of WCAG, however in the

websites/ apps can be used by the widest

recent past WCAG has been upgraded to

possible audience. The current version ensures

version 2.1 which inherits its requirement from

conformity with Level AA of WCAG 2.1. In all 17

WCAG 2.0 with additional guidelines to

new success criteria have been added to the

improve accessibility guidance for three major

new version.

groups: users with cognitive or learning

18

<!-- page 19 -->

3. New features of GIGW 3.0

Cybersecurity

3.4

A

chapter
on
cybersecurity,
formulated by CERT-In, has also
been incorporated which relates
to websites, web portals, web
applications and mobile apps.
The
chapter
focuses
on
protecting web resources from unauthorised
use, access, changes, destruction, or
disruption. It also guides on the prevention of
leakage of sensitive information like passwords,
email addresses and credit card details, which
cause both personal embarrassment and
ﬁnancial risks.
It deals with all aspects of security starting
from design, coding and implementation to
testing and deployment, which prevent
malfunctioning, phishing, cyber-crimes or
cyberattacks to avoid data loss of the

organisations or users.
It is based on the best industry security
practices and guidelines such as ISO 27001, the
Application Security Veriﬁcation Standard
(ASVS) issued by Open Web Application
Security Project (OWASP), OWASP Top 10
vulnerabilities and the Center for Internet
Security (CIS) benchmarks as per the prevailing
security policy.
This chapter must be read in conjunction with
the guidance and advisories issued by CERT-In
from time to time, which should be treated as
updates to the guidance contained in the
chapter.
Government organisations must continue to
obtain a “safe to host” certiﬁcate issued by the
cybersecurity
auditors
empanelled
by
CERT-In/STQC or the auditors of STQC or NIC.

19

<!-- page 20 -->

3. New features of GIGW 3.0

Lifecycle management

T

3.5

he chapter on lifecycle management deals with the policies, processes and plans that
the department has to put in place to guide the website management team in
maintain the quality, accessibility security of the website throughout its lifecycle. It
also stresses on the need for dedicated Web information Manager who is a senior
ofﬁcial from the department to head the website management team.

20

<!-- page 21 -->

3. New features of GIGW 3.0

Risk factors and their mitigations

R

isk

mitigation

is

important

criteria

formulation

of

one

of

the

behind

the

3.6

presented in the conformity matrix.

standard/

Therefore, while the description of each

guideline. The new version of the

guideline informs the users about the beneﬁts

guidelines outlines the risk factors

of conformance the conformity matrix will

associated with non-conformity with each

make the users aware of the risk involved in

section of these guidelines. They have also

case, they fail to meet the guideline.

been

mapped

with

each

any

guideline

and

21

<!-- page 22 -->

GUIDELINES FOR INDIAN GOVERNMENT
WEBSITES AND APPS



Focus
areas

<!-- page 23 -->

4

Focus areas
4.1

Quality

4.2 Accessibility
4.3 Cybersecurity
4.4 Lifecycle management

<!-- page 24 -->

4. Focus areas

Quality

4.1

Q

uality criteria for websites/apps are essential to ensure a
website/app is trustworthy, reliable and engaging for
users. A website/app should be easy to use, accessible to
all users, load quickly, have high-quality content, be
secure, optimised for mobile devices and have a visually appealing
design. Meeting these criteria can help ensure a website's success
and make it stand out from the millions of websites/apps available
on the internet. By prioritising these criteria, owners can create a
high-quality website/app that provides value to its users.

Risks associated with
4.1.1
non-conformity with quality guidelines:
Q1. Websites/apps can have inconsistent and outdated content on a website/app if the responsibility and ownership of the website/app is not assigned to a person or team.
Q2. People may not be able to get the information about the website/app.

24

<!-- page 25 -->

4. Focus areas

Q3. Without correct copyright policy, any information on the website/app may be copied, reproduced, republished, uploaded, posted, transmitted, or distributed without any consent.
Q4. The overall quality of a website’s content can be degraded if the authenticity and relevance
of the ‘linked’ information is not deﬁned through hyperlinking policy.
Q5. Without terms and conditions on websites/apps it is difﬁcult to uphold and maintain the trust
imposed on them by the users to the sites, the government websites/apps should not out rightly
‘disclaim’ the content of another government website/app.
Q6. If Content is not selected keeping the audience in mind, people from diverse professional,
educational and demographic backgrounds cannot easily comprehend the same.
Q7. People cannot get the right information from the website/app if Content is not up to date,
incomplete, inconsistent or scattered.
Q8. Users cannot identify an authenticated government website.
Q9. Websites/apps with poor design methodology may not be accessible with slow internet
connectivity.
Q10. Without feedback and help sections, users will not be able to participate in the improvement
of website/app quality and the government organisation will not be able to get the information
regarding problems faced by users.

Accessibility

4.2

Web accessibility means that people with
disabilities can also perceive, understand,
navigate and interact with the Web and that
they

can

contribute

to

the

Web.

It

encompasses all disabilities that affect access
to the Web, including visual, auditory, physical,
speech, cognitive and neurological disabilities.
The website/app should be designed and
developed in such a way that they are
accessible by all people, whatever may be their
hardware, software, language, culture, location,
or physical or mental ability.

25

<!-- page 26 -->

4. Focus areas

Legal provisions

4.2.1

The United Nations General Assembly adopted its Convention on the Rights of Persons with
Disabilities on the 13th day of December 2006. India is a signatory to the Convention and has
ratiﬁed the Convention on the 1st day of October 2007. To implement the Convention, India has
enacted the Rights of Persons with Disabilities Act, 2016 on 27th December, 2016. With regard to
ICT, one of the important provisions in the act is that all contents available in audio, print and
electronic media must be in accessible format.

International Guidelines and Standards
4.2.2
(WCAG)
W3C’s Web Content Accessibility Guidelines (WCAG) covers a wide range of recommendations for
making Web content accessible. Implementing these guidelines will make content accessible to
persons with disabilities. Details are available at https://www.w3.org/TR/WCAG21/.
GIGW has been developed in accordance with level AA of WCAG 2.1 which are the latest guidelines
on accessibility.

Risks associated with non-conformity
4.2.3
with accessibility guidelines
A1. Visually impaired people cannot access the content.
A2. People with epileptic may get seizures if the website/app has content which blink very fast.
A3. Hearing/Auditory impaired people cannot access the content.
A4. People with cognitive Disability cannot access the time dependent function/content which
does not have pause/extend/back/ forward options.
A5. People with Locomotor/Physical Disability cannot access the whole content present on the
website.

26

<!-- page 27 -->

4. Focus areas

A6. If the content is not robust enough to be interpreted reliably by a wide variety of user agents,
including assistive technologies, the content becomes inaccessible to large audiences suffering
from different impairments.
A7. People who do not understand English language cannot access website/app content and
services.
A8. The government organisation concerned can face legal actions as per national and
international laws if the content of the website/app is not accessible.
A9. Labels or instructions are not provided when content requires user input, which jeopardises
the security or purpose of the content.

Cybersecurity

4.3

Cybersecurity is the activity of protecting

homepages.

websites/apps from unauthorised use, access,

addresses and credit card details have been

changes,

leaked into the public domain exposing

destruction,

or

disruption.

Millions

even confusing) topic in an ever-evolving

embarrassment

landscape. GIGW provides a clear framework

purpose of website/app security is to prevent

for website/app owners seeking to mitigate risk

such risks.

and apply security principles to their web

Website/app security requires vigilance in all

properties.

aspects starting from requirements through

It is important to keep in mind that security is

design and implementation to testing and

never a set-it-and-forge-it solution but is a

deployment. Organisations should implement

continuous process that requires constant

appropriate security analysis, defences and

assessment

countermeasures

reduce

the

overall

risk.

for

both

email

website/app

and

to

passwords,

website/app security can be a complex (or

to

users

of

ﬁnancial

personal
risks.

protection

of

The

a

become

website/app against malfunctioning, phishing,

unavailable due to denial-of-service attacks or

cyber-crimes, or cyberattacks to avoid data

display

loss of the organisations or customers.

Sometimes

websites/apps

modiﬁed

information

on

their

27

<!-- page 28 -->

4. Focus areas

Risks associated with non-conformity
with security guidelines
4.3.1
S1. Malicious users can deface the website.
S2. Any harmful actor may get access to conﬁdential information.
S3. The availability of the website/app can be hampered.
S4. The malicious user may change/modify the content on the website.
S5. Security failures typically lead to unauthorised information disclosure, modiﬁcation, or
destruction of all data or performing a business function outside the user's limits.
S6. A ﬁle upload ﬂaw allows an attacker to retrieve the password database. Security of web
applications determine the protection needs of data in transit and at rest. Attackers can steal such
information for example, passwords, credit card numbers, health records, personal information and
business secrets require extra protection, mainly if that data falls under privacy laws, Personal data
protection bill etc.
S7. An attacker monitors network trafﬁc (e.g., at an insecure wireless network), downgrades
connections from HTTPS to HTTP, intercepts requests and steals the user's session cookie. The
attacker then replays this cookie and hijacks the user's (authenticated) session, accessing or
modifying the user's private data. Instead of the above they could alter all transported data, e.g., the
recipient of a money transfer.
S8. Almost any source of data can be an injection vector, environment variables, parameters,
external and internal web services and all types of users. Injection ﬂaws occur when an attacker can
send hostile data to an interpreter.
S9. Attackers have to gain access to only a few accounts, or just one admin account to
compromise the system. Depending on the domain of the application, this may allow money
laundering, social security fraud and identity theft, or disclose legally protected highly sensitive
information.
S10. Security ﬂaws can be used to extract data, execute a remote request from the server, scan
internal systems, perform a denial-of-service attack, as well as execute other attacks. The business
impact depends on the protection needs of all affected applications and data.
S11. Attackers acting as users or administrators, or users using privileged functions, can create,
access, update or delete every record.
S12. Security misconﬁguration frequently gives attackers unauthorised access to some system
data or functionality. Occasionally, such ﬂaws result in a complete system compromise.

28

<!-- page 29 -->

4. Focus areas

S13. The impact of XSS is moderate for reﬂected and DOM XSS and severe for stored XSS, with
remote code execution on the victim’s browser, such as stealing credentials, sessions, or delivering
malware to the victim.
S14. While some known vulnerabilities lead to only minor impacts, some of the largest breaches to
date have relied on exploiting known vulnerabilities in components.
S15. Most successful attacks start with vulnerability probing. Allowing such probes to continue can
raise the likelihood of a successful exploit to nearly 100%.

Lifecycle management

4.4

Maintaining a website/app is just as important

properly. This involves updating website/app

as developing it because a website/app is a

content, monitoring performance, ensuring

dynamic entity that requires regular updates

security, ﬁxing bugs and errors and optimising

and monitoring to remain relevant, functional

the

and secure. Without proper maintenance, a

Establishing

policies

website/app

website/app

maintenance

can

become

vulnerable

to

website/app

for

search

and

engines.

procedures
is

for

important,

security breaches, performance issues and

including a change management process,

content that is outdated or irrelevant, which

backup and disaster recovery plans, security

can negatively impact the user experience and

policies and a content management plan.

drive

potential

visitors.

Regular

Regularly

can

prevent

security

performance, user engagement and search

breaches, ensure functionality, keep content

engine optimization is crucial to ensure that

up-to-date and optimise the website/app for

the website/app is meeting its objectives and

search engines. Therefore, website/app life

to identify areas for improvement.

cycle

ongoing

The risks already identiﬁed under ‘Quality’ are

maintenance, is crucial for the success and

also associated with the non-conformity of the

longevity of a website.

Lifecycle Management guidelines.

away

maintenance

After

help

management,

launching

including

a

maintenance

is

website/app

up-to-date

website,

essential

to
and

ongoing
keep

the

functioning

29

monitoring

the

website's

<!-- page 30 -->



Guidelines

<!-- page 31 -->

5 Guidelines
5.1

Quality: Guidelines and attributes

5.2 Accessibility: Guidelines and attributes
5.3 Cybersecurity: Guidelines and attributes
5.4 Lifecycle management: Guidelines and attributes

<!-- page 32 -->

5. Guidelines

Quality

5.1

Statement: Association to government is demonstrated by the use
of emblem/logo in proper ratio and colour, prominently displayed
on the homepage of the website or homescreen of the app. 5.1.1
Beneﬁt: Reassures visitors that the government website/app is authentic and trustworthy.
Moreover, the government organisation’s brand identity is reinforced.
Government organisation action: Government organisations must select proper visual identity
elements like emblems or logos to highlight government ownership of the website/app. The State
emblem of India must be displayed on the homepages of the websites and homescreens of the
apps of Central Government Ministries/Departments. State Governments should display their
Emblems and public Sector organisations and autonomous bodies should display their ofﬁcial logo
on the homepage of the website or homescreen of the app to reinforce their identity
Developer action: Visual Identity elements (logos and emblem) must prominently stand out on the
page, in a proper ratio and colour. Developers must ensure that all logo images are accompanied by
proper alternate text so that the screen reader users may be informed of the same. The usage of
the State Emblem of India must comply with the provisions of the State Emblem of India
(Prohibition of Improper Use) Act, 2005.
Evaluator action: The evaluator shall manually test the website/app for verifying conformity with
this.

32

<!-- page 33 -->

5. Guidelines

Statement: Ownership information is displayed on the
homepage/homescreen and on all important entry
pages/screens of the website/app and each subsequent page/
screen is a standalone entity in terms of ownership,
navigation and context of content.
5.1.2
Beneﬁt: Helps to build trust in the visitors and reinforces the government organisation’s branding.
Also, search engines use the ownership information to verify the legitimacy of the websites/apps
and accord higher ranks in search results.
Government organisation action: Provide complete ownership information for publishing on the
website
Developer action: Ensure display of ownership information, either in the header or footer, on the
homepage/homescreen and all-important entry pages/screens of the website/app.
Evaluator action: The evaluator shall manually test the website/app for verifying conformity with
this.

Statement: Source of all documents, not owned by the dept.
that have been reproduced in part or full, is mentioned.
5.1.3
Beneﬁt: Audiences can rely upon the credibility of authentic information being published by the
government organisation. Additionally, giving the credit to the authoring organisation helps
establish an environment of respect for intellectual property of other organisations and
discourages plagiarism.
Government organisation action: If any published government document/report is being
reproduced on the government organisation’s website/app, whether as excerpts or in full, the
organisation must cite the source of the same (complete title of the document/report, along with
the name of the owner organisation and the year of publication).
Developer action: Ensure provision of appropriate data input ﬁelds in the CMS to input the source
(owner organisation of each published document/report and the year of publication).
Evaluator action: The evaluator shall manually test the website/app for verifying conformity with
this.

33

<!-- page 34 -->

5. Guidelines

Statement: Due permissions have been obtained for
publishing any content protected by copyright.

5.1.4

Beneﬁt: Publishing copyrighted information after obtaining due permission protects the
government organisation from legal issues, establishes an environment of respect for information
copyrighted by others in addition to discouraging plagiarism.
Government organisation action: The government organisation must follow proper procedures to
obtain the permission, prior to publishing any information that is copyrighted by any third party.
Developer action: None.
Evaluator action: The evaluator shall check the implementation of copyright policy in backend
audit.

Statement: Homepage/homescreen of the website/app
displays the last updated/ reviewed date.

5.1.5

Beneﬁt: Providing information about the last updated/reviewed date helps visitors to build trust
that the government organisation is providing updated information. Also, search engines accord a
higher ranking to web sites that publish updated content, so they will automatically appear
amongst the top-ranking sites on search results.
Government organisation action: Publish regular and updated content for publishing on the
website/app and review the content of the website/app as per the content review policy.
Developer action: Ensure publishing, on the homepage/homescreen and every important entry
page/screen, of the date on which the information was posted on the website/app, or the date on
which the content was last reviewed and/or modiﬁed.
Evaluator action: The evaluator shall manually test the
website/app for verifying conformity with this.

34

<!-- page 35 -->

5. Guidelines

Statement: Complete information including title, size, format and
usage instructions is provided for all downloadable
material.
5.1.6
Beneﬁt: Downloading material from the Internet can be an expensive and time-consuming
exercise. Therefore, government websites/apps must prov ide Information that will help visitors
determine whether they want to access downloadable material. Providing all required information
about downloadable material helps improve clarity & accessibility, especially for those using
assistive technologies.
Government organisation action: Provide all necessary content details to the content team. The
total size of the ﬁle should be kept to a minimum to ensure acceptable download times for all users,
especially those that do not have high-speed, reliable Internet connections. Prior to making
downloadable material available for visitors, government organisations should check for viruses
and malware.
Developer action: Ensure that there is a mechanism in the CMS to input the following information
about the downloadable material:
(a) Self-explanatory title of the document/ﬁle;
(b) Download and use instructions (install, open, view); and
(c) File format and ﬁle size.
Evaluator action: The evaluator shall manually test the website/app for verifying conformity with
this.

Statement: In respect of each circular, notiﬁcation, document,
form, scheme, service and recruitment notice, the following
should be clearly listed on the website/app:
5.1.7
(a) Complete title;
(b) Language (if other than English);
(c) Purpose/procedure to apply (as applicable); and
(d) Validity (where applicable).
Beneﬁt: Details such as the correct title, language, validity, purpose, procedures would lead to an
accurate search output for information on that scheme/service/recruitment notice etc and it
would be easy for the users to locate & use these documents, schemes, services etc.

35

<!-- page 36 -->

5. Guidelines

Government organisation action: The attributes as speciﬁed in the guideline must be provided
with each Circular, Notiﬁcation, Document, Form, Scheme, Service and Recruitment notice
Developer action: Ensure provision of all ﬁelds necessary for publishing of all information about
documents, schemes, services, along with the necessary archival procedures to archive the
information once the validity expires.
Evaluator action: The evaluator shall manually test the website/app for verifying conformity with
this.

Statement: All outdated Announcements, Tenders, Recruitment
notices, News and Press Releases are removed from
the website/app and/or placed into the archives
as per the archival policy
5.1.8
Beneﬁt: Outdated and irrelevant content must not be served to the visitors and there should be a
proper archival section to access the outdated content.
Government organisation action: The government organisation must ensure that the expiry date
is provided for all time sensitive content
Developer action: Ensure that the mechanism is in place to automatically remove the content
after the expiry date or move it to the archives as per the approved Archival Policy.
Evaluator action: The evaluator shall manually test the website/app for verifying conformity with
this.

36

<!-- page 37 -->

5. Guidelines

Statement: All information about the government organisation
which is useful to users is present in the ‘About us’ section and a
mechanism is in place to keep the information up to date.
5.1.9
Beneﬁt: Helps the visitor access all information about the government organisation, useful for the
citizen.
Government organisation action: The government organisation must prepare the content
describing itself for the About us section.
Developer action: Ensure the website/app has an About us page.
Evaluator action: The evaluator shall manually test the website/app for verifying the content as
required by this checkpoint is present on the website. The evaluator shall verify the conformity to
the mechanism required in the checkpoint through backend audit.

Statement: Website/app has a ‘Contact us’ page providing
complete contact details of important functionaries in the
government organisation and this is linked from the homepage/
homescreen and all relevant places on the website/app.
5.1.10
Beneﬁt: Enables users to contact any government organisation or entity to ask questions, get
information, seek clariﬁcations and resolve problems.
Government organisation action: Provide complete contact information on the Contact us or
Who’s who sections or on the Directory page, including the telephone numbers/fax numbers,
postal address and email addresses, along with the timings, if any, earmarked for personal/public
dealing.
Developer action: Ensure that the CMS has the provision to publish
the contact details of citizen-facing functionaries in the government
organisation.
Evaluator action: The evaluator shall manually test the
website/app for verifying conformity with this.

37

<!-- page 38 -->

5. Guidelines

Statement: Feedback is collected through online forms and a
mechanism is in place to ensure timely response to
feedback/queries received through the website.
5.1.11
Beneﬁt: Helps the visitors to express their ideas, satisfaction levels, suggestions etc. that can be
valuable inputs for enhancement of future versions of the website. Additionally, government
organisations can learn meaningful insights about the usage pattern of the website, which can
further help to focus on near and far term enhancements.
Government organisation action: Ensure feedback received is processed on a regular basis.
Developer action: Ensure providing the mechanism to collect structured feedback from visitors
using Forms. Also, ensure responding to the feedback explaining how it will be processed.
Evaluator action: The evaluator shall manually test the website/app for verifying that the
feedbacks are collected through online forms at the website. The evaluator shall verify the
conformity to the mechanism required in the checkpoint through backend audit.

Statement: Website/app provides a prominent link to the
‘National Portal’ from the homepage and webpages
belonging to the ‘National Portal’ load in the new browser
window.

5.1.12

Beneﬁt: india.gov.in, the National Portal of India (NPI) is a single window source for access to all
information and services being provided by the various constituents of the Indian Government to
its citizens and other stakeholders. Linking to the NPI will help visitors ﬁnd information or services
they could not ﬁnd easily on a government organisation website.
Government organisation action: The government organisation website/app must provide a
prominent link to the National Portal from the homepage and other important pages of citizen’s
interest.
Developer action: Ensure that the government website/app provides a prominent link to the
National Portal from the homepage and other important pages of citizen’s interest. Also, the
hyperlinked pages belonging to the National Portal must load into a newly opened browser window
of visitors.
Evaluator action: The evaluator shall manually test the website/app for verifying conformity to this
checkpoint.

38

<!-- page 39 -->

5. Guidelines

Statement: The website has been tested on multiple browsers.
Hindi/Regional language fonts have been tested on popular
browsers for any inconsistency (loss of layout).
5.1.13
Beneﬁt: Visitors can easily read content and interact with the website in their native language, thus
improving the website’s accessibility and reach.
Government organisation action: Government organisations must ensure the accuracy of the
translated content.
Developer action: Ensure use of Unicode characters when using Hindi/Regional language fonts &
also, testing of the website on multiple browsers and versions of browsers, operating systems,
connection speeds and screen resolutions to ensure access by all and no loss of layout.
Evaluator action: The evaluator shall manually test the website on different browsers for verifying
conformity to this checkpoint.

Statement: The website/app has a readily available Help
section linked from all pages of the website.

5.1.14

Beneﬁt: Allows a pleasant experience while browsing the website.
Government organisation action: None
Developer action: Must include Help content which allows for an easy and convenient navigation
for the visitor to the website/app (e.g., online help, how to open ﬁles of certain formats, how to
access audio/video on the portal, kinds of plug-ins required etc.). Further, the content which
clariﬁes the purpose of the website/app as well as its policies for the visitors should also be
included in this category. Help should be linked from all pages of the website/app and should be
displayed in a consistent location across the website.
Evaluator action: The evaluator shall manually test the website/app for verifying conformity to this
checkpoint.

39

<!-- page 40 -->

5. Guidelines

Statement: Website uses Cascading Style Sheets (CSS) to
control layouts/styles and incorporates responsive design features
to ensure that the interface displays well on
different screen sizes.
5.1.15
Beneﬁt: For the visitors, a consistent look and feel of the website’s User Interface (UI)and its
availability on all devices and screen sizes is important. For the government organisation and
developers, CSS offers ease of making global changes to the layout and design in one place instead
of having to do so on individual pages. Different presentations of the content (for example a large
text alternative for visually impaired users) can be achieved using different style sheets. The
document code is also reduced in size and complexity since it does not need to contain any
presentational markup.
Government organisation action: None.
Developer action: Use CSS for controlling content layout and presentation, in addition to offering
a responsive interface for visitors. Also, ensure testing on different devices.
Evaluator action: The evaluator shall test the website by using browser extension/ tool for verifying
conformity to this checkpoint.

40

<!-- page 41 -->

5. Guidelines

Statement: Website is readable even when style sheets are
switched off or not loaded.

5.1.16

Beneﬁt: Helps provide readable content not only for visually challenged users who may be using
screen readers, but also in some instances where the style sheets may not load swiftly or load at
all due to reasons such as slow connections, technical errors, or due to use of some incompatible
mobile devices.
Government organisation action: None.
Developer action: Ensure testing on different devices to ensure the website remains easily
readable even on turning off style sheets.
Evaluator action: The evaluator shall test the website by using browser extension/ tool for verifying
conformity to this checkpoint.

Statement: Proper page title and language attribute along with
metadata for page like keywords and description are
appropriately included.
5.1.17
Beneﬁt: Once details such as government organisation name, services offered, schemes, location,
help ensure enhanced accessibility, especially for those with screen readers who rely on things
such as page titles, structured page headings and lists. Additionally, search engines rank such sites
higher in search results.
Government organisation action:

The government organisation must provide the relevant

metadata for each page.
Developer action: Must ensure mentioning all necessary metadata in the <head> portion of the
html page from where it is read by search engines.
Evaluator action: The evaluator shall test the website by using browser extension tools for verifying
conformity to this checkpoint.

41

<!-- page 42 -->

5. Guidelines

Statement: Minimum content as prescribed in the guidelines
is present on the homepage/homescreen and all
subsequent pages/screens.
5.1.18
Beneﬁt: The homepage/homescreen being the primary entry page to the entire content of the
website/app should allow visitors to get access to the most important content elements from the
homepage/homescreen itself. Often, visitors may use a search engine for ﬁnding some information
and, therefore, directly reach a subsequent page/screen of the website/app instead of the
homepage/homescreen, therefore, it helps to have some minimum content on each page/screen
of website/app, e.g., self-explanatory title, link to homepage/homescreen, ownership, link to
Contact us etc.
Government organisation action: The government organisation must ensure the availability of:
Minimum content on the homepage/homescreen of a website/app
(a) Government organisation name (alternatively, the name of the project, service etc.
as applicable);
(b) State emblem of India/Logo (as applicable);
(c) About the government organisation (including its main activities and functions);
(d) Link to all the major modules/sections of the site;
(e) Link to all the citizen services offered by the government organisation;
(f) Link to the ‘Contact us’ page of the website/app;
(g) Link to the “Feedback” page;
(h) Link to national portal;
(i) Search/Site Map; and
(j) Terms and conditions of use.
Minimum Content on subsequent pages/screens of a website/app
(a) Self-explanatory title of the page/screen;
(b) Link to the homepage/homescreen;
(c) Link to the parent section/top module of the individual page/screen;
(d) Ownership (name of the government organisation owning the website/app); and
(e) Link to the “Contact us” page.
Developer action: Ensure providing the minimum content as prescribed by the GIGW guidelines
referred on the homepage/homescreen as well as the subsequent pages/screens.
Evaluator action: The evaluator shall manually test it for verifying conformity to this checkpoint.

42

<!-- page 43 -->

5. Guidelines

Statement: Data tables have been provided with necessary
tags/markup
5.1.19
Beneﬁt: Proper use of markup in tables helps with accessibility, ensuring assistive technology
users can easily navigate and comprehend the tabular content.
Government organisation action: None.
Developer action: Avoid use of tables for page layout. Proper tags and markup must be provided
to identify row and column headers and associate data cells and header cells.
Evaluator action: The evaluator shall test the website by using browser extension/ tool for verifying
conformity to this checkpoint.

Statement: Content of the web page prints correctly on an
5.1.20
A4 size paper
Beneﬁt: Offers enhanced accessibility to visitors who may prefer the print format.
Government organisation action: None.
Developer action: Ensure testing with font properties such that the text must print correctly on an
A4 size paper.
Evaluator action: The evaluator shall manually test the website for verifying conformity to this
checkpoint.

Statement: Website is in the nic.in or gov.in domain. Educational
Institutions and Research and Academic Institutions, which are
eligible for registration under ‘gov.in’ may use ‘edu.in’, ‘res.in’
or ‘ac.in’ domains
5.1.21
Beneﬁt: The URL or the Web Address of any Government website is a strong indicator of its
authenticity and status as being ofﬁcial. Use of gov.in or nic.in domain inspires trust in the visitor
that the website being visited is authentic.
Government organisation action: The government organisations must obtain ‘gov.in’ or ‘nic.in’
domain exclusively allotted and restricted to government websites. The domain name conventions,
as speciﬁed in the ‘.IN Registration’ policy, should be followed while registering a ‘gov.in’ Domain
Name. For detailed information and step-by-step procedure on how to register a gov.in Domain
visit http://registry.gov.in.

43

<!-- page 44 -->

5. Guidelines

Developer action: None.
Evaluator action: The evaluator shall manually test the website for verifying conformity to this
checkpoint.

Statement: API integration with key government platforms (India
Portal, DigiLocker, Aadhaar, Single-Sign-On, MyGov, Data Platform,
MyScheme) and similar websites of the government organisation
must be enabled for seamless exchange of Information
and data.
5.1.22
Beneﬁt: Integration with other websites and platforms provides the following beneﬁts to the
government organisation:
(a) Data/Information is consistent as it is being pushed from a single source to all the
interfaces;
(b) It can be managed and maintained easily and is well synchronised across all the interfaces;
(c) Avoids duplication of effort content creation; and
(d) Ensures standardisation and security, e.g., use of DigiLocker, Aadhaar authentication or
single sign-on ensures that any technical, functional or security enhancements are pushed to all
the websites/apps in real time.
Citizens beneﬁt by having a single identity which can be used across multiple websites/apps and
a single repository of documents. They do not have to comprehend the same information and
data from multiple sources.
Government organisation action: The government organisation must identify the websites
and platforms with which the integration needs to be established as per their requirement
so that no duplication efforts are being made. They must provide required APIs and
Web Services to the developer/entity to enable integration.
Developer action: Developers must ensure that the integration is done as per the best
practices pertaining to security and technology.
Evaluator action: The evaluator shall manually test the website for verifying conformity to
this checkpoint.

44

<!-- page 45 -->

5. Guidelines

Statement: The government organisation must ensure a consistent
user experience and visual identities across all its
websites/apps.
5.1.23
Beneﬁt: Maintaining consistency enhances the ease of use for the visitors. If the visitors have
browsed one website/app then the learning curve of using the other websites/apps of the
government organisation is greatly reduced and visitors can interact and ﬁnd information easily
and quickly. Maintaining a consistent visual identity reinforces the authenticity and enhances the
trust level of the visitors.
Government organisation action: The government organisations must ensure a consistent
information architecture, navigation scheme, terminology and visual branding (logos, etc.) across
the web initiatives of all organisations under them.
Developer action: Developers must create templates with common Information Architecture (IA),
conﬁgurable components and neat user interface, which can be implemented on different
websites/apps to achieve consistency.
Evaluator action: The evaluator shall manually test the website for verifying conformity to this
checkpoint.

Statement: Websites/apps must provide integration with
popular social media.

5.1.24

Beneﬁts: Users and the government organisation are increasingly using social media to quickly
connect, share information and even provide services. Social media platforms also provide an easy
means of two-way communication between the user and government organisation. Younger
generation also ﬁnds it easy to connect through social media on smart devices rather than the web
interface.
Government

organisation

action:

The

government

organisations

must

identify

the

information/content that needs to be pushed to the social media platforms directly from the
websites/apps. The content must also be written in a way that is suitable for social media.
Developer action: Developer must ensure a two-way integration by providing a mechanism to
push content from the website/app to the social media platform and also integrate the social
media content into the website/app.
Evaluator action: The evaluator shall manually test the website for verifying conformity to this
checkpoint.

45

<!-- page 46 -->

5. Guidelines

Statement: The language is free from spelling and
grammatical errors.

5.1.25

Beneﬁt: The language used in a government website/app is very important for ensuring effective
communication with the target audiences. When website/app visitors get clear and error free
content, it raises the trust level of the citizens towards the government organisation.
Government organisation action: Check the content manually or with automated spelling and
grammar tools before publishing.
Developer action: Ensure provision of a CMS that enables publishing of error free content both
with respect to grammar and spellings.
Evaluator action: The evaluator shall test the website/app by using a tool for verifying conformity
to this checkpoint. The evaluator shall check in the backend audit for implementation of the
mechanism by verifying documented records.

Hindi
Telugu

46

<!-- page 47 -->

5. Guidelines

Accessibility

5.2

T

he Success criteria under this section have been adopted
from W3C Web content accessibility guidelines
(https://www.w3.org/TR/WCAG21/). Developers are advised
to refer to the W3C website for the complete description
and techniques to meet the success criteria.
Statement: All non-text content that is presented to the user has a
text alternative that serves the equivalent purpose, except
for the situations listed below:
5.2.1
(a) Controls, Input: If non-text content is a control or accepts user input, then it has a name
that describes its purpose (Refer to Success Criterion 4.1.2 for additional requirements for
controls and content that accepts user input);
(b) Time-Based Media: If non-text content is time-based media, then text alternatives at
least provide descriptive identiﬁcation of the non-text content (Refer to Guideline 1.2 for
additional requirements for media);

47

<!-- page 48 -->

5. Guidelines

(d) Sensory: If non-text content is primarily intended to create a speciﬁc sensory
experience, then text alternatives at least provide descriptive identiﬁcation of the non-text
content;
(e) CAPTCHA: If the purpose of non-text content is to conﬁrm that content is being
accessed by a person rather than a computer, then text alternatives that identify and
describe the purpose of the non-text content are provided and alternative forms of
CAPTCHA using output modes for different types of sensory perception are provided to
accommodate different disabilities; and
(f) Decoration, Formatting, Invisible: If non-text content is pure decoration, is used only for
visual formatting, or is not presented to users, then it is implemented in a way that it can be
ignored by assistive technology.
Beneﬁt: Conformity makes information conveyed by non-text content accessible through the use
of a text alternative. For example, a person who cannot see a picture can have the text alternative
read aloud using synthesised speech. A person who cannot hear an audio ﬁle can have the text
alternative displayed so that he or she can read it.
Government organisation action: A meaningful explanatory text equivalent must be speciﬁed for
images and other non-text content. The description should summarise the content or purpose of
the image. For example, to use the description ‘Picture’ to explain a graphic does not serve any
purpose.
Developer action: For images text equivalent can be provided by using the ALT attribute. The ALT
text for an image is displayed before the image is fully downloaded. It is the main source of image
information for users of text-only browsers, users of browsers with graphics turned off and users
who are sight impaired. The following situations are exceptions:
(a)

If the non-text content is a control or accepts input e.g., a submit button then it must

have a name describing the purpose of the control;
(b)

If the non-text content is time-based media (audio/video) then the text equivalent

provides a descriptive identiﬁcation of the same;
(c)

If non-text content is a test or exercise that would be invalid if presented in text, then

text alternatives at least provide descriptive identiﬁcation of the non-text content;
(d)

If non-text content is primarily intended to create a speciﬁc sensory experience,

then text alternatives at least provide descriptive identiﬁcation of the non-text content;
(e)

CAPTCHA: If the purpose of non-text content is to conﬁrm that content is being

accessed by a person rather than a computer, then text alternatives that identify and
describe the purpose of the non-text content are provided and alternative forms of
CAPTCHA using output modes for different types of sensory perception are provided to
accommodate different disabilities; and
(f)

If non-text content is pure decoration, is used only for visual formatting, or is not

48

<!-- page 49 -->

5. Guidelines

presented to users, then it is implemented in a way that it can be ignored by assistive
technology (by using blank alt attribute).

https://www.w3.org/WAI/WCAG21/Understanding/non-text-content.html

Reference: WCAG 2.1 - 1.1.1

Evaluator action: The evaluator will test it manually and by using the accessibility extension to
browser/ accessibility plug-in/web accessibility tool to check the conformity of this checkpoint.

Statement: For pre-recorded audio-only and pre-recorded
video-only media, the following are true, except when the audio
or video is a media alternative for text and is clearly
5.2.2
labelled as such:
(a) Pre-recorded Audio-only: An alternative for time-based media is provided that
presents equivalent information for pre-recorded audio-only content; and
(b) Pre-recorded Video-only: Either an alternative for time-based media or an audio track
is provided that presents equivalent information for pre-recorded video-only content.
Beneﬁt: The intent of this Success Criterion is to make information conveyed by pre-recorded
audio-only and pre-recorded video-only content available to all users. Alternatives for time-based
media that are text based make information accessible because text can be rendered through any
sensory modality (for example, visual, auditory or tactile) to match the needs of the user.
Government organisation action: Create the alternate for time-based media, i.e, transcript in
case audio only and transcript or audio track in case of video only content. Captions are not
needed when the synchronised media is, itself, an alternate presentation of information that is also
presented via text on the Web page
Developer action: Make provision to provide alternatives for time-based media.

https://www.w3.org/WAI/WCAG21/Understanding/audio-only-and-video-only-prerecorded.html

Reference: WCAG 2.1 - 1.2.1

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

49

<!-- page 50 -->

5. Guidelines

Statement: Captions are provided for all pre-recorded audio
content in synchronised media, except when the media is a
5.2.3
media alternative for text and is clearly labelled as such
Beneﬁt: This enables people who are deaf or hard of hearing to watch synchronised media
presentations.
Government organisation action: The government organisations must create captions to provide
the part of the content available via the audio track. Captions not only include dialogue but identify
who is speaking and include non-speech information conveyed through sound, including
meaningful sound effects.
Developer action: Ensure that the captions are available with audio content.

https:/ www.w3.org/WAI/WCAG21/Understanding/captions-prerecorded.html#dfn-synchronized-media

Reference: WCAG 2.1 - 1.2.2

Evaluator action: The evaluator will test the it manually to check the conformity of this checkpoint.

Statement: An alternative for time-based media or audio
description of the pre-recorded video content is provided
for synchronised media, except when the media is a
media alternative for text and is clearly labelled as such.

5.2.4

Beneﬁt: provides people who are blind or visually impaired access to the visual information in a
synchronised media presentation
Government organisation action: The government organisations must provide audio description
of the video content. The audio description augments the audio portion of the presentation with
the information needed when the video portion is not available. Alternatively, all of the information
in the synchronised media (both visual and auditory) may be provided in text form. If all of the
information in the video track is already provided in the audio track, no audio description is
necessary.
Developer action: Developer must provide provision for publishing the alternative for time-based
media or audio description of the pre-recorded video content

https:/ www.w3.org/WAI/WCAG21/Understanding/audio-description-or-media-alternative-prerecorded.html

Reference: WCAG 2.1 - 1.2.3

Evaluator action: The evaluator will test the it manually to check the conformity of this checkpoint.

50

<!-- page 51 -->

5. Guidelines

Statement: Captions are provided for all live audio content
in synchronised media.

5.2.5

Beneﬁts: Enables people who are deaf or hard of hearing to watch real-time presentations.
Government organisation action: The government organisation must provide captions for live
audio content.
Developer action: Provide provision to publish captions

https://www.w3.org/WAI/WCAG21/Understanding/captions-live.html

Reference: WCAG 2.1 - 1.2.4

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: Audio description is provided for all
pre-recorded video content in synchronised media.

5.2.6

Beneﬁts: Provides people who are blind or visually impaired access to the visual information in a
synchronised media presentation. During existing pauses in dialogue, audio description provides
information about actions, characters, scene changes and on-screen text that are important and
are not described or spoken in the main soundtrack.
Government organisation action: Provide Audio description of pre-recorded video content
Developer action: Provide provision to publish audio description

https://www.w3.org/WAI/WCAG21/Understanding/audio-description-prerecorded.html

Reference: WCAG 2.1 - 1.2.5

Evaluator action: The evaluator will test it manually a check the conformity of this checkpoint.

Statement: Information, structure and relationships
conveyed through presentation can be programmatically
determined or are available in text.

5.2.7

Beneﬁts: Sighted users perceive structure and relationships through various visual cues present
on a page (page headings are in a larger and bold font; list items are preceded by a bullet; form
ﬁelds may be positioned as groups that share text labels; a different background colour may be
used to indicate related items and so on). However, visually challenged users cannot take
advantage of these cues. It must be ensured that these information and relationships are
preserved even when the presentation format changes. (For example, when the content is read by
a screen reader or CSS is turned off or replaced).

51

<!-- page 52 -->

5. Guidelines

Government organisation action: None.
Developer action: Developers must ensure that information and relationships that are implied by
visual or auditory formatting are preserved when the presentation format changes. For example,
when the content is read by a screen reader or when a user style sheet is substituted for the style
sheet provided by the author. For example, a form contains several required ﬁelds. The labels for
the required ﬁelds are displayed in red. In addition, at the end of each label is an asterisk character
(*). The instructions for completing the form indicate that "all required ﬁelds are displayed in red
and marked with an asterisk *", followed by an example.

https://www.w3.org/WAI/WCAG21/Understanding/info-and-relationships.html

Reference: WCAG 2.1 - 1.3.1

Evaluator action: The evaluator will test it manually and by using the accessibility extension to
browser/accessibility plug-in/web accessibility tool/assistive technology to check the conformity
of this checkpoint.

Statement: When the sequence in which content is presented
affects its meaning, a correct reading sequence can be
5.2.8
programmatically determined.
Beneﬁts: This helps people who rely on assistive technologies like screen readers because the
meaning evident in the sequencing of the information in the visual presentation will be the same
when the content is presented in spoken form. This also preserves the meaning of the page when
the CSS is turned off or not supported.
Government organisation action: None.
Developer action: Provide a meaningful reading sequence.
Note: Developers must keep in mind that a sequence is meaningful if change of order shall impact
its meaning. Two independent content items like two separate articles in a page may be placed in
any sequence without affecting the meaning. Similarly, the navigation block and the content area
may be placed in any sequence without affecting their meaning. HTML text is always a meaningful
sequence. Tables and ordered lists are meaningful sequences, but unordered lists are not. It must
be clear that providing a particular linear order is only required where it affects meaning There may
be more than one order that is "correct" and only one correct order needs to be provided.

https:/ www.w3.org/WAI/WCAG21/Understanding/meaningful-sequence

Reference: WCAG 2.1 - 1.3.2

Evaluator action: The evaluator will test it manually and by using the accessibility extension to
browser/accessibility plug-in/web accessibility tool/assistive technology to check the conformity
of this checkpoint.

52

<!-- page 53 -->

5. Guidelines

Statement: Instructions provided for understanding and operating
content do not rely solely on sensory characteristics of
components such as shape, colour, size, visual location,
5.2.9
orientation, or sound.
Beneﬁt: Many users including the visually challenged cannot perceive shape, size or use information
about location or orientation. For such users the content that relies on knowledge of the shape or
position of objects becomes inaccessible (for example, “round button” or “button to the right”).
Government organisation action: None.
Developer action:

Provide additional information in content that relies solely on sensory

characteristics of components such as shape, size, visual location, orientation, or sound. This can be
done by providing textual identiﬁcation of items that otherwise rely only on sensory information to
be understood; for example, a round button is provided on a form to submit the form and move onto
the next step. The button is labelled with the text "go." The instructions state, "to submit the form
press the round button labelled go''. This includes both shape and textual information to locate the
button.

https:/ www.w3.org/WAI/WCAG21/Understanding/sensory-characteristics

Reference: WCAG 2.1 - 1.3.3

Evaluator action: The evaluator will test it manually and by using the assistive technology to check
the conformity of this checkpoint.

Statement: Content does not restrict its view and operation to a
single display orientation, such as portrait or landscape,
5.2.10
unless a speciﬁc display orientation is essential.
Beneﬁt: This Success Criterion requires content to display in the orientation preferred by the user
and not restrict the orientation. This improves accessibility for users who rely on a speciﬁc
orientation and promotes ﬂexibility in technology design.
Users with dexterity impairments, who have a mounted device will be able to use the content in
their ﬁxed orientation.
Users with low vision will be able to view content in the orientation that works best for them, for
example to increase the text size by viewing content in landscape.

53

<!-- page 54 -->

5. Guidelines

Government organisation action: None.
Developer action: Developers must ensure that content displays in the orientation
(portrait or landscape) preferred by the user. Content does not restrict its view and operation to a
single display orientation, such as portrait or landscape, unless a speciﬁc display orientation is
essential. Examples of situations where a speciﬁc display orientation is essential could be a:
(a) Banking app that requires the device to be in landscape mode to capture an image of a check
easily and accurately for deposit; and
(b) Piano app that requires the device to be in landscape mode to allow room for enough of the
piano keys to be functionally usable. Since a piano app is emulating a physical piano keyboard that
needs to retain relative physical characteristics between keys, either too few keys would be
available, or the keys would be much too narrow.

https://www.w3.org/WAI/WCAG21/Understanding/orientation

Reference: WCAG 2.1 -1.3.4

Evaluator action: The evaluator will test it manually and by using the accessibility extension to
browser/accessibility plug-in/web accessibility tool/assistive technology to check the conformity
of this checkpoint.

Statement: The purpose of each input ﬁeld collecting information
about the user can be programmatically determined
5.2.11
when:
(a) The input ﬁeld serves a purpose identiﬁed in the Input Purposes for User Interface
Components section; and
(b The content is implemented using technologies with support for identifying the
expected meaning for form input data.
Beneﬁt: People with language and memory related disabilities or disabilities that affects executive
function and decision-making beneﬁt from the browser auto-ﬁlling personal information (such as
name or address). People with learning disability can employ assistive technology which adds icons
to input ﬁelds to communicate the purpose of the ﬁelds visually and people with motor
impairments also beneﬁt from reducing the need for manual input when ﬁlling out forms.
Government organisation action: None
Developer action: Developers must ensure that the purpose of a form input collecting information
about the user can be programmatically determined, so that user agents can extract and present
this purpose to users using different modalities. Developers can use autoﬁll attribute to
programmatically link a pre-deﬁned and published taxonomic term to the input, so that the inputs
can also be machine-interpreted.

54

<!-- page 55 -->

5. Guidelines

https://www.w3.org/WAI/WCAG21/Understanding/identify-input-purpose

Reference: WCAG 2.1-1.3.5

Evaluator action: The evaluator will test it manually and by using the Accessibility extension to
browser/accessibility plug-in/web accessibility tool/assistive technology to check the conformity
of this checkpoint.

Statement: Colour is not used as the only visual means of
conveying information, indicating an action, prompting a
response, or distinguishing a visual element.

5.2.12

Beneﬁt: Conformity to this guidelines beneﬁts user who have difﬁculty perceiving colour
e.g. People with partial sight or older users who do not see colour well. If a page has information that
is conveyed by colour differences like: “required ﬁelds are red”, “error is shown in red” and “January
sales are in red, July are in blue” then these users may not be able to access such information.
Government organisation action: None.
Developer action: Developers must ensure that when colour differences are used to convey
information, such as required form ﬁelds, the information conveyed by the colour differences are
also conveyed explicitly in text. Developers must provide a redundant visual cue for users who may
not be able to discern a difference in text colour e.g., formatting for links on a page includes
presenting them both in a different colour than the other text on the page underlining them to make
the links identiﬁable even without colour vision.

https:/ www.w3.org/WAI/WCAG21/Understanding/use-of-color.html

Reference: WCAG 2.1 - 1.4.1

Evaluator action: The evaluator will test it manually and by using the Accessibility extension to
browser/accessibility plug-in/web accessibility tool/assistive technology to check the conformity
of this checkpoint.

55

<!-- page 56 -->

5. Guidelines

Statement: If any audio on a Web page plays automatically for
more than 3 seconds, either a mechanism is available to pause or
stop the audio, or a mechanism is available to control audio volume
independently from the overall system volume level.
5.2.13
Beneﬁts: The ability for individuals who use screen reading software to turn off background sound
provides numerous beneﬁts. It ensures that the screen reader's speech output can be heard clearly
without interference from other audio, which is especially important for those who are hard of
hearing or have hearing impairments. Additionally, it beneﬁts individuals who struggle to focus on
visual content when audio is playing. This simple feature allows for a more accessible and inclusive
experience for all users.
Government organisation action: None.
Developer action: Ensure that the sound that plays automatically when a page load stops within 3
seconds or provide a control at the beginning of the page to turn the sound off

https:/ www.w3.org/WAI/WCAG21/Understanding/audio-control.html

Reference: WCAG 2.1 - 1.4.2

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: The visual presentation of text and images of text has a
contrast ratio of at least 4.5:1, except for the following:
5.2.14
(a) Large Text: (18 pt. or 14 pt. bold) Large-scale text and images of large-scale text have a
contrast ratio of at least 3:1;
(b) Incidental: Text or images of text that are part of an inactive user interface component,
that are pure decoration, that are not visible to anyone, or that are part of a picture that
contains signiﬁcant other visual content, have no contrast requirement; and
(c) Logotypes: Text that is part of a logo or brand name has no contrast requirement.
Beneﬁts: The contrast ratios are that they improve the readability and accessibility of text for a
wider range of users, including those with visual impairments or colour deﬁciencies. By providing a
minimum luminance contrast ratio between text and its background, text is more visible and legible,
which can improve user experience and overall inclusivity.
Government organisation action: None.
Developer action: Developers must Ensure that a contrast ratio of at least 4.5:1 exists between text
(and images of text) and background behind the text. It must be checked by the use of contrast

56

<!-- page 57 -->

5. Guidelines

checking tools. Alternatively, they can provide a control with a sufﬁcient contrast ratio that allows
users to switch to a presentation that uses sufﬁcient contrast

https://www.w3.org/WAI/WCAG21/Understanding/contrast-minimum

Reference: WCAG 2.1 - 1.4.3

Evaluator action: The evaluator will test it to see whether ‘high contrast mode’ is available and by
using the accessibility extension to browser/accessibility plug-in/web accessibility tool to check
the conformity of this checkpoint.

Statement: Except for captions and images of text, text can be
resized without assistive technology up to 200 percent
without loss of content or functionality.
5.2.15
Beneﬁts: It helps people with mild visual disabilities by allowing them to scale visually rendered text
and text-based controls on a web page, without requiring the use of assistive technology. It ensures
that the author creates web content that does not prevent user agents from scaling content
effectively. By supporting text scaling, people with low vision can increase the size of text to a
readable level, improving their ability to access and read web content.
Government organisation action: None.
Developer action: Developer must create Web content that does not prevent the user agent (e.g.,
browser) from scaling the content effectively. Ensuring that text containers resize when the text
resizes and using measurements that are relative to other measurements in the content.
Alternatively, developers may provide controls on the Web page that allow users to incrementally
change the size of all text on the page up to 200 percent.

https:/ www.w3.org/WAI/WCAG21/Understanding/resize-text

Reference: WCAG 2.1 - 1.4.4

Evaluator action: The evaluator will test it manually and by using the Accessibility extension to
browser/accessibility plug-in/web accessibility tool to check the conformity of this checkpoint.

Statement: If the technologies being used can achieve the
visual presentation, text is used to convey information
rather than images of text except for the following:

5.2.16

(a) Customizable: The image of text can be visually customised to the user's requirements;
(b) Essential: A particular presentation of text is essential to the information being
conveyed;
(c) Use of images for representing text should be limited.

57

<!-- page 58 -->

5. Guidelines

Beneﬁt: Though images add life to a website, they also increase downloading time. Images should
only be used when it adds value to the content. Images should not be used to present text as those
using text-only browsers shall not be able to access the information thus rendering the website
inaccessible to many. Therefore, text must be used to convey information rather than images of text
except for the cases given above. The use of text, rather than images of text, should be considered
for page headings and website navigation items.
Government organisation action: Perform OCR on a scanned PDF document to capture actual text
Developer action: CSS properties like font-family, text-align, font-size etc. can be used to style text
and avoid the need for text in images.

https://www.w3.org/WAI/WCAG21/Understanding/images-of-text

Reference: WCAG 2 1 - 1.4.5

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: Content can be presented without loss of information
or functionality and without requiring scrolling in two
dimensions for:
5.2.17
(a) Vertical scrolling content at a width equivalent to 320 CSS pixels;
(b) Horizontal scrolling content at a height equivalent to 256 CSS pixels; and
(c) Except for parts of the content which require a two-dimensional layout for usage or
meaning.
Beneﬁts: Beneﬁts especially to those with small screens such as mobile devices or limited screen
resolutions. It ensures that content is presented in a way that is easily accessible without the need
for excessive scrolling or complex navigation.
Government organisation action: None.
Developer action: Use responsive web design approach by using CSS media queries, grid or ﬂexbox
to present content without introducing a horizontal scroll bar at a width equivalent to 320 CSS
pixels, or a vertical scroll bar at a height equivalent to 256 CSS pixels for text intended to scroll
horizontally.

https://www.w3.org/WAI/WCAG21/Understanding/reﬂow.html

Reference: WCAG 2.1-1.4.10

Evaluator action: The evaluator will test it

manually and by using the web accessibility
tool to check the conformity of this
checkpoint.

58

<!-- page 59 -->

5. Guidelines

Statement: The visual presentation of the following has a
contrast ratio of at least 3:1 against adjacent colour(s):

5.2.18

(a) User Interface Components: Visual information required to identify user interface
components and states, except for inactive components or where the appearance of the
component is determined by the user agent and not modiﬁed by the author;
(b) Graphical Objects: Parts of graphics required to understand the content, except when a
particular presentation of graphics is essential to the information being conveyed.
Beneﬁts: This beneﬁts people with low vision or other visual impairments who may have difﬁculty
perceiving low contrast controls and graphics and helps them better understand the content or
functionality of the webpage without the need for contrast-enhancing assistive technology.
Government organisation action: None.
Developer action: Providing a control with a sufﬁcient contrast ratio that allows users to switch to
a presentation that uses sufﬁcient contrast

https:/ www.w3.org/WAI/WCAG21/Understanding/non-text-contrast

Reference: WCAG 2.1- 1.4.11

Evaluator action: The evaluator will test it manually and by using the accessibility extension to
browser/accessibility plug-in/web accessibility tool to check the conformity of this checkpoint.

Statement: In content implemented using markup languages that
support the following text style properties, no loss of content or
functionality occurs by setting all of the following and by
changing no other style property:
5.2.19
(a) Line height (line spacing) to at least 1.5 times the font size;
(b) Spacing following paragraphs to at least 2 times the font size;
(c) Letter spacing (tracking) to at least 0.12 times the font size;
(d) Word spacing to at least 0.16 times the font size; and
(e) Exception: Human languages and scripts that do not make use of one or more of these
text style properties in written text can conform using only the properties that exist for that
combination of language and script.

59

<!-- page 60 -->

5. Guidelines

Beneﬁts: People with visual and cognitive disabilities can adjust text spacing to improve their
reading experience without losing any content or functionality. By setting a minimum baseline for
text styling adaptability, users can increase the spacing between lines, words, letters and
paragraphs to effectively read text and other style preferences can be set. This can beneﬁt people
with low vision, dyslexia and cognitive disabilities who may require increased space between text to
read or discern sections and call out boxes. Overall, this aims to improve accessibility and usability
for a wider range of users.
Government organisation action: None.
Developer action: Ensure that content has the ability to be set to the above metrics without loss
of content or functionality in case the user prefers to override the spacing provided by the
developer

https://www.w3.org/WAI/WCAG21/Understanding/text-spacing

Reference: WCAG 2.1- 1.4.12

Evaluator action: The evaluator will test it manually and by using the accessibility extension to
browser/accessibility plug-in/web accessibility tool/assistive technology to check the conformity
of this checkpoint.

Statement: Where receiving and then removing pointer hover or
keyboard focus triggers additional content to become
visible and then hidden, the following are true:
5.2.20
(a) Dismissible: A mechanism is available to dismiss the additional content without moving
pointer hover or keyboard focus unless the additional content communicates an input error
or does not obscure or replace other content;
(b) Hover-able: If pointer hover can trigger the additional content, then the pointer can be
moved over the additional content without the additional content disappearing; and
(c) Persistent: The additional content remains visible until the hover or focus trigger is
removed, the user dismisses it, or its information is no longer valid.
Beneﬁts: This beneﬁts users with low vision, cognitive disabilities, low pointer accuracy and those
who use magniﬁcation or larger mouse cursors by providing a way to view content without reducing
their desired magniﬁcation or increasing the risk of triggering additional content accidentally.
Government organisation action: None.
Developer action: Ensure that content has the ability to be set to the above metrics without loss
of content or functionality in case the user prefers to override the spacing provided by the
developer

60

<!-- page 61 -->

5. Guidelines

https://www.w3.org/WAI/WCAG21/Understanding/content-on-hover-or-focus

Reference: WCAG 2.1-1.4.13

Evaluator action: The evaluator will test it manually and by using the accessibility extension to
browser/accessibility plug-in/web accessibility tool/assistive technology to check the conformity
of this checkpoint.

Statement: All functionality of the content is operable through a
keyboard interface without requiring speciﬁc timings for
individual keystrokes, except where the underlying function
requires input that depends on the path of the user's
5.2.21
movement and not just the endpoints.
Beneﬁts: By ensuring that content is operable through a keyboard or keyboard interface, this
Success Criterion beneﬁts people who are blind, people with low vision and individuals with hand
tremors or other conditions that make using a mouse difﬁcult. It also enables the use of operating
system keyboard accessibility features, such as modiﬁer key locking, which can further improve the
accessibility of the content.
Government organisation action: None.
Developer action: Developers must Identify all functionality on the content and check that all
functionalities can be accessed using only the keyboard or keyboard interface. It is important to
consider functions performed using both the mouse and the keyboard together. Examples of
functionality include the use of physical controls such as links, menus, buttons, checkboxes, radio
buttons and form ﬁelds as well as the use of features like drag and drop, selecting text, resizing
regions or bringing up context menus. This does not necessarily mean that each of the individual
controls can be used from the keyboard as long as there are multiple methods to perform the same
function available on the page. Developers must consider how users will discover any keyboard
equivalents which are available in such a case.

https://www.w3.org/WAI/WCAG21/Understanding/keyboard.html

Reference: WCAG 2.1 - 2.1.1

Evaluator action: The evaluator will test it manually to
check the conformity of this checkpoint.

61

<!-- page 62 -->

5. Guidelines

Statement: If keyboard focus can be moved to a component of the
page using a keyboard interface, then focus can be moved away
from that component using only a keyboard interface and, if it
requires more than unmodiﬁed arrow or tab keys or other standard
exit methods, the user is advised of the method for
5.2.22
moving focus away.
Beneﬁts: Whenever a web page is rendered using plug-ins or embedded applications, it is possible
that functionality of the Web page restricts the keyboard focus to a subsection of the content,
unless the user knows how to leave that state and “un-trap” the focus. This situation may affect
navigation for people who rely on a keyboard or keyboard interface to use the Web, including
visually challenged and people with physical disabilities.
Government organisation action: None.
Developer action: Developers must ensure that if focus can be moved to a component of the page
using a keyboard interface, then focus can be moved away from that component using only a
keyboard interface and, if it is not possible the user is advised of the method for moving focus away

https://www.w3.org/WAI/WCAG21/Understanding/no-keyboard-trap

Reference: WCAG 2.1 - 2.1.2

Evaluator action: The evaluator will test it manually and by using assistive technology to check the
conformity of this checkpoint.

Statement: If a keyboard shortcut is implemented in content using
only letter (including upper- and lower-case letters), punctuation,
number, or symbol characters, then at least one of the
5.2.23
following is true:
(a) Turn off: A mechanism is available to turn the shortcut off;
(b) Remap: A mechanism is available to remap the shortcut to include one or more
non-printable keyboard keys (e.g., Ctrl, Alt); and
(c) Active only on focus: The keyboard shortcut for a user interface component is only
active when that component has focus.

62

<!-- page 63 -->

5. Guidelines

Beneﬁts: Beneﬁts speech users who can avoid ﬁring batches of single-key shortcuts at once and
make full use of programs that offer single-key shortcuts to keyboard users. It also beneﬁts
keyboard-only users who have dexterity challenges an d may accidentally hit keys, as they can turn
off or modify problematic single character shortcuts.
Government organisation action: None.
Developer action: In case a developer has provided shortcuts in their applications to allow for
faster user interaction which involve only character keys (letters, numbers, punctuation or symbol
characters) without modiﬁers provision must be given to allow users to turn off or reconﬁgure
shortcuts that are made up of only character keys. If the keyboard shortcut is only active when a
particular user interface component has focus, then override mechanism is not required.

https://www.w3.org/WAI/WCAG21/Understanding/character-key-shortcuts

Reference: WCAG 2.1 – 2.1.4

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: For each time limit that is set by the content,
at least one of the following is true:

5.2.24

(a) Turn off: The user is allowed to turn off the time limit before encountering it; or
(b) Adjust: The user is allowed to adjust the time limit before encountering it over a wide
range that is at least ten times the length of the default setting; or
(c) Extend: The user is warned before time expires and given at least 20 seconds to
extend the time limit with a simple action (for example, "press the spacebar") and the
user is allowed to extend the time limit at least ten times; or
(d) Real-time Exception: The time limit is a required part of a real-time event (for
example, an auction) and no alternative to the time limit is possible; or
(e) Essential Exception: The time limit is essential and extending it would invalidate the
activity; or
(f) 20 Hour Exception: The time limit is longer than 20 hours.
Beneﬁts: In situations where web functions are time-dependent, (for example, ﬁlling out an online
form) it will be difﬁcult for people with disabilities such as blindness, low vision, dexterity
impairments and cognitive limitations to perform the required functions before a time limit occurs.
This may render the service inaccessible to them. For individuals who are deaf and communicate in
sign language, having control over time limits is important when using a sign-language interpreter.
Providing additional time to pause content can be helpful for those with reading and cognitive
disabilities to better comprehend information.

63

<!-- page 64 -->

5. Guidelines

Government organisation action: None.
Developer action: Developers must ensure that people with disabilities such as blindness, low
vision, dexterity impairments and cognitive limitations are given adequate time to perform the
functions that are time dependent whenever possible. The user must be allowed to turn off the time
limit, adjust the default setting before encountering it or is warned before time expires and given
the option to extend the time limit with a simple action (for example, “press the spacebar”).

https:/ www.w3.org/WAI/WCAG21/Understanding/timing-adjustable.html

Reference: WCAG 2.1 - 2.2.1

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: For moving, blinking, scrolling, or auto-updating
5.2.25
information, all of the following are true:
(a) Moving, blinking, scrolling: For any moving, blinking or scrolling information that (1)
starts automatically, (2) lasts more than ﬁve seconds and (3) is presented in parallel with
other content, there is a mechanism for the user to pause, stop, or hide it unless the
movement, blinking, or scrolling is part of an activity where it is essential; and
(b) Auto-updating: For any auto-updating information that (1) starts automatically and
(2) is presented in parallel with other content, there is a mechanism for the user to pause,
stop, or hide it or to control the frequency of the update unless the auto-updating is part
of an activity where it is essential.
Beneﬁts: Avoiding content that ﬂashes can prevent triggering seizures in people with
photosensitive epilepsy.
Government organisation action: None.
Developer action: Allow the content to be paused and restarted from where it was paused or Use
script to scroll content and provide a mechanism to pauseit or Create content that blinks for less
than 5 seconds

https://www.w3.org/WAI/WCAG21/Understanding/pause-stop-hide

Reference: WCAG 2.1 - 2.2.2

Evaluator action: The evaluator will test it manually to
check the conformity of this checkpoint.

64

<!-- page 65 -->

5. Guidelines

Statement: Web pages do not contain anything that ﬂashes
more than three times in any one second period, or the ﬂash
is below the general ﬂash and red ﬂash thresholds.
5.2.26
Beneﬁts: Certain special effects such as blinking, or ﬂashing have been reported to cause epileptic
seizures. It is also seen that people are more sensitive to red ﬂashing than other colours. Web pages
must not contain anything that ﬂashes more than three times in any one second period. It must also
be checked that the Light/Dark status at the end of the 1- second period is the same as at the start
Government organisation action: None.
Developer action: Ensure that no component of the content ﬂashes more than three times in any
1-second period or keep the ﬂashing area small enough reference

https://www.w3.org/WAI/WCAG21/Understanding/three-ﬂashes-or-below-threshold.html

Reference: WCAG 2.1 - 2.3.1

Evaluator action: The evaluator will test it manually and by using web accessibility tool to check the
conformity of this checkpoint.

Statement: A mechanism is available to bypass blocks of content
that are repeated on multiple Web pages.
5.2.27
Beneﬁts: Web pages and applications often have content that is repeated on other pages or
screens (for example navigation links, heading graphics, banner frames etc). A sighted user can
ignore the repeated material by focusing on the main content area, but it is not possible for a person
using a screen reader as the content is read sequentially.
Government organisation action: None.
Developer action: Developers must provide a mechanism to bypass blocks of content that are
repeated on multiple Web pages. This may be done by:
(a) providing a link at the top of each page that goes directly to the main content area.
(b) providing a link at the beginning of the content block to go to the end of the block
(c) providing links at the top of each page that go to each area of content.
(d) Controls and programmatic focus can also be used to bypass blocks of content.

https:/ www.w3.org/WAI/WCAG21/Understanding/bypass-blocks.html

Reference: WCAG 2.1 - 2.4.1

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

65

<!-- page 66 -->

5. Guidelines

Statement: Web pages/app screens have titles that
describe topic or purpose.

5.2.28

Beneﬁt: This facilitates an easy and unambiguous identiﬁcation of the webpage & also helps in a
more relevant and visible presence in the search engine results. Further, it is important since the
screen readers used by the visually impaired users ﬁrst read the title of the page and in case the
title is not explanatory enough, it may confuse or mislead them.
Government organisation action: The government organisation must ensure that title is complete
with the topic of the page. For the top-level page i.e., homepage/homescreen the name of the
country must be included, for instance, instead of the title being just Ministry of Health and Family
Welfare, it should state, Ministry of Health & Family Welfare, Government of India. Alternatively, in
case of a State ‘Department of Health, Government of Karnataka, India’ Government Department, it
should state ‘Department of Health, Government of Karnataka, India’.
Developer action: there are scenarios when the Web page has a title, but the title does not identify
the contents or purpose of the Web page. This may be caused because—
(a) Authoring tool default page titles, such as: "Enter the title of the HTML document here," "Untitled
document" or "No title";
(b) Empty text in title;
(c) Filler or placeholder text; and
(d) A website generated using templates includes the same title for each page.
The developer should ensure that the above does not affect the page title.

https:/ www.w3.org/WAI/WCAG21/Understanding/page-titled

Reference: WCAG 2.1 - 2.4.2

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: If a Web page can be navigated sequentially and
the navigation sequences affect meaning or operation, focusable
components receive focus in an order that preserves meaning
and operability.
5.2.29
Beneﬁts: When users navigate sequentially through content, they should encounter information in
an order that is consistent with the meaning of the content and can be operated from the keyboard.
Hence if a Web page can be navigated sequentially and the navigation sequences affect meaning
or operation, focusable components must receive focus in an order that preserves meaning and
operability.

66

<!-- page 67 -->

5. Guidelines

Government organisation action: Ensure correct reading order in PDF documents by structuring
the document correctly in the authoring tool used to create the document before conversion to
tagged PDF. Pages with complex layouts with graphics, tables, footnotes, sidebars, form ﬁelds and
other elements may not convert to tagged PDF in the correct reading order. These inconsistencies
must then be corrected with repair tools such as Acrobat.
Developer action: Ensure that interactive elements on a webpage receive focus in an order that
follows sequences and relationships in the content. When designing the content, the interactive
elements such as links and form controls must be placed in the content so that the default tab
order follows the sequences and relationships in the content. Correct tab and reading order must
also be ensured in PDF documents by using a tool for authoring PDF.

https://www.w3.org/WAI/WCAG21/Understanding/focus-order

Reference: WCAG 2.1 - 2.4.3

Evaluator action: The evaluator will test it manually and by using the assistive technology to check
the conformity of this checkpoint.

Statement: The purpose of each link can be determined from the
link text alone or from the link text together with its
programmatically determined link context, except where the
of the link would be ambiguous to users in general.
5.2.30
Beneﬁt: This helps users understand the purpose of each link so they can decide whether they
want to follow the link. Assistive technology has the ability to provide users with a list of links that
are on the Web page. Link text that is as meaningful as possible will aid users who want to choose
from this list of links. Meaningful link text also helps those who wish to tab from link to link.
Meaningful links help users choose which links to follow without requiring complicated strategies to
understand the page.
Government organisation action: None.
Developer action: Developer must ensure that the text of, or associated with, the link describes the
purpose of the link. In cases where the link takes one to a document or a web application, the name
of the document or web application would be sufﬁcient to describe the purpose of the link however
it is not mandatory to use the name of the document or web application; other things may also
describe the purpose of the link.

https:/ www.w3.org/WAI/WCAG21/Understanding/link-purpose-in-context

Reference: WCAG 2.1 - 2.4.4

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

67

<!-- page 68 -->

5. Guidelines

Statement: More than one way is available to locate a web page
within a set of web pages except where the web page is the
result of, or a step in, a process.
5.2.31
Beneﬁts: Providing multiple navigation options can help people ﬁnd information faster, particularly
those with visual or cognitive impairments. For instance, a person with a visual impairment may
prefer using a search feature instead of scrolling through a large navigation bar with a screen reader.
Similarly, a person with cognitive limitations may ﬁnd a site map or table of contents more useful
than a hierarchical navigation scheme.
Government organisation action: None.
Developer action: Developers must include either a “Search” box or a link to a “Search” page from
every page of the website. The search box or link must be titled “Search”, as it is a standard term
understood by web surfers worldwide. As per internationally accepted Usability principles, search
boxes are most effective when placed in the same position on all pages (usually within the upper
third part of the webpage). Additionally, a sitemap or a link to all the pages of the website from the
homepage/homescreen or a table of contents must be provided

https:/ www.w3.org/WAI/WCAG21/Understanding/multiple-ways

Reference: WCAG 2.1 - 2.4.5

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: Headings and labels describe topic or purpose. 5.2.32
Beneﬁt: It is imperative that the information and services on the website/app are well organised and
categorised into relevant modules/sections and sub-sections so that any information can be
located conveniently and is not buried deep inside Webpages. These sections or categories may be
identiﬁed with headings or labels. Headings and Labels wherever used must correctly describe the
topic or purpose of content.
Government organisation action: None.
Developer action: Developers must specify headings using HTML heading tags (H1 to H6) with
proper hierarchy. When headings are clear and descriptive, users can ﬁnd the information they seek
more easily and they can understand the relationships between different parts of the content more
easily. Developers must also provide descriptive labels to help users identify speciﬁc components
within the content. Labels and headings do not need to be lengthy. A single word may sufﬁce if it
provides an appropriate cue to ﬁnding and navigating content.

https://www.w3.org/WAI/WCAG21/Understanding/headings-and-labels

Reference: WCAG 2.1 - 2.4.6

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

68

<!-- page 69 -->

5. Guidelines

Statement: Any keyboard operable user interface has a mode of
operation where the keyboard focus indicator is visible.
5.2.33
Beneﬁt: This helps the user know which element among the multiple elements present in the page
has focus. For e.g., in case of a button a visual change in the button (e.g., colour, size) can indicate
that the focus is on the button.
Government organisation action: None.
Developer action: When standard controls are used the users are informed of the focus location
in a standard, predictable way. Visual appearance may also be enhanced via style sheets to
provide visual feedback when an interactive element has focus or when a user hovers over it using
a pointing device.

https:/ www.w3.org/WAI/WCAG21/Understanding/focus-visible

Reference: WCAG 2.1 - 2.4.7

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: All functionality that uses multipoint or path-based
gestures for operation can be operated with a single pointer
without a path-based gesture, unless a multipoint or
5.2.34
path-based gesture is essential.
Beneﬁt: This is particularly beneﬁcial for those with cognitive or learning disabilities who may not
understand custom gesture interactions. The beneﬁts of providing alternative means for operating
touchscreen or mouse-based content, particularly for users who may have physical, cognitive, or
learning disabilities that these users can still effectively interact with the content. This can help to
ensure that digital experiences are more inclusive
and accessible for all users.
Government organisation action: None.
Developer action: Developer must provide
controls to achieve the same result as path based
or multipoint gestures

https:/ www.w3.org/WAI/WCAG21/Understanding/pointer-gestures.html

Reference: WCAG 2.1-2.5.1

Evaluator action: The evaluator will test it manually
to check the conformity of this checkpoint.

69

<!-- page 70 -->

5. Guidelines

Statement: For functionality that can be operated using a
single pointer, at least one of the following is true:

5.2.35

(a) No Down-Event: The down-event of the pointer is not used to execute any part of the
function;
(b) Abort or Undo: Completion of the function is on the up-event and a mechanism is available
to abort the function before completion or to undo the function after completion;
(c) Up Reversal: The up-event reverses any outcome of the preceding down-event;
(d) Essential: Completing the function on the down-event is essential.
Beneﬁts: This will help users to prevent accidental or erroneous pointer input by allowing them to
cancel pointer operations. The preferred method for cancellation is the up-event, which occurs
when a touchscreen or mouse pointer is released. This will beneﬁt all users by reducing the chance
of accidental activation and ensuring a means of undoing or aborting an action is available.
Government organisation action: None.
Developer action: Incorporate pointer cancellation by making activation occur on the up-event.
This can be done by using the default behaviour of controls and not override that behaviour with an
explicit down-event trigger. The up-event is the default behaviour for almost all controls and any
programming or markup language. Also, for drag and drop events it must be ensured that users who
use a path-based drag-and-drop action to move an item from the initial location to a drop target
can abort the action after picking up the target. This can be done either by releasing the item
outside a drop area, or by moving the item back to its original position in a separate action that
undoes the ﬁrst action e.g., a website shows a ﬁle directory. Files can be picked up and moved over
a trash can icon. When the picked-up ﬁle is released outside this target, it reverts to the old
position.

https:/ www.w3.org/WAI/WCAG21/Understanding/pointer-cancel ation

<title>

Reference: WCAG 2.1- 2.5.2

Evaluator action: The evaluator will test the

HTML5

website manually to check the conformity of
this checkpoint.

<label>

<script>
JAVASCRIPT

<head>
CSS3

<div>

70

<form>

<button>

<!-- page 71 -->

5. Guidelines

Statement: For user interface components with labels that include
text or images of text, the name contains the text that is
5.2.36
presented visually.
Beneﬁts: This will allow users with disabilities to interact with the components using speech
recognition or text-to-speech technologies more easily and with greater predictability. It is
important to determine which text on the screen should be considered a label for any given control
and to bias towards treating only the adjacent text as a label. The beneﬁts of implementing this
Success Criterion include more efﬁcient navigation for speech-input users and a better experience
for text-to-speech users.
Government organisation action: None.
Developer action: Ensure that the words and characters in the visible label of a control match or
are contained within the programmatic name, also known as the Accessible Name.

https://www.w3.org/WAI/WCAG21/Understanding/label-in-name

Reference: WCAG 2.1- 2.5.3

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: Functionality that can be operated by device motion or
user motion can also be operated by user interface components
and responding to the motion can be disabled to prevent
accidental actuation, except when:
5.2.37
(a) Supported Interface: The motion is used to operate functionality through an accessibility
supported interface;
(b) Essential: The motion is essential for the
function and doing so would invalidate the activity;
(c) Functionality that can be operated by device
motion or user motion must also be operable by
user interface components and responding to
the motion can be disabled to prevent accidental a
ctuation, except when:
(i) Supported Interface: The motion is used to
operate functionality through an accessibility
supported interface;
(ii) Essential: The motion is essential for the function
and doing so would invalidate the activity.

71

<!-- page 72 -->

5. Guidelines

Beneﬁts: This will help users with disabilities who may not be able to use device sensors or perform
certain movements, as well as users who are unable to move their devices. By providing alternative
methods of operating all functionality, this success criterion ensures that everyone can access and
use web content.
Government organisation action: None.
Developer action: In Devices that have sensors that can act as inputs, (such as accelerometer and
gyroscope sensors on a phone or tablet device) and allow the user to control something by simply
changing the orientation or moving the device in particular ways the functionality offered through
motion must also be available by another mechanism. The user must also have the ability to turn off
motion actuation to prevent accidental triggering of functions due to tremors or other motor
impairments.

https://www.w3.org/WAI/WCAG21/Understanding/motion-actuation

Reference: WCAG 2.1- 2.5.4

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: The default human language of each Web page can be
programmatically determined.
5.2.38
Beneﬁts: This ensures that users with disabilities, who rely on assistive technologies to access the
content, can understand it better. It beneﬁts people who have difﬁculty reading written material or
recognizing characters and alphabets, those with certain cognitive or learning disabilities who use
text-to-speech software and those who rely on captions for synchronised media.
Government organisation action: None.
Developer action: Default language of the page
must be indicated programmatically by the use
of the lang attribute. In PDF document default
language can be set using the Lang entry in the
document catalogue. Specifying the default language
in the HTTP header in relevant situations can be
considered.

https://www.w3.org/WAI/WCAG21/Understanding/language-of-page.html

Reference: WCAG 2.1 - 3.1.1

Evaluator action: The evaluator will test it

manually to check the conformity of this checkpoint.

72

<!-- page 73 -->

5. Guidelines

Statement: The human language of each passage or phrase in the
content can be programmatically determined except for proper
names, technical terms, words of indeterminate language and
words or phrases that have become part of the vernacular
5.2.39
of the immediately surrounding text.
Beneﬁts: This will help people who have difﬁculty reading, recognizing characters and alphabets,
decoding words and understanding phrases, as well as people with certain cognitive, language and
learning disabilities who use text-to-speech software.
Government organisation action: None.
Developer action: If there are any changes in the default language of the document, either in the
document’s text or any text equivalents (e.g., captions), they also be clearly identiﬁed using the lang
attribute. The language for a passage or phrase can be speciﬁed with the Lang entry in PDF
documents.

https:/ www.w3.org/WAI/WCAG21/Understanding/language-of-parts

Reference: WCAG 2.1 - 3.1.2

Evaluator action: The evaluator will test it manually and by using the Accessibility extension to
browser/ Accessibility plug-in/Web Accessibility tool/ Assistive Technology to check the
conformity of this checkpoint.

Statement: When any user interface component receives focus,
it does not initiate a change of context.
5.2.40
Beneﬁts: This aims to prevent unexpected context changes that can be especially problematic for
people with visual disabilities, cognitive limitations and motor impairments. By ensuring that focus
changes are predictable and consistent, this improves the usability and accessibility of web
content.
Government organisation action: None.
Developer action: Ensure that all changes of context are triggered only by a speciﬁc action on the
part of the user. Further, that action is the one that usually causes changes in context, such as
clicking on a link or pressing a submit button. Actions that simply move the focus to an element
must not cause a change of context.

https://www.w3.org/WAI/WCAG21/Understanding/on-focus.html

Reference: WCAG 2.1 - 3.2.1

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

73

<!-- page 74 -->

5. Guidelines

Statement: Changing the setting of any user interface component
does not automatically cause a change of context unless the user
has been advised of the behaviour before using
5.2.41
the component.
Beneﬁts: It helps users with visual and cognitive disabilities by providing additional cues to detect
changes of context, reducing the chances of disorientation and enhancing their ability to use the
content. Users who are unable to detect changes of context are less likely to become disoriented
while navigating a site, making the content more accessible to a wider range of users.
Government organisation action: None.
Developer action: Provide a submit button to initiate a change of context or if change in context
occurs provide information to users about what will happen when a change to a form control results
in a change of context

https://www.w3.org/WAI/WCAG21/Understanding/on-input

Reference: WCAG 2.1 - 3.2.2

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: Navigational mechanisms that are repeated on multiple
Web pages within a set of Web pages occur in the same relative
order each time they are repeated, unless a change is
5.2.42
initiated by the user.
Beneﬁts: This is particularly helpful for individuals with low vision who use screen magniﬁcation or
visual cues to navigate the website. Ensuring that repeated components occur in the same order on
each page of a website helps users with cognitive limitations, intellectual disabilities and those who
are blind to become comfortable with the website's structure and easily ﬁnd what they are looking
for.
Government organisation action: None.
Developer action: Ensure presenting components that are repeated in web pages in the same
relative order each time they appear. Other components can be inserted between them, but their
relative order is not changed. Similarly in navigational components links or programmatic references
must be presented inside a navigational component in the same relative order each time the
navigational component is repeated. Other links can be removed or inserted between the existing
ones, for example to allow navigation inside a subsection of a set of Web pages, but the relative
order is not changed.

https://www.w3.org/WAI/WCAG21/Understanding/consistent-navigation

Reference: WCAG 2.1 - 3.2.3

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

74

<!-- page 75 -->

5. Guidelines

Statement: Components that have the same functionality within a
set of Web pages are identiﬁed consistently.
5.2.43
Beneﬁts: This will help people who use screen readers to navigate and operate a website more
easily, as they rely on their familiarity with functions that may appear on different pages. It also
beneﬁts people with cognitive limitations and those who have difﬁculty reading or detecting text
alternatives. Consistent labelling and text alternatives enable people to ﬁnd desired functions on
other pages if they are present, interact with non-text content in a consistent way and have a more
predictable and consistent experience while navigating a website.
Government organisation action: None.
Developer action: Apply consistent labels on user interface components (i.e., elements, links,
JavaScript objects, etc.) that have the same function e.g., A Web page has a form ﬁeld at the top of
the page labelled "Search". On the bottom of the page is another form ﬁeld which provides the same
function. It is also labelled "Search."

https://www.w3.org/WAI/WCAG21/Understanding/consistent-identiﬁcation

Reference: WCAG 2.1 - 3.2.4

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: If an input error is automatically detected, the item that
is in error is identiﬁed and the error is described to the
user in text.
5.2.44
Beneﬁts: This helps users, including those who are blind or
have cognitive or learning disabilities, to understand that
an error has occurred and how to correct it. By providing
text-based error messages, users who cannot perceive
visual cues, such as colour or icons, are also able to
understand the error message. This improves the
accessibility of web forms and makes them more
usable for a wider range of users.
Government organisation action: None.
Developer action: Error must be identiﬁed to the user in
text. It is perfectly acceptable to indicate the error in
other ways such as image, colour etc, in addition to the
text description.

https://www.w3.org/WAI/WCAG21/Understanding/error-identiﬁcation.html

Reference: WCAG 2.1 - 3.3.1

Evaluator action: The evaluator will test it manually to
check the conformity of this checkpoint.

75

<!-- page 76 -->

5. Guidelines

Statement: Labels or instructions are provided when content
requires user input.
5.2.45
Beneﬁts: This beneﬁts user, especially those with disabilities, by providing clear and unambiguous
instructions that help them enter information correctly and avoid incomplete or incorrect form
submissions. The goal is to provide enough information for users to accomplish tasks without undue
confusion or navigation, without cluttering the page with unnecessary information.
Government organisation action: None.
Developer action: Developers must present instructions or labels that identify the controls in a
form so that users know what input data is expected. In the case of radio buttons, checkboxes,
combo boxes, or similar controls that provide users with options, each option must have an
appropriate label. Instructions or labels may also specify data formats for data entry ﬁelds,
especially if they are out of the customary formats or if there are speciﬁc rules for correct input.
Developers may also make such instructions available to users only when the individual control has
focus, especially when instructions are long and verbose.

https://www.w3.org/WAI/WCAG21/Understanding/labels-or-instructions

Reference: WCAG 2.1 - 3.3.2

Evaluator action: The evaluator will test it manually and by using the Accessibility extension to
browser/ Accessibility plug-in/Web Accessibility tool to check the conformity of this checkpoint.

Statement: If an input error is automatically detected and
suggestions for correction are known, then the suggestions are
provided to the user, unless it would jeopardise the
5.2.46
security or purpose of the content.
Beneﬁts: This will help users with disabilities to understand how to correct errors and ﬁll in forms
successfully. Providing information about how to correct input errors can beneﬁt users with learning
disabilities, visual impairments and motion impairments by making it easier for them to understand
the nature of the error and how to correct it and reducing the number of times they need to change
an input value. This improves the overall accessibility and usability of it or application for a wider
range of users.
Government organisation action: None.
Developer action: Provide text descriptions to identify required ﬁelds that were not completed
while submitting a form or provide the correct format if the values entered in a ﬁeld have an
incorrect format.

https:/ www.w3.org/WAI/WCAG21/Understanding/error-suggestion

Reference: WCAG 2.1 - 3.3.3

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

76

<!-- page 77 -->

5. Guidelines

Statement: For webpages that cause legal commitments or
ﬁnancial transactions for the user to occur, that modify or delete
user-controllable data in data storage systems, or that submit user
test responses, at least one of the following is true:
5.2.47
(a) Submissions are reversible;
(b) Data entered by the user is checked for input errors and the user is provided with an
opportunity to correct them; and
(c) A mechanism is available for reviewing, conﬁrming, and correcting information before
ﬁnalising the submission.
Beneﬁts: This beneﬁts users with disabilities who may be more likely to make mistakes due to
reading or motor impairments and helps prevent costly errors that could result in ﬁnancial loss or
data loss. By providing safeguards to avoid serious consequences, this success criterion improves
the accessibility and usability of it or application for all users, not just those with disabilities.
Government organisation action: None.
Developer action: Provide safeguards as above to avoid serious consequences resulting from
mistakes helps users with all disabilities who may be more likely to make mistakes.

https://www.w3.org/WAI/WCAG21/Understanding/error-prevention-legal-ﬁnancial-data

Reference: WCAG 2.1 - 3.3.4

Evaluator action: The evaluator will test it manually to check the conformity of this checkpoint.

Statement: In content implemented using markup languages,
elements have complete start and end tags, elements are nested
according to their speciﬁcations, elements do not contain
duplicate attributes and any IDs are unique, except where
the speciﬁcations allow these features.
5.2.48
Beneﬁts: This will help prevent different user agents from rendering the content differently or being
unable to parse it, which can lead to accessibility issues for users with disabilities. By requiring that
web content be correctly structured, with complete start and end tags and proper nesting, this
helps ensure that assistive technologies can parse the content accurately and without crashing,
which improves the accessibility and usability of the website or application for all users.
Government organisation action: None.

77

<!-- page 78 -->

5. Guidelines

Government organisation action: None.
Developer action: Developers must validate the markup to ensure that it is as per the standards

https://www.w3.org/WAI/WCAG21/Understanding/parsing.html

Reference: WCAG 2.1 - 4.1.1

Evaluator action: The evaluator will test it manually and by using the Accessibility extension to
browser/ Accessibility plug-in/Web Accessibility tool to check the conformity of this checkpoint.

Statement: For all user interface components (including but not
limited to form elements, links and components generated by
scripts), the name and role can be programmatically determined;
states, properties and values that can be set by the user can be
programmatically set; and notiﬁcation of changes to these
items is available to user agents, including assistive
5.2.49
technologies.
Beneﬁts: This ensures that user interface controls in web content can be accurately interpreted
and controlled by assistive technologies. By providing role, state and value information for all user
interface components, people with disabilities who use assistive technology such as screen
readers or speech recognition software can more easily access and navigate web content. This can
improve their overall user experience and help them more fully participate in online activities.
Government organisation action: None.
Developer action: Developers who develop or script their own user interface components must
provide role, state and value information on all such
components

https://www.w3.org/WAI/WCAG21/Understanding/name-role-value

Reference: WCAG 2.1 - 4.1.2

Evaluator action: The evaluator will test it
manually and by using the Accessibility
extension to browser/ Accessibility
plug-in/Web Accessibility tool/ Assistive
Technology to check the conformity of this
checkpoint.

78

<!-- page 79 -->

5. Guidelines

Statement: In content implemented using markup languages,
status messages can be programmatically determined through
role or properties such that they can be presented to the user by
assistive technologies without receiving focus.
5.2.50
Beneﬁts: It beneﬁts blind and low vision users of assistive technologies by enabling compatibility
with screen readers and may also beneﬁt users with cognitive disabilities. Properly assigning roles
or properties to status messages allows for possible future uses and personalization
opportunities, while also providing additional information to users without affecting their current
point of regard. Additionally, assistive technologies may choose to delay, suppress, or transform
such messages based on the user's preferences.
Government organisation action: None.
Developer action: The status message provides information to the user on the success or results
of an action, on the waiting state of an application, on the progress of a process, or on the
existence of errors; the message is not delivered via a change in context.
Reference:https://www.w3.org/WAI/WCAG21/Understanding/status-messages.html
WCAG 2.1– 4.1.3
Evaluator action: The evaluator will test it manually and by using the Accessibility extension to
browser/ Accessibility plug-in/Web Accessibility tool/ Assistive Technology to check the
conformity of this checkpoint.

79

<!-- page 80 -->

5. Guidelines

Cybersecurity

P

5.3

Protecting web resources from unauthorised use, access,
changes, destruction, or disruption is generally termed as
“Website Security” or “Secured Website”.

Sometimes web resources become unavailable due to
denial-of-service attacks or display modiﬁed information on the
webpages. Millions of passwords, email addresses and credit card
details have been leaked into the public domain exposing web users
to both personal embarrassment and ﬁnancial risks. The purpose of
Website Security is to prevent such risks.
Website Security requires vigilance in all aspects starting from
design, coding and implementation to testing and deployment.
Organisations should implement appropriate security majors,
defences and countermeasures to protect web resources against
malfunctioning, phishing, cyber-crimes or cyberattacks to avoid
80
