---
doc_id: "aaef671fc6a2bd03"
source_url: "https://schooledn.py.gov.in/webPolicy/prypolicy.pdf"
ministry: "District Institute of Education and Training (DIET), Puducherry"
title: "PRIVACY POLICY"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b58a3aa57df7d163"
---

<!-- page 1 -->

PRIVACY POLICY

The site http://schooledn.puducherry.gov.in does not capture any specific personal
information from you, (like name, phone number or e-mail address), that allows us to
identify you individually.
If this Portal requests you to provide personal information, you will be informed for the
particular purposes for which the information is gathered and adequate security measures
will be taken to protect your personal information.
We do not sell or share any personally identifiable information volunteered on this Portal
site to any third party (public/private). Any information provided to this Portal will be
protected from loss, misuse, unauthorized access or disclosure, alteration, or destruction.
We did not gather any certain information about the User, such as Internet protocol (IP)
addresses, domain name, browser type, operating system, the date and time of the visit and
the pages visited. We make no attempt to link these addresses with the identity of
individuals visiting our site unless an attempt to damage the site has been detected.
