---
doc_id: "5099fdeee91bbee2"
source_url: "https://py.gov.in/sites/default/files/port21012026not.pdf"
ministry: "Forest and Wild Life Department, Puducherry"
title: "Recruitmen Cancellation Notification"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bc374e0045db888a"
---

<!-- page 1 -->

A-12024/32/2025-O/o JAO/Port

I/31097/2026

GOVERNMENT OF PUDUCHERRY
PORT DEPARTMENT
*x*x*x
No.194161/Port/Estt/A2/2026
Puducherry, dt.21-01-2026

NOTIFICATION
The Notification No. 1000/1/Port/Esst/A2/2022-23/1762 dated
05/12/2022 issued by the Port Department, Puducherry in connection with
Direct Recruitment to the post of Junior Engineer (Mechanical) in the Port
Department is hereby stands cancelled. Fresh Notification in this regard will
be released in due course.

(SHIVRAJ MEENA)
DIRECTOR OF PORTS
