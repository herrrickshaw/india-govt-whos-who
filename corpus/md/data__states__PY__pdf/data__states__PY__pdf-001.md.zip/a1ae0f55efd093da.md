---
doc_id: "a1ae0f55efd093da"
source_url: "https://obps.py.gov.in/Images/Guidelines_for_proposal.pdf"
ministry: "Online Building Permission System, Puducherry"
title: "Guidelines for preparation of drawings for OBPS"
date: ""
pages: 22
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5617a39ca8bbe7df"
---

<!-- page 1 -->

GOVERNMENT OF PUDUCHERRY

PLANNING AUTHORITIES
(PUDUCHERRY, KARAIKAL, MAHE & YANAM)

GUIDELINES FOR PREPARATION OF DRAWINGS FOR OBPS
(Industrial Commercial & Residential Buildings – All Categories)

1

<!-- page 2 -->

Contents
INTRODUCTION
SALIENT FEATURES OF THE OBPS
PREPARATION OF DRAWINGS

2

<!-- page 3 -->

INTRODUCTION
The Online Building Permission System (OBPS) is an integrated platform
developed by NIC, Puducherry, to facilitate issuance of building plan approvals for
Residential, Commercial, and Industrial developments through online. The
Department’s web portal (https://obps.py.gov.in) has been upgraded to include the
DIGIT e-DCR open source application for all categories of buildings, enabling
automated scrutiny of building plans. This ensures that all projects—whether a
residential building, a retail outlet, a commercial complex or a manufacturing unit—
are evaluated with technical precision and speed.
Submission and Scrutiny Process
Registration: Owners and developers of Residential, Commercial, and Industrial
sites must submit applications through Registered Technical Personnel (RTP)
enrolled with the respective regional Planning Authorities.
Compliance: All building plans must be prepared according to Puducherry Building
Bye-Laws and Zoning Regulations, 2012& its amendment, specifically formatted for
e-DCR software compatibility.
Auto-Scrutiny: The system automatically validates plans against zoning regulations,
Coverage, FAR limits, setback and specific category requirements (such as industrial
safety setbacks or commercial parking standards etc.,).

Reporting: If the plan is compliant, a report is generated; if not, a Query Report is
issued detailing the specific non-conformities to be rectified.

<!-- page 4 -->

Inspections and Final Approval
Once the system accepts the plan and the online fees are remitted, the Scrutiny
Officer will conduct a site inspection at a pre-fixed time. For Industrial and
Commercial projects, this ensures that the site's physical conditions align with the
higher-density requirements of those zones.
Following a successful inspection and verification of conformity with all rules in
force, the application is forwarded online to the Competent Authority for final
approval. The entire cycle of the application—from payment to final issuance—is
tracked online, with status updates sent via SMS and email.

<!-- page 5 -->

SALIENT FEATURES OF THE OBPS
➢ Online scrutiny of building plans and details, for compliance with the various

provisions of the Puducherry Building Bye Laws and Zoning Regulations, 2012 &
Town and Country Planning Act, 1969.
➢The drawings can be prepared using any drafting tool/software, like AUTOCAD,

LibreCAD, etc., including the open source/ free software.
➢An overall transformation in the concept of conventional plan scrutiny process.
➢ Elimination of human interventions in plan scrutiny of building plans.
➢ Time Bound disposal of application & prompt issue of permit.
➢Complete transparency in the process of scrutiny and issuance of building plan

approval.
➢ Clear understanding of the various provisions of the Puducherry Building Bye

Laws & Zoning Regulations, 2012& its amendment.
➢ Facilities for easy confirmation with the rules prior to official submission of

application for approval.
➢ Plans complying with the norms of Puducherry Building Bye Laws and Zoning

Regulations can only be officially submitted for building plan approval, which avoids
time delay.

5

<!-- page 6 -->

PREPARATION OF DRAWINGS
 All drawings shall be drawn in 1:1 scale, in meters, in model space. i.e. to the
Layout size of A0, A1, A2, etc.
 All required details as per this guideline shall be submitted in a single drawing,
drawn in model space.
 All details shall be furnished using closed polygon with polylines, lines, texts,
dimensions etc. to be incorporated inlayers, index colors as specified in this
guideline.
 It is advisable to keep the .dxf drawing with bare minimum details, which are
required by the system for rules validation.
 The drawing shall be saved in dxf format and to be uploaded for rule
validation.
 Separate drawings (Floor plan, elevations, sections, site plan, setback details,
septictank&soakpit/leachpit/openwelldetailsetc.)incorporatingalldetails as per
Puducherry Building Bye Laws and Zoning Regulations, 2012, set to the scale
and paper sizespecified, shall be prepared, saved as pdf, and these pdf files
are tobe separately uploaded after the .dxf drawings uploaded for rule
validation, is accepted by the system to the respective scale size/layout size.
 Cross Sectional plan should be drawn with maximum information.
 In pdf drawing uploaded,enough blank space as shown in model plans shall be
kept on bottom right corner of every sheet, for approval stamping.
 Complete details of the registered engineer/supervisor & applicant have to be
mentioned in the plan instead of signature of the applicant and engineer.
 All polygons with poly lines shall be closed polygons, closed using<close>
command in Auto CAD or similar in other software.
6

<!-- page 7 -->

 The drawings shall be prepared by matching the various entries in the
drawings with the properties of layers of the supplied layer matrix,
downloadable from the OBPS portal.
 The layer template file, which can be downloaded along with these guidelines,
contains all the layers which are used by the system and can be made use
while creating dxf drawings required for rule validation.
 Wherever details are to be furnished as dimensions, these are to be
incorporated using dimension tools, and shall not be exploded/edited.
 Wherever one or more polygons/ dimensions/ lines/ depicting different
parameters are required to overlap, it shall be ensured that, no gaps/ spaces
are left in between.
 The use of layers/ Texts/ color conventions specified by these guidelines to
designate a parameter shall be restricted to that entity only and shall not be
used elsewhere in the drawing.
 Latitude, Longitude shall be provided in Decimals.

7

<!-- page 8 -->

PREPARATION OF BUILDING PLANS
LAYERS TO BE DRAWN:
Features

Layers

Color

New
construction/
Reconstruction
(Mandatory/
Optional)

Plot Area

PLOT_BOUNDARY

70

Mandatory

-Draw a closed polygon.
FAR(Maximum
permissible)

BLK_n_FLR_n_BLT_UP_AREA
BLK_n_FLR_n_BLT_UP_AREA_DEDUCT

Typical Floors

BLK_n_FLR_n_BLT_UP_AREA

As per sub-occupancy type

Mandatory

-Draw a closed polygon.
As per sub-occupancy type
-Draw a closed polygon.
Additionally draw a
M-Text TYPICAL_FLOOR_PLAN=1,2,n
In the same layer and
Color CodeAs per sub occupancy type
As per sub-occupancy type

Optional
(As per Design)

FAR Area Deduct

BLK_n_FLR_n_FLOOR_AREA_DEDUCT

Building Foot print

BLK_n_BLDG_FOOT_PRINT

Covered Area
(Maximum
permissible)

BLK_n_COVERED_AREA

Building Height
(Maximum
permissible)

BLK_n_HT_OF_BLDG

Plinth Height

BLK_n_PLINTH_HEIGHT

7

Mandatory

Headroom
terrace/Mummty
(Only the height)

BLK_n_MUMTY_HT

-Draw dimension only
7

Optional

Parapet/staircase
railing

BLK_n_PARAPET_HT

-Draw a closed polygon.
As per sub-occupancy type
(when it is more than one sub
occupancy, the higher order
colour codes to be used)
-Draw a closed polygon.
As per sub-occupancy type
(when it is more than one sub
occupancy, the higher order
colour codes can be used)
-Draw a closed polygon.
5

Optional
Mandatory

Mandatory

Mandatory

-Draw dimension only

-Draw dimension only

8

i) Draw dimensions for
Parapet - 3
ii) Draw dimension for
staircase railing - 2
iii) Draw dimension for
-1

Mandatory

<!-- page 9 -->

Wider Road

WIDER_ROAD

7
-Draw a closed polygon.

Setback Front

BLK_n_LVL_n_FRONT_SETBACK

Setback Rear

BLK_n_LVL_n_REAR_SETBACK

Setback Side1

BLK_n_LVL_n_SIDE_SETBACK1

Setback Side2

BLK_n_LVL_n_SIDE_SETBACK2

Guard Room

BLK_n_FLR_n_REGULAR_ROOM_DWn

Motor Room

Functional services
room, e.g.
Electrical/
Generator room,
HVAC room etc.

i) Setback dimension on
site plan using dimension
tool- 2
ii) Draw as closed polygon,
using polyline on site plan.
Polygon shall be touching
the corners of building
Block and plot boundary-2
i) Setback dimension on
site plan using dimension
tool - 2
ii) Draw as closed polygon,
using polyline on site plan.
Polygon shall be touching
the corners of building
block and plot boundary –
11
i) Setback dimension on
site plan using dimension
tool -2
ii) Left side setback-Draw
as closed polygon, using
poly line on site plan- 171

If it is mentioned as
more than one road
in plan info, then it
is Mandatory.
Mandatory

Mandatory

Mandatory

i) Setback dimension on
site plan using dimension
tool -2
ii) Left side setback - Draw
as closed polygon, using
Polyline on site plan-102
7
Use dimension tool to draw
the height -7
(Dwn – n denotes room
number 1, 2,)

Mandatory

BLK_n_FLR_n_REGULAR_ROOM_DWn

11
Use dimension tool to draw
the height -11
(Dwn – n denotes room
number 1, 2,)

Optional

BLK_n_FLR_n_REGULAR_ROOM_DWn

12
Use dimension tool to draw
the height -12
(Dwn – n denotes room
number 1, 2,)

Optional

Optional

<!-- page 10 -->

Habitable room
(Master bedroom/
First Bedroom in
case of twobedroom house)

BLK_n_FLR_n_REGULAR_ROOM_DWn

13
i) Use dimension tool to
draw the height -13

Mandatory in
case of
Residential

Habitable room
(other Bedroom/
2nd bedroom in
case of twobedroom house)

BLK_n_FLR_n_REGULAR_ROOM_DWn

14
i) Use dimension tool to
draw the height -14
(Dwn – n denotes room
number 1, 2,)

Mandatory in
case of
Residential

Habitable room
(it can be used
for any rooms
not covered )

BLK_n_FLR_n_REGULAR_ROOM_DWn

17
i) Use dimension tool to
draw the height -17
(Dwn – n denotes room
number 1, 2,)

Optional

Habitable room
(Living Room)

BLK_n_FLR_n_REGULAR_ROOM_DWn

18
i) Use dimension tool to
draw the height -18
(Dwn – n denotes room
number 1, 2,)

Optional

Habitable room
(Dining Room)

BLK_n_FLR_n_REGULAR_ROOM_DWn

19
i) Use dimension tool to
draw the height -19
(Dwn – n denotes room
number 1, 2,)

Optional

Habitable room
(Children bedroom)

BLK_n_FLR_n_REGULAR_ROOM_DWn

20
i) Use dimension tool to
draw the height -20

Optional

Habitable room
(Store room)

BLK_n_FLR_n_REGULAR_ROOM_DWn

6
i) Use dimension tool to
draw the height - 6

Optional

Habitable room
(Servant room)

BLK_n_FLR_n_REGULAR_ROOM_DWn

8
i) Use dimension tool to
draw the height -8

Optional

(Dwn – n denotes room
number 1, 2,)

9

<!-- page 11 -->

For all nonresidential
buildings
(Ex :Shop /officer/
Commercial
space/Restaurant/
Dining/Café)
(Sale Area or Work
Area)
Kitchen with store

BLK_n_FLR_n_SALE_OR_WORK_AREA

As per sub-occupancy type

- Draw a closed polygon
- Use dimension tool to
draw the height as per
sub-occupancy type

BLK_n_FLR_n_KITCHEN

Kitchen
(for all occupancies)

BLK_n_FLR_n_KITCHEN

Pantry

BLK_n_FLR_n_KITCHEN

General Staircase

BLK_n_FLR_n_STAIR_n

1
-Use dimension tool to
draw the height -1
2
-Use dimension tool to
Draw the height - 2
3
-Use dimension tool to
Draw the height-3

BLK_n_FLR_n_STAIR_n_LANDING_n

BLK_n_FLR_n_SPIRAL_FIRE_STAIR_n
BLK_n_FLR_n_FIRESTAIR_n

BLK_n_FLR_n_FIRESTAIR_n_FLIGHT_n

BLK_n_FLR_n_FIRESTAIR_n_LANDING_n

BLK_n_FLR_n_SPIRAL_FIRE_STAIR_n

Optional

Optional

Optional

i) Draw Polygon around
staircase layout - 7
ii) Add floor height in same
layer with text
FLR_HT_M=numerical value
i) Draw Polygon around
each flight in staircase -7
ii) Number of rises by
drawing lines -3
iii) Dimension for flight
width - 2
iv) Dimension for flight
length – 1
i) Polygon around each
landing - 7
ii) Dimension for flight
width - 2
iii) Dimension for flight
length-1
7

BLK_n_FLR_n_STAIR_n_FLIGHT_n

Fire Staircase

Mandatory

10

i) Draw Polygon around
staircase layout - 7
ii) Add floor height in same
layer with text
FLR_HT_M=numerical value
i) Draw Polygon around
each flight in staircase-7
ii) Number of rises by
drawing lines -3
iii) Dimension for flight
width - 2
iv) Dimension for flight
length – 1
i) Polygon around each
landing - 7
ii) Dimension for flight
width - 2
iii) Dimension for flight
length-1
7

Mandatory as per
rule

Mandatory as per
rule

Mandatory as per
rule

<!-- page 12 -->

Water Closet

BLK_n_FLR_n_WATER_CLOSET

i) Draw polygon for males1
ii) Draw polygon for
females - 2
iii) Draw polygon for
common – 3
i) Draw polygon for males1
ii) Draw polygon for
females - 2
iii) Draw polygon for
common-3

Mandatory as per
rule

Urinal

BLK_n_FLR_n_URINAL

Bath

BLK_n_FLR_n_BATH

i) Draw polygon for males1
ii) Draw polygon for
females - 2
iii) Draw polygon for
common-3
i) Draw polygon for males1
ii) Draw polygon for
females - 2
iii) Draw polygon for
common-3
i) Draw polygon for
females – 1, draw
dimension layer for
height in same color code
ii) Draw polygon for
females – 2, draw
dimension layer for
height in same color code
iii) Draw polygon for
common - 3, draw
dimension layer for
height in same color code

Mandatory as per
rule

Wash basin
(count)

BLK_n_FLR_n_WASH

Toilets

BLK_n_FLR_n_WC_BATH

North Direction

NORTH_DIRECTION

Mandatory

SOLAR_PANEL

7
M-Text N
3

Solar Panels system

Solar Water Heating
System

SOLAR_WATER_HEATER

-Draw a closed polygon
7

RWH

RWH

-Draw a closed polygon
4

Projection balcony/
Cantilever

MText –
RWH_Capacity_L=
(calculated capacity)
For Canopy -1
Any Other -2

BLK_n_FLR_n_PROJECTION

Draw a closed polygon

11

Mandatory as per
rule

Mandatory as per
rule

Mandatory as per
rule

Optional
(Rule has to be
checked and fixed)
Mandatory as per
rule
Mandatory as per
rule

Optional

<!-- page 13 -->

BLK_n_PROJECTION_TO_PLOT_LINE_DISTANCE

Draw a dimension line
For Canopy -1
Any Other – 2

BLK_n_PROJECTION_HEIGHT

Parking

7 (for front setback only)
Other color codes needs to be
introduced.
Front Setback -1
Other Setback -2

OPEN_PARKING

Draw a dimension line
7

BLK_n_FLR_n_STILT_PARKING

-Draw a closed polygon
7

BLK_n_FLR_n_COVERED_PARKING

-Draw a closed polygon
7

BLK_n_FLR_-1_COVERED_PARKING
(For basement floor & thereon -2, -3)

Optional

Optional

Mandatory as per
rule
Mandatory as per
rule
Mandatory as per

7
-Draw a closed polygon

For calculation of
BLK_n_SALE_OR_WORK_PARKING_AREA
parking area for nonresidential sub
occupancies.

As per sub-occupancy type

Distance from
Electric Lines

7

OHEL_n

-Draw a closed polygon

-Draw a closed polyline
7
-Use this M-Text to
mention the voltage –

VOLTAGE_n

Mandatory

Optional

Optional

VOLTAGE_KV=(a numerical
value of volt)
7
HORIZ_CLEAR_OHEL_n

- Draw dimensions to
measure the distance.

Optional

7
VERT_CLEAR_OHEL_n
Stilt Floor

- Draw dimensions to
measure the distance.
As per sub-occupancy type

BLK_n_FLR_n_STILT_FLOOR

Optional
Optional

-Draw a closed polygon to
show the stilt floor.

Dwelling Units

-For height use dimension
tool to draw the height- as
per sub-occupancy type
As per occupancy type

BLK_n_FLR_n_UNITFA

12

Optional

<!-- page 14 -->

Gate

Lift

MAIN_GATE

i) Draw polygon outlining
main gate size - 7
ii) Use dimension tool to
draw main gate height -1
iii) Use dimension tool to
draw main gate width-2

Optional

WICKET_GATE

i) Draw polygon outlining
wicket gate size -7
ii) Use dimension tool to
draw wicket gate height-1
iii) Use dimension tool to
draw wicket gate width-2

Optional

BLK_n_FLR_n_LIFT_n

General Lift–1
Special Lift – 2

Optional

-Draw a closed polygon
Corridor-1
Corridor/Verandah
/ Passageway

Verandah-2

BLK_n_FLR_n_PASSAGE

Optional

Passageway-3
Draw dimension only as
per the color code
provided.

Boundary Wall

Ramp

i) Draw Dimension of front
compound wall - 1
ii) Draw Dimension of
Rear compound wall -2
iii) Draw Dimension of
railing - 3

COMPOUNDWALL

BLK_n_RAMP

Optional

7
Draw a closed polygon and
provide dimension at the
width of the Ramp
(dimension color code- as
per ramp color code)
Mention text–
SLOPE=1IN8for1:8
SLOPE=1IN12for1:12
SLOPE=1IN10for1:10

13

Optional

<!-- page 15 -->

Parking/Vehicle
Ramp

BLK_n_VEHICLE_RAMP_n

Draw a closed polygon
(7 color for one-way Ramp
& 8 for two-way Ramp)
Draw a dimension line using
color 1 for width and a
dimension line using color 2 Optional
for length
Mtext SLOPE=1IN8,SLOPE_HT=2.0
SLOPE=1IN12,SLOPE_HT=
2.40
SLOPE=1IN10,SLOPE_HT=

Exit Travel Distance
(Distance between
stairs)
Roof type

DIST_EXIT

7

BLK_n_ROOF_TYPE

- Draw a dimension layer
7

DrinkingWater

BLK_n_FLR_n_DRINKING_WATER

-Draw a closed polygon at
the Roof.
7

Structure with in
Front Setback

BLK_n_STRUCTURE_n_WITHIN_FRONT_SETBACK

Structure with in
Rear Setback

BLK_n_STRUCTURE_n_WITHIN_REAR_SETBACK

i) Rear Setback dimension
on site plan using
dimension tool – color
code as per activity
ii) Draw as closed polygon,
using polyline on site plan
–color code as per activity

Optional

Structure with in
Side Setback 1

BLK_n_STRUCTURE_n_WITHIN_SIDE_SETBACK1

Optional

Structure with in
Side Setback2

BLK_n_STRUCTURE_n_WITHIN_SIDE_SETBACK2

i) Side Setback dimension
on site plan using
dimension tool – color
code as per activity
ii) Draw as closed polygon,
using polyline on site plan
–color code as per activity
i) Side Setback dimension
on site plan using
dimension tool - color
code as per activity
ii) Draw as closed polygon,
using poly line on site
plan-color code as per
activity

14

-Draw a closed polygon
i) Front Setback dimension
on site plan using
dimension tool – color
code as per activity
ii) Draw as closed polygon,
using polyline on site plan
–color code as per activity

Mandatory as per
rule
Mandatory as per
rule

Optional
Optional

Optional

<!-- page 16 -->

Service Floor

BLK_n_FLR_n_SERVICE_FLOOR

As per sub-occupancy type

Optional

- Draw a closed polygon
- For height use
dimension tool to draw
the height As per sub-occupancy type

Distance Between
Blocks

(Up to 2 service floor it is
exempted from FAR)
7

DIST_BETWEEN_BLK_1_BLK_2

Optional

- Draw a dimension layer
Septic Tank

SITE_COMPONENTS

2

Optional

- Draw a closed polygon at
the Septic Tank.
Site Plan

SITE_PLAN

7
-Draw a closed polygon
at the Site plan.

15

Optional

<!-- page 17 -->

LAYER COLOUR AS PER OCCUPANCY TYPE:
S.No.
1

Occupancy
Industrial

Sub-occupancy
White

Layer color
201

2
3
4

Industrial
Industrial
Industrial

Green
Red
Orange

202
204
203

5
6

Commercial
Commercial

Resort
Lodge, Guest Rooms

99
101

7
8

Commercial
Commercial

Restaurant
Hotel, Resort

102
103

9
10
11
12
13

Commercial
Commercial
Commercial
Commercial
Commercial

Resto Bar,Wine Shop
Residential Stay Houses
Working Hostel, Students Hostel
Orphanage, Oldage Home
Dormitory

104
105
106
107
108

14
15
16

Commercial
Commercial
Commercial

Night Shelter, Homeless Shelter
Shop, Shopping Complex, Mercantile
Petty Shop, ATM

109
110
111

17

Commercial

Office, Banks, IT Office, Training

112

18
18
20
20

Commercial
Commercial
Commercial
Commercial

Library
Store, Godown,Warehouse
LPG Distribution Gas Godown
Clinic, Dispensary, Pharmacy

113
114
115
116

21
22

Commercial
Commercial

Fuel Filling Station Office
Fuel Filling-cum-Service Station

117
118

23
24
25
26
27
28

Commercial
Commercial
Commercial
Commercial
Commercial
Commercial

Battery Charging Station
Market Building
Gymnasia
Club
Group Development(Commercial)
Swimming Pool(Commercial)

119
120
121
122
123
124

29
30

Commercial
Residential

100
25

33

Residential

CNG Fuel Station
Residence/ Residential Flats/Apartments/
Quarters
EWS Building

34

Residential

Group Development(Residence)

16

31 (It is applicable only for plot area
less than or equal to 60sqm)
32

<!-- page 18 -->

DETAILS OF PLAN INFO TO BE PROVIDED AS TEXT IN THE DRAWING FILE:
PLAN INFO
PLOT_NO=123/22
PLOT_REGION=PUDUCHERRY/KARAIKAL/MAHE/YANAM
PLOT_LOCATION=BA_EAST/BA_WEST/CTA/CBA/OTHER_AREA
LAND_USE_ZONE=RESIDENTIAL ZONE/MIXED RESIDENTIAL ZONE/COMMERCIAL ZONE/MIXED COMMERCIAL ZONE /
INDUSTRIAL ZONE / MIXED INDUSTRIAL ZONE/PUBLIC AND SEMI-PUBLIC ZONE / AGRICULTURE ZONE /
RECREATIONAL TOURISM ZONE /TRASPORTATION AND COMMUNICATION ZONE/NA
R.S.NO=112/8
WARD_NO/BLOCK_NO/T.S.NO=22
REVENUE_VILLAGE=KARAIKAL
COMMUNE/MUNICIPALITIES=KARAIKAL
PLOT_AREA_M2= numerical value
PLOT_FRONTAGE=numerical value
PLOT_WIDTH= numerical value
PLOT_DEPTH= numerical value
INDUSTRY_CATEGORY=GREEN/WHITE/ORANGE/RED/NA
IF_THE_PLOT_FALLS_UNDER_CRZ=YES/NO
MINIMUM_GENERATION_CAPACITY_OF_THE_ROOFTOP_SOLAR_PV_SYSTEM_IN_W=numerical value
CAPACITY_OF_SOLAR_WATER_HEATING_SYSTEM_IN_LPD=numerical value
THERE_IS_NO_STORAGE_OF_EXPLOSIVE_OBNOXIOUS_PRODUCTS_AND_OTHER_MATERIAL_LIKELY_TO_CAUSE_HEA
LTH_HAZARDS_AND_DANGER_TO_LIVES_IN_RESIDENTIAL_ZONE=YES/NO/NA
INDUSTRIES_POWER_REQUIREMENT_IN_HP=numerical value/NA
IN_CASE_OF_INDUSTRIAL_ESTATE_AND_APPROVED_INDUSTRIAL_LAYOUTS_THE_SETBACK_PROVIDED_ON_THE_SID
E_OF_EXISTING_RESIDENTIAL_AREA=YES/NO/NA
IS_THE_SITE_BESIDE_THE_NH_OR_ECR=YES/NO
ENSURED_LIGHTING_AND_VENTILATION_THROUGH_ARTIFICIAL_LIGHTING_AND_MECHANICAL_VENTILATION=YES/
NO/NA
NOC_FROM_ELECTRICITY_DEPARTMENT=YES/NO/NA
CRZ_CATEGORY_APPLICABLE_FOR_PLOT=CRZ_I/CRZ_II/CRZ_III_UPTO_200M/CRZ_III_200M_TO_500M/
RIVER_CREEK/NA
RWH_DECLARED=YES/NO
NOC_FROM_THE_AIRPORT_AUTHORITY_OF_INDIA_IF_THE_SITE_FALLS_IN_THE_CCZM_OF_PUDUCHERRY_OR_THE_
SITE_FALLS_WITHIN_THE_VICINITY_OF_AIRPORT=YES/NO/NA
NOC_FROM_THE_COASTAL_ZONE_MANAGEMENT_AUTHORITY_OF_PUDUCHERRY_IF_THE_SITE_FALLS_IN_THE_NO
TIFIED_AREA_OF_COASTAL_ZONE_MANAGEMENT_AUTHORITY_OR_CZMP_OF_PUDUCHERRY=YES/NO/NA
NOC_FROM_THE_NATIONAL_MONUMENT_AUTHORITY_OF_INDIA_IF_THE_SITE_FALLS_WITHIN_THE_300MTS_RADI
US_OF_ASI_IDENTIFIED_MONUMENTS=YES/NO/NA
NOC_FROM_THE_RAILWAY_AUTHORITIES_IF_THE_SITE_ABUTS_OR_FALLS_WITHIN_THE_30MTS_FROM_THE_RAIL
WAY_BOUNDARY=YES/NO/NA
NOC_FROM_THE_IRRIGATION_DIVISION_OR_PWD_OR_MUNICIPALITIES_SURVEY_AND_LAND_RECORDS_IF_THE_SIT
E_FALLS_NEAR_OR_ABUTS_THE_WATER_BODIES_LIKE_CANAL_CHANNEL_LAKE_ETC=YES/NO/NA
NOC_FROM_THE_DEPARTMENT_OF_REVENUE_AND_DISASTER_MANAGEMENT_IF_THE_LAND_UNDER_REFERENCE
_IS_RECORDED_AS_GOVERNMENT_LAND_(LA/LR)_AS_PER_THE_RECORDS_AVAILABLE=YES/NO/NA
WHETHER_SITE_ABUTS_MORE_THAN_ONE_ROAD=YES/NO
IS_THE_PROJECT_PART_OF_INDUSTRIAL_ESTATE_OR_APPROVED_INDUSTRIAL_LAYOUT=YES/NO
IS_SHEET_ROOF_PROVIDED_FOR_ANY_BLOCK=YES/NO

17

<!-- page 19 -->

THE FOLLOWING PLAN INFO IS MANDATORY IN CASE OF INDUSTRIAL OCCUPANCY:
IS_THE_PROJECT_PART_OF_INDUSTRIAL_ESTATE_OR_APPROVED_INDUSTRIAL_LAYOUT=YES/NO (If mentioned YES,
only then the below plan info in mandatory)
IF_THERE_IS_EXISTING_RESIDENTIAL_AREA_ABUTTING_THE_INDUSTRIAL_ESTATE_AND_APPROVED_INDUSTRAL_LA
YOUT=SIDE1/SIDE2/REAR
SITE ABUTTING DECLARATION
WHETHER_SITE_ABUTS_MORE_THAN_ONE_ROAD=YES/NO(If YES, both the below info’s plan is mandatory)
WIDER_ROAD_AVG_WIDTH = numerical value
NARROWER_ROAD_AVG_WIDTH=numerical value
WHETHER_SITE_ABUTS_MORE_THAN_ONE_ROAD=YES/NO (If NO, then below mentioned plan info is mandatory)
WIDER_ROAD_AVG_WIDTH= numerical value
THE FOLLOWING PLAN INFO IS MANDATORY IN CASE OF INDUSTRIAL OCCUPANCY:
OFFICES_OR_VISITOR_MALE_COUNT= numerical value
OFFICES_OR_VISITOR_FEMALE_COUNT=numerical value
WORKER_MALE_COUNT= numerical value
WORKER_FEMALE_COUNT= numerical value
THE FOLLOWING PLAN INFO IS MANDATORY IN CASE OF COMMERCIAL OCCUPANCY:
OCCUPANT_LOAD_STAFF_MALE_COUNT= numerical value
OCCUPANT_LOAD_STAFF_FEMALE_COUNT= numerical value
OCCUPANT_LOAD_PUBLIC_MALE_COUNT= numerical value
OCCUPANT_LOAD_PUBLIC_FEMALE_COUNT=numericalvalue
THE FOLLOWING PLAN INFO IS MANDATORY IN CASE OFSUB-OCCUPANCIES MENTIONED BELOW LODGE GUEST ROOMS, RESIDENTIAL STAY HOUSES, WORKING HOSTEL STUDENTS HOSTEL, ORPHANAGE OLD AGE
HOME, DORMITORY, NIGHT SHELTER HOMELESS SHELTER:
NUMBER_OF_GUEST_ROOMS =numerical value

18

<!-- page 20 -->

DETAILS OF DECLARATION OF PLOT_LOCATION IN PLAN INFO:
Puducherry Region:
Area

PLOT_LOCATION

Continuous Building Area

CBA

Other Area

OTHER_AREA

Boulevard Area(On the eastern side of Grand Canal)

BA_EAST

Boulevard Area(On the western side of Grand Canal)

BA_WEST

Karaikal Region:
Area
Continuous Building Area

PLOT_LOCATION
CBA

Other Area

OTHER_AREA

Remarks
Existing developed areas of very
old settlements.
Area other than the above.

Core Town Area

CTA

Core town area

Area
Continuous Building Area

PLOT_LOCATION
CBA

Remarks
Existing developed areas of very old
settlements.

Other Area

OTHER_AREA

Entire area of Mahe

Area
Continuous Building Area

PLOT_LOCATION
CBA

Remarks
Existing developed areas of very old
settlements.

Other Area

OTHER_AREA

Area other than the above.

Mahe Region:

Yanam Region:

19

<!-- page 21 -->

DETAILS OF ACTIVITIES PERMITTED IN THE SETBACK AREA:

Category

Motor Room
Watchman
Booth
Servant
Room
Cycle stand
Generator
Room
Toilet /
Water Closet
Pump Room
Transformer
Room
Electric Room

Color
Code

Area restriction in
case of any other
occupancy

Area restriction in
case of Industrial
occupancy

1

Up to 2sqm

2sqm

Height
restriction in
case of any
other
occupancy
Up to 1.8m

2

2.5m x2.5m

No area restrictions

Up to 3m

Up to 3m

3

No area restrictions

No area restrictions

Up to 4m

Up to 4m

4

No area restrictions

No area restrictions

Up to 4m

Up to 4m

5

No area restrictions

No area restrictions

Up to 4m

Up to 4m

6

Up to 6sqm

No area restrictions

Up to 4m

Up to 4m

7

Up to 6sqm

Up to 6sqm

Up to 4m

Up to 4m

8

Up to 15sqm

Up to 15sqm

Up to 4m

Up to 4m

9

Up to 15sqm

Up to 15sqm

Up to 4m

Up to 4m

20

Height
restriction in
case of
Industrial
occupancy
Up to1.8m

<!-- page 22 -->

22
