---
doc_id: "aafcba37f822df85"
source_url: "https://dhte.py.gov.in/sites/default/files/pkfa-G.O-16-17.pdf"
ministry: "Higher and Technical Education Department, Puducherry"
title: "G.O.Ms.No.30 dated 30-11-2016"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e6c7246babce4295"
---

<!-- page 1 -->

GOVERNMENT OF PUDUCHERRY
ABSTRACT

Chief Secretariat (Education) - Higher and Technical Education - Award of Financial
Assistance under 'Perunthalaivar Kamarajar Financial Assistance Scheme (PKFAS)' to the
students pursuing Medical, Para-Medica l and Engineering Courses in various Unaided Private
Professional Colleges of the Uni on Territory of Puducherry - Notification for the academic year
2016-17 - Orders - Issued.
CHIEF SECRETARIAT (HIGHER AND TECHNICAL EDUCATION)

Puducherry, dated:30.11.2016

G.O .Ms.No.30

Read : (i) G.O.Ms. No.57 , dated 01 .10.2013 of the Chief Secretariat (Education),
Government of Puducherry.
(ii) G.O.Ms.No.61, dated 27.10.2015 of the Chief Secretariat (Education),
Government of Puducherry.
(iii) 1.D.No.1980/DHTE/Tech/T2/PKFA/2016 dated 21.06.2016 of the
Director of Higher and Technical Education , Government of Puducherry.

ORDER:
NOTIFICATION

The provisions of the notification first read above for providing financial assistance under
'Perunthalaivar Kamarajar Fin ancial Assistance Schem e (PKFAS)' shall also be extended for
the academic year 2016-17, without any modification . The total number of students eligible for
availing the financi al assistance under the scheme shall stand amended in accordance with the
total number of students admitted in M.B.B.S., B.Tech., and B.Sc. (Nursing) courses through
Centralized Admission Committee (C ENTAC) during the academic year 2016 -17 . The rates of
financial assistance shall be the same as notified in the G.Os. first and second read above
respectively for M.B.B.S., B.Tech., and B.Sc (Nursing) courses offered in various Unaided
Private Professional Colleges of the Union territory of Puducherry.
2.
This issues with the concurrence of the Finance Department vide their
U.O.No.2102/F4/A4/FC/2016 dated 13.1 0.2016.
/By Order of the Lieutenant-Governor/

ff.Ye.Ji!~ "f~ , .,., ,,..:, ·.(r I

~7 0 rrrf'

(F. P. VERBINA JAYARAJ
UNDER SECRETARY TO GOVT. (HR. & TECH. EON.)

To
The Director of Stationery and Printing , Puducherry --- with a request to publish the above
notification in the Extra-ordinary Gazette of Puducherry and to forward 100 copies to this
Secretariat for reference and records .
Copy to:
01 . The Chief Secretary to Government, Puducherry.
02. The Chairman , Admission I Fee Committee, DHTE, PIPMATE Complex, Puducherry.
03. All Secretaries I Special Secretaries to Government, Puducherry.
04. All Secretariat Departments I Head of Depa rtm ents, Puducherry.
05. The Director of Hig her and Technical Education , Puducherry.
06. The Director of School Edu cation , Puducherry.
07. The Convenor, CENTAC, Puduch erry .
....oo'.\ The Director of Accounts and Treasuries , Pudu cherry .
09. The Deputy Director of Accounts and Treasuries , Karaikal I Mahe I Yanam.
10. The Deputy Accountant General, AG (Audit), DAT Campus, Puducherry.
11. The CRB /G .O fil e I Spare.
