---
doc_id: "ef829ee4c1e9bee4"
source_url: "https://schooledn.py.gov.in/webPolicy/LinkingPolicy.pdf"
ministry: "District Institute of Education and Training (DIET), Puducherry"
title: "LINKING POLICY"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5de40aceef6e7d6f"
---

<!-- page 1 -->

Linking Policy

Links to external websites /portals
Links to other websites/portals that have been included on this website are provided for
public convenience only. This Directorate is not responsible for the contents or
reliability of linked websites and does not necessarily endorse the views expressed
within them. Mere presence of the link or its listing on this website should not be
assumed as endorsement of any kind. This Directorate does not guarantee that these
links will work all times and this Directorate have no control over availability of linked
pages. When a link to an external website is selected, you are leaving the website of
this Directorate and are subject to the privacy and security policy of the
owners/sponsors of those external website. This Directorate cannot authorize the use
of copyrighted materials contained in linked website/portal. Users are advised to
request such authorization from the owner of the linked website/portal. This
Directorate does not guarantee that linked websites comply with Indian Government
Web Guidelines.

Links to the website of this Directorate by other websites
This Directorate does not object to you linking directly to the information that is hosted
on this website and no prior permission is required for the same. However, we would
like you to inform us about any links provided to this website so that you can be
informed of any changes or updations therein. Also, we do not permit our pages to be
loaded into frames on your site. The pages belonging to this website must load into a
newly opened browser window of the user.
