---
doc_id: "36fe0cef3f556fac"
source_url: "https://schooledn.py.gov.in/notification/sanction-PreMS.pdf"
ministry: "District Institute of Education and Training (DIET), Puducherry"
title: "Expenditure Sanction Orders - Award of Pre-Matric Scholarship to OEBC students"
date: ""
pages: 30
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "0d25535742372442"
---

<!-- page 1 -->

கு ட்‌ No. 25000(1)/DSE/Scholarship/A1/OEBC/2020 -21 ஸு
ட்‌ ___.GOVERNMENT OF PUDUCHERRY P
இ ன DIRECTORATE OF SCHOOL EDUCATION = |
ட னு Puducherry, dated [4/06/202(
ட்‌ ORDER
“4 Sub: DSE- Scholarship- Award of Pre- matric Scholarship to Other Economically Backward Class students —
5 Fresh and Renewal for the year 2019 - 20 (left-out cases) through Direct BeneficiaryTransfer (DBT) for the
uy Students studying in GHSS,GHS,G.M.S, Private High School , Private Hr. Sec, School of Puducherry,
ga Karaikal, and Mahe Region - Expenditure Sanction- Accorded.
டீ Ref: 1.0. 0. Rt. No. 146 dated 28.11.2005 of the Chief Secretariat(Education-Il), Puducherry.
: 2.G.0.Ms. No.47/F3/2014 dated 09.12.2014 of the Finance Department, Puducherry.
ப In pursuance of the 6.05 cited under reference (1) & (2) above, the expenditure sanction of the undersigned is
hereby accorded to incur an expenditure not exceeding to Rs.1,85,000/- ( Rupees One lakh and eighty five thousand
: only) towards the award of Pre-miutric Scholarship to OEBC students for 307 Nos. studying in GHSS,GHS,G.M.S;
Private High School, Private Hr. Sec. School of Puducherry, Karaikal and Mahe Region during the year 2019-20 (left-
out cases) as detailed in the Annexure. —_—_
2. The bill shall be prepared by the concerned D..&_D.Os/. schools-on-receipt-of-the-sanctlon order aiid
present the bills with DAT along with Authorization slip generated from BEAMS, and “E-form” from PACT after
i obtaining necessary BCR entries from the scholarship section of this Directorate. The amount drawn by the
heat concerned Drawing and Disbursing Officer transferred through ECS by the DAT should be disbursed to the students
க concerned through Direct Beneficiary Transfer mode for the amount transferred in the Bank, where the Drawing and
Disbursing Officer is holding the Account. The particulars of the student such as Bank A/c No., IFS code of the Bank,
ம்‌ Aadhaar No. of the student are already available with the Drawing and Disbursing Officers concerned, which was
i submitted by the students/Schools under their control. A Disbursement Certificate along-with the list of students to
்‌ whom the scholarship has been disbursed through Direct Beneficiary Transfer system by the Bank should be sent to this
Directorate immediately for furnishing the same to the Finance department, Puducherry.
3. The Head of Institution have certified that all the applicants satisfy the conditions prescribed for the grant of Pre-
matric Scholarship and that the current rate of scholarship is in accordance with G.O.Ms.No.146 dated 28.11.2005 of
Chief Secretariat (Education), Puducherry.
்‌ 4, It should also be ensured by the Head of Institution that the scholarship should be allowed only for the actual
. number of months they studied in their respective class. The Head of Institution concerned shall ensure before
disbursement that the students are not in receipt of any other scholarship from the Education Department or any other
i Government Department.
5. The Expenditure is debitable to the Head of Account "17- 2225 - Welfare of Scheduled castes, Scheduled Tribes
1 and Other Backward Classes and Minorities- 01- Welfare of Scheduled Castes — 01/277-Education-01/277(01) Award of
Pre Matric scholarship to Other Economically Backward Class students " .
{ | —__Head of Account [Amount | ள்ள
et வகார காளை
* Puducherry Region Rs. 1,15,000 183
Be தை கக க கை
5 Karaikal Region Rs. 30,000 வ களைப்‌
ந ணை ணன்‌ வளை
t Mahe Region 75. 40,000
டட ட்டை 1 “மை. னு
in the current financial year.
j “த ்‌ (P.T.RUDRA GOUD)
. DIRECTOR OF SCHOOL EDUCATION
்‌ To 4 7
1. The Head of Institutions Concerned - with a request to display the list of students in the tos Board
4 Cony ள்‌ to whom the scholarship has been sanctioned. “
]: The Director of Accounts and Treasuries, Puducherry / The Dy. Director of Accounts and Treasuries, Karaikal / Mahe/Yanam.
j 2. The Finance Department The Planning and Research Department, Puducherry
3. The Under Secretary to Govt. (School Education), Secretariat Wing, DSE, Puducherry
4. The Joint Director, OSE, Puducherry / The Dcputy Director (Secondary Education), Karaikal. (yn
5. The Dy. Director (WE), DSE, Puducherry/ The 0. & 0.0, SE, Pudbdheny “> 2 "ores ay fy JO TT 212020-24 : Cok
6. The Chief Educational Officer, OSF, Puducherry/ Karaikal/ Mahe. sale | 3 ௫ Ay
Pucueherry, dated 11 108/29"

<!-- page 2 -->

ஸ்‌
FRESH/ RENEWAL for Pre - Matric Scholarship to OEBC Students - 2019 -20 (left-out.cases) of
GHSS,GHS,GMS,Govt. Aided Private High and Private Higher Secondary Schools of Puducherry,
Karaikal_and Mahe Region i
No. of Students | sz
os oR For 10
For 10 oa
Name of the Institution months@} Total-1 | TOMths | ரவு | Grand Total
Rs.50P.M]° :: it ட்து ல (FI)
vil Nos காய] xX] % நிகாம்‌ [08] Amt]
PUDUCHERRY REGION
ப | | covtte Sax Senoa, TTT [|||
Govt Hr. Sec. School, Pd
| | ணை ட of of of of to 4 | 1 0) மண, 1]
| பூ அலைய [பி] ee
| Govt High School, Pdi
| GHS,Mangalam, Pay. 850000] 1 [+] 750 18] 9250
| |_3_[GHS,Kanuvapet Pay. | 2] of of 2] 1000001010] of 2] 1000
| | 4 |GHS, Thirukkanur Pay. |_of of of of 911011] 750] 1] ஈம
| [| ரு |) 9] 20) 1 1 2 1500] 21] 17000
| (eee || ||| ||
i Govt High School, Pd)
‘ | 5 94௮௭05, Thattanchavady, Pdy. EERE 32000. | 48] 42 | 80 | 67500| 154] 99500
|_| ய்யா] | 0]33] 31] 64] 32000] 48] 42] 90] 67500] 154] 99500
ட வைகை | 1 [| [| |
[| Private Hr. Sec. School, Pd
1
Bees ட 1 1 500] 1 1 750) 2 1250|
Asian English Hr. Sec. School,
| || Total-lV | 6] of of 8) 3000 1] 0) 1] 750] 7] 3780
்‌ |] Puducherry Total -(ie+uiv) | 2135] 33] 89] 44500] 51] 43] 94] 70500. | 183] 115000]
| KARAIKAL REGION
i FRESH -2019 - 20
4 Govt Hr. Sec.School,Kkl
a 1 ‘Thanthai Periyar Govt. Hr.Sec. School,
: Kovilpathu,Karaikal 58 29000) 29000
1 EES 9100 அ 2090010000 sa] 28000
। FRESH -2019 - 20
f Govt Middle.School,Kkl
| af: Surry, 1 ro ol a] a] ool of ol ol of வான
i | ணை ட்ட of of 4a] 500 o_o] of னை of a} 500]
| LL வைய | EET PTE ty
1 Private Middle.School,Kkl
யாட Tami widte Scrooixe [a] ol of வண. வ) | 0] 0] 1] 09
|| 51 கணை பய உவ வை ஊஊ ஊஊ ரணை a] 09]
|| Karaikal Total-(V+VI+VIl) | 59] of 1] 60] 300001 0 01 of of 60] 30000]
|

<!-- page 3 -->

ஸி
்‌ "> MAHE REGIONS = எர ட வல்வை யவ et pn ne)
வேர பி. Sec.School,Mahe
௩1 Purushothaman Govt. Hr.Sec. ea Peers ணை ane நண ண னை ae
1 |School School; Palloor, Mahe 13. 2 28]....14000]. 17] - 14]. 31]: 23250 37250].
= சப்ரா [ 913] 15] ~ 28] 14000]. 47] 14] 21] 28250] ஜு] 97260]
FRESH = 2019-20
Govt Hr. Sec.School,Mahe i
'V.N. Purushothaman Govt. Hr.Sec.
[| Total - IX [400 4] 2000 14011 750] 8] 2ல்‌
| | Mahe Total (VIII+IX) | _a[13| 15] 32| 16000] 18] 14] 32] 24000] 64] 40000]
| rand Total (Puducherry+
| Karaikal+Mahe) 90500) 57 94500| 307| 185000 ;
4 (Rupees One lakh and eighty five thousand only) ட்‌
: (P.T.RUDRA GOUD) |
197 DIRECTOR OF SCHOOL EDUCATION
யு ்‌
ட |

<!-- page 4 -->

No, 28000(2)/DSE/Scholarship/A1/OEBC/2020 - 21 fe
ப்‌ GOVERNMENT OF PUBUCHERRY ¢ 4
: DIRECTORATE OF SCHOOL EDUCATION
os Puducherry, dated.Q% /0872020
ORDER
Sub: DSE- Scholarship- Award of Pre- matric Scholarship to Other Economically Backward Class students - .
Fresh and Renewal for the year 2019 - 20 (left-out cases) through Direct BeneficiaryTransfer (DBT) for the
Students studying in Government Hr.Sec School of Mahe Region - Expenditure Sanction- Accorded.
Ref: 1.G. O. Rt. No. 146 dated 28.11.2005 of the Chief Secretariat(Education-ll), Puducherry.
2.G.0.Ms. No.47/F3/2014 dated 09.12.2014 of the Finance Department, Puducherry.

In pursuance of the 6.05 cited under reference (1) & (2) above, the expenditure sanction. of the undersigned is
hereby accorded to incur an expenditure not exceeding to Rs.39,500/- ( Rupees thirty nine thousand and five hundred
only) towards the award of Pre-matric Scholarship to OEBC students for 63 Nos. studying in Government Hr. Sec
School of Mahe Region during the year 2019-20 (left-out cases) as detailed in the Annexure.

on
2. The bill shall be prepared by the concerned D. & D.Os/ schools on. receipt of the sanction order and
present the bills with DAT along with Authorization slip generated from BEAMS, and “E-form” from PACT after
obtaining necessary BCR entries from the scholarship section of this Directorate. The amount drawn by the
concerned Drawing and Disbursing Officer transferred through ECS by the DAT should be disbursed to the students
concerned through Direct Beneficiary Transfer mode for the amount transferred in the Bank, where the Drawing and
Disbursing Officer is holding the Account. The particulars of the student such as Bank A/c No., IFS code of the Bank,
Aadhaar No. of the student are already available with the Drawing and Disbursing Officers concerned, which was
' submitted by the students/Schools under their control, A Disbursement Certificate alona-with the list_of students to |
whom the scholarship has been disbursed through Direct Beneficiary Transfer system by the Bank should be sent to this |
Directorate immediately for furnishing the same to the Finance department, Puducherry. |
|
& The Head of Institution have certified that all the applicants satisfy the conditions prescribed for the grant of Pre-
matric Scholarship and that the current rate of scholarship is in accordance with G.O.Ms.No.146 dated 28.11.2005 of
Chief Secretariat (Education), Puducherry.
4 It should also be ensured by the Head of Institution that the scholarship should be allowed only for the actual
number of months they studied in their respective class. The Head of Institution concerned shall ensure before |
disbursement that the students are not in receipt of any other scholarship from the Education Department or any other
Government Department.
5, The Expenditure is debitable to the Head of Account “17- 2225 - Welfare of Scheduled castes, Scheduled Tribes
and Other Backward Classes and Minorities- 01- Welfare of Scheduled Castes - 01/277-Education-01/277(01) Award of
Pre-Matric scholarship to Other Economically Backward Class students |
Head of Account “Amount —Wo. ofbeneficiaries
701/277 (01) (03) (34) Scholarship and Stipend டட. வை]
Mahe Region ர Rs._ 39,500 . 63
_Total Rs. 39,500 63
in the current financial year. [
ர (P.T.RUDRA GOUD) |
ள்‌ ர Vy DIRECTOR OF SCHOOL EDUCATION
௦
1. The Head of Institutions Concemed — with 2 request to display the list of students in the Notice Board
to whom the scholarship has been sanctioned.
Copy to- |
1. The Dy. Director of Accounts and Treasuries, Mahe.
2. The Finance Department/ The Planning and Research Department, Puducherry
3. The Under Secretary to Govt. (Schoo! Education}, Secrelatial Wing, DSE, Puducherry
4. the Chief Educalivnal Officer, 056, Mahe. i

<!-- page 5 -->

. oa . |
RENEWAL for Pre - Matric Scholarship to OEBC Students - 2019 - 20 (left-out cases) of GHSS of
Mahe Region ail
ணை படட ணை கனை
௦10
For 10
Name of the Institution months @ | Total-1 | TOPS | Total -1 Grane i fal
Rs. 50 P.M ek (I+1l)
[ vilvi[vii[ Nos] Amt] ix |X |Nosfamt.[Nos.[ Amt,
i. அர இறைய ச அவ என
Govt Hr. Sec. School, Mahe
'V.N. Purushothaman
1 CCC பப்பட்‌
= Total 0[18]_13]_ 34] 15500] 22] 10 | 32 | 24000] 63] 39500
Rupees thirty nine thousand and five hundred only
(P.T.RUDRA GOUD)
ர aly DIRECTOR OF SCHOOL EDUCATION

<!-- page 6 -->

த்‌ ஷ்‌!
No. '25090(3)/DSE/SCHOTETShip/A 1/OEBC/2020-21 7 5 :
ஷ்‌ தது GOVERNMENT OF PUDUCHERRY -. 4
a nk DIRECTORATE OF.SCHOOL EDUCATION
ட்‌ 4 ன ஒன்கள்‌ \ Puducherry, dated 00/10/2020
, ORDER :
Sub: DSE- Scholarship- Award of Pre- matric Scholarship to Other Economically Backward Class students -
Fresh and Renewal for the year 2019-20 inciuding leftout cases through Direct BeneficiaryTransfer (DBT) for
the students studying in GHSS, G.H.S, Private High School of ‘Puducherry, Karaikal, Mahe and Yanam
Region - Expenditure Sanction- Accorded. ., ».. typed ்‌
Ref: 1.G. 0. Rt No. 146 dated 28.11.2005 of the Chief Secreiariat(Education-Il),Puducherry. “அட |
2.Order No.65/DSE/SW/E4/2020-21 dated 24/09/2020 of the Under Secretary to Govt.(School Education), தி
Puducherry. நி கட்ட வை tee 8 |
In pursuance of the G.Os.cited under reference (1) & (2) above, the expenditure sanction is hereby accorded to incur |
an expenditure not exceeding to Rs.15,43,250/- (Rupees Fifteen (216 forty three thousand two hundred and fifty only) |
towards the award of Pre-matric Scholarship to OEBC students for 2521 nos studying in GHSS,G.H:S, Private High 50௭௦௦! |
of Puducherry, Karaikal, Mahe and Yanam Region during the year 2019-20 including leftout cases as detailed in Annexure. ட | .
2. The bill shall be prepared by the concerned D. & D.Os/ schools on receipt of the sanction order and present
the bills. with DAT along with Authorization ‘slip’ generated from BEAMS,and “‘E-form” from: PACT after obtaining |
necessary BCR entries from the scholarship section of this Directorate. The amount‘drawn by the-concerned Drawing |
and Disbursing Officer transferred through ECS by the DAT should be-disbursed to the. students concerned through. Direc! ந்‌ 1
Beneficiary Transfer mode for the amount transferred in the Bank, where’ the Drawing and Disbursing Officer is holding the !
Account. The particulars of the student such as Bank A/c No., IFS code of the Bank, Aadhaar No. of the’student are already ந
available with the Drawing and Disbursing Officers concerned, which was submitted by the students/Schools under மன்‌
coritrol’ A Disbursement Certificate along-with the list of students to whom the scholarship has been disbursed through: |
Direct Beneficiary Transfer system by the Bank should be sent to this Directorate immediately for furnishing the same to the 1 *
Finance department, Puducherry. |
3. The Head of Institution have certified that all the applicants satisfy the conditions, prescribed for the grant. of. Prei- |
matric Scholarship and that the current rate of scholarship is in accordance with G.O.Ms.No.146 dated 28.11.2005 of Chief 1
Secretariat (Education), Puducherry. |
4. It should also be ensured by the Head of Institution that the schdlarship should be allowecl only for the actual nui: |
of months they studied in their respective class. The Head of Institution concerned shall ensure before disbursement that the a
students are not in receipt of anyother scholarship from the Education Department or any other Government Department.
5. The Expenditure is debit able to the Head of Account "17- 2225 - Welfare of Scheduled castes, Scheduled Tribes i
and Other Backward Classes- 01- Welfare of Scheduled Castes - 01/277-Education-01/277(1) Award of Pre-Matri:
scholarship to Other Economically Backward Class students . *
ணை ட்ட படை எனை. ப 15 | டட பட: அனை J
01/277 (01) (03) (34) Scholarship and | ம்‌ s |
ர வ அமவ ரர ட 27,250) 00 -உடடட்டல்‌ |
-01/277 (01) :(02) (34) Scholarship and | | |
| stipend KaraikalRegion | 19.88.2560) ப்ப TB : :
[01/277 (01) (03) (34) Scholarship and | |
பழத்த Mate RABE a | பயயயமப் பமிலி ட்ட பட்‌ பட்டட்ப்ட்ட பரத
-01/277 (01) (06) (34). Scholarship and | at
LLL பப கானை ree oi.) eae க்கை கடனை ட்டட்ட்ட .
டட TB A850 ப படட டட அய ॥
in the current financial year. : ்‌ 5
ன (P.T. RUDRA GOUD)
Vv DIRECTOR OF SCHOOL EDUCATION ॥
Be
To 4
1, The Head of Institutions Concerned — with a request to display, the list of students in. the Notice Board ணு i
to-whom, the Scholarship has-been :sanctioned. ய |
Copy to- : ்‌ manaeniek அணத லட கடம்‌ ஆரு
1. The Director of Accounts and Treasuries, Puducherry 77786 Dy. Directér‘of Accounts and Treasuries, Karaikal /
Mahe/Yanam ்‌ வர்ம பகல PolT Oe. ம
2 The Finance Department’ The Planning and Researci: Department,.Puducherry: ee ee te |
3. The Under Secretary to Govt. (School Education), Sécretariat Wing, DSE, Puducheriy’ “Aen 2௨ ௮ sit le ie Sea | ஸுக.
4. The Joint Director, DSE, Puducherry/ The Deputy Director (Secondary Education), Karaikal © ம்‌ உ 1
5. The Dy. Director (WE). DSE, Puducherry/ Delegates to 056 2௮ - : ese PR EE ope ses j
6 The Chief Educational Officer, DSE, Puducherry/ Karaikal/ Mahe. * a
7 The D. & 0.0, DSE, Puducherry /The internal Audit Wing, nce பஷ வானு உ சாதன னளினை a.
|

<!-- page 7 -->

eer
Name of the தி
joi
[alpuducherry | 2] (27,250
ண ணை «| கணை S| 90,8825}
ண ணை 012 TSC .03,500
ப ணை ஊக ரணை ட 1-1]
* hee
HW GOUD)
ப்‌ 37 DIRECTOR OF SCHOOL EDUCATION 1
|
ர்‌ உ ர சக ப ப ட ட ர ட்‌

<!-- page 8 -->

ne ee ee A A SE SAA SRD பபப பபப அ அதைனய கைக கைய தையை சைகை க க வைகைக்‌.
* fe? ANNEXURE-
FRESH/RENEWAL Proposal for Pre - Matric Scholarship to OEBC Students - 2019-20 including left out cases - Govt.
H.S.S/GHS of Puducherry, Mahe and Yanam
a ணை நை
| எ vu [vur}wos.[ கா௩ | 00] x 18௧] amt [௯] கா ]
நண ணன ணா பட்டபா region ன ணை
[rsh பட ட 122 சை
Kasthuribai Gandhi Govt. ட
Girls Hr. Sec.
1|school,Bahour, Pdy. 31 1| 36] 180000 2) 2 21000
ட அரு 0100500000 903] 500
ட கடை | 3151 2] 025000 2 2] க] 80000 ச 21500]
oe மவ Govt igh கணை பட டட |
பகாள்ள 1 8]_01_2] 115000] of a] 1] 750] 31] 5750)
ணட... 0210050000 பூ 750) 33] 5950
[—Jpuduchersy Totartrey | 29153] 47] 23500] 2] 3] க] 38500 52] 22ம்‌
eae Reglon ணை
[TET FRESHIROTB-20 Govt. Hr. See.School, Mahe கை
1|Pandakkal, Mahe 13 2] 15) 7500 2 2 1500) 17 9000
எ எவ்‌ மி 20 ம] 7500] 2) 0 2] 3500] 391 9000
ன ணை _RENEWAL-2019-20 Govt. Hr. Sec.School, Mahe
PGES | ah lal sol அணி a] aol விலை படலை
1|Pandakkal,Mahe 22] 14| 36) 18000) 31 51] 38250) 87.
ணன க கை ரர வட க
{|} வ] 02214] 86] 38000] ஷீ] 37] 302] 76500) 335] 94500.
[Mahe Totar(uisiv)| 112414] 5] 25500] ன] 3ர[ 308] 78000] 355] 308500]
த ட வள ப பப |
ன ண சை னை 5712: ரர School Yanam |
ட. |P.K. Govt. High
School,Gueriampeta,
1\Yanam இர]: அதி 83) 41500. 5 6750 48250
ரை sf a7] வி. 008] 4) | 6750] 92] 850]
க்‌ Re ne wal-2098-15-Govt-High ளை பபப ப ட]
P.K. Govt. High
School,Gueriampeta, : .
ajYanam 103] 51500] 51] 42 69000} 395] 120500
ணை 100௮ 54] 103] 50500] 50] கம] 92] 69000] 195] 120500]
ச்சு Fresh-2019-20-Goveigh SchoolYanam ப ப ப ப ட |
8௨ Govt. High
School,Gueriampeta, |
1|Yanam 15 35] 7500 15] 7500
ட ரஷா. 1800] 7500] of of of 6 3] 7500 ்‌
ண ண Renewal-2019-20-GoveHigh SchoolYanam கை
P.K. Govt. High
chool,Gueriampeta,
1jYanam 63| 119] 59500) 54| 318] 88500] 237| 148000)
[—rota-vin 0] 56] ஷீ] 319] 59500] 6a| sal 118] 88500] 297) 348000]
இன்‌ Total [த
|Grand Total .
CB cella eet
Yanam) i 124] 151] 143 209000) 129. 248000... 746]... 455000
©... (PT.RUDRAGOUDYS! 2 =a
ay DIRECTOR OF SCHOOL EDUCATION ...........
: |
|
தட்டல்‌ 8 cyclin ae |

<!-- page 9 -->

ee cer STE ன தண SpA aS es பப்ப பப ப்படும்‌
வ ௭9 Proposal for Pre - Matric Scholarship to OEBC Students - 2019-20 - Govt. GovéAided HS/
ட Private H.S.S/H.S_of Karaikal Region
ப்‌
இத்த. For 10 For 10 ‘
ந se Name of the Institution months @ | Total -1 months! வடட Grand Total | .
: No: ட்‌ @Rs.75 (ய)
்‌ 5. 50 P.M |
i P.M = oer
a Far [wenn [ame [| sl At eo] ar
ந 1 த Fresh-2019-20 Govt Middle School,Karaikal
ராச] 8100] 6 30000 of of” of 0) 8] 3000
i 1 Fresh-2019-20 Private High School,Karaikal
1 Elamalia High
j - இறப்பான்‌ 4 5]. 2500. 1 1) 750 3250
a FRESH - 2019-20 - Govt. Higher Secondary School,Karaikal
eee [4414 1] ஏர seo] sa] ரஜ)
} ia Karaikal. அ] 1] 11 2) 1500) 13] 7000
| இ Total - | 4319 ss] க 4] 4] 21500] 13) 7000
| FRESH - 2019-20 - Private Higher Secondary School,Karaikal
j பது St.Mary's Higher Secondary
நித்து * |School,Karaikal. 2 al “150 “Ze00) bis! டண
இத்‌
இ Regional Perfect Higher Secondary
{ 2 | school, Nedungadu, Karaikal 2 2 1000]
q Crescent Girls' Higher Secondary “
ட 3 | School, Ambagarathur.Karaikal. i iia வி
Shanmuga Higher Secondary 1 500) 4
்‌ School,Kovilpathu,Karaikal
Shanmuga Higher Secondary
நிக்கர்‌ 1 2 10000 12 3) 2250
Nirmala Ranee Girls’
இரப்ப யய ட்ட. a] யாவ sof ap ren
ட RVS National
] 7 |Hr.Sec.School,Oharmapuram, 3] 2 1 8000) 4 11: 750] 7 3750.
Karaikal. i
| Servite Hr.Sec.School, [ i
a [த ena 23| 3 30] 15000] 4 1] 750) 31]/  .18750
Karaikal Ammaiyar CT
ee St,Karaikal 2000] | of of 934] 19000)
KMK Kanniyaa Pillai ஈ
immaculate Englis
11 lHr,Sec.School,T.R.Pattinam, 28 அரி. #2000 24) 12000
I Total=1V [ர அடு எப aos000) 4] 3] ர 260) 247] ஈன
| | FRESH -2019-20 - Govt. High School,Karaikal.
[ப வைவைகைவை | 19 om 44494௯
| || Fresh-2019-20-Private Higher Sec.School,Karaikal
Sri Nava Sithi Vinayagar Hr. ட அய்ய
1]960.507௦௦ Varichikudy, 108 ம்‌ 70001 8 2 10 8500
ண Total-VI | 7 01 8] 4000 2) 0) 2] 4500) 10] ' 5500]
டு Total -(isisuisivevevi) | 30a) 2 171 Bae] azs000) a] al _32] 5000] கி 322000
: ள்‌ ன க i(P.TRUDRAGOUD)
ட்‌ «yy DIRECTOR OF. SCHOOL 8000211002:
= : Teg 11 2

<!-- page 10 -->

H.S.S and H.S of Karaikal Region
i [CN ofStudents ன கை கணைய
For 10
Name of the Institution months @| Total-! eave |: Tomen, [ond rem
a Rs. 50 P.M Rs.75 P.M (Getty 4
WaLwn [war [wos] ame ய [x அ ட ரச பன யப “Amt. |
ண ணை ட்ப பக 010520 Private Higher Sezondany உட்டபட வைக கை
னக ee [of df அம்‌ al af வி of அவ
Hr,Sec, School, Varichikudy Karaikal 20]- 28] 21000) 47
Nirmala Ranee Girls i
[எள்‌ வைட [of ls (னி அணி. orl ool aoe] sets] se] அண
த |Karaikal Ammaiyar .
Hr. Sec.School,Elaikkara St,Karaikal. zal அச ஹி 449 - 409500] ன்னை
ன dd 144 அடர்‌ கல்‌ அமி அ
4 |Secondary ்‌
School,Nedungadu, Karaikal. 10) 8000 22| 16500] 38] 24500]
ர TD ed
School, Ambagarathur, Karaikal. 3 தி 9 34]... 12000]. 29] 18500]
SRVS National 4 |
Hr.Sec.School,Dharmapuram, i ்‌
Karaikal. 7\ 15 11000 35] 21] 15750] 43] - 26750
Immaculate English m4 oe
7 |HrSec.School,T.R.Pattinam, ர்‌ BR ee re
Karaikal. 3) 27 26000| 36 74] 55500] 126] 81500
விய கவள. [ol of ala] 2000] 3] நி 8) 6000] மி) ஜஸு
en Total-i[ 0|208| 243] 454| 22ssoo|_260| 254] s15| 386250] S66] 613780
RENE Wat 2018-20 -Govtidale School Kara! கணை
ட னன்ளைகைது ட. 1931-7] 10: sooof 98: of of 10} _s0004
ள்ள Lol a] 9] ௬ 0. of ஊஊ of க: கணட
ண ண கட 12 ஊட) ௧ ௬ ஐ: ஊட ரக _of வை al சட்டி
ப Rene Wat 2016-20 Govt High shoot Karaka
கக வை. 14 sol sel sone] el sl sil வ்‌ al” அஜி
Kurumbagaram,Karaikal. 101 18) 9000 11] 17250]
(வத்தக்‌ எ னள கம கி] 9000] ஏட 5[ 83] ககன 2[ 3729)
|} RENEWAL 2018520 - Govt, Aided Private High கவ்வி டட டட ட்ட ;
pa Rarer TTL al al மனி அடச்‌ ஷி வடம்‌ ௮௮0
Karaikal. : 7|_13| 20] 10000] 12 36] 12000] 36 0
பைக lll dl ll al ௭
School, Kurumbagaram,Karaikal. 19| 26 22500| 26] 25) 51| 38250 60750! :
oe _Total-1v{ o| 26] 39]_65] 22500] 38| 25]. 67]... so2so| 232] 82759
Renewal 201620 Private High SehootKarafial க
மதன்‌ தைட fol al ol sl al of al அஷ்‌ il அணி
school, Karukkankidy,Karaikal. 3 713500 5 34] 30500] 21) 14000
[னன கிவட | !
2 |school,Nedungadu, Karaikal. 5 7| 5250) 7] 5250
[தனனை அடை | பனி வின வண்‌ aol asl ஊன்‌ படவி
School,Neravy,Karaikal. நத] 34] 29] 14500) 15 21] 35750] 501 30250
| பனலக | 1 sal ஒட்‌ வ aol al வ்‌ வடி
Nagar,Karaikal. 18| 9000] 12| 10) 22) 16500 25500
ence el asl eel ணன வின கட்டி
school,T.8.Pattinam;Karaikal. 101-121] 17] 85001 "9 [-19-- 12000]- -33]----20500
பையனை பம்‌ “el “ol ஓலில்‌?
School,Sethur, Karaikal. *:32]- 6000] 16] - 7| 23] 17250], 35| 23250
(வவ as Jala wol-al ala al ல்‌ அணக அவி
School,Nellezhundur,Karaikal. ~~ 2[ 3) sp 3750 “3759: -
School, Nedungadu,Karaikal. | 4500] Pst ai ail, tah 12750
