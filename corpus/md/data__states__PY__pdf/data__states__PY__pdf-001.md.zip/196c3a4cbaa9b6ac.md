---
doc_id: "196c3a4cbaa9b6ac"
source_url: "https://law.py.gov.in/docs/Stipend_called.pdf"
ministry: "Law Department, Puducherry"
title: "Grant of Stipend to the Junior Advocates Scheme Rules, 2020 - Application Called for the year 2025"
date: ""
pages: 1
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "3ae7e351fef5e669"
---

<!-- page 1 -->

—
ல GOVERNMENT OF PUDUCHERRY
cceex<
ae LAW DEPARTMENT
No. 5053/US/LD/2024 Puducherry, dated 21.01.2025
To
1. The President,
Pondicherry Bar Association,
Puducherry.
2. The President,
Pondicherry Bar Association,
Karaikal.
3. The President,
Pondicherry Bar Association,
Mahe.
4. The President,
Pondicherry Bar Association,
Yanam.
Sir,
Sub: Law Department, Puducherry- The Government of Puducherry
Grant of Stipend to the Junior Advocates Scheme Rules, 2020
- Application — Called for.
தகக
1 am directed to state that the Law Department has notified “The Government
of Puducherry Grant of Stipend to the Junior Advocates Scheme Rules, 2020”. The
Scheme provides for monthly assistance to Junior Advocates @Rs.5,000/- per month
for a period of two years or till starting independent practice, whichever is earlier,
from the date of passing the All India Bar Examination (AIBE). A copy of the above
said Rules is enclosed herewith.

2 1 am further to state that the President, Bar Association of the respective
region is requested to obtain the application of the Junior Advocates in the prescribed
format together with the enclosures as stipulated in the Scheme and thereafter forward
those applications to the Law Department, Puducherry on or before 5" February,
2025.

Yours faithfully,
(JHANAZ RA¥FI @ SHANSI)
UNDER SECRETARY (LAW)
Note: The applicants who have already applied in the year
October 2022 need not apply again.
