---
doc_id: "adc22ce8fe6cdde9"
source_url: "https://schooledn.py.gov.in/notification/GO-70.pdf"
ministry: "District Institute of Education and Training (DIET), Puducherry"
title: "G.O.RT.No.70 - Release of Grant-in-Aid for the year 2017-18 to 35 Govt. Aided Private Schools in Puducherry, Karaikal and Yanam region - Expenditure Sanction for the month of May 2017"
date: ""
pages: 4
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "2c4ee9f17ea3aea0"
---

<!-- page 1 -->

ட்‌ GOVERNMENT OF PUDUCHERRY =
ABSTRACT | 4)
Directorate of School Education (Secretariat Wing) - Release of Grant-in-Aid for the
year 2017-18 to 35 Government Aided Private Schools in Puducherry, Karaikal and
DIRECTORATE OF SCHOOL EDUCATION
SECRETARIAT WING

௦.௦ Rt. No. ZO Puducherry, 6.) 3 SEP 2017

READ: 1.D.No.03-03/DSE/GIAS/U.1II/2017-18 dt.10.08.2017 from ஜ்‌

Director of School Education, Puducherry. ‘

ORDER:

Sanction of the Lieutenant Governor is hereby accorded to incur an expenditure
not exceeding Rs. 3,16,07,000/- (Rupees Three crores sixteen lakhs and seven
thousand only) towards the release of Grant-in-Aid to 35 Government Aided Private
Schoois in Puducherry, Karaikal and Yanam regions as shown in the Annexure - | for
payment of monthly salary and wages to the existing employees and pension to the
retired employees of the schools for the month of May 2017 and difference of pension to
20 new pensioners.
2. The release of grant to the managements of 35 Government Aided Private
Schoois wil! be 100% in such a way that 95% of the total expenditure on salary shall be
borne by Government and 5% shall be borne by the management as per Rule 35 (2)
(ii) of Pondicheny School Education Rules, 1996 which will be rernitted to the
respeciive Drawing and Disbursing Officer who will inturn remit the amount in minus
debit of the relevant Head of Account in which salary is drawn. The payment of salary
to the staff is subject to the furnishing of disbursement certificates to the Inspecting
Officers by the Managements for the grant drawn towards the payment of staff salary in
respect of the previous month along with the bills for the month concerned. Payment of
salary shall be effected through Electronic Clearing System (ECS). Similarly, 5% of the
pension payable to the new pensioners from the financial year 2013-14 shall be borne
by the management which will be remitted to the respective Drawing and Disbursing
Officer who will inturn remit the amount to the relevant Head of Account in which
pension is drawn. ,
3: Necessary action shall be taken by the Inspecting Officers / Drawing Officers
concerned to draw and disburse the amount to the Management of 35 Government
Aided private Schools. Certified that the Grant-in-Aid is sanctioned to the Government
Aided Private Schools which fulfill the conditions/provisions ௦4 the said rules. This
advance payment will be adjusted during the year 2017-18 when the finai Grant-in-
Aid for the year 2017-18 in respect of the 35 Government Aided Private Schools will be
finalized and Grant-in-Aid at the rate of 95% is released.

Zl
fs > |

<!-- page 2 -->

ஆ.
4. The expenditure is debitable to the Head of Account as detailed in the
Annexure — ॥ to this G.O.
5. This issues with the concurrence of the Finance Department, Puducherry vide
their ILD. No. 1946/FC/FD/F4/A4/17 dt.11.09.2017
/1BY ORDER //
| ழ்‌
(V. JAISANKAR)
UNDER SECRETARY TO GOVERNMENT(SCHOOL EDN.)
To
The Director of School Education,
Puducherry.
Copy to:

1. The Finance Department, Puducherry.

2. The Director of Accounts & Treasuries, Puducherry.

3. The Director, Planning and Research Department, Puducherry

4, The Deputy Director of Accounts & Treasuries, Karaikal.

5. The Deputy Director of Accounts & Treasuries, Yanam

6. The Principal Accountant General (Civil Audit), Tamilnadu & Puducherry,
Chennai-35/Puducherry.

7. The Jt. Director of Education (SE), Dte. of School Education, Puducherry - He
will verify the accounts and countersign the bills of Immaculate Heart of Mary's
Govi. High School (Mission St and Ariyankuppam), Puducherry, Fatima Govt.
Aided Boys’ High School, Wiseman Govt. Aided High School, St. Mathias Govt.
Aided High School, Uppalam, Shri Hindocha Charitable Trust Govt. Aided High
School, Ariyur, PONCOS Govt. Aided High School, Lingareddiapalayam and
Prof. Annoussamy Govt. Aided High School, Bahour, Puducherry.

8. The Dy. Director of Education (Women), Puducherry - He will follow the
instructions issued by the Director of Schoo! Education in sanctioning monthly
grant to the aided schools, falling within his jurisdiction.

9. The Chief Educational Officer, Puducherry/Karaikal

10.The Delegate to Director of School Education, Yanam - He will draw the bills
presented by the Management of Sarada Vidya Niketan Govt. Aided English
High School, Yanam.

11.The Dy. Inspector of Schools, Zone I/II/II/IV and V, Puducherry / Karaikal

12.The Drawing and Disbursing Officer, Dte. of School Education, Puducherry - He
will draw the bills presented by the management of Immaculate Heart of Mary's
Govt. High School (Mission St and Ariyankuppam), Puducherry, Fatima Govt.
Aided Boys’ High School, Wiseman Govt. Aided High School, St. Mathias Govt.
Aided High School, Uppalam, Shri Hindocha Charitable Trust Govt. Aided High
School, Ariyur, PONCOS Govt. Aided High School, Lingareddiapalayam and
Prof. Annoussamy Govt. Aided High School, Bahour, Puducherry.

ட்ட .

<!-- page 3 -->

ome SE
. ள்‌ கி
a
Le 6 ANNEXURE-1 |
அனை, கு | AMOUNT FOR
சி உட”! NAME OF THE SCHOOL | May 2017 {in
J ~ 5 | Rs.)
ந ன தத ஜனார எர | 4849000 ;
f | 72202-02/110(01)(21) POY (34) Grants «in - aid 12. | "4849000 ்‌
JAYARANI GOVT. AIDED HIGH SCHOOL, PUDUCHERRY | 4150000
SOCIETE PROGRESSISTE GOVT. AIDED HIGH SCHOOL, | .
‘|? |puoucHeRRY 975000 '
OUR LADY OF LOURDES GOVT. AIDED HIGH SCHOOL, | saa
3. WiLUIANUR, PUDUCHERRY 941000
4 ST FRANCIS ASSIS! GOVT. AIDED HIGH SCHOOL, PUDUCHERRY
MMACULATE HEART OF MARY'S GOVT. AIDED HIGH SCHOOL,
8 ப பப்டரிப்க PUDUCHERRY | 1108000) 3
6 187. ANN'S GOVT. AIDED HIGH SCHOOL, PUDUCHERRY i
ST, JOSEPH'S GOVT. AIDED HIGH-SCHOOL, OULGARET, . =». ண்ண eR de மகக ed ey
7 _|puoUCHERRY 398000
8 18 ANTONY'S GOVT. AIDED HIGH SCHOOL, PUDUCHERRY 836000!
IST. JOSEPH GOVT. AIDED HIGH SCHOOL, MUTHIALPET, | = eral
டட“ _|puoucHERRY 979000
IMMACULATE HEART OF MARY'S GOVT. AIDED HIGH SCHOOL, |
19 INELUITHOPE, PUDUCHERRY 462000
{~~ 87. LOUIS DE GSNZAGUE GOVT. AIDED HIGH SCHOOL, |
| 11“ IpupucheRRy _ 293000
IMMACULATE HEART OF MARY'S GOVT. AIDED HIGH SCHOOL,
| 12 Se PUDUCHERRY 559000
டட 180880 HEAR’ OF JESUS GOVT. AIDED HIGH SCHOOL, | ம்பு
| “|puDUCHERRY டட 371000 7
ட ௩ [eATIMA 604 விற BOYS HIGH SCHOOL, PUDUCHERRY .
| டூ /MACULATE HEART OF MARY'S GOVT. AIDED HIGH SCHOOL,
i iPUDUCHERRY. 1814000)
= [IMMACULATE HEART OF MARY'S GOVT. AIDED HIGH SCHOOL, |
| 15 aRivANKUPPAL PUDUCHERRY 1394000
ay 18805. ANNGUS SAMY GOVT. AIDED HIGH SCHOOL, BAHOUR, |
டட மக ப 806000 .
ட 18 [WISEMAN GOVT. A:DED HIGH SCHOOL, PUDUCHERRY | 1492000
| 49 “TSHRI வான்ட்‌ ci ARITABLE TRUST GOVT. AIDED HIGH டட ணி ப்‌
டட SCHOOL. 8:11. PUDUCHERRY. : 1344000: ்‌
20 [87 MATHIAS Gv. AIDED HIGH SCHOOL, PUDUCHERRY 518000)
| ௪ PONCOS GOVT 460 HIGH SCHOOL, LINGAREDDIPALAYAM, | . ஜரா
PUDUCHERRY. _ 1124000
ட... [2202-02/110(01)91) POY (36) GIA - NP 48544000
(a |MES GOVT. AIDED HIGH SCHOOL, KARAIKAL
23 ae GOVi_ AGED HIGH SCHOOL, KOTTUCHERRY, _
KARAIKAL 861000
24 |S) THERESA'S COVT. AIDED HIGH SCHOOL, KURUMBAGARAM,
பக்கக்‌ 417000.
25 ண்‌ AMMAYAR GOVT. AIDED HIGH SCHOOL, KARAIKAL 841000
hast inenaicereeetep leanne inti eats AS
_ 26 _|ST. MARY'S 0041 AIDED HIGH SCHOOL, KARAIKAL 1576000
__27__|NIRMALA RANEE GOVT. AIDED HIGH SCHOOL, KARAIKAL
ட்‌... 2002110018 KL 39 GIA = NP
(| 38 98720 VIDYA NIKETAN GOVT. AIDED HIGH SCHOOL, YANAM
........12202:02/110(01)/04) YANAM (36) GIA - NP
ட 29 jPROF. ANNOUSSAMY GOVT. AIDED PRIMARY SCHOOL, டட இற
| SELIAMEDU, PUSUCHERRY 234000
ட 39 |DAKSHIN BHARAT | INDI PRACHARA SABHA, PUDUCHERAY 0
| 31. |ST. SEBASTIAN GOVT, AIDED PRIMARY SCHOOL, PUDUCHERRY
| ஓ. |ST. DOMINIC SAVIG GOVT. AIDED MIDDLE SCHOOL, |. இஷ
2000. 287000
33___|DEEPA OL! GOVT. AIDED HIGH SCHOOL, PUDUCHERRY
_~:|2202-02/110(02)(01) POY (36)GIA-NP SS
34 is JOSEPH'S GOVT. AIDED ENGLISH PRIMARY SCHOOL,
SHKARAIKAL தைத 485000
்‌ 35: |DHAKSHIN BHARAT HINDI PRACHARA SABHA, KARAIKAL
is Hazzard) Kit (36) GIA - NP
[TOTAL
(Rupees Three crory-Sixteen lakhs and Seven thousand only)
Wcesesens
‘ UNDER SECRETARY TOGOVT (SCHOO Enticatinan 4

<!-- page 4 -->

Sane இ ANNEXURE-II “es .
i AMOUNT FOR ”
SL.NO. . HEAD OF ACCOUNT MAY 2017 (in “
i Rs.
2202 - General Education - 02 - Secondary Education - 02/110 -|
1 Assistance to Non Govt. High Schools - 02/110(01) Assistance to}
Non Govt. High Schools - 02/110(01)(01) Puducherry Region (31) ௫
: }Grants-in-aid (Non Plan) 4849000 i
2202 - General Education - 02 - Secondary Education - 02/110 - =
2 Assistance to Non Govt. High Schools - 02/110(01) Assistance to} a
Non Govt. High Schools - 02/110(01)(01) Puducherry Region (36)
Grant-in-Aid Salaries (Non Plan) 48544000
2202 - General-Education:-:02:+-Secondary Education.-.02/110. -| கன்ட iain சத்‌ அடக்கம்‌ PS
3 Assistance to Non Govt. High Schools - 02/110(01) Assistance 1௦
1 |Non Govt. High Schools - 02/110(01)(02) Karaikal Region (36)
| Grant-in-Aid Salaries (Non Plan) 5249000
| 2202 - General Education - 02 - Secondary Education - 02/110 -
1 ' |Assistance to Non Govt. High Schools - 02/110(01) Assistance to
| Non Govt. High Schools - 02/110(01)(04) Yanam Region (36)
Grant-in-Aid Salaries (Non Plan) 1055000
| 2202 - General Education - 02 - Secondary Education - 02/110 -
மலரிது Assistance to Non Govt. High Schools - 02/110(02) Assistance to
INon Govt. Secondary Schools - 02/110(02)(01) Puducherry
Region (36) Grant-in-Aid Salaries (Non Plan) 4393000
2202 - General Education - 02 - Secondary Education - 02/110 -|
6 Assistance to Non Govt. High Schools - 02/110(02) Assistance to
| _ {Non Govt. Secondary Schools - 02/110(02)(02) Karaikal Region
i (36) சபி Salaries (Non Plan) 517000
es TOTAL 31607000
(Rupees Three crores Sixteen lakhs and Seven thousand only)
*
UNDER SECRETARY TO GOVT. (SCHOOL EDUCATION) ம்‌
