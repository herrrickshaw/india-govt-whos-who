---
doc_id: "d7cb34a4a6fca5c8"
source_url: "https://gstchennai.gov.in/images/pdf/tenders/AMC_COMPUTER_2024_25.pdf"
ministry: "Office of the Principal Chief Commissioner of GST & Central Excise Tamil Nadu & Puducherry Zone, Puducherry"
title: "Click here for Detail"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "76db53e8a5a04f9f"
---

<!-- page 1 -->

•

7j---

...
•,,....
Azadi Ka
Amrit Mahotsav

aq3it@hara@d#tu3nagyecongaaaoraruferu(or4et- 1
OFFICE OF THE COMMISSIONER OF GST & CENTRAL EXCISE (APPEALS-II),

qlraf,{Ia, i.2054/1, 1I kg, 12dirts
NEWRY TOWERS, 2 FLOOR, No.2054/I, II AVENUE, 12TH MAIN ROAD,

341/, ax{-€oooo, p)11.2614 2871
ANNA NAGAR, CHENNAI - 600 040- Phone No. 26142871

GAPPL/MISC/60 /2021-PRO

Date:

.4.2024

To
The Assistant Commissioner (Computers)
O/o The Commissioner of CGST & Central excise
Chennai North Commissionerate
Nungambakkam, Chennai.
Sir,
Sub: Request for uploading of Limited Tender for Annual Maintenance Contract
for Computers, Peripherals, Printers, Network switches
for Chennai Appeals -II Commissionerate on the website - Reg.

*****
Tender documents inviting eligible firms for Annual Maintenance Contract for
Computers, Laptops, Peripherals, Printers, Network switches & Scanners for Chennai
Appeals -II Commissionerate for the period from 01.5.2024 to 31.3.2025 is enclosed
herewith.

I request that
"gstchennai.gov.in/".

the

same

may

be

uploaded

in

our

official

website

Issued with the approval of Competent Authority.
Yours faithfully,

- e
22,
\ < r
\7

(G. NAGABHUSHANAM)

Asst. Commissioner

<!-- page 2 -->

•
7/
.--

t%

/'.-

....
Aza d I Ka
Amrit Mahotsav

5 years ofGST

a@3it harud#unagyecsngararar4feta(3rfet-1)
OFFICE OF THE COMMISSIONER OF GST & CENTRAL EXCISE (APPEALS-II),

qleraf,{Ia, .2054/1, 1I dI, 12ai#l s
NEWRY TOWERS, 2P FLOOR, No.2054/I, II AVENUE, 12TH MAIN ROAD,

3r77IR, ±q{€ooo8o, p)+1.2614 2871
ANNA NAGAR, CHENNAI - 600 040- Phone No. 26142871
GAPPL/MISC/60/2021-PRO

Date: 15.4.2024

LIMITED TENDER NO. 01/2024
The Office of the Commissioner of Central Excise & GST, APPEALS - II
Commissionerate, invites manual tender quotations from experienced, eligible,
reputed, registered firms/companies engaged in the business of providing Annual
Maintenance

Contract

Services

Commissionerate mentioned

of

Computers

and

in Annexure-I for a

its

Peripherals

period from

in

the

01.05.2024 to

31.03.2025. Since the total value of this bid is likely to be below 2 lakhs, the bid
submission will be manual.
The necessary tender documents to be submitted are detailed as below:

(i) Tender Acceptance Letter (Annexure A),
(ii) Letter of Authorisation to submit Bid (Annexure B),
(iii) Company's Turnover Details (Annexure C)
(iv) List of two Qualified Engineers in the panel of the Company (Annexure D)
(v) List of 1 or 2 clients where AMC has been undertaken successfully (Annexure E)
(vi) Price Bid Undertaking (Annexure F)
Before placing your bid you are required to download the following Annexure
(1) Scope of work (2) Eligibility criteria and (3) Terms
from Central Excise Chennai website https ://gstchennai.gov. in/.

2

and

conditions

<!-- page 3 -->

•
The Time Schedule of the Tender process is furnished as under.
S No.

Particulars

Date

Time

1

Bid Submission start date

18.4.2024

(Thursday)

10:30AM

2

Bid Submission last date

24.04.2024 (Wednesday)

03:00 PM

B

Tender opening date

24.04.2024 (Wednesday)

05:00 PM

Duly filled bids and signed copies of the documents in all respects should be
submitted by the bidders on or before 24.04.2024 (Wednesday) either manually or by
post to the Office of the Commissioner of Appeals -II, No. 2054. Newry Towers,
Block

I,

II

Avenue,

12

Main

Road,

Anna

Nagar,

Commissionerate is not responsible for any postal delays)

Chennai-

40.

o

(This
,

,°

er

(G. NAGABHUSHANAM)
Asst. Commissioner
Copy to :-

1. Chennai North/South/Outer Commissionerate (For display in the notice board).
2. The Superintendent (Computers), Chennai North (for uploading on to the
official website).

3

<!-- page 4 -->

•

.... SCOPE OF ANNUAL MAINTENANCE CONTRACT (AMC) OF COMPUTERS
AND IT'S PERIPHERALS

Scope of work: There are around
(i)

30 Computers of various brands viz. :(a) Lenovo (b) HP Compaq (c) Samsung (d) I-Mac

(ii) 9 black and white single function and multifunctional printers
of various brands viz: - (a) HP, (b) Canon (c) Samsung
(iii) 13 HP multifunctional color printers
(iv) 06 HP Scanners
(v) 25 UPS equipments
to be covered under AMC. AMC will include installation of valid reputed Antivirus
software (antivirus to be provided and installed whenever required) and network
maintenance. Refer to Annexure-I for detailed information.

2. ELIGIBILITY CRITERIA FOR MANUAL BIDS
a)

The

firm

should

be registered

with

Goods and Service Tax Department,

GST Registration Certificate Copy (furnishing the GSTIN) to be enclosed.

b)

The firm should be a registered company with the Registrar of Companies.

Proof of the same should be submitted.

c)
the

The firm's AMC should not have been terminated due to deficiency of service in
last

three

years.

The

bidder

should

not

have

been

disqualified

/debarred/blacklisted by any Government office/Semi-Government office/PSU/Bank
for any default for such services

in the past;

An undertaking

on his/her letter

head declaring as follows should be given :
"We have not been disqualified /debarred/ blacklisted by any
Government office/Semi-Government Office I PSUs I Banks for any
default for such services in the past."
d)

The firm must have expertise in onsite maintenance and repair of computers

(Windows Vista/Windows7/Windows 8/Windows 10/ Windows 11/Linux), Laptops,
LaserJet Printers, network components and other hardware parts and accessories.

4

<!-- page 5 -->

e)

The bidder must have Permanent Account Number (PAN) under Income Tax

Act, 1961 and should furnish and provide Income Tax Assessment certificates for
the three years viz., 2021-22 ,2022-23 & 2023-24.

f)

The bidder should have valid ISO Certificate. The same should be submitted.

g)

All the documents/Annexure has to be submitted in the company's letter

head with seal and signature.

3.

GENERAL TERMS & CONDITIONS

The contract period will be for one year from 01.05.2024 to 31.03.2025 and
the rates quoted will remain in force during the period of contract.

The AMC shall

be a comprehensive contract for all the parts of the

machines/accessories/peripherals including parts such as Printer Heads/ Teflon
sheets/key boards/mouse etc.
The contractor

shall

provide one qualified

engineer (hereinafter

called

'the Maintenance engineer') on call basis to attend to any complaint in the Office
of the Commissioner of GST & Central Excise, Appeals - II, Chennai - 600 040.

He shall attend the client's office on all working days from 09.30.00 a.m. to
06.00 p.m. normally, and in case of necessity, beyond this period and also on
holidays, whenever the Commissionerate Computer Section functions requires
so.

Such work timing /days of necessity shall be notified by this office in

advance for which no extra charges will be made.

It is the responsibility of the firm to provide standby maintenance engineer
whenever the maintenance engineer is not available for any reason such as leave
etc.
The maintenance engineers shall rectify or resolve any complaint within 24
hours. All repairs have to be carried out on site itself except in respect of items
covered under warranty.

5

•

<!-- page 6 -->

•

The maintenance engineer once provided shall not be withdrawn /removed or

replaced with another engineer or disturbed from attending to the calls in this
office, by the contractor, without proper, prior explicit concurrence of this office.

Where the maintenance engineer becomes non-available due to reasons as
resignation etc., an immediate replacement has to be provided by the contractor.
In case of necessity / any emergency, if this office so requires, the contractor
shall additionally
set-right

deploy

one or more qualified

service

engineers to quickly

any demanding situation that has arisen unforeseen.

No revision of rates will be entertained during the contract period.
The maintenance service by the contractor shall
breakdown

maintenance

of

all

computer

include preventive and

hardware

items

in

the

entire

Commissionerate.
The maintenance/on call service engineer shall maintain

Log

Registers of all

calls attended/pending issues, and Preventive maintenance records and details of
all

replacement of spares and any such items.

No advance payment in any case will be made. However, quarterly payment
on pro rata basis will be made on satisfactory completion of the contract.
The AMC Service Bills require to be submitted on quarterly basis in Triplicate.
In case of any constrained situation during the above period, if system
configuration change, Upgradation and the number of computers / printers/other
related parts/peripherals have to be increased/reduced by the client, then the
contractor would be intimated and the AMC amount would be reworked accordingly
on pro-rata basis and payments would be made based on the reworked amount,
for the remaining period.
The AMC shall include installation, configuring all software including Operating
System and antivirus software and installation of necessary drivers.

6

<!-- page 7 -->

In case any equipment is taken outside the office premises for the purpose of
repairs, if any PC/printer is not attended/repaired within forty eight hours, the firm
shall provide a standby for the same immediately.

Where the

parts / components

have failed/damaged

or gone out

use by any reason, replacement of those parts/components including
wires, cables, chords, circuit

boards,

mouse & keyboards

etc.,

of

hard disk,
have to

be

provided by the contractor within 24 hours of attending to the call, including the
software installation, if necessary.
Where the replacement of parts or support could not be obtained due to
obsolescence, the entire system (such as Server, Printer, Scanner etc.)
replaced by the contractor with a

new system with

must be

at least the existing

configuration of the same make and brand from the same manufacturer of the
defective system.

Where replacement of the old system with a

new one of the existing

configuration of the same make and brand of the failed system could not be
provided, a system with higher configuration of the same make and brand from
the same manufacturer shall be provided by the contractor.

In case of replacement of any hardware parts such as Hard Disk, etc, the
replacement should

be of the same

make and

brand and

either of the same

configuration or higher.
The AMC will not cover Computer consumables and is not transferable.
Bidders who do not submit Annexures along with the bid will be disqualified for
not following the tender process and their tenders will not be considered.

Failure to comply with any of the conditions mentioned herein (in the tender
document) will disqualify the bidders in the AMC process.

7

•

<!-- page 8 -->

•
In

case of the

firm

backing

out any

time

during

the

period

of AMC

without any explicit consent of this office, the firm will be liable to recovery at
the

rates that will

machines/hardware

have to be incurred

by this

office

on maintenance

of the

for the balance period of the contract through alternative

means.
If the firm fails to carry out repairs/provide any standby PC/printer within
3(three) days to the satisfaction of this office, a
will be charged

for delay

beyond three

penalty

working

of Rs

days till

PC/printers are repaired.

~

100/-

per day

such time the

.2
"-'°v-r

A,s
"
«$

_

(G NAGABHUSNAM)
Asst. Commissioner
APPEALS-II COMMISSIONERATE

8

<!-- page 9 -->

•
ANNEXURE I
Items

Brand/make of system and model

PC's All in Hp/ Dell/ Lenovo /Compaq /samsung
one PC's

Printers
HP/Samsung Single Functional (B/W)
HP/ Samsung Multifunctional
Printer (Colour)
Scanners
UPS

HP/ EPSON
ZEBRONICS

9

Operating system (OS)

No. of PC's

Window 7
Window 8
Window 10
Window 11

30

--

9

--

13

--

06

--

25

<!-- page 10 -->

•

ANNEXURE - A (TENDER ACCEPTANCE LETTER)

Date

To,

_

Sub: Acceptance of Terms & Conditions of Tender. Tender Reference No:
Name of Tender /Work:
Dear Sir,
1 I/We obtained the tender document(s) for the above mentioned 'Tender/Work'
from the website(s) namely: as per your advertisement, given in the above
mentioned website(s).

2. I/We hereby certify that I/ we have read the entire terms and conditions
of the tender documents from Page No. to(including all documents like
annexure(s), schedule(s), etc .,), which form part of the contract agreement
and I/we shall abide hereby by the terms/ conditions / clauses contained
therein.

3. The corrigendum(s)
issued from time to time
by
your department/
organization too have also been taken into consideration, while submitting this
acceptance letter.

4. I /We hereby unconditionally accept the tender conditions of above mentioned
tender document(s) / corrigendum(s) in its totality/ entirety.

5. I/we do hereby declare that our Firm has not been blacklisted / debarred
by any Govt. Department / Public sector undertaking.

6. I/We certify that all information furnished by the our Firm is true & correct
and in the event that the information is found to be incorrect/untrue or
found violated, then your department/ organization shall without giving any notice
or reason therefore or summarily reject the bid or terminate the contract, without
prejudice to any other rights or remedy including the forfeiture of the full said
earnest money deposit absolutely.
Yours faithfully,

Signature of the Bidder
with Official seal

10

<!-- page 11 -->

•
ANNEXURE- B
(LETTER OF AUTHORISATION TO SUBMIT BID)
AN UNDERTAKING (SELF-CERTIFICATE) THAT THE BIDDER HAS NOT BEEN BLACKLISTED
BY A CENTRAL /STATE/UT GOVERNMENT INSTITUTION AND THERE
LITIGATION

WITH

ANY

GOVERNMENT

HAS BEEN NO

DEPARTMENT ON ACCOUNT

OF ANY

ISSUES/SERVICES

SIGNATURE OF THE BIDDER
with Official seal)

11

<!-- page 12 -->

@
ANNEXURE-C
COMPANY'S TURNOVER DETAILS
To be submitted in Company letter head with seal and sign

COMPANY/FIRM OVERALL
TURNOVER

YEAR

TURNOVER UNDER COMPUTER
SERVICE MAINTENANCE

2021-22
2022-23
2023-24

ANNEXURE-D
LIST OF TWO QUALIFIED ENGINEERS IN THE PANEL OF THE COMPANY

SI.
No.

Name of the
qualified engineer

Educational
Qualification

Employee
Code

Technical
qua I ification

Relevant
experience
in years

ANNEXURE -E
LIST OF 1 OR 2 CLIENTS WHERE AMC HAS BEEN UNDERTAKEN SUCCESFULLY

SI.
No.

Name of the
Client

Address of
the Client

Name of the
Engineer

12

Value of the
Contractor

State whether
the client is
Govt./ PSU

<!-- page 13 -->

@

ANNEXURE- F
PRICE BID UNDERTAKING)
From (Full name and address of the Bidder)

To
Dear Sir/madam,

I submit the price Bid for

and

related

activities as envisaged in the Bid Document.

2.
I have thoroughly examined

and

understood

all
the terms and
conditions as contained in the Bid Document, and agree to abide by them.

3.
I offer to work at the rates as indicated in the price Bid inclusive of all
applicable taxes.

SIGNATURE OF THE BIDDER
WITH OFFICIAL SEAL)

13
