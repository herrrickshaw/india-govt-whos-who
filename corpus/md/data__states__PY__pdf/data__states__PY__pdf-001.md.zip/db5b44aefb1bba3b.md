---
doc_id: "db5b44aefb1bba3b"
source_url: "https://agri.py.gov.in/sites/default/files/docs/SanctionPuducherry03.09.2015.pdf"
ministry: "Agriculture and Farmers Welfare Department, Puducherry"
title: "View here"
date: ""
pages: 7
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "bb06809aed000fc9"
---

<!-- page 1 -->

No.Z-11018/15/2014-IT(Pt.) Comp.No.6276
Government of India
Ministry of Agriculture
Department of Agriculture & Cooperation
IT Section
KrishiBhavan, New Delhi
Dated, the 4” September, 2015
(Bill No.71
Sub- Head of Account
eee ee மணை... ee
| MajorHead -2401 | Grants-in-aidtoStateGovernments
| Minor Head = 800 SS | Cropiiiighandty ee =
(2 - ப ப | KrishonnatiYojna-State Plan அ...
02 1 | National E-Governance Plan-Apricuttires 25 >= 5
[2 2... பாகம... |
[0221 2 el Graney inal General 9:
Received a sum of Rs.11,69,921/- (Rs. Eleven Lakhs Sixty Nine Thousand Nine
Hundred Twenty One only) being sanctioned under the Government of India, Ministry of
Agriculture, Department of Agriculture & Cooperation order No.Z-11018/15/2014-IT(Pt.)
comp.no.6276 dated, *2-*September, 2015 on account of Grants- in- aid releasedin favour
ofATMA (Agricultural Technology Management Agency),Puducherry” as sanctioned
towards assistance to the Union Territory of Puducherry for Wie ae for
implementation of Centrally Sponsored Scheme “National e-Governance an-Agriculture
(NeGP-A) in Department of Agriculture & Cooperation” during financial year 2015-16.
Certified that
1. The Grantee is not required to execute the bond.
2. Ihave no reason to believe that the grantee is involved in corrupt practices.
3. The payment may be made to “ATMA (Agricultural Technology Management
Agency)Puducherry”through RTGS(copy enclosed).
4. Funds were released in third quarter of 2014-15 The UT of Puducherry have been requested to
furnish the Utilization Certificate.
en Rpees)
[B.E, :2015-16 |: Rs.2,00,00,000/-
“Expenditure including this bill |: Rs.31,71,220/- Se ப்பது :
——— fe
Ce ee ம. Se
=
HE ress
(Anita Khanna)
Section Officer & DDO
Tele: 23382401
(seat Wet /ANITA K )

<!-- page 2 -->

No.Z-11018/15/2014-IT(Pt) Computer No.6276
Government of India
Ministry of Agriculture
Department of Agriculture & Cooperation
KrishiBhavan, New Delhi
Dated, the 03 September, 2015
To,

The Pay & Accounts Officer(Sectt.I)
Department of Agriculture & Cooperation,
Krishi Bhawan,
New Delhi.

Subject: Release of funds/Grants in aid to 01 Union Territory (UT) under “National e-Governance
Plan-Agriculture (NeGP-A) in Department of Agriculture & Cooperation” during financial
year 2015-16 — regarding.

Sir,

1 am directed to convey the sanction of the President of India to the release of funds (first
installment) to the tune of Rs. 11,69,921/- (Rs. Eleven Lakhs Sixty Nine Thousand Nine Hundred
Twenty One only) towards Grants-in-aid to Agricultural Technology Management Agency (ATMA)
towards assistance to the Government of Puducherry for implementation of “National e-Governance
Plan-Agriculture (NeGP-A) in Department of Agriculture & Cooperation” during financial year 2015-16.

2 It is informed that with the Centre-State funding pattern modified/revised from 2015-16,
the sharing pattern of funds between Center and State for implementation of the National e-
Governance Plan on Agriculture (NeGP-A) has been revised to 50:50 from
earlier 90:10.
35 Further, it has also been decided to adopt a decentralized implementation model for
procurement of hardware. Accordingly, the ongoing centralized procurement process for
hardware for States has been terminated. The States will have to make procurement of Hardware
and install these as per their needs/priorities and the principles/guidelines enumerated herein from
funds released by the Government of India.
4. Out of the funds already released under NeGP-A (FY 2014-15), the site preparation, where
ever completed in the State shall be utilized for hardware installation being procured by the State
under NeGP-A. Unspent balance, if any, will be utilized for carrying out NeGP-A activities
during current financial year. Similarly, unspent balance of AGRISNET funds with the UTs will
also be considered as part of Government of India resources available for NeGP-A. Fresh release
for current financial year is being made to the UTs. Union Territories are required to contribute
matching share (50%) for this year releases. Balance share of funds would be made available in
coming years as per availability of funds. 11 is also requested to refer to this Department’s letter of
even number dated 31.07.2015 issued to all the concerned States/UTs.
5; It may also be noted that the unspent balance of AGRISNET, if any, will have to be
utilized in this Financial Year itself, failing which the concerned UTs having such unspent balance
may surrender the available funds to the Government of India through Demand Draft addressed to
PAO(Sectt.I), Department of Agriculture & Cooperation, New Delhi and payable at Delhi.
6. Following activities are required to be carried out by States as part of NeGP-A
implementation:-

(i) Sites Preparation of offices where hardware is to be installed and establishment of

Computer Training Labs.
(ii) Procurement, Installation and accounting of Hardware/System Software.
(iii) | Backup power arrangements, wherever required.
Contd..p/2-

<!-- page 3 -->

De

(iv) Hiring of manpower on contract basis (Data Entry Operators (DEOs), setting up of
State Project Management Units (SPMUs)

(v) Connectivity for the locations where hardware is being installed and Data Digitisation.

(vi) Recurring expenditure on consumables for these hardware.

(vii) Customization of applications as per State/UTs specific requirements.

JB In view of limited funds available in 1” year, UTs are requested to work out realistic
requirements of hardware to be procured from present funds available, while also catering for
carrying out other above mentioned activities. Following parameters may be kept in view while
working out hardware requirements:-

(viii) Computers and peripherals to be provided to the field locations after considering
existing availability of hardware from various resources of the Union Territories and
AGRISNET.

(ix) | Minimum one and maximum up to three desktops and a printer to be given at Block
level, keeping in view the availability of the power and physical infrastructure.

(x) No Touch Screen Kiosks, Hand held devices and hardware for Mandis (APMCs) to be
procured from this year release. Separate instructions will follow.

(xi) In compliance of Department of Electronics and Information Technology(DeitY) letter
No.NIC/Cloud/2015-DCWS(Pt) dated 29.3.2015, the Government has decided that no
Data Center (Servers etc.) hardware is to be procured and all new State
Websites/Applications will be hosted on NIC cloud/State Data Centers.

(xii) Adequate funds (out of this year total availability) to be earmarked for establishing
connectivity (if not existing earlier), and hiring of Data Entry Operators (DEOs) as per
State/UT requirements. This manpower may be provided in such locations after
installation of hardware.

(xiii) Steps may be initiated to establish SPMUs at the earliest so as to help departments as
dedicated resources in planning and execution of the project.

(xiv) For carrying out the activities under NeGP-A, as enumerated in Para 7 (c ), (f) and (g)
above, proposals may be sent to this Department.

8. It may also be ensured that NeGP-A is implemented for all three departments i.e.
Agriculture, Horticulture, Animal Husbandry Dairies and Fisheries hitherto fore.
9. The above arrangement is for procurement of hardware for this year only. UTs may
prioritize the requirement to ensure availability of hardware and other prerequisite at the Block,
District and State HQ. UTs are requested to forward the actual requirements of hardware for this
year, in the format attached at Annexure-II attached with DO letter of even number dated
31.07.2015, keeping in mind the fund availability.
10.The funds would be utilized in public interest and strictly for the approved components of the scheme
within the terms and conditions laid down in EFC and as per NeGP-A guidelines.
11.No further funds will be released till the Grant released stand fully utilized or surrendered to the
Government of India. The Union Territories concerned should ensure that matching share is released for
carrying out the activities under this scheme.
des Proposal for additional release of funds (second installment) may be forwarded to the Government
only after ensuring that the funds already released stands fully utilized including the State share. The
Utilization Certificate and the Physical & Financial Progress Report in prescribed format should also be
forwarded with the proposal.

Contd...p/3-

<!-- page 4 -->

ப்‌

13. The accounts of the scheme shall be maintained properly and separately and submitted as and
when required. They shall be open to inspection by an officer deputed by the Government of India or the
State Government/UTs.

14. The Union Territories shall maintain a record of all assets acquired wholly or substantially out of
the Government grant and maintain a register of such assets in the prescribed proforma (form GFR-19-A)
contained in General Financial Rules, 2005. If the agency ceases to exist at any time, such properties shall
be reverted to the Government of India.
iby The concerned Union Territoriesshall ensure submission of timely return in respect of its activities
under the scheme National e-Governance Plan-Agriculture (NeGP-A) in Department of Agriculture &
Cooperation” during financial year 2015-16 for which grants is being sanctioned.

16. The aforesaid expenditure may be debited to the following Heads of Account:-

[Head of Account ‘| Description ee i es
Major Head -2401 ட Grants-in-aid to State Governments
| Minor Head - 800 __ _ | Crop Husbandry zs
ட. ்‌ ப... | KrishonnatiYojna-State Plan ன்‌ ்‌
22 ட National E-Governance Plan-Agriculture ff |
02092 _____| Information Technology 2s |
450231- | Grants in aid General (2015-16) : |
17. The Union Territoriesshall furnish the Utilization Certificate in the Prescribed format (GFR-19A)
within 12 months of the closure of the financial year as laid down in 212(1) of General Financial Rules,
2005 and also the achievements-cum-performance reports in terms of Rule 212(3) of General financial
Rules,2005 to the sanctioning authority.
18. This issues with the concurrence of Integrated Finance Division, DAC vide AS &FADy.
No.FTS.6276 dated 12.08.2015and Budget Section ECR No.361 dated 14.08.2015.
i" ithfully,
— r
பு
(Promode Kumar lah. 5
Under Secretary to the Govt. of India
Tel. 23385957
Distribution:- (wiz Pare Piz/PROMODE KUMAR SINGH)
‘WAV எர பாச Secretary
SRA GEOR/Govt. of India
1. Chief Secretary: Government of Puducherry ஐடி ஸ்ம of Agricuiture
2. Secretary(Planning/Secretary(finance)/Secretary(Agriculture)/Secretary(IT), of ot ies eeee 1.8 Coopn,
3. Joint Secretary (e-Governance), Department of Information & Technology, DeitY, New தனிம வனக
5. Director (Agriculture), Directorate of Agriculture, Government of Puducherry-605001
6. Resident Commissioner, Union Territories of Puducherry, New Delhi
7. Deputy Director General, National Informatics Centre (Agriculture Service Division), New Delhi
8. Sr.PPS to Secretary (A&C)
9. PPS to AS(RS) (AS&FA)/JS(IT), Department of Agriculture & Cooperation
10. The Principal Accounts Officer, Department of Agriculture & Cooperation, New Delhi
11. Director of Audit, AGCR Building , New Delhi
12.Director(Budget)/Director(IT)/Deputy Secretary(Fin)Sr. Technical Director(NIC)/U.S(Fin-
V)/AD(Budget)/ B&A Section, DAC
13.HindiAnuvadAnubhag for fair Hindi Translation ee 3
14.Guard File wa ஷ்‌
15.Spare 5 copies. 5) 5!
(Anita Khanna)
Section Officer(IT)
ஜானா afar /Soctic ட்‌
உட்கும்‌
அணைய. லர்‌
பபபல ee Dell

<!-- page 5 -->

* groans 740 Bank Account Details - Rey - singhpromode@gmail com - Gmail
5 : as S.SEZHTAN BABU, த அட EEE Tah Oats ர aes
i COMPOSE t DY. DIR. OF AGRI, - cum- NODAL OFFICER (NeGP - Aj,
E . } DIRECTORATE OF AGRICULTURE
be PUDUCHERRY - 605 001
Poe 0413 - 2336543; 2336945:.23360¢
்‌ Mobile No: 94425 79497
---- Otiginal Message ----—---
ல்‌ From. cbspondicherry “யா படி untoniankotindia. com> x
ட்‌ Date: Mar 31, 2015 4:06:18 PM
- Subject: Bank Account Details - Reg
்‌ Dear Sir/Madam,
ந ல Greeting for the day.!
Search people
: We have furnished the Account Details as per the RTGS rec
ல்ல ளகக ட்‌ அன Name of Account : PROJECT DIRECTOR (ATMA) AGRISNET PUDU
pee aa pn ee IFSC CODE : 0110537951
PEepublicdalk.Ga_- Sepa தல்‌ ப :
இலபல eon பவட அரி MICR CODE :605 026 002
அணத te ர ளட அ : Address:147, ] N Street, Pondicherry 605001
ig ON 2 eager Bank Code ~ 026
pete YES 110 இணைக
See eSHORATEN aoe = Have a nice day.
Spoor ectoragriculture== 22
பட டைட்‌. ட. Thanks & Regards
teeewreAshok Saha cgi Branch Manager
: Bhoopendra 2109. அஹ Pondicherry Branch
So eae a 0413-2337044
ல்‌ i aes emcee 4
12:௮1 googie, com/matliwOitinbox!14c6I72theaeaes ME

<!-- page 6 -->

Sanction Details Page 1 of 2
தக ப து ee 0)... cae அட டட Mone anne பபபல ட அகத்தி அட்‌ கட பம்‌
பத்தி
és | Welcome: Parveeta Cag a
= | Dhawan ange
a User Type: PD re Password
i Fi ial Year: 2015-
Public Financial Management System-PFMS Brees Help
ட்‌ a ரணி CPSMS)
0/0 Controller General of Accounts, Ministry of Finance
Home Sanction Details
Controller: 001-AGRICULTURE Sanction Approved
Users Status:
acon Sanction Z-11018/15/2014-IT(Pt.) Comp. Sanction 03/09/2015
Number: No. 6276 Date:
Sanctions || Sanction Type: Transfer (DDO Bill) Sanction 1169921
| Amount:
Sanction Custom Fields | IFD Number: Dy. No.FTS 6276 AS&FA IFD Date: 12/08/2015
Plan Scheme: 9423-SUB MISSION ON PAO: 000001-PAO(Sectt)-I
Printing Templates INFORMATION TECHNOLOGY
: DDO: 200010-S.0.(CASH),DEPTT. OF Remarks: ok
பபப Templates | AGRI & CO-OP,KRISHI
BHAVAN,N.DELHI
Reports |
ன்‌ | Created By: soit Created On: 07/09/2015 04:41:33 PM
Modified By: soit Modified On: 07/09/2015 04:58:58 PM |
My schemes File Uploaded: puduchery.pdf
Scheme Allocation es
Register/ Track Issue | Grant: 001-Department of Agriculture Function 2401008004502-NATIONAL
and Cooperation Head: E-GOVERNMENT PLAN
AGRICULTURE- INFORMATION
OLD uc TECHNOLOGY
Object Head: 31-GRANTS-IN-AID GENERAL Category: 9-PLAN VOTED-EXPENDITURE
Agency Details:
Sr.No Agency Name City District State | Country Gross
| | | Amount
1 Agricultural Technology Puducherry | PUDUCHERRY | PUDUCHERRY 1169921
Management Agency,
Puducherry
Sanction Approved Successfully But SMS has not been sent due to network issue.
Edit Sanction| |Payee Details} |Cancel Sanction) |Print Sanction Order;
a
ee |
_ qe /ANITA 16 ்‌ ல்‌ oe ?
(aa வவர 009
அஜா ட்‌ பண
சான ட ot ngricultur?
ght வகிப்பது Aan & 09287.
aE 2 PE iow Osi
https://pfms.nic.in/Sanction/SanctionDetails.aspx?sid=04u Y 0GV f2uc= 9/7/201

<!-- page 7 -->

GRANT © MHSBRIAL ஜ்‌. ஒல AMOUNT ர்‌.
TO hot பப ப ட
பாய ம்ப
THIEL te பட epee 92
CS eee
TD irri Ono
