---
doc_id: "1c7ecfcafbf99199"
source_url: "https://agri.py.gov.in/Tenders/TenderPDF/0001_179.pdf"
ministry: "Agriculture and Farmers Welfare Department, Puducherry"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5fb086bd057c6dd6"
---

<!-- page 1 -->

- 3 sEP 2020

GOVERNMENT OF PUDUCHERRY
DEPARTMENT OF AGRICULTURE & FARMERS WELFARE
OFFICE OF THE ADDITIONAL DIRECTOR OF AGRICULTURE

e7h3

I{ARAII{AL
*****

e-Tender Notice

$Dt(

No. 18C/ADA/KKL/DD(AE)-CTW/e-Tenderl20126-2zl

- qFl,

d

dt:01.09.2o26

"e-Tenders" are invited on behalf of the President of India by the Additional Director of
Agriculture, Department of Agriculture & Farmers Welfare, Karaikal from the manufacturer or
authorLed Stockists or eligible contractors or service providers for Supply, Fixing and
executing of Llftlng and Erection of Submersible Motor Pump set , Rewlnding of
Submersible Motor and Reconditioning of Submersible pump-15HP including replacing
the bushes/bearings and impellers , Rewinding of Submersible Motor and Reconditioning
of Submersible pump-15HP without replacing the bushes/bearings and impellers ,Fishing
Operation, Compressor operation work, and suppty and fixing of BCH Starter 20 HP, BCH Relay 17.5
A to 23.5 A, BCH Conductor 40 A, BCH NO Volt Coil - 415 V, Single Phase Preventer, Hour Meter 415 V, 4" Dia UP[/C ISI Column Pipe of iMt each, 6 Sq. mm. ISI Flat Cable, 4" GI Clamp Set, 4" CI
Adapter, 4" G.I Flange set, lOO Amps Fuse Unit set, 7l2O Service wiring (Aluminium), 3 Phase ON
OFF switch Main box 44O V,4" GI Bend, 4" GI Coupler, Panel board rewlring including material,
Volt meter (O-4OO) V, Ammeter (2OA - 60A), GI frame for Panel Board, Panel board sheet
8mm thick nylon sheet lm x lm x 8mm thick, Earthing by 314" GI pipe x 1.5Om B class
proper lnstallation, 12"Dia upvc CM Casing pipe Capping of 1.2O mt depth, Creatlon/
Construction of Concrete Wall of 30 Cm thick and 1.2O Mt Height lncluding plastering,
1O" Dia Steel Plate Top cover on the existing Tube wellr" for the Community Tube wells in
Karaikal region through e-tender platform https://pudutenders.eov.in. Tenders submitted in
any other form will not be accepted.
TENDER SCHEDULE

sl.
1

)
3.

4

Subject
Download documents & Bid submission start
Last date of Submission of Tender Online
Last date of submission of original Tender
Fee and EMD fee by Post/Personally
Date and Time of opening of Tenders

Date and time
07.09.2026 by 5.00 PM
2O.O9.2026 bv 5.00 PM
2L.o9.2026 by 5.00 P\,!
22.09.2026 by 10.00 AM

(If these days happen to be a holiday the next working day will be the date for item Nos. 2

and 4)

Tenderer(s) are requested to stick on to the date and time specified strictly.
Tenders will be accepted only if submitted in the prescribed manner. Tenderers are
requested to read the instructions on help for contractors, information about Digital
Signature Certificate, resources required and bidder's manual kit at the home page of the
website https://pudutenders.sov.in. or http://demoeproc.nic.in/ before submission of
tender through online.
Helpdesk @eprocurement Cell: 04 13-2220225, 04 13-2233262

Email :-eproc.py@support.gov.in (or)
support-eproc. pon@nic. in

Additional Director of Agriculture
Karaikal

To-/

\-fW.U Board, Directorate of Agriculture, Puducherry
II. Notice Board of:

1. Collectorate; 2. O/O ADA, Karaikal; 3. Karaikal Municipaliff; 4. Karaikal KVK,
Thennangudy; S. Government Seed Farm, Madur; 6. Commune Panchayat- Nera'uy,
T.R. Pattinam, Kottucherry, Nedungadu & Thirunallar; 7. lJztravar udhaviyagam Kottucherry, Melakasakudy, Nedungadu, Thirunallar, Thennangudy'

Thalatheru,

Ambagarathur, Vizhidiyur, Nearvy & T.R. Pattinam, Su RenU-Uy
