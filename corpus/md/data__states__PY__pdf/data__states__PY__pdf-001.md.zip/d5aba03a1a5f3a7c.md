---
doc_id: "d5aba03a1a5f3a7c"
source_url: "https://dit.py.gov.in/sites/default/files/IT-Policy-2017.pdf"
ministry: "Information Technology Department, Puducherry"
title: "Click Here to Download - I.T. Policy - 2017"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a2d5016cbbac2f67"
---

<!-- page 1 -->

Registered No. SSP/PY/44/2015-17
WPP No. TN/PMG(CCR)/WPP-88/2015-17
Dated : 20-11-2017
Price : ` 11-00

Registered with the Registrar
of Newspapers for India
under No. 10410

  
La Gazette de L' État de Poudouchéry
The Gazette of Puducherry
PART - I
EXTRAORDINAIRE

 
 


Publiée par
Autorité

` 11-00

Prix : ` 11-00





No.

192 Poudouchéry

No.

Puducherry

EXTRAORDINARY
Published by
Authority

Price : ` 11-00



2017 }

 |

20 {

Lundi

20

Novembre

2017 (29 Kartika 1939)

Monday

20th

November

2017

GOVERNMENT OF PUDUCHERRY
DEPARTMENT OF INFORMATION TECHNOLOGY
(G.O. Ms. No. 3/DIT/2017, Puducherry, dated 16th November 2017)
NOTIFICATION
Whereas, most of the objectives outlined in the Information Technology Policy, 2008 have been achieved,
thereby, the fast moving technology landscape has transformed drastically. As the Information Technology sector
plays a vital role in the economic development, there is an apparent need to review the existing Information
Technology Policy, in view of renewed emphasis laid by the Government of India though its flagship Digital India
program and to secure additional employment opportunities to the youth. The Government of India made a new
approach towards the growth of the industries across the country and adopted several new strategies like Make in
India, Startup India, Standup India, and Ease of Doing Business.
2. Whereas, the Government of Puducherry is also committed to formulate its new Information Technology
Policy in terms of the new policy guidelines of the Government of India and it is proposed to review the existing
Information Technology Policy, 2008.
[ 1901 ]

<!-- page 2 -->

1902
1902

LA GAZETTE DE L’ETAT

[ PART-I

3. Whereas, several rounds of consultative and interactive meetings with line Departments, National
Association of Software and Services Companies (NASSCOM), Confederation of Indian Industry (CII), Chamber of
Commerce, all Industrial Associations, Industry delegates were held and their valuable suggestions/inputs are
incorporated in the Information Technology Policy, 2017.
4. Whereas, the Information Technology Policy, 2017 was approved by the Council of Ministers on 12th
September 2017.
5. And now, therefore, the Hon'ble Lieutenant-Governor is pleased to accord approval for the “Information
Technology Policy, 2017” which is appended to this order.
6. The Department of Information Technology shall formulate guidelines wherever required for implementing
the schemes.
7. This issues with the concurrence of the Finance Department vide I.D. Note No.1953/FC/FD/F5/A3/2017,
dated 8-9-2017.
(By order of the Lieutenant-Governor)
Dr. A.S. S IVAKUMAR ,
Joint Secretary to Government (Information Technology).
————
INFORM ATION TECHNOLOGY POLICY – 2017
1. PREFACE AND OBJECTIVES.—
1.1. Information Technology Policy 2008.— The Information Technology Policy-2008 attempted to
promote sustainable and balanced Information Technology development and promotion by gainfully utilizing the
available human resources with the technology that was in vogue during that time. It had identified medical
transcription, BPO's (Business Process Outsourcing), electronics and software development along with few others
as thrust areas. In order to promote Information Technology development, the policy announced various fiscal
incentives. Further, the policy assures creation of infrastructural facilities across the Union Territory apart from the
structural changes in the existing system. There was a brief lull after 2012 mainly due to withdrawal of tax concessions
and the downturn in the economy at national level.

* The policy provided for sensitization and awareness of the Information Technology in the lives of
the citizens and its impact.

* All the tax concessions have been withdrawn and the scheme of subsidy needs to be restructured.
* The policy did not provide for a long-term vision for the Information Technology development.
1.2. Need for New Information Technology Policy.— Though most of the objectives outlined in the
Information Technology Policy-2008 have been achieved, similarly, the fast moving technology landscape has
transformed drastically. As the Information Technology sector plays a vital role in the economic development, there
is a need to review the existing Information Technology policy, in view of renewed emphasis laid by the Government
of India through its flagship Digital India program and to secure additional employment opportunities to the youth.
The present Union Government made a new approach towards the growth of the industries across the country and
adopted several new strategies like Make in India, Startup India, Standup India, Ease of Doing Business.
Accordingly, the Government of Puducherry would also require to frame its new Information Technology
policy in line with the new policy initiatives of the Union Government across the country and hence, the need to
rework the existing Information Technology policy.

<!-- page 3 -->

PART-I ]

LA GAZETTE DE L’ETAT

1903

1.3.Vision.— The Union territory of Puducherry seeks to leverage the potential of Information and
Communication Technology (ICT) to transform itself from a Resource Based Economy to a Knowledge Based Economy.
In making this transition, the Union Territory will seek to be recognized as one of the leading State/Union Territory
in the Country on e-Readiness Index and also will adopt several new strategies like "Make in India", "Startup India",
"Standup India", "Ease of Doing Business". It hopes to achieve by:

* Attracting investment in the sector.
* Providing opportunities to its large educated people to contribute to the development of this Union
Territory.

* Creating a pool of highly skilled professionals who are at par with the best in the Country.
* Extensively using IT (Information Technology) in Government Sectors/ Undertakings/ Public Sector
Undertakings, etc.

* Focusing investments in Automation, Research and Development.
* Specific courses to be launched to provide project management and software marketing skills.
1.4. Background.— Government of Puducherry is working towards an Information Technology revolution.
It already has emerged as a hardware destination of India and also a center for Information Technology investments
in Information Technology services and Information Technology Enabled Services (ITES). Numerous companies
located here have won prestigious national awards for two consecutive years for earning highest foreign exchange.
A communication revolution is being taking place in Puducherry with the availability of adequate
International and National Bandwidth for both the basic and the value added services, by several Public and Private
Service Providers.
Following are few key differentiators which make the Union territory of Puducherry a preferred choice of
many international IT (Information Technology) majors as well as budding Entrepreneurs.
1.4.1. Infrastructure and its Strategic Location

* The Government of Puducherry has prepared Comprehensive Mobility Plan for the entire
Puducherry region covering an area of 293 sq.km. for achieving the desired Level of Service with
an investment of ` 5321 crores.

* The Union Territory has well connected roads, excellent civic services and other necessary
infrastructure that support the thriving of all industries.

* Proactive and business friendly administration facilitates time bound response to investor needs
and issues.

* For easy availability of finance, branches of national financial institutions exist in the Union
territory of Puducherry.
1.4.2. Air Connectivity

* Puducherry is mere 2 hours drive by road from Chennai International Airport, Tamil Nadu. Mahe
and Yanam are only 70 Kms. and 200 Kms. from Calicut and Visakhapatnam Airport respectively.
It offers proximity to existing Information Technology (IT) hubs, excellent connectivity, peaceful
law and order, and good standard of living.

* As Puducherry being a tourist destination place attracting both domestic and international
tourist, it has been proposed to expand the runway for providing air connectivity to various
destinations.

<!-- page 4 -->

1904
1904

LA GAZETTE DE L’ETAT

[ PART-I

1.4.3. Sea Connectivity

* Hover craft service between Puducherry and Cuddalore.
* Ferry services between Puducherry and Chennai.
* Ferry services between Puducherry and Karaikal.
* A truck terminal at Sedarapet in an area of 75 acres to cater for 2500 goods vehicles.
* MOU with Ennore Port to handle cargo from the existing Puducherry Port.
1.4.4. Electricity
Electricity Department will provide:

* Uninterrupted steady supply of power is available at competitive rates than the neighboring
States.

* More sub-stations to reduce distribution losses.
* Augment the existing power sub-station capacities.
* Separate sub-station at each existing and new industrial estates to ensure quality power.
* Power availability at various sub-stations and locations will be made available on the website.
* Effective Consumer Grievance cell.
1.4.5. Resource Base

* Union territory of Puducherry has all the required resources of skilled and educated manpower,
excellent infrastructural facilities and being served by a committed Government. This not only
provides a vibrant innovative eco-system but also effective cost of operation in these industries.

* Puducherry is an educational hub with 19 Engineering Colleges, 17 Science Colleges, one Central
University, 8 Polytechnic Colleges and 20+ Medical Colleges, there is more to contribute towards
Information Technology growth by striking synergy at appropriate levels.

* This Union Territory has one of the highest levels of literacy in the country.
* This Union Territory has one of the highest penetrations of mobile networks in the country.
1.5. Objectives
This Information Technology policy for Puducherry has been prepared with the following objectives:

* To establish Puducherry as preferred destination for investment in Information Technology/
Information Technology Enabled Services (IT/ ITES) industries.

* To support industries by providing International quality Information Technology infrastructure and
effective Government-business interface.

* To encourage education-led economic development and create more employment opportunities.
* To bring-in increased transparency, efficiency and accountability in Government operations through
e-Governance.

* To achieve the main objectives of the nine pillars of flagship Digital India Program.
* To achieve the highest digital literacy in the Country.
1.6. Targets : The above objectives could be translated into the following measurable targets to
act as guiding principles for the implementation of the policy and further assist in monitoring and reviewing of
progress.

<!-- page 5 -->

PART-I ]

LA GAZETTE DE L’ETAT

1905

Sl. No.

Target

Measure

Potential Impact

(1)

(2)

(3)

(4)

1

Increase of at least 50% in the number Number of applications for 100% Awareness on Information Technology
o f r egistrations b y Info rmatio n reimbursement of registration fee/ policy incentives and growth in
Technology Companies
stamp duty.
registrations.
Number of registrations with Registrar Growth in organized Sector.
of Companies/Industries Department.

2

Achieve 100% Information Technology A specialized course in Information More job opportunities for youth
literacy in Schools and Colleges.
Technology to be introduced at all and availability of skilled labour
levels in all educational institutions for Information Technology Companies.
within next 3 years.

3

All Government Departments to be Guidance by State Apex Committee. e-Governance initiatives such as
computerized and networked.
e-Distr ict, State Resid ent Data
Hub, State Data Center, Common
Ev er y Go v er nmen t e mp lo ye e to Training programs implemented Service Centers (CSCs), etc.
receive training in basic Information and Survey on Information Technology
Technology usage.
usage across Departments.

4

5

Increase of at least 50% in earnings Amount of revenue earned in foreign Growth in international trade and
in foreign exchange from Information exchange in the Union Territory (UT). foreign investment in Information
Technology services and ITES.
Technology sector.

6

Increase in employment by at least Campus recr uitment and Unio n Economic growth through increased
50% in Information Technology sector. Territory (UT) employment exchange employment.
statistics.

7

Citizen services through Common
Service Centers (CSCs).

Usage statistics for e-services by Improved quality of life for citizens
citizens.
80 – CSCs are operational
130 – In principle approval for
CSCs for the year *

*

Would be operational by Financial Year 2017-18.
The above targets have been set for a period of next 5 years.
1.7. Definitions
Following are the definitions of the terms used in this Policy:
1.7.1 Information Technology Companies will include Information Technology Services (ITS), Information
Technology Enabled Services (ITES), Private Communication Providers (PCP's), and Software Industries,
Information Technology maintenance and servicing units and Hardware units.
1.7.2 Information Technology Services are broadly defined as Systems Integration, Processing Services,
Information Services (IS) outsourcing, Packaged Software support and installation, hardware support and
installation.
1.7.3 Information Technology Enabled Services are human intensive services that are delivered over
telecom networks or the internet to the range of business which may include but not limited to:

* Medical Transcription
* Legal Database processing

<!-- page 6 -->

1906
1906

LA GAZETTE DE L’ETAT

[ PART-I

* Digital content development/animation
* Remote Maintenance
* Back office operations - Accounts, Financial Services
* Data Processing
* Animation/Graphics Designing
* Call Centers
* Engineering and Design
* Geographic Information Service
* Human Resource Services
* Insurance Claim Processing
* Payroll Processing
* Revenue Accounting
* Support Centers
* Website Services
* Business Process Outsourcing (BPOs)
2. STRATEGY
To meet the targets and objectives laid down in its Policy, the Union territory of Puducherry will pursue
three broad strategies.

Infrastructure and
Human Resource
Development

Extended
Government
Support

Technology
Enabled
Governance

2.1. Technology enabled governance: To further promote the use of Information Technology, develop
the market for Information Technology products and provide Good Governance, the Government would maximize
the use of technology in all its processes. An Electronic Government (e-Governance) would incorporate technological
tools to set best-practice standards. Information Technology would be used to significantly impact the quality of
governance and as a strategic tool to simplify procedures and revamp and automate processes.
2.2. Infrastructure and Human Resource Development: Quality infrastructure and trained human
resources are critical for the growth of Information Technology and Information Technology Enabled Services (ITES).
Puducherry's human resources are the key to the Union Territory's future development and prosperity. Sincere and
hard working people of the Union Territory will be provided with every opportunity to participate in the 'brick' as
well as the 'click' economy. Only by preparing all sections of society for future challenges can Puducherry realise
its full potential and promise. The Union Territory will build the best-in-class Information Technology infrastructure
to equip its citizens accordingly.

<!-- page 7 -->

PART-I ]

LA GAZETTE DE L’ETAT

1907

2.3. Extended Government Support : Puducherry has accorded very high priority to Information
Technology. Information Technology has been identified as a thrust industry along with tourism. The Union Territory
firmly believes that the cost of technology would be rationalised by large-scale acceptance and use of Information
Technology enabled applications. Towards this end, the Union Territory will ensure that appropriate financial and
operational support is extended to entrepreneurs and enterprises in the software and hardware industries.
3. ACTION PLAN
3.1. Technology Enabled Governance
3.1.1. Government
(a) Various computerization projects executed in Government Departments like Transport,
Registration, Land Records, Police Department, Commercial Taxes Department, Health and
Education needs to be integrated to effectively deliver the services needed by the citizens. To
address the above, online e-District application has been launched to provide integrated service
delivery.
(b) Develop Interoperability systems and standards for seamless transfer of information between
domains and make it mandatory through legislative mechanisms.
(c) Initiate moves to encourage developing the linkages for the existing databases to the public
domain to enable online activities and seamless integration.
(d) Initiate and develop Data Warehouses in every Department to facilitate the process of Electronic
Delivery of Services (EDS). These data warehouses will be linked to the Central database, which
will be maintained in the State Data Centre. Connecting to the existing systems and databases
and developing a comprehensive information system that integrates into a data warehouse for
analytical data mining to support decision-making will be the core issue for the interoperability
standards.
(e) Establish links worldwide with institutions for interchange of ideas and experiences.
(f) Implement projects on Smart Cards.
(g) Steps towards digitization of the domain knowledge available in Secretariat and Government
offices all over the Union Territory and will be made available for all Departments to facilitate a
knowledge-based decision making process.
(h) Suitable innovative schemes will be devised for Government employees to upgrade the levels of
Information Technology usage for Government Departments. Specific need based syllabus will
be drawn up to remove the techno-phobia for employees at all levels.
(i) The guidelines under the Information Technology (IT) Act, 2000 of Government of India, and
further amendments by the Government of Puducherry along with the rules framed thereunder
will be adopted.
(j) An Information Technology Cell with a designated Nodal Officer would be made fully functional
in all Government Departments. The role and responsibility of the Information Technology Cell
in each Department/Government Body will be:

* To prepare an overall Information Technology (IT) vision or strategy for a five year period
with respect to the Department concerned

* Identify the key areas which have maximum citizen interface, and which can be electronically
delivered.

<!-- page 8 -->

1908
1908

LA GAZETTE DE L’ETAT

[ PART-I

* Implementation, maintenance and frequent upgrading of the applications.
* Government will establish a multilingual portal for exchange of information and views on the
directions of the Government's Information Technology (IT) strategy and emerging trends in
the industry, to identify key issues associated with EDS (Electronic Delivery of Services) for
viable Public Private Partnership and to discuss the policy framework to develop channels for
EDS in an integrated manner.

* Government will also develop local language portal, to function as a hub for EDS services of
that Region, inform the developmental activities, propagate the policies, highlight the emerging
areas for the non-urban areas, and address the local officials and the elected public
representative.
(k) Steps would be taken to boost the Information Technology (IT) usage in the most widespread
sector, viz., Agriculture and allied activities and Integrated Rural Development, through Uzhavar
Udaviyagams/Information booths/Public kiosks, etc.
(l) Most of all, the Government functioning shall be realigned such that front-end processes are
made more user friendly and back-end processes are made more efficient.
(m) Government to initiate action towards the standardization of basic data which ensures the
manageability, portability and interoperability of systems across the Departments.
(n) Databases of relevant information to be created for each Department shall be made available to
other Departments and the public wherever necessary.
(o) Geographical Information Systems (GIS) to be attempted which are of strategic advantage for
applications like spatial planning, environmental protection, utility management, traffic regulations,
etc. Steps would be taken extensively to use the Geographical Information Systems (GIS) for
planning, especially for Disaster Management applications.
(p) As a part of right to information, all public domain information, such as, Official Gazette
notifications, acts, rules, regulations, policies, programmes, etc., to be digitized and made available
for electronic access.
(q) Making the Government a Smart buyer, by rewriting the purchase rules relating to Information
Technology (IT) products and services.
3.2. Infrastructure And Human Resource Development
3.2.1. Infrastructure Development
(a) Reliable and quality power supply shall be ensured to Information Technology (IT) Parks and
stand-alone units by permitting unlimited power backup, Captive Power Generation and status
as Independent Power Producers.
(b) The Union Territory Government will ensure through communication providers, the availability
of complete bandwidth requirements.
(c) The Union Territory Government will make Puducherry a smart city by allowing wireless
broadband internet access available across the city.
(d) FSI (Floor Space Index) may be extended with reference to the existing norms stipulated in the
governing land use zones in designated Information Technology (IT) Parks including private
Information Technology (IT) Parks. Such requests need to be addressed to the concerned local
Planning Authorities.

<!-- page 9 -->

PART-I ]

LA GAZETTE DE L’ETAT

1909

(e) To provide business as well as support facilities in the form of community development,
Information Technology (IT) Parks could be developed with an objective of setting up mini
hi-tech cities, wherein, residential, recreational, educational, healthcare, and entertainment facilities
are provided for various classes of employees and their families. In addition, Government will
plan and provide well developed residential areas close to the Information Technology (IT) Parks.
3.2.2. Human Resource Development
(a) Government of Puducherry has invested huge amount to improve the employability skill of its
graduates by implementing Information Technology (IT) Finishing School. Under this program
nearly 5000 and above engineering and sciences graduates are trained in various skills and are
made industry ready for absorption.
(b) The Government will initiate standard assessment and certification programs for various levels
of skill requirements in the industry. Certification for software training will be governed by existing
standards prescribed by the Ministry of Communications and Information Technology,
Government of India. For quality certification of training in hardware, servicing and maintenance,
Directorate of Information Technology will be the nodal agency to prescribe minimum standards
of eligibility.
(c) Computer Education Program in the Government Schools will be extended to enable the school
students to pick up adequate computer skills down to Primary School Level in a phased manner.
(d) Computers and Internet access to be made available to all Schools down to the Primary level.
(e) Specialized training required for ITES employment will be built into the Colleges training
programme. Finishing Schools have been setup to bridge gap in the soft skills area.
(f) Government will take up initiative under a Public Private Partnership mode for imparting quality
Information Technology (IT) education in all Government and aided Schools.
(g) There are many Engineering Colleges in and around Puducherry, conducting courses in Computer
Engineering, Electronics and Communication Engineering, Information Technology and other
engineering fields. The Union Territory will also encourage setting up of private engineering
Colleges as per existing policies. This will ensure the availability of qualified, trained manpower
for the Information Technology (IT) industry.
(h) Training of Teachers for the computer education programs will also be done in a phased manner
over a period of 5 years. In addition to Government sponsored training programs, Union Territory
Government will facilitate and coordinate with other reputed sponsors for training of Teachers.
(i) The availability of English and French speaking Information Technology (IT) skilled manpower
in abundance will be leveraged to position Puducherry to attain a dominant share in the export
market in key areas like Information Technology (IT) training and educational sector, outsourced
processing services including backend work in industry verticals such as finance, insurance,
banking and airlines.
(j) All educational institutions of higher learning and Research and Development organizations to
be networked to provide quality education.
(k) Digital libraries to be set-up in public libraries and academic institutions.
3.3. Extended Government Support For Economic Development
3.3.1. Land Bank : The Government may encourage PPP (Public Private Partnership) projects and may
invest in the cost of the land with ownership to the Government; in such cases which shall be the equity
of the Government. The Government shall also facilitate to get necessary approval from appropriate authorities

<!-- page 10 -->

1910
1910

LA GAZETTE DE L’ETAT

[ PART-I

from such projects. The Government has also identified land bank of 25 acres at Mettupalayam for promotion
of Information Technology Park. Consolidation of additional Land Bank is also on the anvil while preparing
master plan for the entire Union territory of Puducherry. The consolidated Land Bank would give Union
Territory strategic edge in attracting investments. Such Park would have roads, power, water, sewage lines
to start industrial activity in shortest possible time.
3.3.2. Promotional Initiatives
(a) The Government will take effective steps to create brand equity for Puducherry and encourage
participation in International/ National events to position Puducherry as the destination of choice.
(b) Information Technology (IT) Investment Facilitation Centres would be established in select States
in the Country where significant ITES opportunity exists in collaboration with industry
associations like National Association of Software and Service Companies (NASSCOM) to provide
guidance in setting-up businesses and availing incentives from the Government's policies.
(c) The State would appoint senior officials from the Government of Puducherry as "relationship
managers" for all prospective investors to assist in the process of setting up facilities in the
Union Territory (UT).
(d) Since Puducherry has large French speaking population, specialized agencies and help desk (in
embassies) would be setup to facilitate networking with countries, where French is a mother/
official/significant language, like France, Belgium, Luxembourg, Switzerland, Austria, Monaco in
Europe; Québec in Canada; and Cameroon, Mali, Guinea, Mauritius, Madagascar in Africa.
(e) Government recognizes the need to put in effective mechanism to determine infringement of
Intellectual Property Rights (IPR), Cyber Crimes, Software Piracy and crimes associated with
Internet and Information Technology (IT). With the passage of Information Technology (IT) Act,
2000 by Government of India, sufficient enabling mechanism including training for the law
enforcing authorities are being put in place to deal with cyber crimes.
(f) Domain expertise in non-Information Technology (IT) areas will be synergized with Information
Technology (IT) industries to expand their base of activities and level of penetration. This will
promote Business Process Outsourcing (BPOs) for MNCs (Multi-National Companies).
(g) The Government will provide a preferential and a dedicated space for the Small and Mediumsized Enterprises (SMEs) and Small Scale Industries (SSIs) in the public Information Technology (IT)
Parks.
(h) The Government will encourage and send joint business delegations to emerging markets so as
to create necessary networking environment to tap the large global markets for the Small and
Medium-sized Enterprises (SMEs) sector.
(i) The Government will facilitate participation of SMEs in Government approved International/
National Information Technology (IT) trade shows so as to enable them to tap new markets.
(j) Investment related work would be dealt by a separate Cell in Directorate of Information
Technology, Puducherry in coordination with the Directorate of Industries and Commerce,
Puducherry.
(k) The Government would also take steps to conduct 2 to 3 days Invest Events that will be held
every alternate year in Puducherry and in other States/Countries to showcase what the State
has to offer. This event would be jointly promoted by the Department of Industries and Commerce
and the Department of Tourism.

<!-- page 11 -->

PART-I ]

LA GAZETTE DE L’ETAT

1911

3.3.3. Research and Development Initiatives: India is fast becoming a hub of Research and Development
activity. Multinational companies have chosen India as their base for R&D activities. Puducherry
Government will leverage the Union Territory's Unique Selling Proposition (USP) of an 'Intellectual
Powerhouse' to convince Information Technology (IT) MNC's to setup research centres in Puducherry.
(a) Investments in Very Large Scale Integrated (VLSI) chip design services/ Application Specific
Integrated Circuits (ASIC) design services and Embedded System design will be promoted for
enhancing the employment of highly qualified professionals.
(b) Nano Technology is an emerging area for effective delivery of Health, Energy and Computing.
These areas need fundamental R&D. Enabling initiatives will be undertaken to seed R&D activities
in areas like Advanced Computing, Nano Computing, Bio-Informatics, Nano and Micro Sensors
and other devices.
(c) The Government with an objective to provide R&D conducive environment shall provide worldclass infrastructure in terms of Science and Technology Parks with R&D laboratories, Plug and
Play facilities and other amenities.
3.3.4. Bridging the Digital Divide
(a) Union territory of Puducherry has already set up Skill Development Society and Skill Development
Mission. Based on the skill gap analysis and in line with National Skill Qualification Framework
(NSQF), the Union Territory of Puducherry proposes for short-term/long-term/ modular courses
in the existing Degree and Engineering Colleges with the participation of Industry and also
involving the Industrial Associations.
(b) Efforts shall be made to accelerate the process of PC and Internet penetration in the rural areas.
For this the Union Territory would promote setting up of assisted kiosks.
(c) A multilingual Internet Portal has been set up with links to Government Departments and services
to provide single window access "Any Time Any Where".
(d) Government will encourage setting up of Internet Kiosk and Online Libraries in existing
Infrastructure like Public Libraries/ Public Government Offices throughout the Union Territory.
(e) Conduct of Information Technology (IT) Exhibition, Seminars and Workshops will be encouraged
to increase the awareness among the general public.
(f) Conduct of Quiz Programmes and Certification Programmes for different age groups will be
encouraged through industrial associations.
(g) Conduct various digital and financial literacy programmes for different age groups with the help
of various NGO's, Self-Help Group's, Bankers, etc.
3.3.5. Ease of Doing Business, Single Window Clearance: The Government of Puducherry in its
endeavor to increase transparency and improve the efficiency and effectiveness of Government functions
has set up an Information Technology Industrial Guidance Bureau (ITIGB) in the Directorate of Information
Technology. The Bureau is established for effective coordination between the line Departments to enable
the entrepreneurs to get various licences.
The applications received through ITIGB are forwarded within three days to the respective line
Departments for the following purposes:
Information Technology Industrial Guidance Bureau (ITIGB): Single Window Clearance

<!-- page 12 -->

1912
1912

LA GAZETTE DE L’ETAT

[ PART-I

The Committee will be chaired by the Hon'ble Minister [Information Technology (IT)] and will have
the Secretary (IT), the Director (IT) and the Members from the following line Departments:
Sl. No.

Line Departments

Purpose

1

Chief Inspectorate of Factories and Boilers

CIF

Clearance under Factories Act

2

Directorate of Science, Technology and Environment

DSTE

Environment/Pollution clearance

3

Town and Country Planning

TCP

Site clearance

4

Puducherry Planning Authority

PPA

Clearance for building plan approval

5

Town and Country Planning Department.

TCP

Clearance for land Conversion

6

Revenue Department

REV

Clearance from land Acquisition

7

Municipality/Commune Panchayat

LB

Public objection/Issue of permission

Information Technology (IT) Industrial permission/licence/clearance/No Objection Certificate will be issued
within 30 days from the date of application through this Department/Single Window System.
3.3.6. Fiscal and Administrative Incentives: Financial incentives are extended to Information Technology (IT)
Industries are as detailed below:
(a) Declaring Information Technology (IT) and ITES units as Public Utility Services. (* Will be notified
in the Gazette)
(b) Permission to run 3 shift operations ( 24 x 7 operations) for the Information Technology (IT)
Industries will be granted by Labour Department subject to the provision of other facilities such
as one day off, facilities to women workers, etc. Labour Department has already granted exemption
to knowledge based industries in the Union Territory of Puducherry under the Shops and
Establishment Act/Rules 1964.
(c) Union territory of Puducherry to be classified in the following three tiers:
(i) Tier I

: Puducherry

(ii) Tier II

: Karaikal

(iii) Tier III : Mahe and Yanam
(d) Capital Investment Subsidy : (For new and expansion of existing industries)
(i) For Micro and Small Enterprises, 40% on the investments made on land, building, plant
and machinery subject to a maximum of ` 40 lakhs. *
(ii) For Medium and Large Enterprises, 35% on the investments made on land, building, plant
and machinery subject to a maximum of ` 35 lakhs. *
(iii) For Women/SC/ST Entrepreneurs, 45% on the investments made on land, building, plant
and machinery subject to a maximum of ` 75 lakhs. *
* Excluding GST amount, if any, OR while calculating the eligibility amount GST shall
not be included.
(e) SGST : (For new industries)
(i) For Micro and Small Enterprises, 100% of the net SGST paid will be reimbursed for a period
of 5 years for Puducherry (Tier I), 6 years for Karaikal (Tier II), 7 years for Mahe and Yanam
regions (Tier III). +

<!-- page 13 -->

PART-I ]

LA GAZETTE DE L’ETAT

1913

(ii) For Medium Enterprises, 75% of the net SGST paid will be reimbursed for a period of
5 years for Puducherry (Tier I), 6 years for Karaikal (Tier II), 7 years for Mahe and Yanam
regions (Tier III). +
(iii) For Large Enterprises, 50% of the net SGST paid will be reimbursed for a period of 5 years
for Puducherry (Tier I), 6 years for Karaikal (Tier II), 7 years for Mahe and Yanam regions
(Tier III). +
+ Necessary certificate for having paid the SGST has to be obtained from the Commercial
Taxes Department and produced.
(f) Stamp Duty Exemption: 100% stamp duty exemption for purchase/lease mortgages and
hypothecations of land/shed/buildings.
(g) Infrastructure Development (For IT/ITES): 30% subsidy subject to a maximum of ` 1 Crore
will be granted on the investment made on building with a minimum extent of 50,000 Sq.ft.
constructed area, by the infra developers/industries for leasing out to Information Technology (IT)
industries or for own industrial use (for manufacturer of computer systems, software/Information
Technology Enabled Services, Business Process Outsourcing (BPO) and Knowledge Process
Outsourcing (KPO).
(h) Power subsidy
(a) Fixed power cost reimbursement of 50 paise per unit for a period of 5 years for Puducherry
(Tier I), 6 years for Karaikal (Tier II), 7 years for Mahe and Yanam regions (Tier III). Applicable
to the hardware units will be extended to the software and ITES units
(b) For the purpose of power tariff, Software and ITES units will be treated as industrial units at
par with hardware units and power tariff applicable to the hardware units will be extended to
the Software and ITES units.
(i) Generator subsidy: 50% subsidy with a ceiling of ` 5 lakhs per industrial unit for micro, small
and medium industrial units
(j) Interest subsidy: (For new industries) The industrial units availing loan from financial
institutions towards creation of fixed assets and for working capital shall be eligible for an interest
subsidy to an extent of 25% of the annual interest amount paid, for five years which shall be
admissible from the date of commencement of commercial production, subject to a maximum of
` 5 lakhs per annum for a period of 5 years for Puducherry and 7 years for Karaikal, Mahe and
Yanam regions.
(k) Pollution Control Act
(i) All Software Industries will be exempted from the purview of Pollution Control Act.
(ii) Subsidy to Pollution Control Equipment: The units which are installing pollution control
equipment will be granted a subsidy @ 25% upto a maximum of ` 5 lakhs.
(l) Self-Certification By The Information Technology (IT) Companies
(i) Information Technology (IT) companies will be permitted to self certify for the purposes of
compliance of the following Acts:
(i) The Factories Act, 1948
(ii) The Payment of Wages Act, 1936
(iii) The Minimum Wages Act, 1948

<!-- page 14 -->

1914
1914

LA GAZETTE DE L’ETAT

[ PART-I

(iv) The Contract Labour (Regulation and Abolition) Act, 1970
(v) The Pondicherry Shops and Establishments Act,1964
(vi) The Payment of Gratuity Act, 1972
(vii) The Equal Remuneration Act, 1976
(viii) The Maternity Benefits Act, 1961
(ix) The Industrial Employment (Standing orders) Act, 1946
(ii) The self-certification by the Information Technology (IT) companies will be regarded as
sufficient compliance with the requirements of the different Acts and the rules made
thereunder regarding the maintenance of registers and filing of the returns. The first filing
shall be manual. Thereafter, the subsequent returns shall be maintained in electronic form.
Any distortion/misrepresentation of facts while making self certification will be dealt with
penalties, apart from cancellation/stoppage of incentives wherever found necessary.
(m) Intellectual Property Protection Support: Assistance @ 50% subject to a maximum of ` 2 lakhs
for meeting the expenditure for obtaining domestic patent and ` 5 lakhs for international patent.
(n) Market Development Support: Assistance to Micro, Small and Medium Enterprises (MSME) units
for participation in international trade fair as a part of industry association will be given @ 50%
of total rent and literature and display material subject to a maximum of ` 5 lakhs.
(o) Assistance for Energy and Water Conservation: 50% cost of energy/water audit conducted in a
unit by a recognized institution/consultant subject to a limit of ` 25,000 will be reimbursed to
Micro, Small and Medium Enterprises (MSME).
(p) Quality Certification Subsidy: Assistance will be granted to the eligible Micro, Small and
Medium Enterprises (MSME) for maximum 3 quality certifications @ 50% of the cost of quality
certification with a ceiling of ` 2 lakhs for achieving Capability Maturity Model Integration
(CMMI) (Level 2 onwards), ISO 20001/27001, etc.
(q) State Awards: Cash award of ` 2 lakhs and a Citation will be given.
(r) Wage/Employment subsidy of 20% wage/salary up to a maximum of ` 5 lakhs per annum as per
industry, in case of workers who are covered under Provident Fund (PF) (if applicable) will be
granted for a period of 5 years for Puducherry (Tier I), 6 years for Karaikal (Tier II), 7 years for
Mahe and Yanam regions (Tier III).
(s) Technology Acquisition Fund: Assistance for acquisition of appropriate technology in any form
for specific product/process will be provided by way of 50% grant, subject to a maximum of
` 10 lakhs.
(t) Skill Enhancement Fund : 50% of fees subject to a maximum of ` 3,000 per person for 2 weeks
duration training on skill upgrading programme conducted by the Puducherry Management and
Productivity Council or any other institutes approved by the Department of Industries and
Commerce.
(u) Business Incubation Cells: Most of the institutes in Puducherry have Business Incubation Cells
within the institutes, but are operational only to the extent of creating awareness campaigns to
students. The Government will take steps to empower the incubator cells with financial support
and the same will be monitored by the Department of Information Technology (DIT) to seed fund
the business ideas of students.
(v) Promote Innovation and Product Development: The Government will promote innovation and
product development among the students and youth by conducting Annual Innovation and
Product/Service exhibition/Meet/Competition for College students to showcase their innovations.

<!-- page 15 -->

PART-I ]

LA GAZETTE DE L’ETAT

1915

(w) Promote Mobile Application based e-Governance: The Government is already providing
Government services through Mobile Platform to the public. Special impetus will be given to
firms working on mobile applications to facilitate the public to access all Government schemes
and information using their mobile phone.
(x) An Information Technology Park (ITP) will be treated as an ‘Industry’ and be eligible for the
financial incentives. The Government will also facilitate provision of water, power connection
and roads. ITP promoters will be assisted in obtaining necessary cable and satellite links for
connectivity.
4. IMPLEMENTATION FRAMEWORK ACTION PLAN
For a successful way forward for translating the objectives, initiatives, involvement, commitment and
monitoring from the highest level is needed. In light of this, following steps shall be taken by Government to achieve
its objectives under this policy:
4.1. To attract new investments in the Information Technology (IT) projects and to retain the existing
Information Technology (IT) establishments as well as to encourage them to enhance their capacity and turnover,
the following Committee under the Chairmanship of Hon'ble Chief Minister will be constituted so as to decide the
special incentives/concessions to the Information Technology (IT) projects mainly taking into account the investment
to be made by them and employment to be provided.
Composition of the High Level Committee :
(1)

Hon'ble Chief Minister

..

Chairman

(2)

Hon'ble Minister for Information Technology

..

Member

(3)

Chief Secretary to Government

..

Member

(4)

Development Commissioner

..

Member

(5)

Secretary to Government (Finance)

..

Member

(6)

Secretary to Government (Industries and Commerce)

..

Member

(7)

Secretary to Government (Information Technology)

..

Member

(8)

Director of Information Technology

..

Member-Secretary

4.2. A State Apex Committee headed by the Chief Secretary, Government of Puducherry is constituted
for overseeing and for providing policy directions.
Composition of the State Apex Committee:
(1)

Chief Secretary

..

Chairman

(2)

Development Commissioner-cum-Secretary (Finance)

..

Member

(3)

Secretary (Information Technology)

..

Member

(4)

All Secretaries to Government of Puducherry

..

Members

(5)

State Informatics Officer, NIC, Puducherry

..

Member

(6)

Dean, School of Engineering and Technology, Pondicherry University

..

Member

(7)

Professor and Head, Department of Computer Science,
Pondicherry Engineering College.

..

Member

(8)

Director of Information Technology

..

Member-Secretary

<!-- page 16 -->

1916
1916

LA GAZETTE DE L’ETAT

[ PART-I

5. VALIDITY OF THE POLICY
Since requirements of Information Technology (IT) industry keep on changing, there may be a need to review
the working of the policy at regular intervals to fine tune it to the changing requirements. Hence an assessment of
this policy will be made in consultation with stakeholders to make any revision in the policy.
6. CONCLUSION
The new Information Technology (IT) Policy is expected to make Puducherry a preferred Information
Technology (IT) Investment Destination. It envisages strong and specific initiatives to ensure timely and hassle
free guidance/clearances to new entrepreneurs. The policy has specific monitoring mechanism with provision for
regular assessment of its performance.
The new policy will be able to meet its objectives since this has been prepared on the basis of discussion
on various issues that emerged during multi-stage consultations with stakeholders.
The new Policy intends to leverage this unique strength and transform Puducherry into the most preferred
Information Technology (IT) Destination in the Country.
————

online publication at “http://styandptg.puducherry.gov.in”
Government Central Press
Directorate of Stationery and Printing
Puducherry - 605 009
