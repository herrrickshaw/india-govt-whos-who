---
doc_id: "34fef271a58ccdbc"
source_url: "https://lad.py.gov.in/sites/default/files/ladtradelicenseruless.pdf"
ministry: "Local Administration Department, Puducherry"
title: "View / Download"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "31df2199664c5a60"
---

<!-- page 1 -->

Regd. No. M . 8270

Registered with the Registrar
of Newspapers for India

~~

LJ tb)6D1 fill LO IT JH 60 ~ fJ H1 §i UJ
LA GAZETTE DE L'ETAT DE PONDICHERY
THE GAZETTE OF PONDICHERRY
PART -I
EXTRAORDINAIRE·
~fij)B>rT{l!b G>JufiJ!!J

Publiee par
Autorite

Q 6}} rorfl uJ(£1

@]/~6l):

OJ

m.. }

No.
No.

81

EXTRAORDINARY

e!!i· 38-75

Published by

Price : Rs. 38-75

Prix: Rs. 38-75

4 !bJ m 6lJ
Pondichery

b1 rum orf &<R_!Pmrn
Vendredi

1999 ~

c918.Cururi tE' 1 ~

1er

Octobre

1999 (9 Asvina 1921)

Pondicherry

Friday

1st

October

1999

PONDICHERRY MUNICIPALITY
Pondicherry, the 30th September 1999.

No. PM/32/CS/97-99.
N TIFICA TION

In exercise of the powers conferred under sub-section 1 of section 355 of the Pondicherry Municipalities
Act, 1973 and in supersession ofthe Notification dated 6-3-1998 published in the Official Gazette dated 24-4-1998, save
a

respects thin~s done or omitted to be done beforesuch supersess·on, the Special Office, Pondicherry Municipality

hereby directs (vide his proceedings bearing No. PM/32/CS/97, dated 28-9-1999) that, on and from the date ofpublication
ofthis notification, no place within the Municipal limits ofPondicherry Municipality shall b.:: used for any ofthe purposes
specified in the schedule appended to this notification without the licence of the Commissioner and except in accordance
with the conditions specified in the licence.

[369]

<!-- page 2 -->

LA ·GAZETTE DE L'ETAT

370
2.

[PART-I

This notification shall come· into operation after sixty days from the date of publication in the Official

Gazette.
3. The persons intending to start new trade I industry on every such place shall within thirty days of the
publication of such notification apply to the Commissioner for the licence for use of such a place for such purposes.
4. Every such licence shall expire at the end ofthe year unless for special reasons the Commissioner considers
that it should expire at an earlier date, when it shall expire at such earlier date as may be specified therein.
Definition :-'Year' means the financial year i.e. from lst April to 31st March.
5. Application for renewal of such licences shall be made not less than thirty days and not more than ninety
days before the end of every year and applications for licences for places to be newly opened shall be made not less than
thirty days and not more than ninety days before they are opened.
6. The .rate of fees for licences under section 355 and of fees for permissions under section 356 read with
section 456 (2) of the Pondicherry Municipalities Act, 1973 are given in column (3) of the said Sched:::.: ~wan they ·
will come into force on the date of coming into force of this notification.
7. The fees specified in the schedule will apply only to the applications made in time . In the case ofbelated
applications for licences and permissions under section 355 and 356 respectively of the said Act. the fee payable will be
charged at 125% of the prescribed rates. ·
8. The Owner or Occupier of every such place alread~ ha ·
licence fees at the time of renewal of licence for the forth oming fi

e

9. When a licence is required for use o
shall be paid only for one ofthe items dealt "th ·
shall be obtained for all items of trade deal. ·
10. Proportionate licence fee "
trades carried on without licence an de<

e

pay tlie rates of

ibed. but licence

In respect of

11. Applications shall be accompanie "ith there exp fo
licence or permission. The acceptance of the pre-pa.}ment of the fee or
the person making such payment to the licence or permission but onl)
licence or permission.
12.

All licences or permissions issued shall be "Not trans e

1aI WhOfiVilr Uiilil "pliUli for offlifiliin or dimgilrOUII trad .. .
constructs or establishes any factory, workshop or work-place without .~ ................~
section 449 read with Schedule XJII of the Pondicherry Municipalities

whoover
lllla•~e . . .ICUlted under

<!-- page 3 -->

LA GAZETIE DE L'ETAT

PART-[)

371

SCHEDULE
PURPOSES FOR WHICH PREMISES MAY NOT BE USED WITHOUT
A LICENCE/PERMISSION
Sl.

Description of trades/machinery

0.

(1)

(2)

Rate of
licence/
permission fee
(3)
Rs.

Advertising Agency
2

1,000

Agricultural produce likely to attract rates (selling
wholesale or retail or storing for wholesale or retail
trade or for purpose other than private or domestic
·use).

I.

Animals-keeping together ~enty or more sheep or
goats or ten or more pigs or ten or more heads of
cattle.

Keeping 20 or more goats or sheeps
per premises.
(ii) Keeping I 0 or more pigs per
premises.
(iii) Keeping cattle (ten or more)

lQ mt:y

3

lelated
lllill be

Agricultural produce other than
fruits( a) Wholesale trade
(b) Retail sale
(c) Storing in godown

(i)

I 50

50
150
50
50
50

~tes of

4

Appalams, vadavams- manufacturing, selling or
storing.

50

5

Arecanut- selling or storing or cutting for purpose
other than private or domestic use).

IOO

6

Articles of food made of flour, nuts, sugar or
jaggery-preparing for human consumption or
selling or storing.

7

Aerated water - soda and other beverages, syrup used
as cool drinks or mixed with water manufacturing/
storing.

(a) Manufacturing using manpower
(b) Manufacturing using machine
power.
(c) Production of sago, vermicille, etc.
(d) Selling or storing
1.

Manufacture(a) Employing manpower alone
(b) Employing mechanical power/
els:ctric or other.

200
400
100
I 00

50
250

J\.ihiilii " iitoring, paliikin8, pr~liililins, lil~aniiin8,
preparing or manufacturing by. any process whatever, dwnping or shifting per premises.

9

Automobiles

•

(i) Manufacturing
(ii) Sale(a) Car, van,. jeep, auto, motorcycle, tempo and other light
vehicles selling.
(b) Heavy vehicles-selling

3,000
2,000

3,000

<!-- page 4 -->

PART-I)

LA GAZETIE DE L'ETAT

371

SCHEDULE
PURPOSES FOR WHICH PREMISES MAY NOT BE USED WITHOUT
A LICENCE/PERMISSION
Sl.

Description of trades/machinery

0.

(1)

(2)

Rate of
licence/
permission fee
(3)
Rs.

Advertising Agency
2

1,000

Agricultural produce likely to attract rates (selling
wholesale or retail or storing for wholesale or retail
trade or for purpose other than private or domestic
·use).

I.

Animals-keeping together ~enty or more sheep or
goats or ten or more pigs or ten or more heads of
cattle.

(i)

lO illCJ

3
~elated

will be

ct of

such
title
the

er
der

Agricultural produce other than
fruits(a) Wholesale trade
(b) Retail sale
(c) Storing in godown

Keeping 20 or more goats or sheeps
per premises.
(ii) Keeping I 0 or more pigs per
premises.
(iii) Keeping cattle (ten or more)

150
50
150
50
50
50

4

Appalams, vadavams- manufacturing, selling or
storing.

50

5

Arecanut- selling or storing or cutting for purpose
other than private or domestic use).

100

6

Articles of food made of flour, nuts, sugar or
jaggery-prep.firing for human consumption or
selling or storing.

Aerated water - soda and other beverages, syrup used
as cool drinks or mixed with water manufacturing/
storing.

(a) Manufacturing using manpower
(b) Manufacturing using machine
power.
(c) Production of sago, vermicille, etc.
(d) Selling or storing
1.

Manufacture(a) Employing manpower alone
(b) Employing mechanical power/
el~ctric or other.

200
400
100
100

50
250

A&hili " 10toring~ paQkiin~, prtiliiiiin~, lilfilamin~,
preparing or manufacturing by. any process whatever, dumping or shifting per premises.

Automobiles

(i) Manufacturing
(ii) Sale(a) Car, van, jeep, auto, motorcycle, tempo and other light
vehicles selling.
(b) Heavy vehicles-selling

3,000
2,000

3,000

<!-- page 5 -->

-372

LA GAZETrE DE L'ETAT

[PART-I

(1)

(2)

(3)

Rs.

(iii) A sembling repairing, servicing,
welding. parepars storing and
selling. et . inclusive also of any
pan or paru hereof.

400

10

Ballpoint pen or refil manufacturing

100

11

(i)

Beauty parlour
Hair dressing, cutting saloons

500
50

12

Beedies (Beedi leaves) manufacturin_
selling.

100

13

Battery (for vehicles)

14

Bed/matress

(ii)

ring or selling

acturing and

300
100
200
300

15

Boat manufacturing and selling

500

16

·B ook stalls

250
200

17

Bones - buring or storing for sale

18

Building materials - bricks. tiles rag .
burning or storing for sale.

350

'les/ceramic

200
300
400
150
300
300
500

of tiles

1,000
400

amber bricks

s

10

20

') <;{)

r. .......... " + h o."P" ... ,.,;~o ria..._\; ...
.............. • ••o ...., . """~ - · ........ ..... - - - ..... -. & ::::

#" .. ..... .... ; ~

Camphor - boiling

packing,

100
50
50

21

Candles - manufacturing per premises

100

<!-- page 6 -->

ART-1

LA GAZETTE DE L'ET AT

373

(3)

. (2)

(3)
Rs.

Rs.

400

Carpets

(i) Coir
(ii) Other materials

200
500

Carbo n paper manufacturing

200

Canons manufacturing (made of boards and corru=ated boxes).

300 ­

500
50

Cement ancl alLied products storing and selling

500

100

Chalk cryons manufacturing

100

300
100

Chemical products of any type .including dye§,
leaching powder, liquid chlorine, sulphur, etc.
or sulphur products - manufacturing cleaning or
dea ing with in anyother way or storing for sale.

100

Manufactruing, cleaning, etc.,
(ii) Sale or storing

(i)

500
250

200

100

tllies powder - manufacture
300
Cigars (cigarettes) - manufacturing, storing or
el ing (excluding sale in pettyshops, bunks, stalls,

500

(i)

Manufacture or wholesale
trade or storage.
(ii) Retail

1,000
200

250

200

200

C ders selling, storing - per premises

500

· ical Laboratory
orbs of any discription including· matresses,

350

lo\\ s, bedding, etc. , printing dyeing, storing,

g.
200
300
400
150

(i)

Textiles manufactured by powerlooms (excluding handlooms).
(ii) Storing, selling
(iii) Laundries - ordinary
(iv) Dry cleaners - laundries

1,000
500
50

200
300

: · watch - manufacturing, storing or selling

300
300

500

ut - storing and selling whole sale or for

-·-I other than for private use).

1,000
400
:!50

200

100
1 00

100

m ManYfiilrturina. iiliSemblinahatgrina 2,000

er

and selling (including accessories).
(ii) Job work undertaking institute
300
(iii) Repairing and servicing
100
(iv) Stationery1,000
(a) Manufacturing
500
(b) Se1ling

100
50

50
100

(i) Wholesale
(ii) Retail sale
(iii) Coconut shell

- including Eau-de-cologne etc., ring and selling.

500

<!-- page 7 -->

374

LA GAZEITE DE L'ETAT

(1)

(2)

[PAR

R
38

Coal, charcoal and firewood- selling, storing other
than for private use.

2

39

Cotton - selling wholesale or retail or storing for
whole sale or retail trade or for conversion into
yarn.

2

40

Cycle including spare parts

41

Dairy farm or poultry or piggery cattle farm and
cattle feeds and animal feeds including bran manufacture or storage for sale.

42

Distilled water - manufacturing and sale

43

Engines or its spare parts - manufacturing, storing
and selling.

44

Electronic equipments/components .m anufacturing
or storing or selling.

45

Electrical goods - manufacturing or storing or
selling.

46

Eggs - storing and selling

47

Electro plating or gilting

48

Explosive or combustible materials - storing or
selling other than petroleum and it products in
~uantities exceeding those to which the operation
of this Act is limited by the provision of the
Petroleum Act, 1934 or the rules or notifications
issued thereunder.

(i) Manufacturing
(ii) Selling
(iii) Running of cycle store

5

1'

(a) Wood, bamboo, etc.
(b) Explosive materials
(c) Crackers and fire works(i) Manufacture, wholesale or
storage
(ii) Retail sale or storage
( ~' :vtatches- manufacture and/or
~tQn\~~.

e) Celluloid articles, sale, storage, etc.
(f) Sale of kerosene(i) Wholesale
(ii) Retail
(g) Petrol or diesel or high speed diesel
etc., in bunks.
Retail sale
(h) L.P.G. sales and storage

<!-- page 8 -->

:-I]

LA GAZETIE DE L'ETAT
(2)

375
(3)

Rs.
(i)

U)

Other products like paper, cardboard(i) Whole sale trade of storage
(ii) Retail trade
Other items not classified above

200

.:-ancy items - bangles , rings, chains (other than
re cious metal) - manufacturing, storing and
sell ing.
f

300

t food preparing and sales

150

F1bre including vegetable fibre, viz. coconut,
alm irah, jute fibres, etc.
ilm - storing or selling or otherwise dealing with

and all other sea food

Distribution of film
Photo studio with video studio
Photo studio without video studio
Photographic film, materials
including camera.
(e) Video/Audio film
(f) Cassette selling
(g) Cable television
(h) Cassette lending

1,000
1,000
500
500

(a) Storing or otherwise dealing with
(b) Oil-making, selling and storing
(c) Fishnet and allied materials
manufacturing selling and storing .

500
200

(a)
{b)
{c.)
(d)

(a) With A/C
(b) Without A/C

'1Cluc1mg mat weavmg.

(a) Manufacture
(b J :sate

500
250

500
.JUV

500

- plants, cylinders storing (other than LPG)
lling, selling, etc.
(a) Manufacturing, assembling, etc.
(b) Storing and selling
II food grains - selling wholesale or
oring for wholesale or retails trade.

300

500

Other than firewood, charcoal, coal, kerosene,
c., using for any industrial purpose.
~e- wood, bamboo, metal, cane or of any

400
400
500
200

500

- leather and other foam products
·ear shop

1,000
500
200

(a) Wholesale trade or storage
(b) Retail sale or storage
(c) Storage in godown

1,000
500
500
100
300

<!-- page 9 -->

•

376

LA GAZETIE DE L'ETAT

(PART- I

(l)

(2)

(3)

61

Glass- industry including mirror, glassware,
glassplates, etc.

(a) Manufacture
(b) Storing or selling

300
200

62

Gold refining - manufacturing moos gold - per
premises.

(a) Wholesale trade or storage
(b) Retail sale or storage

500
200

63

Gravel breaking up of blue granites, stone, etc. using
machine power.

64

Grocery and provision/general stores

(a) Supermarket/departmental store
(b) Wholesale
(c) Retail

65

Groundnut oil - seeds including gingily, castor etc.,
selling, wholesale or retail, storing for wholesale
or retails trade or for purpose other than private
or domestic use.

(a) Wholesale trade or storage
(b) Retail sale or storage
(c) Storage in godown

500
200
500

66

Gunny bags of any kind storing or otherwise
dealing with.

(a) Wholesale trade or storage
(b) Retail sale

200
100

67

.Hair washing or otherwise drying dealing with manufacture of articles from human hair.

100

68

Handicrafts, gift articles, etc., - manufacturing or
storing or selling.

200

69

Hardware iteni.s

(a) Storing and selling of hardwares
(b) Pipes, rods. bolt, nut and other
products.

70

Hides - skinning of animals horns - ta nin_ or
otherwise dealingwith dead animals.

a

71

Hiring of vessels, furnitures, shamiyana. electn al
goods, etc.

n

Home appliances - storing or selling

73

Hospital/Clinic/Dispensary/Nursing Home

Rs.

500

Hotels including eating houses, coffee/tea hou e
restaurant, snack bar, food stall, cool drinks c
ice parlour.

75

Ice-manufacturing, storing or selling and ice
manufactured out of ice or in the manufacture
which the ice is the main ingredient - storage.

500
300
1,000
500
500

C how-room
n-A C show-room
,.~~.·w == facilities

• illg tactllties
74

2,000
1,000
500

restaurant

MiiDI~ture employing machine power

Y..Aimifac"tiiJe employing manpower
V.1~~esale trade or storage

e or storage

1,000
500
3,000
L ,UUU

500
300
500
100
1,000
100

<!-- page 10 -->

•
[PART-I
(3)
Rs.
300
200
500
200
500

2,000
1,000
500
500
200
500

200
100

'-I]

LA GAZETIE DE L'ETAT

377

(2)

(3)
Rs.

mported cool drinks storage (from other parts of
i.he country).
njection moulded articles - manufacturing
Iron safes and steel furniture and allied products

500
300

1,000
500
3,000

300
200
250
100

ellery (including precious metals) manufacturing,
oring or selling.

(a) Manufacturing
(b) Sales in A/C show-room
(c) Sales in non-A/C show-room

500
2,000
1,000

ammation work

300

ad melting and storing

100

ather - storing and otherwise dealing with

_ me and lime shell - manufacture of chunnam

or including beer, alcohol, arrack, etc., brewing,
ufacturing; storing and selling.

500
300

1,000
100

300

(a) Manufacturing
(b) Wholesale trade or storage
(c) Storing in godown

2,UUU

500
100

(a) Manufacturing

Jaggery including palm productsanufacturing other wise than as cottage industry
• tappers or persons in enjoyment of the tree
a rri ed on in their own sites of places with no
achinery run by any power (electrical or mechanical)
-or the purpose.

1,000
500
500

500

Iron scrap, lumber materials

100

200

1,000

::ing house keeping a choultry, dharmasala or
- ouse not maintained by the Government or
al authority an unlicenced emigration depot
. place where causal visitors ·are received,
ed with sleeping accommodation without

(a) Leather garments, articles manufacturing (using mechanical
power).
(b) Wholesale trade or storage
(c) Storing in godown

500

(a) For one kiln
(b) For" every additional kiln
(c) Retail sale and storage

200
50
100

(a) Manufacturing and brewing
(b) Storing for wholesale trade per
premises.
(c) For everv additional premises
(d) Retail sale with bar
(e) Retail sale without bar
(f) Arrack shop
(g) Toddy shop
The daily rent (inclusive of all services
charges, complements, etc.,)(i) Not exceeding Rs. 200
(ii) Exceeding Rs. 300 not exceeding
Rs. 500.

500
300

7,000
5,000
2,000
1,000
750
500
200

200
500

<!-- page 11 -->

380

LA GAZETIE DE L'ETAT

[PART- I

(I)

(2)

(3)
Rs.
(a) Manufacturing
(b) Storing and selling

103

Paper, paperboard pulp, carton box etc.,

104

Pesticides and other similar products manufacturing,
storing and/or selling.

105

Pickles, jam, masala powder etc. , manufacturing,
storing and selling.

106

Pitch storing and selling

107

Polypropelean bags, plastic tanks, plastic articles
etc ., manufacturing and selling.

108

Prepared food like idly, vade, dosa and food
supplied in stalls on wheels.

200

109

Plywood items, Mica, Flush doors etc., storage
and selling.

500

.

l ,000
500
200

(a) Using machine power
(b) Using manpower

200
50
500

(a) Manufacturing
(b) Storing and selling

(a)
(b)
(c)
(d)
(e)

110 . Printing press

Without using electric motor power
Using electric motor power
Litho press
Computer offset printing
Screen printing

1,000
500

100
300
1,000
1,500
300

111

PVC pipes and fittings

Storing and selling

100

112

Personal Care

(a) Ayurvedic Cosmetics
(b) Cosmetics manufacturing and
selling.

100
500

113

Rags-Storing or otherwise dealing with

114

Real Estate

115

Rexine-storing, packing, printing or manufacturing
by any process whatsoever.

100

,

1 /'

T ) •. Ll_ ... _

, ;...,; .,.. ,..,. ,.a.....,R-t:art;no

llV

J.'-. U.Ul./ " 1.'

1,000

2,500

.,,.,_, .... ,.. u-..l ...... 1... ...... ...,

t.) l VL.J" U.J.,..I._U.

100

I.U.VVoJ

~+

........ ;..._,...

....,I.V'JI..&..J,. • b'

. ... ~ ... . .... 0, · - ·.. - - ­ .. -o,

cleaning and soiling.
117

Ruby-Storing, grinding and/or selling

118

Kalyanamandapams/Reception Hall and similar
others.

200
(i)

The rental value per day inclusive
of all charges not exceeding(a) Rs . 2,000 per day
(b) Exceeding Rs. 2,000
(c) Exceeding Rs. 5,000
(d) Exceeding Rs. 10,000

1,000
2,000
3,000
5,000

<!-- page 12 -->

(PART- I

LA GAZEITE DE L'ETAT .

381

(2)

(3)

(3)

Rs.

Rs.

1,000
500
200

200
50

500
1,000
500
200

500
100
300
1,000
1,500
300
100
100
500

:1

_;,

STD/ISD/Telephone and FAX booths

300

anitary ware-manufacturing, storing and selling

500

Sago-manufactuirng and distilling

500

Scent-Extracting-sale/storage

100

Shampoo/Liquid Blue-manufacturing, storing and
selling.

2,500
100

500

Slate-manufacturing

50

Snuff manufacturing

50
(a) Manufacturing using machine 1,000
power.
(b) Manufacturing using manpower alone 200
200

Soap making

Photocopying unit and amonia printing

1,000

Spectacles - manufacturing, storing and selling
pirit - manufacturing arrack or other sprit containillg alcohol (whether denatured or not by distillation).

500

Software development

500

Stationery articles - storing, selling etc.

300

ports articles - storing, selling

200

tone polishing - cutting, storing and sale

500
200

-~g puppet, toys, dolls manufacturing/selling

100

(a) Wholesale

2,000

- gar - manufacturing or refming

-ugar candy- manufacturing (otherwise than as a
:ottage industry by tappers or persons in engagement
0 the trees carried on in their own premises/sites).

.................-"' . . _& ...... 0 ,
_...,.,~~-..f:',..,..f-,.,.y...;n,....

nn.-; ,.. ..-1..1:-~
-~.~~v.~.&..a.....,

......... 0

..... _
vJ.

200

'H\1\
.JVV

lling or litoring,

200

- 'Dthetic yarn and similar other products - storing
,. elling.

500

::rup- manufacturing (otherwise than as a cottage
· dustry by tappers or persons in enjoyment of the
ees carried on in their own sites or places with
o machinery run by any power (electrical) for the

200

<!-- page 13 -->

382

LA GAZETIE DE L'ETAT

(PART-I

(1)

(2)

(3)
Rs.
(a) Manufacturin$
(b) Selling

500
100

140

Stabilizer and voltage meter

141

Trunk boxes, suitcase - manufacturing and selling

300

142

Tallow - melting

50

143

Tailoring shop

(a) Using electric sewing machines
employing more than 2 persons.
(b) Using ordinary machines

500
100

144

Tamarind (in selling whole sale)

200

145

Tar- storing

300

146

Taxi, van, car, etc, hiring

500

147

Telephone

148· Television set video - assembling, storing for sale
and servicing.

(i) Telephone selling
(ii) Cordless phone selling

1,000
2,000

(a) Sole Agency
(b) Qealership
(c) Servicing

2,000
1,000
300

(a)
(b)
(c)
(d)

NC show room
Non A/C show rooms
Ready made garments
Cutpiece sale

5,000
2,000
1,000
100

149

Textile shops .,. . storing, selling

150

Timber - storing, selling other than for privat~ use
or in a place situated among inhabited houses.

2,000

151

Turpentine - storing, cleaning, preparing by any
process whatsoever.

300

152

Typewriter

153

Umbrella - manufacturing, storing and selling

154

Vegetables or fruits or flowers- storing and selling

155

Valcanizing- keeping ~oulding; by gas or electricity.

156

Warehousing

(a) Running an institute
(b) Service centre
(c) Storing and selling

200
100
300
300

(a) Wholesale trade with A)C godown
(b) Wholesale trade with non-A/C room
(c) Retail trade

730
500
100
50

1,000

<!-- page 14 -->

[PART-I

LA GAZETTE DE L'ETAT

383

(3)

(2)

(3)

Rs.

Rs .

500
100

Weights and measures sale

3,000
1,000

(a) Electronic scales
{b) Platform scale
(c) Others

300

500
2,000

Wind power generators- assembling and selling

50

Wet grindering -job work

500

100

ool- washing or drying/manufacturing

100
200

300

•

(a) Manufacturing of products using
wooL
(b) Storage only

250
100

anufacturing anything from which offensive or
\\holesome smell arises.

200

e of betal leaf, nuts, cigarettes, cigar, snuff, etc.
bunks and petty shops.

50

If one and the same place is used for carrying on more than one of the above trades, for purpose of
e-.. :ing licence fee, trade for which the higher rate has been prescribed should be adopted.
(By order of the Special Officer)
K. ELUMALAI,

Commissioner.
