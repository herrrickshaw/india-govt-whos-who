---
doc_id: "9e99ffeabfd2bb71"
source_url: "https://dhte.py.gov.in/sites/default/files/308815-sanction-g.o..pdf"
ministry: "Higher and Technical Education Department, Puducherry"
title: "3088(15)-Sanction G.O"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c651b08ca1aa25c8"
---

<!-- page 1 -->

No.3088(15)/DHTE/T-3/PKFAS/2021-22
GOVERNMENT OF PUDUCHERRY
DIRECTORATE OF HIGHER & TECHNICAL EDUCATION
*****
Puducherry,
dt.
ORDER

02.02.2022

Sub: DH&TE - Award of Perunthalaivar Kamarajar Financial Assistance
(Renewal) for the year 2020-21 to the students of IV B.Tech
sponsored through CENTAC in private Engg. Colleges in the UT of
Puducherry - Expenditure sanction with advance drawal for
Rs. 2,14,25,000/-Accorded.
Ref: G.O.Rt.No.49
Puducherry.

dt. 15.12.2021 of the Chief. Sectt. (H&T Edn.),

******
In pursuance of the II Block Sanction issued by the Under Secretary to Govt.
(H&T Education) vide reference cited, sanction of the Director of Higher and Technical
Education is hereby accorded to incur an expenditure not exceeding Rs. 2,14,25,000/(Rupees Two Crores Fourteen Lakhs and Twenty Five Thousand only) towards the award
of Perunthalaivar Kamarajar Financial Assistance (2nd and 3rd Renewal for 2017-18 Batch
Students) for the year 2020-21 to 857 students of IV B.Tech, sponsored through CENTAC
in Private Engg. College in the U.T. of Puducherry as detailed in the Annexure to this Order.
2. The entire amount sanctioned vide para 1 above shall be drawn in advance in full,
subject to rendering of accounts to the Directorate of Accounts and Treasuries, Puducherry,
within one month from the date of drawal of advance as per Rules.
3. This Order is issued subject to the fulfilment of eligibility of students as per the
Rules and Regulations stipulated in G.O.Ms. No. 129 dt.17.10.2003, and subsequent
amendments issued vide G.O.Ms. No.97 dt.27.09.2004, G.O.Ms. No.67 dt.08.06.2005,
G.O.Ms No.84 dt. 08.07.2005, G.O.Ms No. 73 dt. 15.07.2006, G.O.Ms No.142 dt. 07.12.2006
G.O.Ms.No.83 dt. 3-8-09 of Education Secretariat. The disbursement of Financial Assistance
shall be drawn by the Directorate of Accounts and Treasuries, Puducherry and paid to the
Institutions concerned as per G.O.Ms.No.57 dt.01.10.2013.
4. The expenditure is debitable to the following Head of Account in the budget of the
current financial year.
Head of Account
“2202 – GENERAL Education – 03/107 (06) Financial Assistance
to the students undergoing professional courses – 03/107(06)(07)
All regions (34) – Scholarships & Stipends”

Amount Rs.
2,14,25,000/-

(Rupees Two Crores Fourteen Lakhs and Twenty Five Thousand only)
//BY ORDER//

(V.SOUMYA)
OFFICE ON SPECIAL DUTY
To
The Drawing and Disbursing Officer, DH&TE, Puducherry.
Copy to:1. Finance Department, Puducherry. 2. The Under Secretary to Govt. (Edn.), Puducherry.
3. The Director of Accounts & Treasuries, Puducherry, 4. The Senior Dy. Accountant
General ( Civil Audit ), Puducherry, 5. The Head of Institutions concerned, 6. The C.R.B.,
Puducherry, 7. Bill section/Cashier, 8. Order File/spare.
