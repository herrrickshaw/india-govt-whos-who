---
doc_id: "a2ecd1faec6ab985"
source_url: "https://dit.py.gov.in/sites/default/files/stationery-purchase.pdf"
ministry: "Information Technology Department, Puducherry"
title: "Circular regarding purchase of stationery items, issued by Directorate of Stationery and Printing, Puducherry, dated 23-12-2003."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "42a35a42c766bb03"
---

<!-- page 1 -->

GOVERNMENT OF PONDJCHERRY
DIRECTORATE OF STATIONERY AND PRINTING

No23671DSPIP21Pur/2003-200~.:7 6>::,;1

Pondtcherry. the

2 3 DEC zooa

CIRCUlAR
Sub: OSP - Pur- Purchase of Non-Paper Stationery
Items/ Carbon Papers etc.,

The Dtrectorate or Stationery ana Pnntino. whtcn was entrusted wun issue ol
Paper and Non-Paper Stationary Items to all DireCI lndenung Offices, used to procure
stationery items requued for ali the offices, based on th<> demand proje,;ted by !hem 1n
the annual indent and i:s~ue peuodicolly.

In case any of the mdented item wos not

cwailab1e in tho :stortt3, o No Objt::Ction Certiftedte for procuring the item locally, after
~totti ng

the l'easonablenes6 or lates certified, by the Dltectorate of Stationery and

Pnmtng, woula be 1ssue<1.
~

This procedure has been reviewed by the Purchase Committee in its meeting

held on l i.I0.2003.

It has been decided by tne Committee not to procure the non

paper statronerv Items lor supply to otner Depa!lments!Oftlces or tne AC1mrmsuat1on by
rne Directorate of Stationery d. Pnntmg
organ~t;ations can procure

Instead. 1t has been dectded that the user

lne Non paper stationery items requ1red by them under the

cclegated powers. ConsequenUy the ISSue of stationery by the Directorate of Stottortery

and Pnnting Wlll be restricted to the following ltems:(a) All prmted rorms and reg1sters.
(b) All Pre-printe<l computer forms.

(c) Duplicating paper

(d) Writing paper
(e) Photocopier paper A4 size.
(I) Stencil paper

(g) Typewr~lng Whllo 1>aper.
3

All pr1nttng work~ vtill be unoortar<on by th1;:, Oepertment.

e

All other paper and non paper atuttonery itoma requ~red by the departments may

oe procured tJ'y the concarn~d offices, after rollowlng l<ud down procedures. without
mrer 11ng to Directo1ate t>f Stationery and Ponttng for No Objection Cemficate 1 Rate
kaasonable Certlllcate etc.

/-v-1:f;Ji;Jo >
{0. RAGESH CHANDRA)
DIRECTOR

Drstribution:­

1. All Heads of Departments/Oilices
2. All Direct Indenting Offices.
3

The Director or Accounts and Treasuries, Pondlcherry.

4

The Oy Director of Accounts and Treasuries. Karaikai/Mahe!Yanam.
