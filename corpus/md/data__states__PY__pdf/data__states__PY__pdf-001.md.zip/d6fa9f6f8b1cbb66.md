---
doc_id: "d6fa9f6f8b1cbb66"
source_url: "https://dhte.py.gov.in/sites/default/files/g.o-m.s.no.11-dt-31.03.20.pdf"
ministry: "Higher and Technical Education Department, Puducherry"
title: "G.O M.s.No.11 dated 31.03.20"
date: ""
pages: 2
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "1ca8b7f570316ac2"
---

<!-- page 1 -->

GOVERNMENT OF PUDUCHERRY
Abstract
Chief Secretariat (Higher and Technical Education) - Award of Financial Assistance under
the “Perunthalaivar Kamarajar Financial Assistance Scheme (PKFAS)” to the students
pursuing M.B.B.S., B.Sc.,(Nursing) and B.Tech. Courses in various Unaided Private
Professional Colleges of the Union territory of Puducherry — Continuance for the Academic
year 2019-20 — Order — Issued.

CHIEF SECRETARIAT(HIGHER AND TECHNICAL EDUCATION)
G.O.Ms.No.11 Puducherry, Dt.: 31.03.2020.
"Read: | 1. 1 G.O.Ms.No.57 dated 01.10.2013 of the Chief Secretariat |

_(Education), Puducherry,
/ ~~ 72.7G.0.Ms.No.107° dated 01.09.2014 of the Chief Secretariat |
(Education), Puducherry. ட்ட ட
~~ 13.0.0.09040.021 dated 20.03.2015 of the Chief Secretariat
i __ (Education), Puducherry,
~4.G.O.Ms.No.61 dated 27.10.2015 of the Chief Secretariat
டட. (Education), Puducherry. |
“5, G.O.Ms.No.30 dated 30.11.2016 of the Chief Secretariat
(Higher & Technical Education), Puducherry. :
6. G.O.Ms.No.36 dated 09.10.2018 of the Chief Secretariat
| ட. Higher & Technical Education), Puducherry.
7. G.O.Ms.No.31 கேம்‌ 01.10.2019 of the Chief Secretariat
்‌ | (Higher & Technical Education), Puducherry. |
8. Letter No.6534/DHTE/Tech/T3/2019 dated 05.11.2019 and |
LD.Note No.1366/DHTE/Tech/T3/2019-20 dated 28.02.2020 !
from the Director of Higher and Technical Education,
ட {Puducherry த ப ப அ பபப
ORDER:
The following Notification shall be published in the Extra-ordinary Official Gazette
of Puducherry, namely:
NOTIFICATION
Approval of the Lieutenant-Governor is conveyed for the continuance of the
provisions of the Notification first read above for providing financial assistance under the
“Perunthalaivar Kamarajar Financial Assistance Scheme(PKFAS)” to the students admitted
through Centralised Admission Committee (CENTAC) and pursuing M.B.B.S.,
B.Sc.,€Nursing) and B.Tech., Courses in various Unaided Private Professional Colleges of the
Union territory of Puducherry for the Academic year 2019-20, without any modification.

<!-- page 2 -->

stort
2: The total number of students eligible for availing the financial assistance under the
said Scheme shall stand amended in accordance with the total number of students admitted in
M.B.B.S., B.Sc.,(Nursing) and B.Tech., Courses through Centralised Admission Committee
(CENTAC) during the Academic year 2019-20.
2 The rates of financial assistance shall be the same as notified in the GOs. read above a
for M.B.B.S., B.Sc.,(Nursing) and B.Tech., Courses offered in various Unaided Private
Professional Colleges of the Union territory of Puducherry.
4. This issues with the concurrence of Finance Department vide their I.D.Note
No.2492/FC/FD/F4/A4/19-20 dated 30.03.2020.
// BY ORDER THE LIEUTENANT-GOVERNOR //
ALT
7 (M.V. HIRAN)
UNDER SECRETARY TO GOVERNMENT
(HIGHER & TECHNICAL EDUCATION)
To
The Director of Stationery and Printing,
Puducherry - For publication in the Extraordinary Gazette of Puducherry
and to forward 25 copies to this Secretariat for record.
Copy to:
1. The Chief Secretary to Government Puducherry.
2. The Commissioner-cum-Secretaries to Government, Puducherry.
3. All Secretaries / Special Secretaries to Government, Puducherry.
4. The Private Secretary to Hon’ble Lieutenant-Governor, Puducherry
5. The Collector, Puducherry / Karaikal.
6. The Chairman, Admission Committee, DHTE, PIPMATE Complex, Puducherry.
7. The Chairman, Fee Committee, DHTE, PIPMATE Complex, Puducherry.
8. All Secretariat Departments / Heads of Departments, Puducherry.
9. The Director of Higher and Technical Education, Puducherry.
10. The Director of Health and Family Welfare Services, Puducherry.
11. The Director of School Education, Puducherry.
12. The Regional Administrator, Mahe / Yanam
13. The Director of Planning & Research Department, Puducherry.
14. The Co-ordinator(Admission), CENTAC, PEC Campus, Puducherry.
15. The Convenor, CENTAC, PEC Campus, Puducherry. ்‌
16. The Director of Accounts & Treasuries, Puducherry.
17. The Deputy Director of Accounts & Treasuries, Karaikal / Mahe / Yanam.
18. The Deputy Accountant General(Civil Audit), DAT Campus, Puducherry.
19. The Central Records Branch, Puducherry.
20. The G.O. File.
[File No.000534/CS(H&T Edn/E.3/2019]
