---
doc_id: "4fde3ee37f60bb0f"
source_url: "https://schooledn.py.gov.in/notification/GO-27.pdf"
ministry: "District Institute of Education and Training (DIET), Puducherry"
title: "G.O.RT.No.27 - Release of Grant-in-Aid for the year 2017-18 to 35 Govt. Aided Private Schools in Puducherry, Karaikal and Yanam region - Expenditure Sanction for the month of March 2017"
date: ""
pages: 4
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "0da3f3beabb6ce87"
---

<!-- page 1 -->

அற GOVERNMENT OF PUDUCHERRY த
ட ABSTRACT ச்‌ தறி
Directorate of School Education (Secretariat Wing) - Release of Grant-in-Aid for the
year 2017-18 to 35 Government Aided Private Schools in Puducherry, Karaikal and
Yanam region — Expenditure sanction for the month of March 2017 — Orders - Issued.
SECRETARIAT WING த
G.0. Rt. No. 27 Puducherry, dt.2 9 JUN 7017
READ: |.D.No.03-03/DSE/GIAS/U.III/2017-18 dt. 11.04.2017 from
Director of School Education, Puducherry.
ORDER:
Sanction of the Lieutenant Governor, is hereby accorded to incur an expenditure
not exceeding Rs.3,55,33,000/- (Rupees Three crores fifty five lakhs and thirty
three thousand only) towards the release of Grant-in-Aid to 35 Government Aided
Private Schools in Puducherry, Karaikal and Yanam regions for payment of monthly s
salary and wages to the employees and pension to the retired employees of these
schools for the month of March 2017. \
2: The release of grant to the managements of 35 Government Aided Private
Schools will be 100% in such a way that 95% of the total expenditure on salary shall be
borne by Government and 5% shall be borne by the management as per Rule 35 (2)
(4) of Pondicherry School Education Rules, 1996 which will be remitted to the
respective Drawing and Disbursing Officer who will inturn remit the amount in minus
debit of the relevant Head of Account in which salary is drawn. The payment of salary
to the staff is subject to the furnishing of disbursement certificates to the Inspecting
Officers by the Managements for the grant drawn towards the payment of staff salary in
respect of the previous month along with the bills for the month concerned. Payment of
salary shall be effected through Electronic Clearing System (ECS). Similarly, 5% of the
pension payable to the new pensioners from the financial year 2013-14 shall be borne |
by the management which will bé remitted to the respective Drawing and Disbursing
Officer who will inturn remit the amount to the relevant Head of Account in which
pension is drawn.
3: Necessary action shall be taken by the Inspecting Officers / Drawing Officers
, concerned to draw and disburse the amount to the Management of 35 Government
Aided private Schools. Certified that the Grant-in-Aid is sanctioned to the Government ்‌
Aided Private Schools which fulfill the conditions/provisions of the said rules. This
advance payment will be adjusted during the year 2017-18 when the final Grant-in-
Aid for the year 2017-18 in respect of the 35 Government Aided Private Schools will be
finalized and Grant-in-Aid at the rate of 95% is released. ்‌
2h

<!-- page 2 -->

ர்‌ Qe
ட்கீ ட
/
él 4. The expenditure is debitable to the Head of Account as detailed in the
Annexure — II to this G.O.
5: This issues with the concurrence of the Finance Department, Puducherry vide
their |.D. No.1219/F4/A4 1 FC /2017 dt. 23.06.17
1} BY ORDER /
(V. JAISANKAR) :
UNDER SECRETARY TO GOVERNMENT(SCHOOL EDN.)
To
The Director of School Education,
Puducherry.
Copy to:
4. The Finance Department, Puducherry.
2. The Director of Accounts & Treasuries, Puducherry.
3. The Director, Planning and Research Department, Puducherry
4. The Deputy Director of Accounts & Treasuries, Karaikal.
5. The Deputy Director of Accounts & Treasuries, Yanam
6. The Principal Accountant General (Civil Audit), Tamilnadu & Puducherry,
Chennai-35/Puducherry.

7. The Jt. Director of Education (SE), Dte. of School Education, Puducherry — He
will verify the accounts and countersign the bills of Immaculate Heart of Mary's
Govt. High School (Mission St and Ariyankuppam), Puducherry, Fatima Govt.
Aided Boys’ High School, Wiseman Govt. Aided High School, St. Mathias Govt.
Aided High School, Uppalam, Shri Hindocha Charitable Trust Govt. Aided High க
School, Ariyur, PONCOS Govt. Aided High School, Lingareddiapalayam and
Prof. Annoussamy Govt. Aided High School, Bahour, Puducherry.

8. The Dy. Director of Education (Women), Puducherry - He will follow the
instructions issued by the Director of Schoo! Education in sanctioning monthly
grant to the aided schools, falling within his jurisdiction.

9. The Chief Educational Officer, Puducherry/Karaikal ்‌

10166 Delegate to Director of School Education, Yanam — He will draw the bills
presented by the Management of Sarada Vidya Niketan Govt. Aided English
High School, Yanam.

11. The Dy. Inspector of Schools, Zone MIW/III/IV and V, Puducherry / Karaikal

42.The Drawing and Disbursing Officer, Dte. of School Education, Puducherry - He ன்‌
will draw the bills presented by the management of Immaculate Heart of Mary's
Govt. High School (Mission St and Ariyankuppam), Puducherry, Fatima Govt.
Aided Boys’ High School, Wiseman Govt. Aided High School, St. Mathias Govt.
Aided High School, Uppalam, Shri Hindocha Charitable Trust Govt. Aided High
School, Ariyur, PONCOS Govt. Aided High School, Lingareddiapalayam and
Prof. Annoussamy Govt. Aided High School, Bahour, Puducherry.

<!-- page 3 -->

அணு ண்ண அணை ணைன வாவ வ அனாதைக்‌ கள்‌ 20 Mesa ட்‌ ன்‌
ig
Pr
jf = ANNEXURE-I
AMOUNT FOR
SL. NO. NAME OF THE SCHOOL MARCH 2017
in Rs.)
ர்‌ த எ | 446000)
| [2202:0211001)01) PDY (31) Grants -in-aid NP___ | 4438000]
i நண
PUDUCHERRY 981000
ண்ட. அப்பளை றனா
ப்பி PUDUCHERRY 1149000
2 ESR பதக நண
VILLIANUR, PUDUCHERRY 2474000
| 6 __|ST. ANN'S GOVT. AIDED HIGH SCHOOL, PUDUCHERRY | 546000]
கணா al
PUDUCHERRY. 398000
[8 __|ST.ANTONY'S GOVT. AIDED HIGHSCHOOL, PUDUCHERRY | 899000]
ae eres Rene a
| | PUDUCHERRY 1142000)
கண்ட age வை கணை
NELLITHOPE, PUDUCHERRY. 678000
a பப்ப |
PUDUCHERRY. 1023000
கண ப வை கா
REDDIARPALAYAM, PUDUCHERRY 559000)
P= ee ree errors | a
PUDUCHERRY 371000
| 14 [FATIMA GOVT. AIDED BOYS' HIGH SCHOOL, PUDUCHERRY | 994000)
நன கிவள கண ட்‌
PUDUCHERRY. 2063000
்‌ ARIYANKUPPAM, PUDUCHERRY Zz 1867000
a வவ்வவைவைணைகனை "
PUDUCHERRY 802000] “ |
கர ட eT
SCHOOL, ARIYUR, PUDUCHERRY 1343000
[a இதத்‌ SbrereooctROROPT |
PUDUCHERRY. 1123000
பட. 2202021100) PDY(36)GIA-NP_ | 24954000)
நன கவ்வை னை a
KARAIKAL 862000
[a இதல்‌ AR OORT | பனு
KARAIKAL. 489000
[= fe202-02r140(07)(02) KKL (G6) GIA-NP- SS 1 5928000
|_____|2202-02/110(04)(04) YANAM(36)GIA-NP_ 2 |: 1057000]
கர lia
SELIAMEDU, PUDUCHERRY 231000
| __30._|DAKSHIN BHARAT HINDI PRACHARA SABHA, PUDUCHERRY |
a மான"
PUDUCHERRY 302000|—
ட. /2202021100201) PDY (36)GIA-NP_ | 4834000
மர வண்கை வை கண எ! ப
KARAIKAL 574000.
ட [22020211002002)66(39)6:11 எச) 625000)
பப ணை 88533000]
(Rupees Three crores ரே ்‌ lakhs and thirty three thousand only)
UNDER SECRETARY TO GOVT. (SCHOOL EDUCATION)

<!-- page 4 -->

மதி ர,
ர்‌ . “
7
/ தட
ட ANNEXURE-II
AMOUNT FOR
SL. NO. HEAD OF ACCOUNT MARCH 2017
in Rs.

2202 - General Education - 02 - Secondary Education - 02/110 -

1 Assistance to Non Govt. High Schools - 02/110(01) Assistance to]
Non Govt. High Schools - 02/110(01)(01) Puducherry Region (31)
Grants-in-aid (Non Plan) 4438000
2202 - General Education - 02 - Secondary Education - 02/110 -

2 Assistance to Non Govt. High Schools - 02/110(01) Assistance to
Non Govt. High Schools - 02/110(01)(01) Puducherry Region (36)
Grant-in-Aid Salaries (Non Plan) = 21954000
2202 - General Education - 02 - Secondary Education - 02/110 - ்‌

3 Assistance to Non Govt. High Schools - 02/110(01) Assistance to
Non Govt. High Schools - 02/110(01)(02) Karaikal Region (36)
Grant-in-Aid Salaries (Non Plan) 5928000
2202 - General Education - 02 - Secondary Education - 02/110 -
Assistance to Non Govt. High Schools - 02/110(01) Assistance to]
Non Govt. High Schools - 02/110(01)(04) Yanam Region (36)
Grant-in-Aid Salaries (Non Plan) 4057000)
2202 - General Education - 02 - Secondary Education - 02/110 -
Assistance to Non Govt. High Schools - 02/110(02) Assistance to
Non Govt. Secondary Schools - 02/110(02)(01) Puducherry!
Region (36) Grant-in-Aid Salaries (Non Plan) —_—
12202 - General Education - 02 - Secondary Education - 02/110 -
Assistance to Non Govt. High Schools - 02/110(02) Assistance to ்‌
Non Govt. Secondary Schools - 02/110(02)(02) Karaikal Region
(36) Grant-in-Aid Salaries (Non Plan) 625000
(Rupees Three crores fifty five Of thirty three thousand only)

UNDER SECRETARY TO GOVT. (SCHOOL EDUCATION)
