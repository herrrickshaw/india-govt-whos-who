---
doc_id: "b9f4f29bbedf3dad"
source_url: "https://www.srkgacyanam.edu.in/userfiles/Circular-Offering-of-SWAYAM-Courses-for-the-academic-year-2023-24.pdf"
ministry: "Dr. Sarvepalli Radhakrishnan Government Arts College, Yanam, Puducherry"
title: "Click Here"
date: ""
pages: 4
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "e77bd8a45d97c1ef"
---

<!-- page 1 -->

gB8¥ Uy, (புதுவைப்‌ பல்கலைக்கழகம்‌ (மத்திய பல்கலைக்கழகம்‌) எர்சர0 Rafrerea (dia ளரு)
oy Xo, uns ரத்னா டாக்டர்‌ பி.ஆர்‌. அம்பேத்கர்‌ நிர்சாக கட்டிடம்‌, una ம St Alo. சாக்கை waraPia அர,
தி ம்‌ ஆர்‌.கி,தகர்‌, காலாப்பட்டு, புதுச்சேரி - 605014 on ala0R, arene, GER! - 605014
‘ து. Pondicherry University (A Central University)
ad Bharat Ratna Dr. B.R. Ambedkar Administrative Building,

“eee R.V. Nagar, Kalapet, Puducherry - 605014
Eee
துணை பதிவாளர்‌ (கல்வி) & 191 - 413 - 2654538
ஊ ஈ௭ணச ௭) = dracademic@pondiuni.ac.in
Depiity Registrar (Academic) ® www.pondiuni.edu.in
TE ய யை க சை சைகை சை சை சை ையையைைைைைைைைைை ளை வையை வை ம
Ref No: PU/AS/Aca10/SWAYAM/2023-24/ 44S Date: 14.02.2024

CIRCULAR No.42
Sub: Offering of sWyam Courses for the academic year 2023-24 - Reg.
Ref: i. This Office E-Circular No.70 (Vide Ref.No. PU/AS/Aca10/ 2023-24/708
dated 29-12-2023
ii. E-Mail dated 30-01-2024 received from the Secretary, University Grants
Commission, Ministry of Education, Govt. of India, New Delhi.

With reference to the subject cited above, I am directed to inform you that the
list of SWAYAM courses (attached) proposed in your department may kindly be offered
during this academic year 2023-24.

Furthermore, you may advice the Faculty Members of your Department/Center
to come forward to offer SWAYAM courses and encourage the students to take the SWAYAM
courses for credit transfer as per norms.

Encl: As above DEPUTY வம்‌ (ACADEMIC)

To

All the Deans/HODs/Centre Heads/Principal, Constituent Colleges

Pondicherry University, Puducherry

Copy to:

1) The Assistant Registrar, Vice-Chancellor’s Secretariat, Pondicherry University

2) The Office of the Director, SEI & RR, Pondicherry University

3) The Office of Director, Culture and Cultural Relations, Pondicherry University

4) The Office of the Registrar, Pondicherry University

5) The Systems Manager & Head(i/c), Computer Centre -- To host in the University weksite
Pondicherry University i

<!-- page 2 -->

NN ்ட  ணை :- "1-௮ அன
[4 [BUSINESS PLANNING AND PROJECT MANAGEMENT Jocommoa_| 3]
[6 |iwTeRwarionat eusiNess___ ocommos [3
உஸ்ஸா டட ஜய |]
[உ 12000 AND HAZARDOUS WASTE MANAGEMENT 108008 13]
[26 |pHoTououURNAUSM ணை "11 - பன கை
[27 Jacabemic waiming ணை : "11 5 பன கண)
[28 CREATIVE COMMUNICATION, EXTENSION AND COMMUNTTY RESOU|OEMMCIS | 3]
[உ [principles or sociology வல al
ண வம ப்பை (11 1 2 ணை
டட [SCIENTIFIC COMPUTING பஸ்பம்‌... வள | 2
[48 [AN INTRODUCTION TO ப பபப அணை (11 அ ணை
[ 49 APPLIED LINEAR ALGEBRA FOR SINGLE PROCESSING, DATA வமர ||

<!-- page 3 -->

[58 [PYTHON FORDaTAScIENCE ணை | டட கை
[9 [PROGRAMMING DATA STRUCTURES AND ALGORITHMS USING PYTHOsTATOa 13]
[ல |INTRODUCTIONTO மமம்‌... | | 3]
ண பட்ட னை (1 ன கை |
[௨ _|GREAT EXPERIMENTS IN PSYHCHOLOGY 00 |]
[_68_[INTRODUCTIONTO FLMsTUDIES_———SSSS~s nS | 2
டட [CONSUMER PSYCHOLOGY வ | 2
[ஐ [COUNSELLING PsycHOLoGy 002 12]
[உ [SOCIETY AND MEDIA 000 | 2
[86 |rumstupes ணை (11. அன கை
[87 [INTRODUCTION TO THE PSYCHOLOGY OF LANGUAGE oPsvos 12
[ஐ PHILOSPHICAL FOUNDATIONS OF SOCIALRESEARCH _____[oaPsvos 12]
[90 EARLY CHILDHOOD CARE AND லகர Joarsvor__| ___2|
[96 _|RESOURCES AND ENVIRONMENT opatio | 3
[98 [TOURISM PLANNING & SUSTAINABLE DEVELOPMENT omsaTo2_| 3]
[ஐ [COMMUNICATION TECHNOLOGIES IN EDUCATION omaaTos_| 3]

<!-- page 4 -->

[106 FToURISM DEVELOPMENT PRODUCTS, OPERATIONS AND CASE STUD|OBaTI1__| ____3|
[nize roo cuemstey ணை (1: ன கை
ணன ணை (ட ன ண
[டர [யமாமா 60 | 3
டட ராவார்‌... சகம்‌ 13
