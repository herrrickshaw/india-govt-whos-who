---
doc_id: "c4b0bae1cbb72b3d"
source_url: "https://dit.py.gov.in/sites/default/files/pswan27062025guidelines.pdf"
ministry: "Information Technology Department, Puducherry"
title: "Guidelines for LAN / PSWAN, ID Note dt. 27-06-2025"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "df3c3885511f4f49"
---

<!-- page 1 -->

P-13031/1/2025-O/o Director IT/PDY

I/16424/2025

GOVERNMENT OF PUDUCHERRY
DIRECTORATE OF INFORMATION TECHNOLOGY
No.P-13031/1/2025-O/o Director IT/PDY
I.D. NOTE
Sub: DIT – PSWAN Project –Ensuring of UPS power supply to the
network devices provided for PSWAN connectivity – Reg.
Ref: I.D. Note No. P-13031/75/2023-0/0 Director IT/PDY Dt.08.04.2024
from this Directorate
*****
Kind attention is invited to the I.D. Note cited under reference above regarding
providing PSWAN connectivity to all the Departments / Offices across the UT of
Puducherry wherein this Directorate provided general guidelines on utilization of PSWAN
infrastructure to cater the connectivity requirements.
2.

As per the guidelines referred, this Directorate clearly indicated that for the

network devices provided & installed by Bharat Sanchar Nigam Ltd., the bandwidth
service provider, must be provided powered through a suitable Uninterrupted Power
Supply System only as the said devices are sensitive one and if raw power supply
provided to the said devices will lead to failure of said devices, resulting in disruption of
PSWAN connectivity until the issue is resolved or the faulty devices are replaced.
3.

In these juncture, it is brought to the notice to this Directorate that some of the

Departments / Offices were still not provided reliable power supply (i.e.) power supply
through uninterrupted power systems causing the network devices failure & BSNL had
inevitably replaced the faulty devices.
4.

It is important to note that that the PSWAN infrastructure is covered with

appropriate Service Level Agreement (SLA) with BSNL to ensure effective functioning and
as per the said SLA, the Departments / Offices provided with PSWAN connectivity has to
ensure provision of UPS to the network devices. BSNL will not be responsible to replace
the devices which became faulty due to the raw power supply.
…2/-

<!-- page 2 -->

P-13031/1/2025-O/o Director IT/PDY

I/16424/2025

:: 2 ::
5.

In order to ensure effective utilization of PSWAN infrastructure, all the

Departments / Offices provided with PSWAN connectivity are hereby once again
requested to confirm the network devices are provided with UPS power supply. Further,
in case if BSNL identifies the cause of failure of network devices due to raw power supply,
BSNL will not replace the network devices until a UPS is provided and specific
approval is obtained from this Directorate. Further, the said Departments / Offices
should approach this Directorate only after provisioning UPS power supply to the
network devices so as to enable this Directorate to issue necessary orders for
replacement of faulty devices.
6.

If no action is taken to provide the UPS power supply to the PSWAN

network devices within 30 days from the date of device failure is identified, the
PSWAN

connectivity

at

the

respective

location

will

be

discontinued

/

are

hereby

/

disconnected by this Directorate.
7.

Further,

the

Heads

of

Departments

Offices

requested

to

communicate copy of this I.D. Note to all their branch offices across the UT of Puducherry
to sensitize about the need to provide UPS power supply to the network devices provided
for PSWAN at respective offices. In this connection, the list of branch offices (both Govt.
Departments/Offices as well as the Undertakings) for each Department which are
provided with PSWAN connectivity is enclosed herewith.
// BY ORDER OF THE SECRETARY (IT) //

(SHIVRAJ MEENA)
DIRECTOR (IT)
To
The Departments / Offices concerned.
Copy submitted to
1. The Chief Secretary, Chief Secretariat, Puducherry
Copy to
2. All Secretaries to Government, Government of Puducherry.
3. The District Collector, O/o. Collectorate, Karaikal.
4. The Regional Administrator, Mahe / Yanam
