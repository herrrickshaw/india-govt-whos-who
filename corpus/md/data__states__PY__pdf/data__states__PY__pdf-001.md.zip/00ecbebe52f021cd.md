---
doc_id: "00ecbebe52f021cd"
source_url: "https://industry.py.gov.in/sites/default/files/recrutiment-rules-post-technical-officer_1.pdf"
ministry: "Industries and Commerce Department, Puducherry"
title: "recrutiment-rules-post-technical-officer.pdf"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fa7d9bc00e01f1a9"
---

<!-- page 1 -->

RECRUITMENT RULES

Supplement to the Gazette No. 15
of the 12th April 2016

Published by Authority of Government of Puducherry

Price : ` 4.00

<!-- page 2 -->

3
GOVERNMENT OF PUDUCHERRY
DIRECTORATE OF INDUSTRIES AND COMMERCE
(SECRETARIAT WING)

(G.O. Ms. No. 6/DI&C/S2/SW/2016, dated 30th March 2016)
NOTIFICATION
In exercise of the powers conferred by the proviso to Article 309 of the Constitution of India, read with the
Notification No. 5/4/65-GP, dated 11th January 1965 of the Government of India, Ministry of Home Affairs, New Delhi,
and in supersession of the Government of Puducherry, Industries Department, Group (C) Technical Posts Recruitment
Rules, 1978 published vide Notification in G.O. (Ms.) No. 177, dated 12th December, 1978 of the erstwhile Development
Department in Supplement to the Gazette No. 13, dated 27th March, 1979 save as respects things done or omitted
to be done before such supersession, the Lieutenant-Governor, Puducherry, hereby makes the following rules
regulating the method of recruitment to the Group 'B' post of Technical Officer in the Directorate of Industries and
Commerce, Puducherry, namely:—
1. Short title and commencement.— (1) These rules may be called the Government of Puducherry,
Directorate of Industries and Commerce, Group 'B' Non-Gazetted - Non-Ministerial post of Technical Officer
Recruitment Rules, 2015.
(2) Application.— They shall come into force on and from the date of their publication in the Official Gazette.
2. Number of post, their classification and Pay Band, and Grade Pay/Pay Scale.— The number of the said
post, its classification and Pay Band, and Grade Pay/Pay Scale attached thereto, shall be as specified in columns (2)
to (4) of the said Schedule.
3. Method of recruitment, age-limit and other qualifications.— The method o f recruitment to the
said posts, age-limit, qualifications and other matters relating thereto, shall be as specified in columns (5) to
(13) of the said Schedule.
4. Disqualifications.— No person,—
(a) who has entered into or contracted a marriage with a person having a spouse living; or
(b) who, having a spouse living, has entered into or contracted a marriage with any person,
shall be eligible for appointment to the said post:
Provided that the Lieutenant-Governor, may, if satisfied that such marriage is permissible under the personal
law applicable to such person and the other party to the marriage and that there are other grounds for so doing,
exempt any person from the operation of this rule.
5. Power to relax.— Where the Lieutenant-Governor is of the opinion that it is necessary or expedient so
to do, he may, by order and for reasons to be recorded in writing relax any of the provisions of these rules with
respect to any class or category of persons.
6. Savings.— Nothing in these rules shall affect the reservations, relaxations in upper age-limit and other
concessions required to be provided for the Scheduled Castes, Scheduled Tribes and other special categories of
persons in accordance with the orders issued by the Government from time to time in his regard.

<!-- page 3 -->

4
SCHEDULE
RECRUITMENT RULES FOR THE POST OF TECHNICAL OFFICER
1. Name of the post

:

Technical Officer

2. Number of posts

:

24* (Twenty four) *[2016] subject to variation dependent
on work-load.

3. Classification

:

Gener al Civil Ser vices–Gr o up 'B '– No n-Gazetted –
Non-Ministerial.

4. Pay Band and Grade Pay/Pay Scale

:

Pay Band– 2 ` 9,300-34,800 + Grade Pay ` 4,200

5. Whether selection post or non-selection post

:

Not applicable

6. Age-limit for direct recruits

:

Not exceeding 30 years
(Relaxable for Government servants up to 5 years in
accordance with the instructions or orders issued by the
Central Government)
Note : The crucial date for determining the age-limit shall be
the closing date for receipt of applications from candidates in
India (and not the closing date prescribed for those in Assam,
Meghalaya, Arunachal Pradesh, Mizoram, Manipur, Nagaland,
Tripura, Sikkim, Ladakh Division of Jammu and Kashmir State,
Lahaul and Spiti District and Pangi Sub-division of Chamba
District of Himachal Pradesh, Andaman and Nicobar Islands
or Lakshadweep)

7. Educational and other qualifications required for :
direct recruits.

Essential :
1 (a) Diploma in Mechanical/Automobile/Industrial/
Production Engineering/Chemical/Electrical/Electronics/
Computer Science/Information Technology/Textiles
from a recognised Board or University; and
(b) Practical Experience in workshop or a factory for a
period of not less than 2 years.
Note: (1) Qualifications are relaxable at the discretion of
the SSC/Competent Authority for reasons to be recorded
in writing in the case of candidates otherwise well
qualified.
Note: (2) The qualification(s) regarding experience is/are
relaxable at the discretion of the SSC/Competent Authority
for reasons to be recorded in writing in the case of
candidates belonging to Scheduled Castes or Scheduled
Tribes if at any stage of selection the SSC/Competent
Authority is of the opinion that sufficient number of
candidates from these communities possessing the
requisite experience are not likely to be available to fill up
the vacancies reserved for them.

<!-- page 4 -->

5
Desirable :
Degree in Mechanical/Chemical/Electrical/Electronics/
Automobile/Industrial/Production Engineering/Computer
Science/Information Technology/Textiles of a recognised
University.
8. Whether age and educational qualifications :
prescribed for direct recruits will apply in the case
of promotees.

Not applicable

9. Period of probation, if any

Two years.

:

10. Method of recruitment whether by direct :
recruitment or by promotion or by deputation/
absorption and percentage of the vacancies to
be filled by various methods.

By Direct Recruitment
Note : Vacancies caused by the incumbent being away on
deputation or long illness or study leave or under other
circumstances for a duration of one year or more may be
filled on deputation basis from officers of Central/State
Government/Union Territories:(a) (i) Holding analogous posts on regular basis in the
parent cadre/department; or
(ii) With 6 years regular service in posts in Pay Band-1;
` 5,200-20,200 with Grade Pay ` 2,800; and
(b) Possessing the qualifications and experience prescribed
for direct recruits under column (7).

11. In case of recruitment by promotion /deputation/ :
absorption, grades from which promotion/deputation/
absorption is to be made.

Not applicable.

12. If a Departmental Promotion Committee exists, :
what is its composition?

Group 'B' Departmental Confirmation Committee (for
considering confirmation):—
(i) Chief Secretary to Government

. . Chairman

(ii) Secretary to Government (Industries . . Member
and Commerce.
(iii) Director of Industries and Commerce . . Member
13. Circumstances in which the Union Public Service :
Commission is to be consulted in making recruitment.

Consultation with Union Public Service Commission is not
necessary.

(By order of the Lieutenant-Governor)
G. M ALAR KANNAN,
Additional Secretary to Government
(Industries and Commerce).
online publication at “http://styandptg.puducherry.gov.in”
Government Central Press
Directorate of Stationery and Printing
Puducherry-9
