---
doc_id: "e3f8cd9e462a5bfa"
source_url: "https://pipdic.in/uploads/news_feeds/adv_con.pdf"
ministry: "Puducherry Industrial Promotion Development and Investment Corporation (PIPDIC), Puducherry"
title: "NOTIFICATION - PIPDIC - APPLICATION FOR THE POST OF CONSULTANT - Retired Group 'B' Govt. officials are invited"
date: ""
pages: 3
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "25602933135ddab5"
---

<!-- page 1 -->

No. PIPDIC/Admin/376/2020/2024/2/ | 2354
PONDICHERRY INDUSTRIAL PROMOTION DEVELOPMENT AND INVESTMENT
CORPORATION LIMITED
(A Government of Puducherry Undertaking)
Puducherry, the 7 4 SEP 2025
To ச
The Director of Industries and Commerce,
Puducherry.
Sir,
Sub: PIPDIC-Engagement of One Govt. retired Official as Consultant for
PIPDIC, Puducherry - Notification - Reg.
{rhein
The Pondicherry Industrial Promotion Development and Investment Corporation
(PIPDIC), Puducherry is inviting application from the Group-B retired Govt. Officials to
work as Consultant with experience in CSS schemes, industrial sector and other
MSME related subjects.
2. Hence, I am to request you to make necessary arrangements for
uploading the advertisement/notification material enclosed in Department’s website
| for information of Public/retired Govt. Officials
்‌ Yours faithfully,
| Ane
General Manager (Admin)
Encl.: As above
Copy to : EDP section - for uploading in PIPDIC website
|
5

<!-- page 2 -->

PONDICHERRY INDUSTRIAL PROMOTION DEVELOPMENT AND INVESTMENT
CORPORATION LTD.
(A Government of Puducherry Undertaking)
No. 60, Romain Rolland Street, Puducherry- 605001
File No. PIPDIC/Admin/376/2020/2024/2 Puducherry, the
NOTIFICATION
The Pondicherry Industrial Promotion Development and Investment Corporation
Limited (PIPDIC), Puducherry intends to engage one official retired from Govt. of
Puducherry as Consultant on contract basis for a period of one year by inviting
applications in the prescribed form:
[ SI.No | Name of the Post No. of Post Eligibility
Retired Group "B" Govt. Officials.
Educational qualification: Any
Consultant degree/Diploma in Engg.

Age: Not exceeding 65 years

Experience: Minimum 3 years’ in

implementing CCS-Schemes / Industrial ்‌

Sector MSME related matters
2. The duly filled in application form, as prescribed in the Annexure-l, may be
submitted to the Managing Director, PIPDIC, No. 60, Romain Rolland Street, Puducherry-
605001, superscribing on the envelope "APPLICATION FOR THE POST OF CONSULTANT™ on
or before 03.10.2025 at 5.00 p.m.
3. 3. The engagement will be on full time basis initially for a period of six months and
shall be expandable depending upon the necessity. The consultancy fee will be paid as
per the rules in force. The other terms and conditions of the agreement shall be in
accordance with the I.D. Note/ Memo. No. 46324/FD/F3/2014 dated 11.09.2014 &
01.12.2022 of the Finance Department, Puducherry. On selection, the officials shall
execute an agreement in the prescribed form. The appointment of consultants shall be
purely of temporary nature against the specific job and the appointment will be cancelled
at any time without assigning any reason thereof. The Managing Director, PIPDIC,
Puducherry reserves the right of any changes, cancellation of this Notification as a whole,
or in part, at any point of time without assigning any reasons.

/1 BY ORDER //
(P.RAGINI)
General Manager (Admin)

<!-- page 3 -->

|
ANNEXURE-I
APPLICATION FOR ENGAGEMENT OF RETIRED GOVT. OFFICIALS AS CONSULTANT IN PIPDIC
LIMITED, PUDUCHERRY
1. Name 7
2. Date of Birth : Recent Passport
3. Address of Communication : Size Photo to be
Pated here |
4. Contact Number (residence/Mobile) ப : |
5. E-mail Id Hy |
ர
6. Particulars of Government Service
6.1 Date of Joining in Govt. service : |
6.2 Date of retirement and the post : |
in which retired |
6.3 Name of the Department/ ன்‌ |
Organization from which retired |
6.4 Last Pay மலய. :
(Copy of the PPO to be enclosed)
7. Education Qualification : .
8. Details of Knowledge in Computer :
9. Brief particulars of experience with 7
nature of duties performed (Starting
last appointment)
Sl.No | Name of the Period Post held Nature Work
Ministry/ Dept
னு
10. Additional information if any, Support  :
Of the suitability of the post
Declaration
"hereby declare that the particulars furnished above are true and correct to the
best of my knowledge and belief. | further declare that | was clear from Vigilance Angle at
the time of retirement.
Place:
Date: ' . Signature of the Applicant ்‌
