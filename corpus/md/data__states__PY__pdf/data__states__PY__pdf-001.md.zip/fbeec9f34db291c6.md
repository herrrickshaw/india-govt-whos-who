---
doc_id: "fbeec9f34db291c6"
source_url: "https://py.gov.in/sites/default/files/home27102026go43.pdf"
ministry: "Forest and Wild Life Department, Puducherry"
title: "G.O. Ms. No.43"
date: ""
pages: 7
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "064eae0b33db4717"
---

<!-- page 1 -->

GOVERNMENT OF PUDUCHERRY |
Abstract
ee
Grant of Non-Productivity Linked Bonus (Ad-hoc Bonus) to Union Territory
Government Employees for the year 2025-26 - Orders - Communicated.
FINANCE DEPARTMENT
G.O.Ms.No.4.3/FD/F3/A2/2026 Puducherry, 27.10.2026
Read: Office Memorandum F.No.7/24/2007/E 111) dated
15.10.2026 of Department of Expenditure, Ministry of |
Finance, Government of India, New Delhi.
ee
ORDER:
1. Recorded.
2. A copy of the Office Memorandum read above is forwarded
herewith for information and necessary action.
// BY ORDER //
(
eae
(5. SIVAKUMAR)
UNDER SECRETARY TO GOVT.
(FINANCE)
To
1. All Secretariat Departments.
2. All Heads of Department/ Office.
Copy to:
1. The Director of Accounts and Treasuries, Puducherry.
2. The Sr. Dy. Accountant General, Puducherry Branch, Kumarakurupallam,
Puducherry.
3. The Dy. Director of Accounts and Treasuries, Karaikal, Mahe and Yanam.
4. The Central Records Branch, Puducherry.
5. The Director, Information & Technology Department, Puducherry
- for uploading the G.O. in the State Portal.

6. The Website Maintenance Section, Finance Dept., Puducherry
7. Stock File.

<!-- page 2 -->

படர ணன்‌
ர. No. 7/24/2007/E Ill (A)
Government of India
Ministry of Finance
Department of Expenditure |
Kartavya Bhawan-1, New Delhi,
Dated 15.10.2026
OFFICE MEMORANDUM
Subject: Grant of Non-Productivity Linked Bonus (ad-hoc bonus)
to Central Government Employees for the year 2025-26.

The undersigned is directed to convey the sanction of the President to
grant of Non-Productivity Linked Bonus (Ad-hoc Bonus) equivalent to 30 days
emoluments for the accounting year 2025-26 to all Central Government
employees in Group ‘C' and all non-gazetted Central Government employees
in Group ‘B’, who are not covered by any Productivity Linked Bonus Scheme.
The calculation ceiling for payment of ad-hoc Bonus under these orders shall
be monthly emoluments of Rs.7000/-. The payment of ad-hoc Bonus under
these orders will also be admissible to the eligible employees of Central Para |
Military Forces and Armed Forces. The orders will deemed to be extended to
the employees of Union Territory Administration which follow the Central
Government pattern of emoluments and are not covered by any other bonus
or ex-gratia scheme.

2. The benefit will be admissible subject to the following terms and
conditions:-
(i) Only those employees who were in service as on 31.3.2026 and have
rendered at least six months of continuous service during the year 2025-26
will be eligible for payment under these orders. Pro-rata payment will be
admissible to the eligible employees for period of continuous service during
the year from six months to a full year, the eligibility period being taken in
terms of number of months of service (rounded off to the nearest number of
months);
(ii) The quantum of Non-PLB (ad-hoc bonus) will be worked out on the basis
of average emoluments/calculation ceiling whichever is lower. To calculate
Non-PLB (Ad-hoc bonus) for one day, the average emoluments in a year will
be divided by 30.4 (average number of days in a month). This will, thereafter,
be multiplied by the number of days of bonus granted. To illustrate, taking the
calculation ceiling of monthly emoluments of Rs.7000/- (where actual average
emoluments exceed Rs.7000/-), Non-PLB (Ad-hoc Bonus) for thirty days
would work out to Rs.7000x30/30.4=Rs.6907.89/- (rounded off to Rs.6908/-).
oe
1
“A
ல
ஆ

<!-- page 3 -->

(iii) The casual labour who have worked in offices following a 6 days week for
at least 240 days for each year for 3 years or more (206 days in each year for
3 years or more in the case of offices observing 5 day week), will be eligible
for this Non-PLB (Ad-hoc Bonus) Payment. The amount of Non-PLB (ad-hoc
bonus) payable will be (Rs.1200x30/30.4 i.e.Rs.1184.21/- (rounded off to
Rs.1184/-). In cases where the actual emoluments fall below Rs.1200/- p.m.,
the amount will be calculated on the basis of actual monthly emoluments.
(iv) All payments under these orders will be rounded off to the nearest rupee.
(v) Various points regarding regulation of Ad-hoc / Non-PLB Bonus are given
in the Annexure.
3. The expenditure on this account will be debitable to the respective object
head in terms of Department of Expenditure's Notification dated 1 eth
December 2022.
4. The expenditure to be incurred on account of Non-PLB (Ad-hoc Bonus) is
to be met from within the sanctioned budget provision of concerned
Ministries/Departments for the current financial year 2026-27.
5. In so far as the persons serving in the Indian Audit and Accounts
Department are concerned, these orders are issued in consultation with the
Comptroller and Auditor General of India as mandated under Article 148(5) of
the Constitution of India.
(Umesh Kumar Agarwal)
Director
To,
All Ministries/Departments of the Government of India as per standard list
etc.
// Copy //
Poly
(A. IDAYAVENDANE ANNIBAL) 2
Superintendent
Finance Department |
f Puducherry.
|

<!-- page 4 -->

| ANNEXURE
| ANNEXURE to O.M. No. 7/24/2007-E-III(A) dated 15/10/2026

[Point Point | Clarification

|_No. _ ten! |

1 தய employees in the| Subject to completion of

‘following categories are eligible | minimum six months
for the benefit of ad-hoc bonus for | continuous service and being in
an accounting year. service as on 31st March, 2026.
(a) Employees appointed on purely | Yes, if there is no break in service.
temporary ad-hoc basis. ட்ட ட.
(0) | Employees who resigned, retired) As a special case only those
“from service or expired before 315! persons who superannuated or
| | March, 2026. retired on invalidation on medical
| grounds or died before 31st March,
2026 but after completing at least
| | six months regular service during
| | the year will be eligible for the ad-
hoc bonus on pro rata basis in
| terms of nearest number of months |
of service.
(c) Employees on deputation/ foreign | Such employees are not eligible
service terms to state governments, | for the ad-hoc bonus to be paid by
பா. Governments, Public Sector | the lending departments. In such
Undertakings, etc., on 3151 March, | cases the liability to pay ad-hoc
| 2026. bonus lies with the borrowing
| organization depending upon the
| ad-hoc bonus/PLB/ex-gratia/ |
incentive payment scheme, if any,
| | in force in the borrowing
| organization.

(9) |Employees who reverted during| The total amount of bonus/ex-
accounting year from deputation on | gratia received for the accounting
foreign service with the organizations | year from foreign employer and the

‘indicated in ‘C’ above. ad-hoc bonus, if any, due from a
central government office for the

| period after reversion will be |
| restricted to the amount due under
| ad-hoc bonus as per these orders.

|

a
3

<!-- page 5 -->

(6) Employees from state | Yes, they are eligible for ad-hoc
Government/U.T. Admn./Public | bonus to be paid by the borrowing
Sector undertakings on reverse| departments in terms of these
deputation with the  Central| orders provided no additional

| Government. incentive as part of terms of
| deputation, other than Deputation
| Allowance, is paid and the

| lending authorities have no
objection பபப ப பபப.

(0 Superannuated employees who Re-employment. ite’ : i

ப employment, eligibility period i

were re-employed. to be’ worked Gut separately for |
| re-employment period; the total
| | amount admissible, if any, for
| | period prior to superannuation
| and that for re-employment period
being restricted to the maximum

| | admissible under ad-hoc bonus |

்‌ _____| under these orders.

(g) | Employees on half-Pay| Except in the case of leave

| | leave/E.O.L./Leave not due/study | without pay the period of leave of

| | leave at any time during the | other kinds will be included for the |

| accounting year. | purpose of working out eligibility |

| period. The period of E.O.L/dies |

| non will be excluded from |

| eligibility period but will not count |

| | | as break in service for the,
| purpose of ad-hoc bonus.

(h) | Employees under suspension at] Subsistence allowance given to
| any time during the accounting| an employee under suspension |
| year. for a period in the accounting year

cannot be treated as emoluments.
| Such an employee becomes
eligible for the benefit of ad-hoc
| bonus if and when reinstated with

| | benefit of emoluments for the
| period of suspension, and in other |

| | cases such period will 6௨
| excluded for the purpose of
| eligibility as in the case of

employees on leave without pay.

(i) Employees transferred from one Employees who are transferred |
| Ministry/Department/Office covered| from any of the  Ministry/

by ad-hoc bonus orders to another | Department/Office covered by

| | within the Government of India or| ad-hoc bonus orders to another |
| | a Union Territory Government| such office without break in)
| covered by ad-hoc bonus orders | service will be eligible on the basis |
| and vice versa. of combined period of service in |
| | the different organizations. Those
ப ப ப ப பப) ஸு nominated on the basis of |
a ‘

<!-- page 6 -->

| ண்ணா [தரம்‌ departmental or open
| competitive exam from one
| organization to a different
| organization will also be eligible
| | for the ad-hoc bonus. The
| | payment will be made only by |
| | the organization where he was |
employed 85 on 315 March, 2026
and no adjustments with the
ப previous employer will be!
0) Employees who are transferred| They may be paid what would
from a Government Department/| have been paid on the basis of
Organization covered by ad-hoc| emoluments in ad-hoc bonus
bonus orders to a Government} covered department for the entire
| Department/ Organization covered| year less the amount due as,
| | by productivity - Linked Bonus | productivity-linked bonus. The |
| | scheme or vice versa. amount so calculated may be
paid by Department where ௨.
| was working on 3151 March,
| | 2026 and/or at the time of
டாட்டா jayment.
(k) Part-time employees engaged on| Not eligible.
nominal fixed payment |
2. Whether ad-hoc bonus is |
payable to casual labour for an |
accounting year in the following |
LL cases:-
| number of days of work in different | for three years from the said
| offices during each of the three accounting year backwards. The |
| eis, with the said | period of 240 days of work in each
| | @ year. | of these years may be arrived at
| by combining the number of days |
| | worked in more than one offices of |
| the government of India, for which
bonus, ex-gratia or incentive |
| payment has not been earned and
| | received,
| | |
(6) | Casual labour who were notin work’ The condition of being in
i on 315‘ March, 2026. | employment on 31st March, 2026
| as laid down in these orders is
| applicable to regular Government
| Employees and not to casual
| labour.
(9) ihe le have a al least if a casual labour, who has been
specified number of days of work in ized i i
| Leach of two years preceding the பரப்ப the accounting year
ஷி 5
இழப்‌

<!-- page 7 -->

ப ர ப foun ae ட்‌
| ‘accounting year but are short of) does not fulfill the © minimum
| this hue to வட்வரவம்‌ in| continuous service of six months

in the said accounting] ௩ ர 313 March, 2026 and
therefore, cannot be granted
| benefit as a regular employee, he
| may be allowed the benefit as for
| a casual labour provided the)
| period of regular service in the
| i said year if added to the period of
| work as casual labour works out
| to at least specified number of
| days in that accounting year.
NY
1] Copy //
rks,
(A. IDAYAVENDANE ANNIBAL)
Superintendent
Finance Department
Puducherry.
|
6
