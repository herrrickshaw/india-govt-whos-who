---
doc_id: "8c1bcda0fe4e730e"
source_url: "https://industry.py.gov.in/sites/default/files/recrutimentrules-post-ad-go.pdf"
ministry: "Industries and Commerce Department, Puducherry"
title: "recrutimentrules-post-ad-go.pdf"
date: ""
pages: 6
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "8df30c52ebd42b8b"
---

<!-- page 1 -->

Lane கக்‌ பன்‌,
ந்தை இ iN
இல்ல ௨ a =
tlhe ay) GOYERM MENTE OF பாயப்‌ ்‌

Kavine ts sux SE

5 Mi 1. SP ட) பருவம்‌ படுவாய்‌

LEN Ee ty

1010. (Ms) No. 746 dated 23rd October 1978]

te ரு ல்லி Fad NOTLELCATION

ait tn! éxeccize ‘ot lie powers conferred by the Notification
No. $/4/65-GP dited Lith Januaty 1905 of the Ministry of Home

© Allnira, QGovertunout of fndia and to supersession of the முத பபாய்‌

of: Pondicherry ‘Class 11 Reeruitment (யர. 1973 for the posts ol

|) Aaslstant Director of Industiies (ii) Admluistrative Ollicer, Indus-
பியி Estate, Thattanchavudy and (til) Pinnning-cum-Sucvey Olllcer in

Sethe fndustrles Departinent, Pondicherry published under 0.0. In

"No. 39, dated 29th Marci 1973 of the Development Ucpartinent, வப

Supplement to Gazette No. 20 duted 15th Muy 19/3 os amended,

i ihe Livutenant-Govertor, Pondicherry licreby imakes the following

ரய] regulating the methods of recruitment to Group ‘B' (Technical)
posta In the Industries Department, Government of Pondicherry,
Ponillcherry.

ர | SHORT TITLE : ‘These rules muy be called the Government

1 of Pondicherry, Industrics Deparlinent Group 'B' Posts (Technical)

i Recrultinent Rules, 1978. '

2. அ. APPLICATION : These rifles shall upply for recruitment to
the posts In the Industries Departnent, Pondicherry specified in
column (1) of the schedule hereto wunexed.

3. NUMUER OF 20819, THEIR CLASSIFICATION AND
SCALES OF PAY: The number of the sid post, it classification and
ihe scale of pay attached therely shall be as speciiied in columns (2) ம
(ர்‌) of the sald schedule, ன்‌

4, METILODS OF RECRUITMENT, AGE-LIMITAND OTHER
QUALIFICATIONS: The method of recruitinent to the said posts,
nge-limit, quatifications and other matters reluling thereto shall be as
specifled in columus (5) to (13) of the said schedule: 4

Provided that the uppor nge-lindt specitled for direct recrubtinent
indy be relaxed In ihe case of candidates belonging toy the
scheduled castes, scheduled trikes ond ather special categories of
persons In accordance with the general orders of the Lieutenant-
Governor issued from time to time. F

5, DISQUALT (AN TIONS : (0140 person who tina more than
one wile living or who lawinge a spouse living, mareles in பரு வரச்‌
பட உ ப்பம்‌ தய of ie கி me freee:
பற்கள்‌ அல வப்‌ இரகம்‌ ae ear MER ee ல > sary
of the said post எ] ப்பா காட tony

<!-- page 2 -->

(i }
81 ) i uf ty i> guy’ hs
இள மிரா ஹி (ம டவ ல H
ர்‌ +i! | 14 ல்லி iM பப்பு [ ரு On
te Va) NoP Wola Whose marrige Ie void by rensorts of Ray ்‌
பயம living at the thie of ய பய யமா i
(ohosu wife Hving atthe Hine of auch marriage, பியி be eligible for |
ப்‌ யய (௦ uy of the suid posts: tb of! |
| 1 Provliled Wot the Licttennut-Governor, பாரு, it sattstied Ural jf |
there 116 apeclal grounds for au orderlug, exempt any person from the |,
ANS thts rulel i) ep te whys ?
eo 6] POWERITO RELAX உ Wheto the Lieutenaut-Governor It,
1:௦1 (he (91/01) tlitt It Is necessary or expedient so to do, mny by order, |;
for redsdlis (0 be recorded’ In welting*dnd In consultatinn with the
ff: Uulou! Publis. Servied! Conslsslon: relax any of the‘ provisions of |
1, ம rules {tb ceopect (புடி class of enlegury of persons." ) 1].
ய்ய Al SAVINGS: (UL Nothiig in these rules shall affect the எண்ட. ர |
பா மாற srecrullments already made fo uccordance with the. |
; ‘recrultuiout- பயறு how, superseded. -| ty 2 “I
1 | (2) Nothlig ய காயப்‌ affect கட்ட ப ப்பயஙிற்‌
அப: பயா யால்‌ to be provided for 'tho schéduled;
* enstes, tho achoduled tribes and other npecial cntegorles of perions |. \
"du necordinea with tho orders ‘sailed by the Government From),
| tino to ture da Uile reguid. ‘ | Nj
நத ! (By Order of the Lleutennnt-Goyeraor) ம்க்‌
1" 2, 0, மொடா,
| Under Secretory te Government. | ¢
॥
| ்‌ 1
த்‌ — |

<!-- page 3 -->

— டை
1 தோட்‌
/
2 a
[2 = if
A
Pot Name at past Accstant Director ef Induetriet
1
/ | Number of poral Pout os பத்து
1 pestle tion வேரி
1. Seale at yiny டி ளர்‌ 31-700
= 5. Whether அவிய peste Selection
ok பய post. ==
1
3) yeni! for allreet reernlts 39 years
3 ete பத wee ti) Depree In Mechanical or Chemi-
ழ்‌ 7 யய required m calor Flectrieal Engineering of
3 ரமா! reneulls: ' a recognised Univ ersily of equi-
is valent and (lip Aboul oa mi
ம்‌ experience in the industrial (1810.
ac , ' ன்‌
அப்ப பயம்‌ ng
ஜ்‌ quatitivwtiona pemyertbed Lee ger Na .
bs பிர்‌ பயி will வுடு fn [duentional மிது tn the
[2 - Ihe ene of prmmotees. eaten! specified te வரியா 117.
: -
சீ].
பப்ப probotion, IF any ஸு
“r . Two years.
ய
ia, AN | of . Gereenttin ey promotion falling which hy
ட்‌ whether hy ஏறி வியன்‌ direct reeruilment.
3 mention by | pramedian et, a :
ட்‌ hy deputation/travsfer and
a pereentage af the yaeaneies
ட்‌ நட ட பி பிட. வர்ற
of nielhiods,
ன்‌ ள்‌
ம்‌
ய பகவா | பஸ்‌ by Prometion front the grate of Tech
2 பவ்ய polation | nicn! Officer anh Superinicndent,
z Irnnster, பமா Gren ahiels பய யை யக ப யய ம்பம்‌
ப்‌ வடை. பியுவபவய fl Workshops with o regrdur service
7, விய fe be பிபி ef years in the race af depres
ய்‌ haters or S years in the case of
2 diploma holders. =
52. 1ஈ19.॥.0/1.0. exists, 5
= 2. பேட, exists, elit 16
ர ita வம்பா Choup ile பிராவ (பி பப
[1] (பி,
[22
5 '
॥
11 Cher 12 i shits, ்‌ ்‌
; ER ‘ i whieh Direct reeruituient shall fee டவவி
BS ie tee bee ட்ப iy வேப்ப with) Che Unian
பட பப்ப பப பயங்‌ Nublie Service Cumearission.
!
|
|

<!-- page 4 -->

i” ய்‌ ப 2
பலக்‌ “ scnepuLe-t . . nie ட, .
‘oreo ; ம] NCTIONAL MaNAcER/Mos“cr MANLY
SS a யாள க்‌ ப
‘ 2) ப Says ம்‌ : Funetional Monuger/Project Manager.
So ‘A Rowe ev" ore jution depondent of work-load)- *
ட டட றத ப 4998 abso to vo ன்ட்‌
படல க்கல்‌ அதது ்‌ ‘General Conteal “Servjee—Group பம்‌ Gazetted —Now-
Be ee se pay பட பட... Rs 2;200-75-2,800-BU=]00-4.000. > .
Bert's Wi jather soloction post OF பண்னி 001 Not opplicuble, த :
ந ’ ote நர்ஸ்‌ for direct மாய _ Not applicable, wal ட
கட்ட யப ரவு வலி ட்ட.
a) What a i 9 of (மலய Civil, தில்‌:
~ Services (Pension) 10% 1972. ப ட ்‌ :
7, Educational aod other qualificutions reyvirod Not applicable. oF 5
for மிலம்‌ ரனமிம.
நட Whether age and educational qualifications Not applicable,
"  proseribed for direct fecruits will apply in the F :
ட case of ‘promotes. . ம்‌ . க
g,.-Period .of probation, if any, Not applicable.” ல ட ன்‌
ட்‌ of recruitment, whether by direct By transfer on deputation, — .
wt டஃப்‌ or by promotion oF by deputation? vate அ
> qransfer und percentage ‘of the vacuncics to be ;
jx filled by various methods. + , ap aig கழு : -
1. In case of recruitment by promotion/deputation/ "Transfer on deputution : ‘ :
“waster, நாமம்‌ from oh promotion) Ollicers of ‘the Government of Pondicherry. (விய
பல்‌ deputationjtrnnater is to De 88 உ which officers of "the Centeal/Stite பக்கப்‌ ப 1
Abe 1 . ‘ ப ஐ. மு sholding pnalogous posts on 7 regula
Sc a ௫1% os, CHS 7 ச me 4 ‘
‘ribeye 1 வ ரை த 0] ப ears oplas service in posts in tt
MR ச * ர டத ப 7 90040 of. Rs. 2,003,500 Of equivalent; +
2 ட்டை: ட்ப ப service imports in t
tof 6 s 1% - ‘scale of “Rs, 1 ,640-2,90) ot equivalor
os நகத்த 1 504 ப: 1 பது . i
_ ae ௫ 0 ணன்‌ Diploma fram ம recognt:
: ்‌ . niversity/ Institution. inv அலியார்‌ :
ச்‌ Choinion!/lélectrleal)Mcctronits Motul!
‘ : . gicul Engineering or in Lethe? Vechnole
ட்‌ oe Food ‘Technology | “Veatile: YVeehuol
a . (according to requirement); aud ’
© Scanned with OKEN Scanner

<!-- page 5 -->

= ன
De a oS a
NP ம reas anc altied
o ; jod of deputation includ
Pliers வலக்‌ pod | | tee
jon) ul 1 n பலுன்‌ -
. சிவர not exceed 3 years) :
red 12. ara DP. வடி what is its composition? Not applicable,
Public Service Commission
ழு. 8 nces in which Union Public Service Consultation with the Union on
Commision js to be consulted in making vce) wile sor கவட "
,
. SCHEDULE-I
1, Name of post Deputy Functional Manager.
2. Number of posts. 4 (1987) (Subject to variation depandent on work-load).
3. Classification General சேயாய்‌ Servico~Group ‘B’ Gareited-Techsical.
| பம்‌ Scale'of pay ~ , Ra, 1,640-60-2,600-BB-75-2,900. ‘ ்‌
| $, Whether solection post or uon-solection post Not applicable. க
| :
| 6 Age Umit for direct recruits, | Not applicable,
|
| 6 (a). Whether benofit of added ycars of servico Not applicable,
admissible under rule 30 of the Central Civil
| Services (Pension) Rulcs, 1972, 7
7. Bdycational and other qualifications required for Not applicabl
| ‘ “ (1 required Applicable. .
| ந, Whether a and educational qualifications Not applicable,
j prescribed for direct recruils will apply io thi ட
| case of promotecs.
| 9, ராரா any 4 |, Not applicable. ்‌ ந ன்‌
|. மு, Method of recruitment whethar by direct’ By transfor tation, ~ ¢
recruitment exktomotion “or by deputatioil/ பம வழு அல
transfer மேம்‌ percentage of tho vacancies to. bo eu RY ot
a filled by various. methods. ப வட . '
‘
C scanned with OKEN Scanner

<!-- page 6 -->

அத 6 2 7. னு
ஃ பதிய of sverwitment by பலவான்‌ | ட on deputation | ee ்‌
3 ot 172 vige fron பன யயயம்‌ க்ப்‌ ம்‌
ek பரட்‌ தத்‌ ea
ந்‌ டட ந்தன?! Halon Territories— - 4
fs eee ட ட டட டு. holding analogous poste om 68 tagular |
[3 ந்தி "basis; oF 4 ம்‌
மா ழ்‌ : i) with 5 yours requlur service in 0045 in the »
(அது ‘ : ‘ ». 80015. of Res f400-2,300 of. equivalent;
; te : பல்கி, ககர அடர்‌ peor 7
ம (ம) * posvessing experiance in development of
ம்‌ Pe Us : ப்‌ { ்‌., . cottage கம்மி village. industrics ‘and allied
ம்‌ ட்‌ உ... (Period of deputation including period of deputation
= * jn another ex-cudre post held, iminediately preceding
| this appointment in the same or 5016 other organisation] ~
வ 8 ' . . ' ர ரலிலி ற்ப th: Central Government shall ordinarily
i 12 Ma a exists, what is its Fomposition ‘Not applicable, ன்‌ % ர ss ஓ நித
ர. கண்ணகை வங LAS AR Macias வெவலாகைநு ல pth
Commission is to be consulted in muking necessar; on ithe Uniad Fable Rervice comment oe
்‌ ! 3 while solecting an oficer f ட
; am ணர்‌ ae | doputation undor tolling hight" பகத்‌? இ aie
ர (Wy order of the Licutenant-Governor) க ்‌
: ம ‘ 2 ்‌ V.. sRAJAGOPALAN, »
5 Under Secretary to Government (lud.).
, F os
‘ Government Presq-(C) WW State த ட்‌ .
Directorate of Slutionery and Printing 8
: PONDICHERKY-0 = -*
© Scanned with OKEN Scanner
