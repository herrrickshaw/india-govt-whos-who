---
doc_id: "d3c9df3d5acf0fd8"
source_url: "https://py.gov.in/sites/default/files/dat30072025memo.pdf"
ministry: "Forest and Wild Life Department, Puducherry"
title: "Memorandum"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "90bec895240931c3"
---

<!-- page 1 -->

BY RPAD
GOVERNMENT OF PUDUCHERRY
DIRECTORATE OF ACCOUNTS & TREASURIES

***
No.l2-l /DAT /S.K.Estt./S.K.Gr-111 (DR)/2022/43

Pvducherry, dt. 30.07.2025

MEMORANDUM

The vndersigned hereby offers to the cand idates mentioned in the
"Annexure" to this Memorandvm a temporary post of Store Keeper Grade-Ill
(Group C) in the Level 2 of the Pay Matrix on Regular basis in the
Department/Office mentioned against them with immediate effect.
The
appointee will also be entitled to draw the dearness and other allowances at
the rates admissible and subject to the conditions laid down in ru les and orders
governing the grant of such allowances in force from time to tim e .
2.

The terms of appointment are as follows :i)
The appointment is temporary and may be termi nated at any time
by a month's notice given by either side w ithout assigning any
reasons. The Appointing Authority, however, reserves the rig ht of
terminating the services of the appointee forthwith or before the
expiry of the stipulated period of notice by making payment to
him/her of a sum equivalent to the pay and allowances for the
period of notice or the unexpired portio n thereof;
ii)
He/She shall be placed on probation for a period of two years from
the date of joining the post.
He/She should pay security deposit as prescribed by Government
iii)
from time to time
iv)
He/She shall have to undergo a Training in "Techniques of Materia l
Management" conducted through Administrative Reforms Wing ,
Chief Secretariat, Puducherry
v)
He/She should pass the Accounts Test for Subord ina te O fficers (Part I
& II) conducted by the Department of Person nel and Adm inistrative
Reforms (Personnel Wing), Chief Secretariat, Puducherry during the
period of probation , failing which he/ she will b e ousted from
service.
vi)
Other conditions of service will be governed by the relevant rules
and orders in force from time to time;

3.
The appointment will be further subject to production of the following
certificates in original:i)
ii)

iii)
iv)

v)

Production of Educational I Technical qualification certificate
Production of Age, Nativity/Residence Certifica te, Nationality
Certificate, Community Certificate, Physically handicapped(for PH
candidates only) and Ex-servicemen(for XSM candidates only)
Production of certificate of fitness from the Competent Medical
Authority (R.M.O).
Submission of a declaration in the form enclosed (Annexure -!) and in
the event of the candidate having more than one w ife living or
being married to a person, having more than one wife living, the
appointment will be subject to him/her being exempted from the
enforcement of the requirement in this behalf
Submission of attestation forms for verifica tion o f character and
antecedents along with joining report.

4.
In case it is found that he/she was guilty of misconduct involving moral
turpitude, which would disqualify him/her for Government Service, or had
suppressed any material fact relating to his/her conduct prior to en try int_
o
Government Service or if any declaration_ given or information furn ished by the
candidate proves to be false, he/she will be lia b le to be discha rged from
service and such other action as Government may deem necessary.

<!-- page 2 -->

-25.
It may please be stated whether the candidate is serving or is under
obligation to serve another Central Government Department/State
Government or Public Authority.

6.
As no person professing a religion different from the Hindu or Sikh religion
can be deemed to be a member of Scheduled Caste, the candidate should
inform about the change if any, of his/her religion to his/her
appointing/administrative authority immediately after such a change.(This
applies only in case of Scheduled Caste candidates).
7.
The appointment is purely on provisional basis and is subject to the caste
certificate being
verified through proper channels in respect of
OBC/MBC/ST/BCM/EBC/EWS/SC and if the certificate and if the verification
reveals that the claim to belong to OBC/MBC/ST/BCM/EBC/EWS/SC is false, the
services will be terminated forthwith without assigning any further reasons and
witho ut prejudice to such further action as may be taken under the provisions of
the Indian Penal Code for production of false certificate.
8.
If the candidate accepts the offer on the above terms and conditions,
he/she should report before the Head of Department/Office concerned
immediately and in any case not later than 20.08.2025. If the candidate fails to
report for duty by the prescribed date, the offer will be treated as cancelled,
and no further com munication will be entertained.
9.

No travelling allowance will be allowed for joining the post.

I /By Order/I
(S. UDAYASANKAR)
DIRECTOR

To
The Individuals concerned
Copy to:1} The Head of Department/Office concerned. --- When the candidate reports for
duty, he may be appointed as Store Keeper Gr.lll. You are requested to verify
the Age, Nativity/Residence Certificate, Educational/Technical Qualifications,
Community Certificate with the original records and to collect the attestation
forms for verifica tion of character and antecedents from the candidate while
joins duty and forward the same separately to the, Directorate of Accounts &
Treasuries, Puducherry. The clauses stated in para 2 of this Memorandum are to
be included in the posting order to be issued. The Bio-data of the individual in
the prescribed Proforma should be sent to the Directorate of Accounts &
Treasuries, Puducherry along with a copy of posting order.

2} The Deputy Secretary to Govt. (Finance}, Chief Secretariat, Puducherry
3) The Under Secretary to Govt.(Administrative Reforms Wing), Puducherry
4) The Under Secretary to Govt., Department of Personnel & Administrative
Reforms(Grievances Cell), Chief Secretariat, Puducherry
5) The Distric t Collector, Karaikal
6) The Regional Administrator, Yanam
7) The Deputy Director of Accounts and Treasuries, Puducherry/Karaikai/Yanam ..
8) The P.S to Chief Secretary to Govt., Puducherry
9) The P.S. to Chief Minister, Puducherry
10) The P.S to Development Commissioner-cum-Secretary(Finance) ,Puducherry
11) The Under Secretary to Govt., Examination Cell, DP&AR, Puducherry.
12) The Employment Officer, Employment Exchange, Puducherry
~ The Programmer, EDP section, DAT, Puducherry ---to upload in the official
website

14) The Store Superintendent, DAT, Puducherry
15) Spare

<!-- page 3 -->

Annexure to the Memorandum No.l2-1/DAT/S.K.Estt./S.K.Gr.III/DR/2022/43, dt.30.07.2025
Sl.
No

Roll No.

1.

13795

2.

Name

Father Name

Date of Birth

Community

Category
under which
selected

Address for Communication

DHIVYA.S

SARAVANAN.G

12.03.1994

GENERAL/
UNRESERVED

UR

No.2, Vasantha Nagar,
Bharathiyar Street, 3rd Cross,
Villianur, Pudl!cherry-605110

50456

ARAVINDH.J

JAYAKUMAR.K

16.05.1997 OBC-MIGRANT

UR

3.

71511

SOMA SHEKAR DOKKADI

KRISHNA MURTHY
DOKADI

10.06.1993 MBC-MIGRANT

UR

4.

46286

NATARAJAN .C

CHANDRAMOULI.S

12.07.1997

GENERAL/
UNRESERVED

UR

5.

45401

ARAVIND KUMAR.E

28.06.1995 MBC-MIGRANT

UR

Tvi./Tmt./Selvi

ELUMALAI.K

Region

Department/ Office in which
posted

Puducherry Block
Development
Office,
Oulgaret,
Puducherry
vice
S.K.Gr-III
Tmt.S.Sheela,
resigned
Plot No.2., Yoga Nagar,
Karaikal Govt. General Hospital, Karaikal
Devanoor Salai, Va richikudi,
vice Thiru.R.Asaithamby, S.K:GrKaraikal- 609609
III promot ed
D.No.6-4-196,YSR Nagar,
Yanam
Govt. General Hospital, Yanam
Yanam - 533464
vice
Thiru.Sur.esh
Kam idi,
S.K.Gr-III Promoted
No.3, First Cross,
. Puducherry 0 / o the DIS, Zone-IV, Villianur,
Puducherry
Parasuramapuram, Villianur,
Vtc€
Thiru.
Puducherry- 605110
S.Bratheeb, S.K.Gr-III resianed.
No.7A, School Street,
Puducherry Planning
and
Research
Sundaram Nagar,
Department, Puducherry vice
Thengaithittu,
Th1ru.S.Viswanathan, S.K.Gr-III,
Puducherry-605004
resigned.
No.6, Second Cross Street,
Puducherry 0 / o the La bour Commissioner,!I
SMV Puram West, Villianur,
La bour Department, Puduch.erry:
Puducherry-605110
vice Thiru .S..K.Prawin Pranav, j
S.K.Gr-III, resigned
.
No.3, 2nd Cross Street,
Puducherry Department of Art and Cu lture~ ~
Sabthagirinagar,
Puducherry
v~ce
Pandasozhanallur, Nettapakam
Thiru.E.Mathivanan, S.K.Gr-III, !
I
Post, Puducherry - 605106
[Qreviously_Qosted.
Plot No.85, Sixth Cross,
Puducherry 0 / o
the
Assistant
Aravindar Nagar,
Director(Filaria), Puducherry vice
Murungapakkam,
Thiru .N.Karthikeyan, S.K.Gr-III,
Puducherry-605004
!promoted.
1

I

6.

38311

BENIE AROKE M

MARlYA JOHN
JOSEPH.A

7.

38537

JANARTHANAN. K

KUMAR.S

8.

44909

SARANYA.T

TAMIZHAPPAN.S

GENERAL/
UNRESERVED

UR

18.10.1999 OBC-MIGRANT

UR

MBC-ORIGIN

UR

08.09.1997

16.02.1991

-

<!-- page 4 -->

-: 2 :-

9.

18569

SWASHMA. K

KRISHNAMURTHY.AM

03.04.1992

OBC-ORIGIN

UR

.
10.

11044

ANANDHABASKARAN.N

NAGALINGAM. K

1

I

28.09.1991

sc- As per
Presidential
Order 1964 and

sc

2002
11.

20049

KAMALKARAN .N

NATARAJAN.S

25.07.1997

sc- As per
Presidential
Order 1964 and

sc

2002
12.

16063

RAGUNATH.R

RAMAKRISHNAN. M

01.01.1992
J

sc- As per
Presidential
Order 1964 and

sc

2002

13. 50489

PREETHI.B

BASKARAN.$

06.04.1991
I

GOMATHI.M

sc

No.27, Mukkulam Street,
Kottucherry, Karaikal-609609

EWS

EWS

No.58, Kallarai Street,
Vanarapet,
Puducherry-605001

EWS

EWS

SC- As per
Presidential
Order 1964 and

2002

I

14. 37717

SUBRAMANIA
15.08.1992
SHARMA@ MURUGAN.R

I
15.

53570

SASIDHARAN ALIAS
SHYAMPRASATH .S

SRINIVASAN .P

02.01.1993
I

-

-

No.29, 1st Main Road, Jothi
Puducherry Ojo the Deputy Director(Adult
Nagar, near RTO,
Education),
Puducherry vice
O.K.Palayam, Mudaliarpet,
Thiru.M .Kannadasan, S.K.Gr-III,
'
Puducherry- 605004
resigned
No.3, Mariamman Kovil Street, Puducherry Transport
Department,
Puducherry
vice
Katterikuppam,
Puducherry-605502
Thiru.D.Priyadarshini, S.K.Gr-111,1
resigned
No.7, Mariamman Koil Street, Puducherry Department of Fisheries &
Fishermen Welfare, Puducherry
G.N.Palayam Pet, Villianur,
Puducherry-605110
vice
Thiru. R.Seenuvasan,
S.K.Gr-111, promoted.
No.3, New Street, Seliamedu, Puducherry Department of Civil Supplies and
Bahuor Commune,
Consumer Affairs, Puducherry
Puducherry-607402
vice Thiru .P.Prasath, S.K.Gr-III,
promoted

--

Karaikal

Ojo the Chief Educational
Officer, Karaikal in the existing
vacancy

Puducherry Govt. Agricultural Engineering
Puducherry
vice
Workshop,
Thiru.S.Senthilvelan, S.K.Gr-111,
Ipromoted.
No.10, Agragaram Street,
Karaikal Community
Health
Centre,
Kottucherry, Karaika l - 609609
vice
Thirunallar,
Karaikal
Tmt/Selvi. M.Subashini, S.K.GrIII, resigned.

?'~
(S.UDAYASANKAR)
DIRECTOR

<!-- page 5 -->

810- DATA

PROFORMA

1. Name in BLOCK Letters
2. Name of Father/Husband

3. Date of Birth
4. Sex
5. Date of Joining as Store Keeper Gr-Ill
6. Nationality
7. Whether MBC/OBC/BCM/EBC/EWS/SC/ST
8. Whether XSM/PH/MSP
9. Whether lnservice candidates, if yes,
name of th e post previously he ld
10. Educational Qualification
11. Technical Qualification
12. Pe riod of Probation
13. Other particulars
14. Residential Address

------'- - - - - - - - - · · - - · - - · - - - - ---·- ·-------

SIGNATURE OF THE HEAD OF
DEPARTMENT/OFFICE
WITH SEAL

<!-- page 6 -->

ANNEXURE -I
I, Thiru/Selvi/Tmt.
declare as under:i)

That I am a bachelor/widower

ii)

that I am married and have only one wife living
that I am married to a person who has no other wife living

ii)

that I am married and have more than one wife living
that I am married to a person who has more one wife living

I request that in view of the reasons stated below, I may be granted
exemption from the operation of restriction on the recruitment to service of
persons having more than one wife living, or having married to a person having
more than one wife living.

I solemnly affirm that the above declaration is true and I understand that
in the event of the declaration being found to be incorrect after my
appointment, I shall be liable to be dismissed from service.
REASONS

Signature
Place:
Date:
Note: Please delete clauses not applicable
