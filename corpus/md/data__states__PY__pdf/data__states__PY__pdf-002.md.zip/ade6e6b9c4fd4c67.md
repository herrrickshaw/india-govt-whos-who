---
doc_id: "ade6e6b9c4fd4c67"
source_url: "https://law.py.gov.in/docs/Instructions.pdf"
ministry: "Law Department, Puducherry"
title: "Instructions given to the Law Officers of various Courts for disposal off the court Cases"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "d611d4620ac2a713"
---

<!-- no text layer: pending OCR -->
