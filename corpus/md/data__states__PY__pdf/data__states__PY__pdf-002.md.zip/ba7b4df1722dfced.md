---
doc_id: "ba7b4df1722dfced"
source_url: "https://py.gov.in/sites/default/files/home14102024ld.pdf"
ministry: "Forest and Wild Life Department, Puducherry"
title: "Circular"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "49950b4f0a80de1f"
---

<!-- page 1 -->

E-File No.F-14011 / 1/2024-0/o. HOME-CSECY
GOVERNMENTOFPUDUCHERRY
HOME DEPARTMENT

&&&
Puducherry.dated 14-10-2024
CIRCULAR
Sub: Home - Celebration of Puducherry Liberation
Day on 131 November, 2024 - Hoisting of
National Flag - Reg.

&&&
The Puducherry Liberation Day is celebrated on 151 November, 2024. All the
Government Departments/ Offices/ Institutions/ Organizations in the Union Territory
of Puducherry are advised to hoist the National Flag on 1/ 11 /2024 in their office
premises and celebrate the occasion.
//By Order//

Signe d by
M V Hiran
Date: 14- 10-2024 12:56 : 10
(M.V. HIRAN)
UNDER SECRETARY TO GOVERNMENT
To
All the Heads of Departments/Offices/Institutions/Organizations ,
Puducherry/Karaikai/Mahe/Yanam.
Copy to:
1. The Director of Information and Publicity,
Puducherry.

~he Director of Information Technology,
Puducherry. - with a request to upload the same in the official
websitoof Government of Pudu cherry.

-:...-:.-- .
