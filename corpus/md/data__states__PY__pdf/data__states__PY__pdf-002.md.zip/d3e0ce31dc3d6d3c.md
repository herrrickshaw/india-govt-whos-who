---
doc_id: "d3e0ce31dc3d6d3c"
source_url: "https://dhte.py.gov.in/sites/default/files/358016-sanction-g.o.pdf"
ministry: "Higher and Technical Education Department, Puducherry"
title: "3580 (16)-Sanction G.O"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "de35ef8659263358"
---

<!-- page 1 -->

No.3580(16)/DHTE/T-3/PKFAS/2020-21
GOVERNMENT OF PUDUCHERRY
DIRECTORATE OF HIGHER & TECHNICAL EDUCATION
*****
Puducherry,
dt 09.03.2021
ORDER
Sub: DH&TE - Award of Perunthalaivar Kamarajar Financial Assistance
(Fresh) for the year 2018-19 to the students of I Year B.Tech
sponsored through CENTAC in private Engineering Colleges in the
UT of Puducherry - Expenditure sanction with advance drawal for
Rs.50,000/- - Accorded.
Ref: G.O.Rt.No.094 dt. 10.02.2021 of the Chief. Sectt. (H&T Edn.),
Puducherry.
******
In pursuance of the II Block Sanction issued by the Under Secretary to Govt.
(H&T Education) vide reference cited, sanction of the Director of Higher and Technical
Education is hereby accorded to incur an expenditure not exceeding Rs. 50,000/- (Rupees
Fifty Thousand Only) towards the award of Perunthalaivar Kamarajar Financial Assistance
(Fresh for 2018-19 Batch Students) for the year 2018-19 to 2 students of I Year B.Tech,
sponsored through CENTAC in Private Engineering Colleges in the U.T. of Puducherry as
detailed in the Annexure to this Order.
2. The entire amount sanctioned vide para 1 above shall be drawn in advance in full,
subject to rendering of accounts to the Directorate of Accounts and Treasuries, Puducherry,
within one month from the date of drawal of advance as per Rules.
3. This Order is issued subject to the fulfilment of eligibility of students as per the
Rules and Regulations stipulated in G.O.Ms. No. 129 dt.17.10.2003, and subsequent
amendments issued vide G.O.Ms. No.97 dt.27.09.2004, G.O.Ms. No.67 dt.08.06.2005,
G.O.Ms No.84 dt. 08.07.2005, G.O.Ms No. 73 dt. 15.07.2006, G.O.Ms No.142 dt. 07.12.2006
G.O.Ms.No.83 dt. 03.08.2009 of Education Secretariat. The disbursement of Financial
Assistance shall be drawn by the Directorate of Accounts and Treasuries, Puducherry and
paid to the Institutions concerned as per G.O.Ms.No.57 dt.01.10.2013.
4. The expenditure is debitable to the following Head of Account in the budget of the
current financial year.
Head of Account

Amount Rs.

“2202 – GENERAL Education – 03/107 (06) Financial Assistance
to the students undergoing professional courses – 03/107(06)(07)
All regions (34) – Scholarships & Stipends”

50,000/-

(Rupees Fifty Thousand Only)
//BY ORDER//

(SUNDARARAJAN. P)
OFFICER ON SPECIAL DUTY

To
The Drawing and Disbursing Officer, DH&TE, Puducherry.

Copy to:1. Finance Department, Puducherry. 2. The Joint. Secretary to Govt. (Edn.), Puducherry.
3. The Director of Accounts & Treasuries, Puducherry, 4. The Senior Dy. Accountant
General ( Civil Audit ), Puducherry, 5. The Head of Institutions concerned, 6. The C.R.B.,
Puducherry, 7. Bill section/Cashier, 8. Order File/spare.
