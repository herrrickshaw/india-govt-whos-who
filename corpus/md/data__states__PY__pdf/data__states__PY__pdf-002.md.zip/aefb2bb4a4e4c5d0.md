---
doc_id: "aefb2bb4a4e4c5d0"
source_url: "https://exciseportal.py.gov.in/puduvaicalal1/pdf/ActAndRules/ED_Revision_07022019.pdf"
ministry: "Puduvaicalal, Puducherry"
title: "Gazette No.7, dated 07.02.2019"
date: ""
pages: 1
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "2d495efb94445f48"
---

<!-- page 1 -->

| Registered with the Registrar io Registered No. ‘ETA!
| of Newspapers for India Gare 66 L.A GAZETTE DE ப்பம்‌ [ணப
| ட்ட ப்பி (2 WPP Ni rec RG er ’
ப்ரி ௦. Rag
if |! WPP-88/2018-20 AMENDMENT
ay படட அடதப்‌ (i) In the schedule appended to the said notification, for the
7 என்ன்‌ ண்‌ = 108 entries under column (3) against serial number 1, the following words ர
பு து ச டூ ச ரி மா ர ல மி ர கி & ழ்‌ and figures shall be substituted, namely:—
"(a) Cheap brands and ordinary brands .. ₹ 93.00
| La Gazette de L' Etat de Poudouchéry whose declared price per case is
The Gazette of Puducherry less than = 600.
PART - II (௫) Medium and premium அன்னான்‌ .. ₹ 110.00"
ப்‌ ்‌ ase is
Amity QarefuiG EXTRAORDINAIRE EXTRAORDINARY rma Seats
அதிகாரம்‌ பெற்ற. Publiée par Published by
வெளியீடு Autorité Authority (By order of the Lieutenant-Governor)
விலை : ₹ 1-00 Prix : = 1-00 Price : ₹ 1-00 J. DAYALANE,
aa eee Se வட்ட ரவு Under Secretary to Government (Revenue).
எண்‌? முறுச்சசர்‌ வியாழக்கிழமை 2019 GF ஈட்றவரி மீ 7 0
No. > 7 Poudouchéry Jeudi ர. Février 2019
No. Puducherry Thursday 7th February 2019 hin
(18 Magha 1940)
GOVERNMENT OF PUDUCHERRY
DEPARTMENT OF REVENUE AND DISASTER MANAGEMENT
No. 1728/DCE/S1/2018.
Puducherry, the 7th February, 2019.
NOTIFICATION
In exercise of the powers conferred by section 21 of the
Puducherry Excise Act, 1970 (No. 12 of 1970), the Lieutenant-Governor,
Puducherry, hereby makes the following further to amend the Revenue
Department's Notification issued under 5.0. No. 24, dated Sth July 1974 1
(hereinafter referred to as the said notification) and published in the ்‌ பந்தன அரிவி்தக் க வ நரச தங்கள்‌! SHON டக றக நபி வா
Extraordinary Gazette No. 83, dated Sth July 1974, as amended from SAPO ABUE teeth debate Chola orea5
time to smednesiely, Printed at: Government Central Press, Puducherry.
ட்ப்ப்ப Posted at: Puducherry HPO on every Tuesday
