---
doc_id: "5cedf123bb77dac6"
source_url: "https://exciseportal.py.gov.in/puduvaicalal1/pdf/camera-cicular.pdf"
ministry: "Puduvaicalal, Puducherry"
title: "Circular for Maintenance and functioning of CCTV/IP Cameras in all licensed premises"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0d247cc787f2ffbd"
---

<!-- page 1 -->

M/6970/2025-O/o TAHSILDAR-SQUAD-DCE

I/31326/2026

GOVERNMENT OF PUDUCHERRY
OFFICE OF THE DEPUTY COMMISSIONER (EXCISE)
PUDUCHERRY
No. M/6970/2026

Puducherry, dated22-01-2026
CIRCULAR

Sub: Excise – Maintenance and functioning of CCTV/IP Cameras in
all licensed premises – Instructions to Distilleries / FL-1 / FL-2 / FL-2
(Tourism Category) / Arrack and Toddy Shop Licensees – Issued –
Reg.
It has been observed during routine inspections and monitoring that the
CCTV/IP camera systems installed in certain licensed premises are not functioning
properly or have not been maintained as per the directions of this office. The failure
to ensure proper functioning of CCTV systems adversely affects the transparency
and monitoring of business activities.
2.
All the licensees of Distilleries, FL-1, FL-2, FL-2 (Tourism Category), and
the lessees of Arrack, Toddy Shop are hereby directed to ensure that CCTV/IP
cameras installed in their licensed premises and godowns are kept in continuous
working condition showing real time, with adequate storage capacity for recording
and retrieval of data whenever required by this office. All licensees shall also
ensure that their CCTV systems have the facility to share live video feed with this
office on or before 28.01.2026 so that real-time monitoring of their premises can be
carried out whenever necessary. The live feed link or access shall be provided to
this office and kept updated at all times.
3.
Any malfunction, technical issue, or interruption in the operation of CCTV
systems shall be immediately reported to this office in writing, along with details of
the remedial action taken. Periodic maintenance of the systems shall be carried out
by the licensees to ensure uninterrupted operation and monitoring.
4.
Non-compliance with the above instructions will be viewed seriously, and
appropriate action will be initiated under Section 28(b) of the Puducherry Excise
Act, 1970, which may result in suspension or cancellation of the license.

DEPUTY COMMISSIONER (EXCISE)
Copy to:
All Distilleries / FL-1 / FL-2 / FL-2 (Tourism Category) / Arrack and Toddy Shop
Licensees – for strict compliance.
Copy Submitted to:
The Secretary (Excise), Puducherry
