---
doc_id: "52de1c1cd5ce5fa3"
source_url: "https://ppclgov.in/admin/dynamic/tender/W8ZV.pdf"
ministry: "Puducherry Power Corporation Limited (PPCL), Puducherry"
title: "AC-032 Inviting offer for the replacement of Existing Sheds for both Boiler feed Pump Motors I&II-Reg.   [ Notice Board ]"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "da3a4f5cb959062b"
---

<!-- page 1 -->

\

_/

ffidtpuDUCHERRypowERCoRpoRArroN LrMrrED @"

(A GOVERNMENT OF PUDUCHERRY UNDERTAKING)
PROIECT OFFICE, T.R. PATTINAM 609 606, KARAIKAL.
Phone:04368Email:nnclm
Ref.No.AC-032lMMC 12025-26/ t
p1.
G STIN No. 34AAA CP 6507812,5
f3 .\0.202s
EN

To

Subl Inviting offer for the replacement of Existing Sheds for both Boiier feed pump
MotorI&II-Reg.
Ref: 1.our Enquiry ref no: AC-o32lMMCl2o2s-261914 Date: 14.oB.2o2s.
2 . Our Enquiry-DDE ref no: AC-O32 I MMC 2025-26 7046 Date: 04 .Og .2025 .
I
I
3. Our Enquiry-DDE ref no: AC-O32/MMC 12025-261 1126 Date: 22.09.2025.
UOTATION TO BE:
Submitted on or before: - 15.LO.2O25 - S pm

Opened on: 16.1O.2O25- 3 pm

Kept valid for 3 months from the date of opening Submitted in ONE part.
Sealed quotation is invited for the replacement of Existing Sheds for both Boiler feed
pump Motor I & II as per the enclosed scope of work and the terms & conditions are
mentioned therein.

General Terms and conditions:

1. The rate quoted should be inclusive of provid,ing manpower, material, transport
charges, tools and tackles, etc. required for the works, GST/ESI/EPF all taxes and
other charges as admissible.

2. Applicable other charges, if any shouid be clearly mentioned. If not mentioned. it will
be presumed that the rate quoted is inclusive of all other charges.

3. The L1 rate shall be selected by considering the lowest of total offered value.
4. The work should be carried out in PPCL site, T.R.Pattinam, Karaikat 609 606. As per
the scope of the work are enclosed.
5. No Workshop facility is available inside PPCL campus and outside private workshops to
be utilized by the party concerned at their own cost.

6. Exact date for commencement of work will be intimated appropriately and the work has
to be completed as per the directions of the Engineer-in-charge.

7. Necessary Gate pass should be obtained well before the commencement of work.
8. The party should ensure round the ciock progress of work at site and should follow all
safety rules and procedures strictly inside the plant.

9. In case of any faulty workmanship in the scope of work, the tenderer must rectifv the
same on free of Cost.

10. PAYMENT: 8O% Payment *i1t Ue made within 30 days from the date of receipt of your
invoice after completion of woik satisfactorily and approval of Engineer-in-charge and
the balance COo/o Payment will be made after submission of ESI / EpF etc. documents.
1 1. The bill in triplicate along with advance stamped receipt should
be sent to the
undersigned for effecting payment.
Page I of 3

<!-- page 2 -->

(

A G ov E RN MENr o F IueygYT TT]
^"J::
606, KARAIKAL.
dilicE; r.R. pArrrNAM 60e

YIYT:J

pRort;i

Phone: 04368-233050 Emqil:ppclmmc-@gpa4'com
Ref.No.AC -ozz

m@N

'Folof qw'

No.34AAAcP6507E\zs

Dt.f3.10.2025

ENQUIBILIAGE--2

EPF in separate code number other than
&
ESI
for
payments
make
shall
L2. The bidder
ppcl. code. If the party fails to arrange the
ppc,. code. No permission shall be given for
ESIi EPF Code, the contract will be cancelled
submission of the foilowing :
Zl%oPayment will be made only after

13. TrIe
c For EPF:

the specific month for the manpower
To be generated from the, trpF we6site for
deployedtoPPCLandthesametobeenclosedseparatelywithacoveringletter.

i.Combinedchallanofaccountno.oI,02,Io,2|&22withTRRNnumber.

ii. EPF-Electronic Challan cum Return'(ECR)
iii. EPF Challan summery/EPF-TRRN details'
o For ESI:

To be generated from the ESI website for

the specific month for the manpower

enclosed separately with a covering letter'
deployed to PPCL and the same to be
i. ESI challan number
(Transaction details)
ii. ESI monthly contribution -online challan status

iii.Eslmonthlycontribution(Contractorwise)forthemonthof.....
the laws or regulations applicable
party
should obtain all permits and licenses under
L4.
shall compiy with and discharge all
and
out
carried
work
the
with
and in connection
various laws such as Factory Act/workmen's
statutory obrigations/liabilities under the
Act / Employee's Provident Fund Act /
compensation Act /Employee's state Insurance

PaymentofWagesAct/ContractLabour(Regulation&Abolition)Act/Minimum
Wages Act Etc., o' aty modification thereof'

No' Ac'o32

as "euorATroN/ENQurRy
1s. sealed quotations should be superscripted
to be
both Bo'er feed pump Motors I & II" and

for the repiacement of Existing Sheds for
puducherry Power corporation Limitedo
sent to The Executive nngiieer (Mech.|,
T.R.Pattinam, Karaikal-6096O6'

16.ourTaxpaymentIdentificationGSTINNo.34AAACP6SoTElzsisregisteredwith
giaa.t should furnish their GST details'
Department, puducherry.

commercial Taxes
any or all the quotations without
accept
to
lreject
rights
all
reserves
17. The undersigned
. assigning any reasons thereof'
of work is not permitted'
1g. The work order is not transferable and. subcontract/sublet referenee cited' aboae'
eartier for the enquiry
lg. If alreadg submitted- the offer
pulse marcZ a note of the dui date extension'

@.r*d

fta[zed

Page2 of

'.

<!-- page 3 -->

PUDUCHERRY P'WER C.RP'RATI'N LIMITED

W

(A GOVERNMENT OF PUDUCHERRY UNDERTAKING)
PROIECT OFFICE, T.R. PATTINAM 609 606, KARAIKAL.

Phone:04368-233060 Email:ppclmmc@gmail.com
Ref.No.AC-03 2/MMC I 2025 -26 I oeS+ G STIN No. 34AAA CP 6507ELZS

Telefax 04368-233355
Dt.I>]0.2025

ENOUIRY PAGE - 3

Charges for the replacement of Existing Sheds for
both Boiler feed pump Motors I & II as per the
enclosed scope of work (Inclusive of Manpower,
Material, Tools, transport, TA-'DA and ESI/EPF)
Sub Total Amount {Rs.}
GST @ o/o for Works
Total Amount (Rs.l
SCOPE OF WORK FOR PROVIDING SHEDS FOR BFP MOTOR
1. Removal of existing damaged shed and shifting to PPCL scrap yard.
2. Supply of required2" inch GI pipe, 1.5 X 1.5 square tube, GI sheets, consumables.
. 3. Necessary fabrication of frame work for shed which includes necessary cutting,
welding and fixing in position.
4. The contractor should deploy essential manpower and should complete the work in
single sitting.
5. Necessary welding machine, cutting set, cutting machine, other tools &amp; tackles.
Consumables, paints and safet5r equipments are under contractor's scope.
6. The sheds to be provided is to have wheel arrangements so that it can be moved
during maintenance works.
7. Applying one coat of metal primer and two coat of smoke grey paint.
8. After completion the contactor should make the place neat and cleaning etc. as
directed by the Engineer-in-charge.
9. The party may visit the site before submitting the offer.
c omme rcial Terms and
Terms
sl.
Details
Terms
in
Enquiry
Accepted
by
No

Inclusive of manpower, Materiai,
Price Quoted

transport charges, GST and ESI/EPF
applicable taxes and other charges.
B0% Payment within 3Odays after work
completion and balance 2Ooh after
submission of ESI & EPF documents

2

Payment Terms

-o

Validity

4

Delivery/ Completion
To be cornpleted as per the directions of
Period
the Eneineer-in-charse.
Acceptance of All the
. ,i;
Terms and Condition To be Accepted
of the Enquirv

5

the Party

90 Days from date of opening

Signature with Seal of the Party
Page 3 of 3
