---
doc_id: "e281fe2fcce2b2a4"
source_url: "https://schooledn.py.gov.in/notification/2018/RRHM2.pdf"
ministry: "District Institute of Education and Training (DIET), Puducherry"
title: "Amendment in the Recruitment Rules for the post of Headmaster Grade-II/ Headmistress Grade-II/ Deputy Inspector of Schools in the Dte. of School Education, Puducherry - Comments of Stakeholders - Called for"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1eb3aea0fa885d37"
---

<!-- page 1 -->

N O.4'l /DS E/SW/Estt./E.1 /2o1 8-19

GOVERNMENT OF PUDUCHERRY
DIRECTORATE OF SCHOOT EDUCATION
SECRETARIAT WING

Puducherry,dr.

24 0cT 20lB

CIRCU[AR
Sub: DSE- SW- Amendment in the Recruilmenl Rules for the
posl
Heodmosler Grode-ll /Heodmlstress Grode-ll / Deputy
Inspeclor of Schools of lhe Directorote of School Educolion, Puducherry'
Commenls of Slokeholdets-Colled for.

of

The Directorote of School Educotion, Puducherry proposes to revise the
Recruitment Rules for the post of Heodmqsler Grode-ll / Heodmislress Grqde-ll /
Depuly Inspeclor of Schools by omending the existing Recruitment Rules,l9Z7.

ln terms of O.M.No.AB-I 401 /61 /2O08-Estt(RR) doted I 3-10-201 5 of the
Depqrtment of Personnel & Troining, Government of Indio, New Delhi, the proposed
schedule for the post of Heodmoster Grode-ll / Heqdmistress Grode-ll / Deputy
lnspector of Schools is uplooded in the officiol website of the Directorote of
7

School Educotion for comments of the stokeholders.

The comments moy kindly be sent to the undersigned lotest by 26-11'2018
ond sofi copy of the some comments moy olso be sent through e-moil to

secttl-edn.pon@nic. in.

\.

- Encl: os obove.

.,.?

XYh.-hs\*
tp.tsorNrarb'
UNDER SECRETARY TO GOVT.
(scHool EDUCATION) ._

To

All concerned Stokeholders
Copy to

l. The Director,

Direciorote of School Educotion,
Puducherry.

'' EDP Section,
i2llhe

Directorote of School Educotion,
Puducherry.

- With the request to uPload the
above circular along with proposed

schedule for the Post of
Headmaster Grade-l| / Headmistress
Grade-ll / DeputY InsPector of
Schools.

<!-- page 2 -->

Nome of the Post

Heodmoster Grode-ll/
Heodmistress Grode-ll /
Deputy Inspector of Schools

Number of posts

l78 (one hundred ond seventyEigrhtl-pO18;Subject to voriotion depending ufon worklood.

Clossiflcotion of the posf

Generol Centrolservices Croup g
Non-Gozetied. Non-Ministeriol

level in the Poy Mqlrix

Age limit for Direct recruits

(Reloxoble for Government servonts upto
5 yeors in
occordonce with the instructions or orders issued
ov- il u
Centrolgovernment
)

Note: The crucial date for determining the age-rimit
be !h: closing date,foy receipt of" apphZario,rr' shalr
7ro*
candidates in India (and not tie crosin[
datu lirriitra
for those in Assam, Meghalaya, Arunachal pradesh, Mizoram,
(anipur, Nagaland, Tripura, Sikkim, Ladakh Division
Jammu and Kashmir state, Lahaur and spiti Dist,ict oJ
and
Pangi sub-Division of chamba District of
Himachar
Pradesh, Andaman and Nicobar Islands
or Laishadr;;

Educotionol ond othei
quolificotions required for

direct recruits

A. Educotionol quotificotion i
l. Moster's Degree from o recognized University.
2. !.!O or Degree in Teoching / Educotion from o recognized
University.

3.

Should hove studied the. porticulor

regionol
longuoge (Tomir /Terugv/ Moroyorom os
one of the sJolect
)
in fhe Secondory level.

B. Experience:Two yeors teoching experience in hondring

secondory levelin o recognized School.

crosses in

<!-- page 3 -->

-2-

8.

Whether oge

ond

educotionol quolificofions

Age

: No

Educollonol quollflcollon: Yes

prescribed for direct recruits

will opply in the cose of
9.

promolees
Period of probolion, lf ony

yeors for direct recruits
NOTE: The Direct Recruits should undergo induction

Progromme "One rnonfh Certificote course on
School leodershp ond Monogement", before
completion of their probotion period.

lo. Method of

recruitmenl,

whether by direct
recruilmeni or by promotlon
or by depuiotion or by
obsorplion ond percenloge
of the voconcies to be

filled by vorious melhods

il

In cose of recruilment by
promolion/d eputotion/obso
rplion, grodes from which
promolion/ deputotion
/obsorplion is lo be mode

50% by promotion foiling which by direct recruitment;
25% bV promotion through Limited Deportmentol Competitive
Exominotion foiling which by promofion.
25% by Direct Recruitment foiling which by deputotion (ISTC)
PROMOTION:In the rotio of 9:3:l of (o), (b) ond (c) below:-

(o) From the grode of Troined Groduote Teocher (Subjech)
with 2 yeors' regulor services in the grode;
(b) From the grode of Troined Groduote Teocher (Longuoges)
with 2 yeors' regulor services in the grode;
(c) From the grode of Heodmoster / Heodmistress of Primory
Schools wifh 2 yeors' regulor service in the grode;
ond
successfully complefed in-service lroining progromme on
School leodership Developmenl for o period of nol less
lhon l6 doys.

Note-l: Only those who opted promotion to the post of

/

/

Heodmosfer Gr.ll Heodmistress Gr.ll Deputy Inspecfor of
Schools will be considered for promotion.

Note-2: Educotionol quolificotion sholl continue to be some
for the persons holding the feeder grode posts on regulor bosis
on the dote of notificolion of the Revised Rules.
Nole-3: Where juniors who hove completed their quolifying/
eligibility service ore being considered for promotion, their
seniors would olso be considered, provided they ore not
short of the requisite quolifying /eligibility service by more thon
holf of such quolifying / eligibility service or two yeors
whichever is less, ond hove successfully completed their
probofion period for promotion to the next higher grode olong

wilh their juniors who hove olreody completed such
quolifying/eligibility service.

<!-- page 4 -->

-3-

Deputolion (lncluding Shorl Term Confrocl):Officers of fhe Centrol Governmenf, Stote Government, Union
Tenitories, Autonomous or Stotutory Orgonizotiorypublic Sector
Undertokings, University or Recognized Reseorch Institution'

o) (i) Holding onologous posts on o regulor bosis in the
porent codre or deportmenf ; or
(ii) with 2 yeors service rendered ofter oppoinlment to
the post on o regulor bosis in Level:Z in the poy Motrix
or equivolent in the porent codre or Deportment;
ond

(b) Possessing the quolificotions ond experience prescribed
for direct recruits in column No. Z

Nofe: The Deportmentol officers in lhe Feeder cotegory in
Level:7 in fhe Poy Motrix with 2 yeors of regulor service in
the grode ond hoving the educotionol quolificofions ond

experience prescribed for considering oppointment on
depufofion bosis is considered olong wilh outsiders. lf the
deportmentol condidote is selecfed for oppointmenf to the
post; if sholl be treofed os hoving been filled by promotion.
(Period of deputotion including the period of depufotion
in onother ex-codre post held immediotely preceding this
oppointment in the some or some other orgonizotion or
deporfments
Centrol/ Stote
Union Territory
Governmenl sholl ordinorily not exceed three yeors. The

of the

/

moximum oge limit for oppoinlment by deputotion shollbe
"not exceeding 56 yeors" on the closing dote of receipt of
opplicotions).
tz.

lf q Deporlmenlol Promotlon

Commltlee exlsls, whol ls lts
composlllon?

Group 'B' Deportmenlol Promolion Commlttee (for Considering
Promotion):-

- Choirmon
- Member
- Member

l. Chief Secretory to Governmenl
2. Secrefory to Govt. (Educotion)
3. Director of School Educotion

Group 'B' Deporlmentol Confirmotion Committee
Considering Confirmolion)
l. Chief Secretory to Governmenf
2. Secretory to Govt. (Educotion)
3. Director of School Educotion
l?

Clrcumslonces under whlch

Unlon Publlc

Servlce

commlsslon ls lo be consulled
ln moklnq recrultmenl

(for

- Choirmon

- Member
- Member

Consultotion with Union Public Service Commission is necessory
while oppoinling on officer on deputotion (ISTC).

\-art

VV. ^ctn\\L

0*NA*,'

(P. EJOUIPVIALE)

UNDER SECRETARY TO GOVT.

(scHoor EDUCATIO*'

:,L
