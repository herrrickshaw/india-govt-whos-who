---
doc_id: "6f83dddb16bca80a"
source_url: "https://ppclgov.in/admin/dynamic/tender/8FR3.pdf"
ministry: "Puducherry Power Corporation Limited (PPCL), Puducherry"
title: "G-125 inviting offer for the Aluminium maintenance work in various buildings inside the PPCL campus at T.R.Pattinam, Karaikal.   [ Notice Board ]"
date: ""
pages: 5
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "9c73229440442ba6"
---

<!-- page 1 -->

\
. 1
| IPUDUCHERRY POWER CORPORATION மருபடி ணை
(A GOVERNMENT OF PUDUCHERRY UNDERTAKING)
PROJECT OFFICE, T.R. PATTINAM 609 606, KARAIKAL.
No. G-125/PPCL/EE(M)/AE(Civil)/ QN/2026-27/6 be Date: .09.2026
QUOTATION NOTICE

Sealed quotations are invited for the work of “Aluminium maintenance work in
various buildings inside the PPCL campus at T.R.Pattinam, Karaikal” by the under
signed from the Contractor and will be received upto 3.30 P.M 5/10/2026 and will be
opened at 4.00 P.M on 6/10/2026.
Eligibility criteria:
The contractor/firm should submit

i) the copy of GST registration certificate

ii) the documentary evidence in support of their ESI & EPF Code,
Quotations should be in a sealed cover, duly super-scribed as the
“Aluminium maintenance work in various buildings inside the PPCL campus at
T.R.Pattinam, Karaikal”
The contractors shall submit the Tender Schedule in Two envelops sealed in
a single cover. The first envelope shall be placed with definite proof for
independent code number for ESI&EPF&GST certificate, and the
envelope shall be super-scribed as “pre- qualification documents” and the
other envelope shall be super scribed as price Schedule wherein the duly
filled schedule shall be placed and sealed.
On the scheduled date of opening, the cover super-scribing “pre-
qualification documents” definite proof for independent code number
for ESI&EPF&GST” shall be opened. At the time of opening of the
Quotation if any contractor fails to furnish related shortfall documents
necessary time frame of one week will be given to the tenderers, to furnish
the documents, with a condition that, the documents must be to the pre-
existed and not the post - existed, failing which their Quotation will be
rejected.

<!-- page 2 -->

afer Beupucu ERRY POWER CORPORATION LIMITED- 7 ச்‌ டு
(A GOVERNMENT OF PUDUCHERRY UNDERTAKING) ம்‌
PROJECT OFFICE, T.R. PATTINAM 609 606, KARAIKAL.
No, G-125/PPC -L/EE(M)/ AE (Civil) /QN/2026-27/_ Cates 09.20 we
‘Terms & Conditions:- ட்‌
Quotations should be in a sealed cover, duly super-scribed as the “Aluminium maintenance work 2
in various buildings inside the PPCL campus at T.R.Pattinam, Karaikal”
1. The decision of the Engineer in charge shall be final and binding on the successful
quotationer, ப
2. The quotation shall remain valid for a period of Ninety (90) days from the date of ன்‌
Opening for acceptance. :
உ If the date of opening of the quotation becomes holiday, then the same will be opened ்‌
on the next working day,
4. The quantity mentioned in the schedule is tentative, and duration of contract will be
one (1) year.
5. The above mentioned work will be carried out by engaging labourers and the tenderer
shall quote his rates per labour basis in the quotation notice.
6. Whenever the Corporation requires manpower, the contractor shall supply manpower
within 24 hours from the intimation given by the Corporation officials and in case of
emergency the contractor is bound to supply the Man power immediately as required
by the corporation.
7. Incase the contractor fails to supply manpower on any occasion, penalty as decided by |
the Engineer-in-charge shall be levied. However such penalty shall not exceed |
Rs.1000/- per occasion.
8. The rate quoted shall be firm and binding and shall be valid for a period of One (1)
year and no increase whatsoever nature shall be considered during the contractual
period.
9. The contractor shall furnish the list of persons to be deployed by him. He shall not
engage persons below 18 years of age.
10. If the services of the contractor are found to be unsatisfactory during the stipulated
contract period and for any other reasons, Engineer ~ in - charge reserves the Tight to
pre-close the contract without assigning any reasons, whatsoever, However, the
contract would be terminated by giving one - month notice
11. While quoting the rates for the services to be rendered by him, the contractor shall take
into consideration all statutory obligations.
12. If any of the personnel employed by the contractor is found to indulge in acts,
subversive of discipline, the same will be brought to the knowledge of the contractor
and he shall arrange for replacement of such personnel.
13. The rate to be quoted shall include all incidental expenses/ESI and EPF Act, Margin of
profit etc.,
14. The company will not provide any transport /canteen facilities to the workers to be
employed by the contractor and the contractor shall make necessary arrangements in
this regard at his own cost.
15. The contractor is informed to inspect the site conditions before quoting his rates.
16. The contractor is liable for damages, during contract period.
17. Tools & Tackles to carry out the work shall be supplied by the contractor only.
18. Any damage that would be occurred to the property of PPCL during execution of the
work, the contractor has to rectify the same at his own cost.

<!-- page 3 -->

ஆத 19. Without prejudice to any of the tights or remedies under this contract if the contractor
ie is not able to execute the works due to unavoidable genuine reasons and beyond his
Py control the Executive Engineer (mech) on behalf of the PPCL shall have the option of
a Due ae ay லன்‌ without compensation to the contia-ctor. . 5
‘se of contract period, deduction of “CESS” to provide social
security and various welfare benefits through the Puducherry Buildings and other
construction workers Welfare Board under Section 18 of the Building and Other
Construction Workers Cess collection (RECS) Act, 1996, shall be made at the rate
of 1% (One Percent) of the gross amount of each bill or as per the advice of the
Government of Puducherry.
| 21. The contractor has to sign the documents of terms and condition of the quotation
| notice for acceptance
| 22. The undersigned reserves the right to accept /reject any or all the quotations without
| assigning any reasons thereof.
Special Conditions:

ம. All work is covered under Puducherry Goods and Services Act 2017 and hence the contractors
are requested to quote the rates including the effect of GST. Additional/ separate claim for any
recovery on GST will NOT be entertained on any account after the award of work. The
payment is also liable for TDS as instructed by the Commercial Tax Department based on
GST.

2. “The Contractor /Service provider shall mandatorily furnish the following documents to the
Commissioner, Commercial Tax:

i. Copy of the work order.
ய்‌. HSN! Code of Goods and Service Accounts code of Services which shall be supplied
during the execution of the Contract.
iii, GST Rate at which the GST would be paid to the commercial Tax Department against
each of the items in (ii) above.

3. The information shall be submitted to the Commissioner, Commercial Tax , with a copy to the

Procuring/ Government Entity, within 15 calendar days of receipt of the Work Order.”
Terms & conditions with respect to ESI & EPF and Payment.

i This work is covered under ESI & EPF Act, and it is responsibility of the
contractor to ensure compliance of ESI and EPF norms. Hence the contractors are
requested to quote the rates including the effect of ESI & ஹா,
Additional/Separate claim for ESI & EPF will not be entertained on any account
after the award of work.

2 The contractor shall make payments for ESI & EPF in separate code number other
than PPCL code. No permission shall be given for PPCL code.

3. PAYMENT:

(i) 100 % Payment for the completed work will be made within 30 days for the
final bill after submission of ESI&EPF etc. documents.

4. Payment will be made only after submission of the following.

௪ For EPF:
To be generated from the EPF website for the specific month for the manpower
deployed to PPCL and the same to be enclosed separately with a covering letter.

<!-- page 4 -->

i Combined challan of account no.01, 02, 10, 21 & 22 with TRRN number, ட்‌ ‘|
ii, EPK ~ Electronic challan cum Return (ECR),
iii, 119/7 Challan summery / EPL 'TIRN details.
. For ESI:
To be generated from the ESI websile for the specific month for the manpower
deployed to PPCL, and the same to be enclosed with a covering letter,
i, ESI-challan number
ii. EST monthly contribution - online challan status (Transaction details)
iii, EST monthly contribution (Contractor wise) for the month ௦...

5. Party should obtain all permits and licenses under the laws or regulations
applicable and in connection with the work carried out and shall comply with and
discharge all statutory obligations/ liabilities under the various laws such as
Factory Act/Workmen’s Compensation Act/ Fmployee’s State Insurance Act/
Employee's Provident Fund Act / Payment of Wages Act/Contract labour
(Regulation &Abolition) Act/ Minimum Wages Act ete., or any modification
thereof, ப்‌

ண a
EXECUTIVE ENGINEER Mech) Plant
To, The Notice Board,
Copy to:
1. The Regional Publicity Officer, Karaikal, }
2. The Executive Engineer (1 &PH), PWD, Karaikal.
3. The Executive Engineer, Karaikal Municipality, Karaikal. With a request to display
4. The Commissioner, T.R. Pattinam, in the Notice Board
T.R. Pattinam Commune Panchayat Office,

<!-- page 5 -->

டட. ச

4 IPUDUCHERRY POWER CORPORATION நாநா ல்‌

if (A GOVERNMENT OF PUDUCHERRY UNDERTAKING)

| PROJECT OFFICE, T.R. PATTINAM 609 606, KARAIKAL.

No. G-125/PPCL/EE(M)/AE(Civil IN / 2026-27, Date: _.09.2026
Price Schedule
Name of work: Aluminium maintenance work in various buildings inside the
PPCL campus at T.R.Pattinam, Karaikal
No | Description of items 1 ane ' ட ள்‌ 1 ழம்‌ ள்‌
ந 1” | Aluminium maintenance work, repair works ! t i 1
1 t ம்‌ : ்‌ 1 1 '
1 1 of aluminium doors & windows, cleaning of | 1 ' !
1
| H glass doors & windows etc. complete as 7 1 ; i
1 ॥ ॥
1 directed by the Engineer-in-charge. ம ட i :
1 ॥ 1 1 1 1
A 1 Aluminium Fabricator Class - I ்‌ 50 i ட்‌ t
' 1 1 1 1 1
1 1 ॥ ॥
1 1 Aluminium Fabricator Class ~ II te ee 1 1
1 ॥ ] i '
H ட்‌ | | i ॥
பத உலக ie ns அலல கக்க தன எ ட ர த கனா த
| i GST @18% | 1 ' 1
நார அதரம்‌ ல aoe வைல toe வல்லவ ல லல அலல்‌ பற்பல அல்ல ல eet
: | Total | [ ' |
நமம ல்க nae ee ee மம்ம பிப பப்பி இண்ட பற்பம்‌ ee அப்ல மடம்‌
ட்டா டல
EXECUTIVE ENGINEER (Mech) Plant
i
