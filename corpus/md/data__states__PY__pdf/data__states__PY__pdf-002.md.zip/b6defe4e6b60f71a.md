---
doc_id: "b6defe4e6b60f71a"
source_url: "https://gstchennai.gov.in/images/pdf/sports-quota-orders/cca%20estt%20order%20116%20dt%2015.11.2021.PDF"
ministry: "Office of the Principal Chief Commissioner of GST & Central Excise Tamil Nadu & Puducherry Zone, Puducherry"
title: "Click here for Details"
date: ""
pages: 2
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "f55d699331e23137"
---

<!-- page 1 -->

|
NATION ஆ Phone No. 28335030/28335020
eng 12 (@:) Fax No. 044-28333050/1015
| A MARKET >, /
: al Email :cou-cexchn@nic.in
: GOVERNMENT OF INDIA
MINISTRY OF FINANCE, DEPARTMENT OF REVENUE
OFFICE OF THE PRINCIPAL CHIEF COMMISSIONER OF
| GST & CENTRAL EXCISE,
| TAMIL NADU & PUDUCHERRY
| No.26/1, MAHATHMA GANDHI ROAD, CHENNAI - 600 034.
| C. No. 11/39/154/2021- CCA- Estt Dated: 15.11.2021
| ORDER No. 116 / 2021
Sub:- Sports Quota recruitment for the year 2021- Constitution of
Committee for recruitment process - Reg. ~
sabe
In connection with Sports Quota Recruitment for the year 2021, the
| Recruitment Committee, comprising of the following officers is hercby constituted:-
| SPORTS QUOTA RECRUITMENT COMMITTEE
| SL Designation Name of the Officers
i No. $/Shri
| 1. Chairman T.G.Venkatesan, ADC, Pr CCO
2. Members 13. Jayabalasundari, 4130, North Comm’te
: 3. D. Lakshmikantha, ADC, Outer Comm’te
: 4, 1). Jayapriya, JC, South Comm’te
5, 13.0. Srinivas, JC, Chennai Customs
H 6. Rajini Menon, AC, Pr.CCO
i ர்‌. P. Paul Sudhakar, Supdt, Pr.CCO
| DUTIES AND RESPONSIBILITIES OF THE COMMITTEE
: ம, This Committee may identify the number of vacancics, selection of
: specific game/cvent for sports quota recruitment and number of
ர posts to be allotted to cach game/cvent.

2. Selection of leading local / national dailics for giving advertisement
and to publish in the department website by mentioning the specific
game/cvent identified for sports Quota recruitment.

Contd/ Page-2
[
|
ந eee

<!-- page 2 -->

|

்‌ ரு

i Page- 2 -

ர 3. All applications to be registered and processed and cligible
candidates to be called for selection trials

| 4, Form sub- committee for conducting field trials in each discipline to
examine the proficiency of the candidates. The sub-committee
should necessarily be headed by an officer of the Department not

| below the rank of Assistant / Deputy Commissioner.

்‌ 5. The candidates selection made in the field trials by the well qualified
independent selectors nominated by the concerned State / National

்‌ Sports Development Authorities / Association / Federations.

i 6. Conduct interview to judge the general intelligence personality traits
and physiological make up of the candidates.

7. Rank wise / position wise lit of the selected candidates, duly signed
by the selectors & countersigned by the Officer - in - charge &
sealed in cover at the sclection field to be submitted to the
Committee. The number of candidates should be at least twice the

number of post allotted to each game / event.

| 8. The Committee / the Officers nominated by the Committee should
ensure that the selection trial and the selection is conducted in the
most judicious manner.

| 9. Any other procedures deemed fit for the selection of the meritorious

| candidates, shall be followed

10 Recommendation to be forwarded to the competent authority for the
appointment of the selected candidates under Sports Quota
recruitment.

Minutes of all the Meeting to be recorded properly and_ all
. cormmunications to the individuals / department / agencies needs prior
: approval of the Chairman.
(M V S CHOUDARY 42 Ti frank}
CHIEF COMMISSIONER OF GST & CE
eee
