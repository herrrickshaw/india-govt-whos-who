---
doc_id: "6ecef67c8f2ceda4"
source_url: "https://py.gov.in/sites/default/files/home10092024.pdf"
ministry: "Forest and Wild Life Department, Puducherry"
title: "G.O Ms. No.64 - CORRIGENDUM"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "656266882d5957a2"
---

<!-- page 1 -->

GOVERNMENTOFPUDUCHERRY
Abstract
Home - Holidays • Change of Pubfic Holiday for Government Offices Including
Govemmcnt Undertaktngs/Boards/Othcr lnslltuhons and for all Banking lnstltuttons
mcludtng Co-operative Banks In the Puducherry, Kara1kal. Mahe and Yanam region or
U T of Puducherry. for Mllad-un-nabi (Btrthday of Prophet Mohammed) for the year
2024 - Corrigendum - Issued.
Home Oepanment
G.O Ms. No.64
Puducheny. dated 10·09-2024
Read: 1. G.O. Ms. No. 59, dated 07/11/2023 of Home OepartmenL
Puducheny.
2. letter No.13/PSWB/Secy/89/2024/190 dated 05/0912024 or
Puducherry State Waqf Board. Puducherry.
CORRIGENDUM:
In the list of holidays to be observed in the year 2024 which was noUOed vide
G.O. read above, the following may be corrected and read as follows:

A ppon dix - I to lhe G •0 • Ms. N0 59• date d 0711112023 0 f Home 0 ~a rtmenl
Sl.
Region
Date
Day
Festival
No.
For
Read
For
Read

1.

2.

Puducheny & 1619/ 2024
Karaikal
and
Yanam R~ion
Mahe Region 17/912024

17/9/2024

Monday

Tuesday

161912024

Tuesday

Monday

Milad-un-nabi
(Birthday of
Prophet
Mohammed)

Appendlx-11 to the G.O.Ms.No.59, daled 07/11/2023 of Home Department
Banki ng Institutions:
St.
No.

1.

2.

Date

Region
For

Festival

Day
Read

For

Puducherry & 16/9/2024 17/912024 Monday
Karaikal
and
Yanam Rf!9.10n
Mahe Region 17/9/2024 16/912024 !Tuesday

Read
[Tuesday

Monday

Milad-un-nabl
(Birthday or
Prophet
Mohammed)

II By Order II

Signed by
M V Hiran

Date: 10-09-2024 17:44:58
(M.V. HIRAN)
liNDER SECRETARY TO GOVERNMENT
To
The Director or S tationery & -with a request to publish In the next Official
Printing, Puducherry.
Gazette and send 20 copies to this Department
~opy to· 1. As per Mailing list for Holidays.
2. The Director. Dire ctorate or Information Technology. Puducherry.
•• • With a request to upload the No lineation on the Web site or
the Government of Puducherry.
