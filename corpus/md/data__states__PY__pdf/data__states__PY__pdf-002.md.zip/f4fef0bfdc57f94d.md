---
doc_id: "f4fef0bfdc57f94d"
source_url: "https://py.gov.in/sites/default/files/padco17052025.pdf"
ministry: "Forest and Wild Life Department, Puducherry"
title: "Notification / Application"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0d9b6e1634e0a175"
---

<!-- page 1 -->

PUDUCHERRY ADIDRA VIDAR AND SCHEDULED TRIBES
DEVELOPMENT CORPORATION LIMITED (PADSTDC)
3rd Floor, ADW & STW Building, Thattanchavady, Puducherry605009. Contact No: 0413-2277318
E-mail id: padco.pon@ni~.in
· NO: 12 7/P ADSTDC/PS/2025-26

Date:
NOTIFICATION

P ADSTDC Invites applications from the aspirants belonging to SCHEDULED
CASTE (SC) and SCHEDULED TRIBE (ST), stude~ts for availing free coaching class
for UPSC Civil Services Examination to be conduCted in the year 2026. The applicants
• .!",

..

shall fulfi_ll the following. conditions.
,.
•

I

1. Applicants should be ordinary residents of U. T of Puducherry belonging to SC /ST.
2: Applicants should be below the age of 35.
3. · Applicants should have completed their.SSLC and Higher Secondary examinations
in the U.T. ofPuducherry;
Last Date for submission of applications is June 02, 2025.

·Note: (i) SC I ST aspirants will be given opportunity for UPSC coaching, irrespective
of their family income. (ii) Entrance exam will be conducted for the Applicants. Based on the marks
··scored in the entrance examination applicants will_be selected for coaching.
Application Form can be downloaded from the webpage of Puducherry State
·
Government Portal https://py.gov.in/.

Managing Director, P ADSTDC Ltd.,

' .·

,. '

.

~

. ...,,· ·

<!-- page 2 -->

..
;""

PUDUCHERRY ADIDRAVIDAR AND SCHEDULED TRIBES
DEVELOPMENT CORPORATION LIMITED
(A Government of Puducherry Undertaking)
3rd

Floor, ADW & ST Welfare Dept .. Thattanchavady,
Puducherry - 605 009

"'"'"'
r-----------------------------------~
Application for Coaching Classes for Civil Service
Examination-2026

/

1. Name of the Applicant (in Block letters)

2. Father/Husband/Guardian's name
3.

Communication address

Mobile No:- - - - - - - - 4.

I I

Date of Birth

years

5. Age
6. Whether Hindu-Adidravidar (or)
Scheduled Tribe
7. Name of the Caste

Rs . _ _ _ _ _ _ _/-

8. Annual family income
9. Aadhar Card Number
10. Education Qualification:Nome of the
Examination
passed

Year of
Passing

Subject
(Main)

Nome and place of the
Institution/University.

%of the mark
obtained

SSLC
HSC

Degree

11. Have you appeared for the Civil Service Preliminary Examinations earlier?
If yes, which years?_ _ _ _ __
12. Whether willing to undergo coaching class in other cities ,
apart from Puducherry?

<!-- page 3 -->

•','

-2(NOTE)

1. Copy of documents mentioned at sl.no.4,6,8,9 & 10 shall be enclosed.
2. Irrespective of income limit all SC/ST aspirants will be given opportunity for
availing coaching.
3. Applicants should be ordinary residents of U.T of Puducherry belonging to SCI ST.
4. Entrance exam will be conducted for the Applicants. Based on the marks scored in
the examination applicants will be selected for coaching.
5. Applicants who had completed their SSLC and Higher Secondary examination in the
U.T. of Puducherry will only be considered for coaching.

DECLARATION
I hereby declare that all above information furnished by me are true and on
selection for coaching through Puducherry Adidravidar and Scheduled Tribes Development
Corporation Limited, Puducherry, I will attend the coaching classes regularly by keeping
punctuality in attendance without any remarks. Further, I undertake that I will abide all
the rules and regulations as prescribed by the Puducherry Adidravidar · and Scheduled
Tribes Development Corporation Limited, Puducherry, without any deviation and will not
make any request to change timing of classes on any account.

Signature of the Applicant
Place:
Date:

<!-- page 4 -->

.

.; .

~~ '

4 t51 ~ae:rf1 ..!8~~ITrrQfJ ut wtiJ f!Jl w u y;lflil@ii.JI-u51611rIT awwurr L_(EJ fill filS)IT !fjA~.o.ia; IJ'&,;,
.

( L/t5}fiiSIQJ

•

~

c!N!T if)fi!ir

fji)ff wtOLl !fj f!)JQJ61ffw)

3-QJ~ {DMTW, ~f}j;/[TrrruiLrT {!j~W

0

wpf!)IW UJPrii@U/-16/~rT {6~~{DifrnUJ.

.

***

NO: 127/PADSTDC/PS/2025-26

PADSTDC 2026 ~Lb ~6tfur@ [5L§J§3uu@Lb UPSC ~6U)6\.J a=lj6ll6hJ {g§jlj~ffiffirT6liT

~6U6lJa=

uuJ1ro~

Qu[!), SC HEDULED CASTE (SC) LDID.IDJLO
SCHEDULED
TRIBE
(ST)
LOrT60lrr6lJ!jffi61f1Lu51®ID.§J
Q])~msruuffiuEdr
ru [J"(]QJJD85u u CB tElJD .fPJ. 6Ul6ffirr60N u u §3 rr IJ &a:, 6Tr U16irr6lJ ® Lb [51 u ri5 §3 QD 6liTa:, QD GIT- · .
b:b&§J® Qa=ww {g6lJ6tfur@Lb.
6lJ@5UQDUU

,_, T~ Q)]6mfrGWQutDrrCTfr y~B=(]a=rflu5kiJ @5Li:J-u5l([!jUUru[Trra.; @®85a.; (]ru6lN(8!lJ.
~< 2. ·61516cirr6mrr u.u §) rr 1J Jjffi 6iT 3 5 6lJ w ~ ffi (§ ~L. u L. L6lJ Jj ffi6TT rrffi ~ ® ffi ffi
r.-·
. .
-~-: ·.'. {g6lJ6mrr(bH.o.

·

' .

3. Q]]6lN6!5NL.lutDrro-fr tDrhl a.;w~ ~ w fr[bl~Xi~J wjbfi)ll.b c:Jwru[bl~ uwcllL.iu£4 uUlQfJ(N
y ~ B=(]crrfl 44615flw 615T UliJ" (]t5 cr 0 {blru u 14 ~ !il® iuE c:Jru 6lN(8w.

. ·6Ul6mrr600fuurfiJa:,QDGTT8:
a=LO!juU1uu§3d:>ffirr6liT ffi@L~ cg§3® ~6irr o2-202s~
..
.·
.
.
~-:

.®[!5J't.j ld:

-~

.

'(i) ·Q/(/.?LO!TaJT ~p-LiJuiafj!}l cPf@67JTJ}i~ cfjffi/ffi/fTITWlL ff LO;fJg;;LiJ

~ : utplhi(!!)Ltf u.flar (S CIS TJuL. L ff!Tr!l&rgp&(!!)Lil u LLfl;iJ#l
· · GlUf!J wm.ilL!LJ dJ;GJfl&a;uu(!}LiJ (g_db~dJ .

(ii) G2fl6/ZTaJlJTUUff!T[Tff8itgfcF(!!j ty(/3 .[p/ @tpQjJi;(ggtfGlj @WcF&UU(!}LiJ. dJ;ffi/W Qu g;;Lil
wfoluGJu6/ZT dJ/Lif u LJQJ)L LLflw Glflazhwu u ff!TfTtt u LLfl;iJ#l&coiT&
(gg ;tffi Qg(!J&&u U(!}Gl/ff.

6ll16'0N60NUUU UL.q.6lJLD L.I.§JcF~a=ifl ~IJ8T @QfJGtmrUJ tDW~ffilru (Portal) www.py.gov.in
6lJ QD 6U §J §) 6TT uu 8:, ffi §J ®6U u ®6lS1 [D ffi a.;Lb Q a= w~ Q a.;rrc;;irwrurr w.

(]wrurr G:ir @w iD@j JDfr
y.~.LD.U,QJ, (]LQ,dl,

<!-- page 5 -->

4 ~~a<Frfl cti{/jJ {/jJ{TfTQ}t LrT I.DJD IDl

w u IPiil(§ Lf~-tliiATrT awwurrL.(f)J

QJQS'I{T {CQS)~.i;a;

(4~A'JQJ Jf{Tlilr.ir

lP&tD
fitrT VP4 {i)tDJQJQSTW)

f5LLrr~<!Frrru111-. 4(DlcFCJ1Frf1 -

•••

iift
~

3-QJ~ {66TTtD, ~~~urrQi/t_IT ~ruth w(iJf!)lw UJPffil@'-9-llilnriT ~ruf6~"'1D·

60/S 009

® ti;{/jJw -=tJ,L.ilu u~ a :f6rTfil/ .$@5 uu'ilJiJ.il
GlufDJQ1:{6JD&fTfilST 6lJl.m-~ uuw
(Application for Coaching Classes for
Civil Ser-vice Examination- 2026)

1. Gl11.m-Gm"uu:f6rrurflm

Gluwrr

2. :f6&UU~rrrr/ &Gm"QJrT/ urr~&fTQJ~rT
Gluwrr
f>T~ .Gl:f6@

Gluwrr
.£/£Trr w t..D
.,!91(5/F~

Gl.srrt..DfH>m
~.suau.il fiT~ •

4.

UlfDtii::D C::f6:$)

5.

QJW{!j/

6.

®Iii {!jJ ~:$]:$1£Trrfil11L £Trr? &{~..U{!j/

II
II
I ~.m-@.sw
-=fj,L.D

u IJ)fil(§ I.SJ--tfil~£Trr?

®~m..u

7. a:rr:$Jtfilm Gluwrr .......... ·. ...... . . .. ..... ........ . ... ... .. ... .... ........... . ..
8. (§@t..Du ~~@ filJ@I.Drr~t..D
9. ~::5rrir &{L~L f>l'Gm"

Name of the
Examination passed

Year of
Passing

f:!§Urrw .................. .1-

······· ··· ······························ ························

Subject
(Main)

Name and place of the
Institution/University.

%of the mark
obtained

SSLC
HSC
Degree

11. ftil!btDC§ (!P~

ftiJ ti;:$1w ~L. .il u~ .$ a;rr m- (!JJ:f6mlm~~ a:f6IT fill fiTQJJ:$111/W6'ffrr £T rr?

I <=fLW I @~m~ I
~w f>J'ffil~, f>T{ljfb f>Ttii!b ~~@a;w .................... . . . . . ....... .... .......... . .

1Z. 4 ~iF aIF rfl {bfilll £T w(b fD GlfilJGYflJMrT a;GYFI ~ :15 Til £I u '-9- .$a; Gl1l @U u t..D ILW 6'ff {brr?

I ~w I ®~~~ I

<!-- page 6 -->

-.

-2(f§#U'-1 : (I) 61/tf'/mtF 6TW 4,6,7,8,9 UJp/!]/$ 10 efJJtlU/6Vp;If/pr§ tFITeT;If//!i/) ti}m6'6'6T.i.t&uUL {J61Jw(JJtiJ
( .3) 6V(!9UJIT611T 6li.P'$t.Jlmpfl o::PfRJ611Tj#p e~t:!fl:!flP'IT61i?Lrf @61fT uL.Li!i1Ttfl.t&f!!9.ir§$ uoflp#l Qu/0
61/tTuiuq o::P~tnfl.i.t&uu@$.
( .1) 61ilwRU"uu/!itTP'ff ~:$1 f)f::rrr6l'i1ur w(b!!))
u lPriiC§'-9-rfilmrt @m ;,m$5 Cl B'rT £515 '-Ip.i(JtFtflofJ.V
r§'-9-ofl(gUUQ/,P'IT.t& ti)g.i.t& (J.vw(JJ$.
(~) 61ilmlf6'6'6Tuu:51TP'rf.t&~.!ir§ fP(!ff 1PfmJP11;f#(J;5tf6J! m.v.i.t&uu@$. o::P~;!fl.V Qu/!J/$ UJ:!fluGJum
o::Pf'-9-UUmLoflwV 61f!w6'6'6TUU;f51TJTff uoflpj#J.i.t&IT.t& (J;5tf;ifQ;5(j).i.t&UU(j}.vtf.
( 5) 61ilw6'6'6TUU;f51TJTff ;51lil<!&67TJ5l .ll..U/ffttJ~NiV UJpj
GUJiilifilm~ u61f6117uu'-9-ut.Jlmm- Llp.i(JtFrfl
!fb Rflmef t.JlP'(JJ5tF:i:!fllili U'-9-fo:!fl(!ff;iffo!TwV UJL(j)(JUJ uuflpj#l.i(§ U/fJ/wVJ.i.t&Uu@$.

w

/!}/m

awe:~

@j {151 L11.51L(Jjltsir6YT

cf1.{61 {61r:r rr6lll Lrr w{b !!Uw -u
Gf!jrr61J

6lll u f]' ri.J o;tsir

~mar~~ w

IP ri.J@j L1l- Wlm-IT a wwurr L_ (J;l

Gla:wwuuLLrr~.

uuJI{iJ#Imw

Glf!jrrLrr ff;~

IL~mwGlwm !!U w,

4 $PI~ Ga:rfl

6lJ m u {61 m~ .$ o;we; ~flirT~

u WI {iJ #I Gl u !D

a:rfl6llf]'

Gw{iJGlo;rrtsirG6llm

61m mJW,

riJ.io;wo;~f6Jm 6lllf6J (!Pa>fDo;a>6YTUJW w{b!!lJt.D 6ll@jULJ a!!5r:r~mf!iUJW a:ifl6ll!J' o;mLUit11-uaum
61mmJw

{iJmLWI~

Go;rruwrrL_GLm

61-io;rru~~mf!i&Glo;rr~(J)lw

6Tm!!lJw

riJf!im

.61J@jULJ

e!Jl~t.D 12...mJ{6)w61fl.i.t!GfDm.

G!fjr:r~mf!i

wrr{b{l5J~f!i!J'
