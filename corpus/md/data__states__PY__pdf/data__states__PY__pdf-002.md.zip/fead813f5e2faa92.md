---
doc_id: "fead813f5e2faa92"
source_url: "https://gstchennai.gov.in/images/pdf/APPEAQLS-II%20TENDER%20-%2020032023.pdf"
ministry: "Office of the Principal Chief Commissioner of GST & Central Excise Tamil Nadu & Puducherry Zone, Puducherry"
title: "Click here for Detail"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "837eb19888ed3666"
---

<!-- page 1 -->

GAPPL/MISC/60/2021-PRO-O/o

COMMR-CGST-APPL- II-CHENNAI

1/1179102/2023

5 years

of GST

OFFICEOF THE COMMISSIONEROF GST & CENTRAL EXCISE (APPEALS_II))
a{{tePId,Vqaa, +2054/1, Ii ghb 12Ttqq?tg
N8WRY TOW8RS12ND FLOOR, No.2054/1, 11 AV£NUE, 12FH MAIN ROAD,
aVTWTV, M- g...g.,
IbPm.2614 2871
ANNA NAGAR, CHENNAI- 600 040-Phone No. 26142871
GAPPL/MISC/60/2021-PRO

Date: 01-03-2023

#Ff+a nra',I +./ LIMITED TENDER NO. 01/2023

heRr rqrq qm Va aVIla SPIT,r Mr q,rI#,Rr, m,IT _ IIXTqq,TaT

Of.04.2023 + 31.03.2024 aH IM at dR HaM & mv HaM , MI, i,iredd
daW

qB# /$nfR=#tdl3i6rfRfBRr

3PN®a RaT

Mla

3m+fqa6tar8,=i3iqaTa%

- 1+

31( 3Tt 3q6w# dR arM TaiuTa MaT eaTit qa.T qa &
WanT + all FI iI tI+ gw gMt %r f@ VV 2 ara + Ha dd #r ++sla,Tr i, 31,T,
dHI dt HErB

naa

©taT @TrI

The Office of the Commissionerof Central Excise & GST, APPEALS - II
Commissioneraterinvites manual tender quotations from experienced/
eligible, reputed, registered firms/companiesengaged in the business o+
providing Annual MaintenanceContract Services of Computers and its
Peripherals in the Commissioneratementioned in Annexure-I for a periodof
one Year from Ol.04'2023 to 31.03.2024.Since the total value of this bid is
likely to be below 2 lakhs, the bid submission will be manual.
Brmfafaa fRfBa aardat gt nBa mar 3iraqv© il

:. fqfa-WaH

(-W-)

-tdt 'W @+iS -f%„ VT (aSWma)
iii. =hiqt b wwd©r aia (a3xm© q)

iv. $qab+TH+a#gaN+ar3+ a Wt (341,IgO El)
v. lgT2 +rTf:hi$1 WaUgH Q. qq. fR. ©lWFaeF]$©qSTf#aTqTr g (3TJHZ©©)
vi. qpqVteftqqqdq (aBPImd)I
The necessary tender documents to be submitted are detailed as below:
i. Tender Acceptance Letter (Annexure A),
ii. Letter of Authorisation to submit Bid (Annexure B)/

<!-- page 2 -->

GAPPL/ MISC/60/2021-PRO-0/o COMMR-CGST-APPL-II-CHENNAI
1/1179102/2023

iii. Company's Turnover Details(Annexure C)
iv. List of two Qualified Engineers in the panel of the CompanY (Annexure
D

v. List of 1 or 2 clients where AMC has been undertakensuccessfuIIY
(Annexure E)
vi. Price Bid Undertaking (Annexure F)

Sqa aa

;lads at

,t,TF8 + q$a 3TNq+ R,ann,T

(3) Mla

HqdIeM (1) Mrt dR qftf€1 (2) qrlar

3it ?Id MM

mira !m

+;i+

dR dw@

https://centralexcisechenrlai.gov.in+ R3a6jg WiT MI

Before placing your bid you are required to download the following
Annexure (1) Scope of work (2) Eligibility criteria and (3) Terms
and
- c-onditions
from
https://gstchennai.gov .in/ .

Ona ,%„

Central

Excise

Chennai

website

dR TXT-WWR m7mqWTfl

The Time Schedule of the Tender process is furnished as under'
Particulars
aRT q}ddRqrtmD%
Bid Submission start date
qT,!a gIa dR 3tM nB
Bid Submission last date

MH+dRnn

radIO

Date

THT
Time

01.03.2023

9:30 AM

13.03.2023

5:00 PM

13.03.2023

05:30 PM

Tender opening date
tT,t qq.K+RRradHt6§afMJdk
aFaradt#tWaHfta qfFMfatWF3t Kam
02.03.2022 q+qr3Mq#aMqTgr%+MeV-I1,
31'1+d 'b'tadd A 2054’ a$dat'
dq, 1, 11 qH,

12qt+t&.

xwnawr, Mr+

HTqqdT.RIMtat3r6-tO#nQ MARrTa# i)

40&%r=fav Aq@®mr=II@I

PF

3

Duly filled bids and signed copiesof the documents in all respecTs
should be submitted by the bidders on or before 13.03.2023either manualIY
or by post to the Office of the Commissioner of Appeals -II/ No- 2054'

Newry Towers, Block I, II Avenue, 12th Main Road, Anna Nagar:
Chennai- 40. (This Commissionerate is not responsible for anY postal
delays)

a

<!-- page 3 -->

GAPPL/ MISC/ 60/2021-PRO-O/oCOMIVIR-CGST-APPL-II-CHENNAI
1/1179102/2023

(dtqFPj3uH / G NAGABHUSNAM)
Wga

Wtb / Asst. Commissioner

Mr f/ Copy to :-

1.8M{TaT/afMT /3T3U xrTaraa (qaa vg # Wf$a HaeTnT)I

Chennai North/South/Outer Commissionerate(For display in the notice
board) .
=.iT=IImB(&TT),8M§raT
I((nRjqTRqT&gaV VT Xv# %,+ +; n,)
The Superintendent(Computers), Chennai North (for uploadingon to the
official website) .

1. &=!aqdWbw@wjt$tqTfqaaWwrttfaH$tqRf©

SCOPE OF ANNUAL MAINTENANCE CONTRACT OF COMPUTERS AND ITS
PERIPHERALS
©r#8qRf© , RqR®a a qr.aS.+ b state H©®,T cErn g
r . fBfi:IS Rtd & 30 –aVg

-thE (q) #T+T (A) aT{–+=F I
2. fiNVgtaaea

<garQrq Ba

qqr @)Ma

(a) RV.IIt„q,r.Q

(i) w.lft. (ii) &qq (iii)+NPT b 18 Rcn Olaf,Heh Rct

(3) 4qq.O. vgarTrq+Rgn;a
(4) 4 qq.It. VM

qT,aS.+ + qm qTqtqa ww tWa&IV mm ( w w+t arq?war d qa qTqVW@WIT,inT e)
dtv+eq$©ra3teM WV Hfqf8agl fBIaTftHanBTObBq31SWo-la
all

Scope of work: There are around
(1) 30 - Computers of various brands viz.
(a). Lenovo (b) HP,HP Compaq (c) Samsung (d) I-Mac
(2) 18 black and white single function and multifunctional printers of
various brands viz - (a).

HP, (b) Canon (c) Samsung

3. 4 HP multifunctionalcolor printers
4. 4 HP Scanners

to be covered under AMC. AMC will include installation of valid reputed
Antivirus software (antivirusto be provided and installed whenever required)
and network maintenance. Refer to Annexure-I for detailed information.

2. #qxKqtdt8TfRvqrqaraTa#
ELIGIBILITY CRITERIA FOR MANUAL BIDS

A

<!-- page 4 -->

(,APPL/ MIS(.../60/2021-PRO-0/oCOMMR-CGST-APPL-II-CHENNAI
1/1179102/2023

q,) q,# ## TTTd a1 ear nt RBITWii wu +gITa Oar uM, ifIWa +dtv;WT
q7TPTqr (avaa3nfwdq,r 3TTdZa qTd w) dR vfR twa 6tdI i I
a) The firm should be registered with Goods and Service Tax
department/(,ST Registration Certificate Copy (furnishing the GSTIN) to be
enclosed .

a) th# #,qa Mxn iT uw =HRJa adl ddI qTINl WWT w®R©aFnvTf©
b)

The firm should be a registered companY with the Registrar of

Companies. Proof of the same should be submitted.
,T) RaR,Odaf++„a

dImM%rqtav/

Ba& A,w, Hfa.THa

MWlq,r+q,mt,tv/ Min

THFaa©dRH{dl-tdtRlar

Sn,II /gq, Raw MR at Vii

fhdt

%rar

,+ + +a &ra aT Rv 3mfta/ ama /'r'„q:W-ftfb"w"8' n;-OndwvqqaW3rr+q7qft§qtv%a=raJU wga war i :

„sad + ++ +arM it Ma SIart dR 1% iT fBI fBHt at anrt

q,rd,w / MaIq,rt q,rIf ,Nr/ +IIdaIm+ rim+ / &d arT F# 3iaett /
and / HrHrTFRqyaaft %IF 'Pir iI"
c) The firm's AMC should not have been terminated due to deFicien qX of
servicein the last three years. The biddershould not have been disqualified
/debarred/blacklisted
by
anY
Government
office/Semi-Government
I)ffit...e/PSU/Bank for any default for such services in the past; An
undertaking on his/her letter head declaringas follows should be given

uwe have not been disqualified /debarred/blacklisted by
any Governmentoffice/Semi-GovernmentOffice / PSUs / Banks for
any default for such services in the past."
,D HAq# #,q,I (f8aaHteT/ faa7
age-Tq dMc

/ H&18 / faMTlo / fHm 11 / MwH),
Mex, ie,1& qc,a dv anI 8rgaqq 'Irl dv aqwrqqtbWTnqagWgT=1 dtv

una$tfBgqaaT6YqtVTfNl

d ) The firm must have expertise in onsite maintenanceand repair of
computers (Windows Vista/Windows7/Windows8/Windows 10/ Windows
11/Linux)/ Laptops/ LaserJet Printers/ network components and other
hardwareparts and accessories.

a) aM,T
&qra3nqcHv:xfgnu-1,1961 &a6dq=wft©TaT:HUT ( bD &tw@Bjyth
HTaa2M2020-2021,2021-22 M 2022-23 bfRq :m=NfqgfWTWTm1 qM VF Wg’WTT
vrftql
e) The biddermust have Permanent Account Number (PAN) underIncome
Tax Act, 1961 and should furnish and provide Income Tax Assessment

2\

<!-- page 5 -->

GAPPL/MISC/60/2021-PRO-O/o COMMR-CGST-AppL-II-CHENNAI
J/1179102/2023

certificates for the three years viz., 2020-2021, 2021-22 and 2022_23.

a) aaaTr+w++wTaU3®T3+WWnRdara@lWTTqqfqHh,qT~,nqTVTftq
f)

The bidder should have valid ISO Certificate. The same should be

submitted .

R) H8#aFaraa/ HEmRIdRd+qa&HRRtA;!FT a{FTdr eK&arg gTa.Tq,Idr

MrI

g) All the documents/Annexurehas to be submittedin the company/s letter
head with seal and signature.

3. WiTUf+MRderd/

GENERAL TERMS & CONDITIONS

• +Rw #I Haftl Rain or.04.2023 +3r.03.2024dq ,.q, d & nv ddt aT
3qaatTtna3T4© iTa„' aFl dTt I
The contract periodwill be for one year from 01.04.2023 to 31.03.2024and
the rates quoted will remainin force during the periodof contract.
• qF ar.31q.f #9ftdt/sq m%+/slqw$ # wt aInt a+ Rr'll iSAVnTHqjtzv/#dt
D

qca/nr3asTft8;fRvv%®rq% +M dTt

I

The AMC shall be a comprehensive contract for all the parts of the

Tachines/accessories/peripherals includingparts such as Printer Heads/
Teflonsheets/key boards/mouse etc.
• ;iFa 3hI ian git V+ ++r

:mIIK in

ST=F +Id,Iq , 3nt,r-II &if

_ 600 040

iR fbfr aitfqjmTaqt#ra+DTqrr qt ala &++Rv8+qTrG©rlrgad,v

xfit=far (W+ H& q?Hra'xqtwr 3TfSRfar’ HFdrvHr) 8r aTa dR .Tra 81
The contractor shall provide one qualified engineer (hereinafter called
'the Maintenanceengineer')on call basis to attend to any complaintin the
Office of the Commissionerof GST & Central Excise, Appeals – III Chennai
600 040.

• W;TF'=F

th

=n aT

far=if

t

Hr=Ita=r

+

wt

Hrt

flaT+

+

VFa:

09.15

t

?TT,T

06'OO q:i am :';f+IFr :M aT 3TrqQHBar M qT ST 3,aRI iT HIT ,+ 3l+e,Id
It+ 301 3wlqarav + +W xqwr7rdR3uteaqUrtgit & e,t ,ta#3V®,i

+it I t+3rnqv% giFt - WIT / ?,rt - MIT gtr ?,r,#,I,r aFir M,T f,V +
@af%wmd&f+u+fRv sf8f\qa5r8in%ra7rarz d8 %qr arwTr I
He shall attend the client's office on all working days from 09.15 a.m. to
06'OO p.m. normalIY, and in case of necessity, beyond this periodand also on

5

<!-- page 6 -->

(,APPL/MISC/60/2021-PRO-O/o COMMR-CGST-APPL-II-CHENNAI
1/1179102/2023

holidays/ whenever the Commissionerate Computer Section functlons
requires so. such work timing /days of necessity shall be notified bY this
office in advance for which no extra charges will be made'

, Pg, STR Ma at q,rwTa9r ag xqtwr xf§Pitr Wm'n M av %+ dR
PI„iM

i n, aT q++ ?,IT,TN,„T 31,IlwT sBUt,T dR @aar

nt

I

It is the responsibilityof the firm to provide standby maintenance englneer

whenever the maintenanceengineer is not available for any reason such as
leave etc.

, 31SSel.T 31BMdr qi 24 ,it & dat MIR at fi)aNd Hr qfi?Mla va rHrqra Mmr
d,1 1 aTM & 3+a#d3nMaa€,!3+q+a3qt wt HWTa %rt - t=la qt $
niqddl Fhtt

The maintenance engineers shall rectify or resolve anY complaint within 24
hours. All repairs have to be carried out on site itself except in respect of
items covered underwarranty.

, gT ,.r,t„viR 3Rd ., it IjPP, W,miT Rif , Bam gwr Wa fhv "„$1d,„,i' ,„„, „„., ,„ ,„.,„ t / a n%n,nFU ar a6ar t qr aft
Mt qB Hf3}ddr + gTa+qIRd Mgr ar war iI §vHr=fwT+iqMy LWT

a+ + 388 Brur a =Tfl{
arT I
The maintenanceengineer once provided shall not be withdrawn/removed
or replaced with another engineer or disturbed from attending to the calls in
this office, by the contractor, without proper/ prior explicit concurrence of
this office,

. .d ..R,*,, .BId,„ B,h,' ,„e %,m + 3Tqq®U d ara i, ad %wt q-"
R;it uf8TafMq acorN :N6ral ntT=iT arT I

Wherethe maintenanceengineer becomes non-availabledue to reasons as
resignationetc., an immediate replacement has to be provided bY the
contractor .

. HTa9qq..T / Q,t+ at 3RqrdRum & HT,Ta #, HaganrMT a 3TaQTHa8a t
an„lit at dd,t-tFt MIn #, Stay,qInd vq+nrrn qt #, MrI sr.Of a%
q,did

XnRq,TVl+,

v6qrv6+3if€1nxl7q+qr3i$Rtar3+q+&Tfti

qH

I

In case if necessity/ any emergency, if this office so requires/the contractor
shaII additionally deploy one or more qualified service engineers to
A

<!-- page 7 -->

GAPPL/MISC/ 60/2021-PRO-0/o COMMR-CGST-APPL-II-CHENNAI
J/1179102/2023

qulckIY set-right

• +faa

anY demanding situation that has arisen unforeseen.

qRsaftl+ataaart#©{+?tttrird©Riw

.WII

I

No revision of rates will be entertained during the contract period.
• 88WT arvnItewTfn
+aBp
311'I+dI,Iq +WIMF{#MllnRd
&
nan63itrw6nra
zqtwr qlrfRFr dTtI
The maintenance service by the contractor sha11 include preventive and

breakdown maintenance of all computer hardware items' in thi -Lniir;
Commission era te.

• Hq(Wr / fra BTN +arHf§IdcTr/ M ITV WR q,VcR/&Rd Hd#TmHT{H3{FKeTVT

RMT+3ITwt SaBaTh#%8aT,!3#+MqNd+RaIn
BruRlgTV Mrl

• RRO3+HrH+#xMHTTadd#%qrdrwT
gIg=ITla

3n£JnqTMRHapTad%qrarwTr

ddtIdf,TacT

I ,THIn/ dnEr #1 +aVaaHMTfea
I

No advance payment in any case will be made. However,quarterly payment
on pro rata basis will be made on satisfactory completion of the coAtFad.

•-rfq-"Twr+f8a +-f8$rf8;M3Tr=IRqTaa nd+,„,
3rrTqT6 il

&w ,„.„

The AMC Service Bills require to be submittedon quarterly basis in Triplicate.

• 3Wtqa3TTf©&dTRRTa8tRT©®rn&Hra&+,qRBTZHMh,ThT.T+
©qarv/ 3n8+qra Mt

dtI dareI qarv #,war / Bel / 3r'=rddfE}aqaf

/

'-;W+#F+*„'t-Br- / ---r dar & t+ %,IT q+t%m„,„,'z„
aWK

aFFtH Hq(wr +fear ThT ar WI,TT,T 3nqrT qT q,r,nttkar R,qT drl:w

3itr?lv3iaf© & fM TTdr,I, VT,HEiR,I trfi} # 3nElrvtR,qr ,irT,Tr 1
In case of anY constrained situation during the above period/ if system
configuration change, Upgradation and the number of computbrs /
printers/other related parts/peripherals have to be increased/reducedby th&
client/ then the contractor would be intimated and the AMC amount would be
reworkedaccordingIY on pro-rata basis and payments would be made based

l

<!-- page 8 -->

(IAPPL/ MIS(.''/60/2021_PRO_O/OCOMMR-CGST-APPL-II-CHENNAI
1/1179102/2023

on the reworked amount, for the remaining period.

. aTM Nrr(eT.T Mr + +fa.hT.if 3MR,T nfCIT 3BTMrvTa wYnaq+ Tea
IM aTv;h qi Mb,TI q,tar at 3naQq% gsM dR t©rqar ufFnfaa #FF
1

The AMC shall include installation, configuring all software including
Operating System and antivirus software and installation of necessarY
drivers.

, qe q®3qq,{aT THTaia +; #?V + %rMa qftaT baB d afa mfl i qR
n*# a.a. / n„ tR „5,,aT & a; ataT tqra aft @n aFar / ”T;"- -$
/

#1 aldf at %# 311 & faT d,q.r,T HNd_N'm

HrT;ttl

STBUT / it.II. / fqzT WaT

In case any equipment is taken outside the office premises for the purpose of
repairs.I if an; PC/printer is not attended/repairedwithin fortY eight hOUrs/
the firm shall provide a standbY for the same immediateIY

, ad 8M8Rq,HUTaqr qj / dnag, Mb,r /am©Tdqr w=M+a®FrqvP, =Ita
Hnq,1% d, a6r{fB€q., drl, &g,r, dR aM a§, aua 3at fsBqa
3iTfaW8a3a
Hat / AMq.rqf8tqTqa, rTaRqq, d+qI MaRt+€zYaRTdwM,dRag iT24
qJ

dabna,8+w gerT%raf+="-rail
,id syd,rd & q,rwT Tg #[ gTa+qI-Idl qr Wga wa a8 dR in ?ra / W
ferex

(#

MIr M/

Mi

ne)

q+ &all

grt

dai

Rta

ii wr% qfa@1197

R,qr war i 1 aM Mea iT mmM,II aT 1:% ft mn 8r wlr@ 3tt stg iT
Mar HTafh7ThT.Tqr qq, MT nTZH dVrI nTZH & MMr
t 30 Van 3IT
gts q,rd aIr %rx :+ %rx dW MFa %r gtI
Where the parts / components have failed/damaged or gone out
of use by any reason, replacementof those parts/componentsincluding
hard disk/ wires, cables, chords, circuit boards, mouse & keYboards etc',
have to be provided by the contractor within 24 hours of attending to the
call, includingthe software installation/ ifnecessarY'
Wherethe replacementof parts or support could not be obtained
due to obsolescence,the entire SYstem (such as Server' Printer, Scanner
etc.) must be replaced by the contractor with a new SYstem with at least
the existing configurationof the same make and brand from the same
manufacturerof the defective system.
, ast M,I mEn €r WTa g,Trac 3tr gts & dWI qYBhqt?la +; ar& Via

R

<!-- page 9 -->

GAPPL/MISC/60/2021-PRO-O/O COMMR-CGST_AppL_II_CHENNAI
I/1179102/2023

n=n & nra tnav f+aw 6rqn€zlna d8 Mar ,dr aq,ri/ af 3afanntar
+ 31# mrm :aI gtS + ram #rPhdtigrz ara WI,t Bart am Ria gr
arwRl

Wh:re replacement of the old system with a new one of the existing
configuration of the same make and brand of the failed system could
not be provided, a system with higher configurationof the' same make
and brand from the same manufacturershall be provided by the contractor.
F+fiBF3nRdfMd

at Wienld+nTZTNa&HrH++/qtRwrqa

varaz Nrr StV 3+t qr at aarz q,TBhqt?Idqr ,II nq,it
HrthTI

Q4 it

q,TRV,7Ttqra q1 dar

• a®© 31TewTltBar + +dta 4'z{dq 3-1 Haq ard+ 88 ©TIhl at qF 3{dt,nq
Bfi it
The AMC will not cover Computer consumablesand is not transferable.
• aMFar ah aa + arT 3,Id'aa gT.!d d# qM, 3+ nfU qf+qT %r aaqTRa

H+H{++nur#''"" ,.n„ a,,'8nM,+ ..n,K ,#fm ;,„, ,

• VFr (REBa aFaraa +) 3PN®a qrd + + %a Br at NTlrda ad it R,hR d+
q{qrfq6xWwr+M
MarR884.jqim„fORd%{epr
dR!,Tr I
[ailure to compIY with anY of the conditions mentioned herein (in the tender
document)will disqualify the bidders in the AMC process.
'

•§T6NtNTiRRFO at FWauFim&bT arM Nd{Hqdfaa#rHaf8&
dtIR h*t at am %# # ,i,,, ,„+ + ,„# #, d,M „,„., + ,',dv #r ,h
3TaRI & Hv SIr %r=+aT qartr wtt;ft / FItdTI + 3141&T.r qr BUT ,TO aT,qr af

34ted qr w+ + aw Mn ,TruK I
Irl case of the firm backing out any time during the period of AMC
without anY explicit consent of this office, the firm will be liable to
recoverY at the rates that will have to be incurred by this office on

q

<!-- page 10 -->

GAPPL/ MISC/60/2021-PRO-0/o COMMR-CGST-APPL-II-CHENNAI
1/1179102/2023

maintenance of the machines/hardware for the balance period of the
contract through alternative means.

Rfa %+ Fa MaT

•

TH.THin it.a. / M

dR dd$a & A,!TTI 3 %+ + at,n HWTa Hd / fMI

att

%ra Hd fr fBFBI IFa & t+ aa %Tt Rad t 3TRIH
Bda da qT a.a. / neT 8r ;RTaid d+ dH qf8fhT loo / - TV& Hr @
armrarwrr

I

If the firm fails to carry out repairs/provide anY standbY PC/printer

within 3 days to the satisfaction of this office, a penaltY of Rs 100/- per
day wi11 be charged for delay beyond three working daYS till such time the
PC/printers are repaired.

, aFBr,fdT MrM#

IN

# Mt gt aHa %'q#t8ar3+ q+ r;want+

HF

3TfirqTrI war iI

This office reserves the right to terminate the services of the firm at
any time without giving any notice whatsoever.

eaR q, a &HrwT %+ dRead aRPa 81 aTa i , a $V3TaRI +’nV+@T3PT+
dldOdldldt at mutt I
If the

services

of the

firm are terminated

due to deficiencY

contract for the remaining period will be awarded to next bidder

the

, Mt 8+ qq,rI + Rna srB,iF qr qr,T,i a8 qa + mBara %r na: sa#%wT +

arwrrl

Not following any of the tender process in anY manner will lead to
automaticdisqualification of the tender F.
e fm at Haq+ / gt / &RCT nPt q#FHHW©q;Ft dR WM
Far,a / M+RIB,i

dO fm

WHim & R;T

arwrr I

No components/spares/computer
parts shall be removed/replaced without
explicit concurrence from the Competent AuthoritY.
IP

U,TW + win vr nf#vAr%a8 ana ara fha faara nr FR nO &T M!
3 agM dR ann q,T TH wtF HBdMarwrr, fa?T#2VatT XT=!qa@1+ geT
+ aT 1 PaRT qHHrt adR + d+ I Saw,7 am ;TUIWla & WWt mara
qT 6„eT %qT aRT,Tr, PIM nh,r d+ qI, RaTa &ad Me

\b

85Tf}art & WMa

<!-- page 11 -->

GAPPL/MISC/60/2021-PRO-O/o COMMR-C(,ST-AppL-II-CHENNAI
. 1/1179102/2023

M 1 fbgt aft feaR aT arad +, av a% fh §riqlr wrrur,i ,I# # ,irdr, all,a 3#{
+n qa vi ii;#1 mm qIn, XHlqa %r 6r=faq 3sttBa- I1 314+dI,Iq qi# qi
&la!;mR

qIORd

iT faT Wang

I

Any dispute arising out of the agreement or that/ which may arise in
future, shall be resolved by taking recourse to arbitration by a
group of 3 members committee, 2 from Commissionerate side and
1 from partY side, failing which the dispute will be subject to Chennai

jurisdiction only. The Office of the Commissionerof GST & Central Excise
Appeals-II Commissionerateis entitled to withhold payments due to the
firm in case of any dispute, till it is resolved.

Signed by G.
_

Nagabhushanam

Date: 014&2023 12:23:11

(at qmiW / G NAGABHWP%prov,ed
TT6Rlqr 31Tg-b / Asst. Commissioner
3TOeT -I1 3TjvarHT / APPEALS-II

\\

COMMISSIONERATE

<!-- page 12 -->

ANNEXUR

Md PTANCEElLETrER I

A

'ENDER A

flatn / Date

+aT # / T,

fay# : fRfBH + fa#m ya qlaf dR +atIfa I mnaT {tq8+dull, RnqT/q,a q,r ,iTV,
Sub: Acceptance of Terms & Conditions of Tender. Tender ReferenceNo:
Name of Tender /Work :

86101/ Dear Sir,

1. # / FH + SIlva “Hfea / M +TnT a©rTT§c(a) dT,Td, –____ +, 3,dvd &aTTa
#@!T13w+fa:8nn+3qHn fafaa€tarax qHa%tfRvil

I/Weobtained the tender document(s) for the above mentioned 'Tender/Work'
from the website(s) namely: as per your advertisement/ given in the above
mentioned website(s).
2' + / Ff + HRH

qTHra.Tt& ya

+ -––– + –––- aqF (acId dtI+, 3TrITa, rTe gt

qtaT+=gtTlfia)+tRfMa vd elf qGtti=+R;+Bar31ddH

ar$iT,Tp3+{#/67T

nT+fRfid fRa
/ QTd / ds Mr gmB qM I
1/We herebY certifY that I / we have read the entire terms and conditions of
the tender documentsfrom Page No. to(includingall documents like
annexure(s)/ schedule(s), etc .,), which form part of the contract agreement and
I/we shall abide hereby by the terms/ conditions / clauses containedtherein.

3. qF rat?fa ql wga HId wav, Hw+ fB8TTT / +Tad @TW a,Ta-wT,i VI ,ITt qTqf}
qqt%t3+ttvr4 + tar wall
The corrigendum(s)

issued

from

time

to time

by

your department/

organizationtoo have also been taken into consideration/while submitting this
acceptance letter.

4. g / EX SRlqa fBfBa aaTdat / ?Ja_fil q+ dR fRfBa 9TH qi DTa #Ff,Tr vd wiirdT
+, nRr eId +, dhMrT BTa P 1
I/We hereby unconditionally accept the tender conditions of above mentioned
tender document(s)/ corrigendum(s)in its totality / entirety.

12

<!-- page 13 -->

5' + / Fa aMy { / ff+ WTt %+ at f+tft Wt%It fB8rNT/ aIdan+ ba nn,Tr qaTrr
%rdta,fBa/faaf3a dft Rm war iI
I / we do hereby declare that our Firm has not been blacklisted /debarred
bY anY Govt. Department/ Public sector undertaking.

6-#/FTWTTfala%taT(dt>/%r+gfhFmft/ WTt %farT qtgaa8#qqHrmwH
aft t 3itt Vm waa /3wu qT{ 'T{vrndq©qrqr aTaTt,,+3in+ R$wT / +,Tad aTiT
8tftv infl fbI:1 Rar wr BaT 6rwT van! aa 31Taq,d gr dT aq,a B 711R,a al 3rrxr
3Tfll%HtqtqfaW gaIn 3Tdf8iW tM WTF,r +r ,IT aq,aiNT qqTaT ,T,IT #[ q+ ,r'a
a+a%t{a+t5qr4 fim araqar il
I/We certify thatall information furnished by the our Firm is true & correct and
in the event that the information is found to be incorrect/untrue or found
violated, then your department/ organization shall without giving any notice or
reason therefore or summarily reject the bid or terminate the CCintra'ctf without
prejudice to anY other rights or remedy including the forfeiture of the full said earnest
money deposit absolutely.

HMv/ Yours faithfully,
daHl# # FTaT€R / Signature of the Bidder,
(3TTRIHTR% dR

13

Rfid / with Official seal)

<!-- page 14 -->

HapPen - a / ANNEXURE- B
P,
ER OF AUT

ORISAT'tON TO SUBMIT BID

TUM rTa-wTPHq) t fhMMat =AB;a&-M/IFM /TtV{FM87+TF=KqaTT
HrdtM H# #rnfia,,TMaatTRqTt R,mT + aTV MOat %_a / +aIM +ifMR
qj{ Wav d8 fUr war II
AN UNDERTAKING(SELF_CERTIFICATE) THAT THE BIDDER HAS NOT BEEN BLACKLISTED
BY A CENTRAL /STATE/UT GOVERNMENT INSTITUTION AND THERE HAS BEEN NO

LITIGATION WITH ANY GOVERNMENTDEPARTMENTON ACCOUNT OF ANY
ISSUES/SERVICES

dlad,d'I + wdm{ / SIGNATURE

OF THE BIDDER

(JEn%TRa HIjl rfid / with Official seal)

14

<!-- page 15 -->

•

3TaWRIF - Tr / ANNEXURE-C

To be submittedin Cl
YEAR

lany letter head with seal and sian

COMPANY/FIRM OVERALL
TURNOVER

2020-21
2021-22
2022-23

TURNOVER UNDER COMPUTER
SERVICE MAINTENANCE

gaRTH
+rdt db +aV

+ a Mr

afijqFd13+ IR +!\d)

LIST OF TWO QUALIFIED ENGINEERS IN THE PANEL OF THE COMPANY
Name of the
qualified engineer

Employee
Code

Educational
Technical
Relevant
Qualification lqualification experIence

in years

31laInF - 5 / ANNEXURE -E

mW

LIST OF 1

Name of the
Client

CLIENTS WHERE AMC HAS BEEN UNDERTAKEN
SUCCESFULLY
Address of Name of 1
the Client

Engineer

1

Contractor

the client is
Govt./ PSU

<!-- page 16 -->

(;FT a

H€d7dqF - Tr / ANNEXURE- F
/ PRICE BID UNDERTAKINGI

+,M (at$q*t Mr Vr HrH a var)
From (Full name and address of the Bidder)

daT + / To
wHaT / nTTaT,
Dear Sir/madam,

# aa 61,IIed A qRqMd faRr Tru 31gmt
fm TV gta gW maT (df) {

v+rHRlaqfRfat€:nth

I

and related activities

I submit the price Bid for
as envisaged in the Bid Document.

2.

g. a& a,nd,r + 3R,TMd RdtlTTvi RT?if dt :naR arT atv va mW;r,

3H6r gmB Mah

fR=! WHa { I

Ihavethoroughlyexar;fined and understood all the terms and conditions
as contained in the Bid Document, and agree to abide bY them'

3.

R .list ,rTTT qd #d wa alt + +i+kiDd at qI 68 Wa ar yaITa maT (a) ( I
I offer to work at the rates as indicated in the price Bid inclusive of all

applicable taxes.

dIdIq,dtI 8 FTTHeN / SIGNATURE

OF THE BIDDER

(nTtIRTftH, ntH pfi(T / WITH OFFICIAL SEAL)

16
