---
doc_id: "eae22ca1fd38b6a5"
source_url: "https://ppclgov.in/admin/dynamic/tender/Qpwk.pdf"
ministry: "Puducherry Power Corporation Limited (PPCL), Puducherry"
title: "F-117 Inviting offers for fourth due date extension tender notice for the work of Providing and fixing of aluminium partition for RIO3 panel inside the power house building of PPCL campus T.R Pattinam , karaikal.   [ Notice Board ]"
date: ""
pages: 3
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "130c794a83b4b7c3"
---

<!-- page 1 -->

| வடவர்‌
fe
> (id HM ப பாம POWER CORPORATION LIMITD
5 (A GOVERNMENT OF 200 பரு IERRY UNDERTAKING)
PROJECT OFFICE, TAR, PATTINAM 609 606, KARAIKAL.
Email:ppel.kkl@nic.in
«Phone: (4368-233060, 233988 Telefax: 04368-233287 |
No. IE117/PPCL/ EE (Mech-Plant)/ ALi (CIVIL) /2025-26/9 0% 3 19... /03/20%
FOURTH DUE DATE EXTENSION TENDER NOTICE
Third Due Date Extension Tender Notice No: F-1 17/PPCL/EE(Mech-Plant)/
\N(CIVEL)/2025-26 /1923 Dated: 06/02/2026 for the work of Providing and fixing of
aluminium partition for RIO3 panel inside the power house building of PPCL campus T.R
Vattinam , karaikal, has been postponed as under:
: Details i As Existing : As Revised i
Last date & Time for receipt of applications : : i
' for issue of tender schedules 02/03/2026 1 04/05/2026;
: Last date & Time for issue of tender ட்‌ 04/03/2026 ' 06/05/2026 i
: Schedules. H — ee = :
1 Last date & Time for receipt of tenders 1 06/03/2026 » 08/05/2026 :
Mll the other terms and conditions remain unaltered. The details may be referred in the
tender Notice which is enclosed herewith and also further details sce at http://ppelgov.in
EXECUTIVE ENGINEER (Mech-Plant)
ee is

<!-- page 2 -->

'PUDUCHERRY POWER CORPORATION LIMITD “கக
(A GOVERNMENT OF PUDUCHERRY UNDERTAKING)
PROJECT OFFICE, T.R. PATTINAM 609 606, KARAIKAL.
Email:ppcl.kkl@nic.in
Phone: 04368-233060, 233988 sa acres ‘Telefax: 04368-233287
Wo. 1) 117/PPCL/EE (Meck- Pinna eee
No. |°-117/PPCL/EE (Mech-Plant)/AT (CIVIL)/2025-267 1279 Dt. /10/2025
TENDER NOTICE
The Executive Engineer(Mcch-Plant), PPCL, T.R.Pattinam, Karaikal invites on behalf of the
Puducherry Power Corporation Limited sealed percentage rate tenders for the following
work from the eligible firms/ contractors registered with the Public Works Department,
Puducherry/Central Public Works Department M.E.S. ,Railways, P&T, other states Public
Works Department. The firms /contractors other than those registered with PWD Puducherry
should produce documents evidence in support of their having satisfactorily completed three
similar works cach costing not less than Rs.0.76 Lakhs or two similar works each costing not
less than Rs. 1.14 lakhs or one similar work costing not less than Rs.1.52 Lakhs in the last seven
year ending on the last day of the month previous to the one in which the tenders are invited
along with the application requesting the tender schedule. The value of executed works
shall be brought to current costing level by enhancing the actual value of work at
simple rate of 7% per annum calculated from the date of completion to last date of
receipt of applications for tenders. All the contractor should produce documents evidence in
support of their having GST Code. Otherwise the tender will be rejected
| ie Approx. koe Eligibility
(1 Name of Work Estimated Cost | ORY | Time of
| (Rs.) ia aa contractors
@i “டு 6) 4)
Providing and fixing of
aluminium partition for Class V
103 panel inside the Two (2) and
ie power house building of | ¥#-1:89:765/- | Rs.3,800/- | ths | above/
| PPCL campus T.R firms
| | Pattinam , karaikal. ate
(i) Last date & Time for receipt of applications for 17/11/2025 4.00 P.M.
issue of tender schedules.
(ii) Last date & Time for issue of tender Schedules. 19/11/2025 4.00 P.M.
(iii) Last date & Time for receipt of tenders 21/11/2025 3.30 P.M
(iv) Date & Time of opening of tenders 21/11/2025 4.00 P.M.
‘Tenders will be reccived by the Executive Engineer (Mech-Plant), PPCL, T.R.Pattinam,
Karaikal as per the date and time mentioned above.
While applying for tender forms,
(a) If the contractors are registered in PWD Puducherry shall submit
(i) the EMD,
(ii) GST Certificate.
(iii)The attested copies of the registration / renewal certificate
(b) The firms /contractors other than those registered with PWD Puducherry shall submit
(i) the EMD,
(ii) GST Certificate.
(iii) the Work completion certificate has to be enclosed,

Tender forms and conditions of contract can be had from the office of the PPCL,
‘T.RPattinam, Karaikal on payment of Rs.500/-(Rupees Five Hundred Only) plus
GST@5.00%by cash as cost of tender schedule(non refundable) but in case of tender
schedule being down loaded the cost of tender schedule is payable in the form of Demand.
Draft of a Scheduled Bank in favour of the Executive Engineer (Mech-Plant), PPCL,
‘T.R.Pattinam ,payable at Karaikal and shall been enclosed in the envelope super scribing
as“ EMD / cost of Tender Schedule” and on depositing of EMD as mentioned in column
(4)in the form noted below.

ad

<!-- page 3 -->

ee
12) 4

வட்டு பம்ப்‌ ன்‌ Be ecu reels the form of Bankers cheque / Fixed Deponit

OR Gi mand பயப்‌ of a sel ze ulec pants and mubmitted nlongwih the tender sehedute,

10. ய்யும்‌ money should be drawn in favour ef the Executive Engineer (Mech-Plant),
PCL, 1 Pattinam, payable at Karaikal,

‘Vender schedule ean பிஸ்‌ be down-loaded by the contractors from the web nite
hip: 7. 7 ppelgoy.in, But the contractors who had downloaded the NIT from the web
site shall follow the procedures prescribed below:

'. ‘Tho contractors who have downloaded the NIT from the website shall submit the
"ender Schedule in Two envelopes sealed in a single cover, The first envelope shall be
placed with vequired amount of coat of Tender Schedule, EMD in the preseribed format
drawn on or before the scheduled date of receipt_of Tender, GST Certificate and the
attested copies of the registeation / renewal certificate /work completion certificates and the
envelope shall be super seribed as“ EMD /cost of schedule” and the other envelope shall
he super scribed as TENDER SCHEDULE where in the duly filled and signed NIT shall
be placed and sealed,

2. The contractor who have purchased the tender schedule directly from the offices
shall also submit tender in two envelopes sealed in a single cover. The first envelope shall
be placed with the copy of receipt of cost of tender schedule, proof of documents for
remittance of BMD, GST Certificate, and the attested copies of the registration /renewal
certificate/ work completion certificate and the envelope shall be superscibed as ‘EMD / Cost of
Schedule” and in the other envelope super-scribing“Tender Schedule” where in the duly
filled and signed NIT shall be placed and scaled,

3. On the date of tender opening, the cover marked “EMD/Cost of Schedule” shall be
opened first, Bidders who fail to submit the required pre-existing documents will be allowed
one weck’s time to furnish the same, failing which their tender will be rejected, Only after
confirming submission of tender cost, EMD, GST certificate, registration/renewal
certificate, and work completion certificate, the “lender Schedule” cover will be opened.

A. If the opening day of tender happens to be a Public Holiday, the same will
be opened on next working day.

5. The time allowed for carrying out the work will be 2(two) months from the
tenth day after the date of written order to commence the work.

6. The undersigned reserves the right to reject any or all the tenders without
assigning any reason thereof, : >

\rhepoue
EXECUTIVE ENGINEER(Mech-Plant)
