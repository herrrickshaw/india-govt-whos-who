---
doc_id: "61c49b9daf7eba1d"
source_url: "https://py.gov.in/sites/default/files/licence.pdf"
ministry: "Forest and Wild Life Department, Puducherry"
title: "BUS STOP NOTIFICATION"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7f872e81e6fbf820"
---

<!-- page 1 -->

LICENCE G.O. NOTIFICATION & ORDERS
GOVERNMENT OF PONDICHERRY
(Abstract)
The Motor Vehicles Act, 1988 (Central Act 59 of 1988) – Appointment of officers to issue
medical certificates for purposes of grant of learner's licence – Notification – Issued.

WELFARE SECRETARIAT (TRANSPORT)
G.O. Ms. No.35/89-Wel ( Tr )

Pondicherry , the 27 th June, 1989.

ORDER:
The following notification shall be published in an extraordinary issue of the Official Gazette:NOTIFICATION
In exercise of the powers conferred by sub-section (3) of section 8 of the Motor Vehicles Act,
1988 (Central Act 59 of 1988), the Lieutenant-Governor, Pondicherry hereby appoints the
Resident medical Officers of the Government General Hospitals in Pondicherry , Karaikal ,
Mahe and Yanam and the Medical Officers of the rural dispensaries, Primary Health Centres and
Subsidiary Health Centres in the Whole of the Union territory of Pondicherry to issue medical
certificates for purposes of grant of learner's licence under the said section.
(BY ORDER OF THE LIEUTENANT-GOVERNOR)

(M. RAJMANI)
UNDER SECRETARY TO GOVERNMENT
To
The Director of Stationery & Printing, Pondicherry
• He is requested to publish the above notification in the Extra-ordinary gazette on 1.7.1989 and
to furnish 25 copies of the same for this Secretariat use.
Copy to:
(1) The Transport Commissioner, Pondicherry .

<!-- page 2 -->

(2) The Director of Health & Family Welfare Services, Pondicherry .
(3) The Medical Superintendent, General Hospital, Pondicherry/Karaikal/Male/Yenam .
(4) The Administrator, Karaikal/Mahe/Yanam .
(5) The Central Record Branch, Pondicherry .
(6) The Government order file.
(7) The Medical Officers of Primary Health Centres , Subsidiary Health centres and rural
dispensaries.
(8) The Spare Copy file.

UNDER SECRETARY TO GOVERNMENT

GOVERNMENT OF PONDICHERRY
(Abstract)
The Motor Vehicles Act, 1988 (Central Act 59 of 1988) – Appointment of officers to issue
medical certificates for purposes of grant of learner's licence – Notification – Issued.
WELFARE SECRETARIAT (TRANSPORT)
G.O. Ms. No.35/89-Wel ( Tr )

Pondicherry , the 27 th June, 1989.

ORDER:
The following notification shall be published in an extraordinary issue of the Official Gazette:NOTIFICATION
In exercise of the powers conferred by sub-section (3) of section 8 of the Motor Vehicles Act,
1988 (Central Act 59 of 1988), the Lieutenant-Governor, Pondicherry hereby appoints the
Resident Medical Officers of the Government General Hospitals in Pondicherry , Karaikal ,
Mahe and Yanam and the Medical Officers of the rural dispensaries, Primary health Centres and
Subsidiary Health Centres in the Whole of the Union territory of Pondicherry to issue medical
certificates for purposes of grant of learner's licence under the said section.

<!-- page 3 -->

(BY ORDER OF THE LIEUTENANT-GOVERNOR)
(M. RAJMANI)
UNDER SECRETARY TO GOVERNMENT

To
The Director of Stationery & Printing, Pondicherry
• He is requested to publish the above notification in the Extra-ordinary gazette on 1.7.1989 and
to furnish 25 copies of the same for this Secretariat use.
Copy to:
(1) The Transport Commissioner, Pondicherry .
(2) The Director of Health & Family Welfare Services, Pondicherry .
(3) The Medical Superintendent, General Hospital, Pondicherry/Karaikal/Male/Yenam .
(4) The Administrator, Karaikal/Mahe/Yanam .
(5) The Central Record Branch, Pondicherry .
(6) The Government order file.
(7) The Medical Officers of Primary Health Centres , Subsidiary Health centres and rural
dispensaries.
(8) The Spare Copy file.
UNDER SECRETARY TO GOVERNMENT

GOVERNMENT OF PONDICHERRY
(Abstract)
The Motor Vehicles Act, 1988 (Central Act 59 of 1988) – Appointment of Officers to issue
Medical certification for the purpose of grant of learner's licence / driving licence renewal
licence – Notification – Issued.

<!-- page 4 -->

-------

WELFARE SECRETARIAT
(TRANSPORT)
-:o:G.O. Ms. No.48/89-Wel ( Tr )

Pondicherry , the 10 th Oct 1989.

Read: (1) G.O >Ms. No.35/89-Wel( Tr ), dated 27.6.1989 of the welfare Secretariat (Transport),
Pondicherry .
(2) Letter No.TD ./T. 15/80/89, dated 29.8.1989 of the Transport Commissioner, Pondicherry .
-:o:ORDER:
The following notification shall be published in the next issue of official gazette:NOTIFICATION
In exercise of the powers conferred by sub-section (3) of section 8 of the Motor vehicles Act,
1988 (Central Act 59 of 1988) and in partial modification of the notification issued in G.O. Ms.
No.35/89-Wel( Tr ), dated 27 th June, 1989 of the Welfare Secretariat (Transport), Pondicherry ,
the Lieutenant-Governor, Pondicherry , hereby authorises all the Registered Medical
practitioners having M.B.B.S. degree including the doctors working in Government
Hospitals/Health Centres in the Union territory of Pondicherry for the purpose of the said subsection (3) with immediate effect.
(BY ORDER OF THE LIEUTENANT-GOVERNOR)

(M. RAJAMANI)
UNDER SECRETARY TO GOVERNMENT

To
The Director of Stationary & Printing,

<!-- page 5 -->

Pondicherrry . – He is requested to publish the above notification in the official gazette and to
furnish 50 copies of the same for this Secretariat's use.

Copy to: (1) The Transport Commissioner, Pondicherry .
(2) The Director of the Health and Family Welfare Service, Pondicherry .
(3) The Administrator, Karaikal//Mahe/Yanan ,
(4) The Medical Superintendent, Government General Hospital,
Pondicherry/Karaikal/Mahe/Yanam .
(5) The Medical Officers of Primary Health Centres , Subsidiary Health Centres and Rural
Dispensaries.
(6) The central Record Branch, Pondicherry .
(7) The Weekly Report file.
(8) The Government Order file.
(9) The Spare Copy file.

UNDER SECRETARY TO GOVERNOR
