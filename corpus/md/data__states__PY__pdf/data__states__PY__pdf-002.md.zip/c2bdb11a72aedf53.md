---
doc_id: "c2bdb11a72aedf53"
source_url: "https://law.py.gov.in/docs/Notary_interview.pdf"
ministry: "Law Department, Puducherry"
title: "Appointment of Notary - Interview Called Letter"
date: ""
pages: 11
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "d0eadaf2c3637dc6"
---

<!-- page 1 -->

GOVERNMENT OF PUDUCHERRY
LAW DEPARTMENT
No.1808/US/2/2015-LD Puducherry, dated 06.06.2022
INTERVIEW CALL LETTER
SUB: LD - Appointment of Notary - Personal Oral Interview — Reg.
Ref : Notification issued in G.O. Ms. No.7/2021-LD, dated
4" February, 2021 of the Law Department, Puducherry.
ஆங்க
With reference to the Notification cited on the subject mentioned above and
in response to the application received from the Advocates for appointment of
Notaries in Puducherry/Karaikal/Mahe/Yanam regions, the personal oral interview
for the applicants is scheduled to be held from 13.06.2022 to 24.06.2022 at
9.30 A.M onwards in the Chamber of the Secretary (Law) Puducherry as per the
scheduled dates in the Annexure for being considered for appointment as Notary.
2. The Advocate(s) is / are requested to attend the oral interview in person
along with the Identity Card and Enrollment Certificate issued by the Bar Council.
Failing to appear on the above said date and time will be a bar to consider his
application.
3. The applicant shall be present 30 Minutes before the interview time. No
Travelling Allowance will be paid for attending the interview.
4. The corresponding dates schedules to concerned applicants who are called
for interview is also uploaded in the website of the Law Department.
(N. MURUGAVEL)
UNDER SECRETARY (LAW)
-CUM-
COMPETENT AUTHORITY
Encl: Annexure as stated above.
Cop To:
1. The Hon’ble Chief Judge, Puducherry.
2. The Hon’ble District Judge, Karaikal.
3. The Hon’ble Sub- Judge, Mahe. With a request to display
4. The Hon’ble Sub- Judge, Yanam. in the Notice Board for the
5. The President, Bar Association, information of Advocates.
Puducherry, Karaikal, Mahe & Yanam.
6. All the Members of the Interview Board.

<!-- page 2 -->

€ a
e@ ANNEXURE
PUDUCHERRY REGION
sl Name &Address
N Enrol. No. Date of Interview
5 | Thiru/Tmt
A. ANBOUSELVAME,
1 94420 69872 Ms.3187/2010
anbouselvamearoumougame187@gmail.com
P.X. AKHILA,
2 9600609309. Ms.No.3324/2012
x.19.akhila@gmai.com
V.R. AROUMOUGAM,
3 7339149116 Ms.No.1344/2011
aroouu47@gmail.com
P.L. ANDRE SELVA,
99940 78055 Ms.No.767/1987
andreselva2@gmail.com |
P.R. ARMUGHAM,
5 93448 64286 Ms.No.3581/2012
prarumugamadv@gmail.com |
N. ARUMUGAM,
97901 46250 Ms.No.887/2003
nanuarumugam@gmail.com
R. ANBUMATHY,
7 96298 78921 Ms.No.2254/2005
shahanaasakthi@gmail.com
V. ARJUN PRASAD RAO,
9894440004 Ms.No.452/2012
arjunprasadrao@gmail.com
R. ASVANI,
7598292729 Ms.No.1249/2003
adv.asvani@gmail.com
K. ASHOK KUMAR,
10 | 9944860509 Ms.No.859/2013
advocateashokkumar1987@gmail.com 13062022
G. BALARAMAN, ஸு
11 | 9486536443 Ms.752/1998
gbalaraman@gmail.com
R. BABU,
12 | 97894 42743 Ms.925/2005
baboubabou@gmail.com
D. BANUMATHI,
13 | 80723 81803 Ms.No.3766/2011
banumathibanumathi30@gmail.com
N. BAZIRAKANNY,
96989 81023 /8124259898 பல்டி
S. BHUVANESWARL,
15 | 7639743839 Ms.No.2618/2013
advocatebhuvana783@gmail.com
B. BALASUNDIRAM,
16 | 90471 44486 Ms.No.3612/2010
balasundiramllb@gmail.com
P. BUVANESHWARI,
17 ‘| 8190005960 Ms.No.3606/2011
bubibuvi@gmail.com
K. BALAJI,
18 | 9842322667/2213333 Ms.No.1141/2002
balashrini@gmail.com
K. BHARATH,
19 | 7373131370 Ms.No.3063/2013
suriyabharath70@gmail.com
S. BALAJL,
20 | 9894926852 Ms.No.1772/2014
sbalaji.lic@gmail.com
1]

<!-- page 3 -->

Name &Address
Enrol. No. Date of Interview

Thiru/Tmt
C. BHAGEERATHY,
96296 49411 Ms.No.2072/2007
bhageeadvt@gmail.com
S. BALAMOUROUGANE,

22 | 9842389393 Ms.No.740/1996
bal_m30@yahoo.co.in
A. BENARD ILANSEZEAN,

23 | 9688755062 Ms.No.1088/ 2008
sezean@gmail.com
5. CHANDRASEKAR,

93451 60165 Ms.No.484/1984

V. CHITHRA,

23 | 91593 18991 Ms.No.1055/1999
vijayanchithra4@gmail.com
K. DASS MUNIA
M. DAROUMALINGAME,

27 | 96002 22176 Ms.No.2761/2013
advmdlingam5378@gmail.com
T. DANASEGARI,
9894817322 Ms.No.1119/ 2002
THIRU-MARINE@YAHOO.COM
V. DEVADOSS,

29 | 99432 55710/2211710 Ms.No.1374/1992
asvdevadass@gmail.com
N. DAYANITHI,
95979 66282 / 2665842 Ms.No.346/2012
nal. dayanidhi@gmail.com aE
K. DAMODHARAN, ்‌
99420 10376 Ms.No.2164/2006
damodharanlawyer@gmail.com
R. DINESHKUMAR,

32 | 8680912345 Ms.No.3362/2011
adv.dinesh1984@yahoo.com
A. DINESH KUMAR,

33 | 94432 87877 Ms.No.1004/2000
adavoca@gmail.com
U. DHANAJAYAN,

34 | 90038 17295 Ms.No.3327/2012
udhanajayan@gmail.com
J. EGAMBARAM,

35 | 9994964952 Ms.No.1295/2012
E-mail: egambaram37@gmail.com
24. GOVINDA THIRUNAVUKARASU,

36 | 99948837949 Ms.No.1220/2003
kaviyabanu09@gmail.com
P. GOPI,

37 | 98942 84004 Ms.No.1080/2002
gobi7doss@gmail.com
R.GIRIJA,
9003373431 Ms.No.391/2010
girijakarthikeyan@gmail.com
5. GEETHA,

39 | 76394 68929 Ms.No.1553/2008
SAARA.SAK@GMAIL.COM
A. GNANARAJAN,
94423 54244 Ms.No.957/2005
gnanarajanadvocate@yahoo.com

<!-- page 4 -->

Sl Name &Address
Enrol. No. Date of Interview
No | vhira/Tmt
S. HEMALADA,
ப Ms.No.1239/2003
K. ILANGO, Ms.No.1107/2002
B. INBA GUNASEKAR,
43 | 79047 06994 Ms.No.944/2006
inba79@gmail.com
| I ILANKUMAR,
9443217105 / 6374155880 Ms.No.1302/2001
iilankumar@yahoo.com
G. IYANAR,
94420 87998 Ms.No.2772/2013
iyanar_gm@yahoo.co.in
P. ILANGOVAN,
97904 18996 Ms.No.3361/2012
ilangolngvn@mail.com
P. INDRA JOSEPHINE SHAKILA,
9894846499 Ms.No.1147/1991
V. ILANGOVARADAN,
70925 39280 Ms.No.736/1984
ilangovaradan30@gmail.com
T. JAYAKANTHAN,
9790283845 Ms.No.1125/2013
jayakanthan1985@yahoo.com
S. JAYACHANDRAN,
9443881953 Ms.No.777/2004
jaichandran25@gmail.com
15.06.2022
G. JOTHIRAMAN,
51 | 98431 24489 Ms.No.2650/2013
gjothiraman@gmail.com
C. JIVA DEVA,
52 | 9894270228/6379014199 Ms.No.1611/2005
deva_jiva@yahoo.co.in
K. JOSHY,
53 | 96002 43281/9840565141 Ms.No.1899/2004
joshylIb@yahoo.co.in
P. JAYARAJ,
9894137277 Ms.No.1036/2006
palanijayaraj@gmail.com
G. KANJANAMALA,
55 | 9751400934 Ms.No.2078/2005
kmala_adv@yahoo.com
P. KULOTHUNGAN,
94436 59069/82480 84997 Ms.No.1676/2004
kuloavocat@gmail.com
K. KANAGARANI,
572 | 89405 15125 Ms.No.667/2009
Kanagaram85@gmail.com
ந்தி G. KARTHIKAYAN, Ms.No.1826/2004
M. KALAISELVAN,
f= 99443 41742 Ms.No.3192/2011
P. KUMARAGURU,
8144040396 Ms.No.1645/2012
Veerakumaraguru@gmail.com

<!-- page 5 -->

| sl Name &Address
. Enrol. No. Date of Interview
No Thiru/Tmt
| T. KALYANASUNDARAM, Ms.No.1408/2007
A. KENGAMUTHU,
62 | 97870 62542 Ms.No.2098/ 2003
A.K.Muthuthu@gmail.com
K. KARKI,
63 | 99431 79537 Ms.No.3313/2011
karkik1982@gmail.com
J. KALIRATHINAM,
99524 74039 Ms.No.2613/ 2006
jkrathinam@gmail.com
K. KARTHIK,
65 | 97901 77465 Ms.No.1332/2011
karthikkoth@gmail.com
A. KARTHIKEYAN,
98946 31652 Ms.No.1410/2007
advkarthikeyanayyanar@gmail.com
K. KRISHNAMOORTHY,
67 | 9865941361/2238478 Ms.No.147/1994
k.krishadvocate2010@gmail.com
R. KUMARAN,
94439 60499 Ms.No.1160/2002
legal. kumaran@gmail.com
R. KANAGARAJ,
9943122625 Ms.No.760/2011
kanagarajramalingammohan@gmail.com
S. LAKSHMI NARAYANAN,
70 | 99945 13885 Ms.910/2007
In ds te@: il.
sInarayananadvocate@gmail. com, 16.06.2022
R. LURDUIGNACIA,
77080 27972 Ms.No.443/2010
P. LUPRAKASAN,
72 | 99447 57716 Ms.No.3732/2011
luprakashbabl@gmail.com
P. LAKSHMITHARAN,
73 | 9843744424 Ms.No.2408/2007
advocatelakshmitharan@gmail.com
5. LAKSHMINARAYANAN,
74 | 9443535984/909200775 Ms.No.526/1996
lakshman1964@yahoo.co.in
R. MUTHUVELAN,
75 | 89036 53884/90470 53884 Ms.No.903/2004
jurisvela@gmail.com
KE. MAHALAKSHMI,
76 | 88079 53330 Ms.No.843/2007
k.e.Mahalakshmiadv@gmail.com
A. MITHUN CHAKRAVARTHY,
77 | 9500259737 Ms.No.586/2009
mithunlaw@gmail.com
V.K. MULLAIKODI,
78 | 9444637311 Ms.No.2141/2000
mullaikodimohandass@gmail.com
M.S. MARUTHUPANDIYAN,
79 | 9443353665 Ms.No.42/1993
advocatemaruthupandian@gmail.com
S. MURUGAN,
90030 50507 Ms.No.1673/2012
mayilammurugan@gmail.com

<!-- page 6 -->

:
: 5
SI Name &Address
N | Enrol. No. Date of Interview
° | Thiru, {Tmt |
NIRMAL CHANDRA @ NIRMAL
81 | CHANDRA SWAIN, Ms.667/2003
94432 42813
T.H. NIZAMUDEEN,
94435 34599/9003495234 Ms.No.693/1998
advocatenizam@gmail.com
V. NARAYANAKUMAR,
9344639658 Ms.No.440/2002
advocatevnk2002@gmail.com
R. PRAVEEN KUMAR, |
94437 99192 Ms1100/2002
tpkadvocate@gmail.com
G. PONNUSAMY @ SURESH KUMAR,
99947 37570 Ms.No.983/ 2006
advocatesureshganesan@gmail.com
G. PRAKASH,
76395 00804 Ms.No.3734/2011
pragashg1@gmail.com
D. PUSHPARAJ,
87 | 8098249828/9092876724 | Ms.No.556/2009
pushparajpushpa@38@gmail.com
S. PREBAKARAN,
88 | 99447 58777 Ms.No.871/2005
advpreba@gmail.com |
N. PAKKIRI,
|» | 99449 80254 Ms.No.1646/2000
S. PRAKASH,
96987 94072 Ms.No.3679/2011
prakashadvocate85@gmail.com
A. PURATCHI KUMAR RODIN, ண்ட்‌
9791563335 Ms.No.1379/2001
pkrodin@gmail.com
S. PARTIBANE, |
9943304579 | Ms.No.2148/2008
partibane77@gmail.com |
L. PRABAKARAN,
94888 20326 Ms.No.2374/2012
Prabakanthan@gmail.com
S. PARIMALAM,
98423 82410 Ms.No.133/1994
parimalamoffice@gmail.com
P. RADHAKRISHNAN,
9894702156 No.1339/2010
radhakrishnangrs1@gmail.com
A.K. RAMADOSS, |
«| 9487063222 | Ms.No.1834/2010
R. RAVICOUMAR,
94437 44379/2358931 Ms.No.138/1994
R. RAJA PRAKASH,
95008 14777 Ms.No.2020/2010
advocateprakash2020@gmail.com
R. RAVICHANDRAN,
9365815951/9994795967 Ms.No.2734/2013
raviadvocate3975@gmail.com
R. RAJAVELU,
100 | 94430 34341 Ms.No.1206/2002
rajavelu_27@yahoo.in
RY பி

<!-- page 7 -->

்‌ 6
sl Name &Address
Ni Enrol. No. Date of Interview
°. Thiru/Tmt
S. RAMAMOORTHY,
101 | 98943 82563 Ms.No.1931/2012
joshussrj@mail.com
M. RAMASWAMY,
9443433937 Ms.No.846/1989
R, RAJARAM,
103 | 97895 45422 Ms.No.1841/2012
RRAJA3557@gmail.com
B. RAJEENEE,
104 | 97892 23634 Ms.No.3608/2011
Rajeeneeradhika@gmail.com
R. RAJA,
9751830234 Ms.No.88/2014
S. SHIBI,
106 | 9345411558, 0413-2201988, Ms.2031/ 2000
shibi.ad@gmail.com
S. SURESH,
107 | 94436 02953 Ms.1908/ 2007
ssureshadvocate@yahoo.com
A. SHANMUGAM,
108 | 96260 09391, 2966031 Ms.3187/2010
shan_kadr@yahoo.co.in
K. SARAVANAN,
109 | 9790379637 Ms.No.1889/2010
saravanan150974@gmail.com
L. SAI RADJACHANDRAN,
110 | 94430 86411 Ms.No.992/2000
sairadjachandran@gmail.com 20.06.2022
K. SARAVANAN, ஞ்‌
111 | 98438 45775 Ms.No.1792/2007
aksaravanan_adv@yahoo.com
H. SENDHILKUMAR, Ms.No.1044/2006
S. SUNDARARAJAN, Ms.No.1717/2006
S. SATHIAMOORTHY,
114 | 98948 32807 Ms.No.3679/2011
Sathiamoorthy03@gmail.com
G. SIVANANDAN,
115 | 94432 42341/2331327 Ms.No.366/1989
sivanand@lawyer.com
K. SANKAR DASS,
116 | 98941 78427 Ms.No.955/2005
sankar6law@gmail.com
K. SUNDARRAJAN,
117 | 9894685785 Ms.No.874/2007
sundarkrish2@gmail.com
B. SIVASANKAR,
118 | 9443216777 Ms.No.1428/2001
sivasankar lawyer@gmail.com
V. SENTHILKUMAR,
119 | 99942 02056 Ms.No.2361/2013
vinobasenthil@gmail.com
V.M. SIVASSANGARANE,
120 | 94434 09907 Ms.No.785/2008
sivassangarane@gmail.com

<!-- page 8 -->

3 yi
SI Name &Address
Ni Enrol. No. Date of Interview
° | Thiru/Tmt
S. SARAVANAN,
121 | 99941 96327 Ms.No.741/2007
advss3107@gmail.com
U. SABITHA,
122 | 98436 54166 Ms.No.1206/2002
sabithanapal@gmail.com
S. SABIYABEGUM,
04863 41427 Ms.No.876/2006
A. SIVAKUMAR,
124 | 9790049614 Ms.No.3191/2012
sivakumaru84@gmail.com
D. SIVAKUMAR,
125 | 7904898334 Ms.No.445/2002
sivalaw.kumar@gmail.com
S. SUGANTHI,
126 | 94865 21552/229024 Ms.No.2217/2005
suganthiadvocatepondy@gmail.com
M. SATHYAVENDHAN,
6 53233 Ms.No.1391/2007
P. SURESH,
99422 06022 Ms.No.2348/2013
sureshkal@gmail.com
G. SRIDHARAN,
129 | 90877 27668 Ms.No.1607/2009
gsridharan0707@gmail.com
S. SASIBALAN,
130 | 9360666983 Ms.No.2663/2006
sasibalan.s@gmail.com சாரணை
P. SAKTHI, =
131 | 98434 52887 Ms.No.317/2009
sakthiadv2008@gmail.com
P. SANTHOSH KUMAR,
132 | 98944 69005 Ms.No.473/2010
knpadvo@gmail.com
I. SURIYA,
133 | 88387 97258 Ms.No.3072/2013
suriya.lawyer13@gmail.com
R.SIVA,
99409 83767 Ms.No.1169/2013
sivaramaswamy04@gmail.com
B. SHANMUGAM,
fa 99941 91115 Ms.No.3785/2012
D. SRIDAR,
9362994116 Ms.No.727/1991
tndstridar1962@gmail.com
5. SAVARIRAM,
137 | 94430 73875 Ms.No.993/2000
ssrulaw@yahoo.co.in
S. SIVAKUMAR,
138 | 98948 41506 Ms.No.1244/2003
sivakumar@lawspet.com
B. SUDHA,
139 | 9597642783 Ms.No.1504/2001
ADVOCATESUDHA2011@GMAIL.COM
K. SIVAKUMAR,
140 | 77084 64135 Ms.No.1682/2012
shivaktvm@gmail.com
\

<!-- page 9 -->

| ்‌
SI Name &Address
N Enrol. No. Date of Interview
5 | Thiru/Tmt
THAMBUMALLA RAMALINGAM,
98947 91494 veo
S. THANGAVELU,
94867 47383 Ms.No.3359/2011
V.K. THILIPAN KUMAR,
143 | 9791872344 Ms.No.3740/2011
advocatethilip11@gmail.com
M. THILAGAVATHY
144 | 99408 5751 Ms.No.1145/2002
tilagavathyraja@; il.com
R. TAMIZE SELVY,
145 | 98423 58877 Ms.No.437/2002
harputam@gmail.com
V. THAMIZHPRIYAN,
146 | 9787891340 Ms.No.349/2012
ADVTHAMIZHPRIYAN18@GMAIL.COM
M.D. THIRUVENGADA RANGAN,
147 | 9597785929/8111096929 Ms.No.3415/2012
springthiru@gmail.com
T. THIAGAPRABAKARAN,
148 | 9688949399 Ms.No.406/2014
thiagaprabakaran@gmail.com
A. VIVEGANANDANE,
9894312523 Ms.No.494/1998
149 avvarsh151@gmail.com
B. VETRIVEL,
150 | 9364432581 Ms.No.1891/2010
rajavetrivel24@gmail.com
151 S. VJAYASANTHI,
9092726377 Ms.No.1059/ 2006 22.06.2022
vijayasanthi83@gmail.com
K. VIMALA,
152 96557 44983 Ms.No.1564/2010
vimalaadvocate5@gmail.com
153 E. VENMANI,
9994046802 Ms.No.1383/2011
kevenmani@gmail.com
154 T. VJAYA SHANTHI,
90958 758309 Ms.No.680/2013
vijayashanthi973@gmail.com
155 | V. VAITHIANATHAN,
94869 35241/98426 79799 Ms.No.425/2002
vvvaithi@rediffmail.com
K. VEERAMOORTHI,
156 74488 23556 Ms.No.330/2009
VEERA.K@CCASSOCIATES.IN
U.VADIVARASAN,
157 7200099451 Ms.No.3715/2011
vadivarasan87@gmail.com
158 K. VJAYABHARATHI,
90035 70740 Ms.No.3789/2011
vijayabharathiballb@gmail.com
S. VIJAYABASKARAN,
159 | 98435 38505 Ms.No.310/2009
adv_vbaskie@yahoo.co.in
R. VENKADESH,
160 | 96776 75520 Ms.No.3269/2012
Rm.venkadeshbl87@gmail.com
S. YOUVARADJANE,
94439 58583 Ms.No.1166/2002
161 ள்‌ ்‌
yuviadv@gmail.com \
By’

<!-- page 10 -->

௩
3 9
6 KARAIKAL REGION
ஓ Name &Address
N Enrol. No. Date of Interview
° | Thiru/Tmt
P.S. AMURDHESWARANATHAN,
1 98427 77234 Ms.No.854/ 2008
Advspsnathan@gmail.com
G. BASKARAN,
2 | 9842403993 Ms.No.64/1986
advgbaskar@gmail.com
K. GNANASEKARAN,
3 9442225827 Ms.No.19/1987
ContactAdv.gnanam@Gmail.com
P. MUTHUKRISHNAN,
8300173215 Ms.No.411/1992
M. MURUGANANDAM,
5 9362911119 Ms.No.1616/2003
advmurug79@gmail.com
A. MAGESH BALA,
9894376363 | Ms.No.1622/2009
Ir.magesh@gmail.com |
T.P.J. NANDAKUMAR,
7 9629720130 Ms.No.3148/2009
tpjnandakumar31@gmail.com |
S.A. SULTAN ABDUL KADER,
99524 61077 Ms.No.372/1979
sultanabdulkader1954@gmail.com
R. SURESH,
98650 15799 Ms.No.1702/2004
sureshadv19@gmail.com
J. SENTHIL RAGHAVAN,
10 | 9842283250 / 04368-221717 Ms.No.905/2007
senthil_rag@yahoo.co.in
S. SAKTHIVEL,
71 | :04368-228755 Ms.No.3908/2012
p.sakthillb@gmail.com
A. SENTHILKUMAR,
12 | 9843275510 / 04368-225750 Ms.No.1109/2002
senthilkumar75510@gmail.com
S. THIRUMURUGAN,
13 | 98426 56138 Ms.No.973/1999
thirumuruganvakkil@gmail.com
A. THIRUMAL VALAVAN,
14 | 04368-231610 Ms.No.631/1997
harshatitu@rediffmail.com
K. THAMIZHARASAN,
15 | 9500178050 Ms.No.1431/2010
thamizhk81@gmail.com
H. UMAR FAROOK,
16 | 93629 10324 Ms.No.1650/2006
Umarfarookuk@gmail.com
M. UMAMAHESWARI,
17 | Umanaban82@gmail.com Ms.No.895/2005
D. VINCENTRAJ,
18 | 97881 08415 Ms.No.1214/2008
vince.mathal@gmail.com
K. VEERAPILLAI,
19 | 9865532667 Ms.No.469/1985
kveerapillai@gmail.com
S. VETTRY VEL,
20 (9952525958 Ms.No.3204/2012
vettry84@gmail.com \
ஷ்‌ ட”
