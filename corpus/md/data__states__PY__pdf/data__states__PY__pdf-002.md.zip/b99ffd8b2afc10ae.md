---
doc_id: "b99ffd8b2afc10ae"
source_url: "https://law.py.gov.in/docs/Stipend.pdf"
ministry: "Law Department, Puducherry"
title: "Grant of Stipend to Junior Advocates Scheme Rules, 2020"
date: ""
pages: 5
method: "tesseract:tam+eng"
script: "LATIN"
needs_ocr: false
sha1: "d8d8e6cb11c0af87"
---

<!-- page 1 -->

GOVERNMENT OF PUDUCHERRY
: ABSTACT
Law Department - The Government of Puducherry Grant of Stipend to Junior Advocates
Scheme Rules, 2020 - Notification - Orders - Issued.
ன வை அவை அ அ அ அப ப ப ப ப அ அ அ அ அ அ அ அ அ அ
LAW DEPARTMENT
G.O.Ms.No.29/2020-LD Puducherry, the 278 December 2020
ORDER:
The following Notification shall be published in the in the Official Gazette of Government
of Puducherry.
NOTIFCATION
Approval of the Lieutenant-Governor, Puducherry is conveyed for the “the Government
of Puducherry Grant of Stipend to Junior Advocates Scheme Rules, 2020”. The details of
the Scheme are as appended to this Notification.
2. This issues with the concurrence of the Finance Department, Puducherry vide
|.D.No.2232/FC/FD/F5/A3/2019, dated 28.11.2019.
/ BY ORDER OF THE LIEUTENANT-GOVERNOR //
(J. JULIET PUSHPA)
SECRETARY TO GOVERNMENT (LAW)

To

The Director of Stationery & Printing,

Puducherry - with a request to arrange for publication of the above notification in
the official gazette of Puducherry and 25 copies of the notification as
published may kindly be provided for reference and record of this
Office.

Copy to:-

1. The Hon'ble Chief Judge, Puducherry

2. The Director, Directorate of Prosecution, Puducherry

3. The Government Pleader. Puducherry.

4. The Under Secretary to Govt., (Finance), Finance Department, Puducherry.
5. The President, Bar Association, Puducherry, Karaikal, Mahe & Yanam.

6. The General Secretary, Bar Association, Puducherry.

7. Spare copy.

<!-- page 2 -->

|
GOVERNMENT OF.PUDUCHERRY GRANT OF STIPEND TO JUNIOR ADVOCATES
: SCHEME RULES, 2020
ல்க

1. Short title, extent and commencement :- ,

(i) These rules may be called “the Government of Puducherry Grant of Stipend to
Junior Advocates Scheme Rules, 2020".

(ii) These rules shall apply to the whole of the Union territory of Puducherry

(ili) They shall be deemed to have come into force with effect from 01.01.2018.

2. Definitions :- In these rules, unless the context otherwise requires:

(a) | “Junior Advocate” shall mean a Law Graduate, who has enrolled in the Bar Council of
Tamil Nadu and Puducherry and who has passed the All India Bar Examination (AIBE)
conducted by the Bar Council of India, a Statutory Body constituted under the Advocates
Act, 1961 (Central Act of 1961) and whose annual family income does not exceed
Rupees two lakhs per annum;

(b) “Government” means the Administrator of the Union territory of Puducherry appointed by
the President of India under Article 239 of the Constitution.

(6) “State Level Committee” shall mean the Committee constituted for the purposes of these
tules with the following composition:

(i) Secretary to Government, Law Department, Puducherry --- Chairman
(ii) President, Bar Association, Pondicherry --- Vice-Chairman
(iii) Six members of Bar Association, three members given
by Pondicherry Bar Association and the --- Members
President of Bar Association of Karaikal, Mahe
and Yanam
(iv) Deputy Secretary / Under Secretary,
Finance Department, Puducherry --- Member
(v) Government Pleader, Puducherry -- Member
(vi) Director of Prosecution, Law Department, Puducherry --- Member Secretary

(d) “Stipend amount” shall be as decided by the Government from time to time and

payable every month to the eligible Junior Advocates;

(6) “Union territory” shall mean the Union territory of Puducherry.

3. Object :- The object of the Scheme is to provide for monthly financial assistance to 25

numbers of young Junior Advocates in the Union territory of Puducherry, every year, for a

period of two years or till starting independent practice, whichever is earlier, from the date of

passing the Ail India Bar Examination (AIBE).

4, Eligibitity - To avail the financial assistance under this Scheme, the applicant shall be:-

(0) a citizen of India;

di) a native by birth or resident of the Union territory of Puducherry for a continuous period
of five years who has pursued Law degree in any Government
Law College;

(iii) a Junior Advocate as defined in 2(a) of these rules and who is not above 30 years of
age, and

(iv) shalt comply with rule 6 of these rules during the period of financial assistance.

2/-

<!-- page 3 -->

1
ன ர 2: :
5. Making of application :- An application for the payment of stipend shall be submitted to the
General Secretary, Bar Association, Pondicherry in respect of Puducherry region: in respect of
Kariakal, Mahe and Yanam regions, application shall be submitted to the respective President of |
the Bar Association concerned. The application shall be submitted alongwith the following
documents:-
(i) Attested copy of the Enrolment Certificate.
(ii) Attested copy of the Certificate evidencing pass in the All India Bar Examination.
(iii) Income Certificate issued by an Officer not below the rank of Deputy Tahsildar.
(iv) Certificate of Nativity by Birth or by continuous residence of five years in the Union
territory issued by an Officer not below the rank of Deputy Tahsildar, Ration Card
Election, ID Card, Aadhaar Card, Bank Pass-book (first page) and PAN card.
(v) Attendance Certificate and Conduct Certificate issued by the President/Secretary of
the Bar Association and Member Secretary, Union Territory of Puducherry Legal
Services Authority.
(vi) Attendance Certificate issued by the Senior Advocate with whom he is attached.
(vii) Applications will be called for in the month of April, every year.
6. Requisite conditions for grant of monthly stipend :- The Junior Advocate shall :-
(i) regularly attend the Free legal aid camps conducted by the Union territory of
Puducherry Legal Services Authority;
(ii) conduct the legal aid cases allotted to him / her by the Legal Aid Committee and
the respective Courts;
(iii) assist the Courts as an Intern;
(iv) shall regularly attend the Chamber of the Senior Advocate with whom he is
attached.
(v) shall obtain regular practice certificate, every three months from the
President/Secretary of the Bar Association concerned.
(vi) shall assist on rotation basis, the Government Pleader /Public Prosecutor or
Additional Government Pleader / Additional Public Prosecutor or Assistant
Government Pleader or Assistant Public Prosecutor within the concerned area of
practice atleast for a period of three months.
(vil) The performance of Junior Advocates shall be reviewed once in six months
before further extending the stipend.
7. Verification and selection of Beneficiaries.- The Member Secretary shall cause to verify
the credentials of the applicants and shall forward the applications of the eligible applicants to
the State Level Committee. The Committee will select the beneficiaries. The marks obtained in
the qualifying examination that is, Bachelor's Degree in Law and the marks secured in the 12"
Std., Board examination with negative marks for additional attempts will be the criteria for merit.
The Rule of reservation notified by the Government of Puducherry for Government employment
shall be followed and one-third of the beneficiaries shall be women. The decision of the
Committee shall be final.
அர்‌

<!-- page 4 -->

7 3:
8. Award of Stipend :- The Member Secretary shall forward the list of the beneficiaries selected
by the State Level Committee to the Law Department for obtaining expenditure sanction from
the Government.
9. Mode of Payment.- The monthly stipend shall be Rs.3,000/- per month from 01.01.2018 to
31.03.2019 and @ Rs.5,000/- per month with effect from 01.04.2019 and shall be disbursed to
the selected beneficiaries after obtaining an Undertaking from them to the effect that in the
event of the beneficiary leaving the profession within a period of five years from the date of his /
her enrolment except those who have entered Government service, the entire stipend received
shall be refunded by them with 6% Simple Interest to the Government. The stipend amount shall
be released by Direct Benefit Transfer (DBT) Method. The performance of the Junior Advocates
shall be reviewed once in six months before further extending the period.
10. Interpretation.- If any doubt arises as to the interpretation of the above rules, the same
shall be referred to the Secretary to Government (Law), Puducherry and his decision thereon
shall be final and binding.
// BY ORDER OF THE LIEUTENANT-GOVERNOR //
When”
(J. JULIET PUSHPA)
SECRETARY TO GOVERNMENT (LAW)

<!-- page 5 -->

APPLICATION FOR GRANT OF STIPEND TO JUNIOR ADVOCATES
Self-attested
Passport size
photograph to
be affixed.
1. Name of the Applicant :
2. Father's Name :
3. Sex i Maile / Female
4. Date of Birth ்‌
5. Age i
6. Residential Address :
(proof to be enclosed)
7. Aadhaar Number :
8. Mobile Number ்‌
9. Caste :
10. Community :
11. Religion :
12. Nationality :
13. Enrolment Number and 4
Date of Enrolment
14. Date of passing the All India:
Bar Examination.
15. Preference of Practice : Civil / Criminal
UNDERTAKING
Vee cee SOMMAughterWife ல்‌... cee aged
verre YBAIS AN TESIGING At ப ட ்ப்பப்ப்ப்ப்ப்ப்ப்ப்ப்ப்ப்ப்ப்டட
Fr வவ வவ வவ வவவி வவ வவ வவ hereby undertake that the facts stated
above are true to the best of my knowledge, belief and information. in the event of
Suppression of any material fact / misrepresentation of any fact or falsehood, | hereby
undertake to indemnify the Government to the extent of the benefit received by me
under the above Scheme
Date ;
Place : SIGNATURE
