---
doc_id: "679b4abbb6cf9d3c"
source_url: "https://ppclgov.in/admin/dynamic/tender/2w8W.pdf"
ministry: "Puducherry Power Corporation Limited (PPCL), Puducherry"
title: "F-110 inviting offers for Eighth Due Date Extension Tender Notice for the work of Providing and laying precast cover slabs to the cable trench and drains in various location inside the PPCL Campus at T.R.Pattinam, Karaikal.   [ Notice Board ]"
date: ""
pages: 57
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ddffb66c56f87e40"
---

<!-- page 1 -->

AnyScanner

<!-- page 2 -->

AnyScanner

<!-- page 3 -->

AnyScanner

<!-- page 4 -->

PUDUCHERRY POWER CORPORTION LIMITED
(A GOVT OF PUDUCHERRY UNDERTAKING)
T.R. PATTINAM, KARAIKAL.
ITEM RATE
NOTICE INVITING TENDERS

Name of work

: Providing and laying precast cover slabs to the cable
trench and drains in various location inside the PPCL
Campus at T.R.Pattinam, Karaikal.

Estimate cost put to tender

: Rs 4,50,918/-

Earnest Money Deposit

: Rs. 9,050 /-

Performance Guarantee

: 5% of the Tendered Value.

Security deposit

: 5% of Tendered Value.

Cost of tender schedule

: Rs.500+GST @ 5%

Time Allowed

: Four (4) Months.

Total Number of pages

: (54) pages

Time & date of opening of Tender

: 27/06 /2025
EXECUTIVE ENGINEER (Mech)Plant

Page | 1

<!-- page 5 -->

PUDUCHERRY POWER CORPORATION LIMITED
(A Govt. of Puducherry Undertaking)
T.R.Pattinam, Kariakal.

Name of the work: Providing and laying precast cover slabs to the cable trench and
drains in various location inside the PPCL Campus at
T.R.Pattinam, Karaikal.

CORRECTION SLIP No.1

The following corrections shall be deemed to have been made wherever the words mentioned
under the column ‘FOR’ appears in the N.I.T. / AGREEMENT.

Sl.No.

For

Read

1.

President of India/Government

Puducherry Power Corporation Limited

2.

Superintending Engineer

Managing Director, Puducherry Power
Corporation Limited, Puducherry.

3.

Engineer-in-charge

4.

Government

Executive Engineer(Mech)Plant
Corporation

Page | 2

<!-- page 6 -->

PPCL Form -6

PUDUCHERRY POWER CORPORATION LIMITED
(A Govt. of Puducherry Undertaking)
T.R.Pattinam, Karaikal.
NOTICE INVITING TENDER
1. Item rate / rate tenders are invited on behalf of Puducherry Power Corporation Limited from approved
and eligible contractors of C.P.W.D. (and those of appropriate list of Department of Telecommunications,
M.E.S Railways and Puducherry State P.W.D) for the work of Providing and laying precast cover slabs to
the cable trench and drains in various location inside the PPCL Campus at T.R.Pattinam, Karaikal. The
enlistment of the contractors should be valid on the last date of sale of tenders.
In case only the last date of sale of tender is extended, the enlistment of contractor should be valid on the
original date of sale of tenders.
In case both the last date of receipt of application and sale of tenders are extended, the enlistment of
contractor should be valid on either of the two dates i.e original date of sale of tender or on the extended date of
sale of tenders.
1.1.
The work is estimated to cost Rs. Rs 4,50,918 /-This estimate, however is given merely
a rough guide.
1.1.1.
The authority competent to approve NIT for the combined cost and belonging to the major
discipline will consolidate NITs for calling the tenders. He will also nominate Division which will deal with all
matters relating to the invitation of tenders.
For composite tender, besides indicating the combined estimated cost put to tender, should clearly indicate
the estimated cost of each component separately. The eligibility of tenderer will correspond to the combined
estimated cost of different components put to tender.
1.2.
Tenders will be issued to eligible contractors provided they produce definite proof from the appropriate
authority, which shall be to the satisfaction of the competent authority, of having satisfactorily completed
similar works of magnitude specified below:
Criteria of eligibility for issue of tender
documents
Three similar works each costing not less than Rs……………………. lacks or Two similar works each
costing not less than Rs……………………..
lacks or one similar work costing not less than
Rs………………….. lacs in last 7 years ending ……………………. (Date).
For the purpose of this clause ‘Similar Work’ means the works of ………………………………………..
……………………………………………………………………………………………………………………
Note: 1. Above condition is applicable (1) for CPWD as well as Non-CPWD contractors for works estimated
to cost above Rs.20 Crores (2) only for Non-CPWD contractors for works estimated to cost upto Rs.20 Crores.

Page | 3

<!-- page 7 -->

2. The value of executed works shall be brought to current costing level by enhancing the actual value of work at
simple rate of 7% per annum; calculated from the date of completion to the last date of receipt of applications for tender.
Agreement shall be drawn with the successful tenderer on prescribed Form No.7/8 which is available as a Govt.
of India publication Tenderer shall quote his rates as per various terms and conditions of the said form which will form
part of the agreement.
3. The time allowed for carrying out the work will be Four (4) months from the date of start as defined in
schedule ‘F’ or from the first date of handing over of the site, whichever is later, in accordance with the phasing, if any,
indicated in the tender documents.
4. The site for the work is available.
or
The site for the work shall be made available in parts as specified below:
……………………………………………………………………………………………………
5. Applications for issue of forms shall be received by EE PPCL upto 23 /06/2025 (4PM) and tender documents
shall be issued by EE PPCL upto 25/06/2025(4PM).
Tender documents consisting of plans, specifications, the schedule of quantities of the various classes of the work
to be done and the set of terms and conditions of contract to be complied with by the contractor whose tender may be
accepted and other necessary documents can be seen in the Office of the Executive Engineer (Mech.) PPCL,
T.R.Pattinam, Karaikal between hours 11.00 a.m. and 4.00 p.m. from 23/06/2025 to 27/06/2025 everyday except on
Sundays and Public Holidays. Tender documents, excluding standard form, will be issued from his office, during the
hours specified above, on payment.
(i) Rs.500+GST@5% in cash as cost of tender.
6. Tenders, which should always be placed in sealed envelope, with the name of work and due date written on the
envelopes, will be received by the EE PPCL upto 03.30 P.M. on 27/06/2025 and will be opened by him or his
authorised representative in his office on the same day at 04.00 P.M.
6.1. Tenders shall be accompanied with Earnest money of Rs.9,050 /- in cash (upto Rs.10.000/-) Receipt Treasury
Challan / Deposit at call receipt of a scheduled bank/fixed deposit receipt of a scheduled bank/demand draft of a
scheduled bank issued in favour of EE PPCL 50% of earnest money or Rs.20 lakhs, whichever is less, will have to be
deposited in the shape prescribed above and balance amount of earnest money can be accepted in the form of Bank
guarantee issued by a scheduled bank having validity for 6 months or more from the last date of receipt of tenders.
6.2 The tender and the earnest money shall be placed in separate sealed envelopes, each marked ‘Tender’ and
‘Earnest Money’ respectively. In cases where earnest money in cash is acceptable, the same shall be deposited with the
Cashier of the Division and the receipt placed in the envelope meant for earnest money. Both the envelopes shall be
submitted together in another sealed envelope with the name of work and due date of opening written on envelope, which
will be received by the EE PPCL upto 3.30 P.M. on 27/06/2025 and will be opened by him or his authorized
representative in his office on the same day at 4.00 P.M. The envelope marked ‘Tender’ of only those tenderers shall be
opened, whose earnest money, placed in the other envelope, is found to be in order.
7. The contractors whose tender is accepted, will be required to furnish performance guarantee of 5%
(Five percent) of the tendered amount within the period specified in Schedule F. This guarantee shall be in the form of
cash (in case guarantee amount is less than Rs.10,000/-) or Deposit at call receipt of any scheduled

Page | 4

<!-- page 8 -->

bank/Banker’s cheque of any scheduled bank/Demand Draft of any scheduled bank/Pay order of any scheduled bank (in
case guarantee amount is less than Rs.1,00,000/-) or Government securities or Fixed Deposit Receipts or Guarantee Bonds
of any Scheduled Bank or the State Bank of India in accordance with the prescribed form. In case the contractor fails to
deposit the said performance guarantee within the period as indicated in Schedule ‘F’ including the extended period if
any, the Earnest Money deposited by the contractor shall be forfeited automatically without any notice to the Contractor.

8. The description of the work is as follows: Providing and laying precast cover slabs to the cable trench and
drains in various location inside the PPCL Campus at T.R.Pattinam, Karaikal. Copies of other drawings and
documents pertaining to the works will be open for inspection by the tenderers at the office of the above mentioned
officer.
Tenderers are advised to inspect and examine the site and its surroundings and satisfy themselves before
submitting their tenders as to the nature of the ground and sub-soil (so far as is practicable), the form and nature of the
site, the means of access to the site, the accommodation they may require and in general shall themselves obtain all
necessary information as to risks, contingencies and other circumstances which may influence or affect their tender. A
tenderer shall be deemed to have full knowledge of the site whether he inspects it or not and no extra charges consequent
on any misunderstanding or otherwise shall be allowed. The tenderer shall be responsible for arranging and maintaining at
his own cost all materials, tools and plants, water, electricity access, facilities for workers and all other services required
for executing the work unless otherwise specifically provided for in the contract documents. Submission of a tender by a
tenderer implies that he has read this notice and all other contract documents and has made himself aware of the scope and
specifications of the work to be done and of conditions and rates at which stores, tools and plant, etc., will be issued to
him by P.P.C.L and local conditions and other factors having a bearing on the execution of the work.
9. The competent authority on behalf of PPCL, T.R.Pattinam, Karaikal does not bind itself to accept the lowest or
any other tender and reserves to itself the authority to reject any or all the tenders received without the assignment of any
reason. All tenders, in which any of the prescribed condition is not fulfilled or any condition including that or conditional
rebate is put forth by the tenderer shall be summarily rejected.
10. Canvassing whether directly or indirectly, in connection with tenders is strictly prohibited and the tenders
submitted by the contractors who resort to canvassing will be liable to rejection.
11. The competent authority on behalf of PPCL, T.R.Pattinam, Karaikal reserves to himself the right of accepting
the whole or any part of the tender and the tenderer shall be bound to perform the same at the rate quoted.
12. The contractor shall not be permitted to tender for works in the CPWD Circle (division in case of contractors
of Horticulture / Nursery category) responsible for award and execution of contracts in which his near relative is posted as
Divisional Accountant or as an officer in any capacity between the grades of Superintending Engineer and Junior
Engineer (both inclusive). He shall also intimate the names of persons who are working with him in any capacity or a
subsequently employed by him and who are near relatives to any gazetted officer in the PPCL, T.R.Pattinam, Karaikal.
Any breach of his condition by the contractor would render him liable to be removed from the approved list of contractors
of this Corporation.
13. No Engineer of gazetted rank or other gazetted officer employed in Engineering or Administrative duties in an
Engineering Department of the Government of Puducherry is allowed to work as a contractor for a

Page | 5

<!-- page 9 -->

period of one year after his retirement from Government service, without the previous permission of the Government of
India in writing. This contract is liable to be cancelled if either the contractor or any of his employees is found any time to
be such person who had not obtained the permission of the Government of India as aforesaid before submission of the
tender or engagement in the contractors’ service.
14. The tender for the works shall remain open for acceptance for a period of ninety days from the date of opening
of tenders, ninety days from the date of opening of financial bid (strike out as the case may be) if any tenderer withdraws
his tender before the said period or issue of letter of acceptance whichever is earlier or makes any modifications in the
terms and conditions of the tender which are not acceptable to the Corporation then the corporation without prejudice to
any other right or remedy, be at liberty to forfeit 50% of the said earnest money as aforesaid. Further the tenderer shall not
be allowed to participate in the re-tendering process of the work.
15. This notice inviting tender shall form a part of the contract document. The successful tenderer/contractor, on
acceptance of his tender by the Accepting Authority, shall, within 15 days from the stipulated date of start of the work,
sign the contract consisting of-(a) The notice inviting tender, all the documents including additional conditions, specifications and drawings, if
any forming the tender as issued at the time of invitation of tender and acceptance thereof together with any
correspondence leading thereto.
(b) Standard C.P.W.D form

7 /8

16. For Composite Tenders:
16.1.1. The tenderer must associate with himself agencies of the appropriate class eligible to tender for the other
components individually.
16.1.2. It will be obligatory on the part of the tenderer to sign the tender document for all the components. (The
schedule of quantities, conditions and special conditions etc.)
16.1.3. After the work is awarded, the contractor will have to enter into separate agreements for each component
with the Officer concerned.
16.1.4. Executive Engineer-in-charge of minor component shall make interim payments in respect of minor
component of work. Executive Engineer in charge of the major component shall make the payment against final bill of the
composite contract.
16.2. The Executive Engineer Incharge of the major component will call tenders for the composite work. The cost
of tender document and Earnest Money will be fixed with respect to the combined estimated cost put to tender for the
composite tender. Security Deposit will be worked out separately for each component corresponding to the estimated cost
of the respective component of works. The Earnest Money will become part of the security deposit of the major
component of work.
16.3 On acceptance of the composite tender by the competent authority, the letter of award will be issued by the
Executive Engineer-in-charge of the major component on behalf of the President of India, making it clear in the letter of
award that the contractor will have to execute separate agreements for different components of work with the concerned
officers of the respective discipline. (Designation to be given).
Signature of Executive Engineer (Mech.)Plant
…………………………………………….
For and on behalf of PPCl, T.R.Pattinam, Karaikal.

Page | 6

<!-- page 10 -->

P.W.D. Form 7 / 8
PUDUCHERRY POWER CORPORATION LIMITED
(A Govt. of Puducherry Undertaking) T.R.PATTINAM,
KARAIKAL.
STATE : PUDUCHERRY

CIRCLE

:

REGION : KARAIKAL

DIVISION

:

PPCL, T.R.Pattinam

SUB-DIVISION :

PERCENTAGE RATE TENDER / ITEM RATE TENDER &
CONTRACT FOR WORKS
(A) Tender for the work of:
Providing and laying precast cover slabs to the cable trench and drains in various
location inside the PPCL Campus at T.R.Pattinam, Karaikal.

(i)

To be submitted by 03.30 p.m. on

27/06/2025

to the Executive Engineer / Assistant Engineer, P.P.C.L., T.R. Pattinam,
Karaikal / Puducherry.
(ii)

To be opened in presence of tenderes who may be present at 04.00 p.m. on 27/06/2025
in the Office of the Executive Engineer / Assistant Engineer, P.P.C.L., T.R.Pattinam, Karaikal /
Puducherry.

Issued to:

----------------------------------------------------------------------------------------------------Contractor
Signature of officer issuing the documents------------------------------------------Designation ---------------------------------------------------------------------------------Date of issue --------------------------------------------------------------------------------

Page | 7

<!-- page 11 -->

TENDER
I/We have read and examined the notice inviting tender, Schedule A, B, C, D, E and F. Specifications applicable,
drawings and designs, general rules and directions, conditions of contract, clauses of contract, special conditions, schedule
of rates and other documents and rules referred to in the conditions of contract and all other contents in the tender
document for the work.
I/We hereby tender for the execution of the work specified for the P.P.C.L., within the time specified in Schedule
‘F’, viz., schedule of quantities and in accordance in all respects with the specifications, designs, drawings and
instructions in writing referred to in Rule - 1 General Rules and Directions and in Clause 11 of the Conditions of Contract
and with such materials as are provided for, by, and in respects in accordance with, such conditions so far as applicable.
We agree to keep the tender open for ninety (90) days from the due date of its opening ninety days from the date
of opening of financial bid (strike out as the case may be) and not to make any modifications in its terms and conditions.
A sum of Rs.9,050 /- is hereby forwarded in cash/receipt treasury challan / deposit at call receipt of a scheduled
bank/fixed deposit receipt of scheduled bank / demand draft of a scheduled bank / bank guarantee issued by a scheduled
bank as earnest money. If I/we, fail to furnish the prescribed performance guarantee within prescribed period. I/we, agree
that the said Executive Engineer, PPCL, Puducherry or his successors in office shall without prejudice to any other right
or remedy be at liberty to forfeit the said earnest money absolutely. Further, if I/we fail to commence work as specified,
I/we agree that PPCL or his successors in office shall without prejudice to any other right of remedy available in law be at
liberty to forfeit the said earnest money and the performance guarantee absolutely otherwise the said earnest money shall
be retained by him towards security deposit to execute all the works referred to in the tender documents upon the terms
and conditions contained or referred to therein and to carry out such deviations as may be ordered, upto maximum of the
percentage mentioned in Schedule ‘F’ and those in excess of that limit at the rates to be determined in accordance with the
provision contained in Clauses 12.2 and 12.3 of the tender form.
Further, I /We agree that in case of forfeiture of earnest money or both Earnest Money & Performance Guarantee
as aforesaid, I / We shall be debarred for participation in the re-tendering process of the work.
I/We hereby declare that I/we shall treat the tender documents, drawings and other records connected with the
work as secret / confidential documents and shall not communicate information/derived there from to any person other
than a person to whom I/we am/are authorized to communicate the same or use the information in any manner prejudicial
to the safety of the State.

Dated:…………………………..

Signature of Contractor
Postal Address

Witness:

Address:

Occupation:

Page | 8

<!-- page 12 -->

ACCEPTANCE
The above tender (as modified by you as provided in the letters mentioned hereunder) is accepted by me for and
on behalf of the President of India for a sum of Rs. --------------------------- (Rupees ……………………
………………………………………………………………………………………… only).

The letters referred to below shall form part of this contract agreement.

(a)
(b)
(c)

For & on behalf of P.P.C.L
Signature

:………………………..

Designation

:…………………….…

Date:………………………

Page | 9

<!-- page 13 -->

PUDUCHERRY POWER CORPORATION LIMITED
(A Govt. of Puducherry Undertaking)
T.R.PATTINAM, KARAIKAL.

General Rules
and Directions:

1. All works proposed for execution by contract will be notified in a form of invitation to tender posted in
public places and signed by the officer inviting tender or by publication in news papers as the case may be.
This form will state the work to be carried out, as well as the date for submitting and opening tenders and
the time allowed for carrying out the work; also the amount of earnest money to be deposited with the application, and
the amount of the security deposit and performance guarantee to be deposited by the successful tenderer and the
percentage, if any, to be deducted from bills. Copies of the specifications, designs and drawings and any other
documents required in connection with the work signed for the purpose of identification b y the officer inviting
tender shall also be open for inspection by the contractor at the office of officer inviting tender during office hours.
2. In the event of the tender being submitted b y a firm, it must be signed separately b y each partner thereof,
or in the event of the absence of an y partner, it must be signed on his behalf by a person holding a power of attorney
authorising him to do so, such power of attorney to be produced with the tender, and it must disclose that the firm
is duly registered under the Indian Partnership Act.1952.
3. Receipts for payments made on account of work, when executed by a firm, must also be signed by all the
partners, except where contractors are described in their tender as a firm, in which case the receipts must be signed
in the name of the firm by one of the partners, or by some other person having due authority to give effectual receipts
for the firm.

Applicable for Item
Rate Tender only
(CPWD-8):

4. Any person who submits a tender shall fill up the usual printed form, stating at what rate he is
willing to undertake each item of the work. Tenders which propose any alteration in the work specified in the said
form of invitation to tender or in the time allowed for carrying out the work, or which contain any other conditions
of an y sort, including conditional rebates will be summarily rejected, No single tender shall include more than one
work but contractors who wish to tender for two or more works shall submit separate tender for each. Tender shall
have the name and number of the works to which they refer written on the envelopes.
The rate(s) and/or amount(s) must be quoted in decimal coinage Amounts must be quoted in full rupees by
ignoring fifty paise and less and considering more than fifty paise as rupee one.

Applicable for
Percentage Rate
Tender
only
(CPWD-7)

4.(a) In case of Percentage Rate tenders, tenderer shall fill up the usual printed form, stating at what
entage below/above (in figures as well as in words) the total estimated cost given in Schedule of Quantities at
Schedule-A, he will be willing to execute the work. Tenders, which propose any alteration in the work specified in
perc
the said form of invitation to tender, or in the time allowed for carrying out the work, or which contain any other
conditions of any sort, including conditional rebates will be summarily rejected.
No single tender shall include more than one work, but contractors who wish to tender for two or more
works shall submit separate tender for each. Tender shall have the name and number of the works to which they
refer, written on the envelopes.

Page | 10

<!-- page 14 -->

GENERAL RULES & DIRECTIONS

5. The officer inviting tender or his duly authorised assistant will open tenders in the presence of an y
intending contractors who may be present at the time, and will enter the amounts of the several tenders in a
Comparative Statement in a suitable form. In the event of a tender being accepted, a receipt for the earnest money
shall thereupon be given to the contractor who shall thereupon for the purpose of identification sign copies of the
specifications and other documents mentioned in Rule 1. In the event of a tender being rejected, the earnest mone y
shall thereupon be returned to the contractor remitting the same, without any interest.
6. The officer inviting tenders shall have the right or rejecting all or an y of the tenders and will not be
bound to accept the lowest or an y other tender.
7. The receipt of an accountant or clerk for any money paid by the contractor will not be considered as any
acknowledgment or payment to the officer inviting tender and the contractor shall be responsible for seeing that he
procures a receipt signed by the officer inviting tender or a duly authorised Cashier.
8. The memorandum of work tendered for, and the schedule of materials to be supplied by the Corporation
and their issue rates, shall be filled and completed in the Office of the Officer inviting tender before the tender form
is issued. If a form is issued to an intending tenderer without having been so filled in and incomplete, he shall
request the officer to have this done before he completes and delivers his tender.
9. The tenderers shall sign a declaration under the officials Secret Act 1923, for maintaining secrecy of the
tender documents, drawings or other records connected with the work given to them. The unsuccessful tenderers
shall return all the drawing given to them.
9. A. Use of correcting fluid, any where in tender document is not permitted. Such tender is liable for
rejection.
Applicable for
Item
Rate
Tender
only
(CPWD -8)

Applicable for
Percentage
Rate
Tender
Only (CPWD -7)

10. In the case of item Rate Tenders, only rates quoted shall be considered Any tender containing
percentage below/above the rates quoted is liable to be rejected. Rates quoted b y the contractor in item rate tender in
figures and words shall be accurately filled in so that there is no discrepancy in the rates written in figures and words
However, if a discrepancy is found, the rates which correspond with the amount worked out be the contractor shall
unless otherwise proved by taken as correct. If the amount of an item is not worked out b y the contractor or it does
not correspond with the rates written either in figures or in words then the rates quoted by the contractor in words
shall be taken as correct. Where the rates quoted b y the contractor in figures and in words tally but the amount is not
worked out correctly, the rates quoted by the contractor will unless otherwise proved be taken as correct and not the
amount. In event no rate has been quoted for any item(s), leaving space both in figure(s), word(s), and amount
blank, it will be presumed that the contractor has included the cost of this/these item(s) in other items and rate for
such item(s) will be considered as Zero and work will be required to be executed accordingly.
10.(a) In case of Percentage rate Tenders only percentage quoted shall be considered. Any tender
containing item rates is liable to be rejected. Percentage quoted by the contractor in percentage rate tender shall be
accurately filled in figures and words, so that there is no discrepancy. However, if the contractor has worked out
the amount of the tender and if an y discrepancy is found in the percentage quoted in words and figures, the
percentage which corresponds with the amount worked out by the contractor shall, unless otherwise roved be taken
as correct. If the amount of the tender is not worked out by the contractor or it does not correspond with the
percentage written either in figures or in words then the percentage quoted by the

Page | 11

<!-- page 15 -->

GENERAL RULES & DIRECTIONS

contractor in words shall be taken as correct. Where the percentage quoted by the contractor in figures
and in words tally but the amount is not worked out correctly, the percentage quoted by the contractor,
will, unless, otherwise proved, be taken as correct and not the amount.
11. In case of any tender where unit rate of any item/items appear unrealistic, such tender will be
considered as unbalanced and in case the tenderer is unable to provide satisfactory explanation such a
tender is liable to be disqualified and rejected.
Applicable for
Item
Rate
Tender
only
(CPWD-8)

Applicable for
Percentage
Rate
Tender
only (CPWD-7)

12. All rates shall be quoted on the tender form. The amount for each item should be worked out
and requisite totals given. Special care should be taken to write the rates in figure as well as in words and
the amount in figure only, in such a way that interpolation is not possible. The total amount should be
written both in figures and in words. In case of figures the word ‘Rs’. should be written before the
figure of rupees and word ‘P’ after the decimal figures e.g., ‘Rs.2.15 P’. and in case of words, the word,
‘Rupees should precede and the word ‘ Paise’ should be written at the end. Unless the rate is in
whole rupees and followed by the word only, it should invariably be upto two decimal places.
While quoting the rate in schedule of quantities the word ‘only’ should be written closely following the
amount and it should not be written in the next line.
12. (a) In Percentage Rate Tender, the tenderer shall quote percentage below/above (in figures as
well as in words) at which he will be willing to execute the work. He shall also work out the total
amount of his offer and the same should be written in figures as well as in words in such a way that no
interpolation is possible. In case of figures the word ‘Rs’. should be written before the figure of
rupees and word P after the decimal figures, e.g. ‘Rs.2.15P and in case of words, the word ‘Rupees’
should precede and the word ‘Paise’ should be written at the end.
13. The contractor shall be required to deposit an amount equal to 5% of the tendered value of
the work as performance guarantee in the form of an irrevocable Bank Guarantee bond of any Scheduled
Bank or State Bank of India in accordance with the form prescribed or in cash or in the form of
Government security fixed deposit receipt etc., as in the case of recovery of security deposit within 15
days of the issue of letter of intent but before award of work. This period can be further extended by the
Engineer-in-Charge up to a maximum period of 7 days on written request of the contractor.
13A. A sum @ 10% of the gross amount of the bill shall be deducted from each running bill of
the contractor till the sum along with sum already deposited as earnest money will amount to security
deposit of 5% of the tendered value of the work (Bank Guarantee is not to be accepted as security
deposit).
13B. The Superintending Engineers / Executive Engineers of the department on evaluation of
tender and if the tender is found that the overall amount quoted is below 15.00%, and less then the
contractor shall be asked to pay an additional performance guarantee amounting to 50% of the difference
between the quoted amount and estimate cost put to tender. Failure to furnish the additional performance
guarantee over and above the normal performance guarantee of 5% within 15 days from the date of
receipt of acceptance letter, shall entitle cancellation of award and forfeiture of EMD furnished.

14. On acceptance of the tender, the name of the accredited representative(s) of the
contractor, who would be responsible for taking instructions from the Executive Engineer
shall be communicate in writing to the Executive Engineer.

Page | 12

<!-- page 16 -->

GENERAL RULES & DIRECTIONS

15. This work is covered under Puducherry Goods and Services Act 2017 and hence the contractors are
requested to quote the rates including the effect of GST. Additional/ separate claim for any recovery on GST will
NOT be entertained on any account after the award of work. The payment is also liable for TDS as instructed
by the Commercial Tax Department based on GST.
“The Contractor /Service provider shall mandatorily furnish the following documents to the
Commissioner, Commercial Tax:
i)
Copy of the work order.
ii)
HSN1 Code of Goods and Service Accounts code of Services which shall be supplied during the
execution of the Contract.
iii)
GST Rate at which the GST would be paid to the commercial Tax Department against each of
the items in (ii) above.
The information shall be submitted to the Commissioner, Commercial Tax , with a copy to the
Procuring/Government Entity, within 15 calendar days of receipt of the Work Order.”

16. The contractor shall give a list of both gazetted and non-gazetted C.P.W.D. employees related to
him.
17. The tender for the work shall not be witnessed by a contractor or contractors who himself/themselves
has/have tendered or who may and has/have tendered for the same work. Failure to observe this condition would
render, tenders of the contractors tendering, as well as witnessing the tender, liable to summary rejection.
18. The tender for composite work includes in addition to building work, all other works such as sanitary and
water supply installation, drainage installation, electrical work, horticulture work, roads and paths etc. The tenderer
apart from being a registered Contractor (B & R) of appropriate class, must associate himself with agencies of
appropriate class which are eligible to tender for sanitary and water supply drainage, electrical and horticulture
works, in the composite tender.
19. The contractor shall submit list of works which are in hand (progress in the following form:
Name of
Work

Name and particulars of Divn.
Where work is being executed

Value of
work

Position of
works in progress

Remarks

(1)

(2)

(3)

(4)

(5)

20. The contractor shall comply with the provisions of the Apprentices Act 1961, and the rules and orders
issued there under from time to time. If he fails to do so, his failure will be a breach of the contract and the
Superintending Engineer / Executive Engineer may in his discretion without prejudice to any other right or remedy
available in law cancel the contract. The contractor shall also be liable for any pecuniary liability arising on account of
any violation by him of the provisions of the said Act.
21. The Contractor / Firm Must obtain necessary prior permit from Pondicherry Ground water Authority for
the water requirement of the Proposed Construction / road work which will be met out either from tube well or
transportation through tanker Lorries before the Commencement of construction work.
22. The issues for which contractors seeking arbitration shall be referred to the Dispute Redressal
Committee (DRC) which is constituted vide circular No. 604/PW/CE/W/EE(P)/AE(P)1/2013-14 dated 1605-2013 at the first instance and then the proposal shall be referred to appointment of Arbitrator as per the provisions
under the General conditions of Contract.

Page | 13

<!-- page 17 -->

CONDITIONS CONTRACT

CONDITIONS OF CONTRACT
Definitions:

1. The ‘Contract’ means the documents forming the tender and acceptance thereof and the formal
agreement executed between the competent authority on behalf of the President of India and the contractor, together
with the documents referred to therein including these conditions, the specifications, designs, drawings and
instructions, issued from time to time b y the Engineer-in-chare and all these documents taken together, shall be
deemed to form one contract and shall be complementary to one another.
2. In the contract the following expressions shall, unless the context otherwise requires, have the meanings,
hereb y respectively assigned to them:
(i) The expression ‘Works’ or ‘Work’ shall, unless there be something either in the subject or context
repugnant to such construction, be construed and taken to mean the works b y or by virtue of the contract contracted
to be executed whether temporary or permanent, and whether original, altered, substituted or additional.
(ii) The ‘Site’ shall mean the land / or other places on into or through which work is to be executed under
the contract or any adjacent land, path or street through which work is to be executed under the contract or any
adjacent land, path or street which may be allotted or used for the purpose or carrying out the contract.
(iii) The ‘Contractor’ shall means the individual firm or company, whether incorporated or not,
undertaking the works and shall include the legal personal representative of such individual or the persons
composing such firm or company, or the successors of such firm or company and the permitted assignees of such
individual, firm or company.
(iv) The ‘President’ means the P.P.C.L., and his successors.
(v) The ‘Engineer-in-charge’ means the Engineer Officer who shall supervise and be in-charge of the
work and who shall sign the contract on behalf of the President of India as mentioned in Schedule ‘F’ hereunder.
(vi) ‘Corporation’ or ‘’Puducherry Power Corporation Limited’ shall mean the Puducherry Power
Corporation Limited.
(vii) The terms ‘Director General of Works’ includes Additional Director General and Chief Engineer of
the Zone.
(viii) Accepting authority shall mean the authority mentioned in Schedule ‘F’.
(ix) Expected Risk are risks due to riots (other than those on account of contractor’s employees) war
(Whether declared or not) invasion, act of foreign enemies, hostilities, civil war, rebellion revolution, insurrection,
military or usurped power, any acts of Corporation damages from aircraft, act of God, such as earth-quake,
lightening and unprecedented floods, and other causes over which the contractor has no control and accepted as such
by the accepting authority or causes solely due to use or occupation by Government of the part of the works in
respect of which a certificate of completion has been issued or a cause solely due to Corporation faulty design of
works.
(x) Market rate shall be the rate as decided by the Executive Engineer on the basis of the cost of materials
and labour at the site where the work is to be executed plus the percentage mentioned in Schedule ‘F’ to cover all
overheads and profits.
(xi) Schedule(s) referred to in these conditions shall mean the relevant schedule(s) annexed to the tender
papers or the standard Schedule or Rates of the Corporation mentioned in schedule ‘F’ hereunder with the
amendments thereto issued upto the date of receipt of the tender.

Page | 14

<!-- page 18 -->

CONDITIONS & CONTRACT

(xii) Department means PPCL which invites tenders on behalf of President of India as specified in
schedule ‘F’.

(xiii) District Specifications means the specifications followed b y the State Government in the area where
the work is to be executed.
(xiv) Tendered value means the value of the entire work as stipulated in the letter of award.
(xv) Date of commencement of work. - The date of commencement of work shall be the date of start as
specified in Schedule F or the 1st date of handing over of the site, whichever is later, in accordance with the phasing
if any, as indicated in the tender document.
Scope
and
performance:

3. Where the context so requires, words imparting the singular only also include the plural and vice versa.
Any reference to masculine gender shall whenever required include feminine gender and vice versa.
4. Headings and Marginal notes to these General conditions of Contract shall not be deemed to form part
there of or be taken into consideration in the interpretation or construction thereof or of the contract.
5. The contractor shall be furnished, free of cost one certified cop y of the contract documents except
standard specifications, Schedule of Rates and such other printed and published documents, together with all
drawings as may be forming part of the tender papers. None of these documents shall be used for any purpose other
than that of this contract.

Works to be
carried out:

6. The work to be carried out under the contract shall, except as otherwise provided in these conditions,
include all labour, materials, tools, plants, equipment and transport which may be required in preparation of and for
and in the full and entire execution and completion of the works. The descriptions given in the Schedule of
Quantities (Schedule - A) shall, unless otherwise stated, be held of include wastage on materials, carriage and
cartage, carrying and return of empties hosting, setting, fitting and fixing in position and all other labours necessary
in and for the full and entire execution and completion of the work as aforesaid in accordance with good practice
and recognized principles.

Sufficiency of
tender:

7. The contractor shall be deemed to have satisfied himself before tendering as to the correctness and
sufficiency of his tender for the works and of the rates and prices quoted in the schedule of quantities, which rates
and prices shall, except as otherwise provided, cover all his obligations under the contract and all matters and things
necessary for the proper completion and maintenance of the works.

Discrepancies
8. The several documents forming the contract are to be taken as mutually explanatory of one another,
and adjustment detailed drawings being followed in preference to small scale drawing and figured dimensions in preference to scale
of errors:
and special conditions in preference to general conditions.

8.1 In the case of discrepancy between the schedule of quantities, the specifications and /or the drawings,
the following order of preference shall be observed.

(i) Description of schedule of quantities.
(ii) Particular specification and special conditions, if any

Page | 15

<!-- page 19 -->

CONDITIONS & CONTRACT

(iii) Drawings
(iv) CPWD, specifications,
(v) Indian standard specifications of B.I.S.
8.2 If there are varying or conflicting provisions made in any one document forming part of the contract,
the Accepting Authority shall be the deciding authority with regard to the intention of the document and his decision
shall be final and binding on the contractor.
8.3. Any error in description, quantity or rate in Schedule of Quantities or any omission there from shall not
vitiate the contract or release the contractor from the execution of the whole or any part of the works comprised
therein according to drawings and specifications or from any of his obligations under the contract.
Signing of contract:

9. The successful tenderer / contractor, on acceptance of his tender by the Accepting Authority shall, within
15 days from the stipulated date of start of the work sign the contract consisting of:
(i) The notice inviting tender, all the documents including drawings, if any, forming the tender as issued at the
time of invitation of tender and acceptance thereof together with any correspondence leading thereto.
(ii)

Standard CPWD Form as mentioned in schedule ‘F’ consisting of:

(a)
Various standard causes with corrections upto the date stipulated in schedule ‘F’
alongwith annexures thereto.
(b)

CPWD safety code.

(c)
Model Rules for the protection of health, sanitary arrangements for workers employed b y CPWD or
its contractors.
(d)

CPWD Contractor’s Labour Regulations.

(e)

List of Acts and omissions for which fines can be imposed.

(iii)

No payment for the work done will be made unless contract is signed by the contractor.

Page | 16

<!-- page 20 -->

PROFORMA OF SCHEDULES
SCHEDULE’A’
Schedule of quantities

Name of Work:
Item No.

Providing and laying precast cover slabs to the cable trench and drains in various location inside the PPCL Campus at T.R.Pattinam, Karaikal.

Description of items

Qty

Unit

Rate
In figures

1

2

3

Providing and fixing precast reinforcement cement concrete slab in cable
trenches, drain and the like including setting in cement mortar 1:3 ( one
cement : three coarse sand) cost of required centering, shuttering, and
finishing with neat cement punning on exposed surfaces but excluding
cost of reinforcement with 1:2:4 ( 1 cement : 2 coarse sand : 4 graded
stone aggregate 20mm nominal size).
Code No: 5.22A.6
Steel reinforcement for R.C.C.work including straightening, cutting,
bending, placing in position and binding all complete above plinth level Thermo -Mechanically treated bars (TISCON / VIZAG / IISCO / SAIL /
JSW) Fe - 415 or more
Removing the existing damaged pre – cast slabs in the drains, cable
trenches & the like, and disposal of the damaged slabs by mechanical
transport to the low lying area of PPCL residential complex area,
including loading conveyance and unloading etc complete as directed by
Engineer – in – charge.

Page | 17

14

Cum

1540

Kg

14

Cum

Total
In words

<!-- page 21 -->

SCHEDULE “B”
Schedule of materials to be issued to the contractor
S.No.

Description

Quantity

Rates in figures & words at

Place of issue

which the material will be

of item

charged to the contractor
1

2

3

4

5

-------Contractor’s own arrangements -----------

SCHEDULE “C”
Tools and plants to be hired to the contractor
Sl.No.

Description

Hire charges per day

Place of issue

1

2

3

4

-------NIL--------

SCHEDULE “D”
Extra schedule for specific requirement/document for the work. if any.
-------NIL--------

SCHEDULE “E”
Reference to General Conditions of contract:General Conditions of Contract for
PWD works (2014)231

18

<!-- page 22 -->

Name of Work

Providing and laying precast cover slabs to
the cable trench and drains in various
location inside the PPCL Campus at
T.R.Pattinam, Karaikal.

Estimated cost of work

Rs 4,50,918/-

(i) Earnest money

Rs.9,050 /-

(ii) (a)Performance Guarantee

5% of tendered value.

(b)

Additional

Performance 50% of difference in cost between the

Guarantee (in case of tender quoted amount and estimate cost put to
which is below 15.00% and tender
more than 15.00% below)
(iii) Security Deposit
2.5% of the tendered value
(or)
5% of tendered value

19

<!-- page 23 -->

SCHEDULE “F”
GENERAL RULES & DIRECTIONS
Officer inviting tender

Executive

Engineer,(Mech)Plant,

PPCL,

T.R.Pattinam.
Maximum

percentage

for

quantity of items of workto be
See below

executed beyond which rates
are

to

be

determined

in

accordance with Clauses 12.2 &
12.3
Definitions:
2(v) Engineer-in-Charge

Executive

Engineer,(Mech)Plant,

PPCL,

T.R.Pattinam.
2(viii) Accepting Authority

Executive

Engineer,(Mech),

PPCL,

T.R.Pattinam.
2(x)

Percentage

on

cost

of

materials and Labour to cover 15%
all overheads and profits.

2(xi)

Standard Schedule of Puducherry Schedule of Rates for the year

Rates

2024-25 applicable to Karaikal region

2(xii) Department

PPCL

9(ii)
Form

Standard PWD contract GCC 2014 (PWD Form 7/8) as modified
& corrected upto date.

20

<!-- page 24 -->

bv
Clause 1

(i)

Time allowed for submission of
Performance Guaranteefrom the
date

of

issue

of

letter

15days

of

acceptance
(ii)

Maximum

allowable

extension

with late fee @0.1% per day of

7 days

performance Guarantee amount
beyond the period provided in (i)
(1 to 15 days to be filled by NIT

above....

approving authority)

Clause 2

Authority

for

fixing The

compensation under clause 2

Clause 2A

Incentive for early completion of

Managing

PPCL, T.R.Pattinam.

Deleted

work
Clause 5

Number of days from the date of
issue of letter of acceptance for
reckoning date of start

21

Director,

10 days

<!-- page 25 -->

Mile stone(s) as per table given below:
Sl.

Description of

Time allowed in days

No.

Milestone(Physical)

(from date of start)

Amount to be with-held in
case of non achievement
of milestone

1.
2.
3.
4.

Time allowed for execution of work .Four (4) months
(Or)
Sl.
No.
1.

Financial Progress

4.

(of

the

(of

the

(of

the

work)

3/8th (of the whole 1/2
work)

3.

(from date of start)

1/8th (of the whole 1/4th
work)

2.

Time allowed in days

work)

3/4th (of the whole 3/4th
work)

work)

Full

Full

Amount to be with-held in
case of non achievement of
milestone

whole In the event of not achieving
the necessary progress as
assessed from the running
of
the
whole payments,1%
tendered value of work will
be withheld automatically
whole for
failure
of
each
milestone.without
any
notice to the contractor.

Authority to decide:
(i)

Extension of time

: Executive Engineer,(Mech)Plant, PPCL, T.R.Pattinam.

(ii)

Rescheduling of mile stone : Executive Engineer,(Mech)Plant, PPCL,
T.R.Pattinam.

22

<!-- page 26 -->

(iii)

Shifting of date of start in case
of delay in handing over of site: Executive Engineer,(Mech)Plant, PPCL,
T.R.Pattinam.

Clause 6 (or) 6A

Measurement of work done (or)
Computerised Measurement Book

Clause 7

6

Gross work to be done together
with net payment /adjustment of

Rs:1,12,730/-

advances for material collected, if
any since the last such payment
for

being

eligible

to

interim

payment

Clause 10A
List of testing equipment to be provided by the contractor at site lab:

---NIL---

Applicable /
Clause 10B(ii)

: Mobilisation Advance

23

Not applicable

<!-- page 27 -->

Clause 10C

:

Applicable / Not applicable

Component of labour
25 %

expressed as percent of value
of work
Clause 10CA
S.N.

: Applicable / Not applicable

Materials

Nearest Materials (other than cement,

Base Price and its

covered

reinforcement

corresponding

Underthis clause

bars,

the

structural

steel and POL) for which All India

period

of

Wholesale Price Index to be followed

materials

all

the

covered

under Clause10 CA*

*

1.

Cement

2.

Steel
reinforcement
bars

---

3.

Bitumen

---

4.

POL

---

---

As per PSR 2024-25
applicable

to

Karaikal region.

Includes Cement component used in RMC brought at site from outside
approved RMC plants,if any.

**

Base price and its corresponding period of all the materials covered under
Clause10 CA is to be mentioned at the time of approval of NIT. In case of
recall of tenders, the base price may be modified by adopting latest base price
and its corresponding period.

Clause 10CC

: Applicable / Not applicable

24

<!-- page 28 -->

Clause 10CC

Clause 10 CC to be applicable in contracts
with

stipulated

periodof ……………………..month
Schedule of completionexceedingtheperiodshowninnextco s
component
lumn
of
other
materials,
Component of civil (except materials
Labour
Xm………………………..
etc.for price coveredUnder Clause 10 CA) /Electrical
%
escalation.
construction Value of work

DELETED

Component of LabourExpressed as percent of Y…………………………..
total value of work
%

Note: Xm.........% should be equal to (100) – (materials covered under clause 10 CA i.e.
Cement, Steel, POL and other material specified in clause 10 CA + Component
of Labour)
Clause 11

Specifications to be followed

C.P.W.D. specifications 2009,

for execution of work

MOST,

MORTH,

CPHEEO

specifications and

manuals

(with

slips

and

IRC

&

correction
subsequent

publications)

Clause 12

Type of work

Maintenance work
Original work

*** To be filled by NIT approving authority either Project and original work or
Maintenance works including works of upgradation, aesthetic, special repair,
addition/alteration in buildings.
The items related to road work like upgradation/improvement of footpath &
central verge, improvement of carriage way by patch repair or
25

<!-- page 29 -->

annual/periodical repairs of road surface and A/R &M/O works pertaining to
road shall be treated as maintenance work.
New road construction works and the strengthening of road surface shall be
considered as original works.
Clause 12.2 & 12.3

Deviation Limit beyond which
clauses 12.2 & 12.3 shall apply 30 %
for building work

12.5

(i)

Deviation Limit beyond which
clauses12.2 & 12.3 shall apply for
foundationwork (except items 100 %
mentioned
in
earth
work
subhead in PSR and related
items)

(ii)

Deviation
Limit
for
items
mentioned in earth
work
subhead of PSR and related items 100 %

Clause 16

Competent

Authority

deciding reduced rates

for The Managing Dirctor,
PPCL, T.R.Pattinam.

Clause 18
List of mandatory machinery,tools & plants to be deployed by the contractor at
site:
1. Central Hot Mix Plant of 40 TPH to 60 TPH capacity with compatible
electronic control system. – 1 no.
2. Hydrostatic Paver finisher with sensor control – 1 no.
3. Vibratory Roller – 1 no.
4. Power Roller 8-10 T – 1 no.
5. Tandem Rollers of 8 to 10 MT Capacity – 2 nos.
6. Water tanker and Tipper / dumper 6 T – 6 Nos.
7. Concrete Mixer – 1 No.
8. Vibrator – 1 No.
9. Motor Grader 75-120 HP – 1 No.
10. Bitumen Sprayer – 1 No.
11. Front loader and sufficient earth moving machineries.End

26

<!-- page 30 -->

Clause 25
Constitution of Dispute Redressal Committee (DRC) will be notified if required.
1. Chairman
2. Member
3. Member
4. Member Secretary

: Chief Engineer, PWD
: Superintending Engineer, Circle-III, PWD, Karaikal
: Superintending Engineer (Not concerned)
: Executive Engineer, BRK, PWD, Karaikal

Clause 36(i)
Requirement of Technical Representative(s) and recovery Rate

2

Graduate
Engineer

Graduate
Engineer
Diploma
Engineer

Civil

Civil
(or)

(Principal
Technical/
Technical
representative)
Principal Technical
Representative

Project
Engineer

/

Site

Engineer

Number

1.

Designation

Minimum
Experience

Minimum
Qualification
No.
of Technical
Representative

Discipline

Sl.

5

1

2

2

5

2

Rate at which recovery
shall be made from the
contractor in the event of
not fulfilling provision of
clause 36(i)
Figures

Words

Rs. 25,000 /- Rupees
twenty
p.m.
five
thousand
per
month
Rs. 15,000 /- Rupees
fifteen
p.m.
thousand
per
month

3

Assistant Engineers retired from Government services that are holding Diploma will
be treated at par with Graduate Engineers.
Diploma holder with minimum 10 year relevant experience with a reputed
construction company can be treated at par with Graduate Engineers for the purpose
of such deployment subject to the condition that such diploma holders should not
exceed 50% of requirement of degree engineers.

27

<!-- page 31 -->

Clause 42

(i) (a)

Schedule
/
statement
for Puducherry Schedule of
determining theoretical quantity
Rates 2024-25 applicable
of cement & bitumen on the basis to Karaikal region printed
byP.W.D.
of Puducherry

(ii)

Variations

permissible

on

theoretical quantities
(a)

Cement:
For works with estimated cost 3% plus/minus
put
to tender not more than Rs.5lakh
For works with estimated cost 2% plus/minus
put to tender more than Rs.5
lakh

(b)

(c)

Bitumen:

2.5% plus & only & NIL on

All works

minus side

Steel

Reinforcement

and 2% plus/minus

structural steel; sections for each
diameter,section and category
(d)

All other materials

NIL

28

<!-- page 32 -->

RECOVERY RATES FOR QUANTITIES BEYOND PERMISSIBLE VARIATION
Sl.

Description of item

Rates in figures and words at which
recovery shall be made from the contractor

No.

Excess beyond
permissible
variation

1.

Cement

2

Steel reinforcement

3

Structural sections

4

Bitumen issued free

5

Bitumen

issued

Less use beyond
permissible variation

at

stipulated fixed price

Clause 47
During the course of contract period, deduction of “CESS” to provide social security
and various welfare benefits through the Puducherry Buildings and other
construction workers Welfare Board under Section 18 of the Building and Other
Construction Workers Cess collection (RECS) Act, 1996, shall be made at the rate of
1% (One Percent) of the gross amount of each bill or as per the advice of the
Government of Puducherry.

29

<!-- page 33 -->

GENERAL CONDITIONS
(1)
The work shall in general be carried out in accordance with CPWD specifications for
works 2009 with correction slips and issued from time to time. Revised CPWD Specification
2009 for cement mortar, cement concrete & RCC.
(2)
However if the said specifications differ from those given in the description of any
particular item in the schedule of quantities and specifications stipulated herein, the latter
shall prevail.
(3)
If the detailed description of any particular item in the schedule of quantities and
specifications finally accepted by the department differs from the particular specifications
given hereunder, the former shall prevail to the extent applicable.
(4)
If the particular specification given hereunder differs from I.S. code provisions, in any
respect, the former shall prevail.
(5)
Wherever any reference to any Indian standard specification occurs in the documents
relating to this contract the same should be inclusive of all amendments issued thereto or
revision thereof if any, upto the date of receipt of tenders.
(6)
Conditions involving any financial implications other than those covered in the
schedule of quantities will not be entertained and such tenders are also liable to be rejected.
(7)
When working near existing structures, care shall be taken to avoid any damage to
such structures, any such damage caused intentionally or unintentionally shall be restored
to original and or acceptable condition and to the satisfaction of the Engineer-in-charge.
(8)
The contractor shall given to the Municipality, Police and other authorities all notices
etc., that may be required to be given as per law and obtain all requisite licenses for
temporary obstructions, enclosures and pay all fees, taxes and charges which may be
leviable on account of the operations during the execution of the contract. No extra claim of
the contractor will be entertained by the department on this account.
(9)
Other agencies doing works related to this project may also simultaneously execute
the works and the contractor shall co-ordinate and co-operate with them as found to be
necessary at no extra cost.
(10) Any cement slurry or lime mortar or any combination thereof or water proofing
material required for continuation from old work is demand to have been in built in the
relevant items themselves and nothing extra shall be paid for the same.
(11) The rate for all items of the work shall be considered as inclusive of pumping out or
bailing out water if required for which no extra payment will be made. This will include

water encountered from any source as rains, flood, and subsoil water table being
high due to any other cause whatsoever.

30

<!-- page 34 -->

CONDITIONS FOR ISSUE OF MATERIALS
The materials shall be issued to the contractor at the place of delivery as
mentioned in schedule ‘B’. If these are delivered at any other site, the difference due
to cartage will be adjusted accordingly. The contractor shall have to cart at his cost
the materials to the site of work as soon as these are issued. The materials shall be
issued between the working hours and as per rules prevails in the stockyard of the
materials as framed from time to time.
The contractor shall bear all incidental charges for cartage, storage and safe
custody of materials. No reimbursement of the expenses will be made by the
department.
The contractor shall construct suitable godown at the site of work for storing
the materials safe against damage of sun, rain, dampness, fire, theft etc. he shall also
employ necessary watch and ward establishment for the purpose.
Cement bags shall be stored in separate godown with pucca floor
weatherproof roofs and walls. Each godown shall be provided with a single door with
two locks. The keys of one lock shall remain with the Department Junior Engineer-incharge of the work and that of the other lock with authorized agent of the
contractor at the site of work so that the cement is removed from the godown
accordingly to the daily requirements with the knowledge of both the parties.
The cement shall be stacked on proper floors consisting of two layers of dry
bricks laid on well-consolidated earth at a level of at least 0.3 meters above ground
level. These stocks shall be in row of 2 and 10 high with a minimum of 0.6 meter
clear space around. The bags would be placed horizontally continuous in each line
as shown in the sketch of C.P.W.D. specification 2009.
The day today receipts and issue accounts of cement shall be maintained buy
the Junior Engineer-in-charge and signed daily by the contractor or his authorized
agent.
MATERIALS OBTAINED FROM DISMANTLEMENT
I.

The contractors, in course of their work, should understand that all
materials (e.g. stone and the other materials) obtained in the work of
dismantling, excavation etc. will be considered PPCL property and issued to
the contractor (if they require the same for their own use) at rates approved
by Government. If these materials are not required by them, they will
dispose of to the best advantage of Corporation.

31

<!-- page 35 -->

DELAY IN OBTAINING MATERIALS BY THE DEPARTMENT
II. Owing to difficulty in obtaining certain materials in the open market, the PPCL
have undertaken to supply materials specified in schedule ‘B’ of the tender forms at
rates stated therein. There may be delay in obtaining the materials by the
Department and the contractor is, therefore required to keep himself in touch with
the day to day position regarding the supply of materials from the Engineer-incharge and to so adjust the progress of their work that their labour may not remain
idle nor may there be any other claim due to so arising from delay in obtaining the
materials. It should be clearly understood that no claim whatsoever shall be
entertained by the PPCL, T.R.Pattinam on account of delay in supplying materials.
III.
M.S. or deformed bars shall be issued in lengths as available in stores. M.S. or
deformed bars shall be issued in straights or in coils as available and nothing extra
shall be payable for straightening the bars. The bars issued in available lengths shall
be cut to the required lengths and nothing extra shall be payable for the same.
IV. The contractor shall have to deposit the approved paints of required color and
shade as per actual requirements of the work to be done with the Engineer-in-charge
at his Departmental Store at the site of work.
The contractor shall be responsible for the water proofness of the roof for one
full monsoon season after the date of completion. He shall rectify the defect noticed
after due intimation in writing is given by the Engineer-in-charge failing which,
Engineer-in-charge shall get the defects repaired at the contractor’s risk and cost.
WATER SUPPLY AND SANITARY WORK
V.
The contractor shall engage licensed plumber for the work and get the
materials tested by the Public Works Department authorities whenever required at
their own cost. The work shall be carried out according to the Public Works
Department Bye-laws and the contractor shall produce necessary certificate from
Public Works Department authorities after completion of work.
VI.
The contractor shall have to deposit water proofing compound as per the
actual requirements for the water proofing job with the Engineer-in-charge at his
Departmental Stores at the site of work.
The water proofing compound will be issued to the contractor from time to
time according to his requirements for the work in the same manner as the issue of
the materials stipulated to be issued departmentally.

32

<!-- page 36 -->

INCONVENIENCE TO PUBLIC
VII.
The contractor shall not deposit materials on any site, which will seriously
inconvenience the public. The Engineer-in-charge may require the contractor to remove any
materials, which are considered by him to be a danger or inconvenience to the public or
cause them to be removed at the contractor’s cost.
VIII.

Any damage to work resulting from rains or from any other cause until the work is

taken over by the Department after completion will be made good by the contractor at his
own cost.
IX. The contractor shall deposit royalty and obtain necessary permit for supply of sand, HBG
metal, red earth, etc. from local authorities.
X.

The contractor shall get himself acquainted with the nature and extent of the work

and satisfy himself about the availability of quarry and of kiln for collection and conveyance
of materials required for the construction. The contractor’s quoted rate should take into
account all these factors and will not be allowed for extra lead for collection and conveyance
of materials for any reason whatsoever.
XI.

The contractor will be permitted to set up labour camp only before a week from the

commencement of work and not exceeding fifteen days after the completion of the work.
XII.

The contractor shall conform to the provision of any government acts which relate to

works and to the regulations and bye-laws of any local authorities. The contractors shall give
all notices required by the said acts or laws etc., pay all fees payable to such authorities and
allow for these contingencies in his tendered rates including fees for encroachments, costs
of restoration etc., and all other fees payable to the local authorities.
XIII.

Where surplus earth of a suitable quality exists at the site of work, the contractor

shall be allowed to use same free of cost making mud mortar for masonry and for laying
mud terracing over the roof. The Engineer-in-charge shall be the final authority to decide
whether the earth obtained from excavation is surplus or not.
The surplus earth excavated which is beyond the requirement of PPCL T.R.Pattinam
works, may be allowed by the Executive Engineer to be disposed of by the contractor on his
own or to sell the surplus earth to private parties at his discretion, but nothing extra will be
paid for carriage or disposal of the surplus earth, if the same is not required for PPCL
T.R.Pattinam works.

33

<!-- page 37 -->

The debris should be removed from the site on day to day basis without affecting the
public in general.

The mixing of concrete should be done at a separate site avoiding stacking of
material at road side.
Wherever fine sand has been mentioned in the schedule of quantities, it
should be conforming to the grading Zone-IV or Zone-V as mentioned in the C.P.W.D.
specifications.
XIV. Concrete will be mixed with mixers either operated by hand or mechanical.
XV. The contractor shall not employ women and men below the age of 18 on the
work of painting with products lead, in any form wherever men above the age of 18
are employed on the work of lead painting, the following principles must be
observed for such use:
a) White lead sulphate or lead, of products containing these pigments shall not
be in painting operation except in the form of paste or of paint ready for use.
b) Measure shall be taken in order to prevent danger arising from application of
paint in the form of spray.
c) Measure shall be taken wherever practicable against danger arising from dust
caused by dry rubbing down and scraping.
d) Adequate facilities shall be provided to enable working painters to wash
during and on cessation of work.
e) Overalls shall be worn by working painters during whole of the working
period.
f) Suitable arrangements shall be made to prevent clothing put off during
working hours being soiled by painting materials.
g) Cases of lead poisoning and suspected lead poisoning shall be subsequently
verified by a medical team appointed by the competent authority.
h) The department may require when necessary medical examination of workers.
i) Instructions with regard to the special hygienic precautions to be taken in the
painting trade shall be distributed to working painter.

34

<!-- page 38 -->

j) The standard section weights referred to as standard table of 5.4 in the CPWD
specification 2009 be considered for conversion of length of various size of
steel bars into weights are as under:-

Nominal size

Cross sectional area

Mass per metre run

mm

Sq.mm.

Kg.

6

28.3

0.222

8

50.3

0.395

10

78.6

0.617

12

113.1

0.888

16

201.2

1.58

20

314.3

2.47

25

491.1

3.85

28

615.8

4.83

32

804.6

6.31

36

1018.3

7.99

40

1257.2

9.86

Issue of steel diameter above 10mm will be regulated on sectional weights
basis, weight being calculated with the help of the above tables. However, for bars
TMT steel up to and including 10mm the following procedure shall be adopted. The
average sectional weights for each diameter shall be arrived at from samples from
each lot of steel received at site. The actual weight of steel issued shall be modified
to take into account the variations between the actual and the standard co-efficients
given above and the contractor’s account will be debited by the cost of this modified
quantity only. The discretion of the Engineer-in-charge shall be final for the
procedure to be followed for determining the average sectional weight of each lot.
Quantity of each diameter of steel received at site of work each day will constitute
one single lot for this purpose.
35

<!-- page 39 -->

SPECIAL CONDITIONS APPLICABLE FOR ROAD WORKS/BRIDGE WORKS
(1)

Construction Equipment:

1.1

The methodology and equipment to be used on the project shall be furnished
by the Contractor to the Engineer well in advance of commencement of work
and approval of the Engineer obtained prior to its adoption and use.

1.2

The Contractor shall give a trial run of the equipment for establishing its
capability to achieve the laid down specification and tolerance to the
satisfaction of the Engineer before commencement of work, if so desired by
the Engineer.

1.3

All equipment provided shall be proven efficiency and shall be operated and
maintained at all times in a manner acceptable to the Engineer.

1.4

No equipment or personnel will be removed from site without permission of
the Engineer.

(2)

Work Program and Methodology of Construction:

The Contractor shall furnish his program of construction for execution of the
work within the stipulated time schedule together with methodology of construction
each item of work and obtain the approval of the engineer prior to actual
commencement of work.
(3)

Revised Programme of Work in case of Slippage:

In case of slippage from the approved work programme at any stage, the
Contractor shall furnish revised programme to make up the slippage within the
stipulated time schedule and obtain the approval of the Engineer to the revised
programme.
(4)

Action in case of Disproportionate Progress:

In case of extremely poor progress of the work or any item at any stage of
work which in the opinion or the Engineer cannot be made good by the Contractor
considering his available resources, the Engineer will get it accelerated to make up
the lost time through any other agency and recover the additional cost incurred, if
any, in getting the work done from the Contractor after informing him in writing
about the action envisaged by him.
(5)

Setting out:

Setting out the work as spelt out in clause 109 of Ministry’s Specifications for
Road and Bridge Works 5th Revision will be carried out by the Contractor.
(6)

Public Utilities:

Action respect of public utilities will be taken by the contractor as envisaged
in Clause 110 of Ministry’s Specifications for Road and Bridge Works 5th Revision.
36

<!-- page 40 -->

(7)

Arrangement for traffic during construction:

Action for arrangement for traffic during construction will be taken by the
contractor as envisaged in the contract documents and spelt out in clause 112 of
Ministry’s Specifications for Road and Bridge Works 5th Revision.
(8)

Quality Control:

The onus of achieving quality of work will be on the contractor who will take
action as stipulated in the Ministry’s for Road and Bridge Works 5th Revision.
(9)

Ministry’s specification for Road and Bridge Works (5th Revision):

Ministry’s specification for Road and Bridge Works 5th Revision will form part
of the contract documents and the contractor will be legally bound to the various
stipulations made therein unless and otherwise specifically relaxed or waived wholly
or partly through a special clause in the contract document.
(10)

Documentation:

The Contractor will prepare drawing (s) of the work as constructed and will
supply original with three copies to the Engineer who will verify and certify these
drawings. Final as constructed drawing(s) shall then be prepared by the Contractor
and supplied in triplicate along with a micro film of the same to the Engineer for
record and reference purposes.
(11) The contractor shall make his own arrangement to provide the bitumen
required for the work from approved public sector, refineries such as IOC, BP, HPL,
etc. and produce the paid voucher to the Engineer-in-charge. The materials so
procured shall be got tested before use.
(12) The use of rubber modified bitumen shall be as per the guide lines of “IRC SP
53-99”
(13) The Contractor shall use “Hydrostatic paver with sensor control” for this
work.
(14) Regarding bearings, the MORTH letter No.RW/NH-34057/1/2008-S & R (B)
dated 22.7.2009 and its Corrigendum No.RW/NH-34057/1/2008-S & R (B) dated
09.09.2009 shall be adhered.
(15) The Pile shall be terminated at a depth as per the direction of Engineer-incharge.
(16) The bearing capacity of 450mm dia 500mm dia and 600mm dia Piles shall be
not be less than 36, 40.5 and 51 MT respectively.

37

<!-- page 41 -->

(17) The defect liability period is Three Years where scope of work involves
provision of structural layer i.e. strengthening where the total thickness of
bituminous layer is 30 mm and above.
(18) The payment for the quantity of Road Work such as Bituminous Macadam
(BM/DBM), Bituminous Concrete / Semi Dense Bituminous Concrete, Wearing Course
shall be made based on the physical measurement of finished work in position in
cum. or sqm. at a specified thickness or based on level measurements, whichever is
less.
ADDITIONAL CONDITIONS
1.
The rate for all items of works shall unless clearly specified otherwise include
cost of all labour, materials and others inputs involved in the execution of item.
2(a) For the purpose of recording measurements and preparing running account
bill the abbreviated nomenclature enclosed with the standard form shall be adopted
.The abbreviated nomenclature shall be taken to cover all the materials and
operations as per the complete nomenclature of the relevant items in the agreement
and other relevant specifications.
(b)
In case of extra and substituted items of work for which abbreviated
nomenclature is not provided in the agreements, the full nomenclature of items shall
be reproduced in the measurement books and bill forms for running account bills.
3.
For all doors and windows whether factory made or otherwise, cleats and
rubber buffers 30mm dia. shall be provided as directed by the Engineer-in-charge
and the rate for the shutter item shall include the cost of providing such wooden
cleats and buffers.
4.
For those doors where hydraulic door closer is provided only wooden cleats
need not be provided and no reduction in rate shall be made for the same.
5.
The particle board shutter shall be provided, with teak wood lipping (beading)
at the edge to which hinges are fixed, without any extra cost.
6.
For works where items of aluminium doors, windows etc., are specified, the
grade of anodic coating to be provided in accordance with table I of IS: 1868-1968
together with reference to IS: 5523-1969.
7.
Where hydrated lime is available, this can be used on the works and the places
where hydrated lime is not available, lime concrete will be prepared by the
traditional method of slaking the lime preparing the lime putty etc.

38

<!-- page 42 -->

8.
(a) Tendered rates are inclusive of all taxes and levies payable under the
respective status. However pursuant to the constitution (46 th Amendment) Act 1982,
if any further tax or levy is imposed by the statute after the date of receipt of
tenders and the contractor thereupon necessarily and properly pays such
taxes/levies, the contractors shall be reimbursed the amount so paid provided such
payment, if, any, is not, in the opinion of the Engineer-in-Charge (whose decision
shall be final and binding) attributable to delay in execution of work within the
control of the contractor.
(b)
The contractor shall keep necessary books of accounts and other documents
for the purpose of this condition as may be necessary and shall allow inspection of
the same by a duly authorized representative of Public Works Department and
further shall furnish such other information/document as the Engineer-in-Charge
may require.
(c)
The contractor shall within a period of 30 days of imposition of any further
tax or levy pursuant to the Constitution (46th Amendment) Act, 1982 give a written
notice thereof to the Engineer-in-Charge pursuant to this condition, together with all
necessary information relating therein.
The components of material, labour and POL as indicated in para 3 of subclauses 10(CC) have been pre determined as below;
(a) Material :

percent

(b) Labour

:

percent

(c) P.O.L

:

100 percent

DELETED

9.
Stipulated materials shall be issued for use at site of work for all the items
where such materials are required. For factory made products like precast cement
tiles, precast hollow concrete blocks, precast foam concrete blocks, precast RCC
pipes etc., stipulated materials shall not be issued by the Department.
10. While execution of the work, the contractor shall organise his work in such a
way that the normal functioning of the premises is not disturbed.
11. Any damage done to the existing structure while dismantling execution of the
work shall be made good by the contractor at claim shall be made good by the
contractor at his own cost and no extra claim shall be entertained on this account.
12. The contractor must see the site before participating the tender and his
viability for executing the work.
13. The item of Anti-termite treatment shall be executed through a specialized
firm.
14. Rates should be quoted for the items specified in the NIT and shall not be
compared with the analysis of rates.
39

<!-- page 43 -->

15.

Rates for all items should be quoted based on the availability of construction

Materials in accordance to BIS/CPWD specifications.
16.
Rates should also be quoted inclusive of testing charges of all construction materials
both at laboratory and in the field. No payment will be made for material testing.
17.
The contractor should arrange for shifting of construction materials / concrete etc.,
near to the work site at his own cost. No extra rate shall be considered for shifting of
materials etc.
18.
For construction of Buildings /drain/canals/channel/bridges and culverts etc., rates
should be quoted inclusive of pumping and de-watering etc. No separate claim like
EIS/SIS/DIS will be admitted towards the dewatering etc. during the execution of work.
19.
The Contractors themselves have to identify the place of disposal of un-serviceable
materials like debris, waste mud, etc arises in the site. No extra lead and lift shall be
considered for such disposal.
20.
The Contractor must do their own arrangements at their own cost for
signage/barricading etc. for the safety of Public during construction in the construction site
of building/road/drain/canal/bridge/culverts etc. No separate claim will be admitted in this
regard.
CONDITIONS FOR STEEL:
21.
The contractor shall make his own arrangements to provide the steel required for the
work from SAIL / IISCO / TISCON / VIZAG / JSW STEEL PLANT and produce the paid voucher
to the Engineer-in-Charge. The materials so procured shall be got tested before use.
22.
The contractor shall procure 43 grade OPC cement having ISI mark from reputed
firms having annual turn over of not less than one million MT and stores it in the site
godown as per the guidelines specified in the CPWD specification 2009 under double lock
system. The paid voucher of the cement procured shall be produced to the Engineer-inCharge. The cement procured shall be got tested before use.
23.
The contractor shall make his own arrangements to provide the bitumen required for
the work from approved public sector, refineries such as IOC, BP, HPL etc., and produce the
paid voucher to the Engineer-in-Charge. The materials so procured shall be got tested before
use.
24.
Necessary test certificates should be produced from the approved laboratory for the
quality of materials.
25.
Defective materials will be rejected and the same have to be reparably by the
contractor at his own cost.

40

<!-- page 44 -->

26. Original purchase vouchers should be produced at the time of receipt of
materials and at the time of verification by the Engineer-in-Charge. The name of
contractor, name of work and agreement number should be clearly noted in the
original vouchers.
27.

The test specimens shall be provided at free of cost by the contractor.

28. The test for cement has to be conducted for every 1000 bags or part. The test
for steel has to be conducted for every consignment of 20 tonne or part thereof for
each size/dia.
29. Payment for the item of laying Semi Dense Bituminous Concrete shall be made
after conducting the density / compaction measurement test and also the surface
roughness measured with Bump Integrator, by the Highways Research Station,
Chennai and ensuring that
(a).
In respect of density /compaction, the test result conforms to the density
prescribed in the mix design and,
(b).
In respect of surface roughness measured with Bump Integrator the result
shall conform to the values prescribed in Table – 3 of IRC – SP-16-2004.
ADDITIONAL CONDITIONS II
ADOPTION OF PSR ABBREVIATED NOMENCLATURE
The Puducherry Schedule of Rates Abbreviated Nomenclature for buildings
and road works shall be adopted in recording of measurements and preparation of
running account bills, etc., wherever applicable as per CPWD Works Manual 2014.
PARTICULAR SPECIFICATIONS
1.
The work executed shall be measured as per metric dimensions given in the
schedule of quantities. The FPS units wherever indicated in the drawings are for
guidance only.
2.
Unless otherwise specified, all the rates quoted by the contractor shall be for
items of work at all levels and heights of the building.
3.
The work shall be executed as per the C.P.W.D. specifications 2009 (with
correction slips and subsequent publications). In case of discrepancies between the
specifications of a particular item as indicated in the C.P.W.D. specifications
mentioned above and as indicated in the nomenclature of the item the latter shall
prevail.

41

<!-- page 45 -->

4.
All stone aggregate, sand etc., shall be obtained only from approved
quarries.All the materials shall be got approved by the Engineer-in-Charge before
they are actually procured and used at site.
5.
The grading of sand to be used for mortars and concrete shall be determined
at the site of work by the Engineer-in-Charge and sand conforming to these gradings
only shall be used on the work.
6.
Necessary washing, screening, etc., of metal and sand shall be done at site as
per requirements of the Engineer-in-Charge.
7.

Bricks shall have crushing strength of class designation.

8.
The work of water supply and internal sanitary installations and drainage shall
be carried out as per bye-laws of the local Municipal body.
9.
All manufactured materials used in the work shall have ISI/BIS mark. In case
of materials for which no manufacturer has been licensed to manufacture the
materials with ISI marking, the materials shall conform to the provisions of
C.P.W.D./MORTH/IRC/CPHEEO specifications or the ISI code (in the absence of
C.P.W.D. specifications or other specification mentioned above for any particular
material). In the case of all materials, tests shall be conducted to ensure that they
conform to the specifications of codes mentioned above.
10.
All materials, which are to be tested before use on the work should be
procured at least 2 months before use on the work so that enough time is available
for testing them before they are actually used.
11.
The cost of samples and all other incidental charges such as packing,
transportation to the laboratory etc., shall be borne by the contractor.
12.
The architectural drawings Nos. based on which the work is to be executed are
available with the Engineer-in-Charge and can be inspected by the prospective
tenderers up to the date of submission of tenders at his office during working hours.
Use and testing of all the manufactured materials used in the work shall be
regulated as per specifications 2009.
13.
Before receiving final payment for the work, contractor shall give an
undertaking to the effect that at his own cost he will rectify the defects in walls, roof
like leakage, cracks etc. Which may come to light during the first monsoon after the
completion of work and for this purpose part of the security deposit which may be
deemed reasonable by the Engineer-in-Charge shall be retained till the first monsoon
is over as security against the contractor’s failure to act upon the undertaking. This
undertaking and consequent retention of part of the security deposit shall not
invalidate the contract.

42

<!-- page 46 -->

The timber to be used on the work shall be of first class wood of species
mentioned in the particular item. The timber shall be kiln seasoned as per B.I.S. 1141
– 1973 and shall be treated with non-leach able type preservative by vacuum
pressure method as per B.I.S. 401 – 1982.
FACTORY MADE PANELLED SHUTTERS FOR DOORS
14.
The shutters shall be fabricated generally as per I.S. 1003 (Part I) – 1997 and as
per Architect’s drawings. The timber to be used shall be of first class wood of
species mentioned in the particular item which shall be kiln seasoned and
preservative treated. The panels shall be as specified in the item number. Samples of
shutters shall be got tested as per I. S. 1003 (Part I) – 1997. The rate quoted for the
item shall include the element of cost of shutter to be sent for testing and no claim
on this account shall be entertained at a later date.
15.
Pressed clay tiles to be used on the work shall conform to I. S. 2690 (Part I) –
1975. However, the water absorption of the tiles when tested by the method
described in the Appendix ‘A’ of the said I. S. 2690 (Part I) 1975 shall not exceed 18%
(Eighteen percent.).
16.
Shahabad stone slabs, marble slabs etc. on treads and risers of steps and
shelves shall be in single pieces.
P.V.C. PIPES INTERNAL WORK AND EXTERNAL WORK
17.
The specification in respect of laying and jointing rigid P.V.C. threaded pipes
both internal and external shall be as per C.P.W.D. specifications. The rigid P.V.C.
threaded pipes shall confirm to relevant ASTM standard and shall be ORIPLAST or
equivalent.
18.
Wherever RCC walls, fins and facials are monolithic the portion of RCC are to
be measured as per the sketch attached in Page No. ………………………
19.
The top surface of the RCC roof slab shall be screeded to be uniform when the
concrete is green, so as to have a proper bond with the roof treatment. Nothing extra
shall be paid on this account.

43

<!-- page 47 -->

20.
For aluminium doors, fixed glazing, fixed windows, sliding windows, louvered
type ventilators and partitions etc. all aluminium sections shall be to the required
size, thickness and weight as shown in the relevant Architect’s Drawings.
21. The weight of stays given in C.P.W.D. specifications 2009 shall be for cast
brass stays only.
The weight of the mild steel and anodized aluminium stays shall be as follows:
Casement stays
(Straight peg
type)

Mild steel with tolerance of
plus or minus %

Anodized
aluminium with
tolerances of plus
or minus %

(a) 300 mm
long

0.13 Kg/each

0.06 Kg/each

(b) 250 mm
long

0.10 Kg/each

0.05 Kg/each

(c) 200 mm
long

The casement window
fasteners

44

0.04 Kg/each
0.155 kg/each

<!-- page 48 -->

Form of Earnest Money Deposit
Bank Guarantee Bond
WHEREAS, contractor.................. (Name of contractor) (hereinafter called "the
contractor") has submitted his tender dated ............. (date) for the construction
of.............................................. (name of work) (hereinafter called "the Tender")
KNOW ALL PEOPLE by these presents that we .........................................

(name

of bank) having our registered office

called

at ...................................

(hereinafter

"the Bank") are bound unto ................................................... (Name and division of
Executive Engineer) (hereinafter called "the Engineer-in-Charge") in the sum of Rs.
......................... (Rs. in words .................................................) for which payment well and
truly to be made to the said Engineer-in- Charge the Bank binds itself, his successors
and assigns by these presents. SEALED with the Common Seal of the said Bank this
................. day of ................. 20... .
THE CONDITIONS of this obligation are:
(1) If after tender opening the Contractor withdraws, his tender during the period of validity of
tender (including extended validity of tender) specified in the Form of Tender;
(2) If the contractor having been notified of the acceptance of his tender by the Engineer-inCharge:
(a) fails or refuses to execute the Form of Agreement in accordance with the Instructions to
contractor, if required;

OR
(b) fails or refuses to furnish the Performance Guarantee, in accordance with the provisions
of tender document and Instructions to contractor, We undertake to pay to the Engineer-inCharge either up to the above amount or part thereof upon receipt of his first written demand,
without the Engineer-in-Charge having to substantiates his demand, provided that in his
demand the Engineer-in-Charge will note that the amount claimed by his is due to him
owing to the occurrence of one or any of the above conditions, specifying the occurred
condition or conditions.

This Guarantee will remain in force up to and including the date* ............. after the
deadline for submission of tender as such deadline is stated in the Instructions to
contractor or as it may be extended by the Engineer-in- Charge, notice of which
extension(s) to the Bank is hereby waived. Any demand in respect of this Guarantee
should reach the Bank not later than the above date.
45

<!-- page 49 -->

DATE .............

SIGNATURE OF THE BANK

WITNESS ..................

SEAL

(SIGNATURE, NAME AND ADDRESS)

*Date to be worked out on the basis of validity period of 6 months from last date of
receipt of tender.

46

<!-- page 50 -->

Form of Performance Security (Guarantee)
Bank Guarantee Bond
In consideration of the President of India (hereinafter called “The Corporation”) having offered to
accept the terms and conditions of the proposed agreement between…………………………….and
…………….....................…… (hereinafter called “the said Contractor(s)”)
for the work
........................................................................................................................................ (hereinafter
called “the said agreement”) having agreed to production of an irrevocable Bank Guarantee for
Rs. …………. (Rupees………………………………
………………………………… only) as a security/guarantee from the contractor(s) for compliance of
his obligations in accordance with the terms and conditions in the said agreement.

1. We, .............................................. (hereinafter referred to as “the Bank”) hereby undertake
to pay to the Government an amount not exceeding Rs. ………………………..
(Rupees ....................... Only) on demand by the Corporation.
2. We, ……………………………….(indicate the name of the Bank) do hereby undertake to pay the
amounts due and payable under this guarantee without any demure, merely on a demand from
the Corporation stating that the amount claimed as required to meet the recoveries due or likely
to be due from the said contractor(s). Any such demand made on the bank shall be conclusive as
regards the amount due and payable by the bank under this Guarantee. However, our liability
under this guarantee shall be restricted to an amount not exceeding Rs………………………….

(Rupees ............................................................................................. only)
3. We, the said bank further undertake to pay the Government any money so demanded
notwithstanding any dispute or disputes raised by the contractor(s) in any suit or proceeding pending
before any court or Tribunal relating thereto, our liability under this present being absolute and
unequivocal. The payment so made by us under this bond shall be a valid discharge of our liability
for payment thereunder and the Contractor(s) shall have no claim against us for making such
payment.
4.
We, ……………………………. (indicate the name of the Bank) further agree that the guarantee
herein contained shall remain in full force and effect during the period that would be taken for
the performance of the said agreement and that it shall continue to be enforceable till all the dues
of the Government under or by virtue of the said agreement have been fully paid and its claims
satisfied or discharged or till Corporation on behalf of the Government certified that the terms and
conditions of the said agreement have been fully and properly carried out by the said Contractor(s)
and accordingly discharges this guarantee.

47

<!-- page 51 -->

5. We, ……………………………. (indicate the name of the Bank) further agree with the Government
that the Corporation shall have the fullest liberty without our consent and without affecting in any
manner our obligation hereunder to vary any of the terms and conditions of the said agreement or to
extend time of performance by the said Contractor(s) from time to time or to postpone for any time or
from time to time any of the powers exercisable by the Government against the said contractor(s) and
to forbear or enforce any of the terms and conditions relating to the said agreement and we shall not
be relieved from our liability by reason of any such variation, or extension being granted to the said
Contractor(s) or for any forbearance, act of omission on the part of the Government or any indulgence
by the Government to the said Contractor(s) or by any such matter or thing whatsoever which under
the law relating to sureties would, but for this provision, have effect of so relieving us.
6. This guarantee will not be discharged due to the change in the constitution of the Bank or the
Contractor(s).
7.
We, ……………………………. (indicate the name of the Bank) lastly undertake not to revoke
this guarantee except with the previous consent of the Corporation in writing.
8.
This guarantee shall be valid up to …………………………unless extended on demand by the
Government.
Notwithstanding anything mentioned above, our liability against this guarantee is restricted to Rs.
…………………… (Rupees ………………..) and unless a claim in writing is lodged with us within six
months of the date of expiry or the extended date of expiry of this guarantee all our liabilities under this
guarantee shall stand discharged.

Dated the ………………..day of ……………………for ............................. (indicate the name of
the Bank)

`

48

<!-- page 52 -->

SPECIAL CONDITIONS

(a) General Terms and Conditions:

1.

This work is covered under ESI & EPF Act, and it is responsibility of the contractor to ensure
compliance of ESI and EPF norms. Hence the contractors are requested to quote the rates
including the effect of ESI & EPF. Additional/Separate claim for ESI & EPF will not be
entertained on any account after the award of work.

2.

The contractor should have independent code number for ESI & EPF and the contractor shall
make pay make payment for ESI & EPF iin own code number other than PPCL code. No
permission shall be given for PPCL code.

3.

PAYMENT: 100 % Payment for the completed work will be made within 30 days for the
running bills as well as final bill after submission of ESI&EPF etc. documents.

4.

Payment will be made only after submission of the following.
 For EPF:
To be generated from the EPF website for the specific month for the manpower deployed to PPCL
and the same to be enclosed separately with a covering letter.
i.
Combined challan of account no.01, 02, 10, 21 & 22 with TRRN number.
ii.
EPF – Electronic challan cum Return (ECR).
iii.
EPF Challan summery / EPF- TTRN details.

For ESI:
To be generated fron the ESI website for the specific month for the manpower deployed to PPCL
and the same to be enclosed with a covering letter.
i.
ESI challan number
ii.
ESI monthly contribution – online challan status (Transanction details)
iii.
ESI montly contribution (Contractor wise) for the month of………..

`

5.

Party should obtain all permits and licenses under the laws or regulations applicable and in
connection with the work carried out and shall comply with and discharge all statutory
obligations/liabilities under the various laws such as Factory Act/Workmen’s Compensation
Act/ Employee’s State Insurance Act/ Employee’s Provident Fund Act / Payment of Wages
Act/Contract labour ( Regulation &Abolition) Act/ Minimum Wages Act etc., or any
modification thereof.

6.

“The tenderers may furnish, within a week of time, the related shortfall documents, to the pre
existed documents at the time of opening of the tender, failing which their tender will be
rejected.

49

<!-- page 53 -->

CORRECTION SLIP TO CLAUSE 25 OF TENDER FORM PWD 7/8

For
Clause 25 (ii)

Read

Chief Engineer, Public Works Department Secretary (Power)
or if there be no

Chief Engineer, the

Administrative Head of the said PWD

CONTRACTOR

`

EXECUTIVE ENGINEER

50

<!-- page 54 -->

Model I

Chapter ....... : Arbitration
[as a separate chapter in the contract agreement itself]
The parties agree that any mutual dispute with regards to terms of this Contract shall be
handled through Arbitration, as per the following terms, between them:
(I)

THAT, the parties agree that any dispute or difference whatsoever arising between
theparties out of/under or in connection with or relating to the construction,
meaning, scope, operation, or effect of the contract or the validity or the breach
thereof shall be referred to a Sole Arbitrator as appointed under clause (IV)
hereinbelow, and that theaward made in pursuance thereof shall be binding on the
parties;

(II)

AND THAT, the parties agree that in respect of those matters, as are not defined inthe
terms and conditions of the main contract, or in this Arbitration Agreement, thesame
shall be decided and settled by the Sole Arbitrator in accordance with theConciliation
Act, 1996 and the amendments thereof as in operation on date of execution of the
Contract;

(III) AND THAT, the parties agree that the place of Arbitration shall be at Puducherry in
the Union Territory of Puducherry;
(IV) AND THAT, whenever the parties decide to resort to Arbitration for
disputeresolution, the Secretary to the Government of Puducherry (Power) shall be
the authority to appoint the Sole Arbitrator from amongst a panel of Arbitrators
maintained by the Government of Puducherry, and such appointment shall be
binding on both the parties:
Provided that before approaching the authorities for appointing of Sole Arbitrator,
the parties shall make a sincere attempt to resolve their dispute, within a time period
of 3 months, through mutual conciliation, and if so felt necessary by the parties under
the supervisory guidance of the Secretary (Power)
(V)

AND THAT, all costs relating to the Arbitration proceedings, shall be borne equally
by both the parties;

`

51

<!-- page 55 -->

(Vl) AND THAT, the parties agree that the language for making all submissions and
evidence will be presented in ENGLISH during the proceedings;

(VII) AND THAT, it is agreed between the parties that they shall extend their fullest
support and co-operation to the Sole Arbitrator and not seek adjournment of the
Arbitration proceedings, without explaining the reasons therefore, in writing,
inadvance, for seeking of suchadjournment, and further that there shall not be
morethan two such adjournments granted, even when there exists a valid reason for
seeking such adjournment. And it is further agreed that the parties should cooperate
incompleting the arbitration process and the broader dispute resolution within 6
monthsor at most with an extension, on mutual consent, of another 6 months;
(VIII) AND THAT, it is agreed by the parties hereto that, in so far as there is an arbitral
award for payment of money, the Sole Arbitrator may include in the sum for which
the award is made, interest at the RBI repo rate, as on the date on which the cause of
action arose, plus 2%, on the whole, or any part of the money, for the whole or any
part of the period, between the date on which the cause of action arose and the date
on which the award is made:
Provided that, on the sum so directed to be paid by an arbitral award, there shall
beno interest payable for three months commencing from the date of award, but there
after, interest shall be payable at RBI repo rate plus 4% for such period of delay,till the
date of payment;
(IX) The Arbitrator shall record, in writing, the arguments of the two parties on each of
the points of dispute and pass a speaking order thereon.
(X)

The fees payable to the Sole Arbitrator as agreed upon by the Parties to the Contract
shall be as prescribed in the Annexure appended to this Contract, which forms part
and parcel of this Contract.

`

52

<!-- page 56 -->

ANNEXURE

Sum in Dispute
Upto Rs.5,00,000/Above

Rs.5,00,000

Rs.45,000/and

Rs.20,00,000/Above

Rs.20,00,000

Fee fixed for Arbitrator

upto Rs.45,000/- plus 3.5 percent of the claim
amount over and above Rs.5,00,000/-

and

Rs.1,00,00,000/-

upto Rs.97,500/- plus 3 percent of the claim
amount over and above Rs.20,00,000/-

Above Rs.1,00,00,000 and upto Rs.3,37,500/- plus 1 percent of the claim
Rs.10,00,00,000/-

amount over and above Rs.1,00,00,000/-

Above Rs.10,00,00,000 and upto Rs.12,37,500/- plus 0.75 percent of the
Rs.20,00,00,000/-

claim

amount

over

and

above

Rs.10,00,00,000/Above Rs.20,00,00,000/-

Rs.19,87,500/- plus 0.5 percent of the claim
amount over and above Rs.20,00,00,000/with a ceiling of Rs.30,00,000/-

`

53

<!-- page 57 -->

DECLARATION TO BE SUBMITTED BY THE CONTRACTOR

I have carefully read all the pages / conditions of this Tender Document and inspected the site before
quoting the rates for this tender and accordingly quoted the rates to suit the site condition.

CONTRACTOR

`

54
