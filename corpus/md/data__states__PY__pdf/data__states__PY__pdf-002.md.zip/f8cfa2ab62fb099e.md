---
doc_id: "f8cfa2ab62fb099e"
source_url: "https://agri.py.gov.in/Tenders/TenderPDF/rfpfinal.pdf"
ministry: "Agriculture and Farmers Welfare Department, Puducherry"
title: "Download"
date: ""
pages: 91
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8da4d1a30622f37a"
---

<!-- page 1 -->

{{arlq Grqa

GOVERNMENT OF PUDUCHERRY
DEPARTMENT OF AGRICULTURE & FARMERS WELFARE
PUDUCHERRY

REqUEST FOR PROPOSAL

Re-Tender for the Pilot Proiects on the Development of Web and Mobile
Applications with Emerging Technologies - Al, loT and ML for the
Department of Agriculture and Farmers Welfare, Puducherry
(Re-tender)
(An initiative under Digital Agriculture Project of NeCP-A, Ministry of Agriculture and
Farmers Welfare, New Delhi)

R F P N o. 7 o o

(ll) | Tech- I l/ Dte I zoz5-26 | Re-Te n d e r

DATE: t4lotlzoz6

DEPARTMENT OF AGRICULTURE & FARMERS WELFARE
NEW LIGHT HOUSE ROAD, VAMBAKEERAPALAYAM
PUDUCHERRY - 6o5 oor.
Tel No: +91-o 413-2266311
e-mail : agi.pon@nrc.in We bsite : https ://agri. py. gov. n
i

R?ot tp<t for Prono.dl for Proic.t< t hdpr f)iqitol Aoricr tltu tre ol thc Mini<trv o{ Aqria tltt tre and Former< Wcl{nre

<!-- page 2 -->

DISCLATMEB

All information contained in this Request for Proposal (herein after referred to
as RFP) are in good interest and faith. Though adequate care has been taken to
provide the complete information in this RFP document, the interested bidders shall
satisfy themselves that the document is completely understood in all respects. The
information published in this document is only indicative and not intended to be
exhaustive. Hence, interested bidders are required to make their own enquiries and
assumptions wherever required.

lntimation of discrepancies, if any, shall be given to this office with a
reasonable time to provide the clarification. lf no intimation is received by this
office within the date mentioned in the document, it shall be deemed that the RFP
document is complete in all respects and the bidder is submitting their proposal
with complete understanding and satisfaction.
The Department of Agriculture & Farmers Welfare, Puducherry, being the
owner and operator of the projects, on completion, ownership of the projects
would rest with the Department of Agriculture and Farmers Welfare, Puducherry
and the Department of Agriculture & Farmers Welfare, Puducherry reserves the
right to invite, consider and reject any or all of the bids submitted in response to
this RFP document at any stage without assigning any reasons whatsoever. The
Department of Agriculture & Farmers Welfare, Puducherry also reserves the right
to withhold or withdraw the process at any stage with intimation to all who have
submitted their proposal in response to this RFP. The Department of Agriculture &
Farmers Welfare, Puducherry reserves the right to change/ modify/ amend any or all
of the provisions of this RFP document without assigning any reason. Any such
change would be only communicated to the bidders by posting it on
https://pudutenders.gov.in/ and no individual communication would be given.
Neither the Department of Agriculture & Farmers Welfare, Puducherry nor its
employees and associates will have any liability to any prospective bidder who are
interested to apply, under the law of contract, for unjust enrichment or otherwise
for any loss, expense or damage which may raise from or be incurred or suffered in
connection with anything contained in this RFP document. Any other information
supplied on behalf of Department of Agriculture & Farmers Welfare, Puducherry
nor its employees other than the information contained in the RFP would arise in
any way from the selection process for the assignment.
The information provided in this document to bidder as part of RFP process
is confidential to Department of Agriculture & Farmers Welfare, Puducherry as
owner of the projects and shall not be used by the bidder for any other purpose,

distributed to, or shared with any other person or organization and any such
distribution/sharing would be treated as an offence.

Request |or Proposol for Projects under Digitol Agriculture of the Ministry of Agriculture and FarmersWelfare,

New Delhi f or the Department of Agriculture and FormersWelfore, Puducherry

l' ;r g r' 2191

<!-- page 3 -->

Contents
NOTICE FOR REqUEST FOR PROPOSAL.

....................,7

UNDERTAKINC...,..,.,..
ABBREVIATIONS & DEFINITIONS
LETTER OF

2.

SCHEDULE OF RFP.........

3.

PROJECT PROFILE & BACKCROUND

...............8
........... 11

..............13

lNFORMAT|ON......

......................16

3.1. ABOUT DEPARTMENT OF ACRICULTURE AND FARMERS WELFARE

C.
D.

Development, lntegration & Configuration............

F.

Mobile Application

16

FunctionalRequirementSpecification(FRS)

1,7

.......... 18

......................20

4.2. APPLICATIONS TO BE DEVELOPED
4.2.1. Scope t: lntelligent Agricultural Advisory System (IAAS)

Application
4.2.1.1.1. Mobile Application for farmers
4.2.1.1.2. Mobile App for field staff.....

20
.........................20

4.2.1.1. Mobile version of the IAAS

.........21
...............21,
......................21

4.2.2. Scope z: RealTime lrrigation Management System (RIMS)..........
4.2.2.1.lrrigation lnfrastructure Mapping...

..........21,
.................22

4.z.2.3.Ctop Area and Cropping Pattern for monitoring the Crop Status Module .................22

4.z..z.4.lrrigation lntensity Module.....

............................22

4.2.2.5.RealTime Soil Moisture Monitoring..

..............22

4.2.2.6. loT enabled irrigation.

22

4.2.2.l.lntegration ............

22

4.2.3. Hosting of the Application.

22

4.2.4. Application Features

23

4.2.5. Key Architectural Considerations........

25

4.2.5.1.AP1-Driven Development (ADD)

25
26

Request for Proposol for Proiects under Digital A+riculture of the Ministry of AEriculture ond FormersWelfare,
New Delhi for the Deportment of Agriculture and Farmers Welf ore, Puducherry

I'r:t ,,3191

<!-- page 4 -->

4.2.5.l.Open Standards & OSS....,.......

27

4.2.5.4. Emerging Technologies - Big Data Analytics, ML & At........

27
28

4.2.6. Computation of the Costin9......................

28

5.
6.
7.
8.
g.

PROjECT TTMELTNES

29

SCHEDULEOFPAYMENTS............,......

29

PRE-QUALTFICAT|ON / ELtCtBtLtTy CR|TER|A

30

TECHNICAL EVALUATION CRITERIA

32

suB-CoNTRACT|NC / CONSORTTUM

34

WORKINC LANCUACE..

34

10,

34

12.

INSTRUCTION TO THEBIDDERS

34
34

12.2. COMPLETENESS OF RESPONSE.

34

12.3. PRE-BtD CLARtFtCAT|ONS.

35
35

12.).2. CLARIFICATION TO PRE-BlD qUERIES / ISSUE OF CORRI6ENDUM

35

12.4. PERIOD OF VALIDITY OF PROPOSA1S..............

35
36

12.6. CURRENCY OF THE PROPOSAL PAYMENT...

36

12.7. ALTERNATIVE / MULTIPLE PROPOSALS...............,

36

T2.8. WITHDRAWAL, SU BSTITUTION, AND MODIFICATION OF PROPOSAL...,.............. 36

12.9. RIcHT TO TERMTNATE THE PROCESS

36

12.10. PUBLICATION / ANNOUNCEMENT OF RFP DOCUMENT

37

12.11. EARNEST MONEY DEPOSIT (EMD) i.e. Bid Security

37

12.12. PERFORMANCE SECUR1TY..................

37

12.1j. SUBMISSION OF PROPOSALS

38

12.13.1.PRE-qUALl FICATION PROPOSAL.

38

rz.r3.z. TECH N ICAL PROPOSAL..

3B

12.1).). FINANCIALPROPOSAL

38

12.14. AUTHENTTCATTON OF BIDS.

39

1f.

BlDEVALUATlON..............

40

11.1. EVALUATTONCRTTERIA

41

13.2. EVALUATTON BASED pRE-qUALtFtCAT|ON.......

47

133.qUALlTYANDCoSTBASEDEVALUATloN(qcBS).'........

42

Request for Proposol for Projects under Digital A+riculture of the Ministry of Agriculture and FormersWelfore,
New Delhi for the Deportment of Agriculture ond Formers Welfare, puducherry

['agc 4191

<!-- page 5 -->

1).4.

TECHNICAL EVALUATION

13.5.

EVALUATTON OF FTNANCIAL PROPOSAL

8.6.

EXCLUSTON OF PROPOSAL/

't4.

AWARD CR|TERIA.....

15.

RrGHT TO ACCEPT / REJECT ANy OR ALL pROPOSAL(S)

45

16.

NOTIFICATION OFAWARD

+5

,....,,,,,,42
............................... 4:l

DTSqUAL|F|CAT|ON..

..............44
.....................45

17.

18.

FAILURE TO ACREE WITH THE TERMS AND CONDITIONS OF THE RFP....,..................45

19.

PENALTIES AND SERVICE LEVEL AGREEMENT (SLA)

46

20.

OTHER TERMS:

48

INTERFERENCE WITH TENDER PROCESS.....

49

25.

MONITORIN6 OF CONTRACT

50

26.

CoRRUPT/FRAUDULENT

27.

CENERAL TERMS AND CONDITIONS OF PROPOSAL AND CONTRACT......................,.. 5O

27.1.

srcNrNG oF CoNTRACT...................

27.2.

EXECUTTON OF

27.).

FAILURE TO ACREE WITH THE TERMS AND CONDITIONS OF THE TENDER..............51

21.
11

23.

24.

PRACT|CES..

............50

....................51

AGREEMENT................

.............51

lo.

......................
coN FrDENTrALrTy...........
coPYRrcHT
INTELLECTUAL PROPERTY RIGHTS

30.1.

owNERSHtP/LTCENStN6 OF FORECROUND TNTELLECTUAL pROpERTy....................52

27.4.
28.

29.

CoNTRACT DOCUMENTS

FIXES...
30.3. BESPOKE DEVE1OPMENT...................
covERNrNC 1AW..............
31.
coMPLtANCE W|TH THE LAW
31.1.
RECOVERTES FROM SELECTED B|DDER.,..,....
32.
TAXES & DUT|ES.....
33.
30.2.

.............. 51
.............. 51

.............52
.................52

PRODUCTS AND

........,,.,..52
.................53
............53
.........,.................53
.........................54
........................54

34.

MANDATORY FURNISHINC OF CST PARTICULARS

54

35.

FORFEITURE OF PERFORMANCE BANK GUARANTEE

55

36.
37.

TENDER EVALUATION

COMMITTEE

................56

Requestfor Proposal for Projects under Digital Agriculture of the Ministry of Agriculture ond Formerswelfore,
New Delhi for the Deportment of Agriculture ond FormersWelfore, Puducherry

l, 1 ,t t, 5lg1

<!-- page 6 -->

38.

39.
40.
40.1.

40.2.

40.3. MEASURES TO BE TAKEN..........

5B

41. oTHER CONDTTTONS

59
60

ANNEXURE-I: PRE-PROPOSALS QUERIES FORMAT...,...
AN N EXU RE-z: COVERINC

1ETTER..........

ANNEXURE-3: PRE-QUALIFICATION BID (FORM 1- 6).............,..

81D.........,....
ANNEXURE-5: FINANCIAL BID TEMP1ATE..............
ANNEXURE 6: CODE OF 1NTECR1TY.............,.,...
ANNEXURE-7: SELF-DECLARATION.....
AN N EXURE-4: TECH NICAL

...........,,.,,.60
......................... 61

...............................62
..............,,.,,....,,,. 70
........................... 75

..........77
...........................78

ANNEXURE 8: PERFORMANCE BANK CUARANTEE (UPON FINAL SELECTION)..................... B0

ANNEXURE-9: NDA - WITH EACH RESOURCE DEPLOYED BY THE SELECTED BIDDER /
COMPANY...

B2

AN N EXU RE-1 O: ARBITRATION........,,....

B4

ANNEXURE-tt: SERVICE LEVEL ACREEMENT (SLA).............

B6

ANNEXURE.l2: PROCEDURE FOR SUBMISSION OF ONLINE BI Dq

89

Requesl for Proposol for Proiects under Digital Agriculture of the Ministry of Agriculture ond FarmersWelfare,
New Delhi for the Deportment of Agriculture ond Formers Welfare, puducherry

I'rtgt:6197

<!-- page 7 -->

GOVERNMENT OF PUDUCHERRY
DEPARTMENT OF AGRICULTURE & FARMERS WELFARE
PUDUCHERRY

RFP No.7oo (ll)/Tech lUDte/zoz5-z6i

Re-Tender Puducherry, Dated: t4lotlzoz6

RE:TENDER FOLTIIE PILOT PROJECTS ON THE DEVELOPMENT OF WEB AND
MOBTLE APPLTCATTONS WrrH EMERGING TECHNOLOGIES - Al, IOT AND ML"

e-tenders are invited on behalf of the President of India from intending
agencies/institutions registered under the Companies Act 1956 lrelevant statutes of
the Government of India / State Covernments to develop Al, loT and ML based web
applications and Mobile Apps related to agriculture on pilot basis under the Digital
Agriculture Project of National e-Governance Plan (NeGP-A) of the Ministry of
Agriculture & Farmers Welfare, New Delhi . Last date for online submission is on
before 4.jo P.M. of o3lozlzoz6 through https:ipudutenders.gov.in/, th
Portal of the Government of Puducherry.

HOUDHARY r.A.S)
R OF AGRICULTURE & FW

Place: Puducherry

Dale: t4lotlzoz6

Request for Proposal for Projects under Digital Agriculture of the Ministry of Agriculture and FarmersWelfore,
New Delhi for the Deportment of Agriculture and Formers Welfare, Puducherry

l',i1i,7191

<!-- page 8 -->

LETTER OF UNDERTAKING

To
The Director of Agriculture and Farmers Welfare,
New Light House Road,

Vambakeerapalayam,
Puducherry - 6o5 oor.
Sir,

Sub: Undertaking for participating in Request for Proposal for the Pilot Projects

of the Development of Web and Mobile Applications with Emerging Technologies - Al,
loT and ML for the Department of Agriculture and Farmers Welfare, Puducherry - Reg.

Ref: RFP No.7oo (ll)ftech lUDte/2o25-26 dated o5lotlzoz6
Uwe.
(i)

do hereby

submit my/our bid for The Development of Web and Mobile Applications with
Emerging Technologies - Al, loT and ML on Pilot basis for the Department of
Agriculture and Farmers Welfare, Puducherry for the Pilot projects under
Digital Agriculture under NeGP-A of the Ministry of Agriculture and Farmers
Welfare, New Delhi in accordance with the Terms and Conditions of this RFP.

( ii)

confirm that l/we have examined and fully understood the details of the tender
and have carefully noted the conditions of contract and the specification with all
the stipulations of which l/we agree to comply and shall not raise any queries,
post completion of the RFP process.

( iii)

undertake to complete the "The Pilot Projects on the development of Web and

Mobile Applications with Emerging Technologies - Al, loT and ML for the
Department of Agriculture and Farmers Welfare, Puducherry" at the places
mentioned in the specification of all the articles as per RFP & tender schedule
from the date of communication of acceptance of my/our tender.
(iu)

further agree that the acceptance of this tender shall result in a valid and
concluded contract binding on me/us, the terms whereof shall be taken to be
those mentioned in the form of agreement hereto annexed notwithstanding the
non-execution of the said agreement.

(r)

declare that l/We agree to do the various acts, deeds and things referred to
herein including the condition relating to non-withdrawal of this tender above
set out in consideration of the Department of Agriculture and Farmers Welfare,
Puducherry.

(ui)

confirm that our Company was not blacklisted by any State Government/ Central
Government/ Public sector Undertakings during the last five years. we also
hereby confirm that our EMD/sD was not forfeited by any state Government /
Central Government / Public Sector Undertakings, during the last five years due
Request for Proposal for Projects under Digitat Agriculture

of the Ministry of Agriculture ond Formerswelfore,
New Delhi for the Deportment of Agriculture and Formers Welfare, puducherry

Pagc Bl91

<!-- page 9 -->

to our non-performance, non-compliance with the tender conditions etc.
(vii)

confirm that our Company has not filed for bankruptcy during the last five years.

(viii) confirm that our Company has not violated / infringed on any lndian or Foreign
trademark, patent, registered design or other intellectual property rights
anytime, anywhere in lndia.
(i*)

Confirm that llwe have read the clause(s) regarding compliance to OneMzM
standards adapted vide No. ryelzotg-STDITEQz release-z dated q.og.2o2o and vide
No. rg-otlzozo-STDITEC release-j dated or.oS.zozz by Deportment of
Telecommunicotions and we assure to deploy secured loT devices from trusted
sources complaint with the TEC Code of Practice for Security Consumer lnternet of
Things (loT) TEC aqtS:zozt.

(*)

confirm that l/we have read the clause(s) regarding restrictions on procurement
from a bidder of a country which shares a land border with lndia, as per
Government of Ministry of Finance Department of Expenditure G.O. No
F.No.6/t8/2o19-PPD dated z)-o7-2o19; l/we certify that l/we, as a bidder are not
from such a country or, if from such a country, has been registered with the
Competent Authority. I certify that this bidder fulfils all requirements in this
regard and is eligible to be considered.

(xi)

shall not sub-contract any work(s) to any individual/selected bidder/contractor
from or a country which shares a Iand border with lndia unless such contractor is
registered with the Competent Authority.

(xii)

declare that all the particulars furnished by l/we in this Tender are true to the
best of my/our knowledge and l/we understand and accept that, if at any stage,
the information furnished is found to be incorrect or false, l/we are liable for
disqualification from this tender and also are liable for any penal action that may
arise due to the above.

(xiii) certify that l/we are liable and responsible for any disputes arising out of
lntellectual Property Rights, if any, that arises, thereof.
(xiv)

certify that l/we shall not form any consortium with other firms/
organizations/bidder/ companies for carrying out the tasks specified in this RFP.

(*u)

ln case of violation of any of the conditions stated above, l/!Ve (Name of the
individual / company), understand that l/We are liable to be blacklisted by the
Department of Agriculture and Farmers Welfare, Government of Puducherry for
a period of five years.

Signature :
Name of the authorized signatory :
Seal of the company:

Request for Proposol for Projects under Digital Agriculture of the Ministry of Agriculture and FormersWelfare,
New Delhi for the Department of Agriculture and FormersWelfare, Puducherry

i'r,t,

9.,91

<!-- page 10 -->

Note:

1. Declaration in the company's letter head should be submitted as per format given
above and the bidder doesnltteserve the any right to fu$r or partial[rmodify, any of
the clauses prescribed herein.

2. lf the bidder firm has been blacklisted by any State Covernment/ Central Government/
Public Sector Undertakings earlier, then the details should be provided.

l. Formation of Consortium is not allowed.

Request for Proposol for Proiects under Digital Agriculture of the Ministry of Agriculture and FarmersWelfore,

New Delhi for the Department of Agriculture and Farmers Welfore, Puducherry

[',r qr'10 191

<!-- page 11 -->

ABBREVIATIONS & DEFI NITIONS

Artificial ntelligence

AI

I

Authorized
Signatory
Bidder/ Legal

Entity
BoQ

Contract /
Procurement
Contract
Day

Demand Release
GoU GoP

INR

loT
!T

The bidder's representative / officer vested (explicitly, implicitly, or
through conduct) with the powers to commit the authorizing
organization to a binding agreement. Also called signing officer /
authority having the Power of Attorney (PoA) from the competent
authority of the respective selected bidder.
Bidder can be a Proprietorship selected bidder, Partnership
selected bidder, Company, LLP or Society registered in India
Bill of Quantity
A contract entered into, between Department of Agriculture &
Farmers Welfare, Government of Puducherry and a successful bidder
concerning the subject matter
A calendar day as per Covernment of Puducherry
A requirement shared on email/ work-order to/f rom the designated email account agri.pon@nic.in
Govt. of India / Govt. of Puducherry
lndian Rupee
lnternet of Things
nformation Technology
lT Consulting, Project Management, lT Project Operations, eGovernance, software application, software testing, application
development, lmplementation and Maintenance of Web Portals, Web
Enabled Applications, GIS Technologies & Remote Sensing, Artificial
I

lT/lTeS Domain

lntelligence, Machine Learning, Data Analytics, Block Chain
Technology, Websites and Mobile Apps using latest available
technologies like Proprietary (.net etc.) Open Source (PHP, Java, CMS
Drupal , geo Server, Open layers , Postgres etc.) and allied activities
MeitY

Ministry of Electronics and lnformation Technology, New Delhi

ML

Machine Learning

Notification

A notification published in the Official Cazette of Government of

Puducherry
PAN

Permanent Account Number as per lT Act

Proiect Site

Wherever applicable, means the place or places designated by the
Department of Agriculture and Farmers Welfare, Puducherry for
testing/com missioning the project
A formal offer made in pursuance of an invitation by Department of
Agriculture and Farmers Welfare, Puducherry and includes any tender,
proposal or quotation

Proposal

Request for Proposal for Projects under Digital Agriculture of the Ministry of Agriculture and Farmers Welfare,
New Delhi for the Deportment of Agriculture ond Formers Welfore, Puducherry

l'.'1, 11 191

<!-- page 12 -->

Proposer

RFP Document

State/UT

Any person / selected bidder / company / contractor / supplier /
selected bidder participating in the procurement / RFP process with the
procurement entity
Documents issued by the Department of Agriculture and Farmers
Welfare, Puducherry, including any amendments thereto, that set out
the terms and conditions of the given procurement and includes the
invitation to Proposals
Government of Puducherry (CoP)

Government
Tender Process

The process of procurement extending from the issue of invitation to
proposals till the award of the contract or cancellation of the Tender
Process, as the case may be

wo/Po

Work Order / Purchase Order

Request for Proposol for Projects under Digitol Agriculture of the Ministry of Agriculture and FarmersWelfore,

New Delhi for the Deportment of Agriculture ond Farmers Welfore, puducherry

l:',zgt: 72|97

<!-- page 13 -->

I. PURPOSE
The purpose of this RFP is to solicit proposals to select suitable bidder for the Pilot
Projects on the development of Web and Mobile Applications based on emerging
Technologies- Al, loT and ML for the Department of Agriculture and Farmers Welfare,
Puducherry under the Project of Ministry of Agriculture & Farmers Welfare, New Delhi.

o The selected Bidder will be required to facilitate by developing Web and Mobile
Applications based on Emerging Technologies - Al, loT and ML on Pilot basis for
the Department of Agriculture and Farmers Welfare, Puducherry.

. The Department of Agriculture and Farmers Welfare, Puducherry expressly
stipulates that selection of Bidder under this document is on the understanding
that this RFP document contains only the principal provisions for the entire

assignment and that for any other services which may be required in
connection with the successful implementation of the assignment shall be
deemed to be a part of the assignment. The selected Bidder shall be required
to undertake to perform all such tasks, render requisite services as may be
required for the successful completion of the entire assignment at no
additional cost to the Department of Agriculture and Farmers Welfare,
Puducherry.
Z. SCHEDULE OF RFP
RFP No.

7oo (l l)/Techll/Dtelzoz5-26 dated o5lo'rlzoz6

Name of Work

Request for Proposal for Pilot Projects on the
Development of Web and Mobile Applications based
on Emerging Technologies - Al, loT and ML for the

1

2

Department of Agriculture and Farmers Welfare,
Puducherry
3

4
5

Proposals lnvited by

Date of issue/publication of
RFP document
Start Date and time for
Submission of Proposals

The Department of Agriculture and Farmers
Welfare,
New Light House Road,
Vambakeerapalayam,
Puducherry 605 o01.
Telephone : + 91- o 41j-2266377
email: agri.pon@nic.in
14loil2026
From t4loll2o26 at 1.3 o P. M

Request for Proposal for Projects under Digital Agriculture of the Ministry of Agriculture and FarmersWelfore,
New Delhi for the Depattment of Agriculture ond Formers welfare, Puducherry

i' ,r - ,' 13191

<!-- page 14 -->

6

Date of Pre-Bid Meeting

7

Last Date for Submission of
Proposal

8

Date of Opening of PreQualification bid
Date of Opening of Technical

9

zTlotlzo>.6 at 1o.oo A.M

to 11.oo A.M.

Venue: Board Room, Directorate of
Agriculture & Farmers Welfare, New
Light House Road,
Vambakeerapalayam,
Puducherry- 605 oo1
o3lozlzoz6 till 4. j o P. M .
o3lotlzoz6 at 5. o o P. M
o3lotlzoz6 at 5 .3 o P. M

Bid
10

Date of Opening of Financial
Bid

12

Place of Submission &
Opening of Proposals
Address for Comm unication

13

Website for downloading RFP

11

Would be communicated to the bidders
shortlisted after evaluation of the technical bids
by mail by the Department Agriculture & FW,
Puducherry to their registered e-mail lD.
Online on https://pudutenders.gov.in/

Directorate of Agriculture and Farmers Welfare
New Light House Road
Vam bakeerapalayam
Puducherry - 6o5 oor.
Tel No: +91-0413-2266311
Email: agri.pon@nic.in
https:/lpudutenders.gov. in/

Document, Corrigendum's,
14

Addendums etc.
Cost of Document

Rs. to,ooo/- which includes e-Procurement

Processing fees

(to

be paid online in the

portal

https:/lpud utenders. gov.in/
15

EMD

Rs. 4,5 o, o o o/-(Rupees Four lakhs fifty thousand
only) (to be paid online in t h e p o rt a l)
h t t p s : / / pudutenders.govjn/

t6

Performance Security

to% of the Bid Value

17

Proposal's Validity

90 days from the Proposal's submission date.

r8

Method of selection

Quality cum Cost Based Selection (qCBS)
Technical: Financial - 8o:zo

Request for Proposal for Proiects under Digitol Agriculture of the Ministry of Agricutture and FormersWelfare,
New Delhi for the Deportment of Agriculture ond Formers Welfore, puducherry

l\ ,:1 f r..: 14 | 97

<!-- page 15 -->

Note:

r)The Department of Agriculture and Farmers Welfare, Puducherry reserves allthe
to cancel the e-tender process and reject any or all of the proposals at any time.
2) No contractual obligation whatsoever does arise from the RFP document/process
unless and until a formal contract is signed and executed between the Department

of Agriculture and Farmers Welfare, Puducherry and the successful proposers.

s)The Department of Agriculture and Farmers Welfare, Puducherry disclaims any factual
or other errors in the RFP document (the onus is purely on the individual proposers
to verify such information) and the information provided herein are intended only
to help the proposers to prepare a logical proposal.

Note: MSEs (Vticro and Small lndustries) and Startups registered under Make in India
initiative will be exempted from the payment of cost of tender document and EMD
but shall submit necessary latest documents to support the claim.

Request for Proposal for Projects under DiEital Agriculture of the Ministry of Agriculture ond FormersWellore,
New Delhi for the Depdrtment of Agriculture ond Formers welf orc, Puducherry

i',r,:.r 15|91

<!-- page 16 -->

3. PROJECT PROFTLE & BACKGROUND INFORMATION
3.1. ABOUT DEPARTMENT OF AGRICULTURE AND FARMERS WELFARE

The Department of Agriculture and Farmers Welfare, Puducherry, established in
early 6os for the promotion of agriculture in the UT of Puducherry has made significant
strides in the field of Agriculture by increasing the productivity of agricultural Iand,
achieving crop diversification, maximizing irrigation potential through micro-irrigation,
building infrastructure, creating a well united input and marketing network etc.

The Department of Agriculture and Farmers Welfare, Puducherry initiated
leveraging of ICT in agriculture as early as 2oo3 by creating farm help centers with
internet connectivity and further connecting them through a Wide Area Network. lt was
also the first Department to host a portal for agriculture to sustain the growth rate of
agriculture in the U.T. of Puducherry, enhance the economic status of the farming
community by overcoming constraints with increased technological intervention and
establishment of a more efficient system for delivery of extension services.
ln Phase I of NeGP-A, web applications were covering CzC, CzB and CzG services to
take the technology further for easy and swift delivery of services.

I. DIGITIZATION OF FARM HOLDINGS
o Digitizing the farm holdings of all the four regions of the U.T.
II. SMART FARMER IDENTITY CARDS
o A qR code based farmer identity card with a unique code to track the
personal and farming profile of an individual farmer and also track the
history of services availed is in the pipeline.

lll. MIS ON EXTENSION AND SCHEME MANAGEMENT; INPUTS QUAL|TY
CONTROL, LICENSES AND AVAILABILITY MANAGEMENT - Applications

on'

o Extension Management lnformation System - to assess weekly crop
prospects and extension activities to plan and monitor

o Scheme Management lnformation System - for an effective MIS on financial
and progress reports

o lnputs Quality Control Management lnformation System - to have a MIS on
the fertilizer, insecticide and seed samples received for analysis and their
reports

o lnputs Licenses Management lnformation System for a license
issue/renewal and

o lnputs Availability Management lnformation system - to keep a track on the
periodical report on the availability of agricultural inputs

Requestfor Proposal for Prolects under Dtgitol Agriculture of the Ministry of Agriculture and FarmersWelfare,
New Delhi for the Deportment of Agriculture ond Formers Welfare, puducherry

l'.,,;:,t' 16191

<!-- page 17 -->

4. scoPE oF woRK
4.t.GENERAL

The main scope of work is to Pilot Projects on the development of Web
applications and Mobile Applications based on emerging technologies - Al, loT
and ML for the Department of Agriculture and Farmers Welfare, Government of
Puducherry.

A. Application Development, Deployment, hand-over and hand-hold
. The selected bidder shall design, develop, build and deploy various
applications, which will be part of the application.

c The selected bidder also has to host the two pilot applicdtions in the existing
N|CSlCloud resources.

o Further, after handing over, the bidder shall hand-holdlassist the Deportment of
Agriculture ond Farmers Welfare, Puducherry to monoge and operote the Pilot
Projects with remote technical support for a minimum period of two crop
seasons from the date of "Go-live.

Note: The applications shall not disturb the existing applications.

B. Requirement Study
The selected bidder shall study the f unctioning of the agriculture
department and various processes to understand the existing system and pen
down the requirements from various stakeholders. The selected bidder shall
identify the stakeholders with the help of the Nodal officer (Dy. Director of
Agriculture - Digital Agriculture) or any designated authority and necessary
information shall be collected by designing questionnaire/ interviews/meetings
with respective stakeholders. The stakeholders will be Department Officials,
Scientists from Agriculture Universities, Krishi Vigyan Kendras, faculty of
Agriculture College and Farmers, if need be. The selected bidder shall submit the
detailed Business Requirement, Functional requirement, Software Requirement
Specifications (SRS) and Use case documents to the Department of Agriculture
and Farmers Welfare, Puducherry on the two pilot proiects - lntelligent
AgriculturalAdvisory System (IAAS) and RealTime lrrigation Management System
(RIMS) and it would be reviewed and approved by the authority concerned of
Department of Agriculture and Farmers Welfare, Puducherry. The selected bidder
shall also suggest additional functionalities, to be incorporated within the limit of
scope of work mentioned in the RFP, to make it more inclusive and in the best
interest of public services.

C. Functional Requirement Specification (FRS)
The selected bidder shall prepare the Functional Requirement Specification

(FRS) once the requirement study has been finalized and approved by the
Requestfor proposol for Projects under Digital Agriculture of the Ministry of Agriculture ond FarmersWelfore,
New Delhi for the Department of Agriculture and FdrmersWelfore, Puducherry

[' .r g r' 17 |191,

<!-- page 18 -->

DePartment of Agriculture and Farmers Welfare, Puducherry. ln the FRS, the
selected bidder shall mention each and every requirement in a detailed way with
all the necessary features. The selected bidder has to submit the FRS to the
Department of Agriculture and Farmers Welfare, Puducherry and any suggestions
shall be incorporated in the FRS.

D. Development, lntegration & Configuration
The selected bidder shall be responsible for the Development I
Customization (if any), lntegration and configuration of the application. The
developed application would be verified against approved SRS and validated by
the Department of Agriculture and Farmers Welfare, puducherry.

E. Web Portal
The web application(s) would be an integral interface for all the
stakeholders involved. Stakeholders should have to go through secured
authentication level where the users will get a dashboard to access all the
functionalapplications role-based and personalized to individual requirements. For
e.g., farmers should have facility to have access on various aspects of agriculture
such as crop calendars, status of their applications on various assistance,
Agricultural officer or field staff shall be able to do approvals. The web portals &
the mobile applications shall be hosted in the existing NICSI Cloud resources of the
Department of Agriculture and Farmers Welfare, Puducherry. The portal shall have
pre- filled forms by fetching data for that beneficiary from the database. Some of
the specifications, but not limited to, of the web portal are as follows:

o The web application shall have strong authentication and security features
and should maintain security rights and privileges through an tntegrated
Management Solution

o Development of application should be on Open Source Technology
o The application shall not allow concurrent sessions for same user.
o The application shall support workflow management system in which all the
departmental activities shall be integrated.

o The application shall support all the major browsers like lnternet Explorer,
Chrome, Firefox and Windows, Android and IOS mobile operating systems

o The application shall have multi-lingual capabilities i.e. Tamil & English
o The application shall be interoperable with industry standard databases
o The application shall provide search engines with advanced full text search
capabilities

o The application shall support HTIPS protocol on Secure Socket Layer (SSL)
o The application shall provide support for comprehensive audit trail
o The application shall support web services and integrate with common
business applications

o The application shall be integrated with standard email, SMS and instant
Request for Proposol for Proiects under Digital Agricutture of the Ministry of Agriculture and Farmerswelfare,

New Delhi for the Department of Agriculture ond FarmersWelfore, puducherry

Pagc 18191

<!-- page 19 -->

messaging services

o The application shall integrate with other products and components of the
platform via open standards
o The application shall support virtualization, encryption and compression
features should have provision to view and analyze historical crop area,
production & yield.
o The application shall have facility to get area, production and yield data by
firing dynamic query. The data should be displayed in graphs, chart forms
o The application shall have provision for department officials to upload their
reports such as weekly sowing report, forecast report, crop conditions report
etc. in the format provided on the portal. Also, the portal should have facility
to store, track and monitoring of the data at different administrative levels
o The application shall have facility for field staff to report any pest or disease
incidence at village level in the format provided on the portal.
o The application shall have facility for field staff to record collected
aggregated yield data at village level in the format provided on the portal.
o The application shall have facility for Agriculture Officer to view the
aggregated pest and disease information registered by Field staff at district
level in the format provided on the portal and make strategic decisions
o The application shall have facility to record the crop survey, disaster and crop
damage against each crop along with damage estimation data, evidences and
damage audits in the format provided on the portal'
o The application shall have facility to estimate and record the crop production
damage against each crop

o The application shall have facility to view the potential threat area, due to
different natural calamities, their vulnerability profile and their occurrence
frequency.

o The application shall have database backup where data should be stored for
contract duration plus 6 months additionally after the project completion.
o The application shall have the facility to collate the data of the district
metrological unit or laboratories are any support system and suggest
solutions.

o The application shall have the facility to integrate the market data and
o

suggest possible solution using Al, ML etc.,
The application shall have the facility to integrate the data on the availability
of agricultural inputs from various sources like State / Private dealers/ 6ol to

o

suggest the availability of inputs.
The application shall have the facility to integrate the custom hiring centers /

o

service centers to provide information on such facilities.
The application shall have the facility to integrate the land records, data, soil

health data etc., to arrive at possible solutions.
Requestfor Proposal for Projects under Digitot Agriculture of the Ministry of Agriculture ond FormersWelfore,

NewDelhifortheDeportmentof AgticultureondFarmersWelfare,Puducheffy

l, .t g f 19 | 97

<!-- page 20 -->

o

F. Mobile Application

The mobile application is the integral part of the solution. Some of the
specifications, but not limited to, of the mobile application are as follows:
o The Mobile Application shall provide an intuitive and user-friendly CUI that
enables users to navigate and apply actions with ease. The GUI should be
responsive with very little or no delays or time lag at launch or whilst
navigating through screens
o Application shall contain pre- filled data and forms
o Mobile app shall be compatible with Android and toS
o Application shall incorporate analytics to identify user experience patterns
o Application shall not occupy excessive RAM
o Application shall follow strict authentication, privacy and security features

o Page loading /refreshing should be quick
o Facility to obtain real time 6PS information
o Shall have a module to enable digital crop survey
o Facility to capture photos, images and videos wherever needed
o lt shall enable ease of configuration and change to existing GUls and support
introduction of new screens

o Screen design should be resolution and size of the device independent
4.2. PILOT APPLICATIONS TO BE DEVELOpED
4.2.r. Scope r: lntelligent Agricultural Advisory System (IAAS)
The primary scope of this Pilot Project is to develop an lntelligent

Agricultural Advisory System on pilot basis comprising web and Mobile
application for the farmers based on latest cutting-edge technologies like
loT/Al/ML and other technologies. Following are the major module
requirements and not limited to it.
o Farmer Registration Module for farmer's details with an API for
integration, wherever needed
o Registration and management of other stake holders such as
fertilizer, pesticides and seed dealers, custom hiring centers,
scientists, crop surveyors etc.
o Crop Data Management to maintain a database on the crops,
varieties seasons, features etc.
o Government Schemes and Benefits
o Crop Management - package of practices for selected paddy
varieties (one each under short, medium and long duration)
o Crop Advisory Framework - that includes advise on pre-sowing
techniques, selection of varieties, nursery management, sowin$,
main field management, irrigation, harvest and market frame
Request for Proposol for Projects uncler Digital Agriculture of the Ministry of Agriculture and FormersWelfare,
New Delhi for the Deportment of Agriculture ond Farmers Welfdre, Puducherry

lt ': '':' t' 20 | 91

<!-- page 21 -->

work
o Development of modules for integration of soil health details,
DAMU details, digitized maps, market data and other agricultural
services of the Department
o Agriculture Extension and Knowledge Management Module
o Reports and Dashboard for the Department
4.2.1.1. Mobile version of the IAAS Application
4.z.t.t.t.Mobile Application for farmers
Mobile Application for farmers shall have the following major
Requirements, but not Iimited to it as follows.
o Shall have facility to fetch farmers, stake holders and scheme
d eta ils

o facility to register for a service for a stakeholder
o lncident reporting such as Pest and disease occurrence through
lmages, Vcice and Video Messages

o List of applied interventions against each crop
o Notifications to be received through any of the broadcast by the
o
o
o

Department
Market price of farrn produce across mandis within their vicinity
Weather data, soil health data, inputs data etc.
The application shall be interactive with cutting edge

technologies like chats, SMS, IVRS etc.
4.2.1.1.2. Mobile App for field staff

o Shall have the functionality to fetch farmer's details, register
Farmers and other stakeholders operating at the village Ievel

o Crop registration feature to register the stake holders, crops and
o
o

capture farm visuals.
Modules for crop survey wherever needed
Facility to view and act on the assigned incidents or Service
requests

o Farmer and Farm details for respective lncidents/SRs
o Provision to maintain and record daily activities
o The application shall be interactive with cutting-edge
technologies like chats, SMS, IVRS etc.

4.2.2. Scope z: RealTime lrrigation Management System (RIMS)
A Real-Time lrrigation Management System on Pilot Basis shall be developed
by the bidder on pilot basis wherein the latest cutting-edge technologies like Al, loT
etc are to be deployed. The implementation of the pilot project shall be for a
minimum area of two acres in a Government farm identified by the Department and
for any two crops - one short duration and one long duration crop. The
Requestfor Proposol for Projects under Digital Agriculture of the Ministry of Agriculture and Farmerswelfore,
New Delhi for the Deportment of Agriculture and Formers Welfare, Puducherty

I'.rgt'21|91

<!-- page 22 -->

Department reserves the right to assign the crops. Following are the major
modules, but not limited to, be built up for Real-Time lrrigation Management.
4.2.1.2. lrrigation lnfrastructure Mapping
The water bodies and water sources for the irrigation in the project area are to
be visualized through this module. This module shall also enable assessment of the

irrigation potential of a particular area.

4.2.r.j. Data Module
The data obtained from the field through the loT Gadgets/Sensors (a minimum of
four sensors in an area of one acre with supporting systems) shall be visualized and
assessed through this module.

4.2.r.4. Crop Area and Cropping Pattern for monitoring the Crop Status Module
Real Time Crop type and Cropping pattern determines the irrigation needs and
hence the inventory of crop system in the field is useful to know whether the irrigation
system is optimally used or not. This shall enable in online monitoring and easy farm

management.
q.2.1.5. lrrigation lntensity Module
Real Time lrrigation intensity shall be defined as the percentage of the cultivable

command area proposed to be irrigated seasonally/annually under an irrigation
command (e;lot eroject area) which can be used to estimate the gap between the
irrigation potential created and potential utilized. This would facilitate in optimizing the
Water Usage.

4.2.r.6. RealTime Soil Moisture Monitoring
This module shall integrate the data of Soil Moisture from the loT Sensors installed

or the moisture information obtained through Satellite Data / DAMUs / Universities /
institutions. This module shall enable in identifying the real time soil moisture
information which will help in decision making for regulating the irrigation overall
optimizing the water usage.
4.2.1.1. loT enabled irrigation
This module shall include loT sensors which would trigger the irrigation circuit
based on other parameters like soil moisture, rainfall, humidity etc.

4.2.t.8. lntegration
The application shall be compatible for integrating the module in the IAAS and it
shall have the scope to f unction independently, as well.

4.2.2. Hosting of the Application
The application developed must be cloud agnostic and the Cloud resources for
hosting would be provided by the Department of Agriculture & FW, Puducherry. Already
web applications are residing in the NlCSl Cloud resources of the Department and the
Request for Proposal for Projects under Diqital Agriculture of the Ministry of Agricutture ond FarmersWelfore,
New Delhi f or the Deportment of Agriculture ond Fotmers Welf ore, Puducherry

|j"t7l 22|91

<!-- page 23 -->

bidder shall host the applications to be developed in the same Cloud resources without
affecting the other applications.

4.2.3. Application Features

a. Open Standards Based - The portal shall be compliant OCC standard
and services like WMS (Web Map Service), WCS (Web Coverage
Service) and WFS (Web Feature Service). lt shali be open to avoid
being captive by any proprietary technologies, have provisions for data
access by third parties and should be modular enabling scale up and
reuse by third parties. Vendor neutral APls should be used by the
platform.

b. Scatable - The lnfrastructure platform shall be based upon service
models and it should demonstrate robustness. The service models can
be chosen from Software as a service (SaaS), Platform as a service
(PaaS) and lnfrastructure as a service (laaS). For the scalability, the
load has to be distributed across system. lnstead of entire application
accessed through web portal, if shall be built with stateless APls that
can be scaled horizontally.

c. lnteroperability- The platform shall have capability to integrate /
interoperate with different technologies, protocols or any third party
application providers. The platform should be non-intrusive in allowing
integration of different services.

d. Multi-Channel Support -Based on the requirement of the stakeholder,
multi-channel delivery such as web portal, SMS, lVR, mobile
applications etc. should be supported by the platform. The expense of
SMS, ATS and IVR will be borne by the bidder. Universal user interface
shall be provided across channels.

e. Security - The security features embedded in the applications shall
meet the standards prescribed by MeitY and the hosting selected
bidder.

f. API First Approach
o The platform shall be based on open API approach as multiple
channels like web portal, mobile applications and other inter{aces
should access the platform

o Adaptable architecture shall be supported for changing business
needs and end user requirements.

o The platform shall have integrated various systems, applications,
databases already being used or to be built for future

o Selected bidder shall set up, and maintain systems and processes
Request for Proposol for Proiects under Digital Agriculture of the Ministry of Agriculture and FarmersWelfore,
New Delhi for the Deportment ol Agriculture ond Formers welf are, Puducherry

r' ., 23lq1

<!-- page 24 -->

for the required APls. The authority does not have any available
APls and the following shall be ensured.

o
o
o
o
o
o
o

Authorization and license key management
Standardization
Authentication
Version Control
Environmentmanagement
Security Covernance
Audit Trail

g. Testing
Testing shall be initiated by the successful bidder along with the requirement

finalization in which test cases and test plan shall be designed simultaneously. The
selected bidder shall submit the test cases and test plan and it shall be approved by the
designated authority of the Department of Agriculture and Farmers Welfare,
Puducherry and standard best testing practices shall be followed throughout the
testing phase(s). Testing shall be performed in spring manner and the identified bugs /
issues shall be resolved in the respective spring only. The selected bidder shall maintain
the record of bug / issues with their status and it shall be submitted to the Department
after each testing phase. The selected bidder shall perform following testing, but not
limited to, as detailed below.

i.

Unit Testing
Once the customization and configuration phase is over, each module of the

application shall be tested end to end. The selected bidder shall demonstrate

the system is a controlled production environment where the data which is
being utilized in a multiple module are managed efficiently.

ii.

Performance and Load Testing:

The ielected bidder shall develop performance scenarios of pedormance
conditions of the applications which shall be reviewed and approved by the
Department. The application along with its infrastructure shall successfully
meet the criteria for the response time. The selected bidder shall gather run
analytics to understand realistic usage and setting up the infrastructure to
meet the performance. The successful bidder shall submit required reports to
the authority.

iii.

User Acceptance Testing (UAT):

The selected bidder shall submit UAT test plan and it should be reviewed and

approved by the designated authority of the Department of Agriculture
Farmers Welfare, Puducherry. The application would go for UATs and the test
results of unit testing and performance testing are to be submitted to the
authority. UAT is to be performed by the Department of Agriculture and
Requestfor Proposol for Projects under Digitol A4riculture of the Ministry of Agriculture ond FormersWelfore,
New Delhi for the Deportment of Agriculture ond Formers Welfore, Puducherry

P;rgr:24197

<!-- page 25 -->

Farmers Welfare, Puducherry as per the test plans and the team performing
UAT shall categorize the defects in critical, high, medium and low priority.
The critical defects identified shall be fixed and retested before go-live by the

selected bidder whereas 9o% of high priority should be fixed before go-live.
The medium and low priorities defects shall be fixed within one month of

"go-live".

iv. Security Testing:
The selected bidder shall perform security testing before hosting the application,

through an CERT-in. ln the security testing, web application, mobile application, external
threat testing, system vulnerabilities etc. shall be tested. The application for lT security
audit shall be in the name of the Director of Agriculture and Farmers Welfare,
Puducherry. The findings of security testing shall be resolved and the certificate in the
name of the Department of Agriculture & FW shall be submitted to the authority before
hosting of the application under intimation to Department of Agriculture and Farmers
Welfare, Puducherry.
h. Deployment of the Application
The selected bidder shall deploy the applications in the NICSI Cloud resources of

the Department of Agriculture and Farmers Welfare, Puducherry. The selected bidder
shall maintain following environments on cloud.

o Developmentenvironment
o Testing environment
o Staging environment
o Production environment
o Disaster recovery
After go-live any change requests shall be done in the development environment
and thorough testing should be performed. The bugs shall be fixed before moving to
staging and subsequently production environment. Disaster recovery should replicate
the production environment and the backup shall be taken at the regular interval.
4.2.4. Key Arch itectural Considerations
4.2.4.1.AP|-Driven Development (ADD)

Digital Platform has greater emphasis on development based on API ecosystem.
API ecosystem shall be the first entry point to the application for various user channels.
As an API is the first artifact that is created during the app development process, API
contracts (APl specification and signature, including the name, parameters, types, error
codes, etc.) shall be finalized in collaboration with all the consumers and stakeholders.
APls are to be designed to ensure reusability across multiple contexts and by multiple
consumers.

The key features and components of API ecosystem to be adhered by the
developer shall be as below.
Requestfor Proposol for Projects under Digital Agriculture of the Ministry of Agriculture and Farmerswelfore,
New Delhi for the Deportment of Agriculture ond Formers Welfare, Puducherry

Pagc 2519L

<!-- page 26 -->

Sl. No

Feature

Description

1

Standardizing APls
and specification

out of box including SOAP <=> REST, XML <=> JSON,

Publishing and
2

Management of
APls

3

4

Version Control

Standardize the APls exposed and perform transformations
XML<=>XML supporting XSLT

Allow authorized user to publish APls and allow lifecycle
management of APls
Provide a controlled mechanism for API versioning control for
any change. Also, provide a means to ensure newer versions
of APls are backward compatible and the older version of the
APls are sunset without affecting the consumers.

Provide appropriate & adequate security mechanisms
governing access to API framework- i.e. Authentication
strength, inspect the headers for APls genuineness before

API Security

acceptance.

5

Help track usage of APIs by the consumers in terms of access
credentials, access duration and timestamp, lP addresses,
Transactions, Licenses etc.

Audit Trail

Provide reporting data on the usage/transactions performed
by users/consuming entities on exposed APl. System shall also
6

API Usage Activity

generate reports on usage information such as most/least
accessed APls, highest/lowest/average response time, data

volumes transferred, transfer rates, the maximum and
minimum response time over a period of time, rejected API
requests
7

API Metering

B

API Policy
Lifecycle

Measure usage at the API layer including measuring usage of
each API by each user based on requests.

Support Coverning and controlling all APls in areas like policy
validation, policy debug tracing and update of API policies at
global or individualAPl level.

4.2.4.2. M icro services
Applications are to be developed using Application Driven Development (ADD),

with every module representing a service (third-party or own) and this app architecture
called Micro services, having its own sets of benefits shall be adhered by the developer.

Request for Proposal for Projects under Digitol Agriculture of the Ministry of Agriculture ond FormersWelfare,

New Delhi for the Depottment of Agriculture ond FormersWelfare, Puducherry

lt .l ;:,'.' 26 | 91,

<!-- page 27 -->

Description

Feature

Sl.No.

1

Modular systems

To allow better management of dependencies. The services
within a system are to be decoupled and the application as a
whole are to be easily built, altered, and scaled

)

Componentization

lndependent components that could be easily replaced and
upgraded

Scalability

Scale only the service which is loaded instead, as compared to
traditional monolith app architecture, where the entire app is
to be scaled, though only a part of the app needs scaling.

Better fault
isolation

Since each of the services are deployed separately, a fault in
one system doesn't shall not bring down other systems as they
are loosely coupled.

3

4

5

Agility

To support agile development. Any new features are to be
quickly developed and discarded. System to allow frequent
releases of software, through systematic automation of
software creation, testing, and approval shall be ensured.

6

Autonomy
Business

7

8

Capabilities
Decentralized
Covernance

Developers and teams shall have the scope to work
independently of each other, thus increasing speed of delivery.
Focus on a single coherent business capability

The focus shall be on using the right tool for the right iob. That

means there shall be no standardized pattern or any

technology pattern.

4.2.4.3. Open Standards & OSS
The applications shall be developed using Open Source Software (OSS) and
tools that adopt Open Standards over Commercial Off the Shelf (COTS)
products to be cost effective, reliable, have ease for customization and have
more skill availability and also have no vendor'lock-in".

q.2.4.+. Emerging Technologies - Big Data Analytics, ML & Al
A wide variety of data are to be continuously streamed from heterogeneous
sources like loT Sensors, Weather Stations, Satellite lmages, various

government agencies and from the public and these may be either
unstructured or semi-structured. These data types typically don't fit well in
traditional data warehouses that are based on relational databases oriented
to structured data sets. Hence, the developer shall ensure robust SQL
databases which can collect process and analyze big data. The developer
shall employ tools for Big Data analytics tools which can interpret the data
and populate a structured relational database intelligently with inference
data for easy consumPtion by the other components of the platform.
Request for Proposol for Projects under Digital Agriculture of the Ministry of A1riculture and FarmersWelfare,
New Delhi for the Deportment of A+riculture ond FormersWelfore, Puducherry

l' .: g i' 27 191

<!-- page 28 -->

Machine learning and Artificial lntelligence shall be an integral part of the

platform to parse, comprehend and understand the data generated. With
this, the Agro Digital platform shall be able to provide intelligent actionable
decisions and advisory based on its learning.

4.2.4.5. Security
Applications hosted on internet are increasingly under attack, so
effective application of security must be a top priority.
Authentication and
Authorization

Auth z.o open standard for access delegation, to grant websites

Focus on OWASP ro

Application development shall focus on the most critical
security risks to applications.

vulnerabilities

or applications access to their information on other websites
but without giving them the passwords

Concerns

Data to be made accessible only to authorized users, by
enforcing appropriate policies at various levels.

Encryption by default

Data exchange via HTTPs using strong SSL Ciphers and the data

Address Privacy

stored on disk are to be encrypted.
Apply Principal of
least privileges

Each system component or process will have to be designed to

have the least authority necessary to perform its
responsibilities, minimizing the attack surface area. Eliminate
unnecessary privileges to reduce risk of network exploits and
computer compromises

4.2.5. Computation of the Costing
Though the scope of development comprises two Pilot applications, the primary

application scoPe is lntelligent Agricultural Advisory System (IAAS) and the second
application scope Real-time lrrigation Management System (RIMS) would be run
independently as well integrated as a sub-set of lntelligent Agricultural Advisory
System. Though the pilot project has two components, it is considered as a unitary
project in terms of development for better compatibility and sync of the technologies
involved and seamless interaction of the databases. Further, additional scope of work, if
any, prescribed by the Department of Agriculture and Farmers Welfare, Puducherry on a
later date for a better outcome shall be at cost of the Sl. The bidder shalt consider both
the projects as a single entity and quote accordingly in the Biil of euantity (eoe).

Request for Proposol for Proiects under Digital Agricutture of the Ministry of Agriculture ond Farmerswelfare,

New Delhi for the Department of Agricutture and Formers Welfare, puducherry

I).rge 28|;97

<!-- page 29 -->

5. PROJECT TTMELTNES

')/ The Solution needs to be developed within approximately 3o weeks

decision of the Department of Agriculture and Farmers Welfare,
Puducherry with overall maximum extension of three Months to
complete the project.
'z The Condition for "Co Live" is the UAT acceptance certificate

provided by the Department of Agriculture, Puducherry.
Deliverables

Timeline to complete each Level

I

Documentation

7th week from contract start date

il

Development

2oth week from contract start date

ilt

Testing

24th week from contract start date

IV

Go Live

3oth week from contract start date

Level

5. SCHEDULE OF PAYMENTS
Deliverables

Schedule of Payment

Documentation and Finalization
of FRs

t5%of the project cost

Prototype of the application

zo%ol the project cost

ilt

Compietion of UAT

z5% of the project cost

IV

Co Live

40% of the project cost

Level
I

The schedule of payment given above is only indicative and subject to variation
based on the receipt of funds from the Ministry of Agriculture and Farmers
Welfare, New Delhi by the Department of Agriculture and Farmers Welfare,
Puducherry and further approval of the competent authority in the Government
of Puducherry.

Request for Proposal for Proiects under Digital Agriculture of the Ministry of Agriculture and FormersWelfore,
New Delhi for the Deportment of Agriculture and Farmers Welfore, Puducherry

i',:,t , 29191

<!-- page 30 -->

7. PRE-qUAL|FtCAT!ON / ELtctBtLtTy CRITER|A

A proposer participating in the tender process shall possess the
following minimum pre-qualification/ eligibility criteria

SI

I

Documents to be attached

Qualification Criteria

No.

The Bidder shall be registered in lndia under
Companies Act 1956 should have registered Copy of certificate of lncorporation
office ln lndia and in existence for at least five issued by Registrar of Companies
years as on 3110312025.

The Bidder should have achieved average annual
2

CA certificate and an audited Profit

and Loss Statement for the last
turnover of at least lNR. 45.00 Crores (fifty
three financial years (i.e. zozo-zr,
crores) from lT/lTeS business in last five financial

years (i.e. 2o2o-21, 2021-22, 2o2z-23; zoz3-24 and
2024-25).

2021-22, 2022-23.; 2oz3-24 and zoz4-

25). A certificate from CA/ statutory

auditor.

3

The Bidder must have minimum experience of
five years (i.e. zozo-21,2021-22, 2022-23; zo21-24
Work order(s) and completion
and zoz4-25) in lT Projects related to Agriculture
certificate(s) from the client
or allied subjects such as Horticulture, Animal
showcasing the years of work

usbandry, and Forestry from the bid
submission date in lndia with either State or
H

experience.

Central Covernment.

4

5

6

The Bidder should have positive net worth as on

A certificate from CA/ statutory

3r't March zoz5.

auditor.

The Bidder shall not be under a declaration of
ineligibility / ban / blacklisting by any State or
Central Government / any other Government
institutions in lndia for any reason as on last
date of submission of the Bid.
The bidder shall have experience in successful
execution of one or more projects that covered
the scope of Development of Web and Mobile
Application in agriculture, Technology based
Crop Mapping, Crop Acreage Estimation, digital
crop survey, digital mapping of land records and
its application for scheme management etc. or
any similar agriculture related project with

A

self-declaration from

a

government notarized affidavit in
an e-stamp paper of denomination
of Rs.to/-.

Number of projects completed with

the value of the projects. Work

Order(s) and

corresponding

Completion Certificate(s) from the
clients

Request for Proposol for Proiects under Di,itol Agriculture of the Ministry of Agricutture and Farmerswelfare,
New Delhi f ot the Depottment of Agriculture and Formers Welf are, puducherry

'e>,tg<:30 191

<!-- page 31 -->

emerging technologies like AUML for central,
state government or any Government enterprise
in lndia during past five years from the date of
bid submission. (i.e. zozo-21, 2021-22, 2022-23;
zoz3-24 and zoz4-25).The project value shall be
at least Rs.z.5o Crores.
The Bidder shall preferably have l'ris/her working

7

project team in Union Territory of Puducherry
with a team of qualified technical personnel (or) Letter of Undertaking in Companies
Bidder has to give undertaking to setup a proiect Letter Head with Seal & Signature
team in Puducherry within one month of award
of work.
NoLe:

the disqualification of bidder from Technical Evaluation.
M ake in I nd ia initiative ryjll be ex-eLrrpted O NtY,f 1om thqTurnover

entgria (clause z) for Pr:e-Qualification but shall eomply with ottrer
elauses.

Request for proposol for Projects under Digitat Agriculture of the Ministry of Agriculture and FormersWelfore,
New Delhi for the Deportment of Agriculture ond Farmerswelf dre, Puducherry

l',rgr'31 191

<!-- page 32 -->

8. TECHNICAL EVALUATION CRITERIA
SI

Evaluation Criteria

No

Max

Documents to be

Marks

attached

The Bidder should have achieved average annual

CA certificate and an

turnover of at least lNR.45.oo Crores from
lT/lTeS business in last five financial years (i.e.
2o2o -21, 2021-22, 20 22-23,; 2023-24 and zo24-25).
1

Turnover: -

10

(t) aetween Rs 45 to 55 Crores - 4 Marks

A certificate from CA /

statutory auditor.

Maximum : r5 Marks

The bidder should have similar experience in
Development of Web as well as Mobile
Application use of emerging technologies like
AUML in Agriculture Domain with value of u
Crores for either State Government / Central
Government / Any Government Agencies in lndia
in last five financial years (i.e. zozo-21, 2021-22,

15

2022)3; 2oz3-24 a nd zo z4-z 5).
One Project:3 Marks; Two Projects: 6 Marks
Three Projects: 9 Marks; Four Projects: rz Marks
Five or more Projects: r5 Marks
Maximum Marks: t5

3

Copy of

completion

certificates

and Work

orders
I
Agreement

from the

Contract

Client.

Quality / Security Certification:

o ISO gooi:2or5 & ISO 27oo1:2o13 - 3 Marks
o CMMi level 3 certification - 4 Marks
r CERT-IN certified Project - 3 Marks

2O2O-21, 2021-22, 2022-23;

zo23-24 and zoz4->.5).

(z) Between Rs 55 to 75 Crores - 7 Marks
$) More than Rs 75 Crores - 10 Marks

2

audited Profit and Loss
Statement for the last
five financial years (i.e.

Copy of the certificate(s)
10

signed and stamped by
the authorized signatory
of the bidder.

Bidder should have an experience of successful

4

execution of one large scale project that covers
the scope of Development of Web and Mobile
Application, Technology based Crop Mapping,
Crop Survey, Crop Acreage Estimation etc. and
use of emerging technologies like AUML for
central, state government or any government
enterprise in lndia in last five financial years (i.e.
2o2o -21, 2021 -22, 2o2z-23; 20 23-2 4 a n d z o z 4-z 5 ).

Copy of

Co-Live/

Completion certificates
15

and Work orders I
Contract Agreement
from the client.

For Single project worth > INR 20 Crores: 5 Marks
For Single project worth > INR 40 Crores: roMarks
Requestfor Proposol for Projects under Digitol Agriculture of the Ministry of Agricutture and FarmersWelfare,
New Delhi tor the Department of Agriculture ond Formers Welfore, puducherry
11 ,,t y,

t: 32 | 91

<!-- page 33 -->

For Single project worth > INR 6o Crores: t5
Marks

Proof of Concept (PoC): Demonstration based on

the Web applications and Mobile applications
developed through Emerging technologies like
Al, ML, loT etc. for Agriculture domain in last five
f in a ncia I yea rs ( i. e. 2o2o-21, 2021-22, 2o2z-2i; 2c23z4 and zoz4-25).

applications and Mobile applications with
Al, ML, loT - t5 Marks

Live Product

Or

For Successful demonstration of Web

5

20

applications and Mobile applications with
other emerging technologies like Block

Demonstration (Only
online and not from local
servers)

Chain, Data Analytics etc., without Al, ML,
loT - 5 Marks.

lag in execution of both applications with
emerging technologies - 5 Marks

(The Web and Mobile applications developed
without Emerging Technologies and other than
for Agriculture project shall not be considered)
Technical Presentation:

6

o Project Understanding of Obiectives: 5 Marks
o Approach and Methodology:1o Marks
o Project Plan and Timeline: 5 Marks
o Personnel Deployment Plan (Based on

3o

Technical Presentation

Resume of Key Personnel): 5 Marks

o Use Case lmplementation : 5 Marks
Total

100

Note:
and this shall apply uniformly for all categories of bidders.

Request for Proposal for Projects under Di1itol Agriculture of the Ministry of Agriculture ond FormersWelfore,
New Delhi for the Department of Agriculture ond Formers Welfore, Puducherry

[',r r,.,33 191

<!-- page 34 -->

g. suB-CoNTRACT|NG / CONSORTIUM
Not allowed
1o. WORKING LANGUAGE
The selected bidder shall deliver all documents only in English language.

II. REPORT!NG
All correspondences by the successful bidder / selected bidder shall be addressed

to the Director, Department of Agriculture and Farmers Welfare, Puducherry.
However, on a regular basis, the selected bidder shall be in contact with the
designated Coordinator in Department of Agriculture and Farmers Welfare,
Puducherry for project management issues and for technical inputs and for all
related requirements of the projects.
12. INSTRUCTION TO THEBIDDERS
Tz.I.6ENERAL

a. A Bidder must submit only one proposal. lf a Bidder submits in more than
one proPosal, such proposals would be summarily disqualified without
assigning any reasons.

b. No commitment of any kind, contractual or otherwise shall exist untess and

until a formal written contract has been executed by Department of
Agriculture and Farmers Welfare, Puducherry. The Department of
Agriculture and Farmers Welfare, Puducherry may cancel this public
procurement at any time prior to a formal written contract being executed.

Iz.z. COMPLETENESS OF RESPONSE
a. Bidders are advised to study all instructions, forms, requirements,
appendices and other information in this RFP document carefully.
Submission of the bid shall be deemed to have been done after careful
study and examination of the RFP document with full understanding of
its implications.

b. Failure to comply with the requirements of this RFP may render the
proposals submitted by Bidders as non-compliant and the Proposals may
be rejected. Bidders must:

i. Comply with all requirements as set out within this RFp.
ii. Submit the forms as specified in this RFP and respond to each
element in the order as set out in this RFp

iii. lnclude all the supporting documentations specified in this
RFP.

Request for Proposal for Projects under Dilital Agricutture of the Ministry of Agriculture ond Farmerswelfore,

New Delhi f or the Department of Agriculture ond Farmers Welfare, puducherry

I'agc 34197

<!-- page 35 -->

12.3. PRE-B|D CLAR!FtCAT!ONS
12.3.1. B! DDERS qUERt ES

The prospective bidder requiring any clarification on the tender shall contact the
Department of Agriculture and Farmers Welfare, Puducherry through email by sending
their queries at agri.pon@gov.in in the format as per Annexure-1 at least days before

7

the last date of submission of Proposals. Beyond this limit no queries would be
entertained. The Department of Agriculture and Farmers Welfare, puducherry will
provide clarifications to only those queries which would be received as specified in
"Schedule of RFP". All future correspondence/corrigendum in respect of the RFp shall
b e p u b I i s h e d o n h Lt p

s:lp udut-errd e rs.gov. in/ .

12.7.2. CLARIFICATION TO PRE-BID qUERIES / TSSUE OF CORRTGENDUM

a. Clarification to the queries received would be published on
https-//p-udutenders,gov-inl. as per the timeline specif ied. H owever,
the Department of Agriculture and Farmers Welfare, Puducherry makes
no representation or warranty as to the completeness or accuracy of
any response made in good faith, nor does the Department of
Agriculture and Farmers Welfare, Puducherry undertake to answer all
the queries that have been posed by the bidders.

b. At any time prior to the last date for receipt of bids, the Department of
Agriculture and Farmers Welfare, Puducherry may, for any reason,
whether at its own initiative or in response to a clarification requested
by a Prospective Bidder, modify the RFP Document by a corrigendum.

c. After the pre-bid conference/meeting, the corrigendum (if any) &
clarifications will be published in the Portal as per the timeline
specified. No individual communication will be made to the queries.

d. Any corrigendum(s) published/issued shall be deemed to be
incorporated into this RFp.

e. ln order to give prospective Bidders reasonable time in which to take
the corrigendum into account in preparing their bids, Department of
Agriculture and Farmers Welfare, Puducherry may, at its discretion,
extend the last date for the submission of proposals.

r2.4. PERIOD OF VALIDtTy OF PROPOSALS
The proposals submitted by bidders shall be valid for a period of
9o days from
the date of submission of the proposal. On completion of the validity period, in case
required, Department of Agriculture and Farmers Welfare, Puducherry would solicit
the bidder's consent to an extension of the period of validity. The request and the
responses there to shall be made in writing by post or email.
Request for Proposal for Prolects under Digitat Agricutture of the Ministry of Agriculture and FormersWelfore,
New Delhi for the Deportment of Agriculture ond Farmers Welfare, puducherry

3sle1

<!-- page 36 -->

12.5. cosT oF RFP

The proposer shall bear all costs associated with the preparation and
submission of their proposal and the Department of Agriculture and Farmers
Welfare, Puducherry shall not be responsible or liable for those costs regardless of
the conduct or outcome of the bid process.
T>.6. CURRENCY OF THE PROPOSAL PAYMENT

The currency of the proposal offers and the payments made (commercial
transactions) shall be in Indian Rupees (lNR).
r2.7. ALTERNATIVE / MULTIPLE PROPOSALS
Alternative/ Multiple Proposals shall not be considered at all.
12.8. WTTHDRAWAL, SUBSTITUTION, AND MOD|F|CATION OF PROPOSAL

i. The bidder may modify, substitute or withdraw proposal after its
submission, prior to the last date prescribed for submission of proposals,
subject to such admission in the e-tender portal and such facilities are not
guaranteed by the Department of Agriculture and Farmers Welfare,
Puducherry. Further, the Department of Agriculture and Farmers Welfare,
Puducherry shall not be responsible for any technical glitches in the etender portal at the time of submission of tender by the prospective
bidders and for any attendant delay / non-submission of the proposal.
ii. No proposal will be allowed to be modified or substituted subsequent to
the last date for submission of proposal.
iii. No proposal may be withdrawn in the interval between the last date for
submission of proposals and the expiration of the period of proposal
validity.

Bidder needs to follow the e-tender portal https://pudutenders.gov,in
processes during withdrawal, substitution, and modification of proposal
and clarifications in respect of BoQ shall be availed from the help desk of
the portal during office hours.
12.9. RIGHT TO TERMINATE THE PROCESS

a) The Department of Agriculture and Farmers Welfare, Puducherry reserves the
right to terminate the RFP process at any time and without assigning any
reason. The Department of Agriculture and Farmers Welfare, Puducherry
makes no commitments, express or implied, that this process will result in a
business transaction with anyone.

b) This RFP does not constitute an offer by the Department of Agriculture and
Farmers Welfare, Puducherry. The bidder's participation in this process may or

may not result in the Department of Agriculture and Farmers Welfare,
Puducherry selecting the bidder to engage towards execution of the contract.
Requestfor Proposal for Projects under Digital Agricullure of the Ministry of Agriculture ond Farmerswelfare,
New Delhi f or the Deportment of Agriculture ond Formers Welfare, Puducherry

l\ ,: ;:, .. 36 | 97

<!-- page 37 -->

12.ro. PUBLTCATTON / ANNOUNCEMENT OF RFP DOCUMENT
The Tender document is available and downloadable in the following website:
https://pud ute nders.gov. in/

rz.rr. EARNEST MONEY DEPOSIT (EMD) i.e. Bid Security

a) fhe bidder shall submit Earnest Money Deposit (EMD) of an amount of
Rupees Four Lakhs and Fifty thousand (Rs.4,5o,oooi-), only through the
portal https://pud utenders.gov.in/.

b) MSEs (wticro and Small lndustries) and Startups registered under Make
in lndia initiative will be exempted from the payment of EMD but shall
submit necessary latest documents to support the claim.

c) Unsuccessful bidder's EMD would be released within 3o working days of
issuing of work order or signing of agreement with successful bidder.

d) The successful bidder's EMD would be returned after submission of
perforrnance Security.

e) The EMD may be forfeited relevant reasons including for the foiiowing
cases:

i.

lf a bidder withdraws his proposal or increases his quoted prices during
the period of proposal validity or its extended period, if any; or

ii. ln the case of a successful bidder who fails to sign the agreement
within the specified time limit.
12.12. PERFORMANCE SECURITY

a) The successful bidder who are eligible under this engagement shall submit a
Performance Guarantee of an amount equivalent lo 10 % of the bid amount in
the form of Performance Bank Guarantee (PBC) for the engagement period
plus 9o days. All charges with respect to the Performance Security shall be
borne by the bidder.

b) The PBG shall be paid within r5 working days of receipt of the work order, as a
measure of expression of commitment for executing the prolect and such bank

guarantee would be discharged after satisfactory completion of the proiects.

c) The Performance Security shall remain with the Department of Agriculture and
Farmers Welfare, Puducherry for the engagement period plus 9o days.

d) The Performance Security shall be returned by the Department of Agriculture
and Farmers Welfare, Puducherry, with whom the ownership of the proiect
rests upon being satisfied that there has been due performance of the
obligations of the bidder under the contract. However, no interest shall be
payable on the performance security.

e) This security may be invoked on violation of any of the conditions in this
Requestfor Proposal for Projects under Digital Alricutture of the Minislry of Agriculture and FormersWelfore,
New Delhi for the Deportment of Agriculture ond FarmersWelfare, Puducherry

i' .r g t' 37 191

<!-- page 38 -->

document including:

i.
ii.

Bidder is not able to deliver services as per SLA.
The bidder or his employee is involved in any unlawful activity during
its engagement with Department of Agriculture and Farmers Welfare,
Puducherry.

iii. lf the Bidder is non-responsive to the requirements raised by the
Department of Agriculture and Farmers Welfare, Puducherry for
consecutive three times.
12.13. SUBMISSION OF PROPOSALS

The e-tender process shall be a three bid system. The proposal shall be submitted

as per the schedule given in the "schedule of RFP". The Pre-Qualification Proposal,
Technical Proposal and Financial Proposal shall be submitted online on
httpsjlpudutenders,gov.in/ portal separately as follows:
Part t: Pre-Qualification Proposal
Part 2: Technical Proposal

Part 3: Financial Proposal
12.1).1. PRE-qUALl Fl CATION P RO POSAL

i. Annexure 2: Declaration (on the letterhead)
ii. Annexure 3: Pre-Qualification Bids (Forms t-6)

a) Form 1; Checklist for Eligibility/Qualification criteria
compliance

b) Form z: Project Details
c) Form 3: Selected bidderi Company information
d) Form 4: Contact Details of officials for correspondence
during proposal process

e) Form 5: Certificate for Average Annual Turnover
f) Form 6: Declaration for Non-Debarment & non-blacklisting
t2.13.2.TECH N ICAL PROPOSAL

Annexure-4 Technical Bid:

i. Form 7: Checklist for Technical Evaluation Criteria compliance
ii. Form 8: Technical Proposal details
12.1j.3. FINANCIALPROPOSAL

i.

Form 9: Financial ProposalAnnexure-5

The Financial proposal shall be submitted ONLY in the portal
httpsJ/pudutenders.gov.[Lon or before the last date of proposal
Request for Proposal for Projects under Digilal Agriculture of the Ministry of Agriculture and FarmersWelfare,
New Delhi f or the Department of Agriculture and Fdrmers Welfare, Puducherry

P;,rgc 38 191

<!-- page 39 -->

submission. Bids received in any other form will not be accepted and may

lead to rejection of the bid. The template of Boe is provided for an
understanding of the bidder in Annexure 5.
Please note that prices/rate should not be indicated by the bidder anywhere

other than Financial Proposal. lf found anywhere before opening of Financial
Bid, their proposal shall be summarily rejected.

Bidders are advised to exercise adequate care in quoting the prices. No
excuse for corrections in the quoted figures will be entertained after the
proposals are submitted to the Department of Agriculture and Farmers
Welfare, Puducherry.
The Bidder should take into account any corrigendum to this RFp document
that may have been published before submitting their proposals.
The pre-qualification bid (Forms at Annexure 2-3), technical bid (Forms at
Annexure 4) should be complete documents and should be in separate
single PDF documents. -All the pages of the bid must be sequentially
numbered and must contain the list of contents with page numbers. Bidders
are required to submit all details as per the formats given in the RFp
document only. Any deficiency in documentation may result in the rejection
of the bid and such decision is at the sole discretion of the Department of
Agriculture and Farmers welfare, Puducherry. Financial bid, as seen in

Annexure 5 shall be entered in the online Boe in the portal
https://puduten ders.gov. in.
The Bidders are requested to go through each section and Annexure of the
RFP document carefully to understand the documents required to be
submitted and the process to be followed as a part of the proposal. Any
deviations may lead to rejection of the proposal.

The Bidder is advised to submit the proposal well before the tast date to
avoid any inconvenience at the last moment. The Bidder will not be allowed
to submit the Proposal after the Bid submission time.
Each document submitted by the bidder's proposals must be duly signed by

the authorized signatory.
Tz.T4.AUTHENTICATION OF BIDS

A letter of authorization shall be supported by a written power-of-attorney
accompanying the bid.

Requestfor Proposal for Proiects under Digital Alriculture of the Ministry of Agricutture ond Formerswelfare,
New Delhi for the Deportment of Agriculture ond Fatmers Welfare, puducherry

, ,l1 , 39 191

<!-- page 40 -->

13. BID EVALUATION
The submitted Bids will be opened as per timeline, by an Officer/team authorized by

Department of Agriculture and Farmers Welfare, Puducherry, in the presence of such of
those Bidders or their representatives who may be present at the time of opening. ln
case of contingency, the virtual meeting may be conducted for the purpose. lf so, a

meeting link will be posted in the Portal of the Department of Agriculture and Farmers
Welfare, Puducherry. (https://agri. py.gov.in/).
There will be three bid-opening events

i. Pre-QualificationProposalopening
ii. Technical Proposal opening
iii. Financial Proposal opening
The tender evaluation committee constituted by the Department of Agriculture
and Farmers Welfare, Puducherry will examine the Proposals to determine whether they
are complete, whether the documents have been attached and properly signed and the

proposals are generally in order. Any proposals found to be non-responsive for any
reason or not meeting any criteria specified in this RFP, will be rejected by the
Department of Agriculture and Farmers Welfare, Puducherry and shall not be included
for fu rther consideration.
The decision of the Tender Evaluation Committee in the evaluation of responses to

the RFP shall be final and binding on all bidders. No correspondence will be entertained
outside the process of evaluation with the Committee. The Tender Evaluation Committee
reserves the right to reject any or all proposals on the basis of any deviations. Each of the
responses shall be evaluated as per the criteria and requirements specified in this RFP.
No enquiry shall be made by the bidder during the course of evaluation of the tender,
after opening of proposal, till final decision is conveyed to the successful bidder(s).
However, the Committee/its authorized representative and the Department of
Agriculture and Farmers Welfare, Puducherry can make any enquiry/ seek clarification
from the bidders, which the bidders must furnish within the stipulated time else the bids
of such defaulting bidders will be rejected.

lnitial proposal scrutiny will be held, and the proposals will be treated as nonresponsive, if they are:

i.
ii.
iii.
iv.

Not submitted in the format as specified in this RFP document;
Found with suppression of details;

Submitted with incomplete information;
Submitted without the documents required under this RFP;

Request for Proposal for Proiects under Digitol Agriculture of the Ministry of Agriculture and Farmerswelfare,

New Delhi for the Deportment of Agriculture dnd Formers Welfare, Puducherry

1' t i:, t: 40 |191

<!-- page 41 -->

v.
vi.
vii.

Non-compliant to any of the clauses mentioned in this RFp;
Lesser validity period than that prescribed in this RFp;

lf it is submitted with conditional and partial offers.

r3.r. EVALUATION CRITERIA
The Department of Agriculture and Farmers Welfare, Puducherry shall evaluate

responses of

the

the bidders to this RFp and scrutinize the supporting

documents/documentary evidence as per standard formats (Annexure 28,4 &
5).
lnability to submit the requisite supporting documents / documentary evidence by the
bidders, may lead to rejection
The decision of the Department of Agriculture and Farmers Welfare, puducherry in

the evaluation of proposals shall be final. No correspondence will be entertained
outside the process of evaluation with Department of Agriculture and Farmers Welfare,
Puducherry. The Department of Agriculture and Farmers Welfare, puducherry may

solicit information in writing/email to seek clarifications or conformations on their
proposals.

During the Proposal Evaluation, the Department of Agriculture and Farmers
Welfare, Puducherry reserves the right to reject any or all the proposals. Each of the
Proposals shall be evaluated as per the criteria and requirements specified in this RFp.

The Tender Evaluation Committee (EC) constituted by the Department of Agriculture

and Farmers Welfare, Puducherry or any committee authorized by the Secretary to
Government (Agriculture), Puducherry shall evaluate the responses to the RFp and all
supporting documents & documentary evidence as mentioned in this section of the
RFP.

The Department of Agriculture and Farmers Welfare, Puducherry reserves the right

to direct the bidders to submit the original documents attached in the technical
proposal to check/ validate the authenticity of the information provided in the prequalification, Technical Evaluation criteria and Financial Evaluation and the requisite
support must be provided by the Bidder. Failure to submit such documents would
result in summary rejection of the bid.
13.2. EVALUATION BASED PRE-qUAL|F|CAT|ON

l.

First the Pre-Qualification Proposal Documents will be reviewed/evaluated

and only those bidders who qualify the minimum requirements (Refer
Section 7- Prequalification) specified in the RFP, will be eligible for
technical evaluation.

ll.

Technical Proposaland Financial Proposal of Bidders who do not meet the

Pre-Qualification criteria will not be opened. All the supporting

documents/ documentary evidence must be attached as per
specifications done in pre-qualification criteria i.e. Section 7 & Form r to
Requestfor Proposal for Projects under Digital Agricutture of the Ministry of Agriculture ond FarmersWelfore,
New Delhi for the Deporhent of Agriculture ond Formerswelfore, puducherry

l' .r s . 41 |19'l

<!-- page 42 -->

Form 6 given in Annexure-3.
r3.3. QUALIry AND COST BASED EVALUATION (qcBS)

o The Technical and Financial Proposalthat will be 8o:zo respectively.
o All the bidders who achieve at least 7o marks in the technical evaluation
only would be eligible for the next stage, i.e. Financial Bid opening.

o The lowest Financial Proposalwillbe given a financialscore of too points.

o The cost indicated in the Financial Proposal shall be inclusive of all taxes
(including GST), duties, fees, levies and other charges imposed or as
applicable under the relevant laws.

o The cost indicated shall be deemed as final and reflecting the total cost
of services and should be stated in INR only. Omissions, if any, in costing
of any item shall not entitle the Bidder to be compensated and the
liability to fulfill its obligations as per the Terms of Reference within the
total quoted price shall be that of the Bidder.
r3.4. TECHNICAL EVALUATION

a) The technical proposal (nefer Form 7 and Form 8 given at Annexure-4) of
Bidders qualified from pre-qualification evaluation will be opened for
technical evaluation. The technical score of all the bidders would be
calculated as per the criteria mentioned below. All the bidders who
achieve at least 7o marks in the technical evaluation would be eligible for
the next stage, i.e. Financial Bid opening.

b) Each of the Technical Bids shall be evaluated against (too) technical Marks.
Evaluation Marks shall be assigned to each Bid on the basis of the
Technical Proposal details and evidences submitted (Refer Form 7 and
Form 8 given at Annexure-4).

c) The Proposal with the highest technical marks shall be given a score of
too(Hundred) points and the other Proposals be given technical score that
are proportional to their marks w.r.t the highest technical marks. The
formula would be as follows:

t. Technical score (in points) = (T/Trrier, )*roo
T- the total technical marks awarded to the Bid
Tnisn

- the Technical Marks achieved by the Bid that was scored

best among all responsive Bids

Note: Technical Mark used to identify the eligible bidder for financial
evaluation shall not be confused with technical score used to
calculate combined weighted score for quality and cost ranking.

Request for Proposal for Projects under Digitol Agriculture of the Ministry of Agriculture ond Farmerswelfare,
New Delhi for the Depdrtment of Agriculture ond Farmers Welfore, Puducherry

l' ,,2 i1,.' 42 | 97

<!-- page 43 -->

d) Upon verification, evaluation/assessment, if in case, any information
furnished by the bidder is found to be false / incorrect, their proposal will
be summarily rejected and no correspondence on the same shall be
entertained.

e) Submission of false/forged documents will lead to forfeiture of EMD and
blacklisting of selected bidder for a minimum period of 3 years from
participating in the Department of Agriculture and Farmers Welfare,
Puducherry tenders.

f) While the Bidder will be -evaluated on the technical evaluation criteria
mentioned, ALL THE DOCUMENTS/FORMS SPECIFIED lN THE RFP (TECHNICAL
PROPOSAL FORMAT (Form 7 and Form 8 in ANNEXURE-4) ARE ALSO
REqUIRED TO BE MANDATORILY SUBMITTED) and non-submission may lead to
rejection of the Proposal.
The minimum technical score (TS) requiredto be qualified is: ao marks

r3.5. EVALUATION OF FINANCIAL PROPOSAL

a) Bidders who secured at least 7o Marks in technical evaluation will be eligible
to participate in financial bid opening process. The Financial Bids (i.e. Form 9 in
Annexure-5) of the technically qualified bidders will be opened on the
prescribed date in the presence of representatives of bidders.

b) After opening of financials bids of eligible bidders, the financial scoring will be
done. As mentioned earlier the weightage of 8o for technical and weightage
of zo will be given to financial score under the evaluation.

c) The lowest financial quoted rate will receive highest marks i.e. too. Scoring to
other higher quoted rate will be assigned using formula indicated below:
Financial Score = (Lowest Rate/Quoted rate) *too

d) After weighted scoring of both technical and financial bids, they will be
combined together and ranked. Highest scorer will secure Rank t, then Rank z
and so on.

e) The Bidder with Rank One based on QCBS system will be selected using
weightage of 8o:zo for Technical and Financial respectively.

f) An illustration of calculation is as under:
A

B

Sr

Name

of the
bidder

c

D

Technical Weighted
Technical
Score
Score
secured(in

points)

(col.
C*o.8o)

E

F

G

H

I

Actual

Financial
Score

Financial
Score

Total
score

Rank

Financial

Weighted (Col. D+
(Col.
col. G)
Quote (in Rate/ Quoted
F*o.zo)
Rate)* too
%)
Rate/

(Lowest

Requestfor Proposal for Projecu under Digitol Agriculture of the Ministry of Agriculture ond FormersWelfare,
New Delhi f or the Deportment of Agriculture and Farmers Welfare, Puducherry

['agc 43197

<!-- page 44 -->

Highest

1

1

Score
2

n

g) lf a Bidder quotes NIL charges / consideration, the bid shall be treated as
unresponsive and will not be considered.

h) Abnormally low financial bids will be handled as per the guidelines issued by

the

Ministry of

Finance, Government of

lndia

(https://doe.gov.in/sites/defa u lt/f iles/Predatory%zopricing%zo%zoAbnormally%zoLow%zoBids.pdf) and for predatory pricing and abnormally

low bids evaluations. and, any conditional bid would be rejected.

i) Errors & Rectification: lf there is a discrepancy between Words and Figures,
the Figure indicated in Words will prevail".

8.6. EXCLUSION OF PROPOSAL/ DISqUALIFICATION
The Department of Agriculture and Farmers Welfare, Puducherry may
exclude or disqualify a proposal if:

t. The information submitted was found to be false or constituted a
misrepresentation; or
r. The information submitted, was found to be materially inaccurate or
incomplete; and
ttt. The proposer is not qualified as per pre-qualification/ eligibility criteria

mentioned in the bidding document, even after seeking clarifications/
additional documents by committee;
tv. The proposal materially departs from the requirements specified in
the proposal or it contains false information;

v. The proposer submitting the proposal, his agent or any one acting on
his behalf, gave or agreed to give, to any officer or employee of the

Department of Agriculture and Farmers Welfare, Puducherry or other
governmental authority a gratification in any form or any other thing
of value so as to unduly influence the Tender Process;
vt. A proposer, in the opinion of the Department of Agriculture and
Farmers Welfare, Puducherry, has a conflict of interest materially
affecting fair com petition.
vtt. A proposal shall be excluded/ disqualified as soon as the cause for its
exclusion/disqualification is discovered.
vttt. Any attempt by a bidder to influence the Department of Agriculture
and Farmers Welfare, Puducherry in the evaluation of the proposal or
contract award decisions may result in the refection of its proposal.
Request for Proposal for Projects under Digitol Agriculture of the Ministry of Agriculture and FarmersWelfare,
New Delhi for the Department of Agriculture ond FormersWelfore, Puducherry

l' .,t 1; t: 44 | 97

<!-- page 45 -->

14. AWARD CRITERTA

The Department of Agriculture and Farmers Welfare, Puducherry will award the

Contract to the Best Value Bidder (Lr Aidder), finalized as per the overall Quality and
Cost based Evaluation (qCBS) mentioned above.

15. RIGHT TO ACCEPT / REJECT ANY OR ALL PROPOSAL(S)

The Department of Agriculture and Farmers Welfare, Puducherry reserves the
right to accept or reject any proposal, and to annul the tendering process / Public
procurement process and reject all proposals at any time prior to award cf contract,
without thereby incurring any liability to the affected bidder or bidders or any
obligation to inform the affected bidder or bidders of the grounds for the
Departrnent of Agriculture and Farmers Welfare, Puducherry action.
16. NOT!FICATION OF AWARD

Prior to the expiration of the validity period, the Department of Agriculture and
Farmers Welfare, Puducherry will notify the successful bidder in writing or through
email, that its proposal has been accepted. The notification of award will constitute the

formation of the contract upon the successful bidders' furnishing of Performance Bank
Guarantee (PBC) ot'to% of the bid amount within r5 days of receipt of the work order.
The award would be given after approvals as required under the procedures are
obtained by the Department of Agriculture & FW, Puducherry and communicated to the
Department of Agriculture and Farmers Welfare, Puducherry.
17. CONTRACT FINALIZATION AND AWARD

a. The Department of Agriculture and Farmers Welfare, Puducherry shall
reserve the right to negotiate with the bidder(s) whose proposal has been

ranked best value bid on the basis of Technical and Financial Evaluation to
the proposed Project.

b. After the Department of Agriculture and Farmers Welfare, Puducherry
notifies the successful bidder that its proposal has been accepted, t h e
Department of Agriculture and Farmers Welfare, Puducherry shall enter
into a contract, incorporating all clauses, pre-bid clarifications and the
proposal of the bidder(s) between the Department of Agriculture and
Farmers Welfare, Puducherry and the successful bidder(s).
18. FAILURE TO AGREE WITH THE TERMS AND CONDITIONS OF THE RFP

Failure of the successful bidder(s) to agree with the Legal Agreement and
Terms & Conditions of the RFP shall constitute sufficient grounds for the annulment

of the award.

ln such a case, the Department of Agriculture and Farmers Welfare,
Puducherry may penalize with the suspension for participation in future for a period

of up to one year.
Request for Proposal for Projects under Digitol Agriculture of the Ministry of Agriculture ond FormersWelfore,

NewDerhiforthe Deportmentof AgricultureondF,rmerswerfare,puducherry

i, ,, l-i , 45 | g1

<!-- page 46 -->

19. PENALTTES AND SERVTCE LEVEL AGREEMENT (SLA)

The purpose of this Service Level Agreement (hereinafter referred to as SLA)
is to define the levels of services which shall be provided by the Supplier as per

the Scope of Work mentioned in the RFP to the department for the duration of
the contract period of the Project.
Subject to conditions of Contract if the successful bidder fails to deliver or
perform the Services within the period(s) specified in Criteria's indicated in
Deliverables, competent authority shall, without prejudice to its other remedies
under the Contract, deduct from the invoices or PBC, as penalty, deduction
would be undertaken as per the penalties defined in penalty section.
Penalty terms
sl.
No
1

Deliverables / Service Level Description
Required set of Documentation work

Timelines / Min
Expected SLA

Applicable Penalty

7th week

Rs. 25ool- post 7th
week for each day
delay.

2

Developm ent of applications:

2oth week

Selected bidder need to ensure the
presentation of the project plan with
detailed schedule for development of

Rs. z5oo/- post zoth

week for each day
delay.

application and adherence of the

scheduled completion of

the

development activity
3

Resource should function in the

3oth =week

development/testing with roo% allocation
i.€., without any other project work
allocation:
The Selected bidder need to produce the
Name list of developers and Tester who

Rs. z5oool- if any
resource identified

that they

are

working in different

project other than
this project.

allocated to the project without any
other allocation of work in different
project till the completion of the
development / testing phase of the
project
4

Replacement of resources -Maximum Replacement
Rs. 5o,ooo/- per
replacement of resources allowed zo% of beyond zo% in resource
the initial total allocated resources.
the Project
timeline

5

Delay in Project Milestone Delivery

Each Level of

Rs. 5o,ooo per week

Milestone
Request for Proposol for Proiects under Digitol Agricullure of the Ministry of Agriculture and FarmersWelfare,

New Delhi for the Deportment of Agriculture ond Formers Welfore, puducherry

i' .t 1:, t' 46 | 97

<!-- page 47 -->

need to

be

taken
6

Delay in Manpower Deployment onsite

7

Delay in bug resolution post testing

8

Delay in Go-Live from the agreed date

Each Software
development
and Tester and
other relevant
domain
experts
Testing
Schedule
should not
lead to delay in

Rs. z5,ooo per week

Rs. 5ooo per week

Co-Live

The

agreed
date as per the

Rs. 1,oo,ooo per
week

contract for
Go-Live should

not

be

changed
9

em Availability - Critical, which means

it has dependency on day to day
of the respective system

Min

SLA

Expected to be

Rs 3oo Per Working
Hour

Less than 1o
H

ours

(.r o

hours)
10

m Availability - Non-Critical, which
eans that it does not have the dependency
day to day functioning of the respective

Min

SLA

Expected to be
7 working days

Rs 5ooo per day

Beyond io days Rs
loooo per day

Note:

1. Scope of work is as mentioned in the RFp
2. Review period taken by the authority for various draft versions submitted
and sign-off period shall be excluded in calculation of timeline for SLA and
penalty purpose

3. The selected bidder needs to have enough skilled manpower in position
and capable of supporting the deliverables mentioned in RFp

4. lf the cumulative penalty under SLA exceeds rc% of the contract value
then the selected bidder's security deposit will be forfeited

5. There will be no change in the rates finalized upon award of tender to
successful bidder during the period of implementation and maintenance &

support

Request for Proposal for Proiects under Digitot Agriculture of the Ministry of Agriculture and FarmersWelfore,

NewDelhifortheDeportmentof AgriculturedndFormersWelfare,puducherry

i, ,,..1 , 47 lgj

<!-- page 48 -->

6. A Non-Disclosure Agreement shall be obtained from all the resources
deployed for the Project as detailed in Annexure-9.

7. The SLA to be furnished by the successful bidder shall be as provided in
Annexure-1't.

It is clarified here that, the SLA terms and condition can be modified accordingly if
suitable reasons and request placed by the successful bidder before starting of the
delivery milestones and further such modified SLA will be in place with mutual
consent between the parties to the contract. Further, relaxation in the imposition of
penalty prescribed in the SLA, if any shall be at the discretion of the Secretary to
Government (Agriculture), Puducherry subject to satisfaction of the reasons.
20. OTHER TERMS:

l.

lf during the engagement period, the total value of penalty is more than to% of
the total value of the invoice raised during the Project tenure, the contract of
the selected bidder may be terminated and the Performance Bank guarantee
may be forfeited. Duration of year will be calculated as 365 days from the date
of signing of the agreement

ll. ln case the selected bidder is not satisfied with the manner in which or amount
of penalties that were levied as above for not meeting the deliverables within
the timelines, the selected bidder may represent the matter to the Department
of Agriculture and Farmers Welfare, Puducherry for decision. The selected

bidder while requesting for penalty waive-off and/or timeline
reduction/extension will be required to present written document detailing the
justification for the request. Such request would be considered by the
Department of Agriculture & Farmers Welfare, Puducherry, on merits.

lll, Only recorded communication such as email or letter will be accepted as
"Communication" for applicability of the above penalty clauses.

lV. Even after this if there is disagreement, the matter may be resolved as per
Section 38'Settlement of Disputes'mentioned in the RFP.

21. LATE PROPOSAL
Proposal submitted after due date and time shall not be accepted.

zz. CANCELLATION OF TENDER PROCESS

l. If any bidding process has been cancelled, it shall not be reopened but it
shall not prevent the Department of Agriculture and Farmers Welfare,
Puducherry from initiating a new proposal process for the same subject
matter of procurement, if required.

ll. The Department of Agriculture and Farmers Welfare, Puducherry may, for
reasons to be recorded in writing, cancel the process of procurement
Request for Proposal for Projects under Digitol Agriculture of the Ministry of Agriculture and FormersWelfare,
New Delhi f or the Deportment of Agriculture and Formers Welfore, Puducherry

{} ;,t 7,'^1 48 | 91

<!-- page 49 -->

initiated by it at any time prior to the acceptance of the successful
proposals; or after the successful pr:oposal is accepted in accordance with
below:

1) lf a proposer is convicted of any offence under the prevailing law, the
Department of Agriculture and Farmers Welfare, Puducherry may:
a. Cancel the relevant Tender Process if the proposal of the convicted
proposer has been declared as successful but no procurement
contract has been entered into;
b. Rescind the relevant contract or forfeit the payment of all or a part of
the contract value if the procurement contract has been entered into
between the Department of Agriculture and Farmers Welfare,
Puducherry and the convicted proposer.
2l lf it determines that the bidder recommended for award or on whom the
contract / award had already been placed or has engaged in corrupt or
fraudulent practices in competing for the contract/award in question.
lll. The decision of the Department of Agriculture and Farmers Welfare,
Puducherry to cancel the piocurement and reasons for such decision shall
be immediately communicated to all the bidders who participated in the
tender process.

23. INTERFERENCE WITH TENDER PROCESS
For a bidder, who withdralv from the tender process after opening of financial
proposal or who withdraw from the tender process after being declared successful

or who fail to enter into contract after being declared successful or who fail to
provide performance security or any other document or security required in terms of
the bidding documents after being declared successful, without valid grounds, in
addition to the recourse available in the bidding document or in the contract, EMD
submitted would be forfeited.
24. DEBARMENT FROM BIDDING

l. lf the Department of Agriculture and Farmers Welfare, Puducherry finds that
a proposer has breached the code of integrity (Annexure-6) prescribed in the
RFP, it may debar the proposer for a period of three years.

ll. Where the entire proposal security or the entire performance security or any
substitute thereof, as the case may be, of a proposer has been forfeited by
the Department of Agriculture and Farmers Welfare, Puducherry in respect
of any tender process or procurement contract, the proposer may be
debarred from participating in any tender process undertaken by the
Department of Agriculture and Farmers Welfare, Puducherry for a period of
three years.

lll.The Department of Agriculture and Farmers Welfare, Puducherry, as the
Request for Proposal for Projects under Digitol Agriculture of the Ministry of Agriculture and FarmersWelfore,
New Delhi for the Deportment of Agriculture ond Formers welfore, Puducherry

i' ,: 1 ,, 49 191

<!-- page 50 -->

case may be, shall .not debar a proposer under this section unless such
proposer has been given a reasonable opportunity of being heard.
25. MONITORING OF CONTRACT

lf delay in delivery of service is observed, a performance notice would be given to
the selected proposer to speed up the delivery. Any change in the constitution of
the selected bidder etc. shall be notified forth with by the contractor in writing to

The Department of Agriculture and Farmers Welfare, Puducherry within thirty
days of such change. Such change shall not relieve the selected bidder, from any
liability under the contract.

26. CORRUPT/FRAUDULENT PRACTICES

l. The Department of Agriculture and Farmers Welfare, Puducherry requires
that the bidders under this tender shall observe the highest standards of
ethics during the execution of such contracts. ln pursuance of this policy, The
Department of Agriculture and Farmers Welfare, Puducherry defines the
terms set forth as follows:

a. "Corrupt Practice" means the offering, giving, receiving or soliciting of
anything of value to influence the action of the public official in the
award of the contract, in contract execution;

b. "Fraudulent practice" means a misrepresentation of facts in order to
influence award of contract or an execution of a contract to the
detriment of The Department of Agriculture and Farmers Welfare,
Puducherry, and includes collusive practice among bidders (prior to or
after proposal submission) to deprive The Department of Agriculture
and Farmers Welfare, Puducherry of the benefits of the free and open
competition.

ll. ln the event of corrupt practice and fraudulence, in addition to penal action
as per the terms and conditions of the contract, legal action may also be
initiated against the bidder and others concerned. Apart from termination of
contract, The Department of Agriculture and Farmers Welfare, Puducherry
may also forfeit the PBG submitted by the bidder.
lll.The Department of Agriculture and Farmers Welfare, Puducherry will declare
a bidder ineligible after giving opportunity of being heard, either indefinitely
or for a stated period of time, to be awarded a contract, if at any time it is
found that the bidder has engaged in corrupt and fraudulent practices in
competing for, or in executing, this contract.
27. GENERALTERMS AND CONDTTTONS OF PROPOSALAND CONTRACT

Bidders should read these conditions carefully and comply strictly while
sending their proposal.
Requestfor Proposol for Proiects under Digital Agriculture of the Ministry of Agriculture and FormersWelfore,
New Delhi for the Depdrtment of Agriculture and FarmersWelfare, Puducherry

L'age 50 191

<!-- page 51 -->

Note: The bidder shall be deemed to have carefully examined the conditions of
the services to be rendered. lf the bidder has any doubts as to the meaning
of any portion of these conditions, he shall obtain clarification(s) before
submitting the proposal and signing the contract with The Department of
Agriculture and Farmers Welfare, Puducherry.
27.r. SIGNING OF CONTRACT

The successful bidder(s) shall execute an agreement within t5 days
from the date of issuance of Letter of lntent (Lol) (or work order if Lol is not
issued) with The Department of Agriculture and Farmers Welfare,
Puducherry. ln addition to terms and conditions being mentioned
hereunder, all terms and conditions of the tender and corrigendum issued
shal! also be applicable for the contract.
27.2. EXECUTION OF AGREEMENT

During the term of contract, the selected bidder will work closely with
the Department of Agriculture and Farmers Welfare, Puducherry and will

perform the activities as per the scope of work. ln case of poor performance,
non-responsiveness or unjustified & repeated delays of the work taken, The
Department of Agriculture and Farmers Welfare, Puducherry shall terminate
the agreement. ln this case, the performance security shall be forfeited.
27.3. FAILURE TO AGREE WITH THE TERMS AND CONDITIONS OF THE TENDER

Failure of the successful bidder to agree with the Terms & Conditions of
the contract shall constitute sufficient grounds for the cancellation of the

proposal or annulment of the award. ln such circumstances, The
Department of Agriculture and Farmers Welfare, Puducherry would reiect
the proposal or annul the award and forfeit the EMD as specified in the
document.
27.4. CONTRACT DOCUMENTS

Subject to the order of precedence set forth in the agreement, all
documents forming the Contract (and all parts thereof) are intended to be
correlative, complementary, and mutually explanatory.
28. CONFIDENTIALITY

r) Selected bidderlselected bidder shall keep all the details and inf ormation
confidential with regard to the assignment, project information's including
dOCuments, featureS, system, code, facilities, Operations, management and
maintenance of the systems/facil ities.

2) The Department of Agriculture and Farmers Welfare, Puducherry shall retain all
rights to prevent, stop and if required take the necessary punitive action against
Request for Proposal for Proiects under Digitat Agricutture of the Ministry of Agriculture and FarmersWelfare,

NewDelhifortheDeportmentof AgricultureandFormeBwelfore,Puducherry

l,

:..i 51 191

<!-- page 52 -->

Selected bidder regarding any forbidden disclosure.

l) For the avoidance of doubt, it is expressly clarified that the aforesaid provisions
shall not apply to the following information:

a. lnformation already available in the public domain;
b. lnformation which has been developed independently selected
bidder/selected bidder;

c. lnformation which has been received from a third party who had the right to
disclose the aforesaid information;

d. lnformation which has been disclosed to the public pursuant to a court order.
+) Any handover of the confidential information needs to be maintained in a list,
both by the Department of Agriculture and Farmers Welfare, Puducherry &
Selected bidder, containing at the very minimum, the name of provider, recipient,

date of generation of the data, date of handing over of data, mode of
information, purpose and signatures of both parties.

5) Notwithstanding anything to the contrary mentioned hereinabove, selected
bidder shall have the right to share the Letter of lntent / work order provided to
it by The Department of Agriculture and Farmers Welfare, Puducherry in relation
to this Agreement, with its prospective purchasers solely for the purpose of and
with the intent to evidence and support its work experience under this
agreement.
29. coPYRtcHT

The copyright in all materials containing data and information furnished to

the Purchaser by the selected bidder herein, as part of responsibility within
scope of this contract, shall remain vested with the Department of Agriculture
and Farmers Welfare, Puducherry.
30. INTELLECTUAL PROPERTY RTGHTS
3O.1. OWNERSHIP/LICENSING OF FOREGROUND TNTELLECTUAL PROPERTY

Ownership of Foreground lP vests in the Department of Agriculture and Farmers
Welfare, Puducherry. No limits as to use, exploitation, reproduction, adaptation
or sublicensing of Foreground lp.
3o.2. PRODUCTS AND FTXES

1. All licenses bought under this agreement shall be bought on behalf of and in the
name of the Department of Agriculture and Farmers Welfare, Puducherry or
mentioning the Department of Agriculture and Farmers Welfare, Puducherry as
the end user of such licenses.

2. "Product" means any computer code, web-based services, or materials
comprising commercially released, pre-release or beta products (whether
Requestfor Proposol for Proiects under Digitat Agricutture of the Ministry of Agricutture and FarmersWelfare,
New Delhi for the Deportment of Agriculture ond FarmersWelfore, Puducherry

Pagc 52197

<!-- page 53 -->

licensed for a fee or no charge) and any derivatives of the foregoing which are

made available to the Department of Agriculture and Farmers Welfare,
Puducherry for license which is published by product owner or its affiliates, or a
third party.

3."Fixes" means product fixes that are either released generally (such as
commercial product sert,ice packs) crthat are provided to you when performing
services (such as workarounds, patches, bug fixes, beta fixes and beta builds)
and any derivatives of the foregoing.

4. All intellectual property rights in any development/enhancement/customization
etc. done on the products pursuant to this agreement shall be owned by the
Department of Agriculture and Farmers Welfare, Puducherry. Source code/
product available under open source policy as per DIT guidelines is exempt from
the above clause pr-ovided that the enhancements done under the project are
made available in the open source.
3o.3. BESPOKE DEVELOPMENT

1. Upon acceptance of any bespoke development as per this Agreement or RFP,
the ownership of all IPR rights in any and all bespoke development done
specifically for Puducherry during the Term for implementation of the Project
under this Agreement will lie with the Department of Agriculture and Farmers
Welfare, Puducherry.

2. The bidder shall provide source code, object code and all other relevant
materials, artifacts etc. of all bespoke development to the Department of
Agriculture and Farmers Welfare, Puducherry and the Department of Agriculture
and Farmers Welfare, Puducherry shallown all IPRs in them.

3.AIl material related to such bespoke development shall be treated as
confidential information by the bidder.

4. The ownership of all IPR rights in anyand all documents, artifacts, etc. (including
all training material) made during the Term for implementation of the Project
under this Agreement will lie with the Department of Agriculture and Farmers
Welfare, Puducherry.
31. GOVERNING LAW

The Contract shall be governed by and interpreted in accordance with
the laws of the Union Territory of Puducherry prevalent during & at the time of
signing of contract. The courts in Puducherry and the Honorable High court of
Madras shall have the jurisdiction.

3r.r. COMPLIANCE WITH THE LAW
1) Selected bidder/selected bidder shall not discriminate against any candidate
Requestfor Proposal for Projects under Digital Agriculture of the Ministry of Agriculture and FormersWelfore,
New Delhi for the Department of Agricultute and Formers Welfore, Puducherry
.

.

53 | 9I

<!-- page 54 -->

for recruitment because of race, religion, creed, color, sexual orientation, dE€,
national origin, pregnancy, genetic information, marital status or the presence
of any sensory, gender, mental or physical disability. Selected bidder/selected
bidder shall strictly adhere to eual opportunity laws in lndia.

z) The Selected bidder/selected bidder shall comply with all its obligations under
Data Protection Law which means any applicable law, regulation, ordinance,
rule, judgment, decree, directive, voluntary code, or court order between a
Covernment Authority and the Department of Agriculture and Farmers
Welfare, Puducherry or Selected bidder/selected bidder containing personal
data protection or privacy requirements etc.

3) The development of applications and its standards shall be in conformity with
the guidelines issued from time to time by the Government of lndia or any of
its organization(s) assigned by it.
32. RECOVERTES FROM SELECTED BIDDER

t) Recovery of penalties shall be made ordinarily from bills.
z) The Department of Agriculture and Farmers Welfare, Puducherry shall
withhold amount to the extent of shortcomings of the delivery of services
unless these are completed as per the SLA. In case of failure to withhold the
amount, it shall be recovered from dues of the selected bidder and
performance security deposit available with The Department of Agriculture
and Farmers Welfare, Puducherry. The balance, if any, shall be demanded
from the selected bidder / selected bidder and when recovery is not possible,
the Department of Agriculture and Farmers Welfare, Puducherry shall take
recourse to law in force.
33. TAXES & DUTTES

TDS, if applicable for any tax, shall be done as per law in force at the time of

execution of the contract.

lf any tax exemptions, reductions, allowances or privileges may be available
to the successful/ selected proposer / selected bidder, the selected bidder shall
use its best efforts to benefit from any such tax savings to the maximum
allowable extent, without any negative impact on the Department of Agriculture
and Farmers Welfare, Puducherry and the contract. Any future changes in tax
provision either by Central or State government shall be applicable.
34. MANDATORY FURNISHING OF GST PARTIcULARS

The Contractor / Service provider shall mandatorily furnish the following
documents to the Commissioner, Commercial Tax:

1) Copy of the Work Order.
2) HSN Code of Goods and Service Account Code of Services which shall be
Request for Proposal for Proiects under Digital Agriculture of the Ministry of Agriculture ond Formerswelfare,

New De/hi for the Deportment of Agri.ulture ond I ormers Welf are, puducherry

lt :r :,2 ;.: 54 | 97

<!-- page 55 -->

supplied during the execution of the contract.

3) CST Rate at which the CST would be paid to the Commercial Tax Department
against each of the items in (ii) above.
The information shall be submitted to the Commissioner, Commercial Tax, with a

copy to the procuring/Covernment Entity, within r5 calendar days of receipt of
the work order.

j5. FORFEITURE OF PERFORMANCE BANK GUARANTEE
The Performance Bank Guarantee (PBC) to be furnished by the successful
bidder shall be as prescr-ibed in A.nnexure-g.
Forfeiture of Performance Bank cuarantee: The Performance Bank Cuarantee, in
full or part may be forfeited in the following cases:

a. When the terms and conditions of contract is breached/infringed.
b' When contract is being terminated due to non-performance of the Successful
Bicider.

Notice clf reasonable time will be given in case of forfeiture of security deposit.
The decision of the Department of Agriculture and Farmers Welfare, puducherry
in this regard shall be final.
36. PAYMENTS

i. Payment would be made in lndian Rupees only
ii. No advance payment would be made and the payment for the projects would be
only in installments, as approved by the Tender Evaluation Committee and further
subject to the release of financial assistance by the Ministry of Agriculture and
Farmers Welfare, New Delhi and further approval for release by the competent

authority of the Government of puducherry.
iii- lnvoices will have to be raised in favour of The Department of Agriculture and

Farmers Welfare, Puducherry based on the instalment plan released by the

committee with the relevant document proofs. Payments shall be subject to
deductions of any amount for which the selected bidder is liable as per the penalty
clause of this RFP document. Further, all payments shall be made subject to
deduction of TDS (Tax Deduction at Source) as perthe applicable Acts & Laws.
iv. After acceptance of the invoice along with the supporting documents, the invoice

would be processed for release of payment within 3o working days after due
verification of the invoice & other supporting documents and such payment would
also be based on the certification by the Department of Agriculture and Farmers
Welfare, Pud ucherry for satisfactory completion.

v. No Payment shall be made in advance to neither the Selected bidder/selected
bidder nor any loan from any bank or financial institution be recommended on the
basis of work award.
Request for Proposal for Proiects under Digitot Agriculture of the Ministry of Agricutture and Farmers
Welfare,

NewDelhifortheDeportmentof AgricultureondFormersWelfore,puducherry

i,

.t

S.5 | 91

<!-- page 56 -->

vi. No interest/charges shall be paid on delayed payments.
vii.The selected bidder / selected bidder shall not be paid any extra charges (or any

out-of-pocket expense) against such items which are required for performing
proper and efficient working.
37. TENDER EVALUATION COMMITTEE

The tender evaluation committee (shortly tender committee) shall comprise

the Secretary to Government (Agriculture), Puducherry as Chairman and Director
(tt), Senior Consultant, SeMT of Gol attached to lT Department, Puducherry;
Director of Agriculture and Farmers Welfare, Puducherry as Member Secretary; The

Director of Agriculture and Farmers Welfare, Puducherry shall co-opt a
Junior/Senior Accounts Officer/Officials dealing with accounts nor budget of the
Department and the Dy. Director of Agriculture (Tech ll) cum Nodal officer (Digital
Agriculture) of the Directorate of Agriculture and Farmers Welfare, Puducherry as
Members. The Secretary to Government (Agriculture), Puducherry as Chairman of
the Tender Evaluation Committee reseryes the right to co-opt a technical member
from NlC, Puducherry, or constitute sub-committees, if desired.

The Department of Agriculture and Farmers Welfare, Puducherry shall be
responsible for floating the RFP and monitoring the progress of assignment,
oversee that the assignment is carried out as per the contract, to assess the quality
of deliverables, to accept/reject any part of assignment, to levy appropriate
liquidated damages or penalty if the assignment is not carried out as per the
contract and if the quality of services is found inferior and for any such deficiency
relate to the completion of assignment. The tender committee shall also approve
the release of payments. Monitoring the progress of the project entails the
following activities.
i. lssuing the notice to proceed
ii. Review the inception phase
iii. Deciding on possible modifications to scope of work and issuing contract
variations
iv. Monitoring Progress of assignment, monitoring that resources are actually
deployed as per the scope of work to ensure that timely completion of
projects in accordance with contract.
v. Billing, payment and monitoring the expenditure vis-i-vis progress
vi. Resolving the problems faces by services providers and dealing with disputes
and arbitration
vii. Terminating services prior to the end of the contract and
viii. ielease of installments of payment and final payment and guarantees (if any)
and closing the contract
ix. Post contract evaluation
Request for Proposal for Proiects under Digitol Agriculture of the Ministry of Agriculture and FarmersWelfare,

New Delhi for the Department of Agriculture ond FormersWelfore, Puducherry

l.',tgc 56 191

<!-- page 57 -->

38. TERMTNATTON OF THE CONTRACT

a. The Department of Agriculture and Farmers Welfare, puducherry, by written
notice sent to the Successful Bidder may terminate the Contract, in whole or in
part, at any time for its convenience. The notice of termination shall specify
that

termination is for the Department of Agriculture and Farmers welfare,
Puducherry convenience, the extent to which performance of the Successful
Bidder under the Contract is terminated, and the date upon which such

termination becomes effective. However, any undisputed payment to the invoices
of the task accomplished by successful bidder would be paid by the Department
of Agriculture and Farmers Welfare, puducherry.

b' lf the selected proposer becomes bankrupt or otherwise insolvent, termination
will be without compensation to the selected proposer, provided that such
termination will not prejudice or affect any right of action or remedy that has
accrued or will accrue thereafter to the Department of Agriculture and Farmers
Welfare, Puducherry.
39. SETTLEMENT OF DISPUTES

If any dispute of any kind whatsoever arise between the Department of
Agriculture and Farmers welfare, Puducherry and the successful bidder in
connection with or arising out of the contract, including without prejudice to the
generality of the foregoing, any question regarding its existence, validity
or
termination, shall be governed by the agreement entered between The
Department of Agriculture and Farmers Welfare, Puducherry and successful
bidder in the format given in the Annexure -ro. The place of arbitration shall be
Puducherry and all legal disputes are subject to the jurisdiction of courts
at
Puducherry and Honorable High court of Madras.

40. FORCE MAJEURE
4o.r. DEFINITION

i.

For the purposes of this Engagement, ,,Force Majeure,, means an event

which

is beyond the reasonable control of a Party, is not foreseeable, is unavoidable

and not brought about by or at the instance of the party claiming to be
affected by such events and which has caused the non-performance or delay
in performance, and which makes a Party's performance of its obligations
hereunder impossible or so impractical as reasonably to be considered
impossible in the circumstances, and includes, but is not limited to, war, riots,
civil disorder, earthquake, fire, explosion, storm, flood or other extreme
adverse weather conditions, strikes, lockouts or other industrial action
(except where such strikes, Iockouts or other industrial action are within the
power of the Party invoking Force Majeure to prevent), confiscation or any
other action by Government bidder.
Request for Proposal for Proiects under Digilal Agriculture

of the Ministry of Agriculture ond Formerswelfare,
New Delhi f or the Deporlment of Agriculture and Formers Welf ore, puducherry

i :,1 i 57 |191

<!-- page 58 -->

ii. Force Majeure shall not include:
a. any event which is caused by the negligence or intentional action of a Party
or by or of such Party's agents or employees, nor

b. any event which a diligent Party could reasonably have been expected both
to take into account at the time of the conclusion of this Engagement, and
avoid or overcome in the carrying out of its obligations hereunder.

iii.

Force Majeure shall not include insufficiency of funds or inability to make any
payment required hereunder.

4o.2.. NO BREACH OF TERMS AND CONDITIONS

r. The failure of a Party to fulfil any of its obligations stated as Terms and
Conditions shall not be considered to be a breach of, or default under, this
Engagement insofar as such inability arises from an event of Force Majeure,
provided that the Party affected by such an event

i.

has taken all reasonable precautions, due care and reasonable alternative
measures in order to carry out the terms and conditions of this Engagement,
and

has informed the other Party as soon as possible about the occurrence of
such an event.
4o.3. MEASURES TO BE TAKEN

t. A Party affected by an event of Force Majeure shall continue to perform its
obligations under the specified Terms and Conditions as far as is reasonably
practical, and shall take all reasonable measures to minimize the consequences
of any event of Force Maieure.

l. A Party affected by an event of Force Majeure shall notify the other Party of such
event as soon as possible, and in any case not later than fourteen (t4) days
following the occurrence of such event, providing evidence of the nature and
cause of such event, and shall similarly give written notice of the restoration of
normal conditions as soon as possible.

ttt. Any period within which a Party shall, pursuant to this Engagement, complete
any action or task, shall be extended for a period equal to the time during which
such Party was unable to perform such action as a result of Force Majeure.

rv. During the period of their inability to perform the Services as a result of an event
of Force Majeure, the Bidder, upon instructions bythe "Purchaser", shalleither:

i.
ii.

Demobilize;or
Continue with the Services to the extent possible, in which case the Bidder
shall continue to be paid proportionately and on pro-rata basis, under the
terms and conditions of this Engagement.

Request for Proposol for Proiects under DiEitol AEriculture of the Ministry of Agriculture ond FarmersWelfare,

New Delhi for the Deportment of Agriculture ond Formers Welfore, Puducherry

I',rgc 58 191

<!-- page 59 -->

v. ln the case of disagreement between the Parties as to the existence or extent of
Force Maieure, the matter shall be settled according to Section

38 - Settlement

of Disputes.
4r. OTHER CONDITIONS

t. The selected bidder shall bear the expenses regarding delivery of services.
ll. The selected bidder shall not, under any circumstances, revise the rates
already approved for services. Any request for an increase in the rates will
not be entertained under any circumstances during the contract period.

ttt. The selected bidder shall execute the whole work in strict accordance with

guidelines of The Department of Agriculture and Farmers Welfare,
Puducherry.

tv. The Department of Agriculture and Farmers Welfare, puducherry shall
reserve the right to make any alterations in or additions to the original scope
of work on mutually agreed terms. Any additional work which the bidder may
be directed to do in the manner specified above as part of the work shall be
carried out by the bidder on the same conditions in alt respects on which he
agreed to do the main work and at the same rates as specified by The
Department of Agriculture and Farmers Welfare, puducherry.

v. Any publicity by the bidder in which the name of The Department of
Agriculture and Farmers Welfare, Puducherry is to be used shall be done only
with the explicit written permission of The Department of Agriculture and
Farm ers Welfare, Puducherry.

vt. The bidder shall submit a self-declaration as seen in Annexure-7.
vtt. The general procedures for submission of online bids in the designated e-

tender portal are provided in Annexure-12 for reference.
@@@@@

Requestfor Proposal for Projects under Digital Agriculture of the Ministry of Agricutture and Formerswelfore,
New Delhi for the Depaftment of Agriculture dnd Fdrmers Welfore, puducherry

['agc 59 191

<!-- page 60 -->

ANNEXURES
ANNEXURE-r: PRE-PROPOSALS qUERIES FORMAT

iTo be filled by the bidder]
Name of the Selected bidder:
Name of Person(s) Representing the Company/ Selected bidden
Name of
Person

Designation

Email-lD(s)

Address for

Contact
Number

Correspondence

Query / Clarification Sought:
Sr. No.

RFP

RFP Clause

Page

No.

Clause Details

Query/ Suggestion/
Clarif ication

No.

Note: - Queries must be submitted in the prescribed formot only (.XLSI .XLSX).
Queries not submitted in the prescribed format will not be considered/
responded at all by the Department of Agriculture and Farmers Welfare,
Puducherry.
Pre-Proposal queries shall be sent at the e-mail address mentioned in the RFP,
and z4 hours before Pre-bid meeting. Queries submitted post that may not be

entertained.

Request for Proposol for Projects under Digitol Agriculture of the Ministry of Agriculture ond FarmersWelfare,

New Delhi for the Department of Agriculture and Farmers Welfare, puducherry

l);rgr'60 191

<!-- page 61 -->

ANNEXURE-2: COVERING LETTER

{fo be submitted in the letter head of the bidder}
To,

The DIRECTOR, DEPARTMENT OF ACRICULTURE AND FARMERS WELFARE,
PUDUCHERRY

Puducherry
Dear Sir,

We, the undersigned, offer Proposal for Pilot Projects on the Development of Web

and Mobile Applications based on Emerging Technologies - Al, loT and ML for the
Department of Agriculture and Farmers Welfare, Puducherry in accordance with
your RFP No.7oo (ll)/Tech ll/Dte/zoz5-26lRe-Tender, dt.r4lotlzoz6. We are hereby
submitting our proposal as per the requirements mentioned in the RFP.
We hereby declare that:

l. All the information and statements made in this proposal are true and we
accept that any misinterpretation or misrepresentation contained in this
proposal may lead to our disqualification by the Client.
ii. We meet the eligibility requirements as stated in this RFP and we confirm our
understanding of our obligation to abide by the policy in regard to corrupt
and fraudulent practices.
iii. Our proposal is binding upon us and subject to

any modifications/

amendments The Department of Agriculture and Farmers Welfare,
Puducherry made before the date of submission.
iv. Our Selected bidder does not face any sanction or any pending disciplinary

action from any authority against our Selected bidder.

v. We understand that the Client is not bound to accept any proposal that the
Client receives.
Thanking you,

Authorized Signature {tn full and initials with Seal}:
Name and Title of Signatory:
Name of Bidder
(Selected bidder/ Company's name):
ln the capacity of:
Address:
Contact information (phone and e-mail):
Date& Time:
Place:
of the Ministry of Agriculture ond FarmersWelfare,
New Delhi f or the Depdrtment of Agriculture dnd Formers Welfore, Puducherry

Request for Proposol for Proiects under Digital Agriculture

['age 61 191

<!-- page 62 -->

ANNEXURE-3: PRE-QUALIFICATION BID (FORM r- 6)

Form t: Checklist for Eligibility / Qualification Criteria Compliance
Form z: Project Details
Form 3: Selected bidder/ Company information
Form 4: Contact Details of officials for correspondence during proposal process
Form 5: Certificate for Average Annual Turnover
Form 6: Declaration for Non-Debarment & non-blacklisting

Requestfor Proposolfor Proiects under DiEital Agriculture of the Ministry of Agriculture ond FarmersWelfore,
New Delhi f or the Department of Agriculture ond Formers Welfare, Puducherry

i'agt'62197

<!-- page 63 -->

Formt: Checklist for Eligibility / Qualification Criteria Compliance (in the letter head
of the bidder
sl.
No.

Documents to be
attached

Qualif ication Criteria

Compliance
(Yes/No)

Reference
Page No &

Remarks

(lf Any)

1

The Bidder shall be registered in
lndia under Companies Act 1956 Copy of certificate of
lncorporation issued
should have registered office ln
by
Registrar of
lndia and in existence for at least
five yeqls as on 3rlo3/zoz5.

2

Companies

CA certificate and an
The Bidder should have achieved audited Profit and
average annual turnover of at Loss Statement for
least lNR. 45.0o Crores (fifty the last three financial
crores) from lT/lTeS business in years (i.e. 2o2o-21,
last five financial years (i.e. zozo- 2021-22, 2022-23, 202321, 2021-22, 2022-23, ZOZ3-24 and

24 and z.oz4-25). A

2024-25).

certificate from CA/
statutory auditor.

The Bidder must have minimum

3

4

5

6

experience of five years (i.e. zozo21, 2O2l-22, 2022-23, ZOZ3-24 and
zoz4-25) in lT Projects related to
Agriculture or allied subjects such
as Horticulture, Animal Husbandry,
and Forestry from the bid
submission date in lndia with
either State or Central
Government.

Work order(s) and
completion
certificate(s) from the
client showcasing the
years of work
experience.

The Bidder should have positive A certificate from CA/
net worth as on 31" March zoz5.
statutory auditor.
The Bidder shall not be under a
declaration of ineligibility / ban /
blacklisting by any State or Central
Government i any other
6overnment institutions in lndia
for any reason as on last date of
submission of the Bid.
The bidder shall have experience
in successful execution of one or
more projects that covered the
scope of Development of Web and
Mobile Application in agriculture,
Technology based Crop Mapping,
Crop Acreage Estimation, digital

A

self-declaration
from a government
notarized affidavit in a

stamp paper of
denomination of
Rs.ro/-.

Number of projects
completed with the
value of the projects.
Work Order(s) and
corresponding
Completion
Certificate(s) from the

Requestfor Proposal for Projects under Digital Agriculture of the Ministry of Agriculture ond FormersWelfare,
New Delhi f or the Deportment of Agriculture and Formers Welf are, puducherry

l'.;qt 63191

<!-- page 64 -->

crop survey, digital mapping of
land records and its application for
scheme management etc. or any

clients

similar agriculture related project

with emerging technologies like
Al/M

L for central, state

government or any Covernment
enterprise in lndia during past five

years from the date of bid
submission. (i.e. zo2o-21, 2021-22,
2022-23, zo23-24 and zoz4-25).The

project value shall be at Ieast
Rs.z.5o Crores.

The Bidder shall preferably have
his/her working project team in
7

Union Territory of Puducherry Letter of Undertaking
with a team of qualified technical in Companies Letter
personnel (or) Bidder has to give Head with Seal &
undertaking to setup a project Signature
team in Puducherry within one
month of award of work.

SIC NATU RE -Authorized Signatory

Date:
Full name and designation:

Contact details with address:
(Seal of organization)

Request for Proposol for Projects under Di4itol Agriculture of the Ministry of Agriculture ond FarmersWelfare,

New Delhi for the Deportment of Agriculture ond Formers Welfore, Puducherry

I' ,r ;1 i: 64 191

<!-- page 65 -->

Form z: Project Details (in the letter head of the bidder)

Form z.t: Project Summary
S.No

!tem
Number of Client
projects enclosed

Details
1

or 2 or 3 clients

1

Name of the Client r

Contract Value (ln Lakhs)

2

Name of the Client z

Contract Value (ln Lakhs

3

Name of the Client 3

Contract Value (tn Lakhs)

Form 2.2: Proiect Details (To be filled for each project)
Item

s.
No

Details

Name of Bidder ent
2 Name of the Client
3 Name of the Pro ct
4 Contract Value (tn Lakhs) (ensure relevant proof has been
enclosed
Mention
the document enclosed as proof of client
5
engagement
i. Master Service Agreement/ Work Order which also
necessarily reflects the project value
ii. Com etion certificate issued the Client
6 Reference
number in the bid
osal
7 No. of cumul ative orders enclosed as a proof for the project
value
8 Na me Titl e & Ad d ress of the CI te nt ho CA n b e co ntacted
9 Whether client irs CMMi Certified? tf so indicate the level
1

10

Com pletion date(month/year)

11

Narrative description of the project

12

Details of work that defines the scope relevant to the
irement

SIC NATUR E -Authorized Signatory

Date:
Full name and designation:

Contact details with address:
(Seal of organization)

Requestfor Proposal for Proiects under Digital Agriculture of the Ministry of Agriculture
ond Farmerswelfore,
New Derhi for the Deportment of Agricurture and Formers wellore, puducherry

l'.r 11 , 65 191

<!-- page 66 -->

Form 3 : Selected bidder/ Company information (in the letter head of the bidder)

Following are the particulars of our organization:
S. No.

Description

1

Name of the bidder

3

Regional official address
(in Puducherry, if any)
Phone No. and Fax No.

4

Registered Headquarters Address

5

Phone No. and Fax No.

6

Web Site Address

7

Details of Selected bidder's Registration
(Please enclose copy of the registration

2

8

document)
Name of Registration Authority

10

Registration Number and Year of
Registration
EPFiESI registration Number

11

Goods and Service Tax Registration No.

12

Permanent Account Number (PAN)

9

Details
(To be filled by the bidder)

Note: Separate sheets and additional details may be attached wherever necessary

Sl CNATU RE -Authorized Signatory

Date:
Full name and designation:

Contact details with address:
(Seal of organization)

Request for Proposol for Projects under Digitol Agriculture of the Ministry of Agriculture ond FormersWelfore,
New Delhi for the Department of Agriculture ond FormersWelfore, Puducherry

Page 66|197

<!-- page 67 -->

Form 4: contact Details of officials for correspondence during proposal
process: (in the letter head of the bidder)
,

Details

Authorized Signatory

Secondary Contact

Name

Title
Company Address
Phone

Mobile
E-mail

SIGNATU RE -Authorized Signatory

Date:
Full name and designation:

Contact details with address:
(Seal of organization)

Requestfor Proposol for Projects under Digitol Agriculture of the Ministry of Agriculture ond FormersWelfare,
New Delhi for the Deportment of Agriculture and Formers Welfare, puducherry

Pagc 67197

<!-- page 68 -->

Form 5: Certificate for Average Annual Turnover

(ln the letter head of the bidders statutory Auditor)

We (Name of the auditing firm) hereby certify that the total

average

annual

turnover

of
(name

M/s

of the bidder) during the last Five audited financial years is as given below:

Average
Annual

Annualturnover in INR
FY 2o2o-21

FY zo21-22

FY 2o22-2l.

FY 2023-24

FY zoz4-z'

Turnover

(Signature of Statutory Auditor)
Name of Statutory Auditor:
Name of Statutory Auditor Firm:

Contact Details (Number and e-mail lD):
(Seal of organization)

of the Ministry of Agriculture ond FarmersWelfore,
New Delhi for the Deportment of Agriculture and F ormers Welfore, Puducherry

Request for Proposol tor Proiects under Digitol Agriculture

Pagc 68191

<!-- page 69 -->

Form 6: Declaration for Non-Debarment & non-btacklisting
(in the letter head of the bidder)

We hereby certify that we, M/s

(name

of

the

bidder),

having

registered office

at

(address of the
registered office) have not been debarred or blacklisted by the Central Government,
any state covernment, a statutory authority or a public sector undertaking.

The certificate below is to be provided by the Bidder.

Yours Sincerely,
S lG NATU RE

-Authorized Signatory

Date:
Full name and designation:

Contact details with address:
(Seal of organization)

Request for Proposal for Proiects under Digitol Agriculture of the Ministry of Agriculture ond FarmersWelfore,

New Delhi for the Deportment of Agriculture and Farmers welfare, puducherry

I ,'

69191

<!-- page 70 -->

ANNEXURE-4: TECHNICAL BID

Form 7: Checklist for Technical Evaluation Criteria Compliance (in the letter head
of the bidder)
Note - Bidders should enclosed require number of projects / credentials for marking
S

SI

No

1

Evaluation Criteria

The Bidder should have achieved average
annual turnover of at least lNR. 45.00
Crores from lT/lTeS business in last five
financial years (i.e. 2o2o-21, zo2't-22, 2o2z23, 2023-24 and zoz4-25).
Turnover: (t) Between Rs 45 to 55 Crores
(z) Between Rs 55 to 75 Crores
(3) More than Rs 75 Crores

Documents to be

attached

Details
/ Name

Comp
liance

of the

(Yes /

Project

No)

Reference
Page No&
Remarks
(if any)

CA certificate and
an audited Profit

and

Loss

Statement for the
last five financial
years (i.e. 2ozo-21,

2021-22, 2022-23,
2023-24 and zoz425). A certificate

from CA

I

statutory auditor.

2

The bidder should have similar experience
in Development of Web as well as Mobile
Application use of emerging technologies
like AUML in Agriculture Domain with
value of z Crores f or either State
Government / Central Government / Any
Government Agencies in lndia in last five
financial years (i.e. 2o2o-21, 2c21-22, 202223, zo23-24 and zoz4-25).
One Project:
Two Projects:
Three Projects:
Four Projects;
Five or more Projects:

Copy of

completion
certificates
and Work orders /

Contract
Agreement from

the client.

Copy of

the

certificate(s)

)

Quality / Security Certification:
o ISO 9oo1:2o15 & ISO 27oo1:2o1j

o CMMilevel3certification
o CERT-lN certified Project

signed

and

stamped by the
authorized

signatory of the
bidder.

Request for Proposal for Projects under Digital A+riculture of the Ministry of Agriculture and FormersWelfare,
New Delhi for the Deportment of Agriculture and Formerswelfore, Puducherry

Page 70197

<!-- page 71 -->

4

Bidder should have an experience of
successful execution of at least one large
scale project that covers the scope of
Development of Web and Mobile
Application, Technology based Crop Copy of Co-Live/
Mapping, Crop Survey, Crop Acreage Completion
Estimation etc. and use of emerging certificates and
technologies like Al/ML for central, state Work orders
I

government or any government
enterprise in lndia in last five financial

Contract

years (i.e. 2o2o-21, 2021-22, 2022-23, 2023- Agreement from
the client.
z4 and zoz4-25)
For Single project worth > INR 20 Crores:
For Single proiect worth > INR 4o Crores:
For Single project worth > INR 60 Crores:

Proof of Concept (PoC): Demonstration
based on the Web applications and Mobile

applications developed through Emerging
technologies like Al, ML, toT etc. for
Agriculture domain in last five financial
years (i.e. 2o2o-21, zo21-22, 2o22-2j, zo2)z4 and zoz4-25).

applications and Mobile applications
with Al, ML, loT
Or
5

For Successful demonstration of Web
applications and Mobile applications
with other emerging technologies like
Block Chain, Data Analytics etc.,
without Al, ML, loT

Live Product
Demonstration
(Only online and
not from local
servers)

any l.g in execution of both
applications with emerging
technologies

(The Web and Mobile applications

developed without Emerging
Technologies and other than for
Agriculture project shall not be
conside
Technical Presentation:

6

o Project Understanding of Objectives
o Approach and Methodology
o Project Plan and Timeline
o Personnel Deployment PIan (Based on

Technical

Presentation

Resume of Key Personnel)
Request for Proposol for Projects under Digital Agriculture of the Ministry of Agriculture and Formers Welfore,

New Delhi for the Deportment of Agriculture ond Farmers Welfore, puducherry

71191

<!-- page 72 -->

o

Use Case lmplementation

S I 6NATU R E

-Authorized Signatory

Date:
Full name and designation:

Contact details with address:
(Seal of organization)

Request for Proposol for Proiects under Digitol Agriculture of the Ministry of Agriculture and FormersWelfare,

New Deihi for the Deportment of Agticulture ond Formers Welfare, Puducherty

['rr g t: 72.,91

<!-- page 73 -->

Form 8: Technical proposal Details (in the letter head of the bidder)

1. Understanding of the Requirement (Not More than z page)
2. Approach and Methodology (Not^4ole tharr3page)

3. Proiect plan with Timeline (NotJdoreihan z roage)
4. Emerging Technology Al, loT and ML - sourcing sotution (Not more than z pages)
5. use case Implementation (Relevant content should not exceed z pages)
6. Risks and Mitigation Measures (Not more than r page)
7

' Bidders experience format-Please attach required documentary evidence as
mentioned in the RFP for each of the assignment i.e. work order AND,

tndisating

Lhe vilue of assignmenlCompletion certlficates lrom the cllent/certificate

of

CompJetion (eertified_by the Statutory Audltor) / pJrase eompletion
eertificate f
ln addition, please provide details as per format below

Format for providing proiects details (Use same format separately for
each project
cited) Form 8.r: Project Summary
S.No

Item
Number of Client
projects enclosed

Details
1

or 2 or 3 clients

1

Name of the CIient r

Contract Value (tn Lakhs)

2

Name of the Client z

Contract Value (tn Lakhs)

3

Name of the Client 3

Contract Value (tn Lakhs)

Form 8.2: Pro ect Details o be filled for each
S.No Item
1
Name of Bidder entity

Details

2

Name of the Client

)

Name of the Project

4

Contract Value (tn Lakhs) ( ensure relevant proof has been enclosed)

5

Mention the document encl osed as proof of client engagement

i. Master Service Agreement/ Work Order/ pO
ii. Copy of Receipt of payment
iii. Client Satisfaction Certificate
6

Refere nce page number in the bid proposal

7

No. of cumulative ord ers enclosed as a proof for the project value

8

Name, Title & Address of the Client who can be contacted
Request for Proposal for Proiects under Dilital Agriculture

of the Ministry of Agriculture and Formersweltare,
New Delhi for the Department of Agricurture and Farmers wetfare, puducherry

l' r'r, 73191

<!-- page 74 -->

9

Whether client is CMMi Certified? lf so indicate the level

10

Com pletion date(m onth/year)

11

Narrative description of the project

12

Details of work that defines the scope relevant to the requirement

-lechniesl

ln oddition to the technical bid documents, bidder will need to prepue s
Presentotion coverlng all aspects. The foeas of the ptesentation should be to
showcase understqnding of the requirements, apprgach gnd methodolp{y proposcd,
technical evoluotion criten-e, The techtical presentation is rrot to be sabmitted along
with tlre technical bLd, bidier's will be notified sepototely for technicalptesentotion-

SIC NATU R E -Authorized Signatory

Date:
Full name and designation:

Contact details with address:
(Seal of organization)

Request for Proposal for Projects under Digitol Agriculture of the Ministry of Agriculture and Formerswelfare,

New Delhi f or the Deportment of Agriculture ond FormersWelfore, Puducherry

Pagt.'74191

<!-- page 75 -->

ANNEXURE-5: Fl NANCTAL Bt D TEM PLATE

Form 9. Financial Proposal (to be filled online oNLy in the portal
https://pudutenders.gov.in/) This is only a template for understanding the Boe
prescribed in the financial bid.
Tender lnviting Auth ority : The Department of

ture and Farmers Welfare, Puducherry
Pilot Projects on the Devetopment of Web Applications and
Mobile App with emerging technologies - Al, loT and ML for |AAS
a n d RI MS fo r the D e pa rtment of Agri culture a nd F a rm e rS
e lfa T€,

Name of Work

Pud U che

7oo (tt)lTech tU Dte/zoz5-26/Re-Tender dated t 4 I ot I zoz6

RFP No

Name of the Bidder/ Bidding
Firm / Com pany
PRICE SCH EDULE

(This BoQ template must not be modified/replaced by the bidder and

the same should be uploaded
after filling the relevant columns, else the bidder is liable to be rejected for this tender.
Bidders are
allowed to enter the Bidder Name and Values on

NUMBER

NUMBER
#

TEXT #

#

TEXT

#

NUMBER
#

NUMBER

NUMBER
#

NUMBER
#

TOTAL

TOTAL

AMOUNT

AMOUN

Without

T With

Taxes

Taxes

7

8

TEXT #

BASIC
RATE ln

sl.
No.

Item Description

Quantity

Units

Figures To
be

entered
by the

CST

Amount

Rs.

P

Bidder
1
1

)
Pilot Projects on the

TOTAL

AMOU
NT

ln

Words

Rs. P
3
1.OOO

4

5

6

Job

Development of Web

o.ooo

o.ooo

9
INR

Zero
Only

applications &
Mobile applications

with

emerging
technologies - Al, loT

and ML etc. for
lntelligent
Agriculture Advisory

System and Real

Time

lrrigation
Management system

under the Digital

Agriculture Project

of NeCP-A of the
Ministry
of
Agriculture and
Farmers Welfare
New Delhi for the

Request for Proposal for Proiects under Digitat Agriculture of the Ministry of Agriculture

ond Formerswelfore,
New Delhi for the Depdrtment of Agricurture ond Farmerswerfore, puducherry

,

'r 75191

<!-- page 76 -->

Department of
Agriculture and
Farmers Welfare
Puducherry.

Total in

o.ooo

o.ooo

Zero
Only

l- rgu res

Quoted

INR

INR Zero Only

Rate in

Words

The CST has been fixed at r8% in the BoQ and the bidders are intimated that it is
subject to the prevailing rates at the time of submission of tenders and further
subject to revision as and when notified by the Government.

Request for Proposal for Proiects under Digital A4riculture of the Ministry of AEriculture and FarmersWelfare,
New Delhi for the Deportment of Agriculture ond Formers Welfore, Puducherry

{'agt:76191

<!-- page 77 -->

ANNEXURE-6: CODE OF INTEGRITY

No official of a procuring entity or a bidder shall act in contravention of the
codes which includes:

l.

Prohibition of any or all;

a. Making offer, solicitation or acceptance of bribe, reward or gift or any
material benefit, either directly or indirectly, in exchange for an unfair
advantage in the RFP process orto otherwise influence the RFP process.

b. Any omission, or mis-representation that may mislead or attempt to
mislead so that financial or other benefit may be obtained or an
obligation avoided.

c. Any collusion, bid rigging or anti-competitive behavior that may impair
the transparency, fairness and the progress ofthe RFp process.

d. lmproper use of information provided by The Department of Agriculture
and Farmers Welfare, Puducherry to the bidder with intent to gain unfair
advantage in the RFP process or for personal gain.

e. Any financial or business transactions between the bidder and any
official of The Department of Agriculture and Farmers Welfare,
Puducherry related to tender or execution process of contract; which
can affect the decision of The Department of Agriculture and Farmers
Welfare, Puducherry directly or indirectly.

f. Any coercion or any threat to impair or harm, directly or indirectly, any
party or its property to influence the RFp process.

g. Obstruction of any investigation or auditing of a RFp process.
h. Making false declaration or providing false information for participation
in a tender process or to secure a contract.

ll.
lll.

Disclosure of conflict of interest.

Disclosure by the bidder of any previous transgressions made in respect
of the provisions of sub-clause (t) with any entity in any country during

the last three years.

ln case of any reported violations, the Department of Agriculture and Farmers
Welfare, Puducherry, after giving a reasonable ground for being heard, comes to the

conclusion that a bidder or prospective bidder, as the case may be, has
contravened the code of integrity, ffiBy take appropriate measures.

Request for Proposal for Projects under Digital Agriculture of the Ministry of Agriculture and Farmers welfore,

New Delhi for the Deportment of Agriculture and Formers Welfore, puducherry

l',:l , 77 191

<!-- page 78 -->

ANNEXURE-7: SELF-DECLARATION

{fo be submitted in the letter head of the bidder}
To,

Date:

The Director,

Department of Agriculture and Farmers Welfare, Puducherry
Puducherry

ln response to the RFP Ref. No.7oo(ll)/Tech lUDte/zoz5-26lRe-Tender,
dt.t4/ot/zoz.6 for the Pilot Projects on the Development of Web and Mobile
Applications with Emerging Technologies - Al, loT and ML for the Department of
Agriculture and Farmers Welfare, Puducherry through The Department of
Agriculture and Farmers Welfare, Puducherry, as an Owner/ Partner/ Director/
Auth. Sign. Of (name of the firm), l/ We (name of the signing authority) hereby
declare that presently our Company/ selected bidder, at the time of bidding:
(a) Possess the necessary professional, technical, financial and managerial
resources and competence required by the Bidding Document issued by the
Department of Agriculture and Farmers Welfare, Puducherry;
(b) Have fulfilled my/ our obligation to pay such of the taxes payable to the Union
and the State Covernment or any local authority as specified in the Bidding
Document;
(c) is having unblemished record and is not declared ineligible for corrupt &
fraudulent practices either indefinitely or for a particular period of time by any
State/ Central government/ PSU/ UT.
(d) Does not have any previous transgressions with any entity in lndia or any other
country during the last three years
(e) Does not have any debarment or blacklisting by any other govt.
departm ent/organization/ society.

(f) is not insolvent in receivership, bankrupt or being wound up, not have its affairs
administered by a court or a judicial officer, not have its business activities
suspended and is not the subiect of legal proceedings for any of the foregoing
reasons;

(g) does not have, and our directors and officers not have been convicted of any
criminal offence related to their professional conduct or the making of false
statements or misrepresentations as to their qualifications to enter into a
procurement contract within a period of three years preceding the
commencement of the Tender Process, or not have been otherwise disqualified
pursuant to debarment proceedings;
(h) Does not have a conflict of interest as mentioned in the bidding document
which materially affects the fair competition.
Request for Proposol for Projects under Digital Agriculture of the Ministry of Agriculture ond FormersWelfare,

New Delhi f or the Deportment of Agriculture ond Farmers Welfore, Puducherry

Prrgt:78197

<!-- page 79 -->

(i) Will comply with the code of integrity as specified in the bidding document.
lf this declaration is found to be incorrect then without prejudice to any other
action that may be taken as per the provisions of the applicable Act and Rules
thereto prescribed by CoP, my/ our security nray be forfeiture in full and our
proposal, to the extent accepteci, may be cancelled.
Thanking you,

Authorized Signature {ln full and initials with Seal}:
Name and Title of Signatory:
Name of Bidder (Selected bidder/ Company,s name):

Address:
Contact information (phone and e-mail):
Date & Time& Place:

Request for Proposal for Proiects under Digitot Agriculture of the Ministry of Agricutture ond Farmerswelfore,
New Delhi for the Department of Agriculture ond Formers Welfore, puducherry

7ele1

<!-- page 80 -->

ANNEXURE 8: PERFORMANCE BANK GUARANTEE (UPON FINAL SELECTION)
Ref Section p.tz of this RFP
<Name>
< Designation>

<Address>
<Phone Nos.>
<email id>

Whereas, <<name of the Bidder and address>>(hereinafter called "the
applicant/Bidder") has undertaken, in pursuapce of contract no. <<insert contract
no.>> dated. <<insert date>> to provide services for <<name of the assignment>> to
<Puducherry eGovernance Society> (hereinafter called "the beneficiary")
And whereas it has been stipulated by in the said contract that the applicant/Bidder
shall furnish you with a bank guarantee by a recognized bank for the sum specified
therein as security for compliance with its obligations in accordance with the
contract;
And whereas we, a banking company incorporated and having its head /registered
office at <<address of the registered office>> and having one of its office at
<<address of the local office>>have agreed to give the supplier such a bank
guarantee.
Now, therefore, we hereby affirm that we are guarantors and responsible to you,
on behalf of the supplier, up to a total of Rs. <<lnsert Value>>(Rupees <<insert
value in words>> only) and we undertake to pay you, upon your first written
demand declaring the supplier to be in default under the contract and without cavil
or argument, any sum or sums within the limits of Rs. <<lnsert Value>>(Rupees
<<insert value in words>> only) as aforesaid, without your needing to prove or to
show grounds or reasons for your demand or the sum specified therein.

We hereby waive the necessity of your demanding the said debt from the
applicant/Bidder before presenting us with the demand.
We further agree that no change or addition to or other modification of the terms
of the contract to be performed there under or of any of the contract documents
which may be made between you and the applicant/Bidder shall in any way release
us from any liability under this guarantee and we hereby waive notice of any such

change, addition or modification.
This Cuarantee shall be valid until <<lnsert Date>>.
Request for Proposol for Projects under Digitol Agriculture of the Ministry of Agriculture ond FormersWelfare,

New Delhi for the Deportment of Agriculture and Formers Welfare, Puducherry

[',rqc B0 l91
