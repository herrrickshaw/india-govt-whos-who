---
doc_id: "4a31ac6bd0cb5da0"
source_url: "https://schooledn.py.gov.in/notification/2018/RP-TEST-CAMP.pdf"
ministry: "District Institute of Education and Training (DIET), Puducherry"
title: "Bharat Scouts and Guides, Puducherry - 'Rajya Puraskar Testing Camp' at State Headquarters, Lawspet, Puducherry 22.12.2018 to 26.12.2018 - Intimation - Reg"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a469b0f525d4f921"
---

<!-- page 1 -->

-_._Sry qg9uJS^S gulpFg pupucHERRy

(STATEHEADQUARTERS,AHNRATSCOENFGUIOCS,MWSFETE6GCNNV)

G;5il/DG/BSG+SD/2018 _ 2O1e

____________.______:____-,_::r. :_-*__:_*::_:.

a.iii'[ole

sub:- school Education - ,n"."r.a*_Horides, puducherry
puraskar
Testing Camp" at State Headquarters, Lawspet, FuOuc -,,Rajya
herry 22.12.201g to
26.12.2018 - Intimation _

*"n

-"o"-

The "Raiva puraskar
_Testing camp" wi' be herd at state Headquarters, Lawspet,
Puducherry for 5 days from zz.lz.zo8
b id.riloia, iir" o"taits of the event are given betow:
1 . Name of the
: "Rajya puraskar Testing Camp,,
2.
, zzjz.zoiaio')a.i;)i)i;""

Date event

i Xirl"Xi
! ?:.ry*yo
6.
Eligibility

: state Headquarters, Lawspet, puducherry.

22.12.2018 at g.OO am.

:26.12.201a;ft;;;;:
:

,|

2. Should have attended pLT
3. First Aid & Ambulance Man course
7.
19.12.2018 before 5 pm at SHe,
.Last date for applying
7. What
ryrc. to
ro bring
: Two sets of correct and comorete'.uniform
Ltghtbeddns,
ropc, st""""-Li dri;i;;kfi;:'rrftidress. with shoes, chapers,

ornt

'

Stliqg
Nore-hnnL
D-h D^
Note-boo!,.,:&nlilncir,
,.r:1*T^{1,".-"r;_,!',:iil"ll'JH:'8fi
i?f:g,-l:T
ano *:ss,
urner roiret
}Note-boord,
requisites
serected_scoutslouioes snouio co-m!
SiSi
ilffi;::;:l;;
wrln comprete preparation. up to rritiya
sopan
sopan _syllabus,
syllabui,-ihtwiil
Tritiya
pi"Iiil];#:;Jiilfi
They wi1 hr""
6ru" pracricer
racr anrr .^,,;:'tl^t^olqlete
(Law, promise, sig'n,
satute, M;tto;
Salute,
Motto, Handshake,
iil.tirk;:'pr"u",
Hrn aa^^
^,^_,ll^191:"parately
U;;i#;'3.o;t E"ss, xit
rnspection, Fras ceremonv. ilffj 3:#
"on.,v'Yr r' rclr ur I:l:::,3$#,
Dvslem' E P's

jr"lli;i5;ffi

"*t
$ffi'J:t"'1:,?i!,illll;"1'd,iilinl:g['":;'ii

six, Hi
cooking, Complss, gstimaiio,'
"1",::,
'i1',3fl1'f$i"sr;,',flHi
Note: - Must show rorr.,, ,i,^lAYllI]T*^9?.999F' Knots. Lashings,
1. Birtfr Certitic
2. Any other state level certificate

.-

ri*iiioj

iffilj 3l,';;[

The erigibre scouts.and Guides
shourd attend the camp in correct
and comprete
cst G-;;ri'f;il"tcouts for the
scouts with scouter/GuiGiiifrEiffiJill,ililffire.the
rhe cap.
scout organiser i.s'hanmusam in
certificate
unrrorm incrudins shoes. propel.hdr

;!:t j:r1y",ff.1,8!s!

;;.i;;#ftr

qd elerd.;iliff te*ificates, at the time of

Res,stration on

The Heads ot
a.re requested to relieve the scouts/Guides
!9!o9ts
and, scout Master
and Guide Captain well in advance
ro attend the camD.
With Scout creetings

To
The scoutmaster/Guide caotarn concerned
through the Heads of Institution.
Copy to:'1. Headmasters/principals
2. The Chief Educationai fficer, Karaikal.
3. The Chi,ef Educational Officer, euOucneny
4. The Deputy Director of Education (W), puiucherry
Copy submitted to:1. The Joint Directot of Education, puducherry;
2. The Director of School Education, euductrJrry _
tor favour of information.
.

<!-- page 2 -->

D GUI

r"tot
Ap p Lf cAn o N F o R RAJ AyAp u RAs KAR f E sir N G

PUDUCHERRY)

ftE: lil)' zo.n
=,

1.

Name of scouVGuide
(ln capital letters)

2. Aadhaar No
(Photo copy should be enclosed) :

Father Name
4. Mother Name

Date of Birth
(Photo copy of Birth Certificate
Should be enclosed)
6. Class

Home Address

pin code
Telephone

8. Date of Joining in the Movement

:

9. Class of Joining in the Movement

:

1 0.

No

-

Date of investiture

11. Date of Completion

of

: 1. pravesh

:

2. Pratham Sopan:
12. camps Attended Ail the camp

"nJ"3',3l'ffi,3",53?n"r.
1.

be enctosed

2.

J.

Signature of ScouVGuide
CERTIFICATE

_.
Ilri: is to certify that the above said scout /Guide is passed up to Tritya sopan & attend
First Aid and
Ambulance man course He/she is erigibre to attend Rajyapuraskar

Testing camp

Signature of Scout Master/Guide Caotain
Counter Signature of the Headmaster/principal
