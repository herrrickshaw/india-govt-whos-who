---
doc_id: "0dcb5c8f932b2cfb"
source_url: "https://agri.py.gov.in/Tenders/TenderPDF/0001_092.pdf"
ministry: "Agriculture and Farmers Welfare Department, Puducherry"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "794550336bd65038"
---

<!-- page 1 -->

OEPART},IIF;NT OF E

12 5 JUL Zt,Zl

R
D

5o43

GOVERNMENT OF PUDUCHBRRY
OF AGRICULTURE & TARMBRS WBLFART,
OF THE ADDITIONAL DIRECTOR OF AGRICULTURD
KARAII(AL

trlo : ...........i......?,..

No. 1 88 / ADA/ KKL/ DD(AE) -CTW/ e -Te nd et I 2O2S -26 I

B*9

dtz 23.07.2025

"e-Tenders" are invited on behalf of the Presiclc.nt o[ Ilrrli:r b.y llrt'Arlrlilittrvtl l)itt't lot

ol'Agricultttre, Department of Agriculture & I?armers Wclfare, Kirrrril<;rl lrour ll:r' :;r'tvtt,'
prcrvtrlers Ior carn ing out the n'ork "Lifting and Erection of Submerslblc Motor I'urnp
set" tbr the Community Tube rvells in Karaikal region lhrough r:-lr:nrler;rlirllorrr
https:/ /ouclu
ers.gov.in. Tenders submitted in any other lorm will not be arcr:cplr:rl
TENDER SCHEDULE

sl.

ect
Dorvnload documents & Bicl submission start
Last date of Submission of Tender Online
Last date of submission of original Tender Fee
and EMD fee bv Post/Personall-y
Date and Time of opening of Tenders

I

2
3
+

Datc and tlme
23.07.2025 by 04,00 I'.M
04.oo t,,M
06.o8,2025
06.08.2025 by 04.30 I'.M
07.O8.2O25 by 10.00 A.M

(lf these da-r's happen to be a holiday the next working day will be the date for itcrn
Nos. 2 and 4)
Tenderer(s) are requested to stick on to the date and time specified strictl.y.
Tenders rvill be accepted only if submitted in the prescribed manner. Tcnderers arc
requested to read the instructions on help for contractors, information al:out Digil;rl
Signature Certificate, resources required and bidder's manual kit at the home paga of
the n,ebsite httos://nudutenders.gov.in. or http:/ /demoeoroc.nic.in/- bcfor<:
submission of tender through online.

Helpdesk @eprocutement Cell: O413-2220.225 Emall :sunoort-elrroc.pon@)nlc.ln

P

(R. GANESAN'
ditional Director of Agriculturc
Karaikal

To,z

y'WrA Board, Directorate of Agriculture, Puducherry

/ ,/ II. Notice Board of:
1. Coltectorate; 2. O/O ADA, Karaikal; 3. Karaikal Municipality; 4. Karaikal l(VK,
Thennangudy; S. Government Seed Farm, Madur; 6. Commune Panchayat- Neravy, T.[1.
pattinam, Kottucherry, Nedungadu & Thirunallar; 7. Uzhavar Udhaviyagam -'l'halatheru,

Kottucherry, Melakasakudy, Nedungadu, Thirunallar, Thennangudy, Ambagarathur'
Vizhidiyur, Nearvy & T.R. Pattinam.
