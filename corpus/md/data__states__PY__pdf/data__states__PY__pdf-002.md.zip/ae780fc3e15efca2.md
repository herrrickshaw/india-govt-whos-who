---
doc_id: "ae780fc3e15efca2"
source_url: "https://ppclgov.in/admin/dynamic/tender/vBpD.pdf"
ministry: "Puducherry Power Corporation Limited (PPCL), Puducherry"
title: "AC-088 Procurement of the Sample cooler for HRSG System   [ Notice Board ]"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3581dcd60a80e56f"
---

<!-- page 1 -->

PUDUCHERRY POWER CORPORATION LIMITD

(A GOVERNMENT OF PUDUCHERRY UNDERTAKING)
T.R. PATTINAM - 609606, KARAIKAL.
E-Mail:ppclmmc@gmail.com

Phone No: 04368- 233060, 233988

Ref. No: AC-088/ MMC/2025-26/Ia

Fax: 04368- 233355.
Dt.S.01.2026

Our GSTIN No.: 34AAACP6507E1Z

ENQUIRY
To

(Asper list enclosed)

Sub:: Inviting offer for Supply of Sample Cooler for HRSG System - Reg.
QUOTATION TO BE:
Submitted on or before: 27.01.2026- 12.00 Noon

Opened on: 28.01.2026 - 3.00 PM

Kept valid for 3 months from the date of opening

Submitted in Two parts.

Sealed quotations are invited for the Supply of Sample Cooler for HRSG System as per
the specification detailed in the annexure and as per the drawing enclosed.

PRE-QUALIFICATION REQUIREMENTS:
THE BIDDER SHOULD HAVE PREVIOUS EXPERIENCE N'SUPPLY OF SAMPLE

COOLER FOR HRSG/BOILER SYSTEM TO ANY GOVERNMENT ORGANISATION /
REPUTED PRIVATE ORGANISATION. THE SUPPORTING DOCUMENTS SHOULD BE

ENCLOSED WITH THE OFFER.
Cover 1: EMD/PQR after verification Cover 2: Price bid.

Terms & Conditions:
1. The rate quoted should be firm and inclusive of all taxes and other charges as admissible.

2. The material should be original and specified make only.
3. The materials should be directly supplied to the PPCL site, T.R.Pattinam, Karaikal - 609 606,

on door delivery basis.

4. 100% payment will be made within 30 days from the date of receipt of your invoice after
receipt of materials at site in good condition. The bill in triplicate along with advance

stamped receipt should be sent to the undersigned for effecting payment.
5. EARNEST MONEY DEPOSIT: An Earnest Money Deposit of Rs.710/- should be paid by
demand draft drawn in favour of The Executive Engineer (Mech.) Plant, Puducherry Power

Corporation Ltd TR. Pattinam, Karaikal on any Nationalized/Schedule bank payable at Karaikal.
The same should be enclosed along with tender/quotation failing which tender will be summarily
rejected. The earnest money deposit will bear no interest and will be released after successful

completion of the supply and acceptance. The EMD willbe returned to unsuccessful bidder on
receipt of a letter requesting for the same after placement of order to the successful bidder.
Page 1 of 4

<!-- page 2 -->

PUDUCHERRY POWER CORPORATION LIMITD
(AGOVERNMENT OF PUDUCHERRY UNDERTAKING)

T.R.PATTINAM - 609606,KARAIKAL.
Phone No: 04368- 233060, 233988
E-Mail:ppclmmc@gmail.com

Ref. No: AC-088/ MMC/2025-26/ TTg

Fax: 04368 - 233355.
Dt. S .01.2026

Our GSTIN No.: 34AAACP6507E1Z

ENQUIRY PAGE No.2

6. PSU &Parties registered with NSIC/SSI/ MSME are exempted for submitting EMD/SD.
However copies of supporting Documents/Certificates should be kept in separate cover super
seribing "Earnest Money Deposit Exemption".

7. The party shall be required to place the earnest money and the tender in separate sealed
envelopes marked "Earnest Money and PQR" & "Tender" respectively. Both the envelopes
shall thern be placed in another sealed envelope and submitted to the tender inviting authority

in the usual manner. The officer opening the tenders shall first open the envelope containing

the earnest money and PQR. If the earnest money and PQR is found to be in order, only then

the Officer shall proceed further with opening the tender. In case the carnest money is not

deposited or is not in order, the tender will be rejected.

8. The delivery period and mode of despatch should be clearly specified.

9. Liquidity Damage Clause: If the supplier fails to supply the materials within the delivery

period, then supplier shall pay LD @0.5% for each week delay in supply and the total LD % willbe
subject to the maximum of 5% of the quoted rate.

10.Warranty/Guarantee: Party should provide warranty /Guarantee certificate for a period of

18 months (eighteen months) from the date of receipt of the shipment or 12 month (Twelve
months from the date of installation for satisfactory operation and good workmanship.

11. The party attheir own cost should arrange transit insurance, if necessary.

12. Quotations should be super scribed as "QUOTATION/ENQUIRY NO. AC-088 Supply of
Sample Cooler for HRSG system" due on 27.01.2026, 12.00PM.

13. Applicable taxes, freight and other charges should be clearly mentioned as whether

inclusive or extra. If not mentioned, it will be presumed that the rate quoted is inclusive of all

taxes and other charges.
14. Our GSTIN No.: 34AAACP6507E1ZS is registered with Commercial Taxes Department,

Puducherry.

15. The undersigned reserves all rights to accept/reject any or all the quotations without
assigning any reasons therefore.

16. IBR Test Certificate to be submitted along with supply of the material.

17.GA Drawing approvalto be obtained before Manufacturing.

DESPATCHED
ON:

EXECUTIVEENGINEER (MECH) PLANT
Page 2 of 4

DESPATCYER

<!-- page 3 -->

PUDUCHERRY POWER CORPORATION LIMITD
(A GOVERNMENT OF PUDUCHERRY UNDERTAKING)
T.R. PATTINAM -609606, KARAIKAL.

Phone No: 04368- 233060, 233988

E-Mail:ppclmmc@gmail.com
Ref. No: AC-088/ MMC/2025-26/1T79

Fax: 04368 - 233355.

Dt.y.01.2026

Our GSTIN No.: 34AAACP6507E1Z

ENQUIRY PAGE No.3

TECHNICAL SCOPE AMD SPECIFICATION
1

A maximum cooling water temperature of 40°C shall be considered for design of

sample cooling system.
2. Capacity of cooler shall be adequate to cool the sample within5°C of cooling water

inlet temperature considering thecombined flow of each analyser connected to sample
cooler and one manual grab sample at flow rate 500 cc per minute assuming adequate
flowing factor.

3.Cooler capacity calculations shall be submitted by bidder. GA drawing should be
submitted along with offer for our approval.
4.Provision shall be made for adjusting the temp. of each sample individually at an
optimum value.

5.Sample cooler shall be of submerged helical coil type of shell and tube design with
removable shell. The sample tube shall be of seamless with no welds and other joint

inside thecooling jacket. Unions shall be provided to facilitate removal of coils.

6.All sample tubing and fittings, other components shall be constructed of type 316
stainless steel.

7.Cooler design shall conform to requirement of ASTM D1192-64 (Equipment for
sampling industrial water and steam).
8. IBR certificate is required wherever applicable.
Technical parameters required:
Cooling water
Inlet

40°Cmaximun

Shell MOC: SS 316

Cooling water inlet/ outlet
size 1 inch NPT

Inlet pressure

2.5 kg/cm2

Shell Design pressure 10
kg/cm2

Outlet pressure

Open atmosphere

Shellhydro test pressure 15
kg cm2

Quality

Less than 35 ppm

SAMPLE BOILER WATER, SUPERHEATED STEAM, SATURATED STEAM
Temperature

400 working

Pressure

50 bar
DM water

Sample coil size YA inch OD
MOC: SS316

Quality

Note: The enclosed Drawing may be considered for selecting dimension.
Page 3 of 4

<!-- page 4 -->

PUDUCHERRY POWER CORPORATION LIMITD
(A GOVERNMENT OF PUDUCHERRY UNDERTAKING)
T.R. PATTINAM - 609606, KARAIKAL.

Phone No:04368- 233060, 233988

E-Mail:ppclmmc@gmail.com

Fax: 04368 - 233355.

Dt. S.01.2026

Ref. No: AC-088/MMC/ 2025-26/119

Our

GSTIN No.: 34AAACP6507E1Z

ANNEXURE-I

Req.

SL.No

Description

1.

Sample Coolers for HRSG(Boiler) samples
as

per

the

Unit Rate

Qty.

specification

&

Drawing

Total cost in
Rs.

02 Nos.

enclosed
Sub-Total

Packing and Forwarding charges in

%only

Freight Charges in

%only

Add: GST@18%
Total

(Rupees
Terms and Condition:
SL

Terms AAccepted by

No.

Details

Terms in Enquiry
Inclusiveof alltaxes &charges

01.

Price Quoted

02.

Payment Terms

03.

Validity

90 Days from date of opening.

04.

Delivery period

Within 30 days

05.

Liquidity Damage Clause

06.

Warranty/ Guarantee
Acceptance of all our terms

06.

& conditions of our

the Party

FOR Site

As per Clause 4 of General Terms and

conditions of our enquiring

As per Clause 9 of General Terms and

conditions of our enquiring
As per Clause 10 of General Terms and
conditions of our enquiring

To be Accepted

enquiry.
Name of the Company:

Company seal with Signature:

Page 4 of 4

<!-- page 5 -->

Ø25X39 ( )

A
meLE

20

SAmPLE

(ooLEe

cooLER

FoR

765

HRSG

ø66.5 x5.5T
