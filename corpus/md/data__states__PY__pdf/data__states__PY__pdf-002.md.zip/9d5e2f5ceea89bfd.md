---
doc_id: "9d5e2f5ceea89bfd"
source_url: "http://gstchennai.gov.in/images/pdf/posting-transfer/ADC_JC_41_2025_CGST_Zone.pdf"
ministry: "Office of the Principal Chief Commissioner of GST & Central Excise Tamil Nadu & Puducherry Zone, Puducherry"
title: "Click here for Details"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f8528b00a1f48e5a"
---

<!-- page 1 -->

GCCO/II/3/16/2025-CCAESTT-O/o Pr CC-CGST-ZONE-CHENNAI-Part(1)

I/2960472/2025

GCCO/II/3/16/2025-CCAESTT-Part(1)

Date: 01.05.2025

DGHRD/ADC-JC/64/2025
OFFICE ORDER NO:41/2025
In pursuance of the Board's Office Order Nos: 69/ 2025 dated 04.04.2025 and Order
no of DGHRD/ADC-JC/63/2025 & Order No.37/ 2025 dated 28.04.2025, the following
posting and transfers in the grade of Additional / Joint Commissioner of Indirect Taxes and
Customs is hereby ordered with immediate effect and until further orders:
SL
NO

EMP.
ID

NAME
(SHRI/SMT/MS/DR)

RAN
K

FROM

TO

1

4315

HARISH K

ADC

COIMBATORE

PR. CCO & CCA

2

3595

C THIYAGARAJAN

ADC

PR. CCO & CCA

AUDIT
(CHENNAI I)

3

7026

BALAJI K

JC

4

3619

V. PANDIRAJA

ADC

5

3624

6

3836

7

4542

8

4630

9

3900

10

7104

SARANYA C

JC

11

4049

T. NALINA SOFIA
(ON STUDY
LEAVE)

ADC

T SAMAYA
MURALI
D RANJITH
KUMAR
MURALI RAO R J
RAMESH
BHARATHI K S
PATTAN IMTIYAZ
KHAN

ADC
ADC
JC
JC
ADC

CHENNAI
NORTH
(ADDITIONAL
CHARGE OF PR
CCO)
CHENNAI
NORTH
CHENNAI
SOUTH
CHENNAI
OUTER
CHENNAI
OUTER
CHENNAI
OUTER
APPEAL
(CHENNAI II)
AUDIT
(CHENNAI I)
PUDUCHERRY

APPEAL
(CHENNAI II)
CHENNAI SOUTH
AUDIT
(CHENNAI II)
TRICHY
COIMBATORE
SALEM
CHENNAI OUTER
CHENNAI OUTER
MADURAI

Page 1 of 3

<!-- page 2 -->

GCCO/II/3/16/2025-CCAESTT-O/o Pr CC-CGST-ZONE-CHENNAI-Part(1)

I/2960472/2025

12
13

3553
3766

RASHMI MISHRA
P.RAM MOHAN

ADC
ADC

SALEM
ON JOINING

CHENNAI NORTH
PUDUCHERRY

14

3847

R.SRI BALAJI

ADC

ON JOINING

COIMBATORE

15

4140

SHIVAPRAKASH
VEERESH BADDI

ADC

ON JOINING

CHENNAI OUTER

16

4284

B LOKNATHA
REDDY

ADC

ON JOINING

CHENNAI NORTH

17

4368

ADC

ON JOINING

TRICHY

18

8188

JC

ON JOINING

COIMBATORE

19

8274

JC

ON JOINING

SALEM

20

8276

JC

ON JOINING

APPEAL
(CHENNAI I)

A DHILEEBAN
VENUGOPALAN
RADHIKA
JAISON PRAVEEN
KUMAR
JAYAPAL
JAYACHANDRAN

2.
The Postings of officers within the Commissionerates shall be given by the
respective Pr. Commissioners/Commissioners with the prior approval of Principal Chief
Commissioner.
3.
The officers mentioned above shall be relieved latest by 09.05.2025 and must join at
their new place of posting latest by 12.05.2025. Officers posted from other zones in terms of
Board’s Office Order No. 69 / 2025 dated 04.04.2025 and who have already joined in Pr.
Chief Commissioner’s office stand relieved with this order; those who are yet to join in this
zone may join the respective Commissionerates directly.
4.
The outgoing officer shall prepare a brief about the time bound/urgent/sensitive issues
in their jurisdiction for the incoming officer to maintain continuity and follow up of
urgent/time bound issues.
5. The compliance report regarding the relieving and joining of the above officers may be
sent by 13.05.2025.
6. All the representations received till date regarding the posting and transfer in the grade of
Additional / Joint Commissioners of Indirect Taxes and Customs, stand disposed of. No
representation whatsoever shall be entertained before joining the new place of posting.
7.

This is issued with the approval of the Pr. Chief Commissioner.

(C Thiyagarajan)
Additional Commissioner

Page 2 of 3

<!-- page 3 -->

GCCO/II/3/16/2025-CCAESTT-O/o Pr CC-CGST-ZONE-CHENNAI-Part(1)

I/2960472/2025

To
The Officers concerned
Copy to:
1.
2.
3.
4.
5.

The Member (Admin), CBIC, New Delhi.
The Member (I/C of South), CBIC, New Delhi.
The Chief Commissioner of Customs, Chennai Zone.
The Chief Commissioner of Customs (Preventive) Zone, Tiruchirappalli.
The (Pr.) ADG, DG Systems, Chennai / DGGI Coimbatore / DG Audit Chennai / DGRI
Chennai / NACIN Palasamudram.
6. The (Pr.) Commissioner of GST & Central Excise, Chennai North / South / Outer /
Puducherry / Coimbatore / Madurai / Salem / Tiruchirappalli / Chennai Audit-I / AuditII / Chennai Appeals-I / Appeals-II / Coimbatore Audit / Appeals.
7. The Chief Accounts Officer (i/c of Pr.CCO), Chennai North.
8. The Sr. PS to the Pr.Chief Commissioner of GST & Central Excise, Tamil Nadu and
Puducherry Zone.
9. The Superintendent, Pr.CCO – for uploading in the Zonal Website.
10. The Hindi Cell, Pr.CCO – for translation.
11. Master Copy

Page 3 of 3
