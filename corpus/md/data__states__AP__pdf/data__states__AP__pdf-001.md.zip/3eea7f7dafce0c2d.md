---
doc_id: "3eea7f7dafce0c2d"
source_url: "https://anucde.info/AdmissionNotificationAY2627Rev.pdf"
ministry: "Acharya Nagarjuna University, Centre for Distance Education, Andhra Pradesh"
title: "Admission Notification for Academic Year 2026-27"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b9a699f18f37cea6"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

ACHARYA NAGARJUNA UNIVERSITY
CENTRE FOR DISTANCE EDUCATION
Recognized by UGC-Distance Education Bureau(DEB), New Delhi
Dual Mode NAAC “A+” Grade with 3.46 Score
PROGRAMMES OFFERED IN ANUCDE (SEMESTER MODE) FOR THE ACADEMIC YEAR 2026-27 BATCH
PG-SCIENCE PROGRAMMES (08)
M.Sc. BOTANY
M.Sc. ZOOLOGY
M.Sc. PHYSICS
M.Sc. CHEMISTRY
M.Sc. MATHEMATICS
M.Sc. STATISTICS
M.Sc. COMPUTER SCIENCE
M.C.A
PG-COMMERCE & MANAGEMENT PROGRAMMES (07)
M.COM - ACCOUNTANCY
M.COM – BANKING
M.B.A GENERAL (Two Specializations)
M.B.A (INTERNATIONAL BUSINESS)
M.B.A (TRAVEL & TOURISM MANAGEMENT)
M.B.A (HOSPITAL ADMINISTRATION)
M.B.A (HUMAN RESOURCE MANAGEMENT)
Last date for payment of
admission fee: 10-09-2026
FOR ADMISSION VISIT OUR WEBSITE

www.anucde.info
For any Information Contact our
email Id: anucdedirector@gmail.com
For General Enquiry Call on:
0863-2346222 / 2346208 / 2346214

PG-ARTS PROGRAMMES (11)
M.A. ENGLISH
M.A. TELUGU
M.A. HINDI
M.A. SANSKRIT
M.A. ECONOMICS
M.A. HISTORY
M.A. POLITICAL SCIENCE
M.A. SOCIOLOGY
M.S.W MASTER OF SOCIAL WORK
M.A. JOURNALISM & MASS COMMUNICATION
M.A. HUMAN RESOURCES MANAGEMENT
LIBRARY PROGRAMMES (01)
M.L.I.Sc MASTER OF LIBRARY & INFORMATION
SCIENCE
CERTIFICATE PROGRAMMES (02)
C.L.I.Sc (CERTIFICATE PROGRAMME IN LIBRARY &
INFORMATION SCIENCE)
C.P.Y (CERTIFICATE PROGRAMME IN YOGA)
DIPLOMA PROGRAMMES (05)







Diploma in Systems Design and Full-Stack
Development
Diploma in Databases, Warehousing and ETL
Pipelines
Diploma in Applications of Generative Artificial
Intelligence
Diploma in Artificial Intelligence and Machine
Learning
Diploma in Cloud Infrastructure Management &
DevOps

<!-- page 4 -->

ACHARYA NAGARJUNA UNIVERSITY
CENTRE FOR DISTANCE EDUCATION
Recognized by UGC-Distance Education Bureau(DEB), New Delhi
Dual Mode NAAC “A+” Grade with 3.46 Score
PROGRAMMES OFFERED IN ANUCDE (SEMESTER MODE) FOR THE ACADEMIC YEAR 2026-27 BATCH
Sl.No. Programme
Code

Programme Name

Eligibility Criteria

1st Year
Admission
Fee Rs.

2nd Year
Admission
Fee Rs.

English

15200

16450*

English

15200

16450*

English

15200

16450*

English

15200

17000*

English

7800

9400*

English

15200

17250*

English

22000

23400*

English

24000

26550*

Duration Medium

PG-SCIENCE PROGRAMMES
1

01

M.Sc. - BOTANY

2

02

M.Sc. - ZOOLOGY

3

03

M.Sc. - PHYSICS

4

04

M.Sc. - CHEMISTRY

5

06

M.Sc. - MATHEMATICS

6

138

M.Sc. - STATISTICS

7

109

M.Sc. - COMPUTER
SCIENCE

8

194

MCA

B.Sc. with Botany as one of the compulsory subject,
along with any two of the following subjects: Zoology,
2 Years
Chemistry, Forestry, Biotechnology, Food Technology,
(4 Sems)
Medicinal Botany, Environmental Science /
Any two Life Science subjects
B.Sc. with Zoology/ B.Sc. Fishery Science/
2 Years
Aquaculture/Industrial Fish and Fisheries/ B.Sc. with all
(4 Sems)
Life Sciences & Environmental Sciences
2 Years
B.Sc. with Physics & Mathematics
(4 Sems)
2 Years
B.Sc. with Chemistry
(4 Sems)
B.A/B.Sc.with Mathematics as one of the Three equal subjects or as 2 Years
a Main Subject
(4 Sems)
2 Years
B.A/B.Sc.with Mathematics and Statistics
(4 Sems)
Any bachelor’s Degree with B.Sc. Computer Science
(OR) B.Sc. Information Technology (OR) B.C.A. (OR)
B.Com. Computer Applications (OR) B.A. Computer
Applications (OR) Any Bachelor’s Degree with
2 Years
Computer Science or Computer Applications as one of (4 Sems)
the subjects (OR)
B.Sc. Computer Applications with Mathematics as
course of study at Intermediate/10+2 Level.
1. Any Bachelor’s Degree with 50% aggregate (45%

2 Years

<!-- page 5 -->

for BC, SC & ST) (other than BFA& BOL) with
(4 Sems)
Mathematics at Inter or Degree. If Mathematics is
not studied at Degree level, Mathematics at Inter
level is required. Ex: B.Com Students with Inter
MEC Group are eligible.
2. Pass in ANUCDE Entrance Test or AP ICET-2025.

PG-ARTS PROGRAMMES
9

14

10

15

11

190

12

110

13

16

14

17

15

18

16

19

17

21

18

29

19

191

2 Years
English
(4 Sems)
2 Years
Any Bachelor’s Degree with Telugu
M.A.- TELUGU
Telugu
(4 Sems)
Any Bachelor’s Degree with Sanskrit / M.A.Telugu with 2 Years
M.A. - SANSKRIT
Sanskrit
at least one Sanskrit paper
(4 Sems)
Any Bachelor’s Degree with Hindi as second Language/ B.A.with
Hindi as Special subject/ Rastra Bhasha Praveena from Dakshin
2 Years
Bharat Hindi Prachar Sabha of Madras / Sahitya Sammalan or
M.A.- HINDI
Hindi
(4 Sems)
Visharad Diploma or Hindi Vidwan program of Allahabad or
Hindi Prachar Sabha, Hyderabad
2 Years
Any Bachelor’s Degree
M.A. - ECONOMICS
Telugu
(4 Sems)
2 Years
Any Bachelor’s Degree
M.A.- HISTORY
Telugu
(4 Sems)
2 Years
Any Bachelor’s Degree
M.A.- POLITICAL SCIENCE
Telugu
(4 Sems)
2 Years
Any Bachelor’s Degree
M.A.- SOCIOLOGY
Telugu
(4 Sems)
MSW - MASTER OF
2 Years
Any Bachelor’s Degree
English
SOCIALWORK
(4 Sems)
M.A.- JOURNALISM &
2 Years
Any Bachelor’s Degree
English
MASS COMMUNICATION
(4 Sems)
M.A.HUMAN RESOURCES
2 Years
Any Bachelor’s Degree
English
MANAGEMENT
(4 Sems)
M.A.- ENGLISH

Any Bachelor’s Degree with English

6730

8550*

6730

8550*

6730

8550*

6730

8550*

6730

8550*

6730

8550*

6530

8550*

6530

8550*

10030

12650*

7730

9550*

8930

11350*

6730

8750*

6730

8750*

PG-COMMERCE & MANAGEMENT PROGRAMMES
20

12

M.COM-ACCOUNTANCY

B.Com/BBM/BBA

21

13

M.COM –BANKING

B.Com/BBM/BBA

2 Years
English
(4 Sems)
2 Years
English
(4 Sems)

<!-- page 6 -->


22

23

24

25

26

193

M.B.A GENERAL
(Two Specializations)

195

M.B.A (INTERNATIONAL
BUSINESS)

196

M.B.A (TRAVEL &
TOURISM MANAGEMENT)

197

M.B.A (HOSPITAL
ADMINISTRATION)

198

M.B.A (HUMAN
RESOURCE
MANAGEMENT)










Any Bachelor’s Degree with 50% aggregate (45%
for BC, SC & ST) (other than BFA& BOL) with 2 Years
Mathematics at 10thor Inter or Degree.
(4 Sems)
Pass in ANUCDE Entrance Test or AP ICET-2025
Any Bachelor’s Degree with 50% aggregate (45%
for BC, SC & ST) (other than BFA& BOL) with 2 Years
(4 Sems)
Mathematics at 10thor Inter or Degree.
Pass in ANUCDE Entrance Test or AP ICET-2025
Any Bachelor’s Degree with 50% aggregate (45%
for BC, SC & ST) (other than BFA& BOL) with 2 Years
(4 Sems)
Mathematics at 10thor Inter or Degree.
Pass in ANUCDE Entrance Test or AP ICET-2025
Any Bachelor’s Degree with 50% aggregate (45%
for BC, SC & ST) (other than BFA& BOL) with 2 Years
(4 Sems)
Mathematics at 10thor Inter or Degree.
Pass in ANUCDE Entrance Test or AP ICET-2025
Any Bachelor’s Degree with 50% aggregate (45%
for BC, SC & ST) (other than BFA& BOL) with 2 Years
(4 Sems)
Mathematics at 10thor Inter or Degree.
Pass in ANUCDE Entrance Test or AP ICET-2025

English

23000

24700*

English

23000

24700*

English

23000

24700*

English

23000

24700*

English

23000

24700*

1 Year
English
(2 Sems)

10675*

-

1 Year
English
(2 Sems)

18000*

-

1 Year
English
(2 Sems)

24000*

-

1 Year
English
(2 Sems)

26000*

-

1 Year
English
(2 Sems)

26000*

-

LIBRARY & INFORMATION SCIENCE PROGRAMMES
27

141

M.L.I.Sc (MASTER OF
LIBRARY & INFORMATION
SCIENCE)

B.L.I.Sc

DIPLOMA PROGRAMMES
28

211

29

212

30

213

31

214

Diploma in Systems Design 10+2 Stream or Polytechnic Diploma (with Mathematics at
and Full-Stack Development
+2 Level / Polytechnic Diploma)
Diploma in Databases,
10+2 Stream or Polytechnic Diploma (with Mathematics at
Warehousing and ETL
+2 Level / Polytechnic Diploma)
Pipelines
Diploma in Applications of
10+2 Stream or Polytechnic Diploma (with Mathematics at
Generative Artificial
+2 Level / Polytechnic Diploma)
Intelligence
Diploma in Artificial
10+2 Stream or Polytechnic Diploma (with Mathematics at
Intelligence and Machine
+2 Level / Polytechnic Diploma)
Learning

<!-- page 7 -->
