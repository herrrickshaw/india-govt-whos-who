---
doc_id: "dafb7e7b17b6cfd5"
source_url: "https://sic.ap.gov.in/sic_fe/assets/img/Circulars/CIRCULAR_28.pdf"
ministry: "Andhra Pradesh Information Commission"
title: "Document"
date: ""
pages: 1
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "01abb9b82b8e2efc"
---

<!-- page 1 -->

~
GOVERNMENT OF ANDHRA PRADESH
GENERAL ADMINISTRATION (GPM&AR) DEPARTMENT
circular U.O. Note 20209/RTIAIGPM&AR/2011 Dated: 30.06.2011

Sub:- Minutes of the meeting of Secretary, DoPt&T with Principal
Secretaries of GADI Personnel Departments of States / Cadres
held on 24.03.2011 at Civil Service Officers Institute, Kasturba
Gandhi Marg, New Delhi Communication of Minutes -
Regarding.

Ref- Lr. No.14015/25/2011, AlS-I, GOI, MOR, PG8&P, Department of
P&T, dt. 6.5.2011, received through U.O. Note No.
135/Spl.A/A3/2011-4, dt.18.06.2011

All the Public Authorities in the State are requested to take action on

as listed below for the proper and effective implementation of RTI Act,
2005 in the State.

(i) Ensure maximum suo-moto disclosure of the information by
the Public authorities Under Section 4(1)(b) of the RTI Act. The
information should also be periodically updated.

(ii) Help create awareness among the disadvantaged Communities
and train Public Information Officers and Appellate authorities.

(ii?) Popularize the RTI Logo and RTI portal, and

(iv) Encourage the PIOs and AAS to do the free online Course on RTI.

(v) Strengthen Suo-Moto disclosure and ensure the safety of RT!
applicants.

2. All the Departments of Secretariat, All HODs and District Collectors

are requested to review the progress in respect of each of the above

flems with the Public Information officers and Appellate Authorities under

their control and ensure that the RTI Act is implemented properly.

MINNIE MATHEW

ఇ SPECIAL CHIEF SECRETARY TO GOVERNMENT
0

All Departments of Secretariat

All the HOD's

All the District Collectors

Copy to :

The Secretary

A.P. Information Commission

HACA Bhavan, Hyderabad.
