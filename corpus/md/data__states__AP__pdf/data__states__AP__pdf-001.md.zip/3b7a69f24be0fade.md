---
doc_id: "3b7a69f24be0fade"
source_url: "https://theiirm.ac.in/wp-content/uploads/2024/12/ONLINE-NOTIFICATION-AND-EXAMS.pdf"
ministry: "Institute of Insurance and Risk Management (IIRM), Andhra Pradesh"
title: "Download for Details"
date: ""
pages: 3
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "21caec26e72d02be"
---

<!-- page 1 -->

HRM
Date: 12/12/2024
Notification
DISTANCE LEARNING PROGRAM
Sub: Conduct of IPGD (Life Insurance / General Insurance / Risk Management)
Examinations for 34" & Previous Batches
The examinations for Distance Learning students of IPGD (Life Insurance / General Insurance &
Risk Management) for the 34" Batch & all previous batches, it has been decided to conduct the
examinations through ‘online’ mode during January 2025. In this connection, Students are required to
note the following:
1. The Date of Commencement of Examinations is 27/01/2025 (Monday). The Time table for PDF
- Examination is given in the Annexure.
2. Students, for the online mode as stated, should register with the link on or before 10 January,
2025 via the Student’s Mail ID. :
3. No further correspondence will be entertained ifno communication is received from the student on
or before the date and time mentioned above.
For PDF based Examinations (PDFE):;
4. From 27/01/2025 (Monday) Question Paper (QP) will be sent to the Students who have registered
themselves for this Examination by email at 09:00 AM (on each day) as per the time table.
Itis helpful ifthe student acknowledges receipt of the QP. If for any reason a student did not receive
the QPs, he/she may send a mail to: dlole@theiirm.ac.in upon which the issue would be sorted out.
5. Students are given a time to write the answers for each subject and upload the same to the specified
address which is dlole@theiirm.ac.in on the same day by 01:00 PM.
6. Students are expected to scan and upload the Answer Scripts in the PDF format.
Incase of technical issues in uploading of PDF files, you may contact the following persons on their Mobile Nos.
| / Email IDs.
i. Mr. Soma Sankaram U : 9948607128 / somasankaram.u@theiirm.ac.in
| ii. Mr. Umesh B / (| 9989427425 / umesh.b@theiirm.ac.in
7, On the first page of the Answer Script, students are required to indicate their (a) Name,
(b) Roll No and (c) Name of the Subject. All pages should be numbered in sequence and initiaied
at the bottom — right side corner.
8. Answers should be written on plain A4 size papers and cach of the papers should be
. initialed by the Student,
The Answers must be in sequence as Ol, Q2, O3 etc. Due weightage will be given to
resentation, neatness, diagrams wherever applicable etc.
RY
న S 9
L, 1
క్లాప

<!-- page 2 -->

HRM
\
' 9, The Answers to each of the Questions must be in Student’s own handwriting. If for any reason
it is found that the handwriting is not that of the particular Student, even in a single Answer
Script, he /she would attract disqualification.

10. Since the method stated above, amounts to open book examination, a Student is expected to
answer in his/ her own words and not copy from text books / other reading material or from other
students. In case it is found that the answers are same or copied as stated, zero marks will be
awarded and the student would be disqualified.

| 11. The Answer Script for each subject should be converted to PDF form separately. Name of
such a file should read: Subject, Stream and Roll No. for e.g: Health Insurance, (LI / GI /
RM) and xx xx (xx) 001. If the Answer Script is not converted into PDF properly, then such
Answer Scripts will not be evaluated and zero marks will be awarded.

12. Incase ofa doubt in regard to an Answer Script or the Answer File, the Institute reserves the right
not only to reject the Answer Script/Answer File but also cancel the Candidate’s registration and
direct him/her to take to the regular mode of examination. In regard to this aspect, the decision
of the Institute is final. In this case, the student will lose one chance of writing the examination

_ _ free of cost.

13. No Marks will be awarded if the PDF file is not properly scanned and sent for the submission.

14. A disqualified student for reasons cited above, would not only stand to lose one chance of writing
the examinations free of further cost, in addition he / she would be barred from taking any other
online examinations of the Institute in future. He / she should take to the regular mode of
examination as and when it is held, no further correspondence would be entertained in this
regard.

15. Please note that you may appear for examinations on the dates specified as applicable to you
only.

, P. Venkstta Vijay Kumar

Head — Distance Education
Official Website www.theiirm.ac.in of the Institute ARM
ce: Students of Distance Learning = IPGD (LI / GI/ RM) Voy సౌ
by emails as per their records. SRE
2

<!-- page 3 -->

HRM
)
Annexure
Re-sit Examinations Schedule - January, 2025
DISTANCE LEARNING PROGRAM
, IPGD (Life Insurance / General Insurance / Risk Management)
(34 & Previous batches)
|
27-01-2025
| ony) | ల va
28-01-2025
29-01-2025
30-01-2025
| aes
31-01-2025
01-02-2025
The Question paper of the each subject will be delivered to the respective candidate
as per the scheduled date at 9am by email and the answer scripts (Scanned PDF
Document) of the same subject to be mailed back on the same day by 1pm.
Subjects:
LI/GI/RM: 1. Health Insurance (HI)
2. Legal & Regulatory Environment (LRE)
3. Insurance Business & Finance (IBF)
LI: 1, Life Insurance Underwriting (LIU)
2. Principles & Practice of Life Insurance (PPLI)
3. Life Insurance Claims Management (LICM)
GI: 1. Property & Business Interruption Insurances (PBI)
2. Cargo & Marine Insurance (CMI)
3. Motor Insurance (MI)
RM: 1. Fundamentals of Risk Management (FRM)
2. Risk Management in Financial Institutions & Treasury Risk Management (RFITRM)
3. Risk Management in Banking, Insurance & Financial Services (RMBIFS)
eee
ew WRY
“a ws
Cr E©) .
29)
రక్షగా
