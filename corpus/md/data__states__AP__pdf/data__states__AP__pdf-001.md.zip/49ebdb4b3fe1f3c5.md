---
doc_id: "49ebdb4b3fe1f3c5"
source_url: "https://www.dravidianuniversity.ac.in/treasury/img/Notifications/Revised.pdf"
ministry: "Dravidian University, Kuppam, Andhra Pradesh"
title: "Recruitment Cell - Revised Attached Corrigendum dated 03-08-2026"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2dadba54d282600d"
---

<!-- page 1 -->

DRAVIDIAN UNIVERSITY
SRINIVASAVANAM, KUPPAM – 517 426 (AP)
Corrigendum to the Employment Notifications:
1. Notification No. 1/DU/Backlog-SC&ST and BC/2026, Date: 15.05.2026
2. Notification No. 2/DU/Asst. Professor/Regular/2026, Date: 15.05.2026
3. Notification No. 3/DU/Regular/Associate Professors and Professors / 2026, Date: 15.05.2026

Date: 03.08.2026

EXTENSION OF TIMELINES
Sub:

Employment Notifications – Extension of timeline for declaration of the final
list of prima-facie eligible and ineligible candidates – Regarding.
******

With reference to the Employment Notifications cited above and the corrigenda issued
from time to time, it is hereby informed that the date for declaration/display of the final list
of prima-facie eligible and ineligible candidates, which was scheduled for 03-08-2026, is
extended and revised as follows:
Sl. No.
Activity
Existing Date Revised Date
1

Declaration/display of the final list of prima facie
eligible and ineligible candidates

03-08-2026

19-08-2026

All other terms and conditions contained in the original Notifications and
Corrigendum shall remain unchanged.
Sd/Registrar
