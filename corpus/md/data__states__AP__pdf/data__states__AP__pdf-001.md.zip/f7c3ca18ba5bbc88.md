---
doc_id: "f7c3ca18ba5bbc88"
source_url: "https://sic.ap.gov.in/sic_fe/assets/img/Circulars/CIRCULAR_30.pdf"
ministry: "Andhra Pradesh Information Commission"
title: "Document"
date: ""
pages: 2
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "5f68ec5e317299ff"
---

<!-- page 1 -->

GOVERNMENT OF ANDHRA PRADESH
GENERAL ADMINISTRATION (GPM&AR) DEPARTMENT
circular U.O.Note. No. 33583/RTIA/ GPM&AR/2011, Dated:27.10.2011
gb: RTI Act, 2005 — Appointment of Nodal Officers for coordination of
RTI Act, 2005 where there is more than one Public Information
Officer — Regarding.
ref- 1.Government of India, Ministry of Personnel, Public Grievances and
Pensions, OM No. 1 / 32/ 2007- IR, dt.14.11.2007.
2.Spl.Chief Secretary to Govt, G.A(GPM8&AR) Dept., D.O.Lr.No.24533
/RTIA/ GPM&AR / 2011, dt.06.09.2011.

The attention of all Departments of Secretariat, all Heads of
Departments and District Collectors is invited to the reference 13 cited,
wherein Government of India based on the observation of the Second
Administrative Reforms Commission in its first report have issued
instructions that all Public Authorities with more than one Public Information
Officer (PIO) should designate a Nodal Officer with the Authority to receive
requests for information on behalf of all PIOs. It was also requested to
create a Central Point within the organization where all the RTI applications
/ appeals may be received and sent to the concerned PIOs / Appellate
Authorities. An Officer should be made responsible to ensure that all the
RTI applications / appeals received are sent to the concerned PIO /
Appellate Authority on the same day.

2. In the D.O.Letter second cited, all Departments of Secretariat
were requested to appoint a Nodal Officer for coordination where there is
more than one PIO and inform the particulars along with contact numbers
to G.A(GPM&AR) Dept.

3. Inspite of the above, it is observed that most of the Public
Authorities under State Government have neither created the Central Point
for receiving the applications / appeals nor appointed the Nodal Officers
for coordination of RTI related matters within the organization.

4. In this connection, it has come to the notice of the Government
that the applicants under RTI Act, are facing much difficulty in approaching
the appropriate PIO and in identifying the First Appellate Authority. 1౧ view
of this, it has been decided to make available the particulars of the Nodal
Officers in all Public Authorities under State Government to the public in
the website of A.P. Information Commission to avoid the confusion as to
whom they have to approach for a particular information.

<!-- page 2 -->

5. All Public Authorities under the State Government where there
is more than one Public Information Officer are requested to appoint a
Nodal Officer for Coordination of RTI Act immediately within the
Organisation with instructions to receive applications / Appeals under the
Act and to send them to the concerned PIOs / Appellate Authorities, on the
same day and to maintain a separate register for the purpose. The timely
submission of reports to the A.P.Information Commission may also be
entrusted to that Nodal Officer.
6. All Departments of Secretariat, all Heads of Departments and
District Collectors are requested to take necessary action accordingly and
inform the particulars along with contact numbers of the Nodal Officers
under RTI to A.P.Information Commission, Hyderabad under intimation of
this Department for making the particulars available in the website of
A.P.Information Commission. They are also requested to see that the above
instructions are followed scrupulously by all the Public Authorities under
their control and intimate the particulars of the Nodal Officers to
A.P.Information Commission. The Public Authorities who have designated
only one Public Information Officer (PIO) may also intimate the particulars
of that PIO to A.P.Information Commission.
MINNIE MATHEW
SPECIAL CHIEF SECRETARY TO GOVERNMENT
