---
doc_id: "c230b9eb3ee6af5b"
source_url: "https://anucde.info/6thSEMNOTIFICATIONMAY2026.pdf"
ministry: "Acharya Nagarjuna University, Centre for Distance Education, Andhra Pradesh"
title: "VI Semester(Regular and Supplimentary) Viva-Voce Examination Notification"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "562e60b866f96c50"
---

<!-- page 1 -->

CENTRE FOR DISTANCE EDUCATION
ACHARYA NAGARJUNA UNIVERSITY:: NAGARJUNA NAGAR- 522 5IO.
SYED ZAINULABDIN,

Office: 0863-2346228

DEPUTY REGISTRAR (EXAMS)

2346229

N o. AN U/C D E/V I Seme ster ExamA',,I ot i fi c ation/ 2026

Date:06-05-2026

NOTIFICATION
Sub: ANU - CDE - Conduct of VI Semester Regular & Supply exams to all UG Courses -

Notification issued - Reg.

Ref: Vice-Chancellor' s orders dated. 05 .05 .2026.

***

The Vice-Chancellor has ordered that the Centre for Distance Education, Acharya Nagarjuna

University to conduct VI Semester (Regular & Supplementary) Examinations for the UG Courses to
the following batches during May,2026.

BATCH

S.NO.
I

)

COURSE

A22 &C23

UG

c2l, Azt &c22

UG

. For payment of Project/Viva Voce fee
2. Last date for payment of examination fee
I

SEMESTER
VI SEMESTER (REGULAR)
VI SEMESTER (SUPPLEMENTARY)

: Rs. 1.000.00
: 20-05-2026

The examination fee payable through offline only

5y)''
DEPUTY REGISTRAR
(cDE - EXAMTNATTONS)

A ls/-t

To
The editors of allNews Papers - With a request to publish the notification as news item in all the

daily News Papers.
Copy to the Director, CDE, ANU.
Copy to the Coordinator, CDE, Exams, ANU.
Copy to the Deputy Registrar, UG Exams, CDE, ANU.
Copy to the Assistant Registrar, Coordinator Office, CDE, ANU.
Copy to all Study Centres of CDE - with a request to notifi in the notice board for communication
Copy to all P.A. to Registrar/RectorA/ice-Chancellor, ANU.
