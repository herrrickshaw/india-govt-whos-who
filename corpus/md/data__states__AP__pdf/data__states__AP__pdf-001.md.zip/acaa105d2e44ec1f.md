---
doc_id: "acaa105d2e44ec1f"
source_url: "https://anucde.info/ExNotificationSepOct2026.pdf"
ministry: "Acharya Nagarjuna University, Centre for Distance Education, Andhra Pradesh"
title: "Examination Notification :: September 2026"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3987f63ac65e7a6d"
---

<!-- page 1 -->

CENTRE FOR DISTANCE EDUCATION
ACHARYA NAGARJUNA LIIIIYERSITY : : NAGARJUNA NAGAR -522510

Office: 0863-2346228
CH. USHA RANI,
.R (U,xams)
2346229
DEPUTY REGIS
05-08-2026
Date:
No.ANU/CDE/I, II, III, IV & V Semester Examinations/Notificationl2}26,

NOTIFICATION
Sub: ANU - CDE - Issue of Examination Notification for conduct of 1", 2nd, 3'd, 4th &
5th Semesters (Regular/Supplementary) and Year End (Supplementary)
Examinations to be Commenced from 24-09-2026 to all UG, PG, & Diploma
Certificate Courses - Regarding.
Ret Vice-Chancellor's Orders dated 04-08-2026.
**{<{.*

The Vice-Chancellor has ordered that the ANU, CDE, I't, 2nd,3'd,4th & 5th Semesters
(Regular/Supplementary) and Year End (Supplementary) examinations to the students of all
UG, PG, & Diploma Certificate courses to be commenced from 24-09-2026 for the following
batches.

sl.

UG Batches

PG Batches

Semesters

No.

Commencement
Exam Date

Tentatively

L

c26
c21, A21,C22, A22,
c23, A23,C24, A24,
c25 &, Azs

I Semester (Regular)
c21, 421, C22, 422, I Semester
c23,423,C24,424 (Supplementary)

3

A25

4

c21, A21,C22, A22,
c23, A23,C24, A24
& czs
1.24 &C25
c21, A21,C22, A22,
C23,423 8.C24
c24
c21. A21,C22, A22.
c23 & A23

II Semester (Regular)
czl, 421, C22, 422, II Semester
c23, A23, C24, A24 (Supplementary)

2.

5.
6.
7
8

&c25

&c25
A24 &,C25

c21, 421, C22, A2Z,
c23,1^23 &C24
c24

IV Semester

c23 & A23

(Supplementary)
V Semester (Regular)
V Semester (Supply)

1.23

10.

czl, A21.c22, A22
8. C23

12.

A25 (Diploma/
Certificate Courses)
c2l, A21, C22, A22,
c23, A23,C24, A24

& czs

(Supplementary)
IV Semester (Regular)

czl, A21,C22, A22,

9

11.

III Semester (Regular)
III Semester

(Regular)

(Supplementary)

(Diploma/Certificate
Courses)

l3

Year End (Supplementary) Exams to all UG, PG, & Diploma
Certificate courses

24-09-2026

<!-- page 2 -->

The Examination fee is payable through online only and it is available at website
WWW.anucde.info. The Time-Tables and Examination application Form (for Semester and
Year End supplementary Students only) is also available at website WWW.anucde.info. The
Regular semester students who have paid tuition fee for 2"d &.3'd year respectively are not
required to pay any examination fee and no need to submit the examination application.
The schedule of dates for pavment of supplementary examinations fees is as follows:
25-08-2026
1. Last date for payment of examination fee without
28-08-2026
2.Last date for payment of examination fee with fine of

fine
Rs.l00/-

:
:
3. Last date for payment of examination fee with Tatkal fine of Rs.500/- :

3l-08-2026

Note:

l. The students who are not paid examination fee and to be appeared for exams, fine will
be imposed for Rs. 1,000/- in addition to examination fee.

2. The Re-Registration batch students to be paid prescribed Re-Registration fee along with
the above said examination fee to complete the course beyond the maximum duration of

the course. The Re-Registration fee details course wise will be attached to fee
notification
Examination Fee for A[ UG, PG & Diploma/Certificate Courses and Year End:
Four &
Above

All UG/PG/Diploma/
Certilicate Courses under

Single

Two

'f hree

semester system

paper

papers

papers

AVhole
papers

First Semester

750

880

I 100

1400

It00

770

220

Second Semester

750

880

r 100

1400

lr00

770

220

Third Semester

750

880

I 100

1400

r 100

770

220

Fourth Semester

750

880

l 100

1400

1100

170

220

Fifth Semester

750

880

I 100

1400

I 100

170

220

750

880

l 100

t 400

I r00

770

220

Project
/ VivaVoce

l,ab I
Practicals

Assignments

Betterment
Fee

2000tand
Exams
Ii'ee

All UG/PG/Diploma/
Certificate Courses
Year-End Supplementary

Note: The semester system students who were completed their courses and got 2nd and 3'd
classes are only eligible for betterment to improve their percentage of marks or to obtain class
with in the maximum duration of the course period respectively.

\
^4.

DEPUTY RBGISTRAR
(CDE - EXAMINATIONS)
The Editors of allNews Papers - With a request to publish the notification as news item in all
the daily newspapers.
Copy to the Director, CDE, ANU.
Copy to the Coordinator, CDE, Exams, ANU.
Copy to all P.A. to Registrar/Rector/Vice-Chancellor, ANU.

To

ooF
