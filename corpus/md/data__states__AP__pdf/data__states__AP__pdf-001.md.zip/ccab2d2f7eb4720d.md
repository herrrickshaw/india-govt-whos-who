---
doc_id: "ccab2d2f7eb4720d"
source_url: "https://www.apindustries.gov.in/APIndus/Data/GO/Rawmaterialsgo.pdf"
ministry: "Industries and Commerce Department, Andhra Pradesh"
title: "GO for Allotment for Raw Materials"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "08a6485db35a0dfd"
---

<!-- page 1 -->

GOVERNMENT OF ANDHRA PRADESH
ABSTRACT
Industrial Promotion – Application and processing of raw materials (coal)
through Information Technology enabled platform with an aim to improve the
ease of doing business in the State of Andhra Pradesh as per various Industrial
Policies for industrial units established in the state of Andhra Pradesh – Orders
- Issued.
=================================================
INDUSTRIES & COMMERCE (POLICY & INVESTMENT) DEPARTMENT
G.O.MS.No. 155

Dated: 03-11-2016
Read the following:

1. G.O.Rt. No. 192, Inds & Com. (MSME) Dept., dated. 26-03-2012.
2. G.O.Rt.No.408, Inds & Com. (MSME) Dept., dated. 28-06-2012.
3. G.O.Rt.No. 332, Inds & Com. (MSME) Dept., dated. 21-05-2013.
4. Circular No: 11-1-5-0006-0006/FD dated 27.06.2011.
5. Circular No: 11-1-2005-0006-0006-FD dated 27.06.2011.
6. Circular No: 11-1-2005-0006, dated 20.07.2010.
7. Circular No. 11-1-5-0006, dated 21.06.2008.
8. New Coal Distribution Policy, Ministry of Coal, Government of India,
dated 18.10.2007.
***

ORDER
Although India has developed sufficient capacities for coal, Micro Small
and Medium Enterprises (MSMEs) facing difficulties in sourcing coal from the
open market. The Department of Industries, Government of Andhra Pradesh
makes recommendations to allot coal to industrial units in Andhra Pradesh.
Before bifurcation of Andhra Pradesh State, MSMEs sourced coal from
M/s. Singareni Collieries Company Limited (SCCL) and in some cases from Coal
India Limited (CIL). After bifurcation, Government of Andhra Pradesh has
designated Andhra Pradesh Mineral Development Corporation Limited (APMDC)
as the nodal agency for coal sourcing in the State. However, presently coal is
sourced through M/s. Singareni Collieries Company Limited( SCCL).
1.
In the G.O. 1st read above, the Government have issued orders directing
the Managing Director, Andhra Pradesh Mineral Development Corporation
Limited, Hyderabad and Commissioner of Industries, Andhra Pradesh to take
up action in making Andhra Pradesh Mineral Development Corporation Limited
as nodal agency for supply and distribution of coal to the MSME sector from
quantity allocated by Coal India Limited for Andhra Pradesh State for the year
2011-12.
2.
In the G.O. 2nd read above, orders were issued for appointment of
APMDC as a nodal agency for supply and distribution of coal to MSMEs from
Mahanadi Coal Field Limited allocated by the Coal India Limited for Andhra
Pradesh State for a period of 5 years from 2012-13 to 2017-18.
4.
In the G.O. 3rd cited, the Government have issued orders directing the
Andhra Pradesh Mineral Development Corporation Limited, to continue as
Nodal agency for supply and distribution of coal to the MSME sector for the
quantity allocated by Coal India Limited for Andhra Pradesh.
5.
At present, the application for coal is initiated manually by an industrial
unit and processed offline by the Government. Units submit their application
for coal allotment along with the required supporting documents in the Office
of the General Manager, District Industries Centre (GMDIC) of the respective
District in hard copies. The District Industrial Promotion Committee (DIPC)
under chairmanship of the District Collector scrutinizes the proposal with the
inspection report of District Industries Centre (DIC) as per technical norms
(P.T.O)

<!-- page 2 -->

::2::
specified by the State Government vide references 4th, 5th, 6th mentioned
above and provides recommendation to Director / Commissioner of Industries
for coal quantity over and above 100 MT per month.
6.
Andhra Pradesh has achieved the distinction of being the 2nd ranked
State in India for Ease of Doing Business as per the DIPP - World Bank ranking
for the year 2015. In continuation with business reform action plan and focus
on technology driven improvements in Government procedures, Industries &
Commerce Department has come up with a proposal to route the application
and processing of coal allocation through the Single Desk Portal (SDP) in line
with the Andhra Pradesh Single Desk Policy 2015.
7.
In line with the above, it is proposed to move to a new online system of
coal allocation facilitated through the Single Desk Portal (SDP). Single Desk
Portal will ensure authenticity of transactions through Digital Signatures and
One Time Password (OTP) based authentication. The number of documents to
be uploaded is minimised and the provision of self-certification by the Unit is
being introduced through this Government Order. The proposed new system
shall eliminate the need to physically visit the Department for seeking coal
allotment recommendation. The step by step process for online application is
available in Annexure I appended to this G.O. The measures proposed in this
G.O. are as follows:
(a) For Fresh Allotments of coal
(1) An applicant will be required to fill an online ‘Common
Application Form’ (Annexure II) to provide enterprise details
and a ‘Self-Assessment Form’ (Annexure III) to assess the
amount of coal to be allocated.
(2) A self-declaration (Annexure IV) will need to be made to
accept liability and penalization in case of misuse by the
Unit.
(2) Upon successful submission of the aforementioned forms, a presigned ‘Recommendation Letter’ specifying the coal quantity will
be auto generated. On the basis of the quantity of coal to be
allotted, the recommendation letter shall be pre-signed in the
name of:
• GMDIC for recommended quantity <100 MT per month
• Additional Director, Directorate of Industries for recommended
quantity 101-350 MT
• Director / Commissioner of Industries for recommended
quantity >350 MT
(3) This recommendation shall have validity linked with that of the
validity of Consent for Operation / Establishment (CFO / CFE)
certificate of the unit.
(b)

For existing allotments of coal

(1) In case of units having valid existing recommendations, it is
proposed that such Units also fill the Common Application
Form (CAF) on SDP and upload the scanned copy of the
manual recommendation letter within 60 days of the release
of this GO.
(Cont…)

<!-- page 3 -->

::3::
(2)

The unit will also need to fill in the self-assessment form. In
case of difference between the existing approved quantity and
quantity assessed on Single Desk Policy, recommendation for
the lower quantity shall be auto-generated. On successful
submission, a recommendation linked to the validity of the
Consent for Operation (CFO) certificate shall be autogenerated.

(c) Process at SCCL / APMDC
(1) A copy of the auto-generated recommendation letter is sent to
SCCL and Andhra Pradesh Mineral Development Corporation
Limited (APMDC) through an auto-generated mail. Applicants shall
approach APMDC / SCCL with the recommendation letter and
make the necessary payment to obtain a Sale Order.
(2) APMDC / SCCL should take a security deposit from the applicants
in form of Earnest Money Deposit (EMD) issued by a commercial
bank and valid for a period of 1 year. Every year, this security
deposit shall be renewed. The security deposit shall be as
follows:
Year
No payment default
Payment Default
5% of previous year
5% of previous year
st
1 Year
consumption
consumption
5% of previous year
5% of previous year
2nd Year
consumption
consumption
rd
3 Year
onwards upto
3% of previous year
5% of previous year
the validity of
consumption
consumption
CFO
certificate
New units
that have
started
5% of current year recommendation. 2nd year
operations
onwards the above shall apply
within the
year
(d)Review and Monitoring
(1) After, a “Recommendation Letter” has been issued, units will be
required to update coal consumption along with production details
on monthly basis.
(2) Units must provide these details for a month by the end of the
next month.
(e)Remedial Measures / Penalty
(1)
Department of Industries is empowered to carry out
random audits / inspections or may engage a third party to do
so. In case of false self-certification by the Unit, following penalty
shall be imposed.
• Recovery of the amounts between administered price (price at
which coal is allocated) and the e-auction price (price at which
coal is sold in the open market). e-auction price shall be price of
(Cont…)

<!-- page 4 -->

::4::
the latest coal e-auction held by Singareni Collieries Company
Limited (SCCL) for the grade of coal procured by the Unit.
• Revocation of the recommendation in case the Unit is found to
be involved in fraudulent practices.
(2) In case the unit has to stop production temporarily and does not
need coal for a certain period, the unit shall select the months
for which no coal is needed on the portal. The system will auto
generate a notification to SCCL directing it not to allot coal to the
particular unit for a given period. The allotment shall be in
abeyance for the period and resume for future months only if
self-certification is resumed online.
8.
The Director of Industries and General Managers, District Industries
Centre are directed not to accept any application offline / hard copies and
process the application as per the guidelines enclosed to this order.
9.
This Government Order shall supersede all the G.Os. /Circulars of
Directors / Commissioners in regards to allotment / recommendation of coal in
the State of Andhra Pradesh.
10.
These orders shall come into force from the date of hosting of the online
software application for ‘Raw Materials Allocation’ on the Single Desk Portal
(SDP).
11.
The Director of Industries, Andhra Pradesh, Hyderabad shall take
necessary action accordingly.
(BY ORDER AND IN THE NAME OF THE GOVERNOR OF ANDHRA PRADESH)
SOLOMON AROKIARAJ
SEC RETARY TO GOVERN MENT &
COMMISSIONER FOR INDUSTRIAL PROMOTION
To
The Director of Industries, Andhra Pradesh, Hyderabad.
Copy to
The Finance(FMU.Rev.IC) Department.
The Accountant General, Andhra Pradesh, Hyderabad.
The Pay and Accounts Officer, Ibrahimpatnam, Krishna District.
The Director of Treasuries and Accounts, Ibrahimpatnam, Krishna District.
All District Collectors through the Director of Industries, Hyderabad.
All Heads of Departments through Director of Industries, Hyderabad.
Heads of SCCL and APMDC.
The General Managers, District Industries Centre through Director of
Industries, Andhra Pradesh, Hyderabad.
The P.S. to Chief Secretary to Government
All Private Secretaries to the Ministers.
The P.S. to Prl. Secretary to Chief Minister.
The P.S. to Secretary &CIP.,
//FORWARDED::BY ORDER//

SECTION OFFICER

(Contd.. for Annexures)

<!-- page 5 -->

ANNEXURE – I
(G.O.Ms.No.155, Ind. & Com. (P&I) Deptt., Dated: 03.11.2016)

Procedure to be followed on Single Desk Portal for raw material
allotment of coal:
1. Units need to apply through the Single Desk Portal (SDP) at
www.apindustries.gov.infor applying for coal raw material.
2. Units not yet registered on SDP:
a. Units not registered in SDP need to first register on it.
b. A unique User ID and Password shall be generated and
communicated via email and SMS.
c. Units shall use the SDP login credentials to log into SDP and
navigate to the ‘Raw Materials’ allocation section.
3. Units already registered on SDP:
a. Registered Units shall login and navigate directly to the ‘Raw
Materials Allocation’ section.
4. Once registered on SDP, all Units shall be identified through their user id
and password and all transactions authenticated through an OTP (One
Time Password) sent on the mobile number provided at the time of
registration.
5. Units are required to fill the Common Application Form (CAF) as
mentioned in Annexure II.
6. Units already having a valid recommendation issued earlier, shall
also fill the assessment form. Additionally such Units shall also provide
the CFO expiry date, recommendation expiry date, recommended
quantity & grade and also upload a scanned copy of the
recommendation.
7. All the relevant documents as indicated on the SDP, shall be scanned
and uploaded along with the CAF. No hard copy is required to be
submitted in the District Industries Centre.
8. All applicants shall fill in the online ‘Self-assessment’ form which will
auto-calculate the quantity of coal that can be allotted based on various
input parameters as mentioned in Annexure III.
9. District Industries Centre will facilitate any technical support with
respect to scanning of documents and uploading them on the Single
Desk Portal (SDP).
10.Document copies that are already existing in the Single Desk Portal
(SDP) shall be auto uploaded.
11.All applicants should provide a ‘Self-declaration’ confirming that details
entered are correct, as mentioned in Annexure IV. Department may
mandate the application to be digitally signed by the Units at a later
stage.
12.After successful submission of the application, an auto generated presigned ‘Recommendation Letter’with validity same as that of the CFO
certificate will be generated and shall be available for download by the
Unit. A copy of the recommendation letter will also be auto-forwarded to
SCCL / APMDC.
13.After a recommendation letter is auto-generated, the department may
ask for additional information or clarifications in case of any shortfall.
The same will be communicated to the Unit through:
a) SMS to the mobile of the authorised representative from the Unit
b) Email Id of the authorised representative from the Unit
c) Entrepreneur dashboard in Single Desk Portal (SDP)

<!-- page 6 -->

(P.T.O)
::2::
14.If the department is not satisfied with the uploaded documents /
additional information provided, the recommendation may be revoked.
The department may also issue a revised allotment letter and also
inform SCCL / APMDC about the same. The previous allotment letter
shall become null and void in that case. Only downward revision can be
done. For upward revisions, fresh applications shall be filed.
15.All Units will need to provide production and consumption details along
with the actual quantity allotted by SCCL monthly on the Single Desk
Portal.
16.Units shall be flagged in case of mismatch between the submitted
returns and recommended quantity beyond a defined tolerance value
(+/- 20%difference between recommended value and last 3 months
moving average of consumption).Additionally, in case the Unit fails to
provide consumption details for more than month, the unit shall be
flagged. Department may decide to carry out inspection of the unit.
Department may also carry out random audits for any unit.
17.Once the validity of the CFO certificate expires, a fresh application will
need to be raised for further allotment.
18.In case of capacity expansions, a new application will need to be filled.
19.Upon generation of a new recommendation letter in case of expansion of
a project / change in coal requirement, the previous recommendation
shall become null and void.
SOLOMON AROKIARAJ
SECRETARY TO GOVERNMENT &
COMMISIONER FOR INDUSTRIAL PROMOTION

<!-- page 7 -->

Annexure-II
(G.O.Ms.No.155, Ind. & Com. (P&I) Deptt., Dated: 03.11.2016)
Common Application Form
A. Application for Raw Material__________________________________
(Coal)
B. Do you already have a valid recommendation: __________________ (Yes
/No)
C. If Yes:
a. CFO expiry date _____________________
b. Recommendation expiry date____________
c.
Recommended quantity ________________ (MT), Grade ________
d. Upload recommendation copy ___________
1

Name & Address of the Industry
A) Factory Address
B) Office Address

2

4

PMT SSI Regn. / IEM / EM No or
UAM & Date
Date of Commencement of
Production
Line of Manufacture:

5

Employment

6

CAPITAL INVESTMENT:
A) Land:
B) Building
C)Machinery

7

A) Installed Production Capacity (
PA / PM)
B) Present Operating Capacity (PA /
PM)
Details of furnace / boilers etc.,
where coal/ fire wood / rice husk to
be used:
A) Type of equipment with Technical
Details:
B) Its rated capacity
C) Consumption for Coal per shift:

3

8

9. Quantity of raw material applied for per month _______ (MT)<linked to
self-assessment form>
10. Production and Sales particulars for the last three years for Coal
Yea
r

Producti
on

Sales
Turnov
er
(Rs)

Excis
e
duty
paid
(Rs)

APGST
/ CST
Paid
(Rs.)

From
Singar
eni
Collieri
es Co.
Ltd.

Other
sources
Importe
d Coal/
Indigen
ous
Coal

Other
sourcesfire
wood /
rice
husk /
furnace
oil
/other
fuels

Consu
mption
of coal
for unit
product
ion

Quantit
y (MTS)
(P.T.O)

<!-- page 8 -->

::2::
The following documents needs to be uploaded by the applying Unit(in case
any certificate mentioned below is already available on SDP, it shall be autouploaded):
a. Copy of IEM part b / UAM (UdyogAadhaar Memorandum)
b. Copy of VAT / Central Excise license wherever applicable
c. Copy of valid Boiler license wherever applicable
d. Copy of CFO from APPCB or Acknowledgement from Industries
Department (Other than polluting industries) or copy of
acknowledgement for renewal of CFO along with earlier CFO
e. Copies of other statutory licenses like Drugs administration, Food &
Public Distribution, Prohibition & Excise
f. Factory license
g. Plan approval by APllC, IALA.
h. In case of rented premises, a registered rent agreement on a nonjudicial stamp paper for a period of minimum 3 years.
i. A certification from a practicing CA, giving the details on the quantity
of coal procured/purchased and payment made thereof.

<!-- page 9 -->

Annexure III
(G.O.Ms.No.155, Ind. & Com. (P&I) Deptt., Dated: 03.11.2016)
Applicant Online Self-assessment Form
The applicant (Unit) will be required to fill an online self-assessment sheet
which will be attached with the application form. The self-assessment sheet will
calculate the estimated amount of coal that can be recommended based on
usage, equipment ratings, actual consumption and technical norms developed
by the department.
Applicant (Unit) Input Parameters
(Coal Unit - Tonnes / month, Production unit - As per technical norms)
Have you started production?
Coal Usage for (boiler / kiln)
Technical details of equipment
Boiler Rating in Sq. m.
Number of Shifts
Category
Sub Category
Avg. Production per month as per sales tax returns
Avg. Production per month as per central excise returns
Avg. Production per month as per operating capacity
Production per month as per Installed capacity
Production per month as per capacity furnished in CFO of APPCB
Unit of production as per technical norms
Consumption of coal as per manufacturer's specification of equipment per
month
Actual consumption of coal per month (Coal from SCCL)
Actual consumption of coal per month (Imported Coal)
Actual consumption of rice husk per month
Actual consumption of firewood per month
Actual consumption of furnace oil per month
Actual consumption of other fuel per month
Total Actual Consumption of coal / firewood / rice husk / furnace oil / others
Technical norm as per consumption based on manufacturer's specification of
equipment per month
Technical norm as per actual consumption of coal / firewood / rice husk /
furnace oil / others
Technical norm of the department as per production
Consumption as per boiler rating and no. of shifts
Boiler license expiry date
Recommended Quantity: Coal
Grade
Recommended
Quantity

Grade C

Grade D

Grade E

Grade F

<!-- page 10 -->

Annexure IV
(G.O.Ms.No.155, Ind. & Com. (P&I) Deptt., Dated: 03.11.2016)
Applicant(Unit) self-declaration prior to Application
I, ___________________, am the Proprietor / Managing Director / Director of
M/s
________________________________
and
manufacture
_____________________.
I declare that the details provided in the self-assessment form is correct.
I further declare that the coal quantity allotted by Government of Andhra
Pradesh will be used only as a raw material for manufacturing process and in
no other manner. We shall not misuse the scarce raw material released by the
concerned authority for any other purpose.
I further declare that details of coal consumption and production details will be
submitted on Single Desk Portal every month.. I hereby accept the
responsibility of on a monthly basis in a timely manner.
I further declare to extend all cooperation to the Inspection teams including
any third party empanelled by Government of Andhra Pradesh as and when
required and also provide full details of production receipt of coal, consumption
/ utilization of coal and the balance quantity of coal and any other detail
sought by the Inspection team.
I hereby accept that if any misuse is detected by the Inspection Team /
Industries Department / Vigilance Department, I shall be liable for penal action
as per the rules / norms in vogue including but not limited to blacklisting for
permanent allotment of coal, which shall make me and / or our unit ineligible
for any further allotments of the scarce raw material in the future.
