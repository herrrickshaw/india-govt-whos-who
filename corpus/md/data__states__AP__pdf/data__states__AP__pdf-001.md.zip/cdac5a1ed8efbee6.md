---
doc_id: "cdac5a1ed8efbee6"
source_url: "https://slprb.ap.gov.in/PDFS/APP_SLPRB_USER_GUIDE_2025.pdf"
ministry: "Andhra Pradesh State Level Police Recruitment Board"
title: "User Guide to apply for the post of Assistant Public Prosecutor in the Andhra Pradesh State Prosecution Department"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ab40d1587fa45dc2"
---

<!-- page 1 -->

Andhra Pradesh
State Level Police Recruitment Board

USER GUIDE
To fill the

Online Application Form for the post of

Assistant Public Prosecutors in Andhra Pradesh
State Prosecution Department

1

<!-- page 2 -->

1. Read the following general Instructions carefully and select the I AGREE
checkbox, then click on Continue to proceed further.

2

<!-- page 3 -->

2. The page will direct to “Payment Details”. If Candidate has already paid,
provide the details of Payment Reference ID, Payment Transaction ID,
SSC Hall Ticket No. and Mobile No. and Click on . Fill all the details and
click on Login .

3. If amount not paid, Select the “Click to Pay Using Debit / Credit card /
Net banking)”, page will be directed to the following screen. Fill all the
details and click on Pay Amount.

3

<!-- page 4 -->

After the successful transaction, it will direct to the following page. Note
down the Payment Reference ID and Transaction ID for future
reference.

4.

Click on Proceed to Online Application Form Filling. Fill all the relevant
details and upload the necessary certificates / documents and Click on
Continue.

4

<!-- page 5 -->

5

<!-- page 6 -->

6

<!-- page 7 -->

5.

The following page will display

7

<!-- page 8 -->

6.

Click on Age Relaxation Details Tab and Fill all the Relevant details and
upload Relevant Certificates / Documents and Click on Save button. It
will show message at bottom Age Relaxation Details saved successfully
and Click on Home Button to Fill Remaining Details. Click on Home
Button.

8

<!-- page 9 -->

7.

Click on Study Details Tab and Fill all the Relevant details and upload
Relevant Certificates / Documents and Click on Save button. It will show
message at bottom Study Details saved successfully and Click on Home
Button to Fill Remaining Details. Click on Home Button.

9

<!-- page 10 -->

8.

Click on Other Details Tab and Fill all the Relevant details and Click on
Save button. It will show message at bottom Other Details saved
successfully and Click on Home Button to Fill Remaining Details. Click
on Home Button.

10

<!-- page 11 -->

9.

After completion of all the details, the status of all the Tabs will be
changed from Red to Blue Colour.

11

<!-- page 12 -->

10.

Click on Submit Application. It will show an alert Message “Once
Application Form is submitted, NO editing will be allowed after
submission. Click YES to Proceed to submit the Application Form or
Click CANCEL to edit the Application.
Click YES to proceed to submit Application Form. Click NO to edit the
Application Form. Please note that after submission of Application, No
modifications will be allowed under any circumstances.

11.

After successful submission of application, Download Application Form
button will be displayed. Click on Download Application Form. Filled in
Online Application Form will be downloaded as a PDF File. Take the
printout of the Filled in Online Application Form.

12.

Preserve this Filled in Online Application Form till the completion of
Recruitment process.
-----End of the Document-----

12
