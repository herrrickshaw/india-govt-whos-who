---
doc_id: "7aecde49e2f4b3b0"
source_url: "http://svuniversity.edu.in/wp-content/uploads/2026/08/Revised-V-Semester-Instant-2026-5.pdf"
ministry: "Sri Venkateswara University, Tirupati, Andhra Pradesh"
title: "V- Semester Instant Examination Notification 2026"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "97f9dd9061c83b02"
---

<!-- page 1 -->

SRI VENKATESWARA UNIVERSITY:: TIRUPATI
EXAMINATIONS BRANCH
No. SVU/B.I (10)/UG Exams/ V-Semester Instant/ Notification/ 2026

Date: 04-08-2026.

From
To
The Controller of Examinations
All the Principals of Affiliated Colleges,
S.V. University
S.V. University
Tirupati
Tirupati
Sir/ Madam,
Notification for UG-V- Semester Instant Examinations
to be held in August2026.
Sub:- SVU Examinations – Conduct of UG- V Semester Instant Examinations
(Regular) of all UG- Courses to be held in August 2026 - Calling for
Applications through online- Notification issued- Regarding.
Ref:-

Rector’s orders dated: 29-07-2026.

*****
With reference to the above, I am, by direction, to issue Notification Schedule for
Registration of Examination applications through online for UG V- Semester Instant
(Regular - R-23) for 2023-24 batch students only of all UG- Courses i.e BA, BA (OL),
B.Com, B.Sc, B.Sc (Home Science),

B-Vocational, B.H.M, B.C.A, B.B.A, B- Music, B-

Dance, etc., which will be conducted in the 3rd week of August 2026 onwards. The details
of the examinations schedule will be intimated in due course.
Further, the Principals are requested to upload Photo and Signature of all students
on or before 06-08-2026. After completion of uploading, further process can be done as per
the on line applications
NOTIFICATION SCHEDULE
Description

V- Semester Instant

The Fee particulars are noted below:Sl.No.

V - SEMESTER

1.

For one paper

Rs.3000

2.

Two papers

Rs.4500

3.

Three papers

Rs.5000

4.

Four papers

Rs.5500

5.

Five papers

Rs.6000

6.

Six papers

Rs.6500

The last date for payment of Instant Examination for without fine is
06- 08-2026.
The last date for
payment of Instant Examination for with fine is
Rs. 1500/- up to 08- 08-2026. & after 09- 08-2026 the fine of Rs.
3000/- up to 11-08-2026.

<!-- page 2 -->

The INSTANT Examinations will be held at the following Centers only.
TIRUPATI

- S.V. Arts College, Tirupati

CHITTOOR

- PVKN Govt. Degree College Chittoor,

MADANAPALLE

- B.T. College, Madanapalli

The Instant Examinations will be conducted in the afternoon session only
between 2.00 PM to 05.00 PM.
NOTE:1. The candidates, who admitted during the academic year 2023-24 with
regulations of 2023-24 and completed the course in the academic year
2025-26, are only eligible for this Instant Examinations.
2. I to IV Semester the supplementary and malpractice candidates are
eligible to apply for the V- Semester instant examinations.
3. The fee paid for V semester instant exams will not be refunded at any
cost.
4. NO PRACTICAL EXAMINATION is conducted in the INSTANT Examination.
5. There is no facility of Revaluation/Re-totalling/Personal Identification in
the INSTANT Examinations.
(BY ORDER)
NEELAM SANJEEVA REDDI
BHAVAN, TIRUPATI
Date: 29-07-2026
Sd/- Dr. B. Rajamanikyam
CONTROLLER OF EXAMINATIONS
To
The Principals of all Govt./Affiliated Degree Colleges, SV University Area.
Copy to the Finance Officer, SV University, Tirupati
Copy to the Dean, Examinations, S. V. University for information.
Copy to the Dean, CDC, S V University for information.
Copy to all the A.A.O.s (Exams), the Superintendents, SVU Examinations
Branch, Tirupati for information and necessary action.
Copy to the PS to Vice-Chancellor/Registrar, SV University Tirupati for
information.
Copy to file.

<!-- page 3 -->

SRI VENKATESWARA UNIVERSITY:: TIRUPATI
EXAMINATIONS BRANCH
Special Instructions to all the Principals of Affiliated Colleges
(UG- V- Semester Instant Examinations of August - 2026)


The College Principals have to open their corresponding User IDs with their Passwords
provided by M/s Tata Consultancy Service (TCS), Mumbai and upload the
fee
particulars
of
the
Students
details
through
https://www.tcsion.com/SelfServices/ for any quarries send to email
ajay.basampelli@tcs.com & helpdesk.svuexams@gmail.com.

 The University has decided to conduct the UG V- Semester Instant Examinations
for the candidates, of B.A/B.Com/ B.Sc/ B.Sc (H.Sc)/ BHM/BCA/BBA/B. Music/B.
Dance and B.A(OL) DEGREE COURSES of 2023-24 batch (Regular Students) only.
 Applications
are
invited
from
the
eligible
regular
candidates,
of
B.A/B.Com/B.Sc/B.Sc(Home Science), B. Sc (Vocational)/ B.A(O.L)/BHM/ BCA/ B.B.A/
B. Music/ B Dance Degree Examinations held in August, 2026 .
 The online applications have to be filled by the respective colleges through their
college logins and submit the same in the above website. While uploading, If there is
any technical problem arisen that has to be brought to the notice of the under signed
immediately for rectification


The College login will be closed after the last date as mentioned in the notification.



The Principals are requested to pay the examinations fee collected from the Students
Through online only and submit the hard copy of applications and nominal rolls to the
Undersigned immediately. Otherwise, the Hall- Tickets will not be issued, so as to avoid
the future problems at the time of publishing the results



Principals are requested to verify all the applications carefully and upload only eligible
candidates.



Principals are responsible for all the uploaded applications from their respective college
login.



The students, who have admitted during the years 2023-24 shall write the
examinations as per the 2023 Regulations.



Further, the Principals are requested to submit the downloaded applications along with
remittance receipt through special messenger on or before the last date fixed by the
University. If the college concerned does not submit the filled- in applications along
with fee remittance receipt to the University within the prescribed date, even though
the students have paid the fee in time, the Principals concerned are responsible for the
late submission of applications and penal fee will be collected from the Principals
concerned.



Time – Table will be circulated in due course.



A copy of the fee structure is enclosed herewith (Appendix- I). The Principals are
requested to display the same on the notice board of the college.



The Principals are requested to send the Nominal rolls (course wise, group wise and
medium wise) separately in the prescribed proforma.



The Principals are requested to cooperate in sending the examination applications in
time to the undersigned
Sd/- Dr. B. Rajamanikyam
CONTROLLER OF EXAMINATIONS

<!-- page 4 -->
