---
doc_id: "669bb83dec9adf7a"
source_url: "https://nalsar.ac.in/wp-content/uploads/2026/05/ASSL-2020-Andhra-Pradesh.pdf"
ministry: "NALSAR University of Law, Andhra Pradesh"
title: "Andhra Pradesh"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "95d0e3ec0e7c3576"
---

<!-- page 1 -->

The Annual Survey
of State Laws in India
Edited by Amita Dhanda and Faizan Mustafa

The National Academy of Legal Studies and Research (NALSAR)
Justice City, Shamirpet,
Hyderabad, Telangana 500101
2022

<!-- page 2 -->

Mode of Citation: ASSL (2020)

All content in this volume is licensed under a Creative Commons Attribution-NonCommercialShareAlike 2.5 India License (CC BY-NC-SA 2.5 IN)
Under the terms of this license, the full text of which can be found at https://creativecommons.org/
licenses/by-nc-sa/2.5/in/legalcode, you are free to:
• Share — copy and redistribute the material in any medium or format
• Adapt — remix, transform, and build upon the material
Under the following terms:
•

Attribution —You must give appropriate credit, provide a link to the license, and indicate if
changes were made. You may do so in any reasonable manner, but not in any way that suggests
the licensor endorses you or your use.

•

Non-Commercial — You may not use the material for commercial purposes.

•

ShareAlike— If you remix, transform, or build upon the material, you must distribute your
contributions under the same license as the original.

•

No additional restrictions — You may not apply legal terms or technological measures that
legally restrict others from doing anything the license permits.

The licensor cannot revoke these freedoms as long as you follow the license terms.
Notices:
•

You do not have to comply with the license for elements of the material in the public domain or
where your use is permitted by an applicable exception or limitation.

•

No warranties are given. The license may not give you all of the permissions necessary for your
intended use. For example, other rights such as publicity, privacy, or moral rights may limit how
you use the material.

Editorial Advisory Board
Archana Parashar, Emeritus Associate Professor, Macquarie University, Australia
• Cole Durham, Professor, Brigham Young University, USA
• Francesco Palermo, Head, Institute for Comparative Federalism, Eurac Research, Italy
• M P Singh, Professor Emeritus, Delhi University and Distinguished Professor, Jindal Global
University, Sonepat
• Manoj Sinha, Director, Indian Law Institute, New Delhi
• Mihir Desai, Senior Advocate, Bombay High Court
• Rangin Tripathi, Professor of Law, National Law University, Odisha
• Sitharamam Kakarala, Professor, Azim Premji University, Bengaluru

•

<!-- page 3 -->

The Annual Survey of State Laws in India

ANDHRA PRADESH

Anindita Mukherjee1

Introduction1
The Andhra Pradesh legislative assembly is in its fifteenth term, and the second since the state was
bifurcated in 2014. The last Assembly elections, held in 2019 along with the general elections, lead to a
massive upset for the incumbent Telugu Desam Party (TDP). The YSR Congress Party (YSRCP), helmed
by YS Jagan Mohan Reddy, was elected to form government with its largest poll margin till date—they
won 151 of 175 seats.2 In keeping with some of their electoral promises, the government announced
a slew of public policy decisions relating to education and social welfare almost immediately after
coming to power in May 2019. A substantial portion of the government’s legislative activity in 2020,
therefore, came down to fine-tuning decisions made in 2019 and responding to judicial challenges to
them. The pandemic, of course, was the other significant determinant, both of the level of legislative
engagement over the year and its substance.

The Year in Numbers
The AP legislature, according to statistics collated by PRS Legislative Research (PRS), has consistently
spent fewer days in session than the national average. As per the PRS annual review of state laws, among
the 19 states that make this data available publicly, the average number of days that state legislatures
have been in session between 2016 and 2019 is 29, while in 2020 they sat for an average of 18 days.3
Data disclosed by the AP government show that the Assembly has been sitting for around 25-26 days
a year since 2014.4 In 2020, that number was halved to 12, of which five were before the lockdown and
seven, after. The number of hours spent in session also dropped proportionately, with the opposition
(TDP) speaking for a paltry 5.8 hours in the entire year in comparison with the ruling party’s 72.8
hours,5 indicating that most decisions made through the pandemic in the Assembly did not see robust
interrogation by the opposition within the Assembly.

1.
2.
3.
4.
5.

Doctoral Fellow, NALSAR University of Law.
E Venkatesu, “Post-poll survey: dalits and farmers solidly behind YSRCP in Andhra Pradesh”, The Hindu, May 27, 2019.
Anoop Ramakrishnan and N R Akhil, “Annual Survey of State Laws 2020”, available at: https://prsindia.org/policy/
analytical-reports/annual-review-of-state-laws-2020 (last visited on March 5, 2022).
The number dropped to 18 in 2016, when the Assembly met only twice, as opposed to the usual three sessions a year.
AP Legislature, Assembly Statistics, available at: https://www.aplegislature.org/web/aplegislature/statistics (last visited on
March 5, 2022).
AP Legislature, Working Analysis of the XV AP Legislative Assembly, available at: https://legislation.aplegislature.org/
PreviewPage.do?filePath=basePath&fileName=WorkingAnalysis/Assembly/Workinganalysis_Assembly_18_1.pdf (last visited
on March 5, 2022).
Andhra Pradesh

1

<!-- page 4 -->

Despite the lacklustre performance of the Assembly in terms of time spent in session, its legislative
output remained on par with non-pandemic years6 and well above the national average for 2020.7 The
Assembly passed 33 bills over the year, of which four were appropriation bills. Most bills received scant
debate in the Assembly, with 16 being passed on the day they were introduced, 13 on the next day and
four taking between three to four days to be passed. Three, out of the 29 substantive bills passed, were
reserved by the governor for the president’s assent. Of these, the president has withheld his assent to
two. As a consequence, two bills passed by the Assembly in 2020 have yet to come into force; two came
into force in 2021, and the remaining 29, in 2020. In addition, 16 bills passed in 2019 came into force
in 2020.
Amongst the 29 bills passed (excluding appropriation bills) one sought to repeal an existing statute, 19
were amendments to Acts and nine were new laws. Four of the bills passed in 2019 which came into
force in 2020 were new statutes on the book while the remaining 12 amended existing legislations.
Interestingly, a significant number of the bills passed through the year started out as ordinances. While
between 2017 and 2019, the average number of ordinances promulgated hovered between five and six,
in 2020, the number tripled to 17. All but one (which was struck down by the AP high court)8 were laid
before the Assembly per procedure and none were re-promulgated, with the possible exception of one.9
Fifteen of these ordinances are now state statutes.10 Alongside its legislative business, the Assembly
also adopted five resolutions through the year, most of which had substantive bearing on questions of
institutional independence both within the state and in the federal setup.

A Note on the Legislative Council
Andhra Pradesh has a bi-cameral system, yet this discussion of AP’s legislative activity concentrates on
the functioning of the Assembly. This is because 2020 was a tumultuous year for the legislative council,
with the Assembly resolving to have it dissolved early in the year.11 While the Council continued to sit—
it met for nine days in 2020, down from 23 in 201912—its role and function was mired in controversy.
This paper will, therefore, focus on the actions of the Assembly, except in contexts where it came into
conflict with the Council (where it will discuss both).

6.

Thirty-nine bills were passed in 2017; 25, in 2018 (when only two sessions were held) and in 2019, the TDP government
passed 20 Bills, followed by 41 by the new YSRCP government. The average number of bills passed between 2014 and 2019
(the five-year term of the XIV Assembly) was 26.6.
7. The average excluding appropriation bills for the 19 states surveyed by PRS in 2020 was 22 bills. See Anoop Ramakrishnan
and N R Akhil, “Annual Survey of State Laws 2020”, available at: https://prsindia.org/policy/analytical-reports/annualreview-of-state-laws-2020 (last visited on March 5, 2022).
8. The Andhra Pradesh Panchayat Raj (Second Amendment) Ordinance, 2020 (Ordinance 5 of 2020) struck down by the AP
HC in N Ramesh Kumar v. State of Andhra Pradesh, WP No 8163 of 2020 decided on May 29, 2020.
9. The Andhra Pradesh Panchayat Raj (Amendment) Second Ordinance, 2020 (Ordinance 6 of 2020) was possibly a repromulgation of the Andhra Pradesh Panchayat Raj (Amendment) Ordinance, 2020 (Ordinance 2 of 2020) after the first
session of the year, but the text of the ordinance is unavailable. Nonetheless, it was laid before the Assembly in November
2020 along with the others that were promulgated in the interim.
10. Thirteen came into force in 2020, two in 2021.
11. AP Legislature, Resolution on Abolition of Legislative Council, Jan. 27, 2020.
12. AP Legislature, Council Statistics, available at: https://www.aplegislature.org/web/aplegislature/statistics (last visited on
March 5, 2022).
2

The Annual Survey of State Laws in India

<!-- page 5 -->

Legislative Activity Classified Thematically
The graph below breaks down the legislative output of the state into nine broad categories. The
ordinances promulgated are absent because they were mostly absorbed into legislation within the year,
thus their inclusion would double numbers and render analysis inaccurate. However, it must be noted
that four ordinances of the 17 promulgated were not enacted as statutes within 2020. All four of these
were amendments to statutes on local self-government.13
The following segment discusses in some detail the bills that were passed in the Assembly in 2020; the
16 bills passed in 2019 which came into force in 2020 are not the focus of analysis here. Legislative
decisions that were the subject of significant contestation or controversy are discussed in greater depth
in the next section.
Thematic Division of Legislative Activity
10
9
8
7
6
5
4
3
2
1
0
Agri/Aquaculture
& Animal
Husbandry

Crime

Education Finance/Revenue

Land

Bills passed in 2020 that came into force later/are yet to come into force

Local
Religious
Government Establishments

Rights

State Governance

Acts that were passed in 2020 and came into force in 2020

Acts that were passed in 2019 and came into force in 2020

State Revenue/Finance
Given that the pandemic put state finances under great stress, it comes as no surprise that the
maximum number of legislations enacted through the year were to do with taxation and revenue. The
AP Goods and Services Tax Act, 2017 was amended on the basis of recommendations of the thirty
eighth GST Council meeting in December 2019.14 The amendment introduced flexibility in compliance

13. The Andhra Pradesh Panchayat Raj (Amendment) Ordinance, 2020 (Ordinance 2 of 2020); the Andhra Pradesh Panchayat
Raj (Second Amendment) Ordinance, 2020 (Ordinance 5 of 2020); the Andhra Pradesh Panchayat Raj (Amendment)
Second Ordinance, 2020 (Ordinance 6 of 2020); the Andhra Pradesh Municipal Laws (Third Amendment) Ordinance, 2020
(Ordinance 17 of 2020).
14. The Andhra Pradesh Goods and Services Tax (Amendment) Act, 2020 (Act 22 of 2020).
Andhra Pradesh

3

<!-- page 6 -->

requirements, made exceptions to accommodate the problems caused by the COVID lockdown and
brought the AP statute in line with the already amended union Act.15
To make up for shortfalls in tax collection and the stress on the exchequer on account of unprecedented
public health spending, states demanded and were permitted an additional borrowing space of two
percent over the normal limit of three percent of Gross State Domestic Product for the year, subject to
the required statutory amendments being made. The AP Fiscal Responsibility and Budget Management
(Amendment) Act, 202016 was enacted towards this end. It must be noted, however, that only half of
this additional two percent is unconditional,17 while the remainder is contingent on ‘reforms’ brought in
by the state in matters relating to the “universalisation of ‘One Nation One Ration card’, Ease of Doing
Business, Power distribution and Urban Local Body revenues.”18 This is in keeping with a long history
of the union government using the financial route to make incursions into state law and policy, with the
Jawaharlal Nehru National Urban Renewal Mission being the most striking example in the recent past.19
In addition, three amendments were brought to AP Value Added Tax Act, 2005, increasing taxes on petrol
and diesel,20 revising tax rates on natural gas,21 and introducing a road development cess.22 While the
first amendment was supported by the Council, it rejected the second and third amendments. They were
enacted nonetheless per article 198 of the Constitution which limits the powers of the Council in relation
to money bills.23 Another amendment enacted to increase state revenue in a trying time, also rejected
by the Council, was the AP Tax on Professions, Trades, Callings and Employments (Amendment) Act,
2020.24 Noting that the professional tax collected had dropped 21.37 percent between 2019-2020, leading
to an impact on disbursement of funds to local government under the Act, the amendment rationalised
professional taxes within the constitutionally mandated ceiling limit of INR 2500 per annum.
An amendment to the AP Electricity Duty Act, 1939 was passed25 to update its definition of a licensee,
which was based on the Indian Electricity Act, 1910 and had not been updated in accordance with the
Electricity Act of 2003. It also sought to give the government the power to revise the rate of duty based
15. The Finance Act, 2020 (Act 12 of 2020).
16. Act 34 of 2020.
17. The original scheme announced had only 0.5 percent unconditional. The union government changed it to one percent
vide Press Information Bureau, “Borrowing options to meet the GST Compensation requirement for 2020-21”, Ministry
of Finance, Aug. 29, 2020, available at: https://pib.gov.in/PressReleaseIframePage.aspx?PRID=1649485 (last visited on
March 5, 2022).
18. Press Information Bureau, “Finance Minister announces Government Reforms and Enablers across Seven Sectors under
Aatma Nirbhar Bharat Abhiyaan”, Ministry of Finance, May 17, 2020, available at: https://pib.gov.in/PressReleasePage.
aspx?PRID=1624661 (last visited on March 5, 2022).
19. Anindita Mukherjee, The Legal Right to Housing in India 66‑67 (Cambridge University Press, New Delhi, 2019). The AP
government seemed to be unperturbed by this turn of affairs, however. It undertook the required ‘reforms’ with alacrity,
becoming the first state to be eligible for additional borrowing. Bureau, “With second set of reforms, AP becomes first
State to be eligible for 0.5% additional borrowing”, The Hindu Business Line, Oct. 02, 2020, available at: https://www.
thehindubusinessline.com/economy/with-second-set-of-reforms-ap-becomes-first-state-to-be-eligible-for-05-additionalborrowing/article32751233.ece (last visited on March 5, 2022).
20. The Andhra Pradesh Value Added Tax (Amendment) Act, 2020 (Act 23 of 2020).
21. The Andhra Pradesh Value Added Tax (Third Amendment) Act, 2020 (Act 41 of 2020).
22. The Andhra Pradesh Value Added Tax (Amendment) Ordinance, 2020 (Ordinance 12 of 2020) repealed and replaced by the
Andhra Pradesh Value Added Tax (Second Amendment) Act, 2020 (Act 40 of 2020).
23. The Constitution of India, 1950, art. 198(5).
24. Act 42 of 2020.
25. The Andhra Pradesh Electricity Duty (Amendment)Bill, 2020 (LA Bill 30 of 2021).
4

The Annual Survey of State Laws in India

<!-- page 7 -->

on current consumption charges as is the practice in Maharashtra, Karnataka, West Bengal, Kerala etc.,
instead of the flat rate of six paise that had been in place since 1994. The bill was reserved for president’s
assent by the governor, since it dealt with a subject in the concurrent list.26

Agri/Aquaculture and Animal Husbandry
The state passed five legislations relating to agriculture, aquaculture and animal husbandry. This was
amongst the areas in which several new statutes were enacted (as opposed to amendments). Andhra
Pradesh currently leads the country in terms of coastal and freshwater aquaculture and efforts are on
to improve its marine fishing industry.27 Three statutes were enacted towards tapping into the economic
potential of aquaculture in the state as well as organising the industry and regulating quality within
it. The AP State Aquaculture Development Authority Act, 202028 was passed as the framework statute
to achieve this end. In order to do so, it creates a nodal authority alongside a licensing system and a
grievance redressal system. The AP Aquaculture Seed (Quality Control) Act, 2006 was accordingly
amended29 to mandate accreditation and licensing of hatcheries in the state in order to avoid inbreeding and low-quality seed production. The AP Fish Feed (Quality Control) Act, 202030 was passed
to regulate the INR 17000 crore fish feed industry and control spurious practices. A similar law was
also passed to regulate and lay down minimum standards for the animal feed industry.31
In December, Andhra Pradesh became the first state in the country to put in place a State Agricultural
Council32 along the lines of governing bodies for other professions like medicine and nursing. The
Council is to regulate agricultural and horticultural education in the state, maintain professional
standards, and streamline research and development.

Crime
Continuing from decisions made in 2019, when the government was elected to power, the state
amended both the AP Excise Act, 196833 and the AP Prohibition Act, 199534 to include offences of
bootlegging, conspiracy, etc. and give statutory legitimacy to the Special Enforcement Directorate set
up towards bringing in gradual prohibition in the state. The move is said to have had mixed results
(alongside the implementation of a prohibition tax and a steep increase in prices) with smuggling
becoming rampant,35 and prices being forced down after a few months of implementation.36
26. It received the President’s assent and came into force in 2021 (Act 10 of 2021).
27. S Guru Srikanth, “New harbours to put Andhra Pradesh on top in marine fishing”, The New Indian Express, Nov. 23, 2020.
28. Act 29 of 2020.
29. The Andhra Pradesh Aquaculture Seed (Quality Control) (Amendment) Ordinance, 2020 (Ordinance 10 of 2020) repealed
and replaced by the Andhra Pradesh Aquaculture Seed (Quality Control) (Amendment) Act, 2020 (Act 36 of 2020).
30. The Andhra Pradesh Fish Feed (Quality Control) Ordinance, 2020 (Ordinance 7 of 2020) repealed and replaced by Act 35
of 2020.
31. The Andhra Pradesh Animal Feed (Regulation of Manufacture, Quality Control, Sale and Distribution) Act, 2020 (Act 37 of
2020).
32. The Andhra Pradesh State Agricultural Council Act, 2020 (Act 38 of 2020); Staff reporter, “State takes the lead in setting up
Agricultural Council”, The Hindu, Dec. 3, 2020.
33. The Andhra Pradesh Excise (Amendment) Act, 2020 (Act 17 of 2020).
34. The Andhra Pradesh Prohibition (Amendment) Act, 2020 (Act 18 of 2020).
35. Sreenivas Janyala, “Andhra Pradesh: Illegal liquor trade on a high after prohibition, over 43,000 held in 3 months”, The Indian
Express, Aug. 31, 2020.
36. Srinivasa Rao Apparasu, “Jagan’s policy of phased liquor prohibition goes for toss, prices drop to prevent smuggling”,
Hindustan Times, Oct. 30, 2020.
Andhra Pradesh

5

<!-- page 8 -->

Responding to suicides amongst young people in the country who found themselves addicted to, or at
the losing end of online gambling portals,37 the government also amended the AP Gaming Act, 1974 to
criminalise online gaming portals that allow for betting and gambling.38 In addition, the government
wrote to the union government asking it to block 132 apps identified as being platforms for the same.39
The move was later emulated by the Tamil Nadu government. While the concern in relation to addiction
and loss of money is real, the autocratic route of banning internet applications continues a troubling
trend in Indian internet governance.

Land
The AP Assembly passed three bills relating to land and immovable property in the year. The AP
Assigned Lands (Prohibition of Transfers) (Amendment) Act, 202040 carved out an exception to the
prohibition of transfer of assigned lands in cases where the land is being acquired by the Andhra
Pradesh Green Energy Corporation (APGECL). This is another significant step in the dilution of
the statute, once created to prevent the acquisition of assigned lands, held by small and marginal
farmers, by government and private entities.41 At the same time, the state enacted an amendment
to the AP Agricultural Land (Conversion for Non-Agricultural Purposes) Act, 200642 allowing for
the reconversion of land acquired by the APGECL for solar power plants to agricultural land. While
neither bill saw any sustained opposition and they were passed quickly by the legislative council too,
their simultaneous passage, despite seeming to be at cross-purposes, merits some interrogation. It is
unclear from the Amending Act, for instance, as to who would own the reconverted agricultural land.
Since the YSRCP came to power in 2019, resurveying land across the state and streamlining the
registration of immovable property and titling process has been squarely on their agenda. The AP
Land Titling Bill, 201943 was introduced and passed by both Houses, only for the president to withhold
his assent. In 2020, the bill with some amendments was passed again.44 The governor referred it to
the president a second time, and as yet it has not received the president’s assent. The ostensible legal
reason behind this is the fact that the statute seeks to create an independent dispute resolution system
for title related disputes, not bound by the civil procedure code and outside the jurisdiction of civil
courts.45 The opposition leaders have argued that the resurveying effort is futile, it has been attempted
37. Press Trust of India, “Andhra Pradesh Passes Gaming Amendment Bill To Ban Online Games”, NDTV, Dec. 02, 2020, available at:
https://www.ndtv.com/india-news/andhra-pradesh-passes-gaming-amendment-bill-to-ban-online-gaming-2332856 (last
visited on March 5, 2022); Jasvinder Sidhu, “IPL’s Dark Side: A Rise in Suicide Cases Has Greeted the Return of Live
Cricket on TV”, The Wire, Oct. 23, 2020, available at: https://thewire.in/sport/ipl-betting-suicide-cricket (last visited on
March 5, 2022).
38. The Andhra Pradesh Gaming (Amendment) Act, 2020 (Act 43 of 2020).
39. Press Trust of India, “Andhra Pradesh Bans Online Gaming, Betting; Asks Centre to Block Access to 132 Apps in State”,
The Wire, Oct. 30, 2020, available at: https://thewire.in/tech/andhra-pradesh-ban-online-gaming-betting (last visited on
March 5, 2022).
40. The Andhra Pradesh Assigned Lands (Prohibition of Transfers) (Amendment) Ordinance, 2020 (Ordinance 11 of 2020)
repealed and replaced by the Andhra Pradesh Assigned Lands (Prohibition of Transfers) (Amendment) Act, 2020 (Act
31 of 2020).
41. K Balagopal, “Land Unrest in Andhra Pradesh-I: Ceiling Surpluses and Public Lands” 42(38) Economic and Political Weekly
3829-3833 (2007).
42. The Andhra Pradesh Agricultural Land (Conversion for Non-Agricultural Purposes) (Amendment) Ordinance, 2020
(Ordinance 8 of 2020) repealed by Act 32 of 2020.
43. LA Bill 38 of 2019.
44. The Andhra Pradesh Land Titling Bill, 2020 (LA Bill 32 of 2020).
45. The AP Land Titling Bill, 2020, ss. 40, 41.
6

The Annual Survey of State Laws in India

<!-- page 9 -->

by previous governments to no avail, and that the bill should be withdrawn by the government.46 The
second iteration of the bill as introduced in 2020 is not accompanied by a statement of objects and
reasons, but the 2019 draft makes its worrisome agenda quite clear:
“In the present system of Deed Registration, documents relating to immovable property
transactions are registered under the Registration Act, 1908, without any title verification.
With India’s rapid movement into the technological age, there is every need to introduce title
registration system, which gives scope for growth in Land market with reduced litigation in
courts and to ensure maximum utilization of land as a resource.”47
The fact that a state with a significant adivasi population should seek to adopt this de Soto48 inspired
neo-liberal approach to land as a market commodity is disquieting. It ignores entirely the impact of
easy access to title transfer on small and marginal holders of land whose bargaining power before large
corporations or deep pockets is deeply unequal.49 An alternate imagination for security of tenure, which
does not buy so uncritically into illusory promises of a historically unfree free-market is necessary,
especially for a government that seems to wish to portray itself as aligned with the interests of the most
marginalised and impoverished communities in its state.

Education
In 2019, the government enacted the AP Higher Education Regulatory and Monitoring Commission
Act.50 It made news for its executive orders to make all government schools English medium51 and
rationalise fee structures in higher education institutions. These orders were challenged before the
AP high court, as they came mid-year and had several contradictory provisions. Private engineering
colleges went to court to protest against the alteration in the fee structure, while the government
maintained that all it had done was prevent the heavy profiteering by said colleges.52 In 2020, the
government brought a retrospective amendment to the Act.53 The amendment delineated the powers
of the Commission (especially in relation to private and deemed universities) more clearly, alongside
several other minor linguistic changes to clarify the intent of the statute. The most significant reason for
its retrospectivity, however, was to validate the fee structure fixed by the Commission for the year 20192020 (which the Court had suspended in its interim order). The government justified the retrospective
amendment on the grounds that it was both in the interest of students and in public interest. The
petition by the private engineering colleges was subsequently withdrawn.
Buttressing the impetus that the government wishes to give to the aquaculture industry in the state, the
AP Fisheries University Act, 202054 was also passed to structure research and education in the subject.

46. “Atchannaidu urges Jagan govt in Assembly to withdraw AP Land Titling Bill”, available at: https://www.ap7am.com/lv340544-atchannaidu-urges-jagan-govt-in-assembly-to-withdraw-ap-land-titling-bill (last visited on March 5, 2022).
47. The Andhra Pradesh Land Titling Bill, 2020, Statement of Objects and Reasons.
48. Hernando de Soto, The mystery of capital: Why capitalism triumphs in the West and fails everywhere else (Basic Books, 2000).
49. Olivier De Schutter, “The Role of Property Rights in the Debate on Large-Scale Land Acquisitions”, in Christophe Gironde,
Christophe Golay, et. al. (eds.), Large-Scale Land Acquisitions: Focus on South-East Asia 53-80 (Brill Nijhoff, 2016).
50. Act 20 of 2019.
51. G.O.Ms. No.85, SE (Prog.I) Dept. dated Nov. 20, 2019.
52. See order dated May 7, 2020 in WP No. 8266 of 2020.
53. The Andhra Pradesh Higher Education Regulatory and Monitoring Commission (Amendment) Act, 2020 (Act 16 of 2020).
54. Act 39 of 2020.
Andhra Pradesh

7

<!-- page 10 -->

Religious Establishments
The state passed two strangely pacificatory amendments to the AP Charitable and Hindu Religious
Institutions and Endowments Act, 1987 in 2020. The first55 exempted eight prominent Hindu temples
from the application procedure for the appointment of trustees on the grounds that the process
kept “truly deserving prominent pious persons, donors, etc.” from being appointed.56 The second
amendment57 restored the hereditary rights (which the original statute abolished) of the Sannidhi
Yadava community in relation to the Tirumala Tirupati Devasthanams.

A Note on Statutes Passed in 2019 that Came into Force in 2020
Since the Andhra Pradesh Assembly went to polls in 2019, a significant chunk of the legislative activity
of the newly elected government happened in the latter half of the year, leading to 16 statutes passed
in 2019 coming into force in 2020. Of these, five were to do with the educational reforms that the
government was keen to bring in, two each to do with revenue, agri/aquaculture and crime (relating to
the phased prohibition agenda). There was also an amendment to the Co-operative Societies Act, 1964
to delete the provision that barred “a deaf-mute or a leper” from being part of committees under the
statute. The AP State Commission for Scheduled Tribes Bill, which had been reserved for the president’s
assent received it only in 2020.58

Contentious Decisions
Trifurcation of the Capital
The bifurcation of the erstwhile state of Andhra Pradesh left the newly formed state with no capital city.
The first Chief Minister, Chandrababu Naidu, embarked on an ambitious and sharply criticised project
to build a world-class capital in Amravati. In order to do so, the AP Capital Region Development
Authority Act was enacted in 2014,59 and a land pooling scheme put in place through which farmers
would trade in their agricultural land for the promise of a developed (smaller) plot in the capital city
and an annual rent for a decade.60 Many farmers did so willingly, others were forced to when their
challenge to the scheme failed in the courts.61 However, on being elected into power in 2019, the YSRCP
seemed to have different plans. The first two bills tabled in the Assembly in 2020 were to repeal the AP
Capital Region Development Authority Act,62 and to put in place a decentralised, trifurcated capital
55. The Andhra Pradesh Charitable and Hindu Religious Institutions and Endowments (Amendment) Ordinance, 2020
(Ordinance 1 of 2020) repealed and replaced by the Andhra Pradesh Charitable and Hindu Religious Institutions and
Endowments (Amendment) Act, 2020 (Act 25 of 2020).
56. The Andhra Pradesh Charitable and Hindu Religious Institutions and Endowments (Amendment) Bill, 2020 (LA Bill 3 of
2020), Statement of Objects and Reasons.
57. The Andhra Pradesh Charitable and Hindu Religious Institutions and Endowments (Second Amendment) Act, 2020 (Act
26 of 2020).
58. Its counterpart statute for Scheduled Castes took longer, and received the President’s assent in 2021. With this, the
Commissions stand bifurcated, in line with the National Commissions.
59. Act 11 of 2014.
60. The Andhra Pradesh Capital City Land Pooling Scheme (Formulation and Implementation) Rules 2015 issued in G.O.Ms.
No.1, Municipal Administration & Urban Development (M2) Department, dated Jan. 1, 2015.
61. Sruthisagar Yamunan, “They gave up farmland for new Andhra capital. Now they are crippled with uncertainty” available at:
https://scroll.in/article/951454/they-gave-up-farmland-for-new-andhra-capital-now-they-are-crippled-with-uncertainty
(last visited on March 5, 2022).
62. The Andhra Pradesh Capital Region Development Authority Repeal Bill, 2020 (LA Bill 2 of 2020).
8

The Annual Survey of State Laws in India

<!-- page 11 -->

with the legislature, executive and judiciary sitting in different cities.63 The stated reason for the same
was to avoid the creation of a ‘honeypot’ city and to decentralise development in the state.64 Two days
later, the Assembly also passed a resolution on the basis of a cabinet sub-committee’s report, initiating
an investigation into insider trading in land in Amravati.65 The report noted that over 4000 acres of
land had been bought by private individuals and associations prior to the announcement that Amravati
was to be the next capital. In the FIR that ensued, family members of a sitting judge of the supreme
court were mentioned,66 and the AP government alleged that the courts were making it impossible for
the state machinery to function on account of powerful vested interests.67
The legislative council, in which the YSRCP does not have a majority, opposed the two bills. In response
to this opposition, the Assembly resolved to abolish the Council altogether.68 In the meantime, farmers
who had given up their lands willingly took up an agitation against the government decision since the
trifurcation would necessarily reduce the scale of development planned at Amravati and put them at a
disadvantage.69 In May 2020, the two bills were reintroduced and deemed to be passed by the legislative
council since it was the second time they had been introduced and passed by the Assembly.70 They
received the governor’s assent on July 31, 202071 amidst wide-spread protest and while the high court
was already hearing petitions against the proposal.72
The episode raised many important questions about urban planning practices, new forms of land
acquisition that bypass compensation and consent requirements, and the degree to which new
governments are bound by the decisions of their predecessors. It also raises institutional questions in
terms of independence of and from the judiciary and the function of bi-cameral legislatures in states,
given the significantly lesser powers of the legislative council within the constitutional scheme.

Amendments to Local Self-Government Laws
Of the 17 ordinances promulgated in 2020, six were amendments to laws relating to municipal
corporations and panchayats. The relatively uncontroversial ones sought to increase property tax in
line with that in neighbouring states,73 increase the powers and responsibilities of panchayats74 and
63. The Andhra Pradesh Decentralisation and Inclusive Development of All Regions Bill, 2020 (LA Bill 1 of 2020).
64. The Andhra Pradesh Capital Region Development Authority Repeal Bill, 2020 (LA Bill 2 of 2020), Statement of Objects
and Reasons.
65. AP Legislative Assembly, Resolution on Insider Trading, Jan. 22, 2020.
66. The Wire Staff, “Andhra Land Scam FIR Names Daughters of Supreme Court Judge”, The Wire, Nov. 25, 2020, available at:
https://thewire.in/government/andhra-land-scam-fir-supreme-court-judge-amaravati (last visited on March 5, 2022).
67. Scroll Staff, “Andhra Pradesh CM writes to CJI, alleges SC judge NV Ramana influencing High Court”, available at: https://
scroll.in/latest/975492/andhra-pradesh-cm-writes-to-cji-alleges-sc-judge-nv-ramana-influencing-high-court (last visited
on March 5, 2022).
68. AP Legislature, Resolution on Abolition of Legislative Council, Jan. 27, 2020.
69. Supra note 61.
70. The Constitution of India, 1950, art. 197(2).
71. The Andhra Pradesh Capital Region Development Authority Repeal Act, 2020 (Act 27 of 2020); the Andhra Pradesh
Decentralisation and Inclusive Development of All Regions Act (Act 28 of 2020).
72. By the end of 2021, the government agreed to re-examine the issue, but the court chose to rule on legislative competence
nonetheless. In March 2022, the court held that the government was bound by the original plan, and could not go ahead with
the move to trifurcate. The Assembly also resolved to withdraw its earlier resolution seeking the abolition of the legislative
Council, since the Union government had not taken necessary action in over a year and half, leaving the House in a state of
disarray, essentially bringing things back to square one.
73. The Andhra Pradesh Municipal Laws (Second Amendment) Ordinance, 2020 (Ordinance 16 of 2020).
74. The Andhra Pradesh Panchayat Raj (Amendment) Ordinance, 2020 (Ordinance 2 of 2020).
Andhra Pradesh

9

<!-- page 12 -->

municipal corporations,75 alter administrative boundaries of urban local bodies76 and alter timelines
for elections to local bodies.77 These were absorbed into legislation in 2020 and 2021.
The Andhra Pradesh Panchayat Raj (Second Amendment) Ordinance, 2020,78 however, came under
intense scrutiny for enacting what seems like political vendetta through the law. The Amendment
altered the terms of office of the State Election Commissioner (SEC), reducing their term to three years
from five, and requiring the SEC to be retired judge of a high court. Most significantly, the ordinance
abruptly ended the term of the (then) current SEC with immediate effect. This came hot on the heels of
the state government locking horns with the Election Commission over its move to postpone elections
to local bodies.79 The ordinance was challenged before the AP high court and struck down80 on the
grounds that it ran afoul article 243K (2) which states:
“Subject to the provisions of any law made by the Legislature of a State the conditions of service
and tenure of office of the State Election Commissioner shall be such as the Governor may
by rule determine: Provided that the State Election Commissioner shall not be removed from
his office except in like manner and on the like ground as a Judge of a High Court and the
conditions of service of the State Election Commissioner shall not be varied to his disadvantage
after his appointment”81
In this case, the HC held, that the ordinance amounted to unauthorised removal from office and that
the term ‘conditions of service and tenure of office’ does not include pre-conditions for appointment.
As a consequence, the SEC was reinstated. However, despite the SEC’s earlier position in favour of
postponement, elections to local bodies were subsequently held.

Disha Act
The rape and murder of a young veterinarian in Hyderabad in November 2019 shook the collective
conscience of the nation, leading to the custodial murder of four ‘accused’ by the Telangana police82 and
a knee-jerk legislative response by the Andhra Pradesh government. The AP government introduced two
bills on this front: the first, an amendment to criminal laws mandating death sentence for particular kinds
of offences against women and children;83 and the second, a statute to create exclusive special courts for
speedy trial of specified offences against women and children.84 The president withheld assent to the latter,

75. The Andhra Pradesh Municipal Laws (Amendment) Ordinance, 2020 (Ordinance 3 of 2020).
76. The Andhra Pradesh Municipal Laws (Third Amendment) Ordinance, 2020 (Ordinance 17 of 2020).
77. The Andhra Pradesh Panchayat Raj (Amendment) Ordinance, 2020 (Ordinance 2 of 2020); the Andhra Pradesh Municipal
Laws (Amendment) Ordinance, 2020 (Ordinance 3 of 2020).
78. Ordinance 5 of 2020.
79. Gali Nagaraja, “Jagan Govt Promulgates Ordinance to Remove State’s Election Commissioner”, The Wire, April 11, 2020,
available at: https://thewire.in/government/andhra-pradesh-ramesh-kumar-state-election-commissioner (last visited on
March 5, 2022).
80. N Ramesh Kumar v. State of Andhra Pradesh, WP No 8163 of 2020 decided on May 29, 2020.
81. The Constitution of India, 1950, art. 243K.
82. Marri Ramu, “Probe into Disha case encounter begins”, The Hindu, Feb. 3, 2020.
83. The Andhra Pradesh Disha Bill - Criminal Law (Andhra Pradesh Amendment) Bill, 2019 (LA Bill 47 of 2019).
84. The Andhra Pradesh Disha Bill - Andhra Pradesh Special Courts for Specified Offences against Women and Children Bill,
2019 (LA Bill 46 of 2019).
10

The Annual Survey of State Laws in India

<!-- page 13 -->

leading to it being withdrawn and reintroduced in 202085 with alterations recommended by the government
of India. This bill too has been reserved by the governor for the president’s consent, which is pending.
Though the focus has been on the speedy trial statute, the mandatory death penalty response to any
incidence of gruesome violence remains both counterproductive and troubling.86 As per the records
on the AP Legislature website, the AP Disha Bill - Criminal Law (Andhra Pradesh Amendment) Bill,
2019 has been passed by both Houses but has not yet come in force. The government must be called on
to expressly withdraw it.

Resolution against NPR
In an act of federal assertion, the Assembly moved a resolution87 to ask the central government to revert
to the 2010 format of data collection for the census, since the addition of new columns pertaining to
parents’ place of birth, mother-tongue etc. is causing “fear, apprehensions and insecurities in the minds
of the people of Andhra Pradesh” and has “led to unnecessary confusion and lack of trust among the
public to the extent of impinging on public order.” The House also expressly reiterated its “principled
stance against the National Register of Citizens (NRC).”

A Note on Access to Information
Since coming to power, the current AP government has taken a public position against making
government decisions (whether legislative or executive) easily accessible online.88 The ostensible
reason for doing this is to avoid ‘frivolous’ public interest litigation that ‘hampers’ the ability of the
government to make decisions. This move from an automated system by which all public government
directives were uploaded directly to a designated website, to a department-based offline system
has significant repercussions for research. For example, the official AP legislature website lists 11
ordinances promulgated in 2020 (without the text of the ordinances being made available), while a
search on the AP Government Order Issue Register (GOIR) shows that 17 were in fact promulgated.
The PDFs associated with the entries on the GOIR are single page documents saying that the ordinance
is appended (but is not). The gazette website does not list any ordinances at all for the period, while
publication in the gazette is mandatory. This method of maintaining data makes research a cat-andmouse game, rendering analysis fraught with the possibility that chunks of data might have been missed
out altogether. Accessing government decisions in their physical form (across different departments)
85. The Andhra Pradesh Disha (Special Courts for Specified Offences against Women and Children) Bill, 2020 (LA Bill 31
of 2020).
86. Sahana Manjesh, “Why The Death Penalty Is Not A Solution To India’s Rape Problem”, available at: https://www.article-14.
com/post/why-the-death-penalty-is-not-a-solution-to-india-s-rape-problem (last visited on March 5, 2022); Jahnavi Sen,
“Seven Reasons Why We Shouldn’t Demand the Death Penalty for Rape”, The Wire, Nov. 25, 2021, available at: https://
thewire.in/women/rape-death-penalty (last visited on March 5, 2022).
87. AP Legislative Assembly, Resolution on National Population Register (NPR), June 17, 2020.
88. “However, with litigants using the GOs to hamper the planning of the state government by challenging them in courts, the
government is said to have taken the decision not to upload the GOs in the portal.
Though the question of transparency is being raised with the move, a senior official told TNIE that the decision will enable
the government to proceed with its planning. “As of now, immediately after GOs are issued, litigants without verifying the
real intentions of the government knock the doors of courts challenging the government attributing their own intentions,
thereby wasting time,” he said.” Express News Service, “Separate records for 3 different series of government orders in
Andhra Pradesh”, The New Indian Express, Aug. 18, 2021.

Andhra Pradesh 11

<!-- page 14 -->

is complex terrain, with variables like identity, political affiliations and the predilections of officials in
charge playing an integral role in whether access is permitted.
In addition, the documents that are in fact uploaded on the AP legislature website are scanned image
files, with parts missing (like the last few lines on several pages). Uploading public documents in this
fashion renders them inaccessible to screen-readers and, hence, is disability unfriendly. In terms of
language too, there is a marked absence of uniformity. Most bills uploaded have Telugu translations
accompanying them, while none of the Acts that were finally passed do. Systematic data archiving
practices that foreground accessibility and accountability must be demanded in relation to public data.
Without this, the maxim ignorantia juris non excusat takes on a sinister tone.

Conclusion
The year 2020 was, in many ways, a year of disasters for Andhra Pradesh. The effect of the pandemic was
compounded by a flood,89 a cyclone,90 an outbreak of a mysterious illness91 and a massive gas leak.92 The
legislative activity of the state does not speak to this reality, however. On the surface, it would seem that
the year was not executive driven, seeing as legislative activity did not flag on account of the reduced
number of sitting hours and the ordinances that were promulgated were also tabled promptly before
the Assembly. But closer analysis shows that the government chose the legislative route primarily in
contexts where on account of either judicial pressure or the requirements of the parent statute, actions
could not be undertaken through executive orders. For example, amendments to taxation and revenue
statutes were made to increase state revenue, but the substance of the pandemic relief work that the
government undertook was transacted entirely through government orders and directives. While this
may seem understandable in the context of an emergency where swift changes in decisions may be
required, it also makes it harder to hold the state to account for its decisions (especially given the
charges of selective release of public information being levelled against it).
In sum, this analysis of the AP government’s legislative practice through 2020 shows a marked absence
of robust democratic engagement, with little productive debate in the Assembly, a strong autocratic
inclination to obscure data and the troublesome tendency to view dissent as an irritant. This is to not
to say that the substance of the government’s interventions was always problematic—indeed, certain
schemes announced were laudable—but, that there persists a distrust of the democratic process as
being an inefficient obstruction to governance, perhaps more so in governments that are elected to
power with absolute majorities.

89. Express News Service, “Flood grips 20 mandals in East and West Godavari districts”, The New Indian Express, Aug. 18, 2020.
90. P Samuel Jonathan, “Cyclone Nivar | Battered fields, shattered dreams in Andhra Pradesh”, The Hindu, Dec. 7, 2020.
91. “Andhra Pradesh: ‘Mystery’ illness puts hundreds in hospital”, available at: https://www.bbc.com/news/world-asiaindia-55209763 (last visited on March 5, 2022).
92. Scroll Staff, “Visakhapatnam: At least 11 dead after gas leak at chemical plant, over 200 hospitalised”, available at: https://
scroll.in/latest/961241/visakhapatnam-at-least-three-dead-after-gas-leak-at-chemical-plant-many-unconscious-sayreports (last visited on March 5, 2022).
12

The Annual Survey of State Laws in India
