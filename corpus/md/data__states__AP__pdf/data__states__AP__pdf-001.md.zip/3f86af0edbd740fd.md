---
doc_id: "3f86af0edbd740fd"
source_url: "https://andhrauniversity.edu.in/syllabus/uploads/Law/R26/Constitutional_Law___Legal_Order..wef..2026-2027.pdf"
ministry: "Andhra University"
title: "View PDF"
date: ""
pages: 45
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "44c943694858db7c"
---

<!-- page 1 -->

LL.M. (2 Years) Program
CONSTITUTIONAL LAW AND LEGAL ORDER
(Program Code: 5-2-01)

(W.E.F. 2026-2027)

Dr. B.R. Ambedkar College of Law
ANDHRA UNIVERSITY
Visakhapatnam - 530 003

1

<!-- page 2 -->

LL.M. (2 Years) Program
CONSTITUTIONAL LAW AND LEGAL ORDER
(Program Code: 5-2-01)

(W.E.F. 2026-2027)
PROGRAM OBJECTIVES:
The 2 Year LL.M. in Constitutional Law and Legal Order is designed to deepen understanding of the
Indian Constitution and its role in shaping the legal and democratic framework of the country. This
course helps students explore key constitutional principles, human rights, federal structure, and the
evolving nature of judicial interpretation. It offers flexibility for students to pursue areas like
constitutional governance, civil liberties, and public interest litigation. Through a blend of theory and
research, students are encouraged to develop a critical perspective on law, justice, and policy making
in India.
PROGRAM OUTCOME:
 Gain deep insight into the structure, values, and functioning of the Indian Constitution.
 Understand the role of the judiciary interpreting and protecting constitutional rights.
 Examine challenges related to governance, equality, secularism, and federalism in a
democratic setup.
 Conduct meaningful research on contemporary constitutional issues affecting society and
governance.
 Develop skills in legal reasoning, rights-based advocacy, constitutional litigation, and public
law research.
ANDHRA UNIVERSITY
REGULATIONS AND SYLLABUS RELATING TO LL.M. DEGREE COURSE
(TWO YEAR) SEMESTER PATTERN
(Effective from the Academic Year 2026‐2027)



Admission: Candidates admitted into 2-year LL.M. course should have;

i.
ii.


Passed the Bachelor of Law Degree examination of this University or
an examination of any other university recognized as equivalent
thereto.
Qualified in the LL.M. Entrance Test conducted in the year for which
the candidate seeks admission.

For the award of LL.M. Degree: A candidate shall be required to have i) received
instruction and training for the prescribed course of study as full-time student for two
academic years, and ii) qualified all the examinations prescribed for the award of the
two Year LL.M. Degree.
2

<!-- page 3 -->



Duration: LL.M. Course has to be pursued in four semesters stretching over two
academic years. Each academic year comprises of two Semesters. Each semester will
be of the duration of 16 weeks.



Medium of Instruction will be in English language.



Attendance: In order to be eligible to take the examination in any subject, candidate is
required to 75% of attendance in each subject which includes lectures, tutorials and
practical training.

If a student for any exceptional reason fails to attend 75% of the classes held in any subject, he/she may
be condoned for the shortage of attendance if the student concerned attended at least 66% of the classes
held in the subject concerned subject to the payment of the fine prescribed from time to time by the
University.
Course Structure & Content: LL.M Course is subject to UGC norms prescribed from time to time.
LL.M Course is to be pursued in a selected branch of specialization offered by the University.
The course consists of 4 compulsory theory papers, one practical examination and dissertation common
to all LL.M students and 6 papers of specialization opted by the candidate.
In the first semester, the candidate has to offer two compulsory theory papers (Compulsory Papers 1&2)
and two Papers from the branch of specialization (Branch Papers.1&2).
In the second semester, the candidate has to offer two compulsory theory papers (Compulsory Papers
3&4) and two Papers from the branch of specialization (Branch papers 3&4).
In the third semester the candidate has to offer two papers exclusively from the selected branch of
specialization (Branch papers 5 & 6) and practical examination comprising of doctrinal work, nondoctrinal work, clinical work and class room teaching. In the fourth semester he/ she has to complete the
dissertation in partial fulfillment of the LL.M degree.
Semester

Compulsory
core paper

Specialization/ Total papers
Branch papers

Marks

Credits

First

2

2

6X4

400

24

Second

2

2

6X4

400

24

1 (Practical)

2

6X3
350

20

MOOCS

1

1
150

14

1300

82

Third
Fourth

Practical
(Dissertation)
Viva
MOOCS

1

1

3

<!-- page 4 -->

Compulsory Papers:

1.
2.
3.
4.
5.

Law and Social Transformation in India
Indian Constitutional Law: The New Challenges
Judicial Process
Legal Education and Research Methodology
Dissertation

Practical Paper with the following components:
Doctrinal Research:
Each student would be assigned in advance a topic and asked to write a doctrinal research paper.
Non-Doctrinal Research:
The student would be asked to go out of the class room and library to make an empirical study of a
problem which has social, economic moral or political dimension. Field data can be collected through any
model of data collection.
Clinical Work:
The modalities can be evolved by the law school. One method is that the legal aid clinic of the law school
can involve itself with other legal aid programmes in the area. Students are encouraged not only to work
with the clinic but also to acquaint themselves with court proceedings, attending Lok Adalat, working of
a business organization, tackling of labour disputes, drafting of business or other deeds and with public
interest litigation. Law Teaching A topic would be assigned to the student in advance. He is required to
handle a class for 25 to 30 minutes, where LL.B. programme co-exists with LL.M. programme, the
students may be asked to teach the LL.B. students.
Proposed change :
MOOCS – Two MOOCS have to be undergone. One in IIIrd Semester & another in IVth Semester. Each
MOOC carries 2 Credits (Max. 50 Marks) for each Semester.
Dissertation:
Dissertation of a minimum length of 120 pages has to be carried by the candidate in the area of his/her
area of specialization in fourth semester. Dissertation shall be evaluated internally and externally through
viva-voce.
Credits:
All papers carry six credits and the dissertation in fourth semester along with VIVA & MOOCs carries 14
credits. Total credits are 82.
Question Paper Pattern:
For semester end written examinations in theory, the question paper carrying 70 marks consists of 9 essay
questions (Nineth question consists of four short notes out of which the candidate may choose any two to
answer). The candidate may choose to write any five questions out of nine questions. Each question
carries 14 marks.
4

<!-- page 5 -->

Marks: Every paper carries 100 marks.
Except for the practical papers, 70 marks are allotted to written examination and 30 marks are allotted to
internal assessment, which split as follows;
i.
ii.
iii.

Class and Seminar Presentation
Assignment
Viva-Voce

-

10 Marks
10 Marks
10 Marks

Practical Examination:
The practical examination consists of 100 Marks shall be held at the end of the third semester on
Research Methodology, Law Teaching and Clinical Work. The marks are allotted as follows.
i.
ii.
iii.
iv.
Examination:

Doctrinal research
Non-doctrinal research
Law teaching
Clinical work

-

25 Marks
25 Marks
25 Marks
25 Marks



Candidate shall take examination in each of the subjects prescribed for study at the end of the
semester by registering for that semester examination and obtaining hall ticket for the same.
Duration of the examination is three hours.



The semester end examination shall be based on the question paper set by an external paper setter.



A candidate will be declared to have passed in the concerned paper if the candidate secures a
minimum of 40% marks. However, for practical papers, a minimum of 50% is essential. The
practical papers of LL.M course are, paper 3 (compulsory practical paper) in the Third semester and
the Dissertation in the Fourth Semester.



For qualifying in the whole examination for obtaining the LL.M degree, the candidate has to secure a
minimum overall aggregate of 50%. The calculation of the aggregate percentage required for
qualifying in the examination would be done only at the end of the completion of the course.



Grafting/Grace is permitted. Grafting allows a candidate an opportunity to utilize the excess marks
he earned in a paper for filling up the shortage of marks in the paper in which the candidate failed.
Eg, A candidate who secured only 35 Marks, would fail having fallen short by 5 Marks of the
required minimum pass mark which is 40 Marks. However, If such candidate happened to secure 45
marks in another paper, the extra five marks which is in excess of what is required for a pass could
be notionally added to fill the deficit of 5 marks of the paper in which the candidate actually failed
and thereby declare the candidate to have been passed in such paper.

Note: Grafting can be availed only when the candidate will be able to pass in the whole examination
due to grafting. Grafting to the extent of one mark per hundred marks of each
semester can be added
to a maximum of two papers only.


0.5 or more will be rounded up to the higher value of 1 only for the purpose of obtaining pass mark
or class elevation, third class to second class or second class to first class. Eg 4.96 will be treated as
5

<!-- page 6 -->

5.0. Similarly, 5.45 becomes 5.5
Scheme of Grading
S.No
1
2
3
4
5
6
7
8
9

Range of Marks
>90 < 100
>80 < 90
>70 < 80
>60 < 70
>55 < 60
>50 < 55
>40 < 50
< 40

Grade
O
A+
A
B+
B
C
P
F

Grade Point
10
9
8
7
6
5
4
0
0

Outstanding
Excellent
Very Good
Good
Above Average
Average
Pass
Fail
Ab (Absent)

Classification of successful candidates is based on CGPA as follows:

 Distinction

---

CGPA 7.0 or more

 I Class

---

CGPA 6.0 or more but less than 7.0

 II Class/Pass

---

CGPA 5.0 or more but less than 6.0

Note:
Only those candidates who appear and pass the examination in all the papers of the First semester, all the
papers of the Second semester, all the papers of the Third semester, and similarly all the papers of the
Fourth semester, at first appearance are eligible to be placed in O grade.
Awards:
No candidate who has not passed all the papers relating to any semester at the first appearance shall be
eligible for the Award of Medals or Prizes by the University and to receive certificates of rank obtained
by them in the examination.
Explanation: Credits, Grade Letter, Grade Points, Credit Points
Credit means the unit by which the course work is measured. One credit means one hour of teaching
work or one hour of practical work per week.
Grade Letter is an index to indicate the performance of a student in a particular course (Paper).
It is the transformation of actual marks secured by a student in a course/paper. It is indicated by a Grade
letter O, A, B, C, D, E. There is a range of marks for each Grade Letter.
Grade Point is Weightage allotted to each grade letter depending on the marks awarded in a course/paper
CGPA: CGPA means Cumulative Grade Point Average. It will be calculated from 2nd semester onwards.
SGPA means Semester Grade Point Average. This is calculated for each semester of the programme.
CGPA x 10 will be the overall percentage of the marks obtained by the candidate
6

<!-- page 7 -->

Revaluation
The candidate has to apply for revaluation on or before 15 days from the date of publication of the
results.
Betterment
A candidate can avail the betterment chances during the validity of all the courses.
General Rules
The candidate who secures less then prescribed SGPA/CGPA may be permitted to appear for the
examination with in the duration of the course or before the expiry of transitory regulations.
Failed candidates will be permitted to appear for the University examinations after the expiry of
transitory regulations as per the existing regulations, scheme and syllabi which are enforce.
Ranks will be given only to the candidates, who have passed all the subjects/papers at a time. However,
Distinction will be given to the candidates, who secure 70% and above , those who have passed all the
subjects / papers at a time.

7

<!-- page 8 -->

Programme Name : Constitutional Law & Legal Order Course
Programme ID: 5-2-01

FIRST SEMESTER:
Sl.
No
1

2

Hours
per week
L T P
4 2
-

Max
Marks
E
I
70
30

4

2

-

70

30

6

Constitutional 4
Law & Legal
Order

2

-

70

30

6

Constitutional 4
Law & Legal
Order

2

-

70

30

6

Paper
No

Title of the Paper

Compuls
TH103101 ory
Paper 01
THCompuls
103102 ory
Paper -02

Law and Social
Transformation in
India

Common
paper

Indian
Constitutional
Law: the New
Challenges
Constitutionalism,
Pluralism and
Federalism

Common
paper

Union- State
Financial
Relations

Course
Code

3

TH103103

Paper- I

4

TH103104

Paper -II

Title of the
Branch

Credits
6

24

SECOND SEMESTER:
Hours
per week
L T P
4 2 -

Max
Marks
E
I
70
30

4

2

-

70

30

6

Constitutional 4
Law & Legal
Order
National
Constitutional 4
Security Public Law & Legal
Order and Rule Order
of Law

2

-

70

30

6

2

-

70

30

6

Sl.
No

Course
Code

Paper
No

1

TH103201

2

TH103202

Compuls
ory
Paper-03
Compuls Legal
Education and
ory
Paper-04 Research
Methodology

3

THPaper -III
103203

4

THPaper- IV
103204

Title
of the
Paper
Judicial Process

Human Rights

Title of the
Branch
Common
paper
Common
paper

Credits
6

24
8

<!-- page 9 -->

THIRD SEMESTER
Sl.
No

Course
Code

Paper No

1

TH103301

Paper -V

Mass Media Law

2

TH103302

Paper -VI

Public Utilities
Laws

Compulsory
Practical

Doctrinal Work,
Law Teaching
Non Doctrinal
Work, Clinical
work,

3

PR3001

Title of the Paper

Hours
Max
per
Marks
week
L T P E
I
70
30
Constitutional 4 2 Law & Legal
Order
Title of the
Branch

Constitutional 4 2 Law & Legal
Order

70

30

12

Credits

6

6

6

MOOCS

2
20

FOURTH SEMESTER:
Sl.
No

Course
Code

Title of the Paper

Max. marks
E

I

Credits

1

DI-2002

Dissertation

2

VV-2002

Viva

50

50

12

MOOCS

--

--

2

TOTAL

14

GRAND TOTAL

82

9

<!-- page 10 -->

FIRST SEMESTER
COURSE CODE : TH-103101
COURSE NAME : LAW AND SOCIAL TRANSFORMATION IN INDIA
Course Objectives:
This course is to be designed to offer (a) awareness of India approaches to social and economic
problems in the context of law s a means of social control and change; and (b) a spirit of inquiry to
explore and exploit law and legal institutions as a means to achieve development within the
framework of law. The endeavour is to make the students aware of the role the law has played and
has to play in the contemporary India society.
Syllabus
1.

Law and social change
Lawas an instrument of social change.
Law as the product of traditions and culture. Criticism and evaluation in the light of
colonization and the introduction of common law system and institutions in India and
its impact on further development of law and legal institutions in India.
Learning outcome :
To provide a comprehensive knowledge of Law as an instrument of social change with
special reference to Indian Constitution.

2.

Religion and the law
Religion as a divisive factor.
Secularism as a solution to the problem.
Reform of the law on secular lines: Problems.
2.1.4 Freedom of religion and non-discrimination on the basis of religion.
Religious minorities and the law
Learning outcome :
To acquaint the students with religion as a divisive factor in society and how to bring reforms
in religion by enacting laws on secular lines.

3.

Language and the law
Language as a divisive factor: formation of linguistic states.
Constitutional guarantees to linguistic minorities.
Language policy and the Constitution: Official language; multi-language system
Non-discrimination on the ground of language
Learning outcome :
Make the students to understand the factors that led to linguistic states and constitutional
guarantees to linguistic minorities.
10

<!-- page 11 -->

4.

Community and the law
Caste as a divisive factor
Non-discrimination on the grounds of caste.
Acceptance of caste as a factor to undo past injustices.
Protective discrimination: Scheduled castes, tribes and backward classes.
Reservation; Statutory Commissions, Statutory provisions.
To create awareness among the students the evils of caste in India society and constitutional
guarantees provided to SSC, ST and BCs.
Learning outcome :

5.

Regionalism and the law
Regionalism as a divisive factor.
Concept of India as one unit.
Right of movement, residence and business; impermissibility of state or regional
barriers.
Equality in matters of employment: the slogan “Sons of the soil” and its practice.
Admission to educational institutions: preference to residents of a state.
Learning outcome :
To acquaint the students the concept of regionalism and role of India Constitution.

6.

Women and the law
Crimes against women.
Gender injustice and its various forms.
Women’s Commission.
Empowerment of women: Constitutional and other legal provisions.
Learning outcome :
To make the students to have a knowledge of the Crimes against women and the role of
International and national agencies in the Protection and Empowerment of Women.

7.

Children and the law
Child labour
Sexual exploitation
Adoption and related problems.
Children and education
Learning outcome :
To make the students to understand the exploration of children in society and the role of law
in protection of their Rights.

8.

Modernisation and the law
Modernisation as a value: Constitutional perspectives reflected in the fundamental
duties.
Modernisation of social institutions through law
Reform of family law
Agrarian reform – Industrialisation of agriculture
11

<!-- page 12 -->

Industrial reform: Free enterprise v. State regulation – Industrialisation
Environmental protection.
Reform of court processes
Criminal law: Plea bargaining; compounding and payment of compensation to victims
Civil law: (ADR) Confrontation v.consensus;mediation and conciliation; Lok adalats
Prison reforms
Democratic decentralization and local self-government
Learning outcome :
To analyse the modern approaches to law and alternative methods of conflict resolution.
9.

Alternative approaches to law
The jurisprudence of Sarvodaya---Gandhiji, Vinoba Bhave;Jayaprakash Narayan--Surrender of dacoits; concept of grama nyayalayas
Socialist thought on law and justice: An enquiry through constitutional debates on the
right to property
Indian Marxist critique of law and justice
Naxalite movement: cause and cure
Learning outcome :
To make the students to understand the jurisprudence of Gandhiji, Vinoba Bhave and the role
of Gram Nayayalayas and a critical analysis of naxal movement in India and steps taken by
the Government to control naxal movement.

Course Ooutcome :
After completion of this course, the student will be able
a) To know how law has changed the society and how there is an improvement in the social
status of women and children because of certain specific legislations in favour of children and
women.
b) To analyse the role of language in interpretation of laws and its importance in statutes.
c) To elucidate the concepts of regionalism and religion as divisive factors in society and how
law effectively control this divisiness.
d) To analyse the challenges that witess in the society in recent times in the areas of social ,
political and economic relations and how far the existing law meet these challenges.
e) To understand the alternative social approaches given by Mahatma Gandhi and Vinoba
Bhave and its impact on the present societal relations.
Select Bibliography
Marc Galanter (ed.), Law and Society in Modern India (1997) Oxford.
Robert Lingat, The Classical Lawof India (1988), Oxford.
U.Baxi, The Crisis of the Indian Legal System (1982). Vikas,New Delhi.
U.Baxi (ed.), Law and Poverty Critical Essays (1988), Tripathi, Bombay.
Manushi, A Jornal about Women and Society.
Duncan Derret, The State, Religion and Law in India (1999). Oxford University Press, New Delhi.
H.M.Seervai, Constitutional Law of India (1996), Tripathi.
D.D. Basu, Shorter Constitution of India (1996), Prentice – Hall of India(P) Ltd., New Delhi.
12

<!-- page 13 -->

Sunil Deshta and Kiran Deshta, Lawand Menace of Child Labour (1997),Sage.
India Law Institute, Law and Social Change: Indo-American Reflections, Tripathi (1988)
J.B.Kripalani, Gandhi: His life and Thought, (1970) Ministry of Information and Broadcasting,
Government of India.
M.P. Jain, Outlines of Indian Legal History, (1993), Tripathi, Bombay
Agnes, Flavia, Lawand Gender Inequality: The Politics of Women’s Rights in India (1999), Oxford.

13

<!-- page 14 -->

COURSE CODE : TH-103102
COURSE NAME : INDIAN CONSTITUTIOAL LAW: THE NEW CHALLNEGES
Course Objectives
The Constitution, a living document, is said to be always in the making. The judicial process of
constitutional interpretation involves a technique of adapting the law to meet changing social mores.
Constitution being the fundamental law, an insight into its new trends is essential for a meaningful
understanding of the legal system and processes. The post graduate students in law who had the basic
knowledge of Indian Constitutional Law at LL.B. level, should be exposed to the new challenges and
perspectives of constitutional development while they are allowed to choose an area of law for
specialization. Obviously, rubrics under this paper require modification and updating from time to
time.
Syllabus
1.
Federalism
Creation of new states
Allocation and share of resources – distribution of grants in aid
The inter-state disputes on resources
Rehabilitation of internally displaced persons.
Centre’s responsibility and internal disturbance within States.
Directions of the Centre to the State under Article 356 and 365.
Federal Comity: Relationship of trust and faith between Centre and State.
Special status of certain States.
Tribal Areas, Scheduled Areas
Learning outcome :
By proper study of this unit, the student will be able to remember about the Federalism, Allocation
and share of resources, the inter-state disputes on resources Centre’s responsibility and internal
disturbance within States and Special status of certain States etc., that are already studied in his LL.B.
Course. By study of this unit, the student will be able to exhibit memory of the previously learned
material by recalling facts terms, basic concepts and answers. He will be able analytically study and
exhibit new thoughts also.
2.
“State”: Need for widening the definition in the wake of liberalization.
Learning outcome :
By proper study of this unit, the student will be able to demonstrate understanding of facts and ideas
by Interpreting giving descriptions and stating main ideas of the need for widening the definition in
the wake of liberalization. By analytically study of this chapter, the student will be able to know that
whether the private undertaking will be coming into the purview of the State.
3.

Right to equality: privatization and its impact on affirmative action.
Learning outcome :

By proper study of these units, the student will be able to understand and solve the problems with
regard to the Right to equality, privatization and its impact on affirmative action, empowerment of
women. By proper study of this unit, the student can be able to solve the problems to new situations
14

<!-- page 15 -->

by applying acquired knowledge and skills of the students are to be improved as their analyzing
capacity will be enhanced. The students will also be able to apply his mind towards the laws which
are enacted for empowerment of women and up to how much the women were secured by study of
the case laws relating to it.
4.

Empowerment of women.
Learning outcome :

By proper study of these units, the student will be able to examine by identifying motives or causes
for the strikes, Hartal, Bundh, Freedom of press and challenges of new scientific development and
whether the wrongful information is given by press and media attracting the defamation, freedom of
speech and right to broadcast and telecast can be liable to be prosecuted on the wrongful information
The students also be able to give guidelines how to solve the problems on this issue.
5.

Freedom of press and challenges of new scientific development Freedom of speech and
right to broadcast and telecast. Right to strikes, hartal and bandh.

Learning outcome :
By proper study of this unit, the student will be able to gather the information, validity of ideas
regarding emerging regime of new rights and remedies, study of Directive Principles and
Fundamental Duties into Fundamental Rights, Compensation jurisprudence, Right to education under
Art 21 A of the Constitution, Commercialization of education and its impact though the Educational
trust of the educational institution is established on non- profit basis and Brain drain by foreign
education market. By proper study of this unit, the skills of the students are to be improved as their
analyzing capacity will be grown up.
6.

Emerging regime of new rights and remedies
Reading Directive Principles and Fundamental Duties into Fundamental Rights
Compensation jurisprudence
Right to education
Commercialization of education and its impact.
Brain drain by foreign education market.

Learning outcome :
By proper study of thes units, the student will be able to compile information together in a
different way by comparing with minority rights with Secularism in a new pattern. The
students also be able to give guidelines how to solve the problems of this issue.
7.
Right of minorities to establish and administer educational institutions and state control.
Learning outcome :
By proper study of this unit, the student will be able to compile information relating to the
Separation of powers: Stresses and strain, Judicial activism and judicial restraint, PIL:
implementation, Appointment, transfer and removal of judges. The students will also be able to judge
that whether collegiums for appointment of judges of High Courts and also the Supreme Court will be
leading to bias, whether Kripark Vs. Union of India case up to how much will be applicable in case of
collegiums. The students also be able to give guidelines how to solve the problems for this issue.
15

<!-- page 16 -->

8.

Secularism and religious fanaticism.

Learning outcome :
By proper study of this unit, the student will be able to compile information relating to the Nexus of
politics with criminals and the business, whether delay in trials on political offenders are justifiable
and Economic offenders are left free is reasonable, why their passports are not ceased, Election
commission, Electoral Reforms, why the candidates with criminal records are given eligibility for
contesting in elections, what is the inner relationship between the election commission and
politicians etc., will be deeply thought by the students. The students also be able to give guidelines
how to solve the problems for this issue.
9.

Separation of powers: Stresses and strain
Judicial activism and judicial restraint.
PIL: implementation.
Judicial independence.
Appointment, transfer and removal of judges.
Accountability: executive and judiciary.
Tribunals
10.
Democratic Process
Nexus of politics with criminals and the business.
Election
Election commission: status.
Electoral Reforms
Coalition government, ‘stability, durability, corrupt practice’
Grass root democracy.
Course outcome:
After studying this paper, the student can






The students will get an idea about the supreme document of India
Every citizen of India must aware the constitution because each and every enactment found its
base in the constitution
Students will have the command on the rights that are given under the constitution
Students can understand why the center and state relations are important in a country like India
Students can be able to know the forms of governments and the features of our Constitution.

Select Bibliography
No specific bibliography is suggested for this course since the course materials obviously depends
upon the latest developments. These developments in the areas specified in the course can be gathered
from the recent materials such as case law, changes and amendments of laws, critical comments,
studies and reports, articles and research paper and lastly contemporary emerging ethos impacting on
constitutional values.

16

<!-- page 17 -->

COURSE CODE : TH-103103
COURSE NAME : CONSTITUTIONALISM: PLURALISM AND FEDERALISM

Course Objectives:
Constitutionalism essentially means a limited government. Where government functions according to
certain principles, it is said to be abiding by constitutionalism. Must it be a democracy or can it be an
autocracy also. In ancient India, the king was supposed to act according to dharma. He was not
absolute in the sense in which John Austin defined sovereignty. Constitutionalism may therefore be
determined by a written constitution or by religion or tradition or by mere practice or convention as in
England. In a plural society, where different religious as well as linguistic groups have to live
together, various rules of accommodation and mutual recognition are incorporated in the Constitution.
Usually these are contained in the bills of rights which contain guarantees of individual liberty and
equality against majoritarian rule. Constitutionalism does not merely imply majoritarian rule, it has to
be a consensual rule. However, where there is not only such vertical pluralism but also horizontal
pluralism reflected by sub nations/regional loyalties, power is not only required to be restrained but it
has to be shared. This calls for a federal government. The purpose of this paper is to provide exposure
to the students to various models of pluralism and forms of constitutional governments and federal
structures.
The following syllabus prepared with this perspective will be spread over a period of one semester.
Syllabus
1.

Constitutionalism
Authoritarianism - Dictatorship
Democracy - Communism.
Limited Government - Concept - Limitations on Government Power.
What is a Constitution?
Development of a democratic government in England - Historical evolution of
constitutional government.
Conventions of constitutionalism – law and conventions
Written constitutions U.S.A., Canada, Australia, Sweden, South Africa and India.
Separation of powers: Montesquieu
Rule of Law: Concept and new horizons
Marxist concept of constitutionalism
Dictatorship of the proletariat.
Communist State from Stalin to Gorbachov.
Fundamental Rights: Human rights
Judicial Review: European Court of Human Rights
Human Rights: International conventions
Limits & doctrine of domestic jurisdiction in international law.

Learning outcomes:


Describes the concept of limited government and with the help of the democratic setup and
also explains the conventions on constitutionalism and significance of written constitution
with comparative study. Elucidate the concept of rule of law with new horizons. And also
discuss about the judicial review.
17

<!-- page 18 -->

2.

Federalism
What is a federal government?
Difference, between confederation and federation
Conditions requisite for federalism.
Patterns of federal government - U.S.A., Australia, Canada, India.
Judicial review - for federal umpiring
New trends in federalism: Co-operative federalism
India - Central Control v. State Autonomy
Political factors influencing federalism
Plural aspects of Indian Federalism: Jammu & Kashmir, Punjab, Assam.
Dynamic of federalism.

Learning outcomes:


3.

Discuss about the federal government with a wide description between confederation and
federation and also explains about the dynamics of federalism. Knowing about the new trends
in federalism in view of the cooperative federalism.
Pluralisms

What is a pluralistic society?
Ethnic, linguistic, cultural, political pluralism
Individual rights - right to dissent
Freedom of speech and expression
Freedom of the press
Freedom of association
Rights to separateness
Freedom of religion
Rights of the religious and linguistic minorities
Compensatory discrimination for backward classes
Women - rights to equality and right to special protection
Scheduled Tribes, Distinct Identity - protection against exploitation - NSIS Exclusion from Hindu Law.
Learning outcomes:


4.

Describes the nature of pluralistic society, in correction with compensatory discrimination for
backward classes and also explains about women rights.
Uniform Civil Code
Non-State law (NSLS) and State Law Systems - Problem of Uniform Code v personal lawsvertical federalism

18

<!-- page 19 -->

Learning outcomes:

5.

Identify the problems of uniform civil code versus personal laws.
Equality in Plural Society.

Right to equality and reasonable classification
Prohibition of discrimination on ground of religion, caste, sex, language.
Abolition of untouchability
Secularism - constitutional principles
Tribal Groups and Equality
Learning outcomes:


6.

Explain about the right to equality and its reasonable classification special reference with
tribal groups and also describes constitutional principles of secularism.
Pluralism and International Concerns
International Declaration of Human Rights
Conventions against genocide
Protection of religious, ethnic and linguistic minorities
State Intervention for protection of human rights
Right of self-determination

Learning outcomes:


Illuminate international conventions on human rights and right of self-determination

Course outcomes:
1. At the end it I expected that the student will be able to understand difference between

constitution and Constitutionalism and how the Indian constitution impose reasonable restrictions
on the governments.
2. To understand India as development of complex federal structure and strengths and its
weaknesses.
3. Explore various functional theories, doctrine and Constitutional principles of federalism and its
interplay under Indian Constitution; and
4. To examine the area of conflicting interest between Union and State and primacy of Union
over the State.
Select bibliography
Upendra Baxi, "Law, Democracy and Human Rights"- 5 Lokayan Bu.lletin 4 (1987)
V.M. Dandekar "Unitary Elements in a Federal Constitution" 22 E.P.W. 1865 (1988)
Rajeev Dhavan, "The Press and the Constitutional Guarantee of Free Speech and Expression" 28,
LLL 299 (1986)
M.A. Fazal"Drafting A British Bill of Rights" 27 J.LLL 423 (1985)
M.P. Jain Indian Constitutional Law (1994), Wadhwa.
Jagat Narain "Judicial Law Making and the Place of the Directive Principles in the Indian
19

<!-- page 20 -->

constitution," J.LLL 198 (1985).
Rhett Ludwikowski, "Judicial Review in the socialist Legal Systems: Current Development" 37
LC.LD. 89-108 (1988)
S.P. Sathe, Fundamental Rights and Amendment of the Indian Constitution, (1968)
H.M. Seervai, Constitutional Law of India (1993), Tripathi, Bomaby.
Students should consult relevant volumes of the Annual Survey of Indian Law published by the
Indian Law Institute.

20

<!-- page 21 -->

COURSE CODE : TH-103103
COURSE NAME : UNION-STATE FINANCIAL RELATIONS

Course Objectives:
The Indian Constitution adopts federal government for various reasons. Power is divided between the
Union and the States in such a way that matters of nationa1 importance are entrusted to the Centre
and matters of local importance are left to the States. The Constitution departs from the model of
classical federalism in many ways. This departure was made to suit the peculiar Indian circumstances.
However, the constitutional provisions were in practice further distorted so as to make the states
totally subservient to the Centre. Distribution of fiscal power is the nerve centre of the federal system.
In this paper a student will be made conscious of various aspects of federal principle, and their
working in the Indian context with a view to ultimately assessing the Indian experience critically. He
must clearly understand various emerging forces such as regionalism, sub-national loyalties and
nationalism. He should be able to see the working of the constitutional process as a vital element of
the political economy.
The following syllabus prepared with this perspective will be spread over a period of one semester.
Syllabus
1. Federalism– Essentials
Models of Federal Government - U.S.A., Australia, Canada
Difference, Between Federation and confederation
Evolution of federal government in India
Learning outcome :
The student will be able to understand about Federalism, different governments of federalism like
USA, Australia, Canada, and difference between federation and confederation, evolution of
federal government in India.

2. Distribution of Legislative Power/Administrative Power
Indian Constitution
Centre- State relations
Factors responsible for subordination of States
Administrative relations
Learning outcome :
Here the student will understand the concept of distribution of administrative powers, center state
relations and the Indian constitutional Law and the factors responsible for subordination of states.

21

<!-- page 22 -->

3. Distribution of Fiscal Power
Scheme of Allocation of taxing power
Extent of Union power of taxation
Residuary power - inclusion of fiscal power
Learning outcome :
In this unit the student learns about power of taxing power, and distribution of Fiscal power.
4. Restrictions of Fiscal Power
Fundamental Rights
Inter-Government tax immunities
Difference between tax and fee
Learning outcome :
This unit makes the student learn inter –Government tax immunities and the difference between tax
and fee.
5. Distribution of Tax Revenues
Tax-Sharing under the Constitution
Finance Commission - Specific purpose grants (Article 282)
Learning outcome :
The student will be able to learn about Tax –sharing under the Constitution, Finance
commission under Article 282.
6. Borrowing Power of the State
Borrowing by the Government of India
Borrowing by the States
Learning outcome :
Here the student learns about borrowing power of the Government of India and borrowing by state
government.
7. Inter-State Trade and Commerce
Freedom of Inter-State trade and commerce
Restrictions on legislative power of the Union and States with regard to trade and commerce
Learning outcome :
22

<!-- page 23 -->

In this unit the student learns about freedom of interstate trade and commerce, restrictions on legislative
power of the union and states regarding to trade and commerce.
8. Planning and Financial Relations
Planning Commission
National Development Council
Plan grants
Learning outcome :
This unit makes the student understand the planning and financial relations of the Government.
9. Co-operative Federalism
Full faith and credit
Inter-State Council
Zonal Councils
Inter-State disputes
Learning outcome :
This unit makes the student understand about co-operative federalism, inter-state council, zonal
councils, and interstate disputes.
10. Federal Government in India
Model of Jammu and Kashmir
Sarkaria Commission Report
What Reforms are Necessary?
Report of the Commission to Review the Working of the Constitution-2002
Report of the Commission of Centre State Relations 2010 (Justice M.M. Punchii Commission).
Learning outcome :
Here the student learns about Federal Government in India, model of Jammu and Kashmir,and Sarkaria
commission Report.
Course outcome:
1. The student will be able to understand federalism, different countries following federal form of
government, difference between federation and confederation, evolution of federal government in
India.
2. The student will have knowledge about the concept of distribution of administrative powers, center
state relations.
3. The student will gain knowledge about taxing power, Government tax immunities and the
difference between tax and fee.
4. Here the student has knowledge about borrowing power of the Government, freedom of interstate
trade and commerce, the planning and financial relations of the Government.
23

<!-- page 24 -->

Select bibliography
H.M. Seervai, Constitutional Lawof India (1991), Tripathi, Bombay.
Sudha Bhatnagar, Union-State Financial Relations and Finance Commissions, (1979)
Ashok Chandra, Federalism in India, (1965)
V.D. Sebastian, Indian Federalism: The Legislative Conflicts Chs. 6-7 and 8 (1980).
Chandrapal, Centre-State Relations and Cooperative Federalism, Chs. 5 and 8 (1983)
G.C.V. Subba Rao, Legislative Powers in Indian Constitution Law, Chs. 37, 38, 39 (1982)
Richard M. Pious, The American Presidency, 293-331, Ch. 9 (1979)
Daniel J. Elazar, American Federalism, Chs. 3 and 4 (1984)
K.P. Krishna Shetty, The Lawof Union-State Relationsand the Indian Federalism Ch.9 (1981)
Report of the Eighth Finance Commission.
Administrative Reforms Commission on Centre-State Relationship Ch. 3 (1969)
Constituent Assembly Debates Vol. 9, 203, 240 and 302-349; Vol. 10, 325-342.
Administrative Reforms Commission, Report of the Study Team on Central-State Relationship (1967)
Vol. 1, Sections land 11, pp. IS- 168
L.M. Singhvi (ed.), Union-State Relations in India 124-154 (19690
Government of Tamilnadu, Report of the Centre-State Relations Inquiry Committee Ch.5 (1971)
D.T. Lakadwala, Union-State Financial Relations (1967)
M.P. Jain, Indian constitutional Law (1994), Wadhwa.
K. Subba Rao, The Indian Federation (1969)
K.C. Wheare, Federal Governement (1963)
Students should consult relevant volumes of the Annual Survey of Indian Law published by
theIndian Law Institute (Constitutional Law II)

24

<!-- page 25 -->

SECOND SEMESTER
COURSE CODE : TH-103201
COURSE NAME : JUDICIAL PROCESS
Course Objectives:
A lawyer, whether academic or professional, is expected to be competent to analyse and evaluate the
legal process from a broader juristic perspective. The objective of this paper is to study the nature of
judicial process as an instrument of social ordering. It is intended to highlight the role of court as
policy maker, participant in the power process and as an instrument of social change. This paper
further intends to expose the intricacies of judicial creativity and the judicial tools and techniques
employed in the process.
Since the ultimate aim of any legal process or system is pursuit of justice, a systematic study of the
concept of justice and its various theoretical foundations is required. This paper, therefore, intends to
familiarise the students with various theories, different aspects and alternative ways, of attaining
justice.
Syllabus
1.

Nature of judicial process
Judicial process as an instrument of social ordering
Judicial process and creativity in law – common law model – Legal Reasoning and
growth of law – change and stability.
The tools and techniques of judicial creativity and precedent.
Legal development and creativity through legal reasoning under statutory and
codified systems.

Learning outcome :
UNIT 1: The student will understand how judicial process works as social ordering, and how it brings
change and stability in Law,

2.

Special Dimensions of Judicial Process in Constitutional Adjudications.
Notions of judicial review
‘Role’ in constitutional adjudication – various theories of judicial role.
Tools and techniques in policy-making and creativity in constitutional adjudication.
Varieties of judicial and juristic activism
Problems of accountability and judicial law-making.

Learning outcome :
UNIT 2: This unit makes the student to understand the special dimensions of judicial process, its role
in constitutional adjudication, using judicial tools and techniques in policy making.
3.

Judicial Process in India
25

<!-- page 26 -->

Indian debate on the role of judges and on the notion of judicial review.
The “independence” of judiciary and the “political” nature of judicial process
Judicial activism and creativity of the Supreme Court-the tools and techniques of
creativity.
Judicial process in pursuit of constitutional goals and values – new dimensions of
judicial activism and structural challenges
Institutional liability of courts and judicial activism – scope and limits.
Learning outcome :

UNIT 3: Here the student understands judicial process in India, independence of judiciary, creativity
of the Supreme Court, and the meaning of judicial activism.
4.

The Concepts of Justice
The concept of justice or Dharma in Indian thought
Dharma as the foundation of legal ordering in Indian thought.
The concept and various theories of justice in the western thought.
Various theoretical bases of justice: the liberal contractual tradition, the liberal
utilitarian tradition and the liberal moral tradition.

Learning outcome :

UNIT 4: This unit makes the student understand the concept of Dharma, how Law has been derived
from Dharma, and various theories of justice in the western thought.
5.

Relation between Law and Justice
Equivalence Theories – Justice as nothing more than the positive law of the stronger
class.
Dependency theories – For its realization justice depends on law, but justice is not the
same as law.
The independence of justice – means to end relationship of law and justice – The
relationship in the context of the Indian constitutional ordering.
Analysis of selected cases of the Supreme Court where the judicial process can be
seen as influenced by theories of justice.

Learning outcome :
UNIT 5: Here the student will be able to understand the relation between Law and Justice, different
theories of justice and the selected cases of Supreme Court where judicial process is seen influenced
by theories of justice.
Course Outcome:
1. The student understands the role of judicial dimensions, legal reasoning and growth of Law.
26

<!-- page 27 -->

2. The student understands problems of accountability and judicial Law making.
3. The student will be able to make difference between independence of judiciary and political nature
of judicial process.
4. The student will understand the concept of Dharma, Dharma as the foundation of legal
ordering in India, and the relation between Lawand Justice.
Select Bibliography
Julius Stone, The Province and Function of Law, Part II, 1.8-16 (2000), New Delhi.
Cardozo, The Nature of Judicial Process (1995) Universal, New Delhi.
Henry J.Abraham, The Judicial Process (1998) , Oxford.
W.Friedmann, Legal Theory (1960), Stevens, London.
Bodenheimer, Jurisprudence – the Philosophy and Method of the Law (1997), Universal, Delhi
J.Stone, Legal System and Lawyers’ Reasonings (1999), Universal, Delhi
U.Baxi, The Indian Supreme Court and Politics (1980), Eastern, Lucknow.
Rajeev Dhavan, The Supreme Court of India – A Socio-Legal Critique of its Juristic Techniques
(1977), Tripathi, Bombay.
John Rawls, A Theory of Justice (2000), Universal, Delhi
Edward H.Levi, An introduction to Legal Reasoning (1970), University of Chicago.

27

<!-- page 28 -->

COURSE CODE : TH-103202
COURSE NAME : LEGAL EDUCATION AND RESEARCH METHODOLOGY

Course Objectives:
A post-graduate student of law should get an insight into the objectives of legal education. He should
have an exposure to programmes like organization of seminars, publication of law journals and
holding of legal aid clinics.
Law is taught in different ways in different countries. The LL.M. course, being intended also to
produce lawyers with better competence and expertise, it is imperative that the student should
familiarise himself with the different systems of legal education. The lecture method both at LL.B.
level and LL.M. level has many demerits. The existing lacunae can be eliminated by following other
methods of learning such as case methods, problem method, discussion method, seminar method and
a combination of all these methods. The student has to be exposed to these methods so as to develop
his skills.
Growth of legal science in India depends on the nature and career of legal research. The syllabus is
designed to develop also skills in research and writing in a systematic manner.
Syllabus
1.

Objectives of Legal Education
Learning outcome :

Studies doctrinal and non- doctrinal social legal research.
2.

Lecture Method of Teaching – Merits and demerits
Learning outcome :

Knowthe relevance of empirical research.
3.

The Problem Method
Learning outcome :



Preparing the hypothesis.

4.

Discussion method and its suitability at postgraduate legal teaching
Learning outcome :

Understand the induction and deduction of the study
5.

The Seminar Method of teaching
Learning outcome :



Studies the research problem.

6.

Examination system and problems in evaluation – external and internal assessment.
Learning outcome :



Importance of survey on available literature and bibliographic research.
28

<!-- page 29 -->

7.


8.

Clinical legal education – legal aid, legal literacy, legal survey and law reform
Learning outcome :



Study the juristic writings relevant to research in India along with foreign periodicals.

9.

10.

Student participation in law school programmes – Organisation of Seminars, publication
of journal and assessment of teachers.
Learning outcome :
Studying the decisional materials including foreign decisions in the area pertaining research
problem.

.Research Methods
Social Legal Research
Doctrinal and non-doctrinal
Relevance of empirical research
induction and deduction
Identification of Problem of research
What is a research problem?
Survey of available literature and bibliographical research.
Legislative materials including subordinate legislation, notification and
policy statements.
Decisional materials including foreign decisions; methods of discovering the
“rule of the case” tracing the history of important cases and ensuring that
these have not been over-ruled; discovering judicial conflict in the area
pertaining to the research problem and the reasons thereof.
Juristic Writings – a survey of juristic literature relevant to select problems in
India and foreign periodicals.
Compilation of list of reports or special studies conducted relevant to the
problem.
Preparation of the Research Design
Formulation of the Research problem
Devising tools and techniques for collection of data: Methodology
Methods for the collection of statutory and case materials and juristic
literature
Use of historical and comparative research materials
Use of observation studies
Use of questionnaires/interview
Use of case studies
Sampling procedures – design of sample, types of sampling to be adopted.’
Use of scaling techniques
Jurimetrics
Computerized Research – A study of legal research programmes such as
Lexis and West law coding
Classification and tabulation of data – use of cards for data collection – Rules
for tabulation. Explanation of tabulated data.
Analysis of data

Learning outcome :
Understand the list of reports or special studies relevant to the research problem.
29

<!-- page 30 -->

Unit-11: Artificial Intelligence in Legal Education and Research:
Introduction to AI in Legal Education and Research.
Meaning, evolution, scope and applications of AI in legal education and research.
AI – Assisted Legal Research Methodology.
Use of AI for identifying legal issues, framing research questions, objectives and hypotheses.
Ethical use of AI and plagiarism check in Legal Research.
Using AI honestly in legal research.
Understanding AI-generated content and plagiarism.
Using plagiarism-checking tools.
Giving proper credit and citations.
Checking AI answers for accuracy and correctness.
AI tools for case law and statutory research.
Searching, retrieving, analyzing and summarizing judgments, statutes and legal materials.
AI, Legal Citation and Academic writing.
AI-assisted drafting, referencing, citation and research documentation.
AI in clinical and experiential Legal Education.
Use of AI for practical and skill-based legal learning,
AI-assisted moot courts, mock trials, legal drafting and client counselling,
Virtual simulations for negotiation, mediation and case analysis.
Develops professional skills through interactive learning and instant feedback.
Learning outcomes:
To understand and effectively use AI tools in legal education, research, academic writing, and practical legal learning
in an ethical and responsible manner.
Course outcomes:
After studying this paper, the student can


Get to know the doctrinal and non-doctrinal social legal research.



Enlighten about the relevance of empirical research.



Know the identification of hypothesis and problem of research.



Know the importance of juristic writings in India as well as foreign periodicals.



Understand the preparation of research design.



Know the formulation of research problem.



Understand how to apply the methods and techniques to the study.



Get to know how to use case studies, questionaries, interview, and observation methods.



Understand the computerized research by the study of lexis and west law coding.



Preparation of classification and tabulation of data through various sources.

Bibliography
30

<!-- page 31 -->

High Brayal, Nigel Dunean and Richard Crimes, Clinical Legal Education: Active Learning in your
Law School, (1998) Blackstone Press Limited, London.
S.K.Agrawal (Ed.), Legal Education in India (1973), Tripathi, Bombay.
N.R.Madhava Menon, (ed) A Handbook of Clinical Legal Education, (1998) Eastern Book Company,
Lucknow.
M.O.Price, H.Bitner and Bysiewiez, Effective Legal Research (1978)
Pauline V. Young Scientific Social Survey and Research , (1962)
William J. Grade and Paul K.Hatt, Methods in Social Research, Mc Graw-Hill Book Company,
London
H.M.Hyman, Interviewing in Social Research (1965)
Payne, The Art of Asking Questions (1965)
Erwin C.Surrency, B.Fielf and J.Crea, A Guide to Legal Research (1959)
Morris L.Cohan, Legal Research in Nutshell, (1996), West Publishing Co.
Havard Law Review Association, Uniform System of Citations.
ILI Publication, Legal Research and Methodology.

31

<!-- page 32 -->

COURSE CODE : TH-103203
COURSE NAME : HUMAN RIGHTS
Course Objectives:
Human rights were conceived rather narrowly as mere freedom from arbitrary government in the past.
It was realised later and much more so during last fifty years since the end of the Second World War
that the threats to liberty, equality and justice did not emanate from the state alone.
Many nations of Asia and Africa came to nationhood during this period. These nations had to bring
about their development and they needed capital. Foreign aid and foreign investments were invited
but these could very well lead to their second subjugation. Poverty, ignorance, exploitation had to be
fought at the global level. Development had to come without the sacrifice of human values. A greater
awareness of human rights, not only as negative restrictions on the state but as positive obligations for
creating an environment in which man could live with dignity was necessary.
The focus of a course on human rights must be on the national problems with an international or
global perspective. The world community's concerns about human rights have been expressed
through various conventions. On the national levels, they are contained in constitutional provisions
such as directive principles of state policy, fundamental rights, fundamental duties and judicial,
legislative as well as administrative strategies of reconstruction. Human rights acquire much more
comprehensive and wider meaning. It requires us to take up cudgels against poverty discriminations
based on caste, colour or sex, make provisions for drinking water, population control, conservation
and preservation of natural resources, ecological balance, protection of consumers against ruthless
and profit seeking, traders or manufacturers, provisions against hazardous industries and so on and so
froth. Human rights is an important parameter for a just society and future lawyers must be able to
assess any programme of social transformation with reference to them.
The following syllabus prepared with this perspective will be spread over a period of one semester.
Syllabus
1.

Panoramic View of Human Rights

1 .1 . Human Rights in Non-western Thought
Awareness of Human rights during tile nationalist movement
Universal Declaration of Human Rights, Constituent Assembly and Part III, drafting
process.
Subsequent developments in International Law and the Position in India (e.g.
Convention of Social discrimination, torture, gender discrimination, environment and
the two human rights covenants.)
Learning Outcomes:
i) To understand the Students the concept of Human Rights and to expose the Students that the
problems of Human Rights during the Nationalist movement;
ii) To apprise the principles of Universal Declaration of Human Rights, Constituent Assembly and
Part III, drafting process.
iii) To understand the Students about subsequent developments in International Law and the
position in India such as Convention of Social discrimination, torture, gender discrimination,
environment and the two human rights covenant
32

<!-- page 33 -->

2.

Fundamental Rights Jurisprudence as Incorporating Directive Principles
The dichotomy of Fundamental Rights (F.R.) and Directive Principles (D.P.)
The interaction between F.R. and D.P.
Resultant expansion of basic needs oriented human rights in India

Learning Outcomes:
i) To understand the Students the dichotomy of Fundamental Rights (F.R.) and Directive Principles
(D.P.) in relation to protection of human rights
ii) To apprise the Students the interaction between F.R. and D.P.
iii) To understand the Students the Resultant expansion of basic needs oriented human rights in
India
3.

Right not be subject to Torture, Inhuman or Cruel Treatment
Conceptions of torture, third-degree methods
"Justifications" for it
Outlawry of torture at international and constitutional law level
Incidence of torture in India
Judicial attitudes
Law Reform - proposed and pending

Learning Outcomes:
i) To understand the Students about conceptions of torture, third-degree methods
ii) To understand the Students to "Justifications" for it
iii) To apprise the students Outlawry of torture at international and Constitutional law level
iv) To understand Incidence of torture in India Judicial attitudes Law Reform - proposed and
pending
4.

Minority Rights
Conception of minorities
Scope of protection
The position of minority "Woman" and their basic rights
Communal Riots as Involving violation of Rights.

Learning Outcomes:
i) To understand the Students about Conception of minorities
ii) To learn the Scope of protection
iii) To understand the Students the position of minority "Women" and their basic rights
iv) To apprise the students the Communal Riots as involving violation of Rights.
5.

Rights to development of Individuals and Nations
The UN Declaration on Right to Development, 1987
The need for constitutional and legal changes in India from human rights standpoint.
33

<!-- page 34 -->

Learning Outcomes:
i) To understand the Students the UN Declaration on Right to Development
ii) To expose the Students about the need for constitutional and legal changes in India from
human rights standpoint.
6.

People's Participation in Protection and Promotion of Human Rights

.

Role of International NGOS
Amnesty International
Minority Rights Groups
International Bars Association, Law Asia
Contribution of these groups to protection and promotion of human rights in India.

Learning Outcomes:
i) To understand the Students the Role of International NGOS, Amnesty International
Minority Rights Groups, International Bars Association Law Asia, Contribution of these
groups in protection and promotion of human rights in India.
7.

Development Agencies and Human Rights
Major international funding agencies and their operations in India
World Bank lending and resultant violation/promotion of human rights
Should development assistance be tied to observance of human rights (as embodied
in various UN declarations)

Learning Outcomes
i) To understand the Students Major international funding agencies and their operations in
India
ii) To understand the World Bank lending and resultant violation, promotion of human right
8.

Comparative Sources of Learning

EEC Jurisprudence
The Green Movement in Germany
The International Peace Movement
Models of Protection of the rights of indigenous peoples: New Zealand (Maoris)
Australia, Aborigines and Canada (Indians)
Learning Outcomes
To understand the Students about EBC Jurisprudence, the Green Movement in Germany, the
International Peace Movement, Models of Protection of the rights of indigenous peoples: New
Zealand (Maoris)Australia, Aborigines and Canada (Indian)
9.
Freedoms
Free Press - Its role in protecting human rights
Right of association
Right to due process of law Access and Distributive Justice
Access and Distribution Justice
34

<!-- page 35 -->

Learning Outcomes:
i) To understand the Students about Free Press-Its role in protecting human right
ii) To expose the Students about the Right of association, Right to due process of law Access
and Distributive Justice
10.

Independence of the Judiciary
Role of the Legal Profession
Judicial appointments - tenure of judges
Qualifications of judges
Separation of judiciary from executive

Learning Outcomes:
i) To understand the Students the Role of the Legal Profession
ii) To apprise the Students about the Judicial appointments and tenure of judges,
Qualifications of judges
iii) To expose the Students about the Separation of judiciary from executive
11.

European Convention of Human Rights

European Commission/Court of Human Rights
Amnesty International
PUCL, PUDR, Citizens for Democracy
Minorities Commission
Human Rights Commission
Remedies Against Violation of Human Rights
Course Outcomes:
i) To understand the Students about the European Commission/ Court of Human Rights
ii) To understand the Students the Role of Amnesty International
iii) To expose the Students about PUCI, PUDR. Citizens for Democracy
iv) To understand the Students the role of Minorities Commission, Human Rights Commission,
and Remedies against Violation of Human Rights
Select bibliography
M.J. Akbar, Riots After Riots (1988) U.Baxi
(ed.), The Right to be Human (1986)
U.Baxi, The Crisis of the Indian Legal System(1982), Vikas Publishing House, New Delhi.F.Kazmi, Human
Rights (1987)
L.Levin, Human Rights (1982)
Madhavtirtha, Human Rights (1953)
W.P. Gromley, Human Rights and Environment (1976)
H. Beddard, Human Rights and Europe (1980)
Nagendra Singh, Human Rights and International Co-operation (1969)
S.C. Kashyap, Human Rights and Parliament (1978)
S.C. Khare, Human Rights and United Nations (1977)
Moskowitz, Human Rights and World Order (1958)
J.A Andrews, Human Rights in International Law (1986)
I. Menon (ed.), Human Rights in International Law (1985)
AB. Robertson (Ed), Human Rights in National and International Law (1970)
Upendra Baxi, "Human Rights, Accountability and Development" Indian Journal of international law279 (1978)

35

<!-- page 36 -->

COURSE CODE : TH-103204
COURSE NAME : NATIONAL SECURITIES, PUBLIC ORDER AND RULE OF LAW

Course Objectives:
In every written constitution, provision is required to be made to equip the state to face grave threats
to its existence arising from extra-ordinary circumstances created by war or external aggression or
armed rebellion. Although "amidst the clash of arms, the laws are not silent" they do not speak the
same language in war as in peace. Extra-ordinary circumstances warrant the invocation of extraordinary laws and such laws are known as emergency laws. They put greater fetters on individual
liberty and also eclipse certain aspects of the due process. But in such circumstances, the democratic
forces must assert that for survival of the State, the least possible liberty should be available. The
students should be familiarized with different aspects of such emergency powers and scrutinizing
intellectual attitude towards such powers.
The following syllabus prepared with this perspective will be spread over a period of one semester.
Syllabus
1.

National Security, Public Orders and Rule of Law
1 .1 .

Emergency Detention in England - Civil Liberties

1 .1 .1 .Subjective satisfaction or objective assessment?
1.2.
Pre-Independence law.
Learning Outcomes:


Students will understand the sources, foundation and structure of national security law and
also recognize the participants in the national security system and understand the
constitutional roles given to each participant.
Preventive Detention and Indian Constitution

2.

Article 22 of the Constitution
Preventive Detention and Safeguards
Declaration of Emergencies
1962, 1965 and 1970 Emergencies
1975 Emergency
Learning Outcomes:


3

Students will understand how power is shared by the branches of government to maintain
national security and also discussed about the provisions regarding preventive detention at
the time of emergency
Exceptional Legislation
COFEPOSA and other legislation to curb economic offenders
TADA: "the draconian law"-comments of NHRC
Special courts and tribunals
Due process and special legislation
36

<!-- page 37 -->

Learning Outcomes:
Students will understand the law as it applies to specific national security issues such as the
use of military force, the activities of the intelligence community, and counterterrorism
activities, knowing about the importance of NHRC in view of the “The Draconian Law"
4.

Civil Liberties and Emergency
Article 19
Meaning of "Security of State"
Meaning of "Public Order"
Suspension of Article 19 rights on declaration of emergency
President's Right to suspend right to move any court
Article 21 - special importance - its non-suspendability
Suspendability -44th Amendment
Learning Outcomes:


5.

Students will gain a greater appreciation for the national security insights provided by the
Gospel and how they can be applied by national security professionals.
Access to Courts and Emergency
Article 359: ups and downs of judicial review
Constitution (Forty-fourth), Amendment Act, 1978.
Constitution (Fifty-ninth) Amendment Act,. 1988.
Learning Outcomes:


6.

Here the students elucidate the provisions under article 359, ups and downs of judicial review
and equipped with the provisions under 44th and 49th amendments of Indian constitution
Martial Law
Provisions in English Law
Provisions in the Constitution



Learning Outcomes:
Identify the martial laws under English Law and its merits and demirits

Course Outcomes:
At the end it is expected that the student will be able to Understand and interpret various
provision and safeguards to protection national security;
 To explore the various approach of public order, importance of rule of law and different
legislations;

Balancing the civil liberties and power of state; and Explore the various functional
institution like election commission, parliament and checks and balance on the
nationalimportance.
Select bibliography
G.O. Koppell"The Emergency, The Courts and Indian Democracy" 8 J.I.L.I. 287 (1966)
H.M. Seervai, The Emergency, Future Safeguards and the habeas Corpus: A Criticism (1978)
International Commission of Jurists, Status of Emergency and Human Rights (1984)
N.C. Chatterji and Parameshwar Rao, Emergency and the Law (1966).
37

<!-- page 38 -->

THIRD SEMESTER
COURSE CODE : TH-103301
COURSE NAME : MASS MEDIA LAW
Course Objectives:
Mass media such as Press, Radio and Television, Films, play a vital role in socialisation,
culturalisation and modenisation of a society. The visual media are bound to have a much greater
impact on human mind. But while these media have such a potential value as man educators, they are
also susceptible to destructive and harmful uses for promoting criminal anti-social and selfish escapist
tendencies. While their positive potential as mass educators has to be harnessed for developmental
purposes, their negative, harmful potential has to be curbed in public interest. Law plays a dual role
vis-a-vis such media. On the one hand, it protects the creative freedom involved in them, on the other,
it has to regulate them so as to avoid their possible abuse. This paper will deal with such interaction
between law and mass media.
The following syllabus prepared with this perspective will be spread over a period of one semester.
Syllabus
1.

Mass media - Types of - Press Films, Radio Television
Ownership patterns - Press - Private - Public
Ownership patterns - Films - Private
Ownership patterns - Radio & Television, Public
Difference between visual and non- Visual Media- impact on Peoples minds.

Learning Outcomes:


2.

Identify the different ownership patterns in media includes individual ownership and also
describes the differences between visual and non-visual media impact on people’s mind
converse about the effects of monopoly upon electronic media in India as well as in other
countries.
Press - Freedomof Speech and Expression - Article 19 (1) (a)
Includes Freedom of the Press.
Laws of defamation, obscenity, blasphemy and sedition.
The relating to employees wages and service conditions,
Price and Page Schedule Regulation

Learning Outcomes:
1.

Define the fundamental rights enjoyed by the citizens of India the fundamental principles
of mass media lawin India and other countries like U.S.A and England.

2.

Practice reporting with an understanding of dos and don’ts as per the law and ethics.
Demonstrate an understanding of the privileges under freedom of speech and expression
38

<!-- page 39 -->

and also reasonable restrictions imposed on it.
3.

Explain defamation law and its types. Identify the implications of media law relating to
contempt of court. Define what would constitute an obscene act and the penalty under it.

4.

Recognise and assess the legal risk associated with contempt of legislature and privacy.
Explain copyright act Demonstrate an understanding on Press and Registration act.

5.

Identify an act leading to drugs and magical remedies act. Evaluate the relevance to
society of Right to Information Act.

6.

Critically analyse how Press Council can interfere with freedom of the press Explain the
term self-regulation in relation to control of Press and Media. Critically analyse different
ethical issues related to media in India with case studies.

7.

Differentiate between ethics and morality

Course Outcomes:
1. After the completion of the course the students will be able to explain and review on critical
evaluation of mass communication Theories
2. The student will be able to identify and define the advertising concepts and will review the
advertising media.
3. Students will be able to identify ethical issues faced by the media and discuss trends in
commercialization of news
4. Students will be able to discuss the various media laws and their implications on conduct of
media
5. Students will be able to analyse the issue of media regulation in India and also in other
countries.
6. Students will be able to avail the provisions towards Freedom of Speech and reasonable
restrictions.

Select Biblographyy
C.M. McPherson, (1979).
R. Young, 'Dispensing with Moral Rights', 6 Political Theory, 63 (1978).
J. Feinberg, 'Voluntary Euthanasia and the Inaltenable Right to Life', 7 Phil. And Public Affairs, 92
(1978).
J. Finnis, The Rights and the Wrongs of Abortion: A Reply to Judith Thomson', 2 Phil. and Public
Affairs, 117 (1973).
A. Geworth, 'Human Rights and The Prevention of Cancer', American Phil Quar., 17 (1980), 117.
H.J. MeCloskey, 'The Right to Life4, 15 Philosophical Quarterly 115 (1965).
J.J. Thompson,'A Defense of Abortion', Phil and Public Affairs, 47(1971).
A. Gewirth, 'Civil Liberties as Effective Powers', in Human Rights: Essays on Justification and
Applications (1983).
M. Sarpiro, Freedom of Speech: The Supreme Court and Judicial Review (1966).
39

<!-- page 40 -->

R.M. Dworkin, 'Principle, Policy, Procedure, in Crime, Proof and punishment: Essays In Memory of
Sir Rupert Cross (1981).
LC. Beeker, Property Rights: Philosophic Foundations (1977).
R: Nozick, Anarchy, State and Utopia ch.7. (1974).
Chhatrapati Singh, Common Property and Common Poverty, (1986).
U.Baxi, "Taking Suffering Seriously", in 8-9 Delhi Law Review 91 (1979-80).
M.N. Gewirth, 'Starvation and Human Rights', in Human Rights: Essays on Justification and
Applications, (1983).
F.I. Michelman, 'Constitutional Welfare Rights and A Theory of Justice', in N. Ameil (ed.) Reading
Rawls. Critical Studies of A Theory of Justice, (1975).
J. Feinberg, The Rights of Animals and Unborn Generations" W.T. Blackstone (ed.) Philosophy and
Environmental Crisis, (1974).
R. Prey, Interests and Rights: The Case Against Animals, (1980).
John B. Howard, "The Social Accountability of Public Enterprises" in Lawand Community Controls
in New Development Strategies (International Center for law in Development 1980).
Bruce Michael Boyd, "Film Censorship in India: A Reasonable Restriction on Freedom of Speech
and Expression ".14 J.I.L.I. 501 (1 972).
Rajeev Dhavan "On the Law of the Press in India" 26 JI.L/. 288 (1984).
Rajeev Dhavan, "Legitimating Government Rhetoric: Reflections on Some Aspects of the Second
Press Commission" 26 J./L/. 391 (1984).
Soli Sorabjee, Lawof Press Censorship in India (1976).
Justice E.S. Venkaramiah, Freedom of Press: Some Recent Trends (1984).
D D. Basu, The Law of Press of India (1980).
Students should consult relevant volumes of the Annual Survey of Indian Law published by the
Indian Law Institute. (Constitutional Law 1 & 11, Administrative Lawand Public Interest litigation).

40

<!-- page 41 -->

COURSE CODE : TH-103302
COURSE NAME : PUBLIC UTILITIES LAWS
Course Objectives:
Public utilities are government monopolies, which are services rather than commercial enterprises.
The law of public utilities is contained in the statutes of incorporation and judicial decisions given by
courts while resolving disputes between the utilities and their consumers or employees or traders or
others entering into business relations with them. In this paper a student will study (a) government
policy in regard to such utilities in general and to each utility in particular, (b) the growth and
evolution of the public utilities; (c) patters of the laws of incorporation and (d) powers, functions and
liabilities of the public utilities vis-a-vis their employees, consumers and others.
The following syllabus prepared with this perspective will be spread over a period of one semester
Syllabus
1. Public Utilities
Railways, Electricity, Gas, Road Transport, telephone, post and telegraph
service, Police, Fire Brigade, Banking service, etc.
Growth and evolution of public utilities and their legislation
Learning Outcome:
By proper study of this unit, the student will be able to remember about the functions of Railways,
Electricity, Gas, Road Transport, telephone, post and telegraph service, Police, Fire Brigade,
Banking service, etc., and also Growth and evolution of public utilities and their legislation on
listening the lectures by the teacher. In this unit, the students will also think about the troubles faced
by the public due to the negligence on the part the said authorities as banking authorities have been
sanctioning the huge loans like even 10 thousand crores to the economic offenders and in other way
to sanction the 10 thousand rupees to the farmers is reasonable and also as the Central Government is
privatizing the Government undertakings, what problems will be faced by the public.

2. Public Utilities - Why Government Monopoly?
Government and Parliamentary Control
Constitutional division of power to legislate.
Learning Outcome:
By proper study of this unit, the student will be able to demonstrate understanding of facts and ideas
by Interpreting giving descriptions and stating main ideas of the need for the public utility service
undertakings, why the government is monopolizing the public utility services though the scams by
the authorities of the said undertakings even though the said undertakings are running on the losses.
The students will be able to distinguish that why the profitable undertakings are privatized and also
to be privatized by making plans on the privatization of LIC like that. The students will have idea of
the purpose of privatization.
3. Utilities Legislation - Patterns of –
41

<!-- page 42 -->

Administrative Authorities - Structure of the Administrative Authorities
Subordinate legislation
Learning Outcome:
By proper study of these units, the student will be able to understand and solve the problems with
regard to the problems faced by the public on the acts of Administrative Authorities and also
know the Structure of the Administrative Authorities because of the participation in Fee legal
aid services conducted by the Universities and law colleges.
4. Public Utilities and Fair Rearing
Quasi-Judicial Decision - Administrative Discretion.
Learning Outcome:
By proper study of this unit, the student will be able to examine by identifying the functions
of quasi judicial authorities like that of Income Tax authorities and also GST authorities.
The students will also be able to give guidelines how to solve the problems on this issue.

5. Public Utilities and Consumer Protection
Rights of consumers protected by the Consumer Protection Act
Rights Arising from law of Contract and law of Torts.
Learning Outcome:
By proper study of this unit, the student will be able to gather the information, validity of ideas
regarding emerging regime of new rights and remedies, study of Directive Principles and
Fundamental Duties into Fundamental Rights, Compensation jurisprudence, Right to education under
Art 21 A of the Constitution, Commercialization of education and its impact though the Educational
trust of the educational institution is established on non- profit basis and Brain drain by foreign
education market. By proper study of this unit, the skills of the students are to be improved as their
analyzing capacity will be grown up.
6. Public Utilities and their Employees.
Application of Articles l6 and 311?
6.1. Application of Industrial law- right to strike.
Learning Outcome:
By proper study of this unit, the student will be able to compile information together in a
different way by comparing with minority rights with Secularism in a new pattern. The
students also be able to give guidelines how to solve the problems of this issue.
7. Public Utilities and Fundamental Rights
42

<!-- page 43 -->

The right to equality: the Airhostess case.
Are Public utilities "State" for the purpose of article 12 of the Constitution?
Extension of the concept of State
Learning Outcome:
By proper study of this unit, the student will be able to compile information relating to the
Separation of powers: Stresses and strain, Judicial activism and judicial restraint, PIL:
implementation, Appointment, transfer and removal of judges. The students will also be able to judge
that whether collegiums for appointment of judges of High Courts and also the Supreme Court will be
leading to bias, whether A.K. Kripark Vs. Union of India case up to how much will be applicable in
case of collegiums. The students also be able to give guidelines how to solve the problems for this
issue.
8. Liabilities and special privileges of public utilities
In contract
In tort
In criminal law
Learning outcome:
By proper study of this unit, the student will be able to compile information relating to the Liabilities
and special privileges of public utilities service undertakings, whether the liability in contract,
tort and in criminal law will be operated in case of public utility service industries or not is to
be studied in depth by the students.
Select bibliography
P.M. Bakshi, Television and the Law, (1986)
Vasant Kelkar, "Business of Postal Service" 33 I.J.PA. pp. 133-141 (1987)
G. Ramesh, "Characteristic of Large Service Organisation in a Developing Country Like India" 32
I.J.PA. 77 (1986)
Nalini Paranjpe, "Planning for Welfare in the Indian Railways" 31 I.J.PA. 171-180 (1985)
Arvind K. Sharrna "Semi-Autonomous Enterprise: Conceptual Portrait - Further Evidence on the
Theory of Autonomy" 33 I.J.PA. p. 99-113.
S.P. Sathe, Administrative Law (1998)
Jain & Jain, Principles of Administrative Law, (1986)
Jagdish Ul, Handbook of electricity Laws, (1978)
Bhaumik, The Indian Railways Act, (1981)
Law Commission of India, 38th Report : Indian Post Office Act, 1898, (1968)
Students should consult relevant volumes of Annual Survey of Indian Law published by the Indian
Law Institute (Constitutional Law 1 & 11, Administrative Law, Consumers Protection Law and
Labour law).

43

<!-- page 44 -->

COURSE CODE : PR-3001
COURSE NAME : COMPULSORY PRACTICAL

Doctrinal Work Course Objectives:
One of the main purposes of conducting doctrinal research is solving the legal problems of bringing
laws. For example, if the government decides to bring umbrella legislation for all the crimes
committed against women, it may initiate doctrinal research by some jurists and experts in the field.
It can be utilized for several other purposes as well like to help lawmakers develop meaningful and
effective laws, develop fresh legal doctrines, aid courts in reaching effective and legally accurate
judgments, help lawyers to interpret statutes and prepare their suits, help students in academia to set a
base and many others.
Doctrinal Work Course Outcomes:
Doctrinal research has helped in developing a basic awareness of legal issues among the people. It has
immensely helped judges and attorneys in legal suits to develop valid arguments and reach an
effective judgment. The development of tort law is a prime example. Doctrinal research by focusing
on “law as it is” has helped in percolating a greater awareness about legal issues among the masses. It
has also helped in pointing out the loopholes in existing laws and statutes.
Non-Doctrinal Work Course Objectives:


Non-doctrinal research, also known as socio-legal research,that employs methods taken from
other disciplines to generate empirical data that answers research questions. (Salim Ibrahim
Ali 2017)



The purpose of non-doctrinal research is to check the utility of a law that has been brought or
how it impacts the non-legal aspects of society. Also, non-legal factors affect the
implementation of the law. Sometimes, a very comprehensive law is brought but sometimes
the environment is such that its effectiveness is shielded by those circumstances.

Non-Doctrinal Work Course Outcomes:


non-doctrinal research focuses on law in action in its playing field i.e., the society. It could be
of great help for analyzing the effects of laws on people and how to bring out legal reforms. It
helps the law to catch up with this ever-changing society. Judicial activism is a great product
of non-doctrinal research.



non-doctrinal research studies law in connection with society and various non-legal aspects
that affect the law. It is socio-legal research.



non-doctrinal research has a wider scope and studies law in comprehensive terms.

Clinical Legal work, Course Objectives:


one of the main elements of Clinical Education. The reason for this is that, they are first
44

<!-- page 45 -->

trained as a trainee, then they step up and learn legal skills and at the same time work as
educators in the law field. Some of the important contributions can be listed as- First, the
focus of this method is rather on students learning it rather than teachers teaching it,


hence amble amount of work is put into it by the students itself. Second, when it comes to
theoretical norms, they are usually tested and operated upon by the students and teachers and
even here it reflecting the working of both teachers and students for the purpose of attaining a
common goal.

Clinical Legal work, Course Outcomes:


It is of great importance to find an active, effective, collaborative, comprehensive and
sustained educational method for legal rights. Based on our research, legal clinics have an
effectual role in creating these features for legal rights education as far as clinical human
rights education can be introduced and recommended as a premier method to increase legal
rights knowledge in the community.



National law school model established post-independent Indian legal education has done a
great job in the development of legal education in India with a strong commitment to
improving existing legal infrastructure. Certainly, with this spirit, changes in syllabus and
structure to cater to the new generation of lawyers.

FOURTH SEMESTER
PAPER CODE
PAPER NAME

:
:

DI - 2002
DISSERTATION

PAPER CODE
PAPER NAME

:
:

VV-2002
VIVA-VOCE

45
