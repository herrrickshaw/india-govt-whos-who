---
doc_id: "947baccc731adfa2"
source_url: "https://apgenco.gov.in/asset/docs/file1/fileupload_261028_aeefb050911334869a7a5d9e4d0e1689.pdf"
ministry: "Andhra Pradesh Power Generation Corporation Limited (APGENCO), Andhra Pradesh"
title: "Tender No: Specification No. e-1005078/HPC&HP/SPV Modules/APGENCO/2026"
date: ""
pages: 59
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "112fccb27abe93fb"
---

<!-- page 1 -->

ANDHRA PRADESH POWER GENERATION CORPORATION LIMITED
Vidyut Soudha, Vijayawada-520004

Specification No. e-1005078/HPC&HP/SPV Modules/APGENCO/2026
(Two Part Bid)
Supply, testing, packing and forwarding, insurance, transportation and unloading of
1.65 MWp SPV modules, ground-mounted, grid-connected of capacities 320 Wp /
325 Wp / 330 Wp Solar Photovoltaic (SPV) modules at 400 MW Solar Power Project
site at Talaricheruvu, Tadipatri, Ananthapuramu District, Andhra Pradesh.
(or)
Alternatively, Supply, testing, packing and forwarding, insurance, transportation
and unloading of 1.65 MWp SPV modules ground-mounted, grid-connected of
capacities 615Wp/620Wp along with the necessary structure modification/rework of
the existing Module Mounting Structures (MMS), wherever required, to ensure proper
installation and compatibility with the supplied modules including Installation,
testing & commissioning of 1.65 MWp SPV modules (Installation as per the quantity
required at site) at 400 MW Grid-Connected Solar PV Power Project at Talaricheruvu
(V), near Tadipatri, Anantapuramu District, Andhra Pradesh.
INSTRUCTIONS TO TENDERERS, CONDITIONS OF CONTRACT,
GENERAL REQUIREMENTS & SCHEDULES.
Phone No: 0866-2526801/2526320/2526323
Email

: se-hpc1@apgenco.gov.in
Sd/Superintending Engineer
Hydel-I/APGENCO
Vidyut Soudha, Vijayawada

<!-- page 2 -->

CONTENTS

S. No.

Description

1.

Notice Inviting Tender

2.

Check List

3.

Instructions to Bidders

4.

General Purchase Conditions (General)

5.

General Purchase Conditions (Financial)

6.

Technical Specification

7.

Schedule-1 (Guaranteed Technical Particulars)

8.

Schedule-2 (General Terms & Conditions)

9.

Schedule-3 (Deviations from Specification)

10.

Schedule-4 (Proforma of letter of Transmittal)

11.

Schedule -5 (Proforma of Guarantee for Equipment Performance)

12.

Schedule -6 (Proforma of Letter of Authority)

13.

Schedule-A (Price Bid Format)

14.

Guidelines for submission of Bank Guarantee

15.

Annexure-1(BG Proforma for EMD)

16.

Annexure-2 (BG Proforma for PEMD)

17.

Annexure-3(Surety Bond Proforma for EMD)

18.

Annexure-4 (BG Proforma for Security Deposit)

19.

Annexure-5 (BG Proforma for Performance )

20.

Annexure-6 ( Surety Bond Proforma for Performance )

21.

Annexure-7(Consent Form)

22.

Annexure-8 (Manufacturing Quality Plan)

23.

Annexure-9(Field Quality Plan)

<!-- page 3 -->

ANDHRA PRADESH POWER GENERATION CORPORATION LIMITED
VIDYUT SOUDHA:: VIJAYAWADA – 520004
NOTICE INVITING TENDER (NIT)
1.

Department Name

Andhra Pradesh Power Generation Corporation Limited

2.

Circle/ Division
Name
Tender Specification
No.
Name of Work

Chief Engineer /HPC & Hydel Projects /APGENCO
Vidyut Soudha, Gunadala, Vijayawada-520004
e-1005078/HPC&HP/SPV Modules/APGENCO/ 2026

Estimated Contract
Value
Transaction fund

NA

3.
4.

5.
6.

Supply, testing, packing and forwarding, insurance,
transportation and unloading of 1.65 MWp SPV modules,
ground-mounted, grid-connected of capacities 320 Wp /
325 Wp / 330 Wp Solar Photovoltaic (SPV) modules at 400
MW Solar Power Project site at Talaricheruvu, Tadipatri,
Ananthapuramu District, Andhra Pradesh.
(or)
Alternatively, Supply, testing, packing and forwarding,
insurance, transportation and unloading of 1.65 MWp SPV
modules ground-mounted, grid-connected of capacities
615Wp/620Wp along with the necessary structure
modification/rework of the existing Module Mounting
Structures (MMS), wherever required, to ensure proper
installation and compatibility with the supplied modules
including Installation, testing & commissioning of 1.65
MWp SPV modules (Installation as per the quantity
required at site) at 400 MW Grid-Connected Solar PV Power
Project at Talaricheruvu (V), near Tadipatri, Anantapuramu
District, Andhra Pradesh.

All the participant bidders shall pay online, a nonrefundable TRANSACTION FEE, to M/s. APTS LTD,
through "Payment Gateway Service on AP e-procurement
platform". The amount payable is 0.03% of the Quoted
Value/Estimated Value, with a cap of Rs.10,000/- plus
applicable GST up to Rs.50.0 crores and Rs.25,000/- plus
applicable GST above Rs.50.0 crore. The Electronic
Payment Gateway accepts all Master and Visa Credit Cards
issued by any bank and Direct Debit facility/Net banking
of select Banks such as ICICI Bank, HDFC, Axis Bank etc,
to facilitate the transaction. Service tax, Bank Charges for
Credit Card Transactions etc, will be applicable.

<!-- page 4 -->

7.

Corpus Fund or AP
e-procurement Fund

8.

Delivery Period

The successful bidder has to pay AP e-procurement fund,
0.04% of Quoted Value/ Estimated Value, with a cap of
Rs.10,000/- plus applicable GST up to Rs.50.0 crores and
Rs.25,000/- plus applicable GST above Rs.50.0 crore on AP
e-procurement platform, before entering into agreement/
issue of purchase orders. The amount shall be paid in
favour of the Managing Director, APTS. There shall not be
any charge towards AP e-procurement fund in case of
works, goods and services with Quoted Value upto Rs.10
lakhs.
The material shall be supplied within 2 months from
placing of Purchase Order.
The service portion of the work shall be commenced within
7 days from the date of intimation by the Field Engineer
and shall be completed within 30 days from the date of
handing over of the site.

9.

Tender Type

Open tender through online AP e-procurement platform.
Two-part type:
Part-I: Pre-qualification/Technical Bid
Part-II: Price bid

10.

Tender Category

Common Products / Services

11.

Bid Security (EMD)

Rs. 1,00,000.00 + 2% of the quoted value shall be submitted in
the following forms towards bid security.
The EMD shall be paid in any of the following forms
i) Non-PEMD Holders: Rs.1 Lakh in the form of
NEFT/RTGS/DD and balance amount in the form of
NEFT/RTGS/DD or Bank Guarantee from any Govt.
Banks/Nationalized Banks/Public Sector Banks/ Scheduled
banks or in the form of insurance surety Bond in the
prescribed Proforma.
ii) PEMD Holders: Rs.1 Lakh in the form of NEFT/RTGS/ DD
and balance amount (2% of the quoted value – Amount of
PEMD) in the form of NEFT/RTGS/ DD or Bank Guarantee
from any Govt. Banks/ Nationalized Banks/ Public Sector
Banks/ Scheduled banks or in the form of insurance surety
Bond in the prescribed proforma.
iii) Bidders registered under MSME shall furnish the exemption
letter from payment of EMD issued by APGENCO. MSME
registered bidders shall invariably obtain the EMD
exemption certificate from APGENCO and submit with PQB
documents. Failure to do so they are liable to attract rejection
of EMD exemption claim.

12.

Bid Security Payable
to

1. DD shall be drawn in favour of Pay Officer, APGENCO,
Vidyut Soudha payable at Vijayawada

<!-- page 5 -->

13.

2. The Bank Guarantee shall be obtained from any Govt.
Banks/Nationalized Banks/ Public Sector Banks/
Scheduled banks in the prescribed format (refer to the
Annexure). The B.G. shall have the validity for a period
of 270 Days from the date of opening of pre-qualification
with claim period of 6 months thereafter.
3. Insurance surety Bond in the prescribed Proforma (refer
to the Annexure) with validity for a period of 450 Days
from the date of opening of pre-qualification thereafter.
4. Direct Credit to APGENCO Account either through NEFT
or RTGS.
APGENCO Bank account details for NEFT/ RTGS
Account No.52077965022,
IFSC Code: SBIN0016576, Branch - Specialized MID
Corporate Branch, Vijayawada.
28-10-2026, @ 17.00 Hrs

17.

Schedule Available
Date & Time
Bid Submission
Closing Date &Time
Pre-Qualification bid
Opening Date.
Price Bid Opening
Date & Time
Tentative)
Bid Validity

180 days from the date of opening of PQ/Technical Bid

18.

Bid Submission

Online through AP E-Procurement platform

19.

Eligibility Criteria

a) The Bidder shall be a manufacturer/supplier/
Authorized dealer of Solar Photovoltaic (SPV) modules.
The bidder may offer supply of modules of his own
manufacture or sourced from other manufacturers. The
bidder shall produce a proof from the concerned
authorities such as Manufacturer’s Authorization
Letter, dealership certificate or any other valid
supporting document.
b) The bidder shall have supplied a minimum cumulative
capacity of at least 2 MWp during the last Seven (7)
years.
c) The bidder or the offered manufacturer shall have
supplied 500 kWp modules to at least one plant in
India, and the supplied modules should have been in
successful operation for a minimum period of one (1)
year as on the date of publication of bid.
d) The bidder shall upload satisfactory performance
certificates of the make to be supplied (not older than
ten years) issued by the end users, along with all
relevant documents such as copies of Contracts/
Purchase Orders/ Completion Certificates, etc., to

14.
15.
16.

18 -11-2026, @ 15.00 Hrs
19-11-2026 @ 12.00 Hrs.
02-12-2026 @ 12.00 Hrs

<!-- page 6 -->

20.

Site Location

21.

22.

Officer Inviting Bids
and Place of
Opening of Tenders
Address

23.

Contact Details

substantiate or to showcase the meeting to the above
requirement. In case the bidder proposes to source from
other manufacturers, the bidder shall also upload a
satisfactory performance certificate of the respective
sourced manufacturer issued by the end users.
e) The bidder should have an annual turnover of not less
than Rs. 5.2 crores for at least ONE year during the last
three (3) financial years. The bidder should enclose
copies of the audited Annual Turnover certificates and
financial statements for the three (3) Financial years
viz., 2023-24, 2024-25 & 2025-26 so as to prove the
financial capacity of the bidder to execute the order.
f) The Bidder shall have Registration Certificate under
GST and a copy of these shall be submitted as part of /
along with the bid.
400 MW Solar Power Project site at Talaricheruvu,
Tadipatri, Ananthapuramu District, Andhra Pradesh515415.
Superintending Engineer, Hydel-I, APGENCO, 4th Floor,
Vidyut Soudha, Gunadala, Vijayawada-520004, AP.
Chief Engineer/ HPC&HP, APGENCO, 4th floor, Vidyut
Soudha, Gunadala, Vijayawada – 520 004.
O/o. Superintending Engineer/ Hydel-I, APGENCO,
4th Floor, Vidyut Soudha, Gunadala, Vijayawada-520004.
Phone: 0866 – 2526801/320/323
Email: se-hpc1@apgenco.gov.in

Note: Responsibility for correctness of the information submitted in the online
bid lies with the bidder. If any information furnished in the bid is proved to be
false at a later date, the bid will not only be rejected but the bidder will be
BLACK LISTED.

Sd/Superintending Engineer
Hydel-I/APGENCO
Vidyut Soudha, Vijayawada

<!-- page 7 -->

CHECK LIST
1.

The following documents pertaining to Pre-Qualification & Technical bid
should be uploaded in “C-FOLDER ATTACHMENTS” only:
1.

EMD: DD/BG/PEMD/Insurance Surety Bond as per item.no.11 & 12 of NIT.

2.

Proof of Experience – Minimum two Performance certificates along with Job
order copies establishing experience.

3.

Proof of Financial capacity- Annual Turnover Certificates (with authentication
of Chartered Accountant) along with Balance Sheets (Financial statements)
for last three financial years.

4.

Proof

of

Technical

Capability

–The

Guarantee

Technical

particulars

along with full Technical details, type test reports and other relevant
documents of the equipment to be supplied.
5.

Registration Certificates: Copies of documents relating to the Registration of
the firm, Partnership deed, Articles of Association.

6.

Guaranteed Technical Particulars: Sheet (in the format enclosed with Tender)
along with full Technical details of the SPV modules to be supplied

7.

Income Tax Registration: Copy of PAN and I.T returns

8.

GST Registration: Copy of GST registration.

9.

Schedules: Filled in Schedules 1 to 6 (formats enclosed in the tender)

10.

Miscellaneous

documents:

Any

other

documents/issues

related

to

PQ/Technical matters and details
2.

Copies of the following Price Bid documents shall be uploaded in
“ATTACHMENTS FOLDER” which will be visible after Price bid opening
only:

1.

Price Summary Proposal sheet duly indicating GST as per Schedule-A.

2.

Any other items/issues related to Price bid/ Price of services can also be
uploaded.

NOTE: 1) Uploading of Documents in the respective folder of AP e procurement
platform will only be considered. Any wrong attachments will lead to
disqualification of the bid.
2) Hard copies shall be submitted by the successful bidder (L1) for
verification if asked by the Competent Authority.

<!-- page 8 -->

INSTRUCTIONS TO BIDDERS
The instructions given below must be read very carefully, as failure in compliance
with any of these may render the offer liable for rejection. If a bidder has any doubt
about the meaning of any stipulation therein, General Purchase Conditions,
technical specification or any other enclosed document, they should immediately
obtain the clarification/ information in writing from the executive who has issued
these documents.
APGENCO or CORPORATION or PURCHASER: shall mean Andhra Pradesh Power
Generation Corporation Ltd., (a Govt. of A.P Undertaking), a company incorporated
in India under Companies Act 1956, having its Regd. Office at Vidyut Soudha,
Hyderabad–500082, (AP).
SUPPLIER or CONTRACTOR or VENDOR or SUCCESSFUL BIDDER: shall mean the
Bidder on whom LOI/PO is issued against this Tender Specification.
APGENCO’s standard terms & conditions are stipulated in this Tender Specification.
Requirements specific to this enquiry are stipulated in the remaining sheets and will
take preference over the standard terms, in case of any ambiguity. The tenderers are
requested to read the Corporation General Terms and Conditions furnished in this
Tender Specification.
1) Registration with e -Procurement platform:
i)

The bidders need to register on the electronic procurement market place of
Government of A.P., that is, www.eprocurement.gov.in. On registration on
the e-procurement market place they will be provided with a user ID and
password by the system using which they can submit their bids on line.
ii) For any queries on registration and online bid submission, on e -Procurement
platform, the bidders may contact HELP DESK of Service provider, on
https://tender.apeprocurement.gov.in.
2) Tender Document:
i) The Bidder is requested to download the tender document and read all the
terms and conditions mentioned in the tender Document and seek
clarification, if any, from the Tender Inviting Authority. Any offline bid
submission clause in the tender document could be neglected.
ii) The Bidder has to keep track of any changes by viewing the
Addendum/Corrigenda issued by the Tender Inviting Authority, from time to
time, in the e-Procurement platform. The Department calling for tenders shall
not be responsible for any claims/problems arising out of this.
3) Digital Certificate authentication:
i)

The bidder shall authenticate the bid with his Digital Certificate for
submitting the bid electronically on e-Procurement platform. Bids not
authenticated by digital certificate of the bidder will not be accepted on the
e -Procurement platform.
ii) For obtaining Digital Signature Certificate, you may please Contact:
Andhra Pradesh Technology Services Limited, 3 rd floor, R&B Building, MG
Road, Labbipet, Vijayawada-520010, Phone:0866-2468108.

<!-- page 9 -->

(OR)
Any other Registration Authority of TCS-CA in India.
The city-wise list of RAs can be accessed by clicking the link "Apply for a
Class-2 Certificate" under "Enroll" section in the website https://www.tcsca.tcs.co.in/mca21/index.jsp
4) Submission of Hard copies:
i)

As per GO No.174 dt.1/9/2008, the requirement for Submission of
Original Hard Copies of the uploaded scanned copies of DD/BG towards
EMD etc, before opening of Price Bids shall be dispensed with.
ii) All the Bidders shall invariably upload the scanned copies of DD/BG & all
other documents in e-Procurement System. This will be the primary
requirement to consider the bid responsive.
iii) Technical Bid evaluation shall be carried out, solely based on the
Documents/ Certificates etc uploaded in the e -Procurement system and
Price Bids of the responsive Bidders shall be opened.
iv) The Purchaser Department shall notify the successful bidder for
submission of original hard copies of all uploaded documents, DD/BG
towards EMD etc, for ensuring their genuineness/authenticity, prior to
entering into agreement or placement of Order. The Successful Bidder
shall, at his sole risk & responsibility, submit the same to the Tender
Inviting Authority, before stipulated date & time.
v) In case, the successful Bidder fails to submit the Original Hard Copies of
uploaded Certificates/Documents, DD/BG towards EMD etc, within the
stipulated date & time (OR) if any variation is noticed in the uploaded
documents and the original hard copies submitted by the successful
Bidder, appropriate penal & deterrent action will be taken as per the rules
in force.
vi) If any of the documents furnished by the bidder is found, at any point of
time, to be false/fabricated/bogus, such Bidder is liable for black listing,
forfeiture of the EMD, cancellation of work and criminal prosecution.
5) Payment of Transaction Fee:
All the participant bidders shall pay online, a non-refundable TRANSACTION
FEE, to the Service Provider through "Payment Gateway Service on eProcurement platform". The amount payable is 0.03% of the Quoted Value,
with a limit of Rs. 10,000/- plus applicable GST for Quoted value upto Rs.50.0
crores and Rs. 25,000/- plus applicable GST for Quoted value above Rs.50.00
crores. The Electronic Payment Gateway accepts all Master and Visa Credit
Cards issued by any bank and Direct Debit facility/Net Banking of select
Banks such as ICICI Bank, HDFC, Axis Bank etc, to facilitate the transaction.
Service tax, Bank Charges for Credit Card Transactions etc, will be applicable.
6) Bid Submission Acknowledgement:
The bidder shall complete all the processes and steps required for Bid
submission. The system will generate an acknowledgement with a unique bid
submission number after completing all the prescribed steps and processes
by the bidder. Users may also note that the bids for which an
acknowledgement is not generated by the e Procurement system are treated

<!-- page 10 -->

as invalid or not saved in the system. Such invalid bids are not made available
to the Tender Inviting Authority for processing the bids. The Government of
AP and Service Provider are not responsible for incomplete bid submission by
users.
7) Corpus Fund or e Procurement Fund:
User departments shall collect, towards e -Procurement fund, 0.04% of
Quoted value with a limit of Rs. 10,000/- plus applicable GST for Quoted value
upto Rs.50.0 crores and Rs. 25,000/- plus applicable GST for Quoted value
above Rs.50.00 crores, from successful bidders on e-Procurement platform,
before entering into agreement/ issue of purchase orders. The amount shall
be paid in favour of the Managing Director, APTS. There shall not be any
charge towards e-Procurement fund in case of works, goods and services with
Quoted value upto Rs.10 lakhs.
8) DISCLAIMER:
i)

This Tender Specification, and any subsequent addenda/amendments etc,
will be made available on e -Procurement platform & APGENCO’s website,
and can be downloaded free of cost. The Bidders shall be solely responsible,
for ensuring that their Bids are completely in line with the requirements
stipulated therein.
ii) Prospective Bidders are advised to intimate the undersigned, about their
interest to participate in the tendering process, so as to enable this Office to
keep them informed about any updations on the subject.
iii) Any discrepancies in the requirements stipulated in these documents, shall
be brought to the notice of the undersigned, and clarifications shall be
obtained prior to submission of Offer itself.
Bidders are advised not to make any assumptions or inferences, on their own.
iv) Since Bids are invited in single part, in case the particulars furnished in the
Price Bid are found to be at variance with the terms & conditions etc indicated
in the Techno-Commercial Bid, the Bid will be processed at the terms which
are more advantageous to APGENCO.
v) Notwithstanding anything stated above, APGENCO reserves the right to
assess the tenderers’ capability to execute the contract, should the
circumstances warrant such assessment in the Overall interest of APGENCO.
In respect of Qualification of the tenderers, the decision of APGENCO is final.
vi) It is not binding on APGENCO to accept the lowest Bid, or any other Bid.
APGENCO reserves the right to place Orders on different Bidders or reject any
or all tenders without assigning any reason.
vii) The Bids will be opened at the time and date specified in the tender notice by
Superintending Engineer or his authorized assistant in the presence of such of
the tenderers or their authorized representatives with valid authorization, who
may desire to be present.
viii) The price bids of such tenderers who are determined to have complied with
the eligibility criteria will only be opened.

<!-- page 11 -->

ix) If due date for opening of the tenders happens to be a Public holiday, the
opening of tenders will be done on the next working day at the same time
specified originally for opening.
x) The contractors have to upload the information preferably in Zip format. Any
other condition regarding receipt of tenders in conventional method
appearing in the tender documents may please be treated as not
applicable.
1.2 EVALUATION OF BIDS:
a) Bids will be processed in two stages (two part bid). In the first stage, the "Bid"
under e-procurement package will be opened to assess whether the Bidder
qualifies and their offer is technically acceptable and substantially responsive.
The Purchaser will examine the Bids to determine whether they are complete,
whether required certificates have been furnished, whether the documents have
been properly signed, whether relevant hard copies have been furnished and
whether the Bids are generally in order. The bids of only such Bidders whose
bids are technically and commercially in accordance with the specification will
be considered for second stage of Price Bid opening/ evaluation. The on-line
system will not open the price-bids of tenderer who are not qualified in
Technical/PQ.
b) A responsive Bid is the one which accepts and fulfils all the terms and conditions
of this specifications and documents, supported by the necessary sureties, and
are complete in respect of details as requested in the Bid document.
1.

The responsive Bids received will be evaluated by the Purchaser to
ascertain the lowest evaluated Bid for complete works covered under
these specifications and documents.

2.

The purchaser is the final authority in deciding the above and his
decision cannot be contended.

1.

The tenders which contain the full information and which comply with the
requirements regarding technical and financial qualifications, experience
will be considered.

2.

Intending bidders can contact the O/o. the Superintending Engineer, Hydel-I,
APGENCO, 4th Floor, Vidyut Soudha, Vijayawada - 520004 for any
clarification/information on any working day during working hours. Phone: 0866
– 2526801/320/323.

3.

APGENCO reserves the right to respond to any e-mail received by it through their
website. APGENCO does not warrant the privacy and/or security of e-mails
during internet transmission.

4.

APGENCO reserves the right, without prejudice to other rights under terms and
conditions of the NIT and tender documents or other remedies available to cancel
tenders without assigning any reasons and will not entertain any
correspondence in the matter. APGENCO accepts no liability whatsoever and will
not be liable for any loss or damage arising directly or indirectly (including
special, incidental or consequential loss or damage) from use of AP eprocurement website or from cancellation of tenders.

<!-- page 12 -->

5.

Responsibility for correctness of the information submitted in the online bid lies
with bidder. If any information furnished in the bid is proved to be false at a later
date, the bid will not only be rejected but the bidder will be BLACKLISTED.

1.3 Tendering Procedure:
1. The online tender shall be submitted in two parts (i.e.) Part-I & Part-II.
Part-I called Pre-qualification/Technical bid should contain financial
standing, record of previous technical experience and commercial terms
etc., specified in the specification.
In Part-II the price bid shall be uploaded in a commercial bid template only.
If uploaded in Pre-qualification/Technical bid template the tender will be
disqualified.
2. All the Bidders shall invariably upload the scanned copies of
DD/BG/Insurance Surety Bond & all other documents in AP eProcurement System within the stipulated date and time mentioned in the
tender specification. This will be the primary requirement to consider the
bid as responsive.
3. The Pre-qualification/Technical bids (Part-I) received through online shall
be opened at the time & date mentioned in the tender specification.
4. Pre-qualification/Technical Bid evaluation shall be carried out, solely based
on the Documents/ Certificates etc uploaded in the AP e-Procurement
system. Price Bids (Part-II) of the qualified Bidders shall be opened.
5. The price bids of the qualified bidders shall be evaluated as per the terms
& conditions of the tender specification.
1.4 Earnest Money Deposit (EMD): Offers must accompany EMD as per S.No.11
of NIT.
1.4.1 The EMD shall be forfeited, if
1.

Bidder withdraws the bid before expiry of its validity.

2.

Successful bidder does not accept the order/LOI or fails to enter into a
contract within validity period of offer.

3.

Successful bidder fails to furnish Security Deposit within 30 days from the
date of issue of P.O/ LOI.

4.

The offer is disqualified for the reasons outlined in clause 1.7.

1.5 Permanent/ Standing EMD Holders: The bidder may deposit with APGENCO,
the permanent fixed deposit of Rs.5,00,000/- (Rupees Five Lakhs only) as
EMD in the form of DD/Pay order/ Banker’s cheque. In case of BG/Surety
Bond, it shall be valid for a period of three years constituting the said sum as
security for the compliance with the obligation undertaken in the offer
submitted by the bidder. No interest will be payable on such amount. Such
bidder shall be entitled to have them considered without payment of EMD
upto Rs.5Lakhs with each tender separately. They need to furnish the

<!-- page 13 -->

Registration Certificate Number and shall also furnish a copy of certificate
along with the offer.
1.6

The fact of having enclosed the EMD, in requisite forms as indicated (1.4), or
bidder holding permanent EMD (1.5), shall be clearly mentioned in their offer,
failing which their offer will not be considered for evaluation whatsoever.

1.7 Post tender rebates or deviation in quoted prices and/or conditions or any other
such offers which will give a benefit to the bidder will not only be rejected
outright but also the original offer will itself get disqualified on this
account, and bidders EMD shall be forfeited.
1.8

Bidders may note that due date and time of opening the bids shall be adhered to
and accordingly, if they wish to witness the bid opening, they should bring
necessary authorization letter from the organization.

1.9

Standard printed conditions of the bidder if uploaded with their offer will not be
accepted.

1.10

Validity of offers: The offer shall be valid for period of 180 days from the date
of opening of Pre-qualification/Technical bids. The period of validity cannot be
counted from any other date other than the date of opening the PQ bid. During
this period bidder shall not be permitted to withdraw or vary their offers, once
made and if they do so, the EMD shall be forfeited.

1.11 Income Tax Certificate: The bidder shall submit along with their offers, the latest
valid Income Tax returns for at least two years during the last three years.
1.12 Past Experience: The list of consumers, to whom the bidder had supplied
identical materials in the past along with P.O details and performance report, if
any, shall be furnished.
1.13 Acceptance of APGENCO Payment Terms: The bidders will be loaded in price
evaluation @ 1.25% of landed cost per month for deviation in payment terms.
1.14 Price Basis: The bidder shall quote FIRM prices in Indian Rupees, the quoted
prices shall include all charges for carrying out the tests and submission of
comprehensive test reports. Taxes and duties like GST shall be indicated
separately.
1.15 Transit Insurance: Bidder shall quote FOR Destination prices inclusive of transit
insurance charge till such time material is unloaded at Project site including 30
days’ storage period. All the damaged parts during transit or otherwise, if any,
are to be made good or replaced with good ones by the bidder/ supplier
irrespective of the settlement of claims with insurance company.
1.16 Goods & Services Tax: The offered prices shall be exclusive of GST. The rate
applicable shall be shown separately. GST will be paid to the seller at the rate at
which it is liable to be assessed/actually assessed on the date of supply. In case
the bidder stipulates GST extra as applicable at the time of dispatch and specifies
the present rate of GST (in numeric percentage or NIL), the offer shall be
evaluated considering rate of GST for the product as per rate of Govt. of India or
as evident from bids received from other bidder. However, liability of APGENCO

<!-- page 14 -->

shall be restricted to actual GST paid at the time of dispatch subject to
production of Tax Invoice.
1.17 Cost Compensation for Deviation: Deviations specifically declared by the
bidders in respective deviation schedules of bid proposal sheets only will be
taken into account for the purpose of evaluation. The bidders are required to
declare the prices for the withdrawal of the deviations declared by them in the
deviation schedules. Such prices declared by bidders for the withdrawal of the
deviations in the deviation schedule shall be added to the bid prices to
compensate for these deviations. In case prices for the withdrawal of deviations
not furnished by the bidder, the APGENCO shall convert such deviations into
Rupee value and add to the bid price to compensate for these. In determining
the Rupee value of the deviations, the APGENCO will use parameters consistent
with those specified in the specification and documents and/or other
information as necessary and available with APGENCO. In case the bidder
refuses to withdraw, the EMD of bidder shall be forfeited. Bidder may note that
deviation variations and additional condition etc. found elsewhere in the bid
other than those stated in the Deviation schedules, save those pertaining to any
rebates, shall not be given effect to in evaluation and it will be assumed that the
bidder complies with all the conditions of bidding documents. In case bidder
refuses to withdraw, without any cost to APGENCO, those deviations, which the
bidder did not state in the deviation schedules, the EMD of the bidder may be
forfeited.
Offer should strictly be in conformity with specifications as stipulated in this
tender. In case no deviations are indicated, it shall be taken
for granted that the offer strictly as per APGENCO requirements.
1.18 Delivery Period: The material shall be supplied within 2 months from placing
of Purchase Order.
The service portion of the work shall be commenced within 7 days from the date
of intimation by the Field Engineer and shall be completed within 30 days from
the date of handing over of the site.
1.19 Delivery Schedule: The material shall be offered for inspection, 7 days in
advance to depute APGENCO representative and the material shall be delivered
within 10 days from the date of issue of dispatch clearance. The offered delivery
period shall be based on delivery schedule indicated in the tender. In case of
any deviation, the bidder shall offer his best, realistic and firm delivery, which
shall be specific and guaranteed.
1.20 It is not binding on APGENCO to accept the lowest or any bid. The corporation
reserves the right to revise the quantities at the time of placing order. The quoted
rates, terms and conditions shall apply. APGENCO further reserves the right to
accept or reject any/all bids without assigning any reasons thereof.
1.21 Bidders are requested to fill in the enclosed Proforma (Schedule-2) for General
Terms and conditions and submit the same in duplicate along with their offer.
1.22 Make/Brand of items offered shall be specified. It shall be appreciated if one copy
of detailed descriptive literature/pamphlets shall be enclosed along with the offer
which may help technical evaluation.

<!-- page 15 -->

The test certificates of the offered materials shall be furnished from any Govt.
recognized test house;
1.23

If the bidder is on DGS&D Rate contract for item(s) covered enquiry. A copy of
the same shall be enclosed along with the offer.

1.24 Amendment of Bidding Documents:
a) At any time prior to the due date & time for submission of bids, the Purchaser may,
for any reason, whether at its own initiative or in response to a clarification
requested by a prospective Bidder, modify the Bidding Documents by amendment
through e –platform.
b) In order to allow prospective Bidders reasonable time to make the amendment into
account in preparing their bids, the Purchaser may, at his discretion, extend the
due date & time for the submission of bids.
1.25 Language of Bids: The Bid prepared by the Bidder and all correspondence and
documents relating to the bid exchanged by the Bidder and the Purchaser, shall be
written in English language only.
1.26 Documents Comprising Online Bid:
List of all documents which shall be submitted as softcopies/ hardcopies are given
in the Check List. The documents which shall be submitted as softcopies shall be
signed, stamped and scanned and uploaded during bid submission. The
documents which shall be furnished as hardcopies shall be signed, stamped
and sent as and when requested by the tender inviting Authority by the
successful bidder.
1.27 Articles of Association:
1. All Bids must be accompanied by duly authenticated copies of the documents
defining the constitution of the company, power of attorney and other relevant
documents, and any bid submitted by a partnership firm must be accompanied by
duly authenticated extracts from the partnership deed or other documents, so as
to show by which person and in what manner contracts may be entered into by or
on behalf of the company, partnership for the due execution of such contracts and
responsibilities.
2. The said documents must be legalized by the local authorities at the place of issue.
Such documents should indicate current address of the firm and full name and
current address of all partners of the firm.
3. Any Bid not containing these documents, or if such documents are incomplete, or
do not conform to the aforesaid forms, may at the discretion of the Purchaser be
excluded from the judicature.
1.28 The Purchaser may, at his discretion, extend the due date & time for the
submission of bids through online corrigendum. However, all rights and
obligations of the Purchaser and Bidders previously subject to the due date & time
will thereafter be subject to the due date & time as extended.

<!-- page 16 -->

1.29 Authentication of Bidding:
1. If the tender is made by an individual, it shall be signed by the individual
above his full name and current address.
2. If the tender is made by a proprietary firm it shall be signed by the proprietor
above, his full name and the full name of his firm with its current address.
3. If the tender is made by a firm in partnership, it shall be signed by all the
partners of the firm above their full names and current address, or by a
partner holding the power of attorney for signing the tender in which case a
certified copy of the power of attorney shall accompany the tender. A certified
copy of the partnership deed, current address of the firm and the full names
and the current addresses of all the partners of the firm shall also accompany
the tender.
4. If the tender is made by limited company or a limited corporation, it shall be
signed by a duly authorized person holding the power of attorney for signing
the tender in which case a certified copy of the power of attorney shall
accompany the tender. Such limited company or corporation may be required
to furnish satisfactory evidence of its existence before Contract is awarded.
5. If the tender is made by group of firms, the sponsoring firm shall submit
complete information pertaining to each firm in the group and state along with
the bid as to which of the firms shall have the responsibility for tendering and
for completion of the Contract document and furnish evidence admissible in
law in respect of the authority assigned to such firm on behalf of the group of
firms for tendering and for completion of the Contract document. The full
information and satisfactory evidence pertaining to the participation of each
member of the group of firms in the tender shall be furnished along with the
tender.
6. The documents or information as required by paras “(a) to (e)” herein above
must be uploaded by the tenderer.
7. All witnesses and sureties shall be persons of status and probity and their full
names, occupations and addresses’ shall be stated below their signatures.
8. All signatures in the tender documents uploaded shall be dated.
Sd/Superintending Engineer
Hydel-I/APGENCO
Vidyut Soudha, Vijayawada

<!-- page 17 -->

2. General Purchase Conditions (General)
Intent of Bid
The intent of the bid is to invite proposal from the bidders capable to supply
1.65 MWp SPV modules of capacities 320 Wp / 325 Wp / 330 Wp, or alternatively,
modules of capacities 615Wp/620Wp along with the necessary structure
modification/rework of the existing Module Mounting Structures (MMS), wherever
required, to ensure proper installation and compatibility with the supplied modules
including Installation, testing & commissioning of 1.65 MWp SPV modules
(Installation as per the quantity required at site) for the 4×100 MW Grid-Connected
Solar PV Power Project at Talaricheruvu (V), near Tadipatri, Anantapuramu District,
Andhra Pradesh.
Bidders are advised to visit the site before participating in the tender.
2.1 The following terms and expressions herein used shall have the meaning as
indicated therein:
Contractor/ Vendors/ Consultant: Shall mean the individual; firm or company
whether incorporated or otherwise in whose name this purchase order is
addressed and shall include its permitted assigns and successors.
Purchaser/ Corporation: Shall mean Andhra Pradesh Power Generation
Corporation Limited., (A Government of A.P. Undertaking), a company
incorporated in India under Companies Act 1956, having its Registered Office at
Vidyut Soudha, Gunadala, Vijayawada –520004, Andhra Pradesh.
Contract / Agreement: shall mean the Purchase Order.
2.2 Reference: This purchase order number must appear on all the correspondence,
packing slips, invoices, drawings or any other document or paper connected with
this purchase order.
2.3 Specifications and drawings: Any information or details which are included in
the specification but not indicated in the drawings and vice-versa shall have the
same effect and meaning as if included for and shown both in the specifications
and drawings. In case of any dispute between the specifications and drawings,
the decision of the Board or its authorized representative shall be final and
binding.
2.4 Additions/ Alteration/ Modifications: APGENCO reserves the right to make
additions/ alterations/ modifications to the quantity of items in the purchase
order. The supplier shall supply such quantities also at the same rate as
originally agreed to and incorporated in the purchase order. The variation shall,
however, be limited to +/- 20% of the ordered quantity.
2.5 Waiver: Any waiver by the authority or any breach of the terms &conditions of
the purchase order shall not constitute any right for subsequent waiver of any
other terms and conditions.
2.6 Subletting and Assignment: The contractor shall not, save with prior consent in
writing of the Corporation, sublet, transfer or assign this order or any part thereof
or interest therein or benefit or advantage thereof in any manner, whatsoever.
Provided nevertheless that any such consent shall not relieve the supplier from
any obligation, duty or responsibilities under the contract.

<!-- page 18 -->

2.7 Information Provided by APGENCO: All drawings. Data and documentation that
are given to the suppliers by APGENCO for the execution of the order are the
property of APGENCO and shall be returned back when demanded. Except for
the purpose of executing the order of APGENCO, supplier shall ensure that the
above documents are not used for any other purpose. The supplier shall further
ensure that the information given by APGENCO is not disclosed to any person,
firm, body, corporate and/or authority and make every effort that the above
information is kept confidential. All such information shall remain the absolute
property of APGENCO.
2.8. Name Plate: Equipment should be provided with name plate giving full details
of manufacture, capacity and other details as specified in the relevant IS or other
specification stipulated. The purchase order number, date and year of supply
and the words “APGENCO” must be etched on the name plate.
2.9 Interchangeability: All similar materials and removable parts of similar
equipment shall be interchangeable with each other. A specific confirmation of
this should be furnished along with the invoices for the supplies.
2.10

Materials & Workmanship: Supplier shall fully guaranteed that the SPV
modules supplied against the purchase order shall be new and first quality,
according to the specifications and shall be free from defects (even concealed
faults, deficiency in design, materials and workmanship).

2.11 Supplier’s liability: Supplier hereby accepts full responsibility and indemnifies
APGENCO and shall hold APGENCO harmless from all acts of omission and
commission on the part of the supplier, his agents, his subcontractors and
employees in execution of the purchase order. The supplier also agrees to
defend and hereby undertakes to indemnify APGENCO and also hold it
harmless from any and all claims for injury to or death of any and all persons
including but not limited to employees and for damage to the property arising
out of or in connection with the performance of the work under the purchase
order.
2.12 Access to supplier’s Premises: APGENCO and/or its authorized representative
shall be provided access to suppliers and/or his sub-contractor’s premises, at
any time during the pendency of the purchase order, for expediting the supplies,
inspection, checking etc.
2.13 Inspection/checking/ testing: All materials/ equipment to be supplied
against this purchase order shall be subject to inspection/checking/testing by
APGENCO or its authorized representative at all stages and places, before,
during and after the manufacture. All these tests shall be carried out in
presence of authorized representative of APGENCO. Supplier shall notify
APGENCO for the inspection of materials/ equipment when they are ready,
giving at least 10 days’ notice. If upon receipt at our stores, the materials /
equipment do not meet the specifications, they shall be rejected and returned
to the supplier for replacement. In such cases all expenses including to - and fro freight, re-packing charges, transit insurance etc., shall be to the account
of supplier.
Inspection by the authorized representative of APGENCO or failure of APGENCO
to inspect the material/ equipment shall not relieve the supplier of any

<!-- page 19 -->

responsibility or liability under this purchase order in respect of such
materials/equipment not be interpreted in any way to imply acceptance thereof
by APGENCO.
The following PDI (Pre-Dispatch Inspection) of the Solar Module will be done at
the Warehouse.
1.
2.
3.
4.
5.
6.

Open Circuit Voltage(Voc).
Short Circuit Current(Isc).
Pmax, Fill factor, Efficiency
To confirm whether the Modules received from OEM in case of supplier.
Test Reports of all Modules
RFID Card, if available.

2.14 Packing and Marking: All materials/equipment shall be securely packed to
the requirement of transportation by Rail/Road/Sea transport. All exposed
services/ connections/ protrusions shall be properly protected. All unexposed
part shall be packed with due care and the packages should bear the words
‘Handle with Care’. The packing requirements of Rail/ Road transport shall be
complied with so as to obtain clear Railway/ Lorry Receipt i.e. without any
qualifying remarks.
All packages and unpacked materials shall be marked with the name of the
Consignor, Consignee, Purchase Order No., gross and net weight, sign of
handling, if any, with indelible paint in English at least at two places. In case
of bundles, metallic plates marked with the above details shall be tagged with
such bundles.
2.15 Dispatch of materials: The equipment & material shall be dispatched only after
issuance of Dispatch clearance from APGENCO Quality Control wing. The
supplier is responsible for the safe delivery of the goods in good condition at
destination stores. The supplier should acquaint himself of the conditions
obtaining for handling and transport of the goods to destination and shall
include and provide for security and protective packing of the goods so as to
avoid damage in transit. After packing the materials / equipment those shall
be dispatched strictly as per the provision of purchase order. In case any
changes in the mode of transportation and / or transporter has to be done,
the same shall be done only after obtaining prior approval in writing. Normally
the goods shall be dispatched through our approved transporter only. All
formalities related to allotment of wagons, loading permission from railways
shall be completed by the supplier. The supplier shall communicate
immediately the dispatch details to the consignee as specified in the purchase
order. The original dispatch documents shall be forwarded immediately, failing
which the supplier shall be responsible for any delay in payment and
consequential payments of demurrages and wharfages to the transporter.
2.16 Demurrage/wharfage:
a) If Dispatch of materials not through authorized/reputed transporter.
b) Late receipt of invoice or due to violation of any other clause(s) of the
purchase order will be to supplier’s account. Supplier shall also be

<!-- page 20 -->

responsible for all such payments due to late receipt of RR/LR and other
documents.
2.17. Acceptance of order: The Purchase orders will be sent to contractor in
duplicate and he shall return one copy along with enclosures, duly signed and
stamped, within one week in token of having received and accepted the order.
2.18 Failure and Termination: If the bidder fails to deliver proper material as per
the Contract to the satisfaction of the Corporation may without prejudice to any
other remedy available to it, cancel the Contract/Purchase order by serving
notice to bidder and forfeit the SD amount submitted.
2.19 Drawings: The necessary general arrangement drawings, Quality Assurance
Plan and bill of materials of the materials shall be furnished within 10 days
from the date of receipt of PO and got approved by APGENCO before
manufacturing.
2.20 Quality Assurance Plan:
The Supplier shall within 10 days of placement of order, submit the following
information to APGENCO.
1.

Manufacturing quality plan (MQP) as per Annexure-8

2.

Field quality plan (FQP) as per Annexure-9

3.

The names of sub-suppliers selected (sub supplier /subcontractor assessment
& approval by quality department).

4.

Inspection and testing schedules.

5.

Quality Assurance Plan (QAP) with customer hold points (CHP) for Quality
department inspection. QAP’s and QA&I/purchaser customer hold points
shall be discussed between the QA&I/purchaser and contractor and
issuance/Clearance of CHP by quality department before the QAP’s is
finalized. The Supplier shall submit the routine test certificates / compliance
certificates of bought out accessories for raw material at the time of routine
testing if required by the quality department and ensure that the quality
assurance requirements of specification are followed by the contractor/subcontractor.

*The Equipments & Materials shall be dispatched only after issuance of MDCC
from the corporate Quality Department.
2.21 Jurisdiction: All and any dispute or difference arising out of or touching this
order shall be decided only by the courts or Tribunals situated in
Vijayawada/Amaravathi. No suit or other legal proceedings shall be instituted
elsewhere.
Sd/Superintending Engineer
Hydel-I/APGENCO
Vidyut Soudha, Vijayawada

<!-- page 21 -->

3. General Purchase Conditions (Financial)
3.1 Prices: Price(s) mentioned in the purchase order shall be firm and not subject to
escalation on any account, till the order is executed in full and its subsequent
amendments accepted by the contractor even though the completion/
execution of order may take longer time than completion period incorporated
and accepted in purchase order.
3.2 Taxes and Levies: Taxes and other levies payable shall be shown separately in
the invoice. These shall be to the account of Corporation, unless otherwise
mentioned in the purchase order.
3.3 Variations in Statutory Levies: Any variation, upward or down ward, in
statutory levies or new levy is introduced after opening of the bids/ placement of
order under this purchase order shall be to the account of the Corporation,
unless otherwise mentioned in the P.O.; provided that in cases where delivery
schedule is not adhered to by the supplier and there are upward
variation/revision after the agreed delivery date, the bidder/supplier shall bear
the impact of such increased levies and if there is downward variation/revision,
the corporation shall be given advantage to that extent.
3.4

Security Deposit (SD):
a) The successful bidder shall furnish the Security Deposit equal to 2.5% of
value of purchase order within ONE month from the date of issue of
Purchase order for proper fulfillment of full execution of order thereof. The
amount of security deposit shall be forfeited to the extent of financial loss
suffered by the Corporation, if supplier fails to execute the order and fulfill
its terms and conditions.
b)

Security deposit may be furnished in the shape of Demand Draft drawn on
any Govt. Banks/Nationalized Banks/Public Sector Banks/Scheduled
banks, payable to Pay officer/APGENCO or bank guarantee in lieu of cash
from any Nationalized banks/Government Banks/ Public sector banks/
Scheduled banks in prescribed proforma (or) in the form of insurance surety
Bond in the prescribed form (Bank Guarantee/Insurance Surety bond shall
be accepted only if amount of SD is above Rs.10000/-). However, the Bank
guarantee/Insurance Surety Bond shall be valid for a period of 6 months
over and above the delivery period with claim period of 6 months and the
validity of the bank guarantee/ Insurance Surety Bond shall be extended
suitably in case of delay in execution of order. The Earnest Money Deposit
(EMD) of the successful bidder shall be returned by APGENCO after
furnishing of Security Deposit by the successful bidder. The SD amount will
be returned after satisfactory completion of the contract.

c) This amount will be released only when there is no pending obligations or
disputes based on satisfactory completion certificate by the Engineer in
Charge. This amount will not bear any interest.
d)

The Security deposit will be returned back to the contractor as soon as
order is fully executed and there is nothing outstanding either against this
purchase order or any other purchase order placed by the corporation on
the supplier.

<!-- page 22 -->

e)

The work shall be commenced from the dates specified by APGENCO,
otherwise EMD will be forfeited.

3.5 Terms of payment:
a) For supply of 320 Wp / 325 Wp / 330 Wp modules of 1.65MWp
Capacity:
100% of the all-inclusive price of the materials shall be paid within 30 days
on presentation of the contractor’s commercial invoice after receipt and
acceptance of the material in good condition at site against furnishing of
performance security in the form of Bank Guarantee/Insurance Surety
Bond for 10% value of the contract covering the guarantee period with a
claim period of 6 months over and above the Guarantee Period subject to
effective performance of the contract and settlement of liquidated damages
etc.,
b) For supply of modules of capacities 615Wp/620Wp along with the
necessary structure modification/rework of the existing Module
Mounting Structures (MMS) including Installation, testing &
commissioning of 1.65 MWp SPV modules (Installation as per the
quantity required at site):

Within the Contractual delivery period: 70% of the all-inclusive price of the
materials will be paid within 30 days on presentation of the contractor’s commercial
invoice and other relevant documents on receipt and acceptance of the material in
good condition at site against furnishing of Performance security in the form of Bank
Guarantee/Insurance Surety Bond for 10% value of the contract covering the
guarantee period with a claim period of 6 months over and above the Guarantee
Period and the Balance 30% payment shall be paid after successful completion of
the necessary structure modification/rework of the existing Module Mounting
Structures (MMS) including Installation, testing & commissioning modules
(Installation as per the quantity required at site).
Beyond the contractual delivery period: 65% of the all-inclusive price of the
materials will be paid within 30 days on presentation of the contractor’s commercial
invoice and other relevant documents on receipt and acceptance of the material in
good condition at site against furnishing of Performance security in the form of Bank
Guarantee/Insurance Surety Bond for 10% value of the contract covering the
Guarantee period with a claim period of 6 months over and above the Guarantee
Period and Balance 35% payment shall be paid after successful completion of the
necessary structure modification/rework of the existing Module Mounting Structures
(MMS) including Installation, testing & commissioning modules (Installation as per
the quantity required at site) thereafter subject to effective performance of the
contract and settlement of liquidated damages etc.
Note: No interest charges will be paid in case the payment is delayed for any
reason.


Payments shall be made through SBI e-payment system.

APGENCO has implemented SBI e-payment system for arranging payments
towards Supply of Material and Services. Successful Bidder is requested to

<!-- page 23 -->

furnish the Consent form for arranging e-payments subject to Purchase Order
duly signed by Authorized Signatory. A cancelled cheque shall also invariably
be enclosed along with consent letter for verifying the details furnished.
Further, the following is informed:
1) Any request for change of Bank Account will not be entertained during the
currency of the Contract.
2) Any request for issue of Cheque or other mode of payment will not be
entertained during the currency of the Contract after implementation of
automated System.
Note: Consent Form as per Annexure– 7 shall be furnished.

3.6



If the supplier has received any over payments by mistake or if any
amounts are due to the Corporation due to any other reasons, when it is
not possible to recover such amount under the contract resulting out of
this order, the Corporation reserves the right to collect the same from any
other amounts and/or Bank Guarantee given by the supplier due to or
with the Corporation.



When the supplier does not at any time fulfill his obligations in
replacing/rectifying etc. of the damages/defective materials in part or
whole,
promptly to the satisfaction of the Corporation, the Corporation
reserves the
right not to accept the bills against subsequent
dispatches made by the supplier and under these circumstance only the
supplier will be responsible for any demurrage, wharfage or damages
occurring to the consignments so dispatched.

Liquidated damages/ failure and termination:

3.6.1 In the event of any delay in the supplies of ordered materials/ delay beyond
the stipulated date of delivery/ delivery schedule, the Corporation reserves
the right to recover from the supplier a sum equivalent to 0.5% of the value of
delayed materials/ equipment/work for each week of delay and part thereof
subject to a maximum of 5% of the total value of the order.
3.6.2 Alternatively, APGENCO may resort to purchase the materials/equipment from
elsewhere at the sole risk and cost of the supplier and recover all such extra
cost incurred by APGENCO in procuring the materials by above procedure.
3.6.3 Alternatively, APGENCO may cancel the purchase Order completely or partly
without prejudice to its right under the alternatives mentioned above.
3.6.4 In case of recourse to alternative 3.6.2 and 3.6.3 above, APGENCO shall have
the right to repurchase the materials which is readily available in the market
to meet the urgency of requirements caused by supplier’s failure to comply
with the scheduled delivery period irrespective of the fact whether the
materials /equipment are similar not.
3.7 Performance Bank Guarantee: The supplier shall ensure that all SPV modules
under this purchase order shall confirm to APGENCO requirements and
specifications. An additional security for 10% value of the contract in the form
of Bank Guarantee/Surety Bond is essential for satisfactory performance of the
equipment over a period of time. In view of this, the suppliers of

<!-- page 24 -->

material/equipment/ instruments/ machinery shall be required to furnish a
bank guarantee from any Nationalized banks/Government Banks/ Public
sector banks/ Scheduled banks (or) in the form of insurance surety Bond in
the prescribed proforma against any manufacturing defects/ poor
workmanship/ poor performance valid for a period up to Guarantee period with
a claim period of 6 months over and above the guarantee period. In case any
deficiencies are found during guarantee period, the same shall be
repaired/rectified/replaced at free of cost. BG shall be from any Govt.
Banks/Nationalized Banks/Public Sector Banks/Scheduled banks in the
prescribed proforma and the BG/Insurance Surety Bond shall have got
approved by APGENCO. If the supplier fails to furnish the Performance security,
10% of order value will be deducted from the bills. The deducted 10%
performance guarantee amount will be released after expiry of guarantee period
or on furnishing of 10% BG/Insurance Surety Bond.
APGENCO shall at its discretion have recourse to the said Bank
Guarantee/Insurance Surety Bond for recovery of any or all amount due from
the supplier in connection with the purchase order including of the Guarantee
obligations. Checking/ approval of supplier’s drawings, inspection and
acceptance of materials/ equipment furnishing to effect shipment and work
done by Installation, testing and commissioning of the equipment by Supplier
shall not in way relieve the supplier from the responsibility for proper
performance during the Guarantee period.
PBG/Insurance Surety Bond will be released on firm’s request, after satisfactory
completion of the Guarantee Period, after ensuring that there are no pending
claims.
3.8
3.9

Insurance: Supplier shall arrange suitable transit insurance cover at their
risk and cost.
Removal of Rejected Goods and Replacement:
1. If upon delivery, the material/ equipment is found not in conformity with
the specifications stipulated in the purchase order, whether inspected and
approved earlier or otherwise, those shall be unacceptable to APGENCO or
its authorized representative. A notification to this effect shall be issued to
the supplier, normally within 30 days from the date of receipt of materials at
our stores.
2. Supplier shall arrange suitable replacement supplies and remove the rejected
goods within 30 days from the date of notification failing which, the goods
shall be dispatched to vendor by road transport on ‘freight to pay basis’ at
supplier risk and cost.
3. External damages or shortages that are prima-facie the results of rough
handling in transit or due to defective packing shall be intimated within a
fortnight of the receipt of the materials, spares etc. In case of internal defects,
damage or shortages or any internal parts, which cannot ordinarily be
detected on a superficial visual examination, though due to bad handling in
transit or defective packing should be intimated within 3 months from the
date of receipt of these material. In either case the damaged or defective
materials should be replaced by the supplier free of cost to the company.

<!-- page 25 -->

4. If no steps are taken within 15 days of receipt of intimation of defects or such
other reasonable time as company may deem proper to afford, the company
may without prejudice to its other rights and remedies arrange for repairs/
rectification of the defective materials or replace the same and recover the
expenditure incurred from the deposits such as EMD, SD and performance
guarantees or other amounts available with the company or by resorting to
legal action.
5. However, if any advance payment had been made by APGENCO for the goods
so rejected on technical ground, rejected materials shall be returned to the
supplier after receipt of suitable replacement supplies. If the supplier does
not settle the rejection within a period of 60days from the date of notification
from stores, rejected goods shall be sent back to supplier at his risk and cost.
3.10 Force Majeure:
 The supplier shall not be liable for any delay or failing to supply the materials
/equipment for reasons of Force Majeure such as Acts of God, Acts of War,
Act of Public Enemy, Natural calamities, Fires, Floods, Frost, Strikes,
Lockouts etc. Only those causes which have duration of more than 7 days
shall be considered for force majeure.
 The vendors shall within 10 days from the beginning of such delay notify to
APGENCO in writing the cause of delay. APGENCO shall verify the facts and
grant such extension of time as facts justify.
 No price variation shall be allowed during the period of force majeure and
Liquidated damages would not be levied for this period.
 At the option of the APGENCO, the order may be cancelled. Such cancellation,
would be without any liability whatsoever on the part of the APGENCO. In
event of such cancellation, supplier shall refund any amount advanced or paid
to him by the APGENCO and deliver back any materials issued to him by the
APGENCO and release the facilities, if any provided by the Corporation.
3.11

Guarantee Period:
Warranty period is as per Manufacturer product warranty i.e 10 years from date
of installation and Performance warranty 10 years from date of installation
(output peak watt capacity with 0.7% degradation per year, which should not be
less than 93% at the end of 10 years).
A Warranty/Guarantee certificate to this extent shall be submitted along with
the supplies. If during the period of Guarantee, it is found defective of
workmanship or material and/or fails in test/operation due to above defects,
such material shall be repaired or replaced by you free of cost to APGENCO
within a reasonable time before expiry of Guarantee period. After
repairs/replacements if any the material shall be delivered free of charge to the
station and if the supplier is not able to effect such repairs or replacement in
time, APGENCO may at its option, do so at your risks and expenses and
recover the full cost from the bidder. The bidder has to furnish an undertaking
to the effect along with invoice/bills.

3.12 Cancellation of Order: The Corporation reserves the right to cancel the order
in part or in full by giving two weeks’ notice thereby if

<!-- page 26 -->

1.
2.
3.

The Supplier fails to comply with any of the terms of the order.
The Supplier becomes bankrupt or goes into liquidation.
The Supplier makes general assignment for the benefit of the creditors
and
4. Any Receiver is appointed for the property owned by the Supplier.
All the remaining terms and conditions are applicable as per the purchase manual of
APGENCO (Available in APGENCO web site).
Sd/Superintending Engineer
Hydel-I/APGENCO
Vidyut Soudha, Vijayawada

<!-- page 27 -->

TECHNICAL SPECIFICATION
4.1 SPV Module
The Solar PV module comprises of PV cell(s) connected in any combination to
achieve the required module power output. PV cells directly produce DC power
on receipt of solar irradiation. The PV cells in a crystalline silicon module shall
be protected by encapsulation between front glass and back sheet/back glass.
The glass shall be made of high transmissivity and front surface shall give high
encapsulation gain. The Peak power rating of the individual module shall be
either 320Wp/325Wp/ 330Wp (no negative tolerance) or 615Wp/620Wp(no
negative tolerance).
4.2 Specific Parameters and Layout Conditions
The SPV modules to be supplied shall have a proven history of reliability and
stable operation in external applications. Each and every SPV module shall be
checked for conformity with relevant standard and no negative tolerance shall
be accepted. Module should have excellent performance under low light
conditions and good temperature coefficient for better output in high
temperature condition. The selection of solar PV modules would be technology
agnostic to suit the solar projects where humidity levels are high and moisture
ingress is more. The modules with suitable quality back sheets or glass to glass
packed modules shall be used. The modules used shall have proven design and
demonstrated performance in harsh environmental condition.
4.3 Rating & Functional Characteristics
a. Modules shall be made up of poly/mono crystalline silicon cells. The modules
should be PID resistance.
b. Peak power rating of the individual module shall be either 320Wp/325Wp/
330Wp (no negative tolerance) or 615Wp/620Wp(no negative tolerance). Each
module with positive power tolerance guarantee of 0W to +5W to avoid array
mismatch losses (value of positive power tolerance of each module shall not
be added/considered in total peak power rating of the individual module).
c. The module efficiency shall be greater than or equal to 17 % at standard test
condition (STC) and the cell should have minimum fill factor of 0.70.
d. It shall perform satisfactorily in relative humidity ≥85% with ambient
temperature range between (-) 40°C and (+) 850C and shall withstand gust
equal or more than 170 km/h on the surface of the panel and shall be able to
withstand mechanical load as per IEC requirement.
e. The Maximum System Voltage(Vdc) is 1000 V DC.
f.

Rated Power Temperature Coefficient for modules shall be > (-) 0.40% per 0C
for better yield.

g. The solar cell shall have surface anti-reflective coating to help to absorb more
light in all weather conditions.
h. The solar module shall have suitable encapsulation and sealing arrangement
to protect the silicon cells from the adverse environment condition. The
arrangement and the material of encapsulation shall be compatible with the
thermal expansion properties of the silicon cells and the module framing
arrangement/material. The encapsulation arrangement including module
edges shall ensure complete moisture proofing for the entire life of the
modules.

<!-- page 28 -->

i.

The front surface of the module shall consist of impact resistant, low iron,
high energy yield anti reflective and superior transmittance (>90%) tempered
glass with minimum thickness of 3.2 mm.

j.

The interconnected cells shall be laminated in vacuum to withstand adverse
environmental conditions. The EVA(ethyl vinyl acetate) used for the modules
should be of UV resistant in nature with gel content of more than 70%. The
back sheet used in the crystalline silicon based modules shall be of 3 layered
structures. The thickness of back sheet should be of minimum 300 microns
with water vapour transmission rate less than 2.0g/m2/day (38°C at 90% RH).
The back sheet can be fluoro-polymer based or of any other well proven
technology details of which shall be submitted and reviewed during detailed
engineering and shall be subject to Employer’s approval. The back sheet shall
have globally benchmarked durability properties on Moisture barrier, Tensile
Strength (Machine Direction & Transverse Direction), Elongation retention
and UV stability and shall be able to withstand maximum system voltage.

k. The module frame is to be made of corrosion resistant materials, aluminium
anodized finish. The anodizing thickness shall be 15 micron or better. The
frame shall be electrolytically compatible with the structure material used for
mounting the modules. In case the offered module is frameless, suitable
retaining clips/clamps used for installing the modules shall not damage the
glass surface in contact with the retaining clamp.
l.

Protective devices against surges shall be provided to protect the PV modules.

m. The junction box at the back of the module shall be weather proof, dust proof,
UV resistant, free of halogen, and self-extinguishing to avoid fire propagation
designed for long life outdoor operation in harsh environment as per relevant
standard specification. The cables coming out of the junction box shall be
suitably sealed providing complete electric isolation. Protection class of
junction box shall be IP 67 or better rated fitted at the back side which should
be weather proof and designed to be used with standard wiring or conduit
connection. The junction box used in the modules shall be IP 67 Single
Junction Box with 3 Bypass Diodes to prevent hot spots in case of cell
mismatch or shading.
n. Each module should have two suitably sized stranded UV resistant cables and
terminated with DC plug-in connector directly. The positive (+) terminal has a
male connector while the negative (-) terminal has a female connector. The
length of cables used for interconnecting the modules shall be 1200 mm with
4sq.mm MC4 connector.
o. The Contractor shall provide data sheet of the offered module along with the
offer giving details of peak power, peak current, peak power voltage, short
circuit current, open circuit voltage, fill factor etc. and the sample solar PV
module electrical characteristics including current-voltage (I-V) performance
curves and temperature coefficients of power, voltage and current.
p. RF Identification Tag
q. White back sheet should be used in module with big size APGENCO Logo
printed or logo Sticker shall be pasted on it, in size of 2’’× 1’’ sq.inch in blue
colour font. The logo shall be made available to successful bidder.
r.

Name Plate
Each module shall also carry the following clear and indelible markings at the
back of module. Type of labels and fixing of labels shall be such that they are
not likely to peel off/fall off during the life of the panel.

<!-- page 29 -->

(i)

Name, Monogram or Symbol of Manufacturer;

(ii)

Type or Model number & Serial number;

(iii)

Polarity of terminals or leads (colour coding is permissible);

(iv)

Short Circuit Current (Isc), Open Circuit Voltage (Voc)

(v)

Maximum Power (Pmax) , Voltage (Vmp), Current ( Imp)

(vi)

Maximum System Voltage for which the module is suitable;

(vii)

Relevant Standards, Certification lab name

(viii)

Weight of the Module

(ix)

Overall Dimension (W x L x D)

(x)

Module Wp tolerance (If it is cumbersome to supply this marking,
then this marking can be left out)

(xi)

Warnings, if any

(xii)

Date & Place of Manufacture.

4.4 Warranty for Module
Module warranty is defined as “The manufacturer should warrant the solar
module(s) to be free from the defects and/or failures specified below for a period
not less than 10 years from the date of installation. Defects and/or failures due
to manufacturing defects and/or failures due to materials non conformity to
specifications/or due to faulty manufacturing, poor workmanship and/or
inspection process. If the solar module(s) fails to conform to this warranty, the
manufacturer will repair or replace the solar module(s) at the owner’s sole
option”.
4.5 Performance Warranty for Module
Each Solar PV module used in solar power plants/ systems must be warranted
for their output peak watt capacity, which should not be less than 93% at the
end of 10 years.
4.6 Standards
The system and equipment shall be designed, built, tested and installed to the latest
revisions of the following applicable standards. In the event of other standards being
applicable they will be compared for specific requirement and specifically approved
during detailed engineering for the purpose:
S.No

Standards

Description
Design qualification and type approval

1

2

Part-1: Test Requirement
IS 14286 (Part-1, Part-II, Part-2: - Test Procedures
Part 1-Sec-1)
Part-1 & Sec-1: Special requirements for
testing of crystalline silicon photovoltaic
( PV ) modules

IS/IEC 61730- Part-I

Photovoltaic
Modules
safety
qualification- Part-I: Requirements for
Construction

<!-- page 30 -->

3

IS/IEC 61730- Part-II

4

IEC 61701

5

IEC 62804 –1 : 2015

Photovoltaic
Modules
safety
qualification-Part-II: Requirements for
Testing
Salt Mist Corrosion Testing
of
Photovoltaic Modules
Photovoltaic Modules - Test methods for
the detection of Potential Induced
Degradation - Part
1:Crystalline Silicon

4.7 Quality Assurance and Testing
The Contractor shall follow the quality assurance and testing requirements as per
approved “Quality assurance and Testing Specifications (QTS)”.
Type Test
SPV modules must be tested and certified by any of the accredited certifying agencies
according to above mentioned international standards at Clause No. 4.6 and the type
test reports shall be submitted for owner’s approval.
Note:
1. The Module Manufacturer/Supplier, along with the Module datasheet, shall
also provide the Details about the PV Cells used for the offered PV Modules.
The information shall contain Cell Source, Type, and Electrical Parameters
including efficiency, Size, Number of Bus bars and any other relevant
information.
2. Bidder shall submit the Self-certified Electro- Luminescence (EL) Test
reports of all the Crystalline Silicon based PV Modules being offered.
3. The bidder shall submit the type test reports for SPV Modules carried out
within last ten years from the date of techno- commercial bid opening.
4. These reports should be for the test conducted on the equipment similar to
those proposed to be supplied under this tender and the test(s) should have
been either conducted at an independent laboratory or should have been
witnessed by a client.
5. However, if the contractor is not able to submit report of the type test(s)
conducted within last ten years from the date of techno- commercial bid
opening or in the case of type test report(s) are not found to be meeting the
specification requirement, the contractor shall conduct all such tests under
this contract at no additional cost to APGENCO either at third party lab or
in the presence of client/owner’s representative and submit the reports for
approval.
4.8 Documentation to be Furnished by the Supplier
The supplier shall submit the following:







Valid IS 14286 & IS/IEC 61730 Type Test Certificates
BIS CRS Registration Certificate
Flash Test Reports (in digital CSV/PDF format) for 100% modules
EL images for the tested sample modules
Quality Assurance Plan (QAP) covering raw material to finished module
Packing list with module serial numbers

<!-- page 31 -->

Schedule-1
Guaranteed Technical Particulars
S.
No

Description

APGENCO
requirement
(Option 1)

APGENCO
requirement
(Option 2)

1

SPV Module Output
Power

320/325/330 Wp
(no negative
tolerance)

615Wp/620Wp
(no negative
tolerance)

2

Open circuit
voltage ( Voc)

≥ 46 V

Vendor to quote

3

Short circuit
current ( Isc)

≤ 9.4 Amp

Vendor to quote

4

Max voltage ( VMax)

38 V

Vendor to quote

5

Rated current ( IMax)

8.7 Amp

Vendor to quote

6

Maximum System
Voltage (Vdc)

1000 V

1000V

7

Suitability

For gridconnected
system and
ground mounted

For gridconnected
system and
ground
mounted

8

Cable &
Connectors

1200 mm with
4sq.mm MC4
connector

Vendor to
quote

9

Junction Box

IP 67 or better
rated Single
Junction Box
with 3 Bypass
Diodes.

IP 67 or better
rated Single
Junction Box
with 3 Bypass
Diodes.

10

Series Fuse Rating

15 Amp

Vendor to quote

11

Cell Type

72-cell
Mono/Polycrysta
lline

Vendor to
quote

12

Module Efficiency

Min 17%

Vendor to quote

13

Temp Range

-400 C to + 850 C

Vendor to quote

14

Existing Module
Dimensions

1956 x 992 x 36
mm

Vendor to quote

Bidders
confirmation

<!-- page 32 -->

15

Hole to Hole
Dimension

1176 mm

Vendor to quote

16

Weight

22 kg

Vendor to quote

17

Application Class

Class A (Safety
Class II)

Vendor to quote

18

Frame

Anodized
Aluminum
Frame

Anodized
Aluminum
Frame

19

Mechanical Load
Test:

5400 Pa Snow
load, 2400 Pa
wind load

5400 Pa Snow
load, 2400 Pa
wind load

20

Product Warranty

Min 10 Years

Min 10 Years

21

Power Output
warranty

Min 10 Years

Min 10 Years

Note: All specified parameters are at STC (25°C Cell, 1000 W/m² Irradiance,
AM 1.5G Spectrum

<!-- page 33 -->

Schedule – 2
Schedule of General Terms and Conditions
(to be uploaded in the Part-I Pre-qualification bid)
Bidders are requested to fill in the blank space and upload the same along with offer
otherwise their offer will be either treated as non-responsive or suitable cost
compensated for deficiencies as deemed fit by the Corporation.
1

2
3
4
5

6
8
9

10
11
12
13
14
15
17
18
19

20
21
22

Tender Specification
No/Enquiry No., date and
due date
Offer/quotation No. & Date
Name of the bidder
GST Registration No
DGS&D’s Registration No., if
any
(Please enclose copy of rate
contract, if any)
Price Basis (F.O.R.)
Discount, if any
Packing and forwarding
charges
(If price basis ex-works)
GST
Freight charges
Insurance
Whether APGENCO Terms of
payment acceptable
Bank charges
Delivery Period

:

Whether delivery is made in
whole/phased delivery
Mode of dispatch
Confirmation of submission of
Performance Bank Guarantee
for 10% of order value for
performance of Equipment
Guarantee Period

:

Transit Insurance charges
Confirmation of submission of
Security
deposit
Bank
Guarantee/ Demand Draft for
2.5% of order value (for
satisfactory fulfillment of the
contractual obligations)

:
:

:
:
:
:

:
:
:

:
:
:
:

Included/Excluded (Indicate rate)
Included/Excluded
Included/Excluded

:
:

To be borne by seller.
Within _________days/weeks/ Months from
the date of receipt of purchase order.

:
:

:

<!-- page 34 -->

We Confirm acceptance towards the following:
23
24

Validity of offer
Recovery of
Liquidated
Damages
period

:
:

25

Part order

:

26

Price Variation

:

27

Rate Certificate

:

28

Guarantee
Certificate

:

29

Interchangeability

:

180 days from the date of opening of PQ bids
In case of delay in Execution of order beyond
stipulated delivery, APGENCO reserves the right
to recover from the vendor Liquidated Damages
equivalent to 0.5% of the value of delayed
materials for each week or part thereof subject to
maximum of 5% of total value of Purchase Order.
Acceptable
The prices quoted shall remain firm till execution
of full order (in case of any specific price variation
formula, the same shall be mentioned with ceiling
limits. If the bidder quotes for variable prices, Non
furnishing of Ceiling limit and the applicable
formula may lead to disqualification of the
tender.)
It is certified that prices quoted herein are the
same as applicable to other Government
Departments/ Public Sector Undertakings.
Warranty period is as per Manufacturer product
warranty i.e., 10 years from date of installation
and Performance warranty 10 years from date of
installation (output peak watt capacity with 0.7%
degradation per year, which should not be less
than 93% at the end of 10 years).
If during the period of Guarantee, it is found
defective of workmanship or material and/or fails
in test/operation due to above defects, such
material shall be repaired or replaced by you free
of cost to APGENCO within a reasonable time
before expiry of Guarantee period. After
repairs/replacements if any the material shall be
delivered free of charge to the station and if the
supplier is not able to effect such repairs or
replacement in time, APGENCO may at its option,
do so at your risks and expenses and recover the
full cost from the bidder.
It is certified that the quoted items are
interchangeable (If applicable) with the items
existing in APGENCO and if fails to interchange,
the same shall be replaced free of cost.

Signature of Bidder with Name, Designation and Office Seal)

<!-- page 35 -->

Schedule-3
DEVIATIONS FROM SPECIFICATION
Dear Sir,
Sub: Supply
of
__________________________________against
No.___________________ dated________________.

enquiry

***
We hereby confirm that the following are the only Deviations and Variations,
(both Technical as well as commercial), from the Specifications/Requirements
stipulated in the aforesaid Enquiry. These are irrespective of what-so-ever has been
stated to the contrary anywhere else, in Our Offer No.___________, Dt._______. These
Deviations and Variations are exhaustive and except for these, the entire project will
be executed as per the requirements of the aforesaid Enquiry.
S.
No.

Description of Deviation

Ref. Of Page &
Clause of Bid
Documents

Monetary implications of the
conditions, in case of
withdrawal
(Rs. in figures) (Rs. in Words)

(A) Technical

(B) Commercial

Note: The Tenderer should indicate, in this Schedule, the amount(s), if any, which
he would charge extra (in addition to the rates quoted by him), for withdrawing
his conditions/deviations & accepting the condition as stipulated in the
Enquiry.

Date

Signature------------------------

Place

Name---------------------------Designation--------------------(Company’s Seal---------------)

<!-- page 36 -->

Schedule-4
Proforma of letter of transmittal
(To be furnished on Bidder’s Letterhead)
(To be enclosed in prequalification bid)
To
The Chief Engineer (HPC&HP),
A.P. Power Generation Corporation Limited,
Vidyut Soudha, Vijayawada 520004, Andhra Pradesh.
Sir,
Ref:- Tender Specification no:e-1005078/HPC&HP/SPV Modules/APGENCO/2026
:&:
1.

We have carefully examined the conditions, instructions, specifications,
drawings etc. in your tender documents cited above. Having examined the
Tender Specification No. e-1005078/HPC&HP/SPV Modules/APGENCO
/2026, including subsequent amendments and clarifications if any, the
receipt of which is hereby acknowledged, we the undersigned, offer to Supply,
testing, packing and forwarding, insurance, transportation and unloading of
1.65 MWp capacity ground-mounted, grid-connected SPV modules of
capacities 320 Wp / 325 Wp / 330 Wp, or alternatively, SPV modules of
capacities
615Wp/620Wp
along
with
the
necessary
structure
modification/rework of the existing Module Mounting Structures (MMS),
wherever required, to ensure proper installation and compatibility with the
supplied modules including Installation, testing & commissioning of 1.65
MWp SPV modules at 400 MW Solar Power Project site at Talaricheruvu,
Tadipatri, Anantapuramu District, Andhra Pradesh under the above-named
Contract in full conformity with the said Bidding Documents and hereby
furnish our Bid.

2.

Accordingly, we hereby submit this Application for assessment of our
qualification duly accompanied by a Bid Security/Earnest Money Deposit of
Rs ______ in the form of _________

3.

We further confirm that our bid contains no deviation from your tender
conditions and specifications.

4.

Besides furnishing the information in the schedules, we submit additional
data/certificates as indicated in the list of Enclosures.

5.

We hereby certify that all the statements made and information supplied in
the Schedules and additional data etc. furnished are true and correct.

6.

We have furnished all information and details necessary for demonstrating
our qualification and have no further pertinent information to supply.

7.

We also hereby declare that we have not been blacklisted/ debarred/
disqualified by any government entity or any international agency for nondelivery or noncompliance of contracts or under corrupt/ fraudulent
practices.

<!-- page 37 -->

8.

We confirm that, we have not applied for or availed corporate debt restructuring/
strategic debt restructuring and not cleared the loan for more than six years/ whether
DRT/NCLT proceedings pending or not, is not eligible to participate in the bid.

9.

We confirm that, we are not be under any liquidation court receivership or similar
proceedings on the due date of submission of bid
Thanking you, we remain,

Date
Seal of the Bidder
Signature
Designation
Address of the Bidder

<!-- page 38 -->

Schedule-5

PROFORMA OF GUARANTEE FOR EQUIPMENT PERFORMANCE

The tenderer hereby guarantees the requirements of this specification.

If any of the requirements of the guarantees given are not fulfilled, the purchaser has
the right to reject the equipment, and if capacity, performance and efficiency
obtained during acceptance tests falls short of that guaranteed by the tenderer, the
tenderer

hereby

affirms

that

such

deficiency

will

be

made

good

by

rectifying/replacing the defective parts. All the replaced parts shall be removed from
the site. While the facility for making good the deficiency will be normally given once,
the purchaser is entitled to reject the equipment in case of repeated failure to meet
the guarantee as per the specification.

Name of the firm:
Signature of the bidder:
Designation:
Date:
Seal of the company

<!-- page 39 -->

Schedule-6

Proforma of Letter of Authority
(To be furnished on Principal’s Letter head)
M/s Andhra Pradesh Power Generation Corporation Ltd
------------------------------------------------------------------------------------------------Dear Sirs,
Ref: Tender Enquiry No.___________ Due opening date___________
***
In connection with your above tender enquiry M/s_________________________________
(Name and full address________________________________ Telephone No.___________
And Fax No.__________________) have been duly authorized by the undersigned to act
as an agent on our behalf.
We confirm that any offer/commitment made by them including price, technical
specifications and delivery schedule shall be binding to us and we further confirm
that we shall fully abide by the said conditions.
This authority shall be irrevocable and remain valid during the period of contract, if
awarded by APGENCO.
Thanking you,
Yours faithfully,

For and on behalf of
________________

Name

________________

Designation_____________

<!-- page 40 -->

SCHEDULE-A
PRICE BID FORMAT
S. No

Rate
per
Wp

Description of the Work

Qty
1.65
MWp

3

Supply, testing, packing and forwarding,
insurance, transportation and unloading of
ground-mounted,
grid-connected
Solar
Photovoltaic (SPV) modules at 400 MW Solar
Power Project site at Talaricheruvu,
Tadipatri, Anantapuramu District, Andhra
Pradesh.
Structure
modification/rework
of
the
existing Module Mounting Structures (MMS),
wherever required, to ensure proper
installation and compatibility with the
supplied modules including Installation,
testing & commissioning
GST

4

Grand Total

1.

2

Amount in Rs

1.65
MWp

Note:
1. The Bidder shall quote the Prices in the price bid through AP e-platform
otherwise their offer will be treated as non-responsive and disqualified.
2. The Bidder shall quote for only
320Wp/325Wp/330Wp capacities.

S.No.1

in

case

of

supply

of

3. The Bidder shall quote for S.No.1 & 2 in case of supply of 615Wp/620Wp.
4. The bidder shall mention applicable taxes on the Prices.
5. However, the bidder may upload this sheet in Attachments folder in the price
bid.
6. The tender will be evaluated based on the lowest quoted rate either for the
supply of 320Wp/325Wp/330Wp or supply and installation of 615Wp/620Wp
modules.

Date

Signature-----------------------

Place

Name---------------------------Designation--------------------(Seal)---------------

<!-- page 41 -->

GUIDELINES FOR SUBMISSION OF BANK GUARANTEE

The Bank Guarantee shall fulfill the following conditions failing which it shall not be
considered valid:
1.

Bank Guarantee shall be executed on non-judicial stamp paper of applicable
value purchased in the name of bank.

2.

Non-judicial stamp paper shall be used within 6 months from the date of
purchase. Bank Guarantee executed on the stamp paper of more than 6
months old shall be treated as invalid.

3.

The contents of the Bank Guarantee shall be as per our proforma which will
be enclosed along with the Purchase Order.

4.

The Bank Guarantee should be executed by a nationalized bank.

5.

The executor of Bank Guarantee (Bank Authority) should mention the Power
of Attorney No. and date executed in his/her favour authorizing him/her to
sign the document or produce the Photostat copy of Power of Attorney.

6.

All conditions, corrections, deletion in the Bank Guarantee should be
authenticated by signature of Bank Officials signing the Bank Guarantee.

7.

Each page of Bank Guarantee shall bear signature and seal of the Bank.

8.

Two persons should sign as witnesses mentioning their full name and address.
Validity of Bank Guarantees:

9.

The Bank Guarantee for EMD shall be valid for a period of 270 days from the
date of opening of pre-qualification with a claim period of 6 months.

10.

The Bank Guarantee for PEMD shall be valid for a period of 3 years from the
date of submission with a further claim period of 6 months.

11.

The Bank Guarantee for Security Deposit shall be valid for a period of 6
months over and above the Delivery period.

12.

The Bank Guarantee for Performance Guarantee shall be valid for a period of
6 months over and above the Guarantee period.

<!-- page 42 -->

ANNEXURE-1
(TO BE STAMPED IN ACCORDANCE WITH INDIAN STAMP ACT)
PROFORMA OF BANK GUARANTEE FOR T H E EARNEST MONEY DEPOSIT
(EMD)
Bank Guarantee No:
Date:
Valid Up to:
Claim Period up to:
In consideration of the Andhra Pradesh Power Generation Corporation Limited(An
enterprise of the Government of Andhra Pradesh) (hereinafter referred to as 'APGENCO'
which expression shall unless repugnant to the context or meaning thereof, include its
successors and permitted assigns) incorporated under the Indian Companies Act, 1956
read with subsequent amendments and Act(s) and having its registered office at Vidyut
Soudha, Gunadala, Vijayawada, Andhra Pradesh,India-520004 having agreed to exempt
(Name of the Tenderer/ Vendor/Contractor/Supplier)having its registered office at _
(hereinafter called the said Tenderer/Contractor which term includes Supplier), under the
terms and conditions of the Tender Notification No.
,Dated
payment of
EMD of Rs… ……… ( Rupees ------------------------only ) is payable part of EMD for the due
fulfillment by the said Te n d e r e r / C ontractor of the terms and conditions contained in
the said Tender for________ ,on production of a Bank Guarantee for Rs.
_____________(Rupees______________only).
At the request of
[Tenderer/Contractor]
We,
…………………,
(hereinafter referred to as the “Bank”), having Registered/Head office at ……………. and a
branch at ………… being the Guarantor under this Guarantee, do hereby irrevocably and
unconditionally undertake to forthwith and immediately pay to the APGENCO without any
delay or demur, merely on your first demand any sum or sums up to a maximum amount
but not exceeding Rs ------------------ (Rupees------------).
We undertake to pay unconditionally to the APGENCO any money so demanded
notwithstanding any dispute(s) raised by the Tenderer/Contractor in any suit, or
proceedings pending before any Court or Tribunal or Arbitration or any other Authority
relating thereto our liability under this present being is absolute and unequivocal. The
payment under this guarantee would not wait till the disputes have been decided by any
Court or Tribunal or in the Arbitration proceeding or by any other Authority.
The payment so made by us under this guarantee shall be a valid discharge of our
liability for payment hereunder and the Tenderer/Contractor shall have no claim against
us for making such payment.
We, (indicate the name of the Bank) further agree that the guarantee herein
contained shall remain in full force and effective till the award of tender to the successful
bidder. Validity of BG will be for a period of 270 days from the date of opening of prequalification bid with a further claim period of 6 months. However, BG of EMD will be
returned after the award of Tender. BG is to be valid till ________ .
We, …………. (indicate the name of the Bank) further agree with the APGENCO
that the APGENCO shall have the fullest liberty without our consent and without affecting
in any manner our obligations hereunder to vary any of the terms and conditions of the
said Tender or to extend time of BG by the said Tenderer/Contractor from time to time or
to postpone for any time or from time to time.
This guarantee will not be discharged due to the change in the constitution of the
Bank or the Tenderer/Contractor.
We, ...............(indicate the name of the Bank) lastly undertakes not to revoke this
guarantee during its currency except with the previous consent of the APGENCO in
writing. Furthermore, we ......... (indicate the name of the Bank) accept that
 This Bank Guarantee is unconditional and absolute

<!-- page 43 -->

 Claim against this Bank Guarantee shall be honoured without any delay or
demur; and
 This Bank guarantee covers all the losses, claims, damages and costs suffered
by the APGENCO against the said Tender.
Notwithstanding anything to the contrary contained hereinabove:
1. The liability of the Bank under this Guarantee shall not exceed… ..................
2. This Guarantee shall be valid up to Dt._______________
3. Unless the Bank is served a written claim or demand on or before Dt._________
(claim period) all rights under this guarantee shall be forfeited and the Bank
shall be relieved and discharged from all liabilities under this guarantee
irrespective of whether or not the original bank guarantee is returned to the
Bank.
We,
________(indicate the name of the Bank), have power to issue this
Guarantee under law and the undersigned as a duly authorized person has full powers
to sign this Guarantee on behalf of the Bank.
In witness where of signed this Guarantee on this_____Day __Year___ for __ Bank
at
Signature
Designation Address & Seal of the Bank
Witness: (1)

& (2)

<!-- page 44 -->

ANNEXURE-2
(TO BE STAMPED INACCORDANCE WITH INDIAN STAMP ACT)
PROFORMA OF BANK GUARANTEE FOR THE PERMANENT EARNEST MONEY
DEPOSIT (PEMD)
Bank Guarantee No:
Date:
Valid Up to:
Claim Period up to:
In consideration of the Andhra Pradesh Power Generation Corporation Limited (An
enterprise of the Government of Andhra Pradesh) (hereinafter referred to as 'APGENCO'
which expression shall unless repugnant to the context or meaning thereof, include its
successors and permitted assigns) incorporated under the Indian Companies Act, 1956
read with subsequent amendments and Act(s) and having its registered office at Vidyut
Soudha, Gunadala, Vijayawada, Andhra Pradesh,India-520004 has afforded a facility to
Tenderer(s)/Contractor(s)/Vendor(s) and Supplier(s) who submit tender(s)/bid(s)/offer(s) in
response to the Tender notice(s) of the Andhra Pradesh Power Generation Corporation
Limited calling for Tenders for supply of materials or rendering of services or execution of
works permitting Tenderer(s)/Contractor(s)/Vendor(s) and Supplier(s) who furnish a
Permanent Earnest Money Deposit (PEMD) of Rs.______ (Rupees _____ only)in the shape
of Bank Guarantee in lieu of Cheque/Demand Draft to have their tenders considered
without separate payment of earnest monies with each tender, wherever the EMD is not
more than Rs. 5.00 lakhs (Rupees Five Lakhs only) in a single case/Tender.
Whereas
(Name
and
address
of
the
Tenderer/Vendor/Contractor/
Supplier)……………… has offered the guarantee of this Bank (indicate the name and
address of the Bank), towards the Fixed/Permanent Earnest Money Deposit and the
APGENCO has agreed to accept the same.
At the request of
[Tenderer/Contractor] We, …………………, (hereinafter
referred to as the “Bank”), having Registered/Head office at ……………. and a branch at
………… being the Guarantor under this Guarantee, do hereby irrevocably and
unconditionally undertake to forthwith and immediately pay to the APGENCO without
any delay or demur, merely on your first demand any sum or sums up to a maximum
amount but not exceeding Rs -------------------- ( Rupees------------).
We, ____(indicate the name of the Bank), do hereby undertake to forthwith and
immediately pay the amounts due and payable under this guarantee without any
demur, merely on a demand from APGENCO. Any such demand made on the bank, shall
be conclusive as regards the amount due and payable by the Bank under this guarantee.
However, our liability under this guarantee shall be restricted to an amount not
exceeding Rs.______/- (Rupees ______ only).
We ____(indicate the name of the Bank)undertake to pay unconditionally to the
APGENCO any money so demanded notwithstanding any dispute(s) raised by the
Tenderer/Vendor /Contractor / Supplier in any suit, or proceedings pending before any
Court or Tribunal or Arbitration or any other Authority relating thereto our liability under
this present is being absolute and unequivocal. The payment under this guarantee would
not wait till the disputes have been decided by any Court or Tribunal or in the Arbitration
proceeding or by any other Authority.
The payment so made by us under this guarantee shall be a valid discharge of liability
for payment thereunder and Tenderer/Vendor /Contractor / Supplier shall have no claim
against us for making such payment
We, ____(indicate the name of the Bank) further agree that the guarantee herein
contained shall remain in full force and effect till the award of tender to the successful
bidder. Validity of BG shall be for a period of 3 years from the date of submission with a
further claim period of 6 months. BG is to be valid till ________.
This guarantee will not be discharged due to the change in the constitution of the
Bank or the Tenderer/Vendor /Contractor / Supplier.

<!-- page 45 -->

We, ____(indicate the name of the Bank) lastly undertakes not to revoke this
guarantee during its currency except with the previous consent of the APGENCO in
writing. Furthermore, we________________Bank accept that
1. This Bank Guarantee is unconditional and absolute
2. Claim against this Bank Guarantee shall be honoured without any delay or
demur; and
3. This Bank guarantee covers all the losses, claims, damages and costs
suffered by the APGENCO against the Tender.
Notwithstanding anything to the contrary contained hereinabove:
a. The liability of the Bank under this Guarantee shall not exceed Rs.______/(Rupees ______ only)
b. This Guarantee shall be valid up to Dt._______________
c. Unless the Bank is served a written claim or demand on or before
Dt._________all rights under this guarantee shall be forfeited and the Bank
shall be relieved and discharged from all liabilities under this guarantee
irrespective of whether or not the original bank guarantee is returned to
the Bank.
We, ____(indicate the name of the Bank), have power to issue this Guarantee under
law and the undersigned as a duly authorized person has full powers to sign this
Guarantee on behalf of the Bank.
In witness where of signed this Guarantee on this ______Day __Year___ for __ Bank
at
Signature
Designation Address & Seal of the Bank
Witness: (1)

& (2)

<!-- page 46 -->

ANNEXURE-3
FORM OF INSURANCE SURETY BOND FOR BID SECURITY (EMD)
Insurance Surety Bond No ..............
Date:
To: (Name and address)
In consideration of the Andhra Pradesh Power Generation Corporation Limited
(An enterprise of the Government of Andhra Pradesh) (hereinafter referred to as
'APGENCO' which expression shall unless repugnant to the context or meaning
thereof, include its successors and permitted assigns) incorporated under the Indian
Companies Act, 1956 read with subsequent amendments and Act(s) and having its
registered office at Vidyut Soudha, Gunadala, Vijayawada, Andhra Pradesh,India520004 having agreed to exempt __________________ ( Name of the Tenderer/Vendor/
Contractor/Supplier) having its registered office at__________________ (hereinafter
called the said Tenderer/ Contractor which term includes Supplier),under the terms
and conditions of the Tender Notification No……………., Dated………, payment of
EMD of Rs___________ ( Rupees ____________only ) is payable part of EMD for the due
fulfillment by the said Tenderer/Contractor of the terms and conditions contained in
the said Tender for _________________________(name of the work), on production of a
Surety Bond for Rs. _____________(Rupees________________________only). At the
request of…………….
[Tenderer/Contractor] We, …………………, (hereinafter
referred to as the “Surety Insurer”), having Registered/Head office at ……………. and
a branch at ………… being the Guarantor under this Surety Bond, do hereby
irrevocably and unconditionally undertake to forthwith and pay to the APGENCO as
our primary obligation without any delay or demur, merely on your first demand and
without reference to the Bidder, if the Bidder fail to fulfil or comply with all or any of
the terms and conditions of the above tender notification any sum or sums up to a
maximum amount but not exceeding Rs ______________ (Rupees---------------------------------------------------------------------------only).
Any such written demand made by the APGENCO stating that the Bidder is
in default of the due and faithful fulfillment and compliance with the terms and
conditions contained in the Bidding Documents shall be final, conclusive and
binding on the Surety Insurer.
We, the Surety Insurer, do hereby unconditionally undertake to pay
immediately the amounts due and payable under this Surety Bond without any
demur, reservation, recourse, contest or protest and without any reference to the
Bidder or any other person and irrespective of whether the claim of the APGENCO is
disputed by the Bidder or not, merely on the first demand from the APGENCO stating
that the amount claimed is due to the APGENCO by reason of failure of the Bidder
to fulfil and comply with the terms and conditions contained in the Bidding
Documents including failure of the said Bidder to keep its Bid open during the Bid
validity period as set forth in the said Bidding Documents for any reason whatsoever.
Any such demand made on the Surety Insurer shall be conclusive as regards
amount due and payable by the Surety Insurer under this Surety Bond. However,
our liability under this Surety Bond shall be restricted to an amount not exceeding
Rs._____________ (Rupees
________
only)
This Surety Bond shall be irrevocable and remain in full force for a period of
450 (Four hundred and Fiftyty) days from the Bid Due Date or for such extended
period as may be mutually agreed between the APGENCO and the Bidder, and agreed
to by the Surety Insurer, and shall continue to be enforceable till all amounts under
this Surety Bond have been paid.

<!-- page 47 -->

We, the Surety Insurer, further agree that the APGENCO shall be the sole judge
to decide as to whether the Bidder is in default of due and faithful fulfillment and
compliance with the terms and conditions contained in the Bidding Documents
including, inter alia, the failure of the Bidder to keep its Bid open during the Bid
validity period set forth in the said Bidding Documents, and the decision of the
APGENCO that the Bidder is in default as aforesaid shall be final and binding on us,
notwithstanding any differences between the APGENCO and the Bidder or any
dispute pending before any Court, Tribunal, Arbitrator or any other Authority.
In order to give effect to this Surety Bond, the APGENCO shall be entitled to
act as if the Surety Insurer were the Principal Debtor and any/Change in the
constitution of the Contractor and/or the Surety Insurer, whether by their
absorption with any other body or corporation or otherwise, shall not in any way or
manner affect the liability or obligation of the Surety Insurer under this Surety
Bond.
In order to give full effect to this Surety Bond, the APGENCO shall be entitled
to treat the Surety Insurer as the principal debtor. The APGENCO shall have the
fullest liberty without affecting in any way the liability of the Surety Insurer under
this Surety Bond from time to time to vary any of the terms and conditions contained
in the said Bidding Documents or to extend time for submission of the Bids or the
Bid validity period or the period for conveying acceptance of Letter of Award by the
Bidder or the period for fulfillment and compliance with all or any of the terms and
conditions contained in the said Bidding Documents by the said Bidder or to
postpone for any time and from time to time any of the powers exercisable by it
against the said Bidder and either to enforce or forbear from enforcing any of the
terms and conditions contained in the said Bidding Documents or the securities
available to the APGENCO, and the Surety insurer shall not be released from its
liability under these presents by any exercise by the APGENCO of the liberty with
reference to the matters aforesaid or by reason of time being given to the said Bidder
or any other forbearance, act or omission on the part of the APGENCO or any
Indulgence by the APGENCO to the said Bidder or by any change in the constitution
of the APGENCO or its absorption, merger or amalgamation with any other person
or any other matter or thing whatsoever which under the law relating to sureties
would but for this provision have the effect of releasing the Surety Insurer from its
such liability.
Any notice by way of request, demand or otherwise hereunder shall be
sufficiently given in writing if addressed to the Surety Insurer and sent by courier
or by registered post or by certified e-mail to the Surety Insurer at the address or email set forth herein.
We undertake to make the payment immediately on receipt of your notice of
claim on us addressed to name of Surety Insurer along with branch address and
delivered at our above branch who shall be deemed to have been duly authorized to
receive the said notice of claim.
It shall not be necessary for the APGENCO to proceed against the said Bidder
before proceeding against the Surety Insurer and the Surety Bond herein contained
shall be enforceable against the Surety Insurer, notwithstanding any other security
which the APGENCO may have obtained from the said Bidder and which shall, at
the time when proceedings are taken against the Surety Insurer hereunder, be
outstanding or unrealized.
We, the Surety Insurer further undertake not to revoke this Surety Bond during
its currency except with the previous express consent of the APGENCO in writing.
The Surety Insurer declares that it has power to issue this Surety Bond and
discharge the obligations contemplated herein, the undersigned is duly authorized
and has full power to execute this Surety Bond for and on behalf of the Surety
Insurer.

<!-- page 48 -->

The Surety Insurer declares that this Insurance Surety Bond is issued by the
(name of Insurance Company) as per the applicable rules and regulations of
Insurance Regulatory Development Authority of India (IRDAI).
For the avoidance of doubt, the Surety Insurer's liability under this Surety
Bond shall be restricted to Rs. _____________ (Rupees ___________________ only). The
Surety Insurer shall be liable to pay the said amount or any part thereof only if the
APGENCO serves a written claim on the Surety Insurer in accordance with
paragraph 9 hereof, on or before ______________ [** (indicate date falling 450 days
after the Bid Due Date)].
This Surety Bond shall also be operatable at our
, branch at
,
from whom, confirmation regarding the issue of this Surety Bond or
extension/renewal thereof shall be made available on demand. In the contingency of
this Surety Bond being invoked and payment hereunder claimed, the said branch
shall accept such invocation letter immediately and make payment of amounts so
demanded immediately under the said invocation.
The Insurance Surety Bond shall be verifiable from the specific portal created
for this purpose.
In witness where of Signed and sealed this Surety Bond on this _____Day
______(month) of __(Year)___ at_____________.
SIGNED, SEALED AND DELIVERED
For and on behalf of the Insurance company by:
(Signature of the Authorised Official)
(Name) (Designation) (Code Number)

<!-- page 49 -->

ANNEXURE-4
(TO BE STAMPED INACCORDANCE WITH INDIAN STAMP ACT)
PROFORMA OF BANK GUARANTEE FOR T H E SECURITY DEPOSIT (SD)
Bank Guarantee No:
Date:
Valid Upto:
Claim Period:
In consideration of the Andhra Pradesh Power Generation Corporation Limited
(An enterprise of the Government of Andhra Pradesh) (hereinafter referred to as
'APGENCO' which expression shall unless repugnant to the context or meaning
thereof, include its successors and permitted assigns) incorporated under the Indian
Companies Act, 1956 read with subsequent amendments and Act(s) and having its
registered office at Vidyut Soudha, Gunadala, Vijayawada, Andhra Pradesh,India520004 having agreed to exempt ( Name of the Contractor/Supplier/Vendor)having
its registered office at
_
(hereinafter
called
the
said
Contractor/Supplier/Vendor) from the demand/payment of Security Deposit payable
under the terms and conditions of the Contract/Purchase Order/Work
Order No.
,Dated
made between the APGENCO
and ( Name of the
Contractor/Supplier/Vendor)for
supply/commissioning/rendering
services/execution of work _____ (herein after called ‘the said Contract/Agreement’),on
production of a Bank Guarantee for Rs. _____________(Rupees__________only).
At the request of
[Tenderer/Contractor] We, …………………, (hereinafter
referred to as the “Bank”), having Registered/Head office at ……………. and a branch at
………… being the Guarantor under this Guarantee, do hereby irrevocably and
unconditionally undertake to forthwith and immediately pay to the APGENCO without
any delay or demur, merely on your first demand any sum or sums up to a maximum
amount but not exceeding Rs -------------------- ( Rupees------------) in the event of any
breach by the said Tenderer/Contractor of any of the terms and conditions contained in
the said Contract/Purchase Order/Work Order No.
,Dated
.
We, ____(indicate the name of the Bank), do hereby undertake to forthwith and
immediately pay the amounts due and payable under this guarantee without any
demur, merely on a demand from APGENCO. Any such demand made on the bank, shall
be conclusive as regards the amount due and payable by the Bank under this guarantee.
However, our liability under this guarantee shall be restricted to an amount not
exceeding Rs_____________(Rupees______________only).
We undertake to pay unconditionally to the APGENCO any money so demanded
notwithstanding any dispute(s) raised by the Contractor/Supplier/Vendor in any suit, or
proceedings pending before any Court or Tribunal or Arbitration or any other Authority
relating thereto our liability under this present being is absolute and unequivocal. The
payment under this guarantee would not wait till the disputes have been decided by any
Court or Tribunal or in the Arbitration proceeding or by any other Authority.
The payment so made by us under this guarantee shall be a valid discharge of our
liability for payment hereunder and the Contractor/Supplier/Vendor shall have no
claim against us for making such payment.
We, (indicate the name of the Bank) further agree that the guarantee herein
contained shall remain in full force and effect during the period that would be taken for
the performance of the said Contract/Agreement and that it shall continue to be
enforceable till all the dues of the APGENCO under by virtue of the said
Contract/Agreement have been fully paid and its claims satisfied or discharged or till the
concerned authority of APGENCO certifies that the terms and conditions of the said
Contract/Agreement have been fully and properly carried out by the said
Contractor/Supplier/Vendor and accordingly discharge the guarantee, subject to
however that the APGENCO shall have no right under this bank guarantee after expiry of
_________ (period)from the date of its execution. BG is to be valid till ________ , Unless a
demand or claim under this guarantee is made on us in writing on or before the ________

<!-- page 50 -->

, we (indicate the name of the Bank) shall be discharged from all the liability under this
guarantee thereafter.
We, (indicate the name of the Bank)
further agree with the APGENCO that the
APGENCO shall have the fullest liberty without our consent and without affecting in any
manner our obligations hereunder to vary any of the terms and conditions of the said
Contract/Agreement or to extend time of BG by the said Contractor/Supplier/Vendor
from time to time or to postpone for any time or from time to time.
This guarantee will not be discharged due to the change in the constitution of the
Bank or the Contractor/Supplier/Vendor.
We, (indicate the name of the Bank) lastly undertakes not to revoke this guarantee
during its currency except with the previous consent of the APGENCO in writing.
Furthermore, we (indicate the name of the Bank) accept that
1. This Bank Guarantee is unconditional and absolute
2.
Claim against this Bank Guarantee shall be honoured without any delay or
demur; and
3.
This Bank guarantee covers all the losses, claims, damages and costs
suffered by the APGENCO against the said Contract/Agreement.
Notwithstanding anything to the contrary contained hereinabove:
a) The liability of the Bank under this Guarantee shall not exceed… .............
1.
This Guarantee shall be valid up to Dt._______________
2.
Unless the Bank is served a written claim or demand on or before
Dt._________ all rights under this guarantee shall be forfeited and the Bank
shall be relieved and discharged from all liabilities under this guarantee
irrespective of whether or not the original bank guarantee is returned to the
Bank.
We, ________(indicate the name of the Bank), have power to issue this Guarantee
under law and the undersigned as a duly authorized person has full powers to sign this
Guarantee on behalf of the Bank.
In witness where of signed this Guarantee on this ______Day __Year___ for __ Bank
at
(Signature(s) of Authorised Personnel of the Bank with Seal)
Designation:
Address:

<!-- page 51 -->

ANNEXURE-5
(TO BE STAMPED IN ACCORDANCE WITH INDIAN STAMP ACT)
PROFORMA OF BANK GUARANTEE FOR T H E PERFORMANCE (PBG)
Bank Guarantee No:
Date:
Valid Up to:
Claim Period up to:
In consideration of the Andhra Pradesh Power Generation Corporation Limited
(An enterprise of the Government of Andhra Pradesh) (hereinafter referred to as
'APGENCO' which expression shall unless repugnant to the context or meaning
thereof, include its successors and permitted assigns) incorporated under the Indian
Companies Act, 1956 read with subsequent amendments and Act(s) and having its
registered office at Vidyut Soudha, Gunadala, Vijayawada, Andhra Pradesh,India520004 has agreed to accept upon request of
( Name of the
Contractor/Supplier/Vendor)having its registered office at
_ (hereinafter called
the said Contractor/Supplier/Vendor) this Bank Guarantee No._________, Dt.____ for
making payment without effecting recovery of 10% of the value of
Contract/Agreement/Purchase Order/Work Order towards Performance Guarantee for the
satisfactory fulfilment of the Contract/Agreement/ Purchase Order/Work Order under
the terms and conditions of the Contract/Agreement/Purchase Order/Work
Order No.
,Dated
made between the APGENCO
and ( Name of the
Contractor/ Supplier/ Vendor) for supply/commissioning/rendering services/
execution of work _____ (herein after called ‘the said Contract/Agreement’),on
production of a Bank Guarantee for Rs. _____________(Rupees__________only).
At the request of
[Tenderer/Contractor] We, …………………, (hereinafter
referred to as the “Bank”), having Registered/Head office at ……………. and a branch at
………… being the Guarantor under this Guarantee, do hereby irrevocably and
unconditionally undertake to forthwith and immediately pay to the APGENCO without
any delay or demur, merely on your first demand any sum or sums up to a maximum
amount but not exceeding Rs -------------------- ( Rupees------------).
We, ____(indicate the name of the Bank), do hereby undertake to forthwith and
immediately pay the amounts due and payable under this guarantee without any
demur, merely on a demand from APGENCO. Any such demand made on the bank, shall
be conclusive as regards the amount due and payable by the Bank under this guarantee.
However, our liability under this guarantee shall be restricted to an amount not
exceeding Rs_____________(Rupees______________only).
We undertake to pay unconditionally to the APGENCO any money so demanded
notwithstanding any dispute(s) raised by the Contractor/Supplier/Vendor in any suit, or
proceedings pending before any Court or Tribunal or Arbitration or any other Authority
relating thereto our liability under this present being is absolute and unequivocal. The
payment under this guarantee would not wait till the disputes have been decided by any
Court or Tribunal or in the Arbitration proceeding or by any other Authority.
The payment so made by us under this guarantee shall be a valid discharge of our
liability for payment hereunder and the Contractor/Supplier/Vendor shall have no
claim against us for making such payment.
We, (indicate the name of the Bank) further agree that the guarantee herein
contained shall remain in full force and effect during the period that would be taken for
the performance of the said Contract/Agreement and that it shall continue to be
enforceable till all the dues of the APGENCO under by virtue of the said
Contract/Agreement have been fully paid and its claims satisfied or discharged or till the

<!-- page 52 -->

concerned authority of APGENCO certifies that the terms and conditions of the said
Contract/Agreement have been fully and properly carried out by the said
Contractor/Supplier/Vendor and accordingly discharge the guarantee, subject to
however that the APGENCO shall have no right under this bank guarantee after expiry of
_________ (period)from the date of its execution. BG is to be valid till ________ .
We, (indicate the name of the Bank)
further agree with the APGENCO that the
APGENCO shall have the fullest liberty without our consent and without affecting in any
manner our obligations hereunder to vary any of the terms and conditions of the said
Contract/Agreement or to extend time of BG by the said Contractor/Supplier/Vendor
from time to time or to postpone for any time or from time to time.
This guarantee will not be discharged due to the change in the constitution of the
Bank or the Contractor/Supplier/Vendor.
We, (indicate the name of the Bank) lastly undertake not to revoke this guarantee
during its currency except with the previous consent of the APGENCO in writing.
Furthermore, we (indicate the name of the Bank) accept that
1. This Bank Guarantee is unconditional and absolute
1. Claim against this Bank Guarantee shall be honoured without any delay or
demur; and
2. This Bank guarantee covers all the losses, claims, damages and costs
suffered by the APGENCO against the said Contract/Agreement.
Notwithstanding anything to the contrary contained hereinabove:
a) The liability of the Bank under this Guarantee shall not exceed… ..............
b) This Guarantee shall be valid up to Dt._______________
c) Unless the Bank is served a written claim or demand on or before
Dt._________ all rights under this guarantee shall be forfeited and the
Bank shall be relieved and discharged from all liabilities under this
guarantee irrespective of whether or not the original bank guarantee is
returned to the Bank.
We, ________(indicate the name of the Bank), have power to issue this Guarantee
under law and the undersigned as a duly authorized person has full powers to sign this
Guarantee on behalf of the Bank.
In witness where of signed this Guarantee on this ______Day __Year___ for __ Bank
at
(Signature(s) of Authorised Personnel of the Bank with Seal)
Designation:, Address:

<!-- page 53 -->

ANNEXURE-6
FORM OF INSURANCE SURETY BOND
[Security Deposit/Performance Security/Additional Performance Security]
Insurance Surety Bond No ...........…
Date:
To:
(Name and address)
In consideration of the Andhra Pradesh Power Generation Corporation
Limited(An enterprise of the Government of Andhra Pradesh) (hereinafter referred
to as 'APGENCO' which expression shall unless repugnant to the context or
meaning thereof, include its successors and permitted assigns) incorporated under
the Indian Companies Act, 1956 read with subsequent amendments and Act(s)
and having its registered office at Vidyut Soudha, Gunadala, Vijayawada, Andhra
Pradesh, India-520004 has agreed to accept upon request of _______________
(Name of the Contractor/ Member of JV or Consortium /Supplier/Vendor) having
its registered office at _______________ (hereinafter called the said Contractor/
Member of JV or Consortium / Supplier/ Vendor) this Surety Bond No._________,
Dt.________ for making payment without effecting recovery of ___% of the value of
Contract/ Agreement/Purchase Order/Work Order towards Performance
Security/Additional Performance Security/Advance Payment Security for the
satisfactory fulfilment of the Contract/ Agreement/ Purchase Order/Work Order
under the terms and conditions of the Contract/ Agreement/Purchase Order/
Work Order No._______________, Dated ______________ made between the
APGENCO and ______________ (Name of the Contractor/ JV or Consortium
/Supplier/Vendor) for supply /commissioning/ rendering services/ execution of
work __________(name of the work) (herein after called ‘the said Contract/
Agreement/Purchase Order/Work Order’),on production of a Surety Bond for Rs.
____________ (Rupees__________only).
AND WHEREAS we, __________ ("Surety Insurer") through our branch at
___________
have agreed to furnish this Surety Bond by way of
Performance Security/Additional Performance Security/Advance Payment
Security.
NOW, THEREFORE, the Surety Insurer hereby, unconditionally and irrevocably,
guarantees and affirms as follows:
 The Surety Insurer hereby unconditionally and irrevocably guarantees the
due and faithful performance of the Contractor's obligations during the
Contract Period/ Warranty period/Defects Liability Period under and in
accordance with the Contract, and agrees and undertakes to pay immediately
to the APGENCO, upon its mere first written demand, and without any demur,
reservation, recourse, contest or protest, and without any reference to the
Contractor, such sum or sums up to an aggregate sum of the Surety Bond
Amount as the APGENCO shall claim, without the APGENCO being required
to prove or to show grounds or reasons for its demand and/or for the sum
specified therein.
 A letter from the APGENCO, officer not below the rank of Chief
Engineer/APGENCO that the Contractor has committed default in the due and
faithful performance of all or any of its obligations under and in accordance
with the Contract shall be conclusive, final and binding on the Surety Insurer.
The Surety Insurer further agrees that the APGENCO shall be the sole judge
as to whether the Contractor is in default in due and faithful performance of
its obligations during and under the Contract and its decision that the
Contractor is in default shall be final and binding on the Surety Insurer,
notwithstanding any differences between the APGENCO and the Contractor, or
any dispute between them pending before any court, tribunal, arbitrators or
any other authority or body, or by the discharge of the Contractor for any
reason whatsoever.

<!-- page 54 -->
















In order to give effect to this Surety Bond, the APGENCO shall be entitled to
act as if the Surety Insurer were the Principal Debtor and any/Change in the
constitution of the Contractor and/or the Surety Insurer, whether by their
absorption with any other body or corporation or otherwise, shall not in any
way or manner affect the liability or obligation of the Surety Insurer under
this Surety Bond.
It shall not be necessary, and the Surety Insurer hereby waives any necessity,
for the APGENCO to proceed against the Contractor before presenting to the
Surety Insurer its demand under this Surety Bond.
The APGENCO shall have the liberty, without affecting in any manner the
liability of the Surety Insurer under this Surety Bond, to vary at any time,
the terms and conditions of the Contract or to extend the time or period for the
compliance with, fulfillment and/ or performance of all or any of the obligations
of the Contractor contained in the Contract or to postpone for any time, and
from time to time, any of the rights and powers exercisable by the APGENCO
against the Contractor, and either to enforce or forbear from enforcing any of
the terms and conditions contained in the Contract and/or the securities
available to the APGENCO, and the Surety Insurer shall not be released from
its liability and obligation under these presents by any exercise by the
APGENCO of the liberty with reference to the matters aforesaid or by reason of
time being given to the Contractor or any other forbearance, indulgence, act or
omission on the part of the APGENCO or of any other matter or thing
whatsoever which under any law relating to sureties and guarantors would but
for this provision have the effect of releasing the Surety Insurer from its
liability and obligation under this Surety Bond and the Surety Insurer hereby
waives all of its rights under any such law.
This Surety Bond is in addition to and not in substitution of any other Surety
Bond or security now or which may hereafter be held by the APGENCO in
respect of or relating to the Contract or for the fulfillment, compliance and/or
performance of all or any of the obligations of the Contractor under the
Contract.
Notwithstanding anything contained herein before, the liability of the Surety
Insurer under this Surety Bond is restricted to the Surety Bond Amount and
this Surety Bond will remain in force for the period specified below and unless
a demand or claim in writing is made by the APGENCO on the Surety Insurer
under this Surety Bond all rights of the APGENCO under this Surety Bond
shall be forfeited and the Surety Insurer shall be relieved from its liabilities
hereunder after the date mentioned.
The Surety Bond shall cease to be in force and effect on _________Unless a
demand or claim under this Surety Bond is made in writing before expiry of
the Surety Bond, the Surety Insurer shall be discharged from its liabilities
hereunder.
The Surety Insurer undertakes not to revoke this Surety Bond during its
currency, except with the previous express consent of the APGENCO in writing,
and declares and warrants that it has the power to issue this Surety Bond and
the undersigned has full powers to do so on behalf of the Surety Insurer.
Any notice by way of request, demand or otherwise hereunder may be sent by
courier, registered post or certified e-mail addressed to the Surety Insurer at
its above referred branch or e-mail set forth herein, which shall be deemed to
have been duly authorized to receive such notice and to effect payment thereof
forthwith, and if sent by post it shall be deemed to have been given at the time
when it ought to have been delivered in due course of post and in proving such
notice, when given by post, it shall be sufficient to prove that the envelope
containing the notice was posted and a certificate signed by an officer & the
APGENCO that the envelope was so posted shall be conclusive.

<!-- page 55 -->

This Surety Bond shall come into force with immediate effect and shall remain
in force and effect for up to the date specified above or until it is released earlier
by the APGENCO pursuant to the provisions of the Contract.
 The Surety Insurer declares that this Insurance Surety Bond is issued by the
......................... (name of Insurance Company) as per the applicable rules and
regulations of Insurance Regulatory Development Authority of India (IRDAI).
 This Surety Bond shall also be operatable at our ___________, branch at
___________, from whom, confirmation regarding the issue of this Surety Bond
or extension/renewal thereof shall be made available on demand. In the
contingency of this Surety Bond being invoked and payment hereunder
claimed, the said branch shall accept such invocation letter immediately and
make payment of amounts so demanded under the said invocation.
 The Insurance Surety Bond shall be verifiable from the specific portal created
for this purpose.
In witness where of Signed and sealed this Surety Bond on this _____Day
______(month) of 2025 at_____________.


SIGNED, SEALED AND DELIVERED
For and on behalf of the Insurance company by:
(Signature of the Authorised Official)
(Name) (Designation) (Code Number)

<!-- page 56 -->

Annexure-7
Consent Form

We hereby issue Consent for the SBI e-payment System implemented by APGENCO
for arranging e-payment for the Supply of following material/Execution of Work.

S.

Description

No.
1

Name of the Work

2

Purchase Order/Agreement Ref No.

3

Bank Account No. with Branch Details

4

Type of Account (Current/Cash Credit etc)

5

Full Name of the Beneficiary as per Bank
Records

6

IFSC Code etc.,

It is noted that APGENCO will not accept any responsibility in any manner for any
technical glitches/problems/malfunctioning of the Bank Portal etc., during the
course of transfer of funds through Bank Portal.

Authorized Signatory of the Agency

<!-- page 57 -->

Annexure-8

MANUFACTUR
ER’S NAME
AND
ADDRESS

MANUFACTURING QUALITY
PLAN
ITEM :

REV.NO.:

MFGR.’s
SUBSYSTE
M:

LOGO

S.
NO

COMPONE
NT &

QP NO.:

CHARACTERI
STICS

CLASS

PROJECT

:

PACKAGE

:

CONTRACT NO.

:

MAIN-SUPPLIER:

DATE:
PAGE: …. OF….
TYPE
OF

QUANTUM

REFEREN
CE

OF CHECK

OPERATIO
N

CHEC
K

M

C/A

DOCUMEN
T

ACCEPTA
NCE

FORMAT
OF

NORMS

RECORD

AGENCY

M

1.

2.

3.

4.

5.

6.

7.

8.

LEGEND:

9
.

D*

C

REMARK
S

A

**
10.

DOC.
NO.:

REV……
CAT…..

REVIEW
ED BY

APPROVE
D BY

11.

* RECORDS, INDENTIFIED WITH “TICK” ( )
SHALL BE ESSENTIALLY INCLUDED BY
SUPPLIER IN QA DOCUMENTATION.
** M: MANUFACTURER/SUB-SUPPLIER
**C: MAIN SUPPLIER, A: APGENCO,
MANUFACTURE
R/

MAINSUPPLIER

SUB-SUPPLIER
SIGNATURE

P: PERFORM W: WITNESS AND V:
VERIFICATION.
AS APPROPRIATE, CHP:APGENCO SHALL
IDENTIFY ‘W’ IN COLUMN “A”

FOR
APGENCO
USE
APPRO
VAL
SEAL

<!-- page 58 -->

Annexure-9

SUPPLIER’S
NAME AND
ADDRESS

SUPPLIER’S
LOGO

FIELD QUALITY PLAN
ITEM :

SUB-SYSTEM:

PROJECT

:

QP NO.:

PACKAGE

:

REV. NO.:

CONTRACT NO.

:

DATE:

MAIN-SUPPLIER:

PAGE: …. OF….

SL.
NO.

1.

ACTIVITY
AND

CHARACTERIST
ICS /
INSTRUMENTS

OPERATIO
N

2.

3.

CLASS
OF
CHECK

4.

QUANT
UM

REFEREN
CE

CHECK

OF
CHECK

DOCUMEN
T

NORMS

5.

6.

7.

8.

TYPE
OF

LEGEND: A = CRITICAL, B=MAJOR,
C=MINOR;

ACCEPTA
NCE

REMARK
S
FORMAT OF
RECORD

9.

DOC.
NO.:

D*

REV……

10.

<!-- page 59 -->

MANUFACTURER
/

MAIN-SUPPLIER

SUB-SUPPLIER

‘A’ SHALL BE WITNESSED BY OWNER
QUALITY DEPTT., ‘B’ SHALL BE
WITNESSED BY OWNER ERECTION /
CONSTRUCTION DEPTT. AND ‘C’
SHALL BE WITNESSED BY MAIN
SUPPLIER (A & B CHECK SHALL BE
OWNER CHP STAGES)

FOR
APGENC
O
USE

SIGNATURE

REVIEW
ED BY

APPROV
ED BY

APPROV
AL SEAL
