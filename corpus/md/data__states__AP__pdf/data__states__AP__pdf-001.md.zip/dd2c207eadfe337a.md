---
doc_id: "dd2c207eadfe337a"
source_url: "https://angrau.ac.in/UPLOADS/CircularsPDFs/CAS_notification.pdf"
ministry: "Acharya N. G. Ranga Agricultural University, Andhra Pradesh"
title: "Click Here"
date: ""
pages: 4
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "b6f78f2d5256bebf"
---

<!-- page 1 -->

ACHARYA N.G. RANGA AGRICULTURAL UNIVERSITY
Administrative Office : Lam, Guntur - 522 034, Andhra Pradesh
Circular .Memo.No.2801/Ser.11/A2/2026 Dated:13.10.2026

Sub: Estt. - ANGRAU — ANGRAU Teachers (CAS) Regulations 2019 — Calling of

applications for 9" to 11" batches — Regarding.

Ref: 1. G.O.Ms.No.20, Higher Education (UE.IJ) Department, dt:28.06.2023 of

the Principal Secretary to Government, A.P., Secretariat, Velagapudi.
2. University Proc.No.2230979/BG/2023, dated: 18.12.2023.
3. University Proc.No.11730/Ser.II/A2/2024, dt:13.03.2024.
4. Lr.No.13/Central APAUTA/ANGRAU, Lam/2026, dt.10.06.2026, from
President, APAUTA.
KEKE

It is informed that the eligible teachers as on 01.01.2025 to 30.06.2026 (three batches from
01.01.2025 to 30.06.2025, 01.07.2025 to 31.12.2025 and 01.01.2026 to 30.06.2026) are requested to
send their filled in application forms in the prescribed proforma through proper channel for
placement in Assistant Professor Academic Level 10-11(1Set) and 11-12 (1500, Assistant
Professor to Associate Professor (Level 12-13A) (2Sets) and Associate Professor to Professor
(Level 13A-14) (2Sets) as per revised ANGRAU Teachers (CAS) Regulations 2019 in the
Revised UGC Pay Scales of 2016.

All the Associate Deans of Colleges, Associate Directors of Research and Heads of
Research Stations / Schemes and KVKs/DAATTCs are requested to bring to the notice of all the
Teachers / Scientists working under their control.

The service rendered in outside agencies as specified in the regulations including the
service rendered in Government / Quasi Government will be considered only if evidence in
support of such service is enclosed to the application. The service certificate including, pay
particulars should be indicated. Any claims and representations for considering such service after
the due date will not be entertained. If the service already considered for promotion, they need
not apply again.

Instructions to be followed for filling and submission of CAS application
form
The candidate should go through the application form thoroughly and carefully before
filling the details
1. The application form along with enclosures should be submitted in as indicated
above. Additional three (3) sets of the self-assessed score card should be
| submitted along with the application form.
P.T.O.

<!-- page 2 -->

25

2. All the enclosures/proof of claims should be enclosed to the application form
serially numbered at the bottom of the page with black ball point pen.

3. The candidate claiming marks under each sub head has to enclose the relevant
documents as proof of claim. The proof should be assigned a proper number
which has to be compulsorily mentioned in the space provided for the
purpose in the application form against the column in the table and also in
the contents page.

4. The application form along with enclosures should be spiral bound. Book
bound copies should be avoided.

5. Application form without enclosures or enclosures submitted in absurd
manner or without serial numbers will not be entertained and are liable to
be rejected.

6. The candidate should strike off with Red ball point pen whichever is not
applicable to him/her. If any information furnished wrongly will be liable for
punishment as per CC&A Rules.

The applicants are requested to furnish the copies of qualifications obtained and last date
of viva-voce exam held, which is essential to consider Ph.D qualification to which they are
eligible. They have to go through the application thoroughly and ensure that they have filled all
the required information.

The Associate Deans of Colleges, Associate Directors of Research and Heads of
Research Stations / Schemes and KVKs/DAATTCs are therefore requested to certify the service
particulars and details of leave availed, by the candidates by verifying the same with their
Service Registers and certify the correctness of the particulars furnished in the application
in the prescribed proforma and forward the same with their endorsement to the University
to the following address.

To

THE REGISTRAR

Acharya N.G, Ranga Agricultural University,
Administrative Office,

Lam, Guntur — 522 034

Further, it has to be indicated clearly whether any leave i.e Earned Leave / HPL / EOL
(without pay & allowances) is availed, if not “Nil” has to be indicated. The Heads of Offices
are responsible for any wrong information furnished by the applicants.

P.T.O.

<!-- page 3 -->

వం;
NOTE:

1. Mandatory requirement of training during assessment period either offline or
online will be considered.

2. If any candidate not applied in the previous notification they can also apply.

3. For allocation of ACR marks, Reporting officer should take into consideration
of all aspects indicated in the Part III (ACR Proforma), keep the ACR in the
sealed cover and submit along with application. The sealed cover shall be
opened at the time of assessment by the Team at University.

If no marks were allotted in Part II] (ACR Proforma) by the Reporting Officer
the applicant will lose marks for the same.

4. Only the copies certified by the concerned authority where ever necessary
should be accepted. Self-certification of attachments should not be accepted. In
such cases, where the candidate could not able to get certified by the concerned
controlling officer (either because of retirement, or any other valid reasons),
the present controlling officer can certify based on records or CRs.

5. The Applicant teacher should be on the active service on the date of
notification issued by the University.

The Head of Offices are requested to verify the particulars thoroughly while forwarding
the applications. Any lapse in this regard will be viewed seriously and Head of Offices and
concerned teacher will be held responsible for the lapse and action will be initiated against them
as per rules in vogue.

Further, all the Heads of Stations / Colleges are permitted to issue Annual Confidential
Reports (ACRs) to the applicants, who are working under their control, based on the work done
report submitted by them in their respective assessment period, who are intend to submit
application for promotion under CAS.

Schedule of Submission of application:

* Last date for submission of application to Associate Deans /

Associate Director of Research : 12.11.2026
* Screening of application by committee at Associate Deans /
Associate Director of Research levels 17.11.2026
e Forwarding of Screening and eligible applications to the University : 20.11.2026
P.T.O.

<!-- page 4 -->

nda:

The application can be downloaded from the ANGRAU website i.e. www.angrau.ac.in,
which will be available shortly.

The applications received after due date will not be considered. The Heads of Offices
concerned are requested to reject the application at their level if the applicant not fulfilled the
requirements as per Regulations and need not forward such applications to the University.

A.MANI
REGISTRAR
To
All the Associate Deans of Colleges of ANGRAU.
All the Associate Directors of Research of ANGRAU.
All the Heads of Research Stations / Schemes.
All the Senior Scientist & Heads of KVK’s in ANGRAU.
All the Coordinators of DAATTCs in ANGRAU
All the Principals of Polytechnic’s of Agriculture & Agricultural Engineering ANGRAU.
Ce: to the Principal Agricultural Information Officer, AI & CC, Guntur
Ce: to the Director, P&M Cell, ANGRAU
Cc: to the Director (Polytechnics), ANGRAU
Cc: to the Director (IP), ANGRAU
The Professor & OIC, ODLC, Lam, Guntur
Ce: to P.S. to Hon’ble Vice-Chancellor, ANGRAU.
Ce: to P.A. to all University Officers, Admin. Office, Lam, Guntur
Ce: to the IT wing, Admin. Office is requested to make necessary arrangements to place in
ANGRAU website immediately
Ce: to All Technical Officers working in Admin. Office, Guntur.
Ce: to the President / General Secretary, APAUTA, Guntur
Ce: to Assistant Registrar (OP).
Ce: to Home Science / Agril. Science / Agril. Engg. & Technology / P.G Section / Exams
Sections Admin. Office.
Ce: to SF/ SC.
//F.B.OM
; >
A
yer
iy)
