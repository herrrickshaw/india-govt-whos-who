---
doc_id: "c7b7a8fbf7fa23e5"
source_url: "https://vsu.ac.in/uploads/general/Bio.pdf"
ministry: "Vikrama Simhapuri University, Nellore, Andhra Pradesh"
title: "Assets / Equipment acquired for DBT Sanctioned Project"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bef9328f7d2f3444"
---

<!-- page 1 -->

Assets Equipment acquired for DBT sanctioned Project No.PR 7952

Freeze Dryer

Ferment or
