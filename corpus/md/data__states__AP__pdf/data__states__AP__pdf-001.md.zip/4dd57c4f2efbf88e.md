---
doc_id: "4dd57c4f2efbf88e"
source_url: "https://angrau.ac.in/UPLOADS/CircularsPDFs/CASapplScoreCard_PD.pdf"
ministry: "Acharya N. G. Ranga Agricultural University, Andhra Pradesh"
title: "Click Here"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "acb3dd9b10bc94ce"
---

<!-- page 1 -->

ACHARYA N.G. RANGA AGRICULTURAL UNIVERSITY
APPLICATION FOR UPGRADATION/PROMOTION UNDER
CAREER ADVANCEMENT SCHEME–2018 FOR
DIRECTORS OF PHYSICAL EDUCATION AND SPORTS OF THE UNIVERSITY
PERFORMANCE BASED APPRAISAL SYSTEM (PBAS)
SELF APPRAISAL REPORT OF THE PERSON UNDER REVIEW
(TO BE FILLED IN BY THE CANDIDATE)
PART–I
GENERAL INFORMATION

(Application proforma is same as that meant for the Teachers and other academic staff of the University)
PART–II

CATEGORY I: TEACHING, TRAINING, COACHING, SPORTS PERSON
DEVELOPMENT AND SPORTS MANAGEMENT ACTIVITIES
(Necessary documentary evidences/certificates must be enclosed by the applicant for each and every
aspect. In cases where documentary evidences/certificates are not available, the applicant’s involvement
should be duly certified by the immediate superior/competent authority)
The self-assessment score should be based on objectively verifiable records
1.1a) Management of physical education & sports program for students (planning,

executing and evaluating the policies in physical education & sports)
Year

Details of the Activity

Impact/out-come/benefit

Marks obtained*

*5 marks/activity/year for planning of physical education & sports activities;
5 marks/activity/year for formulating and organizing various physical fitness tests etc.;
4 marks/activity/year for identifying and organizing physical fitness programmes

b) Lecture cum practice based athlete/sports classes undertaken as per allotted hours
Year

Details of the Activity

Impact/out-come/benefit

Marks obtained*

* 3 marks/activity/year for inspiring the students to participate in sports, gym activities etc.;
3 marks/activity/year for imparting technical know-how (rules, regulations, tricks and tac-tics etc.);
4 marks/activity/year for introduction of new games and sports in the college/University

c) Identifying sports talent and mentoring sports excellence among students
Year

Details of the Activity

Impact/out-come/benefit

Marks obtained*

*10 marks/activity/year

Development and maintenance of play fields, purchase and maintenance of sports
equipment/facilities
Year

Details of the Activity

Impact/out-come/benefit

Marks obtained*

*5 marks/activity/year for the grants received from UGC/Government/Private agencies; Maintenance of various
outdoor/indoor sports facilities; Purchase of equipment for outdoor/indoor games; 3 marks/activity/year for planning,
maintaining and improving the sports facilities in the University/College

1

<!-- page 2 -->

Organizing and conducting sports and games competitions
Details of the
competition

Year

*25 marks for International(I),
10 marks for Inter-University(IU),

Dates and
duration

Level(I/N/S/IU/IZ/IC)

Marks
obtained*

20 marks for National(N), 15 marks for State(S),
5 marks for Inter-Zonal(IZ), 3 marks for Inter-college(IC) levels

Extending services, sports facilities and training on holidays to the institutions and
organizations
Year

Details of the
service/camp

Dates and duration

Details of the trainees

Marks obtained*

* 3 marks/activity/year for organizing and remaining present for indoor/out-door/yoga camps during vacation

Upgradation of scientific and technological knowledge in physical education & sports
Year

Details of the Activity

Dates and duration

Marks obtained*

*3 marks for coaching camp(s)/special training program(s) in physical education & sports attended for learning of
new technology/training methodology; 3 marks/activity/year for introduction of new technology/method(s) in training
students and/or staff;
3 marks for obtaining additional certificate, 4 marks for diploma, 5 marks for degree in the related field
Note: other than the eligibility qualifications

CATEGORY

II:

PROFESSIONAL DEVELOPMENT, CO-CURRICULAR AND
EXTENSION ACTIVITIES, RESEARCH AND ACADEMIC
CONTRIBUTIONS

(Necessary documentary evidences/certificates must be enclosed by the applicant for each and every
aspect. In cases where documentary evidences/certificates are not available, the applicant’s involvement
should be duly certified by the immediate superior/competent authority)

 Student related co-curricular, extension and field based activities
Year

Details of the Activity

Dates and duration

Impact/out-come/benefit

Marks obtained*

*10 marks/year for NSS/NCC officer; 3 marks for cultural activities at college level; 2 marks/activity for organizing
subject related events like lectures on special topics, quiz/debate/elocution, essay competition/exhibition, science day
celebrations in terms of application to sports/physical education

 Contribution to corporate life and management of the sports units and institution through
participation in sports and administrative committees and responsibilities
Year

Details of the Activity

Impact/out-come/benefit

Marks obtained*

*2 marks/activity

(Guidelines, marks allotment and application proforma for the remaining aspects under
Category-II are same as those meant for the Teachers and other academic staff of the
University)

2

<!-- page 3 -->

EXPLANATORY NOTES FOR MARKS ALLOCATION
CATEGORY I: TEACHING, TRAINING, COACHING, SPORTS PERSON
DEVELOPMENT AND SPORTS MANAGEMENT ACTIVITIES
(Necessary documentary evidences/certificates must be enclosed by the applicant for each and every
aspect. In cases where documentary evidences/certificates are not available, the applicant’s involvement
should be duly certified by the immediate superior/competent authority)
The self-assessment score should be based on objectively verifiable records

1. a) Management of physical education & sports program for students (planning, executing
and evaluating the policies in physical education & sports) – Planning of physical education
& sports activities (5 marks/activity/year); Formulating and organizing various physical
fitness tests etc. (5 marks/activity/year); Identifying and organizing physical fitness
programmes (4 marks/activity/year)
b) Lecture cum practice based athlete/sports classes undertaken as per allotted hours –
Inspiring the students to participate in sports, gym activities etc. (3 marks/activity/year);
imparting technical know-how (rules, regulations, tricks and tac-tics etc.) (3
marks/activity/year); Introduction of new games and sports in the college/University (4
marks/activity/year)
c) Identifying sports talent and mentoring sports excellence among students (10
marks/activity/year)
2. Development and maintenance of play fields, purchase and maintenance of sports
equipment/facilities – Grants received from UGC/Government/Private agencies;
Maintenance of various outdoor/indoor sports facilities; Purchase of equipment for
outdoor/indoor games (5 marks/activity/year); planning, maintaining and improving the
sports facilities in the University/College (3 marks/activity/year)
3. Organizing and conducting sports and games competitions at the International (25
marks)/National (20 marks)/State (15 marks)/Inter-University (10 marks)/Inter-Zonal (5
marks)/Inter-college (3 marks) levels
4. Extending services, sports facilities and training on holidays to the institutions and
organizations – Organizing and remaining present for indoor/out-door/yoga camps during
vacation (3 marks/activity/year)
5. Upgradation of scientific and technological knowledge in physical education & sports –
coaching camp(s)/special training program(s) in physical education & sports attended for
learning of new technology/training methodology (3 marks); introduction of new
technology/method(s) in training students and/or staff (3 marks/activity/year); Any
additional certificate (3 marks)/diploma (4 marks)/degree (5 marks) obtained in the related
field (other than the eligibility qualifications)
CATEGORY II: PROFESSIONAL DEVELOPMENT, CO-CURRICULAR AND
EXTENSION
ACTIVITIES,
RESEARCH
AND
ACADEMIC
CONTRIBUTIONS
(Necessary documentary evidences/certificates must be enclosed by the applicant for each and every
aspect. In cases where documentary evidences/certificates are not available, the applicant’s involvement
should be duly certified by the immediate superior/competent authority)



Student related co-curricular, extension and field based activities – NSS/NCC officer (10
marks/year); cultural activities at college level (3 marks); organizing subject related events
like lectures on special topics, quiz/debate/elocution, essay competition/exhibition,
science day celebrations in terms of application to sports/physical education (2
marks/activity)
3

<!-- page 4 -->



Contribution to corporate life and management of the sports units and institution through
participation in sports and administrative committees and responsibilities (2 marks/
activity)
(Guidelines, marks allotment and application proforma for the following aspects is same
as that meant for the Teachers and other academic staff of the University)



Involvement in various activities as committee members, maintenance/verification of stocks etc.



Participation



Membership in scientific societies or associations



Orientation courses/Refresher courses/Research methodology/Training/TeachingLearning-Evaluation Technology/Soft skills programs/Faculty development programmes
etc. attended/organized



Resource person/guest lectures, being invited for coaching at state/national level



Publications



Sponsored Research Projects – carried out/ongoing



Research guidance – M.Phil.or equivalent, Ph. D.



Peer recognition – Awards, Honours/chairperson for technical sessions/lead speaker/invited

in seminars, conferences, short-term training courses, workshops etc.

speaker/key note address etc. 

Note:
A) Furnish a detailed list of activities under each of the above categories, year wise, along
with necessary supporting documents duly certified by the concerned authority separately
B) Furnish the details only for the assessment period
C) Candidate shall mention the score/marks (self-assessment) in each column of the
category, based on the truthful data and the evidences/certificates etc.
D) Candidate shall mention the score/marks (self-assessment) in each column of the
category, even if exceeds the maximum score in the category
E) Any other information beyond the above proforma may be given as special attachment
with necessary details

4

<!-- page 5 -->

ACHARYA N.G. RANGA AGRICULTURAL UNIVERSITY
CAREER ADVANCEMENT SCHEME-2018
PERFORMANCE BASED APPRAISAL SYSTEM (PBAS)

SCORE CARD FOR PROMOTION FROM
ACADEMIC LEVEL
TO ACADEMIC LEVEL
CATEGORY

I: TEACHING, TRAINING, COACHING, SPORTS PERSON
DEVELOPMENT AND SPORTS MANAGEMENT ACTIVITIES
Marks obtained during the
assessment period (year wise)
I
II III VI V VI

Total

Mean

1.1 a) Management of physical education & sports

program for students (planning, executing and
evaluating the policies in physical education &
sports)
b) Lecture cum practice based athlete/sports classes
undertaken as per allotted hours
c) Identifying sports talent and mentoring sports
excellence among students
1.2 Development and
maintenance of play fields,
purchase
and
maintenance
of
sports
equipment/facilities
1.3 Organizing and conducting sports and games
competitions
1.4 Extending services, sports facilities and training on
holidays to the institutions and organizations
1.5 Upgradation of scientific and technological
knowledge in physical education & sports
Total (Max. marks: 100/year)

CATEGORY

II:

PROFESSIONAL DEVELOPMENT, CO-CURRICULAR AND
EXTENSION ACTIVITIES, RESEARCH AND ACADEMIC
CONTRIBUTIONS
Marks obtained during the
assessment period (year wise)
I
II III VI V VI

Student related co-curricular, extension and field based
activities – NSS/NCC officer; cultural activities at college
level; organizing subject related events like lectures on
special
topics,
quiz/debate/elocution,
essay
competition/exhibition, science day celebrations in terms of
application to sports/physical education
Contribution to corporate life and management of the sports
units and institution through participation in sports and
administrative committees and responsibilities
Involvement in various activities as committee members,
maintenance/verification of stocks etc.
Participation in seminars, conferences, short-term training
courses, workshops etc.
Membership in scientific societies or associations

Total

Mean

<!-- page 6 -->

Orientation
courses/Refresher
courses/Research
methodology/Training/Teaching-Learning-Evaluation
Technology/Soft skills programs/Faculty development
programmes etc. – Attended
Orientation
courses/Refresher
courses/Research
methodology/Training/Teaching-Learning-Evaluation
Technology/Soft skills programs/Faculty development
programmes etc. – Organized
Resource person/guest lectures
Publications
Sponsored Research Projects – carried out/ongoing
Research guidance – M.Phil. or equivalent, Ph. D
Peer recognition
Total (Max. marks: 100/year)

OVERALL PERFORMANCE DURING THE ASSESSMENT PERIOD
Marks obtained during the
assessment period (year wise)
I
II III VI V VI

Total

Mean

Category I: Teaching, training, coaching, sports person
development and sports management activities
(Max. marks: 100/year)
Category II: Professional development, co-curricular
and extension activities, research and academic
contributions (Max. marks: 100/year)
Total (Max. marks: 200/year)
Percentage (%)
Annual Performance
* < 60% – Not satisfactory (NS)

*60 to 70% – Satisfactory (S)

* >70% to 80 % – Good (G)

*>80% – Outstanding (OS)

(Remaining application and other aspects such as assigning marks to CR, selection criteria etc.
are same as those meant for the Teachers and other academic staff of the University)
