---
doc_id: "0f7f53eaa84c8bcb"
source_url: "http://svuniversity.edu.in/wp-content/uploads/2026/06/SVU-Corrigendum-to-Recruitment-Notifications-Extention-of-time-09.06.2026.pdf"
ministry: "Sri Venkateswara University, Tirupati, Andhra Pradesh"
title: "Corrigendum to the Recruitment Notification"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "45b47f60cf724066"
---

<!-- page 1 -->

SRI VENKATESWARA UNIVERSITY
Tirupati – 517 502, Tirupati District, Andhra Pradesh, India
Phone : +91 (877) 2289545, 2289414
E-Mail : vcsvutpt@yahoo.com, registrarsvu@gmail.com, registrar@svumail.edu.in,
Website :www.svuniversity.edu.in

Corrigendum to the Employment Notifications:
1. Notification No. 1/SVU/E. II (2)/ASST Prof. /Backlog – SC & ST. BC/2026, dated 15.05.2026
2. Notification No. 2/SVU/E.II(2)/ASST.Prof./Regular/2026, dated 15.05.2026
3. Notification No. 3/SVU/E. II (2)/Assoc. Prof. /Backlog – SC & ST. BC/2026, dated 15.05.2026
4. Notification No. 4/SVU/E.II(2)/Assoc. Prof. & Prof./Regular/2026, dated 15.05.2026

Date: 08.06.2026

Extension of Last Date for Submission of Applications
Sub: Extension of last date for submission of online applications and receipt of hard copies – Reg.
With reference to the Notifications cited above, it is hereby informed that the last date for
submission of online applications, originally fixed as 08.06.2026, is extended up to 15.06.2026.
Accordingly, online applications shall now be submitted up to 5:00 P.M. on 15.06.2026 through the
recruitment portal: https://apuniversitiesrecruitment.apcfss.in/.
Further, the hard copies of the applications, along with self-attested copies of relevant documents,
shall reach the University on or before 5:00 P.M. on 22.06.2026.
The existing and revised timelines for the ongoing recruitment cycle are set out below:
Sl.No. Activity
Existing Date
1.
Last date for submission of online application and
08.06.2026
payment of registration fee through the Common
Recruitment Portal
2.
Last date for receipt of hard copy of the application,
15.06.2026
along with all enclosures, by Registered Post /
Speed Post / Courier
3.
Display of list of prima-facie eligible and ineligible
22.06.2026
applicants
4.
Last date for receipt of grievances on prima-facie
29.06.2026
eligibility
5.
Display of final list of prima-facie eligible
30.06.2026
candidates

Revised Date
15.06.2026

22.06.2026

29.06.2026
06.07.2026
07.07.2026

All other terms and conditions contained in the original Notifications shall remain unchanged.

Sd/- REGISTRAR
SRI VENKATESWARA UNIVERSITY, TIRUPATI.
