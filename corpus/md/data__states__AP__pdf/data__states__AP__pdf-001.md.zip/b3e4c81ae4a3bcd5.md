---
doc_id: "b3e4c81ae4a3bcd5"
source_url: "https://apgenco.gov.in/asset/docs/file1/fileupload_261023_32b127307a606effdcc8e51f60a45922.pdf"
ministry: "Andhra Pradesh Power Generation Corporation Limited (APGENCO), Andhra Pradesh"
title: "Tender No: Dr. MVR RTPP-LT Motors"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b2480654cc2f2424"
---

<!-- page 1 -->

Enquiry Particulars
Department Name
Circle/Division
Tender ID
IFB No / Tender Notice Number
Name of Project

Name of Work

Package number
Period of Completion/ Delivery Period (In Months)
Bidding Type
Tender Category
Type of Product
Currency Type
Default Currency
Estimated Contract Value
Evaluation Type
Evaluation Criteria
Consortium / Joint Venture

APGENCO
CE - GENERATION
1005076
E-04/SE-2/APGENCO
Dr MVR RTPP
Supply of 3 Phase, 415 V, 50 Hz AC and 220 V DC
various LT electrical motors of different KW rating
required for Stage I, Dr. MVR RTPP
N/A
N/A
OPEN - NCB
PRODUCTS
LT Motors
(INR)
Indian Rupee - INR
1,42,10,099
Tender Wise
Based on Price
N/A

Tender Dates
Bid Document Download Start Date & Time
Bid Document Download End Date & Time
Bid Submission Closing Date & Time
Bid Validity Period (In Days)

23/10/2026 02:00 PM
06/11/2026 11:00 AM
06/11/2026 12:00 PM
120

Tender Inviting Authority Particulars

SE - GENERATION-2
PRASANNA VENKATARAMANA BELAGAL
APGENCO
8333868044
se-gen2@apgenco.gov.in

Officer Inviting Bids
Bid Opening Authority
Address
Contact Details
Email
Transaction Fee Details
Transaction Fee Payable to 'APTS ' payable at
Vijayawada.

The participating bidders have to pay a transaction fee of
0.03 % on the Total Cost + GST as applicable.

Bid Security Details
Bid Security(INR)

Bid Security In Favour Of

Mode of Payment

Rs.100000.00

pay officer/APGENCO

Exempted,Online
Payment,Challan Generation

Process Fee Details
Process Fee

No Data Found. . .
Decrypter List

Process Fee Payable To

<!-- page 2 -->

Department User Name

Department Name

BASAVANABOYI APGENCO
NA VENKAIAH
PRASANNA
APGENCO
VENKATARAMAN
A BELAGAL

Phone Number

Email

Designation

Certificate
serial No

Certificate
Expiry

9490612521 seSuperintendin 193a7b6 06/02/20
gen1@a g Engineer
27 12:23
pgenco.
PM
gov.in
04023499836 seSE GenII
1942026 25/02/20
gen2@a
27 10:36
pgenco.
AM
gov.in

Tender Documents
S.No

File Name

File Description

File Size (in Bytes)

Uploaded Date

1

Tender-ID1005076.pdf

Tender
Specification

6201859

22/10/2026 05:43
PM

Required Tender Documents Details
S.No

Documents Required from Contractor

Stage

Optional

1

Rs.2,84,202 in the form of BG/DD/BC in
addition to the Online payment of
Rs.1,00,000 towards EMD as per TS or
Copy of valid NSIC/SSI Registration
Certificate
Experience certificate/PO/performance
certificate as per tender specification
Self-declaration as per tender specifcation
Turnover certificate as per tender
specification
Solvency/net worth certificate as per tender
specification
All filled in bid schedules as per tender
specification

COMMON

Mandatory

COMMON

Mandatory

COMMON
COMMON

Mandatory
Mandatory

COMMON

Mandatory

COMMON

Mandatory

2
3
4
5
6

General Terms and Conditions / Eligibility
General Terms and Conditions / Eligibility

as per tender specification
General Technical Terms and Conditions (Procedure)
General Technical Terms and Conditions (Procedure)

as per tender specification
Legal Terms & Conditions
Legal Terms & Conditions

as per tender specification
Procedure for Bid Submission
Procedure for Bid Submission

<!-- page 3 -->

The bidder shall submit his response through Bid submission to the tender on eProcurement
platform at www.apeprocurment.gov.in by following the procedure given below. The bidder would
be required to register on the e-procurement market place https://tender.apeprocurement.gov.in
and submit their bids online. Offline bids shall not be entertained by the Tender Inviting Authority
for the tenders published in e-procurement platform.
The bidders shall submit their eligibility and qualification details, Technical bid, Financial bid etc.,
in the online standard formats displayed in eProcurement web site. The bidders shall upload the
scanned copies of all the relevant certificates, documents etc., in support of their eligibility
criteria/technical bids and other certificate/documents in the eProcurement web site. The bidder
shall sign on the statements, documents, certificates, uploaded by him, owning responsibility for
their correctness/authenticity. The bidder shall attach all the required documents for the specific
tender after uploading the same during the bid submission as per the tender notice and bid
document.
The Bidder shall also ensure prior to Final Bid submission that the Encryption certificate present
in the DSC Key token is the same as that mapped into his Profile page in the Eprocurement
system. Service provider shall not be responsible for Non-submission of Bid in case there is a
variance in the Encryption certificate between the Key token and the Uploaded certificate in the
Bidders profile in the Eprocurement system.
Registration with eProcurement platform: For registration and online bid submission bidders may
contact HELP DESK.
https://tender.apeprocurement.gov.in
Digital Certificate authentication:
The bidder shall authenticate the bid with his Digital Certificate for submitting the bid electronically
on eProcurement platform and the bids not authenticated by digital certificate of the bidder will not
be accepted on the eProcurement platform.
For obtaining Digital Signature Certificate, you may please Contact:
You may please Contact Registration Authorities of any Certifying Authorities in India. The list of
CAs are available by clicking the link https://tender.apeprocurement.gov.in/digital-signature.html#
3. Hard copies:
i) Vide ref. G.O.Ms.No.174, I&CAD dept dated:1-9-2008, submission of original hard copies of the
uploaded scanned copies of Proof of online Payment (Remittance)/BG towards EMD by
participating bidders to the tender inviting authority before the opening of the price bid is
dispensed forthwith.
ii) All the bidders shall invariably upload the scanned copies of Proof of online Payment
(Remittance)/BG in eProcurement system and this will be the primary requirement to consider the
bid responsive.
iii) The department shall carry out the technical evaluation solely based on the uploaded
certificates/documents, Proof of online Payment (Remittance)/BG towards EMD in the
eProcurement system and open the price bids of the responsive bidders.
iv) The department will notify the successful bidder for submission of original hardcopies of all the
uploaded documents Proof of online Payment (Remittance)/BG towards EMD prior to entering
into agreement.
v) The successful bidder shall invariably furnish the original Proof of online Payment
(Remittance)/BG towards EMD, Certificates/Documents of the uploaded scan copies to the
Tender Inviting Authority before entering into agreement, either personally or through courier or
post and the receipt of the same within the stipulated date shall be the responsibility of the
successful bidder. The department will not take any responsibility for any delay in receipt/nonreceipt of original Proof of online Payment (Remittance)/BG towards EMD,
Certificates/Documents from the successful bidder before the stipulated time. On receipt of
documents, the department shall ensure the genuinity of the Proof of online Payment

<!-- page 4 -->

(Remittance)/BG towards EMD and all other certificates/documents uploaded by the bidder in
eProcurement system. In support of the qualification criteria before concluding the agreement.
4. The GO. Ms. No. 174 -I&CAD dated: 1-9-2008
Deactivation of Bidders If any successful bidder fails to submit the original hard copies of
uploaded certificates/documents, Proof of online Payment (Remittance)/BG towards EMD within
stipulated time or if any variation is noticed between the uploaded documents and the hardcopies
submitted by the bidder, as the successful bidder will be suspended from participating in the
tenders on eProcurement platform for a period of 3 years. The eProcurement system would
deactivate the user ID of such defaulting bidder based on the trigger/recommendation by the
Tender Inviting Authority in the system. Besides this, the department shall invoke all processes of
law including criminal prosecution of such defaulting bidder as an act of extreme deterrence to
avoid delays in the tender process for execution of the development schemes taken up by the
government. Other conditions as per tender document are applicable.
The bidder is requested to get a confirmed acknowledgement from the Tender Inviting Authority a
proof of Hardcopies submission to avoid any discrepancy.
5. Payment of EMD:
It is mandatory for all participant bidders to electronically pay EMD Online by utilizing the
'Payment Gateway Service on E-Procurement platform'. The Electronic Payment Gateway
accepts all Master and Visa Credit Cards issued by any bank and Direct Debit facility/Net
Banking/NEFT payment modes through ICICI Bank and/or Axis Bank Payment Gateways to
facilitate the transaction. This is in compliance as per G.O.Ms. 08 dated 08.05.2016. A GST of
18.00% + Bank charges on the transaction amount payable to APTS shall be applicable. In
addition to this, Bidders can also pay the EMD through Download of PDF format of RTGS Challan
for respective Payment gateway and pay the EMD through their Parent Bank account. Once the
EMD is received by the EProcurement application, Bidders can automatically continue with their
Bid Submission online.
IMPORTANT NOTE REGARDING EMD PAYMENT:
1. Bidders are encouraged to use only Net banking facility for payment of EMDs as far as
possible for faster refunds in case of unsuccessful Bids for the Tender.
2. Bidders are advised not to use RTGS Challan downloads at the penultimate hour of Bid
submission closing as any delay by their banker would not enable Bid submission on the platform.
Please allow a minimum of 60 minutes for enabling 'Continuation of Bid Submission' from the time
the Pool Account receives credit of the EMD from the Bidders Bank for both NEFT and RTGS
Transfers. For RTGS Transfers, the Pool Account can get immediate credit whereas NEFT
transfers would follow RBI Payment Cycle time.
3. Bidders are advised to pay EMD Online atleast T-1 or T-2 days before Bid submission closing
date (T= Bid submission closing date) to avoid last minute delays and denials of successful Bid
submission and to take care of any delays in Banking procedures.
Un Successful Bidder EMD Refund process: The bid is declared unsuccessful, under the following circumstances.
Bid submitted by the bidder is not the lowest bid.
Upon Finalization of the L1 Bid.
Technical Disqualification of the Bid in case of 2 cover system.
EMD paid but bid not submitted
EMD refund will be initiated by the Tender Inviting Authority directly and through Online only and
through the same payment channels as EMD received by the Department. (RTGS / NEFT /Credit
Card /Debit Card refund), within 30 days from the date of publishing the Decision / Result.
However, Service Provider /GoAP will not be held responsible for the delays occurring due to
banking channels/procedures/processes of the respective vendor.
IMPORTANT NOTE REGARDING EMD REFUNDS:

<!-- page 5 -->

Bidders are requested to use discretion in their choice of payment channel for remittance of EMD.
Time taken for Refunds under Ideal conditions:
1. Net Banking / NEFT / RTGS Challan: One (1) Banking Business Day from time of initiation of
refund by Tender Inviting Authority subject to RTGS/NEFT timings of RBI.
2. Credit card/ Debit card: 7-10 working days from time of initiation of refund by the Tender
Inviting Authority. However, this may be longer in case of certain bank cards. In case of delays,
bidders are requested to contact the Card issuing Bank for faster resolution.
6. Payment of Transaction Fee:
It is mandatory for all the participant bidders from 1st January 2006 to electronically pay a Nonrefundable Transaction fee to M/s. APTS , the service provider through 'Payment Gateway
Service on E-Procurement platform'. The Electronic Payment Gateway accepts all Master and
Visa Credit Cards issued by any bank and Direct Debit facility/Net Banking of ICICI Bank, Axis
Bank to facilitate the transaction. This is in compliance as per G.O.Ms. 13 dated 07.05.2006. A
GST of 18.00% + Bank charges on the transaction amount payable to APTS shall be applicable.
The participating bidders will pay a transaction fee @ 0.03% of ECV (estimated contract value)
with a cap of Rs.10,000/- (Rupees ten thousand only) for all works with ECV upto Rs.50 crores,
and Rs.25,000/- (Rupees twenty five thousand only) for works with ECV above Rs.50 crores, at
the time of bid submission electronically. For tenders wherever ECV is not available i.e., for goods
and services, the transaction fee shall be calculated on quoted value. GST as levied by the GOI
on transaction fee, electronic payment gateway charges shall be borne by the bidders.
7. Corpus Fund:
As per GO MS No.4 User departments shall collect 0.04% of ECV (estimated contract value) with
a cap of Rs. 10,000 (Rupees ten thousand only) for all works with ECV upto Rs.50 Crores, and
Rs. 25,000/- (Rupees twenty-five thousand only) for works with ECV above Rs.50 Crores, from
successful bidders on eProcurement platform before entering into agreement / issue of purchase
orders, towards eprocurement fund in favour of Managing Director, APTS . There shall not be any
charge towards eProcurement fund in case of works, goods and services with ECV less than and
upto Rs. 10 lakhs
8. Tender Document:
The bidder is requested to download the tender document and read all the terms and conditions
mentioned in the tender Document and seek clarification if any from the Tender Inviting Authority.
Any offline bid submission clause in the tender document could be neglected.
The bidder has to keep track of any changes by viewing the Addendum/Corrigenda issued by the
Tender Inviting Authority on time-to- time basis in the E-Procurement platform. The Department
calling for tenders shall not be responsible for any claims/problems arising out of this.
9. Bid Submission Acknowledgement:
The bidder shall complete all the processes and steps required for Bid submission. The system
will generate an acknowledgement with a unique bid submission number after completing all the
prescribed steps and processes by the bidder. Users may also note that the bids for which an
acknowledgement is not generated by the e-procurement system are treated as invalid or not
saved in the system. Such invalid bids are not made available to the Tender Inviting Authority for
processing the bids. The Government of AP are not responsible for incomplete bid submission by
users.
Stages
S.No

Stage Name

Evalution Opening date

Dependent Stage Name

1

PQ Stage

2

Commercial Stage

06/11/2026 03:00
PM
10/11/2026 12:00 PQ Stage
PM

Schedule Details
S.No

Schedule ID

Schedule Name

<!-- page 6 -->

1

1

LT Motors
