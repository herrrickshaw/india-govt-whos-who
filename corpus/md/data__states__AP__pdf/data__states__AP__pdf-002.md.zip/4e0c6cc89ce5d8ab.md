---
doc_id: "4e0c6cc89ce5d8ab"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 45
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5b7098d64c78932f"
---

<!-- page 1 -->

GOVERNMENT OF ANDHRA PRADESH
A P STATE DISASTER MANAGEMENT AUTHORITY

Bidding Document
for
Procurement of Goods
National Competitive Bidding
Name of Work: Supply of Search & Rescue equipment (5 Types of CSSR-1) to AP
State Disaster Response Force (AP SDRF), 6th Battalion, Mangalagiri, Guntur District,
Andhra Pradesh.
Estimate Cost Value(ECV): Rs.39,16,980/-

A P State Disaster Management Authority (APSDMA)
Kunchanapalli, Tadepalli (Md), Guntur District, Andhra Pradesh-522501
https://apsdma.ap.gov.in

1

<!-- page 2 -->

TIME SCHEDULE& CRITICAL DATA
Item

Description
13/SDMA/2025

Bid Number & Date

Name of Work:

Supply of Search & Rescue equipment (5 Types of
CSSR-1) to AP State Disaster Response Force (AP
SDRF), 6th Battalion, Mangalagiri, Guntur District,
Andhra Pradesh.
Rs.39,16,980/-

ECV (Estimated Contract Value)

Bid Document Downloading Start date

06.05.2025 at 01.00 PM

Bid Document Downloading End Date

13.05.2025up to 3:30 PM

Last date for uploading of online
documents

13.05.2025up to 4:00 PM

Technical Bid opening date/time

14.05.2025@ 11:00 AM

Financial Bid opening date/time
Bid Document Fee

16.05.2025@ 04:00 PM

Earnest Money Deposit (EMD)

Rs.39,170/-

Rs.5,000/-

Period for furnishing performance
Security
Performance security value

Within 10 days from data of receipt of award

Performance security validity period

24 months from date of supply

Period for signing the order

Within 10 days from date of receipt of LOA

2.5 % of Order value

acceptance

Bid Validity Period

1.Technical Bid Evaluation- Minimum eligibility
2. Financial Tender Selection – Lowest bid among the
technically qualified bidders (L1)
90 days from the last date of submission of Bid

Delivery Period

90 days from the date of agreement

Consignee

Addl. Director General, APSP & APSDRF c/o the
Commandant, 6th Bn, APSP campus, Mangalagiri,
Guntur district, Andhra Pradesh state.

Pre delivery Inspection

Before dispatch, the Equipment ordered will be inspected and
quality clearance certificate will be issued by the Addl. Director
General, APSP & APSDRF c/o the Commandant, 6th Bn, APSP
Campus, Mangalagiri, Guntur district, A P. In addition to that
the Authority may order inspection at any stage for which, the
seller shall provide necessary facilities free of cost.

Method of evaluation of Tenders

Administrative Approval
Source of Funds

GO Rt No.64, Revenue (DM-II) Department
dtd.09.10.2024
Preparedness and Capacity Building funds under SDRF
vide G O Rt No. 2184, Finance (FMU-REV) Department
dtd.05.10.2024

2

<!-- page 3 -->

Annexure I
Technical Bid- Mandatory documents Check list
S.No.

Description

1

Bid Processing Fee of Rs.5,000/- by way of DD from any
nationalized Bank

2

Earnest Money Deposit (EMD)

3

Bidder Letter Form (Annexure-II)

Provided
(Yes/ Page No.
No)

3(a) Format for Consortium Agreement (Annexure-IX)
3(b)

Format for Power of Attorney for Lead Member of Consortium
Agreement (Annexure-X)

4

Bidder Information Sheet (Annexure-III)

5

Tender document, duly signed and stamped in token of
acceptance of all the terms and conditions of the tender
schedule.

6

Certificate of GST, PAN of firm

7

Average turn over copy as per tender document, Certified by CA
for last three years

8

IT returns for any two years out of last three financial years.

The copy of Supply Orders/Contracts issued by/ signed with
State Governments/ Central Government agencies/ Public
9
sector units/any other organization executed by the bidders in
last three years shall been enclosed.
Self-declaration stating that “Firm has not been barred/
10 blacklisted by any organization in doing business with them”
(Annexure-IV).
11 Technical compliance statement (Annexure VI)
OEM Compliance statement with detailed technical
12 specifications, make, model etc., as per format given at
Annexure-VII for specified items only
13 List of major customers (Annexure-VIII)
14 Format for Consortium Agreement (Annexure-IX)
15 Format for Power of Attorney for Lead Member of Consortium
Agreement (Annexure-X)
16 Format for Power of Attorney for Sole Bidder (Annexure-XI)
NOTE: Please Upload Only relevant documents. All pages of the bid document must

3

<!-- page 4 -->

be serially numbered and signed.

Terminology
Throughout this document, the following definitions apply:
a)

“Applicant” means a party that submits, or intends to submit, a Bid;

b)

“Work Order” means the written order resulting from Bidding issued by the
Authority;

c)

“The Authority” means the Andhra Pradesh State Disaster Management
Authority;

d)

“Must” or “mandatory” means a requirement that must be met in order for a
Proposal to receive consideration;

“Should” or “desirable” means a requirement having a significant degree of
importance

4

<!-- page 5 -->

CONTENTS
SI. No

Description

1

Time Schedule & Critical Data

2

Technical Bid- Mandatory documents Check list

3

General Information

4

Section I Notice Inviting Bids

5

Section II Instructions to Bidders

6

Section III- Scope of work

7
8

Section IV Special Conditions
Section V Technical Bid

5

<!-- page 6 -->

General Information
➢ Tenders are invited by the Managing Director, AP State Disaster Management
Authority
➢ Bidding is open to National Bidders only invariably having experience in
manufacturing or supplying Search & Rescue equipment.
➢ The Bidders are requested to submit their technical and financial proposals (Bids)
through e-tendering portal only before the stipulated date and time specified in the
Bid.
➢ In the event of the specified date of Bid opening being declared holiday for the Govt. of
Andhra Pradesh, the Bids will the opening at appointed time and location of next
working day.
➢ The Managing Director, APSDMA reserves the right to accept or reject any Bid and to
annual the Bidding process and reject all Bids at any time prior to contract award,
without thereby incurring any liability to bidders.
➢ The contact address for communication as follows:
21/2B, Pathuru Cross Road Center, Kunchanapalli (PO), Tadepalli Mandal, Guntur
District, Andhra Pradesh-522501.

Managing Director,
APSDMA

6

<!-- page 7 -->

CLARIFICATIONS:

Queries, if any can be made through e-mail only on commr_relief_rev@ap.gov.in Queries
received via any mode other than e-mail id mentioned above will not be entertained. The
queries should only be sent in following format on the official letter head of the company.

S. No.

Page No.

Clause

Description

(Tender Ref.)

(Tender Ref.)

(Tender Ref.)

Query

The addendum/corrigendum, if any shall be published one-procurement platform
https://tender.apeprocurement.gov.in
The Bidders are requested to submit the bids after issue of clarifications duly considering the
changes made if any. Bidders are totally responsible for incorporating/complying the changes/
amendments made by APSDMA.

Managing Director,
APSDMA

7

<!-- page 8 -->

Section – I
NOTICE INVITING BIDS
Name of the Work:
Supply of Search & Rescue Equipment to AP State Disaster Response Force (AP SDRF), 6th
Battalion, Mangalagiri, Guntur District, Andhra Pradesh.
Tender in e-tendering mode is invited by the Managing Director, AP State Disaster Management
Authority, Government of Andhra Pradesh for supply of Water Rescue Equipment for
strengthening of AP SDRF under open tender method on e-procurement platform
https://tender.apeprocurement.gov.in.
1. The eligible Bidders are required to submit their technical and financial bids separately
through e-tendering portal as per the deadline specified in the bid. If, the technical and
financial bids are combined together, such bids will be rejected.
2. Eligible bidders: The bidder shall be Manufacturer, Supplier, Reseller of the Equipment and
shall submit an undertaking as per the attached format. (Bidder must clarify or all items of
Water Rescue Equipment that for which items it’s a manufacturer of the product offered, or
a dealer authorized by the OEM). The bidder or its OEM shall be certified ISO 9001:2015
company/firm and a valid copy of the certificate shall be submitted towards its proof along
with bid.
Bidders

would

be

required

to

register

on

the

e-Procurement

portal

https://tender.apeprocurement.gov.in and submit their bids online. On registration with the
e-Procurement market place they will be provided with a user id and password by the system
through which they can submit their bids online.

3. Joint Venture/Consortium:
3.1 Allowed for two members. Joint Venture/consortium with whom the contract is entered
into and shall be deemed to include the contractor's successors (approved by the Procuring
Entity), agents, subcontractor, representatives, heirs, executors, and administrators as the case
may be unless excluded by the terms of the contract;"
The format for

(i)

The signature shall be of the person authorized with the Power of
Attorney to sign on behalf of the firm/ lead JV/Consortium partner.
(ii) In case of a JV/Consortium, the combined resources will be considered
unless otherwise specified. This is subject to meeting the requisite
terms and conditions specified in the tender.
3.2 The Parties do hereby irrevocably constitute a Joint Venture/Consortium (the
“Joint Venture/Consortium”) for the purposes of jointly participating in the
Bidding Process for the Project in the format enclosed.
3.3 The Parties hereby undertake to participate in the Bidding Process only through
this Joint Venture/Consortium and not individually and/ or through any other
8

<!-- page 9 -->

Joint Venture/Consortium constituted or this Project, either directly or
indirectly.
3.4 The Parties hereby undertake that in the event the Joint Venture/Consortium is declared the
selected Bidder and awarded the Project, it shall enter into a Contract with the Authority for
performing all its obligations as the Contractor in terms of the Contract for the Project.
3.5 Role of the Parties The Parties hereby undertake to perform the roles and responsibilities as
described below:

(a)

Party of the First Part shall be the Lead member of the Joint
Venture/Consortium and shall have the power of attorney from all Parties
for conducting all

business

for and on

behalf of

the Joint

Venture/Consortium during the Bidding Process and until the Appointed
Date under the Contract;
(b)

Party of the Second Part shall be {the Member of the Joint Venture/Consortium

4. All the participating bidders who submit the bids have to pay an amount @ 0.03% of their
final bid value online with a cap of Rs.10,000/- for quoted value of purchase up to Rs.50
crores and Rs.25000/- if the purchase value is above Rs.50 crores & GST applicable as
levied by Govt. of India on transaction fee through online in favour of The Managing
Director, APTS. The amount payable to APTS is nonrefundable.
5. The Bidder shall furnish, as part of his Tender, a Bid document fee of Rs. 5,000/- (Rupees
Five thousand rupees only).by using Net banking/RTGS/NEFT from their registered
Bank Accounts or through Credit Card/ Debit Card to the account of Managing Director,
APSDMA bearing account number 233810100016424of Union Bank of India, IFSC Code:
UBIN0823384. Proof of payment of EMD shall be scanned and uploaded along with the
Bid.
6. The Bidder shall furnish, as part of his Tender, an EMD mentioned in TIME SCHEDULE
& CRITICAL DATA sheet. The Bidder may pay the EMD by using Net
banking/RTGS/NEFT from their registered Bank Accounts or through Credit Card/ Debit
Card to the account of Managing Director, APSDMA bearing account number
233810100016424 of Union Bank of India, IFSC Code: UBIN0823384. Proof of payment
of EMD shall be scanned and uploaded along with the Bid.
7.

The technical bid should cover the following aspects (Qualification Criteria):

a.

The bidder/Consortium partner should be a company registered under the provisions of the
Indian Companies Act, 1956 or updates thereof or a partnership firm registered under the
Indian Partnership Act, 1936 or the Limited Liability Partnerships Act, 2008 or a proprietary
firm. Firm registration or Shop Act Registration certificates must be attached to the bid. The
9

<!-- page 10 -->

consortium shall comprise a maximum of two (2) members. The bidder/Consortium
partner should have registered office in India for not less than 5 years as on 01.04.2025.
b.

The bid shall be secured by an Earnest Money Deposit(EMD) as specified in the document
and

bid

security

(EMD)

shall

be

in

the

form

specified

through

https://tender.apeprocurement.gov.in in favor of Managing Director, APSDMA and
uploaded online through https://tender.apeprocurement.gov.in portal. The bid received will
be evaluated only on confirmation of receipt of original bid security/EMD.
c.

The bidder/Consortium partner shall be in the business of supply of Search & Rescue
Equipment as for at least last 5 years viz. FY 2019-20, 2020-21, 2021-22, 2022-23 and 202324. The bidder/Consortium partner shall be Manufacturer or supplier of the Search& Rescue
Equipment and shall submit an undertaking as per the attached format. (Bidder must clarify
for all items of Rescue Equipment that for which items it’s a manufacturer of the product
offered, or a dealer authorized by the OEM)

d.

The Bidder/Consortium partner should have manufactured and supplied or supplied search
and Rescue Equipment to any State/Central Government organization, or any other
organization of value not less than 50 % ECV (Estimated Contract Value), during last 5
years viz. FY 2019-20, 2020-21, 2021-22, 2022-23 and 2023-24. The bidder/Consortium
partner must have supplied this equipment to government during the last 5 years. Completion
certificates from the client; Consignee receipt and acceptance certificate issued by end user
or GeM OR Work order + Self certificate of completion; OR Work Order + Phase Completion
Certificate from the client shall be submitted with the bid.

e.

The bidder and consortium partner must have the PAN Card and latest GST Registration
Certificate. A copy of the registration must be attached to the bid.

f.

The bidder and Consortium partner shall have positive net worth during last 5 financial years
VIZ. FY2019-20, 2020-21, 2021-22, 2022-23 and 2023-24. The Certificate of positive net
worth must be certified by the Charted Accountant and the copy of the net worth certificate
must be attached to the bid.

g.

The primer bidder must have at least an average annual turnover of not less than ECV
during the last 5 years viz. FY 2019-20, 2020-21, 2021-22, 2022-23 & 2023-24.
Documentary evidence such as Charted Accountant (CA) certificate showing that the bidder
has an average annual turnover of not less than ECV during the last 5 years viz. FY2019-20,
2020-21, 2021-22,2022-23and2023-24. Bidder shall also submit audited balance sheets of
FY2019-20, 2020-21, 2021-22,2022-23 and2023-24.

h.

The bidder / consortium partner or its OEM shall be certified ISO9001:2015 company/firm
and a valid copy of the certificate shall be submitted toward sits proof along with bid.

i.

The bidder and consortium partners shall not be blacklisted by any Government/Semi
Government organization in India. Bidder shall submit an undertaking on stamp paper duly
notarized in their technical bid.
10

<!-- page 11 -->

j.

The Bidder and Consortium partner shall submit original affidavit of correctness of
information (duly notarized) furnished with bid document.

k.

All tender documents shall be signed by authorized power of attorney (PoA) holder of the
consortium partners and must have a bidder seal and must be ink signed. Aboard resolution
OR power of attorney in the name of the person executing the bid, authorizing the sign a
tory to commit the Bidder shall be submitted with the bid.

l.

Service & Support availability of service centers: The Prime Bidder/OEM must have a
Functional Service Centre in the State of each Consignee's Location. If service center is not
already there at the time of bidding, successful bidder / OEM shall have to establish service
center within 30 days of award of contract. Payment shall be released only after submission
of documentary evidence of having Functional Service Centre. Bidder to submit a
declaration for Service & Support Availability of Service Centers.

m.

Service & Support dedicated /toll free telephone number for service support: The bidder
and Consortium partner /OEM must have dedicated toll free telephone number for service
support.

n.

Service & Support Escalation Matrix for Service Support: Primer Bidder/OEM must provide
Escalation Matrix of Telephone Numbers for Service Support.

8. The Financial bid should cover the following aspects:
9.

The financial bid of technically qualified bidders will be opened at prescribed date and time
on thee-tendering Portal in the presence of bidders who wish to attend in the office of the
Managing Director, AP State Disaster Management Authority.

10. The validity of the quoted rates shall be applicable for the period of 90days.
11. The rates quoted shall be inclusive of all duties, taxes, and other levies payable by the
Contractor under the Contract, or for any other cause, as applicable on the deadline for
submission of Bids, shall be included in the rates and prices and the total bid price
submitted by the Bidder.
12. The Primer bidder shall carry out the said work fully as per specifications, and instructions
of the Managing Director, AP State Disaster Management Authority.
13. This invitation for bids is open to only National bidders as per the GoI notification subject
to fulfilment of this tender’s qualification criteria. Bidder shall have the nationality of India.
Bidder shall be deemed to have the nationality of a country if the bidder is constituted,
incorporated or registered in and operates inconformity with the provisions of the laws of
India, as evidenced by its articles of incorporation (or equivalent documents of constitution
or association) and its registration documents, as the case may be.
14. Even though the Bidders meet the above qualifying criteria, they are subject to be
disqualified if they have:
11

<!-- page 12 -->

a. Made misleading or false representations in the forms, statements and attachments scan &
uploaded in proof of the qualification requirements; and/or

b. Record of poor performance such as abandoning the works, not properly completing the
contract, in ordinate delays in completion, litigation history, blacklisting by Govt./Semi
Govt. organization or financial failures etc.
15. The bidder will be selected for award of contract provided the bidder is the technically
qualified, lowest, evaluated responsive & fulfils the qualification criteria mentioned above.
16. The APSDMA will not accept the tenders from blacklisted companies or undependable
Suppliers whose past performance with APSDMA was found to be poor due to delayed
and/or erratic supplies, frequent product failures, and also against whom there have been
adverse reports of sub-standard quality as defined in the other parts of the Bidding
document.
17. The bidders need to scan and upload the required documents as per the check list given.
Such uploaded documents pertaining to technical bid need to be attached to the tender
while submitting the bids online. APSDMA will consider only the bids submitted through
online.
NOTE: For any clarification and further details on the above tender please contact during office
hours (10:00 AM to 5:00 PM) on working days: Telephone No: 08645-246600/9849187446 or mail
to commr_relief_rev@ap.gov.in

Managing Director,
APSDMA

12

<!-- page 13 -->

Section – II
INSTRUCTIONS TO BIDDERS
A. Introduction
1. Definitions:
In this document following terms shall be interpreted as Indicated:
1.1 “The Contract” means the agreement that will be entered in to between the Managing
Director, AP State Disaster Management Authority and the Contractor as recorded in
the Contract between both the parties to contract.
1.2 “The Contract Price” means the price pay able in Indian currency to the Contract or
under the Contract.
1.3 “The Goods” means all of the equipment’s, machinery and/or other materials either
dismantled or mantled, which the Contract or is required to fabricate/manufacture and
supply for rescue operations as per tender by Managing Director, AP State Disaster
Management Authority, Andhra Pradesh under the Contract.
1.4 “The Personnel” means all of the persons/staff mentioned in the technical requirement
(as applicable).
1.5 “The Services” means those services required to be provided under the Contract.
1.6 “The Central Government” means the Govt. of India.
1.7 “The Government or State Government” means the Govt. of Andhra Pradesh
1.8 “The Contractor” means the firm or individual who has entered into contract with the
Managing Director, AP State Disaster Management Authority, Andhra Pradesh.
1.9 “The Managing Director” means The Managing Director, AP State Disaster Management
Authority
2. Eligible Bidders:
This invitation for bid is open to manufacturers/ authorized suppliers/ dealer of
“Search & Rescue Equipment”.
3. Cost of Bidding:
The Bidder shall bear all costs associated with the preparation and submission of
his/her bid, and the Managing Director, AP State Disaster Management Authority, will
in no case be responsible or liable for those costs.
4. Amendment of Bidding Document:
4.1 At any time prior to the deadline for submission of bids, the managing Director, AP
State Disaster Management Authority may amend the Bidding Documents by issuing
addenda/corrigendum. The addendum/ corrigendum will appear on the e-tendering
portal under “Latest Corrigendum”.
4.2 Amendment in bid document will be placed on the e-tendering website which will be
binding on them.
4.3 In order to allow reasonable time in which to take the amendment into account by the
prospective Bidders in preparing their bids, the AP State Disaster Management
13

<!-- page 14 -->

Authority, at its discretion, may extend the dead line for the submission of bids.
B. Preparation of Bids:
5. Language of Bid:
The bid as well as all supporting literature, testimonials, correspondence and documents
relating to the bid shall be in English. The bid, supporting literature, testimonials,
correspondence and documents in any other language must be accompanied by an
accurate translation in English, in which case, for purposes of interpretation of the bid, the
translation in English shall govern.
6. Documents Constituting the Bid:
The bid shall comprise of two components viz. Technical Bid and Financial Bid:
Technical Bid:
(a) Technical proposal in the prescribe format.
(b) Supporting documents.
Financial Bid:
As per e-tendering portal.
7. Bid Prices:
The Bidder shall indicate on the appropriate price schedule, the unit charges (wherever
applicable) and total bid price and the unit prices of the consumable goods it proposes to
supply under the contract. The bid prices shall be inclusive of all taxes, duties etc. levied
outside India and the price for in land transportation, insurance and other local costs
associated with delivery of the equipment, personnel &goods to their final destination and
shall also include all taxes/duties/levies/charges levied in India. Prices quoted by the
Bidder shall remain fixed during the Bidder’s performance of the contract and not subject
to variation on any account, unless otherwise specified in this contract.
8. Taxes &Duties:
All taxes, duties and/or any other charges levied in India by either Central /State
Government, such as but not limited to, customs duties, entry tax, GST etc., shall be paid
by the successful bidder and it shall be included in the unit price.
9. Prices: Bid Currencies: Prices shall be quoted in Indian Rupees only.
10. Earnest Money Deposit (BID SECURITY):
10.1 The Bidder shall furnish requisite amount of BID SECURITY in the form prescribed
by e-tendering portal.
10.2

Any Bid not secured by BID SECURITY as specified above will be rejected as nonqualified and will be returned to the bidder.

10.3

Upon the successful bidder furnishing the signed agreement and performance
security, each unsuccessful bidder will be promptly notified, and their bid security
be returned without interest

10.4

Within 30 (thirty) days of notice of award of contract

10.5

BID SECURITY of the successful bidder will be discharged after the bidder has
14

<!-- page 15 -->

signed the agreement and on production of performance security in bank
guarantee form for an 2.5 %of the contract amount.
11. Period of validity of Bids:
(a) Bids shall remain valid for the period of 180 days from the last date of submission
of the bid. A bid valid for a shorter period will be rejected as non-responsive.
(b) In exceptional circumstances, the Managing Director, AP State Disaster
Management Authority, AP may so licit the Bidder’s consent to an extension of the
period of validity of bids. There quest and responses there to shall be made in
writing. A Bidder may choose to refuse there quest without forfeiting his/her BID
SECURITY.
12. Format for Signing of Bid:
(a) The bidders shall offer the technical bid and financial bid through E-tendering
portal only. The hard copies of these bids shall be made available to the AP State
Disaster Management Authority when demanded. Technical bids shall be signed by
the Bidder persons duly authorized to bind the Bidder to the contract. All pages of
the bid, except for un- amended printed literature, if any, shall be initialed by the
person or persons signing the bid along with company’s seal.
(b) Any interlineations, erasures or overwriting shall be valid only if the person or
persons signing the bid signs them as mark of attestation.
B. Submission of Bids:
14. Deadline for Submission of Bids:
Bids will be received by the Managing Director, AP State Disaster Management
Authority through E-tendering portal only before the submission date and time
published. The bidder shall ensure submission of bids well within the stipulated
time. AP State Disaster Management Authority is not responsible for any problems
in server/difficulty experienced while submission of bids one-tendering portal.
15. Modifications and Withdrawal of Bids:
No modifications and with draw a Bids will be entertained. If the bidder withdraws
the offer within the bid validity period, the BID SECURITY furnished shall be
forfeited by the Government of Andhra Pradesh.
C. Opening and Evaluation of Bids:
16. Opening of Technical Bids:
(a) The Managing Director, AP State Disaster Management Authority, will open all the
Technical Bids in the presence of Bidder’s representatives as mention date and time.
The Bidder’s representative who is present shall sign a register evidencing their
attendance.
(b) The Bidder’s names, and the presence or absence of submission of the hardcopy of
requisite and other details as considered appropriate, will be announced at the
opening.
(c) Bids that are not opened and read out at bid opening shall not be considered further

15

<!-- page 16 -->

for evaluation.
17. Preliminary Examination of technical bid:
17.1 The bids not accompanied by confirmed BID SECURITY will be rejected.
17.2 Prior to the detailed evaluation of the technical bid, the substantial responsiveness
of each technical bid to the bidding documents will be determined. For purposes
of these Clauses, a substantially responsive bid is one, which conforms to all the
terms and conditions of the bidding documents without material deviations.
Deviations from, or objection or reservations to critical provisions, such as those
concerning technical conformity, Applicable Law, Taxes and Duties &Force
Majeure. The determination of a Technical Bid’s qualification is to be based on the
contents of the technical bid itself without recourse to extrinsic evidence.
18. Clarification of Technical Bids:
During evaluation of the bids the Managing Director, AP State Disaster
Management Authority, Andhra Pradesh, may, at his discretion, ask the Bidder for
a clarification of his/her bid, if required. The request for clarification and the
response shall be in writing.
19. Evaluation and Qualification of Technical Bids:
In addition, to technical specifications and specified qualification criteria, the
committee constituted by the Managing Director, AP State Disaster Management
Authority shall evaluate the Technical Bids and make suitable recommendations.
20. Opening of Financial Bids:
The Managing Director, AP State Disaster Management Authority will open the
Financial Bids of only those Bidders whose bids are Technically qualified at eprocurement portal on specified date and time.
21. Preliminary Examination of financial Bids:
(a) The Managing Director, AP State Disaster Management Authority will examine the
bids to determine whether they are complete, free from computational errors etc.
(b) Arithmetical errors will be rectified on the following basis. If there is a discrepancy
between the unit price and the total price that is obtained by multiplying the unit
price, the unit price shall prevail and the total price shall be corrected accordingly.
(c) The Managing Director, AP State Disaster Management Authority may waive any
minor infirmity in the financial bid, which does not constitute a material deviation,
provided such waiver, does not prejudice or affect the relative ranking of any Bidder.
22. Comparison and Evaluation of Financial Bids:
The Managing Director, APSDMA will open and compare the Financial Bids, which have
been determined to be technically qualified. The Managing Director, APSDMA shall
evaluate the Financial Bids based on prices as quoted on e-tendering and issue suitable
orders

16

<!-- page 17 -->

D. Award of Contract:
23. Award Criteria:

The Managing Director, APSDMA will award the contract to the bidder
whose bid has been evaluated to be suitable and accepted.
24. Notification of Award:
Prior to the expiration of the period of bid validity, including the extended period of
bid validity, if any, the Managing Director, AP State Disaster Management
Authority, will notify The Successful Bidder in writing by registered letter or by
electronic mail, about the acceptance of the bid.
25.

Earnest Money Deposit / Bid Security:
The EMD shall not carry any interest. The Forfeiture of the EMD: the forfeiture
of EMD will be made in the following events:
i. The bidder qualifies as L1 and backs out of the L1 quotes/tender specification/
tender terms & conditions.
ii. The bidder signs the agreement and furnishes the Security Deposit but backs
out of his tender bid.
iii. The bidder withdraws his tender after acceptance.
iv. The bidder withdraws his tender before expiry of the validity period of the
tender.
v. The bidder violates any provisions of the terms and conditions of these tender
specifications.
Refund Of EMD:
i. In case of unsuccessful bidder, the EMD will be returned to them after
finalization of the L1 vendor.
vi. The EMD will be returned to the L1 bidder, only after signing of the contract and
submission of Security Deposit (PBG), completion of formality etc. in all
respects to the satisfaction of the APSDMA.
vii. The successful bidder has to deposit 2.5 % of the total contract value as
performance security deposit in the form of Bank Guarantee from any
nationalized bank.
viii. The Performance Security Deposit/Bank Guarantee of successful bidder will be
retained for the period of contract in force and will be returned after expiry of
the contract period, after deducting the outstanding liabilities if any.
ix. The Performance Security Deposit/Bank Guarantee shall not carry any interest.
26. Contract:
As soon as the Managing Director, AP State Disaster Management Authority notifies
the successful Bidder that his/her bid has Been Accepted Through e-endering the
bidder/bidder’s Authorized representative (with power of attorney to sign) shall
attend the office of the Managing Director, AP State Disaster Management
Authority to submit the signed copy of the contract documents within Ten (10) days
of such notification of award.
• The successful bidder shall execute an agreement with APSDMA on Non-judicial
stamp paper worth Rs.100.00 agreeing to all the conditions of the contract within
Ten days upon intimation of acceptance of Tender. The successful bidder has to

17

<!-- page 18 -->

submit performance security deposit after taking Letter of Intent but before having
contract agreement. Failure on enter into an agreement with in the stipulated time
will result in for feature of the EMD.
• After awarding the contract, if the Bidder fails to complete the full activity as per
the agreement, the order given to the bidder will be cancelled. Further, bidder will
be blacklisted and security deposit will be forfeited, in addition to recourse to other
penal measures. No grievance will be entertained in this regard.
• The Managing Director, APSDMA reserves the right to issue
instructions/modifications at any point of time before award of contract.
E. Corrupt or Fraudulent Practices
27. The AP State Disaster Management Authority requires that the successful Bidder
under this contract observe the highest standard of ethics during this process. In
pursuance of this policy, AP State Disaster Management Authority Defines for the
purposes of this provision, the terms set forth below as follows:
(a) “Corrupt practice” means the offering, giving, receiving or soliciting of anything
of value to influence the action of a Members of Tender scrutiny/sub-Committee
/Tender inviting authority in the contract process.
(b) “Fraudulent practice” means Misrepresentation of facts to AP State Disaster
Management Authority, Government or any legal entity in India, in order to
influence the award or execution of a contract, detriment to the interests of the State
Government.
Collusive practice among Bidders (prior to or after bid submission) designed to
establish bid prices at artificial non-competitive levels and to deprive the
Government of the benefits of free and open competition.
28. The APSDMA Will Reject the Proposal For a ward If It Determines That the Bidder
Recommended for A ward has/had engaged in corruptor fraudulent practices in
competing for the contract in question.
29. The APSDMA will declare a firm ineligible for award of the contract, either
indefinitely or for a notified period of time, if it at any time determines that he firm
had engaged in fraudulent practices in competing for, or in executing, a contract in
the State of Andhra Pradesh.
30. Delivery (Consignee): Entire quantity of equipment is to be delivered within 90
Days from supply order date to the AP State Disaster Response Forces, Mangalagiri
office of the Addl. Director General of Police, APSP & APSDRF c/o 6 th Bn, APSP
campus Guntur district, Andhra Pradesh.
31. Delivery and Acceptance: The acceptance and the evaluation of the goods
supplied shall be done by the AP SDRF/ or any technical committee designated by
the MD, APSDMA.
32. The selected supplier shall provide demonstration of supplied equipment and
deliver trainings to the SDRF personal with consultation of Authorities of SDRF.
33. Pre-dispatch inspection at Seller premises: Before dispatch, the Equipment ordered

18

<!-- page 19 -->

will be inspected and quality clearance certificate will be issued by the Addl.
Director General, APSP & APSDRF c/o the Commandant, 6th Bn, APSP campus,
Mangalagiri, Guntur district, A P. In addition to that the Authority may order
inspection at any stage for which, the Seller shall provide necessary facilities free of
cost.
The goods would be dispatched to consignee only after clearance in pre-dispatch
inspection and issuance of quality clearance certificate. The Consignee has every
right to reject any goods which is not delivered in good/acceptable working condition at
place of delivery. In addition to the 2.5% of the Performance Security valid for a period of
two (2) years from the date of agreement, an amount of 10% of the invoice amount will be
withheld and the same will be released as per clause no.4.2 of section IV.
The warranty period for the goods delivered is as per Terms and Conditions in respect
of the goods finally received by the consignee shall in no way be limited or waived
by reason of the good shaving previously been inspected, tested and passed by
Consignee or its inspecting agency prior to the goods' shipment.
• The Seller shall provide, without any extra charge, all materials, tools, labor and
assistance of every kind which the Inspecting officer may demand of him for any
test, and examination, other than special or independent test, which he shall
require to be made on the seller’s premises and the seller shall bear and pay all
costs attendant there on.
• The seller shall also provide and deliver store / sample from consignment under
inspection free of charge at any such place other than suppliers premises as the
Inspecting officer may specify for acceptance tests for which seller/ OEM does
not have facilities or for special / independent tests.
• In the event of rejection of stores or any part thereof by the Inspecting officer
basing on testing outside due to lack of test facility at seller’s premises, the seller
shall, on demand, shall pay to the buyer the costs incurred in the inspection and/
or test. Cost of test shall be assessed at the rate charged by the Laboratory to
private persons for similar work.
• Inspector shall have the right to put all the stores or materials forming part of the
same or any part thereof to such tests as he may like fit and proper as per
QAP/governing specification. The seller is not be entitled to object on any group
whatsoever to the method of testing adopted by the Inspecting officer.
• Unless otherwise provided for in the contract, the quality of the stores or
materials expended in test will be borne by seller.
• Inspecting officers is the Final Authority to Certify Performance / accept the
consignment. The Inspecting officer’s decision as regards the rejection shall be
final and binding on the seller.

19

<!-- page 20 -->

SECTION III
Scope of Work and Bill of QuantitiesS.
No

1

2

Name of the
equipment

Extension
boxes for heavy
voltage usages

Personnel Alert
safety system
(PASS)(Motion scout)
safety for the
Rescuer

Quantity
in Nos

24

60

Specification of the equipment
• Shape/Classification By Function: Rectangular/Square
[Extension cord of fixed length (without re-coiling facility)
• Current Rating of Each Socket (in Ampere): 16 A
• Number of Sockets: 3
• Type of Sockets: 3 Pins Socket
• Type of Switch Control: Single Master, Switch for All
Sockets
• Material of Extension Box: Poly Carbonate
Minimum Length of Cable from Extension Box: 3 Meter.
Inclusive of transportation,delivery at destination and GST etc
complete.
CONSTRUCTIONAL:
• Modes of operation available in the device to be actuated
by rescue personnel: off, manual, and automatic
• Availability of Distress Tone Signals: Operational Signal,
Pre Alert Signal &amp; Alert Signal
• DSU should be free of periodic maintenance: Yes
• Availability of Accidental Deactivation: Two stage manual
actions to switch the unit from automatic mode to off
position
• Display: Alphanumeric, L.E.D. read-out of PASS status
• Weight (With Batteries) (Gram): 225
• Inbuilt intelligence to remove chance of false alarm:
Available
• Automatic full "self-check" function upon start up:
Available
• Battery: Compatible with DSU
• Dimensions Suitable to be worn with self-contained
breathing apparatus (SCBA): 100 X 75 X 45 MM
• LED Indicator to show the unit is 'ON': Green
• Motion sensor timings: Yes
• LED Indicator to indicate when Distress Alarm is raised:
Red
• Device should have sensor temperature control facility
during operation: Yes
• PERFORMANCE: Pre-Alarm level for 6 Seconds (dBA):
75 – 85
• Motion Sensor: 3-axis accelerometer capable to Sense a
broad range of motion
• Integrated Temperature Sensor: when the fire-fighter
exceeds a predetermined time- weighted average
temperature threshold, the audible heat alarm is activated
• Audio Distress Signal Output at 3-meter distance(dBA):
95
• Distress Alarm Count at Full Noise Level (audio signals
per second): 3
• Operating Temperature Range (Degree C): 20 – 65
• Alarm duration: 6 – 8
• Standby Battery Life After Full Charge (Hour): 200
• Accidental switch off during use: eliminated by the options
of tally insertion or two-button push, depending on the
operating mode.

20

<!-- page 21 -->

S.
No

3

Name of the
equipment

Thermal
Imager
(Debris)

Quantity
in Nos

6

Specification of the equipment
• Upper Frequency (Hz): 3000 (+/- 200)
• Alarm duration after battery low signal alarm (Hour):
Minimum 2
• Device is capable to operate in hazardous Condition and
to remain Intrinsically Safe: Yes
• Compliance to IP 67 requirements: Yes
• Unit shall be Compatible with all SCBA. It can be worn
with or without breathing apparatus: Yes
CERTIFICATION:
• National/International certification of the Device for use
by the emergency service personnel: Available
• Name of the Certification: MSA
Certification No. & Dt: 3456 - 11/4/18, Inclusive of
transportation, delivery at destination and GST etc complete.
Warranty (Year): 2 years
Specifications:
LENS MEASUREMENTS FEATURES:
Horizontal Field of View of Standard lens (degree):41-50
Vertical Field of View of Standard lens 35-40
Horizontal Field of View of Telephoto lens NA
Vertical Field of View of Telephoto lens NA
IFOV of Standard lens (mRad) NA
IFOV of Telephoto Lens (mRad) NA
IFOV of (Spatial resolution) (mRad) NA
PERFORMANCE FEATURES
Type Hand held
Detector Resolution (minimum) (pixel) 14000
Temperature Range of Objects (Degree Celsius) -20 to +250
Temperature measuring accuracy of reading (or better) ± 2%
oC
Minimum Focus distance 20 centimeter
Image capture frequency/ frame rate (Hz) N ≥ 9
Image Detector Type Focal Plane Array (FPA) Uncooled Micro
bolometer (for fever measurement & animal husbandry
thermal imager)
Thermal sensitivity (NETD) 0.06 degree Celsius
User selectable Emissivity setting/correction Between 0.01
and 1
Infrared spectral band (micrometer) Between 8 and 14 Image
Palettes 4DISPLAYDisplay Type Color LCD Display size 3.5inch GENERAL FEATURES Image capture, review and save
mechanism One handed image capture, review and save
capability. Storage medium Inbuilt Memory Size of USB stick
0 gigabyte File formats JPEG, BMP, GIF, PNG Built-in digital
camera/ Visual Camera Resolution (Mpixel) N ≥ 1
Details of Operating functions Toggled Button
Facility for the adjustment/ selection of the time/date etc yes.
Interface for image transfer Wi-Fi, USB Cable with suitable
drivers for downloading to PC Focus Auto other features
toggled button. OPERATING CONDITION Minimum
Operating Temperature -10-degree Celsius Maximum
Operating Temperature 50-degree Celsius Operating
Humidity (RH) 90 percent POWER REQUIREMENT Power
Requirements Battery Operated. Chemistry of the battery
lithium-ion Voltage of rechargeable Battery 3.7 Volt
Capacity of rechargeable battery (milliAH) 2500
Suitable charger/adapter provided yes
Battery Backup 4 hour
Power Management Automatic shutdown /User Selectable

21

<!-- page 22 -->

S.
No

Name of the
equipment

Quantity
in Nos

Specification of the equipment
On-screen battery level indicator yes
CERTIFICATION & SAFETY
IP Protection IP54
Safety Certification CE
GENERIC Size/
dimension 219 x 96 x 95 mm
Weight (including batteries) 0.51 kilogram
Automatic active temperature stabilization system of camera
yes
Provision
for
through-the-lens
direct
temperature
measurement capability yes
TEST REPORT DETAILS & TESTS
The equipment supplied with calibration Certificate yes
conformity to Dry Heat for 16 hrs at a maximum temp in
accordance with IS:9000/part-3/section-5/1977 latest Yes
Conformity to Cold Test for 4 hrs at a minimum temp in
accordance with IS:9000/part-2/section-4/1977 latest Yes
conformity to Damp Heat (Cyclic)Test for 2 Cycles of 24 h each
at a temp of 40 degree C & 95% RH Yes
Availability of the test report from Central Govt/ NABL/ ILAC
accredited lab to prove conformity to the Specification Yes
Test Report Number and date for the Specification test (not a
part of biddable parameter) 350333
Name and address of the Lab for the Specification test (not a
part of biddable parameter) NTH(SR)
Inclusive of transportation, delivery at destination and GST
etc complete.

4

Compass

6

Specification :
• The compass should be dry and has the robust aluminum
body. Parts should be made up of nonferrous materials
except magnetic needle and should not be fragile.
• Di Compass should have luminous facility to facilitate night
reading. The light source should be with such type that
illumination does not require an external power source. The
illumination material should be serviceable for minimum 10
years (Certificate to be provided by OEM). Facility for hang
navigation must be made available in the compass.
• Index ring/Bezel (Outer ring where degree/pointer are
marked/mentioned/ printed/engraved) should move
smoothly but does not move freely i.e., move when
deliberate force is applied by user.
• Provision of Anti-friction pads/feature should be given.
• Compass should give accurate result in all climatic
condition. The inaccuracy should not exceed + (One) degree
from true course.
• Compass should give accurate bearing up to minimum 7
degree tilt.
• Compass should be correctly operated on the Temperature
Range between -40 to +60 degree centigrade.
• Graduation/marking provided for 360 degrees. The number
shall be printed/engraved at interval of | each 10 degrees,
each degree shall be displayed with a small line and each
fifth degree shall be displayed with a bigger line. All
graduation shall be distinguishable during day and night.
• Sighting device/sighting part should be an integral part of
compass body, user friendly and bearing should be visible
clearly.

22

<!-- page 23 -->

S.
No

Name of the
equipment

Quantity
in Nos

Specification of the equipment
• The forward and back bearing both are required to be read
simultaneously but user should be able to differentiate
clearly.
• Inner compartment should be properly sealed and strong
enough to prevent ingress of any foreign material inside the
compartment.
• Compass weight should not be more than 250 grams
• Size — Maximum 125mm x 60 mm x 40mm.
• It should be rugged, shock proof and water proof.
• The compass is contained in a soft durable carrying case
having suitable carrying strap. A durable hard
transportation box should be provided.
• Neck sling suitable attached with the compass should be
provided. It should be in loop from, 150 + 5 em long, 2.5 +
0.1 mm dia having lustreless green colour with provision for
neck sling should be available for compass.
• Compass should be durable and repairable,
• The list of repairable parts, nomenclature of the parts and
their cost, user manual with illustration in soft and hard
copy should be provided at the time of procurement,
• The outer body colour of the compass should be lustreless
green.
• The magnetic assembly shall come to rest within 6 second
of time being deflected 180 degrees from a position of
equilibrium.
Conformity to Specification As Per MHA QR for Dry Military
Compass issued by MHA vide NO. IV-21011/03/2012-Prov-I
dated 15th November 2012.
Availability of MHA QR Of Dry Military Compass Yes
Seen and Understand MHA QR of Dry Military Compass Yes
TEST REPORT
Test Report to be furnished to the buyer on demand Yes.
Inclusive of transportation, delivery at destination and GST
etc complete.

5

Generator (5
KV)

Specification
• Portable Generator type: Diesel start, diesel
run
• Rated Output at unity power factor at STP
(KV) :5KV
• Starting Type: Electric Self start
• Rated output Voltage :230 V AC
• Warranty (year) 2 year
06

RATED OUTPUT / STARTING &
RUNNING
• Portable Generator type: Diesel start, diesel
run
• Rated Output at unity power factor at STP
(VA): 5000
• Starting Type: Electric Self start
• Rated output Voltage :230 V AC

23

<!-- page 24 -->

S.
No

Name of the
equipment

Quantity
in Nos

Specification of the equipment

WARRANTY
• Warranty (year) :2 year
GENERIC
• Make and model of engine: KIRLOSKAR
CC418 G1
• Make and model of alternator: KOEL
GREEN/KIRLOSKAR
• Provision of Voltmeter and ammeter in the
output circuits: Yes
• Dimension of Genet in (LxWxH) mm x mm x
mm): 1150X560X840
• Dry weight (Kg) :190
• Period for which the Generator is capable of
delivering declared output :12 hour
• Fuel Tank capacity :12.5 liter
• Efficiency of the alternator (%): 74
• Noise Level of Portable Generator (dB(A)) :75
BATTERY
• Battery Ah capacity in case of Electric start
Generator (Ah) :35
CERTIFICATION / STATUTORY
REQUIREMENTS
• Type approval Portable Generating Set
meeting the requirements of Environmental
(Protection) Rules 1986, in respect of noise
and emission norms, as described in STC of
the Product: Yes
• Type approval number and date: 5635 DT:
28-06-16
• Availability of Test Report from Central
government/NABL/ILAC accredited
laboratory to prove conformity to the
specification for the Portable Generator Set:
Yes
• Test Report number and date: TT-800 DT:
16-12-14
Name and address of laboratory: NSIC
RAJKOT.Inclusive of transportation, delivery at destination
and GST etc complete.

•
Maintain periodically for 2 years after
completion of original warranty.

24

<!-- page 25 -->

Section – IV
SPECIAL CONDITIONS
1. Services to be rendered.
1.1. Supply of Search & Rescue Equipment as per technical specifications
mentioned in the Tender document.
1.2. Service & Support
Availability of Service Centers: Bidder/Consortium/OEM must have a Functional
Service Centre in the State of each Consignee's Location in case of carry-in
warranty. (Not applicable in case of goods having on-site warranty). If service
center is not already there at the time of bidding, successful bidder/consortium /
OEM shall have to establish one within 30 days of award of contract. Payment shall
be released only after submission of documentary evidence of having functional
service centre.
1.3. Warranty
Warranty period of the supplied products shall be minimum 1 years from the date
of final acceptance of goods or after completion of installation, commissioning &
testing of goods (certain items warranty more than 1 year i.e., specified in the scope
of the work), at consignee location. OEM Warranty certificates must be submitted
by Successful Bidder at the time of delivery of Goods. The seller should guarantee
the rectification of goods in case of any break down during the guarantee period.
Seller should have well established Installation, Commissioning, Training.
Troubleshooting and Maintenance Service group in INDIA for attending the after
sales service. Details of Service Centres near consignee destinations are to be
uploaded along with the bid.
Timely Servicing / rectification of defects during warranty period: After having
been notified of the defects / service requirement during warranty period, Seller
has to complete the required Service / Rectification within 15 days time limit. If
the Seller fails to complete service / rectification with defined time limit, a penalty
of 0.5% of Unit Price of the product shall be charged as penalty for each week of
delay from the seller. Seller can deposit the penalty with the Buyer directly else the
Buyer shall have a right to recover all such penalty amount from the Performance
Security (PBG). Cumulative Penalty cannot exceed more than 10% of the total
contract value after which the Buyer shall have the right to get the service /
rectification done from alternate sources at the risk and cost of the Seller besides
forfeiture of PBG.
2. Non-disclosure of confidential information:
The information, property and materials produced, created or supplied under the
contract, including preliminary technical reports and studies, shall not bed is
closed to any third party without the prior consent of the Managing Director,
APSDMA.
3. Record copies:
The Contractor shall retain a record, or copies of all materials developed in the
course of performing the work under this contract such as SOPs or Operational

25

<!-- page 26 -->

Manuals and copies of such materials will be supplied to the Head of the AP SDRF.
4. Payment:
Payments shall be made in Indian currency only. The method and conditions
ofpaymenttobemadetotheSupplierUnderContractarespecifiedhereunder.
The Supplier’s request(s) for payment shall be made to the Purchaser in writing,
accompanied by an invoice describing, as appropriate, the Search & Rescue
Equipment delivered and services performed, and by shipping documents,
submitted, and upon fulfilment of other obligations stipulated in the contract.
4.1 Terms of the Payment for supply of “Supply of Search & Rescue Equipment”:
90 % of the cost of the Supply of Search & Rescue Equipment on delivery to the
consignees i.e., A P State Disaster Response Forces, office of the Addl. Director
General, APSP & APSDRF c/o the Commandant, 6th Bn, APSP campus, Mangalagiri,
Guntur district, Andhra Pradesh state. along with submission of following
documents:
- Tax Invoice
- Inspection Reports/ Certificates
- Delivery Challans
- Acceptance certificate
- Certificate of no penalty or penalty imposed
4.2. 10 % of the cost of the Supply of Water Rescue Equipment after delivery of training
and submission of training report along with submission of following documents:
- Delivery of Training on usage of Search & Rescue Equipment and
submission of training report.
- Satisfactory certificate from the consignee.
5. Prices quoted shall be firm and not subject to adjustments during performance of
the contract. The currency of the payment shall be in Indian Rupees only.
6. Delay in supply of products:
(a) The Contractor shall supply the products as per the specifications. The Contractor
shall commence the work immediately after issuance of contract agreement.
(b) Delivery of the goods and performance of Services shall be made by the Supplier
in accordance with the time schedule specified by the Purchaser in its schedule of
Requirements and specifications.
(c) An unexpected delay by the Supplier in the performance of its delivery obligations
shall render the Supplier liable to any or all of the following actions, for feature of
its performance security/ Penalties or termination of the Contract for default.

(d) If at any time during performance of the Contract, the Supplier or its
subcontractor(s) should encounter conditions impeding timely delivery of the
goods and performance of services, the Supplier shall promptly notify the
Purchaser in writing of the fact of the delay its likely duration and its cause(s). As
soon as practicable after receipt of the Supplier’s notice, the Purchaser shall
evaluate the situation and may at its discretion extend the supplier’s time for
performance, in which case the extension shall be Ratified by the parties by

26

<!-- page 27 -->

amendment of the contract.
6. Penalty:
If the Seller fails to deliver any or all of the Goods/Services within the original/refixed Delivery/Time period(s) specified in the Contract, the Purchaser will be also
entitled to deduct/recover the Liquidated Damages for the delay, unless covered
under
Force
Majeure
conditions
afore
said,
@0.5%perweekorpartoftheweekofdelayedproductsfor the period as pre-estimated
damages not exceeding 5% of the contract value without any controversy/dispute of
any sort what so ever.
7. Survival:
Termination of this Contract for breach shall be governed by the terms of the
contract.
8. Force Majeure:
(a)
Not with standing the provisions of this contract, the Contractor shall not be
liable for forfeiture of its security deposit, liquidated damages, or termination for
default if and to the extent, that its delay in performance or other failure to perform
its obligations under the Contract if it is the result of an event of Force Majeure.
For purposes of this Clause, “Force Majeure” means an event beyond the
control of the Contractor and not involving the Contractor’s fault or negligence and
not foreseeable. Such events may include, but are not restricted to, acts of the
APSDMA in his sovereign capacity, wars or revolutions, cyber piracy or hacking,
terrorism, fires, floods, epidemics, earthquakes, other natural calamities, quarantine
restrictions and freight embargoes.

(b)

(c)

If a Force Majeure situation arises, the Contractor shall promptly notify the
APSDMA in writing of such condition and the cause thereof. Unless otherwise
directed by the Managing Director, APSDMA in writing the Contractor shall continue
to perform its obligations under the Contract as far as is reasonably practical and
shall seek all reasonable alternative means for performance not prevented by the
Force Majeure event.

9. Extension of contract/delivery period:
The Managing Director, APSDMA or a contractor by written communication shall
request the extension of contract period. The contractor or APSDMA shall have right
to either acceptor decline the request for extension of contract period.
10. Validity of rates quoted by bidder:
The rates quoted by the L1 bidder shall be valid for 1 year from the date of issue of
work/supply/sanction order. It is mandatory for the bidder to supply additional
quantity of Water Rescue Equipment up to 25% of tendered quantity at the same
rate, terms, conditions of this tender if the Managing Director, APSDMA desires to
buy the same the decision will be taken by competent authority. This is an option
purely with the Managing Director, APSDMA and does not create any liability
directly or indirectly to place any orders.

27

<!-- page 28 -->

11. Disputes:
All disputes and differences of any kind whatsoever arising out of or in connection
with the contract, whether during or after completion of contract will be settled
amicably in a spirit of co – operation and the APSDMA decision shall be final on all
such matters and shall be binding on the Bidder. Even then any dispute at arises will
be subject to jurisdiction of the courts of Andhra Pradesh.
12. Notices:
Any notice given by one party to the other pursuant to this Contract shall be
inwritingandmaybesenttotheotherpartybypersonalserviceorbyelectronicmailor by
speed post or by internationally recognized courier service and confirmed inwriting
to the other party’s address given in the cover page of Tender Document. A notice
shall be effective when delivered or on the notice’s effective date, whichever is later.
13. Assumption of Risk and Indemnification:
(a) Each party should agree to indemnify and hold the other, including its officers,
directors, agents and employees, harmless from and against all loss, cost, expense and
liability (including legal expenses) arising out of any claim or cause of action for loss
of damage to person or property, and injury or death of third parties, caused by,
resulting from, growing out of or incidental to the services provided or to be provided
by each party under the Contract and all weather modification operations
contemplated by the Contract. Each party should acknowledge that the indemnity
obligation to each other does not include damage to or loss of their respective property
or injury or death to each party’s respective employees,
(b) Contractor shall be responsible for the safety of the Government officers/staff during
delivery and shall be liable for payment of compensation for any
eventuality/untoward incidents.
14. The bidder shall quote their rates for entire quantity as per this Tender. Partial
quantity or any conditional offers will be rejected outrightly.
15. No deviation in the technical specifications in this tender shall be allowed. Whenever
the Brand names mentioned in the specification, please read the brand name along
with" or equivalent" word

28

<!-- page 29 -->

Section- V
TECHNICAL BID

All bidders shall invariably submit the information prescribed below along with technical bid
document
Annexure I: Technical Bid Check List
Annexure II: Bidder Letter Form
Annexure III: Bidder Information Sheet
Annexure IV: Non-Black listing Certificate
Annexure V: Financial Situation
Annexure VI: Technical Compliance Statement
Annexure VII: OEM Compliance (On OEM Letterhead)
Annexure VIII: List of Major Customers
Any other document in support of the prescribed qualification criteria

29

<!-- page 30 -->

Annexure II
Bidder Letter Form
From:
(Registered name and address of the bidder)
To
The Managing Director,
APSDMA
Tadepalli
Guntur District
Andhra Pradesh-520501
Sir,
Having examined the bidding documents and amendments there on, for the supply of
Water Rescue Equipment for AP State Disaster Response Force (APSDRF)
Mangalagiri, Guntur district, State of Andhra Pradesh in response to your tender call
dated___-02-2023.
1. I/We hereby offer to supply and install the item as listed in the schedule to this
tender hereto as you may specify in the acceptance of Tender at the price given in
the said schedule and agree to hold this offer open for a period of 90 days from the
date of opening of the tender.
2. I/we shall be bound by a communication of acceptance / rejection by APSDMA.
3. I/We have understood the Instruction to bidders and terms and conditions of
Contract in the form as enclosed with the invitation to the tender and have
thoroughly Examined the specifications quoted in the Schedule hereto and am/are
fully aware of the nature of the goods required and my/our offer is to supply the
goods strictly in accordance with the specifications and requirements.
4. Certified that ours is:
a) A sole proprietorship firm and the person signing the bid document is the sole
Proprietor/constituted attorney of the sole proprietor (OR)
b) A partnership firm, and the person signing this bid document is a partner of the
firm and has authority to refer to arbitration disputes concerning the business
of the partnership by virtue of the partnership agreement /by virtue of general
power of attorney (OR)
c) A company and the person signing the document is the constituted attorney/
authorized signatory.

5. I/We do hereby undertake that, until a formal notification of award, this bid,
together with your written acceptance thereof shall constitute a binding contract
between us.
(NOTE: Strike out whatever is not applicable. All corrections/deletions should invariably be
attested by the person authorized to sign the bid document).

30

<!-- page 31 -->

6. If bid is accepted, I/we undertake to;
a) Provide services/execute the work according to the time schedule specified in the
bid document,
b) Obtain the performance guarantee of a bank in accordance with bid
requirements for the due performance of the contract, and
c) Agree to abide by the bid conditions, which remain binding upon us during the
entire bid validity period and bid may be accepted any time before the expiration
of that period.
7. We understand that you are not bound to accept the lowest or any bid you may
receive, nor to give any reason for the rejection of any bid and that you will not
defray any expenses incurred by us in bidding.
Yours faithfully,
(Signature)
Dated this day of
Address:

Telephone:
__
E-mail: _______

31

<!-- page 32 -->

Annexure V
Bidder Information Sheet
1

Name of the organization

2

Year of establishment

3

Registered Office Address

4

PAN No

5

GST No

6

Name & Designation of
Authorized person:

7

Phone No.

8

Fax No.

9

Email-ID

10

Nature of the firm
(Proprietary/partnership/etc.…)

11

Whether Manufacturer/authorized
dealer/ Seller /Reseller

12 Total No. of service centers in India
Bank Details of the Agency:
Bank Name
13 Bank Address
Bank Account Number
IFSC Code
Amount Rs.:
DD No.
:
DD Date:
Issuing Bank &Branch:
Amount Rs.:
Payment Id :
Date
:
Issuing Bank &Branch:

Bid Document Fee
14
(Non-refundable)

15 EMD

32

<!-- page 33 -->

Annexure-IV
NON-BLACKLISTING CERTIFICATE
[To be submitted on letter head]
I/We here by certify that the [Name of the Company/firm] has not been ever
blacklisted/debarred by any Central/ State Government/ Public Undertaking / Institute
on any account.
I/We also certify that firm will be supplied the item as per the specification given by
APSDMA and also abide all the terms and conditions stipulated in the bid document.
I/We also certify that the information given in bid is true and correct in all aspects and in
any case at a later date it is found that any details provided are false and incorrect,
contract given to the concern firm or participation may be summarily terminated at any
stage, the firm will be blacklisted and APSDMA may impose any action as per the rules.
Date:

Name:

Place:

Business Address:

Signature of Bidder: Seal of the Bidder

33

<!-- page 34 -->

Annexure-V
Financial Situation

Bidder’s Legal Name:

Date:
Page of pages

Financial
information
in Rs.
Year1

Historic information for previous
(in Rs. million)

() years

Year2

Avg.

Year3

Year…

Yearn

Information from Balance Sheet
Total Assets (TA)
Total Liabilities
(TL)
Net Worth (NW)
Current
Assets (CA)
Current
Liabilities (CL)
Shareholder’s
Funds (Net
Worth)
= (Paid up
equity
+Reserves)
(revaluation
reserves
+Miscellaneous
expenditure
not written off)
Depreciation
Information from Income Statement
Total Revenue
(TR)
Profits Before
Taxes (PBT)

34

Avg.
Ratio

<!-- page 35 -->

Cash Flow Information
Cash Flow from
Operating
Activities
Net cash
accruals= Profit
after Tax
+depreciation
This information should be extracted from the Annual Financial Statements/ Balance sheets,
which should be enclosed. Year 1 will be the latest year for which audited financial statements are
available. Year 2 shall be they ear immediately preceding year
1 and year 3 shall be the year immediately preceding Year 2.

Attached are copies of financial statements (balance sheets, including all related notes, and
income statements) for the years required above complying with the following conditions:
(a) Must reflect the financial situation of the Bidder
(b) Historic financial statements must be audited by a certified accountant
(c) Historic financial statements must be complete, including all notes to the financial
statements
(d) Historic financial statements must correspond to accounting periods already
completed and audited (no statements for partial periods shall be requested or
accepted)

35

<!-- page 36 -->

Annexure-VI
Technical Compliance Statement
Technical compliance statement as per technical specifications mentioned in this
document (taking in to consideration all the amendments issued to this document, if any)
is to be submitted in the following format.

S.No

Item
No.
and
Name

Specification
Required

Specification of
quoted item along
with model, make and
special features, if any

36

Compliance
(Complied/
Complied
higher/Complied
lower)

<!-- page 37 -->

Annexure-VII
OEMs Authorization Certificate

To
The Managing Director,
APSDMA
Tadepalli
Guntur District
Andhra Pradesh-520501
Subject: OEM-Compliance Statement
Item
Description
Item
SI.No
(As per
Name
tender
document)

Qty
(Nos)

Offered
Make, Model
& Technical
Specifications

Complied
(Yes/ NO)

Deviation if
any

We hereby undertake that within the scope of requirement as per the products mentioned
above to provide support & product warranty services as per the tender document/___
yrs from the date of its installation/supply, just in case our authorized partners fail to
render the services.
The undersigned is authorized to issue such authorization on behalf of M/s
______________ (Name of the manufacturer).
For M/s _________ (Name of the manufacturer)
Signature & company seal
Name Designation
Email
Mobile No.
Office Address

37

<!-- page 38 -->

Annexure-VIII
List of Major Customers

S.No.

Costumer full address with Phone
number and mail id.

38

Year of supply

Equipment
supplied

<!-- page 39 -->

Annexure-IX
Format for Consortium Agreement
THIS JOINT BIDDING AGREEMENT is entered into on this the ………… day of
....................................................................................................................................................
20…
AMONGST
1. {…………, a Society/Company registered under the..................... }
and
having
registered office
at ………… (hereinafter referred to as the “First Part” which expression shall,
unless repugnant to the context include its successors and permitted assigns)

its

AND
2. {…………, a Society/Company registered under the ................................ } and having its
registered
office at................. (hereinafter referred to as the “Second Part” which expression shall,
unless
repugnant to the context include its successors and permitted assigns)
3. The above-mentioned parties of the FIRST, SECOND are collectively referred to as the
“Parties” and each is individually referred to as a “Party”.

WHEREAS,
A. Andhra Pradesh State Disaster Management Authority (APSDMA) (hereinafter referred to as
the “Authority”), which expression shall, unless repugnant to the context or meaning thereof,
include its administrators, successors and assigns) has invited bids (the “Bids”) by its Request
for Proposal No. xxxx dated xxx (the “RFP”) for selection of bidder for “ ”(the “Project”).
B. The Parties are interested in jointly bidding for the Project as members of a Consortium and in
accordance with the terms and conditions of the RFP and other Bidding Documents in respect
of the Project, and
C. It is a necessary condition under the RFP that the members of the Consortium shall enter into
a Joint Bidding Agreement and furnish a copy thereof with the Bid.

Now it is hereby agreed as follows:
1. Definitions and Interpretations

In this Agreement, the capitalised terms shall, unless the context otherwise requires, have
the meaning ascribed thereto under the RFP.
2. Consortium

The Parties do hereby irrevocably constitute a consortium (the “Consortium”) for the
purposes of jointly participating in the Bidding Process for the Project.
3. Covenants

The Parties hereby undertake that in the event the Consortium is declared the Selected
Bidder and awarded the Project, it shall enter into an Agreement with the Client and for
performing all its obligations as mentioned in the RFP

39

<!-- page 40 -->

4. Role of the Parties
The Parties hereby undertakes that Party of the First Part shall be the Lead Member of
the Consortium and shall have the power of attorney from all Parties for conducting all
business for and on behalf of the Consortium throughout the contract period.

Responsibilities of the Parties are detailed below:
S.No

5.

Party Name

Role on Project

Joint and Several Liability

The Parties do hereby undertake to be jointly and severally responsible for all obligations
and liabilities relating to the Project and in accordance with the terms of the RFP and the
Contract Agreement that will be signed with the Authority upon selection for the Project.
6. Representation of the Parties

Each Party represents to the other Parties as of the date of this Agreement that:
A. Such Party is duly organized, validly existing and in good standing under the laws of its
incorporation and has all requisite power and authority to enter into this Agreement;
B. The execution, delivery and performance by such Party of this Agreement has been
authorized by all necessary and appropriate corporate or Authority action and a copy of
the extract of the charter documents and board resolution/ power of attorney in favour of
the person executing this Agreement for the delegation of power and authority to execute
this Agreement on behalf of the Consortium Member is annexed to this Agreement, and
will not, to the best of its knowledge:
i.

require any consent or approval not already obtained;

ii.

violate any Applicable Law presently in effect and having applicability to it;

iii.

violate the memorandum and articles of association, by-laws or other applicable
organizational documents thereof;

iv.

violate any clearance, permit, concession, grant, license or other Governmental
authorization, approval, judgment, order or decree or any mortgage agreement,
indenture or any other instrument to which such Party is a party or by which such
Party or any of its properties or assets are bound or that is otherwise applicable
to such Party; or

v.

create or impose any liens, mortgages, pledges, claims, security interests, charges
or Encumbrances or obligations to create a lien, charge, pledge, security interest,
encumbrances or mortgage in or on the property of such Party, except for
encumbrances that would not, individually or in the aggregate, have a material
adverse effect on the financial condition or prospects or business of such Party
so as to prevent such Party from fulfilling its obligations under this Agreement;
C. this Agreement is the legal and binding obligation of such Party, enforceable in
accordance with its terms against it; and

40

<!-- page 41 -->

D. there is no litigation pending or, to the best of such Party’s knowledge, threatened to
which it or any of its Affiliates is a party that presently affects, or which would have a
material adverse effect on the financial condition or prospects or business of such Party
in the fulfillment of its obligations under this Agreement.
7. Termination

This Agreement shall be effective from the date hereof and shall continue in full force and
effect until the Termination of the Agreement with Authority. However, in case the
Consortium is either not prequalified for the Project, or does not get selected for award of
the Project, this Agreement will stand terminated upon return of the Bid Security by the
Client to the Lead Bidder
8. Miscellaneous
a) This Joint Bidding Agreement shall be governed by laws of India.
b) The Parties acknowledge and accept that this Agreement shall not be amended by the
Parties without the prior written consent of the Client.

IN WITNESS WHEREOF THE PARTIES ABOVE NAMED HAVE EXECUTED AND
DELIVERED THIS AGREEMENT AS OF THE DATE FIRST ABOVE WRITTEN.

SIGNED, SEALED AND DELIVERED
For and on behalf of
LEAD MEMBER (BIDDER) by:
Signature

SIGNED, SEALED AND DELIVERED
For and on behalf of
SECOND PART by:
Signature

41

<!-- page 42 -->

Annexure-X
Format for Power of Attorney for Lead Member of Consortium Agreement
Whereas ……………………………… (“the Client”) has invited bids for
....................................................................................................................................................
in the
State of Andhra Pradesh(“Project”). Whereas,
,
and
(collectively the “Consortium”) being Members of the Consortium are
interested in bidding for the Project in accordance with the terms and conditions of the
Request for Proposal and other connected documents in respect of the Project, and Whereas,
it is necessary for the Members of the Consortium to designate one of them as the Lead
Member with all necessary power and authority to do for and on behalf of the Consortium,
all acts, deeds and things as may be necessary in connection with the Consortium’s bid for
the Project and its execution.
NOW THEREFORE KNOW ALL MEN BY THESE PRESENTS
We,
at _

having our registered office at
, and M/s.

, M/s.

, having our registered office at

, having our registered office
,{insert

the

respective
names and addresses of the registered office} (hereinafter collectively referred to as the
“Principals”) do hereby irrevocably designate, nominate, constitute, appoint and authorize
M/s
, having its registered office at , being one of the Members of the Consortium,
as the Lead Member and true and lawful attorney of the Consortium (hereinafter referred to
as the “Attorney”) and hereby irrevocably authorize the Attorney (with power to subdelegate) to conduct all business for and on behalf of the Consortium and any one of us during
the bidding process and, in the event the Consortium is awarded the Project, during the
execution of the Project, and in this regard, to do on our behalf and on behalf of the
Consortium, all or any of such acts, deeds or things as are necessary or required or incidental
to the submission of its bid for the Project, including but not limited to signing and
submission of all applications, bids and other documents and writings, participate in bidders’
meetings and other conferences, respond to queries, submit information/ documents, sign and
execute contracts and undertakings consequent to acceptance of the bid of the Consortium
and generally to represent the Consortium in all its dealings with the Client, and/ or any other
authorized representative of the Client or any person, in all matters in connection with or
relating to or arising out of the Consortium’s bid for the Project and/ or upon award thereof
till the Contract Agreement is entered into with the Client.

AND hereby agree to ratify and confirm and do hereby ratify and confirm all acts, deeds and
things lawfully done or caused to be done by our said Attorney pursuant to and in exercise of
the powers conferred by this Power of Attorney and that all acts, deeds and things done by
our said Attorney in exercise of the powers hereby conferred shall and shall always be
deemed to have been done by us/Consortium.

42

<!-- page 43 -->

IN WITNESS WHEREOF WE THE PRINCIPALS ABOVE NAMED HAVE
EXECUTED THIS POWER OF ATTORNEY ON THIS DAY OF
2025.

For
(signature)
(Name & Title)
For
(signature)
(Name & Title)
(To be executed by all the Members of the Consortium)
Witnesses: [Notarized]
1.
2.
Notes:
1. The mode of execution of the Power of Attorney should be in accordance with the procedure,
if any, laid down by the applicable law and the charter documents of the executant(s) and
when it is so required, the same should be under common seal affixed in accordance with the
required procedure.
2. Also, wherever required, the Bidder should submit for verification the extract of the charter
documents and documents such as a resolution/ power of attorney in favour of the person
executing this Power of Attorney for the delegation of power hereunder on behalf of the
Bidder.
3. Power of Attorney should be executed on a non-judicial stamp paper of appropriate value
as
relevant to the place of execution (if required under applicable laws)

43

<!-- page 44 -->

Annexure-XI
Format for Power of Attorney for Sole Bidder
Know all men by these presents, we………………………………………………….(name
and address of the registered office) do hereby constitute, appoint and authorize Mr.
/ Ms…
. ................................................. (name and residential address) who is presently employed
with us
and holding the position of …………………………………………….as our attorney, to do
in our name and on our behalf, all such acts, deeds and things necessary in connection with or
incidental to our bid for <Insert RFP Name> including signing and submission of all
documents and providing information / responses to the APSDMA representing us in all
matters before APSDMA and generally dealing with APSDMA in all matters in connection
with our bid for the said Project. We hereby agree to ratify all acts, deeds and things lawfully
done by our said attorney pursuant to this Power of Attorney and that all acts, deeds and things
done by our aforesaid attorney shall and shall always be deemed to have been done by
us.
Dated
this
the
day of
200_

For

(Name, Designation and Address) Accepted

(Signature) (Name, Title and Address of the Attorney)
Date :
Note:
The mode of execution of the Power of Attorney should be in accordance with the procedure,
if any, laid down by the applicable law and the charter documents of the executants(s) and
when it is so required the same should be under common seal affixed in accordance with the
required procedure.

44

<!-- page 45 -->

45
