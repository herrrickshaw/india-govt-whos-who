---
doc_id: "f3493fbda6bde60a"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "adcc4f5c0eea004e"
---

<!-- page 1 -->

General Administration (SPF&MC)Department- Allotment of Persons for each
category of posts organised as local cadres of District, contiguous Districts,
Zone, contiguous Zone and Multi-zone in all Departments in conformity with the
provisions of the Andhra Pradesh Public Employment (Organisation of Local
Cadres and Regulation of Direct Recruitment) Order, 2025

Sl.
No.
1

Implementation Committees and
Composition

Purpose

District Level Implementation
Committee (DLIC):
(a)District Collector of the erstwhile
district –Chairman
(b) District Collector of the newly
formed district/s – Co-Chairman
(c)District level Department Head of
the erstwhile district – MemberConvener
(d)District Level Department Head/s of
newly formed district/s – Co-Convener

Allotment of persons to
District and contiguous
District cadre posts in all
Departments in erstwhile
and newly formed Districts
and contiguous Districts.

(e)District Revenue Officer of the
erstwhile and newly formed units –
Members

Stage-wise Timeline
Stage
Preliminary
Work
Stage-I

Stage-II

Activity
Verify cadres, posts, working strength, seniority lists,
readiness of option forms
Draft Seniority List (DSL) published & Option Forms
issued
Last date for objections
Final Seniority List (FSL) published
Employees submit Option Forms & verification

Last date for submission of Option Forms
Final Allocation List (FAL) published, Orders of
Stage-III & IV
Allotment (OOA) issued, affected employees identified
Opening of Rosters & Preparation of Indents
Stage-V
Orders of Transfer/Joining issued
Last date for joining new cadre

Timeline
15.07.2026
16.07.2026
20.07.2026
22.07.2026
22.07.2026 to
26.07.2026
26.07.2026
28.07.2026
30.07.2026
30.07.2026
05.08.2026

<!-- page 2 -->

Sl.
No
.
1.
2.
3.
4.
5.
6.
7.
8.

9.
10.
11.
12.
13.

Name
of
District

the

erstwhile Names of the new District(s) to
which employees of erstwhile
District Cadre are eligible for
allotment
Srikakulam,
Srikakulam, Parvathipuram Manyam
Vizianagaram,
Vizianagaram, Parvathipuram Manyam
Visakhapatnam,
Visakhapatnam,
Anakapalli,
Alluri
Sitharama Raju
East Godavari,
Kakinada,
Dr.
B.R.
Ambedkar
Konaseema, East Godavari
West Godavari
West Godavari, Eluru
Krishna.
Krishna, NTR
Guntur
Guntur, Palnadu, Bapatla
Prakasam
Prakasam, Sri Potti Sriramulu Nellore
(border mapping may apply in part
allocation
depending
on
cadre
distribution)
Sri Potti Sriramulu
Sri Potti Sriramulu Nellore, Tirupati
Nellore.
Chittoor,
Chittoor, Tirupati, Annamayya
YSR Kadapa
YSR Kadapa, Annamayya
Kurnool,
Kurnool, Nandyal
Ananthapuramu,
Ananthapuramu, Sri Sathya Sai

i) Each of the erstwhile Zones and the corresponding new Zones (full or part)
and Multi-Zones along with Districts are mentioned below for the purpose of
allotment of persons.
Presidential Order 1975
(4 Zones, 13 Districts)

Presidential Order 2025
(6 Zones, 26 Districts)

Zone
I:
Srikakulam,
Vizianagaram,
P.
Manyam,
Zone
I:
Srikakulam,
Visakhapatnam,
Anakapalli
Vizianagaram, Visakhapatnam
Zone II: ASR, E. Godavari,
Zone II: East Godavari, West
Kakinada,
Konaseema
Godavari, Krishna
Zone III: W. Godavari, Eluru,
NTR, Krishna

Multi-Zone

I

Zone
IV:
Guntur,
Palnadu,
Bapatla,
Prakasam,
Nellore
Zone III: Guntur, Prakasam,
Zone
V:
Tirupati,
Chittoor,
Nellore
Annamayya,
Kadapa II
Zone IV: Chittoor, Kadapa,
Zone VI: Nandyal, Anantapuramu,
Anantapuramu, Kurnool
Kurnool,
Sri Sathya Sai

<!-- page 3 -->

Workflow of the Implementation Committees
Stage-I: Verification





Verify cadre organization.
Verify cadre strength and working strength.
Prepare and verify Draft Seniority List (DSL).
Publish DSL and invite objections.

Stage-II: Final Seniority & Options




Dispose objections.
Publish Final Seniority List (FSL).
Receive Option Forms from employees.

Stage-III: Allotment




Verify employee options.
Consider preferential category claims.
Allocate employees based on:
o Working Strength
o Seniority
o Employee Options

Stage-IV: Allocation Orders



Publish Final Allocation List (FAL).
Issue Orders of Allotment (OOA).

Stage-V: Joining




Issue Transfer Orders (OOT), where required.
Employees join allotted local cadres.
Update Service Registers.

Stage-VI: Spouse Cases



Receive spouse transfer requests.
Process and issue orders.

Stage-VII: Appeals




Receive appeals.
Examine representations.
Issue final Government orders.

<!-- page 4 -->

Detailed information in each Stage
1. STAGE-I
Verification of Posts, Cadre Strength and Working Strength
1.1
The Implementation Committees shall verify the scheme of
organization of civil posts of each category as District, contiguous District,
Zonal, contiguous Zonal and Multi-Zonal for each Department as per the
G.O.s issued by General Administration (SPF & MC) Department in terms
of Paragraph -3 of the Presidential Order, 2025.
1.2
The Implementation Committeesshall also verify the cadre strength
andworking strength for each category of posts at District, contiguous
District, Zonal, contiguous Zonal and Multi-Zonal level, fixed for each
Department as per G.Os issued by the Finance Department.
1.3
The Implementation Committeesshall compare and ensure that the
distribution of posts among local cadres for each category in each
department is in conformity with the organization of posts issued by
General Administration (SPF & MC) Department.
1.4
The Implementation Committees shall ensure that no post or
person is left unaccounted or unallotted. Action shall be taken against the
person/s responsible, if it is detected at a later date, that any post or
person was concealed.
1.5
The Implementation Committees shall confirm that the above
exercise is in consonance with mapping of the erstwhile District, Zonal and
Multi-Zonal cadres with the corresponding newly constituted District,
contiguous District, Zonal, contiguous Zonal and Multi-Zonal level for each
Department as specified in Annexure–I to this Order and display the same
in the Departmental website for information.
Verification of Draft Seniority Lists (DSL) prepared for Allocation of
Persons
1.6The Implementation Committees shall verify and confirm that the Draft
Seniority List (DSL) of employees in each cadre, for the purpose of
allocationas per the Presidential Order, 2025 is:
(a) Prepared
in
strict
conformity
with
Circular
Memo
No.256656/SPFMC/ 2026, dated 09.06.2026 issued by General
Administration (SPF & MC) Department.
(b) Particulars in the Seniority List are compiled on basis of Service
Register entries and other conclusive records, duly certified by
the appointing authority.
(c) List includes all employees borne on the cadre, including those
on probation, leave of any kind, deputation, training,
suspension, on unauthorized absence/ absconding, etc.

<!-- page 5 -->

(d) No eligible employee of any cadre is omitted.
1.7
Employees on deputation shall be taken into account by their
parent Department and the allotment orders shall be issued by them.
1.8
DSL shall, inter alia, contain the details of (i) Seniority number,(ii)
Name,(iii) Gender, (iv)CFMS ID,(v) Mobile number, (vi)Date of birth, (vii)
Date of joining in the category, (viii)SC Group I, II, III, and STs as per the
Service Register.
1.9
DSL shall also contain in respect of the employees of Preferential
Categories, where applicable and certified by the appointing authority
after verification of the records, (ix) If Persons with Benchmark Disabilities
(PwBD) and Disability with their percentage (%), as certified in per
SADAREM Certificate, (x) having mentally challenged dependent children
(xi) widows who remained unmarried, (xii) employee him/herself suffering
from any of the followingailments:
a) Cancer;
b) Major Neurosurgery;
c) Kidney Transplantation;
d) Liver Transplantation;
e) Open Heart Surgery.
1.10 DSL has to be published immediately after Final Allocation of Cadre
strength and Working strength in each category of postfor the Department
in the Departmental websiteas per orders issued by Finance Department.
1.11 If any information in the DSL, furnished by an employee is found to
be false, incorrect, or misleading, then disciplinary action under the
APCS(CCA) Rules,1991 shall be initiated against the employee concerned
for inflicting a major penalty, besides for the rescinding any allotment
made on the basis of such information.
1.12 If any information in the DSL, isincorrectly certified or forwarded
without due verification, then disciplinary action under the APCS(CCA)
Rules,1991 shall be initiated against the employee concerned for inflicting
a major penalty.
1.13 It is clarified that the above Seniority List prepared shall be only for
the purpose of allocation to the local cadres as per Presidential Order,
2025.
1.14 The actual service seniority of the employee shall be determined as
per the applicable Service Rules, as always.
1.15 Inclusion in the Seniority list or position assigned therein, shall not,
either now or later, confer any vested right relating to allotment,
seniority, preference, or proportional allocation to the employee.

<!-- page 6 -->

1.16 Implementation Committees shall convene an orientation meeting
with Recognised Service Associations to explain the organization of local
cadres, principles governing allotment of post and personsand procedure
proposed for implementation of the provisions of the Presidential Order,
2025.
Issue Option Form (OF)
1.17The Option Forms (OF) shall be issued to all the employees included
in the DSL, by the Head of Office where the employee is working,
simultaneously with the publication of the DSL.
1.18 OF shall be issued in Format appended as Annexure–II to this
Order, enabling the employee to exercise preference among District,
contiguous District, Zone, contiguous Zone and Multi-Zone cadres.
2.STAGE- II
Publication of Draft andFinal Seniority List
2.1

DSL, after verification, shall be approved by the IC.

2.2
DSL shall be published in the Departmental website immediately
after the issue of orders regarding Final Allocation of Cadre and Working
Strength of the Department by the Finance Department.
2.3
Objections from employees shall be invited within five (5) days of
publication of the DSL.
2.4
Objections received shall be concurrently examined and disposed by
the IC.
2.5
Final
Seniority
List
(FSL)
shall
be
published
in
the
th
Departmentalwebsite on the 7 day from the date of publication of DSL.
2.6
Final Seniority List shall contain details of all objections received
and nature of the disposal.
2.7
The FSL shall also order that all the employees whose names are
mentioned in the FSL shall submit their Options Forms (OF) to the Head of
office through e-mail; within (5) days of the publication of the FSL.
Submission of Option Form
2.8
All Government servants in service, on deputation, leave,
suspension, training or foreign service shall submit Option Forms (OF) in
duplicate, indicating their preferences for allotment to the erstwhile or
new local cadre and claims, if any, under point 4.2 of this Appendix,
together with supporting documents and certificates issued by the
competent authorities, within five (5) days from the date of publication of
Final Seniority List (FSL), under acknowledgement on one of the Option

<!-- page 7 -->

Forms. The Option Forms shall be submitted to the Head of Office through
e-mail.
2.9
It shall be the duty of the Head of Office to obtain Option Forms
(OFs) from all employees working in his office and forward to the following
authorities through e-mail:
(i) The Head of the Department, being the Member-Convener of the
Implementation Committee in respect of employees proposed for
allocation to Multi-Zonal Cadres and also to those proposed for
allocation to Zonal and Contiguous Zonal Cadres in Departments,
where no Regional Offices exist under the administrative control of
the Head of the Department.
(ii) The Regional Officer, being the appointing authority and
Member-Convener of the Implementation Committee at the HoD
level, in respect of employees proposed for allocation to the Zonal
and Contiguous Zonal Cadres under his/her jurisdiction.
(iii) The Head of the District, being the appointing authority and
Member-Convener of the Implementation Committee at the District
level in the respective Department, in respect of employees
proposed for allocation to the District and Contiguous District
Cadres.
2.10 The Member-Convenor of the Implementation Committees shall
take further action and place the Option Forms before the Implementation
Committee for consideration.
2.11 Option once exercised by the employee shall be final and irrevocable,
and no request for alteration or modification shall be entertained
thereafter under any circumstances.
3. STAGE–III
Allotment of Persons
3.1
Implementation Committees shall ensure that allotment of the
persons is made strictly in accordance with provisions of Presidential
Order, 2025 and these orders.
3.2
Implementation Committees shall undertake allotment of personnel
with reference to (i) Final allocation of Posts (FAP) and Working Strength
(FWS) to the cadre by the Finance Department (ii) Seniority and
Preferential categories mentioned in the FSL (iii) Options exercised in OF
by the employees.
3.3
Implementation Committees shall ensure that no employee is left
un-allotted, including those on probation, leave of any kind, deputation,
training, suspension, on unauthorized absence/ absconding, etc.

<!-- page 8 -->

3.4
Implementation Committees shall function in an open and
transparent manner and shall not give any scope for any deviation from
the procedure.
3.5 All the Committee Members, Officials, and Staff involved in the
allotment process shall extend be patient, polite, extend utmost courtesy
&adopt a professional approach while interacting with the employees who
approach them with grievances. At the same time,the grievances shall be
dealt with firmly and objectively, leaving no scope for complaints
regarding the conduct of the allotment process.
Number of posts
3.4

Number of posts to be filled up shall be only to the extent of the

FWS.
4. STAGE –IV
Procedure for allotment of persons
4.1
After careful consideration of the matter including administrative
need, feasibility, seniority groups,composition of balanced local cadres,
preferences in terms of paragraph 3 of the Presidential Order, 2025,
Government hereby order that certain classes of employees shall be
exempted from the seniority-based allotment andinstead be extended
priority in allocation.
4.2
Such distinct classes of employees are designated as “Preferential
Categories”.
4.3
The employees belonging to the Preferential Categories in the FSL
shall be allotted in the first instance irrespective of their position in the
Final Seniority List.
4.4

The Preferential Categories shall be considered in the following

order.
(1) Employees with Persons with Benchmark Disabilities (PwBD) having
certified disability of seventy percent (70%) or above as certified in
SADAREM certificate
(2) Employees having dependent mentally challenged children.
(3) Employees who are Widows remained unmarried.
(4) Employees him/herself suffering withailments in the following order
of priority.
i) Cancer,
ii) Major Neurosurgery,
iii) Kidney Transplantation,
iv) Liver Transplantation, and
v) Open Heart Surgery.

<!-- page 9 -->

Tie Cases
4.5 If employees are equally eligible, then the FSL seniority shall be
considered in allotment.
Allotment of persons based on Seniority and Preference
4.6
After completion of allotment of all eligible cases under the
Preferential Categories, as specified above, allocation of the remaining
employees shall be made strictly on thebasis of FSL seniority, duly
considering preferences submitted in the Option Forms (OF)and the
allotment shall be made in descending order of seniority.
Procedure when allocable posts are exhausted in a Local Cadre
4.7
If an employee cannot be allocated the cadre or 1st option
mentioned in the OF due to the exhaustion of vacancies in the cadre by
the higher ranked seniors or Preferential Category candidates, the
allocation shall proceed as follows:
(a)
Subsequent Options: The employee shall be considered for
allotment against their 2nd, or 3rdoptions in descending order of
choice, subject to post availability and seniority.
(b)
Compulsory allotment: In the event that all the preferences
exercised by an employee are exhausted and no posts remain in
any of their preferred choices, the IC shall allocate such employee
to any remaining clear posts in the local cadre.
(c)
Where no option is exercised by any employee within the
prescribed time limit, their cases shall be considered and allotted to
in the available posts in the working strength.
Proportionate Distribution of Scheduled Castes and Scheduled Tribes
4.8
Scheduled Castes (SCs-Group-I, Group-II andGroup-III) andthe
Scheduled Tribes (ST) employees shall be proportionately distributed
among the local cadres based on the working strength. The percentage for
Group-I is (1%), Group-II is (6.5%) and Group-III is (7.5%).
4.9
After completion of the allocation based on Preferential Categories
and Seniority and Preferences,the distribution of three groups of SC
employeesand ST employees shall be reviewed with reference to the
prescribed proportionate requirement.
4.10 In case of shortfall, adjustment shall be made duly substituting the
last allotted General Category employee with the Scheduled Castes of
Group-I,II & III, as the case may be, or Scheduled Tribes employee.
4.11 In case, the number of three groups of SCs and the ST employees
allotted, including under Preferential Categories, meets or exceeds the

<!-- page 10 -->

prescribed proportionate requirement, no further adjustment shall be
made.
Publication of Final Allocation List (FAL) and Issue of Orders
4.12 Final Allocation List(FAL) shall be issued within (2) days of last date
of filing of the options.
4.13 FAL to District, contiguous Districts, Zonal, contiguous Zonaland
Multi-Zonal cadres shall be published in Departmental website in the
format appended as Annexure–III.
4.14 Based on the FAL, Orders of Allotment(OOA) shall be issued in the
format appended as Annexure–IVto this Order to all employees through email or any other method like whatsApp, physical copy, and a copy of the
OOA shall also be furnished to Head of Office (HOO)and communicated to
the employee concerned. The OOA shall be issued by the authorities as
mentioned in point 2.9 (i), (ii) & (iii) above. In respect of Multi-zonal
cadre, the appointing authority i.e. Secretary to the Government or Head
of the Department as the case may be, will issue the OOA.
4.15 On issue of the orders of allotment(OOA), it shall come into force
with immediate effect, and the respective local cadre shall stand
organized accordingly in terms of the Presidential Order, 2025.
5. STAGE-V
Submission of joining report and issue of posting order
5.1
Employee allocated to the same local cadre in which he is working
shall continue in the same post. Such employees shall submit a copy of
the OOA to the Head of Office for record.
5.2
The Appointing Authority shall identify the employees allotted to a
local cadre, other than the one in which they are presently working and
issue Orders of Transfer (OOT) within three (3) days from the date of
publication of the Final Allocation List (FAL).
(i)
In respect of Multi-Zonal cadre posts, where the Appointing
Authority is the Secretary to Government or the Head of the
Department concerned, as specified in the Government Orders
issued onorganising of local cadres, the said authority shall issue
the Orders of Transfer (OOT) to the employees allotted to the
respective Multi-Zonal Cadres.
(ii)
In respect of Zonal cadre and contiguous Zonal cadre posts,
the Head of the Department concerned shall issue the Orders of
Transfer (OOT).

<!-- page 11 -->

(iii)
In respect of District cadre posts, contiguous District cadre
posts , the erstwhile District Head of the Department concerned
shall issue the Orders of Transfer (OOT) to the employees allotted
to the respective District cadres.
5.3
Such employees shall join the new posts within (7) days of the
issue of the OOT.
5.4OOTs issued shall be deemed to be in relaxation of the ban on transfers
of employees imposed by the Finance Department.
5.5
The OOA shall be recorded in the personal Service Registers of all
employees.
5.6
Instructions will be issued separately in respect of the employees
who are on Special Intensive Revision (SIR) duty and Functionaries for
Census – 2027, for their relief and extending joining time in the allotted
cadre.
6. STAGE- VI
Spouse Cases
6.1

After completion of the allotment process under these guidelines,

issue of allotment orders and joining in the allotted local cadre, where
both spouses are working on a regular basis in the State Government,
whether in the same or different Departments and in any category of
posts, and are allotted to different local cadres, either spouse may apply
for change of local cadre to the local cadre in which the other spouse is
working.
6.2

One of the spouses seeking change of local cadre allotment to the

local cadre in which the other spouse is working may submit an
application in the prescribed format appended to this Order as AnnexureVII. The application shall be submitted to the Member-Convener of the
Implementation Committee concerned within three (3) days from the date
of joining in the allotted local cadre.
6.3

The Implementation Committee may consider the request for

change of local cadre of one of the spouses, provided a vacancy exists
within the allocable cadre strength in the requested local cadre after final
allotment. Such change shall be against the overall shortfall in the new

<!-- page 12 -->

local cadre and shall be subject to placement below the last regular
employee in that cadre and forfeiture of seniority in the erstwhile local
cadre.The IC shall consider and issue the orders within (7) days.
7. STAGE-VII
Appeals
7.1
Employees aggrieved by the OOA, can file an Appeal, after joining
in the post allotted, within seven days from the date of OOA in the Format
appended in Annexure-V to this order..
7.2
The Appeal shall lie to Secretary to Government of the Secretariat
Department
concerned,
and
made
through
the
Head
of
Department/District Head concerned , as the case may be.
7.3
The Secretary to Government, after consulting the IC concerned,
shall dispose the Appeal within five days in accordance with the Andhra
Pradesh Government Business Rules and communicate the decision to the
employee concerned.
7.4
In case, the disposal of a representation is likely to result in
modification of the allotment of any other employee, the affected
employee shall be issued a notice indicating the proposed change of local
cadre along with reasons therefor.
7.5
The affected employee shall be afforded opportunity to submit the
representation within a period of five days from the date of receipt of such
notice.
7.6
After consideration of the Appeal, the Government shall pass final
orders within a period of five days in the format appended in Annexure–V
to this order.
