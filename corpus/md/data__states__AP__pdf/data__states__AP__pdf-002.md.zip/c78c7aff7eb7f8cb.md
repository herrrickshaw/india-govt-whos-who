---
doc_id: "c78c7aff7eb7f8cb"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 22
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bf4352ccf88f4a28"
---

<!-- page 1 -->

Registered No. HSE-49/2016

RULES SUPPLEMENT TO PART I EXTRAORDINARY
No.19

AMARAVATI, FRIDAY, JULY 16, 2021

G.256

NOTIFICATIONS BY GOVERNMENT
--x--

HIGHER EDUCATION DEPARTMENT
(C.E)
THE ANDHRA PRADESH PRIVATE HIGHER EDUCATIONAL INSTITUTIONS
(ESTABLISHMENT, RECOGNITION, ADMINISTRATION AND CONTROL OF
INSTITUTIONS) RULES, 2021 FOR GRANTING PERMISSION TO START
PRIVATE UN-AIDED DEGREE COLLEGES, UN-AIDED UNDER GRADUATE
AND POST GRADUATE COURSES AND RELATED MATTERS THEREON.
[G.O.Ms.No.36, Higher Education (C.E), 15th July, 2021.]

NOTIFICATION
In exercise of the powers conferred by sections 20 and 21 read with section 99 of the
Andhra Pradesh Education Act, 1982 (Act No. 1 of 1982) and in supersession of G.O. Ms.No.29,
Education (Rules) dated. 5th February, 1987, and of all subsequent Government Orders, except
for those rules which in part or full pertains to Junior Colleges, Oriental Colleges, Hindi Maha
vidyalayas, Law Colleges, Government Degree Colleges and Aided Sections in Private Aided
Degree Colleges, the Government of Andhra Pradesh hereby makes the following rules for
the granting refusal and withdrawal of permission for New Private Un-aided Degree Colleges;
Un-aided Under Graduate and Post Graduate Programmes, and administrative matters
related to Degree Colleges under the Private Sector.

[1]

<!-- page 2 -->

2

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 3 -->

July 16, 2021]

RULES SUPPLEMENT

3

<!-- page 4 -->

4

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 5 -->

July 16, 2021]

RULES SUPPLEMENT

5

<!-- page 6 -->

6

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 7 -->

July 16, 2021]

RULES SUPPLEMENT

7

<!-- page 8 -->

8

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 9 -->

July 16, 2021]

RULES SUPPLEMENT

9

<!-- page 10 -->

10

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 11 -->

July 16, 2021]

RULES SUPPLEMENT

11

<!-- page 12 -->

12

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 13 -->

July 16, 2021]

RULES SUPPLEMENT

13

<!-- page 14 -->

14

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 15 -->

July 16, 2021]

RULES SUPPLEMENT

15

<!-- page 16 -->

16

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 17 -->

July 16, 2021]

RULES SUPPLEMENT

17

<!-- page 18 -->

18

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 19 -->

July 16, 2021]

RULES SUPPLEMENT

19

<!-- page 20 -->

20

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

<!-- page 21 -->

July 16, 2021]

RULES SUPPLEMENT

21

<!-- page 22 -->

22

ANDHRA PRADESH GAZETTE EXTRAORDINARY

[RSP-I

SATISH CHANDRA,
Special Chief Secretary to Government.

---x---

Published and Uploaded by the Commissioner of Printing, Government of Andhra Pradesh at
Government Regional Press, Vijayawada, www.apegazette.cgg.gov.in
