---
doc_id: "6d7d2e82ccfe9edc"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 35
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0e89abd72973e955"
---

<!-- page 1 -->

File No: J-12011/22/2023-IA.I(R)
Government of India
Ministry of Environment, Forest and Climate Change
IA Division

***

Date 14/10/2025

To,
Mr. Yakama Koteswara Rao
M/s. Andhra Pradesh Power Generation Corporation Limited
Vidyut Soudha, Hyderabad, 500082 Vidyut Soudha, Hyderabad, 500082, NTR, ANDHRA PRADESH,
Vidyut Soudha, Khairathabad, 520004
environment.apgenco@gmail.com
Subject:

Kamalapadu Closed Loop Pumped Storage Project (950 MW) in an area of 359.61 ha
located at Village Attiraladinne, Kamalapadu & Kundanakota etc., Sub-district
Peddapappur & Yadiki, District Anantpur, Andhra Pradesh by M/s Andhra Pradesh
Power Generation Corporation Limited

Sir/Madam,

This is in reference to your online application No. IA/AP/RIV/547838/2025, submitted on
19/08/2025 to this Ministry for the grant of Environmental Clearance (EC) under the
provisions of the EIA Notification, 2006, and its subsequent amendments. The application
pertains to the Kamalapadu Closed Loop Pumped Storage Project (950 MW) in an area of
359.61 ha at Village Attiraladinne, Kamalapadu & Kundanakota etc., Sub-district
Peddapappur & Yadiki, District Anantpur, Andhra Pradesh by M/s Andhra Pradesh Power
Generation Corporation Limited.

2. The particulars of the proposal are as below :

(i) EC Identification No.
(ii) File No.
(iii) Clearance Type
(iv) Category
(v) Project/Activity Included Schedule No.
(vi) Sector
(vii) Name of Project
(viii) Name of Company/Organization

IA/AP/RIV/547838/2025

EC25A0000AP5458706N
J-12011/22/2023-IA.I(R)
Fresh EC
A
1(c) River Valley/Irrigation projects
River Valley and Hydroelectric Projects
Kamalapadu Closed Loop Pumped Storage Hydro
Project
Andhra Pradesh Power Generation Corporation
Limited

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 1 of 35

<!-- page 2 -->

(ix) Location of Project (District, State)
(x) Issuing Authority
(xi) Applicability of General Conditions as per
EIA Notification, 2006

ANANTAPUR, ANDHRA PRADESH
MoEF&CC
No

3. In view of the particulars given in the Para 2 above, the project proposal inter-alia including Form-1(Part
A, B and C)/ EIA & EMP Reports were submitted to the MoEF&CC for an appraisal by the Expert
Appraisal Committee (River Valley & Hydro-electric) under the provision of EIA notification 2006, as
amended.
4. The above-mentioned proposal has been considered by the EAC in its 38th meeting held on 29.08.2025.
The minutes of the meeting and all the project documents are available on PARIVESH portal which can be
accessed from the PARIVESH portal by scanning the QR Code above.
5. The EAC after examining the information submitted and detailed deliberations recommended the
proposal for grant of prior Environmental Clearance by the Ministry to Kamalapadu Closed Loop Pumped
Storage Project (950 MW) in an area of 359.61 ha located at Village Attiraladinne, Kamalapadu &
Kundanakota etc., Sub-district Peddapappur & Yadiki, District Anantpur, Andhra Pradesh by M/s Andhra
Pradesh Power Generation Corporation Limited, under the provisions of EIA Notification, 2006 and as
amended with subject to compliance of applicable Standard EC conditions with the certain specific
environmental safeguard conditions (Annexure I).
6. The details of the Project as per the information submitted by the Project Propoent is enclosed as
Annexure II.
7. The MoEF&CC has examined the proposal in accordance with the provisions contained in the
Environment Impact Assessment (EIA) Notification, 2006, as amended and based on recommendation of
EAC, the Ministry, hereby accords approval for grant of Environmental Clearance to the project for
Kamalapadu Closed Loop Pumped Storage Project (950 MW) in an area of 359.61 ha at Village
Attiraladinne, Kamalapadu & Kundanakota etc., Sub-district Peddapappur & Yadiki, District Anantpur,
Andhra Pradesh by M/s Andhra Pradesh Power Generation Corporation Limited, under the provisions of
EIA Notification, 2006, as amended subject to compliance of the Specific and Standard EC conditions as
given in Annexure (1) for environmental safeguards.
8. The Environmental Clearance to the aforementioned project is under provisions of EIA Notification,
2006, as amended. It does not tantamount to approvals/consent/permissions etc. required to be obtained
under any other Act/Rule/regulation. The Project Proponent is under obligation to obtain approvals
/clearances under any other Acts/ Regulations or Statutes, as applicable, to the project.
9. The Ministry reserves the right to stipulate additional conditions, if found necessary at subsequent stages
and the project proponent shall implement all the said conditions in a time bound manner. The Ministry
may revoke or suspend the environmental clearance, if implementation of any of the above conditions is
not found satisfactory.
10. The above conditions will be enforced, inter-alia under the provisions of the Water (Prevention & Control
of Pollution) Act, 1974, the Air (Prevention & Control of Pollution) Act, 1981, the Environment
(Protection) Act, 1986, the Hazardous Waste (Management, Handling and Transboundary Movement)
Rules, 2016 and the Public Liability Insurance Act, 1991 read with subsequent amendments therein.

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 2 of 35

<!-- page 3 -->

11. The Validity of EC is upto 13 years to the start of production operations by the project or activity.
Validity of EC becomes perpetual subject to the start of production operations by the project or activity. In
case the project proponent fails to start the production operations within the EC validity date, application
for EC validity extension shall be submitted to the regulatory authority as per the provision contained in the
Para 9.0 of EIA notification, 2006, as amended.
12. General Instructions:

(a) The project proponent shall prominently advertise it at least in two local newspapers of the District or
State, of which one shall be in the vernacular language within seven days indicating that the project has
been accorded environment clearance and the details of MoEF&CC/SEIAA website where it is displayed.
(b) The copies of the environmental clearance shall be submitted by the project proponents to the Heads of
local bodies, Panchayats and Municipal Bodies in addition to the relevant offices of the Government who
in turn has to display the same for 30 days from the date of receipt.
(c) The project proponent shall have a well laid down environmental policy duly approved by the Board of
Directors (in case of Company) or competent authority, duly prescribing standard operating procedures to
have proper checks and balances and to bring into focus any infringements/deviation/violation of the
environmental / forest / wildlife norms / conditions.
(d) Action plan for implementing EMP and environmental conditions along with responsibility matrix of
the project proponent (during construction phase) and authorized entity mandated with compliance of
conditions (during operational phase) shall be prepared. The year wise funds earmarked for environmental
protection measures shall be kept in separate account and not to be diverted for any other purpose. Six
monthly progress of implementation of action plan shall be reported to the Ministry/Regional Office along
with the Six-Monthly Compliance Report.
(e) Concealing factual data or submission of false/fabricated data may result in revocation of this
environmental clearance and attract action under the provisions of Environment (Protection) Act, 1986.
(f) The Regional Office of this Ministry shall monitor compliance of the stipulated conditions. The project
authorities should extend full cooperation to the officer (s) of the Regional Office by furnishing the
requisite data / information/monitoring reports.
(g) Any appeal against this EC shall lie with the National Green Tribunal, if preferred, within a period of
30 days as prescribed under Section 16 of the National Green Tribunal Act, 2010.
(h) PP needs to comply the OM dated 24.07.2024 of MoEFCC, where it is stated that the plantation of
saplings shall be carried out in the earmarked 33% greenbelt area as part of the tree plantation campaign "
EK Ped Ma ke Naam" (एक पेड़ माँ के नाम (and the details of the same shall be uploaded in the MeriLife portal
(https://merilife.nic.in).
13. This issues with the approval of the Competent Authority.

Copy To

1. The Secretary, Ministry of Power, Sharm Shakti Bhawan, Rafi Marg, New Delhi 110 001
2. The Chairman, Central Electricity Authority, Sewa Bhawan R.K. Puram, New Delhi - 110 066.
IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 3 of 35

<!-- page 4 -->

3. The Chairman, Central Pollution Control Board, Parivesh Bhawan, CBD Cum-Office Complex, East
Arjun Nagar, Delhi - 110 032.
4. The Principal Chief Conservator of Forests & Head of Forest Force, Aranya Bhavan, K.M. Munshi
Road, Nagarampalem, Guntur – 522 004, Andhra Pradesh.
5. The Principal Secretary (DF S&T)Energy Forests and S&T Dept., D-Block, 2nd floor, A.P. Secretariat,
Government of Andhra Pradesh, Hyderabad-500 022 Andhra Pradesh.
6. Assistant Inspector General of Forests (C), Ministry of Environment, Forest and Climate Change, Sub
Office, Vijayawada Green House, Gopalareddy Road, Vijayawada – 520010, Andhra Pradesh
7. The Chairman, Andhra Pradesh State Pollution Control Board, D.No. 33-26-14 D/2, Near Sunrise
Hospital, Pushpa Hotel Centre, Chalamalavari Street, Kasturibaipet, Vijayawada – 520 010
8. Compliance and Monitoring Division, Ministry of Environment, Forest and Climate Change, Indira
Paryavaran Bhawan, Jor Bagh Road, New Delhi
9. Guard File/Record File/Monitoring File/Website of MoEF&CC.

Annexure 1
Specific EC Conditions for (River Valley/irrigation Projects)

1. Disaster Management
S. No

1.1

EC Conditions
Disposal of the excavated muck and its filling on the low-lying area with proper measures for the
stabilization and greenery to minimize the impacts of the generated construction muck shall be
taken up pari passu with construction work.

1.2

Stabilization of muck disposal sites using biological and engineering measures shall be taken up
immediately to ensure that muck does not roll down the slopes and does not pollute the natural
streams and water bodies in surrounding area. The plantation on muck disposal site with local
species for restoration of ecology and environment of the project site area.

1.3

Necessary control measures such as water sprinkling arrangements, and construction of paved roads
leading to muck disposal sites etc. shall be taken up on priority to arrest fugitive dust at all the
construction sites.

1.4

Solid waste generated, especially plastic waste, etc. should not be disposed of as landfill material. It
should be treated with scientific approach and recycled. Use of single-use plastics may be
discouraged.

1.5

Technical appraisal of project shall be obtained from CEA in terms of Office Memorandum no. 1523/3/2021-Hydel-II dated 29.08.2025 issued by the Ministry of Power, before start of construction
activities of the project.

2. Environmental Management And Biodiversity Conservation

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 4 of 35

<!-- page 5 -->

S. No

EC Conditions

2.1

The Environmental Management Plan (EMP) shall be strictly adhered to as submitted in the
EIA/EMP reports. The budgetary provisions for implementation of EMP, shall be fully utilized
and not to be diverted to any other purpose. In case of revision of the project cost or due to price
level change, the cost of EMP shall also be updated proportionately.

2.2

The contract clause limiting the No. of vehicles used during excavation and transportation shall
followed scrupulously and the same shall informed to the ministry.

2.3

Ambient Air Quality Monitoring Stations for real time data to be installed at project site before
commencement of the construction, shall be displayed at project site and its report to be
submitted to IRO, MoEF&CC.

2.4

No vehicle purchase shall be allowed from funds earmarked for implementation of Wildlife
Conservation plan. Measures for minimizing the human–animal conflict specially for black bear
and leopard be suitably incorporated in the wildlife conservation plan in consultation with State
Forest Department.

2.5

10000 plants shall be planted around the muck disposal area and the survival of plants shall be
submitted with the 6 monthly compliance report.

2.6

Plantation of saplings shall be carried out as a part of the tree plantation campaign "Ek Ped Ma
Ke Naam" and the details of the same shall be uploaded in the MeriLiFE Portal (
https://merilife.nic.in).

2.7

Watershed development plan prepared shall be implemented within 10 km radius of the project.
Implementation status be submitted in the 6 monthly compliance report to the concerned
regional office of the Ministry.

2.8

PP shall obtain necessary permission from the Tungabhadra Board to use water from the
Tungabhadra Dam.

2.9

The water of rainfall yield of self-catchment of the reservoir shall be released to downstream
through body of dam/ barrage/ embankment etc.

3. Socio-economic
S. No

EC Conditions

3.1

Land acquired for the project shall be suitably compensated in accordance with the prevailing
guidelines of the state government and provisions under Right to Fair Compensation and
Transparency in Land Acquisition, Rehabilitation and Resettlement Act, 2013.

3.2

RO plant shall be installed in the nearby 5 villages and the maintenance shall be done by the project
Authorities.

3.3

Solar panel be provided to the families living in rural areas within 10 km radius of project.

3.4

School up to 12th Standard shall be established and managed to provide free quality education for
children from project affected villages/Tribal villages. Adequate transportation facilities shall also

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 5 of 35

<!-- page 6 -->

S. No

EC Conditions
be provided to students to ensure connectivity and ease of access.

3.5

50 bed multi-specialty hospital shall be established to cater the need of tribal population/locals. The
tribal population within 10 km radius of the project shall be given free of cost medical facility.

3.6

Skill development Centre shall be established within 10 km radius of the project and regular
training programmes for development and promotion of traditional art/products of tribal/local
population.

3.7

Bio-Gas plant shall be installed in the Project affected area for Utilizing Cattle waste (Cow Dung)
into renewable source of fuel.

3.8

Preference in employment opportunities and admission to ITI institutions shall be given to Project
Affected Families (PAFs).

3.9

An institutional mechanism to be developed to ensure the preference of jobs to PAFs and also a
policy for preferential treatment for award of sundry works to the PAFs and their dependents.

3.10

The compliance of above conditions shall be monitored by IRO, MoEF&CC and regularly site visit
once in year. The compliance report of IRO shall be regularly submitted to MoEF&CC.

4. Miscellaneous:
S. No

EC Conditions

4.1

After 5 years of the commissioning of the project, a study shall be undertaken regarding impact of
the project on the environment. The study shall be undertaken by an independent agency.

4.2

A dedicated team to oversee environmental management activities (at project site) shall be set up
comprising Environment Manager having post graduate qualification in Environmental Sciences/
Environment Engineering along with other supporting staff. The Environment Manager Shall report
to Project Head directly.

4.3

PP shall procure construction material only from those Organizations having all valid legal/statutory
clearances/permissions or necessary permission to be obtained for quarrying construction materials
for the project as per the EIA Notification, 2006 and as amended thereof.

Standard EC Conditions for (River Valley/Irrigation projects)

1. Statutory Compliance
S. No

EC Conditions

1.1

The project proponent shall obtain forest clearance under the provisions of Forest (Conservation)
Act, 1986, in case of the diversion of forest land for non-forest purpose involved in the project.

1.2

The project proponent shall obtain clearance from the National Board for Wildlife, if applicable.

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 6 of 35

<!-- page 7 -->

S. No

EC Conditions

1.3

The project proponent shall prepare a Site-Specific Conservation Plan & Wildlife Management Plan
and approved by the Chief Wildlife Warden. The recommendations of the approved Site-Specific
Conservation Plan / Wildlife Management Plan shall be implemented in consultation with the State
Forest Department. The implementation report shall be furnished along with the six-monthly
compliance report. (in case of the presence of Schedule-I species in the study area).

1.4

The project proponent shall obtain Consent to Establish / Operate under the provisions of Air
(Prevention & Control of Pollution) Act, 1981 and the Water (Prevention & Control of Pollution)
Act, 1974 from the concerned State Pollution Control Board/ Committee.

1.5

NOC shall be obtained from National Commission of Seismic Design Parameters (NCSDS) of
CWC.

1.6

Necessary approval of CEA shall be obtained for those projects having the project cost more than
Rs. 1,000 crores.

2. Air Quality Monitoring And Preservation
S. No

EC Conditions

2.1

Regular monitoring of various environmental parameters viz., Water Quality, Ambient Air Quality
and Noise levels as per the CPCB guidelines at designated locations shall be carried out on monthly
basis and a detailed database of the same shall be prepared and recorded. This shall be used as a
baseline data for post construction EIA / Monitoring purposes.

2.2

Appropriate Air Pollution Control (APC) system shall be provided for all the dust generating points
including fugitive dust from all vulnerable sources, so as to comply prescribed standards.

2.3

Necessary control measures such as water sprinkling arrangements, etc. bet taken up to arrest
fugitive dust at all the construction sites.

2.4

Conjunctive use of surface water to be planned in the project to check water logging as well as to
increase crops productivity. The field drains shall be connected with natural drainage system (if
applicable).

2.5

Remodelling of existing natural drains (link drains) and connecting them with irrigated land through
constructed field drains, collector drains, etc. are to be ensured on priority basis (if applicable).

2.6

Before impounding of the water, Cofferdams for both at the upstream and downstream are to be
decommissioned as per EIA/EMP report so that once the project is commissioned; cofferdam
should not create any adverse impact on water environment including the rock mass and muck used
for the Cofferdam.

2.7

As the reservoir will be acting as balancing reservoir and there would be fluctuation of water level
during peaking period, efforts be made to reduce impact on aquatic life including impacts during
spawning period both at the upstream and downstream of the project.

2.8

Water depth sensors shall be installed at suitable locations to monitor e-flow. Hourly data to be
collected and converted to discharge data. The Gauge and Discharge data in the form of Excel Sheet

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 7 of 35

<!-- page 8 -->

S. No

EC Conditions
be submitted to the Regional Office, MoEF & CC and to the CWC on weekly basis.

2.9

Mixed irrigation shall be practised and necessary awareness be given to all the farmers and trained
in the use of such systems. Proper crops selection shall be carried out for making irrigation facility
more effective (if applicable).

2.10

On Farm Development (OFD) works like landscaping, land levelling, drainage facilities, field
irrigation channels and farm roads, etc. should be taken up in phased manner prior to the start of
irrigation in the entire command area. The Command Area Development Plan should be strictly
implemented as proposed in the EIA/EMP report (if applicable).

3. Noise Monitoring And Prevention
S. No

EC Conditions

3.1

All the equipment likely to generate high noise shall be appropriately enclosed or inbuilt noise
enclosures be provided so as to meet the ambient noise standards as notified under the Noise
Pollution (Regulation and Control) Rules, 2000, as amended in 2010 under the Environment
Protection Act (EPA), 1986.

3.2

The ambient noise levels should conform to the standards prescribed under E(P)A Rules, 1986 viz.
75 dB(A) during day time and 70 dB(A) during night time.

4. Catchment Area Treatment Plan
S. No

EC Conditions
Catchment Area Treatment (CAT) Plan as proposed in the EIA/EMP report shall be implemented in
consultation with the State Forest Department and shall be implemented in synchronization with the
construction of the project.

4.1

5. Waste Management
S. No

EC Conditions

5.1

Muck disposal be carried out only in the approved and earmarked sites. The dumping sites shall be
located sufficiently away from the HFL of the river. Efforts be made to reuse the muck for
construction and other filling purposes and balanced be disposed of at the designated disposal sites.
Once the muck disposal sites are inactive, proper treatment measures like both engineering and
biological measures be carried out so that sites are stabilized quickly.

5.2

Solid waste management should be planned in details. Land filling of plastic waste shall be avoided
and instead be used for various purposes as envisaged in the EIA/EMP reports. Efforts be made to
avoid one time use of plastics.

6. Green Belt And Wildlife Management

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 8 of 35

<!-- page 9 -->

S. No

EC Conditions

6.1

Based on the recommendation of Cummulative Impact Assessment and Carrying capacity study
of river basin or as per the ToR conditions or minimum 15% of the average flow of four
consecutive leanest months, whichever value is higher, shall be released as environmental flow.

6.2

Detailed information on species composition particular to fish species from previous
study/literature be inventoried and proper management plan shall be prepared for insitu
conservation in the streams, tributaries of river and the main river itself for which adequate
budget provision be made and followed strictly.

6.3

Wildlife Conservation Plan approved by the Chief Wildlife Warden shall be implemented in
consultation with the local State Forest Department.

6.4

To enrich the habitat of the project site, plantation shall be raised as envisaged in the EIA/EMP
report. Plantation to be developed along the periphery of the reservoir in multi-layers with local
indigenous species in consultation with the local State Forest Department.

6.5

Compensatory afforestation programme shall be implemented as per the plan approved.

6.6

Fish ladder/pass as envisaged in the EIA/EMP report shall be provided for migration of fishes.
Regular monitoring of this facility be carried out to ensure it effectiveness.

7. Public Hearing And Human Health Issues
S. No

EC Conditions

7.1

Resettlement & Rehabilitation plan be implemented in consultation with the State Govt. as
approved by the State Govt.

7.2

Budget provisions made for the community and social development plan including community
welfare schemes shall be implemented in toto.

7.3

Preventive measures viz. fuming and spraying of mosquito control shall be done in and around the
labour colonies, affected villages, stagnated pools, etc. Provisions be made to not to create any
stagnated pools to avoid creation of breeding grounds of the vector borne diseases.

7.4

Provision shall be made for the housing of construction labour within the site with all necessary
infrastructure and facilities such as fuel for cooking, mobile toilets, mobile STP, safe drinking
water, medical health care, crèche etc. The housing may be in the form of temporary structures to be
removed after the completion of the project.

7.5

Labour force to be engaged for construction works shall be examined thoroughly and adequately
treated before issuing them work permit. Medical facilities shall be provided at the construction
sites.

8. Risk Mitigation And Disaster Management

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 9 of 35

<!-- page 10 -->

S. No

EC Conditions

8.1

Early Warning Telemetric system shall be installed in the upper catchment area of the project
for advance intimation of flood forecast.

8.2

Drilling and blasting shall be done only either by licensed explosive agent or by the proponent
after obtaining required approvals from Competent Authorities.

8.3

Emergency preparedness plan be made for any eventuality of the dam failure and shall be
implemented as per the Disaster Management Plan.

8.4

Stabilization of muck disposal sites using biological and engineering measures shall be taken up
to ensure that muck does not roll down the slopes and shall be disposed safely and that it does
not pollute the natural streams and water bodies in surrounding area. The engineering measures
for the muck disposal arrangements be evolved after carrying out required slope stability
analysis.

8.5

Catchment area treatment plan shall be prepared and sufficient fund shall be provided for
afforestation, rim plantation, pasture development, nursery development.

9. Corporate Environment Responsibility
S. No

EC Conditions

9.1

The project proponent shall comply with the provisions contained in this Ministry's OM vide F.No.
22-65/2017-IA.III dated 30th September, 2020, as applicable, regarding Corporate Environment
Responsibility.

9.2

Skill mapping be undertaken for the youths of the affected project area and based on the skill
mapping, necessary trainings to the youths be provided for their long time livelihood generation

9.3

The company shall have a well laid down environmental policy duly approve by the Board of
Directors. The environmental policy should prescribe for standard operating procedures to have
proper checks and balances and to bring into focus any infringements/deviation/violation of the
environmental / forest / wildlife norms/ conditions. The company shall have defined system of
reporting infringements / deviation/violation of the environmental / forest / wildlife
norms/conditions and / or shareholders/ stake holders. The copy of the board resolution in this
regard shall be submitted to the MoEF&CC as a part of six-monthly report.

9.4

A separate Environmental Cell both at the project and company head quarter level, with qualified
personnel shall be set up under the control of senior Executive, who will directly report to the head
of the organization.

9.5

Action plan for implementing EMP and environmental conditions along with responsibility matrix
of the company shall be prepared and shall be duly approved by competent authority. The year wise
funds earmarked for environmental protection measures shall be kept in separate account and not to
be diverted for any other purpose. Year wise progress of implementation of action plan shall be
reported to the Ministry/Regional Office along with the Six Monthly Compliance Report.

9.6

Post EIA and SIA be prepared for the project through a third party and evaluation report be
submitted to the Ministry after five years of commissioning of the project.

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 10 of 35

<!-- page 11 -->

S. No

EC Conditions

9.7

Multi Disciplinary Committee (MDC) be constituted with experts from Ecology. Forestry, Wildlife,
Sociology. Soil Conservation, Fisheries, NGO, etc. to oversee implementation of various
environmental safeguards proposed in EIA/EMP report during construction of the project. The
monitoring report the Committee shall be uploaded in the website of the Company.

9.8

Formation of Water User Association/Co-operative be made involment of the whole community be
ensured for discipline use of available water for irrigation purposes

10. Miscellaneous
S. No

EC Conditions

10.1

The project proponent shall make public the environmental clearance granted for their project along
with the environmental conditions and safeguards at their cost by prominently advertising it at least
in two local newspapers of the District or State, of which one shall be in the vernacular language
within seven days and in addition this shall also be displayed in the project proponent's website
permanently.

10.2

The copies of the environmental clearance shall be submitted by the project proponents to the Heads
of local bodies, Panchayats and Municipal Bodies in addition to the relevant offices of the
Government who in turn has to display the same for 30 days from the date of receipt.

10.3

The project proponent shall upload the status of compliance of the stipulated environment clearance
conditions, including results of monitored data on their website and update the same on half-yearly
basis.

10.4

The project proponent shall submit six-monthly reports on the status of the compliance of the
stipulated environmental conditions on the website of the ministry of Environment, Forest and
Climate Change at environment clearance portal.

10.5

The project proponent shall submit the environmental statement for each financial year in Form-V
to the concerned State Pollution Control Board as prescribed under the Environment (Protection)
Rules, 1986, as amended subsequently and put on the website of the company.

10.6

The project proponent shall inform the Regional Office as well as the Ministry, the date of financial
closure and final approval of the project by the concerned authorities, commencing the land
development work and start of production operation by the project.

10.7

The project authorities must strictly adhere to the stipulations made by the State Pollution Control
Board and the State Government.

10.8

The project proponent shall abide by all the commitments and recommendations made in the
EIA/EMP report, commitment made during Public Hearing and also that during their presentation to
the Expert Appraisal Committee.

10.9

No further expansion or modifications in the plant shall be carried out without prior approval of the
Ministry of Environment, Forests and Climate Change (MoEF&CC).

10.10

Concealing factual data or submission of false/fabricated data may result in revocation of this

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 11 of 35

<!-- page 12 -->

S. No

EC Conditions
environmental clearance and attract action under the provisions of Environment (Protection) Act,
1986.

10.11

The Ministry may revoke or suspend the clearance, if implementation of any of the above
conditions is not satisfactory.

10.12

The Ministry reserves the right to stipulate additional conditions if found necessary. The Company
in a time bound manner shall implement these conditions.

10.13

The Regional Office of this Ministry shall monitor compliance of the stipulated conditions. The
project authorities should extend full cooperation to the officer (s) of the Regional Office by
furnishing the requisite data / information/monitoring reports.

10.14

The above conditions shall be enforced, inter-alia under the provisions of the Water (Prevention &
Control of Pollution) Act, 1974, the Air (Prevention & Control of Pollution) Act, 1981, the
Environment (Protection) Act, 1986, Hazardous and Other Wastes (Management and
Transboundary Movement) Rules, 2016 and the Public Liability Insurance Act, 1991 along with
their amendments and Rules and any other orders passed by the Hon'ble Supreme Court of India /
High Courts and any other Court of Law relating to the subject matter.

10.15

Any appeal against this EC shall lie with the National Green Tribunal, if preferred, within a period
of 30 days as prescribed under Section 16 of the National Green Tribunal Act, 2010.

Additional EC Conditions

The above conditions will be enforced inter-alia, under the provisions of the Water (Prevention & Control
of Pollution) Act, 1974, the Air (Prevention & Control of Pollution) Act, 1981, the Environment
(Protection) Act, 1986 and the Public Liability Insurance Act, 1991 along with their amendments and rules
made there under and also any other orders passed by the Hon’ble Supreme Court of India/High Court and
any other Court of Law relating to the subject matter.

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 12 of 35

<!-- page 13 -->

Annexure-II

Kamalapadu Closed Loop Pumped Storage Project (950 MW) at Village Attiraladinne,
Kamalapadu & Kundanakota etc., Sub-district Peddapappur & Yadiki, District Anantpur,
Andhra Pradesh by M/s Andhra Pradesh Power Generation Corporation Limited
The details of the project: -

The Project Proponent and the accredited Consultant M/s. R S Envirolink Technologies Pvt. Ltd.,
made a detailed presentation on the salient features of the project and informed that:
i.

The Kamalapadu Pumped Storage Hydro Project (Kamalapadu PSHP) of capacity 950 MW
is proposed at village Boyareddypalli in the Yadiki Mandal of Ananthapuramu district in
Andhra Pradesh by M/s Andhra Pradesh Power Generation Corporation Limited
(APGENCO). The project comes under the Rayalaseema region of Andhra Pradesh.

ii.

The Kamalapdu PSH Project is envisaged with a installed capacity of 950 MW (3 x 238 + 2
x 118 MW) located in the Ananthapuramu district of Andhra Pradesh. It is a standalone
scheme with two new off stream reservoirs and drawl of water from existing Chagallu
Barrage for initial filling into the proposed lower reservoir through a pipeline arrangement.
Both the reservoirs are planned to be interconnected through water conductor system and the
reversible generator pump turbine would be installed in the surface/ pit powerhouse. The
scheme is envisaged to meet the peak demand of about 9 hours with an estimated annual
energy generation of 2958.42 MU.

iii.

The project is located close to Boyareddypalli (Kamalapadu) Village in the Yadiki Mandal
of Ananthapuramu district in Andhra Pradesh. The project site is easily accessible by Yadiki
– Tadipatri Road. The project’s upper reservoir is at geographical co-ordinate 15°06'13.99"N
and 77°56'10.56"E and lower reservoir at geographical co-ordinate 15°05'0.74"N and
77°56'43.39"E.

iv.

The Terms of Reference was granted by Ministry of Environment, Forest & Climate Change
(MoEF&CC) vide letter no. F No J-12011/22/2023-IA. I(R) dated 7th August 2023 in the
name of M/s New and Renewable Energy Development Corporation of Andhra Pradesh Ltd.
(NREDCAP). Subsequently, MoEF&CC vide letter no. J-12011/22/2023-IA-I(R) dated
02.06.2025 has granted approval for transfer of Terms of Reference (ToR) for the
Kamalapadu Closed Loop PSP (950 MW) from ‘M/s New and Renewable Energy
Development Corporation of Andhra Pradesh Ltd. (NREDCAP)’ to ‘M/s Andhra Pradesh
Power Generation Corporation Limited (APGENCO)’.

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 13 of 35

<!-- page 14 -->

v.

Land requirement:
Forest Land :0.00 ha
Non-forest Land :359.61 ha (257.38 Ha of private land & 102.23 Ha of Govt. land)
Total Land :359.61 ha

vi.

Demographic details in 10 km radius of project area:
The study area falls under Ananthapuramu and Nandyal districts of Andhra Pradesh. A total
of 46 inhabited villages fell within the study area. Out of 46 villages, 42 are in
Ananthapuramu district (15 villages of Pedda Pappuru Mandal, 4 villages of Peddavaduguru
Mandal, 9 villages of Tadpatri Mandal, and 14 villages of Yadiki Mandal), and 4 villages are
in Nandyal district (1 village of Kolimigundla Mandal, 3 villages of Owk Mandal and no
habitation/ village lies in Pyapalli Mandal).
The total population of the study area is 130528, with 50.82% males and 49.17%females.
The number of households is 32240, with an average occupancy of 4–5 persons per
household. The child population below 6 years old was found to be 14406, which is 11.03%
of the total population. The sex ratio was found to be 967 females per 1000 males.59.89% of
the population ((above the 6-year-old population)) in the study are is literate. The rates for
males and females are 71.10% and 48.39%, respectively, resulting in a 22.71% gender
difference.
In the study area, 15.99% and 2.43 percent of the population are members of Scheduled
Castes and Scheduled Tribes, respectively.
Total population of workers in the study area is 73189 (56.07%).66.18% of the working
population are engaged in agriculture and allied services, out of which 19.50% are cultivators
and 46.68% are agricultural laborers. 11.04% of the population engaged in household
industry worker, and 22.75% of the population engaged in other services.

vii.

Water requirement: Approximately 22.45 MCM will be required to meet generation of 950
MW for 9.02 hours. Annual losses due to the evaporation from the lower reservoir work out
to 0.43 MCM. It will be recouped periodically from Chagallu Barrage reservoir.

viii.

Project Cost: The estimated project cost is Rs 4676.50 crore. Total capital cost earmarked
towards Environment Management Plan/environmental pollution control measures is Rs.
1966.11 lakh and the Recurring cost (operation and maintenance) will be about Rs. 2797.61
lakh about i.e. Rs 699.4 lakh per annum.

ix.

Project Benefit: Total Employment will be 700 persons during construction phase and 200
during operational phase of the project. Rs. 733.50 lakh has been allocated under CER and

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 14 of 35

<!-- page 15 -->

Local Area Development Plan for strengthening and development of basic infrastructural
facilities with a view to improve the quality of life of residents in the project vicinity.
x.

Environmental Sensitive area: Nearest protected area to the project components is Rajiv
Gandhi National Park, All the project components are way outside the notified ESZ,which
is at a distance of 72 km.

xi.

MoU / any other clearance/ permission signed with State government:
a) MOU: File No.ENE01-APRE/17/2020-MLO-ENE-Part(3) Dated 22/09/2023
b) Water Allocation: G.O.Ms no.10.dt.11.03.2025 of GoAP.

xii.

Resettlement and rehabilitation: For the development of Kamalapadu Closed Loop PSHP,
the total land requirement for the project is 359.61 ha, out of which 257.38 ha is private land
and 102.23 ha is government land.The entire private land identified for the project falls in
two revenue villages namely Kamalapadu and Kundanakota under Tehsil/Mandal-Yadiki in
Ananthapuramu District of Andhra Pradesh. The private land identified for the projects
belongs to 174 land owner families. All the 174 land owners will be losing their partial
agricultural land holding and none of the families will be losing any house or any other assets.
None of them is getting displaced due to the project from the above land procurement.

xiii.

Schedule – I species: According to WPAA, 2022, 13 species of mammals, one species of
bird (Small Minivet), 06 species of herpetofauna (Python, Bengal Monitor Lizard, Indian rat
Snake, Indian Cobra, Russel’s Viper and Indian Flap-shell Turtle) are listed under ScheduleI. Rest of the faunal species are listed under Schedule- II category of WPAA, 2022.
As per the IUCN Red List of Threatened Species, Version 2022-2, Wild Dog is listed under
Endangered (EN) category, Common Leopard, Sloth Bear, Four-horned Antelope, Sambar
Deer, Bonnet Macaque and Flap-shell Turtle are under Vulnerable (VU) category, Striped
Hyaena, Python, Bengal Monitor Lizard and Anamalai Hill Gecko are listed under Near
Threatened (NT) category. As per the IUCN Red List of Threatened Species version 20231, all birds have been listed under Least Concern (LC) category.

xiv.

Alternative Studies:5 alternatives have been studied for KamalapaduPumped storage Hydro
Project.
 Alternative-1 (1400 MW)-Independent PSP
 Alternative-2 (1200 MW)-Independent PSP
 Alternative-3 (1370 MW)- Independent PSP
 Alternative 4 (1120 MW)- (Independent PSP).
 Alternative 5 (950 MW)- (Independent PSP).

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 15 of 35

<!-- page 16 -->

After carefully considering the merits and drawbacks of all the alternatives, Alternative 5 has
been selected as the final layout.
xv.

Baseline Environmental Scenario:

Period

From April/May 2023 to December 2023

AAQ
Unit in microgram/m3
Core
Min
Max
parameters
PM
2.5
18.60
at
10
PM 10
43.10
locations
6.50
(min.
& SO2
NO2
7.00
Max.)
Buffer
Min
Max
PM 2.5
19.60
PM 10
45.40
SO2
6.90
NO2
8.30
Incremental
GLC Level

River water
samples
(2 samples)

Criteria
Pollutant
(PM10,
PM2.5, SO2,
NOx, Other
parameters
specific to the
sector
PM10
PM2.5
SO2
NOx

S. No
1
2
3
4
5
6
7
8

IA/AP/RIV/547838/2025

Average
42.20
73.20
12.60
13.50

30.40
58.15
9.55
10.25
Average

44.90
77.80
13.40
14.40

32.25
61.60
10.15
11.35

Standards
60
100
80
80
Standards
60
100
80
80

Unit
Baseline
(microgram/m3) Concentration
(A)

Predicted
incremental
value
considering
worst case
stability class
(B)

Total
GLC
(A +
B)

microgram/m3
microgram/m3
microgram/m3
microgram/m3

20
10
10
12

93.20
52.20
22.60
25.50

73.20
42.20
12.60
13.50

Core Zone
Parameters
pH
Total Dissolved Solids, mg/L
Dissolved Oxygen (mg/l)
Chloride (as Cl), mg/L
Total Hardness (as CaCO3),
mg/L
Biological Oxygen Demand
(mg/l)
Chemical Oxygen Demand
(mg/l)
Total Coliform (MPN/100 ml)

Min
7.9
625
7.7
101
233

Max
7.9
625
7.7
101
233

A
A
B
NA
A

2.8

2.8

A

9

9

B

295

295

A

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 16 of 35

<!-- page 17 -->

Ground
water
samples
(10 samples)

Noise levels
Leq (Day &
Night) at 10
locations

Buffer Zone
S. No Parameters
1 pH
2 Total Dissolved Solids, mg/L
3 Dissolved Oxygen (mg/l)
4 Chloride (as Cl), mg/L
Total Hardness (as CaCO3),
5 mg/L
Biological Oxygen Demand
6 (mg/l)
Chemical Oxygen Demand
7 (mg/l)
8 Total Coliform (MPN/100 ml)
Core Zone
S. No. Parameters
1
pH
Total Dissolved Solids
2
(mg/l)
3
Chloride (as Cl) (mg/l)
Total Hardness (as CaCO3)
4
(mg/l)
5
Fluoride (mg/l)
Buffer Zone
S. No. Parameters
1
pH
Total Dissolved Solids
2
(mg/l)
3
Chloride (as Cl) (mg/l)
Total Hardness (as CaCO3)
4
(mg/l)
5
Fluoride (mg/l)
Noise
Level
Core
Buffer

Zone
Residential
Commercial

Soil Quality
at
10
Locations
Monitoring
Location
(Core
/Buffer)

Core Zone

IA/AP/RIV/547838/2025

Min
8.3
286
5.5
110
431

Max
8.3
286
5.5
110
431

A
A
B
NA
A

6

6

A

15.4

15.4

B

430

430

A

Min
6.99
433

Max
7.4
1594

7.2
1013.5

8.5
2000

65
129

229
474

147.0
301.5

1000
600

0.16

0.57

0.4

1.5

Min
7.01

Max
7.4

7.2

8.5

377

943

660.0

2000

57

141

99.0

1000

112

280

196.0

600

0.14

0.34

0.2

1.5

Leq Night dB(A)
From
To
34.6
35.4
36.1
45.2

55
55

Leq Day dB(A)
From
To
44.9
45.9
46.8
58.5

Criteria
Unit
Parameter
[gm/mg/
[Calcium,
Other
Carbon,
(please
Nitrogen,
specify)]
Phosphorus,
Potassium,
Magnesium,
Sodium
Absorption Ratio,
Salinity]
Calcium
(mg/kg)

Observed
Value

From

To

140

165

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Permissible
standard

500

Page 17 of 35

<!-- page 18 -->

Buffer Zone

Flora
Fauna

Magnesium
Available Nitrogen
Available
Phosphorus
Available
Potassium
Organic carbon
Sodium
Adsorption Ratio
Salinity
Calcium
Magnesium
Available Nitrogen
Available
Phosphorus
Available
Potassium
Organic carbon
Sodium
Adsorption Ratio
Salinity

(mg/kg)
(kg/ha)

54
232

64
244

500
500

(kg/ha)

27

30

50

(kg/ha)

267

310

500

(%)

0.32

0.37 1

2.3

2.5

10

(ppt)
(mg/kg)
(mg/kg)
(kg/ha)

0
140
54
167

0
250
96
296

0.01
500
500
500

(kg/ha)

25

28

50

(kg/ha)

223

323

500

(%)

0.36

0.45 1

2.3

3.1

10

0

0

0.01

(ppt)

Particle Size Distribution
Water Holding
Porosity
Capacity (%)
(%)
Sand (%)
Silt (%)
Clay (%)
From To From To From To
From
To
From To
Core
62
69 8
10 21
29 34
40
38
48
Buffer 60
71 7
9 21
31 29
42
33
49
& According to WPAA, 2022, 13 species of mammals, one species of bird (Small
Minivet), 06 species of herpetofauna (Python, Bengal Monitor Lizard, Indian rat
Snake, Indian Cobra, Russel’s Viper and Indian Flap-shell Turtle) are listed
under Schedule I. Rest of the faunal species are listed under Schedule II category
of WPAA, 2022.
As per the IUCN Red List of Threatened Species, Version 2022-2, Wild Dog is
listed under Endangered (EN) category, Common Leopard, Sloth Bear, Fourhorned Antelope, Sambar Deer, Bonnet Macaque and Flap-shell Turtle are under
Vulnerable (VU) category, Striped Hyaena, Python, Bengal Monitor Lizard and
Anamalai Hill Gecko are listed under Near Threatened (NT) category. As per the
IUCN Red List of Threatened Species version 2023-1, all birds have been listed
under Least Concern (LC) category.

xvi.

Details of Solid waste/ Hazardous waste generation/ Muck and its management:
Generation of Municipal Solid Waste- Bio degradable (575.0 Tons in four years),
Generation of Non degradable (197.02 Tons in four years)

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 18 of 35

<!-- page 19 -->

Solid waste management shall involve Reuse/Recycling, Storage/Segregation, Collection and
Transportation and Disposal of Degradable component, non-degradable component& biomedical waste.
Total quantity of Muck to be dumped: 12.87lakh cum.
The entire excavated material is proposed to be dumped at two dumping sites identified over
a combined area of 81.91 ha. Dumping site no. 1 has been identified covering an area of
51.91 ha area, while dumping site no. 2 covering 30 ha is formed by filling up the quarry area
after obtaining the rock for construction. The toes of the disposal piles would be retained and
protected by providing suitably designed gabion walls erected over concrete bases.
Biological measures have also been suggested.
xvii.

Public Hearing for the proposed project has been conducted by the State Pollution Control
Board on 22nd, December 2023, at Kamalapadu (V), Yadiki (M), Ananthapuram District,
Andhra Pradesh. The main issues raised during the public hearing are:
Summary of Issues
Issues/Comments/Obser
vations
To provide employment
opportunities to the local
youth based on their
skills and qualifications.

Reply by the User Agency
During construction a large number of skilled and
unskilled workers shall be engaged in project activities,
majority of them will be from the local
population/surrounding villages.

Employment opportunities shall be provided in the
Project
authorities company or through the construction company as per
should hire local vehicles eligibility during the construction phase of the project.
during construction.
For development of required basic infrastructure facility
during construction and maintenance, contract will be
awarded to local villagers through the construction
company and priority has been given to locals during
hiring of vehicles.
Clarify the basis of
compensation for the
land acquired for the
project.

IA/AP/RIV/547838/2025

Land Compensation shall be as per Provisions of “The
Right to Fair Compensation and Transparency in Land
Acquisition, Rehabilitation and Resettlement Act”
(RFCTLARR) 2013 involving direct negotiations with
the landowners under monitoring of district
administration. (Rules issued through the Andhra
Pradesh G.O.MS. No. 389 dated 20-11-2014)

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 19 of 35

<!-- page 20 -->

No basic infrastructure
facilities in the villages

For infrastructure development in the villages
surrounding to the project, Local Area Development
Fund of Rs 7.335 Crore has been allocated and will be
spent during construction phase of the project.

Need to address the
land ownership issues.
Some of the villagers
have
not
Patta
passbook for the land.

District administration assured to resolve the issues
regarding land ownership and issuing a Patta passbook.
Accordingly fair compensation will be provided.

Fair compensation for
the land to be acquired.
Provide
alternate
sources of livelihood
for the land losers.

Skill development training will be imparted to local
youth to improve their employment opportunities in the
project under local area development plan.

Support
for
the
development of basic
infrastructure facilities
at
Kamalapadu
Boyareddypalli,
Chintalayapalli
and
other
surrounding
villages.
Provision
of
free
electricity
to
the
surrounding villages.

Provision of development and strengthening of basic
infrastructural facilities in project affected village
panchayats and surrounding villages shall be taken up
under Local Area Development Plan after consultation
with the concerned Gram Panchayats and District
Administration.

Support
for
the
construction of Kalyan
Mandapam
in
Chinthalayapalli
village.

Provision for the upgradation of religious places has
been kept under Local Area Development Plan after
consultation with the concerned Gram Panchayats and
District Administration.

Laying of BT road to
the temple.
Construction of toilets
to the female near the
temple.

IA/AP/RIV/547838/2025

APGENCO is committed to following the provisions
and guidelines issued by the State and Central
Governments regarding free or subsidized power to the
project area as well as to the state.

Development of basic amenities including community
toilets has been considered and shall be taken up under
the provisions made under Local Area Development
Plan after consultation with the concerned Gram
Panchayats and District Administration.

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 20 of 35

<!-- page 21 -->

Make donation to the
Chariot
Kotha
Ranganatha
Swamy
temple
at
Chinthalayapalli
village
Provide free technical
education for the higher
education students.

Provide free primary
education in the area
for the poor people in
the area.
Requested to construct
school from the area
under CSR fund

Skill development and training to interested local youth
shall be taken up under the provisions provided in the
section for Local Area Development Plan in
consultation with the concerned Gram Panchayats and
District Administration.
Provision of scholarships for poor and meritorious
students from the schools adjacent to project area have
been made under Local Area Development Plan
Financial provision of Rs 1.30 Crore has been kept for
infrastructure development and quality education for
existing government schools in the area.
Construction of new school shall be explored to be taken
up under CSR by APGENCO.

Approach roads in
Kamalapadu village are
in bad condition and
requested
the
management
to
maintain and upgrade
the village road in the
area.
Kundanakota village
also comes under the
purposed project and
requested
the
authorities to include
their village name in
the project title of the
proposed project.

Development of basic amenities including village
approach roads has been considered and shall be taken
up under the provisions made under Local Area
Development Plan after consultation with the concerned
Gram Panchayats and District Administration.

Provide
infrastructure

Development of basic amenities including development
of infrastructure in schools and beautification of temples
in the area has been considered and shall be taken up

IA/AP/RIV/547838/2025

to

basic
the

Inclusion of a village name in the project title is a
decision that rests with the State Government. It was
suggested to submit request or representation to state
authorities for their consideration.

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 21 of 35

<!-- page 22 -->

villages, schools and
temples in the area.

under the provisions made under Local Area
Development Plan after consultation with the concerned
Gram Panchayats and District Administration.

Authorities
should
develop green belt in
the project

Development of green belt around the project
components, road site planation and plantation over
proposed muck dumping sites after restoration have
been proposed - under Environmental Management
Plan.

Provide RO Plant to the
surrounding villages

Facility of safe drinking water shall be taken up under
the provisions made under Local Area Development
Plan after consultation with the concerned Gram
Panchayats and District Administration.

Adopt hospital in area
and
provide
free
medical camps, for
regular
medical
checkups
for
the
villagers.

Under the Local Area Development Plan, provisions has
been kept for upgradation of infrastructural facilities of
existing medical institutes and medical camps. These
initiatives will be undertaken in consultation with the
District Administration to ensure that the upgrades meet
the specific needs of the communities.
Furthermore, our Environmental Management Plan
includes provisions for establishing a First Aid posts at
all construction sites within the project area. This will be
complemented by an ambulance facility to ensure
prompt medical assistance in case of emergencies. Also
provision has been kept for organize medical camps in
the neighboring villages in collaboration with the district
health department.

Administration utilize
District Mineral Fund
(DMF) collected by
district administration
for the development of
surrounding villages.
There is no availability
of water in the
Pendekallu Reservoir,
how the management
of the project will get
the water from the
reservoir

IA/AP/RIV/547838/2025

District Administration assured that District Mineral
Fund available with district administration will be
utilized development of surrounding villages

Project management informed that the total quantum of
water required for initial filling of both reservoirs
together is worked out to 22.32 MCM. Source of water
has been changed from Pendekallu Reservoir to
Chagallu barrage reservoir as explained in Chapter 1 of
EIA report.

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 22 of 35

<!-- page 23 -->

Provisions to avoid
obstruction of the
natural water flow due
to
the
proposed
establishment.

Both the reservoirs are proposed to be constructed on
multiple streams which further downstream merges and
is known as Pedda Vanka, a left tributary of Penneru
River. The catchment area of these streams at the dam of
both the reservoirs is 6.05 sq km. As per CEA guidelines,
all the water intercepted from catchment of new
reservoirs has to be discharged downstream through
appropriate provisions like spillways or interception
drains etc. to be provided in the project design.

Provide water supply
for about 8000 acres by
constructing reservoir.

Drinking water supply provisions have been kept under
Infrastructure development in local area development
plan for all the hamlets of Kamalapadu, Kundanakota,
Gudipadu villages.
Also, provisions have been kept for repair/ renovation of
the existing drinking water resources (Overhead tanks,
wells, distribution points, pipelines etc.) in same area. A
total cost provision of Rs 20.50 lakh has been kept for
purpose.

Management
shall
provide mini library in
their area for the
educated youth.

Provision of Mini Library has been made under Local
Area Development Activities under upgradation of
Education Facilities head.

xviii.

Status of Litigation Pending against the proposal, if any: Not Applicable

xix.

The salient features of the project are as under:



Project details:
Name of the Proposal
Proposal No.
Location
(Including Coordinates)

IA/AP/RIV/547838/2025

Kamalapadu Pumped Storage Hydro Project
(950 MW)
IA/AP/RIV/547838/2025
Near Kamalapadu village,
Ananthapuramu district of Andhra
Pradesh State
Lower Reservoir- Lat: 15° 5' 0.74" N
Long: 77°56' 43.39" E
Upper Reservoir- Lat: 15°6' 13.99" N
Long: 77°56' 10.56" E

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 23 of 35

<!-- page 24 -->

Company's Name
CIN no. of Company/user agency
Accredited Consultant and certificate
no.
Project location (Coordinates /River/
Reservoir)

Inter- state issue involved
Proposed on River/ Reservoir
Type of Hydro-electric project
Seismic zone


No
Chagallu reservoir
Pumped Storage Project
Seismic Zone II

Category details:

Category of the project
Capacity I Cultural command area
(CCA)
Attracts the General Conditions
(Yes/No)
Additional information (if any)



Andhra Pradesh Power Generation
Corporation Limited
U40109AP 1998SGC 109187
R S Envirolink Technologies Pvt Ltd;
NABET/EIA/25-28/RA 0415
Near Boyareddypalli (Kamalapadu) Village
in the Yadiki Manda I of Ananthapuramu
district in Andhra Pradesh

A
950 MW
No
-

TOR/EC details:

ToR Proposal No.
EAC meeting date
ToR Letter No.
ToR grant Date
Cost of project
Total area of Project
Height of Dam from River Bed (EL)
Details of submergence area
District to provide irrigation facility (if
applicable)
Details of tunnels on upper level.& lower
level and length of canal (if applicable)
No. of affected Village

IA/AP/RIV/547838/2025

IA/AP/RIV/429576/2023
02.06.2023
J- 12011/22/2023 -IA.I (R)
07.08.2023
Rs 4676.50 crore
359.61 ha
Upper Dam-36.50 m
Lower Dam-34.70 m
247.11 ha
NA

Two revenue villages namely Kamalapadu
and Kundanakota under Tehsil/Mandal-

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 24 of 35

<!-- page 25 -->

No. of Affected Families
Project Benefits

IA/AP/RIV/547838/2025

Yadiki in Ananthapuramu District of Andhra
Pradesh
The private land identified for the projects
belongs to 174 land owner families.
The levelized cost of generation of the project
has been found to be Rs 6.50/kWh
considering cost of pumping @ Rs 3.00/kWh.
Kamalapadu pumped storage hydro project is
a technically feasible project and will be
beneficial in meeting the peaking
requirement of energy during evening/night
in the beneficiary state i.e., Andhra Pradesh.
For construction of Kamalapadu PSH
Project, no forest land shall be diverted, and
the proposed project is off-stream pumped
Storage project and have not any impact on
natural water bodies. To develop Greenbelt
in the surrounding of project area, plantation
over 82 ha is proposed over restored muck
dumping other construct ion sites.
The entire private land identified for the
project falls In two revenue villages namely
Kamalapadu and Kundanakota under
Tehsil/Mandal-Yadiki in
Ananthapuramu
District of Andhra Pradesh. The private land
identified for the projects belongs to 174 land
owner families. All the 174 land owners will
be losing their partial agricultural land
holding and none of the families will be
losing any house or any other assets. None of
them is getting displaced due to the project
A.
Purchase of Private Land The
private land required for the project is
proposed to be purchased through a voluntary
sale with a willing seller and willing buyer
basis. The process is undertaken through
direct negotiations between landowners and
Project Proponent. The landowners are
informed in advance , and each landowner
negotiates on the price of land as part of land
take.
B. Govt. Land: For the Government land
required for Project, APGENCO has
submitted land acquisition proposal to the
District
Collector,
Ananthapuramu.
Allotment is under process. The District

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 25 of 35

<!-- page 26 -->

ToR Proposal No.
EAC meeting date
ToR Letter No
ToR grant Date
Cost of project
Total area of Project
Height of Dam from River Bed (EL)
Details of submergence area provide
irrigation facility (if applicable)
Details of tunnels on upper level.& lower
level and length of canal (if applicable)
No. of affected Village

No. of Affected Families
Project Benefits

R&R details

IA/AP/RIV/547838/2025

Collector, Ananthapuramu has issued orders
for Advance Possession of Govt land.
IA/AP/RIV/429576/2023
02.06.2023
J- 12011/22/2023 -IA.I (R)
07.08.2023
Rs 4676.50 crore
359.61 ha
Upper Dam-36.50 m
Lower Dam-34.70 m
247.11 ha District to
NA
Two revenue villages namely
Kamalapadu and Kundanakota under
Tehsil/Mandal-Yadiki in Ananthapuramu
District of Andhra Pradesh
The private land identified for the projects
belongs to 174 land owner families.
The levelized cost of generation of the
project has been found to be Rs 6.50/kWh
considering cost of pumping @ Rs
3.00/kWh. Kamalapadu pumped storage
hydro project is a technically feasible
project and will be beneficial in meeting the
peaking requirement of energy during
evening/night in the beneficiary state i.e.,
Andhra Pradesh. For construction of
Kamalapadu PSH Project, no forest land
shall be diverted, and the proposed
project is off-stream pumped Storage
project and have not any impact on natural
water bodies. To develop Greenbelt in
the surrounding of project area, plantation
over 82 ha is proposed over restored muck
dumping other construct ion sites.
The entire private land identified for
the project falls. In two revenue villages
namely Kamalapadu and Kundanakota
under
Tehsil/Mandal-Yadiki
in
Ananthapuramu District of Andhra
Pradesh. The private land identified for
the projects belongs to 174 land owner

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 26 of 35

<!-- page 27 -->

families. All the 174 land owners will be
losing their partial agricultural land
holding and none of the families will be
losing any house or any other assets .
None of them is getting displaced due to
the project
A. Purchase of Private Land The private
land required for the project is proposed
to be purchased through a voluntary sale
with a willing seller and willing buyer
basis. The process isundertaken through
direct negotiations between landowners and
Project Proponent. The landowners are
informed in advance, and each landowner
negotiates on the price of land as part of
land take.

Catchment area/ Command area

B. Govt. Land: For the Government land
required for Project, APGENCO has
submitted land acquisition proposal to the
District
Collector,
Ananthapuramu.
Allotment is under process. The District
Collector, Ananthapuramu has issued orders
for Advance Possession o f Govt land.
Both Upper and Lower reservoirs are
proposed to be constructed on multiple
streams which further downstream merges
and is known as Pedda Vanka, a left
tributary of Penneru River. The catchment
area of these streams at the dam of both the
reservoirs is 6.05 sq km.

Types of Waste and quantity of generation Municipal Solid Waste- Bio degradable
during construction/Operation
(575.0 Tons in four years), Non degradable
(197.02 Tons in four years)
Material used for blasting and its It has been assessed that one magazine of 20
composition as per DGMS standards.
MT capacit ies would be sufficient to meet the
requirements of the project. A mobile
explosive van sha ll be deployed to carry
explosives at the site of use at upper and lower
dam area. Movement of the vans hould be
done with armed guards and proper
documentation recommended by PESO.

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 27 of 35

<!-- page 28 -->

E-Flows for the Project

Proposed project is standalone Closed loop
pumped storage scheme and provision of Eflow is not required for the scheme.
However to maintain the inflow run-off
from the catchment through the spillway
designed for both upper and lower
reservoir.
Is Projects earlier studied in Cumulative No
Impact assessment & Carrying Capacity
Studies(CIA&CC) for River in which
project located . If yes then
c) E-flow with TOR/Recommendation by
EAC as per CIA&CC study of River Basin.
d) If not the E-Flows maintain criteria for
sustain ing river ecosystem. Details on
provision of fish pass
Project benefit including employment
The proposed project is Off-stream Closed
details (no of employee)
Loop project. It is proposed to utilize the
water from existing Chagallu barrage for
initial filling of the Kamalapadu PSH
reservoir. Both the proposed upper and
lower reservoirs are artificial reservoirs
and are not located on any active streams.
Kamalapadu PSH Project is planned to be
completed in 42Calendar months (excluding
pre-construction activities), at the time of
peak construction work in the project,
around 700 persons may be engaged. Out of
700 nos., about 70% will be from the local
population/surrounding Villages and balance
persons will be skilled/semiskilled from
other area. In addition, the project would
lead to creation of direct and indirect
employment opportunities as new factories
would come up. 1n and around the project
due to reliable power supply/availability,
contract works for the locals during
construction and operation phase, etc. Since
there is no requirement of any forest land
diversion for construction of various
components, therefore requirement of
preparation of Compensatory Afforestation
Plan is not applicable in the present case.
Area of Compensatory Afforestation (CA)
with tentative no of plantation.

IA/AP/RIV/547838/2025

500

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 28 of 35

<!-- page 29 -->

Previous EC details
EC Compliance Report by R.O,
MOEF&CC
No. of trees/saplings proposed in the view
of 'Ek Ped Maa Ke Naam' campaign



Electricity generation capacity:
Powerhouse Installed Capacity
Generation of Electricity Annually
No. of Units



950 MW
2958.42 MU
5; 950 MW [3 x 238 + 2 x 118]

Muck Management Details:
No. of proposed disposal area/
(type of land- Forest/Pvt land)

.
Distance of muck disposal
area(location), from muck generation
sources (project area)/River, HFL of
proposed muck disposal area

Net Quantity of
Muck
to
be
rehabilitated/disposed of is
estimated as
12,873,413 cum. Keeping the above
requirement and topography of the area ,
dumping site no. 1 has been identified covering
an area of 51.91 ha area with a total capacity of
8,283,413 cum muck . The dumping site no. 2
covering 30 ha is formed by filling up the quarry
area after obtaining the rock for construction.
This site is proposed to hold 4,950 ,000 cum.
500 m

Total Muck Disposal Area

81.91 ha

Estimate Muck to be generated

1,18,32,187.99 cum

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 29 of 35

<!-- page 30 -->



Transportation

The generated muck will be carried 1n
dumper trucks tightly covered in line with
international best practices. A ll precautionary
measures will be followed during the
dumping of muck. All dumpers will be well
maintained to avoid any chances of loose
soil from being falling during transportation
. All unpaved routes will be periodically
wetted with the help of sprinklers prior to
the movement of dump trucks.

Monitoring mechanism for Muck
Disposal Transportation

The provisions of Monitoring have been
kept under proposed Environmental
Monitoring Plan.

Land Area Breakup:

Private land
Government land

257 .38 ha Private land
102.23 ha Govt. land

Forest land
Total land
Submergence area/reservoir area

0.00
359.61 ha
247.11 ha

Additional information (if any)



Presence of Environmentally Sensitive areas in the study area
Forest Land/ Protected Area/
Environmental Sensitivity Zone

Yes/No

Details
of
letter/Remarks

Reserve Forest/Protected Forest
Land
National Park
Wildlife Sanctuary

No

monuments/historical temples
Archaeological sites etc

No

No project component falls in any
notified protected area. The nearest
protected area to the project
components
is Rajiv Gandhi
National Park, which is at a distance
of 72.0 km. All the project
components are outside the notified
ESZs of Rajiv Gandhi National
Park.
No places of historical, religious or
archaeological
importance
were
reported from the study area. Each

IA/AP/RIV/547838/2025

No
No

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Certificate/

Page 30 of 35

<!-- page 31 -->

village in the study area has some
cultural sites or sites of religious
significance like temples, mosques,
Church, graveyards etc.
Additional information (if any)
Availability of Schedule-I species
in Study area



Conservation Status of Fauna
According to WPAA, 2022 , 13
species of mammals, one species of
bird (Small Minivet), 06 species of
herpetofauna
(Python,
Bengal
Monitor Lizard, Indian rat Snake,
Indian Cobra, Russel's Viper and
Indian Flap-shell Turtle) are listed
under Schedule I. Rest of the faunal
species are listed under Schedule II
category of WPAA, 2022. As per the
IUCN Red List of Threatened Species,
Version 2022-2, Wild Dog is listed
under Endangered (EN) category,
Common Leopard, Sloth Bear, Fourhorned Antelope, Sambar Deer,
Bonnet Macaque and Flap-shell Turtle
are under Vulnerable(VU) category,
Striped Hyaena, Python, Bengal
Monitor Lizard and Anamalai Hill
Gecko are listed under Near
Threatened (NT) category. As per the
IUCN Red List of Threatened Species
version 2023-1, all birds have been
listed under Least Concern (LC)
category.

Public Hearing (PH) Details
Advertisement for PH with date

Date of PH
Venue

IA/AP/RIV/547838/2025

Publications of notice for public hearing
were given in state/national level Telugu
newspaper "Sakshi" and English
newspaper "The New Indian Express"
dated 21.11.2023.
22nd December 2023
22nd, December 2023, at Kamalapadu
(V), Yadiki (M), Ananthapu ram
District, Andhra Pradesh.

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 31 of 35

<!-- page 32 -->

Chaired by

Meeting was chaired by District
Revenue Divisional Officer/ SubDivisional
Magistrate ,
Guntakal,
District Ananthapuram.
- Provision of Employment of local
Youth.
- Fair compensation for the pattaland
to be acquired
- Provide free technical education for
the higher education students
Support for the development of basic
infrastructure facilities

Main issues raised during PH

No of people attended


151

Brief of base line Environment:

Particulars
Period of baseline data
collection/Sampling period.
(Air, noise, water, land)
flora and fauna of the project
area,
aquatic ecology, etc.

Details

Soil
Air Environment
Noise & Traffic

Summer/ PreMonsoon
June 2023
May-June 2023
June 2023

Water Quality

June 2023

Vegetation

June 2023

Parameters

'

Fauna surveys

June 2023
Socio-economic survey June 2023

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 32 of 35

<!-- page 33 -->

Brief description on hydrology and
water assessment as per the
approved Pre-DPR:

The Project is a standalone scheme with two new
greenfield reservoirs and initial filling proposed from
existing Pendekallu Balancing reservoir through a
pipeline.
While approving the water availability, Wate r Resources
Department (WRD), Govt of Andhra Pradesh has
changed the water source from Pendekallu Balancing
reservoir to Chagallu Barrage, where additional flood
water IS available. The Pendekallu Balancing Reservoir
and the Chagallu Barrage are integral components of the
Penna Ahobilam Balancing Reservoir (PABR) Stage- II
irrigation initiative in Anantapur district, A ndhra
Pradesh.

Additional detail (If any)

Chagallu Barrage, has a capacity of 1.50 TMC
.WRD, Andhra Pradesh allotted 0.800 TMC (0.720 TMC
+0.080 TMC) in two fillings at the rate of 0.400 TMC
(including losses) or inmore no.of fillings based on the
actual availability of water from Chagallu Barrage in
Anathapuram District.
-



Court cases: Nil



Status of other statutory clearances
Particulars
Status of Stage- I FC
Approval of Central Water Commission
Approval of Central Electricity Authority

Letter no. and date
Diversion of forest land is not required
for the proposed project
The Layout Map, hydrology and Power
Potential Studies have been examined by
CWC/CEA
and
necessary
clearances/observations
have
been
issued:
i. CWC
vide
letter
no.
T16012/12/2023/HCD (NWS) dated
16.11.2023 for layout of the project
and letter no. T-11012/9/2023-HYD
(S) DTE dated 15.07.2025 for
hydrology aspect.
ii. The CEA has issued observation

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 33 of 35

<!-- page 34 -->

regarding layout vide letter no.
10/440/HETD&RM/2025
dated
3.07.2025.
Additional detail (If any)
Is FRA (2006) done for FC-1

NA

13. Details of the EMP

S.
No.

Components of EMP

1

Catchment
Area
Treatment Plan
Compensatory
Afforestation and NPV*

3.36

00.00 00.00 00.00 00.00 00.00 00.00 00.00

3.36

0.00

00.00 00.00 00.00 00.0_0 00.00 00.00 00.00

0.00

Biodiversity Conservation
& Wildlife Conservation
4 Plan
Fisheries Development
Plan
5
Muck Dumping and
Management Plan
6
Landscaping,
Restoration
of
Constructionand
SitesSolid
7
Sanitation
Waste
Management
Plan
8
Public Health Delivery
System
9
Energy Conservation
Measures
10 Labour Management
Plan
11 Green
Belt
Development Plan

160.00

00.00 00.00 00.00 00.00 00.00

12
13

2
3

14

Capital
Cost
(Rs. in
lakh)

Recurring Cost (Rs. in lakh)
Year Year Year Year 4 Year
1
2
3
5

Year 6

Total
Cost
Year
7 (Rs. in lakh

00.00 00.00

160.00

89.00

00.00 00.00 00.00 00.00 00.00 00.00 00.00

89.00

70.00

53.75

3.00

1628.70

18.00

255.4 225.4 523.9 342.00 155.2
5
0
0
0
78.00 70.25 80.00 42.75 0.00

0.00

0.00

289.00

173.00

33.96 33.96 33.96 33.96 5.00

0.00

0.00

313.84

60.00

52.50 52.50 47.50 47.50 0.00

0.00

0.00

260.00

32.00

53.00 53.00 53.00 53.00 0.00

0.00

0.00

244.00

25.00
2.25

7.00 2.00 12.00 7.00
0.50 5.45 13.40 8.00

0.00
3.00

0.00
3.00

0.00
0.00

63.00
35.60

Pollution Mitigation
Measures

0.00

16.00 16.00 16.00 16.00 0.00

0.00

0.00

64.00

Environmental
Monitoring Program
Rehabilitation
and
Resettlement Plan**

0.00

23.68 38.68 38.68 38.68 15.00

0.00

0.00

154.72

0.00

0.00 0.00 ' 0.00

0.00

0.00

0.00

IA/AP/RIV/547838/2025

0.00

0.00

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 34 of 35

<!-- page 35 -->

15
16
17

Local
Area
Development Plan
Disaster Management
Plan
Watershed
•,'I;
Development
Plan
Total

733.50

00.00 00.00 00.00 00.00 00.00 00.00

0.00

733.50

275.00

25.00 25.00 25.00 25 .00 25.00 00.00

0.00

400.00

325.00

00.00 00.00 00.00 00.00 00.00 00.00 00.00

325.00

1966.11 545.0 532.2 843. 613.89 203.2 56.75
9
4
44
0

3.00

4763.72

* Diversion of Forest land is not involved in proposed project
* * Cost of private land acquisition (R&R) will be part of DPR cost.

*******

Signature Not Verified
Digitally Signed by : Yogendra Pal Singh
Member Secretary, MoEFCC (EC)
Date: 14/10/2025

IA/AP/RIV/547838/2025

Address: IA Division, Ministry of Environment, Forest and Climate Change,
Indira Paryavaran Bhawan, Jor Bagh New Delhi - 110003

Page 35 of 35
