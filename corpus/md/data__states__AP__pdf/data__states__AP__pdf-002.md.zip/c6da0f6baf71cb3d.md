---
doc_id: "c6da0f6baf71cb3d"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "14eb5e9b6efb29dc"
---

<!-- page 1 -->

I

.L

CENTITB FOIT DIS'[ANCI' BDUCA'TION
ACHARYA NAGAIIJUNA UNIVBRSIl.\,:: NAGARJUNA

I

0

Oflice:

SYED ZAINULABDII*,
DBPUTY RE,G ISTIIAR (Exams)
No.ANU/CDE/I, II, Ill. IV & V Sernester Erarttinlrtions/2025,

l8-l

202

NOTI FICA'TION
ol-1, ll, III, IV

Sub: ANU - CDE - Issue of Exartrinatiort Notification lbr
V Semesters of all UG courses and 1", 2"d. 3'd & 4'h

of all PC

DiplomaiCertiflcate coLrrscs (RcgLrlar/Su pp lenrentary)

examinati

Commencernent from 26-12-2n) and ortu'arcls tenlittivcly - Regartling.
.t

I

i

Ref: Vice-Chancellor's orders datecl. I 5- I l-2025.
*,F***

The Vice-Chancellor's has ordered that the ANU CDE semester

examl

notification forconduct 1",2''d,3rd,4th & 5tl'Seniesters of all UC courses and lt'. 2''d, 3"1 &
Semesters of all PC & Diploma/Celtillcirtc cL)in'ses (llegular/Su

tary)

examinations to the admitted batches ol'(l-l l. ,\-2 l. (:-22. A-22. C:-23. A

. C.-24, A:24. C-

25 & A-25 of allcourses Comrnencement f}om 26tr'December, 2025 and onrJard s tentativelv

51eA

l

l)

Rf]CTS'TRAR

((lDE -

I

NIINATI

To
The Director, CDE, ANU.
Copy to the Coordinator, CDE. Exams, ANU.
Copy to the Assistant Registrar, Coordinator Offlce, CDE, ANU
Copy to Assistant Registrar I.JG and PC Exams. ANLJ.
I

I

Iit
