---
doc_id: "7d7babd8cdab85d0"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "93f00f71cf3cec72"
---

<!-- page 1 -->

+

INSTITUTE FOR DEVELOPMENT AND RESEARCH IN BANKING TECHNOLOGY
(ESTABLISHED BY RBI)
TENDER DOCUMENT FOR
SUPPLY OF CHAIRS AT 3RD FLOOR OF EFC BUILDING, IDRBT
PREMISES, MASABTANK, HYDERABAD,
TELANGANA-500057
IDRBT Ref. No: IDRBT/EST/SMB/261/2025-26

Date:09.12.2025

TENDER SCHEDULE

THROUGH TWO BID TENDERING PROCESS
Name of Bidder:
Address:

Date of Release of Tender

Last date of Submission of tender

: 15:00 Hours on 09.12.2025

: Before 15:00 Hours on 23.12.2025

Institute of Development and Research in Banking Technology (IDRBT),
Castle Hills, Road No-1, MasabTank, Hyderabad-500057.
Ph No: 040-3294182
Email: allestate@idrbt.ac.in

Page 1 of 23

<!-- page 2 -->

Important Instructions to Bidders
This tender is for the “Supply of Chairs at 3rd Floor of EFC Building, IDRBT Premises, Masab

Tank, Hyderabad, Telangana-500057”.
1.

It is a Two Bid containing Technical Bid and Price Bid.

2.

In their own interest the contractors are advised to use their own specific seals and
desist from using currency coins for the purpose. Tenders with incomplete or broken
seals are liable to be rejected, the matter solely resting at the discretion of the Employer.
If a contractor does not quote for one or more items, the Tender will be considered as
incomplete and will be rejected.

3.

Clients reserve to itself the right to accept or reject any tender without assigning any
reason for doing so and does not bind itself to accept the lowest or any other tender.

4.

Employer or Client shall mean Institute of Development and Research in Banking
Technology (IDRBT), Castle Hills, Road No-1, MasabTank, Hyderabda-500057.

Page 2 of 23

<!-- page 3 -->

1.

Notice Inviting Tender (NIT)

The bidders desirous of taking up the work of are requested to submit their offer (Technical &
Commercial) in the prescribed format in response to this tender notice. The criteria and the actual
process of evaluation and subsequent selection of the successful bidder will be entirely at the Institute’s
discretion.
This Tender document is not an offer by IDRBT, but only an invitation to receive responses from the
bidders. No contractual obligation whatsoever shall arise from the tender process unless and until a
formal contract is signed and executed by duly authorized official(s) of IDRBT with the successful
bidder.

S.No.
1

Details
Name of work

Description

Supply Chairs at 3 Floor of EFC Building, IDRBT
Premises, Masab Tank, Hyderabad, Telanganard

500057.
2

Nature of work.

Supply of Chairs

3

Earnest Money Deposit

Rs. 16,000.00 (To be submitted along with the tender.
To be submitted in the shape of DD in favour of
“IDRBT, Hyderabad” and should have validity of
minimum 90 days. Tender documents without EMD will
be rejected. Also “Please note that incomplete tenders
/ tenders with conditions will be rejected and the
EMD will be forfeited”.
EMD of Unsuccessful bidders shall be returned on
completion of tendering process. The original DD must
be submitted at
IDRBT before closing of Tender i.e. on or before 15:00
hours on 23.12.2025.

4

Total Security Deposit 5% of the total value of work done will be deducted from
Amount.
the bill. The same will be refunded after completion of
defects liability period of 12 months. No interest will be
paid on the Security Deposit amount.
Eligibility of the (i)The Bidder / OEM should be NABCB (National
Bidder.
Accreditation Board for Certification Bodies) certified.
ISO-9001:2015 – Quality Management System,
ISO-14001:2015 – Environment Management System
OHSAS-18001:2007- Occupational Health and Safety
Management System
ISO-45001:2018 -Occupational Health and Safety
Management System

5

ISO-50001:2018: Energy Management System
Other certifications UL-GREENGUARD GOLDChemical Emission Limits for low levels of Volatile
Organic Compounds
AIOTA – All India Occupational Therapists Association
FSC & SEDEX CERTIFIED- Forest Steward Ship
Page 3 of 23

<!-- page 4 -->

Council Supplier Ethical Exchange.
All product should have BIFMA (Business and
International Furniture Manufactures Association) level
1 certification.
Relevant proof in support shall be submitted.

(ii) Legal Entity: The Bidder shall necessarily be a
legal entity. Only Authorized Distributors of
following companies are eligible to participate:
(i)
(ii)
(iii)

M/s Godrej Interio
M/s Durian
M/s Featherlite

A proof supporting the legal validity of the Bidder
(Manufacture Authorization Form (MAF) shall be submitted.
Attested copy of certificates is to be submitted along with Bid.
(iii)Financial Capacity: The bidders should be a profit-making
firm for the last four financial years (2021-22, 2022-23, 202324, 2024-25). Relevant proof for supporting the above shall be
submitted. Attested copy of the audited balance sheets along
with Income Tax Return for the completed four financial years
i.e. for (2021-22, 2022-23, 2023-24, 2024-25) shall only be
acceptable.
(iv)Registration: The Bidder shall be registered with the
Income Tax and GST departments. Relevant proof in support
shall be submitted. In proof of having fully valid attested copy
of PAN, GST Registration Copy shall only be acceptable.
(v)Experience: The Bidder should have executed the work
orders of minimum of Rs.8 lakh for providing of furniture items
in the Government Departments in the last four financial years
(2021-22, 2022-23, 2023-24, 2024-25). Relevant proof in
support shall be submitted. In proof, attested copy of work
orders along with work completion certificate/ experience
certificates issued by the Government Departments shall only
be acceptable.

6

Validity of the Offer.

90 days from the date of opening of Price Bid.

7

Time allowed
completion.
Payment terms

45 days from the date of placing work order.

8

for

After 100% completion of work. No RA bills.

Page 4 of 23

<!-- page 5 -->

9

Defects
period.

10

Clarifications if any.

11

Last
Date
submission of
along with EMD.
Submission of Bids

12

liability

12 months from the date of handing over the site by
the Bidder after completion of the work.

Any clarification in this regard may be sought from
the Estate Department, IDRBT through email ID
allestate@idrbt.ac.in / Phone no. 040-23294182.
of On or before 15:00 hours of 23.12.2025
bids
Offers should be submitted in two parts viz., Technical bid
along with Annexure –V and Price Bid and separate envelopes.
The envelope containing the Technical Bid (EMD should be in
a sealed cover bearing the following information on the right
hand top corner:
- Envelope No.1 Technical Bid
- Tender No:
- Name of the work
- Bidder’s Name
The cover containing the Price should be in a separate sealed
cover bearing the following information on the right hand top
corner:
- Envelope No.2 Price Bid
- Tender No:
- Name of the work
- Bidder’s Name

13

Pre Bid Meeting

14

(Penalty
clause)
Liquidated Damages
Eligible Taxes

15

The Envelope No1 (Technical Bid) and Envelope No.2 (Price
Bid) should then be put together in another envelop bearing the
following details:
- Tender No.
- Name of the work
- Bidder’s Name

Pre Bid Meeting will be Conducted on 15.12.2025 @
11.00AM at Institute of Development and Research in
Banking Technology (IDRBT), Castle Hills, Road No-1,
Masab Tank, Hyderabda-500057.
No technical Clarifications shall be entertained
after the Pre bid Meeting.
No Conditional Tenders shall be allowed, if any shall
be summarily rejected.
@ 1.0% of the value of work per week of delay.
Maximum of 15 %.
1. A) Income Tax & GST IT will be deducted at source
as per Govt. Guidelines.
2. B) Reimbursement of GST will be made only on
submission of proper GST invoice as per applicable
GST provision. The contractor should comply with
the following;

Page 5 of 23

<!-- page 6 -->

16

17

18

3. Contractor should have GST Registration Number
4. Invoice should specifically/separately disclose the
amount of GST levied at applicable rate as per GST
provision
5. In case of Correction in the bills after scrutiny,
contractor should submit fresh bills for payment
6. Contractor should timely file his GST return in
accordance with GST provisions to enable the bank
to claim the credit of GST paid to the contractor
7. The GST Number of IDRBT 36AAAAI0204K1Z4
Evaluation of Price 1. Only those Bidders who qualify in Technical
Bids and Finalization
evaluation would be shortlisted and price bid submitted
by the bidder will be opened.
2. The L1 Bidder will be selected on the basis of net total
of the price evaluation as quoted in the bidding.
In case, the L1 amount quoted by two or more
contractors is the same, such lowest contractors will
again be asked to submit sealed “Revised % Percentage
Offers” on the original Estimated Cost of tender but the
revised percentage shall, in no case, be higher than the
percentage quoted during their initial offer for the
project. The L1 shall be decided on the basis of revised
offers.
4. The process of rebidding amongst the two or more
contractors offering same rates shall continue till L1
bidder is discovered.
5. In case, any of such contractors or all contractors (who
have quoted same tender amount in the initial bidding or
subsequent bidding) refuse to submit revised offer, it
shall be treated as “Withdrawal of tender” by the
Contractor before acceptance by PL and the EMD of
such contractors shall be forfeited and they shall not be
allowed to participate in the re-tendering process for the
work.
Working Hours
From 7.00 AM to 8.00 PM on all days (working days
and Holidays) The Contractor has to work in the
Premises of an office which is functional and no in
convenience to be created for effective
functioning of office during office hours and the office
staff. The Contractor should make necessary
arrangements for this.
Any additional
The quoted rate should be inclusive of materials,
Information
labour, wages, fixtures, transportation, installation, all
taxes (excluding GST), wastages, Octroi, machinery,

Page 6 of 23

<!-- page 7 -->

temporary works such as scaffolding, cleaning, over
heads, profit, statutory expenses, incidental charges,
lead and lift charges and all related expenses to
complete the work.
Important Notes for Execution of Work:
Works are to be executed in 3rd floor.
Lifting of all the work m aterials shall be
done through the staircase only.
• Use of lift in any circumstances shall be avoided
/ prohibited.
• All m aterials shall be stored at one place as
shown to the c ontractors.
• Accommodation for Labour shall be done
outside the Office Premises.
• Every contractor is expected before quoting rates
to inspect the site of proposed works and discuss
with Project Architect Consultant and /or IDRBT.
The material must strictly comply with the relevant
specifications. Sample of materials as specified
shall be submitted for the approval of the IDRBT
before supplying the site.
•
•

19

Place of submission of
tender documents

20

Bidder’s Contact
Details

21

The Institute reserve its rights to accept or reject any or all the tenders, either
in whole or in part without assigning any reason(s) for doing so and no claim
/ correspondence shall be entertained in this regard.

To be dropped in the tender box available at the
Security office, Main Gate entrance of IDRBT, Door No:
10-3-311, Road No: 1, Castle Hills, Masab Tank,
Hyderabad – 500 057.
As per Annexure-II.

The Institute may use its discretion as it deems fit to award the work to any
of the bidder without assigning any reason whatsoever.
22

If they quote price in Annexure –V along with the technical bid, the tender
document will be disqualified.

Page 7 of 23

<!-- page 8 -->

IMPORTANT:
It is mandatory that the bidder shall sign and certify with seal on each page of the tender documents as
well as all the supporting documents as a token of having read and understood the terms & conditions
contained therein. The bidder should fill up the information in clear and legible terms. Wherever, the
prices are to be quoted, they shall be written in figures and in words as well. No additions/
modifications/ deletions in the tender documents and other related supporting documents shall be
entertained.
The Bidders submit the following information / documents for examination by Institute to satisfy about
the Bidder’s eligibility:

(a)
(b)
•
•
•

Work experience & Completion of similar works of
specified value during the specified period.
Financial capacity

As per Eligibility criteria.
As per Eligibility criteria.

In the event of intending Bidder’s failure to satisfy the Institute with documentary
evidence in support of their possessing required eligibility; the Institute reserves the
right to refuse their participation in the tendering process.
The bidders may visit the site from 09.12.2025 to 23.12.2025 between 10.00 AM to
4.00 PM (on working days only) after making a prior intimation on our e mail
(allestate@idrbt.ac.in) to understand the scope of the work.
A pre-bid meeting of the intending Bidders will be held 11.00 AM on 15.12.2025 at
Estate Department, Academic Building, IDRBT, Hyderabad.

•

All prospective bidders / Bidders or their authorized representatives are required
to attend the pre- bid meeting to seek clarification, if any, regarding this tender.
No deviation in Institute’s terms and conditions mentioned in the tender shall be
accepted.

•

The duly filled in tender documents shall be submitted on or before 15:00 hours on
23.12.2025.
Any amendments / corrigendum to the tender, if any, issued in future will only be
notified on the IDRBT website.

•

Hyderabad
Date: 09.12..2025

Director

Page 8 of 23

<!-- page 9 -->

DETAILS OF THE TENDER

1 INSTRUCTIONS TO BIDDER
1.1 General Terms and Conditions
1) All efforts have been made to avoid errors in the drafting of the tender documents, the
Bidder is advised to check the same carefully. No claim on account of any errors detected
in the tender documents shall be entertained.
2) The bidder shall attach the copy of the authorization letter / power of Attorney as proof of
authorization for signing on behalf of the Bidder.
3) All Bidders are hereby informed that conditional offers or offers with deviations from the
conditions of Contract, the bids not meeting the minimum eligibility criteria, Technical
Bids, not accompanied with EMD of requisite amount/format, or any other requirements,
stipulated in the tender documents are liable to be rejected.
4) For all purposes of the contract including arbitration thereunder, the address of the bidder
mentioned in the bid shall be final unless the bidder notifies a change of address by a
separate letter sent by registered post with acknowledgement due to the Office of the
IDRBT, Hyderabad. The bidder shall be solely responsible for the consequences of any
omission or error to notify change of address in the aforesaid manner.
5) The requirements of procurement of furniture as mentioned in the tender document is
tentative and may increase or decrease at the sole discretion of the competent authority of
the Client.
1.2

EARNEST MONEY DEPOSIT
1) Bidders shall not be permitted to withdraw their offer or modify the terms and conditions
thereof. In case the bidder fails to observe and comply with the stipulations made herein
or backs out after quoting the rates, the aforesaid bid EMD shall be forfeited to the IDRBT.
2) The bids without Earnest Money Deposit shall be summarily rejected. No claim shall lie
against the IDRBT in respect of erosion in the value or interest on the amount of earnest
money deposit or security deposit.
3) The bid security (earnest money deposit) may be forfeited:
i.

If the bidder withdraws his bid during the period of bid validity specified by the bidder
in the bid form; or

ii. In case of successful bidder, if the bidder:
a) Fails to sign the contract in accordance with the terms of the tender document.
a)

Fails to furnish required security deposit in accordance with the terms of tender
document within the time frame specified by the Client.

Page 9 of 23

<!-- page 10 -->

b) Fails or refuses to honor his own quoted prices for the services or part thereof.
c)

In such case, the bidder is also liable to be debarred from future tendering.

4) No interest shall be paid on the earnest money deposit.
1.3 FINANCIAL BID
1) The Bidder shall be required to quote their prices in a single consolidated statement "Bill
of Quantity (BoQ)” template which is available in the tender document.
2) The Bidder should quote rates for each and every item in terms of per piece and only in
Indian Rupees (in figures as well as words in English). In case of difference of rate in
figures and words, rate written in words shall only be considered.
3) If rate is not quoted for all the items, the bid will not be valid and hence the same will be
rejected. The consolidated price of all the items will be taken into consideration while
awarding of contract to the successful bidder.
4) The rates quoted shall be firm and final. The price should be inclusive of all i.e., cost
of article, inspection of item, transportation, delivery, shifting of items from ground floor
to third floor, installation etc. and all other applicable taxes and duties except GST, if any.
5) At the time of payment of bills, the income tax and any other tax / duty etc. that is required
to be deducted, shall be deducted at source as per Government rules and guidelines as may
be prevailing at the time of payment.
6) evaluation shall be done only in respect of Valid Bid.
1.4 DETERMINATION OF THE SUCCESSFUL BIDDER
1) The technically qualified Bidder meeting the minimum eligibility criteria with the lowest
bid price, subject to arithmetical correction, shall be deemed as the successful Bidder. The
consolidated price of all the items will be taken into consideration for determination of the
successful bidder.
2) In the event of more than one bidder with the lowest price bids (say equal), the bidder with
the highest ‘cumulative annual turnover of the last 3 financial years would be deemed as
‘Successful Bidder’ with respect to the submission of proof of documents as submitted
by the bidder.
1.5 RIGHT OF ACCEPTANCE
1) IDRBT reserves all rights to reject any bids including of those bidders who fail to comply
with the instructions without assigning any reason whatsoever and does not bind itself to
accept the lowest or any specific bids. The decision of the Competent Authority of the
IDRBT in this regard shall be final and binding.
2) Any failure on the part of the bidder to observe the prescribed procedure and any attempt

Page 10 of 23

<!-- page 11 -->

to canvass for the work shall render the bidder’s bids liable for rejection.
3) The competent authority of the Office of the IDRBT reserves the right to award any or part
or full contract to any successful agency (ies) at its discretion and this shall be binding on
the bidders.
4) In case of failure to comply with the provisions of the terms and conditions mentioned, by
the agency that has been awarded the contract, the competent authority of the IDRBT
reserves the right to award the contract to the next lowest bidder or any other outside
agency.
5) The IDRBT shall terminate the Contract if it is found that the Contractor was blacklisted
on previous occasions by any of the Government Departments / Institutions / Local Bodies
/ Municipalities / Public Sector Undertaking etc. In such case, the Contractor is also liable
to be blacklisted by the Client.
1.6 RETURNING OF EARNEST MONEY DEPOSIT (BID SECURITY AMOUNT)
1) The Earnest Money Deposit of the unsuccessful bidders in the technical Bid evaluation
stage shall be returned within 7 (seven) days after opening of the eligible financial Bids.
2) The Earnest Money Deposit of the unsuccessful bidders in the financial bid evaluation
stage shall be returned within 7 (seven) days, on award of contract to the Successful bidder.
3) The Earnest money deposit of all the bidders shall be returned in case of cancellation
of Tender after the opening of Bids and prior to opening of financial bids.
4) No interest shall be paid on Earnest Money Deposit.

Page 11 of 23

<!-- page 12 -->

2. GENERAL CONDITIONS OF CONTRACT (GCC)
2.1 DEFINITIONS
In this Contract including the Schedules the following words and expressions shall (unless the context
requires otherwise) have the meaning assigned to them in this Schedule.
Agreement
Party
Letter of Acceptance
Termination Date
Termination Notice
Contractor

The word “Agreement” and “Contract” has been used interchangeably.
The word party means the Successful Bidder and the Client “IDRBT,
Hyderabad “
Shall mean the intent of the Client to engage the successful bidder.
Shall mean the date specified in the notice of Termination given by either
Party to the other Party, from which the Contract shall stand terminated.
Shall mean the notice of Termination given by either Party to the other
Party.
Shall mean the successful bidder to whom the work order has been
awarded.

2.2 CONFIDENTIALITY
The Contractor shall take all precautions not to disclose, divulge and / or disseminate to any third party
any confidential information, proprietary information on the Client’s business or security arrangements
and/or business of the Client. The obligation is not limited to any scope and the Contractor shall be held
responsible in case of breach of the confidentiality of Client’s information.
a. NOTIFICATION OF AWARD BY ISSUANCE OF

‘LETTER OF ACCEPTANCE’

After determining the successful bidder, Client shall issue a Letter of Acceptance (LoA)in duplicate,
who will return one copy to Client duly acknowledged, accepted and signed by the authorized
signatory, within Three (3) days of receipt of the same by him. The issuance of the Letter of
Acceptance to the bidder shall constitute an integral part and it will be binding to the contract.
a. SIGNING OF CONTRACT AGREEMENT
i.

The successful Bidder shall enter into contract and shall execute and sign the Contract
Agreement in accordance with the Articles of Agreement.

b. WARRANTY OF QUALITY AND QUANTITY
i.

All the Chairs supplied by the Contractor in Client's premises shall carry a mandatory minimum
warranty of one year from the date of installation and commissioning.

ii.

The Contractor, by way of signing the tender document, gives an undertaking that their products
carry warranty of one year on Chairs items which are in conformity with the specifications and
are conforming to the specified design and there are no defects in the process of manufacturing
& installation.

Page 12 of 23

<!-- page 13 -->

iii.

In case of any defect found within one year from the date of supply, items should be repaired
free of cost and if repair is not possible the same should be replaced with a new one.

iv.

Upon receipt of notice from department for defective material, the Contractor shall within 7
days of receipt of the notice, replace the defective material, free of cost at the destination. The
Contractor shall take over the defective material at the time of replacement. No claim
whatsoever shall lie on the Client for the replaced goods thereafter. If the Contractor fails to
replace the defective goods within the period, the department may proceed to take such remedial
actions as may be necessary, at the Contractor's risk and expense besides forfeiting the Security
Deposit and taking action to blacklisting the Contractor.

c. CONTRACTOR’S LIABILITY
i.

The Contractor shall completely indemnify and hold harmless the Client and its employees
against any liability, claims, losses or damages sustained by it or them by reason of any breach
of contract, wrongful act or negligence by the Contractor.

ii.

The Contractor shall not be liable in any way whatsoever and the Client hereby expressly
waives any right to, any loss, injury, damage, cost or expense of whatsoever nature directly or
indirectly (i) caused by, resulting from or in connection with any Biological or Chemical
Contamination or any Nuclear Risks; (ii) consisting of, caused by, resulting from or in
connection with any loss, damage, destruction, distortion, erasure, corruption or alteration of
Electronic Data from any cause whatsoever (including but not limited to Computer Virus)
unless such loss, damage, destruction, distortion, erasure, corruption or alteration of Electronic
Data was due to the negligence or default of the Contractor or any of its employees engaged in
the provision of the Contract to the Client.

iii.

The Contractor shall not Sub-Contract, transfer or assign the contract or any other part thereof
without prior written permission of the Client. In the event of the contractor contravening this
condition, Client shall be entitled to place the contract elsewhere on the contractor’s risk and
cost and the contractor shall be liable for any loss or damage, which the Client may sustain in
consequence or arising out of such replacing of the contract.

d. LIQUIDATED DAMAGES
The date of delivery and quality of Chairs items stipulated in the acceptance of tenders should be
deemed to be essence of the contract and delivery must be completed not later than three weeks from
the date of award of work/supply order. In the event of delayed delivery after expiry of the contracted
delivery period, the Client shall levy a penalty @ 5% per week, on the total value of the late
delivered quantity for the period by which it exceeds the stipulated time period, from the date of
issue of the formal work/supply order, subject to a

Page 13 of 23

<!-- page 14 -->

maximum of 15 %. In the event of delay of more than two weeks, the Client will have the right of
revoking purchase order and forfeiting the Security Deposit.
e. GOVERNING LAWS AND SETTLEMENT OF DISPUTE
i.

Any claims, disputes and or differences (including a dispute regarding the existence, validity
or termination of this Contract) arising out of, or relating to this contract including interpretation
of its terms shall be resolved through joint discussion of the Authorized Representatives of the
concerned parties. However, if the disputes are not resolved by the discussions as aforesaid
within a period 30 days, then the matter will be referred for adjudication to the arbitration of a
sole arbitrator to be appointed by the parties in accordance with the provisions of the Arbitration
and Conciliation Act 1996 and rules made thereunder including any modifications, amendments
and future enactments thereto. The venue for the Arbitration will be Hyderabad and the decision
of the arbitrator shall be final and binding on the parties.

ii.

Jurisdiction of Court: This Contract is governed by the laws of Republic of India and shall be
subject to the exclusive jurisdiction of the courts in Hyderabad.

f.

TERMINATION

This Contract may be terminated by the Client in case the Contractor is found in material breach of its
obligations under this Contract Agreement. In the event of breach of the terms and conditions of the
contract, the contract shall be terminated, and nothing shall be payable by the Client. The Client shall
also blacklist the Contractor and forfeit the se cur i t y deposit f o r its breach of terms and conditions
of the Contract.

Page 14 of 23

<!-- page 15 -->

ANNEXURE-I
BID SUBMISSION FORM
(to be printed on Bidder's letterhead, signed and submitted)
To,
Date:
The Deputy General Manager,

Institute of Development and Research
in Banking Technology (IDRBT),
Castle Hills, Road No-1, Masab Tank, Hyderabad500057.
Ph No: 040-3294182
Email: allestate@idrbt.ac.in
Sub: Supply of Chairs – Reg.

Ref: Invitation to Bid No:
***

We, the undersigned, declare that:
1) We have examined and have no reservations for the Bidding Documents, including Addenda
issued in accordance with Instructions to Bidders.
2) We offer to execute in conformity with the Bidding Documents for supply of Chairs as per the
details given in the tender document for the IDRBT, Hyderabad.
3) Our bid shall be valid for a period of 90 days from the date fixed for the bid submission deadline
in accordance with the Bidding Documents and it shall remain binding upon us and may be
accepted at any time before the expiration of that period.
4) If our bid is accepted, we commit to submit security deposit in accordance with the Bidding
Documents.
5) We also declare that Government of India or any other Government body has not declared us
ineligible or blacklisted us on charges of engaging in corrupt, fraudulent, collusive or
coercive practices or any failure/lapses of any nature.
6) We also accept all the terms and conditions of this bidding document and undertake to abide
by them, including the condition that you are not bound to accept highest ranked bid / lowest
bid or any other bid that you may receive.
Yours sincerely,
Authorized Signatory
(Full Name and Designation)
(Authorized person shall attach a copy of Authorization for signing on behalf of Bidding company)

Page 15 of 23

<!-- page 16 -->

ANNEXURE - II
TECHNICAL BID
FORM

1. Name of the firm…………………………………………………….………………
2. Name of the authorized person submitting the Bid shri /
Smt…………………………………..
3. Designation

of

the

authorized

person

submitting

the

Bid…………………………………………………
4. Address of the firm .................................................................................................
...........................................................................................................................
............................................................................................................................
Tel No. with STD code
(O)…...........……….……(Fax)……….......………….(R)…...……............…….

5. Mobile No. of

the person

submitting the

Bid………………………………………..
6. E-mail of the person submitting the Bid …………………………….………………
7. Organization's email ID…………………
8. Website Address………………………………………………
9. Registration & incorporation particulars of the firm:
i) Private Limited
ii) Public Limited
iii) Any other – Please specify……………………….
10.

Bidder’s bank, its address and current account number ……………………

…………………………………....................................................................
11.

Permanent Income Tax number, Income

Tax circle

.………...................………………………
Page 16 of 23

<!-- page 17 -->

12.

GST No. ………….……………………………………………………
i)

Particulars of EMD

ii) Demand Draft No………………….………………………….
iii) Date………………Name of Bank…………………………
iv) Address of
Bank…………………….……………………………………………….
v)Validity of DD………………….…………………………………………….
13.

Description of similar work of providing furniture items during the last three
financial years in Government Departments.

Description of
work/order
executed

Actual
Value of
work /
order
executed

Name of
Government
Department /
Organization

Start Date

Finish Date

Document
evidence
submitted
(Yes/No)

14. Details of Documents to be submitted:
1

Earnest Money Deposit

Yes/No

2

Copy of PAN

Yes/No

3

Copy of GST

Yes/No

4

Copies of Last three years Balance Sheet

Yes/No

5

Copies of ITR for the last three years

Yes/No

6

Copies of orders of 8 lakh or more in last three financial

Yes/No

years
7

Annexure – I

Yes/No

8

Annexure – II

Yes/No

9

Annexure – III

Yes/No

10

Annexure – IV

Yes/No

11

Annexure - V

Yes/ No

Dated Signature of Bidder with Stamp
Name of the Bidder

Page 17 of 23

<!-- page 18 -->

ANNEXURE-III
(UNDERTAKING)
Hard copy should be submitted along with Technical Bid.
1. I, the undersigned certify that I have gone through all the terms and conditions mentioned
in t h e t e n d e r d o c u m e n t N o …………………………dated.................................... and
undertake to comply with them unconditionally.
2. That the rates quoted by me are valid and binding upon me for the entire period of contract and
it is certified that the rates quoted are the lowest rates as quoted in any other institution in India.
3. That I/We give the rights to the competent authority of the Office of the IDRTB, Hyderabad
to forfeit the Earnest Money/Security money deposit submitted by me/us in case of breach of
conditions of Contract and take action for blacklisting my/our agency.
4. That I/We also give rights to the competent authority of the Office of the IDRBT, Hyderabad
to forfeit the Earnest Money Deposit and initiate action against our agency for blacklisting in
case our agency fails to accept the work order and/or execute the contract agreement, or in
cases of negligence in executing the contract, or in case of breach of contract.
5. That I/We also give rights to the competent authority of the Office of the IDRBT, Hyderabad
to forfeit the Earnest Money Deposit and initiate action against our agency for blacklisting in
case our agency fails to submit the Security Deposit in accordance with the terms and
conditions of the tender document / contract agreement / Letter of Acceptance.
6. That I/We also declare that Government of India or any other Government body has not
declared us ineligible or black listed us on charges of engaging in corrupt, fraudulent, collusive
or coercive practices or any failure/lapses of any nature.
7. That I hereby undertake to provide the items as per the directions given in the tender
document/contract agreement.

Place:

Dated Signature of Bidder along with stamp

Date:

Name of the Bidder
Contact:
Cell No:
E-Mail:

Page 18 of 23

<!-- page 19 -->

ANNEXURE- I V
Hard copy should be submitted along with Technical Bid.

1. That I, the undersigned certify that my firm has not been convicted of an offence under the
Prevention of Corruption Act, 1988.
2. That my firm has not been convicted under the Indian Penal Code or any other law for the time
being in force, for causing any loss of life or property or causing a threat to public health as part
of execution of a public procurement contract.
3. That I hereby certify that none of my relative(s) as defined in the tender document is/are
employed in Office of the IDRBT, Hyderabad as per details given in tender document.
4. In case at any stage, it is found that the information given by me is false/incorrect, the IDRBT,
Hyderabad shall have the absolute right to take any action including termination of the Contract
as deemed fit/without any prior intimation to me.

Place:

Dated Signature of Bidder along with stamp

Date:

Name of the Bidder

Page 19 of 23

<!-- page 20 -->

ANNEXURE - V
(SCHEDULE OF WORKS / REQUIREMENTS/TECHNICAL SPECIFICATIONS)
Name of work : Supply of Chairs at 3rd Floor of EFC Building, IDRBT Premises, Masab Tank, Hyderabad,
Telangana-500057.
Sr.No
1

SFECIFICATION OF THE ITEM
MD CHAIR:
SUPPLYING AND PLACING IN POSITION OF
HIGH BACK MESH CHAIR IN BLACK COLOUR
WITH MATTE FINISH. *ALL OVER SIZE IS :
(L)480MM X (D)510MM X (H) 1180 MM, * THE
CHAIR MADE OF FULL MESH IN BLACK COLOUR,
IT WILL COMES IN MATTE FINSIH IN
CONTEMPORARY STYLE . * ARMS : AMREST IS
HAVING THREE WAY ADJUSTMENT . * SEAT:
SEAT IS MADE OF TWO PIECES INJECTION
MOULDED FRAME COVER WITH MESH * BACK :
FRAME OF DESIGN SHALL BE CURVED MADE OF
TWO PIECES INJECTION MOULDED FRAME
COVER WITH MESH .BACKREST SUPPORT
ADJUSTABLE LUMBAR SUPPORT * MECHANISM
: 3 WAY POSITIONING MECHANISM WITH SEAT
SLIDING * ONLY SEAT SIZE IS (L) 480MM X
(D)510MM & THE BACK SIZE IS (D) 530MM X
(H)740MM , BACK HEIGHT FROM FLOOR
MAXIMUM HEIGHT IS 1180MM & MINIMUM
HEIGHT IS 1080MM . * GAS LIFT 100 MM
TELESCOPIC HAUDRAULIC *BACK ADJUSTABLE
UPTO 5 CM & SEAT SLIDIIND UPTO 5CM * BASE
: 650 MM CHROME BASE WITH SMOOTH
CASTORS .
MESH: BLACK
SEAT fABRIC : BLACK

Ref. Image

Qty
1

Page 20 of 23

<!-- page 21 -->

2

3

CHAIRS : MEDIUM BACK MESH CHAIR
SUPPLYING AND PLACING IN POSITION OF
MEDIUM BACK MESH CHAIR IN BLACK COLOUR
WITH MATTE FINISH. * ALL OVER SIZE IS :
(L)480MM X (D)510MM X (H) 1180MM , * THE
CHAIR MADE OF FULL MESH IN BLACK COLOUR,
IT WILL COMES IN MATTE FINSIH IN
CONTEMPORARY STYLE . * ARMS : AMREST IS
HAVING THREE 1D ADJUSTMENT . * SEAT: SEAT
IS MADE OF TWO PIECES INJECTION MOULDED
FRAME COVER WITH MESH * BACK : FRAME OF
DESIGN SHALL BE CURVED MADE OF TWO
PIECES INJECTION MOULDED FRAME COVER
WITH MESH .BACKREST SUPPORT ADJUSTABLE
LUMBAR SUPPORT * MECHANISM : SIMPLE
SYNCHRO MECHANISM WITH SINGLE LOCK *
ONLY SEAT SIZE IS (L) 480MM X (D)510MM &
THE BACK SIZE IS (D) 530MM X (H)740MM ,
BACK HEIGHT FROM FLOOR MAXIMUM HEIGHT
IS 1180MM & MINIMUM HEIGHT IS 1080MM .
* GAS LIFT 100 MM TELESCOPIC HAUDRAULIC
* BASE : 650 MM NYLON BASE WITH SMOOTH
CASTORS . THE SELLER / COMPANY SHOULD BE
ISO 9001:2008, ISO 9001:2015, ISO
50001:2018, ISO 14001:2015, OHSAS
18001:2007, GREENGUARD, GREEN PRO,
AIOTA, INDIAN DESIGN MARK COMPLIANT. THE
BIDDER SHOULD EITHER OFFER PRODUCTS
HAVING GRIHA COMPLIANCE OR THE OEM
SHOULD HAVE FSC CERTIFICATE. THE BIDDER
SHOULD BE A MEMBER OF BIFMA AND AT
LEAST TWO PRODUCTS OF THE OEM SHOULD
BE CERTIFIED AS BIFMA COMPLIANT AND AN
OFFICIAL PRODUCT OFFICIAL
LINK/SCREENSHOT OF THE PRODUCT LISTING
MUST BE PROVIDED FROM
WWW.BIFMA.ORG".
MESH: BLACK
SEAT fABRIC : BLACK
CONFERENCE ROOM CHAIRS : MEDIUM BACK
CUSHION CHAIR SUPPLYING AND PLACING IN
POSITION OF LEATHERETTE MEDIUM BACK
CHAIR IN BLACK COLOUR SIZE :- (W)650MM X
(D)650MM X (H)1070 MM.SEATING HEIGHT
530MM. MASTERFULLY TAILORED IN BUTTERYSOFT LEATHERETTE TO ACCENTUATE ITS
CURVES, THE CHAIR COLLECTION FEATURES
REFINED SILHOUETTES THAT ADD COMFORT
TO MODERN WORKSPACES. FEATURING 3D
ARMRESTS TAILORED TO YOUR COMFORT, IT
LETS YOU MATCH YOUR DESK HEIGHT. AFFIXED

100

10

Page 21 of 23

<!-- page 22 -->

4

WITH PREMIUM CASTERS FOR FLUID
MOVEMENT ACROSS ANY SURFACE, THIS HIGHBACK MULTIFUNCTIONAL CHAIR WORKS JUST
AS WONDERFULLY IN A WORKSPACE AS IT
DOES IN A STUDY. ERGONOMIC DESIGN HELPS
MAINTAIN POSTURE FOR BETTER
PRODUCTIVITY. HEIGHT ADJUSTABLE LUMBAR
SUPPORT FOR PERSONALISED COMFORT.
BREATHABLE LEATHERETTE UPHOLSTERY FEELS
SOFT AND KEEPS YOU COOLER FOR LONGER.
ADJUSTABLE 3D ARMRESTS LET YOU MATCH
YOUR DESK HEIGHT. ADJUSTABLE HEADREST
ENABLE TO ADAPT YOUR SEATING POSTURE
BASED ON THE TASK. GENEROUSLY PADDED
SEAT AND HIGH BACKREST OFFERS
COMFORTABLE SEATING EXPERIENCE. PADDED
ARMRESTS FURTHER ELEVATES COMFORT.
PNEUMATIC HEIGHT ADJUSTMENT LETS YOU
MATCH THE DESK HEIGHT. TILT TENSION
CONTROL LETS YOU INCREASE OR DECREASE
THE RESISTANCE WHILE YOU RECLINE.
SYNCHRONISED MECHANISM WITH 4
RECLINING POSITION OFFERS PERSONALISED
COMFORT. 136 KG LOAD-BEARING CAPACITY
ENSURES STABILITY AND SECURITY FOR THE
USER. PREMIUM NYLON BASE ENSURES
LONGEVITY. HIGH-QUALITY CASTORS ENSURE
SMOOTH NOISE-FREE MOVEMENT.
NOC & SOC HIGH CHAIRS: MARVEL MEDIUM
BACK MESH CHAIR
SUPPLYING AND
PLACING IN POSITION OF MEDIUM BACK MESH
CHAIR IN BLACK COLOUR WITH MATTE FINISH.
* ALL OVER SIZE IS : (L)480MM X (D)510MM X
(H) 1480MM , * THE CHAIR MADE OF FULL
MESH IN BLACK COLOUR, IT WILL COMES IN
MATTE FINSIH IN CONTEMPORARY STYLE . *
ARMS : AMREST IS HAVING THREE 1D
ADJUSTMENT . * SEAT: SEAT IS MADE OF TWO
PIECES INJECTION MOULDED FRAME COVER
WITH MESH * BACK : FRAME OF DESIGN SHALL
BE CURVED MADE OF TWO PIECES INJECTION
MOULDED FRAME COVER WITH MESH
.BACKREST SUPPORT ADJUSTABLE LUMBAR
SUPPORT * MECHANISM : SIMPLE SYNCHRO
MECHANISM WITH SINGLE LOCK * ONLY SEAT
SIZE IS (L) 480MM X (D)510MM & THE BACK
SIZE IS (D) 530MM X (H)740MM , BACK HEIGHT
FROM FLOOR MAXIMUM HEIGHT IS 1180MM
& MINIMUM HEIGHT IS 1080MM . * GAS LIFT
100 MM TELESCOPIC HAUDRAULIC * BASE :
650 MM NYLON BASE WITH SMOOTH

4

Page 22 of 23

<!-- page 23 -->

CASTORS .
MESH: BLACK
SEAT fABRIC : BLACK

Page 23 of 23
