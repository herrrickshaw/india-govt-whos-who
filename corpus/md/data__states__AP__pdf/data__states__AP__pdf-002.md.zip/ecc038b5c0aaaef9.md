---
doc_id: "ecc038b5c0aaaef9"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 2
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "a944a5b28e2583fe"
---

<!-- page 1 -->

Dr. Y.S.R. HORTICULTURAL UNIVERSITY
Administrative Office, Venkataramannagudem — 534 10 1, W.G. District
Cir.Memo.No.6525/Budget/2016-17 Dated : 01-06-2016
Sub:- Dr.YSRHU — Budget Estimates for the year 2016-17 - Communication
- Certain Instructions — Issued.
--:000:--

The Budget Estimates for the financial year 2016-17 containing the details of
Pay and Allowances, Contingencies, Common Expenditure under Non-Plan, AICRP Schemes
and K.V.K.s are communicated to the Officers noted in the address entry.

The Associate Deans of Horticultural Colleges / Principals of Horticultural
Polytechnics and Heads of Research Stations and Schemes shall incur the expenditure from |
the provisions made in the Budget Estimates for 2016-17 Provided the following two
conditions are satisfied.

The expenditure must be sanctioned by an order of the authority competent
to sanction such expenditure and

Sufficient funds must have been provided for the expenditure in the Budget
for the current financial year.

The above two conditions are independent. They must always ensure
that both the conditions are satisfied before they incur any expenditure
from the university funds.

At the same time, it must be noted that more Provision will not permit
to incur the expenditure without proper justification.

The Budget allotted under Non Plan shall be incurred in a
proportionate manner by observing quarterly regulation except in the case of
labour wages, telephone charges, electricity and water charges, cultivation expenses,
vehicle tax, insurance. The Assistant Comptrollers should follow the quarterly
regulation of expenditure while admitting the bills.

In respect of provisions made under Plan, Government of India,
Other Agencies, Departmental Sponsored Schemes, KVKs the Associate Deans of Colleges,
Programme Co-ordinators of KVKs, Principals of Polytechnics and Heads of Research
Stations and Schemes etc., are requested to invariably obtain concurrence of the
Comptroller before incurring expenditure.

The proposals for sanction of expenditure beyond the powers of
Associate Deans/Principals/Heads of Research Stations and Schemes should be sent to
the University duly enclosing the prescribed proforma after filling up the columns, in
the absence of which the Proposals will not be considered.

All the Associate Deans of Colleges/Principals of Polytechnics/Heads
of Research Stations and Schemes, Programme Coordinators of KVKs and all other
Heads of offices etc., are requested to strictly follow the above instructions in
operating the Budget for the year 2016-17 and keep the expenditure within the
amount allocated for the purpose by observing utmost economy without detriment to
the objectives for which provisions have been made in the Budget Estimates.

Contd.........2

<!-- page 2 -->

2
All the Estimating Officers are requested to note that, sufficient
provisions have been made under all the Head of Accounts after taking into
consideration the proposals submitted by them in consultation with the Deans, Directors
etc. Hence, it may be noted that proposals for provision of any additional funds under
any head of account will not be entertained during the financial year 2016-17
under any circumstances. They are also informed that they should not come up with
proposals for re-appropriation of funds from one sub-head to another simply
because of availability of savings, particularly from out of the savings available under
the sub heads "Labour wages, Vehicles tax, Insurance and Recurring Contingencies to
Non recurring contingencies and vice-versa". It may also be noted that any proposals
or re-appropriation will be examined thoroughly and will be attracted by Audit for
excess estimation by the Estimating Officer and he will be held responsible for such
higher estimation in Budget Estimates 2016-17. 1
All the Associate Deans of Colleges/Principals of Polytechnics/Heads
of Research Stations and Schemes, Programme Coordinators of KVKs and all other
Heads of Offices etc., are requested to strictly adhere to the instructions detailed
above.
The Budget Estimates for 2016-17 is available in University website:
www.drysrhu.edu.in.
Smt. N. SREEKALA
COMPTROLLER
To
All the Associate Deans of Colleges of Horticulture
All the Principals of Polytechnics
All the Heads of Research Stations/Schemes
All the Programme Coordinators of KVKs
CC to: P.S to Vice-Chancellor, Dr. YSRHU
PA to All University Officers, Dr. YSRHU
Copy to: the Joint Registrar / The Deputy Registrar / The Deputy Comptroller
Copy to: All the Assistant Comptrollers / The Assistant Registrars
Copy to: All the sections Superintendents, concerned in the Admn. Office, Dr.YSRHU
Copy to SF/SC
౧౮? Ue A é
Assistant Comptroller (Budget & Grants)
