---
doc_id: "ffdbc3affa22e957"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0817840e9e387530"
---

<!-- page 1 -->

dbeJi"6. 6s6)Epoe5 BDAS6 s.d5. 5e)16 aSI.5e)r.6.
"$eSt)€AS X)oqlj: ol /2025
Xlt&s" Ui>Sco,$
r55dlEooe5 E06Se5 s"df, Se)vt! booef .$esirdirs X:oes
o1l2o25 1is"do C6Siroda:6,$ Co5rJDS (>$cil:d avdon", trds5c$J
l8du.f EE$E g=+ SoaS6 Jdos€S5, erot6G5d8,Sac5rer6 nclc

JDoctu n'Zs5cs 6"S".f ztg" $6$6 & aql $af'*6, Sort$ ag1,
5o16r rro erda'o 3:6$ 18o6 36q50 X>oaroQoDJ esdS$o lSSaJe5
Eo0e5 a"floe:l 8qI tsa5EQd gbSe3or5a:6J3. er,$oe56o eeaJSQq)
XrJoOloOJ eoql5oeSo'ur, 6OJX>Lsq: JDOob a6d Xloz:o66 X:1oe>
X>Jo$on X)OeOoJa)AJl.

eso6J elq55o6o"o>, eeEJS*o X:JoO;o.)J 6OJbLoo: JoooiD
.$eJ"d*)Sd =.:Q,J) er(6 qi:5reeo,tu Xro0Oor)J ep5oe56o boa:o66
€5950 Xroaro6o0J A,$e5 EDoeS Oi$ler JoOctu i:o$S OXpo: fu{o

dc[:a:6 q>o"tr dc$a&Jl.

eraJS*s XrJva"6 ebelo lSoO d6850 $oa:o6o0J }Je5
ir0e5 OXpo / -oo55 Ofue, SovCt Jo0c[r> 5?$o 6'o'J0 8q1e->
ep6s"os EesEQd $odol:6.5ad

Ji.

3)rs6a)6c5OE
1. ff6 t56
@Qg,J eaJs$et> eod:e.veJ,d dJocS:J )oi:! a6ndd:1

=.oogS Oilror

t. er55 ?.:tyhc[:S gl5 - rr
z. Ee5J6a epda0t=,*ec6

36{st Xroa:o6o.)J JoipJ
a *6?,5) -":o$5 OXpog0pOo6st

esa5S$er: 1Eo6 d6,$ C653roi5o

lt'aats"Jd5o.

<!-- page 2 -->

$&)OoE l5oe.r:
d6: 29.06.2026$Jtc$ro: 65c[:o

1

0:30 llo0roSo (e5X:f CXrOn"

6 Jo oSICS Ir'a dusJE,to )

$oo:
ADME / l-i:Sf}6 n"0 so"5oc[ro,
c. p.3.Jtu.er6 t-$4be5S pd5 Sv"a"o,
#6 a:f,o6 E,SoSEb, DM&Ho soSocfi:o Jdotlorr,
Sqvdu -534oo2,

X> So O

1.

2.
3.
4.

lo $SoRl,$ csXl er 60$5 Uryer:

ssc / 105 etddA x)Q8)BeS (x)SJ d6 5;Ssoea sosl
aocc636cbc5 6Q"cBe5

66 / 5d bQase*

5o"pOd?c6 5:"61o Eotsvo:
5. 1s.saJd / 6t6 x)QbBd

6. es,{DaJJ 6O JI:Lser: (59or)Jtf, )
7. sto 6OJbLeSo (JQoAJrf)

8.

il8 x)Q"cBcP

L Cob $;J516o
't 0. era"6 sq)
11. a66 X:oao66 er6-6 Sgoo (6055[qo SJo0;oOJr.t'
X>oao66ilgooelXle>oe5X>JSX:onI:"adc56r5JEdo)

! BoJaBJ 35{50 5oero6o.)J aJd -00e5 OXp I -oo55

OQ *CI EdEQei $odo$6.5a&Jl. Jo35 dc$ar6,$ (Serected)

s{s{reu $rt6$ s0rOo 6st Xf artirs5E,{0.

d6:23.06.2026

eeD,

|!*W,'ta
sdf

ADME{-3C3}5 '

tiSdlEooe5 E0655
5o:"du e3q1,5ort1:
L<
43
