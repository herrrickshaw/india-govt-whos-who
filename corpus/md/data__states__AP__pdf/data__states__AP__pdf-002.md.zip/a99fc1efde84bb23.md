---
doc_id: "a99fc1efde84bb23"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "52ecb83a68226285"
---

<!-- page 1 -->

CENTRE FOR DISTANCE EDUCATION

ACHARYA NAGARJUNA UNIVERSITY :: NAGARJUNA NAGAR - 522 510
Dt: 23-09-2025

NOTE
Admission Criteria:
1. The MBA/MCA admission will be purely based on
the merit in the ANUCEI

ICET-2025

Examinations and the eligibility criteria given in the admission notification.
2. The MBA/MCA admission form will be live on
25-September-2025.
3

Candidates are advised to apply for the admission through the CDE, ANU websIte on or beore

05-0ctober-2025.

4. The CDE, ANU will publish the list of students short-Ilisted for the admission on 06-0ctober
2025.

5. The short-listed students must pay their fee on or before 10-0ctober-2025, failing which their

admission will be cancelled and the seat willbe allotted to the next eligible candidate.
6

The candidates are advised to be very careful while filling the details of Entrance Hallticket
Number and eligibility information, failing which their provisional admission will be cancelled.

7. The CDE, ANU reserves the right to cancelthe admission without assigning any reason what
soever and any fees paid will not be refunded.
8. The ANUCET and ICET rank holders will be given equal weightage. However, if there are not

enough ICET -2025 students, their seats will be filled with ANUCET-2025 students.

9. ANUCET- MBA students with entrance test marks of 180/200 or above are encouraged to

apply for the MBA admission as the current cut-off mark for the ANUCET entrance exam is 180.
10. All the ANUCET- MCA students who are qualified in the exam are encouraged to apply for the

admission as there is nocut-off mark for the MCA admissions.

DIRECTOR

DIRECTOR

CENTRE FOR DISTANCE EDUCATION

4CHARYA NAGARJUNA UNIVERSITY
NAGARJUNA NAGAR -522 513
