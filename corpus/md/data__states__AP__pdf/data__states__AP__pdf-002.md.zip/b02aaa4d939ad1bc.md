---
doc_id: "b02aaa4d939ad1bc"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 2
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "6f6e479aca679749"
---

<!-- page 1 -->

NOTICE INVITING TENDER (Online version)
[SiNo. [em న 05ంగంగకంం టా!
a |
SPSR Nellore District
2, [FILETNIT Number | 1004/CFSc/2019-20 ర!
3. Tender Subject Supply and Installation of LCMS/MS to Antibiotic Residue
Analysis Laboratory, Department of Fish Processing
0 Fae es
(| at Veterinary Hospital Complex, Sri Venkateswara
Veterinary University, Visakhapatnam-530002
Document
[osc ltederType ౦099 లా!
| 6. | Tender Category __| Products, Scientific and Engineering Equipment __|
es EMD Amount _ for | Rs: 1,00,000/- to Rs: 10,00,000 of the bid quoted Rs. 20,000/-
provisions(INR) Rs. 10,00,001 to Rs. 25,00,000/- of the bid quoted Rs: 40,000/-
Rs: 25,00,001/- to Rs:50,00,000/-of the bid quoted Rs: 80,000/-
Above Rs: 50,00,001/-of the bid quoted Rs :1,00,000/-
. The Administrative Officer, College of Fishery Science,
[ [ew ome ననన bomen
Tender document
క్‌ మాన జరయా రము
10 Tender Document
Downloading online 10.02.2020 4:00 PM
closing Date
11. Bid submission Online
5 12. Last date for
submission of all the
uploaded documents
(hard copies) at 12.02.2020 11:00 AM
College of Fishery
Science, Muthukur,
SPSR Nellore District
13. Technical Bid Opening
Date and
Time(Qualification and | 12-02-2020 3:00 PM
Eligibility Stage)
= 14. Price Bid Opening
Date and Time after finalization of Technical bid
(Financial Bid Stage)
College of Fishery Science, SVVU, Muthukur , SPSR
Opening Nellore District
1 of 2

<!-- page 2 -->

మ Associate Dean, College of Fishery Science, SVVU,

Opening authori Muthukur , SPSR Nellore District

Contact 9701620777 / 9441863620

Details/Telephone

19. Procedure for Bid| 1. Bids shall be submitted online.

Submission 2. The participating bidders in the tender should
register themselves free of cost on e-procurement
platform in the website

ద http://www.apeprocurement.gov.in.
Note: After tendering, all Bidders should submit the
attested copies of the uploaded certificates along with
EMD to the Associate Dean, College of Fishery Science,
SVVU, Muthukur , SPSR Nellore District on or before
12.02.2020 11:00 AM, failing which their tender will be
summarily rejected.
Transaction fee on e-Procurement Platform: All the
participating bidders shall pay a transaction fee (non-
refundable) as mentioned in the NIT payable to M/s
APTS, Vijayawada and through on line. (0.03% of
estimate contract value + GST).It is mandatory for all the
participant bidders from 1“January 2006 to pay a Non-
refundable Transaction fee electronically to the M.D.,
A.P.T.S, Vijayawada by the service provider through
"Payment Gateway Service on E-Procurement
platform".
The Bidder shall authenticate the bid with his digital
certificate for submitting the bid electronically on e-
Procurement Platform and the bids not authenticated by
Digital certificate of the bidder will not be accepted on the
e-Procurement platform
20 General Terms and |AS PUBLISHED IN THE TENDER DOCUMENT
స Conditions and
specifications of the
equipment/Items
et Ore వంటా
న @\ Associate D an
© 0)) College of Fishery Science
4 z ట్ట Venkateswara Veterinary University
% ఖ్‌ Yt SPSR Nellore District
* గ
2 of 2
