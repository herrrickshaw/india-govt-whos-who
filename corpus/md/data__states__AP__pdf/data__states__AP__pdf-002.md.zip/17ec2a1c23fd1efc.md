---
doc_id: "17ec2a1c23fd1efc"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 4
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "8c9b354fcf31fa98"
---

<!-- page 1 -->

GOVERNMENT OF ANDRA PRADESH
DEPARTMENT OF WOMEN DEVELOPMENT AND CHILD WELFARE
OFFICE OF THE DISTRICT WOMEN AND CHILD WELFARE
AND EMPOWERMENT OFFICER, GUNTUR
NOTIFICATION NO:RC.NO.36/A1/2026 DATE:09.07.2026
SUB: RECRUITMENT FOR VARIOUS POSTS IN ONE STOP CENTRE (OSC),
GUNTUR AND THULLURU ON CONTRACT BASIS
సన ** **

Applications are invited from eligible candidates (only women) for the following
positions at the One Stop Centre (OSC), Guntur and Thulluru in Guntur District. These
posts are purely on acontract basis for an initial period of one year, subject to
performance and scheme continuation.

Place of No. of క్‌
OSC, Guntur R.P. No.07: SC Group-II
Multi-purpose Staff | OSC, Guntur R.P. No.10: BC-B
3 | Multi-purpose Staff | OSC, Thulluru R.P. No.08: ST
రె

<!-- page 2 -->

GENERAL INSTRUCTIONS & ELIGIBILITY:

¢ Residency: Candidates must be residents of Guntur district and possess a valid domicile
certificate.

¢ Age Limit: Generally, between 18-42 years (relaxation as per Government norms).

¢ Application Mode: Interested candidates should submit their application in the prescribed
format along with self-attested copies of educational certificates, Aadhar card, and
experience certificates as per the below mentioned ANNEXURE-I.

¢ Submission Address: Office of the District Women and Child Development Officer,
Swashakthi Buildings , Opp: R&B Guest House , Collector Bunglow Road , Guntur

e Date for Submission: 10.07.2026 by 10.30 AM

e Last Date for Submission: 18.07.2026 by 5:00 PM.

e Selection Process: Selection will be based on merit, relevant experience, and an interview
conducted by the District Level Selection Committee.

IMPORTANT NOTES:

1. These positions are temporary and do not confer any right to permanent government
employment.

2. Only shortlisted candidates will be called for the interview. No TA/DA will be paid.

3. The selection committee reserves the right to cancel or modify the recruitment process
without prior notice
Key Instructions

= Application Mode: Applications must be submitted (APPLICATION FORM available on
the https://guntur.ap.gov.in/) either in person or via Registered Post to the District
Women and Child Welfare and Empowerment Officer, Guntur.

* The applicants should fully satisfy themselves with respect to their qualification and other
eligibility criteria before submission of application. No further correspondence will be done in
this matter.

Required Documents (Self-Attested Copies)

¢ Proof of Age (SSLC/Birth Certificate).

e Caste Certificate

* Educational Qualification Certificates and Mark sheets.

« Experience Certificates in the relevant field.

e Identity Proof (Aadhar Card/Voter ID).

* Two recent passport-size photographs.

<!-- page 3 -->

Name of the Post Salary per
month
Multi-purpose Staff Rs.13,000/-

<!-- page 4 -->

ANNEXURE-I
Nameofthe], . tst~SS
sino Post Required Educational Qualification and Experience
The Case worker should be a woman, a resident of the local
community (so that local human resource and expertise is
utilised for effective functioning of the centre) and possess
the following basic qualifications:
1 Case Worker e A Bachelor's degree in law / social work / sociology
/ social science / psychology
e Minimum three years of experience of working on
women related relevant domains in a Government or
Non-Governmentproject / programme
e Multi- Purpose worker preferably a woman can be any
7 person who is literate with knowledge / experience of
2 Saree working in the relevant domain. (Preference will be
given to an individual with a High School degree).
(lex aad
District & Child Welfare &
Empowerment Officer, Guntur
