---
doc_id: "c29cfaede72b8d07"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 7
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "4d81d2ee397b2ce9"
---

<!-- page 1 -->

6
GOVERNMENT OF ANDHRA PRADESH
OFFICE OF THE DISTRICT MEDICAL AND HEALTH OFFICER, GUNTUR
GUIDELINES FOR RECRUITMENT OF VARIOUS CATEGORIES OF POSTS IN PRIMARY
HEALTH CENTERs IN ERSTWHILE GUNTUR DISTRICT
NOTIFICATION NO.0059/E1/2026-PHC, DT.22.01.2026

1 Applications are invited from the eligible candidates for filling up of
paramedical posts / FNO / SACW on contract/ outsourcing basis in PHCs
under the administrative control of the District Medical and Health
Officer, Guntur in Erstwhile Guntur District.

2. Details of Name / Category of the posts, number of posts notified, Education
qualification and Experience required are mentioned in Annexure - I.

3. Age relaxations -

OC candidate should not have completed 42 years of age as on 31.12.2025
(Should not have been born before 01.01.1982).

SC/ST/BC Candidates should not have completed 47 years of age as on
31.12.2025. (Should not have born before 01.01.1979).

Ex-Servicemen and Physically Challenged persons should not have
completed 50 years as on 31.12.2025 (Should not have born before 01.01.1976)

4. Candidates shall submit their applications (as per the format given) along
with the following documents through Registered post /Drop ‘Box
arranged in O/o DM&HO, Guntur on or before 02.02.2026 by 5.00 pm.

List of attested copies to be enclosed.
a. Copy of SSC Certificate
b. Copy of Intermediate Certificate
c. Copy of certificate of qualification mentioned against post
d. Copy of Marks memos of qualification mentioned against post
e. Copy of Latest Caste Certificate issued by MRO in case of BC, SC and
ST.
i Study certificates from 4" to 10% class
g. Copy of Sadhram Disability Certificate if applicable
h. Copy of Ex-Service Man Service Certificate if applicable
i. Copy of Sports Service Certificate if applicable
ib Form of application as per the format duly filled and signed.
k. Copy of Service Certificate for weightage marks.
Application Fee :
Rs.800/- for OC, BC Candidates
Rs.500/- for SC / ST / PH / Ex-Service Men Candidates
CG scanned with OKEN Scanner

<!-- page 2 -->

7
The application fees should be paid through online to the Union Bank Account,
Account No.100710100054512 and IFSC Code UBINO810070 in the name of District
Medical & Health Officer, Guntur payable in Guntur Medical College Branch, Guntur the
transaction reference id should be mentioned in the form of application.
5. METHOD OF SELECTION
A. Selection Process by merit
a) Total Marks -100
b) 75% Marks will be allocated against marks obtained in the qualifying
examination i.e., Aggregate of Marks obtained in all the years in the qualifying
examination.
B. Particulars of weightage:
1. @ 2.5 Marks per Six months of service in Tribal Area.
2. @ 2.0 Marks per Six months of service in Rural Area. ”
3. @ 1.0 Marks per Six months of service in Urban Area.
4 .Up to 10 marks @ 1.0 mark per each completed year after acquiring requisite
qualification.
5. No weightage will be given for the service rendered less than Six months,
6. There will be no interview (On merit cum RoR basis only).
6. EDUCATIONAL QUALIFICATIONS:
Sl. | Name / Category of Required Educational Qualifications
No the Post |
Under PHC
SSC, Diploma in Medical Lab. Technology recognized by the Govt.
of Andhra Pradesh
(OR)
Two years Intermediate Vocational Course in DMLT and have one- |
year clinical training in selected Govt. Hospitals (in which the
students have been permitted to undergo clinical training)
(OR) |
Lab. Technician Completed one-year apprentice ship training in identify hospitals |
1 | Contract (300-OCSs) and awarded apprentice ship completion certificate by the board of |
apprenticeship Training, GOI, Southern Region Chennai. Or B.Sc. |
Medical Lab. Technology |
(OR) |
B.Sc. with BZC in first class/B.Sc. (Life Science) in first class with |
P.G. Diploma in Medical Lab. Technology issued by the NIMS |
Hyderabad/SVIMS Tirupati.
Registered with A.P. Paramedical Board with up to date renewal.
Female Nursing [10 Class or equivalent
2 Orderly, (FNO)
Outsourcing Basis
(APCOS) య SORE Se OOS
Sanitary Attendant | ~
cum Wa .
న | 10% Class or equivalent
(APCoS pee eee |
CG scanned with OKEN Scanner

<!-- page 3 -->

8
7. HOW TO APPLY :.

1. Candidates shall submit filled applications form in the Drop Box arranged in the
O/o DM&HO, Guntur or through Registered Post in the name of District Medical
and Health Officer, Guntur Opp. Collectorate, Nagarampalem, Guntur.

2. Visit district website shttp://guntur.ap.gov.in.

3. In case of OC /BC candidates, Fee shall be paid for an amount of Rs.800/- and
SC/ST/PH/Ex-Service men candidates of Rs.500/-

4. The attested xerox copies of the following certificates should be enclosed along with
applications.

a) Aadhar Card

b) Passport size photo

c) SSC or equivalent certificate (for Date of Birth)

d) Latest Caste Certificate in case of SC /ST/BC (with categorization if any)
issued by MRO concerned. In the absence of proper caste certificate, the
candidate will be considered as OC candidate.

e) In case of Physically Challenged person, Latest certificate issued by Medical
Board should be submitted.

f)_ In case of Ex-servicemen, relevant certificate issued by competent authority
should be submitted.

g) Study Certificates from class IV to X from the school where the candidate
studied. If SSC or its equivalent done by private study, without attending
any school, residence certificate issued by MRO for previous 7 years. (in
prescribed proforma). In the absence of the said certificate the candidate will
be considered as non-local.

h) Service certificate from the controlling officer concerned (DM&HO/DCHS/
Any other authority who appointed the applicant) working on Contract ih
Outsourcing basis. In absence of which, the candidate will not be given any
weightage.

i) Fees payment receipt / Counterfoil should be submitted.

8. INSTRUCTIONS TO CANDIDATES:
Caste & Community

a) Community Certificate issued by the competent authority in terms of G.O.Ms.No.
58; SW(i) Dept., dt: 12-05-1997 (Candidates belonging to BC, SC & ST of other
States are not entitled for reservations)

b) The General Rule 22 of Special representation shall apply to the appointments of
these posts subject to various provisions in the relevant Service tules, except in the
case of Physically handicapped persons.

u) The reservation to Women will apply as per General Rule 22-A (G.O.Ms.No.

41, WD&CW(Estt) Dept., dt: 01-08-1996
CG scanned with OKEN Scanner

<!-- page 4 -->

\
9
9. The Rule of Reservation to local candidates is applicable
Local : In terms of Para 8 of the G.O., AP. Public Employment (Organization of
local cadres) and regularization of Director Recruitment order 1975 (G.O.Ms.No,
674; G.A(SPF.A)DEPARTMENT, DT: 29-10-7975), G.O.P No.763;G.A.(SPF.A)
Department,dt:15/11/1975, read with G.O.Ms.No.124, G.A.(SPF.A) Department,
dt; 7/3/2002.

Reservation to the local candidates is applicable as provided in the Rules
and as amended from time to time as in force on the date of notification. The
candidates claiming reservation as local candidates should enclose the required
study certificates (from IV class to SSC) or Residence Certificate as the case may
be. Subsequent production of the certificates will not be entertained under any
circumstances.

10. DEBARMENT

1. Candidates should make sure of their eligibility to the post applied for and that the
declaration made by them in the format of application regarding their eligibility in
all respects. Any candidate furnishing in-correct information or making false
declaration regarding his/her eligibility at any stage or suppressing any
information is liable to be debarred from recruitment conducted by the district
Selection Committee and summarily rejection of their candidature for this
recruitment & future recruitments.

2. The DSC is vested with duty of conducting recruitment and selection as per rules
duly maintaining utmost secrecy and confidentiality in this process and any
attempt by any one causing or likely to cause breach of this duty in such manner
or by such action as to violate or likely to violate the fair practices followed and
ensured by the Department will be sufficient cause for rendering such questionable
means ground for department.

il. DISTRICT SELECTION COMMITTEE DECISION TO BE FINAL

The decision of the district Selection committee pertaining to the application
and its acceptance or rejection as the case may be conduct of counselling and at all
consequent stages culminating in the selection or otherwise of any candidate shall
be final In all respects and binding on all concerned under the powers vested with
it. The department also reserves its right and modify regarding time and conditions
laid down in the notification for conducting the various states up to selection duly

CG scanned with OKEN Scanner

<!-- page 5 -->

10 |
intimating details thereof to all concerned as warranted by any unforeseen
circumstances arising during the course of this process.

nr oe - ee '
Vacancies
Name of the Post మా న che post eae Type of |
Cat i Appointment

/ Category in PHCs District month PP |
as on O1- |
01-2026 alesse a |
Lab-Technician 06 Rs.32,670/- Contract Basis |
2 Female Nursin శ asis |
3 Sanitary Attendant 5 . |
cum Night Watchmen 20 Rs.15,000/- Outsourcing Basis |
SACNW] |

[ota Vacancies త యం
NOTE: - The notified posts are purely temporary on contract / outsourcing
basis, the no.of vacancies may be increased or decreased as per the

instructions of the Government at a later date.
Dat ee orca
istrict Medical an Cen:
Guntu
CG scanned with OKEN Scanner

<!-- page 6 -->

Paste
11 స
passport size
photo
GOVERNMENT OF ANDHRA PRADESH
MEDICAL & HEALTH DEPARTMENT
OFFICE OF THE DISTRICT MEDICAL AND HEALTH OFFICER, GUNTUR
NOTIFICATION NO.0059/E1/2026-PHC
APPLICATION FOR THE POSTOF |
_ PERSONAL DETAILS:
1 | Full Name (Capital Letters) |
2 | Gender |
| 3. | Date of Birth |
| 4 | Father/Mother Name |
{jf
| వ్‌ | Social Status
bo ny న వలుననాలాలలా లలనా
|6 | Whether Physically Handicapped ves / NO
| 7 | Ex-Service Man | YES / NO
| 8 | Sports | YES /NO
| 9 | Aadhar Number |
| 10 | Mobile Number | 1. 2.
| 11 | e-mail addresses |
| 12 | Full Postal Address for Communication |
| 13 | Bank Remittance Id No with date: |
DETAILS OF SCHOOL EDUCATION:
a ee | PLACE, MANDAL AND DISTRICT IN
| R PASSING
| CMASS | వా లన | WHICH STUDIED
a
| IV |
| |
yp =
eee క. a |
VI | |
Vi | a J
| a —— య. —
— న F<
py టా.
CG scanned with OKEN Scanner

<!-- page 7 -->

॥
12
DETAILS OF MARKS OBTAINED
Name of the Maximum | Marks obtained /Grade Percentage
Course Marks /Grade obtained
WORK EXPERIENCE DETAILS:
SL Name of the Type of Organization re Period of works
No| Organization _| (Govt., / Private / NGO) | Position held (from....to..)
DETAILS ENCLOSURES:
Sl. Enclosed
Attested copies of
(Yes/No)
Degree Marks memos |
Caste Certificate (If applicable) |
ls | Council / Para Medical Registration / Renewal Certificate ||
4% to 10% Class Study Certificates
9 | If Private submit Residence Certificate from Thasildar for 7
ears
10 | Experience certificates from employer
Physically Handicapped Certificate
12 Ex-Service Man Service Certificate
13 | Sports Certificates if any
Signature of the Candidate
CG scanned with OKEN Scanner
