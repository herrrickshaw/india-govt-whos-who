---
doc_id: "bba795c89d1ad9ea"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 68
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "48ed494c485e1875"
---

<!-- page 1 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

The Andhra Pradesh Mineral Development Corporation Limited
(A State Government Undertaking)
E-TENDER
FOR

Selection of Agency for Working of Color Granite quarry leases (Tranche – IX) in
A.P. on Raising-Cum-Sale Contract basis
The A.P. Mineral Development Corporation Limited
(A State Government Undertaking)
294/ 1D, Tadigadapa to Enikepadu 100 ft. Road, Kanuru Village, Penamaluru Mandal ,
Vijayawada - 521137, Andhra Pradesh Tel: +91 866 2429999, Fax: +91 866 2429977
Nodal Officer
Sri M. Sudharshan Reddy,
DGM (Mining)
Contact: 9490167241
Email id: sudharsanareddy.m@apmdc.in, contracts-ho@apmdc.in
Tender No.: APMDC/P&C/Color Granite quarry leases Tran-9/2026-27/I
Dated: 05.10.2026
Tender Document Fee (Non-Refundable): INR 11,800 (Rupees Eleven Thousand Eight
Hundred only, inclusive GST at 18%)
Note: The Tender Document Fee is non-refundable and non-transferable.

Page 1 of 68

<!-- page 2 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Contents
1. Schedule for the Tender..........................................................................................................................4
2. Data Sheet...............................................................................................................................................5
3. Disclaimer................................................................................................................................................6
4. Abbreviations...........................................................................................................................................9
5. Definitions and Interpretations..............................................................................................................10
6. Scope of Services...................................................................................................................................12
7. Eligibility Criteria....................................................................................................................................13
8. Instruction to Bidders............................................................................................................................15
9. Additional Instructions to Bidders.........................................................................................................26
10. Additional Information on E-tendering process.......................................................................................27
Annexure 1: General Conditions of Contract-Services...................................................................................30
Annexure 2: Special Conditions of Contract..................................................................................................42
Annexure 3: Format for Power of Attorney...................................................................................................50
Annexure 4: Price Bid Format........................................................................................................................51
Annexure 5: Declaration against Blacklisting.................................................................................................53
Annexure 6: Check-list for the Technical Bid.................................................................................................54
Annexure 7: Proforma of the Agreement to be Signed between APMDC and the Successful Bidder............55
Annexure 8: Format for Performance Security..............................................................................................58
Annexure 9: Format for Financial Criteria......................................................................................................61
Annexure 10: Format for Submission of Pre-Bid Queries..............................................................................62
Annexure 11: Format for Affidavit of Sole Proprietorship.............................................................................63
Annexure 12: Format of Bank Guarantee for EMD........................................................................................64
Annexure 13: Schedules with Specifications of Mineral Blocks.....................................................................66
Annexure 14: Details of the Mineral Block....................................................................................................67

Page 2 of 68

<!-- page 3 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

NOTICE INVITING TENDER (NIT)
The A.P. Mineral Development Corporation Limited
294/ 1D, Tadigadapa to Enikepadu 100 ft. Road, Kanuru Village, Penamaluru Mandal,
Vijayawada - 521137, Andhra Pradesh
Tel: +91 866 2429999, Fax: +91 866 2429977
E-Mail: contracts-ho@apmdc.in
E- Tender for Selection of Agency for Working of Color Granite quarry leases (Tranche – IX) in
A.P. on Raising-Cum-Sale Contract basis
Tender No: APMDC/P&C/Color Granite quarry leases Tran-9/2026-27/I , Dated 05.10.2026;
The Andhra Pradesh Mineral Development Corporation Limited (hereafter referred as
‘APMDC’), fully owned by the Govt. of Andhra Pradesh, invites e-tenders from reputed,
experienced and competent bidders for Working of Color Granite quarry leases (Tranche – IX) in
A.P. on Raising-Cum-Sale Contract basis
The E-tender
shall
be
published
on the AP E-procurement portal at
www.tender.apeprocurement.gov.in and will be available for download from 05.10.2026
onwards. Last date for submission of Technical Bid online is 26.10.2026 by 05:00 PM. Any further
communications, amendments etc. shall be available on the above website of AP E-Procurement
and there will be no newspaper notification/advertisement in this regard.
Intending bidders shall register with AP E-procurement portal using valid Digital Signer
Certificate. Terms and conditions, timelines etc. for participating in the e-tender shall be as per
the tender document and the terms & conditions of AP E-Procurement portal shall also apply, if
any.
Employer reserves the right to (i) reject any or all bids without assigning any reasons
whatsoever, (ii) reschedule/postpone the bid date (s) due to any unforeseen circumstances at
any stage of the bid process, (iii) cancel or annul the entire bid process without assigning any
reasons whatsoever.
Sd/Managing Director
(Representing Governor of Andhra Pradesh)

Page 3 of 68

<!-- page 4 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Page 4 of 68

<!-- page 5 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Schedule for the Tender
Sl. No.
1
2
3

Parameter
Date of publication of NIT
Availability of tender documents on the
e-tendering portal of Government of
Andhra Pradesh
Last date of receiving pre-bid queries
from Bidders

Details
05.10.2026
05.10.2026
12.10.2026
13.10.2026 @ 03:00 PM
Venue: To be held via Video Conferencing
(VC) – Refer CL. 9 for further details.

4

Pre-bid meeting

5

Issue of responses to pre-bid queries,
addendum/ corrigendum, if required

6

Bid Due Date

26.10.2026 @ 17:00 Hrs

7

Opening of Technical Bid

26.10.2026 @ 17:10 Hrs

8

Announcement of Technically Qualified
Bidders

To be communicated later

9

Opening of Price Bid

To be communicated later

10

Issue of LoA to Successful bidder

To be communicated later

14.10.2026

Page 5 of 68

<!-- page 6 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Data Sheet
Sl.
No.

Parameter

1

Name of tender

2
3

Type of tendering
Mode of tendering

4

5
6

7

8

Name
Selection of Agency for Working of Color Granite quarry
leases (Tranche – IX) in A.P. on Raising-Cum-Sale Contract
basis

Open tendering
e-tender
All the participating bidders should:
Mandatory
 Register themselves in the AP eProcurement portal
requirements to
www.tender.apeprocurement.gov.in
participate in E-Tender  Have a valid Digital Signature Certificate (DSC) of signing
type.
Tender Document Fee INR 11,800 /- (Rupees Eleven Thousand eight hundred only).
inclusive of GST
Payable online on AP E-procurement portal
AP E-Procurement
All the participating bidders should pay the applicable fee
Transaction fees for the along with tax online in E- Procurement portal during Bid
tender
submission
Preferred Bidder(s) shall pay 0.04% of ECV with a cap of
Rs.10,000/- for works with ECV up to Rs.50 crores, and
E-Corpus Fund
Rs.25,000/- for works with ECV above Rs.50 crores before
entering into agreement / issue of purchase orders
Minimum
Consideration Amount Refer to Annexure -13.
(Rs/Metric Ton)

9

Earnest Money Deposit Refer to Annexure -13. Payable online on AP E-procurement
(EMD)
portal

10

Performance Security
Deposit (PSD)

Refer to Annexure -13.

Nodal Officer

Sri M. Sudharshan Reddy,
DGM (Mining)
Contact: +91 - 9490167241
Email id: sudharsanareddy.m@apmdc.in, contractsho@apmdc.in

11

12
13

E-mail address to
contracts-ho@apmdc.in
submit pre-bid queries
Address of the APMDC 294/ 1D, Tadigadapa to Enikepadu 100 ft. Road,
Limited
Kanuru Village, Penamaluru Mandal, Vijayawada – 521137,
Page 6 of 68

<!-- page 7 -->

APMDC-13/5/2026-MRKTG-APMDC

Sl.
No.

I/5112248/2026

Parameter

Name
Andhra Pradesh, India

Disclaimer
3.1

This Bid document is neither an agreement nor an offer by APMDC to the prospective
Bidders or any third party. The purpose of this Bid document is to provide interested
parties with information to facilitate the formulation of their Bid pursuant to this Bid
document.

3.2

This Bid document includes statements, which reflect various assumptions and
assessments arrived at by APMDC. Such assumptions, assessments and statements do
not purport to contain all the information that a Bidder may require. This Bid document
may not be appropriate for all persons, and it is not possible for APMDC to consider the
particular needs of each party who reads or uses this Bid document. The assumptions,
assessments, statements and information contained in the Bid document may not be
complete, accurate, adequate or correct. Each Bidder must, therefore conduct its own
due diligence and analysis and should verify the accuracy, adequacy, correctness,
reliability and completeness of the assumptions, assessments, statements and
information contained in this Bid document and obtain independent advice from
appropriate sources.

3.3

Information provided in this Bid document to the Bidder(s) is on a wide range of
matters, some of which may depend upon interpretation of law. The information
provided is not intended to be an exhaustive account of statutory requirements and
should not be regarded as a complete or authoritative statement of law. APMDC accepts
no responsibility for the accuracy or otherwise for any interpretation or opinion on law
expressed herein.

3.4

APMDC, its employees and its consultants make no representation or warranty and shall
have no liability to any person including any Bidder under any law, statute, rules or
regulations, the law of contract, tort, principles of restitution or unjust enrichment or
otherwise for any loss, damage, cost or expense which may arise from or be incurred or
suffered in connection with this Bid document, or any matter deemed to form part of
this Bid document, or arising in any way in relation to this Bidding Process.

3.5

Neither APMDC nor its employees or its consultants make any representation or
warranty as to the accuracy, reliability or completeness of the information in this Bid
document. APMDC also accepts no liability of any nature whether resulting from

Page 7 of 68

<!-- page 8 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

negligence or otherwise howsoever caused arising from reliance of any Bidder upon the
statements contained in this Bid document.
3.6

The Bidder should confirm that the Bid document downloaded by them is complete in
all respects including all annexures and attachments. In the event the document or any
part thereof is mutilated or missing, the Bidder shall notify the Nodal Officer
immediately in writing.

3.7

If no intimation is received within the last date for submission of Pre-Bid queries, it shall
be considered that the Tender Documents received by the Bidder is complete in all
respects and that the Bidder is fully satisfied with the Tender Documents.

3.8

No extension of time shall be granted to any Bidder for submission of its Bid on the
ground that the Bidder did not obtain the complete set of Tender Documents.

3.9

This Bid document and the information contained herein are strictly confidential and
privileged and are for the exclusive use of the Bidder to whom it is issued. This Bid
document shall not be copied or distributed by the recipient to third parties (other than,
to the extent required by Applicable Law or in confidence to the recipient’s professional
advisors, provided that such advisors are bound by confidentiality restrictions at least as
strict as those contained in this Bid document). In the event after the issue of the Bid
document, the recipient does not continue with its involvement in the Bidding Process
for any reason whatsoever, this Bid document and the information contained herein
shall be kept confidential by such party and its professional advisors at all times.

3.10

APMDC may in its absolute discretion, but without being under any obligation to do so,
update, amend or supplement the statements, information, assessment or assumptions
contained in this Bid document at any time during the Bidding Process. All such changes
shall be uploaded on the e-procurement portal of the Government of Andhra Pradesh. It
is the duty of Bidders to visit the e-procurement portal regularly and keep themselves
updated on the Bidding Process and any communication made in relation to the Bidding
Process.

3.11

The
Bidders
or
any
third
party
shall
not
object
to
such
changes/modifications/additions /alterations as provided in Clause 3.10 above, explicitly
or implicitly. Any such objection by the Bidder shall make the Bidder’s Bid liable for
rejection by APMDC. Further objection by any third party shall be construed as
infringement on confidentiality and privileged rights of APMDC with respect to this Bid
document.

Page 8 of 68

<!-- page 9 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

3.12

The Bidder shall not make any public announcements with respect to the Bidding
Process, this Bid document and/or the Bidding Documents. Any public announcements
to be made with respect to the Bidding Process or this Bid document shall be made
exclusively by APMDC. Any breach by the Bidder of this Clause shall be deemed to be in
non-compliance with the terms and conditions of this Bid document and shall render
the Bid liable for rejection. APMDC’s decision in this regard shall be final and binding on
the Bidder.

3.13

By responding to the Bid document, the Bidder shall be deemed to have confirmed that
it has fully satisfied and has understood the terms and conditions of the Bid document.
The Bidder hereby expressly waives any and all claims in respect thereof.

3.14

The Bid is not transferable.

Page 9 of 68

<!-- page 10 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Abbreviations
APMDC

The Andhra Pradesh Mineral Development Corporation

BG

Bank Guarantee

DSC

Digital Signature Certificate

EFT

Electronic Fund Transfer

EMD

Earnest Money Deposit

FY

Financial Year

GCC

General Conditions of Contract

GST

Goods and Services Tax

GSTIN

GST Identification Number

GSTR

GST Returns

IFSC

Indian Financial System Code

INR

Indian Rupee / legal tender currency of India

IT

Income Tax

ITC

Input Tax Credit

JV

Joint Venture

LD

Liquidated Damages

LoA

Letter of Award

MICR

Magnetic Ink Character Recognition

NEFT

National Electronic Funds Transfer

NIT

Notice Inviting Tender

PAN

Permanent Account Number

PSU

Public Sector Undertaking

RfP

Request for Proposal

RTGS

Real Time Gross Settlement

SCC

Special Conditions of Contract

TIA

Tender Inviting Authority

Page 10 of 68

<!-- page 11 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Definitions and Interpretations

5.1

5.2
5.3

5.4
5.5
5.6

5.7
5.8
5.9
5.10
5.11
5.12

5.13
5.14

The words and expressions beginning with capital letters and defined in this document
shall, unless repugnant to the context, have the meaning ascribed thereto herein.
“Applicable Laws” means all laws, legislations, statutes, rules, directives, ordinances,
notifications, exemptions, regulations, judgments/ orders of any court, tribunal,
regulatory bodies and quasi-judicial bodies or any interpretation thereof enacted,
issued, or promulgated by any authority and applicable to either APMDC or to the
Bidders;
“Authorized Signatory” shall have the meaning as set forth in Clause 8.4;
“Bid” means the documents submitted by a Bidder pursuant to this Bid document,
including the Technical Bid along with any additional information/clarifications
required/ sought by APMDC and the Price Bid, submitted strictly in the formats provided
by APMDC. The Bid shall not be considered to be a Bid if it is not submitted as per the
formats prescribed by APMDC;
“Bidder” designates the legal entity which has made a proposal, a tender or a bid with
the aim of concluding a Service Order / Agreement with APMDC;
“Bidding Process” means the process governing the submission and evaluation of the
Bids as set out in the Bid document itself;
“Bid Due Date” shall mean the last date for submission of bids, as given in the Schedule
for the Tender. No bids shall be accepted in the e-procurement portal after the Bid Due
Date;
“Bid Validity Period” shall have the meaning given to it in Clause 8.7;
“EMD” means the amount submitted by a Bidder to APMDC for participating in the
Bidding Process, in terms of Clause 8.6;
“Final Price Offer” at any point of time shall mean the highest price that has been
submitted by a Qualified Bidder
“Financial Criteria” shall have the meaning given to it in Clause 7.2;
“Financial Year” means the 12 months period from 1 st April to 31st March corresponding
to the audited annual accounts;
“Letter of Award (LoA)” means the written official intimation by APMDC notifying the
Preferred Bidder that the work has been awarded in its favour as per the terms and
conditions mentioned therein;
“Net Worth” shall have the meaning ascribed to it in Section 2(57) of the Companies
Act, 2013;
“Notice Inviting Tender” or “Bid document” or “RFP document” or “Tender Paper” or
“Tender Documents” or “Tender” or “Bid Documents” means documents issued by
APMDC vide Bid document No. APMDC/P&C/Color Granite quarry leases Tran-9/202627/I, Dated 05.10.2026 for Selection of Agency for Working of Color Granite quarry
leases (Tranche – IX) in A.P. on Raising-Cum-Sale Contract basis and shall include any
Page 11 of 68

<!-- page 12 -->

APMDC-13/5/2026-MRKTG-APMDC

5.15

5.16
5.17
5.18
5.19
5.20
5.21

5.22
5.23
5.24

I/5112248/2026

modifications, amendments, corrigenda/ addenda or alterations thereto. The
documents are as follows:
a)
This Bid document;
b)
Any corrigendum(a)/addendum(a) and clarification(s) to the Bid document
issued by APMDC subsequent to the issue of the Bid document will also be
considered an integral part of the Bid document. Any reference to the Bid
document in the Agreement shall include such corrigendum(a)/ addendum(a);
“APMDC” means The Andhra Pradesh Mineral Development Corporation Limited having
its corporate office at Vijayawada, Andhra Pradesh including its successor and assignees
or its representatives;
“Price Bid” means the Price Bid submitted by the Bidder, in accordance with Clause
8.14.2;
“Project” shall mean the quarry, quarry lease, or site where mining operations will be
undertaken;
“Related Party” shall have the meaning ascribed to it in Section 2(76) of the Companies
Act, 2013;
“Preferred Bidder” shall have the meaning given to it in Clause 8.20;
“Successful Bidder” shall have the meaning given to it in Clause 8.21;
“Technically Qualified Bidder” means a Bidder whose Technical Bid is responsive and
meets the requirements to the satisfaction of APMDC as per terms and condition of the
Bid document and is qualified for opening of its Price Bid;
“Technical Bid” means proposal submitted by the Bidder in accordance with Cl. 8.14.1;
“Tender Document Fee” shall have the meaning as set forth in Clause 8.5;
“Turnover” shall have meaning ascribed to it in Section 2(91) of the Companies Act,
2013.
All other capitalized words not defined herein shall have the same meaning as ascribed
to them in the Bid document. Terms and expressions not defined anywhere in the Bid
Documents shall have the same meaning as are assigned to them in Indian Contract Act,
1872 and/or in General Clauses Act, 1897.

Page 12 of 68

<!-- page 13 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Scope of Services
6.1

The selected Contractor shall undertake the following broad activities:
6.1.1 The Contractor shall be responsible, at its own cost and expense, to facilitate all
statutory approvals or renewals as may from time to time be required to operate
the mine. However, for avoidance of doubt it is clarified that all Documented
statutory payments to Government Authorities pertaining to clearances /
permissions / approvals shall be made by APMDC. The Contractor shall be
responsible for follow up, coordination & liaison with Government Authority for
obtaining such approvals.
6.1.2 The Contractor shall undertake mining & allied activities at the Project in strict
compliance with all applicable statutory rules/guidelines etc. Towards this, the
Contractor shall arrange, at his own cost, all required manpower, machinery, and
supervisory staff.
6.1.3 The minimum dispatch shall comply with the Minimum Dispatch obligations
mandated during Operations Stage, as provided in Annexure 2 – Special
Conditions of Contract, for the entire duration of the project and the contractor
shall pay the Consideration Amount every month for the actual dispatches in
that month or for a Minimum Dispatch, whichever is higher.

6.2

6.3

The detailed scope and specifications of the services, along with the contract period,
payment terms, etc. are given in Special Conditions of Contract as enclosed in Annexure
2.
The “General Conditions of Contract-Services” as enclosed in the tender at Annexure 1
shall form an integral part of the Bid document and will also form a part of the
Agreement placed against this tender.

Page 13 of 68

<!-- page 14 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Eligibility Criteria
#
7.1

7.2

7.3

7.4

7.5

The Bidders eligible to participate in this tender should fulfill the following Criteria:
Criteria
Required Documents
Legal Entity:
Copies of
a) Company (Private or Public)
Bidder shall be an Indian National, or a
 Certificate of Incorporation
Company (Public or Private) as defined the
 Memorandum of Association
Companies Act, 2013
 Articles of Association
b) Registered partnership firm
Note: Bidding in the form of a
 Registration certificate
JV/Consortium is NOT allowed
 Deed of Partnership
c) LLP firm
 Certificate of Incorporation
 Deed of Partnership
d) Proprietorship
 A copy of notarized affidavit on
Stamp Paper declaring that his/
her Concern is a Proprietary
Concern, and he/she is sole
proprietor of the Concern.
Financial Criteria
Certificate from statutory auditor or
Net Worth
independent chartered accountant
Bidder shall have a minimum net worth INR with UDIN, along with copies of
50 Lakhs (Rupees Fifty Lakhs only) as on the audited financial statements.
31st March of preceding financial year of
tender date, i.e., 31.03.2026
No Dues Certificate
Bidder shall submit certificate from
The bidder shall not have any mineral Department of Mines & Geology –
revenue dues to the Department of Mines & Andhra Pradesh (DMG-AP). In case
Geology – Andhra Pradesh (DMG-AP) at bidder
does
not
have
any
time of submission of bid.
mining/quarry lease in Andhra
Pradesh, an affidavit shall be
submitted.
Tender Document Fee
Proof of payment of Tender Document
Fee; Please refer to Clause 8.5 for
further details
EMD amount
Proof of payment of EMD; Please refer
to Clause 8.6 for further details.

Page 14 of 68

<!-- page 15 -->

APMDC-13/5/2026-MRKTG-APMDC

#
7.6

7.7
7.8

Criteria
Blacklisting Criteria
The Bidder should not have been banned/
blacklisted by APMDC or any government
agency or any PSU as on the date of
submission of Bid.
The Bidder should have valid PAN and GSTIN
registration.
Power of Attorney

I/5112248/2026

Required Documents
Affidavit to this effect, as per the
format given in Annexure 5

a) Copy of GST registration certificate
– REG 06
b) Copy of PAN
a) Power of Attorney (as per the
format given in Annexure 3) in
favour of the Authorized Signatory
of the Bidder who shall also be the
DSC holder. (Kindly refer Clause
8.4)

Page 15 of 68

<!-- page 16 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Instruction to Bidders

8.1

Note:
a. APMDC is inviting tenders for the selection of RCSC contractors for multiple mineral
blocks, with each mineral block corresponding to a separate schedule, as specified
in Annexure -13. Bidders can submit their bids for one or more schedules, at their
discretion.
b. Tender Document Fee shall be payable only once by a Bidder, irrespective of the
number of schedules for which bids are submitted.
c. For each schedule for which a bid is submitted, the Bidder shall be required to pay
the corresponding Earnest Money Deposit (EMD) separately.
d. Technical capability and qualification criteria of the Bidder shall be evaluated only
once, irrespective of the number of schedules for which the Bidder submits bids.
Upon being found technically qualified, the Bidder shall be considered eligible for
further stages of the bidding process for all the schedules applied for.
e. Price Bids shall be submitted separately for each schedule for which the Bidder
intends to participate. The rates quoted for different schedules need not be the
same and may vary from schedule to schedule.
f. Upon selection, Performance Security Deposit (PSD) shall be applicable and
collected schedule-wise, and for each schedule awarded, the Successful Bidder shall
be required to furnish a Performance Security as applicable.
The Bidders intending to participate in this tender are required to register on the eprocurement
portal
of
the
Government
of
Andhra
Pradesh
(www.tender.apeprocurement.gov.in) This is a onetime activity for registering on the
Government website. During registration, the Bidders will be required to attach a
Digital Signature Certificate (DSC) to the Bidder’s unique user ID. The DSC used should
be of appropriate class (Class II or Class III) issued from a registered Certifying
Authority. The registration shall be in the name of the Bidder, whereas the DSC holder
shall be the duly Authorized Signatory of the Bidder.

8.2

The tender documents shall be available on the AP e-procurement portal
(www.tender.apeprocurement.gov.in). There shall be no sale of hard copies of the
tender documents. Tenders can be accessed by the prospective Bidders at the above
websites and may be downloaded by them free of cost. However, the Tender Document
Fee shall have to be paid at the time of bid submission, unless exempted to be paid by
the competent authority.
8.3
E-tendering process is mentioned in Chapter 10.
8.3.1 Both the Technical Bid and the Price Bid have to be submitted on the AP e-procurement
portal. The Price Bids of only technically qualified Bidders shall be opened.
8.4
The Authorized Signatory of the Bidder shall be duly authorized by a Power of Attorney
authorizing him/her to perform all tasks related to tender submission, including but not
limited to sign and submit the bid and to participate in the bidding process on behalf of
Page 16 of 68

<!-- page 17 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

the Bidder. The format for the Power of Attorney is given in Annexure 3 of this Bid
document. Each page of all scanned documents submitted as part of the Technical Bid
shall be initialed with date by the Authorized Signatory of the Bidder at the lower lefthand corner of each page.
8.5

Tender Document Fee
The Bidder shall pay a non-refundable amount (“Tender Document Fee”), indicated in
the Data Sheet, as part of its Technical Bid. The mode of payment of the Tender
Document Fee is also indicated in the Data Sheet.

8.6

Earnest Money Deposit (EMD)

8.6.1 Bidders as part of their Technical Bid shall have to submit an Earnest Money Deposit;
the amount of the EMD is indicated in the Data Sheet. Where bids are submitted for
more than one schedule, the Bidder shall submit separate EMDs corresponding to each
schedule, while the Tender Document Fee shall be payable only once.
8.6.2 Mode of Payment:
The EMD shall be payable either online on the AP e-procurement portal or through a
bank guarantee from any scheduled banks.
For the avoidance of doubt, it is clarified that APMDC shall not be liable to pay any
interest on the EMD deposit so made and the same shall be interest free.
8.6.3 Return of EMD:
The EMD of the technically disqualified Bidders and other unsuccessful Bidders shall be
refunded after issuance of Letter of Award to the Preferred Bidder. The return of the
EMD shall be in the form of bank transfer to the account of the Bidder through the eprocurement portal of the Government of Andhra Pradesh.
8.6.4 The EMD of the Preferred Bidder shall be returned upon the Preferred Bidder furnishing
the Performance Security.
8.6.5 Forfeiture of EMD: The EMD shall be forfeited and appropriated by APMDC as a genuine
pre-estimated compensation and damages payable to APMDC for, inter alia, the time,
cost and effort of APMDC without prejudice to any other right or remedy that may be
available to APMDC hereunder, or otherwise, under the following conditions:
i)

if any of the documents submitted by a Bidder as part of the bid is found to be
not genuine or forged or any of the claims, confirmations, statements or
declarations of the Bidder is found to be incorrect or inconsistent, or is a case of
Page 17 of 68

<!-- page 18 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

any material misrepresentation of facts at any point of time during the bid
evaluation process;
ii)

if the Preferred Bidder fails to acknowledge and return to APMDC a signed copy
of the LoA or Agreement within the timeframe allowed by APMDC;

iii)

if the Preferred Bidder fails to submit the Performance Security within the
timeframe allowed by APMDC;

iv)

if a Bidder withdraws its bid before completion of the bidding process during the
bid validity period, except as provided in Clause 8.7;

v)

If the Bidder has otherwise committed any breach of the terms of Bid document;

vi)

If Preferred Bidder, does not comply with the requirements of the Price Bid

vii)

If the Technical Bid of a Bidder contains any information on Price Bid of the
Bidder;

8.6.6 In case of cancellation of the tender before bid opening date and time, the EMD shall be
refunded to respective Bidder’s account.
8.7

Bid validity period: The bid shall initially remain valid and binding on the Bidder for at
least 180 (one hundred and eighty) days from the Bid Due Date, as given in the Schedule
for the Tender. Any bid with a shorter validity period shall be rejected by APMDC. Under
exceptional circumstances, APMDC may in writing request the Bidders to extend the bid
validity period of their bids. In case the Bidder refuses the request of APMDC to extend
its bid, the EMD of such Bidder will be returned to the Bidder. However, such bids will
not be evaluated further.

8.8

Issue of clarifications:
i) Bidders may seek clarifications or request further information regarding this Tender
Document, only in the format provided in Annexure 10.
ii) Any queries or requests for clarification regarding this Tender Document must be
submitted in Excel format via email to the Nodal Officer, whose contact details are
provided in the Data Sheet. Such submissions shall adhere strictly to the timelines
specified within this Tender Document.

Page 18 of 68

<!-- page 19 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

iii) The email should clearly bear the following subject line: “Queries/Request for
Additional Information under Tender no. APMDC/P&C/Color Granite quarry leases
Tran-9/2026-27/I, Dated 05.10.2026 for “Selection of Agency for Working of Color
Granite quarry leases (Tranche – IX) in A.P. on Raising-Cum-Sale Contract basis.”
iv) Each query should contain complete details of facts, information and Applicable Law
relevant to the query and also the particulars of the person or Company posing the
query. The Corporation reserves the right to not answer any query, including any
query which is incomplete or anonymous.
v) The Corporation shall endeavor to respond to the queries. However, the Corporation
reserves the right to not respond to any question or provide any clarification, in its
sole discretion, and nothing in this Tender Document shall be taken or read as
compelling or requiring the Corporation to respond to any question or to provide
any clarification.
vi) Queries received after the last date for sending queries (as per the Schedule for the
Tender) may not be considered by APMDC.
vii) The responses to the queries received shall be published by APMDC on the AP eprocurement portal and the same shall also be considered to be a part of the tender
documents; however, the source of queries shall not be mentioned.
viii)Any non-written clarifications and information provided by the Corporation, its
employees, consultants or representatives in any manner whatsoever shall not in
any way or manner be binding on the Corporation.
8.9

Issue of corrigendum / amendment: At any time prior to the Bid Due Date, APMDC may
at its own initiative or in response to a query or clarification requested by a prospective
Bidder if found appropriate, issue a corrigendum/ amendment to the tender
documents, which shall be available for download on the AP e-procurement portal and
the same shall also be considered to be part of the tender documents. In order to give
Bidders reasonable amounts of time to take into account such corrigendum /
amendment, APMDC may at its own discretion also extend the Bid Due Date.

8.10

Extension of Bid Due Date: APMDC may, at its discretion, extend the Bid Due Date which
shall be related as an act of amendment of this Bid document.

8.11

Bidder Acknowledgement: It shall be deemed that by submitting its bid, the Bidder has:

Page 19 of 68

<!-- page 20 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

i)

made a complete and careful examination of the tender documents, including
the proforma agreement;

ii)

received all relevant information requested from APMDC;

iii)

accepted the risk of inadequacy, error or mistake in the information provided in
the tender documents or furnished by or on behalf of APMDC relating to any of
the matters related to this tender or otherwise;

iv)

satisfied itself about the scope of work and services to be delivered/rendered
and the extant conditions and all matters, things and information necessary and
required for submitting an informed bid and for providing the required services
in accordance with the tender documents including the contract (to be signed
with APMDC) and performance of all of its obligations thereunder;

v)

acknowledged and agreed that inadequacy, lack of completeness or
incorrectness of information said to be in the bidding documents or ignorance of
any of the matters shall not be a basis for any claim for compensation, damages,
extension of time for performance of its obligations, loss of profits etc. from
APMDC;

vi)

agreed to be bound by the undertakings provided by it under and in terms; and
APMDC shall not be liable for any omission or commission, mistake or error in
respect of any of the above or on account of any matter or thing arising out of or
concerning or relating to the tender documents or the bidding process, including
any error or mistake therein or in any information or data given by APMDC.

8.12

Right to accept or reject any/ all bids: Notwithstanding anything contained in the Bid
document, APMDC reserves the right in its sole discretion, without any obligation or
liability whatsoever, to accept or reject any or all of the Bids at any stage of the Bidding
Process without assigning any reasons, thereof. Further APMDC reserves the right to
annul the Bidding Process and / or to reject any or all Bids at any stage prior to the
signing of Agreement without thereby incurring any liability to the affected Bidders or
any obligation to inform the affected Bidders of the grounds for APMDC’s action.
Decision of APMDC shall be final and binding in this regard. APMDC reserves the right to
reject any bid if at any time, a material misrepresentation is made or uncovered or if the
bid received is conditional or qualified.

8.13

Language of the bid: The bid and all related correspondence and documents in relation
to the bidding process shall be in the English language. Supporting documents and
printed literature furnished by the Bidder with the bid may be in any other language
provided that they are accompanied by translations of all the pertinent passages in the
English language, duly authenticated and certified by the Bidder. Supporting materials,
which are not translated into English, may not be considered. For the purpose of
Page 20 of 68

<!-- page 21 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

interpretation and evaluation of the bid, the English language translation shall prevail.
The English translation of the documents shall be carried out by professional translators
and the translator shall certify that he is proficient in both languages in order to
translate the document and that the translation is complete and accurate.
8.14

Bid to be submitted by Bidders: The bid to be submitted by Bidders shall consist of the
Technical Bid and the Price Bid.

8.14.1 Technical Bid: Bidders shall have to submit their Technical Bid on the AP e-procurement
portal. The Technical Bid should consist of clear and legible scanned copies of all the
required documents and should be submitted within the Bid Due Date, as indicated in
the Schedule for the Tender. The Technical Bid shall contain no information on the Price
Bid of the Bidder. The Technical Bid shall consist of the following:
i)

Technical Bid Checklist (including documents supporting eligibility criteria) as
per Annexure 6 and Chapter 7.

Page 21 of 68

<!-- page 22 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

8.14.2 Price Bid:

8.15

i)

The bidder shall quote Price Bid in multiples of ‘Minimum Consideration Amount’
payable to the Corporation for the quantities dispatched from the Project.

ii)

The Bidder shall quote a rate higher than 1.00 times the Minimum Consideration
Amount payable to the Corporation for each Metric Tonne, and the quoted rate
shall be in multiples of 0.05 (i.e., 1.05 times, 1.10 times, 1.15 times etc.). The
rates quoted shall be exclusive of statutory levies, like Seigniorage fee, DMF,
MERIT, Cess, GST etc.

iii)

The quoted price multiple shall be applied individually to the Minimum
Consideration Amount per Metric Tonne of each mineral to determine the final
payable amount per tonne for each mineral. Refer the note in Annexure 4 for the
approved Minimum Consideration Amount per Metric Tonne for minerals.

iv)

In the unforeseen circumstance where any mineral other than those mentioned
above is to be despatched from the Project, the same quoted price multiple shall
be applied to the latest approved Minimum Consideration Amount per Metric
Tonne of such mineral.

v)

The Price Bid shall be submitted on the AP e-procurement portal as per the price
bid format in Annexure 4.

Material deviation

8.15.1 Bids shall be liable for rejection in case of material deviation, that shall include, inter
alia, the following:
i)

The Technical Bid or any accompanying document or Price Bid submitted by the
Bidder is not in accordance with the formats given in this tender document.

ii)

The Technical Bid is not accompanied by all the documents required to be
submitted in terms of this tender document as per Clause 8.14.1

iii)

It does not contain all the information (complete in all respects) as requested in
this tender document (in accordance with the formats provided in this tender
document);

iv)

The Technical Bid is not accompanied by documentary evidence of the
credentials of the Bidder(s).

Page 22 of 68

<!-- page 23 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

v)

The Technical Bid or Price Bid submitted by the Bidder is conditional or qualified.

vi)

The bid submitted by the Bidder is not valid for the minimum bid validity period,
as per Clause 8.7.

vii)

It is otherwise substantially/ materially in deviation of the terms and conditions
of the tender document.

8.15.2 APMDC may waive any non-conformity in the Bid that does not constitute a material
deviation, reservation or omission. APMDC may request that the Bidder submit
information or documentation, within a reasonable period of time, to rectify nonmaterial non-conformities in the Technical Bid related to documentation requirements.
Requesting information or documentation on such non-conformities shall not be related
to any aspect of the Price Bid. Failure of the Bidder to comply with the request of
APMDC by the date specified therein, may result in the rejection of its Bid. APMDC,
however, is not bound to waive such non-conformity.
8.16

Bid preparation cost: The Bidder shall bear all its costs associated with or relating to the
preparation and submission of its Bid including but not limited to preparation, copying,
postage, delivery fees, expenses associated with any demonstrations or presentations
which may be required by APMDC or any other costs incurred in connection with or
relating to its Bid. All such costs and expenses will remain with the Bidder and APMDC
shall not be liable in any manner whatsoever for the same or for any other costs or
other expenses incurred by a Bidder in preparation or submission of the Bid, regardless
of the conduct or outcome of the Bidding Process.

8.17

Opening of Technical Bids: The Technical Bids shall be opened as per the schedule
indicated in Schedule for the Tender.

8.18

Evaluation of Technical Bids:

8.18.1 The Technical Bids shall first be evaluated to determine whether they are complete,
whether the required documents have been submitted in the correct formats and
whether the documents have been properly signed by the Authorized Signatory and
whether the Technical Bid is generally in order. It will be determined whether the
Technical Bid is of acceptable quality, is generally complete and is substantially
responsive to the tender documents. For purposes of this determination, a substantially
responsive Technical Bid is one that conforms to all the terms, conditions and
specifications of the tender documents without any material deviations (as defined in
Clause 8.15), objections, conditionalities or reservations.
8.18.2 A Technical Bid which is not substantially responsive, may be rejected by APMDC, and
may not subsequently be made responsive by the Bidder by correction of the material
deviations, as defined in Clause 8.15.
Page 23 of 68

<!-- page 24 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

8.18.3 If required, APMDC may ask Bidders to provide clarifications on the uploaded
documents provided in the Technical Bid, if necessary, with respect to any doubts or
illegible documents. The Officer Inviting Tender may ask for any other documents of
historical nature during Technical Evaluation of the tender. Non submission of legible
documents may render the bid nonresponsive. The authority inviting bid reserves the
right to accept any additional document. Such clarifications shall be submitted by the
Bidder through email. The Bidders shall be allowed a maximum time period of 3 (three)
working days for submitting the requisite shortfall documents through email. However,
no changes in the Price Bid shall be sought, offered or permitted. No modification of the
bid or any form of communication with APMDC or submission of any additional
documents, not specifically asked for by APMDC will be allowed and even if submitted,
they may not be considered by APMDC.
8.18.4 The responsive Technical Bids shall then be evaluated in detail to determine whether
they fulfill the eligibility criteria (as given in Chapter 7) and other requirements of the
tender, such as submission of all the requisite documents as listed in Clause 8.14.1.
8.18.5 Based on the evaluation of the Technical Bids as well as any shortfall documents
submitted by the Bidders within the timeframe allowed by APMDC (Refer Clause 8.18.3),
the list of Technically Qualified Bidders (TQBs) shall be prepared.
8.19

Opening and Evaluation of Price Bids

8.19.1 After preparation of the list of Technically Qualified Bidders (TQBs), the Price Bids of
only such TQBs shall be opened by APMDC. A notification regarding the same shall be
sent from the AP E-Procurement to all the TQBs.
8.20

Preferred Bidder:

a. The commercial bids of only the TQBs shall be opened on the Price bid opening date.
b. Tender(s) will be evaluated on the basis of Price bid i.e., multiples of Minimum
Consideration Amount quoted.
c. The bidder quoting the highest (H1) Consideration Amount to the Corporation in terms
of multiples of the Minimum Consideration Amount will be adjudged as Preferred
Bidder and will be issued a “Letter of Award (LoA)”.
d. In the event where the contract is not awarded to the H1 bidder as a result of
unforeseen circumstances, H2 bidder will be given a chance to match the H1 rate and
execute the contract.
e. In the event that 2 (two) or more TQBs (the “Tie Bidders”) have submitted the highest
identical Price Bids. APMDC shall hold an auction amongst such Tie Bidders.
The auction shall be held at the offices of APMDC and only the Tie Bidders shall be
invited to attend the same, wherein the Tie Bidders have to physically submit their
revised Price Bids in sealed covers (signed by the Authorized Signatory on letterhead
Page 24 of 68

<!-- page 25 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

with stamp). The revised Price Bid (the “Revised Price Bid”) submitted by a Tie Bidder
during the auction should be higher than Price Bid already submitted by it, else the
revised Price Bid shall not be considered by APMDC for further evaluation. The Tie
Bidder who offers the highest revised Price Bid in such auction shall be declared to be
Preferred Bidder and the highest revised Price Bid received by APMDC during such
auction shall be the H1 price.
In the event that the Authorized Signatory of a Tie Bidder is not present during the
auction or the Authorized Signatory of such Bidder does not or is unwilling to participate
in such auction, the auction would be held amongst the remaining Tie Bidders and if
there be only one remaining Tie Bidder, the latter will be declared as the Preferred
Bidder, provided that the revised Price Bid submitted by such Bidder is higher than that
its earlier submitted Price Bid; in such a case the revised Price Bid submitted by such
Bidder shall be considered to be the H1 price.
In case of a second round of tie between the revised Price Bids submitted by Tie Bidders,
the Bidder with the higher Net-worth as on 31st March of preceding financial year of
tender date shall be declared as the Preferred Bidder and the H1 price shall be the
revised Price Bid submitted by such Bidder during the auction.
If in case the tie persists even after comparison of the net-worth, the Bidder whose
company was incorporated earlier (based on the date of incorporation as per the
Certificate of Incorporation) shall be declared the Preferred Bidder.
f. The Preferred Bidder shall, within 7 (seven) days of the receipt of the Letter of Award,
sign and send a Letter of Acknowledgement, along with a signed duplicate copy of the
Letter of Award. In the event that the Letter of Acknowledgement is not received within
the stipulated date, the Corporation may, unless it consents to extension of time for
submission thereof, appropriate the EMD and other payments made by the Preferred
Bidder as damages and also cancel the Letter of Award.
g. The bid evaluation criteria as adopted by the Corporation deemed fit is final and binding
on the bidders.
8.21 Signing of Agreement: The Preferred bidder shall sign a contract with the Corporation
within 15 days from the date of acceptance of this tender by paying the Performance
Security Deposit. Upon signing of the Agreement, the Preferred Bidder shall be
considered to be the “Successful Bidder”. The pro-forma of the Agreement is provided
in Annexure 7 hereof.
8.22

Performance Security: The Preferred bidder shall pay performance security deposit
(PSD) as indicated in the Data Sheet.
Performance Security Deposit amount shall be paid by the Preferred bidder(s) in the
form of an unconditional and irrevocable Performance Bank Guarantee (PBG) in favor of
APMDC, payable at Vijayawada from any Nationalized/Scheduled Commercial Bank,
owned by Central/State Govt. in India as per the pro-forma in Annexure 8 at the time of
signing the contract. Performance Security in the form of BG should be operable for
invocation at any Nationalised/ Scheduled bank at Vijayawada.
Page 25 of 68

<!-- page 26 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

The Performance Security will initially be valid for 12 (twelve) months, along with a
claim period of additional 12 (twelve) months and shall be extended for every year at
least 30 days before the expiration of its validity, till completion of the agreement
period. Failure to extend Bank Guarantee within stipulated time shall form event of
default by the Bidder and the Bank Guarantee shall be forfeited in addition to other
consequences of default.
The PSD will be returned within 03 months from the date of expiry of the contract, on
production of “No dues certificate” issued by the authorized representative of the
APMDC and an unconditional "No claim certificate" by the Successful Bidder.

Page 26 of 68

<!-- page 27 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Additional Instructions to Bidders
9.
Project-visit:
9.1.1 Bidders may inspect the Project and apprise themselves of the Project conditions and its
surroundings and obtain for itself, on its own responsibility, all information that may be
necessary for preparing their Bids.
9.1.2 Accessibility, infrastructure facilities, Project condition and working conditions etc, are
also to be verified by the bidders by themselves before submitting the offer. The offers
are deemed to have been submitted considering that the tenderers have inspected the
Project to their satisfaction.
9.1.3 Bidders shall bear their own costs and make their own arrangements required for
visiting the Project.
9.1.4 The Bidder may visit the Project/APMDC office and obtain information that may be
necessary for preparing the Bid document. Bidders who are interested to visit the
Project shall inform the Nodal Officer mentioned in the Data Sheet at least 1 (one) day
before scheduled date of the Project visit, along with the names and contact numbers of
their representatives who would be participating in the Project visit.
9.1.5 A maximum of 4 (four) representatives from each Bidder shall be allowed to participate
in the Project visit.
9.2 Pre-bid meeting:
9.2.1 A pre-bid meeting shall be arranged by APMDC via Video Conferencing; the date and
time of the pre-bid meeting is indicated in the Schedule for the Tender. Bidders wishing
to attend the pre-bid meeting should inform the Nodal Officer by email (Refer Data
Sheet), along with the names and email ids of the officials/ representatives of the Bidder
who would be attending the meeting, at least 1 (one) working days before the pre-bid
meeting and Link to the Video Conference (VC) shall be shared via email with such
prospective Bidders. A maximum of 2 (two) representatives from each Bidder shall be
allowed to participate in the pre-bid meeting.
9.2.2 However, attendance of the Bidders at the pre-bid meeting is not mandatory. All costs
of the Bidder related to attending the pre-bid meeting shall be borne by the Bidder.

Page 27 of 68

<!-- page 28 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

10. Additional Information on E-tendering process
10.1

The e-tendering process shall be held on the e-procurement portal of the Government
of Andhra Pradesh (www.tender.apeprocurement.gov.in). All the steps involved starting
from hosting of tenders till determination of the Preferred Bidder shall be conducted
online on the e-procurement portal.

10.2

The Bidder will have to accept unconditionally the online user portal agreement which
contains the acceptance of all the terms and conditions including commercial and
general terms and conditions and other conditions, if any, along with on-line
undertaking in support of the authenticity of the declarations regarding the facts,
figures, information and documents furnished by the Bidder on-line in order to become
an eligible Bidder. No conditional bid shall be allowed/accepted.

10.3

The Bidder will have to give an undertaking online that if the information/declaration/
scanned documents furnished in support of the same in respect of eligibility criteria are
found to be wrong or misleading at any stage, they will be liable to punitive action and
this includes forfeiture of EMD and cancellation/termination of contract/Agreement.

10.4

The Bidder will submit their Technical Bid and Price Bid online.

10.4.1

Log on to e-procurement portal: The Bidders have to log onto the e-procurement portal
of the Government of Andhra Pradesh (www.tender.apeprocurement.gov.in) using their
digital signature certificate and then search and then select the required active tender
from the "Search Active Tender" option. Then the submit button can be clicked against
the selected tender so that it comes to the "My Tenders" section.

10.4.2

Bid submission:
Note: Procedure for submission of bids on AP E-procurement portal is indicative and
might change, based on any updates/modifications in the application. Please refer to the
AP E-procurement team for any technical support in submission of bids.
a) After paying the Tender Document Fee & EMD/EMDs, pay the Transaction Fee (@
0.03% of ECV (estimated annual contract value) with a cap of Rs.10,000/- (Rupees ten
thousand only) by selecting the mode of payment as online, click on continue then,
select the payment gate way after the successful payment you will get the continue
button.
b) Now attach the entire mandatory documents by clicking on the action icons, the first
icon is to attach the documents from your common folder where bidder documents
are already available in the document library. The second icon is to attach the

Page 28 of 68

<!-- page 29 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

documents from your desktop or folder. After attaching the entire mandatory
document click on continue to proceed further
c) Attach the eligibility documents by the clicking the first icon under the action column
In the commercial stage enter the financial price by clicking on the first icon and the
second icon is to attach the documents like price bid form as it is not mandatory all
the tenders , whenever department user asked the documents.
d) After attaching all the mandatory documents then the filled status will change to
green colour indicating the filled status.
e) Next the bidder has to enter the price offer in the commercial form and click on the
save button
f) After clicking on save button, user will get a dialog box where they can see the
encryption certificate to encrypt your price. So, select your encryption certificate and
click on register to save price
g) After selecting, the encryption certificate you will get an alert as saved successfully
and if you want to edit or check you price once again click on decrypt button select
your encryption certificate and check/edit your price.
h) After the price saved, both the bid forms will be filled status in green colour indicating
successfully attached all documents, Now click on save and continue.
i) Re-verify the document you have attached in the Stage form by clicking on the Red
Cross button and if the documents are properly verified then document status will
change to green colour indicating documents verified successfully.
j) After verifying the documents click on the final bid submission button and it shows the
dialog box of Em signer where signing certificate will be displayed. Now select the
certificate and click on register
System generated acknowledgement receipt for successful bid submission: System will
generate an acknowledgement receipt for successful bid submission. The Bidder should
make a note of 'Bid ID' generated in the acknowledgement receipt for tracking their bid
status.
10.5

Modification of bids: Modification of the submitted bid shall be allowed online only
before the Bid Due Date. A Bidder may modify and resubmit the bid online as many
times as he may wish. Bidder may withdraw only once its Bid online within the end date
of Bid submission.

10.6

Opening of Technical Bids: The Technical Bids shall be opened as per the schedule given
in the Schedule of Tender. The Techno Commercial bids (Cover-I) will be decrypted
online and will be opened by the designated bid openers of APMDC with their Digital
Signature Certificates. In case no bids are received, the tender shall be automatically
cancelled with approval of the competent authority of APMDC.

Page 29 of 68

<!-- page 30 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

10.7

Evaluation of Technical Bids: The Technical Bids shall be evaluated in terms of Clause
8.18. If required, APMDC may ask Bidders to provide clarifications on their bid or
provide shortfall documents within a maximum period of 3 (three) working days.
However, no changes in the Price Bid shall be sought, offered or permitted. No
modification of the bid or any form of communication with APMDC or submission of any
additional documents which are not specifically asked for by APMDC, will be allowed
and even if submitted, they will not be considered by APMDC. Additionally, information
shall also be sent by e-mail, but it will be the Bidder’s responsibility to check their email
id regularly after opening of bid. No separate communication will be required in this
regard. Non-receipt of email will not be accepted as a reason for non-submission of
documents within prescribed time. The Bidder shall submit the requisite clarifications
and the requested documents within the specified period and no additional time will be
allowed for submission of the clarifications/ documents. In case of any failure of the
Bidder to submit the requisite documents within the allowed timeframe, APMDC shall
proceed to evaluate its Technical Bid without any further reference to the Bidder.

10.8

Based on the evaluation of the Technical Bids, the list of Technically Qualified Bidders
shall be prepared and the same shall be selected in the portal and such Bidders shall
also be informed through system. The Price Bid of such shortlisted Bidders shall be
decrypted and opened on the scheduled date and time by the designated bid openers of
APMDC with their Digital Signature Certificates.

10.9

A comparative statement of the Price Bids shall be generated by the e-procurement
system. The same shall be downloaded and will be submitted to the competent
authority of APMDC for approval and further necessary action.

10.10 Upon approval and completion of the due process of APMDC, the Preferred Bidder shall
be issued the LoA in terms of Clause 8.20. The LoA shall be sent through
email/registered/ speed post to the office address of the Preferred Bidder.
1.1

Page 30 of 68

<!-- page 31 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 1: General Conditions of Contract-Services
1.

Definitions
In the interpretation of the Contract and the general and special conditions governing it,
unless the context otherwise requires:

1.1.

“Contract” or “Agreement” shall mean the Agreement and all attached exhibits and
documents referred to therein and all terms and conditions thereof together with any
subsequent modifications thereto;

1.2.

“Project” shall mean the quarry, quarry lease, site, place or places named in the
Agreement or such other place or places at which any work has to be carried out as may
be approved by the APMDC;

1.3.

"Successful Bidder” or “Contractor” shall mean the legal entity (individual, firm,
company etc.) with whom the Contract is placed and shall be deemed to include
successors (approved by APMDC) representatives, heirs, executors, administrators and
permitted assignee as the case may be;

1.4.

"Services" means the services specified in the Agreement which the Successful Bidder
has agreed to provide under the Agreement;

1.5.

"Minimum Consideration Amount" means the amount specified in the Data Sheet.

1.6.

"Consideration Amount" means the amount (per MT) payable to the Corporation
derived from the multiples of the Minimum Consideration Amount quoted by the
Successful Bidder.

1.7.

"Gestation Period" shall mean the duration as defined under Annexure 2 (Special
Conditions of Contract) of this document.

2.

Scope of Services

2.1.

Scope of Services shall be as defined in the Special Conditions of Contract and Annexure
thereto.

3.

Instructions, Direction & Correspondence
A)

All instructions and orders to Successful Bidder shall, excepting what is herein
provided, be given by APMDC.
Page 31 of 68

<!-- page 32 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

B)

All the work shall be carried out under the direction of and to the satisfaction of
APMDC.

C)

All communications including technical/commercial clarifications and/or
comments shall be addressed to APMDC shall always bear reference to the
Agreement.

D)

The Agreement number shall be shown on all challans / invoices,
communications, packing lists, containers and bills of lading (as applicable), etc.

4.

Agreement Obligations

4.1.

If after award of the LoA, the Preferred Bidder does not acknowledge the receipt of
award or fails to furnish the Performance Security within the prescribed time limit (as
the case maybe), the APMDC reserves the right to cancel the LoA and forfeit the EMD.

4.2.

Once the Agreement is accepted and confirmed and signed, the terms and conditions
contained therein shall take precedence over the Successful Bidder’s bid and all
previous correspondence.
The Agreement shall, in all respects, deemed to be and shall construe and operate as an
Indian Contract in conformity with the Indian Laws.
Modification in Agreement
All modifications leading to changes in the Agreement with respect to technical and/or
commercial aspects including terms of delivery of services, shall be considered valid only
when accepted in writing by APMDC by issuing amendment to the Agreement. Issuance
of acceptance or otherwise in such cases shall not be any ground for extension of
agreed delivery date and also shall not affect the performance of Agreement in any
manner except to the extent mutually agreed through a modification of Agreement.

4.3.
5.
5.1.

5.2.

APMDC shall not be bound by any printed conditions or provisions in the Successful
Bidder’s Bid Forms or acknowledgment of Agreement, invoices and other documents
which purport to impose any conditions at variance with or supplemental to Agreement.

6.

Use of Service Order / Agreement Documents & Information

6.1.

The Successful Bidder shall not, without APMDC’s prior written consent, disclose any
approved plan, drawing, pattern, sample or information furnished by or on behalf of the
APMDC in connection therewith, to any person other than a person employed by the
Successful Bidder in the performance of the Agreement. Disclosure to any such
Page 32 of 68

<!-- page 33 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

employed person shall be made in confidence and shall extend only so far as may be
necessary for purpose of such performance.
6.2.

The Successful Bidder shall not, without APMDC’s prior written consent, make use of
any document or information enumerated in Clause 6.1 except for purpose of
performing the Agreement.

7.

Patent Rights, Liability & Compliance of Regulations

7.1.

Successful Bidder hereby warrants that the use of the services delivered hereunder will
not infringe claims of any patent covering such service and Successful Bidder agrees to
be responsible for and to defend at his sole expense all suits and proceedings against
APMDC based on any such alleged patent infringement and to pay all costs, expenses
and damages which APMDC may have to pay or incur by reason of any such suit or
proceedings.

7.2.

The Successful Bidder shall indemnify APMDC against all third-party claims of
infringement of patent, trade mark or industrial design rights arising from the services
delivered by the Successful Bidder.

7.3.

Successful Bidder shall be responsible for compliance with all requirements under the
laws and shall protect and indemnify completely the APMDC from any claims/penalties
arising out of any infringements.

8.

Performance Security

8.1.

The Successful Bidder shall furnish Performance Security as per the terms and
conditions provided in the Bid document.

8.2.

The Performance Security shall be for due and faithful performance during the period of
execution of the services and is liable for forfeiture in the following cases:

If the successful Bidder fails to undertake the work after signing of Agreement,
or

If the Successful Bidder abandons the work before its completion or during its
extended period, or

If the work performed by the Successful Bidder is not as per the Agreement, or

On breach of Agreement by the Successful Bidder.

8.3.

The proceeds of Performance Security shall be appropriated by the APMDC as
compensation for any loss resulting from the Successful Bidder’s failure to complete his
Page 33 of 68

<!-- page 34 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

obligations under the Agreement without prejudice to any of the rights or remedies the
APMDC may be entitled to as per terms and conditions of Agreement. The decision of
APMDC shall be final and binding in this regard.
8.4.

Performance Security shall be extended by the Successful Bidder in the event of delay in
completion of work, as defined in the Agreement for any reason whatsoever. APMDC’s
claim period shall remain valid for twelve months after the expiry of the
guarantee/warrantee/Defect Liability Period or till the satisfactory performance of the
objectives of the Agreement, whichever is later.

8.5.

For the avoidance of doubt, it is hereby clarified, that the Performance Security shall not
carry any interest.

9.

Delivery of Services

9.1.

Delivery of the Services shall be made by the Successful Bidder in accordance with terms
specified in the Special Conditions of Contract.

9.2.

The delivery terms are binding and essential and consequently, no delay is allowed
without the written approval of APMDC. Any request concerning delay will be null and
void unless accepted by APMDC.

10.

Terms of Payment

10.1. Details about the method of payment, payment terms, billings, place of payment, etc.
under this Agreement shall be specified in the Special Conditions of Contract.
10.2. All payments shall be made in INR only and shall be made directly to the bank account
of the APMDC/Successful Bidder, as applicable.
10.3. No advance shall be paid and no letter of credit shall be issued.
10.4. No interest charges for delay in payments, if any, shall be payable by APMDC.
11.

Subcontracting /out-sourcing/ sub-letting/ Assignment

11.1. The Successful Bidder is not allowed to subcontract, outsource, sub-let or assign the
contract and scope of services, either partly or wholly, without the written approval of
APMDC, for the services for which such subletting is sought. However, the APMDC
management reserves the full right to refuse any such approval to the Successful Bidder
without being bound to provide any reason or rationale for such decision.
Page 34 of 68

<!-- page 35 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Provided, nevertheless, that any such consent shall not relieve the Successful Bidder
from any obligation, duty or responsibility under the Agreement.
12.
Cancellation of Agreement
12.1. If the Successful Bidder fails to fulfil the terms and conditions of the Agreement, which
includes those spelt out in the Tender Document, APMDC shall have the right to
terminate the Agreement and award the total or balance work (if any) to any other
Service Provider at the risk and cost of the said Successful Bidder after giving 30 days’
notice to the Successful Bidder as to why the said work shall not be awarded to another
entity at his risk and cost. Further the Agreement could be terminated by APMDC if:
i)
ii)
iii)
iv)

v)

vi)
vii)

viii)

There is a force-majeure situation,
Successful Bidder has given false declaration or document including affidavit,
There is conflict of interest between APMDC & Successful Bidder during the
Agreement execution,
The Successful Bidder defaults in proceeding with the work as per the milestones
and/or in complying with any of the terms and conditions, stipulated in the
Agreement,
The Successful Bidder or firm or any of the partner represented by the Successful
Bidder, in the subject Agreement is adjudged as Insolvent by the concerned
authority and further if the Successful Bidder has been wound up and dissolved,
The Successful Bidder assigns/transfers/sub-lets the entire work or a portion
thereof without the approval of the Competent Authority,
The Successful Bidder offers to give or agrees to give gift or any other
consideration tangible or intangible, as inducement or reward for seeking or
offering benefits in the Agreement as the case may be,
A court order or an order of a competent statutory forum is received in respect
of the Service under consideration of the Agreement.

Termination of the agreement shall not relieve the Successful Bidder of any obligations
which expressly or by necessary implication survives termination. Except as otherwise
provided in any provisions of the agreement expressly limiting the liability of the
Successful Bidder, shall not relieve the Successful Bidder of any obligations or liability for
loss or damage to APMDC arising out of or caused by acts or omissions of the Successful
Bidder prior to the effective date of termination or arising out of such termination. Even
if Agreement is terminated/abandoned prematurely, APMDC reserves the right to
deduct/impose penalties and shall remain indemnified, till such time all or any such
claims are suitably addressed. APMDC reserves the right to appropriate the
Performance Security, as a genuine pre-estimated damages suffered by APMDC for the
non-performance by the Successful Bidder. APMDC may also impose further penalties
on the Successful Bidder such as holidaying/banning/blacklisting for a specific period of
Page 35 of 68

<!-- page 36 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

time. In all such cases, the decision of APMDC shall be final. This notice shall be in
accordance with Clause 12.1.
13.

Right to risk for procurement / rendering of services

If the Successful Bidder fails to fulfill the terms and conditions of the Agreement,
APMDC shall have the right to procure the services from any other party for the
execution/ completion of the scope of services under the Agreement and recover from
the Successful Bidder all charges/expenses/losses/damages which may be suffered by
APMDC, at the risk and cost of the Successful Bidder, after giving 15 (fifteen) days of
notice to the Successful Bidder. This will be without prejudice to the rights of APMDC for
any other action including termination of the Agreement.
14.
Force Majeure
14.1. “Force Majeure Event” means any event or circumstances or combination of events or
circumstances which:
A)
Are beyond the reasonable control of the Party affected by such event (the
Affected Party); and cannot by exercise of reasonable diligence, reasonable
precautions and reasonable alternative measures (where sufficient time to adopt
such precautions or alternative measures before the occurrence of such event or
circumstances is available), be prevented or caused to be prevented;
B)
Materially and adversely affects such Party’s performance of its duties or
obligations or enjoyment of its rights under this Agreement.
14.2. As soon as practicable and in any case within 7 (seven) days from the date of occurrence
of a Force Majeure Event or the date of knowledge thereof, the Affected Party shall
notify the other Party of the same, setting out the details of the Force Majeure Event.
14.3. If the Affected Party is rendered wholly or partially incapable of performing any of its
obligations under this Agreement because of a Force Majeure Event, it shall be excused
from performance of such obligations to the extent it is unable to perform the same on
account of such Force Majeure Event.
14.4. If a Force Majeure Event described above, in the reasonable judgment of the Parties, is
likely to continue beyond a period of 3 (three) months, the APMDC may immediately
terminate this Agreement by giving 1 month notice in writing to the Contractor. In case
of termination of Agreement due to Force Majeure, the Performance Bank Guarantee
shall be returned to the Contractor.
15.

Dispute Resolution

15.1. Any dispute, difference or controversy of whatever nature howsoever arising under, or
out of, or in relation, to this tender or the Agreement (including its interpretation)
Page 36 of 68

<!-- page 37 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

between APMDC and the Successful Bidder, and so notified in writing by either party to
the other party shall, in the first instance, be attempted to be resolved amicably and the
parties agree to use their best efforts for resolving all disputes arising under or in
respect of this tender promptly, equitably and in good faith. In the event of any dispute
between the parties, it is agreed that a discussion shall be held between the Successful
Bidder and APMDC within 7 (seven) days from the date of reference to discuss and
attempt to amicably resolve the dispute. If such meeting does not take place within the
7 (seven) day period or the dispute is not amicably settled within 15 (fifteen) days of the
meeting, the dispute, if referred to, shall be decided by the Civil Court of competent
jurisdiction at Vijayawada. There shall be no arbitration between the Parties. The
provisions of Arbitration & Conciliation Act, 1996 as amended from time to time, shall
have no application to the present work.
15.2. Governing law and jurisdiction: This Agreement shall be construed and interpreted in
accordance with and governed by the laws of State and Central Government in force in
India. The Courts at Vijayawada shall have exclusive jurisdiction over all matters arising
out of or relating to this Agreement.
16.

Governing Language

The Agreement shall be written in English language as specified by the APMDC in the
Instruction to Bidders. All literature, correspondence and other documents pertaining to
the Agreement which are exchanged by the parties shall be written in English language.
Printed literature in other language shall only be considered, if it is accompanied by an
English translation. For the purposes of interpretation, English translation shall govern
and be binding on all parties.
17.
Notices
Any notice given by one party to the other pursuant to the Agreement shall be sent in
writing or by email. A notice shall be effective when delivered or on the notice’s
effective date, whichever is later.
18.
Permits & Certificates
18.1. Successful Bidder shall procure, at his expense, all necessary permits, certificates and
licences required by virtue of all applicable laws, regulations, ordinances and other rules
in effect at the place where any of the work is to be performed, and Successful Bidder
further agrees to hold APMDC harmless from liability or penalty which might be
imposed by reason of any asserted or established violation of such laws, regulations,
ordinances or other rules.
19.
General
19.1. The Successful Bidder shall be deemed to have carefully examined all Agreement
documents to its entire satisfaction. Any lack of information shall not in any way relieve
Page 37 of 68

<!-- page 38 -->

APMDC-13/5/2026-MRKTG-APMDC

19.2.
19.3.

19.4.

20.
20.1.

I/5112248/2026

the Successful Bidder of his responsibility to fulfill his obligation under the Agreement
documents.
The General Conditions of Contract (GCC)-Services shall apply to the extent that they are
not superseded by provisions of other parts of the Special Conditions of Contract.
Losses due to non-compliance of Instructions
Losses or damages occurring to the APMDC owing to the Successful Bidder’s failure to
adhere to any of the instructions given by the APMDC in connection with the contract
execution shall be recoverable from the Successful Bidder.
Recovery of sums due
All costs, damages or expenses which the APMDC may have paid, for which under the
Agreement, the Successful Bidder is liable, may be recovered by the APMDC (he is
hereby irrevocably authorized to do so) from any money due to or becoming due to the
Successful Bidder under this Agreement or other Agreements and/or may be recovered
by action at law or otherwise. If the amount due to the Successful Bidder is not sufficient
to recover the recoverable amount, the Successful Bidder shall pay to the APMDC, on
demand, the balance amount.
Liability and Indemnity
Successful Bidder shall indemnify, defend and hold APMDC harmless against:
a) any and all third party claims, actions, suits or proceedings against APMDC, for any
loss of or damage to property of such third party, or death or injury to such third
party, arising out of breach by the Successful Bidder of any of its obligations under
the Agreement, except to the extent that any such claim, action, suit or proceeding
has arisen due to a negligent act or omission, breach of the Agreement, or breach
of statutory duty on the part of APMDC, its suppliers and Service Providers,
employees, servants or agents; and
b)

c)

any and all losses, damages, costs, and expenses including legal costs, fines,
penalties and interest actually suffered or incurred by APMDC from third party
claims arising by reason of breach by the Successful Bidder of any of its obligations
under this Agreement, except to the extent that any such losses, damages, cost &
expenses including legal costs, fines, penalties and interest (together to constitute
“Indemnifiable Losses”) have arisen due to negligent act or omission breach of the
Agreement, or breach of statutory duty on the part of APMDC, its suppliers or
Successful Bidders, employees, servants or agents or any of the representations;
and
to the extent of the value of free issue materials to be issued till such time the
entire Agreement is executed and proper account for the free issue materials is
rendered and the left over / surplus and scrap items are returned to APMDC. The
Successful Bidder shall not utilize APMDC’s free issue materials for any job other
than the one contracted out in this case and also not indulge in any act,
commission or negligence which will cause / result in any loss/damage to the
Page 38 of 68

<!-- page 39 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

APMDC and in which case, the Successful Bidder shall be liable to APMDC to pay
compensation to the full extent of damage / loss and undertake to pay the same.
20.2. APMDC remains indemnified (even if the Agreement ends pre-maturely) towards all or
any obligations due to APMDC by the Successful Bidder and shall continue to remain in
force till such time all or any such claims are suitably addressed.
21.

Publicity & Advertising
Successful Bidder shall not without the written permission of APMDC make a reference
to APMDC or any Company affiliated with APMDC or to the destination or the
description of goods or services supplied under the Agreement in any publication,
publicity or advertising media.

22.

Blacklisting
Blacklisting of a business concern/entity or supplier may be resorted to in following
cases:i)
If the Proprietor or Partner or Director of the business concern/entity is
convicted by a Court of Law, following prosecution under the normal process of
Law for an offence involving moral turpitude in relations to business dealings;
ii)
If security consideration of the state i.e. any action that jeopardize the security
of the State.
iii)
If there is justification for believing that the Proprietor or Partner or Director of
the Concern/entity has been guilty of malpractices such as bribery, corruption,
cheating, fraud and tender fixing etc.
iv)
If the business concern/entity refuses/ fails to return the APMDC’s dues without
adequate cause;
v)
If the business concern/entity is blacklisted by any Department of the Central
Government / State Government/Central PSU/State PSU.
vi)
If the business concern/entity is a concern/entity evader of Central / State
taxes / duties for which APMDC has received notice from the concerned
department of Central / State Govt.
vii)
If violation of important conditions of contract/agreement.
viii)
If submission of false/fabricated/forged documents for consideration of a tender

23.

Statutory and Legal requirements

23.1. The Successful Bidder shall comply with all the statutory and legal requirements and
requirements for obtaining license under Labor laws (eg. Contract Labour (Regulation
and Abolition) Act 1970) and shall bear all necessary expenses in this regard.
Page 39 of 68

<!-- page 40 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

23.2. The Successful Bidder shall abide by the applicable statutory provisions on minimum
wages, payment of wages, EPF, ESI, gratuity, retrenchment, leave and leave
encashment, health care, uniform and compensation to its employees and workmen.
23.3. Further the Contractor at his cost shall arrange appropriate quality shelter, water and
Medical facilities for the workmen engaged by him, as may be required to ensure
compliance with statutory and legal requirements.
23.4. The Successful Bidder shall not take any action in relation to handling of its personnel
which may adversely affect the existing labour relations of APMDC. The Successful
Bidder has to maintain close liaison and cordial relations with the local people and the
unions.
24.

Safety

24.1. The Successful Bidder shall comply with all the stipulations and requirements of DGMS
as well as with other applicable laws concerning mine safety and as applicable and
relevant to its scope of services. The Successful Bidder shall at all times be responsible
to carry out all operations as per the extant applicable laws. The Successful Bidder shall
also be responsible for complying with the statutory obligations of the state Pollution
Control Board and other environmental and safety regulations. The Successful Bidder
shall ensure that its operations create no hazards or disturbance for the surrounding
inhabitants and areas.
24.2. APMDC may from time to time audit the safety practices employed by the Successful
Bidder and the Successful Bidder shall comply with the recommendations/ directions
made by APMDC as a result of such audit.
24.3. During the course of the contract period, if any accident occurs whether major or minor
in which the Successful Bidder or its employees are involved or are responsible, the
Successful Bidder shall immediately inform APMDC without any delay.
24.4. The Successful Bidder shall indemnify APMDC from any liability falling on APMDC due to
any accident, whether minor or major, or by any act of commission/omission by the
Successful Bidder or by its representatives or by its employees. If APMDC is made liable
for any such claim by the court of law or any other authority, the same shall be
reimbursed to APMDC by the Successful Bidder as if APMDC has paid on their behalf.
The same shall be adjusted from the invoices payable by APMDC to the Successful
Bidder, if not paid within a period of 30 (thirty) days of such payment being made by
APMDC.
Page 40 of 68

<!-- page 41 -->

APMDC-13/5/2026-MRKTG-APMDC

25.

I/5112248/2026

Safety, Inventory and Stock Accountability

25.1. The Contractor shall bear full responsibility for the security, custody, and accurate
accounting of all mineral stocks within the mining lease and stockyard areas. Any
discrepancy between physical stock, book stock, or dispatch records shall be treated as
a loss attributable to the Contractor unless conclusively justified to the satisfaction of
APMDC.
25.2. The Contractor shall prevent grade loss by ensuring proper handling, stacking, and
processing of mineral. Any deterioration in quality or recovery resulting from negligent
or improper practices shall be considered a financial loss to APMDC and recovered from
the Contractor, along with associated penalties.
25.3. Transit shortages, weighbridge inaccuracies, and weighing-related discrepancies shall
fall entirely under the Contractor's risk and responsibility. The Contractor shall ensure
that weighbridges remain fully functional, calibrated, and tamper-proof, and any
mismatch shall be recoverable from the Contractor.
25.4. Loss of slurry, fines, or material due to spillage, runoff, poor drainage, or improper
handling shall also be treated as preventable loss. APMDC may verify stocks through
inspections or DGPS surveys, and any unexplained variance shall be recoverable from
the Contractor along with applicable penalties.
26.

Reporting, MIS & Monitoring System

26.1. The Contractor shall maintain a comprehensive and reliable Reporting and MIS
framework covering all mining, production, dispatch, and stock-related activities. All
information provided shall be accurate, timely, and verifiable at any stage. APMDC shall
have unrestricted rights to inspect, review, or audit any records maintained by the
Contractor, and all reports shall be submitted in formats approved by APMDC.
26.2. The Contractor shall furnish daily operational reports, including a Daily Production
Report and a Daily Dispatch Report. These reports shall capture shift-wise production,
machinery and manpower deployment, drilling and blasting details, equipment
downtime, dispatch quantities, weighbridge slip references, and grade-wise quality
parameters. A Daily Stock Position reflecting opening stock, daily movement, and closing
stock shall also be maintained accurately.

Page 41 of 68

<!-- page 42 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

26.3. A Monthly Operational Report shall be submitted summarizing total production, gradewise output, and dispatch performance, along with cumulative progress against the
mining plan. Monthly machinery and manpower reports detailing equipment utilization,
maintenance activities, manpower strength, and statutory training shall also be
provided. All data required for statutory returns under IBM, DGMS, PCB, and other
authorities shall be supplied within two working days of month-end.
26.4. The Contractor shall prepare a monthly reconciliation of actual dispatch versus the
Minimum Dispatch requirement and compute the corresponding Consideration Amount
payable to APMDC. Any discrepancy identified by APMDC must be resolved within three
working days. Where APMDC implements digital monitoring systems such as CCTV, GPS
tracking, RFID, or automated weighbridge integration, the Contractor shall ensure
uninterrupted support and immediate rectification of any failures, as consistent and
accurate reporting is essential for contract compliance.

Page 42 of 68

<!-- page 43 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 2: Special Conditions of Contract
1.

General
These Special Conditions of Contract delete, amend or add to the clauses in the General
Conditions of Contract. In the event of an inconsistency, these Special Conditions of
Contract shall supersede or take precedence over the General Conditions of Contract to
the extent of that inconsistency.

2.

Scope of work, service requirements including technical parameters
Scope of Work of the Contractor

2.1.

The obligations of the Contractor during the “Development Stage” (as defined in Clause
3.1 (i) below) shall include:
i) The Contractor shall ensure that all the required statutory clearances like EC, CTE,
CTO etc. are obtained within 360 days from the “Commencement Date” as defined
in Clause 3.1 (i) (a) below.
ii) To operationalize the lease in an expeditious manner, APMDC has already started
the process of obtaining statutory clearances. It is clarified that all Documented
statutory
payments
to
Government
Authorities
pertaining
to
clearances/permissions/ approvals shall be made by APMDC.
iii) The Contractor shall be responsible for follow up, coordination & liaison with
Government Authorities for obtaining such approvals. The Contractor shall, at its
own cost and expense, facilitate all such approvals or renewals as may from time to
time be required to operate the mine, including appointment of consultants for
preparation of necessary reports for obtaining clearances, from the date of award of
contract.

2.2.

The obligations of the Contractor during the “Operations Stage” (as defined in Clause
3.1 (ii) below) shall include:
i)

The Contractor shall undertake mining & allied activities at the Project in strict
compliance with all applicable statutory rules/guidelines etc. Towards this, the
Contractor shall arrange, at his own cost, all required manpower, machinery, and
supervisory staff.

ii)

The Contractor shall be responsible for dispatch of the mineral from the Project for
which he/she has been appointed as the successful bidder.
a. The minimum dispatch shall not be less than 60% of the target monthly
production, which shall be derived by dividing the annual production as per the
Approved Mining Plan by 12 months.
Page 43 of 68

<!-- page 44 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

b. For arriving at the Annual Production, the 1st year as per Approved Mining Plan
shall be considered to begin from the “Commercial Operations Date” i.e., the
start of production of minerals.
iii) The Contractor shall pay the Consideration Amount every month for the actual
dispatches in that month or for a Minimum Dispatch as specified above in Cl.(ii),
whichever is higher.
iv) The Contractor shall be granted a “Gestation Period”, as referenced in Clause 3.1(ii)
(a) under Contract Period below, to mobilize resources, establish necessary
infrastructure, and commence mineral production.
v)

During Gestation Period, the minimum consideration clause shall not apply.

vi) The Contractor shall be designated as the authorized agent of the Project
(quarry/mine) and shall operate strictly in accordance with all applicable statutory
laws, regulations, and the terms and conditions of this Contract.
vii) The Contractor shall conduct quarry operations on scientific lines aiming for higher
percentage of recovery, ensuring efficient resource recovery and responsible waste
disposal, in accordance with statutory regulations and directions issued by the
Corporation.
viii) The Contractor shall dump the waste rock/over-burden at proper place(s) in
compliance with statutory provisions and Approved Mining Plan and as approved by
authorized official of the Corporation from time to time. If the dumping space is
patta land, the Contractor shall acquire the same at his own cost and its ownership
shall be transferred to the Corporation at the expiry of the Contract. Nonavailability of dumping space and delays in securing dumping space shall not be a
cause for non-payment of minimum monthly assured consideration as specified
under clause 6.3 below.
ix) All the manpower and machinery required to execute the works shall be arranged
by the Contractor at his cost. The Contractor shall amicably sort out any problems
caused by the local communities for execution of the work under this contract.
x)

All the statutory staff required shall be appointed by the Contractor at his cost and
keep the Corporation informed of such appointments and also termination of such
appointments.

xi) The Contractor shall inform APMDC regarding the number of skilled and un-skilled
workers employed and also machinery and equipment deployed, from time to time.
xii) The Contractor shall arrange and maintain all licenses required for mine operations,
including those for explosives, in compliance with applicable laws and regulations.

Page 44 of 68

<!-- page 45 -->

APMDC-13/5/2026-MRKTG-APMDC

3.

Contract period

3.1.

The entire Contract Term shall be divided into the following stages:

I/5112248/2026

i) Development Stage:
a) Commencement Date: "Commencement Date" shall mean the date of issuance
of the Letter of Award (LoA) to the Successful Bidder, following the completion
of the tender process.
b) Development Stage: “Development Stage” shall be the period of 360 days, from
and including the “Commencement Date” and till date of obtaining “Consent to
Operate (CTO)”. In case of any delay in obtaining the clearances due to reasons
beyond the control of the Contractor, APMDC reserves the right to extend the
duration of “Development Stage” by 90 days without any financial implication on
either side, based on reasons to be recorded in writing.
ii) Operations Stage:
a) Gestation Period: “Gestation Period” shall mean a period of 90 days, from &
including date of obtaining “Consent to Operate (CTO)” and till “Commercial
Operations Date”, which is defined as the date on which mineral production
begins following completion of the Gestation Period. In case of any delay due to
reasons beyond the control of the Contractor, APMDC reserves the right to
extend the Gestation Period by 90 days without any financial implication on
either side, based on reasons to be recorded in writing.
b) Commercial Operations Period: The Commercial Operations Period shall
commence on the “Commercial Operations Date" and shall continue until the
end of the Contract i.e., five (5) years from the Commencement Date, unless
extended/terminated as per the provisions of the Agreement.
3.2.

The RCSC contractor shall be appointed initially for a “Term” of 10 years from the date
of issue of Letter of Award (LoA) i.e., “Commencement Date”. The Term shall be further
divided into 10 “Contract Years”, with the 1st Contract Year starting from the
Commencement Date and valid for 12 calendar months from the 1st day of the month
in which LoA is issued.

3.3.

Upon successful completion of the initial 10 years Term, the contract may be extended
for an additional period of 5 years, subject to mutual agreement between the
Contractor and APMDC, at the sole discretion of APMDC.

3.4.

APMDC may issue a notice of suspension to the Contractor at any time during the
agreement directing to suspend all or any part of the operations, stating the estimated
length of and reason for the suspension. The Contractor shall, on receipt of a notice of
suspension, take all reasonable steps to immediately suspend all services.

4.

Milestones
Page 45 of 68

<!-- page 46 -->

APMDC-13/5/2026-MRKTG-APMDC

5.
5.1.

I/5112248/2026

Not Applicable
Scope of Work of APMDC
The Corporation shall arrange permits from the concerned authorities on receipt of
consideration amount as well as other statutory levies (like seignorage fee cess, DMF,
MERIT etc) from the Contractor.

6.

Payment of Consideration Amount:

6.1

The contractor shall pay the total Consideration Amount for a month based on the
actual despatch quantity of that month as certified by Project Officer (PO) or for the
minimum despatch quantity as per Cl. 2.2 (ii) under scope of work, whichever is higher.

6.2

The total consideration amount for every month shall be paid by the contractor before
15th of the immediate next month. The payments shall commence after conclusion of
the gestation period.

6.3

Monthly Minimum Consideration Amount shall be calculated as follows:
Monthly Minimum Consideration Amount = D X Cf
Where,
• D = Minimum assured despatches (refer clause 2.2 (ii) and 2.2 (iii))
• Cf = Consideration Amount (per MT) derived from the multiples of the Minimum
Consideration Amount as mentioned in the Letter of Award.

6.4

Consideration Amount shall be reconciled at the end of each “Contract Year”. The
Contractor would be permitted to make good of the shortfall of dispatches (and
payment of the consideration amount) in any calendar month, against higher than
minimum dispatch (and consequent payment of the consideration amount) delivered in
any other calendar month, within the same “Contract Year”.

6.5

Incase the contractor fails to make the payments to the corporation, within the
stipulated time, for three (3) months, the corporation shall have the right to terminate
the contract as per clause (13) “Failure and Termination” and forfeit the Performance
Security Deposit (PSD) by giving one (1) month notice.

6.6

All the statutory payments like Dead-rent and seigniorage fee whichever is higher, DMF,
MERIT etc., and any other taxes/levies that may be levied from time to time shall be
paid by the Contractor to the Corporation as per the payment schedule fixed by the
Government.

6.7

All the other documents and arrangements for transportation inclusive of loading at
Project shall be arranged by the Contractor at his cost.

6.8

Mode of Payment: The Consideration Amount shall be payable to the Corporation's
designated bank account via online transfer through NEFT/RTGS. Bank account details
Page 46 of 68

<!-- page 47 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

will be communicated to the Contractor after signing of the Agreement.
6.9

7

For any mineral, in the event that the State Government issues any orders/notifications
to collect Seigniorage Fee on a per cubic meter basis instead of the prevailing policy i.e.,
per metric ton basis, the Consideration Amount (in Rs per MT) finalized through the
tender shall be converted into Consideration Amount (in Rs per CBM), as per the
conversion factor for such mineral prescribed by the Mines Department, GoAP.
The Contractor shall hereby undertakes to comply and adopt any such revision in the
Consideration Amount and deposit Monthly Consideration Amounts accordingly.
Revision on Consideration Amount

7.1

The rates agreed upon and incorporated into the Contract(s) after finalization shall
remain valid from the Commercial Operations Date till the completion of the 2 nd
Contract Year from the date of issuance of LoA (i.e. Commencement Date). Thereafter,
the Consideration Amount shall be subject to 5% Year-on-Year escalation on annual
basis.

7.2

In any case, the 1st escalation shall be made effective not later than the 1 st day of 3rd
Contract Year, notwithstanding any delay in Commercial Operations Date.

7.3

Each subsequent annual escalation shall be applicable after completion of the Contract
Year.
8
Taxes & Duties
8.1
Indirect Taxes
A) The Contractor agrees to and, hereby accepts full and exclusive liability for payment of
any and all taxes, duties, charges and levies as per the Applicable Laws as applicable for
the Scope of Supply in accordance with the provisions of this Agreement.
B) The Contractor shall be liable to bear any direct and indirect taxes, GST tax, duties, fees,
cess, surcharge, levies and other impositions levied under Applicable Law, save that
each party shall be liable to bear its own income taxes and all payments shall be subject
to tax to be deducted at source.
8.2
Direct Taxes
TDS as applicable shall be deducted (if applicable) under Income Tax Act,1961 and
certificate of deduction shall be provided by APMDC to the Contractor in accordance
with the provisions of Income Tax Act,1961.
9
Failure to pay Consideration Amount
9.1
In the event of failure of the Contractor to pay consideration amount(s) as per the
contract
A) The Corporation shall be at liberty to suspend further operations at its Project as
measure of penalty by serving 7 days’ notice till considerations received without
prejudice to its right under clause 13.1. Such suspension of the work by the
Page 47 of 68

<!-- page 48 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Corporation does not absolve the Contractor of his contractual obligation to pay
minimum consideration for the period(s) of suspension and subsequent month on
the plea that production could not be raised due to suspension of the work by the
Corporation.
B) The Corporation also reserves the right to restrain the Contractor to remove the
machinery and equipment till realization of the dues payable to the Corporation.
C) In case the Minimum Monthly Consideration Amount is not paid by the contractor
for 3 (Three) months, the Corporation shall have the right to terminate the contract
under clause 13.1. forfeiting performance security deposit, by giving one month
notice.

10
10.1

10.2

11
11.1

12
12.1

13
13.1

D) However, this clause will not apply if failure had resulted from stopping of Project
operation due to Force Majeure, as per clause 14.1 (under General Conditions of
Contract – Annexure 1) or Government intervention.
Ownership of material at expiration or sooner determination of contract
It is clarified that at the expiration or sooner determination of the contract, the material
that were not despatched from the Project shall be the sole property of the Corporation
and the Corporation shall have the right to sell them at any price to any buyer.
At the expiration or sooner determination of the contract and in the event the
contractor is in dues to the Corporation, the Corporation shall have the right to adjust
the amount from the Performance Security Deposit against such dues from the
Contractor.
Delivery of Project in good order to the Corporation
The Contractor shall at the expiration or sooner determination of the contract deliver to
the Corporation all pits in good order and fit in all respect for further working of the said
Project and the said mineral. In case of Non-compliance of this condition, the
corporation reserves the right to forfeit the Performance Security Deposit.
Losses on account of theft
The Contractor shall be responsible for any damages or losses on account of theft of the
Mineral from the Project and shall reimburse such losses to the Corporation. Theft,
pilferage, unauthorized removal, or illegal transportation of mineral shall be strictly
prevented by the Contractor through adequate security, surveillance, and access-control
measures. Any unaccounted loss shall be deemed a contractual breach, and the full
value of the missing material shall be recovered.
Failure and Termination
The Corporation reserves the right to terminate the contract at any time forfeiting the
Performance Security Deposit due to unsatisfactory performance of the contract like
failure to make payments as stipulated under clause 6.5 of this Contract, failure to
achieve the targets, unscientific quarrying and intentionally spoiling the material not
lifted by the Contractor and failure to comply with the instruction of the Corporation in
the Project operation etc.
Page 48 of 68

<!-- page 49 -->

APMDC-13/5/2026-MRKTG-APMDC

13.2

13.3
13.4

13.5

I/5112248/2026

If the Corporation authorities are required to terminate the contract on account of any
violation of terms and conditions/default or breach of contract, by giving one month
notice and the Contractor shall be liable for all losses/damages caused due to such
termination, including forfeiture of PSD.
In the event of termination of the contract by the Corporation, the Corporation is not
liable for any consequential losses/damages caused to the Contractor.
Termination due to Force Majeure:
If a delay or failure by the Contractor to perform its obligations due to Force Majeure
exceeds 3 (three) continuous months, the APMDC may terminate this Agreement by
giving 1 month notice in writing to the Contractor. In case of termination of Agreement
due to Force Majeure, the Performance Bank Guarantee shall be returned to the
Contractor.
Termination on exhaustion of Mineral Reserves:
The Agreement shall terminate upon it being established to a high degree of certainty
through established procedure used in accordance with Good Industry Practices that
Mineral Reserves at the Project have been exhausted.

14
14.1
14.2

14.3

15

16

Compliance with statutes
The Contractor shall comply with all the relevant laws applicable in respect of this
contract and shall be solely responsible for such compliance
The contractor shall comply with all relevant provisions of the Mines Act, 1952, Mines
and Minerals (Regulation) and (Development) Act, 1957, Maternity Benefit Act 1961,
Payment of wages (Mines) Act, 1936, Minimum Wages Act,1948, Payment of Bonus Act,
1965, payment of Gratuity Act 1972, Workmen Compensation Act, 1923 Contract
Labour (Regulation and Abolition) Act, 1970 Employees Provident Fund Act, 1952,
Employment Exchange (compulsory notification of vacancies) Act, 1959, Industrial
Disputes Act, 1947, Rules and Regulations framed under the above mentioned Acts and
any amendments that might be notified from time to time.
The Contractor shall rectify violations, if any, pointed out by any Statutory Authority
within the stipulated time at his risk and cost. In case the violations are not rectified by
the Contractor within the stipulated time, the Corporation shall rectify such violations
and recover the cost incurred by it from the Contractor.
Indemnity Against Accidents:
The Contractor is responsible for any type of accident whether major/minor in nature
occurring during performance of the contract/work. He shall be responsible for payment
of compensation as per statutory requirements and shall keep the Corporation fully
indemnified in this regard.
Policy of Govt./Closure of mine
Page 49 of 68

<!-- page 50 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

The performance of this contract is subject to policy of the Government (State/Central)
from time to time. The Contractor shall abide by such policy of the Government from
time to time. In the event of non-performance of the contract or termination of the
contract due to Government policy/orders at any time or court orders or closure of the
Project by the Corporation, the Contractor shall not be entitled for any claims/
damages/ losses / compensation whatsoever.
17

Insurance
Insurance cover for the men and machinery employed by the Contractor and for
material losses, damages and shortages should be borne by the Contractor only. The
Contractor shall keep the Corporation fully indemnified in this regard.

Page 50 of 68

<!-- page 51 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 3: Format for Power of Attorney
(to be executed on INR 100 non-judicial stamp paper and to be duly notarized)
Known all men by these presents, we…………………………………………….. (name of the Bidder and
address of the registered office) do hereby irrevocably constitute, nominate, appoint and
authorize Mr./ Ms. (name), …………………… son/daughter/wife of ……………………………… and
presently residing at …………………., who is presently employed with us and holding the position
of ……………………………. , as our true and lawful attorney (hereinafter referred to as the
“Attorney”) to do in our name and on our behalf, all such acts, deeds and things as are
necessary or required in connection with or incidental to submission of our tender against the
Bid document no. ………… dated ………… published by The APMDC Ltd. for the “…………”, including
but not limited to signing and submission of all applications, bids and other documents and
writings,
AND we hereby agree to ratify and confirm and do hereby ratify and confirm all acts, deeds and
things done or caused to be done by our said Attorney pursuant to and in exercise of the
powers conferred by this Power of Attorney and that all acts, deeds and things done by our said
Attorney in exercise of the powers hereby conferred shall and shall always be deemed to have
been done by us.
[AND we hereby confirm we do not have a common seal and therefore no common seal is
required to be affixed hereto per applicable laws.]*
IN WITNESS WHEREOF WE,…………………………., THE ABOVE NAMED PRINCIPAL, HAVE EXECUTED
THIS POWER OF ATTORNEY ON THIS ……… DAY OF …………. 20[•].
For

Witnesses

…………………………………………………………………..
(Signature, name, designation and address)

1.

2.
Accepted

(Signature)
(Name, Title and Address of the Attorney)
* To be deleted if the company seal is duly affixed to the power of attorney.

Page 51 of 68

<!-- page 52 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 4: Price Bid Format
Tender No: APMDC/P&C/Color Granite quarry leases Tran-9/2026-27/I, Dated 05.10.2026
Consideration Amount as per tender terms and conditions, exclusive of statutory levies, like
Seigniorage fee, DMF, MERIT, Cess, GST etc :

S.No. Schedul
e

Offices

Exten
Mineral t (in
Hect.)

Village

Mandal

1

Schedule Puttaparthy
-306
SSS

Color
Granite

4.95

Bonthalapalli

Tanakallu

2

Schedule Puttaparthy
-307
SSS

Color
Granite

4.366 Daduvaripalli

Tanakallu

3

Schedule Puttaparthy
-308
SSS

Color
Granite
(Others)

6

Ethodu

Tanakallu

4

Schedule Puttaparthy
-309
SSS

Color
Granite

5

Ethodu

Tanakallu

5

Schedule Puttaparthy
-310
SSS

Color
Granite

6

Ethodu

Tanakallu

6

Schedule Puttaparthy
-311
SSS

Color
Granite

4.954

Kokkanti

Tanakallu

7

Schedule
YSR Kadapa
-312

Color
Granite

8.634

Kuppam

Chakrayapet

8

Schedule Puttaparthy
-313
SSS

Color
Granite

4.9

Allapalli

O.D.Cheruvu

9

Schedule Puttaparthy
-314
SSS

Color
Granite

4.9

Allapalli

O.D.Cheruvu

10

Schedule Puttaparthy
-315
SSS

Color
Granite

4.9

Allapalli

O.D.Cheruvu

Bidder
Proposed
Considerat quoted rate
exclusive of
ion
statutory
Amount
levies,
like
exclusive
Seigniorage
of
fee, DMF,
statutory
MERIT,
levies, like
Cess, GST
Seigniorag
etc
e fee,
DMF,
* Bidder
MERIT,
quoted their
Cess, GST rate over and
etc
above for the
said
consideration
amount

Note:
 Bidders may submit bids for one or more schedules at their discretion, with separate
Page 52 of 68

<!-- page 53 -->

APMDC-13/5/2026-MRKTG-APMDC



Sl. No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14








I/5112248/2026

Price Bids submitted for each schedule. The rates quoted for different schedules need
not be the same and may vary from schedule to schedule.
Refer to the below table for Mineral-wise Minimum Consideration Amounts:
Mineral
Black Galaxy Granite
Black Granite
Color Granite (Srikakulam Blue)
Color Granite (Kashmir White)
Color Granite (Leptynite)
Color Granite (Others)
Road Metal / Ballast / Building Stone
Ordinary Earth / Morrum / Gravel
Dolomite
Calcite
Mosaic Chips
Pyrophyllite
Quartzite
Dimensional Stones

Proposed Min. Consideration
Amount (CA) (₹)
2,100
1,500
1,500
1,500
1,500
800
105
55
130
180
630
180
260
400

The bidders shall be specifically required to quote their rates/amount over and
above for the said consideration amount.
The rates quoted shall be exclusive of statutory levies, like Seigniorage fee, DMF,
MERIT, Cess, GST etc.
The quoted price multiple shall be applied individually to the Minimum Consideration
Amount per Metric Tonne of each mineral to determine the final payable amount per
tonne for each mineral. In the unforeseen circumstance where any mineral other
than those mentioned above is to be despatched from the Project, the same quoted
price multiple shall be applied to the latest approved Minimum Consideration
Amount per Metric Tonne of such mineral.
The scanned PDF copy of the duly filled in Financial Bid Format (Annexure 4) needs to
be uploaded online along with the financial bid on the e-procurement portal.
The Commercial Bid should not be submitted offline or uploaded along with the
Technical Bid documents. Non-adherence to this could lead to dis-qualification.
Due to an inadvertent error in the e-Procurement Portal Price Bid format, the
Department shall consider the Price Bid submitted by the bidder as an attached
Annexure document for evaluation and finalization, subject to the tender terms and
conditions
(Authorized Signatory of the
Bidder with Seal)
DATE:
Ph No.

Page 53 of 68

<!-- page 54 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 5: Declaration against Blacklisting
(to be executed on letterhead of the bidder)
Date:______________
Sub: Tender No. ______________________
In response to the Tender Document above stated, I/We hereby declare and solemnly swear
that our Company/firm ___________________ is not banned/blacklisted as on date by any
competent court of Law, forum or any State Government or Central Government or their
agencies or by any statutory entities or any PSUs.
AND, if at any stage the declaration/statement on oath is found to be false in part or otherwise,
then without prejudice to any other action that may be taken, I/We, hereby agree to be treated
as a disqualified Bidder for the ongoing Contract.
In addition to the disqualification our concern/entity may be banned/blacklisted.
AND, that I/We, shall have no right whatsoever, to claim for consideration of my/our bid at any
stage and the money deposited in the form of EMD shall be liable for forfeiture in full, and the
tender, if any to the extent accepted may be cancelled.
Signature of the Deponent
(Authorized signatory of the Bidder with Seal)
Date:
Place:

Page 54 of 68

<!-- page 55 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 6: Check-list for the Technical Bid
(to be enclosed with the Technical Bid)
1. Name of the Bidder, Postal address & Registered Office:
2. Type of organization:
3. Contact name & designation of the Authorized Signatory of the Bidder & contact number:
4. Official email, phone, fax:
5. Official website:
Sl. No.
1

Qualification Requirement
Bidder’s Experience – Documents in support of
meeting Eligibility Criteria (Refer Chapter 7)

2

Proof of payment of Tender Document Fee

3

Proof of payment of EMD

4

Power of Attorney - Annexure 3

5

Declaration against blacklisting - Annexure 5

6

Signed copy of check list with seal - Annexure 6

7

Format for Financial Criteria – Annexure 9

8

Any other required documents

Date

Complied

Documents

Signature of the Authorized Signatory of the Bidder with Seal

Page 55 of 68

<!-- page 56 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 7: Proforma of the Agreement to be Signed between APMDC
and the Successful Bidder
Ref: [•]
This Raising-cum-Sale-Contract for Quarry Lease of (Mineral Name) over an extent of [•] Ha in
(Village Name) Village, (Mandal Name) Mandal, (District Name) Dist. Andhra Pradesh
(hereinafter called the “Agreement”) is made on this [•] day of [month], [year].
BETWEEN
The APMDC, represented by Sri <<insert name>>,<<insert designation>> and having its
corporate office at Door No. 294/1D, 100 feet Road (Tadigadapa to Enikepadu Road), Kanuru,
Vijayawada-521137 (hereinafter referred to as “APMDC”, which expression shall, unless
repugnant to or inconsistent with the context, mean and include its successors and permitted
assigns) of the first part.
AND
M/s. [•], an Indian National/Proprietorship/Partnership Firm/Company, incorporated under [•],
represented by Sri <<insert name>>,<<insert designation>> and having its registered office at
[•] (hereinafter referred to as the “Contractor” which expression shall unless repugnant to or
inconsistent with the context, mean and include its successors and permitted assigns) of the
other part.
The APMDC and the Contractor are collectively referred to as the "Parties" and individually as a
"Party".
WHEREAS
i)
APMDC has been granted the Letter of Intent (LoI) No. [•] dated [•] by the State
Government of Andhra Pradesh for Quarry Lease of (Mineral Name) over an extent of
[•] Ha in (Village Name) Village, (Mandal Name) Mandal, (District Name) Dist. Andhra
Pradesh.
ii)

Contractor have submitted their bid against APMDC’s Bid document No. [•] dated [•]
(hereinafter called the “Tender” or “RFP”) for Selection of Agency for Working the
above-mentioned quarry lease on Raising-Cum-Sale Contract basis;

iii)

On the basis of the said Tender, APMDC has adjudged the Contractor as a Preferred
Bidder and issued Letter of Award (LoA) No. [•] dated [•] for the same;

iv)

the Contractor has agreed through their letter of acknowledgement vide letter No. [•]
dated [•] to perform and undertake the scope of work as described in the Tender.
Furthermore, the Contractor has submitted the Performance Security Deposit (PSD) in
the form of a Bank Guarantee amounting to Rs. [•], bearing BG Number [•], dated [•]

Page 56 of 68

<!-- page 57 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

v)

the Contractor is being engaged to provide the required services on the terms and
conditions set forth in this Agreement;

vi)

Both the parties have agreed to enter into the Agreement to set out the mutually
agreed terms and conditions for the Raising-cum-Sale-Contract for Quarry Lease of
(Mineral Name) over an extent of [•] Ha in (Village Name) Village, (Mandal Name)
Mandal, (District Name) Dist. Andhra Pradesh with respective rights, obligations,
performances and other terms and conditions as set out in the RFP and incorporated in
this Agreement.

NOW THEREFORE THE PARTIES hereby agree as follows:
1. The mutual rights and obligations of the Contractor and APMDC shall be as set forth in
this Agreement.
2. The following documents shall constitute the Agreement between APMDC and the
Contractor, and each shall be read and construed as an integral part of the Agreement:
(i) Agreement
(ii) Letter of Acceptance
(iii) The RFP document and any corrigendum (a)/ clarification(s) issued by APMDC to
the Bidding Documents. For the avoidance of doubt, any corrigendum(a)
/amendment(s)
issued
later
shall
prevail
over
the
earlier
corrigendum/amendment
(iv) Bid proposal submitted by the Contractor together with additional documents /
clarifications, if any.

a) All documents forming part of the Agreement (and all parts thereof) are intended to
be correlative, complementary and mutually explanatory. The Agreement shall be
read as a whole. However, in case of any ambiguity or conflict between the
documents listed above at Clause 2, the order of precedence shall be the order in
which the documents are listed in Clause 2.
3. Conditions of Contract
(a) All the terms and conditions as per the Bid document No. [•] dated [•] (including the
General Conditions of Contract and Special Conditions of Contract) shall be
applicable for this Agreement
(b) Contract Period: The contract shall be in force for a period of 10 years from the date
of issue of Letter of Award i.e., from [•] to [•]. Upon successful completion of the
initial 10 years Term, the contract may be extended for an additional period of 5
years, subject to mutual agreement between the Contractor and APMDC, at the sole
discretion of APMDC.
(c) Payment Terms:

Page 57 of 68

<!-- page 58 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

i.

The Consideration Amount per unit for (Mineral Name) is Rs. [•] per
metric ton (MT), as agreed by the Contractor.

ii.

The above-mentioned Consideration Amount shall remain valid from the
Commercial Operations Date till the completion of the 2 nd Contract Year.
Thereafter, the Consideration Amount shall be subject to 5% Year-onYear escalation on annual basis.

iii.

For each month, the Contractor shall pay the total Consideration
Amount, calculated by multiplying the Consideration Amount per unit
with either the actual despatch quantity certified by the Project Officer
(PO) or the Minimum Despatch quantity, whichever is higher.

iv.

The Consideration Amount shall be paid by the Contractor on or before
the 15th day of the following month.

(d)

<Other important terms and conditions may be included>

(e)

The Agreement shall be governed by the laws of India and the courts of
Vijayawada shall have exclusive jurisdiction over all disputes arising under,
pursuant to and/or in connection with this Agreement

(f)

This Agreement has been executed in English, which shall be the binding and
controlling language for all matters relating to the meaning or interpretation of
this Agreement
IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed by their
respective authorized representatives on the day and year first before written.
For and on behalf of APMDC
(Authorized Representative)
Name:
Designation:
In presence of the following witnesses

For and on behalf of M/s.
(Authorized Signatory)
Name:
Designation:

Name:
Designation:

Name:
Designation:

Page 58 of 68

<!-- page 59 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 8: Format for Performance Security
BG should be obtained from a Nationalized/Scheduled Commercial Bank, owned by
Central/State Govt. in India and should be operable and invokable at its Branch in Vijayawada
(To be executed on INR 100/- non-judicial stamp paper)
Bank Guarantee
Bank Guarantee. No.
Date:
To
The Vice Chairman & Managing Director,
A P Mineral Development Corporation Ltd,
294/ 1D, Tadigadapa to Enikepadu 100 ft. Road, Kanuru Village,
Penamaluru Mandal,Vijayawada - 521137, Andhra Pradesh.
In consideration of APMDC (hereinafter referred to as ‘APMDC’, which expression shall unless
repugnant to the context or meaning thereof, include its successors, administrators and
assigns) having issued a Letter of Award to M/s [Name of the Successful Bidder] having its
registered office/Head Office at [address of registered/head office] [herein after referred to as
the "Contractor" which expression shall unless repugnant to the context or meaning thereof,
include its successors, administrators and permitted assigns] vide LoA No. …………. dated
…………… for Raising-cum-Sale-Contract for Quarry Lease of (Mineral Name) over an extent of [•]
Ha in (Village Name) Village, (Mandal Name) Mandal, (District Name) Dist. Andhra Pradesh and
M/s [Name of the Successful Bidder] having agreed to provide a Performance Security in the
form of an unconditional and irrevocable bank guarantee for the due performance of the entire
Agreement for an amount equal to Indian Rs. ------**-------- (Indian Rupees ------** ) initially for a
period of [period of performance bank guarantee].
We, [name of the bank], having its Head office at [address of the head office], (hereinafter
referred to as the "Bank" which expression shall, unless repugnant to the context or meaning
thereof, include its successors, administrators, executors and assigns) at the request of the
Contractor do hereby undertake to pay to the APMDC an amount not exceeding INR [figures]
(Indian Rupees [words]) to secure the obligations of the Contractor under the Agreement on
demand from the Employer on the terms and conditions herein contained herein.
NOW THEREFORE, the Bank hereby issues in favour of the APMDC this irrevocable and
unconditional payment bank guarantee (the “Guarantee”) on behalf of the Contractor in the
amount INR [figures] (Indian Rupees [words]).
1. The Bank for the purpose hereof unconditionally and irrevocably undertakes to pay to the
APMDC without any demur, reservation, caveat, protest or recourse, immediately on
receipt of first written demand from the APMDC, a sum or sums (by way of one or more
claims) not exceeding in the aggregate the amount of INR [figures] (Indian Rupees [words])
without the APMDC needing to prove or to show to the Bank grounds or reasons for such
demand for the sum specified therein and notwithstanding any dispute or difference
between the APMDC and Contractor on any matter whatsoever. The Bank undertakes to
pay to the APMDC any money so demanded notwithstanding any dispute or disputes raised
Page 59 of 68

<!-- page 60 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

by the Contractor in any suit or proceeding pending before any court or tribunal relating
thereto the Bank’s liability under this present being absolute and unequivocal.
2. The Bank acknowledges that any such demand by the APMDC of the amounts payable by
the Bank to the APMDC shall be final, binding and conclusive evidence in respect of the
amounts payable by Contractor to the APMDC under the Agreement.
3. The Bank hereby waives the necessity for the APMDC from demanding the aforesaid
amount or any part thereof from the Contractor and also waives any right that the Bank
may have of first requiring the APMDC to pursue its legal remedies against the Contractor,
before presenting any written demand to the Bank for payment under this Guarantee.
4. The Bank further unconditionally agrees with the APMDC that the APMDC shall be at liberty,
without the Bank’s consent and without affecting in any manner the Bank’s obligation
under this Guarantee, from time to time to:
i. vary and/or modify and of the terms and conditions of the Agreement
ii. extend and / or postpone the time for performance of the obligations of the Contractor
under the Agreement, or
iii. forbear or enforce any of the rights exercisable by the APMDC against the Contractor
under the terms and conditions of the Agreement and the Bank shall not be relieved
from its liability by reason of any such act or omission on the part of the APMDC or any
indulgence by the APMDC to the Contractor or other thing whatsoever which under the
law relating to sureties would, but for this provision, have the effect of relieving the
Bank of its obligations under this Guarantee.
5. Any payment made hereunder shall be made free and clear of and without deduction for,
or on account of, any present or future taxes, levies, imposts, duties, charges, fees,
commissions, deductions or withholdings of any nature whatsoever and by whom ever
imposed; and where any withholding on a payment is required by law, the Bank shall
comply with such withholding obligations and shall pay such additional amount in respect
of such payment such that the APMDC receives the full amount due hereunder as if no such
withholding had occurred. It is clarified that even in such case the obligation of the Bank
shall not in any manner exceed in the aggregate the amount of INR [figures] (Indian Rupees
[words]).
6. The Bank agrees that APMDC at its option shall be entitled to enforce this Guarantee
against the Bank, as a principal debtor in the first instance without proceeding at the first
instance against the Contractor
7. The Bank further agree that the guarantee herein contained shall remain in full force and
effect during the period that specified in the Agreement and that it shall continue to be
enforceable till all the obligations of the Contractor under or by virtue of the said
Agreement with respect to the Performance Security have been fully paid and its claims
satisfied or discharged or till the APMDC certifies that the terms and conditions of the
Page 60 of 68

<!-- page 61 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Agreement with respect to the Performance Security have been fully and properly carried
out by the Contractor and accordingly discharges this guarantee. Any claim under this
Guarantee must be received by us before the expiry of the extended period. The Bank shall
be discharged from all liability under this guarantee thereafter.
8. The payment so made by the Bank under this Guarantee shall be a valid discharge of Bank’s
liability for payment thereunder and the APMDC shall have no claim against the Bank for
making such payment.
9. This Guarantee is subject to the laws of India. Any suit, action, or other proceedings arising
out of this Guarantee or the subject matter hereof shall be subject to the exclusive
jurisdiction of courts of Vijayawada, Andhra Pradesh.
10. The Bank has the power to issue this Guarantee in favour of the APMDC. This guarantee will
not be discharged due to the change in the constitution of the Bank.
11. The Bank undertakes not to revoke this Guarantee during its currency except with the
previous consent of the APMDC in writing.
12. The APMDC may, with prior intimation to the Bank, assign the right under this Guarantee to
any other departments, ministries or any governmental agencies, which may act in the
name of the Government of Andhra Pradesh. The APMDC may also assign this Guarantee in
favour of the Governor of a State, with prior intimation to the Bank. Save as provided in this
Clause 12, this Guarantee shall not be assignable or transferable.
13. This bank guarantee is also encashable at our (VIJAYAWADA BRANCH ADDRESS).
Notwithstanding anything contained hereinabove our liability under this Guarantee is
restricted to Indian Rs.----- **-------- (Indian Rupees --------**--------- only) and shall remain in
force up to and including the claim period of 1 year i.e., ……@…. (the date) and shall be
extended from time to time for the period, as may be desired by M/s ........................... (the
Contractor) on whose behalf this guarantee has been given.
We shall be released and discharged from all liability under this Guarantee unless a written
demand made in the manner prescribed in this Guarantee is issued to the Bank on or before
……@…. (the date), failing which our liability under the Guarantee will automatically cease,
irrespective of whether the original Guarantee has been returned to us or not.
Dated the [day] day of [month] [year] for the Bank.
In witness whereof the Bank, through its authorized officer, has set its hand and stamp.
(Signature)
(Name and Designation)
(Bank Stamp)

Page 61 of 68

<!-- page 62 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 9: Format for Financial Criteria
<<On the letterhead of the Statutory Auditor/Independent Chartered Accountant >>
A. Net-worth (In INR Crores) as on 31.03.2026
Name of the Bidder
Net-worth as on date 31.03.2026
Subscribed and Paid-up Equity
Reserves
Revaluation reserves
Miscellaneous expenditure not
written off
Reserves not available for
distribution to equity shareholders
Total Net worth (1+2-3-4-5)
Name of the Audit Firm/Chartered Accountant:
Registration Number of the Audit Firm:
UDIN:
Seal of the Audit Firm:

(Signature, Name and Designation of the
Authorized Signatory)
Date:

Note:
1. Net Worth shall mean (Subscribed and Paid-up Equity + Reserves) less (Revaluation
reserves + miscellaneous expenditure not written off + reserves not available for
distribution to equity shareholders).
2. The Statutory Auditor/Independent Chartered Accountant of the Bidder should certify
the Net worth table as mentioned above in point A.

Page 62 of 68

<!-- page 63 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 10: Format for Submission of Pre-Bid Queries

S.No.

Clause ref no. and
Page no.

Existing
Provision

Clarification
Sought/Suggested
amendments

Rationale for
Clarification or
Amendment

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.

Page 63 of 68

<!-- page 64 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 11: Format for Affidavit of Sole Proprietorship
<< Must be sworn before a Notary Public & printed on non-judicial stamp paper of the appropriate value
as per local regulations>>

On this day, the ______ day of ___________ 20__, I, ____________________________ (Name
of Proprietor), S/o/D/o/W/o Shri ____________________________, resident of
______________________________________________________________________________
_____________________________, do hereby solemnly affirm and declare as under:
1. That I am the lawful and sole proprietor of the business operating under the name and style of
M/s. __________________________________.
2. That
the
said
proprietorship
business
is
located
at
__________________________________________________ (Business Address).
3. That the business was established on or about [Date of Establishment], and I have been
continuously operating it since then.
4. That I am the sole owner of all assets, equipment, and properties used in the business
operations of M/s. __________________________________.
5. That the business operates solely under my name, and I have not formed any partnership, joint
venture, or any other association with any other individual or entity.
6. That I am solely responsible for all financial transactions, liabilities, and obligations incurred by
the proprietorship concern.
7. That I make this affidavit to attest to my status as the sole proprietor of M/s.
___________________ and to confirm that this business is not a partnership firm or a
company.
8. That the contents of this affidavit are true and correct to the best of my knowledge and belief,
and nothing has been concealed therefrom.
DEPONENT
(Signature of Proprietor)
VERIFICATION
ATTESTED BY:
(Notary Public/Oath Commissioner) (With Official Stamp and Seal)

Page 64 of 68

<!-- page 65 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 12: Format of Bank Guarantee for EMD
(To be stamped in accordance with the Stamp Act, if any, of the Country of the Issuing Bank)
Bank Guarantee No.……………………………..
Date ………………………..
To:
APMDC Ltd.
Door No. 294/1D, 100 feet Road (Tadigadapa to Enikepadu Road),
Kanuru, Vijayawada – 521137, Andhra Pradesh, India
Dear Sirs,
In accordance with Invitation for Request for Proposal under your Document No.
……………………………………, M/s ………………………………………………. having
its
Registered
office/Head Office at …………………………………….. (hereinafter called the "Bidder") wish to
participate in the said bidding for ……………………………………...
As an irrevocable bank guarantee against Earnest Money Deposit for an amount of INR
[figures] valid for ………..*………. Days from ……………. (**)………..required to be submitted by the
Bidder as a condition precedent for participation in the said bidding which amounts is liable to
be forfeited on the happening of any contingencies mentioned in the RFP Documents.
We, the ……………………………………………………. (Name & address of the Bank) having our Head
Office at …………………………………………………(#)guarantee and undertake to pay immediately on
demand by APMDC the amount INR [figures] without any reservation, protest, demand and
recourse. Any such demand made by APMDC shall be conclusive and binding on us
irrespective of any dispute or difference raised by the Bidder.
This guarantee shall be irrevocable and shall remain valid up to …… (*).…… If any further
extension of this guarantee is required, the same shall be extended to such required period
(not exceeding one year at a stretch) on receiving instructions from M/s
……………………………………………… Bidder name) on whose behalf this guarantee is issued.
This Bank Guarantee is encashable at our Vijayawada
(Full Branch Address to be provided by the issuing Bank).

Branch

located

at:

In witness where of the Bank, through its authorised officer, has set its hand and stamp on this
……………………….. day of ……………………20[•] at……………………………..
(Signature, Name and
Designation with Bank Stamp)
Authorised Vide Power
Attorney No….. Date…….

of

NOTE:
Page 65 of 68

<!-- page 66 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

1.

(*) This shall be valid 180 days beyond the Bid Due Date in accordance with Clause
8.7. (**)This shall be the date of opening of Technical Bid.
(#) Complete mailing address of the Head office of the Bank to be given

2.

The Bank Guarantee shall be from a scheduled list of banks.

3.

The BG should be on Non-Judicial stamp paper/e-stamp paper of appropriate value as
per Stamp Act prevailing in the State(s) where the BG is submitted or is to be acted
upon or the rate prevailing in the State where the BG is executed, whichever is
higher. The Stamp Paper/e-Stamp paper shall be purchased in the name of
Bidder/Bank issuing the guarantee.

4.

The Name and Designation of the Officer of the Bank executing the BG and his Power of
Attorney/Signing Power No. should be duly indicated in the BG. Each page of the BG
should be duly signed/initialed by the executants and Stamp of the Bank to be affixed
thereon.

Page 66 of 68

<!-- page 67 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 13: Schedules with Specifications of Mineral Blocks
Schedule
No.
306
307
308
309
310
311
312
313
314
315

Offices
Puttaparthy
SSS
Puttaparthy
SSS
Puttaparthy
SSS
Puttaparthy
SSS
Puttaparthy
SSS
Puttaparthy
SSS
YSR Kadapa
Puttaparthy
SSS
Puttaparthy
SSS
Puttaparthy
SSS

Mineral

Extent
(in Hect.)

Village

Mandal

Survey No.

EMD
(in Rs.)

PSD
(in Rs.)

Color Granite

4.95

Bonthalapalli

Tanakallu

966/P

25,00,000

61,39,497

Color Granite

4.366

Daduvaripalli

Tanakallu

164 Part

25,00,000

64,66,200

Color Granite
(Others)

6

Ethodu

Tanakallu

84

25,00,000

1,39,15,330

Color Granite

5

Ethodu

Tanakallu

84

24,39,450

48,78,900

Color Granite

6

Ethodu

Tanakallu

84

25,00,000

1,50,41,520

Color Granite

4.954

Kokkanti

Tanakallu

1730

25,00,000

1,58,61,560

Color Granite

8.634

Kuppam

Chakrayapet

814/P

25,00,000

2,00,00,000

Color Granite

4.9

Allapalli

O.D.Cheruvu

75

25,00,000

2,00,00,000

Color Granite

4.9

Allapalli

O.D.Cheruvu

75

25,00,000

1,47,69,240

Color Granite

4.9

Allapalli

O.D.Cheruvu

75

25,00,000

2,00,00,000

Page 67 of 68

<!-- page 68 -->

APMDC-13/5/2026-MRKTG-APMDC

I/5112248/2026

Annexure 14: Details of the Mineral Block
<< Letter of Intent (LOI/)/Memo issued by State Government, containing relevant
details of the mineral block to be enclosed separately for kind reference. >>

Page 68 of 68
