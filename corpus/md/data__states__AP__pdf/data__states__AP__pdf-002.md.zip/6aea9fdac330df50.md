---
doc_id: "6aea9fdac330df50"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0f6fc4bc18b2e88d"
---

<!-- page 1 -->

GOVERNMENT OF ANDHRA PRADESH
ABSTRACT
MINES & QUARRIES – Promotion of Manufactured Sand in place of River
Sand in construction activity - Manufactured Sand Policy-2016 – Orders
– Issued.
------------------------------------------------------------------------------INDUSTRIES AND COMMERCE (MINES-II) DEPARTMENT
G.O.Ms.No.38

Date:17-03-2016.
Read the following:

1) DM&G Letter No. 3337/P/2014, dt:27.10.2015.
2) G.O.Ms.No. 19, Ind. & Com.(M.II) Dept., dt: 15.01.16.
3) G.O.Ms.No. 20, Ind. & Com.(M.II) Dept., dt: 15.01.16.
4) G.O.Ms.No.53, Ind. & Com.(Prog-I) Dept., Dt: 23-07-2015.
*****
Order:In the reference 1st read above, the Director of Mines & Geology,
Hyderabad submitted the proposal for issuance of a Policy to promote the
development of Manufactured Sand industries since the Manufactured Sand
(M-Sand) is an alternative to the River Sand in construction activity in view
of the increase in demand of sand for domestic consumption as well as the
scarcity of River Sand.
2.
In the G.O 2nd and 3rd read above, the Government committed to
encourage Manufactured Sand as an alternative to River Sand in order to
conserve River Sand in the State.
3.
Hence, the present policy for promoting Manufactured Sand
industries in the State to utilize Manufactured Sand in place of River Sand
in construction activity is issued.
MANUFACTURED SAND POLICY – 2016
A) PREAMBLE
a) Rivers, Forests, Minerals and such other resources constitute a
Nation’s natural wealth. These resources are not to be frittered away
and exhausted by any one generation. Every generation owes a duty
to succeeding generations to develop and conserve the natural
resources of the Nation in the best possible way in the larger public
interest. The Principle of Intergenerational Equity is recognized world
over, as one generation of human kind has an obligation to conserve
and pass on the natural resources to the succeeding generation.
River systems in the State shall not be treated as a source of Sand as
conservation of Water-bodies is paramount obligation of the State
which is an essential resource for survival of the mankind. There is
no alternate for Water but there is alternate for River Sand in the

1

<!-- page 2 -->

::2::

form of M-sand, which is produced from crushing of the Rock to a
required size of 150 microns. Manufactured sand is produced by
crushing rocks, quarry stones or larger aggregates pieces into sandsized particles. Rocks or quarry stones are blasted and subjected to a
series of crushing cycles to reduce the particles to the size of
naturally occurring sand. The produced sand is then sieved and
washed to remove fine particles and impurities, and tested for
various quality aspects before it is deemed fit as a construction
aggregate. Manufactured Sand is produced from crushing of the rock
to required size and gradation suitable for construction industry.
The use of Manufactured Sand is steadily growing due to various
reasons. Global scarcity for natural sand exists. Injudicious sand
mining and continuous depletion of natural aggregate sources have
led to the implementation of new environmental/land use legislations
which has made the procurement of natural sand difficult and
expensive. In addition, presence of silt and clay in natural sand is
another reason for increased use of Manufactured sand. Natural sand
is inherently high in silt and clay. It can be damaging for screed and
concrete, if the sand is not sufficiently processed to bring down clay
and other impurity content to acceptable levels. Manufactured sand
also reduces the wastage of low-value by-products in the
quarries. The low value aggregates formed as a by-product of rock
crushing can be utilized efficiently to create a high value product.
M-Sand also offers higher flexural strength, better abrasion
resistance, higher unit weight and lower permeability. Due to these
advantages, manufactured sand is being used on a large scale by the
construction sector.
a) Environmental concerns regarding River Sand Quarrying:
i) Sand quarrying is desirable only up to permissible limits as it
prevents channel shifting, progress of flood plain and erosion
effects on opposite banks of river bed.
ii) However, indiscriminate sand quarrying ultimately results in
lowering of fresh water table and draught conditions.
B) Objectives of M-Sand Policy:
The main objectives are:
i)

To prevent damage to eco system by rationalizing the use of
river sand in a conserved manner without causing damage to
environment.

ii)

To promote the development of the Manufactured Sand
industry as an alternative to River Sand, given the increasing
demand of sand for domestic consumption as well as the
scarcity of river sand.
2

<!-- page 3 -->

::3::
iii)

To encourage the MSME sector in setting up of Manufactured
Sand units across all districts, generate employment and
effective utilization of resources within the state of Andhra
Pradesh.

C) Demand and Supply of Sand:
Estimated annual demand for sand in Andhra Pradesh is about
200 Lakh Cbmt and is projected to go upto 250 Lakh cum.
Estimated annual production of River Sand is about 100 Lakh
Cbmt. Hence, quantity required to meet the present surplus
annual demand is 100-150 Lakh Cbmt.
D) Future demand for sand:
i)
Visakhapatnam, Guntur, Nellore, Tirupathi, Vijayawada&
Kurnool are major centers of urbanization, and consume about 5060% of the sand produced in the state. These cities would continue
to be major drivers for sand consumption in the state.
ii) The proposed capital of the state at Vijayawada would also be
a major demand driver for sand consumption and in fact other
building materials also, due to the construction boom and other
major civil works expected in the city.
iii)
There are plans for upgrading the domestic airports of
Visakhapatnam, Rajahmundry, Gannavaram, Kadapa & Tirupathi
to international airports – this will also entail major construction
works which will in turn drive demand for sand.
iv)
The road connectivity within the State and with adjacent
States is expected to improve along with the widening of roads –
this will also drive demand for sand.
E) Manufactured Sand
Manufacturing Units:

and

Potential

for

establishment

of

1) (a) Manufactured Sand (M-Sand) is fine aggregate produced by
crushing hard rock by using crushing, shaping, screening and
classifying methods. Such Manufactured Sand obtained must confer
to IS Code and should be suitable for construction activity. Fine
particles of less than 150 Microns size shall not be present in excess
quantity than the percentage specified in the IS code. Stone dust
obtained in conventional crushing units shall not be treated as
Manufactured Sand as it is detrimental for use in construction and is
not eligible for claiming incentives.
(b) M-Sand unit for the purpose of availing incentives is defined as
a unit which produces atleast 50% of its total produce as
Manufactured Sand.
3

<!-- page 4 -->

::4::
2) Availability of Raw Material for Manufactured Sand in the State:
(i) Vast deposits of Charnokite suite of rocks and Khondalites,
which are suitable to establish Manufactured sand units in
Visakhapatnam, Srikakulam, and Vizianagaram Districts.
(ii) Vast tracts of Quartzites, Pegmatites in addition to Granite
Rock deposits are source rocks to setup Manufactured sand units
in Chittoor, Kadapa and Anantapuramu Districts.
3) Presently there are about six Manufacturing Sand units in the State.
It is estimated that 30 or more such units of 1000 Cbm per day are
needed just to meet the current unmet demand of 100 Lakh Cbm.
The growing demand for sand provides the potential for further units
to be established based on the vast Raw material source available in
the State.
F) Incentives to be provided for the Manufactured Sand Industry in
A.P:
1) For establishment of Manufactured Sand Units, the following
incentives will be provided, subject to the sale happens within the
State and the incentives shall be apportioned in the ratio of
Manufactured sand produced to the total unit production.
All manufacturing sand units will be accorded industry
status.
In addition to the above, the following incentives will be extended to
different category of industries as per MSME Policy 2015-20.
1. Micro and Small Enterprises
i)

Stamp Duty:
100% of stamp duty and transfer duty paid by the
industry on purchase or lease of land meant for
industrial use shall be reimbursed.
100% of stamp duty for lease of land/ shed/ buildings,
mortgages and hypothecations shall be reimbursed.

ii)

VAT/CST/ SGST:
100% of net VAT/CST/SGST shall be reimbursed for a
period of 5 years from the date of commencement of
commercial production.

iii)

Power :
Fixed power cost reimbursement is proposed to be
provided @ Rs.1/- per unit for 5 years from the date of
commencement of commercial production. This will
apply to open access units as well.
4

<!-- page 5 -->

::5::

Reimbursement of power incentive will be provided
subject to condition of installation of separate electric
meter for measuring power consumed by M-Sand
manufacturing
unit,
excluding
coarse
aggregate
producing machinery.
The units generating power from captive power plant will
not be eligible for the subsidy.
iv)

Interest Subsidy:
Interest subsidy on the term loan taken for fixed capital
investment by new Micro and Small enterprises in
excess of 3% per annum subject to a maximum of 9%
per annum for 5 years from the date of commencement
of commercial production.

v)

All other incentives as per the MSME Policy 2015-20.

1. Medium Enterprises
i)

Stamp Duty:
100% of stamp duty and transfer duty paid by the
industry on purchase or lease of land meant for
industrial use shall be reimbursed.
100% of stamp duty for lease of land/ shed/ buildings,
mortgages and hypothecations shall be reimbursed.

ii)

VAT/CST/SGST:
75% of net VAT/CST/ SGST shall be reimbursed for a
period of 7 years from the date of commencement of
commercial production or up to realization of 100% fixed
capital investment, whichever is earlier.

iii)

Power:
Fixed power cost reimbursement is proposed to be
provided @ Rs.1/- per unit for 5 years from the date of
commencement of commercial production. This will
apply to open access units as well.
Reimbursement of power incentive will be provided
subject to condition of installation of separate electric
meter for measuring power consumed by M-Sand
manufacturing
unit,
excluding
coarse
aggregate
producing machinery.
The units generating power from captive power plant will
not be eligible for the subsidy.
5

<!-- page 6 -->

::6::
iv)

Interest Subsidy:
Interest subsidy on the term loan taken for fixed capital
investment by new Medium M-Sand units enterprises @
5% per annum for 5 years from the date of
commencement of commercial production.

v)

All other incentives as per the MSME Policy 2015-20.

1. Large Enterprises
All the Large Enterprises will be provided incentives as
per the Industrial Development Policy 2015-20.
Special incentives:
a.Interest subsidy for Micro and small sand Manufactured units
shall be applicable as per MSME Policy-2015 and for medium
units, 5% subsidy on interest shall be provided.
b.10% reduction of VAT on purchase of machinery/ equipment
used in Manufactured Sand units.
c. 50% concession on seigniorage fee on raw materials used in
the process of Manufacturing Sand shall be extended both for
the new and existing industries.
2) For all existing M-Sand units, Special teams will be constituted
to study each unit on scientific lines in terms of the Technology
adopted, investments made, the production and sales details and
P&L accounts of the units since inception, etc., and suggest a
customized package of measures both financial and non-financial,
for units competitive, as a one off measure delinked from the
incentive policy. The said process shall be completed within 60
days from the date of representation made by the existing M-Sand
unit holder.
3) All M-Sand units availing incentives from Government shall supply
atleast 1/3rd of their production to Govt., works at a rate decided
by the District Collector.
4) All existing M-Sand units are eligible for Seigniorage fee
concession, power cost reimbursement and VAT/CST/SGST
reimbursement as mentioned above based on the category of the
industry.

6

<!-- page 7 -->

::7::
5) Concessions for Conversion of existing stone crushers into M-Sand
Units:
1.

10 % Concession on VAT for purchase of machinery to convert
existing crushers into M-Sand units or a Green field M-Sand
unit will be claimed only on the machinery required for
Manufacture of M-Sand.

2.

5% interest subsidy for conversion of crusher units into
M- Sand units in case of Medium units and 9% interest subsidy
in case of Micro and Small units as stipulated in MSME policy on
the Term loan taken for fixed capital investment on M-Sand
manufacturing activity.

3.

Reimbursement of power incentive will be provided subject to
condition of installation of separate electric meter for
measuring power consumed by M-Sand manufacturing unit,
excluding coarse aggregate producing machinery.

G) Assurance from Govt., to purchase
by the Units:

50% of M-Sand production

All Government Engineering Departments consuming sand in their
civil works shall insist on the following:
i)

Imposition of a condition in their contracts that at least 50% of
the total quantity of sand required in such works shall be met
by Manufactured sand produced from the Units located within
50 Km radius of the works.

ii)

This condition will be extended in phased manner depending
on the increase of establishment of Manufactured sand units.

H) Proposed implementation approach:
i)

88 potential mineral areas have been provisionally identified
for allotment to Manufactured Sand units. Director of Mines &
Geology is directed to indentify new mineral bearing areas for
manufacturing Sand.

ii)

The Director of Mines & Geology is directed to take action for
issuance of RFP for the provisionally identified mineral bearing
areas and also for the new mineral bearing areas for allotment
to M-Sand units.

iii)

The Director of Mines & Geology is also directed to issue RFP in
30 days with the suitable technical and financial parameters for
selection of entrepreneurs duly obtaining prior approval of the
Government.

7

<!-- page 8 -->

::8::
4.
This orders issues with the concurrence of the Finance Department
vide this Department e-file No.15471/M.II(1)/2015, dt.11.01.2016.
5.
The Director of Mines & Geology, Hyderabad shall take necessary
action in the matter.
(BY ORDER AND IN THE NAME OF THE GOVERNOR OF ANDHRA PRADESH)
M. GIRIJA SHANKAR,
SECRETARY TO GOVERNMENT (MINES & FP) (FAC)
To
The Director of Mines & Geology, Hyderabad.
All District Collectors in the State.
}
All Joint Directors of Mines & Geology.
All Deputy Directors of Mines & Geology
} through Director of
All Assistant Directors of Mines & Geology
} Mines & Geology
All Departments of Secretariat, Hyderabad.
The Commissioner of Panchayat Raj, Hyderabad
The Commissioner and Director of Municipal Administration, Hyderabad.
The Panchayat Raj & Rural Development (Pts.III) Department.
The Engineer-in-Chief, Water Resource Department,
The Engineer-in-Chief, TR&B Departmnet,
The Engineer-in-Chief, Panchayath Raj Dept.,
The Managing Director, A.P.Housing Corporation.
The Managing Director, A.P.Police Housing Corporation.
Copy to:
The Secretary to Government of India, Ministry of Mines, New Delhi.
The Law (H) Department.
The Industries and Commerce (M.I/M.III) Department.
The P.S. to Hon’ble Chief Minister.
The P.S. to Hon’ble Minister for Mines and Geology.
The P.S. to C.S.
The P.S.to Secretary to Government, Industries & Commerce Department.
Sf/Sc
//FORWARDED :: BY ORDER//
SECTION OFFICER

8
