---
doc_id: "35dfcfdceb63932e"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f549134e6523f534"
---

<!-- page 1 -->

PURCHASE DEPARTMENT - FORM IV
SRI VENKATESWARA INSTITUTE OF MEDICAL SCIENCES, TIRUPATI

PROPOSAL FOR HOSPITAL/OFFICE FURNITURE (New Item/Repair)
(NOTE: ALL THE COLUMNS ARE TO BE FILLED – Both hard copy and softcopy to be submitted)

Date:
S.no.

Particulars

1.

Name of the proposing department

2.

Proposal for new purchase or repair of
existing item
(a)Name of the furniture

3.

(b) Quantity

In words:

(c) Approximate cost
4.

How the existing work was being carried out so
far? Is the available furniture not meeting your
requirements?

5.

6.

Is it replacement for the condemned furniture?
If so, give details of condemnation and
enclose report of the same
What is the available stock of furniture of similar category?
S.
Name of the item
No.

Qty.

Year of
procurement

7.

Justification & Recommendations of the HOD regarding the need of the furniture (Additional
quantity):

9.

Market Survey: List of the Manufacturers/Suppliers(3 or more):
S.No.
Supplier Details
1.

e-mail id

Phone no.

2.
3.

4.

Date:

Proposalformforhospital/office furniture

Page1of 2

<!-- page 2 -->

8.

Specifications:(To be submitted approved by both HOD & A.E.(Tech.))

A.E. (Tech.)

10.

HOD

Remarks of the Inventory Section/Stores:(1.whether there is stock of requested item for supply 2.If
no, can it be supplied from inventory stores)

11.

Financial Recommendations by the Chief Accounts Officer, regarding our source of funds for
purchase

12.

Administrative Recommendations by the Medical Superintendent

13.

Recommendations of the Professor & In-charge(Purchase & Stores)

14.

Approval of the Director-cum-VC

Procurement procedure for Hospital and Office furniture & repair of Furniture
a.
b.
c.
d.
e.

The prescribed form to be sent by filling all the columns from the departments and duly approved
by the concerned authorities for processing.
The request to be approved by the Director-cum-VC along with the filled in form.
The format of the request letter is attached as advisory, if required may be modified.
As per the present purchase policy the procurement is made through calling sealed quotations
(minimum 03 nos.).
The quotations will be sent to A.E. (Technical) for assessment of matching with the specifications of
the item. For repair of furniture, the proposal &quotations are received from A.E. (Technical).

NOTE: The above procedure is followed for the items of top priority and approved by the Director-cum-VC.

Proposalformforhospital/office furniture

Page2of 2
