---
doc_id: "ed48b925ddce1bf3"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 2
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "99cd4d2a9a238002"
---

<!-- page 1 -->

CENTRE FOR DISTANCE EDUCATION
ACHARYA NAGARJUNA UNIVERSITY:: NAGARJUNA NAGAR-522510
SE
SYED ZAINULABDIN, (త్ర) Office: 0863-2346228
DEPUTY REGISTRAR (Exams) = 2346229
No.ANU/CDEVI, Il, II, 1V & V Semester Examinations/Notification/2025, Date: 13-05-2025
NOTIFICATION
Sub: ANU - CDE — Issue of Examination Notification for conducting of I, II, I, 1V &
V Semester (Regular and Supplementary) examinations Commencement date
from 23-06-2025 to all UG, PG, Year End & Diploma Certificate Courses —
Regarding.
Ref: Vice-Chancellor’s Orders dated 09-05-2025.
* OR KOR OK
The Vice-Chancellor has ordered that the ANU, CDE, I, II, Il, [V & V Semester
examinations to the regular and supplementary students of all UG, PG, Year End & Diploma
Certificate courses be commenced date from 23-06-2025 for the following batches.
SI. Batch Course Semester Commencement
No. Exam Date
Tentative.
[ 1. [A-24 & C-25 UG/PG I Semester (Regular)
2. | C-21, A-21, C-22, | UG/PG 1 Semester
A-22, C-23, A-23 | (Supplementary)
& C-24
C-24 UG/PG Il Semester (Regular)
4, | C-21, A-21, C-22, | UG/PG II Semester
A-22, C-23 & A-23 (Supplementary)
UG/PG 111 Semester (Regular)
C-21, A-21, C-22, | UG/PG II Semester
A-22 & C-23 (Supplementary)
A-22 & C-23 UG/PG IV Semester (Regular) | 23-06-2025
8. | C-21, A-21 & C-22 | UG/PG IV Semester
(Supplementary)
[ 9. | A-21 &C-22 V Semester (Regular)
[ 10. [c-21 [UG | V Semester (Supply)
ll. | C-24 &€<25 hey Diploma/Certificate | (Regular)
Courses
12. | C-21, A-21, C-22, | Diploma/Certificate | (Supplementary)
A-22, C-23 & A-23 | Courses
13. | Year-End (Supply) | UG/PG/Diploma/ All Courses
Certificate Courses a
The Examination fee is payable through online only available at website
WWW.anucde.info. The Time-Tables and Examination application Form (for Semester and
Year End supplementary Students only) is also available at website WWW.anucde.info. The
AE tee

<!-- page 2 -->

Regular semester students are not required to pay any examination fee and do not need to
submit the examination application.
The schedule of dates for payment of supplementary examinations fees is as follows:
1. Last date for payment of examination fee without fine > 27-05-2025
‘ 2. Last date for payment of examination fee with fine of Rs.100/- > 31-05-2025
3. Last date for payment of examination fee with Tatkal fine of Rs.500/- > 05-06-2025
Note: Those who are not paid examination fee and appeared for exams, fine will be imposed
for Rs. 1,000/-.
Examination Fee for UG, PG & Diploma Certificate Courses:
Four& |p.
ల Single Three | Above | Pret | Tabs | Assign | Betterment Fee
ourse 1 Viva- : 4
paper papers | /Whole | 'y 10" | Praeticals | ments
apers
B.A./B.Com.,/B.B.A.
First Semester 680 800 1000 1250 1000 700 200
Second Semester 680 800 1000 1250 1000 700 200
Third Semester 680 800 1000 | 1250 | 1000 700 200 | 2000+exams fee
Fourth Semester 680 800 1000 | 1250 | 1000 700 200
Fifth Semester 680 800 1000 | 1250 | 1000 700 200
| M.A./M.HLR.M/M.S.W/
| M.Com/ M.L.LSe./B.L.1.Se
| First Semester 680 800 1000 1250 1000 700 200
Second Semester 680 800 1000 | 1250 | 1000 700 200
Third Semester 680 800 1000 1250 1000 700 200 | 2000+exams fee
Fourth Semester 680 800 1000 | 1250 | 1000 700 200. i
Diploma/ Certificate |
Courses Suppl 800 1250 | 1000 | 700 200
All UG/PG Diploma/
Certificate Courses 800 1250 700 200
Year-End Supplementa
The Hall-Tickets will be issued only to the candidates who have cleared all the dues to the
University. This is for information and prompt action.
Sue z\sir$—
DEPUTY REGISTRAR (4 \s|25
(CDE - EXAMINATIONS)
To
The Editors of all News Papers — With a request to publish the notification as news item in all
the daily newspapers.
Copy to the Director, CDE, ANU.
Copy to the Coordinator, CDE, Exams, ANU.
Copy to the Assistant Registrar, Coordinator Office, CDE, ANU.
Copy to Deputy Registrar & Assistant Registrar UG and PG Exams, ANU.
Copy to all P.A. to Registrar/Rector/Vice-Chancellor, ANU.
టో క
టా
