---
doc_id: "7cbad2cf611d8f2d"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 20
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "57b01be389fc2ef0"
---

<!-- page 1 -->

1

(To be used for furnishing bids by the eligible firms)
*****

VIKRAMA SIMHAPURI UNIVERSITY , KAKUTUR,
NELLORE
TENDER SCHEDULE FOR SUPPLY PROVISIONS
(DRY/PACKED)
TERMS & CONDITIONS

Address for Communication:
CHIEF WARDEN, VIKRAMA SIMHAPURI UNIVERSITY COLLEGE HOSTELS
(MEN & WOMEN),
VIKRAMA SIMHAPURI UNIVERSITY, KAKUTUR, SPSR NELLORE DIST.
ANDHRA PRADESH
PIN CODE: 524324

1

<!-- page 2 -->

2

VIKRAMA SIMHAPURI UNIVERSITY COLLEGE HOSTELS
KAKUTUR, NELLORE-524324
INVITING TENDER FOR SUPPLY OF PROVISIONS
Tender No. VSUHostels/Provisions/2025

Date 22/07/2025

Vikrama Simhapuri University College Hostels, Kakutur, Nellore inviting tenders to
procure Provisions on a monthly basis from the local provisions firms/suppliers/bidders.
Hostel mess requires provisions to serve 550 to 600 students (Approximately) daily (both
Men and Women's mess) for 12 Months period (i.e. one year) from the date of issue of the
purchase order. Interested Firms/Suppliers/bidders may download the tender along with the
terms & conditions and application form from the University (Tender) website:
www.vsu.ac.in
The cost of tender schedule/tender fees is Rs.1,000/- for Provisions item by demand
draft to be enclosed drawn in favor of Registrar, Vikrama Simhapuri University, Payable
at Nellore from any nationalized bank. The eligible firm shall submit one sealed cover
containing two separate covers i.e. one consist duly signed tender application (Annexure-I)
including terms and conditions and another consists of Earnest Money Deposit (EMD),
tender document fees & check list along with all enclosures addressed to The Registrar,
Vikrama Simhapuri University, Kakutur, Nellore – 524324 either Speed/Registered post
or directly so as to reach the office on or before 05/08/2025. The sealed envelope shall be
super-scribed (please write on top of the cover) as Tender No:
VSU/Hostels/Provisions/2025 dated 22/07/2025. The tenders will be opened on
07/08/2025 at 11.30 A.M. in the chamber of Registrar, Vikrama Simhapuri University
College, Kakutur, Nellore in the presence of the tenderers/representatives. Receipt of
application either after the due date or incomplete application form or without any one of the
enclosures following: tender fee, EMD or enclosures will be summarily rejected. Tenders
received other than the prescribed format will not be accepted.
SCHEDULE OF TENDER ARE AS FOLLOWS:
1.

Department Name

Vikrama Simhapuri University College Hostels
(Men & Women)

2.

Tender Subject

Supply of Provisions

3.

Tender Type

Open Tender

4.

Cost of Tender Document/Fee

Rs.1000/-(Rupees One thousand only)
Non-Refundable
Demand Draft Drawn from any nationalized
bank in favor of “Registrar, Vikrama
Simhapuri University, Nellore” payable at
Nellore.
2

<!-- page 3 -->

3

5.

EMD Amount (INR)

E.M.D @ Rs. 20,000/- (Non Interest bearing
deposit) by way of Demand Draft Drawn from
any nationalized bank in favor of “Registrar,
Vikrama Simhapuri University, Nellore”
payable at Nellore. is to be enclosed”.
Without E.M.D. the Tender will not be
considered.
Rate should be inclusive of all taxes and
transportation amount should be mentioned
separately to the VS University College
Hostels, Kakutur, Nellore.
In respect of successful bidder it will be returned
after the completion of the Tender Tenure. Any
other dues outstanding shall also be recovered
from the EMD. In the case of unsuccessful
Bidders, the EMD shall be refunded within 15
working days.

6.

EMD Payable

Demand Draft Drawn from any nationalized
bank in favor of “Registrar, Vikrama
Simhapuri University, Nellore” payable at
Nellore.

7.

Date of Issue of Tender Document

22/07/2025

Last Date & Time for Submission
of Tender

05/08/2025 at 4.00 P.M at Registrar, Vikrama
Simhapuri University, Kakutur, SPSR
Nellore, Andhra Pradesh, India- 524 324

9.

Date & Time for opening of
Tender Document

07/08/2025 at 11.30 A.M at Registrar,
Vikrama Simhapuri University, Kakutur,
SPS Nellore, Andhra Pradesh, India- 524 324

10.

Tender Validity Period

12 Months (One Year)

11.

Date for Commencement of contract

Will be intimated

12.

Tender Inviting / Opening authority Registrar, Vikrama Simhapuri University,
Kakutur, Nellore

8.

13.

Eligibility Criterion

The Tenderer should possess all requisite licenses,
registrations and certifications etc., (WHEREVER
APPLICABLE) and the same should be obtained
invariably before transacting business with Vikrama
Simhapuri University College Hostels, Kakutur,
3

<!-- page 4 -->

4
Nellore. The tenderer should inform Vikrama
Simhapuri University College Hostels, the correct
address from where the supplies are going to be made
to Vikrama Simhapuri University College Hostels,
Kakutur. The tenderer should possess an experience
certificate and other certificates like Registration of
Firm, GSTIN registration, Firm PAN Card
(WHEREVER APPLICABLE) , Bank account
with Firm name and Latest Income Tax Assessment
order should be enclosed invariably along with the
tender schedule. In case of non-submission of these
certificates, the Vikrama Simhapuri University
College hostel authorities reserve the right to take
any appropriate action including the cancellation of
tender of the respective tender. In this regard the
decision of the Tender Opening Authority/Registrar,
Vikrama Simhapuri University Nellore is final and
binding on the tenderers without any recourse.
Tenders will be opened on 07/08/2025 at 11.30 a.m.
in the chamber of Registrar, Vikrama Simhapuri
University, Kakutur, SPSR, Nellore – 524324
followed by discussions between negotiations
committee and successful bidder.
Note: The University reserves right to accept,
reject or cancel the tenders fully or partially
without assigning any reasons.

14

General Terms and Conditions

AS MENTIONED IN THE NOTICE INVITING
TENDER

4

<!-- page 5 -->

5

VIKRAMA SIMHAPURI UNIVERSITY COLLEGE HOSTELS
KAKUTUR, NELLORE
INVITING TENDER FOR SUPPLY OF PROVISIONS
Tender No. VSU Hostels/Provisions/2025

Date 22/07/2025

“IMPORTANT NOTICE-PLEASE GO THROUGH ALL THE TERMS &
CONDITIONS, VERY CAREFULLY BEFORE FILLING THE FORM SO AS TO
AVOID UNWARRANTED INCONVEINCES TO BOTH, THE TENDERER &
VIKRAMA SIMHAPURI UNIVERSITY COLLEGE HOSTELS”
To (Firm Name/full seal of firm)
M/s. _________________________
_____________________________
_____________________________
TENDER CONDITIONS FOR THE SUPPLY OF PROVISIONS (DRY/PACKED)
FOR THE YEAR – 2025-26
TERMS & CONDITIONS
1. The tenders shall be submitted accordingly to the terms and conditions specified in
paragraphs 2 to 46 unless specified otherwise in the tender it shall be construed that
the terms & conditions stipulated hereunder have been agreed to.
2. Tender invited for Supply of Provisions, quality is important but the brand is
specified wherever it is applicable.
3. The firm shall quote the price as per the agricultural market committee rates
and unit mentioned in tender application (Annexure-I) inclusive of all taxes and
transportation amount should be mentioned separately to the VS University
Hostels, Kakutur, Nellore. The Vikrama Simhapuri Hostels shall not be liable to
pay any tax, any freight etc. which has been expressly stipulated in the tender in
the event of acceptance of the tenderer.
4. RATE REVISION AND ADJUSTMENT CLAUSE :
To ensure fair pricing, the rates quoted by the Contractor will be reviewed and
compared with the market rates determined by the Agriculture Market
Committee every three months.
In the event of any discrepancy, the following adjustments will be made:

5

<!-- page 6 -->

6



If the Contractor's rates are higher than the Agriculture Market Committee
rates, the difference amount will be deducted from the monthly bills.



If the Contractor's rates are found to be varying from the Market Committee
rates in the last three months preceding the completion of the tender period,
the difference amount will be deducted from the Earnest Money Deposit
(EMD).

5. The firm shall submit the tender in a sealed envelope containing
(a) a filled-in tender application form (Annexure-I) with Firm seal, signature, and
date & Tender document each page duly signed stamped and page numbering
done.
(b) a Non-refundable Tender Fee of Rs. 1000/- (Rupees One thousand only)
(c) Earnest Money Deposit (EMD) of Rs.20,000/- (Rupees Twenty thousand
only) by means of a Demand Draft Drawn from any nationalized bank in
favor of “Registrar, Vikrama Simhapuri University, Nellore” payable at
Nellore.
(d) The Self Attested photocopies of (i) Firm Registration certificate, (ii) Firm
PAN Card, (iii) GSTIN Certificate (Wherever applicable) and (iv) Bank
Account in the name of the Firm, Self-attested copies of the Income tax
returns for the last three years & Tender experience certificates.
6. The Contractor should have a registered firm in and around SPSR Nellore
(Dist). The contract should not be sub-leased to anyone in any manner.
Complaints/violations brought to the notice of the Registrar/Chief
Warden/Deputy Warden resulting in the cancellation of the rate contract
immediately and as a token of firm EMD amount will not be refunded to the
firm.
7. The tenderers should submit self-attested copies of the Income Tax returns for
the last three years (i.e. for 2022-2023, 2023-2024 & 2024-25).

8. Tax Deduction (TDS Clause): Applicable TDS under the Income Tax Act or
GST Act shall be deducted from each bill as per statutory provisions and
deposited to the respective authorities by Vikrama Simhapuri University."
9. Bills in triplicate for the items supplied by the firm(s), should be raised for
payment. Payment shall be released after deducting TDS as per Income Tax
Rules and any other deductions as per Government rules and payment shall be
released only after it is ensured that the items/quantity and quantity of items
supplied are to the entire satisfaction of this office. If any items are found to be
defective, or not of the desired quality etc., the same shall be replaced
immediately, for which no extra payment shall be replaced immediately, for
which no extra payment shall be made by Vikrama Simhapuri University,
Nellore.
6

<!-- page 7 -->

7

10. The Tenderer should be a reputed supplier having at least three years dealing
experience with the government departments, PSUs, or educational institutions.
Certificate in token of proof of experience by way of purchase
orders/Agreements, of the concerned department should be enclosed for ready
reference.
11. The tendering firm/Agency/Company shall be bound by the details furnished by
him/her to the Vikrama Simhapuri University, Nellore while submitting the
tender or at subsequent stage. Upon selection of the tendering
Firm/Agency/Company, if at any stage the document furnished by him /her is
found to be false or the quality of the articles or rates are found of poor
quality/different specifications, it would be deemed to be a breach of terms of
contract, the contract shall be cancelled and performance security shall be stand
forfeited.
12. The tender should be sent / submitted to the O/o the Registrar, Vikrama
Simhapuri University, Kakutur, SPSR Nellore – 524 324 the closing time and
date for acceptance of tenders shall be on/before by 05/08/2025. No tender
received later the stipulated date & Time or from other modes/ place shall be
entertained & shall be declared un –responsive.

13. The tenders will be opened on 07/08/2025 in the chamber of Registrar, Vikrama
Simhapuri University, Nellore in the presence of such tendering
firm/Agency/company or their authorized representatives (only one
representative from each company shall be allowed) who wish to be
present/witness at the time of opening of bids.
14. The Authority reserves the right to reject/cancel any or all the tenders at any time or to
relax/amend/withdraw any of the terms and conditions as contained in the Tender
Documents without assigning any reason, thereof. Any inquiry after submission of the
tender will not be entertained.
15. Tenderers shall not approach for refund of EMD till the finalization of the tendering
process and award of contract to qualifying Tenderers. If any tenderer approaches for
EMD, it will be forfeited at the discretion of the competent authority of VSU, Nellore.
EMD shall be refunded to the unsuccessful tenders within 15 days of award of
contract to the successful tenders /tenderers.

16. For packed/sealed items, the rates accepted will be less than OR equal to MRP and in
NO case, rates more than the MRP will be paid. In case of decrease in the MRP on
any later stage within the contract period, the reduced amount will only be paid. And

7

<!-- page 8 -->

8

in case of increase, the V.S. University will NOT be liable to pay the
increase/difference in rates.
17. Free items/gift/scheme extended by manufacturer/company/supplier/firm is also
extended to VSU Hostels without any extra amount.
18. The rate for the brand/company/make/specifications, if it is mentioned in the tender to
be quoted, tenderer should not quote their own brand or any other quality.
19. Risk purchase: If the contractor fails to supply the articles within the time stipulated in
the letter of acceptance, the undersigned shall be at liberty to purchase the articles
from any other sources or from the open market or get the rest of the contract
completed by any other person or firm and the difference of price, if any shall be
deducted from the earnest money deposit OR claim the difference in price on higher
side from the Contractor/deduct from the bills on hand and the V.S. University
college hostels will adopt any other method to realize the same.
20. In the event that the Contractor fails or refuses to supply the items for any reason after
the agreement, at any stage before the completion of the contract period, the following
penalties shall apply:
* The Earnest Money Deposit (EMD) shall be forfeited.
* The contract shall be terminated, and the next lowest bidder shall be selected to
complete the contract.
21. The price finalized by the central purchase committee is final/remains the same
and requests for rate enhancement during the contract period will not be
entertained.
22. The undersigned does not bind himself to accept the lowest tender and reserve the
right to accept the tender in whole or in part i.e, with respect to articles mentioned in
the attached statement and or in respect of any one or more than one articles specified
in the attached statement as he may decide.
23. On acceptance of the tender it will become a contract and shall be a contract and shall
be bound by the terms & conditions of the tender. The contract shall be executed in
Document paper (Bond paper/E Stamp Paper) worth Rs.100/-, the cost of which will
be borne by the bidder only along with the supply of items the contractor has to
furnish the bill/invoice (in prescribed format which will be containing the GST
registration number) for necessary payment from the funds of Vikrama Simhapuri
University College Hostels, Kakutur, Nellore.
24. In case of any dispute between Vikrama Simhapuri University Hostels and the firm,
the decision of the Vikrama Simhapuri University authorities is final and binding on
both parties.

8

<!-- page 9 -->

9

25. Vikrama Simhapuri University authorities reserve the right to extend/cancel the
Contract partially/fully at any time by giving 30 days written notice for
justifiable reasons. Immediate termination will be enforced for serious violations
or fraud.
26. The liberty to carry out negotiations or accept the lowest tender as such is vested with
Hostel Committee and will be exercised after opening and compiling the same and L1 bidder shall be decided on the basis of lowest rate quoted by any of the bidder and
the bidder, who have quoted of in L-1 rate shall be given opportunity by the
competent authority of VSU, Hostels Nellore and ask him in writing to match L-1
price of other items quoted by him in comparison of other bidders, where his quote
has not found L-1.
27. Tenderer submitting tenders would be considered and accepted all the terms and
conditions. No enquiries, verbal or written, shall be entertained in respect of
acceptance or rejection of the tender.
28. In case of the supply of damaged Provisions packets or spoiled Provisions on any
particular day, the firm shall replace them with good quality immediately at free of
cost.
29. There should not be any overwriting or corrections in the tender. If figure is to be
amended, it should be neatly scored out and the revised figure write above and the
same to be self attested with full signature and seal of the firm with date. In the
absence of attested signature the tender is liable to be rejected.
30. Prior to acceptance of the tender, the undersigned reserves the right to call for sample
or demonstration and contractor shall be liable to supply the sample/specimen or give
the demonstration at free of cost.
31. In the event of acceptance of the tender and placing the order for the purchase of the
articles ordered for would be subject to an inspection by the undersigned or his
representative and are liable to be rejected if the articles supplied are not according to
approved sample/specimens or do not confirm to the specifications prescribed.
32. Party/bidder/person, bidding in any tender/quotation HAS NO right to
include/incorporate or insist any terms OR conditions or demands for
supply/service of any items. And the decision of the undersigned on any matter,
in the best interest of the VSU Hostels, shall be final and binding. The
conditional/incomplete tenders will be considered and shall be declared
unresponsive.
33. Delivery Timing: The supplier must ensure delivery of materials before [e.g.,
7:00 AM] each day, unless otherwise specified. Late deliveries will be subject to
inspection and potential rejection.

9

<!-- page 10 -->

10

34. Penalty Clause for any delay: A daily penalty of [e.g., 0.5% of order value per
day], subject to a maximum of [10%], shall be levied for any delay in supply
beyond the specified timeline without valid justification.
35. Bidder/party shall NOT strike out any of the above terms & conditions and if done so,
his/her/their tender/quotation will be rejected summarily.
36. The monthly bill shall be submitted to Chief Warden, VS University Hostels on the
last day of the month and payment will be made to the firm bank account after
successful bill processing within 15 working days.
37. The bidder is advised to be conversant with the terms and conditions as stated
above before accepting the Contract.
38. The bills raised by the selected tendering Firm/Agency/Company should have all tax
registration numbers printed on bill. The bill shall be signed by the authorized
signatory of the firm across a revenue stamp, if it exceeds Rs.5,000/-.
39. Vikrama Simhapuri University Hostels, Nellore shall not be responsible for any
financial loss or other damage or injury to any item or person deployed/supplied by
the successful bidders in the course of their performing the duties to this office in
connection with purchase order /supply order for items to VSU Hostels, Nellore. The
Competent Authority of Vikrama Simhapuri University Hostels, Nellore reserves the
right to relax/withdraw any of the terms and conditions mentioned in the tender
documents, if doing so is in the interest of the VSU, Nellore.
40. The Tenderer should give an affidavit duly nationalized on stamp paper worth
Rs.100/- in clear and un-ambiguous language that it has never been black listed/
no criminal case pending by any of the organization with whom, it had dealing
for supply of similar items during last five years nor has been penalized for
inferior or poor quality in supply.
41. Any action on the part of the Tenderer to influence anybody in the said institute
will be taken as an offence, and they will not be allowed to participate in the
tender enquiry and their offer will not be considered.
42. The Contractor or Bidder shall not pay any bribe or incentive to any of the hostel
workers or hostel members.
43. If any hostel worker or member approaches vendor for any kind of monetary favor or
assistance, please do not engage or entertain their request. Instead, kindly report the
incident immediately to: Chief Warden/Deputy Warden.
44. The Bidder shall not make any payments to Hostel Workers for procuring items from
external sources without obtaining prior approval from the Chief Warden.
10

<!-- page 11 -->

11

45. The Vikrama Simhapuri University College Hostels reserves the right to amend the
tender in full or any part thereof. Amendment to the Tender will be uploaded on the
website of the University and it will be the sole responsibility of the tenderer to verify
the amendments if any and get the amended documents before the submission of the
tender.
46. Firm may contact Deputy Wardens/Chief Warden, V.S.University College Hostels,
Kakutur, Nellore for any clarification.
NOTE: I have carefully read and understood all the terms and conditions of the tender
and undertake to abide by them.

Date:

/

/ 2025

Signature of the Tenderer/Firm
With full address seal of the firm.

11

<!-- page 12 -->

12

VIKRAMA SIMHAPURI UNIVERSITY COLLEGE HOSTELS, KAKUTUR
SPSR NELLORE DISTRICT
CHECK LIST FOR THE TENDER FOR THE YEAR 2025-26
S.No.

PARTICULARS

1

Name of the Proprietor

2

Name of the firm

3

Full Address of the firm with PIN
Code.

REMARKS

……………………………………………..
……………………………………………..
……………………………………………..
………………………………………………
PIN:

4

Contact No. with STD Code and
Mobile No.
Email ID No.

Tele No.__________________
Mob No.__________________
Email ID __________________

5

Firm Registration Certificate No. and
Valid Up to with No. (Enclose copy)

Regd.No___________________

6

PAN No (Enclose copy)

PAN No.___________________

7

GST No (Enclose copy)

TAX No.___________________

8

Details of EMD

Rs._______________________

Value up to ________________

DD No.____________________
Date. _____________________
Bank Name:
__________________________
12

<!-- page 13 -->

13

9

Firm Bank A/c. No. (Enclose Pass
Book Copy)

YES/NO

10

Tender Form Terms and Condition
(Signed copy should be enclosed)

YES/NO

11

Rate List (Filled in all respect &
Signed with Firm Rubber Stamp
should be enclosed) (Please don’t
make any corrections/overwriting)

YES/NO

12

self-attested copies of the Income Tax YES/NO
returns of the tendering company/Firm
Agency for the last three financial
years (i.e. for 2022-2023, 2023-2024
& 2024-25). (Attach separate sheet if
space provided insufficient).
For the FY-2022-23
For the FY-2023-24
For the FY-2024-25

13

Give details of major contracts handled by the tendering Company/Firm/Agency for
the last three years in the following format (enclose the self-attested copies): (if the
space provided is insufficient, a separate sheet may be attached).

S.No.

Details of client along Amount
of
Duration of contract
with
address, Contract
From
To
telephone
numbers (Rs.in Lakh)
and fax numbers

1

2

Signature of Tenderer with Seal

13

<!-- page 14 -->

14

DECLARATION
I/We, ____________________________________________________ (Name of the bidder
party/person/Supplier) have read/gone through all the terms & conditions, enlisted above
from Sl. No. 2 to 46 and fully agree to comply with the same and to participate in the bidding
for
the
supply
of
_________________________________________________
(Items/articles) to the Vikrama Simhapuri University College hostels, Kakutur, SPSR Nellore
District AP for the year 2025. Accordingly, I/We hereby submit my/our competitive
rates/quotation along with a demand draft bearing No.________________________ dated
____________________ for Rs._________________ drawn in in favour of the Registrar,
Vikrama Simhapuri University, Nellore from any nationalized bank towards EMD and other
required documents in a sealed cover for your consideration.
I/We have NOT included/incorporated any terms OR conditions as our own and shall NOT
insist to accept any of our terms conditions till the expiry of contract and the decision (s),
taken by you in regards to my/our quotation/rates will be accepted by me/us.
My name/the name of my/our firm has NOT been black-listed by any of the
Governmental or Government aided Agency/department, Public Sector Undertakings, and
Cooperative Societies etc. In case it is provided otherwise, the Registrar/Chief Warden,
Vikrama Simhapuri University, Kakutur, SPSR Nellore District. Will be at liberty to cancel
the tender/quotation/contract instantly without any notice to me/us and also can proceed with
other administrative/legal actions (s), as deemed fit.
The information / documents furnished along with the above application are true
and authentic to the best of my knowledge and belief. I/we, am/are well aware of the fact
that furnishing of any false information / fabricated document would lead to rejection of
my tender at any stage besides liabilities towards prosecution under appropriate law.
Further, I/We have carefully read the terms and conditions mentioned above and
accept the same in Toto. I shall sign the contract agreement in Document Paper (Bond
Paper/E-Stamp Paper) worth Rs.100/- and shall ensure timely supply of materials as per the
approved specifications and your requirement during the contract period.
Place : Signature f the Tenderer/Bidder
Date:

With date seal of the firm

Witness- I-Name –

Witness-II- Name –

Address-

Address-

Occupation-

Occupation-

14

<!-- page 15 -->

15

To
The Registrar,
Vikrama Simhapuri University,
Kakutur,
Nellore-524324.,
Sir,
Sub:- Submission of tender schedule for the supply of _________________________
for the year – 2025-26-Reg.
Ref:- Tender notice published on in DISTRICT EDITIONS.
In pursuance to your office tender notice published in EENADU/ANDHRA JYOTHI
daily dated _____________ and the undersigned wish to submit this application to participate
in the tender for ________________________________.
1. Please find enclosed herewith DDs bearing No.________________dated ______________
of Rs. ___________ (in words
___________________________________________________) drawn in favor of the
Registrar, Vikrama Simhapuri University, Kakutur, SPSR Nellore District on
___________________ bank payable at _____________________________ towards EMD.
2. The quoted rate list being submitted as per the Agricultural market committee along with
tender form.
3. The rates quoted by the undersigned are inclusive of GST and all taxes, packing &
forwarding charges etc., and Transportation amount mentioned separately.
I/We abide by the terms & conditions set forth in the tender notification and will ensure to
supply as per specifications.
Thanking you,
Yours faithfully,
DATE:
Sign of Tenderer
PLACE:

with full address seal

15

<!-- page 16 -->

16

Annexure-I
TENDER APPLICATION FOR SUPPLY OF PROVISIONS

Tender No. VSU Hostels/Provisions/2025-26

Date 22/07/2025

TENDER SCHEDULE FOR SUPPLY OF PROVISIONS (DRY/PACKED) FOR THE
YEAR-2025-26
Name of the firm/proprietor : …………………………………………………………
Full Address

: ………………………………………………………….

Tel.No/Mobile No

: ………………………………………………………….

GST No: ________________________________________

Sl.No

Name of item

Brand name

1

Upma Ravva
(ఉప్మా రవ్వ )
IdliRavva
(ఇడ్లర
ీ వ్వ )

First Quality

Oil (ప్మమాయిల్)
Toor dal
(కందిపప్పు )
Urad dal
(మినపు ప్పు లావుగండ్ల)ీ
Green Gramdal
(పెసరపప్పు )
Bengal Gram dal
(పచ్చి శనగపప్పు )
Tamarind
(చ్చంతపండ్ల)
Gulla Bengal Gram dal
(తినేశనగపప్పు )
Ground Nut Seeds Big size
వేరుశనగపప్పు లావుగం
డ్డ్లీ (పెద్వి
ద )

Ruchi Gold

Onions Big size
యర్రగడ్లు
డ
(లావులు)

First Quality

2
3
4
5
6
7
8
9
10

11

First Quality

First Quality
First Quality
First Quality

First Quality
Karibuli
First Quality

First Quality

Unit

DRY/PACKED ITEMS
Price for
1 KG
Rs. Ps.

Transportat
ion amount

1 Kg
1 Kg
1 Ltr
1 Kg
1 Kg
1 Kg
1 Kg
1 Kg
1 Kg
1 Kg

1 Kg

16

<!-- page 17 -->

17
12

13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32

Garlic Medium size
తెల్గ
ీ డ్లు
డ
(మీడియంసైజు)
Jeera
(జీల్కర్ర)
Pepper
(మిరియాలు)
Mustard small Best
(ఆవాలు)
Coriander powder(Aachi)
ధనియాల్పొడి
Coriander Seeds
ధనియాలు
Inguva
ఇంగవ్
Turmeric Powder
పసుప్ప
Chilli Powder
కారంపొడి
Red Chillies
ఎండ్లమిరపకాయలు
Crystal
కలుీఉప్పు
Salt
సాల్్
Dry coconut
కొబ్బ రి
Scrubbers (steel)
ర్సర బ్బ ర్స్
BLEECHING
Lavangams
ల్వ్ంగాలునం.2
Elachi
యాల్కులు (7.5)
Patta
పట్ట్
Fenugreek
మంతులునం.1
Rasam Powder
రసంపొడి
Sambar powder
సాంబారుపొడి

First Quality
1 Kg
First Quality

1 Kg

First Quality

1 Kg

First quality

1 Kg

Aachi

1 Kg

First Quality

1 Kg

L.G.

1 Kg

Aachi

1 Kg

Aachi

1 Kg

First quality

1 Kg

TATA

1 Kg

TATA

1 Kg

First quality

1 Kg

Exo

1 Kg

First quality

1 Kg

First quality

1 Kg

First quality

1 Kg

First quality

1 Kg

First quality

1 Kg

Aachi

1 Kg

Aachi

1 Kg

17

<!-- page 18 -->

18
33

Priya

5 Kg

Priya

5 Kg

Priya

5 Kg

Priya

5 Kg

Priya

5 Kg

Priya

5 Kg

First quality

1 Kg

40

Mango Pickles
ఆవ్కాయపచ్ి డి
Lemon Pickle
నిమ్ా కాయపచ్ి డి
Tamota Pickle
టమోట్టపచ్ి డి
Chilli Pickles
పండ్లమిరిి
Amla Pickle
ఉసిరికాయ
Peel Mango
మామిడికాయతొకుర
Sugar
చ్క్కర ర
Gemini Tea Powder

--

1 Kg

41

Five star Tea Powder

--

1 Kg

42

First quality

1 Kg

Aachi

1 Kg

First quality

1 Kg

Aachi

1 Kg

First quality

1 Kg

First quality

1 Kg

First quality

1 Kg

First quality

1 Kg

50

Wadiyas
వ్డియాలు(గొట్ట్లు)
Garam masala
మీటా సాలా
Maratimogga
మ్రాఠీమొగ గ
Meat Masala
చ్చక్కనా సాలా
Anasa flower
అనాసప్పవువ
Jajikaya
జాజికాయలు
Fenugreek Leaves
మంతిఆకు
Biriyani leaves
బిరాా నీఆకు
Shajeera

First quality

1 Kg

51

Milmekar

First quality

1 Kg

34
35
36
37
38
39

43
44
45
46
47
48
49

#

The rates are should be mentioned as per the agricultural committee market rates inclusive of

all taxes and transportation amount should be mentioned separately to the VS University
Hostels, Kakutur, Nellore.

18

<!-- page 19 -->

19

Enclosures: [ wherever applicable]
1. Firm Registration Certificate [ ]
2. PAN Card[ ]
3. GSTIN Registration[ ]
4.BankName___________________________DDNo. ___________dated__________
for Rs. 1,000 towards Tender Fee (Non-refundable)
5.Bank Name_________________________DD No.___________ dated__________
for Rs. 20,000 towards Earnest Money Deposit (EMD). (Refundable) within15
working days, except successful bidder.
6. Self-attested Income tax returns for the last three years & Tender experience
certificates.

Note:
1. The tenderer has to supply of Provisions of No.1 quality only should be supplied.
Inferior quality, if found, at the time of supply will be rejected.
2. There should not be any overwriting or correction in the tender form.
3. The rates quoted are inclusive of All Taxes, Freight, Packing Forwarding charges and
transportation amount separately.
4. The Tender has to be submitted in the tender documents only in the prescribed
proforma supplied by the Vikrama Simhapuri University College Hostels.
5. The Tender to be submitted in sealed envelope super-scribed “TENDER FOR
SUPPLY OF PROVISIONS (DRY/PACKED)” to the Registrar, Vikrama Simhapuri
University, Kakutur, SPSR Nellore District.
6. The rates quoted in the Tender form by following same Terms and conditions.
7. The tenderer has to supply all tender materials on correct date and time with bill
which will be mentioned in tender sheet at the time of giving order of any outlets.
8. The Tenderer has to weigh in front of concerned person/committee.
Date: …………….
Place: ……………
Signature of the Tenderer with seal

19

<!-- page 20 -->

20

OFFICE USE ONLY

HOSTEL COMMITTEE MEMBERS :
1.
2.
3.
4.
5.
6.
7.

20
