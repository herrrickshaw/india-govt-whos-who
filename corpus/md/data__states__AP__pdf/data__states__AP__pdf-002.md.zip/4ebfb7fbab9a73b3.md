---
doc_id: "4ebfb7fbab9a73b3"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "68dc19e93296ff9e"
---

<!-- page 1 -->

GOVERNMENT OF ANDHRA PRADESH€
ABSRACT
Andhra Pradesh Integrated Medical Attendance Rules, 1972 – Guidelines for recognition of Private
hospitals as referral hospitals for the purpose of treatment to State Government employees, retired
pensioners, and their dependents, M.L.As, Ex.-MLAs and other categories of persons as per rules –
Approved - Orders – Issued.
-----------------------------------------------------------------------------------------------------HEALTH MEDICAL AND FAMILY WELFARE (K1) DEPARTMENT
€Dated the 23rd May, 2005€€€

G.O.Ms.No.162€€€€€€€€€€€€€€€€€€€€€€€

€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€
Read the following:
1.€€€€ G.O.Ms.No.38, HM&FW(K1) Deptt., dt.23-1-1996
2.€€€€ G.O.Ms.No.465, HM&FW(K1) Deptt., dt.18-8-2003
3.€€€€ Govt.letter.No.15949/K1/2003-2, dt.23-12-2003.
4.€€€€ From the DME, A.P., Hyd., Lr.Rc.No.3374/MA-A/03, dt.4-5-2004.
5.€€€€ G.O.Ms.No.250, HM&FW(K1) Deptt., dt.11-8-2004
6.€€€€ From the DME, A.P., Hyd., Lr.Rc.No.20866/MA-A/2003,dt.28-12-2004.
7.€€€€ G.O.Ms.No.74, HM&FW(K1) Deptt., dt.15-3-2005.
<<<>>>
ORDER:
Government have been providing medical facilities with necessary infrastructure/equipment
facilities for various specialised treatments in Government hospitals in the State.€ There are
Government teaching hospitals, Specialist hospitals, District headquarters hospitals, Area
hospitals, Primary health centers, Rural dispensaries, Community health centers, in which
medical facilities can be availed by Government employees/retired employees and their
dependents and other categories of persons mentioned in Andhra Pradesh Integrated Medical
Attendance Rules, 1972, for their medical treatment. Simultaneously, medical health and care has
been expanded in the State with establishment of many private hospitals with super specialty
facilities.€ With a view of allowing these facilities to the State Government employees /retired
employees and their dependents and other categories of persons come under the purview of
Andhra Pradesh Integrated Medical Attendance Rules, Government have permitted them to secure
treatment in these hospitals with certain conditions.€ First the facilities available in the Government
Hospitals should be availed by the employees and the facilities which are not available can be sought
from the super specialty hospitals in the private sector.€ Accordingly, Government have issued

<!-- page 2 -->

orders in G.O.Ms.No.38, dated 23.01.1996 recognising seven private hospitals in the State and eight
private hospitals out side the State as referral hospitals for the treatment of employees /retired
employees and their dependents, subject to the following conditions:i) €The above private hospitals will be referral hospitals for all types of cases including acute
mycordial infracture; acute coronary disease; acute renal failure; severe cases of head and spinal
injury, road accident and cases of coma.
ii)€€€ Referral of patients to the above private hospitals should be from the Director, Nizam’s
Institute of Medical Sciences, Hyderabad /Sri Venkateswara Institute of Medical Sciences, Tirupati in
respect of above cases, only on a certificate given by them.
2.€Subsequently the above conditions have been liberalised and a total of 46 private hospitals in the
State and 18 private hospitals out side the State have been recognised as referral hospitals. Many
private hospitals are approaching Government for recognition of their hospitals as referral hospitals.
3.€ In order to take a comprehensive view and to adopt a uniform policy, Government have referred
the issue of framing draft guidelines to the Committee constituted for revision of Andhra Pradesh
Integrated Medical Attendance Rules, 1972 –vide reference third read above.€ In the letter sixth
read above, the Chairman of the Committee and Director of Medical Education has submitted
the draft guidelines to Government.
4.€The issue of framing guidelines for recognition of private hospitals as referral hospitals was
discussed with representatives of Indian Medical Association, A.P. Private Nursing Homes
Association (A.P.N.A.) and some of the corporate hospitals in the meeting held in the conference
hall of Director of Medical Education, Hyderabad on 11-01-2005. There was a general agreement on
the draft guidelines. Government have reviewed the matter again on 3-03-2005.€ In the said
meeting, it was decided to change two conditions regarding offering free treatment to Below
Poverty Line (B.P.L) persons/White Card Holders and adoption of two villages. It was also decided to
ask the hospitals to specify what diagnostic and therapeutic services are going to be offered by them
to five percent (5%) of their bed strength to the B.P.L. families through a Memorandum of
Understanding (M.O.U.) and identify two villages for adoption clearly specifying how they will work
in those villages to improve health care and health status of the population in those villages. These
two changes will bring in greater specificity and accountability and therefore monitoribility.
5.€ Government after careful consideration of the matter hereby approve the following guidelines
for recognition of private hospitals as referral hospitals for the purpose of treatment to State
Government employees, their dependents, retired State Government pensioners, and their
dependents, M.L.As, Ex.-MLAs and their family members and other category of persons mentioned
in Andhra Pradesh Integrated Medical Attendance Rules, 1972 on reimbursement basis:1)€ The private hospital should have bed strength of 100 and more in twin cities of Hyderabad and
Secunderabad, Visakhapatnam, Rajahmundry, Vijayawada, Guntur, Warangal and Tirupati.
2)€In respect of District headquarters, the bed strength should not be less than fifty (50).
3)€The hospital seeking recognition as referral hospital should have facilities for treatments for

<!-- page 3 -->

all types of diseases and surgeries, the hospital should have the following specialities supported by
specialist Doctors, infrastructure facilities, equipment etc:(i) Anesthesiology (ii) Cardiology (iii) Cardio thoracic Surgery (iv)Ear Nose Throat (ENT) (v)Emergency
Medicine (vi)General Medicine (vii)General Surgery (viii)Nephrology (ix)Neuro Surgery (x)Nuclear
Medicine (xi)Obstetrics & Gynecology (xii)Orthopedics (xiii)Pediatrics Pathology (xiv)Plastic
Surgery (xv)Pulmonology (xvi)Radiology (xvii)Surgical Gastro enterlogy (xviii)Surgical Oncology
(xix)Urology (xx)Physiotherapy Unit and (xxi) Dialysis Unit.
4)€In respect of private hospitals having one or more specialized treatments, they shall be given
recognition for that specialty only i.e. Kidney, Heart, Cancer, Neurology and Orthopedic etc.
5)€The strength of the specialist doctors, general doctors and para medical staff should be qualified
and adequate.
6) They should have own pharmacy, lab facilities and theatre facilities and ambulance for
emergency services.
7)€They should be able to provide 24 hours service to the patients.
8)€ Dental Services:i)€ Five in-patient beds, five dental chairs, ambulance facilities, facilities for control of infection,
laboratory, equipment, diagnostic facilities, arrangements for “X”- Ray unit etc.
ii)€ The hospital should be headed by a M.D. specialist in Dentistry services with a minimum of two
doctors and ten para medical staff.
9) The private hospitals should also convey their willingness and abide to the following conditions:(i) The Hospital should give free treatment for outpatient and in-patient services including
diagnostic, surgical, therapeutic and clinical services to the white card holders of the State of Andhra
Pradesh or persons below poverty line (B.P.L.) to a minimum of five percent (5%) of bed strength (for
inpatient services). The Hospital will enter into a Memorandum of Understanding separately on the
exact number of inpatients and outpatients, the types of diagnostic and therapeutic services to be
extended. The details of treatment should be properly documented in a register by the hospital.
(ii) The Hospital should give free medical treatment to students of Andhra Pradesh Social Welfare
Residential School/Tribal Welfare Residential School/ B.C. Welfare Residential Schools, S.T. Ashram
Schools, S.T. Hostels, G.V.V.K. Schools and Maabadi Schools whenever referred by the Principal of
the said School, any Govt. Medical Officer, District Referral Committee, District Social Welfare Officer
or P.D., I.T.D.A. or any authorised official to be notified by Govt. from time to time.
(iii) The private hospital should adopt at least two villages for providing better medical and health
services to the rural people. This includes free diagnostic services, conducting health camps once in
every month in the villages. The Hospital will enter into a Memorandum of Understanding
indicating the villages identified for adoption. In these villages, the hospital should take all steps to
improve the overall health status of the population with special focus in maternal and child health.
(iv) The Hospital shall furnish a monthly return in the following format to the Director of Medical

<!-- page 4 -->

Education, A.P., Hyderabad.
Sl No. Name, Age
and address
of patient

Institution
Particulars
Officer
of
who has referred reference

Disease
or Health
problem

Treatment
provided

Approximate
value of
treatment

€(v) Referral of patients to the private hospital should be from the Director, Nizam’s Institute of
Medical Sciences (NIMS), Hyderabad, Director, Sri Venkateswara Institute of Medical Sciences
(SVIMS), Tirupati, Superintendents of Government Teaching Hospitals and Superintendents of
district headquarters hospitals and Area Hospitals in the State. These Hospitals will first ensure that
facilities available with them and other Government hospitals are fully utilised in the first instance,
before referring the patients to the private hospitals recognised as referral hospitals.
(vi) The Hospital concerned should charge for all medical/surgical /diagnostic services including
major ailments of Heart Bypass surgery, Kidney transplantation, Cancer, Neuro surgery etc., given by
them under this scheme, as per the package rates prescribed by Government of India, Ministry of
Health and Family Welfare for C.G.H.S, Hyderabad and as adopted by the State Government in
G.O.Ms.No.74, H.M.&F.W. (K1) Deptt., dt.15-03-2005 or as may be prescribed by the State
Government or the Director of Medical Education from time to time.€ In respect of dental
treatments and Eye ailments, the package rates shall be as prescribed in G.O.Ms.No.74,
H.M.&F.W.(K1) Deptt., dt.15-03-2005 and as amended from time to time. The Director of Medical
Education/Scrutinising authority shall verify and ensure that the charges levied by the private
hospitals are as per the above rates, before certifying the net admissible amount.€ If the rates of
Private hospitals are less than the C.G.H.S. package rates/Government rates as per annexures to the
said G.O., the lowest rates of private hospitals shall be accepted for scrutiny and payment.
(vii) A 10% cut shall be imposed on the gross admissible amount within the ceiling limit as certified
by the Director of Medical Education, A.P. Hyderabad/ Scrutinising authority in respect of the cases
where the patient is admitted in the private hospitals recognised under emergency conditions
without referral letter from the hospitals mentioned at clause (v) above. The private hospitals
should also accept letter of credit (L.O.C.) from the Departments concerned for giving
treatment and also to give treatment on producing Identity card of the employee under emergency
circumstances, pending issue of letter of credit.
€(viii)The hospital will be inspected in each quarter by a team of Government doctors to be
constituted by Director of Medical Education /Superintendent of Government Teaching Hospital/
Superintendent of Government Head Quarter’s Hospital to ensure that the diagnostic, surgical,
therapeutic services and the overall quality of care in the private hospital are satisfactory.€ The
Director of Medical Education, A.P., Hyderabad or any officer authorised by Director of Medical
Education will conduct inspection periodically to verify and ensure that the said private hospital is
complying with all the conditions as stipulated above and verify the Registers and make
appropriate recommendation to Government through the Director of Medical Education for
necessary action.
ix)€ The Private Hospitals who desires to come under this scheme should submit the application
format as per Annexure to this order along with Memorandum of Understanding to the Director of
Medical Education, A.P., Hyderabad and a demand draft for Rs.30,000/- (Rupees thirty

<!-- page 5 -->

thousand only) from any of the Nationalised Banks drawn infavour of Director of Medical Education,
A.P., Hyderabad towards inspection fee.
x) The Director of Medical Education shall constitute a team of medical experts and Accounts
Officers to do a random sample detailed scrutiny of the bills reimbursed in favour of Government
servants etc for the treatment given to Government employees /retired employees and other
categories of persons as per APIMA Rules, 1972. Charted Accountants can be engaged by Director of
Medical Education for this purpose to satisfy that these cases are not over billed compared to others
and the services offered to B.P.L. persons. For this purpose, a yearly inspection fee shall be
Rs.30,000/- and collected from the hospital concerned.
xi) The Director of Medical Education after getting inspection by an inspection committee headed
by not less than Additional Director along with two (2) other specialists of the rank of the H.O.D. of
Medical College and after satisfying that the hospital is fulfilling all the conditions and is able to
provide quality treatment based on inspection repot, the Director of Medical Education will enter
a Memorandum of Understanding (MOU) with the Management of the hospital. Thereafter, the
Director of Medical Education will issue necessary orders notifying the said hospital as a referral
hospital, duly mentioning the conditions, details of M.O.U. and shall also communicate to all the
H.O.D.s, Regional and District Officers, All scrutinising/ Supervising authorities, Government, and
all other concerned.€ The Director of Medical Education shall take utmost care in approving the
private hospitals as referral hospitals. He shall also get it published in the News papers.
xii) The private hospitals which have already been recognised should also follow these
guidelines to continue their recognition within a period of one month from the date of issue of this
order, duly applying to the Director of Medical Education, A.P., Hyderabad.
(xiii) The recognition so accorded will be valid for a period of three years only from the date of
recognition and the Hospital should submit application before the Director of Medical Education,
A.P., Hyderabad seeking renewal within three months before the date of expiry of the said period,
together with a demand draft for Rs.30,000/- (Rupees thirty thousand only) from any nationalized
bank drawn in favour of Director of Medical Education, A.P., Hyderabad towards application
form and inspection.xiv) The permission accorded to the hospital is liable for cancellation and such
other action as deemed fit, including de-recognition of the hospital and initiate criminal action as per
law against the hospital, whenever the State Government forms the opinion based on
inspection or enquiry into the allegations that the said Private Hospital is not providing treatment to
the State Government employees/ retired employees and their dependents etc. as stipulated above
and violates the conditions mentioned therein, and indulge any irregularities in respect of excess/
bogus claims, cheating the patient or Government or resorting to any unlawful activities etc, after
giving fifteen (15) days notice to the hospital and pass appropriate orders, after considering the
representation, if any, offered by the said Hospital.
6.€ The Director of Medical Education, A.P., Hyderabad shall take necessary further action in the
matter accordingly.
7.€€This order issues with the concurrence of Finance Department vide their U.O.No.3830/90/A1/
ExpM&H/05, dated 03-05-2005.

<!-- page 6 -->

(BY ORDER AND IN THE NAME OF THE GOVERNOR OF ANDHRA PRADESH)
DR. I.V.SUBBA RAO
PRINCIPAL SECRETARY TO GOVERNMENT
€To
The Director of Medical Education, A.P. Hyderabad
The Commissioner, A.P. Vaidya Vidhana Parishad, A.P., Hyderabad.
The Director of Health, A.P., Hyderabad.
The Commissioner of Family Welfare, A.P., Hyderabad.
The Commissioner, Ayush, A.P., Secunderabad.
The Director, Nizam’s Institute of Medical Sciences, A.P. Hyderabad.
The Director, Sri Venkateswara Institute of Medical Sciences, Tirupati.
The Secretary, Indian Medical Association, Hyderabad.
€(through the DME, A.P., Hyd.)
The Secretary, A.P. Nursing Homes Association, Hyderabad.
€(through the DME, A.P., Hyd.)
All Heads of the Departments under the control of HM&FW Department.
The Commissioner of Social Welfare, Masabtank, A.P., Hyderabad.
The Director of Tribal Welfare, Masabtank, A.P., Hyderabad.
The Commissioner of B.C. Welfare, Masabtank, A.P., Hyderabad.
The Secretary, A.P. Social Welfare Residential Schools Society, A.P., Hyderabad.
All District Collectors in the State.
All the Superintendents of Government Teaching Hospitals in the State.
All Superintendents of District Head quarters Hospitals in the State.
All District Medical and Health Officers in the State.
All District Referral Committee in the O/o District Collectors in the State.
All the Superintendents of Police in the State.
All Commissioners of Police in the State.

<!-- page 7 -->

The Commissioner, Printing, Stationery and Stores Purchases (Printing Wing)€
€ Government Press, Chanchalguda, Hyderabad (with a request to publish and furnish 500€€€€
€€€ printed copies of the G.O. to the Govt. and 1000 copies to the DME, A.P. Hyderabad)
Copy to:€ The Registrar, High Court of Andhra Pradesh, Hyderabad.
The Registrar, A.P. Administrative Tribunal, Hyderabad.
The Pay and Accounts Officer, Hyderabad.
The Accountant General, (A&E), A.P., Hyderabad.
The Accountant General (Audit), A.P., Hyderabad.
The Finance (Exp. HM&FW.I) Department.
The General Administration (SC-X) Department.The General Administration (SR/Poll.) Department.
Social Welfare Department
Social Welfare (T.W.) Department
The HM&FW (O.P.) Department.
The President, A.P. Secretariat Association, Secretariat Buildings, Hyderabad.
The President, A.P.N.G.O’s Association, 5-9-1112, Chaitanya Gun Foundry, Hyderabad.
The President, A.P.T.N.G.O’s Association, Secretariat, Hyderabad.
The Spl. Secy. to C.M.
P.S. to Minister (Finance)
P.S. to Chief Secretary to Government
P.S. to Prl. Secretary/ Secretary to Govt., HM&FW Department.
P.S. to Prl. Secy. (W&P), Finance Department.
P.S. to Prl. Secy. Social Welfare Department,
P.S. to Prl. Secy. Social Welfare (T.W.) Department.
P.S. to Secy. Law Department.
P.S. to Secy. to Govt. (Services), General Administration Department.
// FORWARDED :: BY€ ORDER //
SECTION OFFICERANNEXURE TO G.O.Ms.No.162, HM&FW(K1) Deptt., Dated 23-05-2005

<!-- page 8 -->

FORMAT TO BE SUBMITTED ALONG WITH THE APPLICATION FOR RECOGNITION OF PRIVATE
HOSPITALS AS REFERRAL HOSPITAL.
1 Name of the Private Hospital and its full address:
2 Name of M.D. or Authorised person for correspondence / Letter of Authority:3 Name and Address of Pvt. Ltd or Company/ Society/ Trust which established the hospital, with
details:4 Whether owned building or Whether lease/rented building, with details:5 The date of establishment of hospital:6 Total area of Hospital, a) Open area:€€€€€€€€€€€€€€€€€€€ b) Constructed area:7 Bed strength:8 No. of qualified Doctors, their names, qualifications:9 No. of Para Medical Staff (list to be enclosed):10 No. of other staff: (list to be enclosed):11 No. of€ specialties available (with details):12 O.P.D. available details, ambulance services:13 Equipment details:14 No. of operation theatres:15 Pharmacy fecilities:16 Lab-fecilities:17 X-Ray Unit & Other related equipment:18 Whether any branches of Hospital setup, if so details:19 Whether recognition is sought for main hospital, or branches also, if so details:(separate application shall be submitted for each branch)
20 The names of Villages with their full address to be adopted by the Hospital:21 Whether hospital is having any other organizations /Institution:22 Specify the other affiliated Institutions including Medical / Dental/Paramedical or other
educational courses:-I hereby declare that the information furnished above is true to the best of my
knowledge and belief and if it is found that any wrong information is furnished or suppressed the

<!-- page 9 -->

material facts, I will take full responsibility for the consequential action as per law.€ The
management of the Hospital will abide and follow the guidelines issued in G.O.Ms.No.162,
H.M.&F.W.(K1) Deptt., dt.23–05-2005 and instructions issued thereon by Government from time to
time in the matter.
Place:€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€
€ €€€€ €€€€€€€€€€€
€€ (Signature)
Dated:€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€ (Name and Designation and full address official seal.)
