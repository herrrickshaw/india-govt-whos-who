---
doc_id: "c46b9ce7dd8cef29"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f66d647fe3e72d2f"
---

<!-- page 1 -->

GOVERNMENT OF ANDHRA PRADESH
ABSTRACT
HM&FW – APIMA Rules, 1972 – Reimbursement of medical charges to the pensioners –
Certain anomalies in Rules – Enhancement of the Medical reimbursement from
Rs.1.00 lakh to 2.00 lakhs to the retired Government servants and their dependants on
par with serving Government employees – Certain Amendment – Orders – Issued.
--------------------------------------------------------------------------------------------------------------------HEALTH, MEDICAL AND FAMILY WELFARE (K1) DEPARTMENT
G.O. Ms. No. 397

Dated: 14 -11-2008
Read the following: -

1. G.O. Ms. No. 105, HM & FW (K1) Department dated 9-4-2007.
2. From the President/General Secretary, Andhra Pradesh Teachers’ Federation
Lr. No. 144/2006-07 dated 14-8-2007.
3. From the President/General Secretary, A.P. State Government Retired Employees
Association Lr. No. Gen1/MFC/062-R (1) dated 20-11-2007.
4. From the Vice President, State Pensioners’ Association letter dated.17-9-2007.
5. From the Director of Medical Education, A.P,Hyderabad Lr.Rc.No.MA/1/2007
dated 13-11-2007.
6. From the Finance Department U.O. Note No. 9310-A/122/A1/PC.I/2008, Finance
(FC.I) Department, dated 5-8-2008.
<<>><<>>
O R D E R: In the Government Orders first read above the Government have issued orders
providing maximum ceiling limit (Rs. 2.00 Lakhs/Rs. 1.00 Lakh) of medical
reimbursement to the serving and retired employees is as follows:
“The maximum ceiling limit of Rs.2.00 lakhs (Rupees two lakhs only) is
fixed for the major ailments of Bypass Heart surgery, CABGS, Double valve
replacement, Open Heart procedure, Aortic valve replacement, Kidney
transplantation, Cancer and Neuro-Surgery to Brain irrespective of package
rates of CGHS for the treatment obtained in private hospitals, and also for
the treatment obtained in NIMS, Hyderabad and SVIMS, Tirupati or actual
cost whichever is less. This ceiling limit of Rs.2.00 lakhs is applicable to the
serving employees and their dependents. In respect of retired employees,
their dependents and family pensioners, the ceiling limit is Rs.1.00 lakh for
these ailments, as per the recommendations of P.R.C.2005”.
2.
In the letters 2nd to 4th read above, the associations have represented the
Government for enhancement of the medical reimbursement from Rs.1.00 lakh to Rs.2.00
lakhs on par with serving Govt. employees.

(Contd.2)

<!-- page 2 -->

:: 2 ::

3.
The Finance (PC.I) Dept., in the U.O. Note 6th read above have referred the matter
to the Anomalies Committee under the Chairmanship of Sri N. Ranga Chary. The
Committee has recommended that the limit to medical reimbursement in respect of both
the serving employees and the pensioners shall be the same viz., Rs. 2.00 Lakhs.
Accordingly, the Finance (PC.I) Dept., has forwarded the report of the Anomalies
Committee and requested to take further action on issuance of the orders of
enhancement of Medical reimbursement to the Pensioners on par with Serving
Employees.
4.
Government after careful examination hereby issue the following amendment
by replacing the para 7 (1) (b) of the G.O. Ms. No. 105, HM & FW (K1) Department dated
9-4-2007.

AMENDMENT
7 (1) (b)

5.

The maximum ceiling limit of Rs.2.00 lakhs (Rupees two lakhs only) is fixed for
the major ailments of Bypass Heart surgery, CABGS, Double valve replacement,
Open Heart procedure, Aortic valve replacement, Kidney Transplantation,
Cancer and Neuro-Surgery to Brain irrespective of package rates of CGHS for
the treatment obtained in private hospitals, and also for the treatment obtained in
NIMS, Hyderabad and SVIMS, Tirupati or actual cost which ever is less. This
ceiling limit of Rs. 2.00 lakhs is applicable to the retired employees (pensioners)
and their dependents also on par with serving employees for these ailments, as
per the recommendations of P.R.C. 2005 read with the recommendations of
Anomalies Committee.
These orders shall come into force from the date of issue of these orders.

6.
This order issues with the concurrence of Finance(Exp..HM&FW-I) Dept., vide
their U.O.No.11868/860/A.2/Exp.HM&FW-I/08, dated.16-09-2008.
(BY ORDER AND IN THE NAME OF THE GOVERNOR OF ANDHRA PRADESH)
P.K.AGARWAL
PRINCIPAL SECRETARY TO GOVERNMENT
To
The Director of Medical Education, A.P. Hyderabad.
The Director of Nizam’s Institute of Medical Sciences, Panjagutta, Hyderabad.
The Director, Sri Venkateswara Institute of Medical Sciences, Tirupati.
The Secy., State Legislature, Assembly Buildings, Hyderabad.
(Contd.3)

<!-- page 3 -->

::3::

All the Departments of Secretariat,
All the Heads of Departments under control of Health, Medical & Family Welfare
Department.
All the other Heads of the Departments Govt. of Andhra Pradesh.
All Superintendents of Government Teaching Hospitals.
The Legislature (MC/Pension) Department.
The Civil Surgeon Specialist, Civil Dispensary, A.P. Secretariat, Hyderabad.
All Recognized Private Hospitals through the Director of Medical Education, A.P.
Hyderabad.
All the District Collectors in the State.
The Director of Treasuries and Accounts, A.P. Hyderabad
All the District Treasury Officers in the State.
The Accountant General, A.P, Hyderabad.
The Pay and Accounts Officer, A.P, Hyderabad
The Commissioner of Printing Stationery and Stores Purchase (Printing wing ),
Hyderabad
( with a request to publish the amendment in para 4 of the G.O.(two copies)
Copy to:
The General Administration (SC-X/Poll) Department
The General Administration (SR) Department
The Spl. Secy to C.M. / P.S. to Minister (Finance & Health)
P.S. to Prl. Secy. (W&P), Finance Deptt.,
P.S. to Prl. Secy./Secy., HM&FW Deptt.,
Finance (Expr.HM&FW-I) Department.
The concerned Associations.
SF/SC.
//FORWARDED::BY ORDER//
SECTION OFFICER.
