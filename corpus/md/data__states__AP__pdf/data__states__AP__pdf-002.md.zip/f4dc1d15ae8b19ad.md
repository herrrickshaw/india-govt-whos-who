---
doc_id: "f4dc1d15ae8b19ad"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "665a3cb0d82d5488"
---

<!-- page 1 -->

CENTIII; FOIT DIST'ANCE EDUCATION
ACHAIIYA NAGAIiJUNu\ UNIVERSITY:: NAGAITJUNA NAGAII-522510
Office: 08(t3-234622t1

SYED ZAINULABDIN,
DEPUTY ITEGISTRAR (Exams),
No.ANU/CDE/VI Semester

Exam/Notificationl2D2l,

234622e
Date:23-10-2025

NOTIFICATION
Sub: ANU - CDE - Conduct of VI Semester Regular & Supply exams to all UG
Courses - Notif.icatioir issued - Reg.
Ret 1. The Vice-Chancellor Proceedings No. ANU/CDE(CSyVI Sem. Project./ Nol.ifi.
permission /Sep.l20|L5, dated: 04-09 -2025,
2. Vice-Chancellor's orders dated. 03-09-2025.
**{<**

The Vice-Chancellor has,crdered that the Centre for Distance Education, ANU. to
conduct Vl Semester (Regular & Supplementary) examinations for the UG courses to the
fol lowing batches d uring Novembcr/December, 2025.

sl.

Batch

Course

Sernester

No
I

A-21 & C-22

UC

2.

c-21

UG

VI Semester (Regular)
VI Sernester (Supply)

L For payment of Project/Viva'y'oce fee

Rs. 1,000.00

2.Last date for payment of exanrination fbe

05-1 l-2025

The Examination f'ee payable through offline only

5T+rC.+'t E
DEPUTY REGrsrRAr

(cDE - EXAMTNATTO\S)

To

The Editors of all News Papers - With a request to publish the notification as news itern in allthe claily
newspapers.

Copy to the Director, CDE, ANU.
Copy to the Coordinator, CDE, Examsi, ANU.
Copy to the Deputy Registrar, UG Exams, CDE, ANU.
Copy to the Assistant Registrar, Coorrlinator Office, CDE, ANU.
Copy to all study centres of CDE - with a request to notify in the notice board for communication.
Copy to all P.A. to Registrar/Rector/Vice-Chancellor, ANU

l t f LJo
