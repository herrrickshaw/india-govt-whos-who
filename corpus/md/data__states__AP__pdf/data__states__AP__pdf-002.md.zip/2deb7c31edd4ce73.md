---
doc_id: "2deb7c31edd4ce73"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8a852057f1b6a9b5"
---

<!-- page 1 -->

<!-- page 2 -->

ACHARYA NAGARJUNA UNIVERSITY
CENTRE FOR DISTANCE EDUCATION
Recognized by UGC-Distance Education Bureau (DEB), New Delhi
Dual Mode NAAC “A+” Grade with 3.46 Score
PROGRAMMES OFFERED IN ANUCDE (SEMESTER MODE) FOR THE ACADEMIC YEAR 2025 BATCH
PG SCIENCE PROGRAMMES (08)

PG ARTS PROGRAMMES (11)

M.Sc. BOTANY
M.Sc. ZOOLOGY
M.Sc. PHYSICS
M.Sc. CHEMISTRY
M.Sc. MATHEMATICS
M.Sc. STATISTICS
M.Sc. COMPUTER SCIENCE
M.C.A

M.A. ENGLISH
M.A. TELUGU
M.A. HINDI
M.A. SANSKRIT
M.A. ECONOMICS
M.A. HISTORY
M.A. POLITICAL SCIENCE
M.A. SOCIOLOGY
MSW MASTER OF SOCIAL WORK
M.A. JOURNALISM & MASS COMMUNICATION
M.A. HUMAN RESOURCES MANAGEMENT

PG COMMERCE & MANAGEMENT PROGRAMMES (03)
M.COM - ACCOUNTANCY
M.COM – BANKING
M.B.A GENERAL (Two Specializations)
Last date for payment of
admission fee : 10-10-2025
FOR ADMISSION VISIT OUR WEBSITE

www.anucde.info
For any Information Contact our
email Id: anucdedirector@gmail.com
For General Enquiry Call on:
0863-2346222 / 2346208 / 2346214

LIBRARY PROGRAMMES (01)
MLISc MASTER OF LIBRARY & INFORMATION
SCIENCE

<!-- page 3 -->

ACHARYA NAGARJUNA UNIVERSITY
CENTRE FOR DISTANCE EDUCATION
Recognized by UGC-Distance Education Bureau (DEB), New Delhi
Dual Mode NAAC “A+” Grade with 3.46 Score
PROGRAMMES OFFERED IN ANUCDE (SEMESTER MODE) FOR THE ACADEMIC YEAR 2025 BATCH
Sl.No. Programme
code

Programme Name

Eligibility Criteria

Duration

Medium

1st Year
Admission
Fee Rs.

English

15200

English

15200

English

15200

English

15200

English

7800

English

15200

PG SCIENCE PROGRAMMES
1

01

M.Sc. BOTANY

2

02

M.Sc. ZOOLOGY

3

03

M.Sc. PHYSICS

4

04

M.Sc. CHEMISTRY

5

06

M.Sc. MATHEMATICS

6

138

M.Sc. STATISTICS

B.Sc. with any two of the Following Subjects: Botany,
Zoology, Chemistry, Forestry, Biotechnology, Food
2 Years
Technology, Medicinal Botany, Environmental Science
(4 Sems)
or
Any two Life Science subjects
B.Sc. with Zoology/ B.Sc. Fishery Science/ Aquaculture/
2 Years
Industrial Fish and Fisheries/ B.Sc. with all Life
(4 Sems)
Sciences & Environmental Sciences
B.Sc. with Physics & Mathematics
2 Years
(4 Sems)
2 Years
B.Sc. with Chemistry
(4 Sems)
B.A/B.Sc. with Mathematics as one of the Three equal subjects or 2 Years
as a Main Subject
(4 Sems)
B.A/B.Sc. with Mathematics and Statistics
(Or)
B.Tech./B.C.A. Candidates( those who studied Intermediate with
M.P.C. – Mathematics, Physics and Chemistry) with work
2 Years
experience exclusively in Data Science/ Data Analysis for  5 years
(4 Sems)
may also considered for this course.
For those candidates the course duration should be 2½ years. In
the Pre I Semester they should qualify in Basic Statistics - Four

<!-- page 4 -->

theory and One Practical Paper.

7

109

M.Sc. COMPUTER SCIENCE

8

194

MCA

The work experience should be certified by Data Science / Data
Analysis division head for the concerned Company.
Any bachelor’s degree with B.Sc. Computer Science
(OR) B.Sc. Information Technology (OR) B.C.A. (OR)
B.Com. Computer Applications (OR) B.A. Computer
Applications (OR) Any Bachelor’s degree with
2 Years
computer science or computer applications as one of (4 Sems)
the subjects (OR)
B.Sc. Computer Applications with Mathematics as
course of study at Intermediate/10+2 Level.
1. Any Bachelor’s Degree with 50% aggregate (45%
for BC, SC & ST) (other than BFA & BOL) with
Mathematics at Inter or Degree. If Mathematics is
not studied at Degree level, Mathematics at Inter
level is required. Ex: B.Com Students with Inter
2 Years
MEC Group are eligible.
(4 Sems)
2. Pass in ANUCDE Entrance Test / ICET/ Any
Common Entrance test conducted by State or
Central Government with valid Rank in that
Academic Year.

English

22000

English

24000

PG ARTS PROGRAMMES
9

14

M.A. ENGLISH

10

15

M.A. TELUGU

11

190

M.A. SANSKRIT

12

110

M.A. HINDI

13

16

M.A. ECONOMICS

14

17

M.A. HISTORY

2 Years
English
(4 Sems)
2 Years
Any Bachelor’s Degree with Telugu
Telugu
(4 Sems)
Any Bachelor’s Degree with Sanskrit / M.A. Telugu with 2 Years
SANSKRIT
at least one Sanskrit paper
(4 Sems)
Any bachelor’s degree with Hindi as second Language/ B.A. with
Hindi as Special subject/ Rastra Bhasha Praveena from Dakshin
2 Years
Bharat Hindi Prachar Sabha of Madras / Sahitya Sammalan or
HINDI
(4 Sems)
Visharad Diploma or Hindi Vidwan program ofAllahabad or
Hindi Prachar Sabha, Hyderabad
2 Years
Any Bachelor’s Degree
Telugu
(4 Sems)
2 Years
Any Bachelor’s Degree
Telugu
(4 Sems)
Any Bachelor’s Degree with English

6730
6730
6730

6730

6730
6730

<!-- page 5 -->

15

18

M.A. POLITICAL SCIENCE

Any Bachelor’s Degree

16

19

M.A. SOCIOLOGY

Any Bachelor’s Degree

17

21

Any Bachelor’s Degree

18

29

19

191

MSW MASTER OF SOCIAL
WORK
M.A. JOURNALISM & MASS
COMMUNICATION
M.A. HUMAN RESOURCES
MANAGEMENT

Any Bachelor’s Degree
Any Bachelor’s Degree

2 Years
(4 Sems)
2 Years
(4 Sems)
2 Years
(4 Sems)
2 Years
(4 Sems)
2 Years
(4 Sems)

Telugu

6530

Telugu

6530

English

10030

English

7730

English

8930

English

6730

English

6730

English

23000

English

10675*

PG COMMERCE & MANAGEMENT PROGRAMMES
20

12

M.COM - ACCOUNTANCY

B.Com/ BBM/BBA

21

13

M.COM – BANKING

B.Com/ BBM/BBA


22

193

M.B.A GENERAL
(Two Specializations)



2 Years
(4 Sems)
2 Years
(4 Sems)

Any Bachelor’s Degree with 50% aggregate (45%
for BC, SC & ST) (other than BFA & BOL) with
Mathematics at 10th or Inter or Degree.
2 Years
Pass in ANUCDE Entrance Test / ICET/ Any (4 Sems)
Common Entrance test conducted by State or
Central Government with valid Rank in that
Academic Year.

LIBRARY & INFORMATION SCIENCE PROGRAMME
23

141

M.L.I.Sc (MASTER OF
LIBRARY & INFORMATION
SCIENCE)

B.L.I.Sc

1 Year
(2 Sems)

 First Year Admission fee includes Tuition Fee, Theory Examination fee, Assignment Examination Fee, Practical Examination fee and
Project Fee for appearing examinations.
 Separate examination fee is payable for writing Supplementary/Betterment examinations.
 Those who failed to pay the II and/or III year Admission fee as per schedule, must apply for “Regularization of break of study fee Rs.200
per year”, Late fee Rs.100, Tatkal fee Rs.500 and should pay supplementary examination fee to write II and/or III year examinations.
 *Final Year Admission Fee includes: Tuition Fee + All Exams Fees + T.C cum S.C + M.C. + O.D. + Consolidated Marks Memo.
 Processing fee may apply in addition to the Admission fee to all Programmes.
