---
doc_id: "cd9fc9c66f5fcac0"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 31
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b014bb888d67717b"
---

<!-- page 1 -->

ERSTWHILE PMKASAM DISTRICT _ DETAILS OF EMPLOYEES WORKING

IN THE

CADRE OF VILLAGE REVENUE OFFTCER (Gr.r)

(As per Annexure to circular Memo No.256656lspFqcl2026, dated.

0g.06.2026)

Name of the Secretariat
Revenue Depaftment - REV01

Department and Code
Name of the Head of the

CCLA, AP, Mangalagiri

Department and Code

- REV02

Details of the Post:

i. Name of the Rule
(Special Rules/General

A.P. Village Revenue Officers Seruices
Rules 2008

Rules) & Year

ii. Name of the Post

Village Revenue Officer (Gr.I)

iii. Post Category as per
Rules

iv. Gazetted (Yes/No)

No

v. If Gazetted, Gazetted
No

Level

vi. Scale of Pay as per llh
PRC

25,220 - 80,910/-

vii. Present local cadre as
per Presidential Order,

L975 (District, Zone -t,
Zone -2, Zone -3, Zone -

District cadre

4, Multi-Zone, State)

viii. If District cadre, indicate
erstwhile District (13)

Prakasam District

name

ao,,.Oor$tr

yr,

w

4t
DP

S"e(A=lntt",)

Prakasam

V

<!-- page 2 -->

\1Ro G,. t)
A.p puBlrc EMpLoyMENT (ORGANISATION OF LOCAL CADRE AND REGULATION OF DIRECT RECRUTTMENT) ORDER 2025
0)

t,t

Type

of
Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
FinaU
Provisi
onaU

this

o
9u
(9(,
Uo
(,c.

category

o

Seniority list

ority
(a)
Procee

dings
Tentati Numbe
VE

r

(4)

(s)

(b)

Num
ber

Name of the

Government
Servant

Gender
MIF

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in

o
o)
o
o)
G

.9

!

AP
!6

t

'-6C)
6E!
-0)(Je
>>E
c:(J

=

bE
,z

(U

E

po

6

Date

o.=o

.9 .g

0i
t

-b

Eo
>.ltj o

E - g;';
FP;SX
!!-oI 9'afl
c c
E

E

-1e
sa: ^8
if.>

d
U1

.9

q)

.o-P
e>Y
'=
oo

o.

a
€
fl

.E

,9

e

OJ

;i(9,
o9d
tsl:Q

,F

-bda,
q cE
oEc

z.

oo-

!

o)

o

o

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(l7)

(18)

(le)

(20)

Ravi Ramachandruni

M

14181491

9398099012

24.06.t964

01.01.2002

NA

NA

NA

NA

NA

Prakasam

Prakasam

K Rajashekar Reddy

M

1,1413801

9440923899

30.07.1970

01.01.2002

NA

NA

NA

NA

NA

Prakasam

Prakasam

Kondrkandukuru

A.Ramakrishna

lvl

14388623

9010184944

15.08.1970

01.01.2002

OC

NA

NA

NA

NA

Prakasam

Prakasam

Chirala

Perala Sivalayam
Vedi

N.V. Rama Rao

M

L4175750

80194 00836

t5.07.7972

01.01.2002

NA

NA

NA

NA

NA

Prakasam

Prakasam

5

Kandukuru

Mopadu

Final

K. Kotaiah

M

1418006 1

99482s4209

t5.07.7975

01.0 1.2002

OC

NA

NA

NA

NA

Prakasam

Prakasam

6

Bestavaripeta

Bestavaripeta -li

Final

I.Sekhar Reddy

M

t4L69349

9849377367

15.08.t917

01.01,2002

NA

NA

NA

NA

NA

Markapuram

Prakasam

7

Gudlur

Elurupadu

45t

Ch.Mallakarjuna Rao

M

L4429214

7674809727

06.05.1975

01.01.2006

SCMala

NA

NA

NA

NA

Prakasam

Prakasam

I

Gudlur

Chevuru

Final

Dt:72.11.20L7

s60

Sk.Haseenbasha

M

L479t777

9.+41 108321

16.11.1976

01.01.2006

BC-E

NA

NA

NA

NA

Prakasam

Prakasam

9

Yerragondapalem

Yerragondapalem-4

Final

Rc.A3.19
Dt15.09.2014
56/2010

270

N.Chandrasekhar

M

r4ru927

7670936872

09.10.1964

08.07.2007

NA

NA

NA

NA

NA

Markapuram

Prakasam

10

Tarlupadu

Meerjapeb

F

t44t3776

89855 65075

06.01.1967

08.02.2007

NA

NA

NA

NA

NA

Prakasam

Prakasam

11

Pullahcheruvu

Mutukula

t4

14184080

94927575r2

06.01.1974

08.02.2007

NA

NA

NA

NA

NA

Prakasam

Prakasam

t2

Markapuram

l'1

14189905

91 105886216

10.07.1977

08.02.2007

NA

NA

NA

NA

NA

Markapuram

Markapuram

13

Korisapadu

Pamidipadu-1

Ramireddy Subbarao

M

74t80027

9949366680

u.u.1967

02.0s.2007

NA

NA

NA

NA

NA

Prakasam

Prakasam

74

Pedacherlopalli

Vegalayapalli

Final

Rc.A3.19
Dt15.09.2014
55/2010

50

I.Pitchireddy

M

14t7t755

94973767t9

08.01.1972

01.01.2002

NA

NA

NA

NA

NA

Prakasam

Prakasam

15

Kurichedu

Kurichedu-1

Final

2/PRM(v
Ro)10217

69

K.V.NagEraju

M

14429206

9866834s32

01.07.1968

08.02.2007

NA

NA

NA

NA

NA

Prakasam

Prakasam

(1)

(2)

(3)

1

Kanigiri

N Gollapalli

2

Konakanmitla

Chinnarikatla

3

Kandukuru

4

Ward Sachivalayam
15

Final

(6)

Rc.A3.19
Dt15.09.2014
56/2010

Rc.A3.19

s6/2010

Dt15.09.20 14

(7)

49

55

Rc.A3.19
Dt15.09.20 14
56/2010

No.COLP
KM-

Nagaraja Kumari
Palutla

Final

Final

Rc.A3.19

56l20ro
Rc.A3.19

56/2010

Dt15.09.2014

52

D. Dasharadha Rami

Dt15.09.2014

28.t2.20t6

M V M Sesachalam

Reddy

<!-- page 3 -->

OJ

Type

of

I
Sl.No

o
Seniority list

Seniori
Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:

ority

Final/

(a)

Provisi

Procee

onal/ dings
Tentati Numbe
VE

f

(s)

(1)

(2)

(3)

(4)

16

Ongole

Lawyerpeta

Final

77

Naguluppalapadu

Maddiralamuppalla

18

Tarlupadu

Thummalacheruvu

19

Chimakurthy

Ilapavulur

Final

OJ

Num

(b)

ber

Name of the
Government
Servant

Gender

M/F

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in
this
category

Date

(6)

Rc.A3.19
Dt15.09.2014
56/2010

Rc.A3.19
Dt15.09.2014
5612010

9r
c5 L/,
(Jo
(,c.

c

o
.E

g)-

.=o
>o
O-

!G

(u
6

-b
co

>og'

s-gF;
FE;EI
! I B afl

o

po

.-oo
o=:
-o (J .if
->=
!=0)cc
.og
E
f,C
c

.E
!
c

=

,z

=)
o

o

c

c(u
E

3

bE

EB
-Zr--^O
=^

v.=

.9

d
a
OJ

o-

q
o

U
'tr
.q
!

o

e

c)

q

6..

E (9
Bd

bBEo
tt:Q
EEE
i5Ec

-'=

o

'6

z.

o.

o
o

(7)

(8)

(e)

(10)

(11)

(L2)

(13)

(14)

(ls)

(16)

(L7)

(18)

(le)

(20)

401

Pasumarthi
Hanumantharao

M

14185306

9030603993

01.01.1965

08.02.2007

NA

NA

NA

NA

NA

Prakasam

Prakasam

G.Srinu

M

74t729L2

9494023047

07.05.7967

09.01.2008

NA

NA

NA

NA

Prakasam

Prakasam

351

Kasiviswaswara Reddy
Yeruva

M

14772843

9000449885

t9.07.1973

09.01.2008

NA

NA

NA

NA

NA

334

R. Baburao

M

L4772640

9390536044

05.01.1971

06.02.2008

iga) G-

NA

NA

NA

NA

oc-

Prakasam

Prakasam

Prakasam

II
20

Marripudi

Chimata

Final

27

Konakanmitla

Nagarajukunta

Final

22

Ponnalur

K.Agraharam

23

Kandukuru

Janardhana Colony

Final

24

Karamchedu

Daggubadu

Final

25

Mundlamur

Pasupugallu

Final

26

Santhanuthalapadu

P.Gudipadu

Final

27

wtElem

Nekunampuram

Final

28

Peddaraveedu

Maddalakatta

Final

29

Marripudi

Ankepalli

Final

30

Mundlamur

Umamahes,warapura
m

Final

31

Tarlupadu

Pothalapadu

Final

Rc.A3.19

56/2010
Rc.A3.19

s6lz0to

Rc.A3.19

s6l20Lo
Rc.43.19

s6/2010
Rc.43.19

56/2010
Rc.A3.19

s6/2010
Rc.A3.19

56/2010
Rc.A3.19

s612010
Rc.A3.19

s6/2010
Rc.A3.19

56/20t0
Rc.A3.19

56/2010

Dt15.09.2014

335

P Yedukondalu

M

t4L727tt

9347457445

09.01.1974

06.02.2008

tr Gr:

Yes

NA

NA

NA

0t15.09.20 14

280

K. Janaiah

I,4

14172787

995L+89779

30.06.1969

2 1,02.2008

Sc Male

NA

NA

NA

NA

Prakasam

Prakasam

M.Srinivasulu

M

t4t72633

70 13669945

06.0L.1974

2 1,0s.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Prakasam

Dt15.09,20 1 7

450

K.Bramaiah

M

t4190076

970t404t28

01.07.1966

20.05.2008

SC

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

392

Srilakshmi Banala

F

t4t72623

9640088022

08.01.1965

2 1.05.2008

OCOeI
aga)

NA

NA

NA

NA

Prakasam

Prakasam

Dt15,09.2014

106

B.Guravayya

M

t4L72705

9666633916

01.05.1965

21.0s.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

t9z

K Ravi Kumar

M

74t72463

8s00084322

01.07.1965

21.05.2008

BC-D

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

75

K Mastan

M

74772609

9100860 167

01.08.1965

21.05.2008

NA

NA

NA

NA

NA

Prakasm

Prakasam

Dt15.09.2014

76

S Krishnaiah

f4

t4777498

99662874s2

13.06.1966

21.05.2008

OC

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

77

Sk Shabeer

M

L4t72608

9948401486

07.01.1967

21.05.2008

NA

NA

NA

NA

NA

Dtl5.09.2014

707

P.Seshagiri Rao

M

14772706

9848029920

06.09.1967

21.0s.2008

NA

NA

NA

NA

NA

Dtl5.09.2014

78

Venkateswarlu Borra

M

t4172497

99499 66091

07.10.L967

21.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Prakasam

Prakasam

<!-- page 4 -->

OJ

Type

of

lt

o
OJ
Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
Final/

ority
(a)

Provisi Procee

onal/
dings
Tentati Numbe
VE
f

Num

(b)

)Qu
o.

ber

Name of the
Government
Servant

Gender

MIF

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in

this
category

O ttt
q,)o
a-

o
f
ol
o
c

E

o

=
1l
'=

(t)
rE

Date

o

I

€

, >cEHO
6
EP
!6_
E-EF;
cLO i tg
.-60
E6€
Ef $
- >-c EE
E-o
c c
c:(J
E,l.=o

(J

d

E

U)

o
o.
o
G

t

6

o
6.,

:=(9o

beP
Ur:lI
EFe
i5Ec

.og
2e
bE
2z

E-19E
g
=aX
9.>

€
o

'6

z.

o.
o.

c)

q

ts e5

o

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

(18)

(le)

(20)

Du5.09.2014

148

Hari Adapa

M

747726L9

9908076006

24.t2.7967

21.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

79

V Nageswara Rao

M

74772753

9705479253

17.06.1969

21.05.2008

oc

NA

NA

NA

NA

Prdkasam

Prakasam

Dt15.09.2014

110

Y.Srinivasarao

M

147727L4

9966888650

16.07.1969

21.05.2008

NA

NO

NO

NO

NO

Bapatla

Prakasam

Dt15.09.2014

156

G L Prasad

M

t4367673

9398818629

07.10.1969

21.05.2008

NA

NA

NA

NA

NA

Dt15.09.2014

263

Raghavarao Baftula

M

L4772700

7036642027

02.04.7970

2r.0s.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dr15.09.2014

111

V.S.Sarojini

F

74172564

964099463\

01.05.1970

21.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Final

Rc.A3.19
ot15.09.2014
5612070

rb5

Sk. Ameer

M

t477256r

9948567881

30.06.1971

21.0s.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Bodanampadu

Final

Rc.A3.19
5612070

Dt15.09.2014

387

V.Ch.Seshagiri Rao

M

t4t72563

8186908438

15.07.1971

21.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Naguluppalapadu

Uppugunduru

Final

0t15.09.2014

762

P.Yerra Subbaiah

M

t4t72602

9L2t409741

07.10.1971

21.05.2008

SC.C

NA

NA

NA

NA

Prakasam

Prakasam

4t

Pedacherlopalli

Chintagumpalli

Final

Dt15.09.2014

773

14.Madhusudana Rao

t\4

t4L72558

9390543220

07.0L.L973

21.05.2008

NA

NA

NA

NA

NA

42

Pullalacheruvu

Pullalacherwu I

Final

Rc.A3.19
Dt15.09.20 14
56120L0

246

K Koteswac Rao

T,I

L4t72733

6281859470

08.01.1973

21.0s.2008

II

NA

NA

NA

NA

Prakasam

Prakasam

43

Tallur

Boddikurapadu

Final

Dtl5.09.2014

243

T Chena Krishanaiah

M

t4t72635

72868 28705

10.02.t973

21.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

44

Ardhaveedu

Magutur

Final

Rc.A3.19
Dt15.09.2014
56lZO|D

85

Ch.Venkata Krishnudu

M

74L72737

8367329436

20.06.1973

2 1.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

45

Parchur

Kollavaripalem

Final

Dt15.09.2014

LL7

T.Bhaskararao

lvl

14t72661

9550967371

1

1.01.1974

21.05.2008

up111)

NO

NO

NO

NO

Bapatla

Prakasam

46

Cumbum

Yerrabalem

Final

Dt15.09.2014

86

G.Anjaneyulu

M

t4t7727

970054L747

01.03.1974

21.0s.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

47

Cumbum

Cumbum2

Final

Dt15.09.2014

87

K.V.Ramana

M

74172496

9618537544

t2.05.1974

2 1.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

(1)

(2)

(3)

(4)

32

Ongole

Housing Board
Colony

Final

33

Dornala

Chinna Gudipadu

Final

34

Parchur

Parchur-2

Final

35

Pullalacheruvu

Mallapalem

Final

36

Ongole

Valetivaripalem

Final

Kurichedu

Kurichedu-2

Final

20

Konakanmitla

Pedarikatla

39

Kurichedu

40

(s)
Rc.A3.19

s6/2010
Rc.A3.19

s6/2010
Rc.A3.19

56/2010
Rc.A3.19

56/2010
Rc.A3.19

56/2010
Rc.A3.19

s6/2010

Rc.A3.19

s6l20t0
Rc.A3.19

s6/2070

Rc.A3.19

s6l20to

Rc.A3.19

56l20to
Rc.A3.19

56/2010
Rc.A3.19

s6l20t0

SC Gr

Prakasam

Prakasam

SC(Gro

<!-- page 5 -->

qJ

ll

Type

q

of

o)

Seniority list

Seniori

Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:

ority

Final/

(a)

Provisi

Procee

onal/ dings
Tentati Numbe
VC
f

(1)

(2)

(3)

(4)

48

Ulavapadu

Mannetikota

Final

49

Kandukuru

Machavaram

Final

50

Donakonda

Mallampeta

Final

51

Korisapadu

Bodduvanipalem

Final

52

Santhanuthalapadu

Indiranagar

Final

53

Parchur

Ramanayapalem

Final

54

Kanigiri

Yeruvaripalli

Final

55

Yerragondapalem

Millampalli

Final

56

l.4undlamur

Singannapalem

Final

57

Inkollu

Inkollu 4

Final

58

Konakanmitla

Pedarikatla (
Suspended )

Final

59

Lingasamudram

Lingasamudram I

Final

60

Kurichedu

West Gangavaram

Final

61

Martur

Bobbepalli

Final

62

Markapuram

Ward Sachi\ralayam
19

Final

63

Chirala

Hyerpeta

Final

o.

(s)
Rc.A3.19
5612O7O

Num

(b)

56/2010
Rc.43.l9
56120LO

Rc.A3.19
s612010
Rc.A3.19

s6l2070
Rc.A3.19

56120t0
Rc.A3.19

s6l20L0
Rc.A3.19
s612010
Rc.A3.19

56/2010
Rc.43.19

s6/2070
Rc.A3.19

56120t0
Rc.A3.19

s6/2070
Rc.43.19

56/2010
Rc.A3.19
56120L0
Rc.A3.19

56/2010

Date of
Gender

MIF

CFMS ID

Phone No

DOB

DD:MM:YY

loining in
this
category

Date

o
.F

=r
9

(,
(Jo
U\^
(5|

f
(!
c

c
OJ

E

t

po

(u

3

E

E
c

!o

'- o c.)
oc:
-(u(J!
>>E
c:(J
.og
IC

bE

2z

(uco -L
6
>.OO
6
i;-o!

e - OP,;
o-(Jif,p
6 u,7 E L
gE "d *"p
L-o

C C

E -=9 ^8
ea:

E

l=.>

OJ

o-

q

G
.E

.q

!
o

I

E

o

o3a
E5.!!

'FOO

ioe
o9d

tsl:Q
EEE

i5Ec

o
z.

'6

CL

oao

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

Dt15.09.2014

438

Ch.Brahmaiah

M

t4172610

9573799Lr7

07.07.1974

21.0s.2008

Group

(1s)

(16)

(17)

(18)

(1e)

(20)

NA

NA

NA

NA

Prakasam

Prakasam

scIN

Rc.A3.19
Dt15.09.2014
56l2OL0
Rc.A3.19

ber

Name of the
Government
Servant

c

o).=o
>o
O-

d
(t)

90

P.Ravi

M

14172520

9885608274

12.07.t974

21.0s.2008

SC

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

774

Sk.Baji

t4

74t72802

9966857995

05.10.1974

21.0s.2008

NA

62

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

118

Darsi Maruthi
Subrahmanyam

M

14172470

9849945430

06.01.1975

21.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

203

K Sanjeeva Rao

M

7477246t

8143130476

14.05.1975

21.05.2008

up III)

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

L52

M.Srinivasarao

M

74772552

8742067336

10.07.7976

21.0s.2008

NA

NO

NO

NO

NO

Bapatla

Prakasam

Dt15.09.2014

97

Ramprasad Reddy
Chegireddy

M

74172731

9000762702

10.05.7977

21.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

58

Sk.Khadar Vali

M

14172622

767704473t

05.05.1978

21.0s.2008

NA

NA

NA

NA

NA

Markapuram

Prakasam

Dt15.09.2014

122

K.Raghavareddy

M

741725L4

9398348699

06.10.1978

21.0s.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

N.Suresh Babu

M

14172672

8897098808

06.12.1980

21.05.2008

NO

NO

NO

NO

Prakasam

Prakasam

Prakasam

Prakasam

Dt15.09.2014

SC(Gro

SC

(MALA)

Dt15.09.2017

585

G Galireddy

N,I

14191906

9966363980

14.07.1985

21.05.2008

NA

NA

NA

NA

NA

Dt15.09.2014

95

Iv Nagaraju

M

L4172636

8247050101

01.01.1990

21.05.2008

NA

NA

NA

NA

NA

Dt15.09.2014

115

Ch.Venkataeswara Rao

M

t4L72423

9550496292

20.01.2008

21.0s.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

G.Rosaiah

M

t4L72466

96s224r207

04.06.1964

22.0s.2008

SC.
Mala

NO

NO

NO

NO

Prakasam

Prakasam

NA

NA

NA

NA

Markapuram

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

Dt15.09.2014

L37

M. Chalama Reddy

M

t4t72685

91 10716196

72.06.L964

22.05.2008

NA

Dt15.09.2014

138

P. Venkateswarlu

M

14172603

96522403M

01.01.1965

22.05.2008

(Mala)

Prakasam

Sc-

G.III

<!-- page 6 -->

Type
I

of

t,

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

ority
(a)
Procee

onau
dings
Tentati Numbe
VC

r

Num

(b)

ber

Name of the

Government
Servant

Gender

MIF

CFMS ID

Phone No

DOB

DD:MM:YY

Date of
Joining in
this
category

f
Ou

(9Ut

(Jo

(oc\

=

!

NA

NA

NA

NA

Prakasam

Prakasam

III

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

NA

Prakasam

Prakasam

NO

NO

NO

NO

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

Chinnaganjam

Kadavakuduru-2

Final

Rc.43.19
56l20LO

Dt15.09.2014

139

K. Nageswara Rao

M

14t72600

7997583574

10.02.1965

22.05.2008

(Group

Martur-Iii

Final

69

Mundlamur

Kellampalli

Final

70

Gudlur

Gundlapalem

71

Santhanuthalapadu

Chimakurthy

G

Prakasam

64

Martur

oo-

Prakasam

(14)

68

G

'6

z.

NA

(13)

Final

EEE

i5Ec

NA

(12)

Koonakanmitla

=->

=z

o)

NA

(11)

Konakanmitla

e=:

tr-Q

NA

(10)

67

g

.g

!

;iee
ogd

(20)

(e)

Final

'ts-ze
I
c
,a6

_qPo
6U
1= 5 -!P
'F
OO

(le)

(8)

Kovilampadu

a
o
E

c)

u
.E

(18)

(7)

Cs Puram

bE

f9;sx
I E'as
!!=(ucc

U)

(17)

(6)

66

.og

d.

EF
>oEn
g - g,E;

(16)

(s)

Rc.A3.19

>o
O!o_
.-do
oc!
(J l2
-o
>>=
C:(J

o)

,
6

(ls)

(4)

Final

E

o

(3)

Vetapalem-2

c

c
o
E
c(u
!=

(2)

Vetapalem

o

OJ

(1)

65

o)

G
.U

Date

9o
-=

0,1

CL

Seni

ty:
FinaU
Provisi

o
o

sc-

III)
SC(Gr-

Dt15.09.2014

140

D.Salmon

M

74172626

9000222347

01.07.1965

22.05.2008

Dt15.09.2014

L4L

P Thirupathaiah

M

74172532

9866379162

01.07.1965

22.05.2008

Dt15.09.2014

t42

P Srinivasareddy

M

74112799

9603765568

30.09.1965

22.0s.2008

Dt15.09.2014

t43

K.Mohan Pao

M

74772605

9398970703

14.05.1966

22.05,2008

Dt15.09.2014

t44

S.Nageswararao

M

74772750

9966922454

13.07.1966

22.05.2008

SC-II

Final

Rc.A3.19
Dt15.09.2014
s612010

145

G.Venugopal

M

14172764

9707256742

20.07.1966

22.0s.2008

Brahmi
n

NA

NA

NA

NA

Sn Padu 1

Final

Rc.A3.19
Dt15.09.2014
s612010

1,46

P Venkata Swamy

r\4

74772606

9502t37875

10.08.1966

22.05.2008

oc

NA

NA

NA

NA

Prakasam

Prakasam

Ram Nagar (Urban)

Final

t956120 Dt:18.08.2017

195

N. Srinivasa Reddy

M

14172460

9848889469

29.03.t967

22.05.2008

OC

NA

NA

NA

NA

Prakasam

Prakasam

r,1

L4r726M

9177051408

20.72.1967

22.0s.2008

OC

NA

NA

NA

NA

Prakasam

Prakasam

M

L4172599

6301ss3898

10.08.1968

22.0s.2008

NA

NA

NA

NA

Prakasam

Prakasam

t4t72762

9492397100

15.08.1969

22.05.2008

NA

NA

NA

NA

56120t0
Rc.A3.19

s6/2010
Rc.43.19

s6/2010
Rc.A3.19

s6/2010
Rc.A3.19

s6/2010

2)

SC

scMadiga

ocPrakasam

10

I

73

Kothapatnam

Ethamukkala

74

J.Pangulur

Bytamanjulur

75

Gudlur

Chimidithipadu

Final

Final

76

Komarole

Komarole 3

Final

77

Veligandla

P.Rallapalli

Final

78

Gudlur

PaIakondapadu

Final

79

J.Pangulur

Kotapadu

Rc.A3.19
Dt15.09.2014
56/2010

198

ngs of
Collector

21.05.2008

752

l'1. Srinivasa Rao

Rc.A3.19
Dt15.09.2014
s612010

159

Avr Prasad

Rc.A3.l9
Dt15.09.2014
56/2010

160

L.Yv Ramana Rao

f4

14L72735

9704794228

25.05.1970

22.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

200

Sk.Md.Khasim

M

14172559

9849534097

01.06.r970

22.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

0t15.09.2014

163

V.Srinivasa Murthi

PI

14172763

9182596160

72.06.t97t

22,05.2008

Brahmi

NA

NA

NA

NA

NA

NA

NA

NA

Rc.A3.19

s6l20t0
Rc.A3.19

56lZ0t0

K. Krishna Kishore
Babu

ocBrahmi

Prakasam

n

ocPrakasam

n

S. Sivarami Reddy

M

t4t72596

99089s9697

23.06.r97t

22.0s.2008

NA

Prakasam

Prakasam

<!-- page 7 -->

OJ

Type

of

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

ty:
Final/

o
o
oSeni

ority
(a)

Provisi Procee
onaU
dings

Tentati Numbe
VE

r

Num

(b)

ber

Name of the

Government
Servant

Gender
M/F

CFMS ID

Phone No

DOB

DD:MM:\TY

Date of
Joining in

l
Qu

this

(,r,
9o
(n-

category

o,

(4)

(s)

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

80

Ulavapadu

Karedu-3

Final

Rc.A3.19
56l20LO

Dt15.09.2014

394

M. Daniel

M

14t72690

8121556531

01.06.1973

22.05.2008

Group

Final

82

Lingasamudram

Anneboinapalli

Final

83

Markapuram

Ward Sachivalayam 7

Final

84

Podili

Amudalapalli

Final

85

Pullalacheruvu

Kavalakuntla

Final

86

Darsi Mandal

Botlapalem

Final

87

Kurichedu

Potlapadu

Final

88

Tangutur

Ponduru

Final

89

Marripudi

Dharmavaram

Final

90

l.Pangulur

Chandalur

Final

Rc.A3.19

s6/2010
Rc.A3.19

s6/2010
Rc.A3. 19

56/20 10
Rc.A3.19

56/2010
Rc.A3.19
5612070
Rc.A3.19

s6l2o7o
Rc.A3.19
5612070
Rc.A3.19

56l20to
Rc.A3.19

c

o
o

'-GO
ot!

3

o(o
oic

E

po
3

E

(3)

Marlapadu

o

.U

(2)

Tangutur

o)

(o

Date

(1)

81

f

9o
.=o
EP
!l!_
out2
,\E

zz

U)

F9;sr
! I 9'afl

t

g - g,E;

C E

E-OJ

E
E&
c -Z

U

d

q)Eo -b
E
>o gt

E

o
6
6

E

z

EgH
EBd
:=(9 o
bBE

E:9
ge

;

E --6
-a:-f>

.z

zo

oEc
'6
o
o-

(u

o

(1s)

(16)

(t7)

(18)

(le)

(20)

NA

NA

NA

NA

Markapuram

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

sc-

III

scDt15.09.2014

202

K.Jayaram

t1

14772697

9949879s64

29.06.1974

22.05.2008

Group

II
Prakasam

0t15.09.2014

265

P.Mallikharjuna

t'4

14172573

7013214726

01.06.1976

22.05.2008

NA

NA

NA

NA

NA

Dt15.09.2014

183

y'.Rama Koteswara Rac

T4

74772686

8309176600

01.01.1977

22.05.2008

NA

NA

NA

NA

NA

Dt15.09.2014

204

V.Samuyelu

M

74772655

9666489810

01.01.1977

22.0s.2008

NA

NA

NA

NA

NA

Dt15.09.2014

205

Venkata Vasudeva Rao
Ivlutukula

M

t4772688

9447074986

19.05,t977

22.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

186

Sk.Chand Basha

M

150135 1 1

8008201684

30,06.1977

22.0s.2008

BC-E

Na

Na

Na

Na

Prakasam

Prakasam

Dt15.09.2014

787

V.Hanumanthurao

M

t4473475

7729008919

02.05.1978

22.0s.2008

NA

NA

NA

NA

NA

Prakasam

Pra kasam

Dt15.09.2014

188

f4. Kondalarao

M

L4772698

99s9763622

20.0s.1979

22.05.2008

Group

NA

NA

NA

NA

Prakasam

Prakasam

Markapuram

Markapuram

Prakasam

SC-

II
Dt15.09.2014

207

P Sri Hari Babu

M

t4t72699

9948620913

20.06.198r

22.05.2008

;C Gr

NA

NA

NA

NA

tt956120 Dt:18.08.2017

214

Ch. Parasurami Reddy

M

t4t72549

9701788259

04.06.1964

23.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

249

Sk. Hussaian

t4

t4t728tL

6300965597

02.04.196s

23.05.2008

NA

NA

NA

NA

NA

Markapuram

Prakasam

Dt15.09.2014

276

M.Kotaiah

M

t4172684

9849565846

01.06.1965

23.0s.2008

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

2t7

A.Uma Maheswara Rac

M

74t727L3

9705975297

09.08.1965

23.05.2008

OC

NO

NO

NO

NO

Prakasam

Prakasam

Dt15.09.2014

218

P.Chennaiah

M

74772572

9182881263

06.01.1966

23.05.2008

NA

NA

NA

NA

NA

Markapuram

Prakasam

Dt15.09.2014

227

M.Peddanna

M

74772654

9010608857

07.01.1966

23.05.2008

SC-II

NA

NA

NA

NA

Prdkasam

Prakasam

s6/2010

Prakasam

Rc.No.A3

10
91

Donakonda

92

Dornala

93

Martur

lonnathalli

Final

94

YerragondatElem

Venkatadripalem

Final

95

Mundlamur

Vemula

Final

Vaddipadu

Pedda

Bommalapuram

Final

Final

Rc.A3.19

s6/2010
Rc.A3. 19

56/2010
Rc.43.19
56l20LO
Rc.A3.19

s6l2070
Rc.A3.19

s6/2010

SC-GR.

II

<!-- page 8 -->

o
o
c

Type
I

of

t,

Seniority list

Seniori
Sl.No

Name of the

Mandal

Name of the
Sachivalayam

o.
Seni

ty:

ority

Final/

(a)

Provisi

Num

Procee

ber

onal/

dings
Tentati Numbe
VE

(b)

Name of the

Government
Servant

Gender
M/F

CFMS ID

Phone No

DOB
DD:MM:YY

Date of
Joining in

this
category

o
.F

Ou

(., u)

(Jo
(h^

l
c'l
o
c

0)

6
.9
E
c

Date

I

c
o
E

t
po
B

->

9o
.=o
>o
qe
!(E_

oco
=>-Go

i iE
se9E;
O
-r=

E . e-a;

o

d.
tn
OJ

6c2iEy

a
6

oolJ
>>E

EE

ts

.9
.g
4C

E

q:L
.-60
o=:

c=(J

bs
zz

g
1

ea:

i=->

E

.9

z

-8'.
EsE
'F Oo
:=(9o
o9E
UsQ

EEe

(o

i5Ec
'6
o
o

(u

z.

o

(18)

(1e)

(20)

(1)

(2)

(3)

(4)

(s)

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

96

Mundlamur

Pulipadu

Final

Rc.A3.19
5617010

0t15.09.2014

261

G.Kotaiah

M

t4t72474

9642937935

07.01. 1966

23.05.2008

SC.Il

NA

NA

NA

NA

Prakasam

Prakasam

97

Tripuranthakam

Endurivaripalem

Final

0t15.09.2014

390

K.Elia

M

14t72673

83742975L5

24.02.L966

23.0s.2008

(Madig
a)

NA

NA

NA

NA

Prakasam

Prakasam

9B

Giddalur

Uyyalawada

Final

Dt15.09.2014

221

S.Eswara Reddy

t4

14172810

800862028s

01.06.1967

23.05.2008

NA

NA

NA

Yes

NA

Markapuram

Prakasam

99

Darsi Mandal

Samanthapudi

D.Nasar Mastan

M

74L72513

9908568101

01.07.1967

23.05.2008

BC-D

Na

Na

Na

Na

Prakasam

Prakasam

100

Komarole

Bramhanapalli

Final

101

Ardhaveedu

Bollupalli

Final

t02

Podili

Podili - 3

Final

103

Marripudi

Marripudi

Final

104

Santhamaguluru

Vellalacheruvu

Final

105

Pullalacheruvu

Sathakodu

Final

106

Bestavaripeta

Basinepalli

Final

107

Giddalur

Thambalapalli

Final

108

Giddalur

Kommunuru

Final

109

Dornala

Yadavalli

Final

110

Komarole

Allinagaram

Final

111

Giddalur

l,4undlapadu-1

Final

SC

Rc.A3.19

56/2010
Rc.A3.19
56120L0

Rc.A3.19

Dt15.09.2014

223

Sk.Nayab Rasool

M

14t728L5

9640968283

04.07.t967

23.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

304

Bandi Venkateswarlu

M

74t72586

7337512979

08.06.1968

23.0s.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dr15.09.2014

228

M. Moshe

M

74:-72530

8790615840

01.07.1968

23.05.2008

SC-II

NA

NA

NA

NA

Prakasam

Dt15.09.2014

230

Sk Bade Saheb

M

74172682

8978779097

06.01.1969

23.05.2008

NA

NA

NA

NA

Prakasam

Dt15.09.2014

262

Gunuru. Babu

M

14486415

9573893s36

07.02.1969

23.0s.2008

NA

NA

NA

NA

Dt15.09.2014

23r

M Ramaiah

M

74172756

91606906s4

06.03.1969

23.05.2008

NA

NA

NA

NA

Dr15.09.2014

229

K.Venkateswarlu

M

14172585

9705549402

01.06.1969

23.05.2008

NA

NA

NA

NA

NA

Markapuram

Prakasam

Dt15.09.2014

29t

P. Mahanandi

M

L4772727

970156199s

01.06.1969

23.0s.2008

NA

NA

NA

NA

NA

Markapuram

Prdkasam

Dt15.09.2014

316

P Kondaiah

M

14772729

9618828958

01.06.1969

23.05.2008

Group-

NA

NA

NA

NA

Markapuram

Prakasam

Rc.A3.19
Dt15.09.2014
56l2O7O

232

Y.Srinivasulu

M

t4172754

9908462181

01.07.1969

23.0s.2008

BC-A

NA

NA

NA

NA

Prakasam

Prakasam

0t15.09.2014

234

P.V.Ramana

M

t4L72736

9346604252

t2.04.1970

23.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

319

A.Venkata Ramaiah

M

L4L72767

9989469169

16.06.1970

23.05.2008

NA

NA

NA

NA

NA

lvla rka pu ra m

Prakasam

s6lzoto
Rc.A3.19

56/2010
Rc.A3.19

s6/2010
Rc.A3.19

s6/2010
Rc.A3.19
s612010
Rc.A3.19

s6l20t0
Rc.A3.19

s6/2010
Rc.A3. 19

56lzOtO

SC(GR

ouP-il1
SC Gr

II

Prakasam

Prakasam

Prakasam

SC

Rc.A3.19

s6l2o7o

Rc.A3.19

s6l2o7o
Rc.A3.19
5612070

III

<!-- page 9 -->

o)

q

TyPe
I

of
Seniori

Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:

ority

FinaU

(a)

Provisi

Num

Procee

ber

onal/
dings
Tentati Numbe
ve
I

(1)

(2)

(3)

(4)

172

Pullalacheruvu

Komarolu

Final

113

Korisapadu

Pamidipadu-2

Final

tt4

Dornala

Chinna Gudipadu

115

Santhamaguluru

Makkenavaripalem-2

116

Konakanmitla

Nagampalli

tt7

Podili

Podili - 1

Final

118

Dornala

Katakanipalli

Final

119

Komarole

Daddawada

Final

120

Veligandla

Kotalapalli

Final

t27

Podili

Yeluru

Final

722

Darsi l"landal

Darsi-2

Final

L23

Racherla

Racherla-2

Final

124

Chirala

Epurupalem-1

Final

t25

Mundlamur

Edara

Final

t26

Giddalur

Giddalur2

Final

127

Donakonda

Ramapuram

Final

Final

(b)

o

o

Seniority list
Name of the

Government
Servant

Date of

Gender
M/F

CFMS ID

Phone No

DOB

DD:MM:W

Joining in
this
category

9rlg u)

(-)o
(,c.

o
f
ol
6
c

o

E

3
o

'=
=,

o

Date

c(,

.U
!
C

9ool
.=
>o
O-

!(o_
.-60
oc!
0J()lf
>>E
c:(J
.9
.9
2C

bE

=z

-l g,
* -E
E - g, e',i

8g.;,EE
E:
iJ
^-

sSEg;
-r,
a

'E
E

p
z

O-

-i=-:
5.>

d.
tt)
0)

o-

o
(!
I
a
E

(:)

.9

t

OJ

q

o ..
'EEq)
'F Oa
:=(9o

bsP
tsr-9
EEP

i5Ec

o

'6

z.

o.

(1e)

(20)

o
o

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

(18)

Du5.09.2014

264

I Venkata Subbaiah

M

t4r72687

9014719799

t7,o7.r97t

23.05.2008

NA

NA

NA

NA

NA

Rc.A3.19
Dt15.09.2014
56/2010

238

Petluri Lakshmi
Narasimham

M

74t72696

99893331s0

26.07.1971

23.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

B.Kondaiah

M

t4172757

9390669906

06.07.1972

23.0s.2008

II

NA

NA

NA

NA

Prakasam

Prakasam

Venna.Venkata Kasi
Reddy

M

14t72523

988s615080

20.04.1972

23.05_2008

OC

NA

NA

NA

NA

Prakasam

Prakasam

Vv Subbaiah

M

t4772526

63039s3032

31.0s.1972

23.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

SC.III

NA

NA

NA

Cancer

II

NA

NA

NA

NA

Prakasam

Prakasam

(s)
Rc.A3.19

56/2010

Rc.A3.19

56/2010

Rc.43.19

Dt15.09.2014

381

SC.GR.

Prakasam

Prakasam

Dt15.09.20 L4

169

G. Rosamma

F

1,4172779

9010062078

07.07.t972

23.05.2008

Dt15.09.2014

245

M.Ch Samuel

M

t4172583

8897282776

12.05.1973

23.0s.2008

Rc.A3.19
Du5.09.2014
56/2010

138

Sri.P.Venkateswarlu

M

r4r725L5

9346058568

01.06.1973

23.05.2008

NA

NA

NA

NA

Yes

Prakasam

Prakasam

Dt15.09.2014

25t

R.Ravisankar

M

t4t72777

9s05858s72

74.03.1974

23.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

250

K. Subba Rao

M

r4t72525

9440594434

01.06.1974

23.0s.2008

NA

NA

NA

NA

NA

Dt15.09.2014

777

R.Srinivasa Rao

M

14978784

95533 1 1937

10.05.1975

23.05.2008

OC

NA

Na

Na

Na

Prakasam

Prakasam

Dt15.09.2014

370

P.Daniel

M

14172620

9704343672

02.06.197s

23.0s.2008

SC.II

NA

NA

NA

NA

Markapumm

Markapuram

Dt15.09.2014

254

D. Krishna Reddy

M

t4r72665

99089 98349

08.07.1975

23.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

24t

K.Dayanandam

M

14172473

8897165881

06.10.1977

23.05.2008

SC-II

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

88

f'4. Anjaneyulu

M

74t72720

8919159167

25.07.7978

23.0s.2008

NA

NA

NA

NA

NA

Markapuram

Prakasam

Dt15.09.2014

55

K.Kotaiah

M

t4172637

7730803680

16.06.1979

23.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

s6/2010
Rc.43,19

s6/20L0

Rc.A3.19

56/2010
Rc.A3.19

56/2010
Rc.A3.19

56/2010
Rc.A3.19

56/2010
Rc A3.1 o

s6/2010
Rc.A3.19

s6l20Lo
Rc.A3.19

56l20to
Rc.A3.19

56/2010

SC.GR-

Prakasam

<!-- page 10 -->

o)

Type

l

of

@
0.)

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
Final/
Provisi
onaU

ority
(a)
Procee

dings
Tentati Numbe
VC
f

Num

(b)

ber

Name of the

Government
Servant

Gender

wr

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in

this
category

Date

c

o

Ou

(9u)

9o
a-

=l
o

o

c

cqi
E
B

o

ll,
lg

E

!

=

.u

9o
.=o
>o
Oc

!O_
.-60
ot!
(IJ(Jt/
>>=
c:(J
.9
.9
le
!:o
=z

(u
t

-i
>ocoo

E Eloi
89"7E;
EEelg
E=dEc
:Lv'-v,

-!2vzE(u
l=a
c

Iz

a
-e-:

i=.>

d

.9

o-

G ..

tn
()
q

o
U
.E
.9.

!

P

0,

bBE
tsr:Q

Epp

o
o

i5Ec

z

q

EEE
:=(90:
'6

o.

o
6

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(L7)

(18)

(1e)

(20)

0t15.09.2014

2s8

Y. P.Rangaiah

M

74t728t2

9573033450

16.06.1980

23.05.2008

NA

NA

NA

NA

NA

Markapuram

Prakasam

Final

Rc.A3.19
Dt15.09.2014
56/2010

70

S Siva Sankar

PI

14172517

9347792545

10.09.1964

24.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Pedda Obineni Palli

Final

Rc.A3.19
Dt15.09.2014
5612010

277

G.Srinivasulu

M

74172618

9848178s28

05.06.1965

24.05.2008

NA

NA

NA

NA

NA

Markapuram

Prakasam

Mundlamur

lammalamadaka

Final

Dr15.09.2014

272

P.Venu Gopal Reddy

M

14172452

9951159639

01.05.1966

24.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasa m

732

Tarlupadu

Tadivaripalli

Final

Rc.A3.19
0t15.09.2014
5612010

275

f4astanaiah Dudekula

M

74172667

9387424437

07.01.1967

24.05.2008

NA

NA

NA

NA

NA

133

Racherla

Anumulapalli

Final

Dt15.09.2014

276

Erla Venkateswarlu

M

74172730

9494898288

16,05.1968

24.05.2008

NA

NA

NA

NA

NA

Markapuram

Markapuram

734

Markapuram

Rayavaram 2

Final

Rc.A3.19
Dt15.09.2014
56/2010

277

Shaik Deenavali

M

74t72544

995 1270180

01.07.1968

24.05.2008

NA

NA

NA

NA

NA

Markapuram

Prakasam

135

Kondapi

Peridepi

Final

Rc.A3.19
Dt15.09.2014
s6/2010

Sk.Mastan

M

74772648

9505373263

1s.06.1969

24.05.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

136

Ardhaveedu

Pedda Kandukur

Final

NA

NA

NA

NA

NA

Prakasam

Prakasam

t37

Peddaraveedu

Thangiralapalli

Final

NA

NA

NA

NA

Prakasam

Prakasam

138

Bestavaripeta

Nekunambad

Final

139

Peddaraveedu

Cumbumpadu

Final

140

Dornala

Y Cherlopalli

Final

141

Podili

Kambhalapadu

Final

742

Dornala

Nallaguntla

Final

743

Bestavaripeta

Mokshagundam

Final

(1)

(2)

(3)

(4)

128

Giddalur

Giddalur-6

Final

729

Pamur

west Kattakindapalli

130

Bestavaripeta

131

(s)
Rc.43.19
s6/ZOLO

Rc.A3.19

s6/2010

Rc.A3.19

s6/2010

Rc.A3.19

Prakasam

Dt15.09.2014

281

B.Venkateswarlu

M

14772650

8185058855

10,04.1970

24.0s.2008

Rc.A3.19
0t15.09.2014
5612010

235

N Anandha Rao

M

14172674

8328131604

15.06.1970

24.0s.2008

0t15.09.2014

282

P.V.Raju

M

t4772782

9505786553

30.06.1971

24.05.2008

NA

NA

NA

NA

NA

Markapuram

Prakasam

Dt15.09.2014

17L

G Sanjeevareddy

M

L4172751

9550228477

0t.07.L972

24.0s.2008

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

285

Y.Venkata Chennaiah

M

r4t72647

9989216609

04.04.7974

24.05.2008

BC-A

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

377

Sk. Eabaji

M

14172723

7680998724

70.u.L974

24.0s.2008

NA

NA

NA

NA

NA

Dt15.09.20 14

288

K laya Prakash Rao

M

14172504

8897282716

02.07.t975

24.05.2008

NA

NA

NA

NA

Prakasam

Prakasam

0t15.09.2014

292

S.Veeraiah

M

L4L72663

9640402003

15.06.1975

24.05.2008

NA

NA

NA

NA

Markapuram

Prakasa m

s6/2010

Rc.A3.19

s6l2o7o
Rc.A3.19

56l2Ot0
Rc.A3.19

s6/2010
Rc.A3.19

s6/2010
Rc.A3.19
56lZOLO

Rc.A3.19

s6/2010

sc
Madiga

SC.GR.

III

Prakasam

<!-- page 11 -->

0.)

Type

of

6

0)

Seniority last

Seniori

Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
Final/

ority
(a)

Provisi Procee
onaU
dings

Tentati Numbe
VE

r

(s)

(1)

(2)

(3)

(4)

744

Yerragondapalem

Veerabhadrapuram

Final

745

Martur

Bollaplli

Final

146

Vetapalem

Kothapeta-2

Final

147

Peddaraveedu

Chatlamitla

Final

148

Ardhaveedu

Donakonda

149

Tripuranthakam

150

o-

(b)

Num
ber

Name of the

Government
Servant

Gender

MIF

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in

this
category

Date

NA

NA

Prakasam

Prakasam

24.05.2008

NA

NA

NA

NA

Prakasam

Prakasam

05.06.1979

24.0s.2008

NA

NA

NA

NA

Prakasam

Prakasam

9849339246

10.03.1967

25.05.2008

NA

NA

NA

NA

Prakasam

Prakasam

14172574

8008646954

06.02.1968

25.05.2008

NA

NA

NA

NA

Prakasam

Prakasam

F

L4772501

9347604741

16.08.1968

25.0s.2008

NA

NA

NA

NA

Prakasam

Prakasam

Kv Narayana

M

74t772537

9553697619

01.07.L977

2s.05.2008

NA

NA

NA

NA

Prakasam

Prakasam

Sk.Chinna Kasimsa

M

14388679

7997097577

20.04.1965

26.05.2008

NA

NA

NA

NA

Markapuram

Prakasam

I'l

14388691

9L77269379

79,04.1967

26.0s.2008

NA

NA

NA

NA

Markapuram

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

255

T.Ch.Anjaneyulu

M

741727t2

998977250t

15.07.1978

24.05.2008

Dt15.09.2014

398

Syed Baba Fakruddin

M

74772664

6300205097

01.06.1979

Dt15.09.2014

399

Ch Srinivasulu

M

14772671

9666487M5

Final

Rc.A3.19
Dt15.09.2014
56/2010

220

M.Srinivasulu

M

14172732

Ganapavaram

Final

Rc.A3.19
Dt15.09.2014
56/2010

150

V. Svalingaiah

M

Kandukuru

Kovuru

Final

Rc.A3.19
Dt15.09.2014
56/2010

108

T.B.Rathnakumari

151

Vvpalem

Ayyavaripalli

Final

Rc.A3.19
Dt15.09.2014
s6/2010

257

t5z

Bestavaripeta

Galijerugulla

Final

Rc.A3.19
Dt15.09.2014
56/2010

369

153

Giddalur

Gadikota

Final

154

Cumbum

Kandulapuram3

155

Chimakurthy

Devarapalem

Syed Chinna

Dt15.09.2014

302

Final

Rc.A3.19
Dt15.09.2014
56/2010

37r

Sk.Dadapeera

1.4

t4L72627

9s02s07337

13.06.1968

26.05.2008

Final

Rc.A3.19
Dt15.09.2014
56/2010

384

M. Subba Rao

M

L4L72774

9502723942

06.04.t972

26.05.2008

Giddalur

Nardva

Final

158

Pedacherlopalli

Chinnavarimadugu

Final

159

Marripudi

Garlapeta

Final

Rc.A3.19

56/2010
Rc.A3.19

s6/2010
Rc.A3.19

s6/2010

o

NA

24.05.2008

757

oo-

,:do
6 cE
o!E

NA

08.01.1978

s6/2010

o

'o

z.

0)

Prakasam

949028 1581

Rc,43.19

€

Markapuram

747728t3

Final

bE

:5 e
Ee
c
--a
ea:
E
l>.2
NA

M

Arivemula

=z

:=9o
o-9d
tr:9

NA

Sk.Nasar Vali

Cs Puram

=

o
(o

U
,E

o

NA

295

156

.9
2c -g

o-

NA

Dr15.09.2014

s6/2070

o
E

v'-v,

(20)

(13)

Rc.43.19

B

o,

L

(1e)

(12)

s6l20t0

E

:

-

g
6.,
-oa
'F OO

(18)

(11)

Rc.A3.19

G

c(u

E btr5
*E,IE
"d;gr
,r-5

0,

U

(L7)

(10)

Rc.A3.19
56l20LO

U, e,

f

c'l

EP

!o_
'-GO
6=!
.CJ (J I]
, >-c

d.

UI

(16)

(e)

s6/2010

q.1 0

.=o

oc(U -b
'6
>-O O

(1s)

(8)

Rc.A3.19

Ou

(9 u)

.E

(7)

56120t0

o

!

(6)

Rc.A3.19

c

cn-

Kasimpeera

(14)

scMadkJa

OC

Sc-

(Mala)

G.III
SC III

Dt15.09.2014

310

S Raghu Ramaiah

M

t4t72476

9553370596

10.03.1978

26.05.2008

Dt15.09.2014

311

S. Veera Narayana

M

t4r72475

8639558800

1

1.05.1983

26.05.2008

NA

NA

NA

NA

Markapuram

Prakasam

Dt15.09.2014

314

K.Venugopal Reddy

M

14t72536

9346s32499

0s.06.1966

27.05.2008

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

315

S Subbareddy

M

14t72534

9703 13 1669

06.01.1967

27.0s.2008

NA

NA

NA

NA

Prakasam

Prakasam

<!-- page 12 -->

Type

of

0
(u
Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
Final/
Provisi
onaU

ority
(a)
Procee

dings
Tentati Numbe
ve
r

(1)

(2)

(3)

(4)

160

Bestavaripeta

Chetticherla

Final

161

Pamur

Vaggampalli

Final

762

Lingasamudram

Pentrala

Final

163

Ongole

M ukthinuthalapadu

Final

164

Pamur

Nuchu@a

Final

165

Racherla

Somidevipalle

Final

o-

(b)

Num
ber

Name of the

Government
Servant

Gender

wr

CFMS ID

Phone No

DOB

Date of
Joining in

DD:MM:W

this
category

Date

@

o

ts
.9

E

o
o

e-:
E
z --^
5.>

z

o

beE
E:9
f;Pe
i5tsc
'6

o.
o.
(o

(20)

NA

NA

NA

NA

Markapuram

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

30.0s.2008

NA

NA

NA

NA

Prakasam

Prakasam

04.01.1971

30.05.2008

NA

NA

NA

NA

Prakasam

Prakasam

8247357296

04.10.1973

30.05.2008

NA

NA

NA

NA

Prakasam

Prakasam

t4792154

8186074230

15.06.1976

30.05.2008

NA

NA

NA

NA

Markapuram

Bapatla

L4772628

98663 74070

15.06.1976

30.05.2008

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasm

Prakasam

ft.Hasham

T4

747725t9

9989270623

08.06.1979

27.05.2008

Dt15.09.2014

320

B Kumar

M

147726t7

8309002366

06.12.1975

29.05.2008

Dt15.09.2014

327

Dr Hussen

M

14772766

7093043297

05.08.1967

Dt15.09.2014

328

Vennapusa
Srinivasareddy

M

14772506

773L856873

Rc.A3.19
Dr15.09.2014
5612010

329

A Chennakesavulu

M

14772668

656

G.Archana

F

330

Ch. Sekhar

M

s6/2010

=1

c

o a2
.. s
-'E5q,
'= oo
:=(9o

(1e)

297

Rc.A3.19

bE

C

o
o-

(18)

(13)

56/2010

3

FP;SX
o B'af
!.E-zE&
C
E-O
c

.E

U1

(17)

(12)

Rc.A3.19

E

'-oo
ot!
oL).!l
>'>=
c=(J
.9
S'
2C

!lE_
L:L

I

d.

(16)

(11)

s6/2010

o)

iA

(1s)

(10)

Rc.A3.19

C

po=

.9

(e)

Rc.A3.19
Dt15.09.2014
56/2010

.9

fql
(o
c

lu
!

(8)

(6)

Ou

(, (,
Uo
(,G.
o

(7)

(s)

c

(uco>.(!-b o
E _ g,e';

9o
.=o
>o
O-

(14)

SC.II

SC-III

Rc.No.A3

t1956120 Dt:18.08.2017
10

166

Chirala

Vodarevu-1

Final

167

Cs Puram

Chennapanayunipalli

168

Kothapatnam

Madanuru -l

Final

169

Vetapalem

Ramannapeta-1

Final

t70

Pamur

Mopadu

Final

771

Ongole

Manduvavaripalem

Final

772

Ongole

Gundaypalem

Final

773

Santhamaguluru

Tangedumalli

Final

174

Kondapi

Kondapi2

Final

775

Markapuram

vl,/ard Sachivalayam 1

Final

Rc.A3.19

s6/2010

Dt15.09.2014

iqa) G-

II
K Obulapathi

M

L4172669

9177270032

01.05.1979

30.0s.2008

332

G- Sankar Rao

M

t4172776

9908351813

09.04.1970

3 1.05.2008

Dt15.09.2014

318

D.Purushotham

M

L4L72567

965224s092

03.04.L974

17.07.2008

NA

NA

NA

NA

Prakasam

Prakasam

0t15.09.2014

3s9

T Ramanajaiah

M

14184867

9390752970

07.05.L97r

12.08.2008

NA

NA

NA

NA

Prakasam

Prakasam

Rc.A3.19
Dt15.09.2014
56l20LO

360

Krishnarao Pokuri

IY

14184786

8332039909

06.01.1975

12.08.2008

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

381

Maruthuram Ponduri

M

144743il

70362381s3

16.05.1982

21.08.2008

NA

NA

NA

NA

Prakasam

Prakasam

21.0s.2008

777

R.Srinivasarao

M

r4t72895

9966092320

15.06.1971

30.08.2008

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

3s0

N.Ramakrishnaiah

l'4

14172888

94001021s

01.01.1969

01.09.2008

NA

NA

NA

NA

Prakasam

Prakasam

Rc.A3.19
Dt15.09.2014
56/2010

353

A.Vengalreddy

I,4

74t72869

96r8619209

24.06.7974

01.09.2008

NA

NA

NA

NA

Markapuram

Markapuram

Rc.A3.19
Dt15.09.2014
s612070
Rc.43,19

56/2010
Rc.A3.19

56/2010

Rc.A3.19

56/2010
RC .A3l 3!

12007

Rc.A3.19

56/2010

OC

oc

<!-- page 13 -->

Type

of

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
Final/
Provisi

ority
(a)
Procee

onall
dings
Tentati Numbe
VC
r

(1)

(2)

t76

Markapuram

t77

Tangutur

lammulapalem

Final

t78

H.M.Padu

Vemulapadu

Final

L79

Korisapadu

Kurravanipalem

180

Kandukuru

181

(3)

6
(I)

(s)

Num

(b)

ber

Date of

Name of the

Government
Servant

MIF

CFMS ID

Phone No

DOB

Joining in

DD:MM:W

this
category

Date

Prakasam

83309773s6

10.06.1981

01.09.2008

NA

NA

NA

NA

t4L84897

96s23t4634

04,12.1974

12.10.2008

SC-I

NA

NA

NA

NA

Prakasam

Prakasam

M

14184841

880138333 1

30.06.1972

01.12.2008

qa

NA

NA

NA

NA

Prakasam

Prakasam

U. Subbarao

M

14184850

9848421051

74.O4.1969

08.12.2008

NA

NA

NA

NA

Prakasm

Prakasam

B.Daveedu

M

14L84927

9505097792

01.11.1975

08.12.2008

NA

NA

NA

NA

Markapuram

Prakasam

L.Venkateswarlu

M

14184785

9949915481

75.07.1973

1 1.12.2008

SC

NA

NA

NA

NA

Prakasam

Prakasam

G-Chimpa Rao

M

74184946

7702879878

08.08.1985

01.02.2009

Mala

NA

NA

NA

NA

Prakasam

Prakasam

Prakasam

Prakasam

9100883969

0t15.09.2014

357

Srinivasareddy
Sabbasani

M

t4t72848

Final

Rc.A3.19
Dt15.09.2014
s612010

364

Medikonda Venkata
Narayana

M

G Mekapadu

Final

Rc.A3.19
Dt15.09.2014
5612070

363

L.Murali

Vetapalem

Papayapalem

Final

Rc.A3.19
Dt15.09.2014
5612070

358

182

Yerraqondapalem

Narasayapalem

Final

361

183

Kandukuru

Sriram Colony

184

J.Pangulur

Panguluru 1

Guntupalli

186

Lingasamudram

Chinpavani

Final

Rc.A3.19
Dt15.09.2014
56/2010

787

Yerragondapalem

Amanigudipadu

Final

Rc.A3.19
Dt15.09.2014
56/2010

188

Ardhaveedu

Papinenipalli

Final

189

Giddalur

Giddalur-3

Final

190

H.M.PadU

Hanumanthapuram

West Naidupalem

385

V.V.S.Rama Krishna

M

14185107

9642269t40

05.01.1970

23.02.2009

NA

NA

NA

NA

NA

402

Mvp Kishore

M

14186016

9948500640

24.06.197s

05.06.2009

NA

NA

NA

NA

NA

404

B.Mohanrao

M

14185783

9502727750

28.1t.t977

r8.06.2009

NA

NA

NA

NA

NA

lYarkapuram

Prakasam

Dt15.09.2014

406

Sk.Madar Vati

M

14786227

9760720279

20.06.1985

12.08.2009

NA

NA

NA

NA

NA

Pmkasam

Prakasam

Dr15.09.2014

407

Ch.Swarnalathadevi

F

74786226

9652824142

31 08 7973

24.08.2009

NA

NA

Yes

NA

NA

Markapurdm

Prakasam

M

14473439

9848426525

0L.07.1967

01.09.2009

NA

NA

NA

NA

NA

F

14186219

9908604118

t4.02.L976

02.09.2009

NA

NA

NA

NA

NA

Sueboina Pedda
Kasaiah

Final

Rc.A3. 19

56/2010

SC(Gr-

Prakasam

(Gr-III

Ballikurava

Kurichedu

(14)

Sc-

Dt15.09.2014

185

191

o

Prakasam

L4t72840

s6/2010

o"

NA

F

Rc.A3.19

o.

NA

N.Lakshmi

s6/2010

'5

NA

3s6

Rc.A3.19

zG

NA

Dt15.09.2014

56l20to

C)

01.09.2008

30.06.1979

Rc.43.19

=.>

=1

E

07.08.1979

955M07333

Final

-

Markapuram

14t72842

Dt15.09.20 14

:--^
--6

Markapuram

M

56/20tO

c
O

Ee2
Er-Q
Ep9
i5Ec

NA

O. Venkata
Ramanareddy

Rc.A3.19

.rg-zE &

ts
,9

NA

355

56/2010

C C

E-(l)

NA

0t15.09.2014

Rc.A3. 19

=

bE

q 5 s-as

NA

(13)

56120t0

E

>- >E
.9
2C -g

01.09.2008

(12)

Rc.A3.19

to

'-60,
ot!
o(Jl2

'= oL)
:= (9 or

(20)

(11)

56/2010

E

c)

Eia
E5q)

(le)

(10)

Rc.A3.19

o
o
.9
E
E

cqJ

o
oa
6

U
E

(18)

(s)

Final

o
c

E-gE.;
*8.iEr

d.

U)

(17)

(8)

72

^

=
o)

>-oEH
o

(16)

(7)

Ward Sachivalayam

(, (/)
()o
tJ,

o
.E

o)

,
=

(1s)

(6)

(4)

c

l
gu

Pu
.=o
EP
!6

Dt1s.09.2014

408

V.Rajya Lakshmi

Prakasam

Prakasam

Prakasam

Prakasam

<!-- page 14 -->

0)

Type

o
(,

of

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
FinaU
Provisi

ority
(a)
Procee

onal/ dings
Tentati Numbe
ve

f

(4)

(s)

Num

(b)

ber

Name of the
Government
Seruant

Date of
Gender

wr

CFMS ID

Phone No

DOB

loining in

DD:MM:W

this
category

o
9r
(, u)
(Jo
U\^

o
ol
o

c

!J

o

Date

.u

!

c

c)

E

i
o

Po
.=o

EP

!d

.-60)
oE!
ool2
> >E
c:(J

E

.9
vcsl

=

=z

bE

-l
>.6cor0

'to)

E
, g,;';
o-OiFu

d

v)
o)

oq

(o

AH*,= E

'-U

.9

E

Eo=ar
C tr
E-(I) 19
E

-z

!P

ea:

i?.2

OJ

U

zo

636.
E 5.9
'F OO
:=(9o

be?
tsr:9
Ep9
i5Ec

zo

'6

o
o
6

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(ls)

(16)

(L7)

(18)

(1e)

(20)

409

Mnv Dilip Kumar

M

14186969

9966484908

01,06.1984

2s.09.2009

NA

NA

NA

NA

NA

Prakasam

Prakasam

386

S.Ratnaswamy

M

14186965

6304290815

07.05.7973

13.10.2009

NA

NA

NA

NA

NA

Ivlarkapuram

Markapuram

138

P. Venkateswarlu

M

14186215

9000458914

02,01.1978

08.11.2009

BC.A

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

229

K.Venkateswarlu

M

7418740t

99t20t2276

20.07.1968

12.1 1.2009

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

415

V Venkata Ramana

M

14187358

6303629125

12.06.1973

13.1 1.2009

NA

NA

NA

NA

NA

Markapuram

Prakasam

Dt15.09.2014

416

Sk.Akbar Vali

M

14t86221

9182896408

19.05.1978

r3.1 1.2009

NA

NA

NA

NA

NA

Prakasam

Prakasam

Gannavaram

E.Satyanarayana

M

14187349

9701473973

05.02.1978

19.1 1.2009

OC

NA

NA

NA

NA

Prakasam

Prakasam

Parchur

Edubadu

D.Satyanarayana

M

t4t87494

04.04.t979

01.01.2010

NA

NO

NO

NO

NO

Bapatla

Prakasam

200

Peddaraveedu

Gobburu

Final

201

Cs Puram

Cs Puram 1

Final

202

Vetapalem

Ramannapeta-2

Final

203

Maddipadu

Lingamgunta

204

Cumbum

L.Kota

(1)

(2)

(3)

792

Konakanmitla

Gotlagattu,

193

Racherla

J.P.Cheruvu

794

Chimakurthy

Vidya Nagar (Urban)

195

Komarole

Rajupalem

Final

196

Giddalur

Obulapuram

Final

797

Ardhaveedu

Rangapuram

Final

198

Yaddanapudi

199

Final

(5)

Rc.A3.19
Dt15.09.2014
s612010

Rc.A3.19

5612010
Rc.A3.19

56120t0
Rc.A3.19

s6/2010

Rc.A3. 19

Dt15.09.2014

419

T Harinarayana

M

t4187790

8008896933

01.01.1966

3 1.03.2010

NA

0.76

NA

NA

NA

Prakasam

Prakasam

Rc.A3.19
Dt15.09.2014
5612010

420

P Bala Kasaiah

M

14t87974

7036294324

13.07.1981

16.04.2010

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt15.09.2014

427

T. Komala Parvathi

F

14189128

6302286279

06.09.1974

14.10.2010

NA

NA

NA

NA

NA

Prakasam

Prakasam

Final

Rc.A3.19
0t15.09.20 14
5612070

422

Rachapudi Ranga

M

14189341

9866801802

20.06.1985

3l.03.201r

NA

NA

NA

NA

NA

Prakasam

Prakasam

Final

lL9s6l20 Dt:18.08.20U

423

D.Peersa

M

14189371

8008928881

04.06.1991

06.04.201 1

NA

NA

NA

NA

NA

Prakasam

Prakasam

424

P.Tulasiram

M

r4t89374

9293722676

77.M.L967

04.05.201 I

NA

NO

NO

NO

NO

Prakasam

Prakasam

463

Sivaratri Sivaiah

M

14189466

6305059201

08.10.1968

13.05.201

I

NA

NA

NA

NA

NA

Markapuram

Markapuram

452

M.Venkateswarlu

M

14189434

8555016793

01.01.1976

06.06.2011

SC

NA

NA

NA

NA

Prakasam

Prakasam

s612010

Rc.A3.19

56/2010

Rc.No.A3
10

Rc.No.43
205

Inkollu

Pusapadu

Final

1t956170 Dt:18.08.2017
10
Rc.No.43

206

Racherla

Racherla-1

Final

t79s6120 Dt:18.08.2017
10
Rc.No.A3

207

Kandukuru

Yarravaddipalem

Final

n956120 Dt:18.08.2017
10

<!-- page 15 -->

Type

of

a

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

ority
(a)

Num

Procee

ber

onal/ dings
Tentati Numbe
ve

(1)

(2)

(3)

(4)

oSeni

ty:
FinaU
Provisi

C)

Seniority list

(b)

Name of the

Government
Servant

Gender
MIF

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in

this

Chirala

Gollapalem-02

Final

q;o

ro c.

category

Date

ol
(!
c

o
o

E

t
po
3

.9

!

(s)

(6)

(7)

(8)

(e)

(10)

(11)

(L2)

(13)

tL956/2C

9o
.=o
EP'
!(U_

.-60
o<!
oL)l2
>- >=

C:L

.9 -S'
2C
!:o

=1

r

(14)

tc.No.A3
208

f

Ou
(,(,

c
o
E
c(J

,

EFg)

E

>(!

a

E
(u

()
o-

E:-+

I I'ag
19

U
.C

!U

ro

::- (,
if0?
H-o
.Ya>

=Ya*
ea:
=.>

0)

zo

g - $ E;
SE;,EX
E-O
=
.!2
-z

Z
E

o
U

d.

C E

o
(g
o

E.a6(J

;

EE
oEc
'o

ooG

(ls)

(16)

(L7)

(18)

(1e)

(20)

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Bapatla

Prakasam

NO

NO

NO

NO

Bapatla

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

Sc-

Dt:18.08.2017

425

Ch. Sadandarao

M

t4L89422

9t776 902L5

03.02.t977

08.06.2011

(Mala)

G.III

10
1c.No.A3

209

Chinnaganjam

Pedapallapalem

Final

tt956l2C Dt:18.08.2017

426

Ch. Padma

F

14189673

9676323887

09.05.1971

08.06.2011

429

B.Prem Kumar

M

L4189474

4247384873

20.07.1983

08.06.201 1

BC-A

10

tc.No.A3
210

Parchur

Nuthapaladu-2

Final

SC(Gro

tt956l2C Dt:18.08.2017

2t7

Dornala

Dornala -1

Final

lc.No.A3
tt956/2C

up111)

10

Dt:18.08.2017

43L

K. Edukondalu

M

14189571

9704562474

01.07.1965

10.06.2011

L9s6l2C Dt:18.08.2017

444

Sk.Meeravali

M

L4L89442

7989127759

15.03.1967

10.06.2011

NA

NA

NA

NA

Markapuram

Prakasam

445

L.Venkateswarlu

M

14t89697

9652425058

16.04.7967

10.05.201 1

NA

NA

NA

NA

Prakasam

Prakasam

474

Chintaguntla lames

t4

L4389294

9848203472

01.07.1969

10.06.201

NA

NA

NA

NA

436

Shaik Mabuvali

N,I

L4L89674

9182602003

1L.02.L972

10.06.201 1

NA

NA

NA

NA

Markapuram

Prakasam

439

P.Aananda Rao

M

L4L894L2

9347082297

10.04.7975

10.06.201

NA

NA

NA

NA

Prakasam

Prakasam

427

G. Venkatarao

M

14189450

99498 27769

06.05.1975

10.06.201 1

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

BC.A

10

2t2

Bestavaripeta

Akkapalli

Final

10

2\3

Cumbum

Kandulapuram2

Final

lL9s6lzC Dt:18.08.2017
10
Rc.No.A3

zt4

H.14.Padu

Nandanavanam

Final

lt9s6l2c Dt:18.08.2017

1

SC

Prakasam

10
Rc.No.A3

2t5

Markapuram

Ward Sachivalayam 6

Final

lL9s6l20 Dt:18.08.2017
10
Rc.No.A3

2t6

Dornala

Dornala -4

Final

lL9s6l2A Dt:18.08.2017

SC.GR.
1

10
Rc.No.A3

2L7

Chirala

Hariprasadnagarl

Final

Sc-

lt956l20 Dt:18.08.2017

SC-

Rc.No.A3

Eallikurava

Velamavaripalem

Final

(Mala)

G-III

10

2t8

II

lt9s6lzo Dt:18.08.2017

440

S.Yesaiah

t4

L4L89494

9553670777

18.10.1975

10.06.2011

Group

]I

10
Rc.No.A3

2L9

Podili

Kunchepalli

Final

lL9s6l20 Dt:18.08.2017

44r

G.Malyadri

M

14189451

9963040680

07.02.1979

10.06.201 1

NA

NA

NA

NA

NA

683

D.Galeebu

M

14189572

9704160566

01.04.1984

10.06.2011

NA

NA

NA

NA

NA

450

K.Brahmaiah

M

14186016

7036335159

01.06.1969

11.06.2011

SC.
Mala

NA

NA

NA

NA

Prakasam

454

B.Subba Rao

M

14189440

8106595408

07.07.1967

13.06.2011

NA

NA

NA

NA

NA

Prakasam

455

P Nageswararao

M

14189660

8187881731

07.01.1969

13.06.201 1

SC Gr2

NA

NA

NA

NA

Prakasam

Prakasam

10

220

Markapuram

Ward Sachivalayam
13

Rc.No.A3
Final

lL9s6l20 Dt:18.08.201i
Rc.No.A3

22L

Lingasamudram

Pedapavani I

Markapuram

Prakasam

10
Final

lL9s6l20 Dt:18.08.2017
10
Rc.No.A3

222

Pedacherlopalli

Pedda Alavalapadu

Final

lt956l20 Dt:18.08.2017
10
Rc.No.A3

223

Marripudi

Pannuru

Final

tL956/20
10

Dt:18.08.2017

<!-- page 16 -->

Type

of

Seniority list

Seniori

Sl.No

Name of the
Mandal

Name of the
Sachivalayam

ty:

ority
(a)

Provisi

Procee

onal/

o.
Seni

Final/

dings
Tentati Numbe
VE
r

Num

(b)

Gender

wr

CFMS ID

Phone No

DOB

DD:MM:W

loining in
this

9u
(9(,
(Jo
l/1^

category

(3)

(4)

224

Giddalur

Ambavaram-2

Final

Rc.A3.l9
ft15.09.2014
56/2010

275

Giddalur

Kanchipalli

Final

lt9s6l20 Dt:18.08.2017

(6)

o
.E
o)
G
c

C
(u
E

;

po

o
o

3

.U

!

(2)

(s)

ber

Name of the
Government
Servant

Date of

Date

(1)

o
o
c

c

o)

.
E

EF
>c C''
g , g,E;

d.

F9;EX

I 3 aE
!!-(ucc

U

Ete .!2 vz E E

6
E

CD_

,=o

EP

!E_
.-GO
o<!

o(Jlf
- >-c

Eg
2z

O

l-o
:--^-

r=.>

tJ)
C)

o.
q

o

c)

u
.E
0)

a3ts
ri >x

:=(9o
bsP

tir:9

EPe

i5Ec

o

'6

z.

o.

o
o

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(L7)

(18)

(1e)

(20)

170

S. Ramaiah

M

141726t6

9346985306

0t.07.7972

13.06.201 1

NA

NA

NA

NA

NA

Markapuram

Prakasam

467

K.Chinna Siddaiah

M

14189418

9782670746

01.06.1973

13.06.2011

NA

NA

NA

NA

NA

Markapuram

Prakasam

465

M.Pandu

M

14389304

91550997770

10.07.1973

13.06.2011

NA

NA

NA

NA

NA

Prakasam

Prakasam

466

K.Peda Musalaiah

M

14189658

990827659s

12.08.1973

13.06.20 1 1

Group

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NO

NO

NO

NO

Bapatla

Prakasam

Rc.No.A3
10
Rc.No.A3

226

Komarole

Komarole 1

Final

t79s6120 Dt:18.08.2017
10

227

Ballikurava

Nakkabokkalapadu

Final

Rc.No.43
t7956120 Dt:18.08.2017

scII

10
Rc.No.A3

228

Chirala

Besthapalem

Final

Sc-

t7956120 Dt:18.08.2017

458

M. Satyam

M

14189416

98489 27224

15.05.1974

13.06.201

1

10

(Mala)

G.III
SC(Gro

279

Parchur

Pothukatla

Final

79s6/2C

Dt:18.08.20 17

459

M.Kavita

F

14189413

8374163r20

?5.06.7976

13.06.201 1

10

up111)

Rc.No.A3

230

Komarole

Nallaguntla

Final

23t

Kandukuru

Paluru

Final

Dt:18.08.2017

469

Sri.Sk.Kasimvali

M

74429367

830921212s

L4.04.7979

13.06.201

1

NA

NA

NA

NA

NA

Prakasam

Pra kasam

Rc.No.43
1t956120 Dt:18.08.2017

460

K.Venkatarao

M

14189407

6281008125

15.07.7979

13.06.2011

SC

NA

NA

NA

NA

Prakasam

Prakasam

46r

Meruga VUay Mohan

M

14189684

9704314386

01.04.1983

13.06.201

Group-

NA

NA

NA

NA

Markapuram

Prakasam

l195612C
10

10
Rc.No.A3

)1)

Giddalur

Ambavaram-1

Final

SC

179s6120 Dt:18.08.2017
10

1

III

Rc.No.A3

233

Chinnaganjam

Chinnaganjam-2

Final

lt9s6l20 Dt:18.08.2017

470

A. Satyanarayana

M

74789421

934705377:.

09.07.1970

14.06.201

1

oc

NA

NA

NA

NA

Bapatla

Prakasam

47L

P Ramesh

M

14189399

986696s020

05.01.1972

14.06.201

1

SC.II

NA

NA

NA

NA

Prakasam

Prakasam

473

G Gabriyelu

M

14189693

9032135289

16.06.1981

16.06.2011

SC.II

NA

NA

NA

NA

Prakasam

Prakasam

428

Mattaiah Vistharla

M

14189410

9966s47703

05.10.1977

06.08.2011

Group

NA

NA

NA

NA

NA

NA

NA

NA

Prakasm

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

10
Rc.No.A3

234

Pamur

Chintalapalem

Final

t7956120 Dt:18.08.2017
10

235

Pamur

Raviguntapalli

Final

lc.No.A3
L956120 Dt:18.08.2017
10

Rc.No.43

236

Karamchedu

Adipudi

237

Donakonda

Donakonda-1

238

Pamur

Bodawada

Final

sc-

119s6120 Dt:18.08.2017
10

Prakasam

III
V.Borraiah

M

14429356

8297ffi067t

02.08.r966

06.10.2011

434

Sk Mohammad Rafi

M

14189398

9949150810

15.06.1970

06.10.201 1

436

l. Rosaiah

M

t4367965

9982543481

06.06.1972

06.10.201 1

SC-11

Rc.No.A3
Final

1t956120 Dt:18.08.2017
10

239

Santhamaguluru

West-Kundurru

Final

RC .A3l 3E

48120t0

SC(GR

06.06.2011

OUP-

III)

<!-- page 17 -->

o)

Type

of

o
(u

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
Final/
Provisi

ority
(a)
Procee

onal/
dings
Tentati Numbe
ve

r

(s)

(1)

(2)

(3)

(4)

240

Pedacherlopalli

Lakshmakkapalli

Final

o

Seniority list

(b)

Num
ber

Name of the

Government
Servant

Gender
MIF

CFMS ID

Phone No

DOB

Date of
Joining in

DD:MM:W

this
category

o
:,

o)
(o

c(.)
E

3

o

!

OJ

(5

I

Date

(6)

c

=
Ou

0u)
12o
t/)i

€

9p
EP

.=o
!d

.-o0)
@c!
oLJl2
- >-c
C:(J
.9
yc .[,

=

b9
Ea

0.)tro -i gt
E
>6

d.
(n

E
. g,E;
o92
5 Er

o

q 5 E-'s

U
'tr
.9

q
l!

.9

t

c,

EEq*
'F OA
:= (9 o:

bBE
UrQ
EEg
i5!c

c E

E

E -.:
=->

.E

o

'6

z.

o.
o.
(!

(1e)

(20)

!-o

E-=CE

o

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

(18)

437

K.Malyadri

M

t4789437

96s2498435

07.07.7974

06.10.201 1

SC

NA

NA

NA

NA

443

Yasdani Shaik

M

t4t89449

9849s63625

20.07.1985

06.10.2011

NA

NA

NA

NA

NA

Prakasam

Prakasam

Sk Basha

M

14189458

7095541905

0 1.10.1970

06.11.2011

NA

NA

NA

NA

NA

Prakasam

Prakasam

475

M.S.Purnrma

F

14190980

9492359868

07.08.1976

11.01.2012

NA

NA

NA

NA

NA

Eapatla

Bapatla

542

S. Narapa Reddy

M

14790745

9t77212286

08.12.1981

tr.02.20t2

NA

NA

NA

NA

NA

Prakasam

Prakasam

E. Srinivasulu

M

14190601

6303004149

05.u.t977

23.04.2072

NA

NA

NA

NA

NA

Prakasam

Prakasam

Prakasam

Prakasam

Rc.No.A3

lL9s6l20 Dt:18.08.201

Prakasam

10

24t

Ongole

Rangarayudu
Cheruvu

242

Konakanm itla

Veligandla

243

Kandukuru

Bilal Nagar

Rc.No.A3
Final

/t9s6l20 Dt:18.08.2017
10

Rc.No.A3
Final

lL9s6l20 Dt:18.08.201i

l0
Rc.No.A3

244

Chimakurthy

P. Naidupalem

Final

tL9s6/24

Dt:18.08.201i

10
245

Addanki

Namburivaripalem 2Nd Sachivalayam

246

Darsi Mandal

Korlamadugu

Final

247

Pedacherlopalli

Peda Irlapadu

Final

248

Chimakurthy

Pallamalli

Final

Rc.A3.19

Dt15.09.2014

206

V.Punna Rao

M

14960940

8106833626

10.06.1977

23.04.2077

NA

NA

NA

NA

NA

Dt: 12.1 1.2017

510

Sk.Rafi Ahamad

M

14190604

898s268591

02.08.1979

23.04.2072

NA

NA

NA

NA

NA

lLes6/20 Dt:18.08.2017

489

P. Anil Babu

M

14190626

94938s2768

26.08.1979

23.04.2012

(Mala)

NA

NA

NA

NA

Prakasam

Prakasam

56/2010
No.COLP

KM-

Prakasam

Sc-

Rc.No.A3

G.III

10

Rc.No.A3
249

Zarugumalli

Nandanavanam

Final

498

K.Rama Rao

M

14190631

94915tt492

09.12.1979

23.04.2072

SC.III

NA

NA

NA

NA

Prakasam

Prakasam

Dt:12.17.2071

517

P. Sugandhini

F

1419062s

6302332686

08.06.1980

23.04.2012

NA

NA

NA

NA

NA

Prakasam

Prakasam

23.M.20L2

49t

M. Subbarao

M

14190594

9949262908

10.06.1981

23.04.2072

SC

NA

NA

NA

NA

Prakasam

Prakasam

Dt:12.11.2017

490

P..Balaji

M

14190636

9030689742

05.06.1982

23.04.20t2

NA

NA

NA

NA

NA

lr9s6lzo Dt:18-08.2017

s03

Ramadevi Ponnaboina

F

14190996

9849310s08

15.06.1982

23.04.20t2

NA

NA

NA

NA

NA

Prakasam

Prakasam

514

Venkata ramana
kumari Mantri

F

14190610

7337038667

1s.06.1982

23.04.2012

NA

NA

NA

NA

NA

Prakasam

Prakasam

524

Chintapalli Krishnaveni

F

14190597

9703784777

1s.06.1982

23.04.2072

NA

NA

NA

NA

Prakasam

Prakasam

lr9s6lzo Dt:18.08.201i
10

250

Chirala

Devangapuri-2

Final

25t

J. Pangulur

Muppavaram

Final

252

Gudlur

Ammavaripalem

Final

2s3

Ongole

V. N. Colony

Final

No.COLP
KM-

ngs of
Collector
No.COLP

KM.

Prakasam

Rc.No.A3
10
Rc.No.A3

254

Ongole

Gurramvariveedhi

Final

11956120 Dt:18.08.2017

10
Rc.No.A3

255

Maddipadu

Yedugundlapadu

Final

l79s6l20 Dt:18.08.2017
10

scMala

<!-- page 18 -->

Type

of

Sl.No

Name of the
Mandal

Name of the
Sachivalayam

ority
(a)

Provisi Procee

onal/ dings
Tentati Numbe
ve

(1)

(2)

(3)

(4)

o.
Seni

ty:
Final/

o

Seniority list

Seniori

Num

(b)

ber

Korisapadu

Korisapadu

Final

Balajiraopet

Final

Yarajarla

Final

(s)

(6)

Devarampadu

Final

Addanki

Timmayapalem

Final

lL956l20 Dt:18.08.2017

1t956120 Dt:18.08.2017

lr9s6l20 Dt:18.08.2017

lL9s6l20 Dt:18.08.2017

261

Chirala

Paparajuthota-1

Final

?62

Giddalur

Kothakota

Final

263

Inkollu

Idupulapadu 2

Final

No.COLP
KMNo.COLP

f

o)
(o

o)

E

t
po
3

.-60
oc!
-o (-) 12
>>E
c:(J

.9 .g

bE
zz

EFO
g,E;
E
ocJ=;RP5ts b
>(!

I E'afl
!E-0J
c c
vz
.!2
Pt-o
c
O

E

:--^--

(u

6

(f .>

o
oa
o
ts
6

E
(u

G

z.

o

E:A
rr >x
:=(Jo

EBP
tsr:9
EFE
i5!.
E.

o

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

(18)

(le)

(20)

486

Gummalla Yallamanda
Rao

M

t4t90644

9533382599

07.09.1982

23.04.2012

NA

NA

NA

NA

NA

Prakasam

Prakasam

535

Jayalakshmi
Amisagadda

F

14190605

7013504048

25.04.1983

23.04.2072

NA

NA

NA

NA

NA

Prakasam

Prakasam

s08

Praveenbabu
Kadavakuduru

M

14190628

9885467054

17.06.1983

23.04.20t2

NA

NA

NA

NA

NA

Prakasam

Prakasam

502

Kishore Kumar
Gollapati

M

14190629

9553639888

29.08.1984

23.04.20t2

NA

NA

NA

NA

NA

Prakasam

Prakasam

526

J. Sri Lakshmi

F

14190619

7207967766

07.10.1984

23.04.20L2

NA

NA

NA

NA

Prakasam

Prakasam

10

260

9O
qQ

,

6

(8)

Rc.No.A3

Ongole

(,(,

EP'
!6

U
.E

(7)

10

259

DD:MM:W

Joining in
this
category

.-- o

o

d.
(n

G

Rc.No.A3

Ongole

DOB

c
'p
c(u

E
c

10

2s8

Phone No

f

Rc.No.A3

Ongole

CFMS ID

,E

10

257

Gender
M/F

Date

Rc.No.A3

2s6

Name of the
Government
Servant

Date of

f
Or
L-

g)-

sc(GR
Ol:72.77.2017

OUP-

III)
Dt:12.77.2077

s36

Sk. Riruana

F

t4420664

72077 43880

09.04.1985

23.U.2012

NA

NA

NA

NA

NA

Prakasam

Prakasam

119s6120 Dt:18.08.2017
10

511

G Atchaiah

M

14190632

9010201646

10.08.1985

23.04.2012

NA

NA

NA

NA

NA

Markapuram

Prakasam

493

D.Prakasam

M

14190637

80191 12956

25.06.1986

23,04.20t2

NA

NA

NA

NA

Prakasam

Prakasam

KM-

Rc.No.43

264

Singaraykonda

265

Markapuram

266

Karamchedu

Singarayakonda 2

Ward Sachivalayam
27

Final

Final

No.COLP

KM.
No.COLP
KM-

Dti72.71.Zoli

SC
(TYALA)

Dt:12.11.2017

518

A. Ramu

M

14190635

950588747s

07.12.1986

23.U.20r2

NA

NA

NA

NA

NA

Prakasm

Prakasam

Dt:12.11.2017

516

M Ramesh

M

14190609

918204s679

L4.0t.7987

23.M.20t2

NA

NA

NA

NA

NA

Markapuram

Prakasam

t19s6120 Dt:18.08.2017

479

P.V.Koteswara Rao

1,4

14t90732

9966691830

18.06.1987

23.04.2012

NA

NA

NA

NA

NA

Prakasam

Prakasam

s06

Bonthu Sudhakar

M

14190593

99492s869s

06.05.1988

23.04.20t2

SC.II

NA

NA

NA

NA

Prakasam

Prakasam

507

Tella Eulleaih

M

14190592

939M37734

12.06.1988

23.U.2012

NA

NA

NA

NA

Prakasam

Prakasam

505

B.Ravi Kumar

M

14190il0

95534 33081

05.01.1991

23.04.2012

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

No.COLP
KM.
Rc.No.A3

Swarna-1

Final

10
Rc.No.A3

267

Korisapadu

Thimmanapalem

Final

1t956120 Dt:18.08.2017
10
Rc.No.A3

268

Maddipadu

Rachavaripalem

Final

lt9s6l20 Dt:18.08.2017
10

269

Chirala

Andhra Ratnagar
(Deputation In

&-

Rc.No.A3
Final

Minsters Omce)

l19s6l20 Dt:18.08.2017
10

270

Vetapalem

Pullaripalem

Final

27t

Tripuranthakam

Miriyamapalli

Final

No.COLP
KMNo.COLP
KN4-

scMadiga

(Mala)

G.]II
Dt:12.11.2017

512

G. Nancherlu

M

14190633

8186848508

01.07.1991

23.04.2012

Dt:l2.lL.2OL7

525

B. Nasaraiah

M

14190607

9581376632

07.07 .7984

24.M.2012

NA

SC

(Mala)

<!-- page 19 -->

0.)

Type

q

of

OJ

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
Final/
Provisi
onaU

ority
(a)
Procee

dings
Tentati Numbe
VC
f

(1)

(2)

(3)

(4)

272

Chinnaganjam

Chintagumpalli,
Gonasapudi

Final

273

Podili

Sudanagunta

Final

274

Gudlur

Puretipalli

Final

o.

Num

(b)

ber

Name of the

Government
Servant

Date of
Gender
M/F

CFMS ID

Phone No

DOB

DD:MM:YY

Joining in
this
category

C

o
.F

Ou
(, l,

(-)o
(r^

=
c,l

o
c

(u

o

Date

t
po
3

.9
!

c
CJ
E

cD.=o
>o
O!G_
.-60
oc!
-6.' (J ll
>>=

.9
.g
2C

bE

=z

c

(l)

-b
E(l)
>6 o

- g;';

=
E
o9l 56y

SEits

d.
tt)

U
E

(u

o
oq

6
35.
E59

o
U

bsP

'F oo
:=90:

Er:9

E-18E
e =a:
=.U

.q
!

z.

oo-

C C

!.O

(l)

o

EEE

i5!c
'o

o

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

(18)

(1e)

(20)

Dt:12.11.2017

483

P. Nagaraju

M

urg0622

7680977413

02.06.1985

24.04.20t2

NA

NA

NA

NA

NA

Bapatla

Prakasam

17956120 Dt:18.08.2017
10

490

K.V.Anil Kumar

M

14190539

77805803s6

27.08.1987

24.04.2012

NA

NA

NA

NA

NA

Prakasam

532

l.Chinna Kondamma

F

14190590

7382400885

1 1.1 1.1988

24.04.2012

NA

NA

NA

NA

NA

Prakasam

Dt:12.11.2017

509

Ch. Parvathi

F

14190651

78158 27205

30.03.1989

24.M.20t2

NA

NA

NA

NA

NA

Prakasam

Prakasam

lt9s6l20 Dt:18.08.20U

s30

Vasanthi Veerapineni

F

14190621

8742s20709

2 1.04.1989

24.04.2072

NA

NA

NA

NA

NA

Prakasam

Prakasam

s29

D.Vani

F

14190589

8187803801

20.08.1990

24.04.20]2

SC

NA

NA

NA

NA

Prakasam

Prakasam

543

P!.Padmavathi

F

14190865

8639983953

22.08.1984

03.1 1.20 12

SC III

40 o/o

NA

NA

NA

Markapuram

Prakasam

501

A.Macherla

I\4

14190630

6302776234

18.05,1980

23.04.2013

SC.III

NA

NA

NA

NA

Prakasam

Prakasam

(s)
No.COLP

KM.
Rc.No.43

Rc.No.43

lt9s6l20 Dt:18.08.2017
10

275

Chirala

Ramakrishnapuram-1

Final

276

Ongole

Kammapalem

Final

No.COLP
KM-

10

277

lGndukuru

Kondamudusupalem

Rc.No.43
Final

/t956120 Dt:18.08.2017
10
Rc.No.A3

278

Bestavaripeta

Konapalli

Final

/L9s6l20 )t:18.08.2017
10

Rc.No.A3

279

Racherla

Gudimetta

Final

/19s6120 )t:18.08.2017
10

Rc.No.A3
280

Cs Puram

Nallamadugula

Final

11956/ZO
10

)t:18.08.20 17

549

T lohn Lipi

M

14191302

9704599470

01.06.1973

11.06.2013

SC II

NA

NA

NA

NA

Prakasam

Prakasam

281

Parchur

Devarapalli

Final

lL9s6/20 Dt:18.08.2017

554

K.Sujatha

F

14191217

7780353690

01.06.1983

r1.06.2013

NA

NA

NA

NA

NA

Bapatla

Prakasam

550

K Malyadri

M

14191233

9676824958

05.05.1974

12.06.2013

SC III

NA

NA

NA

NA

Prakasam

Prakasam

551

Ch.Thimmaiah

M

14191 153

90t0246264

L5.07.t974

72.06.2073

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt:12.1 1.2017

552

B. Vankata Rao

M

77197229

9s0ss60199

20.08.r980

12.06.2013

NA

NA

NA

NA

NA

Prakasam

Prakasam

lt9s6lz0 Dt:18.08.2017

555

S.China Satyam

M

14191605

9542277756

07.06.1965

13.06.2013

NA

NA

NA

NA

NA

Markapuram

Prakasam

548

D. Polaiah

M

14191710

967ffi35724

06.05.1972

13.06.2013

Group

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

Rc.No.A3
10
Rc.No.A3

282

Cs Puram

Pedarajupalem

Final

/L9s6l20 Dt:18.08.2017
10

Rc.No.A3
283

Ardhaveedu

Yachavaram

Final

lr9s6l20 Dt:18.08.2017
10

284

Kothapatnam

Alooru

Final

28s

Yerragondapalem

Kasikunta Thanda

Final

No.COLP

KM.
Rc.No.A3
10

286

Kothapatnam

Ethamukkala -Ii

Final

No.COLP

KM.

sc
Dt:12.1 1.2017

III
sc-

Rc.No.A3
287

Tangutur

Kakuturivaripalem

Final

lL956l20 Dt:18.08.2017
10

556

M.Mosha

M

74797697

%4029t76t

04.07.7973

13.06.2013

Group

II

<!-- page 20 -->

Type

of

a
OJ

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
Final/
Provisi

ority
(a)
Procee

onal/
dings
Tentati Numbe
ve

I

(s)

(1)

(2)

(3)

(4)

288

Martur

Nagarajupalli

Final

o-

Num

(b)

ber

Name of the
Government
Servant

Gender
MIF

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in

this
category

Date

Peda Pattapupalem

Final

Sn Padu 2

Final

Santhamaguluru

Kommalapadu

Final

lc.No.A3
tL956120 Dt:18.08.2017

292

Peddaraveedu

Pucchakayalapalli

Final

293

Singaraykonda

Somarajupalli

Final

No.COLP
KM.

t
po
=

>- >E
c:(J
.o 'sl

be
21

q 5 E;s

ts

C tr

E-(u

g-23&
E
g

9a:
^-a

i= -Z

.q
!

o
o

:=(9o

beE
E:9
f;g&
6!c
,6

z.

o.
o.

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(L7)

(18)

(1e)

(20)

563

M.Ratna Raju

M

74191037

9014613301

02.o2.1977

17.06.2013

SC.
Mala

NA

NA

NA

NA

Prakasam

Prakasam

564

K.layalakshmi

F

14191 188

9502784345

12.08.L979

18.06.2013

Group

Prakasam

Prakasam

Yes

III

lL9s6l20 Dt:18.08.2017

4812010

0)

E

o

EEIU
'F OO

sc-

tt956120 Dt:18.08.2017

RC.A3l38

c

OJ

6q

(e)

561

D Srinivasulu

M

14791222

898s80804s

01.06.1980

18.06.2013

s66

K.Kotamma

F

14191298

6300409169

19.05.1971

19.06.20 13

10

291

ro c\

3

ol
(o

g7'.;
E
o-O- i Fu

o
a
o

(8)

Rc.No.43
Santhanuthalapadu

q;o

eP,

!o_
.-60
oc!
oull

>.oEF
o

(7)

10

290

(,(./.)

o
.F
C

,

=

o
U

d
at)

6

(6)

l,c.No.A3

Ulavapadu

9u

o
.9
E

10

289

C

l

o.=o

SC(Gro

up III)

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

sc(GR
13.06.2013

OUP-

nD
Dt:12.1 1.2017

565

T Guravaiah

M

7419Lt92

9542789730

0s.09.1980

19.06.2013

NA

Dl:72.11.2071

545

D. Venkatadri

M

74791667

99639s2923

07.05.L974

06.10.2013

Group -

ea

294

Tripuranthakam

Rajupalem

Final

29s

Darsi Mandal

East Venkatapuram

Final

No,COLP
KMNo.COLP

III
Dt:12.1 1.2017

547

Sk. Kasim Peera

M

1479t249

9010408714

t5.07.L972

06.1 1.2013

NA

lL9s6l20 Dt:18.08.20 17

558

N.Srinivasa Rao

M

74192156

9912309949

Q.07.1976

06.12.2013

Group

KM-

SC

Rc.No.A3
10

1

Rc.No.A3

296

Darsi Mandal

Chandaluru

Final

lL9s6/20 Dt:18.08.2017

675

K.Meerabee

F

74792019

8978474591

0 1.06.1982

03.02.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

M

t4792094

9703403660

08.01.1988

03.02.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

10

297

Tripuranthakam

Nadigadda

Final

298

Markapuram

Pedda Nagulavaram

Final

No.COLP

K Venkata Krishna

Dt:12.1 1.20 17

591

n956120 Dt:18.08.2017

657

Kopparapu Kalyani

F

14192090

995901 1956

16.08.1990

03.02.2014

NA

NA

NA

NA

NA

Markapuram

l'larkapuram

702

A.Narsireddy

M

14792454

9666894995

29.06.1991

03.02.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

678

Gannarapu Swathi

F

74792149

9L7782tt49

08.05.1993

03.02.20t4

NA

NA

NA

NA

NA

Dt:12.1 1.2017

674

G Mounika

F

74t9209t

7893936386

01.07.1994

03.02.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

tr9s6l20 Dt:18.08.2017

s68

A.Venkata Subramanye
Kumar

M

14192106

9963671581

31.08.1995

L2.02.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

569

M Ramana Reddy

M

14792774

98481 16963

06.07.198s

t7.02.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

KM-

Reddy

Rc.No.A3
10

299

300

Konakanmitla

Markapuram

On Deputation To
Crda Amaravathi

Ramachandrapuram

Rc.No.A3
Final

n956120 Dt:18.08.2017
10

Final

t956l20 Dt:18.08.2017

Prakasam

10

301

Konakanmitla

Chinthagunta

Final

302

Martur

Marturlv

Final

No.COLP
KMRc.No.A3
10
Rc.No.A3

303

Tallur

Vitalapuram

Final

n956120 Dt:18.08.2017
10

<!-- page 21 -->

Type

of

at

o
q,
Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:

ority

Final/

(a)

Provisi

Procee

onal/
dings
Tentati Numbe
ve

(1)

(2)

(4)

(3)

o.

Num

(b)

ber

Name of the

Government
Servant

Gender
M/F

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in
this
category

Date

E

3

Ou
(9u,
q) 0

(/)c\

o
f
c',

o

E
q,
E

f
o

E
'=

OJ

.E

!

(s)

(6)

G:L
'-6c! o

(l)L,

E - g,;';
0,,

):E 12
c=(J

.og
2c
bE
=1

I

(uco -b
>'(tJ o
=

Pu
.=o
EP
!.!_

fiH;sx
tE'O.)I t'afl
C
E

E-ZE&
c
-&6
E
=a:
e.>

d.

a
o
oo
o
U
.E

!

(u

I
E

c)

o .: cl

EEE

:= (9 o:

bBP
E:9
H ge
i5Ec

zo

'6

o.
o.

o

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

(18)

(le)

(20)

57L

P Madhu

M

74792709

9640674146

20.06.1985

20,02.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

681

Kavuri
Amruthaleelamma

F

14368018

9491709285

25.08.1978

02.03.2014

NA

NA

NA

NA

Prakasam

Prakasam

596

K Hanumantharao

M

14792779

9603782477

10.03.1982

02.03.2014

up III)

NA

NA

NA

NA

Prakasam

Prakasam

s98

Ch.lvlurali

M

L4L92576

9703ss0312

06.05.1984

02.03.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

587

Cherukula
Mallikharjuna Reddy

M

14192048

7013145596

20.06.L987

02.03.2074

NA

NA

NA

NA

NA

634

N Krishna

M

14792735

9666912352

25.06.1987

02.03.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

Rc.No.A3

304

Santhanuthalapadu

Mynampadu

Final

lr9s6l20 Dt:18.08.2017
10

Rc.No.A3

30s

Maddipadu

Seetharampuram

Final

lr9s6l20 Dt:18.08.2017
10

Rc.No.A3
306

Santhanuthalapadu

Final

Chilakapadu

lL9s6l20 Dt:18.08.2017
10

SC.

Madiga
SC(Gro

Rc.No.A3
307

Darsi Mandal

308

Markapuram

Pajmpalli

Ward Sachivalayam
74

Final

11956120 Dt:18.08.2017
10

Final

/t9s6l20 Dt:18.08.2017

Rc.No.A3
10

Prakasam

Rc.No.43
309

Peddaraveedu

Peddaraveedu

Final

/L9s6l20 Dt:18.08.2017
10

310

Singaraykonda

Singarayakonda 1

Final

No.COLP
KM-

Dt:12.1 1.2017

557

I Prabhakar

N4

14192053

9885672346

09.06.1988

02.03.2074

ST

NA

NA

NA

NA

Markapuram

Prakasam

311

Martur

lvlartur-Ii

Final

lL9s6l20 Dt: 18.08.2017

s89

T.Nagaraju

M

14192105

9949279376

05.07.1988

02,03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dl:12.11.20]7

679

Yarajarla Ankamma

F

14192055

7095294235

15.04.1990

02,03.2014

NA

NA

NA

NA

Prakasam

Prakasam

lt9s6l2c Dt:18.08.2017

580

Venkata Rajasekhar
Reddy Narala

M

14192088

9s027616s6

06.06.1990

02.03.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

679

Sk.Fareeda

F

14192092

9963892039

01.06.1992

02.03.2074

NA

NA

NA

NA

NA

Markapuram

Prakasam

632

Abdul Rahiman Shaik

M

1419210 1

949377s866

16.06.1986

03.03.2014

NA

NA

NA

NA

NA

V.Ashok

M

t4t92731

97001L4477

25.06.1986

03.03.2014

NA

NA

NA

NA

NA

662

V Ramadevi Battu

F

14192734

9247847736

19.03.1989

03.03.2014

NA

NA

NA

NA

NA

606

Gayam Subbarcddy

M

14192095

9700448876

17.03.1990

03.03.20r4

NA

NA

NA

NA

NA

Prakasam

Prakasam

572

K.Baleswara Rao

M

14192009

7660843511

06.01.1980

t2.03.2014

NA

NA

NA

NA

NA

Markapuram

Prakasam

Rc.No.A3
10

372

Maddipadu

Doddavarapadu

Final

313

Kanigiri

Vangapadu

Final

No.COLP
KM.
Rc.No.A3
10

SC.
Mala

Rc.No.A3

314

Giddalur

Giddalu18

Final

lL9s6lzc Dt:18.08.2017
10
Rc.No.A3

315

14a rripud i

Final

Kakarla

lr9s6/2c Dt:18.08.2017

Prakasam

10

316

Ballikurava

Chennupalli

317

Markapuram

Gajjalakonda

Prakasam

Prakasam

Rc.No.A3
1

Final

lL9s6l20 Dt:18.08.2017

Prakasam

10
Rc.No.A3

318

Korisapadu

Anamanamuru

Final

lt956l2C Dt:18.08.2017
10

319

Yerragondapalem

Gangapalem

Final

No.COLP

KM.

Dt:12.1 1.2017

<!-- page 22 -->

Type

of

Seniority list

Seniori
Sl.No

Name of the

Name of the

Mandal

Sachivalayam

Provisi
onaU

ority
(a)
Procee

dings
Tentati Numbe
VC
r

(1)

(2)

(3)

(4)

320

Kothapatnam

Rangayapalem

Final

32L

Darsi Mandal

Devavaram

Final

oSeni

ty:
Final/

o
OJ

Num

(b)

ber

Name of the
Government
Servant

Gender

MIF

CFMS ID

Phone No

DOB

DD:MM:W

f
Qu

Date of
loining in
this

(,u)
L)o
t/)i

category

o

.o
o)
(!

E

.=o-

AP
!G

.- G
oc-!
-o (J lf

O.)

c:(J

=
!'=

G

Date

o

.9

E

,
E

ctr

.9 .E

bE

Et
>c
cn

g - g,E;
ooi;+P6EK

;5 e',>fl
3 -z e g
O

t,

E

(l)

E 3A

o.

o

(o

ti
a

E
(u

:--^-

i=.>

=z

o
U

d.

(o

z

c)

.F OO

:i9or

EBP

E:9
,:6al
6

cd

6Ec

'o
oo-

o

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(rs)

(16)

(L7)

(18)

(1e)

(20)

Dt:12.1 1.20 17

s86

G. Siva Kumar

M

t4t92LO7

9182988313

01.07.1986

22.03.20t4

NA

NA

NA

NA

NA

Prakasam

Prakasam

tt956120 Dt:18.08.2017

646

M.Murali

M

14192020

9652402986

15.06.1983

23.O3.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt:18.08.2017

6s3

P.Padmaja

F

14192083

9966863696

05.06.1989

2s.03.20L4

NA

NA

NA

NA

NA

It9s6l20 Dt:18.08.20 17

6L4

M.V.Satheesh

N4

14192085

818781 1012

04.08.1978

27.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

618

V.Sivasankar

t4

74t92032

9494859543

12.07.1983

27.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt:72.11.20t7

602

M. Srinivasa Rao

M

t4t92LL5

901047983 1

15.06.1987

27.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

lr9s6l20 Dt:18.08.20 17

635

A.Siva Sankar

t4

14190076

7660093998

03.04.1988

27.03.20t4

NA

NA

NA

NA

NA

Prakasam

Prakasam

579

P.Seshu Babu

M

14192084

8499946068

16.07.1989

27.03.20t4

NA

NA

NA

NA

NA

Prakasam

Prakasam

638

Sk.Shahid

M

L4L92LL2

9848428439

t0.07.7979

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

616

K.Guravaiah

M

t4192tt7

9885855655

18,08.1981

28.03.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

654

Shaik Arifa

F

74792097

9550776717

05.01.1982

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

6L7

N. Sudakar

M

74792125

830914561

L4.07.7982

28.03.2014

(Gr-llI)

NA

NA

NA

NA

Prakasam

Prakasam

575

Ch.Subbareddy

M

14792049

8985606256

20.08.1982

28.03.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

Otil2.Ll.2077

581

D. Surendra Babu

M

74792102

9652887886

07.09.1982

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

lt9s6l20 Dt:18.08.2017

645

D Nanda Kumar

M

74792727

994824726s

12.06.1983

28.03.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

683

Vani Devarakonda

F

14389625

7981090956

04.01.1984

28.03.2074

Yeruka

NA

NA

NA

NA

Prakasam

Prakasam

(s)
No.COLP
KMRc.No.A3
10

lc.No.A3

322

Gudlur

Mocherla

Final

t7956120

Prakasam

10
Rc.No.A3

323

Zarugumalli

Paidipadu

Final

10
Rc.No.43

324

Karamchedu

Kodavalivasi Palem

Final

lL9s6l20 Dt:18.08.2017
10

32s

Addanki

Gajulapalem - 4Th
Sachivalayam

Final

326

Kandukuru

Budidhapalem

Final

No.COLP
KMRc.No.43
10
Rc.No.A3

327

Yaddanapudi

Poluru

Final

328

Cumbum

Ravipadu

Final

329

Ballikurava

Kopperapadu

Final

330

14addipadu

Pedakothapalli

Final

119s6120 Dt:18.08.2017
10
Rc.No.A3
11956120 Dt:18.08.20 17
10
Rc.No.A3
17956120 Dt:18.08.2017
10
Rc.No.A3
t795612A Dt:18.08.2017
10
Rc.No.A3

331

l.Pangulur

T. Kopperapadu

Final

It9s6l20 Dt:18.08.2017

1

10

Sc l4ala

Rc.No.A3

332

Kandukuru

Palukuru

Final

179s6/20 Dt:18.08.2017
10

333

Addanki

Kakanipalem - 1St
Sachivalayam

Final

334

Singaraykonda

Pakala 1

Final

No.COLP
KMRc.No.A3
10

Rc.No.A:
33s

Ongole

Islampeta

Final

l19s6l2( Dt:18.08.2017
10

STa

<!-- page 23 -->

(u

Type

of

Seniority list

Seniori

Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Provisi
onaU

ority
(a)
Procee

dings
Tentati Numbe
ve
f

(1)

(2)

(3)

(4)

336

Kanigiri

Muggubavi

Final

CL

Seni

ty:
Final/

o
o

Num

(b)

ber

Name of the

Government
Servant

Gender
M/F

CFMS ID

Phone No

DOB

6Lo

DD:MM:W

this

.h Q'

category

Date

o

9g

Date of
Joining in

(Jo

f
c'l
G
g

lIJ

(u

E

t
po
3

.E

E
c

9o
.=o
eP,
!o_
,-do

,

EF

E
- A"€H
o_ruiFs

E6i gEEfs
>>E
c:(J
o(o

6E
=z

.E-z3g
c
E^O

C C

d.

U)

(u

o-

a
o

U
,9

E

(u

(J

E
o

ai6.
EE8
:=(9o

bs3

Er-9
EEE
i5tsc

g =-6
ea:
i7.2

z

(!

'6

o.
o
o

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(L7)

(18)

(1e)

(20)

597

Sreekanth Basireddy

M

1442935s

9676541102

04.05.1984

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Pra kasam

Dt:12.1 1.2017

651

Sk. Mahaboob Basha

M

r4t927c/,

988s83s268

05.04.1985

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

L9s6l'20 Dt:18.08.2017

664

V.Srilatha

F

t4792t20

8LO5r't1672

06.06.r985

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

631

D. Ashok

M

74792t33

85199 s1916

20.05.1986

28.03.2014

(Mala)

NA

NA

NA

NA

Prakasam

Prakasam

(s)

(6)

L9s6l20 Dt:18.08.2017
10

337

Addanki

Kattkindapalem, 9Th
Sachivalayam

Final

338

Inkollu

Pavulurl

Final

No.COLP

KM.
Lc.No.A3
10

339

Chirala

Bosenagar

Final

No.COLP
KM-

Sc-

)t:Lz.7t.20]7

G-III

Rc.No.A3

340

Kanigiri

Punugodu

Final

619

Moulali Pulimaddi

M

t4t92729

9398797703

08.06.1986

28,03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt:18.08.2017

665

G,Madhavi

F

14192098

8374455476

06.07.1986

28.03.2014

SC-B

NA

NA

NA

NA

Prakasam

Prakasam

lt9s6l2c Dt:18.08.2017

648

Y.Vijaya Kumar

M

t4r92t23

8897330014

17.08.1986

28.03.2014

NA

NA

NA

NA

Prakasam

Prakasam

675

M. Madhavi

F

14192043

9440648595

05.10.1986

28.03.2014

NA

NA

NA

NA

Prakasam

Prakasam

/t9s6lzc )t:18.08,201 7
10
Rc.No.A3

341

Naguluppalapadu

Maddiraralapadu

Final

lL9s6/2C
10
Rc.No.A3

342

Ponnalur

Chowtapalem

Final

10

343

Singaraykonda

Mulaguntapadu 2

Final

No.COLP

KM.

SCGr3
SC,

Dt: 12.1 1.2017

Sroup

III

Rc.No.A3

344

Ballikurava

Uppumaguluru2

Final

lL9s6/20 Dt:18.08.2017

602

B.Ashok Chakravarthy

M

L4L92t37

76809r5785

08.05.1987

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

676

D.Bhagyalakshmi

F

t4r92t47

9676s2693s

72.07.1987

28.03.2014

NA

NA

NA

NA

NA

Markapuram

Prakasam

629

Godugula Sudhakar

M

14192100

88859489s8

11.08.1987

28.03.2074

NA

NA

NA

NA

Prakasam

Prakasam

652

Maram Aruna

F

t4420669

6301962582

06.0s.1988

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

649

M.Pavan Kumar

M

L4L92L22

949107901 1

15.07.1988

28.03.2014

Group

NA

NA

NA

NA

Prakasam

Prakasam

10
Rc.No.A3

345

Bestavaripeta

Pitikayagulla

Final

lr9s6l20 Dt:18.08.2017
10
Rc.No.A3

346

Maddipadu

Maddipadu

Final

/r9s6120 Dt:18.08.2017
10

scMala

Rc.No.A3

347

Maddipadu

Basavannapalem

Final

lr9s6l20 Dt:18.08.2017.
10

SC.

Rc.No.A3

348

Ulavapadu

Ulavapadu-2

Final

lt9s6l20 Dt:18.08.2017

III

10

349

Chirala

Paparajuthota

Final

350

Tallur

East Gangavaram

Final

351

Mdanki

Kalavakuru

No.COLP

Dt:12.77.2077

636

M. Rambabu

M

14192153

98667 14831

03.08.1988

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

1L956120 Dt:18.08.2017
10

593

D Siva Reddy

M

14192030

80089 33202

14.06.1989

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

G. Lakshmaiah

M

14t92034

8985677816

27.07.1989

28.03.20L4

NA

NA

NA

NA

Prakasam

Prakasam

KMRc.No.A3

SC(GR

cuP-rr)

<!-- page 24 -->

Type

of

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

ority

Final/

(a)

Provisi

Procee

onal/ dings
Tentati Numbe

(1)

(2)

(3)

(4)

o.
Seni

ty:

ve

a
o

(b)

Num
ber

Name of the
Government
Servant

Gender
MIF

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in
this
category

Date

9u
(, La
q;o
o^

o
or
o
E

o
E

f

o

(u

E
.;

.E
C

E

r

(s)

:,

o).=o

ru
E

->
co
>ocn

.-oo

E - g,A;

C:(J
o.q

.9

bE
zz

O

EP'
!d

o()=;i!
6 O,;
6-Cv'LO

f

E6€ :t 3 g'>f
>>=
z

L

-z p E

C)

d.
(t
c)

oq

G

E
.a
!
OJ

:--^-

g->

G

z.

a
.E
6)

op!*

E ad

:: L:J OJ
oo2
t!Q

EFE

o!c

'o
oo.
G

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

(18)

668

Patipandla Malleswari

F

14191960

6305990940

06.01.1990

28.03.2074

NA

NA

NA

NA

NA

641

G.Siva Nageswara Rao

M

L4L92748

99s1547135

15.07.1990

28.03.2014

Group

NA

NA

NA

NA

Prakasam

Prakasam

Prdkasam

Prakasm

(1e)

(20)

1c.No.A3

3s2

Markapuram

Goguladinne

Final

tt956/ZA Dt:18.08.2017

Prakasm

10

tc.No.A3
353

Ballikurava

Muktheswaram

Final

SC-

tt956120 Dt:18.08.2017

II

10

354

Yaddanapudi

Anantha\raram

Final

lc.No.A3
tt956120 Dt:18.08.2017

6s0

T.Mary Pavani

F

L4t92t2l

7675803753

10.06.1991

28.03.2014

SC-III

NA

NA

NA

NA

610

Gonasani Badulla

M

L4429354

8463951615

1 1.06.1991

28.03.2014

NA

NA

NA

NA

NA

611

Sri.D.Kasimvali

M

14192060

8790233987

10.07.1991

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

637

T.Mahesh Babu

M

14192033

9666794860

20.07.1991

28.03.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

665

B. Madhavi

F

L4L92047

9381933369

15.06.1992

28.O3.20t4

Group

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

10

355

H.M.Padu

Thimmareddypalli

Final

lc.No.A3
tL956l20 Dt:18.08.2017

Prakasam

10
Rc.No.A3

3s6

Komarole

Chintalapalli

Final

lL9s6l20 Dt:18.08.2017
10
Rc.No.A3

357

Darsi Mandal

Bandiveligandla

358

Kothapatnam

Madanuru

li

Final

Final

11956120 Dt:18.08.2017
10
No.COLP
KM-

SC

Dt:12.11.2017

III

Rc.No.A3

359

Parchur

Nuthalapadu-1

Final

1L956120 )t:18.08.2017
10

360

Santhanuthalapadu

Santhi Nagar

Final

lt9s6l20 Dt:18.08.2017

680

M.Sireesha

F

14192010

9550096154

77.04.1995

28.03.2074

639

K Jalaiah

M

14192118

9642475383

02.06.1983

29.03.20L4

630

K.lagadeesh

M

14L92150

8374231930

24.M.1986

79.03.2Ot4

NA

NA

NA

NA

NA

Prakasam

Prakasam

605

G.Rajesh

M

14192059

8801290226

01.01.1990

29.03.20t4

NA

NA

NA

NA

NA

Prakasam

Prakasam

DtiL2.7l.20L7

6s9

I Sujatha

F

L4LgzLtt

8790557021

07.02.1992

29.03.20L4

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt:12.1 1.2017

627

P.Krishna Prasad

M

14368019

98490921048

06.10.1983

01.04.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt:12.11.2017

600

M. Ramanjneyulu

I\4

14192051

79811 63268

24.07.L985

01.04.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

lL956lZO Dt:18.08.2017

684

B.Rajasekhar Reddy

M

14368020

9494529465

29.03.1982

02.05.2014

NA

NA

NA

NA

NA

Markapuram

Prakasam

700

M.Revanth Kumar

M

14t92376

8374515227

08.01.1992

11.06.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

Rc.No.A3
10

NA

SC(Gro

up UI)

Rc.No.A3

361

Naguluppalapadu

Chadalawada

Final

lr9s6/20 Dt:18.08.2017
10
Rc.No.A3

362

Inkollu

Gangavaram

Final

tL956lZO Dt:18.08.2017
10

363

Mundlamur

Sankampuram

Final

3ffi

Inkollu

Bhimavaram

Final

36s

Chirala

lakkavaristreet

Final

366

Giddalur

Giddalur-5

Final

No.COLP
KMNo.COLP
KM.
No.COLP
KM.
Rc.No.A3
10

367

Ponnalur

Singarabotlapalem

Final

No.COLP

KM.

Dt:12.11.201i

<!-- page 25 -->

o)

Type

of

q

Seniori

Sl.No

Name of the
Mandal

Name of the
Sachivalayam

ority
(a)

Provisi Procee

onal/
dings
Tentati Numbe
ve
f

(1)

(2)

(3)

(4)

368

Ongole

Pothurajukaluva

Final

o.

Seni

ty:
FinaU

o

Seniority list

(s)

Num

(b)

ber

Name of the

Govemment
Servant

Gender

wr

CFMS ID

Phone No

DOB

Date of
Joining in

DD:MM:W

this
category

(,9r(/)
(Jo
(,G.

o
f
g)
6
c

o)

6

Date

(6)

3

q)

E

t
po
3

.9

!,
c

9o
.=o
>o
G-

!t!_
G=L
.-60
oc!

-lE0,
>.(I, o

(l)
=

E , 9, e',i

E9;EX
.o L) lJ
>>E
E=(J
.9
.S'
YC

bE
z1

d

(l)

o

o-

.9r!f

G

:=(9o
=

q

ts

g'ae
!8
E-0J
pc c

!

g -a:
=.>

z

.:2

-z

lP

(J
.E

art

.9

o
o

ed

beE
UrQ

EEP

i5Ec
'6

o.
o.
6

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

G7)

(18)

(1e)

(20)

553

Suresh Nunna

M

14191685

6300340072

15.06.1982

13.06.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

689

Narasimham Bariga

M

14792346

9010464846

01.06.1969

2t.07.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

687

( China Venkataswamt

M

14792218

9014408313

06.01.1974

2t.07.7074

SC-III

NA

NA

NA

NA

Prakasam

Prakasam

688

P.Haribabu

M

741922t9

9948893938

05.07.1985

21.07.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

690

D Narasimha

M

L4192367

9010744789

28.07.r97r

22.07.20t4

NA

NA

NA

NA

691

R.Radhamma

F

L4t92282

7032313395

20.04.t974

22.07.2074

NA

NA

NA

NA

NA

Prakasam

Prakasam

692

U Hanok

M

t4192220

9000451766

3 1.05.1983

23.07.2074

Group

NA

NA

NA

NA

Prakasam

Prakasam

Rc.No.A3

lL9s6l20 Dt:18.08.2017
10

Rc.No.A3
369

Kanigiri

Challagirigala

Final

lL9s6l20 Dt:18.08.2017
10

Rc.No.A3

370

Pamur

Dubagunta

Final

lr9s6l20 Dt:18.08.2017
10

Rc.No.A3

37r

Kandukuru

Vikkiralapeta

Final

l1956120 Dt:18.08.2017
10

Rc.No.A3
372

Marripudi

Chilamkuru

Final

lr9s6l20 Dt:18.08.2017

SCGr3

Prakasam

10
Rc.No-A3

373

Inkollu

Vankayalapadu

Final

lL9s6l20 Dt:18.08.2017
10

SC

Rc.No.A3
Kothapatnam -l

374

Kothapatnam

375

l,larkapuram

Nikarampalli

Final

376

Ongole

Karavadi 1

Final

Final

1L956120 Dt:18.08.2017
10
No.COLP

II

Dti17.11.2017

69s

Kukatla Hemalatha

F

t4429369

%92]34677

08.12.1990

14.08.2014

SC-II

NA

NA

NA

NA

Markapuram

Markapuram

lr9s6/20 Dt:18.08.2017.

685

V.S.C.L.Sairam Elchuri

M

t4192767

9912079443

27.08.t978

05.09.2014

NA

NA

NA

NA

NA

Prakasam

Prakasam

696

Y Bala Venkata Reddy

M

t4192296

9440862767

05.04.1970

1 1.09.2014

NA

NA

NA

NA

NA

697

Ch.Anusha

F

L4r92327

789355801 1

20.06.1990

20.09.20L4

NA

NA

NA

NA

NA

Prakasam

Prakasam

698

L. Bala Chandra

M

t4192375

8885405311

05.02.1989

05.1 1.2014

Group

NA

NA

NA

NA

Prakasam

Prakasam

KM.
Rc.No.A3
10

Rc.No.A3
377

Podili

Pamulapadu

Final

lr9s6l20 ft:18.08.2017

Prakasam

10

Rc.No.43

378

Cumbum

Chinna Cumbum

Final

379

Kothapatnam

Alluru - Ii

Final

1L956120 Dt:18.08.2017
10

SC

380

Podili

Poili - 4

Final

381

Tarlupadu

Chennareddypalli

Final

No.COLP

KM.
No.COLP

Dt:12.17.2011

III
Dl:L2.77.2017

699

M. Ramesh

M

L4L92373

8881288873

10.06.1989

06.11.2014

SC-III

0.77

NA

NA

NA

Prakasam

lL9s6l20 Dt:18.08.2017

701

Venkata Siva lGsaiah
Kancharla

M

14192386

8309786861

08.09.1996

06.1 1.2014

NA

NA

NA

NA

NA

Prakasam

567

Sinde Sowjanya

F

r4t92y6

7799482103

13.06.1993

02.12.2014

NA

NA

NA

NA

NA

Markapuram

Markapuram

703

S. Radha

F

14t92491

8500617s07

06.01.1980

23.02.20t5

NA

NA

YES

NA

NA

Prakasam

Prakasam

KM.
Rc.No.43
10
Rc.No.A3

382

Markapuram

Gajjalakonda 2

Final

1t956120 Dt:18.08.2017
10
Rc.No.A3

383

Chimakurthy

Chandrapadu

Final

lt9s6l20 Dt:18.08.2017
10

<!-- page 26 -->

Type

of

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

o
o
oSeni

ty:

ority

Final/

(a)

Provisi

Num

Procee

ber

onal/
dings
Tentati Numbe
ve

I

(s)

(1)

(2)

(3)

(4)

384

Podili

Podili - 2

Final

385

Kanigiri

Baduguleru

Final

(b)

Name of the

Government
Servant

Gender

MIF

CFMS ID

Phone No

DOB

DD:MM:W

c
o

Qu

Date of
loining in
this

(, (,
()o
a/)i

category

q,

l

(,)
(o

E

=
!'=

o

Date

o

.9

c

cT),=o
>o
O!o_
'-60
o=:(-)
o
.!l
- >-c
c:(J
.oE
2C

bE
zz

,
-o

EF
>o9t

p - g,E;
FH.iEE
O bE
E
!=(.JEc
.E -z= e I

d.

o
U
'u

o
o.

-6-!*

U'

o
ts
.9

o

o

o

E B6
iee
o-9=

tr:Q

E-P&.

a
-E sa:
i:, .>

z.

6

6Ec
'o
o
o-

(le)

(20)

c

o

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(L7)

(18)

706

V Yakob

M

t4t92478

9951423490

2s.09.1978

0s.03.201s

SC-II

NA

NA

NA

NA

709

Dasari Kaseerao
Khasim

1,4

14t92498

9391106714

04.04.1978

07.03.2015

SC

NA

NA

NA

NA

Prakasam

Prakasam

Dt:18.08.2017

7L0

Ch.Venkata Narasaiah

pl

14192485

8919341138

1s.06.1982

07.03.201s

NA

NA

NA

NA

NA

Prakasam

Prakasam

lt9s6l20 Dt:18.08.2017

615

P. Rajya takshmi

F

14r92L32

8125430809

30.06.1979

28.03.2015

NA

NA

NA

NA

NA

Prakasam

Prakasam

7t2

T.K.B.Joshi

F

74192525

97047128t3

20.05.1987

28.04.20t5

Group

NA

NA

NA

NA

Prakasam

Pra kasam

NA

NA

NA

NA

Prakasam

Prakasam

(6)

L9s6lZC Dt:18.08.2017
10
tc.No.A3
tL9s5l2C Dt:18.08.2017
10

Prakasam

Rc.No.A:

386

Veligandla

Mogaluru

Final

lt9s6l2(
10
Rc.No.A3

387

Chimakurthy

K.V.Palem

Final

10
Rc.No.A3

388

Tangutur

Kandulur

Flnal

SC-

lt9s6l20 Dt:18.08.2017

II

10
Rc.No.A3

389

Santhamaguluru

Elchuru-1

Final

SC(GR

705

Sarimalla.lyothibabu

t4

14792492

99892 10613

01.10.1967

03.05.2015

7t5

Y.Duraga Prasad

M

14190606

9959455818

02.07.1983

12.05.2015

NA

NA

NA

NA

NA

Prakasam

Prakasam

)ti12.LL.2017

707

Sk Y Gariba

M

74792486

9t82277877

06.05.1976

03.07.2015

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dl:72.11.2017

708

B Yebelu

M

t4792484

9705000674

08.0s.1977

03.07.2015

NA

NA

NA

NA

179s6120 Dt:18.08.2017
10

7t3

Y.Venkateswarlu

M

14368032

9701249018

06.04.1980

28,08.2015

NA

NA

NA

NA

Prakasam

Prakasam

Prakasam

Prakasam

lL9s6l20 Dt:18.08.20 17
10

3UP.II]

Rc.No.43
390

Darsi Mandal

Kothapalli

Final

391

Pamur

Botlagudur

Final

392

Marripudi

Kellampalli

Final

393

Ballikurava

Peda Ambadipudi

Final

11956120 Dt:18.08.2017
10
No.COLP
KM.
No.COLP
Kf4-

SC GR2

Prakasam

sc-

Rc.No.A3

Group

III

Rc.No.A3

394

Santhamaguluru

Pathamaguluru

Final

7LL

B.Raadhika Krishnaven

F

L4t92574

8790727359

05.1 1.1980

16.10.2015

NA

NA

NA

NA

NA

714

D.l.Giri

M

t4t92529

9ss0864987

06.10.1995

30.11.201s

SC

NA

NA

NA

NA

7t7

S Vinod Kumar

M

14389565

9618906954

18.08.1988

28.03.2016

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt:12.11.201,

718

B.Ayyappareddy

M

14193053

986608s03s

06.0r.1978

30.01.2017

NA

NA

NA

NA

NA

Prakasam

Prakasam

ft:12.11.20U

779

Ramakrishna Poluri

M

14193477

9t602L2434

06.07.1985

07.10.2017

NA

NA

NA

NA

NA

Prakasam

Prakasam

Dt:05.07.2018

727

P.Hari Krishna

M

t4429205

8008984782

26.11.199s

13.11.2017

NA

NA

NA

NA

Prakasam

Prakasam

lL9s6l20 Dt:18.08.2017
10

Rc.No.A3
39s

Pedacherlopalli

Murugummi

Final

lt9s6l20 Dt:18.08.2017

Prakasam

10
Rc.No.A3

396

Santhanuthalapadu

l,langamur

Final

lr9s6l20 Dt:18.08.2017
10

397

lvlundlamur

Purimetla

Final

398

Ongole

Chintaygaripalem

Final

399

Ponnalur

Ravulakollu

Final

No.COLP
KMNo.COLP
KM.
Rc.A3/19

5612070

SCGr3

<!-- page 27 -->

Type

of

a
Seniority list

Seniori
Sl.No

Name of the

Mandal

Name of the
Sachivalayam

Provisi

ority
(a)
Procee

onal/ dings
Tentati Numbe
VE
f

(1)

(2)

(3)

(4)

400

Marripudi

Thangella

Final

401

Darsi Mandal

Pothakamuru

402

Donakonda

Gudipadu

403

Pamur

Pamur-1

404

Tripuranthakam

Tripuranthakam -2

405

Giddalur

Giddalur-7

406

Podili

Madalavaripalem

407

Chimakurthy

Budawada

408

Veligandla

Veligandla

409

Veligandla

410

Darsi Mandal

Pothavaram

477

Addanki

Sankavarapadu

Tentativ
e

Tentativ
e

Tentativ

Tentativ
e

Tentativ
e

Tentativ

Tentativ

Tentativ

Tentativ

4L2

Vetapalem

Pandillapalli-1

413

Inkollu

Inkollu2

4L4

Darsi Mandal

Bassirddy Palli

415

Santhamaguluru

Elchuru-2

Tenlativ
e

Tentativ
e
Tentativ
e

Tentativ
e

Tentati!
e

Tentativ
e

oSeni

ty:
Final/

o)

(s)
No.COLP

KM.

Num

(b)

ber

Name of the

Government
Servant

Gender

MIF

CFMS ID

Phone No

DOB

Date of
Joining in

DD:MM:W

this
category

Date

c

9u

(9(/)

(Jo
u)-

't=

f
(,l
.o

c

c

0.J

E
B

po

0)

3

.E
E

9o
.=o
>o
O-

!(o_
.-do
ot!
oJL)g
>>E
c=(J
.9
.9,
2C

bE

=z

()co
t
>.o o
6
ii-o!

d
a

o
I
E

PE6Eb

o

o
_6.. a.!
g
EEIP
.F
OU
:=9o

.!2-zp

.9.

E:9

9 - F,P,;

OJ

o-

cL()iFp

; g q'>fl
Q

!

o

be?
HP&

i5Ec

-c
aY a*
E sa:
iz.2

zo

'6

(le)

(20)

o.

o-

o

(1s)

(16)

(t7)

(18)

NA

NA

NA

NA

NA

NA

NA

NA

NA

Prakasam

Prakasam

17.t2.2078

NA

NA

NA

NA

NA

Prakasam

Prakasam

06.02.2000

27.06.2019

SC-III

NA

NA

NA

NA

Prakasam

Prakasam

9390772289

08.0 1.1987

16.09.2019

NA

NA

NA

NA

NA

Prakasam

Prakasam

15001907

905953,1485

15.05.1993

06,03.2020

NA

Markapuram

Prakasam

M

14999041

8t84874134

30.08.1987

07.03.2020

NA

NA

NA

NA

NA

Markapuram

Prakasam

K. Komal Kumar

M

15025055

9550456299

13.0s.1988

19.03.2020

NA

NA

NA

NA

NA

Prakasam

Prakasam

791

K.Nagaraju

M

15024082

9542127#.7

t2.o7.tq7g

14.09.2020

NA

NA

NA

NA

NA

Prakasam

Prakasam

792

G.V.Padmavathi

F

15005472

9s02422427

06.09.1984

09.11.2020

NA

NA

NA

NA

NA

Prakasa m

Prakasam

793

G.Sai Chand

M

t4t72584

8464836277

06.08.1995

03.12.2020

NA

Na

Na

Na

Na

Prakasam

Prakasam

t94

Y. Maharshi

M

14988888

6281L46827

25.04.1998

03.72.2020

NA

NA

NA

NA

PEkasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

(6)

(7)

(8)

(s)

(10)

(11)

(12)

(13)

Dt:12.11.2017

720

B Sandeep Kumar

l'1

14389708

7893450166

06. 10,1998

07.r2.2017

785

M.Sudhakara Rao

M

15044590

63820474t8

01.05,1992

17.08.2018

786

T.Sivakoteswara Rao

f,l

14959627

9346425919

04.02.1989

787

P Dinesh

t4

14496757

788

K .Ramya Krishna

F

74877980

788

A.Lakshmi Devi

F

789

V. Santhosh Kumar

790

(14)
SCGr2

Yes

Prakasam

SC(GR
OUP-

IID
SC(Gr-

722

K. Manikyam

F

14189415

9494453376

15.02.1973

12.09.202s

723

G.Nagu

t4

14881828

9885562723

28.08.1996

r0.02.2026

NA

NO

NO

NO

No

Prakasam

Prakasam

724

K.Madhusudhana Rao

M

15044590

99s9960012

16.07.1996

10.02.2026

NA

Na

Na

Na

Na

Prakasam

Prakasam

725

E.H K Chaitanya

N4

L4806414

9440726655

25.06.1998

10.02.2026

NA

NA

NA

NA

NA

Prakasam

Prdkasam

3)

<!-- page 28 -->

Type

of

I

Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the

Sachivalayam

Provisi Procee

dings
Tentati Numbe
VE
f

(2)

(3)

416

Pamur

Pamur-3

+L7

Darsi Mandal

Lankojanapalli

418

Yerragondapalem

Yerragondapalem-1

4t9

Karamchedu

Karamchedu-2

420

Pullalacheruvu

Marrivemula

Ardhaveedu

Nagulavaram

Yaddanapudi

Yanamadala

421

422.

423

.l.Pangulur

Alavalapadu

(4)
Tenbtiv
e

Tentativ
e

Tentativ
e

Tenbtiv
e

Tentativ
e

Tentativ
e

Tentativ
e

Tentativ
e

ority

(a)

onal/

(1)

oSeni

ty:
Final/

0.)

(s)

Num

(b)

ber

Name of the
Government
Servant

Gender

MIF

CFMS ID

Phone No

DOB

DD:MM:YY

Date of
Joining in

this
category

Date

Qu
0th
q) 0
(i^

f

c
E
c(u

G

E

o)
c

o,

3
o
'=

.E

c

cD.=o

AP

!l!_
U:L
.-60
o=!
-qJ (J -9

>>=
c=(J
orc
io
=z

*p - g,E;
"EB

o

d.
th

'tU

o

o .. q

o.

o0Ji;-

q

q E E*"g

U
'tr

!-(ucc

-1E
d :=.^u

E

_8

v.<

o
.o

!

o

G

z.

OJ

: B5

:i(9o:

EBE
trQ
Edo)
6

cG

aEc

'o
o-

o-

o

(6)

(7)

(8)

(e)

(10)

(11)

(L2)

(13)

(14)

(1s)

(16)

(17)

(18)

(le)

(20)

726

V Manoj Kumar

M

14844368

9440335818

24.07.t995

10.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasm

727

P,Pavan Kumar

M

t4478438

9611187824

14.06.7992

70.02.2026

NA

Na

Na

Na

Na

Prakasm

Prakasm

728

Sk.Mahaboob Basha

M

14809972

7569242945

22.07.7995

10.02.2026

NA

NA

NA

NA

NA

Markapuram

Pra kasa m

729

Sri Vignesh Parchuri

M

14842453

9059620693

20.06.2001

17.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

730

B Ravindra Naik

M

14828022

7013892328

05.02.1993

t0.02.2026

ST

NA

NA

NA

NA

737

Sk.Nayab Rasool

M

14843388

9394697209

15.05.1995

17.07.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

732

P.Rambabu

t4

148138 1 1

8500042030

10.05.1990

70.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

733

P. lyothi Rao

M

14843375

9908470484

30.07.1993

70.02.2026

ScMala

NA

NA

NA

NA

Prakasam

Prakasam

Prakasam

(Gr-lII)
424

425

+26

477

428

Tarlupadu

Chirala

Tarlupadu

(Deputation In

Tentativ
e

Manchikalapadu

Yerragondapalem

Vadampalli

Ravuru

429

Veligandla

Gannavaram

430

Ballikumva

Konidena

431

Chinnaganjam

e

Collectors Office,

Chimakurthy

Gudlur

Tentativ

Chinnaganjam-1

Tentativ
e

Tentativ
e

Tentativ
e

Tentativ
e

Tentativ
e

Tentativ
e

734

Budala Nagamani

F

14809997

90s2430606

31.07.1993

11.02.2026

NA

NA

NA

NA

NA

Kurnoll

Prakasam

735

M. Yamuna

F

74823459

89770 39967

04.06.1992

tl.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

736

G. Venkata Reddy

M

148 1 1880

7036838387

16.08.1998

L0.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

737

P.Vishnuvardhan

M

74809524

9652620495

12.06.1996

r0.02.2026

NA

NA

NA

NA

NA

Markapuram

Pmkasam

738

G.Vinod Kumar

M

14839167

9502371275

04.06.1997

tL.02.2026

NA

NA

NA

NA

scMala

Prakasam

739

Sk.Nayab Rasool

M

14820963

9014312169

19.08.1988

10.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasm

740

A.Sai Prasanna

M

14801342

9676022784

08.10.1993

10.02.2026

NA

NA

NA

NA

NA

Prdkasam

Prakasam

74L

D. Sai Vimal Kumar

M

14874947

798t875970

06.07.1996

12.02.2026

NA

NA

NA

NA

NA

Eapatla

Prakasam

<!-- page 29 -->

Type

of

a

o
(u
Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

Seni

ty:
FinaU

ority
(a)

Provisi Procee

onal/
dings
Tentati Numbe
VE
f

(1)

(2)

(3)

432

Podili

Kondayapalem

433

Maddipadu

Vellampalli

434

Vetapalem

Kothapeta-3

435

Lingasamudram

Vrkota

436

Ballikurava

Mallayaaplem

437

Santhamaguluru

Sajjapuram

438

Naguluppalapadu

Ch.Uppalapadu

439

Mundlamur

Nayudupalem

440

Ongole

Karavadidonka

441

Kothapatnam

Gamallapalem

442

Tallur

Dosakayalapadu

443

Tripuranthakam

G .Ummadivaram

444

Martur

Rajupalem

445

Santhanuthalapadu

Bodduvaripalem

446

Tripuranthakam

Dupadu

447

Singaraykonda

Kalikivaya

o.

(s)

(b)

Num
ber

Name of the

Government
Servant

Gender
M/F

CFMS ID

Phone No

DOB

DD:MM:W

Date of
Joining in

this
category

Date

=
Ou
|gvt
()o
(,c.

c

.o
o)
(o
C

o

o
E

3
o
'=

.E

E
c

9o
.=o

iP

!(E_
L=L
.-60
oE!

-b
* -E3,
g_E;
E.
o-OiFg

gEE?s

u .!2
>>=
c=(-)
Eg E E
.9
.E
E
2C
c
6

.@

b9
2z

o
z

l--^-g.>

d.

o
U

o-

zo
oE
6 .. q
-9>Y

t

i(cq
o-9d

tJ)
q)

o
(o

o
OJ

.F

OO

ti:Q

EEE

aF- c

(!

'o

z

oo-

o

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(L7)

(18)

(1e)

(20)

Prakasam

Prakasam

(7)

(8)

(e)

742

K. lohnson Raju

M

14846505

9052537228

11.10.1995

t0.02.2026

SC-II

NA

NA

NA

NA

Tentativ
e

743

B.Mahendra Reddy

M

14803020

9494975503

28.r 1.1991

t0.02.2026

NA

NA

NA

NA

NA

Tentativ
e

745

G.Somaiah

M

14869015

8297467t57

10.01.1993

11,02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

746

Syed Jakeec Begum

F

1s030162

8sss928920

rs.o3.t977

tt.02.2026

NA

40

NA

NA

NA

Prakasam

Prakasam

747

S.Sirisha

F

14868862

8328368068

14.06.1993

10,02.2026

ST

NA

NA

NA

NA

Prakasam

Prakasam

748

B.Samuel

M

14804744

779957t050

07.L2.L997

t0.02.2026

NA

NA

NA

NA

Prakasam

Prakasam

749

P.Praveen Kumar

M

t4844640

9618681412

05.10.1992

70.02.2026

SC-B

NA

NA

NA

NA

Prakasam

Prakasam

750

B.Rajasekhar Reddy

lvl

14827077

9700832889

10.08.1991

|t.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

751

Nidamanuri Sai Kumar

M

L4757083

8 12 1033309

26.08.1992

t0.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

752

Ch Vamsi Krishna
Yadav

M

148061 12

99666tt778

08.08.199s

t0.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

753

Brahma Teja

M

148131 14

89774 60355

31.01.1996

10.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

754

M .Tejeswari

F

148L7544

6300720064

08.06.1997

t0.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

755

K.Mohan Naik

M

14796594

99123 1882s

15.07.1994

10.02.2026

ST

NA

NA

NA

NA

Bapatla

Bapatla

756

M Mariya Kumar

l'4

14633515

8978198505

L4.07.7996

t0.02.2026

NA

NA

NA

NA

Prakasam

Prakasam

757

Ch.Nr Anjaneyulu

M

14805352

7989769829

14.06.1978

22.02.2026

NA

NA

NA

NA

Prakasam

Prakasam

758

I. Prasanth

M

74836t77

779983t478

08.12.1995

11.02.2026

NA

NA

NA

NA

Prakasam

Prakasam

(4)
Tentativ

Tentativ
e

Tentativ
e
Tentativ

Tentativ
e
Tentativ

Tentativ
e

Tentativ

Tentativ
e

Tentativ
e
Tentativ
e

Tentativ
e

Tentativ
e

Tentativ
e

(6)

SC(GR

3I,,P-ID

SC(Gro

up II)
SC

(t'4ata)

SC-II

Prakasam

<!-- page 30 -->

o)

Type

a

of

I

o
Seniority list

Seniori
Sl.No

Name of the
Mandal

Name of the
Sachivalayam

ty:
(a)

Provisi

Procee

dings
Tentati Numbe
ve
r

(1)
448

(2)
Karamchedu

(3)

(4)
Tentativ

Swarna-2

e

449

Ongole

Ambedkar Nagar

450

Ulavapadu

Ramayapatnam

451

Kothapatnam

Kothapatnam-Ii

452

Peddaraveedu

Thokapalli

453

Kothapatnam

K Pallepalem

454

Chirala

Burlavaripalem

455

Podili

Talamalla

456

Ongole

Nirmal Nagar

457

Kandukuru

pandellapadu

458

Cumbum

Cumbum4

459

Kanigiri

China Irlapadu

460

Chirala

Vykuntapuram

461

Peddaraveedu

Sunkesula

Tentativ
e

Tentativ
e

Tentativ
e

Tentativ
e

Tentativ
e

Tentativ
e

Tentativ

Tentativ
e

Tentativ
e

Tentativ
e

Tentativ
e

1

Tentativ
e

Tentativ
e

o-

Seni

Final/

onal/

o)

(s)

ority
Num

(b)

ber

Name of the
Government
Servant

Gender
MIF

CFMS ID

Phone No

DOB

DD:MM:YY

Date of
Joining in

this
category

c

f
Or

0 u',
(Jo
6^

o
.E
ol
o

c

E

3

po

0)

G
.U

Date

cq)

3

!

ED,= ol

o

E6l

d.

U)

EP
!6

g"3H

E
o-(u=;-

q)

>>E

E.EE;g

ts

€

5E

-L=(ucc 1J 0)
.!l
-z
o
i=-av ^o

.-60
oc!
q)ut2
c=(J
66

?

^=

9.>

=a

o.

o
|E
@

o

.E
lE

z.

.9

e

E
ia
E<o
'F 60
;it9,
o.9E
Ul:9
OJ

EEE

i5Ec
'6

o.
o.
6

(6)

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

(18)

(1e)

(20)

NA

NA

NA

NA

Prakasam

Prakasam

SC-

759

Ravikumar Telagathoti

M

14819083

8106353376

08.09.1982

70.02.2026

Group

III
760

Pothuraju Kancharla

M

r4805647

9908543418

05.01.1986

70.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

761

K.Santhi Priya

F

14831463

9951582628

11.08.1993

77.07.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

762

M Rama

F

14796386

9866s61668

30.05.1997

70.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

763

G Chinna Badulla

t4

t4872457

9848928463

16.04.1988

77.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

764

K Nireesha

F

147971A7

74t6408t61

28.06.1992

to.o2.2026

Group

NA

NA

NA

NA

Prakasam

Prakasam

SC

III
765

T. Navyavani

F

14803878

83096 s7689

08.07.1989

77.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakaem

766

P. Kinnera Reddy

F

14823388

9s02s55573

20.06.1995

70.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

767

Muntaz Gudia

F

14796684

7901559972

25.01.1999

10.o2.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

768

R.Kavitha Lakshmi

F

74872727

9000243104

22.r0.1996

71.o2.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

769

P.Leelavani

F

14803982

9493790982

28.03.1998

L0.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

770

Nagur Sharif Shaik

M

14951103

9948490344

03.11.1991

t7.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

771

Sk. Farheen

F

t4884454

7416 815 410

08.12.1997

LL.O2.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

772

G Adinarayan

M

1465331 1

9733822476

10.03.1993

70.o2.2026

NA

0.74

NA

NA

NA

Prakasam

Prakasam

<!-- page 31 -->

Type

)

of

Seniority list

Seniori

Sl.No

Name of the
Mandal

Name of the
Sachivalayam

ty:
Final/

(2)

(3)

462

ZanEumalli

Zarugumalli

463

Cumbum

Jangamguntla

464

Vetapalem

Vetapalem-1

465

Korisapadu

Medarametla-2

466

Mundlamur

Pedaullagallu

467

Ongole

Ganugapalem

468

Chirala

Epurupalem-2

469

Inkollu

Pavulu12

470

Ta ngutur

Valluru

477

Tallur

Thurakapalem

472

Naguluppalapadu

Kothakota

473

Chimakurthy

R.L.Puram

474

Tallur

Vel(Euvari Palem

o.
Seni

ority
(a)

Provisi Procee

onal/
dings
Tentati Numbe
ve
f

(1)

o
c,

(s)

Num

(b)

ber

Name of the

Government
Servant

Gender

MIF

CFMS ID

Phone No

DOB
DD:MM:YY

Date of
Joining in

this
category

Date

Ou
(,(,

(Jo
(r^

co
f

o,

o

E

o)

c

3
o

o
o

'=

.U

Pu
.=o
EP
!o_
.-do

o)

EF
>6 gt

E . B E;

E6€ !FH.;ST
I 9'a#
>>E
c=(J
OE

b9

2z

E
c

,
E

d.

u7

o

oq

G

U

'tr
.9

U
E

(l)

(o-!|

E Bd

:= (9 o:

EeP

tr:Q
EEE

.g-ze
8.
c

!

=->

o
z.

i5Ec
'o
o
o-

-^
E =a:

OJ

G

(7)

(8)

(e)

(10)

(11)

(12)

(13)

(14)

(1s)

(16)

(17)

(18)

(1e)

(20)

773

B. Krishna Chaitanya

M

14977329

7036657077

12.09.1995

11.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

774

D.Rajeswari

F

t4843791

9573926820

16.06.1994

10.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

775

E. Poojitha

F

14881484

7995673747

04.09.1997

tt.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

Tentativ
e

776

Y. Swathi

F

t4755753

9381342835

15.07.1996

t0.02.2026

SC-I

NA

NA

NA

NA

Prakasam

Prakasam

Tentativ
e

777

G.Susmitha

F

14815075

9010861240

21.08.1997

rL.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasm

778

Devarapalli Anitha

F

74867474

7396297040

2s.06.1989

),0.o2.2026

SC - III

NA

NA

NA

NA

Prakasam

Prakasam

779

B, Rajitha

F

14823393

63048 66265

02.08.1999

11.02.2026

NA

NA

NA

NA

NA

Prakasam

Pra kasam

780

D.Vishnu Priya

F

L4822224

9985527991

16.0s.1999

1L.02.2026

NA

NA

NA

NA

NA

Prakasam

Pra kasam

781

K.Durga Bhavani

F

14889964

8297t04764

13.05.1993

10.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

782

K Sridevi

F

14955983

84979 37020

10.06.1997

t9.02.2026

NA

NA

NA

NA

NA

Prakasam

Prakasam

783

U.Yeshaya

M

14868546

8464881464

14.08.1994

10.02.2026

BC.C

NA

NA

NA

NA

Prakasam

Prakasam

784

D. Mounika

F

t4802240

9133570995

t7.04.L996

r0.02.2026

(Mala)

NA

NA

NA

NA

Prakasam

Prakasam

NA

NA

NA

NA

Prakasam

Prakasam

(4)
Tentativ

Tentativ

Tentativ
e

Tentativ

Tentativ
e

Tentativ
e
Tentativ
e
Tentativ

Tentativ

Tentativ
e
Tentativ
e

(6)

Sc-

G-III
785

Manoj Kumar

M

14829910

630300062s

Vr*

rrr[aJ*")

24.02.L997

10.02.2026

NA

-ryyV
D20

*,,*rru

lict Magistrate
Prrkrui oi trict,0ngole.
