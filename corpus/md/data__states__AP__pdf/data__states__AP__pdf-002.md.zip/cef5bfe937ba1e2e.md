---
doc_id: "cef5bfe937ba1e2e"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 2
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "4d9892fa22594207"
---

<!-- page 1 -->

@
ANDHRA PRADESH STATE CIVIL SUPPLIES CORPORATION LIMITED
DISTRICT OFFICE, COLLECTORATE COMPOUND, KAKINADA.
S.ILAKKTYA, L.A.S.,
JOINT COLLECTOR & E.0. E.D.
APSCSCL, KAKINADA.
TENDER NOTICE
TRANSPORTATION OF GUNNIES FROM RAILWAY GOODS SHED/ CWC /SWC

AND OTHER GODOWNS LOCATED IN KAKINADA DISTRICT TO RICE MILLS AND
VARIOUS PLACES IN KAKINADA DISTRICT OR TO OTHER PLACES IN THE STATE

AS ENTRUSTED BY A.P STATE CIVIL SUPPLIES CORPORATION FROM TIME TO

TIME UNDER PADDY MSP OPERATIONS WITHIN AND OUTSIDE THE DISTRICT

OF KAKINADA FOR KMS 2023-24
(From 01.10.2023 to 30.09.2024)

No. CS/Al/KKD/Admn/03-Gunnies/2023-24 Dated: 30.09.2023

1. Sealed tenders are hereby invited for appointment of Transport contractor for
transportation of Gunnies from Railway Goods Shed, Rajahmundry/ ౮౫/౮ / 5౫/౮
and other Godowns located in Kakinada to Rice Mills/RBKs and various places in
the District and to other places in the State for the period from 01.10.2022 to
30.09.2023.

2. DETAILS OF TENDER DEPOSITS:

(Amount in Rupees)
Earnest Money Deposit 5,00,000
Security Deposit 10,00,000
Bank Guarantee 10,00,000

3. Each tenderer should have 06 dedicated transport vehicles of 17 MTs capacity.
Out of these, at least 3 vehicles should be of their own and the remaining 3
vehicles can be with a minimum of one year hire Agreement with the owners.

4, Tenders shall be filed in the Office of the District Civil Supplies Manager, A.P.
State Civil Supplies Corporation Ltd., Collectorate Compound, Kakinada. The
time Schedule for sale of tender forms, filing and opening of tenders is detailed
below:

5. TENDER SCHEDULE FOR GUNNIES :

Sale of Tender forms Last date for filing of Opening of Technical

Tender and Financial
on working days Tenders ‘Tender
From 05.10.2023 onwards at =
the office of DM, APSCSCL, At the offically
అ APSCSCL, Kakinada upto
Kakinada Up 5.00 P.M. on 12.00 P.M. On 17.10.2023 at 05.00 PM
16.10.2023 స క!
0౫ 17.10.2023

6. If the dates mentioned above are declared as holidays, the Tenders will be
received and opened on the next working day at the same time.

CamScanner

<!-- page 2 -->

7. Tender Schedule (not transferable) consisting of Tender Forms, Terms &
Conditions and Draft Agreement can be obtained either from the Office of the
District Manager, APSCSCL, Collectorate Compound, Kakinada on payment of
Rs.5,000/- (Rupees Five thousand Only) by way of Demand Draft drawn on any
Nationalized Bank in favor District_Civi lies Mi. er, A.P. Stat ivi
8. Minors are not eligible to participate.
9. The Joint Collector & E.O.E.D, APSCSCL, Kakinada is empowered to cancel the
tenders to extend the date of Sale & filing tenders and to modify the date of
opening tenders without any prior intimation or notice.
Sd/- S.lakkiya
//5.0.// JOINT COLLECTOR & E.O. E.D.,
APSCSCL, Kakinada.
District Civil Supple '5 Manager
exe Ye |
sos
se
a
og
ee
Rees
a
తి...
=
-_
2. So ee
po a a
CamScanner
