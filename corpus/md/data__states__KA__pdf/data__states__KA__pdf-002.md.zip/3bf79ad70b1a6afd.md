---
doc_id: "3bf79ad70b1a6afd"
source_url: "https://hfwcom.karnataka.gov.in/uploads/PHCO%20NOC%20COURT_1779457902.pdf"
ministry: "Commissionerate of Health & Family Welfare Service, Karnataka"
title: "23     5 months ago       ಮಾನ್ಯ ಕರ್ನಾಟಕ ನ್ಯಾಯಮಂಡಳಿಯ ಆದೇಶದಂತೆ ಈ ಕೆಳಕಂಡ ನೌಕರರುಗಳಿಗೆ ನಿರಾಕ್ಷೇಪಣ ಪತ್ರವನ್ನು ನೀಡುವ ಬಗ್ಗೆ."
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c276878b5b7d8bfa"
---

<!-- page 1 -->

eSỦArts T°,orda di,,

JOB:1896393/2026-27

orited-23

1. Karnataka State Diploma in Nursing Examination Board.
Oot:22-08-2025.
2. KARNATAKA
STATE
ADMINISTRATIVE
BANGALORE, DATED:16-04-2026.

26,

TRIBUNAL

AT

ROs,:8.e9.80.3.r/,o(2)/124/125/127/2025

OOT:26-08-2025.

J Ro,:Aw,oo2)/123/2025-26,

DO8:25-08-2025.

ÄOl,:QeSTTO/(8)/29/01/2025-26.

OooB:25-08-2025.

dOod:25-08-2025.

dveod:25-08-2025.

JOi,:CeTJE:AI(3)23/2025-26,

io;:e0,00(2):0ƏeSRI:258/2025-26,

deot:26-08-2025.

<!-- page 2 -->

-2

1

08-12-2006

2

04-02-2015

31-12-2016

4

15-10-2018

5

30-01-2015

6

18-02-2009

7

28-12-2016

8

13-02-2015

31-01-2015

10

26-12-2016

11

01-07-2004

12

29-12-2016

13

14

Je

Bo® doron

29-01-2015

30-11-2006

<!-- page 3 -->

98*514-3

2.

15

03-12-2018

16

09-11-2018

17

15-01-2019

wejotbJDOT).

šO,.....s.
4. AoUOgs, Josdor.
5. BeJO aj.
