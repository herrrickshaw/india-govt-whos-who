---
doc_id: "5bd9a9eedf5db377"
source_url: "https://hed.karnataka.gov.in/uploads/media_to_upload1741685326.pdf"
ministry: "Higher Education Department, Karnataka"
title: "The Rai Technology University Rules, 2019"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4f3f2538e8dfd06b"
---

<!-- page 1 -->

DEPARTMENT OF HIGHER EDUCATION, GOVERNMENT OF KARNATAKA

NOTIFICATION
No. ED 96 URC 2019, Dated: 18-12-2019
In exercise of the powers conferred by sub-section (1) of section 61 of the
Rai Technology University Act-2012 (Karnataka Act No.40 of 2013), the
Government of Karnataka hereby makes the following rules, namely:1. Title and commencement- (1) These rules may be called the Rai Technology
University Rules, 2019.
(2) They shall come into force with effect from the date of their
publication in the official Gezette.
2. Definitions.- In this Rules, unless the context otherwise requires(a) “Act” means the Rai Technology University Act, 2012 (Karnataka Act
No.40 of 2013);
(b) “Section” means section of the Act;
(c) “Council” means the Karnataka Higher Education Council;
(2) The words and expressions used these rules but not defined shall have the
same meanings as assigned to them in that Act.
3. Salary and Allowances and Conditions of Service of Officers and
employees of the University- (1) The salary and allowances payable to the
teaching faculty shall be on par with the U.G.C Pay scales.
(2) The salary and allowances of other employees shall be on par with the other
State Government Employees of equivalent rank.
(3) The method of recruitment of teaching staff shall be in accordance with the
U.G.C regulations issued from time to time in respect of non-teaching staff shall
be in accordance with merit and with recruitment policy of State Government as
the case may be.
4. Institution of New Courses in the University-(1) The University shall send
a proposal along with the approval of the Sponsoring Body and the Board of
Governors to the Council well before the commencement of the each academic
year for starting of new courses as per the course specification of U.G.C, A.I.C.T.E
and other National Accreditation Bodies as the case may be.
Provided that Sponsoring Body and the Board of Governors before approving
the proposal of institution of new courses, shall ensure requisite additional
-2

<!-- page 2 -->

-2facilities having been created and requisite staff having been appointed as per the
norms and standards of concerns Regulatory Authorities.
(2) On receipt of the application under sub-rule (1), the Council shall direct an
inspection to be made by expert committee.
Provided the expert committee constituted by the Council shall consist of
atleast one former Vice-Chancellor of State Public University.
(3) The Executive Director, the Council shall submit the application and its
transcripts and the report of the expert committee to the State Government for
taking a decision thereon.
(4) The State Government shall consider such applications in the light of
recommendation of the expert committee and after such enquiry as may appear to
it to be essential, shall permit the University to start new courses or reject the
proposal as the case may be, including the variation in the intake.
(5) Any application made under sub-rule (1) may be withdrawn by the University
at any time before a permission or rejection is made under
sub- rule (4).
5. Closure of existing Courses in the University-(1) The University if intends to
close down the existing course in view of its in capacity or financial viability or
dearth of admissions shall submit application to the State Government in writing
of not less than 3 months prior to intended closure of the course, stating the
reasons therefor;
(2) The State Government on consideration of the same shall issue directions
either to permit the closure or to reject the closure to the University.
(3) The University shall not close the courses during the currency of the academic
year and until the last batch of students in the course complete their course of
studies and annual examinations conducted by it in respect of course of study or
over.
6. Enhancement and reduction of the Courses.The provisions of rule (4) shall mutatis mutandis apply for enhancement or
reduction in intake of the courses in the University.
7. Powers of State Government to inspect and issue Directions- 1) For the
purpose of ascertaining the standards of teaching, examination and research or any
other matter relating to the University, the Government may, after consultation
-3

<!-- page 3 -->

-3with Vice-Chancellor, cause an assessment to be made by the Expert Committee
constituted by the Government consisting of 3 eminent Educationist, one of them
shall be Former Vice-Chancellor of State Public University.
(2) On receipt of the report from the Expert Committee, the Government shall
communicate its recommendations in regard to result of assessment for corrective
action and the University shall take the corrective measures as are necessary so as
to ensure the compliance of the recommendations. If the University fails to
comply with the recommendations made under sub-section(2), within a reasonable
time the Government may give such directions as it may deem fit which shall be
binding on the University.
8. Permanent Statutory Endowment Fund:- (1) The Permanent Statutory
endowment fund shall be pledged in the name of Director, Collegiate Education,
Karnataka, who shall also be the custodian for all documents and instruments
related to the permanent statutory endowment fund and its investment in a
Nationalized Bank in accordance with the provisions of the Act.
(2) In case the University or the sponsoring body contravenes any of the
provisions of the Act, Statutes, Ordinance, regulations or rules made there under, a
part or whole of the endowment fund may be forfeited by the Government but
before such Forfeiture, a show cause notice shall be served by the Government on
the sponsoring body or the University, as the case may be;
(3) the Government shall, among other things, duly consider the reply
submitted by the sponsoring body or the University.
(4) In case the reply to show cause notice issued under sub-rule (2) is not
submitted by the sponsoring body or the University within 45 days of the notice,
the government may decide the case without waiting for such reply.
(5) the forfeited amount of permanent endowment fund shall vest in the
government and it shall be used in the manner to be specified by the Government
at the time of forfeiture.
(6) All other funds called General Fund under section 49 and Development
Fund under section 50 shall be maintained in double entry Book keeping method,
and shall be kept in a nationalized or Scheduled Bank.
(7) Permanent statutory Fund, General Fund and Development Fund shall
be audited by the Chartered Accountant and annual Statement of accounts along
-4

<!-- page 4 -->

-4with Audit report and its compliance shall be annually submitted to the State
Government through the Director of Collegiate Education.
9. Suspension or Dissolution of the University-1) On receipt of the reply from
University to the Show Cause Notice referred to in proviso of sub-section (4) of
section 58 of the Act, if the Government is satisfied that there is a prima-facie case
of contravention of all or any of the provisions of the Act or the Rules, Statutes
and Ordinances made there under or of contravention of the directions issued by it
under the Act or of financial mismanagement or mal administration or
indiscipline, it shall make an order of such enquiry, as it may consider necessary.
(2) The Government shall, for the purpose any inquiry under sub-section(1)
institute a Commission of inquiry headed by retired Supreme Court or High Court
Judge to enquire into any of the allegations and to make report thereon.
(3) On receipt of the enquiry report from the officer appointed under
sub-section (2), if the Government is satisfied that the University has contravened
all or any of the provisions of this Act or the rules, statutes, or ordinances made
thereunder or has violated any of the directions issued by it under this Act or has
ceased to carry out the powers and functions by it as laid down in section 8 of this
Act, or, a situation of financial mis-management and mal-administration has
arisen in the University which threatens the academic standard of thee University,
it shall issue a preliminary order for the liquidation of the University and appoint
an administrator.
(4) The administrator appointed under sub-section (3), shall have all the powers
and be subject to all the duties of the Governing Body and the Board of
Management under the Act and shall administer the affairs of the University until
the last batch of the students of the regular courses have completed their courses
and they have been awarded degrees, diplomas or awards, as the case may be.
(5) After having corrected the mis-management or awarded the degrees, diplomas
or awards, as the case may be, to the last batches of students of the regular
courses, the administrator shall make a report to the Government.
(6) On receipt of the report under sub-section (5), the Government shall, by
notification in the official Gazette, issue a final order dissolving the University
and from the date of publication of such notification, the University shall stand
dissolved and all the assets and liabilities of the University shall vest in the
Sponsoring Body from such date.
-5

<!-- page 5 -->

-5(7) It shall be competent for the Government to take action as per the provisions
of the Act on such dissolution and run the university in the public interest and in
the interest of the students till the students are provided all facilities to complete
their courses and get their degrees or diplomas.

By Order and in the name of
Governor of Karnataka

(MAHESH R)
Under Secretary to Government
Higher Education Department (Universities-2)
