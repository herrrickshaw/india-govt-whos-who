---
doc_id: "83cdfd1efecf58a2"
source_url: "https://dpal.karnataka.gov.in/storage/pdf-files/(23%20of%201964)%20Cinemas%20(Regulation)%20(Amendment)%20Rules%202022.pdf"
ministry: "Home Department, Karnataka"
title: "The Karnataka Cinemas (Regulation) (2nd Amendment) Rules, 2022."
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7efbe4b04b24fa41"
---

<!-- page 1 -->

GOVERNMENT OF KARNATAKA
No.HD 6 CNA 2021

Karnataka Government Secretariat,
Vidhana Soudha,
Bengaluru, Dated: 17.05.2022.

NOTIFICATION
Whereas the draft of the following rules further to amend the
Karnataka Cinemas (Regulation) Rules, 2014 was published as
required by sub-section (1) of section of 19 of the Karnataka
Cinemas (Regulation) Act, 1964 (Karnataka Act 23 of 1964) in
Notification No: HD 06 CNA 2021, dated:23.02.2022 in part IV-A of
the Karnataka Gazette dated:24.02.2022 inviting objections and
suggestions from all the persons likely to be affected within thirty
days from the date of its publication in the official Gazette.
Whereas, the said Gazette was made available to the public
on 24.02.2022 .
And, Whereas objections and suggestions received in this
behalf have been considered by the State Government.
Now, therefore, in exercise of the powers conferred by sections
19 of the Karnataka Cinemas (Regulation) Act, 1964 (Karnataka Act
23 of 1964) the Government of Karnataka hereby makes the
following rules, namely:RULES
1. Title and Commencement.- (1) These rules may be called
the Karnataka Cinemas (Regulation) (Amendment) Rules, 2022,
(2) They shall come into force from the date of their
publication in the Official Gazette.
2. Amendment of Rule 2.- In the Karnataka Cinemas
(Regulation) Rules, 2014 (hereinafter referred to as the said rules) in
rule 2, for clause (21) the following shall be substituted, namely:-

<!-- page 2 -->

"(21) Multiplex Complex" means a building accommodating
housing an entertainment and cultural center including cinema
theatres, restaurant, shops, Sales, Lodge/Rooms, Bars, Museum,
etc.
Explanation:- In case of Multiplex Complex, the portion of the
permanent building used for the purpose of Cinema theatres,
auditorium including the areas for all ancillary uses such as
projector room, toilets, entrance/exit lobbies/corridors, food
kiosks/cafes/canteens, games and food-court attached to the
theatre, ticket counters shall only be considered;”
3. Amendment of Rule 25.- In rule 25 of the said rules, in
sub-rule (1) the words “of the Electrical Inspector of the district or
area” shall be Omitted.
4. Amendment of Rule 26.- In rule 26, of the said rules,(i) in sub-rule (1), in clause (h), for sub-clause (ii), the following
shall be substituted, namely:“In Multiplex Complex the vehicle parking requirement for
Cinema Theatres shall be as specified above or remaining portion of
the building as provided in the respective zoning regulations. In
such cases, vehicle parking for the theatres portion shall be
exclusively earmarked in the total parking requirement for the
whole building.
Provided that, a suitable parking arrangements shall be
earmarked for physically challenged person”.
(ii) (ii) in clause (i), in the second proviso, for the word
“Distance” the word “setback” shall be Substituted.
5. Amendment of Rule 27.- In rule 27, of the said rules, in
sub-rule (2), for the words “No Objection Certificate” the words
“Building Plan” shall be Substituted.

<!-- page 3 -->

6. Amendment of Rule 29.- In rule 29 of the said rules,(i) in sub-rule (1), for the words and figures “under rule 24” the
words and figures “under rule 30” shall be Substituted.
(ii) sub-rule (4), shall be Omitted.
(iii) sub-rule (5), shall be renumbered as sub-rule (4) and after
so renumbering the following shall be substituted, namely:“(4) The Licensing Authority shall consult the Executive
Engineer, Public Works Department of the district, and Electrical
Inspector of the district before granting permission for constructing
an additional cinema as in sub-rules (1) to (3) above”.
7. Amendment of Rule 31.- In rule 31 of the said rules,
(i) in sub-rule (1), shall be Omitted.
(ii) for sub-rule (2), the following shall be substituted, namely:“(2) On receipt of the application along with Plans as specified
in rule 30 and rule 83, the Licensing Authority shall forward the
connected records to the Executive engineer, Public Works
Department of the district. The Executive Engineer, Public Works
Department shall examine the design calculations, and if satisfied
after scrutiny that the building is constructed as per the
specifications and designs would be sound enough, he shall within
fifteen days forward his report to the Licensing Authority, attaching
a certificate that the specifications and designs are acceptable:
Provided that, in the case of Multiplex Complex, the applicant
shall obtain an approval of Plans for the Commercial portions from
the Local Authority or Town Planning Officer of the district/area.
Thereafter, submit, plans for the Cinema Theatre floors before the
Licensing Authority for approval under cinema regulations”.
8. Amendment of Rule 34.- In rule 34 of the said rules, in
sub-rule (2), in clause (v), after the words "the theatre portion" the

<!-- page 4 -->

words and figures "if the entire floors height exceed above 15
meters” shall be Inserted.
9. Amendment of Rule 37.- In rule 37 of the said rules, in
sub-rule (1), after the existing proviso, the following new proviso
shall be inserted, namely:“Provided further that if the Cinema theatres / multiplex is
shut-down for continuous period of seven days for any of the
following reasons like Force Majeure / act of god/ on or shutdown
due to government order/ strike and bandh, state wide or nationwide and lockdown, etc. until the business resumes after such
situations, for that period and for such reasons the license period
will be extended”
10. Amendment of Rule 39.- In rule 39 of the said rules, in
sub-rule (1), for the words, figures and brackets "sub-rule (1) and
(2) of rule 31” the words, figures and brackets “sub-rule (2) of rule
31” shall be substituted.
11. Amendment of Rule 41.- In rule 41 of the said rules, for
the word, figures and letters "before 8.00 A.M." the word, figures
and letters "before 6.30 A.M." and for the word, figures and letters
"after 10.00 P.M." the word, figures and letters “after 10.30 P.M”
shall be Substituted.
12. Amendment of Rule 48.- In rule 48 of the said rules, in
sub-rule (10),- in clause (i), in the proviso, after the words “Craft
Course” the words “Computer Course” shall be inserted.
(i) after the words “the cinema operator permit” the words
“Such candidate shall be got endorsed in favour of the theatre as
Digital Projector Operator” shall be inserted.
(ii) clause (iii), shall be omitted.

<!-- page 5 -->

13. Amendment of Rule 83.- In rule 83 of the said rules, in
the proviso, after the words “cafes/canteens” the words “ games and
food court” shall be substituted.
14. Amendment of Rule 87.- For rule 87 of the said rules,
the following shall be substituted, namely:“87. Fees for re-grant of license- For regrant of every license,
the same rate of fee as specified in Government Order No: HD 32
CNA 2017 dated:19-04-2021 shall be charged.”

By order and in the name of the
Governor of Karnataka
( B.S. Nagarathnamma)
Deputy Secretary to Government
Home Department
(Crimes, Prisons & Cinema)
