---
doc_id: "6b7b543ed0afc3ca"
source_url: "https://mybmtc.karnataka.gov.in/storage/pdf-files/BMTC%20Paper%20Notifications-2.pdf"
ministry: "Bangalore Metropolitan Transport Corporation (BMTC), Karnataka"
title: "e-Auction notice for sale of scrapped materials -  16/07/2022  (PDF, 87.65 KB)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cd938f4056af08fc"
---

<!-- page 1 -->

“e-mail:cosp@mybmtc.com”
Website: www.bmtc.in

BENGALURU METROPOLITAN TRANSPORT CORPORATION
CENTRAL OFFICES: PURCHASE DEPARTMENT: SHANTHINAGAR: BANGALORE– 560 027

No. BMTC/COSP/STR/SSD/

/ 2022-23

Date:

-07-2022

“e”-Auction Notice
Scrap Materials available at BMTC will be sold through e-Auction to be conducted
by M/s. M.S.T.C. (A Govt. of India undertaking).
The e-Auction schedule is as under:1) Scrapped Materials Date of e-Auction : 27.07.2022
The interested bidders may log onto www.mstcecommerce.com for further details
and registration. They may also contact M/s. M.S.T.C Ltd., at below mentioned
address for needful clarification.
Address:M/.s M.S.T.C. LTD.,
No.19/5, 19/6, 3rd Floor,
Kareem Tower, Cunning Ham Road,
Bangalore- 560 052.
Contact phone Nos: 080- 22260054, 22266417, 22287356
FAX No. 080- 22256365
BMTC Contact phone Nos: + 91 7760991153 / 7760991157

CONTROLLER OF STORES & PURCHASES
