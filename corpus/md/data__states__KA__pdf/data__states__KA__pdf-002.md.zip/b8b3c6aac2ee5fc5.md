---
doc_id: "b8b3c6aac2ee5fc5"
source_url: "https://vtu.ac.in/wp-content/uploads/2026/09/Tender-for-Procurement-of-Sports-kit-bag-and-water-bottles-to-Sports-section-of-VTU-Belagavi.pdf"
ministry: "Visveswaraiah Technological University, Belagaiv, Karnataka"
title: ""
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "13335333c1933c0c"
---

<!-- page 1 -->

«±ÉéÃ±ÀégÀAiÀiå

vÁAwæPÀ

«±Àé«zÁå®AiÀÄ

(“« n AiÀÄÄ C¢ü¤AiÀÄªÀÄ 1994” gÀ CrAiÀÄ°è PÀ£ÁðlPÀ ¸ÀPÁðgÀ¢AzÀ ¸ÁÜ¦vÀªÁzÀ gÁdå «±Àé«zÁå®AiÀÄ)

“eÁÕ£À ¸ÀAUÀªÀÄ”, ¨É¼ÀUÁ«-590 018, PÀ£ÁðlPÀ gÁdå, ¨sÁgÀvÀ

VISVESVARAYA TECHNOLOGICAL UNIVERSITY
(State University of Government of Karnataka Established as per the VTU Act, 1994)

“Jnana Sangama”, Belagavi -590 018, Karnataka State, India

Registrar

Ph. No.0831-2498100 Fax No
Ref: VTU/BGM/SAP/CW-6/T-762/2026-27/2825

(0831)2405467 Website: www.vtu.ac.in
Date: 1-9-2026

TENDER NOTIFICATION
E-Tenders (two cover systems) are invited by the Registrar, VTU, Belagavi, through E- Procurement
web portal of Govt. of Karnataka from Competent Firms for the following works, subject to the Terms
and Conditions mentioned below:
1

Name of Work

2
3

Approximate Value of Work
Earnest Money Deposit (EMD)
Tender Documents Available for
download
Last date of receipt of Tenders
through E-portal
Opening of Tenders
Availability of Tender
Documents

4
5
6
7

Tender for Procurement of Sports kit bag and water
bottles to Sports section of VTU, Belagavi
₹ 11,28,600/₹ 28,250/1-9-2026 to 16-9-2026 up to 2.30 p.m.
16-9-2026

at 2.30 p.m.

17-9-2026 at 4.00 p.m.
http://www.kppp.karnataka.gov.in

Terms and Conditions:
1) Eligibility Criteria:
A. Statutory Requirements:
1. The Tenderer should furnish GST Registration Certificate.
2. The Tenderer should have registered with the Municipal of Corporation/Registration of Societies/
Companies/Director of industries and principal place of business of the company or firm or
partnership, as the case may be.
3. PAN Card Photocopy
4. IT returns for the past 3 years (Assessment year – 2023-24, 2024-25 &2025-26) and GST / VAT
returns for the financial year 2022-23, 2023-24 & 2024-25
B) Technical requirements:
a) If tenderer is quoting as an distributor / retail seller with at least 3 years of experience / expertise in
the successful execution of similar works tendered and the cost of such any one work should not be
less than 50% of estimated amount in a single tender in any State Central Governments or Quasi
Government Department or Undertaking / Universities / Colleges.
b) As proof, the bidders should upload the purchase orders and the corresponding work
completion certificate & Satisfactory Letter for work executed in the previous three financial years
c) Further, conditions and technical specifications incorporated in tender document are binding on
all the bidders.

-1-

<!-- page 2 -->

C) Financial / Commercial Requirements:
a) A turn-over of not less than 80% of estimated cost for at least 3 years, in any of last 5 financial
years. As proof, Profit & Loss Account Statement, Balance Sheets and audited reports certified by
CA for financial year should be uploaded in the e-procurement portal of GoK.
1)

The Bidders should obtain/download the tender document as stated above, through E procurement
platform of Govt. of Karnataka, http://www.kppp.karnataka.gov.in, on payment of requisite tender fees
as prescribed by E-governance. For further any information, contact undersigned during office hours of
working days.
The Registrar
Visvesvaraya Technological University
“Jnana Sangama”,
Belagavi – 590 018.

3) EMD is to be paid online during submission of tender documents.
4) If the tender is cancelled due to unforeseen reasons, the cost of the tender form will not be
refunded.
5) The Bidders should obtain/download the tender document as stated above, through E-procurement
platform of Govt. of Karnataka, http://www.kppp.karnataka.gov.in.
6) The Registrar, VTU, Belagavi reserves the right to accept / reject any or all the tenders without
assigning any reasons, whatsoever.
SD/REGISTRAR

Copy to:
1. The Finance Officer, VTU for information.
2. The Secretary to VC, VTU for information.
4. The Regional Director, Regional Offices at Bengaluru to display the tender notification in
their notice boards.
5. The Stores and Purchase Officer, VTU for information & necessary action.
6. The Director of Physical Education, Sports Section, VTU, Belagavi for information
6. The Private Secretary to the Registrar, VTU for information.
7. The Special Officer, CNC, VTU for information to publish the notification in the Website.
8. All Notice Boards.

-2-

<!-- page 3 -->
