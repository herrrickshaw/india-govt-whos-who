---
doc_id: "4dbac2b1cb0a3c49"
source_url: "https://emapan.karnataka.gov.in/Pages/Images/PDF/Circular1.pdf"
ministry: "e-Mapan, Legal Metrology Department, Karnataka"
title: "Inspection Circular 2"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d0ffb37b500461f3"
---

<!-- page 1 -->

Government of Karnataka
Department of Legal Metrology

Office of the Controller of
Legal Metrology,
No.l, Ali Askar Road, P.B.
No.l75,
Bengaluru, Dated: 1810212019

No. CLM/ACT/CR-021 18-19

CIRCULAR
This is to inform ihat, aU Legal Metrology Officers, who receive online application based

on computerised or random allocation, for the issue and Renewal of new licences of
Manufacturers/ Dealers/ Repairers of weight and measure and online application for,fhe
issue of Packing Registration, shall inspect the premises of the applicant ahd such !i"
inspection shall be limited to the checklist available in the E-Mapan software (Except in
case of complaint-based inspection).

In the instance of complaints raised on an establishment or if there are any
older/repeated complaints on an establishment, then those establishments will be
considered are at High Risk and the inspections will be carried out randomly on those

High Risk Establishments.

OGY

TO'

All the Deputy Controllers/Assistant Controllers/Inspectors
