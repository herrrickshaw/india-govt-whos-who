---
doc_id: "afaa04eafbbc1735"
source_url: "https://rera.karnataka.gov.in/resources/circulars/circular7.pdf"
ministry: "Karnataka Real Estate Regulatory Authority"
title: "The Fees / Charges for various services Rendered by the Authority"
date: ""
pages: 2
method: "tesseract:kan+eng"
script: "LATIN"
needs_ocr: false
sha1: "e7795f3e9863c6f8"
---

<!-- page 1 -->

® Real Estate Regulatory Authority, Karnataka ಗ
Cy No. 1/14, Ground Floor, Silver Jubli Block, Unity Building, C.8.1, Compound, 3° Cross, ಜ್ಞ
ae Mission Road, Bengaluru-560027 EY
No: RERA/ADM/CR- 119 /2019-20 Date: 13/12/2019
CIRCULAR
Sub: The fees / charges for various services rendered by the Authority.
retin
Whereas, under Section 34(e) of the Real Estate (Regulation and Development) Act,
2016 ("said Act") the Karnataka Real Estate Regulatory Authority is vested with the
power to fix the standard fees to be levied on the allottees or the promoter or the real
estate agent, as the case may be for various services carried out by the Authority,
pertaining to operationalise a web based online system for, in www.rera.karnataka.gov.in.

Whereas, under Section 37 of the Real Estate (Regulation and Development) Act,

2016 ("said Act") the Karnataka Real Estate Regulatory Authority is vested with the
power to issue directions from time to time to the promoters, allottees or real estate
agents' as it considers necessary from time to time.

Whereas, in order to provide services on transactional basis for updating registration
of project, technical clearance and permission etc., rendered by the Authority and to state
that it has been decided to levy the fees, which shall be over and above the fees of the
Authority as prescribed in the Rules, which also includes updating website, database
management and maintenance of website etc., But bank charges and taxes shall be charged
extra on actual basis to be paid by the user.

The scale of this fee to be levied on the promoters will be:
registration of project.

<!-- page 2 -->

oo Real Estate Regulatory Authority, Karnataka ಗಡಾ
(ಕ್ರ) No. 1/14, Ground Floor, Silver Jubli Block, Unity Building, C.S.1. Compound, 3" Cross, (:( ¢ |
ee Mission Road, Bengaluru-560027 IBY 4
tas SS
a ಐಎಎ ಎಎ ಎ ಲ್ಲ. ಬ್ರುವ ಬರನ

Charges for inspection of documents and certified copies of the documents shall be
applicable under RTI Act and Rules there under as amended from time to time.

It may please also be noted that the levy of above prescribed fees will be effective _
commencing from this day irrespective of the date of submitting of application and
approval thereof, till further revision.

(By the approval of Hon’ble Chairperson) ದ 1
{ 4 Ss Cunae |
Secretar’
Karnataka Real Estate Regulatory Authority
ug ರಾಗ /ಾಓು ಕ) ರ): ರ ಕಗ
