---
doc_id: "d17f7888dfdfdf7c"
source_url: "https://khb.karnataka.gov.in/uploads/CORRIGENDUM%20CA_1780920980.pdf"
ministry: "Karnataka Housing Board, Karnataka"
title: "48       ತಿದ್ದುಪಡಿ ಪ್ರಕಟಣೆ ಕರ್ನಾಟಕ ಗೃಹ ಮಂಡಳಿಯ ವಿವಿಧ ಬಡಾವಣೆಗಳಲ್ಲಿ ಲಭ್ಯವಿರುವ ನಾಗರೀಕ ಸೌಲಭ್ಯದ (ಸಿ .ಎ ) ನಿವೇಶನಗಳಿಗೆ ಅರ್ಹ ಸಂಸ್ಥೆಗಳಿಂದ ಆನ್ಲೈನ್ ಮೂಲಕ ಅರ್ಜಿಗಳನ್ನು ಆಹ್ವಾನಿಸಿದೆ ."
date: ""
pages: 2
method: "tesseract:kan+eng"
script: "KANNADA"
needs_ocr: false
sha1: "ae5449f68dab6f40"
---

<!-- page 1 -->

—
a a
ಗೃಹಮಂ೦ಹಳಿ
ಕರ್ನಾಟಕ ಗೃಹ ಮ೦ಡಳಿ ಹಾಡಾಸಾಸಾರಾ
ಸಂಖ್ಯೆ; ಕಗೃಮ೦,ಕಾ/ಹ೦ಚಿಕೆ-06/ಸಿಎ/ಪ.ಪ್ರ/2026-27 ದಿನಾ೦ಕ: 05-06-2026
ತಿದ್ದುಪಡಿ ಪ್ರಕಟಣೆ. |
1. ಕರ್ನಾಟಕ ಗೃಹ ಮಂಡಳಿಯು ವಿವಿಧ ಬಡಾವಣೆಗಳಲ್ಲಿ ಲಭ್ಯವಿರುವ 373 ನಾಗರೀಕ
ಸೌಲಭ್ಯದ («ಸಿ.ಎ ನಿವೇಶನಗಳನ್ನು ಹಂಚಿಕೆ ಮಾಡಲು ಅರ್ಜಿಗಳನ್ನು ಆಹ್ವಾನಿಸಿ ದಿನಾ೦ಕ
26-05-2026 ರಂದು ಸಾರ್ವಜನಿಕ ಪ್ರಕಟಣೆಯನ್ನು ಹೊರಡಿಸಲಾಗಿತ್ತು. ಸದರಿ ಪ್ರಕಟಣೆಯಲ್ಲಿ ಈ
ಕೆಳಗಿನಂತೆ ಕೋಷ್ಟಕ (1) ರಲ್ಲಿ ತಿದ್ದುಪಡಿಗಳನ್ನು ಮಾಡಲಾಗಿದೆ.
51. ೫೦. ೩5 CA Médsurement Gi Board Rate
per District Place Site ಸ ಗ (per
notification No. a ) Sq.Mtrs
Mullusoge,
Mullusoge,
Mullusoge, |
Kodagu Kushalnagar 31 1372.50 26910
i Mullusoge,
= ನ Chandapura,
| 250. Kalaburagi Chincholli 2
ನ Chincholli Sy.No. |
Ralaburags 155/5-6 : ಹಂಚಿಕೆಯಿಂದ
952, | Kilabinagi | CmnSbOleSyNoe | 5.4 ತಡೆಹಿಡಿಯಲಾಗಿದೆ.
155/5-6 |
Gadag R.Sy.No.
| ತೂತ 815.00
30000
ಲ Chikmagalur 5th
ರಾಶ ಸತರ wa
ಷೆ Chikmagalur Sth
: Chikmagalur 5th
ನ Chikmagalur 5th |
296. Kadur ಜ್ರ 3562.65 15875
Chikmagalur] Kaur 13875
1801.50 15875
Page 1 of 2 .

<!-- page 2 -->

—_—
2. ಈ ಕೆಳಕಂಡ ನಿವೇಶನವನ್ನು ಹೊಸದಾಗಿ ಸೇರ್ಪಡೆ ಮಾಡಲಾಗಿದ್ದು, ಆಸಕ್ತರು ಈ
ವಿವೇಶನದ ಹ೦ಚಿಕೆ ಕೋರಿ ಅರ್ಜಿ ಸಲ್ಲಿಸಹುದಾಗಿದೆ.
Ce Measurement (in Board Rate:
Sl. No District Site Sq.Mtr: (per
No. anaes) Sq.Mtrs
3. ವಿಷೇಶ ಸೂಚನೆ: ಪ್ರಕಟಣೆಯಲ್ಲಿನ ನಿವೇಶನಗಳ ಪೂರ್ಣ ಅಳತೆಯ ಮತ್ತು
ವಿಸ್ತೀರ್ಣದ ವಿವರಗಳನ್ನು ಮಂ೦ಡಳಿಯ ವೆಬ್‌ಸೈಟ್‌ 777೫.18॥.17780313.801.13 ನಲ್ಲಿ
ಮಾಹಿತಿ ಪಡೆದುಕೊಳ್ಳುವುದು. ಉಳಿದಂತೆ ದಿನಾ೦ಕ: 26-05-2026 ರ ಪ್ರಕಟಣೆಯಲ್ಲಿನ ಷರತ್ತು
ಮತ್ತು ನಿಬಂಧನೆಗಳಲ್ಲಿ ಯಾವುದೇ ಬದಲಾವಣೆಗಳು ಇರುವುದಿಲ್ಲ. ಕ್ಲ
ದಿನಾಂಕ: 08-06-2026 a.
ಕರ್ನಾಟಕ Ny Dow",
Wy ಬೆಂಗಳೂರು
Page 2 of 2
