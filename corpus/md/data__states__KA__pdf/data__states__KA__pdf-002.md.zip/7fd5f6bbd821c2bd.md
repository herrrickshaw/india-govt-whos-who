---
doc_id: "7fd5f6bbd821c2bd"
source_url: "https://kptcl.karnataka.gov.in/storage/pdf-files/RA/Papernotification.pdf"
ministry: "Karnataka Power Transmission Corporation Limited, Karnataka"
title: "32        -->     ಆರ್ಥಿಕ ವರ್ಷ 2022-23 ರ ವಾರ್ಷಿಕ ಕಾರ್ಯ ಸಾಧನೆ ಪರಿಶೀಲನೆ (ಎ.ಪಿ.ಆರ್) ಅಧಿಸೂಚನೆ."
date: ""
pages: 2
method: "tesseract:kan+eng"
script: "KANNADA"
needs_ocr: false
sha1: "e0659f6756f8f8ff"
---

<!-- page 1 -->

ಗೌರವಾನ್ದಿತ ಕರ್ನಾಟಕ ವಿದ್ಯುಚ್ಛಕ್ತಿ ನಿಯಂತ್ರಣ ಆಯೋಗ
೫16ಸಿ-1, ಮಿಲ್ಲರ್‌ ಟ್ಯಾಂಕ್‌ ಬೆಡ್‌ ಏರಿಯ,
ವಸಂತನಗರ, ಬೆಂಗಳೂರು-560052 ಇವರ ಮುಂದೆ
ಕೆಳಕಂಡ ವಿಷಯದಲ್ಲಿ, ವಿದ್ಯುತ್‌ ಕಾಯಿದೆ 2003 ರ ಪ್ರಕರಣ 62 ಮತ್ತು 64ರ ಜೊತೆಗೆ ಓದಿಕೊಳ್ಳಲಾದ ಕರ್ನಾಟಕ
ವಿದ್ಯುಚ್ಛಕ್ತಿ ನಿಯಂತ್ರಣ ಆಯೋಗ (ದರ) ನಿಯಮಾವಳಿಗಳು 2000ರ ಮತ್ತು ಕರ್ನಾಟಕ ವಿದ್ಯುಚ್ಛಕ್ತಿ ನಿಯಂತ್ರಣ
ಆಯೋಗ (ಪ್ರಸರಣ ದರ ನಿಗದಿಪಡಿಸುವ ನಿಬಂಧನೆ ಹಾಗೂ ಷರತ್ತುಗಳು) ನಿಯಮಾವಳಿಗಳು 2006 ಮತ್ತು
ತಿದ್ದುಪಡಿಗಳ ಪ್ರಕಾರ ಆರ್ಥಿಕ ವರ್ಷ 2022-23ರ ವಾರ್ಷಿಕ ಕಾರ್ಯಸಾಧನೆ ಪರಿಶೀಲನೆಯ(ಎ.ಪಿ.ಆರ್‌)
ಅನುಮೋದನೆಗಾಗಿ ನಿಯಂತ್ರಣ ಆಯೋಗದ ಮುಂದೆ ಸಲ್ಲಿಸಿರುವ ಅರ್ಜಿ ಬಗ್ಗೆ.
ಕರ್ನಾಟಕ ವಿದ್ಯುತ್‌ ಪ್ರಸರಣ ನಿಗಮ ನಿಯಮಿತ,
ಕಾವೇರಿ ಭವನ, ಬೆಂಗಳೂರು-560009, ... ಅರ್ಜಿದಾರರು
ಅಧಿಸೂಚನೆ
ಆರ್ಥಿಕ ವರ್ಷ 2022-23ರ ವಾರ್ಷಿಕ ಕಾರ್ಯಸಾಧನೆ ಪರಿಶೀಲನೆಯ(ಎ.ಪಿ.ಆರ್‌) ಅಧಿಸೂಚನೆ.
1.0 ಕರ್ನಾಟಕ ವಿದ್ಯುಚ್ಛಕ್ತಿ ನಿಯಂತ್ರಣ ಆಯೋಗ (ಪ್ರಸರಣ ದರ ನಿಗದಿಪಡಿಸುವ ನಿಬಂಧನೆ ಹಾಗೂ ಷರತ್ತುಗಳು)
ನಿಯಮಾವಳಿಗಳು 2006ರ ಮತ್ತು ಕಾಲಕಾಲಕ್ಕೆ ಆದ ಅದರ ತಿದ್ದುಪಡಿಗಳ ಪ್ರಕಾರ, ಕವಿಪ್ರನಿನಿಯ ಆರ್ಥಿಕ
ವರ್ಷ 2022-23ರ ವಾರ್ಷಿಕ ಕಾರ್ಯಸಾಧನೆ ಪರಿಶೀಲನೆ ಹಾಗೂ ತತ್ಸಂಬಂಧಿ ವಾರ್ಷಿಕ ಪ್ರಸರಣ
ದರದ ಪರಿಷ್ಕರಣೆಯ ಅನುಮೋದನೆಗಾಗಿ ಪ್ರಸ್ತಾವನೆ ಸಲ್ಲಿಸಿರುತ್ತದೆ. ಕವಿಪ್ರನಿನಿಯ ಅರ್ಜಿಯು ಗೌರವಾನ್ವಿತ
ಆಯೋಗದ ಪರಿಗಣನೆಯಲ್ಲಿರುತ್ತದೆ.
26 ಆರ್ಥಿಕ ವರ್ಷ 2022-23ರ ವಾರ್ಷಿಕ ಕಾರ್ಯಸಾಧನೆ ಪರಿಶೀಲನೆ ಅರ್ಜಿಯಲ್ಲಿ, ಕವಿಪ್ರನಿನಿಯ ಪರಿಷ್ಕೃತ
ವಾರ್ಷಿಕ ಅದಾಯದ ಅವಶ್ಯಕತೆ ರೂ. 5146.18 ಕೋಟ ಕೋರಿರುತ್ತದೆ. ಆದಾಯದ ಕೊರತೆಯು
ರೂ.1791.05 ಕೋಟಗಳಾಗಿರುತ್ತದೆ. ಈ ಕೊರತೆಯನ್ನು ಆರ್ಥಿಕ ವರ್ಷ 2024-25 ರ ಅವಧಿಯಲ್ಲಿ
ವಸೂಲಾತಿ ಮಾಡಲು ಅನುಮೋದನೆ ನೀಡಬೇಕಾಗಿ ಕೋರಲಾಗಿದೆ.
3.0 ವಿದ್ಯುಚ್ಛಕ್ತಿ ಕಾಯ್ದೆ 2003ರ ನಿಬಂಧನೆಗಳಿಗೆ ಅನುಸಾರವಾಗಿ ಕರ್ನಾಟಕ ವಿದ್ಯುಚ್ಛಕ್ತಿ ನಿಯಂತ್ರಣ ಆಯೋಗ
(ದರ) ನಿಯಮಾವಳಿಗಳು 2000ರ ಮತ್ತು ಕರ್ನಾಟಕ ವಿದ್ಯುಚ್ಛಕ್ತಿ ನಿಯಂತ್ರಣ ಆಯೋಗ (ಪ್ರಸರಣ ದರ
ನಿಗದಿಪಡಿಸುವ ನಿಬಂಧನೆ ಹಾಗೂ ಷರತ್ತುಗಳು) ನಿಯಮಾವಳಿಗಳು 2006 ರ ಮತ್ತು ಕಾಲಕಾಲಕ್ಕೆ ಆದ ಅದರ
ತಿದ್ದುಪಡಿಗಳ ಪ್ರಕಾರ, ಮೇಲಿನ ಅರ್ಜಿಗೆ ತಮ್ಮ ಆಕ್ಷೇಪಣೆಗಳನ್ನು ಸಲ್ಲಿಸಲು ಆಸಕ್ತಿ ಹೊಂದಿರುವ ವ್ಯಕ್ತಿಗಳು
ತಮ್ಮ ಆಕ್ಷೇಪಣೆಗಳನ್ನು ತಾವು ಆಧರಿಸುವ ದಾಖಲೆಗಳ ಆರು ಸೆಟ್‌ಗಳೊಂದಿಗೆ ಪ್ರಮಾಣ ಪತ್ರದ (ಅಫಿಡವಿಟ್‌)
ಜೊತೆಗೆ ಈ ಪ್ರಕಟಣೆ ಪ್ರಥಮವಾಗಿ ಪ್ರಕಟವಾದ ದಿನಾಂಕದಿಂದ ಮೂವತ್ತು ದಿನಗಳ ಒಳಗಾಗಿ
ಸ್ವೀಕರಣಾಧಿಕಾರಿ, ಕರ್ನಾಟಕ ವಿದ್ಯುಚ್ಛಕ್ತಿ ನಿಯಂತ್ರಣ ಆಯೋಗ, 116ಸ-1, ಮಿಲ್ಬರ್‌ ಟ್ಯಾಂಕ್‌ ಬೆಡ್‌
ಏರಿಯ, ವಸಂತನಗರ, ಬೆಂಗಳೂರು-560052 ಆವರಿಗೆ ಸಲ್ಲಿಸಬಹುದು.
4.0 ಆಸಕ್ತಿಯುಳ್ಳವರು ಕವಿಪ್ರನಿನಿಯ ಎಪಿಆರ್‌ ಅರ್ಜಿಯ ಪ್ರತಿಗಳನ್ನು ಪರಾಮರ್ಶಿಸಲು ಅಥವಾ ಖರೀದಿಸಲು
ಇಚ್ಛಿಸಿದಲ್ಲಿ ಈ ಕೆಳಗೆ ತಿಳಿಸಿದ ಕಚೇರಿಗಳಲ್ಲಿ ಲಭ್ಯವಿರುತ್ತದೆ.
1. ಎಲ್ಲಾ ಮುಖ್ಯ ಇಂಜಿನಿಯರ್‌ (ವಿದ್ಯುಚ್ಛಕ್ತಿ, ಪ್ರಪರಣ ವಲಯ, ಕವಿಪ್ರನಿನಿ, ಬೆ೦ಗಳೂರು, ತುಮಕೂರು,
ಹಾಸನ, ಮೈಸೂರು, ಬಾಗಲಕೋಟೆ ಮತ್ತು ಕಲಬುರಗಿ.
2. ಲೆಕ್ಕಾಧಿಕಾರಿ (ಸಾರ್ವಜನಿಕ ಸಂಪರ್ಕ), ನಿಗಮ ಕಾರ್ಯಾಲಯ, ಕವಿಪ್ರನಿನಿ, ನೆಲಮಹಡಿ, ಕಾವೇರಿ
ಭವನ, ಬೆಂಗಳೂರು.
3. ವಿದ್ಯುತ್‌ ಸರಬರಾಜು ಕಂಪನಿಗಳ ಕಂಪನಿ ಕಾರ್ಯಾಲಯಗಳು, ಬೆಂಗಳೂರು, ಮಂಗಳೂರು, ಮೈಸೂರು,
ಹುಬ್ಬಳ್ಳಿ ಮತ್ತು ಕಲಬುರಗಿ,
5.0 ಎಪಿಆರ್‌ ಪ್ರತಿಗಳನ್ನು ಕೊಳ್ಳಲು ಇಚ್ಛಿಸುವವರು ಎಪಿಆರ್‌ ನ ಕನ್ನಡ ಮತ್ತು ಆಂಗ್ಲ ಭಾಷೆಯ ಪ್ರಶಿ ಪುಸ್ತಕಕ್ಕೆ
ರೂ. 114/- ರಂತೆ ನಗದು / ಡಿಡಿ ಮೂಲಕ ಪಾವತಿಸಿ ಪೂರ್ಣ ಪ್ರತಿಯನ್ನು ಅಥವಾ ಪ್ರತಿ ಪುಟಕ್ಕೆ
ರೂ.1/- ರಂತೆ ಜೆರಾಕ್ಸ್‌ ವೆಚ್ಚಗಳನ್ನು ಪಾವತಿ ಮಾಡಿ ಪುಸ್ತಕಗಳ ಅಪೇಕ್ಷಿತ ಭಾಗಗಳ ಪತಿಗಳನ್ನು ಪ್ರಥಮ |
ಪ್ರಕಟಣೆಯ ದಿನಾಂಕದ ಹತ್ತು ಕೆಲಸದ ದಿನಗಳೊಳಗಾಗಿ ಪಡೆಯಲು ಅವಕಾಶವಿರುತ್ತದೆ. ಈ ದಾಖಲೆಗಳು |
BOEAA SarAys’: https://kptel.karnataka.gov.inad ze ಲಭ್ಯವಿರುತ್ತದೆ. |
6.0 ಆಕ್ಷೇಪಣೆಗಳನ್ನು ಕರ್ನಾಟಕ ವಿದ್ಯುಚ್ಛಕ್ತಿ ನಿಯಂತ್ರಣ ಆಯೋಗಕ್ಕೆ ಮಾತ್ರ ಸಲ್ಲಿಸಬೇಕು. ಆದರೆ ಕವಿನಿ |
ಆಯೋಗದ ನಿರ್ದೇಶನದಂತೆ, ಆಕ್ಷೇಪಣೆ ಸಲ್ಲಿಕೆ ಮತ್ತು ಆದಕ್ಕೆ ಪ್ರತ್ಯುತ್ತರ ಸಲ್ಲಿಸುವ ಪ್ರಿಯೆಯನ್ನು
ತ್ವರಿತಗೊಳಿಸಲು, ಆಕ್ಷೇಪಣೆದಾರರು ಏಕಕಾಲದಲ್ಲಿ ತಮ್ಮ ಆಕ್ಷೇಪಣೆಯ ಪ್ರತಿಯನ್ನು ನೇರವಾಗಿ ವೃವಸ್ಥಾಪಕ
ನಿರ್ದೇಶಕರು, ನಿಗಮ ಕಾರ್ಯಾಲಯ, ಕವಿಪ್ರನಿನಿ, ಕಾವೇರಿ ಭವನ, ಬೆಂಗಳೂರು-560009 ಇವರಿಗೂ
ಕಳುಹಿಸಲು ಕೋರಲಾಗಿದೆ. ಸಾರ್ವಜನಿಕ ಆಕ್ಷೇಪಣೆಗಳನ್ನು ಮೊದಲ ಪ್ರಕಟಣೆಯನ್ನು ಹೊರಡಿಸಿದ |
ದಿನಾ೦ಕದಿ೦ದ 30 ದಿನಗಳೊಳಗೆ ಸ್ವೀಕರಿಸಲಾಗುವುದು. |
ಕರ್ನಾಟಕ ಎದ್ಳುತ್‌ ಪ್ರಸರಣ ನಿಗಮ ನಿಯಮಿತದ ಪರವಾಗಿ
ಸಹಿ/-
ವ್ಯವಸ್ಥಾಪಕ ನಿರ್ದೇಶಕರು
ಕವಿಪ್ರನಿನಿ, ಕಾವೇರಿ ಭವನ, ಬೆಂಗಳೂರು-560 009.
Size: 12x 24cms. Udayavani - Karnataka |
Date of Release: 05.01.2024 & 06.01.2024 Consecutively |
Prajavani - Karnataka i
Date of Release: 05.01.2024 & 06.01.2024 Consecutively |
Layout prepared and submitted for approval by |
Renaissance Advertising |

<!-- page 2 -->

BEFORE THE HON'BLE KARNATAKA ELECTRICITY REGULATORY COMMISSION
#16C-1, MILLER TANK BED AREA,
VASANTHANAGAR, BENGALURU- 560 052.
IN THE MATTER OF:
Application under Section 62 and 64 of Electricity Act 2003 read with KERC (Tariff) Regulations
2000 and KERC (Terms and Conditions for Determination of Transmission Tariff) Regulations
2006 for approval of Annual Performance Review (APR) for FY 2022-23.
Karnataka Power Transmission Corporation Ltd (KPTCL)
Kaveri Bhavan, Bengaluru - 560 009 ಎ. Applicant
NOTIFICATION
NOTIFICATION of APR FOR FY 2022-23
1.0 In accordance with KERC (Terms and Conditions for Determination of Transmission
Tariff) Regulations 2006, and its amendments from time to time, the Karnataka Power
Transmission Corporation Limited (KPTCL) has filed its Annual Performance Review
(APR) for FY 2022-23 and related proposal for revision of Annual Transmission Tariff
before KERC for approval. The application of KPTCLis under consideration of KERC.
2.0 In the APR Application for FY 2022-23, KPTCL has sought revised Annual Revenue
Requirement(ARR) of Rs. 5146.18 Crore. The revenue gap claimed is Rs. 1701.05
Crore, which is requested to be approved for recovery during FY 2024-25.
3.0 In accordance with the provisions of Electricity Act 2003, and KERC (Tariff) Regulations
2000 and KERC (Terms and Conditions for Determination of Transmission Tariff)
Regulations 2006 and its amendments from time to time, it is hereby notified that
persons who are interested in filing their objections to the above application may file the
same with the RECEIVING OFFICER, KERC, #16 C-1, MILLER TANK BED AREA,
VASANTHANAGARA, BENGALURU-560052 along with the documents which they
want to rely upon, in six sets duly supported by an affidavit within 30 days from the date
of the first publication of this Notification.
4.0 For reference of those who are interested, copies of the KPTCL's Annual Performance
Review (APR) application are available for inspection and for purchase at the following
offices:
(1) Office of the Chief Engineer (Electy), Transmission Zone, KPTCL,
Bengaluru, Tumakuru, Hassan, Mysuru, Bagalkote and Kalaburagi.
(2) The Accounts Officer (Public Relations), Corporate Office, KPTCL,
Ground Floor, Kaveri Bhavan, Bengaluru,
(3) Corporate Offices of Electricity Supply Companies (ESCOMSs) situated at
Bengaluru, Mysuru, Mangaluru, Hubballi and Kalaburagi.
5.0 A full set of application is made available to the interested persons at the above offices.
on payment of Rs.114/- for Kannada and English versions for each set of APR |
application by cash or DD or they may also obtain required portion of the application, by |
paying photo copying charges @ Rs. 1/- per page within 10 working days from the
date of first publication of the notification. These documents are also available on the |
website of KPTCL https://kptel.karnataka.gov.in |
6.0 The objections have to be filed with KERC only. But as directed by KERC, in order to |
expedite the process of objection filing and replies thereon, the objectors are also |
requested to simultaneously send a copy of their objections directly to the |
Managing Director, KPTCL, Corporate Office, Kaveri Bhavan, Bengaluru-560009. |
The last date for receipt of public objections is 30 days from the date of first publication. |
For Karnataka Power Transmission Corporation Limited |
Sd/- |
Managing Director,
KPTCL, Kaveri Bhavan, Bengaluru - 560 009.
Size: 12 x 22cms
Deccan Herald - Karnataka,
Date of Release: 05.01.2024 & 06.01.2024 Consecutively |
The Hindu - Karnataka, |
Date of Release: 05.01.2024 & 06.01.2024 Consecutively |
Layout prepared and submitted for approval by |
Renaissance Advertising |
|
|
|
