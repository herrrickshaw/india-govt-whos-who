---
doc_id: "7fb0864ac9ffdeba"
source_url: "https://vtu.ac.in/wp-content/uploads/2026/09/Notification-English-T-763.pdf"
ministry: "Visveswaraiah Technological University, Belagaiv, Karnataka"
title: ""
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ec05210710fb1a60"
---

<!-- page 1 -->

«±ÉéÃ±ÀégÀAiÀiå
vÁAwæPÀ
«±Àé«zÁå®AiÀÄ
(“« n AiÀÄÄ C¢ü¤AiÀÄªÀÄ 1994” gÀ CrAiÀÄ°è PÀ£ÁðlPÀ ¸ÀPÁðgÀ¢AzÀ ¸ÁÜ¦vÀªÁzÀ gÁdå
«±Àé«zÁå®AiÀÄ)

“eÁÕ£À ¸ÀAUÀªÀÄ”, ¨É¼ÀUÁ«-590 018, PÀ£ÁðlPÀ gÁdå, ¨sÁgÀvÀ

VISVESVARAYA TECHNOLOGICAL UNIVERSITY
(State University of Government of Karnataka Established as per the VTU Act, 1994)

“Jnana Sangama”, Belagavi -590 018, Karnataka State, India

Registrar
Ph. No.0831-2498100
Fax No. 0831-2405467
Website: www.vtu.ac.in
Ref: VTU/BGM/SAP/CW1/T-763/2026-27/2826
Date:01-09-2026
TENDER NOTIFICATION
E-Tenders under Two Cover System are invited by the Registrar, VTU, Belagavi, through
e-Procurement web portal of Govt. of Karnataka from Competent Firms for the following works,
subject to the Terms and Conditions mentioned below:
Tender for Procurement of Enterprise Storage,
Secure & Managed Data Transfer, Display units,
Desktop Computers, IP KVM Switch, Notepad,
1
Name of Work
Hard disks for the establishment of proctored
examination Centre at Examination Section,
Belagavi and re-initiate of VTU e-Shikshana
Programme at VTU, Mysuru
2

Approximate Value of Work

₹ 80,88,310/-

3

Earnest Money Deposit (EMD)

₹.1.62.000/-

4

Date of publishing tender Documents
01-09-2026
on e-procurement platform
Last date of receipt of Tenders
16-09-2026 up to 2.30 p.m.
through E-portal
Opening of Tenders
17-09-2026 @ 4.00 p.m.
http://www.kppp.karnataka.gov.in.
Availability of Tender Documents

5
6
7

Terms and Conditions:
1) Eligibility Criteria:
A. Statutory Requirement:
1. The Tenderer should furnish GST Registration Certificate.
2. The Tenderer should have registered with the Municipal of Corporation/Registration of
Societies/Companies/Director of industries and principal place of business of the
company or firm or partnership, as the case may be.
3. PAN Card Photocopy
4. IT returns for the past 3 years (Assessment year – 2023-24, 2024-25 & 2025-26)
and GST returns for 2022-23, 2023-24 and 2024-25.
B) Technical requirements:
1. If the tenderer is Original Equipment Manufacturer (OEM) / Printers / Proprietary /
Software Developers, should have at least 3 years of experience / expertise in the
successful execution of similar works tendered and the cost of such any one work should
not be less than 80% of estimated amount in a single tender in any State Governments or
Quasi Government Department or Undertaking / Universities / Colleges.
2. If tenderer is quoting as an authorized reseller / Channel partner of a OEM at least 3 years
of experience / expertise in the successful execution of similar works tendered and the cost
of such any one work should not be less than 50% of estimated amount in a single tender
in any State/Central Govt. or Quasi Govt. Department or Undertaking / Universities /

<!-- page 2 -->

Colleges.

3. As proof, the bidders should upload the purchase orders and the corresponding work
completion certificate for work executed in the previous three financial years.
4. Further, conditions and technical specifications incorporated in tender document are
binding on all the bidders.
C) Financial / Commercial Requirements:
1. A turn-over of not less than 80% of estimated cost for at least 3 years, in any of last 5
financial years. As proof, Profit & Loss Account Statement, Balance Sheets and audited
reports certified by CA for corresponding financial years should be uploaded in the eprocurement portal of GoK.
2. Authorization letter from OEM for specified tender.
D) Technical Conditions & General Condition:
As per Tender documents.
2) The Bidders should obtain/download the tender document as stated above, through
E-procurement platform of Govt. of Karnataka, http://www.kppp.karnataka.gov.in, on
payment of requisite tender fees as prescribed by E-governance. For further any
information, contact undersigned during office hours of working days.
The Registrar,
Visvesvaraya Technological University
“Jnana Sangama”, Belagavi – 590 018.
3) EMD is to be paid online during submission of tender documents.
4) If the tender is cancelled due to unforeseen reasons, the cost of the tender form will not be
refunded.
5) The details of work can be obtained from the Registrar, VTU, Belagavi, during working
days/hours.
6) The Bidders should obtain/download the tender document as stated above, through
E-procurement platform of Govt. of Karnataka, http://www.kppp.karnataka.gov.in.
7) The Registrar, VTU, reserves the right to accept / reject any or all the tenders without
assigning any reasons, whatsoever.

Sd/REGISTRAR

Copy to:
The Secretary to Hon’ble Vice Chancellor, VTU for information.
The Finance Officer, VTU for information.
The Private Secretary to the Registrar, VTU for information.
The Regional Director (I/c.), VTU Regional Offices at Bengaluru to display the tender
notification in their notice board.
5. The Director, ITISMU, CNC, VTU for information to publish the notification in the Website.
6. The Director, CDOE, VTU, Mysuru for information and needful.
7. Office copy & all notice boards of all the Offices in VTU Campus.
1.
2.
3.
4.
