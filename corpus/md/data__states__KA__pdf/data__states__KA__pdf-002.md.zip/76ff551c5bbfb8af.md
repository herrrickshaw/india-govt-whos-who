---
doc_id: "76ff551c5bbfb8af"
source_url: "https://dtek.karnataka.gov.in/uploads/2026%20GEC%20Faculty%20Transfer%20List_1783513621.pdf"
ministry: "Department of Technical Education"
title: "ವೀಕ್ಷಿಸಿ"
date: ""
pages: 6
method: "tesseract:kan+eng"
script: "KANNADA"
needs_ocr: false
sha1: "f0b5525878ecb643"
---

<!-- page 1 -->

i ಜಿ
ಕರ್ನಾಟಕ ಸರ್ಕಾರ
ತಾ೦ತ್ರಿಕ ಶಿಕ್ಷಣ ಆಯುಕ್ತರ ಕಛೇರಿಯ ನಡಾವಳಿಗಳು
ವಿಷಯ : ತಾ೦ತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ. ವ್ಯಾಪ್ತಿಯ ಸರ್ಕಾರಿ ಇಂಜಿನಿಯರಿಂಗ್‌
ಕಾಲೇಜುಗಳಲ್ಲಿ ಕರ್ತವ್ಯ ನಿರ್ವಹಿಸುತ್ತಿರುವ ಬೋಧಕರ (ಪ್ರಾಧ್ಯಾಪಕರು,
ಸಹ/ಸಹಾಯಕ ಪ್ರಾಧ್ಯಾಪಕರು (ಗ್ರೂಪ್‌-ಎ) ಸಹಾಯಕ ಪ್ರಾಧ್ಯಾಪಕರು
(ಗ್ರೂಪ್‌-ಬಿ) ಗ್ರ೦ಥಪಾಲಕರು ಮತ್ತು ಕ್ರೀಡಾ ದೈಹಿಕ ವಿರ್ದೇಶಕರು)
ವರ್ಗಾವಣೆ ಬಗ್ಗೆ,
ಉಲ್ಲೇಖ: 1. ಸರ್ಕಾರದ ಅಧಿಸೂಚನೆ ಸಂಖ್ಯೆ: ಇಡಿ 137 ಡಿಟಿಇ 2020 ದಿನಾ೦ಕ:
29.01.2021 ರ೦ತೆ  ಅಧಿಸೂಚಿಸಲಾದ ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆಯ
ಬೋಧಕರ ವರ್ಗಾವಣೆ ನಿಯಂತ್ರಣ ನಿಯಮಗಳು-2021.
2. ಸರ್ಕಾರದ ಅಧಿಸೂಚನೆ ಸಂಖ್ಯೆ: ಇಡಿ 137 ಡಿಟಿಇ 2020, ದಿನಾ೦ಕ:
29.06.2021.
3. ಈ ಕಛೇರಿ ಪ್ರಕಟಣೆ ಸಮ ಸ೦ಖ್ಯೆಯ ದಿನಾ೦ಕ: 08.05.2026.
4. ಈ ಕಛೇರಿ ಸುತ್ತೋಲೆ ಸಮ ಸಂಖ್ಯೆಯ ದಿನಾ೦ಕ: 02.07.2026.
5. ಈ ಕಛೇರಿ ಪ್ರಕಟಣೆ ಸಮ ಸಂಖ್ಯೆಯ ದಿನಾ೦ಕ: 02.07.2026.
6. ಈ ಕಛೇರಿ ಪ್ರಕಟಣೆ ಸಮ ಸ೦ಖ್ಯೆಯ ದಿನಾ೦ಕ: 07.07.2026.
7. ಈ ಕಛೇರಿ ಸುತ್ತೋಲೆ ಸಮ ಸಂಖ್ಯೆಯ ದಿನಾ೦ಕ: 07.07.2026 |
-00000-
ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ ಅಧೀನದ ಸರ್ಕಾರಿ ಇ೦ಜಿನಿಯರಿ೦ಗ್‌ ಕಾಲೇಜುಗಳಲ್ಲಿ ಕರ್ತವ್ಯ
ನಿರ್ವಹಿಸುತ್ತಿರುವ ಬೋಧಕರ (ಪ್ರಾಧ್ಯಾಪಕರು, ಸಹ/ಸಹಾಯಕ ಪ್ರಾಧ್ಯಾಪಕರು (ಗ್ರೂಪ್‌-ಎ)
ಸಹಾಯಕ ಪ್ರಾಧ್ಯಾಪಕರು (ಗ್ರೂಪ್‌-ಬಿ), ಗ್ರ೦ಥಪಾಲಕರು ಮತ್ತು ಕ್ರೀಡಾ ೬ ದೈಹಿಕ ಶಿಕ್ಷಣ
ನಿರ್ದೇಶಕರು) ಹಾಗೂ ಸರ್ಕಾರಿ ಪಾಲಿಟಿಕ್ನಿಕ್‌ ಸ೦ಸ್ಥೆಗಳಲ್ಲಿ ಕರ್ತವ್ಯ ನಿರ್ವಹಿಸುತ್ತಿರುವ
ಉಪನ್ಯಾಸಕರ ವರ್ಗಾವಣೆಗಳನ್ನು ನಿಯಂತ್ರಿಸುವ ಸಲುವಾಗಿ ಉಲ್ಲೇಖಿತ1)ರ ಸರ್ಕಾರದ
ಅಧಿಸೂಚನೆಯಲ್ಲಿ ಕರ್ನಾಟಕ ರಾಜ್ಯ ನಾಗರೀಕ ಸೇವೆಗಳ (ತಾ೦ತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆಯ ಬೋಧಕರ
ವರ್ಗಾವಣೆ ನಿಯಂತ್ರಣ) ನಿಯಮಗಳು-2021 ಅನ್ನು ಹಾಗೂ ಉಲ್ಲೇಖ(2ರಲ್ಲಿ ಸದರಿ ನಿಯಮಗಳ
ಕೆಲವೊ೦ದು ಅಂಶಗಳಿಗೆ ತಿದ್ದುಪಡಿಯನ್ನು ಮಾಡಿ ಅಧಿಸೂಚಿಸಲಾಗ?ರುತ್ತದೆ.
ಸದರಿ ವರ್ಗಾವಣೆ ನಿಯಮಗಳ ನಿಯಮ 8 ರಲ್ಲಿ ಸಾರ್ವಜನಿಕ ಹಿತದೃಷ್ಟಿಯ ಕಡ್ಡಾಯ
ವರ್ಗಾವಣೆ ಹಾಗೂ ವಿಶೇಷ ಪ್ರಕರಣಗಳ ಕೋರಿಕೆ ವರ್ಗಾವಣೆಗಳನ್ನು ಪ್ರತಿ ಕ್ಯಾಲಂಡರ್‌ ವರ್ಷದ ಮೇ
ಮತ್ತು ಜುಲೈ ಮಾಹೆಯ ನಡುವೆ ಕೈಗೊಳ್ಳಲು ಅವಕಾಶ ಕಲ್ಪಿಸಲಾಗಿರುತ್ತದೆ.
ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆಯ ಬೋಧಕರ ವರ್ಗಾವಣೆ ನಿಯಮಗಳಲ್ಲಿನ ಅವಕಾಶಗಳನ್ಹಯ
ವಿಶೇಷ ಪ್ರಕರಣಗಳ ಕೋರಿಕೆ ವರ್ಗಾವಣೆಗೆ ಹಾಗೂ ಸಾರ್ವಜನಿಕ ಹಿತಾಸಕ್ತಿಯ ಕಡ್ಡಾಯ
ವರ್ಗಾವಣೆಯಿ೦ದ ಕೋರಿಕೆ/ವಿನಾಯಿತಿ ಬಯಸುವ ಬೋಧಕರಿ೦ದ ಆನ್‌ಲೈನ್‌ ಮೂಲಕ ನಿಗದಿತ
ಕೊನೆಯ ದಿನಾಂಕದೊಳಗೆ ಸ್ವೀಕೃತವಾದ ಮನವಿಗಳನ್ನು ನಿಯಮಾನುಸಾರ ಪರಿಶೀಲಿಸಿ, ವಿಶೇಷ
ಪ್ರಕರಣಗಳಡಿ ಕೋರಿಕೆ ವರ್ಗಾವಣೆಗೆ ಅರ್ಹರಿರುವ ಬೋಧಕರ ಮತ್ತು ಸಾರ್ವಜನಿಕ ಹಿತಾಸಕ್ತಿಯ
ವರ್ಗಾವಣೆ ಮೇರೆಗೆ ಕಡ್ಡಾಯ ವರ್ಗಾವಣೆಗೆ ಒಳಪಡುವ ಬೋಧಕರ ಅಂತಿಮ ಆದ್ಯತಾ ಪಟ್ಟಿಗಳನ್ನು
ತಯಾರಿಸಿ ದಿನಾ೦ಕ: 08.07.2026 ರಂದು ಆನ್‌ಲೈನ್‌ ಮೂಲಕ ಕೌನ್ಸಿಲಿಂಗ್‌ ನಡೆಸಿದ್ದು, ಸದರಿ
ಕೌನ್ಸಿಲಿ೦ಗ್‌ನಲ್ಲಿ ಭಾಗವಹಿಸಿ ಸ್ಥಳ ಆಯ್ಕೆ ಮಾಡಿಕೊಂಡ ಬೋಧಕರುಗಳನ್ನು ಅವರು ಆಯ್ಕೆ
ಮಾಡಿಕೊ೦ಡ ಕಾಲೇಜುಗಳಿಗೆ ವರ್ಗಾಯಿಸಲು ಈ ಆದೇಶ. |

<!-- page 2 -->

ಆದೇಶ ಸಂಖೆ; ಡಿಟಿಇ 11 ಇಎಸ್‌ಟಿ(8) 2026, ಬೆ೦ಗಳೂರು ದಿನಾ೦ಕ: 08-07-2026. aa

ಪ್ರಸ್ತಾವನೆಯಲ್ಲಿ ವಿವರಿಸಿರುವಂತೆ, ದಿನಾ೦ಕ: 08.07.2026 ರಂದು. ನಡೆದ ಸರ್ಕಾರಿ
ಇಂ೦ಜಿನಿಯರಿ೦ಗ್‌ ಕಾಲೇಜುಗಳ ಬೋಧಕರ ಆನ್‌ಲೈನ್‌ ಕೌನ್ಸಿಲಿ೦ಗ್‌ನಲ್ಲಿ ಭಾಗವಹಿಸಿ ಸ್ಥಳ ಆಯ್ಕೆ
ಮಾಡಿಕೊ೦ಡ ವಿಶೇಷ ಪ್ರಕರಣಗಳ ಕೋರಿಕೆ ವರ್ಗಾವಣೆ ಮತ್ತು ಸಾರ್ವಜನಿಕ ಹಿತಾಸಕ್ತಿಯ ಕಡ್ಡಾಯ
ವರ್ಗಾವಣೆಗೊ೦ಡ ಬೋಧಕರನ್ನು ಅನುಬಂಧದಲ್ಲಿ ನೀಡಿರುವಂತೆ ಅವರ ಹೆಸರಿನ ಮುಂದೆ
ನಮೂದಿಸಿರುವ ಕಾಲೇಜುಗಳಿಗೆ ವರ್ಗಾಯಿಸಿ ಆದೇಶಿಸಿದೆ.

1. ಅನುಬಂಧದಲ್ಲಿರುವ... ವರ್ಗಾವಣೆಗೊ೦ಡ ಬೋಧಕರನ್ನು ದಿನಾ೦ಕ: .. 08.07.2026ರ
ಅಪರಾಹ್ನದಿ೦ದ ನೇರವಾಗಿ ಕಾಲೇಜಿನ ಕರ್ತವ್ಯದಿ೦ದ ಬಿಡುಗಡೆಗೊಳಿಸಿ ಆದೇಶಿಸಲಾಗಿದ್ದು,
ಸದರಿಯವರುಗಳು ವರ್ಗಾವಣೆ ಆದೇಶದ ಪ್ರತಿಯೊಂದಿಗೆ ವರ್ಗಾವಣೆಗೊ೦ಡ ಕಾಲೇಜಿನಲ್ಲಿ
ನಿಗಧಿತ ಅವಧಿಯೊಳಗೆ ವರದಿ ಮಾಡಿಕೊಳ್ಳುವಂತೆ ಸೂಚಿಸಿದೆ.

2. ಸಾರ್ವಜನಿಕ ಹಿತಾಸಕ್ತಿಯ ಮೇರೆಗೆ ಕಡ್ಮಾಯ ವರ್ಗಾವಣೆಗೊ೦ಡ ಬೋಧಕರು ಕೆ.ಸಿ.ಎಸ್‌
ನಿಯಮಾನುಸಾರ ಅನ್ಕಯವಾಗುವ ಸೇರುವಿಕೆ ಕಾಲ (101176 0719) ಹಾಗೂ ವರ್ಗಾವಣೆ
ಭತ್ಯೆಗಳನ್ನು ಪಡೆಯಲು ಅರ್ಹರಿರುತ್ತಾರೆ.

3. ವಿಶೇಷ ಪ್ರಕರಣಗಳಡಿ ಕೋರಿಕೆ ಮೇರೆಗೆ ವರ್ಗಾವಣೆಗೊ೦ಡ ಬೋಧಕರು ಸೇರುವಿಕೆ ಅವಧಿ
(2017176 1776) ಹಾಗೂ ವರ್ಗಾವಣೆ ಭತ್ಯೆಗಳನ್ನು ಪಡೆಯಲು ಅರ್ಹರಿರುವುದಿಲ್ಲ.

4. ವರ್ಗಾವಣೆ ಹೊ೦ದಿದ ಬೋಧಕ ವರ್ಗದವರು ಜುಲೈ-2026 ಮಾಹೆಯ ವೇತನವನ್ನು ಅವರನ್ನು
ವರ್ಗಾಯಿಸಿದ ಸ೦ಸ್ಥೆಯಲ್ಲಿ ಪಡೆಯತಕ್ಕದ್ದು.

5. ವರ್ಗಾವಣೆಗೊ೦ಡ ಬೋಧಕರುಗಳು ಪ್ರಾಂಶುಪಾಲರ ಪ್ರಭಾರವನ್ನು ನಿರ್ವಹಿಸುತ್ತಿದ್ದಲ್ಲಿ ಈ
ಕಛೇರಿಯ ಸುತ್ತೋಲೆ ಸ೦ಖ್ಯೆ: ಡಿಟಿಇ/22/ಇಎಸ್‌ಆಿ(1)/2024, ದಿ: 30.09.2024ರ೦ತೆ ಪ್ರಾ೦ಶುಪಾಲರ
ಪ್ರಭಾರವನ್ನು ಸದರಿ ಕಾಲೇಜಿನ ಸೇವಾ ಜೀಷ್ಮತೆಯಲ್ಲಿ ಹಿರಿಯರಾದ ಬೋಧಕ ಸಿಬ್ಬಂದಿಗಳಿಗೆ
ವಹಿಸತಕ್ಕದ್ದು.

6. ವರ್ಗಾವಣೆ ಆದೇಶದಲ್ಲಿನ ಬೋಧಕರು ಪ್ರಸೂತಿ ರಜೆ. ಮೇಲಿದ್ದಲ್ಲಿ ರಜಿಯ ನಂತರ
ವರ್ಗಾವಣೆಗೊ೦ಡ ಕಾಲೇಜಿನಲ್ಲಿ ನೇರವಾಗಿ ಕರ್ತವ್ಯಕ್ಕೆ ವರದಿ ಮಾಡಿಕೊಳ್ಳುವುದು.
ಅಲ್ಲಿಯವರೆಗೂ ವರ್ಗಾವಣೆ ಪೂರ್ವ ಕಾಲೇಜಿನಲ್ಲಿಯೇ ವೇತನವನ್ನು ಪಾವತಿಸುವುದು.

7. ವರ್ಗಾವಣೆ ಆದೇಶದಲ್ಲಿರುವ ಬೋಧಕರು ಅನ್ಯ ಕಛೇರಿ ಕರ್ತವ್ಯದ ಮೇರೆಗೆ ಇತರೆ
ಕಛೇರಿ/ಕಾಲೇಜಿನಲ್ಲಿ ಕರ್ತವ್ಯ ನಿರ್ವಹಿಸುತ್ತಿದ್ದಲ್ಲಿ, ಅಂತಹ ಬೋಧಕರ ಅನ್ಯ ಕಛೇರಿ
ಕರ್ತವ್ಯವನ್ನು ತಕ್ಷಣದಿ೦ದ ಜಾರಿಗೆ ಬರುವಂತೆ ರದ್ದುಪಡಿಸಲಾಗಿದೆ.

8. ನೂತನ ಇಂಜಿನಿಯರಿಂಗ್‌ ವಿಶೇಷಾಧಿಕಾರಿಯಾಗಿ ಕಾರ್ಯಭಾರವನ್ನು ನಿರ್ವಹಿಸುತ್ತಿರುವ
ಬೋಧಕರು ವರ್ಗಾವಣೆ ಹೊಂದಿದ್ದಲ್ಲಿ ಸ೦ಸ್ಥೆಯ ಹಿರಿಯ ಬೋಧಕ ವರ್ಗದವರಿಗೆ ತಮ್ಮ
ಕಾರ್ಯಭಾರವನ್ನು ವಹಿಸಿಕೊಡತಕ್ಕದ್ದು.

9. ಪ್ರಸ್ತುತ ಡಿ.ಡಿ.ಓ ಲಭ್ಯವಿಲ್ಲದ ಸಂಸ್ಥೆಗಳಲ್ಲಿ ಕಾರ್ಯವರದಿ ಮಾಡುವ ಬೋಧಕ ವರ್ಗದವರಿಗೆ
ತಾತ್ಕಾಲಿಕವಾಗಿ ಮುಂದಿನ ಆದೇಶದವರೆಗೆ ವೇತನ ಮತ್ತು ಭತ್ಯೆಗಳನ್ನು (ಹೆಚ್‌.ಆರ್‌.ಎ ಮತು
ಸಿಸಿಎ ,ಭತ್ಕೆಯು ನಿಯಮಾನುಸಾರ ಕಾರ್ಯವರದಿ ಮಾಡಿಕೊಂಡ ಸಂಸ್ಥೆಯ ವ್ಯಾಪಿಗೆ
ಒಳಪಟ್ಟಿದೆ) ಕಾರ್ಯಬಿಮುಕ್ತಿ ಹೊ೦ದಿದ ಸಂಸ್ಥೆಯಿಂದ ಸೆಳೆಯತಕ್ಕದ್ದು. 7

ತಿ

<!-- page 3 -->

10. ಸರ್ಕಾರಿ ಇ೦ಜಿನಿಯರಿಂಗ್‌ ಕಾಲೇಜುಗಳಲ್ಲಿ ಮ೦ಜೂರಾಗಿದ್ದ ಜಿಯಾಲಜಿ ಮತ್ತು ಅಂಗ್ಲ
ವಿಷಯಗಳ ಭೋಧಕರುಗಳಿಗೆ ನಿಗಧಿತ ಕಾರ್ಯಭಾರವಿಲ್ಲದೇ ಇರುವ ಕಾರಣ ಸದರಿ ವಿಷಯಗಳ
ಖಾಲಿ ಹುದ್ದೆಗಳನ್ನು ಪರಿವರ್ತಿಸಿ ಮರು ಹಂಚಿಕೆ ಮಾಡಿ ಆದೇಶಿಸಲಾಗಿರುತ್ತದೆ.ಈ ಹಿನ್ನಲೆಯಲ್ಲಿ
2026ನೇ ಸಾಲಿನ ಕಡ್ಡಾಯ ವರ್ಗಾವಣೆ ಕೌನ್ಸೆಲಿಂಗ್‌ನಲ್ಲಿ ಭಾಗವಹಿಸಿರುವ ಸದರಿ ವಿಷಯಗಳ
ಬೋಧಕರುಗಳು. ಕಾರ್ಯನಿರ್ಪಹಿಸುತ್ತಿರುವ.. ಸ್ಥಳಕ್ಕೆ. ಆದೇ ವಿಷಯದ ಮತ್ತೊರ್ವ
ಜೋಧಕರುಗಳು ಆಯ್ಕೆ ಮಾಡಿಕೊಳ್ಳದ ಕಾರಣ ವಿದ್ಯಾರ್ಥಿಗಳ ಹಿತದೃಷ್ಟಿಯಿ೦ದ ಸದರಿ
ಬೋಧಕರುಗಳ ಇಚ್ಚಾನುಸಾರನ ಪ್ರಸ್ತುತ ಕಾರ್ಯನಿರ್ವಸಿಸುತ್ತಿರುವ ಸ೦ಸ್ಥೆಯಲ್ಲಿಯೇ
ಮುಂದುವರೆಯಲು ಅವಕಾಶ ಕಲ್ಪಿಸಲಾ?ರುತ್ತದೆ.
ಆಸ
ಆ >
ಕಲ © ತಾ೦ತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ
ಇವರಿಗೆ, ಳೂ
ಗ ಮೇಲ್ಕಂಡ ಬೋಧಕ ವರ್ಗದವರಿಗೆ (ಸಂಬಂಧಪಟ್ಟ ಸರ್ಕಾರಿ ಇಂಜಿನಿಯರಿಂಗ್‌ ಕಾಲೇಜು
ಪ್ರಾಂಶುಪಾಲರ/ಅಧಿಕಾರಿಗಳ ಮೂಲಕ). |
2. ಸ೦ಬ೦ಧ ಸರ್ಕಾರಿ ಇಂಜಿನಿಯರಿಂಗ್‌ ಕಾಲೇಜುಗಳ ಪ್ರಾಂಶುಪಾಲರಿಗೆ ಮಾಹಿತಿಗಾಗಿ ಹಾಗೂ
ಮು೦ದಿನ ಸೂಕ್ತ ಕ್ರಮಕ್ಕಾಗಿ. |
ಪ್ರತಿಯನ್ನು: |
1. ಮಹಾಲೇಖಪಾಲರು, ಕರ್ನಾಟಕ, ಬೆ೦ಗಳೂರು.
2. ಸರ್ಕಾರದ ಕಾರ್ಯದರ್ಶಿಗಳು, ಉನ್ನತ ಶಿಕ್ಷಣ ಇಲಾಖೆ ಬಹುಮಹಡಿಗಳ ಕಟ್ಟಡ, ಬೆ೦ಗಳೂರು- |
ಮಾಹಿತಿಗಾಗಿ |
3. ಮಾನ್ಯ ಆಯುಕ್ತರ ಅಪ್ಪ ಶಾಖೆ, ತಾ೦ತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆ೦ಗಳೂರು.
4. ಮಾನ್ಯ ನಿರ್ದೇಶಕರ ಅಪ್ತ ಶಾಖೆ, ತಾ೦ತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆ೦ಗಳೂರು.
5. ಜ೦ಟಿ ನಿರ್ದೇಶಕರು (ಆಡಳಿತ) / (ಸಿಡಿಸಿ) / (ತನಿಖೆ) / (ಪರೀಕ್ಷೆ), ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ
ಬೆ೦ಗಳೂರು.
6. ರಿಜಿಸ್ಟಾರ್‌ (ಅಡಳಿತ), ತಾ೦ತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆ೦ಗಳೂರು
7. ಅಡಳಿತ ವಿಭಾಗ, ತಾ೦ತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆ೦ಗಳೂರು (ಇಲಾಖಾ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರಚುರ
ಪಡಿಸಲು).

<!-- page 4 -->

ಸ೦ಖ್ಯೆ; ಡಿಟಿಇ 11 ಇಎಸ್‌ಟಿ(8) 2026, ದಿನಾ೦ಕ: 08-07-2026ರ ಅನುಬ೦ಧ
2026ನೇ ಸಾಲಿನ ಸರ್ಕಾರಿ ಇ೦ಜಿನಿಯರಿಂಗ್‌ ಕಾಲೇಜುಗಳಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿರುವ ಬೋಧಕರ ವರ್ಗಾವಣೆ ಪಟ್ಟಿ
ಲ E HK
2421887 MURALIDHARA B__ |Co¥emment Engineering College, | MECHANICAL ENGG. [Government Engineering College, [ASST REQUEST-
Mosale Hosahalli, Hassan (GENERAL) Hassan PROFESSOR ILL
GURUBASAVANNA |Government Engineering College, |ELECTRONICS & Govt.S K SJ T Institute of 557 N REQUEST-
MG Hassan |COMMUNICATION Engineering, Bangalore PROFESSOR. | PH
2 a |Government Engineering College, [ELECTRONICS & |Government Engineering College, |ASST REQUEST-
3 | 2422492] VEENA YADAV S Cees N
|Chamarajanagara COMMUNICATION |Ramanagaram PROFESSOR | PH
3gi[DRSANGAPPA __|Government Engineering College, [Government Engineering College, [ASST REQUEST-
4 31 . "Bes ಸ
| 1966381 ೧1೦೧೬ 11001173 116221 ಚಟು 7118601, 16070: PROFESSOR ee
5 | 2243201] VENKATESH ‘Government Engineering College, [COMPUTER SCIENCE AND |Government Engineering College, [ASST y_ | REQUEST-
> | 249701 PRASAD B S. [Kushalanagar ENGG ‘Chamarajanagara PROFESSOR ಕ್ವ PH
3 \Government Engineering College, |ELECTRONICS & [Government Engineering College, |ASST REQUEST-
6 | 22 \AGA TA 7 7 B N
care | ema Ramanagaram COMMUNICATION Arasikere PROFESSOR SPO
DR SATISH KUMAR |Government Engineering College, [Government Engineering College, [asst REQUEST-
be B
7 [2246092 (Chamarajanagara ee! \Chamarajanagara PROFESSOR N SPO
| Government Engineering College, |CIVIL. Government Engineering College, |ASST REQUEST-
8} 2 \N Bes B N
Se ee Viprasinagar, Gangavathi IENGINEERING(GENERAL) |Haveri PROFESSOR 580
DR BASAVARAJU T |Government Engineering College, [COMPUTER SCIENCE AND |GovtS K S J T Institute of OE) PUBLIC
9 | 23549371, Hassan IENGG © Engineering, Bangalore eee [ಟೆ 1111031
| DRKC [Government Engineering College, |COMPUTER SCIENCE AND |Government Engineering College, PUBLIC |
10) 2209102) pa VISHANKAR 110581೮ 11058/2111, 1125527 |ENGG Hassan ವ ಗ N_ | oyrerest
Government Engineering College, [COMPUTER SCIENCE AND |GovtS K S J T Institute of |ASST PUBLIC
2
1 2354938/SHABEEN TAJG A lpamanagaram ENGG Engineering, Bangalore PROFESSOR AU | | ovreresr
Government Engineering College, | CIVIL Government Engineering College, PUBLIC
12) 2405571/SHANTHALA Bo Ny arwar IENGINEERING(GENERAL) |Hassan ಡೀ. .ಡ.ಯ A ೫ 0788557
DRG (Government Engineering College, [MECHANICAL ENGG. [Government Engineering College, PUBLIC
13] 1783441 tA HENDRAMANI__|Ramanagaram (GENERAL) Krishnarajpet, Mandya ಹಂ ತ ಜ್‌ ೧7೫೫7
Government Engineering College, |MECHANICAL ENGG. |Government Engineering College, |ASST PUBLIC
ಹ Ramanagaram (GENERAL) Krishnarajpet, Mandya PROFESSOR = N_ | ovterest |
[Government Engineering College, [MECHANICAL ENGG. _ |Government Engineering College. PUBLIC
352: ;
ತಂ Krishnarajpet, Mandya (GENERAL) Ramanagaram ಸಂ us N | oyterest
Government Engineering College, [COMPUTER SCIENCE AND |Government Engineering College, |ASST PUBLIC
2 ಪ ಸ
ii 2421884/DR HAREESH K | crighnarajpet, Mandya ENGG Ramanagaram PROFESSOR ತ್ತ ಜ್‌ ಬಗ?

<!-- page 5 -->

| 3315.
2244841 |GOPALA (Government Engineering College, [COMPUTER SCIENCE AND |Government Engineering College, [ASST ಇರ್‌
Hoovina Hadagali [೫೧೧ Karwar PROFESSOR us INTEREST |
|8| 25317020440 |Government Engineering College, [ELECTRONICS & IGovernment Engineering College, |ASST y | puBtic
Raichur COMMUNICATION |Mailur, Bidar PROFESSOR INTEREST
[19] 2ssine| ಕಾ Government Engineering College, [ELECTRONICS & [Government Engineering College, [ASST y | PuBLic
Raichur COMMUNICATION Talakal, Koppal PROFESSOR INTEREST
2531704 NAHEEDA Government Engineering College, |ELECTRONICS & Government Engineering College, |ASST y | PUBLIC
THARANNUMB _|Raichur COMMUNICATION. Viprasinagar, Gangavathi PROFESSOR INTEREST
[21 Government Engineering College, ‘Government Engineering College, |ASST PUBLIC
21| 22035 8 8 bd
3542/DR THIMMESHA ೩. ೦83 Eee Hassan PROFESSOR N’ | interest
2330988|THIRTHE GOWDA [Government Engineering College, [COMPUTER SCIENCE AND |Government Engineering College, [ASST 5 PUBLIC
ನ” MT Hassan ENGG 40521೮ 1105802111, 1125587 08೧೯೯55೦೫೩ INTEREST
5] 2s07146/DR BASAVARAIA _ [Government Engineering College, Government Engineering College, [ASST PUBLIC
(23 | 250714 7
60110] Hassan |GEOLOGY Ramanagaram PROFESSOR ಮ ಜ್‌ ರರ
3 Government Engineering College, |COMPUTER SCIENCE AND |Government Engineering College, [ASST PUBLIC —
24| 2256573 \ ; B
24) 2256573| POORNIMA, Raichur |ENGG | Viprasinagar, Gangavathi PROFESSOR Y INTEREST
Government Engineering College, |ELECTRONICS & [Government Engineering College, |ASST PUBLIC
25| 22: N
25) 2256566 08 14815111111 11೪೧. COMMUNICATION [Hassan PROFESSOR INTEREST
[Government Engineering College, [ELECTRONICS & [Government Engineering College, |ASST PUBLIC
2 qi N
26 | 2245063 |DEERA VE Ramanagaram COMMUNICATION [Mosale Hosahalli, Hassan PROFESSOR INTEREST
97] 9244537/HEMANTH KUMAR |Government Engineering College, ELECTRONICS & [Government Engineering College, |ASST ಸ PUBLIC |
cs |Ramanaga COMMUNICATION |Chamarajanagara PROFESSOR, INTEREST _|
Government Engineering College, |ELECTRONICS & [Government Engineering College, |ASST PUBLIC |
| ತಂ ರಂ ವದ Ramanagaram COMMUNICATION |Mosale Hosahalli, Hassan PROFESSOR INTEREST |
(Government Engineering College, [ELECTRONICS & IGovernment Engineering College, |ASST PUBLIC |
1 N
29) 2295218/NOOR FATHIMA | ramanagaram |COMMUNICATION IChallakere, Chitradurga PROFESSOR INTEREST
Government Engineering College, |CIVIL |Government Engineering College, [ASST ni PUBLIC |
೬2. .್ಛಐಆಂಐಐ.| 83/7272 ENGINEERING(GENERAL) |Mosale Hosaballi, Hassan PROFESSOR INTEREST
51 | 353) g99HHANSILAKSHMI K |Government Engineering College, [MECHANICAL ENGG. [Government Engineering College, [ASSOCIATE PUBLIC
31 | 2531599), Haveri (GENERAL) Naragund, Gadag PROFESSOR INTEREST.
cope ,{DR [Government Engineering College, |MECHANICAL ೫೫೧೦. Government Engineering College, |ASSOCIATE at PUBLIC
32| 2372384) p GHA VENDRA C R|Haveri (GENERAL) IMosale Hosahalli, Hassan PROFESSOR INTEREST
0೩ ೧1೩1511 ಛಃ . .
Government Engineering College, |Government Engineering College, |ASST 7 PUBLIC
33| 2259382|KALIDAS Fe |GEOLOGY ee ° PE N | INTEREST
HUCHCHANNAVAR laveri Haveri PROFESSOR

<!-- page 6 -->

5 jp {Government Engineering College, [CIVIL |Government Engineering College, |ASST | pusuic
3. VIJAPUR ಫಾ N .
4) 2405751 |GURURAJ Vu Haveri ENGINEERING(GENERAL) |Naragund, Gadag PROFESSOR INTEREST
| 7 Government Engineering College, {CIVIL |Government Engineering College, |ASST PUBLIC
[35] 2412531/PALLAVIT gineering, ಸ 1
° | 4 Karwar ENGINEERING(GENERAL) |Hoovina Hadagali PROFESSOR INTEREST
36| 2531584/SAMUEL ‘Government Engineering College, _ [MECHANICAL ENGG. (Government Engineering College, [ASST PUBLIC
a IDAYANAND_ Viprasinagar, Gangavathi (GENERAL) Raichur PROFESSOR INTEREST
i Government Engineering College. ‘Government Engineering College, [ASST PUBLIC
[ಟುಟ Krishnarajpet, Mandya ಟಬು Challakere, Chitradurga PROFESSOR INTEREST
ಹ್‌ Government Engineering College, [MECHANICAL ENGG. [Government Engineering College, |ASST 1೫ (ಇ PUBLIC
38| 2256579]DR JAIRAIA R Hoovina Hadagali (GENERAL) Challakere, Chitradurga PROFESSOR INTEREST
so 99 J Government Engineering College, Government Engineering College, |ASST Le fe] PUBLIC
39, 2209510 404೩ರ ಓಲಗ Hacean MATHEMATICS ೨. PROFESSOR ಸ |
i PUBLI
ಡೆ Government Engineering College, Government Engineering College, |ASST 5
೪ ಆರು Kushalanagar ooo Kushalanagar PROFESSOR INTEREST |
I JBLIC
Taal on RAMAKRISHNA Government Engineering College, ‘Government Engineering College, |ASST. 5 Pu |
41) 2308991 | etry Talakal, Koppal 3. 11001102 13203311 PROFESSOR INTEREST |
i ineeri PUBLIC |
5. ನ Government Engineering College, ‘Government Engineering College, [ASST Poe [x
[42] 2422471/SHEMALATHA [ಗಿರ eee Arasikere PROFESSOR INTEREST
ಹ ` ‘Government Engineering College, |೮01470188 551808 AND |Government Engineering College, |ASST [= |x| PUBLIC”
43) 2203974/DR RANGANATHA Sik uchalanagar ೯೫೧. 12558 PROFESSOR INTEREST
7 Government Engineering 00166, |MECHANICAL ENGG. [Government Engineering College, |ASST ೫ |೫| PUBLIC |
ಎಂ ಭಜ Mosale Hosahalli, Hassan (GENERAL) IKrishnarajpet, Mandya PROFESSOR INTEREST
it 1 BLIC |
i Govt.S K $JT Institute of ELECTRONICS & Government Engineering College, [ASST fe [| PU
45] 2511417|DR LEELAVATHIG le ngineering, Bangalore COMMUNICATION Ramanagaram PROFESSOR INTEREST
7 Govt.S K $ J T Institute of ELECTRONICS & Government Engineering College, |ASST PUBLIC,
ಹ | area Engineering, Bangalore ICOMMUNICATION Ramanagaram PROFESSOR INTEREST |
a
ಕಾಲೇಜು ಮತ್ತು. ಸ್‌ ಶಿಕ್ಷಣ ಇಲಾಖೆ
6 ಗ್ರಾ
