---
doc_id: "fffb2da2a2ae76d5"
source_url: "https://www.keonics.in/assets/tenders_images/Tenders17781741581.pdf"
ministry: "Karnataka State Electronics Development Corporation Limited (KEONICS), Karnataka"
title: "ದರಪಟ್ಟಿ ಆಹ್ವಾನ 'INVITATION FOR QUOTATIONS (IFQ) FOR SUPPLY, INSTALLATION, COMMISSIONING, TESTING AND WARRANTY OF VIDEO CONFERENCE SYSTEM WITH ACCESSORIES TO KEONICS, BANGALORE'-  Open"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "debf4257a98544c7"
---

<!-- page 1 -->

-rlir

Iffitr, doarad crotrd Subyrord o0dlq Odil Oob&d

ISO 9O01:2015

iA Government of Karnataka Enterprise)

No. KSEDC/|IS/P06912O25-26

[E-318670]

Date:07.05.2026

rNvrTATroN FOR qUOTATTONS (rFQ)
FOR SUPPLY INSTATLATION, COMMISSIONING,TESTING AND WARRANW OF VIDEO CONFERENCE
SYSTEM WITH ACCESSORIES TO KEONICS, BANGALORE
Sealed quotations are invited from eligible and qualified Companies / Firms for Supply, lnstallation,
Commissioning, Testing and Warranty of Video Conference System with Accessories to KEONICS,
Bangalore in the format given below:

7.

Item Description

sl

Unit

Video Conference System with Accessories

1

No.

atv

Rate

Unit Rate
(Excl. GST)

(%l

(in Rs.)

GST

Unit Rate
(lncl. GST)
(in Rs.)

01

Total

2.

Technica! specification - Video Conference System with Accessories:

Item Description

SI

1

Supply of 75 inch lnteractive Display

2

Supply of Full HD 12X Optical Zoom PT7 Camera

3

Supply of Base station with Unidirectional Microphone of 360 Degree Coverage Full Range
Speakers

4

Supply of Extension Microphone

5

Supply and lnstallation of Cables and Connectors of following specification
HDMI: supports 4K signal transmission USB

6

lnstallation of Complete Solution. lnstallation of interactive display, Mounting of PTZ camera,
Setup of microphone & speakers system, cable laying and termination, lntegration with Laptop/Vc
software, Audio-video synchronization, Network configuration

3

Eligibility Criteria
3.1. The Applicant should be a Company/Firm with valid GST Registration. The Applicant should
have a copy of GST Registration.
3.2. The Applicant should submit compliance to Technical Specifications and Technical
Literature/ Data sheet of Quoted model.

4.

Quoted Price:

4.L. The Applicant shall quote for items in the format of quotation attached.
4.2. The prices shall be quoted in lndian Rupees only.
4.3. All duties, taxes and other levies payable by the bidder (including GST) shall be included in
the quotation.

4.4. GST in connection with the sale shall be shown separately and as applicable.
4.5. The rates and amount quoted shall be fixed for the duration of the contract and shall not
be subject to any adjustment.

4.6. Rates for supply of partial requirements is not acceptable.
4.7. Corrections, if any, shall be made by crossing out, initialing, dating and rewriting
Reg{ Office: f59, Kumara Park West Extension, Railway Parallel Road, Sheshadripuram, Bengaluru 560020
Tel: 080-22225645, Website : www. keonics. i n

<!-- page 2 -->

IFQ for Supply, lnstalla6on, CommissioninS, Testing and Warranty of VC Systems to KEONICS, Bangalore

4.8. Cable or Facsimile quotations are not acceptable
5.

Each bidder must submit only one quotation.

6.

Validity of quotations:
6.1. The quotation shall remain valid for a period not less than 60 days after the deadline fixed
for submission of quotations.

7

Evaluatlon of quotations:

7.1. The Purchaser will evaluate and compare the quotations determined to be substantially
responsive i.e., which are properly signed, and conform to the terms and conditions and
specifications in the following manner:
7 .\.1.
The evaluation will be done including all taxes. lf the tenderer has not included the
taxes in his quotation for the item rate, and has also not indicated the rate of taxes
applicable, the quoted rate will be treated as though it is inclusive of taxes and no
extra payment for taxes will be made
7.f .2.

8.

The evaluation would be done for all the items put together. The items for which
no rates have been quoted would be treated as zero and the total amount would
be computed accordingly. The tenderer who has quoted for partial quantity of any
one or more item(s) would be treated as non-responsive. The Purchaser will award
the contract to the responsive bidder, whose total cost for all the items put
together is the lowest.

Award:

8.1. The Purchaser will award the contract to the bidder whose quotation has been determined
to be substantially responsive and who has offered the lowest evaluated quotation price
(i.e., Total Amount):

8.1.1. The quantity mentioned in the above tablefiormat is tentative and indicative only.
The actual award of services shall be based on the purchaser requirement, and no
claim shall lie on account of variation in quantity.
8.1.2. The Purchaser reserves the right at the time of contract award to increase or
decrease the quantities of any or all of the items indicated in para l above by 25%
without any change in the unit price or any other terms and conditions.
9

100% payment shall be made after the Supply, lnstallation, Commissioning, Testing and Warranty of
materials and their acceptance.

10.

Notwithstanding the above, the Client reserves the right to accept or reject any quotations and to
cancel the quotation process and reject all quotations at any time prior to the award of the
contract.

11. Last date and time of receipt of quotations:
11.1. You are requested to submit the sealed quotations superscribed on the envelope
'rNvrTATtoN FOR QUOTAT|OI{S (tFQ) FOR SUPPLY |NSTALLATTON, COMMISSTONTNG,

TESTING AND WARRANW WARRANW OF VI
ACCESSORIES TO XEONICS, BANGALORE" on or befo

FERENCE SYSTEM WITH
6 by 05.00 PM.

nical,
KEONICS, Bangalore.

Page 2 of 2
