---
doc_id: "1a9de6a98f5dbca7"
source_url: "https://dosel.karnataka.gov.in/uploads/media_to_upload1744365520.pdf"
ministry: "Department of School Education & Literacy, Karnataka"
title: "Right of Children to Free and Compulsory Education Act, 2009 (All Amendments)"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ae105815258bac97"
---

<!-- page 1 -->

THE RIGHT OF CHILDREN TO FREE AND COMPULSORY EDUCATION ACT, 2009
__________________

ARRANGEMENT OF SECTIONS
_________Last updated: 26-7-2021_________

CHAPTER I
PRELIMINARY
SECTIONS
1. Short title, extent and commencement.
2. Definitions.

CHAPTER II
RIGHT TO FREE AND COMPULSORY EDUCATION
3. Right of child to free and compulsory education.
4. Special provisions for children not admitted to, or who have not completed, elementary
education.
5. Right of transfer to other school.

CHAPTER III
DUTIES OF APPROPRIATE GOVERNMENT, LOCAL AUTHORITY AND PARENTS
6. Duty of appropriate Government and local authority to establish school.
7. Sharing of financial and other responsibilities.
8. Duties of appropriate Government.
9. Duties of local authority.
10. Duty of parents and guardian.
11. Appropriate Government to provide for pre-school education.

CHAPTER IV
RESPONSIBILITIES OF SCHOOLS AND TEACHERS
12. Extent of school’s responsibility for free and compulsory education.
13. No capitation fee and screening procedure for admission.
14. Proof of age for admission.
15. No denial of admission.
16. Prohibition of holding back and expulsion.
17. Prohibition of physical punishment and mental harassment to child.
18. No school to be established without obtaining certificate of recognition.
19. Norms and standards for school.
20. Power to amend Schedule.
21. School Management Committee.
22. School Development Plan.
23. Qualifications for appointment and terms and conditions of service of teachers.
1

<!-- page 2 -->

SECTIONS
24. Duties of teachers and redressal of grievances.
25. Pupil-Teacher Ratio.
26. Filling up vacancies of teachers.
27. Prohibition of deployment of teachers for non-educational purposes.
28. Prohibition of private tuition by teacher.

CHAPTER V
CURRICULUM AND COMPLETION OF ELEMENTARY EDUCATION
29. Curriculum and evaluation procedure.
30. Examination and completion certificate.

CHAPTER VI
PROTECTION OF RIGHT OF CHILDREN
31. Monitoring of child’s right to education.
32. Redressal of grievances.
33. Constitution of National Advisory Council.
34. Constitution of State Advisory Council.

CHAPTER VII
MISCELLANEOUS
35. Power to issue directions.
36. Previous sanction for prosecution.
37. Protection of action taken in good faith.
38. Power of appropriate Government to make rules.
39. Power of Central Government to remove difficulties.
THE SCHEDULE.

2

<!-- page 3 -->

THE RIGHT OF CHILDREN TO FREE AND COMPULSORY EDUCATION ACT, 2009
ACT NO. 35 OF 2009
[26th August, 2009.]

An Act to provide for free and compulsory education to all children of the age of six to fourteen
years.
BE it enacted by Parliament in the Sixtieth Year of the Republic of India as follows:—
CHAPTER I
PRELIMINARY
1. 1[Short title, extent, application and commencement].—(1) This Act may be called the Right of
Children to Free and Compulsory Education Act, 2009.
(2) It shall extend to the whole of India 2***.
(3) It shall come into force on such date3 as the Central Government may, by notification in the
Official Gazette, appoint.
4

[(4) Subject to the provisions of articles 29 and 30 of the Constitution, the provisions of this Act shall
apply to conferment of rights on children to free and compulsory education.
(5) Nothing contained in this Act shall apply to Madrasas, Vedic Pathsalas and educational
institutions primarily imparting religious instruction.]
2. Definitions.—In this Act, unless the context otherwise requires,—
(a) “appropriate Government” means—
(i) in relation to a school established, owned or controlled by the Central Government, or the
administrator of the Union territory, having no legislature, the Central Government;
(ii) in relation to a school, other than the school referred to in sub-clause (i), established
within the territory of—
(A) a State, the State Government;
(B) a Union territory having legislature, the Government of that Union territory;
(b) “capitation fee” means any kind of donation or contribution or payment other than the fee
notified by the school;
(c) “child” means a male or female child of the age of six to fourteen years;
(d) “child belonging to disadvantaged group” means 5[a child with disability or] a child belonging
to the Scheduled Caste, the Scheduled Tribe, the socially and educationally backward class or such
other group having disadvantage owing to social, cultural, economical, geographical, linguistic,
gender or such other factor, as may be specified by the appropriate Government, by notification;
(e) “child belonging to weaker section” means a child belonging to such parent or guardian whose
annual income is lower than the minimum limit specified by the appropriate Government, by
notification;
[(ee) “child with disability” includes,—

5

(A) a child with “disability” as defined in clause (i) of section 2 of the Persons with
Disabilities (Equal Opportunities, Protection of Rights and Full Participation) Act, 1995
(1 of 1996);

1. Subs. by Act 2 of 2018, s. 3 and The Second Schedule, for “the marginal heading” (w.e.f. 5-1-2018).
2. The words “except the State of Jammu and Kashmir” omitted by Act 34 of 2019, s. 95 and the Fifth Schedule
(w.e.f. 31-10-2019).
3. 1st April, 2010, vide notification No. S.O. 428(E), dated 16th February, 2010, see Gazette of India, Extraordinary, Part II,
sec. 3(ii).
4. Ins. by Act 30 of 2012, s. 2 (w.e.f. 1-8- 2012).
5. Ins. by s. 3, ibid. (w.e.f. 1-8-2012).

3

<!-- page 4 -->

(B) a child, being a person with disability as defined in clause (j) of section 2 of the National
Trust for Welfare of Persons with Autism, Cerebral Palsy, Mental Retardation and Multiple
Disabilities Act, 1999 (44 of 1999);
(C) a child with “severe disability” as defined in clause (o) of section 2 of the National Trust
for Welfare of Persons with Autism, Cerebral Palsy, Mental Retardation and Multiple Disabilities
Act, 1999 (44 of 1999).]
(f) “elementary education” means the education from first class to eighth class;
(g) “guardian”, in relation to a child, means a person having the care and custody of that child and
includes a natural guardian or guardian appointed or declared by a court or a statute;
(h) “local authority” means a Municipal Corporation or Municipal Council or Zila Parishad or
Nagar Panchayat or Panchayat, by whatever name called, and includes such other authority or body
having administrative control over the school or empowered by or under any law for the time being in
force to function as a local authority in any city, town or village;
(i) “National Commission for Protection of Child Rights” means the National Commission for
Protection of Child Rights constituted under section 3 of the Commissions for Protection of Child
Rights Act, 2005 (4 of 2006);
(j) “notification” means a notification published in the Official Gazette;
(k) “parent” means either the natural or step or adoptive father or mother of a child;
(l) “prescribed” means prescribed by rules made under this Act;
(m) “Schedule” means the Schedule annexed to this Act;
(n) “school” means any recognised school imparting elementary education and includes—
(i) a school established, owned or controlled by the appropriate Government or a local
authority;
(ii) an aided school receiving aid or grants to meet whole or part of its expenses from the
appropriate Government or the local authority;
(iii) a school belonging to specified category; and
(iv) an unaided school not receiving any kind of aid or grants to meet its expenses from the
appropriate Government or the local authority;
(o) “screening procedure” means the method of selection for admission of a child, in preference
over another, other than a random method;
(p) “specified category”, in relation to a school, means a school known as Kendriya Vidyalaya,
Navodaya Vidyalaya, Sainik School or any other school having a distinct character which may be
specified, by notification, by the appropriate Government;
(q) “State Commission for Protection of Child Rights” means the State Commission for
Protection of Child Rights constituted under section 3 of the Commissions for Protection of Child
Rights Act, 2005 (4 of 2006).
CHAPTER II
RIGHT TO FREE AND COMPULSORY EDUCATION
3. Right of child to free and compulsory education.—1[(1) Every child of the age of six to fourteen
years, including a child referred to in clause (d) or clause (e) of section 2, shall have the right to free and
compulsory education in a neighbourhood school till the completion of his or her elementary education.]
(2) For the purpose of sub-section (1), no child shall be liable to pay any kind of fee or charges or
expenses which may prevent him or her from pursuing and completing the elementary education.
1. Subs. by Act 30 of 2012, s. 4, for sub-section (1) (w.e.f. 1-8-2012).

4

<!-- page 5 -->

1

*

*

*

*

*

2

[(3) A child with disability referred to in sub-clause (A) of clause (ee) of section 2 shall, without
prejudice to the provisions of the Persons with Disabilities (Equal Opportunities, Protection of Rights and
Full Participation) Act, 1995 (1 of 1996), and a child referred to in sub-clauses (B) and (C) of clause (ee)
of section 2, have the same rights to pursue free and compulsory elementary education which children
with disabilities have under the provisions of Chapter V of the Persons with Disabilities (Equal
Opportunities, Protection of Rights and Full Participation) Act, 1995:
Provided that a child with “multiple disabilities” referred to in clause (h) and a child with “severe
disability” referred to in clause (o) of section 2 of the National Trust for Welfare of Persons with Autism,
Cerebral Palsy, Mental Retardation and Multiple Disabilities Act, 1999 (44 of 1999) may also have the
right to opt for home-based education.]
4. Special provisions for children not admitted to, or who have not completed, elementary
education.—Where a child above six years of age has not been admitted in any school or though
admitted, could not complete his or her elementary education, then, he or she shall be admitted in a class
appropriate to his or her age:
Provided that where a child is directly admitted in a class appropriate to his or her age, then, he or she
shall, in order to be at par with others, have a right to receive special training, in such manner, and within
such time-limits, as may be prescribed:
Provided further that a child so admitted to elementary education shall be entitled to free education
till completion of elementary education even after fourteen years.
5. Right of transfer to other school.—(1) Where in a school, there is no provision for completion of
elementary education, a child shall have a right to seek transfer to any other school, excluding the school
specified in sub-clauses (iii) and (iv) of clause (n) of section 2, for completing his or her elementary
education.
(2) Where a child is required to move from one school to another, either within a State or outside, for
any reason whatsoever, such child shall have a right to seek transfer to any other school, excluding the
school specified in sub-clauses (iii) and (iv) of clause (n) of section 2, for completing his or her
elementary education.
(3) For seeking admission in such other school, the Head-teacher or in-charge of the school where
such child was last admitted, shall immediately issue the transfer certificate:
Provided that delay in producing transfer certificate shall not be a ground for either delaying or
denying admission in such other school:
Provided further that the Head-teacher or in-charge of the school delaying issuance of transfer
certificate shall be liable for disciplinary action under the service rules applicable to him or her.
CHAPTER III
DUTIES OF APPROPRIATE GOVERNMENT, LOCAL AUTHORITY AND PARENTS
6. Duty of appropriate Government and local authority to establish school.—For carrying out the
provisions of this Act, the appropriate Government and the local authority shall establish, within such
area or limits of neighbourhood, as may be prescribed, a school, where it is not so established, within a
period of three years from the commencement of this Act.
7. Sharing of financial and other responsibilities.—(1) The Central Government and the State
Governments shall have concurrent responsibility for providing funds for carrying out the provisions of
this Act.
(2) The Central Government shall prepare the estimates of capital and recurring expenditure for the
implementation of the provisions of the Act.
1. Proviso omitted by Act 30 of 2012, s. 4 (w.e.f. 1-8-2012).
2. Ins. by s. 4, ibid. (w.e.f. 1-8-2012).

5

<!-- page 6 -->

(3) The Central Government shall provide to the State Governments, as grants-in-aid of revenues,
such percentage of expenditure referred to in sub-section (2) as it may determine, from time to time, in
consultation with the State Governments.
(4) The Central Government may make a request to the President to make a reference to the Finance
Commission under sub-clause (d) of clause (3) of article 280 to examine the need for additional resources
to be provided to any State Government so that the said State Government may provide its share of funds
for carrying out the provisions of the Act.
(5) Notwithstanding anything contained in sub-section (4), the State Government shall, taking into
consideration the sums provided by the Central Government to a State Government under sub-section (3),
and its other resources, be responsible to provide funds for implementation of the provisions of the Act.
(6) The Central Government shall—
(a) develop a framework of national curriculum with the help of academic authority specified
under section 29;
(b) develop and enforce standards for training of teachers;
(c) provide technical support and resources to the State Government for promoting innovations,
researches, planning and capacity building.
8. Duties of appropriate Government.—The appropriate Government shall—
(a) provide free and compulsory elementary education to every child:
Provided that where a child is admitted by his or her parents or guardian, as the case may be, in a
school other than a school established, owned, controlled or substantially financed by funds provided
directly or indirectly by the appropriate Government or a local authority, such child or his or her
parents or guardian, as the case may be, shall not be entitled to make a claim for reimbursement of
expenditure incurred on elementary education of the child in such other school.
Explanation.—The term “compulsory education” means obligation of the appropriate
Government to—
(i) provide free elementary education to every child of the age of six to fourteen years; and
(ii) ensure compulsory admission, attendance and completion of elementary education by
every child of the age of six to fourteen years;
(b) ensure availability of a neighbourhood school as specified in section 6;
(c) ensure that the child belonging to weaker section and the child belonging to disadvantaged
group are not discriminated against and prevented from pursuing and completing elementary
education on any grounds;
(d) provide infrastructure including school building, teaching staff and learning equipment;
(e) provide special training facility specified in section 4;
(f) ensure and monitor admission, attendance and completion of elementary education by every
child;
(g) ensure good quality elementary education conforming to the standards and norms specified in
the Schedule;
(h) ensure timely prescribing of curriculum and courses of study for elementary education; and
(i) provide training facility for teachers.
STATE AMENDMENT
Rajasthan
Amendment of section 8, Central Act No. 35 of 2009.—After the existing clause (ii) of the
explanation to clause (a) of section 8 of the Right of Children to Free and Compulsory Education Act,
6

<!-- page 7 -->

2009 (Central Act No. 35 of 2009), hereinafter in this Act referred to as the principal Act, the following
new clause shall he added, namely:“(iii) ensure achievement of class appropriate learning level by every child of the age of six to
fourteen years;”.
[Vide Rajasthan Act 32 of 2017, s. 2].
9. Duties of local authority.—Every local authority shall—
(a) provide free and compulsory elementary education to every child:
Provided that where a child is admitted by his or her parents or guardian, as the case may be, in a
school other than a school established, owned, controlled or substantially financed by funds provided
directly or indirectly by the appropriate Government or a local authority, such child or his or her
parents or guardian, as the case may be, shall not be entitled to make a claim for reimbursement of
expenditure incurred on elementary education of the child in such other school;
(b) ensure availability of a neighbourhood school as specified in section 6;
(c) ensure that the child belonging to weaker section and the child belonging to disadvantaged
group are not discriminated against and prevented from pursuing and completing elementary
education on any grounds;
(d) maintain records of children up to the age of fourteen years residing within its jurisdiction, in
such manner as may be prescribed;
(e) ensure and monitor admission, attendance and completion of elementary education by every
child residing within its jurisdiction;
(f) provide infrastructure including school building, teaching staff and learning material;
(g) provide special training facility specified in section 4;
(h) ensure good quality elementary education conforming to the standards and norms specified in
the Schedule;
(i) ensure timely prescribing of curriculum and courses of study for elementary education;
(j) provide training facility for teachers;
(k) ensure admission of children of migrant families;
(l) monitor functioning of schools within its jurisdiction; and
(m) decide the academic calendar.
10. Duty of parents and guardian.—It shall be the duty of every parent or guardian to admit or
cause to be admitted his or her child or ward, as the case may be, to an elementary education in the
neighbourhood school.
11. Appropriate Government to provide for pre-school education.—With a view to prepare
children above the age of three years for elementary education and to provide early childhood care and
education for all children until they complete the age of six years, the appropriate Government may make
necessary arrangement for providing free pre-school education for such children.
CHAPTER IV
RESPONSIBILITIES OF SCHOOLS AND TEACHERS
12. Extent of school's responsibility for free and compulsory education.—(1) For the purposes of
this Act, a school,—
(a) specified in sub-clause (i) of clause (n) of section 2 shall provide free and compulsory
elementary education to all children admitted therein;

7

<!-- page 8 -->

(b) specified in sub-clause (ii) of clause (n) of section 2 shall provide free and compulsory
elementary education to such proportion of children admitted therein as its annual recurring aid or
grants so received bears to its annual recurring expenses, subject to a minimum of twenty-five per
cent.;
(c) specified in sub-clauses (iii) and (iv) of clause (n) of section 2 shall admit in class I, to the
extent of at least twenty-five per cent. of the strength of that class, children belonging to weaker
section and disadvantaged group in the neighbourhood and provide free and compulsory elementary
education till its completion:
Provided further that where a school specified in clause (n) of section 2 imparts pre-school education,
the provisions of clauses (a) to (c) shall apply for admission to such pre-school education.
(2) The school specified in sub-clause (iv) of clause (n) of section 2 providing free and compulsory
elementary education as specified in clause (c) of sub-section (1) shall be reimbursed expenditure so
incurred by it to the extent of per-child-expenditure incurred by the State, or the actual amount charged
from the child, whichever is less, in such manner as may be prescribed:
Provided that such reimbursement shall not exceed per-child-expenditure incurred by a school
specified in sub-clause (i) of clause (n) of section 2:
Provided further that where such school is already under obligation to provide free education to a
specified number of children on account of it having received any land, building, equipment or other
facilities, either free of cost or at a concessional rate, such school shall not be entitled for reimbursement
to the extent of such obligation.
(3) Every school shall provide such information as may be required by the appropriate Government or
the local authority, as the case may be.
13. No capitation fee and screening procedure for admission.—(1) No school or person shall,
while admitting a child, collect any capitation fee and subject the child or his or her parents or guardian to
any screening procedure.
(2) Any school or person, if in contravention of the provisions of sub-section (1),—
(a) receives capitation fee, shall be punishable with fine which may extend to ten times the
capitation fee charged;
(b) subjects a child to screening procedure, shall be punishable with fine which may extend to
twenty-five thousand rupees for the first contravention and fifty thousand rupees for each subsequent
contraventions.
14. Proof of age for admission.—(1) For the purposes of admission to elementary education, the age
of a child shall be determined on the basis of the birth certificate issued in accordance with the provisions
of the Births, Deaths and Marriages Registration Act, 1886 (6 of 1886) or on the basis of such other
document, as may be prescribed.
(2) No child shall be denied admission in a school for lack of age proof.
15. No denial of admission.—A child shall be admitted in a school at the commencement of the
academic year or within such extended period as may be prescribed:
Provided that no child shall be denied admission if such admission is sought subsequent to the
extended period:
Provided further that any child admitted after the extended period shall complete his studies in such
manner as may be prescribed by the appropriate Government.
[16. Examination and holding back in certain cases.—(1) There shall be a regular examination in
the fifth class and in the eighth class at the end of every academic year.
1

1. Subs. by Act 1 of 2019, s. 2 (w.e.f. 1-3-2019).

8

<!-- page 9 -->

(2) If a child fails in the examination referred to in sub-section (1), he shall be given additional
instruction and granted opportunity for re-examination within a period of two months from the date of
declaration of the result.
(3) The appropriate Government may allow schools to hold back a child in the fifth class or in the
eighth class or in both classes, in such manner and subject to such conditions as may be prescribed, if he
fails in the re-examination referred to in sub-section (2):
Provided that the appropriate Government may decide not to hold back a child in any class till the
completion of elementary education.
(4) No child shall be expelled from a school till the completion of elementary education.]
STATE AMENDMENT
Rajasthan
Amendment of section 16, Central Act No. 35 of 2009.-In section 16 of the principal Act, for the
existing punctuation mark”. “appearing at the end, the punctuation mark”: “shall be substituted and
thereafter the following proviso shall be added, namely:“Provided that if a child has not achieved class appropriate learning level in a class, he may be held
back in that class.”
[Vide Rajasthan Act 32 of 2017, s. 3]
17. Prohibition of physical punishment and mental harassment to child.—(1) No child shall be
subjected to physical punishment or mental harassment.
(2) Whoever contravenes the provisions of sub-section (1) shall be liable to disciplinary action under
the service rules applicable to such person.
18. No School to be established without obtaining certificate of recognition.—(1) No school, other
than a school established, owned or controlled by the appropriate Government or the local authority, shall,
after the commencement of this Act, be established or function, without obtaining a certificate of
recognition from such authority, by making an application in such form and manner, as may be
prescribed.
(2) The authority prescribed under sub-section (1) shall issue the certificate of recognition in such
form, within such period, in such manner, and subject to such conditions, as may be prescribed:
Provided that no such recognition shall be granted to a school unless it fulfils norms and standards
specified under section 19.
(3) On the contravention of the conditions of recognition, the prescribed authority shall, by an order
in writing, withdraw recognition:
Provided that such order shall contain a direction as to which of the neighbourhood school, the
children studying in the derecognised school, shall be admitted:
Provided further that no recognition shall be so withdrawn without giving an opportunity of being
heard to such school, in such manner, as may be prescribed.
(4) With effect from the date of withdrawal of the recognition under sub-section (3), no such school
shall continue to function.
(5) Any person who establishes or runs a school without obtaining certificate of recognition, or
continues to run a school after withdrawal of recognition, shall be liable to fine which may extend to one
lakh rupees and in case of continuing contraventions, to a fine of ten thousand rupees for each day during
which such contravention continues.
19. Norms and standards for school.—(1) No school shall be established, or recognised, under
section 18, unless it fulfils the norms and standards specified in the Schedule.

9

<!-- page 10 -->

(2) Where a school established before the commencement of this Act does not fulfil the norms and
standards specified in the Schedule, it shall take steps to fulfil such norms and standards at its own
expenses, within a period of three years from the date of such commencement.
(3) Where a school fails to fulfil the norms and standards within the period specified under subsection (2), the authority prescribed under sub-section (1) of section 18 shall withdraw recognition
granted to such school in the manner specified under sub-section (3) thereof.
(4) With effect from the date of withdrawal of recognition under sub-section (3), no school shall
continue to function.
(5) Any person who continues to run a school after the recognition is withdrawn, shall be liable to
fine which may extend to one lakh rupees and in case of continuing contraventions, to a fine of ten
thousand rupees for each day during which such contravention continues.
20. Power to amend Schedule.—The Central Government may, by notification, amend the Schedule
by adding to, or omitting therefrom, any norms and standards.
21. School Management Committee.—(1) A school, other than a school specified in sub-clause (iv)
of clause (n) of section 2, shall constitute a School Management Committee consisting of the elected
representatives of the local authority, parents or guardians of children admitted in such school and
teachers:
Provided that at least three-fourth of members of such Committee shall be parents or guardians:
Provided further that proportionate representation shall be given to the parents or guardians of
children belonging to disadvantaged group and weaker section:
Provided also that fifty per cent. of Members of such Committee shall be women.
(2) The School Management Committee shall perform the following functions, namely:—
(a) monitor the working of the school;
(b) prepare and recommend school development plan;
(c) monitor the utilisation of the grants received from the appropriate Government or local
authority or any other source; and
(d) perform such other functions as may be prescribed.
[Provided that the School Management Committee constituted under sub-section (1) in respect of,—

1

(a) a school established and administered by minority whether based on religion or language; and
(b) all other aided schools as defined in sub-section (ii) of clause (n) of section 2,
shall perform advisory function only.]
STATE AMENDMENT
Rajasthan
Amendment of section 21, Central Act No. 35 of 2009.—In sub-section (2) of section 21 of the
principal Act,-

(i) in clause (c), the existing word “and”, appearing at the end, shall be deleted; and
(ii) after the existing clause (c), so amended, and before the existing clause (d), the following new
clause shall be inserted, namely:“(ca) ensure that teachers perform their duties specified by or under section 24; and”.
[Vide Rajasthan Act 32 of 2017, s. 4].
22. School Development Plan.—(1) Every 2[School Management Committee, except the School
Management Committee in respect of a school established and administered by minority, whether based
on religion or language and an aided school as defined in sub-clause (ii) of clause (n) of section 2,
1. Ins. by Act 30 of 2012, s. 5 (w.e.f. 1-8-2012).
2. Subs. by s. 6, ibid., for “School Management Committee, constituted” (w.e.f. 1-8-2012).

10

<!-- page 11 -->

constituted] under sub-section (1) of section 21, shall prepare a School Development Plan, in such manner
as may be prescribed.
(2) The School Development Plan so prepared under sub-section (1) shall be the basis for the plans
and grants to be made by the appropriate Government or local authority, as the case may be.
23. Qualifications for appointment and terms and conditions of service of teachers.—(1) Any
person possessing such minimum qualifications, as laid down by an academic authority, authorised by the
Central Government, by notification, shall be eligible for appointment as a teacher.
(2) Where a State does not have adequate institutions offering courses or training in teacher
education, or teachers possessing minimum qualifications as laid down under sub-section (1) are not
available in sufficient numbers, the Central Government may, if it deems necessary, by notification, relax
the minimum qualifications required for appointment as a teacher, for such period, not exceeding five
years, as may be specified in that notification:
Provided that a teacher who, at the commencement of this Act, does not possess minimum
qualifications as laid down under sub-section (1), shall acquire such minimum qualifications within a
period of five years.
1

[Provided further that every teacher appointed or in position as on the 31st March, 2015, who does
not possess minimum qualifications as laid down under sub-section (1), shall acquire such minimum
qualifications within a period of four years from the date of commencement of the Right of Children to
Free and Compulsory Education (Amendment) Act, 2017.].
(3) The salary and allowances payable to, and the terms and conditions of service of, teachers shall be
such as may be prescribed.
24. Duties of teachers and redressal of grievances.—(1) A teacher appointed under sub-section (1)
of section 23 shall perform the following duties, namely:—
(a) maintain regularity and punctuality in attending school;
(b) conduct and complete the curriculum in accordance with the provisions of sub-section (2) of
section 29;
(c) complete entire curriculum within the specified time;
(d) assess the learning ability of each child and accordingly supplement additional instructions, if
any, as required;
(e) hold regular meetings with parents and guardians and apprise them about the regularity in
attendance, ability to learn, progress made in learning and any other relevant information about the
child; and
(f) perform such other duties as may be prescribed.
(2) A teacher committing default in performance of duties specified in sub-section (1), shall be liable
to disciplinary action under the service rules applicable to him or her:
Provided that before taking such disciplinary action, reasonable opportunity of being heard shall be
afforded to such teacher.
(3) The grievances, if any, of the teacher shall be redressed in such manner as may be prescribed.

1. Ins. by Act 24 of 2017, s. 2 (w.e.f. 1-4-2015).

11

<!-- page 12 -->

STATE AMENDMENT
Rajasthan
Amendment of section 24, Central Act No. 35 of 2009.-In clause (d) of sub-section (1) of section
24 of the principal Act, for the existing expression “as required”, the expression “required for achieving
class appropriate learning level” shall be substituted.
[Vide Rajasthan Act 32 of 2017, s. 5].
25. Pupil-Teacher Ratio.—(1) 1[Within three years] from the date of commencement of this Act, the
appropriate Government and the local authority shall ensure that the Pupil-Teacher Ratio, as specified in
the Schedule, is maintained in each school.
(2) For the purpose of maintaining the Pupil-Teacher Ratio under sub-section (1), no teacher posted in
a school shall be made to serve in any other school or office or deployed for any non-educational purpose,
other than those specified in section 27.
26. Filling up vacancies of teachers.—The appointing authority, in relation to a school established,
owned, controlled or substantially financed by funds provided directly or indirectly by the appropriate
Government or by a local authority, shall ensure that vacancy of teacher in a school under its control shall
not exceed ten per cent/of the total sanctioned strength.
27. Prohibition of deployment of teachers for non-educational purposes.—No teacher shall be
deployed for any non-educational purposes other than the decennial population census, disaster relief
duties or duties relating to elections to the local authority or the State Legislatures or Parliament, as the
case may be.
28. Prohibition of private tuition by teacher.—No teacher shall engage himself or herself in private
tuition or private teaching activity.
CHAPTER V
CURRICULUM AND COMPLETION OF ELEMENTARY EDUCATION
29. Curriculum and evaluation procedure.—(1) The curriculum and the evaluation procedure for
elementary education shall be laid down by an academic authority to be specified by the appropriate
Government, by notification.
(2) The academic authority, while laying down the curriculum and the evaluation procedure under
sub-section (1), shall take into consideration the following, namely:—
(a) conformity with the values enshrined in the Constitution;
(b) all round development of the child;
(c) building up child's knowledge, potentiality and talent;
(d) development of physical and mental abilities to the fullest extent;
(e) learning through activities, discovery and exploration in a child friendly and child-centered
manner;
(f) medium of instructions shall, as far as practicable, be in child's mother tongue;
(g) making the child free of fear, trauma and anxiety and helping the child to express views
freely;
(h) comprehensive and continuous evaluation of child's understanding of knowledge and his or
her ability to apply the same.

1. Subs. by Act 30 of 2012, s. 7, for “Within six months” (w.e.f. 1-8-2012).

12

<!-- page 13 -->

STATE AMENDMENT
Rajasthan
Amendment of section 29, Central Act No. 35 of 2009.—In sub-section (1) of section 29 of the
principal Act, after the existing expression “curriculum” and before the existing expression “and the evaluation
procedure”, the expression”, class appropriate learning level” shall be inserted.
[Vide Rajasthan Act 32 of 2017, s. 6].
30. Examination and completion certificate.—(1) No child shall be required to pass any Board
examination till completion of elementary education.
(2) Every child completing his elementary education shall be awarded a certificate, in such form and
in such manner, as may be prescribed.
CHAPTER VI
PROTECTION OF RIGHT OF CHILDREN
31. Monitoring of child's right to education.—(1) The National Commission for Protection of Child
Rights constituted under section 3, or, as the case may be, the State Commission for Protection of Child
Rights constituted under section 17, of the Commissions for Protection of Child Rights Act, 2005
(4 of 2006), shall, in addition to the functions assigned to them under that Act, also perform the following
functions, namely:—
(a) examine and review the safeguards for rights provided by or under this Act and recommend
measures for their effective implementation;
(b) inquire into complaints relating to child's right to free and compulsory education; and
(c) take necessary steps as provided under sections 15 and 24 of the said Commissions for
Protection of Child Rights Act.
(2) The said Commissions shall, while inquiring into any matters relating to child's right to free and
compulsory education under clause (c) of sub-section (1), have the same powers as assigned to them
respectively under sections 14 and 24 of the said Commissions for Protection of Child Rights Act.
(3) Where the State Commission for Protection of Child Rights has not been constituted in a State, the
appropriate Government may, for the purpose of performing the functions specified in clauses (a) to (c) of
sub-section (1), constitute such authority, in such manner and subject to such terms and conditions, as
may be prescribed.
32. Redressal of grievances.—(1) Notwithstanding anything contained in section 31, any person
having any grievance relating to the right of a child under this Act may make a written complaint to the
local authority having jurisdiction.
(2) After receiving the complaint under sub-section (1), the local authority shall decide the matter
within a period of three months after affording a reasonable opportunity of being heard to the parties
concerned.
(3) Any person aggrieved by the decision of the local authority may prefer an appeal to the State
Commission for Protection of Child Rights or the authority prescribed under sub-section (3) of section 31,
as the case may be.
(4) The appeal preferred under sub-section (3) shall be decided by State Commission for Protection of
Child Rights or the authority prescribed under sub-section (3) of section 31, as the case may be, as
provided under clause (c) of sub-section (1) of section 31.
33. Constitution of National Advisory Council.—(1) The Central Government shall constitute, by
notification, a National Advisory Council, consisting of such number of Members, not exceeding fifteen,
as the Central Government may deem necessary, to be appointed from amongst persons having
knowledge and practical experience in the field of elementary education and child development.

13

<!-- page 14 -->

(2) The functions of the National Advisory Council shall be to advise the Central Government on
implementation of the provisions of the Act in an effective manner.
(3) The allowances and other terms and conditions of the appointment of Members of the National
Advisory Council shall be such as may be prescribed.
34. Constitution of State Advisory Council.—(1) The State Government shall constitute, by
notification, a State Advisory Council consisting of such number of Members, not exceeding fifteen, as
the State Government may deem necessary, to be appointed from amongst persons having knowledge and
practical experience in the field of elementary education and child development.
(2) The functions of the State Advisory council shall be to advise the State Government on
implementation of the provisions of the Act in an effective manner.
(3) The allowances and other terms and conditions of appointment of Members of the State Advisory
Council shall be such as may be prescribed.
CHAPTER VII
MISCELLANEOUS
35. Power to issue directions.—(1) The Central Government may issue such guidelines to the
appropriate Government or, as the case may be, the local authority, as it deems fit for the purposes of
implementation of the provisions of this Act.
(2) The appropriate Government may issue guidelines and give such directions, as it deems fit, to the
local authority or the School Management Committee regarding implementation of the provisions of this
Act.
(3) The local authority may issue guidelines and give such directions, as it deems fit, to the School
Management Committee regarding implementation of the provisions of this Act.
36. Previous sanction for prosecution.—No prosecution for offences punishable under sub-section
(2) of section 13, sub-section (5) of section 18 and sub-section (5) of section 19 shall be instituted except
with the previous sanction of an officer authorised in this behalf, by the appropriate Government, by
notification.
37. Protection of action taken in good faith.—No suit or other legal proceeding shall lie against the
Central Government, the State Government, the National Commission for Protection of Child Rights, the
State Commission for Protection of Child Rights, the local authority, the School Management Committee
or any person, in respect of anything which is in good faith done or intended to be done, in pursuance of
this Act, or any rules or order made thereunder.
38. Power of appropriate Government to make rules.—(1) The appropriate Government may, by
notification, make rules, for carrying out the provisions of this Act.
(2) In particular, and without prejudice to the generality of the foregoing powers, such rules may
provide for all or any of the following matters, namely:—
(a) the manner of giving special training and the time-limit thereof, under first proviso to
section 4;
(b) the area or limits for establishment of a neighbourhood school, under section 6;
(c) the manner of maintenance of records of children up to the age of fourteen years, under
clause (d) of section 9;
(d) the manner and extent of reimbursement of expenditure, under sub-section (2) of section 12;
(e) any other document for determining the age of child under sub-section (1) of section 14;
(f) the extended period for admission and the manner of completing study if admitted after the
extended period, under section 15;
1

[(fa) the manner and the conditions subject to which a child may be held back under sub-section
(3) of section 16;]
1. Ins. by Act 1 of 2019, s. 2 (w.e.f. 1-3-2019).

14

<!-- page 15 -->

(g) the authority, the form and manner of making application for certificate of recognition, under
sub-section (1) of section 18;
(h) the form, the period, the manner and the conditions for issuing certificate of recognition,
under sub-section (2) of section 18;
(i) the manner of giving opportunity of hearing under second proviso to sub-section (3) of
section 18;
(j) the Other functions to be performed by School Management Committee under clause (d) of
sub-section (2) of section 21;
(k) the manner of preparing School Development Plan under sub-section (1) of section 22;
(l) the salary and allowances payable to, and the terms and conditions of service of, teacher, under
sub-section (3) of section 23;
(m) the duties to be performed by the teacher under clause (f) of sub-section (1) of section 24;
(n) the manner of redressing grievances of teachers under sub-section (3) of section 24;
(o) the form and manner of awarding certificate for completion of elementary education under
sub-section (2) of section 30;
(p) the authority, the manner of its constitution and the terms and conditions therefor, under
sub-section (3) of section 31;
(q) the allowances and other terms and conditions of appointment of Members of the National
Advisory Council under sub-section (3) of section 33;
(r) the allowances and other terms and conditions of appointment of Members of the State
Advisory Council under sub-section (3) of section 34.
(3) Every rule made under this Act and every notification issued under sections 20 and 23 by the
Central Government shall be laid, as soon as may be after it is made, before each House of Parliament,
while it is in session, for a total period of thirty days which may be comprised in one session or in two or
more successive sessions, and if, before the expiry of the session immediately following the session or the
successive sessions aforesaid, both Houses agree in making any modification in the rule or notification or
both Houses agree that the rule or notification should not be made, the rule or notification shall thereafter
have effect only in such modified form or be of no effect, as the case may be; so, however, that any such
modification or annulment shall be without prejudice to the validity of anything previously done under
that rule or notification.
(4) Every rule or notification made by the State Government under this Act shall be laid, as soon as
may be after it is made; before the State Legislatures.
[39. Power of Central Government to remove difficulties.—(1) If any difficulty arises in giving
effect to the provisions of this Act, the Central Government may, by order, published in the Official
Gazette, make such provisions not inconsistent with the provisions of this Act, as may appear to it to be
necessary for removing the difficulty:
1

Provided that no order shall be made under this section after the expiry of three years from the
commencement of the Right of Children to Free and Compulsory Education (Amendment) Act, 2012
(30 of 2012).
(2) Every order made under this section shall be laid, as soon as may be after it is made, before each
House of Parliament.]

1. Ins. by Act 30 of 2012, s. 8 (w.e.f. 1-8-2012).

15

<!-- page 16 -->

THE SCHEDULE
(See sections 19 and 25)
NORMS AND STANDARDS FOR A SCHOOL
Sl. No.
1.

Item

Norms and Standards

Numbers of teachers:
(a) For first class to fifth class

(b) For sixth class to eighth class

Admitted children

Number of teachers

Up to Sixty

Two

Between sixty-one to
ninety

Three

Between Ninety-one to
one hundred and twenty

Four

Between One hundred
and twenty-one to two
hundred

Five

Above One hundred and
fifty children

Five plus one Headteacher

Above Two hundred
children

Pupil-Teacher Ratio
(excluding Head-teacher)
shall not exceed forty.

(1) At least one teacher per class so that there shall be
at least one teacher each for—
(i) Science and Mathematics;
(ii) Social Studies;
(iii) Languages.
(2) At least one teacher for every thirty-five children.
(3) Where admission of children is above one
hundred—
(i) a full time head-teacher;
(ii) part time instructors for—
(A) Art Education;
(B) Health and Physical Education;
(C) Work Education.

2.

Building

All-weather building consisting of—
(i) at least one class-room for every teacher and an
office-cum-store-cum-Head teacher’s room;
(ii) barrier-free access;
(iii) separate toilets for boys and girls;
(iv) safe and adequate drinking water facility to all
children;

16

<!-- page 17 -->

Sl. No.

Item

Norms and Standards
(v) a kitchen where mid-day meal is cooked in the
school;
(vi) Playground;
(vii) arrangements for securing the school building by
boundary wall or fencing.

3.

Minimum number of working
days/instructional hours in an
academic year

(i) two hundred working days for first class to fifth
class;
(ii) two hundred and twenty working days for sixth
class to eighth class;
(iii) eight hundred instructional hours per academic
year for first class to fifth class;
(iv) one thousand instructional hours per academic year
for sixth class to eighth class.

4.

Minimum number of working hours
per week for the teacher

forty-five teaching including preparation hours.

5.

Teaching learning equipment

Shall be provided to each class as required.

6.

Library

There shall be a library in each school providing
newspaper, magazines and books on all subjects,
including story-books.

7.

Play material, games and sports
equipment

Shall be provided to each class as required.

17
