---
doc_id: "6b0e3ca0aaedf14f"
source_url: "https://www.kvafsu.edu.in/notification/2022/Supply-of-Poultry-Chick-Feed-at-VCB.pdf"
ministry: "Karnataka Veterinery, Animal and Fisheries Science University, Bidar, Karnataka"
title: "Supply of Poultry Chick Feed at Veterinary College, Bidar"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0c5e1a9d465efe32"
---

<!-- page 1 -->

KARNATAKA VETERINARY, ANIMAL AND FISHERIES SCIENCES UNIVERSITY,
BIDAR

VETERINARY COLLEGE BIDA
Office of the Dean

Phone: 08482-245106

NO.VCB/DEAN/STORE/LPM/2022-23

Date: 11/06/2022

Quotation
Sub- Quotation towards

supply of Poultry Chick Feed- reg.

As per request from LPM

(Hatchery Unit) Department, sealed quotation are invited to supply
following Poultry Chick feed. The quotation
should include full details of
material

such as
catalogue no. Model capacity etc. Printed
be
pomplet
if
enclosed
catalogue
any time
required for supplying the materials and other conditions. may

undersigned on or before 22/06/2022

SI.No.
01

Deseription

Poultry Chick Feed

The quotation should reach the

Quantity/Each Rate

1x50 Kg Bag

Note: Quotation recieved after last
date and having
description of the material incomplete
will not be entertained.

Yours Faithfully

Dean

Veterinary College, Bidar
DEAN (ety)

Copy To,

1) Veterinary College, Bidar. Notice Board
2) Assistant Comptroller, VCB For Kind
Information

Veterinary College, KVAFSU
P.B. No. 6. BIDAR 585226
