---
doc_id: "bcf4bcaf91e4b125"
source_url: "https://www.keonics.in/assets/tenders_images/Tenders17830777991.pdf"
ministry: "Karnataka State Electronics Development Corporation Limited (KEONICS), Karnataka"
title: "ದರಪಟ್ಟಿ ಆಹ್ವಾನ 'INVITATION FOR QUOTATIONS (IFQ) FOR SUPPLY, INSTALLATION, COMMISSIONING, TESTING AND WARRANTY OF VIDEO CONFERENCE SYSTEM WITH ACCESSORIES TO KEONICS, BANGALORE'-  Open"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9a4be0fc15a74bab"
---

<!-- page 1 -->

&----/ duara# oa, Sdlranrd o0d1Q,Cr1il,Cob&d

.ltltllalt

ISO 9001:2015

Karnataka State Electronics Development Corporation Limited
{A Govemment of Xamataka Enterprise)

No. KSEDC,/!TS,/P177/2O25-26 [E-318670]

Date:30.05.2026

TNVTTATTON FOR QUOTAIONS

(tFQ)

FOR SUpPry TNSTALTATTON, COMMISS|Ot{tNG, TEST|ITG AND WARRANTY OF VTDEO CONFERENCE

SYSTEM WITH ACCESSORIES TO KEONtCS, BANGAI.ORE
1

Sealed quotations are invited from eligible and qualified Companies / Firms for Supply, lnstallation,
Commissioning, Testing and Warranty of Video Conference System with Accessories to KEONICS,
Bangalore in the format given below:

Item Description

sl

Unit

75'lnch Non- lnteractive Display Panel

1

Qtv

No.

01

No.

01

No.

01

Rate

U nit Rate
(Excl. GST)

Unit Rate
(lncl. GST)

(.%)

(in Rs.)

(in Rs.)

GST

(Non-Touch)
Audro and Microphone (For Video Conferencing):

2

3 PIZ Lameta:

Total
2

Technical specifi cation

2.L. 75'lnch Non- lnteractive Dtspiay Panei (Non-Touch):
Specification
I En / IDC oi^al

1

t\l^^ T^,,-h

2

Screen Sizes

75"

3

Resolution

4K UHD (3840 x 2150I

4

Aspect Ratio

16:09

5

Brightness

300 cd/m': or Higher

6

Contrast Ratio

1000:1or Higher

7

Viewing AnBle

178' Horizontal / 178' Vertical

8

Colour Depth

10-bit or Higher

9

Refresh Rate

60 Hz (minimum)

10

Response Time

<8ms

11

Audio

Built-in Stereo Speakers, 2 x 10W or higher

12

Video lnputs

2 x HDMI 2.0, 1x pi5plsypsrt (optional)

iJ

Audio lnputs

3.5 mm Audio ln, HDMI Audio Support

74

Audio Outputs

3.5 mm Audio Out, Optical SPDIF (optional)

15

USB Ports

Minimum2xUSBPorts

Regd Office: #59, Kumara Park West Extension, Railway Parallel Ro
-rei: 08G22225545, Website: www.keonics.in

dripuram, Bengaluru 560020

<!-- page 2 -->

IFQ for Supply, lnstallation, Commissioning, Testing and Warrahty ot VC Systems to KEONICS, Bangalore

16

Network / Connectivity

R 45 Ethernet, Wi-Fi, Bluetooth (optional)

77

nq /qnft rrirra a^mhrtihilirv

Android / Windorvs / Linuy / Tizen / WebOS

18

Control lnterface

Remote control / web ut / R5232 / LAN Control

19

Mounting Options

VESA Standard (400 x 400 mm or above)

20

Power Supply

100-240v Ac, 50/60 H2

27

Power Consumption

< 350W for 75-85"

22

Operating Temperature

0'c - 40"c

23

Operating Humidity

10% - 80% RH (non-condensing)

24

Dimensions (Approx.)

Depends on screen size; e.9., 65" - 1480 x 860 x 60 mm

25

Weight

75" - 55-60 kg or Better

26

Environmental Compliance

Bl5, CE Certified

27

Accessories

Remote Control, Power Cable, Wall Mount Kit, User Manual

2A

Warranty

Minimum 3 Years On-site Comprehensive Warranty

2.2. Audio and Microphone ( For Video Conferencing):
cl
1

System Type

lntegrated Audio and Microphone Solution for Conference /
Meeting Room/ Training Room

2

Audio Coverage

Suitable for rooms up to 10-150 sq. meters (expandable based
on requlrement)

3

Microphone Type

Boundary / Ceiling Array / Tabletop / Wireless Gooseneck
Microphones (as per setup)

4

Microphone Technology

Digital MEMS / Condenser with Noise & Echo Cancellation
Minirnum 4-5 meters (omnidirectional / cardioid pattern)

5
6

Frequency Response

100 Hz - 20 kHz

7

Sensitivity

-30dBt3dB

8

Signal-to-Noise Ratio (SNR)

>55dB

9

Connectivity Options

USB / 3.5 mm Audio / XLR / Bluetooth / tp (depending on model)

10

Supported Audio Protocols

AEC (Acoustic Echo Cancellation), ANR (Automatic Noise
Reduction), AGC (Automatic Gain Control)

11

Microphone Powe!. Supply

USB Powered ,/ Phantom Power (48V) / Rechargeable Battery (for
wireless models)

t2

Speaker Type

lntegrated Active Speakers / External Amplified Speakers

13

Speaker Output Power

Minimum 20W RMS per speaker or higher

i4

Speaker Frequency Response

80 Hz - 16 kHz

15

Amplifier Type

Digital Class-D Amplifier (built-in or external)

Page 2 of 5

<!-- page 3 -->

IFQ for Supply, lnstallation, Commissioning, TesOng and Warrantv of VC Systems to KEONtCS, Bangalore

16

Audio lnputs

!7 Audio Outputs

Mic ln, Line ln, Bluetooth, USB Audio

Line Out, Speaker Out, HDMI Audio Out (if integrated with
display)

18

Audio Control

DSP-Based Audio Processor with
Control, and Echo Cancellation

19

Mounting Options

Tabletop / Ceiling Mount / Wall Mount (as applicable)

20

Network lntegration

Compatible with Slg Dante or USB Audio for VC Systems
(Optional)

21

Compatibility

Compatible with Zoom, Microsoft Teams, Google Meet, WebEx,

Noise Suppression, Gain

etc.
22

Power Consumption

< 30W (operating)

23

Operating Temperature

0'c - 40'c

24

OperatinB Humidity

lO% - 90% RH (non-condensing)

25

Cables & Accessories

Ail necessary audio cable, connectors, power adaptors and
mountin8 accessories included

26

Compliance & Standards

CE, FCC, RoHS, BIS cedified

27

Warranty

Minimum 3 Years Comprehensive On-site Warranty

2.3. PTZ Camera:
sl
1

Category
Camera Type

Specification

4K UHD PTZ (Pan-Tilt-Zoom) Professional Camera for Video
Conferencing, Smart Classroom, and Auditorium Use

2

lmage Sensor

!/2.5" or larger CMOS Sensor with Low-Light Enhancement

3

Effective Pixels

Minimum 8.3 Megapixels

4

Video Resolution

4K (3840 x 2150) @ 30 fps, 1080p @ 60/30 fps, 720p @ 60130 fps

5

Optical Zoom

Minimum 12x-20x Optical Zoom

6

Digital Zoom

Up to 16x Digital Zoom

7

Lens Aperture

F/L.6 - F13.5 (auto adjustable)

Field of View (FOV)

Diagonal: 80"-85"; Horizontal: 70'-75"; Vertical: 4C'-45'

9

Pan Range

1170"

10

Tilt Range

-30'to +90"

11

Pan/Iilt Speed

Pan: 60'/sec, Tilt: 3O'/sec. (adjustable)

t2

Auto Tracking

Al-Based Presenter Auto Tracking (Face / Motion Detection)

13

Preset Positions

Minimum 10 via Remote / Up to 255 via Software Control

t4

Focus Mode

Auto / Manual / One Push Focus

15

Exposure Control

Auto / Manual (Shutter, lris, Gain)

15

White Balance

Auto / Manual / Preset modes

Page 3 of 5

<!-- page 4 -->

IFQ for Supply, lnstalla6on, Commissioning, Tes$ng and Warranty of VC Systems to KEONICS, Bangalore

L7

Low Light Performance

0.1 Lux (Color),0.05 Lux (B&W with lR Cut Filter Off)

18

R..lzlidhr inmnon<rtinn

Supported (81C, HLC, WDR >120 dB)

19

Video
Formats

H.255, H.264, MJPEG

20

Output lnterfaces

Compression

HDMI, USB 3.0, LAN (PoE Supported), SDI (optional), RS-232 /
RS-485

2r

Network Protocols

RTSe RTMP, VISCA over lP, ONVIF, SRL NDI

22

Audio lnput

3.5 mm Line-ln / Embedded via HDMI or USB

Audio Processing

Built-in AEC, Noise Suppression (where supported by model)

Control Methods

lR Remote, RS-232/485, lP (Web Ul), USB (UVC), or Software

24

Control
25

Al Features

Auto-Framing, Speaker Tracking, People Counting (optional based
on firmware)

26

Power Supply

DC 12V / PoE (IEEE 802.3af)

27

MountinB Options

Table / Wall / Ceiling Mount (brackets included)

28

Power Consumption

<18 W (PoE /Adapter)

29

Operating Temperature

0"c - 40"c

30

Operating Humidity

lO% - 90% RH (non-condensing)

31

Dimensions (Approx.)

150 mm x 150 mm x 18O mm

32

Weight

< 2.0 kg

33

Compatibility

Plug-and-Play with Zoom, Microsoft Teams, Google Meet, WebEx,
OBS, vMix, etc.

34

Firmware Upgrade

Web-based / USB Firmware Update Supported

35

lncluded Accessories

Power Adaoter, Remote Control, USB 3.0 Cable, Mounting Kit, User
Manual

36

Certifications

CE, FCC, BlS, RoHS Compliant

37

Warranty

Minimum 3 Years Comprehensive On-Site Warranty

3.

Eligibility Criteria
The Applicant should be a Company/Firm with valid GST Re8istration. The Applicant should
have a copy of GST Registration.

3.1.

3.2. The Applicant should submit compliance to Technical Specifications and Technical
Literature/ Data sheet of Quoted model.
4.

Quoted Price:
4.7. The Applicant shall quote for items in the format of quotation attached.
4.2. The prices shall be quoted in lndian Rupees only.
4.3. All duties, taxes and other levies payable by the bidder (including GST) shall be included in
the quotation.

4.4. GST in connection with the sale shall be shown separately and as applicable.
4.5. The rates and amount quoted shall be fixed for the duration of the contract and shall not
be subject to any adiustment

PaBe 4 o{ 5

<!-- page 5 -->

IFQ for Supply, lnstallation, Commissioning. Testing and Warranty of VC Systems to KEONICS, Bangalore

4.6. Rates for supply of partial requirements is not acceptable.
4.7. Corrections, if any, shall be made by crossing out, initialinB, dating and rewriting.
4.8. Cable or Facsimile quotations are not acceptable.
5.

Each bidder must submit only one quotation.

6.

\ralidity of quotations:
6.1. The quotation shall remain valid for a period not less than 30 days after the deadline fixed
for submission of quotations.

7

Evaluation of quotations:

7,f, The Purchaser will evaluate and compare the quotations determined to be substantially
responsive i.e., which are properly signed, and conform to the terms and conditions and
specifications in the following manner:
7
The evaluation will be done including all taxes. lf the tenderer has not included the
taxes in his quotation for the item rate, and has also not indicated the rate of taxes
applicable, the quoted rate will be treated as though it is inclusive of taxes and no
extra payment for taxes will be made
7.L.2. The evaluation would be done for all the items put toSether. The items for which
no rates have been quoted would be treated as zero and the tota! amount would
be computed accordingly. The tenderer who has quoted for partial quantity of any
one or more item(s) would be treated as non-responsive. The Purchaser will award
the contract to the responsive bidder, whose total cost for all the items put
together is the lowest.

.L.L.

8

Award:

8.1. The Purchaser will award the contract to the bidder whose quotation has been determined

to be substantially responsive and who has offered the lowest evaluated quotation price
(i.e., Total Amount):

8.1.1. The quantity mentioned in the above tableformat is tentative and indicative only.
The actual award of services shall be based on the purchaser requirement, and no
clairn shal! lie on account of variation in quantity.
8.1.2. The Purchaser reserves the right at the time of contract award to increase or
decrease the quantities of any or all of the items indicated in para l above by 25%
without any change in the unit price or any other terms and conditions.
9

100% payment shall be made after the Supply, lnstallation, Commissioning, Testing and Warranty of
materials and their acceptance.

10

Notwithstanding the above, the Client reserves the right to accept or reiect any quotations and to
cancel the quotation process and reject all quotations at any time prior to the award of the
contract.

11.

Last date and time of receipt of quotations:

Ll.L. You
are requested to submit the sealed quotations superscribed on the envelope
.INVITATION

FOR QUOTATIOI{S (IFQ) FOR SUPPTY INSTALLATION, COMMISSIONING,
TESTING AND WARRANTY OF VIDEO CONFERENCE
WITH ACCESSORIES TO
KEONICS, BANGALORE" on or before 07.07.2026 by

or Technical,
KEONICS, Bangalore

Page 5 of 5
