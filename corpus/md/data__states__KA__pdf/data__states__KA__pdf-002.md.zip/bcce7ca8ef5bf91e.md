---
doc_id: "bcce7ca8ef5bf91e"
source_url: "https://kseab.karnataka.gov.in/uploads/2027%20II%20PU%20REPEATER%20CANDIDATE%20REGISTRATION_13102026_1791880516.pdf"
ministry: "Karnataka School Examination and Assessment Board, Karnataka"
title: "25    New      2 days ago       2027ನೇ ಸಾಲಿನ ದ್ವಿತೀಯ ಪಿಯುಸಿ ಪರೀಕ್ಷೆ-1ಕ್ಕೆ ಪುನರಾವರ್ತಿತ ಅಭ್ಯರ್ಥಿಗಳ ನೋಂದಣಿಗೆ ಸಂಬಂಧಿಸಿದ ಸುತ್ತೋಲೆ ಹಾಗೂ ಬಳಕೆದಾರರ ಕೈಪಿಡಿ"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "63fdf124ff33af7a"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

KARNATAKA SCHOOL EXAMINATION AND ASSESSMENT BOARD
6th CROSS MALLESHWARAM, BENGALURU – 560 003

2027 II PUC Exam - 1
ONLINE APPLICATION PROCESS

SEQUENTIAL USER MANUAL & WALKTHROUGH
Step-by-Step Complete Walkthrough
Step - 1: Self-Declarations Modal Box

 When accessing the registration URL, a Self-Declaration modal popup appears in both Kannada and
English.
 Read all eligibility rules regarding KSEAB SSLC Board vs. Other Board candidates carefully.
 Confirm requirements regarding candidate photograph upload and 10th marks card data integration.
 Click on the 'I Agree & Continue' button at the bottom right of the modal box to proceed to
registration.

Step - 2: New User Registration & Password Setup

ONLINE APPLICATION PROCESS PRIVATE, REPEATE AND IMPROVEMENT CANDIDATE

Page 1 of 8

<!-- page 6 -->







Click on 'Create New Account' to open the User Registration form.
Enter your 10-digit Mobile Number. This number acts as your official Username for all logins.
Select Candidate Type: 'Private Fresh Candidate' or ‘Repeater /Improvement Candidate’
(/Regular/Private)'.
Set a password conforming to security rules (8–20 characters, 1 uppercase, 1 lowercase, 1 number,
and 1 special symbol).
Re-enter the password in 'Confirm Password' and click 'Get OTP Verification Code' to verify your
phone.

Step - 3: Candidate Portal Login via OTP






Select the 'OTP Login' tab on the login screen.
Enter your registered 10-digit Mobile Number into the Username field.
Click 'Get OTP' to generate an 8-digit login passkey sent to your registered mobile.
Type the OTP received via SMS and click 'Login' to access your candidate dashboard.




Type your custom account password created during account registration.
Click the 'Login' button to authenticate and enter the candidate portal.

ONLINE APPLICATION PROCESS PRIVATE, REPEATE AND IMPROVEMENT CANDIDATE

Page 2 of 8

<!-- page 7 -->

REGISTRATION FOR PRIVATE FRESH CANDIDATES
Step - 4: Instructions & Navigation Dashboard






After logging in, you land on the Instructions dashboard for 2027 II PUC Exam-1.
Toggle between 'English' and 'Kannada' tabs at the top of the card to read guidelines in your
preferred language.
Review key submission guidelines, required document formats, and payment rules.
Use the top navigation header bar to move across Application, Document Upload, Payment, and
Tracking.

Step - 5: 10th Standard Board Selection & Register Number Entry






Under '10th Standard education board Students Information', click the dropdown to select your
10th board.
Option A (SSLC Board - KSEAB Karnataka): Select 'SSLC Board', type your official 10th
Register Number into 'Enter Register Number', and click the green 'VIEW SSLC DATA' button
to auto-populate your details from the database.
Option B (Other Board - CBSE, ICSE, Other State Boards): Select 'Other Board'. Automatic
data retrieval is not supported for non - KSEAB boards, so you MUST manually type all candidate
detail fields across the application form.
For Other Board Candidates: Manually type your 10th Registration Number, Candidate Name,
Father's Name, Mother's Name, Date of Birth (DOB), Gender, Year of Passing, Board Name,
and Marks details directly into the designated input fields.

ONLINE APPLICATION PROCESS PRIVATE, REPEATE AND IMPROVEMENT CANDIDATE

Page 3 of 8

<!-- page 8 -->

Step - 6: Candidate Personal Details Verification






Verify the auto-populated details: Candidate Name, Father Name, Mother Name, DOB, Gender,
10th Register No, and Year of Passing.
Select your Medium of Instruction (e.g., ENGLISH, KANNADA).
Select Religion, Social Category (e.g., 2A, 3B, SC, ST), and Physical Disability status.
Choose your academic Stream (ARTS, COMMERCE).

Step - 7: Subject Combination & Language Selection






Select your Subject Combination code from the dropdown list (e.g., HISTORY, ECONOMICS,
SOCIOLOGY and EDUCATION - 21.22.28.52).
Indicate 'Language Exemption': Select 'Yes' or 'No' as per KSEAB rules.
Under PART - I, select Language I (e.g., 01 - KANNADA) and Language II (e.g., 02 - ENGLISH).
Under PART - II, confirm the core elective subjects (Subject I to Subject IV).

ONLINE APPLICATION PROCESS PRIVATE, REPEATE AND IMPROVEMENT CANDIDATE

Page 4 of 8

<!-- page 9 -->

Step - 8: Fee Breakdown, Photo Upload & Application Saving







Review the calculated fee breakdown (Registration Fee: ₹60, Admission Fee: ₹400, Marks Card Fee:
₹80, Exam Fee: ₹400, CBC Exam Fee: ₹1020, Total: ₹1960).
Under 'Upload Recent Photo', click 'Choose File' and select candidate recent passport size photo.
Ensure photo size is between 20 KB to 80 KB in .jpg format only, then click 'Upload File'.
Click 'Save Application' to store all entered candidate information.
Click 'Print Slip' to generate a draft application summary slip for verification

Step - 9: Exam Center Selection & Mandatory Document Upload

 Select the District (e.g., TUMAKURU) and Taluka (e.g., KORATAGERE) where you wish to
appear for the examination.
 Under Document Upload list, attach Transfer Certificate from your last studied
school/college/institution in PDF format (100 KB - 500 KB) by clicking 'Choose File' -> 'Upload'.
 Upload Proof of Physically Challenged / Special Reservation UDID card or certificate from district
surgeon in PDF format (100 KB - 1 MB) if applicable.
 Click the 'View' button to confirm uploaded document legibility.
 Read the 'I HERE BY DECLARE THAT' self-declaration text thoroughly and check the declaration
box.

ONLINE APPLICATION PROCESS PRIVATE, REPEATE AND IMPROVEMENT CANDIDATE

Page 5 of 8

<!-- page 10 -->

Step - 10: Online Fee Payment Gateway Interface







Click 'Make Payment' from the top menu or redirect from tracker page.
Verify Application Number, Candidate Name, Total Fee Amount (₹1960), and Payment Status.
Select the 'Online Payment' radio button option.
Click the blue 'MAKE PAYMENT' button to launch the secure online payment gateway.
Complete payment using Net Banking, UPI, Credit Card, or Debit Card to generate payment
receipt.

Step - 11: Application Tracker & Progress Monitoring







Navigate to 'Track Application' tab to monitor application processing status.
Review the 5-Stage Tracker Bar:
1. Candidate Details (Green / Completed)
2. Documents (Green / Uploaded)
3. Payment (Pending / Paid)
4. Principal Review (Pending / Approved)
5. Final Approval
Check status details including Application No, Candidate Name, Verification Status, and
Remarks.
Once payment and verification stages progress, click the green 'DOWNLOAD' button at the bottom
to download your final application PDF.

ONLINE APPLICATION PROCESS PRIVATE, REPEATE AND IMPROVEMENT CANDIDATE

Page 6 of 8

<!-- page 11 -->

REGISTRATION FOR REPEATER/IMPROVEMENT
Step – 1 (Registration & Verification):
Enter Registration Number, select candidate record from search results (matching Candidate Name,
Last Attempted Year/Month, Mother Name), and complete phone OTP verification.

Step - 2 (Subject Selection Rules):


Option - A (2026 Improvement): Select YES/NO from dropdowns for passed subjects willing to
retake.



Option - B (2026 Repeaters): Failed subjects are automatically selected by system rule.



Option - C (2025 & Prior Batches): Failed subjects are automatically selected by system rule.

ONLINE APPLICATION PROCESS PRIVATE, REPEATE AND IMPROVEMENT CANDIDATE

Page 7 of 8

<!-- page 12 -->

Step - 3 (Photo Upload & Save):
Mobile number validation, passport photo upload (.jpg, 20 KB – 80 KB), and clicking Save
Application Details.

Steps - 4–10 (Payment & Final Steps):
Document uploads, online fee payment execution, and tracking application status to download the
final application PDF

ONLINE APPLICATION PROCESS PRIVATE, REPEATE AND IMPROVEMENT CANDIDATE

Page 8 of 8

<!-- page 13 -->
