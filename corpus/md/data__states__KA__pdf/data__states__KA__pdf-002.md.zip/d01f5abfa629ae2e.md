---
doc_id: "d01f5abfa629ae2e"
source_url: "https://ksiidc.karnataka.gov.in/uploads/Part%203024%20E_1787142555.pdf"
ministry: "Karnataka State Industrial and Infrastructure Development Corporation"
title: "6       2 months ago       Job Notification 1"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "46a587745b171a30"
---

<!-- page 1 -->

S TATE I N U ST RIAL A ND I N F RA S TRU TU RE
D EV E LO P M E N T c o RPORATION LIMITE D I K S I I D )

KAR

Q,.' IID C

.nr6f Karnat la ttrdertakinol

(A

c

No.49, 4rh Floor, Ea.l Winq, 'Khan[a Bhav
E{all: rnunhy.blidc@-g ail.

B6ng

Llmited (KSlr Dc)

Stata

the
tuncdoning
lnstituton of lire
lnlrallrlrclure ani Airlon prcjscls. Applicalions a.Einviled for lhe below menlioned Posls fto
st

080 222!8 131',.r32:133,

5 60 001

info@l(sll
a premiet lnfrastLlctur€
Ite io)plementalion of

e9

Ou.lifiqird d.l E P.rl.nc. D.biL

1. Gensl3l ,

fiechnical)
( I post)

Chlel Engineer/SuPedntende t Engineelf.om PWo, Iffigatqir DePt
Reld. Oiicers et he
&alhbr allied d6pt!. / Sht€ &vetnment Boar.ls & Corporatons / 8DA/ BBIIP (GBA) /6nart City
Co,poJation andAvhton SR&r

63

z

Retirsd oficers lrom lh8 PJ.Pods AUL\orii/ of lndia al lhe level cif DG[,l / Jaint Gl'|, G,\4 vilth
'h c-lnc€rned Engineeling {Civil / Elsclrical) along wiih AjrFort ndmirriralve

1,17,0a0/-

EducaUoial qualifl caf on:
. LL.B. delres lrom a recognized
I
. i.-ir.J'*ir, t'" e*c"u;"il or tntiia/sbL Ba. couidl.
lPrefereoi:e Y!' l bo cren t! candi!,atss Possessing highei lqsal qu:lii€ljons a{ld lelevant
expaienca.

Univeriry.

Exp€rl iEs:
Mirymurqq years of posl{laljficauon expea€nce as an rqocal6, ple Frably in h:andlin! na(als
r6lali,rEliJ:Gq/srrunonl De)arlrnotlsl Ptrblic S€clor Undedakjngs, Fnancial ksttdions. or
k,,rasliu:r:ure Proie.a.

Job Re3pon!lbilluo3
' Ora4 v;4 and rsylrv c:nlract!, agreement!, !.'loui, i€ass ds'ios, sals deeds, and oh€r legal
vaa.m€nE,
. har dl€ la.d relalBd lelElmaheru lnclLrd rg acqrisirion, lile v6lincaton, oisPl'li! encload,rEr.ls,

'35

and.rjrgaylL

.i/ari:a l:"n reovory proceedhqq a.bftaIrn, a]d !isP!r6. befolB jLdiciarquasi j.diial

)

.llhori.i3r.
.A;.,:s6 on hbour laws ard rcpresent lhs.CoD}aljon in ornploym.it I ,.i,tsldnl cjsptlca,
di!.jpllllJry procssdings, 6nd staE:cry @rn0|ance.
. Proyids leoal opinlons on .o.porats, co'rmerctl, property, conlralual, a d l4gulalory lsu6s
. C4crdin:te wilii snsrnal adl?oca&s, Governn,eill DePanmenb, and regulalqry au:hodtles.
. lronj{or llligalim and ens,,ro lmt;/ filir,! of plazdings, app.als. alfid. vilr, and bg.t n iic!:s.
. Assisl in le!6l au. diligsnce for ir',last"lclure and Induslrjal d" {.loPment ?rilocls.
. Undqnab any ott :. l€9Bl aliiglrnenis enfusled by th. coryorali.n.

Osik..l SElb
' Slrono daffhg and l€lal rcsB.rch capability.
' SC{d knowledg. ot Corhcr Lair, Prop6rty Law5, L,anour Laws, Arbitr.lisn. Civil Floc4!ut6,
manag.lidgalron ed ielivel prac$c.l legal so'ulions.
. Ei*{ve communi.alioo c c.crdinatioii Ekills.
. r.lility to Dddpdd€nw

'Gitduats i;r Cotumerce [. iranaElme it fronr a r6co! nizsd uilr'ersiv

Ex;cricncs:

(1 prsr)

. tutir6l Fin

&Ascounts Oticers ol Fin;n.jal lnslillIons (subslantre r"ik of DM (FeA)
'cs
r€tireJ ofr.ers rJ tjlDBl/ l{atJnalizrd Banks / NBFCS ofGor nr.t GoK s.alr

t

63

74,250t-

ii handlinp reccvery wo*
Edui!rirml qualifl c.don
:ndualc in any Lranci ofEnllnaeing tom a re.Jgn:zBd u,ive,sity
Exp.rienc.:

0 [o'ii)

. Patir€dlrlnlcgl Cflc9re cf Fir.andai listduUons / Sl0Bl/ a[ona:lzed

&nl6 / NBFC5 nt

.15 lo

,i'.

i5

752501- .

Gcldd.icK sial62 fld above ,
. t inl!,.:m 5

t Engin€r Edr.crti.rr,.l qurtltl..O"..:
5

(lPD:r)

(_)

{ ! p,rsr)

-t

/

I

Mf, ln Ciril li;gl.€e,ins (:tructJinl Engingori,rg l-iiahw,i/ Cr.ginE€nng /
Environm€nlal Engkien,,!rfrorn a ieiogn:ziod ixsiit4:on / sn ?rit7
H.Tech

E&.rloitcar
irrnrdir: u j",,r.,:a,Jan )

EnE:,,e8

(PD

2j

po.t)

at

f5,25nt-

I

0

l

{

' Barh€le/r degr€o in clvi Er.gina.. i .:, / Envlrj:,'il3nlal Englic€ri,g/ st Litr$al E%:ne;.tlg
or €(,.ri,L€ol frorn . rLcq;niii unlel'lti'/ Ills'iti:ucn
' l:islE d d.gr€. in Cir'i Eogines x 'g / Fnvirorxr.enu.l Ei,,rie.nri / SlrucurJ Euilr.: .rrlrJ
or sqL iril6rl fiom € oc.lnized unir3;Elb/ rnstit! lion
'
:,rd iilional 6nifica{o0e / vaining in Ela Erriranm6nlal lJaursBnenl S?sErir n. Frcjcd

I

---T-_'I

Illamger nert w:li atso bs 6. groir

E(pc.ion.e:
..l,,lir:iTrn 7 yl' ol €4sri6,iir ir' lranni,B, our's:upn.rir:. imflenEr,rrL:n, moniloring &
jm.nngsrosnl ot laE+6c.]la lnfrait,.rclL'rs
sr,c.h as iidrr.hal p$It, htelr.i.d

[ojci.3,

r)vnslps; $nrn.itie!. bl$'nes3 pi b. lngistb FiJs, S82.. or dher ir.3n i.tl3sliuclr5
Fi"jB.ti

. Mj';imurn 3 rrs 6yD6,l!nl€ ln eir[.nn6nlal iniraslrult!,a th,)ni:lg 6,::vJ:o?i;en:, uullti
prd.(t', ob',qining_ & mamgn\g shiuery a;rprorals, relubtcrv cJn:?lh.rcB; ci,/:r i- ro1..!rl
-E*inca,'nietl clea;.ra I enliron,motai mr'r i:c,1ng : Err)l;anc6 rnnr,aglr,.cid
.l,,yolveil.in pr6peiauo & rsviei/ of DPRS, EL( studigs,,El,iFr,

!

cDmp:i:ijs rcpod!a'olncrteo,n'el Ep.;ns
EvEiien-. h prolad i: pl€nr.,J.lj.n, monirodn:l, nrrg

tl

con p,i3, €6 lracklng and onviroinrentrl sef.guards.

I

Experi.n.r in coqtinatirg lrih G.vt. Oetts. eg!]ai;ry a, noa:ics, U,.Bs, crnsr{ar&;
aor,lrfi c!,ors, uulityagencias.a olher proj?.t slrkthnlders
. ia,iilkflry or r?orkrq klo ec
of r(ltljlory liam.iflorta & tiomdures oC Mo;; a9c,
SEIiA; sE/\c c PCB. KS lcB &R arla';ia roreet L'ept

I
I

ii
jl
l.__

Gen.r.l lft'.{qrJaiE:
1. Th, appohhsni3l tll haoaaconlracr bas;s Ior o oerial ofore {1)ye.r.The c:nrn,.Ln'r7 !e eriell63 L -J cn tn CrrPoradrn!
reqLir",nG{e ind bo caniidale's pafonnrncD.
i

ZihBnl}jeofselscljonshaUUebaseionLdur.tirralq,diricaliona,releveitexPeri,i.:,:nJpcilcr,,;r','ni]htsn'iJv4
3.lntrested cnEiiaes aro Lqurcq l. l!.l,m.l litr:r l.'.rm.s elonJ r.fl crt,-:, :{ edL'ai:on4 r,,'.[ce :' a,]l crf.rr:n.'
'ceni;bs, . ilr)er by SPeed Post cr i1 pe, !c n, rr ln e DetJv Gt,1.r:i I'i,r""ier i <r\,, (',1,:c. -r il,a .5r, Ji,rY,erl
.c., : | !.
'rndd
TLd aglli€tro- mu.i Ie5U1 ,ifin I i o.ys {rr,n h. aald. ,l Puijtradc r. r, tii. rl.ul:i ,lcr. Ti, } \ial r i .,i dme ct l,ie ;'1. relevr !/"i
bo

intnalcJ;la,rie7

4.Fcranyclanficalon;'Pica3econtactOipuiyGersralMa,raglritvinlireNe:9s15,1'l:'l).

S,U. Ex-c,,.iv" aiec:.r
