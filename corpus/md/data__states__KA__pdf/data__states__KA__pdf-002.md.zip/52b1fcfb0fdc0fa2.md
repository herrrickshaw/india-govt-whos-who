---
doc_id: "52b1fcfb0fdc0fa2"
source_url: "https://ashraya.karnataka.gov.in/Guidelines/2015-16AmbedkarGO.pdf"
ministry: "Rajiv Gandhi Housing Corporation Limited, Karnataka"
title: "ಡಾ. ಬಿ.ಆರ್. ಅಂಬೇಡ್ಕರ್ ನಿವಾಸ ಯೋಜನೆ (ಸರ್ಕಾರಿ ಆದೇಶ) 2015-16"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8475c4d447923ed9"
---

<!-- page 1 -->

;)cdal):

si>;& jSrttJ g,de2}d

s±,5b dDSsg dortdd

sSrtrcJ sisj3 dfcstfort 5S;;J3(xbfto^ tfastod ;^a)S3DA
"C5311 tS.WD*. «?od?{|CJ'

oiwtsdcjjsb, aFt)«®fi/l;ac:4)d

t>j^.
Ldcjsnd:

1. 2015-1653? wcsbd^ccbd jpasSfcid Sdrozs

'atJDa5cdj tfoQS-I88d<gti

2. sa;^3 TSCs^aii dd?3oS> «dfd ?joa3^-s{'a 67

2015. dorti^^adj.

0?5SO^:16.n.201S.

dsed bdoad

?3oa3^(l)d^ 2015-1653? tsqC^ woiisJoicJ ^aadreci 73stea

-scBaJoi) ^oS5-l88dd d? ^dSodo^ ^IraesSri ESraQcbSDd

"fidedpi ^oOdjd cdossj eaad cS>5b
cddAd| ;3eod s3;!J3
d!od lod ^uiouri^rt - r^socra ^?drtd^ 1.00,000 Eidrtdcfe ^3
dJdab

532^ 1.50 dj5)

rfrtd ^edrtdO so.ooort^fi,

^ s35?J

d2^ d;3.i.80

ds!3 -aCTsdoii sioaroodd

aia>r::3ot)rt55j)Ct>. sbdrt^ SisiraFred drarar 532^s3<S^ sicSFdde ^,o;^5dd."
wddog -roil o.at/.eodec^D' ^^tS" oiraeeadoiFa.

di

03jj.?s5daj3a rT&A>fre ^rfedf fDrtOda^SOTd j.oo.ooo
^ djd 3p>uiJ dd cteiso
o^rtd5 d5^ drtd ^ded^ »rtQsJa?iw)d so.ooo da^rivrt ^3 djd
dd dj^Vso
desFdd

■^.d.oc.oodedo' fjsosl- olseasJai)?^

d^^?;aAd. d,

ad55S3ji«3/ 5}sddSc>d drortrd^d ^.rfdSA. Wee
aB.?. ac^^a'
o3;5eaSoi>s,
u/ioStS^ g,

ddfssdJsoeotoA «5S33^rt«>W?» 5;tofS:W?i «o3^oi> wrt d?TOrtdf
d02350i>3' TOSS' 'STOaSoSod d.oda5S«3d
5Ja53a&5i. aooddcb(dS3
oi/sfKdrt
dd3 -sosjSotoodd? die«3 Lds^sd ^o^(2)dod S3ri,3

rfrid y,d?dd doB^ 2333 d35& d&35g dortdd d;!{3 dfadOTi ds33oasx isa^d sltosraA
^tfAdod ed?2i ^dftTJco ^fsters^iosAd.

xisardd «dg£i :^o4-d.a 67

2P1S. dortti^cb. ag3Q^:ifin 7m^

i,c3/ato6 r^ecD stosb fj^d ^d?dd dbBd s^a

arioda^jc.'pd 1.00.000 dadri^rt ^3 d)E3

rtra.1.50

did: drid

J

driOda^^d 50.000 dDdri<>rt ^ did
d^ djD.1.80 «^ri5?''d53rddV---W_
d, 03j3?K5J<xbd3^ »ci.^d7^?'d<i» ;^era ^?dd i
JdDF^s^A ci/3.J500
dj;^ fjrfd gdcdd 50.000 d^dA^ ddss/

&ert
d;a.2400 d/3fWrt^ OcdDSdddq. ^d dbsb dijodd
wod^^oidfi (2015-16, 2016-17 d5;& 2017-18) t^dAslsAj^d^. "

<!-- page 2 -->

20J5-16e3e

siJdrcJO tj;«d asiS oio.'tsrf «3^ bSiF-S 2216-03-104-0-01 da

ao5^ £5&5 waoiof23a
^JDea' 422 do. 981.75 dj&eW
yvaoioeasf3oi>a <52^5^ S/dccs' 423 dd do. 545.30 io?Urid?toj

aeic^ aortSddi waSradddJ^

tsd^ ^23* 422fiQ do.300.00 iOfUddrf5^
Sjsea' 423 da do.I50.00
iojWrtVfi^ &crt e-t3^ do.450.00 iofUrtdSi^ 2216-03-104-0-03
&?i!iF-^Diia
L.dAdW)f^d.

sastoSi

£53710

S35 warira5-20lld

acocg^oi) ddo dsnsTldf

25ci)7ldotond2,» d« 7JO:e|pd5 ddacxbdd eo4-«odr1d did) dro&Scdi eqradd died

T^ets did drid ^dedrtdd if?3^ di?5rfv'd^ sdooOdid, edr d;;sa dbddd^ 7t)c!i5A,
aad d^3 oiofE3j3oSi a«>fS3^27^dd^ eoS^ sloidd Seaasft
?5£jiScdd^
ddsJcond.

;^i5SFdQod ?iriada;!Scod t^otI

sadinao odtd, fjed^di,

acoddi>d'?od di^ Rdrorre. na^odsldca, esixos* sod ddcdaj^di, «eJitro3 adrtd

<aao^o dco ^oSirtdd^ das "aoadcOiod dJads^Jcod *d3?3* oou adi^ d33rtr;!ioj3o33d

?)fadid sdeFd«i7ld«d^

aroO;!Joi A9A)d. jeado di cd/srcsFJr^ Klrordd £oo3

doriFdadoSi Qc33o^:l6in.20l5d^ sdadBJSoaAd.

di esdtddooons odw^dd RfQdid TocaFdd steTlFdadrid ^"3< dai^-dd

£301 o.ecF. yodec^D' saaS oiofd^ri dia^ ©^ccuddd. ooa^ aesFdd Ini^d d;!Ji
oioee(3rt9rt diidod ;!radSod w^ddd.
di oioejscS edas^l desadd
ddooddrtVd^ tJ^idajJoi daa qCTaSotood sosi w>o^ Mdfd egjadajjeiojddd.
di difs^od tsodris^di^ rtdidd^t^«;aodD d?j5 oSjaeesdcdd^ dorsadisaocdofi
«7£)5^7UjWoi^^^d^doi «d«&7id.

di wdedddi^ e{?JFiS -acoaSali ddc3 ;!joa3^w'a 497 dz^-9/20I5 O<30O5{:16.11.2015d
;!33pdiA difdrt djatia^ooAd.

5^?5aFU?J ooe^siasid wea^sad :dj3l)
edd dsJ&d®,
djadiFJf)

rJoOFdd eQfd BocdiFdfiF,
d;^S «q4;Da5.

1. gjpod diaradijaisrawdi, ScroFUii, dorttfodii

2. ;4BaFcjci tsdd sfcod)^ 80o±iFdSFri?b, drtoa^s^ "siOTd.
3. jjsardd dpod TOoSiFdSF, r^diffsatpd^c^ d53b doaaccbs' Dots' <aTOa5.

4. 3j50F£Jd gt?as BocdiFdSFrttfi. fcod3<'d drtFrit" gco^ <30335
5. diOFdd BoodrdSr, dstoa So^ca <90033.

6. StoFdd BooiiFdSr, oJ/aftsFra "good, UEddidQ tfud, doTttfjacb.

7. Tivorrid 8ooS)Fd&F(d5d?it?rftt),tbib d&cod«^) Srtra^hd^c^ <aoaa3. dsapj sa^j.
. 8. ;;ltroFdd ddfd sacdiFdSF, dorfojcxb d^ddadrttt) sia saS-S OdFja <soo35.

9. ilaoFdd odd eaoJj'FdSF. Badosb, jj^cxb di» drorfsj* d&irtV -goad.

10. SsoFdd BacdiFdAFrtW. o^oii^dd tloo^, j/b'd)^ ds'" <aooa5.
•P

<!-- page 3 -->

11.

oBtSess' naoO n^«re SS5 ?ifisi3

23ort^a&.

12. SeSrodfflfdtfds, siESjBb jJot^ 'aOTaJ.

13. d^EjTj^as ?)c3cF3Sd3. iSirorui. ewlos^

aoi>ii5^

14. iJtSD
ZSOTOffBOrtsSj.
M
* f*•

15. ocro sJcraslotJBcdss' sSmsD^ saoiFfjarSRaOireDrtvb.
16. oeg crasj
17. £)cro 3a«lffi& EJOKroc0>3 V3C335FS5Jr«SEK)0530rtS<). .

qjizJcs? naop

>

18. i)eg sscio&rttf ^aJScu^Cdslcb,
19. C)cg ES»a3B^oe30rt«to, aJt^ sJoMocto,

n^eto d;i3 S>rts£>ci
s&o^o3d

20. £>c^ Srtd;Jj;5 eoSo^dj.

21. 2!BS3B dv^zi:i/SBti^b ^3.
^3 »to&Sn9Ar

1. sJtof^

raoirdfir,

sSortcUcb.

2. ste:?^ ?3So«r5Be3jC^ ii!& doa&oJ)3' msf Stldd od ro«bFd3r, £3{?3fi
dort^A«)Cl).

3. 5S33^ ro5lJBc» fSD^CCiJ. SiOSlOfOi) Ej^JEBdrtdj. SBdfj drffj "EBTOb djfo^ortjBSdcJ 5i>d5
■*

sSo!3D30to ddsJd

4.

EaobFdfir, fflipijJ :"5®5j.
5}d3 dddd ttd TOcdM?d&r»,c5i?Bt3;5«'d, dortvljacb.

5.
sJrtoB^djC^ Tlddd
TOoasFdiF, OroS
6. d335^ ;>3djD63
SBrto 5?oci>Cd drtrrttf tiOaro «aOTa3 suad «a BBoSiFdfir, oroa
dortU«d5.

7. aBDFdd a»a3^ 5aoS)FaiFoj>ad

_

"*

roafardSr (add aosbw) ^sdcB dbaJj a:4l9/20l5.

cBgBd a^>d. dodvOxi).

8. afBFdd epjs TOotordAF, «aF^ <3^35 (dj^9), daBa^Jd. doridjBcb.
9. arordd ^psa TOcdsFdiFotdd
10.auoFdd wd eDoSrdSFcdJdd
11.roajD d?^ gdd^.

TOOdrdsr. dda -acroaj. awa^^d. dortvtiBdj,
asBdbS, da3 <30253. droaa^d. dorttf^jd)

,3

<!-- page 4 -->

gfdggi 7ios32?i<si 61

c^SjS "Sl^OSiiSCijj 5i»S330:^d

2015. dor<«K05d:> agrao^:16.11.2015g.

d?J3 c3j5)CS3c3oi>a «)c!iDSJ3?j7lra9?^3cb3:i T^JtoCtS
cSjscas^rts^ sirartrsiraeS.

osjoi):

'5c;s>a3oi 5S»503035d

5J?JO cdfije&scJrttfa

j52Sir?5OTrt)3 sSitSrt^cto^ 2oO&3€ eSto^SjsS 7jOt>o?;J

c;5?;a^{^artV wo3^ ^05fc> sSjorirslrosaoJjFt)^ ^^a;!S3sJ

EiS<S "soaaSoSi s5»a:ao^d so:? cd?j5 oioftseSrtv'a
«rt)3cbO otfow

mo3^ sterf^sfd

;!)03Ja;!3co ^ 6'?ho;5 stortF^ioao&cis^ ^darfwAcJ.

ffisrlfi) tj{?rd £ss^ ftsrfriR!5-20iid sSrofaS TSo^aJci, r^s±t sJot330tori«?rt dsJSc?

stroS. rro^ cSoasotort^orf «52dF^ uf^ ziObtCk, ^crofSD^Srtd wo5^ SocScbS, oc|j3 SDrtro
dtn3rt23? r^Oiffsatps?^^ s3d;& sdow&atos' cots' fstuosdccood ocJsdOi^cod ESOrt^A
fcoadcb ^7iA '^6i>sd<£oozS6i sS?J^3 oi«?aic3n&A ssor^d
d24A TJOoSctb as5so?5^er[^
A^Psicsond^. eiro^rt d< ^dAcj «odriy?i)^ wdsJaA^jo^o) -S^Jooond.
1. DoafE? rrao?> nopseco drfS artd> ocxbSids^

do^oabs'Dots'

•soodotood jjosijosji sb:& «{prs# :s?JriraA-20lld xJ05f|o±i d?}3d&>dd sSroJododsbj^
ddcto sera
oi/ofBcSrttfO »dF ^oOfbd'^Atfsbj^ tsoS^ dsodeo sdJoeooA
w5doira?n;^4cS52.

sorbo

a®5 »ddE93-201ld ?JOdi?|^ (S.E.C.C.)cd5^ dinodd? nopsera

^fdd(3 n^isti doaootosrado so.rtjo ?irid. ^dfddd drtd ;^^?:ob ?3o;^s5od5
d?JSd&>dd. ;^ddBd d:^5
d^ooddd d3ofclo4>?j3^ Tioj^iaTii^hzSy tScSO
SiOdarar d3ofa5oS3ci>j rodf63«rrooO "r^cto dS.5 ortsid
^tfUsb^cb.
3. sraEbod^ sortio «^Fii aoS B5Jrira3-20nd
(S.E.CC.jodd dorJfeStdid d?3.&
d&dd ^oopi):?SSDd3 si5o&),3bd>rf3^ aerassods, socxra&sjodj : eeoTta
dotsooKSJodj s^oAA A.Q dwocjii sera dcraQsoSritfrt esorta dcra dp^^ods'd

sSosO^ eoodradrdEsa^soeri^rt DodfEfrtoo^ n^fre dd3 OrtsbQod

4. fcer! ?sed5;od sfaoSaAlsiJeb^ drtd ^edrtdd dcrapffoort^to ^rta TO^jfco
sSoa^^eoccbFOdrdfsoOsoOdds douo:?33fc^
dotsool^rtd ;^9eab do;|d«'rt

ds5oorf>djd5. Sjd5

Boto n^' doaooi>.3 esorta ?Sr{d ^'ffcxb

dsb^O Bs^^cbd <E3c'F 50&o3aoprt daooorS^ siraa^v^j-^jdo.

,.

5. ;!Jdo sS3ois3oifb^ r^Cotvs ^?dris^d no^ doaood^ri"^ Esarta drtd ^dedrttfd
drid ;^«?eai) do;|d^
d:d537ferad sera ddSd&ddb dd3 o3aeac3ri«;?
sSjorlrdadJidod edFddad

dDSeSdss^cb.

1 i

<!-- page 5 -->

6. oai;J s3;!JS cdJSPKpSrttfa ii7S3

sJdojsto cpzjfcadcS) ^

e^SoF^absb^

^l^DdsSfS).

• wzSrasdd. <S5B50w«^ ei?j3d!odoc^ rosiFtaSiJ

sro^i^SD^cbsldcb. rtsQrfco

ooAirt^. 335^(i)^ ^n', A^orirooci sS5^ wi^sja

-5S)A);i)3d^ 300

4j?1?

?Jd;i^5bb5J &U50tirt?b,

'awdoi ZjOcS) SjafcScto^jd 4^od

o:3Fcrod^ er;J533 S)l35owc} oSros^de

5u;:jejd^ tf^FU^d o±©5ScJe ^jartdg

^0^ oSjjJcdSpto^ sdytioOdoBddi.
• »23rc3t)dd ssaAiFi tjoaoa r^eca

dj3.32000rt«Ao^ ffads srort/s sJrtd

ddfdrt<»i£i dj3.87600r{'9Aod tfadi *9ddfS).

ejSFDSidcb

sS)&>TO

c?lu5?i)d^>rtvaAddfcfct.

add

drots

cdjscd^.

v)i?5dcb.

aorto^ocb sb;^ feooij pj^rtDsiDtJAii^ifi aSscbdd^ ?Jd adroaAcbstd.

adFcrotidj ;^od ?>s3edeS s^oOdJ^, Sdedf^l ^ouoQAidod 5aad :^o6dd?ib
(rododo^, adcsj
rao^oi^ccb dcg ;^ao5oD3od J)eddad'
ddO?^<g

dJ33 i^ioi>r dd^ca doridTSu^aaAd.) ?uOd3 d?d ajarcjadcb ^od
S)ded5Jdc4>j eiraoO^^d:

d^do) fJdfdS oiraeescSA^S cidedrf 53eS ?5o;^d

dsia oi/a?&}f3rtdS dOrtr&zSoartjd)^» ded otos^de oirafssd/^caa^odod dinartcJc duJ^

adF^odelJ^ dOA.JdA, ?J5xic^o4>3 rticb^^joad
djaoOcbd
c3asC!dri"SjaoOrt des?dA,

ddodoadda. ddo

^JdasSid^^rtisb adFdrttfd^
do;^rt«b naaOOetfdradSj^

cSdd^di^s^da*

7. iafsJoaA: dd3 'sjoaaScda d»5oaodd aSis^c3rtja«>sbd aad dda cdoeweJcdja
£a«S)oaS tS>d5 tjtfo:?doa5 d< §s?Sodo3d:

oaa^ dffDFdd stasSjac^ dd3 cdraeBc^rttfa;
drtF

drtd fioeacfsd

do3^ daS
d03e^ doAd

30S

«d ?joaja.303

lUSi

sasjjaji^

5096

w

6

loss

aai o.ao'.aodft^cj' asasJ oirofaSoia:
dAF

d?6d ioeAaai

dofis^ Z3a3

/OSS

d03^ doAd

3UK

<!-- page 6 -->

sSBt^ !s33, dsiij aortij, eu sioTO/dJ erorto ;raao!i4, drtrrtda Si
Sdioaog
5»??JtK)30d5Sb^
Ortr

'

—

eij;>c3 SjcOodD

seas 6.«i ^33«jis;33
10»
5%

cJBfsj snra

juoabnTOo

8096

afdoa;^!. ot?d, don^

5^

iraOl>F^^FCC&ti3 <335.0.
0

acddcvsd «d^35^
do4

tfc^ drtr
I

dsj3fi,e?3d3. (?3t>dFSJS^

cro5*;433clbddd>)

2

rt>a;4e»a5^>rtd5.

3

sn^Ci dc3*rttf^ EroA;03cbd5Jcb.

4

^qjortjDod 5t)j3ri?fC
ssDAtsb^dsdsSdj
n
j.

5

tf23asi)j3ri^d 53«)A^3d5ddcb.

oc^-l
«cid-2
6

8.

gdrtrtdS

odj3-3

ec^^S

BoSjotod E>,to drtd gd!J!rttfa drid dWcS)

.o^rt«od BoSjctod ddldfcdd Eirtro sdtdsawd Bdr dwdodOrid Boi Aid,
J ii?5jod Bd^drtd djtdrt idBoton BdF gtoisbdarid Boij duciisd, doad aJ?

d!dl*^°r' ""

=s°toodjSai

A

'■ idLdJf
SOfs'rtVg fSrid tJdpi)
10. n^efs

sioaeo^cxb RoajFFJiSr^KsOsaorts^j daoa

sJowsotor^^od

11. ;^l53rdOoci m artO: ^5 ddr oatd^oidfl itisard^ ariQsjQsbd rtiO;^ ijciioDA roSfis'
TOoo
d?i4 artsSjsJj 33wg2bsjacS) sjasteds^ csart^) o^rS isa^ aSrtro3-201l

Ttdj^wuad d;J5d&dd ?ioa3^ esbrtresiDh rboccbfi^ artOdasbc^cb.

12. 53anzbrod5 ariodaxid tp&n rtpA ad^usn tiHxi ^edrtdo "fSrid o2io±,

^fra ^dridg

£3^0

rfsIS ^9^530^0^ dsirfrad csart d 5^35 edcd riorf-

sS'g 67 aSta'^^es' 2015 Ojroo^;i6.n.20l5dog ^ 3^?bE§d>.

^

(sides' d3QS±iJ5')
^5^Fdd eo:d saoi>FdSF-2
^ dsjS "SOTaJ

<!-- page 7 -->

?}gsrcid sjdsjtfrt'A

Oedoii: sJsjS «SOT53oi> 5ii5a330^d £)at;J s5S3 o3j»ecs?3rt^'a

ti&DFTivsJtzi s±>t3r1tffi>^ 2^023^ si33£S)£j ;;Jouoqi

^icrosb^ortv" woS^rt K«>7|jS
2015-16(3? «<xb53^oS)cJ ^sSrad ;*j53roB ticro^ 'SivosdaSi SoQS-ISScJd

555ee3 Lc{c!t>:3 .^sSisoj^dO 2015-16f3c ?33dc3 wotd^cdad Jijsdrad Sdsaw
iJcRp :'9c;c>a3oS) Soa3-I88bd ^

s;S;3cdei sSradooftd

"jade^d sdraoOcbd d&S^ zroa d55b

;3cOd dda

dfiai wd S)i»oi3rt9rt - r^ere ^cjfrtv'g 1.00,000 sSdrt^'cd^ ga
sfodoi: ^iiiS d{^ i.SO 6it
sarlra drid gd.fdritfg SO.OOOrt^Jcd^
^a sdd

dt^ 1.80 dra

"Sossacds sSosroodd

5aaaF?ic;Drt)?5c±). sb?3rt5? adrorrad djurer ds^dsb^ dssrdd? dosb^d."

eddoi ta3.a.«D'.»odei:|D^ jasras' o3ji.ea^'o±>5b^ oicb5s^rtjaf?Jto
eoJ^oto ui^ jsart® d«3 •ac'aaJoKsod wSbss^drt/s^Tbacbd r^scera dsja oiroeesdrt«?rt

e^o±iS39rt)dod zssr^S dajacdsdj^ ddA. «dcd 2^da?i«i aesderjadCTAc^, .«ddoi di
edfddda^ aoJsdQAd.

^Jffsrdd «dcd dod^d-isi 67 dta^dadyf 2015, i3ort«;(;5i±>, ac3&o^:i6.U.2015

T^m ^dedridd d;^!^ oiraessdrtd Wcii^dff^n ^
asK^d sJccsSoici^ d83;3c7DAt3.
^SpTbd Qdsd

I.

;!ld;^cb

di 8dAc3od
etj^da

2.

?3owopw5 (dpad sJdage^a {saSroncbd ddsd dodas Sd;«^cb

trosad^iS*

3.

^sardood otsSj aderas t,t^ «cra Sossao^s' «d;^cb
aeardDod crods Sdrrsa lit^ sawiAfc dotsaods* ;i3ds^d5
?iF3Fdood coodi adcpad sJossj jsaa, dos^ dorts. wo doooad,
&»od}9d drir sadja siatSas^ drtrd sld/^cb. ;4dO ocb aada

?Jd;^cb

4.
5

ad«F5^
6.

da&jtfateAdd^dj,

saogtSj djs^d dsbacj

Sd;^cb
S3CS> dads acJjFSS

dd^cb

qoadod wQirao / d06t^ sJoddd

dd;^cb

xouoj;^ di^ saog^ dd4co|p'
ntiT^ TOodrdsrod sasiaaso^ dadSsdSJ^ SdadTlzpa 8cdd sra^i^

dd;^cb

So^roapsao
7.
8.

ucbd "gSd
9.

sJoaaoia saoSjFSisjaFdi «OffaO

?5d«.cb
4

dt^aS .^tpa 8?^d tsA dub ^artdda^ g^apTbd 3:aag«5J saooa

ddX^

doisaoSsi aaoSiFdsbardS tjpK)©

aaoird^Frt^b

<!-- page 8 -->

cryea - f

.

•Cp(^CJs:C332rg2Cpi!(a ^CpO??p2 %Oft ji^{3^J!5£GOffe vopcjsfl ^^ypOPfJGCJ2 (5»g:'pR
'f-eftfiacc? (ajcuopjodojj) ueamcycpjc^

• pcp^^y|;oji cjx»36^ uecgoecjs^ pocco?!p! %pfl ^ycsfScfiJcos^

iiiycj^^cpjGOffe

peopiQGCfOf:

pofey'^oji: cyoja*^ »eccfi g^GS3„ (peoypp poccofcofle, eyp) ff(%yp3g^ ej^cc'Si eryes
cpspfl pyp„ 9^yg3p^ pyfi ueQCpc yocy g?(^ p'^repsoy^G cpecc^Sxics
•cp^i^ippi
cp0f5^irep2?ea

-y(ftyC^iC{2GOffe

GJSir5J?0p

l^S^ffQCp^f

pfpcnp qsypascrjc^ ya^ogpt
poc?

j^rafei iergopysQOQGS

yeiscj2R qr^jopoea cpo'^pyocrssjyGcp ^^cp cpydpecpcpocj (xi)
•cp<^cp9.(2 ppjjpcs
yjspJCposa- ^{s:pjs: gopq^c^p CPs'?
5^Qoc;Vg\/?i G£2p« p^QocrygQoc^ ccpoej^ ©^ygsniarpo S"f2;p (Ul'^)
■gc?cy8Jpc2 ^cpisypeiijqoce/^p crapcecrcp g-^yas
cgQC^ ejjacpcJ pep yi^yp|?2cpcnp pcycqs^oo ©fsypajcrjo ?yp (ha)
•cp?2qifpcrp yj?pjcpoefl^pp ccjcpop?
eryea
ppat^ ygccp -^<3 cpog'^pjft ^yQefl^^pJ cqpqjqq? cpscc^
yyep? ^erp
pjjccya Qaapp GG;»ia cp^scpccp cypeife?
Kspap' eeQ'e;T3ocp pacrcp fiyoGspasp ^cppicpa oaflpp pcppjftes

yoccpojd^ aajiyp'^ ^cppjcpo?^ 5'p£P pc^pppspcs yop^PP^P^PG 0'^)
•cp^scpeep

|3jp'jb5) |cpycj ^cpcp>Qcy ppofl

prac'pcj cpypjftcpeQp

jp^s , ppypp ^jfop/jg-esz

opp

cpo"?

•cpi^cpacp <?ojGJC3 ecpp ctsyccoJeup ^cpcpoQcy yftyg'cpoeKop q^

ppSi. pcpn eqxiVea
3pin ^cpcpogcy peeipJCJ yg'qocaop
s
qsyp^cpecsp '^GcpuK/pWojiosi/ppyop ?s«.qe2/&gh
^?QP jp<a ueoqac? ygcy pirepoy^ cpmqi^GS ppopjeay

(a)

•qai^cpeep

"^pei^ yop^ppoao^ gop^^iefgcpyg q^ paqa pp'npfioraPfi: eecp

ffcsp '^fc^ py^« tQ^»% ^cptiy^ift 'Spop cqjpcssp qsycperp pce(? (aj)
^q2(?£qj;QSg ^PP^

ppocqs pftfep%2p poQjyp /jyp^ spft p^cpo'pp scrfopeocry'^pp
q3f2p

popjyp/jyp^

pcpo

ff(?o?e£2

G3pea

qspo

p'?3Q3y qspp pq2Qjpp« ^cpo?ip pfyojopqjfi ^pqsfaw pip qac^ (in)
■cp^qsg^yop qaoppiga pgocqa ffqp?ip fsrffiSQP
ppppo«
p'^i^hp gtqs>np
'%2©pjiOGq^
ye££e3cycpygjp«

(0

■qatfscyoicrpqSfl 'sr(?i9Qp2 GspfiJgp icrgoptj cyea geocPi^s "cifsjisoaopd
^^ycffijqseofh _ip« "oftpiaiarpqaa vqa^op '(yQjb^ecicsoeescqs
pnOE-?^yfS« g-2sa
cryaa ^szecpoa

(it)

cpyp pppcpQjpes pqio'np ae^ft cjPdzp C5^ ^vi?2 qaoT

tpeopUA? ^ qjyQeaecn cpseccp: p'y'is

<!-- page 9 -->

Ml

&

n

a

bt

8

&

y

&

y
a.

<f

a
•o

"a

"9 "n

kvU-l

a

C1

CT C O

Vf

&

w a^§

21

<a

&

a^

o
a.

i
a

a ;

a

it

o

^

p d e ^ & i3

O

a

8-lSI- auS- aI
ej a a g
Ig<P

to 3

a.
a.

a

a §

&

fe.

&

o
31.

a

oc

s:

"9-

. ww

" ' iti

r s

X it. O -9 T
n a a a. - ■n

DM

•n

a a

iJt4i:: iiII.

o

a
'k ct

& n a

ct
K S

a

a a

at.

a

to

a a a a a a a a a

3

tC

vi ^ w

a a a. a ct. d. g.

■n "n ^

8- &9

f*.

•

"fi sasaasssa

ci it

a a

O • ' *

it-a j±i<.2iiia.K2iita.

■o « a
CM.

OL

n-t|
a

§ &

w to

o
3(.

a

a

2

y

a

C9

a

& «i

&

B)

d a ^

to o

a
a or

a. it

a

it

3®

a
CP
a

s-

y-

<2

fi
la

a

eSL

a

a

•n •n
a

S!- a

a a

<»

»

&

zL ^ e. a

||»l

p, O a 2?

3t« (2 o S9

5■ Sa

n a ST a

t

iS|l

!PI

33G|a,
•n
?>

Jlll

a a 4 2^

a
g
X ^
g (a S- §
9-

oO.
& Ca

& a

a G a a g
to

3<i
8
3t j
& a
a-

S §

tsi
»«

a

a

11
2p aIII
a°^ 61.

<«•

:3&

3 a

& g- a a

a

■a.

"9 ^

^§2

^CT a

a

li""^

a§ «i
i|8l

a io'^o a

2>

t '„ a

„

3 s-

lal"-

u "C.

V

^^3slt

a o 21, y

S" a ^ a

a ^ rt ®

ill

3-

tPf|

a a

I /. S °

€K ^O 8 ^
3. d
2
a

ot

<j>

<!-- page 10 -->

<?»

9

oo

dpc

a

CS.

a
(S>

a
C9

La

a.

a

a

OL

a

19.

a

=l

a

21.

8

a.

a

•CL

a

S Ej

vc

a tra
S"

& &

la

c.

a.

&

ojU.

o

^3

\o

a

u

a

IH.

ta

a
a

a.

c

a

La

a
a

&

es»

a

La

CL

ft.

a

B>

a

21

a

»

a

§.

ta

a

a

21

a

a

%

8

3.

a

a -n

21

&i

a

21

a

&

21

&

a

21

a

□.

21

&

&

54

Q!»

&I

II ^

=i

a

a

a

a

21

g .a

21

SI

8*

I

&•

ta

a

•n

a

&
•n

a

fl

&

ta

a

a

21

K

&

a.

a

-a

9 ^

o

a

& 3

iP

•5 ^

c"- «3.

IJ

0-^ «

to

^^

-P-

a R- JA ^ u

3 5 3
a

&
a a
o

8-

c»

a

& S

a a

a a a

a

0\

IS s

-«
-n-n a -n
■n
a a a ZL

3

21

\0

O •

N-

3

9

ft*

s
e-

ta •

.§

§

o

&

a

8

a

o

3

a
■o

a

i

22

&

3

a

a

&3

a aI

I

^ ~ .fc

sii'^ii
.4?|ii'
ft

i3 a 8 P g a3§

a 38 3S jS sS jS ^

g e» D & D t. &

r- p
