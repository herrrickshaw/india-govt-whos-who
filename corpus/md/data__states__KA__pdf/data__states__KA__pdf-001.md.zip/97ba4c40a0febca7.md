---
doc_id: "97ba4c40a0febca7"
source_url: "https://ksdneb.org/images/Calendar%20of%20events%20for%202026-2027.pdf"
ministry: "Karnataka State Diploma in Nursing Examination Board, Karnataka"
title: "Notification for Calendar of Events for Admission of GNM Course the academic year 2026-2027."
date: ""
pages: 1
method: "tesseract:kan+eng"
script: "LATIN"
needs_ocr: false
sha1: "f124ff30faf53eaa"
---

<!-- page 1 -->

tN
Eee EA
(ಆ) ಕರ್ನಾಟಕ ರಾಜ್ಯ ಶುಶ್ರೂಷಾ ಪರೀಕ್ಷಾ ಮಂಡಳಿ, ಬೆಂಗಳೂರು
ಕ್‌ KARNATAKA STATE DIPLOMA IN NURSING EXAMINATION BOARD
1" Floor, Library Block, Bangalore Medical College & Research Institute Campus, Bengaluru-02,
Ph: 080-26700074, 26700075 Email: ksdneb@gmail.com, Web: www.ksdneb.ora
KSDNEB/EST/ 09 / 2026-27 2816: 21-04-2026
Notification
CALENDAR OF EVENTS FOR ADMISSION OF GNM COURSE THE ACADEMIC
YEAR-2026-27 IS HERE BY NOTIFIED AS FOLLOWS
SINo Description of the events |... 50660]
Issuing the Marks Cards and Certificates of Jan-2026 Annual
Examination and Revaluation. Calling ೩0010810೧5 1೦೯ |
Supplementary Examination and conducting examination for the
| same. Announcement of results of Supplementary Examination and 2
1. inviting applications for Revaluation and Photocopy and | April-May-2026
Announcement of results of Revaluation. Collection of Institution
Renewal Fees, issue of Calendar of Events for 2026-27.
| [|
Inviting application for 2026-27 academic 1* Year GNM Course.
2. Verification of Online applied GNM Counselling applications. May June.2026
3. | Counseling for 1*' Year GNM admission of Govt Quota seats July-August-2026 |
Announcement of Time Table a inviting Application for annual
examination for all the years 1* 2™ and 3 year. Submission of |
4 Internal Assessment marks & Mental Health Practical and | SePtember-October-2026 |
Verification of applications |
Conducting GNM Annual Examination coding work and evaluation of
theory papers. Announcement of results of Annual Examination and
5. | inviting applications for Revaluation and Photocopy and | November-December-2026
Announcement of results of Revaluation. Collecting the original
documents of 2026-27 academic year students.
Issuing the Marks Cards and Certificates of 2026 Annual
Examination passed students. Announcement of Time Table &
| 6, | Calling application for Supplementary examination. Jan-2027
| Verification of 2026-27 academic 1*' Year GNM Original Documents
| & issuing the register number for approved students.
Conducting Supplementary Examination. Coding work, Evaluation of
Supplementary Examination Theory papers and announcement of ಚ ತ
7. the results for the same and calling applications for Revaluation and Bebruary-March-2027
photocopy. Announcement of results of Revaluation
Circulars will be issued for any changes in the Calendar of Events and pther academic matters with the
permission of Chairman, KSDNEB, Bengaluru. \
\ ಗ (2
AN
ec Specral Officer
KSDNEB, Bengaliitu2t!4y)>4 KNPSBRA, Bengaluru
Director of Medical Education and
Chairman KSDNEB, Bengaluru
