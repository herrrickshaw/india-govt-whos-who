---
doc_id: "1d0be2bbb9fe30a4"
source_url: "https://hfwcom.karnataka.gov.in/uploads/Recruitment%20notification%20from%20NHM_1781765393.pdf"
ministry: "Commissionerate of Health & Family Welfare Service, Karnataka"
title: "13     4 months ago      ರಾಷ್ಟ್ರೀಯ ಆರೋಗ್ಯ ಅಭಿಯಾನದಡಿ ನೇಮಕಾತಿ ಪ್ರಕಟಣೆ - ಅರ್ಜಿ ಸಲ್ಲಿಸುವ ಕೊನೆಯ ದಿನಾಂಕವನ್ನು 22/07/2026 ರವರೆಗೆ ವಿಸ್ತರಿಸಲಾಗಿದೆ."
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "516ac7165955c9c2"
---

<!-- page 1 -->

GOVERNMENT OF KARNATAKA

National Health Mission
Karnataka State Health & Family Welfare Society
Arogya Soudha, Ist Floor, West Wing, Magadi Road,
Bangaluru-560023

No: NHM/SPMU/HR/Recruitment-State/Notification/50/2026-27(E-2075738)

Date: 16/06/2026

RECRUITMENT NOTIFICATION UNDER NATIONAL HEALTH MISSION
The Karnataka State Health & Family Welfare Society invites eligible candidates for the various vacant
posts under National Health Mission. The posts are temporary and purely on contract basis. For detailed
information login to www.hfwcom.karnataka.gov.in & www.nhm.karnataka.gov.in website address.
Requisite Qualification and Experience :
Sl
No

Designation

NHM
1 Consultant – 1

No.of
Programme
Posts

01

RCH

Salary
per
month

Category of
Reservation

Required Qualification

Required Experience

Age
Limit

MBBS with Community Medicine
(OR)
MBBS with Masters in Hospital
Administration
(OR)
MBSS with Masters in Health Care
Management
(OR)
MBBS with Masters in Health
Economics

1 year experience in
Health Sector. Health
system analysis /
Planning and
Management of change
in health sector is
desirable

45
yrs

Rs.
80,000/-

--

2

IT Consultant

01

MCA (OR) M.Tech in Information
Technology / Computer Science

3-5 years of experience
in relevant field

45
yrs

Rs.
55,000/-

--

3

Programme
Assistant

02

Any Degree
(From Recognized University)

2 years experience in
relevant field

45
yrs

Rs.
25,000/-

As per
Reservation

4

NHM
Consultant – 2

MBBS with MD in Community
Medicine / MBBS with MPH from
recognized university [OR]
01

BDS with MPH [OR]
NUHM

5

MIS Data
Manager

Graduation Degree in Public Health /
Hospital Management / Social
32
Science / Sociology / Social Work /
POST
(OR)
S
Routine
Vaccine Cold
B-Pharmacy / D-Pharmacy / Life
[1
6 Chain Manager POST Immunization
Science / Biotechnology
[IMM]
(OR)
PER
Any Degree with Prior experience in
DISTR
E-VIN Operation
ICT]

7

8

M&E
Manager

NFDS
Consultant

01

01

PC-PNDT
[PreConception
& Pre Natal
Diagnostic
Technic]

NFDS
[National
Free
Diagnostic
Services]

2 years experience in
health sector

45
yrs

BAMS with MPH
BCA / MCA with Proficient Computer
Knowledge use of MS office, Data
Analysis with Kannada and English
typing

01

Rs.
80,000/-

BCA / MCA
(OR)
BE in Computer Science
(OR)
B.Sc in Computer Science
M.Sc in Biochemistry
(OR)
M.Sc in Microbiology with Computer
skill and knowledge
(OR)
M.Sc in Bio Tech
(OR)
B.E. in Bio Medical Engineering

1 year experience in
Data Management in
any Health Sector (Govt.
or Private)
2 Years of professional
work in district level in
the health sectors and
proven experience in the
public health system.
[Experience in Vaccine
Supply Chain and Cold
Chain (OR) Experience in
managing information
technology driven
projects are preferred]

Experience not
mandatory
1 year Experience in
Laboratory in Managerial
/ Administrative role,
dealing with Procurement
and
supply
chain
management (preferably
in Government Sector /
Public Sector)

Rs.
60,000/Rs.
55,000/-

--

45
yrs

Rs.
30,000/-

--

45
yrs

Rs.
23,100/-

As per
Reservation

45
yrs

Rs.
25,000/-

--

45
yrs

Rs.
55,000/-

--

<!-- page 2 -->

9

10

11

12

13

14

15

16

17

Leprosy
Consultant

Oral Health
Consultant

NPPCD
Consultant

FPLMIS
Consultant

State
HMIS/MCTC
Co-ordinator

RKSK
Consultant

Technical
Assistant

Programmer /
Operational
Manager

CST Coordinator

01

National
Leprosy
Eradication
Programme
[NLEP]

MBBS with MD (Community
Medicine) / MBBS with MPH / DPH
from recognized University (OR)
BDS with MPH / DPH / DPHM (OR)

1 year experience in any
health sector (Govt. /
Private)

Rs.
80,000/-

45
yrs

Rs.
60,000/-

--

Rs.
55,000/-

BAMS with MPH / DPH / DPHM

NOHP
[National
Oral Health
Programme]

BDS

2 years experience in
Oral Health or any other
Public Health Program

45
yrs

Rs.
40,000/-

--

01

NPPCD

BAMS with MPH
[OR]
BAMS with Masters in Community
Health Administration
[OR]
MBA Health Care Administration
from an recognized institute by MCI
(Computer knowledge with Kannada
Proficiency)

1 year experience in
National Health
Programme

45
yrs

Rs.
55,000/-

--

01

Family
Welfare

B.E in Computer Science /
Information Science / Information
Technology (OR) MCA

1 year experience in IT
field.

45
yrs

Rs.
50,000/-

--

B.E. (Computer Science Or
Information Science)
(OR)
M.Sc in Statistics Or Mathematics

2 years experience in
Technical work in Health
Sector
/
Software
Engineer / Programmer
(OR)
Desirable Experience in
IT programming, Data
Base
Management
System in IT Industry /
Health Sector

45
yrs

Rs.
35,000/-

BAMS with MPH

2 years experience in
Public
Health
/
Government
Health
Programme / NGO with
Basic
Computer
Knowledge (MS Office)

45
yrs

Rs.
60,000/-

--

45
yrs

Rs.
50,000/-

--

3 years experience in IT
Industry
as
Software
Programmer / Developer.
Experience in HTML,
Java
Script,
SP.NET/Java/PHP
Postgrads SQL or MySQL
etc.,

45
yrs

Rs.
50,000/-

--

BDS/BAMS/BHMS Graduate with
MPH/ Masters in Public Health
(OR)
Diploma in Public Health/Community
Experience not mandatory
Medicine/Diploma in Health
Administration (DHA) recognized
university of India/Masters in Public
Health.

45
yrs

Rs.
45,000/-

--

01

1

01

01

01

01

Demography

RKSK

SIHFW

E-Health

NVHCP

Minimum 4 years of
experience
in
Government Sector or
Government
supported
programmes, preferably
in
the
fields
of
Programme
Monitoring
and
Implementation
Data
B.Sc / BCA
compilation
(Preferably with Statistics background) Collection,
and analysis Preparation
of
reports,
statistical
statements
and
documentation Handling
academic
or
training
Programme records

B.E / B.Tech in CSE / ISE / IT
(OR)
M.Tech (CS/IT) (OR) MCA

--

<!-- page 3 -->

<!-- page 4 -->

APPLICATION FORM
Date:
POST APPLIED FOR

CATEGORY :

NAME
PHONE NUMBER

MOBILE

LANDLINE

MAIL ID
DATE OF BIRTH

D.O.B [dd/mm/yy]

ADDRESS

EDUCATIONAL QUALIFICATION
Qualification

Subject

Year of
Passing

College / University / School

Total
Score

Percentage

Post Graduation

Graduation

PUC/ Equivalent
course

Matriculation

Page 1 of 2

<!-- page 5 -->

WORK EXPERIENCE (CURRENT TO PREVIOUS)
Company / Institution /
Organization Name

Designation

Total
Experience
From

To

Total Exp. In Year
Govt.
Sector

NGOs

Private
Sector

Health
Relevant
Experience

Award/ Recognition Details :
State

Central

International

Disclaimer :The above information provided by me is true to the best of my Knowledge

Candidate Signature
Note : CERTIFICATE ENCLOSED SHOULD BE SELF-ATTESTED
Page 2 of 2
