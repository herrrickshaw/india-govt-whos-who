---
doc_id: "bc493cacbfa1768a"
source_url: "https://raitamitra.karnataka.gov.in/uploads/newaispectender_1792648628.pdf"
ministry: "Agriculture Department, Karnataka"
title: "ವೀಕ್ಷಣೆ"
date: ""
pages: 3
method: "tesseract:kan+eng"
script: "LATIN"
needs_ocr: false
sha1: "33b6e6f2ca5051f7"
---

<!-- page 1 -->

/ ಕರ್ನಾಟಕ ಸರ್ಕಾರ
! (ಕೃಷಿ ಇಲಾಖೆ)

ಕೃಷಿ ಆಯುಕ್ತರ ಕಾರ್ಯಾಲಯ, ಶೇಷಾದಿ ರಸ್ತೆ ಬೆ೦ಗಳೂರು-01

ಸಂ: ಡಿಕ್ಕವಿ/ಮು. ರೈ/ಸಿ। 5405010007 /2026-27 ದಿನಾ೦ಕ: 19.10.2026
ಇ ಪ್ರಕಟಣೆ :-
ವಿಷಯ: ಮುಖ್ಯಮಂತ್ರಿ ರೈತ ಚೈತನ್ಯ - ಕರ್ನಾಟಕ ಅಗಿಟಿಕ್‌ ಮಿಷನ್‌ ಯೋಜನೆಯಡಿ
ಓ. ಆಧಾರಿತ ವೀಡಿಯೊಗಳನ್ನು ಸೃಜನೆ ಮಾಡಲು %ಓ! ಓ0010೦80೦೧೪ಗಳ
ಚ೦ದಾದಾರಿಕೆಯನ್ನು ಪಡೆಯುವ ಬಗ್ಗೆ.

ವಿಷಯಕ್ಕೆ ಸ೦ಬಂಧಿಸಿದ೦ತೆ, ಮುಖ್ಯಮಂತ್ರಿ ರೈತ ಚೈತನ್ಯ - ಕರ್ನಾಟಕ ಕೃಷಿ
ತ೦ತ್ರಜ್ಞಾನ ಅಭಿಯಾನದಡಿ 4 ಆಧಾರಿತ ವೀಡಿಯೋ ಸ೦ದೇಶಗಳನ್ನು ಸೃಜಸಿ !/೧೩೧%ಂ0
ಮೂಲಕ ಕಳುಹಿಸುವ ಸ೦ಬ೦ಧ 4 ವೀಡಿಯೋ ಸೃಜನೆಗೆ Enterprise Level Applications
ವಾರ್ಷಿಕ ಚ೦ದಾದಾರಿಕೆಯನ್ನು (88501000) ಅರ್ಹ ಸ೦ಸ್ಥೆಗಳಿ೦ದ ಪಡೆಯಲು ದರಪಟ್ಟಿ
ಆಹ್ವಾನಿಸಲಾಗಿದ್ದು, ಆಸಕ್ತ ಸ೦ಸ್ಥೆಗಳು ದಿನಾ೦ಕ: ೨೨. .10.2026 ರ ಕಛೇರಿ
ಸಮಯದೊಳಗಾಗಿ ದರ ಪಟ್ಟಿಗಳನ್ನು "ಕೃಷಿ ನಿರ್ದೇಶಕರು, ಶೇಷಾದ್ರಿ ರಸ್ತೆ, ಬೆ೦ಗಳೂರು"
ಇವರ ಹೆಸರಿನಲ್ಲಿ ಕಳುಹಿಸುವುದು. ಲಕೋಟೆಗಳ ಮೇಲೆ” ಮುಖ್ಯಮಂತ್ರಿ ರೈತ ಚೈತನ್ಯ -
1 58050110008” ಎ೦ದು ನಮೂದಿಸುವುದು.

ಲಗತ್ತು: 1 Enterprise Level Application (with specifications mentioned)
Note: If you have any clarification, please contact Digital Agriculture Section Department of

Agriculture, Bengaluru before quoting.
Contact Details : 8884000261

yan
ಕೃಷಿ ಕರು

ಪಕ್ರಟಣೆ: - ಕಛೇರಿ ಸೂಚನಾ ಫಲಕಕ್ಕೆ

<!-- page 2 -->

Al Enterprise-Level Application (with specifications mentioned)
No

Scope of Work The vendor must provide a comprehensive, multi-
modal Generative AI platform designed for
government administrative workflows. The
platform must feature seamless capabilities across
video generation, image creation, high-stakes
presentation design, and advanced text processing.

Technical & Functional A. Multimedia & Creative Suite

Specifications * Video Generation:

+ Text-to- Video and Image-to- Video
generation using advanced foundational models
(e.g., cinematic quality benchmarks like Kling AI
or Luma Dream Machine).

+ Ability to process audio or script inputs to
generate precise lip-synced digital avatars for
public service announcements.

¢ Support for camera motion controls (pan,
zoom, tilt) and native audio/sound effects
generation.

* Image Generation:

+ Hyper-realistic, high-resolution graphic
design engines (e.g., Flux or DALL-E
benchmarks).

* Consistent character and brand element
retention across multiple generated image sets.

+ Built-in capabilities for image editing:
inpainting, outpainting, and background removal.
* Presentation (PPT) Generation:

+ Al-driven document structure generation
for high-stakes presentations based on raw
research papers, data sheets, and government
briefs.

+ Context-aware styling that applies
approved official government presentation themes
and strict typography.

+ Automated slide structuring including
flowcharts, data tables, and contextually accurate
visual summaries.

B. Core Text & Document Workflows

* Document Analysis: High-capacity PDF parsing
(handling files up to 100 MB) with the ability to
summarize, proofread, and cross-reference text.

* Workflow Automation: Support for chat-driven
local file management, bulk file operations, and

<!-- page 3 -->

2 scheduled text tasks (e.g., Claude Co-Work style

computer operations). 1
* Search & Retrieval: Secure retrieval-augmented \
generation (RAG) to allow the AI to answer
prompts using an uploaded knowledge base of
official public guidelines, rules, and policy books.

3 | Deployment, Security, &

Privacy Usage Limits Uncapped Model Usage: The
platform must provide an unlimited generation tier
(flat-rate enterprise license) for text, image, PPT,
and video assets without usage throttling, token
caps, or credit-based system barriers.
Enterprise Security Enterprise single sign-on
(SSO), multi-factor authentication (MFA), role-
based access control (RBAC), and full compliance
| audit trails for all user interactions.

4 | Vendor Requirements Vendors responding to this request must provide
an itemized breakdown including:

1. Software License Fees: Flat-rate annual
subscription for unlimited platform access
per user tier.

2. Service Level Agreement (SLA):
Guaranteed system uptime percentage,
security patching intervals, and dedicated
technical support availability.

ಗ್ರ
ಕೃಷ್ಟಿ0ಿರ ಶಕರು
