---
doc_id: "68cdce3fca63bdf7"
source_url: "https://ksiidc.karnataka.gov.in/uploads/KSIIDC_1375_1791374154.pdf"
ministry: "Karnataka State Industrial and Infrastructure Development Corporation"
title: "2       3 weeks ago       ಟೆಂಡರ್ ಅಧಿಸೂಚನೆ 2"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fb0bc36c9679f6ca"
---

<!-- page 1 -->

1375/83

Sd/- Deputy General Manager (P&A)

Proof
Final

Date: 08.10.2026
Place: Bengaluru

E-ºÀgÁdÄ ¥ÀæPÀluÉ

fPÉ PÁA¥ÉèPïì, ªÀÄÆgÀ£ÉÃ ªÀÄºÀr, ¥À²ÑªÀÄ ¨sÁUÀ, ªÉÆÃºÀ£ï ¯ÁqïÓ JzÀÄgÀÄ,
JAJ¸ïPÉ «Ä¯ï gÀ¸ÉÛ, ¸ÉÖÃµÀ£ï KjAiÀiÁ, PÀ®§ÄgÀV-585102 E°ègÀÄªÀ
ªÁtÂdå PÀZÉÃj ¸ÀÜ¼ÀzÀ ªÀiÁgÁl.
fPÉ PÁA¥ÉèPïì, ªÀÄÆgÀ£ÉÃ ªÀÄºÀr, ¥À²ÑªÀÄ ¨sÁUÀ, ªÉÆÃºÀ£ï ¯ÁqïÓ JzÀÄgÀÄ,
JAJ¸ïPÉ «Ä¯ï gÀ¸ÉÛ, ¸ÉÖÃµÀ£ï KjAiÀiÁ, PÀ®§ÄgÀV-585102 E°ègÀÄªÀ,
1900 ZÀzÀgÀ Cr «¹ÛÃtðzÀ PÀZÉÃj ¸ÀÜ¼À eÉÆvÉUÉ £É®ªÀÄºÀrAiÀÄ°è 180
ZÀzÀgÀ Cr «¹ÛÃtðzÀ ªÁºÀ£À ¤®ÄUÀqÉ ¸ÀÜ¼ÀzÀ ªÁtÂdå PÀZÉÃj ¸ÀÜ¼ÀzÀ
D¹ÛAiÀÄ£ÀÄß “J°è ºÉÃVzÉAiÉÆ ºÁUÉ ªÀÄvÀÄÛ K£ÀÄ ºÉÃVzÉAiÉÆÃ ºÁV£À ¹ÜwAiÀÄ
DzsÁgÀzÀ ªÉÄÃ¯É” E-ºÀgÁf£À ªÀÄÆ®PÀ ªÀiÁgÁl ªÀiÁqÀ¯ÁUÀÄªÀÅzÀÄ.
«ÄÃ¸À®Ä ¨É¯É: gÀÆ. 1,37,28,186/- (MAzÀÄ PÉÆÃn ªÀÄÆªÀvÉÛÃ¼ÀÄ
®PëÀzÀ E¥ÀàvÀÛ JAlÄ ¸Á«gÀzÀ £ÀÆgÀ JA§vÀÛ DgÀÄ gÀÆ¥Á¬ÄUÀ¼ÀÄ ªÀiÁvÀæ).
EJAr: gÀÆ. 2,00,000/- (JgÀqÀÄ ®PÀë gÀÆ¥Á¬ÄUÀ¼ÀÄ ªÀiÁvÀæ)
(J) WÀlPÀUÀ¼À ¥Àj²Ã®£É ¢£ÁAPÀ: 12.10.2026 gÀAzÀÄ ¨É½UÉÎ 11.00
jAzÀ ¸ÀAeÉ 4.30 UÀAmÉªÀgÉUÉ ªÉÄÃ°£À ¸ÀÜ¼ÀzÀ°è.
(©) E-ºÀgÁf£À°è ¨sÁUÀªÀ»¸ÀÄªÀ §UÉÎ D¸ÀQÛ w½¸ÀÄªÀ PÀqÉAiÀÄ ¢£ÁAPÀ
ªÀÄvÀÄÛ ¸ÀªÀÄAiÀÄ: 21.10.2026 gÀAzÀÄ, ¸ÀAeÉ 5.00 UÀAmÉUÉ.
(¹) £ÉÃgÀ ©rØAUï ¥ÁægÀA¨sÀªÁUÀÄªÀ ¢£ÁAPÀ:23.10.2026gÀAzÀÄ ¨É½UÉÎ
10.00 UÀAmÉUÉ. ªÀÄvÀÄÛ ©qï ªÀÄÄPÁÛAiÀÄ ¸ÀAeÉ 5.00 UÀAmÉUÉ (qÉ¯ÁÖ
¸ÀªÀÄAiÀÄ 5 ¤«ÄµÀUÀ¼ÀÄ.)
ªÀiÁgÁlzÀ ¤AiÀÄªÀÄ ºÁUÀÆ ¤§AzsÀ£ÉUÀ¼ÀÄ: E-ºÀgÁdÄ ªÀÄÆ®PÀ
£ÀqÉ¸À¯ÁUÀÄªÀ ªÀiÁgÁlzÀ ¤AiÀÄªÀÄ ºÁUÀÆ ¤§AzsÀ£ÉUÀ¼À£ÀÄß ªÉ¨ï¸ÉÊmï:
http://kppp.karnataka.gov.in £À°è
«ªÀj¸À¯ÁVzÉ. D¸ÀQÛAiÀÄÄ¼Àî
©qïzÁgÀgÀÄ ªÉÄÃ¯É w½¹gÀÄªÀ ªÉ¨ï¸ÉÊmïUÉ ¨sÉÃn ¤ÃqÀ¨ÉÃPÁV w½¹zÉ.
zÀAiÀÄ«lÄÖ E°è ¸ÀA¥ÀQð¹: E-¥ÉÇæPÀÆågïªÉÄAmï ¸ÀºÁAiÀÄ PÉÃAzÀæ,
PÀ£ÁðlPÀ ¸ÁªÀðd¤PÀ RjÃ¢ ¥ÉÇÃlð¯ï, E-DqÀ½vÀ PÉÃAzÀæ,
JA.J¸ï.©°ØAUï, qÁ.CA¨ÉÃqÀÌgï «Ã¢ü, UÉÃmï ¸ÀASÉå 2, PÉÆoÀr
¸ÀASÉå 146, 146J, 108, 1£ÉÃ ªÀÄvÀÄÛ £É® ªÀÄºÀr, JAJ¸ï
©°ØAUï, PÉ.Dgï.¸ÀPÀð¯ï, ¨ÉAUÀ¼ÀÆgÀÄ - 560001 zÀÆgÀªÁtÂ
¸ÀASÉå:080-4601000/080-68948777 CxÀªÁ E-¥ÉÇæPÀÆågïªÉÄAmï
¸É¯ï PÉÆoÀrAiÀÄ°è vÀgÀ¨ÉÃw ¥ÀqÉ¬Äj. PÉJ¸ïLLr¹ ªÁtÂdå PÀZÉÃj
¸ÀÜ¼ÀPÉÌ ¸ÀA§A¢ü¹zÀ AiÀiÁªÀÅzÉÃ «ZÁgÀuÉUÀ½UÁV G¥À ¥ÀæzsÁ£À
ªÀåªÀ¸ÁÜ¥ÀPÀgÀÄ, PÉJ¸ïLLr¹, ªÉÆ¨ÉÊ¯ï £ÀA. 9845833566 EªÀgÀ£ÀÄß
¸ÀA¥ÀQð¸À§ºÀÄzÀÄ.
¢£ÁAPÀ: 08.10.2026
¸ÀÜ¼À: ¨ÉAUÀ¼ÀÆgÀÄ
¸À»/- G¥À ¥ÀæzsÁ£À ªÀåªÀ¸ÁÜ¥ÀPÀgÀÄ (¹&D)

Account
Executive

e-AUCTION NOTIFICATION
SALE OF COMMERCIAL OFFICE SPACE LOCATED AT
GK COMPLEX, THIRD FLOOR, WEST SIDE SITUATED
OPPOSITE TO MOHAN LODGE, MSK MILL ROAD, STATION
AREA, KALABURAGI - 585102
The Asset of the Commercial Office Space of KSIIDC
located in GK Complex, Third Floor, West side, situated
opposite to Mohan lodge, MSK Mill Road, Station area
Kalaburagi - 585102 measuring Office space of 1900 Sq.ft.
with parking area of 180 Sq.ft. in ground floor on “AS
IS WHERE IS AND WHATEVER THERE IS CONDITION
BASIS” through e-Auction.
Reserve Price: Rs.1,37,28,186/- (Rupees One Crore ThirtySeven Lakhs Twenty-Eight Thousand One Hundred and
Eighty Six only) . EMD: Rs.2,00,000/- (Rupees Two Lakhs
only)
(a) Inspection of the unit on 12.10.2026 from 11.00 a.m to
4.30 p.m at the above location.
(b) Last date & time to express interest in participating in the
e-auction: 21.10.2026, 5.00 p.m.
(c) Date of commencement of Live Bidding: 23.10.2026,
10.00 a.m. and bid closing at 5.00 p.m. (Delta time 5.00
minutes)
Terms and Conditions of sale: The Terms and conditions
of sale through e-auction are detailed on website https://
kppp.karnataka.gov.in.
The interested bidders are advised to visit the aforesaid
website.
Please contact e-procurement help desk Karnataka Public
Procurement portal, Centre for e-Governance, M.S.Building,
Dr.Ambedkar Veedhi, Gate No. 2, Room No. 146,146A, 108
situated in 1st and Ground Floor, MS Building, K.R.Circle,
Bengaluru-560 001. Tel.No.080-4601000/080-68948777 or
taken hands on training at e-procurement cell room.
For any queries related to the KSIIDC Commercial Office
Space, please contact the Deputy General Manager, KSIIDC,
at Mobile No. 98458 33566

(PÀ£ÁðlPÀ ¸ÀPÁðgÀzÀ MAzÀÄ GzÀåªÀÄ)
‘R¤d ¨sÀªÀ£À’, £ÀA. 49, 4£ÉÃ ªÀÄºÀr, ¥ÀÆªÀð ¨sÁUÀ, gÉÃ¸ïPÉÆÃ¸ïð gÀ¸ÉÛ,
¨ÉAUÀ¼ÀÆgÀÄ-01 zÀÆ:22258131-2-3, (r)22259426 ¥sÁåPïì: 080-22255740
E-ªÉÄÃ¯ï:murthy.ksiidc@gmail.com ªÉ¨ï¸ÉÊmï: https://ksiidc.karnataka.gov.in

Studio
Manager

(A Government of Karnataka Undertaking)
'Khanija Bhavan', No.49, 4th Floor, East Wing, Race Course Road,
Bengaluru- 560 001 Phone: 22258131-2-3, (D) 22259426 Fax : 080-22255740
E-mail: murthy.ksiidc@gmail.com Website: https://.ksiidc.karnataka.gov.in

PÜ®ÝìoPÜ ÃÝgÂ PæçWÝÄPÝ ÊÜáñÜá¤ ÊÜáãÆÓèÆ»ÜÂ
A¼ÊÜê©œ ¯WÜÊÜá ¯¿áËáñÜ (PæGÓ…IIwÔ)

Copy

KARNATAKA STATE INDUSTRIAL AND
INFRASTRUCTURE DEVELOPMENT
CORPORATION LIMITED (KSIIDC)

Ravi/Indesign/Tenders/KSIIDC_79

17 x 2

Computer

16 x 2

Job No.

1375/83
