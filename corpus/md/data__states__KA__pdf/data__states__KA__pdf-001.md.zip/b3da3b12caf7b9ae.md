---
doc_id: "b3da3b12caf7b9ae"
source_url: "https://mybmtc.karnataka.gov.in/storage/pdf-files/HSD%20CIRCULARS%20JUNE%202020-06232020132806.pdf"
ministry: "Bangalore Metropolitan Transport Corporation (BMTC), Karnataka"
title: "HSD-june-2020  (PDF, 3.57 MB)"
date: ""
pages: 110
method: "tesseract:kan+eng"
script: "LATIN"
needs_ocr: false
sha1: "06bb7f62dda64b09"
---

<!-- page 1 -->

. ವಸು ಸಷ ಯರ 1 ಬಹರಿ; ನ 1 10% Hee i
aaa ENT SETS Rac La AGE AE EG Os ari 1...
0] ಟಟ en 11102. .ರ [ಭಳ og ೫! i |
ಆ GeV 8 1 092/75 COVERED 8: OE an tals boil vega pa i
at we ont eh Nae i 8. ಸ a ತ 1 | a
Ge bE TE sgt 1. ೪೫... ಗ
ನ ಕ ಭಯ ಯೆ RSs Bay 1 [ ಸ i 1
ನೃ ಸ ಸಂ 1... a ih
‘ 1. 1 SECULAR Qs 24 uy o78 bye HG BAM ಟಕ ae
ಯ್ಯ CS US eo ೪1113418118.
| ಸ ಗ UNI ge ಗ ದಜ 1 ed
, 8 subs ಯ ಗಳ ನಜ ry sacnl |
a ಗಸ tock Vert testi on of AD OFT aed ಯ (ಇ(
` 12460-0೧೯೨೦೧ Tosses: yids ಗ ಜಡಗ [ಜ್‌
foes CERES OR ee ಸ Ss Pape ihe tit
ಸಸ 10 ೦106 01200231 ಟಗ ಲಂ ಟಟ |
P1012 788 Batag «9-751 99 2, 10.12.1೬...
BU NE gate Nau et ನ [6 [ಯತ (ಸ್‌
pol! VAR Skee ಅಲ a POR oe Cate
70 ಗೂ been tobserved" that i tock Verdtioatd on! of: 2೬0.2. qe
and Petrol as laid down inthis" offfoa Clreularsrdferred 161 ಬಸ ‘Rel
above, hag been kept-in ‘arrears; ತಗ 708090, Of 8 0ne OLE tha oa Sy
Hs /Patrol Pumps: in aby asf: our! ivisdong's for? one..on! other Pell te
(2asons. “On further sxamination Of thes various 2625005 ಗ. rots aN
“೦8000011೧6 op de laying the stool Verificetione 44 has: bed 0 vet
vy “Served. that tore often than. ‘not ‘pon Gspyte tion’ of Char pom. 1111/11
ಆಜ್ಯ” 100 7,0,6. 0೧ the: proposed!date, of ನಾಟು ಹಟ ಲ " ety i
‘at various: units as intdanted! by thd UnLta=has been one “೫... 11 PRY
che main reagons amonys teothars tea. `ಸ ವ ಜು ರ ಲ್ಲ ್ಪ i wai
ಎ ಮ 11131. ಸಗಳ ಯ 1.0
‘The matter Tegerdiig’ the “need wofhay Wg" dg: ಬ 8 ಕ
thoir Char genan hag pepe, Eunther a iscussed. with the Blea ts', S ನ್ಗ
Manager, TeOC., Hanitilore ePIC, ಯ ಭಗ
Cepute their Ghar gear or: § pita ble! Mectanitvion ‘rece pt: of: ae ele Fe .
ಎ ಗ regard iS, hoi pomeeas 1
Concerned ‘vinits, vy Should “however: be noted ‘vd ent paalt Mon An taint ae A,
been Clarified’ in: pare. ang! paralsy fhe CE aE: i
referenge, the Presenceiiet Tie Chas he man, ‘ov 1p Dando ALA tent y 4, ney 11
te ettond, ಸ ಜೂ ಯ weet ge ಗ a :
tho ಗಲ್ಫ್‌ son! any ‘othor tines hantoalidetac ಮ 111. 141113]
ಬ ಪಜ ಟಟ 97410075 ಜಗ 500 ಬಕನ ಇನ ರಃ pepe
Chargeman on 1150128710 118 701 10೪0190 171185) 1657 | (1 14.
“th a Ponape (vardations. dn tthe toe! mbtirendh bedi pgtd bist hea ae
ಟ್‌ ae Galera GE Tag Brea toad ಯ 1.
೫ ಜಬ. 9:30792ಬ/( 11. ಗ 1111
(7% 1 quite pose ible® that either sc ue to"'pret oso ipa tiga) i 1 |
vs other earlier envagements cate. op ತಾ ಬ ಜಟ ಟ್‌ oa i |
that such deputation nay not "be. possible LOS pg ೮ ey ee
en each occasion: when Foquas ted For by ಟೂ Un'syeh couus tong’)! 1 (10
it 1s here by dns bros ted tint “Lock Verifieatton: of’. [lob 1
Petrol should te sonc ucted as per the prdgrameet-dlbeadsy: ಸ್‌ ಬ fea |
without waiting for TO. Charsemin of rec hanies tos ಸಕ್ಕ ಯನ, 11101 |.
8೫65005, However the usage] intimation Sib peated facto, 3. 1 ಸ್ಟ i :
27೦1287 29.08, 55001 Vorification WLLL “indverdia bly betaent sto yh ata 1 i
zhe T-0.C Dapots ‘concerned Wall“in advance Teques hiner thge yi | 11 i
Cor depatatjon of Charveman on wechanic, Ag ಒಸರು 15 (51010071 111161 |
-n this’ cirdulan under referenae the: Stéele Vorifsdation: Orie, fae eeed |
Wil-orrange . He 020211. of S toa Werifsoa tion an 20/೫] fatdon coerce weit
th the. various ಜ್‌ ಬಬ ಚಚ ತೂ 11೫ 1೫.111... ಚ
6೫7/1೩06, ೪೧8 ೧೦೧೨೫೮೫ plimps 706! oy the Hac ರ etal Le Be
arious Ranpots for’ this “purpose shall La ಡಿ ಸಗ (0 ಸಣ್ಣ] (12/1120 Tee “ಲ್‌?
1317೧2೮7 ೧7೦೩೦೫೮ಲ್ಲಿ ಎ ಸ ರರ ait ON RRS ETN ನಯ
೫. 1 4 " ಯ en en aoe
8 ` ಗ ಕ ಇ ಜರ ದ,
| co ಎ ೮೧೫00 ೬೫%%9.. 18) 1... Pee OY a
Oe

<!-- page 2 -->

ವಲ ಸಯ್‌ ಚ ಬಾ ಯ ಬಬ ಪ ಟೈ ಸ್ಯ ಬ
ಎಂ ಅಟ ಬ ಚ the “spook. vi Lr cow ron, ere a: |
' in respect of, esch’ puny ds taken agi per programme 216. her
| dowme-by the Stock: Verification ೯11002 ಓಗರ cunder. nob. Ba L
| 0100 187088 Should it be: delayed"¥or ‘posiponed, 2a ನು ae r
. ರ ಬ ಜಗ ಯನ Oakes JURY SE ot y See ಸ oe 5
, 766008 2 3 how! fe a |
_*HD/Petrol the: following*precautdor® Should“ beltakeny— ಸದು |
ಬ. ಸ ಟರ ದವ ಯದು ನ ಪಯ ಜತ್ತ ಗ 312 21೫2? 1 (1೪ Red :
| i)-As “far as possible nee beenice a a ೫.1. ಸ i
ಸ pe Under graound “ಗ ೧] 6 ೧0026100110 101665 ರರ ಗ hy |
ಎ "go thatedt-is"comentent 10೫5060೩೧೪ ಯ ತ? ಭಯ ( ~ |
೨ | vs thon andthe 2.೦80 107 ! the-uWor leing “of: thes 2 fs a :
co Motor is: Teducod).to, minimbin Tey 8 oe seas, SOROS eT | |
. ಸ ಗನ ಬ Toe Sou ey a 3 ಕಯ ದ : ey
/ ಸತ) Care should:be:-taken‘ to abs uretthage 44 key
pee 2 Band’ Operating’ nud pment<is: in working «vs Sass “Ie
. ’ . Condition. so thut: in cas@}ore failure ರಸ ಗ ಯಯ ಇ ಭೋ ಡಿ
ಸ breaks down ofsmotors: at the: ೮1.16; ೦ರ ನಯ್‌ ಸ ee (ಕ್ಕೆ
51001 162181081/0ಗ. ೦೯ imeediately' there- ye BOS ak
` after. the” Hand rOperating#tquipment iss) WOE 14411111 “al
ೆ ಸ capableof being-usedé forgfuelling the is Vie oy Ee |
ಸ 16 ಯಂ 04 51532 7606. defectsxare-kotur aie" peace ge ಸ
1 1. ೨ ತ ಗೆ 1000000 ೫0011511, 1. 1... Loe
111. 1 : pg bee tee og ARES a ye RE ADL Gest
ಮ dil) Sufficient care-'should 03508160. ಬಲ ಬ 111.
: : ." ensure tha tYthe Diesel/regrol decanted EE CTW
` ‘from the’ Under ground Vanktis..ke pt ಎಡದ ಗಡ್ಟ ಗ ದಷ್ಟ ನರ್‌ ಲಲ 1೬1] rd
4 from ge thing ‘contamina ted dvi th, foroden se yot be Wg
». materdals ‘ine ludine Watery. "urther all? ಟೆ ಸ es my
oo “ precautions for-safety frm. fire andi ಗು ಜಟ ಗ]
. Such other danger‘should -bé. “taken ebys tie Mote ಪ we The (
te . keeping all requisite Plree ighting ಗಡ 1.11 at bah !
ನ್‌ ೫೦11 0/011/12:0(1/ ಗಡಿ ಓ1(1ಗ್ಗ' (21/00೧8 ಯ 2` a 11.
3 ಓ.. ೧ ಎ ಸ ಗ ಚ 1 113171 ತ ರಷ (ಸ
ಕ | ಗ Ee ಗಂ OE ee ee ಗ ಅ ಯ್ಯ (ಟನೆ |
| dv) It.should ‘bev ensured tha tifthe. ಜಂ et been me ಲ] Waly :
ಬೆ Prom the! dedantetion ‘of PBs 01/Pa trols oah* wap Cased fey
v0 from the! Underground ' Tanke bs to Lbaren' 110೫2. J
© a) Pefilling: into-the stank -takasy" the. “ಸರ ಯ erik’) ಗ `
444೪11 0% 0 “tind Vand’ durin the! PPOCOBS ರ್‌ ಸ [|
` ಎ 000 team 07/3, ರ)ಇರ 7೦೫ ಹದರ ಇಂತ ee ರ |
cation work. doesnot denvest le: Bpot under. 5. fyi dy iach whe
7. 5, any.clroums tances. ihe? enfire “work? of.'s tock ಪಯ ಚಯ
yo) saa yorifieation should - ಕ್ಯ: 01/10 ಸರ ನ % ಗನ 1.
ತ ್ಪ್ಥ ೬ 1.2... tsoever sc ‘vo kd SSRN
. Tecedpt: of, tits Circular “should: ba acknowledged. 6 11 Ir i
ಕ ರ ಯ et fae ac BRE 1 ನವಯ ಯ Phas wy oes ely ag!
: ನ ನಡಿ ಘಡ ಸ್ಸ : ತ ಸ ರಸ ದಕ ಇದೆ ನರನ ಗ
He ಎ ಕ್ಷ a CE TN Me ಸ್ಸ ಯ
೫144 ಎರ್‌ ಸ್ಪ ಸ ಸ ದ ಭಯದ |
a, ಬಲ? Cant) OBI. 07.21 0೮76ದ 1] ie at
ಸ ಸ TE RUT CHARS ೫ 111. |
“ho Dy. Son) shannyer work anager go |
Rath alsG., Voylonal workoheps , bugs lore/Hubli, for treet | |
The wy. Genk. tanager.& Diyl Wontroller yoo xe te wey a |
Neo Ff. Bangalore liviston/ ‘W087 Kolar /Hysore/lass anf. . ಗ
20317//112113/253/೩00/ 60-21 [ಬ irs4/BLjopur -for Bt end i
vdnforimetion and striot cumpitance of the Jnstructiong, re
! 1 Seb th
\Copy twos. ta! book Verdfieutlon utflcer/Ghiel -eeoumle: ನ i i
LOPfour/uh Lor [11114111014 111ಓ4110(1'/'0111/(' 11೧ ((೧' ವಿ1 ೦ caps
Chiefliseourlty Offleer/Chder Statistdedan - for informs tions cork |?
fos ನ a Gace ಬನ್ನ ದಸ :
ಧ್ಯ (ಬ. ಒಡೆ | | ಇ | £್ಗ8 ae

<!-- page 3 -->

> : my ಸೆ ಎ ಗ
1 KARNATAKA STATE ROAD TRANSPORT COREORATION, uhh Cet eae
i ORWERAL OFPICES:. BANGALORE. ಸ
Be Cs ರ ಜಟ
` : ನ ವ |
as,, SMORES @ PURCHASES DEPAROMUND 2 ಸ ತ
fe ಯದ ಸಸ ಜ್ನ ಸತ | |
WO:KS:CO:P:IIL+G.421 307+ Yes DARED s; ಹ 1]
ಚ 1 ಎರ ಫಲಕ ನ
oe . ws ಎ ಸತಿ :
. : . : wo ಸ ಯು ರ ಗ
The Divisional Controller, Be re 1
15770, ಸತ್ತ 80 ಯ/ (ಬ ಬಹು (೩/2210%ು/ ಅ ಯ.
ಸ ao wt Bs ರ
ಸರಗ da Sagelkot/Bangalore, (G3. 8(R)/ _- eee
BPS (NW) & (8)/Mysare/Kolar Bo ಅ ಭಯ ಜೂ
ಜು ದಿಯ ಕ್‌ 1 ಅ 1 1. 111111. 1111111. ೫೬ Soe |
a : . : . a wee or ತಜಿ
9; 90003. 02 88) 042 17 1/8, 206.7. ರ0ಜ2028:ಬಂಗ್ಯ ಬ!
ಬ `ನ ಸ 8023 2ಶಗ NO:BGM:02600,,dt. 15.541992, ಸ oe he oe
ಸ ತ ನ ಯತರ? " ದ ಯ ಜರ RB ropa
: at ಇ 6 ಸ wee” ' ಎ 1 ;
ಸಜಿ ಟೆ weeks ಯ
ಪ, ' The detailed procedure to be followed, with, regard Jaane |
' . to the receipt.of the HSD O11 in the Depots. ggogtven by]
M/S Indien ‘OL Corporation” Timited ;thas ‘been ಯಂ ಯ ಹಕ್ಕಿ oS
.  __Mifde thie office letter. NO:K80:00:PsIII: G4 11060; datedd ig ae
27.2.1986, 1 1. ಗೆ ಸ ಜಾ
ae OE (| :
‘ 3/8 Indian. O11 Corporation 216, pelgaun vide eee
their letter NO.BGM:0:600 at, 1355-1992 have intimated: (ii. hig
this office ‘that they have received some complaints © ಜ್‌
from some of .our wits regarding the short receipt of ee
೬4 “the HSD O11 in the Tank Trucks in vhich the 220001. 1... 15
. : ಗೂ
was supplied to the Depots. 4 copy. of the letter” a |
: received from M/S. Indian O11 .Corporation tds, Belgaum seg cuige
and sent herewith for your information and necessary ty ae ae
ನ ತಂಟರ್ಯ ಗ ೫...
ಎ fi py IOS
ಯ In the above connection it ia ‘once again ಎ cS
. that HSD loads should be received carefully. ಆಜ್‌ ಬ್ರ (040 |
the Depot Manager, ಂಅಯೇ“ರ ಲ ಲ್‌ ಟ್ಟ ಈ0ಯುಸ7162004/ 1... aN) |
ಟಿ | ( ಗ
Assistant Works. Superintendent as per Ciroular ೫೦:೫೫: ಆ 1((ಊ
00123222164 110601 dh. 274261986, 5೦ ಹಂಡರ ಉಳ ee .
receipt ofthe products, ‘In case any short roost pt! 4
. "of the product is detected in the Indian LL -Gorperation 7) /
Temgoy- before unloading the actual quantity of tag
= goo 0g US ey
. ’ Ub ಸ a :
1 og 1.4೪4
(ಟೊ ‘ .

<!-- page 4 -->

ಡರ : OREO Ea
: oe | ar CoE !
ಚ 2/ಒ- eat |
‘ \ 1. 4 : ಜ್‌ [
ಕ ರಾರಾರದರ ೨ ಜೆ 11. 1414111... .
. short receipt should be assesged and recorded on the goth Bm
. _ back of the challan alongwith Drivers signature. In 1 ae
case the drivers refuse to endorse the shortage the ® tou, |
. ಅ ey 1 ಜಟ (|
> Bae can be recorded in the invoice ond sent) to MAR ae /
Indien Oil. Corporation, Limited. 444 wae Le a
ge ೬.1 Be 1ಬ tah te ಗ ಸರ ನ ಸಳ ಯ ಬ
oR hag OR ED cae nating MSPs ೫... ೪೫೫11]...
. ‘It is requested that,all.the Depot Managers’. peed
co Des ee ee
. should be,advised suitably in thie behalf. 7 fh ene
. , a : ` : 441... 11181111. scat
11111... 18.. 1 ca ಸ ದ
ನ CONTROLIER ೦. 8೦೫056೬ PURCHASES, 2
1 ರ ಕಗ bets |
ಜ್ತ ra ಟ್‌ aoe
: ಯು” oo os 2-4 ಭೆ co [1 oo
Copy to DME/SO of the respective Divisions for “WF. oe
: ‘ co . TE ೫೪. ಸ
infomation and necessary aotion.  ್ಪ ರ್ರ
` ಬ ತ ಕವ ಯ ಸ್ನ ಯದಾ ಎನ್ನ ಕ ಜು ಸ್‌
ನ? ಯಂತ ಭರ ್ಸ್‌್ಫ್ಪ
ನ ರ ರ ಟ್‌
ಏ : re ಟ್‌
ಯ ಯ 3.1... 113... .
i. DAB ದ್ನ So ag a ಫೃ ಚ
: . ಚ್‌ ca Ty OE oe ihe ERED 11 2 21
: ಸ ಸ್ರ : . : * og ae Byte hey 2 ಹ. | ;
we "1 ಸ mo. Doig pet anh SAAR, ge
~ ಗು ಯ? ಟಗ Sigs OR cg
: | ಅಪ 3 41 1... 4.1. ತ್ಕ
“ So : ನ RES 4 1 ae
rs ದ (ಅಳ ಇರೇ ್ಬ
: ಸ Bons ಎ ಯ ಯನ ಭಯ ಗಳೂ” ee
1 ne : ಸ ರಾ ct flee ay ue a a ee |
ಸಡಾ ನ ಜನ ಯಿ | oo ce oe \ aes :
ಸ 12/28592 ನ ಎ | oe Hes ER he ae Us i
Bows : VP OU ರ Oe
oo 8.11 11. ನ 11 ಕ್‌
ನನ 8 ೫... 13111. 11 22.11.18 1:11
ನ ; whi ಸ ಟ್‌ ಸೂ |
` un. a |

<!-- page 5 -->

i
cee | _ PPATTON |
. : CENTRAL OBBICES: Puce ag 1131೧1
vu : 21.1 811]
NOS? sCOrPstiric.ay 4766 Dt, 9.11.92,

. The Divisional ೨೦೧೪೭೦ 32ರ

145/೧೧ venga lore (C)/Baties Lote (re) ನ
[3110(1/)/ NES (2) 7 Myzore/ ko lar / .

. Matiscn/Baneg ಆಲೆ) ಭಟರು ರಹಸ ಯ — |
Sadchur/ NK sy rei/Dellary/ie iy Me :
er) gaun/Baga Meet /Ca 11131111113 rey ‘ :
1.
the Works Manager, |
Revydonal Workshens, Cangalora . |

Sub: Supoly OF WGU O41 Dy Tite. ee,
Tank Bruck “ecantation proceduce , "|
` Ref? Circuler ೧೦೨೭೧ ;43 0,23,17,902 ruceiverd :
from ಗ/ಆ.7,೧.೧, (ರಗ್‌
` We enclose herewith a Copy of the letter NOC Ak |
010 ,.23,17,92 re ceived from ite, ೩22೩೧ ೧.2 ೮. ಟೆ. 111... 11111
regarding the preecedura ta he ಸಸರ ಭೂ decantet ten: call
MSE OL an the Depots. The sane Mey Me eh cuduatae te ad
MO poe Marion 1 ೪... 11.1. Ke MEG Seas dec jar shyt heer ger ds ey
. |
: i
ಗ
' an wry at?
ನ . CONTROL 2 Cit ಗಳಭರ್ಯ ಯ « PUROH, SES, .
Pe 1 \
Se. 31i/2 al . y . ‘ : `
\ AN ae, ‘ :
ಸ ೬.4 |
' :
. ಪ ನ |
‘ . i
:
. f
: : `
i
i
. : ಟ್ರೂ

<!-- page 6 -->

Be tee

(|

i

|

|

a

. |

| |
೬44

|

| |

|

<!-- page 7 -->

|
ಸ INDIAN OIL CORPORATION LTD. 6} |
ರೆ ಣೌ (MARKETING DIVISION) (ia As
2 “aw” 46-D, LALBAGH ROAD, Wy |
ಲ್ಲ "BANGALORE 560 027. |
. ALL CONSUMERS\DIRECT CUSTOMERS, - REE : BC\41 : |
ತೆ ; DATE : 23.7.92 .
> SUB 2 TANK TRUCK DECANTATION PROCEDURE ,
You are aware fuel oils like MS, HSD, FO and LDO are supplied by us
in tank truck based on your indents on our supply locations. /
Supplies of MS (Petrol) and HSD are arranged through our company
owned\contracted tank trucks for delivery at your premises. 0. and
LDO are supplied through your authorised transporters, and aale
transcation completes at our supply location itself. ,
: : |
. We have been periodically sending circulars to our valued customers :
indicating the procedure to be adopted while decanting the product
at qustomers premises. We often receive customer complaints regard-
. ing alleged. shortages in the tank trucks, seeking clarifications,
« We therefore take this opportunity oncéagain, to enclose our cireu--
«sar detailing the decantation procedure to be adopted by you at your
premises, for your guidance and necessary action. -
In case of petrol and diesel supplied by us through our company
owned\contracted tank trucks, we wish to further clarify on the i
following points. : . . .
In .case of shortages noticed by you in any of the compartments ೦೫
the Tank truck, topping of HSD by using diesel oil from the fuel
tank of the tank truck, is_not.an_acceptable practice. In puch. case
Please ensure that the shortages noticed are witnessed by tank truck
driver and the respective tank truck compartments are topped up by
using HSD from your stock by ueing etandard weasuring can duly
certified by Weights and' Measures Department,
Such identified and witnessed shortages may please be recorded on |
the back of all the invoices duly eigned by your representative ac !
well as the TT driver. In cace the TT @river refuses to sien; even |
‘ after witneneing. buch shortages; you may endorsc ag such .on the back ,
‘~ of 0036 involce after intimating to. our BUpply pointe. ‘While, this
procedure is adopted by you, our supply point will be able to 17೧೬೧,
necessary oredit note for the value of the shortages ‘co rouorded and
the same is debited to our transpert contractor.
You Will pleace appreciate that only when we become aware off ° such
recorded Ghortugei on the back of the invoices as per the Procedaras
detailed above, we will be able to take necessary action on the
" traneport combractors Wherever justified and issue credit netes In |
- ೪೦೭೫ 3ಗ೪ಲಬು ೬ ` ` i
. . |
. We therefore request your cooperation in making proper checks while
decanting the product as per the duldelines in the enclosed clraulur
for our mutual benefit. |
Thauking you and assuring you of our beet- attention and’
services at all times. : . :
. Yours faithfully, I
ವರೂ ಎ tor INDIAN OTL CORPORATION Lup. , !
ಇಚ ಸ ಇರ ಸ್‌ oo 4 oo
| Sloe, wes, Gane ve ' Lot ` ನೈ
PY Rom) HDA | ( S.8. RAG 3 |
maven . yo woe ಗ 1(211108 011017 ೫116111 ಎ [
1 BRP en ol ME Ry |

<!-- page 8 -->

|

|

(

1...

| |

|

Oe
|

|

<!-- page 9 -->

೯ ೫816/208೫ DIVISIONAL OFFICE @O |
ee ದರ್ಯದರರೆಧರರರರದರರದರರ ee
“ TANK TRUCK DECANTATION PROCEDURE | ` bad i
oboe
I. RECEIPT OF THE PRODUCT :< | : ao
. Ly On arrival of the tank truck, check that delivery challan
ise made in your favour! : wee oy
ಎ 2. Check that product received is the same as indented - by
you, : 2 ` ವ? fo i
3. Check tank truck number as indicated in the chaliaiix: me `
4. Check. number of compartments and quantity of produat. and
` time of arrival\despatch. °' | ನ್ಮ :
II. DECANTATING OF PRODUCT : 1೫ .
5. Park the tank truck on level gtound and allow ten minutes ‘
for settling down. Ensure that tank truck 62596೩ ' 0೭೦೫೩6೮೬
` earthing clips before decantation of product. 18 `
8. Check seals on delivery manifold and seals on top ‘manhole
; covers of each compartments. , . 2
17. Verify that numbers on s¢als are matching with the nunberg oo
written in the invoice. a 41
ಎ 8, Release valve leverg to ensure product iz in the. pipeline - |
manifold. Tank trucks are alvays calibrated With lines full, |
‘ (refer calibration certificate). , .
9. Ask tank truck driver to produce calibration certificate |
which would mention product level and proof level detaile,
೩0, Check weights & measures marking on the dip rod a6 well no
: at the proof Level. Ag an additional check, verify dip rod :
. calibration With a measuring tape.
11, Check. tank truck number in the dip rod of the tank truck,
Check the dips of the product with the dip rod duly ೧೮೫1೬
fled by the Weights & Measures Dept,
' 12. Check the presence of water with the help of water finding:
paste using dip rod. ಎ
13. Draw samples in Clear glass containers and carry out visual
inepection and identification. In case of doubt about the
quality, contact our supply point, for further inetructione.
14. In case of dip being found ahort. and water detected, pleage :
ನ contact our supply Point. ue
15. Short dip quantity should be topped-up by filling to the .
{ correct’ level though dispensing pump or through a calibrated
a Can with valid Weights & Measures stamping, and quantities
60 filled should be recorded compartment wise on all ೧೦೧೧
of delivery challan duly signed by the receiving party “and
the tank truck driver.
: 16. After ascertaining quality and quantity, deeant the Product, '
: in the correot under-ground tanks, :
ಸಳ... After decanting pledge ensure that the tank truck is ೫11)
eupty before releasing it. Thig ean be done by dipping cach
` compartment of the tank ruck and by checking for the lett . |
over contents in the compartment by opening the bottom
valves of the compartment. Please also ensure that the
: master valves at the top and quick closing valves at the
rear of the tank truck are kept open. Physical inspection '
ly aoing up the tank truck by responsible P¢rson in advieu~ |
bie. :
TIC. STOCK CONTROLS : . ‘ .
J8. Make appropriate entries on the steak register on recelphe :
and lesues. '
19. Take opening and closing stock on a daily basie to oheak |
variotionga, If any, please rnoke Lhat your (ಓಗರ lanka are :
~ only mathematioally. aal lbrated and hence Ghat dh mob tee vest eT
for accounting nownsaana vay .

<!-- page 10 -->

|

|

|

‘ . : . ( |
ನ | |

|

| |

|

|

|
