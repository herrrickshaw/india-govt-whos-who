---
doc_id: "62d7fb2bcc3a0c2f"
source_url: "https://www.nls.ac.in/wp-content/uploads/2026/10/Notification-Research-Degree-Programmes.pdf"
ministry: "National Law School of India University, Bengaluru,, Karnataka"
title: "here ."
date: ""
pages: 5
method: "tesseract:kan+eng"
script: "LATIN"
needs_ocr: false
sha1: "b09764e5515df50a"
---

<!-- page 1 -->

| Por rata ke Post Bag No. 7201, NAGARBHAVI, BENGALURU - 560 242. (Old Code No. 560 072), INDIA.
Telephone: 080 - 23010000, 080 - 23213160, 080 - 23160533 Website : www.nls.ac.in Email : registrar@nls.ac.in
NOTIFICATION

ADMISSIONS TO THE RESEARCH DEGREE PROGRAMMES (2027-28)

Applications are invited for admission to the following Research Degree Programmes at the
National Law School of India University (NLSIU) for Academic Year 2027-28. These are:

1. Ph.D. (Law)

2. Ph.D. (Social Sciences, Humanities and Public Policy)
ELIGIBILITY
Ph.D. (Law)
The following candidates shall be eligible to apply for the Ph.D. (Law) programme:

a) Candidates having a 5-year/ 10-semester/ 15-trimester bachelor's degree in Law
through regular mode from a recognized University having secured a minimum
of 55% marks in aggregate or its equivalent grade on a point scale wherever the
grading system is followed (50% of marks or its equivalent grade in case of
SC/ST/OBC- NCL/Persons with Disability.)

b) Candidates having a 3-year/ 6-semester/ 9-trimester bachelor's degree in Law
(LL.B.) through regular mode from a recognized University having secured a
minimum of 55 % marks in aggregate or its equivalent grade on a point scale
wherever the grading system is followed (50% of marks or its equivalent grade
in case of SC/ST/OBC-NCL Persons with Disability); and

c) Candidates having a Master of Laws degree (LL.M.) through regular mode
from a recognized University having secured an aggregate of at least 55%
marks or its equivalent grade (50% of marks or its equivalent grade in case of
SC/ST/OBC-NCL)/ Persons with Disability);

6) Candidates having passed the Solicitors Examination conducted by the Bombay
Incorporated Law Society and having completed a bachelor’s degree in Law
(LL.B./LL.B. (Hons.)) degree from a recognized University through regular
mode; or

A University for Legal Studies and Research sponsored by the Bar Council of India and established under Karnataka Act 22 of 1986

<!-- page 2 -->

(e) Candidates having a Master of Business Laws (MBL) degree from the National
Law School of India University with a minimum CGPA (Cumulative Grade
Point Average) of 4.00 and having completed a bachelor’s degree from a
recognized University through regular mode.

Provided that candidates in their final year of study in the respective degrees in (a),
(b) and (c) shall be eligible to apply, subject to the candidate securing the minimum
marks or equivalent grade prior to the date of commencement of the Ph.D.
Ph.D. (Social Sciences, Humanities and Public Policy):
The Ph.D. (Social Sciences, Humanities and Public Policy) encourages students with any
degree in the social sciences, humanities, and public policy field to apply. Candidates are
encouraged to review the ongoing research projects and faculty research interests on the
University website while preparing their proposals.
The following candidates shall be eligible to apply for the Ph.D. (Social Sciences,
Humanities and Public Policy) programme:

a) Candidates having a 4-year/ 8-semester/ 12-trimester bachelor's degree
through regular mode from a recognized University having secured a minimum
of 55% marks in aggregate or its equivalent grade on a point scale wherever
the grading system is followed (50% of marks or its equivalent grade in case
of SC/ST/OBC- NCL/Persons with Disability.) 5

b) Candidates having a Master's degree in any discipline through regular mode
with a minimum of 55% or equivalent grade (50% of marks or its equivalent
grade in case of SC/ST/OBC-NCL/Persons with Disability) and a Bachelor's
degree from a recognized University through regular mode; or

b) Candidates having passed the Company Secretaryship examination conducted
by the Institute of Company Secretaries of India and been awarded Associate
Membership of the Institute (ACS) and having completed a bachelor's degree
programme from a recognized University through regular mode; or

c) Candidates having passed the Chartered Accountants examination conducted
by the Institute of Chartered Accountants of India and been awarded
Membership of the Institute of Chartered Accountants of India, and having

<!-- page 3 -->

completed a bachelor's degree programme from a recognized University
through regular mode;
Provided that candidates in their final year of study in the respective degrees in (a), (b)
and (c} shall be eligible to apply, subject to the candidate securing the minimum marks
or equivalent grade prior to the date of commencement of the Ph.D.
ADMISSION PROCESS
Candidates for the Ph.D. programme shall be selected through a two-stage selection process
i. The first stage of the selection process shall be the admission test (NLSAT-PhD) that will test
the research aptitude of the candidates and their subject-matter expertise. Only candidates securing
not less than 50% marks in the written test will qualify for the second stage.
ii. The second stage of the selection process consists of the evaluation of the Research Proposal
submitted by the candidate and the Oral Presentation of the Research Proposal. Both components
shall be of equal weightage (50% for the Research Proposal submitted by the candidate and 50%
for the Oral Presentation of the Research Proposal).
iii. The final selection of the candidates shall be based on the aggregate of the marks secured by
the candidates for the Research Proposal and Oral Presentation of the Research Proposal.
Application
Candidates shall submit the application form duly filled up along with a research proposal of
about 6-8 pages. The application form shall be available on the University website.
The research proposal must:
i, Contain a Tentative Title,
ii. Identify a research problem and discrete research questions,
iii. Demonstrate background research and a thorough awareness and
understanding of the relevant literature on the research problem,
iv. Identify the methodological approach to respond adequately to these
research questions.
Candidates who demonstrate a firm grasp of the foundational themes and
methodological questions of the relevant discipline will be awarded higher marks.

<!-- page 4 -->

The research proposal must be prepared by the candidate without any external
assistance or assistance of AJ tools.

Admission Test (NLSAT-PhD):

The National Law Schoo! Admissions Test-Ph.D. (NLSAT-Ph.D.) will be held on April 25,
2027 in specified centres across the country. The duration of the test shall be 150
minutes. The NLSAT-Ph.D. shall test the students on Research Aptitude and subject-matter
expertise.

The dates for the oral presentation shall be announced after the completion of the NLSAT-
Ph.D. They are likely to be held in May 2027. Classes for the coursework component of the
Ph.D. programme shall commence at the University in July 2027.

TOTAL NUMBER OF SEATS

The maximum number of Ph.D. seats for the Academic Year 2027-28 are 8 (Eight). This
includes 4 in Ph.D. (Law) and 4 in Ph.D. (Social Sciences, Humanities and Public Policy).
The University reserves the right not to fill all the seats where sufficient candidates do not
satisfy the admission requirements.

Application Fee

An application fee of Rs. 3500/- (Rupees Three Thousand Five Hundred Only) shall be
payable at the time of submission of the application.

Last Date for Submitting Applications:

Applications shall be accepted till 11:59 pm, IST on March 23, 2027.

DOCTORAL FELLOWSHIP

Selected candidates will be offered a Doctoral Fellowship of Rs. 50,000 per month for a
maximum period of three years from the date of their admission. The Doctoral Fellows
would be required to work for approximately ten hours every week on university roles related

<!-- page 5 -->

to their doctoral dissertation and towards their development as an academic professional. On

satisfactory progress in their doctoral research and completion of institutional responsibilities,

there will be an annual increase of 10% in the Fellowship Amount. Continuation of the

Doctoral Fellowship at the end of each Academic Year shall be contingent on progress in
. doctoral research and completion of institutional responsibilities. The fellowship may be

discontinued if research undertaken by the Fellow is found unsatisfactory.

Doctoral Fellowships will not be provided to candidates who remain in paid employment or

other forms of paid full-time engagement with any entity or organisation after admission to

the Ph.D. Programme.

Applicants already receiving UGC Junior Research Fellowship (JRF) or any such other

national fellowship/sponsorship are not eligible to receive the Doctoral Fellowship.

REGULATIONS

Regulations governing the Ph.D. programme are available on the University's website.

Candidates should familiarize themselves with the requirements of the programme, before

applying.

oy
Date: 9.10.2026
