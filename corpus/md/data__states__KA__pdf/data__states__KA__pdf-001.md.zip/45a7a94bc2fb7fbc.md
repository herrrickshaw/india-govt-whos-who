---
doc_id: "45a7a94bc2fb7fbc"
source_url: "https://ksiidc.karnataka.gov.in/uploads/RFQ-Appointment%20of%20Concurrent%20Auditor_1790768949.pdf"
ministry: "Karnataka State Industrial and Infrastructure Development Corporation"
title: "9       4 weeks ago       ಕೆಎಸ್ಐಐಡಿಸಿಗೆ 2026–27ನೇ ಹಣಕಾಸು ವರ್ಷಕ್ಕೆ ಸಮಕಾಲೀನ ಲೆಕ್ಕಪರಿಶೋಧಕರ ನೇಮಕಾತಿಗಾಗಿ ಉಲ್ಲೇಖಗಳ ಆಹ್ವಾನ"
date: ""
pages: 25
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c526ce0740f2a528"
---

<!-- page 1 -->

NOTICE
KARNATAKA STATE INDUSTRIAL & INFRASTRUCTURE DEVELOPMENT CORPORATION LIMITED (KSIIDC)
Sub: Invitation of Quotations for Appointment of concurrent Auditor for FY 2026-27
KSIIDC invites quotations from eligible Chartered Accountant / Cost & Management Accountant firms for
appointment as Concurrent Auditor of the Corporation for FY 2026-27.
Interested and eligible firms may submit their technical and financial quotations in sealed covers on or before
06.10.2026.
The detailed Request for Quotation (RFQ), including scope of work, eligibility criteria, and terms of submission, is
available on the Corporation's website: https://ksiidc.karnataka.gov.in/en
Interested firms are requested to visit the website for complete details before submitting their quotations.

By Order,
Karnataka State Industrial & Infrastructure Development Corporation Limited
Sd/Company Secretary

<!-- page 2 -->

REQUEST FOR QUOTATION (RFQ)
FOR

APPOINTMENT OF CHARTERED ACCOUNTANT / COST &
MANAGEMENT ACCOUNTANT FIRM FOR CONCURRENT AUDIT
ASSIGNMENT – FY 2026-27

Issued by:
Karnataka State Industrial & Infrastructure Development Corporation Limited (“KSIIDC”)
Address: Khanija Bhavan, 4th Floor, East Wing, No. 49, Racecourse Road, Bengaluru – 560001
Website: http://ksiidc.karnataka.gov.in
E-mail: comsec@ksiidc.com, edoffice@ksiidc.com;

<!-- page 3 -->

SECTION 1 – INVITATION FOR QUOTATIONS
Karnataka State Industrial & Infrastructure Development Corporation Limited (KSIIDC) invites
quotations in two separate sealed covers (Technical and Financial) from eligible Chartered
Accountant / Cost & Management Accountant firms for conducting the Concurrent Audit (pre-audit)
of the Corporation for FY 2026-27, in accordance with the Scope of Services, manpower norms and
evaluation methodology set out in this document.
Particulars
Name of Assignment
Estimated Cost

Details
Appointment of Concurrent Auditor for KSIIDC,
Bengaluru for FY 2026-27
Rs. 4,00,000/- per annum (excluding GST)

Date of issue of RFQ

01.10.2026

Last date/time for submission of quotations

06.10.2026

Date of opening – Technical Bid

07.10.2026

Date of opening – Financial Bid (technically
qualified bidders only)

08.10.2026

Address for submission

Executive Director, KSIIDC, Khanija Bhavan, 4th
Floor, East Wing, No. 49, Racecourse Road,
Bengaluru – 560001

Contact for queries

Company Secretary, KSIIDC, Bengaluru – Phone:
(080-22259358/ 07760131381)

Note: KSIIDC reserves the right to accept or reject any or all quotations without assigning any reason.
Submission of a quotation does not imply automatic selection. Quotations quoting below 75% of the
Estimated Cost shall be subject to scrutiny under Section 8.3 before being taken up for technical
evaluation.

SECTION 2 – INTRODUCTION
Karnataka State Industrial & Infrastructure Development Corporation Limited (KSIIDC) was
established in the year 1964 as a wholly owned undertaking of the Government of Karnataka under
the provisions of the Companies Act, 1956. The Registered Office of the Corporation is situated at
Khanija Bhavan, 4th Floor, East Wing, No. 49, Racecourse Road, Bengaluru – 560001.
KSIIDC's activities are broadly classified as: (a) Promotional, Developmental, Infrastructure
Initiatives and Nodal Agency Role; (b) Promotion of Industries through Equity assistance; and (c)
Promotion of Industries through Loan assistance. KSIIDC is presently the nodal agency for several
airport and infrastructure projects across Karnataka (including Kalaburagi, Bidar, Shivamogga,
Vijayapura, Raichur and Hassan airports) and is also focused on recovery of dues from NPAs, having
put fresh loan sanctions on hold for over two decades.
Equity Share Capital as of 31 March 2026 stood at Rs. 694.7 crores, and the Corporation posted a
provisional profit before tax of Rs. 115.24 crores on a turnover of Rs. 147.13 crores for the period

<!-- page 4 -->

ending 31 March 2026. Given this scale of operations and the volume of day-to-day transactions
across departments, the Concurrent Audit assignment requires a sustained, near-continuous on-site
presence to ensure files are cleared without avoidable delay, as detailed in Section 5.

SECTION 3 – SCOPE OF SERVICES
The Concurrent Auditor shall conduct pre-audit of the operations of all departments of KSIIDC on a
continuous basis, in accordance with the manpower and attendance norms prescribed in Section 5.
The objective is to function as an effective, real-time control mechanism – files referred by the
departments shall be examined and returned with audit observations/comments before further
processing, with monthly consolidated reporting to Management and immediate escalation of any
major lapses. The departments/functions to be covered, and the illustrative scope under each, are
as follows:

A. Finance & Accounts Department


















Verify that accounting entries are in accordance with Generally Accepted Accounting Principles
/ Indian Accounting Standards (Ind AS).
Verify that all accounting entries (income, expenses, banks, journals, cash, interest calculations
for recovery of loans under OTS, etc.) are incorporated in the books of accounts with all
supporting vouchers and approvals.
Review internal controls, accounting policies, procedures and orders issued from time to time,
to ensure purchases and revenue payments are properly approved, bona-fide, and accurately
classified and recorded.
Verify Heads of Account of various transactions recorded in the books of accounts.
Review compliance with previous audit objections raised, if any, and verify/comment on
supporting documents/vouchers submitted subsequently.
Scrutiny of outstanding advances, Security Deposits and Sundry Creditors & Debtors, Cash
and bank balances.
Review all payments received, accrued interest and other receivables.
Review all Fixed Deposit Receipts with various banks and verify the register maintained against
the corresponding entries in the books of account.
Verify procedures for disposal of assets (scrapping/condemning) are followed; all purchases
above Rs. 10,000/- to be verified and reported.
Verify Bank Reconciliation Statements are prepared on a timely basis.
Verify postings made in the financial accounts against entries made under the Loan Monitoring
System on a routine (weekly) basis.
Verify Journal Entries for correctness and mismatches, especially in statutory payments
(Advance Income Tax/TDS/GST/labour cess etc.), timely submission of statutory returns, and
wrong classification of capital to revenue and vice-versa; the report shall indicate the extent of
verification and months covered.
Review regularity in deduction and deposit of tax on salaries, consultation/professional fees,
and contractor payments.
Verify files before issue of ‘No Due Certificate’ (NDC), with reference to receipts and dues
payable under OTS and status of realisation.

<!-- page 5 -->










Surprise physical verification of cash on a monthly basis, including utilisation and necessary
approvals.
Verify computation and utilisation of CSR funds.
Verify loans and advances to staff and their timely recovery.
Verify lease-rent invoices payable to GoK for Bengaluru International Airport as per agreement
terms.
Verify whether the Corporation maintains a separate account for waiver of loans/interest/other
debits.
Review overtime/TA/DA/other payments for authenticity and procedure followed.
Review existing systems, policies and procedures for compliance with RBI guidelines/circulars
on NPA Management; suggest improvements.
All other files referred to the Concurrent Auditor are part of pre-audit.

B. Recovery Department




Verify all files referred for pre-audit on the procedure/system adopted for recovery in respect of
One Time Settlement proposals, recovery activities, NCLT cases, and cases under Sec. 29 of
the SFCs Act, including delay in selling assets, missing assets (if any), and timely recovery of
outstanding dues, and monitoring of insurance and other claims.
Pre-audit of all security payments proposed to safeguard secured/mortgaged assets against
which recovery action has been initiated under various Sections of the SFCs Act.

C. Information Technology Department




All purchases above Rs. 10,000/-.
Actual requirement of purchases and prior approvals & authorisation.
Systems and procedures followed.

D. Administration Department





All purchases above Rs. 10,000/-.
Actual requirement of purchases and prior approvals & authorisation.
Systems and procedures followed.
Other issues emerging from time to time.

E. Personnel Department



Verify files submitted towards increments, promotions, and filing of returns to the State
Government as per rules, during pre-audit.
Other issues emerging from time to time, if any.

F. Financial Services Division (FSD)


Verify proposals for investment in equity shares/debentures/mutual funds and disinvestment;
physical verification of inventory of stocks; management-related activities.

G. Khanija Bhavan & ITBT Park



All expenditure and fund flows relating to Khanija Bhavan and ITBT Park.
Review the Premises & Facilities Management (P&FM) services provided at both premises.

<!-- page 6 -->






Carry out surprise inspection of security guard deployment as per the tender document at both
premises.
Verify receipt of rent on a monthly basis as per invoices raised, enhancement/rationalisation of
rent, and renewal of lease agreements.
Verify payment of P&FM monthly bills, AMC payments and other major payments.
Any other files referred for audit from time to time, if any.

H. Infrastructure Project Development Department (IPD) – including Airport & NonAirport Projects








Verify Running Account bills relating to contractor payments, discharge of royalty, and O&M
expenditure across all projects of KSIIDC.
Verify prior approval of bills from the competent authority, and applicable statutory deductions
on bills.
Verify expenditure/bills for salary, TA/DA and other staff payments, and maintenance/services
bills.
Review project budgets for accuracy and completeness; analyse budget variances and assess
resource allocation across projects.
Verify existence of contingency funds for unexpected costs, and accuracy of invoicing and
payment tracking systems.
Verify the procedure adopted for award of contracts in compliance with the KTPP Act; review
Bank Guarantees on a quarterly basis.
Verify that payments released to contractors align with the Terms of Reference of agreements,
including escalations and price variation, if any; analyse project cost sheets for completeness
and accuracy.

Note: KSIIDC may, from time to time, reorganise its operations and departments depending on need.
The scope of Concurrent Audit shall encompass all operations even after such
reorganisation/reconsolidation. The work content indicated above is illustrative and the audit shall
encompass all existing and future reorganised operations.

SECTION 4 – GENERAL
The scope of Concurrent Audit under this RFQ is primarily confined to pre-audit / transaction-level
scrutiny of files as and when referred by the departments, together with the reviews specified in this
Section 4. This is distinct from, and complementary to, the periodic systemic review conducted by
the Corporation's Concurrent Auditor. The Concurrent Auditor shall share its monthly reports with
the Concurrent Auditor for cross-reference, and shall coordinate with the Concurrent Auditor to avoid
duplication of effort, so that the two assignments together provide continuous transaction-level
assurance (Concurrent Audit) and periodic systemic/thematic assurance (Concurrent Audit) without
gaps or overlap.
The Concurrent Auditor shall review procedures adopted in taking necessary approvals for official
visits abroad, and assess compliance with applicable State Government guidelines, rules and
directives issued from time to time.

<!-- page 7 -->

The Concurrent Auditor shall review the performance of schemes introduced by the Corporation,
including recoveries, One Time Settlements, and sale/disinvestment of equity holdings.
The Concurrent Auditor shall periodically review the Business Plans of the Corporation and their
achievement with respect to targets and goals.
The Concurrent Auditor shall assess the adequacy of existing systems of reporting and control, and
suggest improvements to internal financial controls, and shall assess the adequacy of systems for
meeting statutory compliance in filing returns, especially in electronic form.
KSIIDC reserves the right to reject any quotation submitted by a firm that does not satisfy the
prescribed technical qualification criteria. KSIIDC further reserves the right to disqualify a firm at any
stage if any information, document, declaration or representation furnished is found to be false,
misleading or materially incorrect.
KSIIDC reserves the right to negotiate the financial quotation, scope, terms and conditions, or any
other aspect of the proposal with the selected firm, and to accept or reject any or all quotations,
wholly or partly, without assigning any reason and without incurring any liability to the bidders.
In the event of any dispute, difference or interpretation arising out of the selection process,
engagement or performance of the assignment, the decision of the Managing Director, KSIIDC, shall
be final and binding on all concerned parties.
The scope of the Concurrent Audit assignment shall extend to all existing departments, divisions,
units, branches, schemes and operations of KSIIDC, and shall automatically include any future
reorganised, restructured, newly created or merged departments, functions, projects, schemes or
operations during the tenure of the engagement.
The Concurrent Auditor shall undertake such additional reviews, verifications and assurance
procedures as may be considered necessary by KSIIDC from time to time.

SECTION 5 – MANPOWER, MINIMUM ATTENDANCE & AUDIT PROCESS
5.1 Nature of Deployment
Given the pre-audit nature of this assignment, a rigid requirement of on-site presence on all 365 days
of the year is not administratively practical and would disproportionately inflate cost without a
corresponding improvement in audit quality. Instead, the selected firm shall ensure continuous, neardaily coverage sufficient to prevent any backlog of files, as follows:






At least one semi-qualified Chartered Accountant/Cost & Management Accountant assistant
from the firm shall be deployed on-site at KSIIDC's registered office on all working days of the
Corporation, so that files referred for pre-audit are taken up without avoidable delay.
A Partner of the firm shall visit KSIIDC's office at least once every month, to review pending
observations, interact with the Executive Director/nodal officer, address escalations, and sign
off on the monthly report before submission.
The firm may deploy additional personnel at its own discretion where required to meet the
turnaround standard in Section 5.3, without any additional cost to KSIIDC beyond the quoted
annual fee.

<!-- page 8 -->

5.2 Attendance & Verification




The firm shall maintain a signed attendance register at KSIIDC premises, countersigned by the
nodal officer referred to in Section 5.5, recording the name and dates of presence of the semiqualified assistant, and separately recording each monthly visit of the Partner.
Failure to maintain the minimum on-site presence prescribed in Section 5.1, without valid
reason recorded and accepted by KSIIDC, or failure of the Partner to undertake the monthly
visit, shall entitle KSIIDC to proportionately reduce that month's fee and/or treat it as a material
breach under the Terms of Appointment.

5.3 Turnaround for Pre-Audit
Files referred to the Concurrent Auditor shall be cleared – i.e., examined and returned with audit
observations/comments/remarks/suggestions recorded in the respective file – within 2 (two) working
days of receipt. Files shall be taken up in the order received, save where KSIIDC directs otherwise
for reasons of urgency.

5.4 Team Continuity
The personnel nominated at the time of bid (Form 4, Annexure I) shall be deployed for the entire
financial year and shall not be substituted or diluted (e.g., replaced by less experienced personnel)
without the prior written approval of KSIIDC. Repeated or unapproved substitution shall be treated
as a material breach.

5.5 Audit Process







The audit shall be conducted at the Registered Office of KSIIDC, Bengaluru. In case of
exigencies, project sites/areas may be visited within Karnataka.
The Concurrent Auditor shall submit a consolidated report of observations made during the
month, in a report format, to the Executive Director, KSIIDC, on a monthly basis, before the
10th of the subsequent month.
Concerned departments shall take appropriate action to comply with audit observations and
submit an Action Taken Report to the nodal officer.
In case of any significant implications, the report shall be placed before the Audit Committee of
the Board for information and instructions.
The Company Secretary (in coordination with the nodal officer for Concurrent Audit) shall be
the nodal officer coordinating the work of the Concurrent Auditor, so as to ensure alignment
with the Concurrent Auditor's coordination requirements under Section 4.

SECTION 6 – CRITERIA FOR QUALIFICATION
The eligibility and qualification criteria set out below are intended to assess the bidder's capability,
experience, professional competence and resource strength for undertaking the Concurrent Audit
assignment. Bidders shall satisfy all prescribed requirements and submit the requisite supporting
documents as part of their proposal.

6.1 Technical Qualification


Self-attested copy of PAN and GST Registration, if registered.

<!-- page 9 -->










Valid Certificate of Practice issued by ICAI/ICMAI, and a self-declaration on letterhead that the
firm has been in operation for at least 5 years.
Minimum of 3 Chartered Accountants/Cost & Management Accountants in the firm (including
partners), of whom at least 1 shall be a fellow member.
Minimum 3 years' experience conducting Concurrent Audit and/or Statutory Audit for any
company, bank, PSU or financial institution, with reference details in the prescribed formats
(Form 5 / Form 6, Annexure I).
A simple undertaking (single paragraph on letterhead) to deploy the team and manpower
prescribed in Section 5, naming the proposed Partner-in-charge and the semi-qualified
assistant(s).
Staff deployed shall have working knowledge of Kannada (reading and writing) – a selfdeclaration on letterhead suffices; no separate certificate required.
Brief CV (maximum 1 page each) of the proposed Partner-in-charge and the semi-qualified
assistant(s).

6.2 Financial Qualification
No minimum financial threshold has been prescribed for bidder eligibility under this RFQ. Firms
satisfying the Technical Qualification Criteria shall qualify for financial evaluation. The award of the
assignment shall be based on the prescribed Technical-cum-Financial Evaluation methodology and
not exclusively on the lowest quoted fee.

SECTION 7 – TERMS OF APPOINTMENT
The appointment shall be for a period of one (1) year, extendable for a further period of one (1) year
at the sole discretion of KSIIDC, based on satisfactory performance and compliance with the
requirements of this RFQ.
The selected firm shall nominate one of its Partners as a nodal person to interact with the Company
Secretary/nodal officer of KSIIDC, and shall be the single point of contact with the firm.
The firm shall ensure that at least one qualified Chartered Accountant is nominated at all times during
the year for discussions and clarifications.
The firm shall discuss observations with the concerned Heads of Departments and Senior Executives
before finalising the report.
The firm shall carry out the Concurrent Audit as prescribed in Section 5 and shall submit the monthly
report to the Executive Director, KSIIDC; any major lapses or lacunae shall be reported immediately,
without awaiting the monthly report.
It shall be the responsibility of the Concurrent Auditor to: comment on the accounting records,
systems and controls examined, identify deficiencies and weaknesses and recommend
improvements; highlight mistakes that are material and have a significant impact on the Corporation's
performance; assist Management on related finance and accounting matters as required; undertake
any other work related to the assignment without claiming additional fee; and audit any other matter
deemed fit in the interest of the Corporation.

<!-- page 10 -->

Action taken on the findings of previous report(s) shall form part of each subsequent report. The
Concurrent Auditor shall revise a report if required by KSIIDC.
The Concurrent Auditor shall act as a warning system and report any issues requiring remedial action
immediately, rather than awaiting the monthly report.
A penalty of 1% of the fee agreed for the relevant period shall be levied for each week of delay in
submission of the Concurrent Audit report, attributable to the firm. Delays exceeding four weeks may
result in termination of the engagement.
The annual fee payable to the firm shall be paid in monthly instalments at the end of each month,
against submission of the monthly audit report and compliance with the deployment requirements
specified in Section 5.
KSIIDC reserves the right to terminate the engagement in the event of unsatisfactory performance,
material breach of terms, insolvency, or any other reason deemed appropriate by KSIIDC.
KSIIDC shall provide reasonable workspace for conducting the audit.
The firm shall not outsource or sub-contract any part of the assignment and shall deploy only the
personnel proposed in the bid or approved replacements thereof.
The selected firm shall communicate acceptance in writing within five (5) working days from the date
of receipt of the Letter of Award.

SECTION 8 – ESTIMATED COST & ABNORMALLY LOW BID SCRUTINY
8.1 Basis of Estimated Cost
The estimated cost of the assignment has been determined based on the minimum deployment
requirements stipulated in Section 5 – near-continuous on-site presence of 1 semi-qualified assistant
(approx. 240 working days p.a.) and a monthly on-site visit by a Partner/Qualified CA (12 days p.a.)
– taking into account prevailing market rates in Bengaluru for the prescribed personnel, and
reasonable provision for off-site reporting, review and coordination.
Component

Basis

Estimated Cost (Rs.)

Semi-qualified Assistant (nearcontinuous on-site presence)

~240 person-days @ Rs. 1,100–
1,400/day

2,64,000 – 3,36,000

Partner / Qualified CA (monthly
visit)

12 days @ Rs. 5,000–6,500/day

60,000 – 78,000

Off-site work (report compilation,
review, coordination)

~15% of on-site cost

48,600 – 62,100

Total (excl. GST)

3,72,600 – 4,76,100

Estimated Cost for the Assignment (excluding GST): Rs. 4,00,000/- per annum.

<!-- page 11 -->

8.2 Fee Quotation
Bidders shall quote a single all-inclusive annual professional fee, exclusive of applicable GST, in the
format prescribed in Form 2 (Break Up of Financial Proposal, Annexure II). The quoted fee shall
cover the entire scope of work and the minimum deployment requirements specified in Section 5,
and shall be deemed to include all costs associated with performance of the assignment, including
professional fees, local conveyance within Bengaluru, report preparation, communication,
administrative overheads and all incidental expenses. No separate reimbursement shall be
admissible for such expenses.
Travel expenses incurred for audit of project sites outside Bengaluru, if specifically required by
KSIIDC, shall be reimbursed in accordance with applicable KSIIDC norms, subject to prior approval
and submission of supporting documents.
Note: KSIIDC reserves the right to seek clarification on any financial proposal that, in its opinion,
appears significantly lower or higher in relation to the estimated scope and resource requirements
of the assignment.

8.3 Abnormally Low Bid Clause
Where a technically qualified bidder's financial quote is less than 75% of the Estimated Cost stated
in Section 8.1 (i.e., below Rs. 3,00,000/-), KSIIDC shall, before including that bid in the financial
evaluation, call upon the bidder to furnish a written justification demonstrating how it proposes to
deploy the minimum manpower prescribed in Section 5 at the quoted price, including a break-up of
manpower cost. If the justification is found unsatisfactory by Management, KSIIDC reserves the right
to exclude such bid from further evaluation, recording reasons in writing.

SECTION 9 – METHOD OF EVALUATION (TECHNICAL-CUM-FINANCIAL)
Selection shall not be made on an L1-among-technically-qualified basis. The final selection shall be
made on a combined Technical and Financial score (70:30), as follows:
Criteria

Maximum Marks (Weightage)

Method of Scoring

Technical

70

Highest technically scoring bidder
gets 70 marks; others scored
proportionately (Technical
Score/Highest Technical Score ×
70)

Financial

30

Lowest quote gets 30 marks;
others scored proportionately
(Lowest Quote/Bidder's Quote ×
30)

<!-- page 12 -->

9.1 Technical Scoring Break-up
Criteria

Marks

Documents

Years of standing of the firm
(min. 15 marks for 5 yrs;
+2/additional yr, max 25)

25

ICAI/ICMAI registration copy

Experience in Concurrent Audit
and/or Statutory Audit/internal
Audit of any
company/bank/PSU/financial
institution (min. 15 marks for 3
yrs; +3/additional yr, max 30)

30

Engagement letters / reference
details

Number of CAs/CMAs in the firm,
incl. fellow members (min. 10
marks for 3; +2 for each
additional, max 20)

20

ICAI/ICMAI registration copy

Proposed team – Partner-incharge (10 marks with minimum
10 yrs exp) and semi-qualified
assistant(s) (15 marks with
minimum 5 yrs exp) named, with
brief CVs as required in Section
6.1

25

Undertaking + CVs

(Total Technical): 100

9.2 Minimum Qualifying Technical Score
A bidder shall be considered technically qualified only if it secures a minimum score of 75 marks out
of 100 in the Technical Evaluation. Only bidders meeting this threshold shall be eligible for Financial
Evaluation; bidders scoring below it shall be disqualified, irrespective of their financial quotation.

9.3 Procedure
The Technical Proposals shall be evaluated first in accordance with the criteria specified in this RFQ
and assigned technical scores.
Financial Proposals of only those bidders meeting the minimum qualifying technical score prescribed
under Section 9.2 shall be opened and evaluated. Financial evaluation shall be based on the annual
fee quoted excluding GST.
The final ranking of qualified bidders shall be determined based on the combined Technical and
Financial scores, in accordance with the evaluation methodology specified in this Section.
The bidder securing the highest combined score shall be recommended for award of the assignment.
In the event of a tie in the combined score, preference shall be given to the bidder securing the
higher Financial Score.

<!-- page 13 -->

The decision of KSIIDC with regard to evaluation, ranking and selection of the successful bidder
shall be final and binding on all bidders.

SECTION 10 – PROCEDURE FOR SUBMISSION
Bidders shall submit their Technical Proposal and Financial Proposal in two separate sealed covers,
duly superscribed, addressed to the Executive Director, KSIIDC, at the address specified in Section
1, on or before the due date and time prescribed in this RFQ.
All pages of the proposal and supporting documents shall be duly signed and sealed by the
authorised signatory of the bidder.
Conditional, incomplete or non-responsive proposals shall be liable to rejection.
KSIIDC reserves the right to accept or reject any proposal, wholly or partly, without assigning any
reason whatsoever, and to negotiate the terms of engagement with the selected bidder.
Any clarification regarding this RFQ may be sought from the Company Secretary, KSIIDC, at the
contact details provided in Section 1.
Proposals received after the prescribed due date and time shall not be considered.

********************

<!-- page 14 -->

ANNEXURES

<!-- page 15 -->

STANDARD FORMATS – ANNEXURE – I
TECHNICAL PROPOSAL
(In Company’s Letter Head)
FORM 1- TECHNICAL PROPOSAL
To:
The Executive Director
Karnataka State Industrial & Infrastructure Development Corporation Limited (KSIIDC)
‘Khanija Bhavan’
No.49, Racecourse Road
Bengaluru-560001
Sir,
Sub:Concurrent Audit Services to KSIIDC- Proposal
We, the undersigned offer to provide the Concurrent Audit services for the above in
accordance with your Request for Quotation (RFQ) dated 01.10.2026. We are hereby
submitting our proposal as per Form-1 to 6 in Annexure I.
If negotiations are held during the period of validity of the Proposal, i.e., before 10.10.2027
we undertake to negotiate. Our Proposal is binding upon us and subject to the modifications
resulting from contract negotiations.
We understand you are not bound to accept any Proposal you receive.
Thanking you,
Yours sincerely,
Authorized Signature:
Name and Title of Signatory:
Name of CA/CMA Firms:
Address:

<!-- page 16 -->

FORM 2 - APPLICATION FOR TECHNICAL QUALIFICATION
(In Company’s Letter Head)
Sl.No
1.
2.

3.

Details from the Applicant
Name and address of the Chartered Accountant’s
/Cost & Management Accountant’s Firm
Firm Registration No. (ICAI/ICMAI) and Date of
Registration
(Enclose copy of the Certificate)
Currency of the Certificate:
(Enclosed Self attested Certificate (In Company’s
Letter Head)

Submissions

FRN: ________
Date: ________
Yes/No

4.

The CA / CMA firm shall hold a valid Certificate of Practice
issued by Institute of Chartered Accountants of India /
Institute of Cost Accountants of India, a copy of which shall
be furnished. Also, a self-declaration in company’s letter
head that the firm is in operation for at least 5 (five) years
should be furnished.

Yes/No

5.

The CA / CMA firm shall submit self-attested copy of PAN
card.

(PAN No.)

6.

The CA / CMA firm shall submit self-attested copy of GST
Registration, if registered.

(GST No.)

7.

[Intentionally omitted]

8.
A

B

9.

N/A

The firm shall furnish a self-declaration for having met the requirements
stipulated in (A) & (B) below by indicating the names of CAs / CMAs, names of
companies, banks, PSUs and financial institutions who have availed its services
in the past. (In Company’s Letter Head)
The firm should have a minimum of 3 Chartered No. of CA/CMA, the
Accountants / Cost & Management Accountants and of firm has including
which at least 1 should be a fellow member (including Fellow Members (Self
partners), (Self-attested Certificate shall be submitted in attested Certificate
company’s letter head)
enclosed)
The firm should have a minimum of 3 years’ experience
conducting Concurrent Audit and/or Statutory Audit for any
company, bank, PSU or financial institution, (Self-attested
Certificate in company’s letterhead shall be enclosed- As
per Form 5 (Concurrent Audit) / Form 6 (Statutory
Audit/Internal Audit) in Annexure I)

The CA / CMA firm shall furnish an undertaking
separately on its letterhead as an enclosure to deploy

Yes/No

Yes/No

<!-- page 17 -->

10.

11.
12.
13.

the team and manpower prescribed in Section 5 of the
RFQ, naming the proposed Partner-in-charge and the
semi-qualified assistant(s).
A brief write up on the audit team proposed to be
deployed shall be furnished (Refer Form-4 in
Annexure I)
Self-declaration that the staff to be deployed have
working knowledge of Kannada (reading and writing)
(In Company’s Letter Head)
Name, address and telephone number, fax, Email of
the contact person (s) at Bengaluru
Curriculum vitae (CV) for proposed Key personnel to
be deployed (brief CV, maximum 1 page each). (Refer
Form-3 in Annexure I)

Yes/No

Yes/No

Yes/No

Note: All the documents mentioned above (in Form 2 to 6) shall be submitted to registered
office of KSIIDC, Bengaluru.

<!-- page 18 -->

FORM 3- FORMAT OF CURRICULUM VITAE (CV) FOR PROPOSED
KEY PROFESSIONAL STAFF
(In Company’s Letter Head)
Proposed Position
Name of Concurrent Audit Firm
Name of Staff
Profession
Date of Birth
Nationality
Years with Firm/Entity
Total post-qualification experience (years)
Membership in Professional Societies
Detailed Tasks Assigned
Key Qualifications:
[Give an outline of staff member’s experience and training most
pertinent to tasks on assignment. Describe degree of responsibility
held by staff member on relevant previous assignments and give
dates and locations.]
Education:
[Summarize college/university and other specialized education of
staff member, giving names of schools, dates attended, and
degrees obtained.]
Employment Record
[Starting with present position, list in reverse order the relevant
employments and assignments, giving dates, names of employing
organizations, titles of positions held, and locations of assignments.
Also give types of activities performed. The CV shall not exceed one
page.]
Languages:
[For each language indicate proficiency:
Excellent, good, fair, or poor; in speaking, reading and writing]

Certification:
I, the undersigned, certify that to the best of my knowledge and belief, these data correctly
describe me, my qualifications, and my experience.
Date:
Place:
(Signature of Staff member and authorized representative of the CA
/ CMA Firms)
Full name of staff member: __________________________________________
Full name of authorized representative: ________________________________

<!-- page 19 -->

FORM 4-TEAM COMPOSITION AND TASK ASSIGNMENT
(In Company’s Letter Head)
1. Professional Staff
Sl.
No.

Name

Position /
Total postqualification
experience
(years)

Task

Knowledge of
Kannada
(Reading &
Writing)
Yes/No

1.
2.
3.
4.
5.
6.
a. Support Staff
Sl.
No.

1.
2.
3.
4.
5.
6.

Name

Position

Task

Knowledge of
Kannada
(Reading &
Writing)
Yes/No

<!-- page 20 -->

<!-- page 21 -->

Note: Only the Partner-in-charge and the semi-qualified assistant(s) required under
Section 5 of the RFQ shall be evaluated under Section 9.1, and shall be subject to
Section 5.4 (Team Continuity) and Section 7 (no sub-contracting).
FORM 5- CONCURRENT AUDIT FIRM’S REFERENCES
(In Company’s Letter Head)
Relevant Services Carried out (covering the entire period of experience claimed)
That Best Illustrate Qualifications
Using the below, provide information on each reference assignment for which your
firm/entity, either individually as a corporate entity or as one of the major companies within
an association, was legally contracted.
Place:
Assignment Name:
Key Professional staff Provided by your
Firm/entity (Profiles)

Location within country
Name and type of entity (Company / Bank
/ PSU / Financial Institution)

No. of Staff-Months: duration of
assignment

Address:
Start Date
(Month/year)

No. of Staff

Completion Date
(Month/year)

Approx. Value of Services

Name of Associates CA/CMA firms, if any:
Name of Senior staff (co-coordinator, Team Leader) involved, and functions performed.
Narrative Description of Project
Description of Actual Services Provided by your Staff:

<!-- page 22 -->

FORM 6- STATUTORY AUDIT FIRM’S REFERENCES
(In Company’s Letter Head)
Relevant services carried out (covering the entire period of experience claimed) that
best illustrate qualifications
Using the below, provide information on each reference Statutory Audit assignment for which
your firm/entity, either individually as a corporate entity or as one of the major companies
within an association, was legally contracted.
Place:
Assignment Name:
Key Professional staff Provided by your
Firm/entity (Profiles)

Location within country
Name and type of entity (Company / Bank
/ PSU / Financial Institution)

No. of Staff-Months: duration of
assignment

Address:
Start Date
(Month/year)

No. of Staff

Completion Date
(Month/year)

Approx. Value of Services

Name of Associates CA/CMA firms, if any:
Name of Senior staff (co-coordinator, Team Leader) involved, and functions performed.
Narrative Description of Project
Description of Actual Services Provided by your Staff:

<!-- page 23 -->

STANDARD FORMATS – ANNEXURE – II
(In Company’s Letter Head)
FORM 1- FINANCIAL PROPOSAL
To
The Executive Director
Karnataka State Industrial & Infrastructure Development Corporation Limited (KSIIDC)
‘Khanija Bhavan’
No.49, Racecourse Road
Bengaluru-560001
Sir,
Subject: Concurrent Audit Services to KSIIDC – Financial Proposal
We, the undersigned, offer to provide the Concurrent Audit services for the above in
accordance with your Request for Quotation (RFQ) dated 01.10.2026. Our attached
quotation (annually) is for the sum of Rs.______[Amount in words] excluding GST.
Our quotation shall be binding upon us subject to the modifications resulting from
contract negotiations, up to expiration of the validity period of the proposal, i.e., 04.01.2027.
We undertake that, in competing for (and, if the awards are made to us, in executing)
the above contract, we will strictly observe the laws against fraud and corruption in force in
India namely “Prevention of Corruption Act 1988”.
We understand you are not bound to accept any proposal you receive.
Thanking you,
Yours Sincerely,

Authorized Signature:
Name and Title of Signatory:
Name of CA/ CMA Firm’s:
Address:

<!-- page 24 -->

FORM 2- BREAK UP OF FINANCIAL PROPOSAL
(In Company’s Letter Head)
Note: The financial proposal breakups (Hard Copy) shall be enclosed in the sealed
Financial Proposal cover
SUMMARY OF COSTS
Sl. No.
I

II
III

Description
Partner / Qualified CA/CMA (monthly on-site
visit – 12 days)

Annual Amount (in Rs.)

Semi-qualified Assistant (on-site on all
working days)
Off-site work, reporting, coordination and
overheads
TOTAL ANNUAL FEE (excluding GST)
GST
GRAND TOTAL COST (including GST – for
information only)

Authorized Signatory
It may be noted that no local conveyance and out of pocket expenses at Registered Office,
Bengaluru will be reimbursed / paid. However, if the Audit team needs to travel outside
Bengaluru on audit work, TA/DA and out of pocket expenses will be reimbursed as per
KSIIDC norms, subject to prior approval of KSIIDC and submission of supporting
documents.
Note: The Total Annual Fee (excluding GST) shown above shall be the same as the amount
quoted in Form 1 and shall be the basis for financial evaluation under Section 9 of the RFQ.

<!-- page 25 -->
