---
doc_id: "c29cf1f7d3afab13"
source_url: "https://www.iiitb.ac.in/includefiles/userfiles/files/RFP_OAN%20MahVISTAAR%20Project_COSS-IIIT-B_27_06_25.docx.pdf"
ministry: "International Institute of Information Technology Bangalore, Karnataka"
title: "Tender Document"
date: ""
pages: 69
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e2da6bbed54b42f7"
---

<!-- page 1 -->

REQUEST FOR PROPOSAL (RFP)
FOR
Expansion and support service for
MahaVISTAAR

Center for Open Societal Systems
International Institute of Information Technology Bangalore,
26/C, Electronics City Phase 1, Hosur Road,
Bengaluru, Karnataka – 560 100

This document is the property of the International Institute of Information Technology, Bangalore
(IIITB). It may not be copied, distributed, or recorded on any medium, electronic or otherwise,
without IIITB’s written permission. Use of contents given in this document, even by the authorized
personnel/agencies for any other purpose other than the purpose specified herein, is strictly
prohibited as it shall amount to copyright violation and thus shall be punishable under the Indian
law.

<!-- page 2 -->

Request for Proposal

THIS RFP DOCUMENT IS NOT TRANSFERABLE

Bidders are advised to study the RFP document carefully. Submission of Bid shall be deemed to have
been done after careful study and examination of the RFP document with full understanding of its
implications.
The response to this RFP should be full and complete in all respects. Incomplete or partial Bids shall
be rejected. The Bidder must quote for all the items asked for in this RFP.

The Bidder shall bear all costs associated with the preparation and submission of the Bid, including
cost of presentation and demonstration for the purposes of clarification of the Bid, if so desired by
IIITB. IIITB will in no case be responsible or liable for those costs, regardless of the conduct or
outcome of the bidding process.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 2

<!-- page 3 -->

Request for Proposal

Disclaimer

IIITB reserves the right to alter/change/modify the procurement of any of the services, hardware, or
software items of this RFP. Thus IIITB, at its discretion, IIITB shall leverage the unit rates provided by
the Bidder in case of an increase or decrease in any of the services, software, or hardware proposed
by the Bidder throughout the tenure of the Contract.
IIITB reserves the right to negotiate, change, modify or alter any/all the items, terms, and provisions
of the RFP/agreement entered pursuant to the RFP and may request additional information if
required from the Bidder during the contract period.
IIITB also reserves the right to withdraw this RFP without assigning any reason and without any
liability to the Bidder or any other person or party.
The Licenses and related products and services under this RFP should be applicable to all locations
identified by IIITB for the execution of the project.
The RFP document is not a recommendation, offer, or invitation to enter into a contract, agreement,
or other arrangements in respect of the services.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 3

<!-- page 4 -->

Request for Proposal

Contents
1 Introduction & Objectives​

9

1.1 Background and Context​

9

1.2 About IIITB​

9

1.4 RFP Schedule and Details​

10

1.5 Project Timelines​

12

1.6 Availability of RFP document​

12

2 Scope of Work​

12

2.1 Maintain the registry and gateway (both sandbox and production) set up for Maha Vistaar:​

13

2.2 Use case visualization and schema building :​
2.3 Documentation and Onboarding starter kits :​
2.4 Onboarding of the network participants :​
2.5 Network monitoring:​
2.6 SaaS provider platform :​
2.7 Catalogue publishing platform; onboarding the providers :​
2.8 Building Custom features and integrations:​
2.9 Evolving the technical architecture of OAN​
2.10 Integration with other network​
2.11 AI & AI Agent enablement​
2.12 Network Governance and Grievance Redressal​
2.13 Infrastructure Provisioning and AI Backend Setup​
2.14 Content Processing Services​
2.15 AI Query and Interaction Services​
2.16 Composable Agent-Based Design​
2.17 Multilingual Conversational Intelligence​
2.18 Context-Aware Information Retrieval​
2.19 Proactive Safety and Input Governance​
2.20 API Suite Development​
2.21 Frontend Integration and Multi-Channel Interface Support​
2.22 Telemetry and Monitoring Services​
2.23 Usage Analytics Dashboard​
2.24 Deployment and Integration​
2.25 Support and Maintenance​
2.26 Capacity Building:​
2.27 DPG Packaging:​
2.28 Reporting Structure:​

13
14
14
14
14
15
15
15
15
15
16
16
16
17
17
17
17
18
18
18
18
19
19
19
20
20
21

2.29 Quality Checks and Monitoring​

21

2.30 Project Management​

22

2.30.1 Project Governance​

22

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 4

<!-- page 5 -->

Request for Proposal

2.30.2 Steering Committee​

22

2.30.3 Transition and Exit Management​

22

3 Response Guidelines​

22

3.1 Guidelines for RFP Technical Response​

22

3.2 Guidelines for RFP Commercial Response​

24

3.2.1 Commercial Model​

24

3.2.2 Format for Commercial Model​

24

4 Evaluation Criteria and Process​

24

4.1 Objective of the Evaluation Process​

24

4.2 Stage 1 – Evaluation of Eligibility Criteria​

25

4.3 Stage 2 – Evaluation of Technical Bid​

26

4.4 Stage 3 - Commercial Bid Evaluation​

27

5 Agreements and Agencies​

28

6 Payments terms, Service Level Agreement and Penalties​

28

6.1 Payment terms​

28

6.2 Service Level Agreements​

29

7 Instructions to Bidder​

29

7.1 Two Bid System​

29

7.1.1 ENVELOPE - I (Technical Bid)​

29

7.1.2 ENVELOPE - II (Commercial Bid)​

29

7.2 EMD​

30

7.3 Content of the Bid​

30

7.3.1 Eligibility Bid Documents​

30

7.3.2 Technical Bid Documents​

31

7.3.3 Commercial Bid Documents​

31

7.4 Late Bids​

31

7.5 Opening of Bids​

31

7.6 Proposal Modification​

32

7.7 Clarification of Bids​

32

7.8 Result Notification​

32

7.9 Cost of Responses​

32

7.10 Precedence of Documents​

33

7.11 No commitment to accept lowest or any Bid​

33

7.12 Non-Transferable RFP​

33

7.13 Soft Copy of RFP Document​

33

7.14 Addenda​

33

7.15 Pre Bid meeting​

33

7.16 Rejection of Bids​

34

7.17 Amendment to Contract​

34

7.18 Correspondence and Notices​

34

7.19 Notification of Award​

34

7.20 Signing of Contract​

34

8 Terms and Conditions​
8.1 Amendment to Bid Document​

34
35

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 5

<!-- page 6 -->

Request for Proposal

8.2 Consortium​

36

8.3 Conditional Bids​

36

8.4 Submission of Bids​

36

8.5 Performance Security​

36

8.6 Pre-Bid Meeting​

36

8.7 Payment Schedule​

37

8.8 Currency of Payments​

37

8.9 Delay in Bidder’s Performance​

37

8.10 Repeat Order​

37

8.11 Other RFP Requirements​

37

8.12 Completeness of the Project​

38

8.13 Canvassing / Contacting​

38

8.14 Indemnity​

38

8.15 Inspection of records​

38

8.16 Publicity​

38

8.17 Solicitation of Employees​

38

8.18 Penalties on Non Compliance of SLA​

39

8.19 Liquidated Damages​

39

8.20 Confidentiality​

39

8.21 Force Majeure​

40

8.22 Resolution of disputes​

41

8.23 Waiver​

42

8.24 Violation of terms​

42

8.25 Termination for Default​

42

8.26 Termination for Insolvency​

43

8.27 Information Ownership​

43

8.28 Sensitive Information​

43

8.29 Technological Advancements​

43

8.30 Governing Language​

43

8.31 Applicable Law​

43

8.32 Prices​

43

8.33 Deduction​

44

8.34 Taxes and Duties​

44

8.35 No Claim Certificate​

44

8.36 Rights reserved by IIITB​

44

8.37 Subcontracting​

44

8.38 Rejection of Bids​

44

9 Annexures​

45

Annexure 1: Pre Bid Query Format​

45

Annexure 2: Cover Letter​

47

Annexure 3: Confirmation of Eligibility Criteria​

48

Annexure 4: Undertaking for Data and Information Security​

50

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 6

<!-- page 7 -->

Request for Proposal

Annexure 5: Technical Bid format​

52

Annexure 6: Statement of No Deviation from RFP Terms and Conditions​

53

Annexure 7: Bidder’s Past Experience​

54

Annexure 8: Commercial Compliance Certificate​

55

Annexure 9: Commercial Bid Form​

56

Annexure10: Format of Bank Guarantee​

57

Annexure 11: Authorization Letter to Attend - Bid Opening​

59

Annexure 12: Proforma for Performance Bank Guarantee​

60

Annexure 13: Grievance Redressal Policy IIITB​

62

Annexure 14: RFP Background and Program Overview​

64

Glossary :
IIITB
GOI

International Institute of Information Technology, Bangalore
Government of India

BG
Bidder

Bank Guarantee
The organization submitting the proposal who will have single point
responsibility for execution of scope and deliverables as required by this
Request for Proposal.

CD

Compact Disk

DD

Demand Draft

DIT

Department of Information Technology

DOT
EMD
EOD

Department of Telecommunication
Earnest Money Deposit
End of Day

FY

Financial Year

GRS

Grievance Redressal System

HO

Head Office

IT

Information Technology

ITD

Information Technology Department

MIS

Management Information System

PBG
PO
RFP

Performance Bank Guarantee
Purchase Order
Request For Proposal

RO

Regional Office

SLA

Service Level Agreements

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 7

<!-- page 8 -->

Request for Proposal

1​ Introduction & Objectives
1.1​ Background and Context
OpenAgriNet (OAN) is a Digital Public Infrastructure (DPI)^AI initiative designed to transform the agriculture
sector by enabling an open, interoperable, and inclusive digital ecosystem. Anchored in the principles of
decentralization and digital public-good architecture, OAN leverages the Beckn Protocol to facilitate seamless
data exchange and service discovery across diverse actors in the agricultural value chain. As a flagship
implementation of this vision, the Maha Vistaar program is being deployed in Maharashtra to demonstrate
how a federated open network can power farmer-centric solutions ranging from access to credit and inputs to
advisories and market linkages. Maha Vistaar serves as both a reference implementation and a testbed for
evolving the core OAN infrastructure, integrating AI-driven interfaces, building state-level capacities, and
enabling service providers to operate through a unified, trusted network.
To know more visit : https://openagrinet.global/
1.2​ About IIITB
The International Institute of Information Technology Bangalore (IIITB), deemed to be a University, was
established in 1998 with a vision to contribute to the IT world through education and research,
entrepreneurship, and innovation. Intersecting technology and society, IIITB has grown in stature to become
an institution of considerable repute with its unique model of education, research, and industry interaction. It
works in partnership with the corporate sector while retaining the freedom of an academic institution.
Inspired by other renowned institutions, it strives to emulate an academic culture that is on par with the best
international institutions. The institute is a registered not-for-profit society supported jointly by the
Government of Karnataka and the IT industry.
To know more visit : https://www.iiitb.ac.in/
1.3​ About COSS
The Center for Open Societal Systems (COSS) at IIIT-Bangalore was established with a vision to positively
impact a billion lives globally by 2030 through the adoption of open digital ecosystems. COSS builds on
India’s leadership in Digital Public Infrastructure (DPI) and works to enable scalable, inclusive, and
interoperable digital solutions that address complex societal challenges.
COSS acts as an anchor institution that brings together governments, academic institutions, nonprofits,
private sector players, and open-source communities. Its approach is rooted in open standards, shared
digital infrastructure, and participatory governance. The Center supports research, capacity building, and
implementation of Digital Public Goods (DPGs) across sectors such as agriculture, education, health, and
governance — both in India and globally.
By fostering collaboration and open innovation, COSS aims to catalyze the creation and adoption of
foundational digital systems that empower societies and ensure equitable access to opportunities.
To know more visit : https://coss.org.in/

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 8

<!-- page 9 -->

Request for Proposal

1.4​ RFP Schedule and Details
General Details
RFP Number

IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR

Department Name
Scope of Work

Centre for Open Societal Systems, IIITB
As mentioned in Section 2

Mode of RFP Submission
RFP Type

Offline
Open

Type of Contract

Information Technology Services

Bidding Type
Base Currency
Consortium

Indigenous
INR (₹)
Not Allowed

Key Dates
Document Download Start Date

3rd July 2025, 10 am

Last Date and time for submission of PreBid Queries
Pre-bid Meeting

11th July 2025, 5 pm
The sessions will be conducted on 15th July 2025, with
slots available between 10:00 AM and 5:00 PM.
Participants can book a 30-minute time slot based on
their preference.
To receive the meeting link, please write to
oansocial@coss.org.in.

Kindly ensure that you block your preferred slot by 11th
July 2025.
Clarification/Amendments ( if any)
Will be published on IIITB website’s tender page
https://www.iiitb.ac.in/tenders
Last Date and Time for Bid Submission (Both 17th July 2025, 5 pm
technical and commercial) Refer to Section 7
Technical presentations by selected Bidders 22nd July 2025, 10 am - 6 pm (Online or Offline).
(Online)
Offline Venue: 86, 7th Cross Road, KHB Block,
Koramangala 4-B Block, 4th Block, Koramangala,
Bengaluru, Karnataka – 560034
Online: The meeting will be held via Zoom and will be
recorded.
The slots for both online and offline sessions will be
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 9

<!-- page 10 -->

Request for Proposal

communicated to the selected bidders via email.
Declaration of Shortlisted Bidders for
Will be published on IIITB website’s tender page
Commercial Bid Opening
https://www.iiitb.ac.in/tenders and also notified via
email on 3rd July 2025
Date and Time for Commercial Bid Opening Will be published on IIITB website’s tender page
(Tentatively 24th July 2025, time and date to be
confirmed via email to qualified bidders )
Declaration of Successful Bidder
Will be published on IIITB website’s tender page
https://www.iiitb.ac.in/tenders and also notified via
email
Results will be announced by 25th July 2025, by 5 pm
Notification of Award and Issue of Purchase Will be published on IIITB website’s tender page
Order
https://www.iiitb.ac.in/tenders
Bid Validity Period (in Days)
12 Months
Documents to be submitted
physically
Tender processing Fee (DD)
Bank Guarantee/DD/NEFT for EMD
Other documents supporting Eligibility Criteria, etc. as
per RFP.
Offline/Online
Mode​ of​Document​ Fee
Payment
Mode of EMD Payment
Offline/Online
Payment Details
Tender processing Fee
(Non- refundable)
EMD Amount

₹10,000

EMD Payable to & at

₹6,00,000
(MSMEs registered with the Central Purchase
organization or the ​concerned Ministry or department
are exempted from Bid Security/EMD. MSME to
mention the same and provide the appropriate
Registration certificate)
The EMD amount will be refunded to all unsuccessful
bidders. For the selected bidder, the EMD amount will
be retained and adjusted against the Performance
Bank Guarantee requirement.
As per RFP

Performance Bank Guarantee

3% of the Contract Value

Other Details
Eligibility Criteria

As per RFP

General Terms and Conditions

As per RFP

Bid Submission Information

The bidders must fulfill the Eligibility criteria for being
eligible to bid.
The prospective bidders may email their queries and suggestions for any changes required to be
made in the bid document through e-mail as per the dates mentioned above. The suggestions and
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 10

<!-- page 11 -->

Request for Proposal

queries shall be responded to in the pre-bid meeting as per the dates mentioned above and
subsequent changes made based on the suggestions and clarifications as above shall be deemed to
be part of the RFP document.
No suggestions or queries shall be entertained after the last date for pre-bid queries specified above.
The Demand Draft on account of tender processing fees should be drawn on Scheduled Commercial
bank in favor of ‘International Institute of Information Technology Bangalore’ along with physical
copies of all the documents mentioned in the RFP in support of eligibility criteria etc. must be
received at the following address before the date
and time of submission of bid.
Tender processing fee or EMD may be paid online (by NEFT) using below details. The bidder should
include payment transaction reference and other details as part of the technical bid documents.
Details for Online Payment:
Account Holder Name: International Institute of Information Technology - Bangalore
Bank Name: Punjab National Bank
Branch Name and Address: United Building, Plot No - 100, Electronic City, Bangalore 561229 (Ph. No.:
080-28520014)
Bank Account Number: 1238011010536 IFSC Code: PUNB0123820 MICR Code: 560024069 Swift
Code: PUNBINBBISB PAN: AAATI1037P
Contact details of COSS, IIITB:
Ms. Kirti Pandey
Mission Director , OAN
Centre of Open Societal Systems (COSS),​
International Institute of Information Technology Bangalore (IIIT-B), 26/C Electronics City Phase 1,​
Off Hosur Road, Opposite Infosys Campus, Bangalore 560100, India.
Email : oansocial@coss.org.in
1.5​ Project Timelines
The Bidder is expected to start at the earliest and adhere to timelines outlined in subsequent sections of
this RFP.
Notes:
●​ IIITB, at its discretion, shall have the right to alter the quantities based on the implementation plan.
This will be communicated formally to the Bidder during the implementation, if a need arises.
●​ The Bidder is required to provide a detailed strategy to IIITB to be able to meet the timelines; if the
Bidder has a faster and more effective solution, the same may be discussed and agreed by IIITB.
1.6​ Availability of RFP document

i.​

RFP document containing conditions of pre-qualification, detailed requirement specifications
including the terms and conditions shall be downloaded from Institute’s website (URL:
https://www.iiitb.ac.in/tenders)

ii.​

Please note that the Institute shall not accept any liability for non-receipt of bid document(s) in
time.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 11

<!-- page 12 -->

Request for Proposal

2​ Scope of Work
This RFP is being issued to identify a competent vendor to support the next phase of implementation
and expansion of the OpenAgriNet – Maha Vistaar network. The selected partner will be responsible
for enhancing the core digital infrastructure, expanding the network’s reach, deepening AI
capabilities, and ensuring robust governance and support systems.
Overview : Open AgriNet Website
Objectives: The key objectives of this engagement include:
I.​

Expand the Open Network Ecosystem:​
Onboard new network participants and service providers to broaden the reach and
functionality of the OpenAgriNet Maha Vistaar ecosystem, enabling greater inclusion and
diversity of services for end users​

II.​

Enhance the AI Layer:​
Improve the performance and contextual relevance of the AI layer through better large
language model (LLM) tuning, support for multiple languages, and region-specific knowledge
representation to ensure hyper-personalised and locally-relevant interactions.​

III.​

Implement New Prioritised Use Cases:​
Work in close collaboration with the Maha Vistaar team to define, design, and integrate new
high-impact agricultural use cases into the OpenAgriNet framework.​

IV.​

Strengthen Governance and Operational Infrastructure:​
Enhance the governance, monitoring, security, and grievance redressal capabilities of the
network to ensure trust, accountability, and operational resilience at scale.​

V.​

Build Internal Capacity and Support Rollout:​
Design and deliver capacity-building programs for the Maha Vistaar IT team and provide
technical assistance for the successful rollout and adoption of the platform across regions.

Network
2.1​ Maintain the registry and gateway (both sandbox and production) set up for Maha

Vistaar:
The selected vendor will be responsible for the maintenance and continuous improvement of the
registry and gateway components for both sandbox and production environments for the Network.
This includes
●​ Infrastructure provisioning
●​ High availability and disaster discovery and periodic backups
●​ Timely maintenance for the registry and gateway components
●​ Network health Monitoring using dashboards, monitor uptime
●​ Network Alerts
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 12

<!-- page 13 -->

Request for Proposal

2.2​ Use case visualization and schema building :
As and when requested by Maha Vistaar team the selected vendor will define and articulate and
develop key agricultural use cases by creating visual models and developing domain-specific
Beckn-compatible schemas to enable seamless service discovery and fulfillment across the network.
This includes
●​ Use case Identification
●​ Use case visualization - creating flow diagrams, user journey and transaction life cycles etc.. for
each use cases
●​ Schema and API design
●​ Build domain specific schema and API definitions in adherence with Beckn Protocol
Specifications.
●​ Document all the above in a publicly accessible place for use by seeker and provider
participants and app developers.

2.3​ Documentation and Onboarding starter kits :
The vendor shall be responsible for creating comprehensive, and modular documentation and starter
kits to ensure smooth onboarding and engagement for all network participants. These documents will
be published on OAN website
This includes
●​ Technical docs for developers integrating seeker and Provider Applications
●​ API specifications (Beckn Protocol Compliant)
●​ Sample payloads and error handling
●​ Develop re-usable training modules
●​ Conduct sessions on demand

2.4​ Onboarding of the network participants :
The selected partner will lead and manage the end-to-end onboarding lifecycle of participants when
required. This includesThe selected partner will lead and manage the end-to-end onboarding
lifecycle of participants when required.
This includes
●​ Define Standardized onboarding workflows which includes introductory sessions,
sandbox integration, testing and production onboarding etc.
●​ Use case mapping - Help the participants to visualise their role in the network and then
map their use case with the existing Vistaar Domains
●​ Installation of protocol servers and configuration support, if needed
●​ Sandbox Testing - Provide support during sandbox testing
●​ Resolve integration challenges
●​ Production transition - Ensure smooth transition to production

2.5​ Network monitoring:
The partner will establish a framework for monitoring the operational health, performance, and
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 13

<!-- page 14 -->

Request for Proposal

reliability of the network. This includes proactive issue detection, performance analytics etc.
This includes
●​ Gateway and registry performance and availability
●​ Availability and Downtime monitoring and Error rates
●​ Enabling Telemetry for the network
●​ Non-responsive participants and failed transactions
●​ Transparency into the behavior of various participants (apps, gateways, registries).
●​ Identifying the slow /lagging participant’s application in the network.

2.6​ SaaS provider platform :
To ensure easier adoption and inclusiveness for those participants, lacking in-house technical
expertise, the selected vendor shall offer or build a SaaS based Provider Platform. This platform should
allow such participants to go live on the Vistaar network without building their own beckn based
backend systems.

2.7​ Catalogue publishing platform; onboarding the providers :
To reduce time-to-go live and simplify Beckn integration for non-technical or semi-technical providers
to join the Beckn network without hosting their own BPP infrastructure, the vendor shall develop and
operate an Aggregator-Based Catalog Publishing Platform.
This platform will act as a multi-tenant, SaaS-based Beckn Provider Platform (BPP) that allows
numerous providers to publish and manage their catalogs through a common aggregator identity. It
will simplify onboarding, reduce technical barriers, and make services instantly discoverable to Beckn
compliant seeker apps.

2.8​ Building Custom features and integrations:
In addition to core platform components, the vendor is expected to provide ongoing support for
building custom features and integrations as per evolving network needs and partner demands. These
may arise from specific agri-sector requirements, policy directives, or third-party ecosystem
integrations.
The vendor must be technically equipped and organizationally prepared to design, develop, and
maintain such enhancements, while ensuring interoperability with the Beckn protocol and minimal
disruption to existing services.
Examples of such scenarios include Agristack, and other such DPG/DPI/Schemes by the government.

2.9​ Evolving the technical architecture of OAN
The Vendor shall actively support and contribute to the evolution of the technical architecture of the
OpenAgriNet (OAN) project. This includes aligning with the architectural vision defined by COSS,
proposing improvements, ensuring scalability and modularity, and adopting best practices in
open-source development. The Vendor is expected to collaborate closely with COSS and other
ecosystem partners to ensure the architecture remains robust, extensible, and suited to the needs of
the stakeholders.
Additionally, the Vendor shall support adopters of OAN in aligning with and updating to the evolving
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 14

<!-- page 15 -->

Request for Proposal

technical architecture. This includes providing technical guidance, contributing to reference
implementations, and ensuring that adopters are equipped with the necessary tools, documentation,
and support to upgrade and integrate new architectural components as they are developed.

2.10​ Integration with other network
As part of this deliverable, the vendor is expected to enable integration/ communication with other
state or central government networks as may be recommended by the Maha Vistaar team.

2.11​ AI & AI Agent enablement
As part of this deliverable, the vendor is expected to design and integrate AI-driven and agent-based
enhancements that can significantly improve usability, automation, scalability, and intelligence
wherever possible in this scope area mentioned in the above points (i.e. from #2.1 through #2.10).
This means, the vendor must:
●​ Identify relevant tasks within this scope that can be automated or assisted using AI (e.g.,
natural language interfaces, pattern recognition, predictive models).
●​ Integrate conversational or visual agents where beneficial (such as chat-based onboarding
assistants, catalog-suggestion bots, or voice interfaces).
●​ Design fallback and escalation mechanisms to avoid over-dependence on AI during critical
processes.
●​ Identifying and benchmark different language models for different stages in the AI pipeline.
This needs to be done in consultation with the implementation partner (government or
others).

2.12​ Network Governance and Grievance Redressal
The vendor shall collaborate with the Maha Vistaar team to design and implement a comprehensive
Network Governance Policy, including a certification framework for providers and a robust grievance
redressal mechanism.
Additionally, upon activation of the Network of Networks (NoN) module, the vendor will support the
formulation and implementation of policies governing inter-network interactions. This will include
mechanisms for whitelisting, prioritisation of providers, and network call orchestration to ensure
seamless interoperability and accountability across participating networks.

AI Layer
2.13​ Infrastructure Provisioning and AI Backend Setup
The selected vendor is responsible for provisioning and configuring compute infrastructure
(cloud-based or hybrid) suitable for running large-scale AI services. This includes:
●​ Setting up virtualized or bare-metal GPU infrastructure for hosting and serving open-source
large language models (LLMs) such as LLaMA/Sarvam or equivalent.
●​ Deploying and managing compute resources, load balancers, storage, and secure network
configurations.
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 15

<!-- page 16 -->

Request for Proposal

●​ Provisioning and configuring a production-ready open source vector database for semantic
search and retrieval.
●​ Ensuring proper setup for scalability, redundancy, observability, and service recovery.
●​ Enabling integration with fallback services such as Bhashini or Azure OpenAI where needed.
The vendor must ensure that the infrastructure is secure, maintainable, and compliant with applicable
state and national guidelines.

2.14​ Content Processing Services
The vendor shall develop a robust, modular automated pipeline to process large volumes of
English/ Marathi content and prepare it for semantic retrieval. Specifically, the vendor will:

●​
●​
●​
●​
●​
●​
●​

Ingest Marathi/ English content from provided sources or feeds.
Parse and extract structured and unstructured data, including titles, headings, and body text.
Translate Marathi content into English using open-source LLMs or secure translation services.
Correct and refine English-translated content using LLMs for grammar and contextual accuracy.
Segment the content into logical, searchable chunks appropriate for vectorization.
Generate embeddings for each chunk and index them in the vector database.
Tag and manage content metadata and support re-ingestion workflows for updated or revised
documents.
●​ Content retrieval should be under the desired time and format suited for the downstream
systems
All services must be exposed via APIs or microservices that allow integration with the larger AI backend.

2.15​ AI Query and Interaction Services
The vendor shall design and implement core AI query services to enable intelligent, multilingual user
interaction. Responsibilities include:
●​ Implementing intent recognition to understand and classify user queries.
●​ Managing LLM token sequences, prompts, and memory for coherent, contextual generation.
●​ Performing vector-based semantic searches using the indexed embeddings from the content
database.
●​ Constructing responses using open-source LLMs, leveraging the retrieved semantic context.
●​ Streaming responses back to the user interface token-by-token to enhance user experience.
●​ Supporting voice-based interactions by:
○​ Detecting language of spoken input.
○​ Transcribing voice to text using secure ASR solutions.
○​ Translating transcription to English for processing.
●​ Translating AI responses back into Marathi or other requested languages and streaming them
to the user in real time.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 16

<!-- page 17 -->

Request for Proposal

●​ All the query response to the user should be available in text as well as in speech format of the
input/user language
The vendor must ensure that all services meet performance, availability, and language fidelity
standards.

2.16​ Composable Agent-Based Design
The solution should use an agentic architecture with modular tools for data access and logic.
Tools must be loosely coupled and support future integration via protocols like MCP without
changes to core orchestration.

2.17​ Multilingual Conversational Intelligence
The system should support multilingual inputs and outputs, including ASR and TTS in Indian
languages. It must handle code-mixed queries and maintain accuracy for domain terms using
glossaries or controlled translation

2.18​ Context-Aware Information Retrieval
The architecture should combine semantic and keyword search with domain-sensitive reranking
to ensure precise retrieval of agricultural and local terms.

2.19​ Proactive Safety and Input Governance
A real-time moderation layer must handle safety checks before LLM execution, covering multiple
threat types with low latency and supporting multilingual, code-switched input.

2.20​ API Suite Development
The vendor must develop a set of secure, scalable APIs to allow programmatic access to key AI
services. The following APIs are required:
●​ Query API for submitting natural language queries and receiving AI-generated responses.
●​ Suggested Questions API to recommend related follow-up queries based on conversation

history.
●​ Transcribe API to convert audio input into text.
●​ Translate API to support bidirectional language translation.

All APIs must include proper authentication, rate-limiting, logging, and adhere to OpenAPI
latest specification documentation. APIs must be designed for easy integration into other
systems or citizen-facing applications.
2.21​ Frontend Integration and Multi-Channel Interface Support
The vendor is required to integrate the developed services with an existing frontend interface.
Additionally, the system must be extensible to support multi-channel interfaces, including:
●​ Integration with WhatsApp chat systems via approved gateways.
●​ IVRS (Interactive Voice Response System) integration for voice-based queries and responses.
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 17

<!-- page 18 -->

Request for Proposal

●​ Additional platforms such as mobile apps or local kiosks, if requested by the Maha Vistaar
team.
The vendor must ensure that all user interactions, regardless of channel, can access the AI backend
securely and consistently.

2.22​ Telemetry and Monitoring Services
The vendor shall implement telemetry and monitoring services to capture system usage and
operational metrics. This includes:
●​ Deploying a lightweight telemetry client within the frontend and APIs to capture anonymised
user actions, events, and system states.
●​ Developing a telemetry data ingestion and processing backend to store, index, and analyze
telemetry events.
●​ Setting up dashboards or alerts to monitor system health, user engagement, and performance
metrics.
All telemetry data must respect user privacy and follow applicable data protection regulations.

2.23​ Usage Analytics Dashboard
The vendor must build an administrative dashboard that provides actionable insights into
platform usage. Key features include:
●​ Vendor should identify the key metric and ways to capture them in the system.
●​ Visualization of the number of users, volume of queries, language breakdowns, and query
types already exists in the Maha Vistaar dashboard. It should be continued and improved.
●​ Dashboard should include valid and invalid queries
●​ Display of user questions with timestamps, anonymized to protect user identity.
●​ Filters for time periods, channels, regions and user type.
●​ Reports on most-used APIs, performance metrics, and model fallback events.
●​ Use case base analytics
●​ Resolved vs un resolved queries.
This dashboard should help stakeholders assess system engagement and inform future improvements.

2.24​ Deployment and Integration
The vendor will be responsible to create and manage the CI-CD pipeline for end-to-end
deployment of all components on the target infrastructure. Key tasks include:
●​ Integrate the test case for the developed code in the CI-CD pipeline and should be the gating
criteria for the deployment
●​ Deploying AI models, vector databases, APIs, and telemetry services on cloud or hybrid
infrastructure.
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 18

<!-- page 19 -->

Request for Proposal

●​
●​
●​
●​

Ensuring fallback and redundancy options via Bhashini or Azure OpenAI in case of failures.
Setting up networking, NAT configurations, domain management, and basic access control.
Creating user accounts and demo environments for testing and stakeholder review.
Integrating with AgriStack, while ensuring full compliance with data privacy regulations and AI
policy guidelines mandated by the Maharashtra Agriculture Department.
●​ Integrating with external APIs such as Weather, Soil Health Card, and Government Scheme
databases, as required by use cases.

2.25​ Support and Maintenance
The vendor shall provide ongoing support and maintenance services for the entire duration of
the contract. This includes:
●​ Creating and managing user accounts and access roles.
●​ Ensuring high system availability and uptime, 99.9% uptime per month.
●​ Performing routine backups and system health checks.
●​ Upgrading the underline frameworks and software regularly
●​ Resolving technical issues, bugs, or performance degradation.

●​ Ensuring the code is vulnerability free and secure
●​ Providing responsive email and remote support during business hours.
●​ Delivering updates, patches, and operational documentation throughout the project lifecycle.
●​ For production systems
○​ Bugs classification should be done in consultation with the COSS Tech team
○​ Bugs should be triaged and acknowledged in 12hrs of reporting
○​ P0 bugs should be fixed and deployed in 24hr of reporting
○​ P1 bugs should be fixed and deployed in 48hr of reporting
○​ P2 bugs should be fixed and deployed in 72hr of reporting
○​ Bugs and defects should be documented in an issue tracking system such as Jira.
○​ System downtime should be kept minimal and downtime should be planned in off peak
hours

Other deliverables
2.26​ Capacity Building:
The vendor shall be responsible for designing and delivering a structured capacity-building program to
equip adopters with a clear understanding of the principles, mechanics, and value of the Open Network
Architecture, including the fine-tuning of language models within the agricultural context. This program
must be developed in close consultation with the Maha Vistaar team and should be tailored to the
specific needs of the relevant government departments.
As part of the engagement, the vendor shall also assess the existing resource capacity and, where
necessary, recommend or support additional hiring within the Maharashtra IT Department, should any
skill-to-role gaps be identified.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 19

<!-- page 20 -->

Request for Proposal

The capacity-building program must include comprehensive documentation, recorded sessions, and
workshops or training sessions delivered in either online or offline formats, as per the requirements of
the Maha Vistaar team.

2.27​ DPG Packaging:
As part of this deliverable, the vendor is expected to work on creating DPG compliance packaging of the
Vistaar implementation.
DPG packaging should ensure that the software is open, reusable, and easy to adopt. It must meet the
DPG Alliance criteria—such as being open source, aligned to the SDGs, and designed to do no harm.
Technically, it should include clear documentation, installation guides, deployment playbooks,
architecture diagrams, APIs, and configuration instructions. Community readiness is supported through
contribution guidelines, a code of conduct, and security policies. For broader adoption, it should offer
localization support, governance models, and real-world use cases. Optional but valuable additions
include accessibility, security, and interoperability certifications. Altogether, effective DPG packaging
makes the solution discoverable, trustworthy, and ready for global implementation.

The ultimate goal is to enable the Vistaar implementation to be readily shared, reused, and
adapted within the broader digital ecosystem, fostering collaboration and maximizing its public
benefit.
2.28​ Reporting Structure:
To ensure effective communication, alignment, and progress tracking throughout the engagement, the
vendor shall comply with the following reporting requirements:
●​ Kick-off Report: A one-time report to be submitted within the first week of project
commencement, outlining team composition, scope understanding, timelines, initial approach,
and any key dependencies or assumptions.
●​ Weekly Review Calls: Regular check-ins with the COSS team to review progress, discuss
blockers and risks, align on priorities, and identify any support or decisions required.
●​ Progress Reports (Weekly & Monthly): Concise written updates shared via email summarizing
completed work, team contributions, key challenges with mitigation measures, and planned
activities for the upcoming period.
●​ Milestone Reports: Submitted upon completion of key milestones, these reports should
include a summary of deliverables, achieved outcomes, stakeholder feedback, and any
important learnings or suggestions for improvement.
●​ Risk, Issue & Action Trackers: A dynamic and regularly updated tracker capturing risks, issues,
mitigation steps, and action items discussed in meetings or identified during execution.
●​ Feedback Implementation: The Vendor shall acknowledge and incorporate feedback from
COSS on deliverables, communication, and overall engagement quality, with an intent to
continuously improve performance.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 20

<!-- page 21 -->

Request for Proposal

●​ Resource Utilization Reports: A monthly summary detailing team effort, resource allocation,
and time spent per task or activity—particularly important for effort-based engagements.
●​ Meeting Documentation: Minutes of key meetings, along with action items, must be shared
within 24–48 hours to ensure clear alignment and follow-through.
●​ Final Closure Report: A comprehensive end-of-engagement report summarizing work
delivered, alignment with objectives, key outcomes, learnings, and forward-looking
recommendations.

2.29​ Quality Checks and Monitoring
●​ Bidder is expected to incorporate high standards of quality in all its deliverables, well-defined and
published quality assurance processes, tracking mechanisms and continuous improvement plans
●​ To ensure Service Quality, IIITB or its other authorized program stakeholders, at its discretion, may
conduct regular as well as random audits in in-person or remote mode
●​ Bidder to monitor and generate reports including those required for cross-verification of SLAs and
related payments

2.30​ Project Management
2.30.1 ​ Project Governance
Bidder is expected to propose the Governance structure as part of response to the RFP which would be
further discussed and finalized mutually between selected bidder and IIITB team at the time of
on-boarding. However, some of the key requirements for governance of this project are mentioned in the
subsequent sections.
2.30.2 ​ Steering Committee
i.​

The Bidder shall participate in periodic Steering Committee meetings and update the Steering
Committee on Project progress, Risk parameters (if any), Resource requirements, immediate next
project steps, and any obstacles in the project.

ii.​

All relevant records of proceedings of the Steering Committee should be maintained and shared with
the Steering Committee and Project Management Office.

iii.​

The bidder should also plan for participation in Steering Committee meetings and any other important
meetings in in-person mode - as and when required and feasible

iv.​

Other than the planned meetings, IIITB may call for a Steering Committee meeting with prior notice to
the Bidder.

v.​

The Steering Committee will consist of stakeholders from IIITB, members from other committees for
the program, its nominated agencies (if required) & stakeholders from Bidder.

2.30.3 Transition and Exit Management
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 21

<!-- page 22 -->

Request for Proposal

i.​

At the end of the contract period or during the contract period, if any other agency is identified or
selected for providing services related to Bidder’s scope of work, the bidder needs to ensure a smooth
transition to new agency/vendor

ii.​

All risks during the transition stage shall be properly documented by Bidder and mitigation measures
shall be planned in advance so as to ensure smooth transition without any service disruption.

iii.​

The transition plan along with a period shall be mutually agreed between Bidder and IIITB and/or its
designated agency when the situation occurs. Bidder shall be released from the project once
successful transition is done and meeting the parameters defined for successful transition.

Note : The bidder shall participate in a monthly performance feedback process for all personnel deployed on
the project. This process will include feedback from both COSS and the client.
In the event that a resource is found to be underperforming or receives unsatisfactory feedback, the bidder
shall replace the concerned resource within a period of 2 (two) to 7 (seven) calendar days from the date of
written notification issued by COSS, IIIT-B.

3​Response Guidelines
This section contains guidelines to be followed by the bidder for the Technical and Commercial responses to
this RFP

3.1​Guidelines for RFP Technical Response
i.​

Understanding of Scope
•​ Demonstrate a clear understanding of the objectives, scope of work, and deliverables.
•​ Highlight how the proposed approach aligns with the OAN and Maha Vistaar goals.

ii.​ Proposed Solution Description
•​ Detailed description of the proposed solution.
•​ Architecture diagram(s) — highlight major components and integration points.
•​ Innovation aspects, if any
•​ Clearly state any assumptions or pre-conditions.
iii.​ Approach and Methodology
•​ Outline the implementation roadmap with key milestones and timelines
•​ Phased approach — milestones, deliverables.
•​ Resource deployment plan.
•​ Risk identification and mitigation measures.
•​ Quality assurance processes.
•​ Outline the implementation roadmap with key milestones and timelines.
iv.​ Technical Proposal
•​ Provide detailed information on proposed technologies, system architecture
•​ Details of technologies, platforms,tools, and processes that will be used for each
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 22

<!-- page 23 -->

Request for Proposal

•​
•​
v.​

component of the scope (e.g., network setup, AI enablement, onboarding, support)..
Scalability, security, and performance features.
Include any open-source components and how they will be maintained or extended.

Team Composition and Experience
•​ Key personnel details: Name, designation, relevant experience, and certifications.
•​ Include resumes or profiles of the proposed team members with relevant expertise.
•​ Highlight past experience in implementing similar digital public goods, AI-based
•​

systems, or open networks.
Identify dependencies on the client’s resources or third parties.

vi.​ Past Performance and References
•​ At least 2–3 case studies demonstrating similar work.
•​ Project description.
•​ Client name (if permissible).
•​ Duration.
•​ Scope and outcomes.
•​ Reference/contact (optional).
•​ Provide case studies or examples of previous projects relevant to this
engagement.
•​ Include references from past clients or partners (with contact details, if
allowed).
vii.​ Project Governance and Risk Management
•​ Propose a governance structure for project management and stakeholder
engagement.
•​ Identify potential risks and propose mitigation strategies
viii.​ Technical Support & Maintenance Approach
•​ Support model (hours of support, escalation matrix).
•​ Warranty or post-implementation support commitments.
•​ Knowledge transfer plan.
ix.​ Annexures
•​ Any additional technical documents, diagrams, or brochures.
•​ Certificates or accreditations.
•​ Declarations (where required).
x.​ Intellectual Property and Compliance
•​ Confirm acceptance of intellectual property, licensing, and open-source
contribution guidelines as outlined in the RFP.
•​ Declare compliance with applicable national and state-level data protection,
procurement, and labor policies.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 23

<!-- page 24 -->

Request for Proposal

3.2​ Guidelines for RFP Commercial Response
3.2.1 ​​ Commercial Model
Financial Proposal
○​ Submit a clear and detailed financial proposal including itemized costs.
○​ Indicate assumptions, exclusions, applicable taxes, and terms of payment.
Below are the details regarding the commercial model expected for the services to be provided by the
selected Bidder

Ser

Service Category

Commercial Model

1
2
3

Resource deployment
License or subscription fees, if applicable
Any Other

Time and Material
Defined by Bidder
Defined by Bidder

The payment terms are outlined in Section 6.1.

3.2.2 ​​ Format for Commercial Model
The bidder must use the format provided in Annexure-9 for sharing proposed commercials which is expected
to be used for evaluation of the commercial bid.

4​ Evaluation Criteria and Process
4.1​Objective of the Evaluation Process
The objective of the evaluation process is to evaluate the bids to select an effective and best fit solution at a
competitive price. The evaluation will be undertaken by IIITB. IIITB may consider recommendations made by an
external experts committee constituted for the selection process. The decision of IIITB shall be final.
IIITB will scrutinize the offers to determine whether they are complete, whether any errors have been made in
the offer, whether required technical documentation has been furnished, whether the documents have been
properly signed, and whether items are quoted as per the required format.
IIITB may call for any clarifications/additional particulars required, if any, on the technical/ commercial bids
submitted. The bidder has to submit the clarifications/ additional particulars in writing within the specified
date and time. The bidder’s offer may be disqualified, if the clarifications/ additional particulars sought are not
submitted within the specified date and time.
A Quality Cost Based System (QCBS) will be used to evaluate bids. The bids shall be evaluated in the following
stages:
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 24

<!-- page 25 -->

Request for Proposal

●​
●​
●​

Stage 1 – Eligibility Criteria
Stage 2 – Technical Bid
Stage 3 – Commercial Bid

Bidders who qualify in the Eligibility Criteria will be considered for Stage 2 evaluation. Of these, Bidders
who meet the minimum qualifying score for the Technical Bid Evaluation will be considered for Stage 3.
An overall QCBS score will be computed for Bidders who qualify for Stage 3, and the successful Bidder
will be selected based on the ranking of QCBS scores.
4.2​

Stage 1 – Evaluation of Eligibility Criteria

IIITB and the evaluation Committee will evaluate the Bidders on each criterion separately and satisfy itself
beyond doubt on the Bidder’s ability / position to meet the criteria. Those Bidders who qualify on ALL the
criteria will only be considered as “Qualified under Stage 1” of evaluation and will be considered for evaluation
under Stage 2.
Those Bidders who do not qualify at this Stage 1 will not be considered for any further processing. IIITB,
therefore, requests that only those Bidders who are sure of meeting all the eligibility criteria, respond to this
RFP process.
Evaluation of eligibility criteria will be as per the information/ response provided by the bidder and the
supporting documents as mentioned below.
Only those bidders who fulfil the criteria mentioned in the table below are eligible for technical evaluation.
Offers received from the bidders who do not fulfil all of the following eligibility criteria are liable to be rejected.
Ser

Eligibility Criteria Requirements

Supporting documents required

1

The Bidder should be a Government
Organization/PSU/Public/Partnership/Private limited
company or subsidiary thereof.
The Bidder/Group Company/ Subsidiary/ Parental
Company should have been in operation for at least 3
years as on date of RFP. In case the current Bidder
Company is the result of a merger / acquisition, at least
one of the merging companies should have been in
operation for at least 3 years as on date of RFP.
The Bidder/Group Company/ Subsidiary/ Parental
Company should be profitable in two out of last three
financial years (2022-23, 2023-24, and 2024-25)

Certificate of Incorporation

2

3

4

The Bidder/Group Company/ Subsidiary/ Parental
Company should have a minimum turnover of INR 5 crores
per annum in two of the last three financial years

Certificate of Incorporation

Audited Financial Statements
for
2022-23, 2023-24, and
2024-25 (Or) Certificate from
the chartered accountant
Audited Financial Statements
for the financial years 2022-23,
2023-24, and 2024-25 (Or)
Certificate from the​ chartered
accountant

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 25

<!-- page 26 -->

Request for Proposal

5

6
7

The bidder should not have been blacklisted by any
Government or PSU enterprise in India as on the date of
the RFP
The Solution is provided by the Bidder/Group Company/
Subsidiary/ Parental Company

Self-Declaration certified by
authorized signatory of the bidder

Bidder should be willing to deliver services from Mumbai
or other places in Maharashtra if requested

Self-Declaration certified by
authorized signatory of the bidder

Self-Declaration certified by
authorized signatory of the bidder

Note:
●​ Bidders need to ensure compliance to all the eligibility criteria points
●​ The decision of the IIITB shall be final and binding in this regard
●​ The Bidders meeting the eligibility criteria will be shortlisted for the Phase 2 – Technical Proposal
Evaluation

4.3​

Stage 2 – Evaluation of Technical Bid

●​ This evaluation will be carried out on a total score of 100 on the basis of the following evaluation
parameters defined in this section
●​ The evaluation methodology is further broken down into sub areas as under
S No

Criteria

Details / What to Look For

1

Profile
Quality of
Proposed
Resources

Relevant skills required to develop, deploy and maintain
scale solutions on cloud infrastructure(AWS, GC, OCI or Azure
or Openstack), hands on the latest technology and tools,
number of such projects undertaken and number of years
of experience with such solutions.
Active contribution to open-source projects.

2

Open
Network
experience

End-to-end implementation and maintenance of
Beckn-compliant registries and gateways (sandbox &
production), infrastructure provisioning, uptime
management, use case visualization, schema/API design,
SaaS-based onboarding tools, developer documentation,
and monitoring via dashboards, telemetry, and alerting
systems (15)
Additional points for setting up open networks for
agriculture (5)

Max
Mark
s
20

Min Pass
Marks

20

14

14

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 26

<!-- page 27 -->

Request for Proposal

3

Generative
AI
experience

4

Staffing
Capability

5

Presentation

Capacity and experience in developing conversational bots
using secure, scalable AI infrastructure (GPU, vector DBs);
hosting open-source LLMs, integrating LLM APIs
(Bhashini/Azure), content ingestion and processing
pipeline, generating semantic embeddings, enabling
intelligent query resolution (text/voice), and building
robust APIs for integration with platforms such as chatbots,
WhatsApp, IVRS, and usage dashboards. (15)
Additional points for developing AI applications in
agriculture (5)
How quickly the vendor can onboard all required
resources. Bonus if immediate joiners are available.
Retention plan, assurance on continuity of resources, and
availability of a backup pool.
Score from Technical evaluation committee on the quality
of the proposed approach, understanding, innovation, and
clarity during the presentation
Total

20

14

10

7

30

21

100

70

Any critical non-compliance/deviations may lead to disqualification of the Bidder. The scores will be
evaluated as whole numbers.
Only those Bidders achieving the minimum passing mark for EACH OF the individual evaluation activities
from Sr. No. 1 to 4, AND a total score of at least 70 will be considered eligible for the Commercial evaluation
process
Also, IIITB may, at its sole discretion, decide to seek more information from the bidders in order to
normalize the bids. However, bidders will be notified separately, if such normalization exercise is
resorted to.
4.4​

Stage 3 - Commercial Bid Evaluation

The bidders who qualify in the Technical Bid Evaluation shall be eligible for Phase-3 Commercial Bid Evaluation.
●​ Financial Bids will be evaluated based on Rate Card submitted by the Bidder, as per Annexure 9.
●​ The Bid value of each Bidder will be converted to a Financial Score based on the ratio of their bid value
to the lowest Bid value among qualified Bidders as follows:
Financial Score = (Lowest Bid Value/Bid Value of Bidder) *100
●​ The total QCBS score for each Bid is calculated using a weightage of 70:30 for the Technical Score and
Financial Score. Thus,
Consolidated Bid Score = Technical Score * 0.7 + Financial Score*0.3
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 27

<!-- page 28 -->

Request for Proposal

●​ The Bidder with the highest Consolidated Bid Score is selected and will be referred to as “Selected
Bidder” and IIITB will notify the same to the selected bidder. The Bidder shall use the format as
Mentioned in Annexure-9: Commercial Bid Form. Commercial bid valuation shall be considered as
below; in case of any kind of discrepancy:
i.​ If there is a discrepancy between words and figures, the amount in words shall prevail.
ii.​ At the sole discretion and determination of IIITB, IIITB may add any other relevant criteria for
evaluating the proposals received in response to this RFP.
iii.​ IIITB may, at its sole discretion, decide to seek more information from the respondents in order to
normalize the bids. However, respondents will be notified separately, if such normalization
exercise as part of the technical evaluation is resorted to.
iv.​ All liability related to non-compliance of this minimum wages requirement and any other law will
be the responsibility of the bidder.
v.​ IIITB shall not incur any liability to the affected bidder on account of such rejection.
vi.​ The final decision on the successful bidder will be taken by IIITB, in consultation with any other
stakeholders as required. The implementation of the project will commence upon signing of a
contract between IIITB and the selected bidder based on the evaluation.
vii.​ If for some reason, the successful bidder fails to execute an agreement within a specified timeline,
IIITB reserves the right to award the contract to the next most eligible bidder based on the
evaluation scores and commercial prices quoted.

5​ Agreements and Agencies
The commercial quote submitted by the Bidder must remain valid for a period of two (2) years from the
date of submission of the proposal. The initial contract will be signed for a duration of one (1) year. In the
event of an extension—either due to project delays, incomplete milestones, or additional
requirements—the same quoted rates shall remain applicable for the extended duration, subject to mutual
agreement.
The final agreement for services and commercials will be executed between IIIT-Bangalore (IIITB) and the
selected Bidder.

6​ Payments terms, Service Level Agreement and Penalties
6.1​Payment terms

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 28

<!-- page 29 -->

Request for Proposal

The payments to the selected bidder will be made after 60 Days from the date of receipt of the invoice after
adjusting for penalty (if any).
Bidders must submit timesheets along with the monthly GST invoice to COSS, IIIT-B at the time of raising the
invoice

6.2​Service Level Agreements
The SLA parameters and penalty slabs for the services will be decided at the time of contracting. Penalties for
non-compliance are detailed in section 8.20

7​ Instructions to Bidder
7.1​ Two Bid System
The RFP shall be in TWO parts – TECHNICAL BID [TB] & COMMERCIAL BID [CB]. Both the Bids must be
submitted together in a single envelope super-scribing “Expansion and support service for MahaVISTAAR”, but
in two separate sealed covers, giving full particulars, addressed to IIITB and duly super scribed as follows:
●​ “Expansion and Support Services for MahaVISTAAR,IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR,
03-Jul-2025 – TECHNICAL BID”
●​ “Expansion and Support Services for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR,
03-Jul-2025 – COMMERCIAL BID”
Two sealed envelopes containing hard copies of Eligibility Bid, Technical Bid and Commercial Bid along with
Soft copies should be submitted in the following manner:
7.1.1​ ENVELOPE - I (Technical Bid)
The Technical Bid shall be submitted as a spirally bound hard copy, prepared in accordance with the
format prescribed in this RFP. In addition, a soft copy of the bid must be submitted via email in a
password-protected file to ensure confidentiality and data integrity.
Hard copy of Technical Bid including Eligibility Bid should be a complete document, bound as a volume and
placed in a sealed envelope super-scribed Technical Bid for RFP No: Expansion and Support Services for
MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 03-Jul-2025.
i.​
A separate sealed envelope should be prepared for EMD & tender processing fees marked as
“EMD/Tender processing Fees”
The two envelopes (Technical Bid and EMD/Tender processing Fees) of Technical Bid should be placed in a
single sealed envelope super-scribed: Technical Bid for RFP No: Expansion and Support Services for
MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 03-Jul-2025.
ii.​
A soft copy of the Technical Bid must also be submitted in MS Word format via email to
oansocial@coss.org.in. The file should be password-protected to ensure confidentiality. In case of any
discrepancies between the hardcopy and softcopy, IIITB will use the hardcopy submitted by the Bidder for
the evaluation. THE TECHNICAL BID SHOULD NOT CONTAIN COMMERCIALS AND COMMERCIALS ARE TO
BE ENCLOSED ONLY IN THE COMMERCIAL BID COVER. A masked copy of Annexure 9-Commercial Bid
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 29

<!-- page 30 -->

Request for Proposal

Form should be a part of Technical Bid.
7.1.2​ ENVELOPE - II (Commercial Bid)
Hard copy of commercial bid should be submitted as per the format given in this RFP.
Signed and stamped hard copy of the Commercial Bid should be a placed in a sealed envelope super-scribed
Commercial Bid for RFP No: Expansion and Support Services for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet
- MahaVISTAAR, 03-Jul-2025
i. A duly filled in Annexure 9-Commercial Bid Form should be a part of Commercial Bid. The hard copy is
to be placed in a Commercial Bid Envelope. In case of any discrepancy between the hardcopy and
softcopy, IIITB will use the hardcopy submitted by the Bidder for the evaluation.

Note:
1.​ The Bid shall be typed in English and signed by the Bidder or a person duly authorized. The person(s)
signing the Bids shall initial all pages of the Bids.
2.​ All envelopes should be securely sealed and stamped.
3.​ The documentary evidence asked for in respect of the eligibility criteria would be essential. Bids not
accompanied by documentary evidence may be subject to rejection. Clarification/ Additional
documents, if any, sought by IIITB from the bidder has to be submitted within the stipulated time.

7.2​

EMD

EMD in the form of Account Payee Demand Draft, Fixed Deposit Receipt, Banker’s Cheque or Bank
Guarantee from any of the Scheduled Commercial banks in an acceptable form, favouring ‘International
Institute of Information Technology Bangalore’ payable at Bangalore valid for twelve months should be
submitted as per format given in Annexure 10–Format for Bank guarantee. The instrument used for
providing EMD should be renewed (if required) to maintain validity of nine months
Non-submission of EMD along with Technical-Bid document will disqualify the Bidder.
i.​
For the selected bidder, the EMD amount will be retained and adjusted against the Performance
Bank Guarantee requirement.
ii.​
For the bidders who do not qualify in this RFP, EMD will be returned to the respective bidder after
the declaration of Successful bidders.
iii.​

EMD submitted by bidder may be forfeited if:
a)​

Bidder backs out of bidding process after submitting the bids;

b)​

Bidder backs out after qualifying;

c)​
Bidder does not accept the Purchase Order / Sign the Contract within the time prescribed by
IIITB after qualifying.
iv.​
The Bidder needs to ensure the complete Bid (encompassing both Technical & Commercial) is
valid for a period of 60 days post the date of submission of the Bids.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 30

<!-- page 31 -->

Request for Proposal

7.3​Content of the Bid
The documents in the bids will be submitted as below:
7.3.1​ Eligibility Bid Documents
The Bidders are requested to meticulously note the Eligibility Criteria & various other clauses mentioned
in the RFP document. The following documents should be submitted in Envelope - I (Technical Bid). These
documents shall be the basis for Eligibility Criteria by IIITB.
Eligibility document should contain following:
i.​
Confirmation of Eligibility Criteria as per Annexure-3
ii.​
Documentary proofs for Eligibility Criteria
iii.​
EMD
iv.​
Tender Processing Fee
7.3.2​ Technical Bid Documents
The following documents should be submitted in the Envelope - I (Technical Bid). These documents shall
be the basis for technical evaluation by IIITB.
1.​ Annexure 2: Cover Letter
2.​ Annexure 4: Undertaking for Data and Information Security
3.​ Annexure 5: Technical Bid Format
4.​ Annexure 6: Statement of no deviation
5.​ Annexure 7: Bidder’s Past Experience
6.​ Proposed Technical Solution and Response addressing sections 2.1,3.1,4.3
7.​ Any other documents
All documentation is required to be in English.
The person(s) signing the Bid shall initial all pages of the Bid, except for unmodified printed literature.
NOTE: TECHNICAL BID MUST BE SUBMITTED IN AN ORGANISED AND NEAT MANNER. NO DOCUMENT,
BROCHURE, ETC. SHOULD BE SUBMITTED IN LOOSE FORM. ALL THE PAGES SHOULD BE SERIALLY NUMBERED.
The Technical Bid shall be submitted in duplicate, inside the single ENVELOPE – I.
7.3.3​ Commercial Bid Documents
The Commercial Bid shall be submitted in the format as specified in Annexure 9 –Commercial Bid Form. The
Bidder is required to submit the following in the Commercial Bid.
1.​ Annexure 8: Commercial Compliance Statement
2.​ Annexure 9: Commercial Bid Form
The Commercial Bid Form must be filled in completely, without any error, erasure or alteration.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 31

<!-- page 32 -->

Request for Proposal

7.4​

Late Bids

Any bid received after the due date and time for receipts of bids as prescribed in this RFP will be rejected and
returned unopened to the Bidder.
7.5​

Opening of Bids

Bids received within the prescribed closing date and time will be opened in the presence of Bidders’
representatives who choose to attend the opening of the RFP on the specified date and time as mentioned
earlier in the RFP document. The Bidder’s representatives present shall sign a register of attendance and
minutes and they should be authorized by their respective companies to do so. A copy of the authorization
letter as per Annexure 11 should be brought to IIITB for verification.
The Bids shall be opened in 2 phases:
●​ In Phase 1, the Confirmation of Eligibility Criteria Bid and Technical Bid shall be opened as per the
schedule given in the RFP in presence of the bidder(s) who choose to attend the meeting at a prespecified date and time, and sign a register evidencing their attendance. However, the Technical Bid will
be evaluated only for the bidders who satisfy all the Eligibility Criteria.
●​ In Phase 2, Commercial Bids of only Bidders who meet the Technical Evaluation cut-off shall be opened
in the presence of Bidders’ representatives who choose to attend, at the time, on the date, and at the
place that will be communicated to them. The Bidders’ representatives who are present shall sign a
register evidencing their attendance. IIITB would notify the technically qualified bidders about the date
and time of opening of the Commercial Bids.
The Bidders’ names, bid modifications or withdrawals, bid prices, discounts, and the presence or absence of
the requisite EMD and such other details as IIITB, at its discretion, may be considered appropriate, will be
announced at the Commercial Bid opening.
IIITB reserves the right to take the services of any one or more external agencies for total evaluation of the
proposal submitted by the Bidder. However, the final decisive parameters would be at the sole discretion of
IIITB and IIITB is not liable to disclose either the criteria or the evaluation report/reasoning to the Bidder(s).

7.6​

Proposal Modification

No additions or changes to any Bidder's proposal will be allowed after the deadline for Bidders to submit their
proposals, unless such modification is specifically requested by IIITB.

7.7​

Clarification of Bids

During the Bid evaluation, IIITB may, at its discretion, ask the Bidders for clarifications with respect to their
Bids. The request for clarification and the response shall be in writing, and no change in the price or substance
of the Bid shall be sought, offered or permitted. IIITB has the right to disqualify the Bidder(s) whose
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 32

<!-- page 33 -->

Request for Proposal

clarifications are found not suitable for the requirement according to the Scope of Work.

Result Notification

7.8​

All Bidders will be communicated any decision made with respect to their RFP response as soon as practical.
IIITB will not be obliged to provide reasons for acceptance/ rejection of any response.

7.9​

Cost of Responses

IIITB will not be liable for any costs or expenses incurred by the bidders arising in any way from the preparation
and submission of the RFP response and any matter concerning the RFP is to be at the Bidder’s sole risk, cost
and expense.

7.10​ Precedence of Documents
i.​

If there is any discrepancy, the hard copy of the Bid document shall be treated as final in case of any
discrepancy with the soft copy.

ii.​

These terms and conditions will prevail over any further terms that the Bidder may include in its response
or otherwise provide to IIITB, and any such further terms will be of no force or effect.

7.11​ No commitment to accept lowest or any Bid
IIITB shall be under no obligation to accept the lowest or any other offer received in response to this RFP and
shall be entitled to reject any or all offers including those received late or incomplete. IIITB reserves the right
to make changes in the Terms and Conditions. IIITB will be under no obligation to have discussions with any
Bidder, and/or entertain any representation.
7.12​

Non-Transferable RFP

This RFP document is not transferable.

7.13​ Soft Copy of RFP Document
The soft copy of the RFP document is made available on IIITB’s website

7.14​ Addenda
i.​

IIITB may issue an Addendum from time to time.

ii.​

An Addendum may be issued to clarify the RFP or to effect modifications to the RFP. Each Addendum will
be published on the IIITB website and will form part of this RFP.

iii.​ To the extent there is any inconsistency between an Addendum and this RFP, the Addendum will prevail
and if between two or more Addenda, the last issued Addendum will prevail.
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 33

<!-- page 34 -->

Request for Proposal

7.15​ Pre Bid meeting
For clarification of doubts of the Bidders on issues related to this RFP, COSS,IIITB intends to hold Pre- Bid
Meeting as per schedule in the RFP.
For any clarification with respect to this RFP, the Bidder may send an email to oansocial@coss.org.in. The
format to be used for seeking clarification is mentioned in Annexure 1 - Pre-Bid Query. It may be noted that all
queries, clarifications, questions, etc., relating to this RFP, technical or otherwise, must be in writing only and
should be sent to the designated Email ID.
It may be noted that queries of any Bidder may not be entertained after the last date for submission of queries
via Email. Only two authorized representatives of the Bidder’s organization will be allowed to attend the
meeting. IIITB may or may not respond to all the queries of the bidder.

7.16​ Rejection of Bids
IIITB reserves the right to reject any or all the Bids or scrap the bidding process at any stage without assigning
any reason. The Earnest Money Deposits in such an event will be returned by IIITB. However, the Tender
processing fee will not be refunded.
7.17​

Amendment to Contract

No variation in or modification of the conditions of the Contract shall be made except by written amendment
signed by the parties.

7.18​ Correspondence and Notices
Any correspondence or notice from one party to another under the terms of the Contract shall be served by
fax or by hand and confirmed in writing to the party’s address. A notice shall be effective from the date when
delivered.

7.19​ Notification of Award
Following evaluation, a Contract may be awarded to the Bidder whose Bid meets the requirements of this RFP
and provides the best value to IIITB from both a Techno-Functional and Commercial point of view. IIITB
reserves the right to award the Contract in whole or in part.
The acceptance of the Bid, subject to Contract, will be communicated by way of placing a notification of award
in writing at the address supplied by the Bidder in the Bid document. Any change of address of the Bidder
should therefore be notified promptly via email at cao@iiitb.ac.in.
The PBG should be submitted within 15 days from notification of award from IIITB. IIITB subsequently shall be
issuing the Purchase Order.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 34

<!-- page 35 -->

Request for Proposal

7.20​ Signing of Contract
The Successful Bidder shall be required to enter into a Contract with IIITB, within thirty (30) days of the award
of the work or within an extended period, as may be specified by IIITB. This Contract shall be based on this RFP
document, PO and such other terms and conditions as may be determined by IIITB to be necessary for the due
performance of the work, as envisaged herein and in accordance with the Bid. However, the terms and
conditions of Purchase Order and RFP shall constitute a binding Contract till such a Contract is issued. IIITB
reserves the right to award the contract in whole or in part.

8​ Terms and Conditions
8.1​

Amendment to Bid Document

At any time prior to the deadline for submission of Bids, IIITB may for any reason either on its own initiative or
in response to a clarification requested by a prospective Bidder, modify the Bid document, by amendment.
All such amendments will be published on https://www.iiitb.ac.in/tenders All such amendments will be
binding on the bidders. In order to allow prospective Bidders reasonable time in which to take the amendment
into account in preparing their Bids, IIITB may, at its discretion, extend the deadline for a reasonable period to
be decided by IIITB for the submission of Bids. Details will be communicated and published on IIITB website
page https://www.iiitb.ac.in/tenders
i.​ IIITB also reserves the right to change any terms and conditions of the RFP and its subsequent addendums
as it deems necessary at its sole discretion. IIITB will inform the Bidder about changes, if any before the
deadline of Bids submission.
ii.​ IIITB may revise any part of the RFP, by providing an addendum/corrigendum to the Bidders at stage till
Commercial Bids are opened. IIITB reserves the right to issue revisions to this RFP at any time before the
deadline for Bids submission.
iii.​ IIITB reserves the right to extend the dates for submission of responses to this document.
iv.​ Preliminary Scrutiny – IIITB will scrutinize the offer to determine whether it is complete, whether any
errors have been made in the offer, whether required technical documentation has been furnished,
whether the documents have been properly signed, and whether items are quoted as per the schedule.
IIITB may, at its discretion, waive any minor non-conformity or any minor deficiency in an offer. This shall
be binding on the Bidder and IIITB reserves the right for such waivers and IIITB’s decision in the matter will
be final.
v.​ Clarification of Offer – To assist in the scrutiny, evaluation and comparison of offer, IIITB may, at its
discretion, ask the Bidder for clarification of their offer. IIITB has the right to disqualify the Bidder whose
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 35

<!-- page 36 -->

Request for Proposal

clarification is found not suitable to the proposed project RFP.
vi.​ IIITB reserves the right to make any changes in the terms and conditions of purchase. IIITB will not be
obliged to meet and have discussions with any Bidder, and / or to listen to any representations.
vii.​ Erasures or Alterations – The offer containing erasures or alterations will not be considered. There should
be no handwritten material, corrections or alterations in the offer. Technical details must be completely
filled up. Correct technical information of the product/service being offered must be filled in. Filling up the
information using terms such as “OK”, “accepted”, “noted”, “as given in brochure / manual” is not
acceptable. IIITB may treat the offers not adhering to these guidelines as unacceptable.
viii.​
Right to Alter Quantities – IIITB reserves the right to alter the requirements specified in the RFP. IIITB
also reserves the right to delete or increase one or more items from the list of items specified in the RFP. IIITB
will inform the Bidders about changes, if any. In the event of any alteration in the quantities, the price quoted
by the Bidder against the item would be considered for such alteration. Bidder agrees that the prices quoted
for each line item & component is valid for the period of Contract and can be used by IIITB for alteration in
quantities. Bidder agrees that there is no limit on the quantities that can be altered under this Contract. During
the Contract period, the Bidder agrees to pass on the benefit of reduction in pricing for any additional items to
be procured by IIITB, in the event the market prices/rate offered by the Bidder are lower than what has been
quoted by the Bidder as the part of Commercial Bid. Any price benefit in the services/equipment should be
passed on to IIITB within the Contract period.
ix.​
The decision of IIITB shall be final and binding in this regard. Deviations will be grounds for
disqualification.

8.2​

Consortium

Consortium is not allowed.

8.3​

Conditional Bids

Conditional Bids shall not be accepted on any ground and shall be rejected straightway. If any clarification is
required, the same should be obtained before submission of Bids.

8.4​

Submission of Bids

The Bidders shall submit two separate sealed envelopes, one containing Technical Bid including Eligibility
criteria and the other containing Commercial Bid. Envelopes shall be addressed to IIITB at the address given;
and bear the RFP Title "Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet MahaVISTAAR, 03-Jul-2025”. Envelopes should indicate on the cover the name and address of the Bidder. A
Bidder shall submit only one proposal.

8.5​

Performance Security

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 36

<!-- page 37 -->

Request for Proposal

Within 15 days after the receipt of notification of award of the Contract from IIITB, the Bidder shall submit
Performance Security as per format given in Annexure 12: Performance Bank Guarantee, which shall be for an
amount of 3% of Contract Value. Performance Security may be furnished in the form Bank Guarantee from a
Commercial bank.
i.​
Performance Security should remain valid for a period of ninety days beyond the date of completion of
all contractual obligations of the supplier including warranty obligations.
ii.​
8.6​

EMD shall be refunded to the successful Bidder on receipt of Performance Security.

Pre-Bid Meeting

All queries/requests for clarification from Bidders must reach COSS, IIITB by email (oansocial@coss.org.in) or
online meeting as per the schedule of events mentioned in section 1.2. Format for the queries/clarification is
provided in “Annexure 1-Pre- Bid Query”. No clarification or queries will be responded to in any other format.
COSS, IIITB will respond to any request for clarification of the RFP document in the Pre- Bid meeting.
The representatives of Bidders attending the pre-bid meeting must have proper authority letter to attend the
same
Any modification to the Bidding documents, which may become necessary as a result of the pre- bid meeting,
shall be made by the Company exclusively through the issuance of an Addendum and/or corrigendum and not
through the minutes of the pre-bid meeting.

8.7​

Payment Schedule

Payment shall be done as per the Payment Terms mentioned in Section 6 of this RFP.
8.8​

Currency of Payments

Payment shall be made in Indian Rupees (INR) only.

8.9​

Delay in Bidder’s Performance

Any unexcused delay by the Bidder in the performance of his implementation/service/other obligations shall
render the Bidder liable to any or all of the following sanctions: forfeiture of his Performance security,
imposition of liquidated damages, and/ or termination of the Contract for default.
If at any time during performance of the Contract, the Bidder should encounter conditions impeding timely
implementation of the Solution and/or performance of services, the Bidder shall promptly notify IIITB in
writing of the fact of delay, its likely duration and cause(s), before the scheduled
delivery/installation/implementation date. IIITB shall evaluate the situation after receipt of the Bidder’s notice
and may at their discretion extend the Bidder’s time for delivery/installation/implementation, in which case
the extension shall be ratified by the parties by amendment of the Contract. If the Bidder’s request for delay in
the implementation of the Solution and performance of services is not found acceptable to IIITB, the above
mentioned clause will be invoked.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 37

<!-- page 38 -->

Request for Proposal

8.10​ Repeat Order
IIITB at its discretion may place repeat orders or any other orders based on its business requirements during
the tenure of the Contract.

8.11​ Other RFP Requirements
i.​ Technical Inspection and Performance Evaluation - IIITB may choose to carry out a technical
inspection/audit and performance of the solution.
ii.​ The Bidder would permit IIITB or any person/persons designated by IIITB to observe the technical and
performance evaluation/benchmarks carried out by the Bidder.
iii.​ The Bidder will identify a representative as a single point of contact for IIITB

8.12​

Completeness of the Project

The Project will be deemed as incomplete if the desired objectives mentioned in Section 2–Detailed Scope of
Work of this document are not achieved.

8.13​ Canvassing / Contacting
Any effort by a Bidder to influence the Company in its decisions on Bid evaluation, Bid comparison or Award of
Contract may result in the rejection of the Bidder's Bid. No Bidder shall contact the Company on any matter
relating to its Bid, from the time of opening of Commercial Bid to the time the Contract is awarded.

8.14​ Indemnity
The Bidders should indemnify IIITB (including its employees, directors or representatives) from and
against claims, losses, and liabilities arising from:
a)​ Non-compliance of the Bidder with Laws/Governmental requirements
b)​ IP infringement
c)​ Negligence and misconduct of the Bidder, its employees, and FTEs
Indemnity would be limited to court awarded damages and shall exclude indirect, consequential and incidental
damages. However, indemnity would cover damages, loss or liabilities suffered by IIITB arising out of claims
made by its customers and/or regulatory authorities.

8.15​ Inspection of records
All Bidder records with respect to any matters covered by this RFP shall be made available to IIITB or its
designees at any time during normal business hours, as often as IIITB deems necessary, to audit, examine, and
make excerpts or transcripts of all relevant data. Said records are subject to examination. IIITB would execute
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 38

<!-- page 39 -->

Request for Proposal

confidentiality agreement with the Bidder, provided that the auditors would be permitted to submit their
findings to IIITB, which would be used by IIITB. The cost of the audit will be borne by IIITB. The scope of such
audit would be limited to Service Levels being covered under this RFP and subsequent contract, and financial
information would be excluded from such inspection, which will be subject to the requirements of statutory
and regulatory authorities. The Bidder‘s records and sites managed for IIITB shall also be subject to
Regulator/IIITB inspection.

8.16​ Publicity
Any publicity related to this project by the Bidder in which the name of IIITB, NIMHANS or government
department or agency is to be used, should be done only with the written permission from IIITB.
8.17​

Solicitation of Employees

Both the parties agree not to hire, solicit, or accept solicitation (either directly, indirectly, or through a third
party) for their employees directly involved in this Contract during the period of the Contract and one year
thereafter, except as the parties may agree on a case-by-case basis. The parties agree that for the period of the
Contract and one year thereafter, neither party will cause or permit any of its directors or employees who have
knowledge of the agreement to directly or indirectly solicit for employment the key personnel working on the
project contemplated in this proposal except with the written consent of the other party. The above restriction
would not apply to either party for hiring such key personnel who
i)​ initiate discussions regarding such employment without any direct or indirect solicitation by the other
party
ii)​ respond to any public advertisement placed by either party or its affiliates in a publication of general
circulation or
iii)​ has been terminated by a party prior to the commencement of employment discussions with the other
party.
8.18​

Penalties on Non Compliance of SLA

IIITB expects the Bidder to provide uninterrupted services to IIITB. Inability of the Bidder to either ensure
readiness of the services as per specifications within defined timelines or to meet the service levels as specified
in RFP shall be treated as breach of Contract and would invoke the penalty clause.
8.19​ Liquidated Damages
i.​

If the deliverables are not acceptable to IIITB as mentioned in this RFP and defects are not rectified to
the satisfaction of IIITB within 30 days of the receipt of the notice, the Bidder shall be liable for
Liquidated Damages for an amount equal to 0.5% of the Total Cost of the Services for every week or part
thereof for the delay.

ii.​

Any additional circumstances applicable for Bidder’s liability for liquidated damages will be worked out
during the contracting phase.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 39

<!-- page 40 -->

Request for Proposal

iii.​

The amount of liquidated damages under this Contract shall not exceed 3% of the Total value of the
Contract as specified in Annexure 9-Commercial Bid Form. The Total Contract value in this context will
include all the charges calculated for the agreement duration based on proposed rates in Annexure 9 –
Commercial Bid Form.

8.20​ Confidentiality
Bidder understands and agrees that all materials and information marked and identified by IIITB as
‘Confidential’ are valuable assets of IIITB/Government agencies and are to be considered their proprietary
information and property. Bidders will treat all confidential materials and information provided by
IIITB/Government Agencies with the highest degree of care necessary to ensure that unauthorized disclosure
does not occur. Bidder will not use or disclose any materials or information provided by IIITB/Government
Agencies without IIITB's prior written approval.
Bidder shall not be liable for disclosure or use of any materials or information provided by IIITB or developed
by Bidder which is:
i.​ possessed by Bidder prior to receipt from IIITB, other than through prior disclosure by IIITB, as documented
by Bidder's written records;
ii.​ published or available to the general public otherwise than through a breach of Confidentiality; or
iii.​ obtained by Bidder from a third party with a valid right to make such disclosure, provided that said third
party is not under a confidentiality obligation to IIITB; or
iv.​ Developed independently by the bidder.
In the event that Bidder is required by judicial or administrative process to disclose any information or
materials required to be held confidential hereunder, Bidder shall promptly notify IIITB and allow IIITB a
reasonable time to oppose such process before making disclosure.
Bidder understands and agrees that any use or dissemination of information in violation of this Confidentiality
Clause will cause IIITB irreparable harm, may leave IIITB with no adequate remedy at law and IIITB is entitled to
seek injunctive relief.
Nothing herein shall be construed as granting to either party any right or license under any copyrights,
inventions, or patents now or hereafter owned or controlled by the other party.
The requirements of use and confidentiality set forth herein shall survive the expiration, termination or
cancellation of this RFP.

8.21​ Force Majeure
i.​

Definition:

a.​ For the purposes of this Contract, “Force Majeure” means an event which is beyond the reasonable

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 40

<!-- page 41 -->

Request for Proposal

control of a Party, is not foreseeable, is unavoidable and not brought about by or at the instance of the
Party claiming to be affected by such events and which has caused the non-performance or delay in
performance, and which makes a Party’s performance of its obligations hereunder impossible or so
impractical as reasonably to be considered impossible in the circumstances, and includes, but is not
limited to, war, riots, civil disorder, earthquake, fire, explosion, storm, flood or other extreme adverse
weather conditions, strikes, lockouts or other industrial action (except where such strikes, lockouts or
other industrial action are within the power of the Party invoking Force Majeure to prevent),
confiscation or any other action by Government Agencies.
b.​ Force Majeure shall not include:
•​ Any event which is caused by the negligence or intentional action of a Party or by or of such Party’s
Sub-Consultants or FTEs or Employees, or
•​ Any event which a diligent Party could reasonably have been expected both to take into account at the
time of the conclusion of this Contract, and avoid or overcome in the carrying out of its obligations
hereunder.
c.​ Force Majeure shall not include insufficiency of funds or inability to make any payment required
hereunder.
ii.​

No Breach of Contract:

The failure of a Party to fulfil any of its obligations hereunder shall not be considered to be a breach of, or
default under, this Contract insofar as such inability arises from an event of Force Majeure, provided that
the Party affected by such an event has taken all reasonable precautions, due care and reasonable
alternative measures, all with the objective of carrying out the terms and conditions of this Contract.
iii.​

Measures to be taken:

a.​ A Party affected by an event of Force Majeure shall continue to perform its obligations under the
Contract as far as is reasonably practical, and shall take all reasonable measures to minimize the
consequences of any event of Force Majeure.
b.​ A Party affected by an event of Force Majeure shall notify the other Party of such event as soon as
possible, and in any case not later than fourteen (14) days following the occurrence of such event,
providing evidence of the nature and cause of such event, and shall similarly give written notice of the
restoration of normal conditions as soon as possible.
c.​ Any period within which a Party shall, pursuant to this Contract, complete any action or task, shall be
extended for a period equal to the time during which such Party was unable to perform such action as
a result of Force Majeure.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 41

<!-- page 42 -->

Request for Proposal

d.​ During the period of their inability to perform the Services as a result of an event of Force Majeure,
the Bidder, upon instructions by IIITB, shall either:
●​
●​

demobilize; or
Continue with the Services to the extent possible, in which case they shall continue to be paid
proportionately and on a pro rate basis, under the terms of this Contract.

e.​ In the case of disagreement between the Parties as to the existence or extent of Force Majeure,
the matter shall be settled according to Clause 5.26.

8.22​ Resolution of disputes

IIITB and the Bidder shall make every effort to resolve amicably, by direct informal discussions between the
respective Project Managers of IIITB and the Bidder, any disagreement or dispute arising between them under
or in connection with the Contract. If IIITB’s Project Manager and the Bidder’s Project Manager are unable to
resolve the dispute they shall immediately escalate the dispute to the senior authorized personnel designated
by the Bidder and IIITB respectively. If after thirty days from the commencement of such discussions between
the senior authorized personnel designated by the Bidder and IIITB, IIITB and the Bidder have been unable to
resolve amicably a Contract dispute; either party may require that the dispute be referred for resolution
through formal arbitration. All questions, claims, disputes or differences arising under and out of, or in
connection with the Contract or carrying out of the work whether during the progress of the work or after the
completion and whether before or after the determination, abandonment or breach of the Contract shall be
referred to arbitration by a sole Arbitrator acceptable to both parties failing which the number of arbitrators
shall be three, with each side to the dispute being entitled to engage one arbitrator. The two arbitrators
engaged by the parties shall engage a third arbitrator who shall act as the presiding arbitrator. The Arbitration
and Reconciliation Act, 1996 or any statutory modification thereof shall apply to the arbitration proceedings
and the venue of the arbitration shall be Bangalore. The arbitration proceedings shall be conducted in English
language. The arbitration award shall be final, conclusive and binding upon the Parties and judgment may be
entered thereon, upon the application of either Party to a court of competent jurisdiction. Each Party shall
bear the cost of preparing and presenting its case, and the cost of arbitration, including fees and expenses of
the arbitrators, shall be shared equally by the Parties unless the award otherwise provides.

8.23​ Waiver
No failure or delay on the part of either party relating to the exercise of any right, power, privilege or remedy
provided under this RFP document or subsequent agreement with the other party shall operate as a waiver of
such right, power, privilege or remedy or as a waiver of any preceding or succeeding breach by the other
party nor shall any single or partial exercise of any right power privilege or remedy preclude any other or
further exercise of such or any other right power privilege or remedy provided in this RFP document all of
which are several and cumulative and are not exclusive of each other or of any other rights or remedies
otherwise available to either party at law or in equity.
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 42

<!-- page 43 -->

Request for Proposal

8.24​ Violation of terms
IIITB clarifies that IIITB shall be entitled to an injunction, restraining order, right for recovery, suit for specific
performance or such other equitable relief as a court of competent jurisdiction may deem necessary or
appropriate to restrain the Bidder from committing any violation or enforce the performance of the covenants,
obligations and representations contained in this RFP document. These injunctive remedies are cumulative and
are in addition to any other rights and remedies IIITB may have at law or in equity, including without limitation
a right for recovery of any amounts and related costs and a right for damages.

8.25​

Termination for Default

IIITB may, without prejudice to any other remedy for breach of contract, by 60 calendar days’ written notice of
default sent to the SP, terminate the Contract in whole or in part:
a)​
If the Bidder fails to deliver any or all of the Solution and services within the time period(s) specified in
the Contract, or any extension thereof granted by IIITB; or
b)​
If the Bidder fails to perform any other obligation(s) under the Contract.
In the event of IIITB terminating the Contract in whole or in part, pursuant to above mentioned clause, IIITB
may procure, upon such terms and in such manner, as it deems appropriate, goods and services similar to
those undelivered and the Bidder shall be liable to IIITB for any excess costs incurred for procurement of such
similar goods or services. However, the bidder shall continue performance of the Contract to the extent not
terminated.

8.26​

Termination for Insolvency

IIITB may, at any time, terminate the Contract by giving 90 calendar days’ written notice to the Bidder, without
any compensation to the Bidder, whatsoever if:
i.​
The Bidder becomes bankrupt or otherwise insolvent, provided that such termination will not prejudice
or affect any right of action or remedy which has accrued or will accrue thereafter to IIITB.
ii.​
The Bidder being a company is wound up voluntarily or by the order of a court or a receiver, or manager
is appointed on behalf of the debenture/shareholders or circumstances occur entitling the court or
debenture/shareholders to appoint a receiver or a manager, provided that such termination will not prejudice
or affect any right of action or remedy accrued or that might accrue thereafter to the IIITB.

8.27​

Information Ownership

All information processed, stored, or transmitted by Bidder equipment belongs to IIITB. By having the
responsibility to maintain the equipment, the Bidder does not acquire implicit access rights to the information
or rights to redistribute the information. The Bidder understands that civil, criminal, or administrative penalties
may apply for failure to protect information appropriately.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 43

<!-- page 44 -->

Request for Proposal

8.28​

Sensitive Information

Any information considered sensitive must be protected by the Bidder from unauthorized disclosure,
modification or access.

8.29​ Technological Advancements
The Bidder agrees to incorporate all changes relating to the platform features being offered, announced by
them from time to time keeping in view the advancement in technology, shortcomings of the platform and
services made available to IIITB and undertake any changes or upgrades required during the implementation
period for improving the overall efficiency of the TMCs and the initiative.

8.30​

Governing Language

The Contract shall be written in the language of the Bid i.e. English. All correspondence and other documents
pertaining to the Contract, which are exchanged by the parties, shall be written in that same language. English
Language version of the Contract shall govern its implementation.

8.31​ Applicable Law
The Contract shall be interpreted in accordance with the Indian Laws for the time being in force and will be
subject to the exclusive jurisdiction of Courts at Bangalore (with the exclusion of all other Courts).

8.32​ Prices
The prices quoted (as mentioned in Annexure 9- Commercial Bid Form submitted by the Bidder) for the
solution and services shall be firm throughout the period of the Contract and shall not be subject to any
escalation.

8.33​ Deduction
Payments shall be subject to deductions (such as TDS) of any amount, for which the Bidder is liable under the
agreement against this RFP.

8.34​

Taxes and Duties

The prices quoted by the Bidder shall include all costs such as, taxes, levies, cess, excise, Octroi and custom
duties, installation, commissioning, insurance if any, etc. as applicable in India, that need to be incurred. The
Bidder has to quote the GST, Cess and any other applicable taxes in separate columns. The entire benefits/
advantages, arising out of fall in prices, taxes, duties or any other reason, must be passed on to IIITB.

8.35​

No Claim Certificate

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 44

<!-- page 45 -->

Request for Proposal

The bidder shall not be entitled to make any claim whatsoever against IIITB under or by virtue of or arising out
of this Contract, nor shall IIITB entertain or consider any such claim, if made by the Bidder after he shall have
signed a “No Claim” certificate in favor of IIITB in such forms as shall be required by IIITB after all payments
due to Bidder are made in full.

8.36​ Rights reserved by IIITB
i.​
IIITB reserves the right to accept or reject any or all Bids without assigning any reasons.
ii.​
IIITB reserves the right to verify the validity of information given by the Bidders. If at any future point
of time, it is found that the Bidder had made a statement, which is factually incorrect, IIITB will reserve the
right to debar the Bidder from bidding prospectively for a period to be decided by IIITB and take any other
action as maybe deemed necessary.
iii.​
IIITB reserves the right to issue a fresh RFP at any time during the validity of the Contract period with
the selected Bidder.

8.37​ Subcontracting
Subcontracting of the work awarded to the selected Bidder in full or partial mode is not permitted under any
circumstances.

8.38​ Rejection of Bids
IIITB reserves the right to reject any or all the Bids or scrap the bidding process at any stage till notification of
award without assigning any reason. The Earnest Money Deposit in such an event will be refunded by IIITB. In
case IIITB scraps the bidding process, the RFP tender processing fees will also be refunded.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 45

<!-- page 46 -->

Request for Proposal

9​ Annexures
Annexure 1: Pre Bid Query Format
If a bidder, intending to respond to the RFP for Expansion and Support Services for MahaVISTAAR at IIITB &
COSS team, requires any clarifications on the points mentioned in the RFP, they may communicate with the
International Institute of Information Technology Bangalore using the format provided below.
All queries should be compiled in the specified documentation format and sent via email to:
oansocial@coss.org.in

S. No. Page No.

Date:​

Section
point No.

RFP Clause

Remarks

Seal and signature of the bidder

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 46

<!-- page 47 -->

Request for Proposal

Annexure 2: Cover Letter
RFP for Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR,
03-Jul-2025
Date:
To,
Centre for Open Societal Systems
International Institute of Information Technology Bangalore
26/C, Electronics City Phase 1,
Hosur Road, Bengaluru,
Karnataka – 560 100
Dear Sir,
Sub: RFP for Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR,
03-Jul-2025
Having examined the RFP documents including all annexures the receipt of which is hereby duly acknowledged,
we, the undersigned, offer to provide Call Center services to IIITB as mentioned in RFP document in conformity
with the said RFP documents in accordance with the Commercial Bid and made part of this RFP.
We understand that the RFP provides generic specifications about all the items and it has not been prepared by
keeping in view any specific bidder.
We understand that the RFP floated by IIITB is a confidential document and we shall not disclose, reproduce,
transmit or make it available to any other person.
We have read, understood and accepted the Terms/ Conditions/ Rules mentioned in the RFP.
Until a formal contract is prepared and executed, this RFP offer, together with IIITB’s written acceptance thereof
and IIITB’s notification of award, shall constitute a binding contract between us.
We undertake that in competing for and if the award is made to us, in executing the subject Contract, we will
strictly observe the laws against fraud and corruption in force in India namely “Prevention of Corruption Act
1988”.
We have never been barred/black-listed by any regulatory / Statutory Authority/PSU/Government undertaking in
India.
We also understand that the whole bidding exercise may be scrapped without assigning any reason and it is
acceptable to us.
This Bid, together with your written acceptance thereof and your notification of award, shall constitute a binding
Contract between us.
We certify that we have provided all the information requested by IIITB in the format requested for. We also
understand that IIITB has the exclusive right to reject this offer in case IIITB is of the opinion that the required
information is not provided or is provided in a different format. It is also confirmed that the information
submitted is true to our knowledge and IIITB reserves the right to reject the offer if anything is found incorrect.
Place:
Date:​

Seal and signature of the bidder

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 47

<!-- page 48 -->

Request for Proposal

Annexure 3: Confirmation of Eligibility Criteria
(On Bidder’s Letter Head)
Date:
To,
Centre for Open Societal Systems
International Institute of Information Technology Bangalore
26/C, Electronics City Phase 1,
Hosur Road, Bengaluru,
Karnataka – 560 100
Dear Sir,
Reference: RFP for Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet MahaVISTAAR, 03-Jul-2025

Ser

Eligibility Criteria Requirements

Supporting documents required

1

The Bidder should be a Government
Organization/PSU/Public/Partnership/Private limited
company or subsidiary thereof.
The Bidder/Group Company/ Subsidiary/ Parental
Company should have been in operation for at least 3
years as on date of RFP. In case the current Bidder
Company is the result of a merger / acquisition, at least
one of the merging companies should have been in
operation for at least 3 years as on date of RFP.
The Bidder/Group Company/ Subsidiary/ Parental
Company should be profitable in two out of last three
financial years (2022-23, 2023-24, and 2024-25)

Certificate of Incorporation

2

3

4

5

6
7

Certificate of Incorporation

Audited Financial Statements
for
2022-23, 2023-24, and
2024-25 (Or) Certificate from
the chartered accountant
The Bidder/Group Company/ Subsidiary/ Parental
Audited Financial Statements
Company should have a minimum turnover of INR 5 crores for the financial years 2022-23,
2023-24, and 2024-25 (Or)
per annum in two of the last three financial years
Certificate from the​ chartered
accountant
The bidder should not have been blacklisted by any Self-Declaration certified by
Government or PSU enterprise in India as on the date of authorized signatory of the bidder
the RFP
The Solution is provided by the Bidder/Group Company/
Self-Declaration certified by
Subsidiary/ Parental Company
authorized signatory of the bidder
Bidder should be willing to deliver services from Mumbai
or other places in Maharashtra if requested

Self-Declaration certified by
authorized signatory of the bidder

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 48

<!-- page 49 -->

Request for Proposal

Note:
a.​
Bidders need to ensure compliance to all the eligibility criteria points.
b.​
Purchase orders without relevant organization confirmation through a credential letter will not be
considered as credentials.
●​
The decision of the IIITB shall be final and binding in this regard. Deviations will be grounds for
disqualification. Bidders who meet all these criteria would qualify for the second stage of evaluation. The
Bidder would also need to provide supporting documents for eligibility proof. All the credentials of the
Bidder necessarily need to be relevant to the Indian market. The decision of IIITB shall be final and
binding on all

Place:
Date:​

Seal and signature of the bidder

(This letter should be on the letterhead of the bidder duly signed by an authorized signatory)

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 49

<!-- page 50 -->

Request for Proposal

Annexure 4: Undertaking for Data and Information Security
(On the Letterhead of the bidder)
Strictly Private and Confidential
To,
Centre for Open Societal Systems
International Institute of Information Technology Bangalore
26/C, Electronics City Phase 1,
Hosur Road, Bengaluru,
Karnataka – 560 100
Dear Sir,
Sub: RFP for Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR,
03-Jul-2025
We acknowledge that during the course of Bid evaluation and subsequent signing of contract with the
successful bidder against the Request for Proposal (RFP) floated for Expansion and Support service for
MahaVISTAAR to IIITB, we shall have access to and be entrusted with confidential Information. In this letter,
the phrase "Confidential Information" shall mean information (whether of a farmer, farm records, commercial,
technical, scientific, operational, administrative, financial, marketing, business, physical data, digital data or
intellectual property nature or otherwise), whether oral or written, relating to IIITB and its business that is
provided to us pursuant to this undertaking.
In consideration of you making Confidential Information available to us, we agree to the terms set out below:
1.​ We shall treat all confidential Information as strictly private and confidential and take all steps
necessary (including but not limited to those required by this undertaking) to preserve such
confidentiality.
2.​ We shall use the confidential information solely for the preparation of our response to the RFP and
subsequently showcasing our capabilities to the evaluation committee and not for any other purpose.
3.​ We shall not disclose any confidential Information to any other person or firm, other than as permitted
by IIITB.
4.​ We shall not disclose or divulge any of the confidential Information to any other client of [name of
product vendor / implementation partner].
5.​ This undertaking shall not prohibit disclosure of Confidential Information:
a.​ To our partners/ directors and employees who need to know such Confidential Information to
assist with the bidding for RFP floated:
b.​ To the extent that such disclosure is required by law;
c.​ To the extent that such disclosure is required by any rule or requirement of any regulatory
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 50

<!-- page 51 -->

Request for Proposal

authority with which we are bound to comply; and
d.​ To our professional advisers for the purposes of seeking advice. Such professional advisors will be
informed of the need to keep the information confidential.
6.​ Upon your request we shall arrange delivery to you of all Confidential Information, and copies
thereof, that is in documentary or other tangible form, except:
a.​ For the purpose of a disclosure permitted by item 5 above; and
b.​ To the extent that we reasonably require to retain sufficient documentation that is necessary
to support any advice, reports, or opinions that we may provide.
7.​ This undertaking shall not apply to Confidential Information that:
a.​ Is in the public domain at the time it is acquired by us;
b.​ Enters the public domain after that, otherwise than as a result of unauthorized disclosure by
us;
c.​ Is already in our possession prior to its disclosure to us;
d.​ and is independently developed by us.

8.​ This undertaking shall continue perpetually unless and to the extent that you may release it in
writing.
We warrant that we are acting as principal in this matter and not as FTE or broker for any person, company, or
firm.
We acknowledge that no failure or delay by you in exercising any right, power or privilege under this
undertaking shall operate as a waiver thereof nor shall any single or partial exercise thereof or the exercise of
any other right, power, or privilege.
This undertaking shall be governed by and construed in accordance with Indian law and any dispute arising
from it shall be subject to the exclusive jurisdiction of the Bangalore courts.

Yours sincerely
Name of Authorized Representative: ​

Signature of Authorized Representative: ​

Verified above signature Place:

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 51

<!-- page 52 -->

Request for Proposal

Date:​

Seal and signature of the bidder

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 52

<!-- page 53 -->

Request for Proposal

Annexure 5: Technical Bid format
Particulars to be provided by the bidder in the technical proposal
RFP for Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR,
03-Jul-2025,
Ser

Particulars

1

Name of the bidder

2

3

Year of establishment and constitution
Certified copy of “Partnership Deed” or “Certificate of
Incorporation” should be submitted as the case may be.
Location of Registered office /Corporate office and address

4

Mailing address& Company website of the bidder

5

Names and designations of the persons authorized to make
commitments to IIITB
Telephone and fax numbers of contact persons
E-mail addresses of contact persons

6
7
8

Description​ of​
business​
background
Service Profile & client profile
Domestic & International presence
Alliance and joint ventures

Details to be furnished by
the bidder

and​

business

Declaration:
1​

We confirm that we will abide by all the Terms and Conditions contained in the RFP.

2​
We hereby unconditionally accept that IIITB can at its absolute discretion apply whatever criteria
it deems appropriate, not just limiting to those criteria set out in the RFP, in shortlisting of bidders.
3​
All the details mentioned by us are true and correct and if IIITB observes any misrepresentation of
facts on any matter at any stage, IIITB has the absolute right to reject the proposal and disqualify us from
the selection process.
4​
We confirm that this response, for the purpose of short-listing, is valid for a period of 365 days,
from the date of expiry of the last date for submission of response to RFP.
5​
We confirm that we have noted the contents of the RFP and have ensured that there is no
deviation in filing our response to the RFP and that IIITB will have the right to disqualify us in case of any
such deviations.
Place:

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 53

<!-- page 54 -->

Request for Proposal

Date:​

Seal and Signature of the bidder

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 54

<!-- page 55 -->

Request for Proposal

Annexure 6: Statement of No Deviation from RFP
Terms and Conditions
Date
To,
Centre for Open Societal Systems
International Institute of Information Technology
Bangalore
26/C, Electronics City Phase 1,
Hosur Road, Bengaluru,
Karnataka – 560 100
Dear Sir,
Reference: RFP for Expansion and support service for
MahaVISTAAR, I IIITB/COSS/2025/OpenAgriNet MahaVISTAAR, 03-Jul-2025

There are no deviations (null deviations) from the terms and Conditions of the RFP. All the terms and
conditions of the RFP are acceptable to us.
Witness​

​

​

​

​

​

Bidder

Signature​

Signature

Name​

Name

Designation​

Designation

Address​

Address

Company​

Company

Date​

​

Date

Company Seal

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 55

<!-- page 56 -->

Request for Proposal

Annexure 7: Bidder’s Past Experience
Date:
To,
International Institute of Information Technology
Bangalore
26/C, Electronics City Phase 1,
Hosur Road, Bengaluru,
Karnataka – 560 100
Dear Sir,
Reference: RFP for Expansion and support service for
MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet MahaVISTAAR, 03-Jul-2025

Ser

Client’s
Name

Client
Vertical

Scope
of
Work

Number
of
impleme
ntations
& size of
team

Client Contact
Remarks
Details along
with contact
person name,
designation,
phone number &
email id

Supporting
Document attached
(PO & Credential
Letter etc.)
Yes/No

Place:
Date:​

Seal and signature of the bidder

(This letter should be on the letterhead of the bidder duly signed by an authorized signatory)
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 56

<!-- page 57 -->

Request for Proposal

Annexure 8: Commercial Compliance
Certificate

Date:

To,
Centre for Open Societal Systems
International Institute of Information Technology Bangalore
26/C, Electronics City Phase 1,
Hosur Road, Bengaluru,
Karnataka – 560 100

Dear Sir,
Sub: RFP for Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR,
03-Jul-2025
Having examined the Bidding Documents, the receipt of which is hereby duly acknowledged, we, the
undersigned, offer to supply and work as a bidder as mentioned in the RFP document & in conformity
with the said bidding documents for the same.
I / We undertake that the prices are in conformity with the specifications prescribed.
I / We agree to abide by this bid for a period of 270 (Two hundred and seventy only) days after the date
fixed for bid opening and it shall remain binding upon us and may be accepted by IIITB, any time before
the expiry of this period.
Until a formal contract is prepared and executed, this bid, together with your written acceptance thereof
and your notification of award shall constitute a binding Contract between us.
I / We understand that you are not bound to accept the lowest or any bid you may receive. I
/ We agree to the Terms & Conditions mentioned in the RFP document. Further, we confirm that we will
abide by all the terms and conditions mentioned in the Request for Proposal document.
I/ we agree that IIITB reserves the right to renew the contract post completion of the 7-year period for
additional two years at mutually agreed price.
Place:
Date:​

Seal and Signature of the Bidder

(This letter should be on the letterhead of the bidder duly signed by an authorized signatory)
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 57

<!-- page 58 -->

Request for Proposal

Annexure 9: Commercial Bid Form
We recommend you to use this reference pricing template for populating your financials. Financials
should factor the cloud cost of hosting the solution for the duration of the contract. In addition to the details,
please also include a summary of the financials. The proposal must be inclusive of taxes.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 58

<!-- page 59 -->

Request for Proposal

Annexure10: Format of Bank Guarantee
(To be Stamped in accordance with Stamp act)
Bank Guarantee No:

Date:

To,
Centre for Open Societal Systems
International Institute of Information Technology Bangalore
26/C, Electronics City Phase 1,
Hosur Road, Bengaluru,
Karnataka – 560 100
Dear Sir,
Sub: RFP for Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR,
03-Jul-2025
In accordance with your proposal reference no.​
​
M/s​ ​
​

dated

having its registered office at ​ ​
​
herein after called ‘bidder’) wish to participate in the said
proposal for Support Services to International Institute of Information Technology Bangalore having its premises
at 26/C, Electronics City Phase 1, Hosur Road, Bengaluru, Karnataka – 560 100.
An irrevocable Financial Bank Guarantee (issued by a nationalized / scheduled commercial Bank) against Earnest
Money Deposit amounting to Rupees​
Rupees (in words)​
valid up to​ is
required to be submitted by the bidder, as a condition for participation in the said bid, which amount is liable to
be forfeited on happening of any contingencies mentioned in the proposal document.

having its registered office at​
has undertaken in pursuance of their offer to International
Institute of Information Technology, Bangalore (hereinafter called as the beneficiary) dated
​
has expressed its intention to participate in the said proposal and in terms thereof has
approached us and requested
us
​
​
Bank​
​
to issue an irrevocable financial Bank Guarantee against Earnest Money Deposit amounting to Rupees​
valid
up to​
.
We, the​
​
Bank at​
having our Head office at​
therefore, Guarantee and undertake to pay immediately on first written demand by International Institute of
Information Technology Bangalore, the amount of Rupees

Rupees ​
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 59

<!-- page 60 -->

Request for Proposal

​
without any reservation, protest,
demur and recourse in case the bidder fails to comply with any condition of the
proposal or any default in violation against the terms of the bid, without the beneficiary needing to prove or
demonstrate reasons for its such demand. Any such demand made by said beneficiary shall be conclusive and
binding on us irrespective of any dispute or difference raised by the bidder.
This guarantee shall be irrevocable and shall remain valid up to​
. If any further
extension of this Guarantee is required, the same shall be extended to such required period on receiving
instructions in writing, from (​
​ )
on
whose behalf guarantee is issued.
In witness whereof IIITB, through its authorized officer has set its hand stamped on this
​
Day of​
2025 at ​

Signed, sealed and delivered by Mr. ………

For and on behalf of the Guarantor to do so and to affix the seal of IIITB, in the presence of

Office Seal​

(Authorized Signatory)

Place:​

Name:

Date:​

Designation:

Mobile No:
Business Address:

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 60

<!-- page 61 -->

Request for Proposal

Annexure 11: Authorization Letter to Attend Bid Opening

Date:

To,
Centre for Open Societal Systems
International Institute of Information Technology
Bangalore
26/C, Electronics City Phase 1,
Hosur Road, Bengaluru,
Karnataka – 560 100
Dear Sir,

Sub: RFP No. Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet MahaVISTAAR, 03-Jul-2025
Mr./Ms.​
due on................ at​

has been authorized to be represent the time of opening of above RFP
on my/our behalf.

Yours faithfully Place:
Date:​

Copy to: Mr./Ms.​
RFP

Seal and Signature of the Bidder

for information and for production before the

Opening Committee at the time of opening of Bids.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 61

<!-- page 62 -->

Request for Proposal

Annexure 12: Proforma for Performance Bank Guarantee
(To be stamped in accordance with stamp act)
Reference No: __________________________________
______________

Date:

Bank Guarantee No: ____________________________
To: ________________________________________________
​
Against contract vide advance acceptance of the RFP No. Expansion and support service for MahaVISTAAR,
IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 03-Jul-2025 covering supply of​ (herein after called the said
‘contract’) entered into between International Institute of Information Technology Bangalore (herein after called
the Purchaser) and​
(herein after called the Vendor) this is to certify that at the request of the Vendor, we
​
(Name of the Bank), are holding in trust in favour of the Purchaser, the amount of Rupees
​
(write the sum herein words) to indemnify and keep indemnified
the Purchaser against any loss or damage that may be caused to or suffered by the Purchaser by reason of any
breach by the Vendor of any of the Terms and Conditions of the said contract and/or in the performance
thereof. We agree that the decision of the Purchaser, whether any breach of any of the Terms and Conditions of
the said contract and/or in the performance thereof has been committed by the Vendor and the amount of loss
or damage that has been caused or suffered by the Purchaser shall be final and binding on us and the amount
of the said loss or damage shall be paid by us forth with on demand and without demur to the Purchaser.
We​
(Name of the Bank) further agree that the guarantee herein
contained shall remain in full force and effect during the period that would be taken for satisfactory
performance and fulfillment in all respects of the said contract by the Vendor
i.e. till​
(viz. the date up to 12 months after the date of signing of the contract between
the Vendor and the Purchaser) hereinafter called the said date and that if any claim accrues or arises against us
​
(Name of the Bank) by virtue of this guarantee before the said date, the same
shall been force able against us
​
(Name of the Bank), notwithstanding the fact that the same is
enforced within six months after the said date,
provided​
that notice of any such claim has been
given to us​
​
(Name of the Bank), by the Purchaser
before the said date. Payment under this letter of guarantee shall be made promptly upon our receipt of notice
to that effect from the Purchaser.
It is fully understood that this guarantee is effective from the date of the said contract and that we​
(Name
of the Bank), undertake not to revoke this guarantee during its currency without the consent in writing of the
Purchaser.
We undertake to pay to the Purchaser any money so demanded not withstanding any dispute or disputes raised
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 62

<!-- page 63 -->

Request for Proposal

by the Vendor in any suitor proceeding pending before any court or tribunal relating thereto our liability under
this present bond being absolute and unequivocal.
The payment made by us under this bond shall be a valid discharge of our liability for payment there under and
the Vendor shall have no claim against us for making such payment.
We​
(Name of the Bank), further agree that the Purchaser shall have
the fullest liberty, without affecting in any manner our obligations hereunder to vary any of the terms and
conditions of the said contractor to extend the time of performance by the Vendor from time to time or to
postpone for any time from time to time any of the power exercisable by the Purchaser against the said Vendor
and to forebear or enforce any of the terms and​conditions relating to the said​ contract and​ we,

(Name of the Bank), shall not be released from our liability under this guarantee by reason of any such variation
or extension being granted to the said Vendor or for any forbearance by the Purchaser to the said Vendor or for
any forbearance and/or omission on the part of the Purchaser or any other matter or thing whatsoever, which
under the law relating to sureties, would, but for this provision have the effect of sore leasing us from liability
under this guarantee.
This guarantee will not be discharged due to the change in the constitution of the Bank or the Vendor.
Office Seal​

(Authorized Signatory)

Place:​

Name:

Date:​

Designation:
Mobile No:
Business Address:

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 63

<!-- page 64 -->

Request for Proposal

Annexure 13: Grievance Redressal Policy IIITB

1. INTRODUCTION

The purpose of this policy is to outline the processes the institution uses to manage and respond to
Vendor grievances. IIITB believes in the philosophy of an open-door policy in the matter of
redressal of vendors’ grievances. An aggrieved vendor can address his grievance under this policy.
2. POLICY STATEMENT AND SCOPE

All Vendors must be treated in a fair and transparent way to redressal of grievance. This policy is a
broad guideline for the grievance redressal mechanism which shall be modified/updated from time
to time.
3. OBJECTIVES

The objective of the Grievance Redressal Procedure is to provide an easily accessible machinery for
settlement of grievances and to adopt measures that would ensure expeditious settlement of
grievances of the vendor leading to increased satisfaction and resulting in improved quality work
with the organization.
4. PROCEDURE

Types of Grievance
4.1 Pre-award grievance - Occurs when a Vendor is informed prior to the contract award
announcement. Matters related to the under noted subjects will not be considered as grievances
under this policy
a. Tender Specification terms and conditions
b. Evaluation Criteria
c. Tender Evaluation process
4.2 Post award grievance- Matters related with the statutory provisions/permission etc. will not be
considered as grievances under this policy and all such issues previously communicated to the
grievance committee shall also not be considered.

5. TIMELINES
●​ Pre-award grievance - Must be submitted within 3 days from the date of issuance of RFQ/Tender.
●​ Post-award grievance - Work Order/Purchase Order or actual cause of grievance when arrived.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 64

<!-- page 65 -->

Request for Proposal

6. GRIEVANCE RESPONSE TEAM:

The member of the grievance Team shall be:
●​ A member of COSS, IIITB
●​ A member of Finance department of IIITB
●​ A member of the Administrative department of IIITB
7. GRIEVANCE RESOLUTION PROCESS

7.1 STAGE - I
A Member of COSS, IIITB will receive and maintain the record of grievance and will forward the
member of the concerned department for earlier resolution. The member should resolve the
issues within 15 days from receipt of the grievance and intimate to the Grievance response team
for onward submission to the vendor.
7.2 STAGE – II
If it is not resolved at the label of Stage-I/vendor is not satisfied with the reply of Stage-I
committee, the vendor can raise a grievance to Stage-II committee within 3 days from the date of
the communication.
Members of Stage-II Committee:
Mission Lead
Member 1
Member 2
Member 3

Head, COSS
CEO, COSS
CAO
CFO

The committee will examine and resolve the issue within 30 days from date of receipt of
communication.
7.3 Appeal
In case the vendor is not satisfied with the resolution of grievance at Stage-II Level, the vendor
may appeal to the Director, IIITB within 3 days from the date of communication of the
committee of stage II decision.
The decision of the Director, IIITB will be communicated to the aggrieved vendor within a
month of the receipt of his appeal and this decision shall be final and binding on the aggrieved
vendor.

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 65

<!-- page 66 -->

Request for Proposal

Annexure 14: RFP Background and Program Overview
9.14.1 Background
MahaVISTAAR project is an initiative designed to establish a OpenAgriNet (Beckn Protocol-based open
network and an AI-powered layer specifically tailored for the agricultural sector) in Maharashtra. Its primary
goal is to create a decentralised, interoperable, and inclusive ecosystem capable of delivering agricultural
services at a large scale. The project's initial phase was conducted from March 4th, 2025, to June 30th,
2025. This initial phase focused on laying the foundational technological layers for both its Network and AI
components. Building on this successful execution and the critical need to maintain momentum, the project
is now initiating an open bidding process for Phase 2 development to further expand and enhance the
infrastructure
9.14.2 Overview of OpenAgriNet Initiative
OpenAgriNet – is a global coalition of innovators, governments, and organisations committed to
revolutionising agriculture by leveraging digital public infrastructure (DPI) and AI. Its overarching mission is
to support countries in transforming agriculture for a smarter, more resilient future, particularly in
developing areas, and to address challenges like climate change and limited farmer access to essential
services. OAN operates as an AI-powered DPI effort that enables open and decentralised Digital Agriculture
Grids, functioning as a "network of networks" with open protocols and data standards. The initiative aims to
create a decentralised, interoperable, and inclusive ecosystem capable of delivering agricultural services at
scale
9.14.3 Overview of OpenAgriNet MahaVistaar
MahaVISTAAR is the first pilot implementation of OpenAgriNet (OAN) in Maharashtra, designed as a
Beckn Protocol-based open network and an AI-powered layer specifically tailored for the agricultural
sector in the state. During the initial phase, five critical use cases were integrated: weather updates,
mandi price information, standard operating procedures (SOPs) from agricultural universities, warehouse
availability, and Custom Hiring Center (CHC) equipment listings. MahaVISTAAR is envisioned to reach 5
lakh (500,000) farmers every week starting July 2025 and aims for 20% of Maharashtra farmers to
actively use the app, with seamless Agri-stack integration for secure and scalable farmer data
management. The platform also includes a dashboard for tracking user queries and providing analytics.
The technical components of MAhaVistaar System are foundational to its design:
1.​ Beckn Protocol-based Open Network Infrastructure: This forms the core, aiming to connect
various stakeholders across the agriculture value chain, including farmers, agribusinesses,
government bodies, financial institutions, and consumers, fostering more effective collaboration.
The network layer is designed with a cloud-agnostic architecture hosted on
government-managed data centres, ensuring compliance, scalability, and data sovereignty. It
Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 66

<!-- page 67 -->

Request for Proposal

incorporates domain-specific standards tailored to the agricultural sector. The architecture
includes Beckn Adaptor (Provider and Seeker), a Beckn Registry, and a Gateway.
2.​ AI-powered Layer: This component provides intelligent, conversational support to farmers
through an AI-powered chatbot. The chatbot supports voice and text inputs and is functional in
Marathi and English. It features a modular architecture allowing integration with various Large
Language Model (LLM) providers, including OpenAI, Google Gemini, and self-hosted LLMs. This
also includes AI-powered cataloguing systems for smarter data management, enabling informed
decisions and efficient data discovery. Query processing involves AI translation (Bhashini), Vector
Search Tools, and LLM Agents (Llama) integrating with external APIs.
3.​ Toolkits: OAN offers various toolkits including Outcome Visualisation, Network enablement,
Technical Architecture, and Digital Public Goods.

Fig 1: MahaVistaar current architecture

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 67

<!-- page 68 -->

Request for Proposal

Fig 2: AI module Architecture

Fig 3: Architecture indicating the search and discovery over the network

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 68

<!-- page 69 -->

Request for Proposal

9.14.3 Reference Documentation
1.​ Github project
2.​ Gitbook

Expansion and support service for MahaVISTAAR, IIITB/COSS/2025/OpenAgriNet - MahaVISTAAR, 3rd July 2025​
page 69
