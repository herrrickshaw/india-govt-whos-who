---
doc_id: "beee3cae3bd09156"
source_url: "https://www.mangaloreuniversity.ac.in/upload/2026/news-notification/GreenMetric2026.pdf"
ministry: "Mangalore University, Konaje, Karnataka"
title: "UI GreenMetric Sustainable University Rankings-2026"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "355ad2a32b0dcb78"
---

<!-- page 1 -->

<!-- page 2 -->

MANGALORE

UNIVERSITY

Mangalore University has retained the 2nd position in India as Most Sustainable
University for 2026 as per the UI GreenMetric World University Rankings
released on 24th September 2026 at Azerbaijan by the University of Indonesia.
The GreenMetric Ranking is based on green campus and environmental
sustainability and assesses the University’s commitment to the environment and
initiatives towards sustainability. The seven criteria on which the assessment is
made are Setting and infrastructure, Energy and climate change, Waste
management, Water conservation and reuse, Transportation and Education and
Governance and Digitalization.
Overall, 68 Indian Universities have been ranked. Mangalore University is ranked
125th in the world. Among State Public Universities, Mangalore University is
ranked 1st.
