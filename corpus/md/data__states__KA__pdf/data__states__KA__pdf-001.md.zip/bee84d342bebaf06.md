---
doc_id: "bee84d342bebaf06"
source_url: "https://hed.karnataka.gov.in/uploads/media_to_upload1764582927.pdf"
ministry: "Higher Education Department, Karnataka"
title: "10     11 months ago      Regarding implementation of guidelines on mental health safeguards"
date: ""
pages: 8
method: "tesseract:kan+eng"
script: "LATIN"
needs_ocr: false
sha1: "46622a48634be53c"
---

<!-- page 1 -->

she.
GOVERNMENT OF KARNATAKA
No:ED 69 UPC 2024 (E) Karnataka Government Secretariat,
M.S. Building,
Dr. B.R. Ambedkar Veedhi,
Bengaluru, Dated:27-11-2025
CIRCULAR
Sub: Regarding implementation of guidelines on mental health safeguards issued by
Hon'ble Supreme Court in all Educational Institutions of Karnataka, as detailed
in this Circular.
Ref: 1. GO No: ED 69 UPC 2025, Bangalore, dated: 23rd September 2025
2. Addendum Order No: ED 69 UPC 2025, Bangalore,
dated:06.10.2025
tee
In recent years, rising instances of student distress and suicides have been issues of
serious concern and warrant immediate attention of educators, parents, and society at large.
Educational Institutions are not only centres of learning but also spaces that nurture emotional
growth, resilience, and overall well-being of students. It is, therefore, crucial for schools and
colleges to ensure a sensitive, supportive, protective, and empathetic environment that
responds effectively to students’ emotional and psychological needs. Alarmed at the growing
prevalence of emotional disturbance among students and in recognition of the crucial role
that Educational Institutions can play in suicide prevention and mental health promotion,
Hon'ble Supreme Court of India has directed that all schools and colleges shall adopt and
implement a uniform mental health policy and issued binding guidelines to all public and
private schools, colleges, universities, training centres, coaching institutes, residential
academies and hostels for preventing student suicides.

In conformity with the guidelines issued by the Hon’ble Supreme Court in para 35
of Criminal Appeal 6378/2025 on mental health safeguards, Government of Karnataka is
releasing this circular prepared by the High-Power Committee constituted as per Ref(1&2) for
this purpose, for mandatory and immediate compliance by all Government/Aided/Private
Schools, PU Colleges, Degree Colleges, Engineering Colleges, Polytechnics, Agriculture
Colleges, Veterinary Colleges, Nursing Colleges, Medical Colleges, Universities, Tutorial
Institutions, Training Centres, Coaching Centres, residential academies, all other Educational
Institutions and hostels in the State.

1. All Educational Institutions with 100 or more enrolled students shall
appoint/engage at least one in-campus qualified counsellor, psychologist, or
social worker with demonstrable training in child and adolescent mental health.
This target should be achieved by all Government, Aided and Private
Educational Institutions within 06 months from the date of issue of this circular
or at the start of the next academic year, whichever is earlier.

1

<!-- page 2 -->

i. All Government Educational Institutions shall establish formal liaisons for
facilitating needy care and treatment to their students with mental
health problems to avail psychiatric services from the available Mental
health teams at the nearest public health institutions (For eg: Nearest
Govt Medical College Hospital or District Hospital or Taluk Hospital etc,.)
till administrative approval is granted for the posts of qualified
counsellor, psychologist, or social worker.

ii. | Over and above engaging minimum 1 in-campus qualified counsellor for
100 or more students as mentioned above, all Educational Institutions
with student strength less than 100, shall establish formal referral
linkages with external mental health services in proximity to the
respective Institutions.

iii. Institutions shall ensure a minimal student-counsellor ratio of at
least one counsellor for 1500-2000 students. The number of counsellors
shall proportionally increase as the number of students increases. This
standard shall be reviewed periodically.

2. The in-campus counsellors appointed by Educational Institutions shall
mandatorily have a UGC recognized postgraduate degree (MA/MSc.) in
Psychology/Human Development/ Counselling/Social Work with at least 1
month of demonstrable supervised training /Internship (essential) and
preferably 6 months of experience in any clinical or community setting of
conducting psychological interventions after their qualifying postgraduate
examination (desirable). The requisite qualifications, experience and training
criteria will be periodically reviewed and revised.

3. The in-campus counsellors engaged by Educational Institutions need to be
considered as health service providers under the non-teaching staff category
and should be exclusively engaged for counselling as well as supporting other
mental health promotion activities.

4. Dedicated faculty Mentors shall be assigned to smaller batches of students,
especially during examination periods and academic transitions, to provide
consistent, informal, and confidential support. A definite action plan regarding
the mentors assigned and the details of the activities undertaken to support
students in coping with academic stress shall be documented. A report of the
same shall be submitted to the district monitoring committee headed by the
respective Deputy Commissioner and the concerned regulatory bodies on an
annual basis.

5. All Educational Institutions, more particularly the coaching institutes/centres,
shall, as far as possible, refrain from engaging in batch/class/section
segregation based on academic performance, public shaming, or assignment of
academic targets disproportionate to students’ capacities. These Institutions
shall ensure that the academic burden on students will not be overwhelming.

6. All Educational Institutions shall establish written protocols for immediate
referral to mental health services, local hospitals, and suicide prevention
helplines. The written protocols refer to Standard Operating Procedures (SOPs)
for supporting students in high distress and management of instances involving
suicidal crisis. It is encouraged that all heads of institutes undergo brief
orientation session on formation of student wellbeing team, development of

2

<!-- page 3 -->

SOPs/written protocols for crisis management and basics of implementing
student mental health initiatives in their respective campuses.

7. Suicide Helpline numbers, including Tele-MANAS and other national services,
shall be prominently displayed in hostels, classrooms, common areas, corridors
and on websites in large and legible print. A few such contact numbers and
services have been given in Annexure-I.

8. Educational Institutions shall ensure that their teachers are oriented and
sensitized about the basics of student mental health and faculty shall address
the mental health concerns of students in distress.

All teaching and non-teaching staff shall undergo mandatory orientation session at
least twice a year, conducted by certified mental health professionals, on psychological
first-aid, identification of warning signs, response to self-harm, suicide-risk management
and referral mechanisms. The training providers could be qualified psychiatric doctors and
other competent mental health professionals of | Government/Private
Hospitals/Organizations. A standard model developed by NIMHANS can be adapted. An
outline of such an orientation session developed by NIMHANS is annexed for reference
(Annexure-Il)

Additionally, all educational institutions shall ensure that a minimum of 2-3 teachers
mandatorily undergo standardised detailed training that equips them to support mental
health promotion activities, interact with students in distress, assess level of distress or
suicidal risk, offer basic support and to know when to refer them to a counsellor or mental
health professional. Details of a standardized training model for this purpose derived from
ICMR implementation project being conducted by NIMHANS -Karnataka site will be
communicated separately.

9. All Educational Institutions shall ensure that all teaching, non-teaching, and
administrative staff are adequately trained to engage with students from
vulnerable and marginalized backgrounds in a sensitive, inclusive, and non-
discriminatory manner. This shall include, but not be limited to, students
belonging to Scheduled Castes (SC), Scheduled Tribes (ST), Other Backward
Classes (OBC), Economically Weaker Sections (EWS), LGBTQ+ communities,
students with disabilities, those in out-of-home care, and students affected by
bereavement, trauma, or prior suicide attempts, or intersecting form of
marginalisation.

10. All Educational Institutions shall establish robust, confidential, and accessible
mechanisms for the reporting, redressal, and prevention of incidents involving
sexual assault, harassment, ragging, and bullying on the basis of caste, class,
gender, sexual orientation, disability, religion, or ethnicity.

i. In alignment with regulatory requirements and institutional values, all
institutes shall ensure that necessary structures and functional mechanisms
are in place and made known to students, for prevention and redressal of
incidents such as ragging, discrimination and harassment (e.g. anti ragging
cell, internal complaints committee for prevention, prohibition and
redressal of sexual harassment of women, student grievance redressal
committee). Respective committees or a designated authority shall be
empowered to take immediate action on complaints and provide psycho-
social support to victims.

3

<!-- page 4 -->

ii. Institutions shall also maintain zero tolerance for retaliatory actions against
complainants or whistle-blowers. In all such cases, immediate referral to
trained mental health professionals must be ensured, and the student's
safety, physical and psychological, shall be prioritized. Failure to take timely
or adequate action in such cases, especially where such neglect contributes
to a student's self-harm or suicide, shall be treated as institutional
culpability, making the administration liable to regulatory and legal
consequences.

11. Every Educational Institution shall constitute a Student Wellbeing Team (SWT)
comprising of representatives from counsellors, trained faculty, students and
parents. This Team shall create awareness about maintaining mental health,
mechanisms like complaint box, grievance redressal committee, anti-ragging
committee and internal complaint committee/POSH Committee etc already in
place in the Institution to deal with concerns of students and assist in processing
emotional problems faced by students. This committee shall also take
appropriate measures to publicize metal health safeguard measures through
brochures, handbooks, prospectus brought out by the Institution and Induction
Program.

12. All Educational Institutions shall maintain anonymized records and prepare an
annual report indicating the number of wellness interventions, student referrals,
training sessions, and mental health-related activities. This report shall be
submitted annually through the District Monitoring Committees to the
respective regulatory bodies. Template for such reporting is enclosed herewith
as Annexure Ill.

13. All Educational Institutions shall prioritize extracurricular activities, including
sports, arts, and personality development initiatives. The period earmarked for
Physical Education plays a vital role in stress management and shall be utilized
exclusively for this purpose, and not be diverted for academic engagements.

14. All Educational Institutions, including coaching centres and training institutes,
shall provide regular, structured career counselling services for students and
their parents or guardians. These sessions shall be conducted by qualified
counsellors/subject experts/other competent people and shall aim to reduce
unrealistic academic pressure, promote awareness of diverse academic and
professional pathways, and assist students in making informed and interest-
based career decisions. Institutions shall ensure that such counselling is
inclusive, sensitive to socio economic and psychological contexts, and does not
reinforce narrow definitions of merit or success. Resource persons for career
counselling at block levels when appointed under Samagra Shiksha or trained
Block Resource Persons (BRP) may be actively utilized by Government schools
and PU colleges for career counselling support for students. The services of
Placement Cells shall be availed in Higher Education Institutions for career
counselling.

15. All residential-based Educational Institutions, including hostel owners, wardens
and caretakers, shall take proactive steps to ensure that campuses remain free
from harassment, bullying, drugs, and other harmful substances, thereby
ensuring a safe and healthy living and learning environment for all students.

4

<!-- page 5 -->

16. All Educational Institutions, including residential-based Educational Institutions,
shall adopt appropriate safety mechanisms such as installation of tamper-proof
ceiling fans and other equivalent safety devices, curtailment of access to unsafe
materials and high-risk areas like rooftops, balconies, etc. in order to deter
impulsive acts of self-harm.

17. \n cities where students migrate in large numbers for competitive examination
preparation, heightened mental health protections and preventive measures
shall be implemented by coaching centres.

; (M. DAYANANDA) @* We
Deputy Secretary to Government,
Higher Education Department
(Collegiate Education)
To,

1. Additional Chief Secretary to Government, Home Department, Vidhana
Soudha, Bengaluru

2. Principal Secretary to Government, Department of School Education,
M.S.Building, Bengaluru.

3. Principal Secretary to Government, Medical Education Department,
M.S.Building, Bengaluru

4. Principal Secretary to Government, Department of Law, Justice and Human
Rights, Vidhana Soudha, Bengaluru

5. Principal Secretary to Government, Health and Family Welfare Department,
Vikasa Soudha, Bengaluru

6. Principal Secretary to Government, Department of Youth Empowerment and
Sports, M.S.Building, Bengaluru

7. Principal Secretary to Government, Agriculture Department, M.S.Building,
Bengaluru

8. Secretary to Government, Department of Skill Development, Entrepreneurship
and Livelihoods, M.S.Building, Bengaluru

9. Secretary to Government, Social Welfare Department, Vikasa Soudha,
Bengaluru

10. Secretary to Government, Parliamentary Affairs and Legislation Department.
Vidhanasoudha, Bengaluru

11. Secretary to Government, Backward Classes and Welfare Department, Vikasa
Soudha, Bengaluru

12. Secretary to Government, Minority Welfare, Huzz, Augaf Department, Vikasa
Soudha, Bengaluru

13. Secretary to Government, Department of Women and Child Development and
Empowerment of Persons with Disabilities and Senior Citizens, M.S.Building,
Bengaluru

14. Secretary to Government, Horticulture Department, M.S.Building, Bengaluru

15. Secretary to Government, Department of Animal Husbandry and Fisheries,
Vikasa Soudha, Bengaluru

16. Commissioner, Department of Collegiate and Technical Education, Bengaluru

17. Director, Department of Collegiate Education, Bengaluru

5

<!-- page 6 -->

18. Director, Department of Technical Education, Bengaluru

19. Director of Public Instruction, Secondary Education, Bengaluru

20. Director of Public Instruction, Primary Education, Bengaluru

21. Director, Department of State Educational Research and Training, Bengaluru

22. Director, Directorate of Child Protection, Bengaluru

23. Joint Director, Mental Health Department of Health and Family Welfare.
Bengaluru

24. Deputy Secretary to Government, Higher Education Department (Universities)
and (Technical Education), M.S. Building. Bengaluru

25. Director of NIMHANS, Bengaluru

26. Registrars of all Public Universities.

27. Registrars of all Private and Deemed / Deemed to be Universities.

28. Principal, B.M.S. Engineering College. Bengaluru

29. Principal, P.E.S College. Bengaluru

30. Registrar, Christ University, Bengaluru

Copy To:

1. PS to Secretary to Government, Department of Higher Education.

2. Section Guard File/Additional copy.

6

<!-- page 7 -->

ANNEXURE-I
Student-Support Resources
ಕ ನ ಗಾವ
Response System
Health 891-4416
Health students
Protection {Women Helpline [181 Immediate emergency 24/7
response and crisis
intervention for Women
Commission for lcomplaint tracking for Women
|\Women Helpline
Protection {National Anti-}1800-180- |Report ragging/harassment 24/7
meee ತ್ಸ ತ
Protection |National Cyber|155260/1930 |Online abuse, fraud, 24/7
Crime Reporting harassment
Helpline
Legal/Rights|National 16101೧6 10114566 Report caste-based 24/7
Prevention of discrimination or violence
Atrocities — Against}
ISC/ST Communities
Legal/Rights|National —Disability/14456 Support for persons with Mon-Sat,
Information Helpline} disabilities 9 AM-5:30
Service PM
lLegal/Rights|National Legal Aidj15100 Free legal help for vulnerable |Mon-Fri,
Helpline 0೦೬05 9:30 AM
5:00 PM
Protection |Child Helpline 1098 (Crucial link between children inj24/7
distress conditions and service:
lavailable for thei
rehabilitation& restoration
7

<!-- page 8 -->

ANNEXURE II
A TENTATIVE OUTLINE OF ORIENTATION SESSION FOR TEACHERS
i) Understanding student mental health and wellbeing and associated outcomes.
ii) Myths and facts related to mental health and wellbeing.
iii) Promoting skills and practices for mental wellbeing.
iv) Understanding the self-help, informal help and professional help.
v) Recognizing signs of distress in students.
vi) Identifying and responding to suicide risk in students.
vii) Role of teachers in supporting student mental health.
ANNEXURE III
Annual Reporting Template for Educational Institutes (add rows if needed)
From ___ to ___ (yearly) ;
pe tote ae
participants] nature
Training program conducted for teaching
and teaching staff for supporting student
1. mental health and wellbeing, including
suicide prevention
ತ le ಸ ಇಂ
25 5
mental health promotion
ea 227 ಡಾ ಇಷ
`` [೦1081266
Educative materials and basic information|
4 {or when to seek professional
help/where/how-displayed ೦0]
website/notice boards
[5 [Workshops on mental heath forstadents | |_| | |_|
‘ounselling services- in campus
(Mention total number of in campus counsellors)
Fe eee LT
(students) with- in campus counselling service
Online counselling services if any facilitated by the institute through external service
provider (Mention name of external services provider and total number of sessions)
Referrals made to external mental health services (e.g. hospitals, clinics etc) | |
(Mention total number of external referrals given)
Any incidence of death by suicide of any
enrolled student
10 |Please mention details: course/gender /
social group/mode of suicide/ date of
Ideath/ action taken (in brief)
[Any new initiative for student mental
lhealth/any other remarks/challenges
11 lencountered and solutions attempted/
Feedback (not more than 250 words)
8
