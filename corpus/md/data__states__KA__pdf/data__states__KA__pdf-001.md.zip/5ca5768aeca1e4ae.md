---
doc_id: "5ca5768aeca1e4ae"
source_url: "https://www.mcehassan.ac.in/secure-file/latest-news?path=Instructions_to_Graduands-1.pdf"
ministry: "Malnad College of Engineering, Hassan, Karnataka"
title: "Instructions_to_Graduands-1"
date: ""
pages: 1
method: "tesseract:kan+eng"
script: "LATIN"
needs_ocr: false
sha1: "fca351ee3bf44aa2"
---

<!-- page 1 -->

RES MALNAD COLLEGE OF ENGINEERING, HASSAN Zz »&
5) 16" GRADUATION DAY CEREMONY - 31-10-2026 ¥ ಈ ಇ

ಇತ್ರ GENERAL INSTRUCTIONS TO GRADUANDS 2026 my ಕ
ಕ್ರ ಟ್ರ ಟ್‌
WZ

Reporting Time: 9.00 AM Venue: In Respective Departments

Registration : 9.00 AM -11.00 AM
1. | Dress code:

Girls : Sari with gown

Boys : Formals with gown

Note: Gowns will be provided during registration with a caution deposit of Rs.500/- (cash only) and

will be refunded after returning the gowns at the end of the ceremony.

Students not following the dress code will not be allowed to enter the Convocation Hall

2. | IDENTITY Proof
Students are required to carry the college ID card when coming to the campus.
3. | ON ARRIVAL AT CAMPUS

“Please ensure timely check-in at 9.00 AM.

“Please report to your respective department counters. All Counters will close at 12.00 Noon sharp.

“Note the seat number on the notice board near the venue and enter the convocation hall. Entry to the

convocation hall will not be permitted after 2.00 PM. Seat numbers will also be shared by respective
HODs in students Whatsapp group.
“ Occupy the designated seats as per the allotted SEAT NUMBER.
* Parents/guests should occupy seats which are designated for them in the venue.
4, | DURING THE CEREMONY

+ Silence must be maintained throughout the ceremony.

*» Please remain seated unless instructed otherwise.

“* Upon arrival of the procession at the venue, please stand-up and remain standing till the Chief Guest and
other dignitaries are seated.

“* During Certificate distribution, Graduates will be directed to proceed to the stage based on their assigned
Number.

“ Photography is strictly prohibited during the Ceremony.

*’ Official photographers will take the photographs of all the graduates receiving the certificate and the
same will be made available later. After receiving the certificate, please follow your row of fellow
graduates and return to your previously designated seat.

“* Use of mobile phone is strictly prohibited during the ceremonial program. All the students and
guests should keep their mobile phones switched-off till the end of the ceremony.

All the graduates and guests are cordially invited to join for lunch from 12.00 Noon to 1.30 PM. |
kos a ಗ a { a
& ಗಸ್‌ i
(Dr. Pr. a A A) (Dr. Nanditha.B'R) (Dr. Ptadeep S)
Dean Exams Dean Academics Principal
MCE, Hassan MCE, Hassan MCE, Hassan
GRADUATION IS A SOLEMN EVENT
