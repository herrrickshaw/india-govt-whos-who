---
doc_id: "c95eaf8f3a88cfe3"
source_url: "https://dwdsc.karnataka.gov.in/uploads/Notification%20Knannada%20%282%29_1772705929.pdf"
ministry: "Empowerment of Differently Abled and Senior Citizens Department, Karnataka"
title: "4     8 months ago      ರಾಜ್ಯ ಅಂಗವಿಕಲ ವ್ಯಕ್ತಿಗಳ ಆಯುಕ್ತರ ಹುದ್ದೆಯ ನೇಮಕಾತಿಗೆ ಅರ್ಹ ಅಭ್ಯರ್ಥಿಗಳಿಂದ ಅರ್ಜಿಗಳನ್ನು ಆಹ್ವಾನಿಸಲಾಗಿದೆ."
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "550f42178a3d9511"
---

<!-- page 1 -->

d&eo d)gl d)d.t/ ar?pddb*uorLo C+o?rcgdd d)gJ- &Oo$ ilortbdd darOeddec
leered. ldt d)da. 3d( de6t. a)drd)dadt/ d6]dd. dorle/66-s6ooo1.
dJd63t€
nozos erorl0*e dstrh/ erobdd dld-odl dcilrogrl erdr elqisQrrl9od erEr

eroo".0derohd.
ercdrS:- uoau5 uoJ::d-d d:d.od: d(d)6ognon djqo$J d dddod e,dFdo$dra

doobddtd.l.
er) adia)d.don daderod nod.o"$ ol9oo,3oo5Joo$bod ddao$dJd ddad34dJ".

er) idroai i(d/ rododr/ JdFdtrd/ drodddai/ d)ddFd.a/ adoaJ(3dd b{eo
Co-osdrdo$O- ddJ er$ao adAtdrd ddbd3d,dr..

iroFdd 'o' ddodd erQEoooiroR dJd. 15 ddFrl9 d(do$dJ.L
dojdrddJ d)df eddd- dJdn 2 ddrd erd6d aldod(ddd dero5ea a-orio
ell)croacs

$ddrig oi.o(a3do$a d(do$dJn io-Rld:d e,drqjddc* dooaddd"d:";
erCilo

d) dde.:aJtSdd d-e31d cgnrlddr" Jdrbn$-d:d d(odlluoais/d6oFd/iEoFo/

x-oaJracJd de:od:d vubsdr/ erd i6oFo/ m-d€. dod"rl9od dtodsd doobdrd
dotocrocfuird od&.,,(o$ d)g) coddqo&.r(o$ d)tl"]d ioo$o i(do dod.rl9o-d vudrd
d€l.rd doddJo"o d5{rlgc cdoa*(3dd d)ddFd3 d-(3rdo- dJd., ls ddrrlg deao

erdc$dddr" dooAd34dJ".

dcgd ,J(€i:d.o,1,M,2oo-2,18,200+37o ao&Fd d(3t a)@. erddo Eerosto rood:rdarri9d
iuord JilQdaArdrd e3d qJdsrldl
dooooolod ercz, &J:do3 dr.oe)d erztr do-do.> d.odo$ biloo+:04.04.2o26 fiod'
s.00 rlo63o$ddrl.

erzlr de)"F.ld JcDd:

irordd roodrrdbr, d:bq/o ild) ddlg er0dcb.6-drt-6 c,lde)zjeddd d3l bood)

uorlodd ia)o(ddsa €etod, 1d( d)da. 3dt dt{,v. a)dJd)dadd deld. dorl9JodJ-s60001.

e:EF ddl/od 6-ort/o "aJoddt da$.,d drobgrlsdJn dzydo6rr JsroB:
https://dwdsc.karnataka.gov.in bod dddrd.od.dddr.

(d)doecdo)f.deF C6
idds rood:rdbr,

ooac5 eeoriddo d,q,ri+ dAidd eeQJo$d>

eroJNed d(d)GDg ic,l:3 a-orto

iaordd erud rdo$FdaF- 2,
drSosro il31 ild"9 e:Qdofu a-orfo
Jde)a+c3dd d)d) Sooo$ uorlodd
iz,>O(ddeo qetoaJ,

<!-- page 2 -->

,#
doorud iard
8dS erotDdd d)

eorlAde

dno ie,3erod ep*r dd:od

I

e) doror did:

"eea!d r
a'ox.doet

(d* sddfi#O):
er) dodoJo dFd

c9{dod: io$o
ddQeddg qDddg

soocco$ did::

")
*) Oorl:
cc) oD"beo$d
ero) {d:r:

'N) zEog/srud zvoS/ddF:
D) adodegddr:
(adeziedddod deJdd8eo$ e,Qrodaod odFoneDd ddrleri EeroajoCood
ArtQdaierod .lde)zJr gd rbdr.gd d [.3o$ d]a&8o$Sr ert.5od6.)
€

a) drod irod:
(tDdodO fedcoood odrQ d.noad dDb.go$&a erl.giDdd.)

6c) iod6Fiard)oDd

aoid a1oror .)s'oi:

e-l (td drad6"d iosl6/
doe3el(f ioel6/

"-d)ee,

Arr?i)

2. a&tld oeod:
3. oaoodrd:

do$4,

-/-/

D) a6?6dFd aj:d: qdd erdrdrlst: (ddQeddd eod*€ ab$ Eidaeo dgd d.9
ode$dd))

E) io8roedo-o sd ejeaDdfi* ddlJd (nog{ oddrls$4 0l-02 dDr^} areddod

ddlJaofDd.b)
4. oFbCdd !dddC::
drje0/

!oio$
add
."\ r
e ioSE

d)do6 dcdi

4tt6/ i*d idrl)

Jcdd

S(&ro3 EdrrE

ggl w.Q

radodd/

aeq.tFtl
nolacz3d/
dldsoeaoE

..2

<!-- page 3 -->

2

s. {pC ddrdb OdF&lDgdrd drd,i iozJoQrdod darAdo dDEo.9. (ioid addd$${ 0l
sB sreddod nd}oorn{cjJ )

o) EeoQ, id-oFd/oosi. i6DFo:
u) rrodrd rd- io&oeQ-. ,c{nvr:
sdr ooodeo$/eo$g lod edm d-odo-oged nod:
") (s-o$ ded dnecmc.::3 lo{c,,nn{9 edd 6Dc$F-D*r/ roo$r{e$d.1)",
ddr.jaoi.Dd$.)

6. n*" oqQrgt* ioa.ro$Eqod detdo do6..e sdg d*Joa$C)&.
7. 0*" o66QFdotd noeJoCA$og edroilooo,l ngne,|Dd dD6o.)/
odrorordondg dEdo ds8o.)lToR lodEFiDd)oDd e?& *rl$
&adaoed noa3roJ:$u d*uo aird cb.
3

doe)cro.gd+J

did), aqan,

&soi

I

2

c

€{ eidroJoef, 0ead da&.gil*o Oa drdl nddend aod) 6r d},oet
qidoraeEoloded E$6 o$odde dogdq
eigd Dod) tod) Dodg cddo
"d
DiilDodd$.${ drr€der: wdeddrodrdaon dodr Eio$.gr,ded ooar dodr Dodq ddd
e4ldQrgdd$i glro o@doneJd)doRd a$d: nodo$ XedoSfldQ ido iedcr)od
ddla$4 d?srtragierd)doRd ood d.rae&r,

i& 6-dderoRd.

l.JN9U9.

c

eqtQ.o$ i&
