---
doc_id: "bedf0aada5e247b1"
source_url: "https://dpal.karnataka.gov.in/storage/pdf-files/acts%20alpha%20and%20dept%20wise%20acts/14%20of%201990%2081.pdf"
ministry: "Home Department, Karnataka"
title: "The Karnataka State Police (Disciplinary proceedings) (Amendment)Rules, 2015."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "42b71867259da67c"
---

<!-- page 1 -->

HOME SECRETARIAT
NOTIFICATION
NO. : HD 38 PoSiLE 2014 Bengaluru, DATED: 15.04.2015
Whereas the draft of the Karnataka State Police (DisciplinaryProceedings) (Amendment) Rules, 2014, was published as required by clause
(a) of Sub-Section (2) of Section 3 of the Karnataka State Civil Services Act,
1978, (Karnataka Act 14 of 1990), in Notification No. HD 38 PoSiLi 2014,
Bangalore, dated: 28.08.2014 in Part IV-A of the Karnataka Gazette
(Extraordinary) dated: 01.01.2015 inviting objections of suggestions from all
the persons likely to be affected thereby within fifteen days from the date of
its publication in the Official Gazette.
Whereas, the said Gazette was made available to the public on
01.01.2015;
And whereas objections and suggestions were not received from any
public;
Now, therefore, in exercise of the powers conferred by sub-section (1) of
Section 3 read with section 8 of the Karnataka State Civil Services Act, 1978
(Karnataka Act No. 14 of 1990), the Government of Karnataka, hereby makes
the following rules, namely;RULES
1. Title and commencement:- (1) These rules may be called the
Karnataka State Police (Disciplinary Proceedings) (Amendment) Rules, 2015
(2) They shall come into force from the date of their publication in the
Official Gazette.
2. Amendment of rule 6:- In the Karnataka State Police (Disciplinary
Proceedings) Rules, 1965, in rule 6, in sub-rule (5)
(i) after the words "the Assistance of any other police officer', the words
"or a retired Ministerial Staf of Police departrment shall be inserted;
(ii) in the proviso, after the words "the retired police officer", the words "or
a retired Ministerial Staff of Police Department" shall be inserted.
By Order and in the name of the Governor of Karnataka
Devendrappa Kattimani
Under Secretary to Government
Home Department (Police Services-B)
