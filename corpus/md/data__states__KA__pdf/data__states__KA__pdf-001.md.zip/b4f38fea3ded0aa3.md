---
doc_id: "b4f38fea3ded0aa3"
source_url: "https://dom.karnataka.gov.in/uploads/bell%20notification%202025_1762521583.pdf"
ministry: "Directorates of Minorities, Karnataka"
title: "37       4 months ago       2025-26ನೇ ಸಾಲಿನ ಪರೀಕ್ಷೆಯ ಬೆಲ್ ಅಧಿಸೂಚನೆ"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f42a5ce0125d0be4"
---

<!-- page 1 -->

&deruso ode9

aooapel:o8o-aaeeaara

I

4B* 080-44863618.

@o.eo 80Q5o o Ede r o au-ooo:)

6mr86 S6dt-O

dodd:sdo&/(,/4. d. d.dra. d/,rrscF-os/2025-26

Emaitdirectorsokdo nr(osmail,com
Web: www.dom. karnata ka.sov.in
oo ro,r.,, tulaq rg5oaf dd o{,
aasoo aJoo. dooetoo-> seoose.

6oaod: .1o-2o25

ddOrt.

oW ?sgo$ eee4 erQaoor'idc.
eog doar-o5dd delo5m eeroa3.

&do$: 2o25-26de uourl eogJoaro6dd odee duooo$d doos;od ddd:d
oiD..:r.o>86.,$ uori0ed ded. d.o.orc6 rSdrJr d3a3eddo6 drdJ rtea"-,s

d0eag dvodr ddaie.s ddC.Dd dro*.
* )*,* *)t

d.:ee3od adon{ doa:o6,$dod. olD.cr.")d.& uoriBed ded. d.o.ooe r3dr3r
dga3eddo6 $dJ rt3€6-,$ dOeq dnde dda3eo aeder: eru{e6deond.

esddod. ogJoao-o6dd dero6o eeraaSoS: d€osrod *rrorlde deua &od.>
droea;eefdg erd6 e36a€ drroe)d esar ee63&detdnd;. dqd Soa36ono eseesriCJ
,$edrda-onQ. dd0 erde erqj5Orriddbd o$J..b.":-6.,$ dari0ed Jed. d.":.oa6 r3drJd
dga3eddd d:dl rt8*6-,$ d0ec3 dnde dda3eorl eroQ drodo: aq1 deolrlCg
oad:od6 {ded doe{ondr" 6uood:oe fl2o25 abQ 6:9.11.2op5 dod> dddor
&dFO&dA, ddo d0eu3 $$o$ongd uodddedd o-orio rPd5dong dadde
ooasosrgdod oa5o$Jd:rdroh aorlo a{{o-oduon ddJeu aep doddg eorld5 drodr

a{doloohrl d6ef,on&. oJodgrtnudu: dnalJeroAd;' dd6 .?ddrJCr *
dCdodood:$d.

doil drorledoallrlC>: -:dOeaa drads
1. d0e6g deo@rlC es$on eee4 erQr-o0rldc. dd:a doddgobe €c(*OroorlCraoari
aJaEr,$ dJaq uo6ri daeraj6. zee* deoSl{ dtued.l$d. ">e* drloe>qiad
dadojcerSCdc" a,CrlJao6&d doer3 deoSddS rb&6,$ drodeJe ade rdoaoon{

dd6ond:d dgJd{Q.(eod:aod-1)dg ase4 deolriC dg e-:rlgad'
2. doe63 deo!{ do{ droeeee&G aisoa d6d$' $Ao$rd ee6d dddd, 63d'r:d
a:sso a-arln edd dae-raJ6dd:" e"dhdo gd:d&dd{Q.
3. ?ee;q eoQaa0r3$ daSojcuon d6e{on 6-oaEdd 6-arl'o rpdddondJa
aouo6d.o{ o: gdr d6odded;.
4. dOeEB deo{rlud:d esg{on ae3 ep6ao0rJdc dd0 ae4 d0erg doedo6

eoQao0ritand:qd.

5. ac* es6ddori$. dd:u doddgobe €atpQu-aorlgoo6rl aiasc's doeug deo{
dn dB d:e g eraddd:. ilra6 erQe! dd:, drorls6c-oorld:' ae{ ddd:" dea:dd{Q'

<!-- page 2 -->

6. d0egoidbd oi$arloedo: d0e{ Jdoia;d 2-s 6driC dr:oa3 d0erg aooie {
&oiraeeedrLoo&d:d "rep ee6-o0/&?oariCJ dJQ doeq deo@d &egas-adddrrid
dsJoiild dd,r, doedrJC$d d€.B&qn 6-oriD eojJdrod)uoduoh ddde) doee
draeJd/ddaje€ eedrd)dr.

7. &deFd6r'oooi6od ?eep *eoQriurl ddcaderorbd doeq riad5d o-od:Qrldd:.
a:es-adoJ:g sjddadod 6-orl'a doeq 6ddod: alerodo$od adodrd
trooisodsadu: doa:ofrdg eoQao0rjerS dnd oderdd aed:dtdc.
s. doed a:doi:d eoqj66erJ$ dqona-on dad6d ed:d oJvado-odd: a"od: rbdr.ad
aleosoJ:d:a epodd. d6aont eldJq/dda6 drae€J6t/ eJooo6 -oa6s/ dd#
roo6s/d.:do-odd rb&gd aers drid:dood: odajedc. EC6€C eoaj5QsriCdc. dOeug
deo{d e"Cri gide6do: eod:d:edd{{g.
o. eoql6Qrri$ doeq deoQd a,Cri ofodde esqiraed "reJBeEo erudddeorldr. draaldef
Soeo6. argeanO6. drodso6. d5t:6dg5or: o6. d6eJro6 def;. areo. a)){/ab{d
rJCdc. d&dddr. adeQ derohd.
eero-cb
'?)oa-o(
ro. ojrodde rrodeod4 dda dgdriddd a,crlood dcrid&d E-Mail, Whatsup,
Telegram, lnstagram dr:osad oadvoegd *adddrrid dme,:d o}oorlo aed;doag.
de a:fl ona$de dlacbd$ dodra:odg Joao6&ddd a3:eel 6Q c-adod: $dr
a&ndcrorbdtd:.
11. doed dJrnobdddrin

a&dorj orbdoeg. *

otrodde aododg doeq deoQld.rad6rJeod ddd dgd

eJd ese4 d,aedef egQroorJd: erld6 $d;da"Cod)dr. d*€g

dd.:adue ded dndrrodaraah draderori:dd:.
12. ese* droedo6 esQao0rld: dOeq doarofr oirodde Oeaoi rVoodo aorlm esaddd

da:dddc ddoi:dod gild&dd*d;.
rG. eeera d-oedo6 es66a0ri$ dOe{ il)nd

dodd en:gd dgdriCdrd ilr*d
e.:EraedoJrg(Sealed cover) dOeug deo@a-od; doerg 6ddod dn{ ajQdoioobri
oderdooe.:o${ a)* de))c.r.E, ,Sedds ddondgd;.

dded
.J.auJC d0ed-zoesd derrado drdr ere:6 ddroirriCdr. * dgri &edemhd.

rfgf-,s d6ero d,oda dddeo d6ef,dC demdg
6uood

6d

do*

4.11.2025

dsarad

o1

dilon
aJsri: 1o.3o Ood
d:Oo6d;tz.eo dddr3

sodddc
100

<!-- page 3 -->

olD.6.or€.,1, uorloed ded, d.o.oac rjdtjd dgaleddd dOeq dodr dddee

doe{rld demdg
6uaod

6d

dod

9.11.2025

?,rad:ilod

ol

9.11.2025

qpd.laad

C\D

d

diloi
a3ud: 1o.3o Ood
d.rOo6d;t2.3o dddri

:2.oo Oo
d:qo6da:3.3o dddri

tsodrJg.)

100
100

o$ der6 d*o$ d.>dJ addr,&

* aJef J*ondd:. otrodde arderodrd drodd egduo dod: a:ddod oa:duoh
eoai.ldOdu: droa3,$d.

dcd-ot
d.

do

eddriCJ

GedO

doa!5

o gided dEdaba *dJ rb&od aseso$dra doeo.$dd drag
€ee,ldoFriurl doedo$ d.,adaoidrd eldea& &rl6d €rJddg

o1

dode->
aruG

e

d.io:oo

dcnd;doder: odrod do Jcrorbd;d:.
o *rad6 a:e.ga:aaduc 6ala aEag*a aDdarEdda drdj
rbdrod ?re€.eoig il)Qddaodrd 4tadasEddJa dOegri
daaoaRd)d (,ddorot do6rl doaeeeiDqd.
o *roda d;egaroddd: (rqjdQtrJcri mqd dgdondJi
adoioqd. eoai6@rrlCc uuQd d$dong daJ:a dneodrJ

d:{ dJd$" a:doJ.:de d.r.
. epddorrid.r uo{ eru$d dgdo$g ad6d;d doeoded
doa36

doaS6oi:d:o {ded d$dg *)Qdildndrd doeode6 doa35d
doBeee,$to{a3ed:.
odcrbeoaohdoJce

")odJ

. d.rorsd dodd eeqldotrl$ doero dradaoiab" ddeSdoc
tod.l-o dOeEp drod6osJod dod d.oeriu.: @dEod.rdJd6g.

. d.to.2o{ ase{6 dd€eaoid6/ddd dgEd dooddJ ,e,eef
droadJd €da dgrd e.:doedrldd;. doda
;Sregaraddd:rlerl esdd:rld dodad docb *Jad:ed.

. d6da ilegerodddJ ,$eef dtaadJd dda dgE-u
odoedoJ:dco egqidogrl€rl dJaeoa & 6eo droeoao
deCajedc. 'gr{ dgrrrcdh &e(, dtaad)d o*roedoJrg
o2

oddde
arer€

ed(,dnd drdr o*eetJob ad6&Oag.' dodd erdoedoj:
dJeeJ 6-oa0$d olrouoddo EB$ eeqldogrisod daoid:"

eJ.1o:15

ddobqd.

o dodd drada dJegeradd$ d.to.25{ odneaSoid:o ddd>
S.odaong&d eoqj5Qrrlur! ddd dgdo$dJ{ drad oeoong

.rdoirBd.

o &.d6.: dda dgEo e-:*oee3oi:d.:a ddo$o; drada
d:egeradddr dn$ o6e-oddab. doo6d:qd.

o d.rradde def errbdddrto erql66rrl$ dda dgdo}ild

.

doeder a$Q eru$Od:dd{ eodu-od dnderorb{r6g.
eoda *egaroddd: esqj6@rrlC J&o$$n ddarde,
doeefdg ddojJJdd.

<!-- page 4 -->

o3

d:.;odde

. esqjdorrldo ddd dgdon s& &qdddra ddd) 6,.oo.erd

aJ.1o:3o

deJ6

dDglode)) tedEad d.oderorbdEr.

uaode

a4

eJe,

d).11:3o

o5

ecdde alo6

dJ.i2:oo

o6

egdde ajo6

d).12:25

adc d.ododoi .idOd aiu6 - doe{oJ: a,od: rloeSo$
€rdQ J::n6$dd6pn.
oajod a3o6- doe{ drnonu: d:odQ
ed:

";dddoi

&.irdrldr aros erus6dJd)ddgn
o qd,: dodoJ: "){ot do! drad6 &egataddd: eoai5orrltrr-r
doed dxnoie! dedeJ €cdJ e.l)dddJ aro6 sDs6d ")odl
gsir:qod.

I

. d0e, dlraot)
. d€ eJer6 erd ddra
eseJ-c6rridc
d.od6 d;eeszsaddd:
{
aJ
o'

6,.oo.ero6. eruQd d$dong wQodo{dd.1 eg,{)68d oodr
arodOd:06*,dCajedc.
l'

tcdde

o7

aarlo

dJ.12:3O

dJado$

o drada d.:eesa5adddJ
@ajcorrieod e,.")o.ejo6. uudd
,JO

d.qdo$dr. ddolodrd.l.
dua*uad:do:
egai"aErtdJ d0e6-a dladaoDod dod
oo
d.oerbdd{ dode)c e"-oo-€ro6 erDgd dgdondra
e9
rrJsod ddoicrafido$e ood.: arodO droaeodaied)

eJero
I

LI

dod-oP

E

de)6

do

doa!6

addrldJ

eedS

I

I

o $ded dgd$d drd: rbdJod a3e$oidJa draeO,e,dd dloE
eoaj6oeritrri doe{on dradaoidJa ddea,r, &ri6d Prdddg
dcnd;d..rad:u-: esdr-od do denrildd:.

o &oda d;egesaddd: $ded d$dgd:d qrddatgdila $-dJ

rbdJ.gd asetsoig drQddon&d ?FdasEdiln doe{ri

o

d.odoJe

dJ. 1:3o

1

eJel6

dO8eodosad.
raauahd>d eod"6Eo3oo6r3
'2)'

o dod6 dregaroddd: erqjdoErisr3 uuqd dgdo$dJd

adoCDed. eeeJdo6rldJ uuqd dgdong ddJd draeodd
doaJ"
or dcd: dddd.:. adoj:aiedc.
o esd.asridc sadr erudd dgdoieg atd6d:d dneodej
doa35o3:d:* $ded d$dg d::Qdaand:d doeode6 doa35r3
erd)rbeodondoiJe .rodr doaeee&d.o{a3ed;.

a

d:. r:45 esd dodd elqld0tri$ dOee drad6oi$a
$deEder: esda;a doeaa d.nd6os:od dod d-oerlo:
eedEod.idJdAg.

dr. r:ao{ ate66 dd8eaon 6/Eidd dg-o FaerddJ ,$eel6

droAdod dda d96o

odnee.3rlddl

drada

d:e garoddd;rtu 11 eldd:rjd d.nd6ri dodl dladJed.

a2

oddde

dc. t:+5

der6

. doda &egerodddr ,$eu6 droadrd dda dg6-o
odJaelioidra Qrsjdotriur3 drae6,$ * 0e€ drdectoR

deCajedc. 'dda dgdrlCil{ ,t€uc dtoA$d e)tB€doj)g
ede,and q o*aeiJoJD a,d6$dag.' dodd od-oeejoj.r
d)eeJ 6-oaodd olroooddo e?$ eesjdOtdeod daoJ:dcn

ddo3r:qd.
l

<!-- page 5 -->

o dodd drdda dregetadddJ d). 1,5o€ e-:*oeu3oJ;d1 ddd:
dodaojrgd:d erqldoErlEri dda dgdon$d draq oeoo$g
adodoed.
o a.d-o.: dda d96o e)dnetJoj:d1 ddoie! dtoda
abe garadddr dro$ eoOu-oddd;. dJooadred.

o airodde aJer6 eerbdddrto eeddoFrJdJ dd{ dgdondJ{
I

I

.

I

doeder: d;Q eruQOS;{d{ eode-ad *oderarb{69.
droda d.:egeraddd.; o4J5Qrrld d&oidJa daaJde,
droeu6dg ddobdd.l.

o3

dr;adde
aJ(.]6

@qldotrJdJ dda dgdondJa dddJ en)qioJer) erdfod
draderorbdld.
de, - doe{on t,dr rJo.JojJ
ed; dododolc

d)- P:oo

uoode

o4

arer6

d). 2:3o

o5

aDdde ejel6

dJ- 2:4o

60rtja
drodoiJ

ed: adddoi o{Od e3o6- doed dlno$er: €DdJ
eaJdridJ eras uDsodJdddgn.

. doe* dlrrool)
. d€ arer6 eod d{o drdda d)egetaddd.: eoaj5oe ridc erugid
dgdong eoQoCo{dd:" sg,r,6Bd dodJ

eJdde

o6

")dOd

esdo d)n6cbdden.

oadodro6do{a3ed:.

d).2:45

. ajoda d:egeradddr eoaj6orrieod eruqd dgdondrd
ddobddJ.
dr:a:5aoricb: eiqldoEridr doedB dradao$od drad
d,oert$d{ doder: eruqd dgdondJ{ eoai5@rduod
ddoierndo$e oocb arod0 dvo&dodaJed.:.

der6

tt

ojo ao6d 6d

d
o

dOe{ond;. dddor oe4 af;driead erdd d5dd, d-ooded doa35r'ldd:" deaerG/dq
d:eeJ ddra6der. dOe$ri dooo6& erJd d{ond:" d0ea3 6ddod: $dmder:
rortn d.oedd dodrldild dr:ar6 qddg oel5,@er'l o* -dtu)dod $d[gdor lcddtd)

draa*ogdtd;.
doedo *radA/6-oe, &sae)dande9 gp 24 teddotr rd s,oddod ef

draA $-d6edaan

d.od6 dregeoddd&{ de&ddt*.

dldl erdd
-:erdd
eoqj6@rrl$ dd{d ddo: dndo.) eedEo, eedadol $.9 eoaj66r ildd de* 2
ar.are. reodd ed:dod esdd d6d{o$dr" drada3eocbqd. drod6on eodd drQ
are&oedddeorJd oaj6dri odcrbeouo6 aduodrd d,:aedn{o: ?se6o
do
oIJa 6,.oo.cro6 erDdd
es&d)e oeduahd.
dd.oe6oia6dd6ri
tl
d
&od dDod dreod)d
6?drld drroe)d sDdodod
rrr3 arode

e16ol:

d&drl$ d.odd:dod doe6d drod€rodd)

<!-- page 6 -->

d
d
6,.")o.erd uDdd 6-odrid drDod sDdoCDd
reddogr,$ dd$d ddo dvoder: odradagdod $o ed6Qe d)dd ded 2 aJ a)e. Geodd
Edrdod Grdd ddd*o$dod * *ddod d:odoo$g dDddE*.

l{E$f,o+
1

7

2

a

I
4
5
6

to
lt
12

ddEd6rlCo Edg
drada doald-l
AC 13 19 AC

BD
CA
DB
AC
BD

20

14
15

17

22
23

€

24

16

BD
CA
DB
AC
BD

d
6,.")o.(,d erudd a-oCrJC dtraod EudOCod
doatd drodde$.
d) od
srirr13
ri a,ode ee6ojo
&od dDod drucd:d
dossdoirorJdod .raJod d6odddd.

edo

edeg

*rlC)

EI}P^

a

ra

ilo.i)de, dDee, Attendance or droA d$aCod al
ederddde:oid d0eq *eo{{ doasd dto6d o{5@rrid dd6, doeodd Jod5'
q{riCd:" a,drkood ddardr, doeerrlCdrd aed:dtd). glo &a:dg e esS56erlC
drd&o il)Oddan*,dc *adAr! 24 eed6@rd$ ad:dod sorladdl*.

$€ e"od: dradaon d;egesaddd: esdd Aodeoi aa)del6 &oeo6dg ee&drd

dros"e drdl eoqj6Qr a-oad:da&d $ded d$dgd droaoeojrdJd ood dro6 dodd
oqj5QrrJCdJ. esdd doeodeS doa36 $aod erJao3tod {CdgoSce d:edod,ndgdod
-dtaead,n$o{Q.
a

d.DdA

esodd

arodddo

ddod

raecuo0d)d

dr:od a-oalsoo eeododg 'PP" ")od) &eo 5oo$o$ do*aod dBoi oh
ddm6daledo a-orln

a-aaoad

aah ddmaddedr. dodA

d
ojcuoo dd

uod
aJ0

gr1 d,oda

eddd

ddod dlod"AA- ood: dod: sooooJ:
eroddd.:

6-0aJudo

eruoerorialdoood

dDd

eAo$d dd

rlC)

. dlal?S eo6e{do-on ded:drlnodd& doe{on dr:uon6dde doa:oddrd doq deo!{
eJeog ae6 dOe{ dddo eorid5 d5d{rldd:. dgadrd a:( areed dA&d,;aqddo
a-orto do6dd dod: a:odg dOeGB draedef eo6aooo3:dd ridld{ dd.ldd; rario
ddo doe{o3cdrd eoidraabuad ofadde eod ddriegde ddt'odd: drar6
esQe{dd aaoa30ofond:Qd.

o d0edoi: &o6d 6d dregeoddd dq, dddc dOef,on *0* d-cq dddes eeddd)
r gl . dgd drd; 6,aocrd ou$d aa€rlC ooderrlddh dSldoa:od aouadrdrdr.

<!-- page 7 -->

uaorlC
a

Er.)

eBed esarbd eeadaoridJ doa:odde.: doeuS deoQdg doeug 6ddod; doe{
dilon{ r rior,JoJc d)oesddon 6-derOq doe{ong oiradde Oeaoj: dder:' d0eeg
eo$dc ddoidod dr:rid:uoh doe{ ddone.:r draq gdr d6"dodd.

aeddd ddsd6ddr
o

doeq 6ddod: doetg dods ,$dddd&d $d:aon dtoAcbdd oodr
dO6eegt':dd:.

a

a

ddd dgd/d"doeso6 eruQd a-oCrid a:oder6 ddoir:aorJ daSo$a-on a-oalod;'
aderduoooi{ dda eedd&.
d0e$ono drhd dodd d"ooerd eruQd a-aCriC o-o6aorf dradJd aooJcrdd:.
dogojoaaR aegdd{d; d:Q aderduooon{ dda aed:dd:.
aroddd dJaaidrlg)
drodA

dOe{o3r: dddeddan ddoi:dg d,rodA a3;egeroddd oa$ erse
eod6dd5duoRd:$d. er{ood ddodd& edtdodaJes&d ddrd6rid d€on&a dddJ
a3uouh .9ud.:do{a3ed: a-orin a3o6 ao0dod dabondila erd:d0dd{d;. a-ario
droda d:ege.roddd ddrd6rlCc de dddodQd.

r. d0e{oJ: 6oo6d 6d esep dnedoo eoQro0 a-orlo aseao dd4eAoJ:ilo ddtbd
ddaiee dqirl dagoiaon aaaoadd{d;.

2. doe* ddobd 6d a3uf, oa:3o riodrJ doeq deo@dg 6-oa0de' atea6
dd4eaono.ddOri dda draadJa{d{d;. ddd d&d vu$d abQdld".oo.ero6 wQd
a-oCrld od.ned, iloerdero d.neef d:Q esd0rl doad drodood eoaj66e rid erdd
ddddon dgon$d dr:a:5 eoQe{dd; (asea€ dd4e6onoe)ddOod ddd: d0eq
dradarl ddddgd;.
G. dJoda d:egz.nddd: droaider6 dneo6, 6diC$d a-orlJo eoo66rlCd:* ofodde
rodm*4 doeq dradari drSd:*nod: droerjandd:.
+. dndode rjoei e.roo.e,d d{to oaj6@eddr doeuS d.radaoi&d gide9fodd.:
eqj5@rri$ esdOrl edbolrod dddC d:ueo3dobe ":oaldd:. oard
da"1*ra{dEde.
s. dufl to:ro riodcrJc dodd oori.o d;p6da l:45 rloeSo$ dodd adcd obodde
eoqj6Qrondod dOeq d.od6d.oCri {de3do: esd)dJ€ eed)doag.

6. drada d:egeroddd: doe{ rydoqjilorird tc e&drld drodu eoaJ6Qrrier3
d.."ro.ego6. drd: eru$d a-oCrlCd:u oedaiedc.
7. d,rada d:egaraddd: doe{ a3doajaarbd oc eardrld dndu: $d. dgdon
dJSSonH&d a:fl ddr.od-odg e eoaj66rrid dao drid:d.ood: odroeaios;od {d.
dgdondJd ddond*q d:Q ;sgdoqjilorbd oe eardrid d.odo: $d. dgdriCdrd
eoqj6QrrlurJ adO J aledc.
e. eoqj5@rojr f".oo.ego6 eruQd aodoigdld eoqj66eon doeods6 doa35. Je" d:gdd
$ded d$doo6r1 d06eu,$obe d".oo.erd eru$d aaCo$g *oda dtegerodddr d&

aadd{d;.

<!-- page 8 -->

,

9. tldde aieo6 erdo.l,d dodd eoodd doeao d::r-ooj:g oc o&drldJ erusBdcaad
d.oda d;ege.roddd; eoqj6Qrrhr13 'odr o$drldr dDd rrurr6d' oodJ oaiOd
aedaJed:.

ro. a,d:u eo?.j56rrJ$ doeq dodaoloCri ddeA&d dodd doeq ddon dlndr.
eoqd a-odoj:d;" a"obdJndDdddrira oaj66rridd:" dOeag
d,..>o.erd

dJdl

*rodOolod drod doerler: ee&dadodoag.
11. doeuo dJadon aier6 ard0,$d

d{o dlodA d:egaroddd: oe4 eoaj56rrlC d..")o.erd

d:Q uuQd a-adoid:o aoddoi:dtd:.
12. oe* eoqj6Qrrjuod d,.")o.erd uu$d aaCrld: oo6do$e 6"riro iloa)def draeerodg
6-oaruod oe{ oaj56rrirfu daojod;a d:aadqdoS:e "roar:d;bu oa3ddA'$d,rood
doddde eoaj56rrldd:u dOeq *.odAos:od dod droeriu: eod:d:edd{d3.
1s. dJadA d:egaroddd: d".ao.ero6. ouQd roCridd:a dneoded doa36ojr odluod
droe6,n da.l:der6 &aese d,odr3 so€dla6 6-oaaudd ":e4 eoql56rrJd d".")o.erd.
uuQd a-oCrl$ qd:ddil. ar-ado da.Udraqdcb.
14. ofodde eoqj6Qrofu d".oo-erd. eru$d a-aCriCd:" doeu-o dnd6osJod &odr3

drid:d-ood: dnerldod o{od de"da3ed:.

egdoarqdd &decd doo$,
eJorlCadr.
