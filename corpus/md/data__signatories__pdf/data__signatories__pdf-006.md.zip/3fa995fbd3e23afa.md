---
doc_id: "3fa995fbd3e23afa"
source_url: "https://mines.gov.in/admin/download/6842aa28a92121749199400.pdf"
ministry: "Mines (MoM)"
title: "Invitation of applications for appointment as Young Professionals in Ministry of Mines (2.20 MB)"
date: ""
pages: 8
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "1590949f2bf2ed79"
---

<!-- page 1 -->

No. A -12024/2/2023-ESTT.
Government of India
Ministry of Mines
oR RARE
Shastri Bhawan, New Delhi
Dated: the 06" June, 2025
CIRCULAR
Sub: Invitation of applications for appointment as Young Professionals in
Ministry of Mines.
ORR RR ROK
Ministry of Mines proposes to engage Young Professionals in the Ministry
for attending to specific and time-bound jobs. Only persons with requisite
qualifications and experience as prescribed would be hired as Young
Professionals.
2. Applications from eligible candidates are invited in the enclosed pro-forma
(Annexure-I) along with the copies of certificates of Qualification and Experience.
35 Applications received incomplete or after due date will not be considered.
Only shortlisted candidates will be intimated and called for interview.
4. The Ministry of Mines reserves the right to reject any application without
assigning any reason.
5. The duly filled application form along with relevant documents is to be
submitted in the prescribed format as per Annexure-I via email
(prakash.m69@nic.in and minal.s99@nic.in) on or before 10th July 2025,
followed by submission of hard copies by post to Under Secretary (Establishment),
Ministry of Mines, Room No. 303, ‘D’ Wing, 3rd Floor, Shastri Bhawan, New Delhi
- 110001.
ont ve >>
Encl : As above "nate \
(Prakash S. Mundharikar)
Under Secretary to the Government of India
Tel. No. 011-23383946
Email- prakash.m69@nic.in
To
1. All Ministries/Departments of the Government of India.
2. NIC Cell (for publishing on Ministry’s official website).

<!-- page 2 -->

<!-- page 3 -->

Terms of Reference
Oe ै]२ ||»  झऑफ
4 0ण्थॉट्यांणा5. एिछ्शातबो Qualifications: Master's degree in|

Mining/Geology/Economics/Finance/Commerce /Engineering (Electronic &
lcommunications/CS/IT) /Metallurgy/ Mining Processing (as per
requisition)/ MCA /MBA/CA, or ICWA.
Desirable Qualifications: Specialized knowledge in Cyber Security,
‘Artificial Intelligence/ Quantum computing/Internet of Things/Web|
designing/SEO/ Digital Marketing and managing the web portals / Mass|
Communication (Social Media Expert) any other relevant areas is desirable.
5 |Experience: Experience: 2-3 years post qualification in the field of Critical Mineral
iGreen Energy/International §Cooperation/metallurgy/Mineral Processin:
Background/Management/Data Analysis/ Technology/Finance,
|Geology/Accountancy/Economy/ Project Management or any other relevant
field.
ob Description:!Young professionals are required to provide assistance in policy and othe
related matters to different divisions of the Ministry and updation of website}
lcontent/ monitoring of Online Dashboard. They will be required to provide
. vb high quality inputs in disciplines like Mining/Geology/Finance/Economics|
के a letc. They are required to do Data analysis/analysis of financial statement o
a B ob 12 the companies/ analysis of Metal Sector as well as Financial Marke
(2 Analysis of production data viz. a viz. target/ various laws, duty structure|
affecting sectors/knowledge of Companies Act w.r.t. PSUs/matters related to}
trade agreement/ preparation of presentation/Project]
iManagement/Innovations/Proficient in Computer Applications knowledge}
lof, etc. They shall perform any other work as may be entrusted from time to}
time.
Short-term on contract basis.
Engagement
Period of |The tenure of Young Professionals is initially for one year, extendable up
Contract to 3 years on yearly basis, subject to satisfactory performance. The decision
lof Ministry shall be final in this regard. No right will be accrued in favour
lof the Young professional regarding renewal of contract, absorption in
service, etc.
Remuneration [Consolidated remuneration of Rs. 70,000/- (Rupees Seventy thousand
lonly) per month.
(Other Terms of | (i) The Young Professionals will not be entitled for any separate monthly
Engagement allowances including but not limited to conveyance allowance, House
Rent Allowances etc. However, in case, he/she is required to travel outside
Delhi (NCR) in the context of the work/assignment, the Ministry shall

<!-- page 4 -->

= the actual cost of travel and daily allowance as per the
Rules/regulation of the Central Government applicable to Group B Non-
Gazetted Officer.
(ii) The Young Professionals will not be eligible for any other facilities
such as residential telephone, residential accommodation, CGHS and
Medical reimbursement, personal support staff, transport facilities etc.
(iii) The Young Professionals shall be eligible for 08 days leave in a
calendar year on pro-rata basis. Therefore, the Young professional shall
not draw any remuneration for the absence in case of absence beyond 08
days in a year (calculated on a pro-rata basis). Also un-availed leave in a
year cannot be carried forward to next calendar year.
(iv) The Young Professionals will be required to discharge the duties as
assigned to him/her by the Ministry.
(v) The Income Tax or any other tax liable to be deducted, as per the
prevailing rules, will be deducted at source before effecting the payment
for which the Ministry will issue TDS Certificate (s).
(vi) In no case, the Young Professionals shall act, or conduct anything with
regard to any person or render any advice to Ministry which is adverse to
the interest of the Ministry.
(vii) The contract of Young Professionals may be terminated, after giving
one-month notice, in following situations:
e If the Young Professional is unable to do the assigned work.
e Quality of the assigned work is not to the satisfaction of the
है oS Ministry.
e ye? ? e If the Young Professional is absent from duty without due
a authorization.
y e If the Ministry elects not to renew the contract of the Young|
4 Professionals at the end of period.
है (viii) Termination shall be effected by written notice of 30 days served to
the Young Professionals. The termination will be without prejudice to
either party’s rights accrued before termination.
ix) Ministry reserves the rights to terminate the contract without giving
any explanation or whatsoever with immediate effect without any
remuneration or notice period on the ground of proven misconduct.
(x) The Young Professional is required to give 30 days’ notice to the
Ministry in case he/she opts to quit the assignment.
(xi) Jurisdiction for legal disputes, if any arising during the period of the
contract, will be in Delhi Courts only.

<!-- page 5 -->

(xii) The person who has worked as Young Professional shall not disclose
the information received by him/her during the period of such engagement
to any person other than Ministry at any time whether during continuance
of such engagement or after its severance.
Further, the Young Professionals shall not represent, advise or work for
any person for 02 years from the date of termination which may be
detrimental to the Ministry.
Selection Selection of the Young Professionals will be done on the basis of personal
process interview by a Selection Committee. Only the short-listed candidates shall
lbe called for the interview. No TA or DA will be paid for attending the
interview. At the time of interview, the shortlisted candidates shall have to
produce their Certificates, in original for verification.
12]Attendance and |(a) The working hours of the young professionals shall be same as regular
working days Government employees working in Ministry of Mines. No extra
remuneration shall be allowed for working beyond office hours or on
Saturdays/Sundays/ Gazetted Holidays. Compensatory leave in such cases
shall be at the discretion of the competent authority.
\(b) The attendance shall be marked in the Bio-metric system.
13]Confidentiality [During the period of assignment with Ministry of Mines, the young
and Secrecy professionals would be subject to the provisions of India Official Secrets
‘Act, 1923 and will not divulge any information gathered during the period
lof his/her assignment to anyone who is not authorised to know the same.
) re Selected candidates shall provide integrity certificates from 2
ed. references known to them.
0 y है JS ie A self-undertaking shall be provided by the candidate to the effect
FZ | ०0 that no criminal record or criminal case in any court is pending against
- है L. h os him/her besides the routine character and antecedent verification.
बल

<!-- page 6 -->

a

<!-- page 7 -->

Annexure-I
APPLICATION PROFORMA FOR YOUNG PROFESSIONAL
(LAST DATE : 10™ JULY. 2025)
I. Name:
Il. Date of Birth: Photograph
If. Address for correspondence: (self-attested)
IV. Contact Details-
Landline No.
Contact No. Alternative No.
Email Id. Alternative Email Id.
V. Academic Qualification (in reverse order, starting from the latest):
S.No. Degree | Year Subjects University/ Class/ Distinction
Institute Division (if any)
(Attach a separate copy if required.)
VI. Professional Qualification (in reverse order, starting from the latest):
S.No. Degree | Year Subjects University/ Class/ Distinction
Institute Division (if any)
(Attach a separate copy if required.)
VIL. List of relevant technical and academic publications (if any)
जा. Relevant experience:
a. Total years of experience and name of organizations.
b. Year-wise tasks of similar nature carried out during last three years.
c. Works of similar nature in hand and the expected date of completion.
Ix. A short note on your suitability for the post.
Name & Signature of the applicant
Name
Signature
Date:
Place:

<!-- page 8 -->
