---
doc_id: "3f4a9480bbe3ccbc"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/10/81901b8a62c987db3ba64e4d69c7f09d.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Amendment dated 10th September, 2025 to the Scheme Guidelines dated June 4, 2021, for the Production Linked Incentive (PLI) Scheme for Promoting Domestic Manufacturing of White Goods (Air conditioners and LED Lights)"
date: "2025-10-01"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c9737c817bcdd959"
---

<!-- page 1 -->

File No. P-29014/101/2020-LEI
Government of India
Ministry of Commerce & Industry
(Department for Promotion of Industry and Internal Trade)
thy

Dated: /O September, 2025
Subject: Amendment to the Guidelines dated June 4, 2021, for the
Production Linked Incentive (PLI) Scheme for Promoting Domestic
Manufacturing of White Goods (Air conditioners and LED Lights) -reg.

The “Production Linked Incentive Scheme (PLI) for White Goods (Air
Conditioners and LED Lights) manufacturers in India”, hereinafter referred to as
PLIWG Scheme, was notified vide notification No. CG-DL-E-16042021-226671 dated
16.04.2021.

For the effective operation and smooth implementation of the PLIWG Scheme,
guidelines were issued by DPIIT on June 4, 2021. The scheme was opened for
applications for a period of three months, starting from June 15, 2021, through a
dedicated web portal: https://pliwg.dpiit.gov.in/.

Subsequently, additional applications were invited under Clause 9.2 of the Scheme
Guidelines for Round 2 and Round 3, for investment periods from March 10 to April
25, 2022, and July 12 to October 12, 2024, respectively.

Based on stakeholder consultations, four corrigenda to the PLI Scheme for White
Goods—issued on August 16, 2021; February 24, 2022; October 9, 2023; and July 9,
2024—introduced measures such as cost-plus pricing, expanded capital investment
eligibility, and extended timelines, which have simplified compliance, improved ease
of doing business, and significantly boosted domestic manufacturing, investment, and
employment in the sector.

In view of the evolving market dynamics and continued interest from industry
stakeholders, it is proposed to invite fresh applications under Round 4 of the
Production Linked Incentive (PLI) Scheme for White Goods.

1. Re-opening of Application Window — Round 4

« Applications for the fourth round are invited under Clause 9.2 of the Scheme
Guidelines for investments, under the same terms and conditions as provided
in the Scheme Guidelines issued on June 4, 2021, with subsequent
amendments.

« For 4th round applicants, the initial investment period (Gestation Period) is
from April 1, 2021, to March 31, 2023 and they are required to achieve the
Minimum Cumulative Incremental Investment for the year 2025-26.

+ Investment Category Upgrade: Applicants having Gestation period 1% April
2021 to 31ST March 2022 or Gestation Period 1% April 2021 to 318" March 2023
may choose to upgrade to a higher investment category.

* The incentive shall be available only for the remaining tenure of the Scheme.

<!-- page 2 -->

2. The following amendments to the scheme guidelines are being
implemented in line with the proposed changes.
os
| Clause) Existing Applicants Moving to Highe:
Existing Applicants Moving tolmvestment Categories
Higher Investment Categories
4.4 Quantum of Incentive
n existing applicant is required tol4.4.1 Existing Applicants who have|
lachieve the Minimum Cumulativelmoved to Higher  Investmen
Incremental Investment for the yeafCategory under - Round 3
2024-25 as stipulated under th 4 33 . : .
respective higher Investment catego गा existing applicant is: required 19
lopted for to claim the incentive@chieve the Minimum  Cumulativ
मिला Incremental Investment for the yea
2024-25 35 stipulated under the
In the event an existing applicant fails|respective higher Investment catego
(© meet the eligibility thresholdjopted for to claim the incentive amount.
investment and Net incremental sal ५७ न ४
under higher Investment category inl” oe event an existing applicant ralls\to
lany claim year, they have the option t imeet the eligibility threshold investmen
return to their original Investment2™4 Net incremental sale under highe
category. Investment category in any claim year,
hey have the option to return to thei
Once this option is exercised, they arejoriginal Investment category.
eae cata Ate nceemefonee ts opon exercised they a
lamount received in the highe peduited {9 Say in ls original
investment categories will need to b loyesimernt category. ny ineen tive
refunded with interest calculated@’™ount ea ne the, highe
based on the current 3-year gpilinvestment categories will need to be
IMCLR, compounded annually. refunded with interest calculated based
हु n the current 3-year SBI MCLR,
Icompounded annually.
.4.2 Existing Applicants unde
Round 1, Round 2 & Round 3 opting
for Higher Investment Category
n existing applicant is required to
achieve the Minimum Cumulative
Incremental Investment for the yea
2025-26 95 stipulated under the}
respective higher Investment category)
pted for to claim the incentive amount.
In the event an existing applicant fails to}
meet the eligibility threshold investmen
land Net incremental sale under highe'

<!-- page 3 -->

Investment category in any claim year,
hey have the option to return to thei
riginal Investment category.
Once this option is exercised, they ar
required to stay in their original
investment category. Any __ incentiv
lamount received in the highe'
investment categories will need to b
refunded with interest calculated based
nn the current 3-year SBI MCLR,
ompounded annually.
.4.3 Applicants who moved to thi
Higher Investment Category during}
Round 3, as per the provisions of the PL
icheme for White Goods, shall continue}
fo be retained under the same category,
(Existing Clause) Revise Clause)
14.7. Time extension for thei4.7 Time extension for th
establishment of an additionallestablishment of an additional
manufacturing facility: manufacturing facility:
he Selected applicants would be/The Selected applicants would b
allowed to submit the details ofjallowed to submit the details of
additional location with all relevantiadditional location with all relevant
documents within three (3) years offdocuments within Five (5) years ०0
icommencing commercial productionlcommencing commercial production
during the tenure of the Scheme. luring the tenure of the Scheme.
3.The Guidelines issued on June 04,2021 and corrigenda issued on August 16,2021,
February 24,2022, October 9,2023 and July 9, 2024 shall be read incorporating above
revisions and additions where ever applicable.
.
Na /
(Sanjiv)
Joint Secretary to the Government of India
Email: Sanjiv.01@gov.in
ww
New Delhi, Dated: \o September, 2025
