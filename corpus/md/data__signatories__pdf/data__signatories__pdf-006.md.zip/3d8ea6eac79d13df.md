---
doc_id: "3d8ea6eac79d13df"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/8fb3b6177ce71c8f7619f9f97a84080f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Office order for entrustment of the additional charge of the post of Director-Planning, BBNL regarding"
date: "2025-07-30"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f99e4fc9177df667"
---

<!-- page 1 -->

No. E-13-2/2019-PSA(Pt.-IIl)
Government of India _
Ministry of Communications
Department of Telecommunications
Sanchar Bhavan, 20, Ashoka Road, New Delhi — 110 001
Dated:30July, 2025
; ORDER
In continuation of this Department’s order of even No. dated 17.10.2024 and
to ensure that the post of Director (Planning), Bharat Broadband Network Limited
(BBNL) does not remain vacant, as an interim measure and subject to the approval
of the Appointments Committee of the Cabinet (ACC), the entrustment of additional
charge of the post of Director (Planning), BBNL is assigned to Sh. Sudhakararao
‘Papa, Director (Enterprises), BSNL for a period of three months w.e.f. 01.08.2025
to 31.10.2025 or till further orders, whichever is earlier.
2. During the period of holding additional charge, Sh. SudhakararaoPapa will
not be entitled to any additional remuneration.
3. This issues with the approval of Hon’ble Minister of Communications.
(Jagbir Aone
Under Secretary to the Govt. of India
Tel. No. 2335 3992
4. Sh. Sudhakararao Papa, Director (Enterprises), BSNL, BSNL Bhawan,
Janpath, New Delhi — 110001 :
2. The CMD, BBNL, Corporate Office, 3rd Floor, Office Block-1, East Kidwai
Nagar, New Delhi-110023.
_ 8. O/o the Establishment Officer:-& Additiona Secretary, ACC, DoP&T, New
Delhi-01.
4. The Secretary, PESB, CGO Complex, Lodi Road, New Delhi-03
5. PS to Hon'ble MoC, Sanchar Bhawan, New Delhi.
6. PS to Hon’ble MoSC, Sanchar Bhawan, New Delhi.
7. PSO to Secretary (T), DoT, Sanchar Bhawan, New Delhi.
8. PPS to All Member (s), Digital Communications Commission, Sanchar
Bhawan, New Delhi. . :
9. Sr. PPS to Addl. Secretary (T), DoT, Sanchar Bhawan, New Delhi.
10. The Company Secretary, BBNL, Corporate Office, 39 Floor, Office Block-1,
East Kidwai Nagar, New Delhi-110023.
11. Sr. PPS/PPS to JS (A)JS (T)DDG (C&A)/Director (PSU-I), Dol, Sanchar
Bhawan, New Delhi.
12. CMD (s) MTNL/BSNL/TCIL/ITI Ltd.
13. Director (Restg.) for uploading on the website of DoT.
14. Dy. Director (OL), DoT, Sanchar Bhawan, New Delhi with the request to
provide Hindi Translation of the order. ”
