---
doc_id: "3fe8da2b9ab3a69f"
source_url: "https://www.dot.gov.in/static/uploads/2025/12/089e394684e7951e93d040c4dcdf3f18.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Vacancy Circular for engagement of Consultants for the Oo Addl DG Telecom DoT Odisha LSA"
date: "2025-12-25"
pages: 7
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "4e3e07717292433c"
---

<!-- page 1 -->

DoT/OD/Consultant/2022-23/ 173305544/2025
Government of India
Ministry of Communications
Department of Telecommunications
Office of the Additional Director General Telecom, Odisha LSA,
1“ & 2™ Floor, CPMG Building, Bhubaneswar 751001.
Tele: 0674-2393700 & FAX-0674-2393889
DoT/OD/Consultant/20-21/ Dated: 12-08-2025
NOTIFICATION
Subject: Engagement of consultants for the vacant posts of Junior Telecom Officer, Junior Engineer,

Telecom Assistant, Steno & Lower Division Clerk (LDC) on temporary contract basis in the
office of Additional Director General Telecom, Odisha LSA-Reg.

Additional Director General Telecom, Odisha Licensed Service Area (LSA), Bhubaneswar,
Department of Telecommunication, Ministry of Communications proposes to engage following
consultants for the vacant post, on purely temporary and on contract basis for a period of Six months
or till regular manpower is posted, whichever is earlier:

a) Junior Telecom Officer-2 Nos.

b) Junior Engineer -3 Nos

c) Telecom Assistant- 1No

d) Steno- LNo

e) Lower Division Clerk — 1No
Applications are invited from retired Government servants/ retired officers/officials of PSUs or
Research Organizations or retired person from BSNL/MTNL under VRS-2019 having age less than
64 years with adequate knowledge of working on computer and preferably having knowledge of DoT
field unit works/Telecom works as mentioned in the Section No.1 (i.e. Nature of Duties) of this
notification.
The consultants will be engaged on short term contract basis initially for a period of Six Months.
Based on his/her performance and requirement of this office, the contract can be further extended up
to a maximum of 6 terms of 6 months each or up to 65 years of age whichever is earlier.
The Additional DGT, Odisha LSA, DoT, Bhubaneswar reserves the right to cancel and not proceed in
the matter of engagement of consultants at any stage without giving any reason, whatsoever. The
decision of Additional DGT, Odisha LSA, DoT shall be final and binding.
The Additional DGT, Odisha LSA, DoT, Bhubaneswar reserves the right to accept or reject in part or
in full any or all the responses without assigning reasons whatsoever. The department reserves the
right to terminate engagement of a consultant at any point of time on the basis of poor performance or
any other reason as deemed fit.
Application form for the post of consultant on contract basis is at Annexure-A. Last date for
submission of application is 15.09.2025. Applications received after due date will not be considered.

Page 1of 7

<!-- page 2 -->

DoT/OD/Consultant/2022-23/ 173305544/2025
1. Nature of Duties for JTO/JE/TA:-
Work may be assigned in any of the following verticals of the LSA based on the respective cadre:

a) Service Compliance- CAF Audit, EMR Audit, Service Testing, Roll out obligation etc.

b) Technology- Secured dedicated communication network, Time Synchronisation of Telecom
Networks, Disaster Technology Management, interconnect Exchange, Inspections of Licensee
Network, Advocacy & Public Awareness etc.

०) Security- Operation and Maintenance of CMS/ IMS, Curbing illegal activities/ Control over
clandestine / illegal operation of telecom networks, Analysis of CDR/SDR and other security
activity assigned from time to time.

d) Rural- Rural connectivity for DBT, verification of OSO sites, RF coverage testing/ telecom
connectivity checking etc.

e) Admin, Legal, PG & Vigilance- Admin, PG, Building, Vigilance, Court case, PG cases, PQ &
VIP Cases, Claims related issues like Medical Bill, TA Bill etc. and processing of various
kinds of purchase bills and stock maintenance etc. along with other admin related Misc
activities etc.

> The consultant may have to go on official tour to discharge the above functions as
and when required. The engaged consultant may be allowed TA/DA on official tour,
if any, as per the entitlement at the time of retirement.

¢ Nature of Duties for Steno :- working on a computer, working on both physical and IT
related files. Working on various tools of Ms Office suites, drafting/Noting skills and general
office administration etc.

* Nature of Duties for Lower Division Clerk (LDC) :- Working on various clerical related
works, working on both physical and IT related files. Working on various tools of Ms Office
suites, drafting/Noting skilla and general office administration etc.

2. Period of Engagement:-

The consultants will be engaged on short term contract basis initially for a period of Six
Months. Based on his/her performance and requirement of this office, the contract can be further
extended up to a maximum of 6 terms of 6 months each or up to 65 years of age whichever is earlier.
Satisfactory performance certificate from the controlling officer is desirable for extending the terms
on each occasion
3. Eligibility:-

a) For consultant in JTO Level-Retired JTO or equivalent or above rank from DoT or any
other central/State Govt or Retired from CDA Scale with minimum substantive grade of
Level 7 of the 7" CPC or equivalent IDA Scale or holding analogous post of
Government/PSU/ Research Organizations.

b) For consultant in JE level — Retired JE or equivalent or above rank from DoT or any other
central/State Govt or Retired from CDA Scale with minimum substantive grade of Level 6
of the 7" CPC or equivalent IDA Scale or holding analogous post of
Government/PSU/Research Organizations.

c) For consultant in TA level — Retired TA or equivalent or above rank from DoT or any
other central/State Govt or Retired from CDA Scale with minimum substantive grade of
Level 5 of the 7" CPC or equivalent IDA Scale or holding analogous post of
Government/PSU/Research Organizations.

d) For consultant in Steno level — Retired Steno or equivalent or above rank from DoT or any
other central/State Govt or Retired from CDA Scale with minimum substantive grade of
Level 4/level5/Level 6 of the 7" CPC or equivalent IDA Scale or holding analogous post
of Government/PSU/Research Organizations.

Page 2 of 7

<!-- page 3 -->

DoT/OD/Consultant/2022-23/ 173305544 /2025
e) For consultant in LDC level — Retired LDC or equivalent or above rank from DoT or any
other central/State Govt or Retired from CDA Scale with minimum substantive grade of
Level 2 of the 7° CPG or equivalent IDA Scale or holding analogous post of
Government/PSU/Research Organizations.
Preference will be given to applicants from DoT/BSNL/MTNL background.
4, Remuneration per month:-
The remuneration and allowances payable will be as per Department of Expenditure , Ministry of
Finance OM No.03-25/2020-E-IIIA dated 09.12.2020, DoT order number 3-10/2014-SEA-1/Fin dated
29.03.2022 and subsequent orders issued by DoT HQ in this regard from time to time, Taxes as per
prevailing rules shall be deducted before effecting payment.
4.1(a) In case of retired officer from Central Government:
A fixed amount shall be admissible, arrived at by deducting the basic pension from the pay drawn at
the time of retirement. The amount of remuneration so fixed shall remain unchanged for the terms of
the contract. There will be no annual increment/percentage increase during the contract period.
4.1 (b) In case of retired officer from PSUs:
The remuneration shall be arrived by ascertaining equivalent level of post in the Central Government
at which the retired PSU employee is proposed to be appointed on contract basis. The notional pay of
such post in Central Government may be arrived at by taking the mean of Cell-1 and Cell-10 of the
corresponding pay level of such post. The sum so arrived may be treated as last basic pay and 50% of
such basic pay may be allowed as remuneration. The amount of remuneration so fixed shall remain
unchanged for the terms of the contract. There will be no annual increment/percentage increase during
the contract period.
4.2 No increment and Dearness allowance shall be allowed during the term of the contract.
4.3 No HRA will be admissible.
4.4 An appropriate and fixed amount as Transport allowance for the purpose of commuting between
the residence and the place of work shall be allowed not exceeding the rate applicable to the appointee
at the time of retirement. The amount so fixed shall remain unchanged during the term of
appointment. However retired employees engaged as consultant may be allowed TA/DA on official
tour if any as per entitlement at the time of retirement.
4,5 Paid leave of the absence may be allowed at the rate of 1.5 days for each completed month of
service. Accumulation of leave beyond a calendar year may not be allowed.
4.6 Income tax or any other tax liable to be deducted as per prevailing rules will be deducted at source
before effecting the payment for which the department will issue TDS certificate. Service tax as
applicable shall be payable extra as the prevailing rates.
5. Age Limit:-
Candidate should not be more than 64 years of age on the last date of submission of this application
i.e. 15.09.2025.
Page 3 of 7

<!-- page 4 -->

DoT/OD/Consultant/2022-23/ 173305544/2025
6. Confidentiality of data and documents:-
The data collected / produced as well as deliverables produced for the O/o Additional DGT, Odisha
LSA, Bhubaneswar, shall remain with this office. No one shall utilize or publish or disclose or part
with, to a third party, any part of the data or statistics or proceeding or information collected for the
purpose of this assignment or during the course of assignment from the O/o Additional DGT, Odisha
LSA, Bhuabneswar, without the express written consent of this office. The consultants are bound to
hand over the entire set of records of assignment to this office before the expiry of the contract and
before the final payment are released by the office.
% Conflict of interest:- it nfli of ii ‘est:-
The consultants engaged shall in rio case represent or give opinion or advice to others in any matter
which is adverse to the interest of the Department.
8. Closing date for submission of applications:-
Up to 17.00 Hrs. of 15.09.2025.
9. Selection Procedure:-
A Selection Panel will be constituted for this purpose. The selection will be made after due scrutiny of
applications and supporting documents, and based on the outcome of offline interviews as well as an
assessment of the candidates. The decision of the department in the matter of selection of consultants
shall be final and binding upon the application. The empaneled list will be informed to the applicants.
10. How to Apply:-
As per enclosed format named as Annexure-A.
¢ Application in prescribed format completed in all respects as mentioned in Annexure-A.
should be submitted for the desired posts, mentioning the name of the post clearly in
Capital Letters on the top of the envelope.
* Applications along with required documents and Self-attested copies of certificates must
reach to "AD (ADMIN), O/o Addl. DGT, DoT, ODISHA LSA, 1° FLOOR, CPMG
BUILDING, BHUBANESWAR-751001" ON OR BEFORE 45.09.2025 BY 5:00 P.M.
through Speed Post or Registered Post or by Hand only. The application(s) received in
the office in any other mode and after the last date and time shall be summarily rejected.
11. Special Condition:-
* A Candidate shall apply only for one post according to his/her eligibility. In case a
candidate applies for more than one post, his/her candidature will be rejected.
* The consultant may have to perform outdoor duties in all over the Odisha LSA
Jurisdiction. Those who are not able to perform outdoor duties need not apply.
12. Application to be forwarded to:-
Additional DGT, Odisha LSA, DoT, 1* & 2” Floor, P & T building, Unit-IIl, Bhubaneswar -751001.
13. Termination of contract:-
The contract may be terminated by either of the party with prior notice of 30 days.
The above said engagement is purely on temporary and on contract basis. The selected candidates will
be governed by the provision of the guidelines for engagement of consultants in DoT as amended
from time to time.
Page 4 of 7

<!-- page 5 -->

DoT/OD/Consultant/2022-23/ 173308544/2025
14. Documents to be attached:-
i) Self-attested copy of LPC of last month of service
ii) Self-attested copy of Latest three months pension amount (Bank/Postal statement of Pension/
Saving account )
iii) Self-attested copy of Copy of Highest educational certificate of the candidate.
Digitally signed by
Suresh Chandra Panda
Date: 12-08-2025
12:03711
AD (Admin. & HR)
O/o Additional DGT, Odisha LSA, DoT
1* & 2 Floor, P & T building,
Unit-III, Bhubaneswar -751001.
Email- ada-od-dot@gov.in
Copy to:
1. Director General, DoT HQ, New Delhi
2. DDG (Estt.) / Director (Estt.), DoT HQ, New Delhi
3. Director (IT) , DoT HQ, New Delhi for publishing on DoT website under ‘Vacancies’
4. GM(Pers.), BSNL Corporate Office, BSNL, Janpath, New Delhi
5. CGMT, Odisha Circle, BSNL, Bhubaneswar
6. Notice Board
7. Office Copy.
Page 5 of 7

<!-- page 6 -->

DoT/OD/Consultant/2022-23/ 173305544/2025
Annexure-A ure-,
APPLICATION FORMAT FOR THE POST OF CONSULTANT (JTO/JE/TA//STENO/LDC)
(एणाहणॉगा ?०५ गएश्त 07 .......................--------------
1. Name: Recent
Passport size
2. Father’s name : photograph
(Self-attested)
3. Present Residential Address:
4. Aadhaar Number:
5. Date of Birth(DD/MM/YYYY):
6. E-mail address with telephone number:
7. Date of entry into Government Service/PSU:
8. Date of retirement:
9. Last Month Basis pay drawn(on superannuation):
10. Basis Pension Drawn as on 31.08.2025:
11. Educational Qualification:
12. Brief particulars of service with nature of duties performed for 10 years before retirement
SLNo | Name of Ministry/Dept. Period Post Held Nature of work
(DD/MM/ done
YYYY)
From To
13. Brief particulars of service with nature of duties performed for after retirement till date
SLNo | Name of Ministry/Dept. Period Post Held Nature of work
(DD/MM/ done
YYYY)
From To
ES ae eae oe eae न पान
{cma La A | A | | |
{Lam [FP ae | |. | |
14. Knowledge of Computer
MS Word CL ar rae
MS Excel ea NT Tt |
Any other (Please speci यश 1 |
Page 6 of 7

<!-- page 7 -->

DoT/OD/Consultant/2022-23/ 1330854472025,

15. Additional information, if any, in support of your suitability for the post.
The candidate has to submit a detailed resume on his experience, works handled relative to Telecom
sector activities and other official functions (Not more than 2 pages)

Following documents must be attached with the application.

1) Self-attested copy of LPC of last month of service

2) Self-attested copy of Latest three months pension amount (Bank/Postal statement of Pension/ Saving
account )

3) Self-attested copy of Highest educational certificate of the candidate.

DECLARATION
This is to certify that no disciplinary proceedings were pending against me on the date of
application and the information given above is true to the best of my knowledge and belief. The
supporting documents would be made available on demand; and that I unequivocally and
unconditionally accept all the terms & conditions of Circular No. DoT/OD/Consultant/20-21/
Dated: 12-08-2025.
ee hereby declare that my engagement as
Consultant in O/o. Addl. DGT, Odisha LSA, Department of Telecommunications, Odisha is purely on
short term contract basis.
2. I shall not have any right to claim for seniority or regular service in the GovernmenULSA on the
basis of the service rendered by me as a Consultant in O/o. Addl. DGT, Odisha LSA.
3. 1am not entitled to any other entitlement in the Department of Telecommunications or O/o. Addl.
DGT, Odisha LSA except consolidated lump sum payment admissible as per rule and therefore will
Not resort to any claim for the same.
Yours faithfully,
Date: Signature:
Place: Full Name:
Page 7 of 7
