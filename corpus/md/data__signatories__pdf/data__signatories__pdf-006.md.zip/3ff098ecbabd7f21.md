---
doc_id: "3ff098ecbabd7f21"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/ac7a87ae8088ca780a239829a635ed7b.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Office Order for look after charge of the post of Member-Technology, DCC regarding"
date: "2025-07-30"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "588dffec8b88f991"
---

<!-- page 1 -->

}- No.1-4/2016-Admn.1__
Government of India
Ministry of Communications
Department of Telecommunications
| 415, Sanchar Bhawan, 20, Ashoka Road, New Delhi-110001
Dated the 3eJuly, 2025
| ; OFFICE ORDER
As an interim measure and subject to approval of the Appointments
Committee of the Cabinet (ACC), the look after charge of the post of Member
(Technology), DCC is assigned to Shri Rudra Narayan Palai, ITS for a period of
three months w.e.f. 01.08.2025 to 31.10.2025 or till his appointment on regular
basis to the post or till further orders, whichever is the earliest.
a He will look after the charge of the post of Member (Technology) in addition
to his existing duties and the officer will not be entitled for any additional
remuneration.
3. This issues with the approval of Hon'ble Minister of Communications,
(Jagbir Singh Rana)
Under Secretary to the Govt. of India
Tele: 2335 3992
Copy to: : 5
1. Shri Rudra Narayan Palai, ITS.
2. PS to Hon'ble MoC.
- 3. PS to Hon'ble MoSC.
4. PSO to. Secretary(T) & Chairman(DCC), DoT
5. PPS to Member(F)/Member(S)/Member(T)/CGCA/DG(T).
6. PPS to AS(T)/Administrator(USOF), DoT
7. PPS to JS(T)/JS(A)/DDG (C&A)/CVO/Economic Advisor DoT
8. All Advisors/Sr. DDGs/DDGs, DoT through e-office notice board.
9. Director (IT) for uploading on DoT website.
10. E-Office notice board.
11. Order Bundle.
(rr भ भा... ||
