---
doc_id: "3fca40daaa44c2f5"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/09/da5a56f1509b297c27602945df299756.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Corrigendum for RFP - Hiring Agency for Design and Development of UNNATI, 2024 web portal"
date: "2025-09-01"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7031d9f73c215309"
---

<!-- page 1 -->

P-44026/19/2024-DBA-II
P-44026/ 19/2024-DBA-II
Government of India
Ministry of Commerce and Industry
Department for Promotion
Promotion of Industry and Internal
Internal Trade
(NERS Division)

****
****

Udyog Bhawan
th Aug 2024
14
Dated 14

CORRIGENDUM

RFP for Hiring Agency for Design and Development of UNNATI, 2024
Subject: - RFP
web portal-reg
In
continuation of DPIIT RFP document dated 15.07.2024 on
In continuation
on the subject
in the table below.
below.
indicated in
above, the following changes are made as indicated
mentioned
mentioned above,
RFP
RFP Clause
Clarification/replies by DPIIT
RFP
RFP Clause
No.
amended clause to be read
successfullyThe
27 (e)
The amended
read
The bidder must have successfully
projectsas:
completed at least two (2) projects
as:
completed
with project value not less than 50
have
bidder
must
lakh
lakh in
in the area of development ooi The
leas1
Governmen1
portal
for
Governmenl successfully completed
completed at leas
web
value
project
with
projects
(2)
I
Agency
two
I
Government
I
Department /
in the
India during last 5 years as not less than 50 lakhs each in
in India
PSU in
area of development of web portal
on
March 2024.
on 31st March
Department I/
for Government Department
in
Government Agency / PSU in
India during last 5 years as on
31st March
2024.
March 2024.
in
IT/ITESThe
in
Turnover
from
IT/ITES The execution will be
27 (b)
Sales
and
terms
the
with
5accordance
~
be
must
and
� 5[accordance
operations and
and services
in
specified
financial yearsconditions
Crores in
in last three financial
years conditions
in the
Request
[Request for Proposal (RFP).
March 2024.
ending at 31S
311� March

27 (a)

27 (d)

chanae.
As per RFP,
RFP, no chanQe.
Audited Balance
submit
may
You
should
Company
Responding
Responding Firm/
Balance
- Registered
be: Registered as aa CompanySheet
Company Sheet for FY 2020-21, 2021-22
and 2022-23.
-and
under Companies Act,1956/2013 Registered
Registered with Goods and Services
Tax Network (GSTN).
(GSTN). Have been
operating for at least five (5) financial
2024.
March 2024.
31st� March
years as on 31
read as:
validThe Clause 27(d) to be read
possess aa validThe
The bidder must possess
9001
and ISO 9001
CMMiDev L3 and

<!-- page 2 -->

28 (b)
(b)

28 (c)
(c)

"The bidder
bidder must
must possess
possess a
a valid
Certificate as on
submission "The
on date of submission
or
ISO
9001
of
CMMiDev
CMMiDev L3
9001
of this
this RFP"
RFP"
on date
date 01
Certificate
as on
0
as
submission
submission of this RFP."
The
The bidder
bidder should
should have
have minimum
minimum 100
100 IT
ITYou
are requested
requested to
to submit
submit an
an
You are
on HR
resources engaged
engaged on
on its payroll
payroll as
as on
confirming the
HR certificate confirming
31st
31st March
March 2024
2024
employees on
on
IT employees
number
number of
of IT
100~125
100-125
marks
3
3 marks
(on Company
payroll (on
company
company payroll
126-150
4 marks
126-150
signed by the
the
letterhead)
letterhead) duly signed
and 5
150
150
5 marks
marks
and
of the
signatory of
the
authorized
authorized signatory
above
department.
department.
have The amended
The
The firm/ company should
should have
clause to
to be
be read
read
amended clause
experience in
in implementation
implementation of projects as:
development,
covering
software
software
resource deployment and maintenance
maintenance No.
Marks
No.
o· Marks
01
support
support for
for any
any Government
Government Department
Department
Projects
I/Government Agency I PSU in
/Government
in India
10
2-4
during
during last
last 5years
5years as
as on
on bid
bid submission
submission
15
date with project value not less than Rs. 5-7
50 lakh.
and above
above 20
8 and
No.
No.
ol Marks
Marks
0
Projects
Document Required
CA
CA Certificate
Certificate may
may be
be accepted
accepted
2-3
4
1~-5
along
with
invoice
submitted
to
along
with
invoice
submitted
to
4-5
8
the client.
the
client.
12
12
6 -7
6-7

8-9
10 above

28 (d)
(d)

16
16
20

remain in
in
Other
Other conditions
conditions will remain
accordance with the terms and
and
in
in the
the
specified
conditions
specified
Request
for
Proposal
(RFP)
.
Request
(RFP).

The
company should have
have The
The firm/ company
clause to
amended clause
to be
be read
read
The amended
experience of developing web portal(s) as:
implementation of Schemes of
for implementation
0
Department
State/Central No.
of
State/Central
of
Marks
No.
01
0 Marks
PSU/Govt.
Government
Government I PSU/Govt.
Projects
Projects
No.
01 Marks
No.
Marks
O1
10
5-7
Projects
Projects
15
7-10
5-7
4
Above 10 20

8-9
10-11
10-11
12-13

Above
~bove 13

4

8
12
16
16
20

Document Required
CA Certificate
Certificate may
may be
be accepted
accepted
CA
along with
with invoice
along
invoice submitted to

<!-- page 3 -->

the client.
Other conditions will remain
remain in
in
accordance with the terms and
conditions
specified
in
in the
Request for Proposal
Proposal (RFP).

8

Training and
and Capacity Building

The agency is required
required to
conduct minimum 2 trainings in
in
each states of NER in
in physical
IT may increase
increase the
mode. DPI
DPIIT
number of visits to the state as
and when required.
The agency will have to travel to
different states of NER at any
given point of time. In
In such cases,
the
transportation
charges,
boarding
lodging expenses
boarding and lodging
shall be borne by the agency.

4

5
27 (h)

Hosting at MeitY empaneled
Cloud
Cloud

Cost of Cloud
Cloud Servers not to be
included in
included
in the Financials. The
cloud
cloud will be provided by DPIIT
NIC team but the development
cost will be borne by the agency.
SMS Gateway Integration with
Cost of SMS Service will be borne
required SMS Pack
required
by
by the agency.
Consortium
bidding/ sub- contractingThe
will
be
in
contracting The execution
Consortium
in
is not allowed
accordance with the terms and
and
conditions
specified
in
in the
Request for Proposal (RFP).

3

User Management

3

Integration Requirements

9 (XII)

Languages of Portal Content

3

Scheme wise Incentives

As per RFP
RFP,, no chan~e.
change.
Bidder to decide based
based on
on the
Gazette Notification of UNNATI
o1
and
their
experience
o1
developinQ
developing similar portals
Please
Please refer clause 9 (Integration
with another Platform
Platform (If required))
required))
Local languages integrated in
in the
Portal such as Assamese, Bodo,
Bengali and Nepali.
Benaali
Please refer to the Gazette
Notification for UNNATI Scheme

<!-- page 4 -->

3
3

3
3
3
3

3
9
3

3

3
3
3

Please refer to the Gazette
Notification for UNNATI Scheme,
Committee Master
Clause 10: Governance and
Implementation Mechanism
Implementation
Please refer to the Gazette
Unit Category
Category
Notification for UNNATI Scheme
Notification
on the
Bidder to decide based on
Notification of UNNATI
Gazette Notification
Unit Master
experience
0
0l
their
and
developing
developina similar portals
Please refer to the Gazette
Claim Master
Notification
Notification for UNNATI
UNNATI Scheme
If required
required by
by the department, application Please refer clause 9 (Integration
will be integrated with other portals forwith
with another Platform (If required))
required))
easy
easv transfer of data.
Bidder to decide based on the
Gazette Notification of UNNATI
Applicant Panel
0
0l
experience
their
and
and
developing similar portals
developing
Please refer to the Gazette
Notification
Notification for UNNATI Scheme
Governance and
Committee Level
Clause 10:
Implementation Mechanism
Implementation
Apply for Claim
Apply
Documents Upload

3
Application
Submission

Preview

before

3
Print Application Form
3
!Acknowledgement
Acknowledgement Letter

3
View/ Download Certificate
3

Approval Authority/Admin Panel

Please refer to the Gazette
Notification
Notification for UNNATI Scheme
Please refer to the Gazette
Notification for UNNATI
UNNATI Scheme
Bidder to decide based on
on the
Final Gazette Notification of UNNATI
0
experience
ol
their
and
developing similar portals
Bidder to decide based on
on the
Gazette Notification of UNNATI
0
experience
their
and
developing
developina similar portals
Bidder to decide based
based on the
UNNATI
Notification of UNNATI
Gazette Notification
0
experience
01
their
and
developing similar portals
developing
Bidder to decide based on
on the
Notification of UNNATI
Gazette Notification
o1
experience
their
01
and
developino similar portals
developing
Bidder to decide based on the
UNNATI
Gazette Notification of UNNATI

<!-- page 5 -->

3
3
~pproval and
and disbursal of
Approval
of claims
3
3
Return application
any query)
application (if any

3
3
View Application
Application Status

3
3
View
View Claim
Claim Status
Status

3
3
Claim Settlement Process
3
3
View
View Certificate
Certificate
3
3
View
View MIS
MIS Report
Report

3
3
View Dashboard
3
3
MIS
MIS reports
reports and
and Drill
Drill down
down Dashboard
Dashboard
10
10

experience
experience
o1
their
and
o1
and
developina
developing similar portals
on the
Bidder
Bidder to
to decide based
based on
the
Notification of
of UNNAT
UNNATII
Gazette
Gazette Notification
their
experience
experience
Ol
and
and
0
develooina
developing similar
similar portals
Bidder
Bidder to
to decide based
based on
on the
the
Notification of UNNATI
Gazette Notification
Gazette
experience
o1
their
0
their
and
and
developina similar
developing
similar Portals
portals
on the
Bidder
Bidder to
to decide based
based on
Gazette
Gazette Notification of UNNATI
o·
experience
0'
experience
their
and
and
develooina similar portals
developing
Bidder
Bidder to
to decide
decide based
based on
on the
the
Notification of UNNATI
Gazette Notification
Gazette
0
their
experience
experience
their
and
and
developina
develooina similar portals
oortals
on the
the
Bidder
Bidder to
to decide
decide based
based on
Gazette Notification
Notification of
of UNNATI
01
their
experience
0
and
and
develooina similar Portals
developing
portals
Bidder
Bidder to decide
decide based
based on
on the
the
of UNNATI
UNNATI
Notification of
Gazette Notification
Gazette
o·
0
their
experience
experience
and
and
developina
developing similar portals
Bidder
Bidder to
to decide
decide based
based on
on the
the
Notification of UNNATI
Gazette Notification
Gazette
o·
experience
experience
their
0
and
developina similar portals
on the
the
Bidder to
to decide
decide based
based on
Bidder
of UNNATI
UNNATI
Gazette
Notification of
Gazette Notification
O'
experience
their
experience
their
0
and
and
developina
developing similar portals
Bidder
Bidder to
to decide
decide based
based on
on the
the
UNNATI
of UNNATI
Gazette Notification
Notification of
Gazette
of
their
experience
experience
Ol
and
and
developing
developing similar
similar portals
portals

!Agency
Agency has
has to
to give support to
DPIIT/NIC/or
DPIIT/NIC/or any
any other
other data
data centre
centre team
team
for hosting and
deployment ol
for
of
the
After development,
the application.
application. After
development.] 11 .. Cost
not to
Cost of
of Cloud
Cloud Servers
Servers not
to be
be
agency has to get the security audit o1
agency
of.-ncluded
ncluded in
in the Financials. The
the source code from CERT _ 11
be
loud
loud
will
be provided
provided by
by DPIIT
DPIIT
c
In
In empanelled agency. SSL has to be c
NIC
team
but
the
development
N
IC
team
but
the
development
implemented
on
the
application
implemented
on
the
application
domain/URL
cc ost will be borne by the agency.

<!-- page 6 -->

9 (XXX)

11
11

13
13

13
13
13
13

13
13

13
13

28 (e)

28 (f)

6

2. The cost of Security audit will
implementing
be borne by the implementing
agency.
agency.
FAQ (Frequently Asked Selected agency in
Provision of an FAQ
in consultation
consultation
address common
Questions) page to address
common with
with DPIIT
user queries.
in
be
in
shall be 6 months The execution will
The project duration shall
and
terms
the
with
and
accordance
with
from the date of contract signing,
in
in
the
encompassing all phases from initial conditions
specified
and user Request for Proposal
design to final deployment and
Proposal (RFP).
acceptance testing.
As per RFP, no change.
in
be
in
execution will be
execution
The
and
accordance with the terms and
accordance
in the
UAT clearance for PHASE-I
specified
specified in
conditions
PHASE-I
Proposal (RFP).
Request for Proposal
Request
As per RFP,
REP, no change.
Helpdesk support for addressing user Please
12 (AMC)
Clause 12
Please refer Clause
related to and
queries and technical issues related
and Form
Form Fin-2
Fin-2 of the RFP.
RFP.
portal usage.
in
in
be
will
The execution
Cost I Fees
Fees related
related to the CERT-in/
CERT-in / SSLIThe
and
with the terms and
borne by the bidder. The same accordance with
shall be borne
shall
in the
shall
user conditions
specified in
shall be reimbursed
specified
reimbursed by the user
quoted value by Request for Proposal
department on
on actual
actual or quoted
Proposal (RFP)
(RFP)..
the bidder, whichever is the lowest.
As per RFP, no change.
in
be in
will be
The execution
with the terms and
required accordance with
One Year Warranty support required
in the
specified
after Handover Stage of the Application conditions
specified in
software
Request for Proposal
Proposal (RFP)
(RFP)..
As per RFP, no change.
change.
AMC Support Services for Five
Five
completion of the
Year Year after completion
AMC Support Services for Three Year
after completion of the Warrantee Period development of the design
design and
and
portal.
web
development of the web
The bidder should have experience o1
01 The execution
in
in
will be
party accordance with the terms and
developing API integration with 3rd party
and
applications (other than email or SMS) conditions
in
specified
in the
specified
Govt. in Request
PSU/State Govt/Central
for any PSU/State
Govt./Central Govt.
Proposal (RFP).
Request for Proposal
on 31st
India during last 5 years as on
As per RFP, no change.
March
March 2024.
The firm/ company should have The
in
in
execution will be
developed and implemented
implemented Mobile accordance with the terms and
on Android or IOS
application on
application
IOS platform
platform conditions
the
in
specified
having Geo-Tagging I/ Geo-Fencing Request for Proposal
having
(RFP) .
Proposal (RFP).
functionality for any Department in State As per RFP, no change.
change.
/ Central Government/Govt. PSU/Govt.
Autonomous body in India
their
Security Audit of Application by
based on their
b} Bidder to decide based

<!-- page 7 -->

ing similar
managing
for manag
similar
experience
experience for
engagements.
enQaQements.
advise on
on the
the
You may
may propose
propose // advise
Open-source technology/platform
technology/platform will
will You
Open-source
(II)
99 (II)
the
the
technical
technical
during
during
same
same
be preferred.
preferred.
be
·presentation
1presentation..
existing data
an existing
data
there is
is an
Yes, there
Hosting at
at MeitY
MeitY empaneled
empaneled Cloud
Cloud Yes,
44
Hosting
base
base
submission may
last date
date for
for submission
may
The last
Technical and
Last date
date of
of receipt
of Technical
and The
receipt of
Last
be extended
by one
one week
week from
from
extended by
be
proposals is
Pinancial proposals
Financial
is
the
of the
the corrigendum.
corrigendum.
issuing of
he issuing
09-08-2024
09-08-2024
will
Proposals that
that are
are received
received late
late will
Proposals
not
not
be considered
considered
be
with regard
regard to
to
details with
The details
Last date
of receipt
receipt of
of Technical
Technical and
and The
date of
Last
confirmed
not be
be confirmed
extension may
may not
an email
Financial proposals
proposals through
through an
email extension
Financial
at this
this point.
point.
that are
are at
05-08-2024 Proposals
Proposals that
05-08-2024
will not
received late
late will
not be
be considered
considered
received
to be
Helpdesk and
and Handholding
Handholding to
be
Helpdesk
46 Form
4. Helpdesk
46
Form 2:
2:
4.
Helpdesk and
and Handholding
Handholding
and
development and
with development
replaced
Bid
replaced with
Financial
Financial Bid
Query
of
Query
of
management
management
format
format
on the
the
System on
Management
Management System
porta
oortall
The revised
revised project
project cost
cost :: Rs.
Rs. 1.50
The
Project Cost
Cost :: Rs.60
Rs.60 Lakhs
Lakhs
Project
crore
crore
Revised
Revised
Rs. 1.50
1.50 Lakhs
Lakhs
27
EMO :: Rs.
EMO
27 (f)
(f)
EMO: Rs.
Rs. 3.00
3.00 Lakhs
Lakhs
EMO:
The agency
agency must
must have
have an
an office
office in
in
office in
in The
Is itit mandatory
mandatory to
to have
have an
an office
Is
Delhi NCR
NCR region
region and
resources
and resources
Delhi
new
new Delhi?
Delhi?
should
development team
of the
the development
team should
of
UdyogNanijya
at UdyogNanijya
stationed at
be stationed
be
supervision o1
o
Bhawan under
under the
the supervision
Bhawan
IT.
NIC-DPI
NIC-DPIIT.
Hosting Charges of Mobile
The mobile
mobile application
application hosting
hosting will
will
The
Application
be provided
provided by
by DPIIT
DPIIT NIC
NIC team
team
be
but the
the development
development cost
cost will be
be
but
the agency.
borne
borne by
bv the
agency.
Additional Functionalities
Functionalities
Additional
app for
of mobile
(i) Development
Development of
mobile app
(i)
and
and monitoring
monitoring and
geo
tagging and
geo tagging
launching on
on Google
Google play
play store
store and
and
launching
store.
Apple app
app store.
Apple
Agency
CERT-In empaneled
empaneled Agency
CERT-In

(ii)
(ii) Query
Query management
management system
system

Report
(iii)
Click Status
Status Report
(iii) One
One Click
Generation
of the
the particular
particular industrial
industrial
Generation of

<!-- page 8 -->

unit which
monitoring.

will

help

in
in

claim

(iv) Training and
and capacity building to
increased so as to ensure
be increased
in each
minimum 2 training sessions in
State of NER.
(v) Preparation of online training
materials like short videos and
and
manuals regarding the procedural
steps involved
involved in
in registration
registration and
and
claim processing.
(vi) One Click Status Report
Generation for all industrial
industrial unit which
o1
will help them in
in tracing the status of
their application.
period
maintenance
The
(vii)
maintenance
period
increased from 3 years to 5 years
increased

5cv2n

~)Y
(Sher Singh Meena)
,Under Secretary to the Govt. of India
