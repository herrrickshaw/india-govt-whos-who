---
doc_id: "3de46628bbedc9cf"
source_url: "https://shipmin.gov.in/sites/default/files/Sr.%20Dy.%20Chief%20Accounts%20Officer%20Circular%20dated%203.5.2021.pdf"
ministry: "Ports, Shipping and Waterways (MoPSW)"
title: "Sr. Dy. Chief Accounts Officer Circular dated 3.5.2021.pdf"
date: ""
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f032a556296ec1e9"
---

<!-- page 1 -->

OE लक किलिकिललिलिली ली
wag ote सामान्य प्रशासन विभाग
'फोन/शा०1९: 91-22-6656 ९ | पोर्ट a Lu !
5656 पोर्ट भवन, दूसरा माला
MUMBAI PORT TRUST घूरजी वल्लभवास मार्ग dere इस्टेट
oar A &> मुंबई - 400 001.
२. fy oe <\ General Administration Department,
mn CANT \ CS ) Port House, 2 floor,
SAGARMALA Xe Sy oy 5.V. Marg, Ballard Estate,
PORT-LED PROSPERITY Se, MUMBAI. 400 001.
No, GAD/P/RECT-Sr. Dy. CAO/4 82 3rd May, 2021.
The Chairmen
All Major Port Trusts
(Except Kamarajar Port Ltd)
Sir/Madam,
Sub: Filling up the post of Sr. Dy. Chief Accounts Officer in
the pay scale of Rs.80000-220000 (pre revised
Rs.32900-58000) in Mumbai Port Trust by absorption
through composite method.

One post of Sr. Dy. Chief Accounts Officer in the pay scale of Rs.80000-
220000 (pre revised Rs.32900-58000) in Mumbai Port Trust is vacant w.e.f.
1.9.2020, In terms of MbPT Employees (RSP) Regulations, 2010, the post is to
be filled by absorption through composite method amongst officers from Major
Port Trusts. Copy of the Recruitment Rules for the post is at Annexure I.

2. Applications are invited from eligible and willing officers of all Major Port
Trusts possessing prescribed qualifications, experience and other
criteria/requirements as per the Recruitment Rules.

3. Applications be made through “Online Application Portal (OAP)”. Print out
of online application should be submitted through proper channel, alongwith
copies of all required documents. The crucial date for determining eligibility for
the post of Sr. Dy. Chief Accounts Officer will be 1.5.2021. Applications,
alongwith following documents may be forwarded by the concerned Port Trust to
the undersigned so as to reach this office on or before 18.6.2021.

(i) Certified copies of ACRs/APARS for the last 5 years (2015-16 to
2019-20) (duly attested by an officer not below the rank of Dy. HOD
on each of the page).

(ii) Astatement showing year wise availability of ACRs and grading duly
signed by the HoD or Secretary. If ACR for a particular year /period
js not available, “No Report Certificate” to that effect may be attached
alongwith ACRs of the preceding years.

<!-- page 2 -->

‘ ‘

(iii) Administrative and Vigilance clearance duly filled, signed and
stamped by the Head of the Department (copy of proforma enclosed
at Annexure II).

(iv) No objection certificate from the respective port.

(v) | Undertaking of the applicants to the effect that candidature will not
be withdrawn, if selected by Services Selection Committee.

(vi) attested copies of all certificates as a proof of educational
qualification, experience in the respective post and pay scale wise,
duly verified by the port while forwarding the application to this Port.

(vii) If any major or minor penalty has been imposed on the applicant
during the last 10 years, the disciplinary case leading to such
penalty along with necessary document may be sent by the
forwarding authority along with the application. Vigilance report is
to be furnished in the attached format as Annexure III.

4.1 Instructions to the candidates:

Interested eligible candidates are requested to apply online against this
circular on the ‘Online Application Portal (OAP)" of the Ministry of Ports, Shipping
and Waterways website http://onlinevacancy.shipmin.nic.in. The link will be
open from 4.5.2021 to 3.6.2021. The candidate at first has to register himself
in the OAP. After applying through online, the candidate has to take printout of
the online application and submit the same alongwith the self-attested
photocopies of supporting documents and 2 recent passport size photographs to
concerned port. Incomplete applications or applications received late may not be
considered.

4.2 In terms of Ministry's letter dated 9.7.2020, the Appointing Authority as
well as Disciplinary Authority for all Dy. HoD level posts will be the Central
Government i.e. Secretary (Shipping). In this connection, all Major Porta are
directed to carry out amendments in their Service Regulations viz. Recruitment
Rules (RRs), Seniority and Promotion (RS&P), Classification, Control and Appeal
and other relevant Regulations (wherever required) as per the laid down.

4.3 Subsequently, the Ministry, by letter dated 29.12.2020 has conveyed that
“till amendments in the Service Regulations viz. Recruitment Rules (RRs),
Seniority and Promotion (RS&P), Classification, Control and Appeal and other
relevant Regulations are notified, Dy. HoD level posts in Major Port Trusts may
be filled up only by absorption through composite method at Port level.
Advertisement for filling up of the posts, DPC etc. may be held at Port level.
However, recommendations of the DPCs may be conveyed by Major Port Trusts recommendations of the DPCs may be conveyed by Major Port Trusts

<!-- page 3 -->

a a -
to this Ministry and obtain approval of the Ministry before issuing appointment issuing appointment
orders.”

5. Circular alongwith annexures in also available on our website
www.mumbaiport.gov.in.
6. An per Ministry’s advisory dated 26.9.2019 in respect of filling up the post
of HoD level, in case of receipt of advance copy of application in respect of any
applicant by the Port, candidature of the candidate will not be considered by the
Ministry if his/ her application is not received through proper channel by the
Port within 15 days of the last date of receipt of applications. The same analogy
will be applicable for the Dy. HoD level post also.

Yours faithfully,

(es

DA: As above (Smt. S.G. Patwardhan)

Sr. Dy. Secretary

<!-- page 4 -->

Finance Department 5
* है Annexure I
[SI [Name of the No. |Classifi- [Scale Whether [Upper Educational and other Whether Period [Method of in case of promotion! Remarks
No.|Post lof cation Jo [Selection Age limit |qualifications prescribed |(a) age lof recruitment labsorption/deputation,
Posts| Pay for Hor direct for direct recruitment — |(b) educational [Probation |(whether by lgrades from which it
(Rs) |Non- lrecruit- qualifications (in years) |direct Ishould be made
Selection ment (c) experience recruitment fF
(in years) for direct lor by
recruits will |promotion/
If FE oa a 5
jof promotion! deputation)
labsorption/
Jdeputation
jenior fase" | ० Essential = (a) No | A” |By absorption |For absorption throug]
Deputy 400 - 16) Member of (b) Yes through composite method,
Chief 20800 Institute of \(c) No composite (Officers holding
[Accounts Chartered method failing {analogous posts or
Officer Accountants of which |Dy.Chief Accounts Officer
India or of land equivalent posts in
Institute of Cost by deputation |respective discipline of
land Works from other Finance Deptt. in the
Accountants of Govt. scale of pay of
India organisations —_|Rs.13000-18250 with
land failing both |3 years regular service
(ii) Twelve years in the grade
lexperience in Iby direct Rs.13000-18250 in a
jexecutive cadre in recruitment. {Major Port Trust or
the field of Finance, Dy.Chief Accounts Officer
Accounting in an and equivalent posts in
industrial/ respective discipline of
commercial/ Govt. Finance Deptt. with
Undertaking. 2 years regular service in
the grade and a combined
regular service of 7 years
jin the scales of pay of
Rs.10750-16750 and
Rs.13000-18250 in the
respective discipline of
Finance Deptt. in a Major
Port Trust will be eligible.
For deputation, Officers
holding analogous posts é
lor holding posts of
Dy. Chief Accounts Officer
land equivalent posts in
respective discipline of
Finance Deptt. in the scale
lof pay of Rs.13000-18250
jin Govt./Semi Govt./PSUs
jor Autonomous Bodies
with 3 years regular
service in the grade will
be eligible. The sclection is
by merit for which the
bench mark in overall हे
* ~ Ierading in the ACRs will
inot be below "Very Good"

<!-- page 5 -->

डर ANNEXURE II 1
Certificate to be given by Head of Department of
Shri/Smt. |
Designation.
1. It is certified that the particulars furnished by the officer are correct.
2; It is certified that no disciplinary/vigilance case is pending or contemplated
against the applicant and he/she is clear from Vigilance and Administrative
angle.
3. His/Her integrity is certified.
4. It is certified that no major/minor penalties have been imposed on the applicant
during the last 10 years. If any, kindly indicate details thereof.
o 5. Attested copies of ACRs for the last five years (1.4.2015 to 31.3.2020) are
enclosed.
6. It is certified that the incumbent meets the requisite eligibility criteria w.r.t.
educational qualification and experience as specified in the Annexure I of the
circular for absorption through composite method.
SIGNATURE OF THE
HEAD OF DEPARTMENT WITH SEAL
७
|

<!-- page 6 -->

e |
a j mg ee Anhexrene™ >कू २६००६ हक
4 ce EE ae ०० Annexes
/ ह ह Date:
ह 3. Nameoftheapplicant :
2 Deptt PRA/eo.
3. Designation & Class .
i 4. Revised pay sealetRs) oo
he @ 5. ‘Whether Annual Property Return (ARH).
. (कक हि asian ip vent ह
। 6. Date-of submission of APR é
| कक record. IFanyy. ie idan : Savi,
9. Tfyes, give details/ status thereof 5 है
Pi 10. Whether under tenancy of punishment हा Res भर. है
| * meray hepte द
| ent ae : YesfNa.
ch |
| WeRemaiacfighaceDep 0ए29 |
1S Ripheneecienrane 2 Accontedy Phat Aceonded
i i Not Accord
' . |
i . Gignatureot cvop py.tvoy
it - ४
