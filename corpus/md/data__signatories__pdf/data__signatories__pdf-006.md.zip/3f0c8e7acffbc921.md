---
doc_id: "3f0c8e7acffbc921"
source_url: "http://www.moef.gov.in/uploads/2017/06/ngt08.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "S.O. 565 (E) – [31/01/2019]: न्यायमूर्ति श्री के रामकृष्णन की नियुक्ति केरल उच्च न्यायालय के पूर्व न्यायाधीश, एनजीटी के न्यायिक सदस्य के रूप में।"
date: "2017-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "60b83ede58c97f40"
---

<!-- page 1 -->

Titi-r.t #0 to Wio 33004/99

REGD. NO. D. L-33004/99

ttmv
413144
QA/-4c Ocrette of ,ainctia
a-mT4R-cri.
EXTRAORDINARY
1417 11—igu5 33q-isiu4

PART 11—Section 3—Sub-section (ii)
TifflWT uchirm
PUBLISHED BY AUTHORITY

rqmil,

452]

7-i'dft 31, 2019/TRET 11, 1940

NEW DEI,111, THURSDAY, JANUARY 31, 2019/MAGIIA 11, 1940

No. -1521

tigicivii, 49' 3iIK Acict lactck 44.141
trl I
9±(. tc". 1, 31 Arviii, 2019
,
r,
6iftTTur arR/ft7g, 2010 (2010 Tr 19) ft vr-r 7 7; "TP-T
Wr.w. 5650).-4o1N
,fr 47.
(1) 4P- T-71.-s TT (3) 7,FT Irt ffirrirtif
5:TPT 6 fr
'41'1

:
7777-{

fr

,-15:4V,
,L1 -‘4.1

wiT

77 `4-j.1'
711:1 114 ;1

771-411-9T .IT
71- :ir141;1

nil 19

2018 Ni1,1)

tfil 74 fr

.
tr, .7TtiT
. v.1.1

TT; .79-14

4;

74T T*T
.
.-J-11

P1'4,-1,

[Tr.#. 17(42)/2016-' J-1/11,-1.4ii (JA

ID]

At-474-1,1W ,f,1'
MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANCE
NOTIFICATION
New Delhi, the 31st January, 2019
S.O. 565(E). In exercise of die powers conferred by sub-sections (1) and (3) of section 6. read with section 7
of the National Green Tribunal Act. 2010 (19 of 2010), the Central Government hereby appoints Justice
Shri K. Ramakrislman, former Judge of High Court of Kerala as ilie Judicial Member of the National Green Tribunal
with effect from the 19'h November_ 2018 (forenoon) for a period of five years or till he attains die age of sixty-seven
years or till further orders, whichever is earlier.
11'.No. 17(42 )12016-PIINGT (Vol.11)1

YASHVIR SINGH. Economic Advisor
•

Uploaded by Die. of Printing at Government of India Press. Ring Road. Martpuri. New Delhi-110064
and Published by the Controller ()I' Publications. Delhi-110054.
Digitally signed by
MANOJ
41ANO.1 KUMAR ViliVA
D55

(;1/2010

' "1""?
KUMAR VERMA Date
13:31:13 +OS 30'
