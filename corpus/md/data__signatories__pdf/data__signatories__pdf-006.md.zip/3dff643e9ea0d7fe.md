---
doc_id: "3dff643e9ea0d7fe"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/3e925efca147a71831751622b56aa19b.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code '10505' to National e-Governance Division NeGD"
date: "2024-08-27"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b03f7f1f91d2c1f0"
---

<!-- page 1 -->

|
Government of India
Ministry of Communications
Departinent of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi- 110001
(Access Services Wing)
No. 16-10 2018-AS-IV/ShortCodes 74g Dated: 27.08.2024
To,
All Access Service Providers.
Subject: - Allocation of short code for DigiLocker helpline
The undersigned is directed to convey the allocation of short code ‘10505’ to National e-
Governance Division (NeGD) for Digilocker Helpline, with the following features: -
(i) Category-I: Service (i.e. mandatory service to be provided by all the Access service
providers.
(ii) Accessibility: Un-restricted (to be accessible across India).
(iii) Metered service: Called Party Pays.
(iv) Terminating/Mapping number: 1800 889 6511
(v) Details and contact number of Nodal person: Amit Kumar, Deputy General Manager,
Mobile : 7781014264, 9471120137
2 All are requested to take necessary action.
3. This is issued with the approval of DDG (AS). wax. 7
ay\e
(Trilok Chandra)
Director (AS-III)
Ph 011-23372063
Copy forwarded for information and necessary action, if any, to:

(i) Secretary, TRAI.

(ii) CMD MTNL/ BSNL.

(ii)Shri J.L Gupta, Director, National e-Governance Division (NeGD), 4" Floor,
Electronics Niketan, 6 CGO Complex, Lodhi Road, New Delhi - 03. The nodal officer
may contact Spl. DG Telecom/Addl DG Telcom of respective LSA unit, for concerned
states/UTs,

(iv)Director (T), DGT Hq (respective LSA field may be asked to coordinate with
respective Nodal officers and TSPs for implementation of helpline, as and when
approached)

(v) A copy for upload on DoT Website
