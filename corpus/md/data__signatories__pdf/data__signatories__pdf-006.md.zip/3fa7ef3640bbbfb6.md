---
doc_id: "3fa7ef3640bbbfb6"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/1cbb6085bdcc0fa5e38549131a973044.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "CPIO & FAA ORDER dated 19.06.2014"
date: "2014-06-19"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b401fbb37652d6d9"
---

<!-- page 1 -->

Ll _-
——— =
i 7
ay F.No.A-60011/28/2010-Admn.I (LA)
Government of India
j Ministry of Law and Justice
i} Department of Legal Affairs
7 hee
Shastri Bhawan, New Dell
yo : Dated the 19%June, 2004
OFFICE ORDER NO. 64 /2014
In supersession of this Department’s earlier orders on the subject, the competer
authority, in pursuance of the provisions contained in Section 5(1) and (2) of the Right t
Information Act, 2005, designates the following officers of this Department as Appellat
Authorities, Central Public Information Officers (CPIO) and Central Assistant Publi
Information Officers (CAPIO) in the various units under Department of Legal Affairs.
Sl. No, Name of the Office | Appellate CPIO CAPIO
Authorit
1. Main Secretariat Dr.(Smt) Gita | Sh. K. Ginkhan | Smt. Asha
Rawat, Thang, DS Sota, US
JS&LA
2. Litigation Dr.(Smt) Gita | Sh. P.K. Behera, | Smt. Savita
Section(High Court) | Rawat, DLA Singal,
and CAT Cell JS&LA Suptd.(L)
3. Litigation Dr.(Smt) Gita |‘Sh. P.K. Behera, |-Sh- -Jiwan}— दा
a Section(Lower Rawat, DLA Ram,
Court) JS&LA Suptd.(L)
, 4. हु Central Agency | Smt. Sh. B.K. Prasad, | Sh. 09.8.
Section Sushma Addl. G.A. Makker,
Suri, Sr. Assistant
Govt. Govt.
Advocate Advocate
é 5. Branch Secretariat, | Sh. H.P. | Sh. Niraj Kumar, | Sh. NLA.
Mumbai Chaturvedi, | Assistant Legal | Pande,
JS&LA Adviser Suptd.(L)
Branch Secretariat, | Sh. 8.8. | 89. Amar Nath | Sh.
Kolkata Sarker, Sr. Pujari, ALA Panchadip
Govt. Chaduri, SO
Advocate
Ts. Branch Secretariat, Sh. G.S. | Smt. रे. Jaya- | Sh. B. Nand
Chennai Yadav, Jakhshmi, Kumar,
1 Additional Assistant Legal Suptd.(L)
HG 7 “* | Legal Adviser | Adviser हु
Branch Secretariat, | Sh. G.S. | Sh. R. Ganesh | Sh. R.
Bangalore | Yadav, Voltair, ALA Rajgopal, SO
Additional
‘ Legal Adviser
'
(et, ine
, (Ravindra Kumar)
4 Deputy Secretary fo the Govt. of India
‘

<!-- page 2 -->

. | ee
oe “7 a
री कप ५ W-2=- nn
el
bigs tse
aay "\ ‘\. All Officers concerned.
E ae 2. PS to Hon’ble MLJ/PPS to LS/PPSs to Additional Secretaries /JS&LAs.
co 3. All Officers & Sections in the Department of Legal Affairs at Main Secretariat/CAS/Branch
ee Secretariats.
का ५ 4. NIC Cell.It is requested that this office order may please be uploaded on the website of the
Department. 7
5. Sh. N.S. Aswal, Assistant Director (OL) with a request to provide hindi translation of the
aforesaid order and also get hoisted the said order on the website of this Department.
c e
\
‘ . ५
