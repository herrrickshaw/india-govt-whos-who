---
doc_id: "3e6ef6d1adecca22"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/60ddae5078c1ce37688ee4da4866a8f3.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "23 2017_10_23 Prevention of Mobile Tempering"
date: "2017-10-23"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "de337cfcee219cde"
---

<!-- page 1 -->

REGD. NO. D. L.-33004/99

jftLVªh laö Mhö ,yö&33004@99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)

izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 730]
No. 730]

ubZ fnYyh] lkseokj] vxLr 28] 2017@Hkkæ 6] 1939
NEW DELHI, MONDAY, AUGUST 28, 2017/BHADRA 6, 1939

संचार मं ालय
(दूरसंचार िवभाग)

अिधसूचना
नई िदल्ली, 25 अगस्त, 2017
सा.का.िन. 1068(अ).—के न् ीय सरकार, भारतीय तार अिधिनयम, 1885 (1885 का 13) की धारा 25 के साथ
पिठत धारा 7 की उपधारा (2) के खण्ड (ट) ारा द शि य का योग करते हुए मोबाइल युिक्त उपस्कर पहचान संख्या
म छेड़छाड़ करने को रोकने के िलए िन िलिखत िनयम बनाती है, अथार्त्ः
1. संिक्ष नाम और ारं भः—
(1) इन िनयम का संिक्ष नाम मोबाइल युिक्त उपस्कर पहचान संख्या म छेड़छाड़ का रोका जाना िनयम 2017
है।
(2) ये राजप म काशन की तारीख को वृ ह गे।
2. पिरभाषा.—इन िनयम म, जब तक िक संदभर् से अन्यथा अपेिक्षत न हो,(क) िविनमार्ता से ऐसा

ि

अिभ ेत है िजसने मोबाइल युिक्त के

ारिम्भक िव य से पूवर् िकसी मोबाइल युिक्त

की कोई मोबाइल युिक्त उपस्कर पहचान संख्या िनधार्िरत करने का अिधकार िविधपूवर्क अिभ ाप्त िकया है;
(ख) मोबाइल युिक्त उपस्कर पहचान संख्या से -

(i) कोई िविशष्ट अंतरार् ीय मोबाइल उपस्कर पहचान संख्या (आईएमईआई); या
(ii) कोई िविशष्ट इलैक् ािनक म संख्या (ईएसएन); या
(iii) कोई अन्य िविशष्ट संख्या या िसगनलअिभ ेत है, जो एक िविश मोबाइल बेतार संचार युिक्त की पहचान करती है; या उक्त योजन के
िलए वैसे ही कृ त्य और योजन ह जैसे ऊपर िविन दर्ष्ट है।
5316 GI/2017

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

3. मोबाइल युिक्त उपस्कर पहचान संख्या म छेड़छाड़.—िविनमार्ता को छोड़कर यिद कोई व्यिक्त (i)

साशय मोबाइल युिक्त उपस्कर िविश पहचान संख्या को हटाता, िमटाता, पिरवतर्न करता है या उसम
कोई फे रबदल करता है; या

(ii)

यह जानते हुए िक उसे ऊपर िविन दर्ष्ट अनुसार समनुरूप बनाया गया है, साशय उपयोग करता है,
उत्पादन करता है, दुव्यार्पार करता है, उसके हाडर्वेयर या साफ्टवेयर को िनयं ण या अिभरक्षा म रखता है
या ा करता है, तो वह िविध िवरू

होगा।
[फा. सं. 19-37/2012/एस-II (पाटर्)]
अिमत यादव, संयुक्त सिचव ( शासन)

MINISTRY OF COMMUNICATIONS
(Department of Telecommunications)

NOTIFICATION
New Delhi, the 25th August, 2017
G.S.R. 1068(E).—In exercise of the powers conferred by clause (k) of sub- section (2) of section 7 read
with section 25 of the Indian Telegraph Act, 1885 (13 of 1885), the Central Government, hereby, make the
following rules to prevent the tampering of Mobile Device Equipment Identification Number, namely:
1. Short title and Commencement——
(1) These rules may be called the prevention of tampering of the Mobile Device Equipment
Identification Number, Rules, 2017.
(2) They shall come into force on the date of their publication in the official Gazette.
2. Definition.—In these rules, unless the context otherwise requires, (a) ‘Manufacturer’ means a person who has lawfully obtained the right to assign a Mobile Device
Equipment Identification Number to a mobile device before the initial sale of the mobile device;
(b) Mobile Device Equipment Identification Number’ means a unique –
(i) international mobile equipment identity number (IMEI); or
(ii) electronic serial number (ESN) ; or
(iii) any other number or signal –
that identifies a unique mobile wireless communication device; or for the purposes has
the same function and purposes as specified above.
3. Tampering of Mobile Device Equipment Identification Number.—It shall be unlawful, if a person,
except the manufacturer –
(i) intentionally removes, obliterates, change, or alter unique Mobile Device Equipment Identification
Number; or
(ii) intentionally use, produce, traffic in, have control or custody of, or possess hardware or software,
knowing it has been configured as specified above.
[F. No. 19-37/2012/S-II (Pt.)]
AMIT YADAV, Jt. Secy. (Admin.)

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed by RAKESH

RAKESH SUKUL SUKUL
Date: 2017.08.29 22:28:58 +05'30'
