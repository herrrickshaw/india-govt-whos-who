---
doc_id: "3cdda58d07e7daac"
source_url: "https://mines.gov.in/admin/download/68131f7eed1c81746083710.pdf"
ministry: "Mines (MoM)"
title: "Comments suggestions on the draft Offshore Areas Mineral Prevention of Illegal Mining and Transportation and Storage Rules 2025 (966.62 KB)"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c46238cdb543d41e"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

MINISTRY OF MINES NOTIFICATION
New Delhi, the [*]th [*], 2025
G.S.R. [*] (E)- In exercise of the powers conferred by clause (pa) of sub-section (2) of section 35 of the
Offshore Areas Mineral (Development and Regulation) Act, 2002 (17 of 2003), the Central Government
hereby makes the following rules, namely:
CHAPTER I
PRELIMINARY
1.

Short Title and Commencement.–
(1)

These rules may be called the Offshore Areas Mineral (Prevention of Illegal Mining
and Transportation) Rules, 2025.

(2)

These rules shall come into force on the date of their publication in the Official Gazette.

2.

Applicability.– These rules shall apply to all minerals in the offshore areas, except mineral oils
and hydrocarbons described in sub-section (1) of section 3;

3.

Definitions.–
(1)

In these rules, unless the context otherwise requires,–
(a)

“Act” means the Offshore Areas Mineral (Development and Regulation) Act,
2002 (17 of 2003);

(b)

“authorised officer” shall have the meaning assigned to it under explanation to
sub-section (7) of section 22;

(c)

“bank guarantee” means a bank guarantee to be issued in Form-A by any
nationalised bank in India acceptable to the Central Government;

(d)

“carrier” means any mode of conveyance or facility by which a mineral is
transported from one place to another and includes a vessel and pipeline;

(e)

“consignee” means the person to whom any mineral or mineral ore from the
licence area or lease area is dispatched to;

(f)

“electronic monitoring system” means an electronic system, as specified by the
Indian Bureau of Mines, which shall be capable of automatically recording,
storing, processing, retrieving, communicating or verifying information, data,
documents relating to operations in offshore areas, continuously, on a real-time
basis, including but not limited to:-

(g)

(i)

tracking of vessels;

(ii)

displacement or weight of vessel;

(iii)

volume and density of run-of-mine; and

(iv)

recording of images and video feed.

“first point of discharge” means the first onshore unloading location in India
where the mineral or mineral ore extracted from the offshore areas is brought
in by the holder of the operating right or an owner of a carrier or a trader, as
the case may be;

1

<!-- page 4 -->

(h)

“Form” means the forms appended to these rules;

(i)

“illegal mining” means any reconnaissance operation or exploration operation
or production operation undertaken by any person or company in any offshore
area without holding an operating right as required under sub-section (1) of
section 5 or, outside the boundaries of the offshore area for which the operating
right has been granted
Provided that violation of any rules, other than these rules, within the licence
area or lease area, by a licensee or a lessee shall not be construed as illegal
mining.

(2)
4.

(j)

“illegal storage” means the storage of any mineral otherwise than in
accordance with the provisions of the Act or the rules made thereunder;

(k)

“illegal transportation” means the removal, shifting, transfer or transport of any
mineral by any holder of an operating right or trader or carrier otherwise than
in accordance with the provisions of the Act or the rules made thereunder;

(l)

“mechanised machinery” means and includes each and every machinery or
platform, both immovable and movable, used in the winning of a mineral from
the licence area or lease area, or beneficiation and its processing, run on
electricity or otherwise and whether owned or operated by the holder of an
operating right or any other person but excludes a carrier;

(m)

“transit permit” shall have the meaning assigned to it in sub-rule (2) of rule 8;
and

(n)

“property” means tools, gear, equipment, appliance, carrier, vehicle,
installation, stores or cargo or any other thing used by any person to extract,
transport or cause to be extracted or transported any mineral or mineral ore
from any offshore area;

(o)

“Schedule” means a schedule appended to these rules;

(p)

“section” means Section of the Act;

(q)

“trader” means any person who carries on the business of buying, possessing,
storing, selling, supplying, transporting, distributing, delivering, exporting or
importing for sale or processing of mineral, directly or otherwise for cash or
for deferred payment or for commission, remuneration or other valuable
consideration, and includes a person who:
(i)

uses mineral and its ingredients as a raw material;

(ii)

has a mineral sharing agreement with the holder of an operating right;

(iii)

has an extraction contract with the holder of an operating right;

(iv)

buys and processes mineral for sale; or

(v)

holds an operating right.

The words and expressions used in these rules but not defined herein shall have the
same meaning as assigned to them in the Act or rules made thereunder.

Powers and functions of Atomic Minerals Directorate for Exploration and Research.–
Throughout these rules, wherever any power, function or responsibility of the Indian Bureau of

2

<!-- page 5 -->

Mines or its officers is specified or any information is to be submitted to the Indian Bureau of
Mines or its officers, the same shall be deemed as power, function or responsibility of the
Atomic Minerals Directorate for Exploration and Research or its officers or requirement of
submission of information to the said Directorate or its officers for minerals having grade equal
to or greater than the threshold value in respect of atomic minerals, in the following manner,
namely:-

5.

(a)

any reference to the Indian Bureau of Mines, to be deemed as reference to the Atomic
Minerals Directorate for Exploration and Research;

(b)

any reference to the Controller General or the Chief Controller of Mines or the
Controller of Mines or the Regional Controller or the authorised officer of the Indian
Bureau of Mines, to be deemed as reference to the Director or as the case may be, the
authorised officer of Atomic Minerals Directorate for Exploration and Research.

Prohibitions.– No person shall carry on production operations, excavation, storage, sale,
transportation, or processing of minerals at any place for the purpose of sale or consumption or
otherwise deal with any mineral, except under and in accordance with the Act and the rules
made thereunder.
CHAPTER II
ELECTRONIC SYSTEM

6.

7.

Establishment of an electronic monitoring system.–
(1)

The holder of an operating right or an owner of a carrier, as the case may be, shall
deploy an electronic monitoring system provided that such electronic monitoring
system shall at all times be in compliance specification issued by the Indian Bureau of
Mines.

(2)

Any person or company who is an owner of a carrier(s), a mine developer and operator
(by whatever name called) in respect of a mine, owner of a mechanised machinery and
such other person as may be specified by the Indian Bureau of Mines shall cause
himself and such carrier and mechanized machinery to be registered online on the
offshore mining regulation web portal.

(3)

No mechanised machinery or carrier shall be used by the holder of an operating right
unless the owner of such mechanised machinery or carrier is validly registered with the
Indian Bureau of Mines in accordance with the requirements of sub-rule (2).

No objection certificate to be obtained by a holder of an operating right or trader for
export of mineral or mineral ore.- Every holder of an operating right or trader who is desirous
of exporting mineral or mineral ore extracted from offshore areas, directly from such offshore
area, shall procure a clearance from the Central Board of Indirect Taxes and Customs, if
applicable, fifteen days prior to exporting such mineral or mineral ore.
CHAPTER III
DISPATCH AND TRANSPORATION OF MINERALS

8.

Dispatch of minerals outside the licence area or lease area.–

3

<!-- page 6 -->

(1)

A holder of an operating right shall, prior to dispatch of any mineral or mineral ore
outside the licence area or lease area, provide the following information on the offshore
mining regulation web portal:
(a)

quantity and grade of mineral or mineral ore dispatched;

(b)

name, address and registration number of the consignee;

(c)

particulars of the carrier carrying the minerals;

(d)

the first point of discharge, expected route for transportation and the particulars
of the route to the first point of discharge and to the destination;

(e)

if the holder of the operating right has availed services of any other person for
transportation, then particulars of the owner of the carrier along with the details
of the carrier including the registration number;

(f)

particulars of royalty and other payments made with respect to such minerals;

(g)

in case of export of the mineral to an overseas consignee, a copy of the
documents along with a copy of the clearance obtained by the holder of an
operating right under rule 7 submitted with the Central Board of Indirect Taxes
and Customs with respect to such export; and

(h)

such other particulars as may be specified by the Indian Bureau of Mines:

Provided that if the holder of an operating right has engaged the services of a mine
developer and operator, by whatever name called, such information may be furnished
by the mine developer and operator. In such case, the mine developer and operator and
the holder of an operating right shall be jointly and severally responsible with respect
to entry and accuracy of the information so furnished.
(2)

Upon due and proper entry of information under sub-rule (1), the holder of an operating
right shall obtain a digitally signed transit permit for lawful transportation of minerals
by way of a registered carrier, from the licence area or lease area, which shall be in the
format specified in Form-B and shall be generated or downloaded, as the case may be,
by the holder of an operating right from the offshore mining regulation web portal.

(3)

The transit permit shall be available for generation or download, as the case may be,
upon furnishment of requisite details, as specified in these rules and by the Indian
Bureau of Mines from time to time, from the offshore mining regulation web portal.

(4)

The Indian Bureau of Mines may, for the reasons to be recorded in writing, suspend
issuance of transit permit as contemplated under sub-rule (2) and sub-rule (3), to the
holder of an operating right, as the case may be, in case:(a)

any dues or penalties have been levied by the authorised officer on such holder
and such dues are outstanding; or

(b)

uses an unregistered carrier;

The Indian Bureau of Mines may revoke the suspension contemplated under sub-rule
4 in case the holder of the operating right rectifies the violations pointed out under
clause (a) and (b) of sub-rule 4, as the case may be.

4

<!-- page 7 -->

9.

(5)

The transit permit shall be specific to each carrier carrying the minerals and at all times
during transit, a digitally signed or authorised copy of the transit permit shall be
retained.

(6)

The holder of an operating right shall ensure that it installs such equipment as may be
necessary to comply with these rules, including equipment to enter relevant information
in the electronic monitoring system, as required in each carrier.

First point of discharge.(1)

The holder of operating right or the owner of the carrier or trader, as the case may be,
shall ensure that adequate weighment system, including each and every electronic
system, mechanical system or technological device or implement utilised in
measurement or weighment of minerals or mineral ores, at the first point of discharge
is installed and maintained in the manner specified by the Indian Bureau of Mines from
time to time;

(2)

The weight of the mineral or mineral ores measured at the first point of discharge shall
be measured against the weight of the mineral or mineral ores at the time of dispatch
from the lease area.

(3)

Any weighment of mineral or mineral ore shall be converted on a dry basis by
application of a conversion factor, as specified by Indian Bureau of Mines based on
scientific study.

(4)

The holder of operating right or the owner of the carrier or trader, as the case may be,
shall allow officers authorised by the Indian Bureau of Mines to inspect the weighment
system installed at the first point of discharge.

10.

Obligations of the consignee.– The consignee, after receipt of the mineral or mineral ore shall
verify the quantity and grade of such mineral or mineral ore received against the details
specified in the transit permit and shall keep the receipt in respect of the minerals received and
maintain records thereof.

11.

Obligations of the owner and operator of a carrier.–
(1)

Every owner and operator of a carrier carrying mineral or mineral ore shall carry:
(a)

a duly working device capable of automatic location tracking and reporting,
which shall be a part of the electronic monitoring system; and

(b)

a valid transit permit.

The carrier shall follow the transportation route specified pursuant to clause (d) of subrule (1) of rule 8.
(2)

The Indian Bureau of Mines may also impose additional conditions as it may deem
necessary with respect to carriage of minerals.

12.

Storage of mineral.– No person shall store minerals and mineral ores extracted or procured
from offshore areas otherwise than in accordance with applicable laws of the State in which the
storage facility will be located.

13.

Obligation to provide details to the Indian Bureau of Mines. – The Indian Bureau of Mines,
may, as and when it deems fit, direct:-

5

<!-- page 8 -->

(a)

An owner or operator of a carrier or a trader carrying mineral or mineral ores to provide
and disclose information, including information regarding the quantity, quality, end
destination, details of the carrier or trader or person on whose behalf mineral or mineral
ores has been dispatched and related price information.

(b)

A consignee who receives minerals and minerals ores dispatched from the licence area
or lease area shall provide and disclose, including information regarding the quantity,
quality, location of storage and related price information.
CHAPTER IV
INSPECTION, CONFISCATION AND RELEASE

14.

Inspection and verification by authorised officer(s).- The authorised officer shall have the
power to inspect, verify, check and draw samples of the stocks of mineral or mineral ores of
any holder of operating right or trader, at any place including in transit and accounts of mineral
and mineral ores and any other documents pertaining thereto.

15.

Seizure of property liable to confiscation.–
(1)

(2)

16.

Every authorised officer, exercising powers of seizure and detention under sub-section
(3) of section 22 shall:(a)

photograph the carrier, mine or any other property and place on such carrier,
mine or any other property a mark in such manner as may be determined,
indicating that the same has been so seized and detained;

(b)

issue a notice in the format specified in Form-C informing the person from
whom the carrier, mine or any other property is seized and detained;

A carrier, mine or any other property ordered to be released in accordance with the
proviso to clause (a) of sub-section (5) of section 22, may be so released upon
furnishing security in the form of cash or a bank guarantee in the format specified in
Form-A;

Depositing the sums.–
All sums collected by compounding the offences shall be deposited with the Central
Government in the Consolidated Fund of India.

17.

Disposal of minerals including processed minerals by public auction in certain cases.–
It shall be lawful for an authorised officer to sell in a fair and transparent manner, by public
auction, any mineral seized and confiscated in accordance with the provisions of these rules
and the proceeds of such sale shall be deposited with the Central Government in the
Consolidated Fund of India.

18.

Authorities to aid in enforcement of these rules.- The administering authority, the Indian
Bureau of Mines and any authorised officer shall be aided by the Indian Navy, Indian Coast
Guard, the police force of the relevant State Government or any other government authority in
administering, implementation and enforcement of these rules.
CHAPTER V
APPEAL AND PENALTIES

6

<!-- page 9 -->

19.

Appeal.– Any person aggrieved by an order issued by any authorised officer under these rules
may, within three months of date of communication of such order to him, prefer an appeal to
the Central Government in accordance with the provisions of Chapter X of the Offshore Areas
Operating Right Rules, 2024 or the rules made under clause (c) of sub-section (2) of section 35
of the Act as the case may be:

20.

Penalties and recovery.–

21.

(1)

Any contravention of these rules except for such contraventions which are not covered
as offence under sub-section (1) to sub-section (3) of Section 23 of the Act shall be
punishable with imprisonment for a term which may extend to five years or with fine
of fifty lakh rupees, which may extend to one crore rupees, or with both, and in the case
of a continuing contravention, with additional fine which may extend to five lakh
rupees for every day during which such contravention continues after conviction for
the first such contravention.

(2)

Whenever any person, in any manner whatsoever, engages in illegal mining, illegal
transportation or illegal storage of any mineral or mineral ore and for that purpose uses
any tool, equipment, carrier or any other thing, the authorised officer may, in addition
to the penalties prescribed under sub-rule (1) above and subject to the provisions of this
rule thereof:

(a)

may recommend to the Central Government, cancellation of the composite licence or
production lease or registration of such person in respect of its operating right, carrier,
mechanised machinery or of such trader or mine developer and operator as may be
granted pursuant to sub-rule (2) of rule 6 thereof

(b)

seize such tool, equipment, carrier or any other thing employed by such person in
extracting, transporting or storing of minerals.

Maintenance of records.–
The authorised officer shall collate, compile and maintain a consolidated record in the format
specified in Form-D and shall mention therein, the details of every offence committed under
these rules.
CHAPTER VI
MISCELLANEOUS

22.

Non-applicability of the rules in certain cases.–
Nothing containing in these rules shall apply to:

23.

(a)

any persons or class of persons who the Central Government may, by an order, specify;
provided the mineral is stored, mined or carried only for the purpose of scientific test
and research work without any commercial motive or purpose;

(b)

institutions, agencies as specified or notified under proviso to sub-section (1) of section
5 or departments exempted under the Act.

Power to rectify apparent mistakes.Any clerical or arithmetical mistake in any order passed by the Central Government or
administering authority or by any other authority or officer under these rules and any error

7

<!-- page 10 -->

arising therein from an accidental slip or omission may, within two years from the date of the
order, be corrected by such Government, authority or officer, as the case may be:
Provided that no order prejudicial to any person shall be passed unless he has been given a
reasonable opportunity to present his case.

8

<!-- page 11 -->

FORM-A
FORMAT OF BANK GUARANTEE
(See rules 3(1)(c) and 15(2))
To
[Name of entity in whose favor this guarantee is to be issued to be included]
WHEREAS,
A.

[Name of the person whose property is seized] incorporated in India under the Companies Act,
2013 with corporate identity number [CIN], whose registered office is at (address of registered
office), India and principal place of business is at [address of principal place of business, if
different from registered office]1 is required to provide an unconditional and irrevocable bank
guarantee for an amount equal to INR [figures] (Indian Rupees [words]) valid until [date of
expiry of bank guarantee] ("Expiry Date").

B.

The Bank Guarantee is required to be provided to [Name of entity in whose favor this guarantee
is to be issued to be included] for discharge of certain obligations under Rule 15 of the Offshore
Areas Mineral (Prevention of Illegal Mining and Transportation) Rules, 2025 ("Rules").

C.

We, [name of the bank] (the "Bank") at the request of [Name of the person whose property is
seized] do hereby undertake to pay to the [Name of entity in whose favor this guarantee is to
be issued to be included] an amount not exceeding INR [figures] (Indian Rupees [words])
("Guarantee Amount") to secure the obligations of [Name of the person whose property is
seized] on demand from the [Name of entity in whose favor this guarantee is to be issued to be
included] on the terms and conditions herein contained herein.

NOW THEREFORE, the Bank hereby issues in favour of (Name of entity in whose favor this guarantee
is to be issued to be included) this irrevocable and unconditional payment bank guarantee (the
"Guarantee") on behalf of [Name of the person whose property is seized] for the Guarantee Amount:
1.

The Bank for the purpose hereof unconditionally and irrevocably undertakes to pay to [Name
of entity in whose favor this guarantee is to be issued to be included] without any demur,
reservation, caveat, protest or recourse, immediately on receipt of first written demand from
[Name of entity in whose favor this guarantee is to be issued to be included], a sum or sums
(by way of one or more claims) not exceeding the Guarantee Amount in the aggregate without
[Name of entity in whose favor this guarantee is to be issued to be included] needing to prove
or to show to the Bank grounds or reasons for such demand for the sum specified therein and
notwithstanding any dispute or difference between [Name of entity in whose favor this
guarantee is to be issued to be included] and [Name of the person whose property is seized] on
any matter whatsoever. The Bank undertakes to pay to [Name of entity in whose favor this
guarantee is to be issued to be included] any money so demanded not withstanding any dispute
or disputes raised by [Name of the person whose property is seized] in any suit or proceeding
pending before any court or tribunal relating thereto the Bank's liability under this present being
absolute and unequivocal.

2.

The Bank acknowledges that any such demand by [Name of entity in whose favor this guarantee
is to be issued to be included] of the amounts payable by the Bank to [Name of entity in whose

1

Note : Suitable changes to be made to the above text in the event the guarantee is provided for any other category
of persons

9

<!-- page 12 -->

favor this guarantee is to be issued to be included] shall be final, binding and conclusive
evidence in respect of the amounts payable by [Name of the person whose property is seized]
to [Name of entity in whose favor this guarantee is to be issued to be included] under the Rules.
3.

The Bank hereby waives the necessity for [Name of entity in whose favor this guarantee is to
be issued to be included] from demanding the aforesaid amount or any part thereof from [Name
of the person whose property is seized] and also waives any right that the Bank may have of
first requiring [Name of entity in whose favor this guarantee is to be issued to be included] to
pursue its legal remedies against [Name of the person whose property is seized], before
presenting any written demand to the Bank for payment under this Guarantee.

4.

The Bank further unconditionally agrees with [Name of entity in whose favor this guarantee is
to be issued to be included] that [Name of entity in whose favor this guarantee is to be issued
to be included] shall be at liberty, without the Bank's consent and without affecting in any
manner the Bank's obligation under this Guarantee, from time to time, to forbear or enforce any
of the rights exercisable by [Name of entity in whose favor this guarantee is to be issued to be
included] against [Name of the person whose property is seized] under the Rules and the Bank
shall not be relieved from its liability by reason of any such act or omission on the part of [Name
of entity in whose favor this guarantee is to be issued to be included] or any indulgence by
[Name of entity in whose favor this guarantee is to be issued to be included] to [Name of the
person whose property is seized] or other thing whatsoever which under the law relating to sure
ties would, but for this provision, have the effect of relieving the Bank of its obligations under
this Guarantee.

5.

Any payment made hereunder shall be made free and clear of and without deduction for, or on
account of, any present or future taxes, levies, imposts, duties, charges, fees, commissions,
deductions or withholdings of any nature whatsoever.

6.

The Bank agrees that [Name of entity in whose favor this guarantee is to be issued to be
included], at its option, shall be entitled to enforce this Guarantee against the Bank as a principal
debtor in the first instance without proceeding at the first instance against [Name of the person
whose property is seized].

7.

The Bank further agrees that the Guarantee herein contained shall remain in full force and effect
during the period that is specified in the Rules and that it shall continue to be enforceable till
all the obligations of [Name of the person whose property is seized] under or by virtue of the
Rules with respect to rule 15 of the Rules have been fully paid and its claims satisfied or
discharged or till [Name of entity in whose favor this guarantee is to be issued to be included]
certifies that the provisions of the Rules with respect to rule 15 of the Rules have been fully and
properly carried out by [Name of the person whose property is seized] and accordingly,
discharges this Guarantee. Notwithstanding anything contained herein, unless a demand or
claim under this Guarantee is made on the Bank in writing on or before the Expiry Date, the
Bank shall be discharged from all liability under this Guarantee thereafter.

8.

The payment so made by the Bank under this Guarantee shall be a valid discharge of Bank's
liability for payment thereunder and no person shall have any claim against the Bank for making
such payment.

9.

This Guarantee is subject to the laws of India. Any suit, action, or other proceedings arising out
of this Guarantee or the subject matter hereof shall be subject to the exclusive jurisdiction of
courts at New Delhi, India.

10

<!-- page 13 -->

10.

The Bank represents that it has the authority and power to issue this Guarantee in favour of
[Name of entity in whose favor this guarantee is to be issued to be included]. This Guarantee
will not be discharged due to the change in the constitution of the Bank.

11.

The Bank undertakes not to revoke this Guarantee during its currency except with the previous
consent of [Name of entity in whose favor this guarantee is to be issued to be included] in
writing.

12.

[Name of entity in whose favor this guarantee is to be issued to be included] may, with prior
intimation to the Bank, assign the right under this Guarantee to any other departments,
ministries or any governmental agencies, which may act in the name of the [Name of entity in
whose favor this guarantee is to be issued to be included]. Save as provided in this clause 12,
this Guarantee shall not be assignable or transferable.

13.

Notwithstanding anything contained herein:

14.

(a)

the liability of the Bank under this Guarantee shall not exceed the Guarantee Amount;
and

(b)

this Guarantee shall be valid up to the Expiry Date.

The Bank is liable to pay the Guaranteed Amount or any part thereof under this Guarantee only
and only if [Name of entity in whose favor this guarantee is to be issued to be included] serves
upon the Bank, a written claim or demand on or before the Expiry Date.

Dated the [day] day of [month] [year] for the Bank.
In witness whereof the Bank, through its authorized officer, has set its hand and stamp.
(Signature)
(Name and Designation)
(Bank Stamp)

11

<!-- page 14 -->

FORM-B
FORMAT OF TRANSIT PERMIT
(See rules 8(2))
Sr.
No.

Item

Particulars

1

Operating Rights Holder / Mine Developer and Operator
Code

2

Operating Rights Holder / Mine Developer and Operator
Registration No.

3

Operating Rights Holder / Mine Developer and Operator
TIN No.

4

Name of Registered Operating Rights Holder / Mine
Developer and Operator

5

Address and Contact Details

6

Offshore Lease Area Details

7

Name of Mineral

8

Mineral Grade

9

Quantity of Mineral (in figure, in MT)

10

Quantity of Mineral (in words, in MT)

11

Royalty

12

OMET

13

Auction Premium

14

Other Payments (if applicable)

15

Vessel Details

16

Electronic Identification/Tracking Device

17

Destination Port / Onshore Facility / First point of
Discharge

18

Name of Purchaser

19

Purchaser Registration No.

20

Purchaser Address

21

Captain’s Name

22

Captain’s License No.

23

Journey Start Date

24

Expected Journey Route

12

<!-- page 15 -->

Sr.
No.

Item

Particulars

25

Journey End Date

26

Distance (in nautical miles and km)

27

Is mineral exported

28

If yes, customs documentation (e.g., shipping bill)
attached

29

Safety and Inspection Clearance Attached

30

Whether a clearance has been obtained from the Central
Board of Indirect Taxes and Customs in respect of export
of minerals, extracted from offshore areas, outside of
India

31

Generate Transit Permit

13

<!-- page 16 -->

FORM-C
FORM OF NOTICE REGARDING SEIZING OF CARRIER, MINE OR ANY OTHER
PROPERTY
(See rule 15(1)(b))
Dated [ ]
To
(Address)
Take notice that the following property(ies) which was/were involved in offence committed under the
Offshore Areas Mineral (Prevention of Illegal Mining and Transportation) Rules, 2025 on ............ (date)
has been seized and detained by Shri. ....................................... Designation.................. and kept under
the custody of the undersigned. The details of the property being seized are as under:
Sr. No.

Item Details

Particulars

l.

Details of carrier, mine or any other property seized.

a.

Place of seizure with date and time.

b.

Description of each carrier, mine or property.

2.

Name and address of person from whom the carrier, mine or property
is seized.

3.

Name and address of any other claimant for the seized carrier, mine or
property.

4.

Name and address of person under whose custody the seized carrier,
mine or property has been kept.

5.

ls the person whose property has been seized, registered with the [Indian (Yes/No)
Bureau of Mines/ offshore mining regulation web portal].

6.

If yes, then registration number of the person whose property is seized,
to be provided.

7.

Approximate value of the seized carrier, mine or property.

8.

Remarks.

In case you want to be heard in person in the matter, you are hereby asked to convey the same in writing
within 15 days from date of issue of this notice at the following address.
(

)

(

)

Signature of authorised Officer.

Signature of the Custodian.

with designation and address.

with designation and address.

14

<!-- page 17 -->

draft Offshore Areas Mineral (Prevention of Illegal Mining and Transportation) Rules, 2025
Strictly Privileged & Confidential

FORM-D
FORMAT FOR KEEPING RECORD OF OFFENCES
(See rule 21)
Sr. Complain
Date of
Name Type of offence
Brief
Propert
Place of
Officer Paymen No. and Signature of Remark
No
t No.
Commissio
of
(relating to
Descriptio
y
Occurrence Detectin
t for
Date of
Authority
s
.
n of
Accuse
Mining,
n of
Involved (Coordinate
g the
Offence Treasur Compoundin
Offence
d
Storage,
Offence
in
s or
Offence (in INR)
y
g the Offence
Transportation
Offence Description)
Challan
)
for
Payment

15
