---
doc_id: "3cede3588eacea5f"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/02d56e9671affadfd37c202fa74068a2.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Promotion cum Posting of Shri. V.K. Khare(27 Aug 2014)"
date: "2014-08-27"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c347b3d56ea99836"
---

<!-- page 1 -->

F. No. A-31011/04/2011-CLS.I
Government of India/Bharat Sarkar
Ministry of Labour & Employment/ Shram Evam Rozgar Mantralaya
Shram Shakti Bhawan, Rafi Marg,
New Delhi, the 2ih August, 2014

OFFICE ORDER NO 18/2014
Consequent to exoneration of the charge (s) framed against Shri Vishal Kumar
Khare, LEO(C), Hyderabad in the disciplinary case initiated by the Office of Chief Labour
Commissioner (Central), vide its Order No. 4(2)/2005- Vig. dated 05.02.2014 and
opening of Sealed Cover recommendations of the DPC held in the UPSC on 24.01.2013
wherein he was assessed as 'FIT' for promotion, the approval of the Competent
Authority is granted for the notional promotion of Shri Vishal Kumar Khare to Junior
Time Scale in the Pay Band-3, Corresponding Pay Scale Rs.15,600-39,100/- with Grade
Pay of Rs. 5400/- against the panel Year 2012-13. Sh. V. K. Khare will be placed at 51.
No. 2(B) below Shri Gautam Moitra (51. No. 2) and above Shri Ratan Lal saha (51. No. 3)
in the panel recommended by the DPC held in the UPSC from the date of promotion of
his junior i.e. 20.02.2013.
2.
The Competent Authority has also approved payment of arrears of pay and
allowances to Shri Vishal Kumar Khare for the period of notional promotion preceding
the date of actual promotion in terms of DOP&T's OM No. 22011/4/91-Estt.(A) dated
14/09/1992.
3.
Subsequent to his promotion in JTS Grade, Shri Vishal Kumar Khare, LEO(C),
Hyderabad is posted as Assistant Labour Welfare Commissioner (Central), Gun &
Carriage Factory, Jabalpur with immediate effect. The actual promotion will be
effective from the date of assumption of charge of the promotional post.
4.
Office of CLC(C), New Delhi and Office of Dy. CLC(C), Hyderabad are requested
to relieve the Officer to enable him to join his place of new posting, immediately. The
Officer is directed to submit his joining report to this Ministry through the respective
Organization of his posting, at the earliest. In case he does not join the promotional
post within a period of 30 days, it will be presumed that he is not interested in
availing of the promotion to JTS Grade and he will be debarred from promotion as
per the relevant Rules.

5.

This issues with the approval of the Competent Authority.

~

(S K Singh)
Under Secretary to the Govt. of India
Tel. No:011-23766903
Distribution:1.
2.
3.

Shri Vishal Kumar Khare, LEO(C), Hyderabad
PS to LEM/PS to MOS(L&E)/PSO to Secy (L&E)/CLC(C)/JS(AP)/DGLW.
Dir.(CR)/Dir.(BS)/DS(AF).
Page 1 of 2

<!-- page 2 -->

-2-

4.
5.
6.
7.

8.
9.

Adm.I/SE Section, 0/o-CLC(C), New Delhi.
Office of Dy. CLC(C), Hydrabad
CLS.II Section, Ministry of Labour & Employment.
The UPSC (Under Secretary-AP-r), Dholpur House, Shahjahan Road,
New Delhi -w.r.t. their letter No. F.1/27(11)/2012-AP.I dated 29.01.2013 &
F.1/27(2)/2014-AP.I dated 13.06.2014.
Personal File of the Officers concerned.
Office order bundle/spare copies.

Page 2 of2
