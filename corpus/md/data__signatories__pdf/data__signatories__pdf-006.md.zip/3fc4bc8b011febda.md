---
doc_id: "3fc4bc8b011febda"
source_url: "https://financialservices.gov.in/sites/default/files/order-notices/IRDAI%2520appointment%2520gazette_1.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "IRDAI%20appointment%20gazette_1.pdf"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "661ccd0775cd778d"
---

<!-- page 1 -->

[भाग II— ण्ड 3(ii)]

भारत का रािृत्र : मार्च 12, 2022/फाल्गुन 21, 1943

541

नई दिल्ली, 8 मार्च, 2022
का.आ. 254.—राष्ट्री कष त बैंक (प्रबंि एवं प्रकीर्च उृबंि) स्ट्कीम, 1970 के ृजरा 3 के उृ-ृजरा (1) के सा
ृठ त बैंककारी कं ृनी (उृक्रमों का अिचन एवं अंतरर्) अजिजन म, 1970 की िारा 9 की उृ-िारा (3) के ंड (ग)
द्वारा प्रित्त िजि ों का प्र ोग करते हुए, के न्री सरकार, एतद्द्वारा, नीर्े िी गई सारर्ी के कालम (3) में जवजनर्िचष्ट
व्यजि ों को उि सारर्ी के कालम (2) में जवजनर्िचष्ट व्यजि ों के स्ट् ान ृर कालम (1) में जवजनर्िचष्ट बैंकों के बोडच में
तत्काल प्रभाव से और अगले आिेि िोने तक, जनिेिक नाजमत करती िजैः
क्र. सं.
1.
2.

बैंक का नाम

वतचमान जनिेिक का नाम

प्रस्ट्ताजवत ‍ ज‍त का नाम

(1)

(2)

(3)

इं जड न बैंक
ूको बैंक

श्री एस. के . ृार्ीग्रिी
डॉ. तुली रॉ

डॉ आदित् गजिा (िन्म जतज : 4.1.1973)
श्री रािेि कु मार (िन्म जतज : 26.9.1965)
[ईफा. सं. 6/3/2011 बीओ-I-ृार्च (1)]
संि कु मार जमश्र, अवर सजर्व

New Delhi, the 8th March, 2022
S.O. 254.—In exercise of the powers conferred by clause (c) of sub-section (3) of section 9 of the
Banking Companies (Acquisition and Transfer of Undertakings) Act, 1970, read with sub-paragraph (1) of
paragraph 3 of the Nationalised Banks (Management and Miscellaneous Provisions) Scheme, 1970, the Central
Government hereby nominates the persons specified in column (3) of the table below as Director on the Board
of the Banks specified in column (1) thereof, in place of the persons specified in column (2) of the said table,
with immediate effect and until further orders:1.
2.

(1)
Indian Bank
UCO Bank

(2)
Shri S. K. Panigrahy
Dr Tuli Roy

(3)
Dr Aditya Gaiha (date of birth: 4.1.1973)
Shri Rajesh Kumar (date of birth: 26.9.1965)
[eF. No. 6/3/2011-BO-I-Part (1)
SANJAY KUMAR MISHRA, Under Secy.

नई दिल्ली, 11 मार्च, 2022
का.आ. 255.—बीमा जवजन ामक और जवकास प्राजिकरर् अजिजन म, 1999 (1999 का 41) की िारा 4
द्वारा प्रित्त िजि ों का प्र ोग करते हुए, के न्री सरकार, एतद्द्वारा, श्री िेबािीर् ृण्डा, आईएएस ( ूृी:87)
(सेवाजनवषत्त), भूतृूवच सजर्व, जवत्ती सेवाएं जवभाग को ृि का का चभार ग्रिर् करने की तारी से आरं भ में तीन
वर्च की अवजि के जलए अ वा ृैंस वर्च की आ ु प्राप्त करने तक अ वा अगले आिेिों तक, िो भी ृिले िो, र्ार
ला ृर्ास ििार रुृए प्रजतमाि (आवास और कार की सुजविा के जबना) के समेदकत वेतन ृजकेि ृर भारती बीमा
जवजन ामक और जवकास प्राजिकरर् के अध् क्ष के ृि ृर जन ि
ु करती िज।
[फा.सं. आर-16011/02/2020-बीमा-I]
जवनोि कु मार, अवर सजर्व
New Delhi, the 11th March, 2022
S.O. 255.—In exercise of the powers conferred by section 4 of the Insurance Regulatory and
Development Authority Act, 1999 (41 of 1999), the Central Government hereby appoints Shri Debasish Panda,
IAS (UP:87) (Retd.), former Secretary, Department of Financial Services to the post of Chairperson, Insurance
Regulatory and Development Authority of India, on a consolidated pay package of four lakh fifty thousand
rupees per month (without facility of house and car), initially for a period of three years with effect from the
date of assumption of charge of the post, or till attaining the age of sixty-five years, or until further orders,
whichever is the earliest.
[F. No. R-16011/02/2020-Ins.I]
VINOD KUMAR, Under Secy.

<!-- page 2 -->

542

THE GAZETTE OF INDIA : MARCH 12, 2022/PHALGUNA 21, 1943

[PART II—SEC. 3(ii)]

नई दिल्ली, 11 मार्च, 2022
का.आ. 256.—बीमा जवजन ामक और जवकास प्राजिकरर् अजिजन म, 1999 (1999 का 41) की िारा 4
द्वारा प्रित्त िजि ों का प्र ोग करते हुए, के न्री सरकार, एतद्द्वारा, श्री राके ि िोिी, भूतृूवच का चकारी उृाध् क्ष
और समूि प्रमु (डेब्र् कज जृर्ल माके ट्स), भारती स्ट्र्ेर् बैंक कज जृर्ल माके ट्स को ृि का का चभार ग्रिर् करने की
तारी से आरं भ में तीन वर्च की अवजि के जलए अ वा बास वर्च की आ ु प्राप्त करने तक अ वा अगले आिेिों तक,
िो भी ृिले िो, र्ार ला रुृए प्रजतमाि (आवास और कार की सुजविा के जबना) के समेदकत वेतन ृजकेि ृर
भारती बीमा जवजन ामक और जवकास प्राजिकरर् में ृूर्चकाजलक जनिेिक (जवत्त त ा जनवेि) के ृि ृर जन ि
ु
करती िज।
[फा. सं. आर-16011/01/2020-बीमा-I]
जवनोि कु मार, अवर सजर्व
New Delhi, the 11th March, 2022
S.O. 256.—In exercise of the powers conferred by section 4 of the Insurance Regulatory and
Development Authority Act, 1999 (41 of 1999), the Central Government hereby appoints Shri Rakesh Joshi,
Former Executive Vice-President and Group Head (Debt Capital Markets), State Bank of India Capital Markets
as Whole-time Member (Finance & Investment) in the Insurance Regulatory and Development Authority of
India, on a consolidated pay package of four lakh rupees per month (without facility of house and car), initially
for a period of three years, with effect from the date of assumption of charge of the post or till attaining the age
of sixty-two years, or until further orders, whichever is the earliest..
[F. No. R-16011/01/2020-Ins.I]
VINOD KUMAR, Under Secy.

श्रम और रोिगार मंत्राल
नई दिल्ली, 4 मार्च, 2022
का.आ. 257.—vkS|ksfxd fookn vf/kfu;e] 1947 ¼1947 dk 14½ dh /kkjk 17 ds vuqlj.k esa dsUnzh; ljdkj

;wdks cSad ds izca/kra=] lac) fu;kstdksa vkSj muds deZdkjkas ds chp vuqca/k esa fufnZ’V vkS|ksfxd fookn esa dsUnzh;
ljdkj vkS|ksfxd vf/kdj.k&lg&Je U;k;ky;] y[kuÅ ds iapkV ¼lanHkZ la- 25@2016½ dks izdkf”kr djrh gSA
[la- ,y-12012/30/2016-vkbZvkj ¼ch-II½]

jktsUnz flag] voj lfpo

MINISTRY OF LABOUR AND EMPLOYMENT
New Delhi, the 4th March, 2022
S.O. 257.—In pursuance of Section 17 of the Industrial Disputes Act, 1947 (14 of 1947), the Central
Government hereby publishes the Award (Ref. No. 25/2016) of the Cent.Govt.Indus.Tribunal-cum-Labour
Court, Lucknow shown in the Annexure, in the industrial dispute between the management of UCO Bank and
their workmen.
[No. L-12012/30/2016 -IR(B-II)]
RAJENDER SINGH, Under Secy.
