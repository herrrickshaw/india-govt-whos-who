---
doc_id: "3edf7c42d0b62abe"
source_url: "https://www.dst.gov.in/static/uploads/2026/01/bfb6f5a9df937bf46f23e43aa6659ef5.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Application format & Guidelines for National awards on Science & Technology popularization for the year 20190 bytes"
date: "2025-12-31"
pages: 15
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "41d3c1cdd24b34f0"
---

<!-- page 1 -->

VERSION 3
GOVERNMENT OF INDIA
MINISTRY OF SCIENCE & TECHNOLOGY
NATIONAL COUNCIL FOR SCIENCE & TECHNOLOGY COMMUNICATIONS DIVISION

NATIONAL AWARDS
FOR

SCIENCE & TECHNOLOGY COMMUNICATION

CODE OF PROCEDURE
CONTENTS

Section No.

Section

Page nos.

I

Description of the awards

2

II

Eligibility for the awards

3

III

Periodicity of the awards

3

IV

Authorities eligible to nominate

4

V

Processing of the nominations

5

VI

Evaluation and selection of the awards

VII

Presentation of the awards

VIII

General

IX

Format of Application

4-5
5
5-6
7 - 14

Part I
Part II
Part III
X
1|Page

Check list

15

<!-- page 2 -->

CODE OF PROCEDURE
Section - I: Description of the awards

The following awards shall be presented every year to an individual or an
institution for outstanding contribution in the field of science and technology
communication and promoting scientific temper which has created
significant impact in the country during the last five years. The awards carry
a citation, a memento and cash award.
Category

Description of the awards

A

National Award for Outstanding
Efforts in Science &
Technology
Communication in general
National Award for Outstanding
Efforts in Science & Technology
Communication
through
Print
Media
including
Books
and
Magazines
National Award for Outstanding
Efforts in Science & Technology
Popularization among Children
National Award for Outstanding
Efforts in Translation of Popular
Science & Technology Literature in
languages mentioned in the eighth
schedule of the Constitution of
India and in English
National Award for Outstanding
Efforts in Science & Technology
Communication through Innovative
and Traditional methods
National Award for Outstanding
Efforts in Science & Technology
Communication in the Electronic
Medium

B

C

D

E

F

2|Page

The
awards
carry
cash
amount
as
indicated below
Rs.5,00,000/(Rupees
Five
Lakh)
Rs.2,00,000/(Rupees
Two
Lakh)

Rs.2,00,000/(Rupees
Two
Lakh)
Rs.2,00,000/(Rupees
Two
Lakh)

Rs.2,00,000/(Rupees
Two
Lakh)
Rs.2,00,000/(Rupees
Two
Lakh)

<!-- page 3 -->

Section - II: Eligibility for the awards
1. The awards are open to all Indian citizens as well as to institutions
registered in India or created by the Central/ State governments/ Union
Territories.
2. To be eligible for the awards, it is required that an Indian citizen/ non
government organization / institution registered in India is recommended
in writing by a competent authority as defined in Section IV.
3. Individuals who are employed in the Ministry of Science and Technology
are not eligible for these awards.
4. Recipient of a particular award shall be considered for the same award
only after a period of 10 years and for a different award after five years.
5. Nominee should be above 35 years of age on the date of nomination
and be alive on the date of award.
6. An organization/ institution shall be eligible for the award if it has
rendered more than 10 years of promotional activity in the field of
science communication after its registration.
7. Individuals who are/were employed in an organization promoted and
financed by state government or the central government or in the
respective governments and whose primary job/duty/responsibility
is/was promotion of Science and Technology communication are
ineligible for the awards unless such contribution has been after
retirement etc. from such an organization/government.

Section - III: Periodicity of the awards
1. The awards shall be conferred annually.
2. If, however, it is considered that none of the recommendations merit
recognition, no award shall be given.

3|Page

<!-- page 4 -->

Section - IV: Authorities eligible to nominate
1. Heads of national science academies, Presidents of professional
science and engineering societies, Vice Chancellors, Registrars of
Universities, Directors of research laboratories, Heads of Departments in
Central and State Governments dealing with the science subjects,
Heads of recognised scientific organizations, Chairmen of registered S &
T based voluntary organizations.
2. Chairperson/President of registered voluntary organization working in
the field of Science and Technology particularly Science and
Technology Communication.
3. Every year a circular letter to the aforesaid agencies shall be issued by
the Ministry of Science & Technology (hereinafter referred to as "the
Ministry"), inviting nominations for the said awards. In addition wide
publicity shall also given to the awards through the media. The
nomination shall be submitted in the prescribed proforma.
Section - V: Processing of nominations
1. Processing of nominations received for the awards shall be made by the
National Council for Science & Technology Communication in the
Ministry.
2. Only completed applications in all respects shall be put up before the
Selection Committee for consideration.
Section - VI: Evaluation and selection of the awards
1. The final selection of the awards shall be made by a Selection
Committee to be constituted by the Ministry. The term of the Selection
Committee shall be three years.
2. The Selection Committee shall consist of nine (9) members who shall be
Indian nationals. The quorum of the meeting shall be five (5) members.
3. If a member of the Selection Committee retires or dies or otherwise
resigns or demits his/her membership before the expiry of the term of
his/her office, another member shall be appointed in his place for the
unexpired period of the term.
4|Page

<!-- page 5 -->

4. The non-official members of the Selection Committee shall be entitled to
travelling and daily allowance in accordance with the Financial Rules
and procedures as applicable in the Government of India.
5. The decision of the Selection Committee shall be by a majority vote. In
the event of the votes on both sides being equal, the Chairperson
presiding over a particular meeting shall have a casting vote.
6. The Selection Committee shall decide on the awards by the First Week
of February, every year.
7. Decisions of the Selection Committee shall be final.
Section – VII : Presentation of the awards
1. The awards, as far as possible, shall be presented at New Delhi at a
special ceremony/function to be held on the 28th February, on the
National Science Day, every year.
2. The awardees shall be invited to receive the awards in person and also
to address the gathering on the subject connected with the work
recognized for the awards.
3. Payment of amount of the awards: The Ministry shall make payment of
the awards at the awards ceremony through an account payee demand
draft/banker's cheque, as the case may be.
4. Non-acceptance of the awards: Before the announcement of conferment
of the awards, the concurrence of the prospective awardees shall be
ascertained. However, even after giving such acceptance, if an awardee
declines to accept the award, the award money shall immediately revert
to the Ministry. If an awardee accepts the award and yet fails to draw the
amount within the validity period, the amount shall also revert to the
Ministry.
Section – VIII : General
1. Any member of the Selection Committee shall be competent to propose
an amendment in the Code. However, final decision in the matter shall
be taken by the Ministry.
5|Page

<!-- page 6 -->

2. The necessary finance for the awards and for all expenses incidental
thereto shall be provided by the Ministry.
3. The secretarial assistance for the Award shall be provided by the
NCSTC Division, Department of Science & Technology, Ministry of
Science & Technology or other agency as the Ministry may decide from
time to time.

6|Page

<!-- page 7 -->

NATIONAL AWARD FOR SCIENCE & TECHNOLOGY COMMUNICATION

FORM 1
FORMAT FOR AN INDIVIDUAL NOMINEE
Category A
B
C
D
E
F
(Please encircle in which category you wish your nomination to be considered)
Part I
1. Full name (in block letters) : ---------------------------------------------------2. Designation: ----------------------------------------------------------------------3. Institute/ Organization: ---------------------------------------------------------4. (a) Address for correspondence :---------------------------------------------

Self attested
passport size
photograph
(Attach
photostat copy
of identity proof)

------------ ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

i) Phone no.

(Work):
(Home):

ii) Mobile no.
iii) Fax no.
iv) E-mail:
(b) Permanent address : ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------5. Date of birth (Attach proof)
6. Academic Qualifications:
Sl.
no

Exams/
Degree

Board/ Institution/

Year of
passing

Subjects

(Attach photostat copies)

7|Page

Division/
position

<!-- page 8 -->

7. Subject of study/research:
8. Area of specialization:
9. Details of professional experience (Period and description of work in chronological order):
10. Please specify details of notable contribution during the last FIVE years in the field of chosen
category in Science & Technology Communication (not more than 500 words) (Attach proof):
11. List of publication/books/articles etc: (Attach photostat copies)
12. Details of awards/honours received, if any (Attach photostat copies)
13. Justification in support of your suitability for the award (in100 words).
14. Declaration:
I certify that the information provided above is correct in all respect.

Date:
Place:

(Signature)
Name: -----------------------------

Attachments (Self attested photostat copies):
1. Identity proof (Passport/Election ID Card/Govt. Authorized ID Card/Driving License/Pan
Card)
2. Date of birth certificate
3. Certificates of academic qualifications
4. Proof of the notable contribution
5. Publications/ books//articles etc.
6. Proof of awards/honours received

8|Page

<!-- page 9 -->

Part II

Brief resume of the nominator:
(within 100 words)

Brief description by the nominator of the outstanding contribution made by the nominee:
(within 200 words)

________________________is recommended for the National Award under the category
(Name of the nominee)
A
B
C
D
(Please encircle)

E

F

Date:
Place:

Nominator’s name:
Address with pincode:
Phone
Fax:
E-mail :

9|Page

Nominator’s signature:

<!-- page 10 -->

Part-III

SUMMARY SHEET

Category A
B
C
D
E
F
(Please encircle in which category you wish your nomination to be considered)
1.

Category :

2.

Name :

3.

Designation :

4.

Organisation, if any :

5.

Address:

Phone :
Fax :
E-mail :
6. Date of birth :
7.

Details of the Nominator :
a) Name :
b) Designation :
c) Address :

Phone :
Fax :
E-mail :

8.

Major contribution (500 words as given in para 9 of Part-I)

10 | P a g e

<!-- page 11 -->

NATIONAL AWARD FOR OUTSTANDING CONTRIBUTION IN SCIENCE & TECHNOLOGY
COMMUNICATION

FORM 2

FORMAT FOR INSTITUTIONAL NOMINEE

Category A
B
C
D
E
F
(Please encircle in which category the nomination of your organization is to be considered)
Part I
1.

Full name (in block letters) ----------------------------------------------------------------------------

2.

Address -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------i)

Phone no.

ii)

Mobile No.

iii)

Fax no.

iv)

E-mail:

3.

Date and no. of registration:
(Attach copies of registration certificate Memorandum of Association, Articles of
Association)

4.

Whether operating in own premises or in rented premises:

5.

The details of the managing committee, qualification of the members and their inter-se
relationship:

6.

Total staff strength of the Institution:

7.

Date on which the last election of the members of the managing committee was held:

8.

Sources of funding:

9.

Details of notable contribution during the last FIVE years in the field of chosen category in
Science & Technology communication (not more than 500 words) :

11 | P a g e

<!-- page 12 -->

10.

Justification in support of your suitability for the award (in100 words).

11. Declaration:
Resume shall include following details:
1. Name and Designation
Details of the organization with which nominator is associated. In case of non-government
organization its objectives as per its constitution/annual repots of for the last two years,
Performa in the sphere of S&T Communication.
I certify that the information provided above is correct in all respect.

Date:
Place:

(Signature)
Name: -----------------------------

Attachments (Self attested photostat copies):
I.

Certificate of Registration, Memorandum and Articles of Association.

II.

Minutes of the General Body meeting held during last five years.

III.

Annual Reports and Audited Annual Accounts for the last five years.

IV.

Copies of publications/books/articles etc.

V.

Copies of awards/honours received.

Vi.

proof of notable contribution.

12 | P a g e

<!-- page 13 -->

Part II

Brief resume of the nominator:
(within 100 words)

Brief description by the nominator of the outstanding contribution made by the institute (within
200 words):

__________________________is recommended for the National Award under Category
(Name of the institute)
A
B
C
D
(Please encircle)

E

F

Date:
Place:

Nominator’s Name:
Address with pincode:
Phone:
Fax:
E-mail :

13 | P a g e

Nominator’s Signature:

<!-- page 14 -->

Part III

SUMMARY SHEET

Category A
B
C
D
E
F
(Please encircle in which category the nomination of your organization is to be considered)
1.

Category :

2.

Name of the Institute :

3.

Address:

Phone :
Fax :
E-mail :
4.

Date of registration :

5.

Details of the nominator :
a) Name :
b) Designation :
c) Address :

Phone :
Fax :
E-mail :

6.

Major contribution (500 words as given in para 9 of Part-I)

14 | P a g e

<!-- page 15 -->

Check List
1.

Name and Designation:

2.

Date of Birth:

3.

Status of organization where working, if any:

4.

(a) Status of the nominator:
(b) Recommendation of the nominator (Part II)

5.

15 | P a g e

Notable contributions during the last five years in the field (Claim 10 of
Form 1)
