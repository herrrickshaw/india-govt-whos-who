---
doc_id: "3ca3caa3c3f9a96b"
source_url: "https://www.dahd.gov.in/static/uploads/2026/04/a8d25b44233fa52e1a947903af7b84b9.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Amendment in the Operational Guidelines of National Livestock Mission (NLM)"
date: "2022-12-28"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b9c8a1a0739db113"
---

<!-- page 1 -->

R-99014 / 45 / 20z1-Anlm_Dadf (E19799)

Govemment of India
Ministry of Fishedes, Animal Husbandry & Dairying
Department of Animal Husbandry & Dairying
Krishi Bhawan, New Delhi
Dated 28'h D ecembe\2022

Ordet
Subject: Amendment in the operational Guidelines of National Livestock Mission(NlM)
This is in teference to the National Livestock Missionopetational guidelines which was
published in July,202l.This Department has been receiving requests and representations
regarding amendments / modiEcations/ chriGcations from various State Govemments/ Union
Territories/ Hon'ble Member of Parliament / Bankes etc. The matter has been deliberated in
the Empowered Committee held on 22.11.2022utder the chairmanship of Secretary, DAHD.
The Empowered committee has approved the following amendmenisin existing operational
guidelines oftheNationd Livestock Mission.
t.

In para 3.2.1 'joiot applications may also be considered as individual categoty of
applicants

lt

In pata 5.3: aftet the last bullet the following amendments mey be inserted:

o The minimum beneficiary contdbution for bank Enanced proiects l0%o of total
project cost.
tll

In para 5.8 aftet the pata 5,8.3, a new para 5.8.4 as under shall be inserted:
5.8.4: Administative Cosc The Depattment v,rill also ptovide Rs. 1.05 Ctore (100%
centtal share) as yeatly funding to the Sate Implementing Agency towards administrative
cost fnr inviting proposals from the beneGciaries, awateniss iteation and handholding of
bene6ciaries to facilitate them to get bank loan etc. A detailed component wise breafup
of the administmtive cost is as follows:

Sr.

N

Patticulars

o

A

Workshop

1

State level l7orkshop

2

3

4

Regional level

Workshop
Miscellaneous
Expense pet
workshop
Skill based Training

Per Unit Price Up
To (Rs.)

2000
1000

Expected
Count
(Tentative)
150

5

beneficiaries

Workshop
s0
Workshop

100

beneficiaries

1s,00,000.00
50,00,000.00

55

20,000

1,000

Amount (Rs.)

Workshop
50

beneficiaries

10 Training

Total A

11,00.000.00

5,00,000.00

81,00,000.00

B

Entepreneurship Develo pment Facilitation H elp Desk

1

Veterinary Graduates

56,000/- Per Month

2

12

13,,14,000.00

<!-- page 2 -->

Months
2

-)

Data Entry Opemtor

20,000 Per Month

TAIDA/ Vehicle

As per State Govt
Norms

hiring for Field visits

2

12

4,80,000.00

Months

2,00,000.00

4

Mobr-le

10 000

4

40,000.00

5

Computer

s0,000

2

1,00,000.00

7

Networking

1000 Per Month

12 Months

12,000.00

8

Printers/routers/com
putet accessories

9

Stationary

10

Miscellaneous

II
I

,+4,000.00

Lumpsum

Total B
Total A+B
In words

II
rI

80,000.00
1,00,000.00

24,00,000.00
1,0s,00,000.00

Rupees One Crore Five Lakh only

Note-

i. salarr adiustments up to 107o in annual increments may be permitted for veterinary
Graduates and Data Entry Opetators engaged.

ii. computer/Mobile/Printer etc equipment should not be putchased every ye,*. It should
be based on the actual requirement for implementation of NLM EDp.
iii. In case of States having huge numben of eligible applications, if required State can
propose fot more administrative cost in propottionate to this cost struchle. That will be
evaluated by PAC on case-to-case basis.

lv

In para 5.8.1.2: the following shall be substituted in place of existing first para:

..:p.:, of the entreprcneurship programme, the subsidy will be provided by
____]n
SIDBI to the lending scheduled bank or Financial Institutions like NCDC etc. to thl
subsidy account of bene6ciaries. The SIDBI on receiptof the subsidy component, shall
telease the fust instalment of subsidy to the appropiate account ofEntrepreneurs/
Eligible Entities after disbutsement ofminimum 25lo of total loan sanctioned. The
SIDBI needs to opendedicated account for subsidy and shall intimate the DAHD for
mapping in PFMS system. The manner of subsidy release has been mentioned against
each entrepreneurship component.

In paa 6.1.tActivity II: The unit size fot Establishment of Enuepreneurship for
breed development in small ruminant sector (sheep & goat farming) and Activity
IV: Promotion of Piggery Enttepreneur, may be considered as undin
Under Activity II: Establishment of Entrepreneur for breed development in small
ruminant sector (sheep & goat farming), the Enrepreneurs / Eligible Entities can
establish sheep and goat breeding unit with minimum 100 females and 05 males and can

apply in multiple of 100+5 unit with a maximum limit up to 500+25 unit. Accordingly,
50% capital subsidy up to following subsidy celling will be prowided to beneficiaries:

<!-- page 3 -->

Unit Size fot Goat/Sheep Farm

Max amount of capital subsidy

100 females *5 males

10 lakhs

200 females +10 males

20 lakhs

300 females +15 meles

30 lakhs

400 females +20 males

40 lakhs

500 females +25 males

50 lakhs

Under Activity fV: Promotion of Piggery Enttepteneur, the entrepreneur will be provided
assistance for the esablishment of a breedet farm with minimum 50sowand 05 boars. The
applicant can also establish breeder farm with 100 sow and 10 boars. Accordingly, 50% capital
subsidy up to following subsidy celling will be provided to beneficiaries:

vl.

Unit Size for Piggery Farm

Max amount of capital subsidy

50 sows *5 boars

15 lakhs

100 sows+ 10 boars

30 lakhs

The following clarifications are also approved by Empowered Committee:

o

The applicant may also be eligible forapplying fot more than one component in

NLM EDP simultaneously.

o

More than one adult membet of a family may also be eligible to apply and may
avail bene6ts under the NLM EDP scheme, provided he/she frrlfils the eligibiJity
criteria.

r

The bene6ciary needs to hold a savings account in the lender bank and the
bank will release subsidy in savings account of beneficiary and not in loan account.

@r. O. P. Cha
Distribuuon

Jornt Secretary to the Government of India

1.
2.

To all the Scheduled Banks
All the Additional chief Seueary /principd Sectetary/sectetary, Animal Husbandry
Departrneot all S tzte/ UT
3. Deperrnent of Financial Services, Ministry of Finance

4.
5.

AS&FA,DAHD

SIDBI for uploading in the NLivI EDP portal

CC to
1.

PS to Hon'ble Minister FAHD

2.
3.

PS to Hon'ble MOS, FAHD
Sr. PPS to Secretary (DAHD)

4.

NIC of DADF for uploading in the departrnent,s website
