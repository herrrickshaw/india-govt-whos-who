---
doc_id: "3faeecf8e1e28c16"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/bb09cabff717096bb873a8c223f1238e.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 28.04.2025: Kerala Panel for High Court, CAT Ernakulam, AFT Ernakulam and Lakshadweep Administration"
date: "2025-04-28"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "bd02f46c44917e70"
---

<!-- page 1 -->

F. No. 3-11017/7/2025-Judicial
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
ak OK aC
Shastri Bhawan, New Delhi
Dated the 28" April, 2025
ORDER
The President is pleased to engage following Advocates for conducting
Central Government litigation before the High court of Kerela at Kochi, Central
Administrative Tribunal at Ernakulam Bench, Armed Forces Tribunal at
Ernakulam and for conducting litigation of Lakshadweep Administration before
the High Court of Kerala, as shown in the List-'A', List-'B', List-'C’ and List ‘D’
below, with effect from the date of this order for a period of three years or until
further orders, whichever is earlier:
List ‘A‘
High Court of Kerala
Sl.No | Name of Contact Details Enrol. No.
Advocate (S/Shri)
1, Prathap G. Padickal, Perungala, P.O
Padickal Kayamkulam, Alappuzha-690559
Mob: 9961566078, 0479280078
Email- K/2513/1999
prahthapgpadickal@gmail.com
2. Girish Kumar V 67/3709, Amprayil House, ERG
Road, Near High Court of Kerala,
Kochi Kerala-682018
Mob: 7736020151 K/2108/1989
Email: Gkviswam.adv@gamil.com
3. T.C Krishna CRRA-51, Thekke Cherupilli,
Cherupiili Road, Off Azad Road,
Kochi-682017 K/802/1990
Mob: 9447135770
Email: advtckrishna@gmail.com
4, Deepa Rajesh Deepa Bhavan, Eathinanam,
Malakunnam, P.O Changanassery,
Kottayam-686535 K/742/2007
Mob: 9895469920
Email: Deepaadv83@qmail.com
5. Daya Sindhu Gurukrupa, A.N Puram, Alappuzha,
Shreehari N. S. Iron Bridge, P.O Alappuzha-688011
Mob: 8547253410 K/129/2013
Email: Sh.legalmail@gmail.com
Page 1 of 4

<!-- page 2 -->

Mini Gopinath Gokulam, Thekkecherupilly House,
Cherupilly Road, Azad Road, Kaloor-
682017 K/1288/1998
Mob: 7907342383, 9037840595
Email: advminigopinath@gmail.com
a P Anirudhan 6A, B15, Lotus Sopanam, Near
Abhishekam Auditorium, Tripunithura,
Ernakulam, Kerala 682301
Mob: 9496176999 k/2306/2021
Email: Anirudhraj10@outlook.com
Anil Kumar C. R. | Cheruvallikudiyil, Mangattor,
Kolenchery, P.O-682311
Mob: 9605212655 K/1190/2020
Email: Akcr501@qmail.com
Suraj Kumar D. Krishna Prasad & CO, 3
Krishnarpanam, Excel Park, Stp
Road, Elamkulam, Kochi-20 MS/8006/2021
Mob: 9698614484
Email: advsurajkumard@gmail.com
10. K.N, RKB Legal, F-1 ‘Teertham’ St. K/1017/1994
Radhakrishnan Benadict Road, Kombara-Kochi-19
Mob: 9496733988
Email: advknr@gmial.com
Tie Jose Antony Kodavelil House, Manappuram P.O, K/778/2011
Cherthala P.O Alappuzha, Kerala
Mob: 9048370396
Email:
advjoseantonycherthala@gmail.com
Menon P.O, Tripunithura, Ernakulam,
Kerala-682307
Mob:7907359034
EMail: renjishsmenon@gmail.com
Central Police Station, Near High
Court, Ernakulam-682018
Mob: 9961669587, 7356759587
Email: advkspraveen@gmail.com
Page 2 of 4

<!-- page 3 -->

LIST ‘B’
CENTRAL ADMINISTRATIVE TRIBUNAL, ERNAKULAM BENCH
Sl Name of Contact Details Enrol. No.
No. Advocate (Shri)
SENIOR PANEL COUNSEL
1. Sinu G Nath Edayilerathu House, K/154/2005
Chenneerkara, P.O, Kulanada
Via, Pathanamthitta, Dist. Pin-
689503
Mob: 9387649093
List ‘Cc’
. हे ARMED FORCE TRIBUNAL AT ERNAKULAM
Sl. [Name of Contact Details Enrol, No.
No. Advocate (Shri)
Central Government Counsel
1. Sunil Kumar P Central Law Firm, Power House K/1049/1999
Road, Cochin-18
Mob: 9809997788
Email: clfadvocates@gmail.com
115६ "0:
HIGH COURT OF KERALA
(For conducting Litigation of Lakshdweep Administration)
Sl. No. | Name of Contact Details Enrol. No.
Advocate
SENIOR PANEL COUNSEL
1. Ms. Sreekala K | Mangalath (H), Thuruthissery, K/869/2003
L Mekkad, P.O-683589
Mob: 9847906081
Email: Klsreekala123@gmail.com
Page 3 of 4

<!-- page 4 -->

2s Prenjith Kumar | 42/1222 (64/1446), 1st Floor, K/327/2014
K.S Thuruthiparambil House, A.R
Prakasham Road, Ernakulam-
682018
Mob:9562959275
Email: prenjithrajam@gmail.com
25 The engagement and professional fee of the aforesaid advocates will be
governed by the terms and conditions contained in this Department's OM No.
26(1)/99-Judl. dated 2409.1999 read with OM No. 26(1)/2014/Judl. dated
01.10.2015 & instructions issued subsequently through OMs especially the OM
No. J-16/11/2017-Judicial dated 08.02.2018 imposing certain restrictions on
panel counsel. The aforesaid OMs are available on the website of this
Department i.e. www.legalaffairs.gov.in in the tab ‘Judicial Section’ under
heading ‘Circulars pertaining to litigations’.
4. Hindi version of this order will follow. Qr4 30 3X
\y:
(Madhab chain Prusty)
Senior Government Advocate
Copy (through email) to:

1. PS to Hon'ble MoS (I/C) L8d.

2. PSO to Law Secretary/All Additional Secretaries and Joint Secretaries in the main Secretariat of
Department of Legal Affairs

3. Shri AR. L. Sundaresan ASGI for High Court of Madras.

4. Branch Secretariat, Chennai.

5. The Registrar, High Court of Kerala at Kochi (Ernakulam).

6. The Registrar, CAT, Ernakulam Bench.

7. The Registrar, AFT, Ernakulam Bench.

8. The Administrator, Administration of the Union Territory of Lakshadweep, Kavaratti Island, Pin-682555.

9, LIMBS Section for necessary section.

10. One copy of this order is uploaded on website of this Department i.e. www.legalaffairs.gov.in under tab
‘Judicial Section’ in the link ‘Orders related to empanelment of Advocates for Union of India’ for the
information of all concerned.

11. Hindi unit, Department of Legal Affairs for Hindi translation of the order.

12. Office copies. ya

Wee te ne
uh
Ke
(Kumar Gaurva)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
Page 4 of 4
