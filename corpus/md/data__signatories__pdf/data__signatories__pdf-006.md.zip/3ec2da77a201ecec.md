---
doc_id: "3ec2da77a201ecec"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/0038_Advt_Corrigendum_22072026.pdf"
ministry: "Department of Space"
title: "Corrigendum:VSSC/P/ADVT/MME/25/2026 Dated:03.06.2026      53.38 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "e5bc97251aa9dcd1"
---

<!-- page 1 -->

भभारत सरकभार/GOVERNMENT OF INDIA
अअंतररक्ष वविभभाग/DEPARTMENT OF SPACE
वविक्रम सभारभाभभाई अअंतररक्ष ककद/VIKRAM SARABHAI SPACE CENTRE
वतरुविनअंतपपुरम/THIRUVANANTHAPURAM – 695 022
No.VSSC/P/ADVT/MME/25/2026

21.07.2026

CORRIGENDUM TO ADVT No. VSSC/P/ADVT/MME/25/2026 DT. 03.06.2026

क्रम सअं.
Sl. No.

01

वनवविदभा सअं.
Tender No.

VSSC/PURCHASE
UNIT V [MME
PURCHASE]/
VS2026000038 01
[ददो भभाग / PT TWO PART]

Sl.
No.

01.

विरर न/ Description

मभातभा
Qty.

1.50

एए 2050 डीसी सं चक बबले टो का बनरारण और आपूबरर
Manufacture and Supply of AA2050 DC
cast billets

टन/
1.50
Tonnes.

वनवविदभा शपुल्क
Tender
Fee
लभागगूनहह /
NA

बदोलली प्रस्तपुत करनने ककी समय-सलीमभा
Time limit for submission of Bid

बदोलली खदोलनने ककी वतथथ
Bid Opening date

Upto 11/08/2026 [14:00 Hrs.]

11/08/2026 [14:05 Hrs.]

All other terms and conditions of the original tender notice shall remain
unchanged.

हस्तभाक्षररत/Sd/प्रधभान, क्रय एविअं भअंडभार / Head, Purchase & Stores
