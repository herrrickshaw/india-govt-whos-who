---
doc_id: "3df97faaf78cfb40"
source_url: "https://financialservices.gov.in/sites/default/files/order-notices/guidelines.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "guidelines.pdf"
date: ""
pages: 6
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "4ead3adb1a8a60f0"
---

<!-- page 1 -->

Accessibility Standards and Guidelines for infrastructure and services in Insurance
Sector
Introduction:
Financial services play a necessary and important role in societies by enabling access to
products, resources, and services, enabling savings and asset creation, and facilitating
economic self-sufficiency. Access to financial services for all is a necessity in today’s world
not merely at the community or household level, but at an individual level, to open doors
to insurance/ banking and other financial services. Access to and inclusion in financial
services is crucial to poverty reduction and participation in economic prosperity, and
growth and development.
The increasing pervasiveness of technology in the delivery of financial services and the
disruption of traditional channels of delivery through ‘FinTech’ (technology for financial
service delivery) have generated new enthusiasm and newer ways for reaching out to
persons who remain uncovered. The increasing nature of services now available through
technology has triggered growing demand among persons who remained marginalized due
to traditional paper-based services. It also calls to ensure that new barriers to access are
not created.
Accompanying this growth spurt in technology, there has also been an increasing
recognition of the rights of persons with disabilities and the utmost importance of
providing equal access to them to all services, including financial services.
Insurance sector is committed to be a part of “Sugamya Bharat Abhiyan” or “Accessible
India Campaign” of Government of India. These Harmonized guidelines aim to make
insurance services accessible to the persons with physical disabilities in compliance with
the Rights of Persons with Disabilities Act 2016 (RPwD Act).
A. Infrastructure accessibility: Harmonized guidelines and Standards of Universal
Accessibility in India, 2021 as amended from time to time, issued by the Ministry of
Housing and Urban Affairs shall be followed in respect of every building owned, operated/
used and /or managed in the insurance sector.
B. Service accessibility:
a) Home collection/ delivery of insurance and /or claim documents, for persons with
disabilities, through insurance agents/ by post/ courier/electronic means etc.
b) Insurance offices to provide all practical assistance to persons with disabilities, for
availing insurance facilities to ensure that no person with disability is denied access
due to non-availability of accessibility in services. In this regard, the offices are
advised to:
i) Accept communications made at any operational office of the respective
company chosen by the person with disability as nearest approach centre. It will
be duty of the office, so chosen by the person with disability, to forward his
Page 1 of 3

<!-- page 2 -->

communication to the dealing office.
ii) Additional facilities like reading and filling up of proposal forms, claim forms,
discharge voucher etc. to be provided to a persons with disabilities. The dealing
officer / Manager of the office should read out the rules of business and other
terms and conditions in the presence of a witness, if required by the customer.
iii) Magnifying glasses will be provided in all insurance offices for the use of persons
with low vision, wherever they require for carrying out insurance transactions
with ease. The branches should display at a prominent place notice about the
availability of magnifying glasses and other facilities available for persons with
disabilities.
C. Information and communication technology accessibility:
a) In recent years, digital technologies have increasingly contributed to economic

growth and citizen empowerment. These technologies have become ubiquitous in
everyday life and enable people to access various services from the comfort of their
homes.
b) Government has established web presence through multiple websites, web portals,

web applications and mobile apps that offer information and services to the public.
However, inconsistency in conventions, layout standards, navigation strategies and
technologies adopted can reduce the effectiveness of websites/apps. Indian
Government Websites should conform to the essential prerequisites of UUU
trilogy i.e. Usable, User-Centric and Universally Accessible. They also form the
basis for obtaining Website Quality Certification from STQC (Standardisation
Testing Quality Certification), an organization of Ministry of Electronics &
Information Technology, Government of India.
c) Web accessibility means that people with disabilities can also perceive, understand,

navigate, and interact with the Web. It encompasses all disabilities that affect access
to the Web, including visual, auditory, physical, speech, cognitive, and neurological
disabilities. Thus, the impact of persons with disabilities is radically changed on the
Web because the Web removes barriers to communication and interaction that
many people face in the physical world. The Website and apps should be designed
and developed in such way that they are accessible by all people, whatever may be
their hardware, software, language, culture, location, or physical or mental ability.
Accessibility is crucial for meeting the requirements of the RPWD Act, 2016 to
create a more inclusive digital environment, and covers internationally accepted
guidelines on accessibility.
d) Website standard as specified in the standard for Indian Government Websites
Page 2 of 3

<!-- page 3 -->

(GIGW) as amended from time to time, as adopted by Department of
Administrative Reforms and Public Grievances, Government of India shall be
followed.
e) Documents to be placed on websites shall be in electronic publication (ePUB) or

Optical Character Reader (OCR) based pdf format.
f) Websites, apps, information and communication technology based public facilities

and services, electronic goods and equipment which are meant for everyday use,
information and communication technology based consumer products and
accessories for general use with persons with disabilities, and other products and
services which are based on information and communication technology, shall
comply with the Indian standards IS 17802 (Part 1), 2021 and IS 17802 (Part 2),
2022, published by the Bureau of Indian Standards vide notification numbers HQPUB013/1/2020-PUB-BIS(278), dated the 24th December, 2021 and HQPUB013/1/2020-PUB-BIS(358), dated the 4th May, 2022, respectively as amended
from time to time.

Page 3 of 3

<!-- page 4 -->

बीमा क्षेत्र में बनु ियादी ढाांचे और सेवाओ ां के निए सगु म्यता मािक और नदशानिदेश
प्रस्ताविा:
वित्तीय सेिाएँ उत्पादों, संसाधनों और सेिाओ ं तक पहचँ को सक्षम करके , बचत और आवतत
सृजन को सक्षम करके और आवथिक आत्मवनर्िरता को सक
ु र बनाकर समाज में एक आिश्यक और
महत्िपर्ू ि र्वू मका वनर्ाती हैं। आज की दवु नया में सर्ी के विए वित्तीय सेिाओ ं तक पहचँ एक
आिश्यकता है, न के िि समदु ाय या घरे िू ततर पर, बवकक व्यविगत ततर पर, तावक बीमा/बैंवकंग और
अन्य वित्तीय सेिाओ ं के विए दरिाजे खि
ु सकें । वित्तीय सेिाओ ं तक पहचँ और इसमें समािेश गरीबी
में कमी िाने और आवथिक समृवि, िृवि तथा विकास में र्ागीदारी के विए महत्िपर्ू ि है।
वित्तीय सेिाओ ं की आपवू ति में प्रौद्योवगकी की बढ़ती व्यापकता और 'विनटेक' (वित्तीय सेिा
वितरर् के विए प्रौद्योवगकी) के माध्यम से आपवू ति के पारंपररक चैनिों में कमी ने उन िोगों तक पहचँ ने
के विए नया उत्साह और नए तरीके सृवजत वकए हैं जो अर्ी तक इन सेिाओ ं से िंवचत हैं। प्रौद्योवगकी
के माध्यम से अब उपिब्ध सेिाओ ं की बढ़ती प्रकृ वत ने उन िोगों के बीच बढ़ती मागं को बढ़ािा वदया
है जो पारंपररक पेपर-आधाररत सेिाओ ं से हावशए पर रह गए हैं । साथ ही इसमें यह सवु नवित करने का
आह्वान वकया है वक पहचँ में नई बाधाएँ पैदा न हों।
प्रौद्योवगकी में इस तेजी के साथ-साथ वदव्यांगजनों के अवधकारों की मान्यता र्ी बढ़ रही है तथा
वित्तीय सेिाओ ं सवहत सर्ी सेिाओ ं तक उन्हें समान पहचं प्रदान करने के महत्ि पर र्ी जोर वदया जा
रहा है।
बीमा क्षेत्र र्ारत सरकार के " सगु म्य र्ारत अवर्यान" या "एक्सेवसबि इवं िया कै म्पेन" का
वहतसा बनने के विए प्रवतबि है। इन ससु ंगत वदशा-वनदेशों का उद्देश्य बीमा सेिाओ ं को वदव्यांगजन
अवधकार अवधवनयम, 2016 ( आरपीिब्कयिू ी अवधवनयम) के अनपु ािन में शारीररक रूप से विकिांग
व्यवियों के विए सि
ु र् बनाना है।
क. अवसांरचिा सि
ु भता: आिास और शहरी कायि मंत्रािय द्वारा समय-समय पर यथा संशोवधत
जारी वकए गए सामंजतयपर्ू ि वदशा-वनदेशों और र्ारत में साििर्ौवमक सगु म्यता मानक, 2021 का बीमा
क्षेत्र में तिावमत्ि िािी, संचावित/प्रयि
ु और/या प्रबंवधत प्रत्येक इमारत के संबंध में पािन वकया
जाएगा।
ख. सेवा सुगम्यता:
क) वदव्यांगजनों के विए अवर्कतािओ/ं िाक/कूररयर/इिेक्रॉवनक माध्यमों आवद के माध्यम से
1

<!-- page 5 -->

बीमा और/या दािा दततािेजों का घर पर संग्रहर्/वितरर्,
ख) बीमा कायाििय वदव्यांगजनों को बीमा सवु िधाओ ं को प्राप्त करने के विए सर्ी व्यिहाररक
सहायता उपिब्ध कराएं तावक यह सवु नवित वकया जा सके वक वदव्यागं ता िािे वकसी र्ी व्यवि को
सेिा में सगु म्यता की अनपु िब्धता के कारर् िवं चत न होना पडे। इस सबं धं में कार्ाालर्ों को सलाह
दी जाती है कक:
i)
वदव्यांगजन द्वारा वनकटतम संपकि कें द्र के रूप में चनु ी गई कंपनी के वकसी र्ी पररचािनरत
कायाििय में वकए गए पत्राचार को तिीकार करना। वदव्यांगजन के पत्राचार को संबंवधत कायाििय को
अग्रेवित करने का दावयत्ि उसके द्वारा चनु े गए कायाििय का होगा।
ii) वदव्यांगजन को प्रतताि प्रपत्रों, दािा प्रपत्रों, वितचाजि िाउचर आवद को पढ़ने और र्रे जाने
जैसी अवतररि सवु िधाएं उपिब्ध कराई जानी हैं। यवद ग्राहक द्वारा अपेक्षा की जाती है तो कायाििय
के संबंवधत अवधकारी/प्रबंधक द्वारा वकसी साक्षी की उपवतथवत में व्यिसाय के वनयमों और अन्य वनयम
ि शतों को पढ़ कर सनु ाया जाना चावहए।
iii) सर्ी बीमा कायािियों में जहां कहीं र्ी कम-दृवि िािे व्यवियों को बीमा िेनदेन आसानी से
करने के विए मैग्नीिाइगं ग्िास की आिश्यकता हो, उन्हें उपयोगाथि उपिब्ध कराया जाएगा ।
शाखाओ ं को मैग्नीिाइगं ग्िास की उपिब्धता और वदव्यागं जनों के विए उपिब्ध अन्य सवु िधाओ ं
के बारे में वकसी तपि तथान पर सचू ना प्रदवशित करनी होगी।
ग. सूचिा और सच
ां ार प्रौद्योनगकी सुगम्यता:
क) हाि के ििों में, विवजटि प्रौद्योवगवकयों ने आवथिक विकास और नागररक सशविकरर् में
उत्तरोत्तर योगदान वदया है। ये प्रौद्योवगवकयां दैवनक जीिन में सििव्यापी बन गई हैं और िोगों को घर बैठे
सहजता से विवर्न्न सेिाओ ं तक पहचं प्रदान करती हैं।
सरकार ने जनता को सचू ना और सेिाएं प्रदान करने िािी कई िेबसाइटों, िेब पोटििों, िेब
एवलिके शनों और मोबाइि ऐलस के माध्यम से अपनी िेब उपवतथवत तथावपत की है। तथावप,
कनिेंशन्स, िेआउट मानकों, नैविगेशन तरैटेजीस और अपनाई गई प्रौद्योवगवकयों में असगं वत
िेबसाइटों/ऐलस की प्रर्ािशीिता को कम कर सकती है। र्ारतीय सरकारी िेबसाइटों को ययू यू ू
रायिॉजी अथाित् यजू ेबि, यजू र-सेंवरक और यवू निसििी एक्सेवसबि की महत्िपर्ू ि पिू ि-अपेक्षाओ ं के
अनरू
ु प होना चावहए। ये, इिेक्रॉवनक और सचू ना प्रौद्योवगकी मंत्रािय, र्ारत सरकार के एक संगठन
एसटीक्यसू ी (तटैंििािइजेशन टेवतटंग क्िाविटी सवटिविके शन) से िेबसाइट क्िाविटी सवटिविके शन प्राप्त
करने के विए आधार र्ी तैयार करते हैं ।
ग)
िेब सगु म्यता से तात्पयि यह है वक वदव्यांगजन िेब को अनर्ु ि कर सकें , समझ सकें , नेविगेट
कर सकें और उसके साथ इटं रै क्ट कर सकें । इसमें दृश्य सबं धं ी, श्रिर् संबधं ी, शारीररक, बोिने संबधं ी,
ख)

2

<!-- page 6 -->

इद्रं ीय संबंधी और न्यरू ोिॉवजकि वदव्यांगता सवहत िेब सगु म्यता को प्रर्ावित करने िािी सर्ी
अक्षमताएं शावमि हैं। इसविए, िेब पर वदव्यांगजनों के प्रर्ाि में कािी बदिाि हआ है क्योंवक िेब
उन सचं ार और िाताििाप अिरोधों को दरू कर देता है वजसका कई िोग दवु नया में आमतौर पर सामना
करते हैं। िेबसाइट और ऐलस को इस प्रकार विजाइन और तैयार वकया जाना चावहए वक िे सर्ी िोगों
के विए सगु म्य हों, चाहे उनका हािििेयर, सॉफ्टिेयर, र्ािा, संतकृ वत, तथान या र्ौवतक अथिा
मानवसक क्षमता कुछ र्ी हो। आरपीिब्कयिू ी अवधवनवयम, 2016 की अपेक्षाओ ं को परू ा करने के विए
सगु म्यता अवत महत्िपर्ू ि है तावक अवधक समािेशी विवजटि पररिेश सृवजत वकया जा सके और
सगु म्यता के संबंध में अंतरािष्ट्रीय ततर पर तिीकृ त वदशावनदेशों को शावमि वकया जा सके ।
घ)
प्रशासकीय सधु ार और िोक वशकायत विर्ाग, र्ारत सरकार द्वारा अपनाए गए र्ारत सरकार
की िेबसाइटों के विए यथा विवनवदिि वदशावनदेशों, वजन्हें समय-समय पर संशोवधत वकया जाता है, के
अनसु ार िेबसाइट मानकों का पािन वकया जाना चावहए।
ङ)
िेबसाइट पर उपिब्ध कराए जाने िािे दततािेज इिेक्रॉवनक पवब्िके शन (ई-पीयबू ी) या
ऑवलटकि कै रे क्टर रीिर (ओसीआर) आधाररत पीिीएि िॉमैट में होने चावहए।
च) िेबसाइट, ऐलस, सच
ू ना और संचार प्रौद्योवगकी आधाररत जन सवु िधाएं और सेिाएं,
इिेक्रॉवनक िततएु ं और उपकरर् जो रोजमराि के उपयोग के विए हैं, वदव्यांगजनों के आम उपयोग के
विए सचू ना और संचार प्रौद्योवगकी आधाररत उपर्ोिा उत्पादों और अवतररि उपतकर (एक्सेसरी)
और सचू ना और सचं ार प्रौद्योवगकी पर आधाररत अन्य उत्पाद ि सेिाएं, र्ारतीय मानक ब्यरू ो द्वारा
क्रमशः 24 वदसंबर, 2021 की अवधसचू ना सं. एचक्य-ू पीयबू ी013/1/2020-पीयबू ी-बीआईएस
(278) और 4 मई, 2022 की अवधसचू ना सं. एचक्य-ू पीयबू ी013/1/2020-पीयबू ी-बीआईएस (358)
के जररए प्रकावशत र्ारतीय मानक आईएस 17802 (र्ाग 1), 2021 और आईएस 17802 (र्ाग 2),
2022 जैसा वक समय-समय पर संशोवधत वकया जाता है, का अनपु ािन करें गे।

3
