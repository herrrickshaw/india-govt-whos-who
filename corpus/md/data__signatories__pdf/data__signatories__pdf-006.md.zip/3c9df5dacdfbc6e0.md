---
doc_id: "3c9df5dacdfbc6e0"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/caffd63c435a1d4774569cfd778ff7be.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Extension of Panel Counsel for Armed Force Tribunal, Chandigarh Order dated 07.02.2024"
date: "2024-02-08"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "e2aa3ed09d40316f"
---

<!-- page 1 -->

F. No. J-11017/3/2024-Judicial (2)
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
eee
Shastri Bhawan, New Delhi,
Dated the 7'" February, 2024
ORDER
The President is pleased to extend the terms of the panel counsel whose
names are occurring in this Department's Order No. J-11017/1/2021-Judicial dated
06.04.2021 for conducting litigations of Army, Navy and Air Force before the Armed
forces Tribunal, Reginal Bench Chandigarh, ‘until further orders’.
2: The engagement and professional fee of the aforesaid counsels will be
governed by the terms and conditions contained in this Department’s O.M. No.
26(1)/99-Judl. dated 24.09.1999 read with OM No. 26(1)/2014/Judl. dated 01.10.2015
& instructions issued subsequently through OMs specially the OM No. J-16/11/2017-
Judicial dated 08.02.2018 imposing certain restrictions on panel counsel. The
aforesaid OMs are available on the official website of this Department i.e.
www. legalaffairs.gov.in in the tab ‘Judicial Section’ under heading ‘Circulars pertaining
to litigations’.
3 Hindi version of this order will follow.
oar i)
Aur
(Sunita Anand)
Joint Secretary & Legal Adviser
Copy (through email) to:-
1. PS to Hon'ble MoS (I/C)L&J
2. PSO to Law Secretary / Additional Secretaries in the main secretariat of Department of Legal
3. Affairs.
4. Shri Satya Pal Jain, Addl SGI, Punjab & Haryana High Court, Chandigarh
5. Shri Jagjot Singh Lalli, Deputy SGI, Punjab & Haryana High Court, Chandigarh.
6. Shri Balram Sharma, Deputy SGI, High Court of Himachal Pradesh, Shimla
7. Toupload on the website of this Department i.e. www.legalaffairs. gov in in the tab ‘Judicial Section’
under the link ‘Orders related to empanelment of Advocates for Union of India’.
8. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
9. Office/Spare copies. Wea
or
(Kumar Gaurva)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
