---
doc_id: "3f6e1a16dbe1ec7a"
source_url: "https://master-dopt.digifootprint.gov.in/static/uploads/2025/10/e7b9bfc4a9811d001e72b6aacbe5a71b.pdf"
ministry: "Department of Personnel and Training (DoPT)"
title: "The Kerala Administrative Tribunals (Procedure) Amendment Rules, 2014"
date: "2014-10-27"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4bb7f264279d6105"
---

<!-- page 1 -->

'f7•R'r Ito 'to Teo-33004/99

REGD. NO. D. L.-33004/99

are!

Tize Gcaette of ,3inctia
3.11:1711113T
EXTRAORDINARY
VTIT H-1717-4 3--.77-7111-4 (i)
PART II—Section 3—Sub-section (1)
17TRIMT /4" I+ chtrild
PUBLISHED BY AUTHORITY
14. 5541

thm— „ 317:;
,,J,RT 27, 2014/4-att 5, 1936
NE'N DELHI, 1110NDA17 , OCTOBER 201-4/1CA1T1TIKA 5, 1936

CC Ii

Wrfiff, cl

9r+1717 at< 4.9. 41111 41

(¢fz After

al t-4,111

rq4, 27 .3fq;,rsiv.
.
2014
7T.*-r.i. 7470).
7j7 (7), -,tz

(2)

737-1:11 tl

--4-r
-", s
3t7 7t3- (7)7- ..1T

Pit 3Tf9)--*7-t-r (:4i;,41)
1. (1) 79- F9-zilfr

7

T

4 31T-T17

(2) ir 4..rm

•31-Rit',u1 31f
itr 36

7,

th (Tr)

, 1987.371 #q1- 4-1 t& *,-‘1* i

r TrT:r

1985 (1985 TT 13) k.r. a i <I 35 Rr
Tr :4 ,41 4 1 1- ',C1

MT9f)-19=-47 f9TT
,r

t,

(13:41) Ttifr4-9- f9-74, 2014 t:

9 11tiPlt

Trft 4 3r-f-a-

2.*,-*-rzr 3PM:TRT 3Tr3 7771- (7fT7T) f

1, 1987 * 1'474 5 * -3-1R4-1 ,-1 (3) it,

Tti.17

fk7-4-r -.7111 , 6p-!id!
g

r 3 191" Cliff{

ft 9

3ift-T

411 in
['TT. #.

11014/6/2011-7.3r.]
3i49T

iTR

:

aiff

Mf

17-7-6 *

ft-7 Tr7 3A-T

4 83-finTw-i-r
fkr;:rfkfta-

17(31), 7111W 6 der, 1987 5,RI

f*-7

,(1) #. #f.Tr.fW.1000(31), aitru 11.10.1988
(11) Tr.
99(3T), Tra-q 26.02.1991 1
(iii) T. Trr.Tr.fk. 557(3T), 7rfra- 04.09.1991

(iv)?T. Fr.Trr.fk. 564(3T), ,711 -st ,1 07.07.1994
(y)

77.Tr.fW. 756(31), 91-49- 18.10.1994

(vi)

7T.TTA. 41(3T), (1 I

4268 01/2014

i-i 4{1-1 71 -1.

22.01.1996 I
(1)

<!-- page 2 -->

THE GAZETTE OF INDIA : EXTRAORDINARY

2

[PART II—SEC. 3(i)]

MINISTRY OF PERSONNEL, PUBLIC GRIEVANCES AND PENSIONS
(Department of Personnel and Training)
NOTIFICATION
New Delhi, the 27th October, 2014
).— In exercise of the powers conferred by clauses (d), (e) and (f) of sub-section (2) of section 35
G.S.R. 74
and clause (c) of sec, on 36 of the Administrative Tribunals Act, 1985 (13 of 1985), the Central Government hereby
makes the following es further to amend the Central Administrative Tribunal (Procedure) Rules, 1987, namely:1. (1) These rules ay be called the Central Administrative Tribunal (Procedure) Amendment Rules, 2014.
(2) They shall co e into force on the date of their publication in the Official Gazette.
strative Tribunal (Procedure) Rules, 1987, in rule 5, in sub-rule (3), the following proviso
2. In the Central A
shall be inserted, namely:
"Provided that the time allo ed by the Registrar to rectify the defects shall not exceed thirty days."
[ F. No. A-11014/6/2011-AT]
ARCHANA VARMA, Jt. Secy.
FOOT NOTE.-The principal rules w e published in the Gazette of India vide notification number G.S.R. 17(E), dated
6th January, 1987 and s bsequently amended vide –
(i) No. G.S.R. 1000(E), ..ted 11-10-1988.
(ii) No. G.S.R. 99(E) ,date 26-2-1991.
(iii) No. G.S.R. 557(E), date 4-9-1991.
(iv) No. G.S.R. 564(E), dated , 7-1994.
(v) No. G.S.R. 756(E), dateci 18- "-1994.
(vi) No. G.S.R. 41(E), dated 22-1-1 96.

9-i7f ,74T,
27 31
3T54

, 2014
al-Wk7471. , 1985 (1985 Ti 13) t- ?-:4-71- 35 fr

:77 vi (2) -4, t7s-, (7), 7j77: (Z.) 3frT...#3. (9-) 77 51-7 36*

(Tr) TTr

i7-14-1, 1989'Fr 47#9ip-19-

*Riv,

7

33T'Itt.ul

SPIN Pi t

1. (1) -;7P--4-14-st TT #Tq71-7-.FT7 3411-7
P17

(2)

dI

31, ..;t :-

) 9Tr ftzr, 2014 t

4 -,7-1 tqt
q4-i (3) it,

3-771:4 ,“ul (epir) ffzi-4, 1989 * f'H-zrlt

2.
347: '7?7- ift9- r+74-1- ,Tt I

, oT17--T

sli7+7N-ii r 1 ;i 4i

4-'1

d

,

(rmk-1it i t i-7rzzit re-6*-fm-9- *

*01711 d 3.17.f9).. 7417 ,-r 437

9 t 57144i i"
[Tr. #. 7-11014/6/2011-T3T.]
314-H-r q4-11, =4-5-fa• +1 -al

trN %,-9 : M -R-44 4R-9-

thA ,-41 fi 31-fi)---9-9-r

1:rr.wr.R. 929(o),

26 631-c-4,, 1989 ,,N.1

w*TRr9- f:ht .rr7
NOTIFICATION
New Delhi, the 27th October, 2014
G.S.R. 748(E).—In exercise of the powers conferred by clauses (d), (e) and (f) of sub-se tion (2) of Section 35
and clause (c) of section 36 of the Administrative Tribunals Act, 1985 (13 of 1985), the Centra. Government hereby
makes the following rules further to amend the Andhra Pradesh Administrative Tribunal (Prot. dure) Rules, 1989,
namely:-

<!-- page 3 -->

[ITT

,s 3(i)]

1-1101

: 3113TWITT

3

1. (1) These rules may he called the Andhra Pradesh Administrative Tribunal (Procedure) Amendment Rules,
2014.
(2) They sh. 1 come into force on the date of their publication in the Official Gazette.
2. In the Andhr. Pradesh Administrative Tribunal (Procedure) Rules, 1989, in rule 5, in sub-rule (3), the following
proviso shall be in rted, namely:"Provided that the ti

allowed by the Registrar to rectify the defects shall not exceed thirty days."
[ F. No. A-11014/6/2011-AT]

ARCHANA VARMA, It. Secy.
FOOT NOTE.-The principal rul s. were published in the Gazette of India vide notification number G.S.R. 929(E), dated
26th October, 1989.

di 111i

9# q,-41, 27 33-477, 2014
FT.TT.P.. 749 (31).-4, ,, l'4

7,crwmr (2) 477g17 (q), 73" (Z) 31177
(9-)
7911tI
dth.)--+-7r (7-r
-w--7r) ftzrA-, 1986 47

791-7PH7 3ffi1=1,:ui 34-Rfk-44-7, 1985 (1985 TT 13) 49- 9-TrTr 35

-

1. (1) 77 P7zP:ft

ft

2.

=i 9. 1 1

349:TIIRI".11;41

,711

7.77

I

,V-;-1 9.114-71 41i TT: 3*T; 1-,6

f= -7 pH-6715-41 f911-7 a9-rfr

(srf-*-4-r) 9n

."0.417T rt 1 +-I t ,fie.=t, 'SP

if :4

(2)

grrr 36 *
- ITT (71-)

:-

fir 2014 1: I
,

i>r--9-7- AT
1771 ( NT1 ) 97 0-1- 1

OD 47

5 -4. ,,34P1 ,44-; '") —
+1, .1+-Itrli371

1 11,
ttft9.ts1757-1* •1;1(.;

f9fi sTrqr47 ,1 6

17RT

[7r.Fr.

11014/6/2011-7.3T1
.

r•n

311 ,111+-11, '.-1"i1-71'.-1111

77

:

1

f

1-1-7T7

,(1,-1-1

3tfijit1-411

FiT.TT.

T.Fr.RT9-

1 1 30(3T), 11;71 ,1 3 31-477, 1986 7aTT:T

NOTIFICATION
New Delhi, the 27th October, 2014
G.S.R. 749(E).— In exercise of the powers conferred by clauses (d), (e) an (0 of sub-section (2) of Section 35
and clause (c) of section 36 of the Administrative Tribunals Act, 1985 (13 of 1985), the Central Government hereby
makes the following rules further to amend the Karnataka Administrative Tribunal (Proc•dure) Rules, 1986, namely:1.

(1) These rules may be called the Karnataka Administrative Tribunal (Procedure)

endment Rules, 2014.

(2) They shall come into force on the date of their publication in the Official Gazett
2. In the Kamataka Administrative Tribunal (Procedure) Rules, 1986, in rule 5, in sib-rule (3), the following
proviso shall be inserted, namely:"Provided that the time allowed by the Re gi strar to rectify the defects shall not exceed thirty d. s."
[ F. No. -11014/6/2011-AT]
ARCHANA VARMA, It. Secy.
FOOT NOTE.-The principal rules were published in the Gazette of India vide notification number G.S.R. 1130(E),
dated 3 October, 1986.

<!-- page 4 -->

[PART II—SEC. 3(i)]

THE GAZETTE OF INDIA : EXTRAORDINARY

4

di to ri

tt-41', 27 3r477, 2014
rRinTPH-T 31-f4T-Tur 3iffk41:1- , 1985 (1985 TT 13) 'O. a RI 35 *9*T 517-1TTT cI1 kf,„
.51-47.7
(7)
3frT #Y (9) ( 11 niTr 36 *
fk7 n4-.1 Fs:1 d
o (71%-zrr) f4743., 1988 *T 31( Tten-19-

Fr.wr.R. 750 30.— *ft
3wa171- (2) * T (q),
1;PlItiRt

3767:1. (1)

(2) it thrril 4 ITTP17

srfa- ii+11

cm

.44-1 (3) 4, f*wTfkitt7

(311%7T) r97PT, 1988 * fk-zrq 5 *

4-1 v.1 31-9r-rfat

2.

ftTf, 2014 t I

SPIItii;4) 3TRTTITT (VP*-74T)

f473:ft TT 1:TRIRT

34-7:1ii4 t1 11) 441 vi I Q,+I 1, 317i7

. 1=riti-hr-

31-77 3T-4* Cfiti R ,1

1"

3-Trvw 7-#

[Tr. #. 7- 11014/6/2011-7.3-T1
14-11, #71-*-9- 37f:T17.-*T.P... 485(3T), d ..t1-1 22

Tir ',Tr%

.

91 ,t

1988

S4q1- 11ii 111Y 4 1 1.! I

NOT 1C1111.0
New Delhi, the •7th October, 2014
G.S.R. 750(E).— In exercise of the powers conferre by clauses (d), (e) and (f) of sub-section (2) of Section 35
and clause (c) of section 36 of the Administrative Tribunals ct, 1985 (13 of 1985), the Central Government hereby
Rules, 1988, namely:makes the following rules further to amend the Maharashtra Ad 'stradve Tribunalocedure)
(Pr
1. (1) These rules may be called the Maharashtra Administra 've Tribunal (Procedure) Amendment Rules, 2014.
(2) They shall come into force on the date of their publicatio in the Official Gazette.
2. in the Maharashtra Administrative Tribunal (Procedure) Rule 1988, in rile 5, in sub-rule (3), the followirig,
proviso shall be inserted, namely:"Provided that the time allowed by the Registrar to rectify the defects s ii not exceed thirty days."
[ F. No. A-11014/6/2011-AT]
ARCHANA VARMA, It. Secy.

FOOT NOTE.-The principal rules were published in the Gazette of India vide no lcation number G.S.R. 485(E) dated
22th April, 1988.

di

*4;1

i?‘ ill, 27 31-F107, 2014
t, 7RTT4TRT: 3119)777 3TrUfk7TIT, 1985 (1985
.
751(30. Wfizrtit
3M-TP7T (2) * th (7), th- (Z.) 47 Zt-f (9) 7z11- UM 36 * (sis (Tr) urn 1qc."71
* iW7
7R-rmf4T 34-R-+-73-r (5rftzro fk4-7, 1986 TT 317 #R 9 i
—

.

13) 4T
-'

TT

r
f-4-47

317f7
1. (1) 7 -1=H-zi-19=t r #f1:9-7r 7Fr *REIT 1>Tqn t1 RI= 31-RTM (e-f-zrr) #R1-T317 1
(2)r thrt Tx 4 si P1-9"

7Tf -t?4- 4' 719.

201

1

31:fil*TIT (err) 1:474.13-, 1986 * fkz:PT 5 * ayf-N.44- n (3) it,
tit7 3t6:PZirrcr7 "F"+-Zrr ,311411, 3P1-f1
2. ailftgT

RI 35
,

<!-- page 5 -->

i1R-ff .W1 t1'141: 31UTN1771

3(i)]

[ 9471

"Li 1 TfWt7IT gRI 1ft-zetkiTNfi- Tff*fk7 39-gra 371-14cilti ft9- 3TruT.

Mr.#. 7- 11014/6/2011-5r.3L]
3T-4-9-r a 4-11, #77 +71

th=1 ,-o

':TM %Wu! : 41(1

1986 gR1

1-RITK-9-7r tits4111-, Tri.*T.f4.936(3T), 7rfru 4

7-+-Orfff*-7771
NOTIFICATION
ew Delhi, the 27th October, 2014
G.S.R. 751(E).—' In exercise of the owers conferred by clauses (d), (e) and (t) of sub-section (2) of Section 35
and clause (c) of section 36 of the Administra ve Tribunals Act, 1985 (13 of 1985), the Central Government hereby
makes the following rules further to amend the 0 "sha Administrative Tribunal (Procedure) Rules, 1986, namely:1. (1) These rules may be called the Odisha A' ministrative Tribunal (Procedure) Amendment Rules, 2014.
(2) They shall come into force on the date of eir publication in the Official Gazette.
2. In the Odisha Administrative Tribunal (Proced e) Rules, 1986, in rule 5, in sub-rule (3), the following proviso
shall be inserted, namely"Provided that the time allowed by the Registrar to recti v the defects shall not exceed thirty days."
[ F. No. A-11014/6/2011-AT]
ARCHANA VARMA, It. Sect'.
number G.S.R. 936(E) dated
published
in
the
(+a7elte
't
India
Vide
nOtirleari011
FOOT NOTE.-The principal rules were
4th July, 1986.
to

4- , 27 33--47p-T, 201
Frt ft-3r4iNiRtal-ft-*R-13-r 3TR
T4T.vr.fk . 752(311.— ".n.,-F,i)-1
TTIA N. i (2) ITIt7s (7), T (-7—) 6.11-7 47.sr (7) 9-7r um 36 *4.4s (Tr)
fkqlt, 1994 =Fr 31171.#ill--17

, 1985 (1985 7-T 13) fr t414..1 35 -1--Tr
.1r.9-71-447i

Pal -rF-717 1 ,14i tz ,

3-Tzlt :1. (1)..77 -ftlft
(2) it thr141
2.

#nR-T7r 771- 7P9714t

-P11717ft

TWIT f9-7"4 2014 t-

sr-f- -#4 I

11k1 ,1 Q- 71-fr77

(3) k

SPI i tint 3TRT7FT (5ft-tiT) ftliT, 1994 *FiTrIT 5*
7R71:Fr
R7r srlit.;41r, 34"TrEd:
5.
77,7 lre.=1). ,TrTerv9- fk7 3.7w

"'A

..14,1f7:77 u 3Tft-7;

trt-q-T.

r
[ter. TT. 7

-

1014/6/2011-sr.3r1
a4-11,Ti-79- 7rfWq-

facer terra
:
rim
1IPT9' fktr, Tr7

thTILli u 3.1-RaT ti iw 1 m T1T.TT.fk 876(30, Ttiq- 21

, 1994 ,41•0,1

NOTIFICATION
New Delhi, the 27th October, 2014
G.S.R. 752(E).— In exercise of the powers conferred by clauses (d), (e) and (f) of sub-section (2) o Section 35
and clause (c) of section 36 of the Administrative Tribunals Act, 1985 (13 of 1985), the Central Governm nt hereby
makes the following rules further to amend the West Bengal Administrative Tribunal (Procedure) Rules, 1994, mely:1. (1) These rules may be called the West Bengal Pradesh Administrative Tribunal (Procedure) Amendmen. Rules,
2014.
(2) They shall come into force on the date of their publication in the Official Gazette.

\ikc

01 -2—

<!-- page 6 -->

•

-

[PART II—SEC, 3(i)]

THE GAZETTE OF INDIA : EXTRAORDINARY

6

2. In the West Bengal Administrative Tribunal (Procedure) Rules, 1994, in rule 5, in sub-rule (3), the following
proviso shall be inserted, nam ly:"Provided that the time allowe by the Registrar to rectify the defects shall not exceed thirty days."
[F. No. A-11014/6/2011-AT]
ARCHANA VARMA, Jt. Secy.
FOOT NOTE.-The principal rules were blished in the Gazette of India vide notification number G.S.R. 876(E), dated
21' December, 1994.
I
, 27a rc1at,2014
^

7TT.TTR. 753(31). —

5IR =

3i-f9)--+-Ttrr 3A-Rxrq- , 1985 (1985 TT 13) ft UM 35 fr

ZrcIVRT (2) *k.s (7), kis (".) aft +..s

Tqr

36 *. kAs (Tr) gvi

WI I t, P

3T-R-TTErr (vf%-zrr) -Hf -q-q, 2010 wr 417 Tfsit

1. 1 )

fW-4414f

ri 1 +i ;") cl

(2) 4

SI?II ilri

1I 4

!nl..11! ,r11114,,

1:•17,

"Tra7zit

"77417.1

ca * fA7 IWPTIWka. 9-3-47 cT t 3 e7k :

.3TfkfT3T 31r771") 7.#1-"TEM- P47:14:r 2014 t

1 e. t5 14 I1 ca tfil" I

3.779.T

tot

2.

~Tr 1 ,al4i

ttzr-i., 1994 IT

5 't

L.; 3971-7. d1-74-R

31-fr-z-f

,

( )

'71

flt

41 1"
[Tr. #. 7- 11014/6/2011-7.3r.]
31'1 ,11 1 411, t1 40-71 ,.-11"dd

fa7771. : 77

5-177

3rfi.N.71.:4'11 i, aI

FIT.T1'.5".75 7=-T), 11....1..5 14 I:4747T, 2010 qT7

) ..;1 T17, 1
7F-Rf9.' 147
NOTIFICATION
New Delhi, the 27th October, 2014

G.S.R. 753(E).

—

In exercise of the powers conferred by clauses (d), (e) and (f)

sub-section (2) of Section 35

and clause (c) of section 36 of the Administrative Tribunals Act, 1985 (13 of 1985), th= Central Government hereby
makes the following rules further to amend the Kerala Administrative Tribunal (Procedure) les, 2010, namely:ent Rules, 2014.
1. (1) These rules may be called the Kerala Administrative Tribunal (Procedure) Amen
(2) They shall come into force on the date of their publication in the Official Gazette.
2.

In the Kerala Administrative Tribunal (Procedure) Rules, 2010, in rule 5, in sub-rule (3), t e following proviso

shall be inserted, namely:"Provided that the time allowed by the Registrar to rectify the defects shall not exceed thirty days.
[ F. No. A-1

14/6/2011-AT]

ARCHANA VA" MA, Jt. Secy.

FOOT NOTE. The principal rules were published in the Gazette of India vide notification number G.S.
14th September, 2010.
-

Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-I 10054.

758(E) dated
