---
doc_id: "3eac68aeb3ca0fb5"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/935489016a4c7285ecc2af67f8d83086.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment in Recruitment Rules for the post of Despatch Rider, Lady Harding Medicla College and Smt. Sucheta Kriplani Hospital-reg."
date: "2019-04-16"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "37716e6255144ec1"
---

<!-- page 1 -->

( GOVERNMENT OF INDIA.
MINISTRY OF HEALTH AND FAMILY WELFARE
Public Notice on draft Recruitment Rules for the post of Despatch Rider in LHMC &
SSKH, New Delhi

In compliance with DoPT's OM No. AB.14017/61/2008-Estt.(RR) dated 13.10.2015,
the draft Recruitment Rules for the post of Despatch Rider, Lady Hardinge Medical College
and Smt. Sucheta Kriplani Hopsital, New Delhi is annexed.

The stakeholders interested in making any objections/comments or suggestions on. the
draft Recruitment Rules may do so in writing, within a period of 30 days from the date of
publication of draft Recruitment Rules to Sh. Thenkholal Baite, Section Officer (MH-ID,
Room No. 405A, Directorate General of Health Services, Nirman Bhawan, Maulana Azad
Road, New Delhi-110108 or e-mail address: t.baitel2@nic.in

(G.P. Samanta)
Under Secretary to the Govt. of India
Tele: 011-23061521
New Delhi
Dated:

<!-- page 2 -->

1 [TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART il, SECTION 3, SUB-SECTION ({i}]
GOVERNMENT OF iNDIA
( MINISTRY OF HEALTH AND FAMILY WELFARE प्‌
Notification
पु New Delhi, the 2018.
GS.R....— In exercise of the powers conferred by the proviso to article 309 of the
Constitution and in supersession of the Lady Hardinge Medical College and Shrimati
Sucheta Kripalani Hospital, New Delhi, (Group 'C’ posts) Recruitment Rules, 1990, except as
respects things done or omitted 10 be done before such supersession, the President hereby
makes the following rules regulating the method of recruitment to the post of Despatch
rider, namely:-
1, Short title and commencement. - (1) These rules may be called the Lady Hardinge
Medical College and Shrimati Sucheta Kripalani Hospital, New Delhi (Despatch Rider),
Recruitment Rules, 2018,
{2} They shall come into force on the date of their publication in the Official Gazette.
2. Application. - These rules shall apply to the posts specified in Column (1) of the
Schedule annexed to these rules.
3. Number of post, classification, level in pay matrix or pay scale, - The number of the said
post, its classification and level in the pay matrix or pay scale attached thereto shall be as
specified in columns (2) to (4) of the Schedule annexed to these rules.
4, Method of recruitment, age-limit, qualifications, etc. - The method of recruitment, age-
limit, qualifications and. other matters relating to the said post shall be as specified in columns
(5) to (13) of the said Schedule.
5. Disquaiification, - No person, -
(a) who has entered into or contracted a marriage with a person having a spouse living;
or
(b} who, having a spouse living, has entered into or contracted a marriage with ony
person,
shall be eiigible for appointment to the said post:
Provided thal fhe Central Government may, if satisfied that such moniage is
permissible under the personal law applicable to such person and the other party to the
mariage and that there are other grounds for so doing, exempt any person from the
operation of this rule,
6, Power to relax. - Where the Central Government is of the opinion that it is necessary or
expedient so to do, it may, by order, and for reasons to be recorded in writing relax any of
tne provisions of these rules with respect to any class or category of persons.
7, Saving. - Nothing in these rules shall affect reservation, relaxation of age-imit and other
concessions required to be provided for ihe Scheduled Castes, the Scheduled Tribes, the
Other Backward Classes, The Ex-servicemen and other special categories of person in
accordance with the orders issued by the Central Government from time to time in this
regard.

<!-- page 3 -->

SCHEDULE
Name of post. Number of posts, Classification. Level in pay matix | Whether selection
| or pay scale. post or non-
selection post,
Despatch Rider 1(One)* (2018) General Central | Level 2 in the pay Non Selection.
Service, Group | matrix. { Rs. 19900-
‘Subject to variation 'C, Non | 63200).
dependent — on! Gazetted, Non
workload. Ministerial |
Age-limit for direct recruits. Educational and other qualifications required for
. direct recruits.
पु Between 18-25 years 12% pass from a recognized Board with valid driving
license, .
Whether age and | Period of probation, if | Method of recruitment, whether by direct
educational qualifications | any. recruitment or by promotion or by deputation
prescribed for direct /absorption and percentage of the vacancies
recruits will apply in the to be filled by various methods,
case of promotes.
ee
Age-No Two years By Promotion failing which by direct
Qualification--yes recruitment.

<!-- page 4 -->

In case of recruitment by | If a Departmental Promotion | Circumstances in which Union
. promotion or deputation or | Committee exists, what is its | Public Services Commission is to
/ absorption grade from which | Composition. be consulted in = making
«| promotion or deputation/ recruitment.
absorption to be made,
(11) (12) {13)
Promotion from Group ‘C' | DPC (for considering confirmation) Not applicable.
employees in Lady Hardinge | 1.Vice Principal ,LHMC & Smt. S.K.
Medical College & Smit. | Hospital
Sucheta_ Kripalani Hospital |
with three years regular -Cheirman |
service m ne eon 50 2.Addl, Medical i
pay matrix ( Se ” ) Superintendant,LHMC
of the pay mairix.
~Member
3. Deputy Director (Admn.), LHMC
-Member
[A.11018/21/207 6-MHIl]
(G.P. Samanta)
Under Secretary to the Government of India.
