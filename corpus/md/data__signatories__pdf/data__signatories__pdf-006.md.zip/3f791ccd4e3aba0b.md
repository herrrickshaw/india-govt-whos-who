---
doc_id: "3f791ccd4e3aba0b"
source_url: "https://msme.gov.in/static/uploads/2025/06/c2aac48ed0183b193f983830bc141b2e.pdf"
ministry: "Micro, Small & Medium Enterprises (MSME)"
title: "-Revised operational Guidelines of KVY"
date: "2024-07-16"
pages: 46
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ee8d5557cc07bbf8"
---

<!-- page 1 -->

<!-- page 2 -->

Revised Guidelines of
Khadi Vikas Yojana

1

<!-- page 3 -->

Sr.
No.

Page No.

Content

Introduction

01

Modified Market Development Assistance (MMDA)

5-8

02

Interest Subsidy Eligibility Certificate Scheme

09-1'8

03

Khadi Artisans Workshed Scheme

19-21

04

Strengthening
of Infrastructure
of Existing weak
Institutions & Assistance for Marketing Infrastructure

05

Centre of Excellence for Khadi (CoEK)

27-28

06

Khadi Quality Assurance

29-34

07

Marketing Promotion (Exhibitions)

35-38

08

Science & Technology (S&T)Scheme

39-43

09

List of abbreviations

44

10

Glossary

45

2

Khadi

22-.26

<!-- page 4 -->

Revised Guidelines

of Khadi Vikas Yojna (KVY)

lntroduction
Gandhiji envisioned Gram Swaraj through the development of Khadi and
Village Industries. Khadi and Village Industries Commission (KVIC),the nodal
arm of Govt. of India in rural industrialization, strives to improve the socioeconomic conditions of the rural population through a host of schemes
providing support to the non-farm Sector for its all-round development. Such
supports include financial assistance to enhance skills, upgrade technology,
expand the market, augment the entrepreneurs/artisans'
capacity and their
group, and establish linkage with banks for ava.iling requisite capital.
KVIC, as part of its commitment to rural industrialization, has been assessing
rural resources and formulating plans, programmes, and schemes for their
most effective and balanced utilization, thereby helping the rural workforce to
earn a sustainable livelihood, either self-employment or wage employment,
through establishing micro-industries in the hinterland of the country, at very
low per capita investment. The growth of the Khadi and Village Industries (KVI)
Sector has continued unabated, with the catalytic support of KVIC.
Govt. of India, Ministry of MSME, has formulated various developmental
schemes for implementation through KVIC. These schemes primarily focus on
employment generation, productivity, wage enhancement, and social welfare
security of artisans.
Khadi Gramodyog Vikas Yojana:
In the past, the Khadi and Village Industries sector had various separate
schemes developed to meet the Sector's needs. As a part of rationalization, the
Ministry has merged different existing KVI schemes under a umbrella scheme
of "Khadi Gramodyog Vikas Yojana" has two major components for the
development of KVIprogramme.
I.

Khadi Vikas Yojana- wherein the activities earlier carried out under
Khadi are grouped and

II.

Gramodyog Vikas Yojana-wherein the activities earlier carried out under
different village industries are grouped.

Objectives of the Khadi Vikas Yojana:
•

Increase productivity
livelihood.

and wages of Khadi artisans

•

Increase number of artisans

•

Improve infrastructure

•

Increase Khadi production and sales

•

Renovate &modernize sales outlets

•

Promote Marketing and Exports

for Khadi production

3

& secure

<!-- page 5 -->

Components

of Khadi Vikas YoJana:

1. Modified Market Development Assistance (MMDA)
2. Interest Subsidy Eligibility Certificate scheme (ISEC)
3. Work-shed Scheme for Khadi artisans
4. Strengthening of the infrastructure of existing weak Khadi institutions
and assistance for marketing infrastructure
5. Centre of Excellence for Khadi
6. Khadi Quality Assurance
7. Marketing Promotion (Exhibitions)
8. Science & Technology (S&T)Scheme

******

4

<!-- page 6 -->

1. Modified Market Development
A.

Assistance

Introduction

Ministry of MSME introduced expand MPDA scheme in which MMDA was a
part of it and implemented from 3rd Quarter of 2016-17. The MPDA was
subsequently brought under Khadi Gramodyog Vikas Yojana (KGVY) from
2018-19 onwards.
B.

Objectives

The MMDA aims for technology up gradation, engaging design consultants for
developing the new products, value addition by adopting latest technologies in
the post fabric stage/process,
modernization &computerization of sales
outlets, introduction of mobile sales van, engaging external marketing
consultants,
extension of sales discount, capacity building of the sales
personnel and incentives to artisans & Karyakartas thereby improving
production & sale of Khadi.
C.

Eligible Entities for Mmda

The Khadi Institutions (Kls) affiliated/ registered with KVIC, State/UT KVIBs,
State /D'I' KVIB units holding valid Khadi/Polyvastra
and Khadi Mark
Certificate and whose annual budget duly approved by KVIC.
D.

Financial Assistance
1.

Modified
Market
Development
Assistance
(MMDA) for
Cotton/Muslin, Wool and Polyvastra shall be calculated @ 35% on
Prime Cost (cost of raw material + conversion charges up to grey
cloth + processing charges), excluding margin [establishment
expenditure (25%)· and trading (3%), insurance (1%) & bank
interest (4%)].

11.

Modified Market Development Assistance (MMDA)for Silk Khadi
shall be calculated @ 20% on Prime Cost (cost of raw material +
conversion charges up to grey cloth + processing charges),
excluding margin [establishment expenditure (25%) and trading
(3%), insurance (1%) & bank interest (4%)].

111.

Production of Khadi and Polyvastra products for the purpose of
Government supplies under Rate Contract (RC) to be made against
the wholesale target approved by Standing Finance Committee
(SFC) are not eligible for MMDA. However, only artisans and
Karyakartas of those KIs engaged in production and supply in
Govt. supply / Rate Contract will be eligible for MMDAincentive @
17.15% on prime cost. (35-;-100x49).
5

<!-- page 7 -->

E.

IV.

The MMDA will be paid on Prime Cost of regulated Cost Chart
mechanism. Sale price of Khadi and Khadi products fully de-linked
from the regulated cost chart mechanism and Khadi products can
be sold at market linked prices.

v.

The MMDAwill be released on quarterly basis to KIs as per the
approved target through online portal.

Disbursement

of MMDAamong Stakeholders

1.

The quantum of MMDAshall be distributed to the KIs of Cotton/
Woolen Khadi & Polyvastra-(i) producing institutions (34%), (ii)
Selling institutions (17%), (iii) Artisans (35%) & (iv) Karyakartas
(14%). Where a Khadi institution is involved both in production
and selling activities, the amount of assistance shall be 51 % of the
MMDA,which will be utilized for the purpose, enumerated under
1.1 and 1.2.

11.

The quantum of MMDA shall be distributed to the Kls of Silk
Khadi- (i) producing institutions (40%), (ii) Selling institutions
(20%), (iii)Artisans (30%) & (iv)Karyakartas (10%). Where a Khadi
institution is involved both in production and selling activities, the
amount of assistance shall be 60% of the MMDA, which will be
utilised for the purpose as enumerated under 1.1 and 1.2.

F.

Utilization of MMDAby various Stakeholders

1.1

Producing Khadi Institution
of Artisans):

(for production

growth/increase

in No.

1.

The producing institutions shall utilize their entitled MMDA for
procuring tools & equipment / up-gradation of technology.

11.

Engaging designers & consultants for improving the existing designs
and introduction of new designs and latest fashion.

111.

Value addition to post fabric process.

IV.

Engaging technicians
other equipment.

v.

This is an indicative list and Kls may take up any other initiative
activities related to Khadi Production.

1.2

Sellin.g Khadi Institutions

for maintenance

of Charkhaa/

Looms/ and

(for sales growth/ reduction of Stock)

1.

The. selling Institutions shall utilize their entitled MMDAfor all sales
promotional activities
by way of introduction of computerization/
bar-coding/ billing/ debit / credit card swiping machine, accounts,
renovation of sales outlets.

11.

Introduction of mobile sales van, participation
international exhibitions.

111.

Extension of sales discount/ discount on whole sales for clearance of
stock.
6

in domestic and

<!-- page 8 -->

IV.

Capacity building of sales personnel.

v.

This is an indicative list and KIs may take up any other innovative
activities related to Khadi Sales.

1.3

Quantum of incentive to Artisans and Karyakartas
1.

35% of total MMDA amount shall be passed on to the spinners &
weavers and 14% of total MMDA shall be passed on to Karyakartas
engaged in the production/ sales activities of Cotton, Woolen, &
Polyvastrain the form of incentive or bonus through their bank/ post
office accounts.

11.

30% of total MMDA amount shall be passed on to the reelers/
twister / winders & weavers and 10% of total MMDAshall be passed
on to 'Karyakartas or maximum ceiling of Rs. 10,000/- per quarter
per Karyakartha, whichever is less under Silk Khadi, in the form of
incentive or bonus through their bank/ post office accounts.

111.

The incentives of the Artisans as well as Karyakartas are to be paid
through Aadhar seeded bank / post office accounts only through
Direct Benefit Transfer (DBT) by Khadi and Village Industries
Commission.

G.

Monitoring and Evaluation
1.

The KVIC will ensure proper, effective utilization of financial
assistance under the scheme by applying necessary checks & balances
from time to time. The Khadi Institutions has to furnish quarterly/
annual Utilization Certificate as per Annexure-I.

11.

An officer of Group-A/Class-1 of State/ Divisional Office / Zonal
office/Central Office may conduct random verification.

111.

KVIC shall evaluate the scheme both at midterm and at the end of
Finance Commission Cycle.

IV.

KVIC maintains on-line portal for disbursement of MMDA through
Direct Benefit Transfer (DBT)as per the procedure in vogue.

v.

Nodal Officer / Directorate:
Phone nO.022-26714325

Directorate of Khadi, KVIC, Mumbai*******

7

<!-- page 9 -->

(ANNEXURE-I'
DETAILS OF UTILISATION STATEMENT OF MMDA GRANT
Name
Board

1.

of

Institu tion /

Code No.
2.

Year
claim

of

MMDA

3.

Quarter

4.

Receipt
MMDA

of

total

a)

MDA earned
prime cost

on

Rs ..........................

b)

MMDA earhed
purchases

on

Rs ............. .,............

(I / II / III/IV)

Rs............. .,............

Total
UTILIZATION OF MMDA
Details of utilisation
Grant

Sr.
No.
I

of MMDA

Amount
(Rs.)

towards
Product
Utilisation
development (as per 3. 1 of OM dated

-------------)
II

Towards Market Development (as per
3. 2 of OM dated ------------)
Total

(In case of composite institutions they may furnish U.C. for I & II and in case
of marketing institutions they may furnish U.C. for II above).

Chartered

Accountant

Signature

of Secretary

Note: Quarterly UCs shall be furnished by KIs and annual
furnished by Chartered Accountant (CA).

*****

8

with seal

UCs shall be

<!-- page 10 -->

2. Interest

Subsidy Eligibility Certificate

Introduction:
The Government ofIndia vide their letter No.4 (47/75-KVI (I)dated 17-5-1977 have
approved a comprehensive interest subsidy scheme for institutional financing of
the Khadi and Village Industries Programme.
1. The Interest Subsidy Scheme shall be applicable to the following types of
loans from institutional financing agencies.
(i)

Loans raised by the Khadi and Village Industries Commission (KYIC)for
disbursement as capital investment and working capital loans to:
(a) A State Khadi and Village Industries Board:
(b)A registered Institution:
A registered institution means an institution
registered under the Societies Registration Act 1860 (21 of 1860) or under
any other law for the time being in force in any State.
(c) ACo-operative Society: A co-operative society means, a society registered
under the Co-operative Societies Act 1912 (2 of 1912) or under any Cooperative law for the time being inforce in any State. This includes the
industrial co-operative societies, the service co-operative Societies and the
block level multi-purpose co-operative societies.
(d)A trust created for public purposes of a charitable or religious nature.

(ii)

Loans raised by the Khadi and Village Industries Commission for purchasing,
stocking and distribution of raw materials to registered institutions and cooperative societies and for the production and sales activity undertaken by
the Commission departmentally.

(iii)

Loans raised by the State Khadi and Village Industries Boards for
disbursement of capital investment and working capital loans to institutions
/ co-operative societies / individual artisans or to meet requirements of its
departmental activities connected with the production and sales of Khadi and
Village Industries products.

(iv)

Loans raised by the Registered Institutions to meet their capital investment
and working capital needs.

(v)

Loans raised by the co-operative societies to meet their capital investment
and working capital needs.
2. The interest subsidy will be admissible on the funds raised for the
development of Khadi and Village Industries, as specified in the schedule of
village industries in the KVICAct. The industries which may be specified
from time to time in pursuance of Notification under Section 3 of the said
Act also will qualify for the interest subsidy.

9

<!-- page 11 -->

3. Financial Institutions will include all the scheduled and non-scheduled
banks (including the State Bank of India and its subsidiaries, nationalized
banks and co-operative banks).
State Financial Corporation, Industrial
Development Bank of India and other financial institutions which are
created; registered under Act of Parliament or State Legislatures.
4. The quantum of subsidy shall be limited to the difference between the actual
rate of interest charged by the financing institutions and 4 (four) percent to
be borne by the borrower. If at any stage interest rate charged by the Khadi
and Village Industries Commission is modified, the quantum of subsidy shall
be limited to the difference between the rate of interest charged by the
financial institutions and such modified rate of interest.
5. The scheme shall be implemented in the following manner.
(i)

At the time of sending budget proposals to the budget section of field
offices under KVIC, the institution aided with State Khadi and Village
Industries Boards will indicate separately funds likely to be made
available to them from the banks industry-wise, purpose wise and also
institution wise. As regards the directly aided institutions ; co-operative
societies, similar information will be sent by the concerned institutions ;
co-operative societies to the concerned State; Divisional Directors of the
Khadi and V.I. Commission, before the budget discussions are held.

(ii)

After the receipt of the above information by the budget section of the
Commission ; State; Divisional Directors of the Commission, discussions
will be held at the time of Annual Budget discussions with the concerned
State Boards; Institutions; co-operative societies and the programme for
the institutional financing will be finalized. After the discussions are held
by the State; Divisional Directors or at the H.O. of the Commission
proposals of directly aided institutions, co-operative societies as well as
board aided institutions etc. will be sent to the Zonal Dy. CEO's approval
and to concerned industry;
programme directors who will place their
proposals before SFC for its ratification.

(iii)

After the proposals are approved by the Zonal Dy. CEO's, the Bank
Finance Cell will receive copies of the approval of the Zonal Dy. CEO's,
only such DAl's ; BArs whose names are included in the approval
accorded by the Zonal Dy. CEO's will qualify for issuing interest subsidy
eligibility from the Commission.

(iv)

On the basis of the limits approved by the Zonal Dy. CEO's in respect of
bank borrowings for different purposes the Bank Finance Cell in field
offices under KVIC will issue interest subsidy eligibility certificates in
favour of the concerned State Boards ; Institutions ; co-operative
societies etc. aided by KVIC; KVIBas per format-I (B).

(v)

In respect of institutions and co-operative societies working under the
State Boards, the State; Divisional Directors will issue the Interest
Subsidy eligibility certificates for borrowings by these agencies from banks
within the limits indicated in the Interest Subsidy Eligibility Certificate
issued in their favour by the commission under Para (iv)above.
10

<!-- page 12 -->

(vi)
"

The Interest Subsidy Eligibility certificate to be issued by the Commission
would be signed by the Chief Executive Officer of the Commission or he/
she may delegate powers to the Dy. Chief Executive Officer (K), Dy. Chief
Executive Officer (V.I.) or State/ Divisional Directors under KVIC,
communicates that the Interest Subsidy Eligibility Certificate to be issued
by the State Boards in respect of institutions and societies/working under
them
should
be
signed
by
their
C.E.O./Secretary/Executive
Officer/ Administrator, otherwise State/ Divisional Directors issues ISEC
for both DAl's/ BAl's as per format-1 (A)& 1(B)

(vii) On the strength of the Interest Subsidy Eligibility Certificate the State
Board/institutions/co-operative
societies etc., will negotiate with their
bankers for the required financial accommodation.
(viii) The final decision to accept or reject any loan application from eligible
borrowers will vest with the banks. However, in case the banks reject
some applications they may indicate to the Commission/the State Board
the reasons for rejecting the loan applications.
(ix)

The Commission will have no liability of any kind either in respect of the
principal amount of loan or payment of 4 per cent (or at revised rate)
interest to be borne by the borrowers for which interest subsidy eligibility
certificate has been issued by the Commission, or by KVIB. Its liability
shall restricted only to the extent of payment of interest subsidy as per
scheme.

(x)

The concerned institutions/State
Boards will inform the Commission
about the amount sanctioned by the banks in each case, the terms and
conditions (about the rate of interest, the tenure of loan etc.) on which
such amount are sanctioned and the position about the release/ drawl of
funds against such sanctions as soon as the loans/limits are sanctioned
by the banks and availed by the institutions/ State Boards etc.

(xi)

In respect of directly aided institutions (including State Boards) the banks
shall advise the Commission about the sanction and disbursement of
loans to the borrowers in respect of whom the interest subsidy eligibility
certificates are issued by the Commission giving reference to the Interest
Subsidy Eligibility Certificate issued by the Commission.

(xii) In respect of the institutions and co-operative societies whose loan
applications have been recommended by the State Khadi & V.1. Boards,
the banks shall advice regarding the sanction and disbursement of loans
to such borrowers to the concerned State Khadi and V.1.Boards.
(xiii) The bank will advise to the Commission/State Boards sanction
disbursement of loans (vide Para xi and xii) in Form No.2.

and

(xiv) The State Khadi and V.1. Boards, the State/ Divisional Directors of the
Commission and the Khadi and V.1. Commission, Mumbai will maintain
interest subsidy claim register in Form No.3, industry-wise.

11

<!-- page 13 -->

(xv)

In respect of institutions (including State Boards) whose interest subsidy
eligibility certificates are issued by the Commission, the banks shall
submit their interest subsidy claims in Form No.4 giving reference to the
interest subsidy eligibility certificate No. and date and also the No. and
date of bank's payment advices and release of funds. These claims may be
sent to the Commission's concerned State Directors who will scrutinise
the claims and send the same to the Bank Finance Cell of the
Commission, for payment.

(xvi) In respect of institutions and co-operative societies whose interest subsidy
eligibility certificates were issued by the State Khadi and V.1. Boards, the
banks shall submit to the concerned State Boards their interest subsidy
claims in form No. 4 giving reference to the interest subsidy eligibility
certificate No. and date issued by the State Boards also the No and date of
the bank payment advises of release of funds. The concerned State Khadi
and V.1.Boards will scrutinise the claims and send the same to the Bank
Finance Cell of the Khadi and V.I. Commission for payment.
(xvii) The claims received by the State/ Divisional Directorate of the
Commission must be countersigned by an officer not below the rank of
State/ Divisional Directors of the Commission.
(xviii)In respect of claims received by the State Khadi and V.1.Boards the claims
must be countersigned by an officer not below the rank of Secretary/Chief
Executive Officer/Executive Officer / Administrator of the State and V.1.
Boards.
Note: (i) For the loans raised by the State Boards, to meet the requirement of
their department activities or for disbursement (vide para2 (iii) the
procedure prescribed for the directly aided institution would be followed.
(ii) These payment being of a routine nature and of committed character
like sales rebate etc. no specific sanction of the Standing Finance
Committee would be necessary for individual payment. However, they
would be covered by the budget allocation made for interest subsidy to be
paid to the banks.
(iii) Directorate of Accounts in Central Office shall arrange payment of
interest subsidy amount as per the instructions of the Bank Finance cell
under advice to the section and the concerned State Director or the State
Khadi and V. I. Board, who would make the note of such payments in
their registers of claims.
(iv)lt may be necessary to open a proper head in the monthly and annual
accounts statements of the Commission, to indicate the disbursement of
interest subsidy to the banks.
6. KYIC shall disburse Interest Subsidy through online portal directly to the
concerned financed banks.

******
12

<!-- page 14 -->

IS/BF /FORM NO.1 (A)
INTEREST SUBSIDY ELIGIBILITY CERTIFICATE
To be issued to the State Khadi and Village Industries
1)

Name of the State Board

2)

Name
of
the
Institutions/ cooperative societies, whose budgets
were approved by the Commission,
alognwith the limits of bank's
borrowings
sanctioned
by
the
Commission
(Industry-wise,
purpose-wise)

3)

The Khadi and Village Industries
Commission agrees to the State
Board surrendering its first charge
on the
assets
of the above
institution in favour of the Banks

4)

The State Boards should issue to
the
Banks
Interest
Subsidy
Eligibility Certificate In respect of
the above institution in Form No.1

Board

(B)

The Commission would be liable to
pay interest subsidy as per the
scheme only for the period for which
the loan is sanctioned by the bank
and is not liable to pay such
interest subsidy for the defaulted
period

5)

Chief Executive Officer
Khadi and Village Industries Commission
To,
C.E.O./E.O./Secretary/Administrator
(Khadi and Village Industries Board)
Copy to:

13

<!-- page 15 -->

IS/BF /FORM No.1 (B)
Address

{Ofthe State Office/State Board)
No. IS/
(State)

(Industry) (Running No.)
Date:INTEREST

.

SUBSIDY ELIGIBILITY CERTIFICATE

Full Name of the borrower
Complete address of the borrower
Industry
Purpose
Amount of loan (Rs.)
The above mentioned (Institution) has applied to
(Narne and address of the Bank)
For a loan of
Rs.

__

for

___
(purpose and industry)
The

above

loan

upto

Rs.

Will be eligible for the interest subsidy payable by the Commission in terms of Govt. of
India, Ministry of Industry (Dept. of Industrial Development) letter No.4 (47)/7S-KVI(1)
dated the 17thMay, 1977.
The Commission agrees to surrender its first charge over the assets (moveable
and immoveable) of the above institution in favour of the Banks.
The final decision to accept or reject any loan application from eligible borrowers
will vest with the banks. However, in case the banks reject some applications they
may indicate to the Commission/the State Boards the reasons for rejecting the loan
application.
The Commission will have no liability of any kind either in respect of the
principle amount of loan or payment of 4 per cent or revised rate of interest to be
borne by the borrowers for which interest subsidy eligibility certificate has been issued
by the Commission. Its liability shall be restricted only to the extent of payment of
interest subsidy as per scheme.
14

<!-- page 16 -->

The Commission would be liable to pay interest subsidy as per the scheme only

10r the period for which the loan is sanctioned by the bank and is not Hable to pay
such interest! subsidy for the defaulted period'.
This is iesued for the year

..

'Fa,
State / Divisional Director

15

<!-- page 17 -->

IS/BF/FORM NO.2

Bank
(Name & Address)
No.

_

Date:

__

To:
(Address of the State Office/State Board/institution/Cooperative

Society)

Sub:- Advice about payment of

_ to

Sub:- Advice about payment of Loan of Rs.
for

_

under the Interest Subsidy Scheme of the

KVIC.
Ref:- Your Interest Subsidy Eligibility Certificate No.

_

date

Sir,
With reference to your above mentioned Interest Subsidy Eligibility
Certificate,

Rs.

I am to advise you that our bank has sanctioned/disbursed
to
for
on

a loan for
_

(Date)
The loan carries an interest at

%

and is repayable in
Yours faithfully,

Agent / Manager
___________
Copy to: The Director (Bank Finance)
Khadi and V.I.Commission,
MUMBAI-400 056.
16

Bank

<!-- page 18 -->

IS/BF /FORM No.3

Industry
INTEREST SUBSIDY CLAIMS REGISTER

Date

Full
name of
the
borrower

1

2

Complete
address

Amount
of loan
applied
for

Purpose
of the
loan

Number

Date

Amount

Narne of the Bank

3

4

5

6

7

8

9

Interest Subsidy Eligibility Certificate

Bank's Payment Advice
No.&
date
of
advice

Amount
of loan

Date of
payment

Tenure

10

11

12

13

Interest subsidy claims
Rate of
Interest

Mode of
recovery
of
interest

Date of
receipt

Period

14

15

16

17

17

Amount

18

Sent to
head office

Payment Advice

No.

Date

Amount
Paid

19

20

21

Date of
Payment
22

Remarks

23

<!-- page 19 -->

IS/BF IFORM NO.4
BANK
(Name and Address)
No.

Statement of Interest Subsidy payable by Khadi and Village Industries Commission

In respect of advances to Khadi and Village Industries Institutions/Co-operatives

for

~------_
(period)

Sr.No

Name & Address of Amount
the borrower
Loan
disbursed
(Industry
wise)*
1

2

Difference to
be paid
by
the KVIC(6) -

of Amount of interest
the Bank
Rate

3

at the Normal lending rate of Amount of interest at
4% recoverable from the
borrower
Period
Amount

4

5

Interest subsidy Eligibility Certificate

6

7

Banks's Disbursement Advice

Remarks

(7)

Issuing authority
8

9

Number
10

Date

Number
11

Date
12

13

14

This is to certify that the amount of interest subsidy claimed herein has not been received from the KVICso far by the Bank
* Statement of Accounts to be enclosed:
Agent
State office KVICofficial

State Khadi & V.1. Board official
18

Bank

<!-- page 20 -->

3. Workshed
A.

Scheme

for Khadi Artisans:

Introduction
Khadi activity is a source of livelihood for about 5.00 lakh artisans
engaged, as spinners, weavers, other artisans etc., spread across rural India.
Khadi sector represents the continuity of age-old Indian heritage of hand
spun and hand woven cloth, reflecting socio-cultural-tradition of the
country. The Work shed Scheme for Khadi Artisans (WSKA)encourages
artisans to spend more time on Khadi activities, with a congenial atmosphere
for their sustainable earnings by possessing their own work place. KVICis
implementing the Work shed Scheme for Khadi Artisans (WSKA)since 20082009.

B.

C.

Objectives
i.

To provide a better work place to Khadi Artisans to carry out their
spinning and weaving activities efficiently.

11.

To provide storage space - for raw material, implements, accessories,
semi-finished, finished goods, etc.
Eligibility

i. The artisans working with KIs affiliated to KVICjState KVIBs, including
their departmental activities shall be eligible for the scheme. The artisans
covered under AWFT,MMDAincentive, worked at least 100 days in a yearpreference shall be given to BPLcategory.
ii. The title of the land should be in the name of the artisan and or his jher
spouse.
Or

Any ancestralj family property for which consent is obtained legally can be
considered for construction of workshed.
Or

The land allotted by the State Govt.jPanchayat etc. to the artisans will also
qualify for construction of workshed.
iii. The Group Work shed may be constructed on the land owned by the KIs

and it must be leased out to the artisans for a period of minimum 10 years.
iv. Artisan availed similar benefit previously from KVICjCentraljState Govt.
will not be eligible. However, if such work shed are damagedj destroyed
due to natural calamities but did not receive any compensation, shall be
considered for the scheme after obtaining desired Certificate from the
concern Local Authority.

19

<!-- page 21 -->

v. The construction
cost if increased, the beneficiary need to bear the
additional cost by withdrawing from the available AWF credit. In case of BPL

category additional requirement of fund, the sponsoring KI shall arrange
without insisting from the artisan.
D.
1.

Financial Assistance
The financial assistance for construction of Individual as well as Group
work shed w.e.f. 01.04.2022 is as under:

Component

Area
unit

per Amount of Assistance

Construction of 20 Square Rs.l, 20,000/- or 75% of the cost of
Individual work meters
the work shed including toilet,
shed including
whichever is less.
toilet
For
North-Eastern
region
Rs.l,
20,000/ -or 90% of the actual cost of
the work shed
including toilet
whichever is less.
Construction of 10 Square
Group
work meters per
shed including Artisan
toilet (Minimum
5 Artisans &
Maximum
15
Artisans)

Rs.80,000/- Per Artisan or 75% of the
cost of the work shed, including toilet
whichever is less.
For North-Eastern region RS.80,OOO
/Per Artisan or 90% of the actual cost
of the work shed including toilet,
whichever is less.

11.

Cost of land will not be part of project cost. Financial assistance will be
for the purpose of construction of work shed only.

iii.

Financial assistance will be released in two (2)equal installments - one
on clearance of proposal by the Committee and the other one after
physical verification progress.

IV.

A Work shed Committee shall be constituted with one member having
civil engineering background.

20

<!-- page 22 -->

E. Workshed

Committee:

The proposal for Workshed received from the KI:s shall exam~ne and recommend
by the Committee comprising of the following members.
- Chairman
1. State/ Divisional Director
- Member
2. CEO/Representative of State KVIBoard
3. Chairman / Secretary of State Level Khadi
Federation or Parent body of Khadi Institution
Viz. TNSSm Tirupur, Shri Gandhi Ashram,
Lucknow/ Major Khadi Institution.

- Member

4. Accounts officer, SO/ DO of KVIC

- Member

5. An engineer not below the rank
Of Asst. / Executive Engineer
Of State KVIB/ State Govt.Agencies.
F.

- Member

Monitoring and Evaluation Of Scheme
~ The KVIC shall ensure proper, effective utilization of financial
assistance under the scheme by applying necessary checks & balances
for which KVIC shall issue detailed modalities for monitoring of the
scheme for its effective implementation.
~ KVIC shall arrange to conduct physical verification through their
technical staff while & after construction of Workshed.
~ An officer of Group-Az Class-I of State/ Divisional Office / Zonal Office

/ Central Office may conduct random
sheds.

physical verification of work

~ The State/Divisional Directors shall furnish utilization certificates in
GFR 12A format on both the occasions of 1st and 2nd installment as per
the procedure in vogue.
~ KVIC shall evaluate the scheme both at midterm and at the end of
Finance Commission Cycle.

>- Nodal Officer / Directorate:

Directorate of Khadi, KVIC, Mumbai-

Phone no.022-26714325

*******
21

-----

<!-- page 23 -->

4. Strengthening of Infrastructure of Existing Weak Khadi
Institutions
(SIEWKI) and
Assistance
for
Marketing
Infrastructure
A.

Introduction
Production of Khadi, the handcrafted textile, is an artisan intensive
activity. Most of the artisans work from their dwelling places paving the way
for engagement of a large number of women artisans. The Khadi institutions
were working since inception of the Commission with large infrastructure,
passage of time for various reasons the financial condition and the
infrastructure have gradually been deteriorated, resulted in dilapidated
condition, tools & equipment were in obsolete condition requires repairs and
renewals for which financial assistance felt essential.
There
are
some
sick/weak/problematic/"D"
category
khadi
institutions spread throughout the country with strong artisan base and
- good landed properties with infrastructure requires renovation, repairs,
renewal. The Commission has adopted a system of evaluating institutions in
terms of turnover and performance as to "A+", "A", "B", "C" & "D" and "D"
category is considered as an institution requires nursing fund for restoration
to its normal functioning at the earliest. In order to reviveI restart the Khadi
activities by such Kls, a scheme was formulated and in implementation since
2009-10.

B.

Objectives
i.

To bring the sick/ weak/ problematic/ D-Category Khadi institutions
into normal, having adequate infrastructure and landed prope:ty, but
structure requires repairs - unused condition of tools and equipment,
possessing sufficient skilled artisans.

ii.

Make an effort to overcome the existing 'near stagnatio~' to nor~alcy
and bring transformation of Khadi artisans to provide sustainable
employment.

111.

iv.

Make use of infrastructure after renovation, repair, renewal etc.
1m rove marketing of khadi products by renovation of sales outlets
and introduction new designs and producing ready to use products.

22

<!-- page 24 -->

C.

D.

Eligibility
1.

Khadi Institutions having adequate infrastructure
which are
sick/weak/problematic/"D"category institution requires renovation,
repairs, renewal - having experienced skilled artisans, needs funds for
procurement of raw material and payment of wages.

ii.

Khadi Institutions ready to negotiate for working partnership with
parent bodyI neighboring institutions to achieve better performance.

iii.

Khadi Institutions desires to avail bank finance under ISEC scheme for
further requirement of working capital.

Financial Assistance
[Rs, in lakh)

Sr.
Component
No
(I) Capital Expenditure
l. Repairs, overhauling of implements,
purchase of accessories and spare
parts
2. Repair of work sheds I godownI sales
outlets I officeincluding furniturefixtures to make those functional
Procurement of new implements
[Charkha & Loorrr/ Readymade
Garment Unit etc.)
(II) Working fund
1. Purchase of raw material
3.

2.
3.

4.

i.

Payment to artisans
Other production overheads such as
Supervision, Sales Distribution
Expenditure, Processing, fabric
conversion
Payment of statutory dues such as
P.F., Municipal Tax etc., Payment of
interest to the Bank loan for
renewal etc.
TOTAL ( I + II )

Cost

Total Cost
Rs.5.75

Rs.0.75

Rs.1.50

Rs.3.50

Rs.9.25
Rs.4.00
Rs.3.00
Rs.1.50

Rs.0.75
Rs. 15.00

All costs mentioned above are indicative and interchange of heads is
permitted subject to ceiling of Rs.15.00 lakh.
23

<!-- page 25 -->

ii.

The institution will submit comprehensive revival plan. The Khadi technical
officials visits and furnishes
technical
feasibility report. The revival
committee constituted by KVIC clears the proposal. The financial assistance
will be released in two installments. The State/Divisional Director releases
50% as 1st installment and the 2nd installment will be released based on

physical verification report.
iii.

The State/Divisional Directors furnishes utilization certificates in GFR 12A
format on both the occasions of 1st and 2nd installments as per the procedure
m vogue.

iv.

On completion of the
completion report.

scheme, the institution

II. Assistance for Marketing Infrastructure
A.

shall furnish

scheme

(AMI)- Sub Scheme

Objective
The sub scheme will aim at achieving higher sales in the assisted
outlets of KIs so as to bring sustainability in the process of production in
Khadi sector and will emphasize on improving the usage of common logo/
signage, the brands, sales of products of assured quality, improved shop
ambience through better decor, visual merchandising and functional
improvement through computerization/ bar coding etc.

B.

Eligibility
1.

Khadi Institution registered and/financed by KVIC or State ZU'TKVI
Boards with target/budget from KVIC/KVIB.The Kls must possess
valid Khadi Certificate & Khadi Mark certificate.

ii.

Sales outlets owned/Rented/Leased Outlet by the Kls. In case of
Rented/Leased sales outlets an agreement for minimum five (5) years
while or after the renovation of sales outlets of Khadi Institutions is
required.

24

<!-- page 26 -->

"

C. Financial Assistance for Marketing Infrastructure
i. The assistance under Marketing Infrastructure
institutions will be as follows:-

Scheme for the selected
[Rs. in Lakh)

Sr.

Funding Pattern

Govt.
Grant

Contr.

a)

Departmen tal Sales
Outlets of KVIC

Govt. Grant - 100%

25.00

0.00

25.00

b)

Departmental Sales
Outlets of KVIBs

21.25

3.75

25.00

c)

Institutional Sales
outlets (Metro cities)

Govt. Grant - 75%

18.75

6.25

25.00

Institutional outlets

Govt. Grant - 75%

(Non- Metro cities)

Inst. Contr. - 25%

15.00

5.00

20.00

No

(d)

ii.

Inst's

Component

Govt. Grant - 85%
Inst. Contr. - 15%
Inst. Contr. - 25%

Total

40% of the aggregate annual turnover of retail sales of the Institution during
the last three years may be reckoned for extending financial support under
the scheme. Any additional cost over & above the sanctioned limit will be
borne by the KIs. The maximum assistance shall be @Rs. 2500/- per sq. feet
for renovation of the sales outlets of KIs subject to the maximum limit
prescribed in the above table.
NEZ notified hilly areas, A&NIslands, Lakshadweep etc. will be eligible for
90% of the assistance considering the topographical areas.

iii.

The institution's own contribution as proportion of the accepted project cost
will be as follows:
Departmental Sales Outlets of KVIC

--Nil--

Departmental Sales Outlets of State
/ UT Boards

15% of the project cost

Institutions registered and financed
by KVICor State / UT KVIBoards.

25% of the project cost

(Note: Institutions are permitted to mobilize their contribution through
Bank also.)

25

<!-- page 27 -->

Note: The average project cost has been worked out at Rs.25 lakh per sales outlet
of which 15% and 25% will be contributed by the KVIB and Khadi
institutions respectively while the assistance will be 100% in respect of 4
outlets managed by KVIC. In case of outlets, other than the departmental
outlets of KVIC and KVIBs, the maximum assistance provided will be
Rs.18.75 lakh for outlets located in metropolitan cities and Rs.15.00 lakh in
other places which is further subject to a maximum of 40% of the aggregate
annual turnover of retail sales of the Institution during the last three years.
Any additional cost over & above the accepted limit will be borne by the KI.
D. Release of Fund
i) The funds will be released in three instalments of 40%+40%+20%by
80S/DOs.
ii) The full Contribution of the Kls to be utilized along with the first two
instalments. The final instalment will be released to the Kls on completion of
entire work as per the approved proposal.
iii) Departmental KGBs of KVICwill receive the funds in two equal instalments.
E. Committees for consideration

of proposal of renovation Sales Outlet

at Zonal Level
The committee comprising Dy. CEO (Zone), Concerned 80/DO Director as
Convener, Representatives from KVIB & KI, FBAAOfficer as members; will
assess the Renovation proposals and recommend to the KVIC, Mumbai for
approval.
F. Monitoring and Evaluation of Scheme
The KVIC shall ensure proper, effective utilization of financial assistance
under the scheme by applying necessary checks & balances from time to
time.
1.

The Khadi Technical officials conduct
monitoring of programme.

visits periodically for effective

ii. KVICshall evaluate the scheme both at midterm and at the end of Finance
Commission Cycle.

*****

26

<!-- page 28 -->

5. Centre of Excellence

for Khadi (CoEK):

Introduction
KVICunder its Khadi Vikas Yojna (KVY)has decided to set up 'Centre of Excellence
for Khadi' in association with National Institute of Fashion Technology (NIFT)to
develop new Khadi Products of high end domestic and international market and to
strengthen khadi brand.
NIFT is a premier institute of design, management and technology with 17
campuses across India and it has emerged as a Centre of excellence and
innovation with a distinctly conscious concern for social responsibility. KVIC has
set up of Centre of Excellence for Khadi in Hub and Spokes model in five NIFT
Campuses viz NIFr Delhi, NIFT Kolkata, NIFT Gandhinagar, NIFT Shillong and
NIFr Bengaluru & the project period is for three years.
Areas of Association:
i.

The CoEK will work on creating benchmarked
standards for Khadi.

design process of global

11.

Create new fabric and products based on the season-wise colour forecast
and fashion trends.

iii.

Disseminate quality standards for fabrics and clothing for high-end domestic
and international market.

iv.

Branding and publicity by creating interesting narratives around new Khadi,

v.

Creative visual merchandising and packaging for new Khadi products.

vi.

Increase the global reach of Khadi by organizing National & Intemational
Khadi fashion shows and exhibitions.

vii.

Any other activity that may be mutually agreed upon between NIFT & KVIC.

Budget
Budget I Financial Sanction

Operative Head

1st Year 2nd Year

3rd Year

Total

OPEX

662.20

695.20

695.20

2052.60

CAPEX

165.00

0.00

0.00

165.00

lTotal Direct Expense

827.20

695.20

695.20

2217.60

NIFTAdministrative & Infrastructure
Overheads (AIO)20%

165.44

139.04

139.04

443.52

Total Amount

992.64

834.24

834.24 2661.12(*)

(*) Additional expenses of Rs. 6 - 7 Cr will be met out from Internal
Revenue Generated (IRG)from the operations.
27

<!-- page 29 -->

Evaluation

of Monitoring:-

Coordination Committee for CoEK comprising of DG-NIFT, CEO-KVIC, FA-KYIC
and Director-CoEK for coordination and regular interaction on the matter related
to CoEK.
Advisory Committee under the Chairmanship of Secretary (MSME)and comprising
of JS (ARI),MSME (Co Chairman), JS- Ministry of Textiles, CEO- KVIC& DirectorCoEK, NIFT and other members from 5 various categories.
Expected outcome of the project
Build a new narrative around Khadi fabrics and design for branding,
packaging, product positioning of new Khadi fabrics, apparels and products
developed by CoEK.
•

Make Khadi fashionable for youth.

•

Participation in fashion shows and Exhibitions.

•

Specialized training of trainers for pattern masters and tailors at NIFT.
Help selective Kls to increase their business through the assistance
designs and quality of finished product.

•

Improve Khadi footprints nationally and globally.

•

Strengthen Brand Khadi.

*****

28

of

<!-- page 30 -->

Roles and Responsibilities of Accredited Agency

i.

Followingare the role and responsibilities of the accredited agency:
•

Draw the samples of Khadi and Khadi products as part of onsite verification
and carry out laboratory testing of drawn samples for the use of natural fiber
along with other agreed test parameters.

•

Submit to KVIC its verification report along with recommendation for
registration and Khadi Mark Tag and label entitlement of the persons and
certified Khadi Institutions applying for Khadi Mark registration.

•

It has to inspect the Khadi Production process through physical inspection
at applicants production centers as per the format prescribed by KVIC

•

An indicative list of items that needs to be verified randomly during the
physical inspection at the premises of person/ organizations are as follows:
1. Details of Khadi activities; Production/Sales / Exporrt,
2. Number of production centre
3. Number of Sales Outlets
4. Number of Spinners
5. Number of Weavers
6. Number of Artisans
7. Number of Staff
8.Products manufactured as per the list provided by the applicant.
9. Adherence to process of Khadi Production i.e. 'Hand Spinning on
Charkha and Weavingon Handlooms'.

•

Undertake 'Khadi Mark Tag and label management' including planning,
printing and stock maintenance of tags and labels and issuance of tags and
labels to persons and Certified Khadi Institutions registered under the Khadi
Mark Scheme.

•

Carry out annual verification registered persons and certified Khadi
Institutions draw samples as part of annual verification and carry out
laboratory testing of drawn samples to ensure the continued compliance to
Khadi Mark criteria and continued suitability of label entitlement.

•

In addition to the sample drawn and tested as part of onsite verification and
annual verification, Textiles Committee shall carry out laboratory testing of
Khadi and Khadi product samples for the agreed test parameters as and
when sent by KVICto Textiles Committee.

30

<!-- page 31 -->

D. Scheduled

of Charges

for Activities

Under Khadi Mark Scheme

i. Operational Fee:-

Sr. No.

Item

Charges

1

Annual Operational Fee/ Grant

Rs. 98,00,000/- +GST

ii. Verification Fee:Type of
Verification

Khadi Institutions
Turnover

Marketing
KI's

Turnover up
to 1 Cr.

Turnover
1 Cr. to 5 above 5 Cr.
,Cr.

Onsite
verification
Fee

Rs. 12,500/+GST

Rs. 20,000/+GST

Rs. 30,000/+GST

Rs. 30,000/+GST

Annual
Verification

Rs. 12,500/+GST

Rs. 20,000/+GST

Rs. 30,000/+GST

Rs. 30,000/+GST

Note:
•

The annual operational feel grant, onsite verification fee and Annual
verification fee are valid for 3 years from the date of signing of MoU.

•

The test charges will be as per the schedule of test charges notified by
the textiles committee from time to time.

•

Textiles Committee will prefer to receive the funds as Grant in aid.

iii. Testing Charges

Sr.No.

Test Charges (in Rupees)

Parameters

1

Fiber Composition

Rs. 550/ -+GST*

2

Direction of Twist and twists per inch
of yarn in the Khadi Fabric / product
(Warp & weft)

Rs. 500/ -+GST**

3

Count of yarn in the Khadi Fabric/
product (warp & weft)

Rs. 200/ -+GST***

4

Ends per inch and picks per inch in
the khadi fabric / product

Rs. 200/ -+GST

5

Total testing charges per sample

Rs. 1450/ -+GST

31

<!-- page 32 -->

* The charges is meant for upto two component fibers in the sample. In case of the
more than two fibers, additional charges of Rs. 250/- will be charged for each
additional component fiber.
**The charges is meant for single yarn/ resultant twist of piled yarn. In case of
twists of singles of piled yarn, the charges will be Rs. 650/***Thecharges are for testing of count of yarn as revised. In case of testing of count
of yarn after removal of added matter will be Rs. 300/E. On site verification, sample drawing and testing:
a.

KVIC on its part shall send the application for registration to Textiles
Committee within the agreed time frame and Textiles Committee on its
part shall deploy adequate qualified and trained staff for onsite verification
as well as drawing and testing of samples and complete the verification,
testing and reporting process within the agreed time frame.

b. Carryout onsite verification upon receipt of the application for registration
from KVIC.
c. The onsite process verification shall cover
(i)

Verification of hand spinning and hand weaving process at the
production centers

(ii)

Evaluation of production capacity and label entitlement

d. If found satisfactory in the onsite verification, samples will be drawn and
the drawn samples will be tested in Textiles Committee's laboratories for
the required parameters.
e. Textiles Committee shall submit onsite verification report to KVICalong
with recommendation within agreed time frame for registration and Khadi
Mark tag and label entitlement of the persons and certified Khadi
institutions applying for Khadi Mark registration. In case of any
discrepancy Textile Committee should clearly state nature of discrepancy.
F. Khadi Mark tag and label management:
a.

KVICprovided the specification for Khadi Mark tags and labels.

b. Textiles Committee shall plan and get printed the required quantity of
Khadi Mark tags and labels and maintain sufficient stock.
c.

Upon the receipt of request for Khadi Mark tags and labels from persons
and certified Khadi institutions registered under the Khadi Mark Scheme,
Textiles Committee shall issue appropriate Khadi Mark tags and labels
according to their entitlement under intimation to Directorate of Khadi
Certification.

32

<!-- page 33 -->

d.

Textiles Committee shall maintain the records for issuance of Khadi Mark
tags and labels to persons and certified Khadi institutions registered under
the Khadi Mark Scheme.

e.

Textile Committee shall submit monthly report to KVIC in respect of
issuance Khadi Mark tags and labels to persons and certified Khadi
institutions.

G. Annual verification visits
a. Textiles Committee shall carry out annual verification visits, as may be
mutually decided and agreed upon, to persons and certified Khadi
institutions registered under the Khadi Mark Scheme.
b. During the annual verification visit the production process shall be verified
for continued compliance to the requirement of hand spinning and hand
weaving process.
c. The production capacity will be verified to evaluate the continued
suitability of label entitlement.
d. Samples will be drawn and! tested to ensure the use of natural fibre and
other agreed parameters.
e. Textiles Committee .shall submit the annual verification report to KVIC.
f.

The annual verification report shall include any deviation, deficiency,
change in the production process or label entitlement.

g. The annual verification visits shall be carried out in accordance with the
procedure to be outlined separately.
H. Procedure for onsite verification, evaluation of label entrtlement,
drawing and testing of samples, Khadi Mark tag and label management and
annual verification visit:
a.

It has been agreed between the parties that

the onsite verification,
evaluation of label entitlement, sample drawing, testing, reporting, Khadi
Mark tag and label management and the annual verification visits shall be
carried out in accordance with the mutually agreed procedure to be
outlined separately.

b. The procedure shall include methodology for onsite verification, sampling
criteria, verification parameters, testing parameters, test standards,
evaluation of label entitlement, formats for onsite verification and annual
verification visit, reporting and time frame for onsite verification, sample
drawing, testing and report submission as well as annual verification visit.
c. The procedure shall also include planning, printing and issuance of Khadi
Mark tags and labels and submission of periodical statement to KVICon
issuance of Khadi Mark tags and labels to persons and certified Khadi
institutions.
33

<!-- page 34 -->

d. Any amendment in the procedure shall be mutually discussed and agreed
upon between KVICand the Textiles Committee.
e. Textile Committee and its officials shall maintain full confidentially in
respect of any information including production technology, market
strategy etc. gained during the drawing and testing samples and shall,
under no circumstances, divulge the information so gathered/ acquired to
any other person or organization.
f.

The KVIC shall have full rights to supervise witness and monitor the
process, assess the reports and to reject any report as submitted by Textile
Committee. Rejection shall also be communicated to Textile Committee.

g. In case, at any point of time, it is established that an official engaged by
Textile Committee has indulged in any practice which is not ethical, or has
behaved in a manner uncalled for, the KVICshall bring the same in to the
notice of Secretary, Textiles Committee, for necessary action.

*****

34

<!-- page 35 -->

7.

Marketing

Promotion

(Exhibitions)

KVIC is playing a role in creating marketing
opportunities for KVI products i.e. organic, natural, pure, eco-friendly, biodegradable and skin friendly products. The potential of Khadi to make strong
inroads into the consumer domain has also attracted unscrupulous elements and
profit oriented corporate to benefit from its strength. Linked to this is the
increasing popularity of Khadi around the world, in addition to domestic markets.
Thus, marketing of products of Khadi and Village Industries are important
stepping stones of rural development which ultimately constitutes our
developmental goal.
KVICcontinued its marketing strategy of popularizing KVIproducts through
exhibitions to accelerate at large in the domestic and international markets, which
proved as a cost effective medium for publicity as well as opening marketing
opportunities to the KVI products and also as an instrument for creating
awareness.
Introduction!

1.

Objectives:

Domestic Exhibition Pattern under Marketing:
S
N

Level of Minimum Minimum
Minimum
the
Duration
Stalls State/District
Exhibition
!Institutions

1. National
2. Zonal
3. State

25 Days
15 Days
10 Days

150
75
50

4. District

7 Days

20

15 States
4 States
40
Institutions
10
Institutions

Maximum
Grant
to be provided
by KVIC
(Rs. in Lakhs)

Sales
Target
(Rs. in
Lakhs)

75.00
40.00
20.00

500.00
270.00
100.00

7.50

15.00

2.

Eligibility Criteria for Organizers:

1.

National, Zonal, State and District level exhibition will be organized by SO/
DO of KVIC or State KVIB. However SO/DO's can organize District level
exhibitions through Khadi Institutions / Khadi Federation also

3.

Release of funds:

1.

35% along with work order against Bank Guarantee of adequate value.

2.

50% on completion of erection of stalls and other arrangement to be certified
by an Officer authorized by the Organizing Committee.
35

<!-- page 36 -->

3.

10% on receipt of report of completion of Exhibition including photos and
other formalities prescribed by the Organizing Committee /State /Divisional
Director duly recommended by the Organizing Committee.

4.

5% after receipt of complete report and payment accounts with item-wise
Statement of Expenditure, refund of IRG amount and unspent balance, etc.,
duly verified by the Accountant.

4.

Stall Distribution Particulars:
SN

Particulars

% Coverage

1.

Khadi
REPG/PMEGP Units
Others

60%
30%
10%

2.
3.
5.

Stall Rent:
Maximum Rental for Standard stall Size (Amount in Rs.)
Particulars
National Level
Zonal Level
State Level
District Level

3mtr. X 3mtr.
Rs 10,000+GST
Rs s,OOO+GST
Rs 3,000+GST
Rs.2,000+GST

3mtr. X 2mtr.
Rs s,OOO+GST
Rs 2,sOO+GST
Rs 1,sOO+GST
Rs 1,OOO+GST

1. Allocation of Stalls: On the basis of Lots / First come First Serve basis on
the basis of Online Payment receipt of registration.
2. Scope of Work to be clearly mentioned in the RFP
(a)

Participants from N.E. States & Aspirational Districts
Concessions

50%

(b)

Departmental Sales Outlets KVIC/KVIB

Free

(c)

Training and other Administrative
Institutions etc.

Free

6.

Internal Revenue Generation (IRG) :
1. Entry Fees to visitors: Nil for all levels of Exhibition
2. Stall rent collection
3. Local Sponsorships from Banks etc
4. Sale of Stall space to Food/Entertainments stall etc
36

<!-- page 37 -->

No

Level of
Exhibition

1
2

National Level
Zonal Level
State Level
District Level

3

4

Food/ En tertainmen t Stall
Charges (Amount in Rs.)

Proposed Entry Fee
(Amount in Rs.)

25000
10000
5000
2000

NIL
NIL
NIL
NIL

7.

Distribution of IRG:

(a)

To cover the excess expenditure
Over and above sanctioned funds

50%

(b)

Remittable to KVIC,CO

50%

8.

Eligible Items for Expenditure:
No Particulars

Indicative
0/0

Ground rent/Hall rent
Erection of Pavilion/Stalls (3x3)
3.
Decoration of Stalls
4. Theme Pavilion
5. Electricity charges
6. Transportation, Conveyance charges
7. Back-up support like Insurance, Security, First-Aid, etc.
8.
Buyer-Seller Meets in National & Zonal Level Exhibition
Fashion Shows (compulsory in National/Zonal / State
9.
level Exhibitions) and cultural events
10. Publicity including Press Conference
11. Printing & Stationery
12. Leaflet & Presentations at the Trade Inquiry Stall
13. Inaugural & Valedictory function
14. Shields & Trophies for participation/performance
15. Technical Demonstrations
16. Data collection and Survey of visitors
17. Miscellaneous! Contingency
TOTAL (Interchangeability of heads permitted)

1.
2.

37

15
25
5
5

20

5
5
100

<!-- page 38 -->

9. Monitoring and Evaluation:
i.

ii.
iii.

The KVICwill ensure proper, effective utilization of financial assistance
under the scheme by applying necessary checks & balances from time to
time.
KVIC shall evaluate the scheme both at midterm and at the end of
Finance Commission Cycle.
Directorate of Marketing will be the Nodal Directorate (Phone No. 02226716680)

****

38

<!-- page 39 -->

8. Science & Technology (S&T)Scheme

Introduction
Under the S&T Scheme, Research and Development programs are
implemented focusing on to enhance the quality of products, increase the
productivity and earning of artisans, reduction in human drudgery, Development
of new products and diversification as per market demand and efficient use of local
raw materials. Keeping in view of the above and to a give new dimension to
Khadi and Village Industries, the following type of projects are supported
under the S&T scheme.
1. Research and Development (R&D)projects for Khadi and Village Industries

(KVIl·
2. Demonstration / Field trails / Dissemination of the developed technologies by
the Research/Technical Institutions to Khadi and VillageIndustries Sector.
3. ISO 9001- Quality Management System Certification for the KVIC
establishments.
4. Strengthening of Product/Process standardization, Intellectual Property Right
in the KVI sector through Grant for Patent registration, and organizing
Technology Upgradation programs.
Objectives of Scheme
1. To reduce the drudgery of the workers and the artisans in the operation of
tools and implements.
2. To enable the artisans/village industries Units/entrepreneurs to increase
their earning capacity.
3. To enable artisans/village industries units/entrepreneurs to produce quality
goods in comparison with the products of other sectors.
4. To enable artisans/village industries units/entrepreneurs
to use raw
materials available locally so that they may not be required to migrate in
search of raw materials outside their familiar region.
Eligible Institution to undertake S&T Projects
1. Any Premier Technical Institutes/

Universities/ R&D organizations / Govt.
organization engaged in R&D activities, design development/ Directly Aided
Institution of KVIC/KVIB and reputed NGOs registered under Darpan
Portal.
2. An individual engaged in research in Khadi and VillageIndustries.

39

<!-- page 40 -->

;

Focus Area of Research& Development
The following areas are to be taken up for R&Dwork:

» Technology/Research
»
»
»
»

and Development focus on solving the existing
problems in Khadi Sector and Village Industries, looking to the suitability
in implementation of different schemes.
Improvisation of the existing Machines/Tools and implements used in KVI
sector to enhance Productivity/quality and reduce drudgery.
Standardization of process/ technology/quality of end product.
Demonstration/Field trials/ Dissemination of the developed technology for
adoption by the concerned industry/agency
for qualitatively improving the
implementation of the Programme.
StudylEvaluation:
In order to have better input of information and data
compilation for various R&D works studies may be undertaken which may
also become part of the R&D work.

» Publicity of improved implements

etc.: Adequate publicity must be made
for developed technology, standards, processes.

Procedure for project proposal Evaluation and Approval
Step: 1 (a) Proposal under R&D of Government approved agencies Premier
Technical Institute/University / any R&D organizations
having adequate
infrastructure/facilities to implement the project shall be submitted in the
prescribed Proforma to the Director (S&T), KVIC,Mumbai. However, one copy of
the same is to be sent to the concerned State/Divisional Director for information.
(b) Proposals under R&D/ Dissemination from the Directly Aided Institutions of
KVIC/KVIB/Individual/NGOs having adequate
infrastructure/facilities
to
implement the project will have to be forwarded in the prescribed Proforma along
with relevant enclosures to the Director (S&T) through the State/Divisional
Director.
Step: 2
The State/Divisional Director may examine the proposal of
NGOs/Individuals/Technical Institutions/R&D Organizations etc., whenever
required, with reference to the extant guidelines of KVIC. The State/Divisional
Director will verify the infrastructure, manpower and financial position etc. and
will forward the proposal to the Director (S&T)with specific recommendations
within 3 weeks of receipt of the proposals.
Step: 3
On receipt of the proposal, the Director (S&T)will process the proposal
with reference to the extant guidelines of KVIC and obtain the technical
40

<!-- page 41 -->

Budget provision

•

of Scheme of S&T Proposals

A grant or subsidy to an individual should not exceed Rs.5,00,000 /- (including
all charges & taxes, etc.) in any case and to an institution, it should not exceed
Rs.50,00,000/- (including laboratory trials and field trials, etc.).
Project costing above Rs. 50,00,000/- for Institutions are subject to approval of
the Ministry.
The above ceiling limits are subject to revision, time to time, with the approval
of the Ministry.
The budget provision for S&T Programme shall be up to. 2% of Annual budget
allocation under the Khadi Vikas Yojana (KVY)Scheme and Gramodyog Vikas
Yojana (GVY)Scheme each.

Procedure of ImplementaUon

and Monitoring of the project

1. On sanction of S&T projects, the Implementing Agency shall execute an
agreement in prescribed format.
2. Release of funds will be made through the respective State/Divisional Director
in phased manner.
3. The Implementing Agency shall be required to submit Periodical Progress
Report in the prescribed format with details of the activities completed to
the Director (S&T) under intimation to the respective State/Divisional
Director. The Director (S&T)will review the progress/ achievement with the
support of the Concerned Programme Directorate, and if required,
suggestions/ opinions of concerned Experts may be obtained. The
suggestions may be communicated to the Implementing Agency for
incorporation in the research work.
4. On Completion of the project, the Implementing Agency shall be required to
submit the Final Progress Report in the prescribed format, including details
of Quarter-wise Dissemination Plan/ Dissemination activities to be carried
out along with Utilization certificate to the Director (S&T) through the
concerned State / Divisional Director.
5. The duration of the project shall be as per the sanction and may be
extended as per the request of IA with proper justification with the approval
of the Competent Authority. While enhancing the tenure of the project, the
extension accorded should be very clearly identified with reasons and with
accountability on the Implementing Agencies to ensure that the project
must be completed within the extended period.

42

<!-- page 42 -->

!

F. Procedure on Project completion & Dissemination of the project
1. After

completion
of the
R&D work,
all implements/equipment
used/involved in the projects will be the property of KVIC and the State
Director / Divisional Director will be the custodian.

2. The Project Investigator should protect the outcome of each R&D project
through the suitable provisions of IPR, i.e., patent, brand name, copyright,
trademark, etc. The patent, copy right will be jointly filed in the name of the
CEO, KVIC, Mumbai and the Head of Implementing Agency. The Project
Investigator and Co-Project Investigator will be inventors of the technology.
3. Tentative plan for multi-location field trial/ Dissemination should be essentially
submitted with each R&D project report of technology/prototype development.
After successful development of technology/prototypes,
the S&T Committee
may approve the proposed budget for field trial subsequently, if required.

****

43

<!-- page 43 -->

List of Abbreviations

I

KVIC

Khadi and Village Industries Commission

KVIB

Khadi and Village Industries Board

SO

State Office of KVIC

CEO

Chief Executive Officer

DIT

Directorate of Information
Technology
,

FBAA

Finance Budget Audit and Accounts

ZLC

Zonal Level Committee

SLC

State Level Committee

CLC

Central Level Committee

EcR

Economic Research

SFC

Standing Finance Committee

CA

Chartered Accountant

MoU

Memorandum of Understanding

GST

Goods and Services Tax

·DBT

Direct Benefit Transfer

CFC

Common Facility Centre

AWFT

Artisans Welfare Trust

CoEK

Centre of Excellence for Khadi

KI

Khadi Institution

DAI

Directly Aided Institution

BAI

Board Aided Institution

MoMSME

Ministry of Micro, Small, Medium Enterprises

ISEC

Interest Subsidy Eligibility Certificate

NIFT

National Institute of Fashion Technology

44

<!-- page 44 -->

Glossary
KVIC - Means Khadi and Village Industries commission constituted under section
4 of the Khadi and VillageIndustries Commission Act, 1956 (61 of 1956).
Khadi Institutions - Means a certified khadi institution which is enlisted with
Khadi and Village Industries commission (KVIC)or Khadi and Village Industries
Board (KVIB)for financial and technical support and is issued valid khadi
certificate under a code for such certification issued by KVICunder clause (K)of
sub section (2) of Section 15 of the act read with sub regulation (1) of regulation 24
of KVICregulation 2007.
Stock - Means the goods or merchandise kept on the premises of a shop or
warehouse and available for sale or distribution.
AWFT - Means Artisan Welfare Fund Trust provides financial help required by the

artisans in their hours of need. Amount accruing to Artisan Welfare Fund (AWF)is
kept in fixed deposits in nationalized Banks.
Artisans - Means individual involved in spinning/ reeling and weaving of Khadi
products also includes other Karyakartas involved in wet processing i.e. bleaching,
dying, mercerizing, finishing, printing and processes involved in Khadi.
Sales - Retail sales and wholesales including Government supply, Franchisee,
Bulk sales to end customer for a particular year. Wholesale excludes the sectoral
sale Le.- from one KIto another KI.
Escrow - An escrow account is a temporary pass through account held by a third
party during the process of a transaction between two parties. This is a temporary
account as it operates until the completion of a transaction process, which is
implemented after all the conditions between the buyer and the seller are settled.
Khadi Artisans- Khadi artisansare those persons, who are involved in the process
of production activities such as; spinning, warping, twisting, weaving,
dyeing/printing etc.
Khadi Karyakartas- Khadi Karyakarta means persons involved in production &
post-production activities such as; Salesmen, Sales-women, cashier, accountant,
marketing executives, helper, tailoring staff, store-keeper, godown-keeper etc.

45
