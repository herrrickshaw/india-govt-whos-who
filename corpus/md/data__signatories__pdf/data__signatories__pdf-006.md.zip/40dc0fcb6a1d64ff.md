---
doc_id: "40dc0fcb6a1d64ff"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/d93ded26dc521dc5ca03bbdf2419dd2c.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Scheme of Financial Penalty for violation of terms and conditions of Licences Agreement and instruction in respect of Subscriber Verification Failure Cases"
date: "2026-06-04"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "110c057d91c81690"
---

<!-- page 1 -->

800- 32/ 2011-V AS
Government of India
Ministry of Communications & Information Technology
Department of Telecommunications
(Access Services Cell)
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
Dated: 26th April'2013
To
All DDsG TERM Cells
Subject: Scheme of Financial Penalty for violation of terms and conditions of
License Agreement and instructions in respect of Subscriber
Verification Failure Cases.
Ref:

(i)
(ii)
(iii)
(iv)

Letter No. 800-52/2008-VAS-III(Part) Dated 24.12.2008
Letter No. 800-20/2010-VAS dated 03.02.2011.
Letter No. 800-20/2010-VAS dated 07.02.2011.
Letter No. 800-32/2011-VAS dated 07.11.2012

The Hon'ble TDSAT in its judgment dated 12.04.2012 in petition No. 252 of
2011 (COAI & Ors. Vs. DoT & Anr.) has inter-alia concluded in para 332 as
under:
"(xi) The financial penalty should be calculated on the principles as
it is followed in the Income Tax system, i.e. rate of financial penalty
to be calculated separately for each slab and the total amount of
penalty arrived at."
2.
Accordingly, it has been decided as under in respect of the demands
raised w.e.f. 01.04.2009 as per DOT instructions dated 24.12.2008 for Customer
Acquisition Form (CAF) non-compliance cases:
(i) Closed demands i.e. the demands raised by DoT which have been paid in
entirety by the operators need not be opened.
(ii) The demands which have either not been paid at all or have been partially
paid by the operators may be recovered as per directions contained in
above-said para 332(xi) of TDSAT judgment dated 12.04.2012 i.e.

<!-- page 2 -->

calculating financial penalty on the principles as it is followed in the
Income Tax System.
(iii) Future demands from the date of pronouncement of TDSAT judgment
may be raised as per above-said directions of TDSAT.
3.

Rest of the instructions in this regard shall remain unchanged.
I ,"J,D l°>

I

'.)_.

-h . '--\

4A.K\Tirkey)
AD (AS-II)
Copy to:
1. Secretary TRAI.

2. Sr. DDG(Security-TERM), DOT
3. All Access Service Providers (CMTS/
information please.
4. COAi/ AUSPI for information please.
5. DDG(AS-II), DOT
6. DDG(Accounts), DoT

UAS

Licensees)

for
