---
doc_id: "3edb28dafcfeaace"
source_url: "https://master-dolr.digifootprint.gov.in/static/uploads/2025/09/88531fdaa0c749437a4f3bf3a5c992a1.pdf"
ministry: "Department of Land Resources (DLR)"
title: "Audit Report/Opinion in respect of World Bank financed-Rejuvenating Watersheds for Agricultural Resilience through Innovative Development Programmc (REWARD)’ Loan No. 9314-lN for the year 2021-22"
date: "2025-09-20"
pages: 24
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0aa057192552ba0a"
---

<!-- page 1 -->

142822/2025/WM Division

ffien (ffiquu), i

tD.rqrdq TETFesr-o

Office of the Director General of Audit (Central Expenditure) I

S fr c * sTn .r{i, {qrtcr \.*c, r{ ffi-110 oo2

DGACR Building, lndraprastha Estate, New Delhi-110 002
qa{{< qqil

No.- AMG-V/2-lEAP-REWARD/DoLR/2021-22/2023 -241

t{r d,

|

I)atcd: 21.06.2023

lL

frtlr+' (REwARD)
,1fr dtrtrd Fdilrrr,
(st i.Bn, fi'Er* €E{rr
Tt frir-fr - lloool

I

2

ET{: Audit Report/Opinion in respect of World Bank financed-Rejuvenating Watersheds for
Agricultural Resilience through Innovative Development Programmc (REWARD)' Loan No.
9314-lN for the year 2021-22.

t

r(tfrtf,tstf,r,
Please find enclosed Audit Rcport/Opinion in respect of World Bank Financed-Rejuvenating

Watershcds for Agricultural Resiliencc through lnnovative Development Programme (REWARD)'
Loan No. 93 l4-lN, Department of Land Rcsources lor the period 2021-22.

E ncl: As above

You rs faithfully,

-s/d-

l)irector (AM(l -V)

No.- A MG-V/2-IEAP-REWARD/D oLR/2lt2l-22t.1023-24/
I

lt]- t \Y

I)atcd:21.06.2023

. Copy forwarded along with Financial Statement submitted by the entity to Director,
Government of lndia, World Bank and ADB Division, Deparlment of Economic Affairs'

t

Ministry of Finance, North Block, New Delhi for information.

2. Copy to Sr. Administrative ofllcer (PPO/EAP), O/o C&AC of India 9, Pt Deendayal
Upadhyaya Marg, New Delhi-l 10124 lor information.

->r^r\\-z-^a)
Dircctor (AMG -V),

Ph.

Fax

91-11-23702422
91-11-23702271

File No. S-11027/11/2022 (Computer No. 3012340)

1

E-mail : dgace@cag.gov.in
Website : https://cag. gov. in/cen/new-delhi-iii/ten

Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 2 -->

142822/2025/WM Division

Officc of Director General of Audlt (Ccntral Expenditure)
AGCR Building, I.P' Estate, New Delhi-110002

i

'I tt

;

Thc Dircctor @EWARD)'
Government of India,
Department of Land Resources'
2'd Floor, Shivaji Stadium
New Delhi-l10001.

Subject: -Audit Report/Opinion in respect of World Bank Financed

Rejuvenating

WatershedsforAgriculturalResiliencethroughlnnovativeDevelopmentPrcgramme.
(REWARD)' Loan No. 9314-IN, Department of Land Resources' Ministry of Rural '
Development for the period 2021'22.

WehaveauditedtheaccompanyingfinancialstatementsoftheRejuvenating
Programme
Watersheds for Agricultural Resilience through lnnovative Development
Ministry of Rural
(R-EW AIfD) Loan No. 9l l4-lN, Department of Land Resources,
Funds' and the
Development comprising of 'statement of Sourccs and Applications of
'Reconciliation of claims to Total Applications of Funds' for the year ended 2021-22. These
staler)rcnts are the responsibility of the Programme N{anagernent Our

responsibility is td

express an opinion on the accompanying financial statemel)t bcs'rd on our

audit'

t

we conducted our audit in accordance rvith the Auditing Standards promulgated by
theComptrollerandAuditorGeneraloflndia.Thosestandardsrequirethatweplanand
perlbmrtheaudittoobtainreasonableassuranceaboutlvhetherthefinancialstatementsare
basis, ev idence supporting the
tr.ee of material misstatement. our audit exanrines. on a test
amounts and disclosures in the financial statenrenls. lt also includes assessing

the accounting

'

prirrciplesusedandsignificantestimatesmadebl'managenrent,aswellasevaluatingthe
basis lor our
slatement presentation. we believe that our audit provides a reasonable
overall

opinion.
the

In our opinion, the financial statements prescnt fairly' in all material respects'
watersheds for
Sources and Application of funds of world llank Financed Rejuvenating
for the
Resilience tlrrough lnnovative l)evelopment Progratnme (REWARD)
AgricultL,ral

1e:,r tnicJ 1021-22 inaccordance

u'ith Gr.r''erttn:ent oflndia Accounting Standards'

i

-*
RFdzr'rn9 e s*e' af ftrcfr'110o02Phone no'
+91-l.1.23454i00, Fax no. +91-11-237o2271 AGl:R Buildin&IP Estate' NewDelhi'110002

s=P+r'.!i+rE.!aaa4:44:!-:g2t:e

t'.'.- -,ri r izils4loo, h.;{ a. -91-11'23702271, ffi:n<
2

File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 3 -->

142822/2025/WM Division

/

In addition, in our opinion. (a) with respect of Stateme{rt of Expenditures (SoEs),
adequate supporting documentation has been maintained to support claims to the world Bank
for reimbursements ofexpenditures incurred at Rs. 289051261- (Two Crore Eighty Nine Lakh
Irivc Thousand One Hundred Twenty Six only) and (b) Expenditures of Rs. 28905 126l- (Two r

crore Eighty Nine Lakh Five Thousand one Hundred Twenty Six only) are eligible for
financing under the Loan agreement.

During the course of audit, SoEs and the connected documents were examined and
these can be relied upon to support reimbursement under the Loan agreement'

This report is issued without prejudice to cAG's right to incorporate the audit
observations in the RJport of CAG of India for being laid before ParliamenVState or UT
Legislature.

t

fu-,- --=.,-;
Director (AMG-V)

{

Ffrin,3{rf ff q*8, aE AiF&-110002Phone Do.
+91-11-23454100,Faxno.+91'11-23T022Tl.AGCRBuilding,lPEstate,NewDelhi-110002
3

tE'ra a. +91-11-2345,1100, S-tr a. +91-11-2370227f

iffim

File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

I

<!-- page 4 -->

142822/2025/WM Division

.

til

I'

i;$
Annexure
Example oIs Statenrcnt of Sources
and fupUcaflon of Funds
(proJecs implemented by core

*rr***_r*i deprrtments)

Nameof rhefroje

t

'

_

"w

-,srD qi, qo,ru)
sratement,l#_:xJjffiffil;*;ljil[]{'" ir
Report for the year endecl !o,r,o-ar , Lr\( la-f
.

Part icula rs

I

I

\,rl.,cuurg Datilnce, (U cash balances are

controllr:d by the enlity) (A)

Current

Prcvious

n Ik.
IK '000
Froject to

lo-il99r

pnY,r:?r a-t

date

Nti-

l..rrL

4bsoo

lqt86

Nd-

NIL

I
Rcccipts

Funds rcccivcd ton.,
@
Budgct ('l"ircse rvil! inclu<Je exlemal assislance
rece ivccl by Govemn.le_ll_r tor the project.)

l:un<ls recsivccl @

Irr:plemenring Authoriry through external

as.sistansc

Ilcnclrciary Contribution ( rf any)

7iN tu
f'{1L
QoSoo

hrL

'fotat Ileccipts (B)
Toirrl Sources (C = ,\ + B)

t .{ tc66

tr o Sat

Expcnditures b3, Componcnt

11" loY
Lc&Lt t .L2

A. oFr(ce 4.$E$vtg
B. R.r^ris, RA?Es 4 Trbces
C. ?b***,wxLt- #{*stcg5

rr{qt{
Np-

tBcc 5.1?a

Nr tNt r-

NIL

NTL

lq7t.-l,tl

'l'ot:rl Hrpcn ditures [D)

Closing Bnlrncc, (if crsh balances trc
controllcd by'the cnlig') ( C-D)
Notes:

.

l. lnformalion about the basis of preparation of the financial stategents wit!
regard to rhe Financial Rules and Codex applicable.

2, Tha abo'e figures will be based os montNy/qusrterly abstract accounts
prepared by the accounts compiling officcs, duly rcconcilod by the rcspective

DDOs, with details ofunreconciled amounb to bc furnished.

3. Na;rnes of accounring unirs rvhose {inucial Etatements firc

il

prepare the consolidared accounts.

Y

,/l

4, Any other proje* specilic Note.

4
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

n

.

I

<!-- page 5 -->

142822/2025/WM Division

Annexure 2
Stmple Ilcconciliation of Chims to'fotal Applicctions of Iiunds

Niinre of thc I'rojcct .

Loan i Crcdlt
llcconciliation of Chims to I

l'+1ib ?*(ts

R''i 5 qo'' N )
r

^;;B

eear- &-L

Amt (Rs. '000)
C rr rron f

Previous

Yerr
NI L

Ycrr
r{lL

181*5.,rc

r\qEt

l.i t t-

NIL

]II

h{ ru

N(L

IV

Nt lL

r-..rtL I

\c h od rr lec

Bank Irunds elaimcd during the ycrr (A)

I

Total Expcnditure mrdc tluring the year (ts)
Less: Outstanding AC Bills (C)

II

\Yorld lilnk Shnre @ x,/, of (F) above (G)

CFAO

I'roject

Datc

Date

tgtoS-uJ

NIL

N,L

l\t L

Project
to dlte

I

Notes:

l.

Total expendilure rnade durir:g the 1,ear (B aboi'e) musr be the same as as
the Total Expendirures shorvu on thc Statcment of Sources and
Applications of Funds (D on thc Statemcnt of Sourccs ancl Applications of
Funds)

2.

Outstanding AC Bills (C above) reflect funds
havc been booked as cxpcncliture but nol settl
unsertled advances). Tl
balance of unsettlcd AC
s,;ttlccl during the yoar, and AC bills rrnsettted at thc cnd

Expcnditures not clairned (E abovo) rnny refleet timlng differencos tbr
eligible expertditures inculrsd dwing the yenr brrt clainted after the year
end.

Amounts A and G sbove must be equal

i''

5
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

t

r^

<!-- page 6 -->

142822/2025/WM Division

a
Year wise statement of Expenditure under REWARD

Programme

202L-22
Expenditure (in

Subject

Rupees)
Office Expenses
Rents Rates and Taxes

72t07
7084t270

Proiect Manaqement Unit
Professional SeMces

7991799

Total- Rs. 289O5126 (2.890 Cr)
(From 18m Feb- 31't March,2022 Expenditure- Rs. 62L9144 (0.62 Cr)

2422-23
Manaqement Cell
Domestic Travel
Office Expenses
Rents Rates and Taxes

389663
1486137
28386898

Semina r, Workshop, Conference
Other AdministraUve Expenses 816911
Other Charqes
150556
ppoft-Institutional
Professiona I Su
Su ppolt, CapaciW Bu i ld i nq
5000000
Other Charqes

Proiect Manaqement Unit
Professional Services

BL227L6

Total- Rs. 44352881(4.435 Cr)

$"'t*e*,-'
LtANBo )
r*r,tl
t-'' kqrc-&i /TH
I

zrftlTurocr S'crat'ry
",*gTrrli/Goveriffini ol lndra
{{d

.fo ;.*n

fturnTOro Laod F'so'iI(e5

i'r,t; fa*n i tti{Ill'hl'n cl Rural
:rd fti*{l./'1"* ee'h'

6
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

Dev

<!-- page 7 -->

142822/2025/WM Division

7
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 8 -->

142822/2025/WM Division

8
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 9 -->

142822/2025/WM Division

kr

t,

;*
Example of a Staternent of Sources
antl Alplication of Funds
(proj ccts imptcmenteO Uy
.o ru go"e*iil'J Uoprrtments)

;\nnexure I

t*ff

wGltq$mu(t*
projecr,(_Vy*n8
?+ril., #ng *,,hJ{$m&
:t}t
Looan/Credit/Gra
an/Credi t/Gra uurt No. fe;iliurtr
W[)fu]fr _+ttH0n tk lfi nAU qfi cll
Name of&e

(uoRN . rBRD.13rqo.
statemenr ofi $ources
$o urces and
a n d Applica;""E;futhBJi
App licari""E lhthBJi
iN)
Report for the year ended
_

-:"a_Z

I ,rf =

openinggilm
corrtrollcd hr1, the entity) (A)

_
_ &om
mn6s recerved

Governrnent through

Budget (Thcse will include extsmal assisranie
receir,e{ by Covernment lor thc proi
Funds recerusd
run6s
projcct
reccived directly
d

by

Implemcnting Authority through extcrnal
Bcricficiarl, Contribut ion 1 if anyl

'l'otal Sourrcs (C -A + B)
Erpenditures b1, Component

A, IYffNAqer{GNr celL
B. oTnee AbnqrnrsreATivc €x

Closing Balance, (if cash balances arc
contrr:lled by the entity) ( C-D)
Notes:
1-

.$rlr.d ,trtu beun

"{apsed af?h

at*6}i

Informrtion about the basis of preparatioa of thc financial statements with
regard ts the Fiflancial Rules and Codes applicable.

2. The abcvc figurcs will bc bascd onmonrhly/quarterly abstrac accounrs

prcparcd bythe accounts compiling officos, dulyrcconcilcdby rhc respcctivc
DDOs, withdetails ofunreconciled amouuts to be fumished.

3' Nanrcs of accounting units rvhosc 0nancial statenents arc aggregated to
prcpare the consolidated accounts,

4. Any othcr projeor specific Nore.

10
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 10 -->

142822/2025/WM Division

Annexurc 2

$'

o't

sample Rcconciliation of Clrirns to r"ot:rr ;tpprications of Funds

N,rneorther,,,*I#rHf
Reco nciri ati,"

/f
ff#q*'ffi
]
A N' t 6R

3;lJfJ;l[l[ix]1ff;[J]iiil*:

Report for thc ycar ended

-

13 t'ro. rru)

Lo-?z: ZOZ3

ztmi (Rs. '000)
Schedulcs

Bank Funds claimed during thc ycar

(A)

I

Total Erpcnditure made during the year (B)
Less: Cutsrrndiug AC Bills (Ci
Ineligible expenditures (D)
Expenditures not claimed (E)
Total Eligible Expenclitures Claimed
tl')={B)_(ci_(D)-{E)

II

ilI
ru

\Yorld Bank Share @xy, of {F} abovc (G)

Current

Previous

,.$qa6 z

n..YqLr* to dafe

r 6(B\

Project

NIL

qL{3s0 2Eqo6

Nti
NttI.{IL
Qq

Nlr
NIL

Nlt

ap zB1o5

NA

hlA

,FP"}

t9
CFAO

Date
Notes:

l.

Total expcnditurc made during the 1,car'(B above) must be thc
same as as
the Total Expenditurcs shown on the Staiemcnt of Sources
and

Applications ofFunds (D on the statemcnt of Sources and Apprications
Funds)

of

outstanding AC Bills (c above) reflect funds drawn rgainsr AC bills rhat

have been booked as expenditure but not settlerl by the-end of the
1,ear (ie.
unseftied advances). The project should shorv in schcdule II the opening
balance of unsertlcd AC bills, AC bills d'arvn cluring rhe year, nciitts
settlcd during the year, and AC bills unsetrled ar the errd of the yrrar.
J.

Expenditures not claimcd (E above) may reflect timing differences tbr
cligible expend.itures incured during the 1'ear but clainrecl after the ycu.
end.

4.

/tmouots A and G above nru:,-t be cqual.

I
11
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

-*HI
( (€ t4 A (q)

<!-- page 11 -->

142822/2025/WM Division

World Eank Assisted WMp

r-sE 2oli-l* Ri ,oz2:-l- vnpnrlit'

i;.

i Brrdopt usr"t

{REtVARD}

Management Cetl (Detailed

Head)

(a).DomesticTravel Expelses

-l - ---o'

I
I
!

l_

+*--I
I o.tso i
{..%_

i ts01 05 101 13 o-z 11

j *-*
j

{%

2501" 05 101 13 03 s0

Sub-Total

sub total

!

I

0ti3-

--_---_

9!her Charges

I

I

I

Expenses *

I

I

I

o.sgo
Qfigf-i*t
;t;oz 1;-- | 0.7s0
[c ]office
or *1 L
i 1.000
--_
[d] Rents, Rates and Ta{g!__ zsoi 0s t01 1t02 14
s.soo
i'-sub
total
I
.ti% o.rgo
Seminar, Workshops,
Conference etc.
Other Administrative Expenses
2501 0s 101 L3 03 2;

I'rr

t

''-

I ,, i ,, I zaz2_23

i
i

i
i

1.2i0

T%

0.03e

j---!1a

i

i
I

o.zso
2.800
3.300

0.00c
0.149
2.83?
3.026

I
I

i

0.500
L.750

o.soo

U.U61

0.4 50

0.015

0.750

Professional Suppon-lnstitutional arpp"rt, C, pr.ity

0.097

BuildinLMBE,lFC, tT and gthers

Offilg Expenses

250105- 101 13 04 13

Adyertising and publicity

7.00c

0.050

0.000

2501 05 101 13 04 ?6

0.500

0.050

Qlhcr Charges

2501 05 101 13 04 50

0.500

0.500

0.000
o qnn

sub total

8.000

0.600

Project Managernent unit

0.500

a) Professional Services

2501 05 101 13 05 28

1.600

0.900

b) Other Charges

0.812

2s01 0s 10J 13 0s sg

0.400

0.0s0

0.000

SUB TOTAL

Total REWARD

2.CI00

0.950

0.812

17.880

5.600

4.435

&- ba-^-e*'
(dtqq

'

ffi{lTH LtANBol)

ar|rl rftE/Undor sccrclary
TT! rtr(lc'#Governrl€fi t d trrla

fff ftFtt RBq/Dro Lcn., Rtloutc.l
l[{q &ff3 txm/ffin. o{ Furc DoY.
ci f,itti/Ncu Brrnt

12
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

i

<!-- page 12 -->

142822/2025/WM Division

13
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 13 -->

142822/2025/WM Division

14
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 14 -->

142822/2025/WM Division

Statemeat of Ehpenditure as on 31.O3.2A24 for World Bank Assisted project-REWARD
iVlagor F{ead

Sr nc

BE 2023-

RE 2023-

24

Scherme (Plan)
(Rs. in
Cr.)

Expenditure
(Rs.)

{Rs. in Cr.)

World Bank Assisted REWARD Frograrnme

B

Managemeni Cell {Detaileci Head)
(a) Domestic Travel Expenses

25C1 05 7A1!3A2lL

C.9C

0.10

AAAAA OA

b) Foreign Travel Expenses

2501 05 '!Ot 13 071_2

O.BC

(c ) Office Expenses

2501 0s L0113A213

1.00

0.80
c.50

24.44770.AO

(d) Rents, Rates and Taxes

2501 05 101 13 02_ 14
sub total

3.s0

3.5C

6.24

4.90

0.0c

0.0c

0.00

2.OA

0.75

178273.0O

Seminar, Workshops, Conference e-ic.
a.Other Administrative Expenses
b. Other Revenue Expenditure

c.(liher Charges

C

n

0.c0
33561128.00
36015842.00

2s01 05 101 13 03 20
2501 05 10L 13 03 49
2s01 0s 101 13 03 50

0.00

0.00

0.00

sub total

2.00

0.v5

LV8273.AO

0.05

0.00
0.00
33117C00.00

Professionai Support-instituticnal Support, Capacity Building,
M&E,|EC, lT and oihers

Office Expenses

2501 05 101 13 04 13

3.5C

Advertising and Publiciiy
Oiher Revenue Expenditure
Oiher Charges

250i 0s 107130426

0.50

250145 101 13 A449-5
2501 05 10! 1,3 04 50

4.0c

3.s0

0.00

0.00

0.00

sulr total

8.CIo

3.70

331170OCI.00

2501 05 101 13 05 28
2501 05 101 13 05 49

1.8C

0.8c

.4100000.0c

b)Other Revenue Expencjiture

1.0c

U.Ji]

2411518.CC

c)Other Charges

2501 05 101 13 05 5C

0.0c

0.0c

d) Other Contrac'lual Services

501.05.101.13.05.30

0.00

U.UU

0.00

SUB TCIT,A8-

2.80

,..3.0

19.00

L0.45
lN Crore

6511 518.00
75822633.00

Project Management unit
a) Professional Services

Total: REWARD

7.5822633

\
.,ri6.Lfi
\:
r"
4r,i

X$r*
^ r:sOOY)
.. 6."fftit:r,..
pil}]l?rt;l::7)t -^

<
. . J)i
q$:..1;',
.1,* .ro: ., ,

i

,.

ii.Ad6i'!' ', -' ,"1ot*,-.- _^i, SodfcfS
'*1i* crsf*""]tioaia'

15
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 15 -->

142822/2025/WM Division

Statement of Expenditure as on g1,.Og.2O24 for trIorld Bank er"i"t.A pro;u.tREWARD
S.No.

Nanre of fixpeerditune

Sudget Head

Amount {Rs.}

2s01.0s.101.13.A2.fi.

49944.AG

2501.05. 101.1_3.02.13

2404770.AC

2501.05.101.L3.O2.14

33s61128.00

2501.05. 101_. L3.03.49

178273.0O

2501_.05. 101 .13.O4.49

33117000.00

2501.CI5.101.13.0s.28

4100000.00

2s0i.05.101.13.05.49

24L1518.00

Domestic Travel Expenses-REWARD
1

Office Ixpenses-REWARD
2

Renis, Rates & Taxes- REWARD

Other revenue Expenditure-REWARD
4

(Seminar, Workshop & Conference etc.

Other revenue Expenditure-REWARD
5

(Office Expenses-REWARD)
Project Management un it- professiona I

A

services(REWARD)

Project Management unit- Other Revenue
services(RtWARD)
7

Total

75822633.00

(sr. rff. ff

lRg rfR :!tir'

Sf.Ar di. Cr' '

16
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 16 -->

142822/2025/WM Division

n

Name of the Project: Reiuvenating Watershed for Agricultural Resilience Through
lnnovation Development program

Loan/ Grant/ Credit/ No. p172187 (Loan tBRD-93140-tN
Reconciliation of Claims to Total Applications of Funds
for the
emded
Amt {Rs.'00CI}
Sefruedufies
Currrent Year
Previous
Project to
Year
date
Bank Funds claimed during the
year (A)

I

Total Expenditure made during
the year (B)
Less: Outstanding bills (C)

lneligible expenditures (D)
Expenditures not claimed (E)
Total Eligible Expenditures
claimed (F)=(B)-(c)-(D)-(E)

0.oCI

n 16183..00

115181.00

75E22.63

44350.00

L49477.63

[fl

0"00

[[8

0.00
0.00

0.00
0.00

0.00
0.00

0.CIo

0.00

vs822"69

4435CI.00

749077.63

NA

NA

EV

World Bank Share @ x% of (F)
above (G)

CFAC

,,1, t',- " :-'etni

Daie

Date

Notes:
L.

2.

?

Tctal expenditure rnace during the year {B above) must be the same as the
Totai Expenditures shown on the Staternent of Sources and Applications of
Funds (D on the staternent of sources anrJ Applications of Funds)
Ouistanding A/C Bills (C above) neflect funds drawn against A/c bills that have
been booked as expenditure but not seitled by the end of the year (i.e.
unsettled advances). The projeci should shown in schedule Il the opening
balance of unsettled A/c Bills, A/c Bills drawn during the year. A/c Bills settled
during ti're year. A/c Bills unsettled at the end of the year.
E;<penditures not claimed ([ above) may refiect timing di'iierences ior eiigibie
expenditures incurred during the year but claimed aften the year end.
Arnounts A and G above must be equal.

17
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 17 -->

142822/2025/WM Division

Nanne of the Project: Reiuvenating Watershed for Agricultural Resilience Through
I

nnovation Development Program

Loanl Grant/ Credit/ No. p172187 (Loan tBRD-93140-tN
Statement of Sources and Applications of Funds
Report for the year ended g!.Og.ZOZ4
ln Rs'000
Particulars

Current

Previous

Project to

Year

Year

date

Opening Balance (Al (if cash balances are
controlled by the entity)

0.00

0.00

75822.63

178800.00

310108.50

0.00

0.00

0.00

0.00

0.00

0.00

Total Receipts (B)

75822.66

178800.00

310108.60

TotalSources(C-A+B)

7s822.66

178800.00

3L0108.50

35015.E4

30250.00

87188.E4

L78.27

970.00

L1,49.27

C. OFFiCE EXPENSES & PMU

39628.52

13L20.00

6074A.52

Tota! Expemdltunes (D)

75822.63

44350.0CI

149477.63

CI.00

0.00

ffieceipts

Funds from Governrnent through Budget
{These will include external assistance reeeived
by Govennment for the projeci.)

Funds received directly by

project

lmplementing authority through external
assistance

Other Receipts

Expenditunes hy eormpomemt
A. MANIAGEMENT CELL
ts. CTHER ADMINISTRATIVE EXPENSES

eBoslatg Balanee, ( e-E) (if cash baflaraaes ane

eomtnolled hy t0re emtityCI

Note: The fund has been lapsed at the end of eveny financial year.
'*" tq-.*frrr. c, F, ir.gDDyi
.qnl{:r y,i .i* o,4ulni*.1;r ir-furv
{ftsrSi,
:.]Y:
f
S. Arljl. Ccmmlsr:-,re .i :\Cd. irogr4rq$e Of€<{cr (Re$r:
,,,.i{.?-Jffii;
r''-c,B<&
:nra- r-,"'' I18.r'a'
rur'*.
1lft si'.=,.r('Lq'" 1ii"

File No. S-11027/11/2022 (Computer No. 3012340)

G...

Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 18 -->

142822/2025/WM Division

19
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 19 -->

142822/2025/WM Division

20
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 20 -->

142822/2025/WM Division

F.No. S-1'l 0281 1 12022-REWARD(E-301 3 I 74)
Government of lndia
Ministry of Rural Development
Department of Land Resources
Shivaji Stadium Annexi Building,
New Delhi, 1oth July, 2025

To

The Director (AMG-V)
O/o the Director General of Audit (Central Expenditure)
AGCR Building, I.P. Estate,
New Delhi - 110002

Subject: Audit of World Bank Assisted REUIARD Program for the
Financial Year 2o24-25 (Loan No. 93l4-INf-Reg.
Madarn,

I am directed to say that Rejuvenating Watersheds for
Agricultural Resilience through Innovative Development (REWARD) is a
Program for Results (P for R) program financed by the World Bank,
Government of India, and State Governments. The program covers: (i)
the Department of Land Resources (DOLR), Government of India (ii)
Watershed Development Department (WDD), Government of Karnataka
(GoK) and, (iii) Directorate of Soil Conservation and Watershed (DSC &
WD), Government of Odisha (GoO).

2.

Reward is a five-year program with Program Development
Objective to Strengthen Capacities of National and State Institutions; to
adopt improved watershed management for increasing farmers'

resilience; and support value chains in watersheds of participating
States. The total program cost is USD 149.94 million(revised), out of
which the World Bank financing is USD 102.80 million, comprising of
US$43.S million for Odisha, US$53.6 for Karnataka and US$ 5.4
million for DoLR. Karnataka and Odisha State Governments have
separate loan agreements with World Bank.

3.

As per World Bank's mandate, the Annual Audit of World Bank
funded REWARD program needs to be done by the Comptroller and
Auditor General of India. An Expenditure Sheet, Statement of Sources
and Applications of Fund, Reconciliation of Claims to total application
of fund duly attested is enclosed for the read5r reference.
Cont.. /2

21
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 21 -->

142822/2025/WM Division

-2-

4.

CAG is, therefore, requested to conduct the audit of the
expenditure of REWARD Program for the financial year 2024-25 and
issue audit certificate for submission to World Bank Office. The

.

expenditure of the program during the financial year 2024-25 was Rs.
7.8486 crore.

Yours faithfully,

yS

4\0.'
,. P. Reddy)

Senior Addl. Com issioner and
Addl. Project
Encl: As Above

qr

"l

22
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 22 -->

142822/2025/WM Division

Statement of Expenditure as on 31.03.2025 for World Bank Assisted
proiect-REIIIARD
S.No

Name of Expenditure
Domestic Travel Expenses-REWARD

1.

2

3

4

Foreign Travel Expenses-REWARD

Office Expenses-REWAR D
Rents, Rates & Taxes- REWARD

Other revenue Expenditure-REWARD
(Seminar, Workshop & Conference
5
6

Professional Support-Office Expenses

Professiona I Su pport-Advertising and
7
Publicity
Other revenue Expenditure-REWARD
(Office Expenses-REWARD)
8
Project Management unit9

Professiona I services( REWARD)

Budget Head

Amount (Rs.)

2501.05. 10 1..L3.02.!L

741878.40

250 1.05. 10 1..13.02.L2

1L5L446.00

2501.05.101.13.02.13

692439.00

2501.05.10L.L3.02.L4

34958s93.00

2s0 1. 0s. 10 1..L3.03.49

464437.00

2501.05.101.13.04.13

L8,48,860.44

2501.0s.101.L3.O4.26

12,40,44L.OO

2s01.05.101.13.04.49

2s000000.00

2501.05. L01.13.05.28

10824677.00

2s01.0s.101.13.05.49

1553108.00

Project Management unit- Other
10

Reven ue services( REWARD)

Total

78485879.44

;f

23
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 23 -->

142822/2025/WM Division

Name of the Project: Rejuvenating Watershed for Agricultura! Resilience Through

lnnovation Development Program

LoanlGrant/ Credit/ No. P172187 (Loan IBRD-93140-!N
Statement of Sources and Applications of Funds
Report for the year ended 31.03.2025

ln Rs'000
Particulars

Current

Previous

Year

Year

Opening Balance (A) (if cash balances are
controlled by the entity)

Project to
date

0.00

0.00

78485.87

75822.63

388594.47

0.00

0.00

0.00

0.00

0.00

0.00

Total Receipts (B)

78485.87

75822.66

388594.47

TotalSources(C=A+B)

78485.87

75822.66

388594.47

A. MANAGEMENT CELL

37544.35

36015.84

124733.19

B. OTHER ADMINISTRATIVE EXPENSES

464.437

178.27

t6r2.7L

C. OFFICE EXPENSES & PMU

40477.O8

39628.s2

1,01217.60

Total Expenditures (D)

78485.87

75822.63

227563.50

0.00

0.00

Receipts
Funds from Government through Budget (These

will include external assistance received by
Government for the project.)
Funds received directly by Project lmplementing

authority through external assistance
Other Receipts

Expenditures by Component

Closing Balance, ( C-D) (if cash balances are

controlled by the entity0

Note: The fund has been lapsed at the end of every financial year.

ffi

,S..

24
File No. S-11027/11/2022 (Computer No. 3012340)

Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm

<!-- page 24 -->

142822/2025/WM Division

Name of the Project: Rejuvenating Watershed for Agricultural Resilience Through
I nnovation Development Program

Loanl Grant/ Credit/ No. P172187 (Loan tBRD-93140-!N
Reconciliation of Claims to Total Applications of Funds
Report for the year ended 31.03.2025
Amt (Rs. '000)
Schedules
Current Year
Previous
Project to
Year
date
Bank Funds claimed during the
year (A)

Tota! Expenditure made during
the year (B)
Less: Outstanding bills (C)
!neligible expenditures (D)
Expenditures not claimed (E)
Tota I Eligible Expenditures
Claimed (F)=(B)-(c)-(D)-(E)

I

0.00

0.00

116181.00

78485.87
0.00
0.00
0.00

7s822.63

il
llt

0.00
0.00
0.00

227s63.50
0.00
0.00
0.00

78485.87

75822.63

227s63.50

NA

NA

NA

IV

World Bank Share @ x% of ltl
above (G)

;\
Project Director

CFAO

1fr't

JM ffi.ffim#nm
:ft'"#lt'""*=

Date
Notes:
1,.

2.

3.

4.

Total expenditure made during the year (B above) must be the same as the Total
Expenditures shown on the Statement of Sources and Applications of Funds (D
on the Statement of Sources and Applications of Funds)
Outstanding A/C Bills (C above) reflect funds drawn against A/c bills that have
been booked as expenditure but not settled by the end of the year (i.e. unsettled
advances). The project should shown in Schedule ll the opening balance of
unsettled A/c Bills, A/c Bills drawn during the year. A/c Bills settled during the
year. A/c Bills unsettled at the end of the year.
Expenditures not claimed (E above) may reflect timing differences for eligible
expenditures incurred during the year but claimed after the year end.
Amounts A and G above must be equal.

25
File No. S-11027/11/2022 (Computer No. 3012340)
Generated from eOffice by Vikas Hasnani, V.H(EXPERT), EXPERT CONSULTANT, DOLR on 12/09/2025 05:40 pm
