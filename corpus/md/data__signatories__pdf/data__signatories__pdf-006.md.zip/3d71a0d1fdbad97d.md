---
doc_id: "3d71a0d1fdbad97d"
source_url: "https://www.meity.gov.in/static/uploads/2026/02/715cceb16d0ab711c3455f43973102b1.pdf"
ministry: "Electronics and Information Technology (MeitY)"
title: "Addendum to para 7.1 of EMC scheme notification dated 1st December, 2022"
date: "2022-12-01"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "98cdc7addf3a23a2"
---

<!-- page 1 -->

eFile No. W-45/10/2022-IPHW
Government of India
Ministry of Electronic and Information Technology (MeitY)
(IPHW Division)

Dated: 1st December,2022

No. W-45110/2022-IPHW

Subject: Addendum to Electronics Manufacturing Clusters (EMC) Scheme to provide
world-class infrastructure for attracting investments in the Electronics Systems Design and
Manufacturing (ESDM) Sector
References:
i.

Electronics Manufacturing Clusters (EMC) scheme notified vide notification no. 252 dated
22.10.2012 in Part-I, Section-I of Gazelle of India (Extraordinary) [F.No. 8(50)/2011IPHW}

ii.

Guidelines for Electronics Manufacturing Clusters (EMC) scheme issued on 15th April,
2013 [F.No. 8(50)1201l-IPHW}

In continuation to Para 7.1 of EMC scheme notification cited under reference (i) above, the
period for disbursement of funds to the approved applicants which was applicable upto 21 st
October, 2022, is hereby extended for further period of2 years i.e. , upto 21 st October, 2024 (F. No.
W-4511012022-IPHW dated 25th November, 2022).
2.
The disbursement of funds will be in accordance to extant EMC scheme Guidelines and
subsequent amendments thereto (as applicable). All other terms and conditions mentioned in
reference (i) cited above will apply mutatis-mutandis.
3.

The aforesaid addendum will come into force with immediate effect.

4.
This issues with the approval of Hon 'ble Union Minister for Electronics and Information
Technology, Government ofindia.

(Asha Nangia)
Scientist-G IGroup Coordinator
Ph: 011 -24301465
New Delhi, Dated: I" December. 2022
Copy to:
I.

ii.
III.

IV .

v.
vi.
vn.
vln .
IX .

All Ministriesl Departments of Government of India
All States I Union Territories
Cabinet Secretariat
PMO
NIT! Aayog
Comptroller and Auditor General of India
JS&FA, Ministry of Electronics and Information Technology
Implementation agencies of projects under EMC scheme
Internal circulation
