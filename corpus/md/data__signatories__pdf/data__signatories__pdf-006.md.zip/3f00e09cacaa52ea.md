---
doc_id: "3f00e09cacaa52ea"
source_url: "https://mohua.gov.in/static/uploads/2025/10/b8380395459093f64b2232d883808f4a.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Guidelines"
date: "2025-10-29"
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9bac9940d8cbb2f3"
---

<!-- page 1 -->

Hkkjr ljdkj Government of India
“kgjh fodkl ea=ky; Ministry of Urban Development
INSTRUCTION FOR SANCTION AND IMPLEMENTATION OF PROJECTS OUT OF 10%
LUMP SUM PROVISION FOR THE BENEFIT OF NORTH EASTERN REGION
INCLUDING SIKKIM

1.

Introduction

The Scheme of 10% Lump Sum Provision for the benefit of North Eastern Region
including Sikkim became operational in the Ministry of Urban Development from the
financial year 2001-02. It is now under implementation as per guidelines of Non-Lapsable
Central Pool of Resources (NLCPR). The assistance released from the Pool is tied with
the project and no diversion is permissible.
2.

Objective of the Scheme

The broad objective of the scheme is to ensure speedy development of
infrastructure in the North Eastern Region including Sikkim by increasing the flow of
budgetary financing for new infrastructure projects / schemes in the Region. Both physical
and social infrastructure sectors will be considered for providing support under the Central
Pool, with projects relating to basic services like Water and Sanitation receiving priority.
3.

Coverage

All urban areas falling under North Eastern Region and Sikkim excepting cities
covered under Urban Infrastructure and Governance component of Jawaharlal Nehru
National Urban Renewal Mission (JNNURM) shall be eligible for assistance under the
scheme subject to availability of funds.
4.

Admissible Components
Grants-in-aid under the scheme shall be released for the following thrust areas:-

(i)

Water supply – Urban Water Supply Programme / Augmentation of water supply

(ii)

Development / Improvement of Sewerage System / Sanitation projects / Septage
Management / City Sanitation Plan

(iii)

Solid Waste Management Project / decentralized treatment of liquid waste

(iv)

Construction of Bridges / Flyovers / Footpaths

(v)

Construction of market complex / parking complexes / truck terminus
1

<!-- page 2 -->

(vi)

Construction of retaining wall

(vii)

Civic amenities like playground, community hall, night shelters, old age and
destitute children home, burial and cremation ground

(viii)

Improvement of existing / construction of new roads, pavements

(ix)

Drainage system such as Storm water drainage

5.

Inadmissible Components:

(i)
(ii)
(iii)
(iv)

Salary and Wages
Purchase of Vehicles
Furniture and fixtures
Regular maintenance works

6.

Institutional arrangement at the level of Central Government to approve the
projects as per Department of Expenditure OM No. 1(3)/PF.II/2001 dated 1st
April, 2010.

(a)

Ministry of Urban Development in normal course
(For proposal costing less than Rs. 25.00 crores)

(b)

Standing Finance Committee (SFC)
(For proposal costing Rs. 25.00 crore or more but less than Rs. 100.00 crore)

(i)
(ii)
(iii)
(iv)

Secretary of the Administrative Ministry / Department
Chairperson
Financial Advisor of the Administrative Ministry/ Department Member
Joint Secretary in-charge of the Subject Division
Member
Representative of the Planning Commission, Department of Expenditure and M/o
DoNER. Representative of any other Ministry / Department that the Secretary /
Financial Advisor may suggest can also be invited, as per requirement.

(c)

Expenditure Finance Committee (EFC)
(For proposal costing Rs. 100.00 crore or more but less than Rs. 300.00 crore)

(i)
(ii)
(iii)
(iv)
(v)

Secretary of the Administrative Ministry / Department
Chairman
Secretary (Planning Commission) or his representative
Member
Secretary (Department of Expenditure) or his representative Member
Financial Advisor of the Administrative Ministry/Department
Member Secretary
Representative of the Planning Commission, Department of Expenditure and M/o
DoNER. Representative of any other Ministry / Department that the Secretary /
Financial Advisor may suggest can also be invited, as per requirement.
(Secretary Ministry of DoNER may be an ‘Invitee’)
2

<!-- page 3 -->

(d)

Expenditure Finance Committee (EFC)
(For proposal costing Rs. 300.00 crore and above)
Secretary (Department of Expenditure)
Chairman
Secretary (Planning Commission) or his representative
Member
Secretary of the Administrative Ministry
Member
Financial Advisor of the Administrative Ministry / Department Member Secretary
Representative of the Planning Commission, Department of Expenditure and M/o
DoNER. Representative of any other Ministry / Department that the Secretary /
Financial Advisor may suggest can also be invited, as per requirement.

(i)
(ii)
(iii)
(iv)
(v)

(Secretary Ministry of DoNER may be an ‘Invitee’)
(e)

Appraisal limits (Rs. in Crore)
Limit
Appraisal forum
< 25.0
Ministry in normal course
≥ 25.0 & < 100.0
Standing Finance Committee (SFC)
≥ 100.0 & < 300.0 Expenditure Finance Committee (EFC) chaired by Secretary
of Administrative Ministry / Department
=≥ 300.0
Public Investment Board (PIB) / Expenditure Finance
Committee (EFC) chaired by Secretary (Expenditure); project
/ scheme where financial returns are quantifiable will be
considered by PIB and other by EFC

(f)

Approval limits (Rs. in Crore)
Limit
Appraisal forum
< 25.0
Secretary of Administrative Ministry / Department
≥ 25.0 & <150.0 Minister in-charge of Ministry / Department
≥ 150.0 & < Minister-in-charge of Ministry/Department & Minister of Finance
300.0
=≥ 300.0
Cabinet / Cabinet Committees
The institutional arrangements at the level of Central Govt. will be as per the
Department of Expenditure’s OM dated 1(3)/PF-II/2001 dated 1st April, 2010 and as
amended from time to time by the Ministry of Finance. In case of any amendment
in the limits in the appraisal limit or approval limit by Department of Expenditure in
future, the limits included in para above will be deemed to have been automatically
amended in accordance with the instructions of Ministry of Finance.

7.

Allocation of funds
(i)

The allocation of funds for the States for the year would be worked out keeping in
view equitable distribution of resources for the states and also considering
various parameters such as completion of projects, present performance in
utilizing funds, number of urban settlements, urban population, coverage of new
urban centers etc. inter-State and intra-State difference, Human Development
Indices, BPL population, infrastructure density area and terrain would also be
kept in mind.
3

<!-- page 4 -->

8.

Criteria for submission of proposals
The following are the requirements to be ensured while forwarding the proposal(s)
for consideration under the scheme:(i)

The proposal should be for financing of capital projects or improving
utilization of existing assets.

(ii)

The proposal should be accompanied by a Detailed Project Report (DPR)
and should be cleared from all administrative and regulatory angles such as
land being free of encumbrance, environment clearance, observance of
building byelaws etc. The DPR should be submitted after endorsement by
the concerned Municipal Body (Urban Local Body).

(iii)

The projects with an outlay of more than Rs. 2.00 crore may be given priority.

(iv)

Each location-specific project would be counted as one.
small projects into one will not be allowed.

(v)

The cost of land acquisition is not eligible for funding under the Scheme.

(vi)

The proposal should be forwarded by the Urban Development Department of
the State.

(vii)

The projects should be implementable within 2-3 years.

(viii)

Preference shall be accorded to those projects which are included in the
Prime Minister’s package, if any, announced for the State / Region.

(ix)

State Government should send proposal after considering the overall
priorities of the cities / towns. Such shelf of projects should be furnished at
the beginning of every financial year. All projects included in the shelf of
project shall have the same interse priority for the purpose of short listing and
sanction by the Ministry. Any change in the list should be communicated to
the Ministry duly approved by the Competent Authority.

(x)

Before considering the project proposal by the Ministry, the State
Government should confirm that encumbrance free land is available for the
proposed project and will be physically made available to the implementing
agency as soon as the project is sanctioned.

(xi)

No change in scope or design shall be permitted. In case the scope of the
project gets changed due to unavoidable circumstances, revised DPR should
be submitted and approval of Ministry should be taken before execution of
further work.
4

Clubbing many

<!-- page 5 -->

(xii)

Only those project proposals which cannot be funded under state plan should
to be submitted under 10% lump sum scheme.

(xiii)

The State Government should ensure that external power supply and water
is immediately made available on completion of project

(xiv)

Mechanism for handing over assets created and its operational and
maintenance under any projects under the scheme should be clearly
delineated before submission of a proposal to M/o Urban Development.
Funds under this scheme would not be used to substitute a budgeted
ongoing project or scheme.

(xv)

9.

In case the project is not found viable or does not meet the requirements mentioned
above for consideration under the scheme, it will be returned to the State
Government / concerned agencies and the reasons communicated.

10.

Procedure for submission and sanction of the projects.
(i)

Projects should be submitted by Municipal Bodies through the Department of
Urban Development of the respective states and included in the shelf of project.

(ii)

State Government should certify that the specific projects submitted to the
Ministry of Urban Development, Government of India, are not duplicated within
the State outlay. It may also be certified that the DPR for such project is not
being submitted to any other authority for financial assistance.

(iii)

The area covered under the project should be those which have been included in
census 2011 or are townships notified by the State Govts. A copy of such
notification / certification that the town is included in the Census 2011 or has
been categorized as town is to be enclosed alongwith DPR.

(iv) The Ministry of Urban Development will get the projects appraised through its
technical wings to ascertain technical soundness and economic viability. This,
however, shall not obviate the need for due diligence and vetting at State level by
its own technical agencies.
(v)

In case, any of the State Govt. desires to get the project implemented through
central agencies such as NBCC then the detailed project proposal prepared by
these agencies have to be submitted and recommended by the State
Government.

(vi) All projects must be completed within a definite time line and no cost / time
overruns will be allowed. Better performing States which utilize funds and
complete projects within the stipulated time will be given preference in
sanctioning of more projects.
5

<!-- page 6 -->

(vii) Proposals relating to escalation in cost of sanctioned projects will not qualify for
consideration under this scheme. Cost escalations shall be met by concerned
State Governments.
(viii) To consider sanction of projects out of the shelf of the projects sent by the States
a Committee chaired by Joint Secretary (UD) with JS (M), JS&FA, representative
from Ministry of DONER with Director (UD) as Convenor / Secretary would
review the shelf of the project to shortlist projects for sanction. The short listing
would be done keeping in view availability of vetted DPRs, eligibility of the project
under the guidelines. The Committee would ensure that the projects shortlisted
for sanction do not overlap with the projects of other Ministries and also whether
any other project being sanctioned/already sanctioned by other ministries can
fulfil the requirements that are sought to be fulfilled by the proposed project.
(ix) The shortlisted projects would be sanctioned out of the states allocation for new
projects subject to availability of funds.
(x)

11.

The Committee will work out the state allocation of funds for the year considering
various parameters such as completion of projects, present performance in
utilizing funds, number of urban settlements, urban population, coverage of new
urban centres etc.
Financing Pattern

(i)

(ii)

12.

Funds will be released to the State Government / Executing agency whose
projects have been routed through and recommended by respective State
Government.
For projects to be executed by the State Government through their agencies, the
cost shall be shared by the Central and State Government in ratio of 90:10.
However, in case of projects to be executed by Central Government agency, the
sanctioning committee may provide enhanced level funding. The State will bear /
waive Turn Over Tax / Work Contact Tax, or any such State level taxes where
the projects are executed by Central Agency.
Release of funds

(i)

Once the proposal is found suitable for support under the Scheme the Ministry of
Urban Development shall release funds to the executing agency / State
Government.

(ii)

Funds for the projects sanctioned will be released in three instalments depending
upon the progress both physical and financial in the following ratio 30:40:30. The
first instalment shall be released once the state is ready to award the work after
completion of all formalities on submission of documents relating to
6

<!-- page 7 -->

administrative sanction, technical sanction, environmental clearance, permission
for right of way and work order placed on the contractor.
(iii)

The 2nd/ subsequent instalments would be released only after the utilization of
80% of the previous instalments and full utilization of all other prior releases
including the State share, if any. However, if any UC(s) has become due as per
provisions of GFRs, release of subsequent instalment shall be subject to
fulfilment of the said provisions.

(iv) Releases under the scheme shall depend on timely submission of the Utilization
Certificates & Quarterly Progress Reports to the Ministry of Urban Development.
(v)

13.

State Govts should release funds to the Executing Agency within a fortnight of
receipt of the same in order to ensure timely completion of the project.
Submission of Utilization Certificates

(i)

Utilization Certificate would be submitted by the executing agency (either a
Central Agency like NBCC or a State Agency) based on the implementation
schedule given in the original project proposal. In any case, 100% UCs in the
proforma prescribed for the purpose shall have to be provided within 6 months of
completion of the project.

(ii)

UCs shall be issued only after the expenditure on the project has been incurred
by the implementing agency.

(iii)

UCs should be duly counter-signed by the Secretary of the Urban Development
Department on behalf of the State Government/General Manager in case
executing agency is from Central Government.

(iv) Release of further instalments shall be recommended only after receipt of UCs
and a review of the implementation of the programme / project.
14.

Monitoring & Evaluation
(i)

The States and the executing agencies shall report quarterly the progress of the
respective projects indicating the cumulative achievement upto the end of the
quarter under report.

(ii)

The Quarterly Progress Report (QPR) should reach Joint Secretary(UD), Ministry
of Urban Development within three weeks of the end of the quarter under report.

(iii)

State Governments should create a Project Monitoring Cell, which will closely
monitor all ongoing projects to ensure timely completion of the projects. State
Government should conduct a study of at least 5 (five) identified projects so as to
7

<!-- page 8 -->

find out causes for cost and time overruns of projects, to identify areas for
improvement and take remedial measures.
15.

Monitoring Mechanism at the States level
(i)

16.

17.

Chief Secretaries of the State Governments shall be expected to hold monthly
meetings to review the progress of ongoing projects under the Scheme and make
available summary record of such meetings to the Ministry of Urban
Development, where a monitoring cell may be created for the purpose.
Monitoring Mechanism at the Centre.

(i)

In the Ministry of Urban Development, Govt. of India, there will be a Monitoring
Committee headed by the Joint Secretary (UD) with Director (UD), Director
(Finance) and representatives of Ministry of DoNER, Ministry of Finance and
Planning Commission. The committee will meet once in a quarter.

(ii)

Monitoring & Evaluation of implementation of the project shall also be undertaken
through field inspections by officers of Ministry of Urban Development, also
impact studies, social audits and evaluations would be conducted by
Governmental or independent agencies at the request of the Ministry.
Third Party Monitoring Mechanism
Third Party Monitoring Mechanism would be employed by MoUD to keep track the
progress of the project / scheme. Expenditure in this regard would be met from the
Non-plan Expenditure in MoUD budget for professional services.

18.

Transparency and Publicity of Information
In order to ensure that the information about developmental schemes being
financed through the Scheme of Lump Sum provision for North Eastern Region and
Sikkim reaches the ultimate beneficiaries, i.e the targeted population, there is a
need to ensure greater transparency and publicity of information. For this purpose,
the following shall be ensured.
(i)

The State Governments should observe all the statutory formalities which
include calling tenders on a competitive basis through advertisement in
leading newspapers/trade journals, website etc.

(ii)

State Governments should display boards at project sites, including road
sides etc, indicating the date of sanction of the project, date of
commencement of the project, likely date of completion, estimated cost of
the project, source of funding i.e, the name of the Scheme.
8

<!-- page 9 -->

(iii)

It may be ensured by the state governments that assets created are well
maintained and mechanism for recovery of maintenance plans should be
development prior to execution of the project.

(iv) The possibility of executing project on PPP basis should be explored
actively rather than resorting to grant funding in all cases. This option can
be considered especially in the case of commercially viable projects such
as bus stands and shopping complexes. MoUD will be open to funding of
preparation of DPRs in respect such projects.
******
07.02.2013

9
