---
doc_id: "3ffbbfa787a737ad"
source_url: "https://www.labour.gov.in/static/uploads/2025/07/9b50a3bbd69e4e45f7dc2d5a5f3e7e0c.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Draft copy of National Career Service Centre for SC and ST (Group C) Recruitment Rules, 2017"
date: "2017-04-12"
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "85b41f770edb74b1"
---

<!-- page 1 -->

F.No.n G F..-A-12018/U112017-l!:.E-UI
Government of India
Mjnistry of Labour & F:m}lloyment
Din:ctorate Gcncn1l of Employment

Sbram Shaldi llhawan, Raii Marg,
New Delhi, dated the April I 'l,..-.-2017
CIRClJLAR
Sub:

Amendment of Recruitment Rules - For Group 'C' Posts in NCS Centre for
SC/ST~ undel' Directorate Gcncntlof Employment- reg.

His proposed to amend the existing Recruitment Rules titled Coaching-cum-Guidance
Centre (Group 'C' & 'I)' posts) Rules, 2004 notified vide GSR No.38 dated 28.01.2004. The
draft Recruitment Rules Jor Group 'C' posls (MTS, LDC, UDC, Stenographer and Instructor
Stenography) in the National Career Service Centres lor SC/STs under the Directorate General
of Employment is enclosed for information of all stakeholder/;. Any suggestion/comments on
the proposed amendment to the Recruitment Rules may be ~uhmiued to the undersigned within
30 days from the date of issue of !his Circular.

To,

l.
2.
3.

All the SRF.O~, NCS Centre fm· SC/STs under DGE.
l'S to DDG(E )/Director of Employment, DW:t(HQ).
NlC, Ministry of Labour & Employment fo•· uploading the cil·cular in Ministry's
Website.

~! l>R..\Fl'" ~J< IS S€.NT ~7' E.N\M1.. .,-.,. ~'- S~E.O~. I>RAF~

~~

\S A-l..So
W£tilS!l\'E.

A\/Pci~~L..E

1-.1

t-1\\N

OF LA<lot..lR..lol. E~~·_s

<!-- page 2 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDJN'ARY PART II, SECTION 3(i)J

Govcmmcnt of India
Ministry of J,a\Jour and Employment
Directorate General of Employment
New Delhi, thc~~pril, 20 17
Notification
G.S.R. No. . ......... -In exercise of the powers conferred by the proviso to article 309 of the Constitution, and in supersession of the
Coaching-cum-Guidance Centre (Group 'C' and 'D' Recruitment Rules, 2004, except as respects things done or omitted to be done before
such Sllpersession, the President hereby makes the following rules including method of recruitment of Group 'C' posts in the Offices of
National Career Service Centre for SCjSTs under the Directorate General of Employment, Ministry of Labour and Employment, namely:!.
Short title and commencement:- (1) These rules may be called the National C<treer Service Centre for SC/STs {Group 'C')
Recruitment Rules, 2017. (2) They shall come into force on the dale of their publication in the Offidal Gazette.
2.

Application:- These rules shall apply to the posts spedfied in column (ll of the Schedule annexed to these rules.

3.
Number of posts, classification, Level in Pay Matrix:· The number of posts, classification and the Level in the Pay Matrix attached
thereto, shall be as specified in columns (2) to (4) of the said Schedule annexed to these rules.
4.
Method of recruitment, age-limit, qualifications etc.- The method of recruitment, age-limit, qualifications etc. and other matters
relating thereto, shall be as specified in columns (5} to (13) of the said Schedule.
5.

Disqualifications.- No person,·
(a) who has entered into or contracted a marriage with a per·son having a spouse living; or(b) who having a spouse living, has entered into or contracted a man·iage with any person,
shall be eligible for appointment. to the said post:
Provided that the Central Govenuncnt may, if satisfied t11at such marriage is permissible under the per·sonal law applicable to
such person and the other party to the marriage and that there are other grounds for so doing, exempt any person from the operation of
llus rule.
6.
Pm>ver to relax.- Where the Central Government is of the opinion that it is necessary or expedient to do so, it may by order, for
reasons to be recorded in writing relax any of the provisions of these rules with respect to any class or category of persons.
7.
Saving clause.-· Nothing in these rules shall affect reservations, relaxation of age-limit and other concessions required to be
provided for candidates belonging to the Scheduled Castes, the Scheduled Tribes, Other Backwar·d Classes, Ex-Serviceman and other
special catego1ics of persons, in accordance with the orders issued by the Central Government from time to time in this regard.

<!-- page 3 -->

Schedule
Name of Post

Number ·o i Post

c iiisSJfication

Level in tl1 e
Pay Matrix

Whethe r

Age limii !Oi direct recruitment

Education and
other
Qua lifications
r~uired for
direct recnuits

6

7

selection

post or nonselection
post

1.
Multi-Tasking
Staff

2.
51 " (2017)
' Subject to
variation
dependent on
workload

- .

3.
General
Central
.serviceGroup 'C'
No nGazetted,
Non
Mi nisterial

-.

4.

Level l
(Rs.18000
- 56900)

-

5.
Nonapplicable

Between1S and 25 Years .o fag e.

Matriculation
pass or its
(upper age limit IS relaxable · for . equivalent
candidates belonging to Schedules
Castes/Scheduled Tribes/Other Backward OR
· Classes/Persons
with
Disab ihti es/El<Servicemen!Departmenlal and Centra! Industrial
Government Employees in a ccordance Training
with the instruction s or orders issued by Institute (I TI)
the Government of India fro m time-to- pass
time.)

· Nore: The crucial date for determining tl1e
age limit sllall be the closing da!e of
receipt of app~cation from ca ndidates In
India (and not the closing date prescribed
for
those
in Assam,
Meghalaya,
Arunachal Pradesh, Mizoram. Manipur,
Nagaland, Tripura, Sikkim,
Ladakh
Division of J&K Slate, Lahual and Spiti
· D istrict a nd Pangi Sub Division Chamba
d lslrict of Himachal Pradesh, A ndaman &
Nicobar Islands or Lakshadw e€p) .

......

·-

.....

..

Whether age
and
educational
qualifications
prescribed
for direct
recruitment
will apply in
the case of
omotees

8
Not
applicable

<!-- page 4 -->

'· ,eriod of
probation, if
any

Method of
recruitment whether
by direct recruitment
or by promotion or
deputation/
absorption and
percentage of the
vacancies to be
filled by various
methods

- ..

In case of
recruitments by
promotion/
deputation/
absorption grades
from which
promotion/
deputation!
absorption to be
made

It"DPC exists, what is its composition

Circumstances in which

U PSG is to be consulted in
making recruitment

... ··- --+-------,,..,-----------1

--~~--+---~~~~--~~~~~----~--------------------~---·-

10
Two Years ; By direct r-ecru~ment

--- 9

11

Not applicable

12

Group

13

·c· - Departmental Confirmation Committee:-

Not applicable

1.

Director of EmploymenUJoint Director of Employment of DGE.

- Chairman
2.

Deputy Director of Employment/
Employment of DGE - Member

3.

Sub-Regional Employment Officer, National Career Service
Centre for Schedule Castes /Scheduled Tribes under DGE Member

4.

A Gazetted Officer belonging to Scheduled Castel Scheduled
Tribe- ·Member

L-----------'-----------------'----------------'-------------------------··-...

Assistant

Director of

<!-- page 5 -->

Schedule
Na-me"oiPosi····-.--N:-:-um--,-be_r__o-=-f-,-·Classificalion
Post

l

Level in the ···rw=h-el:::-h_e_rs-e71e--c"""ti-on-;,-·- .Age lim~ for direct ··-··--Education and Other .. ""Whether age and·-·
pay Matrix
post or nonrecruitment
Qualifications required for
educational
selection post
direct recruits
qualifications
prescribed for direct
recruitment will
apply in the case of
promotes_ .
.. ... . ... ........... .
7
6
8 - - --:--:-1
Yes, to the extent
(Rs.19900of age
qualification
from
a indicated in Column
63200)
recognized
Board
or 11
(upper age limit is University;
relaxable for candidates
belonging to Schedules (ii) A typing speed of 35
Castes/Scheduled
w. p.m. in English or 30
Tribes/Other
Backward w.p.m
in
Hindi on
Classes/Persons
with , Computer.
'
Disabilities/ExServicemen/Departmental ' (35 w.p.m. and 30 w.p.m.
to 10500
and Central Government correspond
Employees in accordance KDPHI9000 KDPH on an
with the instructions or average
of
5
key
orders issued by the depressions for each
Government of India from word)
lime-to-lime.)

~7L-ov-,-e-r1~D~iv~is7io-n-+-~2~5~.~~~-0~1~7:::-)-+-~G~e~~~~-ra~I-·_-:_I·-··-~Le-~~~~~~2-~~N~o-n~-s~!~ie-c~t~io-n-~B-efuv~e-e_n_1~8~~a-n~d~2~7~ye_a_r-~(~i)~1~2~mc~la_s_s~o_r_e_q_u~iv-a~le-ontCier1<
·subject to
variation
dependent on
workload

Central
Service Group 'C'
Non-Gazetted,
Non Ministerial

Note: The crucial date for
determining the age limit
shall be as fixed by the
Staff
Selection
Commission.
(Where .
recruitment is not through ·
sse. Cfucial date for
determining the age limit
shall be the last date for
receipt of applications.)

<!-- page 6 -->

of

Period of
probation, if
any

Method
recruitrrleni"wii'ei'ti.er by direct
recruitment or by promotion or deputation/
absorption and percentage of the vacancies
to be filled by various methods

9

10
(Q 85% by direct recruitment through sse.

Two Years

II DPC exists, what is its
composition

In case of recruitments by promotionf
deputation/ absorption grades from
which promotion/ deputation/
absorption to be made

of

11

!

Circttmstance
sin which
UPSC is to be
consulted in
making
recruitment

12

10%
th.e vacanCies shall be filled :, Group 'C' - Departmental Promotion/
from amongst the Group C Staff in the Confimnation Commilfee:
(ii) 1O"h or the vacancies shall be filed from Level 1 of pay matrix and who possess
amongst the Group C Staff In the Level 1 of 12"' Class pass Of equivalent 1. Director of Employmen!IJoint Director of
pay matnx and who possess 12"' Class quafificalion and have rendered 3
Employment of DGE. - Chairman
pass or equivalent q ualifK:alion and have years regular seNice in the grade, on
rendered 3 years regular service in the the basis of departmental qualifying 2. Deputy DirectOf of Employment/ Assistant :
Director of Employment of DGE
grade. on the basis of departmental examination . The maximum age limit
qualifying e)(aminalion. The maximum age for eligibility for examination is 45
Member
limit for eligibility for examination is · 45 years. (50 years of age for SC/ST)
years. (50 years of age for SC/ST)
3. Sub-Regional
Employment
Officer,
National Career Service Centre for
I
Note:- If more of such employees than the ' Note:- If more of such employees than
Schedule Castes /Scheduled Tribes
number of vacancies available under !he number of vacancies available
under DGE - Member
Clause (ii) qualified sf the examination, such under Clause (ii) qualified at the
excess number of employees shall be examination, such excess number of 4. A Gazetted Officer belonging to
considered for filling the vacancies arising in employees shall be considered for
Scheduled Castel Scheduled Tribe •
Member
the subsequent years so that the employees filling the vacancies arising in the
qualifying at an earlier examination are subsequent years so that the
considered before those who qualify at a employees qualifying at an earlier
later examination.
examination are considered before
those who qualify at a later
(iii) 5% of the vacancies shall be filled on examination.
seniority-cum-fitness basis from Group C
employees who have 3 years regular 5% of the vacancies shall be lolled on ,
service In posts with the pay scale of Level seniority-cum-fitness basis from Group '
C employees who have 3 years r99ular :
1 of pay matrix
service in posts with the pay scale of
- - - - - - - ------..L...:L:.:e:..:v.::cel'-1'-o"'f:..r..:a"'-'m:.:.at=ri:.:.x____ ....

1

·· · ---------------~------'
j

!

i

I

<!-- page 7 -->

Schedule
Name of Post

f-:-:-.- .

Number of Post

2.
25• (2017)

1.

Upper Division Clerk

•subject to
variation
dependent on
wort< load

Classification

the.]

..

· ··Level in
pay Matrix
. ..
4.
Level4

··-·- ....
3.
General Central
ServiceGroup·c·
Non-Gazetted,
Non Ministerial

.
'

Whether
selection post or
non-selection
post

Age limit for direct recruitment

Education and other
Qualifications
required for direct
recruits

5.

7

8

Non-Selection.

(Rs.2550081000)

'

:

....

--···.

Between fsari"(i" 27 years of age

Degree
recognized
(upper age limit is relaxable for University
candidates belonging to Schedules equivalent.
CastesfScheduled
Tribes/Other
Backward Classes/Persons with
Disabilities/ExServicemen/Departmental
and.
Central Government Employees in :
accordance with tlle instructions or
ordets issued by the Government of
India from time-to-time.)
The crucial date for
Note:
Cletermining the ;Jge limit shall be
as fixed by the Staff Selection
Commission. (Where recruitment is
not through sse. crucial date for
determining the age limit shall be
the last date for receipt of
applications.)

····-··

--·of
or

<!-- page 8 -->

Whether.age
and educational
qualifications
prescribed for
direct
recruitment will
apply in the case
of promotBs

Pe~io(for·-.---,M'""e""ll1::-od,.,-o"'"'f.---...,c::ln"""'ca,..,.,se.,...,o7
f '"'re"'c.,.ru"""'it'"'m'"'e=-=n·'""ts hy promotion/

If DPC exists, whal is its composition

probation, if
any

Circumsta
ncesin
which
UPSC is
to be
consulted
in making

recruitment whether deputation/ absorption grades from
by direct recruitment which promotion/ deputation/ absorption
or by promotion or
to be made
deputation/
absorption and
percentage of tne
recru~en
vacancies to be filled
by various methods
t
. ·--;~--t-----::-----if--!"<-=:..:=;~=~
·----...,,.,..,------ t - - - - --13
8
9
10
Groop
Departmental·.
Not
Not applicable
'i'Vio Years lor 1. By promotion Promotion
failing
which
by
PromotiOn/Confirmation
Committee:
applicable
direct
Lower DiVision Cieri<. (Level 2 in Pay
recru~ment.
deputation,
1. Director of Employment/Joint Director
Matrix) will1 eight years' service in the
'Nir for
of Employment of DGE. - Chainnan
or
grade
promotees

- r2

·c·

2.
2. Direct recruitment 1 Note:
through
S1aff Where juniors who have completed
Selection
their qualifying of eligibility service are
Commission.
being considered for promotion, their
SMior would also be considered ' 3.
provided they are not short of the
requisite qualifying or eligibility service
by more than half of such qualifying/
, eligibility service or 2 years, whichever
is less and have successfully completed 4.
their probation period for promotion to
the next higher grade along with their
juniors who have already completed
such qualifying/ eligibility service

· · - - - - - '- - - - - ' - - -- - ·

Deputy Director of Employment/
Assistant Director of Employment of
DGE • Member
Sub-Regional Employment Officer,
National Career Service Centre for
Schedule Castes /Scheduled Tribes
under DGE • Member
A Gazetted Officer belonging to
Scheduled Casle/ Scheduled Tribe ·
Member

<!-- page 9 -->

(

Deputation
Officers of the Central Government:
(i) holding analogous post on regular
basis; or
(ii) with eight years regular service in the
grade of Lower Division Cieri( (Level 2 in
Pay Matrix) or equivalent.
T he departmental officer in the feeder
category who are in the direct line of
promotion shall not be eligible for
consideration for appointment on
deputation.
Similarly, the deputationists shall not be
eligible for consideration for appointment
by promotion.
Period of deputation including the period
of deputation in another ex-cadre post
preceding
the
held
immediately
appointment in the same of some other
organization or department of the
Central Government shall ordinarily not
exceed three years.
The Maximum age limit for appointment
by deputation shall be "Not exceeding
56 years' as on the closing dale of
receipt of applications.

<!-- page 10 -->

Schedule
Name of Post

Number of
Post

1.
Stenographer
Grade 'D'

2.
. ···-··
-f4' (2017}

'

•subject to
variation
dependent
on workload

C lassifieatio.n ·

Level in the

pay Matrix
3. General
Central
ServiceGroup'C'
NonGazetted,
Non
Ministerial

4.
Level4
(Rs.25500-

81000)

Whether
selection post
or nonselection post

5.
Not applicable

Age iimlt for d irect recruitment

--

6

Between 18 and 27 years of age

I Education and other Qualifications

'

required for direct recruits

- -·(i) ·-121

7

class pass or equivalent
from a recognized Board or
University

(upper age limit is relaxable for
candidates belonging to Schedules
Tribes/Other (ii) Skill Test Norms Dictation: 10
· Castes/Scheduled
Backward
Classes/Persons
with mts @ 80 w.p.m.
Disabilities/ExServlcemen/Oepartrnental
and Trascrlpllon:
Central Government Employees in
accordar>ce with the instructions or 65 mts.(Eng.)f75 mts.(Hindi) (On
orders issued by the Government of Manual Typewriter) or
India from time-to-time.}
50 mts. (Eng.), 65 mts. (hindi)
(on Computer)
Note:
The crucial date for
determining the age lmit shall be as
advertised by the Staff Selection
Commission. (Where recruitment is
not through
crucial date for
determining the age limit shall be tile ,
last date for recei!:!l of B!:!21ications.) I

sse.

.I

.. _

.,I
I

<!-- page 11 -->

Whether age
and educational
qualifications
prescribed for
direct
recruitment will
apply In the case
of promotes

Period of
probation, if

any

8

9

Not applicable

Two Years

In case cit ·
recruitments by
promotion/
deputation/
absorption
grades from
which promotion/
deputation/
absorption to be
made
10
11
Direct recruitment through Stair Not applicable
Seleclion Commission

If DPC exists, what is its composition

' Note: Vacancies caused by the
incumbent
being
away
on
deputation or long dlness or study
leave
or
under
other
circumstances for duration of one
year or m<lre may be filled on
deputation from the officials of the
·, central
Government
holding
analogous posts or regular basis
and possessing the qualification
prescribed lor direct recruits at Col.
8.

1. Director of Emptoymeni/Joint Director
Employment of DGE. - Chainnan

Method of recruibnent whether by
direct recruitment or by promotion
or dei)(Jtation/ absorption and
percentage of the vacancies to be
filled by various methods

·c· -

Group
Committee:

2.

Circumstance
s in which
UPSC isto
be consulted
in making
recruitment

12
DepartmentaiPromotion/Confirmation

of

Deputy Director of Employmenll Assistant :
Director of Employment of DGE - Member
·

3. Sub-Regional Employment Officer, National
Career Service Centre for Schedule Castes
/Scheduled Tribes under DGE - Member
4. A Gazetted Officer belonging to Scheduled
Caste/ Scheduled Tribe- Member

13
Not
applicable

<!-- page 12 -->

Schedule

I_ ame..
N_

oi 'P;-:o::s;l r--;N:-;:u-::m
~be=r:-:o:-;f--,r-;ctas=:-:SI:;;.fi;:ca=
tion
=-~(evei in tile
Post
Pay MatriX

1.

2.

Instructor
(Stenography)

13"

I

Whether
selection post
or non•
selection post

Age limit for direct recruitment

3~-~_,~;14~--~---~~~~.~~~~~~~s_~~+---_-~-~-~-~-----~7----------~~

General
Central
Service
Group 'C' NonGazetted/
Non-Ministerial

•(Subject to
variation
dependent
upon
workload)

Level6
Rs .35400112400)

Non-Seleciion

30 years of age.

(upper age limit is relaxable for
candidates belonging to Schedules
Castes/Scheduled
Tribes/Otller
. Backward
Classes/Persons
with
· Disabililles/ExSecvlcemen/Departmenfal and Central
Government Employees in accordance
with tile Instructions or orders issued
by the Govemme11t of India from !Wnet<>-lime.)
.· Note: The crucial dale for defarmining
• the age limit shall be the closing date
of application
from
of
receipt
candidates in India (and not the
closing date prescribed for those in
Assam,
Meg halaya,
Arunachal
Pradesh,
Mi;zoram.
Manipur,
Nagaland, Tripura, Sil<kim, LadaKh
Division of J&K State, Lahual and Spiti
District and Pangi Sub Division
Chamba district of Himachal Pradesh,
Andaman & Nicobar Islands or
Lakshadweep).

.,

c________ --.

L___ __

Education and other ·Qualifications
required for d irect recruits

_,___ __

_J.._

. -·--'---- - --'--------

(ai

~~~a·~~~~~~

· Graduate of a recogni;zed
University or equivalent.

(b)
Diploma
in
Secretariat
Practice/Commercial Practice from
recognized instHu6on or National
Council for Training in Vocational
Trades Certificate in Stenography
Recognised
institute/
from
Board/University).
experience
Three
years'
Instructor (Stenography}.

as

Desirable;
(I) Knowledge of Stenography in one
of the regional languages.
of
Computer
(ii)
Knowledge
Operation.
Note: "The qualifications regarding
experience are relaxable at the
discretion of the Appointing Authority
for reason to be recorded in writing
in case of candidates belonging to
SC & ST if at any stage of selection
the Appointing Authority is of the
opinion that sufficient number of
candidates from tllese communities
possesSing the requisite experience
are not ~kely to be available to fill up
the vacancies reserved for them.'

<!-- page 13 -->

Whether age and
educational
qualifications
prescribed for direct
recruitment will apply
in the case of
promotes

- ·--· ... .9..

Not applicable

·---

Pejiod of'·--·- Meltlod of recruitment lin case of
probation. if any
whether by direct
recruitments by
recruitment or by
· promotion/
promotion or
deputation/
deputatiorlf absorption absorption
and percentage of the grades from
vacancies to be filled
which promotion/
deputatiorlf
by various methods
absorption to be
made
10
11
12
Two Years
By direct recruitment
Not applicable

' - - - - - -- - -···..

If DPC exists, what is its oompositio n

13

.I

14

-

- Oepartmental
Group
'C"
Saeening
CommiUee/Oepartmental Confirmalion Committee:

.

-------'--~-----.J..._

Circumstances
in which UPSC
is to be
consulted in
making
recruitment

_____

1.

Director of EmploymenVJoint Director
Employment of DGE. - Chainnan

2.

Deputy Director of EmploymenVAssistant
Director of Employment of DGE - Member

3.

Sub-Regional Employment Officer. National
Career Service Centre for Schedule Castes
/Scheduled Tribes under DGE - Member

4.

A Gazetted Officer belonging to Scheduled
Caste/ Scheduled Tribe - Member

Not applicable

of

.J...__ __ _ _ _ _ _ _,_ _ _ _ _ __ _ _ ___.__ _ _ __ _ J
