---
doc_id: "3ef3c4a2dcbbf071"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/bb17d47bf0227787ab86dffbd3b81ad7.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Deputation/visits abroad exceeding five days - approval of Screening Committee of Secretaries reg."
date: "2010-12-13"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b90e3bb0c1807c83"
---

<!-- page 1 -->

No.DC- 23(2 )/E. Coord/2006
Government of India
Ministry of Finance
Department of Expenditure
E.Coord. Branch
North Block, New Delhi
~; 'p~ember,
2010

Subject: Deputation/visits abroad exceeding five days - approval of
Screening Committee of Secretaries reg.

******
Reference is invited to this Department's Office Memorandum of even
no. dated 23 July 2010 on the above subject.
2.
The foreign deputation of officers of the level of Joint Secretary and
below exceeding five days have been exempted from Screening Committee of
Secretaries (SCaS) procedure vide the aM referred to above. However, scas
procedure has been retained in respect of foreign deputation proposals where the
number of members exceeds five, irrespective of the level.
3.
Consequent to the issue of the above OM, clarificatioI1l have been
sought from this Department as to whether the scas procedure is applicable to
delegations where the size exceeds five in number but where the expenditure on
the visit of 5 or less members is borne by the Government of India.
4.
In this connection, it is clarified that the scas approval will not be
required in respect of cases where the delegation consists of officers of the level
of Joint Secretary and below and expenditure in the case of only 5 members or
below is borne by Government of India although the overall size of the
)
delegation may exceed five.
This issues with the approval of Cabinet secr~

p~

(Madhulika P. Su~
Joint Secretary to the Government of India
