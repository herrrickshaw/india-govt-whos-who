---
doc_id: "3ef7cfcc35b3a42f"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/d0c9ff46da2df73a5f858c60c233e5b8.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code '14404' National Consumer Helpline"
date: "2016-09-12"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f3d2c9a1110efd48"
---

<!-- page 1 -->

Government of Ind ia
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No. 16-3/2013-AS.lH/ Part-U/216B,3-3

Dated : 12/09/2016

To,
All Access Service Providers.
CORRIGENDUM
Subject:- Allocation of S hort Code as National Consu mer Helpline to M inistry of Co nsumer
Affairs, Food and Public Distrib ution , Govt. of India.

The undersigned is directed to convey the approva l of co111petent authority for a ll ocation of Short
Code '14404' as Natio nal Cons umer He lpline to Ministry ofCons u111er Affairs, Food and Public
Distribution. Govt. of India wit h features as und er:
(i)

Cateao r -1: Serv ice i.e. mandat r / sJ;~_otice__to_be__pm\~ided-b

(ii)

Accessib ili ty: Un-restricted i.e. ava il ab le on STD also.

all-th ~AGG@ss-1:>rev-icler~.------

· (i ii ) Metered Service: (It 111 ay be taken as Ca lled Party Pays or Call in g Party Pays depending
- - - - - - - -On a-intimati on. to this effect:-issued by the agency to which thi sshortc oae i5allocatecl in
furtherance to this DoT in struction) .
2.
The ea rli er iss ued short code 155277 fo r Natio nal Co nsu me1· Helpline to Ministry of
Consumer Affa irs, Food and Public Di strib ut ion , Govt. of India (copy encl osed) is withdrawn with
immed iate effect.
3.

/\II are req~1 es ted to take necessary acti on.

Copy forwarded for infor111at ion and necessary action to, if any, to:
1.
2.

3.
4

/

Secretary. TRA I.
Join t Secretary. Department of Consumer Affai rs, Ministry of Consum er Affairs, Food and
Publi c Di stribution. Krishi Bhawan. New Delhi- I I0001 with rererence to your D.O letter No.
0.110 11 / 11 /2 0 16-CVv' F/CP U elated 23/08/2 0 16 (It is requested to appoint a nodal officer to
i11111!e111ent the helpline. as and when cleciclecl).
CMD MTNL/ BSNL.
Director (T ERM-!), DoT (HQ) . (A ll TERM Ce ll s may be asked to co-ordin ate with
spective Noda l Officers and TSPs for implementation of Helpline. as and when
)proachecl).
\DG (IT) with request to kind ly upload on DoT Website.

<!-- page 2 -->

(

or

Covcrl!Il!Cll l
l ll<ii;J
M inisi n oi'C ommun ica1ion :..
D epa n rn en r o r T elecom mun ic;r 1 ion s

Ac c es~ Service ~ \Ving
2(J, As iioh; Road.!\('\\ Dc lh i-1JOOOJ

f\iu. j 6-3/2013-A.S .fil / Par1-f1/204/~.?iS /

Dated :09/08/2016

To
A ll Access Se r vic e: Providers.

S hort C od e '1::1::1277' a.<- Na tio11al C on s umer He lplin e w M ini srry of
Co ns um er· A ffair·~,, F<• t: u and l'ublic Disirillution. G ovt. of Indi a .

S ubj ec t: - Allocation of

The u11d ers ig11ed is di ree led 1c1 co n ve: · th e ap1m1va I of co mpetent auth ority for a Ilocat ion of
Shon Code '155277' as National Co nsumer Helpline to f\!lin istr.' of Cons um er Affa irs. Food and
Publi c Distribuiion. Govt. of India. with feat ures as und er:
(i)

Category-I: Serv ice (i.e. 111anda10ry senfice 10 be provided by a lI the Access providers .

(ii)

Accessibi lity: Un -restri cted i.e. ava il ab le on STD also.

(i ii) Metered Service: (It may be taken as Ca ll ed Party Pa ys or Ca lling Pa11y Pays depending
. on a separate intimati on. to this effect. issued from the agency to wh ich thi s sho11 cod1.--- - ­
is- all ocated iii-furtheranc e t01Fli's DoT in struct ion). ­
2.

All are requested LO rake necessary acti on.
(Sa nchit h:.umar Garg)

A.DFT(AS-IJI ;
Tel. : 011-2303(1 4~4

£ ma i! :sa n ch itk.ga rglu·gm .in

1.

3.
4.

5.

.l oin t Secrernry. Departrne111 of Co nsum er Affairs. IVlinistry of Consum er Affairs. Food and
Publ ic Dist ri bution. Kr ishi Bhawan. New Delhi-] l 000 I with reference to yo ur 0.0 letter No.
0.1101 l/ 11 /2016-CWF/CPU elated 03 /08/2016.
Secretary. TRA I.
CMD IVITNL/ BSNL.
Director (TE RM-.l ). DoT (HQ). (A ll TERM Cell s may be asked to co-ordinate with
respective Nodal Officers and TSPs for im plementat ion of Helpli11e. as and when ).
ADG ( IT ) with reques1 to kindl y upload on DoT Website.
