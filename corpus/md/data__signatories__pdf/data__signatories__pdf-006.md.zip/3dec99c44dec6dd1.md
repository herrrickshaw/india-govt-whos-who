---
doc_id: "3dec99c44dec6dd1"
source_url: "https://mines.gov.in/admin/download/64d46cc269f641691643074.pdf"
ministry: "Mines (MoM)"
title: "THE MINES AND MINERALS (DEVELOPMENT AND REGULATION) AMENDMENT ACT, 2023 (280.44 KB)"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "49ef34bacc0dac08"
---

<!-- page 1 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—23

REGISTERED NO. DL—(N)04/0007/2003—23

सी.जी.-डी.एल.-अ.-10082023-247989
xxxGIDHxxx
CG-DL-E-10082023-247989

xxxGIDExxx
vlk/kkj.k

EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 19]

ubZ fnYyh] cq/kokj] vxLr 9] 2023@ Jko.k 18] 1945 ¼'kd½

No. 19]

NEW DELHI, WEDNESDAY, AUGUST 9, 2023/SRAVANA 18, 1945 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 9th August, 2023/Sravana 18, 1945 (Saka)
The following Act of Parliament received the assent of the President on the
9th August, 2023 and is hereby published for general information:—

THE MINES AND MINERALS (DEVELOPMENT AND REGULATION)
AMENDMENT ACT, 2023
NO. 16 OF 2023
[9th August, 2023.]

An Act further to amend the Mines and Minerals (Development and
Regulation) Act, 1957.
BE it enacted by Parliament in the Seventy-fourth Year of the Republic of India as
follows:—
CHAPTER I
PRELIMINARY
1. (1) This Act may be called the Mines and Minerals (Development and Regulation)
Amendment Act, 2023.
(2) It shall come into force on such date as the Central Government may, by notification
in the Official Gazette, appoint.

Short title and
commencement.

<!-- page 2 -->

2
Amendment
of section 3.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

2. In section 3 of the Mines and Minerals (Development and Regulation) Act, 1957
(hereinafter referred to as the principal Act), in section 3,—
(i) after clause (aa), the following clause shall be inserted, namely:—
'(aaa) "exploration licence" means a licence granted for undertaking
reconnaissance operations or prospecting operations or both in respect of
minerals specified in the Seventh Schedule;';
(ii) in clause (ae), after the words "composite licence", the words ", exploration
licence" shall be inserted;
(iii) for clause (ha), the following clause shall be substituted, namely:—
'(ha) "reconnaissance operations" means any operations undertaken for
preliminary prospecting of a mineral through regional, aerial, geophysical or
geochemical surveys and geological mapping, and include pitting, trenching,
drilling and sub-surface excavation;'.

Amendment
of section 4.
Amendment
of section 4A.

3. In section 4 of the principal Act, in sub-section (1), after the words "prospecting
licence", the words "or of a exploration licence" shall be inserted.
4. In section 4A of the principal Act,—
(i) for the marginal heading, the following marginal heading shall be substituted,
namely:—
"Termination of prospecting licences, exploration licences or mining
leases.";
(ii) in sub-section (1), for the words "prospecting licence", at both the places
where they occur, the words "prospecting licence or exploration licence" shall be
substituted;
(iii) in sub-section (3), after the words "prospecting licence", the words "or
exploration licence" shall be inserted.

Amendment
of section 5.

5. In section 5 of the principal Act, for the marginal heading, the following marginal
heading shall be substituted, namely:—
"Restrictions on the grant of mineral concession.".

Amendment
of section 6.

6. In section 6 of the principal Act,—
(a) for the marginal heading, the following marginal heading shall be substituted,
namely:—
"Maximum area for which mineral concession may be granted.";
(b) in sub-section (1),—
(i) after clause (aa), the following clause shall be inserted, namely:—
"(ab) one or more exploration licences covering a total area of more
than five thousand square kilometres:
Provided that the area granted under a single exploration licence
shall not exceed one thousand square kilometres;";
(ii) in clause (c), for the words "reconnaissance permit, mining lease or
prospecting licence", the words "mineral concession" shall be substituted.

Substitution
of Chapter
heading of
Chapter III.

7. In Chapter III of the principal Act, for Chapter heading, the following Chapter
heading shall be substituted, namely:—
"PROCEDURE FOR OBTAINING MINERAL CONCESSION IN RESPECT OF LAND IN WHICH THE
MINERALS VEST IN THE GOVERNMENT".

67 of 1957.

<!-- page 3 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

8. In section 10 of the principal Act,—
(i) for the marginal heading, the following marginal heading shall be substituted,
namely:—

Amendment
of section 10.

"Application for mineral concession.";
(ii) in sub-section (4), in clause (a), for the words, figures and letters "sections
10B, 11, 11A or the rules made under section 11B", the words, figures and letters
"sections 10B, 10BA, 11, 11A, 11B or 11D" shall be substituted.
9. After section 10B of the principal Act, the following section shall be inserted,
namely:—
"10BA. (1) The provisions of this section shall not apply to—
(a) the areas covered under section 17A;
(b) the minerals specified in Part A of the First Schedule;
(c) the minerals specified in Part B of the First Schedule where the grade of
atomic mineral is equal to or greater than such threshold value as may be notified
by the Central Government from time to time;
(d) any land in respect of which the minerals do not vest in the Government.
(2) Notwithstanding anything contained in sections 10B and 11, an exploration
licence may be granted in any area by the State Government for the purpose of
undertaking reconnaissance or prospecting operations or both in respect of any mineral
specified in the Seventh Schedule.
(3) The Central Government may, by notification in the Official Gazette, and for
reasons to be recorded in writing, amend the Seventh Schedule so as to modify the
entries therein with effect from such date as may be specified in the said notification.
(4) The State Government shall, after obtaining the previous approval of the
Central Government, and in such manner as may be prescribed by the Central
Government, notify the areas in which exploration licence shall be granted, subject to
such terms and conditions as may be specified in the notification.
(5) The Central Government may require the State Government to notify the area
for grant of exploration licence within such period as may be fixed in consultation with
the State Government, and in case the State Government does not notify the area
within such period, the Central Government may, after the expiry of the period so fixed,
notify the area for grant of exploration licence.
(6) The State Government shall, for the purpose of granting exploration licence
through auction by method of competitive bidding, including e-auction, select an
applicant who fulfils the eligibility conditions as specified in this Act and grant
exploration licence to such applicant.
(7) Where—
(a) the State Government has not successfully completed auction for the
grant of exploration licence; or
(b) after completion of auction, the exploration licence or letter of intent for
grant of exploration licence has been terminated or lapsed for any reason
whatsoever,
the Central Government may require the State Government to conduct and complete
the auction or re-auction process, as the case may be, within such period as may be
fixed in consultation with the State Government, and in cases where such auction or
re-auction process is not completed within such period, the Central Government may,
after the expiry of the period so fixed, conduct auction for the grant of exploration
licence for such area:

Insertion of
new section
10BA.
Grant of
exploration
licence for
minerals
specified in
Seventh
Schedule
through
auction.

<!-- page 4 -->

4

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

Provided that upon successful completion of the auction, the Central Government
shall intimate the details of the preferred bidder in the auction to the State Government
and the State Government shall grant exploration licence for such area to such preferred
bidder in such manner as may be prescribed by the Central Government.
(8) The holder of exploration licence shall be entitled to a share of applicable
amount quoted in the auction of mining leases payable by the lessee to the State
Government in respect of the area granted in mining lease pursuant to the prospecting
operations undertaken by the holder of such exploration licence:
Provided that the share in applicable amount payable to the holder of exploration
licence by the lessee of such area shall be allowed only in respect of the minerals
specified in the Seventh Schedule.
(9) The Central Government shall by rules provide for the manner of conducting
auction for grant of exploration licence, including its terms and conditions, the bidding
parameters for selection, share payable to the holder of exploration licence from out of
the applicable amount quoted in auction of mining leases payable by the lessee of
such area, the period for such payment and such other conditions as may be necessary.
(10) Notwithstanding anything contained in section 7,—
(a) the exploration licence shall be granted for a period of five years from
the date of execution of the exploration licence;
(b) if, after three years from the date of execution of exploration licence,
but before the date of its expiry, the holder of the exploration licence makes an
application for the extension of the period of that licence, the State Government
may, on being satisfied that within the period of five years, it shall not be possible
for the holder of such licence to complete the reconnaissance or prospecting
operations for reasons beyond his control, extend the said period to a further
period not exceeding two years.
(11) After three years from the date of execution of the exploration licence, the
holder of such licence may retain an area not exceeding twenty-five per cent. of the
total area covered under that licence for the purpose of continuing reconnaissance or
prospecting operations and shall surrender the remaining area after submitting a report
to the State Government stating the reasons for retention of the area proposed to be
retained by him and the boundaries of that area.
(12) The holder of the exploration licence shall, within three months of the
completion of the operations for which licence has been granted, or of the date of
expiry of the exploration licence, whichever is earlier, submit a geological report to the
State Government explaining the result of the reconnaissance and prospecting
operations, in such manner as may be prescribed.
(13) If the holder of the exploration licence fails to complete the reconnaissance
and prospecting operations before expiry of the exploration licence, or fails to submit
the geological report within the period specified in sub-section (12), the State
Government may take such action as it deems fit, including imposition of penalty.
(14) Within six months from the date of receipt of the geological report from the
holder of the exploration licence, the Central Government or the State Government
shall initiate the auction process for grant of one or more separate mining leases under
section 10B or section 11 or section 11D, as the case may be, in respect of the area
where existence of mineral content is established and shall select the preferred bidder
for grant of such mining leases within one year from the date of receipt of the geological
report:
Provided that in case the preferred bidder is not selected within the period so
specified, the State Government shall pay to the person who was the holder of exploration
licence such amount, and in such manner, as may be prescribed.".

<!-- page 5 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

5

10. After section 11C, the following section shall be inserted, namely:—

Insertion of
new section
11D.

"11D. (1) Notwithstanding anything contained in this Act, the Central Government
shall, for the purpose of granting mining lease or composite licence in any area in
respect of any mineral specified in the Part D of the First Schedule, select, through
auction by method of competitive bidding, including e-auction, a preferred bidder who
fulfils the eligibility conditions as specified in section 5, on such terms and conditions,
and in such manner, as may be prescribed.

Central
Government
to conduct
auction for
grant of
mining lease
or composite
licence in
respect of
minerals
specified in
Part D of
First
Schedule.

(2) Upon successful completion of the auction, the Central Government shall
intimate the details of the preferred bidder in the auction to the State Government and
the State Government shall grant mining lease or composite licence for such area, to
such preferred bidder, in such manner, as may be prescribed by the Central Government.
(3) The royalty, dead rent, applicable amount quoted in the auction and any
other statutory payment in relation to the mining lease or composite licence auctioned
by the Central Government shall accrue to the State Government or concerned
authorities, as the case may be, as if the auction has been conducted by the State
Government.".
11. In section 12 of the principal Act,—
(a) for the marginal heading, the following marginal heading shall be substituted,
namely:—

Amendment
of section 12.

"Registers of mineral concession.";
(b) in sub-section (1),—
(i) in clause (e), the word "and" shall be omitted;
(ii) after clause (f), the following clauses shall be inserted, namely:—
"(g) a register of applications for exploration licences; and
(h) a register of exploration licences,".
12. In section 12A of the principal Act,—
(i) after the words "composite licence", wherever they occur, the words "or
exploration licence" shall be inserted;

Amendment
of section
12A.

(ii) in sub-section (4), in the proviso, for the words "or of a composite licence",
the words "or composite licence" shall be substituted.
13. In Chapter IV of the principal Act, for Chapter heading, the following Chapter
heading shall be substituted, namely:—
"RULES FOR REGULATING THE GRANT OF MINERAL CONCESSIONS".
14. In section 13 of the principal Act, in sub-section (2),—
(i) clause (ac) shall be omitted;
(ii) in clause (qqg), for the words, figures and letters "mining lease or composite
licence under section 10B, 11, 11A, 11B", the words, figures and letters "mineral
concession under section 10B, 10BA, 11, 11A, 11B, 11D" shall be substituted;
(iii) after clause (v), the following clauses shall be inserted, namely:—
"(va) the manner of notifying the areas for grant of exploration licence
under sub-section (4) of section 10BA;
(vb) the manner of granting exploration licence to the preferred bidder
under the proviso to sub-section (7) of section 10BA;

Substitution
of Chapter
heading of
Chapter IV.
Amendment
of section 13.

<!-- page 6 -->

6

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(vc) the manner of conducting auction for grant of exploration licence, the
terms and conditions thereof, the bidding parameters for selection, the share
payable to the holder, the period for payment and other conditions under
sub-section (9) of section 10BA;
(vd) the manner of submitting geological report under sub-section (12) of
section 10BA;
(ve) the amount to be paid and the manner of payment under the proviso
to sub-section (14) of section 10BA;";
(iv) after clause (x), the following clauses shall be inserted, namely:—
"(xa) the terms and conditions and the manner of selecting a preferred
bidder under sub-section (1) of section 11D;
(xb) the manner of granting a mining lease or composite licence to a
preferred bidder under sub-section (2) of section 11D;".
Amendment
of section
17A.

15. In section 17A of the principal Act, in sub-sections (1), (1A) and (2), after the words
"prospecting licence", the words "or exploration licence" shall be inserted.

Amendment
of section
18A.

16. In section 18A of the principal Act, in sub-section (1), after the words "prospecting
licence", at both the places where they occur, the words "or exploration licence" shall be
inserted.

Amendment
of section 19.

17. In section 19 of the principal Act, for the marginal heading, the following marginal
heading shall be substituted, namely:—
"Mineral concession to be void if in contravention of Act.".

Amendment
of section 21.

18. In section 21 of the principal Act, in the Explanation, after the words "composite
licence", the words ", exploration licence" shall be inserted.

Amendment
of section
24A.

19. In section 24A of the principal Act, for the marginal heading, the following marginal
heading shall be substituted, namely:—
"Rights and liabilities of a holder of mineral concession.".

Amendment
of First
Schedule.

20. In the principal Act, in the First Schedule,—
(i) after the figures and letter “11C”, the figures and letter “11D” shall be inserted;
(ii) for Part B, the following Part shall be substituted, namely:—
"PART B
Atomic minerals
1. Minerals of the "rare earths" group containing Uranium and Thorium.
2. Phosphorites and other phosphatic ores containing Uranium.
3. Pitchblende and other Uranium ores.
4. Uraniferous allanite, monazite and other thorium minerals.
5. Uranium bearing tailings left over from ores after extraction of copper
and gold, ilmenite and other titanium ores.
6. Beach sand minerals, that is, economic heavy minerals found in the teri
or beach sands, which include ilmenite, rutile, leucoxene, garnet,
monazite, zircon and sillimanite.";

<!-- page 7 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

7

(iii) after Part C, the following Part shall be inserted, namely:—
"PART D
Critical and Strategic Minerals
1. Beryl and other beryllium bearing minerals.
2. Cadmium bearing minerals.
3. Cobalt bearing minerals.
4. Gallium bearing minerals.
5. Glauconite.
6. Graphite.
7. Indium bearing minerals.
8. Lithium bearing minerals.
9. Molybdenum bearing minerals.
10. Nickel bearing minerals.
11. Niobium bearing minerals.
12. Phosphate (without uranium).
13. Platinum group of elements bearing minerals.
14. Potash.
15. Minerals of the "rare earths" group not containing Uranium and Thorium.
16. Rhenium bearing minerals.
17. Selenium bearing minerals.
18. Tantalum bearing minerals.
19. Tellurium bearing minerals.
20. Tin bearing minerals.
21. Titanium bearing minerals and ores (ilmenite, rutile and leucoxene).
22. Tungsten bearing minerals.
23. Vanadium bearing minerals.
24. Zirconium bearing minerals and ores including zircon.".
21. In the principal Act, after Sixth Schedule, the following shall be inserted, namely:—
"THE SEVENTH SCHEDULE
[ See sections 3 (aaa), 10BA(2) and 10BA(3)]
Minerals
1. Apatite.
2. Beryl and other beryllium bearing minerals.
3. Cadmium bearing minerals.
4. Cobalt bearing minerals.
5. Copper bearing minerals.

Insertion of
new Seventh
Schedule.

<!-- page 8 -->

8

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

6. Diamond.
7. Gold.
8. Graphite.
9. Indium bearing minerals.
10. Lead bearing minerals.
11. Lithium bearing minerals.
12. Molybdenum bearing minerals.
13. Niobium bearing minerals.
14. Nickel bearing minerals.
15. Potash.
16. Platinum group of elements bearing minerals.
17. Minerals of 'rare earths' group.
18. Rhenium bearing minerals.
19. Rock Phosphate.
20. Selenium.
21. Silver.
22. Tantalum bearing minerals.
23. Tellurium bearing minerals.
24. Tin bearing minerals.
25. Titanium bearing minerals and ores (ilmenite, rutile and leucoxene).
26. Tungsten bearing minerals.
27. Vanadium bearing minerals.
28. Zinc bearing minerals.
29. Zirconium bearing minerals and ores including zircon.".
————
DR. REETA VASISHTA,
Secretary to the Govt. of India.
————
CORRIGENDA
THE BIOLOGICAL DIVERSITY (AMENDMENT) ACT, 2023
No. 10 OF 2023
In the BIOLOGICAL DIVERSITY (AMENDMENT) ACT, 2023 (10 OF 2023), as
published in the Gazette of India, Extraordinary, Part II Section, 1, dated the 3rd August, 2023,
Issue No. 13,—
(i) in page 2, line 41, for ‘‘refferred’’, read ‘‘referred’’;
(ii) in page 4, line 17, for ‘‘Biodivesity’’, read ‘‘Biodiversity’’;
(iii) in page 5, line 16, for ‘‘Pachayati’’, read ‘‘Panchayati’’;
(iv) in page 8, line 3, for ‘‘Commitee’’, read ‘‘Committee’’;

<!-- page 9 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

9

(v) in page 8, line 22, for ‘‘affiairs’’, read ‘‘affairs’’;
(vi) in page 8, line 31, for ‘‘sustainble’’, read ‘‘sustainable’’;
(vii) in page 8, line 39, for ‘‘princiapal’’, read ‘‘principal’’;
(viii) in page 11, line 25, for ‘‘as prescribed’’, read ‘‘as may be prescribed’’;
(ix) in page 12, line 10, for ‘‘veriety’’, read ‘‘variety’’;
(x) in page 12, line 17, for ‘‘veriety’’, read ‘‘variety’’;
(xi) in page 12, line 20, for ‘‘veriety’’, read ‘‘variety’’;
(xii) in page 12, line 26, for ‘‘substiututed’’, read ‘‘substituted’’;
(xiii) in page 13, line 1, for ‘‘prinicpal’’, read ‘‘principal’’;
(xiv) in page 13, line 11, for ‘‘princiapl’’, read ‘‘principal’’;
(xv) in page 13, line 34, for ‘‘penalities’’, read ‘‘penalties’’;
(xvi) in page 14, line 3, for ‘‘accordance the’’, read ‘‘accordance with the’’.

UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110054.
MGIPMRND—273GI(S3)—09-08-2023.

signed
Kshitiz Digitally
by Kshitiz Mohan
2023.08.10
Mohan Date:
04:46:25 +05'30'
