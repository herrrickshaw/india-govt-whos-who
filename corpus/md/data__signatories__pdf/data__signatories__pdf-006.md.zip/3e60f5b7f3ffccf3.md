---
doc_id: "3e60f5b7f3ffccf3"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/9c94f4313601969213c45bab7cc7bd68.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Notification-Appointment of Dr. Sandeep Gulia as Livestock Officer in DADF dated 16.12.2016."
date: "2016-12-16"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "6d5d4f46e36f2093"
---

<!-- page 1 -->

(To be published in Part-I Section 2 of the Gazette of India)
No. A.12025/5/2015-Admn.1 हि
Government of India
Ministry of Agriculture and Farmers Welfare
Department of Animal Husbandry, Dairying & Fisheries
(Adinn.I Section)
Krishi Bhawan, New Delhi.
Date: IG /12/2016 7
NOTIFICATION
In view of the recommendation of the Union Public Service Commission vide their
letter No.F1/211(34)/2015-R.I dated the 12" July, 2016, the President is pleased to appoint
Dr. Sandeep Gulia as Livestock Officer in the Pay Level 10 of Pay Matrix as per VII CPC
corresponding to pre-revised scale of pay PB-3 Rs.15,600-39,100 with grade pay of Rs.5400
+ NPA w.e.f the forenoon of 9" December,2016 in the Department of Animal Husbandry,
Dairying and Fisheries. 026 ane
7 द BB
हे (था (४0५७) _
Under Secretary to the Government of India
Telephone No. 23383340
To
The Manager,
Government of India Press,
Faridabad (along with Hindi Version)
i Copy to:-

1. Dr.Sandeep Gulia, Livestock Officer

2. PS to MOS(SB)

3. PPS to Secretary(ADF)/ PS to AS & FA

4. PS to all Divisional Heads/AHC

5. Director (Admn.)/DS(RTI)

6. P & AO (Sectt.), Department of Animal Husbandry, Dairying and Fisheries, Krishi
Bhawan, New Delhi.

7. Deputy Secretary, UPSC, Dholpur House, Shahjahan Road, New Delhi-110069 w.r.f.
their Letter No.F.1/211(34)/2015-R.I dated 12" July,2016.

8. The Additional Chief Secretary to the Govt. of Haryana, Animal Husbandry &
Dairying Department, Chandigarh with reference to Endst No. 5150-AH-3-2016/
13807dated 08.12.2016.

9. Dr. Jai Narayan Sharma, SDO(A.H.&D), Thanesar, Department of, Animal Husbandry
& Dairying, 4" Floor, Mini Secretariat Building, Kurukshetra- 136118 (Haryana) with
a request to forward the LPC in respect of Dr. Sandeep Gulia at the earliest.

. sh & Coordination Section/ DDO/Hindi Anubhag.

\. ULNIC, DADF for updating the website of the Department. Ne
™/2. Service-Book/ Guard File / Spare Copies One
xe
(Lalit Grover) हि
Under Secretary to the Government of India
