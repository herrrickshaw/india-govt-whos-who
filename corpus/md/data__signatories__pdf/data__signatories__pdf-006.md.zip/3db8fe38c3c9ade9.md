---
doc_id: "3db8fe38c3c9ade9"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/6981ad2dd85e39b3cceb8c65c267e11e.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "MEITY revised Model Technical Specifications for Tablet PCs dated 27.08.2021"
date: "2025-07-03"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "08ee7f50a189168a"
---

<!-- page 1 -->

682

375597/2021/BE-II
375597 t2021|BE-|I

W-43/4/2020-IPHW-MeitY
W
- 43 I 4 I 2020 -IPHW-M eitY

Government
of India
Government of
India
Ministry of
Ministry
Information
of Electronics
Electronics and
and Information Technology
Technology
(IPHW
(IPHW Division)
Division)
Electronics
Electronics Niketan, 6, CGO Complex,
Complex,
Lodhi Road, New Delhi
Delhi 110003
Lodhi
110003
Dated:
2021
Dated: August
August 27,
27,2021
Subject:
Technical Specifications
Subject: Revised
Revised Model
Model Technical
Specifications of
of Tablet
Tablet PCs
PCs
Reference:
Technical Specifications
Reference: Model
Model Technical
Specifications of
Tablet PCs
of Tablet
PCs issued
issued vide
vide F.No.
F.No. No.
No. W43/4/2020-IPHW-MeitY
431 412020-IPHW-MeitY dated 17.04.2021.
17 .04.2021.

An industry
consultation was
An
industry consultation
was held
held on
on 16.07.2021
16.07.2021 to
to revise
revise the
the model
model technical
technical
specifications of
Tablet PCs issued by
specifications
of Tablet
by Ministry
Ministry of
of Electronics and Information
Information Technology
Technology
(MeitY)
vide F.No.
F.No. W-43/4/2020-IPHW-MeitY
W-43/4/2020-IPHW-MeiIY dated
(MeitY) vide
dated 17.04.2021.
17.04.2021. Based
Based on
on the
model technical
specifications
of
Tablet
PCs
are
as
under:
recommendations, the revised model
technical specifications ofTablet PCs
Parameter
Parameter

Specification
Specification

Processor
Processor

Quad-Core
with frequency of
of 1.8
1.8 GHz or more
Quad-Core with

RAM
RAM

2 GB or higher

ROM

32 GB or higher

Rear Camera

5 MP or higher

Front
Fronl Camera

2 MP or higher

Battery (mAh)
(mAh)

5000 mAh
mAh or more

Display
(SizeiType,/Resolution)
(Size/Type/Resolution)
Bluetooth Version

8.0"
8-0" or more
(capacitive, multi-touch)
TFT
multi-touch)
TFT (capacitive,
(or higher)
600 xx 1024
1024 (or
higher)

4.0 or higher

Page 1I of
of 2

<!-- page 2 -->

683
6E:

375597/2021
/BE-II
37559712021tBE-n

Parameter
Pararnetcr
Wi-Fi
Wi-Fi

Specification
Specification
802.1
a/b/g/n or higher
802.111 ablgln

4G/LTE
Network
Network Support(
Support( Data &
& 4G/LTE
voice)
3G/2G/V0LTE
3G/2GNoLTE
SIM
SIM card slot

1i Micro
Micro SIM
SIM

Voice Calling Support
Support

Yes

Micro
Micro USB
USB 2.0 Slot

Yes

Audio
Audio In/Out
ln/Out

3.5 mm Headphone
Headphone Jack

GPS

Yes

Operating
Operating System
System

Android
Android 10.0 or equivalent

Certifications
Certifications

BIS, EPR and RoHS and any other relevant Indian Certificates
Certificates

All the other
other conditions
conditions of
Technical Specifications
All
of the Technical
Specifications of
of Tablet PCs issued vide F.N0.
F.No. WW43/4/2020-IPHW-MeitY
43 I 4 12020-IPHW-MeitY dated 17.04.2021
17 .04.2021 remain unchanged.
unchanged.
*****

Page
PaEe 2 of
ot 2

<!-- page 3 -->

684
6EZ

375597/2021/BE-II
375597t2021tBE-||
W-43/4/2020-IPHW
w-43/4/2020-IPHW
Government
India
Government of India
Ministry of
of Electronics
Electronics and
Ministry
Information
and Information Technology
Technologl
(IPHW Division)
(IPHW
Division)
Dated: 17.04.2021
Subject: Model
Model Technical
Technical specifications
specifications of
Subject:
of Desktop
Desktop PCs, Laptop
Laptop PCs and Tablet PCs

Ministry of
of Electronics
Electronics and Information
Ministry
Information Technology (MeitY)
(MeitY) has notified
notified mechanism
mechanism
for calculating
calculating local
local content
for Desktop
for
content for
Laptop PCs
Desktop PCs
PCs and
and Laptop
PCs vide
vide Notification No.
No. W431412019-IPHW -MeitY dated
dated 07
43/4/2019-IPHW-MeitY
07.09.2020,
furtherance of
the Public
.09.2020, in
in furtherance
of the
Public Procurement
Procurement
(Preference to
to Make
Make in
in India)
India) Order 2017.
(Preference

2. MeitY,
MeitY, in
in consultation
consultation with
with the
2.
the Industry
Industry stakeholders has
has framed
framed model
model technical
specifications
of Deslcop
specifications of
Desktop PCs,
PCs, Laptop
Laptop PCs and Tablet PCs for
procurement
to be made by
for
Ministries // Departments
their agencies I/ PSUs. The procuring
Departments and their
Ministries
procuring entities may incorporate
incorporate
the specifications
specifications of
of Desktop
Desktop PCs, Laptop
the
Laptop PCs and Tablet PCs as per their requirement in the
tender
document from
from the model technical
tender document
technical specifications given below:
3. Model
Model Technical
Specifications:
3.
Technical Specifications:

3.1
Desktop PCs:
3.1 Desktop
PCs:
Parameters
Parameters

r

Processor

Entry Level
Core
10100/AMD
10100/AMD
3200G

22

Model Specifications
Model
Specifications

Mid Level
Mid
i3
R3
R3

Core
10400/AMD
10400/AMD
3400G

High end
i5
R5
R5

Core i7
10700/AMD R7
i7 10700/AMD
R7
3700

RAM
RAM

4GB

8GB
8Gts

(16GB)/(8GBx2)
(16GB)
I (8GB x 2)

ROM
ROM Size

500
5OO GB HDD
HDD

500
5OO GB HDD
HDD

1 TB
1
TB HDD,
HDD,
256GB(SDD)

Chipset

Commercial
Commercial chip sets

DVD
DVI)

DVDRW
DVDRW

Display
Display size
(Monitor)
(Monitor)

21.5"
WTFT
2l.5" WTFT

Display
Display Type

LCD/LED
LCD / LED

Kevboard
Keyboard

Wired / Wireless
Wireless

<!-- page 4 -->

685
68:

375597/2021
/BE-II
375597t202'.U8E-|I

Parameters
Parameters
3 2:

-

�

Model
Model Specifications
Specifications

� �

Mouse

Wired
Wired // Wireless
Wireless

Cabinet

MT
MT

SMPS

180-250W
180-2s0w

Speaker
Spealier

1 speaker port
port
1

Ports
Porls

Minimum
VGA/'IIDMI. LAN
LAN
Minimum 6 USB,
USB. VGA/HDMI,

OS
OS

Windows/
Windows/ Linux
Linux

Certification
Certification

BIS,
Indian Certificates
Certificates
BlS, BEE,
BEE, EPR, RoHS or any other
other relevant Indian

3.2
3-2 Laptop
Laptop PCs:
Parameters
Parameters

s

23

e

Model
NIodel Specifications
Specifications

Entry Level

Mid
Mid Level
Level

High
High End

Pentium
Pentium Gold
6405U/
6405Ut AMD
AMD
Athlon
Athlon 3050U

Core
i3 1005G1/
Core i3
AMD
AMD Ryzen
Ryzen 3
3250U

Core
1035G1/
Core i5
i5 1035Gl/
AMD
AMD Ryzen
Ryzen 5
3500U
3500u

RAM
RAM

Minimum
Minimum 4GB
DDR4,
DDR4, with
with 2
DIMM
DIMM slots
slots with
with
upto
upto 32GB
32GB memory
memory
expandability
expandability

Minimum
Minimum 4GB
4GB
DDR4,
DDR4. with
with 2
DIMM
DIMM slots
slots with
with
upto
upto 32GB
32GB memory
memory
expandability
expandability

Minimum
Minimum 8GB
DDR4, with
with 2 DIMM
DIMM
slots with
with upto 32GB
memory
memory
expandability

ROM
ROM Size

11 TB
TB HDD
HDD

11 TB
TB HDD
HDD

+256 GB
TB HDD
11 TB
HDD +256
SSD
SSD

Processor
Processor

500 GB
500
GB HDD/
IrDD/ 512
GB SSD
Battery
Battery

Lithium
Lithium ion
ion
(WattHour) - Minimum
Battery Capacity
Battery
Capacity (WattHour)
Minimum 36
Battery
Battery Backup Time (Hours) - 8

Chipsets

SoC

<!-- page 5 -->

686
68t

375597/2021/BE-11
375597t2021|BE-|I

Model
Model Specifications
Specifications

Parameters
Parameters
Display size

14""
14

Display
Display Type

LCD/LED
LCD / LED

Resolution
Resolution

1366x768 HD
HD display
display

Bluetooth

Enabled 5.0 or higher

Wireless Device

Wireless 802.11 ac+ BT
higher
BT 5.0 or higher

Interfaces

RJ-45, Min.
RJ-45.
Min. 22 USB3.0 Type A
A&
& 1I USB
USB 3.0 Type C, Audio
Audio combo

port. DC Adapter
port
port,
Adapter Jack,
Jack. HDMI
HDMI port

Audio
Audio

Built-in
Built-in
high definition
with high
definition audio
audio support. Built-in
Built-in stereo speakers with
Microphone.

Security
Security

FTPM 2.0 etc.
etc.
Bios Password/ FTPM

Hardware
Hardware
interface
interface

USB and HDMl
HDMI

Ethernet
Ethemet
controllers

Gigabit Ethernet

Keyboard
Keyboard &&
touch
touch pad device

with touch pad
Keyboard with
Keyboard

Mouse

Optional

Camera for
for video
conferencing
conferencing

HD
I1D 720p Webcam

Certification
Certification

BIS, BEE, EPR, RoHS
Indian Certificates
RoHS or any other relevant Indian
Certificates

3.3
3.3 Tablet
Tablet PCs:
Parameter
Parameter
Processor
Processor
RAM
RAM

Specification
Specification
-Core with
Quad-Core
with frequency
frequency of
of 1.8
I .8 GHz or more

lo*o

2 GB or higher
t,

<!-- page 6 -->

687
6E7

375597/2021/BE-II
375597t2021tBEJl

Parameter
Parameter

Specification
Specification

ROM
ItOM

32 GB or higher

Rear Camera

55 MP or higher
higher

Front
f'ront Camera

2 MP or higher

(mAh)
Battery
Battery (mAh)

5400mAh
5400mAh or more
8.0" or more

Display
(SizeiType,{Resolution)
(Size/Type/Resolution)

TFT (capacitive,
(capacitive, multi-touch)
multitouch)
TFT

Bluetooth
Bluetooth Version.

4.0 or higher
higher

Wi-Fi
wi-Fi

802.11 a/b/g/n
alblgln

(or higher)
600 xx 1024 (or
higher)

4GILTE
Network
Network Support(
Support( Data &
& 4G/LTE
voice)
voice)
3G/2GNoLTE
3G/2GAloLTE

SIM
SIM card slot

II Micro
Micro SIM
SIM

Voice
Voice Calling
Calling Support

Yes

Micro
Micro USB
USB 2.0 Slot

Yes

Audio In/Out
In/Out
Audio

3.5mm
3.5mm Headphone Jack

GPS

Yes

Operating
Operating System
System

0.0 or equivalent
Android
Android I10.0
equivalent

Certifications

BEE, EPR and RoHS and any other relevant Indian
Indian
BIS and BEE,
Certificates

4.
Local
as per
per the
the MeitY
MeitY Notification
W-43/4/2019Notification No.
No. W-43/4/20194.
content shall
shall be
be calculated as
Local content
IPHW-MeitY
07.09.2020,
from time to time.
IPHW-MeitY dated 07
.09.2020, as amended
amended from

yearly basis,
5.
aforesaid model
or earlier
on aa yearly
basis, or
earlier as
model specifications shall
shall be
be revised on
5. The
The aforesaid
deemed necessary,
with lndustry
Industry // Industry
Industry Associations.
Associations.
necessary, after due consultation
consultation with
k
*1.,I**

****
