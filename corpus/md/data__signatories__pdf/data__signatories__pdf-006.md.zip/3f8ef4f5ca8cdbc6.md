---
doc_id: "3f8ef4f5ca8cdbc6"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2026/01/93acb7cdb7f804b4429188895370a820.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Status of APAR of CHS officers to be considered for their promotion to HAG level post - reg"
date: "2026-01-01"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0720e692e39b0183"
---

<!-- page 1 -->

No.A.280 12l 19/20 19-APAR
Government of India
Ministry of Health and Family Welfare
(CHS Division)

Nirman Bhawan, New Delhi- 1 1001 1
Dated the 23'd MaY, 2Ol9
Oflice Memorandum

Sub: status of ACRs/APARs of cHS officers to be considered for their
promotion to HAG level Post-reg.

A proposal to Iill up vacancies of Addl. DGHS/HAG in Central Health
Service (CHS) against vacancies for the panel year 2Ol7-18, 2018-19 and
2Olg-2O is under consideration of this Ministry. Accordingly, a draft
combined eligibility list of SAG level oflicers who are eligible for consideration
for promotion to HAG level post and are in zone of consideration has been
prepared as per Rule 6(3)(ii) and (iii) of CHS Rules, 2014 and circulated vide
this Ministry's OM No. A.32Ol2lOll 2019- CHS IV dated 21.O5.2O19.
The status of APARs in respect of CHS officers referred in the above
mentioned oM is encl0sed herewith as Annexure I for information of all
concerned. It is requested that the all pending ACRs/APARs as indicated in
Annexure I may be made available to this Ministry by 28.5.20 19 so that
further necessary action to consider these officers for their promotion to HAG

2.

level post may be taken.

5o"h Noi^

Encl-As above

(Sarita Nair)
Under Secretary to the Govt of India
Tele No 23063068
To
1. The DGHS, Nirman Bhawan, New Delhi.

2. The Principal Secretary(Health), GNCT, Delhi'
3. The Medical Superintendent, Dr. RML Hospital, New Delhi.
4. The Medical Superintendent, Safdarj ang Hospital, New Delhi'
5. The Dean, MAMC, New Delhi,
6. The Director, LHMC, New Delhi.
7. The Medical Superintendent, GTB Hospital, New Delhi.
8. The Director, GB Pant Hospital, New Delhi.
g. The Principal secretary, Andaman & Nicobar Island Administration, Port

Blair.
10. The Director Principal, Dr. Baba Saheb Ambedkar Medical College and
Hospital, Sector 6, Rohini, Delhi
11.The Director, CGHS, Nirman Bhawan, New Delhi.
12. The Sr. Technical Director, NIC with the request to upload the above oM
on the website of this Ministry.

<!-- page 2 -->

Ar,l,.-O-Xl^
sp€ciality/

n=

Place of posting

DoB

2015-16

2074-15

2013-14

2012-13

PG

or. K.T. Bhowmik

NT

Radio'

SJH

o5l )ullL957

2

Dr. S,D. Khaparde

PH

PG

Dte. GHS

3

Dr. K.C. Agarwal

NT

PEDIATRICS

stH

4

Dr. R.S. Ahuia

NT

PLAS]IC

GNCI, Delhi

30l!!nl19s5
2tltunll9s5
o2ltebltgSS

5

Dr. B.T. Kudva

NT

NA

NA

SURGERY

or. Gautam 5en Gupta NT

MEDICINE

CGHs, Mumbai

MrcRoElot-

All&PH Kolkatta

Dr. AnilAsarwal

T

FORENSIC

OllArE/!954
tssT
lo4leebl

OGY
7

GNCI of Delhi

atlAuEltgs'

NA

MEDICIN E

T

8
9

Dr. Tarun Kumar

T

10

Dr. Bhaskar Charan

T

(ebi
11

Dr. V. Ramesh

PAIHOLOGY SJH

Bto-

29lo.tl19s4

GNcT of oelhi

251avlt9s4

SlH,New Oelhi

24lAwl1934

Safdariung
HosPital.
GNCI of Delhi

04ltunl19s4

CHEMISfBY

Mishra

BtoCHEMISTRY

NT

DERMATOL
OGY
GENERAL

12

Dr. N.K. Gupta

1

13

Or. H.S. Hira

T

031)unlt9s4

MEDICINE
GENERAL

GNcTof Delhi

MTDICINE

loe/s€p/1ss3
AllH&PH, Kolkata 161!\rll t9S3

14

Dr. G.X. Pandey

T

PUBTIC

15

or. P.K. Pandey

T

OPHTHATM

16

Or. A.(. Mehtani

T

HEALTH

cNCr of oelhi

1slsep/19s5

ORTHO,

Dr. fiML Hospital,

ozlMatll9s4

SURGERY

New Delhi

MICROBIOL

GNcT of Delhi

04/sepl19s4

5.J. Hospital

04lsepl19s5

OLOGY

t7

Dr. aibhabatiMishra

T

l8

or.(Smt.)shabnam

NT

OGY

Bhandari

RADIO.
oTAGNOStS

201011

1

6

2011-12

NA

2009-10

,. i

<!-- page 3 -->

19

Dr. U.C. Garga

NT

RADIO.

Dr. R.M.L.

ot/ Julltgss

Hosoital
PAIHOLOGY LHMC, N€w Delhi 25lOdl1953
DIAGNOSIS

20

or. Manjula Jain

T

21

Dr. H.G. Brahmne

NT

MICROBIOL

Dkector, BCG,

Dr. A.S. Nigam

NT

Guindv. Chennai
PATHO!OGY CGH5, Delhi

Dr. M.K. Saha

NT

oBsr &

o1ltul/1gs6

NA

OGY

22

z3ltt l/19s4

A&N lslands

14lo.r/L956

CGHS(RMLH)

10/ AuEllgs4

GYNAE

24

or. (Smt.) Pushpavati

NT

25

sin?h
or. Bharat Singh

NT

26

Dr. V.K. Gupta

T

27

Dr. Raj Narain Rai

PH

OBST&
GYNAE

Derhi

lpArHo[ocy lcNcr,

NT

2A

l01/rur/1ss5

PSM

GNCI of Delhi

18/Nov/19s3

lru

lNcDc,

l2otluvLssa

TUBERCULO

NTl, Bangalore

25lMaylt95S

Derhi

Available

l^o l*o

l"o l"o l"o

l*

lavarhble

l*

sts
T

SURGERY

GNCI of Delhi

0s/Aus/1953

T

SURGERY

LHMC, N€w Delhi

L5/tull195s

Dr. Karoon ASarwal

T

PLASTIC

02/AIte/L9s4

Dr. Sidharth Ramji

T

PEDIATRICS

VMMC &
SJ.HosDital.
GNCTof D€lhi

33

Dr. Ajay Kumar Jain

T

PHYSIOI"OGY

GNCTof Oelhi

19loecl1953

34

Dr. M.M. Mehnidiratta

T

NEUROLOGY GNCTof O€lhi

18/Dec/19s3

35

Dr. B.(. Jain

T

SURGERY

GNCT of Oelhi

29lMayll9s3

36

Dr. N.S.Hadke

T

SURGERY

GNCT of Delhi

lol AuEll9s3

37

Dr. Jagdish Chandra

T

PEDIATRICS

Director, LllMC,

311Augllgss

29

Dr. P.N. Agarwal

30
31

SURGERY

13lNov/1956

Dr. sun€ela Garg

T

PSM

GNCT of Delhi

16lNo\t 119s6

39

Dr. Arvind 5aily

T

PEDIATRICS

tHMC, New Delhi

2alhnl195s

40

Dr. A.C. Dhariwal

PH

PG

Advisor. NVBDCP, 0slNov/19s5
Delhi

availabl€
NA

NA

lavairabre

<!-- page 4 -->

4t

A.K. saxena

lDr.

l*'

Dr. P.X. Sharma

NT

42

DERMATOL

CGHS, SJH

14lsepl1957

CGHS(RMLH}

21lAuEl1956

OGY

DERMATOL
OGY

Dr. Rajesh Kumarlain

43

T

OPHTHALM

tHMc, New Delhi 24lAptl1953

OLOGY

Or. (.H.S. Rao

NT

DERMATOL

CGHt BanSalore

141lunl1955

GNCT of Delhi

09lseplr9s4

GNSI of oelhi

3lloec/1957

OGY

Dr. sudha Prasad

45

T

OBST &

GYNAE

I
Dr. sanjayTyagi

T

CARDIOIOG

x.x. ciranar

NT

ANAESTHESI S.J.Hospital

s.x. rain

T

GENERAL

49

Dr. P.P. Singh

T

50

Dr. {Smt.)c.K. Dursa

51

Dr.{smt.)hdrani

52

Dr. Sunill(umar

47

24lo.tllgss

lor.
48

[HMC, New Delhi

04lMath9s6

ENT

GNCT of Delhi

2A1tuu1954

NT

SURGERY

Dr. R.M.L.

lLlOCtll9s6

NT

PATHOLOGY 5.J. Hospital

1slMay/19s6

sJ Hospital

08/Sep/195s

lor.

Iabl€

MEDICINE
NA

Hospital

iaspalsinch Dari

53

NT

5URGERY

T

ANAESTHESI GNCT, Delhi

12lsephgss
03/sep/x95s

I'o l'o

lDr.
54

Dr. S.L. Jain

T

PATHOLOGY GNcTof Delhi

55

Dr. (smt.)s.N

NT

PSYCHIATRY

Dr. R.M.L.

221l\rnl19s6

PLASTIC

S.J. Hospital

l2lMayllgs6

NCDC, Delhi

051^ptlL9s9

Deshpande

n.r. raravan

55

Nf

lor.

NA

NA

NA

Available

SUR6ERY

Dr. SunilGupta

57

NA

NT

MICROBIOL
OGY

LHMC, NEW D€lhi 22lAuEl1954

Dr. Anita ruli

T

59

Dr. Raiesh Kumar Suri

T

ANATOMY

60

Dr. Jaadish chandra

T

SURGERY

61

aru.a Jain

T

58
I

lD..

SJH,ND

MAMC, GNCTof
D€lhi
ANAESIHESI LHMc, New oelhi

26lAuCl19s3

o2llanl19s7

L9lMayll9s5

<!-- page 5 -->

r.P. Yadav

NT

PEDIATRICS

Dr. Sushil (umar

T

OPHTHALM

Dr. B.M. Singh

NT

OTOGY
MEOICINE

Dr. N.S. Negi

NT

NT

62

lor.
63
54

h

Dr. v.K. Tiwari

Dr. R.M.L.

t5ltulllgs6

HosDital

lGNCrofDerhi 121/May/1es8 INA
CGHS (RMLH}

04lll(r'.ay/1954

MEOICINE

5.J. Hospital

11lllr'r'.atlL956

ptAsTtc

RMLH

t2locrllgsl

l"o

NA
I

SURGERY

67

F
r-

Dr. AchalGulati

T

ENT

GNCT of Delhi

2AlEeblr9sa

Dr. v.(. Gupta

T

Bto-

GNCT of Oelhi

ozlMat/tgss

Dr. Poonam Bhadoria

T

CHEMISTRY
ANAESTHESI GNCT, Delhi

0UDe./19sG

Dr. Rakesh (umar

T

ANAESTHESI GNCT, O€lhi

zal )ullLgss

Dr. Rajiv Garg

T

OPHTHALM

tHMC, New D€lhi

Available

131Aprl19sa

OLOGY

Dr. Karam Chand

7Z

NT

NEURO'

s..,. Hospitar

110/run/1ss5

SURGERY

73

Dr.l.L. Goyal

I

74

Dr. Rajesh Rastogi

NT

PSYCHIATRY

S.J. Hospital

T

ENT

Govt. of N.c.T. of 27 /tllnllgSG
Delhi
o1lMay/19Ss
GNCT, Delhi

OPHTTIALM

GNCI of Delhi

o2lJanlagss
271Jvnllgss

INA

NA

l[\]o

l^o l'o l*o l*o

OLOGY

75

L

lDr.,.c.Parsey

t"

Dr. A.K. Sethi

T

Dr.(Smt.) Pratima

NT

Mittal

OBST &

GYNAE

F',-

l*o

or. Aiay Kumar Gupta

T

Dr. Geeta A, Khwaja

T

NEUROLOGY GNCTof D€Ihi

81

Dr. Rajesh sood

NT

ANAESTHESI Dr. R.M.L.

Irz

Dr. sangeeta Yadav

T

PEDIATRICS

GNCTof Delhi

12/sep/1956

83

Dr. R.N. Mandal

T

PEDIATRICS

GNcTof oelhi

151lunlL953

I
ORTHO.

GNCTof O€lhi

SURGERY

I

NA

LHMC, NEw Delhi 24lSee/1954

T

Es

l*

14ltull1956

Dr. shashiRaheia

7a

l*o l"o lno l*o

lo5^---l-l-

Available

03llunlLgss

l^o

I'o
22lMarlL955

l*o

F-

<!-- page 6 -->

84

Dr. V.K. Gupta

NT

PATTIOLOGY ccHS, Allahabad

85

Or. G.S. Meena

T

PSM

GNCToI Delhi

25loecl19ss

86

Dr. Sunil Kumar

T

SURGERY

GNCTof D€Ihi

Lzlapti196o

87

Dr. (smt.)Nilima lain

NT

MEOICINE

S.r. Hospital

LHMc, New oelhi

88

Dr. o.P. Pathania

T

SURGERY

89

Dr. C.P. Baveia

T

MICROBIOL

GNCT of Delhi

Y*

90

or.P.B. Chulaki

NI

OGY
ENT

CGHS, Bangalore

lo2lMat
1ol )unlL956

91

Dr. (Smt.)Gul Motwani NT

ENT

5JH

25lSep/195s

92

Dr. P.K. Malik

NT

OPHTHALM

CGHS (RMLH)

93

Or. Rajendra Sharma

NT

94

Dr. AnjaliTempe

T

Iable
ilabl€

20lAuElL956

I 1es8

NA

Availab

r
NA

loe/oec/1es6

OTOGY

OBST &

NA

NA

161)anl195a

& Dir€ctor,

10/Nov/1958

GNCT of oelhi

laltebl19s7

GYNAE

95

D., N.B. Mathur

96

T

PEDIAIRICS

GNcT of Delhi

20lSep/!954

T

PUBLIC

AIIH&PH,

otlo.tl19s7

HEALTH

97

Dr. sunilGomber

T

PEDIATRICS

GNCT of Delhi

291Aptl1957

98

Dr. PrabalRajvanshi

NT

MEDICINE

S.J. tlosPital

zolsepllgss

99

Dr. R.S. Taneia

NT

MEDICINE

Or. R.M.L.

251!an11957

NA

Hospital

100

Dr,5,R. Karmakar

PH

PG

AllH&PH, Kolkata 0rlFeblL9s6

NA

Available
