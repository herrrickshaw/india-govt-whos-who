---
doc_id: "3f8fd9ede61ee19c"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/4f8c0c6eb6360453f6025c7afa4cb333.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Assignment of charge of the post of Addl. SGI for High Court of Bombay to Shri Devang Girish Vyas, Addl. SGI for High Court of Gujarat: Gazette Notification dated 21.07.2023"
date: "2023-07-21"
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "68437842de054165"
---

<!-- page 1 -->

रजजस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-22072023-247525
xxxGIDHxxx
CG-DL-E-22072023-247525
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग I—खण्ड 2
PART I—Section 2
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 27]
No. 27]

नई ददल्ली, िुक्रिार, जुलाई 21, 2023/आषाढ़ 30, 1945
NEW DELHI, FRIDAY, JULY 21, 2023/ASHADHA 30, 1945
जिजध और न्याय मंत्रालय
(जिजध कायय जिभाग)
अजधसूचना
नई ददल्ली, 21 जुलाई, 2023

फा. सं. जे-11013/6/2023-न्याजयक.—राष्ट्रपजत गुजरात उच्च न्यायालय के भारत के अपर महासॉजलजसटर श्री देिांग जगरीि
व्यास को 21 जुलाई, 2023 से छह महीने की अिजध के जलए अथिा बॉम्बे उच्च न्यायालय में भारत के अपर महासॉजलजसटर की
जनयजमत जनयुजि होने तक, जो भी पहले हो, बॉम्बे उच्च न्यायालय में भारत के अपर महासॉजलजसटर का प्रभार सौंपते हैं।
जिजय कु मार िमाय, संयुि सजचि एिं जिजध सलाहकार
MINISTRY OF LAW AND JUSTICE
(Department of Legal Affairs)
NOTIFICATION
New Delhi, the 21st July, 2023
F. No. J-11013/6/2023-Judicial.—The President is pleased to assign charge of Additional Solicitor General
of India for High Court of Bombay to Shri Devang Girish Vyas, Additional Solicitor General of India for High Court
of Gujarat, for a period of six months with effect from 21st July, 2023 or till the appointment of regular Additional
Solicitor General of India for High Court of Bombay, whichever is earlier.
VIJAY KUMAR SHARMA, Jt. Secy. & Legal Adviser

4742 GI/2023
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ
KUMAR VERMA

Digitally signed by MANOJ
KUMAR VERMA
Date: 2023.07.22 14:02:39
+05'30'
