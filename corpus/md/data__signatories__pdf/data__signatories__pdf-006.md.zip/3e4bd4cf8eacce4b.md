---
doc_id: "3e4bd4cf8eacce4b"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/deda02c6733a1a067677fccbfa0546ce.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "DoT issues advisory to alert general public on tower frauds."
date: "2022-08-18"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "354dd52b6360b9ca"
---

<!-- page 1 -->

No. 13-01/2021-CS-II

Department of Telecommunications
Ministry of Communications, Government of India
Sanchar Bhawan, 20-Ashoka Road New Delhi-01
(Carrier Services Wing)
PUBLIC ADVISORY
(Frauds related to installation of Mobile Tower)

It has come to the notice of Department of Telecommunications (DoT)
that some unscrupulous companies/ agencies/ individuals cheat general public
and collect money by promising them hefty monthly rental etc. in the name of
installation of Mobile Towers.
In this regard the public at large is hereby informed that:1. DoT/ TRAI is not directly or indirectly involved in leasing/renting the
premises for installation of mobile towers.
2.

DoT/ TRAI or its officers do not issue any “No Objection Certificate” for
the installation of mobile towers.

3.

The updated list of Telecom Service Providers (TSPs) and Infrastructure
Providers (IP-1), authorized to install mobile towers, is available on DoT
website i.e. https://dot.gov.in and https://dot.gov.in/infrastructureprovider.

4.

Public is hereby cautioned to be extra careful and verify the credentials of
the company, in case any company/agency/individual asks for money for
installation of mobile tower. The association of TSPs and IP-1s have
confirmed that their members do not ask any money for installation
of Mobile Towers.

5.

If any person comes across any such fraudulent activity, then he/ she
may report the incident to local police authorities.

6.

In addition, the local field units of DoT may also be contacted whose
contact
details
are
available
on
DoT
website
at
https://dot.gov.in/relatedlinks/director-general-telecom

Date: 05th Aug, 2022

Director (Carrier Services-II), DOT
Ph: 011-23036189/ 23036222
*******
