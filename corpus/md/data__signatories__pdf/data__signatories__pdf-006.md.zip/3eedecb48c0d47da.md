---
doc_id: "3eedecb48c0d47da"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/06/61a4e30aae9a96a7ce07e6069dc5e3b8.pdf"
ministry: "Tourism"
title: "Tender Notice for construction of India Pavilion at FITUR 2019, in Madrid, Spain."
date: "2025-08-04"
pages: 9
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "9e1ebb09824e4b4e"
---

<!-- page 1 -->

Cc -

Incredible !ndia
IT.Paris/FITUR/2019 Paris, 03.12.2018
Subject: - Inviting Quotations from Agencies to conceptualize, design, fabricate, install
& dismantle of India Stand at FITUR — 2019.

Sir/Madam,

India Tourism Paris is participating in the Feria International de Turismo (FITUR)
2019 scheduled to be held in Madrid. Spain from 23-27 January 2019. The objective of our
participation in the said fair is to showcase India’s myriad tourism products and to promote
India as a ‘Must Visit’ destination for travelers from Europe.

India Tourism Paris, invites bids from professional agencies /consortium of agencies
(ic. one lead agency + one Partner) for designing and construction of India stand at FITUR
2019, Madrid, providing ancillary services and dismantling of India Stand after the event is
over, as per details given below:

2. Space

India Tourism has booked the stand N°: 6901 01 252 sq.m.(Floor plan attached). This
is a four-side open space (Island). India Tourism will be the main exhibitor along with 25 co-
exhibitors.

Si SCOPE OF WORK (including design specifications & requirements)

India Tourism Paris requires the services of a professional agency/ies having requisite
experience in handling work of similar nature of Intemational Fairs and exhibitions for
construction of India pavilion at FITUR as per the scope of work given below. The Indian
Pavilion should present India as a multifaceted destination that combines an ancient culture
and heritage with a modern, innovative and vibrant present. The pavilion should have an
inviting look and should be open with minimum barriers. The essence of a visit to the
pavilion should be experience based and visually appealing with use of various technologies.
The aim of the India Pavilion is to give the visitor the experience of visiting India as a tourist,
focusing on its varied tourist attractions. It is expected that the design should reflect the
variety, culture and vibrancy of India as a cultural destination with a touch of its unique
tourism products. The theme of our stand would be “Incredible India” which is the brand line
of our marketing strategies.

3.1 To Design, fabricate and install the stand on time and dismantle the stand after the
event is over.

3.2 To provide good quality, comfortable furniture as per stand design and space,

3.3. There should be a High Truss with Incredible India Logo along with Incredible India
images visible from all sides.

३.4. To provide LED wall/Digital Screen of 4LX3H Meters or more along with a DVD

Player, Mike with Speakers. Btrc bese, n *t

INDIA TOURISM, PARIS, “0४०
(France, Switzerland, Portugal, Spain)
Ministry of Tourism, Government of India,
13 - Boulevard Haussmann. 75009 — Paris, France.
Tel: 00 33 (0) 1 45 23 30 45, Fax: (0) 145 23 33 45
Website: www.incredibleindia.ora, Email:directorindiatourismparis@gmail.com
[1]

<!-- page 2 -->

3.5 A Meeting Area for seating at least 6-8 persons and should be covered area.
Meeting room comfortable enough to hold press interviews, meetings etc.

3.6 To provide high speed Internet / WIFI connection to the participants &
India Tourism.

3.7 The Pavilion should be erected on a raised platform of 2 inches and all
images displayed will be back lit in the form of Translites.

3.8 To provide Electricity Connections.

3.9 To provide plants & beautification and liaison with the fair authorities for
setting up of our stand.

3.10 The work also includes construction of booth at site well in time,
maintenance & daily cleaning etc.

3.11 Coordination with the fair authorities for setting up of our stand, with
proper lighting.

3.12 A representative of the stand constructor should be available throughout
the working hours of the event.

3.13 Stand Design:

i) It should be functional and projecting an image of “Incredible India”. The
booth should essentially reflect an ethnic Indian décor & ambiance.

ii) The pavilion should essentially reflect Indian décor and ambience and at
the same time a professional and business type lay out best suited for
buyer — seller mectings with effective and adequate branding of the
Incredible India as per design.

iii) The Pavilion must showcase Adventure Tourism Product of India.

iv) There should be casy accessibility and visibility. Double sided pictures /
signage are to be produced by the agency of high quality, and backdrop
with their logos for all participants / co-exhibitors in the Pavilion as per the
design. All the images should be backlit.

v) A small designated area for cultural activity like Dance, Yoga
demonstrations etc. to be provided, one small table and two chairs for
Henna / Mchendi applying also to be provided.

vi) There should be a Store Room, with wall racks & hooks for hanging clothes,
coat stand and a small wall mirror may also be provided. The outer wall of
the storage area may be used for branding with Incredible India images.

vil) There should also be a small Pantry area in the stand along with a small
refrigerator for providing tea / coffee, soft drinks etc. It should match the
aesthetics of the stand.

vii) A Pavilion plan display in four corners of the pavilion indicating the
placement of booths with booth numbers, for facilitating visitors and
business contacts of the co-exhibitors.

ix) Each co-exhibitor’s booth should be properly numbered and displayed
prominently. Individual storage space is also to be provided.

x) All other ancillary works related to India Pavilion like provision of back
drops for VIP area, coffee/tea machine, provision for soft drinks, milk,
coffee, tea and sugar, cookies, mineral water with dispenser and paper
napkins, disposable spoons/stirrers/ glasses/cup, dustbins with bags etc.
are within the scope of work of the agency. There should be regular
cleaning of the dustbins & carpet. tre Pongo

पु न tre Pongo
2

<!-- page 3 -->

xi) All visual display materials produced will be the property of India Tourism
Paris and should be handed over after the completion of the exhibition.

3.14 Provisions for Co-Exhibitors

i. A total of 25 Co-Exhibitors are expected to participate within the Indian
stand at the fair.

ii. Each co-exhibitor would be given an individual space of 4 sq.mtr.

iii They are to be provided with one table with 4 chairs (two chairs on either
side of the table)

iv. Sufficient storage space to be provided within their stand.

v. Electricity points(Minimum 2) for charging laptop, mobile phone, etc.

vi. | There should be a low partition between the co-exhibitors.

vii. A small dustbin should also be provided.

viii. Double sided attractive pictures / signage to be produced by the agency,
and backdrop with the logos of the co-exhibitors /participants as per
design.

ix. Each individual booth of the co-participants should be designed in an
uniform manner with easy visibility. Stand Number should be visible.

3.15 Information Counter:

i. The Information Counter of India Tourism Paris is to be placed along with 2
barstools and 2 display racks to display brochures.

ii. The information desk should also have storage space (shelves) with the
provision of lock.

iii. The back drop of the information counter should have a prominent image
of a popular India Tourism product such as Taj Mahal etc.; so that image is
clearly visible.

iv. Reception / Information area should be well designed for the main exhibitor
(India Tourism) at the entrance.

v. There should be a Name Board near the entrance displaying the name of all
the co-participants and their booth nos.

vi. Design of the India Stand should showcase the Indian architecture. It
should also reflect the diversity, culture, heritage and vibrancy of India.

vii. There should be extensive branding with images provided by us or if
required may be purchased by the agency and the logo Incredible India
should be used frequently and prominently.

4. Guidelines for Submission of Tender:

4.1 The tender should be submitted in two covers as per details given below:

4.2 Cover-I: Superscribed “Technical Bid for Design & Construction of India

Stand at FITUR 2019”. To include the following documents/ details:

i) Profile & Track record of the agency / both the agencies in the case of
consortium. 00/-2«-1०५

2

<!-- page 4 -->

ii) Details of work undertaken relating to design and construction of pavilion /
stands in fairs / exhibitions / Marts in the last three years ie 2015-16,
2016-17 and 2017-18, with copies of relevant work orders. Experience of
setting up Pavilions/ Booths/ Stands at International Fairs / Exhibitions /
Events overseas as well as at International Tourism related Fairs
/Exhibitions Events overseas during the last three years i.e 2015-16, 2016-
17 and 2017-18 may be highlighted.

iii) Specific experience relating to the particular event (FITUR), if any, with
copies of relevant work orders / Client Completion Certificate specifying the
dates, months and year of the project and total cost of the project in
support of details furnished.

iv) The Firm/ Agency (all members/ agencies in case of Consortium) shall not
be under declaration of ineligibility for corrupt or fraudulent practices with
any Government department/ agencies/ ministries or PSUs and should not
have been black listed at the time of submission of bid. All bidders (both
the agencies in case of consortium) should submit a self-undertaking on
the company’s letter head duly signed by the authorized signatory, stating
that they have never been blacklisted by any Government of India Ministry/
Department/Public Sector Undertaking / Authority/ Organization/ Agency.

v) Details of any awards won for stand design in the past three years i.e 2015-
16, 2016-17and 2017-18 supported by documentary proof.

vi) In the case of consortium, MoU signed between the lead agency and the
partner agency clearly specifying the name of the lead agency in the
consortium to be submitted. The MoU should be signed by both the
agencies. A total of two agencies only permitted in a consortium.

vii)  Concept/ Design of the India Pavilion with detailed layout, decoration plan,
space utilizations etc. (only single design) must be submitted in hard copy
as well as on CD/pen drive.

viii) Bid securing declaration in the letter head of the company duly signed by
the authorised signatory to be submitted by bidders, accepting and stating
that if they withdraw or modify their bids during the period of validity, or if
they are awarded the contract and they fail to sign the contract, or to
submit a performance security before the deadline defined in the tender
document, they will be suspended for one year including the next edition of
the FITUR from being eligible to submit Bids for contracts with the India
Tourism, Paris.

4.3 Cover — 2: Superscribing “Financial Bid - Design & Construction of India

Stand at FITUR 2019” and to include the following documents / details:

i) Financial Bid, duly dated, signed by the authorized representative of the
agency and clearly indicating the cost as per format given below :-

Fair construction, dismantling and | cost in Euros | rate of tax,
ancillary services as per scope of | (€) ifany in €
work & requirements detailed at
Para-3 of the Bid document _ _

FITUR

2019,

Madrid 23-

—

2019)

Gti Poy
4
Ey, =

<!-- page 5 -->

ii) All bidders should indicate cost for the fair as well as the total cost
inclusive of all taxes. All components related to construction of pavilion as
per submitted design should be inclusive. No additional payment would be
made for any components related to construction of the pavilion. The
financial bids will be evaluated on the basis of total cost inclusive of
taxes.

(iii) The financial bid should be in Euros.

(iv) The financial bid should contain an undertaking by the agency that the
agency accepts and agrees to abide by the terms and conditions as
mentioned in this tender document No. IT.Paris/FITUR/2019 dated
03.12.2018.

4.4 The agencies submitting their bids should also mention in the covering
letter that they agree to the terms and conditions mentioned in the tender
document.

4.5 All the documents submitted by the agencies should be signed on each
page by the authorised signatory of the company. The document should be
spiral bound, duly page numbered, and properly indexed. The agencies who
do not submit their bids in the proper format, with required documents and
in the required format would be liable for rejection.

4.6 The two sealed covers, i.e Cover-I -Technical Bid & Cover-II Financial Bid
should be put up in an outer cover, which should be sealed and
superscribed as “Technical and Financial Bids for Design & Construction of
India Stand at FITUR 2019”. The left bottom of the outer cover should have
details of the bidding agency such as, Name in full of the contact person in
the agency, Postal Address, Tel. No., E-mail and sent to the Assistant
Director, India Tourism Paris, 13 Boulevard Haussmann 75009-Paris
France to reach on or before 1400 hrs. on 26t December, 2018.

5. Opening of Bids and selection procedure:

5.1 Technical bids and Financial bids will be opened by a Constituted

Committee which will evaluate the technical Bids of the agencies which are found

eligible after initial scrutiny of the bids at 1500 hrs on 26** December, 2018.

5.2 The technical bids will be judged by following the criteria:

S1.No. Particulars

| | Profile & Track Record | = |
2 Experience of setting up Pavilions/ Booths/ Stands at
International Fairs / Exhibitions / Events not related to
tourism during last three years 2015-16, 2016-17and
2017-18.
1 Mark per ject for a maximum of 5 Marks a
Experience of setting up Pavilions/ Booths/ Stands at
International Tourism related Fairs / Exhibitions
Events in overseas during last three years 2015-16
J |.
5 . g

<!-- page 6 -->

2016-17and 2017-18. Oo
[2 Marks per project for a maximum of 10 Marks}
Awards received for Pavilions / Booths / Stands at
events at Sr. Nos. 2 & 3 above.
1 Mark per award for a maximum of 5 Marks)
Concept & Design of Pavilion | 2 |
| | Effective Utilization of Space | 5 |
7 Effective Branding in the Pavilion _
8. Innovative ideas and other attractions in the Pavilion _
=

5.3 Whereas, Technical Evaluation will carry a weightage of 70 marks, financial
bids will carry weightage of 30 marks. The agencies scoring 70 per cent
marks (49 marks) or above in Technical Evaluation shall be eligible for
opening of their financial bids.

5.4. The financial bids of only those agencies that score 70 percent mark (49
marks) or above in Technical Evaluation will be opened in the presence of
their representatives. The date and time of opening of the financial bids will
be conveyed to the selected agencies. Financial evaluation will carry a
weightage of 30 Marks.

5.5 The agency which scores the highest aggregate marks on the basis of
technical and financial evaluation (after adding the scores from the
technical and financial evaluation) will be awarded the contract for
construction of the India Pavilion at the event.

6. Terms of Payment:

Payment will be made to the successful bidder as per the following schedule:

6.1 Payment of 30% of the total contractual amount will be made by

cheque/bank draft/electronic transfer as advance 14 days before the fair.

6.2 Payment of 70% of the total contractual amount will be made through

cheque/bank draft/electronic transfer on completion of the Travel Mart,

dismantling the pavilion and clearing of site.

7. Submission of Performance Security:

The selected agency has to submit Performance Security in the form of Bank

Guarantee/ Account Payee Demand Draft raised in favor of India Tourism, Paris’

from a scheduled bank for 5% of the total contract value. The Performance

Security should remain valid for a period of 60 days beyond the date of

completion of all contractual obligations. The selected agency will submit

Performance Security within 3 days from the date of te Renee of Letter of Intent

6

<!-- page 7 -->

from India Tourism, Paris. In case of any deficiency and unsatisfactory

performance by the consultant, the Performance Guarantee would be invoked

and the payment due to the agency would be withheld. No interest will be paid by
the Ministry of Tourism on the Performance Guarantee.

8. Additional Information:

8.1 India Tourism Paris reserves the right to reject or accept any offer in full or
in part without assigning any reasons whatsoever.

8.2 Incomplete and conditional bids will be rejected outright.

8.3 Any Displays / Translites produced for the India Pavilion at the event will
be the property of the Ministry of Tourism, Govt. of India, on completion of
the event and shall be handed over post event.

8.4 Validity of Tender: Tender shall remain valid for acceptance for a period of
90 days from the last date of opening of Tender/or till the end of the event
for which the tenders were called for, whichever is earlier.

8.5 Insurance: Insurance, including transit and third-party insurance will be
arranged by the service provider.

8.6 Liquidated Damages: In the event of service provider’s failure to complete
the work within the specified time, and as per the requirements of
standards of quality constructions, as mentioned in the tender document,
India Tourism Paris will recover from the service provider, as Liquidated
Damages, a sum of 10 % of the contract price for every day’s delay. Besides,
if the execution is delayed the IT, Paris may take action to debar the agency
from participation in further tenders and/or blacklist the agency.

8.7 Termination by default: India Tourism Paris reserves the right to terminate
contract of any agency in case of change in the Government procedures or
for unsatisfactory services.

8.8 Risk - Purchase Clause: If the service provider, after submission of tender
and the acceptance of the same, fails to abide by the Terms and Conditions
of the tender document or fails to complete the work within the specified
time or at any time repudiates the contract, India Tourism Paris will have
the right to:

a) In case, India Tourism Paris gets the incomplete job completed through
alternative sources and if price of completing the work is higher, the service
provider shall pay the balance amount incurred by the office for completing
the work, to IT, Paris.

b) For all purposes, the work order accepted by the bidder and issued by
India Tourism Paris will be considered as the formal contract.

8.9 Force Majeure: Neither party will be liable in respect of failure to fulfil its
obligations, if the said failure is entirely due to Acts of God, Governmental
restrictions or instructions, natural calamities or catastrophe, epidemics or
disturbances in the country. If there is a delay in performance or other
failures by the service provider to perform its obligation under its contract
due to event of a Force Majeure, the service provider shall not be held

st

<!-- page 8 -->

responsible for such delays/ failures. If a Force Majeure situation arises, the
service provider shall promptly notify the IT, Paris in writing of such
conditions and the cause thereof providing sufficient and satisfactory
evidence immediately on occurrence of such event. Unless otherwise
directed by the IT, Paris in writing, the service provider shall continue to
perform its obligations under the contract as far as reasonably practical,
and shall seek all reasonable alternative means for performance not
prevented by the Force Majeure event.

8.10 Arbitration:

(a) In event of any dispute or difference between the IT, Paris and the
Agency, such disputes or differences shall be resolved amicably by mutual
consultation. If such resolution is not possible, then the unresolved dispute
or difference shall be referred to arbitration of the sole arbitrator to be
appointed by the Secretary, Ministry of Tourism on the recommendation of
the Secretary, Department of Legal Affairs (“Law Secretary”) Government of
India. The provision of Arbitration and Conciliation Act, 1996 (No.26 of
1996) shall be applicable to the arbitration. The Venue of such arbitration
shall be at New Delhi or any other place, as may be decided by the
arbitrator. The language of arbitration proceedings shall be English. The
arbitrator shall make a reasoned award (the “Award”), which shall be final
and binding on the ITP and the Agency. The cost of the arbitration shall be
shared equally by both the parties to the agreement i.e. the IT, Paris and
the Agency (ies) and the service provider. However, expenses incurred by
each party in connection with the preparation, presentation shall be borne
by the party itself.

(b) Pending the submission of and /or decision on a dispute, difference or

claim or until the arbitral award is published; the ITF and the Agency shall

continue to perform all of their obligations under this Agreement without
prejudice to a final adjustment in accordance with such award.

8.11 Jurisdiction: The contract shall be governed by the Laws of India and by
applying to this tender, the agency accepts the applicability of Indian Law
and jurisdiction of India Courts in any dispute.

8.12 For any clarifications, you may please contact India Tourism, Paris by c-
mail directorindiatourismparis@gmailcom or telephone 0033- (0)145233045
before 18 December 2018.

The two sealed covers, Technical and Financial Bid should be put in a outer
cover superscribed “Technical and Financial Bid for Design & Construction of
India Stand at FITUR 2019:” and should be sealed. The Outder cover should have
details of the company e.g. Full Name, Postal Address, Fax, E-mail, Telephone
number of the Tenderer on the bottom left corner of the cover and sent to the
Assistant Director, India Tourism Paris, 13 Boulevard Haussmann 75009-Paris
France to reach on or before 1400 hrs. 26t December 2018.

wb There
Assi; Director
8

<!-- page 9 -->

My Nombre Expositor/Exhibitor Name: 4
Pabelién/Halt: IN. Stand/Stand Number: ‘Superficie/Surface m2: Escala/Scale: IFEMA
Pabelon 6 fae
STAND ADJUDICADO / ALLOCATED STAND SITUACION DE STAND / STAND LOCATION
ws
a Cis
a
oe OB Ba + प्र
ty oh 2.६ | | «|
oa JOU बाग 17: +» [71
हा Bas = cei |]
Tos BOs} f
eg “यह
a
PLANTA DEL STAND / STAND FLOOR PLAN
co
Pid de PT PPP in f PoP Po ire fof
png ees ore gad ttcs cops rasrcrtreeetsonctrdadiccn Rrorarrertromabncactet oth ond
ह है | डी हक Ue a ह॥ के ४8 ee है 8) ६3
>१५ ७5० २३नी लमरपद 31०० न हि पड कि ८ अंक फ> तप १०३ 89% कब बज बे 40405. tes Rete epee I ue Mle 4
1 ' 1 pty : 1 ४ ' ४11 : ४ ४ i 21k . : :
: ४ ४ rin . ४ : : 1118 ४ : : : $08 . : :
“a SOU UU A le ee ee ee een Teor ern armongenns
५ : : - 08 : ‘ 1 डे Pie 1 : : : 26k : डे '
>०० लत लाइक टत० प०००० ०५०३६ ००००६-००:१०८० ००२० ६५००० ६०० ३०००० ४०० ००००० ०००० १०००-४:०६०॥६-००-+००००३०००० «०००
uy Poop ope Po pop pope Pp per pre PoP Wy
a नाई जाई न्न नतच 4 ---+--+६----६---६------॥---२----३ a
लय beast 2०६ i iui| §
a fob ob ogee POR BSP EP bP ap Pak a ag 4
#| |: Lodthoduduitith ft i |
1 : 1 4 8 : ४ : : way : : : : 2 Oe : : :
: ‘ ४ st | ४ : : tin ५ : : : es i : :
CE SER SR ae SRR ieee aera Emerg aga Tag ae eg eee a ee ECP eR ET
: ४ : | 828 1 ° : tut & : : : : 111 : : :
enna denna danas Fedele np nnn n eden nn fee pededpe nt ned denen bd dh od
Coa fe ee 8 Ye | Ss Ue Ue £ ae हो मे
Stee ood vote eas yale ane eee gS A Os
tom on BAe eo fe Rh आ 2७8 ४६ ७४७6 & 2.5 ७७ 5७ ७३
pis 3 ॥ 408: $ 3 ४ 9 ४ Bog Fos Be Bf ६
7 डकडफकिकनरृंि्कतम-- तह...
PASILLO/AISLE
~ जलन
~ = = = services oucts
19/07/2018 |
nee “Sane
