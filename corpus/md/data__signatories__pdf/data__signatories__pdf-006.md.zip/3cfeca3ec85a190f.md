---
doc_id: "3cfeca3ec85a190f"
source_url: "https://mnre.gov.in/static/uploads/2026/01/ea26b14b5c5b17f5540d266f23c452e8.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Amendment in Guidelines for Implementation of Awareness and Outreach component under PM Surya Ghar"
date: "2025-10-06"
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9ca1bc34877298eb"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach

1) Background
a) The Government of India has approved the PM Surya Ghar: Muft Bijli Yojana on 29 th
February, 2024 to increase the share of solar rooftop capacity and empower residential
households to generate their own electricity. The scheme has an outlay of Rs 75,021 crore
and is to be implemented till FY 2026-27. The administrative approval was granted to the
scheme vide Order No. 318/17/2024-Grid Connected Rooftop dated 16th March, 2024.
b) The Financial Outlay for the scheme includes a component on Awareness and outreach with
a financial outlay of 1% of Scheme Component for Central Financial Assistance for
Residential Consumers I.e. Rs 657 crore.
c) Installation of 1 crore rooftops in the residential sector would require creating awareness
and disseminating information regarding the benefits available under PM Surya Ghar: Muft
Bijli Yojana. Under the Awareness and Outreach component of the scheme, Ministry will
utilize various channels for promotion, including public campaigns, such as social media,
print media, television, Radio jingles, nukkad and door-to-door campaigns to make
awareness about installation of Rooftop System (RTS), RTS registration and application
process, knowledge dissemination on best practices followed and information
dissemination to public regarding various components of the scheme.
2) Scope
a) These guidelines pertain to the implementation of the “Awareness & Outreach”
Component of PM Surya Ghar: Muft Bijli Yojana, under the administrative approval
granted on 16th March, 2024.

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach
Page 1 of 9

<!-- page 5 -->

b) The scope of these guidelines encompasses the framework for planning, developing,
and executing Awareness and outreach activities. These guidelines outline the process
by which requests for Awareness and Outreach plans from DISCOMs/State Nodal
Agency/ Ministry/ NPIA are received and evaluated by the Ministry of New and
Renewable Energy (MNRE), which will have the discretion to approve, modify, or
decline proposed activities.
3) Aims and Objectives
a) To create awareness among electricity consumers with focus on residential category
to take advantage of the scheme.
b) To motivate residential segment electricity consumers for taking active part in the
installation of PV System on their rooftops and to make them aware about each and
every part of the process involved in setting up rooftops solar system (RTS).
c) To communicate technical issues to consumers in a user-friendly manner in order to
enable them to make more informed choices regarding rooftop solar.
4) Implementation
a) The National Programme Implementing Agency (NPIA) shall be responsible for
implementation and monitoring of the Awareness and Outreach scheme component
for the scheme at the National Level. The State Implementation Agencies (SIAs) shall
be responsible for implementation and monitoring of the Awareness and Outreach
scheme component at the State Level.
b) The NPIA shall formulate the National Awareness and Outreach Plan for PM Surya
Ghar (NAOP-PMSG), with the approval of Ministry of New and Renewable Energy. The
SIA shall formulate the State Awareness and Outreach Plan (SAOP), with the approval
of MNRE through NPIA.

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach
Page 2 of 9

<!-- page 6 -->

c) It is also envisaged that the PM Surya Ghar: Muft Bijli Yojana shall be promoted
through collaborative efforts with field level formations of various other Ministries at
the Central level as well as other Departments at the State level. This may include
dissemination of Awareness and Outreach materials through Self Help Groups and
other formations like Cooperatives. These Ministries (“Partner Ministries”) shall also
be able to conduct their awareness and outreach activities through a Departmental
Awareness and Outreach Plan (DAOP). This will be treated on the same lines and under
the same framework as the NAOP. The Ministries shall also identify a Nodal
Implementation Agency (NIA) on their behalf that will be responsible for the
implementation of the DAOP, flow of funds from the Ministry/NPIA and for submission
of necessary reports to the Ministry of New and Renewable Energy and the Mission
Directorate of the scheme as required.
d) The DISCOMs/ State Nodal Agencies/ interested Ministries shall submit their
respective Awareness and

Outreach

plans

to

the

National

Programme

Implementation Agency. The NPIA shall scrutinize the plans and associated cost with
the plans. NPIA may undertake necessary convergence activities at its level for NAOP,
DAOP and SAOP. The SAOP and DAOP shall be assessed by the NPIA before being
proposed to MNRE for approval.
e) NPIA shall, from time to time, submit detail Awareness and Outreach plan with budget
to the Awareness and Outreach Committee. NPIA shall list all the activities with
budgets to be carried out across different State level/ District level/ sub district level
for MNRE’s approval.
f) An Awareness and Outreach Committee under the chairmanship of Mission Director,
PM Surya Ghar: Muft Bijli Yojana shall convene meetings regularly to assess the NAOP,
DAOPs and SAOPs submitted for consideration. The Committee shall either decline or
approve the proposed modifications in the respective Action Plans along with the
budgetary envelope for the Plan, and this shall be considered to be the
approval/rejection of MNRE. The other members of the committee shall include:

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach
Page 3 of 9

<!-- page 7 -->

i) Representative of the NPIA
ii) Representative of National Film Development Corporation (NFDC)
iii) Representative of Rooftop Solar Division in MNRE
iv) Representative of IFD Division, MNRE
v) Representative of I&PA division, MNRE
vi) Representative of SIA (in case of approval of Awareness and Outreach plan of
respective state SIA)
vii) Representative of the respective Department/Ministry (in case of approval of
Awareness and Outreach plan of respective Department/Ministry in Government
of India)
g) The Awareness and Outreach Committee shall scrutinize the plans and check for any
deviation from the rates as established by the Central Bureau of Communications
(CBC). The Awareness and Outreach Committee will consider the media plan (long
term/short term and obtain the approval of Secretary (MNRE) for carrying out the
activities. In respect of activities not covered under CBC approved rates i.e., non CBC
items, an Internal Cost Committee in MNRE would evaluate the reasonability of rates.
h) The Awareness and Outreach Committee shall assign the undertaking of the
Awareness and outreach activities to third party organizations (NFDC, DISCOM, SNA
or any other external organization) at its own discretion. Preference shall be given to
execute the media plan activities through CBC empaneled vendors at standard rates
adopted by CBC.
i) The organization that is assigned with the Awareness and outreach related activities
may establish different Awareness and outreach channels for the promotion of the
PM Surya Ghar: Muft Bijli Yojana at state level and in regional languages.

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach
Page 4 of 9

<!-- page 8 -->

j) The DISCOMs/ State Nodal agencies/ interested Ministries shall only use branding and
Awareness and outreach material as permitted under PM Surya Ghar scheme by
MNRE. Any cobranding or variation in the usage of branding is subject to prior
approval of MNRE.
k) The National Programme Implementation Agency (NPIA) will be responsible for the
monitoring of the communication plans for various activities for conducting such
awareness activities for consumers. NPIA shall create a Awareness and outreach
activities calendar that can be monitored from time to time.
l) The organization assigned with the Awareness and outreach work shall adhere to the
budgetary limit assigned to them as per the Awareness and Outreach Plan.
m) The Implementing Agencies may propose modifications in the approved Action Plans
from time to time and the Committee may consider this modification requests in line
with these guidelines. The Implementing agencies shall submit regular status reports
to the Committee through NPIA, as and when required by the Committee.
5) Components of Awareness and outreach Plans
a) The Awareness and outreach Plans may, inter alia include the following major
components
i) Electronic Media Campaigns, which will include:
(1) Publicity on Television - Private Cable & Satellite with dubbing in official
regional languages.
(2) “Audio-visual spots’’ like Testimonial Videos, in show integrations with
national and regional Celebrities that would be shown on TV & social media.
(3) “Audio Spots/Jingles’’ broadcast through radio.
(4) Street theatre to promote desirable behaviour through street plays, folk songs
etc.

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach
Page 5 of 9

<!-- page 9 -->

(5) Talk shows, panel discussions and expert lectures on related issues on national
and regional channels.
(6) Radio Jingles on Private radio Stations and All India Radio Stations
(7) Any other electronic/digital media campaigns activities.
ii) Print media campaigns, which may include:
(1) Advertisement in newspapers and magazines (National/Regional).
(2) Coverage of events, success stories in newspapers (National/Regional).
(3) Publication of brochures, pamphlets, leaflets, flip charts, newsletter, etc.
highlighting the initiatives taken up by Ministry, schemes, technologies,
sources available at all levels.
(4) Printing and dispatch of e-tokens for sending to scheme beneficiaries through
Department of Post or any other channel.
(5) Hoardings and bus panel designs (National/Regional levels).
(6) FAQs booklet.
(7) Any other print media channels.
iii) Outdoor Publicity
(1) Preparation and putting up of digital display board, hoardings and banners at
public places viz. railway stations, bus stops, post offices, District
Administration Offices, on buses, bus stops, other public spaces etc. through
PR agencies and other bodies.
(2) Road shows, Nukkad Nataks to showcase green conscious living, flash mobs in
cities’ malls/prominent markets etc.

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach
Page 6 of 9

<!-- page 10 -->

(3) The Common Service Centers (CSCs) and other outreach partners such as
Department of Posts (through postal workers), Ministry of Petroleum and
Natural Gas (through LPG dealer network) and Ministry of Youth Affairs
(through volunteers on MyBharat portal) shall conduct a door-to-door
campaigns to raise awareness and to generate applications on the national
portal.
(4) Urban Local Bodies and Panchayati Raj Institutions shall mobilize Institutions
at the State and district level for door-to-door campaigns.
iv) Publicity campaigns on Internet websites and mobile applications (apps)
(1) Publicity through Internet via advertisements on Meta, Twitter, LinkedIN,
Emailer etc. mediums through official account handle of the Ministry.
(2) Publicity through internet advertisements on websites.
(3) Bulk Mobile messages (SMS).
(4) Any other online publicity channels
v) Purchase of equipment/services
(1) Fee/expenses for hiring Technical and managerial consultants/experts to carry
out the above Awareness and outreach activities.
(2) Cost of procuring services rendered by Public Relations Agencies
vi) Other Relevant Activities
(1) Development of communication kit comprising of all Awareness and outreach
materials like posters, hoardings, Banner, slogans, SMS messages, informative
booklet, leaflets, audio-visual CDs, documentary films etc.
(2) Arrangements for coverage of conventions/events/press conference etc.
(3) Production of documentary on success stories and innovative practices and
showcasing it.

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach
Page 7 of 9

<!-- page 11 -->

(4) Promotion

of

scheme

through

coverage

of

conventions/

events/

conference/making of documentary films/success stories and sponsorship
activities for such conventions/events/conferences
(5) Conduct of Impact assessment of awareness activities undertaken under this
component
b) Branding on solar rooftop system
i) The Ministry may issue detailed directives pertaining to use of scheme-specific
branding and its display on installed rooftop solar system (on module, inverter or
other equipment used for installations). These directives shall be binding on the
vendor. Under these directives, only PM Surya Ghar Yojana scheme related
branding material duly approved by the Ministry shall be used. Any other branding
material (such as branding specified by state government in case the state
government is providing additional subsidy in convergence with PMSG:MBY) shall
be subject to prior approval from NPIA.
ii) The cost of implementation for the branding under such directive shall be under
the scope of vendor, and the complete cost shall be borne by the vendor.
6) Financial Outlay and Management
a) The total financial outlay of Awareness & Outreach component of the scheme is Rs
657 crore.
b) General Financial Rules (GFRs) would be followed while dealing with matters involving
public finances in respect of activities to be undertaken in para 5 of the guidelines.
Further, for all types of publicity purposes/rates, guidelines of Central Bureau of
Communication (CBC) and National Film Development Corporation Limited (NFDC)
shall be followed where available. Any deviation in this regard in cases of urgency or
short notice (up to a month) for incurring expenditure on account of conducting such
un-planned activities under Awareness and outreach would require prior approval of
Awareness and Outreach committee.

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach
Page 8 of 9

<!-- page 12 -->

c) After the approval of the relevant NAOP, SAOP or DAOP, the Implementing Agency
may request for advances as per the extant norms of the Ministry of Information and
Broadcasting (Ministry of I&B). In case of requests that may not fall within the remit
of these extant norms, the releases shall be guided by the following
i) Advance release of up to 40% of the budget sanctioned for the Implementing
Agency
ii) 60% of the budget to be released after completion of the activities, submission of
activity reports, utilization certificates, and audited statement of expenditure.
d) Any advance to a privately owned DISCOM will be released after submission of bank
guarantee of requisite amount.
e) The admissible CFA for conducting the Awareness and outreach programme e.g.
National, International or State level by the implementing agency may be restricted as
per the norms set by the I&PA/CBC.
f) The Implementing agency will remit the accrued interest and other charges to
Consolidated Fund of India as per Rule-230(8) of GFRs 2017.
7) Monitoring
a) The NPIA shall monitor the implementation of the Awareness and outreach Plans in
coordination with other Departments of Central Government and their Nodal
Implementation agencies and SIAs. In particular, the NPIA shall regularly coordinate
with Ministry of Information & Broadcasting and to track progress of Awareness and
outreach related activities that have been approved by the Awareness and Outreach
Committee as a part of the AOPs.
8) Amendment of Guidelines
a) MNRE may make necessary amendments in the scheme guidelines for Awareness &

Outreach within the overall spirit of the Cabinet approval or issue any clarification to
remove difficulties in the implementation of the scheme, as and when required, with
the approval of Hon’ble Minister, New and Renewable Energy.

Guidelines for PM-Surya Ghar: Muft Bijli Yojana
Awareness and Outreach
Page 9 of 9
