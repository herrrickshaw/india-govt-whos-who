---
doc_id: "3eabd25c86b51dcf"
source_url: "https://mnre.gov.in/static/uploads/2025/07/83afc65c56f8f720bb26fdd6c154f875.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Revised Guidelines for installation of prototype wind turbine models"
date: "2025-06-12"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "9dd2b835e6f032eb"
---

<!-- page 1 -->

F. No.: 238/17/2017-Wind
Ministry of New and Renewable Energy
(Wind Energy Division)
Atal Akshaya Urja Bhawan,
Lodhi Road, New Delhi-11003
Date: 12'" June, 2025
Subject: Revised Guidelines for installation of prototype wind turbine models- reg.
Ministry had issued guidelines for installation of prototype wind turbine models on
22.05.2012 and amended the same on 20.09.2012 and on 01.06.2016. These guidelines are
being issued in suppression of the existing guidelines in order to facilitate the installation of
limited number of prototype wind turbines so as to promote testing and certification
process of wind turbine in the country.
These guidelines are applicable for all the wind turbine manufacturers in India, who wish
to install prototype wind turbine model(s) in the country and synchronize with the Indian
grid system. It is desirable to allocate land on “footprint basis” for installation of prototype
wind turbine(s).
The installation of a prototype wind turbine model will be allowed only to carry out type
testing for obtaining type certificate from Internationally Accredited Certifying Agencies,
subject to the following conditions:
(i) Implementing Agency:
The guidelines will be implemented by the National Institute of Wind Energy (NIWE),
Chennai. The manufacturer(s) of the wind turbine whose prototype is to be installed, shall
submit requisite information and documentation as per the prescribed format (to be
provided by NIWE) to NIWE, Chennai for obtaining recommendation to permit
installation of wind turbine prototype model for testing and grid synchronization /
commissioning.
(ii) Eligibility for Type Certification Schemes and documents required to be
submitted with application:
a. The following type certification schemes will be considered under these guidelines;
« IECRE OD 501
« IS/IEC 61400-22:2010

b. The type testing and certification shall be carried out only by Internationally
Accredited Testing and Certification bodies.

c. Prototype certificate for the prototype wind turbine model (to be installed at a
specific location) shall be provided to NIWE by the Wind turbine manufacturer. In
case the site /location details is not part of Prototype certificate, a separate letter /
document issued by the type certification body in this regard may be submitted.

3 ५७०7०, ०६. 1202S

<!-- page 2 -->

d. The manufacturer(s) of wind turbines shall provide copies of contracts signed for
type testing and type certificate with Internationally Accredited Testing and
Certification Bodies.

e. The prototype certificate shall have a maximum validity period of 3 years. Extension
of prototype certificate validity may be allowed subject to the compliance of the
conditions stipulated in the clause 6.3: “Prototype Certification” of IECRE OD501
and submission of revised/modified prototype certificate for the same prototype wind
turbine model to NIWE. In case of revised/modified prototype certificate, wind
turbine prototype model name shall be the same. However, manufacturers may
include variants/ alternative configurations in the existing name of the prototype wind
turbine model to distinguish differences. In addition, a list of changes/modifications
and a list of new components/ parts used in the modified prototype wind turbine
issued by the type certification body shall have to be provided to NIWE along with
revised/modified prototype certificate to obtain the revised recommendation letter to
carryout type testing.

f. A letter issued by the type testing and type certification body on the status of type
testing and type certification shall be provided at the end of every year to NIWE.

(iii) Operation and Maintenance:
Regular maintenance and service shall be carried out for the prototype wind turbines
installed. The type certification body will provide a letter at the end of the year regarding
regular operation and maintenance of prototype wind turbines. Failing which the wind
turbines are liable to be disconnected from the grid.

2. A maximum period of 3 years from date of issuance of recommendation letter from
NIWE for the prototype wind turbines will be allowed to complete testing and for obtaining
the type certificate. However, validity of prototype certificate shall be maintained till the
type certificate is issued. In case of submission of revised/modified prototype certificate for
the existing prototype wind turbine model and after obtaining the revised recommendation
letter from NIWE to carryout type testing, the testing and certification shall have to be
completed and type certificate shall be submitted within 4 years from the date of issuance of
recommendation letter by NIWE with regard to original prototype certificate.

35 A maximum period of 18 months from date of issuance of recommendation letter
from NIWE, within which all the prototype wind turbines shall be commissioned / grid
synchronized.

4. Commissioning certificate / grid synchronization report for the prototype wind
turbines, issued by the concerned State utility / SNA shall be provided by manufacturer to
NIWE, immediately after the commissioning / grid synchronization.

5. For each prototype wind turbine model, maximum 3 Nos of wind turbines will be
allowed for grid synchronization / commissioning.

6. The type certificate for prototype wind turbine model shall be obtained from an
Internationally Accredited Type Certification Body as per the scheme mentioned in Para-
1G) within the 3 years from the letter of NIWE. In case of submission of modified/revised
prototype certificate, the type certificate shall have to be submitted in accordance to Para 2

)४७०००० ५५ eS

<!-- page 3 -->

above, failing which such installed prototype wind turbine(s) shall be immediately
disconnected from the grid and uprooted at the cost of manufacturer(s).
7. The prototype wind turbines shall be owned by the concerned wind turbine
manufacturer and shall not be sold to any party, until the model is included in Revised List
of Models and Manufacturers of wind turbines (RLMM).
8. Serial production and installation of prototype wind turbines will not be allowed until
the wind turbine model is included in RLMM.
9; The components / items procured / imported for manufacturing of the prototype wind
turbines will be new and unused. No second-hand components / machines will be allowed.
However, the changes/modification to the already installed prototype wind turbine will be
allowed as per the clause ii(e) above.
10. The components / items procured / imported for manufacturing of the prototype wind
turbines will be eligible for custom and excise duty exemption as per notifications issued by
custom and excise departments from time to time.
11. An Affidavit and indemnity bond have to be submitted by the manufacturers to the
State utility/ SNA and NIWE for complying to the above conditions. The format of the
indemnity bond can be obtained from NIWE.
12. If one or more of the conditions mentioned above are not satisfied, the permission
granted for the prototype installation and testing can be withdrawn unilaterally in the interest
of safety and security.
13. This issues with the approval of Secretary, MNRE. हे
\wera, 0 6 28°
(Vikram Dhaka)
Scientist-D
To
All concerned.
