---
doc_id: "3ca0ce93da6a4f6c"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/67c487176d03db7716586184e36123b6.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 358 of 2026 in Honble High Court of Delhi: DoT instructions dated 10.06.2026 to ISPs"
date: "2026-06-10"
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6abe9fdbce9bbf3a"
---

<!-- page 1 -->

4-10/2025-DGT/4(Part-I)

I/3407387/2026

By Email/ DoT Website
File No.: 4-10/2025-DGT/4(Part-I)
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
nd
2 Floor, UIDAI HQ, New Delhi -110001
Date:

-06-2026

To
All Licensees with Internet Service Authorization
Subject: CS (COMM) 358/2026: HOME BOX OFFICE INC vs. MOVIEBOX.PH &
ORS. in the Hon’ble High Court of Delhi.
Please find enclosed the Hon’ble High Court of Delhi order dated 06.04.2026 in the
captioned case.
2.
Please refer to Para 27(v) of the said Court Order. In compliance with the directions
contained therein, an additional list comprising 46 domains/URLs for blocking public access
has been received from the counsel for the Plaintiff, as per the enclosed list.
3.
In view of the above, all Licensees with Internet Service Authorization are hereby
instructed to take immediate necessary action in respect of blocking access to the said
website(s)/domain(s), as per the enclosed list, in compliance with the said court orders.

Encl: A/A

ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court order/
enclosed Annexure pl.
ii.)
Mr. Aditya Singh Thakur (aditya.t@saikrishnaassociates.com), Plaintiﬀ's
Counsel - For kind information and with a request to take action as per the enclosed
Annexure pl.

<!-- page 2 -->

4-10/2025-DGT/4(Part-I)

I/3407387/2026

CS(COMM) No. 358/2026:
Website(s)/domain(s)
No. Domains
1
w3.cuevana.one
cuevana.one
2
cuevana.homes
3
cuevana.skin
4
cuevana3hd.buzz
5
cuevana3hd.one
6
cuevana3io.lat
7
cuevana3io.me
8
cuevana3to.lat
9
cuevana3to.pro
10 cuevana8tv.lat
11 cuevanaplus.club
12 cuevanaplus.mom
13 cuevanaplus.one
14 cuevanapro.one
15 cuevanatv.fun
16 cuevanatv.legal
17 cuevanatv.one
18 cuevana3i.cv
19 cuevana3plus.net
20 cuevana3cc.site
21 cuevana.gs
cuevanav.net
la.movie
22 www.cuevana3.is
cuevana3.is
23 cuevanapro.homes
24 cuevanapro.lat
25 cuevana3.sc
cuevanas.org
26 new.bollyflix.gd
new.bollyflixpro.com
bollyflix.frl
27 kisskh.asia
28 vixsrc.to
29 movix.tax
movix.health
movix.rodeo
movix.blog
movix.website

URL
https://w3.cuevana.one
https://cuevana.one
https://cuevana.homes
https://cuevana.skin
https://cuevana3hd.buzz
https://cuevana3hd.one
https://cuevana3io.lat
https://cuevana3io.me
https://cuevana3to.lat
https://cuevana3to.pro
https://cuevana8tv.lat
https://cuevanaplus.club
https://cuevanaplus.mom
https://cuevanaplus.one
https://cuevanapro.one
https://cuevanatv.fun
https://cuevanatv.legal
https://cuevanatv.one
https://cuevana3i.cv
https://cuevana3plus.net
https://cuevana3cc.site
https://cuevana.gs
http://cuevanav.net
https://la.movie/
https://www.cuevana3.is
https://cuevana3.is
https://cuevanapro.homes
https://cuevanapro.lat
https://cuevana3.sc/
https://cuevanas.org
https://new.bollyflix.gd
https://new.bollyflixpro.com
https://bollyflix.frl
https://kisskh.asia
https://vixsrc.to
https://movix.tax
https://movix.health
https://movix.rodeo
https://movix.blog
https://movix.website

IP Address 1
104.21.27.191
104.21.27.191
172.67.163.189
172.67.209.23
104.21.2.45
172.67.157.150
172.67.144.33
172.67.178.244
172.67.204.229
172.67.200.212
104.21.28.227
172.67.168.170
104.21.38.37
104.21.17.82
104.21.62.116
104.21.28.145
104.21.4.156
172.67.190.113
172.67.143.114
172.67.206.65
172.67.198.210
104.21.34.14
172.67.218.96
104.21.55.176
172.67.197.176
104.21.90.84
104.21.80.104
172.67.166.146
172.67.211.103
172.67.209.176
104.21.43.18
13.127.247.216
13.127.247.216
104.26.0.225
104.21.18.123
104.21.30.142
104.21.78.230
104.21.63.138
75.2.60.5
75.2.60.5

IP Address 2
172.67.143.119
172.67.143.119
104.21.34.188
104.21.58.222
172.67.152.132
104.21.40.234
104.21.55.23
104.21.17.252
104.21.69.51
104.21.13.166
172.67.147.193
104.21.87.21
172.67.218.191
172.67.175.80
172.67.223.128
172.67.170.223
172.67.132.58
104.21.19.229
104.21.27.186
104.21.58.187
104.21.13.80
172.67.153.23
104.21.24.117
172.67.171.201
104.21.90.84
172.67.197.176
172.67.177.226
104.21.49.192
104.21.85.212
104.21.45.44
172.67.215.218

172.67.72.114
172.67.181.211
172.67.172.251
172.67.137.245
172.67.146.16

<!-- page 3 -->

4-10/2025-DGT/4(Part-I)

30
31
32
33

I/3407387/2026

reelzone.live
www.videasy.net
videasy.net
cineby.bz
distanz-film.com
aether.mom

https://reelzone.live
https://www.videasy.net/
https://videasy.net
https://cineby.bz
https://distanz-film.com
https://aether.mom

172.67.191.228
104.21.92.118
172.67.192.252
104.21.31.155
172.67.164.46
104.21.57.117

104.21.20.77
172.67.192.252
104.21.92.118
172.67.178.58
104.21.41.101
172.67.190.89

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21

22
23
24
25
26

27
28
29

30
31
32

Domains
w3.cuevana.one
cuevana.one
cuevana.homes
cuevana.skin
cuevana3hd.buzz
cuevana3hd.one
cuevana3io.lat
cuevana3io.me
cuevana3to.lat
cuevana3to.pro
cuevana8tv.lat
cuevanaplus.club
cuevanaplus.mom
cuevanaplus.one
cuevanapro.one
cuevanatv.fun
cuevanatv.legal
cuevanatv.one
cuevana3i.cv
cuevana3plus.net
cuevana3cc.site
cuevana.gs
cuevanav.net
la.movie
www.cuevana3.is
cuevana3.is
cuevanapro.homes
cuevanapro.lat
cuevana3.sc
cuevanas.org
new.bollyflix.gd
new.bollyflixpro.com
bollyflix.frl
kisskh.asia
vixsrc.to
movix.tax
movix.health
movix.rodeo
movix.blog
movix.website
reelzone.live
www.videasy.net
videasy.net
cineby.bz

URL
https://w3.cuevana.one
https://cuevana.one
https://cuevana.homes
https://cuevana.skin
https://cuevana3hd.buzz
https://cuevana3hd.one
https://cuevana3io.lat
https://cuevana3io.me
https://cuevana3to.lat
https://cuevana3to.pro
https://cuevana8tv.lat
https://cuevanaplus.club
https://cuevanaplus.mom
https://cuevanaplus.one
https://cuevanapro.one
https://cuevanatv.fun
https://cuevanatv.legal
https://cuevanatv.one
https://cuevana3i.cv
https://cuevana3plus.net
https://cuevana3cc.site
https://cuevana.gs
http://cuevanav.net
https://la.movie/
https://www.cuevana3.is
https://cuevana3.is
https://cuevanapro.homes
https://cuevanapro.lat
https://cuevana3.sc/
https://cuevanas.org
https://new.bollyflix.gd
https://new.bollyflixpro.co
https://bollyflix.frl
https://kisskh.asia
https://vixsrc.to
https://movix.tax
https://movix.health
https://movix.rodeo
https://movix.blog
https://movix.website
https://reelzone.live
https://www.videasy.net/
https://videasy.net
https://cineby.bz

IP Address 1
104.21.27.191
104.21.27.191
172.67.163.189
172.67.209.23
104.21.2.45
172.67.157.150
172.67.144.33
172.67.178.244
172.67.204.229
172.67.200.212
104.21.28.227
172.67.168.170
104.21.38.37
104.21.17.82
104.21.62.116
104.21.28.145
104.21.4.156
172.67.190.113
172.67.143.114
172.67.206.65
172.67.198.210
104.21.34.14
172.67.218.96
104.21.55.176
172.67.197.176
104.21.90.84
104.21.80.104
172.67.166.146
172.67.211.103
172.67.209.176
104.21.43.18
13.127.247.216
13.127.247.216
104.26.0.225
104.21.18.123
104.21.30.142
104.21.78.230
104.21.63.138
75.2.60.5
75.2.60.5
172.67.191.228
104.21.92.118
172.67.192.252
104.21.31.155

IP Address 2
172.67.143.119
172.67.143.119
104.21.34.188
104.21.58.222
172.67.152.132
104.21.40.234
104.21.55.23
104.21.17.252
104.21.69.51
104.21.13.166
172.67.147.193
104.21.87.21
172.67.218.191
172.67.175.80
172.67.223.128
172.67.170.223
172.67.132.58
104.21.19.229
104.21.27.186
104.21.58.187
104.21.13.80
172.67.153.23
104.21.24.117
172.67.171.201
104.21.90.84
172.67.197.176
172.67.177.226
104.21.49.192
104.21.85.212
104.21.45.44
172.67.215.218

172.67.72.114
172.67.181.211
172.67.172.251
172.67.137.245
172.67.146.16

104.21.20.77
172.67.192.252
104.21.92.118
172.67.178.58

<!-- page 8 -->

33

distanz-film.com
aether.mom

https://distanz-film.com
https://aether.mom

172.67.164.46
104.21.57.117

104.21.41.101
172.67.190.89

<!-- page 9 -->

$~56
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 358/2026
HOME BOX OFFICE INC
Through:

versus
MOVIEBOX.PH & ORS.
Through:

.....Plaintiff
Mr. Siddharth Chopra, Mr. Saikrishna
Rajagopal, Mr. Raghav Goyal, Ms.
Mehr Sidhu, Mr. Affan Moin and Mr.
Aditya Thakur, Advocates.
.....Defendants
Mr. Shivansh Tiwari and Ms. Kruttika
Vijay, Advocates for D-21/Porkbun
LLC.

CORAM:
HON'BLE MR. JUSTICE TUSHAR RAO GEDELA
ORDER
06.04.2026

%

I.A. 9146/2026 (Additional Documents)
1.

The present application has been filed on behalf of the plaintiff under

Order XI Rule 1(4) of the Code of Civil Procedure, 1908 (‘CPC’) as applicable
to commercial suits under the Commercial Courts Act, 2015 (‘CC Act’) seeking
leave to place on record additional documents.
2.

The plaintiff is permitted to file additional documents in accordance with

the provisions of the CC Act and the Delhi High Court (Original Side) Rules,
2018.
3.

Accordingly, the application stands disposed of.

I.A. 9147/2026 (Seeking Additional time to file Court fees)
4.

The present application has been filed by the plaintiff under Section 149

read with Section 151 of CPC, seeking exemption from payment of Court Fees
at the time of the filing of the suit.
5.

Considering the submissions made in the present application, an

extension of two weeks is granted to affix the requisite Court Fees.
CS(COMM) 358/2026

Page 1 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 10 -->

6.

The application stands disposed of.

I.A. 9145/2026 (Exemption from issuing notices to D-41 and D-42)
7.

The present application has been filed on behalf of the plaintiff under

Section 80 read with Section 151 of CPC seeking exemption from issuing prior
notices to defendant no.41/DoT and defendant no.42/MEITY.
8.

In view of the urgent nature of relief sought against defendant nos.1 to

20, the plaintiff is exempted from effecting prior notice under Section 80 of the
CPC upon defendant nos.41 and 42 at this stage.
9.

The application stands disposed of.

I.A. 9144/2026 (Order XXXIX Rules 1 & 2, CPC)
10.

Present application has been filed on behalf of the plaintiff under Order

XXXIX Rules 1 & 2 of CPC, 1908 seeking ex-parte ad-interim injunction
against the defendants.
11.

Plaintiff claims to be a company incorporated in the State of Delaware,

USA. Plaintiff is an entertainment company which has produced acclaimed
television series such as “Game of Thrones” and “The Wire”. Plaintiff was
accorded international award for ‘Outstanding Drama Series’ at the Primetime
Emmy Awards in 2019 for the show “Game of Thrones” and in 2023, for the
show “Succession”. Plaintiff claims to be a reputed production house and a
studio involved in the business of production, acquisition, co-production,
promotion, marketing, distribution of various cinematograph films and
audio-visual contents in various languages, in multiple formats worldwide
including television, digital and internet connected platforms.
12.

The plaintiff has produced in the past, the Series called ‘Euphoria:

Season 1’ and ‘Euphoria: Season 2’ (hereinafter referred to as ‘the Series’). The
plaintiff also is planning to launch ‘Euphoria: Season 3’ (hereinafter referred to
as ‘the Show’) on 15.04.2026 in India on the Over-The-Top (OTT) platform
JioHotstar and on 12.04.2026, globally. Plaintiff states that it has applied for
CS(COMM) 358/2026

Page 2 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 11 -->

registration of copyright of the Show in USA on 11.03.2026.
13.

In para 6 of the plaint, the plaintiff has given the brief background of

what the Series contain. In para 7, the plaintiff has given details of various
awards as well as nominations by the Series including 25 Primetime Emmy
Awards (9 wins), 1 Golden Globe Award, 3 Critics’ Choice Television Awards,
1 Peabody Award etc. The lead actress also won ‘Outstanding Lead Actress’ in
the Series.
14.

The plaintiff has claimed to have spent large sums of money in

production of the Series and the Show and has actively promoted the Show
prior to the release. Plaintiff has released the official trailer of the Show on
14.01.2026 on YouTube which generated more than 6 million views as on
31.03.2026.
15.

Plaintiff’s Series and Show are works of visual recording including

sound recording and qualify as “Cinematographic Film” under the provisions
of Copyright Act, 1957. Plaintiff asserts to be the owner of the original artistic
works embodied in the Series and the Show. By virtue of provisions of Section
40 of the Copyright Act, 1957 read with the International Copyright Order,
1999, the rights of the plaintiff are recognised, protected and enforceable in
India. In para 11 of the plaint, the plaintiff has enlisted an illustrative list of
cinematographic films/shows of which it is the author and/or first owner. The
same is enumerated hereunder:-

CS(COMM) 358/2026

Page 3 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 12 -->

16.

Plaintiff asserts that it has not issued any license or any authorisation to

any of the defendants and the plaintiff has a clear apprehension that the
defendant nos.1 to 20 are likely to host, upload, stream, reproduce, download,
distribute, broadcast, make available to the public and/or communicate to the
public the Series and the Show.
17.

Plaintiff claims that in the industry, it is an ordinary practice of prudence

that the Series which is released on paid OTT Platforms, the initial stage of
release and subsequent days constitute primary and most crucial in the
commercial lifecycle of the content. On the basis of the viewership and
popularity that the Show achieves during this period, the plaintiff is able to
recover and recoup substantial investment made in the production, promotion
and distribution of the Show. It is when parties like defendant nos.1 to 20 and
defendant no.43/Ashok Kumar(s) indulge in the aforesaid copyright violations
that the plaintiff would suffer huge financial losses, and such unscrupulous
defendants unjustly enrich themselves with.
18.

Plaintiff claims that the parallel availability of infringing copies of the

the Show in the form of unauthorised digital downloads on the internet and
mobile platforms during the official release window would amount to
infringement. It is stated that this directly impacts plaintiff’s business and
erodes the commercial value of the Show. It is stated that the defendants’
websites are available all across the world including India thereby conferring
territorial jurisdiction with this Court to pass necessary orders to protect the
interests of the plaintiff.
19.

The plaintiff has enlisted the domain names pertaining to defendant

nos.1 to 20 in para no.24 of the plaint. Plaintiff states that the infringing
websites are online locations which enable users of the said websites to, (a)
view (by a process known as streaming/downloading) cinematograph
films/television shows, being motion pictures, television and anime programs,
CS(COMM) 358/2026

Page 4 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 13 -->

or other audio-visual content, on devices connected to the internet; (b) cause
copies of those cinematograph films/shows to be downloaded onto the memory
of their devices for watching later or enabling others to watch or make further
copy of those cinematograph films/shows; and/or (c) identify other online
locations (by a process known as linking) which enable users to engage in the
activities set out in (a) or (b).
20.

Based on the judgment of this Court in UTV Software Communication

Ltd. & Anr. vs. 1337x.to & Ors., in CS(COMM) 724/2017, the plaintiff states
that the infringing websites of the defendants are rogue websites which are
likely to commit acts of infringement as stated above and thus, are required to
be restrained from infringing the copyrights of the plaintiff in the Show as well
as the Series. Plaintiff also apprehends that the rogue websites might, at the
launch and during the currency of the Show and subsequently, may create
mirror/redirect/alphanumeric websites which may also need to be restrained by
way of dynamic injunction as propounded in UTV Software (supra).
21.

Plaintiff also asserts that on previous occasions, this Court has adopted

real-time blocking measures to curb infringement by the rogue websites, as
reflected by the order dated 30.01.2026 passed in CS(COMM) 89/2026 titled
JioStar India Pvt. Ltd. vs. GHD Sports & Ors., and consequently, such
illegal/rogue websites have been injuncted and taken down by way of the
dynamic injunction granted by this Court.
22.

The modus operandi undertaken by the defendant nos.1 to 20 and

defendant no.43/Ashok Kumar(s) are clearly mentioned in para nos.30 to 34 of
the plaint and are not repeated herein for the sake of prolixity. Some of the
websites owned by the defendants which have been blocked in other
jurisdictions are mentioned in para 36 of the plaint. In order to support the
contents of the plaint and the manner in which rogue websites operate, the
plaintiff has annexed with the plaint the affidavit of an investigator, namely Mr.
CS(COMM) 358/2026

Page 5 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 14 -->

Manish Vaishampayan, the details of which are mentioned in para nos.42 to 47.
23.

Predicated on the above, plaintiff seeks an ex-parte ad-interim

injunction and other reliefs in its favour and against the defendants.
24.

Having considered the submissions made by the learned counsel for the

plaintiff and perusing the pleadings and the documents on record, this Court is
of the opinion that an ex-parte ad-interim injunction would be in order.
25.

The plaintiff being the producer and owner of the Series and the Show

has the exclusive distribution rights to publicly exhibit and communicate the
Series and contents associated with it, through all modes. The apprehension of
the unauthorized dissemination, telecasting, or communication of the Series
and the Show on the websites shall pose a significant threat to the plaintiff’s
revenue streams undermining the value of the considerable investment made by
the plaintiff in producing the said Series and the Show. The issue of the
websites engaging in the piracy of copyrighted content presents a recurring
threat and disseminating or communicating any portions of the Series and the
Show, without proper authorization or licensing from the plaintiff, would
violate the plaintiff’s copyright.
26.

In view of the above and given the fact that the plaintiff has copyright in

the Series and the Show in question, if an ex-parte ad-interim injunction is not
granted at this stage, irreparable harm would be caused to the plaintiff as the
Show is scheduled to be released on OTT Platform JioHotstar on 15.04.2026 in
India and on 12.04.2026 globally. Considering the possibility of unauthorized
dissemination of the Series and the Show in question in the age of internet, it
would require effective and swift means to contain the spread of unauthorized
dissemination of the same. Balance of convenience also lies in the favour of the
plaintiff. The need for immediate relief is particularly pressing in this case,
considering the release of the upcoming season of the Euphoria Series. Any
delay in blocking access to websites or any other rogue websites providing the
CS(COMM) 358/2026

Page 6 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 15 -->

impugned services, could lead to financial losses for the plaintiff, and an
irreparable breach of their copyright. Therefore, swift action to prevent the
alleged infringements is crucial in the present case.
27.
i.

In view of the above, the following directions are passed:The

defendant

nos.1

to

20

and

any

such

other

mirror/redirect/alphanumeric website which appears to be associated
with any of the defendant websites, either based on its name, branding,
the identity of its operator, or source of the content or discovered to
provide additional means of accessing the defendant websites and other
domains/domain alongwith their sub-domains and sub-directories,
owners/website operators/entities which are discovered during the
course of the proceedings to have been engaged in infringing the
plaintiff’s exclusive rights and copyrights in the Series – Euphoria:
Season 1, Euphoria: Season 2 and/or the upcoming season of the same –
Euphoria: Season 3, its owners, partners, proprietors, officers, servants,
employees, and all others in capacity of principal or agent acting for and
on their behalf, or anyone claiming through, by or under it, are restrained
from, in any manner, hosting, streaming, reproducing, distributing,
making available to the public and/or communicating to the public, or
facilitating the same on their websites, through the internet in any
manner whatsoever, in respect of the Series – Euphoria: Season 1,
Euphoria: Season 2 and/or the upcoming season of the same – Euphoria:
Season 3 in which the plaintiff has copyright;
ii.

Defendant nos.21 to 31 i.e., the Domain Name Registrars (DNRs), their
directors, partners, proprietors, officers, affiliates, servants, employees,
and all others in capacity of principal or agent acting for and on their
behalf, or anyone claiming through, by or under it, are directed to
lock/suspend and provide all details including but not limited to names

CS(COMM) 358/2026

Page 7 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 16 -->

of registrants of the said defendant nos.1 to 20 websites, including KYC,
credit card, mobile number etc., to the plaintiff, identified in the instant
suit, within 72 hours of receiving a copy of this Order. Specific DNRs
for each website are disclosed in Annexure-A appended to this Order;
iii.

Defendant nos.32 to 40/ISPs, their directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and on their behalf, or anyone claiming
through, by or under it, are directed to block access to the defendant
nos.1 to 20 websites as identified by plaintiff in the instant suit, within 72
hours of receiving a copy of this Order. The details for the same are
identified in Annexure-B appended to this Order;

iv.

If any further websites are discovered during the course of the
proceedings, which are found to be unauthorizedly streaming,
communicating, hosting or making available content over which the
plaintiff has exclusive copyright in respect of the Series – Euphoria:
Season 1, Euphoria: Season 2 and/or the upcoming season of the same –
Euphoria: Season 3, the plaintiff is at liberty to communicate the details
of such websites, domain names, URLs to defendant nos.21 to 31/DNRs
and defendant nos.32 to 40/Internet Service Providers (ISPs). Upon
receiving such intimation from the plaintiff alongwith supporting
evidence, defendant nos.21 to 31/DNRs are directed to forthwith lock or
suspend the domain name registrations of such newly discovered
infringing websites and defendant nos.32 to 40/ISPs are directed to
immediately block access to the said websites;

v.

Defendant no.41/DoT and defendant no.42/MEITY are directed to issue
a notification calling upon the various ISPs registered under it to block
access to the various infringing websites identified by the plaintiff in the
instant suit, as well as any additional infringing websites discovered

CS(COMM) 358/2026

Page 8 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 17 -->

during the course of the release of the Series and the Show – Euphoria,
and notified by the plaintiff on real time basis;
28.

For any further infringing websites discovered by the plaintiff, which are

found to be offering or dealing in the plaintiff’s copyright content in the Series
and the Show, the plaintiff shall be at liberty to approach the learned Joint
Registrar (Judicial) by filing an appropriate application under Order I Rule
10, CPC for impleadment of such infringers.
29.

For extension of the present ex-parte ad-interim injunction against such

newly discovered infringers, the plaintiff shall also be at liberty to approach
this Court in accordance with law.
30.

The plaintiff shall continue to file affidavits providing details of the

newly discovered websites, their domain names and the URLs, which are
communicated and blocked to ensure that this Court is fully informed of the
websites in respect of which blocking orders are sought.
31.

If any website, which is not primarily an infringing website, is blocked in

pursuance of this Order, it is permitted to approach the Court by giving an
undertaking that it does not intend to do any illegal dissemination of the content
over which the plaintiff has copyright and the Court would consider modifying
the injunction if the facts and circumstances so warrant.
32.

Issue notice.

33.

Let a reply to this application be filed by the defendants within four

weeks from service. Rejoinder, thereto, if any, be filed within two weeks
thereafter.
34.

Compliance of Order XXXIX Rule 3 of CPC shall be done within ten

days from date.
CS(COMM) 358/2026
35.

Let the plaint be registered as a suit.

36.

Upon filing of the process fee, issue summons of the suit to the

CS(COMM) 358/2026

Page 9 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 18 -->

defendants through all permissible modes.
37.

Mr. Shivansh Tiwari, learned counsel appears on behalf of defendant

no.21/Porkbun LLC (DNR) and accepts summons.
38.

The summons shall state that the Written Statement shall be filed by the

defendants within 30 days from the date of the receipt of summons. Alongwith
the Written Statement, the defendants shall also file Affidavit of
Admission/Denial of the documents of the plaintiff, without which the Written
Statement shall not be taken on record.
39.

Liberty is granted to the plaintiff to file Replication, if any, within 30

days from the receipt of the Written Statement. Along with the Replication
filed by the plaintiff, an Affidavit of Admission/Denial of the documents of
defendants be filed by the plaintiff, without which the Replication shall not be
taken on record.
40.

In case any party is placing reliance on a document, which is not in their

power and possession, its details and source shall be mentioned in the list of
reliance, which shall also be filed with the pleadings.
41.

If any of the parties wish to seek inspection of any documents, the same

shall be sought and given within the prescribed timelines.
42.

List before the Joint Registrar (Judicial) on 09.07.2026 for completion of

service and pleadings.
43.

List before the Court on 22.09.2026.

TUSHAR RAO GEDELA, J
APRIL 6, 2026/JYH

CS(COMM) 358/2026

Page 10 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 19 -->

ANNEXURE-A
Defendant No.
21.

Porkbun LLC

DNR

22.

Tucows Domains Inc.

23.
24.
25.

NameSilo, LLC
Spaceship, Inc.
Immaterialism Limited

26.
27.

Dynadot LLC
Namecheap, Inc.

28.
29.

NETIM SARL
Key Systems GmbH

30.
31.

Registrar NIC.DO
AsiaRegister, Inc.

CS(COMM) 358/2026

Domain Names
cuevanago.online
cuevanahdpro.cam
cuevanahub.online
cuevanaoficial.online
cuevanastorm.cam
gocuevana.online
lacuevana.pics
cuevana-hd.legal
thecuevana.club
thecuevana.lat
thecuevana.online
cue-vana.pro
flixhq.tw
n1.olamovies.info
olamovies.info
olamovies.app
hurawatch.fm
hurawatch.tw
braflix.la
katmoviehd.pictures
flixhq-tv.lol
moviesmod.pink
moviesmod.town
cinegram.nethdhub4u.catering
multimovies.sarl
wvv-fmovies.com
new4.hdhub4u.fo
hdhub4u.hn
cineby.gd
cuevana.bi
kisskh.ws
cineb.gg
series2watch.net
myflixer.watch
seriesonline.sx
multimovies.nl
1shows.nl
braflix.nl
kisskh.do
moviebox.ph

Page 11 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 20 -->

ANNEXURE-B
Sr. No. Defendant Domain
Defendant No. 1
1.
moviebox.ph
Defendant No. 2
2.
flixhq.tw
3.

flixhq-tv.lol

URL

IP Addresses

https://moviebox.ph

10.0.10.3

https://flixhq.tw

172.67.204.164
104.21.77.48
104.21.63.139
172.67.146.17

https://flixhq-tv.lol

Defendant No. 3
4.
katmoviehd.pictures

https://hatmoviehd.pictures

Defendant No. 4
5.
cuevana.bi
6.
cuevanago.online

104.21.48.236
172.67.188.91

https://cuevana.bi
https://cuevanago.online

104.21.4.62
104.21.20.192
172.67.194.23
104.21.71.93
172.67.170.80
104.21.43.115
172.67.178.143
172.67.222.60
104.21.46.12
172.67.184.200
104.21.76.5
172.67.144.202
104.21.71.116
172.67.190.118
104.21.19.233
104.21.25.230
172.67.168.46
172.67.159.35
104.21.9.59
104.21.59.103
172.67.223.9
172.67.137.39
104.21.7.181
172.67.173.112
104.21.55.217

7.

cuevanahdpro.cam

https://cuevanahdpro.cam

8.

cuevanahub.online

https://cuevanahub.online

9.

cuevanaoficial.online

https://cuevanaoficial.online

10.

cuevanastorm.cam

https://cuevanastorm.cam

11.

gocuevana.online

https://gocuevana.online

12.

lacuevana.pics

https://lacuevana.pics

13.

cuevana-hd.legal

https://cuevana-hd.legal

14.

thecuevana.club

https://thecuevana.club

15.

thecuevana.lat

https://thecuevana.lat

16.

thecuevana.online

https://thecuevana.online

17.

cue-vana.pro

https://cue-vana.pro

Defendant No. 5
18.
n1.olamovies.info

https://n1.olamovies.info

19.

olamovies.info

https://olamovies.info

20.

olamovies.app

https://olamovies.app

CS(COMM) 358/2026

104.21.92.109
172.67.192.20
104.21.92.109
172.67.192.20
172.67.206.248
104.21.69.96
Page 12 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 21 -->

Defendant No. 6
21.
moviesmod.pink
22.

https://moviesmod.pink

moviesmod.town

https://moviesmod.town

Defendant No. 7
23.
multimovies.sarl

https://multimovies.sarl

24.

multimovies.nl

Defendant No. 8
25.
kisskh.ws
26.

https://multimovies.nl
https://kisskh.ws

kisskh.do

https://kisskh.do

Defendant No. 9
27.
cineby.gd

https://cineby.gd

28.

104.21.15.140
172.67.162.187
172.67.210.228
104.21.83.26
104.21.89.139
172.67.160.53
172.67.210.176
104.21.69.174
104.21.31.129
172.67.176.136
104.21.95.144
172.67.170.119
104.21.64.235
172.67.188.49
172.67.152.123
104.21.56.139

cineb.gg

https://cineb.gg

Defendant No. 10
29.
sflix.ps

https://sflix.ps

Defendant No. 11
30.
series2watch.net

104.21.80.141
172.67.185.14

https://series2watch.net

Defendant No. 12
31.
seriesonline.sx

172.67.202.187
104.21.85.56

https://seriesonline.sx

Defendant No. 13
32.
flixtor.mov

104.21.47.138
172.67.171.77

https://flixtor.mov

Defendant No. 14
33.
myflixer.watch

104.21.20.252
172.67.195.62

https://myflixer.watch

Defendant No. 15
34.
wvv-fmovies.com

104.21.18.180
172.67.183.25

https://wvv-fmovies.com

Defendant No. 16
35.
hurawatch.fm

172.67.178.50
104.21.17.192

https://hurawatch.fm

104.21.21.128
172.67.198.161
104.21.17.42
172.67.220.253

36.

hurawatch.tw

Defendant No. 17
37.
1shows.nl

CS(COMM) 358/2026

https://hurawatch.tw
https://1shows.nl

104.21.55.26
172.67.144.36

Page 13 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 22 -->

Defendant No. 18
38.
cinegram.net

https://cinegram.net

Defendant No. 19
39.
braflix.la

172.67.179.124
104.21.67.188

https://braflix.la

172.67.137.247
104.21.73.25
172.67.162.149
104.21.15.118

40.

braflix.nl

Defendant No. 20
41.
hdhub4u.hn

https://braflix.nl
https://hdhub4u.hn

42.

hdhub4u.catering

https://hdhub4u.catering

43.

new4.hdhub4u.fo

https://new4.hdhub4u.fo

CS(COMM) 358/2026

104.21.57.108
172.67.145.95
104.21.90.168
172.67.158.53
104.21.10.190
172.67.131.179

Page 14 of 14

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/04/2026 at 18:58:13

<!-- page 23 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
