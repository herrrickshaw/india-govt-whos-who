---
doc_id: "3f1c2cb8fed8ef91"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/b3550467da0f502fd0e41672c167036d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Application requirement from all existing UL(VNO) Cat B licensees"
date: "2018-08-31"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b40aca9bb8bc1c38"
---

<!-- page 1 -->

20-562/2016/AS-l(pt)
Government of India
Department of Telecommunications
.
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
51

Dated: 31 August 2018
To,
All existing VNO Cat B licensees
Subject: Application for UL (VNO) cat B authorisation after interim period thereby making
the validity of 10 years - regarding.
Reference: Existing VNO Cat B licenses.

VNO category B licenses were issued with the validity of one year and subsequently
extended from time to time . New Category of license i.e. UL(VNO) category B has been
51
introduced with effect from 31 Au gust 2018 and the same is required to be complied.
2.
New application may be submitted for UL(VNO) category Bas per revised UL(VNO)
guidelines within a period of six weeks from the date of issue of this letter. In case new
applications are not submitted within this period the existing agreement will cease to exist.
3.
The existing licence under interim arrangement shall cease to exist with the signing
of new licence as per revised appl ication and terms and conditions as per guidelines and
draft licence agreement annexed herewith . UL(VNO) Cat B Licensee is required to submit
entry fee as per the license agreement and guidelines for the extended period of validity
before signing the new license agreement. FBG for the extended period is also required to
be submitted alongwith the details of the license fee paid .
4.

Fresh agreement w ill have to be signed .

~~\11'\l.l'
Director (AS)

Encl : 1. Revised UL(VNO) guidelines .
2. Revised UL(VNO) agreement.
