---
doc_id: "3f3e6fcac0fe922b"
source_url: "https://www.mea.gov.in/images/pdf/Advt-for-Yoga-Instructors.pdf"
ministry: "External Affairs (MEA)"
title: "Advertisement for appointment of Yoga Teacher"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "19a4eec33e496a0b"
---

<!-- page 1 -->

SANS %
i विदेश मंत्रालय, नई दिल्‍ली
uN MINISTRY OF EXTERNAL AFFAIRS
ea NEW DELHI
ey
aera wat
No. Q/Wel/851/18/2017 1* March, 2021
ADVERTISEMENT FOR APPOINTMENT OF YOGA TEACHER
Ministry of External Affairs invites applications from trained Yoga instructors/teachers to teach Yoga at
MEA office (Jawaharlal Nehru Bhawan) and residential complexes (Chanakya Puri Complex and
Housing Complex at Dwarka) on part-time basis (2 hours on each working day). The
teacher/instructors will also be required to participate actively in all Yoga related activities of the
Ministry. A total monthly honorarium not exceeding Rs 20,000/- would be paid to the
instructors/teachers. The engagement would be on contractual basis.
Essential Qualification:
*  Degree/diploma/certificate in field of Yoga from a recognized Yoga institute/University.
+ Experience in conducting Yoga workshops and demonstrations.
* Good communication skills (preferably bilingual).
Age: Between 25-50 years
How to apply: Interested candidates may send in their applications to Ms Archana Monga, Welfare
Officer, Ministry of External Affairs with their complete bio-profile, photographs and contact details by
email to : welfare@mea.gov.in.
Last date of reciept of applications : 22" March, 2021 by 1700 Hrs
Shortlisted candidates will be invited for an interview.
sR
