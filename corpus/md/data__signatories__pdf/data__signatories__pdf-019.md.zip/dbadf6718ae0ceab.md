---
doc_id: "dbadf6718ae0ceab"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/e5c9d2bc910aa863a20564f688739601.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Reasoned Orders as per Supreme Court direction, World Medical College, Jhajjar"
date: "2017-08-11"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d0c74e6dccecc7b1"
---

<!-- page 1 -->

BY SPEED POST

No.U.12012/686/2015-ME - | [3063589]

Government of India
Ministry of Health & Family Welfare

(Department of Health& Family Welfare)
Nirman Bhawan, New Delhi-11
Dated the jo August, 2017.

ORDER
Subject: Conditional permission granted for establishment of Medical College in 2016-17
-Decision of the Central Government - World College of Medical Sciences &
Research, Jhajjar - reg.

Whereas the Amma Chandravati Educational & Charitable Trust made application
for establishment of new medical college at Jhajjar in the name & style of World College
of Medical Sciences & Research, Jhajjar for the academic session 2016-17 to the Ministry.
The Ministry forwarded the application to MCI for evaluation and making
recommendation to the Ministry u/s 10 A of IMC Act, 1956 for the academic session
2016-17. *

2... Whereas the Medical Council of India (MCI) conducted assessment of the college on
12th & 13th January, 2016 and the assessment report was considered by the Executive
Committee of MCI in its meeting held on 31.1.2016 and following was noted:
i. Deficiency of faculty is 93.85 % as detailed in the report.
ii. 2. Shortage of Residents is 97.83 % as detailed in the report.
iii. 3. Many Residents are not staying in the campus.
iv. Medical Superintendent is not available. 5
v. OPD: It is under construction / development. Examination rooms are not occupied
by the respective departments. Equipment is not available.
vi. Hospital is under construction/development. Rooms are allotted in wards but they
are not occupied and non-functional. Equipment are not available.
vii. Bed occupancy was 01 % on day of assessment.
viii. There was NIL Major & NIL Minor operation on day of assessment.
ix. There was NIL Normal Delivery & NIL Caesarean Section on day of assessment.
x, Radiological & Laboratory investigation workload was NIL on day of assessment.
xi. MRD: It is not available.
xii. Casualty: Separate Casualty for 0.G. is not available. Central 02 & Central Suction
are not available. Defibrillator, Ventilator are not available.
xiii. Central Clinical laboratory is non-functional.
xiv.0.T.s: They are under construction.
xv. ICUs: ICCU & ICUs are not occupied & non-functional. There was NIL patient in ICCU
or any ICU. Major equipment is not available.
1 <

<!-- page 2 -->

xvi.Labour Room: It is under construction / development.

xvii. Radiodiagnosis department: Only 1 mobile & 1 static X-ray machine are
available against requirement of 2 each. No USG is available. AERB approval is not
available.

xviii. Blood Bank is not available.

xix.CSSD, Intercom, Laundry, Kitchen, Canteen are not available.

xx. No arrangements have been made for disposal of Bio-Medical waste.

xxi.Nursing staff: Only 34 Nurses are available against requirement of 175.

xxii. Paramedical & Non-teaching staff: Only 10 Paramedical & Non-teaching staff
are available against requirement of 100.

xxiii. Dean’s office & Administrative office are located in hospital.

xxiv. MEU, College Council, Pharmaco Vigilance Committee are not constituted.

कर, Lecture Theaters are under construction.

xxvi. College building is under construction.

xxvii. Students’, Residents’, Nurses’ Hostels are under construction.

xxviii. Residential Quarters are under construction.

xxix. Gender Harassment Committee as required by order of Hon’ble Supreme
Court is not constituted.

XXX. Preclinical departments of Anatomy, Physiology, Biochemistry are under
construction.

3. Whereas, based on the above, the MCI vide letter dated 31.1.2016 recommended to
the Central Govt. not to issue Letter of Permission for establishment of New Medical
College, Jhajjar by Amma Chandravati Educational & Charitable Trust u/s 10A of the IMC
Act, 1956 for the academic year 2016-2017.
4. Whereas, u/s 10 A (4) of IMC, Act, 1956, the Ministry afforded an opportunity of
hearing to the college before a personal hearing committee on 24.2.2016 & 6.5.2016 and
the case was referred back to MCI for review. The matter was considered by MCI in its
meeting 13.5.2016 and again recommended for disapproval of scheme for academic year
2016-17 on the ground that the college failed to meet qualifying criteria ground vide
letter dated 15.5.2016.
5. Whereas, the Ministry accepting the recommendation of the MCI conveyed its
disapproval to the scheme of the Trust for establishment of new medical college in 2016-
17 vide letter dated 8.6.2016.
6. Whereas on Oversight Committee (OC) directive, the Ministry obtained compliance
from the college afresh and forwarded it to MCI. MCI returned the compliance citing
various reasons. Ministry forwarded the reply of MCI to OC.
7. Whereas the OC vide its letter dated 11.08.2016 approved the scheme of
establishment of new Medical College at Jhajjar by Amma Chandravati Educational &
, L

<!-- page 3 -->

Charitable Trust in name & style World College of Medical Sciences & Research, Jhajjar
with an annual intake of 150 for the academic year 2016-17 on certain conditions.
8. Whereas the Central Government on the approval of the OC issued necessary Letter
of Permission on 20.08.2016 to Amma Chandravati Educational & Charitable Trust for
establishment of new Medical College at Jhajjar with intake capacity of 150 for the
academic year 2016-17 with conditions imposed by the OC;
9, Whereas as per the conditions laid down in the Letter of Permission an assessment
with regard to verification of compliance submitted by the College in the Ministry was
conducted by the MCI on 26 & 27% October, 2016.
10. Whereas, the assessment report (26 & 27th October, 2016) was considered by the
Executive Committee of MCI at its meeting held on 22.12.2016 and noted the following
deficiencies:-
I. Deficiency of faculty is 29.23 % as detailed in the report.
Il. Shortage of Residents is 28.26 % as detailed in the report.
Ill. | Bed Occupancy is 34 % on day of assessment.
IV. There was NIL Normal Delivery & NIL Caesarean Section on day of
assessment. There was NIL woman in Labour Room.
V. 1605: There was NIL patient in ICCU & MICU, only 1 in NICU/PICU and only 2
in SICU on day of assessment.
VI. Central Library: It is partially air-conditioned. There is no separation of
Students’ Reading Room (Outside) & Students’ Reading room (Inside).
VII. | Anatomy department: There are only 65 mounted specimens.
11. Whereas, the MCI vide letter dated 26.12.2016 has informed and recommended to
the Ministry as under:

In view of the above, the college has failed to abide by the undertaking it had given
to the Central Govt. that there are no deficiencies as per clause 3.2(i) of the directions
passed by the Supreme Court mandated Oversight Committee vide communication dated
11/08/2016. The Executive Committee, after due deliberation and discussion, have
decided that the college has failed to comply with the stipulation laid down by the
Oversight Committee. Accordingly, the Executive Committee recommends that as per the
directions passed by Oversight Committee in para 3.2(b) vide communication dated
11/08/2016 the college should be debarred from admitting students in the above course
for a period of two academic years i.e. 2017-18 & 2018-19 as even after giving an
undertaking that they have fulfilled the entire infrastructure for establishment of new
medical college at Gurawar, Jhajjar, Haryana by Amma Chandravati Educational &
Charitable Trust, New Delhi with an annual intake of 150 MBBS students under Pandit
B.D Sharma University of Health Sciences, Rohtak, Haryana the college was found to be
grossly deficient. It has also been decided by the Executive Committee that the Bank

3

<!-- page 4 -->

Guarantee furnished by the college in pursuance of the directives passed by the Oversight
Committee as well as GOI letter dated 20/08/2016 is liable to be encashed.
12. Whereas the Ministry decided to grant a personal hearing to the College on
17.1.2017 by the DGHS. The Hearing Committee after considering the oral and written
submission of the College, submitted its report to the Ministry. In its report, the Hearing
Committee remarked as under:
Srl. Deficiencies reported by MCI Remarks of hearing
ro) Meee [ities
Deficiency of faculty is 29.23 % as detailed in the | No satisfactory reply
a
Shortage of Residents is 28.26 % as detailed in the | No satisfactory reply
a
cm
iv | There was NIL Normal Delivery & NIL Caesarean | No satisfactory reply
Section on day of assessment. There was NIL woman
| रण new
v ICUs: There was NIL patient in ICCU & MICU, only 1 in
NICU/PICU and only 2 in SICU on day of assessment.
vi | Central Library: It is partially air-conditioned. There; To be verified in
is no separation of Students’ Reading Room (Outside) | Medical college
& Students’ Reading room (Inside).
specimens. medical college
13. Whereas, the Ministry forwarded the Hearing Committee report to the OC for
guidance. The OC vide its letter dated 14.05.2017 conveyed their following views to the
Ministry:-
(i) Faculty:- The College has explained the grounds on which the assessors had not
accepted the 4 faculty members. Faculty deficiency of 06.18% is within acceptable
limits.
(11 on leave+4 not considered being late) Which is acceptable; hence there is no
deficiency.
(ii) Residents:- The College has explained the grounds on which the assessors had
not accepted the 6 residents. Resident deficiency is 08.69% (3 on leave+6 not
considered being late) which is acceptable. Hence there is no deficiency.
(iii) Bed Occupancy:- The College has explained the grounds which are acceptable
and hence there is no deficiency.
(iv) Deliveries:- This deficiency is subjective. No MSR.
(v) ICUs:- This deficiency is subjective. No MSR
(vi) Central Library:- Explanation of the College is acceptable.
है L

<!-- page 5 -->

, (vii) Anatomy department:- This deficiency is subjective. No MSR.
LOP Confirmed
14. Whereas the Ministry after considering the recommendation of MCI, Hearing
reports of the DGHS & Views of the OC decided to accept recommendation of MCI since
the College was found deficient in MCI inspection. Accordingly, Ministry vide letter dated
31.05.2017 debarred the College from admitting students for two years i.e 2017-18 &
2018-19 and authorized the MCI to encash the Bank Guarantee of Rs. 2 crores;
15. Whereas the college filed W.P (C) No. 514 of 2017 in the Hon’ble Supreme Court of
India which is a connected matter to W.P (C) No. 411 of 2017 - GLOCAL MEDICAL
COLLEGE AND SUPER SPECIALITY HOSPITAL & RESEARCH CENTRE Versus Union of
India & Others and the Hon’ble Supreme Court gave the following direction on 01.8.2017
“In the above persuasive premise, the Central Government is hereby ordered to
consider afresh the materials on record pertaining to the issue of confirmation or
otherwise of the letter of permission granted to the petitioner colleges/institutions.
We make it clear that in undertaking this exercise, the Central Government would
re-evaluate the recommendations/views of the MCI, Hearing Committee, DGHS and
the Oversight Committee, as available on records. It would also afford an
opportunity of hearing to the petitioner colleges/institutions to the extent
necessary. The process of hearing and final reasoned decision thereon, as ordered,
would be complete peremptorily within a period of 10 days from today. The parties
would unfailingly co-operate in compliance of this direction to meet the time frame
fixed”
16. Now, in compliance with the above direction of Hon’ble Supreme Court dated
1.8.2017, the Ministry granted hearing to the college on 3.8.2017. The Hearing Committee
after considering the record and oral & written submission of the college submitted its
report to the Ministry. The findings of Hearing Committee are as under:
The committee noted that the inspection was conducted on 26th -27th October,
2016. Diwali was on 29th October. The argument of the college that the inspection
was too close to a major national festival cannot be disputed.
As per regulations MCI should not conduct inspections two days before or after
major festivals. In this case the head count on the first day of inspection on
26.10.2016 was 3 days before Diwali.
5

<!-- page 6 -->

Further, 10 faculty have been verified by the assessors but were not considered in
head count since they came later than the appointed time of 11:00 AM. The college
has submitted declaration form for the 27 faculty/residents who were not
considered by MCI. The salary slips in respect of these 27 staffs do not bear details
of bank account, PAN/PRAN etc.
The college has submitted certificate from MCI vendor that the Biometric
Attendance Machine have been installed. It suggests 140 faculty are available of
which 112 were enrolled. Since this happened subsequently to the inspection, it
does not have bearing on the extent of deficiency as on the day of inspection.
The bed occupancy figure of 62% as claimed by the college is supported by the MRD
data. The assessors have noted as only 34%.
In view of the magnitude of the deficiencies pointed out in the inspection the
Committee agrees with the decision of the Ministry conveyed by letter dated
31.05.2017 to debar the college for 2 years and also permit MCI to encash bank
guarantee
17. Accepting the recommendations of the Hearing Committee, the Ministry reiterates
its earlier decision dated 31.05.2017 to debar the college from admitting students for a
period of two years i.e. 2017-18 and 2018-19 and also to authorize MCI to encash the
Bank Guarantee of Rs. 2 Crores.
LO te D
(D VK Rao)
Under Secretary to the Govt. of India
Telefax: 011-23062959
To
The Chairman/Secretary,
Amma Chandravati Educaitonal & Charitable Trust
No. 9709, C-9, Vasant Kunj,
New Delhi - 110070
Copy to:
1 The Secretary, Medical Council of India, Pocket-14, Sector-8, Dwarka, New Delhi.
2 The Secretary, Medical Education Department, Govt. of Haryana, Room No. 45, 6th
Floor, Haryana State Secretariat, Chandigarh 160001.
3 The Registrar, Pt. B.D. Sharma University of Health Sciences, Rohtak, Haryana -
124001.
4 The ADG (ME), Dte.GHS, Nirman Bhawan, New Delhi.
5 The Director, Medical Education, Govt. of Haryana, Chandigarh.
6
