---
doc_id: "dcb7b01cce2c5ef3"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_6a98f6d819cdc6.75695762.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Office Order - The work allocation assign to Ms. Roui Kullai, IFS(MN:1998), Inspector General of Forests in the Ministry of Environment, Forest and Climate Change, order dated 02-09-2026"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "5565e5e2d5ef6d2d"
---

<!-- page 1 -->

File No.:12016/07/2025-IFS.I [E. 271199]
Government of India
Ministry of Environment, Forest and Climate Change
५००००
6 Floor, Prithvi Wing,
Indira Paryavaran Bhawan, Jor Bagh Road,
Ali Ganj, New Delhi-110003.
Date: 02™ September, 2026
OFFICE ORDER
The following work allocation amonst the IGF in the Ministry has been made
with immediate effect and until further orders:-
pare A Current work Work allocated
Beth allocation i
Ms. V. L. Roui Kullai, EAP, ROHQ, EAP
IFS(MN:1998), IGF " ‘
Additional Charge of Jt. | Additional Charge of Jt.
CEO National CAMPA | CEO National CAMPA
2. This has the approval of competent authority.
(Qiok
\
°
(Prem Prakash Maurya)
Deputy Secretary to the Govt. of India
Ph - 011-20819192
Distribution :
i. PS to Hon'ble Minister of Environment, Forest and Climate Change;
ii. PS to Hon'ble Minister of State Environment, Forest and Climate Change;
iii, | PPS to Secretary, MoEF& CC;
iv. PPSs to DGF & SS/ADGF(WL)/ ADGF(FC)/ ADGF(PT)/CEO (CAMPA);
v. PSs to All IGFs/JSs/Jt. CEO(CAMPA)
vi. | JS(Admin), MoEFCC, New Delhi;
vii. All DIGFs/AIGFs;
viii. | Concerned officers;
ix. All Regional Offices/RO(HQ);
x. NIC cell for uploading on website;
xi. Reference Folder.
