---
doc_id: "de1ebdf5cd41ddb8"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/CorrigendumC12_27042026.pdf"
ministry: "Department of Space"
title: "Corrigendum:URSC/C&MG/C/C/12/2025-26 Dated:16/03/2026      724.65 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "e2da74bc1c155bc2"
---

<!-- page 1 -->

भारत सरकार/ GOVERNMENT OF INDIA
अं त र

िवभाग/DEPARTMENT OF SPACE

य़ू. आर. राव उप ह के

/U.R.RAO SATELLITE CENTRE

िनमाण व अनु र ण समू ह/CONSTRUCTION AND MAINTENANCE GROUP

No. URSC/C and MG/ACMD/DOOR/1064/ETN-102M/2025-26

Dt. 27.04.2026

CORRIGENDUM –I
On behalf of President of India, following Corrigendum-I is issued for the item rate Etender Invited for the work of “Horizontal Extension of Rendezvous Simulation Lab at ISITE
Campus, URSC, Marathahalli, Bengaluru (Civil, Electrical, Airconditioning and other allied
works)”.
No. URSC/C&MG/C/C/12/2025-26 Dt. 16/03/2026-NIET
The details are as follows.
अविध, िजसम िनिवदा द ावेज को डाऊनलोड िकया जा
सकता है । / Period during which the tender
document can be downloaded:

िनिवदा ा
के िलए अंितम िदनां क तथा समय / Last
date and time for receipt of tenders:

िदनां क 07.05.2026 को 17.00 बजे तक
बढ़ाया गया.
Extended
upto
17:00
Hrs.
on.07.05.2026
िदनां क 11.05.2026 को 17.00 बजे तक
बढ़ाया गया.
Extended
upto
17:00
Hrs.
on.11.05.2026
िदनां क 14.05.2026 को 17.00 बजे तक
बढ़ाया गया.
Extended
upto
17:00
Hrs.
on.14.05.2026
िदनां क 21.05.2026 को 14.30 बजे तक.
Upto 14:30 Hrs. on 21.05.2026

िनिवदा खोलने के िनधा रत तारीख व समय / Due date
and time of opening of tenders:

िदनां क 21.05.2026 को 15.00 बजे तक.
After 15:00 Hrs. on 21.05.2026

बोली

ीकरण / Bid clarifications:

बोली
ीकरण के िलए उ र दे ने की अंितम तारीख /
Last date of reply to bid clarification:

All other terms and conditions remain unchanged as in the above tender notice.
Sd/Group Director
(CONSTRUCTION AND MAINTENANCE GROUP)
