---
doc_id: "da4a9b40ad4a2cc2"
source_url: "https://morth.gov.in/backend/documents/uploaded/1782286935_nF01uZqNFX.pdf"
ministry: "Road Transport and Highways (MoRTH)"
title: "Additional Augmented and Systematic Remedial Measures to Address Concerns regarding Construction of National Highways in Hilly Regions and Amendments to the RFP for DPR/ Model EPC Document thereof ::"
date: ""
pages: 25
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "9f21adcd6fa9b18a"
---

<!-- page 1 -->

Ge 130.262 N
Benes No. RW/NH-33044/37/2025-S&R(P&B) (Comp No 255492)
ng Government of India
(६५०४) Ministry of Road Transport & Highways
ears... Spo Transport Bhawan, 1, Parliament Street, New Delhi-1 10001 _
Dated: 24% June, 2026
CIRCULAR
To,
1. The Chief Secretaries of all the State Governments/ UTs.
2. The Principal Secretaries/ Secretaries of all States/ UTs Public Works Department/
Road Construction Department/ Highways Department (dealing with National
Highways and other centrally sponsored schemes).
3. The Chairman, National Highways Authority of India, G-5 & 6, Sector-10, Dwarka,
New Delhi-110075.
4. The Managing Director, NHIDCL, 4 & 2° floor, Tower-A, World Trade Centre,
Nauroji Nagar, New Dethi-110029.
5. The Director General (Border Roads), Seema Sadak Bhawan, Ring Road, New Delhi-
410010.
6. All Engineers-in-Chief and Chief Engineers of Public Works Department of States/
UTs/ Road Construction Department/ Highways Departments (dealing with National
Highways and other centrally sponsored schemes).
7. The Secretary General, Indian Roads Congress
8. The Director, IAHE, Noida, UP
9. All CE-ROs, ROs and ELOs of the Ministry.
Subject: Additional Augmented and Systematic Remedial Measures to Address Concerns
regarding Construction of National Highways in Hilly Regions and Amendments to the
RFP for DPR/ Model EPC Document thereof
Reference: i)Ministry Circular No. RW/NH-33044/55/2021-S@R (P&B)pt. /Hill. Slope
Monitoring dated 28th November, 2024
| ii) Policy Circular No. RW/NH-33044/37/2025-S&R (P&B) dated 7th November,
2025.
iii) Ministry Circular No RW/NH-37010/4/2010-EAP (Printing) Vol- IV dated
05.03.2019 and subsequent amendment to EPC Model RFP thereof.
iv) RW/NH-33044/29/2021 -S&R(P&B) Part (Comp No 248404) dated 29.09.2025 and
subsequent amendment to Model DPR RFP thereof
Madam/ Sir,

The rapid expansion and widening of National Highway corridors traversing
mountainous, steep, and geologically sensitive hill terrains have historically involved
extensive mechanical slope cuts, resulting in widespread landslides, erosion, and hillside
destabilization. Recognizing the need for a_ scientifically structured engineering
methodology to manage these slope failures, the Ministry constituted a multi-disciplinary
Expert Committee to streamline the planning process. This resulted in the issuance of
specialized investigation and mitigation matrices issued vide circular mentioned under

<!-- page 2 -->

reference (i). Subsequently, Ministry issued circular mentioned under reference(ii) vide
which comprehensive directions were issued to incorporate these Protective measures into
Project preparation and execution stages. However, it has been noticed that these
guidelines have not been incorporated in Model EPC document and TOR for DPR consultants.
2. In this background, Certain amendments to the Standard RFP clauses have been made,
There shall be no Bonus clause in EPC contract National Highways Projects in Hilly Region.
The amendment to Model EPC documents is attached at Annexure-| and amendments to TOR
for DPR Consultants are attached at Annexure-Il to this circular,
3. These amendments shall be applicable only for National Highways Projects in Hilly
terrain/ Projects of Protection works in Hilly terrains.
3, All the executing agencies are requested to make the aforesaid Modifications in the
RFP document for appointment of Consultancy Services for Preparation of Detailed Project
Report (DPR) in respect of National Highways and centrally sponsored road works, before
inviting tenders.
4. This issues with the approval of Competent Authority.
Yours’ Faithfully,
a nn
(Akil Ahfnad)
Superintending Engineer
For DG(RD)&SS
Encl: Annexure-A
Copy:
1. Technical circular file of S&R (P&B) Section Technical circular file of S&R (P&B) Section
2. NIC-for uploading on Ministry's website under “What's new” & “Comprehensive
Compendium circulars”
Copy for kind information to:
1. PS to Hon’ble Minister (RT&H)
|
2. PS to Hon’ble MOS (RT&H)
3. OSD to Hon'ble MOS (Corporate Affairs and RT&H)
4. Sr. PPS to Secretary (RT&H)
5. Sr. PPS to DG (RD) & SS
6. Sr. PPS to Addl. Secretary (Transport) /Joint Secretary
7. Sr. PPS/ PPS to AS&FA
8. Sr. PPS/ PPS to all ADGs/ CEs

<!-- page 3 -->

कि
Annexure-A
Amendments in Model EPC Contract Documents in case of Projects in Hilly Terrain
10000 8 35440 5 520 हक 22 5037 कमाए एन मत ले सलल्
[clause Existing provision in| Modified pr. Existing provision in Modified provision applicable to Hill Road projects
No _| Model Agreement __ Si dla pines ae: Ee mot a so
| pee लि पन टप त क क न गत जज
| Clause Bonus for early | Deleted
19.20 completion |
| In the event that the | |
Project Completion Date
| occurs prior to the | |
| Scheduled Completion |
Date, the Contractor shall | |
| be entitled to receive a |
payment of bonus | |
| equivalent to 0.03% (zero
| | point zero three per cent) | |
| of the Contract Price for |
| । each day by which the |
Project Completion Date |
precedes the Scheduled |
| | Completion Date, but | |
| subject to a maximum of |
| | 5% (five per cent) of the
| Contract Price. Provided, |
however, that the payment
of bonus, if any, shall be |
made only after the issue |
| = the Completion |
| Certificate. For the
| avoidance of the doubt, |
| the Parties agree that for |
the purpose of determining
| the bonus payable
hereunder, the works shall
always be deemed to be as
L specified in this Contract 301 १8५

<!-- page 4 -->

ia but excluding
the works deemed to be
deleted from the scope of
work under clause 8.3 of
this Contract Agreement
and the Contract Price |
shall always be deemed to | |
be the amount specified in
i Clause 19.1 (i) after | |
excluding the Contract
| Price of the Works deemed |
to be deleted from the
Scope of Work under clause |
8.3 of this Contract
Agreement, and shall
exclude any revision | |
| thereof for any reason. The | |
Parties also agree that |
। bonus shall be payable only |
| if each work for which |
| Time Extension has been
granted is completed | |
| within respective Extended |
दि लि, | a ee 3 a a शा) |
Annexure-! to Schedule-B ; _ है |
2 (iv) tf ee a,
= of Way = of Way
[Refer to paragraph 2.3 of [Refer to paragraph 2.3 of the Manual]. Details of the Right of Way are given in Annex II of
the Manual]. Details of the Schedule-A
Right of Way are given in Additional Provision in case of Hill Road: -
| Annex II of Schedule-A. हर Authority shall provide additional Right of Way (RoW) or designated legal access beyond the
standard highway limits at the locations explicitly specified ‘dina ritpeminag en. | Table below. This additional land
[|| width/access allocation is strictly for:
1. The construction of Catch Water Di of Catch Water Drains (CWDs on hill slopes to propert intercept, collect,
y

<!-- page 5 -->

i: safely discharge surface hill runoff before it flows into the main road formation,
preventing uncontrolled velocity runoff from inducing pavement erosion and slope =
2: Accommodating subsurface slope stabilization anchor components (including soil nails,
fully grouted rock bolts, or active ground anchors) where specialized engineering designs
| structurally require these elements to extend past the normal highway boundary into land or
rock strata.”
(Details to be provided in following format)
| SL. ol Start ik Plehiaide eee. | pap 7
Chainage Chainage (LHS/RHS) | Width Engineering
| (km) (km) | | Allocated & Structural
| a Se ee
| | of km [e.g., km [e.g., [LHs]* [e.g., 4.5m]* Construction
| | 24+500]* | 24+900]* | | | of standard
| | | | Catch Water
| | Drains (CWD)
| | | and runoff
| | | channels
| | | beyond
| hi |
| | | {tare |
| La et ie ote) ict eect
| | * For illustration purpose only. Details are to be filled up as per actual project/site specific
व 3S |
Clause | 1 0105५ tt oot in kes Mees Sra ae os _ ee a
4 | Road Embankment and Road Embankment and Cut Section
| Cut Section
"= (i) Widening and improvement of the existing road embankment/ cuttings and construction of new |
(i) Widening and road embankment/ cuttings shall conform to the Specifications and Standards given in Section |
improvement of the 4 of the Manual and the specified cross-sectional details. Deficiencies in the plan and profile
existing road of the existing road shall be corrected.
embankment/cuttings (ii) Raising of the existing road [Refer to the provision O' TS"ENs of the existing road [Refer to the provision of 3 कस कब | Manual and specify sections to
i... ree

<!-- page 6 -->

BF construction of be raised] ता
new road
, embankment/ cuttings | The existing road shall be raised in the following sections:
shall conform to the pais ——
Specifications and re Section, yee Extent |
Standards given in |No. (from | ः i |
Section 4 of the Manual | (16 raising
and the specified | km) | [Top of | |
| Cross-sectional details. | | finished | |
| Deficiencies in the plan road |
| and profile of the | | | i level] | |
existing road shall be i | - | |
| corrected. [_ ue fe Sree rs | |
| (ii) Raising of the | (iti) Additional Provision in case of Hill Roads: - |
| existing road [Refer to |
| the provision of relevant | The design and execution of all cut slopes, hillside scaling, and valley slope stabilization works |
| Manual and specify | shall strictly conform to the firmed-up geotechnical and geological baseline metrics compiled in |
| sections to be raised] | Table below. These Parameters have been verified through detailed subsurface borings executed |
| | at intervals of 500 meters or closer at critical Zones, including deep cuts, high fills, landslide- |
The existing road shall be prone stretches, and structural bridge abutments as per “Expert Committee Report on Cost |
| raised in the following _ Effective Long Term Remedial Measures for landslide Prone Areas in Hilly Regions issued by |
5 sections: | Ministry vide circular No RW/NH-33044/55/2021-S&R(PEB) pt/Hill Slope Monitoring dated
| 28.11.2024 a
| हर | |
oS Secti) — Len| Exten | fo, deep cut sections exceeding a vertical height of 6.0 meters, the baseline data reflects |
| + | on | sth | tof | borehole exploration extended to the full cutting depth above the finished road level or |
N (from raisin || minimum of 5.0 meters into a competent stratum, whichever was achieved earlier.
- kmto g || Representative bulk samples from coarse-grained soils, gravels, or bouldery strata have been |
| | km) | [Top | | tested via Large Scale Shear Box testing apparatus to ensure realistic shear strength values. |
| | of __7# || | | The firmed-up Parameters, structural cross-sections, and baseline work item quantities detailed |
|| finis herein represent the absolute minimum contractual requirements for the project. |
ed __ subsequent change in parameters or rameters or modification of of -protection systems proposed by systems proposed by the
quent chang eects or modification of p Y prop. हैः

<!-- page 7 -->

road Contractor during actual execution must be vetted and validated by the fe independent third-
level] party institution nominated by the Authority (e.g., THDCIL, GSI, NIRM or others) before
approval."
(Details to be provided in following format)
Js) —— ce SSE Ea SES: _—___.——____—
| | Boreho Side Sub-Soil | Firmed- | Wat ae Pore Rock | Min Vetting
| leID/ | (LHS/R | Profile | up Sub- | er | Water | Properti | Lengt ir
iE HS) Descripti | Soil | Leve | Coeff. es h of Reference
ge on Properti | {(m) | (Ru) (CR%, Rockf
| es | RQD%, all
GSI, is
| : a RMR) r
| | BH-01 LHS* | Debris | Density: | 2.4m | 0.15 CR: 45% | 24.0m | THDC India Ltd.
| | ॥ km | fe J | 1.95 | belo | [As | RQD: | (Min 3 | Ref:
| 42+200 River | t/m? | w 7 35% | fields | THDC/GEO/2026
| | | ढ़ | Borne | c=4.5 NSL* | IRC:75 | GSI: 40 of 8m) | /04*
| Material | t/m? | Le RMR: 44 | है
। । We (RBM)Y | @ = 32° | | (Fair) * ।
| * For illustration purpose only. Details are to be filled up as per actual project/site specific
i | parameters
[Clause ~ eas HAGE, ds PSL ea Ee ee ae a ee eC 3
6 de Drainage | Roadside Drainage
| | Drainage system = Drainage system including surface and subsurface drains for the Project Highway shall be
surface and subsurface provided as per the provision of relevant Manual.
। drains for the Project ls 30100 % ३
| Highway shall be provided Additional Provision in case of Hill Roads: -
| as per the provision of
| | relevant Manual. The roadside and slope drainage network for hilly terrains shall be designed as a “a
system engineered to prevent surface runoff from infiltrating treated slope configurations or
a causing destructive toe erosion. The drainage layout scope shall explicitly include:
athe ec पाक परम SER oct es ag ca ST ee Pe
Me

<!-- page 8 -->

|... nica Sh 120०0 000
1. Contour / Catch Water Drains (Expert Committee Code G12e): Reinforced ara concrete
drains constructed around the upper periphery of treated slopes to cut off and safely bypass
surface runoff water from entering active construction zones.
| 2. Channelization of Natural Hilly Streams and Nalas (Codes G12a to G12d): All cross-
discharging natural watercourses intersecting the highway alignment must be structurally lined
and channelized using Cement Concrete (CC) channels, anchored CC channels, or high-capacity |
| Gabion Revetment Mattress channels, dimensioned precisely based on the catchment peak |
| | discharge values. |
| | 3. Sub-surface Internal Drainage Networks (Code 6024): Strategic installation of continuous |
horizontal rows of sub-surface Semi-perforated PVC pipes wrapped with non-woven geotextile. |
| These must be oriented specifically to intersect internal water-bearing rock joints, relieving
| | internal hydrostatic pore water pressures within active slope bodies.” |
Migs
a ne SF en 123 Special Requirement foe Gil baa ति:त--7--7_त-त_--  । Z
r Clause | Special Requirement for 12. Special Requirement for Hill Roads:- This section contains the mandatory execution 4
12 Hill Roads: - | requirements, verification Procedure, and muck control site Provisions as per “Expert
| | Committee Report on Cost E, {fective Long Term Remedial Measures for landslide Prone |
| | Areas in Hilly Regions issued by Ministry vide circular No RW/NH-33044/55/2021- |
| | | S&R(P&B) pt/Hill Slope Monitoring dated 28. 11.2024 and Ministry circular No RW/NH-
| | 33044/37/2025-S&R(P&B) dated 07.11.2025’:- |
| | 12.1 Staged Cutting and Stabilization Sequence |
| | To allow excavated hillsides to achieve time-dependent mechanical stability, all highway
construction works in mountainous stretches shall be executed in distinct temporal stages. |
| | The initial contract period of approximately one year shall be restricted strictly to initial
| | formation cutting, slope profiling, and the simultaneous execution of the Corresponding |
| engineered slope stabilization measures. Subsequent sub-base layouts, pavement layer
Construction, and final structural works shall proceed only on those specific subsections |
where both the formation cut and the completed protection measures have remained
Proven stable through at least one full monsoon season.
— eee

<!-- page 9 -->

Lets 10 2 ०2% | eee 10000 20008 102 ck Pe कफ
12.2 Hill Side Excavation and Cutting Methodology
1. Stepped Benching: All major hill cutting activities shall be carried out in a stepped,
terraced, or benched configuration rather than vertical or continuous steep un-benched
cuts, maximizing structural resilience.
| | 2. Top-to-Bottom Execution: Mechanical excavation works must proceed strictly from the
top of the designated cutting profile downward to mitigate localized rotational failure
risks. |
| | 3. Simultaneous Protection: Surficial and structural protection works (including |
shotcreting, drapery netting, and active rock anchoring) must be implemented |
| concurrently alongside the mechanical excavation sequence. |
| 12.3 Pre-Execution Verification and Crack Remediation |
। | Prior to commencing an mechanical excavation or hill cutting, the Contractor shall verify
| | ig any है
the actual site geometry by conducting a high-resolution topographic survey covering a |
| | 300-meter wide strip (150 meters on either side of the existing alignment center) using |
LIDAR or Al-camera fitted UAV drones.
|
| | Any ground tension cracks identified within this 300-meter influence zone must be |
| | mapped, traced, and immediately sealed using stable matching concrete filler materials |
| | to completely prevent the infiltration and percolation of surface rainwater into the
| | underlying subsoil mass. |
| | 12.4 Permanent Geodetic Observation Points |
|
| The Contractor shall construct permanent concrete geodetic observation pedestals on all |
| treated and active slope faces. The exact spatial coordinates of these points must be
regularly surveyed, logged, and monitored throughout the execution period to |
| immediately detect any structural micro-movements or signs of creep within the slope
| mass. |
Table12.1 : Details of Pre-Approved Muck Stacking and Safe Disposal Sites (Details to ।
be provided in following format as per relevant matrix based on Ministry circular
dated 28.11.2024 and dated 07.11.2025 as mentioned in Para 12 above)
we
cn CCCC:i(t;é‘tONCOCt#(C(Uité#C(Uwité#C.UwitétNCO(UitétNO((t((#(ét(i#iéiw#tiw#ti(iéitiéiéitidiwdéiwdaeeeeeeee ree

<!-- page 10 -->

oa SO er le
FEF Chainage Side es ० af =
Site No. | Location (LHS/RHS) Capacity Civil Distance | Restrictions /
(km) (m3) Retention from Environmental
Structures Edge (m) Guardrails
Required |
par DS-01* | km RHs* r Gabion Toe | Toe 60m* Must not
14+800* | m3* | Retention obstruct, alter,
| | | Wall with | | or discharge
| Launching | loose debris
| | | Apronon | | into natural |
| River Bed | valley eo |
| | | | (604 + | or river paths.
| | | GO09)* | | Zero layout |
| | नक्शे कद i | |
* For illustration Purpose only. Details are to be filled up as per actual project/site specific
| Parameters |
|
| | | Table12.2 : Details of Structural Slope Protection and Landslide Mitigation Provision to be |
| | Provided: - (Details to be Provided in following format as Per relevant matrix based on
| | | Ministry circular dated 28.11.2024 and dated 07.11.2025 as mentioned in Para 12 above) |
| 1७७ Peer ree | Primary [3 Field iB Geological Compulsory | Mandatory | न | |
| Stretches Slope | Parameters | Failure / Core ‘Dry’ | Surface / Special
(From/To हे ॥ (Height/Angle) Weathering Slope | Sub- | =
| | km) Type | | Profile Mitigation | Surface | Protections
Measures Water Required
| L | | (Committee Flow | |
| Code) | Additions |
| km | Rock ia aia Wedge Rock ne Contour | Shooting
55+100 to Slope (A02c) Failure Scaling Perimeter | Stones Zone: |
km (Code Angle 60°-75° (CO6a-B) (GO1a), drainage Provision of ।
55+400* A01a)* (A03d)* Anchored channels dynamic
