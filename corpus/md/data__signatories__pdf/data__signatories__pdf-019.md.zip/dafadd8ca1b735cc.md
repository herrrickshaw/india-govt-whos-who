---
doc_id: "dafadd8ca1b735cc"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/F_05Notice_14052026.pdf"
ministry: "Department of Space"
title: "URSC/ PUBLIC TENDER NOTICE NO. F/05/26-27 Dated:12.05.2026      855.14 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "b724b2b7fee70391"
---

<!-- page 1 -->

भारत सरकार, अंतररक्ष तवभाग /Government of India, Department of Space
यू .आर. राव उपग्रह केन्द्र (यू .आर.एस.सी.)/ U R Rao Satellite Centre [URSC]
(पूवि में इसर उपग्रह केन्द्र/ (Formerly known as ISRO Satellite Centre)
एच.ए.एि. एयरप टि र ड, तवमानपुरा प स्ट,
HAL Airport Road, Vimanapura Post,
बें गिूरु/Bengaluru - 560 017
भाित/India

URSC/ PUBLIC TENDER NOTICE NO. F/05/26-27

12.05.2026

भारत के राष्ट्रपतत की ओर से व. प्रधान, क्रय एवं भंडार, यू.आर. राव उपग्रह केन्द्र (यू.आर.एस.सी.),द्वारा तनम्नतिखित मद ं की आपूतति के तिए
केवल ई-प्रापण के जरिए तनतवदाएं आमं तित हैं ।
On behalf of the President of India, Sr. Head, Purchase & Stores, U R Rao Satellite Centre [URSC] invites
tenders ONLY through e-procurement for supply of the following.
दो भाग निनवदा/Two Part Tender
क्रम सं
Sl. No.

01

निनवदा संदभभ
TENDER REFERENCE

संनिप्त नवविण
BRIEF DESCRIPTION

URSC/CE /ICA/2026000416

आईसाइट में ए आई टी-1 व ए आई टी -2 स्वच्छ कि में सी सी टी
वी प्रणाली के नलए सीनमत ए एम सी
Non-Comprehensive AMC for CCTV system of AIT-1 and
AIT-2 cleanroom, ISITE

बोली प्रस्तुत कििे हे तु प्रािं नभक नतनि/Bid Submission Start Date : 13.05.2026 (16.00 Hrs)
बोली स्पष्टी किण की नतनि /Bid Clarification Date up to

: 28.05.2026 (16.00 Hrs)

बोली प्रस्तुत कििे की नियत नतनि/ Bid Submission Due Date

: 03.06.2026 (14.30 Hrs)

बोली खुलिे की नतनि/Bid Opening Date

: 03.06.2026 (15.00 Hrs)

वैध तडतिटि हस्ताक्षर प्रमाणपि (डी.एस.सी) प्राप्त इच्छु क तनतवदाकार https://eproc.isro.gov.in पर िॉग इन करके अपना प्रस्ताव
ऑनिाईन भेि सकते हैं । क ई तनतवदा शुल्क िागू नहीं है ।
Interested Tenderers having valid Digital Signature Certificate [DSC] may login to https://eproc.isro.gov.in and
submit Offers online. No Tender fees applicable.
तनतवदाओं क उपर क्त तनतदि ष्ट् तदनांक पर ि िा िाएगा। अहि तवक्रेताओं के दर ब िी (द भाग तनतवदाओं के मामिे में ) क ि िने की समय
सूची क बाद में सूतचत तकया िाएगा। ब िी िगाने से संबंतधत तववरण क इसर ई-प्रापण प टि ि में िातगन करके दे िा िा सकता है ।
Tenders will be opened on the date specified above. Schedule for opening of the Price Bid (in case of Two Part
Tenders) of Qualified Vendors will be intimated later. Bidding details can be seen by the participated vendors
by logging into ISRO e-procurement portal.
उपर क्त के संबंध में शुखददपि/अनुशेष, यतद क ई ह , त उसे हमारे ई-प टि ि एवं वेबसाइट पर प्रकातशत तकया िाएगा।
Corrigendum/Addendum, if any, related to above shall be hosted in our e- portal and Website.

Sd/व. प्रधाि, क्रय व भंडाि / Sr. Head, Purchase & Stores
