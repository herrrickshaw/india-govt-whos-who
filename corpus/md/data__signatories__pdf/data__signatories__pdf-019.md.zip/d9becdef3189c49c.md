---
doc_id: "d9becdef3189c49c"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/d5198be7cde709e3a01312e5790975e7.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Order dated 14.08.2026 reg. Posting on promotion to the Senior Time Scale (STS) grade of ITS Gr. A"
date: "2026-08-14"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5a9872e280ace716"
---

<!-- page 1 -->

9-1/2026-STG-II

I/3432277/2026

No. 9-1/2026-STG-II
Government of India
Ministry of Communications
Department of Telecommunications
419, Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
Date: 14.08.2026
OFFICE ORDER
Consequent upon their promotion to the Senior Time Scale (STS) grade
vide oﬃce order No. 9-1/2026-STG-II dated 21.05.2026, the oﬃcers already
working in HQ and retained are posted to the units in DoT (HQ) indicated against
their respective names from the date of regular promotion in STS/कायालय आदेश
सं या 9-1/2026-STG-II िदनांक 21.05.2026 के तहत सीिनयर टाइम केल (STS) ेड म पदो त
के प रणाम व प, पहले से ही मु यालय म काम कर रहे और रखे गए अ धका रय को डीओटी
( मु यालय) म उनके नाम के सामने दशाई गई इकाइय म एसटीएस म िनयिमत पदो त क तारीख से
तैनात िकया जाता है:S. Staff Name (S/Sh./Ms.)
Wing/Division of posting in Remarks
No. No.
DoT HQ
21468 Shubham
1
Retained in SRI Divison
Retained
60017 Divya Kumar Singh Retained in IT Division
year only
2
60019 Vivek Krishna Verma Retained in Pers. Wing
3
21472 Laksheswari Kumari Retained in IT Divison
4
Jaiswal
21477 Saurabh Kashyap
5
Retained in AI&DIU Unit
21475
Manishankar
Meena
6
Retained in LP Division
60028 Tabish Jawed
7
Stakeholder Engagement --

for

one

2.
Charge reports may be furnished to all concerned./चाज रपोट सभी संबं धत
यि य को दी जा सकती ह।
3.
This is issued with the approval of the competent authority./यह स म ा धकारी
के अनुमोदन से जारी िकया गया है।

(Bijender Singh)/(िबजे सह)
Under Secretary to the Govt. of India/अवर स चव
Ph. No: 2303-6282
Distribution:

i. PSO to Secretary(T);
ii. PPS to Member(F)/DG(Telecom);
iii. Advisor(O)/Advisor(T)
iv. Additional Secretary(T)/Administrator ,DBN

<!-- page 2 -->

9-1/2026-STG-II

I/3432277/2026

v. Heads of all LSAs;
vi. Sr. DDG (Pers.)/ DDG(C&A)/ DDG(Accounts)/ DDG(IR)/ DDG(SRI)/
DDG(SE)/ DDG(SPPI)/ JS(A)/ DDG(IT)/ DDG(IP)/ DDG(LP)/ DDG(AI&DIU)/,
DoT(Hq.);
vii. DG (NCA-T);
viii. Admn.I-IV/Cash/Pension/Library/G-I/G-II/PFP/PHP/RTI/Vig.I Sec., DoT(Hq);
ix. Pay Bill Section, DoT(Hq.);
x. US(SNG)/ADG(APAR)/AD(STG-I)/AAO(STG-I), DoT(Hq.);
xi. Officers concerned;
xii. PA to US(SGT)- with a request to upload the order on the website;
xiii. Order Bundle;
