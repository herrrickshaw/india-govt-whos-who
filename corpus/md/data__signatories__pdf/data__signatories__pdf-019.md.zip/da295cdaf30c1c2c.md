---
doc_id: "da295cdaf30c1c2c"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/877636768a5006a79d7427b233fb7cb2.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment to the NLD License for Adjusted Gross Revenue"
date: "2021-10-29"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a8f4e198df80447e"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, Ashoka Road, New Delhi-110001
(Carrier Services-III Cell)
No. 10-54/2010-CS-III (Vol. II)

Dated: 28.10.2021

To
All the NLD Licensees (Other than UL)
Subject: Amendment to the NLD License (Other than UL) for Adjusted Gross Revenue
(AGR) - regarding.
In pursuance to Condition 12.1 of the NLD license, the Licensor hereby amends the NLD

license agreement as under:
Amended Clause
Existing Clause
DEFINITIONS AND INTERPRETATIONS DEFINITIONS
AND
as given in Annexure-I
INTERPRETATIONS
as
given
in
Annexure-I
31 .
"REVENUE" for the purpose of
levying LICENCE fee as a percentage of
revenue shall mean the Gross total Revenue
income accruing to the LICENCEE by way of
providing NLD service under the LICENCE
including the revenue on account of
supplementary/value added services and
leasing of infrastructure, interest, dividend etc.
as reduced by the component part of a passthrough nature actually paid to other service
providers
to
whose
networks
the
LICENCEE 's NLD network is interconnected,
for carriage of calls. The Gross Revenue shall
also include previous debits (e.g. bad debts
recovered, of excess provisions m earlier
years.) It is clarified that any lease or rent
charges for hiring of infrastructure shall not be
so deducted. Goods and Service Tax (GST)
collected and passed on to the Government(s)
from customers of the LICENCEE shall not

31. Gross Revenue:
The Gross Revenue shall include all
revenues accruing to the Licensee on account
of goods supplied, services provided, leasing
of infrastructure, use of its resources by
others, application Fee, installation charges,
call charges, late Fees, sale proceeds of
instruments (or any terminal equipment
including accessories), handsets, bandwidth,
mcome from Value Added Services,
supplementary
services,
access
or
interconnection charges, any lease or rent
charges for hiring of infrastructure etc. and
any other miscellaneous items including
interest, dividend etc. without any set off of
related items of expense, etc.
Applicable Gross Revenue (ApGR):
..d)

Page 1of8

<!-- page 2 -->

form a part of the Revenue.

ApGR shall be equal to Gross Revenue (GR)
of the licensee as reduced by the items listed
below:
(i) Revenue from operations other than
telecom activities/ operations.
(ii) Revenue from activities under a
license/ permission issued by Ministry
of Information and Broadcasting.
(iii) Receipts from the USO Fund.
(iv) List of other income* to be excluded
from GR to arrive at ApGR
a. Income from Dividend
b. Income from Interest
c. Capital Gains on account of profit of
Sale of fixed assets and securities
d. Gains from Foreign Exchange rates
fluctuations
e. Income from property rent
f. Insurance claims
g. Bad Debts recovered
h. Excess Provisions written back
*Subject to conditions given in Annexure
D.

Adjusted Gross Revenue (AGR):

.

For the purpose of arriving at the "Adjusted
Gross Revenue (AGR)", following shall be
excluded from the Applicable Gross
Revenue (ApGR):
a. Charges of pass-through nature paid
to other telecom service providers to
whose network, the Licensee's NLD
network is interconnected, for
carriage of calls, and:
b. Goods and Service Tax (GST) paid to
the Government, if the Applicable
Gross Revenue (ApGR) had included
as component of GST .

Page 2 of 8

<!-- page 3 -->

2.
This amendment comes into effect from 01.10.2021 and will be applicable to the
dues which arise from the operations of the Licensee after the said date.
3.
The new Format of Statement of Revenue and License Fee incorporating the effect of
above amendment, is enclosed. It is clarified that the existing format shall also be replaced with
this new format (attached with this amendment) with effect from 01.10.2021.
4.
This amendment shall be part and parcel of the NLD License Agreement and all others
Terms & Conditions shall remain unchanged.

~\
"])

(Pradeep Kumar)
Director (CS-Ill)
For and on behalf of the President of India
Ph. No. 23036348
Copy to:
1.
2.
3.
4.

Secretary (TRAI).
DGT, DoT (HQ)/CGCA.
Advisor (Economics)/ Wireless Advisor/ Sr. DDG (TEC).
DDG(AS)/DDG(DS)/DDG(Satellite)/DDG (LFP)/ DDG (LFA)/ DDG (SPPI)/ DDG(SA)/
DDG(WPF)/ DDG(A/C) for kind information please.
5. Director (IT) may kindly arrange to upload this letter on the website of DoT.

Page 3 of 8

<!-- page 4 -->

ANNEXURE-D to the National Long Distance Service License Agreement
List of other income to be excluded from GR to arrive at ApGR
SL
No.
a.

b.

Item/ Head ·of Description and conditions applicable
'Other Income'
from Income from dividend is return on investment made by the company.
Income
Such investment is made out of surplus funds available with the
Dividend
company. Companies Act, 2013 and Accounting Standard-9
classified dividend income as 'other income' i.e., distinct from the
core operations of the entity.

Income
Interest

from

Therefore, income from dividend shall not be part of ApGR for the
purpose of computation of LF .
Income from interest is return on investment made by the company in
bank deposits, corporate deposits, debentures etc. Such investment is
made out of surplus funds available with the company. Also
sometimes, Licensee receives interest from Tax Authorities on
advance tax or refundable tax. Companies Act, 2013 and Accounting
Standard-9 classified interest income as 'other income' i.e., distinct
from the core operations of the entity.
At the same time, Licensee accepts refundable deposits from
customers, telecom vendors and other Licensees. These deposits
essentially are part of telecom operations. The interest income earned
on such amounts should be recorded and certified by statutory
auditors.

c.

Capital gams on
account of profit
on sale of fixed
and
assets
securities

d.

from
Gains
Foreign Exchange
rates fluctuations

Therefore, income from interest shall not be part of ApGR for the
purpose of computation of LF. However, interest earned on
refundable deposits from customers, telecom vendors and other
Licensees shall be considered m ApGR for the purpose of
computation of LF. Also, any refundable deposit received by the
Licensee on the strength of telecom service viz. linkage with tariff,
advance rental etc. shall also have similar treatment for inclusion in
ApGR.
Capital gain earned by the Licensee on the account of profit on sale
of assets and securities, are of from investing activities instead of
from telecom operations. Therefore, the revenue on account of sale of
immovable property, securities, warrants or debt instruments, other
items of fixed assets shall not be part of ApGR for the purpose of
computation of LF.
Foreign Exchange differences arise when actual rates at the time of
settlement differs from those at which they were initially recorded in
the books. The provisions contained in the Accounting Standard-I I
Page 4 of 8

<!-- page 5 -->

require a notional entry for exchange differences in respect of
liabilities at the closing date of the AFSs. The foreign exchange gains
reflected in the profit and loss statement of Licensee could arise from
reduction of payment liability or increase in the value of foreign
exchange accounts receivables. In other words, foreign exchange
fluctuation is a contingency -which has impact on every business
which may have something to do with foreign exchange and is not
specific and unique to telecom business.

e.

f.

g.

h.

Therefore, revenue/profit ansmg out of upward valuation or
devaluation on account of fluctuation of foreign exchange shall not
be part of ApGR for the purpose of computation ofLF.
Income
from Licensee may rent or lease part of their properties and earn revenue
property rent
in the form of rent. Some Licensees as part of staff welfare measure
provides staff quarters to their employees and receive rent from such
staff. Revenue from rent cannot be distinctly treated as only from
telecom business. Therefore, revenue/income from property rent shall
not be part of ApGR for the purpose of computation of LF. In case
property is let out for 'establishing, maintaining and working of
telecommunication' , then revenue/income from such rent shall be
considered in ApGR for the purpose of computation of LF.
Insurance claims
A receipt from Insurance company against loss of property/fixed
assets is basically a reimbursement in nature for the loss occurred by
the Licensee. Receipt of insurance claim from insurance company
shall not be part of ApGR for the purpose of computation ofLF.
Bad
Debts Bad debt is an amount owed by a debtor that is unlikely to be
recovered
received/ realized and recognized as an expense in the books of
accounts. Bad Debts recovered represents reversal of debits (i.e. bad
debts) appearing in the profit and loss account of previous year(s).
This basically represents an adjustment to the amount of an expense
(i.e. bad debts) as estimated in an earlier year(s) in which it had
already recorded as part of revenue from operations.
Therefore, income on account of bad debts recovered shall not be
part of ApGR for the purpose of computation ofLF.
Excess Provisions Excess Provisions written back represent the reversal of excess
written back
provision made for any liability or expenses in any previous year. On
settlement, this excess provision is written back into books of
accounts as other income. This basically represents an adjustment 60
instead of actual revenue earned.
Therefore, income on account of excess provisions written back shall
not be part of ApGR for the purpose of computation of LF.
Page 5 of 8

<!-- page 6 -->

National Long Distance Service License
ANNEXURE-A

S.N.

Format of Statement of Revenue and License Fee
............... (Name and address of OPERATOR)
National Long Distance Service License No............ .
Statement of revenue and License Fee
for the Quarter ...........of the financial year .......... ..
(AMOUNT IN RUPEES)
CUMULATIVE
ESTIMATE
PARTICULARS
ACTUALS
THE
FOR
THE D FOR THE UPTO
PREVIOUS
PREVIOUS
CURRENT
QUARTER
QUARTER
QUARTER

1.

Revenue from Services:

1.

Revenue from provisioning of
NLD service
Revenue
from
supplementary/value
added
services.

11.

...
111.

lV.

l(a)
(i)

Goods and Service Tax (GST)
Any
other
income/
miscellaneous receipt.

(iii)

Revenue from calling cards
Revenue from sale of calling
cards
Any
other
income/Miscellaneous receipt
from Calling Cards
Goods and Service Tax (GST)

2.

Income from investments.

1.

...

Interest income
Dividend income
Any
other
miscellaneous
receipt from investments.

3.

Non-refundable deposits.

4.

Revenue

(ii)

11.

111.

from

~

Page 6 of 8

<!-- page 7 -->

sharing/leasing
infrastructure

of

other

5.

Revenue
from
Operations/Activities other
than Telecom Operations/
Activities as well as revenue
from activities under a
license from Ministry of
Information
and
Broadcasting

6.

Miscellaneous revenue

AA

GROSS REVENUE OF THE
COMPANY: (ADD 1-6)

BB

Vlll.

LESS
Revenue from operations other
than
telecom
activities/
operations
Revenue from activities under
a license from Ministry of
Information and Broadcasting
Receipt from USO Fund
Items of 'Other Income' as
listed in Annexure- VIII
Income from Dividend
Income from Interest
Capital Gains on account of
profit of Sale of fixed assets
and securities
Gains from Foreign Exchange
rates fluctuations
Income from property rent
Insurance claims
Bad Debts recovered
Excess Provisions written back

BB

Total (1+2+3+4)

1.

2.

3.
4.
l.
11.

...
111.

IV.

v.
Vl.
Vll.

...

-

1\

~

Page 7 of 8

<!-- page 8 -->

cc

APPLICABLE
GROSS
REVENUE (ApGR) (AA­
BB)

DD

DEDUCT:
Revenue of pass through
nature passed on to other
service
providers. (operator­
wise details).
Note: Lease/rent charges for
hiring of infrastructure not to
be deducted.
Revenue of pass through
nature passed on . to other
telecom service providers for
usage of Calling cards at the
originating point (Operator­
wise detail)
Revenue of pass through
nature passed on to other
telecom service providers for
usage of Calling Cards at the
terminating Point (operator­
wise detail)
Goods and Service Tax (GST)
paid to the Government.
TOTAL
DEDUCTIBLE
REVENUE (1+2)

1

l(a)

I

l(b)

2.
DD

EE

ADJUSTED
GROSS
REVENUE (CC-DD)
REVENUE SHARE @ ------­
---------­ OF ADJUSTED
GROSS REVENUE

~

Page 8 of 8
