---
doc_id: "dd3ede3dd4c532a4"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/d76d234bda17e98a7ee7601440092120.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Regular Promotion and Transfer & Posting in SAG of P&T BWS Group A Electrical-reg."
date: "2024-08-21"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a287745e9f4132ca"
---

<!-- page 1 -->

No. 6-1/2014-EW
Government of India
Ministry of Communications
Department of Telecommunications
(A&E Section)

618-A, Mahanagar Doorsanchar Bhawan
Jawahar Lal Nehru Marg, New Delhi - 110 002

Dated: 21.08.2024
ORDER
The President is pleased to promote the following officer of P&T Building
Works
Service (Group-A) to the Senior Administrative Grade of the same service
in the Pay
Level 14 of 7"CPC on regular basis with effect from the date of assumption
of charge in
higher grade and post by the officer as indicated below:
Name of the Officer & Staff No[

Shri Sanjay Gupta, 96532

Present
Posting

Posting on promotion

Director
(Electrical),

Department
of
Posts
as
Chief
| Engineer (Electrical) against post

Delhi LSA

| transferred

vide

DoT

Order

No

02/2024-EW dated 21.08.2024.
2.

The above promotion

24-

order is being issued after obtaining the vigilance clearance

from the Vigilance branch, DoT and DoP. However, in case it comes to the notice of
the
controlling Authority that any disciplinary case is pending or any penalty is in operation
against the officer, the concerned officer should not be promoted without obtaining the
specific approval of this Department. Information in this regard may be brought to
the
notice of this Department forthwith.
3.
Further, the following transfer & postings of P&T BWS Group ‘A’ (Electrical) Officers
in SAG is hereby ordered with immediate effect and until further orders:
Name
of
the|
PresentPosting
Officer & Staff No.
"Shri Amar Relan,(DDG (Electrical)
96529
MaharashtraLSA

[Posting on transfer

Remarks

[ DDG
(Electrical) [Transfer at own
cost
[ O/o DG(T), New |against existing vacancy.

Delhi

*He will also look after the works of DDG

till further orders.

(IM), NTIPRIT without any extra remuneration

4.
Shri Sanjay Gupta has already been granted non-functional upgradation in SAG
(Level-14), hence his pay need not be fixed again.
Page 1 of 2

<!-- page 2 -->

5.

Charge report may be furnished to all concemed. Hindi version will follow.

(Awadﬁéﬁ%rmﬁq

Director (Electrical)

Ph:011-23258925
Copy to:

PS to MoC/ PS to MoSC

©

ONOARON

Secretary (Posts)
PS to Secretary (T)
. Member (S)/ Member (T) / Member (F), Digital Communications Commission

Secretary, UPSC w.r.t. letter no. F.1/34(06)/2024-PD-6 dated 30.05.2024

Director General Telecom, DoT Hq.

Heads of Delhi LSA, Maharashtra LSA

Additional Director General (Coordination), PSB, Department of Posts

Sr. DDG (BW)/DG (NTIPRIT)/DDG (Estt)

10 Chief Engineer (Civil)-1&ll, Department of Posts
11. Director (Civil)/ Director (Architecture)
12. Officers concerned.
13.80(0L), DoT for Hindi version
14. Director (EW) — for uploading on DoT website

15. Order bundle.

Page 2 of 2
