---
doc_id: "da03bf70e65dea0b"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/982ad6f89961d6d9c7c20905f5c406da.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "AU IP Policy 2021 created & implemented by DPIIT IPR Chair"
date: "2025-07-14"
pages: 53
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ea3340f1e634adcb"
---

<!-- page 1 -->

IP Policy of Andhra University

Intellectual Property Policy of
Andhra University, 2021

<!-- page 2 -->

IP Policy of Andhra University

<!-- page 3 -->

IP Policy of Andhra University

<!-- page 4 -->

IP Policy of Andhra University

<!-- page 5 -->

IP Policy of Andhra University

<!-- page 6 -->

IP Policy of Andhra University

<!-- page 7 -->

IP Policy of Andhra University

<!-- page 8 -->

IP Policy of Andhra University

<!-- page 9 -->

IP Policy of Andhra University

<!-- page 10 -->

IP Policy of Andhra University

<!-- page 11 -->

IP Policy of Andhra University

<!-- page 12 -->

IP Policy of Andhra University

<!-- page 13 -->

IP Policy of Andhra University

<!-- page 14 -->

IP Policy of Andhra University

<!-- page 15 -->

IP Policy of Andhra University

Members of the IP Committee Involved in drafting the IP Policy

1. Dr. H Purushotham, DPIIT-IPR Chair Professor, Centre for IPR, Andhra University
2. Dr. Anindya Roy Chowdhury, Research Officer, Centre for IPR, Andhra University
3. Mr. Ravi Teja Chittipottu, Research Assistant, Centre for IPR, Andhra University

<!-- page 16 -->

IP Policy of Andhra University

<!-- page 17 -->

IP Policy of Andhra University

Table of Contents
1.

PREAMBLE

19

1a) Need for IP Policy

19

1b) Scope of IP Policy

20

1c) Right to amend the IP Policy

20

1d) Acknowledgement

20

2.

DEFINITION

21

3.

OWNERSHIP OF INTELLECTUAL PROPERTY

24

a) Patents

25

b) Copyright

25

c) Trademarks

25

d) Industrial Designs, Semiconductor Integrated Circuits, and Plant Varieties

26

3A. IP generated from research conducted in collaboration with external partners

26

4.

26

EVALUATION AND MANAGEMENT OF IP

a) Centre for Intellectual Property Right (CIPR)

26

b) University IP Advisory Committee

28

c) IP Appellate Authority

28

5.

28

REGISTRATION OF IP

a) IP filing procedure from the university

29

b) Filing of application in India

30

c) Filing of application in foreign countries

30

6.

RENEWAL OF PATENTS

30

7.

LICENSING OF IP

31

8.

REVENUE SHARING

31

9.

ENCOURAGING ENTREPRENEURSHIP AND STARTUP

31

<!-- page 18 -->

IP Policy of Andhra University

10.

HOLDING EQUITY IN START-UPS/ACADEMIC SPINOFFS

31

11.

INCENTIVES FOR INVENTORS

32

12.

RESEARCH ETHICS AND INTEGRITY

32

13.

IP EDUCATION, AWARENESS, AND TRAINING PROGRAM

32

14.

CONFIDENTIALITY, DATA PROTECTION, AND PRIVACY

33

15.

INFRINGEMENTS, DAMAGES, LIABILITY, AND INDEMNITY

33

16.

CONFLICT OF INTEREST

33

17.

AGREEMENTS AND CONTRACTS

33

18.

DISPUTE RESOLUTION

34

19.

JURISDICTION

34

ANNEXURE I: IP AGREEMENT FORM

35

ANNEXURE II: INVENTION DISCLOSURE FORM

37

ANNEXURE III: FEE STRUCTURE FOR COMPLETE PATENT LIFECYCLE PAYABLE AT INDIAN PATENT
OFFICE
39

<!-- page 19 -->

IP Policy of Andhra University

1. Preamble
Andhra University is one of the oldest and prestigious multidisciplinary universities in the
country. Since its foundation in 1926, it has a proven track record of meeting educational
demands and resolving regional sociological issues. The university has a vision to create new
frontiers of knowledge in quest for developing a humane and just society. It is therefore
necessary that the knowledge generated in the university can be translated into Intellectual
Property Rights (IPR) of the stakeholders. Hence, it is required to develop an IP policy for
making the inventions made in the university available to the public while providing adequate
safety to the IPR. Further, it is important to bring in an efficient IPR management practice
within the university system to promote the IPR culture.

1a) Need for IP Policy
Innovation is the main key for every economy to grow. Academic and research institutes are
the primary hub of innovative minds in a country. In this era of the knowledge economy, the
innovations generated in such institutes must be protected. The agreement on Trade Related
Aspect of Intellectual Property Rights (TRIPS) in 1995 is one of the most comprehensive
multilateral agreements on IPR. According to the World Intellectual Property Organization
(WIPO), an IP policy provides structure, predictability, and a beneficial environment in which
universities and researchers can access and share knowledge, technology, and IP. All the top
universities in the world manage and protect their IPs through efficient IP policies. Although
India ranks 4th based on the journal publications according to the 2019 SCIMAGO journal and
country rank, it ranks only 46th in the Global Innovation Index 2021. The Government of India
brought out the National IPR Policy in 2016. One of the Policy's key goals is to promote and
develop IPR in academic and research institutions in order to facilitate the creation and use of
IPR for the benefit of the general public. In the coming decade, the Science, Technology, and
Innovation Policy (STIP) aspires to attain technological self-sufficiency and place India among
the top three scientific superpowers. The COVID-19 pandemic has presented a compelling
opportunity for academics and industry to collaborate. Andhra University's IP policy strives to
achieve the university's vision and mission by aligning itself with existing science and
technology policies of India. The policy will promote technology self-reliance and
indigenization to achieve the larger goal of “Atmanirbhar Bharat”.

19

<!-- page 20 -->

IP Policy of Andhra University

1b) Scope of IP Policy
This Intellectual Property Policy Document (hereinafter referred to as the “Policy”) is intended
to provide guidance for academic and non-academic staff (both temporary and permanent),
students (undergraduate, postgraduate, and research scholars), startup companies generating
IPs at the university incubation center, and outside sponsors on the practices and rules of the
Andhra University, Visakhapatnam, Andhra Pradesh, India (hereinafter referred to as “the
university”) regarding IPRs and obligations thereunder including intellectual property
ownership, protection process, exploitation, technology transfer, and revenue sharing. This
policy addresses intellectual property issues in order to protect academic freedom, gives a fair
part of the benefits to intellectual property creators, supports research, technology transfer, and
material benefit from intellectual property generation. This policy is to be read as
complementary to and not in derogation of the various laws concerning Intellectual Property
and any other law, for the time being in force, in India. The policy shall be implemented by the
Centre for Intellectual property rights (CIPR) of the university and is to be followed in all
matters related to IPR in the university.

1c) Right to amend the IP Policy
The IP Advisory Committee of the university (See Clause 4b) shall have the responsibility for
interpreting the policy and recommending changes to the policy from time to time to the
Academic Senate. The Senate shall consider such changes/recommendations and take such
decision thereon as it deems fit. The IPR Policy may be amended by the university from time
to time as and when needed.

1d) Acknowledgement
The provisions of this policy are broadly based on the model guidelines on implementation of
IPR policy in Academic Institution, issued by the Cell for IPR Promotion & Management
(CIPAM), a professional body under the aegis of Department for Promotion of Industry and
Internal Trade (DPIIT); and the best practices from premier academic institutions in India like
IIT Kharagpur, IIT Delhi, IIT Bombay, etc.

20

<!-- page 21 -->

IP Policy of Andhra University

2. Definition
a) Academic Freedom: The freedom of academic staff of the university to pursue their
academic activities, choose their research field, pursue self-directed research, and collaborate
and communicate with others regarding their scholarly efforts adhering to the university’s
academic mission.

b) Creator(s): “Creator(s)” refers to an individual or a group of individuals of the university,
who make, conceive, reduce to practice, author, or otherwise make a substantial intellectual
contribution to the creation of any intellectual property. “Creator(s)” includes an “inventor” in
the case of inventions under Patent Law, an “author” in the case of works falling under the
Industrial Designs Law and/or Copyright Law.

c) Fair use: Fair use is defined as the amount of copying permitted by law in order for copyright
to not obstruct the advancement of human knowledge. The possibility of fair use exists only in
the case of copyright. Fair use in the classroom during regular teaching is understood more
liberally than that permissible in teaching for distance education multimedia packages. Because
distance education packages are commercial products, authorization to use any intellectual
property owned by others that may be quoted or reproduced in the package must be obtained.

d) Intellectual Property: Intellectual property means any property generated out of the
intellectual effort of the creator(s). The following are examples of intellectual property.
i)

Patent is an exclusive right granted for an invention, which is a product or a process that
gives a new technical solution to a problem or a new way of doing something.

ii)

Copyright is an exclusive right given to the author for models, engineering drawings,
computer software, animations and visualizations, information technology processes,
original innovative or creative literary works, works of graphic or plastic art and
cinematographic and animated films, teaching material for classroom and online
courses such as courseware for distance education, original data and records of research,
and undisclosed and/or unpublished information, etc. In the case of copyrightable
works, it must be fixed in a tangible form, and the creator(s) or rights-holder is
empowered by law to prevent others from copying this form.

iii)

Trademarks are distinctive words or graphic symbols or logos or a combination thereof,
identifying the university as associated with, or as a source of, a product; or as a
producer and/or distributor of goods or services. The use regulated by this policy refers
21

<!-- page 22 -->

IP Policy of Andhra University

to the identification, statement, or display of the university name, insignia, logo in any
way that can reasonably be interpreted as implying endorsement, approval or
sponsorship by the university or its officials.
iv)

Industrial design means shapes, configurations, patterns, ornaments, or compositions of
lines or colors applied to any article, whether in two dimensional, three dimensional, or
both forms, by any industrial process or means, whether manual, mechanical, or
chemical, separate or combined, which in the finished article appeal to and are judged
solely by the eye; but does not include any mode or principle.

v)

Semiconductor IC layout design means the representation of an integrated circuit in
terms of planar geometric shapes.

vi)

Plant variety means a variety of plant species that is novel, distinct, uniform and stable
characteristics.

vii)

Geographical indication is an indication of agricultural goods and natural goods that are
originating or manufactured in the territory of a country or a region or locality in that
territory where a given quality, reputation, or other characteristic of such goods is
essentially attributable to its geographical origin.

viii)

Trade secret can consist of any processes, methods, equipment, technical information,
etc. which gives a competitive edge. For example, Coca-Cola has protected its secret
formula for over 100 years via trade secret. Three key factors define a trade secret:
•

not a common knowledge to competitors

•

gives an economic edge to its holder

•

the holder makes a reasonable effort to maintain the secrecy

e) Individual scholarships, fellowships, and grants: No individual scholarship, fellowship
or training grant tenable at the university shall contain any provision giving the awarding
agency any right to intellectual property created by the recipient.

f) Sponsored research: For the purposes of this policy, a specific research project funded by
an outside entity, whether non-profit or for-profit, governmental or private, national or
international, shall be considered "sponsored research." Funds provided by an external entity
to a student, scholar, fellow, or trainee for the support of education or research are not
considered "sponsored research".

22

<!-- page 23 -->

IP Policy of Andhra University

g) Usual university resources: Usual university resources mean facilities such as office space,
standard laboratory facilities, library, normal access to software, computers and networks,
standard secretarial services, salary, and perquisites.

h) University-supported resources: University-supported resources mean special facilities
and equipment, specific funding, the intellectual property already owned by the university,
requisitioning the time and labor of students and staff through university administrative
channels, or at the university’s instance and expense, and remission by the university of any or
all of the normal duties of staff or students to provide time or resources to generate intellectual
property.
The Departmental Administrative Committee is responsible for evaluating cases of resource
use for intellectual property generation and determining if considerable use of universitysupported resources has occurred. When the creator(s) believes their work will need more than
the typical usage of university resources, they must tell their Departmental Administrative
Committee. The following university resources, in particular, will be considered universitysupported resources under this policy.
i)

Financial support provided by the university over and above the regular salary/perks as
per employment/enrolment/sponsorship contract or over and above the scholarship
provided to students/research scholars.

Exception: honor fellowships, awards, prizes, grants, assistantships and scholarships, and
facilities built up with such funds, shall not constitute university-supported resources. Use of
infrastructure developed by creator(s) using their own funds, like their own earnings through
consultancy, royalty proceeds, etc. shall not constitute use of university-supported resources.
ii)

Funds provided by the university to secure, maintain and enforce rights in intellectual
property;

iii)

Funds specifically provided by the university to the creator(s)s to scale up or reduce to
practice a particular patentable intellectual property;

iv)

Funds provided to commercialize and/or exploit intellectual property;

v)

Sponsored research grants or contracts as per the terms of the contract;

vi)

Substantial funding by the university for the printing of books to be decided by the IPR
Committee on a case-by-case basis;
23

<!-- page 24 -->

IP Policy of Andhra University

vii)

Intellectual Property Resources;

viii)

Pre-existing intellectual property owned by the university;

ix)

Explicit use of the name, insignia, logo, or trademark of the university in the creation

and vending of intellectual property. However, a statement of affiliation by academic staff
constitutes legitimate self-representation and shall be regarded as the use of usual university
resources.

i) University confidential information: University confidential information means trade secrets,
technical know-how, confidential data and related information about intellectual property owned
by the university.

j) Work for hire: Work for hire is defined as any work commissioned by the university from a
creator(s) or an external agency. In all such cases, the ownership of the resulting intellectual
property shall be assigned to the university in a written contract between the parties concerned.

3. Ownership of Intellectual Property
This policy, as amended from time to time, shall be deemed to be a part of the university's
conditions of employment for all employees and a part of the university's conditions of enrolment
for students, and shall be made available to staff prior to appointment, students upon enrolment,
(See Annexure I).
It is also the policy of the university that all potential creators who participate in a sponsored
research project and/or make use of Institute-supported resources shall be informed of this policy
and shall accept the principles of ownership of intellectual property as stated in this policy unless
an exception is approved in writing by the university.
The university shall explicitly mention in the appointment order of all university personnel that
the IP generated by them during the employment tenure shall belong to the university regardless
of the source of funding, if any. All the academic and non-academic employees, and research
scholars shall sign this agreement (See Annexure I).
The IPs filed by or granted to university individuals, during the tenure of their association with
Andhra University and before the implementation of this policy, shall be reassigned to the name
of the university.

24

<!-- page 25 -->

IP Policy of Andhra University

a) Patents
i. The ownership of all inventions, whether generated by student, research scholar, or faculty
(in fulfilment of their obligations with the university), developed using university resources, or
developed using a combination of university finances, resources, and/or facilities, shall remain
with the university.
ii. If the university determines that an invention was created by an individual(s) on his or her
own time, unassociated to his or her commitments to the university, and was conceived or put
into practice without the use of university resources, the university shall vest the invention in
the individual(s)/inventor (s).

b) Copyright
i. The ownership rights in scholarly and academic works generated utilizing resources of the
university, including books, articles, student projects/dissertations/ theses, lecture notes, audio
or visual aids for giving lectures shall ordinarily be vested with the author(s).
ii. The ownership rights in lecture videos or Massive Open Online Courses (MOOCs), films,
plays, and musical works, university materials including, but not limited to, course syllabi,
curricula, exam questions, exam instructions, and papers/ reports specifically commissioned by
the university, shall ordinarily be vested with the university. The moral rights shall continue to
vest with the author(s) wherever applicable.
iii. Any publication and/or document arising out of research activities shall be owned jointly
by the university and researcher(s). The use of name, logo and/ or official emblem of the
university shall not be done without prior written permission from the university.
iv. Particular care needs to be taken that no publication is made till the patent, if applicable, is
filed.
The university shall be entitled to a non-exclusive, non-transferable license to use the work
within the university for non-commercial educational and research purposes. Any
copyrightable work generated as work for hire shall belong to the university as per the terms
of the original contract.

c) Trademarks
i. The ownership rights in all trademarks involving the university shall ordinarily be vested
with the university.

25

<!-- page 26 -->

IP Policy of Andhra University

ii. If the university determines that the creator of the trademark was created by an individual(s)
on his/ her own time and unrelated to his/ her responsibilities [e.g., name of a company/ startup venture by the student(s)], then the right to the same shall ordinarily be vested with the said
individual(s).

d) Industrial Designs, Semiconductor Integrated Circuits, and Plant Varieties
i. All Industrial designs, Semiconductor integrated circuits, and Plant variety whether created
by student/ researcher/ faculty (in furtherance of their responsibilities with the university)
developed by utilizing the resources of the university, or with the mix of funds, resources,
and/or facilities of the university, shall ordinarily be vested with the university.
ii. If the university determines that the industrial design was created by an individual(s) on
his/her own time and unrelated to his/her responsibilities towards the university and was
conceived or reduced to practice without the use of resources of the university, then the
industrial design shall vest with the individual(s).

3A. IP generated from research conducted in collaboration with external partners
Ownership of IP for research undertaken in collaboration with external partners will be established
according to the terms and conditions of the agreement signed between the parties. Unless
otherwise specified, the university shall generally retain a perpetual, royalty-free right to utilize
the IP for research and educational purposes.
The university shall ensure that the IP ownership clause is included in the agreement with parties
for collaborative projects.

4. Evaluation and Management of IP
The Centre for IPR of the university is responsible for evaluating, protecting, marketing, licensing,
and managing IPs generated in the university. An IP centre of a university is known as the IPM Cell
in some places, and the Technology Transfer Office or the Technology Licensing Office in the
western countries.

a) Centre for Intellectual Property Right (CIPR)
The IPR Chair has been granted to Andhra University by the Department for Promotion of
Industry and Internal Trade (DPIIT), Ministry of Commerce and Industry, Government of India,
under the Scheme for Pedagogy and Research in IPRs for Holistic Education and Academia
(SPRIHA). Leveraging the expertise available with DPIIT-IPR Chair, the university has
26

<!-- page 27 -->

IP Policy of Andhra University

established the Centre for IPR. The broad objectives of the CIPR are as under.
Vision: To create a vibrant and sustainable IP ecosystem in the university
Mission: To serve and support university researchers in the transfer of research findings from
university to industry for commercial exploitation, consumer development, and public benefit
Objectives of IPR Chair
1. To introduce IPR as a credit course at the undergraduate level in the university
2. To introduce postgraduate degree/diploma courses on IPR
3. To introduce exclusive curricula on IPR for doctoral and post-doctoral studies
4. To introduce certificate course/distance learning course/online courses on IPR
5. To set up a repository for IPR-related information and case studies at the university
6. To manage the IP portfolio of the university and facilitate the filing of IPR applications
and coordinate with the patent agent/attorney
7. To facilitate IP commercialization
Functions of CIPR:
i)

Educating university staff and students the concepts of IP law and procedure for securing
intellectual property rights. This includes teaching the IPR course in the university and
organizing capacity building programs/workshops/awareness programs

ii)

Promoting and encouraging IP generation

iii)

Contracting with professionals such as, IP lawyers, patent agents, search providers to
outsource one or more of these operations; paying and honoring their invoices and bill
as per contracted terms and tariffs.

iv)

Taking responsibility of the administrative and the financial aspects of running the CIPR

v)

Mediating between industry and the institute

vi)

Facilitating technology transfer, including licensing or assigning or selling IP in India
and abroad

vii)

Maintaining and managing the records of IPs filed by the university because IPs that
require registration also require constant renewal

viii)

Although academic institutions generate not only patents but copyright, designs,
trademark and new plant varieties. The quantity and quality of patents they file for will
secure the university ranking under various ranking frameworks. Therefore, it is the

27

<!-- page 28 -->

IP Policy of Andhra University

function of CIPR to educate and motivate faculty and students to file more number of
patent applications.

b) University IP Advisory Committee
The university shall set up an IP advisory committee. The committee shall be chaired by the ViceChancellor. The Registrar shall be the convenor. DPIIT-IPR Chair, Dean R&D, and the Principal
of B. R. Ambedkar Law College shall be the member of the committee. Also, there shall be expert
members from the Govt and industry in the area of IP. and nominated Ex-officio members. ViceChancellor/Registrar can nominate additional members if required.

Terms of reference:
i.

The tenure of the advisory committee shall be 3 years.

ii.

The committee shall guide, mentor, and review the progress of the activities of DPIIT-IPR

Chair, Centre for IPR, Andhra University from time to time.
iii.

The advisory committee shall meet twice in a year.

iv.

The committee members shall be paid TA/DA as per university norms and honorarium @

₹2000 (Rupees two thousand only) as a sitting allowance.
v.

Expenditure shall be met from the DPIIT-IPR Chair grants-in-aid as per sanction order.

c) IP Appellate Authority
The Registrar of the university is the appellate authority in resolving any issues arising out of the
implementation of IP policy of the university. The appeal shall be disposed of within one month
from the date of receiving the appeal.

5. Registration of IP
The university shall make it mandatory for all research scholars from applied science and
engineering departments to file at least one IP (Patent, Design, IC layout, and Copyright)
application during their association with the university. The university shall bear the filing cost.
The creator(s) of the IP shall disclose all the information to CIPR by submitting the invention
disclosure form (IDF) to enable them to decide whether the university wants to own the IP or not
(See Annexure II). An invention shall typically be patented by the university if it has commercial
potential. If the university does not wish to own the IP, it shall permit the inventors to file for their
own IP. However, the revenue generated by such IPs shall be shared by the university as stated in
28

<!-- page 29 -->

IP Policy of Andhra University

the ‘revenue sharing’ section.
In the case of patentable IP, it is essential that patent application has been filed before academic
publication or any kind of disclosure to the public. In the case of a sponsor project, if the sponsor
wishes to manage the filing of patents and bearing the cost, the creator(s) shall inform CIPR about
the same. The creator(s) shall also inform CIPR about the status of that application from time to
time.

a) IP filing procedure from the university
1. The student/Research scholar/faculty member shall have to submit the invention disclosure form
(IDF) about his/her invention in the prescribed format to CIPR. IDF can be obtained from the CIPR
office.
2.

After submitting the IDF, the creator(s) and the stakeholders involved in the process shall

maintain confidentiality i.e., refrain from disclosing the details to third party, unless authorized in
writing by the university.
3.

Based on the IDF received, CIPR along with the patent agent/attorney approved by the

university in consultation with the inventors shall carry out a prior art search and patentability
assessment.
4.

Once the invention meets the patentability criteria, based on the stage of the technology of

invention, a provisional specification or complete specification of the patent application would be
drafted by the patent agent/attorney.
5.

The patent filing shall be done by the patent agent/attorney on behalf of the inventor and the

university.
6.

All the necessary application forms for filing the IPR will be signed by the Registrar as

applicant (Andhra University), and the inventors of Andhra University.
7.

Once the patent application is filed, CIPR shall inform the inventor /HOD / Principal /

Registrar/VC along with the filed patent application number.
8.

At all stages of the process, the creators must maintain complete transparency in exchanging

information with CIPR. The creators must keep CIPR up to date on any development/modification
of the intellectual property.
9.

The CIPR is responsible for coordinating with the inventors/University authorities/Patent

agents/attorneys and manage the entire IP including prosecution, maintenance and
commercialization of the created IP.
10.

IP prosecution and commercialization is a complex and lengthy process but brings name
29

<!-- page 30 -->

IP Policy of Andhra University

and fame to the University. It is hereby informed that all students/research scholars/ faculty
members shall be given required guidance from CIPR to facilitate protection of the IPs created by
the University research and advancements.
As the main IP generated by a university is patent, only the patent filing process has been mentioned
above. In case, there is a need to file other types of IPs, similar process will be followed, i.e.,
conducting search etc.

b) Filing of application in India
It is strongly advised that the creator(s) file a provisional patent application as soon as possible. If
the creator(s) can afford to file a provisional patent application, authorization to file will be granted
automatically before the application is evaluated by CIPR. In such circumstances, the creator(s)
are exempt from disclosing the invention's specifics to CIPR at this time. If the institution chooses
not to manage the IP, the creator(s) must take the necessary measures to file a complete
specification within 12 months. In such cases, the university shall waive off its ownership right
for that IP. If the university decides to own the IP, the cost for provisional patent filing shall be
reimbursed to the inventor(s).

c) Filing of application in foreign countries
The university may consider the request to file a patent application outside India depending on the
merit of the IP. If the university decides not to file an application outside India, then it shall assign
the right for that IP in that country to the creator(s) and permit the creator(s) to protect the IP in
that country on their own or with a sponsor. Any revenue generated out of that IP shall be subject
to the rules of revenue sharing with the university.

6. Renewal of Patents
The university shall pay the renewal fees of a patent for the first seven years (Please refer to
Annexure III for complete fee structure payable at Indian Patent Office). If the patent has been
commercially exploited within the first seven years, then the university shall pay the renewal fees
for the remaining thirteen years of the patent validity from the revenue generated out of licensing
and royalty. If the patent has not been commercialized within the first seven years, then the
university and the creator shall share the renewal fees on a 50:50 basis. If creator(s) are not
interested to renew the patent, then the university shall decide whether to pay the renewal fees or
withdraw the application. If the patent is jointly owned by the university and other sponsor(s), the
patenting cost shall be equally shared.
30

<!-- page 31 -->

IP Policy of Andhra University

7. Licensing of IP
The university may, either through CIPR or its agents or creator(s), approach external agencies
for licensing out IP owned by it. The priority shall be given to domestic manufacturer(s) or
MSME(s). The right of first refusal (ROFR) shall stay with the inventors. All agreements shall be
signed by the Registrar on behalf of the university. The creators of an IP shall sign a revenuesharing agreement for the IP being transferred. The agreement may be modified from time to time
with mutual consent among the creators and intimated to Registrar. Any conflict regarding the
revenue sharing among the creators shall be resolved by the university which is binding on all the
creators of the IP.

8. Revenue sharing
For university-owned IP, the inventor(s)/creator(s) shall get 70% and the university shall get 30%
of the net revenue earned out of licensing fee and royalty. Out of the university’s share of 30%,
50% shall go to the IP fund of the university; 30% shall go to the concerned department for the
development of R&D infrastructure; 10% shall go to university overheads, and 10% to the CIPR
to meet its revenue/capital expenditure. If the university owns the IP with another sponsor, the
revenue sharing shall be on mutually agreed terms.

9. Encouraging Entrepreneurship and Startup
The university may grant a license on the IP to the faculty inventor(s) or creator(s) of the property,
who opt to create an academic spin-off. A sabbatical leave may be considered by the competent
authority in exceptional cases for commercializing highly innovative technologies In that case, if
any faculty member of the university wants to start a venture (academic spin-off), a sabbatical leave
of 2-3 years shall be permitted as per the Govt of India norms. If the venture is not successful, he/she
shall be allowed to join back at the university. If any university faculty/ research scholars/ students
want to start any innovation-based venture, the university shall encourage and support such ventures
through its incubation centre. To promote a start-up/ venture set up by a researcher, it may be
exempted from any upfront fee and/or royalty accrued to the academic institution for a certain
period.

10.

Holding equity in start-ups/academic spinoffs

The university may accept equity in lieu of licensing fee and royalty from the start-ups/academic
spinoffs for its IP through its Special Purpose Vehicle (SPV) such as the incubation centre created
31

<!-- page 32 -->

IP Policy of Andhra University

under Section 8 of the Companies Act.

11.

Incentives for inventors

The university shall incentivize the students and faculties filing IP applications by means of
special award or grant. An inventor filing a complete specification with CIPR will be given a cash
award of ₹10,000. The amount shall be shared by all the inventors of the patent application. It is
the responsibility of the university to motivate higher number of students to take part in IP
generation.

12.

Research ethics and Integrity

To improve the standard of research and curb academic malpractice, research ethics and integrity
shall be properly monitored for all research projects in the university. A laboratory notebook is a
crucial tool for research data management and IP management system in an organization and can
act as legal evidence for proving inventorship/authorship. To strengthen the practice of responsible
research, each student/ research scholar is suggested to properly document and preserve the lab
notebook issued by the university. The principal investigator of a project and the research guide are
responsible for educating his/her team/scholars about the utilization of lab notebooks. All research
project participants are responsible for the correctness of the data they collect and write in the lab
notebook.
Concerning scientific publications, all individuals who have contributed as authors must be
acknowledged as such. Plagiarism in journal articles, doctoral and master's theses, or any other
scientific report is a disciplinary violation that will result in disciplinary action. Any allegation of
research misconduct should be addressed to either the Dean R&D or the Dean, Academic Affairs.
The lab notebook issued by the university is a property of the university. Research scholars shall
surrender the lab notebook to their respective guides at the time of submission of the thesis.

13.

IP education, awareness, and training program

It is the responsibility of the members of CIPR to educate the student community about the IPR
laws. Consequently, CIPR members along with other IP experts shall teach the IPR credit course
in the university. The university shall make it mandatory for all the faculty members to take part
in the IP awareness and training program conducted by CIPR. The faculties shall consult CIPR
about the potential patentability of the research before sending it for journal publication. The
32

<!-- page 33 -->

IP Policy of Andhra University

university shall make the DPIIT-IPR Chair/ Head of CIPR a member of doctoral committees/R&D
projects so that appropriate guidance can be provided to the researchers on IPR aspects.

14.

Confidentiality, Data Protection, and Privacy

All users of information, documents, and/or data within the university must ensure that the same
is always held securely and all activities pertaining to such information, documents, and/or data
will be kept confidential by the user(s) and will be used only for purpose of such activities. The
university shall have proper nondisclosure agreements with the user(s) in place to protect the data
and personal information against unauthorized access, loss, destruction, or breach.
Notwithstanding the above, any information which is already under public domain or required by
law or regulation to be disclosed or is independently developed by the researcher or is received
from a third party having no obligations of confidentiality to the disclosing party shall not be
treated as confidential information.

15.

Infringements, damages, liability, and indemnity

In any contract between the licensee and university, the university shall seek indemnity from any
legal proceedings including this, but not limited to manufacturing defects, production problems,
design guarantee, up-gradation, and debugging obligation. The university shall also ensure that
university personnel have an indemnity clause built into the agreements with the licensee(s) while
transferring technology or copyrighted material to licensees. The university shall retain the right
to engage in or desist from or not in any litigation concerning patent and license infringements.

16.

Conflict of interest

The inventor(s) are required to disclose any conflict of interest or potential conflict of interest.

17.

Agreements and Contracts

All agreements including but not limited to the following categories need to be approved by the
university. The Registrar acts as a final signing authority in all categories of agreements including
but not limited to i) Confidentiality agreement/ Nondisclosure agreement, ii) Consultation
Agreement, iii) Material transfer agreement, iv) Technology transfer agreement, v) License
agreement, vi) Revenue sharing agreement. All the agreement forms will be developed by CIPR
as needed.
33

<!-- page 34 -->

IP Policy of Andhra University

18.

Dispute Resolution

In case of any dispute arising out of the IPs, the decision taken by the university shall be final and
binding.

19.

Jurisdiction

All agreements to be signed by the university shall have the jurisdiction of the appropriate court
of Andhra Pradesh and shall be governed by the appropriate laws of India.

*****************************************************************************

34

<!-- page 35 -->

IP Policy of Andhra University

Annexure I: IP Agreement Form
INTELLECTUAL PROPERTY AGREEMENT WITH ALL ACADEMIC/ NONACADEMIC STAFF OF ANDHRA UNIVERSITY

1. Name (CAPITAL LETTERS) ………….....

……………..

First Name

Middle Name

……………………..
Surname

2. I submit that by virtue of:
- My employment at Andhra University (AU) and /or
- My participation in research at AU
- Opportunities provided or to be provided by AU which result in
significant use of AU funds and facilities, and/or
- Opportunities to have a share in royalties and other inventor(s)/author(s)
as per Intellectual Property Guidance.
I, hereby agree that:
A. I shall promptly disclose and assign to AU any right to all inventions, copyrightable
materials, computer software, semiconductor mask patterns, tangible research property and
trademarks (Intellectual Property) conceived, invented, authored or validated to practice by me,
solely or jointly with others which:

35

<!-- page 36 -->

IP Policy of Andhra University

IP AGREEMENT FORM
(i) are an outcome of sponsored research or any other agreement to which I have direct or
indirect participation or
(ii) are an outcome of substantial utilization of AU resources or
(iii) is an outcome of “work-for-hire” as per IPR guidelines.
B. I shall cooperate with AU to obtain, protect or exploit the intellectual property through
legal protection such as patent, copyright, etc.
C. I shall make available all documentation to AU for intellectual property.
D. I shall surrender to AU the documents related to intellectual property if I leave AU for any
reason or at any other time asked for such documents.
E. I shall assist the university in technology transfer/licensing to entrepreneurs.
F. The agreement will be in force for the entire period specified and even after the termination
of my employment or other association with AU.

Signature

Witness

Department/Centre

Signature

Designation

Name

Date

Date

36

<!-- page 37 -->

IP Policy of Andhra University

Annexure II: Invention Disclosure Form
INVENTION DISCLOSURE FORM
1. Title of the Invention
2. Technical field of the invention
3. Inventor(s) filing the patent
Name(s)

Department

Designation(s)

_________________________

Office Phone __________________________

E-mail ______________________

4. Principal Investigator _____________________________________________________
5. Is the patent to be filed a process or a product?
6. Description of the invention
• The problem for which solution was researched
• How the invention solves the problem
• Keywords to describe the invention

7. Date of start of the project
8. Project is funded by
9. Give literature search (prior art) details
10. Unique benefits of the invention as compared to prior art

37

<!-- page 38 -->

IP Policy of Andhra University

INVENTION DISCLOSURE FORM
11. Any environmental issues?
12. Has the work been displayed anywhere?
If yes, when?
13. Has the work been reported/published/presented (oral or poster) anywhere?
If yes, give a full description.
14. Has any related patent been filed by the inventor?
15. Commercial aspects of the invention (Demand vs Supply, Price, Current manufacturers in
India and abroad)
16. Development stage:
Give your opinion on the current stage of development of the invention as it relates to its
marketability (select from the options below):
Embryonic (needs substantial work to bring to market)
Partially developed (could be brought to market with significant investment)
Off-the-shelf (could be brought to market with nominal investment)
17. List of potential licensees/buyers of the invention
18. I/We agree to assign my/our rights in the invention to Andhra University
19.
I/We
hereby
declare
that
no
part
of
this
work
has
published/reported/presented/displayed anywhere before filing the patent application.
(Strike out if not applicable)

been

Declaration: I/We hereby declare that the information provided here is correct and true to
the best of my/our knowledge. In case any of the above information is found to be untrue or
misleading, I am/we are aware that I/we may be held liable for it.

Inventors’ Signatures

Date

38

<!-- page 39 -->

IP Policy of Andhra University

Annexure III: Fee Structure for Complete Patent Lifecycle payable
at Indian Patent Office
For e-filing

Number
of Entry

On what
payable

Number
of the
relevant
Form

1

2

3

1

On application
for a patent
under sections
7, 54 or 135
and rule 20(1)
accompanied
by provisional
or complete
specification—

1

For physical filing

Natural
person(s) or
Startup(s) or
Small
entit(y)/(ies)
or
educational
institution(s)

Other(s),
alone or
with natural
person(s) or
Startup(s) or
Small
entit(y)/(ies)
or
educational
institution(s)

Natural
person(s) or
Startup(s) or
Small
entit(y)/(ies)
or
educational
institution(s)

Other(s), alone or
with natural
person(s) or
Startup(s) or
Small
entit(y)/(ies) or
educational
institution(s)

4

5

6

7

Rupees

Rupees

Rupees

Rupees

1600

8000

1750

8800

Multiple of
8000

Multiple of
1750 in case
of every
multiple
priority.

Multiple of 8800 in case of every
multiple priority.

Multiple of
1600 in case
of every
multiple
priority.

in case of
every
multiple
priority.

(i) for each
sheet of
specification in
addition to 30,
excluding
sequence listing
of nucleotides
and/ or amino
acid sequences
under sub-rule
(3) of rule (9);

(i) 160

(i) 800

(i) 180

(i) 880

(ii) for each
claim in
addition to 10;

(ii) 320

(ii) 1600

(ii) 350

(ii) 1750

39

<!-- page 40 -->

IP Policy of Andhra University

(iii) for each
page of
sequence listing
of nucleotides
and/ or amino
acid sequences
under sub- rule
(3) of rule (9).

2

3

4

On filing
complete
specification
after
provisional up
to 30 pages
having up to 10
claims –
(i) for each
sheet of
specification in
addition to 30,
excluding
sequence listing
of nucleotides
and/ or amino
acid sequences
under sub-rule
(3) of rule (9);
(ii) for each
claim in
addition to 10;
(iii) for each
page of
sequence listing
of nucleotides
and/ or amino
acid sequences
under sub- rule
(3) of rule (9).
On filing a
statement and
undertaking
under section 8.
i) On request
for extension of
time under
sections 53(2)
and 142(4),
rules 13(6),
80(1A) and 130
(per month).
ii) On request
for extension of
time under subrule (5) of rule
24B (per
month).

2

(iii) 160
subject to a
maximum
of 24000

(iii) 800
subject to a
maximum
of 120000

Not allowed

Not allowed

No fee

No fee

No fee

No fee

(i) 160

(i) 800

(i) 180

(i) 880

(ii) 320

(ii) 1600

(ii) 350

(ii) 1800

(iii) 800
subject to a
maximum
of 120000

Not allowed

Not allowed

(iii) 160

subject to a
maximum
of 24000

3

No fee

No fee

No fee

No fee

4

480

2400

530

2600

4

1000

4000

1100

4400

40

<!-- page 41 -->

IP Policy of Andhra University
iii) On request
for extension of
time under subrule (11) of rule
24C (per
month).
On filing a
declaration as
to inventorship
under sub-rule
(6) of rule 13.

5

10000

2200

11000

5

No fee

No fee

No fee

No fee

On application
for postdating.

-

800

4000

880

4400

7

On application
for deletion of
reference under
section 19(2).

-

800

4000

880

4400

(i) On claim
under section
20(1);

6

800

4000

880

4400

6

800

4000

880

4400

7

2400

12000

2600

13200

7A

No fee

No fee

No fee

No fee

-

1500

7500

1700

8300

8

800

4000

880

4400

9

2500

12500

2750

13750

9

11

2000

6

8

10

4

(ii) On request
for direction
under section
20(4) or 20(5).
(i) On notice of
opposition to
grant of patent
under section
25(2);
(ii) On filing
representation
opposing grant
of patent under
section 25(1).
On giving
notice that
hearing before
Controller shall
be attended
under rule
62(2).
On application
under sections
28(2), 28(3) or
28(7).
Request for
publication
under section
11A(2) and rule
24A.

41

<!-- page 42 -->

IP Policy of Andhra University

12

13

14

15

16

i)

ii)

iii)

iv)

v)

vi)

On application
under section
44 for
amendment of
patent.
On application
for directions
under section
51(1) or 51(2).
On request for
grant of a
patent under
sections 26(1)
and 52(2).
On request for
converting a
patent of
addition to an
independent
patent under
section 55 (1).
For renewal of
a patent under
section 53—
before the
expiration of
the 2nd year
from the date of
patent in
respect of 3rd
year;
before the
expiration of
the 3rd year in
respect of the
4th year;
before the
expiration of
the 4th year in
respect of the
5th year;
before the
expiration of
the 5th year in
respect of the
6th year;
before the
expiration of
the 6th year in
respect of the
7th year;
before the
expiration of
the 7th year in
respect of the

10

2400

12000

2650

13200

11

2400

12000

2650

13200

12

2400

12000

2650

13200

-

2400

12000

2650

13200

-

800

4000

880

4400

-

800

4000

880

4400

-

800

4000

880

4400

-

800

4000

880

4400

-

2400

12000

2650

13200

-

2400

12000

2650

13200

42

<!-- page 43 -->

IP Policy of Andhra University

vii)

viii)

ix)

x)

xi)

xii)

xiii)

xiv)

xv)

xvi)

8th year;
before the
expiration of
the 8th year in
respect of the
9th year;
before the
expiration of
the 9th year in
respect of the
10th year;
before the
expiration of
the 10th year in
respect of the
11th year;
before the
expiration of
the 11th year in
respect of the
12th year;
before the
expiration of
the 12th year in
respect of the
13th year;
before the
expiration of
the 13th year in
respect of the
14th year;
before the
expiration of
the 14th year in
respect of the
15th year;
before the
expiration of
the 15th year in
respect of the
16th year;
before the
expiration of
the 16th year in
respect of the
17th year;

before the
expiration of
the 17th year in
respect of the
18th year;

-

2400

12000

2650

13200

-

2400

12000

2650

13200

-

4800

24000

5300

26400

-

4800

24000

5300

26400

-

4800

24000

5300

26400

-

4800

24000

5300

26400

-

4800

24000

5300

26400

-

8000

40000

8800

44000

-

8000

40000

8800

44000

-

8000

40000

8800

44000

43

<!-- page 44 -->

IP Policy of Andhra University

xvii)

xviii)

17

before the
expiration of
the 18th year in
respect of the
19th year;
before the
expiration of
the 19th year in
respect of the
20th year.
On application
for amendment
of application
for patent or
complete
specification or
other related
documents
under section
57—
before grant of
patent;

18

19

20

after grant of
patent;
where
amendment is
for changing
name or
address or
nationality or
address for
service.
On notice of
opposition to an
application
under sections
57(4), 61(1)
and 87(2) or to
surrender a
patent under
section 63(3) or
to a request
under section
78(5).
On application
for restoration
of a patent
under section
60.
Additional fee
for restoration
under section
61(3) and rule
86(1).

-

8000

40000

8800

44000

8000

40000

8800

44000

800

4000

880

4400

1600

8000

1750

8800

320

1600

350

1750

14

2400

12000

2650

13200

15

2400

12000

2650

13200

-

4800

24000

5300

26400

13

44

<!-- page 45 -->

IP Policy of Andhra University

21

22

On notice of
offer to
surrender a
patent under
section 63.
On application
for the entry in
the register of
patents of the
name of a
person entitled
to a patent or as
a share or as a
mortgage or as
licensee or as
otherwise or for
the entry in the
register of
patents of
notification of a
document under
sections 69(1)
or 69(2)

-

1000

5000

1100

5500

1600

8,000

1750

8,800

(In respect
of each
patent)

(In respect
of each
patent)

(In respect
of each
patent)

(In respect of each patent)

-

320

1600

350

1750

-

800

4000

880

4400

17

2400

12000

2650

13200

4000

20000

4400

22000

16

and rules 90(1)
or 90(2).

23

24

25

26

On application
for alteration of
an entry in the
register of
patents or
register of
patent agents
under rules
94(1) or rule
118(1).
On request for
entry of an
additional
address for
service in the
Register of
Patents under
rule 94(3).
On application
for compulsory
license under
sections 84(1),
91(1), 92(1)
and 92A.
On request for
examination of
application for
patent—
(i) under
section 11B and
rule 24(1);

18

45

<!-- page 46 -->

IP Policy of Andhra University

(ii) under rule
20(4)(ii).

27

28

29

30

31

32

33

34

On request for
expedited
examination of
application for
patent under
rule 24C.
Conversion of
the request for
examination
filed under rule
24B to request
for expedited
examination
under rule 24C.
On application
for revocation
of a patent
under section
85(1).
On application
for revision of
terms and
conditions of
licence under
section 88(4).
On request for
termination of
compulsory
licence under
section 94.
On application
for registration
as a patent
agent under
rule 109(1) or
rule 112.
On request for
appearing in the
qualifying
examination
under rule
109(3).
For continuance
of the name of
a person in the
register of
patent agents—

(i) for the 1st
year to be paid
along with
registration;

5600

28000

6150

30800

18A

8000

60000

Not allowed

Not allowed

18A

4000

40000

Not allowed

Not allowed

19

2400

12000

2650

13200

20

2400

12000

2650

13200

21

2400

12000

2650

13200

22

3200

Not
applicable

3500

Not applicable

-

1600

Not
applicable

1750

Not applicable

-

800

Not
applicable

880

Not applicable

46

<!-- page 47 -->

IP Policy of Andhra University

35

36

37

38

39

40

41

(ii) for every
year excluding
the 1st year to
be paid on the
1st April in
each year.
On application
for duplicate
certificate of
patent agent
under rule
111A.
On application
for restoration
of the name of
a person in the
register of
patent agents
under rule
117(1).
On a request for
correction of
clerical error
under section
78(2).
On application
for review or
setting aside the
decision or
order of the
controller under
section 77(1)(f)
or 77(1)(g).
On application
for permission
for applying
patent outside
India under
section 39 and
rule 71(1).
On application
for duplicate
patent under
section 154 and
rule 132.
(i) On request
for certified
copies under
section 72 or
for certificate
under section
147 and rule
133(1).
(ii) On request
for certified
copies under
section 72 or
for certificate

-

800

Not
applicable

880

Not applicable

-

1600

Not
applicable

1750

Not applicable

1600

23

(Plus
continuation
fee under
entry
number 34)

1750

Not
applicable

(Plus
continuation
fee under
entry
number 34)

Not applicable

-

800

4000

880

4400

24

1600

8000

1750

8800

25

1600

8000

1750

8800

-

1600

8000

1750

8800

1000

5000

1100

5500

(up to 30
pages and,
thereafter,
30 for each
extra page)

(up to 30
pages and,
thereafter,
150 for each
extra page)

(up to 30
pages and,
thereafter,
30 for each
extra page)

(up to 30 pages and, thereafter,
150 for each extra page)

2400

12000

3300

13200

(up to 30

(up to 30

(up to 30

(up to 30 pages and thereafter, 30

-

-

47

<!-- page 48 -->

IP Policy of Andhra University
under section
147 and rule
133(2).

42

43

44

For certifying
office copies,
printed each.
On request for
inspection of
register under
section 72,
inspection
under rule 27 or
rule 74A.
On request for
information
under section
153 and rule
134.

pages and
thereafter,
30 for each
extra page)

pages and
thereafter,
30 for each
extra page)

pages and
thereafter,
30 for each
extra page)

for each extra page)

-

800

4000

880

4400

-

320

1600

350

1750

-

480

2400

530

2650

45

On form of
authorisation of
a patent agent.

26

No fee

No fee

No fee

No fee

46

On petition not
otherwise
provided for.

-

1600

8000

1750

8800

-

10

10

10

10

-

3200

16000

3500

17600

-

No fee

No fee

Not
applicable

Not applicable

1000

5000

1100

5500

(up to 30
pages and,
thereafter,
30 for each
extra page)

(up to 30
pages and,
thereafter,
150 for each
extra page)

(up to 30
pages and,
thereafter,
30 for each
extra page)

(up to 30 pages and, thereafter,
150 for each extra page)

No fee

No fee

Not
applicable

Not applicable

47

48

49

50

51

For supplying
of photocopies
of the
documents, per
page.
Transmittal fee
for
International
application.
Transmittal fee
for
International
application (for
ePCT filing).
For preparation
of certified
copy of priority
document and
for transmission
of the same to
the
International
Bureau of
World
Intellectual
Property
Organization.
For preparation
of certified
copy of priority
document and

-

-

48

<!-- page 49 -->

IP Policy of Andhra University

52

e-transmission
through WIPO
DAS.
On statement
regarding
working of a
patented
invention on a
commercial
scale in India
under section
146(2) and rule
131(1).
To be
submitted for
claiming the
status of a small
entity, startup
or eligible
educational
institution.
Request for
adjournment of
hearing under
rule 129A (for
each
adjournment).

27

No fee

No fee

No fee

No fee

28

No fee

No fee

No fee

No fee

-

1000

5000

1100

5500

55

Application for
withdrawing
the application
under section
11B(4), and
rules 7(4A) and
26.

29

No fee

No fee

No fee

No fee

56

Miscellaneous
form under rule
8(2), to be used
when no other
form is
prescribed.

30

53

54

As applicable

Note: In addition to the above-mentioned Govt fees, there will be the patent agent/attorney fees
that may range between ₹50,000 to ₹1.5 Lakhs depending upon the reputation of the patent
agent/attorney.

49

<!-- page 50 -->

<!-- page 51 -->

<!-- page 52 -->

<!-- page 53 -->

Andhra University
Visakhapatnam, India, 530003
Accredited by NAAC with 'A' Grade
ISO 9001: 2015 Certified
ESTD: 1926
