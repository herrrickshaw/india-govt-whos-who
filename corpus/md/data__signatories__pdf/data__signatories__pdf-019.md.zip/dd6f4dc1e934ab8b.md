---
doc_id: "dd6f4dc1e934ab8b"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/2d2ecb719731f54b2e982fa8c8b00243.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "11 Cabinet approves TCIL's 'C' corp in USA"
date: "2018-03-21"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7fd9b3f2ef4930b0"
---

<!-- page 1 -->

Ministry of Communications

Cabinet approves formation of 100% owned C
Corporation of Telecommunications Consultants
India Ltd. (TCIL) in USA
Posted On: 21 MAR 2018 8:27PM by PIB Delhi

The Union Cabinet chaired by Prime Minister Shri Narendra Modi has given its approval
forformation of 100% owned C Corporation of Telecommunications Consultants India
Ltd.(TCIL) in USA as per the details given below:

i.

Formation of C Corporation of Telecommunications Consultants India Ltd. (TCIL) in
the state of Texas, USA with authorization for registering in other states of USA for
doing business subsequently.

ii.

TCIL's Equity Investment of 100% in the C Corporation amounting to USD 5 Million
(equivalent to INR 33.84 crores taking the exchange rate as Rs. 67.68)in a phased
manner.

iii.

TCIL's submission of Counter Guarantees amounting to USD 5 Million to Lenders of
Loans/ Facilities / Vendors and also client for Bid bonds / Advance/ Performance
Guarantees etc. required in connection with the execution of Projects in USA.

C Corporation will be earning precious foreign exchange for the country and increasing
profitability of TCIL which is a Government PSU.

C Corporation is formed in the state of Texas, USA in connection with the execution of Projects
in USA.
The newly formed C Corporation shall earn an estimated profit of around 10% in the initial
years with turnover of USD 10 Million, which may get increased subsequently depending upon
the volume of work.

Formation of C Corporation in USA shall help TCIL to expand its business/ turnover/profits
and ultimately result in increased dividend to the Government being a State PSU.

<!-- page 2 -->

Total investment of USD 5 Million will be made by TCIL in the form of Equity from its internal
resources. TCIL may also be required to provide Counter Guarantees of around USD 5 Million
for getting finances in US for expansion of business and also Bid Bonds/ Advance Payment
Guarantees/ Performance Bank Guarantees to Govt. authorities/ Final client on behalf of C
Corporation. As such there will be no financial implication on the part of the Government.

Background:
TCIL is a leading ISO - 9001: 2008 and ISO 14001:2004 certified, Schedule-A, Mini Ratna
Category-l, 100% owned Govt. of India Undertaking. It has executed projects in more than 70
countries in the domain of Telecommunications and Information Technology. It provides
consultancy and turnkey project execution service from concept to completion, in the field of
telecommunications, IT and civil infrastructure.

The consolidated networth of the company as on 31.03.2017 was Rs.2433.66 crore. The
standalone networth of the company was Rs. 588.92 crore. Company has paid/declared
cumulative dividend of Rs. 192.99crore to Government of India till 31.03.2017.
'Google Fiber' is Google's 'fiber-to-the-Premises Project' in the United States for providing
high capacity Broadband Internet and cable television to all the cities. M/s Google have
selected few international Companies as their technical partner like M/s. Ericsson, M/s Mastec,
M/s AT&T, M/s Zoya etc. who in turn have further subcontracted the works to various
companies for different activities. M/s Teletech is one of the companies who have signed
Master service agreement with M/s Mastec and M/s Ericsson for execution of network rollout
works in Austin (Texas) and San Jose (California). M/s Teletech Team approached TCIL for
providing full techno commercial and logistic support for three projects. M/s Teletech Team
have signed a MoU with TCIL on 13.04.2016 followed by a Joint Co-operation Agreement on
27.05.2016. TCIL being a foreign entity needs to form a C Corporation which is recognized as
a separate tax paying entity. This would also enable TCIL to have L-1 Visas for its manpower
resources.

****
