---
doc_id: "ddaf4640ba4edbd5"
source_url: "https://www.legislative.gov.in/static/uploads/2025/07/5821107129ea63c0cff62d1ebe0acce5.pdf"
ministry: "Legislative Department (LD)"
title: "Preamble to the Constitution of India in Urdu"
date: "2025-11-25"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "e27238c864f96d91"
---

<!-- page 1 -->

35 ४४७०७
Ae
T wi
mst | ash ated
Ant
Sat pe Shs ly Les
wilye ४५० we 6sly glow 3५७७ ४॥| 9S ole
LF Kod Lure CEU ४ ९५७३३
Sus F obi tlal
ses isle freon bbl SSS a1 IT
Cr hed? A pclae
७६५० ७४५३
छोर कली: ५०४72 है|
nee Kod
gael T gh Aa PICT RE beef Th
US By eth S Cte Se
