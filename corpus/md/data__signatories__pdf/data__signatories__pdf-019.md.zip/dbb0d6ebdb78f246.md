---
doc_id: "dbb0d6ebdb78f246"
source_url: "https://dohe-education.gov.in/static/uploads/2025/11/01fd24c903b75698b6cb8c41c8831c33.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "guidelines of the Scheme"
date: "2024-11-06"
pages: 24
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a51ebff75f6d56af"
---

<!-- page 1 -->

PRADHAN MANTRI VIDYALAXMI (PM-Vidyalaxmi) SCHEME
GUIDELINES
(Applicable for Education Loans taken after 6th November 2024)
1.
1.1.

Introduction
One of the major objectives of the Government is to ensure that no student is denied

the opportunity to pursue higher education due to financial constraints. For helping out youth
who have not been eligible for any benefit under government schemes and policies, the Union
Budget 2024-25 has announced a financial support for loans up to 10 lakhs for higher education
in domestic institutions. The Union Cabinet on 6th November 2024 approved “Pradhan
Mantri Vidyalaxmi” (PM-Vidyalaxmi), a Central Sector Scheme to financial support to
meritorious students so that financial constraints do not prevent any youth of India from
pursuing quality higher education. The broad contours of the scheme are:
1.1.1. A mission mode mechanism will facilitate and drive the extension of education loans
to meritorious students who get admission in the top 860 quality Higher Educational
Institutions (QHEIs) of the nation, translating to covering more than 22 lakh students
every year.
1.1.2. A special loan product will enable collateral free, guarantor free education loans;
made accessible through a simple, transparent, student-friendly and entirely
digital application process.
1.1.3. Loan amounts up to ₹ 7.5 lakhs will be provided a 75% credit guarantee by the
Government of India, to support banks to expand coverage.
1.1.4. Furthermore, for students with up to Rs. 8 lakhs annual family income, the scheme
will also provide for 3% interest subvention on loans up to Rs 10 lakh.
1.1.5. This is in addition to the full interest subvention already offered to students with up to
Rs. 4.5 lakhs annual family income.
1.1.6. PM Vidyalaxmi will build on the scope and reach of initiatives taken over the last
decade for maximizing access to quality higher education for the youth.
1.1.7. The Scheme is applicable for all Scheduled Banks/Regional Rural Banks (RRBs)/Cooperative Banks.

1|P M - V i d y a l a x m i

– scheme guidelines Dept of Higher

Education, 2024

<!-- page 2 -->

2. Education loan under PM-Vidyalaxmi
2.1.

Under PM-Vidyalaxmi, a special loan product of collateral-free and guarantor-free education

loans is introduced. This education loan will be available to students who get admission on their

own merit to quality Higher Education Institutions (QHEIs) in India. The criteria of selecting
QHEIs are given at paragraph 6 of this guideline.
2.2.

Students of all family income groups will be eligible to get this education loan, if they so desire.

2.3.

There is no cut-off on highest amount of education loan. It will depend on course fee and other

fees charged by the QHEI and other associated expenses (like mess, hostel fee, other refundable and
non-refundable fees of the QHEI, cost of a reasonable quality laptop and reasonable amount of living
expenses required by the student during the course period). This amount will vary from QHEI to

QHEI. An example of the same may be seen at Annexure I.
2.4.

All students getting admission in the QHEIs in India for degree/ diploma programmes can avail

this benefit. There will be no limit on number of students getting such loans.

2.5.

Loan will be made accessible through a simple, transparent, student-friendly and

entirely digital application process, with a simple 2-page application format. The name of the
portal will be same as name of the scheme.
2.6.

Students admitted through open competitive examinations/ merit based admission shall get this

loan. Students admitted through management quota (or similar quota) will not be eligible.
2.7.

Bank may take life insurance cover of the student borrower if the loan amount is above certain

threshold, to be decided by individual banks. As per request of the borrower, the insurance premium
can be included in the education loan amount.
2.8.

The repayment period of the education loan would be up to 15 years excluding moratorium

period (Course period + 1 year), which is same as IBA Model Education Loan Scheme guidelines.
2.9.

3. 3% Interest subvention under PM-Vidyalaxmi
3.1.

A student whose annual family income is up to ₹ 8 lakhs and who is pursuing any course from

these quality HEIs shall be eligible to get 3% interest subvention for education loans up to ₹10 lakhs.
3.1.1. If education loan amount is more than ₹ 10 lakhs, interest subvention shall be provided for
disbursed total principal amount of loan up to ₹ 10 lakhs only;
3.1.2. 3% Interest subvention shall be provided for interest accrued on outstanding education loan
during moratorium period (course period plus one year).

3.1.3. In a year, a maximum of One lakh such interest subventions shall be provided. In case
number of fresh applicants exceeds One lakh, a sequential method will be used to select 1
lakh beneficiaries, as detailed in Paragraph 7.

2|P M - V i d y a l a x m i

– scheme guidelines Dept of Higher

Education, 2024

<!-- page 3 -->

3.1.4. An example of the same may be seen at Annexure -2 .
3.2.

It may be noted that as per the guidelines of the PM-USP CSIS scheme, students who are

pursuing technical/ professional courses from approved NAAC accredited HEIs/ NBA accredited
courses and whose annual family income is up to ₹4.5 lakhs, shall be eligible for interest subvention
during moratorium period for education loan up to ₹ 10 lakhs.
3.3.

Thus, students whose annual family income is between ₹4.5 lakhs and ₹8 lakhs shall be eligible

to apply for 3% interest subvention for all degree/ diploma courses in the QHEIs. An indicative
distribution regarding eligibility for interest subvention in PM-Vidyalaxmi and PM-USP CSIS in the
QHEIs is given in the table below:

Technical/ Professional courses

Other courses

100% interest subvention

3% interest subvention

(PM-USP CSIS)

(PM-Vidyalaxmi)

Annual income 4.5 lakhs – 8

3% interest subvention

3% interest subvention

lakhs

(PM-Vidyalaxmi)

(PM-Vidyalaxmi)

Annual income Up to 4.5 lakhs

4. Credit Guarantee on education loans:
4.1.

When education loan sanction amount is up to ₹ 7.5 lakhs, irrespective of family income, the

student shall be eligible for credit guarantee where 75% of outstanding default will be covered by
Government, as per the other existing guidelines of the PM-USP Credit Guarantee Fund Scheme for
Education Loans (CGFSEL) run by DHE.

5.

PM-Vidyalaxmi will supplement the PM-USP Central Sector Interest Subsidy (CSIS)

run by DHE.
5.1. Under the PM-USP CSIS, students with annual family income up to ₹ 4.5 lakhs and
pursuing technical/ professional degree courses from approved institutions get full
interest subvention during moratorium period for education loans up to ₹ 10 lakhs.
5.2. For degree/ diploma courses which are not covered in PM-USP, if the student is
studying in the QHEIs covered in PM-Vidyalaxmi, the student will be eligible for 3%
interest subvention, if the annual family income of the student is up to ₹ 8 lakhs.
5.3. Further, for all degree/ diploma courses of the QHEIs, the student will be eligible for
3% interest subvention, if the annual family income of the student is up to ₹ 8 lakhs.
5.4. Thus, PM Vidyalaxmi and PM-USP will together provide holistic support to all
deserving students to pursue higher education in quality HEIs and technical/
professional education in approved HEIs.
3|P M - V i d y a l a x m i

– scheme guidelines Dept of Higher

Education, 2024

<!-- page 4 -->

5.5.

Both interest subvention and credit guarantee benefits under PM-Vidyalaxmi shall be

admissible only once either for undergraduate or post graduate or integrated course.
5.6.

Student availing any other Central /State Government Scholarship or any other interest

subvention scheme or Fee reimbursement shall not be eligible for availing benefits under this
Scheme.
5.7.

Interest subvention and credit guarantee under this Scheme shall not be available to

those students who discontinue their course midstream, or who are expelled from the Institution
on disciplinary or academic grounds. However, Interest subvention and credit guarantee would
be available only if discontinuation is due to medical grounds for which necessary
documentation to the satisfaction of the Head of educational institution needs to be provided.
6.

Quality Higher Education Institutions (Quality HEIs) under PM-Vidyalaxmi

6.1. Criteria for eligibility of an Institute to be considered as quality HEI under PMVidyalaxmi are as under:
6.1.1. Top 100 ranked HEIs in the overall/ category-specific and/or domain specific
rankings in latest list of NIRF published by the Ministry of Education; plus
6.1.2. Top 200 ranked HEIs under the governance of state/ut governments in the latest list
of NIRF published by the Ministry of Education; plus;
6.1.3. All remaining HEIs under the governance of Government of India.
6.1.4. Indian campus of foreign education institutions, foreign campus of Indian education
institutions and foreign education institutions will not be covered.
6.2. Thus, interest subvention benefits shall be available for Indian Higher Education
Institutions (HEIs) which are in the list of quality HEIs and for study in India only.
6.3. Department of Higher Education (DHE) shall prepare a list of such Higher Education
Institutions (HEIs) in consultation with NBA (for NIRF ranked institutions) and AISHE
(for remaining central government institutions). This list will be updated every year using
the latest NIRF ranking.
6.4. A list of 860 Institutes for the year 2024-25 has been prepared. Details of how list is
prepared may be seen at Annexure-3. The list is at Annexure-4. A mission mode
mechanism will facilitate and drive the extension of education loans to meritorious
students who get admission in these top 860 quality higher educational institutions of the
nation, translating to covering more than 22 lakh students every year.
6.5. Placement record of the institute may also be adopted as one of the criteria for selection
of QHEI in future.
4|P M - V i d y a l a x m i

– scheme guidelines Dept of Higher

Education, 2024

<!-- page 5 -->

7.

The sequential method to be used to select 1 lakh beneficiaries is as under:

7.1. For ensuring equitable inter-state representation, all-India slots will be distributed
across States based on population. If enough applications do not come from a State/UT,
vacant slots shall be redistributed among remaining states on pro-rata basis.
7.2. Then, preference will be given to candidate who have got admission in a government
HEI.
7.3. Then preference will be given to technical/ professional courses.
7.4. Then, preference will be given to candidate who passed higher secondary (10+2) board
examination from a Government school.
7.5. Next preference will be given to candidate who passed secondary (10th standard) board
examination from a Government school.
7.6. Next preference will be given to candidate who passed higher secondary from a rural
school.
7.7. Next preference will be given to girl students.
7.8. The classification regarding government school, rural school shall be decided based on
the latest UDISE+ data of the Department of School Education and Literacy,
Government of India.
7.9. Safeguards will be built to ensure that some institutions are not crowding the application
process.
7.10. The state-wise population in age-group 18-23 years, as per latest available population
projection, used to compute the Gross Enrolment Rate (GER) in higher education and
published as a part of All India Survey of Higher Education (AISHE), shall be used.
7.11. The state-wise number of slots allotted based on population in age-group 18-23 years
prepared on the basis of latest population projection and used to compute the Gross
Enrolment Ratio (GER) of higher education in the All-India Survey on Higher
Education (AISHE) is given at Annexure 5. Illustrative examples of allocation of slots
within a state to the applicants is also given at Annexure 5.
8.

Interest Rate

The interest rates charged on the educational loan shall be capped at individual bank’s
Externally Benchmarked Lending Rate (EBLR) + 0.5%. In all cases, interest rate charged for
loans under PM-Vidyalaxmi shall be less than the interest rate charged by the bank on

5|P M - V i d y a l a x m i

– scheme guidelines Dept of Higher

Education, 2024

<!-- page 6 -->

education loans not covered under PM-Vidyalaxmi. Individual banks will be free to charge
interest which is lower than this as per their policy.
9.

Moratorium Period

9.1. Under the Scheme, moratorium period is defined as Course Period plus one year.
9.2. Interest computation will be at simple annual rate on the outstanding principal disbursed
amount education loan during moratorium period;
9.3. 3% Interest for only the moratorium period, at simple rate of interest on amount disbursed
or outstanding, whichever lower, will be borne by the Government of India, subject to
the condition that the student completes the course of study successfully.
9.4. The borrower shall have to pay remaining part of the interest which gets accrued during
moratorium period.
9.5. Further, entire principal education loan as well as any outstanding interest due to nonpayment of principal shall be paid by the borrower.
9.6. After the moratorium period, entire interest on the outstanding loan amount shall be paid
by the student according to the loan agreement with the bank which gave the education
loan.
9.7. Interest subvention amount shall be paid only to the education loan account. Therefore,
interest subvention will be paid only if the education loan account is found live during
transfer of subvention amount to the education loan account of the student.
10.

PM-Vidyalaxmi Portal

10.1. For all the education loans of quality HEIs, there will be a unified portal for loan
application, which will be under the administrative control of the DHE. Once the
education loan is sanctioned by the banks and disbursed, the banks will update the same
in the portal seamlessly.
10.2. Further, the Portal of PM-Vidyalaxmi will be for applying, consolidating, approving and
disbursing the interest subvention amounts. The eligible applicants for interest
subvention, as per self-declaration of the students will be informed by the DHE to apply
for interest subvention benefits in the same portal.
10.3. The Department of Higher Education runs the central sector scheme Pradhan Mantri
Uchchatar Shiksha Protsahan (PM-USP) which inter alia includes interest subsidy and
credit guarantee on education loans. Once this portal becomes operational, all existing

6|P M - V i d y a l a x m i

– scheme guidelines Dept of Higher

Education, 2024

<!-- page 7 -->

education loan beneficiaries of PM-USP CSIS and PM-USP CGFSEL shall also be
brought under the PM-Vidyalaxmi portal as given in Paragraph 18 of guidelines.
10.4. Following are the basic required documents for interest subvention:
10.4.1.

KYC Details (Student) – Aadhaar, PAN ID and Address Proof.

10.4.2.

Previous Qualifying self-attested copy of Mark sheets.

10.4.3.

Entrance Exam Result.

10.4.4.

Offer letter from Institution along with Fee Structure.

10.4.5.

Proof of Income from designated public authority of the state.

10.4.6.

If the QHEI has already accepted some of these documents at the time of
admission, the student should submit a certificate regarding the same from the
QHEI (proforma given at Annexure 6). Only the remaining documents will have
to be submitted by the students to the bank / portal.

11.

Definition of Family
11.1.

The definition of “family”, for the purpose of determining the family income

criteria in this scheme shall be the student plus her/ his father & mother plus her/ his
spouse, wherever applicable.
12.

Courses eligible
12.1.

All the Graduation/ Post Graduation degree and diploma courses offered by

QHEIs are eligible.
13.
13.1.

Income Limit/ Proof
Income proof is required from authorized Public Authority of the State Government.
Guidelines for the verification and uploading of income certificate to be submitted by
beneficiary students are as follows:

13.1.1. If a student has already submitted income certificate at the time of admission to the
HEI and the same has been used by the HEI for verification, the student will submit
a certificate to that effect from competent authority of the HEI. The format of the
certificate from the authority of the HEI is given at Annexure 6.
13.1.2. If the student has not submitted any income certificate or the HEI has not verified
any income certificate submitted by the beneficiary student, student has to submit
the income certificate verified by designated public authority. Student shall submit
it at the bank for verification and upload at the portal.
7|P M - V i d y a l a x m i

– scheme guidelines Dept of Higher

Education, 2024

<!-- page 8 -->

13.1.3. Usually, the concerned bank shall upload the verified income certificate to the PMVidyalaxmi portal. In case of any delay by the bank in uploading of the certificate,
the student shall have the option to upload the certificate. In that case too, the bank
has to verify the certificate;
13.1.4. For interest subvention benefits, the responsibility of verifying the income certificate
shall be with the lending bank if the student submits the income certificate to the
bank;
13.1.5. For students who have uploaded the certificate in the PM-Vidyalaxmi portal, the
same will be forwarded to the lending bank for verification. Lending bank should
complete verification before the application is taken up for de-duplication.
13.1.6. The portal shall have necessary system checks to prevent duplicate/excess claim.
14.

Competent Authority

14.1. The responsibility of disbursing education loans will be on the respective banks who
have sanctioned the loans. The Department of Finance (DFS), Ministry of Finance
shall be monitoring the loan delivery by the banks.
14.2. Department of Higher Education, Ministry of Education shall be competent authority
for interest subvention and credit guarantee under the Scheme.
14.3. The National Credit Guarantee Trustee Company Limited (NCGTC) shall be
competent authority with respect to operations of the credit guarantee fund.
15.

Role of Canara Bank

15.1. Canara Bank shall act as the nodal bank to coordinate the activities of PM-Vidyalaxmi
with IBA, member banks and DHE;
15.2. Canara bank shall develop and maintain the PM- Vidyalaxmi Portal as per the terms
& conditions of the MoU agreed upon between DHE & Canara Bank in this regard;
16.

Applicable date

16.1. The PM- Vidyalaxmi scheme shall be applicable for all education loans sanctioned
after 6th November 2024.
17.

Monitoring

8|P M - V i d y a l a x m i

– scheme guidelines Dept of Higher

Education, 2024

<!-- page 9 -->

17.1. The Department of Higher Education shall be monitoring the scheme through the PMVidyalaxmi portal, developed and maintained by Canara Bank as per the terms and
conditions of MOU executed between the DHE and Canara Bank in this regard.
17.2. Once the education loan is sanctioned and disbursed, bank shall update this
information on PM-Vidyalaxmi portal.
17.3. If the student has opted for interest subvention while availing loan, the application for
interest subvention along with information of its coverage under credit guarantee shall
reach DHE via portal.
17.4. DHE shall be consolidating, approving and disbursing the interest subvention amounts.
17.5. DHE shall check if the institution/ course comes under quality HEIs list in AnnexureA and self-declared income of the student comes within Scheme purview. An Aadhar
based de-duplication shall be run on PFMS to check if student is not getting any other
scholarship/ interest subvention benefit of GoI.
17.6. The student shall submit a self-certificate that she/he is not getting any other
scholarship or interest subvention benefit from any State government, as per format
given at Annexure 7.
17.7. The bank which has sanctioned education loan in PM-Vidyalaxmi shall also certify
that they have not given any other education loan to the student for this course, as per
format given at Annexure 8.
17.8. The eligible applicants for interest subvention will then be informed by the DHE to
upload further necessary certificate/ data as per scheme requirement such as income
certificate certified by competent State government authority, for further processing as
per Scheme guidelines.
17.9. The student and bank shall upload further necessary certificate/ data as per scheme
requirement.
17.10. Release of interest subvention from 2nd year onwards is subject to satisfactory
academic performance of the student as per scheme guidelines. The QHEI and student
shall be responsible for providing updated academic results as per course design. The
QHEI should actively endeavor to upload the academic results of each trimester/
semester/ year (as per their course design) in Automated Permanent Academic
Account Registry (APAAR), so that the student can provide his/ her consent for pulling
necessary academic results for this. If the QHEI has not uploaded the results in
APAAR, the student should submit self-attested copies of the result in the PmVidyalaxmi portal.
9|P M - V i d y a l a x m i

– scheme guidelines Dept of Higher

Education, 2024

<!-- page 10 -->

17.11. Lending banks and the student applicants will be jointly responsible to submit timely
and correct data, as per requirements of the scheme from time to time. Failure to do so
may result in non-disbursal of interest subvention or premature termination of the
benefits under the scheme. In such an eventuality, the lending bank shall be responsible
jointly with the student. The Department of Higher Education or service provider of
the portal shall not be held liable in any manner whatsoever.
17.12. The portal shall provide information to both the lending bank as well as the student
regarding status of their application, stage of processing, disbursal of subvention,
coverage of credit guarantee, etc. The student and the bank should see the portal from
time to time for completing any pending action on their part.
17.13. Subject to receipt of information from the students, banks, HEIs and NCGTC, the
portal shall provide information to the student applicants, the lending banks, the HEI
and the NCGTC on the following:
17.13.1.

Amount of loans sanctioned, date-wise disbursal and moratorium period,

17.13.2.

Coverage of PM-USP CGFSEL on education loan,

17.13.3.

Details of the student, including family income certificate, social group, contact
details, loan account details and academic results of each semester/ trimester
during the moratorium period,

17.13.4.

Status of receipt of verified certificates for processing the application,

17.13.5.

Status of de-duplication of student’s application,

17.13.6.

HEI details and HEI fee structure

17.13.7.

Whether the student has been selected for interest subvention,

17.13.8.

Details of interest subvention claim raised by the bank (date, amount of loan,
period of interest, amount of interest),

17.13.9.

Details of sanction of interest subvention by DHE (Date and amount)

17.13.10. Details of generation and sending of e-voucher/ Programmable CBDC wallet
amount to the student
17.13.11.

Details of all communications as well as reminders sent to the bank and student
regarding the scheme/ seeking information, etc.

17.13.12. Details regarding approval given by the student to credit e-voucher/
Programmable CBDC wallet amount to loan account of the student
17.13.13. Details of payments made to loan account of the student (date and amount),
17.13.14. Details of additional information required from the bank/ student in case of PFMS/
NACH failure
10 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 11 -->

18.

De-duplication with other scholarship or interest subvention on education loan
schemes of Government of India and state governments

18.1. Interest subvention under the Scheme will be provided to students who do not get
benefit under any scholarship scheme or any other interest subvention scheme of the
government of India/ State government.
18.2. Aadhaar will be used for de-duplication with scholarship schemes as well as other
interest subvention schemes of Government of India via Public Finance Management
System (PFMS).
18.3. For de-duplication process with State Government scholarship/interest subvention on
education loan schemes, a self-declaration will be taken from the students that they are
not getting any benefit of any scholarship or interest subvention/ credit guarantee
schemes on education loans from any State/UT governments. The banks should also
certify that they have not given any such education loan to the student.
18.4. If the declaration given by the student is found to be false at any subsequent date,
interest subvention shall be stopped immediately.
18.5. If a new applicant is found to be beneficiary of some other scholarship or interest
subvention scheme, she/he will be given an option to select one of the schemes. Once
the student exercises such an option and selects PM-Vidyalaxmi, de-duplication with
the PFMS shall again be conducted to ensure that benefit of PM-Vidyalaxmi flows to
a student who has not got any other scholarship or interest subvention benefit.
18.6. De-duplication will be conducted every year. A student found to be beneficiary of
another scheme in any of the years during the moratorium period will not receive
interest subvention benefit.
19.

Disbursement of Interest Subsidy Claims

19.1. Once the application for interest subvention gets approved, the student will get sms,
email and whatsapp message to install the e-voucher/Programmable CBDC wallets on
their mobiles.
19.2. On receipt of claims from Banks, interest subvention amount will be credited to evoucher/Programmable CBDC wallet of each student.
19.3. Once the student opts for redemption of the e-voucher/ Programmable CBDC towards
repayment of his/her education loan amount, this interest subvention amount shall get
credited to his/her education loan account through Direct Benefit Transfer (DBT)
11 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 12 -->

towards interest payment through Public Financial Management System (PFMS)
Portal and National Automated Clearing House (NACH), as per guidelines of the
Department of Expenditure, Ministry of Finance.
19.4. If the student does not exercise this option within 3 months of credit, the amount shall
be transferred back to the account of the DHE. In such a case, the student will not get
the interest subvention for that academic year.
20.

Interest Concession

20.1. In model education loans, the student is free to pay his/ her interest after the
moratorium period. Therefore, Lending Bank may provide up to 1% interest
concession if interest is serviced, partially or fully, either by the government or the
student or both, during the study period and subsequent moratorium period prior to
commencement of repayment. In short, the benefit of interest subvention by the
government needs to be appropriately passed on to the student.
21.

Claims by Regional Rural Banks (RRBs)

21.1. The Regional Rural Banks should submit their claim directly to Canara Bank, the nodal
bank and not to route it through the sponsor bank.
22.

Audit

22.1. Statutory Audit of the Accounts coinciding with the Annual Statutory Audit of the
Bank should be conducted once a year.
23.

Onboarding of beneficiaries of PM-USP CSIS and PM-USP CGFSEL, mentioned
at paragraph 6.3 of these guidelines) on PM-Vidyalaxmi Portal

23.1. The lending and disbursing bank (“Bank Head Office” or “Bank HO” hereinafter) shall
provide the details of the student beneficiaries of PM-USP CSIS and CGFSEL
according to the digital format specified for the purpose.
23.2. De-duplication of the student beneficiaries via PFMS shall be done following the same
process as is being followed for the beneficiaries of PM-Vidyalaxmi
23.3. Results of de-duplication shall be communicated to the student and Bank HO.
23.4. For students who are not duplicate, further due process for payment of interest
subvention shall follow.

12 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 13 -->

23.5. Students who have been identified as duplicate during PFMS de-duplication exercise
shall have the option to discontinue either the CSIS or the other scheme where she/he
is deriving the benefit. If they choose to continue in CSIS, rechecking her/his deduplication status through PFMS will be done. If the student’s de-duplication status is
found OK, the Bank HO and the student shall be intimated about submission of interest
subvention claims.
23.6. Once a student who was earlier found as a beneficiary of multiple government schemes
(central government or state government) is subsequently found as a person who is not
a beneficiary of such multiple schemes for the same academic year, interest subvention
shall be released following the due procedure.
23.7. However, if a student is found to be beneficiary of some other scholarship or interest
subvention scheme of any Ministry/ Department in the central government or the state
government for the same academic year or for the same course of study, interest
subvention benefits will not be given to them.
24.

Fraud Detection:

24.1. Lending Banks and the student applicants shall be jointly responsible to submit timely
and correct data, as per requirements of the scheme from time to time. Failure to do so
may result in premature termination of the benefits under the scheme. In such an
eventuality, the lending bank shall be responsible jointly with the student applicant.
The Department of Higher Education or service provider of the portal shall not be held
liable in any manner whatsoever.
24.2. If any information submitted by the bank or the student is found to be incorrect at a
future date, the student will be liable to refund the entire subsidy claim paid to her/
him. The lending bank will be responsible for recovery of this amount.
24.3. In case of such a detection, the student shall be debarred from any future benefit from
any other government scheme. In addition, other legal procedures, as applicable under
laws of the land might be initiated against such a student.
24.4. Appropriate action on the lending bank shall also be taken up in such cases if lapses
are on the part of the bank.
25.

Communications to the students:

25.1. While applying for education loan in the PM-Vidyalaxmi portal, the student shall be
declaring their annual family income in the portal. However, no family income
13 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 14 -->

certificate is to be uploaded at that time. Banks need to upload the loan sanction related
details (date of sanction, amount sanctioned for entire course duration, disbursement
amount to the QHEI, disbursement to the student, etc. as stipulated in the portal from
time to time.
25.2. Based on all the education loans where the sanction and disbursement has happened
during a financial year, the applications where annual family income is less than ₹ 8
lakhs will be shortlisted and the applicants will be intimated to apply for the interest
subvention benefit, as applicable to them, in the same portal using the student’s login
ID. If the student does not apply within a stipulated period, she/ he will not be eligible
to apply for interest subvention in that year.
25.3. Once the student applies for interest subvention with all completed documents, the
application shall be sent to PFMS for de-duplication. The student shall be able to see
this status in their login.
25.4. The results of the de-duplication exercise will be intimated to the student.
25.5. In the first year, if the student is found to be a beneficiary of some other scheme, she/
he will get an opportunity to exercise option to either continue with the earlier benefit
or PM-Vidyalaxmi portal.
25.6. The student should exercise the option within 15 days of intimation about deduplication.
25.7. After that, selection of students for 3% interest subvention will be done. The results of
the process will be intimated to the students by SMS and whatsapp messages. This will
also be available in the portal for all the stakeholders information.
25.8. Once the students’ interest subvention has been processed and amount sent to the
digital wallet (e-voucher/ CBDC wallet), the same will be intimated to the student.
25.9. The student must exercise her/ his option to use this amount for payment to her/ his
education loan account within the stipulated deadline. If the student does not exercise
the option of payment within the stipulated deadline given in paragraph 19.4, she/ he
will not be eligible to get interest subvention benefits for that year.
25.10. The student should check the portal periodically for information on cut-off dates and
stages of application.
26.

Contact us:

26.1. For any query related to application process of PM-VIDYALAXMI:

14 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 15 -->

Section Officer (National Scholarships)
National Scholarship Division,
Ministry of Education, Department of Higher Education,
West Block 1, 2nd Floor, Wing 6, Room No. 6,
R. K. Puram, Sector 1, New Delhi- 110066.
Tele: 011- 20862360
E-mail: es3.edu@nic.in
Canara Bank Head Office,
Canara Bank , Head Office,
Retail Asset Wing,
2nd Floor, Jeevan Prakash Building,
No 113-1, JC Road, Bengaluru - 540002
Tele: 080- 22533876
Email id:- hoel@canarabank.com
26.2.

Once a login ID is created for the student, all subsequent queries/ grievances, etc.
should be lodged in the student login part of the portal.

26.3.

Appropriate mechanism to address and resolve the complains will be developed
keeping the Lending Banks in loop.

15 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 16 -->

Annexure-1
Illustrative Examples of Collateral free, Guarantor free education loans, irrespective of
annual family income or number of students getting such loan or amount of loan
o

Institute-1 is in quality HEI list
o In Institute-1, course fee for a 2-year MBA course is ~ ₹25 lakhs;
o Let us assume that hostel, laptop, mess and other out-of-pocket expenses are
20% in 2 years i.e ~ ₹ 5 lakhs. Other expenses limit is as per the Model
Education Loan Scheme of IBA.
o Then any student of this Institute and this course can avail collateral-free and
guarantor-free education loan for up to ₹ 30 lakhs,

o

Institute-2 is in quality HEI list
o In Institute-2, course fee for a 4-year B.Sc. course is ~ ₹8 lakhs;
o Let us assume that hostel, laptop, mess and other out-of-pocket expenses are
20% in 4 years i.e ~ ₹ 2 lakhs. Other expenses limit is as per the Model
Education Loan Scheme of IBA.
o Then any student of this Institute and this course can avail collateral-free and
guarantor-free education loan for up to ₹ 10 lakhs,

o The loan disbursement will be as per institution and students’ requirement
o No ceiling of family income for such education loans
o No ceiling of loan amount for such education loans

16 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 17 -->

Annexure -2
Illustrative Example of 3% interest subvention to be given to one lakh students every year
on education loan for students with annual family income up to ₹ 8 lakhs.
o The student has taken an Education loan of ₹ 30 lakhs for a 2 year course.
o Out of 30 lakhs, in first year (2024-25), depending on students’ and QHEI’s requirement,
Rs ₹ 16 lakhs is disbursed by the bank at one go.
o Let us assume that 8.5% interest rate is being charged by bank.
o As simple interest rate is charged by banks during moratorium period, an interest of Rs ₹
1.36 lakhs will be due in FY 2025-26.
o Interest subvention is provided for loan amount up to Rs 10 lakhs. On ₹ 10 lakhs, @3%
interest for one year, interest will be ₹ 30,000
o Thus, in 2025-26, student will pay ₹ 1.06 lakhs and central government will pay ₹ 30,000.
o Further, in 2025-26, Bank disburses remaining Rs 14 lakhs for second year to student.
o In second year also, government shall pay subsidy of 3% on Rs 10 lakh outstanding. Student
shall pay remaining interest.
o Thus, in 2026-27, student shall pay ₹2.25 lakhs interest and central government shall pay ₹
30,000 interest.
o Since 2027-28 is the last year of moratorium period, student shall pay ₹2.25 lakhs interest
and central government shall pay ₹ 30,000 interest.
o However, if the student repays ₹ 25 lakhs after 2nd year and remaining outstanding is only ₹
5 lakhs, then interest accrued in 2027-28 is ₹42,500. 3% interest on outstanding amount is
₹15,000. Therefore, student pays ₹27,500 and central government pays ₹15,000 as interest
for this year.
o After moratorium period (course + 1 yr) period is over, student shall repay entire principal
and interest and government shall not pay any amount.

17 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 18 -->

Annexure-3
Elaboration on process of Institution selection under quality HEI list
o Criteria for selection under quality HEI list is
1. Top 100 ranked HEIs in the overall/ category-specific and/or domain specific
rankings in latest list of NIRF published by the Ministry of Education; plus
2. Top 200 ranked HEIs under the governance of state/ut governments in the latest
list of NIRF published by the Ministry of Education; plus;
3. All remaining HEIs under the governance of Government of India.
o NIRF ranking 2024 has been considered to make the first list for AY 2024
o NIRF has ranked HEIs under overall, category-specific and domain
specific ranking which are as follows:
o Categories are Overall – 200, University – 200, College – 300,
state public universities - 100
o Domains are Engineering – 300, Management – 125, Medical –
50, Pharmacy – 125, Law – 39,
o As per criteria 1: In NIRF top 100 under overall, category-specific and
domain specific ranking a total of 468 different HEIs are taken
o Eg. IIT Madras appears in overall, engineering and
management ranking – it is counted once
o As per criteria 2: Between NIRF 101-200, another 88 State Govt HEIs
are taken
o University: 51, college: 36, standalone institution: 1
o As per criteria3: Another 304 central government HEIs have been
taken from different ministries in central government
o Together, it gives 860 quality HEIs eligible for PM-Vidyalaxmi
covering 22 lakh fresh students each year
o List will be updated based on NIRF rank each year
o A student selected for PM Vidyalaxmi shall continue to get support even if the HEI’s
cannot enter updated list in subsequent year

18 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 19 -->

Annexure 4: List of quality Higher Education Institutions (QHEIs) for the year 2024-25

19 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 20 -->

Annexure 5: State-wise distribution of 1,00,000 slots for 3% interest subvention under
PM-Vidyalaxmi for 2024-25
Sl.
No.

State/UT

Population
(18-23 years)

distribution of slots for 3% interest
subvention

1

A & N Islands

36,066

24

2

Andhra Pradesh

51,81,200

3,428

3

Arunachal Pradesh

1,77,069

117

4

Assam

40,16,400

2,657

5

Bihar

1,55,73,188

10,302

6

Chandigarh

1,27,714

84

7

Chhattisgarh

33,33,600

2,205

8

Delhi

25,32,754

1,676

9

Goa

1,36,320

90

10

Gujarat

72,01,018

4,764

11

Haryana

32,89,200

2,176

12

Himachal Pradesh

7,33,400

485

13

Jammu and Kashmir

16,28,600

1,077

14

Jharkhand

47,34,600

3,132

15

Karnataka

66,55,600

4,403

16

Kerala

31,28,800

2,070

17

Ladakh

27,409

18

18

Lakshadweep

6,081

4

19

Madhya Pradesh

96,63,008

6,393

20

Maharashtra

1,28,67,200

8,512

21

Manipur

3,67,017

243

22

Meghalaya

3,78,940

251

23

Mizoram

1,44,397

96

24

Nagaland

2,72,117

180

25

Odisha

48,18,800

3,188

26

Puducherry

1,11,238

74

27

Punjab

30,82,600

2,039

28

Rajasthan

93,45,800

6,183

29

Sikkim

87,169

58

30

Tamilnadu

69,37,600

4,590

31

Telangana

39,14,800

2,590

32

D & N Haveli and Daman & Diu

93,217

62

33

Tripura

4,83,507

320

34

Uttar Pradesh

2,85,62,243

18,895

35

Uttarakhand

13,39,400

886

36

West Bengal
All India

1,01,64,800

6,724

15,11,61,000

1,00,000

20 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 21 -->

Illustrative examples of allocation of slots within a State following priority criteria mentioned
in Paragraph 3 of the guidelines:
i.

Example 1: In Andhra Pradesh, 5000 eligible applications received after de-duplication.
3000 are from government and 2000 are from private. Note that total slots for Andhra
Pradesh is 3,428 as per state-wise allocation given above.
a) First, all 3000 applications from government HEIs will be selected,
b) Among 2000 applicants from private HEIs, priority will be given to
professional/ technical courses. Suppose 1500 applications are from
professional/ technical courses.
c) Among 1500 applications, priority will be given to those who have passed
higher secondary from government institutions. Suppose 300 passed higher
secondary from govt. institutions. These 300 will be selected.
d) For remaining 1200 applicants, priority will be given to those who have passed
secondary from government institutions. Suppose 50 passed secondary from
govt. institutions. These 50 will be selected
e) For remaining 1150 applicants, priority will be given to those who have passed
higher secondary from rural school. Suppose 50 passed higher secondary from
rural schools. These 50 will be selected.
f) For remaining 1100 students, priority will be given to girl students. Suppose
there are 100 girls among these 1100 applicants. Then remining 28 slots will be
given to girls with lowest annual income.

Note that, if some of the states have less applications, the vacant slots of that state shall be
allotted to remaining states on pro-rata basis using the inter-state ratios from the above table.
That has not been considered in steps (a) to (f) of example 1.
ii.

Example 2: In Uttar Pradesh 18,000 applications are received and total slots are 18,895.
Then, all applications will be selected. The 895 excess slots will be allotted to remaining
states on pro-rata basis.

Notes:
1. If a student has passed higher secondary from Uttar Pradesh Board and has been
admitted in a HEI at Tamil Nadu, the student will be considered against slot allotted
for Uttar Pradesh.
2. There will be no upper limit on number of applicants from a government HEI.
3. If total applications from Private HEIs are large, cut-off on number of eligible students
from a private HEI will be applied only if total applications exceed the state-wise total
slots. Otherwise, information will be sent to remaining HEIs of that state that they
need to raise awareness of their students regarding availability of the scheme.

21 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 22 -->

Annexure 6
Format of certificate from quality Higher Education Institution (QHEI) for students who
have provided income/ caste/ benchmark disability certificates to the QHEI
(The certificate is to be given in letter head of the QHEI with signature and seal of Vice
Chancellor/ Principal / authorised regular employee of the QHEI)
This is to certify that:
1. Shri/ Ms. ________________ s/o/d/o ______________________, bearing AADHAAR no
_____________________ is a Bonafide student of this institute.
2. He/ She has taken admission in the course _______________ of this institute on _______
(DD/MM/YYYY) and duration of the course is ____ years.
3. The total fee for the entire duration of course (including registration fee, admission fee, tuition fee,
hostel fee and all other non-refundable and refundable fees put together) is approximately ₹
________ lakhs, the trimester-wise/ semester-wise/ year-wise (strike off which are not applicable)
details of which is enclosed.
4. It is further certified that the following certificates submitted by Shri/ Ms. ________________ has
been duly verified by our institute (strike off whichever is not applicable):
a) Board/ Council certificate of higher secondary examination, which states that he has completed
his higher secondary from the Board/ Council of __________ in the year ____.
b) Board certificate of secondary examination, which states that he has completed his secondary
examination from the Board of __________ in the year ____.
c) Annual family income certificate from designated public authority which states that his/her
annual family income from all sources in the year ____________ is ₹___________ only (family
is defined as the student plus father plus mother plus spouse, wherever applicable).
d) Persons with Benchmark Disability certificate, which states that he/ she is a case of
__________ and he/ she has __________% permanent disability (as per guidelines).
e) Caste certificate, according to which he/ she is from Scheduled Castes (SC) / Scheduled Tribes
(ST) / Non-creamy layer Other Backward Classes (NC-OBC) (strike off whichever is not
applicable).

___________________
Signature
Full name :
Designation:
Office Seal

22 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 23 -->

Annexure 7
Format of certificate from students regarding non receipt of any other scholarship /
interest subvention on education loan from any ministry/ department/ institution/
organization in central government or state government

This is to certify that:
1. Myself, Shri/ Ms. ________________ s/o/d/o ______________________, bearing AADHAAR no
_____________________ is a Bonafide student of _________________ (name of institute).
2. That I have taken admission in the course _______________ of this institute on _______
(DD/MM/YYYY) and duration of the course is ____ years.
3. That, I am neither selected nor receiving any other scholarship from any Ministry/ Department /
Autonomous Body/ Commission/ Institution/ Organisation in the central government or any
state/UT government.
4. That, I am neither selected nor receiving any other interest subvention on education loan from any
Ministry/ Department / Autonomous Body/ Commission/ Institution/ Organisation in the central
government or any state/UT government.
5. That, if I am selected for interest subvention benefit under PM-USP CSIS or under PMVidyalaxmi, I shall not avail of any other scholarship or interest subvention benefit from any of
the agencies specified in points 3 and 4 above.
6. That, if the certificate given by me is found to be false on any future date, I shall not be debarred
from all these benefits.
7. That, if the certificate given by me is found to be false in any future date, I shall return entire
interest subvention benefit received by me to the bank, so that it can be returned to the concerned
government department who has released the interest subvention.

___________________
Signature
Full name of student: ______________________________

23 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024

<!-- page 24 -->

Annexure 8
Format of certificate from banks regarding non receipt of any other scholarship / interest
subvention on education loan from any ministry/ department/ institution/ organization in
central government or state government
This is to certify that:
1. Shri/ Ms. ________________ s/o/d/o ______________________, bearing AADHAAR no
_____________________ is a Bonafide student of _________________ (name of institute).
2. That Shri/ Ms. ________________ have taken admission in the course _______________ of this
institute on _______ (DD/MM/YYYY) and duration of the course is ____ years.
3. That, as per records verified by this bank, Shri/ Ms. ________________ has not been sanctioned
any education loan which provides interest subvention benefit by any other Ministry/ Department
/ Autonomous Body/ Commission/ Institution/ Organisation in the central government or any
state/UT government.
4. That, if the certificate given by the bank is found to be false on any future date, the bank shall
refund all the interest subvention benefits given to this student by the government. In addition, the
government shall be free to take other administrative and legal actions on the bank and personnel
involved in this certification process.
___________________
Signature
Full name: ______________________________
Designation and bank seal:

-------------------------------------------

24 | P M - V i d y a l a x m i – s c h e m e g u i d e l i n e s D e p t o f H i g h e r

Education, 2024
