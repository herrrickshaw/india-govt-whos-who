---
doc_id: "dc4acf1f3dd6ba54"
source_url: "https://dof.gov.in/static/uploads/2025/09/e289057e5ad3d944b9c6839223a8d142.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Observance of the countdown to International day of Yoga -2022 -reg"
date: "2021-05-06"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "355ce5c99a6f8480"
---

<!-- page 1 -->

1
it of Fsheries
eee ee arene tS Ne: ASUST2TINORS Adri (Part) (e-20252)
भारत सरकार
Government of India
मत्स्यपालन, पशुपालन और डेयरी मंत्रालय
Ministry of Fisheries, Animal Husbandry and Dairying
मत्म्यपालन विभाग
Department of Fisheries
प्रथम फ्लोर, चंद्रलोंक विल्डिंग,
जनपथ, नई दिल्‍ली
दिनांक 06 मई, 2021
OFFICE MEMORANDUM
Sub: Observance of the Countdown to International Day of Yoga- 2022- Reg
The undersigned is directed to say that International Day of Yoga-2022 will be
Organized on 21" June, 2022 and this year to commemorate the 75” year of
Independence, Government of India 18 celebrating “Azadi ka Amrit Mahotsav’ A
countdown to International Day of Yoga- 2022 is being organized in all the
Ministries/Department and this Department has been allotted 9" May, 2022 for
Organizing event for countdown.
Zi Accordingly, it has been decided to organize the countdown on 09” May,
2022 at 07:30 AM. All the Officers and Staff of Department of Fisheries are
Tequested to assemble in the Parking Area (Near Gate No. 4) of Krishi Bhawan by
07:15 AM for the Organizing Yoga demonstration and activity. 7
७
x
whe
(Sheema Chakrabarty)
Under Secretary to the Government of India
Distribution:
1. PSO to Secretary (Fisheries)
2. PS to JS (Admn)/JS (MF)
3. All Officers and Staff, Department of Fisheries, New Delhi
4. NIC with the fequest to upload the above OM on the official website of the
Department '
