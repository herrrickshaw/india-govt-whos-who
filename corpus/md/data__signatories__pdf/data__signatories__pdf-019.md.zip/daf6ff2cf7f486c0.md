---
doc_id: "daf6ff2cf7f486c0"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/07/dedb044c7d59df3ce065d183736bdadc.pdf"
ministry: "Tourism"
title: "Approved Guidelines for Financial Assistance to State Government / Union Territory Administrations for Organizing Fair and Festivals and Tourism related Events"
date: "2025-07-16"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e9448b7336e25aa1"
---

<!-- page 1 -->

Government of tndia
Ministry of Tourism
(Publicity, Events and IT Division)
No.9(3 1)/202 1-100

st
1 April, 2022

Approved Guidelines for Fina ncial Assistance to State Government I
Un ion Territory Admin istrations for Organizing Fair and Festivals and
Tourism related Events

The Ministry of Tou ri sm shall provide fi nancial assistance to State
Governments I UT Administrations for organ izi ng fai rs I festivals and
tourism re lated events such as seminars , conclaves , convention s etc. for

the promotion of tourism under Domestic Promotion and Publicity including
Hos pita lity (OPPH) Scheme . The co nditions for provid ing the financial
assista nce would be as under :1.

The fa irs, festiva ls and events should be selccted by the State
Governments I UTs based on their tourism potential.

2.

Ministry of Tourism , Government of Ind ia would provide a
max imum financial assista nce of Rs . 50 .00 Lakh per fai r I festiva l
I event in the case of States and Rs . 30 .00 Lakh in case of Union
Territory .

3.

Maximum financial assistance to be provided to each State

Government I UT Administration during 1 linancial year shou ld
not exceed Rs 80.00 lakh for all fairs/festivals and Tourism
related Events . The Financial Ceiling for the Union Territories
would be Rs. 50 00 Lakhs .
Assistance for maximum of 6 fairsl festivals l event will be

provided

to t ~1f~ State Govern men t of Union terri tories during one financial

year . In case of more th an 6 fairs fo r a particular state, 2 more fa irs
can be considered on receivi ng the fu ll justification about the same
and approval of Secretary (Tourism ) will have to be obtained for
considering such requests . However, the ceili ng ind icated in 3 above
wou ld rema in .

<!-- page 2 -->

5.

The fair, festival or event should be Identified by the States I UTs
based on their potential for the development
and promotion of tourism and informed to the Ministry of Tourism
well in advance.

6.

Central Financial Assistance wou ld be provided only for the
following items :i)
Creation of semi permanent structures .
ii)
Production of posters, pamphlets , advertisement in newspaper and production of film .
iii)
Remuneration of artists.
iv)

Sitting arrangements , lighting , sou nd , lodging & boarding,
transportation , hiring of space and other similar activities .

7.

Prior approval of the Ministry of Tourism should be taken before
comm itting any expend iture and proposals shou ld be sen t to the
Ministry at least 2 months in advance of the event. No assistance
would be extended on cx-post facto basis .

8.

Support of the Ministry of Tourism wou ld be subject to
availability of funds and relevance of the event.

9.

Adequate publicity to the Ministry of Tourism would be given in
the different advertisements or media releases issued by the
State Govmnments I UTs . Ministry's logo (Incmd lble India) and
website would also be given due publicity

10.

The State Government I UT Governments organizing the event
would contribute alleast 50 % of the tota l expendi ture involved on
the fair I festival or event.

11 .

Ministry of Tou rism will re lease 100% amount towards the
proposa ls approved . However, 3 proposa ls only , can be
submitted by the State Government I Union Territory
Administrations in the first instance. No fair I festival I event
proposal will be considered thereafter unless the State
Government submits full details of the

<!-- page 3 -->

expenditure (including State I UTs components) and Uti lization
Certificate for the amount with a brief note on the advan ta ges
gained as the outcome of fair I festival I event towards the
assistance provided fo r 3 proposals . Subsequently, the other
proposal can be sent to Ministry of Touris m as mentioned in para
4 above.
12 .

The proposal for the financial assista nce should include in details
the break- up of exp enditure and the agencies involved in
organIZing the event. The proposal shou ld
also include the na mes of sponsors if any , and the amount being
contributed by them.

13 .

The State Governments I UTs must follow all cod al formalities
wh il e spend ing the money re leased by the Ministry of Tourism as
fi nancial assista nce.

14.

To the North-Eastern States including Sikkim and the state of
Ja mmu and Kashmir , 100 % assistance may be provided by the
M in istry of Tourism, Government of Ind ia .

Instructions for MoT s Divi sions

1.

The proposals rece ive d from the State Governments I Union
Terrilory Administrations will be processed by the con cerned
programme I planning division of the Ministry. Wh ile processing
proposa ls for 2010-11 , in respect of any State I UT, the sta tu s of
Ulilizatlon Cer\!ficates (UCs) pend ing for the years upto 2009-10
in respect of that State I UT shall also be indicated .

2.

Th e concerne d division Wi ll open only one file for each State I
Union Territory during one financial year for all the fa irs I festiva ls
I events of that Stale I UT.

3

The DiVision will try to ensure th at UCs and other detai ls are
rece ived from the Sta tes I Union Te rri tories in time .

<!-- page 4 -->

4.

Preference would be given to the proposals rece ived online and
online submission of UG:s and other deta ils w ill be encouraged .
