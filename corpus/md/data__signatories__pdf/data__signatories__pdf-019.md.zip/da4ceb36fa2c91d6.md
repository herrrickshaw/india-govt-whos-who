---
doc_id: "da4ceb36fa2c91d6"
source_url: "https://steel.gov.in/sites/default/files/2025-10/Steel%20grade%20exemption%20order%20%28lot%203%29%20dated%2015.10.2025.pdf"
ministry: "Steel (MoS)"
title: "Steel grade exemption order (lot 3) dated 15.10.2025.pdf"
date: "2025-10"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ae83a2a5368f6b44"
---

<!-- page 1 -->

<!-- page 2 -->

Annexure 1- Lot 3: List of grades for exemption
Sl No.

Grades

Product Description

Quantity Half
yearly (in
Ton per end
user)

1

50BV30

Alloy Steel wire rods

250

End use

Dimension

Product condition

Hand tools

Any

Chemistry (C: 0.27-0.33%, Si: 1%
max, Mn: 0.7-1%, Cr: 0.32-0.5%, V:
0.1-0.15%, B: 0.0005 max)
