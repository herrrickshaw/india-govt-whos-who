---
doc_id: "ddcde95da9a7f5ae"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/a0db22a3e3a14561b9da9ef51b6312b2.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer & posting of officers in SAG of ITS Group A- Shri Vinod Kumar, Staff no. 20814"
date: "2025-07-17"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "212cfc4bc9c0be35"
---

<!-- page 1 -->

12-3/2025-STG-I

I/3297100/2025

No. 12-3/2025-STG-1
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi
Dated the 17th July 2025
OFFICE ORDER
Subject: Transfer & posting of officers in SAG of ITS Group ‘A’-reg.
Approval of the competent authority is hereby conveyed for transfer and
posting of following officer in SAG of ITS Group ‘A’ with immediate effect:
S.No.

Staff
No.

Name of the Present Place of Posting
officer
Posting
Transfer
(Shri/Ms.)

1.

20814

Vinod Kumar

on

DDG(SRI), DoT HQs TEC

2.
Shri Ashok Kumar [Staﬀ No. 20620], DDG UP (W) LSA is hereby entrusted
with the charge of DDG (SRI), DoT HQs in addition to his present responsibilities
and without any extra remuneration
3.

Charge report may be furnished to all concerned. Hindi version will follow.

(Vivek Krishna Verma)
ADG (STG-III)
Tele 011-2303 6282
Copy to:
1. PS to Hon’ble MoC /APS to Hon’ble MoSC
2. Chairman, DCC/ Member(S)/ Member (T)/ Member(F)/ DG Telecom, DoT;
3. AS(T)/ Administrator USoF / All Advisors, DoT;
4. CMD, BSNL/MTNL;
5. All Heads of LSA/TEC/NTIPRIT/NCCS;
6. CVO, DoT HQ;
7. All DDGs, DoT HQs/ DDG(C&A) DoT Hqrs;
8. ADG (APAR)/AD (STG-I)/AAO (STG-I), DoT HQs;
9. SO, Pay Bill Section/ SO (O&M);
10. The Officers concerned;
11. Official Language Section, DoT for Hindi version of the order.
