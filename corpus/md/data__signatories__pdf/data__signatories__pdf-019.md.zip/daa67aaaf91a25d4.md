---
doc_id: "daa67aaaf91a25d4"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_68bea51fd116f8.66576021.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Office Order - Dr. G. Trinadh Kumar, IFS(AGMUT 2002), IGF (C) assigned the additional charge of Regional Office, Gandhinagar, order dated 25.06.2025"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "80cb52af70d611fa"
---

<!-- page 1 -->

Computer No: 148698

No. 12016/05/2021-IFS.|
Government of India
Ministry of Environment, Forest and Climate Change
rrRx

6t Floor, Prithvi Wing,
Indira Paryavaran Bhawan, Jor Bagh Road,
Ali Ganj, New Delhi-110003.

Dated

25" June, 2025.

OFFICE ORDER
Dr. G. Trinadh Kumar, IGF (C), Sub-Office Hyderabad, is hereby assigned
the additional charge of Regional Office, Gandhinagar with effect from 01.07.2025
until further orders in addition to his existing work.
This has the approval of competent authority.

o)5 b\w((
(Prem Prakash Maurya)
Under Secretary to the Govt. of India
Ph - 011-20819192

Distribution :
i. PS to Hon'ble Minister of Environment, Forests and Climate Change;
ii. PS to Hor'ble Minister of State Environment, Forests and Climate Change;

iil. PPS to Secretary, MoEF& CC;

iv. PPSs to DGF & SSYADGF(WL)/ ADGF(FC)/ ADGF(PT)/CEO (CAMPA);
v. PSs to All IGFs/JSs/Jt. CEO(CAMPA)
vi. JS(Admin), MoEFCC, New Delhi;
vii. All DIGFs/AIGFs;
viii. Concerned officers;
ix. All Regional Offices/RO(HQ);
x. NIG cell for uploading on website;
xi. Reference Folder.
