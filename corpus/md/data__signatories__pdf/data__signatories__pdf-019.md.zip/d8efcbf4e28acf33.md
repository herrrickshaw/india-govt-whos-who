---
doc_id: "d8efcbf4e28acf33"
source_url: "https://powermin.gov.in/static/uploads/2025/06/2cc2e107f8b5c0f9b39fdb05ccc00d13.pdf"
ministry: "Power"
title: "Office Order Dated 21st February, 2013 (Director/DS)"
date: "2025-06-28"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "bd7b793db4b7f9fe"
---

<!-- page 1 -->

८3838»
| |
=
No. 1/3/2011-Adm.II
भारत सरकार
Government of India
विद्युत मंत्रालय
Ministry of Power
Shram Shakti Bhawan, Rafi Marg, New Delhi - 110001
Telephone No. 23715507; FAX No. 23717519
Dated th S
meee 21 FEB 2013
OFFICE ORDER
In supersession of all previous orders regarding Link Officer Arrangement at the
level of Director/Deputy Secretary in the Ministry of Power, the following shall be the “Link
Officer Arrangement” in the Ministry with immediate effect until further orders:
Name of the Officer Name of the Officer
No
1. | Shri Rajiv Kumar Gupta, <---> | Shri C.J.Jose,
Director (Hydro) Deputy Secretary(Coord)
2. | Shri P.T. Bhutia, <---> | Shri K.L. Sharma,
Deputy Secretary (EC Deputy Secretary (T&R)
3. | Shri N.Sriraman, <---> | Shri R.Chaturvedi,
Deputy Secret: (Admn.I Deputy Secretary (Admn.II)
4. | Shri Alok, Director <---> | Shri V. Apparao
(Thermal & IC. Director (IPC/St.Th)
5. | Shri Ghanshyam Prasad, <---> | Shri Arun Kumar,
Director (OM Director (P&P)
Shri Sanjeev Kumar, <---> | Shri Pranay Kumar, Shri Sanjeev Kumar
Director (RE, RGGVY & IT) Director (R&R and V&S) will be the Link Officer
except for the work
relating to V&S.
"2
2s In the absence of both the Link Officers, the concerned Under Secretaries shall gubmit
the files direct to the concerned Divisional Head. -
Cy o
.P. Bose )
Under Secretary to the Government of India
® : 2371 5327
Copy to:
1. Officers concerned.
जज 2. PS to Minister of Power/PS to Minister of State for Power. |
3. PPS to Secretary(P)/PSO to AS(AL)/PPS to AS(DC), Ministry of Power
. 4. All Officers/Desks/Sections/Units in the Ministry of Power. %
| 5. Technical Director, NIC Cell, Ministry of Power, for updating the Intrapower
6. Personal Files/Office Order File/Incumbency folder
