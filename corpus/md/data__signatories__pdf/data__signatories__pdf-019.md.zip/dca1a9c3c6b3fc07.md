---
doc_id: "dca1a9c3c6b3fc07"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/9daea1e7a23e6d7fcf8bd67d7b04f91d.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment of Recruitment Rules for the posts of Stenographer Grade-C proposed as Stenographer Grade-I at CDTL, Mumbai. CDSCO, DGHS, MoHFW."
date: "2022-09-04"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e11a49b48bbc731f"
---

<!-- page 1 -->

A.12018/05/2022-DRS-Part(VlI)
Government of India

Ministry of Health and Family Welfare

Department of Health and Family Welfare
(Drugs Regulation Section)
*****

Dated:ofAugust,2022
NOTICE

This Ministry is examining a proposal for amendment of Recruitment Rules for the post of
Stenographer Grade-C proposed as Stenographer Grade-I at Central Drugs Testing Laboratory(CDTL),
Mumbai, Central Drugs Standard Control Organisation (CDSCO), Directorate General of Health
Services, Ministry of Health & Family Welfare. In this regard, draft Recruitment Rules have been
prepared, a copy of which is attached.

2.

Before finalizing the same, comments, if any, are invited from all stakeholders in the matter

within a period ofthirty days from the date ofthis notification on the website ofthe Ministry of Health
and Family Welfare. The comments/objections/suggestions received from the stakeholders within the
specified period shall be considered by the Ministry as per rules/requirement before finalizing the
Recruitment Rules.

3.

The comments may be furnished to undersigned Room No.434-C,'C Wing, Nirman Bhavan,

New Delhi-110011 or may kindly be sent to drugsdiv-mohfw@gov.ln.

Encl:A/a.

(Bikash R. Mahato)

Under Secretary to the Government of India
Tele:-011-23061141

<!-- page 2 -->

Schedule

Name of post.

Number of

Classification.

post.

Level in pay
matrix or pay
scale.

Ill
STENOGRAPHER
GRADE T'

(2)

(3)

(4)
Pay Level-6
Service Group-B with Pay Scale
*1992-Subject -Non
Gazetted (Rs. 35400to
variation Non-Ministerial
112400)
depends ^ on
*01

General

Central

workload

Whether

Age-limit for direct recruits.

selection
post or nonselection
post.

(5)
N.A

(6)
30 years.
Notel :Relaxable for Government

servants up to five years in accordance

with the instructions or orders issued by
the Central Government.

Note2: The crucial date for determining
the age limit shall be the closing date
for receipt of applications from
candidates in India and not the closing
date prescribed for those in Assam,
Meghalaya, Arunachal Pradesh,

Mizoram, Manipur, Nagaland, Tripura,
Sikkim, Ladakh Division ofJammu and

Kashmir State, Lahaul and Spiti
District and Pangi sub-Division of

Chamba District of Himachal Pradesh,
Andaman and Nicobar Islands or

Lakshadweep.
Educational and other qualifications required for direct Whedier age and education^ Period of probation,ifany.
recruits.
qualifications prescribed for
direct recruits will apply in the
case of promotees.
(8)
iZI
(9)
Essential! Qualification:

(1) Degree from recognised university or equivalent

Not Applicable

Two years for direct recruitment

<!-- page 3 -->

(2)Speed in Stenography
(i)Shorthand (100/120 words per minute)
(ii)Typewriting(40-50 words per minute)
If a Departmental Promotion Circumstances in which Union Public
deputation/ Committee exists, what is its Service Commission is to be consulted
whether
by
direct promotion/
in making recruitment.
recruitment
or
by transfer, grades from which composition.
Method of recruitment In case of recruitment by

deputation/
promotion
or
by promotion/
deputation/ transfer and transfer to be made.
percentage
of the
vacancies to be filled by
various methods.

(10)

(12)

nil
Group

'B'

Departmental

Transfer on Deputation;
on
By
Transfer
deputation failing which Stenographer in the Pay Promotion Committee(for
Level - 4 with Pay Level promotion/confirmation):
by direct recruitment.
(Rs. 25500-81100) with 5
years regular service in the 1.Drugs Controller General
grade
or
equivalent (India)-Chairman
working
in
the
government/subordinate
2. Director, Central Drugs
office and attached office of Testing Laboratory -Member

(13)
Not Applicable

government.

Deputy
Director
Note: The period of 3.
Administration
(Drugs)-Member
deputation including the
period of deputation in
another excadre post held
immediately preceding this
appointment in the same or
some

other

organisation/department of
the

central

Government

shall ordinarily not exceed
three years.

..J

<!-- page 4 -->

[F:No. A.12018/05/2022-DRS-Part(VII)]

(Bikash R. Mahato)

Under Secretary to the Government of India
