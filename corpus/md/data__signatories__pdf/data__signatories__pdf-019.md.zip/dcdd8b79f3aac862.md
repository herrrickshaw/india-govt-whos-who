---
doc_id: "dcdd8b79f3aac862"
source_url: "https://www.dot.gov.in/static/uploads/2026/09/0d5c027956e786c2e9727fdabf5d420a.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of Class A ISP License, bearing no. 820-1103/2010-LR Dated 22.09.2010, for All India Service Area, granted to M/s Sisam Technologies Private Limited"
date: "2026-09-18"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "36e3d36100a7f457"
---

<!-- page 1 -->

820-1103/2010-LR(Vol-II)

I/3445077/2026

WITHOUT PREJUDICE
F. No. 820-1103/2010-LR(Vol-II)
Government of India
Ministry of Communications
Department of Telecommunications
(Data Services Cell)
Sanchar Bhawan, 20, Ashoka Road
New Delhi-110001
Dated: 18-09-2026
To,
M/s Sisam Technologies Private Limited
(a) 804, Maniprabhu Apptt., Nr. O.P. Chamber. Navrangpura Six Roads,
Navrangpura, Ahmedabad - 380014 (Gujarat).
(b) Ground Floor, Paresh Co-op Housing Soc. Ltd., Nr. Chaitanya Bus Stop,
Opp. Old GNFC Tower, Naranpura, Ahmedabad- 380014 (Gujarat).
Email: mukeshjainco@yahoo.com

Subject:- Termination/Revocation/Cancellation of Class A ISP License,
bearing no. 820-1103/2010-LR Dated 22.09.2010, for All India Service Area,
granted to M/s Sisam Technologies Private Limited, in terms of condition no.
10.2 (i) of Part-I of the said License Agreement.
Whereas, Department of Telecommunications, Government of India (“the
Licensor”) has granted a Class A ISP License, bearing no. 820-1103/2010-LR
Dated 22.09.2010 (“the License”), for All India Service Area, to M / s Sisam
Technologies Private Limited ("the Licensee").
2.
Whereas, the Licensee is required to provide the services under the terms
and conditions of the License and instructions issued by the LICENSOR from time
to time.
3.
Whereas, as per National Security Directive on Telecommunication Sector
(NSDTS), the licensees are required to connect only Trusted Products in its
network with eﬀect from 15th June 2021. Condition 34.29 of the Part-VI (Security
Conditions) of the ISP License Agreement further stipulates that, with eﬀect from
15th June 2021, the licensee, shall only connect Trusted Products in its network
and also seek permission from Designated Authority for upgradation or expansion
of existing Network utilizing the Telecommunication Equipment not designated as
Trusted Products. Instructions to all the Licensees by the Licensor have been
issued in the past vide letters dated 30.03.2021, 16.06.2021 and 10.06.2022,
requesting compliance related to trusted telecom products and registration on
Trusted Telecom Portal. Pursuance with the licensee through various
communication have also been done by the concerned LSA ﬁeld unit of the
department in this regard.

<!-- page 2 -->

820-1103/2010-LR(Vol-II)

4.
That for non-registration on the Trusted Telecom Portal, a Show Cause
Notice, bearing no. DS/1/2025-DIR(DS-II), dated 04.02.2025 (“SCN”), was issued
to the Licensee on the address provided in the License. The aforesaid SCN was
sent by way of speed post as well as by an email on the registered email ID(s) of
the Licensee on 13.02.2025.
5.
That the aforesaid SCN was issued to the Licensee to submit its reply, within
21 days, as to why the License granted to it should not be terminated, in terms of
the Condition No. 10.2(i) of Part-I of the License.
6.
That despite having given enough time and opportunity to the Licensee to
show cause and explain the alleged violation of terms and conditions of the
License mentioned in the SCN, the Licensee has failed to submit any reply
whatsoever to the Licensor. Further, concerned LSA ﬁeld unit, vide its email dated
16.09.2026 has informed that the licensee is still not registered on the Trusted
Telecom Portal.
7.
That the failure of the Licensee to either comply the stated non-compliance
or submit any reply or explanation to alleged violation of terms and conditions of
the license mentioned in the SCN implies that the Licensee has nothing to say in
this regard and that the Licensee has failed to comply with the conditions of the
License and therefore, has violated the conditions of the License as stated in the
SCN.
8.
Therefore, the competent Authority has now decided to terminate/ revoke/
cancel the Class A ISP License, bearing no. 820-1103/2010-LR Dated
22.09.2010, for All India Service Area, granted to M/s Sisam Technologies
Private Limited, in terms of condition no. 10.2 (i) of Part-I of the said License and
that the said License is terminated/ revoked/ cancelled w.e.f. 61 st calendar day
from the date of issue of this letter.
9.
That the Licensee is further directed to terminate and stop all
interconnections with all service providers eﬀective from the date of termination of
the License.
10.
That the Licensee shall also intimate its subscribers of consequential
withdrawal of service by serving a 15 days notice to them during the operation of
the service in terms of condition 10.9 of Part-I of the License.
11.
That the Licensee shall take note of the condition no. 10.7 of Part-I of the
License, which is reproduced as under:
“It shall be the responsibility of the LICENSEE to maintain the Quality of Service,
even during the period when the notice for surrender/ termination of LICENSE is
pending and if the Quality of Service is not maintained, during the said notice
period, it shall be liable to pay damages. The LICENSEE shall also be liable to pay
the Licence Fee till the end of the notice period and more speciﬁcally till the date
on which the surrender/termination becomes effective.”
12.
That the Licensee shall take note of the condition 11.2 of Part-I of the
License, which is reproduced as under:

I/3445077/2026

<!-- page 3 -->

820-1103/2010-LR(Vol-II)

I/3445077/2026

"On termination or surrender or expiry of the LICENCE, the Bank Guarantee shall
be released after a minimum period of six months to the LICENSEE only after
ensuring clearance of all dues, which the LICENSEE is liable to pay to the licensor.
In case of failure of the LICENSEE to pay the amounts due to the LICENSOR, the
outstanding amounts shall be realized through encashment of the Bank Guarantee
without prejudice to any other action(s) for recovery of the amounts due to the
LICENSOR without any further communication to the Licensee."
13.
That the Licensee shall also take note that in case, it comes to the notice of
the Licensor about any other violation of license conditions by the Licensee,
necessary action in respect of said violation may be initiated by the Licensor in due
course of time.
14.
the Bank Guarantee(s) submitted by the Licensee against the said the
license will be released under condition 11.2 of Part-I of the License after ensuring
clearance of dues, including dues/ penalty arising, if any, as a consequence of the
aforesaid violation.
15.

That the Licensee may acknowledge the receipt.

Director (DS-II)
Email: dirds2-dot@nic.in
jto1ds2-dot@gov.in
Copy to: 1. DG Telecom, DoT, New Delhi, with a request to instruct the concerned
LSA(s) to intimate all Licensees/Infrastructure Providers in their area to
discontinue to provide/obtain any “telecom resources” to/from M / s Sisam
Technologies Private Limited.
2. Addl. DGT, Gujarat LSA, DoT.
3. Sr. Joint CGCA(Revenue), O/o CGCA, DoT with a request to release the
Bank Guarantees of the aforesaid company after ensuring dues from
respective sections of DoT as per letter No. vide 1-90/2012/LF-1(Pt.1) dated
05.09.2018 and letter No. 1-8/2017/LFP-1 dated 17.04.2017. As far as
due(s) of Data Service Cell is concerned, the same will be intimated to O/o
CGCA in due course of time.
4. Secretary, TRAI.
5. Wireless Advisor, for issue of Dues/No Dues Certiﬁcate till the eﬀective date
of termination of License and convey to office of CGCA.
6. CCA, Gujarat Circle, DoT.
7. DDG(AS)/DDG(CS)/DDG(SAT)/DDG(SA)/DDG(SPPI)/DDG(LFP)/
DDG(WPF), DoT HQ.
8. Director (IT), DOT HQ for uploading this order on DoT website for information

<!-- page 4 -->

820-1103/2010-LR(Vol-II)

I/3445077/2026

to all Service Providers.
9. File No.: 820-1103/2010-LR(Vol-II)
