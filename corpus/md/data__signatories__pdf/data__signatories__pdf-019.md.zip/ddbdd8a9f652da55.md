---
doc_id: "ddbdd8a9f652da55"
source_url: "https://doj.gov.in/static/uploads/2025/09/1a4b445b3879debd426d455aceea2a17.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment Shri Justice Ashutosh Kumar, Judge Patna High Court as Chief Justice of Gauhati High Court (14.07.2025)"
date: "2025-07-14"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f6eaa5b416543576"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K-13018/03/2025-USI
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011, Dated: 1461 July, 2025.

NOTIFICATION
In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint Shri Justice Ashutosh
Kumar, Judge of the Patna High Court, to be Chief Justice of the Gauhati High
Court, with effect from the date he assumes charge of his office.

g) 14 ';
(Jagannat Snnivasan)
Joint Secretary to the Government of India
Tele: 2338 3037

To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

-2
No. K-13018/03/2025-USI

Dated: 14.07.2025

Copy to:1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.

Shri Justice Ashutosh Kumar, Judge of the Patna High Court through the
Registrar General, Patna High Court, Patna.
The Secretary to Governor, Assam, Dispur.
The Secretary to Governor, Arunachal Pradesh, Itanagar.
The Secretary to Governor, Mizoram, Aizawl.
The Secretary to Governor, Nagaland, Kohima.
The Secretary to Governor, Bihar, Patna.
The Secretary to Chief Minister, Assam, Dispur.
The Secretary to Chief Minister, Arunachal Pradesh, Itanagar.
The Secretary to Chief Minister, Mizoram, Aizawl.
The Secretary to Chief Minister, Nagaland, Kohima.
The Secretary to Chief Minister, Bihar, Patna.
The Secretary to the Acting Chief Justice, Gauhati High Court, Guwahati.
The Secretary to the Acting Chief Justice, Patna High Court, Patna.
The Chief Secretary, Government of Assam, Dispur.
The Chief Secretary, Government of Arunachal Pradesh, Itanagar.
The Chief Secretary to Government, Mizoram, Aizawl
The Chief Secretary to Government, Nagaland, Kohima.
The Chief Secretary, Bihar, Patna.
The Registrar General, Gauhati High Court, Guwahati.
The Registrar General, Rajasthan High Court, Jodhpur.
The Accountant General, Assam, Dispur.
The Accountant General, Bihar, Patna.
The President's Secretariat, (CA.II Section), Rashtrapati Bhavan, New
Delhi
PS to Principal Secretary to the Prime Minister, PM's Office, South Block,
New Delhi.
Registrar (Conf.), o/o Chief Justice of India, 7, Krishna Menon Marg, New
Delhi.
PS to MoS, L&J (I/C) / PPS to Secretary (Justice).
Technical Director, MC, Department of Justice, with a request to upload
on the website of the Department (www.doi.gov.in).

(Prem Chand)
Under Secretary (Appointments-I)
Tele: 011-23382978
