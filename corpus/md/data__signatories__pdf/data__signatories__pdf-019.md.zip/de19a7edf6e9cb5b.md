---
doc_id: "de19a7edf6e9cb5b"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/ef6b8dca218a6bd387aa22a5325385e3.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Important policy decisions taken and activities/initiatives during June, 2016"
date: "2016-06-22"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a416a2fac0b8911d"
---

<!-- page 1 -->

. fi
yf
fon oe ne Ministry of Human Resource Development
है Department of School Education and Literacy
. important policy decisions and activities/initiatives:

(i) The National Steering and Monitoring Committee (NSMC) meeting was
held by me on 22.06.2016 in New Delhi to review the implementation of
the Mid Day Meal Scheme.

{ii) | A Regional Workshop was held at New Delhi on 3-4 June, 2016 and
another at Thiruvananthapuram on 10-11 June, 2016 to review the

* performance of the States in implementation of Mid Day Meal Scheme. :

(iii) A meeting of the Consuttative Committee of the Parliamagad attached to
Ministry of Human Resource Development was held ov Sth June, 2016
at Gangtok, Sikkim on "Teachers Education”. ‘

(tv) A school volunteering programme called "Vidyanjali" was launched on
19.06.2016 to facilitate volunteers to assist schools in co-curricular
activities.

{v) | The India Teacher Education Portal (ITEP) named "Prashikshak” was i
jaunched on 30th June, 2016. The portal provides real time information i
on District Institutes of Education and Training (DIET). A meeting was ho
also held on the same day with Principal Secretaries/Secretaries of |
schoo! Education Departments of States/UTs to review the Central {
Sponsored Scheme of Teacher Education (CSSTE). :

{vi) A National Conference on the theme “Towards Literate india Prospects i
and Strategies" was held on 28th June, 2016 at New Delhi to develop :
strategies for achieving full literacy among the working age population. :
