---
doc_id: "dac7db71b8adfeb8"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/b15b17e039772a218e14b5f4e96f96fe.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Appointment of Vice Chancellor of Central University of Jammu"
date: "2020-02-25"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f18ee8e413a3f2d3"
---

<!-- page 1 -->

*

GOVERNMENT OF INDIA
MINISTRY OF HUMAN RESOURCE DEVELOPMENT
DEPARTMENT OF HIGHER EDUCATION
Appointment of Vice-Chancellor of Central University of Jammu.
The Vice-Chancellor, being the academic as well as administrative head,
is expected to be:
•

A visionary with proven leadership qualities, administrative capabilities as
well as teaching and research credentials.

•

Having outstanding academic record throughout and a mínimum of 10 years’
experience as Professor in a University or 10 years’ of experience in a reputed
research and/or academic administrative organisation with proof of having
demonstrated academic leadership.

•

Preferably not more than 65 years of age as on the closing date of receipt of
applications of this advertisement.

Salary and Service Conditions
•

The post carries a pay of Rs. 2,10,000/- (Fixed) per month with Special
Allowance of Rs. 11,250/- and other usual allowances.

•

The terms and conditions of the Services will be those as set forth in the Act,
Statutes and Ordinances of the University.

Procedure for appointment
•

Appointment will be made from a panel of ñames recommended by a
Committee constituted under the provisions of Central Universities Act, 2009.

•

The advertisement and the format of application are available on the websites
http: //mhrd.gov.in and https://www.cuiammu.ac.in/

•

The applications in the prescribed proforma should reach within 30 days
from the date of the.publication of this advertisement, by Registered/Speed
Post to:
Deputy Secretary (Central Universities),
Department of Higher Education, Ministry of HRD,
Room N0.213, ‘C’ Wing, Shastri Bhawan, New Delhi-110115

“Application for the post of Vice Chancellor, Central University of
Jammu”, should be super-scribed on the envelope.
This Department is not responsible for postal delay.
*****

<!-- page 2 -->

HTCcT
yryy yyrray faFRT
TEtlcR ftWT f^TRT
4e4?4t4>4p

5R3T#i^hT ^cfí^c^lcH'M i +riMÍr) Í T fódííd
3ranyfíty> i yry-yny T s im f ^ ysrer
O
• ^

cArlrcf
i
C

% ^trw «t>óryfct
^ y F 3wfly i r sncft f:
O

3juft
3Ík y d ld Q * 5WHT3# £ yO y y XJ^T zyy?ft
i
O
«N

dTy ftTítTW 3Ík ?ft^T

ffrSTTI
• f^9f^^TTpRT
yuiicíl 3Í W R R i
V.

y y 3Í <r¿<\l<rld<H 10 y i yy 3TOW
3 fyy ár't'^C
O
c

f t ü f yy ftey yr ísüií^r yyyr

yycsy ir rrerfficr

3fcbiejílct> o^clrci # 10 q*í yy 3Ty3Ty|
• ?
y í^rTTMoH # 3TTte- yrf^T i T ÑFWPW f?rf^ yy 65 ^
x

i r 3TRT
ÍT 3 ít o 3TT5T
yy y|T
O
«3

fft^yr dií3.oTi'M i
íd*l 3Íty Üfll ?Tcf
•

y^r yy 2,10,000/- w r (fStftyy) yütaiF i yyy 11,250/- yxyiyy

swt 3ík

3T?y <h w i «-¿i §r?yf yy §Ririw ?tor £i
• iryratf i r í^ y y y 3íty ?t3

fWr ^fr

i

arUtí^Rm", yy d tf^ ty í yyr

m y r ^ f t # i r y f £i
fóyfíd

y fiy T

• y?- P r y ííd i ^ i ry f t s y fiy y r a y arittf^ryy, 2009 i

y ry y iy t i

aiyiry y f é y yyr

díílírl yyRT íílLhifty f i y y y y w t i y^F 3yyr ir ir i r ynyafri

• yf

í^diyy

3ftr

3niyy

yy

yyy

iyyr^e:

http://mhrd.gov.in

3tty

http://www.cuiammu.ac.in/ y ¿McH®y ^
• fírtrifid u H a ti # 3 y iy y

fiy r y y i

yyy^iy i r f^rfír ir 30 í i y i

afiyy ^ R f r /

■i-'íls ytyc yyiyr íí«Hri y ^ yy y^yir yT%y:
x

O

3y yf*ry, ( i .- i i y fó*yfayyray)
j e ír t t RhfíT ftsny y ry y yrcmiy fóyny y y iy y ,

yyra yreyT 213, ‘tfr f^y, ? n y i wysr, y f fi^ft-110115
“fel4>TÍ yy ‘^oryfcT i y y
y? fiiy y, si0!! í^piq

aniyy- 3 R y r^ ^ ty f^ y f^ y y ry y ”, 3¡yyfprf^ry ?tyT yí% yi

foTT^yry y^ri
•****#

<!-- page 3 -->

Format of Application for the post of Vice-Chancellor of Central Universitv of
Jammu.

Affix the latest Passport
size Photo

(Applicant is requested to type the information in the following format, and can add more lines in the
format wherever required.)
1. General Information of Applicant
Ñame
(In Capital Letters)
Date of Birth
(Day/Month/Y ear)
Correspondence Address
Phone No.
Mobile:
Landline:
Email:
2. Present Position
a. Designation
b. Organization
c. Pay Scale
d. Date of Appointment
to the present post
e. Total Experience
(In Years and Months)
3. Details of Experience possessed as per eligibility criteria:
(10 years’ Professorship or equivalent as per UGC Regulations on Mínimum Qualiflcations for
Appointment of Teachers and other Academic Staff in Universities and Colleges and Measures
for Maintenance of Standards in Higher Education 2010 and subsequent modifícations)
S.No.

Post Held

Pay Scale

Organization

Nature of duties Experience (In Years
and Month)

<!-- page 4 -->

4. Educational Qualification (In chronological order from latest to Graduation level)
S.No.

Qualification

University

Year

Subject(s)/
Topic(s)

%
Achieved

Distinctions
etc.

5. Administrative Experience/Post(s) & responsibilities held
S.
No.

Post ' '

1.

Head of the Department
Chairman, Board of
Studies
Member, Board of
Studies
Dean of Faculty
Member of Academic
Council
Member of Executive
Council
Member of Professional/
Academic Bodies
Others (Specify)

2.
3

4.
5.
6.
7.
8.

Organizaron/
University

From
(Date)

Duration
To
(Date)

Experience
(In Years and
Months)

6. (a) Academic/Teaching Experience & responsibilities (In chronological order from latest to oldest)
S. No.

Post

Organization/
University

From
(Date)

Duration
To
(Date)

Experience
(In Years
and Months)

(b) Participation and contribution in relevant areas in higher education

Visiting Professor
Resource Person
Others (Specify)

Organisation

Area of specialisation

(c) Involvement with formulation of academic programmes:
S.No.

Nomenclature of Innovative Academic
Programmes formulated

Date of approval by
Academic Council

Year of
Introduction

<!-- page 5 -->

(d) Important MoUs formulated for academic collaborations:
s.

No.

MoUs formulated

Ñame of Agencies/Departments
involved

Year of MoU

Ñame of Agencies/Departments
involved

Period of holding
the Chair

(e) Position of Chairs:
S. No. Ñame of Chair

7. International academic Exposure, if any
Organiza tion/
S. No. Post/
Assignment University

Area of Assignment

From

Duration
In Years &
To
Months

8. Scholarly achievements:
A. Contribution to Journals and Books:

Details

Books authored
Editor in Chief
Editorships
Peer reviewer for
Member of the International Advisory
Board
Others (Specify)
B. Publication:

B.I Kindly provide list of scholarly publications in recognised professional and/or academic journals:
Total Publications:...................
S.No. Date

Title

Ñame of journal

Refereed
journal or
not

Number of
Citations
(where possible)

<!-- page 6 -->

B.II List of articles in popular magazines or newspapers
Total Articles:
S.No. Date

Titlé

Ñame of Magazine/
Newspaper

C. Participaron and scholarly presentations in conferences:
C.I National
S.No. Date

Title of Conference or Institution

Title/Subject of presentation fif made)

Title of Conference or Institution

Title/Subject of presentation (if made)

C.II International
S.No. Date

D. Participation and contribution in National/International Fora in the area of your academic
and professional expertise

Plenary Lectures/Invited Talks
Congresses attended
Examinership etc.
Others (Specify)

International
National
International
National
International
National
International
National

Number(s)

9. Research Projects:
S.No. Client/Organisation’s
ñame

Nature of project

Duration of
project

10. Consulting experience:

List key Consulting assignments undertaken:
S.No. Client/Organisation’s
ñame

Nature of assignment

Duration of
assignment

Amount
of grant
(Rupees)

<!-- page 7 -->

11. Honours /Awards & Fellowships for Outstanding Work:
Sr.
No.

Elected/Honorary
Feliow

Ñame of
Award/Fellowship
etc.

Awarded by

Year of Award

12. No. of Research Scholars successfully guided :
Ñame of Programme

Awarded (No.) (Under-progress not to be included)

13. Strengths (in 100 words)

14. Your Vision for the University (upto 500 Words)

15. Details of Referees, if any
S. No.

Ñame of the
Referee

Post Held by
Referee

Email

Phone No.

Mobile

I, hereby, declare that all the statements/ particulars made/furnished in this application are true, complete and
correct to the best of my knowledge and belief. I also declare and fully understand that in the event of any
information furnished being found false or incorrect at any stage, my application/candidature is hable to be
summarily rejected at any stage and if I am already appointed, my Services are hable to be terminated
without any notice from the post of Vice-Chancellor as per Act/ Statutes etc. and other applicable rules.
Place:
Date:

(Signature of the Applicant)

Note: Total No. of pages (A-4 size) of the application should not exceed 10 pages.
