---
doc_id: "dd0c9a6a8edb200b"
source_url: "https://dof.gov.in/static/uploads/2025/12/8bfff0418b9d87d8b6237ff2d67bfc36.pdf"
ministry: "Department of Fisheries (DoF)"
title: "SUSTAINABLE HARNESSING OF FISHERIES IN THE EXCLUSIVE ECONOMIC ZONE RULES, 2025."
date: "2025-12-24"
pages: 21
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "c4335ee7c5edc237"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-05112025-267394
xxxGIDHxxx
CG-DL-E-05112025-267394
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 732]
No. 732]

नई ददल्ली, मंगलिार, निम्बर 4, 2025/कार्तिक 13, 1947
NEW DELHI, TUESDAY, NOVEMBER 4, 2025/KARTIKA 13, 1947

जिदेि मंत्रालय
अजधसूचना
नई ददल्ली, 4 निम्बर, 2025
सा.का.जन. 818(अ).— के न्द्रीय सरकार, समुरी क्षेत्र, महाद्वीपीय िेल्फ, अनन्द्य आर्थिक क्षेत्र और अन्द्य सामुदरक
क्षेत्र अजधजनयम, 1976 (1976 का 80) की धारा 7 की उपधारा (4) के खंड (क) के साथ पठित धारा 15 द्वारा प्रदत्त िजियों
का प्रयोग करते हुए, एतद्द्वारा अनन्द्य आर्थिक क्षेत्र में मत्सस्ट्य संसाधनों के अन्द्िेषण, उपयोग, संरक्षण और प्रबंधन के जलए
जनम्नजलजखत जनयम बनाती है, अथाित:
1. संजक्षप्त नाम, अनुप्रयोग और प्रारं भ.- (1) इन जनयमों का संजक्षप्त नाम अनन्द्य आर्थिक क्षेत्र में माजत्सस्ट्यकी का सतत उपयोग
जनयम, 2025 है।
(2) ये जनयम अनन्द्य आर्थिक क्षेत्र में मत्सस्ट्यन और मत्सस्ट्यन संबंजधत गजतजिजधयों पर लागू होंगे।
(3) ये रािपत्र में प्रकािन की तारीख को प्रिृत्त होंगे।

7357 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

2. पठरभाषाएँ.- (1) इन जनयमों में, िब तक दक संदभि से अन्द्यथा अपेजक्षत न हो, (क) "प्रिेि पास" से तात्सपयि इन जनयमों के अंतगित िारीकताि प्राजधकारी द्वारा िारी दकया गया पास है;
(ख) “अजधजनयम” से समुरी िल, महाद्वीपीय िेल्फ, अनन्द्य आर्थिक क्षेत्र और अन्द्य समुरी क्षेत्र अजधजनयम, 1976
(1976 का 80) अजभप्रेत है;
(ग)

"न्द्यायजनणाियक अजधकारी" से तात्सपयि राज्य के दकसी अजधकारी से है, िो सहायक जनदेिक के पद से नीचे का न
हो तथा जिसे संबंजधत राज्य सरकार या संघ राज्य क्षेत्र प्रिासन द्वारा जनर्दिष्ट दकया गया हो;

(घ) "प्राजधकृ त अजधकारी" से इन जनयमों के प्रयोिनों के जलए अजधसूचना द्वारा के न्द्रीय सरकार द्वारा प्राजधकृ त कोई
अजधकारी अजभप्रेत है;
(ङ)

"अपीली प्राजधकारी" का अथि है मत्सस्ट्यपालन जिभाग, मत्सस्ट्यपालन, पिुपालन और डेयरी मंत्रालय में संयुि सजचि
के पद से अन्द्यन
ू अजधकारी, जिसे कें र सरकार द्वारा जनर्दिष्ट दकया गया हो;

(च) "मत्सस्ट्य" का अथि है दफनदफि, मोलस्ट्क, क्रस्ट्टेजियन और समुरी स्ट्तनधाठरयों, सरीसृपों और समुरी पजक्षयों को
छोड़कर समुरी िानिरों और पौधों के सभी अन्द्य प्रकार;
(छ) "मत्सस्ट्यन" का अथि है दकसी भी जिजध से मत्सस्ट्य खोि करना, उसका लक्ष्य रखना, आकर्षित करना, पकड़ना, ग्रहण
करना या हािेसस्ट्टंग करना;
(ि) "मत्सस्ट्यन संबंजधत गजतजिजधयों" का अथि है मत्सस्ट्य को उतारना, पैकेसिंग करना, जिपणन करना, प्रसंस्ट्करण करना,
संरक्षण करना, भंडारण करना, िीजित मत्सस्ट्य का रांसपोटेिन करना, रांसजिसपंग करना, या पहले बंदरगाह पर
नहीं उतारे गए मत्सस्ट्य का रांसपोटेिन करना;
(झ) "मत्सस्ट्यन पोत" से ऐसा पोत या नाि अजभप्रेत है िो जििेष रूप से लाभ के जलए समुर में मत्सस्ट्यन में लगा हुआ है;
(ञ) "िारीकताि प्राजधकारी" से अजभप्राय के न्द्रीय सरकार के मत्सस्ट्यपालन जिभाग में उप जनदेिक के पद से अन्द्यन
ू
अजधकारी से है, जिसे अनन्द्य आर्थिक क्षेत्र में मत्सस्ट्यन और मत्सस्ट्यन संबंजधत गजतजिजधयों के जलए मत्सस्ट्यन पोतों को
प्रिेि पास िारी करने के जलए नाजमत दकया गया है;
(ट)

"यंत्रीकृ त मत्सस्ट्यन पोत" से ऐसा मत्सस्ट्यन पोत अजभप्रेत है जिसके पतिार या बोडि पर इं िन लगा होता है, िो
प्रणोदन और मत्सस्ट्यन कायि िैसे िाल डालना और खींचना या लाइनें चलाना आदद के जलए मिीनी िजि का
उपयोग करता है;

(ि)

"मोटर चाजलत मत्सस्ट्यन पोत" से अजभप्राय है, एक इं िन युि मत्सस्ट्यन पोत, िो अंदर या बाहर लगा हो, जिसका
उपयोग के िल प्रणोदन के जलए दकया िाता हो, न दक मत्सस्ट्यन कायों के जलए;

(ड)

"प्रचालक" से तात्सपयि दकसी व्यजि या उद्यम, या मत्सस्ट्य दकसान उत्सपादक संगिन या माजत्सस्ट्यकी सहकारी सजमजतयों
(बहु-राज्य सहकारी सजमजतयों सजहत) से है, िो मत्सस्ट्यन पोत के संचालन या प्रबंधन को जनयंजत्रत करता है या
जिसने इसके संचालन की जिम्मेदारी संभाली है;

(ढ)

मत्सस्ट्यन पोत के संबंध में "माजलक" से पोत का माजलक और कोई अन्द्य व्यजि अजभप्रेत है, जिसके अंतगित कोई
संगिन या व्यजियों का संघ भी है, चाहे िह जनगजमत हो या नहीं, जिसके पास पोत या पोत में कोई जहस्ट्सा है
और इसमें बंधक, पट्टेदार या पोत का िास्ट्तजिक कब्िा रखने िाला अन्द्य व्यजि भी िाजमल है;

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

(ण) "मत्सस्ट्यन पोत का रजिस्ट्रार" से व्यापाठरक नौिहन अजधजनयम, 1958 (1958 का 44) की धारा 435ड के अधीन
जनयुि रजिस्ट्रार अजभप्रेत है;
(त)

"मत्सस्ट्यन क्राफ्ट का पंिीकरण और लाइसेंससंग" या "ठरयलक्राफ्ट" का अथि है कें र सरकार द्वारा स्ट्थाजपत िेब-सक्षम
अनुप्रयोग पोटिल पर मत्सस्ट्यन पोत को पंिीकृ त करना और प्रिेि पास िारी करना ;

(थ)

"राज्य" से तात्सपयि तटीय रे खा िाली राज्य सरकार या संघ राज्य क्षेत्र प्रिासन से है;

(द)

"सत्सयापन अजधकारी" से अजभप्राय राज्य के दकसी अजधकारी से है जिसे के न्द्रीय सरकार द्वारा उनके परामिि से
दस्ट्तािेिों के सत्सयापन तथा प्रिेि पास प्रदान करने के जलए मत्सस्ट्यन पोत के भौजतक जनरीक्षण के जलए नाजमत
दकया गया है।

(2) इसमें प्रयुि िब्दों और अजभव्यजियों के , िो पठरभाजषत नहीं हैं, दकन्द्तु समुरी िल, महाद्वीपीय िेल्फ, अनन्द्य
आर्थिक क्षेत्र और अन्द्य सामुदरक क्षेत्र अजधजनयम, 1976 (1976 का 80) और व्यापाठरक पोत पठरिहन अजधजनयम,
1958 (1958 का 44) में पठरभाजषत हैं, िही अथि होंगे िो उन अजधजनयमों में क्रमिः उनके जलए जनर्दिष्ट हैं।
3. प्रिेि पास – (1) चौबीस मीटर और उससे अजधक लंबाई िाले सभी मोटर चाजलत मत्सस्ट्यन पोत और मिीनीकृ त मत्सस्ट्यन
पोत को अनन्द्य आर्थिक क्षेत्र में पठरचालन के जलए प्रिेि पास प्राप्त होगा।
(2) चौबीस मीटर से कम कु ल लंबाई िाले मोटर चाजलत मत्सस्ट्यन पोत के जलए प्रिेि पास की आिश्यकता नहीं होगी, जसिाय
उन पोत के िो जििेष रूप से टूना और टू ना िैसी प्रिाजतयों के मछली पकड़ने में लगे हों।
(3) अनन्द्य आर्थिक क्षेत्र में प्रचालन करने िाले मत्सस्ट्यन पोत को समुरी सुरक्षा आिश्यकताओं, अनुिीक्षण, जनयंत्रण और
जनगरानी तथा संरक्षण और प्रबंधन उपायों का अनुपालन करना होगा।
4. प्रिेि पास िारी करने की प्रदक्रया - (1) पंिीकृ त मत्सस्ट्यन पोत का माजलक, अनन्द्य आर्थिक क्षेत्र में मत्सस्ट्यन और मत्सस्ट्यन
संबंजधत गजतजिजधयों के जलए ऐसे पोत का उपयोग करने के जलए प्रिेि पास प्रदान करने के जलए सत्सयापन अजधकारी को
फॉमि 1 में ठरयलक्राफ्ट पोटिल के माध्यम से आिेदन कर सकता है।
(2) मचेंट जिसपंग अजधजनयम, 1958 (1958 का 44) के प्रािधानों के अनुसार मत्सस्ट्यन पोत की उपयुिता और समुरी योग्यता
के अधीन फॉमि II में प्रिेि पास िारी दकया िाएगा।
(3) संबंजधत बंदरगाह का सत्सयापन अजधकारी दो सप्ताह के भीतर दस्ट्तािेिों की िैधता और प्रामाजणकता सजहत आिेदन का
सत्सयापन करे गा और इसे िारीकताि प्राजधकारी को अग्रेजषत करे गा।
स्ट्पष्टीकरण.- इस उपजनयम के प्रयोिनों के जलए, "बंदरगाह" से तात्सपयि के न्द्रीय सरकार या राज्य द्वारा जनर्दिष्ट
बंदरगाह, मत्सस्ट्यन बंदरगाह या मछली उतारने का कें र है।
(4) यदद सत्सयापन अजधकारी दो सप्ताह के भीतर सत्सयाजपत आिेदन और सहायक दस्ट्तािेि प्रस्ट्तुत करने में जिफल रहता है,
तो लंजबत जस्ट्थजत स्ट्िचाजलत रूप से िारीकताि प्राजधकारी को भेि दी िाएगी।
(5) िारीकताि प्राजधकारी ऐसी िांच करने के पश्चात्, िैसा िह उजचत समझे, जनर्दिष्ट क्षेत्र में मत्सस्ट्यन और मत्सस्ट्यन संबंजधत
गजतजिजधयों के जलए मत्सस्ट्यन पोत का उपयोग करने के जलए पांच से दस कायि ददिसों के अंदर प्रिेि पास प्रदान कर सके गा
या देने से इं कार कर सके गा।
स्ट्पष्टीकरण.- इस उपजनयम के प्रयोिनों के जलए, "जनर्दिष्ट क्षेत्र" से तात्सपयि िारीकताि प्राजधकारी द्वारा अनन्द्य आर्थिक
क्षेत्र में मत्सस्ट्यन या मत्सस्ट्यन संबंजधत गजतजिजधयों के जलए जनर्दिष्ट क्षेत्र से है।
(6) िारीकताि प्राजधकारी द्वारा िारी या निीकृ त प्रत्सयेक प्रिेि पास फामि II में होगा, जिसे आिेदक द्वारा ReALCRaft पोटिल
से डाउनलोड दकया िा सके गा।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(7) उप-जनयम (6) के अधीन िारी प्रिेि पास में मत्सस्ट्यन पोत के प्रचालक या माजलक द्वारा अनुपालन दकए िाने िाले लागू
जनबंधन और ितों का उल्लेख होगा।
(8 ) िहां प्रिेि पास के जलए आिेदन अस्ट्िीकार कर ददया गया है, िहां आिेदक को ऐसे अस्ट्िीकार के कारणों से अिगत
कराया िाएगा।
(9) माजलक या प्रचालक, िैसा भी मामला हो, यह सुजनजश्चत करे गा दक मूल प्रिेि पास, भौजतक या जडजिटल रूप में, मत्सस्ट्यन
पोत पर प्रमुखता से प्रदर्िित दकया िाए तथा प्राजधकृ त अजधकारी द्वारा मांगे िाने पर प्रस्ट्तुत दकया िाए।
(10) प्रिेि पास अहस्ट्तांतरणीय, गैर-आबंठटत होगा तथा पोत-जिजिष्ट होगा।
(11) यदद िारीकताि प्राजधकारी, इस संबंध में उसे दकए गए संदभि पर या अन्द्यथा, इस बात से संतष्ट
ु है दक प्रिेि पास कपट
या आिश्यक तथ्य के बारे में गलत बयानी द्वारा प्राप्त दकया गया है, तो िह प्रिेि पास के धारक को कारण बताने का उजचत
अिसर देने के पश्चात प्रिेि पास को रद्द या जनलंजबत कर सकता है ।
5. प्रिेि पास की िैधता और निीकरण.- (1) प्रिेि पास िारी होने की तारीख से तीन िषि की अिजध के जलए िैध रहेगा।
(2) मत्सस्ट्यन पोत का माजलक मौिूदा प्रिेि पास की समाजप्त से कम से कम तीस ददन पहले ReALCRaft पोटिल के माध्यम
से निीनीकरण के जलए आिेदन कर सकता है।
(3) िहां प्रिेि पास के निीकरण के जलए आिेदन अस्ट्िीकार कर ददया गया है, िहां आिेदक को ऐसे अस्ट्िीकार के कारणों
की जलजखत में सूचना दी िाएगी।
6. जनगरानी, जनयंत्रण और जनरीक्षण - (1) प्रिेि पास िाला मत्सस्ट्यन पोत मछली उतारने के जलए अपने आधार बंदरगाह से
चलेगा और िहीं िापस आएगा।
(2) यदद कोई मत्सस्ट्यन पोत अपने आधार बंदरगाह के अलािा दकसी अन्द्य बंदरगाह में प्रिेि करने का इरादा रखता है, तो
इसकी सूचना मत्सस्ट्यन पोत के रजिस्ट्रार, िारीकताि प्राजधकारी और प्राजधकृ त अजधकाठरयों को दी िाएगी।
(3) यदद दकसी मत्सस्ट्यन पोत को दकसी अन्द्य देि के प्राजधकाठरयों द्वारा िब्त या जहरासत में जलया िाता है, तो पोत का माजलक
या संचालक तुरंत इसकी सूचना राज्य मत्सस्ट्यपालन जिभाग और िारी करने िाले प्राजधकारी को देगा।
(4) उप-जनयम (3) के अधीन सूचना प्राप्त होने पर, राज्य मत्सस्ट्यपालन जिभाग, के न्द्रीय सरकार द्वारा समय-समय पर इस
संबंध में प्रख्याजपत पोत संचार और सहायता प्रणाली के जलए मानक प्रचालन प्रोटोकॉल के अनुसार आिश्यक कदम उिाएगा।
(4) िाजणज्य पोत पठरिहन अजधजनयम, 1958 (1958 का 44) और उसके अधीन बनाए गए जनयमों के अंतगित जनधािठरत
अपेक्षाओं का अनुपालन करे गा।
(5) मत्सस्ट्यन पोत समय-समय पर के न्द्रीय सरकार द्वारा इस संबंध में प्रख्याजपत पोत संचार और सहायता प्रणाली के जलए
मानक प्रचालन प्रोटोकॉल के अनुसार अपना जििरण राज्य मत्सस्ट्यपालन जिभाग के जनगरानी स्ट्टेिनों को प्रेजषत करेगा।
स्ट्पष्टीकरण.- इस जनयम के प्रयोिनों के जलए, "आधार बंदरगाह" से अजभप्राय प्रिेि पास में दिािए गए मत्सस्ट्यन पोत
के प्रचालन बंदरगाह से है।
7. जनरीक्षण और प्रितिन.- (1) प्राजधकृ त अजधकारी समुर में मत्सस्ट्यन पोत के अनुिीक्षण, जनयंत्रण और जनगरानी के जलए
जिम्मेदार होगा।
(2) प्राजधकृ त अजधकारी दकसी उल्लंघन की ठरपोटि िारीकताि प्राजधकारी, न्द्यायजनणाियक अजधकारी और संबंजधत मत्सस्ट्यन पोत
के रजिस्ट्रार को जलजखत रूप में, के न्द्रीय सरकार द्वारा जनर्दिष्ट तरीके से करेगा।
8. माजत्सस्ट्यकी प्रबंधन योिनाएं - (1) के न्द्रीय सरकार, िैज्ञाजनक संस्ट्थाओं, तटीय राज्यों, मछु आरों और उनके संघों के परामिि
से, अनन्द्य आर्थिक क्षेत्र में सतत माजत्सस्ट्यकी के जलए पाठरजस्ट्थजतकी तंत्र दृजष्टकोण का अनुसरण करते हुए माजत्सस्ट्यकी प्रबंधन

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

5

योिनाएं जनर्दिष्ट करेगी, िो अजधकतम सतत उपि िैसे प्रबंधन उद्देश्यों के अनुरूप मत्सस्ट्य मृत्सयु दर या स्ट्टॉक बायोमास स्ट्तर
सजहत सिोत्तम उपलब्ध िैज्ञाजनक िानकारी पर आधाठरत होगी।
(2) के न्द्रीय सरकार, िैज्ञाजनक संस्ट्थाओं, तटीय राज्यों, मछु आरों और उनके संघों के परामिि से, अनन्द्य आर्थिक क्षेत्र में समुरी
िैिाल की कृ जष सजहत समुरी कृ जष के जलए कदम उिाएगी और मत्सस्ट्यन के दबाि को कम करने, अजतठरि आिीजिका सृजित
करने और समुर से उत्सपादन बढाने के उपायों को बढािा देगी।
स्ट्पष्टीकरण.- इस उपजनयम के प्रयोिनों के जलए, "समुरी कृ जष" से समुरी िलीय िीिों की कृ जष
अजभप्रेत है, जिसमें मछली, मोलस्ट्क, क्रस्ट्टेजियन और िलीय पौधे िाजमल हैं।
(3) उप-जनयम (1) और उप-जनयम (2) के अंतगित माजत्सस्ट्यकी प्रबंधन योिना में जनम्नजलजखत प्रबंधन कायि िाजमल हो सकते
हैं, परं तु इन्द्हीं तक सीजमत नहीं होंगे, अथाित:् (i)

स्ट्थाजनक और सामजयक मत्सस्ट्यन का बंद होना;

(ii)

मत्सस्ट्यन जगयर प्रजतबंध;

(iii) पकड़ने के जलए मत्सस्ट्य का न्द्यूनतम कानूनी आकार;
(iv) मत्सस्ट्यन पोत या माजत्सस्ट्यकी में भाग लेने िालों की संख्या पर सीमाएं;
(v)

बायकै च न्द्यूनीकरण उपाय;

(vi) पारं पठरक और गैर-पारं पठरक समुरी माजत्सस्ट्यकी संसाधनों िैसे समुरी जस्ट्िड, माइक्टोदफड्स का इष्टतम
उपयोग;
(vii) समुरी प्रदूषण, पठरत्सयि, खोए हुए या त्सयागे गए मत्सस्ट्यन उपकरण या छोड़े गए उपकरण से जनपटने के उपाय;
(viii) गहरे समुर और महासागरीय संसाधनों के जलए सतत मत्सस्ट्यन और पोत पर मत्सस्ट्य संचालन के जलए कौिल
और क्षमता जनमािण;
(ix) मत्सस्ट्यन पोत पर पोस्ट्ट-हािेस्ट्ट नुकसान को कम करने के जलए सिोत्तम प्रथाएँ;
(x)

आिश्यक मत्सस्ट्य प्राकृ जतक िास (ईएफएच) की पहचान और संरक्षण, जिसमें स्ट्पॉसनंग, प्रिनन और फीसडंग
ग्राउं ड िाजमल हैं;

(xi) समय-समय पर के न्द्र सरकार द्वारा घोजषत संरक्षण और प्रबंधन उपाय; और
(xii) मत्सस्ट्य भंडार का संरक्षण या पुनिीिन उपाय िैसे सी रें सचंग , कृ जत्रम जभजत्तयों की स्ट्थापना।
(4) अनन्द्य आर्थिक क्षेत्र में मत्सस्ट्यन और मत्सस्ट्यन संबंजधत गजतजिजधयों में लगे सभी मत्सस्ट्यन पोत उप-जनयम (1) के तहत िारी
माजत्सस्ट्यकी प्रबंधन योिनाओं का अनुपालन करेंगे।
(5) के न्द्रीय सरकार गहरे समुर में मत्सस्ट्यन कौिल और मूल्य-श्ृंखला दक्षताओं को बढाने के जलए माजत्सस्ट्यकी सहकारी
सजमजतयों, स्ट्ियं सहायता समूहों और मत्सस्ट्य दकसान उत्सपादक संगिनों सजहत पारं पठरक और लघु-स्ट्तरीय मछु आरों को प्रजिक्षण
और क्षमता जनमािण प्रदान करने के जलए कदम उिाएगी।

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

9. कै च की उत्सपजत्त - (1) अनन्द्य आर्थिक क्षेत्र में प्रचालन करने िाले भारतीय मत्सस्ट्यन पोत द्वारा पकड़े गए मत्सस्ट्य को भारतीय
मूल का माना िाएगा और भारत के क्षेत्र में जस्ट्थत दकसी पोटि पर उतारे िाने पर उस पर कोई आयात िुल्क, उपकर या लेिी
लागू नहीं होगी। ।
(2) दकसी भारतीय मत्सस्ट्यन पोत द्वारा अनन्द्य आर्थिक क्षेत्र में पकड़ी गई और जिदेिी बंदरगाह पर उतारी गई मत्सस्ट्य को जनयाित
के रूप में िगीकृ त दकया िाएगा और िह लागू कानूनों और जिजनयमों द्वारा जनयंजत्रत होगी।
(3) संबंजधत मत्सस्ट्यन पोत का रजिस्ट्रार और के न्द्रीय सरकार द्वारा जनर्दिष्ट कोई अन्द्य प्राजधकरण पोत के कप्तान द्वारा जिजधित्
प्रमाजणत पकड़(कै च) से संबंजधत आंकड़ों के सत्सयापन के जलए जिम्मेदार होगा और जनयम 12 में यथा उपबंजधत तरीके से ठरकॉडि
दकया िाएगा।
स्ट्पष्टीकरण - इस उपजनयम के प्रयोिनों के जलए, " जस्ट्कपर" का तात्सपयि ऐसे व्यजि से है जिसके पास मत्सस्ट्यन पोत की
कमान या प्रभार है या उसके संचालन की जिम्मेदारी है।
10. कै च और स्ट्िास्ट्थ्य प्रमाणपत्र.- ( 1) समुरी उत्सपाद जनयाित जिकास प्राजधकरण और जनयाित जनरीक्षण पठरषद, लागू राष्ट्रीय
और अंतरािष्ट्रीय जिजनयमों के अनुसार, रेसेजबजलटी, स्ट्िच्छता मानकों के अनुपालन और इको-लेबसलंग के प्रयोिनों के जलए
मत्सस्ट्यन पोत द्वारा पकड़ी गई मत्सस्ट्य के जलए क्रमिः कै च सर्टिदफके ट और स्ट्िास्ट्थ्य प्रमाणपत्र िारी कर सकते हैं।
(2) कै च सर्टिदफके ट और स्ट्िास्ट्थ्य प्रमाण पत्र के जलए आिेदन संबंजधत एिेंजसयों के जनर्दिष्ट ऑनलाइन पोटिल के माध्यम से
प्रस्ट्तुत दकए िाएंग,े जिन्द्हें पोत और कै च से संबंजधत िानकारी के सत्सयापन और प्रसंस्ट्करण के जलए ReALCRaft पोटिल के
साथ जिजधित एकीकृ त दकया िाएगा।
स्ट्पष्टीकरण.- इस जनयम के प्रयोिनों के जलए,(क) " जनयाित जनरीक्षण पठरषद" से तात्सपयि जनयाित (गुणित्ता जनयंत्रण और जनरीक्षण) अजधजनयम, 1963 (1963
का 22) की धारा 3 के अंतगित स्ट्थाजपत जनयाित प्रमाणन जनकाय अजभप्रेत है;
(ख) "कै च सर्टिदफके ट" से समुरी उत्सपाद जनयाित जिकास प्राजधकरण या समय-समय पर के न्द्रीय सरकार द्वारा जनर्दिष्ट
ऐसे अन्द्य प्राजधकरण द्वारा िारी प्रमाण पत्र अजभप्रेत है, िो मत्सस्ट्य या माजत्सस्ट्यकी उत्सपादों की खेप के साथ
आपूर्ति श्ृंखला से गुिरने िाली मत्सस्ट्य के संबंध में सटीक और सत्सयापन योग्य िानकारी प्रदान करने के जलए
ददया िाता है;
(ग) "समुरी उत्सपाद जनयाित जिकास प्राजधकरण" से समुरी उत्सपाद जनयाित जिकास प्राजधकरण अजधजनयम, 1972
(1972 का 13) के अधीन स्ट्थाजपत प्राजधकरण से है।
11 जमड-सी रांसजिपमेंट – (1) एक्सेस पास के साथ मत्सस्ट्यन पोत के संचालक या माजलक संबंजधत क्षेत्रीय माजत्सस्ट्यकी प्रबंधन
संगिन के लागू पैमानों और समय-समय पर प्रख्याजपत भारतीय ठरििि बैंक के प्रासंजगक ददिाजनदेिों के अनुसार, मीड सी में
मदर िेसल्स के जलए रांसजिपमेंट कर सकता है।
स्ट्पष्टीकरण. - इस उप-जनयम के प्रयोिनों के जलए, "मदर िेसल्स" से तात्सपयि ऐसे पोत से है, जिसे िाहक पोत,
प्राप्तकताि पोत या फै क्टरी पोत भी कहा िाता है, िो कै च को प्राप्त करके , भंडारण करके , प्रसंस्ट्करण करके और संरजक्षत करके
तथा उसे बंदरगाह तक पहुंचाकर समुर में मत्सस्ट्यन पोत को सहायता प्रदान करता है, तथा ईंधन, खाद्य, पानी, चालक दल की
जचदकत्ससा आिश्यकताओं या अन्द्य सहायता प्रदान कर सकता है।
(2) प्रचालक या माजलक, िारीकताि प्राजधकारी, मत्सस्ट्यन पोत के रजिस्ट्रार और इजडयन कोस्ट्ट गाडि को कम से कम अड़तालीस
घंटे पहले सूजचत करेंगे, जिसमें फॉमि III में मदर िेसल्स, पकड़ी गई मत्सस्ट्य की मात्रा, प्रिाजत और रांसजिपमेंट की तारीख,
समय और जनदेिांक का ब्यौरा देना होगा।

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

7

12. कै च ठरपोर्टिंग . – (1) मत्सस्ट्यन पोत के रजिस्ट्रार, प्राजधकृ त अजधकारी, िारीकताि प्राजधकारी या अन्द्य प्राजधकाठरयों को
ऐसे प्रारूप में और ऐसे आिजधक अंतरालों पर मत्सस्ट्य संबंधी आंकड़े प्रस्ट्तुत करेगा, िैसा दक के न्द्रीय सरकार द्वारा जनर्दिष्ट दकया
िा सकता है।
(2) के न्द्रीय सरकार जिजभन्न प्रकार के मत्सस्ट्यन पोत के जलए यात्रा ठरपोटि का प्रारूप जनर्दिष्ट कर सके गी, जिसमें अन्द्य बातों के
साथ-साथ दफि कै च, मत्सस्ट्यों की प्रिाजतयों, संख्या, ििन, मत्सस्ट्यन क्षेत्रों और यात्रा अिजध का जििरण िाजमल हो सकता है।
13. मछु आरों और चालक दल की पहचान . – जिजिष्ट आर्थिक क्षेत्र में मत्सस्ट्यन पोत पर सिार प्रत्सयेक मछु आरे और चालक दल
के सदस्ट्य को समय-समय पर के न्द्र सरकार द्वारा जनर्दिष्ट QR कोड िाला आधार काडि या मरीन दफिठरि जडजिटल आइडेंठटटी
काडि साथ रखना होगा।
स्ट्पष्टीकरण.- इस जनयम के प्रयोिनों के जलए, "मछु आरे " से तात्सपयि ऐसे मछु आरे और मछु आठरनों से है िो आिीजिका
या लाभ के जलए मत्सस्ट्यन और मत्सस्ट्यन से संबजं धत गजतजिजधयों में लगे हुए हैं, जिनमें मत्सस्ट्य श्जमक भी िाजमल हैं।
14. जिनािकारी मत्सस्ट्यन, िुिन
े ाइल मत्सस्ट्यन और नो दफसिंग िोन पर प्रजतबंध - के न्द्र सरकार, राज्यों और िैज्ञाजनक संस्ट्थानों
के परामिि से, भारत के जिजिष्ट आर्थिक क्षेत्र (प्रादेजिक िल से परे ) में जनम्नजलजखत गजतजिजधयों को जिजनयजमत, प्रजतबंजधत
और जनजषद्ध करेगी, अथाित: (क) डायनामाइट, जिस्ट्फोटक, िहर, हाजनकारक रसायन, या अन्द्य जिनािकारी सामग्री या जिजधयों का उपयोग,
जिसमें पेयर रॉसलंग या बुल रॉसलंग िाजमल है;
(ख) रॉसलंग, पसि-सीसनंग और जगल नेटटंग कायों के जलए मेकेनाइज्ड मत्सस्ट्यन पोत या मोटोराइज्ड दफसिंग क्रॉफ्ट
पर िनरे टर के साथ या उसके जबना सतह या िलमग्न आर्टिदफजियल लाइट्स या एलईडी लाइट्स, दफि लाइट
अरैक्टर या दकसी अन्द्य प्रकाि उपकरण का उपयोग या स्ट्थापना या संचालन;;
(ग) िुिेनाइल दफि को पकड़ना या संबंजधत गजतजिजधयाँ;
(घ) 'नो दफसिंग िोन” या समय-समय पर के न्द्रीय सरकार द्वारा अजधसूजचत ऐसे 'जनर्दिष्ट क्षेत्रों' में मत्सस्ट्यन; और
(ड) के न्द्र सरकार द्वारा समय-समय पर लगाए गए प्रजतबंध अिजध के दौरान मत्सस्ट्यन।
स्ट्पष्टीकरण. - इस जनयम के प्रयोिनों के जलए, "िुिेनाइल मत्सस्ट्य" से तात्सपयि मत्सस्ट्य की उस प्रिाजत से है िो समयसमय पर जनर्दिष्ट माजत्सस्ट्यकी प्रबंधन योिना(ओं) में जनर्दिष्ट िैज्ञाजनक रूप से जनधािठरत न्द्यन
ू तम लीगल साइि से कम है।
15. अिैध, ठरपोटि न की गई और अजनयजमत मत्सस्ट्यन पर प्रजतबंध - के न्द्र सरकार अिैध, ठरपोटि ना की गई और अजनयजमत
मत्सस्ट्यन को रोकने, जनिारण और समाप्त करने के जलए एक नेिनल पलांन िारी करेगी, जिसका एक्सक्लूजसि इकोनॉजमक
िोन में पठरचालन करने िाले िेसल्स को अनुपालन करना होगा।
16. क्षेत्रीय माजत्सस्ट्यकी प्रबंधन संगिन और अंतरािष्ट्रीय उपकरणों का अनुपालन - मत्सस्ट्यन और मत्सस्ट्यन से संबंजधत गजतजिजधयां
संबंजधत क्षेत्रीय माजत्सस्ट्यकी प्रबंधन संगिनों के प्रासंजगक संरक्षण और प्रबंधन उपाय जिनमें भारत भी िाजमल है के अनुपालन
में होंगी।
17. न्द्यायजनणाियक अजधकारी द्वारा की िाने िाली िांच – (1) िहां प्राजधकृ त अजधकारी को यह जिश्वास हो दक दकसी
मत्सस्ट्यन पोत का उपयोग इन जनयमों के दकसी उपबंध या एक्सेस पास की दकसी िति के उल्लंघन में दकया िा रहा है या दकया
गया है, तो िह इसकी ठरपोटि अजधजनणियन अजधकारी को देगा

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(2) इन जनयमों के प्रािधानों या एक्सेस पास की ितों के उल्लंघन के संबंध में प्राजधकृ त अजधकारी से ठरपोटि प्राप्त होने पर,
न्द्यायजनणाियक अजधकारी सभी संबंजधत पक्षों को सुनिाई के जलए उजचत समय देने के बाद िांच करे गा।
18. उल्लंघन और दंड.- (1 ) न्द्यायजनणाियक अजधकारी, जनयम 17 के उपजनयम (2) के अधीन िांच के पश्चात् यह जिजनश्चय
करे गा दक क्या दकसी व्यजि ने इन जनयमों के दकसी उपबंध या एक्सेस पास की दकसी िति का उल्लंघन करते हुए दकसी
मत्सस्ट्यन पोत का उपयोग दकया है, कराया है या करने ददया है, तो िह जलजखत आदेि द्वारा जनम्नजलजखत िुमािना अजधरोजपत
कर सके गा:-:(क). 15 मीटर से कम कु ल लम्बाई िाले मोटोराइज्ड और मेकेनाइज्ड मत्सस्ट्यन पोत के मामले में , िह पांच हिार रुपए
तक के िुमािने के जलए दायी होगा, तथा बाद में उल्लंघन करने पर पंरह हिार रुपए तक का िुमािना हो सके गा।
(ख). 15 मीटर से अजधक लंबाई और 24 मीटर से कम कु ल लंबाई िाले मेकेनाइज्ड मत्सस्ट्यन पोत के मामले में, िह दस
हिार रुपए तक के िुमािने के जलए दायी होगा, और बाद में उल्लंघन करने पर, िुमािना पच्चीस हिार रुपए तक
हो सकता है।
(ग). 24 मीटर या उससे अजधक लम्बाई िाले मेकेनाइज्ड मत्सस्ट्यन पोत के मामले में, िह तीस हिार रुपए तक के
िुमािने के जलए दायी होगा, तथा बाद में उल्लंघन करने पर पचास हिार रुपए तक का िुमािना हो सके गा।
(2) उपजनयम (1) के अधीन लगाए िा सकने िाले दकसी िुमािने के अजतठरि, न्द्यायजनणाियक अजधकारी जनम्नजलजखत को
जनदेि दे सके गा(क) मत्सस्ट्यन पोत के एक्सेस पास को छह महीने से अजधक की जनर्दिष्ट अिजध के जलए जनलंजबत कर सकता है; या
(ख) िैसा भी मामला हो, एक्सेस पास को रद्द या जनरस्ट्त कर सकता है।
(3) एक्सेस पास के जनलंबन की जस्ट्थजत में, ऑपरे टर को तत्सकाल यह सुजनजश्चत करना होगा दक ऐसे पोत का मत्सस्ट्यन या मत्सस्ट्यन
से संबंजधत गजतजिजधयां तब तक बंद कर दी िाएं िब तक दक जनलंबन जलजखत रूप में रद्द न कर ददया िाए।
(4) जनलंजबत या रद्द दकए गए एक्सेस पास का अब उपयोग नहीं दकया िाएगा और ऐसे जनलंजबत या रद्द दकए गए एक्सेस
पास की जस्ट्थजत िारीकताि प्राजधकारी द्वारा रीएएलसीआरएएफटी पर अद्यतन की िाएगी।
(5) इन जनयमों के अधीन न्द्यायजनणाियक अजधकारी द्वारा लगाए गए आर्थिक दंड राज्य द्वारा भूजम पर देय लोक रािस्ट्ि के
बकाया के रूप में िसूल दकए िाएंगे, जिसमें संबंजधत राज्य के भूजम रािस्ट्ि कानूनों के अंतगित कलेक्टर और जिला मजिस्ट्रेट
की िजियों का प्रयोग दकया िाएगा।
19. अपीलें.- (1) जनयम 4 या 5 के तहत िारीकताि प्राजधकारी के आदेि से या जनयम 18 के तहत न्द्यायजनणाियक अजधकारी
द्वारा पाठरत दकसी आदेि के जिरुद्ध अंसतुष्ट कोई भी व्यजि आदेि की सूचना के तीस ददन के भीतर अपीलीय प्राजधकारी को
अपील कर सकता है।
(2) अपीलीय प्राजधकारी पक्षकारों को उजचत अिसर देने के पश्चात अपील की सुनिाई करेगा तथा िीघ्रता से अंजतम आदेि
िारी करे गा।
(3) अपीलीय प्राजधकारी न्द्यायजनणाियक अजधकारी द्वारा पाठरत आदेि की स्ट्िप्रेरणा से समीक्षा कर सकता है, जिसके जिरुद्ध
तीन महीने की अिजध के भीतर कोई अपील दायर नहीं की गई है, तादक िैधता, औजचत्सय या प्रदक्रयात्समक जनयजमतता सुजनजश्चत
की िा सके , बिते दक प्रभाजित व्यजि को सुनिाई का उजचत अिसर ददए जबना कोई प्रजतकू ल आदेि पाठरत न दकया िाए।

<!-- page 9 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

9

20. न्द्यायजनणाियक अजधकारी और अपीलीय प्राजधकारी की िजियां ।- न्द्यायजनणाियक अजधकारी और अपीलीय प्राजधकारी,
िांच करते समय, माजलक या संचालक या प्राजधकृ त अजधकारी से मत्सस्ट्यन पोत के दस्ट्तािेि और ठरकाडि प्रस्ट्तुत करने तथा
अपराध से संबंजधत ऐसे साक्ष्य प्राप्त करने की अपेक्षा करेंग,े िो उजचत समझे िाएं।
21. रािस्ट्ि का प्रेषण.- इन जनयमों के अधीन अर्िित समस्ट्त रािस्ट्ि भारत कोष को या के न्द्रीय सरकार द्वारा जिजनर्दिष्ट
अनुसार िमा दकए िाएंगे।
[फा. सं. UI/251/10/2025]
अजखनो जिमल, संयुक्त सजचि
फॉमि I
एक्सेस पास के जलए आिेदन प्रारूप
(जनयम 4 (1) देखें)
1.

2

1.

माजलक /FFPO/SHG/माजत्सस्ट्यकी सहकारी/कं पनी का नाम

2.

पंिीकरण संख्या।

3. माजलक /FFPO/SHG/माजत्सस्ट्यकी सहकारी/कं पनी का पता

:

:

4. GST नंबर/ CIN (कं पजनयों के मामले में)
5. आधार काडि नं.
6. पैन काडि नं.
7. मोबाइल नं .
8. ईमेल
9. िेबसाइट
3.

10. मत्सस्ट्यन पोत का नाम

:

4.

11. मत्सस्ट्यन पोत का पंिीकरण संख्या:

:

12. पोटि ऑफ रजिस्ट्री:
13. IMO संख्या (िैसा लागू हो)
14. अंतरािष्ट्रीय कॉल साइन (िैसा लागू हो)
15. MMSI संख्या / AIS संख्या (िैसा लागू हो)
16. रांसपोंडर / िीएमएस नं.
17. चालक दल की क्षमता

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

18. प्रस्ट्ताजित मत्सस्ट्यन या मत्सस्ट्यन से संबंजधत गजतजिजधयों का प्रकार :
(i) पसि सीन दफसिंग (ii) लॉग लाइन दफसिंग ( iii) जगलनेट कॉम लॉग
लाइन दफसिंग (v) जगलनेट दफसिंग ( v) पोल और लाइन दफसिंग ( vi)
हैंडलाइन दफसिंग ( vii) रॉसलंग दफसिंग (viii) जमड़-िाटर पेलाजिक
रॉसलंग ( ix) जस्ट्िड जिसगंग, (x) अन्द्य - कृ पया जनर्दिष्ट करें
5.

19. एक्सेस पास अिजध

:

20. (i) बेस पोटि, और
(ii) मत्सस्ट्यन का प्रस्ट्ताजित क्षेत्र
6.

21. मत्सस्ट्यन पोत की जिजिष्टताएं : (i) कु ल लंबाई

:

(ii) चौड़ाई

:

(iii) इं िन का HP

:

(iv) सकल टन भार

:

(v) नेट टन भार

:

(vi) मत्सस्ट्य पकड़ने की क्षमता

:

(vii) इं िन जििरण

:

(viii) ईंधन क्षमता
(ix) जनमािण िषि

:

…………से

<!-- page 11 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

11

घोषणा
हम, मेससि [नाम], िचन देते हैं दक हमारा मत्सस्ट्यन पोत [िेसल्स का नाम] िो 'एक्सेस पास' के जलए अजभप्रेत है, जिनािकारी
मत्सस्ट्यन पद्धजतयों में िाजमल नहीं होगा, िैसे दक पेयर रॉसलंग (बुल रॉसलंग), िुिीनाइल दफसिंग, दफसिंग के जलए
आर्टिदफजियल लाइट या एलईडी लाइट का उपयोग, या िन्द्यिीि (संरक्षण) अजधजनयम, 1972 के तहत अजधसूजचत लुप्तप्राय
या संरजक्षत प्रिाजतयों का मत्सस्ट्यन। मत्सस्ट्यन पोत मत्सस्ट्यन के तरीकों के प्रकार का सख्ती से उपयोग करते हुए और भारत के
जिजिष्ट आर्थिक क्षेत्र में माजत्सस्ट्यकी के सतत दोहन जनयम, 2025 के तहत अनुमत मत्सस्ट्यन के क्षेत्रों में काम करे गा और संबंजधत
क्षेत्रीय माजत्सस्ट्यकी प्रबंधन संगिन िैसे दक सहंद महासागर टू ना आयोग और अन्द्य ऐसे क्षेत्रीय या अंतरािष्ट्रीय उपकरणों जिनमें
भारत भी िाजमल है द्वारा अपनाए गए जनयमों और लागू संरक्षण और प्रबंधन उपायों का पालन करेगा। उल्लंघन की जस्ट्थजत
में सरकार जनयमों के अनुसार िुमािना लगा सकती है तथा एक्सेस पास को जनलंजबत या रद्द कर सकती है।
मैं पुजष्ट करता/करती हँ दक प्रदान की गई िानकारी मेरी िानकारी के अनुसार सत्सय एिं सही है।
……………………………

……………………………..

आिेदक के हस्ट्ताक्षर

ददनांक और स्ट्थान

फॉमि II
एक्सेस पास का प्रारूप
(जनयम 4 (6) देखें)
एक्सेस पास संख्या: [संख्या]
मान्द्य जतजथ: [ददनांक] से: [ददनांक] तक
नया/निीनीकृ त
मत्सस्ट्यन पोत और संचालक का जििरण
1.

माजलक का नाम

:

2.

पता और मोबाइल नंबर

:

3.

मत्सस्ट्यन पोत का नाम और पंिीकरण संख्या,

:

अनुमत मत्सस्ट्यन के प्रकार
4.

पोटि ऑफ रजिस्ट्री

:

5.

कु ल लंबाई

:

6.

बेस पोटि

:

7.
8.

मत्सस्ट्यन क्षेत्र
कॉल जचह्न

:

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

एक्सेस पास के जनयम और ितें
इस मत्सस्ट्यन पोत को भारत के जिजिष्ट आर्थिक क्षेत्र में, भारत के जिजिष्ट आर्थिक क्षेत्र में माजत्सस्ट्यकी के सतत दोहन जनयम,
2025 के तहत, जनर्दिष्ट मत्सस्ट्यन के प्रकार और क्षेत्र के जलए ही संचाजलत करने की अनुमजत है और इन जनयमों के तहत लागू
ितों का पालन करना है, जिसमें मत्सस्ट्यन और मत्सस्ट्यन से संबजं धत गजतजिजधयों का जिजनयमन (जनयम 3), मॉनीटॉटरंग,
जनयंत्रण और जनगरानी (जनयम 4), माजत्सस्ट्यकी प्रबंधन योिना (जनयम 6), जमड-सी रांसजिपमेंट (जनयम 9), कै च ठरपोर्टिंग
(जनयम 10), मछु आरों और चालक दल की पहचान (जनयम 11), जिनािकारी मत्सस्ट्यन, िुिीनाइल दफसिंग और नो-दफसिंग
जोन (जनयम 12) का जनषेध, अिैध, अप्रजतबंजधत और अजनयजमत मत्सस्ट्यन का जनषेध (जनयम 13), क्षेत्रीय माजत्सस्ट्यकी प्रबंधन
संगिन और अंतरािष्ट्रीय उपकरणों का अनुपालन (जनयम 14), और िन्द्यिीि (संरक्षण) अजधजनयम 1972 के तहत अजधसूजचत
लुप्तप्राय प्रिाजतयों का मत्सस्ट्यन िाजमल है।

इन ितों या जनयमों के प्रािधानों या इन जनयमों के तहत िारी आदेिों या जनदेिों का कोई भी उल्लंघन, जिसके पठरणामस्ट्िरूप
दंड ददया िाएगा, जिसमें एक्सेस पास का जनलंबन या रद्दीकरण भी िाजमल है।

िारी करने िाला प्राजधकरण

मुहर और हस्ट्ताक्षर
िारी करने की जतजथ:
स्ट्थान:
फॉमि III
मदर िेसल्स का जििरण, कै च की मात्रा, और रांसजिपमेंट के जलए प्रिाजतयाँ
(जनयम 11(2) देखें)
1. मदर िेसल का नाम

:

2. एक्सेस पास सं.

:

3. डोनर िेसल /िेसल्स का

:

नाम
4. एक्सेस पास संख्या/सं.

:

5. मदर िेसल के माजलक
का नाम एिं पता
6. रांसजिपमेंट की
प्रस्ट्ताजित जतजथ और
समय

:

7. जनदेिांक (अक्षांि और

:

देिांतर)
8. लैंसडंग पोटि

:

<!-- page 13 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

13

कै च का जििरण
प्रिाजत का नाम

संरक्षण जिजध

मात्रा (टन में)

घोषणा
हम घोषणा करते हैं दक उपरोि जििरण सत्सय और सटीक हैं और यह रांसजिपमेंट सभी प्रासंजगक जनयमों का अनुपालन करता
है, जिसमें भारतीय ठरििि बैंक के ददिाजनदेि और भारत के जिजिष्ट आर्थिक क्षेत्र में माजत्सस्ट्यकी का सतत दोहन जनयम, 2025
िाजमल हैं।

डोनर िेसल माजलक के हस्ट्ताक्षर
नाम

मदर िेसल माजलक के हस्ट्ताक्षर
नाम

MINISTRY OF EXTERNAL AFFAIRS
NOTIFICATION
New Delhi, the 4th November, 2025
G.S.R. 818(E).— In exercise of the powers conferred by section 15 read with clause (a) of sub-section (4) of
section 7 of the Territorial Waters, Continental Shelf, Exclusive Economic Zone and Other Maritime Zones Act, 1976
(80 of 1976), the Central Government hereby makes the following rules for the exploration, exploitation, conservation,
and management of fisheries resources in the exclusive economic zone, namely:
1. Short title, application, and commencement. - (1) These rules may be called the Sustainable Harnessing of Fisheries
in the Exclusive Economic Zone Rules, 2025.
(2) These rules shall apply to fishing and fishing-related activities in the exclusive economic zone.
(3) They shall come into force on the date of their publication in the Official Gazette.
2. Definitions. – (1) In these rules, unless the context otherwise requires, (a)

“access pass” means a pass issued by the Issuing Authority under these rules;

(b)

“Act” means the Territorial Waters, Continental Shelf, Exclusive Economic Zone and Other Maritime
Zones Act, 1976 (80 of 1976);

(c)

“Adjudicating Officer” means an Officer of the State, not below the rank of Assistant Director, specified
by the concerned State Government or Union territory Administration;

(d)

“Authorised Officer” means any officer authorised by the Central Government by notification for the
purposes of these rules;

(e)

“Appellate Authority” means an Officer, not below the rank of Joint Secretary in the Department of
Fisheries, Ministry of Fisheries, Animal Husbandry and Dairying, specified by the Central Government;

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(f)

“fish” means finfish, molluscs, crustaceans, and all other forms of marine animals and plants excluding
marine mammals, reptiles, and seabirds;

(g)

“fishing” means searching for, trailing, pursuing, attracting, catching, taking, or harvesting fish by any
method;

(h)

“fishing-related activities” means landing, packaging, marketing, processing, preserving, storing, live
transportation of fish, transhipping, or transporting fish not previously landed at a port;

(i)

“fishing vessel” means a ship or boat which is exclusively engaged in sea-fishing for profit;

(j)

“Issuing Authority” means an officer not below the rank of Deputy Director in the Department of
Fisheries in the Central Government, designated for issuing access pass to fishing vessels for fishing and
fishing related activities in the exclusive economic zone;

(k)

“mechanised fishing vessel” means a fishing vessel with an engine fitted to the hull or on board, which
use machine power for propulsion and fishing operation like casting and pulling nets or operating lines;

(l)

“motorised fishing vessel” means a fishing vessel with an engine, fitted inside or outside, used solely for
propulsion and not for fishing operations;

(m) “operator” means an individual or enterprise, or Fish Farmer Producer Organisations or Fisheries
Cooperatives (including multi-state cooperatives), controls the operation or management of a fishing
vessel or who has assumed the responsibility for its operation;
(n)

“owner” in relation to a fishing vessel means the owner of the vessel or any other person, including an
any organisation or association of persons, whether incorporated or not, by whom the fishing vessel or a
share in the vessel is owned and includes a mortgage, lessee or other person in actual possession of the
fishing vessel;

(o)

“Registrar of the fishing vessel” means the Registrar appointed under section 435E of the Merchant
Shipping Act, 1958 (44 of 1958);

(p)

“Registration and Licensing of Fishing Craft” or “ReALCRaft” means the web-enabled application portal
established by the Central Government for registering fishing vessel and for issuance of access pass;

(q)

“State” means a State Government or a Union territory Administration with a coastal line;

(r)

“Verifying Officer” means an officer of the State designated by the Central Government in consultation
with them for verifying documents and for physical inspection of fishing vessel for grant of access pass.

(2) Words and expressions used herein and not defined but defined in the Territorial Waters, Continental Shelf,
Exclusive Economic Zone and Other Maritime Zones Act, 1976 (80 of 1976) and the Merchant Shipping Act, 1958 (44
of 1958), shall have the meanings respectively assigned to them in those Acts.
3. Access pass. –(1)All motorised fishing vessel having overall length of twenty-four meters and above and mechanised
fishing vessel shall have an access pass to operate in the exclusive economic zone.
(2) No access pass shall be required for motorised fishing vessel having overall length less than twenty-four metres
except those exclusively engaged in fishing of tuna and tuna like species.
(3) The fishing vessel operating in the exclusive economic zone shall comply with the sea safety requirements,
monitoring, control, and surveillance; and conservation and management measures.
4. Process for issuing access pass. – (1) The owner of a registered fishing vessel may make an application through the
ReALCRaft portal in Form I to the Verifying Officer for grant of access pass for using such fishing vessel for fishing
and fishing related activities in the exclusive economic zone.
(2) The access pass shall be issued in Form II subject to the fitness and seaworthiness of the fishing vessel as per the
provisions of the Merchant Shipping Act, 1958 (44 of 1958).
(3) The Verifying Officer of the concerned port shall verify the application, including the validity and authenticity of
documents, within two weeks and forward it to the Issuing Authority.
Explanation. – For the purposes of this sub-rule, “port” means a port, fishing harbour, or fish landing centre
designated by the Central Government or State.
(4) If the Verifying Officer fails to submit the verified application and supporting documents within two weeks, the
pendency status shall automatically be escalated to the Issuing Authority.

<!-- page 15 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

15

(5) The Issuing Authority may after making such enquiry as he deems fit, either grant or refuse to grant access pass,
within five to ten working days, for using the fishing vessel for fishing and fishing related activities in the specified
area.
Explanation. – For the purposes of this sub-rule, “specified area” means an area specified for fishing or fishingrelated activities in the exclusive economic zone by the Issuing Authority.
(6) Every access pass issued or renewed by the Issuing Authority shall be in Form II, which shall be downloadable by
the applicant from the ReALCRaft portal.
(7) The access pass issued under sub-rule (6) shall specify the applicable terms and conditions to be complied with by
the operator or owner of the fishing vessel.
(8) Where an application for access pass has been refused, the applicant shall be informed of the reasons for such refusal.
(9) The owner or the operator, as the case may be, shall ensure that the original access pass, in physical or digital form,
is prominently displayed on board the fishing vessel and produced upon demand by Authorised Officer.
(10) An access pass shall be non-transferable, non-assignable, and shall be vessel-specific.
(11) If the Issuing Authority is satisfied either on a reference made to him in this behalf or otherwise, that an access pass
has been obtained by fraud or misrepresentation as to essential fact, he may after giving the holder of the access pass a
reasonable opportunity of showing cause, cancel or suspend the access pass.
5. Validity and renewal of access pass. – (1) An access pass shall remain valid for a period of three years from the
date of its issuance.
(2) The owner of the fishing vessel may apply for renewal at least thirty days prior to the expiry of the existing access
pass through ReALCRaft portal.
(3) Where an application for renewal of access pass has been refused, the applicant shall be informed of the reasons for
such refusal in writing.
6. Monitoring, control, and surveillance. – (1) The fishing vessel with an access pass shall operate from and return to
its base port for fish landing.
(2) In the event of a fishing vessel intending to enter any port other than that referred to as its base port, it shall be
intimated to the Registrar of the fishing vessel, the Issuing Authority, and the Authorised Officers.
(3) If a fishing vessel is seized or detained by the authorities of any other country, then the vessel owner or operator
shall promptly report it to the State Fisheries Department and the Issuing Authority.
(4) On receipt of information under sub-rule (3), the State Fisheries Department shall take necessary steps in accordance
with the Standard Operation Protocol for Vessel Communication and Support System promulgated in this regard by the
Central Government, from time to time.
(4) The fishing vessel shall comply with requirements prescribed under the Merchant Shipping Act, 1958 (44 of 1958)
and the rules made thereunder.
(5) The fishing vessel shall transmit its details to the designated State Fisheries Department monitoring stations in
accordance with the Standard Operation Protocol for Vessel Communication and Support System promulgated in this
regard by the Central Government, from time to time.
Explanation. – For the purposes of this rule, “base port” means the port of operation of the fishing vessel
indicated in the access pass.
7. Inspection andenforcement. – (1) The Authorised Officer shall be responsible for monitoring, control, and
surveillance of a fishing vessel out at sea.
(2) The Authorised Officer shall report any violation in writing to the Issuing Authority, the Adjudicating Officer, and
the Registrar of the fishing vessel concerned, in such manner as specified by the Central Government.
8. Fisheries management plans. – (1) The Central Government, in consultation with scientific institutions, coastal
States, fishers and their associations shall specify fisheries management plans following ecosystem approach for
sustainable fisheries in the exclusive economic zone, which shall be based on the best available scientific information,
including fishing mortality or stock biomass levels consistent with management objectives such as Maximum
Sustainable Yield.

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(2) The Central Government, in consultation with scientific institutions, coastal States, fishers and their associations,
shall take steps for mariculture, including seaweed cultivation in the exclusive economic zone and shall promote
measures to reduce fishing pressure, create additional livelihoods, and enhance production from the sea.
Explanation. – For the purposes of this sub-rule, “mariculture” means the culture of marine aquatic organisms,
including fish, molluscs, crustaceans and aquatic plants.
(3) The fisheries management plan under sub-rule (1) and sub-rule (2) may include, but not be limited to, the following
management actions, namely: (i)

spatial and temporal fishing closures;

(ii)

fishing gear restrictions;

(iii)

minimum legal size of fish for capture;

(iv)

limits on the number of fishing vessel or participants in a fishery;

(v)

bycatch reduction measures;

(vi)

optimum utilisation of conventional and non-conventional oceanic fisheries resources such as oceanic
squids, myctophids;

(vii)

measures to address marine pollution, abandoned, lost, or discarded fishing gear or ghost gear;

(viii)

skilling and capacity building for sustainable fishing for deep-sea and oceanic resources, and onboard
fish handling;

(ix)

best practices for reducing post-harvest losses on board the fishing vessel;

(x)

identification and protection of Essential Fish Habitat (EFH), including spawning, breeding, and
feeding grounds;

(xi)

conservation and management measures as declared by the Central Government from time to time; and

(xii)

conservation of fish stocks or rejuvenation measures such as sea ranching, installation of artificial reefs.

(4) All fishing vessel engaged in fishing and fishing-related activities in the exclusive economic zone shall comply with
the fisheries management plans issued under sub-rule (1).
(5) The Central Government shall take steps to provide training and capacity-building of traditional and small-scale
fishers including fisheries cooperatives, Self Help Groups and Fish Farmer Producer Organisations to enhance skills for
deep sea fishing and value-chain efficiencies.
9. Origin of catch. – (1) The fish harvested by Indian fishing vessel operating in the exclusive economic zone shall be
treated to be of Indian Origin and shall not be subject to any import duty, cess, or levy when landed at a port located
within the territory of India.
(2) The fish caught in the exclusive economic zone by an Indian fishing vessel and landed at foreign port shall be
classified as exports and shall be governed by applicable laws and regulations.
(3) The Registrar of the fishing vessel concerned and any such other authority as specified by the Central Government
shall be responsible for the verification of the catch-related data, duly authenticated by the skipper of the vessel and shall
be recorded in the manner as provided in rule 12.
Explanation. – For the purposes of this sub-rule, “skipper” means a person having command or charge of a
fishing vessel or responsibility for its operation.
10. Catch and health certificate. – (1) The Marine Products Export Development Authority and the Export Inspection
Council may issue catch certificate and health certificate, respectively, to the fish caught by the fishing vessel for the
purposes of traceability, compliance with sanitary standards, and eco-labelling, in accordance with applicable national
and international regulations.
(2) The applications for catch certificate and health certificate shall be submitted through designated online portals of the
respective agencies, which shall be duly integrated with the ReALCRaft portal for verification and processing of vessel
and catch-related information.

<!-- page 17 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

17

Explanation. – For the purposes of this rule, –
(a)

“Export Inspection Council” means the export certification body established under section 3 of the Export
(Quality Control and Inspection) Act, 1963 (22 of 1963);

(b)

“catch certificate” means the certificate issued by the Marine Products Export Development Authority or
such other authority as specified by the Central Government from time to time, accompanying a
consignment of fish or fishery products to provide accurate and verifiable information concerning fish
passing through the supply chain;

(c)

“Marine Products Export Development Authority” means the authority established under the Marine
Products Export Development Authority Act, 1972 (13 of 1972).

11. Mid-sea transhipment. – (1)The operator or owner of fishing vessel with an access pass may undertake mid-sea
transhipment to a mother vessel in accordance with the applicable measures of the Regional Fisheries Management
Organisation concerned and the relevant guidelines of the Reserve Bank of India as promulgated from time to time.
Explanation. – For the purposes of this sub-rule, “mother vessel” means a vessel, also termed as a carrier
vessel, receiver vessel, or factory vessel, that supports fishing vessel at sea by receiving, storing, processing, and
preserving catch, and transporting it to port, and may provide fuel, food, water, medical needs of crew, or other
assistance.
(2) The operator or owner shall intimate the Issuing Authority, the Registrar of the fishing vessel and the Indian Coast
Guard at least forty-eight hours in advance, providing details of the mother vessel, quantity of catch, species, and
transhipment date, time, and coordinates, in Form III.
12. Catch reporting. –(1) The fishing vessel shall furnish such fishery data to the Registrar of the fishing vessels,
Authorised Officer, Issuing Authority, or other authorities in such format and at such periodical intervals as may be
specified by the Central Government.
(2) The Central Government may specify the format for voyage reports for different types of fishing vessel, which may,
inter alia, include the details of fish catch, fish species, numbers, weight, fishing areas, and trip duration.
13. Fishers and crew identity. –Every fisher and crew member on board a fishing vessel in the exclusive economic
zone shall carry a QR-coded Aadhaar card or a Marine Fishers Digital Identity Card, as specified by the Central
Government, from time to time.
Explanation. – For the purposes of this rule, “fisher” means fishermen and fisherwomen engaged in fishing and
fishing-related activities for livelihood or profit, includes fish workers.
14. Prohibition of destructive fishing, juvenile fishing, and no-fishing zones. –The Central Government, in
consultation with the States and Scientific Institutions, shall regulate, restrict, and prohibit in the exclusive economic
zone of India (beyond territorial waters), the following activities, namely: (a)

use of dynamite, explosives, poisons, noxious chemicals, or other destructive materials or methods,
including pair trawling or bull trawling;

(b)

use or installation or operation of surface or submerged artificial lights or LED lights, fish light attractors
or any other light equipment with or without generator on mechanised fishing vessel or motorised fishing
craft for trawling, purse-seining, and gill netting operations;

(c)

capture of juvenile fish or related activities;

(d)

fishing in ‘No Fishing Zones’ or such ‘designated areas’ as notified by the Central Government from
time to time; and

(e)

fishing during the ban period imposed by the Central Government from time to time.

Explanation. – For the purposes of this rule, “juvenile fish" means a species of fish that is below the
scientifically determined minimum legal size as specified in the Fisheries Management Plan(s) specified from time to
time.
15. Prohibition of illegal, unreported, and unregulated fishing. –The Central Government shall issue a National
Plan of Action to prevent, deter, and eliminate illegal, unreported, and unregulated fishing, which the vessels operating
in the exclusive economic zone shall comply with.

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

16. Compliance with Regional Fisheries Management Organisation and International Instruments. – The fishing
and fishing-related activities shall be in compliance with relevant conservation and management measures of the
concerned Regional Fisheries Management Organisations to which India is a party.
17. Enquiry to be made byAdjudicating Officer. –(1) Where an Authorised Officer has reason to believe that any
fishing vessel is being, or has been, used in contravention of any of the provisions of these rules or any of the conditions
of the access pass, he shall make a report thereof to the Adjudicating Officer.
(2) On receipt of a report from the Authorised Officer regarding contraventions of the provisions of these rules or
conditions of the access pass, the Adjudicating Officer shall hold an enquiry after giving all the parties concerned a
reasonable period of being heard.
18. Violations and penalties. – (1) The Adjudicating Officer shall, after enquiry under sub-rule (2) of rule 17, decide
whether any person has used or caused or allowed to be used any fishing vessel in contravention of any of the provisions
of these rules or any of the conditions of the access pass, he may by order in writing, impose such penalty, as follows:–

(a) In the case of motorised and mechanised fishing vessel of less than 15 metres of overall length, he shall be
liable to a penalty not exceeding five thousand rupees, and for subsequent contravention, a penalty which may
extend to fifteen thousand rupees.
(b) In the case of mechanised fishing vessel of more than 15 metres of length and less than 24 metres of overall
length, he shall be liable to a penalty not exceeding ten thousand rupees, and for subsequent contravention, a
penalty which may extend to twenty-five thousand rupees.
(c) In the case of mechanised fishing vessel of 24 metres and above of overall length, he shall be liable to a penalty
not exceeding thirty thousand rupees, and for subsequent contravention, a penalty which may extend to fifty
thousand rupees.
(2) In addition to any penalty that may be imposed under sub-rule (1), the Adjudicating Officer may direct to–
(a) suspend the access pass of the fishing vessel for a specified period not exceeding six months; or
(b) cancel or revoke the access pass, as the case may be.
(3) In case of suspension of an access pass, the operator shall immediately ensure that fishing or fishing-related activities
of such vessel is stopped until the suspension is revoked in writing.
(4) The suspended or cancelled access pass shall no longer be used and the status of such suspended or cancelled access
pass shall be updated on ReALCRaft by the Issuing Authority.
(5) The pecuniary penalties imposed by the Adjudicating Officer under these rules shall be recovered by the State as
arrears of public revenue due on land, with the exercise of powers of the Collector and District Magistrate under the
land revenue laws of the respective State.
19. Appeals. –(1) Any person aggrieved by an order of the Issuing Authority under rules 4 or 5 or against any order
passed by the Adjudicating Officer under rule 18, may appeal to the Appellate Authority within thirty days of the
communication of the order.
(2) The Appellate Authority shall, hear the appeal after giving a reasonable opportunity to the parties, issue a final order
expeditiously.
(3) The Appellate Authority may suo motu review the order passed by the Adjudicating Officer, against which no appeal
has been filed within the period of three months, to ensure legality, propriety, or procedural regularity, provided no
prejudicial order is passed without giving the affected person a reasonable opportunity to be heard.
20. Powers of Adjudicating Officer and Appellate Authority. –The Adjudicating Officer and Appellate Authority,
while holding the inquiries, shall require the owner or operator or the Authorised Officer, to produce the documents and
records of the fishing vessel, and obtain any such evidence related to the offences as deemed fit.
21. Remittance of revenue. - All revenue earned under these rules shall be remitted to Bharat Kosh or as may be
specified by the Central Government.

[F. No. UI/251/10/2025]
ACQUINO VIMAL, Jt. Secy.

<!-- page 19 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

19
Form I

1.

2.

3.
4.

Application Format for access pass
(See rule 4 (1))
1.
Name of the owner /FFPO/SHG/Fisheries
:
Cooperative/Company
2.
Registration No.
3. Address of the owner /FFPO/SHG/Fisheries
:
Cooperative/Company
4. GST No./CIN (in case of companies)
5.
Aadhaar Card No.
6.
PAN Card No.
7.
Mobile No.
8.
Email
9.
Website
10. Name of the fishing vessel
:

5.

11. Registration No. of Fishing Vessel:
12. Port of Registry:
13. IMO No. (as applicable)
14. International Call Sign (as applicable)
15. MMSI No. / AIS No. (as applicable)
16. Transponder / VMS No.
17. Crew Capacity
18. Type of fishing or fishing-related activities proposed: (i) Purse
Seine fishing (ii) Long Line fishing (iii) Gillnet cum Longline fishing
(v) Gillnet fishing (v) Pole and line fishing (vi) Handline fishing (vii)
Trolling fishing (viii) Mid-water pelagic trawling (ix) Squid jigging,
(x) Others please specify
19. Access pass duration

6.

20. (i) Base port, and
(ii) Proposed area of fishing
21. Specifications of fishing vessel: -

:

:

(i) Overall length

:

(ii ) Breadth

:

(iii) HP of the engine

:

(iv ) Gross tonnage

:

(v) Net tonnage

:

(vi) Fish hold capacity

:

(vii) Engine details
(viii) Fuel capacity

:

(ix) Year of built

:

From ………… To …………

Declaration
We, M/s [Name], undertake that our fishing vessel [vessel Name] intended for ‘access pass’ shall not engage in
destructive fishing practices, such as pair trawling (bull trawling), juvenile fishing, use of artificial light or LED light
for fishing, or fishing of endangered or protected species as notified under the Wildlife (Protection) Act, 1972. The
fishing vessel shall operate strictly using the type of fishing methods and in areas of fishing permitted under the
Sustainable Harnessing of Fisheries in the Exclusive Economic Zone of India Rules, 2025 and shall comply with the
rules and applicable conservation and management measures adopted by the concerned Regional Fisheries Management
Organisation such as Indian Ocean Tuna Commission and other such regional or international instruments to which
India is party. In case of violation, the Government may impose penalties as per the rules and suspend or cancel the
access pass.
I confirm that the information provided is true and correct to the best of my knowledge.
……………………………
……………………………..
Signature of the Applicant

Date and Place

<!-- page 20 -->

20

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Form II
Format for access pass
(See rule 4 (6))
Access pass No.: [Number]
Valid from: [Date] To: [Date]
Fresh/Renewed
Fishing vessel and operator details
1.

Name of the owner

:

2.

Address and mobile No

:

3.

Name and registration No. of the fishing vessel,
type of fishing permitted

:

4.

Port of registry

:

5.

Overall length

:

6.

Base port

:

7.

Area of fishing

:

8.

Call sign
Terms and conditions of access pass

This fishing vessel is permitted to operate solely for the type of fishing and area specified, within the exclusive economic
zone of India, under the Sustainable Harnessing of Fisheries in the Exclusive Economic Zone of India Rules, 2025 and
to follow the stipulations applicable under these Rules including regulation of Fishing and Fishing-related Activities
(rule 3), Monitoring, Control, and Surveillance (rule 4), Fisheries Management Plans (rule 6), Mid-Sea Transhipment
(rule 9), Catch Reporting (rule 10), Fishers and Crew Identity (rule 11), Prohibition of Destructive Fishing, Juvenile
Fishing, and No-Fishing Zones (rule 12), Prohibition of Illegal, Unreported, and Unregulated Fishing (rule 13),
Compliance with Regional Fisheries Management Organisation and International Instruments (rule 14), and Fishing of
endangered species as notified under the Wildlife (Protection) Act, 1972.
Any violation of these conditions or the provisions of the rules or orders or instructions issued under these rules, which
shall result in penalties, including suspension or cancellation of the access pass.
Issuing Authority
Seal and Signature
Date of Issue:
Place:

<!-- page 21 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

21

Form III
Details of mother vessel, quantum of catch, and species for transhipment
(See rule 11 (2))
1. Name of the mother
:
vessel
2. Access pass No.
:
3. Name of the donor
:
vessel/s
4. Access pass No/s.
:
5. Name and contact of the
:
owner of the mother
vessel
6. Proposed date and time
:
of transhipment
7. Coordinates (Latitude
:
and Longitude)
8. Port of landing
Details of catch
Name of species

Quantity (in Tonnes)

Preservation method

Declaration
We declare that the above details are true and accurate and that the transhipment complies with all relevant rules,
including the Reserve Bank of India Guidelines and the Sustainable Harnessing of Fisheries in the Exclusive Economic
Zone of India Rules, 2025.

Signature of the Donor Vessel Owner
Name

Signature of the Mother Vessel Owner
Name

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA

Digitally signed by SARVESH KUMAR
SRIVASTAVA
Date: 2025.11.05 02:54:30 +05'30'
