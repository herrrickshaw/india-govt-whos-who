---
doc_id: "d994e4e9ff44bfff"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/43ee3c0cef8fc6b9e8a0ab7c3489673f.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Promotion and Posting of Central Labour Service Officers reg- (Office Order- 16-18)"
date: "2018-07-04"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "174048380eccb2fc"
---

<!-- page 1 -->

No.A-31011/03/2018-CLS.I
Government of India
Ministry of Labour & Employment
Shram Shakti Bhawan, Rafi Marg.
New Delhi, dated 4th July, 2018.

OFFICE ORDER No. 16/2018
The President is pleased to appoint following Senior Time Scale (STS) Officers of
Central Labour Service (CLS) to Junior Administrative Grade (JAG) of CLS on promotion
on regular basis in Level 12 in the Pay Matrix [Rs.78,800-2,09,200]. The promotion of
these officers will be effective from the date of assumption of charge of the promotional
post, as indicated below:-

51.

Name of Officer
{Shri)

Present place of posting

Posted to

No.

1.

S.G. Sonawale

Dy. Welfare Commissioner
(C), Jabalpur

2.

Karam Chand

Dy. Labour Welfare
Commissioner (C), CPWD,
Mumbai

Labour Welfare Commissioner((),
Ordnance Factory, Khamaria,
Jabalpur
Dy. Chief Labour
Commissioner((), Mumbai

3.

Ambrish Sharma

Regional Labour
Commissioner((), Jaipur

Labour Welfare Commissioner(C),
CPWD, Delhi

4.

G. S Rathore

Welfare Commissioner (C),
Ajmer

5.

V.M. Manickam

Dy. Labour Welfare
Commissioner (C), CPWD
Bhopal
Dy. Labour Welfare
Commissioner (C), CPWD,
Chennai

6.

K.S. Guru

7.

Ganpati Bhat

8.

Dy. Chief Labour
Commissioner( C), Chennai

Dy. Labour Welfare
Commissioner (C), Ordnance
Factory, Dehradun
Regional Labour
Commissioner((), Banglore

Dy. Chief Labour
Commissioner(C),CLC (HQ),
New Delhi
Welfare Commissioner (C),
Hyderabad

VK Trivedi

Regional Labour
Commissioner((), Jabalpur

Labour Welfare Commissioner(C),
Army HQ, Delhi

9.

Pankaj Dubey

Regional Labour
Commissioner((), Kanpur

Welfare Commissioner (C),
Raipur

10.

R.C. Srivastava

Regional Labour
Commissioner((), Dhanbad

Welfare Commissioner (C),
Dehradun

11.

G.V.P.L.N. Rao

Dy. Welfare Commissioner
(C), Karimnagar

Labour Welfare Commissioner((),
Vehicle factory, Jabalpur

<!-- page 2 -->

2

2.
The concerned Organization is requested to immediately relieve the above
mentioned Officers to enable them to join the place of new postings. The Officers
concerned are directed to submit their joining report to this Ministry through the
respective Organization of their postings at the earliest.

3.

In case, any officer does not join the promotional post within a period of 30

days, it will be presumed that he is not interested in availing the promotion and he will
be debarred from promotion as per the relevant rules.

(Ajay Malik)
Under Secretary to the Government of India
Distribution:The Officers concerned.
PS to MOS(IC), L&E/PSO to Secretary(L&E)
CLC(C), New Delhi
DGLW, New Delhi
PS to JS(RKG)/PS to DS.(CLS-1)
Director General of Works, CPWD, Nirman Bhavan, New Delhi.
Director General Ordnance Factory Board, S.K. Bose Marg, Kolkata
DDG(CP), Integrated Hqs of Ministry of Defence (Army), West Block-Ill, R.K.Puram,
New Delhi
9. US(AP.I), UPSC w.r.t. their letter No-1/27(5)/2018-AP.I dated 3.5.2018
10. Admn.I Section, 0/o-CLC(C), New Delhi
11. CLS.II (Vig) Section, Ministry of Labour & Employment
12. Personal file of the Officers concerned/ Office Order bundle/spare copies.

1.
2.
3.
4.
5.
6.
7.
8.
