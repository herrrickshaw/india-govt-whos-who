---
doc_id: "dca4eb1cace1b681"
source_url: "https://mnre.gov.in/static/uploads/2025/07/d3a2bcd71bce62cc5b386328fe96bce7.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Recommendation of the Committee for the appointment on Compassionate Ground in the Ministry. (04/10/2022 1.3 mb, PDF)"
date: "2022-10-04"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "999a9f2767f9458f"
---

<!-- page 1 -->

Page 1 of 2
Report of the Committee Constituted for evaluating the applications
received in the Ministry of New and Renewable Energy for
compassionate appointment
The Committee for considering of the cases of Compassionate Appointment in the Ministry
of New & Renewable Energy was constituted vide MNRE’s Order No. 25/17/2017- Admin-I
Part(I) dated 29" August, 2022 (Annexure-1). The composition of Committee is as follows:
i. Shri Sandeep Mukherjee, Deputy Secretary : Chairman
ii. Shri Kailash Chand, Deputy Secretary : Member
iti. Ms. Sunita Dhewal, US हि Member
2. The Committee met on 22.09.2022 and 23.09.2022, and considered the 09 applications
received by Ministry of New & Renewable Energy for compassionate appointment. Out of the
nine applications received by the MNRE, one application namely from Smt.Geeta daughter of Late
Shri Chhatar Pal is found to be incomplete as the supporting documents affidavits have not been
attached/provided. Therefore, the Committee could not evaluate the said application.
3. The Committee, therefore, scrutinized the remaining eight applications in response to the
Ministry of New & Renewable Energy’s O.M. dated 21% June, 2022 (Annexure-2) and awarded
points based on the criteria/parameters mentioned in the said O.M. As per the said O.M each
application is required to be evaluated in terms of the total of 100 points. In addition to the above,
cases where the wife of deceased official has applied for compassionate appointment for herself,
she shall get 15 additional points as grace points.
4. The breakup of these 115 points is as under:
a) Family Pension/ Monthly amount (Excluding DA & Allowance)-20 points
b) Terminal Benefits (DCRG, GPF/ PPF, LIC/ PLI, Leave encashment etc.)/ Lump sum
amount under NPS etc.- 10 points
c) Annual income of earning Members and income from property-10 points
d) Movable/immovable property-10 points
e) Left over service of deceased- 15 points
f) Number of Dependents i.e. Mother or Father, Spouse (Wife) only- 10 points
g) Unmarried daughters-10 points
h) Dependent minor children-10 points
ke
Soe
k, |

<!-- page 2 -->

, Page 2 of 2
i) Unmarried major son (upto 25 years of age) and Dependent major son i.e., physically &
mentally challenged (without age limit)-05 points
j) If wife of the deceased has applied for compassionate appointment for herself- 15 point
5. In so far as, the 04" criteria of 10 points i.e. the value of ‘Immovable property’ the
Committee relied on the circle rates/cost of the dwelling unit of the relevant area in evaluating the
value of the property. Based on the application and other papers, the points awarded to each of the
eight eligible applicants is shown as per Annexure-3. For quick reference the points awarded by
the Committee in respect of each applicant is reproduced below: -
81.10 Name of the applicant and relation with the | Points awarded out
deceased government servant of 115
pho | Sh. Amit Kumar Kansal, Son
6. In view of points awarded as mentioned in para 5 above, the Committee recommends
that the application of Smt. Jharna Jena, Wife of Lt. Sanjay Kumar Jena, MTS may be
considered for the Compassionate appointment.
x ‘ °
| a Sus
(Sandeep Viner (Kailash Chand) (Sunita Dhewal)
Deputy Secretary Deputy Secretary Under Secretary
Chairman Member Member
Enclosures:
1. Consolidated details of funds disbursed to family members of the deceased Govt Servant-
Appendix-1
2. PPO of the deceased government servant (as on 1.1.2016)-Appendix-2 |
3. Circle rates and detailed calculation in respect of immovable property-Appendix-3 |
|
|

<!-- page 3 -->

10००० -3
POINTS AWARDED ON 115 POINTS-SCALE FOR COMPASSIONATE APPOINTMENT a
a Parameter Maximum point Points awarded(Sh/Smt)
earmarked for
each Amit Kumar | Om Dheeraj Jharna Bala
Parameter as per | Kansal Prakash Yadav Jena
MNRE guidelines
dated 21.06.2022
1. Family Pension/ Monthly 16 16 16 16 18 14 14
amount (Excluding DA &
Allowance)
2. Terminal Benefits (DCRG,
GPF/ PPF, LIC/ PLI, Leave 10 03
encashment etc.)/ Lump
sum amount under NPS
etc.
Annual income of earning
Members and income 10 10 08 10 10
from property
Movable/immovable 10 02 05 02 00 |e | ०? | 10
property
| Left over service of 15 03 05 03 | ४ |
deceased
Number of Dependents i.e 10 05 05 05 05 10 05
Mother or Father, Spouse
(Wife) only
Dependent unmarried 10 05 |.” |
daughters
[3._|Dependentminarehiren | छ [wf छ | छर् क
Unmarried major son a
(upto 25 years of age) and
Dependent major son i.e.
physically & mentally
challenged (without age
limit)
Spouse-if she herself has 15 15
applied for
compassionate apptt.
a पा | झ की हू | कर ्खक्ि | कर छ/
00पी a
Dee Sow 6०८
