---
doc_id: "ddaf4ea2f97c1fb7"
source_url: "https://mohua.gov.in/static/uploads/2026/01/e8a1d7c872228e7ddee998d7b511ef57.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Recovery of HBA against gratuity-retirement cum death gratuity"
date: "1965-04-15"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "2bffbaf2764adf57"
---

<!-- page 1 -->

८ No.10/15/59 -HIV = e
Co oe Goverment of India jeg ss. ie 2 उकेए
24202 जे Ministry of works iand Housi oie WE ae “=
geal Ee Re a al eee 33 Se eke el , BOR ute F
vag 10% 71 ae Besos. aes he ig ae
: fee eee : ~~ New Dell ) dated the '© 1 958 - 1.
ee Don हर 05% कं 28 8 7 कल हे 22003: aes si
1 पर ५४226 व 8.1 emorandum<, | कक Sa ae pare a :
1 VAR अधि 1 Office Memo 9५ ceo eae as ae a oe
oe Vets 22.25 F gavance = a
BS ates ८४ ४ Rules to regula e tite er of advances to Geni 1 os
ABE ees * © Cover ser a 07 re building etc houses =
ie = procedure for recovery. of 80५ 01080 0. pavance een ae
18 223 ee ees म 150 1/48809४-८०प४ ०7 ent gratuity. हे
Hees किक के एप 5 302: a SOT a कु 5 सके 3 mec ae aie
paige age ee es SES iets 020 ::2 5-5 “४ के
oN aes oy asl AS ee ae अं 0 पर
eo ete ce & oe ee 32 5 es eee
eee : rs aes कस 15७४ Bee ee a eer 7 a
Riki Aiea dersigned is direct Ce vefer to this Ministryts ees
AG Se areas tanidun No.10/15/69-i1, ili dated the g3rd July,1962, cat
= MBETPIBAL es decided that, where a portion OF the advance) |
a a sa ne fe Sn iS £0 be wiped of by oS
कि नम ता grabaity
aS “ope aw pays Salary actu 115 _प74७7 १5067 $18 04: 18 अमल की
51 1 +8७०17७7७1४ no interest Shona 98 27878, don the principal =
3५ amour & Of outstanding ad ince beyond the te Of reti: renent 3 ae
csihae : Sime ener eae aes snow been : ae h Government 5 ee “ “at
pe ; who di heen ee 2 the advance 4 failed of foe 075 आओ:
201 इक मकर पाप 88. संत ग तीज तरल +
By him under th we हि basen Bere WOE Vee en
Outstanding t OF पा, e will be adjusted ecainst gratuity 555:
(88 “admissible t can be. iven exemption fr Levy Of fy, a
1 5 आवक हे on the ov g amoi idvance i the date ae
7 Of HS ’Geath. It has now been decided an. consultation with
ete fhe Ministry OF Finance yo rks) that in Case %a 1 rrment के
(Servant dies vias viee, anda portion < stand 7
“Balance of the aavan ee eee eee came ees oY
soil “Cimeretirement gratuity admissible to his s iccessor,— nO : :
area terest should). be charged on the amount of the advance thus :
te sdjusted: against 2a m=retirenent gratuity, cen
Lae ee 8 Ben ae Sere बी 3072 eee a
ae be f death a overnment servant. ~~ Sc ae See
UR c In its applic tion to th 2 personnel of théerin Nae:
i it and Accounts: Ber: artment, this order issues with the
ee concurrence ‘of the Comptroller and Aud tor General of india
wh = Ee a a
i: ५ Bo ae कक eek oe
i a pe oe eee ४८6९ ५६ centre
os ieee es fe eee tary to the Govt,of India | ‘
es oo) SS spe oer ay Se a
AT em ST ee Sd eat ae reas ee
LC seekers SES ee alt pee aR. rin: 2 ai
R11 Ministries/Departments. Perens eee ae
: aes a — SERS SE 01815: Cae
i pale: 200 5 5 वि य ल 2 52
ie a Boe ata a
Se say ae ot
: 8 5 Serene SS 1 cs BROT TSS a
५०३४० ७०३४ % है ४
