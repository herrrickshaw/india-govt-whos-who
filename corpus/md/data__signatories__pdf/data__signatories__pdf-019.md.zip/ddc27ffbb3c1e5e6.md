---
doc_id: "ddc27ffbb3c1e5e6"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/40a53284efb2625eeca1ed0d40b1451f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS Comm No. 578 of 2024 in Honble High Court of Delhi: DoT instructions dated 14.04.2025 to ISPs"
date: "2025-04-14"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e273f2c2ccd2257f"
---

<!-- page 1 -->

813-7/25/2024-DS

I/3268055/2025

By Email/DoT Website
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Service Cell)

No. 813-07/LM/2024-DS-II

Dated:14-04-2025

To,
All Licensees with Internet Service Authorization

Subject: CS (COMM) 578 of 2024: DABUR INDIA LIMITED versus ASHOK
KUMAR AND OTHERS in the High Court of Delhi.

Kindly ﬁnd enclosed the Hon’ble Delhi High Court order dated20.11.2024 in
the captioned suit.
2. Please refer to Para 15 of the said Court order with regard to blocking of access
to the impugned websites/ domains/ URLs [8 nos] enumerated in the Para 15 of
the said court order.
3.
In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action with regard to blocking of
access to the said impugned websites/ domains/ URLs, as above, in compliance
with the said court order.
Encl: A/A

Director (DS-II)
Email: dirds2-dot@nic.in
Copy to:
i.) Sh. V. Chinnasamy, Scientist E (chinnasamy.v@meity.gov.in), Electronics
Niketan, Ministry of Electronics and Information Technology (MeitY), New Delhi for
kind information and with request to take action as per the Annexure pl.
ii.) Plaintiﬀ's Counsel for kind information and requested to take action as per the
Annexure pl.
iii) IT Wing of DoT for uploading this order on DoT websites pl.

<!-- page 2 -->

Additional impugned websites/ domain/ URLs as per Para 15 of the
Court Order dated 20.11.2024 in CS(COMM) 578 of 2024https://maxisa.vip/
https://roc22.com/
https://35ksg.com/
https://shopp5.vip/
https://79mia.com/login
https://aisths.vip/login
https://fiisp8.com/
https://13rozx,vip/ [https://13rozx.vip/]

<!-- page 3 -->

$~33
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 578/2024 & I.A. 45627/2024
DABUR INDIA LIMITED
Through: Ms. Kripa Pandit, Adv.
M: 9810013453
versus

.....Plaintiff

ASHOK KUMAR AND OTHERS
.....Defendants
Through: Mr. Tejas Karia, Ms. Swati Agarwal,
Mr. Shashank Mishra, Mr. Mohit
Singh, Mr. Vaarish Sawlani and Ms.
Priyanka Khosla, Advs. for D-3
M: 7042398848
Mr. Varun Pathak, Ms. Amee Rana,
Ms. Sana Banyal and Mr. Tanuj
Sharma, Advs. for D-4.
M: 9818990029
Mr. Siddhant Grover, Adv. for D-5.
CORAM:
HON'BLE MS. JUSTICE MINI PUSHKARNA
ORDER
20.11.2024

%

I.A. 45627/2024 (Application for seeking direction/ clarification with
respect to order dated 18th July, 2024)
1.

The present application has been filed by the plaintiff under Section

151 of Code of Civil Procedure, 1908 (“CPC”) seeking directions in terms
of the order dated 18th July, 2024, passed by this Court.
2.

It is submitted that the present suit has been filed by the plaintiff

against the illegal and unauthorized adoption and use of the trademark by
Ashok Kumar/ unknown defendant no.1, and the violation of its copyright

CS(COMM) 578/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 14/04/2025 at 13:19:26

Page 1 of 7

<!-- page 4 -->

for the purpose of deceiving and/or duping members of the general public
and trade, by impersonating the plaintiff and/or agents/partners/associates.
The plaintiff came to know that Ashok Kumar/ unknown defendant no.1 are
currently running and operating fake domain names.
3.

It is submitted that the present application has been filed seeking

clarification/ further directions in respect of the order dated 18th July, 2024.
Vide order dated 18th July, 2024, this Court had restrained the Ashok
Kumar/ unknown defendant no.1 from running the impugned websites/
domain names containing the plaintiff’s registered trademark/ trade name/
logo/ trade dress/ domain name.
4.

It is submitted that in the said order, the plaintiff was granted the

liberty to approach this Court in order to seek further directions to include
any additional infringing websites/ domain/ URLs, that are found imitating
and infringing the plaintiff’s prior and copyright/registered trademark
‘DABUR’.
5.

It is submitted that the plaintiff has again received new complaints

from its consumers reporting that they have been victims of fraud and have
been manipulated by certain individuals, who through newly encountered
websites/ domain/ URLs, are impersonating the plaintiff company and have
duped consumers into making false investments for securing job
opportunities with the plaintiff company. Thus, the present application has
been filed seeking to include these additional websites/ domain/ URLs found
impersonating and infringing the plaintiff’s registered trademarks and
copyright.
6.

The details of the additional infringing domain/ URLs have been

given in paragraph 7 of the present application. Further, the additional

CS(COMM) 578/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 14/04/2025 at 13:19:26

Page 2 of 7

<!-- page 5 -->

websites found by the plaintiff as registered by defendant no.2, have been
given in a chart in paragraph 8 of the present application.
7.

Learned counsel appearing for the plaintiff submits that the additional

websites do not use/ incorporate the plaintiff’s trademark with its domain
name. However, they are found to be misrepresenting themselves as the
plaintiff and are also involved in duping the members of the general public
by offering false work from home job opportunities to unsuspecting
members of the public by using the plaintiff’s well-known registered
trademark ‘DABUR’, with the tag line ‘Celebrate Life!’. The screenshots as
given in the present application, are reproduced as under:

CS(COMM) 578/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 14/04/2025 at 13:19:26

Page 3 of 7

<!-- page 6 -->

CS(COMM) 578/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 14/04/2025 at 13:19:26

Page 4 of 7

<!-- page 7 -->

CS(COMM) 578/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 14/04/2025 at 13:19:26

Page 5 of 7

<!-- page 8 -->

8.

Learned counsel appearing for the plaintiff submits that at the time of

filing the present application, the plaintiff discovered that the domain name/
URLs in question are not presently operating/ opening. However, given that
these domains/ URLs have not expired and are still valid domains, the
plaintiff has strong apprehension that the same may become active again.
9.

It is further submitted that as per the complaints received by the

plaintiff company, the customers are being approached through new
WhatsApp numbers/ Telegram profiles that are being used in conjunction
with the additional websites to dupe unwary customers.
10.

The details of the new WhatsApp numbers and Telegram profiles,

along with the screenshots thereto, have been given in paragraph 13 of the
present application.
11.

Issue notice. Notice is accepted by learned counsel appearing for the

defendants.
12.

Mr. Tejas Karia, learned counsel appearing for defendant no. 3

submits that upon perusal of the application filed by the plaintiff, it is
manifest that the plaintiff has filed the proof of the infringing activity.
13.

Likewise, learned counsel appearing for the other defendants also

submit that they shall comply with the directions passed by this Court.
14.

Learned counsel appearing for defendant no.4 submits that no

directions have been prayed against the defendant no.4.
15.

Accordingly, considering the submissions made before this Court, the

directions are issued thereby directing defendant no.2, i.e., Gname.com Pt.
Ltd., defendant no.6, i.e., Department of Telecommunications and defendant
no. 7, i.e., Ministry of Electronics and Information Technology to suspend
the additional impugned websites/ domain/ URLs, i.e., https://maxisa.vip/ ;

CS(COMM) 578/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 14/04/2025 at 13:19:26

Page 6 of 7

<!-- page 9 -->

https://roc22.com/

;

https://79mia.com/login

https://35ksg.com/
;

https://aisths.vip/login

;
;

https://shopp5.vip/

;

https://fiisp8.com/

;

https://13rozx,vip/ .

16.

Defendant no.3, i.e., WhatsApp LLC, defendant no.5, i.e., Telegram

FZ LLC and defendant no.6, i.e., Department of Telecommunication, are
directed to suspend and block the telephone numbers/ WhatsApp numbers/
Telegram profiles, as reproduced in paragraph 13 of the present application.
17.

With the aforesaid directions, the present application is disposed of.

CS(COMM) 578/2018
18.

Requisite steps be taken by the plaintiff for bringing amended Memo

of Parties, on record.
19.

Re-notify before the Joint Registrar (Judicial) on 12th December,

2024.

MINI PUSHKARNA, J
NOVEMBER 20, 2024/kr

CS(COMM) 578/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 14/04/2025 at 13:19:26

Page 7 of 7

<!-- page 10 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
