---
doc_id: "dda228d16dcecc4a"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/07/a79cc39a393dc0791c47402b51e9d67b.pdf"
ministry: "Tourism"
title: "Tender for Design & Construction of ITB Asia 2023, Singapore from 25th to 27th October 2023 for Ministry of Tourism, Govt. of India."
date: "2023-09-18"
pages: 42
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "62ff4f37dbe340f2"
---

<!-- page 1 -->

Ministry of Tourism
Government of lndia
(Overseas Marketing Division)
NOTICE INVITING TENDER

Ministry of Tourism, Government of lndia inviting a Tender for professional agency
for conceptualization, design and construction of India pavilion and providing other related
ancillary services at ITB Asia 2023, Singapore lrom 25th to 27th October 2023 on the theme "
Incredible India! Visit India Year 2023". The detailed programme and other information of
tender are as per Tender Document.

2.

All interested bidder are requested to apply for Tender lor design and construction of

India pavilion and providing other related ancillary services at ITB Asia 2023, Singapore from
25th lo 27th October 2023 through https: / / eprocure.gov.in/ eprocure/ app

R K Bhati F11
Asst. Director General
Overseas Marketing Division
Ministry of Tourism

la

<!-- page 2 -->

Tender
for
Design & Construction of
ITB Asia 2023, Singaporefrom 25th to 27th October 2023
for
Ministry of Tourism, Govt. of India

RFP No: OM-1/2023-OM-Part(3)-ITB Asia dated 18.09.2023

Ministry of Tourism
Government of India

<!-- page 3 -->

Table of Contents
1

INTRODUCTION
1.1.

About of Tourism

1.2.

Tender for Design and Construction of India Pavilion at ITB Asia 2023, Singapore from (25th
to 27th October 2023)
5

1.3.

Consultant to design and fabricate the Indian Pavilion at ITB Asia 2023, Singapore from (25th
to 27th October 2023)
5

1.4.

Request for Proposal (RFP)

5

1.5.

Schedule of Selection Process

6

1.6.

Communications and Nodal Officer

6

2

3

4

5

GUIDELINES FOR APPLICANTS

5

7

2.1.

Eligibility criteria

7

2.2.

Broad Scope of Work

7

2.3.

Technical Specifications and Requirements

8

2.4.

in time installation

9

2.5.

Pre-Bid Meeting

10

2.6.

Guidelines for Submission of Bids

10

2.7.

Fact sheet of the experience shall be given in below Table format:

11

a.

Bid Security/ Bid security Declaration

13

b.

Superscribed “Financial Bid” – Tender for Design & Construction of India Pavilion at ITB Asia
2023, (25th to 27th October 2023)
13

c.

Submission to be in electronic form

14

d.

Document to be signed by authorized representatives.

14

e.

Power of Attorney

15

f.

Offline bids.

15

g.

Signed and Stamped (by seal of company) on each page.

15

h.

Terms and conditions

15

OPENING OF BIDS AND SELECTION PROCEDURE

15

3.1.

Opening of Bids

15

3.2.

Technical Bids evaluation criteria

16

3.3.

Terms of Payment

17

INSTRUCTIONS TO APPLICANTS

17

4.1.

Additional Conditions

17

<!-- page 4 -->

4.2.

Liquidated Damages

18

4.3.

Validity of Tender

18

4.4.

Insurance

19

4.5.

Termination by default

19

4.6.

Risk – Purchase Clause

19

4.7.

Bid Security/ Bid security Declaration

19

4.8.

Force Majeure

20

4.9.

Arbitration

20

a.

in time installation

20

b.

PREPARATION AND SUBMISSION OF PROPOSAL

21

Technical Specifications and requirements

21

I. India Pavilion at ITB Asia 2023, (25th to 27th October 2023) from (26th to 29th October
2023)
21
II.

Submission to be in electronic form

21

III.

Document to be signed by authorized representatives.

21

IV.

Signed and Stamped (by seal of company) on each page.

21

V.

List of Documents to be submitted in original to the authority

21

4.10. Jurisdiction
SCHEDULES
SCHEDULE - 1: TERMS OF REFERENCE ( TOR)

22
22
22

Terms of Reference

22

2.

Technical Specifications and Requirements

22

3.

Key Deliverables and Payment Schedule

23

4.

Financial Proposal

25

4.1. Formats to be adhered

25

4.2. Superscribed “Financial Bid” – Tender for Design & Construction of India Pavilion at ITB Asia
2023, Singapore (25th to 27th October 2023).
25
APPENDIX-I: TECHNICAL PROPOSAL FORMS

27

Form 3: Power of Attorney for Authorised Representative

27

ANNEXURE-I: Declaration by bidding agency

29

ANNEXURE - II: FINANCIAL PROPOSAL FORMS

30

Form 1: Covering Letter
ITB Asia 2023, Singapore (25th to 27th October 2023)

30
30

Total cost for ITB Asia 2023, Singapore (25th to 27th October 2023) (exclusive of traxes / GST) in

<!-- page 5 -->

words.

31

ANNEXURE- 3 BID SECURITY DECLARATION

33

<!-- page 6 -->

1 INTRODUCTION
1.1.

About of Tourism
Tourism is one of the fastest-growing sectors globally and has a significant impact on
trade, investment, infrastructure development, employment generation, and social
inclusion. The Ministry of Tourism (MOT) (hereinafter referred to as “Authority”), is
responsible for the formulation of policy to establish a country’s tourism brand
across the world in general and in key source markets in particular.

1.2.

Tender for Design and Construction of India Pavilion atITB Asia 2023, Singapore
from (25th to 27th October 2023)
The Ministry of Tourism requires the services of a professional agency for
putting up a pavilion in ITB Asia 2023 from (25th to 27th October 2023) which will
enable high impact participation at the event. Additionally, the pavilion will be
made more vibrant with activities, with more impactful and meaningful
participation enabling preference as a prelude to destination choice.

1.3.

Consultant to design and fabricate the Indian Pavilion at ITB Asia 2023,
Singapore from (25th to 27th October 2023)
The Indian Pavilion at ITB Asia 2023, Singaporeshould present India as a multifaceted destination that combines an ancient culture and heritage with a
modern, innovative and vibrant present. The pavilion should be open,
minimalistic and impactful. The essence of a visit to the pavilion should be
experience based and visually appealing with use of various technologies. The
aim of the India Pavilion is to give the visitor, experience of visiting India as a
tourist, focusing on its varied tourist attractions.
The India Pavilion has co-exhibitors including Tour Operators, Travel Agents,
Hoteliers, Airlines and State Governments, who are provided space within the
Pavilion
to
showcase
their
tourism
products
and
packages.
The Pavilion will provide each of the co-exhibitors with self-contained booths
of 4 sq. mtr each.

1.4.

Request for Proposal (RFP)
The Authority hereby invites proposals (referred as ‘Proposal’) from shortlisted firms
(hereinafter referred as the ‘Applicant’ or the ‘Bidder’) for Selection of a professional
agency for conceptualization, design and construction of India Pavilion and providing
other related ancillary services (as detailed under the Scope of Work in this
document) inITB Asia 2023, SingaporeBrief description of the Selection Process.
The Authority has adopted a two-stage selection process (collectively the “Selection

<!-- page 7 -->

Process”) for evaluating the Proposals invited from the shortlisted agencies,
comprising of technical and financial proposal.
In the first stage, a technical evaluation will be carried out as specified in the RFP and
in the second stage, a financial evaluation will be carried out as specified in the RFP.
Proposals will finally be ranked according to their combined technical and financial
scores as specified in technical evaluation criteria in the RFP.
1.5.

Schedule of Selection Process
The Authority would endeavour to adhere to the following schedule:

1.6.

S no

Event Description

Timeline

1.

Last date for receiving queries

22.09.2023

2.

Pre-bid Conference

25.09.2023

3.

Response to pre-bid queries

26.09.2023

4.

Proposal Due date or PDD

09.10.2023

Communications and Nodal Officer
All communications including the submission of Proposal should be in English
language and addressed to the Nodal Officer:
Mr. R K Bhati,
Assistant Director General
International Cooperation, OM Division
1st Floor, Transport Bhawan,
1 Parliament Street, New Delhi
Tel.: 011-23724175
E-mail: rk.bhati@nic.in
All communications should have the following information, marked at the top in bold
“Tender for professional agency for conceptualization, design and construction of
India Pavilion and providing other related ancillary servicesatITB Asia 2023,
Singapore”

<!-- page 8 -->

2
2.1.

GUIDELINES FOR APPLICANTS

Eligibility criteria
(i).

(ii).

(iii).

A professional agency with an annual turnover of Rs. 4.00 crore or more (if
Annual turnover of agencies in USD /Euro, etc. the same should be
converted and quoted in INR using official exchange rate of the Ministry of
External Affairs, Govt. of India for the month of March 2023 at Annexure-5
below) during the financial year 2021-22 or 2022-23 (Audited) or during
Calendar year 2021 (Audited) or during the Calendar year 2022 (Audited)
as the case may be.
Previous experience of handling work of conceptualizing, designing and
construction of Pavilion of the size 150 sq. mt. at minimum three (3)
international fairs and exhibitions, held overseas during the Financial Year
2018-19, 2019-20, 2021-22 and 2022-23. Out of the three projects one
project should be for Government (Central / State or Foreign Govt.) / PSU
organization (Event conducted virtually will not be counted).
Relaxation of norms for MSMEs will be as per the instructions of
Government of India.

Details of the Pavilion

Name of
the Event

Month &
Date of
the event

City &
country

Space hired
for India
Pavilion

Estimated No. of
booths required
in India Pavilion

ITB Asia
2023,
Singapore

25th to 27th
October
2023

Singapore

153 sq. mtr.

10-12 individual
booths of 4 Sq. Mt.

2.2.

Broad Scope of Work

2.2.1

Conceptualization and designing the India Pavilion for ITB Asia 2023, (25th to
27th October 2023)
(i). This involves creating impactful designs which present India as a multifaceted destination that combines an ancient culture and heritage with a
modern, innovative and vibrant present.
(ii). The concept should be consistent with the Incredible India! Branding.

<!-- page 9 -->

2.2.2
(i).
(ii).

2.2.3
(i).

(ii).
(iii).
2.2.4
(i).
(ii).
(iii).
(iv).
2.2.5
2.2.6

Constructionof India Pavilion
It should be as detailed in the Specifications and Requirements in para-5 of
this tender document, atITB Asia 2023, (25 th to 27 th October 2023).
This also includes providing water supply fittings in the cafeteria and
electrical fittings in the pavilion / and in all booths of co-exhibitors as per
requirements as well as daily cleaning of the pavilion during the course of
the exhibition.
Operation &Maintenance relating to India Pavilion
The India Pavilion must have a fresh look and must not appear jaded or
worn-out due to normal wear and tear or damage to the material used / reused.
The scope of work will include construction of the pavilion at site well in
time,
maintenance and cleanliness activities, during the event and dismantling of
the pavilion after the event.
Ancillary Servicesrelating to the India Pavilion
This will include but not be limited to printing of participant’s directory,
Providing ethnic uniforms for staff working in the India Pavilion,
Providing storage area including pantry with provision for tea, coffee, snacks
drinking water, microwave oven, refrigerator, etc.
Providing backdrop for Press Conference and other events like cultural
shows organized during the event are also included in the scope of work.
The design must be made adaptable to the booth space as specified above.
The agency will be responsible for storage and transportation of reusable
material for the events covered in this tender.

2.3.

Technical Specifications and Requirements

2.3.1

India Pavilion atITB Asia 2023, (25th to 27th October 2023)will have 10-12
individual booths of 4 Sq. Mt. each for co-exhibitors in the pavilion. This may
vary depending on the registrations received.
The Pavilion should reflect an open and inviting look, with minimum barriers
and have a professional business type layout conducive for conducting buyer–
seller meetings. Material and other items used for construction of India Pavilion
should be of international standards and should adhere to the specifications
prescribed by fair authorities.
The Pavilion should focus on the theme “Incredible India! Visit India Year
2023” — as its campaign tagline to revive international tourism along with
effective ‘Incredible India’ branding.
There should be a dedicated activity area for cultural performances, yoga, sari
tying and mehndi demonstrations etc.

2.3.2

2.3.3

2.3.4

<!-- page 10 -->

2.3.5

2.3.6

Modern technology including 1 large video screens/walls should be
incorporated in the Pavilion. The video wall / screen would have static
displays for photo opportunities as well as for running loops of Incredible
India promotional films.
There should be easy accessibility to and within the Pavilion and double-sided
signage for all participants/ co-exhibitors in the Pavilion.

The India Pavilion atITB Asia 2023, (25 th to 27 th October 2023):
(i).
(ii).
(iii).

(iv).
(v).
(vi).
(vii).
(viii).
(ix).
(x).

(xi).
(xii).
(xiii).

(xiv).
(xv).

(xvi).

2.4.

Prominent and visible signage.
Visible and prominently located Reception area with Information Counters.
The registration / reception area should be equipped with appropriate
technologies that enable capturing information and exchanging information
with attendees/ visitors to the Pavilion digitally (such as QR code-based
systems)
A VIP lounge, comfortable enough to hold press interviews, meetings, etc.
Individual storage with locking provision, with visible fascia (i.e company name
of all Co-Exhibitors / participants properly displayed)
A separate larger, covered storage area for use by Ministry of Tourism.
Designated areas for activities such as mehndi application, handicraft display /
demonstrations, cultural performances, etc.
Office space, with working desks and chairs.
A Cafeteria/Restaurant area
A Pavilion plan display in four corners of the pavilion indicating the placement
of booths with booth numbers, for facilitating visitors and business contacts of
the co-exhibitors.
Internet connectivity and individual electrical connections.
Greenery/Plants to be placed within the Pavilion.
Optimum use is to be made of the first / mezzanine floor atITB Asia 2023, (25th
to 27th October 2023)where permissible, in keeping with the overall theme
and décor of the Pavilion.
The Pavilion should be erected on a raised platform of 2 inches and all images
displayed will be back lit in the form of Translates.
The space earmarked for common facilities including activity area will be
restricted to 30% of the total area of the Pavilion, whereas 70% of the area of
the Pavilion will be for booths / areas for participants in the Pavilion. This may
change depending on the registrations received.
The responsibility for required insurances and other formalities and adhering to
local laws and rules/regulations/requirements of the organisers of the event
would be the responsibility of the agency.
in time installation

<!-- page 11 -->

The agency should ensure that the India Pavilion is fully constructed and
ready to use latest by 1800 hrs. on the previous day prior to commencement
of
ITB Asia 2023, (25th to 27th October 2023).

2.5.

Pre-Bid Meeting
a. A pre-bid meeting will be held for the interested bidders in the Conference
Room, Ministry of Tourism, Government of India, Transport Bhavan, and 1
Parliament Street, New Delhi 110001 on 25/09/2023, for clarifications
required on any aspect pertaining to the tender Document. Any change in the
pre-bid meeting schedule will be notified on the Ministry of Tourism’s
website www.tourism.gov.in. The pre-bid queries could be sent to the
Ministry of Tourism prior to the meeting till 1500 hrs on 22/09/2023 as per
the following format :-

S. No.

Tender
No.

Clause

Page No.

Current
requirement

Clarifications
requested

b. Based on discussions held during the pre-bid meeting, amendments /
clarifications in the tender Document will be hosted on the websites of the
Ministry of Tourism www.tourism.gov.in and on e-procure website of the
Government of India.
2.6.

Guidelines for Submission of Bids
The Technical and Financial Bids for construction of India Pavilion a ITB Asia
2023, (25th to 27th October 2023)should be submitted in online mode.
The Technical Bid - Tender for Design & Construction of India Pavilion atITB Asia
2023, Singapore Should include the following documents/details:

S No.

Details required

1

Copy of PAN Card & GST Registration certificate (or Income
Tax Account Number as applicable for overseas bidder).

2

Profile of the Agency

Particulars

<!-- page 12 -->

3

Details of Technical Manpower and Staff available in–
house with the bidding agency.

4

Track record of the agency and Client completion
certificates during the four years i.e 2018-19, 2019-20,
2021-22 and 2022-23.

5

Details of Pavilions / Stands / Booths designed and
constructed for other countries at various International
fairs / exhibitions held overseas during the four years
i.e2018-19, 2019-20, 2021-22 and 2022-23

6

Chartered Accountant certificate only, indicating turnover
of the company during the
Calendar year 2021 or,
financial year 2021-22 (Audited) or,
Financial year 2022-23 (Audited) or,
calendar year 2022(Audited)
in support of fulfilling the requirement as indicated at
clause 2.1 to the RFP, to be submitted. Duly signed
certificate from Chartered Accountant only will be
accepted as supporting document.

2.7.

Fact sheet of the experience shall be given in below Table format:

Details of Specific Experience
Project 1
(i). Date of the event:
(ii). Area hired for construction of the pavilions in Sq. mts:
(iii). Entity for which Pavilion was constructed and also indicate
Govt/Pvt/PSU/Foreign Govt:
(iv). Completion Certificate No. (with the page number on which document is
attached):
(v). Work Order with reference no. (With the page no. on which document is
attached)
Project 2
(i). Name of the event:
(ii). Date of the event:
(iii). Area hired for construction of the pavilions in Sq. mts:
(iv). Entity for which Pavilion was constructed and also indicate

<!-- page 13 -->

Govt/Pvt/PSU/Foreign Govt:
Completion Certificate No. (with the page number on which document is
attached):
(vi).
Work Order with reference no. (With the page no. on which document is
attached);
Project 3
Name of the event:
(i). Date of the event:
(ii). Area hired for construction of the pavilions in Sq. mts:
(iii). Entity for which Pavilion was constructed and also indicate
Govt/Pvt/PSU/Foreign Govt:
(iv). Completion Certificate No. (with the page number on which document is
attached):
(v).
Work Order with reference no.
(With the page no. on which document is attached)
Project 4
Name of the event:
(i). Date of the event:
(ii). Area hired for construction of the pavilions in Sq. mts:
(iii). Entity for which Pavilion was constructed and also indicate
Govt/Pvt/PSU/Foreign Govt:
(iv). Completion Certificate No. (with the page number on which document is
attached):
(v).
Work Order with reference no. (With the page no. on which document is
attached)
Project 5
(i). Name of the event:
(ii). Date of the event:
(iii). Area hired for construction of the pavilions in Sq. mts:
(iv). Entity for which Pavilion was constructed and also indicate
Govt/Pvt/PSU/Foreign Govt:
(v). Completion Certificate No. (with the page number on which document is
attached):
(vi).
Work Order with reference no. (With the page no. on which document is
(v).

attached)

Notes:
2.7.1. The Bidder shall not have been declared ineligible for corrupt or fraudulent
practices with any
2.7.2. The Bidder shall not have been declared ineligible for corrupt or fraudulent
practices with any Government departments/ agencies/ ministries or PSU’s and
should not be blacklisted at the time of submission of bid. Further, bidding
agencies should submit an undertaking agreeing to undertake the assignment in
accordance with the Scope of Work and terms and conditions detailed in the
tender document. A declaration by the authorised representative of the bidding

<!-- page 14 -->

agency, on the letter head of the agency, to be submitted as per format given in
Annexure 1.
2.7.3. The Concept/ Design of the India Pavilion atITB Asia 2023, (25th to 27th October
2023) with detailed layout, decoration plan, etc.should be submitted online.
a.

BID SECURITY/ BID SECURITY DECLARATION
(i).

(ii).
(iii).
(iv).
(v).
(vi).

b.

A Bidder is required to submit, along with its Bid, Bid Security Declaration
as per Annexure - 3 (the, Bid Security Declaration) accepting that if they
withdraw or modify their Bids during period of validity etc. they will be
barred from submission of Bids in any Works/Service tender issued by
Ministry of Tourism, Government of India for a period upto 5 (five) years.
The Bid shall be summarily rejected if it is not accompanied by Bid Security
Declaration. The Bid document shall be available free of cost through
eProcurement Portal and Ministry of Tourism Website.)
The Bidder shall furnish as part of its Bid, a Bid Security Declaration.
Any Bid not accompanied by the Bid Security Declaration shall be
summarily rejected by the Authority as non-responsive.
The Authority shall be entitled to bar the Bidder from submission of Bids in
any Works/Service tender issued by Ministry of Tourism, Government of
India for a period upto 5 (five) years as Damages inter alia in any of the
events specified. The Bidder, by submitting its Bid pursuant to this RFP,
shall be deemed to have acknowledged and confirmed that the Authority
will suffer loss and damage on account of withdrawal of its Bid or for any
other default by the Bidder during the period of Bid validity as specified in
this RFP. No relaxation of any kind on Bid Security declaration shall be given
to any Bidder.

SUPERSCRIBED “FINANCIAL BID” – TENDER FOR DESIGN & CONSTRUCTION OF INDIA
PAVILION ATITB ASIA 2023, (25TH TO 27TH OCTOBER 2023)
While submitting the Financial Proposal, the Applicant shall ensure the
following:
(i).
(ii).

(iii).
(iv).

The financial bid forITB Asia 2023, (25th to 27th October 2023) must be
submitted as per Performa at Annexure- 2.
Financial bids of technically qualified agencies will be evaluated on the basis
of total cost for event [i.e cost quoted forITB Asia 2023, (25th to 27th
October 2023)] exclusive of taxes/GST.
GST / Taxes as applicable will be paid by the Ministry of Tourism
The bid of the agency will be treated as unresponsive in case of a mismatch
while quoting financial cost between figure and words, or mismatch
between per sq. mtr. Rate and total cost.

<!-- page 15 -->

(v).

The financial bid should be in Indian Rupees (INR). If, however, the Agency
has formulated costs in a currency other than Indian Rupees (INR), for the
sake of uniformity and comparison, the same may be converted to Indian
Rupees (INR) as per the official exchange rate of the Ministry of External
Affairs (MEA), Government of India for the month of September2023.
Official MEA exchange rates for the month of September2023 in respect
of some of the leading currencies:

Foreign Currency

INR (September
2023)

1 US Dollar

Rs. …..

1 Pound Sterling

Rs. ….

1 Euro

Rs. ….

To view the official currency exchange rates of MEA for the month of
September 2023 bidders may refer to Annexure-5.

c.

(vi).

The cost quoted will be firm (in the currency quoted) and fixed for the
duration of performance of the contract. At no point of time will any
deviation from the quoted rate (in the currency quoted) be entertained by
the Ministry of Tourism.

(vii).

The Financial Bid shall not include any conditions attached to it and any such
conditional financial proposal shall be rejected summarily.

SUBMISSION TO BE IN ELECTRONIC FORM
The Applicant shall submit his bid in the electronic form on or before 1700
hrs on 09/10/2023.Document to be signed by authorized representatives.

d.

DOCUMENT TO BE SIGNED BY AUTHORIZED REPRESENTATIVES.
Proposals along with all the scanned copies of the document should be
submitted in the electronic form only through online portal as mentioned above.
Before the proposal documents are uploaded, all attached documents should be
signed by the authorized representative (the “Authorised Representative”) as
detailed below:
a) by the proprietor, in case of a proprietary firm; or
b) by a partner, in case of a partnership firm and/or a limited liability
partnership; or,

<!-- page 16 -->

c) by a duly authorized person holding the Power of Attorney, in case of a
Limited Company or a corporation.
e.

POWER OF ATTORNEY
The Applicant should submit a Power of Attorney as per the format at Form 3 of
Appendix- I; provided, however, that such Power of Attorney would not be
required if the bid submission is signed by a Partner or Director (on the Board of
Directors) of the Applicant in case the Applicant is a partnership firm or limited
liability partnership.

f.

OFFLINE BIDS.
Those bids sent offline will not be entertained.

g.

SIGNED AND STAMPED (BY SEAL OF COMPANY ) ON EACH PAGE.
All documents submitted by agencies should be signed and submitted by the
authorized signatory of the company. The document should be spiral bound, duly
page numbered, and properly indexed. The agencies who do not submit their
bids in the proper format, with required documents and in the required format
will be liable for rejection.

h.

TERMS AND CONDITIONS
(i).

The agencies submitting their bids should also mention that they agree to
the terms and conditions mentioned in the tender document.
The successful agency will execute a Performance Guarantee for 10% of
the total value of the contract in the form of Account Payee Demand
Draft or a Bank Guarantee from a Commercial Bank in an acceptable form
or in the form of a Fixed Deposit Receipt pledged to the ‘Pay & Accounts
Officer, Ministry of Tourism’ payable at New Delhi. The Performance
Guarantee should remain valid for a period of 60 days beyond the
completion of the period of contract. The Security Deposit/Bank
Guarantee will be released after satisfactory completion of the
contractual obligation on part of the agency.

(ii).

3
3.1.

OPENING OF BIDS AND SELECTION PROCEDURE

Opening of Bids
Technical bids will be opened in the presence of representatives of agencies
submitting bids at 03.00 hrs. on ----/ ---/2023 to ascertain fulfilment of eligibility

<!-- page 17 -->

criteria and submission of required documents. Thereafter, a Constituted
Committee will evaluate the Technical Bids of the agencies which are found eligible
after initial scrutiny of the bids. Evaluation of technical bids of the eligible agencies
would be based on documents furnished in support of items at Sr. No. (i) of the
table in Para 3.2. In respect of items at Sr. No. (ii) to (vi) of the table, the evaluation
would be on the basis of presentation on Concept & design to be made by the
eligible tenderers/agencies before the said Constituted Committee in the Ministry
of Tourism. Date, time and venue of the presentations will be conveyed to the
eligible agencies.

3.2.

Technical Bids evaluation criteria
The technical bids will be judged following the criteria as detailed below:
Component

S.No.

(i)

(ii)

(iv)

(v)
(vi)

(i).

Marks

Experience in setting up of Pavilions/ Booths/ Stands at
International Fairs / Exhibitions in an area of 100 Sq. Mt and
above held overseas during four years 2018-19, 2019-20, 50 marks
2021-22 and 2022-23.
(10 marks per fair & exhibition for a maximum of 50 Marks)
Concept & Design of Pavilion

Effective Utilization of Space including the first /
mezzanine Floor

25 marks
8 marks

Effective Branding in the Pavilion

8 marks

Innovative ideas and other attractions in the Pavilion

9 marks

Total

100 marks

Whereas, Technical Evaluation will carry a weightage of 70%, financial bids
will carry weightage of 30% . The agencies scoring 70 per cent marks (70
marks) or above in the Technical Evaluation shall be eligible for opening of
their financial bids.

<!-- page 18 -->

(ii).

(iii).

(iv).

The financial bids of only those agencies that score 70% per cent marks (70
marks) or above in Technical Evaluation will be opened in the presence of
their representatives. The date and time of opening of the financial bids will
be conveyed to the selected agencies. Financial evaluation will carry a
weightage of 30 Marks.
The agency which scores the highest aggregate marks on the basis of
technical and financial evaluation (after adding the scores from the technical
and financial evaluation) will be awarded the contract for construction of
the India Pavilion at the event.
The Financial Bid is to be submitted, based on space given in Details of the
Pavilion under clause 2.1 of the tender document atITB Asia 2023, (25th to
27th October 2023). However, in the event of any change in the space
booked for the India Pavilion at any of the said events, the total cost
(exclusive of taxes) quoted by the agency would be reduced / increased on
pro-rata basis (on per sq. mtr. basis).

3.3. Terms of Payment
The key deliverables, timelines and payment milestone for the assignment are
given below:

Sno.

1

2

Key Deliverables
Timely completion of construction of the Pavilion
authenticated by the concerned officer of the Ministry of
Tourism, Government of India.
Once the successful bidder has obtained a certificate from
the concerned officer of the Ministry of Tourism,
Government of India on completion of the Travel Mart,
dismantling the pavilion and clearing of the site
satisfactorily in accordance with the terms and conditions
of the Work Order issued to the Agency.

4

INSTRUCTIONS TO APPLICANTS
4.1.

ADDITIONAL CONDITIONS

Payment

50%
50%

<!-- page 19 -->

(i). The Ministry of Tourism reserves the right to reject or accept any offer without
assigning any reasons whatsoever.
(ii). Incomplete and conditional bids will be rejected outright.
(iii). Any Displays / Translites produced for the India Pavilion at the events will be
the property of the Ministry of Tourism, Govt. of India, on completion of the
contractual period.
(iv). Design selected for the India Pavilion atITB Asia 2023, (25th to 27th October
2023)will be the property of the Ministry of Tourism. The Ministry of Tourism
reserves it right to use the same design for other fairs organized / participated
by the Ministry of Tourism and its field offices in India and overseas.
(v). The selected service provider will ensure that the design, construction and
maintenance of the India Pavilion are in compliance with the regulations
issued by the fair/exhibition organizers including insurance as applicable.
(vi). The Ministry of Tourism is, however, not bound to accept any tender or to
assign any reason for non-acceptance. The Ministry of Tourism reserves its
right to accept the tender either in full or in part. Conditional, erroneous and
incomplete Bids will be rejected outright.
(vii). The Ministry of Tourism reserves its right to summarily reject an offer received
from any agency on national security considerations, without any intimation to
the bidder.
(viii). The Ministry of Tourism reserves the right to place an order for the full or part
quantities under any items of work under scope of work.
(ix). Agencies submitting proposals will not be permitted to alter or modify their
bids after expiry of the deadline for receipt of bids.
(x). The Ministry of Tourism reserves its right not to accept bids from agencies
resorting to unethical practices or on whom investigation/enquiry proceedings
has been initiated by Government Investigating Agencies / Vigilance Cell.
4.2.

LIQUIDATED DAMAGES

In the event of service provider’s failure to complete the work within the specified
time as indicated at clause 5 above, and as per the requirements of standards of
quality constructions, as mentioned in the tender document, the Ministry of
Tourism will recover from the service provider, as Liquidated Damages, a sum of 2
% of the total cost of the contract for every hour’s delay beyond 1800 hrs. of the
previous day till 0700 hrs. on the day of commencement of the Fair. In case, the
agency fails to handover the stand fully constructed in all respect for use by the
Ministry of Tourism by 0700 hrs., the total cost of the project payable would be
forfeited, besides, the Ministry may take action to debar the agency from
participation in future tenders and/or blacklist the agency.
4.3.

VALIDITY OF TENDER

The period of validity of the Tender is 120 days from the closing date of the
proposals. If need be, necessary extension would be considered by the Ministry of

<!-- page 20 -->

Tourism.
4.4.

INSURANCE

Insurance, including transit insurance will be arranged by the service provider.
4.5.

TERMINATION BY DEFAULT

The Ministry of Tourism reserves the right to terminate the contract of any agency
in case of a change in the Government procedures or for unsatisfactory services.
4.6.

RISK – PURCHASE CLAUSE

If the service provider, after submission of tender and the acceptance of the same,
fails to abide by the Terms and Conditions of the tender document or fails to
complete the work within the specified time or at any time repudiates the
contract, the Ministry of Tourism will have the right to:
(i).
(ii).

(iii).

(iv).

Forfeit the EMD
Invoke Security Deposit / Performance Bank Guarantee, debar it from
participation in further tenders, can initiate action to recover the liquidated
damage and consider black listing of firm.
In case the Ministry gets the incomplete job completed through alternative
sources and ifprice of completing the work is higher, the service provider shall
pay the balance amount incurred by the Ministry for completing the work, to
the Ministry.
For all purposes, the work order accepted by the bidder and issued by the
Ministry of Tourism will be considered as the formal contract.
4.7.

(i).

(ii).
(iii).
(iv).
(v).
(vi).

BID SECURITY/ BID SECURITY DECLARATION

A Bidder is required to submit, along with its Bid, Bid Security Declaration as per
Annexure - 3 (the, Bid Security Declaration) accepting that if they withdraw or
modify their Bids during period of validity etc. they will be barred from
submission of Bids in any Works/Service tender issued by Ministry of Tourism,
Government of India for a period upto 5 (five) years.
The Bid shall be summarily rejected if it is not accompanied by Bid Security
Declaration. The Bid document shall be available free of cost through
eProcurement Portal and Ministry of Tourism Website.)
The Bidder shall furnish as part of its Bid, a Bid Security Declaration.
Any Bid not accompanied by the Bid Security Declaration shall be summarily
rejected by the Authority as non-responsive.
The Authority shall be entitled to bar the Bidder from submission of Bids in any
Works/Service tender issued by Ministry of Tourism, Government of India for a
period upto 5 (five) years as Damages inter alia in any of the events specified.
The Bidder, by submitting its Bid pursuant to this RFP, shall be deemed to have
acknowledged and confirmed that the Authority will suffer loss and damage on

<!-- page 21 -->

account of withdrawal of its Bid or for any other default by the Bidder during
the period of Bid validity as specified in this RFP. No relaxation of any kind on
Bid Security declaration shall be given to any Bidder.
4.8.

FORCE MAJEURE

Neither party will be liable in respect of failure to fulfil its obligations, if the said
failure is entirely due to Acts of God, Governmental restrictions or instructions,
natural calamities or catastrophe, epidemics or disturbances in the country. If
there is a delay in performance or other failures by the service provider to perform
its obligation under its contract due to event of a Force Majeure, the service
provider shall not be held responsible for such delays/failures. If a Force Majeure
situation arises, the service provider shall promptly notify the Ministry in writing of
such conditions and the cause thereof providing sufficient and satisfactory
evidence immediately on occurrence of such event. Unless otherwise directed by
the Ministry in writing, the service provider shall continue to perform its
obligations under the contract as far as reasonably practicaland shall seek all
reasonable alternative means for performance not prevented by the Force
Majeure event.
4.9. ARBITRATION
(i). In event of any dispute or difference between the Ministry and the Agency, such
disputes or differences shall be resolved amicably by mutual consultation. If such
resolution is not possible, then the unresolved dispute or difference shall be
referred to arbitration of the sole arbitrator to be appointed by the Secretary,
Ministry of Tourism on the recommendation of the Department of Legal Affairs,
Government of India. The provision of Arbitration and Conciliation Act, 1996
(No.26 of 1996) shall be applicable to the arbitration. The Venue of such
arbitration shall be at New Delhi or any other place, as may be decided by the
arbitrator. The language of arbitration proceedings shall be English. The
arbitrator shall make a reasoned award (the “Award”), which shall be final and
binding on the Ministry and the Agency.
(ii). The cost of the arbitration shall be shared equally by both the parties to the
agreement i.e. the Ministry and the Agency (ies) and the service provider.
However, expenses incurred by each party in connection with the preparation,
presentation shall be borne by the party itself.
(iii). Pending the submission of and /or decision on a dispute, difference or claim or
until the arbitral award is published; the Ministry and the Agency shall continue
to perform all of their obligations under this Agreement without prejudice to a
final adjustment in accordance with such award.
a.

IN TIME INSTALLATION

The agency should ensure that the India Pavilion is fully constructed and

<!-- page 22 -->

ready to use latest by 1800 hrs. on the previous day prior to
commencement of ITB Asia 2023, Singapore (25th to 27th October 2023).
b.

PREPARATION AND SUBMISSION OF PROPOSAL

Technical Specifications and requirements
I.

India Pavilion at ITB Asia 2023, from (25th to 27th October 2023)
ITB Asia 2023, Singapore (25th to 27th October 2023)will have 10-12 individual
booths of 4 Sq. Mt. each for co-exhibitors in the pavilion. This may vary depending
on the registrations received.

II.

Submission to be in electronic form
The Applicant shall submit his bid in the electronic form on or before 1700 hrs on
26/09/2023.Document to be signed by authorized representatives.

III.

Document to be signed by authorized representatives.
Proposals along with all the scanned copies of the document should be submitted
in the electronic form only through online portal as mentioned above. Before the
proposal documents are uploaded, all attached documents should be signed by
the authorized representative (the “Authorised Representative”) as detailed
below:
a) by the proprietor, in case of a proprietary firm; or
b) by a partner, in case of a partnership firm and/or a limited liability
partnership; or,
c) by a duly authorized person holding the Power of Attorney, in case of a
Limited Company or a corporation.

IV.

Signed and Stamped (by seal of company) on each page.
All documents submitted by agencies should be signed and submitted by the
authorized signatory of the company. The document should be spiral bound, duly
page numbered, and properly indexed. The agencies who do not submit their bids
in the proper format, with required documents and in the required format will be
liable for rejection.

V.

List of Documents to be submitted in original to the authority
The following documents are required to be submitted in original online, failing
which the Bid shall be rejected:
(a).
(b).

Power of Attorney as required under Clause 2.5
Bid Security Declaration

<!-- page 23 -->

The bid specified shall clearly bear the following identification:
“RFP for Design & Construction of India Pavilion atITB Asia 2023, Singapore from
(25th to 27th October 2023)for Ministry of Tourism, Govt. of India”
4.10. JURISDICTION
The contract shall be governed by the Laws of India.

Asst. Director General (OM)
Ministry of Tourism
Government of India, New Delhi
SCHEDULES
SCHEDULE - 1: TERMS OF REFERENCE ( TOR)
(See Clause 2.3)
Terms of Reference

2.

Technical Specifications and Requirements
2.3.7

2.3.8

2.3.9

2.3.10
2.3.11

2.3.12

India Pavilion atITB Asia 2023, Singapore (25th to 27th October 2023)will have
10-12 individual booths of 4 Sq. Mt. each for co-exhibitors in thepavilion. This
may vary depending on the registrations received.
The Pavilion should reflect an open and inviting look, with minimum barriers
and have a professional business type layout conducive for conducting buyer–
seller meetings. Material and other items used for construction of India Pavilion
should be of international standards and should adhere to the specifications
prescribed by fair authorities.
The Pavilion should focus on the theme “Incredible India! Visit India Year
2023” — as its campaign tagline to revive international tourism along with
effective ‘Incredible India’ branding.
There should be a dedicated activity area for cultural performances, yoga, sari
tying and mehndi demonstrations etc.
Modern technology including 1 large video screens/walls should be
incorporated in the Pavilion. The video wall / screen would have static
displays for photo opportunities as well as for running loops of Incredible
India promotional films.
There should be easy accessibility to and within the Pavilion and double-sided

<!-- page 24 -->

signage for all participants/ co-exhibitors in the Pavilion.
The India Pavilion atITB Asia 2023, Singapore (25th to 27th October 2023)should have:
(i).
(ii).
(iii).

(iv).
(v).
(vi).
(vii).
(viii).
(ix).
(x).

(xi).
(xii).
(xiii).
(xiv).
(xv).

(xvi).

Prominent and visible signage.
Visible and prominently located Reception area with Information Counters.
The registration / reception area should be equipped with appropriate
technologies that enable capturing information and exchanging information
with attendees/ visitors to the Pavilion digitally (such as QR code-based
systems)
A VIP lounge, comfortable enough to hold press interviews, meetings, etc.
Individual storage with locking provision, with visible fascia (i.e company name
of all Co-Exhibitors / participants properly displayed)
A separate larger, covered storage area for use by Ministry of Tourism.
Designated areas for activities such as mehndi application, handicraft display /
demonstrations, cultural performances, etc.
Office space, with working desks and chairs.
A Cafeteria/Restaurant area
A Pavilion plan display in four corners of the pavilion indicating the placement
of booths with booth numbers, for facilitating visitors and business contacts of
the co-exhibitors.
Internet connectivity and individual electrical connections.
Greenery/Plants to be placed within the Pavilion.
Optimum use is to be made of the first / mezzanine floor atITB Asia 2023,
Singapore (25th to 27th October 2023)
The Pavilion should be erected on a raised platform of 2 inches and all images
displayed will be back lit in the form of Translates.
The space earmarked for common facilities including activity area will be
restricted to 30% of the total area of the Pavilion, whereas 70% of the area of
the Pavilion will be for booths / areas for participants in the Pavilion. This may
change depending on the registrations received.
The responsibility for required insurances and other formalities and adhering to
local laws and rules/regulations/requirements of the organisers of the event
would be the responsibility of the agency.

3.

Key Deliverables and Payment Schedule

3.1.

The key deliverables, timelines and payment milestone for the assignment are given
below:
Sno.
1

Key Deliverables
Timely completion of construction of the Pavilion
authenticated by the concerned officer of the Ministry of

Payment
50%

<!-- page 25 -->

Sno.

Key Deliverables

Payment

Tourism, Government of India.
Once the successful bidder has obtained a certificate from
the concerned officer of the Ministry of Tourism,
Government of India on completion of the Travel Mart,
dismantling the pavilion and clearing of the site satisfactorily
in accordance with the terms and conditions of the Work
Order issued to the Agency.

2

50%

Note:
(i). Payment of the contractual amount will be made by electronic transfer as per the
Bank details received from the successful bidder.

3.2.

Evaluation Criteria
The technical bids will be judged following the criteria as detailed below:
Component

S.No.

(i)

(ii)

(iv)

(v)
(vi)

Marks

Experience in setting up of Pavilions/ Booths/ Stands at
International Fairs / Exhibitions in an area of 100 Sq. Mt and
above held overseas during four years 2018-19, 2019-20, 50 marks
2021-22 and 2022-23.
(10 marks per fair & exhibition for a maximum of 50 Marks)
Concept & Design of Pavilion

Effective Utilization of Space including the first /
mezzanine Floor

25 marks
8 marks

Effective Branding in the Pavilion

8 marks

Innovative ideas and other attractions in the Pavilion

9 marks

Total

100 marks

<!-- page 26 -->

(i).

(ii).

(iii).

(iv).

4.

Whereas, Technical Evaluation will carry a weightage of 70%, financial bids
will carry weightage of 30%. The agencies scoring 70 per cent marks
(70 marks) or above in the Technical Evaluation shall be eligible for opening
of their financial bids.
The financial bids of only those agencies that score 70% per cent marks
(70 marks) or above in Technical Evaluation will be opened in the presence
of their representatives. The date and time of opening of the financial bids
will be conveyed to the selected agencies. Financial evaluation will carry a
weightage of 30 Marks.
The agency which scores the highest aggregate marks on the basis of
technical and financial evaluation (after adding the scores from the technical
and financial evaluation) will be awarded the contract for construction of
the India Pavilion at the event.
The Financial Bid is to be submitted, based on space given in Details of the
Pavilion under clause 2.1 of the tender document atITB Asia 2023, (25th to
27th October 2023). However, in the event of any change in the space
booked for the India Pavilion at any of the said events, the total cost
(exclusive of taxes) quoted by the agency would be reduced / increased on
pro-rata basis (on per sq. mtr. basis).

Financial Proposal

4.1. Formats to be adhered
Applicants shall submit the financial proposal in the formats at Appendix-II (the
“Financial Proposal”) clearly indicating the total cost of the Consultancy of Form-2 of
Appendix-II) in both figures and words, in Indian Rupees, and signed by the
Applicant‘s Authorised Representative. The bid of the Consultancy will be treated as
unresponsive in case of a mismatch while quoting financial cost between figure and
words.
4.2. Superscribed “Financial Bid” – Tender for Design & Construction of India
Pavilion atITB Asia 2023, Singapore (25th to 27th October 2023).
While submitting the Financial Proposal, the Applicant shall ensure the following:
(i).
(ii).

(iii).

The financial bid forITB Asia 2023, Singapore must be submitted as per
Performa at Annexure- 2.
Financial bids of technically qualified agencies will be evaluated on the basis
of total cost for event [i.e cost quoted for ITB Asia 2023, Singapore (25th to
27th October 2023) exclusive of taxes/GST.
GST / Taxes as applicable will be paid by the Ministry of Tourism

<!-- page 27 -->

(iv).

The bid of the agency will be treated as unresponsive in case of a mismatch
while quoting financial cost between figure and words, or mismatch between
per sq. mtr. Rate and total cost.

(v).

The financial bid should be in Indian Rupees (INR). If, however, the Agency
has formulated costs in a currency other than Indian Rupees (INR), for the
sake of uniformity and comparison, the same may be converted to Indian
Rupees (INR) as per the official exchange rate of the Ministry of External
Affairs (MEA), Government of India for the month of September2023.

Official MEA exchange rates for the month of September2023 in respect of some of
the leading currencies:

Foreign Currency

INR (September 2023)

1 US Dollar

Rs. …..

1 Pound Sterling

Rs. ….

1 Euro

Rs. ….

To view the official currency exchange rates of MEA for the month of September 2023
bidders may refer to Annexure-5.
(vi).

The cost quoted will be firm (in the currency quoted) and fixed for the
duration of performance of the contract. At no point of time will any
deviation from the quoted rate (in the currency quoted) be entertained by
the Ministry of Tourism.

(vii).

The Financial Bid shall not include any conditions attached to it and any such
conditional financial proposal shall be rejected summarily.

<!-- page 28 -->

APPENDIX-I: TECHNICAL PROPOSAL FORMS
(See Clause 2)
APPENDIX-I
Form 3: Power of Attorney for Authorised Representative
Know all men by these presents, we, ......................................... (name of Firm and address of
the registered office) do hereby constitute, nominate, appoint and authoriseMr /
Ms........................................
son/daughter/wife
and
presently
residing
at
........................................, who is presently employed with us and holding the position of
.................... as our true and lawful attorney (hereinafter referred to as the “Authorised
Representative”) to do in our name and on our behalf, all such acts, deeds and things as are
necessary or required in connection with or incidental to submission of our Proposal for
___________________________________________________, proposed to be done by the
.......................................... (the “Authority”) including but not limited to signing and
submission of all applications, proposals and other documents and writings, participating in
pre-bid and other conferences and providing information/ responses to the Authority,
representing us in all matters before the Authority, signing and execution of all contracts and
undertakings consequent to acceptance of our proposal and generally dealing with the
Authority in all matters in connection with or relating to or arising out of our Proposal for the
said Project and/or upon award thereof to us till the entering into of the Agreement with the
Authority.
AND, we do hereby agree to ratify and confirm all acts, deeds and things lawfully done or
caused to be done by our said Authorised Representative pursuant to and in exercise of the
powers conferred by this Power of Attorney and that all acts, deeds and things done by our
said Authorised Representative in exercise of the powers hereby conferred shall and shall
always be deemed to have been done by us.
IN WITNESS WHEREOF WE, ................................ THE ABOVE NAMED PRINCIPAL HAVE
EXECUTED THIS POWER OF ATTORNEY ON THIS ...................................... DAY OF ....................,
20.......
For ............................................

(Signature, name, designation and address)
Witnesses:
1.
2.

<!-- page 29 -->

Notarised
Accepted
........................................
(Signature, name, designation, and address of the Attorney)

Notes:
1.

The mode of execution of the Power of Attorney should be in accordance with the
procedure, if any, laid down by the applicable law and the charter documents of the
executant(s) and when it is so required the same should be under common seal
affixed in accordance with the required procedure. The Power of Attorney should be
executed on a non-judicial stamp paper of Rs. 100 (hundred) and duly notarised by a
notary public.

2.

Wherever required, the Applicant should submit for verification the extract of the
charter documents and other documents such as a resolution/power of attorney in
favour of the person executing this Power of Attorney for the delegation of power
hereunder on behalf of the Applicant.

3.

For a Power of Attorney executed and issued overseas, the document will also have
to be legalised by the Indian Embassy and notarised in the jurisdiction where the
Power of Attorney is being issued. However, Applicants from countries that have
signed the Hague Legislation Convention 1961 need not get their Power of Attorney
legalised by the Indian Embassy if it carries a conforming Apostille certificate.

<!-- page 30 -->

ANNEXURE-I: Declaration by bidding agency
(On Applicant‘s letter head)
The Asst. Director General (OM),
Ministry of Tourism
Transport Bhawan,
1, Parliament Street, New Delhi
Subject: - Undertaking
Madam/Sir,
This has reference to the Ministry of Tourism’s Tender no.………………
dated ………….for Design & Construction of India Pavilion atITB Asia 2023,
Singapore (25th to 27th October 2023).

In this context, I / We as an authorized representative(s) of company
certify the following:(a)
That we are not declared ineligible for corrupt or fraudulent
practices with any Government departments/ agencies/ Ministries or
PSU’s and are not blacklisted on the date of submission of this bid.
(b)
That we will undertake the assignment, in accordance with the
Scope of Work and the terms & conditions detailed in the tender
document and at the cost submitted by the agency in the financial bid
(Cost should not be mentioned in this undertaking).

Name of the Bidder: ..................................
AuthorisedSignatory:.................................
Name:
Seal:
Date:
Place:

Page 29 of 41

<!-- page 31 -->

ANNEXURE - II: FINANCIAL PROPOSAL FORMS
Form 1: Covering Letter
(On Applicant‘s letter head)
To be provided on ‘Company letter head’

The Asst. Director General (OM),
Ministry of Tourism
Transport Bhawan,
1, Parliament Street, New Delhi
Subject: -Financial Quote Details.
Madam / Sir,
This has reference to the Ministry of Tourism’s RFP no. …………………
dated
……………………. for Design & Construction of India Pavilion atITB Asia 2023,
Singapore (25th to 27th October 2023).
2. In this context, our total financial quote (for ITB Asia 2023, Singapore 25th
to 27th October 2023 in respect of above RFP is Rs. ................./-(Rupees in
words), excluding taxes/GST, as detailed below:

Sr. Particulars
No.

ITB Asia 2023, Singapore
(25th to 27th October 2023)
Cost per Sq. Total Cost.
Mt.
(Excl. Taxes
(Excl. Taxes
GST
GST

a)

Total cost of Fabrication of India
Pavilion (Exclusive of Taxes / GST)
(including adaptation of the
design, construction, maintenance
& dismantling of the pavilion;
Decoration, branding & Display

Page 30 of 41

<!-- page 32 -->

within the pavilion; Transportation
of material if any to the site and
back and Expenditure on any other
activities / components including
those listed in the scope of work,
etc.)
b)

Total cost forITB Asia 2023,
Singapore (25th to 27th
October 2023) (exclusive of
traxes / GST) in words.

3. I / We understand that the total cost (exclusive of taxes / GST) as given
above will be considered for financial evaluation.

Name of the Bidder: ..................................
AuthorisedSignatory:..........................
.......
Name:
Seal:
Date:
Place:
Please Note
(i)

Financial bids of technically qualified agencies will be evaluated on the
basis of total cost for event (i.e. cost quoted forITB Asia 2023, Singapore
(25th to 27th October 2023) exclusive of taxes/GST.

(ii)

GST / Taxes as applicable will be paid by the Ministry of Tourism.

(iii)

The bid of the agency will be treated as unresponsive in case of a
mismatch while quoting financial cost between figure and words, or
mismatch between per sq. mtr. Rate and total cost.

(iv)

The financial bid should be in Indian Rupees (INR). If, however, the Agency
has formulated costs in a currency other than Indian Rupees (INR), for the
sake of uniformity and comparison, the same may be converted to Indian

Page 31 of 41

<!-- page 33 -->

Rupees (INR) as per the official exchange rate of the Ministry of External
Affairs (MEA), Government of India for the month of September 2023.

Official MEA exchange rates for the month of September 2023 in respect of
some of the leading currencies:

Foreign Currency

INR (September 2023)

1 US Dollar

Rs. …..

1 Pound Sterling

Rs. …..

1 Euro

Rs. …..

To view the official currency exchange rates of MEA for the month of
September 2023, bidders may refer to Annexure- 5.
(v)

(vi)

The cost quoted will be firm (in the currency quoted) and fixed for the
duration of performance of the contract. At no point of time will any
deviation from the quoted rate (in the currency quoted) be entertained
by the Ministry of Tourism.
The Financial Bid shall not include any conditions attached to it and any
such conditional financial proposal shall be rejected summarily.

Page 32 of 41

<!-- page 34 -->

ANNEXURE- 3 BID SECURITY DECLARATION

Bid Security Declaration Format

(To be forwarded on the letterhead of the Bidder)

Ref. Date:

Tender No.:

To
The Asst Director General(OM),
Ministry of Tourism
Transport Bhawan,
1, Parliament Street, New Delhi

Sub: Bid for ……………………………. Project
I/We hereby declare that

1.

I/We am/are aware that I/we have been exempted from submission of Bid
Security in lieu of this Bid Security Declaration.

2.
3.

I/We understand that bid must be supported by a Bid-Security Declaration.

4.

I/We agree that the decision of the Authority regarding invocation of the Bid
Security Declaration shall be final and binding on me/us and shall not be
called upon in question under any circumstances.

5.

Name and Signature of Authorized Signatory of Bidder along with seal of
Bidder

I/We understand and accept that if I/We withdraw my/our bid within the bid
validity period or if awarded the bid and on being called upon to submit the
Performance Guarantee/Performance security, fail to submit the same
within the stipulated time period as mentioned in the bidding document or
on being called upon to sign the contract agreement, fail to sign the same
within such period mentioned in the bidding document, I/We , i.e.
*******************(the name of bidder) accept that I/ We shall be
banned from submission of Bids in any Works/Service tender issued by
Ministry of Tourism for a period upto 5 (five) years.

Page 33 of 41

<!-- page 35 -->

FLOOR PLAN OF ITB ASIA 2023, SINGAPORE

Page 34 of 41

<!-- page 36 -->

4 sq
5m

Wa
ll*

TAMILNADUTOURISM

BoothNo.：
（
6A-06 ）
1

8 sq
1m
GOATOURISM

（
：
6A-0 ）
BoothN
o.
6
0

India

108 sq
m

Area

TheMinistryofIndia

BoothNo.

3 sq
6m

（

RajasthanTo
urism
（
6A-0 ）
Booth：
No.
5
7
4 sq
5m

：
6A-0 ）
5
9

3 sq
Wa 6 m
ll* Karnat

UttarPrad
aka
esh
（
6A-0 ）
Booth：
（
6A-0 ）
Booth：
No.
5
Page 35 of 41 No.
5
6
8

*W ：
Setupbytheorga

<!-- page 37 -->

ANNEXURE -5
MEA OFFICIAL RATE OF EXHCHANGE SEPTEMBER 2023

Page 36 of 41

<!-- page 38 -->

Page 37 of 41

<!-- page 39 -->

Page 38 of 41

<!-- page 40 -->

Page 39 of 41

<!-- page 41 -->

Page 40 of 41

<!-- page 42 -->

Page 41 of 41
