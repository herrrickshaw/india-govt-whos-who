---
doc_id: "dbbbeb9caed57141"
source_url: "https://www.dot.gov.in/static/uploads/2026/02/cd99783148de26988684d267802f7681.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "86 Amendment to the existing KYC instructions for M2M connections"
date: "2024-03-21"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fdad47b18678a9c8"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
(Access Services Wing)
12th Floor, Sanchar Bhawan, 20 Ashoka Road, New Delhi ~ 110 001
Dated: 21.03.2024

File No: 800-09/2010-VAS-III
To
All UAS/ UL (having Access Service Authorization) Licensees

Subject: Amendment to the existing KYC instructions for M2M connectionsrelaxation of the restrictive features for M2M connections
This is in reference to this office letters of even number dated 16.05.2018 and
30.05.2019 vide which instructions for implementing restrictive features for SIMs used
only for M2M communication services and related KYC instructions were issued. The
telecom industry, vide its various representations, has requested for relaxation of
restrictive features for SIMs used only for M2M communication services.
In this regard, the representations of the telecom industry have been examined and
the undersigned is directed to convey the approval of competent authority for the

2.

following:
i.

The restrictive features for M2M SIMs as mentioned in para 4 of DoT instructions
dated 16.05.2018 (which was earlier relaxed vide letter dated 30.05.2019) shall be
replaced as under:
a.
Outgoing/ Incoming calls shall be allowed to/from predefined set of
maximum four (4) numbers only.
b.
Likewise outgoing/ incoming SMS shall be allowed to/from predefined set
of maximum four (4) numbers only.
Data communication shall be allowed on a maximum of One Hundred (100)
c.
predefined public IP addresses/ URLs with fixed APNs or equivalent
technology options by the Licensee.
d.
These restrictions are not applicable to calls made to emergency numbers
like police, fire, ambulance, etc.

Note: A list of such numbers/ IP addresses is to be provided to the licensee while
obtaining M2M SIM cards. At a later stage, if the need arises, the licensee can be requested
to change/ reconfigure these numbers/IP addresses. These restrictive features shall be
configured by the licenseein its network and shall not apply to data communication on
private networks/ VPNs.

lof2

RO

<!-- page 2 -->

The earlier instructions in respect of M2M SIMs are amended to above extent only
and other terms & conditions of earlier instructions shall remain the same.
3.

ADG (AS-II)
Copy to:
1. DG (T), DoT HQ, New Delhi for kind information & necessary action.
2.

DDG (NT)/ DDG (SA)/ DDG (Al&DIU), DoT HQ, New Delhi

3. JS (CIS), MHA, North Block, New Delhi- for kind information.

20f2
