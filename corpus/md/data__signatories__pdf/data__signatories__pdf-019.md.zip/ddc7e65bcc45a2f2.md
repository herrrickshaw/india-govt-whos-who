---
doc_id: "ddc7e65bcc45a2f2"
source_url: "https://powermin.gov.in/static/uploads/2025/06/fea600f98bd27b80c524002ef2fffb7f.pdf"
ministry: "Power"
title: "tender 78"
date: "2025-07-14"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "4255ba4a2f1a30be"
---

<!-- page 1 -->

No. 7/12/2011-Adm.II1
भारत सरकार
Government of India
विद्युत मंत्रालय
Ministry of Power
Shram Shakti Bhawan, Rafi Marg, New Delhi —- 110001
Telephone No. 23766253
July 14, 2011
To
(As per list enclosed) .
Subject: Tender for disposal of old and obsolete computers hardwares & peripherals.
Sir,

I am directed to invite sealed quotations/financial bid from the firms registered with Central
Pollution Control Board possessing valid registration number for disposal of old/unusable/obsolete
computer hardwares and peripherals of this Ministry on ‘As is where is basis’. All items are located at
Shram Shakti Bhanwan/Nirman Bhawan. Items identified for disposal would be available for inspection
for the firms at Room No. 22, Shram Shakti Bhawan, New Delhi on any working day between 3.00-5.00
PM.

2. Interested firms registered with Central Pollution Control Board possessing valid registration are
advised to speed post or submit their financial bid addressed to Under Secretary (GA), Ministry of Power,
Room No. 22, Shram Shakti Bhawan, New Delhi as per the prescribed proforma (Annexure-A)
superscripting as “Tender for disposal of old/unusable/obsolete Computer hardware and peripherals”
latest by 5 August, 2011. The financial bids of the firms received after the stipulated dated shall not be
accepted by the Ministry.

Yours faithfully,

@biikax,
(Madhukar Sood)
Under Secretary to the Govt. of India
Tele: 2375-2495

<!-- page 2 -->

Annexure-A
List of IT items to be disposed off on ‘As is Where is Basis’.
[items Total Amount (in RS.)
1. Computer- P-IV (CPU & Monitor) (Total: 55 No.) | '&
2. | HP/Samsung Printer
| (1010/2410/9130/9300/2550/4070/5748/5315, Dot Matrix)
| (Total: 69 No.)
3. UPS (625VA/I KVA) (Total : 118
4. Server- (IBM P-IV) (Total: INo.) | '(&
1
Ls. Scanner (HP 3970/HP 4070) (Total: 2 No.)
