---
doc_id: "dd83092ccd4efeda"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/9a4425fad23f35d977c5f9cf03c6c7a3.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Deputation of government officers To Central Public Enterprises-Review of policy."
date: "2025-07-14"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2b12998f597f2a18"
---

<!-- page 1 -->

CHAPTER II
PERSONNEL POLICIES
(d) Immediate Absorption/Deputation
7.
Deputation of Government officers to Central Public Enterprises—Review of Policy.

DPE/Guidelines/II(d)/7

The undersigned is directed to refer to this Department's O.M. of even number dated the 19th June, 1998 on the subject mentioned above
and to say that the sub-para (i) thereof has since been modified vide DOPT Amendment No. F.27(18) EO/99/ACC dated 19.4.2000 published
in the Gazette of India.
Sub-para (i) thereof stands modified as under:"In respect of sick and potentially sick Public Sector Undertakings, the Administrative Secretary of the Ministry/Department concerned, in
consultation with the Public Enterprises Selection Board and with the approval of the Cabinet Secretary, could take a decision at any stage in
the process of recruitment to the post of Chairman, Managing Director or Chairman-cum-Managing Director of the Public Sector Enterprises,
to take a person on deputation from any of the All India or Group "A" Central Services without insisting on the rule of immediate absorption."
2. All the administrative Ministries/Departments are requested to take note of the above modification for information and guidance.
(DPE OM No. 18(4)/98-GM-GL-26 dated 26th June, 2000)
