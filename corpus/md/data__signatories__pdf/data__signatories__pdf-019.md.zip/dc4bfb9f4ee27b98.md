---
doc_id: "dc4bfb9f4ee27b98"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/43489dd2094ca917ba2f7555fc9cb385.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Recruitment Rules for the post of Private Secretary (Central Leprosy Training Regional Institute (CLTRI) Chengalpattu)"
date: "2020-07-02"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "832a032d72623998"
---

<!-- page 1 -->

FftN6. 80t{6to
File No. A.l20t 8/ 48/2019-Lep
Govemment of India
Ministry of Health and Family Welfare
(CCD Section)

Subject:- Public Notice on Amendment of Recruitment Rules
for the post of
P vate Secretary (Group .B,) in Central Leprosy Training and Research
Institute(CLTN),Chengalpartu Reg.

In compliance of DOp&T.s O.M. No. AB.14017/61/2008_Esft.

(RR)
Recruitment Rules etc. for the post
of Private secretary (Group 'B') in central Leprosy Training
and research tnstitute
(CLTRI), Chengalpattu are annexed.
dated 13.10.2015, the draft Notification containing

2.

The stakeholders interested in making any objections/comments
or suggestions
on the draft Recruitment Rules may do so in wdting,
within a period of 30 d'ays liom
the date of publication of draft Recnritment Rules to Shri
Baidyanath pmsad, Under
Secretary, Ministry of Health & Family Welfare, Room No.
753_A Nirman Bhawan,
Maulana Azad Road, New Delhi 1 l0O I I or e-mail address
baidyanath.prasadarrnic.in

@&--

tBaidyirarh Prdsadl
Under Secretary to the Govr. ol lndia
Tel.2306l5l0
New Delhi
Dated: ( - (-v.,r

<!-- page 2 -->

[1O tsE PUBLISHED IN THE CAZETTE O!'INDIA. PAR]II. SECTION 3. SIJBsECTI0N (i)l
Covernmenl of India
Minislry of Healrh and Fanrily Welfarc
NOTIFICATION
New Delhi, the ..........2019.

C.S.R....-.-ln exercise of the powers confe[ed by the proviso
to article j09 of the
Constilulion and in supcrsession ol. lh( Centrcl f_"pro.l
fluini,U ana i.i"u..f, lnsitur".
Chengalpattu (Scrlior personal Assisrant.l Recruitrnenr
RrL.. iili:;;;p; ; respecls things
done or omited to be donc before sut.h aup",r..ai.,n,
,h. p."afl.,_"'fr","uy makes the
following rules r€Bulating the method of recruitmen, ,.
,i. por, oi'frir.t""S,"",.tu.y, in th.
Central Leprosy 'fraining and Research Il1stitute.
[amely:_

l. Shorrtirlc-and cL,mller)ccnrenl._(l) -l.hese rules llta) be called the
Ministry
of.Health and
'ii"r",u.,
Fanrilr w^eltarc. ccnrrar Lepros) Training and n"..ur"rl
rn.ii,u,". p,irui"
1c.oup

'B posl) Recruitment Rules.20l9_

(2) They shall come inro lbrce on rhe dale oftheir pubiication

in the Otlicial Gazc[e.

2. Nurrrbcr of post. classilication. lcvel in pay nratrix._ The nunrber
of said post. ils
classitication and
in thc pay matrix arrachc,l rherero. shall fr.
.p""n"a
_level
in colunrns
(2) lo {4)ofthe Schdule anncreJ
",
to rhese rules
age-timir. quatificarions. erc._ The mcrhod or.recru m(Ir.
ag(i_YiTX
l::]"1mrnl.
rmrr. quattlrcatrons
and other matters relating to the said post shall be as specified
":^f
in columins
(5)1o (l-i) olrhe said Schedule.
4. Disqualification.- No persorr.(a) uto has entered into or contracled a mariage \ ith a person ha\iDg
a spouse living;
or(b) who, having a spouse livitrg. has entt,rtd into or c,rniraci.,l u n,orrirgE
*itt,
p",.on.

,ny

shall be eligible fbr.appointmeDt to the said post:

Provided that the Celltral Govenlmcnt nray, if satisfied thal
such marlagc is
pcrmissihle xnder.thc persotrcl lnw applicable to such person
and the other parl) 1() the
rn^arnage cnd that thcrc are other
!rounds lbr so doing, excmpt any person liom thc operation
ofthis rule
5. Power to relax. - Where the Central Government is of thc opinion that
il is necessar! or
expedient solo do, it rnay, by order and ibr reasons to be rccordea in *riti,rg.
,"fr* unf uitf.,"
provisions ofthese rules with respect to any class or category olp".ron.. -'
6. Saving. - Nothing in thcse rules shall ai'fcct reservalion. relaxation of age-limit

and other
Scheiuled lribes. the
Othcr Backward Classcs. lhe Ex-ser.vicemcn or any other special catcgories
ol.persons in
accordance with thc orders issued by the Central Governnient from
ime to tinre in rhis
legard.
c-oncessions required to be provided tor the ScheduleLi castes. thc

<!-- page 3 -->

SCHEDI.]LE

Name 01 Number
posl.

iassification.

evel in pay nlatrix.

Whether

selection oi non
-seleclion post.
(s)

ol'posts-

(l)

(2)

(3)
l*(20 te) (icnerrl Ccntral
Secrelary. *subject Services. Croup 'B'
Pri!ate

to

(4)
I-cvel- 7 in the pav matrix Selection.
(Rs.:1190{I)212400).

Gazetted. Minislerial.

variatioD
ltl
thc
workload.

Age-limil for direcl Educational qualilicatior Whethcr agc and Peliod
o
recruits.
s required for direcl Educational qualification probation. ifany.
J prescribed for direcl
:ecruits will apply in the
rase

(6)

\ot applicablc.

ol promotees.

t7)

(8)

Not applicablc.

Not applicable.

(9)

\ol applicable-

Mcthod
ol In case ol recruitmenl If
a department Circumstances in
recruitment whethe by
prontolion or promolion committee which

r direct or by deputation/ absorption exists. whal is
promotion or bv grade liorn uhich Composition.
deputatioll and pror)lotion
percentagc of the or
deputation /

its

post to be fillcd by absorption b bc made.
various methods.

Union Public

Scrvice
Commission is lo
be consulted in
rnaking
recruitment.

t0)
(l t)
(12)
l3)
By
promotion Promolion:
tiroup'B' I)cpartnrental Consultation with
failing which by Stenographer Grade-l in Corlirnatiol')
Union Public
transler
or the level-6 in the pay Comnrittee (lbr
Service
deputatioll.
natrix(Rs.35400-l I 2 100) aonllrmation)consisting of Commission
with 5 years regular
is necessary for
service in the grade.
1. Dy. l)irector General any relaxation ot
0r
ileprosy). Dircctorate amendment o1
6 years combined scrvice [iencral of
Health provisions of lhe
in drc Stenographer Scrvices- Chainrran;
recruitment rules

Crade-l and Il

ir the 2. Direclor. Central
Ievel-6 in thc pay Leprosy lrainirrg and
malrix(Rs.35400-l I 2100) Research Institnte
Vembcr:
l.Deputy
Notc: uhere .luniors uho Director/Assistanl
complcterl theirl Director. Centml Leprosy

hcve

<!-- page 4 -->

u.tlitying or. c'tigihili

are

bei

rtrrsidcrcd lbr plontotior).
seniors shall
considered provi

ir

arc not shofl ol
ulsllc
qualiti in

eligibiliry scr.!ice

re than half ol'
ualifying

iSibilit] ser!ice or
ars. whichever is

d havc successfi.rll
pleted

ir probation period lbr

otion 1o the
iglrer grade along wi

it juniors rvho hav

ready conrpleted suc
tualit'ving
rvtcc,

or eligibili

flicers lrolding thc post

t Stenographcr' undcr. thc
(iovenlDlenl
Holding analogous post
regular basis in the
t cadre or
Or
Slenographer Crade-l

\

i

level-6 in tlre pay

lar

with 5

sclvice in

dcpartment :

Or

Six vears combinc
rce tn
SlenographcI Crade-l
I in the lcvel
Rs.15400-ll2l00) in

y Matrix.

l] depa(mental oll'ic

the feeder catego
are in the direcl li

l pronlotion shall
be

considcratio

raiDing and Resealc
nstitute Member.

<!-- page 5 -->

apPointment o
ion. Similarly. t
tionist shall not

ligible for considerati
appointment b)
rn.

period

o

including

of deputation i

re Post

hel

rnnediatclY Prcccdi

is appointmcnt in

organizatior
ni of the Cle
shal
\'cLnnlellt
ex
inarily not

!ea$.

Maximun agc
appointmcnt

ion shall be tt
ceeding filtY-six

on the closing datc
eipt ofapplications.
1he maxinum agc limi
transl'er shall be n

ceeding fif1y-six Y
on the closing date
eiot of aPPlications

[Flic No. A- 12018/48/2019-t.eP]

(Baid-Yanalh Plasad)

Under Secretar) to the Co!emmcnt

of Indiir
