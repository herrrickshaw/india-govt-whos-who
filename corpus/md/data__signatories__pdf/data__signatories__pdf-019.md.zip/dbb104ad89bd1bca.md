---
doc_id: "dbb104ad89bd1bca"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/e474fe693bcd2536f2984d63ca0d905d.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Result of the Interview for appointment as Notary for the State of Jharkhand (held on 25.02.2019)"
date: "2019-03-08"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6a4e36b905e965ab"
---

<!-- page 1 -->

Government of India
Ministry of Law and Justice
Department of Legal Affairs
Notary Cell
****
Notary Cell, Department of Legal Affairs had conducted Interviews for
appointment as notaries for the State of Jharkhand on 25.02.2019 at Patna. The
candidates were assessed keeping in view their competency, legal knowledge and other
relevant factors related to the selection of Notary as per requirement of the Notaries Act,
1952, the Notaries Rules, 1956 and the relevant guidelines by the Interview Board
constituted for the purpose by the Central Government. On the basis of the performance
of the candidates before the Interview Board, the Interview Board has recommended
names of the following candidates for appointment as notaries for the State of
Jharkhand.

2.

All the successful candidates, whose names appear in the below mentioned list,

will be issued Appointment Letters for appointment as Notary shortly. The candidates
are strictly advised not to visit this Office personally for submission of any document or
for issue of certificate of practice. Only after receiving appointment letter from this
Department, the concerned candidate is required to send the documents mentioned in
the appointment letter. The certificate will be issued in due course of time.
BY THE ORDER OF THE
COMPETENT AUTHORITY
NOTARY CELL
08.03.2019

<!-- page 2 -->

Interview
Sl.No.

Name

Date of
App'n

Area of Practice

1

1

Ranjit
Kumar Jha

Gen

23.04.2018

Dhanbad-CumKenduadih-CumJagata

Late Uday Kant Jha

2

2

Rajesh
Sharma

Gen

03.06.2018

Jharia-CumJorapokhar-CumSindri

Sri Kanu Hajam
Sharma

3

3

Hare
Krishna
Gupta

Obc

19.08.2018

Ranchi

Late Binod Sahu

4

4

Vijay Nath
Kunwar

Gen

31.08.2018

Bokaro

Hari Nandan
Kunwar

5

5

Archana
Kumari

Gen

31.08.2018

Chas

Manmohan Jha

6

6

Ajay Kumar
Sinha

Gen

31.08.2018

Bokaro

Jagdish Prasad

7

7

Madhusuda
n Sharma

Gen

14.09.2018

Garhwa

Murli Dhar Sharma

8

8

Awadh
Kishore
Chaubey

Gen

15.09.2018

Garhwa

Ram Mahal
Chaubey

9

9

Anjani
Sinha

Gen

16.09.2018

Dhanbad-CumKenduadih-CumJagata

Late.Janardan
Prasad

S.No.

Category

Father's Name

Address
At- Uday Bhawan Dhaiya
Near Trimurti Appertment
PoIsm,Dhanbad,Jharkhand
Lodna Nadipar Madhuban
Kujama Basti Lodna Tisra
Dhanbad Jharkhand
,Dhanbad,Jharkhand
Lucky Sweet Opposite
New Market Ratu Road
,Ranchi,Jharkhand
Camp-1, Qtr. No. D-19
Marafari Bokaro Steel
City,Bokaro,Jharkhand
Vill - Baghraibera Po Satanpur Ps - Sector
12,Bokaro,Jharkhand
Sri Rajendra Palace, Flat
No. 03 1st Floor Bhojpur
Colony, Po.Ps- Chas
,Bokaro,Jharkhand
Vill- Rejo P.O- Bana P.SMeral,Garhwa,Jharkhand
Village Mahupi Po
Garhwa Ps
Garhwa,Garhwa,Jharkhan
d
Manaitand Chhat Talab
Rajpati Saw
Colony,Dhanbad,Jharkha
nd

Enrol. No.
1885-A/2001
Dt.09.05.01

1503/2002
Dt.09.09.02
117/2001
Dt.14.06.01
4092/2005
Dt.12.05.05
1936/2003
Dt.26.02.03
469/1988
Dt.29.04.88
184/2007
Dt.28.02.07
3669/2005
Dt.07.02.05

689/2010
Dt.28.08.10

<!-- page 3 -->

10

10

Raju Prasad
Gupta

Obc

24.12.2018

Madhupur

Jagat Narayan
Shaw

11

12

Mukund
Mahato

Obc

22.01.2019

Jamtara

Late Pashupati
Mahato

12

13

Shukdeo
Rana

Obc

22.01.2019

Jamtara

Sri Dwarika Rana

13

14

Sisir Kumar
Mondal

Obc

23.01.2019

Jamtara

Late Jaydeb
Mondal

14

15

Binay
Kumar
Sinha

Gen

23.01.2019

Madhupur

Sri Chandra
Mouleshwer
Prasad

15

16

Bal Kishor
Das

Gen

23.01.2019

Madhupur

Murli Prasad Das

16

17

Debasish
Kundu

Gen

24.01.2019

Chandil

Ram Krishna
Kundu

17

18

Roopesh
Narayan
Sinha

Gen

01.02.2019

Madhupur

Surendra Narayan
Sinha

At B.D Gutgutia Road,
Hajigali Po Madhupur Ps
Madhupur,Deoghar,Jhark
hand
Vill-Simla Post-Kunjora
PsPalojori,Deoghar,Jharkha
nd
Vill-Pakdih Post-Bena PsJamtara,Jamtara,Jharkha
nd
Vill-Bewa Post-Bewa PsMihijam,Jamtara,Jharkha
nd
Kundubanglo, Chitragupt
Colony Post-Madhupur
PsMadhupur,Deoghar,Jhark
hand
Tilak Vidyalaya Road,
Kela Bagan PostMadhupur PsMadhupur,Deoghar,Jhark
hand
H No 59 Main Road
Chandil Po Chandil Ps
Chandil,Saraikela
Kharsawan,Jharkhand
At Po Sarath Ps Sarath
Sub Divn
Madhupur,Deoghar,Jhark
hand

1253/1999
Dt.09.04.99

8369/1996
Dt.01.10.96
991/1998
Dt.19.05.98
973/1999
Dt.06.04.99

3269/2004
Dt.21.06.04

5712/1995
Dt.12.12.95

3857/2005
Dt.07.02.05

1846/1994
Dt.05.10.94

<!-- page 4 -->

18

19

Manoj
Kumar
Sinha

19

20

Bachandeo
Nath Arya

Obc

02.02.2019

Koderma

Nando Prasad

20

21

Rajeev
Nayan
Prasad

Gen

04.02.2019

Dumka

Late Rudra
Narayan Prasad

21

22

Obc

08.02.2019

Bundu

Lakhi Charan
Mahto

22

23

Gen

08.02.2019

Bundu

Hira Lal Jaiswal

23

24

Gen

08.02.2019

Bundu

Ashutosh
Mukharjee

Gireshwar
Mahto
Anup Kumar
Jaiswal
Sanjay
Kumar
Mukharjee

Gen

01.02.2019

Koderma

Keshar Prasad

Ward No. 09 Vidyapuri
Near Joda Mandir Jhumri
Telaiya Ps Jhumri
Telaiya,Koderma,Jharkha
nd
Vill Kairi Post Khutta Ps
Satgawan,Koderma,Jhark
hand
Harnakundi Road, Near
Kali Mandir Purana
Dumka P.O. - Dumka,
P.S. - Dumka
Town,Dumka,Jharkhand
Thana Toli Bundu
Bundu,Ranchi,Jharkhand
Chowk Bazar Bundu
,Ranchi,Jharkhand
Navratri Toli Bundu
Bundu,Ranchi,Jharkhand

49043/1997
Dt.02.06.97

224/2007
Dt.28.02.07

86/2009
Dt.22.01.09
1698/1991
Dt.28.10.91
2468/2003
Dt.04.08.03
1700/2002
Dt.03.12.02
