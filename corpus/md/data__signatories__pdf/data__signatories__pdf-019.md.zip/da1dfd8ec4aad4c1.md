---
doc_id: "da1dfd8ec4aad4c1"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/09/aed109dbfa297c3ddc26e2c711da6b87.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "National Vaccine Policy Book(April 2011)"
date: "2011-04-01"
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "48440407a3ac7f72"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

Foreword
The National Vaccine Policy document has been developed
following the recommendation of National Technical Advisory Group
on Immunization (NTAGI). This policy document addresses broad
issues of strengthening the institutional framework, processes,
evidence base and framework required for decision making for
strengthening Universal Immunization Programme in India and to
streamline the decision making process on new and underutilized
vaccine Introduction. The document also aims to address the issues
of vaccine-security, management, regulatory guidelines, vaccine
research & development and product development.
I would like to thank Prof. N.K. Ganguly, Ex-DG, ICMR for
drafting this Policy document which will lay down the basic guiding
principles in improving the Immunization programme in the country. I
also take this opportunity of thanking Secretary (DHR) & Secretary
(DBT) for their critical input in drafting the National Vaccine Policy.

(K. Chandramouli)

National Rural Health Mission

<!-- page 4 -->

TABLE OF CONTENTS
Executive Summary
1. Preamble
1.1. Background
1.2. Purpose of this document
1.3. Process adopted in the development of this document

1
3
3
3
4

2. Policy context and framework
2.1. Current UIP vaccines
2.2. New and under-utilized vaccines
2.3. Potentially new vaccines
2.4. Vaccine security and other issues

4
4
4
5
5

3. Situation analysis
3.1. Burden of VPDs and their surveillance
3.2. Barriers to strengthen Immunization Programme

5
5
6

4. Vaccine Research and Development
4.1. Institutional capacity and framework
4.2. Vaccine quality regulatory system
4.3. Vaccine production and supply

7
7
11
15

5. Introduction of new vaccines in UIP
5.1. Vaccine selection
5.2. Vaccine formulations and immunization schedules
5.3. National Technical Advisory Group on Immunization (NTAGI)
5.4. Decision making process

16
16
17
18
19

6. Operational efficiency of UIP
6.1. Improving vaccine coverage
6.2. AEFI surveillance system
6.3. VPD surveillance
6.4. Vaccine forecasting, procurement and management
6.5. Human resource
6.6. Advocacy and communication
6.7. Ethics and equity

20
20
20
21
23
26
27
28

7. Implementation and monitoring

29

8. Key references

30

9. List of Contributors

33

(i)

<!-- page 5 -->

ABBREVIATIONS
ACIP

Advisory Committee on Immunization Practices

AD

Auto Disable syringes

AEFI

Adverse Event Following Immunization

ANM

Auxiliary nurse-midwife

CDC

Center for Disease Control and Prevention

CDSCO

Central Drugs and Standards Control Organization

CLAA

Central License Approving Authority

DPCO

Drug Price Control Order

DPT

Diphtheria, Pertussis and Tetanus

ECDC

European Center for Disease Prevention and Control

EPI

Expanded Program for Immunization

FSP

Financial Sustainability Plan

GAVI

Global Alliance for Vaccines and Immunization

GFR

General Financial Rules

GIS

Geographical Information System

GNI

Gross National Income

GOI

Government of India

GRADE

The Grades of Recommendation Assessment, Development
and Evaluation

HMIS

Health Management Information System

ICB

International Competitive Bidding

ID

Infectious Disease

JE

Japanese Encephalitis

MoHFW

Ministry of Health and Family Welfare

(iii)

<!-- page 6 -->

NABL

National Accreditation Board for Testing and Calibration of
Laboratories

NDMA

National Disaster Management Authority

NIB

National Institute of Biologicals

NIHFW

National Institute of Health and Family Welfare

NIP

National Immunization Program

NRA

National Regulatory Authority

NRHM

National Rural Health Mission

NTAGI

National Technical Advisory Group on Immunization

OPV

Oral Polio Vaccine

PAHO

Pan American Health Organization

ProMIS

Procurement Management Information System

PSU

Public Sector Unit

RCH-2

Reproductive and Child Health Phase II

SAGE

Strategic Advisory Group of Experts

SAIF

Sophisticated and Analytical Instrument Facilities

UIP

Universal Immunization Program

UNICEF

United Nations Children’s Fund

VPD

Vaccine Preventable Disease

WHO

World Health Organization

(iv)

EXECUTIVE SUMMARY
Vaccines are one of the most successful health interventions that bring
about significant reductions in infectious diseases and adverse health
consequences and improve quality of life in the population. Over the years
vaccines have provided highly cost effective improvements to human health
by reducing avoidable human suffering, costs of care and treatment,
economic consequences of work i.e. lower productivity and loss of work.
More and more diseases are becoming vaccine preventable; including
those for prominent killers like pneumonia and diarrhoea, and the
technology used is evolving rapidly. Since vaccines are administered to
healthy people, especially children, it is pivotal to ascertain they are safe
and cost effective. Consequently vaccine development has become time
and resource intensive, with more stringent regulatory pathways to ensure
safety and efficacy of vaccines. In a situation where there is abundance of
new and expensive vaccines on one hand and limitations of resources on
the other, it becomes imperative that use of vaccines through induction in
the Universal Immunization Program (UIP) as well as in the free market is
done through a framework of decision-making that confers positive health
and economic benefits to the society.
The UIP in India targets 2.7 Crores infants and 3.0 Crores pregnant women
every year and is one of the largest in the world. The country also has a
strong vaccine manufacturing capacity that has recently taken on the
challenge of producing more complex vaccines. Most of the new vaccines
are used by one segment of the population, which can afford them, while the
most vulnerable segment of the population, which is serviced through the
UIP misses out on this opportunity. There is a scope for improvement in the
health system and the vaccine enterprise in the country to enable its optimal
functioning and bring about coordination between the various interdependent steps and involved stakeholders. This policy document deals
with issues critical to strengthening of the vaccine enterprise to ensure longterm supply of affordable vaccines to the people who need it the most. The
document is divided under the following sections:
•

Policy context and framework : This section provides information
on why this document is required, what is the scope of the document
and overall framework.

•

Burden of Vaccine Preventable Diseases (VPDs) in India: This
section discusses how introduction of vaccines have impacted the
burden of VPDs in India. It also outlines other diseases which can be

01

<!-- page 7 -->

prevented by currently available and possibly available vaccines in
future in India.
•

Vaccine research and development: This discusses the
challenges in vaccines research, mapping of capacity for vaccine
research in the country, research networks and creation of biorepositories retrospective use.

•

Introduction of new vaccines: This section discusses processes,
matrix and evidence base in decision making before the introduction
of new vaccines in India.

•

Improving operational efficiency: This section deals with Adverse
Events Following Immunization (AEFI) and VPD surveillance
systems, cold chain & effective vaccine management, human
resources in immunization, vaccine coverage, advocacy and
communication, and equity and ethics etc.

•

Program implementation and monitoring: This section outlines
how this document should be used and how the progress in the
implementation of this policy can be monitored.

1.

PREAMBLE

1.1.

Background
The Expanded Program for Immunization (EPI) in India was
launched in 1978. The ambit of EPI was increased with the inclusion
of measles vaccine (and discontinuation of typhoid vaccine) in 1985
and it was renamed as the Universal Immunization Program (UIP).
The aim of UIP was to cover all districts in the country by 1990, in a
phased manner and target all infants with the primary immunization
and all pregnant women with TT immunization. For almost 2
decades, UIP did not add any additional vaccine. However, since
2006, vaccines namely Hepatitis B, second dose of measles and
Japanese Encephalitis (JE) vaccine have been introduced. During
the same period, a number of other safe and efficacious vaccines
have become available for major killers like pneumonia and diarrhea,
which are being used in the immunization programs of many
developing and developed countries.
The discussion on the formulation of National Vaccine Policy for India
started in a meeting of National Technical Advisory Group of
Immunization (NTAGI) in August 2010. Subsequently, in Sept 2010,
Ministry of Health and Family Welfare (MoHFW) identified Dr. N.K
Ganguly, Ex- DG, ICMR to draft National Vaccine Policy.

1.2.

Purpose of this document
A National Vaccine Policy with specific relevance to local vaccine
needs is required to guide decision-making and develop a long-term
plan to strengthen the whole vaccine program and not just a
component. This National Vaccine Policy does not intend to cover all
aspects of immunization service delivery or is not a detailed guideline
on specific vaccine. This Policy document intends to provide broader
policy guidelines and framework to guide the creation of evidence
base to justify need for Research and Development (R&D),
production, procurement, quality assessment of vaccines for UIP in
India. This document also addresses the broad issues of
strengthening the institutional framework, processes, evidence base
and framework required for decision making for new vaccine
introduction, addresses vaccine-security & program management,
regulatory issues, and product development.

02

03

<!-- page 8 -->

1.3.

Process adopted in the development of this document
The working group constituted by Dr. N.K. Ganguly in Sept. 2010
started to develop an initial draft of this policy document. The working
group had a series of meetings, reviewed a number of policy,
program and operational documents. The first draft was completed
and shared with NTAGI members for comments in February 2011.
The comments from NTAGI members and subsequent revision were
done in March 2011.

2.

challenges. Furthermore, there is need for the institutionalizing and
strengthening of decision making process and enhancing
confidence of the people in the process besides preparing in-built
country mechanism for sustainable production of newer vaccines
within country.

2.3.

The diseases which are prevalent in developing countries are often
different than the ones in developed countries. However, till last
decade majority of the vaccine research was being done in
developed countries and the focus was on the vaccines against
diseases, which are prevalent in developed country setting. India has
a leading vaccine industry; however, there is need for investing more
on the research for the vaccines for the priority diseases in the
country. Such research can be promoted only when there is
conducive environment, funding and subsequent chances of vaccine
being introduced in the National program.

POLICY CONTEXT AND FRAMEWORK
This document covers all categories of vaccine, vaccines being used
in UIP, vaccines available but not part of UIP (both new and
underutilized), and those vaccines, which are likely to become
available in the future. The document also touches the aspects
related to vaccine security in the country and vaccination program in
broader framework of National Health Policy of India.

2.1.

Current UIP vaccines

2.4.

UIP in India and its core antigens have made a significant impact on
the burden of diseases in the country and directly contributed to
reducing child mortality. However, the regular production and supply
of these vaccines, in a setting where majority of manufacturers are
increasingly paying attention to the newer vaccines is a big
challenge. There is limited production capacity of these vaccines in
public sector units and the involvement of private sector
manufacturers is required to ensure that supply of UIP vaccine is not
threatened.

2.2.

New and under-utilized vaccines
There are a number of new vaccines, which have become part of
National Immunization Programs (NIPs) in many developing and
developed countries. Many a times, the decision to introduce these
vaccines is delayed due to limited production capacity, which
indirectly affects the price of these vaccines too. Sometimes
vaccines are not used as these are not indigenously produced or not
available in sufficient quantity. On the other hands, the
manufacturers don’t produce vaccine because these are not used in
the program. The authorities should use innovative financing,
funding and assured supply mechanisms to overcome these

04

Potentially new vaccines

Vaccine security and other issues
India should be able to ensure quality, safety, and efficacy of all
vaccines that are either indigenously produced or imported for the
use in the country. Achieving this requires a robust regulatory
mechanism to be in place. Furthermore, the implementation of
immunization program should be put in the perspective of broader
goals of National Health Policy. The sufficient political will & support,
and the necessary sufficient and sustainable financing mechanisms
should also be ensured for this purpose.

3.

SITUATION ANALYSIS

3.1.

Burden of VPDs and their surveillance
Since the beginning of EPI in India, there has been a general decline
in the reported number of cases of the main VPDs (diphtheria,
tetanus, pertussis and measles).
The overarching goal of vaccine use is to reduce morbidity and
mortality due to vaccine preventable diseases (VPD). While
surveillance information for specific VPD is limited, trends in Infant
Mortality Rate (IMR) to reflect the impact of vaccination suggest that
IMR in India has fallen steadily to reach 50 deaths per 1000 livebirths (SRS 2009).

05

<!-- page 9 -->

For almost 2 decades since the beginning of UIP, India had same 6
antigens in the UIP and recently Hepatitis B and measles second
dose has been incorporated in UIP. There are a number of diseases,
for which vaccines exists for long (Typhoid, Rubella), which may
further be considered for the introduction in NIP in India. Similarly, a
number of new vaccines have become available in last few years.
Haemophilus influenzae type b (Hib) vaccines, Pneumococcal
conjugate vaccines, Rotavirus vaccines, HPV vaccines, which have
estimated high burden and possible role in reducing child mortality in
India.
One of the major hurdle in the decision making process for the
introduction of new vaccine has been the lack of indigenous
surveillance data to assess the disease burden. The country need to
build upon the available investigator initiated research, modeling
data, and systematic reviews to assess the disease burden.
Nonetheless, the efforts should be made to strengthen VPD
surveillance system. The institutional capacity building should be
done for conducting demonstration projects and impact studies in
the country.

3.2.

Barriers to strengthen Immunization Programme
There are well recognized challenges in the implementation of
immunization program in the country. These challenges are:
• Weak VPD surveillance system;
• Lack of data on disease burden in India and resulting perception
that the disease is not important public health problem;
• Lack of diagnostic tools for certain vaccine preventable diseases
that could be used without sophisticated instruments or
specialized training;
• Lack of baseline surveillance data also is a bottleneck in
monitoring the impact of vaccination;
• Limited economic evaluations to show cost effectiveness of
vaccines over other interventions to support decision-making;
• Lack of a financial sustainability plan for the introduction of new
vaccines in the UIP also affects decision making in this area.
• Shortage of trained manpower to manage the UIP at the Center as
well as State levels, for innovations in vaccines, for disease

06

surveillance and for procurement and effective vaccine
management.
These challenges need to be addressed to improve the
Immunization Programme performance in India. This policy
document also aims to provide policy measures to address the
above mentioned barriers.

4.

VACCINE RESEARCH AND DEVELOPMENT
The research and development (R&D) and manufacturing of
vaccines for locally prevalent diseases in India should be given a
priority. These include vaccines for major killers like pneumonia and
diarrhea, diseases with potential to cause outbreaks like JE,
Dengue, Cholera, Typhoid and diseases like Leishmaniasis etc. The
processes, funding, networks, repositories etc. that would make this
possible are detailed in the following sections.

4.1.

Institutional capacity and framework
Vaccine development is a long, multi stage process where critical
actions must be decided and taken in synergy and not sequentially.
The R&D of vaccines is undertaken in the academia as well as by the
vaccine industry. There are a number of challenges faced by the
developing countries in vaccine research.
India has a number of institutions, where vaccine related projects are
implemented i.e. Indian Council of Medical Research (ICMR),
Department of Science and Technology (DST), Council for Scientific
and Industrial Research (CSIR), small and medium vaccine
industries, medical and engineering schools, in addition to the
Department of Biotechnology (DBT) supported autonomous
institutions.
India’s strong and growing vaccine manufacturing sector and a
rapidly rising global demand in vaccine R&D is also a tremendous
economic opportunity. A number of linkages need to be explored
between academia, industry and international institutions such as
NIH/NIAID, Gates Foundation, GAVI Alliance, PATH, WHO and the
International Centre for Genetic Engineering and Biotechnology
(ICGEB). Areas that require attention include the following:
• A fund for grand challenges in vaccine R&D needs to be created.
This fund to be utilized for R&D of country disease burden specific
vaccines,

07

<!-- page 10 -->

• The vaccine grand challenge mechanism will ensure that all
varied type of infrastructures and services, approved by Central
Drugs Standard Control Organization (CDSCO) are available,
accessible, and affordable to the investigators involved in vaccine
research and development.
• Flexible governance and granting systems should be in place to
ensure that additional science funding, cooperate granting
system (where funding agency, project managers and
investigators work as a team for collective decision making) and
subcontracting mechanisms are in place.
• Enabling processes for rapid decision-making to allow building
alliances and partnerships, both national and global, and for
support to agencies for diffusion of the technologies into the social
systems, should be in place.
• Workable mechanisms need to be developed to sustain vaccine
development teams, for a decade or more, for a continuity and
focus, and new skills incorporated to fulfill evolving requirements.
4.1.1. Mapping of research capacity and network
The mapping of vaccine R&D activities in the country is important to
assess the strengths and gaps, and to avoid duplication of efforts.
This exercise also helps identify candidates that have potential and
should be taken forward and quickly abort/correct those activities
that have lacunae. Mapping exercises are very important in case of
vaccines, where the pipeline of candidates has to be large and the
development resource-intensive.

08

monetary and human, towards fight against a specific disease or a
group of diseases (for example a network of neglected tropical
diseases).
• These networks could then collaborate within themselves, share
intellectual property, expertise, biological material and also
collaborate with international groups working on similar projects.
• Creation of Sophisticated and Analytical Instrument Facilities
(SAIF) within a region/state will encourage sharing of expensive
instruments and enable participation of investigators from various
universities and institutions. This will also enable periodic
upgradation of the facilities.
4.1.2. Creation of Bio-repositories
Banking of biological samples both sera and organisms that are
collected during diseases surveillance, epidemics or clinical trials
can be a tremendous source of materials for retrospective use in
identifying biomarkers, genetic make-up or studying changes in
pathogenic organisms in India in case of re-emergence of a disease.
Administration, management, custodianship, and security of biobanks can be major issues. Without proper guidelines and policies
about benefit-sharing, data-sharing, privacy, access (both for
depositing of samples and retrieval), policies to handle bio-piracy
etc., a well intended effort can not function optimally.
• The existing guidelines that govern the functioning of a National
Biorepository in India and the best practices followed in other
countries should be examined and an India specific Standard
Operating Procedure and Guidelines needs to be drafted with
appropriate linkages with different programs,

The participation of national government institutions, private
institutions and industries that have resources and manpower in the
area of health research should be given a platform to share ideas and
intellectual property and encouraged to collaborate. These groups
when identified to have common goals should be encouraged to
write joint grants and thus utilize the infrastructure and manpower to
the optimum capacity. The results of mapping exercise should be
made available to researchers in the country and to other funding
agencies investing in similar activities.

• The repositories should be accredited and linked with
International Repository System and to other discovery research
units in the country,

The mapping exercise could result in disease or intervention (drug/
vaccine/ delivery systems/adjuvants) specific networks that could
synergize the efforts and enable concentration of resources, both

• There is an urgent need to establish a repository for pathogenic
organisms. All the data sets generated should be strongly linked
with other national programs.

• The bio-repositories need to be equipped with fingerprinting,
sequencing for analysis of the genetic makeup of the organism,
and freeze-drying facility for long-term storage,

09

<!-- page 11 -->

4.1.3. Public Private Partnerships

Korea, National Institute of Cholera and other Enteric Diseases
(NICED), Kolkata, and Shantha Biotechnics Ltd, Hyderabad.

The concept of public private partnership (PPP) has helped in
bridging the gaps between academia, industry, and funding agencies
effectively. It unifies the commitment of public sector to develop
products to improve health of the population with the private sectors
discipline and culture in business development and marketing. The
non-profit enterprise has effectively led to development of several
products in the past decade. The PPPs have also evolved innovative
methods for intellectual property and portfolio management, and has
unique structures and methods for governance.

The vaccine industry suffers from the lack of support for risky
vaccines. The continuous inputs needed to and from the repositories,
largely set up in public sector institutes and platforms available with
Indian Institutes of Technology (IITs), research institutes and
universities, is largely missing. There should be robust mechanisms
in place to integrate these partnerships in PPP mode.
In order to fund the long and multistage pathway of vaccine
development, where the various components have to work in
synergy rather than sequentially, novel funding mechanisms for
various stages need to be in place with the flexibility required to fund
various partners in an enterprise model. Some of these are already
available like the BIPP and Small Business Innovation Research
Initiative (SBIRI) mechanisms of DBT, and New Millennium Indian
Technology Leadership Initiative (NMITLI) program of CSIR are
available for industrial development of lead candidates.

There are a few approaches to strengthen PPP mechanisms in
vaccine research:
• Flexible governing and funding mechanisms should be evolved to
support product development in the PPP mode,
• Flexibility of contracting experts, both from national and global
pool for a defined period should be built-in in these partnerships.
During setting up of the policy framework, the industry may be
provided a channel to voice their opinion and experiences and their
concerns could be utilized in framing the policy. If industry has
genuine concern about tardy regulatory mechanisms or a decision
has been made to their detriment, an independent and speedy
redressal mechanism should be in place. A need based realistic
procurement policy should help.
There are several examples where product development have taken
the public private partnership route and have resulted in shortening of
the time frame for vaccine development, such as the Meningococcal
Meningitis Vaccine Initiative (MMVI), where the product was
produced in India with multiple partners, met international standards
in quality, was exported to and used in Africa. The model has been
instrumental in indigenously 116 E rotavirus vaccine being
developed with effective collaboration between Indian & US
academia, and Indian vaccine industry in partnership with PATH.
Another example is the development of influenza H1N1 vaccine with
support of 3 Indian vaccine manufacturers under the BIPP
(Biotechnology Industry Partnership). An indigenous new generation
Oral Cholera Vaccine has also been brought to the market under
such model with the partners being International Vaccine Institute,

10

More flexible granting mechanisms, unlike the milestone based,
short-term, project-specific funding currently followed, are needed
for vaccine R&D. The innovative funding mechanisms lasting for 5-8
yrs should be instituted for young investigators interested in vaccine
development including flexible mechanisms for training in related
areas like Good Laboratory/Clinical/Manufacturing practices ethics
(Including IPR) and hands on skill development in certain technology
platforms.
4.1.4. Product development for public health emergency
There is a need to develop mechanisms, where speedy regulatory
clearances are possible including flexibilities in the import of
biological materials needed for such development. The mechanisms
need to be evolved where the risk of the manufacturers is cushioned
by appropriate assistance from the Government. It should be
mandatory for the Government to support such developments with
Advance Market Commitments and honour the commitments.

4.2.

Vaccine quality regulatory system

4.2.1. Existing vaccine regulatory system
The Central Drugs and Standards Control Organization (CDSCO) is
the National Regulatory Authority (NRA) in India. CDSCO is headed

11

<!-- page 12 -->

by the Drugs Controller General (India) [DCG(I)]. It approves
vaccines that are introduced in the country, grant permission to
conduct clinical trials, registers and controls the quality of imported
vaccines, as well as lays down standards for updating India
Pharmacopoeia. It also approves licenses as the Central License
Approving Authority (CLAA) for the manufacture of vaccines,
coordinates the activities of the States and advises them on matters
relating to uniform administration of the Act and Rules. The Central
Drugs Laboratory (CDL), Kasauli performs lot release for all imported
vaccines as well as locally produced vaccines.
4.2.2. Scope for Improvements in the quality assessments
Indian vaccine industry has occupied an important niche in the
manufacturing of EPI vaccines in the last decade. However, with the
exception of measles vaccine, which is from a domestic WHO prequalified producer, all other NIP vaccines supplied are from WHO
non pre-qualified manufacturers. This is in spite of the fact that India
is one of the major suppliers to UN agencies of pre-qualified
vaccines.
The Indian vaccine industry has taken up new challenges of
manufacturing more complex vaccines like the meningococcal
conjugate vaccine, pneumococcal conjugate vaccine, and other
combination vaccines. Recognizing this emerging strength of Indian
manufacturers, the NRA should be appropriately strengthened with
trained manpower, and an accredited laboratory which can serve as
the National Control Laboratory. There are other areas, which need
to be strengthened:
• The current regulatory guidelines followed by the NRA for
vaccines are dated and essentially designed for the drugs. There
is an urgent need to develop vaccine specific guidelines.
• Laboratory testing for vaccine consistency is a critical component
of vaccine quality. A system of accreditation of laboratories
through a set of internationally accepted parameters should be in
place. The institutions like the National Institute of Biologicals
(NIB) need to be adequately strengthened to take on the
laboratory testing of new generation of vaccines.
• India should develop prequalification standards that are in
alignment with WHO-UNICEF standards. Single window system

12

should be in place to prevent any unnecessary delays in
regulatory clearances.
• Most of the EPI vaccines procured for use in India comes from
manufacturers that are not WHO pre-qualified and have different
risk taking ability. Adhering to the WHO-UNICEF prequalification
standards will enable more domestic manufacturers to cater to
international markets. Coupled with a more efficient procurement
system that factors the timelines of the vaccine manufacturing
process, the risk of the vaccine manufacturers will be significantly
reduced.
• There is a need to set up systems for fast-track clearance of
vaccines needed for emergencies. One of the ways to achieve this
is that Indian NRA recognizes the NRAs of other countries as is
done by countries procuring vaccines through UNICEF. In situations
where time is essence, having this types of provisions will go in a
long way to save several lives during public health emergencies.
4.2.3. Clinical trials
Clinical trials are very crucial for decisions making about vaccine
development. These should be planned and executed according to
the Good Clinical Practices (GCP) guidelines and maintain highest
standards possible. GCP training courses should be mandatory for
all PIs leading clinical trials.
• There is a need to create a pool of trained investigators to design
and oversee clinical trials for vaccines. The Clinical Development
and Services Agency, within the Department of Biotechnology and
its partners, which have this mandate, should be supported
appropriately.
• Capacity building for data management and biostatistics to
analyze and interpret the results of a clinical trial is essential. A
training program for the support staff participating in each trial may
be different and therefore be budgeted in the trial.
• There should also be provision to engage trained auditors from
time to time for independent assessment of vaccine trials
conducted in the country.
4.2.4. Intellectual Property Rights (IPR) and technology transfer
The Indian Patent Act was amended in 2005 and the product patents
have been allowed in the country, which has significant impact on the

13

<!-- page 13 -->

cost of health care products in India. Improving the institutional
capacity for intellectual property (IP) management and technology
transfer will help investigators involved in the research to understand
the patent claims and will enable them to make sound judgments,
during the product development. There are a few steps needed in
this arena:
• Strengthening Indian patent office, reducing the time to examine
and grant a patent, and creation of more comprehensive IP
databases in India
• Encouraging technology transfer from multinational companies
to develop products and gaining access to technologies and
know-how
• Indian patent law may have provisions to permit compulsory
licensing in special situations like the H1N1 pandemic or in
situations, where a technology/intermediate is needed for vaccine
development.
• The country should develop/use expertise to study the flexibilities
enshrined in the Trade Related Aspects of Intellectual Property
rights (TRIPS) agreement to reduce the negative impact of the
patents. The arrangements like ‘Bolar provision’ which permits the
manufacturers of generic pharmaceuticals to begin product
development, while the patent is still in force. This could be
particularly helpful in reducing the lead-time to obtain regulatory
clearances during vaccine development.
• Collective management of IPR and open access agreements
should be resorted to improve innovation and access. Innovations
in ways to deal with IPR of new vaccines need to emerge through
innovative funding of R&D.
• It is suggested that a body is created to acquire and hold IPR for
technologies beneficial for use in public health. This body could
then license the technology to emerging manufacturers on
acceptable terms for development of vaccines and related
products.
Mechanisms needs to be set up for a robust technology transfer
units, positioned to transfer technologies to companies for public
good. Setting up of special infrastructure for new vaccines should be
incentivised through tax relief for imports. In case of requirement of a

14

new vaccine, the mechanisms like SBIRI and NMITLI should provide
part support as loan on soft interest rate and part as grant just as was
done in case of development of H1N1 vaccines and similar funding
mechanism should be available for other new vaccine development
as well.

4.3.

Vaccine production and supply
India is a major producer and exporter of vaccines: approximately
43% of global vaccine supply is provided by Indian manufacturers,
primarily from the private sector. Till recently, both public and private
sector vaccine producers were supplying vaccines to UIP.
• An effective, functional and inclusive platform needs to be created
so that all the stakeholders have the same understanding of the
issues and work towards a common goal to ensure sustainable
and uninterrupted production and supply of good quality, safe and
effective vaccines at the most competitive price.
• Local manufacturers must be encouraged to comply with WHO
GMP standards. They may be assured with accurate demand
estimates, followed by purchases of all ordered vaccines.
• Public sector units should be updated with long-term goals in
mind. The public sector units should be lead by a person with
strong scientific background and should have a forward-looking
corporate like governing system.
The Indian domestic market for UIP alone is 100 million doses, and
therefore has considerable bearing on global vaccine pricing. The
R&D costs of UIP vaccines is minimal, however, the non-UIP
vaccines involve technology licensing, R&D, infrastructure, and
operational costs. In addition, the stringent regulatory requirements,
for the licensing of newer vaccines, add up to the cost. The pricing
policy on vaccines should be based on a realistic assessment to
retain the interest of the vaccine industry in research on the new
vaccines. The Public sector industry should be revived to provide
vaccines that have very low profit margins and to make these units
competitive, they should be able to hire global consultants through
appropriate mechanisms and be allowed to hire key personnel
through market competitive rates. A professional and technical
management system should be in place to help identify the
infrastructure gaps.

15

<!-- page 14 -->

4.3.1. Vaccine financing and sustainability
The ideal situation for any national government is to assume
ownership of NIP to the fullest extent possible and accordingly create
fiscal and legislative space. Meeting benchmarks and enacting
protective legislation are the essential conditions for the financial
sustainability.

monitor these studies periodically. It could also review status of
vaccine development and manufacturing activities in the country and
arrange technical assistance in various aspects of vaccine
development.
5.1.2. Criteria for selection of vaccines for introduction
The selection of vaccine for possible introduction in NIP is a complex
process. There are a few laid down guidelines. The below given
criteria may be considered for an informed decision making about the
introduction of new vaccine in UIP.

• A financial sustainability plan (FSP) for immunization should be
created. The FSP should include the breakdown of vaccine and
non-vaccine expenditures (system costs) and plan for scale up in
the coming years. It should also factor in the changes to be
brought about by the introduction of new vaccines, expansion in
cold chain capacities and management.

• Disease burden (incidence/prevalence, absolute number of
morbidity/mortality, epidemic/pandemic potential);
• Safety and efficacy of the vaccine under consideration;

• The non-vaccine expenditure should also include expansion and
sustenance of trained human resource. This should clearly
describe the expenditures to be met by the central and state
government.

• Affordability and financial sustainability of the vaccination
program, even if the initial introduction is supported by the
external funding agency;
• Program capacity to introduce a new antigen, including cold chain
capacity;

• Possibility of creation of expanded Vaccine fund through
innovative financing mechanism should be considered. An interagency task force should be created and should assess the legal
and administrative barriers to make such a fund operational. This
fund could also be used for introduction of new vaccines and for
development of vaccine for emergency.

5.

INTRODUCTION OF NEW VACCINES IN UIP

5.1.

Vaccine selection

• Availability of a domestic or external vaccine production capacity;
• The cost effectiveness of the vaccination program and also of the
alternatives other than vaccination.
The Grades of Recommendation Assessment, Development and
Evaluation (GRADE) system is one such system followed, which
allows a systematic and transparent grading of evidence with
deliberate separation of quality of evidence and strength of
recommendation.

5.1.1. Identifying vaccines of local relevance
The decision to include a new vaccine should be guided by the
disease burden in the country. This information, ideally, be derived
through strong surveillance system within country. Furthermore, the
data from the investigator initiated researches, from modeling studies
and the data from countries with either geographical proximity or
similar demography may also be used for these decision makings.
A mid term (5-7 year) strategy on the required evidence with regard to
the burden of diseases should also be in place, with scope for
periodic monitoring and review. A multi-agency policy unit should be
created to conduct meetings of various stakeholders to evaluate and

16

5.2.

Vaccine formulations and immunization schedules
There are a number of new vaccines, which may be considered for
the possible introduction in UIP in India. The modifications in the
existing immunization schedule may be required for accommodating
these new vaccines, for a broader utilization of some vaccines or for
changing the number of doses based on experience elsewhere.
• Technical consultations should be carried out to examine the
possibility of any alteration in vaccine formulation (e.g. vaccines
with or without preservative, with or without adjuvant, liquid or
lyophilized etc.) that could enable the use of a vaccine in the

17

<!-- page 15 -->

existing schedule. Such a consultative process should include
scientists, program managers, cold chain managers and
representatives of the manufacturers.

Infectious Disease (ID), Clinicians other than ID, Immunologists,
Medical Microbiologists, Cold chain experts/ logisticians, Statistic
modelers, Social scientists, and Drug regulators. It is also
important to have experts in ethics, health economics, and
nursing/pharmacy from the field, immunization program
managers, and representatives of the civil society etc. Other
members should be ex-officio members from the Ministry of
Health and Family Welfare. There may be also be representation
from the State Ministry of Health.

• The combinations vaccines have shown to improve coverage,
and reduce non-program costs, especially in countries with
similar issues. These factors should be considered before making
a decision on the use of combination vaccines in UIP.

5.3.

National Technical Advisory Group on Immunization (NTAGI)
NTAGI is a group of experts from vaccination and immunization
related fields in India. NTAGI advises the national government
regarding the technical issues related to the vaccination and
immunization. This group meets on a regular basis and considers
various technical and policy decision related to immunization
program in India.
There is a general perception in India that the time lag from the
availability of a vaccine to its use in the NIP should be reduced. There
are a few steps which should be followed to ensure the effective and
efficient functioning of NTAGI:
• The guidelines of international bodies like World Health
Organization Strategic Advisory Group of Experts (WHO-SAGE)
should be assessed in context of the capacity of India’s National
Immunization program to absorb a particular vaccine.
• The country specific ‘situational analysis’ for each vaccine should
be done by this expert group.
• The inputs from translational research in the country to support
such introduction should be improved. Capacity and infrastructure
in this field should be created/revamped. The interdisciplinary
collaborations within the nation and at global level need to be
initiated and established. The members of NTAGI should have
sufficient interaction with each other and other global advisory
bodies.
• The NTAGI should be supported by subgroups that look into
specific areas such as vaccine security, vaccine ethics, equity,
financial sustainability, and improvements in health system.
• The NTAGI should have wider representation to include experts
from the areas of Public health, Paediatrics, Epidemiology,

18

• It must be mandatory for the members to declare conflicts of
interest to ensure an unbiased decision making process. The
members should be allowed a term of a minimum of 2 years term
(which could be extended).

5.4.

Decision making process
The potential inclusion of any new vaccine in UIP should initially be
discussed by NTAGI. The NTAGI may consider various factors
before giving technical recommendation for introducing any new
vaccine in the program. The technical decision of NTAGI should be
considered by immunization division for implementation. The
program division may further consider the operational aspects of the
decision implementation.
Moreover, the vaccine specific work plans need to be prepared,
which includes review of existing evidence on burden and efficacy,
identify data gaps and outline plan of work to collect any additional
data needed for decision making. These work plans can be strictly
adhered to streamline and support the decision making efforts in the
country. The efforts should be made to address the identified gaps in
these areas and the needful activities may be done in this direction in
collaboration with various stakeholders.
A proportion of country’s population accesses vaccines from the
private market, where new vaccine entry follows the marketing
strategy of the manufacturers based on their experience from
introduction in developed countries. This segment of the population
should be studied as it can provide valuable post marketing
surveillance (Phase -IV analysis) data. The profile of the people
accessing these vaccines as well as the mapping of service
providers could be useful for future planning and decision making.

19

<!-- page 16 -->

6.

OPERATIONAL EFFICIENCY OF UIP

6.1.

Improving vaccine coverage

• The capacity building in AEFI surveillance and case investigation
should be done in the entire country. The national and state level
should have sufficient capacity to conduct causality assessment
for AEFI. A mid term plan for capacity building should be prepared.

The coverage of UIP vaccines in this country is >70% only in 11
states, 50-70% in 13 and below 50 % in the rest of the 8 states. The
last group also happens to include the most populous states, which
brings down the national average below 50%. This is an area of
concern and issues need to be addressed to improve UIP program
performance.

• There is need for establishing a strong mechanism for AEFI
surveillance between immunization division and DCGI. The Post
Marketing Surveillance (PMS) network being set in Maharashtra
state should be used for strengthening AEFI surveillance in the
entire country. Post marketing surveillance (PMS) of AEFI is also
important to generate new hypotheses about vaccine reactions
that are specific to the population. The experiences from Global
PMS network in Maharashtra state could help in developing
model practices at the state level.

• An assessment of existing bottlenecks that impede success in
UIP should be carried out by an independent agency.
• An in-depth assessment of the immunization systems in the
states should be carried out to understand the better outcomes in
a few versus the abysmal performance in others. Similarly, the
neighboring country structures (e.g., Sri Lanka and Bangladesh
etc.) should also be studied to learn from them.

• Effective collaboration and effective communication between
National Control Laboratory, the National Immunization Program
(NIP), and DCGI office should be established and quick
identification and resolution of a vaccine batch related problem.
Clarity of responsibilities and good liaison system between NRA
and NIP is required and revised TOR of the immunization staff at
all levels to delegate their role in the AEFI reporting has to be
prepared.

• A systematic registration and identification of pregnancies and
births along with computerization of data for data-management
will be useful to facilitate reaching the every new cohort of
children.
• Linking of the Geographical Information System (GIS) with UIP
network can also be used to track delivery of vaccines.

• The Central Drug Laboratory at Kasauli, which is currently used
for testing for vaccine samples in AEFI, should be upgraded and
efforts should be made to get NABL certification.

• The strengths and gains from National Rural Health Mission
(NHRM) in improving coverage of vaccination in certain states
should be consolidated. The ANMs should be adequately
incentivized to contribute to increasing coverage

6.2.

AEFI surveillance system
The vaccines are administered as preventive measures to healthy
individuals particularly children. The adverse events following
immunization (AEFI) should be handled effectively in order to
maintain/restore public faith in immunization program. The national
operational guidelines on AEFI surveillance has been updated in
2010 and widely disseminated. All states and districts are now
required to constitute AEFI committees, which assist in streamlining
the reporting mechanism, investigate the reported serious AEFI and
are involved in the causality assessment.

20

• National Immunization Program (NIP) and National Regulatory
Authority (NRA) should be provided with adequately trained
human resource to manage and coordinate immunization safety
initiatives.
• The national AEFI secretariat needs to be set in India. This may be
established at National Centre for Diseases Control or similar
identified institution. This secretariat would establish the links with
the Brighton Collaboration and Global Advisory Committee on
Vaccine Safety (GACVS) to further strengthen AEFI surveillance
in India.

6.3.

VPD surveillance
Vaccine Preventable Diseases (VPD) surveillance system in India is
weak and needs to be strengthened to create an evidence base to

21

<!-- page 17 -->

enable planning and deployment of effective interventions.
Presently, the efforts to collect data on childhood infectious diseases
of public health importance are fragmented and there is a need for
reliable and comparable data to establish baseline information,
monitor trends of infectious diseases, and monitoring the impact of
existing interventions.

important details about disease hotspots and help in the
prediction of epidemics and outbreaks.
• Innovations in diagnostics and tools for surveillance should be
encouraged and facilitated. Tools for surveillance should be such
that even the laboratories that are in the periphery at the primary
health center can use it without much training of staff.

India has different surveillance models. Integrated Disease
Surveillance Project (IDSP) is one of those surveillance systems.
IDSP is a case-based surveillance system for detection of early
warning signals of outbreaks. There are other sentinel surveillance
systems which falls under different vertical national health programs
for diseases targeted for control, elimination or eradication. The
following steps need to be taken to further strengthen the VPD
surveillance system in India:

• Surveys like the National Family Health Survey (NHFS) should be
further strengthened with trained manpower to create data sets on
baseline demography. Such baseline demographic data is of
utmost importance in interpreting disease burden data, results of
clinical trials or when an adverse events following any intervention
has to be investigated and causal linkages established.
The National Polio Surveillance Project (NPSP) has done extremely
well in acute flaccid paralysis (AFP) surveillance in India.
WHO/NPSP provides needed technical and training support for AFP
and measles. This project could be used as a model for deriving
lessons for VPD surveillance in the country.
IDSP needs
considerable strengthening in terms of laboratory and technical
capacity in order to take on VPD surveillance and the efforts in this
direction are already being done for inclusion of Hib and
pneumococcal pneumonia and meningitis surveillance under IDSP.
Since the organisms causing these two diseases are fastidious
growers and are affected by prior treatment with antibiotics, inclusion
of antigen based and DNA based tests will allow detection of
organisms, which would otherwise be missed.

• VPD surveillance has to be a long-term program in order to
assess the impact of vaccination and therefore has to have a
component for capacity building of the people involved.
• The VPD surveillance models followed in other countries like
Brazil, United States of America, in Europe should be studied,
with regard to integration and management of different
surveillance networks in India.
• Assistance may be sought from international agencies, which
already have the resource and expertise in this area, especially
for training, monitoring and independent evaluation of the system.
• The country needs to establish a VPD surveillance networks with
multi level system with first node being at district level. The next
level can be at region; (one for each region of North, West, East
South and Central India) and finally should be monitored by a
Central body. These networks should work with defined and
unified protocol, common SOPs, and also have a stringent and
rigorous system of monitoring/auditing. These networks should
also be equipped with the latest available systems for
communication for timely dissemination of data to higher levels for
action.
• Environmental surveillance using technology like Geographical
Imaging System (GIS) and Remote Sensing (RS) should also be
used to support sentinel surveillance. This could provide

22

6.4.

Vaccine forecasting, procurement and management
All UIP vaccines are purchased at the central level for distribution to
the states. The procurement of vaccines in GoI is done under the
broad overarching General Financing Rules (GFR). The vaccines
are purchased using Annual Rate Contracts (as per GFR) against
which Supply Orders are issued. Parallel contracts are awarded for
most vaccines, because no single domestic manufacturer has
enough available production capacity to cover the entire annual
requirement. While the UIP vaccines are purchased by the central
government from indigenous sources, OPV for mass immunization
campaigns as well as Japanese Encephalitis (JE) vaccine is
procured through other mechanisms.

23

<!-- page 18 -->

The current dependence on a limited number of domestic vaccine
producers leaves the UIP vulnerable to price increases and supply
shortages. There is need for a few steps to be taken to address this
issue:
• Transparent evaluation criteria and effective contract monitoring
systems need to be instituted along with establishment of an
independent evaluation committee with binding outcomes to
oversee all vaccine procurement.
• Procurement timing has been out of step with the realities of
vaccine supply. UIP vaccines have a long production time, short
shelf life, and a supply that must respond to the continuous birth of
babies with a specific schedule of needs. A multi year cycle of
procurement should be tried and contractual lead time increased
to better match vaccine production cycles.

6.4.2. Cold chain management
Cold chain storage capacity in India has improved in recent years. A
nationwide cold chain assessment in 2008 revealed the shortage of
cold chain equipment, of space allocation, and lack of preventive
/corrective measures for breakdown of installed cold chain
equipment facilities in immunization centers and storage facilities.
The shortage of appropriately trained manpower to manage the cold
chain logistics and equipment is another challenge.
These cold chain management challenges can be addressed by:

• The current number of personnel attending to UIP procurement
and distribution is not adequate for the magnitude of the task.
Mechanisms to improve the efficiency of procurement and
distribution must be identified.

• Mechanisms and systems in place for independent auditing of
cold chain capacity,

• Quantities and delivery schedules for procurement of AD syringes
must match vaccine quantity and delivery schedules.

• Developing some basic standards of storage and vaccine stores
as per the global standard and need to be circulated to the states

• Closer management of delivery schedules to ensure that overstocking and under-stocking in different states needs to be
instituted.

• Regular self assessment of cold chain and vaccine management
using standard global Effective Vaccine Management tool.

• An in-depth study of the distribution system – including lower
levels, should be undertaken to evaluate factors considered for
forecasting and determining supply requirements. This will be
helpful in addressing the vaccine supplies and shortages at
various levels in the country.
6.4.1. Vaccine wastage
An assessment of vaccine wastage in India, conducted in 2009
revealed that wastage rates depended on formulation, presentation
and was inversely proportional to session size. Both cold chain
requirement and vaccine wastage is expected to increase several
fold with the introduction of newer vaccines compared to the UIP
vaccines. Smaller dose vial is recommended for vaccines that have
only one dose in the UIP schedule (e.g. Single dose for birth dose of

24

HepB), and 2- 5 dose vials for the newer & more expensive
vaccines). A huge amount of vaccine is damaged in the primary
stores, which is beyond the scope of vaccine wastage study, needs
to be factored in to. Adopting WHO multi-dose vial policy at session
sites may be considered.

• Regional cold chain training cum support units should be
established by GOI to provide appropriate support to the states.

6.4.3. Vaccine stockpile in disaster and outbreak situation
The growing need is being felt to stockpile of vaccines against certain
diseases with potential to cause outbreaks such as Cholera, JE and
H1N1 and other seasonal influenza. These vaccines are required for
an affected target population and the quantity needed for stockpile
should be assessed together with the National Disaster
Management Agency (NDMA). This may be achieved by taking
following step:
• The manufacturers of these vaccines have to be communicated of
the decision ahead of time for planning production and when the
stock expires or is utilized.
• Adequate budgetary provision for such stockpiles should be
created and adequate cold chain equipment earmarked for
storage.

25

<!-- page 19 -->

• The NDMA also needs to be intimated about the locations of these
stockpiles and effective communication maintained with the
agency for delivery of these vaccines during an emergency
situation.

6.5.

• The Tamil Nadu example, where an Independent Public Health
Department with clear lines of supervision, needs to be studied for
scale-up.
• In order to improve vaccine coverage and service delivery, all
human resource initiatives should be in the framework of NHRM.
Various interventions under NRHM, like provision of second
ANMs, support for alternate vaccine delivery etc. should be taken
into consideration for planning for HR activities. Alternate vaccine
delivery needs to be strengthened to reduce vaccine wastage and
improved quality of vaccination.

Human resource
The UIP in India is among the largest immunization program in the
world, targeting 2.7 Crore infants and 3.0 Crore pregnant women.
The program is administered by the Immunization Division of the
MoHFW, GoI. Several assessments have revealed the shortage of
appropriately trained human resource for immunization services at
all levels in the country.

• Available technical resources at the national level i.e. NIHFW and
other national institutes etc. can be utilized for public health
training /orientation for immunization managers.

The present size of immunization division is extremely small, given
the size of the country and number of beneficiaries to be serviced.
Capacity building needs to be supported on a sustainable basis and
should be adequately stressed in the national budget.

• Capacity for data management in order to improve the Health
Management Information System (HMIS) and the mother and
child tracking system is needed. In order to reduce the gap
between reported and evaluated coverage, facility based
reporting should be strengthened.

• The institutional framework for immunization and capacity for
program managers with a public health background and good
leadership skills to drive immunization program needs to be
established.

• There is a need for capacity building in cold chain management in
the country. The institutional framework for strengthening cold
chain management need to be built.

• Immunization is a centrally driven vertical program, with limited
ownership at the facility level. The knowledge, skills and attitude
needed for the various functions should be reviewed, gaps
identified and long-term projection for human resource need to be
developed.

Health is a state subject. A clear co-ordination mechanism needs to
be in place in consonance with central program. A policy for better
state-center co-ordination in vaccine should be adopted maintaining
the state autonomy and creating a structure to coordinate. The
lessons learnt from program introduction should be used to improve
the system. Setting up an appropriate infrastructure for evaluation
and monitoring should be a priority. Any major shift in policy at the
state level should be affected through a state and center coordination
committee

• The existing system should be equipped to handle the new
vaccine introductions. The gap between policy and scale-up of
human resource needs to be addressed.
• The central immunization division needs to be much larger and
expansion needs to be looked into in terms of functional
categories: Data analysis and policy, management for vertical
programs, cold chain, research and communication etc.
Expansion of public health cadre at the central level to enable
induction of more officers from the cadre as immunizations
managers both at the immunization Division at the Centre and at
the State level is much needed.
• A cadre also needs to be built for monitoring and supervision of
immunization program, which is currently lacking.

26

6.6.

Advocacy and communication
Advocacy and communication efforts are as important for community
acceptance of the new vaccine as also for maintaining their
confidence in the existing vaccines. This is especially important for
situations where a few serious adverse events following
immunization are reported. In the community, there are always
people who have concerns regarding vaccines- either perceived or

27

<!-- page 20 -->

real. A system has to be in place to speedily deal with them in a
scientific manner, so that individual concerns do not affect the
vaccination program in the community.
• Operational research to gauge the perceptions of the target
community about immunizations could help in developing the
communication and advocacy strategy and should be
encouraged. The messages and methods used for its
dissemination need to be tailored to the target audience.
• The training of health care workers is needed to respond to the
frequently asked questions (FAQs) by the parents and care givers
so their confidence in the immunization program is maintained
and if possible augmented.
• Effective communication system should be in place to convey the
benefits (and expected adverse events) as well as disadvantages
of not being immunized to the population to be immunized.
• There are needs for studies and operational research to
understand the public and community attitude towards
immunization. This information should be utilized for policy
formulation and taking corrective actions.

6.7.

Ethics and equity
The ethical use and equitable access to prevention and care should
be the basic mantra of any program meant for ameliorating disease
burden in the country. The new vaccines, which are relatively
expensive than traditional vaccines, are commonly used by the
upper and middle class families through personal resources from the
private market. The children of poor families, which can’t afford these
vaccines, are at disadvantage and introduction of these new
vaccines in NIP is an approach to make vaccine accessible to the
poor and needy.

impoverished other than government funds e.g. Typhoid vaccines
in Pakistan, where the rich kids pay a price for the vaccine that
allows it to be subsidized to the poor kids. In Bangladesh, the
fishery industry finances the cholera vaccine for the poor. Such
models need to be studied and similar ones to be developed for
India at least for some vaccines such as pneumococcal conjugate
vaccine, rotavirus vaccine and HPV vaccine.

7.

IMPLEMENTATION AND MONITORING
The national vaccine policy will be widely disseminated amongst
policy makers and program managers. This document will be utilized
for the drafting of the strategies and operational plans. This will be
key document which will be utilized for harmonizing other policy and
planning document.
For each area, a number of monitoring indicators will be prepared
and progress on this document will be monitored accordingly. This
will include a summary of progress, identified areas where progress
is lagging, and propose corrective actions, where needed.
There are multiple stakeholders, including national and state
governments and development partners, in immunization program in
India. The Union and state governments are involved in all aspects of
program while the role of development partners are most often
involved in providing technical assistance and support, rather than
direct implementation.
While the policy implementation will be monitored on the regular
basis, this policy will be reviewed after periodic intervals, allowing
changes to be made, which respond to the reality of then health
policy environment in the country.

• Public health benefits of vaccines in the mass immunization
programs should always outweigh the adverse effects. The
economic burden and inconvenience to the parents/family should
always be factored in when planning.
• Studies that compare the burden to benefits ratio of vaccination to
other options available for prevention should be encouraged.
• There are several models for financing of vaccination for the

28

29

<!-- page 21 -->

8.

KEY REFERENCES
• WHO/SEARO. Regional vaccine policy for WHO South East Asia
region, New Delhi, 2003
• WHO/UNICEF. The State of World’s Vaccines and Immunization,
Third Edition, 2009
• (Draft ) comprehensive Multi Year Plan for immunization in India (
2010-2017)

NTAGI :
• Bryson M, Duclos P, Jolly A, Bryson J. A systematic review of
national immunization policy making processes. Vaccine 2010;
28 Suppl 1:A6-12.
• Senouci K, Blau J, Nyambat B, Coumba Faye P, Gautier L, Da
Silva A, et al. The Supporting Independent Immunization and
Vaccine Advisory Committees (SIVAC) initiative: a countrydriven, multi-partner
to support evidence-based decision
making. Vaccine 2010; 28 Suppl 1: A26-30.
• Bryson M, Duclos P, Jolly A, Cakmak N. A global look at national
Immunization Technical Advisory Groups. Vaccine 2010; 28
Suppl 1: A13-7.
• Gessner BD, Duclos P, Deroeck D, Nelson EA. Informing decision
makers: experience and process of 15 National Immunization
Technical Advisory Groups. Vaccine 2010; 28 Suppl 1:A1-5.
• John, TJ. India’s National Technical Advisory Group On
Immunization. Vaccine 28S(2010) A88-90
• Duclos, P. National Immunization Technical Advisory Groups
(NITAGs). Guidance for their establishment and strengthening.
Vaccine 2010. 28: A18-A25
Matrix for decision making :
• ACIP. http://www.cdc.gov/vaccines/recs/default.htm#acip (last
accessed 8/1/2011)
• http://www.cochrane-handbook.org
• Guyatt GH, Oxman AD, Vist G, Kunz R, Falck-Ytter Y, AlonsoCoello P, Schünemann HJ, for the GRADE Working Group.(
Rating quality of evidence and strength of recommendations
GRADE: an emerging consensus on rating quality of evidence
and strength of recommendations. BMJ 2008; 336: 924-6

30

• Jaeschke R, Guyatt GH, Dellinger P, Schünemann H, Levy MM,
Kunz R, Norris S, Bion J; GRADE working group.( Use of GRADE
grid to reach decisions on clinical practice guidelines when
consensus is elusive. BMJ 2008; 337: a744

Vaccine security :
• Working paper produced by Vaccine Security Workshop
organized by MoH& FW in collaboration with WHO, 2009
(including the thematic papers)
• Assessment of vaccine wastage In India, 2010. MoH&FW and
UNICEF
•

Assessment of Vaccine Procurement System in India, 2004,

Financial Sustainability :
• Kamara L, Milstien J, Patyana M, Lydon P, Levin A and Brenzel L.
Strategies for financial sustainability of immunizations: A review of
strategies from 50 national immunization financial sustainability
plans. Vaccine 2008; 26: 6717-26.
Innovative financing Mechanisms ( for a Corpus Vaccine fund
for India)
• Innovative Financing Mechanisms To Advance Global Health
Past, Present and Future Investments IAVI POLICY BRIEF: 21
JUNE 2009 (http://ghtcoalition.org/files/IAVI_Innovative_
Financing_Mechanisms_to_Advance_Global_Health_2009_EN
G.pdf last accessed 29-12-2010
• Innovative Financing for Global Health A Moment for Expanded
U.S. Engagement? A Report of the CSIS Global Health Policy
Center (http://csis.org/files/publication/100316_Hecht_
InnovativeFinancing_Web.pdf last accessed on 1/1/11)
• Procurement and pricing of new vaccines for developing
countries IAVI POLICY BRIEF16 (http://www.rho.org/files/IAVI_
vaccine_procurement_pricing.pdf)
• Engaging the Debates: An Update on Innovative Financing
Mechanisms for Global Health. SUPPLEMENT TO IAVI POLICY
BRIEF 21: SEPTEMBER 2010 (http://www.iavi.org/Lists/IAVI
Publications/attachments/af3aaa24-8b53-43e0b7b13ce527
d32236/IAVI_Engaging_the_%20Debates_An_Update_on_Inno
vative_Financing_Mechanisms_for_Global_Health_2010_ENG.
pdf last accessed 1-1-11)

31

<!-- page 22 -->

Surveillance :
• http://www.ecdc.europa.eu/en/activities/diseases/Pages/
Full__on_vaccine_preventable_diseases_and_invasive_bacteri
al_infections.aspx
• http://www.ecdc.europa.eu/en/healthtopics/immunization/
external_links/Pages/external_links.aspx
• Global Framework for immunization monitoring and Surveillance
(GFIMS)

9.

LIST OF CONTRIBUTORS
A core team of officials, experts and researchers that was created to
review, give inputs and share their experience in evolving this policy
document are as follows:
1.

Prof. N.K. Ganguly, Former DG, Indian Council of Medical
Research (Chairman)

2.

Prof. N.K Arora, Director, The INCLEN Trust

3.

Dr. Ajay Khera, DC, Child Heath & Immunization, MoHFW, GoI

4.

Dr. T.S. Rao, Advisor, Department of Biotechnology, GoI

5.

Dr. Paul Francis, NPO, WHO India

• Letourneau et al. Improving Global Monitoring of vaccine safety.
Drugs Safety 2008. 3: 389-98.

6.

Dr. Ambujam Nair Kapoor, DDG, Indian Council of Medical
Research

• Duclos P et al. Immunization safety priority project at WHO.
Seminars in Pediatric infectious diseases 14: 233-9.

7.

Dr. Satish Gupta, Health Specialist (Immunization), UNICEF

8.

Dr. Ajay Kukrety, CDSCO

9.

Dr. Sanjukta Sen Gupta, Scientist, National Institute of
Immunology

Adverse Events Following Immunization :
• Operational Guidelines on Surveillance and Response to AEFI,
2010, MOHFW,GOI

National Technical Advisory Group (NTAGI)
1.

Secretary (Health &Family Welfare),

- Chairperson

2.

Secretary (Department of Health Research)- Co-Chairperson

Members

32

3.

Secretary, Department of Bio-technology, GoI

4.

Director General Health Services, MoHFW, GoI

5.

Additional Secretary & Mission Director, NRHM

6.

Joint Secretary (RCH), MOHFW, GoI

7.

Dr. N.K. Ganguly - Ex DG, ICMR

8.

Dr. N.K.Sethi, Senior Advisor (Health), Planning Commission

9.

Dr. V.K.Paul, Prof. & Head, Dept. of Pediatrics, AIIMS,

10.

Dr N K Arora, Paediatrician, & ED, INCLEN

11.

Dr A P Dubey, Prof & Head, Dept of Pediatrics, MAMC

12.

Dr. J. Pulliyel, Head, Deptt. of Pediatrics, St. Stephen’s
Hospital

13.

Dr. D.A.Gadkari, Former director, NIV, Pune

33

<!-- page 23 -->

34

14.

Dr. V. Ravi, Prof. of Virology, NIMHANS, Bangalore

15.

Dr. Shahid Jameel, Prof. of Virology, ICGEB, New Delhi

16.

Lt. Gen. (Retd.) D.Raghunath, (Path) Former DGAFMS &
currently Principal Executive, Sir Dorabji Tata Centre for
Research in Tropical Diseases, Bangalore

17.

Dr. J. P. Muliyel, Director & Head, Deptt. of Community
Medicine, CMC, Vellore

18.

Dr. Rajesh Kumar, Prof. of Community Medicine, PGIMER,
Chandigarh

19.

Dr. Sudhanshu Vrati, Dean, Translational Health Science
&Technology Institute (THSTI), Faridabad

20.

Dr. Lalit Kant, Scientist G, Indian Council of Medical Research

21.

Director, National Centre for Disease Control, Delhi

22.

Drug Controller General of India

23.

Director, National Institute of Immunology

24.

President, Indian Academy of Pediatrics

25.

Representative from UNICEF India

26.

Representative from WHO India

27.

Deputy Commissioner

- Member Secretary
