---
doc_id: "ddefeae7d7c678d2"
source_url: "https://www.labour.gov.in/static/uploads/2025/07/33865304ab47630d1bef9796d69a9a4b.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Tripartite Consultation Meeting for consideration of draft Child Labour (Prohibition & Regulation) Amendment Rules, 2016-to be held on 10.01.2017"
date: "2017-01-09"
pages: 36
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bdac15688cc476e5"
---

<!-- page 1 -->

MEETING NOTICE

F.No.A-42025/2/2004-CL (Voi.IV)
Government of India
Ministry of Labour & Employment
Shram Shakti Bhawan, Rafi Marg,
New Delhi~1, Dated 03ro January, 2017
To

(i)

The Central Trade Union Organizations
(As per list attached at AnnexureMI)
NGOs (As per list attached at Annexure-11)
The Employers' Associations
(As per list attached at Annexure-HI)
The Representative of State Governments
(As per list attached at Annexure-IV)

(ii)
(iii)
(iv)

Subject:

Tripartite Consultation Meeting for consideration of draft Child Labour (Prohibition &
Regulation) Amendment Rules, 2016, Report of Technical Advisory Committee and
Ratification of ILO Convention No.138 & 182 --to be held on 10.01.2017 - regarding.

Madam/Sir,
It has been decided to hold a Tripartite Consultation Meeting under the chairmanship of
Hon'ble MOS (Independent Charge) for Labour & Employment with the representatives of the Central
Trade Unions, Employers' Association, NGOs and Central/State Governments on 10.01.2017
(Tuesday} at 11:00 A.M. in Mirza Ghalib Chamber, SCOPE Convention Centre, CGO Complex, New
Delhi on the subject cited above.
2.

The agenda items for consideration m the Tripartite Meettng are as under·,- Draft Child Labour (Prohibition & Regulation) Amendment Rules, 2016 (Copy enclosed
The draft Rules also available on Ministry's website- www labour gov 111)
r
Ratification of ILO Convention No.138 & 182 (copy enclosed)
, Report of Technical Advisory Committee on review of Schedule of hazardous
occupations & processes.

3.
In this regard, the Central Trade Unions, Employers' Association. NGOs and Central/State
Governments are requested to nominate one delegate/representative each from their respective
organization for the Meeting. The non-official outstation delegates are entitled for travelling allowance
(air fare ~ Economy Class-by most direct route-AIR INDIA only). The Non-official delegates have to
submit the nomination letter for settlement of TA claims.
4.
The Names with complete postal address, email address, telephone & Fax No_ of the
representatives who will be attending the Meeting, may be sent to this Ministry by Email to
dk.himanshu@nic.in or anita.tnpathi76@nic.in at the earliest.
5.

It is requested to make it convenient to attend the meeting.
Yours faithfully,

~-c:Z.I ' \:><\I

Encl: as above

{Anita Tripathi)
Deputy Secretary to the Government of India
Tete No.23711354
Copy with the request to attend the Meeting
1.
2
3.

All the Members of the Committee.
Secretary (L&E)/ AS (L&E)/JS(RA)
PS to MOS(IC). L&E/PSO to Secretary (L&E)

<!-- page 2 -->

A nn exure-!
CENTRAL TRADE UNION ORGANIZATIONS

s.

Name and Address of the Organization

I Office Bearer

No
1.

2.

Bhartiya Mazdoor Sangh, Dattopant Thengadi
Shri Baij Nath Rai , Pres ident
Bhawan , 27, Deendayal Upadhyay Marg , Rouse
Avenue, New Delhi-11 0002.
Tel: 011- 23222654, Fax: 011 -23212648
Email: bms@indiya.com/bmsdtb@gmai l.com
1
Indian National Trade Union Congress,
Dr. G. Sanj eeva Reddy, President
'SHRAMIK KEN DRA',
4, Bhai Veer Singh Marg, New Delhi-110001 .
Tel: 01 1- 23747767/23747768, Fax: 01 123364244
Email: intuchq@del3.vsnl. net. in
All India Trade Union Congress,
Shri Ramendra Kumar, President
35-36, D. D.U. Marg, Rouse Avenue ,
New Delhi-110002.
Shri Gurudas Das Gupta, Genera l
Tel: 011- 23217320, 23220264,
Secret ary
Fax: 011-2 3222427
Email: aitucong@boLnet. in
1
Hind Mazdoor Sabha,
Sh ri Sharad Rao, President
120, Saba Road , New Delhi-110001
Tel : 011 - 23413519, Fax. 011 -234 11 03~s h ri Harbhaj an Si ngh Sid hu, General
Ema11: hms1@gmall.com, hms1@gma1l.com
Sec ret ary

I
I

3.

4.

5.

6.

7.

Centre of Indian Trade Unions,
B. T. Rannadive Bhawan, 13-A, Rouse Avenue ,
New Delhi-11 0002.
Tel: 23221306, 23221288,
Fax: 23221284
Email: citu@bol. net. in , akpcitu@gma il.com
All India United Trade Union Ce ntre (AIUTUC),
77/2/1 , Len in Saran i. Kolkata-7000 13.
Tel : 033-2265-9085, 2249-1828, 2265-3234,
Fax: 033-22465605, 22465114, 22467754
Email: utucls@vsnl.net
Delhi Address:
3A/38, W EA, Karol Bag h, New Delhi-110005.
Tel : 01 1-257 49464
Telefax: 011 -25726631
(Coordinator- Mr. Prem ChandMob.98684341 75)
Trade Union Coordination Centre (TUCC),
Central Committee, Lokhande Bhawa n, F-52,
Vikash Nagar, Hastashal, Uttam Nagar, New
Delhi-1 10059.
Tel: 23714131 , 23352273,

Dr. A. K. Padmanabhan, President
Sh ri Gurudas Das Gupta, General
Secretary
Shri Krishna Chakraborti, President

Shri SP Tiwary, Gen eral Secretary

<!-- page 3 -->

-------- --

Mob.094330313 43 (S PTiwary), 09331331343
Email: tucccc@y ahoo.co.in &
tucci nd ia @__g__f!l_a~ .com
Self Employed WOri·len's Association (SEWA), -~-Ms. Jyotiberl MeCwan, Gener3i.
SEWA Receptio n Centre, Opp. Victoria Garden, Secretary
Bhadra, Ahmed abad-380001, Gujarat.
Tel: 079-25506441,25506444,25506441,
Fax: 079-25506 446
Email: mai!@sewa org. sewau~_~on@g~~ils;_o_m_
-···
- - - - - ..
1
AU India Centra! co·uncil of -Trade Union
' Shri S. Kumarasamy, President
'
(AICCTU),
U-90, Shakarpur , Delhi-11 0092
Tel: 011· 22521 067, Fax 011-22442790,
Email: aics;t~@g_mail. com
Labour Progress ive Federation (LPF),
Shri M. Shanmugam, General
Kalingram, 10, T hiyagaraya Street, North
Secretary
Usman Road, T h1yagaraya Nagar,
Chennai-600017
Tel: 044-281433 33, Fax 044-28141122
Email: lpfhqr@_g mail. com
---- -~ ...
-------·------ -~ ---------11
United Trades U nion Congress,
, Shri Abani Roy, General Secretary
1
249, Bipin Beha ri Ganguly Street, 1s Floor,
Kolkata-700012
i Email: shadique7@gmail.com
Tel: 033-222592 34, Telefax 033-22375609,
1

8.

--~-~-

9.

.-.- ~- __ _j

~

10.

11.

I

12.

Delhi Address:
17, Ferozshah R oad, New Delhi-110001.
Ph.23782167, Fax: 23782342
National Front of Indian Trade Unions
(Dhanbad),
Water Board Col any, Harimandir Road,
Hirapur, Dhanba d-826001.
Tel: 0326-23108 04, Fax 0326-2310804,
Email: nfitunp@ gmaiLcom , contactus@nfitu.org
Delhi Address:
5130/5, Main Ba zar, Paharganj, New Delhi110055.
Mob.093127658 69
~-·

---· ··--.. .. - - Dr. Deepak Jaiswal, President
-~-

"'

I
j'

J

I

<!-- page 4 -->

Annexure-11

NGOs
- - - - ----

S.No.

.-

--~---

1.
2.

3.
4.
5.
6.
7.

8

_-_-rj~~,~

Name of the NGO --55
·Prayas Juvenile Aid_s;en_tre~ciety_
elhi
Pratham
Mumba
HAQ Centre for Child Rights
New D elhi
- - · - - -- - - · - - - - - - - - - -

Bachpan Bachao Andolan

New De lhi
Justice & Care
De Ihi
---------· .. New
---Apne Aap
New De Ihi
-----Save the Children
-- ------- -·---- - - - r~e.w_De Ihi
Child Rightsand YoujCRY)
. ---- New De Ihi
-·

-

<!-- page 5 -->

Annexure·lll
EMPLOYERS' ORGANIZATION

--

-

--

S.No.

Name of the~ Address-

1.

Organ1sat1on
Council of lnd1an

Alllndta Organ1sat1on of Em~ployers Federatton House Tansen Marg, New I

Employers (CIC)-

Dolhr-110001

AlOE

' Ph: 011- 23765083

-

-

~~

I E-mail- aioe@ficci.com __
2.

,

Council of Indian
Employers (CIE)-SCOPE

i

I

____
1
1"
Floor,
Core-8.
SCOPE
Complex.
7
Lodi
Road,
Jawaharlal
Nehru Stadium
1
1 Marg. CGO Complex. Pragati V1har, New Delhi, DL 110003
Phone 0112436 2604

Council of Indian

Email- scopedg~.com
Army & Navy Building, 148,MahatmaGandhi Road, Mumbai- 400023.

Employers (CI E)-- EFI

Tel 2281423214093

!

3.

i

E-mail: efisola r@mtnl.net.in, efisolar(al_gmail .com
4.

All India

41h Floor, 'Jeevan Sahakar', SirP.M.Road, Fort.Mumbai-400001.

Manufacturers'
Organization (AIMO)

Tel 022-22615858 I 22615959
Fax 022-22615656

I

I Email: ainzoindia@aimoindia.com

5.

All India Association

National President's - president@aimoindia.com
1 National Gen. Secy E-mail: gs@aimoindia.com ~New Excelsior Build1ng, 6th Floor,AK. Nayak Marg, Fort, Mumbai-400

of Industries (AlAI)

001, Maharashtra, INDIA.
Phone +91-22-22019265
~ Fax: +91-22- 2201 9764

--

6.

Federation of
Association of Small
Industries of India
(FASII)

___ i. ~~'!ll_:__ i!lf_o@liaiindl~~con] .
1

-----~--

---~~-

----

General Secretary/President (Whoever is authorized)
Federation of Association of Small Industries of India (FASII)
India (FASII), Laghoodyog Kutee, 23-B/2, GuruGobind Singh Marg (New
Rohtak Road). Nearliberty Cinema, New Delhi-11 0005_
Telefax No.28713341

7

Indian Council of Small
Industries (ICSI)

1 Email:-fasii1959@_gmail.com
i The President,
Indian Council of Small Industries
19/2, Banamali Naskar Road. Kolkata-700060

I

I

Fax No 033-23490924,
Tele No.033-23491129, 09830411264 (M)

Email: pcri@vsnl.com , icsi.kolkata@yahoo.com

8.

Laghu Udhyog Bharti
(LUB)

, Laghu Udhyog Bharti (LUB)

!, 1-E/11, Swami Ramtirath Nagar. Jhandewalan Extn_,
New Delhi-11 0055_

Phone-23625064. 23525052. 41540772
Telefax 23525052 #
9.

The Associated
Chambers of

Email -headoffice@lubindia.com
The Associated Chambers of Commerce&
I lndustryoflndia, ~.Sardar ~_?_tel Marg. Chanky__§_e_uri

i
,

'

<!-- page 6 -->

r

Commerce & Industry -~ NewDelhi-110021.
of India (ASOCHAM)
Phone:011-4655 0555
Fax 011-46536481/82
~mail~ as~ocham@n!~~i.n .

10.

Confederation of
, Indian Industries
I (CII)

- ---

I
~
, Confederation of Indian Industry,
'
I
23, lnsttuWonaiArea. Lodi Road, New Delhi-11 0 003.
i
! Phone:24621874. 24626149
I
, Fax:24633168, 24626149.
Email:ciico@ciionl~!l.e.o~g , i_!l}o@cii.in ___ . -~~~-~__,
Federation of Indian Chamber of Commerce & Industry, Federation
I House, Tansen Marg, New Delhi.
'
I Phone 23738760-70
' FaxNo.23329369

i

__J

11.

Federation of Indian
Chambers of
Commerce and
Industry (FICCI)

12.

PHD Chambers of
Commerce &
lndustnes (PHDCCI)

: Email:ficci@!~cci.~om

...

------·····

...

---··--

4/2,SJri lnstitutionaiArea. August Kranti rv'erg,
: New Delhi, Delhi 110016, New Delhi, DL 110016

I Phone:011 2686 3801
--1-§!!Jail- phdcci@.phdcci.in

13.

14.

Federation of Indian
Micro, Small &
Medium Enterprises
Chamber of Small
lndustrv Associations
...

-----

-------~···

--i
I

. ----------·-- - ~_j

<!-- page 7 -->

Annexure~IV

List of Representative of State Governments
1. Secretary (Labour)
UT of And man & Nicobar Islands
Secretariat, Port Blair-744101.

2. Principal Secretary (Labour}
Govt. of Andhra Pradesh
308, 3rd Floor, L Block Secretariat,
Hyderabad-500022

3. The Secretary {Labour)
Govt. of Arunachal Pradesh
Civil Secretariat, Block No. 9,
ltanagar-791111.
4. The Secretary (Labour)
Govt. of Assam
Block H, 1st Floor,
Dispur, Guwahati-781006
5. Secretary (Labour)
Govt. of Bihar
Vikas Bhawan, Baily Road,
Patna-800015

6. The Secretary (Labour)
Chandigarh Administration
UT Secretariat, Sector-9,
Chandigarh

7. Secretary {Labour)
Govt. of Chhattisgarh
D. K. S. Bhawan, Mantralaya,
Raipur, Chhattisgarh-492001
8. The Secretary (Labour)
UT of Dadra & Nagar Haveli
Silvassa-396230.

9. The Secretary {Labour)
UT of Daman and Diu
Secretariat, MOTI Daman-396220.
10. The Secretary-cum-Commissioner
Office of Labour Commissioner
Govt. of NCT of Delhi
5, Sham Nath Marg, Oelhi-110054

+

<!-- page 8 -->

11. Secretary {Labour)
Govt. of Goa
New Secretariat Complex,
Porvorim Goa-403501.
12. The Principal Secretary {labour)
Govt. of Gujarat
Block No. 5, 6th Floor,
New Sachivalaya, Gandhinagar
13. The Principal Secretary (Labour)
Govt. of Haryana
Room No. 606, 6th Floor, Mini Secretariat,
Sector-17, Chandigarh
14. The Principal Secretary (Labour)
Govt. of Himachal Pradesh
A-419, H. P. Government Sectt.,
Shimla-171002
15. The Secretary (Labour)
Govt. of Jammu & Kashmir
Room No. 112, 1st Floor, Civil Secretariat,
Srinagar-190001.
16. The Principal Secretary (Labour)
Govt. of Jharkhand
Nepal House, Doranda,
Ranchi-834002.
17. The Additional Chief Secretary (Labour}
Govt. of Karnataka
Room No. 414, 4th Floor, Vikasa Soudha,
Dr. Ambedkar Veedhi, Bangalore
18. Additional Chief Secretary,
Department of Labour & Skill,
Govt. of Kerala
Room No. 138, 2nd Floor, North Block,
Govt. Sectt., Thiruvananthapuram
19. The Secretary
Deptt. Of Labour, Employment & Training
Lakshdweep Administration
Secretariat, Kavaratti
20. The Principal Secretary (Labour)
Govt. of Madhya Pradesh
Room No. 64, Mantralaya,
Vallabh Bhawan, Bhopal-462004
-2-

<!-- page 9 -->

21. The Principal Secretary (Labour)
Govt. of Maharashtra

Room No. 128, Mantralaya
Mumbai-400032.
22. The Principal Secretary (Labour)
Govt. of Manipur

Manipur Secretariat, South Block,
lmphal-795001.
23. The Principal Secretary (Labour)
Govt. of Meghalaya

Add I. Secretariat Building,
Shillong-793001.
24. The Secretary,
Department Of Labour, Employment & Industrial Training,
Govt. of Mizoram

Upper Republic near Seventh Day Adventist Church,
Aizawl-796001.
25. Secretary (labour)
Govt. of Nagaland

New Secretariat, Kohima-797001.
26. The Principal Secretary (Labour)
Govt. of Odisha

Shram Bhawan, Kharavel Nagar, near Gurudwara,
Bhubaneshwar
27. The Secretary (labour)
Govt. of Puducherry
B' Block, Ground Floor, Chief Secretariat,
Puduch erry-605001.
28. The Principal Secretary (Labour)
Govt. of Punjab

Mini Secretariat, Sector-9,
Chandiga rh-160001.
29. The Secretary & Commissioner (Labour)
Govt. of Rajasthan

Room No. 2024, Main Building,
Secretariat, Jaipur-302006
30. The Principal Secretary
Department of labour
Government of Sikkim

Shram Bhawan, Sokaythang
PO-Tadong, Gangtok-737102

+

<!-- page 10 -->

31. The Secretary
Department of Labour
Govt. of Tamil Nadu
Secretariat, Chennai-600009.
32. The Principal Secretary {Labour)
Govt. of Telangana
0-Biock, 1st Floor, Room No. 230,
Telangana Secretariat, Hyderabad-500004.
33. The Special Secretary (Labour)
Govt. of Tripura
Civil Secretariat, Agartala-799001
34. The Principal Secretary {Labour)
Govt. of Uttar Pradesh
20-21, Bahukhandi Bhawan,
Sachivalaya, Lucknow-226001.
35. The Secretary (Labour)
Govt. of Uttarakhand
Secretariat, 4, Subhash Road,
Dehradun-248001.
36. The Additional Chief Secretary {Labour)
Govt. of West Bengal
New Secretariat Building, 12th Floor,
1, K.S. Roy Road, Kolkata-700001.

*****

<!-- page 11 -->

F.No.A-42025/2/2004-CL (Voi.IV)

Government of india
Ministry of Labour & Employment
(Child Labour Section)
Shram Shakti Bhawan, Rafi.Marg,
New Delhi-1, Dated i;,'•Sept~mber, 2d16

OFFICE MEMORANDUM
.·"

Subject: Constitution of Committee for framing of Rul¢_s

er Chiid... LClbour
---·uXCi'
·:,·-'

(Prohibition & Regulation) Act, 1986 as amended: by Child Labour
(Prohibition & Regulation) Amendment Act, 2016- reg_afding.

In order to formulate Rules under Section 18 of the Child lab.our (Prohibition &
Regulatron) Act,

1986 as amended by Child Labour (Prohibition & Regulation)

Amendment Act,

2016,

a Committee has been constituted with the following

composition:

1. Joint Secretary, Child Labour, Ministry of L & E

b.

2. Representative of Ministry
3. Representative of Office of

Information & Broadcasting
-·-Member
St-,.~jtvkuW1VV~- D.P; f'_L.l.,.....·D~v\M""';)

LC
:->
-::,
f Si..: 0 rJ~)..c$/v-u,.n->-4.. b'f f.-1-E.~
4. Representative of Ministry 9f Women & Child Developro..ent
/.MMHMr ~4MN4 .fllHNt. :f", £. j

5. Senior Officer, State Labour OJ:Wartment Maharashtra
L Gh.. SVNI(. 1/:>Jt&,tH- I b I.-C..J
6. Ms. Helen Sekar, Senior fellow, VVGNLI

l

---~chairman

\\j";e/· Shri S.D. Singh, Retired Legal Consultant
~"v

~8. Deputy Secretary/ Director, Child Labour, Ministry of L & E

--~Member
-

---Member

.

·--Member

-·- MeiTiber
---Member

~!)! \\;.'
0\l\ ..../
-f\.

Secretary
The terms of reference for the Committee will be as under:-

2

The Committee is required to frame Rules under following· Sections:-

(i)

The conditions and safety measures for child who works as an arjist iri an
audio visual entertainment industry, including advertisement, films, t8ievi$ion
serial, for any such other entertainment for the sports activity except the
cir"CUs, under Section 3(2) (b).

<!-- page 12 -->

-2Prescribing any other activity vvhich a child as an artist can pe1iorm or

(ii)

practice under sub-section (c) of Explanation under 3(2)(b).
(iii)

The manner of payment of amount to the child or adolescent in whose favour

the amount is credited in the Child and Adolescent Labour Rehabilitation
Fund under sub-section 4 of Section 14 B.
The manner and payment of the amount to the apprqprTate Government for

(iv)

compounding of offence committed for the first time under sub-section(3) of
Section 14 or any offence committed by an accused person being parent or
guardian; under section 14 D(1) .. ·
(v)

The powers to be exercised and the duties to be performed

bY the officer

specified and the local limits within which such powers or duties shali be
carried out under section 17A

(vi)

Review of existing Rules made on the matter listed under Section 18 of the
Principal Act.

Deputy Secretary to the Government of India
Tele No.23711354

To

._

t~''fM~

~)

All the Members of the Committee

-/(ii)

Secretary, Ministry of Information & Broadcasting

/(iii)

Secretary, Ministry of Women & Child Development

,__/iiv)

DG, VVGNL!

cftl)

Principal Secretary, Labour Deptt., Government of M.aharasthra

~vi)

PS to Secretary (L&E)

vfviil

PStoCLC _~I G

..--------{vii i)

PS to AS (L&E) _

~ PS to JS(RA)

~

I

\\ill. 1 \ c1

<!-- page 13 -->

Draft Child labour {Prohibition and Regulation) Amendment Rules, 2016
1. (1) These rules may be called the Child Labour (Prohibition and Regulation)
Amendment Rules, 2016.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Child Labour (Prohibition and Regulation) Rules, 1988 (hereinafter referred to
as the Principal rules), in rule 1, in sub-rule (1), for the words, brackets and figures "the
Child Labour (Prohibition and Regulation) Rules, 1988, the words, brackets and figures
"the Child and Adolescent Labour (Prohibition and Regulation) Rules, 1988" shall be
substituted.
3. In rule 2 of the principal rules,-

(i)

for clause (a}, the following clause shall be substituted, namely:'(a) "Act'' means the Child and Adolescent Labour (Prohibition and Regulation)

Act, 1986(61 of 1986)';
(ii)

for clause (b), the following clause shall be substituted, namely:'(b) "Committee" means the Technical Advisory Committee constituted under
sub-section {1) of section 5 ofthe Act';

(iii)

after clause {d), the following clause shall be inserted, namety:'(dd) "Municipality" means an institution of self-government constituted under
article 243Q of the constitution;';

(iv)

after clause (e), the following clause shall be inserted, namely:'( eel "Panchayat" means a Panchayat constituted under article 2438 of the
constitution;';

{v)

for clause {g), the following clauses shall be substituted, namely:'(g) "section" means the section of the Act;
{h) the words and expressions used in these rules, but not defined therein and
defined in the Act, shall have the meanings as assigned to them in the Act.'.

4. After rule 2 of the principal rules, the following rules shall be inserted, namely:"2A. Prevention of child employment.- To ensure that the children and adolescents are
not employed or permitted to work in any occupation or process in contravention to the
Act, the Central Government, through appropriate measures, shall(a) arrange public awareness campaigns in media including the television, radio,
internet and the print media to make the general public, including the
employers and the children and adolescents who may be employed in
contravention of the Act to aware the provisions of the Act, and thereby
discourage employers or other persons from engaging children and adolescent
in any occupation or process in contravention of the provisions of the Act;
(b) promote reporting of enterprises or instances of employment of children or
adolescents in contravention of the Act, by developing and advertising easily
accessible means of communication to authorities specified by the Central
Government;

2

<!-- page 14 -->

(c) display to the possible extent the provisions of the Act and these rules and other
information relating thereto in railway coaches, at railway stations, major bus
stations, ports and port authorities, airports and other public places including
shopping centers, markets, cinema halls, hotels, hospitals, panchayat offices,
police stations, court complexes, and offices of all authorities authorised under
the Act;
{d) promote through appropriate method the inclusion of the provisions of the Act
in learning material and syllabus in school education; and
{e) promote inclusion of training and sensitisation material on the provisions of the
Act and the responsibilities of various stakeholders thereto, in police, judicial
and civil service academies, teachers training and refresher courses and arrange
sensitization programmes for other relevant stakeholders including, panchayat
members.
2B. Child to help his family, etc.- {1) Subject to the provisions of section 3, a child
without affecting his school education, in any manner, may(a) help his family in his family enterprise, subject to the condition that such help,(i)
shall not be in any hazardous occupation or process listed in Part B of the
(ii)

Schedule;
shall not include work or occupation or process that is remunerative for

(iii)

the child or his family or the family enterprise;
shall only be allowed to help in his family, or in a family enterprise where

(iv)

his family is the occupier;
shall not perform any tasks during school hours or between 7 pm and 8

(v)

(vi)

am;
shall not be engaged in such tasks of helping which hinders or interferes
with the right to education of the child, or his attendance in the school, or
which may adversely affect his education including activities which are
inseparably associated to complete education such as homework or any
extra-curricular activity assigned to him by the school;
shall not be any engagement which continues more than the period which
may make him tired without rest and such rest shall be of at least to fresh
his health and mind and a child shall not help for more than three hours

excluding the period of rest in a day; and
(vii)
shall not include in anyway substitution of the child for an adult or
adolescent while helping his family or family enterprise;
(b) aid or assist his family in such manner which is not incidental to any occupation,
work, profession, manufacture or business, or for any payment or benefit to the
child or any other person exercising control over the child, and which is not
detrimental to the growth and development of the child;
Explanation 1.- For the purposes of this rule, for comprising the family of a child, only(a) real brother and sister of the child, or

3

<!-- page 15 -->

(b) brother or sister of the child through lawful adoption by the parents of the child;

and
(c) real brother and sister ofthe parents of the child;
shall be included.
Explanation 2.- For the purpose of this rule, an Inspector may seek the clarification from
the Central Government, in case of any doubt in respect of 'help' for securing
compliance with the provisions of section 3, and shall abide by the clarification so
obtained;
2C. Child to work as an artist, etc.- (1) Subject to the provisions of section 3, a child may
be allowed to work as an artist subject to the following conditions (a) no child shall be allowed to work for more than five hours in a day, and for not
more than three hours without rest;
(b) any producer of any audio -visual media production or any commercial event
involving the participation of a child, shall involve a child in participation only
after obtaining the permission from the District Magistrate of the district where
the activity is to be performed and shall furnish to the District Magistrate before
starting the activity an undertaking in Form C and the list of child participants,
consent of parents, name of the individual from the production or event who
shall be responsible for the safety and security of the child;
{c) the undertaking referred to in clause (b) shall be valid for six months and shall
clearly state the provisions for education, safety, security and reporting of child
abuse including,(i)

ensuring facilities for physical and mental health of the child;

(ii) timely nutritional diet of the child;
(iii) safe, clean shelter with sufficient provisions for daily necessities; and
(iv) compliance to all laws applicable for the time being in force for the
protection of children, including their right to education, care and
protection, and against sexual offences;
{d) appropriate facilities for education of the child to be arranged so as to ensure
that there is no discontinuity from his lessons in school;
(e) one responsible person be appointed for maximum of five children for the
production or event, so as to ensure the protection, care and best interest of the
child;
(f) twenty percent of the income earned by the child from the production or event
to be directly deposited in a fixed deposit account in a nationalised bank in the
name of the child which may be credited to the child on attaining majority; and
(g) no child shall be made to participate in any audio visual and sports activity
against his will and consent.
(2) For the purposes of clause (c) to the explanation of sub-section (2) of section 3, the
expression "such other activity" contained therein, shall mean-

4

<!-- page 16 -->

(i) any activity where the child himself is participating in a sports competition or
event or training for such sports competition or event;
(ii) cinema shows on television, internet, radio or any other media including reality
shows which includes quiz shows and talent shows;
(iii) drama serials;
{iv) participation as anchor of a show or events; and
(v) any other artistic performances which the Central Government permits in
individual cases.".
5. After rule 15 of the principal rule, the following rules shall be inserted, namely:"15A. Hours of work - Subject to the provisions of section 7, no adolescent shall be
required or permitted to work in an establishment in excess of such number of hours of
work as is permissible under the law for the time being in force regulating the hours of
work ofthe adolescent in such establishment.".
6. In sub-rule (1) of rule 16 of the principal rules, for the word "children", the word

"adolescent" shall be substituted.
7. After rule 16 of the principal rules, the following rule shall be inserted, namely:"16A. The manner of payment of amount to the child or adolescent under sub-section
(4) of section 148, etc.,- (1) The amount credited to the Fund constituted under sub-

section (1) of section 148 and deposited or invested, as the case may be, under subsection (3) of that section, and the interest accrued on it, shall be paid to the child or
adolescent in whose favour such amount is credited in the following manner, namely:(i)

(ii)

(iii)

(iv)

the Inspector or the nodal officer having jurisdiction shall, under his
supervision, ensure that an account of such child or adolescent is opened in a
nationalised bank and inform the bank in which the amount of the Fund is
deposited or, as the case may be, to the officer responsible to invest the
amount of the Fund under sub-section (3) of section 148;
the interest accrued on the proportionate amount of the Fund in favour of the
child or adolescent shall be bi-annually transferred to the account of the child
or adolescent, as the case may be, by the bank or officer referred to in clause
(i} under information to the Inspector referred to therein;
when the concerned child or a-dolescent completes the age of eighteen years,
then, as soon as may be possible forthwith, the total amount in his favour
remaining in the bank or remaining so invested under sub-section (3) of section
148 shall be transferred to the account of child or adolescent, as the case may
be; and
the Inspector referred to in clause (i) shall prepare a report of the amount
transferred under clause (ii) and clause (iii) with particulars of the concerned
child or adolescent sufficient to identify him and send a copy of the report
annually to the Central Government for information.

5

<!-- page 17 -->

(2) Subject to the direction of the Court, any amount recovered in accordance with the
Judicial pronouncement in favour of a child or adolescent in respect of the
contravention of the provisions of the Act shall also be deposited in the Fund referred to
in sub-rule (1) and shall be spent in accordance with such pronouncement.".
8. In rule 17 of the principal rules, for sub-rule (1), the following sub-rules shall be

inserted, namely:"(1) All adolescent employed in any of the occupations set-forth in the schedule, shall
produce a certificate of age from the appropriate medical authority, required to do so by
an Inspector.
(1A) The appropriate medical authority shall, while examining an adolescent for issuing
the certificate of age under sub-rule {1), take into account{i)
{ii)

the Aadhar Card of the adolescent; and in the absence thereof;
the date of birth certificate from school or the matriculation or equivalent
certificate from the concerned examination Board of the adolescent, if
available; and in the absence thereof;
the birth certificate of the adolescent given by a corporation or a municipal
authority or a panchayat;

{iii)

and only in the absence of the methods specified in clauses {i) to (iii), the age shall
be determined by such medical authority through an ossification test or any other
latest medical age determination test and such test shall be conducted on the order
of appropriate authority specified by the Central Government in this behalf and such
determination shall be completed within fifteen days from the date of such order.".
9. After rule 17 of the principal rules, the following rules shall be inserted, namely:-

"17A. Any person who may file a complaint for commission of the offence under subsection (1) of section 16 may include school teachers and representatives from school
management committee who shall be sensitised to file complaint in the event that any
of students in their respective schools is employed in contravention to the provisions of
the Act.
17.B. Manner of compounding the offence.- (1) An accused person,who commits an offence first time under sub-section (3) of section 14; or
(ii) who being parent or a guardian, commits an offence under section 14;
(i)

may file application to the District Magistrate having jurisdiction for compounding
the offence under sub-section (1) of section 14D.
(2) The District Magistrate shall after hearing the accused person and the Inspector
concerned on application filed under sub-rule (1) dispose of the application and if
application is allowed, issue the certificate of compounding subject to(i)

the payment of a sum of fifty percent of the maximum fine provided for
such offence within a time specified in such certificate; or
6

<!-- page 18 -->

(ii)

the payment of an additional sum of twenty-five percent of the maximum
fine provided for such offence together with the compounding amount
specified under clause (i), if the accused person fails to pay the
compounding amount under that clause within time and such delayed
payment shall be made within the period specified for such purpose in the
certificate of compounding.

(3) The compounding amount shall be paid by the accused person to the Central
Government.
(4) If the accused person fails to pay the compounding amount under sub-rule (2), then,
the proceeding shall be continued as specified under sub-section (2) of section 14D.
17C. Duties of District Magistrate.- (1) The District Magistrate shall(i)

specify such officers subordinate to him, as he considers necessary, to be
called the nodal officers, who shall exercise all or any of the powers and
perform all or any of the duties of the District Magistrate conferred and
imposed on him by the Central Government under section 17A and the District
Magistrate may, as he thinks appropriate, assign such powers and duties to a
nodal officer to be exercised and performed by him within his local limits of
jurisdiction as subordinate officer;

(ii)

preside over as chairperson of the Task Force to be formed in a District
consisting of(a) Inspector appointed under section 17 by Central Government for the
purposes of his local limit of jurisdiction;
(b) Superintendent of police for the purposes of his local limit of jurisdiction;
(c) Additional District Magistrate for the purposes of his local limit of
jurisdiction;
(d) Nodal officer referred to under clause (i) for the purposes of his local limit
of jurisdiction;
(e) Deputy Labour Commissioner for the purposes of his local limit of
jurisdiction;
(f) two representatives each from a voluntary organisation involved in rescue
and rehabilitation of employed children in the district on rotation basis for a
period of two years;
(g) a representative of the District Legal Services Authority to be nominated by
the DistrictJudge; and
{h) a member of the District Anti Trafficking Unit;

(i) Chairperson of the Child Welfare Committee of the District;

(j) Child Labour Protection Officer in the District under the Integrated Child
Protection Scheme of the Ministry of the Government of India dealing with
women and child development;
(k) Any other person nominated by the District Magistrate;
(I)

the Secretary of the Task Force who shall be any nodal officer referred to in
clause (i) and nominated by the Chairperson.

7

<!-- page 19 -->

{2) The Task Force referred to in clause (ii) of sub-rule (1) shall meet at least once in
every month and shall make a comprehensive action plan for conducting the rescue
operation taking into account the time available, point of raid in accordance with the
law for the time being in force, confidentiality of the plan, protection of victims and
witnesses and the interim relief in accordance with the guidelines for rescue and
repatriation issued by the Central Government from time to time and the Task Force
shall also cause to upload the minutes of such meeting on the portal created for such
purpose by the Central Government.
{3) Apart from the duties referred to in sub-rule (1), the District Magistrate shall ensure
through Nodal officers referred to in clause (i) of that sub-rule that the children and
adolescent who are employed in contravention of the provisions of the Act and rescued
shall be rehabilitated,
(a) in accordance with the provisions of(i)

the Juvenile Justice (Care and Protection of Children) Act, 2015 {2 of 2016)
and the rules made there under;

{ii)

the Bonded Labour System {Abolition) Act, 1976 (19 of 1976);

{iii)

the Central Sector Scheme for Rehabilitation of Bonded Labourers, 2016;

(iv)

any National Child Labour Project;

{v)

any other law for the time being in force under which such children or
adolescents may be rehabilitated; and

{b) subject to the direction of the concerned court and in accordance with the
judicial pronouncements;
(c) the guidelines for rescue and repatriation issued by the Central Government
from time to time in this regard.
170. Duties of Inspectors.- An Inspector appointed by the Central Government under
section 17, for the purposes of securing compliance with the provisions of the Act, shall

(i)

comply with the norms of inspection issued by the Central Government from

(ii}

time to time;
comply with the instructions issued by the Central Government from time to
time for the purposes of securing the compliance with the provisions of the
Act by the Inspector; and

(iii}

report the Central Government quarterly regarding the inspection made by
him for the purposes of securing the compliance with the provisions of the
Act and the action taken by him for such purposes.

17E. Periodical inspection and monitoring for the purposes of section 17B etc.- The
Central Government shall create a system of monitoring and inspection for carrying into
effect the provisions of section 17 which may include inter~atia-

8

<!-- page 20 -->

(i) the number of periodical inspection to be conducted by the Inspector of the
places at which the employment of children is prohibited and hazardous
occupations or processes are carried out;
(ii) the intervals at which an Inspector shall report to the Central Government
complaints received to him relating to the subject matter of inspection under
clause (i) and the details of action taken by him thereafter;
(iii) maintenance of record electroni-cally or otherwise of(a) children and adolescent found to be working in contravention of the Act
including children who are found to be engaged in family or family
enterprises in contravention of the Act;
(b) number and details of the offences compounded;
(c) details of compounding amount imposed and recovered; and
(d} details of rehabilitation services provided to children and adolescent
under the Act.".
10. In Form A appended to the Principal rules, in column heading of column 2, for the
words "Name of child", the words "Name of adolescent" shall be substituted.
11. After Form B appended to the Principal rules, the following Form shall be inserted,

namely:-

"FORM C
[See Rule 2C[b)]
Undertaking under Rule 2C(b) of the
Child Labour (Prohibition and Regulation) Rules, 1988

I ..................................................... Producer of ........................................ An

audio visual media production/organizer of
...................................................................... A commercial event, involving the
participation of the following child/children, namely:-

S.No.
Address

Name of the Child/

Parent' s/G u ard ian's

Children

Name

9

<!-- page 21 -->

do hereby undertake that in the course of the involvement of the above
mentioned

child/children

in

the

event

.......................................................................... {specify the event),
there shall be no violation of any provision of the Child and Adolescent Labour
(Prohibition and Regulation) Act, 1986 and Child and Adolescent Labour
(Prohibition & Regulation)Rules, 1988 and full care shall be taken of the physical
and mental health and other requirements of the child/children so that he/they
should not feel any inconvenience. I also undertake that during the event all laws
applicable for the time being in force for the protection of children, including their right
to education, care and protection, and legal provisions against sexual offences would be
complied.

Name and Signature".

Dated: ................... .

F.No ................. .

(.................... ·•···· -1
Joint Secretary to the Government of India
Note.- The principal rules were published in the Gazette of India extra-ordinary vide
G.S.R 847(E) dated 10.08.1988.

10

<!-- page 22 -->

SECRET
A-42025/0112016-CL
Govenunent Of India
Ministry of Labour and Employment

C138- Minimum Age Convention, 1973 (No. 138)
Convention concerning Minimum Age for Admission to Employment (Entry
into force: 19 Jun 1976) Adoption: Geneva, 58th ILC session (26 Jun 1973)Status: Up-to-date instrument (Fundamental Convention).
Preamble
The General Conference of the International Labour Organisation,

Having been convened at Geneva by the Governing Body of the International Labour Office, and having met in its Fiftyeighth Session on 6 June 1973, and

Having decided upon the adoption of certain proposals with regard to minimum age for admission to employment, which
is the fourth item on the agenda of the session, and

Noting the terms of the Minimum Age (Industry) Convention, 1919, the i\Tinimum Age (Sea) Convention, 1920, the
Minimum Age (Agriculture) Convention, 1921, the \I.Iinimum .Age (Trimmers and Stokers) Convention, 1921, the
Minimum Age (Non-Industrial Employment) Convention, 1932, the Minimum Age (Sea) Convention (Revised), 1936, the
Minimum Age (Industry) Convention (Revised), 1937, the Minimum Age (Non-Industrial Employment) COnvention
(Revised), 1937, the Minimum Age (Fishermen) Convention, 1959, and the Minimum Age (Underground Work)
Convention, 1965, and
Considering that the time bas come to establish a general instrument on the subject, which would gradually replace the
e;..:isting ones applicable to limited economic sectors, with a view to achieving the total abolition of child labour, and

Having detennined that these proposals shall take the form of an international Convention,
adopts this twenty-sixth day of June of the year one thousand nine hundred and seventy-three the following Convention,
which may be cited as the Minimum Age Convention, 1973:

Page 18 of 48

<!-- page 23 -->

SECRET
A-42025/01/20 16-CL
Government Of India
Ministry of Labour and Employment

A1·ticle 1
Each :"llcmbcr for which this Convention is in force undertakes to pursue a national policy designed to ensure the
effective abolition of child labour and to raise progress[yelythe minimum age for admission to employment or work to a
leYel consistent with the fullest physical and mental development of young persons.

Article 2
1. Each ?\.!ember which ratifies this Convention shall specify, in a declaration appended to its ratification, a minimum age

for admission to employment or work \~ithin its territory and on means of transport registered in its territory; subject to
Articles 4 to 8 of this Convention, no one under that age shall be admitted to employment or work in any occupation.
•

2. Each :\Iember which has ratified this Convention may subsequently notify the Director-General of the International

Labour Office, by fmther declarations, that it specifies a minimum age higher than that pre\1ously specified.
~

3. The minimum age specified in pursuance of paragraph 1 of this Article shall not be Jess than the age of completion of
compulsmy schooling and, in any case, shall not be less than 15 years.

•

4. :-:fohvithstanding the provisions of paragraph 3 of this Article, a Member whose economy and educational facilities are
insufficiently deYeloped may, after consultation with the organisations of employers and workers concerned, where such
exist, initially specify a minimum age of 14 years.

•

s. Each Member which has specified a minimum age of 14 years in pursuance of the provisions of the preceding
paragraph shall include in its reports on the application of this Convention submitted under article 22 of Lhe Constitution
of the International Labour Organisation a statement-(a) that its reason for doing so subsists; or
(b) that it renounces its right to avail itself of the provisions in question as from a stated date.

Article3
•

1. The minimum age for admission to any type of employment or work which by its nature or the circumstances in ·which

it is carried out is likely to jeopardise the health, safety or morals of young persons shall not be less than 18 years.

Page 19 of 48

<!-- page 24 -->

SECRET
A-42025/0 1/20 16-CL
Government Of India
Ministry of Labour and Employment
2. The types of employment or work to which paragraph 1 of this Article applies shall be determined by national laws or
regulations or by the competent authority, after consullation with the organisations of employers and workers concerned,
where such exist.

•

3- Notwithstanding the provisions of paragraph 1 of this Article, national laws or regulations or the competent authority
may, after consultation with the organisations of employers and workers concerned, where such exist, authorise
employment or work as from the age of 16 years on condition that the health, safety and morals of the young persons
concerned are fully protected and that the young pet·sons have received adequate specific instruction or vocational
training in the releYanl branch of activity.

Article 4
1. In so far as necessary, the competent authority, after consultation v.rith the organisations of employers and workers

concerned, where such exist, may exclude from the application of this Convention limited categories of cmplo}Tilent or
work in respect of which special and substantial problems of application arise.
2. Each Member which ratifies this Convention shall list in its first report on the application of the Convention submitted

under article 22 of the Constitution of the International Labour Organisation any categories which may have been
excluded in pursuance of paragraph 1 of this Article, giving the reasons for such exclusion, and shall slate in subsequent
reports the position of its law and practice in respect of the categories excluded and the e)l.ient to which effect has been
given or is proposed to be given to the Convention in respect of such categories.

•

3· Employment or work covered by Article 3 of this Convention shall not be excluded from the application of the
Convention in pursum1ce of this Article.

Article5
•

1. A :'IIember whose economy and administrative facilities are insufficiently developed may, after consultation with the

organisations of employers and workers concerned, where such exist, initially limit the scope of application of this
Convention.
•

-:?.. Each Member which avails itself of the pro\risions of paragraph 1 of this Article shall specify, in a declaration appended

to its ratiftcation, the branches of economic activity or types of undertakings to which it will apply the provisions of the
Convention.
•

3· The provisions of the Convention shall be applicable as a minimum to the follo\,ing: mining and quanying;
manufacturing; constmction; electricity, gas and water; sanitaty services; transport, storage and communication; and

Page 20 of 48

<!-- page 25 -->

SECRET
A-42025/01120 16-CL
Govemment 0 f India
Ministry of Labour and Employment
plantations and other agricultural undertakings mainly producing for commercial purposes, but excluding family and
small-scale holdings producing for local consumption and not regularly employing hired workers.

•

4. Any ?.!ember which has limited the scope of application of this Convention in pursuance of this Atticlc-~

•

(a) shall indicate in its reports under Arlide 22 of the Constitution of the International Labour Organisation the
general position as regards the employment or work of young persons and children in the branches of aclivity
which are excluded from the scope of application of this Convention and any progress which may have been made
towards wider application of the provisions of the Convention;
(b) may at any Lime formally extend the scope of application by a declaration addressed to the Director-Genera! of

the International Labour Office.

Article6
This Convention does not apply to work done by children and young persons in schools for general, vocational or
technical education or in other training institutions, or to work done by persons at leas\14 years of age in undertakings,
where such work is carried out in accordatlCe with conditions prescribed by the competent authority, after consultation
with the organisations of employers and workers concerned, where such exist, and is an integral part of-(a) a course of education or training for which a school or training institution is primarily responsible;
(b) a programme of training mainly or entirely in an undertaking, which programme has been approved by the
competent authority; or
•

(c) a programme of guidance or orientation designed to facilitate the choice of an occupation or of a line of training.

Article 7
•

1. National laws or regulations may permit the employment or work of persons 13 to 15 years of age on light work which

is-•

(a) not likely to be harmful to their health or development; and
(b) not such as to prejudice their attendance at school, their participation in vocational orientation or training
programmes approved by the competent authority or their capacity to benefit from the instruction received.

Page 21 of 48

<!-- page 26 -->

SECRET
A-42025/0 l/20 16-CL
Government Of India
Ministry of Labour and Employment

•

2. Kationallaws or regulations mny also pcm1i1 the employment or work of persons who are at leasll5 years of age but
ha\'e not yet completed their compulsOiy schooling on work which meets the requirements set fortl1 in sub~paragraphs
(a) and (b) of paragraph 1 of this Article.

•

3. The competent authority shaH determine the activities in which emplo}ment or work may be permitted under
paragraphs 1 and 2 of this Article and shall prescribe the number of hours during which and the conditions in which such
emplo}1nent or work may be undertaken.

•

4. Notwithstanding the provisions of paragraphs 1 and 2 of this Article, a Member which has availed itself of the
prodsions of paragraph 4 of Article 2 may, for as long as it continues to do so, substitute the ages 12 and 14 for the ages
13 and 15 in paragraph 1 and the age 14 for the age 15 in paragraph 2 of this Article.

Article 8
1. After consultation with the organisations of employers and workers concerned, where such e.;,:ist, the competent

authority may, by permits granted in individual cases, allow exceptions to the prohibition of employment or work
prO\ided for in Article 2 of this Convention, for such purposes as participation in artistic performances.
2. Permits so granted shall limit the number of hours during \\"hicll and prescribe the conditions in whicl.J employment or
work is allowed.

A1·ticle 9
•

1. All necessary measures, including the provision of appropliate penalties, shall be taken by the competent authority to
ensure the effective enforcement of the proYisions of this Convention.
2. Xational laws or regulations or the competent authority shall define the persons responsible for compliance with the
pro\isions giving effect to the Convention.
3· :National laws or regulations or the competent authority shall prescribe the registers or other documents which shall be
kept and made available by the employer; such registers or documents shall contain the names and ages or dates of birth,
dtLly certified wherever possible, of persons whom he employs or who work for him and who arc less than 18 years of age.

Article 1.0
•

1. This Convention revises, on the terms set forth in this Article, the Minimum Age {Industry) Convention, 1919, the

:_>,1inimum Age (Sea) Convention, 1920, the Minimum Age (Agriculture) Convention, 1921, the ;\-Iinimum Age (Trimmers
and Stokers) Convention, 1921, the Minimum Age {Non-Industrial Employment) Convention, 1932, the Minimum Age

Page 22 of 48

<!-- page 27 -->

SECRET
A-42025/0112016-CL
Government 0 f India
Ministry of Labour and Employment
(Sea) Convention (Revised), 1936, the Minimum Age {Ind11slry) Convention (Re\ised), 1937, the IVIinimum Age (NonIndustrial Employment) Convention (ReYised), 1937, the i\linimum Age (Fishermen) Convention, 1959, and the

Minimum Age (Underground Work) Convention, 1965.

•

2. The coming into force of this Convention. shall not close the ~Iinimum Age (Sea) Convention (Revised), 1936, the
Minimum Age (Industry) Convention (Revised), 1937, the Minimum Age (Non-Industrial Emplo}111Cnt) Convention
(Revised), 1937, the Minimum Age (Fishermen) Convention, 1959, or the :VIinimum Age (Underground Work)
ConYention, 1965, to further ratification.
3. 'l11e Minimum Age (Industry) Convention, 1919, the :Vlininmm Age (Sea) Convention, 1920, the Minimum Age
(Agriculture) Convention, 1921, and the Minimum Age (Trimmers and Stokers) Convention, 1921, shall be closed to
further ratification when all the parties thereto have consented to such closing by ratification of this Convention or by a
declaration communicated to the Director-General of the lnternational Labour Office.

•

4. \\'hen the obligations of this Convention are accepted-~

(a) by a :\!ember which is a party to the l\linimum Age (Industry) Convention (Revised), 1937, and a minimum age
of not less than 15 years is specified in pursuance of Article 2 of this Convention, this shall ipso jure involve the
immediate denunciation of that Convention,

•

{b) in respect of non-industrial employment as defined in the Minimumr\ge (Non-Industrial Employment)
Convention, 1932, by a i>Jembcr which is a party to that Convention, this shall ipso jure involve the immediate
denunciation of that Convention,

•

(c) in respect of non-industrial employment as defined in the Minimum Age (Non-Industrial Employment)
Convention {Revised), 1937, by a Member which is a party to that Convention, and a minimum age of not less than
15 years is specified in pursuance of Article 2 of this Convention, this shall ipso jure involve the immediate
denunciation of that Convention,

•

(d) in respect of maritime employment, by a Member which is a party to the Minimum Age (Sea) Convention
(Revised), 193 6, and n minimum age of not less than 15 years is specified in pursuance of Article 2 of this
Convention or the Member specifies that Article 3 of this Com·ention applies to maritime employment, this shall
ipso jure involve the immediate denunciation of that Convention,

Page 23 of 48

<!-- page 28 -->

SECRET
A-42025/0 l/20 16-CL
Government 0 f India
Ministry of Labour and Employment

•

(e) in respect of employment in maritime fishing, by a ~!ember which is a pmty to the Minimum Age (Fishermen)
Convention, 1959, and a minimum age of not less than 15 years is specified in pursuance of Article 2 of this
Convention or the Member specifics thatAJticle 3 of this Convention applies to emplo:y1nent in maritime fishing,
this shall ipso jure involve the immediate denunciation of that Convention,

•

CO by a :-v1cmber which is a party to the lvlinimum Age (Underground \York) Convention, 1965, and a minimum age
of not less than the age specified in pursuance of that Convention is specified in pursuance of .Article 2 of this
Convention or the Member specifies that such an age applies to employment underground in mines in virtue of
Article 3 of this Convention, this shall ipso jure involve the immediate denunciation of that Convention,

if and when this Convention shall have come into force.

•

s. Acceptance of the obligations of this Convention-•

(a) shall involve the denunciation of the Minimum Age {Industry) Convention, 1919, in accordance with Article 12
thereof,

•

(b) in respect of agriculture shall involve the denunciation of the Minimum Age (Agriculture) Convention, 1921, in
accordance vvith ~'l.lticle 9 thereof,

•

(c) in respect of maritime employment shall involve the denunciation of the Minimum Age (Sea) Convention, 1920,
in accordance with Article 10 thereof, and ofthe Minimum Age (Trimmers and Stokers) Convention, 1921, in
accordance with Article 12 thereof,

if and when this Convention shall ha\·c come into force.

A1•ticle 11
The formal ratifications of this Convention shall be communicated to tbe Director-General of the International Labour
Office for registration.

Al'ticle 12
~

1. This Convention shall be binding only upon those Members of the International Labour Organisation whose
ratifications haYe been registered with the Director-General.

•

2. It shall come into force twelve months after the date on which the ratifications of two Members have been registered
with the Director-General.

Page 24 of 48

<!-- page 29 -->

SECRET
A-42025/01120 16-CL
Government Of India
Ministry of Labour and Employment
3· Thereafter, this Convention shall come into force for any Member twelve months after the date on which its
ratifications has been registered.

A1•ticle 13

•

1. A Member which has ratified this Convention may denounce it after the expiration of ten years from the date on which

the Convention first comes into force, by an act communicated to the Director-General of the International Labour Office
for registration. Such denunciation shall not take effect until one year after the date on which it is registered.

•

2. Each 1Iember which has ratified this Convention and which does not, within the year following the expiration of the
period of ten years mentioned in the preceding paragraph, exercise the right of denunciation provided for in this Article,
will be bound for another period of ten years and, thereafter, may denounce this Convention at the expiration of each
period of ten years under the terms provided for in this Article.

Article 14
•

1. The Director-General of the International L1b0ltr Office shall notify all Members of the International Labour

Organisation of the registration of all ratifications and denunciations communicated to him by the i\Iembers of the
Organisation.
~

2. '\\'hen notifying the :Members of the Organisation of the registration of the second ratificalion communicated to him,
the Director-Geneml shall draw the attention of the Members of the Organisation to the date upon which the Convention
will come into force.

Article 15
The Director-General of the International Labour Office sball communicate to the Secretary-General of the United
Nations for registration in aecordance v.ith Article 102 of the Charter of the United Nations full particulars of all
ratifications and aels of denunciation registered by him in accordance with the provisions of the preceding Articles.

Article 16
Al such times as it may consider necessary the Go\·erning Body of the International Labour Office shall present to the
General Conference a report on the working of this Convention and shall examine the desit·ability of placing on the
agenda ofthe Conference the question of its revision in whole ot· in part.

Article 17
•

1. Should the Conference adopt a new COJl\'ention revising this Convention in whole or in part, then, unless the new

Convention otherwise provides:

Page 25 of 48

<!-- page 30 -->

SECRET

A-42025/01/2016-CL
Govemment Of India
Ministry of Labour and Employment
•

(a) the ratification by a :\Icmber of the new revising Convention shall ipso jure involve the immediate denunciation
of this Conwntion, notwithstanding the proYisions of Article 13 above, if and when the new revising Convention
shall have come into force;

•

(b) as from the date whc11 the new revising Convention comes into force this Convention shall cease to be open to
ratification by the ;,\Iembers.

2. This Convention shall in any case remain in force in its actual fonn and content for those i\Iembers which have ratified

it but have not ratified the revising Convention.

Article :18
The English and French versions of the text of this Conwntion arc equally authoritatiYe.

Page 26 of 48

<!-- page 31 -->

SECRET
A-42025/01/2016-CL
Government Of India
Ministry of Labour and Employment

ANNEXURE III

C182 -Worst Forms of Child Labour Convention, 1999
(No. 182)
Convention concerning the Prohibition and Immediate
Action for the Elimination of the Worst Forms of Child
Labour (Entry into force: 19 Nov 2000)Adoption: Geneva,
87th ILC session (17 Jun 1999)
Status: Up-to-date
instrument (Fundamental Convention).
Preamble
'11le General Conference of the International Labour Orgailization,

Having been convened at Geneva by the Governing Body of the International Labour Office, and having met in its 87th
Session on 1 June 1999, and

Considering the need to adopt new instruments for the prohibition and elimination of the worst forms of child labour, as

the main priority for national and international action, including international cooperation and assistance, to
complement the Convention and the Recommendation concerning Minimum Age for Admission to Employment, 1973,
which remain hmdamcntal instruments on child labour, and

Considering that the effective elimination ofthe worst forms of child labour requires immediate a11d comprehensive
action, taking into account the importance of free basic education and the need to remove the children concerned from
all such work and to pt·ovide for their rehabilitation and social integration while addressing the needs of their families,
and
Recalling the resolution concerning the elimination of child labour adopted by the International Labour Conference at its
83rd Session in 1996, and
Recognizing that child labour is to a great eJ..i:ent caused by poverty and Lhat the long-tenn solution lies in Sustained
economic growth leading to social progress, in pmiicular poverty alleviation and universal education, and

Page 27 of 48

<!-- page 32 -->

SECRET
A-42025/0 1/20 16-CL
Government Of India
Ministry of Labour and Employment
Recalling Lhe Convention on the Rights of the Child adopted by the United Nations General Assembly on 2.0 November
1989, and

Recalling the ILO Declaration on Fundamental Principles and Rights at Work and its Follow-up, adopted by the
International Labour Conference at its 86th Session in 1998, and

Recalling that some o[ the worst forms of child labour are covered by other international instruments, in particular the
Forced Labour Convention, 1930, and the United Nations-Sttpplementary Convention on the Abolition of Slavery, the
Slave Trade, and Institutions and Practices Similar to Slavery, 1956, and

Having decided upon the adoption of certain proposals with regard to child labour, which is the fourth item ou the
agenda of the session, and

Having determined that these proposals shall lake the form of an international Convention;

adopts this seventeenth day of June of the year one thousand nine hundred and ninety-nine the follmving Convention,
which may be cited as the 'i\'orst Forms of Child Labour Convention, 1999.

Article 1
Each :\!ember which ratifies this Convention shall take immediate and effective measures to secure the prohibition and
elimination of the worst forms of child labour as a matter of urgency.

Article 2
For the purposes of this Convention, the term child shall apply to all persons under the age of18.

Article 3
For the purposes of this Convention, the term the worst forms of child labour comprises:

•

(a) all forms of slavetyor practices similar to s\avety, such as the sale and trafficking of children, debt bondage and
sctfdom and forced or compulsory labour, including forced or compu!sol)' recmitment of children for use in armed
con!1ict;

•

(b) the use, procuring or offering of a child for prost ltution, for the production of pornography or for pornographic
pelfonnances;

Page 28 of 48

<!-- page 33 -->

SECRET
A-42025/01120 16-CL
Govemment Of India
Ministry of Labour and Employment
(c) the use, procuring or offering of a child for illicit activities, in particular for the production and trafficking of

drugs as defined in the relevant international treaties;

•

(d) work which, by its nature or the circumstances in which it is carried out, is likely to harm the health, safely or
morals of children.

Article4
1. The types of work referred to under Article 3(d) shall be determined by national laws or regulations or by the

competent authority, after consultation with the organizations of employers and workers concerned, taking into
consideration relevant international standards, in particular Paragraphs 3 and 4 ofthe ·worst Forms of Child Labour
Recommendation, 1999.

•

2. The competent authority, after consultation with the organizations of employers and workers concerned, shall identify
where the types of work so determined exist.

•

3. The list of the types of work determined under paragraph 1 of this Article shall be periodically examined and revised as
necessary, in consullation with the organizations of employers a11d workers concerned.

Articles
Each :\!ember shall, after consultation with employers' an-d workers' organizations, establish or designate appropriate
mecl1anisms to monitor the implementation of the provisions giving effect to this Convention.

Article 6

•

1. Each ?\-!ember shall design and implement programmes of action to eliminate as a priority the worst forms of child

labour.
•

2. Such programmes of action shall be designed and implemented in consultation with relevant government institutions
and employers' and workers' organizations, taking into consideration the views of other concerned groups as appropriate.

Article 7
•

1. Each ;'.Iember shall take allnecessaJ}' measures to ensm·e the effective implementation and enforcement of the

provisions giving effect to this Convention including the provision and application of penal sanctions or, as appropriate,
other sanctions.
•

2. Each Member shall, taking into account the importance of education in eliminating child labom·, take effective and
time-bound measures to:

Page 29 of 48

<!-- page 34 -->

SECRET
AA2025/0l/2016-CL
Government Of India
Ministry of LabDur and Employment
•

(a) prevent the engagement of children in the worst forms of child labour;
(b) provide the necessary and approp1iate direct assistance for the removal of children from the worst forms of
child labour and [or their rehabilitation and social integration;

•

(c) ensure access to free basic education, and, wherever possible and appropriate, vocational training, for all
children removed from the worst forms of child labour;

•

•

(d) identify and reach out to children at special risk; and

•

(e) take account of the special situation of girls.

3. Each ;v!ember shall designate the competent authority responsible for the implementation of the provisions giving
effect to this Convention.

Article 8
Members shall take appropriate steps to assist one another in giving effect to the provisions of this Convention through
enhanced international cooperation andjor assistance including suppott for social and economic development, poverty
eradication programmes and uniwrsal education.

Article 9
The formal ratifications of this Convention shall be communicated to the Director-General of the International Ltbour
Office for registration.

Article 10
•

1. This Convention shall be binding only upon those Members of the International Labour Organization whose

ratifications have been registered with the Director-General of the International Labour Office.
2. It shall come into force 12 months after the date on which the ratifications of two Members ha\'C been registered with
the Director-General.
•

3. Thereafter, this Convention shall come into force for any Member 12 months after the date on which its ratification has
been registered.

Article 11

Page 30 of48

<!-- page 35 -->

SECRET
A-42025/0 l/20 16-CL
Govemment Of India
Ministry of Labour and Employment

•

1. A l\Iember which has ratified this Convention may denounce it after the expiration of ten years from the date on which
the Convention first comes into force, by an act communicated to the Director-General ofthe International Labour Office
for registration. Such denunciation shall not take effect until one year arter the date on which it is registered.

•

2. Each Member ·which has ratified this Convention and which does not, within the year following the expiration of the

period of ten years mentioned in the preceding paragraph, exercise the right of denunciation provided for in this Article,

will be bound for another period of ten years and, thereafter, may denounce this ConYention at the expiration of each
period often years under the terms provided for in this At·ticle.

Article 12
•

1. The Director-General of the International Labour Office shall notify alll\Iembers of the International Ltbour
Organization of the registration of all ratifications and acts of denunciation communicated by the Members of the
Organization.

•

2. When notifying the Members of the Organization of the registration of the second ratification, the Director-General
shall draw the attention of the Members of the Organization to the date upon which the ConYention shall come into force.

A1•ticle 13
111e Director-General of the International Labour Office shall communicate to the Secretal)·-Gcneral ofthe United
Nations, for registration in accordance with article 102 of the Charter of the United Nations, full particulars of al1
ratifications ami acts of denunciation registered by the Director-General in accordance with the provisions of the
preceding Articles.

Article 14
At such times as it may consider necessary, the Governing Body of the International Labour Office shall present to the
General Conference a report on the working of this Convention and shall examine the desirability of placing on the
agenda of the Conference the question of its revision in whole or in part.

Article 15
1. Should the Conference adopt a new Convention reYising_ this Convention in whole or in part, then, unless the new

Convention otherwise provides-•

(a) the ratification by a ;-.Icmber of the new revising Convention shall ipso jure involve the immediate denunciation
of this Convention, notwithstanding the provisions of Article 11 above, if and when the new revising Convention
shall have come into force;

Page 31 of 48

<!-- page 36 -->

SECRET
A-42025/01/20 16-CL
Government Of' India
Ministry of Labour and Employment

•

(b) as from the date when the new revising Convent-ion comes into force, this Conventio11 shall c~ase to be open to
ratification by the Members.

•

2. This Convention shaH in any case remain in force in its aclllal form and content for those Members which have ratified
il but have not ratified the revising Convention.

Article 16
The English and French versions of the text of this Convention are equally authoritative.

Page 32 of 48
