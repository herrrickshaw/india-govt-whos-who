---
doc_id: "de32ca25ba18ee7d"
source_url: "https://mohua.gov.in/static/uploads/2025/11/8156b6e7a6b2512f2f03b0c73d800baf.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Rajghat Samadhi Rules, 1952"
date: "1952-06-05"
pages: 18
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "070404ae48926055"
---

<!-- page 1 -->

|
RAJGHAT SAMADHI RULES, 1952 |
(Approved by the Government of India in the Minis- ~~ |
try of Works, Production & Supply letter No. 3554-
WI/52 dated 5th June, 1952)
“Creation of Samadhi Fund :
Ne (1) There shall be formed a fund to be called the Sa-
madhi Fund, and there shall be placed at the credit
thereof all sums received by the Commettee as
donations and grants or on any other account ap-
- proved by the Government of India.
(2) The Samadhi Fund shall be vested in the Commit-
: tee and balance standing at the credit of the Fund
shall be kept in such custody as the Committee
may, with the approval of the Government of india,
from time to time decide.
Objects to the Samadhi Fund may be applied
2: The Samadhi Fund shall be applicable to the follow- |
ing objects : - 2
है (1) To payments for the maintenance or repair or ent
bellishment of the Samadhi;
(2) To the payment of the saleries and allowances of
the establishment employed by the Committee for |
- , the purposes of the Act; [m.o.v.d. notification no.
'25011/2/83-103 dated 5.3.1987) |
(3) to the payment of the cost of audit of the Samadhi
Fund : z |
|
(4) to the payment of any other expense incurred by |
the Committee in carrying out the provisions of the |
Act; and
7 : |
|

<!-- page 2 -->

(5) to any object which may be declared by the Cont
mittee with the concurrence of the Government of
India, to be an object to which the Samadhi Fund
i may be applicable. :
Buy The annual budget shall be prepared by the Secre-
“ tary of the Committee and shall be placed at a
meeting of the Committee in the month of January
each year. A copy of the approved budget shall
within ten days of the Committee’s resolution be
sent to the Chief Commissioner who will have power
‘en to issue directions in respect of the budget.
Audit of accounts and annual report
4. (1) — The accounts of the Samadhi shall be audited every
year by the Comptroller and Auditor General of
India [m.o.U.D. notification no. 25014/2/72-w3 dated
: : 21.11.1974]
(2) The Committee shall publish an annual report on
के the Administration of the Samadhi with a financial
estimates and the report of the auditor.
Power Over funds |
- 5. (1) The Secretary of the Committee shall have powers
to sanction petty expenditure not exceeding Rs.
= 5000/= (Rupees five Thousand) in any one finan-
cial year. Any expenditure exceeding R. 5000/=
shall require the prior approval of the Committee.
: (2) The Chairman of the Committee shall have powers
to sanction an emergent expenditure exceeding
Rs. 5000/= on any approved object in anticipation
of the sanction of the Committee, but such an ex-
penditure shall be reported to the next meeting of
the Committee. हे
[M.o.u.D. notification no. 25012/1/79-w3 dated
3.3,1987 ४
Appointment of a Secretary : हि
6. The Committee shall exercise its power of admini-
stration, control and management of the Samadhi
8

<!-- page 3 -->

] .

| न
through a Secretary appointed by itself.
[M.o.u.D. notification no. 25011/2/83w3 dated
5.3.1987] ;

Access to the Samadhi

| qe (1) Subject to such rules, restrictiéns and levy of charges
as may be prescribed by the Committee from time
to time, the public shall have a right of access to
the Samadhi.

(2) The Committee may prohibit the entry of visitors to
the whole or part of the Samadhi premises for a
temporary period.

(3) The Committee may authorise the Secretary care-
taker or any other employee to expel out of Sa-
madhi premises any person found violating any rules

= or directons laid down for observance by the visi
tors and if necessary reasonable force may be
used for carrying out the said purpose.
[m.o.u.d. notification no. 25011/2/83-W3 dated
5.3.1987]
(4) Such rules or directions may relate to the taking
हा out of shoes and the washing of hands before en-
tering the enclosure where Mahatma Gandhi was
- cremated, the plucking of flowers, the use of foun-
tain water for drinking or other allied purposes, the
spoiling of grassy plots, trees, furniture, building or
other valuables within the premises of the Samadhi.
(5) The Committee may due provision for the protec-
: tion of the Samadhi from pollution or desecration.
Custody and use of the common seal
8. The Common seal of the Committee shall remain in
the custody of the Secretary and shall be affixed
to all agreements, contracts notices and other al
lied instruments made and executed in the name
of the Committee.
2

<!-- page 4 -->

Rajgaht Samadhi—Revised Bye Laws 1994
approved by the Govt. of India M.o.u.D. Vide letter no. 20512/
1/88-w3 the 7th July, 94
PART—A
_ PRELIMINARY

le Short title and commencement : (1) These Bye-
laws may be called the Rajghat Samadhi Commit-
tee Bye-Laws, 1993.

(2) They Shall come into force on the date of their
publication in the Gazette of India.

a Application : These Bye-Laws shall apply in all mat-
ters of Administrative and Financial Management of
the Committee and to every employee of the Cont
mittee.

3: Definitions : In these Bye-Laws, unless the context
otherwise requires.

: (a) “Appointing Authority” in relation to any post,
means the authority competent to make appoint-
ment to that post;

= (b) “Chairman” means the Chairman of the Commit-
९6;
हे (c) “Committee” means the Rajghat Samadhi Com-

mittee constituted under the Rajghat Samadhi Act,

: 1951 (41 of 1951);
(d) “employee” means any person serving the Com
mittee in any post specified in the Recruitment
Rules for the posts concerned;

10

<!-- page 5 -->

(e) “Secretary” means the Secretary of the Com
mittee.
-PART—I
FUNCTIONING OF THE COMMITTEE
3 Meeting of the Committee : (1) The Chairman shall
convene a meeting of the Committee atleast once
in four months.
(2) The Chairman may, on the receipt of a requisti
tion of any three members, convene a meeting of
the Committee. Z
Time and Place of Meetings : The time and place
of all the meetings shall be fixed by the Chairman.
Notice of Meeting : (1) A written notice for every
. meeting shall be sent or circulated to every men
ber atleast two days before the scheduled date.
* (2) The notice shall’ state the place, the date and
the time of the meeting and shall specify the- busi
क्र ness to be transacted thereat. a |
(3) No business, which is not on the agenda, shall
be considered at the meeting without the permis-
sion of the Chairman.
Procedure for bringing matters before the Commit-
teers
Any member wishing to bring any matter before
the Committee shall send his proposal to the Sec- |
retary who shall submit it to the Chairman for 0-- |
ders. The Chairman shall refer the proposal to the |
Committee, but, in special case, in which he con-
siders reference of the proposal to the Committee
: LL के
|

<!-- page 6 -->

के is inexpedient or unnecessary, he may, for rea-
sons to be recorded in writing, refuse§to do so and
after such refusal the matter shall be deemed to
be dropped.
ee Secs Quorum : Three members shall form the quorum
for a meeting.
9. Chairman to preside at meeting : The. Chairman
shall. preside at every meeting of the Committee.
In his absence, the members present may elect
any other member as Chariman and, thereupon,
the business of the meeting shall be transacted
under the Chairmanship of the member so elected.
LO: Decision by majority : All- questions and matters
before the Committee at a meeting shall be de-
cided by a majority of votes of the memebrs pres-
| ent. In case of equality of votes, the Chairman of
the meeting shall have a second or casting vote.
11. Same question not to be brought before Commit-
tee until after lapse of three months : Any question
decided by a resolution of the Committee shall not
again be brought ‘for consideration until after a
lapse of three months from the date of the resolu-
tion. Provided that the Chariman may,°for sufficient
reasons, allow any such question to be brought
before the Committee at any time. a
12: Minutes : The minutes of the proceedings of every
meeting of the Committee shall be recorded in a
book under the signature of the Secretary. The
minutes shall also be signed by the Chairman at
the next meeting after the same are confirmed.
ig: Receipts for money : A receipt shall be issued for
-any money received by or on behalf of the Commit.
tee, by the Secretary or by his subordinate, if he is
authorised by the Secretary to do so, in terms of
rule 82-of the Central Treasury Rules. ‘
a

<!-- page 7 -->

| .
| >
14. Annual Report 7: The Committee shall publish an
2 Annual Report on-the administration of the Samadhi
| together with a financial statement and the report
| * of the Auditor. : 5
PART—l ;
ESTABLISHMENT :
1D: Secretary : (1) The Committee shall appoint a per-
son as a parttime Secretary to assist it in the
efficient performance of its duties assigned under
section 5 of the Rajghat Samadhi Act, 1951 (41 of
1951). ae
(2) The Secretary so appointed shall perform such
duties as may be entrusted to him by the Commit-
tee. =
(3) The Secretary shall be paid such allowances,
as the Committee may decide from time to time.
16. Other Staff : (1) Any other post needed for the
office of the Committee, equivalent to the posts in
x Group ‘C’ and ‘D’ in the Central Government Of-
fices, may be created on the orders of the Com
mittee and the Chairman and the Secretary re-
spectively shall be the appointing authorities for
these posts. 3
(2) ,The creation of posts equivalent to Group ‘A’
and| ‘B’ in the office of the Committee shall be
approved by the Ministry of Urban Development as
per the provisions of the Delegation of Financial
Power Rules, 1978, and appointments there to be
made as per the Central Civil Services (Classifica-
tion, control and Appeal) Rules, 1965. 5
13 |
|

<!-- page 8 -->

\

(3) In. respect of any matter not specifically pro
vided in these Byelaws regarding general condi

tions of service, pay and allowances, leave salav,
joining time, the provisions of the Fundamental Rul=

the Supplementary Rules and the orders and Gev

. sions applicable to the Central Government ser

vants shall apply, mutatis mutandis to the empioy
ees of the Committee.

17. Posts and pay Scales : The Committee may '.:.
the following posts in the scale of pay noted ays
each :..

a मन कक9+ नमक + कम न ++७+_ मन --“ पलक “पर र

S.No. Posts Scale of Pay No. of pests

श्र :

Group C हे

(i) | Sanrakshak Rs. 1400-40-1600-50-2300 1
EB-60-2600
(i) | Sahayak Rs. 1200-30-1560-£B-40-2040 1
5 Sanrakshak

(ii) Clerk-cum Rs. 950-20-1150-EB-25-1500 1

General Assistant हि

; Group D
(iv) Jamedar Rs. 775-10-965-EB-12-1025 a
(v) Chowkidar Rs. 750-8-790-EB-10-940 25
(vi) Peon : Rs. 750-8-790-EB-10-940 a
\viil) Safai Sewak Rs. 750-8-790-EB-10-940 7

a ee न ++-_ननअमओन मनन नन-न नतनण-सपर नकल

18. Age limits : The minimum and maximum age for ap-
pointment to. posts mentioned in regulation 17 shall
be as laid down in Government orders for corre-
sponding posts in the Central Government except
for the post of Secretary, for whom the lower age
limit shall be 21 years and the upper age limit shall

be 50 year.
14

<!-- page 9 -->

19. Qualifications : (1) The Sanrakshak shall be a gradu-
ate and preference shall be given to a person hold-
ing the Degree of Master of Arts. He shall be well |
versed in Gandhian concepts and ideoligies and
possess administrative capacity.
(2) Sahayak Sanrakshak shall be a Graduate and
shall possess the knowledge of Gandhian concepts.
(3) Clerk-cur+General Assistant shall be atleast a
| Matriculate with fair knowledge of typing and book
= keeping.
| (4) Jamedar, Chowkidar and Peons shall be atleast
| middle School pass. Knowledge of cycling is desir-
able.
(5) Safai sewak shall have elementary knowledge |
of reading, writing and arithmetic. .
(6) In case of the Scheduled Caste or the Sched-
uled Tribe candidates qualifications may be relaxed, |
in accordance with the orders issued by the Cen-
tral Government from time to time in this regard.
20. Appointing. Authority : (1) The Secretary shall be
= the appointing authority in respect of posts of Jame-
dars chowkidars, Peons and Safai sewak.
(2) The Chairman shall be the appointing authority
in respect of posts of Sanrakshak, Sahayak.
Sanrakshak and clerk-cumGeneral Assistant or any
: other full time or part time staff.
el. Recruitment : (1) Recruitment to a post under the
Committee shall be made as per the provisions of
the Employment Exchange (Compulsory Notification
of Vacancies), Act, 1959), (31 of 1959) and in ac-
cordance with such rules and orders for the reser-
vation of vacancies for the Scheduled Castes and
Scheduled Tribes, as have been or may be issued
15 |
|
|
|
1

<!-- page 10 -->

by. the .Central Government from time-to-time by |
adopting any of the following methods namely :
(a) by direct recruitment;
(b) by promotion; =
(c) by appointment on deputation basis from other
Central or State Government Departments; or
(d) on contract for a specified period.
223 Appointment. Probation and Confirmation : :
(1) Medical Examination on first appointment : Can-
didates selected for appointment in the Committee
shall be required to undergo a medical examination
by a Medical Authority as may be specified by the
Committee.
(2) Probation : On initial appointment, either by
direct recruitment or by Promotion to a higher cat-
egary of post, an employee other than the Secre-
tary shall be placed on Probation for a period of
two. years which may be extended by the Appoint
’ ing Authority, if necessary. g
: 3) Confirmation : After satisfactory completion of
the period of probation an employee may be con-
firmed in the establishment of the Committee.
PART—IV ६
DUTIES AND CODE OF CONDUCT
23: Duties of the Employees : The Secretary and other
employees of the Committee shall exercise such ,
powers and perform such duties as the Committee
may, from time-to-time assign to them.
16 i
