---
doc_id: "dd2e113a39babdcc"
source_url: "https://mohua.gov.in/static/uploads/2025/10/5c59705dae5264e1eb18977e8d9651ff.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "MP CSP Presentation"
date: "2025-10-15"
pages: 32
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ea216f46ff8fba1d"
---

<!-- page 1 -->

CITY

SANITATION
PLAN

For Raisen , Ashta and
Khajurao Towns in MP

ULB’s

<!-- page 2 -->

C O M P A N Y

P R O F I L E - (CEMDS)

CENTRE FOR ENVIRONMENTAL MANAGEMENT & DECISION SUPPORT
Head Office:
Gregor Mendel Strasse
33,
1180 Vienna



Set up as a non-for-profit association under Austrian
law in 2004



Network of National and International Partners and
experts.



Active in India since 2005

AUSTRIA

India Liaison Office:
Mumbai / Pune

ULB’s

<!-- page 3 -->

Phasing of C S P
Phase I

KEY STAGES

Establishing Baseline
Technical Situation Analysis
Demand Supply Assessment
Future projections
Waste management options
Strategies for sanitation management
Phasing and
Providing a platform for piloting

Phase II
KEY STAGES

Technical Assistance for developing infrastructure
Developing Strategies for Awareness generation and
Capacity building
ULB’s

<!-- page 4 -->

C S P
Key Agencies
Government of
Madhya Pradesh
Urban Local Bodies

City Ashta
District Sehore
Population 35,702 (census 2001)
Area 1538 ha.
Number of Wards 18
City Khajuraho
District Chhatarpur
Population 19,285 (census 2001)

Supporting Agency

Area 59 sq.km.
Number of Wards 15

Water aid

Technical Support
CEMDS

City Raisen
District Raisen
Population 19,285 (census 2001)
Area 19 sq.km.
Number of Wards 18

ULB’s

<!-- page 5 -->

Methodology
Policy Objectives

Cross sectoral study of-

Strategies

Affordability and willingness to pay
Eradication of open
defecation

100% HOUSEHOLD
SANITATION
FACILITY

Cost effective solutions
O& M
Awareness generation

Safe disposal of
solid and liquid
waste

Suitable
Technological
Options

Capacity Building
Financial models
Institutional set up

Sustainable
Approach towards
O& M

Resource
mobilization and
reforms

Human Resource management
Community Participation

ULB’s

<!-- page 6 -->

Cluster Approach
Need for Clustering

Outcome of Reconnaissance survey highlighted similarities in
following aspects which formed basis of clusteringAvailability and status of Infrastructure
Socio economic profile
Urban Sprawl & Density Pattern
Housing Typology
Topographical features
It helped to establish a uniform base for study
• Ease in data assessment and analysis of the issues
• Strategies were more specific and contextual
• Ease in implementation and phasing
•

ULB’s

<!-- page 7 -->

F O C U S

A R E A S

of

C S P

HOUSEHOLD SANITATION

EXISTING SEWERAGE

SURFACE DRAINS

SWM PRACTICES

WATER SUPPLY

ULB’s

<!-- page 8 -->

Issues Addressed Through C S P
HOUSEHOLD SANITATION

Access to sanitation infrastructure
Factors responsible for open
defecation
Effect of open defecation on
health , hygiene and environment

Service level benchmarking
Demand gap and future needs

Technological options
EXISTING SEWERAGE

SWM PRACTICES
SURFACE DRAINS
WATER SUPPLY
ULB’s

<!-- page 9 -->

Issues Addressed Through C S P
HOUSEHOLD SANITATION
EXISTING SEWERAGE SYSTEM

Coverage and status of system
Efficiency existing of network
Issues in conveyance and treatment
Service level benchmarking

Strategies for future
Issues related to Health , Hygiene
and Urban environment
SWM PRACTICES
SURFACE DRAINS
WATER SUPPLY

ULB’s

<!-- page 10 -->

Issues Addressed Through C S P
HOUSEHOLD SANITATION

EXISTING SEWERAGE SYSTEM
SURFACE DRAINS
Coverage and status of system

Efficiency existing of network
Issues in conveyance and treatment
Water logging areas
Strategies for future
SWM PRACTICES

WATER SUPPLY

ULB’s

<!-- page 11 -->

Issues Addressed Through C S P
HOUSEHOLD SANITATION

EXISTING SEWERAGE SYSTEM
SURFACE DRAINS
SWM PRACTICES
Current practices of SWM

Existing infrastructure
Factors affecting Open dumping

Generation of waste in future
Service level benchmarking
Involvement of community
Awareness generation
Technological options
WATER SUPPLY
ULB’s

<!-- page 12 -->

Issues Addressed Through C S P
HOUSEHOLD SANITATION

EXISTING SEWERAGE SYSTEM
SURFACE DRAINS
SWM PRACTICES

WATER SUPPLY
Access to water supply
Quality and Quantity of supply
Demand supply gap
Future projections

Service level benchmarking
Effect of water quality on health

ULB’s

<!-- page 13 -->

After identifying the sectors for detail study and
finalizing the indicators and parameters,
following activities were enlisted with detail tasks

ULB’s

<!-- page 14 -->

Activity

L i s t i n g for CSP

(PHASE I)

Baseline study
& Database
Creation
Sanitation
Infrastructure
Assessments

Demand Supply
Gap Analysis

Identifying key
issues & Future
projections

Activity 1

General Baseline study and generation of digital
maps

Activity 2

Technical Situation analysis and inception report

Activity 3

Stakeholder engagement, awareness raising and
communication strategy

Activity 4

Waste management options

Activity 5

Financing plans and Institutional capacity

Activity 6

Draft City Sanitation Plan summarizing all
previous results

Activity 7

Participatory Planning

Activity 8

Final city sanitation plan

Waste
management
Options

ULB’s

<!-- page 15 -->

Activity 1

Baseline Study
Identifying upstream and downstream issues relevant for
with an emphasis on the water resources
Mapping existing institutional situation for managing
solid and liquid waste, data for Waste generation, socioeconomic conditions of housing and slum areas
Mapping important issues for urban planning (e.g future
development plans, Heritage and Tourism especially for
Khajuraho as it is a world heritage Site);
Mapping existing data for environmental status (hygienic
and environmental conditions, water supply, water
resources, main polluters, etc.)

ULB’s

<!-- page 16 -->

Activity 2

Technical Situation Analysis
Assessment of existing sanitation practices and available
infrastructure with focus on –
# Access to infrastructure
# Coverage of infrastructure network

# Efficiency
# O&M

# Generation of waste

For
Household water and sanitation
Surface drains and existing sewerage
Solid waste management practices
Identifying key issues/ problems/ gaps or loopholes in the
service levels

ULB’s

<!-- page 17 -->

Activity 3

Stakeholders’ Engagement

• Stakeholder survey (Identifying various
target groups and beneficiary groups).
• Setting up stakeholder groups for targeted
involvement in development of the CSP and
interaction strategies.
• Informing stakeholders about the results of
the baseline study and situation analysis
• Selected ULB representatives from the e
respective cities participated in an exposure
visit to Pune, Mahabaleshwar, Nasik.
ULB’s

<!-- page 18 -->

Activity 4

Waste management options

• Estimation of Future generation of solid and
liquid waste volumes
• Outline design and feasibility study of
different options to meet future requirements

• Outline assessment of costs of each option

ULB’s

<!-- page 19 -->

Activity 5

Activity 6

F i n a n c i n g p l a ns a n d
Institut ional capac Ity

•

Surveys on affordability, willingness to pay and
preferences among future users

•

Developing financing mechanisms that allow an extension
of the sanitation coverage

•

Assessment of realistic institutional capacity for
managing the various options

Draft City Sanitation Plan

•

Summarizing results of technical analysis and
Affordability surveys

•

Waste management options with indicative costs

•

Outlining various strategies and develop Phasing plan
ULB’s

<!-- page 20 -->

Activity 7

Activity 8

Participatory

Plann ing

•

Elaborating Advantages and disadvantages of various
waste management options to stakeholders in view of
existing constraints and opportunities

•

Participatory assessment and selection of preferred
options

Final City Sani tat ion

Plan

•

Budget Estimation of Preferred options

•

O&M and financial models for sanitation management

•

Strategies for IEC , Monitoring and Evaluation

•

Way forward and Road Map for Pilot Project
ULB’s

<!-- page 21 -->

Role of G I S

Preparing base map
C
Data base generation
C
Spatial representation of existing data
C
Preparing Thematic and Analytical maps
C
Comparative study through spatial data
representation
C
Developing ICT tools
C

ULB’s

<!-- page 22 -->

Information & Communication
T e c h n o l o g y (ICT)

I C T TOOLS

SALIENT FEATURES

SAMS
•

Ease in decision making - SAMS web based Sanitation
Amenities Management System with online GIS and CSP
data .

•

GIS based tool for planning and management purpose :
Participatory mapping through mapper in local language.

•

Transparency in Monitoring and Evaluation through mobile
capturing of key data with photo and lat longs.

MAPPER
MOBILE APPLICATION

Contribution
from CEMDS

ULB’s

<!-- page 23 -->

I C T TOOLS




S A M S (Sanitation Amenities Management System)

Easy for analyzing and
reviewing the spatial and
non-spatial data for each
of the sanitation sector

Spatial representation of
the available data related
to
sanitation
Infrastructure such as
locations of –

Community toilets
 Garbage collection points
 Open dumps
 Hand pumps/ stand posts
 Treatment plant


ULB’s

<!-- page 24 -->

ULB’s

<!-- page 25 -->

Contribution by

CEMDS

International best practices for sanitation:
Surveying, studying and documenting various
practices related to solid and liquid waste
management in context to small cities
Support from International experts and from
other projects.

ULB’s

<!-- page 26 -->

Strategy Formulation

Sustainable Approach

Providing Household toilets

Demand based strategy for
Sanitation infrastructure

Initiating door to door collection
Providing Community bins

Assimilate Sanitation management
plan with development plan

Rehabilitation of drain channels
Initiating awareness generation

Upgrading sewerage
system

Provision of Sanitation infrastructure for
solid and liquid waste
Sustainable models of community
managed O& M
Upgrading status of infrastructure

ULB’s
Mid Term

Efficiency in O & M

Mitigating Demand Gap

Augmenting sanitation coverage

Integrated Planning

Long Term

Short Term

<!-- page 27 -->

Suggested Technological options for wastewater management
Option



Technical details



Operational cost



Management cost





Required Fund
mobilization
Required Human
resource
Sustainability and
environmental
impact

OFFSITE



ONSITE

Consideration of
Need in future

Environme
nt
Concerns

TYPE

Option 1

Pour Flush Toilets with Septic Tanks

Option 2

Water Seal Toilets with Twin Pits

Option 3

Ecosan (Dehydrated vaults)

Option 4

Anaerobic Baffled Reactor (ABR)

Option 5

Activated Sludge Process (ASP)

Option 6

Upflow Anaerobic Sludge Blanket (UASB)

Option 7

Solid Immobilized Bio Filter (SIBF)

Option 8

Waste Stabilization Pond

Environment

Meaning

Capital Cost

Meaning

Capital
Cost

O/M Cost

O&M
Cost

Meaning

Higher Consideration

Lower capital cost

Lower Cost

Lower Consideration

Moderate capital Cost

Moderate Cost

Least Consideration

Higher capital Cost

High Cost

ULB’s

<!-- page 28 -->

Suggested Technological options for SWM

Mid
Term

Transport

Treatment

Community bins

Door to door
collection after
segregation at
Source

Transfer Station

Option 2

Short
Term

Long
Term

Transfer Station
Community
Composting

Regional
approach

Disposal

Composting at site
and Landfill Inerts
Landfill Inerts

Community bins

Option 3

Option 1

Collection

Identifying the
cities within
the region

ULB’s

Composting at site
and Landfill Inerts
Landfill Inerts

Identifying the
strategic
landfill site

<!-- page 29 -->

Strategies for Waste Management Options
Developing Social Accountability by direct involvement of citizens in
decision making
Introduction of competitive reward schemes at ward/ cluster/ slum level
as well as at city level

Ensuring monitoring and evaluation in designing Implementation and
post implementation phase
Introducing concept of Participatory Community Monitoring by
providing Community score cards, Citizen Report cards, etc.

Promoting NGOs and SHGs for involvement of capacity building

ULB’s

<!-- page 30 -->

R O A D A H E A D…

ULB’s

<!-- page 31 -->

WHY PILOT ?
Need of Pilot Project
P H A S E - II
Demonstrating and
testing practicality of
suggested strategies
Demonstrating effective
implementation of
scheme through a pilot
project
Capacity Building to
establish a Sustainable
model for Sanitation
management

Implementation Plan & Pilot Project (PHASE II)
•

•

•

•

Identifying and enlisting target areas based on the
outcome of existing status analysis
Prioritizing the crucial areas through participatory
assessment with stakeholders
Developing Short term strategy and draft an
implementation plan for the same

Carrying out detail technical survey and prepare project
report elaborating –
•
•
•
•

engineering design for waste management
Fund mobilization
Resource mobilization and Institutional set up
O&M
ULB’s

<!-- page 32 -->

Identification of Area for Piloting

Socio economic conditions
Coverage of Infrastructure
Access to Infrastructure

Status of sanitation
Infrastructure
Population density

Vulnerability of Issues

Participatory Assessment

Prioritization of areas

ULB’s
