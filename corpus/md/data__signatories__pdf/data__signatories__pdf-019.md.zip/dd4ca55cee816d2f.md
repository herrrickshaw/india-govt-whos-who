---
doc_id: "dd4ca55cee816d2f"
source_url: "https://www.dot.gov.in/static/uploads/2025/12/574123fe6dbe42f61233957569e8c879.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS Comm No. 977 of 2025 in Honble High Court of Delhi DoT instructions dated 19.09.2025 to ISPs"
date: "2025-12-24"
pages: 33
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "597496c09f4a2c8a"
---

<!-- page 1 -->

By Email/ DoT Website
File No.:4-10/2025-DGT/4
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
nd
2 Floor, UIDAI HQ, New Delhi -110001
Date: 03-10-2025
To
All Licensees with Internet Service Authorization
Subject: CS (COMM) 810/2025: JIOSTAR INDIA PRIVATE LIMITED versus
SERIALMAZA.MY & ORS. in the Hon’ble High Court of Delhi
Please find enclosed the Hon’ble High Court of Delhi order dated 24.09.2025,
23.09.2025 and 08.08.2025 in the captioned case.
2.
Please refer to para 35(d & e) of the Court order dated 08.08.2025 along with
Court order dated 24.09.2025 and 23.09.2025 in respect of blocking access to the
website(s)/domain(s) [292 no.] impleaded as Defendant No. 146 to 216, 219 to 309,
315 to 380 and 383 to 446 in the captioned suit.
3.
In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access to
the said website(s)/domain(s), as per the enclosed list, in compliance with the said
court orders.
Encl: A/A

Sudhir

Digitally signed by
Sudhir
Date: 2025.10.03
17:52:49 +05'30'

ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court order/
enclosed Annexure pl.
ii.)
Ms Ishi Singh (ishi@saikrishnaassociates.com), Plaintiﬀ's Counsel - For kind
information and with a request to take action as per the enclosed Annexure pl.

<!-- page 2 -->

42
DOCUMENT – A

Proposed Additional Rouge Websites
Defendant
(Mirror/redirect/alphanumeric
Website
Nos.
domain name of the Proposed

Proposed

Domain

Defendant

(DNR)

Name

Registrar

DNR Nos.

Defendant)
146.

123moviesfree9.wtf

139.

NameSilo, LLC

147.

hdmovies4u.pet

38.

NameCheap, Inc.

148.

filmyzilla19.net

37.

Dynadot LLC

45.

Internet Domain Service BS

149.

150.

filmyzilla19.com
multimovies.pro

151.

Corp
139.
217.

cloudmoviez.site

(Proposed
Defendant)

NameSilo, LLC
Atak

Domain

Teknolojileri A.Ş.

152.

filmyfly.navy

139.

NameSilo, LLC

153.

vegamovie.study

40.

Porkbun LLC

154.

privatemoviez.website

40.

Porkbun LLC

155.

moviehax.video

38.

NameCheap, Inc.

156.

movies4u.cl

37.

Dynadot LLC

157.

9xmovies.vu

37.

Dynadot LLC

158.

moviezguru.run

38.

NameCheap, Inc.

159.

desiremoviess.buzz

41.

Spaceship, Inc

160.

1full4movies.com

38.

NameCheap, Inc.

161.

desiremovies.cards

37.

Dynadot LLC

162.

filmycab.watch

38.

NameCheap, Inc.

163.

mp4moviez.spot

38.

NameCheap, Inc.

164.

downloadhub.fan

37.

Dynadot Inc

165.

1moviesfd.beauty

38.

NameCheap, Inc.

Bilgi

<!-- page 3 -->

43
166.

rdxhd.bar

38.

Namecheap,Inc.

167.

yomovies.codes

38.

Namecheap,Inc.

168.

ofilmyzilla.biz

37.

Dynadot Inc

169.

ofilmywap.how

38.

Namecheap,Inc.

170.

movie4me1.live

38.

Namecheap,Inc.

171.

5movierulz.cheap

37.

Dynadot Inc

172.

14filmywap.com

37.

Dynadot Inc

173.

bdmusic23.com

37.

Dynadot Inc

174.

7starhd.spa

37.

Dynadot Inc

175.

vegamovies-in.lol

41.

Spaceship, Inc

176.

dudefilms.dev

38.

NameCheap, Inc.

177.

filmyhit.gives

37.

Dynadot Inc

178.

prmovies.horse

38.

Namecheap,Inc.

179.

mp4moviezcom.bond

41.

Spaceship, Inc

180.

1hdmoviearea.buzz

41.

Spaceship, Inc

181.

melamovies.com

142.

Cosmotown, Inc.

182.

filmywapcom.lol

41.

Spaceship, Inc

183.

desiremovies.esq

42.

Tucows Domains Inc.

184.

filmyhit-com.lol

41.

Spaceship, Inc.

185.

9kmovies.credit

37.

Dynadot Inc

186.

filmy4wap.dad

38.

NameCheap, Inc.

187.

ssrmovies.vision

144.

Name.com, Inc.

188.

mp4moviez.host

38.

NameCheap, Inc.

189.

ssrmoviescom.lol

41.

Spaceship, Inc.

190.

bolly4u.lifestyle

38.

NameCheap, Inc.

191.

zaaflix.com

38.

NameCheap, Inc.

192.

moviesflix.ad

41.

Spaceship, Inc.

193.

vegamovies-nl.wang

40.

Porkbun LLC

194.

allmovieshub.dev

38.

NameCheap, Inc.

<!-- page 4 -->

44
195.

filmylol.org

140.

Hosting Concepts B.V. d/b/a
Registrar.eu

196.

filmy-meet.icu

42.

Spaceship, Inc.

197.

fmovieszz.lol

42.

Tucows.com Co.

141.

HOSTINGER

198.

topmovies4u.online

UAB

199.

katmovie.icu

41.

Spaceship, Inc.

200.

rdxhd-official.lol

41.

Spaceship, Inc.

201.

movies-nation.bond

41.

Spaceship, Inc.

202.

yomovies1.beauty

38.

NameCheap, Inc.

203.

9xflixcom.forum

41.

Spaceship, Inc.

204.

www4.hdtodaytv.tv

139.

NameSilo, LLC

205.

hdmovieshub-in.lol

41.

Spaceship, Inc.

206.

extramovies.mba

139.

NameSilo, LLC

207.

desiremovies.poker

41.

Spaceship, Inc.

208.

jagritiserial.com

41.

Spaceship, Inc.

209.

aamidakini.com

37.

Dynadot Inc

210.

dhaakadbeera.com

37.

Dynadot Inc

211.

manpasandkishaadi.com

37.

Dynadot Inc

212.

meribhavyalife.info

37.

Dynadot Inc

213.

jhanak.online

41.

Spaceship, Inc.

214.

meribhavyalife.net

37.

Dynadot Inc

215.

serialmaza.live

37.

Dynadot Inc

216.

218.
education.techevz.com

(Proposed
Defendant)

Name SRS AB

operations,

<!-- page 5 -->

48
DOCUMENT – A
Proposed Additional Rouge Websites
Defendant
(Mirror/redirect/alphanumeric
Website
Nos.
domain name of the Proposed

Proposed

Domain

Defendant

(DNR)

Name

DNR Nos.

Defendant)
219.

310.
1movies.bz

(Proposed

Sarek Oy

Defendant)
220.

extramovies.faith

139.

NameSilo, LLC

221.

filmy4web.monster

38.

NameCheap, Inc.

222.

flixindia.xyz

38.

NameCheap, Inc.

223.

playx4.movielinkbd.sbs

41.

Spaceship, Inc.

224.

movies4u.exposed

41.

Spaceship, Inc.

225.

moviesyaya.net

41.

Spaceship, Inc.

226.

olamovies.blog

40.

Porkbun, LLC

227.

rogmovies.space

38.

NameCheap, Inc.

228.

9kmovies.vu

37.

Dynadot Inc

229.

mp4moviez.moe

38.

NameCheap, Inc.

230.

zoechip.gg

38.

NameCheap, Inc.

231.

7starhd.cc

37.

Dynadot Inc

232.

9xmovie.fan

37.

Dynadot Inc

233.

downloadhub.cash

38.

NameCheap, Inc.

234.

filmlinks4u.cyou

38.

NameCheap, Inc.

235.

hexawatch.cc

37.

Dynadot Inc

236.

moviekhuji.com

38.

NameCheap, Inc.

237.

moviesflix.lt

37.

Dynadot LLC

238.

311.
movieyes.duckdns.org

(Proposed
Defendant)

Gandi SAS

Registrar

<!-- page 6 -->

49
239.

skysetx.rip

144.

Name.com, Inc.

240.

ssrmovies.biz.in

37.

Dynadot LLC

241.

worldfree4u.biz.in

37.

Dynadot LLC

242.

watchmovierulz.blue

42.

Tucows Domains Inc

243.

yomovies.video

38.

NameCheap, Inc.

244.

zeefliz.space

38.

NameCheap, Inc.

245.

dvdplayin.buzz

41.

Spaceship Inc

246.

720pflix.auction

37.

Dynadot Inc

247.

khatrimaza.deals

37.

Dynadot Inc

248.

movieswatchhd.com

38.

NameCheap, Inc.

249.

skymovieshd.gifts

37.

Dynadot Inc

250.

ww1.movierulzfree.my

38.

NameCheap, Inc.

251.

bdmusic24.club

38.

NameCheap, Inc.

252.

extraflix.cfd

38.

NameCheap, Inc.

253.

hdfilm2.com

38.

NameCheap, Inc.

141.

HOSTINGER

254.

jattfilms.art

operations,

UAB

255.

myflixerz.tube

42.

Tucows Domains Inc.

256.

movie20.movielinkbd4u.com

41.

Spaceship Inc

257.

uhdmovies.us

38.

NameCheap, Inc.

258.

7starhd.watch

38.

NameCheap, Inc.

259.

7starhd.zip

40.

Porkbun, LLC

260.

9kmovies.bond

38.

NameCheap, Inc.

261.

9xflix.chat

37.

Dynadot Inc

262.

bdmusicboss.top

40.

Porkbun, LLC

263.

bollyflix.faith

42.

Tucows Domains Inc.

264.

apnetv.fun

40.

Porkbun, LLC

265.

bigg-boss.com

43.

Sav.com, LLC

266.

bigg-boss.net

43.

Sav.com, LLC

<!-- page 7 -->

50
267.

bigg-boss19.com

37.

Dynadot Inc

268.

bigg-boss19.online

37.

Dynadot LLC

269.

biggboss.co

139.

NameSilo, LLC

270.

biggboss.org

43.

Sav.com, LLC

271.

312.
biggboss19desiserial.su

(Proposed

ARDIS-SU

Defendant)
272.

biggboss19fullepisodes.com

37.

Dynadot Inc

273.

biggboss19in.com

37.

Dynadot Inc

274.

tumsetumtak.net

37.

Dynadot Inc

275.

watch.desitashan.org

38.

NameCheap, Inc.

276.

watch.desitv.to

38.

NameCheap, Inc.

140.

Hosting Concepts B.V. d/b/a

277.

biggboss19watchonline.com

Registrar.eu

278.

dhaakadbeera.net

37.

Dynadot Inc

279.

world4ufree.cv

37.

Dynadot

280.

bdboss24.com

43.

Sav.com, LLC

281.

go5pm.net

38.

NameCheap, Inc.

140.

Hosting Concepts B.V. d/b/a

282.

yodesihd.net

Registrar.eu

283.

ogomovies.gg

38.

NameCheap, Inc.

284.

biggboss.us

43.

Sav.com, LLC

285.

biggboss19.cfd

37.

Dynadot LLC

286.

biggboss19.co

37.

Dynadot Inc

287.

biggboss19.live

38.

NameCheap, Inc.

288.

biggboss19.me

37.

Dynadot Inc

289.

biggboss19.net

38.

NameCheap, Inc.

290.

biggboss19.one

37.

Dynadot Inc

291.

biggboss19.online

41.

Spaceship, Inc.

<!-- page 8 -->

51
292.

biggboss19.org

293.

37.

Dynadot Inc

313.
biggboss19.se

(Proposed

Loopia AB

Defendant)
294.

314.
biggboss19.su

(Proposed

ACTIVE-SU

Defendant)
295.

biggboss19live.co

37.

Dynadot Inc

296.

biggboss19live.com

37.

Dynadot Inc

297.

biggboss19live.net

37.

Dynadot Inc

298.

biggboss19show.com

37.

Dynadot Inc

140.

Hosting Concepts B.V. d/b/a

299.

biggboss19th.com

300.

Registrar.eu
312.

biggboss19th.su

(Proposed

ARDIS-SU

Defendant)
301.

biggboss19tv.com

37.

Dynadot Inc

302.

biggboss19watch.live

37.

Dynadot Inc

303.

biggboss19watch.net

37.

Dynadot Inc

304.

biggbosslive.net

37.

Dynadot Inc

305.

biggbosslive.org

37.

Dynadot Inc

140.

Hosting Concepts B.V. d/b/a

306.

biggboss19episode.com

Registrar.eu

307.

biggboss.cfd

37.

Dynadot LLC

308.

biggboss19live.watch

40.

Porkbun, LLC

140.

Hosting Concepts B.V. d/b/a

309.

yehrishtakya.org

Registrar.eu

<!-- page 9 -->

53
DOCUMENT – A
Proposed

Additional Rouge Websites

Proposed

Domain

Defendant

(Mirror/redirect/alphanumeric

Defendant

(DNR)

Website

domain

DNR Nos.

Nos.

Proposed Defendant)

315.

9xmovies.sex

38.

NameCheap, Inc.

316.

movies4u.ec

37.

Dynadot Inc.

317.

desiremovies.fan

37.

Dynadot Inc.

name

318.

of

the

Name

Registrar

13.
mkvcinemas.gift

Tucows Domains Inc.

319.

jalshamoviez7.com

37.

Dynadot Inc.

320.

hindilinks4u.beer

38.

NameCheap, Inc.

321.

filmycab.rocks

38.

NameCheap, Inc.

322.

9xmovies.organic

37.

Dynadot Inc.

323.

5movierulz.villas

37.

Dynadot Inc.

324.

mp4moviez.supply

38.

NameCheap, Inc.

325.

filmyfly.dog

139.

NameSilo, LLC

326.

yomovies.christmas

38.

NameCheap, Inc.

327.

ofilmyzilla.bet

37.

Dynadot Inc.

45.

Internet Domain Service BS

328.
filmyzilla20.com

Corp

329.

cinedokan.xyz

38.

NameCheap, Inc.

330.

15filmywap.com

37.

Dynadot Inc.

331.

7starhd.gift

37.

Dynadot, LLC

332.

vegamovies-in.bond

41.

Spaceship, Inc.

333.

dudefilms.watch

38.

NameCheap, Inc.

334.

movieshorizon.biz

38.

NameCheap, Inc.

335.

khatrimazacom.lol

41.

Spaceship, Inc.

<!-- page 10 -->

54
336.

movieplex.email

38.

NameCheap, Inc.

337.

mkvmoviespoints.skin

41.

Spaceship, Inc.

338.

hhdmovies.biz

38.

NameCheap, Inc.

339.

moviesflix-pro.top

41.

Spaceship, Inc.

340.

skymovieshd.army

38.

NameCheap, Inc.

341.

luxmovies.tips

38.

NameCheap, Inc.

342.

1movierulzhd.site

38.

NameCheap, Inc.

343.

bolly-mod.lat

41.

Spaceship, Inc.

344.

world4ufree.news

13.

Tucows Domains Inc.

345.

bollyflixcom.icu

41.

Spaceship, Inc.

346.

movie4z.movielinkbd.sbs

41.

Spaceship, Inc.

347.

kmmovies.art

41.

Spaceship, Inc.

348.

filmfly.sbs

38.

NameCheap, Inc.

349.

multimovies.lol

139.

NameSilo, LLC

350.

filmyhit.bar

37.

Dynadot, LLC

351.

prmovies.beer

38.

NameCheap, Inc.

352.

desiremovies.nagoya

13.

Tucows Domains Inc.

353.

vegamovies-nl.beer

40.

Porkbun

140.

Hosting

354.
filmylol.lol

Concepts

d/b/a Registrar.eu

355.

9xflixcom.bond

41.

Spaceship, Inc.

356.

desiremovies.taxi

41.

Spaceship, Inc.

357.

filmy4web.website

38.

NameCheap, Inc.

358.

7starhd.xin

37.

Dynadot Inc.

359.

9xmovie.foo

37.

Dynadot, Inc.

360.

biggboss19episodes.com

37.

Dynadot Inc.

361.

biggboss19free.com

37.

Dynadot Inc.

362.

biggboss19stream.com

37.

Dynadot Inc.

363.

bengalitvserial24.com

43.

Sav.com, LLC

B.V.

<!-- page 11 -->

55
364.

ishaniserial.com

37.

Dynadot Inc.

365.

ittisikhushiserial.com

38.

NameCheap, Inc.

366.

ziddidilin.com

37.

Dynadot Inc.

140.

Hosting

367.

yrkkhdesiserial.org

Concepts

d/b/a Registrar.eu

368.

shirdiwalesaibabatv.com

37.

Dynadot Inc.

369.

ssrmovies.solar

37.

Dynadot Inc.

370.

zeefliz.website

38.

NameCheap, Inc.

371.

khatrimaza.fan

37.

Dynadot Inc.

372.

skymovieshd.legal

37.

Dynadot Inc.

373.

bollyflix.ist

13.

Tucows Domains Inc.

374.

tmkocserial.com

37.

Dynadot Inc.

375.

filmyzilla20.org

37.

Dynadot Inc.

376.

biggbossserial.net

37.

Dynadot Inc.

377.

B.V.

381
alphabaydarknet.com

(Proposed

Squarespace Domains LLC

Defendant)
378.

382
uflix.to

(Proposed

Government of Kingdom of

Defendant

Tonga

)
379.

cinetvshows.com

38.

NameCheap, Inc.

380.

biggbossott3.com

37.

Dynadot Inc.

<!-- page 12 -->

57
DOCUMENT – A
Proposed

Additional Rouge Websites

Proposed

Domain

Defendant

(Mirror/redirect/alphanumeric

Defendant

(DNR)

Website

domain name of the Proposed

DNR Nos.

Nos.

Defendant)

383.

yrkkhlive.com

37.

Dynadot Inc

384.

yomovies.lifestyle

38.

NameCheap, Inc.

385.

www20.movierulz.ink

38.

NameCheap, Inc.

386.

ww.anupamatvserial.com

37.

Dynadot Inc

387.

world4ufree.red

37.

Dynadot Inc

388.

world4u.bond

41.

Spaceship, Inc.

389.

vegamoviies.my

37.

Dynadot, LLC

390.

vegamoviesv.com.in

37.

Dynadot, LLC

391.

vegamovies-nl.cloud

40.

Porkbun LLC

45.

Internet Domain Service BS

392.

vegamoviescom.com

Name

Registrar

Corp

393.

vegamovies8.cloud

41.

Spaceship, Inc.

394.

vegamovies.jewelry

41.

Spaceship, Inc.

395.

vegamovie.vision

40.

Porkbun LLC

396.

topmovies.rip

13.

Tucows Domains Inc.

397.

themoviespalace.fit

38.

NameCheap, Inc.

398.

tamildhool.tech

38.

NameCheap, Inc.

399.

447.
ssrmovies.keivastgoed.net

(Proposed
Defendant)

Key-Systems GmbH

400.

ssrmovies.exchange

144.

Name.com, Inc.

401.

rogmovies.org

38.

NameCheap, Inc.

402.

okhatrimaza.lat

37.

Dynadot, LLC

403.

myflixtor.tv

13.

Tucows Domains Inc.

<!-- page 13 -->

58
404.

multimovies.city

139.

NameSilo, LLC

405.

mp4moviez.fish

38.

NameCheap, Inc.

406.

moviezguru.email

38.

NameCheap, Inc.

407.

movieshunt.guru

41.

Spaceship, Inc.

408.

moviesflix.fr

37.

Dynadot Inc

409.

movieseflix.my

37.

Dynadot, LLC

410.

moviery.movielinkbd4u.com

41.

Spaceship, Inc.

411.

movielinkhub.fun

139.

NameSilo, LLC

412.

mkvcinemas.city

38.

NameCheap, Inc.

413.

jiorockerscom.bond

41.

Spaceship, Inc.

141.

HOSTINGER

414.

hdmovie2.space

operations,

UAB

415.

hdmovie2.directory

144.

Name.com, Inc.

416.

hdhub4u.florist

13.

Tucows Domains Inc.

417.

freedrivemovie.xyz

37.

Dynadot, LLC

418.

filmyzerox.cfd

142.

Cosmotown Inc

419.

filmyworlds.pw

38.

NameCheap, Inc.

420.

filmyworlds.bond

41.

Spaceship, Inc.

421.

filmyhunks.skin

41.

Spaceship, Inc.

422.

448.
filmyhunk.chat

(Proposed

Devexpanse

Defendant)

Regery.com

Ltd

423.

filmyhit-com.mom

41.

Spaceship, Inc.

424.

filmycabel.xyz

37.

Dynadot, LLC

425.

filmy4wap1.sbs

38.

NameCheap, Inc.

426.

downloadhub.gifts

37.

Dynadot Inc

427.

downloadhub.casa

41.

Spaceship, Inc.

141.

HOSTINGER

428.

downloadhub.cafe

UAB

d/b/a

operations,

<!-- page 14 -->

59
429.

dotmoviess.pics

41.

Spaceship, Inc.

430.

cinevood.cool

37.

Dynadot Inc

431.

biggbossseason19.com

37.

Dynadot Inc

432.

biggboss19.lol

37.

Dynadot Inc

433.

biggboss19.com

38.

NameCheap, Inc.

434.

biggbos.live

40.

Porkbun LLC

435.

bdhdmusic23.buzz

41.

Spaceship, Inc.

436.

allmovieshub.games

38.

NameCheap, Inc.

437.

9xmoviese.vip

37.

Dynadot Inc

438.

9xmoveis.com

37.

Dynadot Inc

439.

7sttarhd.lat

37.

Dynadot, LLC

440.

7starhd.me

144.

Name.com, Inc.

441.

7starhd.institute

41.

Spaceship, Inc.

442.

5movierulz.clinic

13.

Tucows Domains Inc.

443.

1tamilmv.cab

13.

Tucows Domains Inc.

444.

1tamilblasters.digital

139.

NameSilo, LLC

445.

1full4movies.world

38.

NameCheap, Inc.

446.

16filmywap.com

37.

Dynadot Inc

<!-- page 15 -->

$~29
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 810/2025
JIOSTAR INDIA PRIVATE LIMITED
.....Plaintiff
Through:

Ms. Ishi Singh, Mr. Manish
Singh, Advocates

versus
SERIALMAZA.MY & ORS.
.....Defendant
Through:

Mr. Yash Raj, Mr. Vignesh Raj T
(VC), Advocates for D-40 and
D140

CORAM:
JOINT REGISTRAR (JUDICIAL) Dr. AJAY GULATI

%

ORDER
24.09.2025

I.A. No. 24091/2025 on behalf of the plaintiff seeking
impleadment of additional websites and their domain name
registrars engaged in infringing activities as defendant nos.
315 to 382 (rouge websites) in the memo of parties.
1.

The plaintiff is seeking to implead additional rogue-

websites as defendant nos. 315 to 380 because they have been
found to be indulging in illegally disseminating the copyrighted
material belonging to the plaintiff. Proposed defendant nos. 381
& 382 are DNR’s concerning 2 of these rogue websites which are
sought to be impleaded. The application is supported by the
required affidavit. Keeping in view the contents of the suit and
the application, the same is allowed. The proposed defendants
are impleaded as defendant nos. 315 to 382. Ld. Counsel for the
plaintiff is also directed to serve a copy of this IA on the
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 25/09/2025 at 13:54:23

<!-- page 16 -->

defendant DNR’s who are already in the array i.e. defendant nos.
13, 37, 38, 40, 41, 42, 45, 139 and 140 since these DNR’s are
concerned with some of the rogue websites which have been
impleaded today.
2.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve the newly impleaded defendants
with summons within two weeks, through the electronic mode
only, on filing of PF.
3.

The order blocking the rogue-websites passed by the

Hon’ble Court on 08.08.2025 shall operate qua the freshly
impleaded defendants as well, in terms of directions contained in
para 36 of the order dated 08.08.2025. The injunction order
passed by the Hon’ble Court contained in para 35 (a) of the order
dated 08.08.2025 shall operate qua the newly impleaded rogue
websites. Further, in terms of para 35 (b) and (c), the concerned
DNR’s who are already in the array and those impleaded today,
are directed to lock and suspend / deactivate the rogue websites
impleaded today, and the concerned DNR’s are also directed to
disclose complete details of the new rogue websites in an
affidavit within four weeks, to be filed in the Court. Defendant
nos. 47 to 55 / ISP’s and defendant nos. 56 and 57 are directed to
take necessary steps qua defendant no. 315 to 380, as were given
by the Hon’ble Court in paras 35 (d) and (e) of the order dated
08.08.2025. IA is allowed and disposed off accordingly.
I.A. No. 24092/2025 on behalf of the plaintiff seeking
impleadment of additional websites and their domain name
registrars engaged in infringing activities as defendant nos.
383-448 (rouge websites) in the memo of parties.
4.

The plaintiff is seeking to implead additional rogue-

websites as defendant nos. 383 to 446 because they have been
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 25/09/2025 at 13:54:23

<!-- page 17 -->

found to be indulging in illegally disseminating the copyrighted
material belonging to the plaintiff. Proposed defendant nos. 447
& 448 are DNR’s concerning 2 of these rogue websites which are
sought to be impleaded. The application is supported by the
required affidavit. Keeping in view the contents of the suit and
the application, the same is allowed. The proposed defendants
are impleaded as defendant nos. 383 to 448. Ld. Counsel for the
plaintiff is also directed to serve a copy of this IA on the
defendant DNR’s who are already in the array i.e. defendant nos.
13, 37, 38, 40, 41, 45, 139, 140, 141, 142 and 144 since these
DNR’s are concerned with some of the rogue websites which
have been impleaded today.
5.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve the newly impleaded defendants
with summons within two weeks, through the electronic mode
only, on filing of PF.
6.

The order blocking the rogue-websites passed by the

Hon’ble Court on 08.08.2025 shall operate qua the freshly
impleaded defendants as well, in terms of directions contained in
para 36 of the order dated 08.08.2025. The injunction order
passed by the Hon’ble Court contained in para 35 (a) of the order
dated 08.08.2025 shall operate qua the newly impleaded rogue
websites. Further, in terms of para 35 (b) and (c), the concerned
DNR’s who are already in the array and those impleaded today,
are directed to lock and suspend / deactivate the rogue websites
impleaded today, and the concerned DNR’s are also directed to
disclose complete details of the new rogue websites in an
affidavit within four weeks, to be filed in the Court. Defendant
nos. 47 to 55 / ISP’s and defendant nos. 56 and 57 are directed to
take necessary steps qua defendant no. 383 to 446, as were given
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 25/09/2025 at 13:54:23

<!-- page 18 -->

by the Hon’ble Court in paras 35 (d) and (e) of the order dated
08.08.2025. IA is allowed and disposed off accordingly.

Dr. AJAY GULATI
(DHJS),
JOINT REGISTRAR (JUDICIAL)
SEPTEMBER 24, 2025/sk

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 25/09/2025 at 13:54:23

<!-- page 19 -->

$~30
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 810/2025
JIOSTAR INDIA PRIVATE LIMITED
.....Plaintiff
Through:

Ms. Ishi Singh, Mr. Manish,
Advocates

Versus

SERIALMAZA.MY & ORS.
.....Defendant
Through:

Mr. Yash Raj, Advocate for D-40
& D-140

CORAM:
JOINT REGISTRAR (JUDICIAL) Dr. AJAY GULATI

%

ORDER
23.09.2025

I.A. No. 23943/2025 on behalf of the plaintiff seeking
impleadment of additional websites and their domain name
registrars engaged in infringing activities as defendant nos.
146 to 218 (rouge websites) in the memo of parties.
1.

The plaintiff is seeking to implead additional rogue-

websites as defendant nos. 146 to 216 because they have been
found to be indulging in illegally disseminating the copyrighted
material belonging to the plaintiff. Proposed defendant nos. 217
& 218 are DNR’s concerning 2 of these rogue websites which are
sought to be impleaded. The application is supported by the
required affidavit. Keeping in view the contents of the suit and
the application, the same is allowed. The proposed defendants
are impleaded as defendant nos. 146 to 218. Ld. Counsel for the
plaintiff is also directed to serve a copy of this IA on the
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 03/10/2025 at 16:10:01

<!-- page 20 -->

defendant DNR’s who are already in the array i.e. defendant nos.
37, 38, 40, 41, 42, 45, 139, 140, 141, 142 and 144 since these
DNR’s are concerned with some of the rogue websites which
have been impleaded today.
2.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve the newly impleaded defendants
with summons within two weeks, through the electronic mode
only, on filing of PF.
3.

The order blocking the rogue-websites passed by the

Hon’ble Court on 08.08.2025 shall operate qua the freshly
impleaded defendants as well, in terms of directions contained in
para 36 of the order dated 08.08.2025. The injunction order
passed by the Hon’ble Court contained in para 35 (a) of the order
dated 08.08.2025 shall operate qua the newly impleaded rogue
websites. Further, in terms of para 35 (b) and (c), the concerned
DNR’s who are already in the array and those impleaded today,
are directed to lock and suspend / deactivate the rogue websites
impleaded today, and the concerned DNR’s are also directed to
disclose complete details of the new rogue websites in an
affidavit within four weeks, to be filed in the Court. Defendant
nos. 47 to 55 / ISP’s and defendant nos. 56 and 57 are directed to
take necessary steps qua defendant no. 146 to 216, as were given
by the Hon’ble Court in paras 35 (d) and (e) of the order dated
08.08.2025. IA is allowed and disposed off accordingly.
I.A. No. 23949/2025 on behalf of the plaintiff seeking
impleadment of additional websites and their domain name
registrars engaged in infringing activities as defendant nos.
219-314 (rouge websites) in the memo of parties.
4.

The plaintiff is seeking to implead additional rogue-

websites as defendant nos. 219 to 309 because they have been
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 03/10/2025 at 16:10:01

<!-- page 21 -->

found to be indulging in illegally disseminating the copyrighted
material belonging to the plaintiff. Proposed defendant nos. 310
to 314 are DNR’s concerning some of these rogue websites
which are sought to be impleaded. The application is supported
by the required affidavit. Keeping in view the contents of the
suit and the application, the same is allowed. The proposed
defendants are impleaded as defendant nos. 219 to 314. Ld.
Counsel for the plaintiff is also directed to serve a copy of this IA
on the defendant DNR’s who are already in the array i.e.
defendant nos. 37, 38, 40, 41, 42, 43, 139, 140, 141 and 144 since
these DNR’s are concerned with some of the rogue websites
which have been impleaded today, and to the DNR’s who have
been impleaded today.
5.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve the newly impleaded defendants
with summons within two weeks, through the electronic mode
only, on filing of PF.
6.

The order blocking the rogue-websites passed by the

Hon’ble Court on 08.08.2025 shall operate qua the freshly
impleaded defendants as well, in terms of directions contained in
para 36 of the order dated 08.08.2025. The injunction order
passed by the Hon’ble Court contained in para 35 (a) of the order
dated 08.08.2025 shall operate qua the newly impleaded rogue
websites. Further, in terms of para 35 (b) and (c), the concerned
DNR’s who are already in the array and those impleaded today,
are directed to lock and suspend / deactivate the rogue websites
impleaded today, and the concerned DNR’s are also directed to
disclose complete details of the new rogue websites in an
affidavit within four weeks, to be filed in Court. Defendant nos.
47 to 55 / ISP’s and defendant nos. 56 and 57 are directed to take
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 03/10/2025 at 16:10:01

<!-- page 22 -->

necessary steps qua defendant no. 219 to 309, as were given by
the Hon’ble Court in paras 35 (d) and (e) of the order dated
08.08.2025. IA is allowed and disposed off accordingly.

Dr. AJAY GULATI
(DHJS),
JOINT REGISTRAR (JUDICIAL)
SEPTEMBER 23, 2025/sk

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 03/10/2025 at 16:10:01

<!-- page 23 -->

10/3/25, 4:21 PM

Fwd: Compliance for the Order dated 23.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

Fwd: Compliance for the Order dated 23.09.2025 passed by the Hon'ble High Court of
Delhi in CS(COMM) 810 of 2025: JioStar India Private Limited v. serialmaza.my & Ors

Manish Shukla < dirit.hq-dgt-dot@gov.in >
Fri, 26 Sep 2025 10:07:48 AM +0530

To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>
Cc "Kripa Shanker Pandey"<adt.hq-dgt-dot@gov.in>

1 Attachment(s)
23.09.2025.pdf
125.2 KB

हार्दिक शुभकामनाओं के साथ/ With warm regards,
मनीष शुक्ला/ Manish Shukla
निदेशक (टी), डीजीटी मुख्यालय/ Director (T), DGT HQ

============ Forwarded message ============
From: Cyber Law Legal <cyberlaw-legal@meity.gov.in>
To: "adgnthq-dgt-dot"<adgnt.hq-dgt-dot@gov.in>, "Manish Shukla"<dirit.hq-dgtdot@gov.in>
Cc: "Deepak Goel"<gccyberlaw@meity.gov.in>, "Sathyanarayanan Subramanian"
<sathya.s@meity.gov.in>, "Avneet Toor Gupta"<avneett.g@nic.in>, "Nagarajan N"
<nagarajan.n@meity.gov.in>
Date: Thu, 25 Sep 2025 17:39:08 +0530
Subject: Fwd: Compliance for the Order dated 23.09.2025 passed by the Hon'ble High
Court of Delhi in CS(COMM) 810 of 2025: JioStar India Private Limited v. serialmaza.my &
Ors
============ Forwarded message ============

Dear Sir,
Request your attention to the trailing email as under. Would appreciate, if you could review it and
take necessary action, as required.
Kindly, inform us once the needful has been done.
Thanks and Regards
Nagarajan. N
Scientist C
Cyberlaw Division
about:blank

1/5

<!-- page 24 -->

10/3/25, 4:21 PM

Fwd: Compliance for the Order dated 23.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

Ministry of Electronics and Information Technology (MeitY)
Tel: 9310759547

============ Forwarded message ============
From: Ishi Singh <ishi@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Ram Meena"<dirds2-dot@nic.in>, "Cyber Law Legal"<cyberlawlegal@meity.gov.in>, "Dr. Sandip Chatterjee"<gccyberlaw@meity.gov.in>, "Prafulla Kumar"
<pkumar@meity.gov.in>, <sathya.s@meity.gov.in>
Cc: "Yatinder Garg"<yatinder@saikrishnaassociates.com>, "Priyansh Kohli"
<priyansh@saikrishnaassociates.com>, "Ashok Yadav"<ashok.yadav1@jiostar.com>
Date: Thu, 25 Sep 2025 13:46:16 +0530
Subject: Compliance for the Order dated 23.09.2025 passed by the Hon'ble High Court of
Delhi in CS(COMM) 810 of 2025: JioStar India Private Limited v. serialmaza.my & Ors
============ Forwarded message ============
Dear Sir,
We act on behalf of JioStar India Pvt. Ltd. (‘JioStar’) having their office at Star House, Urmi Estate, 95, Ganpatrao
Kadam Marg, Lower Parel (W), Mumbai – 400013, (hereinafter referred to as “Our Client”). Our Client is the
Plaintiff in the above-captioned suit.
Our Client is the producer of various TV Shows, films and/or web series which are communicating on JioStar
Channels and/ or JioHotstar and has exclusive rights in such works (Plaintiff’s Work) as enumerated under
Section14(d) of the Copyright Act, 1957, including inter alia to publicly exhibits and communicate the said content
through any medium or mode including on JioStar Channels or JioHotstar. Our Client is thus the sole and exclusive
owner of the copyright and Broadcast Reproduction Rights in relation to the aforesaid broadcasts of general
entertainment content communicated through the JioStar Channels and JioHotstar, as per Section 37 and 17 of the
Copyright Act, 1957.
Our Client has instituted the above-captioned Suit against various ‘rogue’ websites inter alia the Defendant Nos. 1
to 35 (“Defendant Websites”) before the Hon’ble High Court of Delhi, inter alia, seeking permanent and exparte ad-interim and temporary injunction restraining violation of its exclusive statutory rights in relation to the
Plaintiff’s Work as well as for other reliefs.
Our Client has also arrayed various Domain Name Registrars (Defendant No.36-46) , Internet and Telecom Service
Providers (ISPs), (Defendant No. 47 – 55) as well as the concerned Government departments i.e. Department of
Telecommunication (DoT) (Defendant No.56), the Ministry of Information and Technology (MEITY) (Defendant
No.57) to ensure effective compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
The above-mentioned matter came up before the Hon’ble Justice Manmeet Singh Arora, Delhi High Court on
08.08.2025, on which date, the Hon’ble Court was pleased to issue notice to you and was also pleased to pass an exparte ad-interim order (Injunction Order) in terms of Prayer Clause in terms of application under Order XXXIX
Rules 1 and 2. The relevant para of the Order dated 08.08.2025 is extracted herein below:
“35. Accordingly, till the next date of hearing the following directions are issued:
a.
Defendant nos.1 to 35 including their owners, partners, proprietors, officers, servants, affiliates, employees,
and all others in capacity of principal or agent acting for and on its behalf, or anyone claiming through, by or
under it, are restrained from in any manner communicating to the public, hosting, storing, reproducing, streaming,
broadcasting, rebroadcasting, causing to be seen or heard by public on payment of charge and/or making available
for viewing Plaintiff’s content through their websites including those listed as under:

about:blank

Defendant No.
1.
2.

Defendant Websites
serialmaza.my
5movierulz.cash

3.
4.
5.

zolomovies.biz
tudhadkanmaindil.com
yomovies1.bond
2/5

<!-- page 25 -->

10/3/25, 4:21 PM

Fwd: Compliance for the Order dated 23.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

6.
7.
8.
9.
10.
11.
12.
13.
14.

tamildhool.net
sungohd.com
vegamovies-nl.quest
vegamovies-nl.bio
shivshaktiserials.com
movies4u.mba
movienest.lol
mkvcinemas.men
mangallakshmiserial.com

15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.

khatronkekhiladi.net
hdmovie2.yoga
bolly4u.video
biggbosstoday.net
biggbossott3.com
bdhdmusic23.cc
hdhub4u.fail
hdhub4u.family
hdmovie2.computer
hdmovie2.shoes
q.hdhc.site
bromovies.tv
bollyflix.dance
5movierulz.life
5movierulz.dance
1pogolinks.site
1tamilcrow.net
biggboss.my
fullserials.xatab.top
go5pm.com
ww1.couchtuner.guru

b. Defendant nos. 36 to 46 are directed to lock and suspend/deactivate the above mentioned domains/subdomains
of the infringing websites.
c.
Defendant nos. 36 to 46 are directed to disclose complete details [inter alia name, address, email, phone
number and IP address] of Defendant nos. 1 to 35, and mode of payment along with payment details used for
registrations of the said domain names. The said disclosure shall be made by an affidavit and be filed before this
Court within a period of four weeks.
d.
Defendant nos. 47 to 55 [ISPs] are directed to block access to these infringing websites tabulated above,
within 48 hours of receipt of this order.
e.
Defendant nos. 56 [i.e. DoT] and 57 [i.e., MEITY] shall take steps to ensure that ISPs comply with the
directions issued above, through appropriate communications and notices sent to the said ISPs, including other
ISPs which are registered with them.
f.
In case, there is any work in respect whereof there is any dispute as to the ownership of the copyright, an
application may be moved by the affected party before the Court, to seek clarification.
36. In the facts of this case, the Plaintiff has also prayed for a dynamic injunction to protect its copyrighted works
from the hydra-headed websites, as soon as they are created. This Court is satisfied in the facts of this case dynamic
injunction ought to be issued to protect the Plaintiff’s copyrighted works.
36.1. It is thus further directed that if any other mirror/alphanumeric/similar/redirect variation of the websites
identified in the suit as Defendant Nos. 1 to 35 are found to be directly or indirectly infringing Plaintiff’s rights, the
Plaintiff will be at liberty to file an appropriate application under Order I Rule 10 CPC for impleading the said
websites along with an affidavit with sufficient supporting evidence for seeking extension of the injunction to such
websites. Upon filing such applications before the Registrar, if the Registrar is satisfied, the websites will be
impleaded and the injunction shall be made operational against the said newly impleaded websites.”
Further, in addition to the afore-mentioned order dated 08.08.2025, we have filed an impleadment applications
before the Hon'ble High Court of Delhi, for impleading the new additional rouge websites and new Domain Name
about:blank

3/5

<!-- page 26 -->

10/3/25, 4:21 PM

Fwd: Compliance for the Order dated 23.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

Registrar as Defendant Nos. 146 - 218 and 219 - 314, which was listed before the Ld. Joint Registrar on 23.09.2025.
The Ld. Joint Registrar was inclined to pass an order in favour of the Plaintiff whereof a direction for impleading
the additional Defendant Nos. 146 - 218 and 219 - 314 was passed. The relevant extracts of the order dated
23.09.2025 for ease of reference.
“1………. .Keeping in view the contents of the suit and the application, the same is allowed. The proposed
defendants are impleaded as defendant nos. 146 to 218.
3. The order blocking the rogue-websites passed by the Hon’ble Court on 08.08.2025 shall operate qua the freshly
impleaded defendants as well, in terms of directions contained in para 36 of the order dated 08.08.2025. The
injunction order passed by the Hon’ble Court contained in para 35 (a) of the order dated 08.08.2025 shall operate
qua the newly impleaded rogue websites. Further, in terms of para 35 (b) and (c), the concerned DNR’s who are
already in the array and those impleaded today, are directed to lock and suspend / deactivate the rogue websites
impleaded today, and the concerned DNR’s are also directed to disclose complete details of the new rogue websites
in an affidavit within four weeks, to be filed in Court. Defendant nos. 47 to 55 / ISP’s and defendant nos. 56 and 57
are directed to take necessary steps qua defendant no. 59 to 138, as were given by the Hon’ble Court in paras 35
(d) and (e) of the order dated 08.08.2025.
4. .......... Keeping in view the contents of the suit and the application, the same is allowed. The proposed defendants
are impleaded as defendant nos. 219 to 314.
6. The order blocking the rogue-websites passed by the Hon’ble Court on 08.08.2025 shall operate qua the freshly
impleaded defendants as well, in terms of directions contained in para 36 of the order dated 08.08.2025. The
injunction order passed by the Hon’ble Court contained in para 35 (a) of the order dated 08.08.2025 shall operate
qua the newly impleaded rogue websites. Further, in terms of para 35 (b) and (c), the concerned DNR’s who are
already in the array and those impleaded today, are directed to lock and suspend / deactivate the rogue websites
impleaded today, and the concerned DNR’s are also directed to disclose complete details of the new rogue websites
in an affidavit within four weeks, to be filed in Court. Defendant nos. 47 to 55 / ISP’s and defendant nos. 56 and 57
are directed to take necessary steps qua defendant no. 219 to 309, as were given by the Hon’ble Court in paras 35
(d) and (e) of the order dated 08.08.2025."
In light of the above, you are hereby requested to comply with the order dated 23.09.2025, by immediately
issuing notifications to all ISPS for blocking the websites of Defendant Nos. 146-216 and 219-309.
The next date of hearing in the captioned matter is 08.01.2026 before the Ld. Joint Registrar and 20.01.2025
before the Hon'ble Court.
In compliance with the provisions of Order XXXIX Rule 3 of the Code of Civil Procedure, 1908, we are issuing
this notice as intimation of the ex-parte ad interim order passed by the Hon’ble Court on 08.08.2025 and also
service of the entire suit papers. The suit papers being voluminous, they can be downloaded from the link below:
https://drive.google.com/drive/folders/1IEhDuAdwA14UeN6Qwoa5MobNM7doyGpp
For your convenience, please find attached the Order dated 23.09.2025.
If you have any queries, please feel free to contact us.
Please acknowledge a safe receipt.
Regards
Ishi Singh

Documents Evidence for 2 application.pdf

2nd Impleadment Application.pdf

about:blank

4/5

<!-- page 27 -->

10/3/25, 4:21 PM

Fwd: Compliance for the Order dated 23.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

3rd Impleadment Application.pdf

Document Evidence 3rd application.pdf

Ishi Singh | Associate | Saikrishna & Associates| 57, Jor Bagh, New Delhi, India - 110003 |
Enrolment No. D/1977/2024
• MANAGING IP - Global Awards 2014- Firm of the Year - India – Contentious
• CHAMBERS - ASIA PACIFIC 2014 - Leading Firm
• CHAMBERS - ASIA PACIFIC 2014 - Star Individual- IP Litigation [Saikrishna Rajagopal]
• CORPORATE INTL MAGAZINE GLOBAL AWARD: Media Law - Law Firm of the Year in India2014
• CORPORATE INTL MAGAZINE GLOBAL AWARD: IP Litigation - Law Firm of the Year in India2014
• CLIENT CHOICE AWARDS - 2014 - Intellectual Property - Copyright – India
• INDIAN BUSINESS LAW JOURNAL- Law Firm Awards - Winner- Intellectual Property- India2013
• CHAMBERS- ASIA PACIFIC 2013 - Leading Firm
• WTR-1000- 2013- Recommended Firm
NOTE

The Information contained in this e-mail and/or in any of the attached files is confidential and
proprietary information of Saikrishna & Associates and also the subject of legal professional privilege.
This privilege is not waived or lost by mistaken transmission or receipt. If you are not the intended
recipient, any use, disclosure or copying of this mail is unauthorised. If you have received this mail in
error, please notify us at info@saikrishnaassociates.com immediately by reply email and destroy
the original.

about:blank

5/5

<!-- page 28 -->

10/3/25, 4:19 PM

Fwd: Compliance for the Order dated 24.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

Fwd: Compliance for the Order dated 24.09.2025 passed by the Hon'ble High Court of
Delhi in CS(COMM) 810 of 2025: JioStar India Private Limited v. serialmaza.my & Ors

Manish Shukla < dirit.hq-dgt-dot@gov.in >
Fri, 26 Sep 2025 10:08:01 AM +0530

To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>
Cc "Kripa Shanker Pandey"<adt.hq-dgt-dot@gov.in>

3 Attachment(s)
4th Impleadment Application fi…

5th Impleadment Application fi…

4.2 MB

3.8 MB

24.09.2025.pdf
128.5 KB

हार्दिक शुभकामनाओं के साथ/ With warm regards,
मनीष शुक्ला/ Manish Shukla
निदेशक (टी), डीजीटी मुख्यालय/ Director (T), DGT HQ

============ Forwarded message ============
From: Cyber Law Legal <cyberlaw-legal@meity.gov.in>
To: "adgnthq-dgt-dot"<adgnt.hq-dgt-dot@gov.in>, "Manish Shukla"<dirit.hq-dgtdot@gov.in>
Cc: "Deepak Goel"<gccyberlaw@meity.gov.in>, "Sathyanarayanan Subramanian"
<sathya.s@meity.gov.in>, "Avneet Toor Gupta"<avneett.g@nic.in>, "Nagarajan N"
<nagarajan.n@meity.gov.in>
Date: Thu, 25 Sep 2025 17:41:33 +0530
Subject: Fwd: Compliance for the Order dated 24.09.2025 passed by the Hon'ble High
Court of Delhi in CS(COMM) 810 of 2025: JioStar India Private Limited v. serialmaza.my &
Ors
============ Forwarded message ============

Dear Sir,
Request your attention to the trailing email as under. Would appreciate, if you could review it and
take necessary action, as required.
Kindly, inform us once the needful has been done.
about:blank

1/5

<!-- page 29 -->

10/3/25, 4:19 PM

Fwd: Compliance for the Order dated 24.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

Thanks and Regards
Nagarajan. N
Scientist C
Cyberlaw Division
Ministry of Electronics and Information Technology (MeitY)
Tel: 9310759547

============ Forwarded message ============
From: Ishi Singh <ishi@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Ram Meena"<dirds2-dot@nic.in>, "Cyber Law Legal"<cyberlawlegal@meity.gov.in>, "Dr. Sandip Chatterjee"<gccyberlaw@meity.gov.in>, "Prafulla Kumar"
<pkumar@meity.gov.in>, <sathya.s@meity.gov.in>
Cc: "Yatinder Garg"<yatinder@saikrishnaassociates.com>, "Priyansh Kohli"
<priyansh@saikrishnaassociates.com>, "Ashok Yadav"<ashok.yadav1@jiostar.com>
Date: Thu, 25 Sep 2025 14:12:34 +0530
Subject: Compliance for the Order dated 24.09.2025 passed by the Hon'ble High Court of
Delhi in CS(COMM) 810 of 2025: JioStar India Private Limited v. serialmaza.my & Ors
============ Forwarded message ============
Dear Sir,
We act on behalf of JioStar India Pvt. Ltd. (‘JioStar’) having their office at Star House, Urmi Estate, 95, Ganpatrao
Kadam Marg, Lower Parel (W), Mumbai – 400013, (hereinafter referred to as “Our Client”). Our Client is the
Plaintiff in the above-captioned suit.
Our Client is the producer of various TV Shows, films and/or web series which are communicating on JioStar
Channels and/ or JioHotstar and has exclusive rights in such works (Plaintiff’s Work) as enumerated under
Section14(d) of the Copyright Act, 1957, including inter alia to publicly exhibits and communicate the said content
through any medium or mode including on JioStar Channels or JioHotstar. Our Client is thus the sole and exclusive
owner of the copyright and Broadcast Reproduction Rights in relation to the aforesaid broadcasts of general
entertainment content communicated through the JioStar Channels and JioHotstar, as per Section 37 and 17 of the
Copyright Act, 1957.
Our Client has instituted the above-captioned Suit against various ‘rogue’ websites inter alia the Defendant Nos. 1
to 35 (“Defendant Websites”) before the Hon’ble High Court of Delhi, inter alia, seeking permanent and exparte ad-interim and temporary injunction restraining violation of its exclusive statutory rights in relation to the
Plaintiff’s Work as well as for other reliefs.
Our Client has also arrayed various Domain Name Registrars (Defendant No.36-46) , Internet and Telecom Service
Providers (ISPs), (Defendant No. 47 – 55) as well as the concerned Government departments i.e. Department of
Telecommunication (DoT) (Defendant No.56), the Ministry of Information and Technology (MEITY) (Defendant
No.57) to ensure effective compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
The above-mentioned matter came up before the Hon’ble Justice Manmeet Singh Arora, Delhi High Court on
08.08.2025, on which date, the Hon’ble Court was pleased to issue notice to you and was also pleased to pass an exparte ad-interim order (Injunction Order) in terms of Prayer Clause in terms of application under Order XXXIX
Rules 1 and 2. The relevant para of the Order dated 08.08.2025 is extracted herein below:
“35. Accordingly, till the next date of hearing the following directions are issued:
a.
Defendant nos.1 to 35 including their owners, partners, proprietors, officers, servants, affiliates, employees,
and all others in capacity of principal or agent acting for and on its behalf, or anyone claiming through, by or
under it, are restrained from in any manner communicating to the public, hosting, storing, reproducing, streaming,
broadcasting, rebroadcasting, causing to be seen or heard by public on payment of charge and/or making available
for viewing Plaintiff’s content through their websites including those listed as under:

Defendant No.
1.
2.
about:blank

Defendant Websites
serialmaza.my
5movierulz.cash
2/5

<!-- page 30 -->

10/3/25, 4:19 PM

Fwd: Compliance for the Order dated 24.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.

zolomovies.biz
tudhadkanmaindil.com
yomovies1.bond
tamildhool.net
sungohd.com
vegamovies-nl.quest
vegamovies-nl.bio
shivshaktiserials.com
movies4u.mba
movienest.lol
mkvcinemas.men
mangallakshmiserial.com

15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.

khatronkekhiladi.net
hdmovie2.yoga
bolly4u.video
biggbosstoday.net
biggbossott3.com
bdhdmusic23.cc
hdhub4u.fail
hdhub4u.family
hdmovie2.computer
hdmovie2.shoes
q.hdhc.site
bromovies.tv
bollyflix.dance
5movierulz.life
5movierulz.dance
1pogolinks.site
1tamilcrow.net
biggboss.my
fullserials.xatab.top
go5pm.com
ww1.couchtuner.guru

b. Defendant nos. 36 to 46 are directed to lock and suspend/deactivate the above mentioned domains/subdomains
of the infringing websites.
c.
Defendant nos. 36 to 46 are directed to disclose complete details [inter alia name, address, email, phone
number and IP address] of Defendant nos. 1 to 35, and mode of payment along with payment details used for
registrations of the said domain names. The said disclosure shall be made by an affidavit and be filed before this
Court within a period of four weeks.
d.
Defendant nos. 47 to 55 [ISPs] are directed to block access to these infringing websites tabulated above,
within 48 hours of receipt of this order.
e.
Defendant nos. 56 [i.e. DoT] and 57 [i.e., MEITY] shall take steps to ensure that ISPs comply with the
directions issued above, through appropriate communications and notices sent to the said ISPs, including other
ISPs which are registered with them.
f.
In case, there is any work in respect whereof there is any dispute as to the ownership of the copyright, an
application may be moved by the affected party before the Court, to seek clarification.
36. In the facts of this case, the Plaintiff has also prayed for a dynamic injunction to protect its copyrighted works
from the hydra-headed websites, as soon as they are created. This Court is satisfied in the facts of this case dynamic
injunction ought to be issued to protect the Plaintiff’s copyrighted works.
36.1. It is thus further directed that if any other mirror/alphanumeric/similar/redirect variation of the websites
identified in the suit as Defendant Nos. 1 to 35 are found to be directly or indirectly infringing Plaintiff’s rights, the
Plaintiff will be at liberty to file an appropriate application under Order I Rule 10 CPC for impleading the said
websites along with an affidavit with sufficient supporting evidence for seeking extension of the injunction to such

about:blank

3/5

<!-- page 31 -->

10/3/25, 4:19 PM

Fwd: Compliance for the Order dated 24.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

websites. Upon filing such applications before the Registrar, if the Registrar is satisfied, the websites will be
impleaded and the injunction shall be made operational against the said newly impleaded websites.”
Further, in addition to the afore-mentioned order dated 08.08.2025, we have filed an impleadment applications
before the Hon'ble High Court of Delhi, for impleading the new additional rouge websites and new Domain Name
Registrar as Defendant Nos. 315 - 382 and 383 - 448, which was listed before the Ld. Joint Registrar on 24.09.2025.
The Ld. Joint Registrar was inclined to pass an order in favour of the Plaintiff whereof a direction for impleading
the additional Defendant Nos. 315 - 382 and 383 - 448
was passed. The relevant extracts of the order dated
24.09.2025 for ease of reference.
“1……… Keeping in view the contents of the suit and the application, the same is allowed. The proposed defendants
are impleaded as defendant nos. 315 to 382 .
3. The order blocking the rogue-websites passed by the Hon’ble Court on 08.08.2025 shall operate qua the freshly
impleaded defendants as well, in terms of directions contained in para 36 of the order dated 08.08.2025. The
injunction order passed by the Hon’ble Court contained in para 35 (a) of the order dated 08.08.2025 shall operate
qua the newly impleaded rogue websites. Further, in terms of para 35 (b) and (c), the concerned DNR’s who are
already in the array and those impleaded today, are directed to lock and suspend / deactivate the rogue websites
impleaded today, and the concerned DNR’s are also directed to disclose complete details of the new rogue websites
in an affidavit within four weeks, to be filed in the Court. Defendant nos. 47 to 55 / ISP’s and defendant nos. 56 and
57 are directed to take necessary steps qua defendant no. 315 to 380, as were given by the Hon’ble Court in paras
35 (d) and (e) of the order dated 08.08.2025 .
4. .......... Keeping in view the contents of the suit and the application, the same is allowed. The proposed defendants
are impleaded as defendant nos. 383 to 448.
6. The order blocking the rogue-websites passed by the Hon’ble Court on 08.08.2025 shall operate qua the freshly
impleaded defendants as well, in terms of directions contained in para 36 of the order dated 08.08.2025. The
injunction order passed by the Hon’ble Court contained in para 35 (a) of the order dated 08.08.2025 shall operate
qua the newly impleaded rogue websites. Further, in terms of para 35 (b) and (c), the concerned DNR’s who are
already in the array and those impleaded today, are directed to lock and suspend / deactivate the rogue websites
impleaded today, and the concerned DNR’s are also directed to disclose complete details of the new rogue websites
in an affidavit within four weeks, to be filed in the Court. Defendant nos. 47 to 55 / ISP’s and defendant nos. 56 and
57 are directed to take necessary steps qua defendant no. 383 to 446, as were given by the Hon’ble Court in paras
35 (d) and (e) of the order dated 08.08.2025."
In light of the above, you are hereby requested to comply with the order dated 24.09.2025, by immediately
issuing notifications to all ISPS for blocking the websites of Defendant Nos. 315-380 and 383 - 446 .
The next date of hearing in the captioned matter is 08.01.2026 before the Ld. Joint Registrar and 20.01.2025
before the Hon'ble Court.
In compliance with the provisions of Order XXXIX Rule 3 of the Code of Civil Procedure, 1908, we are issuing
this notice as intimation of the ex-parte ad interim order passed by the Hon’ble Court on 08.08.2025 and also
service of the entire suit papers. The suit papers being voluminous, they can be downloaded from the link below:
https://drive.google.com/drive/folders/1IEhDuAdwA14UeN6Qwoa5MobNM7doyGpp
For your convenience, please find attached the Order dated 24.09.2025.
If you have any queries, please feel free to contact us.
Please acknowledge a safe receipt.
Regards
Ishi Singh

Evidence Document list 4.pdf

Documents Evidence for list 5.pdf
about:blank

4/5

<!-- page 32 -->

10/3/25, 4:19 PM

Fwd: Compliance for the Order dated 24.09.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 810 of 2025: JioSta…

Ishi Singh | Associate | Saikrishna & Associates| 57, Jor Bagh, New Delhi, India - 110003 |
Enrolment No. D/1977/2024
• MANAGING IP - Global Awards 2014- Firm of the Year - India – Contentious
• CHAMBERS - ASIA PACIFIC 2014 - Leading Firm
• CHAMBERS - ASIA PACIFIC 2014 - Star Individual- IP Litigation [Saikrishna Rajagopal]
• CORPORATE INTL MAGAZINE GLOBAL AWARD: Media Law - Law Firm of the Year in India2014
• CORPORATE INTL MAGAZINE GLOBAL AWARD: IP Litigation - Law Firm of the Year in India2014
• CLIENT CHOICE AWARDS - 2014 - Intellectual Property - Copyright – India
• INDIAN BUSINESS LAW JOURNAL- Law Firm Awards - Winner- Intellectual Property- India2013
• CHAMBERS- ASIA PACIFIC 2013 - Leading Firm
• WTR-1000- 2013- Recommended Firm
NOTE

The Information contained in this e-mail and/or in any of the attached files is confidential and
proprietary information of Saikrishna & Associates and also the subject of legal professional privilege.
This privilege is not waived or lost by mistaken transmission or receipt. If you are not the intended
recipient, any use, disclosure or copying of this mail is unauthorised. If you have received this mail in
error, please notify us at info@saikrishnaassociates.com immediately by reply email and destroy
the original.

about:blank

5/5

<!-- page 33 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
