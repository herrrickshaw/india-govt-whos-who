---
doc_id: "dbc9986bcbe40dfa"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2026/09/b2c23e72d016aa65062e797e87c1c393.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Standard Operating Procedure for Pre-hospital Care in Road Traffic Injuries"
date: "2026-09-28"
pages: 29
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d6bd01f0a31e9572"
---

<!-- page 1 -->

4790271/2026/HOSPITAL-II

Standard Operating
Procedure for Pre-hospital
Care in Road Traffic Injuries
Trauma and Burn Division
Directorate General of Health Services
Ministry of Health and Family Welfare
Government of India

4
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

<!-- page 2 -->

4790271/2026/HOSPITAL-II

Table of Contents:
Chapter

Title of the chapter

Page Number

1

Introduction

5

2

Prehospital Care

6

3

Step 1: Care at Scene: On Call and At scene
(Emergency Call Response)

8

4

Step 2: En-route Care (Ambulance Based
Management by EMTs)

14

5

Step 3: Referral and Hand over at Hospital

18

6

Step 4: Reaching Health Care Facility and
Documentation

19

7

Training and Capacity Building

20

8

Monitoring and Evaluation

21

9

The Role of Teleconsultation in Pre-Hospital Care

23

Title

Page Number

List of figures

Figure
1

Steps to follow at the emergency scene

9

2

Process following a road-crash

10

3

X-ABCDE approach

11

4

Personnel in post-crash response

12

5

Flow chart of the process following a crash

13

6

Key components of En-route care

14

7

Pre-hospital communication process of the command
centre

15

5
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

1|Page

<!-- page 3 -->

4790271/2026/HOSPITAL-II

Abbreviations

ACLS

Advanced Cardiovascular Life Support

ALS

Advanced Life Support

AIS

Automotive Industry Standard

BVM

Bag-Valve Mask

BLS

Basic Life Support

BP

Blood Pressure

CPR

Cardiopulmonary Resuscitation

CT

Computed Tomography

ED

Emergency Department

EMS

Emergency Medical Services

EMT

Emergency Medical Technician

ERS

Emergency Response System

ETA

Estimated Time of Arrival

FAST

Focussed Assessment with Sonography in Trauma

GPS

Global Positioning System

HAZMAT

Hazardous materials

HR

Heart Rate

ICU

Intensive Care Unit

MRI

Magnetic Resonance Imaging

NELS

National Emergency Life Support

NS

Normal Saline

PTV

Patient Transport Vehicle

RR

Respiratory Rate

SpO2

Peripheral Oxygen saturation

STEMI

ST Segment Elevated Myocardial Infraction

6
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

2|Page

<!-- page 4 -->

4790271/2026/HOSPITAL-II

List of Contributors
Dr. Arin Choudhury
Department of Emergency Medicine,
VMMC and Safdarjung, New Delhi
Dr. Amlendu Yadav
Professor and HOD, Emergency Medicine,
Dr RML Hospital, New Delhi

Dr. Sanjay Kumar
Professor and HOD, Emergency Medicine,
LHMC, New Delhi
Dr. Sanjeev Bhoi
Professor, Emergency Medicine, JPNATC,
AIIMS, New Delhi

Dr. Krishan Kumar
CMO(SAG), Dte.GHS

Dr. Sushma Adappa
National Consultant (Trauma and Burns),
WHO India
Dr. Manas Pratim Roy
Dr. L Swasticharan
Assistant Director General, Dte.GHS
Director EMR & DDG, Dte.GHS
Dr. Mohammed Asheel B
Dr. Swati Sharma
NPO, Injury and Disability Prevention, WHO Consultant (Trauma and Burns), Dte.GHS
India
Dr. Priya Redhu
Dr. Tej Prakash Sinha
Consultant (Trauma and Burns), Dte.GHS
Additional Professor, Emergency Medicine,
JPNATC, AIIMS, New Delhi

7
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

3|Page

<!-- page 5 -->

4790271/2026/HOSPITAL-II

Definitions
1. Emergency Medical Services (EMS): A comprehensive system that provides
arrangements of personnel, facilities, and equipment for the effective delivery of
emergency medical care to individuals with sudden illness or injury.
2. Pre-Hospital Care: Emergency medical services rendered to patients for analytic,
resuscitative, stabilizing, or preventative purposes, prior to and during transportation to
healthcare facilities.
3. Basic Life Support (BLS): A level of pre-hospital and inter-hospital emergency care
that includes airway management, administration of basic medications,
cardiopulmonary resuscitation (CPR), control of shock and bleeding, and splinting of
fractures.
4. Advanced Life Support (ALS): An advanced level of pre-hospital and inter- hospital
emergency care that includes BLS functions plus cardiac monitoring, defibrillation,
electrocardiography, intravenous therapy, administration of medications, and other
advanced techniques.
5. Ambulance: A medically equipped vehicle used to transport patients to treatment
facilities, such as hospitals, typically providing out-of-hospital medical care during
transport.
6. Emergency Response System (ERS): An electronic device that enables high- risk
individuals to secure immediate help in the event of a physical, emotional, or
environmental emergency.
7. Golden Hour: The critical period immediately following a traumatic injury, during
whichthereisthehighestlikelihoodthatpromptmedicalandsurgicaltreatment will prevent
death.
8. Emergency Medical Technician (EMT): A health care provider trained to provide
emergency medical services to the sick and injured.
9. Life Threatening: An injury or Illness that is acute, with sudden onset of symptoms
and poses an immediate risk to a person's life or long-term health

8
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

4|Page

<!-- page 6 -->

4790271/2026/HOSPITAL-II

Chapter 1: Introduction
Road accidents represent a significant global public health crisis, consistently ranking among
the leading causes of death, particularly impacting individuals in their most productive years,
aged 15 to 49. In India, MoRTH 2023 report revealed that road crashes claimed approximately
1.73 lakh lives and injured 4.63 lakh people.
Given that road accidents are a complex outcome of multiple interacting factors, a multipronged strategy is imperative to mitigate both their frequency and severity. While prevention
efforts, robust infrastructure, and stringent enforcement are foundational, the crucial phase after
an accident occurs known as pre-hospital care often dictates the difference between life and
death, or between recovery and permanent disability.
The paramount importance of effective pre-hospital care cannot be overstated, especially in the
context of road traffic injuries. The immediate aftermath of a crash is often referred to as the
"Golden Hour," a critical window during which prompt and appropriate medical intervention
can dramatically improve survival rates and reduce the severity of long-term injuries. Rapid
response, on-scene stabilization, and timely, safe transport to a definitive care facility are
essential to manage haemorrhage, secure airways, and address other life-threatening conditions
common in trauma. Without a well-orchestrated pre-hospital system, even the most advanced
hospital care may be rendered ineffective if the patient arrives too late or in an unsalvageable
state.
Beyond road traffic injuries, pre-hospital care is equally vital for a broad spectrum of medical
and trauma emergencies, including cardiac events, strokes, burns, poisonings, occupational
injuries, falls and mass casualty incidents. In all these scenarios, the ability of first responders
whether laypersons or trained EMTs to provide immediate medical attention, alert appropriate
services, and ensure efficient patient transfer significantly influences outcomes. It serves as the
critical initial link in the continuum of emergency healthcare, ensuring that life-saving
interventions begin at the earliest possible moment, outside the traditional hospital setting.
Across the world, pre-hospital care systems are structured around two principal
operational models. The Anglo-American model, characterized by a “scoop-and-run”
approach, is led by paramedics and EMTs who prioritize rapid transport of patients to hospitals
for definitive care (as seen in the USA and UK). In contrast, the Franco-German model follows
a “stay-and-play” approach, deploying physician-led teams to provide advanced on-scene
stabilization before patient transport (adopted in countries such as Germany and France).
India’s Emergency Medical Services (EMS) framework is fundamentally aligned with the
Anglo-American model, based on non-physician providers with a "scoop-and-run" principle.
However, this system is undergoing rapid and strategic evolution to address the nation's
immense geographical and demographic complexities.
In line with these global learnings and national priorities, the primary objective is to
institutionalize a structured, responsive, and technologically enabled EMS ecosystem. These
guidelines aim to ensure timely medical attention, coordinated multi-agency response, and
equitable access to quality emergency care across the country.

9
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

5|Page

<!-- page 7 -->

4790271/2026/HOSPITAL-II

Chapter 2: Prehospital Care
Prehospital care is a critical part of the emergency healthcare system, providing immediate
medical attention to patients at the scene of an incident before they arrive at a hospital. This
care is delivered through a well-coordinated system that includes first responders, trained
professionals at dispatch centers, ambulances and trauma care facilities. The entire process
relies on standardized protocols and guidelines to ensure seamless care.
A strong prehospital care system is defined by its ability to efficiently connect emergency
dispatch with first responders at the scene and to have a swift and effective transport system to
take the patient to the nearest and most appropriate health facility. This integrated approach
ensures that patients receive timely and expert care from the moment of the emergency through
their arrival at the hospital.
The fundamental goal of prehospital care is to minimise morbidity and mortality outside of the
hospital setting. This is accomplished through two key actions:
1. Timely and appropriate interventions: Providing immediate medical care to stabilize
the patient at the scene.
2. Safe and timely transport: Ensuring rapid and secure movement of the patient to the
most suitable medical facility for definitive care.
Objectives of Prehospital Care:
1. To define and standardize the essential components, protocols, and steps for effective
and consistent pre-hospital care delivery.
2. To strengthen the capacity of both lay first responders and professional paramedics
through enhanced training and skill development, ensuring timely and effective
interventions.
3. To increase public awareness and participation to ensure timely initial response to
emergencies.
4. To integrate and leverage telemedicine solutions to extend expert medical guidance to
the field and optimize emergency care delivery.
5. To implement robust monitoring and evaluation frameworks for continuous assessment,
quality assurance, and ongoing improvement of pre-hospital services.
Key components of Prehospital Care:
A well-functioning prehospital care systems rely on the coordinated efforts of several
interconnected elements:
•

Trained Professionals: A tiered system of professionals, from laypersons providing
basic first aid to highly skilled paramedics, who can assess, stabilize, and treat patients
in an emergency. Defined roles help to avoid duplication and unnecessary delay.

•

Essential Equipment: This includes a fleet of well-maintained ambulances, reliable
communication systems, and all necessary medical supplies for both basic and advanced
life support.

•

Robust Command Center: An efficient dispatch and command center is vital for
coordinating the response, directing resources, and facilitating information exchange
10

File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

6|Page

<!-- page 8 -->

4790271/2026/HOSPITAL-II

among all stakeholders. Many of our states maintain a control room/ command centre
for movement of ambulances, as health is a state subject.
•

Efficient Transport Systems: Ambulances (ACLS, BLS, PTV etc) must be available
to match the patient's condition, the severity of their injury, and the distance to the
appropriate receiving facility.

•

Medical Direction and Oversight: A critical link between prehospital providers and
physicians, often through teleconsultation (e-Sanjeevani), provides real-time guidance
and medical direction for treatment decisions in the field.

•

Continuous Quality Improvement: Ongoing evaluation and analysis of data are
essential to monitor system efficiency, identify areas for improvement, and enhance
patient care.

Steps in Prehospital Care
The steps in prehospital care include:
1. Step 1: Care at Scene: On Call and At scene (Emergency Call Response)
2. Step 2: En-route Care (Ambulance Based Management by EMTs)
3. Step 3: Referral and Hand over at Hospital

11
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

7|Page

<!-- page 9 -->

4790271/2026/HOSPITAL-II

Chapter 3: Care at Scene: On Call and At scene (Emergency Call Response)
The first moments of an emergency are often managed by lay responders, or "Good
Samaritans"—bystanders, community members, or passers-by who are the first on the scene.
Their quick and informed actions are a crucial link in the "Chain of Survival" and can
significantly improve patient outcomes.
a. For Lay Responders (Good Samaritan):
Lay responders can provide basic, yet vital, emergency care such as applying direct pressure to
control bleeding or performing Hands-Only CPR. In 2016, the Indian Supreme Court formally
incorporated the Good Samaritan guidelines into law, which were then codified by Parliament
into the Motor Vehicles Act in 2019. This step was taken to protect and encourage bystanders
to assist victims of road accidents without fear of legal and procedural harassment.
Section 134A of Motor Vehicle Act, 2019 stipulates “A Good Samaritan shall not be liable for
any civil or criminal action for any injury to or death of the victim of an accident involving a
motor vehicle, where such injury or death resulted from the Good Samaritan’s negligence in
acting or failing to act while rendering emergency medical or non-medical care or assistance."
1. Assess the Situation and Ensure Safety
o
o

Ensure personal safety and assess surroundings for potential hazards such as
live wires, fire, leaking fuel or traffic, etc.
Victims should be moved only if the environment poses an immediate threat to
life (e.g., fire, water submersion, explosion risk).

2. Check Patient’s Condition
o
o

o
o

Responsiveness: Gently shake the person's shoulders and call out to check if
they are conscious.
Breathing and Pulse: Check for normal breathing by observing chest
movement. If you are trained and find no pulse or breathing, immediately
begin Hands-Only CPR.
Bleeding: Control any visible bleeding by applying pressure with a clean cloth.
Only use a tourniquet if you are professionally trained to do so.
Sprinkling water on face or trying to feed water or liquids or any other such
unwarranted actions are not recommended.

3. Call for Help (Activate EMS/112 Ambulance)

There are various emergency numbers such as 102,108,1033 etc which needs to be
integrated with 112 to improve real time dispatch and optimization of response times.
Dial 112, the national integrated emergency response number, operational 24*7 in
India since 2019 for citizens in emergencies.
As per NHM recommendation, the ambulance response time for reaching the accident
site should be within 30 minutes for rural areas and 20 min for urban areas after
receiving the call. It also recommends the patient should reach the health facility
within the next 30 min as a quality benchmark.
4. Lay Responders will also provide Basic First Aid while waiting for EMTs in

the following ways:
12
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

8|Page

<!-- page 10 -->

4790271/2026/HOSPITAL-II

•
•
•
•
•

For a person experiencing cardiac arrest, it may be helpful to perform hands-only
CPR (chest compressions).
For bleeding, pressure may be applied to the wound using a clean cloth.
If a person has a fracture, immobilize the affected limb to prevent further injury.
Avoid moving the injured limb unnecessarily.
For burns, it may be beneficial to cool the area with running water
For suspected poisoning, vomiting should not be induced unless instructed by a
medical professional.

Figure 1: Steps to follow at the emergency scene

Assurance and support for lay responders
o

Awareness of Legal Protection:
➢ Individuals must be aware of Good Samaritan Law which protects them from
being forced to reveal their identity when they assist someone who is injured.
➢ Individuals cannot be forced to serve as a witness in medico-legal cases, such
as road traffic injuries, without their explicit permission, as per the Good
Samaritan Law.
➢ The Good Samaritan Law protects individuals from being compelled by
hospitals to pay bills when assisting an injured person by bringing them to the
facility for emergency care.

o

Clear Guidance: Emergency response centers/ Command centers should provide
clear, calm instructions to bystanders on how to manage the situation until
professional help arrives.

o

Focus on Information: Bystanders should be assured that their role is to provide
relevant information to the Command Center. Provide relevant information
regarding the accident/incident location, number of people injured and severity.
13

File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

9|Page

<!-- page 11 -->

4790271/2026/HOSPITAL-II

Figure 2: Process following a road-crash (image generated by Microsoft Co-pilot)

b. Despatching equipped ambulance

Following a crash, it is important to locate the site quickly. Every effort should be made to
avoid unnecessary delay due to unclear directions. The closest and most appropriately equipped
emergency unit should be activated by the Command Centre. Relevant factors like severity,
number of casualties, and environmental hazards should be considered. If required, there is a
need to coordinate with fire services and police. Communication to traffic police is required to
prevent secondary accidents. Specialized teams (neonatal, critical care, mental health,
HAZMAT) may be sent, based on need and geography. There should be a provision of
escalation, in case the situation worsens
c. On-Scene care by emergency medical technicians (EMTs)

After a lay responder has initiated basic first aid, an Emergency Medical Technician (EMT)
arrives. The EMTs’ main goals are to perform a rapid assessment, provide life-stabilizing care,
and prepare the patient for safe transport to a hospital. Their actions are critical for improving
patient outcomes, especially in cases of trauma, stroke, cardiac and poisoning emergencies.
Role of EMTs at the Scene
1. Scene Assessment and Safety:
o
o
o

First, ensure the safety of yourself and bystanders.
Identify any immediate life-threatening conditions.
Call for additional support, such as fire or police services, if needed.

14
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

10 | P a g e

<!-- page 12 -->

4790271/2026/HOSPITAL-II

2. Perform Primary Survey (X-ABCDE Approach)

o X- Exsanguination:
Identify and Stop severe
bleeding using cloth, gauze,
or scarves with firm
pressure or tourniquet (if
trained).
o A-Airway: Ensure the
airway is clear and secure it
if compromised, using Jawthrust or chin-lift, clear
obstructions
o B-Breathing:
Assess
breathing rate and effort
and provide oxygen if
needed.
o C-Circulation:
Check
pulse, BP, signs of shock,
and control bleeding.
o D-Disability:
Assess
neurological status using
the AVPU (Alert, Verbal,
Pain, Unresponsive) or
GCS (Glasgow Coma
Scale).
o E-Exposure:
Remove
clothing to check hidden
injuries while preventing
hypothermia.
Figure 3: X-ABCDE approach

15
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

11 | P a g e

<!-- page 13 -->

4790271/2026/HOSPITAL-II

Figure 4: Personnel in post-crash response

3. Condition-Specific Interventions

As we encourage an integrated approach where trauma and other emergencies are
managed simultaneously, such practices should be built within the system.
o Trauma (Road Traffic Injuries, Falls): Cervical spine immobilization using
collars and spine boards, control bleeding and splint fractures with the help
of padded boards.
o Stroke: Use FAST (Face drooping, Arm weakness, Speech difficulty, Time
to call) assessment, elevate head, check blood sugar, prioritize transport to
stroke- ready hospitals and document exact onset time.
o Myocardial Infarction (chest pain): Give aspirin, nitroglycerin
sublingually, perform ECG if available. Monitor chest pain and vitals.
o Snake Bite: Immobilize the affected limb with a splint, do not elevate, avoid
cutting or sucking the wound, and transport urgently.
o Poisoning: Avoid contact with substance, remove contaminated clothing if
chemical exposure, administer activated charcoal if appropriate, manage the
airway and carry sample of ingested substance.
o Mass casualty: A plan should be there in place, including triage, in case
there are multiple victims
Early defibrillation, glucose and sepsis screening, obstetric emergencies may be
considered.
4. Prepare for Patient Transport and Communicate with the Hospital:

Secure the patient on a stretcher or spine board, head immobiliser.
Continue monitoring vitals- Pulse, BP, SpO2, such provisions should be there
in the ambulance.
o A standardised protocol should be followed for performing scene site triage,
including priority care and initial assessment, to ensure timely and
appropriate care delivery
o Maintain communication:
o
o

16
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

12 | P a g e

<!-- page 14 -->

4790271/2026/HOSPITAL-II

▪

Notify the receiving hospital (pre-arrival notification) of ETA,
condition and interventions
• To prevent delays in emergency care, hospitals should give
prior notice if any essential services are not working, such as
CT/MRI scans or lack of available beds. This helps to ensure
patients are redirected in time and do not face delays in
receiving emergency care

▪

Use telecommunication system if integrated

Figure 5: Flow chart of the process following a crash

17
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

13 | P a g e

<!-- page 15 -->

4790271/2026/HOSPITAL-II

Chapter 4: Step 2: En-route Care (Ambulance Based Management by EMTs)
En-route care serves as the vital bridge between on-scene stabilization and definitive treatment
at a healthcare facility. During this critical "Golden Hour," EMTs must focus on monitoring,
managing deterioration, and continuing resuscitation, while ensuring real-time communication
with hospitals to ensure timely and medically appropriate transport of trauma victims from the
accident site to healthcare facilities using ambulances.
Optimizing prehospital time is a key indicator of a high-quality emergency medical system. The
efficiency of this process is influenced by where ambulances are strategically positioned and
how well personnel are prepared.
The total prehospital time is broken down into four key components:
o Notification Time is the time elapsed from the occurrence of the injury until the
prehospital or ambulance system is notified. It is influenced by the availability
of telecommunications.
o Response Time is the time elapsed from the notification until arrival of an
ambulance to the site of the ill or injured person. It is influenced by capabilities
of a dispatch center to handle emergency calls and especially by geographic
distribution of sites of ambulance dispatch. Traffic congestion, poor maps and
poor road signs may all increase the response time
o Scene Time is the time elapsed from the arrival of prehospital providers on the
scene until departure
o Transport Time is the time elapsed from the departure from the scene until
arrival at the hospital or other treatment facility

Figure 6: Key components of En-route care

18
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

14 | P a g e

<!-- page 16 -->

4790271/2026/HOSPITAL-II

India’s ambulance infrastructure is guided by the Automotive Industry Standard (AIS-125),
which classifies vehicles into four types based on equipment and staffing. Each type addresses
different medical transport needs.
o Type A Ambulance /Medical First Responder – does not have the capability to
transport patients in supine state or provide them medical care inside the vehicle.
o Type B Road Ambulance/ Patient Transport Vehicle – designed and equipped
for the transport patients who are not expected to become emergency patients.
o Type C Road Ambulance: Basic Life Support Ambulance with appropriately
equipped staff for transport and treatment of patients requiring non-invasive
airway management, basic monitoring.
o Type D Road Ambulance: Advanced Life Support Ambulance with
appropriately equipped staff for transport and treatment of patients requiring
invasive airway management/intensive monitoring.

•

Ambulance preparedness and regulatory checks:
•

A command system for ambulance dispatch and coordination should be in
operation. Both private and government ambulances should be considered for
optimum use of the available resources. Ambulances are dispatched to scene
sites based on orders or requests from the dispatch system, ensuring coordinated
response. These ambulances must be equipped with GPS trackers, enabling realtime location identification and tracking. This will make it possible to direct an
ambulance carrying a critical patient to the nearest equipped hospital, thus
saving precious time during golden hour.

Figure 7: Pre-Hospital Communication Process of the Command Centre

•

Strategic Allocation:
➢ Ambulances are allocated based on population density or facility
demand/requirement, ensuring appropriate coverage. At present, for
every 500,000 people, one Advanced Life Support (ALS) ambulance is
recommended, while one Basic Life Support (BLS) ambulance is
suggested for every 100,000
19 people.

File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

15 | P a g e

<!-- page 17 -->

4790271/2026/HOSPITAL-II

➢ Appropriate and strategically located spaces are available for parking
and stationing ambulances, facilitating rapid deployment and alignment
with high-risk areas.
➢ Use heatmaps based on traffic and accident data to guide the distribution
of BLS (Basic Life Support) and ALS (Advanced Life Support)
ambulances.
•

Manpower and Training: EMT Personnel should have clear knowledge of the
distinctions between and appropriate uses of BLS and ACLS ambulances

•

Equipment and Documentation:
➢ Ambulances should be stocked with essential equipment and life-saving
medications, all verified against a comprehensive checklist in accordance
with AIS-125 specifications.
➢ EMTs must meticulously maintain a logbook and a standardized clinical
document for each patient to ensure continuity of care.

•

Yearly monitoring and surveillance of the ambulance services are to be
conducted.

Key Components for Enhanced Ambulance Setups
A highly effective ambulance system relies on two critical pillars: skilled manpower and robust
functional readiness.
1. Manpower:
•
•
•

Trained Staff: All ambulances in the fleet should be equipped with a dedicated
ambulance driver and at least one trained EMT.
Continuous Education: EMTs must be certified by accredited authority along with
yearly training to maintain skills to perform cases.
Teleconsultation: Emergency medical doctors provide tele-consultation to EMTs in the
field when needed, with the frequency of such consultations noted.

2. Functional requisites:
a. Equipment and Supplies:
i. EMTs can maintain checklist for the equipment to facilitate first aid/
emergency management available within the ambulance.
ii. The ambulance should be equipped with essential basic equipment for
patient transfer and care, including a stretcher, cervical collar, tourniquet,
splints, spineboard, and oxygen, noting when this equipment was last
observed.
iii. A comprehensive checklist is maintained for all life-saving medications
available within the ambulance.
b. Regulatory Standards: The items in the checklist should be in accordance with
AIS-125 Specifications to ensure20consistency and quality.
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

16 | P a g e

<!-- page 18 -->

4790271/2026/HOSPITAL-II

c. Documentation: A logbook should be diligently maintained and filled out by
EMTs. Standardised documents detailing the clinical condition of the injured
person to be completed for each patient.
Steps to be performed by EMTs:
1. Maintain Airway and Breathing Support
o
o
o

Keep the airway open. Use suctioning if needed.
Provide oxygen therapy (NRBM15L/min).
Assist ventilation with a Bag-Valve Mask (BVM)if required in patients with
poor respiratory effort.

2. Monitor and Manage Circulation

Monitor BP, pulse, ECG (if ALS ambulance equipped) and observe signs of
shock.
o Control external bleeding.
o Start IV fluids (Ringer Lactate or Normal Saline) based on patient’s fluid
status.
o

3. Neurological Status and Pain Management

Monitoring GCS score and neurological status.
Administer pain relief medication (e.g., Diclofenac75mgIM) with the help
of teleconsultation.
o Avoid morphine or sedatives unless ALS-equipped and trained.
o
o

4. Immobilization and Splinting
o
o

Keep fractures stable using splints to immobilize limbs.
Apply a rigid cervical collar if a spinal injury is suspected.

5. Continuous Monitoring and Communication
o
o

Reassess vital signs (BP, HR, RR, SpO2, temperature) every5-10 minutes.
Communicate with the receiving hospital, providing details of the patient’s
condition, interventions performed and specific requirements (e.g., ICU
bed, surgical team)

6. Teleconsultation Support

Tele-consultation services are available continuously. EMTs should utilize teleconsultation services for guidance while at the scene site or during en-route care.
EMTs in ALS ambulances should be able to connect with remote physicians for
clinical decision-making via:
o
o

Telephonic guidance
video/audio calls (if equipped)

EMTs may administer specific medications (shock, STEMI, stroke, pain
management) as per direct physician orders under tele-supervision. Leveraging this
facility and establishing round-the-clock tele-clinics across various facilities will
enable immediate resolution in case of emergencies. e-Sanjeevani could play a vital
role in such intervention.
21
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

17 | P a g e

<!-- page 19 -->

4790271/2026/HOSPITAL-II

Chapter 5: Step 3: Referral and Hand over at Hospital
The transition of care from EMTs to hospital staff is a critical phase in the continuum of
emergency medical services. Poorly executed handovers can result in clinical errors, delays
in definitive care, or duplication of procedures. Structured communication, particularly
when based on standardized formats like MIST, ensures clarity, continuity, and
accountability between pre-hospital and in-hospital teams.
No healthcare facility, whether private or government, is legally permitted to deny
immediate emergency care to patients. The amended Motor Vehicle Act makes it
mandatory to provide cashless treatment to the victims of Road Traffic Injuries. The
relevant guidelines have been gazette-notified in 2025.
Ambulance staff should properly hand over the injured person to hospital staff, providing
comprehensive details about the patient, incident, care given during transport, and any
relevant written documentation. The handover process should be followed as stated below:
The Handover Process
1. Notify the Receiving Hospital

Both private and government hospitals may be considered while mapping a network of
ambulance and hospitals. Before reaching the hospital, EMTs must initiate timely
communication with the nearest appropriate healthcare facility. This allows the medical
team to prepare necessary resources (ICU bed, trauma team, blood bank, ventilator, etc.)
Inform the Emergency Department (ED)of the patient’s condition and estimated arrival
time. Including details on injury and patient vitals. This enables resource mobilization and
reduces treatment waiting time.
2. Communicate with the Patient’s Family

•
•

•

Effective and empathetic communication with patient attendants during transport
and handover is an essential part of pre-hospital ethics and care.
EMTs should inform family members of:
o Patient status
o Expected arrival time
Use calm, reassuring tone, especially in emotionally heightened trauma cases.
Avoid speculative medical opinions or false assurances.

3. Structured Handover Using MIST Format

The MIST format is a globally accepted framework for clinical handovers in
trauma and emergency care. It ensures clarity and completeness, minimizing
errors during the transfer of care.
o M-Mechanism of Injury:(e.g., road traffic accident, fall, poisoning, burn).
o I-Injuries Sustained:(e.g., head trauma, fractures, burns).
o S-Signs and Symptoms:(Vital signs, consciousness level, pain, distress
signs).
o T-Treatment Provided:(Interventions performed enroute).
22
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

18 | P a g e

<!-- page 20 -->

4790271/2026/HOSPITAL-II

Chapter 6: Step 4: Reaching Health Care Facility and Documentation
Upon arrival at the healthcare facility, EMTs must complete the hand over and
documentation process, which ensures that clinical teams are fully informed. This step
forms the final link in the pre-hospital care, with implications for patient safety, hospital
readiness, medico-legal accountability, and EMS system evaluation
Based on the injury type and severity the patient is referred to the designated trauma care
facilities (Level I, II and III).
Facilities are mapped according to their resource capacities, including investigations and
bed availability.
Levels of trauma care facilities:
Level I- Provides the highest level of definitive and comprehensive care for patient with
24/7 availability of emergency physicians, nurses, surgeons, and all major super
specialties for complex injuries.
Level II- Provides definitive care for severe trauma patients and on-call facility for
neurosurgeons, paediatricians. If neurosurgeons are not available, general surgeons are
present round the clock.
Level III- Focuses on initial evaluation and stabilization of trauma cases.
A robust link between field responders and health facilities can reduce deaths before
and after hospital admission.
The Final Handover and Documentation Process
1. Patient Reception and Emergency Triage
o

Assist in transferring the patient from the ambulance to the ED.

2. Final Documentation and Reporting

Complete the Pre-Hospital Care documentation. It is essential for:
•
•
•

Clinical continuity at the emergency department
Legal recordkeeping
Audit, training, and system improvement
o Submit records to hospital staff and maintain a copy for EMS
documentation (Interventions and medications given)

23
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

19 | P a g e

<!-- page 21 -->

4790271/2026/HOSPITAL-II

Chapter 7: Training and Capacity Building
Strengthening human resources through training programs, certifications, and upskilling is
essential to ensure that both lay responders and EMTs are equipped to act confidently,
correctly, and consistently during emergencies.
1. Public Awareness Campaigns: Community advocacy programs should be actively
conducted to promote public awareness of First Aid and the Good Samaritan Law.
Frequent advertisements should highlight the availability of free ambulance services
2. Integrating First Aid in Education: Basic trauma care, including skills to control
bleeding and perform CPR (cardiopulmonary resuscitation), should be integrated
into school curriculum.
3. Professional EMT Training: EMTs must undergo regular training to keep their skills
current. This includes:
➢ Standardized Life Support: Providing training on the National Emergency Life
Support (NELS) standards.
➢ Simulation-Based Learning: Utilizing skill labs for realistic, simulation-based
training.
➢ EMTs should regularly participate in training sessions to update their knowledge
and skills through Allied Health Department
➢ EMTs must be aware of key quality indicators, such as golden hour compliance
rates, stipulated hospital drop-off times, and process indicators like the percentage
of triaging/initial assessments performed at the scene
➢ Driving Skills: Training EMTs to drive ambulances, providing a critical backup
option in emergencies.
➢ Safety Measures: Ensuring all staff are provided with appropriate safety gear, such
as high-quality helmets for bike ambulances, and vehicles are equipped with safety
features like seat belt alarms.
➢ Ambulance Staff including EMTs must adhere to standard working hours, with
details on shift durations and patterns available.
4. Community Responder Networks: Creating a network of trained Community First
Responders with support from organizations like the Red Cross, St. John's Ambulance,
and local civil defence teams.

24
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

20 | P a g e

<!-- page 22 -->

4790271/2026/HOSPITAL-II

Chapter 8: Monitoring and Evaluation
An effective Monitoring and Evaluation (M&E) framework is the cornerstone of a highperforming emergency medical service (EMS) system. The responsibility for all M&E
activities, including data collection, continuous quality assessment, and periodic analysis, lies
primarily with the respective States and Union Territories, ensuring timely reporting and
corrective actions. States/UTs are encouraged to institutionalize structured review mechanisms
to strengthen accountability and promote continuous quality improvement. It enables evidencebased policy decisions, identifies service delivery gaps, and maintains compliance. It allows:
•
•
•
•

Measure performance at state and district levels
Identify gaps in service delivery
Enable evidence-based policy decisions
Maintain compliance

Key assessment factors for prehospital care and response
The following metrics should be continuously measured and reported:
•

Service Delivery Performance:
o

Response Time: The median time it takes for an ambulance to reach the scene.

o

Transport Time: The median time taken to transport patients to the hospital.

o

"Golden Hour" Compliance: The percentage of injured individuals who
receive care within the critical "golden hour."

o

Coverage: The percentage of the population and injured individuals
successfully accessing and being transported by the service.

o

Triage Rates: The percentage of cases where on-scene triage is successfully
performed.

Outcome parameters: Survival to discharge with good neurological status reduced trauma
mortality, decreased disability days.
o
•

An improvement plan may be chalked out for the next year, after gap analysis.

Operational Readiness:
o

Ambulance Status: The total number of available ambulances by type (BLS,
ALS) and their functional status.

o

Regular Audits: Periodic, random checks of ambulances to ensure compliance
with AIS-125 specifications and the implementation of infection control
protocols.

o

Downtime Reporting: Regular reporting on essential equipment and services
that are non-functional.

o

Human Resources: The total number of EMTs and drivers, categorized by
gender, and their adherence to standard working hours.

o

Call Volume: The total number 25
of emergency calls received daily and weekly.

File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

21 | P a g e

<!-- page 23 -->

4790271/2026/HOSPITAL-II

By closely monitoring these metrics, the EMS system can identify areas for improvement,
streamline operations, and ultimately save more lives.

Key performance indicators:
1. Command Centre: Proportion of call answer within 10 seconds.
o Numerator: Total number of calls responded within 10 seconds.
o Denominator: Total number of calls received.
2. Median Ambulance Response Time: The average (median) time taken from dispatch
to on-scene arrival.
o Numerator: Sum of (Time of Ambulance Arrival at Scene - Time of Call
Receipt at Dispatch Center) for all emergency calls.
o Denominator: Total number of emergency calls where an ambulance was
dispatched and arrived.
3. "Golden Hour" Compliance Rate (for Time-Sensitive Conditions): The percentage
of patients with time-sensitive conditions who receive initial pre-hospital interventions
and reach a definitive care facility within 60 minutes of the incident.
o Numerator: Number of patients with identified time-sensitive conditions (e.g.,
severe trauma, OHCA, stroke) for whom the total pre-hospital time (incident to
hospital arrival) was ≤ 60 minutes.
o Denominator: Total number of patients with identified time-sensitive
conditions requiring pre-hospital care.
4. Bystander-Initiated CPR Rate: The percentage of out-of-hospital cardiac arrest
(OHCA) cases where CPR was initiated by a layperson before EMS arrival.
o Numerator: Number of confirmed OHCA cases where bystander CPR was
performed.
o Denominator: Total number of confirmed OHCA cases.
5. Haemorrhage control Rate: The proportion of major haemorrhage controlled within
minutes.
o Numerator: Number of road accident cases where life-threatening hemorrhage
was controlled within minutes.
o Denominator: Total number of road accident cases with life-threatening
hemorrhage.
6. Teleconsultation Utilization Rate: The percentage of calls where EMTs successfully
utilized teleconsultation with a physician.
o Numerator: Number of calls where teleconsultation with a physician was
initiated and documented.
o Denominator: Total number of calls requiring pre-hospital care.
These indicators can be assessed every 3 months for monitoring purposes.

26
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

22 | P a g e

<!-- page 24 -->

4790271/2026/HOSPITAL-II

Chapter 9: The role of Teleconsultation in Pre-Hospital Care
Teleconsultation is a vital tool that extends the expertise of emergency medical professionals
to the field, serving as a critical bridge between pre-hospital care and definitive hospital
treatment. It is especially impactful in remote areas where access to specialized care is limited.
Platforms like India's eSanjeevani can be leveraged to provide real-time, remote medical
guidance during emergencies. A dedicated 24/7 telemedicine cell, staffed by emergency
physicians and nurses, can offer critical support to on-scene responders and laypersons.
Key functions of teleconsultation in this context include:
•

Real-Time Guidance: EMTs can connect with physicians for clinical decision-making,
allowing them to administer life-saving treatments like specific medications for shock,
stroke, or heart attacks under direct supervision.

•

On-Demand Expertise: A trauma nurse coordinator at the telemedicine cell can
perform a quick initial assessment via audio/video call, advise on immediate first aid,
and decide on the appropriate type of emergency response needed.

•

Support for Lay Responders: The public can receive immediate, guided first aid
advice for specific injuries like major cuts or burns, helping them stabilize the victim
until professional help arrives.

The integration of teleconsultation not only improves patient outcomes during the critical
"Golden Hour" but also helps conserve trauma center resources by enabling prompt decisionmaking and triage. Looking beyond the initial emergency, telemedicine can also play a crucial
role in post-trauma follow-up and rehabilitation.

27
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

23 | P a g e

<!-- page 25 -->

4790271/2026/HOSPITAL-II

Approach:

28
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

24 | P a g e

<!-- page 26 -->

4790271/2026/HOSPITAL-II

29
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

25 | P a g e

<!-- page 27 -->

4790271/2026/HOSPITAL-II

Pre-hospital care – mail action points (summary)

30
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

26 | P a g e

<!-- page 28 -->

4790271/2026/HOSPITAL-II

References:

1.

Ministry of Road Transport and Highways: Road accidents in India 2023. Available at:
https://morth.nic.in/road-accident-in-india

2.

World Health Organisation. Pre-hospital trauma care system, 2005. Available at:
https://iris.who.int/bitstream/handle/10665/43167/924159294X.pdf

3.

World
Health
Organisation.
Pre-hospital
tool
kit.
Available
https://www.who.int/teams/integrated-health-services/clinical-services-andsystems/emergency-and-critical-care/prehospital-toolkit

4.

Emergency Response Support System. Available at : https://112.gov.in

5.

Automative Industry Standard (AIS-125) Constructional and Functional Requirements.
Available at https://morth.nic.in/sites/default/files/ASI/352018104443AMAIS_125.pdf

6.

Notification dated 21.01.2016 regarding Good Samaritan. Available at:
https://morth.nic.in/sites/default/files/circulars_document/Notification_dated_21.01.20
16_regarding_Good_Samaritan.pdf

7.

Cashless Treatment of Road Accident Victims, 2025 (MoRTH). Available at :
https://morth.nic.in/sites/default/files/notifications_document/2-Re-SO2489(E)%20dated%204th%20June,%202025(Guidelines)-1.pdf

8.

National Emergency Life Support (NELS), Provider course manual for Paramedics.
Available
at:
https://whoccet.org/wp-content/uploads/2022/05/Provider-CourseManual-for-Paramedics.pdf

9.

WHO
Emergency
care
system
framework.
Available
https://www.who.int/publications/i/item/who-emergency-care-system-framework

at:

at:

10. Muller, G., & Brits, H. (2024). The transition of patient care: Exploring the outcomes

of prehospital to hospital patient handover practices and healthcare provider
education. African
Journal
of
Emergency
Medicine, 14(3), 212. https://doi.org/10.1016/j.afjem.2024.07.002
11. Martin-Gill C, Patterson PD, Richards CT, Misra AJ, Potts BT, Cash RE; Prehospital

Guidelines Consortium. 2024 Systematic Review of Evidence-Based Guidelines for
Prehospital
Care.
Prehosp
Emerg
Care.
2025;29(6):703-712.
doi:
10.1080/10903127.2024.2412299. Epub 2024 Nov 6. PMID: 39373357.
12. Jana

A, Sarkar A, Parmar V, Saunik S. Examining district-level disparity and
determinants of timeliness of emergency medical services in Maharashtra, India. Sci
Rep. 2023 Dec 1;13(1):21239. doi: 10.1038/s41598-023-48713-1. PMID: 38040797;
PMCID: PMC10692338.
31

File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

27 | P a g e

<!-- page 29 -->

4790271/2026/HOSPITAL-II

13. National

Highway Traffic Safety Administration (NHTSA): US Department of
transportation. Available at: https://www.nhtsa.gov/

14. National Association of Emergency Medical Technicians (NAEMT). Available at :

https://www.naemt.org/
15. Fire and Disaster Management Agency (FDMA):Ministry of Internal Affairs and

Communications. Available at : https://www.fdma.go.jp/en/
16. European Society for Emergency Medicine (EUSEM). Available at : https://eusem.org/
17. Jensen KO, Teuben MPJ, Lefering R, Halvachizadeh S, Mica L, Simmen HP, Pfeifer
R, Pape HC, Sprengel K; TraumaRegister DGU. Pre-hospital trauma care in
Switzerland and Germany: do they speak the same language? Eur J Trauma Emerg Surg.
2021 Aug;47(4):1273-1280. doi: 10.1007/s00068-020-01306-3. Epub 2020 Jan 29.
PMID: 31996977; PMCID: PMC7223374.
18. Carney CJ. Prehospital care--a UK perspective. Br Med Bull. 1999;55(4):757-66. doi:
10.1258/0007142991902763. PMID: 10746329.
19. Al-Shaqsi S. Models of International Emergency Medical Service (EMS) Systems.
Oman Med J. 2010 Oct;25(4):320-3. doi: 10.5001/omj.2010.92. PMID: 22043368;
PMCID: PMC3191661.
20. Gui L, Gu S, Lu F, Zhou B, Zhang L. Prehospital emergency care in Shanghai: present
and
future.
J
Emerg
Med.
2012
Dec;43(6):1132-7.
doi:
10.1016/j.jemermed.2012.02.067. Epub 2012 Oct 6. PMID: 23047196; PMCID:
PMC7126957.
21. Oliveira J. e Silva, L., Herpich, H., Puls, H.A. et al. Emergency medicine in Brazil:
historical perspective, current status, and future challenges. Int J Emerg Med 14, 79
(2021). https://doi.org/10.1186/s12245-021-00400-6
22. Bruce D, Ramakrishnan T, Patel P (Peter). Developing Prehospital Care in India–A
Potential Model for Low- and Middle-income Countries. Prehospital and Disaster
Medicine. 2023;38(S1):s41-s41. doi:10.1017/S1049023X23001449
23. Siman-Tov, M., Strugo, R., Podolsky, T., Rosenblat, I., & Blushtein, O. (2021). Impact
of dispatcher assisted CPR on ROSC rates: A National Cohort Study. The American
Journal
of
Emergency
Medicine,
44,
333-338.
https://doi.org/10.1016/j.ajem.2020.04.037
24. Deri, Y.; Berzon, B.; West, D.; Machloof, M.; Strugo, R.; Kaplan, T.; Soffer, S. The
Impact of Prehospital and Hospital Care on Clinical Outcomes in Out-of-Hospital
Cardiac Arrest. J. Clin. Med. 2022, 11, 6851. https://doi.org/10.3390/jcm11226851
25. Ministry of health and Family Welfare. Guidelines for telemedicine services in ABHWC. Available at: https://www.mohfw.gov.in/pdf/Telemedicine.pdf
26. Ministry of health and Family Welfare. National telemedicine services. Available at:
https://esanjeevani.in/

32
File No. V.28017/118/2025-H-II (Computer No. 8346494)
Generated from eOffice by MANTU KUMAR, SO(MK)-T&B-MOHFW, SECTION OFFICER, DOHFW DEPARTMENT on 09/09/2026 01:18 pm

28 | P a g e
