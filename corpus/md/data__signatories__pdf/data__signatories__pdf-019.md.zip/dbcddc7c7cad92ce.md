---
doc_id: "dbcddc7c7cad92ce"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/4c5514d690a419d4f8a868c8c412fbd2.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Generic testing procedure for implementation of Mobile Number Portability-Seventh Amendment- Regulations, 2018-19 of 2018- for the new entrants"
date: "2022-11-28"
pages: 22
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f461b3b4fdc46b3d"
---

<!-- page 1 -->

Government

of India

Ministry of Communications
Telecommunications
Department
(Access Services Wing)
12" Floor, Sanchar Bhawan, Ashoka Road, New Delhi
Dated:
FileNo:800/12/2017-AS.II

of

28.11.2022

To

All UL/UL(VNO) (having Access Service) Licensees
MNP Service Providers
Subject: Generic testing procedure for implementation of Mobile Number Portability
(Seventh Amendment) Regulations, 2018 (9 of 2018) for the new entrants.
In reference to the Test procedure issued vide letter no. 800-12/2017/AS.II dated
12.09.2019, TEC has informed that testing procedure dated 12.09.2019, formulated by TEC, was
with regards to the implementation of the Telecommunication Mobile Number Portability (7th
Amendment) Regulations, 2018 (9 of 2018) for the existing TSPs and not applicable for new
entrants.
In this regard, a new test guide for implementation of MNP regulation up to the
2.
Telecommunication Mobile Number Portability (7th Amendment) Regulations, 2018 (9 of 2018)
will
for new entrants is enclosed with this letter. This new test guide is generic in nature and
allow pairing of the operators as per the choice of LSA.

it

In case of any clarification regarding the test guide, Mobile Technologies (MT) wing of
3.
TEC may be contacted.
Enclosure: A/a

Wael

Y

(Nisha)

ADG

Copy
i.

ii,
iii.
iv.
v.

vi.

to:
for

DG(T)
taking necessary action.
Sr. DDG, TEC

Secretary, TRAI, New Delhi
M/s Ring Central India Pvt Ltd
M/s Plintron India Pvt Ltd
COAI

(AS-II)

<!-- page 2 -->

800-12/2017-AS.II

662764/2022/Office of ADG(AS-II)

टेस्ट गाइड
सं:23016:2022
TEST GUIDE
No.:23016:2022

Test Guide
for
मोबाइल नंबर पोटेबबबलटी
Mobile Number Portability

ISO 9001:2015

दू रसंचारअभियांभिकीकेंद्र
खुर्शीदलालिवन, जनपथ, नईभदल्ली–110001, िारत
TELECOMMUNICATION ENGINEERING CENTRE
KHURSHID LAL BHAWAN, JANPATH, NEW DELHI–110001, INDIA
www.tec.gov.in

537/558

<!-- page 3 -->

800-12/2017-AS.II

662764/2022/Office of ADG(AS-II)

© टीईसी, 2022
© TEC, 2022
इस सर्ााबिकार सुरबित प्रकाशन का कोई भी बिस्सा, दूरसंचार अबभयांबिकी कें द्र, नई ददल्ली की बलबित स्र्ीकृ बत के बबना, दकसी भी
रूप में या दकसी भी प्रकार से जैसे

- इलेक्ट्रॉबनक, मैकेबनकल,फोटोकॉपी, ररकॉर्डडग, स्कै ननग आदद रूप में प्रेबित, संग्रिीत या

पुनरुत्पाददत न दकया जाए ।
All rights reserved and no part of this publication may be reproduced, stored in a retrieval system
or

transmitted,

in

any

form

and

by

any

means - electronic, mechanical, photocopying,

recording, scanning or otherwise, without written permission from the Telecommunication Engineering
Centre, New Delhi.

Release 01: August, 2022

538/558

<!-- page 4 -->

539/558

800-12/2017-AS.II

662764/2022/Office of ADG(AS-II)

FOREWORD
Telecommunication Engineering Centre(TEC) is the technical arm of
Department of Telecommunications (DOT), Government of India.

Its

activities include:
 Framing

of

TEC

Product/Equipment,

Standards for
Standards

for

Generic

Requirements

for

a

Interface

Requirements

for

a

Product/Equipment, Standards for Service Requirements & Standard
document of TEC for Telecom Products and Services
 Formulation of Essential Requirements (ERs) under Mandatory Testing
and Certification of Telecom Equipment (MTCTE)
 Field evaluation of Telecom Products and Systems
 Designation of Conformity Assessment Bodies (CABs)/Testing facilities
 Testing & Certification of Telecom products
 Adoption of Standards
 Support to DoT on technical/technology issues

For the purpose of testing, four Regional Telecom Engineering Centers
(RTECs) have been established which are located at New Delhi, Bangalore,
Mumbai, and Kolkata.

ABSTRACT

This Test Guide aims at uniform assessment of implementation of MNP
regulation upto the Telecommunication Mobile Number Portability (7 th
Amendment) Regulations, 2018 (9 of 2018) for new licensed network
operators.

Test Guide No.: 23016:2022
2

<!-- page 5 -->

662764/2022/Office of ADG(AS-II)

800-12/2017-AS.II

Contents
History Sheet ........................................................................................................................................... 4
1.

Scope............................................................................................................................................... 5

2.

Test Cases for Mobile Network Operators (MNO) ........................................................................... 5

3.

TestCases – NLD/ILD ................................................................................................................... 14

Glossary ................................................................................................................................................ 20

Test Guide No.: 23016:2022
3

540/558

<!-- page 6 -->

662764/2022/Office of ADG(AS-II)

541/558

800-12/2017-AS.II

History Sheet
Sl. No.

Test Guide No.

1.

TEC 23016:2022

Title
Test Guide
Portability

2.

Test Guide No.: 23016:2022
4

For Mobile Number

Remarks
Aug, 2022

<!-- page 7 -->

542/558

800-12/2017-AS.II

662764/2022/Office of ADG(AS-II)

1. Scope
This Test Guide aims at uniform assessment of implementation of MNP regulation upto the
Telecommunication Mobile Number Portability (7th Amendment) Regulations, 2018 (9 of 2018)
for new licensed network operators.

2. Test Cases for Mobile Network Operators (MNO)
The pre-requisites are mentioned in Annexure-I, followed by Annexure-II containing test SIM
details and Annexure-III containing Timer values for testing.

S.
No.

Test Case

Role
Day

1
SMS to 1929 for
UPC

DNO

1

SMS to 1929 for
UPC

DNO

1

MNP
SP

1

MNP
SP

1

1 (a)

2 (a)

2(b)

Validation
of
requesting number
at MNPSP

Description
UPC Request (SMS) to be
routed to correct Zone
MNPSP (serving NRH of
the customer) by DNO
SMSC.
UPC Request (SMS) to be
routed to incorrect Zone
MNPSP (not serving NRH
of the customer) by DNO
SMSC.
MNPSP to match MSISDN
in 'UPC request' (SMS) with
requesting
(A-party)
number, if numbers are
same, UPC request will be
accepted
If A-party number and
MSISDN mentioned in UPC
Request SMS
are not
identical, UPC request will
be rejected and notified to
the customer with rejection
reason
Message
Validation

2 (c)

3

Message
from
MNPSP
to
Customer
for
request
within
5mins
MNPSP to perform

MNP
SP

1

MNP

1

SIM
require
ment

Category

SIM2 SIM14

Individual

SIM1

Individual

SIM2 SIM14

Individual

SIM2

Individual

SIM3 SIM14

Individual

Format

Acknowledgement for UPC
Request message submission
to MNPSP

SIM3

Test Guide No.: 23016:2022
5

Test
Result

Comment

<!-- page 8 -->

662764/2022/Office of ADG(AS-II)

following checks

543/558

800-12/2017-AS.II

SP

and
SIM4

(i) a UPC has
already been issued
and has not expired
yet.

i- SIM3

(ii) the mobile
number has been
ported earlier and, if
so, a period of
ninety (90) calendar
days has not elapsed
from the date of its
last porting; OR
UPC code already
exist OR Porting in
Progress
OR
Number_range OR
Number
Fomat
validation

iiSIM4

MNPSP to send
relevant message's
to all the above
cases
3 (a)

3 (b)

4

MNPSP to send
'UPC
Rejected'
(SMS)
to
the
customer in case
validations (ii) is
true
MNPSP to send
'UPC
Resend'
(SMS)
to
the
customer in case
validations (i) listed
above is true
MNPSP to send
'Subscriber
info
query' to DNO for
following items if
all
above
validations
are
'false':
(i) the number is a
Corporate mobile
number;

MNP
SP

1

SIM4

Individual

MNP
SP

1

SIM3

Individual

1

SIM5 SIM14

MNP
SP

Individual
ii SIM5

(ii)
there
are
outstanding
payments due from

iii SIM6

Test Guide No.: 23016:2022
6

<!-- page 9 -->

544/558

800-12/2017-AS.II

662764/2022/Office of ADG(AS-II)

the
postpaid
Subscriber by way
of pending bill,
issued
per
the
normal billing cycle
but before the date
of
request
for
Unique
Porting
Code (UPC);
(iii)
the
Port
Request has been
made before the
expiry of a period of
ninety (90) calendar
days from the date
of activation of a
new
connection;
MNPSP to assign
corporate UPC if
validation (i) is
'true' and remaining
validations
are
'false'
4 (a)

4 (b)

4 (c)

4 (d)

No response from
Donor within 'UPC
info Time'

MNP
SP

No response from
Donor within 'UPC
info delayed time'

MNP
SP

Negative
acknowledgement
from Donor within
'UPC info delayed
Time' (if any of the
above validations is
true)
Subscriber
info
Response' (positive
ACK) from Donor
within 'UPC info
delayed Time'

1

UPC delayed (SMS) to be
sent to subscriber

SIM7

Individual

1

UPC rejected (SMS) to be
sent to subscriber with
rejection
reason
'No
response from Donor'

SIM8

Individual

MNP
SP

1

UPC rejected (SMS) to be
sent to subscriber with all
rejection reasons

Alread
y
Covere
d

Individual

MNP
SP

1

UPC Accepted (SMS) to be
sent to the subscriber with
valid UPC code.

SIM9 SIM14

Individual

RNO

1

CAF to be submitted with
UPC information, date and
time. RNO to send a
message to subscriber upon
CAF submission

SIM9 SIM14

Individual

RNO

1

SIM9 SIM14

Individual

SIM9-

Individual

5
CAF submission at
RNO
6

7

RNO will send port
request to MNPSP
with
UPC,
MSISDN, date and
time of subscriber's
porting request.
MNPSP shall verify

MNP
1

Test Guide No.: 23016:2022
7

<!-- page 10 -->

662764/2022/Office of ADG(AS-II)

whether:

545/558

800-12/2017-AS.II

SP

SIM14

The Port Request is
not in process for
the same mobile
number;
7 (a)

7 (b)

8

In
case
above
validation is 'false',
MNPSP will send
'Port
Response'
(Rejected) to DNO
and RNO and Port
Rejected (SMS) to
the customer with
rejection reason.
In case of all MCH
validations
are
'true', MNPSP will
send 'Port Response'
(accepted) to DNO
and RNO and Port
Accepted (SMS) to
the customer with
date & time.
MNPSP will send
acknowledgement
'Port
Request
submitted' (SMS) to
the subscriber with
24-hour
port
cancellation
window information
‘Port
Cancel’
request by customer
within
24-hour,
MNPSP to match
MSISDN in 'Port
Cancellation' (SMS)
with requesting (Aparty) number, if
numbers are same,
Port Cancel request
to be accepted

MNP
SP

1

SIM9

Individual

SIM10
SIM14

Individual

1

Customer sends 'Port Cancel'
request to MNPSP within
24-hour window. MNPSP to
send
'Port
Cancel
Notification' to RNO and
DNO and 'Port Cancel
Accepted' (SMS) to the
customer

SIM10

Individual

1

Customer sends 'Port Cancel'
request to MNPSP after 24hour window.
MNPSP will send Error
Notification
indicating
rejection reason to RNO;
and 'Port Cancel Rejected'
(SMS) to the customer

SIM11

Individual

1

MNP
SP

Custo
mer

9
Port Cancel' request
after
24-hour
window

Custo
mer

Test Guide No.: 23016:2022
8

<!-- page 11 -->

546/558

800-12/2017-AS.II

662764/2022/Office of ADG(AS-II)

10

Disconnection
of
service by DNO.

DNO

2-4

SIM11
SIM14

Individual

Provision of service
by RNO.

RNO

2-4

SIM11
SIM14

Individual

SIM11
SIM14

Individual

SIM11
SIM14

Individual

11

12

Port broadcast by
MNPSP.

13

14

14
(a)

14
(b)

14
(c)

14
(d)

MNP
SP

MT & MO calls
(Voice / SMS) to
RNO
and from the ported
number
Non Payment Disconnect

Non
Payment
Disconnect (NPD)
request by Donor
before
/
after
permissible period.

Negative
acknowledgement
(error notification)
by MNPSP to DNO

2-4

The MNO should be able to
accept the port broadcast
message from the MNPSP
and should send back the
port
broadcast
answer
message to the MNPSP as
acknowledgement. Based on
this message, the MNO
should be able to update the
routing tables at their end.

2-4

DNO

NPD within 7 days.

SIM11
SIM14
SIM11

NPD
NPD

3
MNPSP to send negative
acknowledgement
specifying rejection reason.

MNP
SP

3

If any of the above
validations is true, MNPSP
to
send
negative
acknowledgement
specifying rejection reason.

Alread
y
Covere
d

NPD

NPD after 7 days (and
before 60 days) of bill due
date and within 90 days
from the broadcast date

SIM12
SIM14

NPD

SIM12
SIM14

NPD

Non
Payment
Disconnect (NPD)
request by Donor
within
allowed
period

DNO

3

NPD request from
MNPSP to RNO

MNP
SP

3

Test Guide No.: 23016:2022
9

<!-- page 12 -->

662764/2022/Office of ADG(AS-II)

14
(e)

Donor to cancel
NPD request

DNO

3

NPD Response by
RNO to MNPSP

RNO

3

MNP
SP

3

MNP
SP

3

DNO

3

MNP
SP

14
(f)

14
(g)
14
(h)
14
(i)

14
(j)

15

16

17

18

19

MNPSP to make a
query from DNO &
wait for 96 hours
NPD
Response
from MNPSP to
DNO
NPD
Acknowledgement
from
DNO
to
MNPSP
NPD
Acknowledgement
from MNPSP to
RNO
Number
return
process initiation by
MNPSP
Donor
acknowledges
number return
Reconnection
request within 60
days
of
NPD
Acknowledgement
(Disconnect)
received from RNO
to MNPSP
Reconnection
notification
by
MNPSP to DNO;
number reconnected
to RNO.
Broadcast of LRN
with NRH

22

Donor will cancel NPD
request before NPD ACK
message to MNPSP
NPD response to be sent by
RNO within 30 days of
receiving NPD Request
(Multiple NPOSA by RNO
within 30 days is not
allowed. Second NPOSA
will be accepted only on
30th Day.)

SIM12

NPD

SIM13
SIM14

NPD

SIM13
SIM14
SIM13
SIM14

NPD

NPD

3

SIM13
SIM14

NPD

MNP
SP

3

SIM13

NPD

DNO

3

SIM13

NPD

RNO

4

SIM14

NPD

MNP
SP

4

SIM13

NPD

MNP
SP

4

SIM13

NPD

SIM15
SIM20

Corporate

SMS to 1929 for
UPC

DNO

1

CorporatePort Order
Submission

RNO

1

CorporatePort Order
Acknowledgement.

MNP
SP

1

DNO to acknowledge Nonpayment disconnect request
within 96 calendar hours.

NPD

SIM13
SIM14

20

21

547/558

800-12/2017-AS.II

UPC Request (SMS) to be
routed to correct Zone
MNPSP (serving NRH of
the customer) by DNO
SMSC.
RNO submit Corporateport
request to MNPSP for 10
(upto 100) MSISDN's
MNPSP
will
send
acknowledgement
'Port

Test Guide No.: 23016:2022
10

SIM15
SIM20
SIM15
-

Corporate
Corporate

<!-- page 13 -->

662764/2022/Office of ADG(AS-II)

23

No port withdrawal
window message to
be sent.
Port Cancel' request
by customer within
24-hour, MNPSP to
match MSISDN in
'Port Cancellation'
(SMS)
with
requesting (A-party)
number, if numbers
are
same,
and
submitted
with
correct
format
within 24 hours
time of raising the
Port Request, Port
Cancel request to be
accepted.

Request submitted' (SMS) to
the subscriber

25

RNO

1

MCH should accept the port
cancel request

Donor will reject partial
Corporateport request with
following rejection reason
1. Authorization Letter not
in Desired Format

Corporate

Port

SIM20

Corporate Subscriber will
cancel port request within 24
hrs from port request submit
time & date.

24

CorporatePort Order
Rejection
authorization letter

548/558

800-12/2017-AS.II

RNO/
DNO

DNO

1

3-4

SIM15

Corporate

Corporate
SIM16

Corporate

2. Incorrect Donor name or
Recipient name or circle
name

SIM17

Corporate

3. Authorized Signatory
Name & Signature missing
/mismatch

SIM18

Corporate

4.Authorized Signatory Email id missing

Corporate

5. Authorized signatory seal
/ signature not available in
all pages

Corporate

6. Authorized Signatory
Signature
missing
/
mismatch

Corporate

7. Company letter head not
valid

Corporate

8. Company name mismatch

Corporate

9. Company Stamp Missing

Corporate

10.
Mobile
number
mentioned is incorrect

Corporate

DNO will send corporate

Test Guide No.: 23016:2022
11

SIM19

Corporate

<!-- page 14 -->

662764/2022/Office of ADG(AS-II)

Order Confirmation
26
CorporatePort Order
Partial Acceptance
& Full Acceptance
27

28

29

30

31

32
32
(a)

porting order response to
MNPSP with acceptance
MNPSP will send 'Port
Response' (accepted) to
DNO and RNO and Port
Accepted (SMS) to the
customer with date & time.

MNP
SP

3-4

MNP
SP

3-4

MNPSP will send
message to Donor

DNO

3-4

DNO will send Service
Disconnect Answer

CorporatePort Order
Service Connect

MNP
SP

3-4

MNPSP will send
message to RNO

CorporatePort Order
Service
Connect
Answer

RNO

3-4

RNO will send
Connect Answer

CorporatePort Order
Service
Disconnection
CorporatePort Order
Service Disconnect
Answer

SD

SC

Service

MNPSP will send broadcast
message with correct LRN
to all operators
Number Porting Order Termination (NPOT)
CorporatePort Order
broadcast

NPOT request by
Current NO of
MSISDN
to
Number
range
Holder.

MNP
SP

3-4

DNO

7

MNP
SP

7

32
(b)
Negative Ack by
MNPSP to the
Current NO

32
(c)
Positive Ack
MNPSP to
Current NO

32
(d)
33

549/558

800-12/2017-AS.II

by
the

Broadcast of LRN
with NRH
RDB-Sync

MNP
SP

7

RNO

7

MNP
SP

RNO/
DNO

SIM19
SIM20
SIM19
SIM20
SIM19
SIM20
SIM19
SIM20
SIM19
SIM20
SIM19
SIM20
SIM19SIM20
SIM19

Corporate

Corporate

Corporate

Corporate

Corporate

Corporate

NPOT
NPOT

SIM19

NPOT

SIM19

NPOT

7

SD-Notice to all the MNO

SIM19

NPOT

7

MNPSP will release the
RDBPD based on Operator
request. The MNO should be
able to download partial
bulk sync data, and populate

NA

RDB

33
(a)
Customer to initiate
Partial
RDB
Download

The Current Subscription
Network sends an NPOT
request for number return to
the Number Range Holder.
MNPSP to send negative
acknowledgement
specifying rejection reason.
wrong_NRH/
invalid_referenceID/
order_already_exists/
active_order_exists
/
number_not_routed/
number_not_routed_to_send
er
NPOT message is accepted
by the CNPMS and NPOT is
forwarded to Number Range
Holder.
NPOTA (+) by Number
Range Holder

SIM20

Test Guide No.: 23016:2022
12

<!-- page 15 -->

662764/2022/Office of ADG(AS-II)

33
(b)
Customer to initiate
Full
RDB
Download

550/558

800-12/2017-AS.II

RNO/
DNO

7

it in its routing tables.
MNPSP will release the
RDBF based on Operator
request. The MNO should be
able to download full bulk
sync data, and populate it in
its routing tables.

Test Guide No.: 23016:2022
13

NA

RDB

<!-- page 16 -->

551/558

800-12/2017-AS.II

662764/2022/Office of ADG(AS-II)

3. TestCases – NLD/ILD
The pre-requisites are mentioned in Annexure-IV.

S.No

Test Case ID

Role

Day

Description
CoCCommCO

1

Port broadcast by
MNPSP.

MNPSP

1

The MNO should be
able to accept the port
broadcast message from
the MNPSP and should
send back the port
broadcast
answer
message to the MNPSP
as
acknowledgement.
Based on this message,
the MNO should be able
to update the routing
tables at their end.

RNO/DNO

1

RNO/DNO

1

MNPSP will release the
RDBPD based on MNO
request (based on date
range, LRN range, LSA
or
a
combination
thereof). The MNO
should be able to
download partial bulk
sync data and populate
it in its routing tables.
MNPSP will release the
RDBFD based on MNO
request. The MNO
should be able to
download full bulk sync
data, and populate it in
its routing tables.

2

3

RDB-Sync
MNO to initiate
Partial RDB
Download

MNO to initiate
Full RDB
Download

Test Guide No.: 23016:2022
14

Test Results

Comments

<!-- page 17 -->

662764/2022/Office of ADG(AS-II)

800-12/2017-AS.II

Annexure I –Pre-Requisites
(1)

All test scenarios will be performed on the TEST platform.

(2)

The Test Cases are designed considering a pair of Moblie Network Operators
(MNOs).

(3)

The Testing will be performed under reduced timer parameters (from days to hours)
to enable faster completion of the testing scenarios.

(4)

Availability of 1929 short code for network operator TEST SMSC to place the UPC
request.

(5)

Centralized SMSC for each MNO.

(6)

Numbering plan should be in SYNC for both MNPSPs and MNO.

(7)

The MNO will do testing both as RNO and DNO.

(8)

Testing SIM numbers and Testing SPOCs details should be share with MCH in
advance.

(9)

Spare SIM will be needed for Testing and MNO should share new SIM as and when
they change testing numbers.

(10)

Proposed PAIR - MNO A and MNO B taking a set of 3 LSAs (one of them has to be
AS, NE or JK).

Test Guide No.: 23016:2022
15

552/558

<!-- page 18 -->

662764/2022/Office of ADG(AS-II)

553/558

800-12/2017-AS.II

Annexure II–SIM Requirements
S. No.
1.
2.
3.
4.
5.
6.
7.

SIM No.
SIM 1 to SIM 10
SIM 11 to SIM 13
SIM11
SIM 14
SIM14
SIM 15 to SIM 20

SIM Type
Prepaid SIM
Postpaid SIM
Postpaid SIM
Postpaid SIM
Roaming SIM
Corporate SIM

SIM 21

Special LSA

Test Guide No.: 23016:2022
16

Test Scenarios
Intra LSA
Intra LSA
SIM will be Ported SIM
Intra Zone & Inter LSA
Inter Zone & Inter LSA
Will be used for AS,NE, J&K
For Successful scenario

<!-- page 19 -->

662764/2022/Office of ADG(AS-II)

554/558

800-12/2017-AS.II

Annexure III - Timer Values for Testing
S.NO.

Timer Details

Description

1.

UPC Info Time

2.

UPC delay time

3.

UPC Validity

4.

Port schedule
time (Individual
Intra)

5.

Port schedule
time (Individual
Inter)

6.

Port response
time for
corporate port

7.

Cancel deadline

8.

NPD timers

The time within
DNO must
response for the
subscriber info
query
Maximum time
to wait for DNO
response for
subscriber info
query
UPC will be
valid for
MCH to
schedule porting
window of
individual port
request for intra
LSA
MCH to
schedule porting
window of
individual port
request for Inter
LSA
Time given to
DNO to respond
for corporate
port request
Cancellation
request can be
raised with in
NPD can be
raised after bill
due date
NPD cannot be
raised after bill
due date
NPD should be
raised within 90
days from last
porting

Time Defined
In Regulation

Proposed
Timing For
Testing

2 Min

2 Min

Proposed
Timing For
Testing
(As,Ne,J&K)
2 Min

5 Min

5 Min

5 Min

4 Days

4 Days

5 Days

48 Hrs

48 Hrs

72 Hrs

96 Hrs

96 Hrs

72 Hrs

96 Hrs

96 Hrs

96 Hrs

24 hrs

24 hrs

24 hrs

7 days

3 Days

3 Days

60 days

7 Days

7 Days

90 Days

7 Days

7 Days

Test Guide No.: 23016:2022
17

<!-- page 20 -->

662764/2022/Office of ADG(AS-II)

9.

NPD
Reconnection

10.

Grace Period to
raise Number
Return

555/558

800-12/2017-AS.II

Reconnection
can be raised
within
Number return
due to NPD can
be raised within

60 Days

3 Days

3 Days

7 Days

1 Days

1 Days

Test Guide No.: 23016:2022
18

<!-- page 21 -->

662764/2022/Office of ADG(AS-II)

800-12/2017-AS.II

Annexure IV–Pre-Requisites
(1) All test scenarios will be performed on the TEST platform.
(2) Numbering plan should be in SYNC for both MNPSPs and Operators
(3) Testing SPOCs details should be share with MCH in advance

Test Guide No.: 23016:2022
19

556/558

<!-- page 22 -->

800-12/2017-AS.II

662764/2022/Office of ADG(AS-II)

Glossary
CAF

Customer Application Form

DNO

Donor Network Operator

LRN

Location Routing Number

MCH

MNP Clearing House

MNO

Mobile Network Operator

MNP

Mobile Number Portability

MNPSP

MNP Service Provider

MSISDN

Mobile Station Integrated Services Digital Network

NPD

Non Payment Disconnection

NPOSA

Number Portability Order Suspension Acknowledgment

NPOT

Number Porting Order Termination

NPOTA

Number Porting Order Termination Acknowledgment

NRH

Number Range Holder

RDB

Relational Database

RDBFD

Relational Database Full Download

RDBPD

Relational Database Partial Download

RNO

Recipient Network Operator

SMS

Short Message Service

UPC

Unique Porting Code
****

Test Guide No.: 23016:2022
20

557/558
