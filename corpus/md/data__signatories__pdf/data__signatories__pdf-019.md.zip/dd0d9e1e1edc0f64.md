---
doc_id: "dd0d9e1e1edc0f64"
source_url: "https://mohua.gov.in/static/uploads/2025/11/ac4e15ca963b03d06a7e78af30f3195e.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Recruitment Rules for the post of DG,CPWD"
date: "2004-12-02"
pages: 6
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "d45ef6c27f909970"
---

<!-- page 1 -->

| भी पा
७
रजिस्ट्री सं* डी० एल'-33004/99 fps REGD. NO. D.L.-33004/99
Say
a
Ra OD
सत्ममेव जयते
असाधारण
EXTRAORDINARY
भागग--खण्ड 3--उप-खण्ड 6)
+ PART Il—Section 3—Sub-section i)
ड़ प्राधिकार से प्रकाशित
हर - हा PUBLISHED BY AUTHORITY है
सं. 537] ः नई दिल्‍ली, शनिवार, दिसम्बर 4, 2004/अग्रहायण 13, 1926
1४०. 537] NEW DELHI, SATURDAY, DECEMBER 4, 2004/AGRAHAYANA 13, 1926
शहरी विकास मंत्रालय
( कार्य प्रभाग )
अधिसूचना
है नई दिल्‍ली, 2 दिसम्बर, 2004
सा.का.नि. 791(अ).--राष्ट्रपति, संविधान के अनुच्छेद 309 के परनन्‍्तुक द्वारा प्रदत्त शक्तियों का प्रयोग करते हुए तथा केन्द्रीय लोक निर्माण
विभाग (निर्माण महानिदेशक) भर्ती नियम, 1986 का अतिक्रमण करते हुए, .ऐसे अतिक्रमण के संबंध में किए गए अथवा किए जाने बीलें अतिक्रमण F
को छोड़कर, राष्ट्रपति केन्द्रीय oie fat fase a fate ate ae ae ad ato 'का विनियमन करते हुए. निम्नलिखित नियम न्‍
बनाते हैं, अर्थात्‌ :-- है none ५५ गज करेक ag
1. संक्षिप्त नाम तथा प्रारंभ---(1) “इन नियमों का नाम (केन्द्रीय लोक निर्माण विभाग) (निर्माण महानिदेशक) भर्ती
नियम, 2004 है। :
(2) वे राजपत्र में ga at atta a प्रवृत्त होंगे। है ह ae
2. पदों कौ संख्या, वर्गकरण तथा बेत॑नमान.--उपयुक्त पदों की संख्या, उनका वर्गीकरण तथा उससे संबंधित वेतनमान वे होंगे, जो
इन नियमों के साथ संलग्न अनुसूची के स्तम्भ (2) से (4) तक में विनिर्दिष्ट हैं। कि पड

3. भर्ती की पद्धति, आयु-सीमा तथा अन्य अहताएँ आदि... डक्त पदों at भर्ती की पद्धति, आयु-सीमा, अर्हताएं तथा उससे संबंधित

अन्य बातें वे होंगी जो उपर्युक्त अनुसूची के स्तंभ (5) से (14) तक में विनिर्दिष्ट हैं।

4. निर्हता.--वह व्यक्ति-

(क) जिसने ऐसे व्यक्ति से, जिसका पति या पत्नी जीवित हो, से विवाह किया है, या

(ख) जिसने अपने पति या पत्नी के जीवित होते हुए, किसी व्यक्ति से विवाह किया है,
wa पद के किसी पद पर नियुवित का पात्र नहीं होगा : i

परन्तु यदि केन्द्रीय सरकार का यह समाधान हो जाता है कि ऐसा विवाह, ऐसे व्यक्ति और विवाह के अन्य पक्षकार को लागू स्वीय विधि
के अधीन अनुज्ञेय है और ऐसा करने के लिए अन्य आधार हैं तो वह किसी व्यक्ति को इस नियम के प्रवर्तन से छूट दे सकती है।

5. शिथिल करने की शक्ति.---जहां केन्द्रीय सरकार की यह राय है कि ऐसा करना आवश्यक या समीचीन है, वहां वह उसके लिए
जो कारण हैं उन्हें लेखबद्ध करके तथा संघ लोक सेवा आयोग से परामर्श करके इन नियमों के किसी डपबंध को किसी वर्ग या प्रवर्ग के व्यक्तियों की
बाबत, आदेश द्वारा शिथिल कर सकती है।

3604 GI/2004 (1) .

<!-- page 2 -->

| 2 2 eee etre [Past Sve. 39]

6. व्यावृत्ति.--इन नियमों की कोई भी बात, आरक्षण, आयु-सीमा में छूटतथा अन्य रियायतों पर प्रभाव नहीं डालेगी, जिसका
केन्द्रीय सरकार द्वारा इस संबंध में समय-समय पर जारी आदेशों के अनुसार अनुसूचित जातियों, अनुसूचित जनजातियों, अन्य पिछड़े वर्गों, भूतपूर्व
सैनिकों और अन्य विशेष प्रवर्ग के व्यक्तियों के लिए उपबंध करना अपेक्षित है।

अनुसूची
Gad aie aie पा re 1
पद नाम पद की संख्या वर्गीकरण है वेतनमान क्या प्रवरण पद है या सीधी भर्ती के लिए आयु
गैर प्रवरण पद है सीमा
ee | ee
1 2 cor: fa od eee 2 ढ़
निर्माण 01* सामान्य केन्द्रीय सेवाएं 26,000 रु. प्रवरण लागू नहीं
महानिदेशक (2004) समूह “क' राजपत्रित निर्धारित
7 *कार्यभार अननुसचिवीय
: परआधारित
विचलन के
रे अधीन।
क्या केद्रीय सिविल सेवा... सोधी पके लिएसपिक saa di Rae eS केन्द्रीय सिविल सेवा सीधी भर्ती के लिए शैक्षिक. क्या सीधी भर्ती के लिए निर्धारित परिवीक्षा अवधि, भर्ती की पद्धति क्या सीधी
पेंशन नियम, 192 के... तथा अन्य seat आयु तथा शैक्षिक अ्हताएं, प्रोन्‍्ततों. यदि कोई हो भर्ती द्वारा या प्रोन्नति द्वारा
नियम 30 के अंतर्गत सेवा के मामले में लागू होंगी या प्रतिनियुवित/आमेलन
के अतिरिक्त वर्षों का लाभ द्वारा तथा विभिन्‍न पद्धतियों
अनुमत्य है | द्वारा भरी जाने वाली
रिक्तियों की प्रतिशतता
ज्ण्फपो२ककृ्ततऋ+5.....त#ह.. $$ _ SEAT Sat atierererar
7 8 ea ee 10 n
लागू नहीं लागू नहीं ee । ओ्रेलति 7 लागू नहीं प्रोन्नति
परलति डर या प्रतिनियु्ति द्वत वा आवेलन दाए ai eam, ae ऋ करक्‍फाय ८: कु ऊउ_ +- द्वारा या प्रतिनियुक्ति द्वारा या आमेलन द्वारा भर्ती के मामले, बे ग्रेड यदि कोई विभागीय. किन परिस्थितियों में संघ लोक
जिनसे प्रोन्नति या प्रतिनियुक्ति या आमेलन किए जाने हैं प्रोन्नति समिति विद्यमान. सेवा आयोग से भर्ती करने
है, तो इसका गठन के संबंध में परामर्श किया ।
ak Sc i es 2 जाना है
12 ्््््््फ्््जज--_+१__ ४7 13 4
app >> +ं>«9न>9>क+ >> >«+ 5 « eee ||
. प्रोन्नति :
(1) (ए) अपर महानिदेशक (निर्माण) के ग्रेड में 22,400-24,500 रु. 1. अध्यक्ष या सदस्य, संघ लोक सेवा आयोग से
के वेतनमान में दो वर्ष की संयुक्त नियमित सेवा सहित 24,050- संघ लोक सेवा आयोग परामर्श करना, इन नियमों i
26,000 रु. के वेतनमान में अपर महानिदेशक (विशेष निर्माण) “अध्यक्ष के किसी प्रावधान में संशोधन ।
(बी) अपर महानिदेशक (वास्तुकीय) के ग्रेड में 22,400-24,500% 2. af, शहरी या छूट देने के समय L
के वेतनमान में दो वर्ष की नियमित सेवा थारी तथापि कॉनट्रेक्ट विकास मंत्रालय आवश्यक है। |
आधार पर सीधी भर्ती द्वारा पद धारण करने वाले व्यक्त पात्र -सदस्य i
नहीं होंगे। 3. सचिव, सड़क परिवहन
उपर्युक्त (1) पूरा न होने की स्थिति में और राजमार्ग मंत्रालय !
(2) (ए) अपर महानिदेशक (विशेष निर्माण) के रूप में पांच वर्ष की ae
संयुक्त नियमित सेवा सहित 24,050-26,000 रु० के वेतनमान में अपर
महानिदेशक (विशेष निर्माण), 22,400-24,500 रु. के वेतनमान

<!-- page 3 -->

( सन 1 भालकारजफ: असषाण _________ गर-खण्ड 36)] भारत का राजपत्र : असाधारण BG so GG
12
में अपर महानिदेशक (निर्माण) तथा 18,400-22,400 रु. के
वेतनमान में मुख्य अभियन्ता (वै. या सि.), या
है (बी) अपर महानिदेशक (वास्तुकीय) के रूप में पांच वर्ष की
संयुक्त नियमित सेवा सहित 22,400-24,500 रु. के बेतनमान में
अपर महानिदेशक (वास्तुकीय) तथा 18,400-22,400 रु. के
वेतनमान में मुख्य वास्तुक।
टिप्पणी : 1-प्रेड में प्रोन्नति पर विचार एक सामान्य पात्रता सूची
के आधार पर किया जाएगा जो अपर महानिदेशक ( निर्माण) या
हे अपर महानिदेशक (वास्तुकीय) के ग्रेड में अधिकारियों द्वारा
निर्धारित अर्हता सेवा पूरी करने की तारीख को ध्यान में रखते हुए
तैयार की जाएगी। 1
टिप्पणी : 2--अपर महानिदेशक (निर्माण) के ग्रेड में कार्यरत
किसी अधिकारी को निर्माण महानिदेशक के रूप में प्रोन्‍तत करने .*
पर तभी विचार किया जाएगा यदि उन्हें अपर महानिदेशक
(विशेष निर्माण) के रूप में प्रोन्‍नत किया जा चुका हो। यदि,
टिप्पणी 1 में उल्लिखित सामान्य पात्रता सूची के अनुसार, कोई
अपर महानिदेशक (निर्माण) किसी अपर महानिदेशक (वास्तुकीय)
से वरिष्ठ हैं, तो निर्माण महानिदेशक के पद पर प्रोन्नति के लिए
कनिष्ठ अधिकारी से पहले वरिष्ठ अधिकारी के नाम पर विचार
किया जाएगा, किन्तु उन्हें निर्माण महानिदेशक के पद पर तभी
sia किया जाएगा यदि उन्हें अपर महानिदेशक (विशेष निर्माण)
के रूप में प्रोन्‍्नत किया जा चुका हो ।
टिप्पणी : 3--यदि किसी कनिष्ठ ने अपनी अर्हक/पात्रता सेवा पूरी 7
कर ली है, और उसकी प्रोन्नति ,पर विचार किया जा रहा है तो
डसके वरिष्ठ कर्मचारियों पर भी विचार किया जाएगा बशर्ते कि
'डनकी अपेक्षित अर्हक या पात्रता सेवा ऐसी अर्हक या पात्रता सेवा
से आधी से अधिक या दो वर्ष, जो भी कम हो, से कम न हो तथा
उसने अपने ऐसे कनिष्ठों, जिन्होंने पहले ही इस प्रकार की अर्हक/
पात्रता सेवा पूरी कर ली है, के साथ-साथ अगले उचततर ग्रेड में
प्रोन्नति के लिए परिवीक्षा अवधि को सफलतापूर्वक पूरा कर
लिया हो। : .
के :
[फा. सं. 5/4/2003-एस एण्ड डी/ई डब्ल्यू-1]
मेहर सिंह, अवर सचिव
MINISTRY OF URBAN DEVELOPMENT
(Works Division)
NOTIFICATION
New Delhi, the 2nd December, 2004 j
G.S.R. 791(E).—In exercise of Powers conferred by the proviso to article 309 of the Constitution and in
supersession of the Central Public Works Department (Director General of Works) Recruitment Rules, 1986, except as
tespects things done or omitted to be done before such supersession, the President hereby makes the following rules
regulating the method of recruitment to the post of Director General of Works in Central Public Works Department,
namely ;:—
1. Short title and commencement.—(1) These rules may be called the Central Public Works Department (Director
General of Works) Recruitment Rules, 2004.

<!-- page 4 -->

4 THE GAZETTE OF INDIA: EXTRAORDINARY [Part Il—See. 3]
(2) They shall come into force on the date of their publication in the Official Gazette. .
2. Number of posts, classification and scale of pay. —The number of said posts, its classification and the scale
of pay attached thereto, shall be as specified in columns (2) to (4) of the Schedule annexed to these rules. |
|
3. Method of recruitment, age limit and other qualifications, etc.—The method of recruitment to the said posts, |
age limit, qualifications and other matters relating thereto shall be as specified in columns (5) to (14) of the said Schedule. ।
4. Disqualification.—No person, —
(a) who has entered into or contracted a marriage with a person having a spouse living; or
(b) who, having a spouse living, has entered into or contracted a marriage with any person,
* shall be eligible for appointment to any of the said post :
Provided that the Central Government may, if satisfied that such marriage is permissible under the personal law f
applicable to such person and the other party to the marriage and that there are other grounds for so doing, exempt any
person from the operation of this rule. i
5. Power to relax,—Where the Central Government is of the opinion that it is Necessary or expedient so to do, it
may, by order, for reasons to be recorded in writing, and in consultation with the Union Public Service Commission relax
any of the provisions of these rules with respect to any class or category of persons.
6, Saving.—Nothing in these rules shall affect reservations, relaxation of age limit and other concession required
to be provided for the Scheduled Castes, the Scheduled Tribes, the Other Backward Classes, Ex-servicemen and other
special categories of persons in accordance with the orders issued by the Central Government from time to time in this
regard,
SCHEDULE |
'
Name of Number ofpost Clasiifcaion ~*“Sealeof pay Whelher SIGN ok Ee of Number of post Classification Scale of pay Whether selection post Age limit for direct recruits
post or non-selection a nomesclection post
1 2 3 4 2 6
Sr ni eee ns
Director — 1* (2004) General Central Services Rs, 26000 Selection. Not applicable
General — *Subject to Group ‘A’ Gazetted Fixed,
(Works) variation depen- Non-Ministerial,
dent on workload,
a
SSS 5 न नामक पर तन-+++++5+++८-नञ
कक हटसटह हट ्छहअइअपफ /ई/-:टपस्‍उफक्च-+--हनन्‍-तह#ह8ह8/#ह8..... ै$ै$ 1
Whether benefit of added Educational and other Whether age and. Period of Method of recruit- ४
years of service is qualifications required educational qualification probation, if any ment, whether by
admissible under rule 30 for direct recruits prescribed for direct direct recruitment or |
of Central Civil Services recruits will apply in the by promotion or by 1
(Pension) Rules, 1972 case of promotees deputation or | =
absorption and
percentage of the —
Posts to be filled by
oui ations motions _
7 8 9 10 ता
ST Sar Sn
Not applicable Not applicable Not applicable — i Notappticable ___Notapplicable  Bypromotion, applicable — By promotion

<!-- page 5 -->

mat
\
€ भा“ बष्ड 30) ताक सपा फसिललननननननन तन ञ_ 36)] भारत का राजपत्र : असाधारण 5
In case of recruitment by promotion or deputation or absorption Ifa Departmental Circumstances in which.
grades from which promotion or deputation or absorption to be Promotion Committee Union Public Service
made exists, what is its Commission to be
composition consulted in making
So ओ फकएा recruitment
12 13 14

Promotion :

(1) (9) Additional Director General (Works-Special) in the payscale 1. Chairman or Member, Consultation with Union
of Rs. 24050-26000 with two years combined regular service Union Public Service Public Service Commis-
in the grade of Additional Director General (Works) in the pay Commission—Chairman sion is necessary at
scale of Rs. 22400-24500and Additional Director General 2. Secretary, Ministry of — the time of amendment
(Works-Special) in the scale of Rs. 24050-26000; ‘Urban Development. or relaxation of any

Or —Member provision of these rules
(b) Additional Director General (Architecture) in the pay scale 3, Secretary, Ministry
of Rs. 22400-24500 with twoyears regular service inthe grade of Road Transport and
provided that a person holding the post by direct recruitment Highways —Member
oncontract basis shall not be eligible
Failing (1) above. हि
Q) (a) Additional Director General (Works-Special) in the
pay scale of Rs. 24050-26000 with five years combined
regular service as Additional Director General (Works-
Special), Additional Director General (Works) in the
pay scale of Rs. 22400-24500 and Chief Engineer
(Electrical or Civil) inthe pay scale of Rs. 18400-22400;
Or
(b) Additional Director General (Architecture) in the pay ‘
scale of Rs. 22400-24500 with five years combined |;
regular service as Additional Director General
(Architecture) and Chief Architect in the pay scaleof *
Rs. 18400-22400.
Note:1—Promotion to the grade shall be considered based
onacommon eligibility list prepared with reference to
the date of completion by Officers of the prescribed
qualifying service 1n. the grades of ‘Additional Director
General (Works) or Additional Director General
(Architecture). “
Note ; 2—An Officer in the grade of Additional Director
General (Works) shall be considered for promotion as हु
Director General (Works) only after he has been .
considered and promoted as Additional Director General. .
(Works-Special). If, as per the common eligibility list
referred to in Note |, an Additional Director General
(Works) is senior to an Additional Director General | aa
(Architecture), the senior shall be considered for
promotion to the post of Director General (Works) before हु i
his junior, but will be promoted to the Latter post only हु
after he has been considered and promoted as Additional
Director General (Works-Special)
Note: 3—Where juniors who have completed their
qualifying or eligibility service are being considered
____for promotion thei seniors would also be consdepe 8 रऊनआनईआईश/"_"णाणओओ promotion, their seniors would also be considered

<!-- page 6 -->

2 |
6 - THE GAZETTE OF INDIA : EXTRAORDINARY [Parr I—Szc. 3(1
12 |
provided they are not short of the requisite qualifying |
or eligibility service by more than half of such 2
qualifying or eligibility serive or two years, whichever
is less, and have successfully completed their period
of probation for promotion to the next higher grade
alongwith thier juniors who have already completed
such qualifying or eligibility service. ।
a aaa ee oT
IF. No.5/4/2003/S & D/EW-I] |
MEHAR SINGH, Under Secy. I
|
To न i el pers Tel
Printed by the Manager, Govt. of India Press, Ring Road, Mayapuri, New Delhi-l 10064
and Published by the Controller of Publications, Delhi-110054
