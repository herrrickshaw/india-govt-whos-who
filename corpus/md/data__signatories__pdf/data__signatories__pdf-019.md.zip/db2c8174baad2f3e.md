---
doc_id: "db2c8174baad2f3e"
source_url: "http://consumeraffairs.gov.in/public/upload/files/2%20Director%20Gr%20II%20_0_1733216849.pdf"
ministry: "Department of Consumer Affairs (DoCA)"
title: "Download Amendment of Recruitment Rules for Director Grade-II , NTH"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2c9e40969a83d145"
---

<!-- page 1 -->

By Speed Post
A-12018/03/1998-NTH.
Government of India
Ministry of Consumer Affairs, Food and Public Distribution
Department of Consumer Affairs

***** **
Gallery No .12/2, J amnagar House
Shahjahan Road, New Delhi - 110 011
Dated, the 11th
January, 2017
To
The Director General
National Test House,
· Sector'" V, C.P. Block,
Salt Lake;Kolkata-700091.
Subject:- Seventh Central Pay Commission's recommendations - revision of pay scales Amendment of R~cmitment Rules for the post of Director Grade-II in National Test
House.
Sir;

I am . directed to refer to Department of Personnel & Training O.M. No.AB14017/13/2016-Estt. (RR) dated 9th August, 2016, on the above mentioned subject and to
, forward herewith copy of the Revised Recmitment Rules 2016 for the post of Director Grade II
. 1n-Natfonai Test· House duly notified in the Gazette of India, Part II, Section3, Sub Section(i)
. ~ide ·GSR No;24o dated 10.12.2016 for record and further necessary action. These Recmitment
Rules are also available on the website of egazette.nic.in in the name of this Ministry.

· a~
(D.~nker)

Deputy Director (NTH)
Tel No.23073612
E-mail: d.sonker@nic.in
Copy to:
1. Directoii sdent1st-In charge, All regional Branches, National Test House,
2. ·Department of Personnel and Training, Estt~ (RR)Division, North Block, New Delhi
3. ·secretary,J)i:iion Public serv'ice Commission [Kind attention: Shri B.S.Heet, Under
Secretafy(RR);]
4. L-l ;LegiSlative bepaitment, Shastri Bhavan, New Delhi. (OL) & (English).
· \ ~)~he.: Parliainent Library, Parliament Annexe, Parliament Street, New Delhi(Two copies)
~ Guard files.
·

<!-- page 2 -->

~ -q:-12018/03/ 1998-~.iT.10[.
m«r~

~~, m ~ Bl~RCfl fcrn\Ur ii?llcill
~~~
~~ 12/2, \5llt:FPRm

~~-110011,~ 11 ~,2017
W:rr~

'

WR~~ICfl,
~~Wffi,

~-v motfTo~
'
'
~~' ChlciCflldl-700 091
~: ~ ~ ~ 3IBWr cfi1" ruq:;1f(~l - tja'1qHl ~ ~ - ~ -cro-&1Uf Wffi ~ R~~ICfl

(~ -2) ~~~ ~m-iIT~~I

~'

~,
'34lfcffi
~-q\ Cfllf4Cfl ~"5ffu&1Ur~~~ 9 m, 2016 ~CflfOWO ~~
':l
':l

14017/13/2016-~(:aw.:aw.) Cflf~~ ~mOCflfORO ~o 240 ft.rtCfl 10.12.2016 IDU m«r

m "3tr-m

~m, m1T rr,
3,
(i) ~ ~~~, ~-cro-&1Ufmffi~ Pi~~1Cfl c~ -2) ~
~tcr~
~Wm, 2016 cfil"~>ITTr ~ ~ mcfT 311Cl~l!Cfl Cfll{C11$ ~~ ~
':l
~3TI'%1 ~~Wm egazette.nic.in cfi1" tjiSIBl$C:-q\

mw ii?llcill ~~if~~I

<ro=TN:23073612

"'

~-~: d-sonker@nic.in

>rfu:
1. ~~Wfficfil"~ ~m-@1"311~ R~~ICfl/~~IRCfl->rmtl-1
2. Cfllf4Cfl~"5ffu&1Urfcrmlr, ~(3W.3W.)>flWT,-;mt~, ~~I
3. ~' tm~Bcrr 3IBWr ['UIHICfltiOI: m~.~. me,~~ (3W.3W.)]
4. ~-l,~fcrmlr,~~,~~~)~(~)I
5. ~ ~ ':l
4«1Cfllcill, fiB<fill ~' ~l111"f, ~~ ccn-·5rfu"ll"i)I

6. 1lli~

<!-- page 3 -->

<!-- page 4 -->

·.·
:··:

·....

·-'....:

...

... ·

....... . :;.-. :· ...

: _ ~·.:.

·:

;·)/;>··· ·.
.... ·. :· ~·:c> .. __. ~· ~ i'3.s2~:'.>,~: {'~':t!tE :iijAZE'I:fE ~ OF :ilIDiA::·DECEW3Eifi 6; iOi.61AGRAHAYANA·i9 ;::.i 93s ·JPART__tr~Ec. 3(i)1

' ; ,_ ~

.- . .

.

/:'.. ,~,-GITil)f~. -;;ft-:~~~·~h:r (5) °frm(13fif fclRG:bc!:~1

..

.

.

. .

:.;·~-~

_:· ..-:->.

:2~-:r:_ .,.-\. .; ., _. _~-'.:"_ q~~~~~-91r~~~w~~foi;~-~~~am:~~aR~~~~
>~':: :: · .· '.: . ·~

·fcifu ~- ~~-,~1~A~~ ~::Q:m~~ ~ 3{r<'.l"·amm: ~ m~ mft" o:c:tfcRr, ~ w f.tinr~:-srcrcTrr"fr w~Wfr1

:.r>i:::': -::~~ . ,>~: s~:~~~-': *l~'~:<1:~,::·. ~:~~· cfi'r_ -~u<r- ~foil-~~- ajq~~m:~41~~ -~;·.:~~r~alh:~~

:·~::;~<--_ j . ,~_ . '- im;.. urr~:. ~/~~;"cfifcl1 :cim ~ -~ "frCfT anm ~~'R111~r ~ -\f'ifrt<l+ff:~ ~ ~~ ~ ~ q.y <rr

·· .. ;. .:.. .-·--:· .. ·;·:.:· · - .. ·

.

·--. ·~

.

··.- ..._- '

. (5) .

(4)

~

.

~ · if

m_.13
~

118500- .
209200/-

(6) .

50 . ~ "fr -~ ;:r@. (~ -~ m<:r ;;rift
·.· ~~iT:'irr/~.m ~: ~if :~ ~ ~

.: ~~:=?4t~~~~

• crRra - ~'- if ~:~·-anm- :imi m ?t;
·. ~ ~cfi'r .'l'f{· affitl(~~i~ (<r foil~
. -;;ft' · ~;· . ~;: j 31·¥01i'9tj --~~T •. ~ •
. . -.~ ~;·: '11•11~a;s;·:~; :~. -~ - ci;~ifu:
' ·~ ?t;:~-~/f%.li i"i~ :"SR* ?t; ~am:

· ~~ - -~ - ooiN · ~ :~w -~-W'lWT

:, -~··3ifi:'J::j~:~1\ :~:~ :~-~ ~

. ~-~~-~~~ti> :

<!-- page 5 -->

...

.

·J

.

.
- '···. ...

~ Cfi1~ . :~10, 2016/~ 19, 1938
•

< ;

: .. :/ ..

...

> mm ...-IBf· ~ f<1c1: '3TI9!i<r<il !(~ am: 31r<l'

·;-~ .·.···

. ·

1353

Cf<l'T m~ ..-IBf ~ f<1c1:

..-IBf c!i'I' ~ -..-IBf m&

~~aID:!i~

-

~ m ~ ID"U m

~q<?\"1fd ~

st RI Pl 1Rti m anilwr g:m

~~~"@<fi

am~~ID"U
'+RT~
ftfui<ff cnr

cnm-

>rfcl'!IIB
(8)

(7)

(9)

(10)

, ' · (i) . ~ ~-m fc\sgfc\o;u11:14 ii'~

~ID"U~"'l'WwR
i:n: stfdf.'l1Rti (~ ~

'. : (~ :<IT °'11ct\'[IR:Cfl)/~ (~ <l'T
· · · ' <>41ct~iR:Cil) ~ ·· ·ti1<iil=a< c!i'I' Wft m

ID"U, ~ ~ "1' WwR CR

.

.

..

31.,.qCfl1P!Cfl

m t)

~~ID"Ul

~ {\lf\f.'\4fo1 :'.m :. :~ m · C!GfAAt

:"

~

. :_: sii~1fi\4i't ~Wit irr ;rifcp WT'!ie.11

.:x:(~w ·;;~;t~.~~- ~4;'1~~
. .:, ':'.~ ~ -"<f~t"~ ~ ~!ITTm
.·. : ; :,m~if ~ ~ ·cnr ~'S1111Wl

. : · fu0raft ·1:~···~ -- ~ ~ c!i'I'

.. /~m•· ~ -i*r'~~ .~-~ - 3lf41<T ~ Glii"h11e1<

. . . ;~ :c!i'l'-;;ff~~i:

.

. . · - ·_~2:·: ~. ~ -(~) ~~WIT

·.··. :: · · S~ ~ ~:_ fc\Ci<til1ei·{::-_ai1W"<ta . -~ am:

: ~~{((ifilc(~-;'{cit1fd4\. ¥. ~ ~ -a:!ITT ~ 'dCf

·:· ·:~~~~·~fft~ -~~~mi;r.TCR
-: ~~; ~ ircIT ~-# . .'<r<f t: fol; ~ ~

. ,:.~ )T~i~ffi,:-_~ ~~~- -~ : \3"'1' ~ ~
.-. ~ -. ~.; -i:i<ffit : ~ - ~ - ~ ~ c!i'I'

.,: ;: ~==~t'· . ·. · :, ·,·.·

...

. -,, .·.. .(!):: ~

. ii1r<ici'1~1H

· fcl~afclw<n4

ii'

.· ~~ .::* '·~ c!i'I' Wft <IT

. · ~"1i'fri4f{l{t~lst"i·~:i"'1fi\4i't ~ (iilcN'd<

.. :··

. : :. ··_ ,.-;.·::_-._:·

...

" - ~-~
-ifr~· ~,
~....··.· ·~·
·· ~ ·:..
·..
':

.· ·:· :

fclMT ~!ITim ~I ..

.

.

·..: ~ (ii) '_'J!(TrtTfri9;:.:cWIT :~<i;T 'qiffit ~ P-1'~

.. :. ;<ii·ir_~~ mmft-~~trfulur ~ ~ ~
...
.

·;: .

·:.

.--...

..' -:.~m stfdf.'l1fdi ~ ~m Cf<l'T ~ ~ mftf fcl-aii 1'1 t m
(~ ia\01 · mu ·mff c!i'l'~~rr ~ .~ aj'm, ~~Cf<l'T ~I

1'1

' . . ;:·_:·~,=~~~~ .

~~~~WIT

3lf41<T ii' ~ ~ ~ f<1c; i:n:mllr
fcl>tiT~I

.: .. -« ·· _:<~rF . .·.

(13)

~ ..-IBf ~ ~

am: ~

armro cm- siR1Pl1Rt> <~
~ 31.,.qCfl1P!Cfl ~ 'lfl' t)

CR~~~~ -~

WIT 3IT<fl<T ii'
3\fCf!l<fCli ~I

'f<lll!IT

9l<'1T

<!-- page 6 -->

. -.:·.. ·~

. ; · '.. ·j

.

·.· .•

' .. ·.!

.· ~: ·.·) f3s4_·. ·.. · THE ~:. GAZETTE OF INDIA: DECEMBER 10,2016/AGRAHAYANA 19,1938 JPARTil-SEc. 3(i))
···:~~cntmt .~ ·~~~

3.~~.~~

, · ·• ·; ·:~~~t;~~~ : :,,.Efi~~~::~~r::i~

.: .': __ .:,·..-.'·'t'II~~:~:~ .mt..

·.· . · · · .· .. $imm.~~an~it~it<rr ~~!119', ~~

. . . -.~ ~ it,.~ , i\-~~.:..fr 9111 w, 9111 -.i-

:a:r~<re;r

·~ ~·~-~ ·~~~ ~~.~~~
. ~· ~~~ffif~~

. . . ·~· > . : . ·: :~ :: ~ .!·mfcfi~ cfi't" a:rn-m

. - . - ;·:· ·'.: - *1_cti~al tt4'fi ~~'~.w. ~~

. · $/qr;ii=rd\·qi~ "@~ ~m ~I '
... :; >·~R\f.\~ - (~ -~ '. at(W<iCfiiRl<ii

·. ..

·····( <;~1~8~i27'~~

.,. -·~~~!i~'f4iaf4~ 1~4'j

.
·

. ;: •. · .. (~ -- (i)·:· ~ ;it~t ~ ~

· ~ ·if-· ~ 3lTaR 'Cf{
irrfur · ~ tR ·· m<:UT ~

.•. :

~t:~·:·

~ . : {ii) ·»~-~~

.. . > ·::c ·

..

.

· .·,::~~:: , ~· ~ <~:.m-12, m
·. ' 7ffooo~2ci92001.:. ;:IT . ·~ ~
.. ::. '4a'141'1 'ifJ¥rlmr,anim: tr<:~ ·~
: ».:. ·~~-~~~l)tff{~ .~cfi't"Wrrcfi't"

·. .. .

·.'. ::.~;-·3ffi: .:- . . . .

.

· ~ .. ·(~r~ ~ t·~ a:r~ mm 'i:rcft ~

··- ·- .~·:. :,' ~ :. >. ·.

..

.:~...~:::fcllt:!: <re!; . ~

'31R~a$nt~w1

.· ·: J~1:~tar-1 - . =·~ ·:~ :·-~ .~·
. .. .. . .

.

;·~ :~.~cfi't":~'-c:fft!; if~ .

. . .· . ~~Rif.\\~R;, 'f{_ ~;·:~ ~ ~

/ .. : :Gff.( ~ tw.f,:· ~ ,,~1 ~ i;f<liR,
... :;~Ri84:ct>:-~\~ '· 'Cf{ . ~ ~
:'. ~,~~ ·iR-¥·m~·~1
::.~~2: .:·~Rif.11Rh ;.(~ ..~ ·
~'ai~'fi1Pt<+J~ :~ :· ~~

·mcfi't"

. . . ~:rfu~~~. c:~:~~~~'fi~\!
• .• >,:;); .$'t~':i~jF!t;1.
·-

.

'. ~ :~i : ".::>//'(\-': ._ ..

·,: ::~=3: j1frjf.\1Rti J~ .. ~

>; a;·~~«iiPi~ ·~,~<m -.JI~~) 'Cf{

·~:: ~-~·t=~~~s~~-~

'·:. : · 5i:r'cftf'~ ~ ~ ~1 •·

•. <

. :::·. .. ~

.

~-

.. ·. .

. ·..

<!-- page 7 -->

:·

....

.·

.

"'.:·:·(, I

'._

.

.

' t~ II~~ 3(i)J

'qffij' C!ii ~ - : ~ 10, 20161~ 19 ; 1938

1355

- - ~·A ·· : - stRlf.:l~fyt; - ~ -~ - ~
. -.~ >cr{ :f%Rn ' ~~'~--~ ~
~: , ~--~-w-u 1fu-tt: 2016 ir

..

o

'("

•

:

- -: '. i~;~~a,tr~~~?i~~-?r :~~~; ';

-P

'~: ·: 3lfmfui- . ~~- ~- ~ ' CJ)f

· ,' J~~ :)'~li~T -~-- ~ f.'t<:rimr amm: ~

-:~~-_fr~- ~- '3CRf ~ ~ cfi1'

.

ftictrftllrr .~.- ai+~ - Rl@1Ra ~
':~ ;¥~.ffi~cfil-~~

.;. ·:

:~-~1 ::::-:

'

.-. .

[tnr. ~--i:!;-12018/3/1998~"CJ?f tr~
... ;
.··
_

,

tr. ~- ~. ~ f.'fe:llfifl ("CJ?f tr i:i;q)

..

.. ;..
•' ~

New Delhi, the 6th December,· 2016

...

.· . . :~_.:

-~ _ _ ·-. - -<G-.S.R,-240:~- Iil exercise -of the powers conferred by the 'proviso to article 309 · of the CcinstitUtion and in
_ _ .fopersession .of ·the; Ministry of Consumer Affairs, Food and Public Distribution (Department of Consumer Affairs)
_ ;NaticmaLTest House, Kolkata; Director (Grade II), Recruitment Rules, 2007, except as respectthings done or omitted to
:· -_: ' :bi~-:done_' before ·such siipersession, the President hereby makes the following mles regulating the method of recruitment
< to-, the ~po-st o f: Director (Grade II) in the National Test House, Ministry of Consumer Affairs, Food and Public
:))istribution, Depaitment of Consumer Affairs, namely :-

_; ~~li~ttlti~

comme~cement.-

f._,, _
and
(1). These rules may be called the Ministry of Consurrter Affairs, Food and
"Public Distribution (Department -of Consumer Affairs), National Test House, Director (Grade II) Recruitment Rules,
: . 2016> .-

:

' (2)'.:' _They ~hailcbme into force on the date of their publication in the -Official ·Gazette.
:~;

·_ 2:

: Number of p'ostS, classification and level in the pay matrix.- The number of the post; _its classification and
level in;the pay:matrix attached thereto, shall be as specified in columns (2) to (4) of the Schedule annexed to these rules.

..

_

.>·
:- ·/3;\-'. M~th~a:~ff~cr~ifrn~nt, age -lirilit, educational qualifications, etc.·. The .method of'i-ecruhinerit t~ the said post,
· ·: ;',;' }· :\_:;.:-~; ::.'_;:ag~'.fortit;'educatioriaLqualifications and other matters relating to the said post shall be as specified in coiumns (5) to (13)

c---,>\\r(:! ,::y:--.:-~~f ~e-afor~s~~..~-~~e~ule.
.: _

·•
• DisqualificatiOn.- No person,-

· · · ' 4;

-(a) \vh-6 lias·entered info or contracted a marriage with a person having a spouse living;·or ·

"· :,:_.:: ..

-·cb) who, having a spouse living, has entered into or contracted a marriage with any other person,
-

'

_.- shall be·eligible.for appoiritment to the said post:
· )_:'

~- i_ -':>- Pro~ided .that ~h~ ·Ce~tral -Government may, .if

satisfied

that -such - marriage is · permissible under the

-·:_ :·:.:._< -';/per~on~iJaw applicable.to such -person and the other party to the marriage and that there are other grounds for so doing,
'

' ./:_,exempt anf person:from the operation of this rule.

>;;: . · :Ptitve/tti ·r elax~- ·Where the Central Government is -of the opinion that it is necessary arid expedient so to
·: .. ~'-- do,.:-i(may, 'by-order
for reasons to be recorded in writing and in consultation -with ·the Union Public Service
-._· :_- ·.- • Comrriissiori-- relax :a:riy.of the provisions of these rules with respect' to any class or category of persons .

',.

and

. -6.

· . -.- SaVi'Ilg:~N-6thlng iri these rules shall affect reservation, relaxation of age limit and ·other concessions required to

'be~'pro~idecffor the:Scheduled -Castes, .the Scheduled Tribes, Ex-servicemen and other special categories of persons in

. ; .

:·-accordancewith the ·orders -issued by the Central Government from time to time in this regard.
· .... '

·· ...... ·
···;._

. . ...
·.,

...
··- .. --: .

<!-- page 8 -->

:·~·:· ··::·:

-·~·-

.~

.

. ~- - -...-· ·'·:"::-

.- - ·. :· .. ..

·';

· i35·6----: · '(-TI-ffi ~AiET.TE :oF INDIA: bECEMBER-10, 2016iAGRAHAYANA 19, _1938 .[PA.R'f n.:._sEc. 3(i)]
SCHEDULE
Name of the- ·. Number of
Po-st
.P_osts

(2) .

. (l) _ --

04* _(2016)
Director : ..
(Grad~=n):- - _ : (*Subject to··
.:;, .-:varfatiori ·dep~nderit ori
: workload).

'. ~ :

;

-Classification

Level in the Pay
Matrix

- (3)

(4)

General Central
Ser\rice, Group 'A'
Gazetted, Non._ Ministerial

Level 13 in the
Pay Matrix _ .
rupees 118500"
rupees 209200.

Whether
Selection post
orNonselection-post
(5)

Selection

:

-.·

..· . - · ...

';..

~

. --

_- ,.

';,

..

(6)
Not . exceeding 50 years
(relaxable
for
Government Servants by
five ·years' in accordance
with the instructions
i_ssued. - by the Central
Goverrirnent).
Note ·: The crucial date
for determining the age
'.limit shall be the closing
· date __ for :_ receipt of
applitations · ·
from
·candidates in Iridia except
.the
closing
date
-prescnhed for those in
Assam,
Meghalaya,
Arunachal
Pradesh,
. Mizoram,
Manipur,
Nagaland,
Tripura,
_-Sikkim; Ladakh Division
of Jammu- and Kashmir
State; Lahaul and Spiti
:District and Pangi SubdivisiOn - of
Chamba
District of .Himachal
Pradesh, .Andaman and
.NiCobar Islands
and
-Lakshadweep .

.
.~ ~ . - ·.

Age limit-for direct
recruitment

.. .
-'

".--"

.. ;~· ... - ..

.- ..

-EducationaLand.-: other . qualifications . Whether
age . ... & . Period
of Method of Recruitment:
'educational qualifications : Probation, if any
·whether .
by .
Direct
prescribed :for. Direct·Recruitment:6r by Promotion
~ ·~~: ...
Recruitment will apply in
or
by . deputation
and
·-·, .
.the case of promotees
:percentag·e . of . the vacancies
to .. be - . filled . by various
- ":· _,·.
meihods

<-- ;~equired for .direcdedruits _.

:"-'.~~

_

:.·,

..

(7)

(8)

_Age: No
. ·- : ESSENTIA1:-: .:
.. (i) . -. c_Naster'. s . · · D~gree
in Educational
:chefnistry(Pure/Applied)/, . · , Physics Qualification: .Yes
:· ;:·· :XPrire/A~plied)~ . ' or ; De~_ee -iri
· ·Engineering ofMetallurgy oi Textile I Rubber· ·Technology: of a . recognised
University of eciUivalent;
.
. . - '. ~ (ii) .. :~.t\.vei~r years'.~: experience· iii
. ·: <-Managerial capacity-'. in ilie .field '' of .
.." . ; -testing and evaluation of .materials arid .
. -·. ;_ kriowlei:lge of'.their behavior in a
laboratorf .o{ iristiri.ltion , of staridings
'. :speciaiisirig'_in.Material sCience.

(10)

(9)

for . Promotion failing which by
Two years
deputatii:m (inducting shortdirect ·recruits
term contract) failing both by
diiect recri1itment.

...

.

-------

-------

<!-- page 9 -->

-;

.

'' .

~·

..

· ·;.·

<

... _,, -.:.

.· .;:

.:~ ..-:..·:· ~;\. '·>.[~n -: ~"3ci)r.,· .
....'liffir C!iT ~: ~· 10; 20161~ 19,1938
13s1
.· c >.~
.
~~~==,======~~~~~~~~=====~
.
.:./:.': :.:
. . . · . . . . . .· :.:.·- :·:...
. ..

·· ·.·.. :. ··...

~~<-: ·:::-~~·~-· ·~::

~.-

·::~.

·~

._"'._ ,. < .Note L:-_Qtialifications are relaxable at

.... .·'·< '.th'e \ discretion .'oC the:· Union , Public

·2;:~}<< ~~:=z~~:t:~<?~~r:~~-~~~:~~a~i~:d. of

·· ,·:~:.:r_,: ..Note:2: : Tne qualificatfori(sr regarding.
): : 'exP.erfonce is ':hfre relaxable at . the
·.. ~: ··.· \ :Iiscretion of •trie·Uru6n Public Service
. . :> ·'coinniissiori:in the•,case ·of candidates
O . · ':: belonging- · . ter Scheduled . Castes . or .
· ,. Schedulect'.. Tiibes( if;af .any >Stage ·. of ·
~sefoctic:m ,·.the'-:,,Urii'On Public ~ Service
; c6:mmis~ion,:is of: "ihe .. opinion ; that
;:sufficient .number .· of candidates . from .
. "t~ese :: colnm.uniti~s/·possessing ' the .
:requisi:te expei:ience -,are 'noH ikely to ·
. :;~bl~:<~vfillabfo to 'fin -up the posts
. . . reser:Vea for them . .-.

-·>·: mitsiRAim:E:·{ :::: , ·-

•.

.

': : .m ~Doctorate '.:Degree -: in . Chemistry/
!Physics .·or P.ost/ Graduaie ··Degree .in
·'- Engineerilig/Metiilllirgyffechiiology
, } rnni· a : rec·ogniSe'd::: University or·
'_

~-t~~~talf~~~~striii;e: . . · •~xperience ..
;prefeiably)n'aTaboratoiy; ·and
.
' (iii)· Researdi"experience:-in _Inciustriai .
:·materiais,and'testin · :methodoloa .·.·

.:In ·.·case.- of recruitment by promotion/ · If a Departmental Promotion Committee
·grades . .·from ·which exists, what is its composition
- ;promotiorildeputatiori tcf be made

<'.: cteputa.ti~·n, •

.. (U) .

Circumstances
in
which
Union
Public.
Service
Commission to be ·consulted
in making recniitment.
(13) :

(12)

Group . 'A'

Consultation . with the Union
·Public Service .Commission is
considering promotion) necessary whifo:making direct
recruitment and appointing an
~20920bwith ;five _ years '.:-regular ser'iice in !.Chairman or a Member of Union Public
officer
on
deputation
,thb'.:gr_acie)·
·..·
. .
Service Commission
Chairman
(including
short
term
·.Note:tWhete'jtlniOrs whb have completed 2: Director General, National Test House
contract).
_ h !leir,c.:quaiifyiiig/eligibility service are
- Member and
:: :belii'g~:consid~red~ for ' ·promotion, ;. their 3, Additional Secretary/ Joi.Ilt Secretary, ... ..
~· .. :-senfors·::: would ~ also ·< be •consi-dered . Department of Consumer Affairs.- Member' .
?ptovid~d :.- thef'~.aie . Lnri( :.short . . of · the . Group 'A' _Departmental Promotion
l:teqil1sifo :quilii'fyingJe~igibility ~. service by ·.Committee for confirmation ··· consisting.
i:fuofe :' :· 0 ·1nanc<. ;ifa1f.•''. . -of
such bf :.'_qiiafilYhigieligibifiiy:se~i~~-or t'w6 years, 1. Director.Genen1l, National Test House .
~wili'cl1ever'.:iif-:l~ss;}artd . ha-Ve suc:C'essfolly
Chairman; and .
. 'fo6mpiefoci( t!ifo:. ~probatf6n -'period·, ·for . · 2. · · Joint Secretary, Departriient of ··
. ::·promotion"to : tlie~n"el'fr liigher •grade along Corisumer Affairs.
Member .
~ with)their'. :juniors c:wlio ; 'have already ·
. d:nnpieted :such . \ qiialifyingte1igibility
. ·~ s·~rViCi~f ·: .... ·;
:·.. :. .
· :Promotion:

. ..

.

Departmental Promotion

~i~0~ef.t~~1~1-~~:~i~~~~sth;81;~~~ ;:~~~~;e0ji~r

:.>

0

'fieputatfolit; ·•. (lriali.ling. , ·- Short~term

.g~~~~~~~;g~§f:~,~~J~r.~~:i:~·.

_::'Secto6 > .,_;,,,uii.dertakings/Aufonomous

·; :BO-ciiesFR..i!'~~iiI-drrnstittfretuniversities .
· (~)'(i)~h6Id.iilg analcigous·p6st on.a regular

'. basis.in.the.pareritcadfe/Departirient; or
.

~·.

.

_;

.: ....
·.:

...
·: ·

·,;

:.. ·_:.

;"····

··-·-·-·· --·-----· -

-----------

- - ---- -

<!-- page 10 -->

:..

~-

>

I

1358

THE GAZETTE OF INDIA: DECEMBER 10, 2016/AGRAHAYANA 19, 1938 [PART 11-SEc. 3(i)]

(ii) with five years regular service in the
grade rendered after appointment thereto
on a regular · basis in the level 12 in the
Pay - Matrix rupees . 78800-209200 or
equivalent :. in the · parent cadre/
department; and
(b)
possessing
the
educational
:qualifications and experience prescribed
for direct recruits under Column (7).
. Note 1. The departmental officers in the
feeder category·who are in the direct line
of promotion will not be eligible for
consideration for
appointment on
deputation. Similarly, : deputationist shall
not be · eligible for consideration for
appointment by promotion.
·Note 2. Period ·of deputation (including
short-term contract) including period of
deputation (including short-term contract)
· in another ex-cadre post held immediately
preceding this appointment in the same or
some other Organisation/Department of
the Central .Government shall ordinarily
. not exceed five years.
·Note 3. _The . Maximum .age limit ·for
:·appointment by deputation (including
short term contract) shall be not
·exceeding fifty six years as on the closing
date of the receipt of applications.
Note 4: .For the purpose of appointment
on deputation basis, the service rendered
.on· a regular basis by an officer prior to
51
the 1 January, 2016 or the date from
which the pay matrix · based on the
recommendations of the Seventh Central
Pay Commission has been extended,
shall be deemed to be ser\rice rendered in
the .corresponding level extended based
on the recommendations of the said Pay
Commission

[F. No. A-12018/3/1998-NTH]
D.K. SONK.ER, Dy. Director (NTH)

Upioaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-I I 0064
and Published by the Controller of Publications, Delhi-110054.
AR' 01,11.n,,,,,,..by,.RVESH
SARVESH KUM KUMARSIWASTAVA
SRIVASTAVA · ~;;;01 " 1 ~"'' 1 ~""

------------
