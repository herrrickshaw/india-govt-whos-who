---
doc_id: "d8ec6d0e1bee476c"
source_url: "https://mohua.gov.in/static/uploads/2025/10/c72ec48e9db1a49e17dd294484fa9cf7.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Notification regarding Empowerment of Administrator/Lt. Governor of UTs without Legislature under the Real Estate (Regulation and Development) Act, 2016"
date: "2017-03-03"
pages: 1
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "12d6124b87f97f0c"
---

<!-- page 1 -->

0 LLL
रजिस्ट्री सं० डी० एल०-33004/99 REGD. NO. D. L.-33004/99
REI
| ey
॥॥॥
JTRNa ad Fr <lsiGqa
k f Indi
Che Gazette of jndia
असाधारण
EXTRAORDINARY
भाग 1[-..-खण्ड 3--उप-खण्ड (7)
PART I—Section 3—Sub-section (ii)
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
tim) क्षक्क ऋकत का कक्कल्फ क्र 1231] ..___ऋई दिल्‍ली बुबवाए सजा उप ठ बाज उक्त दिल्‍ली, बुधवार, मई 3, 2017 13, 1939
No. 1231] NEW DELHI, NEY DELHI, WEDNESDAY, MAY 3, 2017/VAISAKHA 13,1939 MAY 3, 2017/VAISAKHA 13, 1939
SSS तन + 33२२...
गृह मंत्रालय
अधिसूचना
नई दिल्‍ली, 2 मई, 2017
का.आ.1394(अ).--राष्ट्रपति, संविधान के अनुच्छेद 239 के खण्ड (1) के अनुसरण में एतट्ठारा यह निदेश देते हैं कि अंडमान एवं
निकोबार द्वीपसमूह, चंडीगढ़, दादरा एवं नगर हवेली, दमण एवं दीव तथा लक्षद्वीप केन्द्र शासित प्रदेशों के संबंध में, रियल एस्टेट
(विनियम एवं विकास) अधिनियम, 2016 (2016 का 16) के अंतर्गत धारा 82 एवं धारा 84 के तहत प्रदत्त शक्तियों से भिन्‍न उपयुक्त
सरकार की शक्तियों एवं कृत्यों का प्रयोग एवं निर्वहन राष्ट्रपति के नियंत्रण के अध्यधीन एवं अगले आदेशों तक, संबंधित केन्द्र शासित प्रदेश
के प्रशासक अथवा उप राज्यपाल, जिस भी नाम से सम्बोधित किया जाता हो, के द्वारा किया जाएगा।
[फा. सं. यू-11030/4/2016-यू टी एल]
प्रवीण कुमार श्रीवास्तव, संयुक्त सचिव
MINISTRY OF HOME AFFAIRS
NOTIFICATION
New Delhi, the 2nd May, 2017
§.0.1394(E).—In pursuance of powers conferred under clause (1) of article 239 of the Constitution, the President
hereby directs that the powers and the functions of the appropriate Government under the Real Estate (Regulation and
Development) Act, 2016 (16 of 2016), other than the Powers under section 82 and section 84, shall, subject to the control
of the President and until further orders, be exercised and discharged, in relation to the Union territories of Andaman and
Nicobar Islands, Chandigarh, Dadra and Nagar Haveli, Daman and Diu and Lakshadweep, by the Administrator or the
Lieutenant Governor, by whatever name called, of the respective Union territory.
(F.No.U-11030/4/2016-UTL]
PRAVEEN KUMAR SRIVASTAVA, Jt. Secy.
2901 GV/2017 "Uploaded by Dis OF Pana _ Faro"
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-1 10064
and Published by the Controller of Publications, Delhi-110054.
ALOK KUMAR pai sinesiy Aton nuns,
