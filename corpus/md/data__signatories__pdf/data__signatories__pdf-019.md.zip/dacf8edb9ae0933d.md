---
doc_id: "dacf8edb9ae0933d"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/69550f995b834ec4a894e2948a88e001.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment of Shri Ashim Shridhar, Advocate as Gr. 'B' Panel Counsel for Supreme Court of India: Order 11.12.2019"
date: "2019-12-11"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ddaea56e990845ba"
---

<!-- page 1 -->

F. No. J-'11016/1/201g-Judicial (Part-1)

Government of lndia
Ministry of Law and Justice
Department of Legal Affairs
(J udicialSection)
Shastri Bhawan, New Delhi,
Dated 1 1th December, 2019

ORDER

The President is pleased to engage Shri Ashim Shridhar, Advocate for
conducting Central Government litigation before the Supreme Court of lndia, as
mentioned below, from the date of this order for a period of three years or until further
orders, whichever is earlier:
SUPREME COURT OF INDIA

GROUP'B' PANEL COUNSEL
NAME (Shri)

Contact details

Enrl. No.

Ashim Shridhar

841227 , Safdarjung Enclave, New

Dt2201t2011

Delhi-1 10029
Mob: 9971547353
Tel. 01 1-23381457

Email: ashim shridhar@hotmail.com

2.

The terms & conditions of the engagement of aforesaid Advocates will be
governed by this Department's OM No.21(4)/99-Judl. dated 24.09.1999 read with OM
No. 26(1)/2014/Judl. dated 0'l .10.2015 & instructions issued subsequently through
OMs. The aforesaid OMs are available on the website of this Department i.e.
www.legalaffairs.gov in in the tab'Judicial Section' under heading 'Circulars pertaining
to litigations'.

3.

Hindi version of this order will follow

<S="t=(S. R. Mishra)
Additional Secretary

Copy to:-

1. PS to ML&J/PS to Law Secretary/Ps to Legislative Secretary/All Additional Secretaries/Ps to all
JS&LA in the Main Sectt.

2. PS to Attorney General, PS to Solicitor General, PS toAll Addl. Solicitors General.
3. The Registrar, Supreme Court of lndia, New Delhi.
4. The lncharge, Central Agency Section, Supreme Court Compound, New Delhi.
5. All the Branch Secretariats Mumbai, Kolkata, Bengaluru & Chennai.
6. The Group'B'panel counsel, as above.
7. The Pay & Accounts Office, Department of Legal Affairs, New Delhi.
8. One copy of this order is uploaded on website of this Department i.e. www.legalaffairs.gov. in under
tab 'Judicial Sect'on' in the link 'List of empanelled Counsel' for the information of all concerned.
9. Hindi unit, Oepartment of Legal Affairs for Hindi translation of the order.
---...,A-\ - - -&
10. Guard File/Judicial Section with 5 spare copies.
(D. Srinivas)

Section Officer (Judicial)
Tel. 01 1-23384945
Email: judicial-dla@nic.in
