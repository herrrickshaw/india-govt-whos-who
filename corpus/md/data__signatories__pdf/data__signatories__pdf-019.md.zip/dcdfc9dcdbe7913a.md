---
doc_id: "dcdfc9dcdbe7913a"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/512948953442baea05b03f0aed0f3849.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Trusted Telecom Portal - Policy regarding input of data pertaining to Non-India Registered OEMs"
date: "2021-07-08"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "309bd43a67528090"
---

<!-- page 1 -->

To
All Telecom Service Providers

Subject: Trusted Telecom Portal (TTP): Policy regarding
input of data pertaining to Non-India Registered
(NIR) OEMs

1. As per the existing procedure, when Telecom Service Providers (TSPs)
plan to procure directly from a Non-India Registered (NIR) OEM, the
detailed information with regard to the OEM (company) and the product
is to be provided in the Trusted Telecom Portal (TIP) by the TSPs.
However, if the TSPs procure through India Registered OEMs, these
inputs are provided in the portal by the India Registered OEMs.
2. Based on the feedback on interactions with multiple stakeholders and
inputs received through COAi, the procedure regarding input of data in
the TIP when a TSP plans to procure directly from a NIR OEM has been
revised. The revised policy is deliberated in below Paragraphs.
3. In cases where a TSP plans to procure through a NIR OEM, and the NIR
OEM has an India Registered entity, then the NIR OEM (parent entity)
can nominate its India Registered Entity to interact with the Trusted
Telecom Portal through its authorized Nodal Officer. The Letter of
Nomination should be ink signed by the authorized signatory of the NIR
OEM and supported by an appropriate Board Resolution of the NIR OEM
empowering the Authorized Signatory. The format for Letter of
Nomination of India Registered Entity by NIR OEM is enclosed as
Form 3.
4. Upon such nomination, the India Registered Entity of the NIR OEM would
be required to provide the Letter of Authorisation for the nominated nodal
officer, as per format given in Form 4, along with the documents
mentioned in Paragraph 3 above to the address given below:

<!-- page 2 -->

The Director
Trusted Telecom Cell, Room No 208
National Security Council Secretariat,
SP Bhawan, Sansad Marg,
New Delhi 110 001
5. The nominations so received will be scrutinized and upon acceptance of
the same, the Nominated Nodal Officer of the India Registered Entity of
the NIR OEM will be allowed access to the Trusted Telecom Portal to
provide required information on behalf of the NIR OEM.
6. In case of any further queries, you may contact on email dirttc­
nscs@gov.in or tele number +911123451596.

<!-- page 3 -->

FORM3

Letter of Nomination of its India Registered Entity by Non­
India Registered OEM for interaction with Trusted
Telecom Portal

1.

................................ (Name of NIR OEM) hereby nominates its India

Registered Entity M/s........................................... (Name of the India
Registered Entity) and authorizes it to provide information with respect to our
Company and the Product we intend to sell to an Indian Telecom Service Provider.

2.

We also authorize ................................................... (Name of the India

Registered Entity) to nominate a Nodal Officer from their company who will be
authorized to interact with the Trusted Telecom Portal and provide information as in
Paragraph 1 above.

3.

We agree that all such information provided by the designated Nodal Officer

from the India Registered Entity in the Trusted Telecom Portal for implementation of
National Security Directive on Telecommunication Sector (NSDTS) is authenticated
by us.
4.

The India Registered Entity is authorized to provide information through the

designated Nodal Officer as and when required by the Designated Authority through
Online I Offline means and same is authenticated by us.

(Signature of Authorised Signatory of Non-India
Registered OEM)
Name
Designation
Date:

Enclosed: Copy of board resolution of the NIR OEM empowering the authorized
signatory of the Company

•.

<!-- page 4 -->

..
' ' '

..

FORM4

Letter of Authorization for Nodal Officer of India
Registered Entity of Non-India Registered OEM
This is to certify that Mr. I Ms ............................................ is employed in

1.

............................................................... (name of the India Registered Entity of
NIR OEM) as .................................................... (designation).

He I She is assigned as the Nodal officer by........................................(Name

2.

of the India Registered Entity of NIR OEM) to access and provide all information on
the Trusted Telecom Portal on behalf of both ..................................... (India
Registered Entity of NIR OEM) and ......................................:.. (Non-India
Registered OEM) with effect from ................... 2021.

He I She is also authorized to provide information as and when required by the

3.

Designated Authority through Online I Offline means on behalf of both .............. ..
...... ...... ...... ...... ...... ...... . (India Registered Entity of NIR OEM) and .......... ..
... ... ... ... ... ... ... ... ... ... ... ... ..... (Non-India Registered OEM)
4.

His I Her specimen signatures for offline communication is as appended below:

5.

His I Her email id and Mobile number for authentication purpose will be as
follows:
a) email id:
b) Mobile number:
(Signature of Authorised Signatory of the India
Registered Entity of NIR OEM)
Name
Designation
DIN if applicable
Date:

Enclosed: Copy of board resolution authorizing the Signatory of the Company
