---
doc_id: "dc4e6d9bd0acb98c"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/caf26bfe91710e93942998e3ae8982a4.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Note 12"
date: "1998-08-31"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "724a005308d21b73"
---

<!-- page 1 -->

PRESS NOTE NO. 12
(1998 SERIES)

Government of India
Ministry of Industry
Department of Industrial Policy & Promotion
Udyog Bhawan,
Subject: De-licensing of Sugar Industry

1. The Government has further reviewed the list of industries retained under compulsory licensing,
and has decided to delete sugar industry from the list of industries requiring compulsory
licensing under the provisions of the Industries (Development and Regulation) Act, 1951.
However, in order to avoid unhealthy competition among sugar factories to procure sugarcane, a
minimum distance of 15 KM would continue to be observed between an existing sugar mill and
a new mill by exercise of powers under the Sugarcane Control Order, 1966.
2. The entrepreneurs who wish to avail themselves of the de-licensing of sugar industry would be required
to file an Industrial Entrepreneur Memoranda (IEM) with the Secretariat of Industrial Assistance in the
Ministry of Industry as laid down for all de-licensed industries in terms of the Press Note dated 2nd
August, 1991, as amended from time to time.
3. Entrepreneurs who have been issued Letter(s) of Intent (LOI) for manufacture of sugar need not file an
initial IEM. In such cases, the LOI holder shall only file Part "B" of the IEM at the time of commencement
of commercial production against the LOI issued to them. It is however open to entrepreneurs to file an
initial IEM (in lieu of the LOI/ Industrial Licence held by them) if they so desire, whenever any variation
from the conditions and parameters stipulated in the LOI/ Industrial License is contemplated.
(ASHOK KUMAR)
Joint Secretary to the Government of India
New Delhi, the 31st August, 1998

(ASHOK KUMAR)
Joint Secretary to the Government of India
