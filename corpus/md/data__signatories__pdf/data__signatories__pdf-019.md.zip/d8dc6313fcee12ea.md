---
doc_id: "d8dc6313fcee12ea"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/86ed0bde35b21d3c9833d6abff6f0f37.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Raising of age limit from 33 to 37 years for appointment of Senior Residents in the Central Govt. Hospitals / Institutions including Statutory / Autonomous bodies wholly financed by the Central Govt. -reg."
date: "2018-02-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "188556cb096e1fd8"
---

<!-- page 1 -->

No. S. 11014/01/2017-ME-I)
Government of India
Ministry of Health & Family Welfare
(Department of Health and Family Welfare)
***
Nirman Bhawan, New Delhi
Dated the o4February, 2018
To
The Directors/Medical Superintendents/Deans,
of All Central Government Hospitals/Institutions including
Statutory/Autonomous bodies wholly financed by the Central Govt.
Subject: Raising of age limit from 33 to 37 years for appointment of Senior Residents in the
Central Govt. Hospitals / Institutions including Statutory / Autonomous bodies
wholly financed by the Central Govt. -reg.
I am directed to say that the Ministry of Health & Family Welfare vide letter No.
5.11014/33/89-ME (P) dated 06.05.1991 had earlier raised the age limit for appointment
of Senior Residents from 30 to 33 years under the Residency Scheme applicable to the
Central Govt. Hospitals/Institutions including Statutory/Autonomous bodies wholly
financed by the Central Government Medical Council of India vide Notification dated
08.06.2017 amended the "Minimum Qualification for Teachers in Medical Institutions
Regulations, 1998", vide which among other things, a Senior Resident (Broad Specialties) is
defined as under :"Senior Resident is one who is doing his/her residency in the concerned post
graduate subject after obtaining PG degree (MD/MS) and is below 40 years of age"
In the above background, representations have been received in the Ministry for
2.
raising the upper age limit for appointment as Senior Residents under the Residency
Scheme of the Central Govt. The matter has been examined in consultation with Directorate
General of Health Services and it has been decided that the upper age limit for appointment
to the post of Senior Resident in Central Govt. Hospitals/ Institutions including
Statutory/Autonomous bodies wholly financed by the Central Govt. shall be 37 years with
immediate effect. The age limit is relaxable by 5 years for SC/ST candidates
Yours faithfully,

(DVK Rao)
Under Secretary to the Govt. of India
" Ph. 011-23062959.
Copy to:
Directorate General of Health Services, Nirman Bhawan, New Delhi.
Principal Secretaries (Health/Medical Education) of All State Govts./UTs with
the request to consider adopting the revised age limit in their respective
States/UTs.
