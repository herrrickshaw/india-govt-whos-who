---
doc_id: "dbfede4dfe8eff37"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/4f6278d1e5f93fbf94939664ac4c2d63.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment dated 19th May 2006 to the detailed guidelines dated 01.11.2001 for migration of existing operators and issue of fresh licence for Public Mobile Radio Trunking Services"
date: "2006-05-19"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6d2c65a0a23b4a47"
---

<!-- page 1 -->

Government of India �
Ministry of Communications & Information Technology �
Department of Telecommunications �
(VAS Cell) �
Sanchar Bhavan, 20 Ashoka Road, New Delhi -110001. �
No.311-88/2005-VAS/30 �

Dated: 19 .05.2006

To
All Public Mobile Radio Trunking Services Licensees
Subject: Amendment to the detailed guidelines dated 01.11.2001 for migration of existing
operators and issue of fresh licence for Public Mobile Radio Trunking Services.
The undersigned is directed to convey the approval of competent authority for
amendment of the following clause(s) of the detailed guidelines dated 01.11.2001 for
migration of existing operators and issue of fresh licence for Public Mobile Radio Trunking
Services (PMRTS). The existing and amended clauses are as under:Existing
Clause B(ii)
New licences for operation of PMRTS shall
be granted on non-exclusive “first-cum-first
served” basis. One MHz frequency
spectrum shall be allotted at the time of
grant of licence.
Clause B(iii) �
Fresh PMRTS licensees shall be bound to
use only digital technology.

Amended �
Clause B(ii) �
New licences for operation of PMRTS shall be
granted on non-exclusive“first-cum-first served”
basis.
Clause B(iii)
Frequency spectrum shall be allotted depending upon
the justified requirements and the availability of the
same.

2.
Other clauses of the detailed guidelines dated 01.11.2001 for migration of existing
operators and issue of fresh licence for Public Mobile Radio Trunking Services (PMRTS)
shall remain unchanged.
Sd/(Rajvir Sharma) �
Director (VAS-I) �
Ph:-23036253 �
Copy to :1. � Wireless Advisor, WPC, DoT, Sanchar Bhavan, New Delhi -1
2. � Sr.DDG(TEC), K.L.Bhavan , New Delhi –1
3. � Sr.DDG(LF), DoT, Sanchar Bhavan, New Delhi –1
4. � Secretary, TRAI, New Delhi.
5. � DDG(LR), Sanchar Bhavan , New Delhi-1 with request to arrange to publish the
amendment on DoT website www.dotindia.gov.in.
