---
doc_id: "dcaeda6b507b2e16"
source_url: "https://www.dsir.gov.in/static/uploads/2025/10/7097c6d14e1b16c0a7773daefa1b1380.pdf"
ministry: "Department of Scientific and Industrial Research (DSIR)"
title: "Open Tender for inviting quotations for hiring Auto-rickshaw (TSR) on monthly package basis for the official use in the Department of Scientific and Industrial Research(DSIR)"
date: "2025-10-30"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "759698880a9923d1"
---

<!-- page 1 -->

LIMITED TENDER NOTICE

No.D-260171112019-cA
Government of tndia
Ministry of Science & Technology

Department of Scientific & Industrial Research
IAN ISO 9001:2008 CERTIFIED DEPARTMENTI

62{P\-./\Y"g/
w'*.*6t3i.

Technology Bhawan,
New Mehrauli Road,
New Delhi_110016.
Dated: 18 Janiuary,2022

Sub:- Open Tender for inviting quotations for hiring Auto-rickshaw (TSR) on monthly
package basis for the officilal use in the Department of Scientific and Industrial
Research (DSIR).

On behalf of the President of India, O"p"rtrn"nt of Scientific and Industrial Research (DSIR),
Government of India, New Delhi, invites quotations for hiring Auto-rickshaw (TSR) with driver
(Dispatch Rider) on monthly package contract basis for the official use in the Deparlment of
Scientific and Industrial Research (DSIR), for delivery/collection of dak/ packets/reports etc. Initially
this will be for a period of ONEyear but can be extended furtheron annual basis up to maximum 3
years on annual basis, on the same rates, terms & conditions, subject to mutually agreed to the
Deptt. and the service provider.The rates of package(s) isi are to be filled up in the enclosed
prescribed proforma. The terms and conditions of hiring of TSR are mentioned below:

1. The services of the Auto-rickshaw (TSR) is required for delivery and collection of Dak, Files,
Reports etc. for official use of the Department of Scientific and Industrial Research. The main
secretariat of the Depadment is at Technology Bhawan, New Mehrauli Road, New Delhi.
2.

The driver should be fully aware of the traffic regulations as well as the road routes of Delhi
city and location of various offices in Delhi as he has to deliver/collect dak/packets/files etc. of the
Department.

3. Only such person can submit his quotation who has 'Auto-rickshaw' in his/her own name
and having valid driving l[cense. The owner/driver must have all the necessary documents
(Registration, Insurance Papers, PUC Cerlificate etc.) The driver will have to carry mobile phone of
his own while on duty.

4.
5.

The TSR should be in excellent working condition.

The TSR owner shall have to comply with the relevant laws and rules issued in respect of

TSR from time to time. The Department will not be responsible for any lapse on the part of the TSR
owner during or after the expiry of the contract.

6.

The TSR owner will report for duty at Technology Bhawan at 9.00 A.M. in the morning. The
normal working hours are from 9.00 AM to 6.00 PM on Monday to Friday, but he has to perform
duty on odd hours as and when required by the Department, Dak will be distributed/collected twice
a day i.e. at 10.30 AM and 2.30 PM invariably, and if required he may be asked for third or more
rounds. During duty hours he will be solely responsible for the Dak, documents, files, packets etc.
in his possession and will deliver the documents/letters/packets to the addressees and get
acknowledgement thereof. Mileage and time in a day would be counted from first duty point to last
duty point only. No night charges will be paid.

7. The TSR driver will be provided a log-book. The driver shall make the entries for the
journeys per{ormed by him date-wise and the same are to be signed by the concerned officer after

<!-- page 2 -->

-:2:completion of day's duty. The log-book will be presented on the first day of the week to Section
Officer (General Admin.) for verification.

8. The bills for hiring of auto-rickshaw should be submitted after the completion of the month.
The payment shall be made on monthly basis.
9. No advance payment, in any case, would be made.
10, The Auto rickshaw Driver shall make alternate arrangement in case of his absence/leave.

In case the vehicle is not made available on any particular day without taking prior permission and
making alternate arrangement, DSIR shall make alternative arrangement by hiring Taxi/TSR for
such period and the amount so spent will be recovered from the monthly bill of TSR.

11. Department of Scientific and Industrial Research shall not be responsible for damages of
any kind for any mishap/acr;idenVinjury caused to the vehicle (s)/drive(s) while per-forming Outy tor
the Ministry. All liabilities, lergal or monetary will have to be borne by the owner.
12. The approved rates will not be changed during the period of the contract.
13. The quotation should accompany an Earnest Money Deposit (EMD) of T1,000/- (Rupees

One Thousand only) in the form of Demand Draft drawn in favour of the DDO, DSIR, New Delhi.
The EMD will be refunded after completion of the selection process of the successful bidder/s.

14. The successful bidderwill have to deposit an amount <15,OOO/- (Rupees FifteenThousand

only) as 'Performance Security Deposit' in the form of Demand Draft or Fixed Deposit drawn in
favour of the DDO, DSIR, New Delhi. The Performance Security Deposit will be refunded within 60
days after successful completion of the contract period.

'15. This contract in DSIR whould be valid for one year, which can be extended further on year to

year basis, subject to satisfactory performance.

16. DSIR reserves the right to terminate the contract at any time if the service of the Autorickshaw Driver is not found satisfactory. The decision of the Department in this regard will be final.
17. The quotation/s may be sent in the enclosed 'Proforma' (along with its Annexure) in a
sealed envelope containing quotations marked 'QUOTATION FOR HIRING AUTO' addressed to
the Under Secretary (Adrnin.), Deptt. of Scientific and Industrial neseare,tr, Oovt. of India,
Technology Bhawan, New Mehrauli Road, New Delhi-110016. Sealed quotations may be dropped
in the Tender Box of DSIR kept near the Reception of Technology Bhawan, New Delhi, or seni by
Post / courier so as to reach the undersigned by the due date and timeby S.bO pM o;
08.02.2022.Tenders sent hy FAX/e-mail will not be considered. The quotations received after
stipulated date & time will not be considered. The quotations will be opened on nextday dated
08.02.2022 at 10.00 A.M. in the Techrrology Bhawan. DSIR reserves the right to reject any or all
the quotations without assigning any reason there
Encl: Annexure -l

.

Under Secretary to the Govt. of India
g 26528472
To

Shri V.K. VarLln, Scientist'F' & Head, lTeG, with request DSIR for uploading this tender on
the official website of the Department and cpp portal at the earliest.

<!-- page 3 -->

Annexure-l
HIRING OF THREE WHEELER
Name of the Owner
Complete Address & Telephone/
Mobile Number
Permanent Account Numher (PAN)
R.C. of Vehicle

Validity of Insurance
Validity of permit
Experie ncecertificate, if any

RATES OF PER MONTH PACKAGE

Breakup of Service

Amount in Rupees

Rates for package of 1650 Kms &270
Hrs. in a month.

Rates for additional Km. and
additional hour beyond 1650 kms &
270 hours

(Signature of the applicant)
Name
Address
Mob.
