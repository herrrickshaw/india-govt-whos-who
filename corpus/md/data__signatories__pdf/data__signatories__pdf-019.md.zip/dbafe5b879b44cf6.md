---
doc_id: "dbafe5b879b44cf6"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/8d0f9e9dc379d2e606761f3818cd9c2d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 1306 of 2025 in the Hon'ble High Court of Delhi: DoT instructions dated 03.06.2026 to ISPs"
date: "2026-06-03"
pages: 62
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c3c4e1da61edec3d"
---

<!-- page 1 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

By Email/ DoT Website
File No.:4-10/2025-DGT/4(Part-VIII)
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
2nd Floor, UIDAI HQ, New Delhi -110001
Date:

-05-2026

To
All Licensees with Internet Service Authorization
Subject: CS(COMM) No. 1306 of 2025: Dazn Limited
abbonamentoiptvitalia.com & Ors. in the Hon’ble High Court of Delhi.

&

Anr.

v.

Please find enclosed the Hon’ble High Court of Delhi order dated 08.12.2025 in the
captioned case.
2.
Please refer to para 36(vii) and 37 of the said Court order along with 18th, 19th, 20th &
21st additional lists received from the plaintiff counsel regarding blocking access to the total
409 no’s of websites/domains as listed in the enclosed list.
3.
In view of the above, all Licensees with Internet Service Authorization are hereby
instructed to take immediate necessary action in respect of blocking access to the said
website(s)/domain(s), as per the enclosed list, in compliance with the said court orders.

Encl: A/A

ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court order/
enclosed Annexure pl.
ii.)
Mr. Manish Rawat (mrawat@saikrishnaassociates.com), Plaintiff's Counsel For kind information and with a request to take action as per the enclosed Annexure
pl.

<!-- page 2 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

CS(COMM) No. 1306 of 2025:
websites/domains

List 18
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39

URL/Domain/IP
feartv.de
germany8k.store
aminoxiptv.de
streamhaus.tv
berlin8k.xyz
subsly-tv.de
4ktivi.de
ger-8k.com
warfen8k.pro
skyde.top
iptvanbietersky.de
tvnexus.live
ultimateipzwei.com
beirutiptv.de
boersenpdfzwei.store
germanfast8k.de
preussenfighter.live
xtream-pro.de
ger8k.xyz
samborita.de
kevintv.de
pash26.de
germany8k.online
secret-s8k.de
ranktv.de
cccmia-stg.de
ch-lohaus.de
8k-de.top
thousandsunny.de
neexvio.de
uptv-platform.me
candy8k.xyz
iptvstore2.click
8k-pro-iptvstore.cc
iptvstore1.click
iptvstore.host
8k-pro-iptvstore.com
saphiriptvstorestrong.com
omega-mg8k.world

Registrar
1blu GmbH
NameCheap, Inc.
eNom LLC
Synergy Wholesale Accreditations Pty Ltd
Namecheap
IP-Projects GmbH & Co. KG
HOSTINGER operations, UAB
NameCheap, Inc.
NameCheap, Inc.
OVH,sas
Key-Systems GmbH
NameCheap, Inc.
NameCheap, Inc.
united-domains GmbH
NameCheap, Inc.
PORKBUN, LLC
NameCheap, Inc.
Key-Systems GmbH
Namecheap
1blu GmbH
NameCheap Inc.
Checkdomain GmbH
NameCheap, Inc.
InterNetX GmbH
NameCheap Inc.
NameCheap Inc.
OVH GmbH
Spaceship, Inc.
netcup GmbH
InterNetX GmbH
OVH SAS
Namecheap
NAMECHEAP
NameCheap, Inc.
NAMECHEAP
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.

<!-- page 3 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56

omega-mg8k.xyz
omega-mg8k.fit
omega-mg8k.cloud
pro.legion8k.com
omega-mg8k.ink
candy8k2.xyz
omegamg.watch
gaminghub8k.online
x1store.xyz
x1store.site
x1store.space
x1strong.store
x1s.site
x1s.online
pommefriet.be
xstore.live
playergox.me

Namecheap
NameCheap, Inc.
NAMECHEAP
NameSilo, LLC
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Key-Systems GmbH
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24

URL/Domain/IP
line.baati.xyz
line.gayega.xyz
line.yearter.xyz
line.x1fast.vip
candycloudtrex.fyi
candycloudtrex.men
candytrex.fyi
line.cheaplytrex.com
innovationtv.eu
mag.ugoiptv.com
vpn.cheaplytrex.com
es.cheaplytrex.com
it.cheaplytrex.com
gr.cheaplytrex.com
vpn.vpntxvpn.ru
omegamgtrex.men
omegamgtrex.fyi
omegamgtrexofficial.men
omegamgtrexofficial.fyi
omega.wd.trxdnscloud.ru
omegamg.wd.trxdnscloud.ru
candycloudtrexofficial.fyi
candycloudtrexofficial.men
arslantekone.us

Registrar
Namecheap
Namecheap
Namecheap
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
NameCheap, Inc.
Dynadot LLC
Tucows Domains Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
R01-RU
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
RU-CENTER-RU
RU-CENTER-RU
Spaceship, Inc.
Spaceship, Inc.
NameCheap, Inc.

S.No. URL/Domain/IP
1
iptvstreaming.art
2
joinlive.awslink.xyz

Registrar
Namecheap
TLD Registrar Solutions Ltd

<!-- page 4 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

3
4

cockpit.awslink.site
server37.ydvioctst.store

NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3
4
5
6
7
8
9
10
11

URL/Domain/IP
candydream.fyi
admin-12k.org
hibanet.online
lineiptv-4kvip.cc
nvidia21282.wd.hamhg76251.xyz
candycloudeagl4k.fyi
best-fra.org
gaminghub-d4k.xyz
vp.gaminghub-d4k.xyz
cdn23601.vip-cdn-d4k.com
154204139570.4k-26com.com

Registrar
Spaceship, Inc.
Dynadot Inc
Dynadot Inc
HOSTINGER operations, UAB
Namecheap
Spaceship, Inc.
Dynadot Inc
Namecheap
Namecheap
Dynadot Inc
Cloud DNS Ltd

S.No.
1
2
3
4
5
6
7

URL/Domain/IP
0099001.xyz
gaminghub-b1g.store
yoursyco.sbs
candycloud.blog
b1g-pro-iptvstore.cc
tv.8dott.xyz
tv8k.store

Registrar
Namecheap
NameCheap, Inc.
HOSTINGER operations, UAB
Namecheap
NameCheap, Inc.
Namecheap
NameCheap, Inc.

S.No.
1
2
3
4
5
6

URL/Domain/IP
line.dndnscloud.ru
wowtv.cc
marovis.xyz
line.x1-dino.online
omegamgdino.fyi
omegamgdino.men

Registrar
RU-CENTER-RU
Immaterialism Limited
NameSilo, LLC
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.

S.No.
1
2
3
4
5

URL/Domain/IP
wrpdictf.pricedns.com
wrpdictf.yangsmart.com
vyijpxev.rmhat.com
rtvcjpza.yangsmart.com
9721196.c21s.cc

Registrar
NameCheap, Inc.
NameCheap, Inc.
Realtime Register B.V.
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3
4

URL/Domain/IP
cdn-z2rlw16r.b-cdn.net
nggwqctx.mcbsmart.com
line.tivigaminghub.xyz
line.hey-ott.net

Registrar
Name.com, Inc.
NameCheap, Inc.
Namecheap
Tucows Domains Inc.

<!-- page 5 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

S.No.
1
2
3
4
5
6
7
8

URL/Domain/IP
mrbo.cc
mrbo.me
mrbo.nl
r656.vip
v2.yoyoyoyoplaywithme.vip
psn.bizertybizerty.bz
www.r56mail.com
max.francemail.top

Registrar
NameCheap, Inc.
NameCheap, Inc.
NAMECHEAP, INC.
NameCheap, Inc.
NameCheap, Inc.
Immaterialism Limited
NameCheap, Inc.
Spaceship, Inc.

S.No.
1
2
3
4

URL/Domain/IP
jbczezar.megaxeno.com
neo.paixif.com
jbczezar.xenontv2.xyz
8808874.lbtx4.xyz

Registrar
NameCheap, Inc.
Realtime Register B.V.
Namecheap
Namecheap

S.No. URL/Domain/IP
1
atlasproontv.top
2
ap4ko.net

Registrar
HOSTINGER operations, UAB
NameCheap, Inc.

S.No.
1
2
3
4

URL/Domain/IP
king-365.com
r360.fyi
r60.fyi
r365.io

Registrar
Dynadot Inc
NameCheap, Inc.
NameCheap, Inc.
eNom, LLC

S.No.
1
2
3

URL/Domain/IP
vevox.365me.art
vevox-tv.art
bossmail.shop

Registrar
Dynadot LLC
Dynadot LLC
Spaceship, Inc.

List 19
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13

URL/Domain/IP
wache.xyz
cf.viewand.xyz
cf.strong-gaminghub.xyz
8k.wd.strong-gaminghub.xyz
pro.strong-gaminghub.xyz
cf.super-gaminhub.xyz
cf.vip8kgaming.xyz
cf.supergaminghub.xyz
cf.gaminghub8k.xyz
cf.bek252.xyz
dhea22.xyz
bek252.xyz
cf.dhea22.xyz

Registrar
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap

<!-- page 6 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40

omegamg8k.fyi
candycloud8kstrng.men
candycloud8kstrng.fyi
candycloudstrng8k.fyi
candycloudstrng8k.men
pro.0699906.xyz
digitalsale.digital
tech22.me
stream4k.best
5874.cloud
tvgc.click
vpss.click
4kdream.cloud
566213.cloud
745562.cloud
x1strong.space
x1s.space
x1strong.online
streamx1.xyz
x1x1.fun
connecttx1.sbs
proiptv-premium.xyz
proiptvpremium.xyz
proiptvstream.sbs
cf.strongiptv8.com
vip5546.site
cf.business-cloud-8k.com

Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Spaceship, Inc.
NAMECHEAP
NAMECHEAP
NAMECHEAP
HOSTINGER operations, UAB
NAMECHEAP
NAMECHEAP
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap
HOSTINGER operations, UAB
Namecheap
Namecheap
Namecheap
HOSTINGER operations, UAB
NameCheap, Inc.
NameCheap, Inc.
PDR Ltd. d/b/a PublicDomainRegistry.com

S.No.
1
2
3
4
5
6
7
8

URL/Domain/IP
candycloudmagnum.fyi
mail.astrogol.com
candygoldenott.fyi
candycloudgoldenott.fyi
novirexa.cc
zantrivo.cc
qorvexia.cc
gol.ndcgl.com

Registrar
Spaceship, Inc.
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3
4
5
6

URL/Domain/IP
gen.gengengen.live
adoiptv.com
list2.thekingiptv.com
iptv.mstrihi.com
my.amazing-tv.com
portal.checkouttv.xyz

Registrar
GoDaddy.com, LLC
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap

<!-- page 7 -->

4-10/2025-DGT/4(PartVIII)

S.No.
1
2
3
4
5
6

I/3404892/2026

URL/Domain/IP
vennetv.net
vennetv.cx
stv-pr.cx
s-tv.cx
s-tv.cc
sero.cx

Registrar
NameCheap, Inc.
CentralNic Ltd
CentralNic Ltd
CentralNic Ltd
Immaterialism Limited
CentralNic Ltd

S.No. URL/Domain/IP
1
seroip.tv
2
iptvsero.com

Registrar
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3
4
5

URL/Domain/IP
iptvuke.it.com
xrexmtpm.teckndc.com
xrexmtpm.astrogol.com
bg12.ewmsu.com
penalhome.xyz

Registrar
Namecheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Dynadot LLC

S.No.
1
2
3
4
5
6
7
8

URL/Domain/IP
activationpanel.tv
line.trexgaminghub.xyz
line.germany8k.best
line.cf-x1store.vip
vpn.1610cr7mist.com
vpn.19852109ts.xyz
line.x1-cdn.me
line.ottsources.xyz

Registrar
NameCheap, Inc.
Namecheap
Dynadot LLC
NameCheap, Inc.
Dynadot Inc
Namecheap
NameCheap, Inc.
Namecheap

S.No. URL/Domain/IP
1
m.hakuna-tv.cc
2
hakuna-tv-4k.com

Registrar
Internet Domain Service BS Corp
Hello Internet Corp

S.No.
1
2
3

Registrar
NameCheap, Inc.
Cloud DNS Ltd
Dynadot Inc

URL/Domain/IP
iptvitaliane4k.com
4k.4k-26com.com
smarters-4k.info

S.No. URL/Domain/IP
1
shop.watchhd.to
2
iptv.watchhd.to

Registrar
Government of Kingdom of Tonga
Government of Kingdom of Tonga

List 20
S.No. URL/Domain/IP
1
iptvguardaa.com
2
00004mg.purpleeresto.it

Registrar
HOSTINGER operations, UAB
TLD Registrar Solutions Ltd

<!-- page 8 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

S.No. URL/Domain/IP
1
italia-iptv.com
2
compassdrive.prvtstwo.com

Registrar
HOSTINGER operations, UAB
Sollutium EU sp. z o.o.

S.No. URL/Domain/IP
1
iptvabbonamentiitalia.it
2
he3b09.chucky691028.cc

Registrar
TLD Registrar Solutions Ltd
Internet Domain Service BS Corp

S.No. URL/Domain/IP
1
iptv4kitaly.site
2
cf.trueservice.site

Registrar
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3

Registrar
Realtime Register B.V.
Namecheap
NameCheap, Inc.

URL/Domain/IP
abbonamentoiptvitalia.it
ipfrvdnv.duperab.xyz
ipfrvdnv.aabzx.com

S.No. URL/Domain/IP
1
iptvhd.space
2
eta.965212.top

Registrar
Nicnames, Inc.
NameSilo,LLC

S.No. URL/Domain/IP
1
iptvthebest.best
2
srvr107580.carsetwo.com

Registrar
Sollutium EU sp. z o.o.
Sollutium EU sp. z o.o.

S.No. URL/Domain/IP
1
www9.miglioriptvportal.net
2
miglioriptvitalia.com
3

miglioriptvteam.info

4
5

migliorexplorer.xyz
srvr16950.astrafey.xn--mk1bu44c

Registrar
Internet Domain Service BS Corp
Center of Ukrainian Internet Names
(UKRNAMES)
Center of Ukrainian Internet Names
(UKRNAMES)
URL Solutions Inc.
Key-Systems, LLC

S.No.
1
2
3

URL/Domain/IP
iptvitalian.shop
it.rexloop.live
smart.cwdn.cx

Registrar
Namecheap, Inc.
NameCheap, Inc.
CentralNic Ltd

S.No. URL/Domain/IP
1
iptvitaliano.com
2
9hytba.chucky68273.com

Registrar
Hosting Concepts B.V. d/b/a Registrar.eu
Hello Internet Corp

S.No. URL/Domain/IP
1
iptvitaliana.com

Registrar
NICNAMES, INC.

<!-- page 9 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

S.No. URL/Domain/IP
1
lookiptv24.net

Registrar
HOSTINGER operations, UAB

S.No. URL/Domain/IP
1
iptvsmartnet.com
2
miss34618.wd.vynexcdn.com

Registrar
GoDaddy.com, LLC
DEVEXPANSE LTD d/b/a Regery.com

S.No. URL/Domain/IP
1
link4tv.me
2
ky-tv.cc

Registrar
NameCheap, Inc.
Web Commerce Communications Limited
dba WebNic.cc

S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19

URL/Domain/IP
mailr365.info
r365mail.biz
mair360.blue
r365mail.cam
r365mail.cc
r365mail.live
mailr365.onl
mair367.shop
mailr365.nl
mair374.vip
mailr365.me
r365mail.pink
mailr365.foo
mair381.vip
mair30.city
mair360.me
r365mail.contact
r365mail.fit
mair361.shop

Registrar
eNom, LLC
eNom, LLC
NameCheap, Inc.
eNom, Inc.
eNom, Inc.
eNom, Inc.
eNom, Inc.
Namecheap, Inc.
E-nom Inc
NameCheap, Inc.
eNom, LLC
eNom, LLC
eNom, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
eNom, LLC
eNom, LLC
Namecheap, Inc.

S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13

URL/Domain/IP
atlasptv.cc
medclassic.xyz
meditvclassic.net
1133.site
myvod54.xyz
myvod35.site
oujdaip.xyz
hjikl.xyz
atshow.xyz
myvod512.site
aghd.xyz
jourview.xyz
myvod35.xyz

Registrar
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
Namecheap
Namecheap
Namecheap
NameCheap, Inc.
Namecheap
Namecheap
Namecheap

<!-- page 10 -->

4-10/2025-DGT/4(PartVIII)

14

I/3404892/2026

radhji.xyz

Namecheap

List 21
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43

URL/Domain/IP
swiss8k.xyz
candycloudstrong8k.xyz
omegamg8k.xyz
8kplayer4k12.com
uptv-access.me
uptv-network.me
uptiserv.xyz
domainkaufen.online
celsofrance.online
akshxlensbsnwlfx.de
zurich-suiza.org
businesscloud8k.online
germanygermanygermany.de
germany-tvflash.site
germantv.store
vinetex.de
iamobile.de
hesat-r.de
businesscloud8k.business
jz34-gamhub.xyz
starke8zuschauer.de
candycloud-8k.men
8gaminghub.xyz
starke8free4.de
business-8k.xyz
germantvhub.xyz
x1private8k.store
graufuchs.cc
colour-one.de
x1private.store
sspremium.de
way-gaminghub.xyz
8k-omegamg.xyz
shadowcs8k.de
xstore.fit
candy-cloud-8k.xyz
candy8kcloud2.xyz
cf-business-cloud.site
prokaufen.online
nicebusiness-cloud-8k.com
candy8k4.online
zurich-suiza.xyz
lot66gamhub.xyz

Registrar
Namecheap
Spaceship, Inc.
Spaceship, Inc.
PDR Ltd. d/b/a PublicDomainRegistry.com
OVH SAS
OVH SAS
OVH
NameCheap, Inc.
NameCheap, Inc.
InterNetX GmbH
HOSTINGER operations, UAB
HOSTINGER operations, UAB
netcup GmbH
NameCheap, Inc.
HOSTINGER operations, UAB
InterNetX GmbH
InterNetX GmbH
netcup GmbH
HOSTINGER operations, UAB
Namecheap
InterNetX GmbH
Spaceship, Inc.
Namecheap
Key-Systems GmbH
Spaceship, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Key-Systems GmbH
NameCheap, Inc.
NameCheap Inc.
Namecheap
Spaceship, Inc.
NameCheap Inc.
NameCheap, Inc.
Spaceship, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
HOSTINGER operations, UAB
Namecheap

<!-- page 11 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69

8kgaminghub1.shop
bbt-streamer.de
x1private8k.online
gamhubsupe.xyz
bbt-stream.de
germantv.online
tvgermany275.site
zurich-suiza.com
xstreamportal.com
germantv4.online
strongghub.xyz
amarschalder.de
uptv-strgonline.xyz
uptv-strgplus.xyz
rumpelst.de
4k-dani.ch
strong8k-ger.xyz
ybptv.de
uptv-strgplus.me
swissiptvs.vip
iptv7.de
sbox2.be
woistderhund.xyz
ultieins.online
nexustv.rest
xstore.vip

Namecheap, Inc.
Hetzner Online GmbH
NameCheap, Inc.
Namecheap
Hetzner Online GmbH
NameCheap, Inc.
NameCheap, Inc.
HOSTINGER operations, UAB
NameCheap, Inc.
NameCheap, Inc.
Namecheap
Hetzner Online GmbH
OVH
OVH
Neue Medien Münnich GmbH
Ascio Technologies Inc. Danmark
Namecheap
1blu GmbH
OVH SAS
NameCheap, Inc.
NameCheap Inc.
OVH
Namecheap
NameCheap, Inc.
NAMECHEAP
NameCheap, Inc.

S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14

URL/Domain/IP
mail.pro2-ott.com
premiumorg5.com
premiumorg4.com
ftp.iptv-premium-ott.com
pro.premium-tv.name
ipro.premium-org.com
bestiptv2.premium-tv.org
premium-tv-france.com
premiumorg9.com
tv.premium-org.net
ipro.ipremium-ott.com
premiumorg7.xyz
soul.iptvpro2.com
monde.ottpro2.com

Registrar
PDR Ltd. d/b/a PublicDomainRegistry.com
Name SRS AB
NameCheap, Inc.
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
Name SRS AB
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
Namecheap
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com

S.No.
1
2
3

URL/Domain/IP
fdkdfn.com
fssfe.com
fsaaw.com

Registrar
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.

<!-- page 12 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

4
5
6

uykebeux.ghlts.com
megaottpremium.fit
5638384.magtv.in

7
8
9
10

megaottcandycloud.men
omegamgteams.fyi
megottcandycloud.xyz
54k-vapi-west.ott-flex.de

NameCheap, Inc.
NameCheap, Inc.
Endurance International Group India
Private Limited
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Greenmark IT GmbH

S.No.
1
2
3
4
5
6

URL/Domain/IP
line.dy1161.xyz
francepremiumtv.xyz
670179413646.cdn-plus.com
277037151849.cdn-4tr.com
870021055168.cdn-royal.com
121245236361.dns-e4k-26.sbs

Registrar
Dynadot LLC
Namecheap
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
Dynadot LLC

S.No. URL/Domain/IP
1
atlaspro.in

Registrar

2
3
4
5
6
7

protv.top
tvprotv.in
prolivepp.net
apsmarter.net
azz19.net
ndasat.net

Tucows Domains Inc.
Tucows.com Co
Tucows Domains Inc.
Tucows Domains Inc.
Tucows Domains Inc.
Tucows Domains Inc.
Tucows Domains Inc.

S.No.
1
2
3
4
5
6
7

URL/Domain/IP
candypromax.fit
candypromax.ink
candypromax.fyi
candycloudprommax4k.fyi
app.due-ew.top
line.smart-ultra.cc
opg.bshgcj.top

Registrar
NameCheap, Inc.
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.
NameSilo,LLC
NameCheap, Inc.
NameSilo,LLC

S.No.
1
2
3

URL/Domain/IP
proxpanel.app
proxpanel.live
millcitymax.xyz

Registrar
Tucows Domains Inc
Tucows Domains Inc.
Namecheap

S.No.
1
2
3

URL/Domain/IP
swiss-hd.online
al.efetv.de
powerip.be

Registrar
NameCheap, Inc.
Key-Systems GmbH
Hostnet bv

<!-- page 13 -->

4-10/2025-DGT/4(PartVIII)

I/3404892/2026

S.No.
1
2
3

URL/Domain/IP
line.liondnscloud.ru
francetvlink.xyz
candycloudlion.xyz

Registrar
RU-CENTER-RU
Dynadot LLC
Spaceship, Inc.

S.No.
1
2
3

URL/Domain/IP
proiptv.business
clientportal-proiptv.club
proiptv.link

Registrar
Gandi SAS
PDR Ltd. d/b/a PublicDomainRegistry.com
NAMECHEAP

<!-- page 14 -->

5/27/26, 11:15 AM

Fwd: URGENT | DOT & MEITY | Eighteenth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'bl…

Fwd: URGENT | DOT & MEITY | Eighteenth
Additional List- Compliance for the Order
dated 08.12.2025 passed by the Hon'ble
const1.hq< const1.hq-dgt-dot@govcontractor.nic.in >
High Court of Delhi in CS(COMM) 1306 of
dgt-dot
2025: Dazn Limited & Anr. v.
abbonamentoiptvitalia.com & Ors.

Manish Shukla < dirit.hq-dgt-dot@gov.in >
Mon, 11 May 2026 2:21:11 PM +0530

To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Kripa Shanker Pandey"
<adt.hq-dgt-dot@gov.in>,"SUNIL KUMAR"<const1.hq-dgtdot@govcontractor.nic.in>,"Arun Kumar"<consnt.hq-dgt-dot@govcontractor.in>

हार्दिक शुभकामनाओं के साथ/ With warm regards,
मनीष शुक्ला/ Manish Shukla
निदेशक (टी), डीजीटी मुख्यालय/ Director (T), DGT HQ

============ Forwarded message ============
From: Manish Rawat <mrawat@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Manish Shukla"<dirit.hq-dgt-dot@gov.in>,
<cyberlawlegal@meity.gov.in>, "Dr. Sandip Chatterjee"<gccyberlaw@meity.gov.in>,
"Prafulla Kumar"<pkumar@meity.gov.in>, <sathya.s@meity.gov.in>, "Kripa Shanker
Pandey"<adt.hq-dgt-dot@gov.in>, "Shri Prem Chand Sharma"<ddgit.hq-dgt-dot@gov.in>
Cc: "Yatinder Garg"<yatinder@saikrishnaassociates.com>, "Priyansh Kohli"
<priyansh@saikrishnaassociates.com>, "Ishi Singh"<ishi@saikrishnaassociates.com>,
"Shudhata Sudhir"<shudhata@saikrishnaassociates.com>, "Anurag Kashyap"
<Anurag.Kashyap@dazn.com>
Date: Fri, 08 May 2026 13:04:40 +0530
Subject: URGENT | DOT & MEITY | Eighteenth Additional List- Compliance for the Order
dated 08.12.2025 passed by the Hon'ble High Court of Delhi in CS(COMM) 1306 of 2025:
Dazn Limited & Anr. v. abbonamentoiptvitalia.com & Ors.
============ Forwarded message ============
Dear Sir,

We act on behalf of DAZN Limited and its Indian subsidiary DAZN Software Private
Limited (“DAZN”) having their office at Plot No.1, Survey No.83/1, Floor 17-A and B, Galaxy,
Raidurgam, Hyderabad, Telangana 500081 (hereinafter referred to as “Our Client”). Our Client is the
Plaintiff in the above-captioned suit.

Our Client owns and operates the online streaming platform / website ‘https://dazngroup.com/’
and https://www.dazn.com/en-IN/home (“DAZN”) and its mobile application. DAZN enables its viewers
about:blank

1/4

<!-- page 15 -->

5/27/26, 11:15 AM

Fwd: URGENT | DOT & MEITY | Eighteenth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'bl…

to watch sporting content including live streaming of sporting events etc. It embeds in its system, a highly
evolved video streaming technology, impeccable quality of video streaming and provides a vast library of
sporting and entertainment content, placing it amongst the most popular video streaming services for
sports. The Plaintiffs broadcast various sporting events in the field of boxing, football, martial arts, chess,
tennis, snooker etc. on its platform.

“Serie A Championship” ( the Event) is a renowned football event which commenced on 23rd August
2025 and is scheduled to conclude on 24th May 2026. The ongoing event is the 124th season of top-tier
Italian football, the 94th in a round-robin tournament, and the 16th since its organization under an own
league committee. It is stated that in exercise of the Exclusive Rights the Plaintiff No.1 will exploit the
Exclusive Rights directly and through its affiliated subsidiaries and companies in India i.e. through
Plaintiff No. 2. That these Exclusive rights inter-alia include rights for ongoing and upcoming matches of
the Event.

Our Client has instituted the above-captioned Suit against various ‘rogue’ websites inter alia the
Defendant Nos. 1 to 9 before the Hon’ble High Court of Delhi, inter alia, seeking permanent and exparte ad-interim and temporary injunction restraining infringement of their Broadcast Reproduction
rights arising on account of illegal communication of the Event by Plaintiffs without any permission as
well as for other reliefs.

Our Client has also arrayed various Domain Name Registrars including you, (Defendant No.10 - 19),
WhatsApp LLC (Defendant No.20) , TElegram FZ-LLC ( Defendant No.21) , Payment Processors (
Defendant No. 22-26) , Internet and Telecom Service Providers (ISPs / TSPs), (Defendant No. 27 – 35),
as well as the concerned Government departments i.e. Department of Telecommunication (DoT)
(Defendant No.36) and the Ministry of Information and Technology (MEITY) (Defendant No.37), to
ensure effective compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.

The above-mentioned matter came up before the Hon’ble Justice Manmeet Pritam Singh Arora, Delhi
High Court on 08.12.2025, wherein, the Hon’ble Court was pleased to issue notice to you and was also
pleased to pass an ex-parte ad-interim order in terms of Prayer Clause of the application under Order
XXXIX Rules 1 and 2. The relevant para of the Order dated 08.12.2025 is extracted herein below:

“36. Accordingly, till the next date of hearing the following directions are issued:
I. Defendant Nos. 1- 9, their owners, partners, proprietors, officers, and all others in capacity of
principal or agent acting for and on their behalf, or anyone claiming through, by or under them are
restrained from in any manner hosting, streaming, broadcasting, making available for
viewing/downloading, communicating, and / or sharing without authorization, any part of the Event
i.e., ‘Serie A Championship’ in any manner whatsoever so as to infringe the Plaintiffs’ Exclusive Rights.
II. Defendant Nos. 10 to 19/DNRs are directed to lock and suspend the domain name registrations of the
Defendant Nos. 1 to 9 and their associated domain as mentioned at ANNEXURE-A attached along with
this order and to disclose the complete details such as name, address, email, phone number, IP address,
Mode of payment along with payment details used for registration of domain name by
the registrant(s).
III. Defendant No. 20/WhatsApp LLC is directed to suspend the WhatsApp accounts of the numbers
mentioned in ANNEXURE-B attached along with this order and to provide the BSI report of the said
WhatsApp accounts.
IV. Defendant No. 21/Telegram FZ-LLC is directed to suspend the Telegram account – ‘@migliore_tv
(+39 351 073 9501)’ and to provide the BSI details of the said Telegram account.
V. Defendant Nos. 22 – 26 their directors, partners, officers, affiliates, and all others in capacity of
principal or agent acting for and, on their behalf, or anyone claiming through, by or under are directed
to block the account of the recipient mentioned at ANNEXURE-C attached along with this Order.
VI. Likewise, Defendant Nos. 27 – 35 (ISPs) are directed to block the infringing websites of the
Defendant Nos. 1 to 9.
VII. Defendant Nos. 36 (DoT) and 37 (MeitY) are directed to issue a notification calling upon the
various ISPs registered under it to block access to the infringing websites of Defendant Nos. 1 to 9.
about:blank

2/4

<!-- page 16 -->

5/27/26, 11:15 AM

Fwd: URGENT | DOT & MEITY | Eighteenth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'bl…

VIII. Proforma Defendants will comply with the aforesaid directions within 48 hours from receipt of
this order.
37. During the Event, which is scheduled to last until 24.05.2026 if any further additional
websites/domains/URLs, are discovered by the Plaintiffs, which are unauthorisedly streaming and
communicating content of the live event which is the subject matter of this suit, the Plaintiff is granted
liberty to communicate the details of such websites/URLs to the proforma Defendants i.e., DNRs, ISPs
and DoT as well as MeitY for locking and suspending the said websites/URLs on real time basis without
undue delay. Upon receiving the said intimation from the Plaintiffs, Defendant Nos. 27 – 35 (ISPs) shall
take steps to immediately block the said websites/URLs. Defendant No. 36 (DoT) and Defendant No. 37
(MeitY) shall also issue necessary blocking orders to the ISPs/DNRs for blocking the said websites. The
proforma defendants will take step in a timely manner to ensure that these websites can be blocked on a
real time basis and there is no undue delay.

38. For directions issued hereinabove, the Plaintiffs shall file affidavits providing the details of the
newly discovered websites/domain names/URLs, DNRs which are communicated and locked/blocked
to ensure that the Court is fully informed of the websites in respect of which blocking orders are sought.”

In light of the above Hon’ble Court’s direction under Para 37, we have hereby identified a list of
additional rogue websites/domain/URL, which are engaged in illegally streaming and communicating the
Plaintiff’s Exclusive Content. List of the additional websites/domain/URL is also enclosed herewith and
the evidence against the websites/domain/URL is available in the link below:

https://drive.google.com/drive/folders/13CJSeFxS3B_TeZv7wnc-bLwHK6fUwdT7?usp=sharing

Accordingly, you are hereby requested to comply with the order dated 08.12.2025 by immediately issuing
notifications to all ISPs for blocking the access to the additionally identified rogue
websites/domain/URL, on a real-time basis so that there is no delay.

For your convenience, please find attached the Order dated 08.12.2025, passed by the Hon’ble Court.

Please feel free to contact us should you have any queries.

Please acknowledge a safe receipt of this email.

Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiffs

Manish Singh| Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi - 110003,
India|Tel:+91-11-40244360 (100Lines) |Handphone: +91-9927402957 | Enrolment
Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020

about:blank

3/4

<!-- page 17 -->

5/27/26, 11:15 AM

Fwd: URGENT | DOT & MEITY | Eighteenth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'bl…

• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege,
not being waived or lost by mistaken transmission or receipt. If you have received this
mail in error, please notify us at info@saikrishnaassociates.com immediately by reply
email and destroy the original - any use, disclosure or copying of this mail is unauthorised

2 Attachment(s)

about:blank

Order dated 08.12.2025.pdf

List 18.xlsx

85.9 KB

13.3 KB

4/4

<!-- page 18 -->

List 18
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40

URL/Domain/IP
feartv.de
germany8k.store
aminoxiptv.de
streamhaus.tv
berlin8k.xyz
subsly-tv.de
4ktivi.de
ger-8k.com
warfen8k.pro
skyde.top
iptvanbietersky.de
tvnexus.live
ultimateipzwei.com
beirutiptv.de
boersenpdfzwei.store
germanfast8k.de
preussenfighter.live
xtream-pro.de
ger8k.xyz
samborita.de
kevintv.de
pash26.de
germany8k.online
secret-s8k.de
ranktv.de
cccmia-stg.de
ch-lohaus.de
8k-de.top
thousandsunny.de
neexvio.de
uptv-platform.me
candy8k.xyz
iptvstore2.click
8k-pro-iptvstore.cc
iptvstore1.click
iptvstore.host
8k-pro-iptvstore.com
saphiriptvstorestrong.com
omega-mg8k.world
omega-mg8k.xyz

Registrar
1blu GmbH
NameCheap, Inc.
eNom LLC
Synergy Wholesale Accreditations Pty Ltd
Namecheap
IP-Projects GmbH & Co. KG
HOSTINGER operations, UAB
NameCheap, Inc.
NameCheap, Inc.
OVH,sas
Key-Systems GmbH
NameCheap, Inc.
NameCheap, Inc.
united-domains GmbH
NameCheap, Inc.
PORKBUN, LLC
NameCheap, Inc.
Key-Systems GmbH
Namecheap
1blu GmbH
NameCheap Inc.
Checkdomain GmbH
NameCheap, Inc.
InterNetX GmbH
NameCheap Inc.
NameCheap Inc.
OVH GmbH
Spaceship, Inc.
netcup GmbH
InterNetX GmbH
OVH SAS
Namecheap
NAMECHEAP
NameCheap, Inc.
NAMECHEAP
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap

<!-- page 19 -->

41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56

omega-mg8k.fit
omega-mg8k.cloud
pro.legion8k.com
omega-mg8k.ink
candy8k2.xyz
omegamg.watch
gaminghub8k.online
x1store.xyz
x1store.site
x1store.space
x1strong.store
x1s.site
x1s.online
pommefriet.be
xstore.live
playergox.me

NameCheap, Inc.
NAMECHEAP
NameSilo, LLC
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Key-Systems GmbH
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24

URL/Domain/IP
line.baati.xyz
line.gayega.xyz
line.yearter.xyz
line.x1fast.vip
candycloudtrex.fyi
candycloudtrex.men
candytrex.fyi
line.cheaplytrex.com
innovationtv.eu
mag.ugoiptv.com
vpn.cheaplytrex.com
es.cheaplytrex.com
it.cheaplytrex.com
gr.cheaplytrex.com
vpn.vpntxvpn.ru
omegamgtrex.men
omegamgtrex.fyi
omegamgtrexofficial.men
omegamgtrexofficial.fyi
omega.wd.trxdnscloud.ru
omegamg.wd.trxdnscloud.ru
candycloudtrexofficial.fyi
candycloudtrexofficial.men
arslantekone.us

Registrar
Namecheap
Namecheap
Namecheap
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
NameCheap, Inc.
Dynadot LLC
Tucows Domains Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
R01-RU
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
RU-CENTER-RU
RU-CENTER-RU
Spaceship, Inc.
Spaceship, Inc.
NameCheap, Inc.

<!-- page 20 -->

S.No.
1
2
3
4

URL/Domain/IP
iptvstreaming.art
joinlive.awslink.xyz
cockpit.awslink.site
server37.ydvioctst.store

Registrar
Namecheap
TLD Registrar Solutions Ltd
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3
4
5
6
7
8
9
10
11

URL/Domain/IP
candydream.fyi
admin-12k.org
hibanet.online
lineiptv-4kvip.cc
nvidia21282.wd.hamhg76251.xyz
candycloudeagl4k.fyi
best-fra.org
gaminghub-d4k.xyz
vp.gaminghub-d4k.xyz
cdn23601.vip-cdn-d4k.com
154204139570.4k-26com.com

Registrar
Spaceship, Inc.
Dynadot Inc
Dynadot Inc
HOSTINGER operations, UAB
Namecheap
Spaceship, Inc.
Dynadot Inc
Namecheap
Namecheap
Dynadot Inc
Cloud DNS Ltd

S.No.
1
2
3
4
5
6
7

URL/Domain/IP
0099001.xyz
gaminghub-b1g.store
yoursyco.sbs
candycloud.blog
b1g-pro-iptvstore.cc
tv.8dott.xyz
tv8k.store

Registrar
Namecheap
NameCheap, Inc.
HOSTINGER operations, UAB
Namecheap
NameCheap, Inc.
Namecheap
NameCheap, Inc.

S.No.
1
2
3
4
5
6

URL/Domain/IP
line.dndnscloud.ru
wowtv.cc
marovis.xyz
line.x1-dino.online
omegamgdino.fyi
omegamgdino.men

Registrar
RU-CENTER-RU
Immaterialism Limited
NameSilo, LLC
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.

S.No.
1
2
3
4

URL/Domain/IP
wrpdictf.pricedns.com
wrpdictf.yangsmart.com
vyijpxev.rmhat.com
rtvcjpza.yangsmart.com

Registrar
NameCheap, Inc.
NameCheap, Inc.
Realtime Register B.V.
NameCheap, Inc.

<!-- page 21 -->

5

9721196.c21s.cc

NameCheap, Inc.

S.No.
1
2
3
4

URL/Domain/IP
cdn-z2rlw16r.b-cdn.net
nggwqctx.mcbsmart.com
line.tivigaminghub.xyz
line.hey-ott.net

Registrar
Name.com, Inc.
NameCheap, Inc.
Namecheap
Tucows Domains Inc.

S.No.
1
2
3
4
5
6
7
8

URL/Domain/IP
mrbo.cc
mrbo.me
mrbo.nl
r656.vip
v2.yoyoyoyoplaywithme.vip
psn.bizertybizerty.bz
www.r56mail.com
max.francemail.top

Registrar
NameCheap, Inc.
NameCheap, Inc.
NAMECHEAP, INC.
NameCheap, Inc.
NameCheap, Inc.
Immaterialism Limited
NameCheap, Inc.
Spaceship, Inc.

S.No.
1
2
3
4

URL/Domain/IP
jbczezar.megaxeno.com
neo.paixif.com
jbczezar.xenontv2.xyz
8808874.lbtx4.xyz

Registrar
NameCheap, Inc.
Realtime Register B.V.
Namecheap
Namecheap

S.No.
1
2

URL/Domain/IP
atlasproontv.top
ap4ko.net

Registrar
HOSTINGER operations, UAB
NameCheap, Inc.

S.No.
1
2
3
4

URL/Domain/IP
king-365.com
r360.fyi
r60.fyi
r365.io

Registrar
Dynadot Inc
NameCheap, Inc.
NameCheap, Inc.
eNom, LLC

S.No.
1
2
3

URL/Domain/IP
vevox.365me.art
vevox-tv.art
bossmail.shop

Registrar
Dynadot LLC
Dynadot LLC
Spaceship, Inc.

<!-- page 22 -->

5/27/26, 11:18 AM

URGENT | DOT & MEITY | Nineteenth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble Hig…

URGENT | DOT & MEITY | Nineteenth Additional
List- Compliance for the Order dated 08.12.2025
passed by the Hon'ble High Court of Delhi in
CS(COMM) 1306 of 2025: Dazn Limited & Anr. v.
abbonamentoiptvitalia.com & Ors.

Kripa
< adt.hq-dgt-dot@gov.in >
ShankerPandey

mrawat@saikrishnaassociates.com < mrawat@saikrishnaassociates.com >
Fri, 15 May 2026 3:02:44 PM +0530

To "secy-dot"<secy-dot@nic.in>,"Manish Shukla"<dirit.hq-dgtdot@gov.in>,"cyberlawlegal"<cyberlawlegal@meity.gov.in>,"Dr. Sandip
Chatterjee"<gccyberlaw@meity.gov.in>,"Prafulla Kumar"
<pkumar@meity.gov.in>,"sathya.s"<sathya.s@meity.gov.in>,"Kripa Shanker
Pandey"<adt.hq-dgt-dot@gov.in>,"Shri Prem Chand Sharma"<ddgit.hq-dgtdot@gov.in>
Cc "Yatinder Garg"<yatinder@saikrishnaassociates.com>,"Priyansh Kohli"
<priyansh@saikrishnaassociates.com>,"Ishi Singh"
<ishi@saikrishnaassociates.com>,"Shudhata Sudhir"
<shudhata@saikrishnaassociates.com>,"Anurag Kashyap"
<Anurag.Kashyap@dazn.com>

Dear Sir,

We act on behalf of DAZN Limited and its Indian subsidiary DAZN Software Private
Limited (“DAZN”) having their office at Plot No.1, Survey No.83/1, Floor 17-A and B,
Galaxy, Raidurgam, Hyderabad, Telangana 500081 (hereinafter referred to as “Our
Client”). Our Client is the Plaintiff in the above-captioned suit.

Our Client owns and operates the online streaming platform / website
‘https://dazngroup.com/’ and https://www.dazn.com/en-IN/home (“DAZN”) and its
mobile application. DAZN enables its viewers to watch sporting content including live
streaming of sporting events etc. It embeds in its system, a highly evolved video
streaming technology, impeccable quality of video streaming and provides a vast library
of sporting and entertainment content, placing it amongst the most popular video
streaming services for sports. The Plaintiffs broadcast various sporting events in the
field of boxing, football, martial arts, chess, tennis, snooker etc. on its platform.
“Serie A Championship” ( the Event) is a renowned football event which commenced
on 23rd August 2025 and is scheduled to conclude on 24th May 2026. The ongoing
event is the 124th season of top-tier Italian football, the 94th in a round-robin
tournament, and the 16th since its organization under an own league committee. It is
stated that in exercise of the Exclusive Rights the Plaintiff No.1 will exploit the Exclusive
Rights directly and through its affiliated subsidiaries and companies in India i.e.
through Plaintiff No. 2. That these Exclusive rights inter-alia include rights for ongoing
and upcoming matches of the Event.

about:blank

1/4

<!-- page 23 -->

5/27/26, 11:18 AM

URGENT | DOT & MEITY | Nineteenth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble Hig…

Our Client has instituted the above-captioned Suit against various ‘rogue’ websites inter
alia the Defendant Nos. 1 to 9 before the Hon’ble High Court of Delhi, inter alia, seeking
permanent and ex-parte ad-interim and temporary injunction restraining infringement
of their Broadcast Reproduction rights arising on account of illegal communication of
the Event by Plaintiffs without any permission as well as for other reliefs.
Our Client has also arrayed various Domain Name Registrars including you, (Defendant
No.10 - 19), WhatsApp LLC (Defendant No.20) , TElegram FZ-LLC ( Defendant No.21)
, Payment Processors ( Defendant No. 22-26) , Internet and Telecom Service Providers
(ISPs / TSPs), (Defendant No. 27 – 35), as well as the concerned Government
departments i.e. Department of Telecommunication (DoT) (Defendant No.36) and the
Ministry of Information and Technology (MEITY) (Defendant No.37), to ensure
effective compliance of any orders that the Hon’ble Delhi High Court was inclined to
pass.

The above-mentioned matter came up before the Hon’ble Justice Manmeet Pritam
Singh Arora, Delhi High Court on 08.12.2025, wherein, the Hon’ble Court was pleased
to issue notice to you and was also pleased to pass an ex-parte ad-interim order in terms
of Prayer Clause of the application under Order XXXIX Rules 1 and 2. The relevant para
of the Order dated 08.12.2025 is extracted herein below:
“36. Accordingly, till the next date of hearing the following directions are issued:
I. Defendant Nos. 1- 9, their owners, partners, proprietors, officers, and all others in
capacity of principal or agent acting for and on their behalf, or anyone claiming
through, by or under them are restrained from in any manner hosting, streaming,
broadcasting, making available for viewing/downloading, communicating, and / or
sharing without authorization, any part of the Event i.e., ‘Serie A Championship’ in
any manner whatsoever so as to infringe the Plaintiffs’ Exclusive Rights.
II. Defendant Nos. 10 to 19/DNRs are directed to lock and suspend the domain name
registrations of the Defendant Nos. 1 to 9 and their associated domain as mentioned at
ANNEXURE-A attached along with this order and to disclose the complete details such
as name, address, email, phone number, IP address, Mode of payment along with
payment details used for registration of domain name by the registrant(s).
III. Defendant No. 20/WhatsApp LLC is directed to suspend the WhatsApp accounts of
the numbers mentioned in ANNEXURE-B attached along with this order and to
provide the BSI report of the said WhatsApp accounts.
IV. Defendant No. 21/Telegram FZ-LLC is directed to suspend the Telegram account –
‘@migliore_tv (+39 351 073 9501)’ and to provide the BSI details of the said Telegram
account.
V. Defendant Nos. 22 – 26 their directors, partners, officers, affiliates, and all others
in capacity of principal or agent acting for and, on their behalf, or anyone claiming
through, by or under are directed to block the account of the recipient mentioned at
ANNEXURE-C attached along with this Order.
VI. Likewise, Defendant Nos. 27 – 35 (ISPs) are directed to block the infringing
websites of the Defendant Nos. 1 to 9.
VII. Defendant Nos. 36 (DoT) and 37 (MeitY) are directed to issue a notification
calling upon the various ISPs registered under it to block access to the infringing
websites of Defendant Nos. 1 to 9.
about:blank

2/4

<!-- page 24 -->

5/27/26, 11:18 AM

URGENT | DOT & MEITY | Nineteenth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble Hig…

VIII. Proforma Defendants will comply with the aforesaid directions within 48 hours
from receipt of this order.
37. During the Event, which is scheduled to last until 24.05.2026 if any further
additional websites/domains/URLs, are discovered by the Plaintiffs, which are
unauthorisedly streaming and communicating content of the live event which is the
subject matter of this suit, the Plaintiff is granted liberty to communicate the details of
such websites/URLs to the proforma Defendants i.e., DNRs, ISPs and DoT as well as
MeitY for locking and suspending the said websites/URLs on real time basis without
undue delay. Upon receiving the said intimation from the Plaintiffs, Defendant Nos. 27
– 35 (ISPs) shall take steps to immediately block the said websites/URLs. Defendant
No. 36 (DoT) and Defendant No. 37 (MeitY) shall also issue necessary blocking orders
to the ISPs/DNRs for blocking the said websites. The proforma defendants will take
step in a timely manner to ensure that these websites can be blocked on a real time
basis and there is no undue delay.

38. For directions issued hereinabove, the Plaintiffs shall file affidavits providing the
details of the newly discovered websites/domain names/URLs, DNRs which are
communicated and locked/blocked to ensure that the Court is fully informed of the
websites in respect of which blocking orders are sought.”

In light of the above Hon’ble Court’s direction under Para 37, we have hereby identified
a list of additional rogue websites/domain/URL, which are engaged in illegally
streaming and communicating the Plaintiff’s Exclusive Content. List of the additional
websites/domain/URL is also enclosed herewith and the evidence against the
websites/domain/URL is available in the link below:

https://drive.google.com/drive/folders/13Q5m_r_KcLSCWi7UGZA9-lQTv0StNoIg?
usp=sharing

Accordingly, you are hereby requested to comply with the order dated 08.12.2025
by immediately issuing notifications to all ISPs for blocking the access to the
additionally identified rogue websites/domain/URL, on a real-time basis so that there
is no delay.

For your convenience, please find attached the Order dated 08.12.2025, passed by the
Hon’ble Court.
Please feel free to contact us should you have any queries.
Please acknowledge a safe receipt of this email.
Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiffs
about:blank

3/4

<!-- page 25 -->

5/27/26, 11:18 AM

URGENT | DOT & MEITY | Nineteenth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble Hig…

Manish Singh | Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi 110003, India|Tel:+91-11-40244360 (100Lines) |Handphone: +919927402957 | Enrolment Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment &
Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files
constitutes confidential information of S&A and may also be the subject of
legal professional privilege, not being waived or lost by mistaken
transmission or receipt. If you have received this mail in error,
please notify us at info@saikrishnaassociates.com immediately by reply
email and destroy the original - any use, disclosure or copying of this
mail is unauthorised

2 Attachment(s)

about:blank

List 19.xlsx

Order dated 08.12.2025.pdf

11.7 KB

85.9 KB

4/4

<!-- page 26 -->

List 19
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40

URL/Domain/IP
wache.xyz
cf.viewand.xyz
cf.strong-gaminghub.xyz
8k.wd.strong-gaminghub.xyz
pro.strong-gaminghub.xyz
cf.super-gaminhub.xyz
cf.vip8kgaming.xyz
cf.supergaminghub.xyz
cf.gaminghub8k.xyz
cf.bek252.xyz
dhea22.xyz
bek252.xyz
cf.dhea22.xyz
omegamg8k.fyi
candycloud8kstrng.men
candycloud8kstrng.fyi
candycloudstrng8k.fyi
candycloudstrng8k.men
pro.0699906.xyz
digitalsale.digital
tech22.me
stream4k.best
5874.cloud
tvgc.click
vpss.click
4kdream.cloud
566213.cloud
745562.cloud
x1strong.space
x1s.space
x1strong.online
streamx1.xyz
x1x1.fun
connecttx1.sbs
proiptv-premium.xyz
proiptvpremium.xyz
proiptvstream.sbs
cf.strongiptv8.com
vip5546.site
cf.business-cloud-8k.com

Registrar
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Namecheap
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Spaceship, Inc.
NAMECHEAP
NAMECHEAP
NAMECHEAP
HOSTINGER operations, UAB
NAMECHEAP
NAMECHEAP
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap
HOSTINGER operations, UAB
Namecheap
Namecheap
Namecheap
HOSTINGER operations, UAB
NameCheap, Inc.
NameCheap, Inc.
PDR Ltd. d/b/a PublicDomainRegistry.com

<!-- page 27 -->

S.No.
1
2
3
4
5
6
7
8

URL/Domain/IP
candycloudmagnum.fyi
mail.astrogol.com
candygoldenott.fyi
candycloudgoldenott.fyi
novirexa.cc
zantrivo.cc
qorvexia.cc
gol.ndcgl.com

Registrar
Spaceship, Inc.
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3
4
5
6

URL/Domain/IP
gen.gengengen.live
adoiptv.com
list2.thekingiptv.com
iptv.mstrihi.com
my.amazing-tv.com
portal.checkouttv.xyz

Registrar
GoDaddy.com, LLC
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap

S.No.
1
2
3
4
5
6

URL/Domain/IP
vennetv.net
vennetv.cx
stv-pr.cx
s-tv.cx
s-tv.cc
sero.cx

Registrar
NameCheap, Inc.
CentralNic Ltd
CentralNic Ltd
CentralNic Ltd
Immaterialism Limited
CentralNic Ltd

S.No.
1
2

URL/Domain/IP
seroip.tv
iptvsero.com

Registrar
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3
4
5

URL/Domain/IP
iptvuke.it.com
xrexmtpm.teckndc.com
xrexmtpm.astrogol.com
bg12.ewmsu.com
penalhome.xyz

Registrar
Namecheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Dynadot LLC

S.No.
1
2
3

URL/Domain/IP
activationpanel.tv
line.trexgaminghub.xyz
line.germany8k.best

Registrar
NameCheap, Inc.
Namecheap
Dynadot LLC

<!-- page 28 -->

4
5
6
7
8

line.cf-x1store.vip
vpn.1610cr7mist.com
vpn.19852109ts.xyz
line.x1-cdn.me
line.ottsources.xyz

NameCheap, Inc.
Dynadot Inc
Namecheap
NameCheap, Inc.
Namecheap

S.No.
1
2

URL/Domain/IP
m.hakuna-tv.cc
hakuna-tv-4k.com

Registrar
Internet Domain Service BS Corp
Hello Internet Corp

S.No.
1
2
3

URL/Domain/IP
iptvitaliane4k.com
4k.4k-26com.com
smarters-4k.info

Registrar
NameCheap, Inc.
Cloud DNS Ltd
Dynadot Inc

S.No.
1
2

URL/Domain/IP
shop.watchhd.to
iptv.watchhd.to

Registrar
Government of Kingdom of Tonga
Government of Kingdom of Tonga

<!-- page 29 -->

5/27/26, 11:19 AM

URGENT | DOT & MEITY | Twentieth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble High …

URGENT | DOT & MEITY | Twentieth Additional ListCompliance for the Order dated 08.12.2025 passed
Kripa
by the Hon'ble High Court of Delhi in CS(COMM)
< adt.hq-dgt-dot@gov.in >
ShankerPandey
1306 of 2025: Dazn Limited & Anr. v.
abbonamentoiptvitalia.com & Ors.

mrawat@saikrishnaassociates.com < mrawat@saikrishnaassociates.com >
Thu, 21 May 2026 12:59:47 PM +0530

To "secy-dot"<secy-dot@nic.in>,"Manish Shukla"<dirit.hq-dgtdot@gov.in>,"cyberlawlegal"<cyberlawlegal@meity.gov.in>,"Dr. Sandip
Chatterjee"<gccyberlaw@meity.gov.in>,"Prafulla Kumar"
<pkumar@meity.gov.in>,"sathya.s"<sathya.s@meity.gov.in>,"Kripa Shanker
Pandey"<adt.hq-dgt-dot@gov.in>,"Shri Prem Chand Sharma"<ddgit.hq-dgtdot@gov.in>
Cc "Yatinder Garg"<yatinder@saikrishnaassociates.com>,"Priyansh Kohli"
<priyansh@saikrishnaassociates.com>,"Ishi Singh"
<ishi@saikrishnaassociates.com>,"Shudhata Sudhir"
<shudhata@saikrishnaassociates.com>,"Anurag Kashyap"
<Anurag.Kashyap@dazn.com>

Dear Sir,

We act on behalf of DAZN Limited and its Indian subsidiary DAZN Software Private
Limited (“DAZN”) having their office at Plot No.1, Survey No.83/1, Floor 17-A and B,
Galaxy, Raidurgam, Hyderabad, Telangana 500081 (hereinafter referred to as “Our
Client”). Our Client is the Plaintiff in the above-captioned suit.

Our Client owns and operates the online streaming platform / website
‘https://dazngroup.com/’ and https://www.dazn.com/en-IN/home (“DAZN”) and its
mobile application. DAZN enables its viewers to watch sporting content including live
streaming of sporting events etc. It embeds in its system, a highly evolved video
streaming technology, impeccable quality of video streaming and provides a vast library
of sporting and entertainment content, placing it amongst the most popular video
streaming services for sports. The Plaintiffs broadcast various sporting events in the
field of boxing, football, martial arts, chess, tennis, snooker etc. on its platform.
“Serie A Championship” ( the Event) is a renowned football event which commenced
on 23rd August 2025 and is scheduled to conclude on 24th May 2026. The ongoing
event is the 124th season of top-tier Italian football, the 94th in a round-robin
tournament, and the 16th since its organization under an own league committee. It is
stated that in exercise of the Exclusive Rights the Plaintiff No.1 will exploit the Exclusive
Rights directly and through its affiliated subsidiaries and companies in India i.e.
through Plaintiff No. 2. That these Exclusive rights inter-alia include rights for ongoing
and upcoming matches of the Event.

about:blank

1/4

<!-- page 30 -->

5/27/26, 11:19 AM

URGENT | DOT & MEITY | Twentieth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble High …

Our Client has instituted the above-captioned Suit against various ‘rogue’ websites inter
alia the Defendant Nos. 1 to 9 before the Hon’ble High Court of Delhi, inter alia, seeking
permanent and ex-parte ad-interim and temporary injunction restraining infringement
of their Broadcast Reproduction rights arising on account of illegal communication of
the Event by Plaintiffs without any permission as well as for other reliefs.
Our Client has also arrayed various Domain Name Registrars including you, (Defendant
No.10 - 19), WhatsApp LLC (Defendant No.20) , TElegram FZ-LLC ( Defendant No.21)
, Payment Processors ( Defendant No. 22-26) , Internet and Telecom Service Providers
(ISPs / TSPs), (Defendant No. 27 – 35), as well as the concerned Government
departments i.e. Department of Telecommunication (DoT) (Defendant No.36) and the
Ministry of Information and Technology (MEITY) (Defendant No.37), to ensure
effective compliance of any orders that the Hon’ble Delhi High Court was inclined to
pass.

The above-mentioned matter came up before the Hon’ble Justice Manmeet Pritam
Singh Arora, Delhi High Court on 08.12.2025, wherein, the Hon’ble Court was pleased
to issue notice to you and was also pleased to pass an ex-parte ad-interim order in terms
of Prayer Clause of the application under Order XXXIX Rules 1 and 2. The relevant para
of the Order dated 08.12.2025 is extracted herein below:
“36. Accordingly, till the next date of hearing the following directions are issued:
I. Defendant Nos. 1- 9, their owners, partners, proprietors, officers, and all others in
capacity of principal or agent acting for and on their behalf, or anyone claiming
through, by or under them are restrained from in any manner hosting, streaming,
broadcasting, making available for viewing/downloading, communicating, and / or
sharing without authorization, any part of the Event i.e., ‘Serie A Championship’ in
any manner whatsoever so as to infringe the Plaintiffs’ Exclusive Rights.
II. Defendant Nos. 10 to 19/DNRs are directed to lock and suspend the domain name
registrations of the Defendant Nos. 1 to 9 and their associated domain as mentioned at
ANNEXURE-A attached along with this order and to disclose the complete details such
as name, address, email, phone number, IP address, Mode of payment along with
payment details used for registration of domain name by the registrant(s).
III. Defendant No. 20/WhatsApp LLC is directed to suspend the WhatsApp accounts of
the numbers mentioned in ANNEXURE-B attached along with this order and to
provide the BSI report of the said WhatsApp accounts.
IV. Defendant No. 21/Telegram FZ-LLC is directed to suspend the Telegram account –
‘@migliore_tv (+39 351 073 9501)’ and to provide the BSI details of the said Telegram
account.
V. Defendant Nos. 22 – 26 their directors, partners, officers, affiliates, and all others
in capacity of principal or agent acting for and, on their behalf, or anyone claiming
through, by or under are directed to block the account of the recipient mentioned at
ANNEXURE-C attached along with this Order.
VI. Likewise, Defendant Nos. 27 – 35 (ISPs) are directed to block the infringing
websites of the Defendant Nos. 1 to 9.
VII. Defendant Nos. 36 (DoT) and 37 (MeitY) are directed to issue a notification
calling upon the various ISPs registered under it to block access to the infringing
websites of Defendant Nos. 1 to 9.
about:blank

2/4

<!-- page 31 -->

5/27/26, 11:19 AM

URGENT | DOT & MEITY | Twentieth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble High …

VIII. Proforma Defendants will comply with the aforesaid directions within 48 hours
from receipt of this order.
37. During the Event, which is scheduled to last until 24.05.2026 if any further
additional websites/domains/URLs, are discovered by the Plaintiffs, which are
unauthorisedly streaming and communicating content of the live event which is the
subject matter of this suit, the Plaintiff is granted liberty to communicate the details of
such websites/URLs to the proforma Defendants i.e., DNRs, ISPs and DoT as well as
MeitY for locking and suspending the said websites/URLs on real time basis without
undue delay. Upon receiving the said intimation from the Plaintiffs, Defendant Nos. 27
– 35 (ISPs) shall take steps to immediately block the said websites/URLs. Defendant
No. 36 (DoT) and Defendant No. 37 (MeitY) shall also issue necessary blocking orders
to the ISPs/DNRs for blocking the said websites. The proforma defendants will take
step in a timely manner to ensure that these websites can be blocked on a real time
basis and there is no undue delay.

38. For directions issued hereinabove, the Plaintiffs shall file affidavits providing the
details of the newly discovered websites/domain names/URLs, DNRs which are
communicated and locked/blocked to ensure that the Court is fully informed of the
websites in respect of which blocking orders are sought.”

In light of the above Hon’ble Court’s direction under Para 37, we have hereby identified
a list of additional rogue websites/domain/URL, which are engaged in illegally
streaming and communicating the Plaintiff’s Exclusive Content. List of the additional
websites/domain/URL is also enclosed herewith and the evidence against the
websites/domain/URL is available in the link below:

https://drive.google.com/drive/folders/1LI8SGaJNwuiNG2qfstrY6zgXJE8m4sW5?
usp=sharing

Accordingly, you are hereby requested to comply with the order dated 08.12.2025
by immediately issuing notifications to all ISPs for blocking the access to the
additionally identified rogue websites/domain/URL, on a real-time basis so that there
is no delay.

For your convenience, please find attached the Order dated 08.12.2025, passed by the
Hon’ble Court.
Please feel free to contact us should you have any queries.
Please acknowledge a safe receipt of this email.
Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiffs
about:blank

3/4

<!-- page 32 -->

5/27/26, 11:19 AM

URGENT | DOT & MEITY | Twentieth Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble High …

Manish Singh | Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi 110003, India|Tel:+91-11-40244360 (100Lines) |Handphone: +919927402957 | Enrolment Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment &
Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files
constitutes confidential information of S&A and may also be the subject of
legal professional privilege, not being waived or lost by mistaken
transmission or receipt. If you have received this mail in error,
please notify us at info@saikrishnaassociates.com immediately by reply
email and destroy the original - any use, disclosure or copying of this
mail is unauthorised

2 Attachment(s)

about:blank

List 20.xlsx

Order dated 08.12.2025.pdf

11.6 KB

85.9 KB

4/4

<!-- page 33 -->

List 20
S.No.
1
2

URL/Domain/IP
iptvguardaa.com
00004mg.purpleeresto.it

Registrar
HOSTINGER operations, UAB
TLD Registrar Solutions Ltd

S.No.
1
2

URL/Domain/IP
italia-iptv.com
compassdrive.prvtstwo.com

Registrar
HOSTINGER operations, UAB
Sollutium EU sp. z o.o.

S.No.
1
2

URL/Domain/IP
iptvabbonamentiitalia.it
he3b09.chucky691028.cc

Registrar
TLD Registrar Solutions Ltd
Internet Domain Service BS Corp

S.No.
1
2

URL/Domain/IP
iptv4kitaly.site
cf.trueservice.site

Registrar
NameCheap, Inc.
NameCheap, Inc.

S.No.
1
2
3

URL/Domain/IP
abbonamentoiptvitalia.it
ipfrvdnv.duperab.xyz
ipfrvdnv.aabzx.com

Registrar
Realtime Register B.V.
Namecheap
NameCheap, Inc.

S.No.
1
2

URL/Domain/IP
iptvhd.space
eta.965212.top

Registrar
Nicnames, Inc.
NameSilo,LLC

S.No.
1
2

URL/Domain/IP
iptvthebest.best
srvr107580.carsetwo.com

Registrar
Sollutium EU sp. z o.o.
Sollutium EU sp. z o.o.

S.No.
1
2

URL/Domain/IP
www9.miglioriptvportal.net
miglioriptvitalia.com

3

miglioriptvteam.info

4
5

migliorexplorer.xyz
srvr16950.astrafey.xn--mk1bu44c

Registrar
Internet Domain Service BS Corp
Center of Ukrainian Internet Names
(UKRNAMES)
Center of Ukrainian Internet Names
(UKRNAMES)
URL Solutions Inc.
Key-Systems, LLC

S.No.
1
2

URL/Domain/IP
iptvitalian.shop
it.rexloop.live

Registrar
Namecheap, Inc.
NameCheap, Inc.

<!-- page 34 -->

3

smart.cwdn.cx

CentralNic Ltd

S.No.
1
2

URL/Domain/IP
iptvitaliano.com
9hytba.chucky68273.com

Registrar
Hosting Concepts B.V. d/b/a Registrar.eu
Hello Internet Corp

S.No.
1

URL/Domain/IP
iptvitaliana.com

Registrar
NICNAMES, INC.

S.No.
1

URL/Domain/IP
lookiptv24.net

Registrar
HOSTINGER operations, UAB

S.No.
1
2

URL/Domain/IP
iptvsmartnet.com
miss34618.wd.vynexcdn.com

Registrar
GoDaddy.com, LLC
DEVEXPANSE LTD d/b/a Regery.com

S.No.
1
2

URL/Domain/IP
link4tv.me
ky-tv.cc

Registrar
NameCheap, Inc.
Web Commerce Communications Limited dba
WebNic.cc

S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19

URL/Domain/IP
mailr365.info
r365mail.biz
mair360.blue
r365mail.cam
r365mail.cc
r365mail.live
mailr365.onl
mair367.shop
mailr365.nl
mair374.vip
mailr365.me
r365mail.pink
mailr365.foo
mair381.vip
mair30.city
mair360.me
r365mail.contact
r365mail.fit
mair361.shop

Registrar
eNom, LLC
eNom, LLC
NameCheap, Inc.
eNom, Inc.
eNom, Inc.
eNom, Inc.
eNom, Inc.
Namecheap, Inc.
E-nom Inc
NameCheap, Inc.
eNom, LLC
eNom, LLC
eNom, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
eNom, LLC
eNom, LLC
Namecheap, Inc.

<!-- page 35 -->

S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14

URL/Domain/IP
atlasptv.cc
medclassic.xyz
meditvclassic.net
1133.site
myvod54.xyz
myvod35.site
oujdaip.xyz
hjikl.xyz
atshow.xyz
myvod512.site
aghd.xyz
jourview.xyz
myvod35.xyz
radhji.xyz

Registrar
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
Namecheap
Namecheap
Namecheap
NameCheap, Inc.
Namecheap
Namecheap
Namecheap
Namecheap

<!-- page 36 -->

5/27/26, 11:20 AM

URGENT | DOT & MEITY | Twenty-First Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble Hi…

URGENT | DOT & MEITY | Twenty-First Additional
List- Compliance for the Order dated 08.12.2025
passed by the Hon'ble High Court of Delhi in
CS(COMM) 1306 of 2025: Dazn Limited & Anr. v.
abbonamentoiptvitalia.com & Ors.

Kripa
< adt.hq-dgt-dot@gov.in >
ShankerPandey

mrawat@saikrishnaassociates.com < mrawat@saikrishnaassociates.com >
Mon, 25 May 2026 3:35:53 PM +0530

To "secy-dot"<secy-dot@nic.in>,"Manish Shukla"<dirit.hq-dgtdot@gov.in>,"cyberlawlegal"<cyberlawlegal@meity.gov.in>,"Dr. Sandip
Chatterjee"<gccyberlaw@meity.gov.in>,"Prafulla Kumar"
<pkumar@meity.gov.in>,"sathya.s"<sathya.s@meity.gov.in>,"Kripa Shanker
Pandey"<adt.hq-dgt-dot@gov.in>,"Shri Prem Chand Sharma"<ddgit.hq-dgtdot@gov.in>
Cc "Yatinder Garg"<yatinder@saikrishnaassociates.com>,"Priyansh Kohli"
<priyansh@saikrishnaassociates.com>,"Ishi Singh"
<ishi@saikrishnaassociates.com>,"Shudhata Sudhir"
<shudhata@saikrishnaassociates.com>,"Anurag Kashyap"
<Anurag.Kashyap@dazn.com>

Dear Sir,

We act on behalf of DAZN Limited and its Indian subsidiary DAZN Software Private
Limited (“DAZN”) having their office at Plot No.1, Survey No.83/1, Floor 17-A and B,
Galaxy, Raidurgam, Hyderabad, Telangana 500081 (hereinafter referred to as “Our
Client”). Our Client is the Plaintiff in the above-captioned suit.

Our Client owns and operates the online streaming platform / website
‘https://dazngroup.com/’ and https://www.dazn.com/en-IN/home (“DAZN”) and its
mobile application. DAZN enables its viewers to watch sporting content including live
streaming of sporting events etc. It embeds in its system, a highly evolved video
streaming technology, impeccable quality of video streaming and provides a vast library
of sporting and entertainment content, placing it amongst the most popular video
streaming services for sports. The Plaintiffs broadcast various sporting events in the
field of boxing, football, martial arts, chess, tennis, snooker etc. on its platform.
“Serie A Championship” ( the Event) is a renowned football event which commenced
on 23rd August 2025 and concluded on 24th May 2026. The event is the 124th season
of top-tier Italian football, the 94th in a round-robin tournament, and the 16th since its
organization under an own league committee. It is stated that in exercise of the
Exclusive Rights the Plaintiff No.1 will exploit the Exclusive Rights directly and through
its affiliated subsidiaries and companies in India i.e. through Plaintiff No. 2.

Our Client has instituted the above-captioned Suit against various ‘rogue’ websites inter
alia the Defendant Nos. 1 to 9 before the Hon’ble High Court of Delhi, inter alia, seeking
about:blank

1/4

<!-- page 37 -->

5/27/26, 11:20 AM

URGENT | DOT & MEITY | Twenty-First Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble Hi…

permanent and ex-parte ad-interim and temporary injunction restraining infringement
of their Broadcast Reproduction rights arising on account of illegal communication of
the Event by Plaintiffs without any permission as well as for other reliefs.

Our Client has also arrayed various Domain Name Registrars including you, (Defendant
No.10 - 19), WhatsApp LLC (Defendant No.20) , TElegram FZ-LLC ( Defendant No.21)
, Payment Processors ( Defendant No. 22-26) , Internet and Telecom Service Providers
(ISPs / TSPs), (Defendant No. 27 – 35), as well as the concerned Government
departments i.e. Department of Telecommunication (DoT) (Defendant No.36) and the
Ministry of Information and Technology (MEITY) (Defendant No.37), to ensure
effective compliance of any orders that the Hon’ble Delhi High Court was inclined to
pass.

The above-mentioned matter came up before the Hon’ble Justice Manmeet Pritam
Singh Arora, Delhi High Court on 08.12.2025, wherein, the Hon’ble Court was pleased
to issue notice to you and was also pleased to pass an ex-parte ad-interim order in terms
of Prayer Clause of the application under Order XXXIX Rules 1 and 2. The relevant para
of the Order dated 08.12.2025 is extracted herein below:
“36. Accordingly, till the next date of hearing the following directions are issued:
I. Defendant Nos. 1- 9, their owners, partners, proprietors, officers, and all others in
capacity of principal or agent acting for and on their behalf, or anyone claiming
through, by or under them are restrained from in any manner hosting, streaming,
broadcasting, making available for viewing/downloading, communicating, and / or
sharing without authorization, any part of the Event i.e., ‘Serie A Championship’ in
any manner whatsoever so as to infringe the Plaintiffs’ Exclusive Rights.
II. Defendant Nos. 10 to 19/DNRs are directed to lock and suspend the domain name
registrations of the Defendant Nos. 1 to 9 and their associated domain as mentioned at
ANNEXURE-A attached along with this order and to disclose the complete details such
as name, address, email, phone number, IP address, Mode of payment along with
payment details used for registration of domain name by the registrant(s).
III. Defendant No. 20/WhatsApp LLC is directed to suspend the WhatsApp accounts of
the numbers mentioned in ANNEXURE-B attached along with this order and to
provide the BSI report of the said WhatsApp accounts.
IV. Defendant No. 21/Telegram FZ-LLC is directed to suspend the Telegram account –
‘@migliore_tv (+39 351 073 9501)’ and to provide the BSI details of the said Telegram
account.
V. Defendant Nos. 22 – 26 their directors, partners, officers, affiliates, and all others
in capacity of principal or agent acting for and, on their behalf, or anyone claiming
through, by or under are directed to block the account of the recipient mentioned at
ANNEXURE-C attached along with this Order.
VI. Likewise, Defendant Nos. 27 – 35 (ISPs) are directed to block the infringing
websites of the Defendant Nos. 1 to 9.
VII. Defendant Nos. 36 (DoT) and 37 (MeitY) are directed to issue a notification
calling upon the various ISPs registered under it to block access to the infringing
websites of Defendant Nos. 1 to 9.
VIII. Proforma Defendants will comply with the aforesaid directions within 48 hours
from receipt of this order.
about:blank

2/4

<!-- page 38 -->

5/27/26, 11:20 AM

URGENT | DOT & MEITY | Twenty-First Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble Hi…

37. During the Event, which is scheduled to last until 24.05.2026 if any further
additional websites/domains/URLs, are discovered by the Plaintiffs, which are
unauthorisedly streaming and communicating content of the live event which is the
subject matter of this suit, the Plaintiff is granted liberty to communicate the details of
such websites/URLs to the proforma Defendants i.e., DNRs, ISPs and DoT as well as
MeitY for locking and suspending the said websites/URLs on real time basis without
undue delay. Upon receiving the said intimation from the Plaintiffs, Defendant Nos. 27
– 35 (ISPs) shall take steps to immediately block the said websites/URLs. Defendant
No. 36 (DoT) and Defendant No. 37 (MeitY) shall also issue necessary blocking orders
to the ISPs/DNRs for blocking the said websites. The proforma defendants will take
step in a timely manner to ensure that these websites can be blocked on a real time
basis and there is no undue delay.

38. For directions issued hereinabove, the Plaintiffs shall file affidavits providing the
details of the newly discovered websites/domain names/URLs, DNRs which are
communicated and locked/blocked to ensure that the Court is fully informed of the
websites in respect of which blocking orders are sought.”

In light of the above Hon’ble Court’s direction under Para 37, we have hereby identified
a list of additional rogue websites/domain/URL, which are engaged in illegally
streaming and communicating the Plaintiff’s Exclusive Content. List of the additional
websites/domain/URL is also enclosed herewith and the evidence against the
websites/domain/URL is available in the link below:

https://drive.google.com/drive/folders/1RMHIrifN53q3SjQLN7KsbgURLFezmVUY?
usp=sharing

Accordingly, you are hereby requested to comply with the order dated 08.12.2025
by immediately issuing notifications to all ISPs for blocking the access to the
additionally identified rogue websites/domain/URL, on a real-time basis so that there
is no delay.
For your convenience, please find attached the Order dated 08.12.2025, passed by the
Hon’ble Court.

Please feel free to contact us should you have any queries.
Please acknowledge a safe receipt of this email.
Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiffs
Manish Singh | Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi 110003, India|Tel:+91-11-40244360 (100Lines) |Handphone: +91about:blank

3/4

<!-- page 39 -->

5/27/26, 11:20 AM

URGENT | DOT & MEITY | Twenty-First Additional List- Compliance for the Order dated 08.12.2025 passed by the Hon'ble Hi…

9927402957 | Enrolment Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment &
Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files
constitutes confidential information of S&A and may also be the subject of
legal professional privilege, not being waived or lost by mistaken
transmission or receipt. If you have received this mail in error,
please notify us at info@saikrishnaassociates.com immediately by reply
email and destroy the original - any use, disclosure or copying of this
mail is unauthorised

2 Attachment(s)

about:blank

List 21.xlsx

Order dated 08.12.2025.pdf

13.3 KB

85.9 KB

4/4

<!-- page 40 -->

List 21
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40

URL/Domain/IP
swiss8k.xyz
candycloudstrong8k.xyz
omegamg8k.xyz
8kplayer4k12.com
uptv-access.me
uptv-network.me
uptiserv.xyz
domainkaufen.online
celsofrance.online
akshxlensbsnwlfx.de
zurich-suiza.org
businesscloud8k.online
germanygermanygermany.de
germany-tvflash.site
germantv.store
vinetex.de
iamobile.de
hesat-r.de
businesscloud8k.business
jz34-gamhub.xyz
starke8zuschauer.de
candycloud-8k.men
8gaminghub.xyz
starke8free4.de
business-8k.xyz
germantvhub.xyz
x1private8k.store
graufuchs.cc
colour-one.de
x1private.store
sspremium.de
way-gaminghub.xyz
8k-omegamg.xyz
shadowcs8k.de
xstore.fit
candy-cloud-8k.xyz
candy8kcloud2.xyz
cf-business-cloud.site
prokaufen.online
nicebusiness-cloud-8k.com

Registrar
Namecheap
Spaceship, Inc.
Spaceship, Inc.
PDR Ltd. d/b/a PublicDomainRegistry.com
OVH SAS
OVH SAS
OVH
NameCheap, Inc.
NameCheap, Inc.
InterNetX GmbH
HOSTINGER operations, UAB
HOSTINGER operations, UAB
netcup GmbH
NameCheap, Inc.
HOSTINGER operations, UAB
InterNetX GmbH
InterNetX GmbH
netcup GmbH
HOSTINGER operations, UAB
Namecheap
InterNetX GmbH
Spaceship, Inc.
Namecheap
Key-Systems GmbH
Spaceship, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Key-Systems GmbH
NameCheap, Inc.
NameCheap Inc.
Namecheap
Spaceship, Inc.
NameCheap Inc.
NameCheap, Inc.
Spaceship, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.

<!-- page 41 -->

41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69

candy8k4.online
zurich-suiza.xyz
lot66gamhub.xyz
8kgaminghub1.shop
bbt-streamer.de
x1private8k.online
gamhubsupe.xyz
bbt-stream.de
germantv.online
tvgermany275.site
zurich-suiza.com
xstreamportal.com
germantv4.online
strongghub.xyz
amarschalder.de
uptv-strgonline.xyz
uptv-strgplus.xyz
rumpelst.de
4k-dani.ch
strong8k-ger.xyz
ybptv.de
uptv-strgplus.me
swissiptvs.vip
iptv7.de
sbox2.be
woistderhund.xyz
ultieins.online
nexustv.rest
xstore.vip

NameCheap, Inc.
HOSTINGER operations, UAB
Namecheap
Namecheap, Inc.
Hetzner Online GmbH
NameCheap, Inc.
Namecheap
Hetzner Online GmbH
NameCheap, Inc.
NameCheap, Inc.
HOSTINGER operations, UAB
NameCheap, Inc.
NameCheap, Inc.
Namecheap
Hetzner Online GmbH
OVH
OVH
Neue Medien Münnich GmbH
Ascio Technologies Inc. Danmark
Namecheap
1blu GmbH
OVH SAS
NameCheap, Inc.
NameCheap Inc.
OVH
Namecheap
NameCheap, Inc.
NAMECHEAP
NameCheap, Inc.

S.No.
1
2
3
4
5
6
7
8
9
10
11

URL/Domain/IP
mail.pro2-ott.com
premiumorg5.com
premiumorg4.com
ftp.iptv-premium-ott.com
pro.premium-tv.name
ipro.premium-org.com
bestiptv2.premium-tv.org
premium-tv-france.com
premiumorg9.com
tv.premium-org.net
ipro.ipremium-ott.com

Registrar
PDR Ltd. d/b/a PublicDomainRegistry.com
Name SRS AB
NameCheap, Inc.
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
Name SRS AB
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com

<!-- page 42 -->

12
13
14

premiumorg7.xyz
soul.iptvpro2.com
monde.ottpro2.com

Namecheap
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com

S.No.
1
2
3
4
5
6

URL/Domain/IP
fdkdfn.com
fssfe.com
fsaaw.com
uykebeux.ghlts.com
megaottpremium.fit
5638384.magtv.in

7
8
9
10

megaottcandycloud.men
omegamgteams.fyi
megottcandycloud.xyz
54k-vapi-west.ott-flex.de

Registrar
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Endurance International Group India Private
Limited
Spaceship, Inc.
Spaceship, Inc.
Spaceship, Inc.
Greenmark IT GmbH

S.No.
1
2
3
4
5
6

URL/Domain/IP
line.dy1161.xyz
francepremiumtv.xyz
670179413646.cdn-plus.com
277037151849.cdn-4tr.com
870021055168.cdn-royal.com
121245236361.dns-e4k-26.sbs

Registrar
Dynadot LLC
Namecheap
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
PDR Ltd. d/b/a PublicDomainRegistry.com
Dynadot LLC

S.No.
1

URL/Domain/IP
atlaspro.in

Registrar

2
3
4
5
6
7

protv.top
tvprotv.in
prolivepp.net
apsmarter.net
azz19.net
ndasat.net

Tucows Domains Inc.
Tucows.com Co
Tucows Domains Inc.
Tucows Domains Inc.
Tucows Domains Inc.
Tucows Domains Inc.
Tucows Domains Inc.

S.No.
1
2
3
4
5
6

URL/Domain/IP
candypromax.fit
candypromax.ink
candypromax.fyi
candycloudprommax4k.fyi
app.due-ew.top
line.smart-ultra.cc

Registrar
NameCheap, Inc.
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.
NameSilo,LLC
NameCheap, Inc.

<!-- page 43 -->

7

opg.bshgcj.top

NameSilo,LLC

S.No.
1
2
3

URL/Domain/IP
proxpanel.app
proxpanel.live
millcitymax.xyz

Registrar
Tucows Domains Inc
Tucows Domains Inc.
Namecheap

S.No.
1
2
3

URL/Domain/IP
swiss-hd.online
al.efetv.de
powerip.be

Registrar
NameCheap, Inc.
Key-Systems GmbH
Hostnet bv

S.No.
1
2
3

URL/Domain/IP
line.liondnscloud.ru
francetvlink.xyz
candycloudlion.xyz

Registrar
RU-CENTER-RU
Dynadot LLC
Spaceship, Inc.

S.No.
1
2
3

URL/Domain/IP
proiptv.business
clientportal-proiptv.club
proiptv.link

Registrar
Gandi SAS
PDR Ltd. d/b/a PublicDomainRegistry.com
NAMECHEAP

<!-- page 44 -->

$~44
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 1306/2025 & I.As. 30663-67/2025
DAZN LIMITED & ANR.
Through:

.....Plaintiffs
Mr. Siddharth Chopra, Mr. Yatinder
Garg, Mr. Ishi Singh and Mr.
Priyansh Kohli, Advocates

versus
ABBONAMENTOIPTVITALIA.COM & ORS.
Through: Mr. Abhi Udai
Advocate for D-21

.....Defendants
Singh Gautam,

CORAM:
HON'BLE MS. JUSTICE MANMEET PRITAM SINGH ARORA
ORDER
%
08.12.2025
I.A. 30667/2025 (seeking exemption from filing court fee)
1.

This is an application filed under Section 149 of the Code of Civil

Procedure, 1908 (‘CPC’) seeking exemption from filing court fee at present.
2.

The application is allowed subject to the court fee being deposited

within one (1) week, failing which the consequences of Order VII Rule
11(b) CPC shall follow and the plaint shall stands rejected.
3.

The application stands disposed of.

I.A. 30666/2025 (seeking exemption from pre-institution mediation)
4.

This is an application filed under Section 12A of the Commercial

Courts Act, 2015 read with Section 151 CPC seeking exemption from
instituting pre-litigation mediation.
5.

Having regard to the fact that the present suit contemplates urgent

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 1 of 18

<!-- page 45 -->

interim relief and in light of the judgement of the Supreme Court in Yamini
Manohar v. T.K.D. Keerthi1, exemption from the requirement of preinstitution mediation is granted to the plaintiffs.
6.

Accordingly, the application stands disposed of.

I.A. 30665/2025 (Under Order XI Rule 1(4) CPC)
7.

This is an application seeking leave to file additional documents under

Order XI Rule 1(4) of CPC [as amended by the Commercial Courts,
Commercial Division and Commercial Appellate Division of High Courts
Act, 2015 (‘Commercial Courts Act’)] read with Section 151 CPC, within
thirty (30) days.
8.

The Plaintiff, if it wishes to file additional documents, will file the

same within thirty (30) days from today, and it shall do so strictly as per the
provisions of the Commercial Courts Act and the Delhi High Court
(Original Side) Rules, 2018 (‘DHC Rules’).
9.

For the reasons stated in the application, the same is allowed.

10.

Accordingly, the application is disposed of.

I.A. 30664/2025 (seeking exemption from issuing statutory notice)
11.

This is an application filed under Section 80 read with Section 151 of

CPC seeking exemption from issuing notice.
12.

Issue notice to defendant nos. 28, 31, 36 and 37 through all modes.

13.

Keeping in view the fact that Defendant Nos. 28, 31, 36 and 37 are

proforma Defendants, the exemption as sought is hereby granted.
14.

The application stand disposed of.

CS(COMM) 1306/2025
15.
1

Let the plaint be registered as a suit.

(2024) 5 SCC 815

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 2 of 18

<!-- page 46 -->

16.

Summons be issued to defendant nos. 1 to 9, which are identified as

the infringing defendants by e-mode on filing of process fee. Affidavit of
service be filed within two (2) weeks.
17.

The summons shall indicate that the written statement(s) must be filed

within thirty (30) days from the date of receipt of the summons. The
defendants shall also file affidavit(s) of admission/denial of the documents
filed by the plaintiffs, failing which the written statement(s) shall not be
taken on record.
18.

The plaintiffs are at liberty to file replication(s) thereto within thirty

(30) days after filing of the written statement(s). The replication(s) shall be
accompanied by affidavit(s) of admission/denial in respect of the documents
filed by defendants, failing which the replication(s) shall not be taken on
record.
19.

It is made clear that any unjustified denial of documents may lead to

an order of costs against the concerned party.
20.

Any party seeking inspection of documents may do so in accordance

with the Delhi High Court (Original Side) Rules, 2018.
21.

After Plaintiffs have received Basic Subscriber Information [‘BSI’]

details from the proforma Defendants with respect to Defendant Nos. 1 to 9,
it shall file an amended memo of parties within two (2) weeks from the
receipt of the information and thereafter fresh summons will be issued to the
said entities by the Joint Registrar.
22.

Defendant Nos. 10 to 37 have been impleaded as ‘proforma

Defendants’ in the suit for ensuring compliance of the Court’s directions.
Since they are proforma Defendants, no summons is being issued to the said
Defendants. The said Defendants, therefore, do not have to file written

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 3 of 18

<!-- page 47 -->

statements. Directions for compliance have been issued qua said proforma
Defendants in I.A. 30663/2025.
23.

Defendant No. 38 is an unknown entity-John Doe, as Plaintiff has

sought relief against the unknown entities.
24.

List before the learned Joint Registrar (J) on 19.01.2026.

25.

List before Court on 20.05.2026.

I.A. 30663/2025 (Under Order XXXIX Rule 1 and 2 CPC)
26.

The Plaintiffs have filed the present Suit seeking a permanent

injunction to restrain infringement of their broadcast reproduction rights by
Defendant Nos. 1 to 9 and other unknown parties.
27.

The learned Counsel for the Plaintiffs sets up the plaintiff’s case as

follows:
27.1. The Plaintiff No. 1, DAZN Limited, is a global sports streaming and
entertainment platform that offers live and on-demand/over-the-top (OTT)
sports broadcasting in over 200 countries. The Plaintiff No. 1 is also an
exclusive right owner for several works broadcast on its platform.
27.2. Plaintiff No. 2, DAZN Software Private Limited is the Indian
subsidiary of Plaintiff No.1, overseeing operations in India as well as
technological developments.
27.3. Plaintiff

No.

1

owns

and

platform/website https://dazngroup.com

operates

the

online

streaming

and https://www.dazn.com/en-

IN/home (“DAZN”) and mobile application which enables its viewers to
watch sporting content including live streaming of sporting events etc.
27.4. It is stated that the subject matter of the present suit pertains to the
matches of the ongoing event i.e., Serie A Championship, which was
commenced on 23.08.2025 and is scheduled to conclude 24.05.2026. The

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 4 of 18

<!-- page 48 -->

said event is the 124th season of top-tier Italian football, the 94th in a roundrobin tournament, and the 16th since its organization under an own league
committee.
27.5. The Plaintiffs have acquired exclusive global media rights,
comprising television rights to be exercised via broadcast delivery systems,
digital rights to be exercised via digital delivery systems, including internet
and mobile technology, and certain ancillary rights (“Exclusive Rights”) in
respect of the ongoing event ‘Serie A Championship’ (“Event”). In exercise
of the exclusive rights in the Event granted by one Lega Calcio Serie A
(“LCA”) which is the owner of the Exclusive Rights, the Plaintiffs have
acquired the Exclusive Rights to be exercised via Plaintiff No. 2 in India.
Overview of the Defendants:

27.6. Defendant nos. 1 to 9 are the IPTV Service Providers operating
through their respective websites and associated domains.
27.7. Defendant Nos. 10 to 19 are Domain Name Registrars (“DNRs”)
arrayed for the purpose of blocking access to domains used by the
Defendant Nos. 1 to 9 and to disclose information such as Name, Address,
Email address, Mobile Number, payment details, etc. (‘BSI’) related to the
Registrants of Defendant Nos. 1 to 9.
27.8. Defendant no 20/ WhatsApp and 21/Telegram FZ-LLC are impleaded
to seek direction to block/delete the groups or accounts made on their
platforms, which are used by the infringing Defendants to communicate with
the users for registering them.
27.9. Defendant Nos. 22 - 26 are payment processors utilized by Defendant
Nos. 1-9 and their associated domains.
27.10.Defendant nos. 27 to 35 are Internet Service Providers (“ISPs”),

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 5 of 18

<!-- page 49 -->

engaged in the business of providing internet and telecommunication
services to the public in India and are the gateways which enable access of
such rogue Defendant Nos. 1-9 and their associated domains through
internet into India.
27.11.Defendant No. 36/Department of Telecommunications (‘DoT’) and
Defendant No. 37/Ministry of Electronics and Information Technology
(‘MeitY’), are impleaded to assist in enforcing/ensuring compliance with
any orders of Court.
27.12.Defendant no. 38 is an unknown identity that has been impleaded as
John Doe.
Overview of Infringement

27.13.The Defendant Nos. 1 to 9 under their IPTV services are
communicating, hosting, streaming, and making available to the public live
sporting events without authorisation from lawful rights holders (“Impugned
Services”) using IPTV Players without any authorisation. The Defendant
Nos. 1–9 offer their IPTV services through their respective websites. To
access the infringing content via the IPTV Player, Defendant Nos. 1–9
provide their customers with (a) a username, (b) a password, and (c) a URL
on the medium of WhatsApp and Telegram upon payment of substantial
subscription fees through payment channels of Defendant Nos. 22 to 26. The
option to communicate through WhatsApp and Telegram are available on
the respective websites. A screenshot of the WhatsApp exchange between
the investigator and Defendant Nos. 1 to 9, wherein subscription details
were requested, is annexed as Document 11 filed along with the plaint.

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 6 of 18

<!-- page 50 -->

27.14.The offering of Impugned Services of the infringing defendants is not
geo-restricted and freely accessible to users across India, including in Delhi
as evidenced from the affidavit of the investigator2.
27.15.The Plaintiffs, as rightsholders and exclusive licensees of the ‘original
works’ as well as ‘broadcasts’, enjoy protection under Section 37 of the
Copyright Act, 1957 (“Act”). Therefore, the making available and/or
communication to the public of the content in which the Plaintiffs have the
Exclusive Rights, without the Plaintiffs’ authorisation by the Defendant Nos.
1 – 9 or any other unknown websites/ domains/ UIs/ URLs would amount to
a

violation

of

the

Plaintiffs’

exclusive

rights.

The

alleged

reproduction/communication is contemporaneous and has a potential to
erode the Plaintiffs’ market, a considerable compensation for which has been
paid by the Plaintiffs.
27.16.The Plaintiffs have also issued email notices to Defendants No. 1 to 9
informing them of the infringing domains hosted or facilitated through their
services and requesting that they investigate the matter and take appropriate
action. Despite these clear and specific notifications, no remedial action has
been taken to date thereby showing that these are rogue defendants on the
principles identified by the Court in UTV Software Communication v
1337x.To3.
27.17.It is further submitted that during the live transmission of major
sporting events, including the aforesaid event, the Plaintiffs have observed
that the infringing Defendants frequently re-emerge by creating multiple
associated domains and mirror websites mere minutes before the
2
3

Annexed as Document no.9 along with the plaint.
2019 SCC OnLine Del 8002

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 7 of 18

<!-- page 51 -->

commencement of the match. Moreover, each time an infringing website,
URL, or domain is blocked, new websites and associated domains are
promptly generated to continue the unlawful activity. In view of these
peculiar circumstances and the Defendants’ persistent evasive conduct, the
grant of a Dynamic Injunction to safeguard the Plaintiffs exclusive rights is
warranted.
27.18.Learned counsel for the Plaintiff has also placed reliance on the
judgment passed in its favour by the Coordinate Bench of this Court in
CS(COMM) 1152/2025 dated 06.11.2025, suit titled as DAZN Limited &
Anr. vs 9GOALS.IO & Ors., granted in favour of the Plaintiff for the same
Event with respect to rogue websites.
Court’s Findings:

28.

The Court has heard the learned counsel for the plaintiff and has

perused the case.
29.

Learned counsel for the Plaintiff states that an advance service has

been affected on the defendants. However, none appears for the defendants
except Defendant No. 21.
30.

After considering the submissions of learned counsel for the

Plaintiffs, as well as the pleadings and documents on record, the Court is
satisfied that the Plaintiffs have made out a prima facie case for an ex parte
ad-interim injunction.
31.

The Plaintiffs have acquired exclusive rights for multiple events,

including the Event mentioned in the Rights Confirmation Letter dated
10.10.2025, through substantial financial investment.
32.

The Defendant Nos. 1 to 9’s failure to reply to the Plaintiffs’ email

notices and their non-appearance despite due service of the suit paper book

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 8 of 18

<!-- page 52 -->

further militates against them and reflects a lack of due diligence and good
faith.
33.

The apprehension of the unauthorised dissemination, telecasting, or

broadcasting of the Event by IPTV Service Providers is substantiated by the
report of the investigator placed on record. This Courts finds merit in the
submissions of the plaintiff that any delay in blocking access to Defendant
Nos. 1 - 9 or any other IPTV Service Providers/ websites/ domains
providing the Impugned Services, could lead to financial losses for the
Plaintiffs, and an irreparable breach of the Exclusive Rights.
34.

In respect of the prayer of the Plaintiff for a dynamic injunction

during the subsistence of the series/Event, this Court notes that the Courts
have recognised that due to the dynamic and continuously evolving nature of
the digital ecosystem, legal remedies must remain sufficiently robust and
effective to curb copyright infringement, particularly in the fast-paced and
ever-changing environment of the internet. The Court, in Universal City
Studios (supra), has elaborated on this principle, the relevant paragraph of
which is reproduced below:
“17. Any injunction granted by a Court of law ought to be effective in
nature. The injunction ought to also not merely extend to content which
is past content created prior to the filing of the suit but also to content
which may be generated on a day-to-day basis by the Plaintiffs. In a
usual case for copyright infringement, the Court firstly identifies the
work, determines the Copyright of the Plaintiff in the said work, and
thereafter grants an injunction. However, owing to the nature of the
illegalities that rogue websites indulge in, there is a need to pass
injunctions which are also dynamic qua the Plaintiffs as well, as it is
seen that upon any film or series being released, they may be
immediately uploaded on the rogue websites, causing severe and instant
monetary loss. Copyright in future works comes into existence
immediately upon the work being created, and Plaintiffs may not be
able to approach the Court for each and every film or series that is
produced in the future, to secure an injunction against piracy.

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 9 of 18

<!-- page 53 -->

19. As innovation in technology continues, remedies to be granted also
ought to be calibrated by Courts. This is not to say that in every case, an
injunction qua future works can be granted. Such grant of an injunction
would depend on the fact situation that arises and is placed before the
Court.
20. In the facts and circumstances as set out above, an ex parte ad
interim injunction is granted restraining the Defendants, who are all
rogue websites, from in any manner streaming, reproducing,
distributing, making available to the public and/or communicating to
the public any copyrighted content of the Plaintiffs including future
works of the Plaintiffs, in which ownership of copyright is undisputed,
through their websites identified in the suit or any mirror/redirect
websites or alphanumeric variations thereof including those websites
which are associated with the Defendants’ websites either based on the
name, branding, identity or even source of content. To keep pace with
the dynamic nature of the infringement that is undertaken by hydraheaded websites, this Court has deemed it appropriate to issue this
‘Dynamic+ injunction’ to protect copyrighted works as soon as they are
created, to ensure that no irreparable loss is caused to the authors and
owners of copyrighted works, as there is an imminent possibility of
works being uploaded on rogue websites or their newer versions
immediately upon the films/shows/series etc. The Plaintiffs are
permitted to implead any mirror/redirect/alpha numberic variations of
the websites identified in the suit as Defendants Nos.1 to 16 including
those websites which are associated with the Defendants Nos.1 to 16,
either based on the name, branding, identity or even source of content,
by filing an application for impleadment under Order I Rule 10 CPC in
the event such websites merely provide new means of accessing the
same primary infringing websites that have been injuncted. The
Plaintiffs are at liberty to also file an appropriate application seeking
protection qua their copyrighted works, including future works, if the
need so arises. Upon filing such applications before the Registrar along
with an affidavit with sufficient supporting evidence seeking extension
of the injunction to such websites, to protect the content of the
Plaintiffs, including future works, the injunction shall become
operational against the said websites and qua such works. If there is any
work in respect of which there is any dispute as to ownership of
copyright, an application may be moved by the affected party before the
Court, to seek clarification.”

(Emphasis Supplied)

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 10 of 18

<!-- page 54 -->

35.

In view of the findings recorded above, grounds for immediate

injunctive relief as well as dynamic injunction is made out in this case,
considering the live broadcast of the Event.
36.

Accordingly, till the next date of hearing the following directions are

issued:
I.

Defendant Nos. 1- 9, their owners, partners, proprietors, officers, and
all others in capacity of principal or agent acting for and on their
behalf, or anyone claiming through, by or under them are restrained
from in any manner hosting, streaming, broadcasting,

making

available for viewing/downloading, communicating, and / or sharing
without authorization, any part of the Event i.e., ‘Serie A
Championship’ in any manner whatsoever so as to infringe the
Plaintiffs’ Exclusive Rights.
II.

Defendant Nos. 10 to 19/DNRs are directed to lock and suspend the
domain name registrations of the Defendant Nos. 1 to 9 and their
associated domain as mentioned at ANNEXURE-A attached along
with this order and to disclose the complete details such as name,
address, email, phone number, IP address, Mode of payment along
with payment details used for registration of domain name by the
registrant(s).

III.

Defendant No. 20/WhatsApp LLC is directed to suspend the
WhatsApp accounts of the numbers mentioned in ANNEXURE-B
attached along with this order and to provide the BSI report of the
said WhatsApp accounts.

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 11 of 18

<!-- page 55 -->

IV.

Defendant No. 21/Telegram FZ-LLC is directed to suspend the
Telegram account – ‘@migliore_tv (+39 351 073 9501)’ and to
provide the BSI details of the said Telegram account.

V.

Defendant Nos. 22 – 26 their directors, partners, officers, affiliates,
and all others in capacity of principal or agent acting for and, on their
behalf, or anyone claiming through, by or under are directed to block
the account of the recipient mentioned at ANNEXURE-C attached
along with this Order.

VI.

Likewise, Defendant Nos. 27 – 35 (ISPs) are directed to block the
infringing websites of the Defendant Nos. 1 to 9.

VII.

Defendant Nos. 36 (DoT) and 37 (MeitY) are directed to issue a
notification calling upon the various ISPs registered under it to block
access to the infringing websites of Defendant Nos. 1 to 9.

VIII.

Proforma Defendants will comply with the aforesaid directions within
48 hours from receipt of this order.

37.

During the Event, which is scheduled to last until 24.05.2026 if any

further additional websites/domains/URLs, are discovered by the Plaintiffs,
which are unauthorisedly streaming and communicating content of the live
event which is the subject matter of this suit, the Plaintiff is granted liberty
to communicate the details of such websites/URLs to the proforma
Defendants i.e., DNRs, ISPs and DoT as well as MeitY for locking and
suspending the said websites/URLs on real time basis without undue delay.
Upon receiving the said intimation from the Plaintiffs, Defendant Nos.
27 – 35 (ISPs) shall take steps to immediately block the said websites/URLs.
Defendant No. 36 (DoT) and Defendant No. 37 (MeitY) shall also issue
necessary blocking orders to the ISPs/DNRs for blocking the said websites.

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 12 of 18

<!-- page 56 -->

The proforma defendants will take step in a timely manner to ensure that
these websites can be blocked on a real time basis and there is no undue
delay.
38.

For directions issued hereinabove, the Plaintiffs shall file affidavits

providing the details of the newly discovered websites/domain names/URLs,
DNRs which are communicated and locked/blocked to ensure that the Court
is fully informed of the websites in respect of which blocking orders are
sought.
39.

If any website, which is not primarily an infringing website, is

blocked in pursuance of this Order, it is permitted to approach the Court by
giving an undertaking that it does not intend to do any illegal dissemination
of the content over which the Plaintiffs have Exclusive Rights and the Court
would consider modifying the injunction if the facts and circumstances, so
warrant.
40.

The provisions of Order XXXIX Rule 3 CPC shall be complied

within one (1) week from today and an affidavit shall be filed within one (1)
week
41.

Issue notice.

42.

Upon steps being taken by the Plaintiff issue notice to Defendant Nos.

1-37 through all modes. Affidavit of service be filed withing two [2] weeks.
43.

Learned counsel for defendant no. 21 has entered an appearance on

advance service and accepts notice. He states that defendant no. 21 will
abide by the directions issued by the Court.
44.

Defendant nos. 10 to 37 are directed are directed to file their

compliance affidavit within four (4) weeks and provide BSI details as
directed above.

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 13 of 18

<!-- page 57 -->

45.

Let the reply to this application be filed by Defendant Nos. 1 to 9,

within a period of four (4) weeks.
46.

Rejoinder thereto, if any, be filed within a period of two (2) weeks

thereafter.
47.

List before the learned Joint Registrar (J) on 19.01.2026.

48.

List before Court on 20.05.2026.

49.

The digitally signed copy of this order, duly uploaded on the official

website of the Delhi High Court, www.delhihighcourt.nic.in, shall be treated
as a certified copy of the order for the purpose of ensuring compliance. No
physical copy of order shall be insisted by any authority/entity or litigant.

MANMEET PRITAM SINGH ARORA, J
DECEMBER 8, 2025/rhc/AJ

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 14 of 18

<!-- page 58 -->

ANNEXURE- A
A.
1.
2.
3.
B.
4.
5.
6.

Hostinger Operations UAB (Defendant No.10)
abbonamentoiptvitalia.com (Defendant No.1)
xtremehd.io (Defendant No.5)
iptv-italia-extreme.com (Defendant No.7)
NameCheap Inc. (Defendant No.11)
cf.business-cdn.me (Associated Domain of 1)
cf.hi-ott.me (Associated Domain of 2)
o4x5a3l4f4t2y424z2i4.fw1.frontcloud.pro
(Associated Domain of 3)
7.
o4x5a3l4f4t2y424z2i4.spn3.frontcloud.me
(Associated Domain of 3)
8.
dino-4k.online (Associated Domain of 7)
9.
cf.business-cdn.me (Associated Domain of 8)
10. v4k.top (Associated Domain of 9)
11. cf.hi-ott.me (Associated Domain of 2)
C.
Porkbun LLC (Defendant No.12)
12. best4kliveiptv.com (Defendant No.2)
D.
13.
E.
14.
15.
F.
16.
G.
17.
18.
19.
H.
20.
I.

Ultahost, Inc.(Defendant No.13)
migliore-tv.sbs (Defendant No.3)
OVH (Defendant No.14)
serverplay.shop (Defendant No.4)
online.serverplay.vip (Associated Domain of 9)
Cloudflare, Inc.(Defendant No.15)
live4.playsapp.org (Associated Domain of 4)
Cloud DNS Ltd (Defendant No.16)
fls-c84p.dnsabr.com (Associated Domain of 3)
90276-apnic.new-tx.com (Associated Domain of 5)
97004-myers.new-tx.com (Associated Domain of 6)
Realtime Register B.V. (Defendant No.17)
extremeiptv.it (Defendant No.6)
PDR Ltd. d/b/a PublicDomainRegistry.com
(Defendant No.18)

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 15 of 18

<!-- page 59 -->

21. cnamenl3.cdnnet.xyz (Associated Domain of 7)
22. clien-01.clien-01.com (Associated Domain of 9)
23. it2.beesolo.pet (Associated Domain of 9)
J.
Hosting Concepts B.V. d/b/a Registrar.eu
(Defendant No.19)
24. tutto-iptv.com (Defendant No.8)

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 16 of 18

<!-- page 60 -->

ANNEXURE-B

S.No.
1.
2.
3.
4.
5.
6.
7.

Details of the WhatsApp accounts
+1 252-510-4361
+44 7491599584
+33 7 56 75 73 68
+44 7366820657
+44 7491284998
+33 7 56 75 69 29
+44 7878757088

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 17 of 18

<!-- page 61 -->

ANNEXURE-C
S.No.
1.

Payment Details
realonemd7@gmail.com
(44 7401495938)
(For Defendant No.1)

Payment Processor
PayPal Payments Private
Limited
(Defendant No.22)

2.

https://www.paypal.com/ncp/paymen
t/YJG2CTEJFMEKS
( For Defendant No.2)

PayPal Payments Private
Limited
(Defendant No.22)

3.

paypal.me/madu60
(For Defendant No.3)

4.

PayPal Payments Private
Limited
(Defendant No.22)
https://pay.sumup.com/b2c/X7XVZB SumUp
KYPC?checkout_id=1ad772de(Defendant No.25)
404d-452e-9848-113ef26eac03
(For Defendant No.4)

5.

https://digitalisation10.myshopify.co
m/cart/45080160501956:1
(For Defendant No.5)

6.

http://digitalisation10.myshopify.com Shopify Commerce India
/cart/45080160469188:1
(Defendant No.23)
(For Defendant No.6)

7.

https://whop.com/checkout/6PHKUR Whop
QCbBllZ30Icp-3c2Q-1FU4-W0N3(Defendant No.24)
hPkSP7Sa7i0d/
(For Defendant No.7)

8.

https://buy.stripe.com/eVqbJ282s1qu
23R4Ji4Ja0j
(For Defendant No.8)

Stripe
(Defendant No.26)

9.

paypal.me/AliBaaliouy/30

PayPal Payments Private
Limited
(Defendant No.22)

(For Defendant No.9)

Shopify Commerce India
(Defendant No.23)

CS(COMM) 1306/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/12/2025 at 22:52:32

Page 18 of 18

<!-- page 62 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
