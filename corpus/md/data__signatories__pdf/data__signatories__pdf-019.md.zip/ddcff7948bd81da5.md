---
doc_id: "ddcff7948bd81da5"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/0815ae82a507696fd17b7f24d1722e0c.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Framing of Recruitment Rules to the post of ECG Technician, RHTC hospital."
date: "2024-11-10"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1ab91b60f561e4b8"
---

<!-- page 1 -->

F.No.A. 120 | 8 I 07 I 2024 -l\ft[-Il (FTS : - 82 5 9 8 5 1 )

Government of India

Ministry of Health and Family Welfare
Department of Health and Family Welfare

Nirman Bhavan New Delhi- 1 1001 I
Dated 27th September, 2024

NOTICE
This Ministry is examining a proposal for framing of Recruitment Rules

for the posts of ECG Technician in RHTC Hospital, Najafgarh, Directorate
General of Health Services, Ministry of Health & Family Welfare. In this regard,

draft Recruitment Rules have been approved by the Competent Authority.

2.

Before taking up the proposal for framing the Recruitment Rules with

the DoP&T and other agencies for finalizing the Recruitment Rules, comments,

if any, are invited from all stakeholders in the matter within a period of thirty
days from the date of notification in the website of the Ministry of Health and

Family Welfare. The objections/suggestions received from the stakeholders

within the specified period shall be considered by the Ministry as per
rules/requirement.

3.

The comments may be fumished to the undersigned in Room No. 401-D,

D Wing, Nirman Bhawan, New Delhi-ll00ll and the soft copy may be sent to
anuradha.ramakri shan@ni c. in .

Linder:#ffi

<!-- page 2 -->

GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE
RURAL HEALTH TRAINTNG CENTRE
NAJAFGARH, NEW DELHI-I IOO43
Notification

G.S.R......- In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules regulating the method of recruitment to the post of ECG
Technician in the RHTC Hospital, Najafgarh New Delhi, namely:-

l. Short title and commencement. - (l) These rules may be called the Ministry of Health and Family
Welfare, RHTC Hospital, Najafgarh New Delhi, ECG Technician, (Group 'C' Post) Recruitment Rules,
2024.
(2) They shall come into force on the date of their publication in the Official Gazette.

2. Number of post, classification and level in pay matrix.

- The number of post, its classification and

level in the pay matrix attached thereto shall be as specified in columns (2) to (a) of the Schedule
annexed to these rules.

3. Method of recruitment, age limit, qualifications, etc.

The method of recruitment, age limit,

qualifications and other matters relating to the said post shall be as specified in columns (5) to (13) of the
said Schedule.
4. Disqualification. - No person, (a) who has entered into or contracted a marriage with a person having a spouse living; or
(b) who, having a spouse living, has entered into or contracted a marriage with any person,
shall be eligible for appointment to the said post:

Provided that the Central Government may, if satisfied that such marriage is permissible under
the personal law applicable to such person and the other pafty to the marriage and that there are other
grounds for so doing, exempt any person from the operation of this rule.
5. Power to relax. - Where the Central Government is of the opinion that it is necessary or expedient so

to do, it may, by order, and for reasons to be recorded in writing and in consultation with Union Public
Service Commission, relax any of the provisions of these rules with respect to any class or category of
persons.

6. Saving. - Nothing in these rules shall affect reservation, relaxation of age limit and other concessions
required to be provided for the Scheduled Castes, the Scheduled Tribes, the Other Backward Classes, the
Ex-servicemen and other special categories of person in accordance with the orders issued by the Central
Government from time to time in this regard.

<!-- page 3 -->

DRAFT SCHEDULE
Recruitment Rules for the post of ECC Technician
Name of post.

Number of post.

(3)

(2)

I

Level in pay matrix.
(4)

Classification.

General Central Service, Level-Sin the pay matrix (Rs.

ECG

01* (2024)

Technician.

to Group'C', Non-Cazetted, 29200-92300).
variation dependenl Non-Ministerial.

+(subject
cn workload).

Whetherselectio Age-limit
n post or nonselection post.

fordirect recruits.

(6)

(5)
Not applicable.

Between l8-27 Years.
(Relaxable for Covemment servants up to the age of forty years in the case of general
candidates and up to 45 years candidates belonging to the SC/ST in accordance with
the instructions or orders issued by the Central Govemment from time to time.
Note:

The crucial date for determining the age- limit shall be the closing date

for receipt of applications from candidates and not the closing date prescribed for
lhose in Assam, Meghalaya, Arunachal Pradesh, Mizoram, Manipur, Nagaland,
Tripur4Sikkim, Lahaul and Spiti District and Pangi Sub- Division of Chamba
District of Himachal Pradesh, UT of Ladakh, Andaman and Nicobar lslands and
Lakshadweep).
Educational and other qualifications required for direct Whether age and Period ofprobation, if any.
educational
recruits.
qualifications

prescribed for

direct recruits

will apply in the

case

of

Dromotees.

(7)
Essential Qualifications:

(e)

(8)
Not applicable.

Iwo

years

for

itment.
[a) Class 12th Pass in Science with Physics, Chemistry,

MathematicV biology from a recognised Board or
University; and

Note - There shall be a

(b) Degree in Electronics and Communication
Engineering from All India Council for Technical

mandatory induction training
of at least two weeks for
successful completion oI
probation as prescribed by the

Education recognized Un iv ers ityll n stitute.

competent authority.

<!-- page 4 -->

Diploma in Electronics and Communication
Engineering from All India Council for Technical
Education recognized University/ Institute;

ive years' experience of handling cardiac
uipment likel2 channel ECG, Cardiac monitor,
Defibrillator, TMP and Holter machine in a
inimum 100 beds recognised hospital in Medicine
Cardiology Department.

ote l: Qualifications are relaxable at the discretion
mpetent authority in case of candidates otherwi
qualified.
2: The qualifications regarding
s/are relaxable at the discretion of the
ty in the case of candidates belonging
Castes and Scheduled Tribes if at any
Selection the competent authority is of the opi
sufficient number of candidates from
ities possessing the requisite experience
likely to be available to fill up the v
for them.

\4ethod of

recruitment,
whether
by
direct
"ecruitment or
by
rromotion or by deputation
' absorption and percentage
rf the vacancies to be filled
ry various methods.

ln case of recruitment by promotion or by deputation/ absorption, grade
flrom which promotion or deputation/ absorption is to be made.

fl0)

01)

By deputation (including Deputation (lncluding short term conffacV absorption

:

;hort

;ontract)/absolption, failing Officers of the Central Government or State Government, Union
which by Direct Recruitment. territories, autonomous or statutory organization, PSUs, University or
Recognized Research lnstitutions :

(a) (i) holding analogous posts on regular basis in the parent cadre
Department;
cr

(ii) offrcials in Level -04 of pay Matrix (Rs.25500-81100/-) with five
years'regular service

<!-- page 5 -->

and

) possessing the education qualifications and experience prescribed
Recruitment under column (7) of Schedule.

ote l: The period of deputation including the period of deputation
ex-cadre post held immediately preceding this appointment in
or some other organization/department of the Central Govern
ordinarily not exceed three years.

ote 2: The maximum age-limit for appointment by deputation shall
exceeding fifty-six years as on the last date or receipt of application.
ote 3: The Central or State Government ofiicers shall only be conside

f a Departrnental Promotion Committee exists, what is its composition. lircumstances in which Unior
Public Services Commission is
:o be consulted in making
:ecruitment.

(12)
Departmental Confirmation Committee comprising of:

(13)

lonsultation with the Unior

Public Service Commission is
l. HospitaU Medical Superintendent Rural Health Training lot necessary.
Centre, Najafgarh, New Delhi-- Member;
2.Head of the Concerned Department, RHTC Hospital-Member;

3. Deputy Director looking after the work of the Hospital in
Directorate General of Health Services --Member.
