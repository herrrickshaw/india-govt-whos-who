---
doc_id: "dcca2e23d1ec8dc3"
source_url: "https://shipmin.gov.in/sites/default/files/Draft%20guidelines%20for%20Pillar%203%20%E2%80%93%20Component%204-%20credit%20Risk%20coverage%20for%20Shipbuilding%20Projects-_0.pdf"
ministry: "Ports, Shipping and Waterways (MoPSW)"
title: "Draft guidelines for Pillar 3 – Component 4- credit Risk coverage for Shipbuilding Projects-.pdf"
date: ""
pages: 43
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3d2bd3451b9bbbcf"
---

<!-- page 1 -->

File No. SY-19014/80/2024-SBR
Government of India
Ministry of Ports, Shipping and Waterways
(SBR Section)
3rd Floor, PTI building,
1 – Parliament Street,
New Delhi – 110001
Dated: November 4th, 2025
To,
1. CMD, Cochin Shipyard Limited (CSL)
2. CMD, Shipping Corporation of India (SCI)
3. CMD, Hindustan Shipyard Limited
4. CMD, Mazagon Dock Shipbuilder Limited
5. CMD, Goa Shipyard Limited
6. CMD, Garden Reach Shipbuilder and Engineers Limited (GRSE)
7. CMD, Swan Defence and Heavy Engineering
8. CMD, L&T Shipbuilding
9. CMD, Shoft Shipyard pvt. Ltd.
10. CMD, Chowgule and Company Pvt. Ltd.
11. CMD, Titagarh Wagon Limited
12. CMD, Chowgule Global
13. Head, ISTC
14. Directorate General of Shipping
15. Advisor, Shipyards Association of India (SAI)
16. CEO & MD, Indian Shipbuilders Association of India (ISBA)
17. CEO, Indian National Shipowenrs Association (INSA)
18. VC & CEO, Gujarat Maritime Board (GMB)
19. New India Assurance (NIA)
20. Export Credit Guarantee Corporation of India (ECGC)
21. Sagarmal Finance Corporation Limited (SMFCL)
22. Indian Register of Shipping (IRS)
23. Indian Maritime University (IMU)
24. Centre of Excellence in Maritime and Shipbuilding (CEMS)
25. Ship Recycling Industries Association (SRIA)
26. International Shipyards (HD KSOE, Hanwha Ocean, Imabari Shipyards, CMA
CGM, AP Mollar Maersk, MSC, Damen Shipyards, Royal HSC, DP World,
NYK Line Japan)
27. Container Shipping Lines Association (CSLA)

Subject: Draft Guidelines for P3 i.e., Shipbuilding Development Scheme (SbDS) for
Capacity & Capability development and credit risk coverage for shipbuilding in India.
Sir,
The undersigned is directed to say that Union Cabinet, in its meeting held on
24.09.2025, approved the Shipbuilding Development Scheme (SbDS) for Capacity
& Capability development and credit risk coverage for shipbuilding in India of this
Ministry to promote shipbuilding in India.

<!-- page 2 -->

2.

In this regard, it is stated the draft guidelines for the above
prepared
been
in consultation with various stakeholders. A copy of
attached for perusal. NIC team is requested to upload the draft
website/portal.

3.

It is requested that your opinion i comments on draft
Division in the attached proforma latest by l3th November, 2025
mail - js-shipping@gov.in, j s-ports@nic.in, dirl-psw@gov.in and

4.

DG Shipping is requested to upload the same on their

scheme have

draft guidelines is
on the Ministry's
may be sent to SBR
on the following
.ln.

seek inputs /

comments/ suggestions from public / stakeholders.

5.

Your Co-operation and early reply wilt be highly appreciated.
Yours faithfully,

(1*t
to the Govt. of India
Tel: 011-23311659

<!-- page 3 -->

Format for seeking comments on Guidelines for adopting
Shipping Development Scheme (SbDS) for Capacity and
Capability Development and Credit Risk Coverage for
Shipbuilding in India - reg.

Organization/Agency Name:
Address with Contact details:
Type of Agency (GoWPrivate/PSU/lndividual/other):
Para wise remarks on the draft:

sl.

Para No. ol Existing text in the draft Proposed

No.

the Draft

guidelines

Remarks

changes

Other Remarks (lf any):

E-mail this format to js-shipping@gov.in js-ports@nic.in, dirlpsw@nic.in and copy to usshipping2-psw@gov.in.

<!-- page 4 -->

Committee Report on Shipbuilding Credit
Risk Coverage Guidelines under
Shipbuilding Development Scheme (SBdS)

1

<!-- page 5 -->

INDEX
Sr. No.

Page Number

1

Background

3-6

2

Annexure-I : Minutes of Stakeholder
consultation meeting dated 15.10.2025
(Online)

7-8

3

Annexure-II : Minutes of meeting- core
committee with all other stakeholdersdated 17.10.2025 (Physical/Online at
GIFT city Ahmedabad)

9-15

4

Annexure-III: Minutes of meeting – core
committee meeting dated 25.10.2025
(Online)

16-18

5

Annexure-IV: Minutes of meeting- core
19-24
committee with all other stakeholdersdated 30.10.2025 (Physical/Online at DG
shipping office, Mumbai)

6

Annexure-V: Inputs from Stakeholders
on Capacity and Capability building
guidelines under SBdS

25-27

7

Annexure- VI: Constitution of Credit Risk
coverage Core Committee Order for
Drafting Guidelines Under SbDS

28-32

8

Annexure-VII: Draft Credit Risk coverage
Guidelines -

33-40

2

<!-- page 6 -->

Committee Report on Ship building Credit Risk coverage Guidelines under
Shipbuilding Development Scheme (SBdS)
Dated: 03-11-2025
1. Background
In pursuance of the Office Memorandum No. SY-13017/III/2025-SBR dated 9th
October 2025 issued by the Ministry of Ports, Shipping and Waterways (MoPSW), the
Directorate General of Shipping (DGS) was entrusted with the task of constituting
three committees for formulation of guidelines under the Shipbuilding Development
Scheme (SBDS) and the Shipbuilding Financial Assistance Scheme (SBFAS).
Accordingly, three committees were constituted:
1. Committee-I – For framing guidelines on the Shipbuilding Financial Assistance
Scheme (SBFAS).
2. Committee-II – For framing guidelines on Capacity and Capability Building of
Greenfield Shipbuilding Clusters and Brownfield Shipyard Expansion Projects.
3. Committee-III – For formulating Credit Risk Coverage Guidelines for
Shipbuilding Projects.
This report pertains to the work carried out by Committee-III, constituted to prepare
guidelines for Shipbuilding credit risk coverage under the 4 th component of the
Shipbuilding Development Scheme (SBDS).
2. Objective of the Committee
The Committee was established to:





Operationalize the ₹1,443 crore corpus allocated under SBDS for Credit Risk
Coverage.
Develop the institutional and governance framework for the nomination,
onboarding, and functioning of credit risk cover agencies.
Define fund disbursement, reporting, and monitoring structures.
Ensure alignment with the Cabinet-approved framework for the Shipbuilding
Development Scheme (Pillar 3).

The guidelines aim to provide Indian shipyards with insurance-based protection
against pre-shipment, post-shipment, and vendor-related risks, strengthening
sectoral resilience and investor confidence.

3

<!-- page 7 -->

3. Constitution of the Committee
As per MoPSW’s order, the Directorate General of Shipping (DGS) constituted
Committee-III with representation from:








MoPSW (Director–SBR)
Directorate General of Shipping (DGS)
ECGC Limited
New India Assurance (NIA)
Sagarmala Development Financial Corporation Ltd (SDFC)
Shipyards Association of India (SAI)
Shipbuilders and Industry Experts (SWAN Defence, L&T etc.)

Director (SBR), MoPSW served as the Member from the Ministry, and an officer from
DGS, Shri Ravi Kumar Moka, Ship Surveyor-cum-DDG (Tech), acted as the Member
Convener of the Committee.
4. Meetings Conducted with Stakeholders

Date

Venue

Type

Online Stakeholder
15.10.2025 Meeting with Core
committee

Participants

MoPSW, DGS, SAI, ISBA, CSL,
IRS, GMB, SCI, INSA, SRIA,
Industry representatives

Virtual

Gujarat Maritime
Physical/Hybrid
DGS, GMB, regional shipyards
Board Office, GIFT
17.10.2025 Stakeholder Meeting
(L&T, ABG, Chowgule, Mandovi),
City, Ahmedabad
with Core committee
cluster associations
(Hybrid)

25.10.2025

Core Committee
(Internal Review)

MoPSW (JS–SBR, Dir–SBR),
DGS, ECGC, NIA

Virtual

Physical/Hybrid
Directorate
30.10.2025 Stakeholder Meeting General of
with Core committee Shipping (Hybrid)

4

DGS, ECGC, NIA, Shipyard
representatives, APMB, SAI,
SWAN Defence, KPMG

<!-- page 8 -->

5. Summary of Deliberations
5.1 Scope and Framework
The committee agreed that the credit risk coverage guidelines form a key risk
mitigation pillar under the Shipbuilding Development Scheme (SBDS) and would:




Be applicable to all registered Indian shipyards.
Operate through nominated government-owned insurance agencies (ECGC
& NIA).
Focus on pre-shipment, post-shipment, and vendor default insurance
products tailored to shipbuilding contracts.

5.2 Institutional Framework





Nodal Body: National Shipbuilding Mission (NSbM) – Apex oversight body.
Implementing Agency: Directorate General of Shipping (DGS) or Sagarmala
Financial Corporation Ltd (SFCL) to handle fund disbursal.
Credit Risk Cover Agencies: ECGC Ltd (for export-linked covers) and New
India Assurance (NIA) (for domestic shipbuilding).
Corpus Allocation: ₹1,443 crore to be disbursed annually or in multiple
tranches based on utilization and fund requirement.

6. Key Deliberations
6.1.1 The detailed list of deliberated items and inputs from stakeholders on the
Shipbuilding credit risk coverage guidelines are attached as Annexure-II.
6.1.2 The Minutes of meetings for the three core committee meetings with Industry
stakeholders and one core-committee meeting along with List of participants is
attached as Annexure-I.

7. Items to be Finalized with NSbM
The following aspects require policy-level finalization by the National Shipbuilding
Mission (NSbM):
1. Confirmation of the Implementing Agency (DGS or SFCL).
2. Corpus replenishment mechanism and flexibility for mid-term fund
augmentation.
3. Decision on allowing private insurers or reinsurance partners in subsequent
phases.
4. Approval mechanism for product design and pricing (through IMGB).
5. Standard MoU templates defining fund access, performance benchmarks, and
reporting structure.

5

<!-- page 9 -->

6. Reinsurance and vendor default product design validation.
7. Actuarial study protocol and periodic review cycle.
8. Conclusion
The Committee on Shipbuilding Credit Risk Coverage completed its mandate by:




Conducting four comprehensive stakeholder consultations and one internal
meeting.
Consolidating and reviewing stakeholder inputs from ECGC, NIA, shipyards,
and industry bodies.
Finalizing the framework for credit risk coverage guidelines, incorporating
operational, financial, and institutional mechanisms.

The draft operational guidelines for the Shipbuilding Risk Coverage Scheme under
SBDS attached as Annexure-IV is accordingly submitted for Approval and onward
submission to the Ministry.
9. Annexures





Annexure I: Minutes of Meetings (dated 15.10.2025, 17.10.2025, 25.10.2025,
and 30.10.2025) along with List of participants.
Annexure-II : Consolidated Stakeholder Feedback/inputs Table on the
Shipbuilding Risk coverage Guidelines under SBdS.
Annexure III: Committee Constitution Orders (MoPSW O.M. dated
09.10.2025)
Annexure IV: Draft guidelines for Shipbuilding Risk coverage under SBdS.
Submitted by

(Ravi Kumar Moka)
Ship Surveyor-cum-Deputy Director General (Tech)
Member Convener – Committee on Shipbuilding Credit Risk Coverage
Directorate General of Shipping, Mumbai
To:
The Director General of Shipping
For onward submission to
Ministry of Ports, Shipping and Waterways (MoPSW)
Government of India

6

<!-- page 10 -->

Annexure- I

1st Online Stakeholder consultation Meeting
MOM of Core committee meeting with Stakeholders on Credit Risk
coverage
Date: 15th October 2025
Time: 11:45 hrs
Venue: Online Meeting
Convened by: DG Shipping, MoPSW

Participants:








Ravi Kumar SJ, DGS
K. Ramesh & Team (ECGC)
Sanjay Kumar & Team (NIA)
Abhinav Parpudi
Amit Dethe
Anuj Gupta
Other stakeholders

Key Discussion Points and Actions to be Taken
Corpus Utilization & Guidelines
Key Discussion Points:




Government approved outlay of ₹1,443 crore for credit risk cover under shipbuilding
scheme.
Corpus intended for payouts on defaults; operational costs to be recovered via nominal
premiums.
MoPSW to deﬁne process guidelines for fund release (annual/semi-annual/mid-year
contingency).

Leverage & Multiplier Factor
Key Discussion Points:



ECGC to propose leverage/multiplier factor based on risk proﬁle and actuarial
evaluation.
MoPSW will not impose leverage; decision left to ECGC.

Policy Structure
Key Discussion Points:

7

<!-- page 11 -->





Policies likely to be contract-speciﬁc, not blanket or annual.
Duration should align with shipbuilding timelines (2–6 years).
May require new product ﬁling with IRDA for multi-year coverage.

Premium & Viability
Key Discussion Points:



Premiums should be nominal but su icient to maintain insurance principles.
Premium revenue to cover operational costs and capacity building.

Technical Expertise & Training
Key Discussion Points:



Need for sector-speciﬁc expertise for loss assessment and product design.
MoPSW to facilitate training and technical support.

Operational Mechanism
Key Discussion Points:



Corpus parked with MoPSW; ECGC to request funds based on underwriting plans.
Provision for additional corpus mid-year if initial allocation exhausted.

Contractual Issues”
Key Discussion Points:



Ownership and salvage rights in case of buyer insolvency discussed.
Industry practice: buyer ownership only after ﬁnal payment; contract terms critical.

Risk & Insolvency Trends
Key Discussion Points:



Past insolvencies noted; data-driven approach recommended.
Shipyards generally conduct credit checks before signing contracts.

8

<!-- page 12 -->

Annexure- II

2nd Physical/Hybrid Stakeholder Consultation meeting
MOM of Core committee meeting with Stakeholders on Shipbuilding Credit
Risk coverage
Date: 17th October 2025
Time: 14:45 hrs to 15:20 hrs
Venue: Online Consultation
Convened by: Directorate General of Shipping (DG Shipping), Ministry of Ports, Shipping &
Waterways

Participants: (Full List of Participants is attached as Annexure-I).







Shri Vipul Singhal, Director, MoPSW
Shri Pradeep Sudhakaran, CSS, DGS
Shri Ravi Kumar, SS , DGS
Representatives from ECGC Ltd – Shri Suresh & Team
Representatives from NIA – Shri Bharat Bezawada & Ms. Swati Gupte
Shri Abhinav Parpudi, Consultant (MoPSW)

Meeting Objective
To ﬁnalize implementation guidelines for Credit Risk Cover under SBDS, focusing on
onboarding agencies, fund disbursement, reporting, and oversight. Product-speciﬁc details
to be addressed later.

Context and Opening Remarks
The meeting aimed to operationalize ₹14,143 crore allocation under SBDS for credit risk
coverage. Guidelines will deﬁne onboarding process, roles, fund transfer mechanism, and
monitoring framework. Product design will follow through stakeholder interactions.

Key Discussion Points and Actions to be Taken :
1. Scope of Guidelines
Key Discussion Points:
• Focus on onboarding credit risk cover agencies, deﬁning roles, fund transfer process, and
monitoring mechanism.
• Product-speciﬁc details (pre-shipment, post-shipment, vendor default) will be ﬁnalized
later.
Actions to be Taken:

9

<!-- page 13 -->

• NSM to ﬁnalize implementing agency and issue nomination letters.
• Agencies to submit proposals with timelines for product development and fund
management.
2. Agencies & Nomination Process
Key Discussion Points:
• ECGC Ltd and NIA conﬁrmed as initial agencies.
• Nomination letters to be issued by NSM after proposal evaluation.
• Communication routed through respective ministries, not directly to agencies.
Actions to be Taken:
• NSM to coordinate with ministries for o icial communication.
3. Implementing Agency & Fund Management
Key Discussion Points:
• Likely implementing agency: Sagarmala Development Financial Corporation (SDFC).
• Annual business plan required for year-on-year corpus allocation; mid-year
replenishment allowed if corpus exhausted.
Actions to be Taken:
• Implementing agency to prepare fund disbursement modalities.
4. Premium Structure & Nature of Insurance
Key Discussion Points:
• Premium to be nominal, covering operational and training costs; actuarial study will
determine actual rates.
• NSM approval required for each product; implementation agency to review premium
fairness.
• Insurance covers optional, not mandatory.
Actions to be Taken:
• Agencies to initiate actuarial studies and share ﬁndings with NSM.
5. Additional Points

10

<!-- page 14 -->

Key Discussion Points:
• Agencies must include fund management plan per IRDA norms.
• Corpus usage restricted to issuing covers and claim settlement only.
• NSM empowered to introduce new products without cabinet approval.
Actions to be Taken:
• Draft guidelines to incorporate premium study requirement and reporting obligations.

Decisions and Conﬁrmations
Proceed with implementation guidelines based on:
• Agency onboarding via NSM nomination.
• Corpus management with annual and mid-year allocations.
• Quarterly reporting with ﬂexibility for interim top-ups.
• NSM oversight for all approvals.

11

<!-- page 15 -->

ANNEXURE-II
LIST OF PARTICIPANTS FOR PHYSCIAL/HYBRID MEETING ON Capacity & Capability development
Guideliens under SbdS on 17-10-2025 @ GIFT City
Attended participants
113
Start time
10/17/25, 9:45:00 AM
End time
10/17/25, 3:56:49 PM
Meeting duration
6h 11m 48s
SNO

Name

1 Ravi Kumar(SS)
2 GES GSL
3 vijayendra Deshpande (Unverified)
4 HSL (Unverified)
5 Sabyasachi Majumder
6 SAN MARITIME INDIA PVT LTD (Unverified)
7 IMU Prof. Sivakholundu
8 CEO MMB
9 SCI- N K Tripathi (Unverified)
10 CAPT ARUN KUMAR
11 Anshul Wadia
12 Naveen Kumar (External)
13 GRSE (Unverified)
14 Hariprasad R (External)
15 Ankush Raj
16 Rohit Tagade (External)
17 San Marine Marine
18 R. V. Vimal (External)
19 Sanjeev (Unverified)
20 Gaurav Bhalerao (External)
21 CSL (Unverified)
22 Jobin Joseph (Synergy) (Unverified)
23 Sanjiv Kapoor (External)
24 Akshay S
25 Sanjeev Shoft Shipyard (Unverified)
26 prasanna kumar
27 Tanay Nagvekar
28 Sree Veeramanee N
29 Sushil Rajmane (External)
30 Akshay Jain | VEDAM (External)
31 Goa Shipyard Ltd (Unverified)
32 shipbuilding-apmb (External)
33 Dy CE (DPA) (Unverified)
34 Capt. Kapil Kekre (External)

Organization
DGS
GSL
SAI
HSL
INSA
San Marine
IMU
MMB
SCI
SAI
Wadia
IRS
ISBA
IRS-PMU
SEED-EY
IRS
SanMarine
SAI
SAI
SAI
CSL
Synergy
SWAN DEFENCE
SEED-EY
SHOFT
Wadia
Chowgule Lavgan Ship Repair Pvt Ltd
Chowgule Global Lavgan Shipyard
SAI
Vedam
GSL
APMB
DPA
INSA

12

<!-- page 16 -->

35 Nagesh Krishna Moorthy
36 Aneena R Innocent
37 CSL Nagesh (Unverified)
38 Anshuman Srivastava
39 Attreya Sawantt
40 Bosco D Silva
41 Shri Vipul Singhal
42 Dhrumil D Kelkar
43 Amit Waje (External)
44 SCI- N K Tripathi (Unverified)
45 Pranav R Pai
46 Mitesh Agarwal (External)
47 Ram K (Unverified)
48 Traffic Manager, NMPA (External)
49 pranati (Unverified)
50 Anuj Gupta
51 Prasad Sawant
52 GSL (Unverified)
53 Uday Bhatt.SRIA
54 pranati prabhu
55 BHARATH KRISHNAN
56 Naseer A
57 Sanjiv Walia
58 Rob (Unverified)
59 Manager ( Environment and Safety) (Unverified)
60 MMB (Unverified)
61 Chief-Manager (Env&Safety), DPA (Unverified)
62 Dharmesh Jani (Unverified)
63 Gopi Krishna Sivvam (External)
64 Prantik Bhatt
65 ASHA V RAO (Unverified)
66 Malika SeaTech (Unverified)
67 Dethe, Amit
68 Amal Aloshie Vithayathil (External)
69 PRADEEP
70 Janaki Ganesan
71 Anil Jain (Unverified)
72 Pravat Kusum Halder (External)
73 priyesh Kamat
74 Daniel (Unverified)
75 sanjeev (Unverified)
76 MAZAGON DOCK SHIPBUILDERS LTD (External)
77 Aaisha KS (External)
78 Ankur Anal

SAI
SEED-EY
CSL
SAI
Mandovi
MOC
MoPSW
INSA
IRS
SCI
SRIA
SRIA
TNMB
NMPA
SHOFT
KPMG-PMU
BuoyancyConsultants (External)
GSL
SRIA
SHOFT
L&T Kattupalli
SAI
SAI
MOC
KMB
MMB
DPA
SAI
SRIA
ISBA
CSL
SeaTech
KPMG
IRS
ISBA
SAi
SAI
Victoria shipyard
Synergy
SAI
ECGC
MDL
SAI
DGS

13

<!-- page 17 -->

79 san maritime (Unverified)
80 A C ROY (Unverified)
81 Tom Davis, CSL (Unverified)
82 Anuj Gupta (Unverified)
83 A S
84 Suken Shah
85 CMC (External)
86 Vishal Jain
87 dijo (Unverified)
88 Sajan John (Unverified)
89 IMU - Prof. Sivakholundu (Unverified)
90 Saurabh Pradip Gadkari (External)
91 anil jain (Unverified)
92 Harshita Raju
93 RAADS MARINE (Unverified)
94 Harshita Jaiswal
95 Pandurang Dhond
96 K.RAMESH (Unverified)
97 Parpudi, Abhinav
98 Mehul Diwan
99 SANJAY KUMAR ECGC NRO (Unverified)

San Marine
AC ROY shipbuilders
CSL
KPMG-PMU
SAI
SAI
CMC
SeaTech
CSL
CSL
IMU
SAI
Vedam
ISBA
SAI
ISBA
Chowgule
NIA
KPMG
SAI
ECGC

14

<!-- page 18 -->

15

<!-- page 19 -->

Annexure- III

3rd Hybrid Core committee meeting
MOM of Core committee meeting with Stakeholders on Shipbuilding Credit
Risk coverage
Date: 25 October 2025
Time: 1400 – 1500HRS
Chair: Shri Venkateshpathy, Joint Secretary(SBR), MoPSW
Participants:







Shri Vipul Singhal, Director, MoPSW
Shri Pradeep Sudhakaran, CSS, DGS
Shri Ravi Kumar, SS , DGS
Representatives from ECGC Ltd – Shri Suresh & Team
Representatives from NIA – Shri Bharat Bezawada & Ms. Swati Gupte
Shri Abhinav Parpudi, Consultant (MoPSW)

1. Background
The meeting was convened to operationalize the Credit Risk Insurance Component of the
Shipbuilding Development Scheme (SbDS) approved by the Cabinet by ECGC & NIA and
to:




Finalize the implementation framework for Pre-shipment, Post-shipment, and
Vendor Default Insurance covers;
Identify implementing agencies;
Establish timelines and actionable items for inclusion in the SbDS Operational
Guidelines.

2. Key Discussions
2.1. MoPSW Introductory Remarks (JS)






The Cabinet has approved ₹1,443 crore outlay for Credit Risk Coverage under SbDS
till FY 2036.
NSbM will issue detailed guidelines within 90 days of Cabinet approval (as per
Appendix I of the Cabinet Note).
MoPSW proposes to nominate ECGC Ltd and New India Assurance (NIA) as
implementing agencies for export and domestic shipbuilding risk covers
respectively.
Three key clarifications sought:
1. Whether ECGC/NIA can directly float products under the scheme or require
approvals from SEBI/IRDA/parent ministries.
2. Whether funds can flow directly from the Consolidated Fund of India (CFI)
or require a layer such as Sagarmala Financial Corporation Ltd (SMFCL).

16

<!-- page 20 -->

3. Tentative timelines for product formulation and presentation before the
Inter-Ministerial Governing Board (IMGB).
2.2. ECGC Response






Formal communication from MoPSW to ECGC (and its parent ministry, Department
of Commerce) is required to initiate product development.
The Vendor Default Insurance product falls outside ECGC’s current mandate and
needs IRDA and Department of Commerce clearance.
Once clearance is received, product rollout is possible within 3–4 months.
Actuarial studies will be conducted to determine risk leverage ratios and product
viability.
Noted need for possible replenishment of corpus over time, since one large claim
can deplete the ₹1,443 crore corpus.

2.3. NIA Response





NIA’s existing Trade Credit Insurance products cover up to six months’ credit
period, inadequate for shipbuilding’s 7–10-year project cycles.
Long-term credit exposure requires Surety Bond or Project Insurance products,
currently under development.
Reinsurance support from global partners will be necessary due to large risk
aggregation per project (₹200–300 crore average exposure).
Proposed actuarial assessment of coverage structure and corpus adequacy.

2.4. Discussion Points







Director (MoPSW) emphasized that products should be customized for shipyardspecific needs, not generic trade policies.
Premiums must be nominal, prioritizing sectoral development rather than
profitability.
Government will provide annual corpus infusion; insurance products must be
designed for self-sustenance and scalability.
NSbM will seek business plans from ECGC/NIA for annual risk coverage and
required corpus leveraging.
Provision to replenish corpus mid-term in case of extraordinary events (force
majeure, market collapse, etc.) will be included in guidelines.
ECGC/NIA to engage in detailed stakeholder consultations with shipyards before
finalizing products.

3. Framework for Guidelines (as agreed)
1. Implementing Agencies

17

<!-- page 21 -->

ECGC Ltd: Export-related risk covers (Pre-shipment, Post-shipment, Vendor
Default – export).
o New India Assurance (NIA): Domestic shipbuilding risk covers and Surety
Bonds.
2. Guiding Principles
o Premiums to be kept minimal considering Government corpus support.
o Annual corpus allocation based on leveraging ratio and business plan
submitted to NSbM/IMGB.
o Detailed actuarial justification to be part of each agency’s submission to
their regulatory authority and NSbM.
o Products to ensure financial sustainability with periodic actuarial review.
o

3. Fund Flow
o Option 1: Direct fund flow from Consolidated Fund of India to ECGC/NIA.
o Option 2: Layered mechanism through Sagarmala Financial Corporation
Ltd (SMFCL) (MoPSW to decide based on DoE advice).
o

4. Product Approval & Timelines
o MoPSW to issue formal communication to ECGC and NIA by 30 Oct 2025
authorizing product development.
o Both agencies to present draft products to IMGB/NSbM..
o IMGB approval is needed to enable the launch of the scheme.

5. Closing Remarks





JS emphasized that ECGC and NIA, being Government institutions, are to act as
pilot agencies under this scheme.
Both agencies will independently design and propose risk coverage products;
duplication is to be avoided.
NSbM Secretariat will coordinate all inter-agency communication.
Director (MoPSW) reiterated that the guidelines must remain simple, generic, and
flexible within the ambit of the Cabinet-approved DCN Pillar 3 document.

The meeting concluded with Vote of thanks to the chair.

18

<!-- page 22 -->

Annexure- IV

4th Physical/Hybrid Stakeholder Consultation meeting
MOM of Core committee meeting with Stakeholders on Shipbuilding
Risk coverage Guidelines)
Time: 17:00 -19:00
Venue: Hybrid (DG Shipping HQ and online)
List of Participants : (Full List of Participants is as per Annexure-II)
 DG Shipping (Pradeep Sudhakaran, Ravi Kumar Moka, Ankur Anal, PMU.
 Ministry of Ports/Shipping/Waterways (MoPSW), NSBM, national shipyard
 associations (SAI, INSA)
 Major shipyards (Aatreya, SDHI, L&T, Aatreya, San Marine, Chowgule, APMB,
 CSL, HSL, )
 Researchers, evaluation agency reps), IMU,
 State Maritime Boards (GMB, Andhra Pradesh)
 NIA/ECGC, finance experts
Key Discussion Points:
• Objective: Operationalize ₹1,443 crore allocation under SBDS for credit risk coverage.
• Guidelines focus on onboarding agencies, defining roles, fund transfer process, and
monitoring mechanism.
• Product-specific details (pre-shipment, post-shipment, vendor default) will follow later
through stakeholder interactions.
Actions to be Taken:
• NSM to finalize implementing agency and issue nomination letters.
• Agencies to submit proposals with timelines for product development and fund
management.
2. Agencies & Nomination Process
Key Discussion Points:
• ECGC Ltd and NIA confirmed as initial agencies.
• Nomination letters to be issued by NSM after proposal evaluation.
• Communication to route through respective ministries, not directly to agencies.

3. Implementing Agency & Fund Management

19

<!-- page 23 -->

Key Discussion Points:
• Likely implementing agency: Sagarmala Development Financial Corporation (SDFC).
• Annual business plan required for year-on-year corpus allocation; mid-year
replenishment allowed if corpus exhausted.
Actions to be Taken:
• Implementing agency to prepare fund disbursement modalities.
4. Premium Structure & Nature of Insurance
Key Discussion Points:
• Premium to be nominal, covering operational and training costs; actuarial study will
determine actual rates.
• NSM approval required for each product; implementation agency to review premium
fairness.
• Insurance covers optional, not mandatory.
Actions to be Taken:
• Agencies to initiate actuarial studies and share findings with NSM.
5. Additional Points
Key Discussion Points:
• Agencies must include fund management plan per IRDA norms.
• Corpus usage restricted to issuing covers and claim settlement only.
• NSM empowered to introduce new products without cabinet approval.
Actions to be Taken:
• Draft guidelines to incorporate premium study requirement and reporting obligations.

20

<!-- page 24 -->

Summary of Queries and Replies:
SN

Inputs/clarification sought

DGS Clarification

Agencies sought clarification on the
nomination processes for selection of
credit risk coverage provider

It was clarified that presently only
ECGC and NIA will be nominated by
NSbM. Communication in this regard
will be routed through respective
ministries.

3

The stakeholders sought clarity on
the term "Nominal Premium" in the
draft guideline and requested to
quantify the same as the premium for
these covers will be additional cost to
shipyard and/or shipowners as
passed on cost

It was clarified by ECGC and NIA that
an actuarial study is required, without
which quantification of premium is not
possible. DGS and MOPSW further
clarified that these premiums will be
reviewed and approved by NSbM.

3

Query on mandatory nature of
insurance - Stakeholders sought
clarification whether the insurance
would be mandatory for shipyards

It was clarified that these insurance
covers will be optional and not
mandatory for the shipyards, and be
based on shipyard risk appetite

4

They requested clarification on the
fund management strategy for the
corpus, as the funds would remain
idle in the absence of claims,
particularly during the initial phase.

It was requested from the insurance
agencies to incorporate an IRDAIcompliant fund management plan
within their proposals.

5

Stakeholders discussed whether the
corpus under this scheme could also
be utilized to subsidize insurance
premiums in addition to covering
claims

It was clarified that as per the
approved cabinet note the corpus is
restricted to cover claim settlement
only

A query was raised on whether funds
allocated under various pillars, such
as SBFAS, MDF, and SbDS, can be
utilized interchangeably.

It was clarified that funds allocated to
each pillar are separate and distinct;
however, reallocation within
subschemes under the same pillar
may be permitted with the approval of
the competent authority.

1

6

21

<!-- page 25 -->

7

A query was raised on whether any of
these insurance products would also It was clarified by ECGC that none of
cover litigation costs incurred by
these insurance policies will cover the
shipyards prior to the processing of
litigation costs.
claim settlements.

8

It was clarified that presently only
ECGC and NIA will be nominated by
NSbM. Communication in this regard
will be routed through respective
ministries.

Agencies sought clarification on the
nomination processes for selection of
credit risk coverage provider

22

<!-- page 26 -->

ANNEXURE-IV
LIST OF PARTICIPANTS FOR PHYSCIAL/HYBRID MEETING ON SBFAS & SBdS, Credit Risk cover Guidelines on 30-10-2025
Attended participants
64
Start time
10/30/25, 1:20:19 PM
End time
10/30/25, 6:44:57 PM
SNO
Name
Organizaion
Email
1 Ravi Kumar(SS)
DGS
ravi.k43@dgsmumbai.onmicrosoft.com
2 DIRECTORATE GENERAL OF SHIPPING-INDIA
DGS
Directorate@dgsmumbai.onmicrosoft.com
3 Anil Devli, CEO INSA (External)
INSA
ceo@insa.org.in
4 Amal Aloshie Vithayathil (External)
IRS
Amal.Aloshie@irclass.org
5 Amit Waje (External)
IRS
Amit.Waje@irclass.org
6 Uday Bhatt.SRIA
SRIA
7 Pandurang Dhond | Ship Building DivisionChowgule
(External)
pandurang.sbd@chowgule.co.in
8 Capt. Kapil Kekre (External)
INSA
kekre@insa.org.in
9 Nihal (Unverified)
SAI
10 Prashant Asogekar | Ship Building Division (External)
prashant.asogekar@chowgule.co.in
11 CSL (Unverified)
CSL
12 Daniel (Unverified)
SAI
13 AMAL (Unverified)
IRS
14 Srinivasa Rao P (Unverified)
HSL
15 Ankur Anal
DGS
ankuranal@dgsmumbai.onmicrosoft.com
16 K Swaminathan (External)
SWAN Defence
cdr.swaminathan@swan.co.in
17 Rekha CSLA (Unverified)
CSLA
18 Goa Shipyard Limited (Unverified)
GSL
19 shipbuilding-apmb (External)
APMB
shipbuilding-apmb@apmaritime.in
20 Joseph MATHEW
Seatrium
joseph.mathew@seatrium.com
21 Sanjiv Kapoor (External)
SWAN Defence
sanjiv.kapoor@swan.co.in
22 ASHA (Unverified)
SAI
23 R. V. Vimal (External)
Chowgule
vimal@chowguleglobal.in
24 priyesh Kamat
Synergy
25 Sanjay | Guidance Tamil Nadu (Unverified)Guidance Tamilnadu
26 Prantik
ISBA
27 Prathamesh Bam
Chowgule Lavgan Shipyardca@chowgulelavgan.com
28 Aaisha KS (External)
San Marine
aaisha.ks@titagarh.in
29 Jignesh Shah (External)
SWAN Defence
jignesh.shah@swan.co.in
30 SANJIV WALIA
SAI
31 Attreya Sawantt
Mandovi
32 Mitesh Agarwal (External)
SWAN LNG
mitesh.a@swanlng.co.in
33 sivakholundu (Unverified)
IMU
34 Anil Jain (Unverified)
35 Rajeev Nayyer (External)
SWAN defence
rajeev.nayyer@swan.co.in
36 Gupta, Anuj
PMU-KPMG
anujgupta21@kpmg.com
37 Dethe, Amit
PMU_KPMG
amitdethe@kpmg.com
38 Tom (Unverified)
39 ECGC LTD (Unverified)
ECGC
40 Abhinav (Unverified)
ECGC
41 PALANIMUTHU GOPAL
L&T
PALANIMUTHU.G@larsentoubro.com
42 Swati Gupte - NIA (Unverified)
NIA
43 Sanjay Kumar
ECGC
44 Pallavi sinha, New india (Unverified)
NIA

23

<!-- page 27 -->

24

<!-- page 28 -->

Annexure- V
INPUTS FROM STAKEHOLDERS ON THE SBdS - Shipbuilding Credit Riesk coverage guidelines
Discussion Held on 15 Oct 2025
S.No

Name of
person/organization

Inputs

Reply from DGS official

Asked about the modalities of corpus utilisation
Corpus will be distributed annually or multi-year
— whether the ₹1443 crore fund would be
depending on insurer’s underwriting plan. Additional
provided yearly or upfront, and how
funds can be requested mid-year upon justification.
claims/defaults would be handled at the
operational level.
Queried about ownership of partially built
Ownership depends on the contract; generally, the
vessels (70–80% completed) in the event of
shipbuilder retains ownership until full payment.
buyer insolvency, and who retains salvage
Buyer’s claim is limited to unpaid value.
rights.

1

NIA

2

NIA

3

NIA

Raised issue of whether ship-wise or master
Individual contract-wise policies preferred; duration
policies will be used and how long the coverage may exceed 12–18 months for complex ships. Insurers
period will be.
may file a new multi-year policy with IRDAI.

4

NIA

Highlighted that actuarial data on past
insolvencies and default trends is crucial for
designing a viable product.

DGS agreed; suggested compiling data from shipyard
associations and class societies to support product
design and reinsurer engagement.

5

ECGC

Emphasised need for sector-specific technical
expertise to assess risk and quantify losses;
requested ministry support.

MoPSW will facilitate capacity-building programmes
and technical training through maritime experts.

6

ECGC

Asked whether operational expenses can be
covered via premiums.

Insurers can charge nominal premiums to shipyards to
recover operational and training costs, while the
corpus covers risk payouts.

7

ECGC

Queried about the leverage or multiplier ratio
for corpus utilisation and exposure limits.

MoPSW will not fix leverage; insurer’s actuarial team
to determine multiplier (e.g., 5× or 10×). Ministry will
define only the fund-release process.

8

ECGC

Suggested establishing a Committee of
Directions (COD) similar to NEIA for
underwriting decisions.

DGS agreed in principle; governance structure to be
discussed further with MoPSW.

9

ECGC

Mentioned importance of defining costeffective yet viable premium rates to maintain
prudence among insured entities.

DGS concurred — premiums should remain low but
viable; corpus may grow over time if payouts are
minimal.

Discussion Held on 17 Oct 2025

Sr No.

10

11

Name of person /
organization

Input / Point of Discussion

DGS/MoPSW Reply

NIA/ECGC

The group requested details of the onboarding
process and the oversight structure for the
scheme.

DGS or SFCL will act as the Implementing Agency with
oversight by the NSbM Inter-Ministerial Governing
Board; agencies will be onboarded via EOI and formal
MoUs defining scope, corpus access, reporting, and
performance obligations.

NIA/ECGC

The participants asked for detailed productMeeting scope is limited to implementation guidelines
level clarifications on what would be covered
covering onboarding, fund disbursal, reporting, and
under pre-shipment, post-shipment, and vendor timelines; product specifications will be developed in
default insurance.
subsequent sessions with insurers and shipyards.

25

<!-- page 29 -->

12

13

14

15

NIA/ECGC

NIA/ECGC

The group sought clarity on the eligibility of
Agencies are currently envisaged as government/PSU
insurance agencies, specifically whether entities entities (e.g., NIA, ECGC) selected via an EOI process
beyond government/PSU (including private
and formalized by MoU; any inclusion of private
insurers) could participate.
insurers can be escalated to NSbM for consideration.

NIA/ECGC

The stakeholders asked for clarity on the
mechanism for corpus replenishment and its
governance.

The corpus will be centrally managed by the
Implementing Agency under NSbM oversight;
additional funding is subject to NSbM decisions and
overall corpus availability.

NIA/ECGC

The stakeholders asked how fund disbursals
would be structured (annual versus mid-year
releases) and what records would be required.

The Implementing Agency will manage the corpus with
annual releases and mid-year top-ups (if required).
There will be quarterly reporting, details of which will
be set out in MoUs/agreements.

16

NIA/ECGC

17

NIA/ECGC

18

19

20

21

22

Product design will not be finalized at this stage;
today’s focus is on governance and process for
operationalization, with product terms to be codeveloped after onboarding.

The stakeholders requested confirmation on
whether product design details would be
finalized during this meeting.

ECGC

The stakeholders raised concerns about the
potential early exhaustion of the allocated
annual corpus and the need for mid-year fund
availability.
The participants asked how catastrophic events
(such as a pandemic) would be handled if they
depleted the overall scheme corpus before
March 2036.
The agency requested clarity on whether
policies would be issued in the name of the
insurer (e.g., ECGC/NIA) or the Implementing
Agency (DGS/SFCL), and who would bear
liability if funds were unavailable at the time of
claim.

It was clarified that annual allocations will be provided
with flexibility for mid-year top-ups based on
utilization and demand, and interim requests will be
considered.
It was submitted that such extreme scenarios will be
deliberated with NSbM.

NEIA-like corpus-backed underwriting structures may
be referenced; specific arrangements will be defined in
agreements and product documentation and taken up
with NSbM.

NIA

The insurer asked how leverage assumptions
(for example, a 20x illustration) would be
determined and whether they would be
sufficient under high-claims scenarios.

referenced leverage is indicative and dependent on
underwriter risk assessment; if claim pay-outs exceed
the agency-level corpus, the Implementing Agency may
allocate additional funds subject to overall corpus
availability and NSbM decisions.

NIA/ECGC

The participants asked whether Implementing
Agency will have directions / restrictions on
quantum of the policy premiums and what
costs they are intended to cover.

Premiums will be kept nominal due to the seed corpus
being provided by GoI. It should primarily cover
operating expenses and capacity building; pricing
mechanics will be finalized during product/agreements
based on insurer risk assessment.

NIA/ECGC

As the Vendor Default Cover is a new concept in
the Indian context, the group sought clarity on As correctly mentioned, the Vendor Default Cover is a
new concept in the Indian context; its scope will be
the scope and triggers for Vendor Default,
including warranty support failure, vendor
developed during product design. DGS/MoPSW will
endeavour to coordinate with industry stakeholders to
insolvency, and quality/specification failures.
They also requested to share literature and
share literature and references in this regard.
references on the same from other countries.

NIA/ECGC

The stakeholders asked about the reporting
mechanism and utilization monitoring
requirements.

26

Quarterly reporting is envisaged with flexibility for
interim threshold-based requests; the Implementing
Agency will monitor utilization and performance and
escalate to NSbM as required.

<!-- page 30 -->

23

24

25

NIA/ECGC

The participants asked about the expected
timelines for rolling out products after
onboarding.

Timelines will be defined during onboarding and in
agreements; the immediate priority is to finalize
implementation guidelines by 24 October 2025.

Chowgule- Sagar
satpute

It was also discussed if a government run
insurer can become the Implementation Agency
This point was noted and will be deliberated further
instead of DGS or SFCL, due to specific expertise
with NSbM.
required to monitor and manage the insurance
products.

NIA/ECGC

The stakeholders asked whether reinsurance
would be included as part of risk layering for
the products as the reinsurance may increase
cost and hence the policy premiums.

Reinsurance may be explored during product design,
with cost and structure to be determined in
coordination with the agencies.

Discussion Held on 30 Oct 2025

NIA/ECGC

Agencies sought clarification on the nomination It was clarified that presently only ECGC and NIA will
processes for selection of credit risk coverage
be nominated by NSbM. Communication in this regard
provider
will be routed through respective ministries.

27

Chowgule SBD

The stakeholders sought clarity on the term
It was clarified by ECGC and NIA that an actuarial study
"Nominal Premium" in the draft guideline and is required, without which quantification of premium is
requested to quantify the same as the premium not possible. DGS and MOPSW further clarified that
for these covers will be additional cost to
these premiums will be reviewed and approved by
shipyard and/or shipowners as passed on cost NSbM.

28

Chowgule SBD

Query on mandatory nature of insurance Stakeholders sought clarification whether the
insurance would be mandatory for shipyards

It was clarified that these insurance covers will be
optional and not mandatory for the shipyards, and be
based on shipyard risk appetite

29

NIA/ECGC

They requested clarification on the fund
management strategy for the corpus, as the
funds would remain idle in the absence of
claims, particularly during the initial phase.

It was requested from the insurance agencies to
incorporate an IRDAI-compliant fund management plan
within their proposals.

30

Stakeholders discussed whether the corpus
under this scheme could also be utilized to
Shri Rajiv Nayyar- SWAN Defence
subsidize insurance premiums in addition to
covering claims

It was clarified that as per the approved cabinet note
the corpus is restricted to cover claim settlement only

31

A query was raised on whether funds allocated
Shri Rajiv Nayyar- SWAN
Defence
under
various pillars, such as SBFAS, MDF, and
SbDS, can be utilized interchangeably.

It was clarified that funds allocated to each pillar are
separate and distinct; however, reallocation within
subschemes under the same pillar may be permitted
with the approval of the competent authority.

32

A query was raised on whether any of these
insurance products would also cover litigation
Shri Rajiv Nayyar- SWAN Defence
costs incurred by shipyards prior to the
processing of claim settlements.

It was clarified by ECGC that none of these insurance
policies will cover the litigation costs.

26

27

<!-- page 31 -->

Annexure- VI

No. SY - 13017 lll2025-SBR

flT{A'TSilt
Government of lndia

q6a, q!6 qftT6t 3itt ilffirrt d"rfic
Ministry of Ports, Shipping and Waterways

st fi.arr 4mr / SBR Section)

qft{64 ffifr I Transport Bhawan,

r - fifEentl I - Parliament Street,

ngAlFfi- l100ol / New Delhi - 1l00ol
Eai{. / Dated: ogth October, 2025
OFFICE MEMORANDUM

Subject: constitution of the stakeholders consultation committees to
facilitate drafting of guidelines on 'scheme for Capacity & Capability
Development and Credit Risk Coverage for Shipbuilding in India' - reg.
The undersigned is directed to state that the Govemment has approved the
,scheme for Capacity & Capability development and credit risk coverage for
Shipbuilding in India-Shipbuilding Development Scheme' for the promotion of the
shipbuilding sector in India. Extract of the approved scheme is attached as
Annexure. Two sets of Guidelines for the scheme are to be issued for
operationalization and implementation of the scheme. For the purpose of drafting
these guidelines, following committees are to be constituted'

2. (i) The Directorate General of Shipping may constitute a committee of

stakeholders, such as, Indian Maritime University, Centre of Excellence in
Maritime and shipbuilding, Shipyards Association of India, Indian Shipbuilder
Association, Cochin Shipyard Limited, Indian Register of Shipping, Indian Marine
Designers Association. Director (SBR), MoPSW shall be a member of the
Committee and an officer with adequate seniority fiom Directorate General of
Shipping shall be the member convener of the committee.

(ii) The above committee shall hold consultations with all concerned
stakeholders including shipyards (domestic as well as intemational) and shipping
institutions (domestic as well as intemational) and shall formulate draft guidelines
on following components of the scheme, namely, 'Capital support for greenfield
capacity expansion', 'Capital assistance to existing/ brownfield shipyards towards
the expansion of production capacity' and 'Capability development initiatives'.

28

<!-- page 32 -->

3. (i) The Director General of Shipping may constitute a second Committee

comprising of stakeholders, such as, New India Assurance, Export Credit
Guarantee Corporation of Indi4 Sagarmala Finance Corporation Limited, Indian
Shipbuilder Association, Shipyards Association of India, Cochin Shipyard
Limited. Director (SBR), MoPSW shall be a member of the Committee and an
officer with adequate seniority from Directorate General of Shipping shall be the
member convener of the committee.

(ii) The above committee shall hold consultations with all concemed
stakeholders including shipyards (domestic as well as international), shipping
institutions (domestic as well as intemational), financial institutions and shall
formulate draft guidelines on the 'shipbuilding risk coverage' component of the
scheme.

4. Director General of Shipping shall submit these two draft guidelines to the
MoPSW by 24th October, 2025.

5. This issues with approval of the competent authority.

*YaIY4rc\"y{

To

(Y#i-nav Mittalyl t
Under Secretary to the Government of India
Email id: usshipping2-psw@gov.in
Tel No.: 01f- 2331f659

Directorate General of Shipping,
{Kind Attn.: Shri Shyam Jagannathan, DGS}
9'n Floor Beta Building,
i-Think Techno Campus,
Kanjur Marg (East), Mumbai -

Copy to:

i. Office of Secretary (PSW)
ii. Office of SS(PSW)
iii. Oflice of JS (S)
iv. Director (SBR)

29

<!-- page 33 -->

Annexure- VI

भारत सरकार/ GOVERNMENT OF INDIA
प न,पोत प रवहन और जलमाग मं ालय /
MINISTRY OF PORTS, SHIPPING AND WATERWAYS

नौवहन महा नदे शालय, मब
ंु ई
DIRECTORATE GENERAL OF SHIPPING, MUMBAI
File No: 26-12/9/2022-NA - DGS

Dated :12-10-2025

Order
Subject: Constitution of Credit Risk Coverage Core Committee for Drafting Guidelines Under
Shipbuilding Development Scheme (SbDS).
In pursuance of the Government of India’s approval for the Scheme for Capacity Capability
Development and Credit Risk Coverage for Shipbuilding in India (Shipbuilding Development Scheme
— SbDS), and as per Ministry of Ports, Shipping and Waterways (MoPSW) directions, the following
committee is constituted for preparing draft guidelines for Credit Risk coverage and for conducting
stakeholder outreach and workshops for industry inputs.
1. Committee Constitution
The Credit Risk Coverage Core Committee as decided by the Competent authority shall comprise the
following members:
S. No.

Representative

Organization/Association Name

Role

1

Director (SBR)

Ministry of Ports, Shipping and Waterways
(MoPSW)

Member

2

Representative

Directorate General of Shipping (DGS)

Member
Convener

3

Representative

New India Assurance Co Ltd

Member

4

Representative

Export Credit Guarantee Corporation of India(
ECGC)

Member

5

Representative

Sagarmala Finance Corporation Limited (SMFCL)

Member

6

Representative

Shipyards Association of India (SAI)

Member

7

Representative

Indian Shipbuilder Association (ISBA)

Member

8

Representative

Shipping Corporation of India (SCI)

Member

9

Representative

Cochin Shipyard Limited (CSL)

Member

The Committee may co-opt other experts/ Stakeholders, as considered necessary for its deliberations.
___________________________________________________________________________________________________________________
बीटा ब डींग, 9वी मंिजल, आई थंक टे नो कै पस, कांजूर माग (पव
ू ), मंबई – 400 042
Beta Building, 9th Flr., I-Think Techno Campus, Kanjur Marg (E) / Mumbai – 42

फोन/Tel.: 91-22-25752040/1/2/3, फै स/Fax.: 91-22-25752029/3530
ई-मेल/E-mail : dgship-dgs@nic.in वेबसाईट /Website: www.dgshipping.gov.in

<!-- page 34 -->

2. Mandate
(I) Draft guidelines for the credit risk coverage offered to shipyards in accordance with the approved
scheme and reference documents from MoPSW attached as Annexure-I.
(II) Conduct stakeholder outreach and workshops to gather industry inputs on the guidelines.
3. Terms of Reference(TOR) of the Committee:






Review the approved scheme and relevant directives on credit risk coverage of Shipbuilding
Development Scheme (SbDS).
Draft comprehensive guidelines for credit risk coverage offered to shipyards, in consultation
with all stakeholders.
Ensure alignment of guidelines with scheme objectives and requirements of all stakeholders.
Hold consultations, outreach events, and industry workshops to ensure broad-based
participation and feedback.
Submit consolidated draft guidelines to the Directorate General of Shipping for onward
transmission to MoPSW by the stipulated date.

4. Timeline



The Committee shall submit the draft guidelines to the Directorate General of Shipping by 24th
October, 2025.
The committee may convene meetings and workshops as required to ensure timely completion
of the mandate.

5. Secretariat and Coordination


The Directorate General of Shipping shall provide secretarial and administrative support to the
Committee.

6. General


7.

All concerned departments, agencies, and stakeholders are requested to extend full
cooperation to the Committee for effective framing of the guidelines.
This order is issued with the approval of the Competent Authority.

Ravi Kumar M
Ship Surveyor-cumDeputy Director General (Tech)
Directorate General of Shipping
Encl.:
 Annexure I: Extract of Approved Shipbuilding Development Scheme (SbDS)
 Annexure II: List of Committee Members

To,
1. All Organizations/Stakeholders as per Annexure-II.

31

<!-- page 35 -->

Annexure II: List of Committee Members

Credit Risk Coverage Core Committee: List of Members
S.
No.

Organization/Association Name
Ministry

1

of

Ports,

Shipping

Name of the Members
and

Waterways (MoPSW)

Shri Vipul Singhal, Director (SBR)

Shri Ravikumar Moka, SS-cum-DDG(Tech)2

Directorate General of Shipping (DGS)

Member Convenor
Shri Ankur Anal, JSS-cum-ADG (Tech)

3

4

New India Assurance Co Ltd

Smt Swati Gupte, Chief Manager

Export Credit Guarantee Corporation

Shri Subhash Chahar, DGM

of India (ECGC)

Ms. Aarti Pandey, DGM

Sagarmala
5

Shri K Ramesh, General Manager

Finance

Corporation

Limited (SMFCL)

Shri Dinesh Kumar, Director (Sagarmala)

Shri Sagar Satpute, CCPL

6

Shipyards Association of India (SAI)

7

Indian Shipbuilder Association (ISBA)

Shri Palanimuthu G, DGM, L&T

8

Shipping Corporation of India (SCI)

Shri. Shyamalendu Bhushan Das, GM

9

Cochin Shipyard Limited (CSL)

Ms. Asha V Rao, AGM (Fin)

Shri Rajeev Nayyar, SDHI

32

<!-- page 36 -->

DRAFT GUIDELINES FOR SHIPBUILDING RISK COVERAGE
under Shipyard Development Scheme (SBdS)

Annexure-VII

1. (a) Title: The scheme for providing Capital support for greenfield capacity expansion,
capital assistance for brownfield shipyard expansion , capability development through
India Ship Technology Centre and providing shipbuilding risk coverage shall be called
“Shipbuilding Development Scheme ” and the guidelines formulated to implement the
scheme together

shall be called “Guidelines for Implementation of Shipbuilding

Development Scheme(SbDS)”.
(b)

Validity: The Shipbuilding Development Scheme and the guidelines shall come

into force with effect from XXX and remain valid for all Detailed Project Reports (DPRs)
submitted from XXX to 31 March 2036, including the said dates.
(c)

Applicability: The scheme for providing shipbuilding risk coverage shall apply to

all existing Indian shipyards that are duly registered.
2.

Definitions.

a) SbDS (Shipbuilding Development Scheme) - A government initiative aimed at enhancing
domestic shipbuilding capacity and competitiveness through financial support and risk
mitigation.
b) NSbM (National Shipbuilding Mission) - The apex body responsible for overseeing the
implementation of shipbuilding schemes including SbDS.
c) Implementation Agency - The designated government entity (e.g., Directorate General of
Shipping or Sagarmala Financial Corporation Limited) responsible for releasing funds to
nominated credit risk cover agencies.
d) Credit Risk Cover Agencies - Government-owned entities or public sector undertakings
nominated by NSbM to design and administer insurance products for shipbuilding-related
risks.

33

<!-- page 37 -->

DRAFT GUIDELINES FOR SHIPBUILDING RISK COVERAGE
under Shipyard Development Scheme (SBdS)
e) Pre-Shipment Insurance - Insurance product that covers financial losses due to buyer default
or cancellation during vessel construction.
f) Post-Shipment Insurance - Insurance product that covers risks of non-payment after vessel
delivery due to disputes, defects, or political factors.
g) Vendor Default Insurance - Insurance product that protects shipyards from losses due to
vendor failure to deliver critical components.
h) Corpus - The total financial allocation under SbDS (₹1,443 crore) designated for credit risk
coverage.
i) Nomination Solicitation - The process by which NSbM invites proposals from eligible entities
to serve as credit risk cover agencies.
j) Performance Metrics - Criteria used to evaluate credit risk cover agencies, including claim
settlement time, accuracy of loss estimation, and stakeholder

3. Purpose
The objective of this guideline is to operationalize the ₹1,443 crore allocation under the
Shipbuilding Development Scheme (SbDS) for credit risk coverage. This initiative aims to provide
financial protection to Indian shipyards against key risks associated with shipbuilding contracts
and vendor dependencies. By offering structured insurance products, the scheme is intended to
insulate shipyards from various types of risks in undertaking both domestic and export-oriented
shipbuilding projects, thereby strengthening the sector’s resilience, competitiveness, and longterm viability.

34

<!-- page 38 -->

DRAFT GUIDELINES FOR SHIPBUILDING RISK COVERAGE
under Shipyard Development Scheme (SBdS)
4. Institutional Framework
The Implementation Agency for this scheme will be the Directorate General of Shipping or
Sagarmala Financial Corporation Limited. The Implementation Agency will be solely responsible
for the release of funds to the nominated credit risk cover agencies. It will not be involved in
product development, underwriting, or oversight functions.
4.1 Step 1: Nomination of Credit Risk Cover Agencies
Credit risk cover agencies will be responsible for developing the financial products to be offered
to the Indian shipbuilding sector. These agencies will be nominated directly by NSbM after
evaluating proposals submitted by eligible government entities.
4.1.1 Eligibility Criteria
Only government-owned entities or public sector undertakings shall be eligible for nomination as
credit risk cover agencies under this scheme. These entities must demonstrate either substantial
experience in the maritime domain or a proven track record in administering credit risk or
insurance products in infrastructure, export, or industrial sectors.
4.1.2 A Nomination Solicitation
NSbM will seek nominations from all eligible and relevant government entities to provide the credit
risk covers as approved by the Cabinet. This process will ensure transparency, inclusivity, and
alignment with the strategic objectives of the scheme.
4.1.3 Nomination Process
NSbM shall directly nominate credit risk cover agencies based on proposals received from eligible
government entities. The Implementation Agency will act upon NSbM’s nominations and release
funds accordingly.
Proposals will be evaluated based on:

35

<!-- page 39 -->

DRAFT GUIDELINES FOR SHIPBUILDING RISK COVERAGE
under Shipyard Development Scheme (SBdS)


Demonstrated domain expertise in maritime or infrastructure insurance



Capacity to underwrite and manage large-scale credit risk covers



Existing operational frameworks for policy issuance, claims management, and fund
administration



Ability to scale operations and customize insurance products to meet the specific needs
of the shipbuilding sector

The final nomination of agencies and the categories of insurance products to be developed will
be subject to approval by the Inter-Ministerial Governing Board constituted under NSbM.
4.1.4 Designation and Onboarding
Once nominated by NSbM, credit risk cover agencies will be formally designated through Letters
of Nomination issued by NSbM. Each agency will enter into an agreement with the Implementation
Agency, which will define the scope of fund access, reporting obligations, and performance
benchmarks.
This agreement will serve as the operational foundation for the agency’s role in administering
credit risk covers under SbDS.

4.2. Corpus Access and Fund Allocation
Step 2: Corpus Management
The corpus allocated under SbDS for credit risk coverage shall be centrally managed by the
Implementation Agency with the approval of NSbM.
Funds will be allocated to the nominated credit risk cover agencies on a financial year basis.
The allocation will be determined based on projected demand from shipyards, historical utilization
trends, and prevailing market conditions that influence risk exposure.

36

<!-- page 40 -->

DRAFT GUIDELINES FOR SHIPBUILDING RISK COVERAGE
under Shipyard Development Scheme (SBdS)
A mid-year allocation may be considered on a request basis depending upon the fund requirement
raised by the Implementation Agency as a formal submission.
4.3 Step 3: Initial Disbursement
An initial tranche of funds will be disbursed by the Implementation Agency to credit risk cover
agencies to enable the immediate rollout of credit risk cover products.
Subsequent disbursements will be linked to performance indicators such as policy uptake, claims
processed, and fund utilization efficiency.
Credit risk cover agencies will provide annual business plans to justify the release of additional
corpus.

4.4 Credit Risk Cover Products
Step 4: Product Design
Credit risk cover agencies shall design and offer the following credit risk cover products:


Pre-Shipment Insurance (Buyer’s Default): Protects shipyards from financial losses due
to buyer cancellation or default during vessel construction. Covers incurred production
costs and potential lost profits.



Post-Shipment Insurance: Covers risks of non-payment by the buyer after vessel
delivery due to disputes, defects, political instability, or other factors.



Vendor Default Insurance: Protects shipyards against losses from vendor failure to
deliver critical components. Covers advances paid to vendors.

Credit risk cover agencies will also be responsible for ensuring all relevant regulatory compliances
for the products they develop, including obtaining necessary approvals from their parent entities
or administrative ministries.

37

<!-- page 41 -->

DRAFT GUIDELINES FOR SHIPBUILDING RISK COVERAGE
under Shipyard Development Scheme (SBdS)
Additionally, credit risk cover agencies must commit to specific timelines for product development,
internal and external approvals, and introduction of the products in the market to ensure timely
rollout and sectoral impact.
The Implementation Agency shall monitor adherence to these timelines and regulatory obligations
through periodic progress reports submitted by the credit risk cover agencies. Any delays or
deviations shall be escalated to NSbM for review and corrective action.
4.5 Step 5: Customization
All insurance products must be tailored to reflect the unique structure of shipbuilding contracts,
including advance payments, milestone-based payments, delivery-linked payments, and retention
money.
Credit risk cover agencies may offer bundled or modular products based on shipyard needs.
Product development shall incorporate stakeholder inputs, including from shipyards.

4.6 Premium Structure
Step 6: Premium Charges
Credit risk cover providers may charge premiums to shipyards for the products offered under this
scheme. However, since the corpus is being provided by the Government of India through the
Implementation Agency, premium rates shall be nominal.
Pricing must primarily reflect operational expenses and capacity building costs of the credit risk
cover agencies.
The Implementation Agency will review and approve the premium structures proposed by each
agency and seek prior approval of NSbM to ensure consistency, fairness, and alignment with the
scheme’s objectives.

38

<!-- page 42 -->

DRAFT GUIDELINES FOR SHIPBUILDING RISK COVERAGE
under Shipyard Development Scheme (SBdS)
4.7. Operational Responsibilities
Step 7: Risk Assessment and Claims Management
Credit risk cover agencies shall be responsible for conducting risk assessments and underwriting
policies based on sound methodologies. They must establish transparent and efficient claims
management processes to ensure timely resolution and financial support to shipyards. Agencies
are expected to maintain actuarial discipline and adhere to best practices in insurance
administration.
Credit risk cover agencies will also be responsible for managing payouts under the scheme. They
shall follow industry-standard processes for loss estimation, due diligence, fraud prevention, and
claims verification to ensure integrity and fairness in disbursement.
To ensure accountability, credit risk cover agencies shall be evaluated against defined
performance metrics such as claim settlement turnaround time, accuracy of loss estimation, and
stakeholder satisfaction. These metrics will be reviewed periodically by the Implementation
Agency.
Additionally, the Implementation Agency shall conduct regular audits of the credit risk cover
agencies to verify compliance with scheme guidelines, financial integrity, and operational
standards. Findings from these audits shall be reported to NSbM for necessary action.
4.8 Step 8: Capacity Building
Each credit risk cover provider shall invest in developing sector-specific expertise related to
shipbuilding and maritime risks. This includes training underwriters and claims officers, engaging
with shipyards to raise awareness about available products, and building internal capabilities to
manage complex insurance portfolios.
Each credit risk cover provider shall invest in developing sector-specific expertise related to
shipbuilding and maritime risks. This includes training underwriters and claims officers, engaging

39

<!-- page 43 -->

Annexure- IV

DRAFT GUIDELINES FOR SHIPBUILDING RISK COVERAGE
under Shipyard Development Scheme (SBdS)

with shipyards to raise awareness about available products, and building internal capabilities to
manage complex insurance portfolios.
Each credit risk cover provider shall invest in developing sector-specific expertise related to
shipbuilding and maritime risks. This includes training underwriters and claims officers, engaging
with shipyards to raise awareness about available products, and building internal capabilities to
manage complex insurance portfolios.

4.9 Monitoring and Oversight
Step 9: Reporting Requirements
Credit risk cover providers shall submit quarterly reports to the Implementation Agency detailing
the number of policies issued, claims processed, fund utilization, and the overall impact of the
credit risk covers on the shipbuilding sector. These reports will be used to assess performance
and guide future fund allocations. The periodicity of the reports will be as decided by the
Implementation Agency. Any irregularities shall be reported to NSbM.
4.10 Step 10: Oversight Mechanism
An Inter-Ministerial Governing Board under NSbM shall oversee the implementation of the credit
risk cover component of SbDS. The Board will review fund utilization, evaluate policy
effectiveness, recommend adjustments to product design or fund allocation, and ensure that the
scheme’s objectives are being met in a timely and efficient manner.

40
