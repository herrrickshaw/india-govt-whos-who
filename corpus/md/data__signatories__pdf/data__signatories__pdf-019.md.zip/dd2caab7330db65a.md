---
doc_id: "dd2caab7330db65a"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/36e7eacfc90e9da87a5cb0336e2a04e2.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Additional panel for CAT, Nagpur and various District Courts in Maharashtra: Order dated 26.02.2019 along with Order dated 18.04.2022"
date: "2022-04-18"
pages: 22
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "37404bf72e8c4366"
---

<!-- page 1 -->

F. No. J-1 1 017 11 12022-Judicial (Part-1 )
Government of lndia
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi
Dated the 1Bt; April,2022

ORDER

With reference to this Department's earlier Orders, as mentioned under
column-ll in the table below, regarding engagement of Advocates for conducting
Central Government litigation before the courts / tribunals mentioned undet column-lll,
the President is pleased to extend the terms of all the panel counsel figuring in the
panel as per corresponding order and courts / tribunals (mentioned under column-ll &
/// respectively), with effect from the date shown against each under column-lV, "until

further orders":
Details of orders
(Order No. and date)

Name of court / tribunal panel
counsel engaged for

with effect from

il
)-I7OL7 I !7 I 20t8Jud icial
dated 24.01.2019

ilr

IV

Gauhati HiBh Court (PB) at

24.O7.2022

sl.
No.
I

1.

Term extended

Guwahati, Central Administrative

Tribunal Guwahati Bench and
Armed Forces Tribunal (RB) at
Guwahati
2

J -L1077 / 78 / 2019-J u d

icial

dated 28.02.2019

High Court of Uttarakhand and
Armed Forces Tribunal (CB) at

28.O2.2022

Nainital
3

4.

J -L1077

h8 I 20L8J u d icial

Central Administrative Tribunal,

dated 02.08.2018

Circuit Bench at N ain ita I

J-71017 / 25 / 2Ot8J ud icial

Punjab & Haryana High Court,
Central Administrative Tribunal,
Chandigarh Bench and Armed

dated 22.11.2018

02.08.2077

22.77.2027

Forces Tribunal (RB) at

Chandigarh
5

J-

LLOL5 / L / 2OL8-J u d icia I

Various District & Subordin ate

79.O2.2027

dated 19.02.201.8

Courts in the state of Haryana

6

)-77015 / 6 / 2O78J ud icial
dated 19.04.2018

District Courts Chandigarh (UT)

L9.04.2021.

7.

J-

Various District Courts in the

18.04.2027

LLOL5 / 7 / 20L8-J u d icia I

dated 18.04.2018

state of Telangana

r}

-:4>

<!-- page 2 -->

1710t7 / 16 / 2OL7J ud ci a I
dated 11.10.2017
i

9

10

tt.

High Court of Tripura, various
District & Subordinate Courts in
the state of Tripura

J-L7077 I 76 /2077-J udicial

Various District & Subordinate

dated 07.11.2017

courts in the state of Tripura

J -rLO77 / 16 /

Various District & Subordinate

20t7-J u d icia I

dated 02.08.2018

courts in the state of Tripura

-TLOLI I L I 20L8{ ud ici a I

J&K High Court at Jammu, Central

dated 25.02.2019

Administrative Tribunal, Jammu

J

1.7.1.0.2020

07.17.2020

02.08.2027

26.02.2022

Bench and Armed Forces Tribunal
(RB) at Jammu. Terms of Panel
Counsel for High Court of Jammu
& Kashmir at Srinagar were also
extended.
72.

)-t7OL5 / 9 / 2Ol8-J ud icia I
dated 02.08.2018

Various District Courts in the
earstwhile state of Jammu &

02.08.2027

Kashmir and now UT of Jammu &
Kashmir and UT of Ladakh
13

J-

71Ot7 / L3 I ZOL8-J u d ici a I

High Court of Jharkhand, Central

07.03.2022

Administrative Tribunal, Ranchi
Bench and District & Subordinate

dated 07.03.2019

Courts in the state of Jharkhand

!4.

)-tt015 / 2 I 2079-J ud icia

I

dated 09.03.2019
15.

J-

tt0l7 / 2L I 20L8-J u d icia I Various District &

(Part-1)

dated

26.02.2019
16.

J

-

Various District & Subordinate
Courts in the state of Rajasthan

the

Subord inate

26.02.2022

state of

Maharashtra

tL}ts I L I 2OL9J ud ci a I

dated 09.03.2019

Courts in

09.o3.2022

i

Various District & Subordinate
Courts in the state of Kerala

09.03.2022

2.

The terms & conditions of the engagement of aforesaid Advocates will be
governed bythis Department's OM No.26(l)/99-Judl. dated 24.09.1999 read with OM
No. 26(1)/2014/Judl. dated 01 .10.2015 & instructions issued subsequently through
OMs. The aforesaid OMs are available on the website of this Department i.e.
www.leqalaffairs.qov. in in the tab'Judicial Section'under heading 'Circulars pertaining
to litigations'.

3.

Hindi version of this order will follow.

};+1n"e\s,\o

(R. K. Srivastava)
Joint Secretary & Legal Adviser

<!-- page 3 -->

F. No. J-l 1 0'l 7/1 l20224udicial (Part-1 )

Oaled.. 18.04.2022

Copy to:-

1. PS to ML&J/PS to MSLJ/PS to Law Secretary/Ps to Legislative Secretary/All Additional
Secretaries/PS to all JS&LA in the Main Sectt.

2. The lncharge, Branch Secretariats at Mumbai, Kolkata, Chennai and Bangalore.
3. The Registrar of High Courts and Benches of High Courts mentioned in column-lll in the
table above.
4. The Addl. Solicitor General of lndia, High Court of Rajasthan, High Court of Punjab &
Haryana and Southern Zone.
5. The Assistant Solicitor General of lndia for the High Courts i Benches of High Courts as
per list.
6. The Cash (LA) Section for the payment of retainership fee to Sr. CGSCS, SGCs figuring
in the orders mentioned under column-ll in the table above with effect from the
corresponding date shown against each undet column-lv.
7. The Pay & Accounts Office, Department of Legal Affairs, New Delhi.

8. One copy of this order is uploaded on website of this Department i.e.

www.leoalaffairs.qov. in under tab 'Judicial Section' in the link 'List of em panelled
Advocates' for the information of all concerned.
9. Hindi unit, Department of Legal Affairs for Hindi translation of the order
10. Guard FileiJudicial Section with 5 spare copies.

/"9

(1. C. Dabaria)

Assistant Legal Adviser (Judicial)
Tel.01 1-23384831
Email: iudicial-dla@nic.in

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

<!-- page 17 -->

<!-- page 18 -->

<!-- page 19 -->

<!-- page 20 -->

<!-- page 21 -->

<!-- page 22 -->
