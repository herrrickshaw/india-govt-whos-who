---
doc_id: "ddb8b9c5a5da97b3"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/15a147ecf7b7ee5744b22f72ebe18ee7.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Indian Telegraph (Amendment) Rules_28March2017"
date: "2017-03-28"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "61f4362ac5e0e9f4"
---

<!-- page 1 -->

REGD. NO. D. L.-33004/99

jftLVªh laö Mhö ,yö&33004@99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 238]

ubZ fnYyh] eaxyokj] ekpZ 28] 2017@ pS=k 7] 1939

No. 238]

NEW DELHI, TUESDAY, MARCH 28, 2017/CHAITRA 7, 1939

संचार मं ालय
(दूरसंचार िवभाग)

अिधसूचना
नई िदल्ली, 28 माचर्, 2017
सा.का.िन. 297(अ).—के न् ीय सरकार, भारतीय तार अिधिनयम, 1885 (1885 का 13) की धारा 7 ारा द
शि य का योग करते हुए, भारतीय तार िनयम, 1951 का और संशोधन करने के िलए िन िलिखत िनयम बनाती है,
अथार्त् :—
1. (1) इन िनयम का संिक्ष नाम भारतीय तार (संशोधन) िनयम, 2017 है।
(2) ये सरकारी राजप म काशन की तारीख से वृ समझे जाएंगे।
2. भारतीय तार िनयम, 1951 म िनयम 525 (िजसे इसम इसके प ात् उ िनयम कहा गया है), के उपिनयम (2)
के खंड (ii) म मद संख्या (क ख) के प ात् िन िलिखत मद को शािमल िकया जाएगा अथार्त्—
"(क ग) िदनांक 1 अ ैल 2002 से पूवर् ितस्थािपत की गई ामीण घरे लू सीधी ( त्यक्ष) एक्सचज लाइन के
िलए, िदनांक 18 जुलाई, 2012 से 1 वषर् की अविध के िलए एक हजार दो सौ पचास हजार करोड़ रु. की
अिधकतम रािश की ितपूित अिभगम अभाव भार के स्थान पर, ामीण तार लाइन की संचालनात्मक
वहनीयता के िलए भारतीय डाक (संशोधन) िनयम, 2017 के लागू होने की तारीख से पा संचालक को की
जाएगी।
3. उ िनयम के िनयम 526 के “मद (क), मद (क क) और मद (क ख)” के शब्द , को क और अक्षर के स्थान पर
“मद (क), मद (क क), मद (क ख) और मद (क ग)” के शब्द, को क और अक्षर को ितस्थािपत िकया जाएगा।
[फा. सं. 30-104-1/2013-यूएसएफ]
अिमत यादव, संयुक्त सिचव ( शा.) दूरसंचार िवभाग
िटप्पणी : मुख्य िनयम डाक एवं तार पुिस्तका खंड I, िवधायी अिधिनयम, भाग-II, संस्करण म कािशत िकए गए थे और
िपछली बार िदनांक 10.12.2015 की अिधसूचना सं. सा.का.िन. 241 ारा संशोिधत िकए गए थे।
1740 GI/2017

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

MINISTRY OF COMMUNICATIONS
(Department of Telecommunications)
NOTIFICATION
New Delhi, the 28th March, 2017
G.S.R. 297(E).—In exercise of the powers conferred by section 7 of the Indian Telegraph Act, 1885
(13 of 1885), the Central Government hereby makes the following rules further to amend the Indian Telegraph
Rules, 1951, namely:—
1. (1) These rules may be called the Indian Telegraph (Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In rule 525 of the Indian Telegraph Rules, 1951 (hereinafter referred to as the said rules), in
sub-rule (2), in clause (ii) after item (ab), the following item shall be inserted, namely:—
“(ac) For rural household Direct Exchange Lines installed prior to 1st April 2002, an amount of
maximum of one thousand two hundred fifty crore rupees for a period of one year, with effect
from 18th July, 2012 shall be reimbursed to the eligible operator, from the date the Indian
Telegraph (Amendment) Rules, 2017 come into force, for operational sustainability of rural
wire lines in lieu of Access Deficit Charges.”
3. In rule 526 of the said rules, for the words, brackets and letters “item (a), item (aa) and item (ab)”,
the words, brackets and letters “item (a), item (aa), item (ab) and item (ac)” shall be substituted.
[F. No. 30-104-1/2013-USF]
AMIT YADAV, Jt. Secy. (A), DoT
Foot Note: The principal rules were published in the Post and Telegraph Manual Volume I, Legislative
Enactments, Part II, Edition and last amended vide notification number G.S.R. No. 241 dated
10.12.2015.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
SARVESH KUMAR
SRIVASTAVA

Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2017.03.28 23:30:16 +05'30'
