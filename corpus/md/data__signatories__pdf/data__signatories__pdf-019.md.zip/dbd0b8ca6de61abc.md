---
doc_id: "dbd0b8ca6de61abc"
source_url: "https://dof.gov.in/static/uploads/2025/09/d398f7de1879d3664428c92dbb94e0de.pdf"
ministry: "Department of Fisheries (DoF)"
title: "RFP on O&M’ of Phase-1 and ‘DBFOT’ of Phase-2 of the ‘Integrated Coastal Aquaculture Facilities’ at Mulapolam Village, Srikakulam District, Andhra Pradesh in PPP Mode (30-12-2022)"
date: "2022-12-30"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "24b497f23cef5964"
---

<!-- page 1 -->

राष्ट्रीय माल्यिकी विकास बोर्ड
= National Fisheries Development Board
iw FRTUTE FAUT Department of Fisheries
ua मत्स्यपालन, पशुपालन BA SAM HATTA /Ministry of Fisheries, Animal Husbandry & Dairying
ges ; ‘UIA BRB /Government of India A
Cohoeg) स्तम्भ संख्या-235, पी.वी.एन.आर एक्सप्रेस वे, डाक-एस.वी.पी.एन.पी. ए. हैदराबाद- 500052 NFDB SS
sea aa Pillar No: 235, PVNR Expressway, SVPNPA Post, Hyderabad-500 052
TPH Phone No. 040- 24000201; HH Fax No: 040-2401 5568; HG/ Mail: info.nfdb@nic.in
NFDB/ Division I/ Mulapolam Land Development/2020-21 Date: 30.12.2022
CORRIGENDUM II
(Extension of due dates for bid submission)
To
Tender Notice: NFDB/Division I/Mulapolam Land Development/2020-2021, Dt.
02-12-2022, Tender ID: 2022_ DADF_727090_1
After due consideration of the requests received from the prospective bidders,
the Competent Authority has approved extension of the due dates of the bid
submission for the Request for Proposal (RFP) on ‘O&M’ of Phase-1 and ‘DBFOT’
of Phase-2 of the ‘Integrated Coastal Aquaculture Facilities’ Mulapolam Village,
Srikakulam District, Andhra Pradesh in PPP Mode as following.
¢ Due date & time for receipt of bids ‘online’: 16:00 Hrs (IST) on 12-01-2023
e Due date & time for submission of hard copies of technical bids: 16:00 hrs
CST) on 17-01-2023
e Date and time of opening of technical bid: 11:00 Hrs (IST) on 18-01-2023
Date: 30.12.2022 १:४2
Place: Hyderabad ’ “०-5०
Executive Director (Tech)
National Fisheries Development Board
nfdb.gov.in 6६.७ /nfdbindia (Qj) /nfdbindia
