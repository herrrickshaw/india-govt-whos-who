---
doc_id: "dc7d76faf2000def"
source_url: "https://mohua.gov.in/static/uploads/2025/11/7814c5550cccf097b1dde2cf7e400b8b.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of Rs. 9.60 lath as part amount of 3rd installment of Central Assistance to State Govt. of Jharkhand for 01 BLC (New Construction) project under PMAY-U Mission - reg."
date: "2021-02-03"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ef7d96cd3b632876"
---

<!-- page 1 -->

https://pfms.nic. in/Sanction!TemplateAdvice.aspx?AdviceNum=jF...

PAO(Sectt.)/HUA/Admin/Advice/ 2020-21/
GOVERNMENT OF INDIA
PAO(Sectt.), M/o Housing and Urban Affairs
507-C(wing),Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664

To,
The General Manager,
Reserve Bank of India,
Central Accounts Section,
Additional Office Building,
East High Court Road,
NAGPUR - 440 001

Code No:

1707
Advice No: 492
Advice Date: 04/02/2021

Sir,
Please debit our account with Rs.9,60,000/- (Nine Lakh Sixty Thousand Only.) by contra
credit to the following accounts of the Governments with the amounts mentioned against each:

Month and Year of Accounts: February,2021
SI.No.

Name of the
State

State
Code

1

JHARKHAND

125

The Amount to be Settled: February,2021

Scheme Code

Amount

Sanction No. and Date

1989-STATE AND UT
GRANTS UNDER PMAY
(URBAN)

9,60,000

N-11012/36/2019-HFA-V-UD
(Comp. No. 9062433) dated
03/02/2021

GRAND TOTAL:

9,60,000

Signature of the authorized official

(Pawan Kumar Bhatnagar)
Senior Accounts Officer

1. 0/0 the Accountant General (A&E)-I, .Jharkhand, Ranchi-834002
h B K Mandal, US(HFA), M/o-HUA

DIISA

S

Pawan Kum Viagar
(Senior Accounts Officer)

g
Pt o
U
t

I of 1

4JJo
t*i

04-02-2021 12:08

<!-- page 2 -->

2t
N-11012/36/2019-HFA-V-UD (Comp. No. 9062433)

Government of India
Ministry of Housing & Urban Affairs
HFA-V Section
Room No. 03, Technical Cell, Gate No. 7,
Nirman Bhawan, New Delhi
Dated: 03.02.2021
To
Pay and Accounts Officer (Sectt.),
Ministry of Housing and Urban Affairs,
Nirman Bhawan, New Delhi - ii
Sub:

Release of Rs. 9.60 lath as part amount of 3rd installment of Central
Assistance to State Govt. of Jharkhand for 01 BLC (New
Construction) project under PMAY-U Mission - reg.

Sir,
I am directed to convey the sanction of the competent authority for release of
Rs. 9,60,000/- (Rupees Nine Lath and Sixty Thousand only) to State
Government of Jharkhand for 01 BLC project as part amount of 3rd installment
of Central Assistance (SC component) for Creation of Capital Assets under Pradhan
Mantri Awas Yojana - Urban (PMAY-U) Mission for the FY 2020-21.
2.
The statement showing details of the project against which the above Grant is
released towards part amount of 3rd installment of the Central Assistance is at
Annexure.

The State Govt. of Jharkhand was released funds of Rs. 397.20 lakh as ist and
3.
2nd installment of Central Assistance for 331 beneficiaries of 01 BLC (NC) projects vide
this Ministry's sanction letter No. N-11011/28/2016-HFA-III (FTS-16738) dated
29.10.2016, letters of even number dated 26.03.2019 and 25.09.2019.
In compliance to the conditions for release of 3 r and final installment of
4.
Central Assistance for 01 BLC (NC) projects, the following have been furnished by the
Govt. of Jharkhand:
i.

UC of Rs. 342.00 lakh against the total Central Assistance of Rs. 397.20 lakh
released for the Pakur ULB approved in 21 CSMC meeting under PMAY-U
Mission.
ii. Physical progress report as per Enclosure to Annexure 8 of the Mission
guidelines
in. ATR on TPQMA Report
iv. Completion certificate as per Annexure 9 of the Mission guidelines.
V.
Status of 6 mandatory reforms under PMAY-Mission, which is in conformity
with Annexure A attached with MoA.
vi. Compliance report on Desk and Site scrutiny conducted by HUDCO for the said
projects.
vii. Photographs of the completed houses.
The State has furnished physical progress report and Third Party Quality
5.
Monitoring (TPQM) report along with Action Taken Report (ATR). The TPQMA has
found quality of work to be satisfactory and the compliances on the recommendations
of TPQMA have also been made by the State as per ATR.
Contd...P.2/

<!-- page 3 -->

-2-

-

6. Based on decision of CSMC under Pradhan Mantri Awas Yojana (PMAY) Housing for All (Urban) Mission in its 21 meeting held on 24.04.2017, the amount of
central grant is being released subject to the following conditions:
L The funds shall be utilized for the purpose and within the selected categorized
beneficiaries, for which these are given. Otherwise these will have to be refunded
along with interest as per provisions under GFR 2017.
ii. The expenditure on the implementation of the scheme/projects will be shared
between the Central and the State/ ULB/ Implementing Agency (IA) as
committed. The committed State share should also be released within 15 days
from the date of receipt of Central Assistance in the SLNA account. In case of
shortfall of State/ULB/IA share, corresponding amount of Central share will be
deducted from the subsequent releases for the projects.
iii. The funds including Central Assistance and State share will thereafter be released
by the State/UT Government to the implementing agencies without any delay
failing which the amount would be recovered from the State/UT Government
with interest, as applicable, for the period of default.
iv. Necessary sanctions/approvals/compliances required under the statutory or
other regulatory regime as applicable would be obtained by the authority(ies)
concerned with the project(s).
v. The State Government and implementing agency shall put in place a monitoring
system to ensure that the project(s) achieve scheduled milestone and envisaged
outcomes including implementation of reforms and other conditionalities
required under the scheme.
The
State Government shall utilize the grant in accordance with the approved
vi.
guidelines for the implementation of the Scheme of PMAY-U Mission.
vii. The State Government shall furnish the Utilization certificates of the Grant
released in the prescribed format as per GFR 2017 as provided in the scheme
guidelines.
viii. Where there is an element of cash transfer to individual beneficiaries, the same
may be made through DBT/EAT module of PFMS as applicable. The State
Government shall submit an authenticated certificate from the bank showing
complete details of disbursement of funds to each beneficiary before further
releases for the projects.
ix. The State Government shall ensure the geo-tagging of all houses approved under
BLC component of PMAY-IJ Mission.
x. The State Government shall be required to certify that the specifications of the
houses conform to NBC/IS Standards and that requisite infrastructure for the
projects are provided by the State Government/ULB.
xi. The State Government shall ensure quality monitoring of the said projects by
Third Party Quality Monitoring Agency (TPQMA) in 2-3 visits and submit the
Action Taken Report (ATR) on the observations/recommendations of TPQMA
before release of balance amount of 3rd and final installment of Central
Assistance.
xii. The balance amount of 3rd and final installment of Central Assistance will be
released contingent of achieving all mandatory reforms, completion of projects
including construction of houses and infrastructure in each project and
submission of project completion reports for all approved projects as per
Annexure 9 of the Mission Guidelines.
xiii. The State should ensure that Model Code of Conduct is not violated while
releasing funds to Implementing Agencies/ULBs/Beneficiaries.
contd ... P.3/

_

<!-- page 4 -->

-

3-

Additional allocation through 2nd Supplementary Demand for Grants 2020-21 for
7.
PMAY-U is yet to be received. Therefore, in pursuance to DEA O.M. No. 7/41/2019BA(Pt.I) dated 06.01.2021 conveying authorization for incurring excess expenditure of
Rs. 6,000.00 crore over and above BE allocation for PMAY-U by invoking Appendix-lo
under Rule 61 and 69 of GFR 2017, the expenditure involved will be debited from
head 3601.06.502.01.02.35 (SC component) under Demand No. 57 of Ministry of
Housing and Urban Affairs for the year 2020-21 and will be transferred to the following
head of accounts on regularization after receiving the 2nd SDG 2020-21:
Major Head:
Sub-Major Head
Minor Head
Sub Head
Detailed Head
Object Head

3601
o6
789

17
01
1 7- 01-35

Grants-in-aid to State Governments
Centrally Sponsored Schemes
SC Component
Pradhan Mantri Awas Yojana (Urban)
assistance to State Governments for
PMAY(U)
Grants for Creation of Capital Assets

The amount will be credited to the State Government's Account at Reserve Bank
8.
of India, CAS, Nagpur as per procedure laid down by Ministry of Finance, Department
of Expenditure in this regard.
Requisite UCs of jst and 2nd installment of Central Assistance have been received
9.
from State Govt. and are enclosed herewith.
As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee
10.
Institution(s)/Organisation(s) shall be open to inspection by the sanctioning authority
and audit, both by the Comptroller and Auditor General of India under the provision of
CAG (DPC) Act 1971 and internal audit by the Principal Accounts Office of the Ministry
or Department, whenever the Institution or Organisation is called upon to do so.
This issues with the concurrence of the Finance Division vide their Note No. 78
ii.
(E: 9062433) dated 11.09.2020.
12.
This sanction has been registered at S. No.140in the Sanction Register of HFA
Mission Directorate of the Ministry of HUA for the year 2020-21.
Yours faithfully,
(B.l1)
Under Secretary to the Government of India
Tel. 011-23063285
End.; As above.
Copy to:

1. Secretary, Urban Development & Housing Deptt., State Government of
Jharkhand, Ranchi
2. Accountant General (A&E), Jharkhand
3. CCA, MoHUA
4. Director (IFD), MoHUA
5. Director (HFA-3), MoHUA.
6. Deputy Secretary (Budget), MoHUA
Contd ... P.4/

<!-- page 5 -->

7 NITI Aayog, SP Divn./DR Dix-n., New Delhi
0/0 CGA, Mahalekha Niyantrak Bhavan, New Delhi.
Dy. Chief (MIS/DRMC), HFA Directorate to place this sanction at appropriate
place on the Website of the Ministry.
10 PMU (MIS), HFA Directorate
11 A0 (HFA), MoHUA
12 Sanction folder
13 File Copy

(B.K. Mandal)
Under Secretary to the Government of India

<!-- page 6 -->

g
N

-

z
C

N

z

5

=

N

e_

•

C c

E

c

-

N

C

CC

C

C

I
C

C

N

V
N

z

-

<!-- page 7 -->

129689/209IHFA-V SECTION

Form GFR 19- A
Scc Rule 2123 I)J
Form of L'liliialion Cer1iticite

Ceriilied timt ont of Rs.122$.40/- (Ont hundred twenty *'o erorv fifty eight hikli fiturty thousand
only) Gmnis-in-aid sanctioned duiinu the year 2017-18 in favor of Urban Development & housing
Development, Govt. of Tharkhand under this Ministry/Department Letter no. given in the table below, a
sum of Rs.12258.40/- (One hundred fwcnl

two erore fifty eight Iakh fourty thousand only) has

been utilized for the purpose of Beneficiary Led Construction under Pradhan Mantri Awas Yojna
(PMAY) for which it was sanctioned and that the balancc of 1{s NIL remaining utilized at the end of
the year.

Sr. No.

Letter No. and Dale

Amount (in l.h)

A.

N-Il Oh l/28f20l6-l1F/-ttI(('N-306738)Datcd:-04.05.2017

12059.40

B.

N-1 101 1128/2016-1-IFA-I1I(CN-3016738)Dated:-3 1.05.2017

199.00

C.

Amount Received (A+B)

12258.00

D.

Expenditure

12258.00

Balance Amoutit (C-D)

2. Certified that I have satisfied myself that the conditions on which the grant-in-aid was sanctioned
have been duly fulfilled/ are being fulfilled and that I have exercised the following checks to see that

the money was actually utilized for the PUPOSC for which it was sanctioned.
3. Physical progress of the projects, where Government of India grants have been utilized, is enclosed.
Kind of Check exercised:
I. ULI3s wise tiC details kept in file

run Kumar Singh)
Principal Secretary to Govt.

<!-- page 8 -->

501
/

15

UC for F.V. (201920)
(VR 1-('

(Rule 239)
Govt. Of Jliarkhaiad
Form Utilization Certificate For the year 2019-2020
No.

Lefler No. and Date

Amount

(In lakhs)

Certified Mat

out of Rs.

143.40 LaIdis

of grants

sanctioned during the year 2018-19 in favour of Urban

1. central fund released
during
2018-19

Development &

year

the

Housing

Department

.

Govt. Of

Jharkhand under the Ministry/ Department Letter no.
given in the margin and Rs. 143.40 Lakhs on account of

( * As per details given
below)

unspent balance of the previous year, a sum of Rs.

143.400

8.1 1012/36/2019-

HFA-V-UD

143.40 Lakhs has been utilized for the propose of
PMAY(U)- Vertical IV for which it was sanctioned and

(Comp,No.-9062433)
/26.03.19

that the balance of Rs. 0.00 Lakhs remaining unutilized
of the end of the year has been surrendered to

2.

Government (vide No..

Total Fund Received -

143.40

3

Fund utilized
31.08.2019

143.40

4.

Total Unspent Balance
( Row 2-3)

2.

:

upto

dated ..)/ will be adjusted

towards thtgrants payable during the year.

0.00

Certified that 1 have satistied myself that the conditions on which the grants-in-aid
was sanctioned have been duly fulfilled/ are being fulfilled and that I have exercised
the followings checks to see that the money was actually utilized for the propose for
which it was sanctioned.

Kinds of Check exercised
1. Cash Book
2. Pass Book
3. Utilization Certificate w.r.t ULBs
4. Sanction Letters w.r.t ULBs
5. Annexure-8 of PMAY Guidelines

Signature..

J~

.................

Designation.. .Director

ck....
Designation.. .Secretary
Date:... P!Ii?.............
