---
doc_id: "dbbb72b070d0d1bb"
source_url: "https://www.dst.gov.in/static/uploads/2025/11/c39ae9b6f7ed3bc66cba5e92d545bce4.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Science policymakers stress the need for attracting youth towards science and cultivating innovative spirit"
date: "2020-12-27"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3bc7978cbef7fe45"
---

<!-- page 1 -->

Ministry of Science and Technology
Department of Science & Technology

Science policymakers stress the need for attracting youth towards
science and cultivating innovative spirit

Science policymakers underscored the importance of attracting youth towards science and
cultivating an innovative spirit from a very young age to develop scientific temper at a discussion
on DD news. “The biggest challenge is to attract youth into science from an early age for optimal
use of India’s talent for the progress of the country,” Director General, CSIR Dr. Shekhar C Mande
said while appearing on a DD News programme to discuss the role of science, technology and
innovation and the way forward.The discussion was organized after Prime Minister Narendra
Modi’s address on using science, technology, and innovation for the progress and development of
the country at the inauguration of the sixth edition of India International Science Festival (IISF
2020).“We have a rich tradition of science and technology in the country. Our achievements in
this field are unprecedented, and it has played a crucial role to take us to where we are today,” Dr.
Mande said at the discussions. He emphasised that event-based teaching and learning promoted
in the New Education Policy would help attract young minds into science and technology and
develop scientific temper. “We need to spread science and technology in local languages attract a
large number of people and provide the population in the villages with equal opportunities to
participate in science, technology, and innovation,” he added.
“We do not lack talent, and COVID-19 is a big example of how we escalated efforts to start
producing various medical equipment and even went on to export them. Scientists in the country

<!-- page 2 -->

have all the potential, talent, and skill to realise the Prime Minister’s dream of Aatmanirbhar
Bharat,” Dr. Mande stressed.Adviser, Department of Science and Technology (DST) and head,
PCPM, Dr. Akhilesh Gupta, explained that starting innovation early would help in developing
scientific temper and quality research. “Education starts early, but innovation starts very late. This
needs to change,” Dr. Gupta said.
Dr. Gupta hoped that the Science, Technology, and Innovation Policy (STIP 2020) would help
retaining quality Ph.D. researchers in the country to work for the progress and development of the
country. He also spoke about the need to convert brain drain to brain gain by utilizing the expertise
of the diaspora and their eagerness to contribute to the country.Dr. Gupta explained how science
is being used as an enabling tool by people in villages and remote areas. “The ultimate goal is to
make science people-centric and use it as a key driver for economic and human development,” he
pointed out while citing an example under a new proposed scheme, where wifi would be made
available to villages.He also underlined the need for excellence at an individual and institutional
level while elaborating about the progress and development of India in the field of science,
technology, and innovation.
“We are at the third position in the world both in the field of scientific publications as well as in
startups. We are producing 25,000 Ph.Ds in science and are not very far behind from the US and
China. In college research, we were at 13th position in 2013, but today we are at 9th position,” he
said.Shri Jayant Sahasrabudhe, National Organising Secretary, Vijnana Bharati, also participated
in the discussion underlined the importance of science in being self-reliant.

Follow us on social media:
IndiaDST /

IndiaDST

IndiaDST /

IndiaDST /

IndiaDST /

IndiaDST /
