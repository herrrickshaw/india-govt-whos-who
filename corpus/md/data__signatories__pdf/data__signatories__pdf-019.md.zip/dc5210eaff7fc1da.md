---
doc_id: "dc5210eaff7fc1da"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/a79dfe8b7b3d3d2fe4ab010c055ed47a.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 442 of 2026 in the Hon’ble High Court of Delhi: DoT instructions dated 11.05.2026 to ISPs"
date: "2026-05-11"
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "98dba5bf9d9d15f5"
---

<!-- page 1 -->

4-10/2025-DGT/4(Part-II)

I/3396972/2026

By Email/ DoT Website
File No.: 4-10/2025-DGT/4(Part-II)
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
nd
2 Floor, UIDAI HQ, New Delhi -110001
Date:

-05-2026

To
All Licensees with Internet Service Authorization
Subject: CS (COMM) 442 of 2025: Warner Bros. Entertainment Inc. & Ors. vs.
bolly4u.tr and Ors. in the High Court of Delhi.
Please find enclosed the Hon’ble High Court of Delhi order dated 24.04.2026
in the captioned case.
2.
Please refer to para 3 of the said Court order received from the plaintiff’s
counsel regarding blocking access to the website(s)/domain(s) [6 numbers] as listed in
the enclosed list.
3.
In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access to
the said website(s)/domain(s), as per the enclosed list, in compliance with the said
court orders.
Encl: A/A

ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court order/
enclosed Annexure pl.
ii.)
Mr. Affan Moin (affan@saikrishnaassociates.com) Plaintiﬀ's Counsel- For kind
information and with a request to take action as per the enclosed Annexure pl.

<!-- page 2 -->

4-10/2025-DGT/4(Part-II)

I/3396972/2026

CS(COMM) No. 442 of 2025:
Website(s)/domain(s)

SCHEDULE - A
URL
of
New
Mirror/Redirect/Alphanu meric
Variations
of Injuncted
Website

IP Addresses
Alphanumeric
172.67.213.243

https://new.katmoviehd.cymru
104.21.23.218
172.67.213.243
https://katmoviehd.cymr u
104.21.23.218
https://animepahe.si

1,85,17,82,08,138
172.67.199.116

https://sd1.sdmoviespoint.courses
104.21.76.192
104.21.33.223
https://sdmoviespoint.garden
172.67.151.21
172.67.142.158
https://sdmoviespoint.gdn
104.21.27.132

of New Mirror/Redirect/
Variation of Injuncted Website

<!-- page 3 -->

Fwd: Compliance with the Order of the Hon'ble High Court of
adt.hqDelhi dated 24th April 2026 read with the Order dated 09th
dgt< adt.hq-dgt-dot@gov.in >
May 2025 in Warner Bros. Entertainment Inc. & Ors. vs.
dot
bolly4u.tr and Ors. [CS(COMM) 442/2025]

Cyber Law Legal < cyberlaw-legal@meity.gov.in >
Mon, 04 May 2026 10:35:01 AM +0530

To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Manish Shukla"<dirit.hqdgt-dot@gov.in>,"Kripa Shanker Pandey"<adt.hq-dgt-dot@gov.in>
Cc "Deepak Goel"<gccyberlaw@meity.gov.in>,"Sathyanarayanan Subramanian"
<sathya.s@meity.gov.in>,"Avneet Toor Gupta"<avneett.g@nic.in>,"Nagarajan N"
<nagarajan.n@meity.gov.in>,"Shri Prem Chand Sharma"<ddgit.hq-dgtdot@gov.in>

Dear Sir,
Request your attention to the trailing email as under. Would appreciate, if you could review it and
take necessary action, as required.
Kindly, inform us once the needful has been done.
Thanks and Regards
Nagarajan. N
Scientist C
Cyberlaw Division
Ministry of Electronics and Information Technology (MeitY)
Tel: 9310759547

============ Forwarded message ============
From: Affan Moin <affan@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Manish Shukla"<dirit.hq-dgt-dot@gov.in>, "Kripa Shanker Pandey"
<adt.hq-dgt-dot@gov.in>, <adetds2-dot@gov.in>, <ada2.dl-dgt-dot@gov.in>, "Kripa
Pandey"<cscsolan33@gmail.com>, <cyberlaw-legal@meity.gov.in>,
<gccyberlaw@meity.gov.in>
Cc: "Raghav Goyal"<raghav@saikrishnaassociates.com>, "Mehr Sidhu"
<mehr@saikrishnaassociates.com>
Date: Fri, 01 May 2026 10:02:00 +0530
Subject: Compliance with the Order of the Hon'ble High Court of Delhi dated 24th April
2026 read with the Order dated 09th May 2025 in Warner Bros. Entertainment Inc. & Ors.
vs. bolly4u.tr and Ors. [CS(COMM) 442/2025]
============ Forwarded message ============

WITHOUT PREJUDICE
By E-mail

<!-- page 4 -->

Date: May 01, 2026
Dear Ma’am/Sir,
We act on behalf of:
(i) Warner Bros. Entertainment Inc., having its office at 4000 Warner
Boulevard, Burbank, California 91522, United States of America;
(ii) Netflix Studios, LLC, having its office at 100 Winchester Cir Los
Gatos, CA, 95032-1815 United States of America;
(iii)
Disney Enterprises, Inc., having its office at 500 S. Buena Vista,
Burbank, California 91521, United States of America;
(iv) Apple Video Programming LLC having its office at 8600 Hayden
Place, Culver City, California 90232, United States of America and;
(v) Crunchyroll LLC having office at 5750 Wilshire Blvd, Los Angeles,
California, 90036, United States of America, hereinafter referred to as ("Our
Clients").
We are under instructions from Our Clients to address you as under:
1. Our Clients are the authors and/or first owners and/or owners and/or distributors of
cinematograph films/television shows ("Original Content"). Our Clients instituted a Suit
against various infringing websites before the Hon'ble High Court of Delhi, inter alia, for
permanent injunction restraining violation of Plaintiffs' copyrights in relation to the Original
Content as well as for other reliefs. Our Clients also impleaded various internet and telecom
service providers, domain name registrars as well as the concerned Government
Departments (Department of Telecommunication and the Ministry of Electronics and
Information Technology), as Defendants, to ensure effective compliance of any order that the
Hon'ble Delhi High Court was inclined to pass.
2. The above-mentioned matter came up for consideration before Hon'ble Mr. Justice
Amit Bansal, of High Court of Delhi on 9th May 2025 and the Hon'ble Judge was pleased to
pass an ex-parte ad-interim order in favour of the Plaintiffs. The relevant portion of the order
dated 9th May 2025 is extracted below:
"37. Consequently, defendants no. 1 to 23 and as mentioned in Annexure
A (and any such other mirror / redirect / alphanumeric website which appears to
be associated with any of the defendant websites either based on its name,
branding or the identity of its operator, or source of the content or discovered to
provide additional means of accessing, defendant websites, and other domains
/domain along with their subdomains and subdirectories, owners / website
operators / entities which are discovered to have been engaging in infringing the
Plaintiffs' exclusive rights), its owners, partners, proprietors, officers, servants,
employees, and all others in capacity of principal or agent acting for and on their
behalf, or anyone claiming through, by or under it, are restrained from hosting,
streaming, reproducing, distributing, making available to the public and / or
communicating to the public, or facilitating the same, on their websites, through
the internet in any manner whatsoever, any cinematograph work / content /
program / show in relation to which plaintiffs have copyright and / or exclusive
distribution rights.
38. Defendants no. 24 to 35 (DNRs) and other DNRs, their directors,
partners, proprietors, officers, affiliates, servants, employees, and all others in
capacity of principal or agent acting for and on their behalf, or anyone claiming
through, by or under it, are directed to lock and suspend and provide details
relating to the registrant of the defendants no. 1 to 23 (and any such other mirror
/ redirect / alphanumeric website which appears to be associated with any of the

<!-- page 5 -->

defendants no. 1 to 23 either based on its name, branding, the identity of its
operator, or the source of the content or discovered to provide additional means
of accessing the defendants no. 1 to 23, and other domains / domain along with
their subdomains and subdirectories, owners / website operators / entities which
are discovered to have been engaging in infringing the plaintiffs' exclusive
rights), as mentioned in Annexure B, including KYC, credit card, mobile number
etc., to the plaintiffs, within 72 hours of being communicated with a copy of this
order.
39. Defendants no. 36 to 44 (ISPs), their directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of principal or
agent acting for and on their behalf, or anyone claiming through, by or under it,
are directed to block access to the defendants no. 1 to 23 websites identified by
the plaintiffs in the instant suit and as mentioned in Annexure A (and any such
other mirror / redirect / alphanumeric website which appears to be associated
with defendants no. 1 to 23 either based on its name, branding or the identity of
its operator, or the source of the content or discovered to provide additional
means of accessing, the defendants no. 1 to 23, and other domains/domain along
with their subdomains and subdirectories, owners / website operators / entities
which are discovered to have been engaging in infringing the Plaintiffs' exclusive
rights), within 72 hours of being communicated with a copy of this order.
40. Defendants no. 45 and 46 (DoT and MEITY), are directed to issue a
notification calling upon the various internet and telecom service providers
registered under it to block access to the defendants no. 1 to 23 websites
identified by the plaintiffs in the instant suit and as mentioned in Annexure A (and
any such other mirror / redirect / alphanumeric website which appears to be
associated with any of the defendants no. 1 to 23 either based on its name,
branding or the identity of its operator, or the source of the content or discovered
to provide additional means of accessing, the defendants no. 1 to 23, and other
domains/domain along with their subdomains and subdirectories, owners/website
operators/entities which are discovered to have been engaging in infringing the
Plaintiffs' exclusive rights), within 72 hours of being communicated with a copy
of this order."
A copy of the Order dated 9th May 2025 is available at the drive link attached
herewith.
3. In view of the interim injunction order dated 9th May 2025 Our Clients had filed an
Impleadment Application against the below mentioned website, for impleading it as
Defendant Nos. 58 to 63, in the said suit:
Proposed
Defendant
No.

58
59
60
61
62
63

Mirror/redirect/alpha numeric domain Corresponding
name of the Proposed Defendant
Original Defendants
which were blocked
vide ex-parte interim
injunction order dated
09.05.2025
new.katmoviehd.cymru
pikahd.com
katmoviehd.rodeo
katmoviehd.cymru
(Defendant No. 2)
animepahe.si
animepahe.ru
(Defendant No. 22)
sd1.sdmoviespoint.courses
sdmoviespoint.voto
dmoviespoint.meme
sdmoviespoint.gardens
sdmoviespoint.my
sdmoviespoint.gdn
(Defendant No. 23)

<!-- page 6 -->

4. The Hon'ble High Court of Delhi vide Order dated 24th April 2026, was pleased to
implead the above-mentioned Defendants and has extended the reliefs granted vide order
dated 9th May 2025 against the said Defendants. The relevant portion of the Order dated
24th April 2026 is extracted hereinbelow.
“3. The order blocking the rogue-websites passed by the Hon’ble Court
on 09.05.2025 shall operate qua the freshly impleaded defendant as well which
stand injuncted, in terms of directions contained in paragraph 37 & 41 of the
order dated 09.05.2025. Further, defendant ISP’s shall give effect to the
injunction by blocking defendant nos. 58 to 63. Also, Department of
Telecommunications and Ministry of Electronics and Information Technology
shall issue blocking orders against defendant nos. 58 to 63 within a period of one
week. The concerned DNR’s of the newly impleaded defendants shall lock and
suspend the domain names, and also supply necessary details of the domain name
registrant / KYC etc to the plaintiffs. A copy of this order be served on the ISP’s,
DoT & MEITY and the concerned DNR/s within four weeks. Compliance of Order
39 Rule 3 CPC be done within a week. IA is allowed and disposed off
accordingly.”
5.

Accordingly, we request you, DoT & MeitY (Defendant Nos. 45 & 46) to comply

with the order of the Hon'ble High Court of Delhi dated 24th April 2026, by issuing a
notification calling upon the various internet and telecom service providers registered under
you to block access to the said websites i.e., Defendant Nos. 58 to 63 identified in attached
Annexure-A.
6. A copy of the injunction order dated 9th May 2025 and Order dated 24th April 2026
along with a copy of the Impleadment Application and Documents as filed before the
Hon'ble High Court of Delhi are being made available through the following link:
https://drive.google.com/drive/folders/1RWFWU8bCtTVg9EsPjMWIcBT8I_7kiIpa?
usp=drive_link
7. For your reference, the next date of hearing in the matter is 04th May 2026 before the
Court. In view of the above facts and circumstances, we request you to comply with the
Order of the Hon'ble High Court of Delhi dated 24th April 2026.
If you have any queries, please feel free to contact us.
Sincerely,
Affan Moin
Saikrishna & Associates
Counsels for Plaintiffs
Enclosed:
1. Impleadment Application
2. Documents
3. Order dated 9th May 2025
4. Order dated 24th April 2026
5. Annexure-A in Excel Sheet format
6. Annexure-A in PDF format
CC:

<!-- page 7 -->

1. Department of Telecommunications
Through Secretary, Ministry of Communications and IT,
20, Sanchar Bhawan, Ashoka Road,
New Delhi – 110001
Email Id:
secy-dot@nic.in
dirit.hq-dgt-dot@gov.in
adt.hq-dgt-dot@gov.in
adetds2-dot@gov.in
ada2.dl-dgt-dot@gov.in
cscsolan33@gmail.com
2. Ministry of Electronics and Information Technology
Through the Director General (DIT) Cyber Laws & e-security,
Electronics Niketan, 6, CGO Complex,
Lodi Road, New Delhi – 110003
Email Id:
cyberlaw-legal@meity.gov.in
gccyberlaw@meity.gov.in

Affan Moin | Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003 | Fax: +91-1204633999 | Handphone: +91-9305598112 | Enrollment Number- D/11429/2025

• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious

The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege,
not being waived or lost by mistaken transmission or receipt. If you have received this mail in
error, please notify us at info@saikrishnaassociates.com immediately by reply email and
destroy the original - any use, disclosure or copying of this mail is unauthorised.

3 Attachment(s)
Schedule A .xlsx

Schedule A.pdf

13.1 KB

64.7 KB

Order dated 24.04.2026 (bolly…
121.8 KB

<!-- page 8 -->

$~32
*
IN THE HIGH COURT OF DELHI AT NEW
DELHI
+
CS(COMM) 442/2025
WARNER BROS ENTERTAINMENT INC & ORS.
.....Plaintiff
Through: Ms. Mehr Sidhu, Mr. Aditya
Singh Thakur and Mr. Affan
Moin, Advs.

versus
BOLLY4U.TR & ORS.
.....Defendant
Through:

None.

CORAM:
JOINT REGISTRAR (JUDICIAL) MS. SWATI KATIYAR
ORDER
%
24.04.2026
Fresh IA No. 11461/2026 on behalf of plaintiffs under Order I
Rule 10 of the Code of Civil Procedure, 1908 seeking
impleadment of additional mirrors, redirects, or alphanumeric
variations as defendant nos. 58-63.
1.

The

plaintiffs

is

seeking

to

implead

additional

rogue-websites as defendant nos. 58 to 63 because they have been
found to be indulging in illegally disseminating the copyrighted
material belonging to the plaintiff. Keeping in view the contents of
the suit and the application, the same is allowed. The proposed
defendants are impleaded as defendant nos. 58 to 63.

Issue

summons to the newly impleaded defendants.
2.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve the newly impleaded defendant
with summons within 2 weeks through the electronic mode only,
on filing of PF.
3.

The order blocking the rogue-websites passed by the

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/04/2026 at 16:04:54

<!-- page 9 -->

Hon’ble Court on 09.05.2025 shall operate qua the freshly
impleaded defendant as well which stand injuncted, in terms of
directions contained in paragraph 37 & 41 of the order dated
09.05.2025. Further, defendant ISP’s shall give effect to the
injunction by blocking defendant nos. 58 to 63. Also, Department
of

Telecommunications

and

Ministry

of

Electronics

and

Information Technology shall issue blocking orders against
defendant nos. 58 to 63 within a period of one week. The
concerned DNR’s of the newly impleaded defendants shall lock
and suspend the domain names, and also supply necessary details
of the domain name registrant / KYC etc to the plaintiffs. A copy
of this order be served on the ISP’s, DoT & MEITY and the
concerned DNR/s within four weeks. Compliance of Order 39 Rule
3 CPC be done within a week. IA is allowed and disposed off
accordingly.
MS. SWATI KATIYAR,
JOINT REGISTRAR (JUDICIAL)
APRIL 24, 2026/bk

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/04/2026 at 16:04:54

<!-- page 10 -->

SCHEDULE – A
Injuncted Website Location
(at the time of suit as well as
additionally
impleaded
websites)
bolly4u.tr
bolly4u.vc
vegamovies4u.ac
vegamovies4u.bz
vegamovies4u.com.by
vegamovies4u.in
vegamovies4u.io
vegamovies4u.me
pikahd.com
katmoviehd.rodeo
037HdMovie.com
037Hd.tv
Movieverse.one
streamblasters.pm
coolsanime.net
coolsanime.me
hdmania.live
hdmania.org
hdmania.mobi
andyday.tv
tvshows4mobile.org
tvshows4mobile.com
animesugetv.to
donkey.to
anikoto.to
broflix.ci
broflix.cc
nunflix.org
popcornmovies.to
gojo.wtf
wooflix.tv
booflix.to
wcostream.tv
cinevez.foo

Domain Name of
Mirror/Redirect
/Alphanumeric
Variation
of
Injuncted Website
new.katmoviehd.cy
mru
katmoviehd.cymru
animepahe.si
sd1.sdmoviespoint.
courses

URL
of
New
Mirror/Redirect/Alphanu
meric Variations of
Injuncted Website

IP Addresses of New
Mirror/Redirect/
Alphanumeric Variation
of Injuncted Website

https://new.katmoviehd.
cymru

172.67.213.243
104.21.23.218
https://katmoviehd.cymr
172.67.213.243
u
104.21.23.218
https://animepahe.si
185.178.208.138
https://sd1.sdmoviespoint.cou 172.67.199.116
rses
104.21.76.192

sdmoviespoint.gard
en

https://sdmoviespoint.garden

sdmoviespoint.gdn

https://sdmoviespoint.gdn

104.21.33.223
172.67.151.21
172.67.142.158
104.21.27.132

<!-- page 11 -->

cinevez.io
cinevez.dev
awafim.tv
animez.org
animepahe.ru
sdmoviespoint.voto
sdmoviespoint.meme
sdmoviespoint.my
andydayss.lol
andyday.tube
andydayz.lol
andydayzz.lol
nunflix.li
fullhdmovies.me
wooflixtv.co
animetsu.to
gojo.live

<!-- page 12 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
