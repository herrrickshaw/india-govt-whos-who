---
doc_id: "de2d60aba3b6dfbb"
source_url: "https://www.labour.gov.in/static/uploads/2026/05/9262ddc2c90cfc0e926a1e3d26c5133d.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Notification regarding appointment of Chief Inspector and Inspector Cum Facilitator in case of major ports under the OSH and WC Code 2020"
date: "2026-05-13"
pages: 4
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "6ee8dfa6365cfb57"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-18052026-272654
xxxGIDHxxx
CG-DL-E-18052026-272654
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 2393]
No. 2393]

नई दिल्ली, बुधवार, मई 13, 2026/वैिाख 23, 1948
NEW DELHI, WEDNESDAY, MAY 13, 2026/VAISAKHA 23, 1948

श्रम एवं रोज़गार मंत्रालय
अजधसूचना
नई दिल्ली, 13 मई, 2026
का.आ. 2485(अ).—के न्‍दरीय सरकार, उपिीजवका िन्‍दय सुरक्षा, स्ट्वास्ट््य और कायय ििाएं संजिता, 2020 (2020
का 37) की धारा 34 की उपधारा (1) और (5) द्वारा प्रित्त िजियों का प्रयोग करते हुए और भारत के रािपत्र, असाधारण
भाग-2 खंड-3 उपखंड (ii), तारीख 12 जसतम्बर, 2015 द्वारा प्रकाजित भारत सरकार के श्रम एवं रोिगार मंत्रालय की
अजधसूचना संख्या 2476 (अ), तारीख 9 जसतम्बर, 2015 को उन बातों के जसवाय अजधक्ांत करते हुए, जिन्‍दिें ऐसे अजधक्मण
से पूवय दकया गया िै या करने का लोप दकया गया िै, नीचे िी गई सारणी के स्ट्तंभ (2) में जवजनर्ियष्ट अजधकाररयों को, उि
सारणी के स्ट्तंभ (4) में तत्‍स्ट्थानी प्रजवजष्टयों में जवजनर्ियष्ट पत्‍तनों की स्ट्थानीय सीमाओं के भीतर उक्त संजिता के प्रयोिनों के
जलए क्मि: मुख्य जनरीक्षक-सि-सुजवधाप्रिाता और जनरीक्षक-सि-डॉक सुरक्षा सुजवधाप्रिाता के रूप में अजधसूजचत करती िै।
सारणी
क्.सं.
(1)
1.

अजधकारी
(2)
मिाजनिेिक,
कारखाना सलाि सेवा
मिाजनिेिालय, मुंबई।

3465 GI/2026

एवं

पिनाम
(3)
श्रम

संस्ट्थान मुख्य
जनरीक्षक-सिसुजवधाप्रिाता

(1)

पत्‍तनों की सीमाएँ
(4)
सभी प्रमुख पत्‍तन।

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

2.

3.

4.

5.

6.

7.

8.

9.

10.

11.

12.

13

उप मिाजनिेिक,
जनिेिक (सुरक्षा) और उप जनिेिक (सुरक्षा),
डॉक सुरक्षा प्रभाग,
कारखाना सलाि सेवा एवं श्रम संस्ट्थान
मिाजनिेिालय, मुंबई।
उप जनिेिक (सुरक्षा,
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा, मुंबई
उप जनिेिक (सुरक्षा),
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा,
कोलकाता
उप जनिेिक (सुरक्षा),
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा, चेन्नई
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा, नवी
मुंबई.
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा,
मोरमुगाओ.
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा,
कांडला।
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा,
जविाखापट्टनम ।
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा,
पारािीप।
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा,
तूतीकोररन।
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा, न्‍दयू
मैंगलोर।
सिायक जनिेिक (सुरक्षा) और अपर सिायक
जनिेिक (सुरक्षा), जनरीक्षणालय डॉक सुरक्षा,
कोजि।

[PART II—SEC. 3(ii)]

जनरीक्षक-सिसुजवधाप्रिाता

सभी प्रमुख पत्‍तन।

जनरीक्षक-सिसुजवधाप्रिाता
जनरीक्षक-सिसुजवधाप्रिाता

मुंबई, िवािरलाल नेिरू
पत्‍तन , कांडला और
मोरमुगाओ।
कोलकाता, िजल्िया, पारािीप
और जविाखापट्टनम ।

जनरीक्षक-सिसुजवधाप्रिाता

चेन्नई,
तूतीकोररन,
न्‍दयू
मैंगलोर, कोजि और एन्नोर।

जनरीक्षक-सिसुजवधाप्रिाता

िवािरलाल नेिरू पत्‍तन ।

जनरीक्षक-सिसुजवधाप्रिाता

मोरमुगाओ।

जनरीक्षक-सिसुजवधाप्रिाता

कांडला।

जनरीक्षक-सिसुजवधाप्रिाता

जविाखापट्टनम।

जनरीक्षक-सिसुजवधाप्रिाता

पारािीप।

जनरीक्षक-सिसुजवधाप्रिाता

तूतीकोररन।

जनरीक्षक-सिसुजवधाप्रिाता

न्‍दयू मैंगलोर।

जनरीक्षक-सिसुजवधाप्रिाता

कोजि।

[फा.सं.एस 65025/10/2026-आईएसएच-II]
आलोक चंर, वररष्ठ श्रम और रोिगार सलािकार

MINISTRY OF LABOUR AND EMPLOYMENT
NOTIFICATION
New Delhi, the 13th May, 2026
S.O. 2485(E).—In exercise of the powers conferred by sub-sections (5) and (1) of Section 34 of the Occupational
Safety, Heath and Working Conditions Code, 2020 (37 of 2020) and in supersession of the notification of Government
of India in the Ministry of Labour and Employment vide S.O. 2476(E), dated the 09th September, 2015, published in the
Gazette of India, extraordinary, Part-II, Section 3, sub-section (ii), dated the 12th September, 2015, except as respects

<!-- page 3 -->

[भाग II—खण्ड 3(ii)]

3

भारत का रािपत्र : असाधारण

things done or omitted to be done before such suppression, the Central Government hereby notifies the officers specified
in column (2) of the Table below to be the Chief Inspector –cum- Facilitator and Inspector –cum- Facilitator of Dock
Safety respectively for the purposes of the said Code, within the local limits of the ports specified in the corresponding
entries in column (4) of the said Table.

TABLE
S.No.

Officers

Designations

Limit of ports

(1)

(2)

(3)

(4)

Directorate General Factory Advice Service and

Chief Inspector-cum-

Labour Institutes, Mumbai.

facilitator

Deputy Directorate General,

Inspector-cum-

Director (Safety) and Deputy Director(Safety),

facilitator

1.

2.

Director General,

All major ports.

All major ports.

Dock Safety Division,
Directorate General Factory Advice Service and
Labour Institutes, Mumbai.
3.

Deputy Director (Safety,

Inspector-cum-

Mumbai, Jawaharlal Nehru

Assistant Director (Safety) and Additional

facilitator

Port, Kandla and Mormugao.

Deputy Director(Safety),

Inspector-cum-

Kolkata, Haldia, Paradip and

Assistant Director (Safety) and Additional

facilitator

Vishakapatnam.

Deputy Director(Safety),

Inspector-cum-

Chennai,

Assistant Director (Safety) and Additional

facilitator

Mangalore,

Assistant Director (Safety), Inspectorate Dock
Safety, Mumbai
4.

Assistant Director (Safety), Inspectorate Dock
Safety, Kolkata
5.

Assistant Director (Safety), Inspectorate Dock

Tuticorin,

New

Kochi

and

Ennore.

Safety, Chennai
6.

Assistant Director (Safety) and Additional

Inspector-cum-

Assistant Director (Safety), Inspectorate Dock

facilitator

Jawaharlal Nehru Port.

Safety, Navi Mumbai.
7.

Assistant Director (Safety) and Additional

Inspector-cum-

Assistant Director (Safety), Inspectorate Dock

facilitator

Mormugao.

Safety, Mormugao.
8.

Assistant Director (Safety) and Additional

Inspector-cum-

Assistant Director (Safety), Inspectorate Dock

facilitator

Kandla.

Safety, Kandla.
9.

Assistant Director (Safety) and Additional

Inspector-cum-

Assistant Director (Safety), Inspectorate Dock

facilitator

Vishakaptanam.

Safety, Vishakhapatnam.
10.

Assistant Director (Safety) and Additional

Inspector-cum-

Assistant Director (Safety), Inspectorate Dock

facilitator

Paradip.

Safety, Paradip.
11.

Assistant Director (Safety) and Additional

Inspector-cum-

Assistant Director (Safety), Inspectorate Dock

facilitator

Safety, Tuticorin.

Tuticorin.

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY
12.

Assistant Director (Safety) and Additional

Inspector-cum-

Assistant Director (Safety), Inspectorate Dock

facilitator

[PART II—SEC. 3(ii)]
New Mangalore.

Safety, New Mangalore.
13

Assistant Director (Safety) and Additional

Inspector-cum-

Assistant Director (Safety), Inspectorate Dock

facilitator

Kochi.

Safety, Kochi.

[F. No. S-65025/10/2026-ISH-II]
ALOK CHANDRA, Senior Labour And Employment Advisor

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. KUMER CHAND
MEENA

Digitally signed by
KUMER CHAND MEENA
Date: 2026.05.18
15:41:11 +05'30'
