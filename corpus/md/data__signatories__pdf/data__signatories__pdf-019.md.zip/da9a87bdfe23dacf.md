---
doc_id: "da9a87bdfe23dacf"
source_url: "https://www.dst.gov.in/static/uploads/2026/03/325200fefd5eb7e1b8d8905add7b6715.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Guidelines of SUNIL programme"
date: "2020-03-31"
pages: 24
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ed46b0249970e44b"
---

<!-- page 1 -->

Guidelines for Submission of Project
Proposal
Under
Strengthening, Upscaling & Nurturing
Innovations for Livelihood (SUNIL)
programme

SCIENCE FOR EQUITY, EMPOWERMENT &
DEVELOPMENT (SEED) DIVISION

GOVT. OF INDIA
MINISTRY OF SCIENCE & TECHNOLOGY
DEPARTMENT OF SCIENCE & TECHNOLOGY
TECHNOLOGY BHAWAN, NEW MEHRAULI ROAD
NEW DELHI – 110 016
Website: https://dst.gov.in/seed-home

<!-- page 2 -->

A.

INTRODUCTION

India has abundant resources and expertise to create, utilize and scale the Science Technology
and Innovation (STI) solutions addressing grassroot issues. Along with this, need-based research
& development (R&D) involving community-based organizations and dissemination of locally
appropriate products/processes/technologies on the basis of feedback from end-user ensure
uptake, impact and socio-economic development of Society at large. Therefore, a conducive
environment with bottom-up STI approach involving various stakeholders viz. Knowledge
Institutions (KI), Non-Governmental Organizations (NGOs), Voluntary Organization (VO),
Community Groups (CG), Social entrepreneurs and citizens is needed for sustainable
development leading to a better livelihood opportunities and quality of life.
Strengthening, Upscaling & Nurturing Local Innovations for Livelihood (SUNIL) programme, earlier
named as TARA (Technological Advancement for Rural Areas) programme under Science for
Equity, Empowerment and Development (SEED) division of Department of Science & Technology
(DST), Govt. of India aims to support technology delivery and creation of social enterprise models
for Economically Weaker Section (EWS) of society including need-based action research projects
to identify local and systemic solutions to implement S&T based projects at community level;
capacity building of Community based organizations (CBOs), NGOs, KIs, Start-ups & Social
ventures for developing examples of Sustainable Development Goals (SDGs) at ground level.
B.

FOCUS OF PROGRAMME

Focus of the SUNIL programme is not only limited to the deployment of many field-tested models
and location-specific technologies to meet the needs of citizens, it also encourages improving their
S&T knowledge, skill enhancement, capacity building and socio-economic conditions in the areas
of Natural Resource Management; Drinking Water & Sanitation; Education; Health & Nutrition;
Social Security; Local transport & Development; Electricity & Clean Energy; Entertainment;
Integrated-farming & best practices; Linking people to financial services; Phone & Internet
facilities; Livelihood & skill development etc. It broadly supports following three major aspects1. Technology delivery & enterprise creation model for improving efficiency of livelihood
system:
•

Providing emerging & locally appropriate STI solutions to strengthen weakest link of
livelihood system through Land-Lab-Land approach involving KIs, NGOs and Community;

•

Utilizing strongest link of local livelihood system for encouraging social entrepreneurship
development for EWS Society.

2. Technology interventions for Addressing Societal Needs (TIASN)
•

Research on identifying local & systemic need and STI solutions at the community level

•

Developing scientific and need-based innovative technologies for improvement of
economically weaker sections such as small and marginal farmers, rural artisans, landless
laborer and urban population in unorganized sectors;

•

Recognizing strengths & weaknesses of livelihood system;
1

<!-- page 3 -->

•

Standardizing pilot tested locally appropriate technologies

•

Identifying local innovation system and linking with National Innovation system;

•

Mapping welfare system with S&T knowledge system;

•

Other systemic gaps related to implementation of S&T based projects at community level.

3. Capacity Building of Community-based organizations (CBOs), NGOs, Knowledge
Institutions (KI) & Social Start-ups:
•

Organizing awareness creation programmes, workshops, roundtable discussions,
conferences, exhibitions, skills & training programmes to enhance the S&T capability of
CBOs and NGOs;

•

Imparting knowledge on societal development issues, Sustainable Development Goals
(SDGs), National Priorities (NPs) and Scientific Social Responsibilities (SSR) to scientists &
researchers (Postdoc, PhD & MTech students);

•

Standardization of S&T enabled NGOs.

Note: Programme will not encourage basic research proposals from KIs. Need assessment &
implementation plan at grassroot level including NGO partner is essential component in formulated
project proposal for seeking grant from Department. In project support, livelihood efficiency
including needs of EWS citizen viz. food, clothing, education, health, entertainment, livelihood,
earning, employability etc. should be encouraged along with consideration of environment, social &
economic values.
C.

DURATION OF PROJECT SUPPORT

Project proposals for 3-5 years in project mode support will be supported under SEED division.
The initial 3 months in the project proposal should be focused on problem identification and
stakeholder selection, while outputs of the project should be measurable. The outcome and impact
of STI on society should be indicative during last year of project implementation.
D.

PROJECT PARTNERS

The programme is open to S&T capable NGOs and Knowledge Institutions for collaborative S&T
research and interventions involving other Community based organizations viz. Self-Help Groups
(SHGs), Farmer Producer Organizations (FPOs), Social entrepreneurs, Start-ups and community.
The S&T capable NGOs should have strong social connect and working knowledge of cultural
sensitivities & needs in remote areas to deliver technologies and social entrepreneurship models
at grassroot level. Their ability in training, capacity building and technology dissemination at
community along with formal connections with Knowledge Institutes in producing detailed
engineering design and testing, will respond to the immediate requirements of changing
technologies, demography, and aspirations of EWS people. This inclusive & equitable approach by
cross-bridge collaboration between NGOs, KIs, CBOs, SHGs, FPOs Social entrepreneurs, Startups and citizens will act as a forwarding path towards Atma Nirbhar Bharat (ANB).

2

<!-- page 4 -->

E.

ELIGIBILITY CRITERIA

A coordinated project proposal involving above-mentioned partners should be submitted online.
Before applying to new proposal, PI must ensure to maintain maximum two number of ongoing
projects supported to Host Institution (HI) by SEED division at a time. Organizations already
working on two ongoing projects supported by SEED division need not to apply under this call for
proposal. Teams eligible for receiving project grants under the SUNIL Programme include:
Principal Investigator (PI)/ Co-PI from KI•

Scientists, engineers, technologist working IITs, NITs, Autonomous Bodies/Aided Institutions
and other educational institutions/ Universities under Central/State Governments, R&D
institutions, laboratories having adequate infrastructure and project implementation experience
at societal level.

Principal Investigator (PI)/ Co-PI from NGOs•

Non-Governmental Organization/Voluntary organizations/private institutions with minimum 3
years field level experience in S&T interventions and management should have delivered
proven technology models for field level applications to community after registration.
Experience in handling projects having focus on S & T with support from scientific departments
of Govt. of India will be encouraged.

•

S&T based voluntary organizations/institutions should come with legal status or as a society
registered under the Societies Registration Act 1860 or a trust registered under the Indian
Trusts Act 1982 or Charitable or Religious Act 1920 or under the corresponding State Act.

•

Prior to applying for project proposal grant, it is mandatory for every NGO to register first at
NGO- DARPAN portal of NITI Aayog https://ngodarpan.gov.in and to get NGO Unique ID.

•

Signed audited statements are available (at least for the last three financial year): balance
sheet, income and expenditure statement, receipts and payments account, schedules to these,
notes on accounts and the statutory auditor’s report.

•

NGOs/VOs Should submit Foreign contribution regulation Act (FCRA) certificate (to access
international funding if any).

Involvement of CBOs/Community Groups/FPOs/ SHGs & Social ventures: Direct funding to
this group of project partners will not be supported. However, they will have to apply through
NGOs or KIs mentioning their specific role and budgetary requirement in the project proposal.
•

FPOs promoted and supported by Government Departments, Corporates and Domestic &
International Aid Agencies, NABARD, SFAC) or registered on e-NAM platform and having
formal working space/ office, bank account and Aadhar details etc.

•

SHGs registered by Khadi & Village Industries Commission (KVIC), Common Service Centre
(CSC), NABARD or having saving bank account in the name of SHG.

•

Social Start-ups and Entrepreneurs including private as well as state sponsored incubators who
offer accelerated technological and innovation growth etc.
3

<!-- page 5 -->

Note: Only one Principal Investigator (PI) / Project Coordinator/ Senior Programme Officer
and one Co-PI from NGO and/ or KI will be allowed for a project and will be eligible to draw
emoluments from only one project supported by SEED Division, DST at a particular time.
Other human resources on project will be decided on the recommendations of EC members
and need of project. Positions may be Programme Officer/ Programme Professional/ Project
Assistant/ Project Associate/ Field assistant/ Technical Assistant/ Field Worker/ Supervisor/
Labourer etc.
F.

FUNDING PATTERN

The project support to meet the recurring and non-recurring cost will be based on the requirements
to carry out proposed objectives and activities to address the problem of particular size of
population and geographical area to be covered in a select time period. Project grant to KI and
NGO will, therefore consist of:
a. Recurring (General) grant supports for Human resources, Field trails/experimentations,
consumables, travel, contingencies, trainings, capacity building, publication and
dissemination related to identified solutions & activities and maintenance of the
infrastructure in terms of institutional overhead etc. Number of positions to be recruited in
scientific project will be as per the decision of Expert Committee/ Programme Advisory
Committee. Contingency charges (<3% of total recurring cost of project) will be sanctioned
irrespective of project proposal being submitted by a Govt./ Non-Govt. organization.
Expenditure under contingency head will be only on unforeseen items and will be released
from DST at the time of 2nd or subsequent releases based on documentary evidence and
need of the items covered under contingency. In addition to contingency, maximum 5 - 7%
of total recurring expenditure to NGOs/VOs and max. 10% of total recurring expenditure to
various Central/State Govt. institutions/ IITs/ UGCs/ ICAR/ ICMR/ CSIR/ AYUSH etc. or Rs.
1,00,000/- per year whichever is lower will be provided as institutional overheads/
administrative expenses during project tenure.
b. Small amount of Non-recurring (Capital) grant for infrastructure, adaptive R&D, field testing
and demonstration facilities etc. For construction activities like creation of Common Facility
Centre for community use, work-sheds, minor bore/tube wells, construction of rainwater
harvesting structure/ ponds/ poly houses/ testing labs/ incubation centres/ low-cost sanitary
toilets, minor work for installation of procured instrument etc. and for all other related allied
activities, a maximum of 40% of total project cost will be sanctioned to the implementing
organization if they are integral part of project subject to the condition that the rest of the
fund would be arranged by organization either from State Govt./beneficiaries etc. Amount of
capital grant on proposed project will be finalized based on the budget justification
submitted by implementing institutions/agencies and recommendations of Expert
Committee/ Programme Advisory Committee.
Initial release for the project will be less than 30% of approved recurring budget and total
Capital budget approved by Department. Next release to the organizations will be based on
the performance evaluation of the project in terms of indicators covered and replicable
4

<!-- page 6 -->

technology packages/models developed for remote applications and employment
generation of EWS.
G.

SHORTLISTING AND SELECTION MECHANISM

A detailed review of the proposal submitted by NGO in collaboration with KI and other
CBO/FPOs/SHGs will be undertaken in the following stages:
1st level: The Programme Division (PD) at the DST level will carry out a preliminary screening of
the proposals received on prescribed format and shortlist those, which prima facie satisfy the
eligibility criteria and have all prescribed supporting documents. Such shortlisted proposals shall
be placed before the Selection/ Expert Committee.
2nd level: Project proposal should be presented before EC members in the EC meeting/GMW
organized by PD for next level of screening. However, the S&T delivery capability and
performance of KIs, CBOs and NGOs may be evaluated by Technical Expert Group (TEG)
Members through on-the-spot assessment, if required. In this round, shortlisting of project
proposals for support will be based on innovative idea and merit of proposal (viz. technology
transfer; S&T delivery; knowledge dissemination, S&T absorption capacity of the community etc.)
to strengthen the existing knowledge support to Welfare System. For Project proposal formulation,
cross-bridge collaboration among Knowledge Institutions (KI), NGOs/VOs, Community Based
Organizations (CBOs) and Social ventures etc. will be encouraged.
On the spot assessment of infrastructure, S&T capabilities, strength and delivery potential of the
organization by the team of experts involving State Govt./Local Govt. personnel may be conducted
(if recommended by the Expert Committee during 2nd level of screening) for consideration under
project support.
3rd level: Evaluation of the proposal along with on-the-spot assessment report of the visiting expert
team will be done by the Expert Committee in next EC meeting/GMW. Final decisions for providing
financial support will be taken mainly on quality and merit of proposed proposal together with the
credibility and past record of candidate organization(s) based on above selection criterion & the
recommendations of expert committee.
H.

OPERATION OF THE SUNIL PROGRAMME

This scheme will be operated in the following method:
•

Once the magnitude of project grant is approved with justification details from organization as
required to determine the amount, the grant will not be rigidly tied to specific items of
expenditure so long as the main objectives of the programme and the total estimates are not
changed. However, such changes with proper justification as recommended by Expert
Committee will be approved by SEED, DST and will be communicated to organizations.

•

Since, all projects under programme will have the component of field-based testing,
dissemination, and related activities involving community groups and end users. Requirement
of Field visit/ on-the-spot assessment for any project/organization will be decided by Expert
Committee members during project progress evaluation.
5

<!-- page 7 -->

•

Certification on the basis of on-the-spot visits and / or group assessment of projects through
Group Monitoring Workshops (GMW)/ Expert Committee (EC) Meetings (signed Field visit
Report/ Minutes of Meeting/ Record note of Discussion) to assess the progress and
performance with set of indicators by expert team would be adequate for release of funds
annually (refer Table 1 for Monitoring & Evaluation indicators). The continuation of project
and modifications in objectives may further be decided for subsequent years based on the
report of expert team/evaluation.

•

If required, a community based participatory monitoring system may be conducted by
Department of Science & Technology utilizing NGOs/CBOs/SHGs/FPOs/Civil society
organizations for monitoring of projects through their feedback.

•

Accounts of organizations at all levels shall be open to audit by the Comptroller and Auditor
General (C&AG) as well as by the internal audit wing of Pay & Account Office of Ministry of
Science & Technology. Auditing of expenditure by the Department’s accounts team would be
considered in addition to certification by Charted Accountants.

•

Grantee Institutions/organization (GI) should be required to submit performance cum
achievement reports soon after the end of each financial year, and in any case, not later than
six months after the close of the financial year under Rule- 242 (2) of GFR-2017. Failing to the
aforesaid compliance, the GI may be debarred from getting next grant for another 05 year.

•

Any asset or constructed structure created out of the Grant-in-aid project should be handed
over to KI/NGO/SHG/FPO/community/beneficiaries based on an undertaking to use the assets
for societal development work in future, adaptive R&D on technology development, scaling &
delivery, provided the activities and performance of the groups are found satisfactory in larger
public interest. After implementation of project, retention and handover details of capital assets
should be intimated to DST. Implementing agencies will ensure proper utilization and
management of these facilities even after the project period is over.

•

The extension of project period beyond original sanctioned date will not be more than 50% of
the original time period except in the case of natural calamity / disaster or due to any other
force-majeure incident. GI should send the request of extension to DST at least 3 months prior
to the date of completion of the project.

•

Convergence with schemes/programmes of inter-Ministries/ Departments will be agenda point
in each periodical monitoring and review meetings of the SUNIL programme.

•

A central data base validated by Expert members & implementing agencies will be maintained
by PD for convergence benefits and easier follow-ups. The data collated will be used for
monitoring various pre-defined parameters of programme.

•

The Ministry of Science & Technology, Government of India reserves the right to conduct
random inspection/check from time to time of any of the implementing organizations/institutes.
It can discontinue funding under the programme at any point of time if the performance of the
organization is found to be unsatisfactory.

6

<!-- page 8 -->

TABLE 1: MONITORING & EVALUATION INDICATORS
Technology delivery & enterprise creation model
Output’s Indicators
●

●
●
●

●

Outcome’s Indicators

No.
of
technologies/
techniques/ tools/ processes/
innovative
products/
packages/
devices
modulated
No.
of
technologies/
techniques/ tools/ processes
deployed & demonstrated
No.
of
technologies/
techniques/ tools field tested
No. of Common Facility
Centres/
Permanent
Structures/ Technology Labs
created under the project
No. of target community
groups/ researchers using
the facilities / products/
technologies created under
the project

●
●
●
●
●
●
●

No. of technologies/ products/
packages
transferred/commercialized
No. of technologies/ products/
packages/
social
enterprise
models ready to transfer
No. of local innovations converted
into social enterprises/ start-ups
created (technology-wise)
No. of market linkages developed
No. of people (Male/ Female)
employed
through
project
interventions
No. of Social Entrepreneurs/
Start-ups/ FPOs/ SHGs formed/
nurtured under project
No. of sustainable livelihood
opportunities created & utilized by
community

Impact’s Indicators
●
●
●
●
●
●

●
●

Increased access to S&T services
& facilitative units/ infrastructure.
Reduction in drudgery, cost and
hesitation over use of technology/
tool/ process/ products
Increase in household income
Average productivity gain per user
Increase in access to markets and
financial institutions
Improved access to location
specific technologies/ techniques/
tools/
processes/
innovative
products/ packages/ devices
Increased interest of academic and
R&D
institutions
in
societal
research and testing at field level.
Improvement
in
access
to
indigenously developed/ modified
technologies, socially relevant S&T
innovations

Capacity Building of CBOs, NGOs, KIs and community
●

●
●

●

●
●
●

No. of reports generated to
identify available resources
and
need
of
target
population
No. of manuals/ reports
created
in
vernacular
language on S&T solutions.
No. of portals, Apps & database created on locally
available resources and
knowledge management
No.
of
workshops/
roundtable
discussions/
conferences/
exhibitions/
surveys conducted
No. of Awareness/ Skill
Development/
training
Programmes conducted
No. of Panchayat/ meetings
conducted with local Govt.
No. of internships supported
under programme

●
●
●
●

●
●

●

No. of manpower trained by
supported
institutions/
organizations in current year
No. of portals and mobile Apps
users both from implementing KIs/
NGOs and external sources
No. of STI solutions adopted by
community for productivity gain in
traditional practices
No. of formal understanding/
collaborations
established
between KIs, NGOs, State & local
Govt., private partners & UN
agencies
No. of human resources deployed
in Academic/ Industry/ NGOs
No. of Scientists & researchers
(Postdoc, PhD & MTech students)
from KIs inclined towards societal
research
No. of organizations/ agencies/
social ventures motivated and
mobilized for replication of project
outcomes
(scientific
capacity
building)

●
●

●
●
●
●
●
●
●
●

Improved
access
to
human
resource pool and knowledge base
Improved access to data and
productivity gain due to efficient
and cost-effective management of
locally available resources
Improved access to financial
services
Improved traditional practices by
STI inputs
Improved employment rate due to
capacity building
Reduced migration rate
Inclined KIs towards societal
research issues and solutions
involving community groups.
Improved participation and decision
making of EWS society in social
gathering & meetings.
Increase in S&T knowledge of
SHGs, FPOs, NGOs and social
ventures
No. of forward/ backward linkages
developed for sustenance of
societal projects

Research to identify local and systemic solutions
●

No. of S&T delivery solutions
developed for innovative
technologies/
tools/

●
●

No. of field-based technical
studies conducted
No. of research Papers/ articles
7

●
●

Increased export of indigenous
products/ goods
Increase in S&T outreach and

<!-- page 9 -->

●

●

●
●
●
●

products/ services
No. of innovative ideas taken
up from community for
further
technology/
tool/
product/
process
development by NGOs/ KIs/
industry
No. of locally appropriate
technologies/
tools/
processes pilot tested &
standardized

●
●
●
●
●
●

published
No. of reports/ Manuals generated
No. of people engaged in societal
& action research projects
No. of telecasting/ tele-films
created
No. of success stories published
No. of Patents (applied/granted)
No. of MoU/ formal contracts
signed
for
local/
Global
collaboration

●
●
●
●
●

geographical coverage area
Improved Index of living standard in
society
Increase in evidence-based R&D
on socially relevant issues
Decreased social isolation
Promoted
Inclusiveness
and
Equity.
No. of local organizations like gram
panchayat/ cooperation/ voluntary
groups engaged

Contribution towards Sustainable Development Goals (SDGs) and National Missions (NMs)
Convergence towards national schemes/ programmes for development of remote areas
Total number of beneficiaries covered under project (Category-wise, gender-wise percentages)
Geographical area covered under project (village/block, district, State-wise)

I.
INSTRUCTIONS TO BE FOLLOWED & DOCUMENTS/ENCLOSURES REQUIRED
TO BE SUBMITTED ALONGWITH THE PROJECT PROPOSAL
•

The applicants, after assessing their eligibility and suitability as per the eligibility conditions of
the programme, shall be required to apply through e-Project Management System (e-PMS
Portal) (https://onlinedst.gov.in/) (Open in Google Chrome or Mozilla Firefox for better
results), attaching required documents with the signatures and rubber stamps of the concerned
persons/ officials, failing which will reject the proposal. It is mandatory to submit the proposals
through online mode only.

•

DST will not be responsible for the non-submission of proposal by PI due to any personal
reasons, regional festivals, poor network speed, natural calamities, etc. All the incomplete
applications will be summarily rejected. However, the rejected candidates will have the option
to apply in the subsequent phases of selection.

•

Submission of new project proposal for support will be based on fresh call for proposal
initiated on e-PMS Portal (https://onlinedst.gov.in/).

•

Proforma for project proposal submission (Annexure- I for reference).

•

Please furnish one copy of the following documents*:
o Authenticated copy of valid registration certificate of NGO/VO/private institution.
o Memorandum of Association, Rules and Bylaws of the society/trust/section 8 company.
o Balance sheets, statement of Accounts and Annual report of the organization for the last
3 financial years.
o Memorandum of Understanding/ Consent between project partners.
o Copy of signed General terms & conditions from Heads of partner institutions
(Annexure- II)
o Certificate from the Principal investigators (PI) (Annexure- III)
8

<!-- page 10 -->

o
•

Bio-data of PI & Co-PIs (Annexure- IV)

Count minimum 9-12 months from submission of the proposal to arrive at expected time
point for final decision on the proposal for support. Please site file number/TPN number
received from e-PMS portal in all future correspondence.

Any query/ correspondence regarding the above Call for Proposal may be initiated on 01126590618 or mail to the following address: Dr Debapriya Dutta (HEAD & Advisor), Email: ddutta@nic.in
or
Dr Anuradha Pughat (Scientist), Email: anuradha.pughat@gov.in
Science for Equity, Empowerment and Development Division
Department of Science and Technology
Technology Bhawan, New Mehrauli Road
New Delhi – 110 016

**********

9

<!-- page 11 -->

ANNEXURE-I

PROFORMA FOR PROJECT PROPOSAL SUBMISSION
(TO BE FILLED BY APPLICANT)

PART A
(Please limit to 3-4 pages only)
DESCRIPTION ABOUT THE ORGANIZATION (KI/ NGO)
1. Title of Project:
2. Project Duration:
3. Proposed Objectives:
4. Name, Address & Contact Details of PI (from NGO/ Knowledge Institution):
5. Name, Address & Contact Details of Co-PI (from Knowledge Institution/ NGO):
6. Identification of NGO:
6.1. Name of Organization
6.2. Address with PIN CODE
6.3. Contact person
6.4. Telephone & Fax No.
6.5. E-mail:

Website:

6.6. Registered as: Society/ Trust
6.7. Date of registration
6.8. NGO Darpan ID
7. Identification of KI:
7.1. Name of Organization
7.2. Address with PIN CODE
7.3. Contact person
7.4. Telephone & Fax No.
7.5. E-mail:

Website:

7.6. Registered as: Society/ Trust/ Others
8. Area of proposed work (viz. Natural Resource Management; Drinking Water & Sanitation;
Education; Health & Nutrition; Social Security; Local transport & Development; Electricity &
Clean Energy; Entertainment; Integrated-farming & best practices; Linking people to financial
services; Phone & Internet facilities; Livelihood & skill development etc.)
9. Give an organization chart, job description and expertise of your organization (for NGO
& KI both).
10. Scientific Manpower in position in the organization as on date (for NGO only)
10

<!-- page 12 -->

S.N.

NAME &
DESIGNATION

11.

Pattern of expenditure for last five years (for NGO only)

S.N.

12.
i.

HIGHEST
QUALIFICATION

SPECIALIZATION

FUNDING AGENCY

LINK WITH THE
ORGANIZATION

AMOUNT

YEAR

DATE OF
JOINING

Full time/
part time
employee

PURPOSE

Best Practices (for NGO only)
Indicate how often governing body meets in a year, how often general body meets?
(Give the dates of most recent three formal meetings of the Governing Body and general
body, place and number of members attending out of total number)

ii.

Attach most recent three annual audit reports as presented to the governing body and
approved, list the years here (reports should be placed during visit of the expert team/
presentation before Expert Committee members).

iii.

Indicate how many persons joined/ left the organization in the most recent three-year
period.

iv.

Do you formally assess performance of your staff, how frequently is assessment made, who
does the assessment, is the result shared with concerned member.

v.

What measures and incentives are in place to attract new bright people to your organization
and retain them.

vi.

Do you price and sell your products and services or give that free to beneficiaries?

vii. Do you have your own marketing group or have access to consultancy services?
viii. What measures are in place to make your initiative financially self-reliant and sustainable in
future - we are referring to funds you are seeking as project mode support.
ix.

Name two R&D/ S&T institution, organization with whom you partnered in some successful
technology led initiative; was there a MoU formally signed, what did the partners contribute
to the initiative, what product was developed?

13. List three successful and proven technology models and related packages/products
developed and commercialized, if any (viz. New / Improved Machine or equipment / bioproduct etc.) – for NGO and KI both
List four successful technology models as complete package/ products developed
and commercialized
Package/
Package/
Package/
Package/
Specific Details
Product 1

1. Developed during (time)
11

Product 2

Product 3

Product 4

<!-- page 13 -->

2. Investment in R&D (Rs.)
3. Funded by
4. Purpose of product
5. Intended users
6. Launched in market on
7. Sold on subsidized price/ not
8. Product distributed/ Franchised out
9. Growth in number of users since launch
10. Patented/ branded (details)
11. Manufactures created
12. Revenues from IPR
13. Plans for modification/ scaling

PART B
(Please limit to two pages only)
SOURCE OF FUNDS AND PERMANENT FACILITIES
1.

Please give details of agencies (national as well as international) which gave funds, amount
received, and purpose for which they were utilized in the format given below for the last ten
years (for NGO & KI both). Copy of sanction letters to be shown at the time of
presentation/ field visit.
S.N.

AGENCY

AMOUNT

YEAR

PURPOSE – Project details

1.
2.

2.

Description about permanent facilities (land, equipment, building etc.) created in the project
area & proposal for utilizing facilities in the project mode support. (for NGO & KI both)
S.N.

ITEM

YEAR OF
CREATION /
PROCUREMENT

1.

12

PURPOSE FOR
WHICH USED

SOURCE OF FUNDING

<!-- page 14 -->

PART C
(Please limit to four-five pages only)
DESCRIPTION OF ACHIEVEMENTS & PROPOSED ACTIVITIES
1. Please describe briefly your activities for the last five years highlighting the S&T

interventions in proposed project area with details for the following:
S.N.

ACTIVITIES (for NGO & KI both)

BRIEF DETAILS (with
quantitative figures if
possible)

1.

Expertise developed (training, projects undertaken etc.)

2.
3.

Technologies developed and disseminated/ innovations
S&T based revenue generation model(s) developed

4.
5.
6.
7.
8.
9.

Participatory approaches (involvement of community)
Areas of influence (village/block/district) etc.
Involvement of beneficiaries and local organizations
Involvement in district and state level planning
Training programmes/ workshops organized
Publications – training manual, contributions to magazines
and journals
Visit of villagers to organization/ meetings conducted, if any
Technology benefits to society
Patent granted, if any
Award/Recognition for technology development &
dissemination
Linkages with S&T institutions/ resource persons/ R&D
agencies for technical back up

10.
11.
12.
13.
14.

2. Geographical coverage (villages/blocks & districts covered) with details about location of

field units/offices, and locations of projects handled in last five years. Show linkages in a
chart form.
3. Focus on technology delivery and enterprise creation for improving livelihood efficiency in

next 5 years from now. Expected societal changes from proposed project, if any.
4. List the need-based project objectives to be focused during project implementation, if
approved under SUNIL programme: year-wise work plan of action with time line and deliverables in
tabular form

S.NO.

PROPOSED
OBJECTIVE (4-5
only)

YEAR

LIKELY DELIVERABLES

1.
2.
3.
13

MEANS OF VERIFICATION
(INDICATORS)

<!-- page 15 -->

5. WORK PLAN (MAX. 250 WORDS): State the methodology in a sequence of clearly defined
steps leading to achievement of the stated objectives.

6. Proposed collaboration with Knowledge Institutions/ Social ventures/ other voluntary

groups to benefit and empower citizen through S&T interventions.

7. PUBLICITY, PROMOTION & DISSEMINATION PLAN: (provide a publicity, promotion &

dissemination plan which shows how the project achievements will be properly
disseminated)

8. Suggest output, outcome and impact indicators for effective monitoring of project

performance (refer table 1 in guidelines of SUNIL programme).

Project performance indicators (objective-wise)
Output’s Indicators
●

Outcome’s Indicators
●

14

Impact’s Indicators

<!-- page 16 -->

PART D
(Please limit to 3 pages only)
BUDGET DETAILS
Proposed budget from partner agencies should be realistic based on the requirements to carry out
proposed objectives and activities to address the problem of particular-size of EWS population and
areas to be covered in a select time period. Please give brief justification for each item
proposed under different budget heads.
A.

RECURRING (GENERAL) BUDGET HEAD:

1. MANPOWER (team of scientists/engineers/technical support staff including social scientist total not
more than four)
Designation

Monthly

(Number of persons)

Emoluments (Rs.)

BUDGET (Rs. in lakhs)
Year
1st

2nd

___
3rd

4th

5th

Justification

i.
ii.
Total

(Only NET qualified candidates will be considered as JRF/SRF)

2.

CONSUMABLES (Supplies/Materials for adaptive R&D/technology refinement and field testing etc.)
Description

Budget (Rs. in Lakhs)
Year
1st 2nd

3rd

___________________
4th

5th

Justification

Items
i.
ii.
Total

3.

TRAVEL
Item

Budget (Rs. in lakhs)
Year
15

___________________

<!-- page 17 -->

1st
1.

Local

2.

Out Station

2nd

3rd

4th

5th

Justification

Total
(International travel is not permitted)

4.

ADAPTIVE R&D, FIELD TESTING/ DEMONSTRATION, TECHNOLOGY DISSEMINATION,
DOCUMENTATION & TRAINING
Item

Budget (Rs. in Lakhs)
Year
1st

2nd

3rd

_____________
4th

5th

Justification

1. Adaptive R & D
2. Field Testing/demonstration
3. Technology dissemination
4. Documentation & Training (Topic, purpose, no. of trainings/yr., duration of training days, level of
Participation, cost/training)
Total

5.

CONTINGENCY
Item

Budget (Rs. in Lakhs)
Year
1st

2nd

3rd

_____________
4th

5th

Justification

Total

6.

INSTITUTIONAL OVERHEADS
Item

Budget (Rs. in Lakhs)
Year
1st

Total

16

2nd

3rd

_____________
4th

5th

Justification

<!-- page 18 -->

B.

NON-RECURRING (CAPITAL) BUDGET HEAD: (Small grant only for essential permanent
equipment and structure etc.)*:
Equipment / Item details

Estimated Cost (Rs.)

Justification

1.
2.
Total
*. Budgetary quotations (min. 3 no.) will be required in support of estimates for equipment, if project is
approved for financial support. (Pl. give estimates, if the equipment is to be fabricated locally for prototype
testing etc). Include installation charges, transport, taxes/duties/levies, etc. Please try to avail tax/duty
exemptions as applicable to your institution/ organization. Proper record should be maintained for the items
procured under this Head. As per rule 149 of GFR, the procurement of Goods & Services is Mandatory for
Goods and/or Services available on GeM Portal only and PI will also follow DoE's guidelines for incurring
expenditure under the different sub-head.

PART E
SUMMARY OF PROPOSAL
(Please limit to 2-3 pages only)
1.

Title of Project:

2.

Project Duration:

3.

Proposed Objectives (4-5 only):

4.

Name, Address & Contact Details of PI (from NGO/ KI):

5.

Name, Address & Contact Details of Co-PI (from KI/ NGO):

6.

Registration number & date of Registration as NGO/ VO / private institution:

7.

NGO Darpan ID of NGO/ VO/ private institution

8.

Detailed mailing address and contact number of Authorized office bearer of both organizations for
issuing sanction, if project proposal is approved:

9.

Area of proposed work (viz. Natural Resource Management; Drinking Water & Sanitation;
Education; Health & Nutrition; Social Security; Local transport & Development; Electricity & Clean
Energy; Entertainment; Integrated-farming & best practices; Linking people to financial services;
Phone & Internet facilities; Livelihood & skill development etc.):

10.

Problem identification and baseline study for proposed project:

11.

Details of collaborative partners (NGOs/ KIs/ Social Ventures/ CBOs/ SHGs/ FPOs etc.): MoU/
partnership certificate to be shown at the time of presentation on proposal.

12.

Role of partner organization/ agency/ group in implementation of project:

13.

Geographical coverage area of proposed project (villages/blocks/districts)

10.

Estimated year-wise budget required for project support:

BUDGET ESTIMATES: SUMMARY
17

<!-- page 19 -->

(Rs. in lakhs)
Item

Budget
____________________________________
1st
2nd
3rd
4th
5th
Total

A.

Recurring
1. Manpower
2. Consumables
3. Travel
4. Adaptive R & D, Field Testing/Demonstration, Technology Dissemination, Documentation &
Training etc.
5. Contingencies/Other cost
6. Institutional Overheads

B.

Non-Recurring
Permanent equipment / item

Grand Total (A+B)

18

<!-- page 20 -->

ANNEXURE-II

Department of Science & Technology
Science for Equity, Empowerment & Development Division (SEED) Division
Terms and Conditions for Organizations selected for project support under SUNIL Programme
1. Focus of Strengthening, Upscaling & Nurturing Innovations for Livelihood (SUNIL) programme will adhere to
following three aspects:
•
•

•

Technology delivery & enterprise creation model: Land-Lab-Land approach to provide emerging & locally
appropriate STI solutions to strengthen weakest link of livelihood system and utilizing strongest link of local
livelihood system for social entrepreneurship development to EWS Society.
Research to identify local and systemic solutions: It includes research to identify solutions to local
problems, strengths & weaknesses of livelihood system, defining S&T based NGOs, standardization of pilot
tested locally appropriate technologies, identification of local innovation system, aligning Welfare system with
knowledge system and other systemic gaps related to implementation of S&T based projects at community
level.
Capacity Building of CBOs, NGOs and KIs: Awareness creation, workshops, roundtable discussions,
conferences, exhibitions, skill & training programmes to enhance the S&T capability of CBOs, NGOs and
social issues related knowledge of Scientists & researchers (Postdoc, PhD & MTech students) and
standardization of S&T enabled NGOs.

2. Manpower sanctioned under project should have relevant qualifications and experience/expertise against each
sanctioned post which should be relevant to activities proposed for three/ five years. Principal Investigator (PI)
/Senior Program Officer (SPO) should have PhD Engineering/ Sciences/ Medicine/ Pharma or PG in
Engineering/ Sciences/ Medicine/ Pharma with minimum 5 years of field experience in technology development
and delivery / implementing S&T based projects/programs for societal application. Program Officer (PO) should
have Ph. D Engineering/ Sciences/ Medicine/ Pharma or PG in Engineering/Medicine/ Pharma or Graduate in
Engineering/ Medicine/ Pharma, and Post Graduates in Science with minimum 3 years of experience in handling
S&T based societal projects. Program Professionals (PP) should have PG in Science or Graduate in Engineering/
Medicine, or Graduate in Science/Social Science/ Rural Management/ ICT with minimum 5 years of experience in
implementing S & T based societal projects. While, Technical Assistant/ Supervisor/ Construction Specialist/
Field Assistant/ Supervisor should be Graduate in Science/ Social Science or Diploma holder in any discipline
with minimum 3 years of experience in implementing S&T based societal projects.
3. Project Manpower should have at least 50% new young personnel willing to work in remote areas. Organization
should evolve an appropriate mechanism with incentives etc. to retain and nurture manpower at least for 3-4 years
to ensure timely delivery of expected outcome. Recruitment of women candidates should be encouraged.
4. Project manpower will work for full time in project mode as per organizations rules and regulation, and not as
employee(s) of Department of Science and Technology (GOI) and may also be utilized in coordinating data
collection & analysis of SUNIL programme in terms of output, outcome and impact. Such staff member will not
draw salary from other projects but may receive honorarium for specific activities. The support should also be
utilized to dream and visualize innovative ideas and activities.
5. Minimum Infrastructure and support services to project manpower should be the responsibility of the organization.
Each organization should also strengthen networking with KVKs, smaller VOs in respective area of influence for
large scale technology dissemination and other outreach activities. Also, project personals would catalyze and
promote capacity building of these partner VOs.
6. Continuation and financial support for project will depend on evaluation of progress and assessment by expert
team from time to time. Non-performance may lead to stoppage of grant/disqualification for further project
support.
7. International travel is not permissible under the programme.
8. After receipt of project grant, signed bio-data and joining details about the manpower recruited should be
intimated to SEED Division, DST within three months.
19

<!-- page 21 -->

9. Progress report along with audited statement of expenditure (SE) and utilization certificate (UC) as per timeline
for each financial year should be submitted each year.
10. Unspent balance and interest accrued at the end of each financial year should also be reported in SE & UC and
permission may be sought to carry forward the unspent balance to the next financial year. Interest accrued in each
financial year should be deposited to Consolidated Fund of India- Bharat Kosh and details should be mentioned in
UC & SE.
11. Capital assets/facilities created from project support will be used by the intended beneficiaries during
implementation period, and even after completion of the project support. GFR-2017 rules should be followed.
12. DST (SEED Division) will be immediately informed in case any member of the project team leaves the
organization and replacement along should be reported within 3 months of vacancy.
13. All equipment and other field assets, banners, boards, manuals, reports etc. will carry the credit as ‘Catalyzed &
Supported under SUNIL Programme of Science for Equity, Empowerment & Development Division, Dept. of
Science & Technology, New Delhi’.
14. DST will be authorized to conduct audit and inspection of the project Support at any time and the project team will
facilitate such audit or inspection.
15. An official of DST will be invited to attend the meetings of the executive body of the organization, wherein
progress and expenditure details related to project activities are discussed. DST will nominate a suitable officer for
this purpose.
16. DST will be kept informed about projects funded by other agencies. Accounts of such projects should be
separately maintained.
17. Each training activity should be properly documented along with the subject matter, content of training, names of
trainers and names of participants along with their address, place and date(s) of training.
18. Each member of the project team should maintain a log book recording the tasks performed by him/her on a day to
day basis.
19. Proper documentation should be maintained in respect of activities taken up by the project support group as each
new idea being pursued, expenses incurred in processing the idea, person involved, equipment proposed etc.
20. Benefits accrued to society / beneficiaries, directly or indirectly should be documented in story and video form.
21. Project implementing agency/organization will be responsible in case of any financial & legal administrative
responsibility and dispute between the agency/organization and project staff. DST will not be liable for such legal
cases of disputes.
We agree to the above terms and conditions.

Date:
Place:

(

)
Signature with seal
Head of the Organization 1

Date:
Place:

(

Date:
Place:

(

)
Signature with seal
Head of the Organization 2

)
Signature with seal
Head of the Organization 3

*Signature of all partner organizations/ agencies
20

<!-- page 22 -->

ANNEXURE-III

CERTIFICATE FROM PI & Co-PI
1.

This is to certify that the information given above is true to the best of my knowledge and
belief

2.

We agree to abide by the terms and conditions of the grant set forth by the Department of
Science & Technology.

3.

Certified that the equipment, other basic facilities and such other administrative facilities as
per terms and conditions of the grant, will be extended to project team throughout the
duration of the support.

4.

PI & Co-PI assures financial and other managerial responsibilities of the project
implementation.

5.

Support under SUNIL programme of SEED division, DST will be acknowledged in all future
internal or external publications/ reports/ presentations etc. and IPR guidelines will be
followed.

6.

Project team of Grantee organization will facilitate to conduct audit or inspection of project
at any time by expert team of DST.

7.

Partner agencies will abide by the “Terms and Conditions for project support under SUNIL
Programme”.

8.

Certified that the organization has never been blacklisted by any department of the State
Government or Central Government.

9.

We have not applied for similar support to any other agency/ department.

Date:
Place:

(

Date:
Place:

(

)
Signature
Principal Investigator

Date:
Place:

(

*Signature of PI & Co-PIs

21

)
Signature
Co-Principal Investigator

)
Signature
Co-Principal Investigator

<!-- page 23 -->

ANNEXURE-IV

Bio-data of PI & Co-PI
(a) Principal Investigator
Name, Designation, Department:

Institute/University Name and Address:

Date of Birth:
Likely Date of retirement:
Gender (M/F):
Category (Gen/SC/ST/OBC):
Telephone(O), Telephone (R) and Fax:
Mobile:
Email:

Education and Training (Graduation onwards):
Degree

Year

University/Institute

Field of Specialization

Field of Experience (Keywords)
Number of Papers published
Significant publications (Maximum 10)
Title

Authors

Journal

Volume

Page

Year

List of proposed area related publications from last five years

22

SCI Index

<!-- page 24 -->

(b) Co- Principal Investigator
Name, Designation, Department:

Institute/University Name and Address:

Date of Birth:
Likely Date of retirement:
Gender (M/F):
Category (Gen/SC/ST/OBC):
Telephone(O), Telephone (R) and Fax:
Mobile:
Email:

Education and Training (Graduation onwards):
Degree

Year

University/Institute

Field of Specialization

Field of Experience (Keywords)
Number of Papers published
Significant publications (Maximum 10)
Title

Authors

Journal

Volume

Page

Year

SCI Index

List of proposed area related publications from last five years
(c) Other Co-Investigator *
*You can add additional Co-Investigator as per your requirements as (a),(b),(c),(d),(e),(f)…...

23
