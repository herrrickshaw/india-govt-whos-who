---
doc_id: "d985eebdc08df4a2"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/1bf84757f58acebdbc2d2f1e5e6cd360.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 16.03.2024 for the empanelment of advocates for various district & subordinate courts in Rajasthan"
date: "2024-03-16"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b7ba6a41b3a707a0"
---

<!-- page 1 -->

J-11017/6/2024-JUDICIAL

I/2815/2024

F. No. J-11017/6/2024-Judicial (Part-2)
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
****
Shastri Bhawan, New Delhi
Dated the 16th March, 2024

ORDER
The president is pleased to engage following Advocates for conducting
Central Government litigations before various District & Subordinate Courts in the
state of Rajasthan, as shown in the table below, with effect from the date of this
order for a period of three years or until further orders, whichever is earlier:
DISTRICT & SUBORDINATE COURTS IN RAJASTHAN
Sl.
No.

Name of
Advocate

Contact Details

Enrolment No.

DISTRICT – JAIPUR
ADDITIONAL STANDING GOVERNMENT COUNSEL
1.

Amit Kumar
Gupta

B-191, Mahal Yojna, Jagatpura,
Jaipur-17
Mob.9314432569
E-mail: gupta.amit233@gmail.com

R/2089/2008

2.

Naveen Kumar
Jain

93, Lav Kush Nagar, Tonk Phatak,
Jaipur.
Mob: 9828077498

R/38/1998

DISTRICT – NAGAUR
ADDITIONAL STANDING GOVERNMENT COUNSEL
3.

Govind Prakash
Soni

2nd Floor, Vijay Tower, Opp.old
Govt. Hospital, Nagaur, Rajasthan
Mob. 7737689313

R/256/1982

DISTRICT – BIKANER
ADDITIONAL STANDING GOVERNMENT COUNSEL
4.

Manoj
Kachhawa

11/414, M.P. Colony, Bikaner,
Rajasthan
Mob: 8946815190
Email: mkkachhawa@rediffmail.com
Page 1 of 3

R/2307/2019

<!-- page 2 -->

J-11017/6/2024-JUDICIAL

5.

I/2815/2024

Prem Sukh G.L. Pathano Ka Mohalla, Phar Bazar,
Bikaner-334001
Mob: 9829472987
Sharwan
Badi Jassolai, Bikaner
Mob: 958826889
Kumar

R/2012/2001

7.

Sandeep
Swami

--

R/1938/2004

8.

Sukh Ram
Meghwal

Nokha Road, Bikaner, Rajasthan.
Mob: 9782460189

R/1794/2006

6.

R/60/1995

DISTRICT – BHILWARA
ADDITIONAL STANDING GOVERNMENT COUNSEL
9.

Ladu Lal Teli

1-K-18, R.C. Vyas Colony Bhilwara,
Rajasthan-311001
Mob: 9414112999
Email: lltelibhilwara@gmail.com

R/1225/1995

DISTRICT – KOTA
ADDITIONAL STANDING GOVERNMENT COUNSEL
10.

Ashok Kumar

CHH 13, Ambedkar Colony, Kunhadi,
Kota-324008
Mob: 8078627447
Email:ashokbadaladvocate@gmail.com

R/897/1995

3.
The terms & conditions of the engagement of aforesaid Advocates will be
governed by this Department’s OM No. 27(11)/99-Judl. dated 24.09.1999 read
with OM No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued
subsequently through OMs, especially the OM No. J-16/11/2017-Judicial dated
08.02.2018 imposing certain restrictions on panel counsel. The aforesaid OMs are
available on the website of this Department i.e. www.legalaffairs.gov.in in the tab
‘Judicial Section’ under heading ‘Circulars pertaining to litigations’.
4.

Hindi version of this order will follow.

(Jaspal Singh Dhanju)
Deputy Legal Adviser (Judicial)

Page 2 of 3

<!-- page 3 -->

J-11017/6/2024-JUDICIAL

I/2815/2024

F. No. J-11017/6/2024-Judicial

Dated: 16.03.2024

Copy (through email) to:1. PS to MoS (I/C) L&J
2. PSO to Law Secretary/All Additional Secretaries and Joint Secretaries in the main secretariat
of Department of Legal Affairs.
3. Additional SGI, High Court of Rajasthan.
4. Deputy SGI for High Court of Rajasthan at Jodhpur and at Jaipur.
5. Standing Govt. Counsel for District Jaipur, Nagaur, Bikaner, Kota
6. Cash (LA) Section for payment of retainership fee to Standing Govt. Counsel, Bhilwara (Shri
Ladu Lal Teli) with effect from the date of this order.
7. The Pay & Accounts Office, Department of Legal Affairs, New Delhi.
8. One copy of this order is uploaded on website of this Department i.e. www.legalaffairs.gov.in
under tab ‘Judicial Section’ in the link ‘Orders related to empanelment of Advocates for Union
of India’ for the information of panel counsel as above and all other concerned.
9. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
10. Office / spare copy

(Kumar Gaurva)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in

Page 3 of 3
