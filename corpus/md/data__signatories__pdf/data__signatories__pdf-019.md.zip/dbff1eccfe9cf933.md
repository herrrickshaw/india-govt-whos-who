---
doc_id: "dbff1eccfe9cf933"
source_url: "https://www.legislative.gov.in/static/uploads/2025/06/00ea97ab2b1ac5b864a85b91c331d739.pdf"
ministry: "Legislative Department (LD)"
title: "Tender upcoming-2023030351-1"
date: "2016-01-13"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5ef2f3fe93db3fcb"
---

<!-- page 1 -->

~

~o

-m ~"-(1f-I)04/0007/2003-12
o

REGISTERED

NO. DL-(N)04/0007/2003-12

mn~
EXTRAORDINARY
'WT II-~
I
PART 11- Section 1
W1fCfiT{ ~ ~

PUBLISHED

~ ~,

~trcm:,~

BY AUTHORITY
30, 2013~

10, 1934 (~)

NEW DELHI, WEDNESDAY, JANUARY 30, 2013IMAGHA 10,1934 (SAKA)
~
Separate

'WT -q f'r;;{ ~

~

~ \lffift t ~

1% ~

cf;~ -q WT ~ wf; I

3lWf ~

paging is given to this Part in order that it may be filed as a separate

compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 30th January, 20 \3/ Magha 10, !934 (Saka)

THE READJUSTMENT
OF REPRESENTATION
OF SCHEDULED
CASTES AND SCHEDULED TRIBES IN PARLIAMENTARY AND
ASSEMBLY CONSTITUENCIES
ORDINANCE, 2013
No. 2 OF 2013
Promulgated

by the President in the Sixty-fourth

Year of the Republic of

India.
An Ordinance to provide for the readj ustment of seats in the House of the
People and in the Legislative Assemblies ofthe States andfor the readjustment of
territorial constituencies therefor, insofar as such readjustment is necessitated by
the inclusion in or exclusion from the lists of the Scheduled Castes and the Scheduled
Tribes and for matters connected therewith or incidental thereto.
WHEREAS
Parliament is not in Session and the President is satisfied that circumstances
exist which render it necessary for him to take immediate action;
Now, THEREFORE,
in exercise of the powers conferred by clause (I) of article 123 of the
Constitution, the President is pleased to promulgate the following Ordinance:I. (I) This Ordinance may be called the Readjustment of Representation of Scheduled
Castes and Scheduled Tribes in Parliamentary and Assembly Constituencies Ordinance,
2013.

Short title and
commencement.

(2) It shall come into force at once.
2. In this Ordinance, unless the context otherwise requires,37

or 1948.

(a) "Census Commissioner" means the Census Commissioner appointed under
sub-section (I) of section 4 of the Census Act, 1948;

Definitions.

<!-- page 2 -->

2

THE GAZETTE OF INDIA EXTRAORDINARY

[PART 11-

(b) "Commission" means the Election Commission referred to in article 324 of the
Constitution;
(c) "Delimitation Act" means the Delimitation Act, 2002;

33 of 2002.

(d) "Delimitation Order" means the Delimitation of Parliamentary and Assembly
Constituencies Order, 2008;

(e) "Last census" means the census held in India in 2001;
(j) "Scheduled Castes Orders" means the Constitution (Scheduled Castes) Order,
1950, the Constitution (Scheduled Castes) (Union Territories) Order, 1951, the
Constitution (Dadra and Nagar Haveli) Sheduled Castes Order, 1962 and the
Constitution (Puducherry) Scheduled Castes Order 1964, made by the President under
article 341 of the Constitution;
(g) "Scheduled Tribes Orders" means the Constitution (Scheduled Tribes) Order,
1950, the Constitution (Scheduled Tribes) (Union Territories) Order, 1951, the
Constitution (Scheduled Tribes) (Uttar Pradesh) Order, 1967 and the Constitution
(Sikkim) Scheduled Tribes Order, 1978, made by the President under article 342 of the
Constitution;
(h) "State" includes a Union territory having a Legislative Assembly but does
not include the State of Jammu and Kashmir.
i:s[im<l[ion
population
Scheduled
Castes and
Scheduled
·1ribcs.

of
of

3. (I) As soon as may be after the commencement of this Ordinance, the population as
at the last census, of the Scheduled Castes or, as the case may be, of the Scheduled Tribes,
in each State shall be ascertained or estimated by the Census Commissioner.
(2) Where by reason of the amendments made in the Scheduled Castes Orders and the
Scheduled Tribes Orders after the last census and upto 31 st May, 2012, the population of the
Scheduled Castes or the Scheduled Tribes as at the last census is varied in a State. the
Census Commissioner shall ascertain or estimate as on the 1st day of March, 200 I, the
population of the Scheduled Castes or the Scheduled Tribes so varied, and also ascertain or
estimate the proportion of such population of the Scheduled Castes or the Scheduled Tribes,
respectively, to the total population of the State in the last census.
(3) The population figures ascertained or estimated under sub-section (2) shall be
notified by the Census Commissioner in the Gazette ofIndia.
(4) The population figures so notified shall be taken to be the relevant population
figures as ascertained or estimated at the last census and shall supersede any figures
previously published; and the figures so notified shall be final and shall not be called in
question in any COUl1.

Readjustment
of tcrr itorial
constituencies
by
Commission.

4. (I) After the population figures have been notified for any State under section 3, the
Commission shall make such amendments as may be necessary in the Delimitation Order,
having regard to the provisions of articles 81, 170,330 and 332 of the Constitution, of section
8 of the Delimitation Act, and of this Ordinance, for the purpose of giving proper representation
to the Scheduled Castes or, as the case may be, to the Scheduled Tribes of that State, and the
First Schedule and the Second Schedule to the Representation of the People Act, 1950 shall
be deemed to have been amended accordingly.
(2) In making any amendments in the Delimitation Order under sub-section (1), the
Commission shall, as far as may be necessary, have regard to the provisions of clauses (c)
and (d) of sub-section (I) of section 9 ofthe Del imitation Act.
(3) The Commission shall(a) publish its proposals for the amendments in the Gazette of India and the
Official Gazette of the State concerned and also in such other manner as it thinks fit;

(b) specify a date on or after which such proposals will be further considered by it;
(c) consider all objections and suggestions which may have been received by it
before the date so specified and for such consideration hold one or more public
sittings at such place or places in each State as it thinks fit; and

43 of 1950.

<!-- page 3 -->

SEC.

I]

THB GAZETTE OF INDIA EXTRAORDINARY

3

(d) thereafter make necessary amendments in the Delimitation Order.

5 of 1908.

5. (I) In the discharge of its functions under this Ordinance, the Commission shall
determine its own procedure and shall have all the powers of a civil court under the Code of
Civil Procedure, 1908, while trying a suit, in respect of the following matters, namely:-

Procedure and
powers of
Commission.

(a) summoning and enforcing the attendance of witnesses;
(b) requiring

the production of any document; and

(c) requisitioning any public record from any court or office.

(2) The Commission shall have the power to require any person to furnish any
information on such points or matters as, in the opinion of the Commission, may be useful
for, or relevant to, any matter under the consideration of the Commission.

2 of 1974.

(3) The Commission shall be deemed to be a civil court for the purposes of sections 345
and 346 of the Code of Criminal Procedure, 1973.
Explanation.- For the purposes of enforcing the attendance of witnesses, the local
limits of the jurisdiction of the Commission shall be the limits of the territory ofIndia.
6. (/) The Commission shall cause the amendments made by it in the Delimitation
Order to be published in the Gazette of India and in the Official Gazettes of the States
concerned.
(2) Upon publication in the Gazette of India, every such amendment shall have the
force of law and shall not be called in question in any court.

Publication of
amendments
and their
dates of
operation.

(3) As soon as may be after such publication in the Gazette of India, every such
amendment shall be laid before the House of the People and the Legislative Assembly of the
State concerned.
(4) Subject to the provisions of sub-section (5), the readjustment of seats and territorial
constituencies in the House of the People or in the Legislative Assembly of a State necessitated
by any amendments made by the Commission in the Delimitation Order and provided for in
that Order as so amended shall apply in relation to every election to the House or, as the case
may be, to the Assembly, held after the publication of such amendments in the Gazette of
India and shall so apply in supersession of the provisions relating to representation contained
in the Representation of the People Act, 1950.

43 of 1950.

(5) Nothing contained in the foregoing sub-sections shall affect the representation in
the House of the People Of in the Legislative Assembly of a State until the disolution of the
House or of the Assembly, as the case may be, existing on the date of publication of the
amendments made by the Commission in the Gazette ofIndia.
7. (/) The Commission may, from time to time, by notification in the Gazette oflndia and
in the Official Gazette of the State concerned,-

Certain other
powers of
Commission.

(a) correct any printing mistake in the Delimitation Order as amended under this
Ordinance, or any error occurring therein from any inadvertent slip or omrnission; and
(b) where the boundaries or the name of any district or any territorial division
mentioned in the said Order are or is altered, make such amendments as appear to it to
be necessary or expendient for bringing the Order up-to-date.

(2) Every notification under this section shall be laid, as soon as may be after it is
issued, before the House ofthe People and the Legislative Assembly of the State concerned.
8. All things done, and all steps taken, before the commencement ofthis Ordinance by
the Census Commissioner for the ascertainment or estimation of population of the Scheduled
Castes and the Scheduled Tribes, or by the Commission for the purpose of readjustment of
seats and territorial constituencies shall, insofar as they are in conformity with the provisions
of this Ordinance, be deemed to have been done or taken under these provisions as if such
provisions were in force at the time such things were done or such steps were taken.

Validation of
acts done
previous to
the cornmencernent

of Ordinance.

<!-- page 4 -->

THE GAZETTE OF INDIA EXTRAORDINARY

4
Power

to

remove

difficulties.

[PART

II-SEc. I]

9. (I) If any difficulty arises in giving effect to the provisions of this Ordinance,
the Central Government may, by order published in the Official Gazette, make. such
provisions, not inconsistent with the provisions of this Ordinance, as appear to it to be
necessary or expedient for removing the difficulty.
(2) Every order made under sub-section (J) shall be laid, as soon as may be, after
it is made, before each House of Parliament

PRANAB MUKHERJEE,
President.

P.K.MALHOTRA,
Secy. to the Govt. of India.

PRINTED

BY DIRECTORATE

NEW DELHI

OF PRINTING AT GOVERNMENT

AND PUBLISHED

BY THE CONTROLLER

OF

OF INDIA

PRESS, MINTO ROAD,

PUBLICATIONS,

DELHI,

2013.

GMGIPMRND-4683GI(S3)-31-1-2013.

--_._--
