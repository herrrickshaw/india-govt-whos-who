---
doc_id: "d93fbabd20a89be7"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/11/142f9babc960fe1c3ede05cf4bb532c7.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment of three Advocates for various courts : Order dated 17.05.2023"
date: "2023-05-17"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c8d2e5ad24137027"
---

<!-- page 1 -->

F. No. J-11015/4/2023-Judicial
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
ake
Shastri Bhawan, New Delhi,
Dated the 17" May, 2023
ORDER
With reference to this Department’s Order No. J-11015/1/2020-Judicial dated
06.03.2020 regarding engagement of Advocate for various courts in the State of Madhya
Pradesh, the President is pleased to extend the terms of all the panel counsel whose
names are figuring under List ‘A’, ‘B’ and ‘C’ in the aforesaid order dated 06.03.2020, for
a further period of one year with effect from 06.03.2023 or until further orders,
whichever is earlier.
2. The terms & conditions of the engagement of aforesaid panel counsel will be
governed by this Department's OM No. 27(11)/99-Judl. dated 24.09.1999 (in respect of
panel counsel mentioned under list ‘A’) and OM No. 26(1)/99-Judl. dated 24.09.1999 (in
respect of panel counsel mentioned under List ‘B’ & ‘C’), both to be read separately with
OM No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued subsequently through
OMs especially the OM No. J-16/11/2017-Judicial dated 08.02.2018 imposing certain
restrictions on panel counsel. The aforesaid OMs are available on the website of this
Department i.e. www.legalaffairs.gov.in in the tab ‘Judicial Section’ under heading
‘Circulars pertaining to litigations’.
3. Hindi version of this order will follow, age
pen
(Vijay Kuar Sharht
Joint Secretary & Legal Adviser
Copy (through email) to:-
1, PS to Hon'ble MLJ/ Sr. PPS to Hon’ble MSLJ
2. Sr. PPS to Law Secretary/PSO to AS (RSV)/PSO to AS (RM)/Sr. PPS to AS (ARR)/Sr. PPS to
JS&LA (SA) / PSO to JS&LA (PS)
3. Shri Pushpendra Yadav, Deputy SGI for High Court of Madhya Pradesh (PB) at Jabalpur.
4. Shri Praveen Kumar Newaskar, Deputy SGI for High Court of Madhya Pradesh, Gwalior Bench.
5. Shri Himanshu Joshi, Deputy SGI for High Court of Madhya Pradesh, Indore Bench.
6. The Registrar, High Court of Madhya Pradesh at Jabalpur.
7. The Registrar, Central Administrative Tribunal, Jabalpur Bench.
8. Cash (LA) Section for the payment of retainership fee to Standing Govt. Counsels mentioned in
aforesaid Order dated 06.03.2020 for a Period of one year with effect from 06.03.2023,
9. The Pay & Accounts Office, Department of Legal Affairs, New Delhi
10. One copy of this order is uploaded on website of this Department i.e. www. legalaffairs.gov.in under
tab ‘Judicial Section’ in the link ‘Orders related to empanelment of Advocates for Union of India’ for
the information of all concerned.
11, Hindi unit, Department of Legal Affairs for Hindi translation of the order. Qual
12. Guard File/Judicial Section with 5 Spare copies, ei
4 Jo sf 2.023
(Lakka Muneswara Rao)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
