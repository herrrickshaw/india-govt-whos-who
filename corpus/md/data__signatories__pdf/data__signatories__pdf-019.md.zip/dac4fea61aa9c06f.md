---
doc_id: "dac4fea61aa9c06f"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/115e0697b8678a008bc685c5861409c6.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Re-appointment of Shri K. K. Venugopal, Sr. Advocate as Attorney General for India for further term of three months or until further orders, whichever is earlier: Gazette Notification dated 29.06.2022"
date: "2022-06-29"
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "0632b914ae197a08"
---

<!-- page 1 -->

रिज ी सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-29062022-236898
xxxGIDHxxx
CG-DL-E-29062022-236898
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग I—ख ड 2
PART I—Section 2
ािधकार से कािशत
PUBLISHED BY AUTHORITY
सं. 13
No. 13

नई द ली, बुधवार, जून 29, 2022/ आषाढ़ 8, 1944
NEW DELHI, WEDNESDAY, JUNE 29, 2022/ASHADHA 8, 1944

िविध एवं याय मं ालय
(िविध काय िवभाग)
अिधसूचना
नई द ली, 29 जून, 2022
फा. सं. जे-11011/1/2020- याियक:. — रा पित,

ी के .के .वेणुगोपाल, व र अिधव ा को 1 जुलाई, 2022

से अगले तीन महीने क अविध या अगले आदेश तक, जो भी पहले हो भारत के महा यायवादी के पद पर पुन: िनयु
करते ह।

आर.के . ीवा तव, संयु त सिचव एवं िविध सलाहकार

MINISTRY OF LAW AND JUSTICE
(Department of Legal Affairs)
NOTIFICATION
New Delhi, the 29th June, 2022

F. No. J-11011/1/2020-Judicial:. —The President is pleased to re-appoint Shri K. K. Venugopal, Senior
Advocate as Attorney General for India with effect from 1st July, 2022 for a further period of three months or until
further orders, whichever is earlier.
R.K.SRIVASTAVA, Jt. Secy. & Legal Adviser
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR
VERMA

4332 GI/2022

(1)

Digitally signed by
MANOJ KUMAR VERMA
Date: 2022.06.29
19:03:47 +05'30'
