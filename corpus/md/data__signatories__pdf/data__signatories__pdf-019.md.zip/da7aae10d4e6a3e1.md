---
doc_id: "da7aae10d4e6a3e1"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/09/aaf25bc69036384cc09183184dc9822d.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Corrigendum reg. - AMC for Electrical works"
date: "2015-03-19"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "8f847092f8dd1a9c"
---

<!-- page 1 -->

F.No.A.13012/2/2015 Admn II (LA)
Government of India
Ministry of Law & Justice
Department of Legal Affairs
Dated: 19" March, 2015.
CORRIGENDUM

In partial modification of this Department’s Quotation Notice of even number

dated 10” March. 2015 regarding Annual Maintenance contract for the Servicing,

Maintenance and Upkeep of the Small Electrical work of the Department of Legal Affairs

during the financial year 2015-16 may be read as under:-

Sealed rate quotations are invited from interested firms/ parties for small

Electrical and other miscellaneous and allied jobs as mentioned in the enclosed Annexure

during the year 2015-16 (01.04.2015 to 31 03.2016) in the Department of Legal Affairs.

2. The supply of material will be governed by the following conditions:- supply of material will be governed by the followin conditions:-

(a) The rates quoted in response to this quotation will remain in force for a period one
year from the date of acceptance of terms and conditions for the financial year 2015-
16.

(b) The material to be used for the above purpose should be of branded standard quality.

(c) The rate should be inclusive of delivery charges to this Department in Room No.

413,’A’ Wing, Shastri Bhawan, New Delhi.

(d) The rates should be quoted according to the specifications given in attached __ list.
The rates of sales tax, if chargeable should be mentioned clearly.

(e) One representative of the firm will have to visit this Department daily i.e Monday to
Friday to enquire about the demand or to make delivery. Telephone number/ mobile
number of the firm should be indicated for urgent communication.

(f) In case of short/late supply or/ non-compliance of any order to this Department or in
the event of unsatisfactory performance, the contract can be terminated at any time
without assigning any reasons at the cost and risk of the firm.

(9) This Department shall not be bound to accept the lowest rates and an order may be
placed with any other firm considered suitable for the work. The decision of the
competent Authority in this Department will be final in this regard.

3. The quotation should be sent (by name) to the undersigned in a sealed cover
marked “QUOTATION ANNUAL MAINTENANCECONTRACT FOR’ THE
SERVICING MAINTENANCE AND UPKEEP OF THE SAMLL ELECTRICAL WORK
OF THE DEPARTMENT OF LEGAL AFFAIRS DURING THE FINANCIAL YEAR
2015-16” in Room No. 413, A Wing Shastri Bhawan, Dr .Rajendra Prasad Road
New Delhi latest by 20" March 2015 at 3.30.P.M. The quotation will be opened on
the same day at 4.00 P.M. Further details, if any, can be obtained from Section
Officer, Admn. Il (LA), Room No. 413, A Wing, Shastri Bhawan, New Delhi.
(Telephone - 23384837).

॥ 2-2

(Mata Prasad)

Section Officer
Copy to :- Technical Director, NIC with a request to upload in the Department Website.
