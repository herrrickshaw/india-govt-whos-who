---
doc_id: "dba88badaf99986d"
source_url: "https://www.dot.gov.in/static/uploads/2025/12/4ecb5f1e48a578ce883a92226d9b237d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Office Order reg. Confirmaton of completion of probation period of probationers of ITS 2022 - Promotee batch in the grade of Junior Time Scale of ITS Group A"
date: "2025-12-24"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "463007db0489b342"
---

<!-- page 1 -->

8-6/2025-STG-II

I/3329882/2025

F.No.8-6/2025-STG-II
Government of India / भारत सरकार
Ministry of Communications / संचार मं ालय
Department of Telecommunications / दरू संचार िवभाग
Sanchar Bhawan, 20, Ashoka Road,
New Delhi, dated the October 31 , 2025
OFFICE ORDER
The President is please to conﬁrm the completion of probation period of
following probationers of ITS-2022 (Promotee) batch in the grade of Junior Time
Scale (JTS) of ITS Group ‘A’ with effect from the dates mentioned against each:
S.
No

Staff
No

Name
( S/Shri/Ms.)

Category Date of Confirmation in grade of
JTS

1

60051 Santhapuri Prasad

UR

30.12.2024

2

60053 Rajesh Kumar

UR

30.12.2024

3

60055 Jyoti Sengar

UR

31.12.2024

4

60056 Prakash Kumar

UR

30.12.2024

5

60030 Vivekanand Kumar

OBC

30.12.2024

6

60031 Jay Pal Singh

OBC

30.12.2024

7

60032 Mohammad Faraz
Akhtar

OBC

30.12.2024

8

60041 Ashutosh Dhawan

SC

30.12.2024

9

60079 Chandan Kumar

UR/
PwBD

31.12.2024

2.

This is issued with the approval of competent authority.

(Bijender Singh)/(िबजे सह)
Under Secretary to the Govt. of India/अवर स चव
Ph. No: 2303-6282
Copy to:
1. PPS to Hon’ble MoC/MoSC
2. PSO to Secretary (T)
3. PPS to Member (S)/Member (T)/Member (F)/DG (telecom)
4. PPS to Addl. Secy (T)/Advisor (O)/Advisor (T)
5. Heads of LSAs/TEC/NCA-T/NCCS

<!-- page 2 -->

8-6/2025-STG-II

I/3329882/2025

6. All DDGs DoT Hqrs
7. Admn I-IV/Cash/Pension/Library/G-I/G-II/Vig.I DoT Hqrs
8. ADG(STG-I) / AAO (STG-I) – for updating in service book.
9. Pay Bill Section DoT Hqrs
10. Officers concerned- through uploading on DoT Website.
11. PA to US (SGT) – for uploading on the website of DoT
12. Order Bundle.
13. OL Section for Hindi version of the order.
