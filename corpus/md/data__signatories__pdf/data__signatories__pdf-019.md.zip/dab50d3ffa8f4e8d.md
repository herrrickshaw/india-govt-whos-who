---
doc_id: "dab50d3ffa8f4e8d"
source_url: "https://socialjustice.gov.in/public/ckeditor/upload/44641758177828.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "The Constitution (Scheduled Castes) Order, 1950 (updated upto 18-09-2025)"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3c80b37d1d86e504"
---

<!-- page 1 -->

1

THE CONSTITUTION (SCHEDULED CASTES) ORDER, 1950
C.O. 19

In exercise of the powers conferred by clause (1) of article 341 of the Constitution of India, the
President, after consultation with the Governors and Rajpramukhs of the States concerned, is pleased to
make the following Order, namely:—
1.

This Order may be called the Constitution (Scheduled Castes) Order, 1950.

2. Subject to the provisions of this Order, the castes, races or tribes or parts of, or groups within, castes
or tribes specified in 2[Parts I to 3[XXV]] of the Schedule to this Order shall, in relation to the States to
which those Parts respectively relate, be deemed to be Scheduled Castes so far as regards member thereof
resident in the localities specified in relation to them in those Parts of that Schedule.
4

[3. Notwithstanding anything contained in paragraph 2, no person who professes a religion different
from the Hindu, 5[ the Sikh or the Buddhist] religion shall be deemed to be a member of a Scheduled
Caste.]
6

[4. Any reference in this Order to a State or to a district or other territorial division thereof shall be
construed as a reference to the State, district or other territorial division as constituted on the 1st day of
May, 1976.]

1. Published with the Ministry of Law Notification No. S.R.O. 385,
dated the 10th August, 1950, Gazette of India, Extraordinary,
1950, Part II, Section 3, page 163.
2. Subs. by the Scheduled Castes and Scheduled Tribes Lists
(Modification) Order, 1956.
3. The figure “XXI” has been successively subs. by Act 18 of 1987,
s. 19 and 1st Sch. (w.e.f. 30-5-87), by Act 28 of 2000, s. 19 and
3rd Sch (w.e.f. 1-11-2000) and by Act 29 of 2000, s. 24 and 5th
Sch. (w.e.f. 9-11-2000) and by Act 6 of 2014, s. 28 and 5th Sch.(
w.e.f.2.6.2014 ) to read as above.

4. Subs. by Act 63 of 1956, s. 3 and First Sch., for paragraph 3.
5. Subs. by Act 15 of 1990, s. 2, for "or the Sikh".
6. Subs. by Act 108 of 1976, s. 3 and the First Sch., for paragraph 4
(w.e.f. 27-7-1977).

<!-- page 2 -->

1

[THE SCHEDULE

PART I. - Andhra Pradesh
1. Adi Andhra
31. Madasi Kuruva, Madari Kuruva
2. Adi Dravida
32. Madiga
3. Anamuk
33. Madiga Dasu, Mashteen
4. Aray Mala
34. Mahar
3
5. Arundhatiya
[35. Mala, Mala Ayawaru]
6. Arwa Mala
36. Mala Dasari
7. Bariki
37. Mala Dasu
8. Bavuri
38. Mala Hannai
2
***
39. Malajangam
10. Bindla
40. Mala Masti
3
[11. Byagara, Byagari]
41. Mala Sale, Netkani
12. Chachati
42. Mala Sanyasi
13. Chalavadi
43. Mang
3
[14. Chamar, Mochi, Muchi, Chamar-Ravidas, Chamar- 44. Mang Garodi
Rohidas]
45. Manne
15. Chambhar
46. Mashti
16. Chandala
47. Matangi
17. Dakkal, Dokkalwar
48. Mehtar
18. Dandasi
49. Mitha Ayyalvar
19. Dhor
50. Mundala
20. Dom, Dombara, Paidi, Pano
51. Paky, Moti, Thoti
4
21. Ellamalawar, Yellammalawandlu
***
22. Ghasi, Haddi, Relli Chachandi
53. Pamidi
3
[23.Godagali,
Godagula(in
the
districts
of 54. Panchama, Pariah
Srikakulam,Vizianagaram and Vishakhapatanam)]
55. Relli
24. Godari
56. Samagara
25. Gosangi
57. Samban
26. Holeya
58. Sapru
27. Holeya Dasari
59. Sindhollu, Chindollu
5
28. Jaggali
[60. Yatala
29. Jambuvulu
61. Valluvan.]
3
[30. Kolupulavandlu, Pambada, Pambanda, Pambala]
PART II. – Assam
1. Bansphor
9. Kaibartta, Jaliya
2. Bhuinmali, Mali
10. Lalbegi
3. Brittial Bania, Bania
11. Mahara
4. Dhupi, Dhobi
12. Mehtar, Bhangi
5. Dugla, Dholi
13. Muchi, Rishi
6. Hira
14. Namasudra
7. Jalkeot
15. Patni
8. Jhalo, Malo, Jhalo-Malo
16. Sutradhar.
_____________________________________________________________________________________
1. Subs. by Act 108 of 1976, s. 3 and the First Sch., for the former Sch. (w.e.f. 27-7-1977).
2. Omitted by s.28 and 5th Sch.of Act 6 of 2014.
3. Subs. by Act 61 of 2002, s. 2 and the First Sch.
4. Omitted by s. 2 and the First Sch., ibid.
5. Ins. by s. 2 and the First Sch., ibid.

<!-- page 3 -->

PART III.— Bihar
1. Bantar
2. Bauri
3. Bhogta
4. Bhuiya
5. Bhumij 1***
2[6.Chamar,
Mochi, Chamar-Rabidas, Chamar
Ravidas, Chamar-Rohidas, Charmarkar]
7. Chaupal
8. Dabgar
2
[9. Dhobi, Rajak]
2
[10. Dom, Dhangad, Bansphor, Dharikar, Dharkar,
Domra]
11. Dusadh, Dhari, Dharhi

12. Ghasi
13. Halalkhor
14. Hari, Mehtar, Bhangi
15. Kanjar
16. Kurariar
17. Lalbegi
18. Musahar
19. Nat
2
[20. Pan, Sawasi, Panr]
21. Pasi
22. Rajwar
23. Turi.

PART IV.—Gujarat
1. Ager
18. Mahyavansi, Dhed, Dhedh, Vankar, Maru
2. Bakad, Bant
Vankar, Antyaj
3. Bawa-Dedh, Dedh-Sadhu
19. Mang, Matang, Minimadig
2
[4. Bhambi, Bhambhi, Asadaru, Asodi, Chamadia, 20. Mang-Garudi
Chamar, Chamar-Ravidas, Chambhar, Chamgar, 21. Meghval, Meghwal, Menghvar
Haralayya, Harali, Khalpa, Machigar, Mochigar, 22. Mukri
Madar, Madig, Mochi (in Dangs district and 23. Nadia, Hadi
Umergaon Taluka of Valsad district only), 24. Pasi
Nalia, Telegu Mochi, Kamati Mochi, Ranigar, 25. Senva, Shenva, Chenva, Sedma, Rawat
Rohidas, Rohit, Samgar]
26. Shemalia
2
[5. Bhangi, Mehtar, Olgana, Rukhi, Malkana, 27. Thori
Halalkhor, Lalbegi, Balmiki, Korar, Zadmalli, 28. Tirgar, Tirbanda
Barwashia, Barwasia, Jamphoda, Zampada, 29. Turi
Zampda, Rushi, Valmiki]
30. Turi Barot, Dedh Barot.
3
6. Chalvadi, Channayya
[31. Balahi, Balai
7. Chenna Dasar, Holaya Dasar
32. Bhangi, Mehtar
8. Dangashia
33. Chamar
9. Dhor, Kakkayya, Kankayya
34. Chikwa, Chikvi
10. Garmatang
35. Koli, Kori
11. Garoda, Garo
36.Kotwal (in Bhind, Dhar, Dewas, Guna, Gwalior,
12. Halleer
Indore, Jhabua, Khargone, Mandsaur, Morena,
13. Halsar, Haslar, Hulasvar, Halasvar
Rajgarh, Ratlam, Shajapur, Shivpuri, Ujjain
14. Holar, Valhar
and Vidisha districts)].
15. Holaya, Holer
16. Lingader
17. Mahar, Taral, Dhegu Megu
____________________________________________________________________________________
1. Certain words omitted by Act 30 of 2000, s. 23 and the Fifth Sch. (w.e.f. 15-11-2000).
2. Subs. by Act 61 of 2002, s. 2 and the First Sch.,
3. Ins. by Act 32 of 2002, s. 2.

<!-- page 4 -->

PART V.— Haryana
4
1. Ad Dharmi
[19. Kabirpanthi, Julaha , Kabirpanthi Julaha]
1
[1A. Aheria, Aheri, Hari, Heri, Thori, Turi]
20. Khatik
2. Balmiki, Chura, Bhangi
21. Kori, Koli
3. Bangali
22. Marija, Marecha
4. Barar, Burar, Berar
3 [23. Mazhabi, Mazhabi Sikh]
2
2
[5. Batwal, Barwala]
[24. Megh, Meghwal]
6. Bauria, Bawaria
3 [25. Nat, Badi]
7. Bazigar
26. Od
8. Bhanjra
27. Pasi
3
[9.Chamar, Jatia Chamar, Rehgar, Raigar, Ramdasi, 28. Perna
Ravidasi, Balahi, Batoi, Bhatoi, Bhambi, Chamar- 29. Pherera
1
Rohidas, Jatav, Jatava, Mochi, Ramdasia]
[29A. Rai Sikh]
10. Chanal
30. Sanhai
11. Dagi
31. Sanhal
12. Darain
32. Sansi, Bhedkut, Manesh
13. Deha, Dhaya, Dhea
33. Sansoi
3
14. Dhanak
[34. Sapela, Sapera]
15. Dhogri, Dhangri, Siggi
35. Sarera
3
16. Dumna, Mahasha, Doom
[36. Sikligar, Bariya]
17. Gagra
37. Sirkiband.
18. Gandhila, Gandil Gondola
PART VI.— Himachal Pradesh

1. Ad Dharmi
29. Hesi
2. Badhi, Nagalu
30. Jogi
3. Balmiki, Bhangi, Chuhra, Chura, Chuhre
31. Julaha, Julahe, Kabirpanthi, Keer
4. Bandhela
32. Kamoh, Dagoli
5. Bangali
33. Karoack
6. Banjara
34. Khatik
7. Bansi
35. Kori, Koli
8. Barad
36. Lohar
9. Barar, Burar, Berar
37. Marija, Marecha
10. Batwal
38. Mazhabi
11. Bauria, Bawaria
39. Megh
12. Bazigar
40. Nat
13. Bhanjra, Bhanjre
41. Od
14.Chamar, Jatia Chamar, Rehgar, Raigar, Ramdasi, 42. Pasi
Ravidasi, Ramdasia, Mochi
43. Perna
15. Chanal
44. Phrera, Pherera
16. Chhimbe, Dhobi
45. Rehar, Rehara
17. Dagi
46. Sanhai
18. Darain
47. Sanhal
19. Darai, Daryai
48. Sansi, Bhedkut, Manesh
20. Daule, Daole
49. Sansoi
21. Dhaki, Toori
50. Sapela
22. Dhanak
51. Sarde, Sarera, Sarare, Siryare, Sarehde
23. Dhaogri, Dhuai
52. Sikligar
24. Dhogri, Dhangri, Siggi
53. Sipi
25. Doom, Doomna, Dumna, Dumne, Mahasha
54. Sirkiband
26. Gagra
55. Teli
27. Gandhila, Gandil Gondola
56. Thathiar, Thathera
5
28. Hali
[57. Barwala]
_____________________________________________________________________________________________
1. Ins. by s.2 of Act 24 of 2016.
2. Subs. by Act 31 of 2007, s. 2.
3. Subs. by Act 61 of 2002, s. 2 and the First Sch.,

4. Subs. by Act 4 of 2015, s.2.
5. Ins. by s. 2 and the First Sch of Act 61 of 2002.

<!-- page 5 -->

1

[PART VIA.—Jharkhand

1. Bantar
2. Bauri
2
. ***
4. Bhuiya
5. Chamar, Mochi
6. Chaupal
7. Dabgar
8. Dhobi
9. Dom, Dhangad
10. Dusadh, Dhari, Dharhi
11. Ghasi

12. Halalkhor
13. Hari, Mehtar, Bhangi
14. Kanjar
15. Kurariar
16. Lalbegi
17. Musahar
18. Nat
19. Pan, Sawasi
20. Pasi
21 Rajwar
22. Turi.]
PART VII. – Karnataka

1. Adi Andhra
2. Adi Dravida
3. Adi Karnataka
4. Adiya (in Coorg district)
5. Ager
6. Ajila
7. Anamuk
8. Aray Mala
9. Arunthathiyar
10. Arwa Mala
11. Baira
12. Bakad
13. Bant (In Belgaum, Bijapur, Dharwar and North
Kanara districts)
14. Bakuda
15. Balagai
16. Bandi
3
[17. Banjara, Lambani, Lambada, Lambadi,
Lamani, Sugali, Sukali]
18. Bathada
19. Beda Jangam, Budga Jangam
20. Bellara
21. Bhangi, Mehtar, Olgana, Rukhi, Malkana,
Halalkhor, Lalbegi, Balmiki, Korar, Zadmalli
22. Bhambi, Bhambhi, Asadaru, Asodi, Chamadia,
Chamar, Chambhar, Chamgar, Haralayya,
Harali, Khalpa, Machigar, Mochigar, Madar,
Madig, Mochi, Muchi, Telegu Mochi, Kamati
Mochi, Ranigar, Rohidas, Rohit, Samgar
4
[23. Bhovi, Od , Odde, Vaddar, Waddar, Voddar,
Woddar, Bovi ( Non-Besta), Kalluvaddar,
Mannuvaddar]
24. Bindla
25. Byagara
26. Chakkiliyan

27. Chalavadi, Chalvadi, Channayya
28. Chandala
29. Chenna Dasar, Holaya Dasar
30. Dakkal, Dokkalwar
31. Dakkaliga
32. Dhor, Kakkayya, Kankayya
33. Dom, Dombara, Paidi, Pano
34. Ellamalwar, Yellammalawandlu
35. Ganti Chores
36. Garoda, Garo
37. Godda
38. Gosangi
39. Halleer
40. Halsar, Haslar, Hulasvar, Halasvar
41. Handi Jogis
42. Hasla
43. Holar, Valhar
44. Holaya, Holer, Holeya
45. Holeya Dasari
46. Jaggali
47. Jambuvulu
48. Kadaiyan
49. Kalladi
50. Kepmaris
51. Kolupulvandlu
52. Koosa
3
[53. Koracha, Korachar
54. Korama, Korava, Koravar]
55. Kotegar, Metri
56. Kudumban
57. Kuravan
58. Lingader
59. Machala

_____________________________________________________________________________________________
1. Ins. by Act 30 of 2000, s. 23 and the Fifth Sch. (w.e.f. 15-11-2000).
2.Omitted by Act 8 of 2022, s.2.
3. Subs. by Act 61 of 2002, s. 2 and the First Sch.,
4. Subs. by Act 4 of 2015, s.2. for entry 23

<!-- page 6 -->

60. Madari
61. Madiga
62. Mahar, Taral, Dhegu Megu
63.Mahyavanshi, Dhed, Vankar, Maru Vankar
64. Maila
65. Mala
66. Mala Dasari
67. Mala Hannai
68. Mala Jangam
69. Mala Masti
70. Mala Sale, Netkani
71. Mala Sanyasi
72. Mang, Matang, Minimadig
73. Mang Garudi, Mang Garodi
74. Manne
75. Masthi
76. Mavilan
77. Meghval, Menghvar
78. Moger
79. Mukri
80. Mundala

81. Nadia, Hadi
82. Nalkadaya
83. Nalakeyava
84. Nayadi
85. Pale
86. Pallan
87. Pambada
88. Panchama
89. Panniandi
90. Paraiyan, Paraya
91. Paravan
92. Raneyar
93. Samagara
94. Samban
95. Sapari
96. Sillekyathas
97. Sindhollu, Chindollu
98. Sudugadu Siddha
99. Thoti
100. Tirgar, Tirbanda
101. Valluvan.

PART VIII. – Kerala
1. Adi Andhra
2. Adi Dravida
3. Adi Karnataka
4. Ajila
5. Arunthathiyar
6. Ayyanavar
7. Baira
8. Bakuda
1
***
10. Bathada
1
***
2
[12. Bharathar (other than Parathar), Paravan]
1
***
14. Chakkiliyan
15. Chamar, Muchi
16. Chandala
17. Cheruman
18. Domban
1
***
1
***
22. Gosangi

23. Hasla
24. Holeya
25. Kadaiyan
2
[26. Kakkalan, Kakkan]
27. Kalladi
2
[28. Kanakkan, Padanna, Padannan]
3
***
2
[30. Kavara (other than Telugu speaking or Tamil
speaking Balija, Kavarai, Gavara, Gavarai,
Gavarai Naidu, Balija Naidu, Gajalu Balija or
Valai Chetty)]
31. Koosa
32. Kootan, Koodan
33. Kudumban
2
[34. Kuravan, Sidhanar, Kuravar, Kurava, Sidhana]
35. Maila
4
[36. Malayan [in the areas comprising the Kannur,
Kasaragode, Kozhikode and Wayanad districts)
37.Mannan, Pathiyan, Perumannan, Peruvannan,
Vannan, Velan]
4

_____________________________________________________________________________________
1. Omitted by Act, 61 of 2002, s.2 and First Sch.
2. Subs by s. 2 and First Sch. ibid.
3. Omitted by Act 10 of 2003 s.3 and the First Sch.
4. Subs. by Act 24 of 2016, s.2.

<!-- page 7 -->

1

***
2
[39. Moger (other than Mogeyar)]
40. Mundala
41. Nalakeyava
42. Nalkadaya
43. Nayadi
3
***
45. Pallan
4
[46. Palluvan,Pulluvan]
47. Pambada
48. Panan
3
***
2
[50. Paraiyan, Parayan, Sambavar, Sambavan,
Sambava, Paraya, Paraiya, Parayar]
3
***
3
***
3
***
2
[54.Pulayan, Cheramar, Pulaya, Pulayar, Cherama,
Cheraman, Wayanad Pulayan, Wayanadan
Pulayan, Matha, Matha Pulayan]

3

***
56. Puthirai Vannan
57. Raneyar
58. Samagara
59. Samban
2
[60. Semman, Chemman, Chemmar]
4
[61. Thandan (excluding Ezhuvas and Thiyyas who
are known as Thandan, in the erstwhile Cochin
and Malabar areas) and (Carpenters who are
known as Thachan, in the erstwhile Cochin and
Travancore State), Thachar (other than
carpenter)]
62. Thoti
63. Vallon
64. Valluvan
3
** *
3
***
67. Vetan
2
[68. Vettuvan, Pulaya Vettuvan (in the areas of
erstwhile Cochin State only)
69. Nerian]

PART IX.— Madhya Pradesh
1.Audhelia
5
[2. Bagri, Bagdi (excluding Rajput, Thakur subcastes among Bagri, Bagdi]
3. Bahna, Bahana
4. Balahi, Balai
5. Banchada
6. Barahar, Basod
7. Bargunda
8. Basor, Burud, Bansor, Bansodi, Bansphor, Basar
9. Bedia
10. Beldar, Sunkar
11. Bhangi, Mehtar, Balmik, Lalbegi, Dharkar
12. Bhanumati
13. Chadar
14. Chamar, Chamari, Bairwa, Bhambi, Jatav,
Mochi, Regar, Nona, Rohidas, Ramnami,
Satnami,Surjyabanshi,surjyaramnami, Ahirwar,
Chamar Mangan, Raidas

15. Chidar
16. Chikwa, Chikvi
17. Chitar
4
[18. Dahait, Dahayat, Dahat ,Dahiya]
19. Dewar
20. Dhanuk
21. Dhed, Dher
22. Dhobi (in Bhopal, Raisen and Sehore distircts)
23. Dohor
24. Dom, Dumar, Dome, Domar, Doris
25. Ganda, Gandi
26. Ghasi, Ghasia

1. Omitted by Act 10 of 2003 s.3 and the First Sch.
2. Subs. by Act, 61 of 2002, s.2 and First Sch
3. Omitted by s.2 and First Sch ibid.

4. Subs. by Act 34 of 2014, s.2.
5. Subs by Act 31 of 2007, s.2,

27. Holiya
28. Kanjar
29. Katia, Patharia
30. Khatik
31. Koli, Kori

<!-- page 8 -->

32.Kotwal (in Bhind, Dhar, Dewas, Guna, Gwalior,
Indore, Jhabua, Khargone, Mandsaur, Morena,
Rajgarh, Ratlam, Shajapur, Shivpuri, Ujjain and
Vidisha districts)
33. Khangar, Kanera, Mirdha
34. Kuchbandhia
35. Kumhar (in Chhatarpur, Datia, Panna, Rewa, Satna,
Shahdol, Sidhi and Tikamgarh districts)
1
[36. Mahar, Mehra, Mehar, Mahara]
37. Mang, Mang Garodi, Mang Garudi, Dankhni Mang,
Mang Mahasi, Madari, Garudi, Radhe Mang
38. Meghwal
39. Moghia

40. Muskhan
41. Nat, Kalbelia, Sapera, Navdigar, Kubutar
42. Pardhi (in Bhind, Dhar, Dewas, Guna, Gwalior,
Indore, Jhabua, Khargone, Mandsaur, Morena,
Rajgarh, Ratlam, Shajapur, Shivpuri, Ujjain and
Vidisha distircts)
43. Pasi
44. Rujjhar
45. Sansi, Sansia
46. Silawat
47. Zamral
2
[48. Sargara]

PART X.—Maharashtra
1. Ager
28.Kaikadi (in Akola, Amravati, Bhandara, Buldana,
2. Anamuk
Nagpur, Wardha and Yavatmal districts and
3. Aray Mala
Chandrapur district, other than Rajura tahsil)
4. Arwa Mala
29. Katia, Patharia
5. Bahna, Bahana
30. Khangar, Kanera, Mirdha
6. Bakad, Bant
31. Khatik, Chikwa, Chikvi
7. Balahi, Balai
32. Kolupulvandlu
3
[8. Basor, Burud, Bansor, Bansodi, Basod]
33. Kori
9. Beda Jangam, Budga Jangam
34. Lingader
10. Bedar
35. Madgi
3
[11.Bhambi, Bhambhi, Asadaru, Asodi, Chamadia, 36. Madiga
Chamar, Chamari, Chambhar, Chamgar, Haralayya, 37. Mahar, Mehra, Taral, Dhegu Megu
Harali, Khalpa, Machigar, Mochigar, Madar, 38. Mahyavanshi, Dhed, Vankar, Maru Vankar
Madig, Mochi, Telegu Mochi, Kamati Mochi, 39. Mala
Ranigar, Rohidas, Nona, Ramnami, Rohit, Samgar, 40. Mala Dasari
Samagara, Satnami, Surjyabanshi, Surjyaramnami, 41. Mala Hannai
Charmakar, Pardeshi Chamar;
42. Mala Jangam
12. Bhangi, Mehtar, Olgana, Rukhi, Malkana, Halalkhor, 43. Mala Masti
Lalbegi, Balmiki, Korar, Zadmalli, Hela.]
44. Mala Sale, Netkani
13. Bindla
45. Mala Sanyasi
14. Byagara
46.Mang, Matang, Minimadig, Dankhni Mang, Mang
15. Chalvadi, Channayya
Mahashi, Madari, Garudi, Radhe Mang
16. Chenna Dasar, Holaya Dasar, Holeya Dasari
47. Mang Garodi, Mang Garudi
17. Dakkal, Dokkalwar
48. Manne
18. Dhor, Kakkayya, Kankayya, Dohor
49. Mashti
19. Dom, Dumar
50. Meghval, Menghvar
20. Ellamalvar, Yellammalawandlu
51. Mitha Ayyalvar
21. Ganda, Gandi
52. Mukri
22. Garoda, Garo
53. Nadia, Hadi
23. Ghasi, Ghasia
54. Pasi
24. Halleer
55. Sansi
25. Halsar, Haslar, Hulasvar, Halasvar
56. Shenva, Chenva, Sedma, Ravat
26. Holar, Valhar
57. Sindhollu, Chindollu
27. Holaya, Holer, Holeya, Holiya
58. Tirgar, Tirbanda
59. Turi.
_____________________________________________________________________________________
1. Subs. by Act 61 of 2002, s. 2 and First Sch.
2. Ins. by s.2 and First Sch. ibid.
3.Subs. by Act 31 of 2007, s. 2.

<!-- page 9 -->

1. Dhupi, Dhobi
2. Lois
3. Muchi, Ravidas
4. Namasudra

PART XI.—Manipur
5. Patni
6. Sutradhar
7. Yaithibi
PART XII.—Meghalaya

1. Bansphor
2. Bhuinmali, Mali
3. Brittial Bania, Bania
4. Dhupi, Dhobi
5. Dugla, Dholi
6. Hira
7. Jalkeot
8. Jhalo, Malo, Jhalo-Malo

9. Kaibartta, Jaliya
10. Lalbegi
11. Mahara
12. Mehtar, Bhangi
13. Muchi, Rishi
14. Namasudra
15. Patni
16. Sutradhar.

PART XIII.—1[Odisha]
6
1. Adi Andhra
[26. Dhoba, Dhobi, Rajak, Rajaka
1
[2. Amant, Amat, Dandachhatra Majhi, 27. Dom, Dombo, Duria Dom, Adhuria Dom,
Amata, Amath]
Adhuria Domb]
3. Audhelia
28. Dosadha
4. Badaik
29. Ganda
5. Bagheti, Baghuti
30. Ghantarghada, Ghantra
6. Bajikar
31. Ghasi, Ghasia
7. Bari
32. Ghogia
2
***
33. Ghusuria
9. Basor, Burud
34. Godagali
3
[10. Bauri, Buna Bauri, Dasia Bauri]
35. Godari
11. Bauti
36. Godra
12. Bavuri
37. Gokha
1
[13. Bedia, Bejia, Bajia ]
38. Gorait, Korait
14. Beldar
39. Haddi, Hadi, Hari
15. Bhata
40. Irika
1
16. Bhoi
[41. Jaggali, Jaggili, Jagli ]
4
17. Chachati
[42. Kandra, Kandara, Kadama, Kuduma,
18. Chakali
Kodma, Kodama]
4
[19.Chamar,Chamara,Chamar-Ravidas,
43. Karua
Chamar-Rohidas, Mochi, Muchi, Satnami] 6[44. Katia, Khatia
20. Chandala
45. Kela, Sapua Kela, Nalua Kela, Sabakhia
21. Chandhai Maru
Kela, Matia Kela, Gaudia Kela
5
***
46. Khadala , Khadal, Khodal]
23. Dandasi
47. Kodalo, Khodalo
3
[24. Dewar, Dhibara, Keuta, Kaibarta]
48. Kori
2
25. Dhanwar
***
50. Kurunga
______________________________________________________________________________
1. Subs. by Act 34 of 2014, s.2.
2. Omitted by Act 24 of 2016, s. 2.
3. Subs. by Act 61 of 2002, s. 2 and the First Sch.

4. Subs. by Act, 31 of 2007, s.2.
5. Omitted by Act 25 of 2002, s. 2.
6. Subs, by Act. 4 of 2015,s.2.

<!-- page 10 -->

51. Laban
52. Laheri
53. Madari
54. Madiga
55. Mahuria
1
[56. Mala, Jhala, Malo, Zala, Malha, Jhola]
57. Mang
58. Mangan
59. Mehra, Mahar
60. Mehtar, Bhangi
61. Mewar
62. Mundapotta
63. Musahar
64. Nagarchi
65. Namasudra
66. Paidi
67. Painda
68. Pamidi
2
[69. Pan, Pano, Buna Pana, Desua Pana, Buna Pano]
70. Panchama
71. Panika
72. Panka

73. Pantanti
74. Pap
75. Pasi
76. Patial, Patikar, Patratanti, Patua
77. Rajna
78. Relli
3
[79. Sabakhia, Sualgiri, Swalgiri]
80. Samasi
81. Sanei
82. Sapari
83. Sauntia, Santia
84. Sidhria
85. Sinduria
1[86. Siyal, Khajuria]
87. Tamadia
88. Tamudia
89. Tanla
4
***
5
[91. Turi, Betra ]
92. Ujia
93. Valamiki, Valmiki
6
[94. Mangali (in Koraput and Kalahandi districts)
95. Mirgan (in Navrangpur districts).]

PART XIV.—Punjab
1. Ad Dharmi
20. Khatik
2. Balmiki, Chura, Bhangi
21. Kori, Koli
3. Bangali
22. Marija, Marecha
1
4. Barar, Burar, Berar
[23. Mazhabi, Mazhabi Sikh]
1
[5. Batwal, Barwala]
24. Megh
6. Bauria, Bawaria
25. Nat
7. Bazigar
26. Od
8. Bhanjra
27. Pasi
7
[9.Chamar, Jatia Chamar, Rehgar, Raigar, Ramdasi, 28. Perna
Ravidasi, Ramdasia, Ramdasia Sikh, Ravidasia, 29. Pherera
Ravidasia Sikh]
30. Sanhai
10. Chanal
31. Sanhal
11. Dagi
32. Sansi, Bhedkut, Manesh
12. Darain
33. Sansoi
13. Deha, Dhaya, Dhea
34. Sapela
14. Dhanak
35. Sarera
15. Dhogri, Dhangri, Siggi
36. Sikligar
16. Dumna, Mahasha, Doom
37. Sirkiband.
6
17. Gagra
[38. Mochi.]
8
18. Gandhila, Gandil Gondola
[39. Mahatam, Rai Sikh]
19. Kabirpanthi, Julaha

1. Subs. by Act 61 of 2002, s. 2 and the First Sch.,
2. Subs. by Act 34 of 2014, s.2.
3. Subs. by Act 17 of 2017, s.2.
4. Omitted by Act 25 of 2002, s. 2.
5. Subs, by Act., 4 of 2015, s.2.

6.Ins. by Act 25 of 2002, s. 2.
7. Subs. by Act 25 of 2002, s. 2.
8, Ins. by Act, 31 of 2007, s.2.

<!-- page 11 -->

PART XV. — Rajasthan
1. Adi Dharmi
2. Aheri
3. Badi
4. Bagri, Bagdi
5. Bairwa, Berwa
6. Bajgar
7. Balai
8. Bansphor, Bansphod
9. Baori
10. Bargi, Vargi, Birgi
11. Bawaria
12. Bedia, Beria
13. Bhand
14.Bhangi, Chura, Mehtar, Olgana, Rukhi, Malkana,
Halalkhor, Lalbegi, Balmiki, Valmiki, Korar,
Zadmalli
15. Bidakia
16. Bola
17.Chamar, Bhambhi, Bambhi, Bhambi, Jatia, Jatav,
Jatava, Mochi, Raidas, Rohidas, Regar, Raigar,
Ramdasia, Asadaru, Asodi, Chamadia, Chambhar,
Chamgar, Haralayya, Harali, Khalpa, Machigar,
Mochigar, Madar, Madig, Telugu Mochi, Kamati
Mochi, Ranigar, Rohit, Samgar
18. Chandal
19. Dabgar
20. Dhanak, Dhanuk
21. Dhankia
22. Dhobi
23. Dholi
24. Dome, Dom
25. Gandia
26. Garancha, Gancha

27. Garo, Garura, Gurda, Garoda
28. Gavaria
29. Godhi
30. Jingar
31. Kalbelia, Sapera
32. Kamad, Kamadia
33. Kanjar, Kunjar
34. Kapadia Sansi
35. Khangar
36. Khatik
37. Koli, Kori
38. Kooch Band, Kuchband
39. Koria
40 Madari, Bazigar
41. Mahar, Taral, Dhegumegu
42. Mahyavanshi, Dhed, Dheda, Vankar, Maru Vankar
43. Majhabi
44. Mang, Matang, Minimadig
45. Mang Garodi, Mang Garudi
46. Megh, Meghval, Meghwal, Menghvar
47. Mehar
48 Nat, Nut
49. Pasi
50. Rawal
51. Salvi
52. Sansi
53. Santia, Satia
54. Sarbhangi
55. Sargara
56. Singiwala
57. Thori, Nayak
58. Tirgar, Tirbanda
59. Turi.

PART XVI.—Tamil Nadu
1. Adi Andhra
2. Adi Dravida
3. Adi Karnataka
4. Ajila
5. Arunthathiyar
6. Ayyanavar (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)
7. Baira
8. Bakuda
9. Bandi
10. Bellara
11.Bharatar (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)
12. Chakkiliyan
13. Chalavadi
14. Chamar, Muchi
15. Chandala
16. Cheruman
1. Subs. by Act 18 of 2021, s. 2 ,
2. Subs. by Act 18 of 2021, s.2.

1

[17.
Devendrakula
Velalar{Devendrakulathan,
Kadaiyan,(excluding in the coastal areas of Tirunelveli,
Thoothukudi, Ramanathapuram, Pudukottai, Thanjavur,
Tiruvarur and Nagapattinam districts), Kalladi,
Kudumban, Pallan, Pannadi, Vathiriyan]
18. Dom, Dombara, Paidi, Pano
19. Domban
20. Godagali
21. Godda
22. Gosangi
23. Holeya
24. Jaggali
25. Jambuvulu
2
26. Kadaiyan (in the districts of Tirunelveli,
Thoothukudi, Ramanathapuram, Pudukottai, Thanjavur,
Tiruvarur and Nagapattinam)
27. Kakkalan (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)

<!-- page 12 -->

1

28. *****
29. Kanakkan, Padanna (in the Nilgiris district)
30. Karimpalan
31.Kavara (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)
32. Koliyan
33. Koosa
34. Kootan, Koodan (in Kanyakumari district and
Shenkottah taluk of Tirunelveli district)
1
35. *****
36. Kuravan, Sidhanar
37. Madari
38. Madiga
39. Maila
40. Mala
41. Mannan (in Kanyakumari district and
Shenkottah taluk of Tirunelveli district)
42. Mavilan
43. Moger
44. Mundala
45. Nalakeyava
46. Nayadi
47.Padannan (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)
48. Pagadai
1
49. *****
50. Palluvan
51. Pambada
52. Panan (in Kanyakumari district and Shenkottah taluk
of Tirunelveli district)
53. Panchama

1

54. *****
55. Panniandi
56. Paraiyan, Parayan, Sambavar
57.Paravan (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)
58.Pathiyan (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)
59. Pulayan, Cheramar
60. Puthirai Vannan
61. Raneyar
62. Samagara
63. Samban
64. Sapari
65. Semman
66.Thandan (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)
67. Thoti
68. Tiruvalluvar
69. Vallon
70. Valluvan
71.Vannan (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)
1
72.*****
73. Velan
74. Vetan (in Kanyakumari district and Shenkottah taluk
of Tirunelveli district)
75. Vettiyan
76.Vettuvan (in Kanyakumari district and Shenkottah
taluk of Tirunelveli district)

PART XVII.—Tripura
1. Bagdi
18. Keot
2. Bhuimali
19. Khadit
3. Bhunar
20. Kharia
2
[4. Chamar, Muchi,Chamar –Rohidas,
21. Koch
Chamar-Ravidas ]
22. Koir
5. Dandasi
23. Kol
6. Dhenuar
24. Kora
2
[7. Dhoba, Dhobi ]
25. Kotal
8. Dum
26. Mahisyadas
9. Ghasi
27. Mali
10. Gour
28. Mehtor
11. Gur
29. Musahar
2
[12. Jalia Kaibarta, Jhalo-Malo ]
30. Namasudra
13. Kahar
31. Patni
14. Kalindi
32. Sabar.
3
15. Kan
[33. Dhuli, Sabdakar, Badyakar
16. Kanda
34. Natta, Nat.]
17. Kanugh
1. Omitted by Act 18 of 2021, s. 2 ,
2. Subs. by Act 34 of 2014, s. 2.
3.Ins. by Act 61 of 2002, s. 2 and the First Sch.

<!-- page 13 -->

PART XVIII.—Uttar Pradesh

1. Agariya 1[excluding Sonbhadra district] }
2. Badhik
3. Badi
4. Baheliya
5. Baiga 1[excluding Sonbhadra district]
6. Baiswar
7. Bajaniya
8. Bajgi
9. Balahar
10. Balai
11. Balmiki
12. Bangali
13. Banmanus
14. Bansphor
15. Barwar
16. Basor
17. Bawariya
18. Beldar
19. Beriya
20. Bhantu
21. Bhuiya 1[excluding Sonbhadra district]
22. Bhuyiar
23. Boria
24. Chamar, Dhusia, Jhusia, Jatava
25. Chero 1[excluding Sonbhadra and Varanasi
districts]
26. Dabgar
27. Dhangar
28. Dhanuk
29. Dharkar
30. Dhobi
31. Dom
32. Domar
33. Dusadh
34. Gharami
35. Ghasiya

36. Gond 1[excluding Mehrajganj, Sidharth
Nagar, Basti, Gorakhpur, Deoria, Mau,
Azamgarh, Jonpur, Balia, Gazipur,
Varanasi],2[ Mirzapur, Sonbhadra, Sant
Kabir Nagar, Kushinagar, Chandauli and
Bhadohi districts]
37. Gual
38. Habura
39. Hari
40. Hela
41. Kalabaz
42. Kanjar
43. Kapariya
44. Karwal
45. Khairaha
3
[46. Kharwar(excluding Benbansi) (excluding
Deoria, Balia, Gazipur, Varanasi and
Sonbhadra districts) ]
47. Khatik
48. Khorot
49. Kol
50. Kori
51. Korwa
52. Lalbegi
53. Majhwar
54. Mazhabi
55. Musahar
56. Nat
1
57.Pankha
[excluding
Sonbhadra
and
Mirzapur districts]
58. Parahiya 1[excluding Sonbhadra district]
59. Pasi,Tarmali
60. Patari 1[excluding Sonbhadra district]
61. Rawat
62. Saharya1 [excluding Lalitpur district]
63. Sanaurhiya
64. Sansiya
65. Shilpkar
66. Turaiha.

_____________________________________________________________________________
1.
2.
3.

Ins. by Act 10 of 2003, s. 3 and the First Sch.
Subs. By Act 20 of 2022, s.3 and First Sch.
Subs. By Act 10 of 2003, s.3 and First Sch..

<!-- page 14 -->

PART XIX.—West Bengal

1. Bagdi, Duley
31. Kaur
2. Bahelia
32. Keot, Keyot
3. Baiti
33. Khaira
4. Bantar
34. Khatik
5. Bauri
35. Koch
6. Beldar
36. Konai
7. Bhogta
37. Konwar
8. Bhuimali
38. Kotal
9. Bhuiya
39. Kurariar
10. Bind
40. Lalbegi
11.Chamar, Charmakar, Mochi, Muchi,
41. Lohar
Rabidas, Ruidas, Rishi
42. Mahar
12. Chaupal
43. Mal
13. Dabgar
44. Mallah
14. Damai (Nepali)
45. Musahar
15. Dhoba, Dhobi
46. Namasudra
16. Doai
47. Nat
17. Dom, Dhangad
48. Nuniya
18. Dosadh, Dusadh, Dhari, Dharhi
49. Paliya
19. Ghasi
50. Pan, Sawasi
20. Gonrhi
51. Pasi
21. Halalkhor
52. Patni
1
[22. Hari, Mehtar, Mehtor, Bhangi, Balmiki]
53. Pod, Poundra
23. Jalia Kaibartta
54. Rajbanshi
24. Jhalo Malo, Malo
55. Rajwar
25. Kadar
56. Sarki (Nepali)
26. Kami (Nepali)
57. Sunri (excluding Saha)
27. Kandra
58. Tiyar
28. Kanjar
59. Turi.
2
29. Kaora
[60. Chain].
30. Karenga, Koranga
3
[PART XX.—Mizoram
1. Bansphor
9. Kaibartta or Jaliya
2. Bhuinmali or Mali
10. Lalbegi
3. Brittial-Bania or Bania
11. Mahara
4. Dhupi or Dhobi
12. Mehtar or Bhangi
5. Dugla or Dholi
13. Muchi or Rishi
6. Hira
14. Namasudra
7. Jalkeot
15. Patni
8. Jhalo, Malo or Jhalo-Malo
16. Sutradhar.
4

[PART XXI.—Arunachal Pradesh
* * * **
______________________________________________________________________________
5

1. Subs. by Act, 25 of 2002, s. 2.
2. Subs. by Act, 24 of 2016, s.2.
3. Ins. by Act 34 of 1986, s. 13 and the First Sch. (w.e.f. 20-2-1987).

4. Ins. by Act 69 of 1986, s. 16 and the First Sch. (w.e.f. 20-2-1987).
5. Omitted by Act 61 of 2002, s. 2 and First Sch.

<!-- page 15 -->

1

1. Bhangi (Hadi)
2. Chambhar
3. Mahar

[PART XXII—Goa
4. Mahyavanshi (Vankar)
5. Mang.]

2

[PART XXIII.—Chhattisgarh
1. Audhelia
23. Dom, Dumar, Dome, Domar, Doris
2. Bagri, Bagdi
24. Ganda, Gandi
3
3. Bahna, Bahana
{25. Ghasi, Ghasia, Sais, Sahis, Sarathi, Soot4. Balahi, Balai
Sarathi, Thanwar }
5. Banchada
26. Holiya
6. Barahar, Basod
27. Kanjar
7. Bargunda
28. Katia, Patharia
8. Basor, Burud, Bansor, Bansodi, Bansphor,
29. Khatik
Basar
30. Koli, Kori
9. Bedia
31. Khangar, Kanera, Mirdha
10. Beldar, Sunkar
32. Kuchbandhia
11.Bhangi, Mehtar, Balmiki, Lalbegi, Dharkar 4{33. Mahar, Mahara, Mahra, Mehar, Mehra }
12. Bhanumati
34. Mang, Mang Garodi, Mang Garudi,
13. Chadar
Dankhani Mang, Mang Mahasi, Madari,
14. Chamar, Chamari, Bairwa, Bhambhi, Jatav,
Garudi, Radhe Mang
Mochi, Regar, Nona, Rohidas, Ramnami,
35. Meghwal
Satnami, Surjyabanshi, Surjyaramnami,
36. Moghia
Ahirwar, Chamar Mangan, Raidas
37. Muskhan
15. Chidar
38. Nat, Kalbelia, Sapera, Navdigar, Kubutar
16. Chikwa, Chikvi
39. Pasi
17. Chitar
40. Rujjhar
18. Dahait, Dahayat, Dahat
41. Sansi, Sansia
19. Dewar
42. Silawat
20. Dhanuk
43. Zamral ]
5
21. Dhed, Dher
{44. Turi }.
22. Dohor
______________________________________________________________________________
1. Ins. by Act 18 of 1987, s. 19 and the First Sch. (w.e.f. 30-5-1987).
2. Ins. by Act 28 of 2000, s.19 and the Third Sch. (w.e.f. 1-11-2000).
3. Subs. by Act, 24 of 2016, s.2.
4. Subs. by Act 24 of 2023, s.2.
5. Ins. by Act 31 of 2007, s. 2.

<!-- page 16 -->

1

[PART XXIV.—2 {Uttarakhand}
1. Agariya
34. Gharami
2. Badhik
35. Ghasiya
3. Badi
36. Gond
4. Baheliya
37. Gual
5. Baiga
38. Habura
6. Baiswar
39. Hari
7. Bajaniya
40. Hela
8. Bajgi
41. Kalabaz
9. Balahar
42. Kanjar
10. Balai
43. Kapariya
11. Balmiki
44. Karwal
12. Bangali
45. Khairaha
13. Banmanus
46. Kharwar (excluding Benvansi)
14. Bansphor
47. Khatik
15. Barwar
48. Khorot
16. Basor
49. Kol
17. Bawariya
50. Kori
18. Beldar
51. Korwa
19. Beriya
52. Lalbegi
20. Bhantu
53. Majhwar
21. Bhuiya
54. Mazhabi
22. Bhuyiar
55. Musahar
23. Boria
56. Nat
24. Chamar, Dhusia, Jhusia, Jatava
57. Pankha
25. Chero
58. Parahiya
26. Dabgar
59. Pasi, Tarmali
27. Dhangar
60. Patari
28. Dhanuk
61. Saharya
29. Dharkar
62. Sanaurhiya
30. Dhobi
63. Sansiya
31. Dom
64. Shilpkar
32. Domar
65. Turaiha.]
33. Dusadh

______________________________________________________________________________
1. Ins. by Act 29 of 2000, s. 24 and the Fifth Sch. (w.e.f. 9-11-2000).
2. Subs. by Act, 4 of 2015, s.2.

<!-- page 17 -->

1

[PART-XXV-Telangana

1. Adi Andhra
2. Adi Dravida
3. Anamuk
4. Aray Mala
5. Arundhatiya
6. Arwa Mala
7. Bariki
8. Bavuri
9.Beda (Budga) Jangam
10. Bindla
11. Byagara, Byagari
12. Chachati
13. Chalavadi
14.Chamar, Mochi, Muchi, Chamar-Ravidas,
Chamar-Rohidas
15. Chambhar
16. Chandala
17. Dakkal, Dokkalwar
18. Dandasi
19. Dhor
20. Dom, Dombara, Paidi, Pano
21. Ellamalawar, Yellammalawandlu
22. Ghasi, Haddi, Relli Chanchandi
23. Godari
24. Gosangi
25. Holeya
26. Holeya Dasari
27. Jaggali
28. Jambuvulu
2 9. Kolupulvandlu, Pambada, Pambanda, Pambala

30. Madasi Kuruva, Madari Kuruva
31. Madiga
32. Madiga Dasu, Mashteen
33. Mahar
34. Mala, Mala Ayawaru
35. Mala Dasari
36. Mala Dasu
37. Mala Hannai
38. Malajangam
39. Mala Masti
40. Mala Sale, Nethani
41. Mala Sanyasi
42. Mang
43. Mang Garodi
44. Manne
45. Mashti
46. Matangi
47. Mehtar
48. Mitha Ayyalvar
49. Mundala
50. Paky, Moti, Thoti
51.Pamidi
52. Panchama, Pariah
53. Relli
54. Samagara
55. Samban
56. Sapru
57. Sindhollu, Chindollu
58. Yatala
59. Valluvan.]

_____________________________________________________________________________________
1.

. Ins. by Act 6 of 2014, s. 28 and the Fifth Sch.
