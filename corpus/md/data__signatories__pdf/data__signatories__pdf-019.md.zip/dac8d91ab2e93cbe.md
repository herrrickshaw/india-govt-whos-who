---
doc_id: "dac8d91ab2e93cbe"
source_url: "https://mohua.gov.in/static/uploads/2025/10/f6ee25849bef68a59b7a8eb886613ebd.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Office Orders No.K-14011/33/2009-PHE-II Date 27-7-2011"
date: "2011-07-27"
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d11a187cfa48e015"
---

<!-- page 1 -->

MINISTRY OF EXTERNAL AND EUROPEAN AFFAIRS

Directorate General of Globalisation,
Development and Partnerships

Paris,

Delegation for Foreign Action by Local
Self-Governing Bodies
N°/DGM/AECT

Call for Projects 2011 in support of Indo-French Decentralised
Cooperation
PRESENTATION AND DESCRIPTION OF SUBMITTED PROJECT
I.

INFORMATION ON THE SUBMISSION

Project submitted by: [name of the leader French local self-governing body]
French region: [name of the French region]
French department: [name of the French department]
First name:
Surname:
E-mail:
II.

PRESENTATION OF THE SUBMITTED APPLICATION AND INFORMATION
ON THE PARTNERS

Project title:
Theme: Choose from below
Sub-theme: [enter a sub-theme]
Beneficiary country/countries: [name of Beneficiary country/ countries]

Leader French local self-governing body:
Other partner French local self-governing body:
Self-governing body 1
Name of the self-governing body:

<!-- page 2 -->

Address:
Postal code:
City:
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
Self-governing body 2
Name of the self-governing body:
Address:
Postal code:
City:
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
Self-governing body 3
Name of the self-governing body:
Address:
Postal code:
City:
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
Self-governing body 4
Name of the self-governing body:
Address:
Postal code:
City:
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
Self-governing body 5
Name of the self-governing body:
Address:
Postal code:
City:
Contact person’s first name:
Contact person’s surname:
Contact person’s title:

2

<!-- page 3 -->

E-mail:
Leader Indian partner local self-governing body:
Name of the self-governing body:
Beneficiary country: India
Address:
Postal code:
City:
Website (without http://):
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
Other partner local self-governing bodies in India or a third country:
Self-governing body 1
Name of the self-governing body:
Beneficiary country:
Address:
Postal code:
City:
Website (without http://):
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
Self-governing body 2
Name of the self-governing body:
Beneficiary country:
Address:
Postal code:
City:
Website (without http://):
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
Self-governing body 3
Name of the self-governing body:
Beneficiary country:
Address:
Postal code:
City:

3

<!-- page 4 -->

Website (without http://):
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
Self-governing body 4
Name of the self-governing body:
Beneficiary country:
Address:
Postal code:
City:
Website (without http://):
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
Self-governing body 5
Name of the self-governing body:
Beneficiary country:
Address:
Postal code:
City:
Website (without http://):
Contact person’s first name:
Contact person’s surname:
Contact person’s title:
E-mail:
III.

DESCRIPTION OF THE SUBMITTED PROJECT

DESCRIPTION OF THE PROJECT
Summary [10 lines maximum]:

Context

Background

Aims of the project: General purpose

Innovation (if applicable, specify the innovative nature of the project)

4

<!-- page 5 -->

Year in which the cooperation Agreement was signed: [year]
Year in which project was started: [year]
Estimated year of project completion: [year]
Beneficiaries of the project [list of beneficiaries, using a comma separator]:
ACTIONS ENVISAGED
Guiding theme of the project and links between actions

Synergy and complementarity of these actions with other projects (projects with French
cooperation (DCP, etc.) and other bilateral or multilateral donors; local or French NGO
projects; programmes of local public or semi-public organisations; complementarity with local
or regional strategies in France.)

COMMUNICATION AND EVALUATION
Have you undertaken any publicity measures for the project?
In France
In partner countries
Will there be an assessment policy for this project?
Yes
No
PROJECT FEASIBILITY
Specific input on the technical, organisational, environmental, financial
profitability), political, social and cultural feasibility of the project

(or

Indicate how the Contracting Authority intends to disengage itself gradually from the
project

IV.

DETAILS OF THE ACTIONS OF THE PROPOSED ACTION

ACTION 1
Action title:
Aim of the action

Brief description

5

<!-- page 6 -->

Course of action (chosen technical solutions, works to be undertaken, proposed
training programmes, etc.)

Indicators for follow-up of action

Expected qualitative results

Expected quantitative results

Expected impacts on conclusion of project

Beneficiaries of the action [comma-separated list of beneficiaries]:
Assessment apparatus to be used for the proposed action

ACTION 2
Action title:
Aim of the action

Brief description

Course of action (chosen technical solutions, works to be undertaken, proposed
training programmes, etc.)

Indicators for follow-up of action

Expected qualitative results

Expected quantitative results

6

<!-- page 7 -->

Expected impacts on conclusion of project

Beneficiaries of the action [comma-separated list of beneficiaries]:
Assessment apparatus to be used for the proposed action

ACTION 3
Action title:
Aim of the action

Brief description

Course of action (chosen technical solutions, works to be undertaken, proposed
training programmes, etc.))

Indicators for follow-up of action

Expected qualitative results

Expected quantitative results

Expected impacts on conclusion of project

Beneficiaries of the action [comma-separated list of beneficiaries]:
Assessment apparatus to be used for the proposed action

V.

PRÉSENTATION OF PROJECT PARTNERS IN EN FRANCE AND OTHER
FOREIGN COUNTRIES

Contracting Authority/ Authorities for the project [comma-separated names]:

7

<!-- page 8 -->

Local Project manager [Comma-separated names]:

Specify its role (particularly with reference to the financial contribution of the partner
in building the cooperation)

Other organisations/ bodies involved
Name of organisation(s): [Comma-separated names]
Status: [Please choose: local authorities, not-for-profit organisation, cooperative, public
institution, other]:
VI.

BUDGET AND AMOUNT OF CO-FINANCING REQUESTED FOR

BUDGETARY INFORMATION
Total project cost: [amount]

€

Co-financing requested for:
2011: [amount]
€ ([percentage]

%)

Amount of the leader French partner local-self-governing body’s own resources:
2011: [amount]
€
-

In cash: [amount]
In kind: [amount]

€
€

Amount of other French partner local-self-governing body’s own resources:
Self-governing body 1
Name of the self-governing body:
2011: [amount] €
-

In cash: [amount]
In kind: [amount]

€
€

Self-governing body 2
Name of the self-governing body:
2011: [amount] €
-

In cash: [amount]
In kind: [amount]

€
€

Self-governing body 3

8

<!-- page 9 -->

Name of the self-governing body:
2011: [amount] €
-

In cash: [amount]
In kind: [amount]

€
€

Self-governing body 4
Name of the self-governing body:
2011: [amount] €
-

In cash: [amount]
In kind: [amount]

€
€

Self-governing body 5
Name of the self-governing body:
2011: [amount] €
-

In cash: [amount]
In kind: [amount]

€
€

Amount apporté par la collectivité locale partenaire chef de file en Inde :
Name of the self-governing body:
2011: [amount]
-

€

In cash: [amount]
In kind: [amount]

€
€

Amount of contribution made by other partner self-governing bodies, Indian or third
country:
Self-governing body 1
Name of the self-governing body:
Beneficiary country:
2011: [amount]
-

€

In cash: [amount]
In kind: [amount]

€
€

Self-governing body 2
Name of the self-governing body:
Beneficiary country:
2011: [amount]
-

€

In cash: [amount]
In kind: [amount]

€
€

9

<!-- page 10 -->

Self-governing body 3
Name of the self-governing body:
Beneficiary country:
2011: [amount]
-

€

In cash: [amount]
In kind: [amount]

€
€

Self-governing body 4
Name of the self-governing body:
Beneficiary country:
2011: [amount]
-

€

In cash: [amount]
In kind: [amount]

€
€

Self-governing body 5
Name of the self-governing body:
Beneficiary country:
2011: [amount]
-

€

In cash: [amount]
In kind: [amount]

€
€

Amount of the planned co-financing from Europe:
Source of funding: [Name]
2011: [amount]
€
The Oudin Law (loi Oudin):
If your project is on water or electricity, is it financed
by an additional budget or budget of association of communes (The Oudin Law)?:
[amount]
€
by the general budget?: [amount]
€

10

<!-- page 11 -->

MINISTRY OF EXTERNAL AND EUROPEAN AFFAIRS
Directorate General of Globalisation,
Development and Partnerships

Paris,

Delegation for Foreign Action by Local
Self-Governing Bodies
N°/DGM/AECT

Call for Projects 2011 in support of Indo-French
Decentralised Cooperation
Expenses
Please fill in the details below as well as the table for budgeted expenses. Please attach
this as a Word document to your application. Please do not send this document by post; it
must be sent only through electronic mail.
Name of the leader French local self-governing body:
Region:
Leader partner Indian local self-governing body:
State:
Project title:

<!-- page 12 -->

TABLE II: BUDGETED EXPENSES (in euros)
EXPENSE HEADS

AMOUNT (€)

§.1- Expenses (apart from those listed in §2):
- Action 1
2011 :
- Action 2
2011 :
- Action 3
2011 :
- etc.
- Follow-up costs
2011 :
- Costs for Project Publicity
2011 :
- Administrative or organisational fees (10% max)
2011 :
- Miscellaneous and unbudgeted (5% max)
2011 :
SUB-TOTAL 1:
§.2- Total expenses borne by partners in India:
2011

-

In cash:
In kind:
SUB-TOTAL 2:
GRAND TOTAL:

<!-- page 13 -->

MINISTRY OF EXTERNAL AND EUROPEAN AFFAIRS

Directorate General of Globalisation,
Development and Partnerships

Paris,

Delegation for Foreign Action by Local
Self-Governing Bodies
N°/DGM/AECT

Call for Projects 2011 in support of Indo-French
Decentralised Cooperation
Resources
Please fill in the details below as well as the table for budgeted resources. Please attach
this as a Word document to your application. Please do not send this document by post; it
must be sent only through electronic mail.
Name of the leader French local self-governing body:
Region:
Leader Indian partner local self-governing body:
State:
Project title:

<!-- page 14 -->

TABLE I: BUDGETED RESOURCES
SOURCE

AMOUNT
€

Amount of the leader French self-governing
body’s own resources:
Name:
2011 :
-

1

In cash:
In kind:

Raised - Acquired - Paid – To be negotiated

%

NATURE OF THE AMOUNT COMMITTED
Mandatory field 1

<!-- page 15 -->

Amount of other partner French
governing bodies’ own resources:

self-

Name:
2011:
-

In cash:
In kind:

Amount contributed by the leader partner
self-governing body in India:
Name:
2011:
-

In cash:
In kind:

Amount contributed by other local selfgoverning bodies in India or another
country:
Name:
2011:
-

In cash:
In kind:

<!-- page 16 -->



Other public fund resources*:
- Administrations
- European Union, etc.
- Subsidy granted by another selfgoverning body

* excluding MEEA co-financing:


Other project partners in France:
Name:
2011:



Other project partners in India:
Name:
2011:



Other

<!-- page 17 -->

RESOURCES APART FROM
THE MEEA
2011:
(Sub-total 1)
AMOUNT REQUESTED FROM
THE MEEA*
2011:
(Sub-total 2)
TOTAL

<!-- page 18 -->

MINISTRY OF EXTERNAL AND EUROPEAN AFFAIRS
Directorate General of Globalisation,
Development and Partnerships

Paris,

Delegation for Foreign Action by Local
Self-Governing Bodies
N°/DGM/AECT

Call for Projects 2011 in support of Indo-French
Decentralised Cooperation
Chronogram/ Gantt Chart
Please fill in the details required below and append your chronogram below. Please attach
this as a Word document to your project presentation. Please do not send this document
by post; it must be sent only through electronic mail.
Name of the leader French local self-governing body:
Region:
Leader Indian partner local self-governing body:
State:
Project title:
PROJECT SCHEDULE AND CHRONOGRAM
