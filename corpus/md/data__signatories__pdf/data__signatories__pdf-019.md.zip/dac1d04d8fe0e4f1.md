---
doc_id: "dac1d04d8fe0e4f1"
source_url: "https://www.mea.gov.in/images/pdf/ADV-September-2022.pdf"
ministry: "External Affairs (MEA)"
title: "Advertisement for Engagement of Senior Policy Specialist/ Policy Specialist for G-20 Secretariat of the Ministry of External Affairs on Consultancy basis"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "154c65e0130d8865"
---

<!-- page 1 -->

Q/PF/575/28/2022
Government of India
Ministry of External Affairs
(Administration Division)
Jawaharlal Nehru Bhawan, New Delhi,
27th September 2022
Advertisement for Engagement of Senior Policy Specialist/ Policy Specialist for G-20 Secretariat of the
Ministry of External Affairs on Consultancy basis
Applications
in
the
prescribed
proforma
as
given
in
the
Portal
(www.g20recruitment.mea.gov.in) are invited from eligible candidates for engagement of 12
(Twelve) Senior Policy Specialists/ Policy Specialists in the G-20 Secretariat of the Ministry of
External Affairs (MEA), New Delhi, as per details given below:
Position: Senior Policy Specialist
Number of Positions: 6 (Six)
1.
Qualifications
/Essential
Criteria

:
•

Applicant should be an Indian National.

•

Applicant should possess higher qualification (Masters’
and above) from a reputed Indian or International
Institution/University
in
Development
Cooperation/Development
Partnership/International
Relations/International Law/International Development/
Public Administration/Strategic Studies/ International
Trade/Environment & Climate or a related subject.

•

At least eight years of experience in handling multilateral
work
in
UN
agencies
or
International Organizations or International
consultancy
organizations or Government of India, in relevant fields.

•

Candidate should have experience of participating in
international meetings involving international climate
agenda/international developmental agenda/development
cooperation/debate
on
sustainable
development
goals/international discussions on digital economy or
emerging technologies

•

Candidates should possess good writing and analytical
skills and have experience in policy making or advocacy.
Experience in speech writing, analytical writing and
preparing negotiation strategy.

<!-- page 2 -->

2.

3.

Desirable Criteria

Nature of Duties

•

Should possess good speaking skills in English and any
other foreign language.

•

Candidate should be proficient in computers.

•

Experience of internships shall not be counted

•

Age upto 50 years and he/she should be in good health.

•

Relaxation in age criterion could be considered for
deserving candidates.

•

Experience of handling/providing consultancy on G20
related issues.

•

Will be attached to G20 substantive Secretariat work
streams and would be expected to research and develop
concept notes/issue notes/background documents, themes
and key priorities in respective areas for India’s G20
forthcoming Presidency.

•

Would need to prepare draft outcome documents for the
G20 meetings, and to help with negotiation process and
negotiation strategy, including live drafting of document
during negotiations. Responsible to keep track of country
position on relevant subjects.

•

Keeping track of the state of play on issues discussed in
G20 Working Group and to work towards proposals that
would garner consensus in G20.

•

Responsible to cover meetings and coordinate with various
Line Ministries/Departments of GoI, Think Tanks,
International Organizations and G20 member & Invitee
Countries etc.

•

Any other task assigned by the Head of the Division.

:

:

<!-- page 3 -->

Position: Policy Specialist
Number of Positions: 6 (Six)
1.
Qualifications /
Essential Criteria

2.

Desirable Criteria

:

•

Applicant should be an Indian National.

•

Applicant should possess a higher qualification (Masters’
and above) from a reputed Indian or International
Institution/University in Economics / Development
Cooperation / Development Partnership / International
Relations / International Law / International Development /
Strategic Studies / Public Administration / International
Trade / Environment and Climate / Trade / Agriculture /
Labour Economics / Women Issues / Energy / Health /
Disaster Management / Anti-corruption.

•

At least five years of experience in handling multilateral
work in UN agencies or International Organizations or
International Consultancy / Consultancy Organizations /
Government of India as Consultant / Advisor, in relevant
fields.

•

Candidate should have experience of participating in
international meetings involving international discussions /
negotiations on any of the issues of Climate & Environment,
Health, Agriculture, Trade, Investment and Industry, Energy,
Anti-Corruption, Developmental Issues, Digital Economy
etc.

•

Candidate should possess good writing and analytical skills
and have experience in policy making or advocacy.
Experience in speech writing, analytical writing and
preparing negotiation strategy.

•

Should possess good speaking skills in English and any
other foreign language.

•

Candidate should be proficient in computers.

•

Age upto 45 years and he/she should be in good health.

•

Relaxation in age criterion could be considered for deserving
candidates.

•

Experience of handling/providing consultancy on G20
related issues.

:

<!-- page 4 -->

3.

Nature of Duties

:

•

Will be attached to G20 substantive secretariat work
streams, and would develop concept notes/issue
notes/background documents/scoping notes, themes and key
priorities in respective areas for India’s forthcoming
Presidency.

•

Would need to prepare draft outcome documents for the G20
meetings, and to help with negotiation process and
negotiation strategy, including live drafting of document
during negotiations.

•

Would need to prepare presentations, interventions, position
papers etc. for Ministerial meetings, taking meeting records,
coordination with G20 Countries & IOs and feeding
outcomes of Sherpa meetings in Leaders’ Declaration.

•

Develop knowledge on the state of play on issues discussed
in G20 Working Groups and to work towards proposals that
would garner consensus in G20.

•

Responsible to cover meetings and perform liaison duties
with various Line Ministries/Departments of GoI, Think
Tanks, International Organizations and G20 member and
invitee Countries etc.

•

Research and documentation work for the G20, in the run up
to and during India’s G20 Presidency including assessing
key issues, country positions.

•

Any other task assigned by the Head of the Division.

<!-- page 5 -->

COMMON CRITERIA FOR BOTH THE POSITIONS
1.

Period of
Consultancy

:

Consultancy will end on 30 November 2023
The contract may be terminated on one month’s notice from either
side or on payment of one month’s remuneration in lieu thereof.
Unauthorized absence may lead to termination of the engagement.

2.

Job Location

:

3.

Remuneration &
Entitlements

:

Ministry of External Affairs (Sushma Swaraj Bhawan or any
other office of G20 in New Delhi), New Delhi.
•

For Senior Policy Specialist:
The remuneration package will be up to a maximum of
Rs.2,75,000/- per month. The amount of remuneration so
fixed shall remain unchanged for the term of contract. No
increment and dearness allowance shall be allowed during
the term of contract.

•

For Policy Specialist:
The remuneration package will be up to a maximum of
Rs.2,25,000/- per month. The amount of remuneration so
fixed shall remain unchanged for the term of contract. No
increment and dearness allowance shall be allowed during
the term of contract.

•

Deduction of mandatory taxes will be applicable.

•

The employment will be strictly contractual and will not
confer any other benefits to the selected candidate.

•

In case the Consultant is required to travel domestically as
part of his/her duties, the Ministry will take care of their
travel, accommodation, and per-diem costs, on par with
Under Secretary in the Ministry.

•

The consultant shall not be entitled to any benefit like
Provident Fund, Pension, Gratuity, Medical Attendance
Treatment, Seniority, Promotion etc. or any other benefits
available to the regular employees of the Ministry.

•

No HRA shall be admissible.

•

The engagement is on full time basis as per Government of
India rules. In exigencies, he/she may be required to work

<!-- page 6 -->

beyond office hours and/or on closed holidays. No extra
allowance or remuneration for such work is admissible.
He/She shall not accept any other professional
appointment, paid or otherwise during the term of
engagement with this Ministry.
•

The work generated in the Secretariat will be sole property
of G20 Secretariat, Government of India. The information
would be covered under Official Secrets Act.

•

Paid leave of absence may be allowed to the rate of 1.5
days for each completed month of service. Accumulation
of leave beyond a calendar year may not be allowed. Leave
cannot be claimed as a matter of right. Leave will not be
allowed for more than 10 days at a time. Discretion is
reserved to the Head of Division to refuse or revoke leave
in the public interest. Leave encashment will not be
permissible on unspent leave. Unspent leave will lapse on
commencement of notice period. No other leave of any
kind shall be admissible to him/her. In case he/she remains
absent from duty beyond entitled leave, a proportionate
deduction from the consolidated fee as applicable will be
made.

•

The selected Consultant will be required to enter into a
contract with the Ministry in a prescribed format w.e.f. the
actual date of engagement.

<!-- page 7 -->

4.

How to apply

:

l The applicants who fulfill the eligible criteria may submit
application
online
in
the
portal
www.g20recruitment.mea.gov.in
l Ministry of External Affairs will review the applications
and short list the candidates it considers suitable for
interview. The short-listed candidates will be intimated by
email. The candidates not shortlisted for interview will not
receive any communication.
l The date, time and venue of the interview will be
conveyed through email at the email address provided by
the applicants.
l Applicants will have to make their own arrangements to
reach the place of interview.
l No TA/DA will be payable by the Ministry to Applicants
for attending interview.
l The final selection will be based on their performance in
the interview.
l The decision of the Government regarding selection of
candidates will be final.

The last date for receiving applications is 12th October 2022 (1730 Hrs). Applications
received after the closing date or without the prescribed documents or otherwise found incomplete or
not in the prescribed proforma as given in the Portal, are liable to be rejected and no correspondence
shall be entertained in this regard.
*****
