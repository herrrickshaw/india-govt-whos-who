---
doc_id: "ddef18e5c25cbf1c"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/b20f7ede37080a0d1876a9aa18911a36.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "O.M.No.F.22(2)/2001-Judl., 14th May, 2001 - Terms and conditions of Counsel of Calcutta High Court."
date: "2001-05-14"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "86da903a34d65166"
---

<!-- page 1 -->

हि
v , :
fe yt
SB
: . F.No.22(2)/2001-Judl.
है Government of India
Ministry of Law, Justice & Company Affairs
Department of Legal Affairs
Judicial Section
OFEICE MEMORANDUM
New Delhi, the 14th May, 2001,
Subject : Revision of fee -payable to Special Counsel/tenior Panel
Counsel Group “I, Senior Panel Counsel Group II and Junior
Counsel in the Calcutta High Court, Kolkata,
The undersigned is directed to refer to this Department's
O.M.No. 22(1)/87-Judl. dated Sth June, 1987 on.the above subject and to state
that the question of further revision of fee Payable to Panel Counsei of
Calcutta High Court, Kolkata, was under consideration of the. Government and ~
the Government has decided to revise the fee w.e.f. 14th May, 2001, as
under: =
\(@annexure I to the Scheme of terms and conditions contained with”
f \his Department's 0.4. . No. 22(1)/87-Judl. dated 05. 05.,1987 shall be
Teplaced by the Annexure to this 0.M.
as (biTerm IV of the Scheme of terms and conditions contained with this
Department's 0.M. dated 05,05. 1987 shall be substituted by the
folloking, namely i=
- TV. TERM OF ENGAGEMENT :-
, the cliitialdturther engagement :~.the term of eMgagenedt of
the Comsel would be for a period of three years or until
पर further orders whichever is. earlier, The term may be
extenfed further at the discretion of the Government of India
(2) “ermination of engagement :~ The engagement of the
; pets would be terminable at any time without assigning any
. (c)In term IX,2 of the Scheme, the amount of Rs.10
+ : ५ है -100/-and Rs. 200/-
. shall be revised to Rs. 300/- and Rs. 600/- respectively,
(a4) In term ‘x1II.10 the existing amoun
wid 1, 10, t of Rs.25/- and
Rs. 50/wherever occuring, hi oI i
Rs, 150/respectivein: ng, shall be इज. to Rs.75/- and
“2. The Counse! Will be pai in tec}
K है paid fee at the old at t
oe in the High Court, etc. and other work 4०6 bee fees th
1th ra 26 at the revised rates in respect of work done by themon/af ter
. L Sy -_ “SS
. ५५ other provisions of this Department’s  0.M. No. 2:
ed 05.081 साया ७ 4 जी n +-M.No. 22(1)/87-Judl.
ey न the ned_therewith“shall remain. the~same,
% a

<!-- page 2 -->

end. i के 1 bea ee ae a4
‘ \
—2- ‘
4, The Scheme of terms and conditions contained with this Department's
O.M. dated 05.05, 1987 as amended by this.0.M. shall also’be applicatile to
the Panel Counsel of Central me te nla Me apatite Kolkata, However, the
fee payable to them will be borne by the Mini ies/Departments themselves.
$ : ia ~
AN
: : : tak eens) _
Joint Secretary & Legal Adviser to the Government cf India
Copy forwarded to :-
1, All Ministries/Departments to the Government of Indra
2. All Panel Counsel in the Calcutta High Court (through Branch
Secretariat, Department of Legal Affairs, Kolkata)
3. Department of Expenditure, Ministry of Finance, New Delhi. w.r.t.
their I.D.No.9(11)/99-E. II(B) dated 12.04, 2001 ‘
4, Legal Adviser, Railway Board, New Delhi (with 5 s/copies).
5. Joint Secretary (Legal), Department: of Revenue, Ministry of Finance,
New Delhi (with 5 s/copies).
6. CBDT, Department of Revenue, Ministry of Finance, New Delhi (with 5
s/copies).
4 Branch Secretariats - Mumbai/Kolkata/Chennai/Bangalore.
8. Central Agency Section, Litigation (HC/LC) Section, Cash Section,
B&A, Advice A/B/C Sections.
9. Pay and Accounts Officer, Department of Legal Affairs, New Delhi,
10. Guard File/Judicial Section (with 250 s/copies)
> “i 171
Hill 0
(sk mim)
: Section Officer

<!-- page 3 -->

~4 ee. fe MOR UME,
OURT
EFFECTIVE FROM 14"! MAY, 2001 .
SI.No. | Nomenclature Special Panel Sr. Counsel Sr.Counsel — Jr.Couns
| Counsel Gp.l Gp. ont
zt 2, 3. 4. 5 i
1 Suits, Appeals, Writ/Revision _ Petitions ~~ |
including Special Civil Application in the | Rs.3,000/- Rs.2,000/- Rs.1,250/- | RS.650/-
High Court |
Conference/consultation (per consultation) Rs.300/- Rs.250/- Rs.200/- Rs. 150/-
2 Applications including interim motions,
Notices, Appeals, Leave Applications,
Arbitration, Company matters, Crm, | Rs.1,100/- Rs.900/- Rs.700/- Rs 4507.
Revision and other Land Acquisition i
References (per day per effective hearing)
Conference/Consultation (per consultation! Rs.300/- Rs.250/- Rs.200/- Rs. 150/-
3 Drafting or settling pleadings, and affidavits | Rs.900/- ~ | Rs.6Q0/- Rs.500/- Rs.350/-
(per pleading) हे
Conference/consultation (per consultation Rs.300/- Rs.250/- Rs.200/- _Rs.150/-
4 Appearance before Arbitrator and Tribunals,
etc. and Courts other than the High Court | Rs.2,500/- Rs.2,000/- Rs. 1,250/- | Rs 800/-
(per day per effective hearing )
Conference/consultation (per consultation Rs.300/- Rs.250/- Rs.200/- _Rs 150/-
5. Chamber applications, including
adjournment applications per day inclusive Rs.300/- Rs.Z00/-
of consultation ——
6 Written opinions and written advice
including advice on evidence (inclusive of | Rs.1,350/- Rs,750/- Rs.450/- Rs350/-
consultation ————____
Note '- No ceiling on conference/consultation in the case of Special Panel Counsel whereas in the case of M&F Categori
ceiling is four (relaxable to six at the discretion of the Branch Secretariat.)
