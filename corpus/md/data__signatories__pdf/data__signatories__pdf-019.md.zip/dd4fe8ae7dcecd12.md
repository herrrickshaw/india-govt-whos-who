---
doc_id: "dd4fe8ae7dcecd12"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/08/9d78f5f2786b49ee9cdce36d46808f60.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Electrical Appliances for Domestic Water Heating (Quality Control) Order, 2023"
date: "2024-03-05"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "043964414c27aeff"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-14032024-252987
xxxGIDHxxx
CG-DL-E-14032024-252987
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 1191]
No. 1191]

नई ददल्ली, सोमवार, मार्ध 11, 2024/फाल्गुन 21, 1945
NEW DELHI, MONDAY, MARCH 11, 2024/PHALGUNA 21, 1945

वाजणज्य और उद्योग मंत्रालय
(उद्योग संवधधन और आंतररक व्यापार जवभाग)

आदेि
नई ददल्ली, 5 मार्ध, 2024
का.आ. 1253(अ).— भारतीय मानक ब्यूरो अजधजनयम, 2016 (2016 का 11) की धारा 16 द्वारा प्रदत्त िजियों
का प्रयोग करते हुए, कें द्र सरकार का, भारतीय मानक ब्यूरो से परामिध करने के बाद यह मत है दक यह िनजहत में आवश्यक
अथवा जहतकर है, अत: एतद्द्वारा जनम्नजलजखत आदेि करती है, नामत:1. संजिप्त िीर्धक और प्रारं भ - (1) इस आदेि को डोमेजस्ट्िक वािर हीटिंग के जलए जवधुत उपकरण (गुणवत्ता
जनयंत्रण) आदेि, 2023 कहा िाएगा।
(2) यह आदेि िासकीय रािपत्र में इस अजधसूर्ना के प्रकािन की तारीख से छह माह के बाद लागू होगा।
2. मानक जर्ह्न का अजनवायध प्रयोग – ताजलका के कॉलम (1) में जवजनर्दधष्ट वस्ट्तुएं या सामान ताजलका के कॉलम
(2) में उजल्लजखत तदनुरूपी भारतीय मानक के अनुरूप होंगे तथा उनमें भारतीय मानक ब्यूरो (अनुपालन मूल्यांकन)
जवजनयम, 2018 की अनुसूर्ी-II की स्ट्कीम-I के अनुसार भारतीय मानक ब्यूरो के लाइसेंस के तहत मानक जर्ह्न लगा
होगा।
बिते दक इस आदेि में से कु छ भी जनयाधत की िाने वाली स्ट्वदेि में जवजनर्मधत वस्ट्तुओं या सामान पर लागू नहीं
होगा।

1789 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

बिते दक इसके अजतररि सूक्ष्म उद्यम के संबंध में, िैसा दक सूक्ष्म, लघु और मध्यम उद्यम जवकास अजधजनयम,
2006 (2006 का 27) की धारा 2 के क्रमिः खंड (ि) और (ड) के तहत पररभाजर्त दकया गया है, यह आदेि इस
अजधसूर्ना के प्रकािन की तारीख से बारह माह की अवजध समाप्त होने के बाद लागू होगा।
बिते दक लघु उद्यम के संबंध में भी, िैसा दक सूक्ष्म, लघु और मध्यम उद्यम जवकास अजधजनयम, 2006 (2006 का
27) की धारा 2 के क्रमिः खंड (ि) और (ड) में पररभाजर्त दकया गया है, यह आदेि इस अजधसूर्ना के प्रकािन की तारीख
से नौ माह की अवजध समाप्त होने के बाद लागू होगा।
3. प्रमाणन और प्रवतधन प्राजधकरण –भारतीय मानक ब्यूरो ताजलका में जवजनर्दधष्ट वस्ट्तुओं या सामान के जलए
प्रमाणन और प्रवतधन प्राजधकरण होगा।
4. उल्लंघन के जलए पेनल्िी– इस आदेि के प्रावधानों का उल्लंघन करने वाले व्यजि को भारतीय मानक ब्यूरो
अजधजनयम, 2016 के प्रावधानों के तहत दंजडत दकया िाएगा। स्ट्िे
ताजलका
वस्ट्तु या सामान

भारतीय मानक

भारतीय मानक का िीर्धक

(1)

(2)

(3)

डोमेजस्ट्िक वािर हीटिंग के 302(भाग 2/ खंड 21) : 2018 स्ट्िेिनरी स्ट्िोरे ि िाइप इलेजररक वॉिर हीिर के जलए
जलए जवधुत उपकरण

उपकरण
302(भाग 2/ खंड 35) : 2017 इलेजररक इं स्ट्िेंिेजनयस वॉिर हीिर के जलए उपकरण
368 : 2014

इलेजररक इमसधन वॉिर हीिर

2082 : 2018

स्ट्िेिनरी स्ट्िोरे ि िाइप इलेजररकवॉिर हीिर

17150 : 2019

पाइप्ड नैर्ुरल गैस (पी एन िी) से उपयोग दकया िाने
वाला जमनी डोमेजस्ट्िक वॉिर हीिर

नोि – इस ताजलका के प्रयोिन के जलए, भारतीय मानकों के संबध
ं में िारी संिोधनों सजहत उनके नवीनतम
संस्ट्करण, िैसा दक भारतीय मानक ब्यूरो द्वारा समय-समय पर अजधसूजर्त दकए गए हैं, लागू होंगे।
[फा. सं. पी- 29026/8/3/2022– एलईआई]
संिीव, संयुि सजर्व
MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
ORDER
New Delhi, the 5th March, 2024
S.O. 1253(E).— In exercise of the powers conferred by section 16 of the Bureau of Indian Standards Act,
2016 (11 of 2016), the Central Government, after consulting the Bureau of Indian Standards, is of the opinion that it is
necessary or expedient so to do in the public interest, hereby makes the following Order, namely:1. Short title and commencement.- (1) This Order may be called the Electrical Appliances for domestic
water heating (Quality Control) Order, 2023.
(2) It shall come into force on the expiry of six month from the date of publication of this notification in the
Official Gazette:
2. Compulsory use of Standard Mark.- Goods or articles specified in column (1) of the Table shall
conform to the corresponding Indian Standard specified in column (2) of the Table and shall bear the Standard Mark
under a license from the Bureau of Indian Standards as per Scheme-1 of Schedule-II to the Bureau of Indian Standards
(Conformity Assessment) Regulations, 2018:
Provided that nothing in this Order shall apply to goods or articles manufactured domestically for export:

<!-- page 3 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

3

Provided further that in relation to micro enterprises, as defined under clauses (h) and (m), respectively of
section 2 of the Micro, Small and Medium Enterprises Development Act, 2006 (27 of 2006), it shall come into force
on the expiry of twelve month from the date of publication of this notification:
Provided also that in relation to small enterprises, as defined under clauses (h) and (m), respectively of
section 2 of the Micro, Small and Medium Enterprises Development Act, 2006 (27 of 2006), it shall come into force
on the expiry of nine month from the date of publication of this notification.
3. Certification and enforcement authority.- The Bureau of Indian Standards shall be the certifying and
enforcing authority for the goods or articles specified in the Table.
4. Penalty for Contravention.- Any person who contravenes the provisions of this Order shall be punishable
under the provisions of the Bureau of Indian Standards Act, 2016.
TABLE
Goods or articles

Indian Standard

Title of Indian Standard

(1)

(2)

(3)

302 (Part 2/Sec 21): 2018

Appliances for stationary storage type electric
water heaters

302 (Part 2/Sec 35): 2017

Appliances for electric instantaneous water
heaters

Electrical appliance for
domestic water heating

368: 2014

Electric Immersion Water Heaters

2082: 2018

Stationary storage type electric water heaters

17150: 2019

Mini domestic water heater for use with piped
natural gas (PNG)

Note.- For the purposes of this Table, the latest version of Indian Standards including the amendments thereof, as
notified by the Bureau of Indian Standards from time to time shall apply.

[F. No. P-29026/8/3/2022-LEI]
SANJIV, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ
Digitally signed by
MANOJ KUMAR VERMA

2024.03.14 16:35:57
KUMAR VERMA Date:
+05'30'
