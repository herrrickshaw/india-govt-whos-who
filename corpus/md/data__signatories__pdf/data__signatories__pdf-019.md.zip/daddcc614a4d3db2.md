---
doc_id: "daddcc614a4d3db2"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/6a43e722f94a302e7f08d606d30c7ea4.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Status of Industrial Entrepreneur Memorandum Intentions & Implementation (State Wise)"
date: "2025-07-15"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a54ec50513a3c21c"
---

<!-- page 1 -->

STATUS OF INDUSTRIAL ENTREPRENEUER MEMORANDUM INTENTIONS & IMPLEMENTATION (STATEWISE)

Name of the
State

INDUSTRIAL ENTREPRENURS MEMORANDUM
(Part A) FILED
upto May
2020
2021
2022

0

2020
Actual
Nu
Invest
mbe ment
rs
Report
File
ed
d
(Rs.Cr)

2021
Actual
Nu
Invest
mbe ment
rs
Report
File
ed
d
(Rs.Cr)

upto May
2022
Actual
Nu
Invest
mbe ment
rs
Report
File
ed
d
(Rs.Cr)

Num
bers
Filed

Propose
d
Investm
ent
(Rs.Cr)

Nu
mbe
rs
File
d

Propos
ed
Invest
ment
(Rs.Cr)

0

0

0

0

0

0

0

0

0

0

0

59

9727

47

9373

20

5621

42

9840

47

10350

18

19480

1

60

2

15

0

0

0

0

0

0

0

0

Assam

4

99

17

1221

5

308

9

989

4

452

6

429

Bihar

5

1304

21

11004

2

240

2

121

2

71

2

226

Chandigarh

1

3

0

0

0

0

0

0

0

0

0

0

Chhattisgarh
Dadra & Nagar
Haveli

109

22193

98

31564

20

3481

51

73567

70

16492

22

2543

13

516

8

2787

4

270

8

2364

4

68

5

320

Daman & Diu

5

0

6

700

2

0

5

326

3

176

0

0

Delhi

32

3710

7

901

4

850

0

0

2

106

0

0

Goa

5

0

7

163

2

1850

0

0

3

62

1

101

Gujarat

220

46141

214

92566

78

35076

285

34866

110

104968

58

11410

Haryana
Himachal
Pradesh
Jammu &
Kashmir

42

2243

44

5714

15

1688

15

4915

19

3562

9

849

7

218

5

591

3

237

5

855

8

1473

2

235

4

151

5

681

1

0

1

15

5

126

1

0

Jharkhand

8

547

10

1347

3

4015

18

1667

11

2728

6

4670

Karnataka

120

162492

114

61726

41

52033

41

6565

43

6327

22

2901

Kerala

10

382

4

121

1

1

1

97

4

79

1

1

Lakshadweep
Madhya
Pradesh

0

0

0

0

0

0

0

0

0

0

0

0

93

32831

113

21859

30

3353

60

5275

63

14500

22

4187

Maharashtra

296

44188

273

277335

94

16471

101

33715

171

45855

95

17658

Manipur

0

0

0

0

0

0

0

0

0

0

0

0

Meghalaya

1

405

0

0

3

284

0

0

0

0

0

0

Mizoram

0

0

1

220

0

0

0

0

0

0

0

0

Nagaland

0

0

0

0

0

0

0

0

0

0

0

0

Orissa

46

37721

60

137939

26

60302

28

28954

30

89167

14

36748

Puducherry

0

0

5

406

2

1300

0

0

3

6

1

0

Andaman &
Nicobar
Andhra
Pradesh
Arunachal
Pradesh

Num
bers
Filed

Propos
ed
Invest
ment
(Rs.Cr)

IEMs IMPLEMENTED (Based on Part B filed)

<!-- page 2 -->

Punjab

42

1479

40

8016

13

2017

22

1198

29

5627

4

605

Rajasthan

40

12698

61

42452

17

7753

21

5917

14

7571

20

12248

Sikkim

0

0

2

40

0

0

0

0

0

0

0

0

Tamil Nadu

76

6807

115

29636

27

6070

17

1184

40

13684

30

3257

Telengana

57

7392

41

4614

11

1399

12

6057

25

6739

12

1646

Tripura

0

0

1

15

0

0

1

29

0

0

0

0

Uttar Pradesh

91

11384

114

17278

27

3934

51

14177

60

11333

21

5578

Uttarakhand

18

377

27

5609

10

370

11

459

22

4489

7

522

West Bengal

27

9552

27

5535

14

2819

11

817

20

1967

13

1609

1432

414620

1489

771428

475

211742

818

233969

812

347978

392

127223

Total

Note: IEM Part A is being filed by non-MSME category Industries ; Part B is being filed at the time of
commencement of commercial production for Part A filed since December 1991.
