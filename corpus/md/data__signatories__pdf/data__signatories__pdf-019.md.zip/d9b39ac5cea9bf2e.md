---
doc_id: "d9b39ac5cea9bf2e"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/06/b42c79f79e87f356f93feb44f8cb181f.pdf"
ministry: "Tourism"
title: "Tender for setting of an integrated system for providing information to tourist through TIL/helpline,tourist information centre at selected 09 Airports, interacting with tourist with Chat Bots linked to www.incredibleinda.org."
date: "2021-11-10"
pages: 71
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "54fa66e995f1f6aa"
---

<!-- page 1 -->

Ministry of Tourism
Government of India
(Travel Trade Division )
7th Floor,
Chanderlok Building,
36 Janpath Road,
New Delhi - 110 001
Tender No.:TT/38/2020

Date:10/11/2021

Last date for submission of Bids:

03/12/ 2021 till 1500 HRS

Through online on (http://eprocure.gov.in/epublish/app)
No offline bids will be accepted.
Opening of Technical Bids:

07/12/ 2021 at 1500HRS

Pre-Bid Meeting : No Pre-Bid Meeting will be held in view of prevailing
circumstances. Prospective Bidders, requiring any
clarifications on the bid document shall notify Ministry
of Tourism on e-mail ID: traveltradedivision@gmail.com
by 17/11/2021(1000 hrs) as per format given at
Annexure 3.
Clarifications / Responses to queries received will be
uploadedon http://eprocure.gov.in/epublish/appwww.tour
ism.govin by 1700 hrs. 24/11/ 2021.

***********

1

<!-- page 2 -->

INDEX
S.No Subject
Page No.
1. Key dates & Events
4 to 5
2. SECTION -1
6
3. Disclaimer
4. SECTION -2 (Introduction)
7 to 9
5. Background
6. Objective
7. SECTION -3 (Scope of Work)
10 to 19
8. Tourist Info Line / Helpline
9. Tourist Info Line Call Handling
10. Specification required for TIL/CRM
11. Required Key features of IVRs
12. Required Key features of ACD
13. Required Key features of Voice logger
14. Required Key features of CTI
15. Special IT features
16. Reporting
17. Critical Success Factors
18. MoT Support
19. Manning the Airport Counter
20. Chat Services
21. Tourist Complaints Handling under CPGRAM
22. SECTION -4 (Eligibility Criteria)
19 to 21
23. Minimum Eligibility Criteria for Agency
24. Pre-Bid Meeting
25. SECTION -5 (Preparation of Bid)
22 to 35
26. Instruction for preparation of Biding
documents
27. Technical proposal
28. Financial proposal
29. Submission and opening of proposal
30. Bid Opening
31. Evaluation of Proposal
32. Technical Evaluation
33. Technical Evaluation Criteria
34. Financial Evaluation
35. Overall Evaluation
2

<!-- page 3 -->

36.
37.
38.
39.
40.
41.
42.
43.
44.
45.
46.
47.
48.
49.
50.
51.
52.
53.
54.
55.
56.
57.
58.
59.
60.
61.

Award of contract/work order
Submission of Performance Guarantee
Terms and Conditions
Amendment of RFP document
Bid Security /EMD Declaration Form
SECTION 6 (Schedule for completion of Task) 36 to 38
Project Plan and Time Line
Review of Deliverables
Roles and Responsibilities
SECTION 7 (Termination of Contract)
39 to 41
Termination for Default
Termination for Insolvency, Dissolution etc.
Termination for Convenience
No Claim Certificate
Suspension
Consequences of Termination
Withdrawal by the Agency
Intellectual Property Rights (IPR)
SECTION 8 (Payment Terms)
42 to 43
Schedule of Payment
SECTION 9 (Miscellaneous)
44 to 46
Standards
Standard of Performance
Time for Implementation of the Project
Right to Inspect Support Facilities
Confidentiality

62. Force Majeure
63.
64.
65.
66.
67.
68.
69.
70.
71.
72.
73.

Arbitration and Jurisdiction
Review Meetings
Progress Reporting and Escalation procedures
Period of contract
Indemnity
Exit Management schedule
Exit Management Plan
Right to vary Quantity
Limit of Liability
Insurance
Withdrawal, substitution and Modification of
Bids
74. Annexure-1
3

<!-- page 4 -->

75. Annexure-2
76. Annexure-3
77.
78.
79.
80.
81.
82.

4

Annexure-4
Annexure -5
Annexure-6
Annexure-7
Annexure -8

<!-- page 5 -->

KEY DATES & EVENTS :
Name of the Bid

About the Project

Period of Contract

Setting of an integrated system for providing
information to tourist through Tourist Info Line
(TIL) / helpline, tourist information centre at
selected 09 Airports, interacting with tourist with
Chat Bots linked to Incredible India official
website (www.incredibleindia.org) and handling
tourist complaints under CPGRAM portal.
Establishment, O p e r a t i o n a n d Management of
an integrated system for providing information to
tourist through Tourist Info Line (TIL) / helpline,
tourist information centre at selected 09airports,
interacting with tourist with Chat Bots linked to
Incredible
India
official
website
(www.incredibleindia.org) and handling tourist
complaints under CPGRAM portal over a period
of
3 years from the
effective
date of
commencement of the project.
Three years extendable for another two years on
the same terms and conditions
Yes, on the website
http://eprocure.gov.in/epublish/app

Financial Bid to be
submitted together with
Technical Bid
Selection Method
QCBS 70:30
Proposal Language
English
Proposed Currency
INR
Sub-contracting allowed No
Tender Inviting Authority Ministry of Tourism, Government of India
Date of Publication on
http://tourism.gov.in http: 10/11/2021.
//eprocure.gov.in/epublish/
app
Contact person for
Mr. Niraj Sharan, Asstt. Director General (TT)
Clarification
Ministry of Tourism, Govt. of India
Correspondence Address Room no. 2, 8th Floor, Chanderlok Building, 36
Janpath Road, New Delhi - 110 001
(neeraj.sharan@nic.in)
Pre-bid meeting
No Pre-bid meeting will be held due to prevailing
circumstances. Prospective Bidders, requiring
5

<!-- page 6 -->

clarifications on the bid document shall notify
Ministry
of
Tourism
on
e-mail
ID: traveltradedivision@gmail.com by
17/11/2021 (1000 hrs) as per format given
in Annexure 3. Clarifications / Responses related
to query received will be uploaded by 1700 HRS
24/11/
2021
http://tourism.gov.in; https://tourism.euniwizarde.c
om
Last date for submission of 03/12/ 2021 till 1500 HRS
bids Bids
Through
online
on
(http://eprocure.gov.in/epublish/app)
No offline bids will be accepted.
Bid Security
Annexure -6 must be duly filled , signed &
Declaration Form
Stamped on company
Letter Head
Opening of Technical Bid 07/12/ 2021 at 1500HRS
( online opening of bids at
http://eprocure.gov.in/epublish/app)
Date, Time
To be communicated
& Venue for the Opening (online at http://eprocure.gov.in/epublish/app)
of Financial/
Financial Bid for qualified
bidders
Proposed Validity Period 90 days from proposal due date

************

6

<!-- page 7 -->

SECTION 1: DISCLAIMER
This Request for Proposal (RFP) is issued by the Ministry of Tourism,
Government of India for setting of an integrated system for providing
information to tourist through Tourist Info Line (TIL) / helpline, tourist
information centre at selected 09 airports, interacting with tourist with Chat
Bots linked to Incredible India official website (www.incredibleindia.org) and
handling tourist complaints under CPGRAM portal.
Whilst the information in this RFP has been prepared in good faith, it is not
and does not purport to be comprehensive or to have been independently
verified. Neither Ministry of Tourism nor any of its officers or employees, nor
any of their advisers nor consultants accept any liability or responsibility for
the accuracy, rationality or wholeness of, or for any errors, omissions or
misstatements, negligent or otherwise, information contained herein, or makes
any representation or warranty, express or implied, with respect to the
information contained in this RFP or on which this RFP is based or with
respect to any written or oral information made or to be made available to any
of the recipients or their professional advisers and, so far as permitted by law
and except in the case of fraudulent misrepresentation by the party concerned,
and liability therefore is hereby expressly disclaimed.
The information contained in this RFP is selective and is subject to updating,
expansion, revision and amendment at the sole discretion of Ministry of
Tourism. It does not purport to, contain all the information that a recipient
may require for the purposes for deciding for participation in this process.
Each Party must conduct its own analysis of the information contained in this
RFP, to correct any inaccuracies therein and is advised to carry out its own
investigation, the regulatory regime which applies thereto and by and all
matters pertinent to the assignment and to seek its own professional advice on
the legal, financial and regulatory consequences of entering into any
agreement or arrangement relating to the engagement.
Ministry of Tourism shall be the sole and final authority with respect to
qualifying a bidder through this RFP. The decision of Ministry of Tourism, in
selecting the Agency who qualifies through this RFP shall be final and
Ministry of Tourism reserves the right to reject any or all the bids without
assigning any reason.

7

<!-- page 8 -->

SECTION 2: INTRODUCTION
1. Background
1.1. About Ministry of Tourism
The Union Ministry of Tourism (MoT) is the nodal agency for the formulation
of national policies and programmes and for the co-ordination of activities of
various Central Government Agencies, State Governments/UTs and the
Private Sector for the development and promotion of tourism in the country.
2. Objective
The objective of this RFP is for setting up of an integrated system for
providing information to tourist through Tourist Info Line (TIL) / helpline,
tourist information centre at selected 09 airports, interacting with tourist with
Chat
Bots
linked
to
Incredible
India
official
website
(www.incredibleindia.org) and handling tourist complaints under CPGRAM
portal on turnkey basis for Ministry of Tourism.
The selected agency would be appointed for a period of 3 years from the
effective date of commencement of the project. The tenure of the agency can
be extended for a further period of two years on the same terms and conditions
and with the provision that services of the agencies may be dispensed with at
any time, giving three months’ notice, in the event of non-performance, underperformances or any other reason which would be specified.
SECTION:
3
SCOPE
OF
ELIGIBILTY/QUALIFICATION/EXPERIENCE
FOR MANPOWER

WORK and
REQUIREMENT

3.1. Tourist Info Line (TIL) / Helpline (Minimum one manpower to
handle one specific foreign language at a time including one manpower
each for English and Hindi)
(i)
To provide information services to the international tourists (Pre &
Post arrival) and domestic tourists, assist the callers with advice on action to
be taken during times of distress while travelling in India and if need be alert
the concerned authorities.

8

<!-- page 9 -->

(ii)
The scope of services includes providing voice-based contact center
support from the Service Provider’s delivering with adequate number of
manpower required for the job on Full Time Equivalent basis.
(iii)

Operation window: 24x7, 365 days in a year.

(iv)
Offering a “multi-lingual helpdesk” in basic language i.e. Hindi and
English with also qualified call agents conversant in International Languages
namely Arabic, French, German, Italian, Japanese, Korean, Chinese,
Portuguese, Russian, Spanish.
(v)
The Call agents can be Indian Nationals having following
qualifications to provide support service in terms of providing information
relating to travel & Tourism in India to the domestic and International
tourists/visitors:
a. A graduate degree from recognized University.
b. Foreign language Diploma certificate from the Cultural Centres of
Embassies / International institutes in the respective international
language mentioned above
c. Minimum two years’ experience of interpretation services with Fluency
in speaking the respective language.
d. Should have adequate knowledge in the field of tourism and hospitality
sector, particularly with reference to India's Heritage, monuments, and
ancient history.
(vi)
To provide inbound SMS solution for the project. This solution should
be able to handle the inbound and out bound SMSs to the scale of the project.
(vii)
Outbound calling would be done primarily to revert on any
information that was not available to the caller at the time of call. Another
purpose of outbound caII would be to educate any selected group regarding
government schemes and programmes, tourist products, etc.
(viii) The selected agency is expected to improve to match following Key
Performance Indicators: a. Average Handling Time (AHT)
b. First Time Resolution (FTR)
c. Average Speed of Answer (ASA)
d. Call Abandonment Rate etc.

9

<!-- page 10 -->

(ix)
All the core activities are to be performed by the selected agency only
and cannot be sub contracted to other agencies. These include:
 Continue to provide all the requisite infrastructure (IT and Non-IT) for
the project and the Data Centre.
 All calling operations for the project
 Operations and management of all the IT and Non-IT infrastructure
along with the Tourism Infoline site.
 Manpower deployment for the project
 Meeting all the requirements of Service Level Agreement (SLA) of the
project (Annexure 1).
 Prime responsibility to carry out all the activities mentioned in the
scope of work in this section.
 Coordination with other agencies required for smooth operation of the
TIL project.
 As regard, addition/ deletion from the list of core activities, decision of
Technical Coordination Committee (TCC) constituted by MoT to steer
and Monitor TIL project will be final and binding on the AGENCY for
the core activities.
(x)
The toll-free number will be owned by and made available by the
MoT and this shall form bulk of the available lines. The charges for toll-free
number will be paid bvMoT. However, any coordination or technical
integration with the Telecom Service Providers (TSPs)/ other agencies in this
regard would be done by the selected agency with no cost implication to the
MoT.
(xi)
The selected agency will identify and engage a Telecom Service
Provider (TSP) to provide 2 outbound PRI lines and 2 PRI line for inbound
calls. The agency will have to enter in a bipartite contract with the TSP
selected by it for PRI lines. However, the agency has to fulfill all Service
Level Agreements (SLA) requirements as per RFP Telecom cost, data
connectivity, SMS and SMS Gateway or any additional bandwidth cost will
be reimbursed by MOT at actuals.
(xii)
The selected agency will have the complete responsibility of
knowledge management and training of the personnel deployed for the
project. The agency will build a Question Bank database/Knowledge Bank
and step by step query resolution workflow and will be required to provide
update question bank/knowledge base & FAQ database regularly. The agency
will develop training methodology including training material in English and
Hindi and designated international languages for Helpdesk Agents for various
10

<!-- page 11 -->

types of training such as induction training, training of trainer, supervisor
training for processes specific to TIL, training etc.
(xiii) The selected agency will provide regular analytical reports to MoT
that are necessary to monitor the performance of all the SLA parameters and
Key Performance Indicators (KPIs) as identified by the Technical
Coordination Committee (TCC).
(xiv) The total number of Full Time Equivalent (Manpower) to be indicated
clearly.
(xv) The agency will also be responsible to cater to future requirements of
TIL project for which, MoT will bear the full cost for incorporating any such
future requirements. Some of the possible future requirements for the project
may be for Additional Human resource required as per the RFP.
(xvi) From time to time the requirements would be reviewed and
accordingly requirements may be curtailed and increased.

3.2. Tourist Info Line Call Handling
The call handling function of TIL (through Helpdesk Agent/ IVRS) can be
broadly classified under the following two categories:
 Providing General Information on Tourist Spots, attractions across the
country, entry regulation etc.
 Guidance & Assistance to tourists at times of emergencies and
complaints
The functionalities have been broadly detailed below:
a) First Level Call Resolution
The call centre agents at the first-level are expected to enable the following
functionalities:
 Provide Tourist information
 Assist in Resolution of grievances posed by callers
First level call resolution will only deal with queries present in the standard
question bank. Resolution of calls in the first-level will require call centre
agents preferably to possess basic knowledge about tourism in India.
11

<!-- page 12 -->

b) Second-Level Call Resolution
The Helpdesk Agents at the second-level will enable the following
functionalities:
 Resolve specialized queries not being answered by first level agents
 Provide guidance to tourists to handle any grievances and any form of
emergencies
The Helpdesk Agents for second level call resolution will require graduates
with Tourism background. The above call resolutions will be supported by
qualified tourism professionals who will handle these queries.
A call will be escalated to the second-level if the information required by the
caller requires tourism expertise to ensure the quality of advice. All queries
asked by the callers not already present in the standard question bank and
answered with the aid of Tourism consultant will be transcript and stored in a
temporary question bank for future reference and evaluation. Such queries
after validation and approval from the panel of experts (as appointed by
Ministry of Tourism) will be added to the standard question bank.
3.3
The overall scope of work for the establishment, operation and
maintenance of MoT project has been divided into tentative time period of
three phases also needs to be indicated:
 Phase I – Establishment & Go-Live / Operationalization of TIL project
 Phase II – Stabilization of MoT project including its operations
 Phase III – Operation, maintenance & on-going support for TIL project
Further, if any additional IT infrastructure, Non IT infrastructure, hardware,
software, licenses etc. required for the specified scope of work and to meet the
SLA requirements, AGENCY would be responsible for the procurement,
installation, up-gradation, support, operation and maintenance of the same for
entire duration of project period or thereafter as per mutual consent.
3.4. Required key features of TIL / Customer Relation Management
(CRM)
The features that the AGENCY needs to consider for the CRM component of
TIL are provided below. However below-given features are exhaustive and
should be considered while giving the commercial pricing. Any other features
required by MoT will be discussed separately by MoT after the rollout stage.
12

<!-- page 13 -->

The customized CRM should be a web-based solution with seamless
integration to the other tools such as Interactive Voice Response System
(IVRS), Computer Telephony Integration (CTI), SMS gateway.
 It should have integration with TIL for fetching data for validation and
pushing back the validated data.
 Provide a single view to the team deployed by the AGENCY for TIL
project for all the relevant functions of the TIL.
 Complete management of Tourism related service sets for both
incoming and outgoing calls from the TIL
 For all inbound calls separate caller profile needs to be created in the
CRM which can be referenced based on the contact number, 18-digit
unique ID.
 Customized out-bound call validation interface with all the necessary
details available on screen with a clear step-by-step validation steps and
necessary pop ups for validation of key columns based on business
rules.
 Call back scheduling to ensure maximum coverage on call-out services
 Should have customizable agent prompts
 Skill based Routing based on the following as per business rules:
a. Segment based routing (based on people segment information
stored in database systems)
b. Help Desk Assistant (HA) profile/skills based
c. HA Groups with necessary skill-set
 CRM should be integrated with SMS gateway depending on MOT
requirements
 Content Management / Knowledge Repository (i.e. both standard and
temporary question bank) with a robust search engine to ensure
efficient retrieval of information availability for the agent.
 Collaborative knowledge management module with role-based logins
which will act as a collaboration tool for discussion between AGENCY,
knowledge partner & MOT. Also, the tool should define the workflow
for approval of responses to new queries faced by HA before it is added
to standard question bank.
 Call quality monitoring:
 Agent scoring (by defining KPIs)
3.5. Required key features of Interactive Voice Response System (IVRS)
The key features of IVRS would include:

13

<!-- page 14 -->










IVRS should be scalable and provide ease of integration with the other
components of TIL solution.
IVRS shall interact with the callers in duplex mode through synthesized
recorded voice in Hindi/English/ international Languages depending on
region from where the call originates.
Caller may skip menu by pressing the necessary response. At any time
during the call the caller may be transferred to the Helpdesk Agent by
pressing a pre-defined number.
IVRS should be integrated with the CRM and stakeholder profiles of
previous callers can be referenced through their contact number, 18digit unique ID, based on caller input
IVRS should be able to retrieve HA availability from Automatic Call
Distributor (ACD) and announce expected callers queue waiting time
and queue length

3.6. Required Key features of ACD (Automatic Call Distributor)
Some of the key features of ACD would include:
 ACD should handle high-volume calls efficiently
 ACD should integrate seamlessly with the IVRS and PBX
 ACD tones and announcement requirements:
a. Record new announcements from a pre-recorded file
b. Record new announcements by speaking into a microphone
c. Play flash announcements i.e. short messages played to HA at
beginning of call to identify call by region or service type
d. Play intelligent delay announcements i.e. provides the caller an
estimate of how long before the call will be answered
e. Play standard delay announcements
f. Define maximum time (trigger time) before standard delay
announcement plays (able to define different times per business
unit)
g. Define delayed time (trigger time) before normal announcements
h. Provide music to callers waiting in queue
 Queue optimization, allowing the caller the option to be called back
 Abandoned call recovery, to determine the contact number of a
missed/abandoned call
 ACD should also have necessary monitoring and reporting capabilities
for supervision and monitoring.

14

<!-- page 15 -->

3.7. Required Key features of Voice Logger
Some of the key features of Voice Logger would include:
 100% automatic call recording
 Optimal Compression Techniques should be used
 Recording should be sharable amongst AGENCY personnel and MOT
through email, bulk transfer for supervisory requirements
 Ability to search through call details to locate specific calls as well as
matching records
 Flexible and easy to implement and integrate with other tools of TIL
3.8. Required Key features of Computer Telephony Integration (CTI)
Some of the key features of CTI would include:
 The CTI functionality shall support relevant screen pop-ups on the
HA‟s screen on the basis of CLI, ANI (Automatic Number
Identification), DNIS (Dialed Number Identification Sequence).
 The CTI shall enable a computer application to take control of the call
flow inside the Switch/EPABX & also allow the computer application
to decide the most suitable action / HA for an incoming call.
 The CTI link shall pass events & information of HA states & changes in
HA states as well as incoming calls to the computer applications
3.9. Special IT Features
 The solution provided by the service provider should have the provision
to use the Department of Electronics and IT, Government of India
(Deifty’s) built infrastructure namely GI Cloud the Meghraj, Mobile
Sewa, National Service Delivery Gateway.
 The service provider has to ensure that open source software should be
used for development purpose keeping in view the Government of India
policy to promote open source software across the Government
Departments for ensuring e-governance applications and systems.
 The service provider has to ensure that the application developed for
Tourist Info Line is inter-operable. There should be a provision for data
information exchange with other applications programme interface
(API). Therefore, the process of open standard should be adopted while
developing the application software for the Tourist Info Line.
 The TIL has to have a provision for its integration with other
applications to enable the Ministry of Tourism to consider integration
of the TIL application with similar such applications developed by any
15

<!-- page 16 -->

specific State or region.
 The service provider has to ensure compulsory provision for data
warehousing and business intelligence to support strategic and tactical
decision making and provide coherent picture of the Tourist Info Line
at a point in time.
 The service provide should ensure that there is end-to-end Government
process re-engineering be conducted to streamline and simplify the
process before carrying out software development. The Ministry of
Tourism at its absolute decision can get a third-party quality audit
conducted.
3.10.

Reporting

 The Reporting tool should provide a ready-to-use view into the wealth
of data gathered by Management system and service management tools.
It should consolidate data from all the relevant modules and transform it
into easily accessible business-relevant information. This information,
should be presented in a variety of graphical formats which can be
viewed interactively (slice, dice, drill down, drill through)
 The tool should allow customers to explore the real-time data in a
variety of methods and patterns, and then produce reports to analyze the
associated business and service affecting issues
 The presentation of reports should be in an easy to analyze graphical
form, enabling the administrator to put up easily summarized reports to
the management for quick action (Customizable Reports).
 Provide Historical Data Analysis: The software should be able to
provide a time snapshot of the required information as well as the
period analysis of the same in order to help in projecting the demand for
bandwidth in the future.
3.11. Critical Success Factors
Some of the critical success factors for TIL as provided below:
Quality of Tourist Advice

Service Standards

• Accuracy and adequacy of Tourism
advice.

• Delivery of services to meet the
expectations of Tourist.

16

<!-- page 17 -->

• Creation of comprehensive knowledge • Efficient validation of TIL records
database to address queries in standard as per MoT requirement
manner.
• Courteous and responsive (i.e.
• Correct information on Tourism time bound) query resolution.
programmes(national / state level) of
MoT.
Scalability
Improvisation
•Flexibility in operational framewo • Ability to quickly mold internal
rk
to
incorporate
new helpdesk processes to incorporate
services/programmes
as
the dynamically changing requirements
scope of TIL expands to include of MoT and stakeholders
other MoT programmes.
• Recruitment of resources for multiple
roles (including management, subject
matter experts or operational roles) as per
scalability requirement
•
Multitier architecture to ensure faster an
d efficient ICT efficient scalability of
ICT infrastructure

3.12

Ministry of Tourism, Government of India

 MOT will provide support to the AGENCY in smooth coordination
with the stakeholders for development of TIL application
 TCC for TIL project would be constituted and it will be responsible for
following activities:
 Overall responsibility of management of the project.
 Monitor the deliverables submitted by AGENCY, as well as coordinate
the TIL operations.
 MoT reserves the right to terminate the contract on breach of the
contract Address all issues pertaining to the project including taking on
the responsibility for the final sign off as well as annual performance
review on annual basis, terms and conditions (including RFP and
related documents) by the AGENCY. Also, TCC may extend the
project based on mutually accepted and agreed terms.
 Monitor the performance of the AGENCY through SLAs as mentioned
in this document.

17

<!-- page 18 -->

3.13. Manning the Airport Counters integrated with TIL/Helpline.
i.

09 Airport Counters with following Full Time Equivalent (Manpower)
and manning the same as per details given below:

S.No. Name of Domestic Office
1
India tourism, New Delhi
2
India tourism, Mumbai
3
India tourism, Chennai
4
India tourism, Kolkata
5
India tourism, Guwahati
6
India tourism, Bangalore
7
India tourism, Patna (Gaya Airport)
8
India tourism, Hyderabad
9
India tourism, Varanasi
10
Ahmadabad Air Port – IT, Mumbai
(Yet to be commenced )
Total

Timings
24*7
24*7
24*7
24*7
9:00 AM to 6:00 PM
24*7
9:00 AM to 6:00 PM
24*7
8:30 AM to 6:00 PM
24*7
49

ii.

The agency to man the counters as per the timings mentioned above.

iii.

Deployed manpower will interact with Tourists / Visitors face to face or
over phone and provide response to queries related to tourism in India.
( Information related to Railways, Airports, Bus, Hotels and Tourist
Places etc are required to be disseminated among tourists.
The persons manning the counter should have a knowledge of local
tourist places of the city and also other places.
Preference to local resource with desirable knowledge and good
communication skills.
To share space with India Tourism representative at facilitation center.
Resource Deployment:
 At least two Manpower during the above mentioned time at
Major International Airports.
 One Manpower during flight operating hours and may increase
as per the traffic.
 Centralized Operation Management through senior profile.
 From time to time the requirements would be reviewed and
accordingly requirements may be curtailed and increased.
Experience
 Experienced resources in handling calls in the BPO / Customer
Facing role or Tourism Industry Exposure to Tourism Industry.

iv.
v.
vi.
vii.
viii.

ix.

18

<!-- page 19 -->

(x)

(xi)

Language & Communication Skills:
 Fluent in English & Hindi.
 Excellent written English skills
 Foreign language proficiency would be additional qualification.
Key Skills
 Ability to understand the tourist requirement or complaint.
 High interpersonal interaction skills – build a rapport.
 Other preferable traits – Good knowledge of Local Tourist Places
 Having adequate knowledge in the field of tourism and
hospitality sector, particularly with reference to India's Heritage,
monuments, and ancient history.

Persons deputed at the Airport Facilitation Counter will work under the
direct supervision of the concerned Regional/India Tourism Offices.
3.14. Chat Services
i. The scope of services includes providing chat services from the Service
Provider’s delivering with Chat Application and Chat AGENTS on FTE
(Full Time Equivalent) basis.
ii. Operation window: 24x7, 365 days
iii. Operation days: 7 Days
iv. Educational qualification –
 Fluent in English & Hindi.
 Excellent written English skills
 Foreign language proficiency would be additional qualification.
 adequate knowledge in the field of tourism and hospitality sector,
particularly with reference to India's Heritage, monuments, and ancient
history.
v. Number of Chat Bots – 10 Bots
vi. Number of Manpower – Minimum two (02) manpower attending the
Chat Bots.
vii. From time to time the requirements would be reviewed and accordingly
requirements may be curtailed and increased.
 Services to be offered:
a. Information Assistance to the tourist
b. Deployment of Virtual Chat Assistant (VCA)/ Provision of live Agents
to seamlessly handle the chat interactions which the Chat-bot would not
be able to answer from the existing FTE of helpline centre.
c. Classification, Analysis and Management of emails received from
tourists
through
contact
mail
on
Incredible
India
website(info.mot@gov.in).
19

<!-- page 20 -->

3.15. For handling tourist complaints including through CPGRAM (1
Full Time Equivalent/Manpower)
 To work 5 days in a week (working days excluding Saturday, Sunday
and Government holidays) during the period 9:00 AM to 5:30 PM.
 To work with Travel Trade Division of the Ministry to handle the
subject matter related to complaints and CPGRAM.
 Good with Office working tools & applications.
 Graduate degree from a recognized University - Fluent in English &
Hindi with good writing skill.
 From time to time the requirements would be reviewed and accordingly
requirements may be curtailed and increased.
The manpower required to be manned for the services would keep on
changing as per the requirements. Further, it will also depend on the
agency quoting the same.
SECTION: 4 Minimum Eligibility Criteria for agency:
4.1. Only reputed agencies/firms who meet the given minimum eligibility
criteria, mentioned below, as on the release date of RFP, are eligible to apply
and agencies/firms which do not meet the necessary eligibility criteria will not
be considered for further evaluations.
SN
i.

ii.

20

Documentary evidence to be
submitted
The Firm / Agency should:
Copy of the Certificate of
be a company incorporated in India Incorporation / Registration / any
under the Companies Act, 1956/ other
document
to
prove
2013 and subsequent amendments proprietorship
thereto or a partnership firm Copy of PAN card
registered under LLP Act, 2008/ Copy of GST Registration
Indian Partnership Act, 1932 or a
proprietorship firm
have a valid PAN card
have valid GST registration
The Firm / Agency must have at Self-certification from authorized
least Five (05) years of experience signatory stating that the Firm /
for providing the required services Agency is in operation in India for
as mentioned in this RFP in India to the last Five (05) years
Eligibility Criteria

<!-- page 21 -->

iii.

iv.

v.

vi.

21

the Central/ State Government
organizations / PSU prior to the
publication of RFP document.
The Firm / Agency should have Turnover Certificate duly certified
an annual turnover of at least INR by Chartered Accountant along
10 Cr in each of the last three (3) with Balance Sheet and P&L
Financial Years (Either 2020-21, Statement for each of the last
,2019-20 ,2018-19 or in case audited three (3) Financial Years (Either
accounts are not available for 2020- 2020-21, ,2019-20 ,2018-19 or in
21, it may be 2019-20,2018-19, case audited accounts are not
2017-18) from the business of available for 2020-21, it may be
handling info line/call centre or 2019-20,2018-19, 2017-18) from
similar nature of services from its the business of handling info
India operations
line/call centre or similar nature of
services from its India operations
In the last 4 years– the Firm / Client Work Order/ Contract
Agency, should have successfully documents/ project completion
executed/
completed
projects certificate, within the last 4 years
of providing services of managing projects of providing services of
and operating Info Line / Call managing and operating Info Line
Centre or similar nature of project / Call Centre or similar nature of
to Central/State Government/PSU as project
to Central/State
per the below criteria:
Government/PSU
Three completed projects each with
project cost over INR 1 crore; or
Two completed projects each with
project cost over INR 3 crore;
Or One completed project with
project fee over INR 5 crore
The Firm/ Agency shall not be Self-certification
letter
under declaration of ineligibility for undertaking to this effect on
corrupt or fraudulent practices with company’s letter head signed by
any
Government
department/ company’s
authorized
agencies/ ministries or PSU’s and signatory (as per Annexure2)
should not have been blacklisted at
the time of submission of bid in
India.
The Firm / Agency should have a Self-certification on company’s
full-fledged establishment within letter head signed by an
India and an office with a dedicated authorized representative of the
team in Delhi-NCR.
agency certifying that the agency
has an office in Delhi-NCR.

<!-- page 22 -->

4.2.

Pre-Bid Meeting

No Pre-Bid Meeting would be held due to prevailing circumstances. All
prospective Bidders, requiring clarification on the bid document shall notify
Ministry of Tourism on e-mail ID: traveltradedivision@gmail.com by
17/11/2021 (1000 hrs) as per format given in Annexure 3.
Clarifications / Response to queries received will be uploaded on:
http://eprocure.gov.in/epublish/appand www.tourism.gov.in by 1700 hrs. On
24/11/2021
SECTION: 5. Instructions for preparation of proposal:
5.1 The Bidder must comply with the following instructions during
preparation of Proposals:
The original proposal (Technical Proposal and Financial Proposal) shall be
uploaded on http://eprocure.gov.in/epublish/app. The documents uploaded
shall contain no interlineations or overwriting, except as necessary to correct
errors made by the firm itself. Any such corrections must be authenticated by
the persons or person who sign(s) the proposals.
An authorized representative of the firm should authenticate all pages of the
Technical and Financial Proposals. The authorization in the form of Power of
Attorney for the representative of the firm to sign the proposal should be
attached.
The index of the bids should clearly reflect the list of documents requested in
the technical bid. All pages in the bid should be numbered.
The Technical Proposal and the Financial Proposal should be uploaded on
http://eprocure.gov.in/epublish/app as per the guidelines enumerated in this
document.
The Proposal should be submitted on or before 1500 Hrs. on 03/11/2021
No Proposal will be accepted after the deadline for submission and in the
event of any proposal being received after the closing time for submission of
proposals, the same shall be returned un-opened.

22

<!-- page 23 -->

5.2

Technical Proposal

The Technical Proposal must include the following:
a) Power of Attorney to sign the proposal
b) Documents to fulfil the requirements for Minimum Eligibility Criteria
mentioned in this RFP.
c) Letter of Technical Proposal Submission (as per the format at Annexure
4)
d) Declaration of ineligibility for corrupt or fraudulent practices
Documents (as per the format at Annexure 2)
e) The Bidders are exempted to submit EMD. Bidders are required to
submit Bid Security declaration from in prescribed format as mentioned
in Annexure 6 in lieu of EMD.
f) Format for Past experiences (as per the format at Annexure 8)
The documents submitted by the bidders for Eligibility Criteria and Technical
Evaluation Criteria shall be kept confidential by Ministry of Tourism till the
process of selection are completed.
5.3

Financial Proposal

The Financial Proposal must include the following:
a) Letter of Financial Proposal Submission (as per the format at Annexure
-5 & 5A)
b) All costs associated with the Assignment should be included in the
Financial Proposal as per format given in Annexure 5. The total
amount indicated in the Financial Proposal shall be without any
condition attached or subject to any assumption and shall be final and
binding. In case any assumption or condition is indicated in the
Financial Proposal, it shall be considered non-responsive and liable to
be rejected.
c) (Format for Financial Bid submission is provided in Annexure V.
d) (For avoidance of doubt, it is clarified that all taxes, excluding GST,
shall be deemed to be included in the cost shown under different items
of Financial Proposal. The Applicant shall be paid only GST over and
above the cost quoted in the Financial Proposal. Further, all payments
shall be subjected to deduction of taxes at source as per applicable
Laws.
e) n case of any additional cost involved in any work, the same should be
included within the relevant item of work detailed in Annexure V.
23

<!-- page 24 -->

6. Submission and opening of proposals
6.1 Bid Submission
i.

All the bids must be valid for a period of 90 days from the last date of
bid submission. No request will be considered for price revision during
the contract period. If necessary, Ministry of Tourism will seek
extension in the bid validity period beyond 90 days. The bidders, not
agreeing for such extensions will be allowed to withdraw their bids
without forfeiture of their EMD.

ii.

Proposal should be submitted on http://eprocure.gov.in/epublish/app

iii.

Bids NOT submitted as per the specified format and nomenclature will
be
out
rightly
rejected.

iv.

Bidders shall indicate their rates in clear/visible figures as well as in
words as provided in the format at Annexure 5. In case of
mismatch/Calculation Mistake in amount in words and figure,
following may be substituted: Discrepancies/ non-conformities/ errors
in the financial bid form will be addressed as follows:
a) If, in the cost structure quoted, there is discrepancy between the
unit cost and total cost, the unit cost shall prevail and the total
shall be corrected accordingly;
b) If there is an error in the total corresponding to the addition and
subtraction of the sub-totals, the sub-totals shall prevail and the
total shall be corrected; and
c) If there is a discrepancy between words and figures, the amount
in words shall prevail;
d) Such a discrepancy in an offer will be conveyed to the tenderer
asking him to respond by a target date and if the tenderer does
not agree to Procuring Entity’s observation, the tender is liable to
be
rejected
and
considered
unresponsive.

v.

The interested bidders may submit their Bid on or before the time
mentioned in his RFP.

vi.

Financial bid may be submitted as per the format for quote details for
financial bid (refer to Annexure 5: Financial Bid format)

24

<!-- page 25 -->

6.2 Bid Opening
The bids will be opened on the website in the presence of bidder’s
representatives who choose to attend the Bid opening sessions. However,
bidders may keep themselves updated about process through online login on
the bidding site. The bidders’ representatives who are present shall sign a
register evidencing their attendance. In the event of the specified date of Bid
opening being declared a holiday for the Ministry of Tourism, the Bids shall
be opened at the same time and location on the next working day. Ministry of
Tourism will open the Technical and Financial proposals for all the bidders
who submitted the proposals within the bid submission deadline.
6.2.1 Opening of Technical Proposal.
 The Technical Proposal of the bidders will be opened in the bidopening session in the presence of the bidder’s representatives.
However, the bidders may keep themselves updated about the status of
bid through online login on the e-tendering website
https://tourism.euniwizarde.com.
 Bids received without Earnest Money Deposit (EMD) will be rejected
straight way.
6.2.2 Opening of Financial Proposal:
For the purpose of opening of financial bids, Ministry of Tourism shall
shortlist only those agencies who are technically qualified (bidder securing
70% and above marks in technical evaluation). Technically qualified bidders
would be called to attend opening of financial bids.
The Financial Bids of technically unsuccessful bidders would not be opened
and shall be destroyed unopened by the Ministry of Tourism in due course.
The Financial Proposal shall be opened in the presence of qualified bidders’
representatives on a date and time which will be duly notified. However, the
technically qualified bidders may keep themselves updated about the status of
the bids through online login on the e-tendering website.

25

<!-- page 26 -->

7. Evaluation of proposals
The Selection Method will be Quality cum Cost Based System (QCBS) where
bidder will also be evaluated based on a technical presentation. The criteria
will be 70:30 where 70% weight-age will be given to Technical Bid and
30% weight-age to Financial Bid.
7.1 Technical Evaluation
i.

Ministry of Tourism will constitute an Evaluation Committee (EC) to
evaluate the responses of the bidding agencies

ii.

If there is only one bid, MOT reserves the right to process the single
bid or take recourse to the process of re-tendering.

iii.

The EC constituted by the MOT shall evaluate the responses to the RFP
and all supporting documents / documentary evidence. Inability to
submit requisite supporting documents / documentary evidence, may
lead to rejection.

iv.

All proposals received within the prescribed time limit will be
scrutinized to assess their eligibility based on the eligibility criteria and
submission of documents as mentioned in Para 4 of Section 1 under the
heading “Minimum Eligibility Criteria” of this document. The
proposals which do not meet the eligibility criteria, will be rejected,
forthwith, or at any stage of detection.

v.

The selection will be comprised of evaluation of “Technical Proposals”
of only those Agencies which meet minimum eligibility criteria,
followed by evaluation of “Financial Proposals” of only those Agencies
which get a score of 70% or more in the technical evaluation.

vi.

Any effort by a bidder to influence MOT’s bid evaluation, bid
comparison or contract award decisions may result in the rejection of
the bidder’s bid and and suitable action would be taken as per the Bid
Security Declaration.

vii.

When deemed necessary, MOT may seek clarifications on any aspect of
their bid from the bidder. However, that would not entitle the bidder to
change or cause any change in the substance of the tender submitted or
price quoted. This would also not mean that their bid has been accepted.

26

<!-- page 27 -->

viii.

MOT may waive any minor infirmity or non-conformity in a bid,
provided such waiver does not prejudice or affect the relative ranking of
any other bidder.

ix.

MOT reserves the right to accept any bid, and to cancel/abort the
Tender process and reject all bids at any time prior to award of
Contract, without thereby incurring any liability to the affected bidder
or bidders, of any obligation to inform the affected bidder of the
grounds for MOT’s action and without assigning any reasons.

x.

Technical presentation to be made to the Evaluation Committee based
on the Understanding of the project as per this RFP document:

7.2 Technical Bid Evaluation Criteria
(a)Basis on documents submitted in Technical presentation
S.No Criteria
.

Weight
-age
(Max)

1

Company Profile

35

1.1

Turnover from
BPO business

27

SDocuments Required and
uMarking Criteria
b
w
e
i
g
h
t
a
g
e
(
M
a
x
)
/
15

CA Certificate certifying the
turnover from BPO Business
of latest FY year.
(a)5 marks for fulfilling

<!-- page 28 -->

1.2

Regional Language
capabilities

5

1.3

Number of BPO
seats

10

1.4

Size of single larg
est
customer supporte
d
(Depending up on
the project value
in INR)

3

1.5

Existing
Spare capacity in
terms of BPO Seats

2

2

Qualification, Expe 10
rience of Key
Personnel, HR
Process

28

minimum
Requirement of Rs. 10 Crore
per annum.
(b) 10 marks for turnover/FY
more than 10 Crore but not
more than 15 crores.
(c) 15 marks for the
turnover/FY more than 15
crores
Matriculation certificate.
Additional two marks for
each
Regional language other than
Hindi.(As mentioned in
eighth schedule of Indian
constitution)
Work order issued by
the clients with in the latest
two(2) Financial year.
(a) Less than 400 SeatsZero marks.
(b) 5 marks for more than 400
seats but less than 600 seats.
(c) 10 marks for more than
600 seats
Certificate from the client
verifying the claim

Self-Certification

<!-- page 29 -->

2.1

Average
qualification
&experience of
agents proposed,
span of control,
attrition etc.

2Details manpower dashboard for last
one year

2.2

Proposed Project
Management &
Governance
structure

2Detailed proposal

2.3

Senior& dedicated
members assigned
for the proposed
project

1Proposed Project/Account Manager

2.4

Recruitment Process

2.5

Training

2Dedicated hiring team and brief
details of past hiring experience
3Training methodology,
trainers, trainingareas, content
and training infrastructure

(Graduation would be taken as an
average )

(b) Manpower/FTEs with multi lingual communication skill out of 10 foreign
languages as mentioned at para 3.1 (iv) besides English and official language
Hindi.
S.No. Criteria

3

29

Weight Sub-weight- Documents Required and
-age
age
Marking Criteria
(Max) (Max)/

Manpower/FTEs 10
with multi lingual
communication
skill besides
Hindi and
English language

<!-- page 30 -->

3.1

(a) More than 4
and up to 10 FTEs
with multi lingual
communication
skill

5 marks

At least 6 months Diploma
Certificate issued by any
recognised/registered
institute in each language
for the employees claimed
for multilingual skill in
foreign language .

3.2

(b) More than
10 andupto 15
FTEs with multi
lingual
communication
skill - 8 marks

8 marks

3.3

(c) More than 15
manpower

10 marks

At least 6 months Diploma
Certificate issued by any
recognised/registered
institute in each language
for the each employee
claimed for multilingual
skill in foreign language
At least 6 months Diploma
Certificate issued by any
recognised/registered
institute in each language
for the each employee
claimed for multilingual
skill in foreign language

(c). Basis on Technical Presentation made before the Committee
S.No Criteria
.

Wei Sub- Documents Required
ght weight
-age -age
(Ma (Max)
x)
25

4

Methodology, Work
plan & Understanding
of the Requirements

4.1

Robustness of Implement
ation Plan

10

4.2

Work Force Management

5

30

Level
of detail, risk
mitigation, practicality ,number
of locations
Plan for ramp-up/ /maintaining
multi-lingual proficiency.

<!-- page 31 -->

4.3

Physical infrastructure

3

4.4

Redundancy and
scalability

2

4.5

SLA commitments
offered and additional
KPIs monitored
Case Studies

5

5
5.1
5.2

5.3

Similar Multi-channel
projects
Ability to ramp-up of
resources in short timeCase Study
BCP/DR capability
(Technology and Plan)
Total weight-age

Adequacy in terms of suitability
of location, physical
and
data security, power back up,
environmental
protection telecom infrastructure.
Successful projects detailing the
retention and
scalability
as and when required
Service level parameters
and details of KPIs monitored

20
5

Case Study

8

Case Study

7

Case Study

100 100

Note:
Supporting Documents are required to be submitted in accordance with the
Technical Evaluation Criteria above.
Two properly marked CDs containing the information, as per the
Technical Evaluation parameters are required to be submitted.
The Ministry of Tourism (MoT) reserves the right to visit any or all of the
short-listed bidders for a physical verification of stated capacities and
capabilities. Discrepancy between stated capacity/capabilities and
site verification shall be reviewed by the committee while taking any final
decision about evaluation of Technical Bid.
disqualification.

31

<!-- page 32 -->

8 Financial Evaluation
i.
ii.
iii.

iv.

v.

The financial bids of only technically qualified bidders will be opened
in the presence of bidders’ representatives.
EC would scrutinize the financial bids. The bids found lacking in strict
compliance to the financial bid format shall be rejected straightaway.
Financial bids will be evaluated based on total price. Any alteration /
overwriting / cutting in the bid should be duly countersigned else it will
be out rightly rejected. Conditional tenders shall NOT be accepted on
any ground and shall be rejected straightway
For consideration of their bids, the bidders must quote rates for all the
resources in the detailed financial bid (refer to Annexure 5: Financial
Bid format)
For avoidance of doubt, it is clarified that all taxes, excluding GST,
shall be deemed to be included in the cost shown under Financial
Proposal. The Applicant shall be paid only GST over and above the cost
quoted in the Financial Proposal. All payments shall be subjected to
deduction of taxes at source as per applicable Laws.

9. Overall Evaluation
Selection of agency / firm will be based on the aggregate scores of
the Technical Evaluation and Financial Evaluation. The agency / firm
which scores the highest aggregate score would be awarded the contract.
The
overall
evaluation
process
is
mentioned
below:
i.

ii.
iii.
iv.

The EC would evaluate the proposals for short listing only those
bidding agencies which fulfil the minimum eligibility criteria as
mentioned in this document.
EC would evaluate the technical bids of only the shortlisted agencies.
EC would evaluate the financial bids of only those agencies which
score at least 70% or above marks in the technical evaluation phase.
For each of the bidders, a Normalized Commercial Score would be
calculated by the Financial Evaluation Committee. The methodology
for calculation of Normalized Commercial Score is given below:

Normalized Commercial Score of a Bidder = {Lowest Financial Bid /
Financial Bid of the bidder under consideration} X 100 (adjusted to 2
decimals)
Final Score= 0.70 * Technical Score + 0.30 * Normalized Commercial Score
32

<!-- page 33 -->

10. Award of Contract / Work order
On selection of the agency/firm and acceptance of financial quote submitted
by the selected agency, a Letter of Intent (LOI) would be issued to the agency.
On receipt of LOI, the agency would submit a letter of acceptance. A
performance guarantee Para 12 below will be submitted within 15 working
days of receiving LOI. Thereafter, a detailed work order will be issued to the
agency.
11. Submission of Performance Guarantee
The selected agency must submit Performance Guarantee (PG) in the form of
Bank Guarantee as per format in Annexure 7 from a scheduled bank for 3% of
the total contract value having validity of 60 days beyond the date of
completion of the two years of contract. In case of contract is extended for one
year, the selected agency shall again submit Performance Guarantee (PBG)
for the extended period having validity of 60 days beyond the extended date
of contract.
In case of any deficiency and unsatisfactory performance by the agency, the
Performance Guarantee would be invoked and the payment due to the agency
would be withheld. No interest will be paid by Ministry of Tourism on the
Performance Guarantee. In the event of any amendments to Agreement, the
Bidder shall within 15 days of receipt of such amendment furnish the
amendment to the Performance Guarantee as required.
12. Terms and Conditions
12.1 Indemnity and Limitation of Liability
i.

33

The “Indemnifying Party” undertakes to indemnify, hold harmless the
“Indemnified Party” from and against all claims, liabilities, losses,
expenses (including reasonable attorneys’ fees), fines, penalties, taxes
or damages (Collectively “Loss”) on account of bodily injury, death or
damage to tangible personal property arising in favour of any person,
corporation or other entity (including the Indemnified Party)
attributable to the Indemnifying Party’s negligence or wilful default in
performance or non-performance under this Agreement

<!-- page 34 -->

ii.

If the Indemnified Party promptly notifies Indemnifying Party in
writing of a third party claim against Indemnified Party that any Service
provided by the Indemnifying Party infringes a copyright, trade secret
or patents incorporated in India of any third party, Indemnifying Party
will defend such claim at its expense and will pay any costs or
damages, that may be finally awarded against Indemnified Party

iii.

Indemnifying Party will not indemnify the Indemnified Party, however,
if the claim of infringement is caused by:



Indemnified Party’s misuse or modification of the Service;
Indemnified Party’s failure to use corrections or enhancements made
available by the Indemnifying Party;
Indemnified Party’s use of the Service in combination with any product
or information not owned or developed by Indemnifying Party;




However, if any service, information, direction, specification or materials
provided by Indemnified Party or any third party contracted to it, is or likely
to be held to be infringing, Indemnifying Party shall at its expense and option
either:




Procure the right for Indemnified Party to continue using it
Replace it with a non-infringing equivalent
Modify it to make it non-infringing

The foregoing remedies constitute Indemnified Party’s sole and exclusive
remedies and Indemnifying Party’s entire liability with respect to
infringement.
iv.

The indemnities shall be subject to the following conditions:

a. the Indemnified Party as promptly as practicable informs the Indemnifying
Party in writing of the claim or proceedings and provides all relevant
evidence, documentary or otherwise;
b. the Indemnified Party shall, at the cost of the Indemnifying Party, give the
Indemnifying Party all reasonable assistance in the Defence of such claim
including reasonable access to all relevant information, documentation and
personnel provided that the Indemnified Party may, at its sole cost and
expense, reasonably participate, through its attorneys or otherwise, in such
Defence;

34

<!-- page 35 -->

c. if the Indemnifying Party does not assume full control over the Defence of a
claim as provided in this Article, the Indemnifying Party may participate in
such Defence at its sole cost and expense, and the Indemnified Party will
have the right to defend the claim in such manner as it may deem
appropriate, and the cost and expense of the Indemnified Party will be
included in Losses;
d. the Indemnified Party shall not prejudice, pay or accept any proceedings or
claim, or compromise any proceedings or claim, without the written consent
of the Indemnifying Party;
e. all settlements of claims subject to indemnification under this Clause will
be entered only with the consent of the Indemnified Party, which consent
will not be unreasonably withheld and include an unconditional release to
the Indemnified Party from the claimant or plaintiff for all liability in
respect of such claim; andinclude any appropriate confidentiality agreement
prohibiting
disclosure
of
the
terms
of
such
settlement;
i. the Indemnified Party shall account to the Indemnifying Party for all
awards, settlements, damages and costs (if any) finally awarded in
favour of the Indemnified Party which are to be paid to it in connection
with any such claim or proceedings;
ii. the Indemnified Party shall take steps that the Indemnifying Party may
reasonably require to mitigate or reduce its loss because of such a claim
or proceedings;
iii. in the event that the Indemnifying Party is obligated to indemnify an
Indemnified Party pursuant to this Article, the Indemnifying Party will,
upon payment of such indemnity in full, be subrogated to all rights and
defences of the Indemnified Party with respect to theclaims to which
such indemnification relates; and if a Party makes a claim under the
indemnity set out under this section, in respect of any particular Loss or
Losses, then that Party shall not be entitled to make any further claim in
respect of that Loss or Losses (including any claim for damages)
iv. The Bidder shall indemnify the Ministry of Tourism from and against
any costs, loss, damages, expense, and claims arising from third parties
or liabilities of any kind howsoever suffered, arising or incurred inter
alia during and after the Contract period out of any negligence or
wrongful act or omission by the Bidder or any third party associated
with the Bidder in connection with or incidental to this Contract; or
35

<!-- page 36 -->

v. any breach of any of the terms of the Bidder’s Bid as agreed, the RFP
and thisContract by the Bidderany infringement of patent,
trademark/copyright or industrial design rights arising from the use of
the supplied goods and related services or any part thereof
vi. The Bidder shall also indemnify the Ministry of Tourism against any
privilege, claim or assertion made by a third party with respect to right
or interest in, ownership, mortgage or disposal of any asset, property
etc.
vii. The liability of either Party (whether in contract, tort, negligence, strict
liability in tort, by statute or otherwise) for any claim in any manner
related to this Agreement, including the work, deliverables or Services
covered by this Agreement, shall be the payment of direct damages
only which shall in no event exceed one time the total contract value
payable under this Agreement. The liability cap given under this Clause
shall not be applicable to the indemnification obligations set out in this
Section.
viii. In no event shall either party be liable for any consequential, incidental,
indirect, special or punitive damage, loss or expenses (including but not
limited to business interruption, lost business, lost profits, or lost
savings) nor for any third-party claims (other than those set forth in
Point 1 of this section) even if it has been advised of their possible
existence.
ix. The allocations of liability in this section represent the agreed and
bargained-for understanding of the parties and compensation for the
Services reflects such allocations. Each Party has a duty to mitigate the
damages and any amounts payable under an indemnity that would
otherwise be recoverable from the other Party pursuant to this
Agreement by taking appropriate and commercially reasonable actions
to reduce or limit the amount of such damages or amounts.
x. Regardless of anything contained (except for the Bidder’s liability for
bodily injury and/ or damage to tangible and real property for which it
is legally liable and its liability for patent and copyright infringement in
accordance with the terms of this Agreement) the total liability of the
Bidder, is restricted to the total value of the contract and the Bidder is
not responsible for any third party claims

36

<!-- page 37 -->

13.

Amendment of RFP Document

At any time before the deadline for submission of bids, MoT may, for any
reason, whether at own initiative or in response to a clarification requested by
a prospective Bidder, modify the bidding document by amendment. If
required, MoT also reserves the rights to extend the deadline for the
submission of bids. Any modifications in the RFP Document would
be conveyed
through
notifications
on
the
websites
https://tourism.euniwizarde.com and www.tourism.gov.in.
14. Bid Security
i.

ii.

To safeguard against a bidder’s withdrawing or altering its bid during
the bid validity period, Bid Security referred to as Bid Security
Declaration Form at annexure VI shall be obtained from the bidders.
The appropriate action would be taken as per the terms and conditions
specified in the Bid Security Declaration Form

SECTION 6: SCHEDULE FOR COMPLETION OF TASK
15. Project Plan and Time line
The AGENCY will have to synchronize various activities and adhere to the
time schedule as provided in the table below:
S.No
1

37

Activities
Time
a. Establishment of Hardware Infrastructure 8- 10 weeks from
& Software Infrastructure for TIL.
date of agreement
b. Establishment of Telecommunications signing.
Infrastructure for TIL
c. Establishment of Non-IT Infrastructure for
TIL.
d. Design, Development, Testing and
Implementation of TIL Solution
e. Prepare the FRS (Functional Requirement
Specification) Document
f. Prepare the SRS (System Requirement
Specification) Document and the System
Design Document (SDD)
g. Develop a prototype of the TIL Solution
h. Develop the TIL Solution
i. Earmarking and Mobilization of TIL Team
j. Mobilization of Core Team

<!-- page 38 -->

2

3

k. Mobilization of Operational Team
l. Creation of Knowledge Repository
m. Preparation of Standard Operating
Procedures and Information Security
Guidelines & Protocol for TIL
n. Capacity Building
o. Preparation of Training Manuals for
Helpdesk Agents
p. Training on TIL Application to the
Helpdesk Agents
q. Go-Live / Operationalization of TIL
r. Operation & Maintenance of TIL Project 3 Years
for a period of 3 years from the date of GoLive of TIL
s. On-going Support for Implementation of As and when
Additional Requirements of MoT during required during the
the period of 3 years from the date of Go- period of 3 years
Live of TIL project.
from the date of
Go-Live of TIL
project.

15.1 In case of addition of any other programs of Ministry of Tourism
to the TIL, the timelines for incorporation and implementation of the
same shall be mutually discussed between the appointed AGENCY and
MOT.
I.

II.

III.

38

If the successful bidder fails to offer the services within the periods as
specified in the schedule above, MOT shall, without prejudice to its
other remedies under the Bid, deduct from the performance security, as
liquidated damages, a sum equivalent to 0.25% of the total cost of the
contract value for each week or part thereof of delay until Final
Acceptance, up to a maximum deduction of the 10% of the total
contract value. However, if the cumulative delay is more than 45 days,
MOT has the right to terminate the contract and invoked the
performance security and the amount of Bank Guarantee would be
appropriated to Government Account.
The bidder will strictly adhere to the timelines quoted in the RFP and
any delay on behalf of AGENCY will be liable to the penalty of 0.25%
per week of the contract value
The Bidder will submit detailed presentation on the methodology with
timelines for the execution of the project along with the Proposal as per
Scope of Work specified in the RFP

<!-- page 39 -->

16. Review of Deliverables
Ministry of Tourism will review each deliverable within agreed time frame
and will issue “Permission to Proceed” or “Permission to Proceed subject to
certain conditions”.
17. Roles and Responsibilities
17.1. Successful Bidder / AGENCY

















39

AGENCY shall procure, install, operate, maintain, upgrade and provide
support for the complete infrastructure (IT, non IT and others) required
for the TIL project for the complete duration of the project on turnkey
basis.
AGENCY shall have the complete responsibility of data security for the
TIL project
AGENCY shall manage the overall project as a single point of contact.
AGENCY shall obtain the license of call center operation for the
project.
AGENCY shall prepare and Monitor the Project Plan, Periodic Status
Reports, Training Guidelines & Modules, Knowledge Management
Protocol, prepare and submit risk and mitigation strategies, Review
Meetings etc.
AGENCY shall understand the business requirements of the MOT for
TIL as well as other programmes of the Ministry as and when they are
planned to be rolled out through TIL.
Continual revision in the formats and data to be incorporated by the
AGENCY in the weekly / fortnightly / monthly /quarterly / yearly
reports to be submitted with regards to TIL operations & SLAs.
AGENCY shall prepare guidelines and details of the changes if any that
are required in the CRM, IVRS applications, reporting formats
AGENCY shall provide training to Helpdesk Agents, select members of
training Agency and select officials of MOT.
The complete responsibility to commission, operate, upgrade and
maintain the non IT components of TIL project (As mentioned in the
scope of the project) including access control system, CCTV cameras,
power etc. would be the responsibility of AGENCY
Any other IT and non-IT components that would be required for smooth
operation of TIL project should be procured, commissioned, operated,
upgraded and maintained by the AGENCY during the entire project
period

<!-- page 40 -->











AGENCY shall establish and maintain the specified Service Level
Agreement (SLAs.). AGENCY should provide all the system generated
reports that is required to monitor the SLA for the project
AGENCY shall undertake regular maintenance and upgradation of the
system to ensure its optimum utilization and performance.
AGENCY shall have the responsibility to maintain discipline of the
office environment and safety of the helpdesk, Helpdesk Agents and
other support staffs deployed at the TIL site.
AGENCY shall provide maintenance, upgrade and support all
components (including IT and non IT) of TIL Project.
The AGENCY would ensure that all laws, rules and guidelines
governing the operation of call centers like safety of employees,
reimbursement for night working hours etc. should be strictly adhered
to
The AGENCY would ensure that all laws, acts, rules and guidelines
governing the applications and the security guidelines of Ministry of
Communications & Information Technology are adhered to.

SECTION 7: Termination of Contract
18. Termination for Default
MoT may, without prejudice to any other remedy for breach of contract, by
written notice of default sent to the successful Bidder, terminate the contract
in whole or in part if:
 The successful Bidder fails to deliver any or all of the obligations
within the time period(s) specified in the contract or any extension
thereof granted by the MoT.
 The successful Bidder fails to perform any obligation(s) under the
contract.
However, the disputes if any, may be referred to Arbitration as per clause 36
19. Termination for Insolvency, Dissolution etc
MoT may at any time terminate the contract by giving written notice to the
successful bidder without compensation to the successful bidder, if the
qualified Bidder becomes bankrupt or otherwise insolvent or in case of
dissolution of firm or winding up of company, provided that such termination
will not prejudice or effect any right of action or remedy which has accrued
thereafter to MoT.

40

<!-- page 41 -->

20. Termination for Convenience
Either party reserves the right to terminate by prior written notice, the whole
or part of the contract. The notice of termination shall specify that termination
be for either party convenience, the extent to which performance of work
under the contract is terminated and the date on which such termination
becomes effective.
21. No Claim Certificate
The successful bidder shall not, be entitled to make any claim, whatsoever,
against MoT under or by virtue of or arising out of this contract nor shall MoT
entertain or consider any such claim after bidder shall have signed a "no
claim" certificate in favour of MoT in such forms as shall be required by MoT
after the works are finally accepted.
22. Suspension
MoT may by a written notice of suspension, suspend all payments to the
successful bidder under the contract, if the successful bidder fails to perform
any of its obligations under this contract, (including carrying out of the
services) provided such notice of suspension:



shall specify the nature of the failure and
shall request the successful bidder to remedy such failure within a
specified period from the date of' issue of such notice of suspension.

23. Consequences of Termination
a. In the event of termination of this contract due to any cause whatsoever
accept „Termination for Convenience‟, the AGENCY shall be liable for
any legal recourse including blacklisting by the Ministry.
b. In the event of termination of this Contract due to any cause
whatsoever, whether consequent to the stipulated Term of the Contract
or otherwise the Ministry shall be entitled to impose any such
obligations and conditions and issue any clarifications as may be
necessary to ensure an efficient transition and effective business
continuity of the project which the AGENCY shall be obliged to
comply with and take all available steps to minimize loss resulting from
that termination/breach and further allow and provide all such
assistance to the Ministry and/or the successor AGENCY, as may be
required to take over the obligations of the erstwhile AGENCY in
41

<!-- page 42 -->

relation to the execution/continued execution of the scope of this
Contract.
c. Nothing herein shall restrict the right of the Ministry to invoke the Bank
Guarantee and other Guarantees furnished hereunder, enforce the Deed
of Indemnity and pursue such other rights and/or remedies that may be
available to the Ministry under law.
d. The termination hereof shall not affect any accrued right or liability of
either Party nor affect the operation of the provisions of this Contract
that are expressly or by implication intended to come into or continue in
force on or after such termination.
24. Withdrawal by the AGENCY
AGENCY at any point of time during project duration, if withdraws from the
project, shall constitute sufficient grounds for the annulment of the award and
in case of exigency, if the Ministry gets the work done from elsewhere, then
AGENCY will fully cooperate in the migrating of process to the other service
provider.
25. Intellectual Property Rights (IPR)

42



MoT shall own and have a right in perpetuity to use all Intellectual
Property Rights (IPR) which have arisen out of or in connection with
the implementation of this project, including all processes, products,
data, knowledge products, training material and other documents which
have been developed by the AGENCY during the performance of
Services and for the purposes of inter-alia use or sub-license of such
services under this project. The AGENCY undertakes to disclose all
Intellectual Property Rights arising out of or in connection with the
performance of the services to the MoT and execute all such
agreements/documents and file all relevant applications, effect transfers
and obtain all permits and approvals that may be necessary in this
regard to effectively transfer and conserve the Intellectual Property
Rights of the MoT.



Further, if the MoT desires, the AGENCY shall be obliged to ensure
that all approvals, registrations, licenses, permits and rights which are,
inter-alia, necessary for use of the systems/ equipment installed by the
AGENCY, the same shall be acquired in the name of the MoT, prior to
termination of this project and which shall be assigned by the MoT to
the AGENCY for the purpose of execution of any of its obligations

<!-- page 43 -->

under the terms of the bid or this project. However, subsequent to the
termination of this project, such approvals etc. shall ensure to the
exclusive benefit of the MoT.




43

The AGENCY shall ensure that while it uses any software, hardware,
processes or material in the course of performing the Services, it does
not infringe the Intellectual Property Rights of any person and the
AGENCY shall keep the MoT indemnified against all costs, expenses
and liabilities howsoever, arising out of any illegal or unauthorized use
(piracy) or in connection with any claim or proceedings relating to any
breach or violation of any permission/license terms or infringement of
any Intellectual Property Rights by the AGENCY during the course of
performance of the services.
Information Security: The AGENCY shall not carry and/ or transmit
any written material, information, layouts, diagrams, storage media
(hard disk/ tapes) or any other goods/ materials in physical or electronic
form, which are proprietary to or owned by the MoT out of TIL
premises without prior written permission from the MoT. The
AGENCY personnel and sites shall comply with ISO 27001 standards.
AGENCY acknowledges that MoT‟s business data and other MoT
proprietary information or materials, whether developed by MoT or
being used by MoT pursuant to a license agreement with a third party
(the foregoing collectively referred to herein as “proprietary
information”) are confidential and proprietary to MoT; and AGENCY
agrees to use reasonable care to safeguard the proprietary information
and to prevent the unauthorized use or disclosure thereof, which care
shall not be less than that used by AGENCY to protect its own
proprietary information. AGENCY recognizes that the goodwill of
MoT depends, among other things, upon AGENCY keeping such
proprietary information confidential and that unauthorized disclosure of
the same by AGENCY could damage the MoT, by reason of
AGENCY‟s duties hereunder. AGENCY may come into possession of
such proprietary information, even though AGENCY does not take any
direct part in or furnish the services performed for the creation of said
proprietary information and shall limit access thereto to employees with
a need to such access to perform the services required by this
agreement. AGENCY shall use such information only for the purpose
of performing the said services. AGENCY shall, upon termination of
this project for any reason, or upon demand by MoT, whichever is
earliest, return any and all information provided to AGENCY by MoT,
including any copies or reproductions, both hardcopy and electronic.

<!-- page 44 -->



MoT shall retain all right, title and interest in and to any and all data,
entered or generated by the AGENCY for MoT pursuant to this
agreement and any modifications thereto or works derived there from.

SECTION 8: Payment Terms
26. Schedule of Payments
AGENCY will have to setup the helpdesk conforming to the scope mentioned
in the RFP. In this regard, AGENCY may be given the advance (if asked for,
as per the terms and conditioned defined in the RFP) as per the formula
mentioned in the table below. After the go live of the TIL project, AGENCY
shall be paid the bills raised by the AGENCY based on the no. of FTE on
quarterly basis. On-going support for implementation of additional
requirements of MoT shall be paid additionally based on the rates provided by
AGENCY in this document.
Sl. No.
1.

2.

44

Payment
Time of Payment
Milestones
M1: Advance Start of Project
(Payment in two
equal instalments)

Payment Formula

Advance* = Upto 20% of the
contract value of the project in
two equal instalments on
submission of Single Bank
Guarantee for the amount equal
to 110% of the advance
requested.
First instalment will be paid at
the time of signing of the
contract.
Second instalment will be paid
at the time of Go-Live of TIL
project.
Advance paid to the AGENCY
will be adjusted on quarterly
payments
made
to
the
AGENCY
in
8
equal
instalments.
M2: Payment Schedule for
Payable
Amount =
during
completion of task, (Helpdesk FTE rate quoted by
stabilization Phase II, point No the AGENCY for the first year
period of the 1(Project plan and in the financial bid as
project
Timeline).
mentioned in Annexure 5 &
5A) X (average no. of FTE per

<!-- page 45 -->

3.

month for that quarter) * 3
M3: Payment After the
Payable Amount = {(Helpdesk
after the
stabilization period FTE rate quoted by the
stabilization till the entire
AGENCY for the respective
period till the duration of the
year in the financial bid as
entire duration project
mentioned in Annexure 5 &
of the project (quarterly basis
5A) X (average no. of FTE for
payments till the rest the respective quarter)}* 3
of the duration of the
project)

*Advance paid to the AGENCY will be adjusted on quarterly payments made
to the AGENCY in 8 equal instalments. This value of advance is exclusive of
the telecom, data bandwidth, SMS charges to be reimbursed by the Ministry.
Also, AGENCY shall provide a bank guarantee of amount equal to 110% of
the advance requested.

Note:









The invoices towards the services rendered by the AGENCY shall be
submitted to MoT as per the schedule given above. MoT shall release the
payments after checking the invoices as per agreement subject to satisfactory
performance of the AGENCY and adherence to SLAs and other conditions
of the RFP.
All taxes, GST, duties etc. shall be payable by the AGENCY. However, in
case of change or revision of Service Tax, the payment will be made as
applicable. The documentary evidences for payment of service tax will be
submitted by the AGENCY.
Mandatory taxes/duties etc. as applicable shall be deducted by MoT.
For modification in seats or addition of seats adequate amount would be
adjusted /increased in line with the rates quoted by the AGENCY in the
financial format as provided in Annexure 5 & 5A of the RFP. However, the
same would be finalized by the Technical Coordination Committee in
discussion with the AGENCY.
For implementation of additional requirements of the MoT (including
addition of other programmes of the MoT) beyond the estimated 10 manmonth effort; the effort estimate, the payment model would be finalized by
the Technical Coordination Committee in discussion with the AGENCY.

45

<!-- page 46 -->

SECTION 9: Miscellaneous
27. Standards
The services to be rendered under the contract to be signed between MoT and
selected bidder on stamp paper shall conform to the standards mentioned in
this document, and in case no applicable standards are mentioned, to the latest
authoritative standards as laid down by the competent institution governing
that standard.
28. Standard of Performance
The selected bidder shall render the service and carry out its obligations under
the contract with due diligence, efficiency and economy in accordance with
generally accepted norms, techniques and practices used in the industry.
29. Time for Implementation of the Project
The successful bidder shall complete and implement the project within the
agreed time frame starting from the date of award of contract. The
implementation schedule specified in this RFP shall be strictly adhered to.
30. Right to Inspect Support Facilities
MoT shall reserve the right to inspect the premises to be used for the purpose
of this project without any prior notice.
31. Confidentiality
The selected bidder and its personnel shall not, either during the term or after
expiration of this project, disclose any proprietary or confidential information
relating to the services, contract or MoT's business or operations without the
prior written consent of MoT.
32. Force Majeure




46

Notwithstanding the conditions of the bid, the bidder shall not be liable
for forfeiture of its performance guarantee, liquidated damages or
termination for default, if and to the extent that, its delay in
performance or other failure to perform its obligations under the
contract is the result of an event of Force Majeure.

<!-- page 47 -->



For purposes of this Clause, "Force Majeure" means an event beyond
the control of the bidder and not involving the bidder's fault or
negligence and not foreseeable. Such events may include, but are not
restricted to, acts of MoT either in its sovereign or contractual capacity,
wars or revolutions, fires, floods, earthquakes, epidemics, quarantine
restrictions and freight embargoes.



If a Force Majeure situation arises, the successful bidder shall promptly
notify the MoT in writing of such conditions and the cause thereof.
Unless otherwise directed by MoT in writing, the bidder shall continue
to perform its obligations under the contract as far as reasonably
practical and shall seek all reasonable alternative means for
performance not prevented by the Force Majeure event.



MoT may terminate the contract, by giving a written notice of
minimum 30 days to the bidder, if as a result of Force Majeure the
Bidder is unable to perform a material portion of the services for a
period of more than 60 days.

33. Arbitration and Jurisdiction


In the event of any dispute relating to the import or meaning of any
terms and conditions which could not be solved amicably by the parties,
the parties may refer the matter to the Arbitrator to be appointed by the
MoT on the request of either of the parties for arbitration in consonance
with the provisions of the Arbitration and Conciliation Act, 1996(Act
26 of 1996), on the designated reference in dispute. All legal
proceedings shall lie to the jurisdiction of courts situated in New Delhi.

34. Review Meetings


There shall be weekly / fortnightly meetings to review functionality
issues and progress of work. The frequency of meetings will be
mutually decided at the time of signing of the contract. All matters
which are not resolved during the review meeting will be escalated as
per the escalation procedure mutually agreed by both the parties.

35. Progress Reporting and escalation procedures


47

The selected bidder should submit weekly / fortnightly report. These
reports shall indicate the progress of work and matters that need
escalation or which are pending for decision. In particular, the timeschedule shall be reported for each individual deployed.

<!-- page 48 -->

36. Period of contract
MoT intends to appoint a selected bidder / AGENCY for the time period as
mentioned in this RFP. The time period mentioned in the agreement as
mutually decided by both the parties will need to be strictly adhered to.
37. Indemnity


The AGENCY shall execute and furnish a Deed of Indemnity in favour
of the MoT in a form and manner acceptable to the MoT, indemnifying
the MoT from and against any costs, loss, damages, expense, claims
including those from third parties or liabilities of any kind howsoever
suffered, arising or incurred inter alia during and after the contract
period out of:



any negligence or wrongful act or omission by the AGENCY or the
AGENCY‟s team or third party in connection with or incidental to the
contract; or



any breach of any of the terms of the AGENCY‟s bid as agreed, the bid
and the contract by the AGENCY, the AGENCY‟s team or any
member of third party.



The indemnity shall be to the extent of 3 months of billing in favour of
the MoT.

38. Exit Management Schedule
Exit management schedule shall be a part of the contract to be signed in
between MoT and selected bidder.
38.1 Exit management
38.1.1 Purpose:
a. This clause sets out the provisions which will apply on expiry or
termination of the “Contract”, the “SLA (Service Level Agreement)”
and “RFP (Request of Proposal)”.
b. The AGENCY shall carry out its obligations set out in this Exit
Management Clause.

48

<!-- page 49 -->

38.1.2 Transfer of Assets
a. The AGENCY shall be entitled to use the facilities for the duration of
the exit management period. The “asset” in this regard would be
considered as the complete infrastructure that is provided to the
AGENCY by MoT and the infrastructure set up by the AGENCY for
TIL project.
b. The MoT at any time during the exit management period may ask
AGENCY to provide a complete and up to date list of the Assets within
30 days of such notice. All the Assets detailed in the list shall be handed
over to MoT within the time period as indicated to the AGENCY by
MoT.
c. Upon service of a notice as mentioned in point above, the following
provisions shall apply:
i.

The Assets to be handed over to the Ministry shall be free from
any lien and liabilities.

ii.

All asset/ infrastructures that is procured and installed at TIL site
by the AGENCY shall be owned by the MoT.
On the expiry of this clause, the AGENCY shall handover all
confidential information and all other related materials in its
possession to the Ministry.

iii.

iv.

The infrastructure, data and information delivered to the AGENCY
by the Ministry during the contract term or on expiry of the
contract duration should not be sold or re-used or copied or
transferred by the AGENCY without prior written notice and
approval of the Ministry. The complete infrastructure at the TIL
site shall be the legal properties of the Ministry.

38.1.3 Cooperation and Provision of Information during the exit
management period:
a. The AGENCY shall allow the Ministry or its nominated agencies the
access to information reasonably required to define the then current
mode of operation.
b. The Ministry or its nominated agencies shall be entitled to copy all
related information. Such information shall include details pertaining to
the daily operation, asset, human resource details, calling details,
49

<!-- page 50 -->

system details, application details and other performance data. The
AGENCY shall permit the Ministry or its nominated agencies to have
reasonable access to its employees and facilities as reasonably required
to understand the TIL operations and to assist appropriate knowledge
transfer.
39. Exit Management Plan
39.1.1 The AGENCY shall provide the Ministry with a recommended "Exit
Management Plan", which shall deal with at least the following aspects of exit
in relation to the Project Implementation:
a. A detailed program of the transfer process that could be used in
conjunction with a Replacement Successful Bidder including details of
the means to be used to ensure continuing provision of the services
throughout the transfer process or until the cessation of the services and
of the management structure to be used during the transfer;
b.
b. Plans for the communication with various stakeholders including
Ministry and any related third party as are necessary to avoid any
material detrimental impact on TIL projects’ operations as a result of
undertaking the transfer; Plans for provision of contingent support to
TIL project and Replacement Successful Bidder for a reasonable period
after transfer.
39.1.2 The AGENCY shall re-draft the Exit Management Plan annually
thereafter to ensure that it is kept relevant and up to date.
39.1.3 Each Exit Management Plan shall be presented by the Successful
Bidder to and approved by the Ministry or its nominated agencies.
39.1.4 The terms of payment as stated in the Terms of Payment Schedule
include the costs of the Successful Bidder complying with its obligations
under this Schedule.
39.1.5 In the event of termination or expiry of SLA, Project Implementation,
Operation and Management SLA or Contract each Party shall comply with the
Exit Management Plan.
39.1.6 During the exit management period, the Successful Bidder shall use its
best efforts to deliver the services.

50

<!-- page 51 -->

39.1.7 Payments during the Exit Management period shall be made in
accordance with the Terms of Payment Schedule.
39.1.8 This Exit Management plan shall be furnished in writing to the
Ministry or its nominated agencies within 15 days from the Effective Date of
this Agreement and seek the approval.
40. Right to Vary Quantity
At the time of award of contract, the quantity of manpower resources and
services originally specified in the bidding documents may be
increased/decreased. It shall be without any change in the service charge or
other terms and conditions of the Bid and the bidding documents. If the MOT
does not procure/engage any subject matter of procurement or procures less
than the quantity specified in the bidding documents due to change in
circumstances, the bidder shall not be entitled for any claim or compensation
except otherwise provided in the bidding document.
41. Limit of Liability
There shall be no limitation of liability in case of any damages for bodily
injury (including death) and damage to real property, tangible personal
property, intangible personal property and intellectual property rights.
However, where there has been misconduct, gross negligence, dishonesty or
fraud on behalf of the AGENCY, the AGENCY‟s liability under this Contract
shall be subject to the amount of price during 3 months of billing.
42. Insurance
The AGENCY shall maintain standard forms of comprehensive insurance
including liability insurance, system and facility insurance and any other
insurance for the personnel, assets, data, software, etc. for entire duration of
the contract.
43. Withdrawal, Substitution, and Modification of Bids
i.

A Bidder may withdraw the Bid or re-submit the Bid (technical and/or
financial) as per the instructions/ procedure mentioned at eProcurement website

ii.

Bids withdrawn shall not be opened and processed further.

51

<!-- page 52 -->

iii.

The Consultants would indemnify Ministry of Tourism against any
claim of copyright violation / plagiarism, etc.

Bidder may use data, software, designs, utilities, tools, models, systems and
other methodologies and know-how (“Materials”) that bidder own in
performing the Services. Notwithstanding the delivery of any Reports, bidder
retain all intellectual property rights in the Materials (including any
improvements or knowledge developed while performing the Services), and in
any working papers that bidder compile and retain in connection with the
Services (but not Client Information reflected in them). Upon payment for the
Services, Client may use any Materials included in the Reports, as well as the
Reports themselves as permitted by this Agreement.
Interested bidders may submit bids as per the requirements stipulated in this
document latest by 1500 Hrs. on 03/12/ 2021.

52

<!-- page 53 -->

Annexure -1 Draft Service Level Agreements (SLAs)
Service Level Agreement (hereinafter referred to as SLA) is to clearly define
the levels of service which shall be provided by the Service Provider to MOT
for the duration of this contract.
Benefits of
this SLA

Trigger a process that draws the MOT and the Service
Provider management attention to some aspect of performance
when that aspect drops below an agreed upon threshold, or
target. Makes explicit the expectations that MOT has for
performance. Helps MOT control the levels and performance
of
Service
Provider
services.
MOT and Service Provider shall maintain a weekly/monthly
contact to monitor the performance of the services being p
provided by the Service Provider and the effectiveness of this
SLA.
This SLA document provides for minimum level of services
required as per contractual obligations based on performance
indicators and measurements thereof. The Service Provider
shall ensure provisioning of all required services while
monitoring the performance of the same to effectively
comply
with
the
performance
levels.
The services provided by the Service Provider shall be
reviewed by the MOT and MOT shall:
a. Check performance of the Service Provider against these
SLAs over the review period and consider any key
issues of the past period’s performance statistics
including major incidents, service trends, etc.
b. Discuss escalated problems, new issues and matters still
outstanding
for
resolution.
c. Review of
outstanding

statistics
faults

related
and

to rectification of
agreed
changes.

d. Provide suggestions for changes to improve the service
levels. In case desired, MOT may initiate an interim
review to check the performance and the obligations of
53

<!-- page 54 -->

the Service Provider. The SLA may be reviewed and
revised in accordance to the procedures detailed under
SLA Change Control. SLA Change Control procedures
will be used if there is a dispute between UIDAI and the
Service Provider on what the performance targets should
be set.
It is acknowledged that this SLA may change as MoTs needs
evolve over the course of the contract period. This document
also defines the following management procedures:
a. A process for negotiating changes to the SLA.
b. An issue management process for documenting and
resolving difficult issues.
c. MoT and Service Provider management escalation
process to be used as in RFP document in the event that
an issue is not being resolved in a timely manner by the
d. lowest possible level of management. If there is any
confusion or conflict between this document and the
e. Contract, the Tender and its addenda, the Contract will
prevail.
The parties may amend this SLA by mutual agreement in
accordance with terms of this contract. Changes can be
proposed by either party. The Service Provider can initiate an
SLA review with the MoT. Normally, the forum for
negotiating SLA changes will be MoT’s monthly meetings.
Unresolved issues will be addressed using the issue
management process. The Service Provider shall maintain and
distribute current copies of the SLA document as directed by
MoT. Additional copies of the current SLA will be made
available at all times to authorized parties.
This process provides an appropriate management structure for
the orderly consideration and resolution of business and
operational issues in the event that quick consensus is not
reached between Purchaser and Service Provider. It is
expected that this pre-defined process will only be used on an
exception basis if issues are not resolved at lower management
levels.
a. Either MoT or Service Provider may raise an issue by
documenting the business or technical problem, which
presents a reasonably objective summary of both points
of view and identifies specific points of disagreement
with
possible
solutions.
54

<!-- page 55 -->

b. Purchaser and the Service Providers representative will
determine which committee or executive level should
logically
be
involved
in
resolution.
c. A meeting or conference call will be conducted to
resolve the issue in a timely manner. The documented
issues will be distributed to the participants at least 24
hours prior to the discussion, if the issue is not an
emergency
requiring
immediate
attention.
d. Management of Purchaser and Service Provider will
develop a temporary, if needed, and the permanent
solution for the problem at hand. The Service Provider
will then communicate the resolution to all interested
parties. In the event a significant business issue is still
unresolved, the arbitration procedure described in the
Contract will be used.
The parameters noted below in the Service Level Agreement
will start to be applicable after the completion of 90 days from
the start of commencement of work or after the reach of steady
state,
whichever
is
earlier.
MoT reserves the right to re-visit SLAs at a later date based on
learning from past experience and stabilization of operations.
The SLA parameters are provided in the table below

SLAs

Definition

Calculation Formula

Data Source

Average
Call This is the average ACD out put
CMS Report
Response Time/ time
taken
by It is the number of
Average Speed callers waiting in a Calls waiting to be
of Answer
queue
to
be picked
within
the
attended by an Threshold.
agent
Total Delay/ Total
Calls Received by
Agent
First Call
*First
contact
SR Dump.
Resolution Rate completion applies (1- Repeat %)
when
the
first
55

<!-- page 56 -->

person,
the Repeat is calculated as
customer
reaches follows
answers
the
question, resolves - (Unique QRC/Total
the problem or calls Answered)
dispatches service Repeat to be Calculated
where appropriate. on
only
Request,
Warm transfers and Queries
and
call backs should be Complaints after TAT
considered second
or greater contact.
Average Call
This is the average Sum( talk time +Hold CMS Report
Handling Time amount of time Time +Wrap time
during which agents )/Total Calls Answered
work with callers,
including actual talk
time, hold time and
after call work /
wrap up time
Abandoned Call This
is
the (Calls Offered – calls CMS Report
Rate
percentage of calls Answered)/
Calls
abandoned by a Offered
caller when a caller
is in agent queue
The values of the above SLA will be baseline with the successful bidder in
initial 180 days of go live of TIL.

56

<!-- page 57 -->

Annexure 2 : Declaration of ineligibility for corrupt or fraudulent
practices
To be provided on ‘Company Letterhead’
The Assistant Director General (Travel Trade),
Ministry of Tourism, Govt. of India
Transport Bhawan,
1, Parliament Street,
New Delhi
Subject: Declaration of ineligibility for corrupt or fraudulent practices.
Madam / Sir,
This is with reference to the Ministry of Tourism’s RFP no. TT/38/2020 dated
………… for Setting up of an integrated system for providing information to
tourist through Tourist Info Line (TIL) / helpline, tourist information centre at
selected 09 Airports, interacting with tourist with Chat Bots linked to
Incredible India official website and handling tourist complaints under
CPGRAM portal for Ministry of Tourism.
In this context, I, as an authorized representative(s) of company, declare that
presently our Company is not declared ineligible / blacklisted for corrupt &
fraudulent practices, by any State/ Central government/ PSU.
If this declaration is found to be incorrect, then without prejudice to any other
action that may be taken, our security may be forfeited in full and the tender if
any to the extent accepted may be cancelled.
Thanking you,
Name of the Bidder: …...............................
Authorised Signatory: …..............................
Name:
Seal:
Date:
Place:

57

<!-- page 58 -->

Annexure 3: Format to share Pre-Bid Queries
Contact Details of the Organization / Authorized Representative submitting
Pre-Bid Query Request
Name:
Address:
Name and Position of Person
submitting request:
Telephone/Mobile Number:
Email ID:
Fax:
Pre-Bid Queries
RFP
RFP
RFP Section/
Content of the RFP
Sr.
Section/
Query or point of
Page Subrequiring
No.
Sub-section
clarification required
No. section
clarification
Title
No.
1.
2.
3.
4.
5.

58

<!-- page 59 -->

Annexure - 4: Content and Format of Technical BID
TABLE 2
TECHNICAL EVALUATION CRITERIA
S.No Criteria
.

Weigh Sub- Documents Required and
t
weight Marking Criteria
-age -age
(Max) (Max)/
35

1

Company Profile

1.1

Turnover from
BPO business

15

1.2

Regional Language
capabilities

5

1.3

59

Number of BPO seats

10

CA Certificate certifying the
turnover from BPO Business
of latest FY year.
(a)5 marks for fulfilling
minimum
Requirement of Rs. 10 Crore
per annum.
(b) 10 marks for turnover/FY
more than 10 Crore but not more
than 15 crores.
(c) 15 marks for the turnover/FY
more than 15 crores
Matriculation certificate.
Additional two marks
foreach Regional language other
than Hindi.(As mentioned in
eighth schedule of Indian
constitution)
Work order issued by
the clients with in the latest
two(2) Financial year.
(a) Less than 400 SeatsZero
marks.
(b) 5 marks for more than 400
seats but less than 600 seats.
(c) 10 marks for more than
600 seats

<!-- page 60 -->

1.4

Size of single largest
customer supported
(Depending up on the
project value in INR)
Existing
Spare capacity in
terms of BPO Seats
Qualification, Experien 10
ce of Key
Personnel, HR Process
Average qualification
&experience of agents
proposed, span of
control, attrition etc.

3

Certificate from the client
verifying the claim

2

Self-Certification

2

Details manpower dashboard
for last one year

2

2.4

Proposed Project
Management &
Governance structure
Senior& dedicated
members assigned for
the proposed project
Recruitment Process

2.5

Training

3

1.5

2

2.1

2.2

2.3

(Graduation would be taken as an
average )
Detailed proposal

1

Proposed Project/Account Manag
er

2

Dedicated hiring team and brief
details of past hiring experience
Training methodology,
trainers, trainingareas, content
and training infrastructure

(b) Manpower/FTEs with multi lingual communication skill out of 10 foreign
languages as mentioned at para 3.1 (iv) besides English and official language
Hindi.
S.No. Criteria

3

60

Weight Sub-weight-age
age
(Max) (Max)/

Manpower/FTEs 10
with multi lingual
communication
skill besides
Hindi and English
language

Documents Required and
Marking Criteria

<!-- page 61 -->

3.1

(a) More than 4
and up to 10 FTEs
with multi lingual
communication
skill

5 marks

At least 6 months Diploma
Certificate issued by any
recognised/registered
institute in each language
for the employees claimed
for multilingual skill in
foreign language .

3.2

(b) More than
10 andupto 15
FTEs with multi
lingual
communication
skill - 8 marks

8 marks

3.3

(c) More than 15
manpower

10 marks

At least 6 months Diploma
Certificate issued by any
recognised/registered
institute in each language
for the each employee
claimed
for
multilingual skill in foreign
language
At least 6 months Diploma
Certificate issued by any
recognised/registered
institute in each language
for the each employee
claimed
for
multilingual skill in foreign
language

(c). Basis on Technical Presentation made before the Committee
S.No Criteria
.
4

4.1

4.2

61

Methodology, Work
plan & Understanding
of the Requirements
Robustness of Impleme
ntation Plan
Work Force
Management

Weight Sub-weight-age Documents Required
-age
(Max)
(Max)
25

10 Level of detail, risk
mitigation, practicality ,number
of locations
5 Plan for ramp-up/ /maintaining
multi-lingual proficiency.

<!-- page 62 -->

4.3

Physical infrastructure

3

4.4

Redundancy and
scalability

2

4.5

SLA commitments
offered and additional
KPIs monitored
Case Studies

5

5
5.1
5.2

5.3

Adequacy in terms of suitability
of location, physical and
data security, power back up,
environmental protection telecom
infrastructure.
Successful projects detailing the
retention and scalability
as and when required
Service level parameters
and details of KPIs monitored

20

Similar Multi-channel
projects
Ability to ramp-up of
resources in short timeCase Study
BCP/DR capability
(Technology and Plan)
Total weightage
100

5 Case Study
8 Case Study

7 Case Study
10
0

Note:
Supporting Documents are required to be submitted in accordance with the
Technical Evaluation Criteria above.
Two properly marked CDs containing the information,
Technical Evaluation parameters are required to be submitted.

as per the

The Ministry of Tourism (MoT) reserves the right to visit any or all of the
short-listed bidders for a physical verification of stated capacities and
capabilities.
Discrepancy
between
stated capacity/capabilities and
site verification shall be reviewed by the committee while taking any final
decision about evaluation of Technical Bid.in immediate disqualification.

62

<!-- page 63 -->

Annexure -5: Content and Format of Financial Bid
FORMAT FOR FINANCIAL BID:
Commercial Format
This is the
commercial
proposal for the Response to
RFP issued
by MoT for Setting up of an integrated system for providing information to
tourist through Tourist Info Line (TIL) / helpline, tourist information centre at
selected 010 Airports, interacting with tourist with Chat Bots linked to
Incredible India official website and handling tourist complaints under
CPGRAM portal in the Ministry of Tourism. These costs indicated below are
final and we, the Respondent, agree to provide the required services as detailed
in the MoT’s Request for Proposal (RFP) issued on _____________ by MoT.
The call centre services will be governed by the Service Level Agreement to
be entered into the MoT with us, which will encompass the services mentioned
in the above referred Request for Proposal.
Cost (Base Payment Rate) per FTE per shift per month and FTE per shift

No.

Description

A

1

Cost per FTE per shift

A

2

Cost per FTE per shift per month
(For thefirstyear)

Costs (INR)

Terms & Conditions:
1. The above quotations are in compliance to pricing terms as mentioned
in the RFP document. It is clarified that all taxes, excluding GST, are
included in the cost shown under the said Financial Proposal. All
applicable taxes at actual will be paid by MoT separately. Any TDS
deductible,as
per the Income Tax Regulations, will
be
deducted from amounts
payable to the vendor.
2. FTE is defined as 182 login hours per month. All the cost of other
support resources, technology, set-up, etc will need to be incorporated
in
the
FTE
cost.

63

<!-- page 64 -->

3. Vendors have to quote only for the first year of operations. This quote
will be known as 'Base Payment Rate'(BPR). This BPR will be
escalated for in the subsequent years as under
Period
Year1
Year2
Year3
Beyond 3 years,i.e., during the period of
extension, if any

Escalation
BPR
BPR+ 5%
BPR+ 10%
To be decided by MoT but will be
at least at the level of Year 3

4. Forecasting methodology – Vendor & MOT shall mutually discuss and
agree the forecasting process which shall provide for lock in period
along with minimum 95% of locked forecast.
5. Payment terms are Net 30 Calendar days from the date of receipt of
invoice
6. Pricing provided includes technology cost as provided in the RFP.
7. The pricing provided do not include the telecom/ connectivity /
bandwidth /SMS costs (if any) which would be reimbursed by MOT at
actuals.
8. The above quoted costs are valid for at least 180 days from the date of
closure.
Yours faithfully,
Authorised Signatory

Name

Designation: Company’s stamp/seal

64

Date:

<!-- page 65 -->

Annexure 5A: FINANCIAL BID COVERING LETTER
(To be submitted on the Letter head of the applicant)
To,
(Address)
Ref: Request for Proposal (NIT) Notification No. ………… dated_____
Dear Sir/Madam,
1. Having examined the RFP document, we, the undersigned, herewith submit
our response to your RFP Notified vide F. No. …….dated ____ for Setting up
of an integrated system for providing information to tourist through Tourist
Info Line (TIL) / helpline, tourist information centre at selected 09 Airports,
interacting with tourist with Chat Bots linked to Incredible India official
website and handling tourist complaints under CPGRAM portal in the
Ministry of Tourism., in full conformity with the said RFP document.
2. We, the undersigned, offer to provide services to AGENCY for providing
the PRI Line services for the TIL Project in accordance with your RFP.
3. We have read the provisions of the RFP document and confirm that these
are acceptable to us. Hence, we are hereby submitting our Financial Bid.
4. We agree to abide by this RFP consisting of this letter, financial bid and all
requisite supporting documents, for a period of 90 days from the closing date
fixed for submission of bid as stipulated in the RFP document.
5. We agree that the price quoted by us will remain fixed for entire period and
firm and any discounting observed in the rates will be passed on to customer
in due course of the project.
6. We agree that in case of revision of statutory taxes and duties the invoicing
will be done as per the prevailing rates as notified by GoI.
7. We would like to declare that we are not involved in any litigation with any
Government entity in India and we are not under a declaration of ineligibility
for corrupt or fraudulent practices.

65

<!-- page 66 -->

8. We hereby declare that we have not been blacklisted by any Central / State /
UT Government or Government entity.
9. We hereby declare that we have not been charged with any fraudulent
activities by any Central/ State/ UT Government or Government entity.
10. We hereby certify that we have taken steps to ensure that no person acting
for us or on our behalf will engage in bribery.
11. We understand that the MoT is not bound to accept any bid received in
response to this RFP.
12. In case we are engaged as a Service Provider, we agree to abide by all the
terms & conditions of the Contract that will be issued by the AGENCY.
13. We already have the technical and financial capability in India for
carrying out the services as detailed in the „Scope of work and SLAs‟.
14. Our correspondence details with regard to this RFP are:
S.No.

Information

1.

Name of the Contact Person

2.

Address of the Contact Person

3.

Name, designation and contact address of
the person to whom all references shall be
made regarding this NIT

4.

Telephone number of the Contact Person

5.

Mobile number of the Contact Person

6

Fax number of the Contact Person

7.

Email ID of the Contact Person

8.

Corporate website URL

66

Details

<!-- page 67 -->

15. We also understand that in case of deficiencies in the declaration
submitted through this letter or deficiencies in our services as per the
requirement of RFP, AGENCY reserves the right to terminate the services or
take necessary action as per the provisions of the NIT.
We remain,
Yours sincerely,
Authorized Signature [In full as well as initials]:________________________
Name and Title of Signatory:______________________________________
"Bid Security Declaration" accepting that if they withdraw or modify their
bids during period of validity etc., they will be suspended for the time
specified in the tender documents.

67

<!-- page 68 -->

Annexure 6
Bid Security Declaration Form
Date:___________________
No._____________
To,
The Assistant Director General (TT)
Ministry of Tourism, Government of India
1st Floor ,TransportBhawan
Parliament Street
New Delhi

Tender

I/We. The undersigned, declare that:
I/We understand that, according to your conditions, bids must be supported by
a Bid Securing Declaration.
I/We accept that I/We may be disqualified from bidding for any contract with
you for a period of one year from the date of notification if I am /We are in a
breach of any obligation under the bid conditions, because I/We
a) have withdrawn/modified/amended, impairs or derogates from the tender,
my/our Bid during the period of bid validity specified in the form of Bid; or
b) having been notified of the acceptance of our Bid by the purchaser during
the period of bid validity (i) fail or reuse to execute the contract, if required, or
(ii) fail or refuse to furnish the Performance Security, in accordance with the
Instructions to Bidders.
I/We understand this Bid Securing Declaration shall cease to be valid if I
am/we are not the successful Bidder, upon the earlier of (i) the receipt of your
notification of the name of the successful Bidder; or (ii) thirty days after the
expiration of the validity of my/our Bid.
Signed: (insert signature of person whose name and capacity are shown)
in the capacity of (insert legal capacity of person signing the Bid Securing
Declaration)
Name: (insert complete name of person signing he Bid Securing Declaration)
Duly authorized to sign the bid for an on behalf of (insert complete name of
Bidder)
Dated on _____________ day of ___________________ (insert date of
signing)
Corporate Seal (where appropriate)
Name of Firm:_________________________________________________
Address______________________________________________________
68

<!-- page 69 -->

Annexure 7: Format of Performance Bank Guarantee
PERFORMANCE SECURITY:
<Name>
<Designation>
<Address>
<Phone Nos.>
<Fax Nos.>
<Email id>
Whereas, <name of the supplier and address> (hereinafter called “the bidder”)
has undertaken, in pursuance of contract no. <Insert Contract No.> dated.
<Date> for Setting up of an integrated system for providing information to
tourist through Tourist Info Line (TIL) / helpline, tourist information centre at
selected 009 Airports, interacting with tourist with Chat Bots linked to
Incredible India official website and handling tourist complaints under
CPGRAM portal in the Ministry of Tourism. (hereinafter called “the
beneficiary”)
And whereas it has been stipulated by in the said contract that the bidder shall
furnish you with a bank guarantee by a recognized bank for the sum specified
therein as security for compliance with its obligations in accordance with the
contract;
And whereas we, <Name of Bank> a banking company incorporated and
having its head/registered office at <Address of Registered Office> and
having one of its office at <Address of Local Office> have agreed to give the
supplier such a bank guarantee.
Now, therefore, we hereby affirm that we are guarantors and responsible to
you, on behalf of the supplier, up to a total of Rs.<Insert Value> (Rupees
<Insert Value in Words> only)as 3 % of contract valueand we undertake to
pay you, upon your first written demand declaring the supplier to be in default
under the contract and without cavil or argument, any sum or sums within the
limits of Rs. <Insert Value> (Rupees <Insert Value in Words> only) as
aforesaid, without your needing to prove or to show grounds or reasons for
your demand or the sum specified therein.
We hereby waive the necessity of your demanding the said debt from the
bidder before presenting us with the demand.
69

<!-- page 70 -->

We further agree that no change or addition to or other modification of the
terms of the contract to be performed there under or of any of the contract
documents which may be made between you and the Bidder shall in any way
release us from any liability under this guarantee and we hereby waive notice
of any such change, addition or modification.
This Guarantee shall be valid until <Insert Date>)
Notwithstanding anything contained herein:
Our liability under this bank guarantee shall not exceed Rs. <Insert Value>
(Rupees <Insert Value in Words> only).
This bank guarantee shall be valid up to <Insert Expiry Date>)
It is condition of our liability for payment of the guaranteed amount or any
part thereof arising under this bank guarantee that we receive a valid written
claim or demand for payment under this bank guarantee on or before <Insert
Expiry Date>) failing which our liability under the guarantee will
automatically cease.

70

<!-- page 71 -->

Annexure 8: Format for Past experiences
Assignment Name

Name of primary bidder

Name of Client

Location

Address

Duration

Start Date and End Date

Contract Value (in INR)

Description of Project
Description of services provided

***********

71
