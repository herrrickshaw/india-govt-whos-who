---
doc_id: "dc2ef6f414fbf2ad"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/2e1918d268fbc44473b526d4f88875a3.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allocation of Location Routing Number LRN to Ms RingCentral India Private Limited for Rajasthan LSA"
date: "2025-04-25"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a14aa55f9fb45e74"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
(Access Services Wing)
No. 16-07/2024-AS-III/ #5 Dated:25.04.2025
To,
M/s RingCentral India Private Ltd., .
05-163, WeWork, DLF Forum,
Cyber City, DLF Phase-lll,
Gurugram, Haryana-122002.
Subject: - Allocation of Location Routing Number (LRN) to M/s RingCentral
India Private Limited for Rajasthan LSA.
Considering the request of M/s RingCentral India Pvi. Ltd. for allotment of
LRN Codes, it has been decided to allot the following LRN Codes:
Name of LSA |Allotted LRN Code
RingCeniral India Private Limited Rajasthan 3029
2. These LRN codes are allocated on the condition that this code will be
reverted back to the Licensor automatically after 6 months from the date of
issuance of this letter if not utilized.
3. This is issued with the approval of DDG (AS). Digitally signed by
Vaibhav Jain
Date: 25-04-2025
18:26:36
Director (AS-III)
Ph. No. 011-23372488
Copy for kind information and necessary action, if any, to:
1. Secretary, TRAI
2. Director (T), DGT HQ, DoT with request to convey the allocation to related
LSA field unit.
3. All Access Service Providers.
4. All MNP Service Providers
5. A copy for upload on DoT website.
