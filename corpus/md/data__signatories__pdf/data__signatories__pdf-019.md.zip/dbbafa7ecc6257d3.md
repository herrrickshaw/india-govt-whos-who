---
doc_id: "dbbafa7ecc6257d3"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/0137fb3bc75ae39dc58bd9b78055ab0b.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Corrigendum - I"
date: "2025-07-01"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b02796ca2fa67fa8"
---

<!-- page 1 -->

F.No. 5(14)/2015-BE-III
F.No.
5(14)/2015-BE-III
Govt. of
of India
India
Govt.
Ministry
Industry
Ministry of
of Commerce
Commerce and
and Industry
Department
Policy and
Department of
of Industrial
Industrial Policy
and Promotion
Promotion
Udyog
New Delhi
Udyog Bhawan,
Bhawan, New
Delhi
Dated
Dated 55th June,
June, 2015
2015
CORRIGENDUM
CORRIGENDUM
Subject:
Subject: Request
Request for
for Qualification-cum-Request
Qualification-cum-Request for
for Proposal
Proposal for
for appointment
appointment of
of Creative
Creative

Agency
initiative.
Agency for
for DIPP
DIPP to
to carry
carry out
out the
the assignments
assignments related
related to
to Make
Make in
in India
India initiative.
In
In the
the Request
Request for
for Qualification-cum-Request
Qualification-cum-Request for
for Proposal
Proposal for
for appointment
appointment of
of
Creative
revised:
Creative Agency
Agency for
for DIPP,
DIPP, the
the following
following stands
stands revised:
1)
1)

2.7.2 The
would have
2.7.2
The Successful
Successful Applicant
Applicant would
have to
to provide
provide aa Quarterly
Quarterly Work
Work Plan
Plan for
for

the
days after
after receipt
receipt of
of the
the Work
Work Order.
Order.
the first
first year
year to
to the
the DIPP,
DIPP, within
within 77 days
May
be read
May be
read as:
as:
2.7.2
2.7.2

The
provide aa Quarterly
for
Quarterly Work
Work Plan
Plan for
The Successful
Successful Applicant
Applicant would
would have
have to
to provide

the
the first
first year
year to
to the
the DIPP,
DIPP, within
within 10
10 days
days after
after receipt
receipt of
of the
the Work
Work Order.
Order.
2)
2)

Point
production items
attached with
4B at
page
C -- Turnkey
Turnkey production
items attached
with Form
Form 4B
at page
under Para
Para C
Point 55 under

46
be read
46 may
may be
read as:
as:
Radio
use (per
International use
(per Foreign
Foreign language
language adapt)
adapt) (60
(60 sec
sec with
with all
all its
its
Radio spot
spot -- International
time
time adaptation)
adaptation)

Deputy Secretary
Secretary (BE-III)
(BE-III)
Deputy
