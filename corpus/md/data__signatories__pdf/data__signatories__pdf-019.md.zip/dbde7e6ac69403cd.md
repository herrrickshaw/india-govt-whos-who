---
doc_id: "dbde7e6ac69403cd"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/79aa8b7be45e7e890c223455c3b15041.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Corrigendum of Notice For Invitation of Expression of Interest."
date: "2025-07-11"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ee11a9b92e19fecf"
---

<!-- page 1 -->

No. 11002-2/2023-DMS
Government of India
Delhi Milk Scheme
West Patel Nagar
New Delhi-08

Dated the 06" May, 2024

CORRIGENDUM
A notification of Eol Tender No. 11002-2/2023-PD&CC was published by DMS on
23.4.2024 through e-Procurement System of Government of India, for inviting Expression of
Interest (Eol) from State Dairy Federation(SDFs)/ Mother Dairy and/or Milk Producer
Companies and Milk Unions of SDFs (like Amul, Mother Dairy, Verka, Sudha, Sanchi etc.)
seeking quotation/rate for leasing out of partial shelf space in DMS milk booths (about 400 plus
in numbers) and collaborating with the selected parties to support milk and milk products

retailing outlet services in respect of various milk and milk products.

In partial modification to the above notification, the Para 3 of the “INVITATION OF
EXPRESSION OF INTEREST” providing the Critical dates for bid/Eol submission, may be
read as under:-

S.No | Table of critical events Indicative | Indicative
a, a ० | गोशा॥]6 Date
(i) Date of publication of Eol To 23.4.2024
Date of publication of minutes of meeting
of pre-bid conference/amended Eol
(iii) Date of submission of Technical proposals
(End date)
: General Manager
Delhi Milk Scheme
