---
doc_id: "d9857a36bcffcf0a"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/3e4ecc6ca43d4a843880d32fb79a3788.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Appointment of Consulting Agency for Startups for DPIIT, Request for Proposal"
date: "2025-07-01"
pages: 48
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ac906930fce8b12e"
---

<!-- page 1 -->

F. No. P 38015(19)/2019-STARTUP INDIA
DEPARTMENT FOR PROMOTION OF INDUSTRY AND INTERNAL TRADE
Ministry of Commerce and Industry, Government of India

APPOINTMENT OF CONSULTING AGENCY
FOR
STARTUPS
FOR
DEPARTMENT FOR PROMOTION OF INDUSTRY AND INTERNAL TRADE

REQUEST FOR PROPOSAL

March 2020

NOTICE INVITING - REQUEST FOR PROPOSAL

1

<!-- page 2 -->

DEPARTMENT FOR PROMOTION OF INDUSTRY AND INTERNAL TRADE

REQUEST FOR PROPOSAL (RfP) FOR SELECTION OF CONSULTING AGENCY FOR STARTUP
INDIA INITIATIVE

Startup India initiative is intended to build a strong eco-system for nurturing innovation and Startups in the
country. The revolution started in August 2015 with Hon'ble Prime Minister announcing Government's
commitment to promoting Startups. The Department for Promotion of Industry and Internal Trade (DPIIT)
has been entrusted with implementation of the Startup India Program. In order to achieve the objectives of
the program, DPIIT formulated the Startup India Action Plan with support from Project Monitoring Unit
(PMU). The action plan was launched on 16th January, 2016 with several Ministries and Departments
collaborating to achieve designated goals under various action points.
The program has achieved significant milestones in last four years and is on progress to realise the targets
envisaged in the Startup India action plan. The Government of India has undertaken series of reforms to
make India a conducive place for Startups. The focus has been to create awareness about
entrepreneurship, improve regulatory regime for Startups, to develop infrastructure required by young
innovator, provide funding avenues for Startups, and to strengthen collaboration between Central and State
Governments to support new businesses. There is a growing need to do a lot more to achieve the vision of
becoming the leading Startup nation.
There are major requirements to transform the Startup landscape and to scale up the Startup India
initiative. The related Ministries/ Departments need to achieve their targets under the action plan and build
on their capacity to support growing number of Startups. The Department for Promotion of Industry and
Internal Trade being the nodal department for the Startup India initiative is expected to play a proactive role
and provide insights to Central Government Department and State Governments to ensure effective
implementation of action plan .
In this regard, DPIIT intends to on-board a consultancy, for a period of three years extendable one year at a
time (for a total duration of 5 years), to assist and support the department in effective and on ground
implementation of Startup India Action plan. The agency will also support the Department in scaling up the
Startup India initiative through manifold interventions considered important for building a strong Startup
ecosystem.
The salient features of the project, eligibility criteria and prescribed formats for submission can be accessed
in the RfP document uploaded on the website: http://eprocure.gov.in and http://dipp.nic.in
Interested applicants are requested to submit their responses to the "RFP" on Central Public
th
Procurement Portal (http://eprocure.gov.in) on or before 14 April 2020 at 03:00 PM.

The submissions must be addressed to:
Director (Startup India Section), email- sis-dipp@nic.in
Department for Promotion of Industry and Internal Trade
Ministry of Commerce & Industry, Government of India
Udyog Bhawan
New Delhi-110011

2

<!-- page 3 -->

Disclaimer

1. This RfP document is neither an agreement nor an offer by Department for Promotion of Industry
and Internal Trade, Ministry of Commerce and Industry, Government of India (hereinafter referred
to as DPIIT) to the prospective Applicants or any other person. The purpose of this RfP is to
provide information to the interested parties that may be useful to them in the formulation of their
proposal pursuant to this RfP.
2. DPIIT does not make any representation or warranty as to the accuracy, reliability or completeness
of the information in this RfP document and it is not possible for DPIIT to consider particular needs
of each party who reads or uses this document. RfP includes statements which reflect various
assumptions and assessments arrived at by DPIIT in relation to the statement of work. Such
assumptions, assessments and statements do not purport to contain all the information that each
Applicant may require. Each prospective Applicant should conduct its own investigations and
analyses and check the accuracy, reliability and completeness of the information provided in this
RfP document and obtain independent advice from appropriate sources.
3. DPIIT will not have any liability to any prospective Applicant/ Firm/ or any other person under any
laws (including without limitation the law of contract, tort), the principles of equity, restitution or
unjust enrichment or otherwise for any loss, expense or damage which may arise from or be
incurred or suffered in connection with anything contained in this RfP document, any matter
deemed to form part of this Rf P document, the award of the Assignment, the information and any
other information supplied by or on behalf of DPIIT or their employees, any Consulting Agency or
otherwise arising in any way from the selection process for the Assignment. DPIIT will also not be
liable in any manner whether resulting from negligence or otherwise however caused arising from
reliance of any Applicant upon any statements contained in this RfP.
4. DPIIT will not be responsible for any delay in receiving the proposals. The issue of this RfP does
not imply that DPIIT is bound to select an Applicant or to appoint the Selected Applicant, as the
case may be, for the services and DPIIT reserves the right to accept/reject any or all of proposals
submitted in response to RfP document at any stage without assigning any reasons whatsoever.
DPIIT also reserves the right to withhold or withdraw the process at any stage with intimation to all
who submitted RfP Application.
5. The information given is not exhaustive on account of statutory requirements and should not be
regarded as complete or authoritative statement of law. DPIIT accepts no responsibility for the
accuracy or otherwise for any interpretation or opinion on the law expressed herein.
6. DPIIT reserves the right to change/ modify/ amend/ cancel any or all provisions of this RfP
document. Such revisions to the RfP / amended RfP will be made available on the website of DPIIT
and CPPP portal.

3

<!-- page 4 -->

Section 1. Letter of Invitation
New Delhi
th

Date: 16 March 2020
1. Introduction

Government of India launched the 'Start-up India' initiative to create a strong eco-system for
fostering innovation and start-ups in the country. The program has completed three years and achieved
significant milestones under the envisaged Startup India action plan . The Government has also gone
beyond the mandate of the action plan and undertaken major reforms.
There is a growing need to do a lot more to achieve the vision of becoming the leading Startup
nation. There are major requirements to scale up the Startup India initiative. The related Ministries/
Departments need to achieve their targets under the action plan and build on their capacity to support
growing number of Startups. The Department for Promotion of Industry and Internal Trade being the nodal
department for the Startup India initiative is expected to play a proactive role and provide insights to Central
Government Department and State Governments to ensure effective implementation of action plan .
The Department proposes to engage a consultancy organisation to provide support to the
Department for Promotion of Industry and Internal Trade for a period of three years, extendable one year at
a time for a total duration of 5 years, to assist and support the department in effective and on ground
implementation of Startup India Action plan. The agency will also support the Department in scaling up the
Startup India initiative through manifold interventions considered important for building a strong Startup
ecosystem .

ro

Objectives

'

The main objective of the assignment is to:

1. Assist DPIIT in effective and on ground implementation of Startup India action plan;
2 . Handhold, supervise and monitor implementation of recommendations for next three years,
extendable one year at a time for a total duration of 5 years;
3. Examine the needs of current Startup ecosystem and provide short, medium and long term
recommendations for implementation by various agencies in consultation with various stakeholders
to scale up the Startup India initiative; and
4. Undertake the State Startup ranking exercise in every year by coordinating with States and other
relevant ecosystem stakeholders.

4

<!-- page 5 -->

3.0 A Consulting Agency will be selected as per Quality cum Cost Based Selection (QCBS)
process.
The RfP includes the following documents:
SECTION 1: Letter of Invitation
SECTION 2: Instructions to Applicants
SECTION 3: Pre - Qualification and Technical Proposal - Standard Forms
SECTION 4: Financial Proposal - Standard forms
SECTION 5: Terms of Reference
SECTION 6: Standard format of Work Order

All clarifications/ corrigenda will be published only on the website of DPIIT. The official website for
accessing the information related to RfP is: www.dipp.gov.in (the "Official Website") along with
Central Public Procurement Portal (eprocure.gov.in/eprocure/app).

Yours sincerely,

Director (Startup India)
DPIIT

s

<!-- page 6 -->

Section 2. Instructions to Applicants
2.1
Introduction
2.1.1 The Client named in the Data Sheet will select an organization in accordance with the
method of selection specified in the Data Sheet. Applicants are advised that the selection of
Consulting Agency shall be on the basis of an evaluation by Client through the selection process
specified in this RfP (the -Selection Process). Applicants shall be deemed to have understood
and agreed that no explanation or justification for any aspect of the Selection Process will be
given and that Client's decisions are final without any right of appeal whatsoever.
2.1.2 The Applicants are invited to submit Technical and Financial Proposals (collectively
called as -the Proposal), as specified in the Data Sheet, for the services required for the
Assignment. The Proposal will form the basis for grant of work order to the selected Consulting
Agency. The Consulting Agency shall carry out the assignment in accordance with the Terms of
Reference of RfP (the - TOR).
2.1.3 The Applicant shall submit the Proposal in the form and manner specified in this RfP. The
Proposal shall be submitted as per the forms given in relevant sections herewith.
2.1.4 Applicants shall bear all costs associated with the preparation and submission of their
proposals, and their participation in the Selection process, and presentation including but not
limited to postage, delivery fees, expenses associated with any demonstrations or presentations
which may be required by Client or any other costs incurred in connection with or relating to its
Proposal. The Client is not bound to accept any Proposal, and reserves the right to annul the
selection process at any time prior to grant of work order, without thereby incurring any liability to
the Applicants.
2.1.5 Client requires that the Applicant hold Client's interest's paramount, avoid conflicts with
other assignments or its own interests, and act without any consideration for future work. The
applicant shall not accept or engage in any assignment that may place it in a position of not being
able to carry out the assignment in the best interests of Client and the Project.
2.1.6 It is the Client's policy to require that the Applicants observe the highest standard of ethics
during the Selection Process and execution of work/assignment. In pursuance of this policy, the
Client:
(i) will reject the Proposal for award if it determines that the Applicant has engaged in corrupt or
fraudulent activities in competing for the work order in question;
(ii) will declare an Applicant ineligible, either indefinitely or for a stated period of time, to be
awarded any contract or work order if it at any time determines that the Applicant has engaged in
corrupt or fraudulent practices in competing for and in executing the work order.
2.1. 7 Dispute Resolution: If any dispute or difference of any kind whatsoever arises between
the parties in connection with or arising out of or relating to or under this RfP, the parties shall
promptly and in good faith negotiate with a view to its amicable resolution and settlement. In the
event no amicable resolution or settlement is reached within a period of thirty (30) days from the
date on which the above-mentioned dispute or difference arose, such dispute or difference shall
be finally settled by Secretary, DPIIT, whose decision shall be final.

2.1.8 Termination of Assignment: Client will have the right to terminate the assignment by
giving 30 (thirty) days written notice. In the event of termination for no fault of Applicant, the
Client will reimburse all the expenses incurred by the Applicant (upon submission of proof)
including closing-up of the project. If the assignment is terminated due to the fault of the
Applicant or in case of termination of the assignment by the Applicant for reasons not attributable
to the Client, the Client will forfeit the performance security of the Applicant.
2.1.9 The Applicant shall submit his proposal in four covers containing details of EMD, PreQualification Proposal, Technical Proposal and Financial Proposal respectively.

6

<!-- page 7 -->

2.1.10 The evaluation will be done in accordance with procedure given in Clause 2.6.
2.1.11 Number of Proposals: No Applicant shall submit more than one Application .
2.1.12 Right to reject any or all Proposals:
(i) Notwithstanding anything contained in this RfP, the Client reserves the right to accept or reject
any Proposal and to annul the Selection Process and reject all Proposals, at any time without any
liability or any obligation for such acceptance, rejection or annulment, and without assigning any
reasons thereof.
(ii) Without prejudice to the generality of above, the Client reserves the right to reject any
Proposal if:
a) at any time, a material misrepresentation is made or discovered, or
b) the Applicant does not provide, within the time specified by the Client, the supplemental
information sought by the Client for evaluation of the Proposal.
(iii) Such misrepresentation/ improper response by the Applicant may lead to the disqualification
of the Applicant. If such disqualification/ rejection occurs after the Proposals have been opened
and the highest ranking Applicant gets disqualified/ rejected, then the Client reserves the right to
consider the next best Applicant, or take any other measure as may be deemed fit in the sole
discretion of the Client, including annulment of the Selection Process.
2.1.13 Acknowledgement by Applicant
(i) It shall be deemed that by submitting the Proposal, the Applicant has:
a) made a complete and careful examination of the RfP;
b) received all relevant information requested from the Client;
c) accepted the risk of inadequacy, error or mistake in the information provided in
the Rf P or furnished by or on behalf of the Client;
d) satisfied itself about all matters, things and information, including matters herein
above, necessary and required for submitting an informed Application and performance
of all of its obligations there under;
e) acknowledged that it does not have a Conflict of Interest; and
f) agreed to be bound by the undertaking provided by it under and in term hereof.
(ii) The Client and/ or its advisors shall not be liable for any omission, mistake or error on the part
of the Applicant in respect of any of the above or on account of any matter or thing arising out of or
concerning or relating to RfP or the Selection Process, including any error or mistake therein or in
any information or data given by the Client and/ or its consultant.
2.2

Clarification and amendment of RfP documents

Applicants may seek clarification on this Rf P document, within seven (7) days of the date of
issue of this RfP document. Any request for clarification must be sent by standard electronic
means (PDF and word file) to the Client's email addressed: sis-dipp@nic.in
The Client will endeavour to respond to the queries prior to the Proposal Due Date. The Client
will post the reply to all such queries on its official website and CPPP portal.
2.2.1 At any time before the submission of Proposals, the Client may, for any reason, whether
at its own initiative or in response to a clarification requested by a prospective Applicant, modify
the RfP documents by an amendment. Only the amendments/ corrigenda posted on the Client's
Official Website shall be valid. In order to afford the Applicants a reasonable time for taking an
amendment into account, the Client may at its discretion extend the Proposal Due Date.
2.2.2 Date of Pre-Bid Meeting and venue is mentioned in Data Sheet. Applicants willing to
attend the pre-bid should inform client beforehand in writing through email. The maximum no. of
participants from an applicant, who chose to attend the Pre-Bid Meeting, shall not be more than
two per applicant. The representatives attending the Pre-Bid Meeting shall accompany with an
authority letter duly signed by the authorized signatory of his/her organization.

7

<!-- page 8 -->

2.3

Earnest Money Deposit

2.3.1 A Earnest Money Deposit in the form of a Demand Draft/ Bank Guarantee, from a
scheduled Indian Bank in favour of Pay and Account Officer, DPIIT, New Delhi_, payable at
New Delhi, for the sum of Rs 20,00,000/- (Rupees Twenty Lakhs Only) shall be required to be
submitted by each Applicant. The Bank Guarantee shall be in the format of Form 3F.
2.3.2 The Demand Draft/ Bank Guarantee in original shall be placed in an envelope and marked
as -EMD- [name of assignment] and -Not to be opened except in the presence of evaluation
committee. This envelope shall be delivered to DPIIT in physical form before the Proposal
Due Date. In addition, a scanned copy (in pdf format) shall also be uploaded on CPPP. Bids
received without the specified Earnest Money Deposit Bid Security will be summarily rejected.
2.3.3 Client will not be liable to pay any interest on Earnest Money Deposit. Bid security of PreQualified but unsuccessful Applicants shall be returned, without any interest, within one month
after grant of the work order to the Selected Applicant or when the selection process is cancelled
by Client. The Selected Applicant's Earnest Money shall be returned, without any interest upon
the Applicant accepting the work order and furnishing the Performance in accordance with
provision of the RfP and work order.
2.3.4 Client will be entitled to forfeit and appropriate the Earnest Money Deposit as mutually
agreed loss and damage payable to Client in regard to the RfP without prejudice to client's any
other right or remedy under the following conditions:
(i) If an Applicant engages in a corrupt practice, fraudulent practice, coercive practice,
undesirable practice or restrictive practice as envisaged under this RfP (including the
Standard Form of work order);
(ii) If any Applicant withdraws its Proposal during the period of its validity as specified in this
RfP and as extended by the Applicant from time to time,
(iii) In the case of the Selected Applicant, if the Selected Applicant fails to accept the work
order or provide the Performance Security within the specified time limit, or
(iv) If the Applicant commits any breach of terms of this RfP or is found to have made a false
representation to Client.
Performance Security equivalent to the amount indicated in this RfP shall be furnished before
start of work on assignment in form of a Bank Guarantee substantially in the form specified in the
RfP/ work order.
For the successful bidder the Performance Security shall be retained by Client until the
completion of the assignment by the Applicant and be released 60 (Sixty) days after the
completion of the assignment.
2.3.5 Any entity which has been barred by the Central Government, any State Government, a
statutory authority or a public sector undertaking, as the case may be, from participating in any
project and the bar subsists as on the date of the Proposal Due Date, would not be eligible to
submit a Proposal.
2.3.6 An Applicant should have, during the last 3 (three) years, neither failed to perform on any
agreement, as evidenced by imposition of a penalty by an arbitral or judicial authority or a judicial
pronouncement or arbitration award against the Applicant or its Associate, nor been expelled from
any project or agreement nor have had any agreement terminated for breach by such Applicant or
its Associate.
2.4

Preparation of proposal

2.4.1 Applicants are requested to submit their Proposal in English language and strictly in the
formats provided in this RfP. The Client will evaluate only those Proposals that are received in the
specified forms and complete in all respects.
8

<!-- page 9 -->

2.4.2 In preparing their Proposal, Applicants are expected to thoroughly examine the RfP
Document.
2.4 .3 The technical proposal should provide the documents as prescribed in this RfP. No
information related to financial proposal should be provided in the technical proposal.
2.4.4 Failure to comply with the requirements spelt out above shall lead to the deduction of
marks during the evaluation . Further, in such a case, Client will be entitled to reject the Proposal.
However, if any information related to financial proposal is included in the technical proposal the
applicant shall be disqualified and his proposal will not be considered.
2.4.5

The Proposals must be digitally pre-signed by the Authorized Representative (the

-Authorized Representative) as detailed below:
(i) by the proprietor in case of a proprietary firm ;

(ii) by a partner, in case of a partnership firm and/or a limited liability partnership; or

(iii) by a duly authorized person holding the Power of Attorney, in case of a Limited Company
or a corporation ;
2.4.6 Applicants should note the Proposal Due Date, as specified in Data Sheet, for submission
of Proposals. Except as specifically provided in this RfP, no supplementary material will be
entertained by the Client, and the evaluation will be carried out only on the basis of Documents
received by the closing time of Proposal Due Date as specified in Data Sheet. Applicants will
ordinarily not be asked to provide additional material information or documents subsequent to the
date of submission, and unsolicited material if submitted will be summarily rejected . For the
avoidance of doubt, the Client reserves the right to seek clarifications in case the proposal is nonresponsive on any aspects.
2.4.7 Financial proposal: While preparing the Financial Proposal, Applicants are expected to
take into account the various requirements and conditions stipulated in this RfP document. The
Financial Proposal should be a lump sum Proposal inclusive of all the costs including but not
limited to all taxes (except service tax) associated with the Assignment. While submitting the
Financial Proposal, the Applicant shall ensure the following:
(i) All the costs associated with the Assignment shall be included in the Financial Proposal.
These shall normally cover remuneration for all the personnel (Expatriate and Resident, in
the field, office, etc.), local transportation at the location of deployment, equipment, printing
of documents, secondary and primary data collection , etc. The total amount indicated in the
Financial Proposal shall be without any condition attached or subject to any assumption, and
shall be final and binding. In case any assumption or condition is indicated in the Financial
Proposal , it shall be considered non-responsive and liable to be rejected .
(ii) The Agency will have to travel to different States/UTs at any given point of time. In such
cases, the transportation charges shall be borne by the client based on approved norms of
the department and in consultation with IF wing, DPIIT.
(iii) The Financial Proposal shall take into account all the expenses and tax liabilities and
cost of insurance specified in the work order, levies and other impositions applicable under
the prevailing law. For the avoidance of doubt, it is clarified that all taxes, excluding service
tax, shall be deemed to be included in the cost shown under different items of Financial
Proposal. The Applicant shall be paid only service tax over and above the cost of Financial
Proposal. Further, all payments shall be subjected to deduction of taxes at source as per
Applicable Laws.
2.4 .8 The proposal should be submitted as per the standard Financial Proposal submission forms
prescribed in this RfP.
2.4.9

Applicants shall express the price of their services in Indian Rupees only.
9

<!-- page 10 -->

2.5

Submission, receipt and opening of proposals

2.5.1 The Proposal shall be submitted through e-procurement portal CPPP. The procedure for
filing of e-tender is provided on the portal. Files uploaded on the portal should have file name in
accordance to following format [form_name.applicant_name] . Applicant name should contain only
first two words of its name. Proposal received in any other manner shall be summarily rejected.
2.5.2 The Authorized Representative of the Applicant should authenticate EMO Details, Prequalification, Technical and Financial proposal using digital signatures. The Authorized
Representative's authorization should be confirmed by a written power of attorney by the
competent authority accompanying the Proposal (Pre-Qualification Proposal) .
2.5.3 The Applicant shall submit his proposal in four covers containing details of EMD, PreQualification Proposal, Technical Proposal and Financial Proposal respectively, on eprocurement portal.
2.5.4

No proposal shall be accepted after the closing time for submission of Proposals.

2.5.4.1 After the deadline for submission of proposals the Pre-Qualification Proposal shall be
opened by the Evaluation Committee to evaluate whether the Applicants meet the prescribed
Minimum Qualification Criteria. The RfP , Technical and Financial Proposals shall remain sealed.
2.5.5 After the Proposal submission until the grant of the work order, if any Applicant wishes to
contact the Client on any matter related to its proposal, it should do so in writing at the Proposal
submission address. Any effort by the firm to influence the Client during the Proposal evaluation,
Proposal comparison or grant of the work order decisions may result in the rejection of the
applicant's proposal.
2.6

Proposal Evaluation

2.6.1
As part of the evaluation, the Pre-Qualification Proposal submitted (Form 3A - 3E) shall
be checked to evaluate whether the Applicant meets the prescribed Minimum Qualification
Criteria. Subsequently the Technical Proposal submission, for Applicants who meet the Minimum
Qualification Criteria (-Shortlisted Applicant), shall be checked for responsiveness in
accordance with the requirements of the RfP and only those Technical Proposals which are
found to be responsive would be further evaluated in accordance with the criteria set out in this
RfP document.
2.6.2
Prior to evaluation of Proposals, the Client will determine whether each Proposal is
responsive to the requirements of the RfP at each evaluation stage as indicated below. The
Client may, in its sole discretion, reject any Proposal that is not responsive hereunder. A
Proposal will be considered responsive at each stage only if the following requirements are met:
Pre-qualification
(i) The client will satisfy itself that the applicants meet the minimum qualifications prescribed before
evaluating technical and financial proposals.
Technical Proposal

i.

the Technical Proposal is received in the form specified in this RfP;

10

<!-- page 11 -->

ii.
iii.
iv.

it is received by the Proposed Due Date including any extension thereof in terms hereof;
it does not contain any condition or qualification; and
it is not non-responsive in terms hereof.

Financial Proposal

i.
ii.
iii .
iv.

The Financial Proposal is received in the form specified in this RfP;
it is received by the Proposed Due Date including any extension thereof in terms hereof;
it does not contain any condition or qualification; and
It is not non-responsive in terms hereof.

The Client reserves the right to reject any Proposal which is non-responsive and no request for
alteration, modification, substitution or withdrawal will be entertained by the Client in respect of
such Proposals. However, client reserves the right to seek clarifications or additional information
from the applicant during the evaluation process. The Client will subsequently examine and
evaluate Proposals in accordance with the Selection Process detailed out below.
2.6.3
As part of the evaluation, the Pre-Qualification Proposals submitted should fulfill the
Minimum Qualification Criteria. In case an Applicant does not fulfill the Minimum Qualification
Criteria, the Proposal of such an Applicant will not be evaluated further.
2.6.4
Minimum Qualification Criteria

s

No
1

2

3

4

Basic Requirement

Minimum Qualification Criteria

Should be Company registered under Companies Act,
1956 or a partnership firm registered under LLP Act 2008
Registered with the Service Tax Authorities. Should have
been operating for the last three years.
Project
Management Bidders must have successfully handled 2 large scale
assistance
programs (of a basic contract value of atleast Rs 1 crore
each) covering strategy and Governance, Policy
formulation/Knowledge
Partnership
services
for
Centre/state governments in the last 5 years.
Turnover
from The Consulting Agency must have a cumulative revenue
from consulting services and related activities of Rs. §QQ
consulting services
~ and above in the last three financial years (2016-17,
2017-18 and 2018-19) . (A certificate from Chartered
Accountant should be submitted).
Black listing
Consulting Agency Bidder should not be black-listed by
any Central / State Government / Public Sector
Undertaking in India.

Document

Registration

Form 38

Form 3D

Form 3C

Form 38

2.6.5
Technical Evaluation: The evaluation committee (-Evaluation Committee) appointed
by the Client will carry out the evaluation of Proposals on the basis of the following evaluation
criteria and points system. If required, the Client may seek specific clarifications from any or all
Agency(ies) at this stage. Each evaluated Proposal will be given a technical score (St) as
detailed below. The maximum points/ marks to be given under each of the evaluation criteria
are:

11

<!-- page 12 -->

5 No.

A.
1.

Technical proposal evaluation
parameters
Project Experience

Marking criteria

Maximum marks
40 marks

Experience of managing large scale 1 Assignment- 5 marks
PMU for atleast one year for Central 2 Assignment- 10 marks
Govt/State
Govts/Central
Govt. 3 Assignment- 15 marks
Agencies/ State Govt. Agencies with a14 Assignment- 20 marks
minimum contract value of INR 3
crores in last 5 years in India
Experience
of
designing
and 1 Assignment- 5 marks
executing initiatives to promote start- 2 Assignments- 10 marks
ups/innovations on behalf of Central 3 Assignments- 15 marks
Govt/State
Govts/Central
Govt.4 Assignment- 20 marks
Agencies/ State Govt. Agencies

20 marks

B.

Team Experience

30 marks

1.

Project Director:

2.

•

2.

Must have led engagements
on innovation
challenges/hackathons with
startup and innovation
ecosystem players- like
academia, co-working
spaces, incubators

•

Must have led enagagements
on program managing startup
support programs like startup
accelerator programs,
challenges.

Project manager:
•

•

10 marks
Minimum qualificationpost graduate degree in
Information and
Technology ( Technology
and Strategy)

•

Minimum work
experience- minimum of
15 years holding C-level
management/executive
position

•

Min qualification - MBA or 10 marks
equivalent

•

Min work experience- 12
years

Must have led engagements
on being knowledge partner
to Government
entities/initiatives in startup
engagement programs

•

Must have managed PMUs of
flagship Govt.
Programs/initiatives

12

20 marks

<!-- page 13 -->

3.

•

Must have had experience in
managing startup
engagements with Central
govt/State
Govt./PSUs/Corporates

•

Must have managed projects
with experience in investment
promotion programs of
Central Govt. And State
Govts.

Project Leader:

•
•

•
4.

Must have experience in
managing PMU for flagship
program of Central Govt
Must have had experience in
managing startup
engagements with Central
govt/State
Govt./PSUs/Corporates

•

Min qualification - MBA pr 6 marks
equivalent

•

Min work experience - 8
years

•

Min qualification - Post
graduation

•

Min work experience - 4
years

Must have experience of
managing global Central
Govt. Outreach events

Project Associates: (2 resources)

4 marks

C.

Approach & Methodology (including technical presentation)

30 marks

1.

Conceptual Clarity & Understanding of Assignment

5 marks

2.

Approach & Methodology

10 marks

3.

Work Plan

5 marks

4.

Case study of similar type of engagement as anticipated in the scope o1 10 marks
work of this proposal undertaken by the applicant:

13

<!-- page 14 -->

a. Impact of the engagement
b. Enablement of Startups
100 marks

Total (A+B+C)

Bidders, whose bids are responsive, based on minimum qualification criteria as in Pre-Qualification Criteria
and score at least 60 marks from the technical evaluation criteria would be considered technically qualified.
*The team along with the Project Manager shall be stationed at DPIIT during the contract period.
A proposal will be considered unsuitable and will be rejected at this stage if it does not respond to
important aspects of RfP Document and the Terms of Reference.
2.6.6 Final selection: The final selection of the consultant would be based on QCBS (QualityCum Cost Based Methodology). The technical score would be calculated for each applicant by the
client and all the applicants who get at least 60 marks out of 100 would be considered for financial
evaluation. Applicants who get a technical score of less than 60 out of 100 would not be considered
for the financial evaluation. The financial score would be calculated through a normalization
process where the lowest bidder would be given 100 marks and scores of all other bidders would
be normalized against this. Final selection would be on the basis of weighted score where the
weights for technical and financial scores would be in the ratio of 70:30. The applicant with the
highest weighted score would be awarded the contract.

Commercial Bid Evaluation

a. The Financial Bids of technically qualified bidders will be opened on the prescribed date in the presence
of bidder representatives.
b. If a firm quotes NIL charges I consideration, the bid shall be treated as unresponsive and will not be
considered.
c. The bidder with lowest qualifying financial bid (L 1) will be awarded 100% score (amongst the bidders
which did not get disqualified on the basis of point b above). Financial Scores for other than L 1 bidders will
be evaluated using the following formula: Financial Score of a Bidder (Fn) ={(Commercial Bid of L
1/Commercial Bid of the Bidder) X 100)% (Adjusted to two decimal places)
d. Only fixed price financial bids indicating total price for all the deliverables and services specified in this
bid document will be considered.
e. The bid price will include all taxes and levies and shall be in Indian Rupees.
f. Any conditional bid would be rejected
g. Errors & Rectification: Arithmetical errors will be rectified on the following basis: "If there is a discrepancy
between the unit price and the total price that is obtained by multiplying the unit price and quantity, the unit
price shall prevail and the total price shall be corrected. If there is a discrepancy between words and
figures, the amount in words will prevail".
Combined and Final Evaluation

a. The technical and financial scores secured by each bidder will be added using weightage of 70%
and 30% respectively to compute a Composite Bid Score.

14

<!-- page 15 -->

b. The bidder securing the highest Composite Bid Score will be adjudicated as the most responsive
Bidder for award of the Project. The overall score will be calculated as follows :
Bn = 0.7 * Tn + 0.3 * Fn
Where
Bn = overall score of the bidder
Tn = technical score of the bidder (out of maximum 100 marks)
Fn = normalized financial score of the bidder

c.

In the event the bid composite bid scores are 'tied', the bidder securing the highest technical score
will be adjudicated as the Best Value Bidder for award of the Project.

2.7

Grant of Work Order

2.7.1 After selection, a Work Order will be issued, in duplicate, by the Client to the Successful
Applicant and the Successful Applicant shall, within 3 (three) days of the receipt of the work order,
sign and return the duplicate copy of the work order in acknowledgement thereof. In the event the
duplicate copy of the work order duly signed by the Successful Applicant is not received by the
stipulated date, the Client may, unless it consents to extension of time for submission thereof,
appropriate the Earnest Money Deposit of such Applicant in full or to the extent of mutually agreed
pre-estimated loss and damage suffered by the Client on account of failure of the Successful
Applicant to acknowledge the work order, and the next highest ranking Applicant may be
considered.
2.7.2 Performance Security: Performance Security equivalent to 10 (Ten) percent of the total
cost of Financial Proposal shall be furnished from a Nationalized/Scheduled Bank, before start of
work on assignment, in form of a Bank Guarantee substantially in the form specified at Annexure of
the work order. For the successful bidder, the Performance Security will be retained by Client until
the completion of the assignment by the Applicant and be released 60 (Sixty) Days after the
completion of the assignment.

2.8

Confidentiality

Information relating to evaluation of proposals and recommendations concerning grant of the work
order shall not be disclosed to the applicants who submitted the proposals or to other persons not
officially concerned with the process, until the winning firm has been notified that it has been given
the work order.
2.9

Fraud and Corrupt Practices

2.9.1 The Applicants and their respective officers, employees, agents and advisers shall
observe the highest standard of ethics during the Selection Process. Notwithstanding anything to
the contrary contained in this RfP, the Client will reject a Proposal without being liable in any
manner whatsoever to the Applicant, if it determines that the Applicant has, directly or indirectly or
through an agent, engaged in corrupt practice, fraudulent practice, coercive practice, undesirable
practice or restrictive practice (collectively the -Prohibited Practices) in the Selection Process. In
such an event, the Client will, without prejudice to its any other rights or remedies, forfeit and
appropriate the Earnest Money Deposit, as mutually agreed genuine pre-estimated compensation

15

<!-- page 16 -->

and damages payable to the Client for, inter alia, time, cost and effort of the Client, in regard to the
RfP, including consideration and evaluation of such Applicant's proposal.
2.9.2 Without prejudice to the rights of the Client under this Clause, hereinabove and the rights
and remedies which the Client may have under the WORK ORDER or the Agreement, if an
Applicant or Consulting Agency, as the case may be, is found by the Client to have directly or
indirectly or through an agent, engaged or indulged in any corrupt practice, fraudulent practice,
coercive practice, undesirable practice or restrictive practice during the Selection Process, or after
the issue of the WORK ORDER or the execution of the Agreement, such Applicant or Consulting
Agency shall not be eligible to participate in any tender or RfP issued by the Client during a period
of 2 (two) years from the date such Applicant or Consulting Agency, as the case may be, is found
by the Client to have directly or through an agent, engaged or indulged in any corrupt practice,
fraudulent practice, coercive practice, undesirable practice or restrictive practice, as the case may
be.
2.9.3 For the purposes of this Clause, the following terms shall have the meaning hereinafter
respectively assigned to them:
2.9.3.1'corrupt practice' means (i) the offering, giving, receiving, or soliciting, directly or indirectly, of
anything of value to influence the action of any person connected with the Selection Process (for
avoidance of doubt, offering of employment to or employing or engaging in any manner
whatsoever, directly or indirectly, any official of the Client who is or has been associated in any
manner, directly or indirectly with the Selection Process or the WORK ORDER or has dealt with
matters concerning the Agreement or arising there from, before or after the execution thereof, at
any time prior to the expiry of one year from the date such official resigns or retires from or
otherwise ceases to be in the service of the Client, shall be deemed to constitute influencing the
actions of a person connected with the Selection Process; or (ii) save as provided herein, engaging
in any manner whatsoever, whether during the Selection Process or after the issue of the WORK
ORDER or after the execution of the Agreement, as the case may be, any person in respect of any
matter relating to the
Project or the WORK ORDER or the Agreement, who at any time has been or is a legal, financial
or technical consultant/ adviser of the Client in relation to any matter concerning the Project;
(a) -fraudulent practice means a misrepresentation or omission of facts or disclosure of
incomplete facts, in order to influence the Selection Process;
(b) -coercive practice means impairing or harming or threatening to impair or harm,
directly or indirectly, any persons or property to influence any person's participation or action
in the Selection Process;
(c) -undesirable practice means (i) establishing contact with any person connected with or
employed or engaged by the Client with the objective of canvassing, lobbying or in any
manner influencing or attempting to influence the Selection Process; or (ii) having a Conflict
of Interest; and
(d) -restrictive practice means forming a cartel or arriving at any understanding or
arrangement among Applicants with the objective of restricting or manipulating a full
and fair competition in the Selection Process.
2.10

Pre-Bid Meeting

2.10.1 Pre-Bid Meeting of the Applicants will be convened off-line at the designated date, time and
place. A maximum of two representatives of each Applicant will be allowed to participate on
production of an authorization letter from the Applicant.
2.10.2 During Pre-Bid Meeting, the Applicants will be free to seek clarifications (posted on the
website) and make suggestions for consideration of the Client. The Client will endeavour to provide
clarifications and such further information as it may, in its sole discretion, consider appropriate for

16

<!-- page 17 -->

facilitating a fair, transparent and competitive selection process. The clarification shall be posted on
the official website of DPIIT.

2.11

Miscellaneous

2.11.1 The Selection Process shall be governed by, and construed in accordance with, the laws of
India and the Courts at New Delhi shall have exclusive jurisdiction over all disputes arising under,
pursuant to and/or in connection with the Selection Process.

2.11 .2 The Client, in its sole discretion and without incurring any obligation or liability, reserves the
right, at any time, to:

2.11.2.1

suspend and/or cancel the Selection Process and/or amend and/or
supplement the Selection Process or modify the dates or other terms and conditions
relating thereto;
2.11 .2.2 consult with any Applicant in order to receive clarification or further
information;
2.11.2.3
retain any information and/or evidence submitted to the Client by, on behalf
of and/or in relation to any Applicant; and/or
2.11 .2.4
Independently verify, disqualify, reject and/or accept any and all
submissions or other information and/or evidence submitted by or on behalf of any
Applicant.

2.11.3 It shall be deemed that by submitting the Proposal, the Applicant agrees and releases the

Client, its employees, agents and advisers, irrevocably, unconditionally, fully and finally from any
and all liability for claims, losses, damages, costs, expenses or liabilities in any way related to or
arising from the exercise of any rights and/or performance of any obligations hereunder, pursuant
hereto and/or in connection herewith and waives any and all rights and/ or claims it may have in
this respect, whether actual or contingent, whether present or future.

2.11.4 All documents and other information provided by Client or submitted by an
Applicant to Client shall remain or become the property of Client. Applicants and the Consulting
Agency, as the case may be, are to treat all information as strictly confidential. Client will not
return any Proposal or any information related thereto. All information collected, analyzed,
processed or in whatever manner provided by the Applicant to Client in relation to the
assignment shall be the property of Client.

2.11.5 The Client reserves the right to make inquiries with any of the clients listed by the
Applicants in their previous experience record.

2.12

Tentative schedule for selection process

The Client will endeavour to follow the following schedule
Date of issue of RFP
Last date for receiving queries/requests for clarification
Pre-bid meeting
Client's response to queries/requests for clarification
Proposal due date
Openin!=l of pre-qualification proposal

17

16th March 2020 (Monday)
24th March 2020 (Tuesd ay) by 3:00
PM
25th March (Wednesday) at 11:00 AM
2 nd April (Thursday) 2020
14th April 2020(Tuesday) at 3:00 PM
15 th April 2020 (Wednesday) at 4:00
PM

<!-- page 18 -->

Presentation b the a

licants meetin

ualification criteria 22 nd April 2020 (Wed nesday)
o be intimated separately

*Applicant may note that the venue and time of opening of financial bid shall be posted on official
website of client after presentation by applicants.

2.13 Data Sheet
Reference
Section 1, Point 2

Section 1, point 3
2.1.1

2.3.4
2.2

2.2.2

2.4.6

Form 4A and 48

Description
Government of India intends to facilitate States and UTs in improving
regulatory environment in States and UTs to give boost to manufacturing,
services and other economic activities and implementation of its 'Make in
India' initiative. This entails developing recommendations for implementing
reforms by the States and ranking States on regulatory ease. This will also
require identification of best practices followed by the States and
documenting them for sharing with and implementing by other States.
A Consulting Agency will be selected as per Quality cum Cost Based
Selection (QCBS) process.
The name of Client is: -Department of Industrial Policy and Promotion,
Ministry of Commerce and Industry, Government of India
The proposal of the applicant shall be valid for 60 (sixty) days from the
Proposal Due Date.
th

Clarification must be requested on or before 24 March 2020.
Applicants shall share the MS Word file in soft copy of pre-bid queries at the
time of requesting clarifications. The address for requesting clarification is:
sis-dipp@nic.in
th

Date & Time of pre bid meeting 25 March 2020 at 11 :00 AM, at the
Official Address:
Department for Promotion of Industry and Internal Trade, Udyog Bhawan,
New Delhi-110001
The last date of submission of Proposal is 14m April 2020 at 3:00 PM (1ST).
The proposal will be submitted on CPPP. The address for submission of
EMO/Bank Guarantee is:
Director,
Startup India
DPIIT
Udyog Bhawan, New Delhi
The applicant to state cost in Indian Rupees onlv.

18

<!-- page 19 -->

Section 3. Pre-Qualification and Technical Proposal - Standard Forms
Form 3A:

Pre - Qualification Proposal Submission Form

Form 38

Self-certification of Minimum Eligibility and of not being blacklisted

Form 3C

Average Annual Turnover of Applicant

Form 3D:

Format for highlighting relevant experience

Form 3E:

Format for Power of Attorney for Authorized representative

Form 3F:

Format of Bank Guarantee for Earnest Money Deposit

Form 3G:

Technical Proposal Submission

Form 3H:

Profile of the agency

Form 31:

Format for CV of the professional staff proposed

Form 3J:

Understanding of the project and proposed methodology

*Please attach a clear scan copy of all the documents

19

<!-- page 20 -->

Form 3A: Pre-Qualification Proposal Submission Form
[Location, Date]

To
Director,
DPIIT
Udyog Bhawan,
New Delhi-110001
RfP dated (date] for selection of Consulting Agency for [name of assignment]
Dear Sir,

With reference to your RfP Document dated [date], we, having examined all relevant documents and
understood their contents, hereby submit our Pre-Qualification Proposal for selection as [name of
assignment]. The Proposal is unconditional and unqualified.
We are submitting our Proposal as [name of the Applicant].
We understand you are not bound to accept any Proposal you receive.
Further:

1. We acknowledge that Client will be relying on the information provided in the Proposal and the

2.
3.
4.
5.

6.

documents accompanying the Proposal for selection of the Consulting Agency, and we certify that
all information provided in the Proposal and in the supporting documents is true and correct,
nothing has been omitted which renders such information misleading; and all documents
accompanying such Proposal are true copies of their respective originals.
This statement is made for the express purpose of appointment as the Consulting Agency for the
aforesaid Project.
We shall make available to Client any additional information it may deem necessary or require for
supplementing or authenticating the Proposal.
We acknowledge the right of Client to reject our application without assigning any reason or
otherwise and hereby waive our right to challenge the same on any account whatsoever.
We certify that in the last 3 (three) years, we have neither failed to perform on any assignment or
contract, as evidenced by imposition of a penalty by an arbitral or judicial authority or a judicial
pronouncement or arbitration award against the Applicant, nor been expelled from any project,
assignment or contract by any public authority nor have had any assignment or contract terminated
by any public authority for breach on our part.
We declare that:

a. We have examined and have no reservations to the RfP, including any Addendum issued by the
Authority;
b. We do not have any conflict of interest in accordance with the terms of the RfP;
c. We have not directly or indirectly or through an agent engaged or indulged in any corrupt practice,
fraudulent practice, coercive practice, undesirable practice or restrictive practice, as defined in the
RfP document, in respect of any tender or request for proposal issued by or any agreement entered
into with Client or any other public sector enterprise or any government, Central or State; and
d. We hereby certify that we have taken steps to ensure that no person acting for us or on our behalf
will engage in any corrupt practice, fraudulent practice, coercive practice, undesirable practice or
restrictive practice.

20

<!-- page 21 -->

7. We understand that you may cancel the selection process at any time and that you are neither
bound to accept any Proposal that you may receive nor to select the Consulting Agency, without
incurring any liability to the Applicants.
8. We declare that we are not a member of any other Consortium/JV applying for selection as a
Consulting Agency.
9. We certify that in regard to matters other than security and integrity of the country, we or any of our
affiliates have not been convicted by a court of law or indicted or adverse orders passed by a
regulatory authority which would cast a doubt on our ability to undertake the Project or which
relates to a grave offence that outrages the moral sense of the community.
10. We further certify that in regard to matters relating to security and integrity of the country, we have
not been charge-sheeted by any agency of the Government or convicted by a court of law for any
offence committed by us or by any of our affiliates. We further certify that neither we nor any of our
consortium members have been barred by the central government, any state government, a
statutory body or any public sector undertaking, as the case may be, from participating in any
project or bid, and that any such bar, if any, does not subsist as on the date of this RfP.
11. We further certify that no investigation by a regulatory authority is pending either against us or
against our affiliates or against our CEO or any of our Directors/ Managers/ employees.
12. We hereby irrevocably waive any right or remedy which we may have at any stage at law or
howsoever otherwise arising to challenge or question any decision taken by Client in connection
with the selection of Consulting Agency or in connection with the selection process itself in respect
of the above mentioned Project.
13. We agree and understand that the proposal is subject to the provisions of the RfP document. In no
case, shall we have any claim or right of whatsoever nature if the Project is not awarded to us or
our proposal is not opened or rejected.
14. We agree to keep this offer valid for 60 (sixty) days from the POD specified in the RfP.

15. A Power of Attorney in favour of the authorized signatory to sign and submit this Proposal and
documents is attached herewith .
16. The Technical and Financial Proposal is being submitted in a separate cover. This PreQualification Proposal read with the Technical and Financial Proposal shall constitute the
application which shall be binding on us.
17. We agree and undertake to abide by all the terms and conditions of the RfP Document.

We remain,

Yours sincerely,
Authorized signature Name and title
of signatory Name of Firm
Address:
Telephone:
Fax:
(Name and seal of the Applicant/Member in Charge)

21

<!-- page 22 -->

Form 38: Self-certification of Minimum Eligibility and of not being blacklisted

[Location, Date]

Here give a certificate that the Consulting Agency is a registered firm under Companies Act, 1956 or a
partnership firm registered under LLP Act, 2008 Registered with the Service Tax Authorities. Should have
been operating for the last three years* and is not being currently blacklisted** by any Central/ State/ Public
Sector undertaking in India.
If at any time it is found out that the Consulting Agency did not had the capabilities as enumerated above,
DPIIT may put the Consulting Agency in negative list without prejudice to any other civil/ criminal action
under the law and forfeiture of the earnest money deposit and in due course the performance guarantee in
lieu of penalty

*Kindly provide supporting documents of being registered firm/incorporation certificate
**Kindly provide details if the company has been blacklisted in the past with the relevant supporting
documents

22

<!-- page 23 -->

Form 3C: Format for Pre-Qualification Proposal (Cumulative Annual Turnover of Applicant)

SN

Financial years

1.
2.
3.

2016-17
2017-18
2018-19

Revenue from Consulting
Services (INR)

Cumulative Annual Turnover

Certificate from the Statutory Auditor

This is to certify that [name of company] [registered address] has received the payments
shown above against the respective years.

Name of Authorized Signatory
Designation.
Name of firm

Signature of Authorized Signatory Seal of Audit firm

Note:

1. In case the Applicant does not have a statutory auditor, it may provide the certificate from its
Chartered Accountant.

23

<!-- page 24 -->

Form 3D: Format for highlighting relevant experience

Assignment Name:

Approx. value of the Contract

Country:
Location within the Country:

Dura~on of a~si_
gnme_nt (rno_n_tbs) : _

Name of Client:

Total number of staff-months:

Address of Client:

Name of Project Manager involved and functions performed:

Names of 5 professionals and qualification details:

Description of Actual Services Provided by Your Staff:

*Kindly provide supporting documents such as contract/work order copy LOI/completion
certificate etc.
*Please note that the experience will not be counted if the relevant supporting document is not
attached.
*Please provide experience of the registered firm/company/partnership who is applying (do not
share experience of sister companies/subsidiaries)
* Please attach a clear scan copy of the supporting documents

24

<!-- page 25 -->

Form 3E: Format for Power of Attorney for Authorized Representative

Know all men by these presents, We, [name of organization and address of the registered office] do hereby
constitute, nominate, appoint and authorize Mr/ Ms [name], son/ daughter/ wife of [name], and presently
residing at [address], who is presently employed with/ retained by us and holding the position of
[designation] as our true and lawful attorney (hereinafter referred to as the -Authorized Representative),
with power to sub- delegate to any person, to do in our name and on our behalf, all such acts, deeds and
things as are necessary or required in connection with or incidental to submission of our Proposal for and
selection as Consulting Agency for [name of assignment], to be developed by DPIIT (the -Authority)
including but not limited to signing and submission of all applications, proposals and other documents and
writings, participating in pre-bid and other conferences and providing information/ responses to the
Authority, representing us in all matters before the Authority and undertakings consequent to acceptance of
our proposal and generally dealing with the Authority in all matters in connection with or relating to or
arising out of our Proposal for the said Project and/or upon award thereof to us until accepting the work
order with the Authority.
AND, we do hereby agree to ratify and confirm all acts, deeds and things lawfully done or caused to be
done by our said Authorized Representative pursuant to and in exercise of the powers conferred by this
Power of Attorney and that all acts, deeds and things done by our said Authorized Representative in
exercise of the powers hereby conferred shall and shall always be deemed to have been done by us.
IN WITNESS WHEREOF WE, [name of organization], THE ABOVE NAMED PRINCIPAL HAVE
EXECUTED THIS POWER OF ATTORNEY ON THIS [date in words] DAY OF [month] [year in yyyy
format] .

For [name and registered address of organization] [Signature]
[Name]
[Designation]
Witnesses:

1. [Signature, name and address of witness]
2. [Signature, name and address of Witness] Accepted
Signature] [Name]
[Designation]
[Address] Notes:

25

<!-- page 26 -->

1. The mode of execution of the Power of Attorney should be in accordance with the procedure, if
any, laid down by the applicable law and the charter documents of the executant(s) and when it is
so required the same should be under seal affixed in accordance with the required procedure.
2. Wherever required, the Applicant should submit for verification the extract of the charter documents
and other documents such as a resolution/power of attorney in favour of the person executing this
Power of Attorney for the delegation of power hereunder on behalf of the Applicant.
3. For a Power of Attorney executed and issued overseas, the document will also have to be legalized
by the Indian Embassy and notarized in the jurisdiction where the Power of Attorney is being
issued. However, the Power of Attorney provided by Applicants from countries that have signed
The Hague Legislation Convention, 1961 are not required to be legalized by the Indian Embassy if
it carries a conforming Apostille certificate.

26

<!-- page 27 -->

Form 3F: Format of bank Guarantee for Earnest Money Deposit

BG No.
Date:

1. In consideration of you, Department for Promotion of Industry and Internal Trade, Ministry of
Commerce and Industry, Government of India, Udyog Bhawan, New Delhi - 110 011 (hereinafter
referred to as the -Authority which expression shall, unless repugnant to the context or meaning
thereof, include its administrators, successors and assigns) having agreed to receive the proposal
of [Name of company], (hereinafter referred to as the -Bidder which expression shall unless it be
repugnant to the subject or context thereof include its successors and assigns), for appointment as
Consulting Agency for [name of assignment] pursuant to the RfP Document dated [date] issued in
respect of the Assignment and other related documents including without limitation the draft work
order for services (hereinafter collectively referred to as -RfP Documents), we [Name of the Bank]
having our registered office at [registered address] and one of its branches at [branch address]
(hereinafter referred to as the -Bank), at the request of the Bidder, do hereby in terms of relevant
clause of the Rf P Document, irrevocably, unconditionally and without reservation guarantee the
due and faithful fulfilment and compliance of the terms and conditions of the RfP Document by the
said Bidder and unconditionally and irrevocably undertake to pay forthwith to the Authority an
amount of Rs. [in figures] ([in words]) (hereinafter referred to as the -Guarantee) as our primary
obligation without any demur, reservation, recourse, contest or protest and without reference to the
Bidder if the Bidder shall fail to fulfil or comply with alt or any of the terms and conditions contained
in the said RfP Document.
2. Any such written demand made by the Authority stating that the Bidder is in default of the due and
faithful fulfilment and compliance with the terms and conditions contained in the RfP Document
shalt be final, conclusive and binding on the Bank. We, the Bank, further agree that the Authority
shall be the sole judge to decide as to whether the Bidder is in default of due and faithful fulfilment
and compliance with the terms and conditions contained in the RfP Document including, Document
including without limitation, failure of the said Bidder to keep its Proposal valid during the validity
period of the Proposal as set forth in the said RfP Document, and the decision of the Authority that
the Bidder is in default as aforesaid shall be final and binding on us, notwithstanding any
differences between the Authority and the Bidder or any dispute pending before any court, tribunal,
arbitrator or any other authority.
3. We, the Bank, do hereby unconditionally undertake to pay the amounts due and payable under this
Guarantee without any demur, reservation, recourse, contest or protest and without any reference
to the Bidder or any other person and irrespective of whether the claim of the Authority is disputed
by the Bidder or not, merely on the first demand from the Authority stating that the amount claimed
is due to the Authority by reason of failure of the Bidder to fulfil and comply with the terms and
conditions contained in the RfP Document including without limitation, failure of the said Bidder to
keep its Proposal valid during the validity period of the Proposal as set forth in the said RfP
Document for any reason whatsoever. Any such demand made on the Bank shall be conclusive as
regards amount due and payable by the Bank under this Guarantee. However, our liability under
this Guarantee shall be restricted to an amount not exceeding Rs. [in figures] ([in words]).
4. This Guarantee shall be irrevocable and remain in full force for a period of 60(sixty) days from the
Proposal Due Date and a further claim period of thirty (30) days or for such extended period as
may be mutually agreed between the Authority and the Bidder, and agreed to by the Bank, and
shall continue to be enforceable until all amounts under this Guarantee have been paid.
5. The Guarantee shall not be affected by any change in the constitution or winding up of the Bidder
or the Bank or any absorption, merger or amalgamation of the Bidder or the Bank with any other
person.
6. In order to give full effect to this Guarantee, the Authority shall be entitled to treat the Bank as the
principal debtor. The Authority shall have the fullest liberty without affecting in any way the liability

27

<!-- page 28 -->

of the Bank under this Guarantee from time to time to vary any of the terms and conditions
contained in the said RfP Document or to extend time for submission of the Proposals or the
Proposal validity period or the period for conveying of Letter of Acceptance to the Bidder or the
period for fulfilment and compliance with all or any of the terms and conditions contained in the said
RfP Document by the said Bidder or to postpone for any time and from time to time any of the
powers exercisable by it against the said Bidder and either to enforce or forbear from enforcing any
of the terms and conditions contained in the said RfP Document or the securities available to the
Authority, and the Bank shall not be released from its liability under these presents by any exercise
by the Authority of the liberty with reference to the matters aforesaid or by reason of time being
given to the said Bidder or any other forbearance , act or omission on the part of the Authority or
any indulgence by the Authority to the said Bidder or by any change in the constitution of the
Authority or its absorption, merger or amalgamation with any other person or any other matter or
thing whatsoever which under the law relating to sureties would but for this provision have the
effect of releasing the Bank from its such liability.
7. Any notice by way of request, demand or otherwise hereunder shall be sufficiently given or made if
addressed to the Bank and sent by courier or by registered mail to the Bank at the address set forth
herein.
8. We undertake to make the payment on receipt of your notice of claim on us addressed to (Name of
bank along with branch address] and delivered at our above branch which shall be deemed to have
been duly authorized to receive the said notice of claim.
9.

It shall not be necessary for the Authority to proceed against the said Bidder before proceeding
against the Bank and the guarantee herein contained shall be enforceable against the Bank,
notwithstanding any other security which the Authority may have obtained from the said Bidder or
any other person and which shall, at the time when proceedings are taken against the Bank
hereunder, be outstanding or unrealized.
10. We, the Bank, further undertake not to revoke this Guarantee during its currency except with the
previous express consent of the Authority in writing .
11. The Bank declares that it has power to issue this Guarantee and discharge the obligations
contemplated herein, the undersigned is duly authorized and has full power to execute this
Guarantee for and on behalf of the Bank.
12. For the avoidance of doubt, the Bank's liability under this Guarantee shall be restricted to Rs. [in
figures] ([in words]) . The Bank shall be liable to pay the said amount or any part thereof only if the
Authority serves a written claim on the Bank in accordance with paragraph 8 hereof, on or before
[date].

Signed and Delivered by [name of bank]

By the hand of Mr. /Ms. [name], it's (designation] and authorized official.

(Signature of the Authorized Signatory)
(Official Seal)

Notes:

28

<!-- page 29 -->

The Bank Guarantee should contain the name, designation and code number of the officer(s) signing the
Guarantee.
The address, telephone number and other details of the Head Office of the Bank as well as of issuing
Branch should be mentioned on the covering letter of issuing Branch .

Form 3G: Technical Proposal Submission Form

[Location , Date]
Director (Startup India),
DPIIT,
Udyog Bhawan,
New Delhi-110001
RfP dated [date] for selection for [name of assignment]

Sir,
With reference to your RfP Document dated [date], we, having examined all relevant documents and
understood their contents, hereby submit our Technical Proposal for selection as [name of assignment].
The Proposal is unconditional and unqualified.
We are submitting our Proposal as [name of the applicant].
If negotiations are held during the period of validity of the Proposal, we undertake to negotiate in
accordance with the RfP. Our Proposal is binding upon us, subject only to the modifications resulting from
negotiations in accordance with the RfP.
We understand you are not bound to accept any Proposal you receive. Further:

1. We acknowledge that Client will be relying on the information provided in the Proposal and the
documents accompanying the Proposal for selection of the Consulting Agency, and we certify that
all information provided in the Proposal and in the supporting documents is true and correct,
nothing has been omitted which renders such information misleading; and all documents
accompanying such Proposal are true copies of their respective originals.
2. This statement is made for the express purpose of appointment as the Consulting Agency for the
aforesaid Project.
3. We shall make available to Client any additional information it may deem necessary or require for
supplementing or authenticating the Proposal.
4. We acknowledge the right of Client to reject our application without assigning any reason or
otherwise and hereby waive our right to challenge the same on any account whatsoever.
5. We certify that in the last 3 (three) years, we have neither failed to perform on any assignment or
contract, as evidenced by imposition of a penalty by an arbitral or jud icial authority or a judicial
pronouncement or arbitration award against the Applicant, nor been expelled from any project,
assignment or contract by any public authority nor have had any assignment or contract terminated
by any public authority for breach on our part.

29

<!-- page 30 -->

6. We declare that:
a. We have examined and have no reservations to the RfP, including any Addendum issued by the
Authority;
b. We do not have any conflict of interest in accordance with the terms of the RfP;
c. We have not directly or indirectly or through an agent engaged or indulged in any corrupt practice,
fraudulent practice, coercive practice, undesirable practice or restrictive practice, as defined in the
RfP document, in respect of any tender or request for proposal issued by or any agreement entered
into with Client or any other public sector enterprise or any government, Central or State; and
d. We hereby certify that we have taken steps to ensure that no person acting for us or on our behalf
will engage in any corrupt practice, fraudulent practice, coercive practice, undesirable practice or
restrictive practice.
7. We understand that you may cancel the selection process at any time and that you are neither
bound to accept any Proposal that you may receive nor to select the Consulting Agency, without
incurring any liability to the Applicants.
8. We certify that in regard to matters other than security and integrity of the country, we or any of our
affiliates have not been convicted by a court of law or indicted or adverse orders passed by a
regulatory authority which would cast a doubt on our ability to undertake the Project or which
relates to a grave offence that outrages the moral sense of the community.
9. We further certify that in regard to matters relating to security and integrity of the country, we have
not been charge-sheeted by any agency of the Government or convicted by a court of law for any
offence committed by us or by any of our affiliates. We further certify that neither we nor any of our
consortium members have been barred by the central government, any state government, a
statutory body or any public sector undertaking, as the case may be, from participating in any
project or bid, and that any such bar, if any, does not subsist as on the date of this RfP.
10. We further certify that no investigation by a regulatory authority is pending either against us or
against our affiliates or against our CEO or any of our Directors/ Managers/ employees.
11. We hereby irrevocably waive any right or remedy which we may have at any stage at law or
howsoever otherwise arising to challenge or question any decision taken by Client in connection
with the selection of Consulting Agency or in connection with the selection process itself in respect
of the above mentioned Project.
12. We agree and understand that the proposal is subject to the provisions of the RfP document. In no
case, shall we have any claim or right of whatsoever nature if the Project is not awarded to us or
our proposal is not opened or rejected.
13. The Financial Proposal is being submitted in a separate cover. This Technical Proposal read with
the Financial Proposal shall be binding on us.
14. We agree and undertake to abide by all the terms and conditions of the RfP Document.

We remain,
Yours sincerely,

Authorized Signature [In full and initials]:
Name and Title of Signatory:
Name of Firm:
30

<!-- page 31 -->

Address:
Telephone:
Fax:
(Name and seal of the ApplicanUMember in Charge)

31

<!-- page 32 -->

Form 3H: Profile of Agency
{Location, Date]

Brief Profile of Agency (in one page)
Number of offices with locations in India

Form 31: Format for CV of the professional staff proposed

1. Name
2. Position:
3. Date of Birth
4. Education:
'
,from

I

:
:ro

-1

,
icompany

r-------

,Position
:Held

,

C-

5. Employment Record

:s. Brief Profile
I

Year of experience
etc.

7. Countries of Work Experience
8. Languages
9. Work Undertaken that Best Illustrates Capability to Handle the Task Assigned Year:
Location:
Client: Position Held:
Main features:
Activities Performed:

32

<!-- page 33 -->

10. Certification

I, certify that to the best of my knowledge and belief, this CV correctly describes myself, my
qualifications, and my experience. I understand that any wilful misstatement described herein may
lead to my disqualification or dismissal, if engaged.

Date:_ _ _ __ _ __ __

Signature of staff member/ Authorized signatory

Day/Month/Year

Form 3J: Understanding of the project and proposed methodology

0

o

0

o
o

0

o

No. Activi y

Understanding of the project

Technical approach and methodology
Case study of similar type of engagement: Impact of the engagement
and
Enablement of startups

Work plan

Time Period
1st

2nd

..

..

.. ...

33

.... ...

....

...

...

...

<!-- page 34 -->

Section 4. Financial Proposal - Standard Forms

Form 4A:

Financial Proposal Submission

Form 48:

Summary of Costs

Form 4A: Financial Proposal Submission Form

[Location]
[Date]
To
Director,
DPIIT,
Udyog Bhawan,
New Delhi-110001
Dear Sir,
Subject: Services for [name of assignment].

We, the undersigned, offer to provide the services for [name of assignment] in accordance with your
Request for Proposal dated [date] and our Proposal. Our attached Financial Proposal is for the sum of
[amount(s) in words and figures) (excluding service tax)
Our Financial Proposal shall be binding upon us subject to the modifications resulting from arithmetic
correction, if any, up to expiration of the validity period of the Proposal, i.e. [date].
We undertake that, in competing for (and, if the award is made to us, in executing) the above assignment,
we will strictly observe the laws against fraud and corruption in force in
India namely -Prevention of Corruption Act 1988.
We understand you are not bound to accept any Proposal you receive.

34

<!-- page 35 -->

Yours sincerely,

Authorized Signature [In full and initials] :
Name and Title of Signatory:
Name
Address:

of

Firm:

Form 48: Summary of Costs

Item

Costs of Financial
Proposal
(including all other
taxes)

Cost for Year-2
Amount
Amount in
in
words
fi!::iures

Cost for Year-1
Amount in
words

Amount in
figures

Cost for Year-3
Amount in
words

Amount
in
figures

Total Cost
Service Tax
Total cost of Financial
Proposal (including
service
tax)

Service tax would be payable at the applicable rates as may be in force from time to time.

For Financial Evaluation, the total fee for the period will be considered. This Fixed Annual Fee will
cover costs/expenses of the Consulting Agency for undertaking work as detailed in the Scope of Work.

35

<!-- page 36 -->

Section 5. Terms of Reference

5.1 The scope of work for empanelled Consultant includes the following:
Consulting agency should perform the following functions to assist DPIIT in successfully running the Startup
India initiative:
1) Assist DPIIT in conducting baseline evaluation for the Startup India initiative, evaluate the
implementation success and state of progress of the programs under the initiative, and provide
recommendations for implementation

a.
b.
c.

Study the current landscape for startups and start-up enablers in India in terms of sector wise
growth & investments in the various sub-sectors
Evaluate the implementation success and state of progress of the programs under the Startup India
initiative
Identify global best in class practices to facilitate the startup ecosystem in the country

2. Assist DPIIT in developing a futuristic vision, defining the aspirations for Startup India

a. Assist in creation of time bound targets for India's global standing as a startup ecosystem in
consultation with relevant stakeholders
b. Development of measurable indicators with globally accepted measurable matrices such as
investments in startups, number of startups, employment generation, and other relevant sector
specific indicators

3. Identify key challenges in the startup ecosystem through discussions with entrepreneurs, investors and
incubators etc.
a.

Identify challenges in regulatory approvals, taxation, ease of doing business and global expansion
for Indian startups
b. Determine key process bottlenecks which prevent businesses, HNls and other investors to invest in
startups
c. Identify sector-specific challenges for the key sectors

4. Identify key interventions to facilitate the startup eco-system in India
a.

Identify policy interventions required to facilitate the startup ecosystem in the country and
accelerate investment into startups
b. Define an action plan to attract investment in startups in the country
c. Facilitate startups in getting access to market. For example, in public and private procurement, both
in India and abroad

5) Program Management

36

<!-- page 37 -->

a.

Develop an action plan for implementation of the identified interventions and associated
programs
b. Handhold, supervise and monitor implementation of recommendations for next two years
c. Designing and set up a system to monitor progress on the above initiatives in achievement
of deliverables and targets set for various agencies
d. Collecting data for, developing, reviewing and validating impact analysis reports
e. Developing a risk register with anticipated risks & risk responses and communication plan

6. Develop a mechanism for providing access to startups to work with all levels of the central government
and state governments
a. Provide a single node of access for startups to approach the line ministries to pitch
ideas, seek support and provide inputs on relevant policies
b. Coordinate with various ministries to test/ trial run disruptive technologies,
processes and concepts
c. Assist the startups in designing and implementing pilots in collaboration with
respective line ministries

7. Assist DPIIT in conducting outreach programs comprising of competitions, hackathons, workshops to
enhance interest in the ecosystem
a.

Provide inputs on themes, event conceptualization, identification of speakers and
participants
b. Provide support in preparation of redefined list of target regions and target sectors
c. Develop annual calendar for outreach programs and workshops for both domestic
and international markets
8. Assistance in providing inputs related to the Startup India Website and promotional content
a.

Support DPIIT to periodically review, analyze Startup India website and suggest
improvement on the website structure (biannual)
b. Support DPIIT to maintain website content hygiene, review and update of sector specific
content (biannual)
c. Support DPIIT in providing information regarding content to be used in various client's
engagements
d. Support in fact checking and providing outline for any new content components as
suggested by the client
e. Development of content ready for design (content types and periodicity to be reviewed and
agreed with the client on regular intervals)
f. Support client in coordination with IT development & design agency(ies) responsible for
uploading of approved content

37

<!-- page 38 -->

5.2 Location Scope The team (except Project Director) shall be deployed full time at
Udyog Bhawan in Delhi for the duration of the engagement. The Project Director shall
have to be present at Udyog Bhawan as per the requirements of the project as directed
by DPIIT.
Duration of the engagement of the consulting agency would be 3 years (for a period of three
years extendable one year at a time (for a total duration of 5 years),

38

<!-- page 39 -->

Section 6. Standard Form of Work Order

STANDARD FORM OF WORK ORDER FOR APPOINTMENT OF CONSULTING AGENCY

Between

[Name of client]

[Name of CONSULTING AGENCY]

[Date]

39

<!-- page 40 -->

I.

Form of Work Order

Work order to undertake [name of assignment]
The Department for Promotion of Industry and Internal Trade, Ministry of Commerce and Industry,
Government of India, Udyog Bhawan, New Delhi-110001 , India, hereinafter referred to as the
-Client which expression unless repugnant to context or meaning thereof shall include its
successors, affiliates and assigns) has:
a . requested the Consulting Agency to provide certain services as defined in the
General Conditions attached to this work order (hereinafter called the -Services); and
b. The Consulting Agency, having represented to the Client that they have the required professional
skills, personnel and technical resources, have agreed to provide the services on the terms and
conditions set forth in this assignment.
NOW THEREFORE the Client hereto hereby agrees as follows :

1. The following documents attached hereto shall be deemed to form an integral part of this work
order:

Appendix A: Terms of reference containing, inter-alia, the Description of the
Services and reporting requirements ,
Appendix B: Cost Estimate
Appendix C: Copy of Bank Guarantee for Performance Security [in the format given
in Annexure A]

2. The mutual rights and obligations of the Client and the Consulting Agency shall be as set forth in
the work order; in particular:
a. The Consulting Agency shall carry out the Services in accordance with the provisions of
the work order; and
b. Client will make payments to the Consulting Agency in accordance with the provisions of
the work order.
3

Commencement, completion, modification and termination of work order
40

<!-- page 41 -->

3.1.1 Effectiveness of work order: This Work order shall be effective from the date of issue by the
client or date of receipt of the work order by the consulting agency.
3.1.2 Commencement of Services: The Consulting Agency shall commence the Services from the
date of issue by the client or date of receipt of the work order by the consulting agency (i.e. may not
require to notify by the client again) .
3.1.3 Expiration of work order: Unless terminated earlier pursuant to relevant clauses in this work
order hereof, this work order shall expire when Services have been completed and all
payments have been made at the end of such time period after the Effective Date.
3.1.4 Modification: Modification of the terms and conditions of this work order, including any
modification of the scope of the Services or of the work order Price, may only be made by written
agreement between the Parties.
3.1.5 Force Majeure
Neither party will be liable in respect of failure to fulfil its obligations, if the said failure is entirely due
to Acts of God, Governmental restrictions or instructions, natural calamities or catastrophe,
epidemics or disturbances in the country. Force Majeure shall not include (i) any event which is
caused by the negligence or intentional action of a Party or by or of such Party's agents or
employees, nor (ii) any event which a diligent Party could reasonably have been expected both to
take into account at the time of being assigned the work, and avoid or overcome with utmost
persistent effort in the carrying out of its obligations hereunder.
A Party affected by an event of Force Majeure shall immediately notify the other Party of such event,
providing sufficient and satisfactory evidence of the nature and cause of such event, and shall
similarly give written notice of the restoration of normal conditions as soon as possible.
3.1.6 No Breach of Work order: The failure of a party to fulfil any of its obligations under the Work
order shall not be considered to be a breach of, or default under this Work order insofar as such
inability arises from an event of Force Majeure, provided that the Party affected by such an event:
a) has taken all precautions, due care and reasonable alternative measures in
order to carry out the terms and conditions of this Work order, and
b) has informed the other party as soon as possible about the occurrence of such
an event.
c) the dates of commencement and estimated cessation of such event of Force
Majeure; and
d) the manner in which the Force Majeure event(s) affects the Party_s
obligation(s) under the Work order.
3.1.7 Neither Party shall be able to suspend nor excuse the non- performance of its obligations
hereunder unless such Party has given the notice specified above.
3.1.8 Extension of Time: Any period within which a Party shall, pursuant to this Work order,
complete any action or task, shall be extended for a period equal to the time during which such
Party was unable to perform such action as a result of Force Majeure.
3.1.9 Payments: During the period of their inability to perform the Services as a result of an event
of Force Majeure, the Consulting Agency shall be entitled to continue to be paid under the terms of
this Work order, as well as to be reimbursed for additional costs reasonably and necessarily
incurred by them during such period for the purposes of the services and in reactivating the services
after the end of such period .
3.2

Termination
41

<!-- page 42 -->

3.2.1 Any side (Client or the Consulting Agency) should be able to give notice of 3 months for the
termination of Project. If the Agency decides to terminate the project, then the client will forfeit the
Performance Guarantee.
3.2.2 By the client: The Client may terminate this Work order, written notice of termination to the
Consulting Agency, to be given after the occurrence of any of the events specified in this clause:
a)
if the Consulting Agency do not remedy a failure in the performance of their obligations
under the Work order, within a period of seven (7) days, after being notified or within such
further period as the Client may have subsequently approved in writing;
b)
within fifteen (15) days, if the Consulting Agency become insolvent or bankrupt;
c)
if, as the result of Force Majeure, the Consulting Agency are unable to perform a
material portion of the Services for a period of not less than fifteen (15) days;
d)
within fifteen (15) days, if the Consulting Agency fails to comply with any final decision
reached as a result of arbitration proceedings pursuant to relevant clauses hereof;
e)
within seven (7) days, if the Consulting Agency submits to the Client a false statement
which has a material effect on the rights, obligations or interests of the Client. If the
Consulting Agency places itself in position of conflict of interest or fails to disclose promptly
any conflict of interest to the Client;
f)
within seven (7) days, if the Consulting Agency, in the judgment of the Client has
engaged in Corrupt or Fraudulent Practices in competing for or in executing the Work order;
g)
if the Client, in its sole discretion and for any reason whatsoever, within a period of
fifteen (15) days_ decides to terminate this Work order.
3.2.3 Payment upon termination: Upon termination of this Work order, the Client will make the
following payments to the Consultants:
a)
Remuneration pursuant to relevant clauses for Services satisfactorily performed prior
to the effective date of termination;
b) If the Work order is terminated pursuant to Clause 3.2.2 a), b), d), e) or f), the
Consulting Agency shall not be entitled to receive any agreed payments upon termination of
the Work order. However, the Client may consider to make payment for the part satisfactorily
performed on the basis of the quantum merit as assessed by it, in its sole discretion, if such
part is of economic utility to the Client. Under such circumstances, upon termination, the
Client may also impose liquidated damages as per the provisions of relevant clauses of this
Work order. The Consulting Agency will be required to pay any such liquidated damages to
Client within 30 days of termination date.
3.2.4 Disputes about Events of Termination: If either Party disputes Termination of the
work order under relevant clauses hereof, such Party may, within forty-five (45) days after
receipt of notice of termination from the other Party, refer the matter to arbitration under
relevant clauses hereof, and this Work order shall not be terminated on account of such
event except in accordance with the terms of any resulting arbitral award.
3.3 . INTELLECTUAL PROPERTY
3.3.1 Commission to own intellectual property created: All rights to any intellectual property
conceived or produced by the Consultant for the Client in the course of performing the Consultancy
Services and all information (including information that is in electronic form), working papers, reports
or other papers collected or produced by the Consultant for the purpose of providing the Consultancy
Services are the property of the Client from the date that property is created or developed and the
Consultant waives in favour of the Client any moral rights that the Consultant may have.
3.3.2 Existing intellectual property: Despite anything to the contrary contained in this Agreement,
it is understood and agreed that the Consultant shall retain all of its rights in its proprietary
information including, without limitation, its methodologies and methods of analysis, ideas, concepts,
expressions, know how, methods, techniques, skills, knowledge and experience possessed by the
Consultant prior to, or acquired by the Consultant during, the performance of this Agreement and the
Consultant will not be restricted in any way with respect to the same.
3.3.3 On termination or completion: Not more than five (5) Business Days following the date of
termination of this Agreement (for whatever reason) or completion of the Consultancy Services, the
Consultant will deliver to the Client all information (including information that is in electronic form),
Confidential Information, intellectual property, working papers, reports or other papers that are the
property of the Client.
3.4 Obligations of the Consulting Agency

42

<!-- page 43 -->

3.4.1 General: The Consulting Agency shall perform the Services and carry out their obligations
hereunder with all due diligence, efficiency and economy, in accordance with generally accepted
professional techniques and practices, and shall observe sound management practices, and employ
appropriate advanced technology and safe methods. The Consulting Agency shall always act, in
respect of any matter relating to this Work order or to the services, as faithful advisers to the Client,
and shall at all times support and safeguard the client's legitimate interests in any dealings with Subconsultants or third parties.
3.4.2 Conflict of interest
3.4.2.1 Prohibition of Conflicting Activities: Neither the Consulting Agency nor their Sub-consultants
nor the Personnel shall engage, either directly or indirectly, in any of the following activities:
a) during the term of this Work order, any business or professional activities which would
conflict with the activities assigned to them under this Work order; and
b) after the termination of this Contact, such other activities as may be specified in the SC.
c) during the term of this work order, the team members allotted by the Consulting Agency to this
project may not work with any other Country on Ease of Doing Business.
3.4.3 Confidentiality: The Consulting Agency, their Sub-consultants, and the Personnel of either of
them shall not, either during the term or after the expiration of this Work order, disclose any
proprietary or confidential information relating to the Project, the Services, this Contact or the Client's
business or operations without the prior written consent of the Client.
3.4.4 Documents Prepared by the Consulting Agency to be the Property of the Client: All designs,
reports, other documents and software submitted by the Consulting Agency pursuant to this work
order shall become and remain the property of the Client, and the Consulting Agency shall, not later
than upon termination or expiration of this Work order, deliver all such documents and software to
the Client, together with a detailed inventory thereof. The Consulting Agency may retain a copy of
such documents and software. Restrictions about the future use of these documents and software, if
any, shall be specified in the SC.
3.4.5 Liability of the Consulting Agency: Subject to additional provisions, if any, in this work order the
Consulting Agency's liability under this Work order shall be as provided by the Applicable Law.
3.4.6 Professional Liability Insurance: Consulting Agency will maintain at its expense, Professional
Liability Insurance including coverage for errors and omissions caused by Consulting Agency's
negligence, breach in the performance of its duties under this Work order from an Insurance
Company permitted to offer such policies in India, for a period of one year beyond completion of
Services commencing from the Effective Date, (i) For an amount not exceeding one time the total
payments for Professional Fees made or expected to be made to the Consulting Agency hereunder
or (ii) the proceeds, the Consulting Agency may be entitled to receive from any insurance maintained
by the Consulting Agency to cover such a liability, whichever of (i) or (ii) is higher with a minimum
coverage of [insert amount and currency] .
3.5 Obligations of the client
3.5.1 Assistance and Exemptions: the Client will use its best efforts to ensure that the
Government will provide the Consulting Agency with work permits and such other
documents as necessary to enable the Consulting Agency to perform the Services:
3.5.1 .1 issue to officials, agents and representatives of the Government all such
instructions as may be necessary or appropriate for the prompt and effective
implementation of the Services;
3.6 Payments to the Consulting Agency
3.6.1 Advance payment will not be considered .
3.6.2 The Agency will submit pre-receipted invoices in triplicate, complete in all respects, on
the last working day of every quarter, for necessary settlement. Payment would be made on
equal instalments on quarterly basis subject to satisfactory completion of work in the quarter.
The invoices should be submitted along with complete details of the work undertaken during
the quarter, supporting documents and bills (if required) as well as copies of the work/ material

43

<!-- page 44 -->

I produced during the quarter, for which the bills are submitted . A reconciliation sheet
pertaining to the bills will be submitted every quarter.
3.6.3 The final payment shall be released only after completion of the required work detailed
in the RfP Document.
3.6.4 The SeNice Tax/ VAT shall be paid as applicable.
3.6.5 For facilitating Electronic transfer for funds the selected agency will be required to
indicate the name of the Bank and Branch, account number (i.e. bank names, IFSC Code and
Bank Ne No.) and also forward a cheque leaf duly cancelled to verify the details furnished .
These details should also be furnished on the body of every bill submitted for payments by the
selected agency.
3.6.6 Currency: The price is payable in local currency i.e. Indian Rupees.
3.6.7 Payment for Additional SeNices: For the purpose of determining the remuneration due
for additional seNices as may be agreed under relevant clauses for modification in this work
order.
3.7 Settlement of disputes
3.7.1 Amicable Settlement: The Parties shall use their best efforts to settle amicably all
disputes arising out of or in connection with this Work order or its interpretation.
3.7.2 Disputes Settlement: Any dispute between the Parties as to matters arising out of and
relating to this Work order that cannot be settled amicably within thirty (30) days after receipt
by one Party of the other Party_s request for such amicable settlement may be submitted by
either Party for settlement in accordance with the provision specified in the SC or all disputes
shall be finally settled by by Secretary DPIIT.
3. 7.3 Any grievance regarding penalty shall be first decided/resolved at JS level and with
final decision of Secretary DPIIT, whose decision shall be final.
3.8 Responsibility for accuracy of project documents
3.8.1 General
3.8 .1.1 The Consulting Agency shall be responsible for accuracy of the estimate and all other
details prepared by him as part of these seNices. He shall indemnify the client against any
inaccuracy in the work, which might surface during implementation of the project.
3.9 Liquidated damages

3.9.1 If the selected Consultant fails to complete the Assignment, within the period specified
under the work order, the Performance Guarantee is liable to be forfeited in full or part in case of
underperformance and undue delays in performance by the agency, besides other action,
including blacklisting of the agency as may be deemed fit by the Client. In case of part forfeiture of
Performance Guarantee and if the agency proceeds to complete the assignment, the
Performance Guarantee will need to be buffered and restored to the original value.
4

Miscellaneous
4.1 Assignment and Charges
4.1.1 The Work order shall not be assigned by the Consulting Agency save and except with prior
consent in writing of the Client, which the Client will be entitled to decline without assigning any
reason whatsoever.
4.1.2 The Client is entitled to assign any rights, interests and obligations under this Work order to
third parties.
4.1.3 Indemnity: The Consulting Agency agrees to indemnify and hold harmless the Client from and
against any and all claims, actions, proceedings , lawsuits, demands, losses, liabilities, damages,
fines or expenses (including interest, penalties, attorneys_ fees and other costs of defence or
investigation (i) related to or arising out of, whether directly or indirectly, (a) the breach by the
Consulting Agency of any obligations specified in relevant clauses hereof; (b) the alleged negligent,
reckless or otherwise wrongful act or omission of the Consulting Agency including professional
negligence or misconduct of any nature whatsoever in relation to Services rendered to the Client; (c)
any SeNices related to or rendered pursuant to the Work order (collectively -Indemnified matter).
As soon as reasonably practicable after the receipt by the Client of a notice of the commencement of
any action by a third party, the Client will notify the Consulting Agency of the commencement thereof;
44

<!-- page 45 -->

provided, however, that the omission so to notify shall not relieve the Consulting Agency from any
liability which it may have to the Client or the third party. The obligations to indemnify and hold
harmless, or to contribute, with respect to losses, claims, actions, damages and liabilities relating to
the Indemnified Matter shall survive until all claims for indemnification and/or contribution asserted
shall survive and until their final resolution thereof. The foregoing provisions are in addition to any
rights which the Client may have at common law, in equity or otherwise.
4.1.4 Notices: Unless otherwise stated, notices to be given under the Work order including but not
limited to a notice of waiver of any term, breach of any term of the Work order and termination of the
Work order, shall be in writing and shall be given by hand delivery, recognized international courier,
mail, telex or facsimile transmission and delivered or transmitted to the Parties at their respective
addresses specified in the SC. The notices shall be deemed to have been made or delivered (i) in
the case of any communication made by letter, when delivered by hand, by recognized international
courier or by mail (registered, return receipt requested) at that address and (ii) in the case of any
communication made by telex or facsimile, when transmitted properly addressed to such telex
number or facsimile number.
4.1.5 Severability: If for any reason whatever any provision of the Work order is or becomes invalid,
illegal or unenforceable or is declared by any court of competent jurisdiction or any other
instrumentality to be invalid, illegal or unenforceable, the validity, legality or enforceability of the
remaining provisions shall not be affected in any manner, and the Parties will negotiate in good faith
with a view to agreeing upon one or more provisions which may be substituted for such invalid,
unenforceable or illegal provisions, as nearly as is practicable. Provided failure to agree upon any
such provisions shall not be subject to dispute resolution under the Work order or otherwise.
4.1.6 Professional Liability Insurance: Consulting Agency will maintain at its expense, Professional
Liability Insurance including coverage for errors and omissions caused by
Consulting Agency's negligence, breach in the performance of its duties under this Work order from
an Insurance Company permitted to offer such policies in India, for a period of one year beyond
completion of Services commencing from the Effective Date, (i) For an amount not exceeding one
time the total payments for Professional Fees made or expected to be made to the Consulting
Agency hereunder or (ii) the proceeds, the Consulting Agency may be entitled to receive from any
insurance maintained by the Consulting Agency to cover such a liability, whichever of (i) or (ii) is
higher with a minimum coverage of [insert amount and currency].

4.1.7
Performance security
4.1.7.1 The Consultant shall prior to the Effective Date and as a condition precedent to its
entitlement to payment under this Work order, provide to the Client a legal, valid and
enforceable Performance Security in the form of an unconditional and irrevocable bank
guarantee as security for the performance by the Consultant of its obligations under this
Work order, in the form set out in this work order, in an amount equal 10 (Ten) percent of the
total cost of Financial Proposal under this Assignment. Further, in the event the term of this
Work order is extended, the Consultant shall at least fifteen (15) days prior to the
commencement of every Subsequent Year or at

least thirty (30) days prior to the date of expiry of the then existing bank guarantee,
whichever is earlier, provide an unconditional and irrevocable bank guarantee as
Performance Security for an amount equivalent to 10 (Ten) percent of the total cost of
Financial Proposal under this Assignment.
4.1.7.2 The Performance Security shall be obtained from a scheduled commercial Indian
bank, in compliance with Applicable Laws (including, in case the Consultant is a nonresident, in compliance with applicable foreign exchange laws and regulations). {In the event
the Consultant is a joint venture consortium, the Performance Security may be provided by

45

<!-- page 46 -->

any Member; provided that such Performance Security shall mention the details of this Work
order and the other Members.}
4.1.7.3 The Performance Security shall be extended accordingly such that the Performance
Security remains valid until the expiry of a period of 60 (Sixty) Days from the date of
completion of the assignment. If the Client shall not have received an extended/ replacement
Performance Security in accordance with this clause at least thirty (30) days prior to the date
of expiry of the then existing Performance Security, the Client shall be entitled to draw the full
amount of the bank guarantee then available for drawing and retain the same by way of
security for the performance by the Consulting Agency of its obligations under this Work
order until such time as the Client shall receive such an extended/ replacement Performance
Security whereupon, subject to the terms of this Work order, the Client will refund to the
Consulting Agency the full amount of the bank guarantee, unless the Client has drawn upon
the Performance Security in accordance with the provisions of this Work order, in which case
only the balance amount remaining will be returned to the Consulting Agency; provided that
the Client will not be liable to pay any interest on such balance. The Client will return the
bank guarantee provided as Performance Security to the issuer thereof for cancellation
promptly upon receipt of any extension/ replacement thereof. Subject to satisfactory
completion of all deliverables under this Work order, the Performance Security will, subject to
any drawdowns by the Client in accordance with the provisions hereof, be released by the
Client within a period of 60 (Sixty) Days from the date of completion of the services.
4.1.8
Penalty
4.1.8.1 Penalty: The selected agency has to provide services as per the requirements of the
RFP. In case the services rendered are not as per the requirement of the Department, the
selected agency will have to come up with a solution within a given timeframe failing which 20%
will be deducted from the amount payable. The other form of penalty not mentioned in the RFP
will be decided by the appropriate authority on case to case basis.
4.1.8.2 Any dispute regarding penalty shall be handled as per dispute settlement provision.

5. The Client shall have the right to claim under the Performance Security and appropriate the

proceeds if any of the following occur:
a. the Consultant becomes liable to pay penalty;
b. occurrence of any of the events listed in sub-clauses (a) through (f) of Clause 3.2.2;
c. any material breach of the terms hereof; and/or
d. without prejudice to paragraph above, the Consultant fails to extend the validity of the
Performance Security or provide a replacement Performance Security in accordance with
the provisions of this Work order.
e. Non-compliance of mutually agreed time lines/time plan
f. For any reasons the project is not completed owing to the faulty delivery/ non-cooperation/
non deliverance by the agency
g. For any reason Contract is terminated by agency

*All conditions of RFP shall be considered to be integral part of this work order.

46

<!-- page 47 -->

Annexure A: Form of Bank Guarantee for Performance Security

(To be stamped in accordance with Stamp Act if any, of the country for issuing bank) Ref.:
Bank Guarantee:
Date:
Sir,
In consideration of Department for Promotion of Industry and Internal Trade, Ministry of Commerce and
Industry, Government of India (hereinafter referred as the _Client_, which expression shall, unless
repugnant to the context of meaning thereof include its successors, administrators and assigns) having
awarded to M/s [name of Consulting Agency] a [type of company], established under laws of [country] and
having its registered office at [address] (hereinafter referred to as the _Consulting Agency which expression
shall unless repugnant to the context or meaning thereof, include its successors, administrators, executors
and permitted assigns), an Assignment for preparation of [name of assignment] Work order by issue of
Client's Work order Letter of Award No. [reference] dated [date] and the same having been unequivocally
accepted by the Consulting Agency, resulting in a Work order valued at Rs. [amount in figures and words]
for (Scope of Work) (hereinafter called the _Work order_) and the Consulting Agency having agreed to
furnish a Bank Guarantee amounting to Rs. [amount in figures and words] to the Client for performance of
the said Agreement.
We [Name of Bank] incorporated under [law and country] having its Head Office at [address](hereinafter
referred to as the Bank), which expression shall, unless repugnant to the context or meaning thereof,
include its successors, administrators executors and assigns) do hereby guarantee and undertake to pay
the Client immediately on demand an or, all monies payable by the Consulting Agency to the extent of Rs.
[amount in figure and words] as aforesaid at any time up to [date] without any demur, reservation, contest,
recourse or protest and/ or without any reference to the Consulting Agency. Any such demand made by the
Client on the Bank shall be conclusive and binding notwithstanding any difference between the Client and
the Consulting Agency or any dispute pending before any Court, Tribunal, Arbitrator or any other authority.
We agree that the Guarantee herein contained shall be irrevocable and shall continue to be enforceable
until the Client discharges this guarantee.
The Client shall have the fullest liberty without affecting in any way the liability of the Bank under this
Guarantee, from time to time to vary the advance or to extend the time for performance of the Work order
by the Consulting Agency nor shall the responsibility of the bank be affected by any variations in the terms
and conditions of the work order or other documents. The Client shall have the fullest liberty without
affecting this guarantee, to postpone from time to time the exercise of any powers vested in them or of any
right which they might have against the Client and to exercise the same at any time in any manner, and
either to enforce or to forbear to enforce any covenants, contained or implied, in the Work order between
the Client and the Consulting Agency any other course or remedy or security available to the client. The
Bank shall not be relieved of its obligations under these presents by any exercise by the Client of its liberty
with reference to the matters aforesaid or any of them or by reason of any other act or forbearance or other
acts of omission or commission on the part of the Client or any other indulgence shown by the Client or by
any other matter or thing whatsoever which under law would but for this provision have the effect of
relieving the Bank.
The Bank also agrees that the Client at its option shall be entitled to enforce this Guarantee against the
Bank as a principal debtor, in the first instance without proceeding against the Consulting Agency and
notwithstanding any security or other guarantee that the client may have in relation to the Consulting
Agencies liabilities.
This Guarantee shall be irrevocable and shall remain in full force and effect until discharge by the Bank of
all its obligations hereunder.

47

<!-- page 48 -->

This Guarantee shall not be affected by any change in the constitution or winding up of the Consulting
Agency/the Bank or any absorption, merger or amalgamation of the Consulting Agency/the bank with any
other Person.
Notwithstanding anything contained herein above our liability under this guarantee is limited to Rs. [amount
in figure and words] and it shall remain in force up to and including [date] and shall extend from time to time
for such period(s) {not exceeding one year), as may be desired by M/s [name of Consulting Agency] on
whose behalf this guarantee has been given. Date this [date in words] day [month] of [year in _yyyy_
format] at [place].
WITNESS

1. [signature, name and address]
2. [signature, name and address]

[Official Address]

Designation

[With Bank Stamp]

Attorney as Per Power of Attorney No.
Dated
Strike out, whichever is not applicable.
The date will be fixed as indicated in S.C.C.
The stamp papers of appropriate value shall be purchased in the name of bank which issues the
be
issued
either
by a
"Bank Guarantee". The
bank guarantee shall

bank

(Nationalized/Scheduled) located in India or a foreign bank through a correspondent bank (scheduled)
located in India or directly by a foreign bank which has been determined in advance to be acceptable to the
Client.

48
