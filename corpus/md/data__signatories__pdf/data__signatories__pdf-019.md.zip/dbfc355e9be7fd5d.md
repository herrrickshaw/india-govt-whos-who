---
doc_id: "dbfc355e9be7fd5d"
source_url: "https://dof.gov.in/static/uploads/2025/09/99ad8403e884b3dc96d241d79dad680d.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Recruitment Rules for the Post of FDC ,2023"
date: "2023-05-09"
pages: 5
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7981e44a4c2ccb88"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-11052023-245821
xxxGIDHxxx
CG-DL-E-11052023-245821
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 286]
No. 286]

नई दिल्ली, बृहस्ट्पजतिार, मई 11, 2023/िैिाख 21, 1945
NEW DELHI, THURSDAY, MAY 11, 2023/VAISAKHA 21, 1945

मत्सस्ट्यपालन, पिुपालन और डेयरी मंत्रालय
(मत्सस्ट्यपालन जिभाग)
अजधसूचना
नई दिल्ली, 9 मई, 2023
सा.का.जन. 358(अ).—राष्ट्रपजत, संजिधान के अनुच्छेि 309 के परन्तुक द्वारा प्रित्त िजियों का प्रयोग करते हुए
और पिुपालन, डेयरी और मत्सस्ट्यपालन जिभाग, माजत्सस्ट्यकी जिकास आयुि समूह 'क' पि भती जनयम, 2017 को, उन बातों
के जसिाए अजधक्ांत करते हुए, जिन्हें ऐसे अजधक्मण से पूिव दकया गया है या करने का लोप दकया गया है, मत्सस्ट्यपालन,
पिुपालन और डेयरी मंत्रालय, मत्सस्ट्यपालन जिभाग में माजत्सस्ट्यकी जिकास आयुि के पि पर भती की पद्धजत का जिजनयमन
करने के जलए जनम्नजलजखत जनयम बनातें हैं, अर्ावत:् 1.संजिप्त नाम और प्रारं भ:-(1) इन जनयमों का संजिप्त नाम मत्सस्ट्यपालन जिभाग, माजत्सस्ट्यकी जिकास आयुि (समूह 'क' पि )
भती जनयम, 2023 है।
(2) ये रािपत्र में उनके प्रकािन की तारीख को प्रिृत्त होंगे।
2. पि की संख्या, िगीकरण और िेतन मैट्ररक्स में स्ट्तर:-उि पि की संख्या, उसका िगीकरण और इससे संलग्न िेतन
मैट्ररक्स में स्ट्तर िह होगा, िो इन जनयमों से उपाबद्ध अनुसूची के स्ट्तंभ (2) सेस्ट्तंभ (4) में जिजनर्िवष्ट हैं।
3076 GI/2023

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

3. भती की पद्धजत, आयु-सीमा और अन्य अहवताएं आदि- उि पि के जलए भती की पद्धजत, आयु-सीमा, अहवताएं
औरसंबंजधत अन्य बातें िे होंगी िो उि अनुसूची के स्ट्तंभ (5) सेस्ट्तंभ (13) में जिजनर्िवष्ट हैं।
4. जनरहवता- िहव्यजि(क) जिसने ऐसे व्यजि से जिसका पजत या जिसकी पत्नी िीजित है, जििाह दकया हैया जििाह की संजििा की है; या
(ख) जिसने, अपने पजत या अपनी पत्नी के िीजित रहते हुए दकसी व्यजि से जििाह दकया है या संजििा की है,
उि पि पर जनयुजि का पात्र नहीं होगा;
परन्तु यदि के न्रीय सरकार का यह समाधान हो िाता है दक ऐसा जििाह ऐसे व्यजि और जििाह के अन्य पिकार
को लागू स्ट्िीय जिजध के अधीन अनुज्ञेय है और ऐसा करने के जलए अन्य आधार हैं तो िह दकसी व्यजि को इस जनयम के
प्रितवन से छू ट िे सके गी।
5. जिजर्ल करने की िजि–िहां के न्रीय सरकार की यह राय है दक ऐसा करना आिश्यक या समीचीन है, िहां िह उसके
जलए िो कारण है, उन्हें लेखबद्ध करके और संघ लोक सेिा आयोग से परामिव करके इन जनयमों के दकसी उपबंध को दकसी
िगव या प्रिगव के व्यजियों की बाबत, आिेि द्वारा जिजर्ल कर सके गी।
6. व्यािृजत्त –इन जनयमों की कोई बात, ऐसे आरिण, आयु-सीमा में छू ट और अन्य ट्ररयायतों पर प्रभाि नहीं डालेगी,
जिनका के न्रीय सरकार द्वारा इस संबंध में समय-समय पर िारी दकए गए आिेिों के अनुसार अनुसूजचत िाजतयों,
अनुसूजचत िनिाजतयों, अन्य जपछडे िगों, भूतपूिव सैजनकों और अन्य जििेष प्रिगव के व्यजियों के जलए उपबंध करना
अपेजित है।
अनुसच
ू ी
पि की संख्या

पि का नाम.

िगीकरण

िेतन मैट्ररक्स में स्ट्तर चयन अर्िा अचयन सीधे भती दकए िाने
िाले व्यजियों के जलए
पि
आयु-सीमा

(1)

(2)

(3)

माजत्सस्ट्यकी जिकास
आयुि

01 (2023)

साधारण के न्रीय

स्ट्तर -13

कायवभार के आधार
पर पट्ररितवन दकया
िा सकता है।

सेिा, समूह “क”,

(123100-

रािपजत्रत,गैर -

215900 रुपये)

सीधे भती दकए िाने िाले
व्यजियों के जलए अपेजित
िैजिक और अन्य अहवताएं

(4)

अनुसजचिीय

सीधे भती दकए िाने िाले
व्यजियों के जलए जिजहत आयु
और

िैिजणक

अहवताएँ,

(5)

(8)
लागू नहीं होता

कोई हो

लागू नहीं होता

भती की पद्धजतिः भती सीधी
होगी या पिोन्नजत या
प्रजतजनयुजि/

आमेलन

द्वारा

तर्ा जिजभन्नपद्धजतयों द्वारा
भरी िाने िाली ट्ररजियों की
प्रजतितता।
(9)

लागू नहीं होता

चयन

पट्ररिीिा की अिजध, यदि

पिोन्नत व्यजियों की ििा में
लागू होगी या नहीं
(7)

(6)

(10)
लागू नहीं होता

प्रोन्नजतद्वारा जिसके न हो
सकने पर प्रजतजनयुजि द्वारा
जिसके अन्तगवत अप्लकाजलक
संजििा भी है।

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

प्रोन्नजत या प्रजतजनयुजि/आमेलन द्वारा भती की ििा में िे श्रेजणयां जिनसे प्रोन्नजत या प्रजतजनयुजि/आमेलन दकया िाएगा
(11)
प्रजतजनयुजि:
कें रीय सरकार या राज्य सरकारों या संघ राज्य िेत्रों या कानूनी संगठनों या स्ट्िायत्त संगठनों या सािविजनक िेत्र के उपक्मों या
मान्यताप्राप्त जिश्वजिद्यालयों या मान्यता प्राप्त अनुसध
ं ान संस्ट्र्ानों के अजधकारी िो:
(क) (i) मूल काडर या जिभाग में जनयजमत आधार पर सिृि पि धारण दकए हुए हैं ,
या
(ii) जिन्होंने मूल काडर या जिभाग में िेतन मैट्ररक्स स्ट्तर-12 (78800-209200 रुपये) में जनयजमत आधार पर जनयुजि के पश्चात
उस श्रेणी में पांच िषव कीजनयजमत सेिा की हो, और
(ख) जनम्नजलजखत िैजिक अहवता और अनुभि रखते हैिःअजनिायव:
(i)

माजत्सस्ट्यकी में जििेषज्ञता के सार् प्राणी जिज्ञान में स्नातकोत्तर या दकसी मान्यता प्राप्त जिश्वजिद्यालय से माजत्सस्ट्यकी या
समुरी िीि जिज्ञान में स्नातकोत्तर या के न्रीय माजत्सस्ट्यकी जििा संस्ट्र्ान, मुंबई से जडप्लोमा;

(ii)

माजत्सस्ट्यकी जिकास, समुरी या अंतिेिीय या िोनों के िेत्र में िस िषव का अनुभि।

ट्रटप्पण-1: पोषक प्रिगव श्रेणी के ऐसे जिभागीय अजधकारी, िो प्रोन्नजत की सीधी पंजि में हैं, प्रजतजनयुजि पर जनयुजि के जलए
जिचार दकए िाने के पात्र नहीं होंगे। इसी प्रकार प्रजतजनयुि व्यजि प्रोन्नजत द्वारा जनयुजि के जलए जिचार दकए िाने के पात्र नहीं
होंगे।
ट्रटप्पण -2: प्रजतजनयुजि की अिजध (अल्पकाजलक संजििा सजहत) जिसके अंतगवत कें रीय सरकार संिगव के उसी या दकसी अन्य
संगठन या जिभाग में इस जनयुजि से ठीक पहले धाट्ररत दकसी अन्य बाह्य- पि पर प्रजतजनयुजि की अिजध िाजमल है, प्रजतजनयुजि
की अिजध सामान्यत: पांच िषव से अजधक नहीं होगी।
ट्रटप्पण -3: प्रजतजनयुजि (अल्पकाजलक संजििा सजहत) द्वारा जनयुजि के जलए अजधकतम आयु-सीमा आिेिन प्राप्त करने की अंजतम
तारीख को 56 िषव से अजधक नहीं होगी।
प्रोन्नजत:
िेतन मैट्ररक्स के स्ट्तर -12 (78800-209200 रूपये) में उपायुि (माजत्सस्ट्यकी)ग्रेड में पांच साल की जनयजमत सेिा ।
ट्रटप्पण 1: िहां ऐसे कजनष्ठ व्यजियों के संबंध में , जिन्होंने अपनी अहवक या पात्रता सेिा पूरी कर ली हो, प्रोन्नजत के जलए जिचार
दकया िा रहा हो, िहां उनसे ज्येष्ठ व्यजियों के संबंध में भी जिचार दकया िाएगा परन्तु यह तब िबदक उनके द्वारा की गई ऐसी
अहवक या पात्रता सेिा के आधे से अजधक से या िो िषव से, इनमें से िो भी कम हो, और उन्होंने अपने ऐसे कजनष्ठ व्यजियों सजहत
जिन्होंने ऐसी अहवक या पात्रता सेिा पहले ही पूरी कर ली है अगली उच्चतर श्रेणी में प्रोन्नजत के जलए, अपनी पट्ररिीिा की अिजध
सफलतापूिवक पूरी कर ली हो।

भती करने में दकन पट्ररजस्ट्र्जतयों में संघ लोक सेिा
आयोग से परामिव दकया िाएगा।

यदि जिभागीय प्रोन्नजत सजमजत है, तो उसकी संरचना।
(12)
1.

संघ लोक सेिा आयोग के अध्यि या
सिस्ट्य,

2.

- अध्यि

संयुि सजचि (प्रिासन),
मत्सस्ट्यपालन जिभाग

3.

(13)
प्रजतजनयुजि (अल्पकाजलक संजििा सजहत) आधार
पर एक अजधकारी की जनयुजि के जलए संघ लोक
सेिा आयोग के सार् परामिव आिश्यक है।

- सिस्ट्य

संयुि सजचि (माजत्सस्ट्यकी),
मत्सस्ट्यपालन जिभाग

- सिस्ट्य

[फा. सं. ए–12018/1/2020-प्रिासन-I]
सागर मेहरा, संयक्
ु त सजचि

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

MINISTRY OF FISHERIES, ANIMAL HUSBANDRY AND DAIRYING
(Department of Fisheries)
NOTIFICATION
New Delhi, the 9th May, 2023
G.S.R. 358(E) .—In exercise of the powers conferred by proviso to article 309 of the Constitution, and in
supersession of the Department of Animal Husbandry, Dairying and Fisheries, Fisheries Development Commissioner,
Group ‘A’ Recruitment Rules, 2017, except as respects things done or omitted to be done before such supersession,
the President hereby makes the following rules regulating the method of recruitment to the post of Fisheries
Development Commissioner in the Ministry of Fisheries, Animal Husbandry and Dairying, Department of Fisheries,
namely: 1.
Short title and commencement.- (1) These rules may be called the Department of Fisheries, Fisheries
Development Commissioner (Group ‘A’ post), Recruitment Rules, 2023.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. Number of post, classification and level in pay matrix. - The number of post, its classification and the level in
the pay matrix attached thereto shall be as specified in columns (2) to (4) of the Schedule annexed to these rules.
3.
Method of recruitment, age-limit, other qualifications, etc.– The method of recruitment, age-limit,
qualifications and other matters relating to the said post shall be as specified in columns (5) to (13) of the said
Schedule.
4.

Disqualification. – No person, (a) who has entered into or contracted a marriage with the person having a spouse living, or
(b) who, having a spouse living, has entered into or contracted a marriage with any other person,

shall be eligible for appointment to the said post;
Provided that the Central Government may, if satisfied that such marriage is permissible under the personal
law applicable to such person and the other party to the marriage and that there are other grounds for so doing,
exempt any person from the operation of this rule.
5. Power to Relax.– Where the Central Government is of the opinion that it is necessary or expedient so to do, it
may, by order and for reasons to be recorded in writing and in consultation with the Union Public Service
Commission, relax any of the provisions of these rules with respect to any class or category of persons.
6. Saving.– Nothing in these rules shall affect reservations, relaxation of age-limit and other concessions required to
be provided for the Scheduled Castes, the Scheduled Tribes, ex-servicemen, Other Backward Classes and other special
categories of persons in accordance with the orders issued by the Central Government from time to time in this regard.
SCHEDULE
Name of
Post

Number
of post

Classification

level in
pay matrix

(1)
Fisheries
Development
Commissioner.

(2)
01
(2023)
Subject to
variation
dependent
on workload.

(3)
General Central
Service,
Group “A”,
Gazetted,
NonMinisterial.

(4)
level
13 (Rs.123100215900).

Educational and
other qualification
required for direct
recruits.

Whether age and
educational qualification
prescribed for direct
recruits will apply in the
case of promotees.
(8)
Not applicable

(7)
Not applicable

Period of
probation,
if any.

(9)
Not
applicable

Whether
selection
post or nonselection
post
(5)
Selection.

Age-limit for
direct recruits

(6)
Not
applicable.

Method of recruitment: whether by direct
recruitment or by promotion or by
deputation/ absorption and percentage of
the vacancies to be filled by various
methods.
(10)
Promotion failing which by Deputation
including short-term contract

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

5

In case of recruitment by promotion or deputation/absorption, grades from which promotion or deputation or
absorption to be made.
(11)
Deputation:
Officers under the Central Government or State Governments or Union territory Administration or Statutory
organisations or autonomous organisations or public sector undertakings or recognized universities or recognised
research institutes:
(a)
(i) holding analogous post on regular basis in the parent cadre or Department; OR
(ii) with five years' regular service in the grade rendered after appointment thereto on a regular basis in
level 12 (Rs.78800-209200) in the pay matrix or equivalent in the parent cadre or Department; and
(b) possessing the following educational qualifications and experience.
Essential:(i)
Masters Degree in Zoology with specialisation in fisheries or Masters Degree in Fisheries or Marine
Biology from a recognised University or Diploma from the Central Institute of Fisheries Education,
Bombay;
(ii)
Ten years' experience in the field of fisheries development, marine or inland or both.
Note-1: The departmental officers in the feeder category who are in the direct line of promotion shall not be
eligible for consideration for appointment on deputation. Similarly, deputationists shall not be eligible for
consideration for appointment by promotion.
Note-2: The period of deputation (including short term contract) including period of deputation in another excadre post held immediately preceding this appointment in the same or some other organisation or department of
the Central Government shall not ordinarily exceed five years.
Note-3: The maximum age-limit for appointment by deputation (including short-term contract) shall be not
exceeding fifty-six years as on the closing date of receipt of applications.
Promotion:
Deputy Commissioner (Fisheries) in level 12 (Rs.78800-209200/-) of pay matrix with five years of regular service
in the grade.
Note 1: Where juniors who have completed their qualifying or eligibility service are being considered for
promotion, their seniors would also be considered provided they are not short of the requisite or qualifying or
eligibility service by more than half of such qualifying or eligibility service, or two years, whichever is less, and
have successfully completed probation period for promotion to the next higher grade along with their juniors who
have already completed such qualifying or eligibility service.

If a Departmental Promotion Committee exists, what is its composition
(12)
1.
2.
3.

Chairman or Member, Union Public
Service Commission
Joint Secretary (Administration),
Department of Fisheries
Joint Secretary (Fisheries),
Department of Fisheries

Circumstances in which Union
Public Service Commission to be
consulted in making recruitment.
(13)

– Chairman
– Member

Consultation with Union Public
Service Commission is necessary
for appointing an officer on
deputation (including short term
contract) basis.

- Member
[F. No. A-12018/1/2020-Admn.I]
SAGAR MEHRA, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2023.05.11 19:44:28
+05'30'
