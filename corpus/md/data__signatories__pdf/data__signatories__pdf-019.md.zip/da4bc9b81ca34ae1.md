---
doc_id: "da4bc9b81ca34ae1"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/d1572c28287067323f26c4a01f64f277.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Inspection of registered design under section 17(1)"
date: "2025-06-30"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8a4508033973909e"
---

<!-- page 1 -->

FORM 5

Request for inspection under section 17(1)

Fee Rs. 500
1

Insert name and address I (or We)1 ___________________________________________
and nationality

2

Insert the number and
class of the Design.

hereby request to inspect the Design No.2________________
in Class _________________________ as I/We am/are entitled
under section 17(1) of the Design Act 2000.

Address for service in India is :Dated this ________________ day___________________ 2000
3

To be signed by the
applicant or authorised
agent.

(Signed)3_______________ ________________________

TO
THE CONTROLLER OF DESIGNS
THE PATENT OFFICE, CALCUTTA.
