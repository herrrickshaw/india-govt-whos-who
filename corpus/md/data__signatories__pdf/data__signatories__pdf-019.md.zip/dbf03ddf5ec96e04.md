---
doc_id: "dbf03ddf5ec96e04"
source_url: "https://www.dsir.gov.in/static/uploads/2025/11/10bd35ff3ba8fdb4fec347b9c7dbc305.pdf"
ministry: "Department of Scientific and Industrial Research (DSIR)"
title: "Innovation Studies Report - Capital Goods - Regulatory & Policy Benchmarking"
date: "2013-03-01"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c85d3eee0de10042"
---

<!-- page 1 -->

Capital Goods: Regulatory & Policy Benchmarking
The capital goods industry has witnessed increased competition in the present scenario of high
globalisation. Western countries like Germany and Italy have been leaders in this technology oriented
sector for a long time but over the last few decades, China has emerged as a strong competitor on the
back of its low manufacturing costs and supportive government policies. The capital goods sector in
India has not succeeded in building competitiveness primarily due to structural disadvantages,
inadequate support mechanism and firm level inefficiencies. A comparative assessment of Indian capital
goods sector vis-à-vis that of competing countries has been done hereunder to facilitate formulation of
suitable policies and strategies for improving competitiveness of Indian players in the global market.
Privatisation of capital goods sector in major countries has improved competitiveness
The capital goods industry in India is largely dominated by public sector enterprises, which has to a large
extent affected the development of this sector. In terms of overall output as well, PSEs dominate the
market and even though their market share has dipped over the last decade, they command a large
market share due to preferential purchase policies of the government. India can take a cue from China,
which too was largely dominated by SOEs until late 1970s but the economic reforms during 1980s and
1990s that included privatisation drive and labour reforms has improved the industrial performance,
efficiency and overall competitiveness of the sector and today, China is one of the leading global
suppliers of capital goods.
Another disadvantage for the Indian capital goods sector emanating from the industry structure is that
the sector includes a wide range of products but lacks depth due to low demand sophistication of Indian
market, which in turn leads to low competitiveness of its products in the global market. On the other
hand, major advanced countries generally do not produce entire range of products rather focus on select
segments where they are most competitive.
Strong government focus imminent for development of capital goods sector
China has maintained a strong focus on development of capital goods sector and its government has
constantly supported the industry by providing policy impetus as well as implementing expedient
measures with respect to taxation, subsidies and financial support during the times of economic crisis.
Better investment climate in competing countries gives them a competitive edge
Leading countries in capital goods manufacturing have maintained a healthy investment climate that has
helped them in attracting substantial foreign capital required for effective development of the capital
intensive industries. China has been amongst the most favoured nations for investments on account of
low labour costs, large domestic market, preferential policies for foreign investments, export promotion
policies and stable political climate. Germany‟s investment climate is also highly lucrative for
manufacturing businesses, owing to the various incentives offered by the government, existence of sound
and secure legal framework, open and transparent markets, strong infrastructure, reliable logistics,
internationally competitive tax conditions and financial support from the government.
In contrast, India has not been able to attract huge FDI despite liberal investment policies and low labour
costs, primarily due to poor physical infrastructure that affects the supply chain and hence adds to the

32

<!-- page 2 -->

costs. According to industry estimates, infrastructure inadequacies translate into 5 per cent cost
disadvantage for Indian capital goods manufacturers vis-à-vis foreign manufacturers.
State subsidies and incentives have played a key role in sector’s development
Industry players in China enjoy various subsidies and incentives such as cash grants, interest subsidies,
debt forgiveness, extension of non-performing loans, energy subsidies, land subsidies, etc. Moreover, the
Chinese government has often negotiated technology transfer from foreign enterprises in exchange for
providing access to government projects.
Similarly, in Italy various subsidies are being provided under the National incentives plan to the eligible
enterprises including Capital grants, operating grants, interest rate subsidies, tax credits, equity
participation and guarantees.
In India, the benefit of interest subsidies available to many sectors is not available to the capital goods
sector, rendering them uncompetitive against their counterparts in other countries which are heavily
subsidised. The cost burden is further aggravated by the high incidence of direct and indirect taxes.
According to industry estimates, the cost disadvantage to Indian capital goods manufacturers due to
indirect taxes is estimated at nearly 24%.
Additionally, India allows second hand imports of capital goods at concessional rates for various sectors,
which has deterred the growth of domestic capital goods industry. Consequently, the capital goods
industry is losing its competitiveness to the cheap imports.
Besides lack of subsidies, the Indian capital goods industry also does not receive adequate export
incentives due to which its export competitiveness is low. For instance, export promotion schemes of the
government are not easily available for project exports and interest rate subvention provided earlier to
the capital goods sector has been discontinued. Lack of export incentives lowers the competitiveness of
the industry, which already suffers from high export transaction costs.

33
