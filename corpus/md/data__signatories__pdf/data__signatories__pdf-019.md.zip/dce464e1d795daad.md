---
doc_id: "dce464e1d795daad"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/5e74f708916261eaee6ab2f63ef7c647.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Clarification regarding panel for Allahabad HC made in the year 2015: Order dated 16.04.2019"
date: "2019-04-16"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "12e03f520ae204a3"
---

<!-- page 1 -->

No.J-11017/3/2019-Judicial
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
tee
Shastri Bhawan, New Delhi,
Dated \G*> April, 2019
ORDER
With reference to this Department's Order No. J-11017/3/2019-Judicial dated
07.03.2019 regarding engagement of some Advocates for various Courts / Tribunals in the
state of Uttar Pradesh, it is stated that the aforesaid order dated 07.03.2019 has been issued in
addition to the earlier Orders No. 36(1)/2015-Judl. dated 09.04.2015 read with Order No
J-11017/20/2017-Judicial dated 09.04.2018 and not in supersession of these two orders. The
aforesaid orders dated 09.04.2015 & dated 09.04.2018 still exist.
2 Hindi version of this order will follow.
Srv
we —
(S. R. Mishra)
Additional Secretary
Copy for information to:- |

1. PS to MLJ/PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary/All Additional
Secretaries/PS to all JS&LA in the Main Sectt.

2. Shri Shashi Prakash Singh, Additional Solicitor General of India, Allahabad High Court, Savitri
Nilayam, 2/22, Triveni Nagar, Kunwar Chandra Prakash Marg, Lucknow-226020 w.r.t. his letter
dated 12.03.2019.

3. Shri Gyan Prakash, Asstt. SGI, Allahabad High Court, Allahabad

4. Shri Surya Bhan Pandey, Asst. SGI, Allahabad High Court, Lucknow Bench.

5. Sr. CGSCs for CAT, Allahabad Bench and CAT, Lucknow Bench

6. To upload on the website of this Department i.e. www. legalaffairs.gov.in in the tab ‘Judicial Section’
under the link ‘List of empanelled counsel’

7. Hindi unit, Department of Legal Affairs for Hindi translation of the order.

8. Guard File/Judicial Section with 5 spare copies.

(D. Srinivas

Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
