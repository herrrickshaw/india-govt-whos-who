---
doc_id: "da2fd15ec6d0f66c"
source_url: "https://www.texmin.gov.in/static/uploads/2025/06/00367aa00f8692c12672a772ea552049.pdf"
ministry: "Textiles (MoT)"
title: "Nomination of Liaison Officer for Welfare of EWS employees"
date: "2024-03-11"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e579512012cfc3c8"
---

<!-- page 1 -->

F.No, A-420 11/9/2013-Estt
Government of India
Ministry of Textiles
++++

Udyog Bhwan, New Delhi
\\ h M-''}=’ 2024
OFFICE MEMORANDUM
Subject: Nomination of Liaison Officer for EWS.

The undersigned is directed to refer to DON’s OM No. No.DOPF16704945 149 12

dated

08. 12.2022

on

the

above

cited subject and to say that Sh. Ravi Shankar Shukla, Director (Admn)
has been nominated as Liaison Officer for EWS in this Ministry. The
contact details of above mentioned officer are given below:
Sh. Ravi Shankar Shukla
Director (Admn)
Room No. 235,
Udyog Bhawan, New Delhi- 1 IOO 11
Tel: OI1-23062163

-R\\"

(JayastVree Sivakumar)

Under Secretary to the Govt. of India
To,

1. Officer concerned
2. An Attached/Subordinate Offices/PSUs/Boards etc under the
Ministry of Textiles.
3. Deputy Secretary, Establishment (Reservation-I) Section, DoPF,
North Block, New Delhi
