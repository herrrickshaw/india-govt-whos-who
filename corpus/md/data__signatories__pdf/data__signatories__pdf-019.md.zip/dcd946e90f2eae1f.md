---
doc_id: "dcd946e90f2eae1f"
source_url: "https://doj.gov.in/static/uploads/2025/12/737c2fbbc6b7256ad80c3458cea6277b.pdf"
ministry: "Department of Justice (DoJ)"
title: "Gujarat National Law University, Gandhinagar"
date: "2021-03-17"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c803023b6ac2340e"
---

<!-- page 1 -->

F. No.N-9/35/2018-NM
Government of India
Ministry of Law and Justice
(Department of Justice)
Serre
Jaisalmer House, 26, Mansingh Road,
New Delhi-110011
Dated: 03 July, 2019
SANCTION ORDER
Sanction of the Competent Authority is hereby accorded to the payment of Rs. 10,000/- (Rupees Ten
Thousand Only) to Gujarat National Law University, Gandhinagar towards Second & Final Instalment out of
total project cost of Rs. 1, 60,000/- (Rupees One Lakh Sixty Thousand Only) (non-recurring expenditure) for
under taking a project for holding one day “National Conference on Backlog of Cases and Court Management”
as submitted by Gujarat National Law University, Gandhinagar vide letter dated 10.10.2018 under the “Scheme
of Action Research and Studies on Judicial Reforms’ .First instalment of Rs.1,50,000/- was released to Gujarat
National Law University, Gandhinagar, the implementing Agency vide this Department's sanction order of even
no. dated 29" November, 2018
2. The expenditure involved is debitable to Demand No. 61 during 2019-20 (Plan) under MH 2014-
é Administration of justice, 17-National Mission for Justice Delivery and Legal Reforms, 17.02-Action Research
and Studies on Judicial Reforms, 17.02.28-Professional Services.
3. This has been entered in the Register of Grants/Expenditure at SI. No. 2 at page No. 145-146.
4. This issues with the concurrence of IFD [Law] vide AS & FA Note No. 42 dated 25.06.2019 and approval of
Secretary (J) vide Note No. 44 dated 1.7.2019 in Efile/Computer No.4351
> pedo
_———
(Z.A.Khan)
Under Secretary to the Government of India
Telefax: 23072139
To,
Pay & Accounts Officer, $
Ministry of Law & justice, Department of Legal Affairs,
Janpath Bhawan, Janpath,
New Delhi
Copy to:-

1. Cash-I Section, Department of Justice, New Delhi with one spare copy and a copy of Agreement. It is
requested that the payment may be made through e-payment to Gujarat National Law University,
Gandhinagar.

2. Under Secretary (Admin-ll), Department of Justice, Jaisalmer House, New Delhi.

3. IFD/Budget Division, Ministry of Law and Justice, Legislative Department, Shastri Bhawan, New Delhi

(4८४०, Jaisalmer House, New Delhi for uploading on the Department of Justice website.

5. Gujarat National Law University, (Kind Attn: Prof. (Dr.) Bimal N. Patel, Director),
knowledge Corridor, Koba, Gandhinagar-382426-Gujarat.

6. Under Secretary ( Admin. 1), Department of Justice, Jaisalmer House, New Delhi

7. Principal Accounts Office, 4" Floor, Ministry of Law and Justice, Lok Nayak Bhawan, Khan Market,

New Delhi
8. Guard File
9. Spare Copies-5
