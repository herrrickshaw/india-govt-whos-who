---
doc_id: "dca9ec0392eaeaa5"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/2603e4be63e1c30c69389cc2908a2c68.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Group A Amendment"
date: "2017-12-07"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9c18b422850d2159"
---

<!-- page 1 -->

MINISTRY OF HEAVY INDUSTRIES AND PUBLIC ENTERPRISES
(Department of Public Enterprises)

NOTIFICATION
New Delhi, the 7th December, 2017

G.S.R. 1499(E).-In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules to amend the Ministry of Heavy Industries and Public Enterprises,
Department of Public Enterprises, Group A posts Recruitment Rules, 2014, namely:1. (1) These rules may be called the Ministry of Heavy Industries and Public Enterprises, Department of Public
Enterprises, Group 'A' posts Recruitment (Amendment) Rules, 2017.
(2) They shall come into force on the date-of their publication in the Official Gazette.
2. In the Ministry of Heavy Industries and Public Enterprises, Department of Public Enterprises, Group A posts
Recruitment Rules, 2014,(a) for rule 3, the following rule shall be substituted, namely:"3. Number of posts, classification, Level in the Pay Matrix.• The number of the said posts, their classification
and the Level in the Pay Matrix attached thereto shall be as specified in columns (2) to (4) of the said
Schedule". ;
(b) in the Schedule, (i) against serial number I, relating to the post of Arbitrator,(i) in column (4), for the col umn heading and the entries relating thereto, the following column heading and
entries shall be substituted, namely :"Level in the Pay Matrix

(4)
Level 14
(Rs. 144200-218200)"

<!-- page 2 -->

4

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART II-SEC. 3(i)]

(ii) in column ( 11 ), under the sub-heading "Deputation (including short-term contract)", in item (a),(a) in sub-item (ii), for the entry "Pay Band-4, Rs. 37400-67000 with grade pay of Rs. 8700/-", the entry
"Level 13 in the Pay Matrix (Rs. 118500-214100)" shall be substituted;
(b) in sub-item (i ii), for the entry, "Pay Band-3, Rs. 15600-39 100 with grade pay of Rs. 7600/-", the entry
"Level 12 in the Pay Matrix (Rs. 78800-209200)" shall be substituted;
(ii) against serial number 2, relating to the post of Joint Adviser,(i) in column (4), for the column heading and the entries relating thereto, the following column heading and
entries shall be substituted, namely :"Level in the Pay Matrix
(4)

Level 13
(Rs. 123 100-215900)"

(i i) in column (11), under the sub-heading "Deputation (including short-term contract)", in item (a), in subitem (ii), for the entry "Pay Band-4, Rs. 15600-39100 with grade pay of Rs. 7600/-", the entry "Level 12 in
the Pay Matrix (Rs. 78800-209200)" shall be substituted;
(iii) against serial number 3, relating to the post of Joint Director,(i) in column (4), for the column heading and the entries relating thereto, the following column heading and
entries shall be substituted, namely :"Level in the Pay Matrix

(4)
Level 12
(Rs. 78800-209200)"

(ii) in column (11 ), under the sub-heading "Promotion", in item (a), in sub-item (ii), for the entry "Pay Band-3,
Rs. 15600-39100 with grade pay of Rs. 6600/-", the entry "Level 11 in the Pay Matrix (Rs. 67700-208700)"
shall be substituted;
(iv) against serial number 4, relating to the post of Deputy Director,(i) in column (4), for the column heading and the entries relating thereto, the following column heading and

entries shall be substituted, namely :"Level in the Pay Matrix
(4)

Level 11
(Rs. 67700-208700)"
(ii) in column ( 11), in the sub-heading "Promotion" in item (a),-

(a) in sub-item (ii) for the entry "Pay Band-2, Rs. 9300-34800 with grade pay of Rs. 5400/-", the entry "Level
9 in the Pay Matrix (Rs. 53 100- 167800)" shall be substituted;
(b) in sub-item (i ii), for the entry "Pay Band-2, Rs. 9300-34800 with grade pay of Rs. 4200/-", the entry
"Level 6 in the Pay Matrix (Rs. 35400-112400)" shall be substituted;
(v) against serial number 5, relating to the post of Assistant Director,(i) in column (4), for the column heading and the entries relating thereto, the following colu mn heading and
entries shall be substituted, namely :-

"Level in the Pay Matrix

(4)
Level 10
(Rs. 56100-177500)"

<!-- page 3 -->

5

'ITI«f cf>T ~ : arm~

(ii) in column (11 ), in sub-heading "Promotion" in item (a),-

(a) in sub-item (ii), for the entry "Pay Band-2, Rs. 9300-34800 with grade pay of Rs. 4600/-", the entry
"Level 7 in the Pay Matrix (Rs. 44900-142400)" shall be substituted;
(b) in sub-item (iii), for the entry "Pay Band-2, Rs. 9300-34800 with grade pay of Rs. 4200/-", the entry
"Level 6 in the Pay Matrix (Rs. 35400-112400)" shall be substituted.
[F. No. A-12018/1/2017-Admn.]
RAJESH KUMAR CHOUDHRY, Jt. Secy. (Admn.)

Note : The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section(i) vide
number G.S.R. 735(E), dated the 16th October, 20 14.

RAKESH
SUKUL

Digitally signed by RAKESH
SUKUL
Date: 2017.12.09 14:36:46
+oS'30'

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi- 110064
and Published by the Controller of Publications, Delhi- I I0054.
