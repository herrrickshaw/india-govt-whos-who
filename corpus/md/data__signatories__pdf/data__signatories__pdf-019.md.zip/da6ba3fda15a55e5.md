---
doc_id: "da6ba3fda15a55e5"
source_url: "https://steel.gov.in/sites/default/files/2025-04/Steel%20and%20Steel%20Products%20%28Quality%20Control%29%20Second%20%28Amendment%29%20Order%2C2014%20dated%2031.03.2014_0.pdf"
ministry: "Steel (MoS)"
title: "Steel and Steel Products (Quality Control) Second (Amendment) Order,2014 dated 31.03.2014_0.pdf"
date: "2025-04"
pages: 9
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "15cc0b895022f390"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (ii)
PART II—Section 3—Sub-section (ii)

izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la. 813]

ubZ fnYyh] lkseokj] ekpZ 31] 2014@pS=k 10] 1936

No. 813]

NEW DELHI, MONDAY, MARCH 31, 2014/CHAITRA 10, 1936

bLikr ea=kky;
vkns'k
ubZ fnYyh] 31 ekpZ] 2014

dk-vk- 979 (v)-—के ीय सरकार, भारतीय मानक यूरो अिधिनयम, 1986 (1986 का 63) क धारा

14 ारा दत शिय का योग करते ए इपात और इपात उपाद (गुणवता िनयं'ण) ितीय आदेश, 2012
म) और संशोधन करने के िलए भारतीय मानक यूरो से परामश, करने के पश्चात् एतn~~}kjk िन.निलिखत आदेश
जारी करती है, नामत:—

1.

(1) यह आदेश इपात और इपात उपाद (गुणवता िनयं'ण) ितीय (संशोधन) आदेश, 2014 कहा
जाएगा।
(2) यह 01 अैल, 2014 से वृत होगा।

2. इपात और इपात उपाद (गुणवता िनयं'ण) ितीय आदेश, 2012 म) अनुसूची को िन.निलिखत अनुसूची से

ितथािपत 6कया जाएगा, अथा,त:्

“अनुसच
ू ी

[पैरााफ 2 (च) और 3 देख]

भारतीय मानक यूरो
रो के अिनवाय माणन वाले इपात
पात उ पाद!
पाद! क" सूची
भारतीय

शीषक

मानक

(एचएस) कोड

संया
(1)

मानक म िननिलिखत सीमा तक उपाद के वृत होने क तारीख

आईटीसी

(2)

(3)

(4)
(क)

1447 GI/2014

(1)

उपाद

िनन तारीख से
भावी

(ख)

<!-- page 2 -->

2
1

THE GAZETTE OF INDIA : EXTRAORDINARY
2002

म"यवत# और उ%च ताप सेवाएं िजसके
अंतगत बॉयलर भी है, के िलए दाब पाके िलए .टील 0लेट

72085110
72085120
72085210
72085220
72111300
72111420
72111490
72119011

[PART II—SEC. 3(ii)]

(क) परा"विनक परी1ण क दशा म 85
िमलीमीटर से अिधक मोटाई क 0लेट
(कक) परा"विनक परी1ण क दशा म 80
िमलीमीटर से अिधक ले5कन 85
िमलीमीटर से अनिधक मोटाई क 0लेट
(ख) 16 िमलीमीटर से 6यून मोटाई और
3500 िमलीमीटर से अिधक चौड़ाई क
0लेट

1 जुलाई, 2014
1
1

अैल, 2014
अैल, 2014

72119090

उपयु;त (क), (कक) और (ख) को
छोड़कर अ6य उपाद के िलए
(ग)

2

2041

म"यम और िनन ताप पर उपयोग के
िलए दाब पा- के िलए इ.पात 0लेट

72085110
72085120
72085210
72085220
72111300
72111420
72111490
72119090

3

4

2830

2831

अवसंरचना योजन के िलए
इ.पात पुनब?@लन के िलए काबन इ.पात
ढलवा िबलेट, िबलेट Aपड, िबलेट, Cलूम
और िसि@लयां।

साधारण

िनन त6य अवसंरचना इ.पात म
पुनब?@लन के िलए काबन इ.पात ढलवा
िबलेट, िबलेट Aपड, िबलेट, Cलूम और
िसि@लयां।

72061090

परा"विनक परी1ण क दशा म 85
िमलीमीटर से अिधक मोटाई क 0लेट;
(कक) परा"विनक परी1ण क दशा म 80
िमलीमीटर से अिधक ले5कन 85
िमलीमीटर से अनिधक मोटाई क 0लेट
(ख) 16 िमलीमीटर से 6यून मोटाई और
3500 िमलीमीटर से अिधक चौड़ाई क
0लेट;
(ग) उपयु;त (क), (कक)
और (ख) को
छोड़कर अ6य उपाद के िलए
(क)

12

िसतबर, 2012

1 जुलाई, 2014
1
1

अैल, 2014
अैल, 2014

12

िसतबर, 2012

सभी उपाद

12

िसतबर, 2012

सभी उपाद

िवलोप 5कया गया

72071190
72071290
72071920
72071990
72061090
72071190
72071290
72071920
72071990

5

1786

कं करीट पुनब?@लन के िलए उ%च शिE
वाली िवFिपत इ.पात छड़ और तार

72072090
72131090
72142090

(8एमएम तथा इससे अिधक)

िमलीमीटर से कम के Gयास क
उ%च कठोरता क िवFिपत इ.पात छड़
(क) 12

648

5Jयागत कार क
शीत बेि@लत गैरअिभके ि6Kत िवLुत इ.पात शीट तथा
पMी।

अ;तूबर, 2014

और तार ।

(ख) 12 िमलीमीटर और 16 िमलीमीटर के

6

1

पूणतया

72251920

(सीआरएनओ)

72261920

बीच आकार क उ%च कठोरता क
िवFिपत इ.पात छड़ और तार।
(ग) उपयु;त (क) और (ख) को छोड़कर
अ6य उपाद के िलए
(क) अिधकतम 5.3 वाट/5कलोNाम (1.5
टे.ला/50 हेटज पर) क हािन वाले शीत
बेि@लत गैर-अिभके ि6Kत िवLुत इ.पात
शीट तथा पMी ।
उपयु;त (क) को छोड़कर अ6य
उपाद।
(ख)

31

माच, 2013

12

िसतबर, 2012

1 जुलाई, 2014

12

िसतबर, 2012

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(ii)º
7

3024

Hkkjr dk jkti=k % vlk/kj.k

कण के अनुकूल िवLुत इ.पात शीट तथा
पMी। (सीआरजीओ)

72251100
72261100

3

डोमेन Pरफाइं ड Nेन ओPरएंPटड
इलेि;Sकल .टील शीTस और ि.S0स
िजसका 6यूनतम पोलराईजेशन 800
ए/एम फ@ड .Sथ पर 1.85 टेसला हो
(क)

1 जुलाई, 2014

तथा अिधकतम िवशेष कोर हािन 0.23

एमएम क सांकेितक मोटाई के िलए 0.90
वॉट/5क.Nा. (1.70 टेसला/50 हेटज) और
0.27

एमएम

0.95 वाट/

सांकेितक

मोटाई

के

िलए

5क.Nा. (1.70 टेसला/50 हेटज)

हो।

(ख)

उपयु;त (क) को छोड़कर उपाद के

01

अ;टू बर, 2013

12

िसतबर, 2012

31

माच, 2013

िलए

8

15391

शीत बेि@लत गैर अनुकूल िवLुत इ.पात
शीट तथा .Sीप-अध सं.कृ त कार
(सीआरएनओ)

72251920

सभी उपाद

72261920
72091720
72091730
72091790
72092720
72092730

9

2062

त0त बेि@लत म"यम तथा उ%च त6यता
अवसंरचना इ.पात (6 िमलीमीटर से
अ6यून Gयास या मोटाई और 50

72092790

72162200

िमलीमीटर मोटाई से 6यून त0त
बेि@लत
सपाट
बेिलत
उपाद
(शीट/पMी/कुंडली).
(ख) 12 िमलीमीटर और इससे अिधक क
मोटाई/Gयास
वाली सपाट छड़ और
गोल/चोकोर/षटभुज/अUटभुज छड़

72163100

__________________________

72139190
72139990
72149990

6

72161000

िमलीमीटर से कम के अवसंरचनामक
शलाका और छड़ को छोड़कर)

72162100

िमलीमीटर

x

50

िमलीमीटर

x

72163200
72163300
72164000
72165000

(क) 6

(ख-क)

12

मोटाई/

िमलीमीटर

से

------------------कम

Gयास वाले सपाट छड़ और
अUटभुज छड़

गोल/चोकोर/षटभुज/

--------------------------------------

परा"विनक परी1ण क दशा म 85
िमलीमीटर से अिधक मोटाई क 0लेट.
(ग)

72111300
72111410
72111420
72111430
72111440
72111450
72111460
72111490

-------------------

--------------------------------------

परा"विनक परी1ण क दशा म 80
िमलीमीटर से अिधक ले5कन 85
िमलीमीटर से अनिधक मोटाई क 0लेट
(घ) 16 िमलीमीटर से 6यून मोटाई और
3500 िमलीमीटर से अिधक चौड़ाई क
0लेट.
(गक)

------------------1

vizSy, 2014

-------------------

__________________________
(ड.) 590 िमलीमीटर और इससे अिधक से
लेकर
72119012
72119090

1016

(गहराई)

इ.पात.

िमलीमीटर

आकार

तक

के यूिनवसल बीम .S;चरल

-------------------

(च) 305 िमलीमीटर और इससे अिधक से
लेकर
72139190

356

िमलीमीटर

आकार

यूिनवसल कॉलम .S;चरल .टील.

तक

के

31

माच, 2013

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY
72139990

[PART II—SEC. 3(ii)]

(च-क) 10 िमलीमीटर से 80 िमलीमीटर

क मोटाई और 2500 िमलीमीटर अथवा
इससे अिधक चौड़ाई क 0लेट;
(च-ख) 50 x50 x4 और 100 x100 x8

72149190
72149990

के बीच आकार वाले एंगल से;शन (एल
से;शन) .S;चरल इ.पात;
--------------------------------------

-------------------

72082510
72082520
72082530
72082540
72082590
72082610
72082620
72082630
72082640
72082690
72082710
72082720
72082730
72082740
72082790
72083610
72083620
72083630
72083640

72083690
72083710
72083720
72083730
72083740
72083790
72083810
72083820
72083830
72083840
72083890
72083910
72083920
72083930
72083940
72083990
72085110
72085120
72085130
72085140
72085190

72085210
72085220
72085230
72085240
72085290

(छ)

उपयु;त (क), (ख),(ख-क), (ग) (घ),

(ड.),

(च),

(च-क),

छोड़कर अ6य उपाद।

और

(च-ख)

को

12

िसतबर, 2012

<!-- page 5 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

5

72085310
72085320
72085330
72085340
72085390

72089000

LiVhdj.k % इस आदेश के उ8े9य के िलए एत:ारा यह प;ट 6कया जाता है 6क कटम टे=रफ हे?स के अनुसार शु@क
लगाने का िनण,य लेते समय इस आदेश के ावधान का इतेमाल कॉलम (।) क अनुAपी िविB म) उि@लिखत
भारतीय मानक संDया के सामने कॉलम (2) के तहत अनुAपी िविB म) वEणत िवशेष उपाद के िलए 6कया
जाएगा और इस कार के मामले म) यह आदेश उन उपाद पर लागू नहG होगा जो कॉलम (3)के तहत अनुAपी
िविB म) उि@लिखत आईटीसी (एचएस) कोडो के अंत,गत आते हJ ले6कन कॉलम (।) म) उि@लिखत अनुAपी भारतीय
मानक के तहत नहG आते हJ ।**

[iQk- la- 1 (1)@2014&VhMCY;w]
;w- ih- ¯lg] la;qDr lfpo

uksV %&&मूल आदेश का.आ. 415 (अ) 6दनांक 12 माच, 2012 क अिधसूचना के ारा भारत के राजप', असाधारण

म) कािशत 6कया गया था िजसे 6क बाद म) अिधसूचना संDया का.आ.2128(अ) 6दनांक 10 िसत.बर, 2012,
का.आ.2510(अ) 6दनांक 17 vDrwcj, 2012 और का.आ.450(अ) 6दनांक 15 फरवरी, 2013, का.आ.853 (ई)
6दनांक 28 माच,, 2013 तथा का.आ.3011 (अ) 6दनांक 1 अLतूबर, 2013 से संशोिधत 6कया गया है ।
MINISTRY OF STEEL
ORDER
New Delhi, the 31st March, 2014
S.O. 979 (E).—In exercise of the powers conferred by section 14 of the Bureau of Indian Standards Act,
1986 (63 of 1986), the Central Government, after consulting the Bureau of Indian Standards, hereby makes the
following order further to amend the Steel and Steel Products (Quality Control) Second Order, 2012, namely :-1. (1) This order may be called the Steel and Steel Products (Quality Control) Second (Amendment) Order, 2014.
It shall come into force with effect from 1st April, 2014.

(2)
2.

In the Steel and Steel Products (Quality Control) Second Order, 2012, for the Schedule, the following Schedule
shall be substituted, namely:“ SCHEDULE
[See paragraph 2(f) and 3]
List of steel products under mandatory Bureau of Indian Standards certification

Indian

Title

ITC (HS)
Code

(2)

(3)

Standard
number
(1)

Date of coming into force of the product in the standard to the extent given
below

(4)
(A) Product

1.

2002

Steel plates for
pressure vessels for
intermediate and
high temperature
service including
boilers

72085110
72085120
72085210
72085220

(a) Plates of thickness more than 85 mm in
Ultrasonic Tested condition;

(aa) Plates of thickness more than 80 mm but not
exceeding 85 mm in Ultrasonic Tested condition;

(B) With effect from

1st July, 2014

1st April, 2014

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY
72111300
72111420

(b) Plates of thickness less than 16 mm but width
more than 3500 mm;

1st April, 2014
12th September, 2012

72111490
72119011

[PART II—SEC. 3(ii)]

(c) for other products excluding (a), (aa) and (b)
above

72119090
2.

2041

Steel plates for
pressure vessels
used at
moderate and
low
temperature

72085110
72085120
72085210
72085220

(a) Plates of thickness more than 85 mm in
Ultrasonic Tested condition;

1st July, 2014

(aa) Plates of thickness more than 80 mm but not
exceeding 85 mm in Ultrasonic Tested condition;

1st April, 2014

(b) Plates of thickness less than 16 mm but width
more than 3500 mm;

1st April, 2014

72111300
72111420
72111490

3.

4.

2830

2831

72119090

(c) for other products excluding (a), (aa) and (b)
above

Carbon steel cast
billet ingots, billets,
blooms and slabs for
re-rolling into steel
for general structural
purposes

72061090
72071190
72071290

All Products

Carbon steel cast
billet ingots, billets,
blooms and slabs for
re-rolling into low
tensile structural
steel

72061090
72071190
72071290

12th September, 2012

12th September, 2012

72071920
72071990
All products

Omitted

72071920
72071990
72072090

5.

6.

7.

1786

648

3024

High strength
deformed steel bars
and wires for
concrete
reinforcement (8
mm and above)

72131090
72142090

Cold rolled
non-oriented
electrical steel
sheet and stripfully processed
type (CRNO)

72251920
72261920

Grain oriented
electrical steel
sheet and strip
(CRGO)

72251100
72261100

(a) High strength deformed steel bars and wires
of diameter less than 12 mm

1st October, 2014

(b) High Strength deformed steel bars and wires of
sizes between 12 mm and below 16 mm

31st March, 2013

(c) for other products excluding (a), & (b) above

12th September, 2012

(a) Cold rolled non-oriented electrical steel sheets
and strips with Watt loss not exceeding 5.3
Watt/Kg (at 1.5 Tesla/50 Hz)

1st July, 2014

(b) For other products excluding (a) above

(a) Domain Refined Grain Oriented Electrical
Steel Sheets and Strips with minimum
polarization of 1.85 Tesla at a field strength of
800 A/m and maximum specific core loss of 0.90
Watt/Kg (1.70 Tesla/50 Hz) for nominal thickness
of 0.23 mm and 0.95 Watt/Kg (1.70 Tesla/50 Hz)
for nominal thickness of 0.27 mm.

(b) For products excluding (a) above

12th September, 2012

1st July, 2014

1st October, 2013

<!-- page 7 -->

¹Hkkx IIµ[k.M 3(ii)º
8.

15391

Cold rolled
non-oriented
electrical steel
sheet and stripsemi-processed
type (CRNO)

Hkkjr dk jkti=k % vlk/kj.k
72251920

All products

7
12th September, 2012

72261920
72091720
72091730
72091790
72092720
72092730
72092790

9.

2062

Hot rolled medium
and high tensile
structural steel
(excluding bars and
rods of diameter or
thickness less than
6 mm and
structurals below
50 mm x 50 mm x
6 mm)

72139190
72139990

(a) Hot Rolled Flat Rolled products (sheets/
strips/ coils) less than 6 mm thickness;

72149990
72161000
72162100
72162200
72163100

(b) Flat bars and rounds/ squares/ hexagons/
octagon bars of thickness/ diameter 12 mm and
above;
(ba) Flat bars and rounds/ squares/ hexagons/
octagon bars of thickness/ diameter less than
12 mm

31st March, 2013

1st October, 2014

72163200
72163300
72164000

(c) Plates of thickness more than 85 mm in
Ultrasonic Tested condition;

72165000

(ca) Plates of thickness more than 80 mm but not
exceeding 85 mm in Ultrasonic Tested condition;

72111300

(d) Plates of thickness less than 16 mm but width
more than 3500 mm;

1st July 2014

1st April 2014

72111410
72111420
72111430

(e) Universal Beam structural steel of size
(depth) greater than 590 mm up to and
including size 1016 mm;

72111440

72111490

(f) Universal Column structural steel of size
greater than 305 mm up to and including size
356 mm;
(fa) Plate of thickness of 10 mm to 80 mm and
width of 2500 mm or more;

72119012

(fb) Angle (L section) structural steel of size
between 50x50x4 and 100x100x8;

72111450
72111460

72119090

72139190
72139990

72149190
72149990
72082510
72082520
72082530
72082540
72082590
72082610
72082620
72082630

(g) for other products excluding (a), (b), (ba), (c),
(ca), (d), (e), (f), (fa) and (fb) above

31st March, 2013

12th September, 2012

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY
72082640
72082690
72082710
72082720
72082730
72082740
72082790
72083610
72083620
72083630
72083640
72083690
72083710

72083720
72083730
72083740
72083790
72083810
72083820
72083830
72083840
72083890
72083910
72083920
72083930
72083940
72083990
72085110
72085120
72085130
72085140
72085190

72085210
72085220
72085230
72085240
72085290

72085310
72085320
72085330
72085340
72085390
72089000

[PART II—SEC. 3(ii)]

<!-- page 9 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

9

Explanation.—For the purpose of this Order, it is hereby clarified that while taking a decision on the levy of duty as per
the Customs Tariff Heads, the provisions of this Order shall apply to the specific products described
under corresponding entry under column (2), covered under the Indian Standard number mentioned
under corresponding entry under column (1) and in such case this Order shall not apply to those
products which falls under the ITC (HS) Codes mentioned in corresponding entry under column (3) but
do not fall under the corresponding Indian Standards mentioned under column (1).”
[F. No. 1(1)/2014-TW]
U. P. SINGH, Jt. Secy.

Note:— The principal Order was published in the Gazette of India, Extraordinary vide notification number S.O. 415(E),
dated the 12th March, 2012 and subsequently amended vide notification numbers S.O. 2128 (E), dated the
10th September, 2012 ; S.O. 2510(E), dated the 17th October, 2012, S.O. 450(E), dated the 15th February,
2013, SO 853 (E) dated 28th March, 2013 and SO 3011 (E) dated 1st October 2013.

Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
