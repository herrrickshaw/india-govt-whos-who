---
doc_id: "de33bf01af2bbeec"
source_url: "https://www.dhr.gov.in/static/uploads/2025/09/d1127e2b4b9f6beaf909ee6a54a46d3b.pdf"
ministry: "Department of Health Research (DHR)"
title: "Policy Brief vol 1"
date: "2025-09-02"
pages: 80
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a2b2c65a872398d3"
---

<!-- page 1 -->

HEALTH TECHNOLOGY
ASSESSMENT IN INDIA (HTAIN)

POLICY BRIEFS

HEALTH TECHNOLOGY
ASSESSMENT IN INDIA
(HTAIn)
DEPARTMENT OF HEALTH RESEARCH
MINISTRY OF HEALTH & FAMILY WELFARE

<!-- page 2 -->

THE LOGO

The logo of Health Technology Assessment in India (HTAIn) is in the form of a
shield which represents the protecting role of HTAIn towards its citizens as the
Board shields the citizens from financial hardship arising out of health care seeking.
The top of the shield is marked with Ashok Chakra, depicting the allegiance of
HTAIn towards the constitutional values and the nation. Rod of Asclepius and
symbol of Indian Rupee are placed side by side below the National Emblem, as
while making a decision about cost- effectiveness of an intervention, HTAIn gives
due consideration to both public health potential and costs associated with an
intervention. “सर्वे सन्तु निरामयााः । (Sarve Santu Niramayah)” is scripted in Devnagri
script on a ribbon, which means “Let All Be Healthy’, and expresses the devotion
of HTAIn towards the values of Universal Health Cara

<!-- page 3 -->

This document contains the Policy Briefs of the completed Health Technology
Assessment Studies conducted by Health Technology Assessment in India
(HTAIn), which includes HTAIn Secretariat, the Regional Resource Centers and
Technical Partners of HTAIn established in different states across India. There is an
introductory overview of Health Technology Assessment in India (HTAIn)
established under Department of Health Research (DHR), Ministry of Health &
Family Welfare, New Delhi followed by the policy briefs.

Designed and compiled By
Dr. Kavitha Rajsekar
Scientist ‘E’
HTAIn Secretariat
Department of Health Research
Ministry of Health & Family Welfare
New Delhi
Dr. Aamir Sohail
Health Policy Analyst
HTAIn Secretariat
Department of Health Research
Ministry of Health & Family Welfare
New Delhi

For more information kindly visit www.htain.icmr.org.in Or, Contact
Health Technology Assessment in India Secretariat
Department of Health Research
Ministry of Health & Family Welfare
1st Floor, Indian Red Cross Society Building,
1, Red Cross Road,
New Delhi - 110001.
Email ID: htain-dhr@nic.in
Phone No: +91 11- 23736906/ 23736085

<!-- page 4 -->

CONTENTS

Sl. No.

Topic
1. Health Technology Assessment in India (HTAIn)
2. Policy Briefs

Page No.

i. Intraocular Lens for Cataract Surgery – A Hope to See Again.

1

ii. Safety Engineered Syringes for Therapeutic care in India.

4

iii. Health Technology Assessment of Strategies for Cervical Cancer Screening in India.

7

iv. Expanding Informed Contraceptive Choice for Indian Women: Will Nexplanon Matter?

10

v. Diagnostic Efficacy of Digital Hemoglobinometer (TrueHb), HemoCue and Non- invasive
Devices for Screening Patients for Anemia in the Field Settings.

13

vi. Health Technology Assessment of Uterine Balloon Tamponade for Management of
Postpartum Haemmorhage in India.

15

vii. Evaluation of Pulse Oximetry as a Tool to Prevent Childhood Pneumonia Related
Morbidity and Mortality.

17

viii. Cost Effectiveness Analysis of Hypothermia Detection Devices (BEMPU, ThermoSpot and
Fever Watch) for Premature and Low Birth Weight Neonates in India.

21

ix. Health Technology Assessment of “Portable Automated ABR” Neonatal Hearing
Screening Device.

23

x. Health Technology Assessment of various RT-PCR Kits/Methods for the Diagnosis of
Influenza A/ H1N1pdm09 Virus in All Age Group Patients in India.

26

xi. Decentralized Screening of Hepatitis B & C at Primary Health Centres in Tamil Nadu.

28

xii. Rapid Health Technology Assessment for Incorporating TrueNat as a Diagnostic Tool for
Tuberculosis Under RNTCP in India.

31

xiii. Health Technology Assessment of Automated Resuscitation Device (ARD) for Neonatal
Resuscitation at Point of Delivery in Indian Healthcare System.

33

xiv. A Comprehensive HTA of Project Lifeline – A Portable ECG Facility at PHCs of
Ahmedabad District of Gujarat.

36

xv. Health Technology Assessment of Population-Based Screening for Type 2 Diabetes &
Hypertension in India.

40

xvi. Economic-Evaluation of Percutaneous Coronary Intervention as Compared to Coronary
Artery Bypass Grafting in Left Main Coronary Artery Disease.

42

xvii. Economic Evaluation of Different Treatment Modalities for Management of Patients with
Multivessel Coronary Artery Disease (MV-CAD).

45

xviii.Economic-Evaluation of Percutaneous Coronary Interventions (PCI) Against Optimal
Medical Therapy (OMT) For Management of Patients with Single Vessel Coronary Artery
Disease (SV-CAD) Without Left Main Coronary Artery (LMCA) Involvement.

47

xix. Health Technology Assessment of Low Cost Portable Ventilator

50

<!-- page 5 -->

HEALTH TECHNOLOGY ASSESSMENT IN INDIA (HTAIn)
1. Health Technology Assessment (HTA)
Health technology assessment (HTA) is widely used methodology internationally
for optimization of resource allocation in health. It is a multidisciplinary process that
gathers policy relevant evidence about the medical (clinical effectiveness), economic
(cost effectiveness), social and ethical issues related to the use of a health intervention
in a systematic, inclusive, transparent and robust manner to assist policy makers in
decision making in Health and Healthcare.

Health Technology Assessment
Health technology assessment is intended to provide a bridge between the
world of research and the world of decision-making (1). HTA inform Government
agencies while drafting policy recommendations in the field of health, health care
professionals in drafting Standard Treatment Guidelines, hospitals and healthcare
administration regarding the use of a health intervention, insurance companies
while deciding their premium and reimbursement rate, manufactures during
device or drug production, patient cares and advocacy groups regarding the ethical
and legal issues of a health intervention. We can say, HTA is a multidisciplinary
process and together it has the potential to help the country in its global
commitment of Universal Health Coverage (UHC)

<!-- page 6 -->

Who does the HTA inform?

2. Health Technology Assessment in India (HTAIn)
Recognizing the importance of Health Technology Assessment (HTA) in healthcare
decision making and to facilitate the process of transparent and evidence-informed
decision making in the field of health, Government of India has set up a body as “Health
Technology Assessment in India (HTAIn)” under the Department of Health Research
(DHR), Ministry of Health & Family Welfare (MoHFW). HTAIn is entrusted with the
responsibility to analyze evidences related to cost-effectiveness, clinical-effectiveness
and equity issues regarding the deployment of health technologies viz. medicines,
devices and health programmes by means of HTA in India, and in turn help in efficient
use of the limited health budget and provide people access to quality healthcare at
minimum cost.

<!-- page 7 -->

3. Purpose of establishing HTAIn
The Government of India is committed to extend healthcare services to its 1.34
billion population as part of India’s Universal Health Coverage (UHC) agenda. One of
the most important challenges in India that warrant immediate attention is increasing
catastrophic out of pocket expenditures (OOP) in healthcare. According to National
Health Accounts Report 2017-18 Household’s Out of Pocket Expenditure on health
(OOPE) was 61% of total health expenditure (2). 2017 World Bank report estimated the
OOP spending on healthcare in India to be as high as 62% (3). Extending adequate
healthcare services to the population requires optimal utilization of existing resources
to ensure that the greatest amount of health is bought for every rupee spent. National
Health Policy 2017 also proposes a responsive and strong regulatory framework so that
challenges of quality of care, cost escalations and impediments to equity are addressed
effectively. The main purpose of the HTAIn is to engage in explicit and evidence-based
decision-making in health taking India towards universal health coverage. HTA will
help to bridge the evidence-to-policy gap and ensure alignment of academic and policy
interests through HTA towards the common goal of improving decision-making for
health resource allocation to improve the health of the Indian population.
4. Objectives of HTAIn


Maximizing Health



Reducing Out of Pocket Expenditure (OOP)



Minimizing Inequality

5. HTAIn Structure
HTAIn consists of – (i) DHR In-house Secretariat, (ii) Technical Appraisal
Committee (TAC), (iii) HTAIn Board and (iv) Regional Resource Centers/ Hubs and
Technical Partners (TP). The secretariat coordinates between the Resource Centres,
Technical Partner(s) (TP), Technical Appraisal Committee (TAC) and the Board.

<!-- page 8 -->

Organizational structure of HTAIn to conduct HTA


User Department/ User Agency: Provides topics of study to HTAIn and implement the
recommendations of the completed studies.



HTAIn Secretariat or Secretariat: DHR-in-house body that coordinates between the
User Department, TAC, Board, Regional Resource Centres and Technical Partners.



Technical Appraisal Committee (TAC): It appraises the HTA study at different stages
mainly after proposal development and the outcome of the study.



HTAIn Board: Board appraises the recommendations of the studies from TAC and
takes the final decision before sending the recommendations to the User Department
for implementation.



Technical Partners and Regional Resource Centres/ Hubs: Technical Partners are
Central/ State Government Institutes that conduct the HTA studies of HTAIn.
Regional Resource Centres a have additional tasks of liaising and coordinating with
the State Governments as an extended arm of HTAIn Secretariat.

<!-- page 9 -->

HTAIn Regional Resource Centres and Technical Partners
6. HTAIn Functioning
7.1.

Key Phases

Key Phases of the HTAIn Process

<!-- page 10 -->

Intraocular Lens for Cataract Surgery
"A hope to see again"

<!-- page 11 -->

Intraocular Lens for Cataract Surgery *
"A hope to see again"
HTAIn Secretariat, Department of Health Research, Ministry of Health &Family Welfare

July 2018

Policy Brief
Summary
Cataract is the leading cause
of blindness worldwide. In
India cataract has been
reported to be responsible for
50-80% of the blindness in the
country most prevalent in
older population. Women and
people with low socioeconomic
status are more at risk. In
order to bridge the gap
between the evidence-topolicy, a comprehensive Health
Technology Assessment (HTA)
study was undertaken by
Health Technology Assessment
in India Secretariat (HTAIn
Sec.) to examine the
comparative effectiveness and
cost-effectiveness of various
cataract surgeries and
intraocular lenses (IOLs).
Overall the study suggested
that Manual Small Incision
Cataract Surgery (MSICS) with
Rigid PMMA lens was found to
be the most appropriate
strategy in a country like India
where age related cataract
were more reported in rural
areas lacking in medical
infrastructure and among the
people with low socioeconomic
status.

* The policy brief is based upon
the Health Technology
Assessment of "intraocular
lenses for treatment of agerelated cataracts in India" July 2018 and can be found on
the link:
https://dhr.gov.in/sites/default/
files/htaincataract_0.pdf

Courtesy: International Agency for the Prevention of Blindness (IAPB)

Background
Cataract is the leading cause of blindness
(51%) and low vision (33%) worldwide (Fig. 1)
(1). The prevalence of blindness in India is
around 1% where cataract contributes for
almost 60-70% (2). As per the ongoing
national blindness survey 2017-2018, the
overall prevalence of blindness has reduced
to almost 0.50% but cataract is still as
prevalent as 70 % (Fig. 2).

Recommendations

Under Rashtriya Swasthya Bima Yojna (RSBY)
cataract is one of the most utilized (16-36%)
packages in most of the states. RSBY offers
four different packages for cataract ranging
from 4000 to 7000 INR (Table-1) and among
them “Cataract with foldable Intraocular lens
(IOL) by Phacoemulsification tech. Unilateral”
of 7000 INR was found to be the most utilized
cataract package (3).

Phacoemulsification cataract surgery
can be provided in those areas where
infrastructure and experts are available
for Phaco. surgery.

Experts reported that most common surgical
options for the treatment of cataract in India
are Phacoemulsification (Phaco) and Manual
Small Incision cataract surgery (MSICS) that
utilizes foldable Acrylic and rigid PMMA
lenses, respectively. However, there is a lack
of evidence in Indian context for comparing
the clinical and cost-effectiveness of these
surgical interventions and IOLs for the
treatment of age-related cataracts.

On the basis of clinical efficacy, cost,
accessibility, availability and feasibility,
MSICS with rigid lens is most
appropriate intervention to treat
cataract patients in India in current
scenario.

The benefit packages for Phaco. with
foldable lens and Small Incision Cataract
Surgery with rigid PMMA lenses may
cost as 9606 INR and 7405 INR
respectively.
The package is inclusive of initial OPD
consultation, diagnostic tests
(optometry, vision test etc.), counselling,
pre-surgery/ anaesthetics, surgery,
ward, drugs, medical consumables, lens,
food for patient and one attendant and
one follow-up visit cost.

Page 1

<!-- page 12 -->

Policy Brief
Choice of cataract surgery
and lenses in India are
made depending upon the
clinical, economic and
social conditions of
patients and surgeon’s
expertise, infrastructure
available at clinic etc. To
bridge this gap between
evidence and decision for
an evidence-informed
policymaking, a
comprehensive Health
Technology Assessment
(HTA) study was
undertaken by Health
Technology Assessment in
Figure 1.
India Secretariat (HTAIn Sec.) to
examine the clinical and cost-effectiveness of various
cataract surgeries and intraocular lenses (IOLs) for the
treatment of age-related cataracts. Since this HTA topic
was given to the HTAIn Sec. by RSBY and Phaco. and
MSICS was the most common intervention the two were
compared for their effectiveness and
equity implications.

Clinical and Cost-Effectiveness
The study included the secondary as
well as primary data collection,
wherever required. Phaco. and MSICS
showed comparable clinical efficacy in
terms of visual acuity and complications. There were comparable clinical
benefits with rigid PMMA and foldable
Quality Adjusted Life Years
Gained -QALY (4)
QALY is a measure of gain in expected
lifespan resulting from an intervention
weighed by the quality of that life e.g. an
intervention that leads to a five-year
gain in life expectancy, but implies
considerable pain during those years
might be estimated to have a lower QALY
than an intervention that results in
four-year gain, but with less pain during
that period.
QALY is a generic measure of health and
offers the potential to compare the
health gain across different diseases and
hence provide a rationale to decide while
making investment across different
health programmes in different areas of
health care, such as treatments for heart
disease and cancer, and to assess the
opportunity cost (on the budget) of
adopting programmes.
EQ5D is the most utilized tool worldwide
to measure QoL

QALY for for different
types of cataract
surgeries (Phaco.
and MSICS) and lenses
(rigid and foldable
lenses). Our Study
showed that MSICS
leads to a better VRQoL
compared to Phaco (Fig.
4(a). However, the
economic evaluation
depicted phaco with
foldable lens to be costeffective over MSICS
with rigid lenses (Fig.
4(b) with an incremental
cost-effectiveness ratio of 3862.79
INR per QALY, Incremental Net
Health Benefit of 0.55 QALYs and Incremental Net
Monetary Benefit of 63255.2 INR.
There was no generalizable literature available on the cost
of cataract surgery/ lenses in India. Therefore, a primary
collection was done in secondary and
tertiary hospital settings. Average Cost
of Cataract Surgery package from
three secondary centers was calculated to be 9606 INR for Phaco. and 7405
INR for MSICS while in tertiary setting
it came out to be 13017.51 INR and
9215.89 INR, respectively. The package
included OPD consultation, diagnostic tests (optometry, vision test etc.),

Figure 2. Prevalence of Blindness and cataract
contribution.

acrylic lenses when
implanted after a
Phaco. surgery. There
is also not enough
evidence suggesting
the superiority of
multifocal lens over
monofocal or the role
of IOL material in
developing posterior
capsule opacification
(PCO). Overall, MSICS
with rigid monofocal
lenses sounds a wise
strategy to cater to
the huge backlog of
cataract patients in
India without compromising the quality of
healthcare. There are
very few studies
reporting quantitative

Figure 3. HTA overview

Vision related quality of life -VRQoL (5)
VRQoL represents the degree to which vision impacts an individual’s
ability to complete activities of daily living and one’s social, emotional
and economic well-being.
It is a specific measure of visual impairment and can be assessed by
measuring the degree of impairment experienced in activities of daily
living that rely on sight.
A disease specific tool (such as IND-VFQ33 for cataract) is used to
measure the QoL

Page 2

<!-- page 13 -->

Policy Brief

Figure 4. Pre and Post
surgery scores for
(a) EQ5D and (b) INDVFQ-33 subscales for
different
combinations of
surgery and IOLs

(a)

(b)

Policy Implications
counseling, pre-surgery/ anesthetics, surgery, ward, drugs, RSBY was initially designed to target only the Below
medical consumables, lens, food for patient and one
Poverty Line (BPL) households but has been expanded to
attendant and one follow-up visit cost.
cover other defined categories of unorganized workers (2).
As per the ongoing Blindness Survey of India (2017-18),
cataract prevalence is estimated to be almost 4% in the
In terms of the suitability depending upon the health
50+ age population of the country. Upon extrapolation of
service determinants, resources available, accessibility, cost evidence, it was seen that treating all these patients with a
and clinical effectiveness etc. in the rural and low
combination of SICS with rigid lens may lead to a cost
socioeconomic setting where cataract prevalence was most saving of 17.3 b. INR.
MSICS being less technology dependent seems to be
Key Findings
According to the 2011
advantageous for high-volume case-loads of age-related
Phaco vs. MSICS - Comparable
census, 70% of Indian
cataract whilst maintaining excellent visual outcomes.
Clinical Efficacy in terms of VA
population (mostly poor)
MSICS was mostly performed at secondary level hospitals
and complications.
reside in rural areas (9)
without any requirement of the constant power supply
where most of the cataract
while Phaco. was performed mostly at the tertiary level,
Foldable vs. Rigid PMMA lenses cases
were
reported
(7)
Comparable Clinical Efficacy.
requires high capital investment and recurring
therefore,
for
a
public
expenditures of the Phaco. machine and consumables and a
health programme MSICS
specially trained personnel to handle the machine (6).
[MSICS + Rigid PMMA lens] vs.
with rigid lens seems to be
Moreover, indigenous PMMA that is used in MSICS would
[Phaco. + Foldable lens] :
beneficial without comprobe less expensive in contrast to the foldable lens used in
[MSICS + Rigid PMMA]
mising the quality of care
Phaco. which is mostly imported and expensive (6).
Better VRQoL
and extra cost saving will
[Phaco.+ foldable lens]
Studies reported that there was a providerhelp to cater more cataract
0.57 QALY Gain
consumer mismatch for cataract in India i.e. cataract cases patients/ backlogs.
[MSICS + Rigid PMMA]
and backlogs were reported
Less Costly
more from the rural area (7)
Conclusion
and most of the ophthalmMSICS - Less technology
Both Phaco. and MSICS showed comparable clinical efficacy in
dependent mostly performed at
ologists were concentrated
terms of visual acuity and complications. Moreover, the clinical
secondary hospitals
in the urban areas. Moreover, outcome of the rigid PMMA and acrylic foldable were also equally
cataract prevalence was
good. However, the cost of MSICS with rigid lens came to be lesser
Phaco. - More technology
dependent, require good
than phaco. with foldable lens and also MSICS is less technology
more in the prevalence was
infrastructure and performed
dependent
hence
MSICS
with
rigid
lens
seems
advantageous
in
more in the uneducated
mainly at tertiary level.
rural settings where the majority of cataract cases were reported
population with low
and also help to cater more cataract patients.
socioeconomic status (8).

Equity Considerations

Therefore, for a public health programme in a populated
and diverse country having enormous socio-economic
differences, SICS seems to be more appropriate intervention to address the large backlog of cataracts cases.

Sources
1. WHO. World Health Report, Visual Impairment and Blindness, 2010.
2. National Programme for Control of Blindness Surveys. npcb.nic.in/
3, RSBY::Rashtriya Swasthya Bima Yojna. http://www.rsby.gov.in/
4. Methods for the Economic Evaluation of Health Care Programmes. 4th Edition.
Oxford Press.
5. Finger RP et al. Investig Ophthalmol Vis Sci. 2011, 52(9):6081–8.
6. Ruit et al. Am J Ophthalmol. 2007, 143(1):32-38.
7. Vajpeyi et al. Ophthalmic Res. 1999;31(2):86-92.
8. Rakhi Dandona LD. Br J Ophthalmol. 2001; (85:):1484–1488.
9. http://censusindia.gov.in/

Page 3

<!-- page 14 -->

Safety Engineered Syringes for Therapeutic
Care in India.

<!-- page 15 -->

HT
AI
nRes
our
c
eHub,
S
c
hool
ofPubl
i
cHea
l
t
h
Pos
tGr
a
dua
t
eI
ns
t
i
t
ut
eofMedi
c
a
l
E
duc
a
t
i
ona
ndRes
ea
r
c
h
Cha
ndi
ga
r
h,
I
ndi
a

4

<!-- page 16 -->

5

<!-- page 17 -->

6

<!-- page 18 -->

Health Technology Assessment of Strategies
for Cervical Cancer Screening in India.

<!-- page 19 -->

Health Technology Assessment in India
Department of Health Research, MoHFW

Health Technology Assessment of Strategies
for Cervical Cancer Screening in India
POLICY BRIEF
SUMMARY
Cancer of the uterine cervix is the second most
common cancer among women world-wide. It is
also the second most common cancer among
Indian women, which constitute the largest burden
of cervical cancer patients in the world. One out of
every five women in the world suffering from this
disease is an Indian. The establishment of a strong
link between high-risk persistent human
papillomavirus (HPV) infections and the occurrence
of cervical cancer has resulted in the recent
development of HPV related control strategies for
the prevention of cervical cancer. Introduction of
screening led to reduction in occurrence of
cervical cancer cases from 19% to 58% along with
decrease in cancer deaths from 28% to 70% as
compared to no screening in a lifetime cohort of 1
lakh women. There was reduction in lifetime risk
of cervical cancer among Indian women from
2.18% in the case of no screening to 0.879 - 1.729
% with implementation of various screening
strategies. This reduction in cancer cases and
associated mortality translated into gain of 3141
to 6848 life years and 3630 to 8198 QALYs among
various screening strategies implemented in a
cohort of 1 lakh women. The study concludes that
VIA every 5 years is the most cost-effective option
with an incremental cost of INR 21,196 (USD 320)
per QALY gained in the context of India.
Introduction
The establishment of link between high-risk human
papillomavirus (HPV) infection and occurrence of
cervical cancer has resulted in recent development
of HPV related control strategies for prevention of
the same.

The present study was designed to assess
the cost effectiveness of 3 screening
strategies i.e., visual inspection with
acetic acid (VIA), Papanicolaou test (Pap
smear) and HPV DNA test at a frequency
of every 3 years, 5 years and 10 years in
the context of India.
Methodology: The present study based
on a markov model, societal perspective
and discount rate of 3% estimated the
lifetime costs and consequences in a
hypothetical cohort of 30 year old women
screened with either of the screening
strategy at various time intervals.
Diagnostic accuracy of the screening
strategies and data on transition
probabilities was based on the results of
the existing meta-analysis studies.
Primary data was collected for assessing
per person cost of screening, cost of
treating cervical cancer and quality of life.
Results: Introduction of screening leads
to reduction in lifetime occurrence of
cervical cancer cases from 19% to 58%
and cervical cancer deaths from 29% to
70% as compared to no screening. Among
various screening strategies, VIA every 5
years was found to be most cost-effective
at an incremental cost of INR 16,905 (US$
255) per QALY gained.

7

<!-- page 20 -->

POLICY RECOMMENDATIONS
1. Screening with VIA every 5 years
among the women of age 30-65 years is
recommended for India.
2. A minimum 30% of screened positive
patients are needed to be treated for VIA
every 5 years to remain cost effective.
Similarly, lifetime risk of cervical cancer
of at least 0.7 is required for VIA 5 yearly
to be cost effective.

Rationale
As India is on the path towards universalizing
national level screening program, the present
study was designed to assess the costeffectiveness of three screening strategies of
VIA, Pap smear and HPV DNA as compared to
no screening scenario at the frequency of
every 3 years, 5 years and 10 years among
women in the age groups 30-65 years in India.
In addition, we also evaluated the costs and
consequences of a scenario comprising of
screening with HPV vaccination as compare to
screening alone or do nothing.

3. In terms of equity considerations and
specifically considering the screening
strategy of VIA every 5 years, it was seen
that there was around 30% more
reduction in cervical cancer cases and
subsequent mortality in the bottom
1/3rd of the income population group as
compared to upper 2/3rd of the income
group in India. Similarly, in terms of
financial risk protection, bottom 1/3rd of
the income group had greater reduction
in OOP expenditure (INR 1073 vs INR 770
respectively) and more households
averted catastrophic health expenditure
(520 vs 245 respectively) as compared to
upper 2/3rd in the cohort of 1 lakh
women screened with VIA 5 yearly

POLICY BRIEF
PAGE 02
8

<!-- page 21 -->

Conclusion
Introduction of screening leads to reduction in
occurrence of cervical cancer cases from 19% to 58%
along with decrease in cancer deaths from 28% to
70% as compared to no screening in a lifetime
cohort of 1 lakh women. This further implies
reduction in lifetime risk of cervical cancer among
Indian women from 2.18 in the case of no screening
to 0.879 - 1.729 with implementation of various
screening strategies. Furthermore, the decrease in
incidence cancer cases with screening led to savings
in terms of lifetime reduction in per women OOP
expenditure of INR 636 (USD 9.6) to INR 810 (USD
12.2). Finally, the study concludes that among
various screening strategies, VIA every 5 year is the
most cost effective screening method in the context
of India.

Cost and cost effectiveness
1. The overall lifetime cost incurred by the cohort of 1
lakh women in the scenario of no screening was INR
194 million (USD 2.93 million) and treatment
expenditure (on invasive cancer) constituted 90% of this
cost (INR 175 million; USD 2.65 million) (Table 6).
Similarly, among various screening scenarios, the
overall cost ranged from INR 327 (USD 4.94 million) to
INR 951 million (USD 14.38 million) and the treatment
expenditure constituted 12% (INR 114 million; USD 1.72
million) to 42% (INR 137 million; USD 2.07 million) of
the overall cost. This proportional decrease in the cost
of treatment during the scenario of screening led to
savings in terms of lifetime reduction in per women
OOP expenditure of INR 636 (USD 9.6) to INR 810 (USD
12.2) among various screening strategies.
2. The incremental cost per QALY gained with screening
Figure 1: Annual number of cases and age-specific
incidence
rates of cervical cancer in India (estimates
varied from of INR 33,354 (USD 504) to INR 92,209 (USD
for 2018
1394) as compared to no screening as shown in table 8.
Similarly, the incremental cost per cervical case prevented and death averted was found to be in the
range of INR 598,675 (USD 9050) to INR 284,815 (USD 4306) and INR 682,287 (USD 10,314) to INR
264,715 (USD 4002) respectively with various screening strategies as compared to the scenario of no
screening.
Acknowledgement:
The study was conducted by Postgraduate Institute of Medical Education
and Research (PGIMER) Chandigarh, a resource hub of HTAIn, DHR, MohFW
References:
1) World health Organisation
2) https://hpvcentre.net/statistics/reports/IND.pdf
3) https://hpvcentre.net/statistics/reports/IND_FS.pdf

POLICY BRIEF
PAGE 039

<!-- page 22 -->

Expanding Informed Contraceptive Choice
for Indian Women Will Nexplanon Matter?

<!-- page 23 -->

Expanding Informed Contraceptive Choice for
Indian Women: Will Nexplanon Matter?
Policy Brief

Health Technology Assessment in India (HTAIn)
National Institute of Reproductive Health (NIRRH), Mumbai

Recommendations
Addition of Nexplanon to current
Family planning scenario in the
public health sector of India is
found to be cost-effective. It
could be considered for program
introduction to improve the
contraceptive basket of choice in
a phased manner. The model
shows that larger the proportion
of method users, the higher is the
cost-effectiveness.
The pre-requisites recommended
for Nexplanon introduction into
the public health sector of India
are recommended to be:
Conducting feasibility and
acceptability studies before
introducing Nexplanon with due
consideration to ethical issues of
autonomy and coercion.
Creating awareness regarding
Nexplanon among all
stakeholders and eligible couples.
Program introduction could be
phased top-down from Medical
Colleges to 24X7 PHC level
manned by Medical Officers
(MBBS), as Nexplanon requires
surgical removal.

Summary
Currently, India’s National family planning program has two Long Acting Reversible
Contraceptive (LARC) methods: Copper-Intra Uterine Device-380-A and Depot Medroxy
Progesterone Acetate (DMPA) three-monthly injections. The policy question of whether
another LARC (Nexplanon, a sub-dermal contraceptive implant) should be added to this
basket is addressed in this brief. Health Technology Assessment (HTA) has been the chosen
approach to explore this question. Literature review, primary data collection for costing and
economic evaluation via decision analytic modelling was done as a part of HTA. The decision
analytical model, which is a mathematical model, that simulates reality, showed that an
additional cost of 17,716 INR will be incurred by the Indian government to gain one Quality
adjusted life year (QALY) if Nexplanon is added to the current basket of contraceptive
choices in the public health system. This shows that the intervention is very cost-effective,
using the comparator as the threshold of GDP per capita.

Context and Gap Analysis
India’s journey of providing family planning services to her people has seen multiple
shifts in focus and strategy. The current approach tries to balance the demographic
(population stabilization) and the health (improving, maternal, adolescent and child
health) and economic benefits of family planning. The unmet need of spacing methods of
contraception has increased over the past few decades(1). To counter this, one of the
strategies has been to roll-out new contraceptives. The launch of two new contraceptives
into the public health system of India in recent years: the injectable contraceptive
Medroxyprogesterone acetate (MPA) named as ‘Antara’ and the contraceptive pill,
named ‘Chhaya’; reiterates this strategy of the National family planning program (2).
Including these, we currently have seven modern contraceptive methods in our
program.
Indian Council of Medical Research (ICMR) has conducted a phase-3 clinical trial on
Implanon during 2004-2008 enrolling 3119 women across India. Implanon was offered
along with other existing contraceptive methods available in the National family welfare
program. The relative acceptability of Implanon was observed to be 2.1 % among all
contraceptive methods and 3.4% among spacing methods.

Effective pre-insertion
counselling and preparedness for
management of side-effects by
trained health personnel.
Efficient follow-up and tracking
mechanism for users of
Nexplanon
Figure 1: Shows the implant, Nexplanon

PAGE 01
10

<!-- page 24 -->

Policy Brief

Aims and Objective
This policy brief addresses the policy question of
whether adding a new contraceptive, Nexplanon
into the National Family Planning program in
India would be cost-effective. It summarizes the
results of a Health Technology Assessment study
on Nexplanon, conducted by the HTA Resource
Hub, ICMR-National Institute for Research in
Reproductive Health, Mumbai.

Methods and Approach
To answer the policy question, a ‘Health
Technology Assessment’ (HTA) approach was
adopted. It is a systematic evaluation of properties,
effects, and/or impacts of health technology. HTA
is a multidisciplinary process to evaluate the
social, economic, organizational and ethical issues

About Nexplanon
What is it? A subdermal contraceptive implant, the size of a match stick, inserted beneath
the skin in the upper arm of the woman. Contains 68 mg of Etonorgestrel (Progestin-onlycontraceptive).
How is it different from Implanon? Nexplanon is bio-equivalent to Implanon but has
an addition of barium sulphate that makes it radio-opaque.
Period of use: Approved for a period of three years
Clinical effectiveness: Highly effective. Best among long acting reversible
contraceptives. 0.05% of Nexplanon users would have an unintended pregnancy
during the first year of use(3)
Safety: Commonest side effect is Menstrual irregularities; with Amenorrhea being highest
(30%) and Menorrhagia being at 10%. Headache, acne and weight gain are other reported
side-effects(4).
Return to fertility: Within one month of removal(4)
Insertion and Removal: Requires doctors who are trained in the procedure of insertion
and removal. Removal involves a small incision in the upper arm

of a health intervention or health technology(5). As per the HTA India reference case, QALY is used as a measure of outcome (6). It is a
measure of the state of health of a person or group in which the benefits, in terms of length of life, are adjusted to reflect the quality of life.
One QALY is equal to 1 year of life in perfect health (7)The following steps were followed for the HTA:
1) A systematic review (A systematic review is an appraisal and synthesis of primary research papers using a rigorous and clearly
documented methodology in both the search strategy and the selection of studies (8). for clinical effectiveness of Nexplanon
2) Extensive literature review for other contraceptive methods, costing, cost-effectiveness, quality of life during contraceptive use
and related states and HTA on Nexplanon
3) Primary data collection for collecting cost data from four levels of public health system in Maharashtra
4) Estimation of age specific transition probabilities from Calendar data of National Family Health Survey-4
5) Review of literature on social and ethical issues
6) An economic evaluation to assess whether adding Nexplanon to the current system would be cost-effective. This involved
conceptualization and running a decision analytic model, in our case a Markov model (shown in Figure 2).

Results
The economic evaluation using age specific data on contraceptive use
demonstrates that an additional cost of INR 17,716 would have to be
incurred by the government to gain one additional Quality adjusted life
year (QALY). This is well within the threshold of GDP per capita (about
137945 INR). Represented in Figure 3.

Figure 2: A Decision Analytic Model: Markov Model

1) When a simulated cohort of 15-year olds (from census 2011)
went through the markov model, experiencing the mentioned
health states, about 10.48 lakh pregnancies 1.17 lakh maternal
deaths and 10. 22 lakh child births could be averted by adding
Nexplanon to the public health system.
2) Increase in contraceptive users will improve cost-effectiveness
(shown by sensitivity analysis)

Figure 3. Incremental Cost-Utility Ratio. (Additional cost incurred
by government to gain one QALY)

11
PAGE 02

<!-- page 25 -->

Policy Brief

Budget Impact Analysis
A Budget Impact Analysis (BIA) was done to assess how
introduction of Nexplanon into the Public health system of
India would impact the budget of India. We considered the
additional expenditure for Nexplanon over a period of three
years at different levels of public health care facilities. This
was expressed as a percentage of family planning budget and
as a percentage of health budget. This is depicted in figure
number 4.
Figure 4 shows that expenditure towards Nexplanon will
amount to less than 0.5% of the health budget of the country.
The expenditure for Nexplanon (A) included product of price
of Nexplanon device and estimated number of acceptors,
information education and communication activities, training
of health personnel, incentives on acceptance of Nexplanon

Figure 4. Expenditure for Nexplanon as a percentage of Family
planning Budget and Total health budget

and management of side-effects. The savings (B) due to unintended pregnancies that were prevented due to Nexplanon introduction
were calculated. To calculate net savings over a period of three years, A was subtracted from B. Net savings were estimated to be at ₹
76,04,85,91,940.

References
1. Chaurasia AR, Singh R. 40 Years of Planned Family Planning Efforts In India. :23.
2. National Family Planning Programme [Internet]. Hum Do | Family Planning. 2017 [cited 2019 Feb 1]. Available from:
https://humdo.nhp.gov.in/about/national-fp-programme/
3. Trussell J. Contraceptive failure in the United States. Contraception. 2011 May;83(5):397–404.
4. Hohmann H, Creinin MD. The contraceptive implant. Clin Obstet Gynecol. 2007 Dec;50(4):907–17.
5. WHO | Health technology assessment [Internet]. WHO. [cited 2019 Feb 4]. Available from:
https://www.who.int/medical_devices/assessment/en/
6. HTA in India A Manual by DHR MOHFW . Oct 2018
7. Glossary [Internet]. NICE. [cited 2019 Feb 4]. Available from: https://www.nice.org.uk/glossary?letter=q
8. What is a Systematic Review - Systematic reviews - Library guides at QUT [Internet]. [cited 2019 Feb 4]. Available from:
https://libguides.library.qut.edu.au/systematicreviews
9. Kuntz K, Sainfort F, Butler M, Taylor B, Kulasingam S, Gregory S, et al. Overview of Decision Models Used in Research [Internet].
Agency for Healthcare Research and Quality (US); 2013 [cited 2019 Feb 4]. Available from:
https://www.ncbi.nlm.nih.gov/books/NBK127474/

PAGE 03
12

<!-- page 26 -->

Diagnostic Efficacy of Digital
Hemoglobinometer (TrueHb), HemoCue
and Non- Invasive Devices for Screening
Patients for Anemia in The Field Settings.

<!-- page 27 -->

Diagnostic efficacy of digital hemoglobinometer
(TrueHb), HemoCue and non- invasive devices for
screening patients for anemia in the field settings
Health Technology Assessment in India (HTAIn)
Indian Institute of Public Health, Delhi (PHFI)

Recommendations
Invasive devices shows overall
better performance than Noninvasive devices in the field
settings.
For screening of Anemia,
HemoCue (AUC 0.92, 95% CI 0.880.94) and True Hb (AUC 0.85, 95%
CI 0.83-0.89) are comparable with
no statistically significant
difference between the two.
For screening of Severe Anemia,
TrueHb (AUC 0.91, 95% CI 0.850.97) fares better than all other
devices including HemoCue (AUC
0.73, 95% CI 0.67-0.79)
Both True Hb and HemoCue
overestimates Hb in extreme cold
weather conditions.
Overall it appears that TrueHb is
better than HemoCue in
estimating Hb including severe
anemia
The cost of True Hb device is less
but the running cost is high as
compared to HemoCue. The cost
of true Hb device is less but it's
running cost is more than
hemocue. The running cost to the
health system for measuring each
test is RS 24.4 in rural areas for
hemocue while it is RS 38.7 for
true Hb. Considering operational
issues, and accuracy across
different weather conditions true
hb seems to fare better than
hemocue

Policy Brief

Summary
A Heaith Technology Assessment was conducted to establish the diagnostic accuracy of Digital
Hemoglobinameter TrueHb (newer version), HemoCue and Non invasive Masimo and AJO
spectroscopic device against automated analyzers (gold standard) for screening of anemia in
laboratory and community settings. Invasive devices shows overall better performance than
Non-invasive devices in the field settings. Among the invasive devices TrueHb fares better
than all other devices including HemoCue in case of severe anemia.

Background
Anaemia, defined as a low blood haemoglobin concentration and it has been shown to be a
public health problem that affects low-, middle- and high-income countries and has
significant adverse health consequences, as well as adverse impacts on social and economic
development. Most reliable methods for hemoglobin estimation requires equipped
laboratory that may not be available everywhere, especially rural areas. Moreover these
methods are not always cost effective and have operational challenges. Therefore, it is
important to evaluate simple, cost-effective, user friendly and portable methods for
diagnosis of anaemia where there are no or minimal laboratory facilities.
A comprehensive Health technology assessment (HTA) was conducted to assess and to
obtain the evidence against the clinical and cost-effectiveness of various devices for
hemoglobin estimation. The study was intended to get a scalable method of hemoglobin
estimation, even to “Hard to Reach” can be obtained and this method could be incorporated
with the public health programs for anemia prevention. The primary objective of the
study was to establish the diagnostic accuracy of Digital Hemoglobinometer TrueHb
(newer version), HemoCue and non invasive devices ( AJO Spectroscopic device and
Masimo Pulse Oximeter) against automated analyzers (gold standard) for screening of
anemia in laboratory and community settings. The study also aimed to establish the level
of agreement in the classification of anemia as reported by ANM (using the device that will
be found better) and laboratory technician. The study concluded Invasive devices shows
overall better performance than Non-invasive devices in the field settings.

Devices available for Hemoglobin Estimation

(a)

(b)

Figure 1: Invasive (a) TrueHb (b) HemoCue
13
PAGE 01

<!-- page 28 -->

Policy Brief

(c)

(d)

Figure 2: Non-Invasive (c) Masimo's device (d) AJO spectroscopic device

Findings
A total number of 1398 patients were included in the analysis, 752 in Puducherry and 646 in Kolkata. Their distribution as per ICMR
Classification of Anemia is given below (Table 1).
Table 2 shows the Diagnostic Accuracy Parameters for testing anemia and no anemia by ANM/ frontline workers (capillary sample) is
given below. The overall performance of Hemocue is better as compared to all other devices with a sensitivity of 89.9% and Area under
ROC of 0.92.

Table 1

Table 2

Table 3

Table 4

Table 3 shows Diagnostic Accuracy Parameters for testing severe
anemiaby ANM/ frontline workers (capillary sample) is given
Table 5
below. The overall performance of TrueHb fares better than any
other device with a sensitivity of 87.1% and area under ROC of 0.91.
Projected costs of resources for each test for measuring Hemoglobin
(in INR) is given in table 4.
Table 5 shows the costs of the device and running cost for each test
for measuring Hemoglobin (in INR). The cost of true Hb device is less
but it's running cost is more than hemocue. The running cost to the
health system for measuring each test is Rs. 24.4 in rural areas for hemocue while it is Rs. 38.7 for true Hb. Considering operational issues,
and accuracy across different weather conditions true hb seems to fare better than hemocue

Conclusion
Invasive devices shows overall better performance than Non-invasive devices in the field settings and among the invasive devices TruHb
appeared to perform better be . Overall it appeared that TrueHb is better than HemoCue in estimating Hb including severe anemia. However,
both the devices over estimate Hb in cold and high altitude. TrueHb is also cheaper than HemoCue but the running cost is higher than HemoCue.

PAGE 0214

<!-- page 29 -->

Health Technology Assessment of Uterine
Balloon Tamponade for Management of
Postpartum Haemmorhage in India.

<!-- page 30 -->

Health Technology Assessment in India
Department of Health Research, MoHFW

Health Technology Assessment of Uterine Balloon
Tamponade for Management of Postpartum
Haemmorhage in India
SUMMARY
In

the

year

maternal

2015,

there

deaths

maternal
more

POLICY BRIEF

globally.

deaths

than

occur

half

were

of

in

them

an

estimated

Nearly

99

developing
occurring

303,000

%

of

countries

in

sub-

all
with

Saharan

Need of the Study:
Given

the

availability

uterine

balloon

UBTs

in

of

tamponade

management

of

effectiveness

of

PPH,

the

effective uterine balloon tamponade in the public

death

is

treatable

post-partum

causes

of

hemorrhage.

maternal

Operational

health

system.

Guidelines on Maternal and Newborn Health in India

effectiveness

for

India.

management

of

PPH,

guidance

Note

on

PPH

No

of

introducing

Indian

the

and

on

of

Africa and one third occurring in South Asia. One of
preventable

keen

and

types

government

top

is

different

studies

uterine

a

cost

describe

balloon

cost

tamponade

in

management and Dakshata Guidelines recommend use
of

intrauterine

cases

or

balloon

refractory

management
Tamponade
includes
ESM

decision

bleeding
Various

devices

available

uterine

packed

tree

UBT

model

for

cases

fails.

condom

UBT,

tamponade

uterine
when

Balloon
the

balloon

tamponade

devices

like

Bakri

for

a

was

medical

Uterine
across

used

atony

world
device,
UBT.

A

hypothetical

cohort of women with atonic PPH in India. A primary
costing

study

across

five

public

health

centers

in

Maharashtra centers was performed. The QALYs per
woman

in

condom

UBT,

ESM

UBT

and

Bakri

UBT

were 23.767, 23.769 and 23.763 respectively showing
a very minute difference in QALYs.

Objective: To evaluate cost-effectiveness of Condom
Uterine
in

balloon

Govt.

PPH)

of

India’s

against

tamponade

device

(that

has

guidelines

ESM-UBT

techniques

and

been
for

management

Bakri

available

recommended

uterine

for

of

balloon

management

of

atonic type of postpartum hemorrhage.

Recommendations:
Analysing

the

net

health

benefits

based

on

QALY,

there

is

less

than

0.1

difference

between

the

Condom, Bakri & ESM-UBT alternatives; indicating the similarity in health benefits of the three UBTs.
ICUR value of ESM UBT against Condom UBT shows

that

ESM UBT is only 42.8% cost-effective.

Good quality efficacy data on ESM-UBT should be generated by doing RCTs in Indian settings, before
any

decision

regarding

the

same

is

undertaken.

Considering

the

above

statements,

decision-making

regarding ESM UBT’s introduction into the public health system must be made with caution.
If ESM-UBT is considered for introduction, it should be noted that to gain the benefits estimated by the
model, a universal coverage needs to be attained (100%) which currently seems to be very challenging
given

the

current

Guidelines.

poor

use

of

condom

UBT

in

spite

of

being

recommended

in

the

Govt.

of

India

15

<!-- page 31 -->

Table

4

shows

maternal

deaths

averted

due

to

intervention. ICURs are mentioned in the table 5. Annual
deaths

and

surgeries

averted,

monetray

savings

are

mentioned in Table 6.
Findings: Of total 2,07,85,669 births in India in the year
2017-18, by applying incidence of PPH and the effectiveness
of medical management, we estimated that 59,862 women
will require UBT. In this cohort, our model estimates the
total costs, deaths, QALYs, DALYs and surgeries of each of
the three decision trees as presented in Table 1.

Table
for

2

the

shows
two

the

incremental

comparisons

UBT

and

Bakri

Primary

and

secondary

i.e.

UBT

costs

ESM
vs.

and

UBT

outcomes,

vs.

Condom

outcomes

are

Condom
Balloon.

presented

in

Table 3

Budget

impact

budget

required

analysis
for

shows

that

introduction

annual

of

ESM

additional
UBT

into

India’s public health system is estimated to be 0.004 % of
the total health budget and 0.005% of the total maternal
and child health budget.
Conclusion:
Clinical
currently

effectiveness
limited

to

data

available

few

case

a

for

ESM-UBT

studies.

ICUR

is

values

suggest ESM-UBT to be cost-effective as compared to
condom
shows

UBT,

that

only

but
a

probabilistic

43%

sensitivity

probability

that

analysis

ESM-UBT

are

cost-effective given the uncertainties. Decision making
for

introducing

ESM-UBT

should

be

made

with

caution.

References:
1) Maternal mortality [Internet]. [cited 2019 Jul 19]. Available from: https://www.who.int/news-room/factsheets/detail/maternal-mortality
2) Sample Registration Survey. (2018). SPECIAL BULLETIN ON MATERNAL MORTALITY IN INDIA

http://www.censusindia.gov.in/vital_statistics/SRS_Bulletins/MMR%20Bulletin-2014-16.pdf
3)

Balloon

Tamponade

for

Atonic

Primary

Postpartum

Acknowledgement:
The

2014-16. MMR India [Internet]. 2016; Available from:

Hemorrhage

-

Tabular

View

-

ClinicalTrials.gov

[Internet]. [cited 2019 Jul 25]. Available from:https://clinicaltrials.gov/ct2/show/record/NCT02430155

study

was

conducted

by

National

Institute

for

Research in Reproductive Health
(NIRRH-ICMR)

16

<!-- page 32 -->

Evaluation of pulse oximetry as a tool to
prevent childhood pneumonia related
morbidity and mortality.

<!-- page 33 -->

Health Technology Assessment in India (HTAIn)
Department of Health Research, MoHFW
Regional Technical Resource Centre for HTA, SCTIMST Trivandrum

Evaluation of pulse oximetry as a tool to prevent childhood
pneumonia related morbidity and mortality
Summary

Recommendations

Pneumonia is the leading cause of
death in children <5 years of age and
it is estimated that pneumonia is
responsible for 15% of childhood
deaths worldwide.1,2 This study
primarily aimed to determine the
cost-effectiveness of pulse oximetry
devices in the screening of childhood
pneumonia by health workers in
resource-poor settings. Using a
systematic review, a decision-tree
modeling exercise and a budget
impact analysis, the following
findings were observed;



 The evidence from the systematic
review was in favour of the use of
pulse oximetry along with the
existing guidelines
 The deaths averted due to
childhood pneumonia when
IMCI+PO is used instead of IMCI
alone is 21 and 36 per 1000
patients when the sensitivity of
pulse oximetry is assumed at
70% and 85% respectively. The
ICER for both sensitivities shows a
negative value suggesting that
PO, when added to the existing
IMCI, would become a costsaving intervention.
 The costing and budget impact
analysis
showed
that
the
introduction of pulse oximeter
along with existing IMCI will
increase the cost per patient
per year by INR 0.36 only. The
overall cost of roll-out of pulse
oximeters in PHC’s in India
would
amount
to
INR
9,04,59,000.








Integrated Management of Childhood Illness (IMCI) guidelines along with
Pulse Oximetry (PO) is a cost-saving prognostic tool as compared to IMCI
alone provided there is supplementary oxygen availability.
IMCI should be the basic prognostic tool for childhood pneumonia but PO is
beneficial in the referral of cases. Pulse oximetry, in general, may be used to
measure oxygen saturation in cases wherever required.
Among outpatients with pneumonia, peripheral oxygen saturations
(SpO2)<90% were associated with increased morbidity and mortality. A
hospital admission threshold of <92% would be safer and clinically better
justified. All severe cases irrespective of the availability of Pulse oximeter
will be referred to a tertiary care facility for expert management.
In tertiary care, when SpO2 ≥ 80%, pulse oximetry has high accuracy in
estimating oxygen saturations and may be used instead of (Arterial Blood
Gas) ABG; in patients with SpO2 < 80%, however, the evaluation of
oxygenation by pulse oximeter is not a good substitute for ABG analyzer.
In tertiary care hospitals, especially in ICU’s, multipara monitors which
measures advanced parameters like ECG, Respiration, Pulse Rate,
Temperature should be preferred

Background
Globally, pneumonia is the leading cause of death in children <5 years of age.
Despite interventions being available, it is estimated that pneumonia is responsible
for 15% of childhood deaths worldwide.1,2 The present recommended strategy for
diagnosis and prognosis of pneumonia is IMCI tool for professional health workers
at health facilities and Integrated Community Case Management (iCCM) tool for
community health workers. In the absence of appropriate prognostic tools at the
frontline, currently recommended World Health Organization (WHO) guidelines
for integrated management of childhood illness (IMCI) often lead to an overuse of
antibiotics and the under-referral of patients with severe pneumonia who require
hospital care.3,4 Currently, the identification of these IMCI symptoms remains
inconsistent and unreliable among health-care personnel.

Objectives:
To determine the effectiveness (i.e. sensitivity, specificity, positive and negative
predictive values) and cost-effectiveness of pulse oximetry devices in the screening
of childhood pneumonia by health workers in resource-poor settings (LMICs) & to
identify whether children have lower mortality rates, lower morbidity, and shorter
length of stay where pulse oximeters are used to inform diagnosis and treatment
compared with where pulse oximeters are not used.

17

<!-- page 34 -->

Methods:

A systematic literature review (SLR) was conducted with PICO as a population consisting of patients aged 0-5 years with
pneumonia in low and middle income countries (LMICs). Intervention was IMCI +Pulse Oximetry and the comparator was
IMCI alone. The outcomes were diagnostic accuracy of pulse oximetry, cost per Quality Adjusted Life Years (QALY) gained,
and incremental deaths averted with the introduction of pulse oximetry. The SLR was conducted using electronic
databases such as Database of Cochrane, PubMed, Web of Science, ProQuest, Google Scholar and WHO Global Health
Library, with no language restrictions.
We extracted the costs of the IMCI implementation in Indian primary healthcare settings from previous studies. The
average number of hospital visits (outpatient and inpatient) were calculated including the associated out of pocket health
expenditure for each category. We indexed the amount to the current INR rate using inflation tools. Pulse oximeters which
fit the predefined specifications were shortlisted and their net average cost was taken for costing purposes. The training
cost was derived from consultation with the program implementers.
A decision tree model was developed for estimating the Incremental Cost Effectiveness Ratio (ICER). For populating the
model, we required data pertaining to disease progression, care-seeking, healthcare, prognostic and cost parameters. In
addition to data gathered from SLR, we did a scoping review wherever necessary to extract data for the decision model.

Systematic Review – Result Summary
Out of the seven studies which were eventually shortlisted, 6 of them favoured the use of Pulse Oximetry. In general, the
states having a high prevalence of pneumonia risk factors and poor access to health services had a higher burden of
pneumonia cases and deaths.5 Although hypoxemia is common, the absence of routine pulse oximetry results in most
hospitalized hypoxemic children not receiving available oxygen treatment. It is important to recognize that referral/
admission rates are dependent on the thresholds for oxygen therapy.
Clinical signs alone are poor predictors of hypoxemia, and using pulse oximetry in resource-poor health facilities to target
oxygen therapy is likely to save costs. The fingertip pulse oximeter was deemed the most usable and scalable in most of
the studies. There is evidence to indicate that pulse oximetry may lead to improved health outcomes, with lower mortality
rates (when combined with improved/adequate oxygen administration); pulse oximetry may change physicians’
decisions regarding illness severity, and increase hospital admissions related to previously unrecognized hypoxemia.
Oximetry can reduce resource waste by indicating when to end treatment, and by decreasing false positives.

Economic Evaluation – Result Summary

A decision tree was parameterized on a spreadsheet to
estimate the incremental cost-effectiveness of
implementing pulse oximetry + IMCI program over IMCI
alone. A lifetime study horizon starting from the base year
of 2019 was considered appropriate to cover all costs and
effects comprehensively. Pneumonia has a predominant
risk within the first 5 years of life, with gradually
declining risk until about 15 years.

In absolute terms, the introduction of pulse-oximetry
devices to IMCI is estimated to result in annual reductions in
pneumonia deaths in India. The deaths averted per year for
PO2 within a cohort of 10000 pneumonia cases would be 367
if the sensitivity is 85% and 213 if the sensitivity is 70%.
Owing to the large under-five population (128 million) India
could significantly reduce the mortality due to childhood
pneumonia by the introduction of PO into the existing IMCI.
We found that the ICER is -117.32 and -18.75 when the
sensitivity of the IMCI+PO is 85% and 70% respectively. This suggests that it is a cost-saving intervention from a societal
perspective.

18

<!-- page 35 -->

Results of Cost-effectiveness of IMCI + PO as compared to IMCI Alone
Intervention
Cost (in INR)
LY
QALY
ICER
IMCI (0.55)
3,22,47,526
601736.1
601736.1
-117.32
IMCI+PO (0.85)
2,95,03,112
625127.9
625127.9
Intervention
Cost (in INR)
LY
QALY
ICER
IMCI (0.55)
3,22,47,526
601736.1
601736.1
-18.7521
IMCI+PO (0.7)
3,19,93,096
615304.17
615304.17
*Number given in brackets in the first column is the sensitivity of each intervention

Budget Impact Analysis - Results Summary

The cost of the roll-out of pulse oximeters for 1.5 lakh health and wellness centres
 Number of health and wellness centres: 150000
 Cost of PO: INR 2500
 Overall cost of PO: 150000*2500 = INR 37,50,00,000
But, as on 31st March 2017, there were only 25650 Primary Health Centres (PHCs) functioning in India 6. If we were to
provide a pulse oximeter to all the PHC’s in India, the cost of the roll-out of pulse oximeters would be INR 6,41,25,000
(25650*2500). The cost of training frontline health workers to use PO is INR 2,63,34,000. The overall cost of the rollout of pulse oximeters in PHC’s would amount to INR 9,04,59,000. The number of functioning Community Health
Centres (CHCs) in India was 5510 as on 31st March, 2016. 7 Each community health centre would require at least 4
finger-tip pulse oximeters which should ideally be placed in the casualty, OP and inpatient ward. The cost of equipping
all the CHC’s with the specified number of pulse oximeters amount to INR 5,51,00,000 (5510*2500*4).

Key Findings
 Pulse oximetry, used in conjunction with clinical guidelines like the IMCI, is beneficial in screening and diagnosis
of pneumonia in the community. It is important to note here that such diagnoses have to be coupled with the
prompt provision of oxygen therapy at the community level institutions, in order to reap the benefits of a more
early and accurate diagnosis.
 The deaths averted due to childhood pneumonia when IMCI+PO is used instead of IMCI alone is 21 and 36 per
1000 patients when the sensitivity is 70% and 85%. When we take a lifetime horizon this results in a QALY gain
of 1356 and 2339 years respectively.
 The ICER for both sensitivities shows a negative value suggesting that PO, when added to the existing IMCI,
would become a cost-saving intervention.
 The costing and budget impact analysis showed that the introduction of pulse oximetry along with existing IMCI
will increase the cost per patient per year by INR 0.36 only.
 The overall cost of the roll-out of pulse oximeters in PHC’s in India would amount to INR 9,04,59,000. The cost
of equipping all the CHC’s with the specified number of pulse oximeters amount to INR 5,51,00,000. The overall
domestic general government health expenditure per capita for India is US$61.40 8. For a three trillion dollar
economy which spends 1.15% of its GDP on healthcare, the implementation of the IMCI+PO would cost only
0.003% of its annual budget.
 The decision tree was able to show that on top of the large reduction in deaths due to pneumonia, the addition
of pulse oximetry to IMCI has the potential to increase the correct treatment of severe cases. Thus, pulse
oximetry appears to be both an effective and cost-effective option for the government to contemplate
implementation of the same in the primary healthcare institutions.
 In the case of IMCI+PO, the value of ICER was less than the GDP per capita in all simulations as part of the
probabilistic sensitivity analysis. The sensitivity analysis also showed that the majority of the values fell into
the right lower quadrant, signifying ICER to be negative with gain in QALYs and less cost incurred in the
intervention scenario.

19

<!-- page 36 -->

Conclusion
The evidence from the systematic review was overwhelmingly in favour of the use of pulse oximetry along with the
existing guidelines. The deaths averted due to childhood pneumonia when IMCI+PO is used instead of IMCI alone
is 21 and 36 per 1000 patients when the sensitivity of pulse oximetry is assumed at 70% and 85% respectively.
When we take a lifetime horizon this results in a QALY gain of 1356 and 2339 years respectively. The ICER for both
sensitivities shows a negative value suggesting that PO, when added to the existing IMCI, would become a costsaving intervention. The costing and budget impact analysis showed that the introduction of pulse oximeter along
with existing IMCI will increase the cost per patient per year by INR 0.36 only. The overall cost of roll-out of pulse
oximeters in PHC’s would amount to INR 9,04,59,000. The cost of equipping all the CHC’s with the specified number
of pulse oximeters amount to INR 5,51,00,000. The overall domestic general government health expenditure per capita
for India is US$61.407. For a three trillion-dollar economy which spends 1.15% of its GDP on healthcare, the
implementation of the IMCI+PO would cost only 0.003% of its annual budget.

References
1. Rudan I, Boschi-Pinto C, Biloglav Z, Mulholland K, Campbell H. Epidemiology and etiology of childhood pneumonia.
Bull World Health Organ. 2008 May;86:408-416B.
2. Liu L, Oza S, Hogan D, Perin J, Rudan I, Lawn JE, et al. Global, regional, and national causes of child mortality in
2000–13, with projections to inform post-2015 priorities: an updated systematic analysis. The Lancet. 2015 Jan
31;385(9966):430–40.
3. Izadnegahdar R, Cohen AL, Klugman KP, Qazi SA. Childhood pneumonia in developing countries. Lancet Respir Med.
2013 Sep 1;1(7):574–84.
4. Rodrigues CMC. Challenges of Empirical Antibiotic Therapy for Community-Acquired Pneumonia in Children. Curr
Ther Res. 2017 Jan 1;84:e7–11.
5. Farooqui H, Jit M, Heymann DL, Zodpey S. Burden of Severe Pneumonia, Pneumococcal Pneumonia and Pneumonia
Deaths in Indian States: Modelling Based Estimates. PLoS ONE [Internet]. 2015 Jun 18 [cited 2019 Jul 24];10(6).
Available from: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4472804/
6. State/UT-wise Functioning of Primary Health Centres as on 31st March 2017 [Internet]. Open Government
Data(OGD) Community. [cited 2019 Aug 17]. Available from: https://community.data.gov.in/state-ut-wisefunctioning-of-primary-health-centres-as-on-31st-march-2017/
7. Functioning Community Health Centres (CHCs) as on 31.03.2016 [Internet]. Open Government Data(OGD)
Community. [cited 2019 Aug 20]. Available from: https://community.data.gov.in/functioning-community-healthcentres-chcs-as-on-31-03-2016/
8. Domestic general government health expenditure per capita, PPP (current international $) | Data [Internet]. [cited
2019 Aug 19]. Available from: https://data.worldbank.org/indicator/SH.XPD.GHED.PP.CD?locations=IN

20

<!-- page 37 -->

Cost Effectiveness Analysis of Hypothermia
Detection Devices (BEMPU, ThermoSpot and
Fever Watch) for Premature and Low Birth
Weight Neonates in India.

<!-- page 38 -->

Health Technology Assessment in India
Department of Health Research, MoHFW

Cost Effectiveness Analysis of Hypothermia Detection Devices
(BEMPU, ThermoSpot and Fever Watch) for Premature and
Low Birth Weight Neonates in India

POLICY BRIEF
SUMMARY
Hypothermia

has

Organization

(WHO)

normal

(36.5°C

range

been

defined

as

body

–

by

World

temperature

37.5°C)

and

has

Health

below
been

Recommendation

the

sub-

classified into three grades; mild (36.0°C – 36 .5°C),
moderate

(32.0°C

hypothermia.

–

35.9°C),

Premature

and

and

severe

Low

(<32.0

Birth

C)

Weight

(LBW) neonates are at a greater risk for hypothermia
because

they

regulation
reaches
arise

a

lack

body

fat

and

system.

Often

it

goes

severe

and

standard

can

of

state
even

care

where
lead

(SoC)

poor

thermal

undetected

several

to

for

have

until

it

complications

death.

detecting

The

current

hypothermia

includes measuring the body temperature of neonates
every

six

neonatal
and

hours

with

an

axillary

thermometer

intensive

care

unit

(NICU).

Early

continuous

monitoring

for

at

detection

hypothermia

is

desirable to prevent progression of hypothermia from
the

mild

range

lead

to

further

assess

the

detecting
Fever

to

a

severe

complications.

cost

devices

Watch

more

to

condition

This

effectiveness
such

as

study
of

BEMPU,

monitor

the

that

can

aimed

to

hypothermia

ThermoSpot

body

and

temperature

continuously and give either a visual or audio- visual
alert when the new-born’s body temperature drops, in
NICU

setting

neonates
of

the

in

for

India.

premature

and

This

concluded

interventions

are

study

low

cost-saving

Based on the ICER value, the CEA shows that
Bempu

and

Thermospot

are

not

cost-effective

devices for detecting hypothermia in premature
and low birth weight neonates in India.
Considering

that

devices

provide

opposed

to

care,

could

we

higher

in

practical

continuous

intermittently

cost

if

have

they

these

monitoring

by

the

accepted

resulted

terms

in

standard

marginally

an

increase

in

life years, but this was not the case.
When

data

becomes

available

of

its

use

in

a

community setting; with the device being worn
by

discharged/at

the

CEA

could

home
be

pre-term

re-visited

babies,

with

then

the

fresh

device

will

barriers

like

data.
It

is

not

worth
be

a

remembering
remedy

for

that

the

societal

gender based discrimination, neglect of female
new-borns
country

that

nor

exist

of

in

poor

some

parts

awareness

of
of

the
post

detection care of new-borns.
Additionally, it has been claimed that neonatal
hypothermia

is

more

about

due

to

the

hypothermia

lack

weight

knowledge

that

neither

prevention rather than lack of equipment.

a

of

the

birth

from

as

and

of
its

societal

perspective.

BEMPU HYPOTHERMIA ALERT DEVICE

FEVER WATCH

21

Conducted by Indian Institute of Public Health Shillong (IIPHS)

<!-- page 39 -->

Objective:

To

Hypothermia
against

Alert

the

detection

assess

the

device,

standard

of

cost

of

ThermoSpot

care

hypothermia

effectiveness

i.e.

among

and

of

BEMPU

Fever

thermometer

premature

and

Watch

in

early

low

birth

hospital

Hypothermia

(prevalence

way

sensitivity

is

common

range,

32%

in

to

infants

85%)

and

born
at

at

home

quadrant
that

of

the

range,

11%

to

92%),

even

in

to

simulation

newborns,

with

it

the

highest

would

require

temperature

monitoring

to

progressing.

However,

SoC

designed

for

facility

literate

caregivers.

hypothermia

level

prevalence
frequent

prevent

available,

care,

which

devices

LBW

continuous

condition

is

Non-invasive

detecting

this

it

from

is

largely

requires

health-

newly

specifically

presented

interventions lie

(Fig

are

analysis

not

use

2).

performed

(PSA).

Tornado

in north-west
implies

cost-effective

standard

3

shows

part

of

In

a

which

of

Fig
as

plane

in

the

of

care

results
the

when
with

from

a

probabilistic

analysis,

we

reported

tropical

among

or

are

cost-effectiveness

optimum

Thermometer

findings

environments

the

interventions

sensitivity

(prevalence

analysis

Diagram in Fig. 1. Both

compared

weight neonates in India.
Rationale:

one

by

product

of

considering
India

as

on

per

capita

April

2019

gross
as

domestic

threshold

for

determining the cost- effectiveness. India had a GDP per
capita of INR. 1, 42,034 (2045.794 USD) in April, 2019
as per Census and Economic Information Centre (CEIC)
data.

introduced
designed

for

newborns, monitor the neonate’s body temperature around
the clock and gives either a visual or audio-visual alert

Findings:
estimated

Cost-effectiveness
from

societal

analysis

perspective.

results

Table-1

shows

were
cost

parameters of intervention and standard of care. Results of

Conclusion
The

analysis

carried

neither

of

the

societal

perspective.

out

in

interventions
Based

this
are

on

study

cost

the

shows

saving

ICER

that

from

value,

a

this

CEA shows that Bempu and Thermospot are not costeffective

devices

premature

LBW

carried

out

designed

for

detecting

neonates.

based

primary

on

very

study

hypothermia

However,
limited

that

this

study

evidence,

generates

good

a

in
was

well-

quality

evidence, would enable revisiting the CEA especially
in
References:

community

settings,

which

is

potentially

the

setting where the use of such devices is needed.

1) https://www.viaglobalhealth.com/product/bempu-hypothermia-device/
2) https://www.deccanchronicle.com/gadgets/110116/watch-ing-over-your-childs-health.html
3) Lunze, K., Bloom, D. E., Jamison, D. T., & Hamer, D. H. (2013): The global burden of neonatal hypothermia:
Systematic review of a major challenge for newborn survival, BMC Medicine, pp. 11-24.

22

<!-- page 40 -->

Health Technology Assessment of Portable
Automated ABR Neonatal Hearing Screening
Device.

<!-- page 41 -->

Policy Brief
February 2020

Health Technology Assessment in India (HTAIn), Department of Health Research, MoHFW
Regional Medical Research Centre (RMRC), Bhubaneswar

Health Technology Assessment of “Portable Automated ABR”
Neonatal Hearing Screening Device
Summary of findings
 Clinical efficacy, cost-effectiveness and operational challenges were assessed in the implementation of ‘Portable Automated
ABR’ neonatal hearing screening devices in health-care facilities of Odisha.
 “Portable Automated ABR”, designed based on the principle of BERA, developed by the School of International Bio design
(SIB), Dept. of Biotechnology (DBT) Govt. of India.
 It was found to be cost-effective as compared to OAE and can be used as a part of Universal Health Coverage (UHC) of hearing
screening among infants in out-reach areas.

Background
Hearing impairment is one of the leading contributors to years lived with a
disability, with over 5 percent of the world’s population (360 million people)
currently living with a disabling Hearing Loss (HL). Congenital hearing impairment
in infants and children has been linked with lifelong deficits in speech and
language acquisition, poor academic performance, individual and social
maladjustments, and emotional difficulties. Excessive emphasis is placed on the
importance of early detection, reliable diagnosis, and timely intervention, as it can
help in developing better skills among the hearing impaired infants equivalent to
their peers.

Policy Recommendations
 For Universalizing the hearing
screening services, provisions of
screening services should be
available at nearest facilities such
as sub-divisional hospital, CHCs,
and if possible at PHCs to reduce
both indirect as well as intangible
cost.
 Portable Automated ABR can be
recommended in out-reach areas
replacing BOA in RSBK at SDHs,
CHCs and PHCs for greater
coverage of UNHS.

Figure 1: Effects of hearing impairment
on child development
Studies indicated a prevalence of 5-6 per 1000 live births in India [1], of neonatal
hearing loss (HL), with highly considerable repercussion on lifelong disability and
Quality of Life (QoL). However, this figure only indicates a tip of the iceberg as the
majority of hearing impairment cases remain undetected [2, 3].

 It is suggested to conduct a small
scale implementation using
existing infrastructure to identify,
if any, operational challenges of
the implementation as well as
facilities available for cochlear
implant for assessing budgetary
implications before a large scale
implementation.

1
23

<!-- page 42 -->

As per RBSK program, an Otoacoustic Emission (OAE) is used at the facility level, while Behavioural Observation Audiometry
(BOA) is adopted at the community level for hearing screening. For further confirmation, it is followed by Brainstem Evoked
Audiometry Response (BERA) at referral facilities (4). Community-based screening is being carried out using a brief
questionnaire and behavioural testing by a trained health worker during visit of mobile health team (MHT) under RBSK. Any
infant who did not pass the screening is to be followed up at the district hospital for OAE and automated Auditory Brainstem
Response audiometry (AABR) testing.
Major concern associated with the present hearing screening program under Rashtriya Bal Swasthya Karyakram (RBSK) was
that it is provided through the District Early Intervention Centres (DEICs) which are available at the DHH level or higher level
of medical care. In India, where non-institutional deliveries are still among the prevalent practices, the vast majority of the
infants are left out from the early detection and intervention for the hearing impairment. Deliveries at CHC, PHCs and
community level are also among the few missed cases of hearing screening and goes without any intervention or treatment.
Other issues in the implementation of the program were identified as a lack of human resources, inadequate infrastructure,
equipment-related shortcomings, and low priority for deafness prevention. These indicated the need for a portable
technology which can detect the hearing impairment through first level of screening with better or similar diagnostic accuracy
at various levels of care and at the same time it should be user-friendly too.
The “Portable Automated ABR” is a non-invasive, safe and simple technology been designed based on the principle of BERA.
The device has been developed by the School of International Bio design (SIB) start-up Portable Automated ABR Innovation
Labs India Pvt. Ltd by Dept. of Biotechnology (DBT) Govt. of India. The present Health Technology Assessment (HTA) was
aimed to determine the cost-effectiveness of this technology by comparing Portable ABR against OAE as well as BERA, and
examine the potential ethical implication prior to its introduction into the universal screening program.

Figure 2: Portable Automated ABR Neonatal
Hearing Screening Device

Methods
OAE hearing screening test, which is commonly used under RBSK program, was
compared with ‘Portable Automated ABR’. HTA was classified into three broad
areas: diagnostic validation of ‘Portable Automated ABR’, economic evaluation
and assessment of Quality of Life (QoL) of ‘Portable Automated ABR’, and
ethical and social implication of ‘Portable Automated ABR’ implementation.

Results
‘Portable Automated ABR’ was found to be cost-effective. The sensitivity results
revealed that the ‘Portable Automated ABR’ device had higher sensitivity in
Figure 3: Overview of Health
comparison to OAE. The number of false positive cases were far less in ‘Portable
Technology
Assessment
of stress
Automated ABR as compared to the OAE method, resulting into lower costs (direct, indirect
and intangible),
and less
‘Portable
Automated
ABR’
and anxiety on the families of new-borns. Study revealed that per unit cost for screening a new-born using ‘Portable Automated
hearingscreening device
ABR’ was lower than that of OAE device.

2

24

<!-- page 43 -->

The Portable Automated ABR device was found to be less costly and more effective. Cost-Effective Analyses (CEA) indicates
that implementing Portable Automated ABR in the UNHS program will help in reducing the cost for the health system in long
run but also to significantly reduce the societal cost.

Table I: Expected overall budget
implication for implementation of
Portable Automated ABR at Primary
Health Centres/ Community Health
Centres (CHCs)/Sub-Divisional
Hospitals for hearing screening in
India

Key Findings
 The Portable Automated ABR device has portability and doesn’t requires any
soundproof room.
 The test duration per baby was recorded between 10-15 minutes and it does not
require considerable reliance on high manpower such as audiologist and is user-friendly
in the nature. Hearing screening can be performed by any healthcare staffs, (preferably
a staff nurse) with basic skill based training (3–5 days).
 Per-unit cost for screening a new-born using ‘Portable Automated ABR’ was lower than
that of OAE device.
 Portable Automated ABR can detect 6240 cases and OAE, 9360 cases per annum
- per unit cost of ABR and OAE are INR 97 and INR 67 respectively.
 The UNHS by Portable Automated ABR will cost lesser if we focus on the budgetary
provisions as compared to OAE as it results into
- ICERs -7,17,889 for system implementation.
 Considering the annual birth rate, the prevalence rate of hearing loss, and the high
diagnostic accuracy of device,
- Portable Automated ABR imposes lower costs than the OAE device in long run.
- In absence of skilled manpower can be easily taught to other staffs.

References
1. Khurmi M, Gupta M, Patle A,
Kaur P, Mathur N, Chaudhari
G,
Prabhakar
PK,
Mohammed SK, Khera A.
Improving child survival
under National Health
Mission in India: Where do
we stand? Indian Journal of
Child Health. 2015:49-54.
2. World Health Organization.
New-born
and
infant
hearing screening: current
issues and guiding principles
for action. 2009.
3. World Health Organization.
Global costs of unaddressed
HL and cost-effectiveness of
interventions:
a
WHO
report, 2017. World Health
Organization; 2017.
4. Khurmi MS, Gupta M,
Chaudhari G. Addressing the
public health challenge of
birth defects in India. Indian
Journal of Child Health.
2014:95-8.

3
25

<!-- page 44 -->

Health Technology Assessment of Various
RT-PCR Kits/Methods for the Diagnosis of
Influenza A/H1N1pdm09 Virus in All Age
Group Patients in India.

<!-- page 45 -->

Health Technology Assessment in India
Department of Health Research, MoHFW

Health Technology Assessment of various RT-PCR kits/methods for the
diagnosis of Influenza A/H1N1pdm09 virus in all age group patients in India.

INTRODUCTION
Lower respiratory tract viral infections, including those due to influenza, are among the most common infectious diseases in
humans and they are associated with significant morbidity and mortality. Seasonal influenza viruses infect 5–15% of the
human population each year, resulting in ~500,000 deaths worldwide. A significant number of severely ill patients infected
with H1N1pdm09 requiring intensive care and mechanical ventilation for severe viral pneumonia.
Nucleic acid tests are sensitive and specific and provide a rapid diagnosis, making them invaluable for patient and outbreak
management. Real-time polymerase chain reaction (PCR) can be considered as gold standard for detection of influenza viruses
due to its high sensitivity and specificity. Real time RT-PCR developed by WHO is considered as gold standard method for
influenza A H1N1pdm09 diagnosis from Nasal/throat swabs.
Currently in India, suspected patients are screened by clinician and prescribing Oseltamavir drug without waiting for test
report. Government of India recommended testing of sample from suspected patients of category C only. Indiscriminatory use
of anti influenza anti-viral drug may develop resistance. Limited labs are testing H1N1pdm09 virus in country and have not
been able to effectively implement at large programs due to lack of adequate infrastructure, trained manpower and limited
resources and high costing of kits.

RECOMENDATIONS
1. In view of highest diagnostic accuracy (100%
sensitivity and 100% specificity) among all the kits
evaluated in this study, invitrogen kit is recommended
for diagnosis of Category C patients for influenza
A/H1N1pdm09 virus from clinical samples with an
incremental cost of 355 Rs/test.
2. Diagnostics of H1N1in India, is currently being
provided by ICMR-VRDL and NCDC network and all these
centres are using real time PCR based technique with
Invitrogen kits. The present study reconfirms the fact
Invitrogen kit is most cost effective kit for H1N1
diagnostics with no additional burden to the healthcare
system.

RATIONALE OF THE STUDY
Indiscriminatory use of anti influenza anti-viral drugs
may

develop

resistance.

Limited

labs

are

testing

H1N1pdm09 virus in country and have not been able to
effectively implement at large programs due to lack of
adequate

infrastructure,

trained

manpower

and

limited resources and high costing of kits. Sensitivity,
specificity

and

exhibits

huge

cost

of

variation.

different
The

molecular

purpose

of

tests
this

assessment was to appraise the current evidence for
the clinical effectiveness (in terms of sensitivity and
specificity) and cost-effectiveness of different RTPCR

Figure 1: Forest plot for sensitivity (A) and specificity (B) of
each individual study for overall kit, the pooled estimate are
represented by diamond and the horizontal lines represent
95% confidence intervals (CI).

kits against CDC/WHO real time RT-PCR for diagnosis of
influenza A/H1N1pdm09 in India.

26

<!-- page 46 -->

Table 1: Summary table for key findings of the study

METHODOLOGY
Clinical Effectiveness (Sensitivity & Specificity) Literature Review
The research methodology was designed using PRISMA-P (Preferred Reporting Items for Systematic reviews and Meta-analyses Protocols)
statement guidelines including the preparation of a pre-specified protocol and analysis plan.
Primary Data Collection
Primary data were collected from in-house reports (NIV data), four (n=4) kits evaluated during the financial year 2018-2019.
Validation and costing Study
From four different companies’ influenza diagnosis molecular kits [Thermo Fisher Scientific (Invitrogen); TRUPCR H1N1 kit (3BBlackBio
Bhopal); Qiagen artus Infl./H1 LC/RG RT-PCR Kit; and Cepheid Xpert® Flu kit] were evalauetd and compared with CDC/WHO gold standard kit.

KEY FINDINGS
Literature Review: Diagnostic accuracy of the kits for detection of H1N1 showed huge variation. The sensitivity of different kits varied from
76% to 100% whereas the specificity of different kits varied from 67% to 100% among the studies included in the review. Even for the same kit,
there was huge variation between different studies both for sensitivity and specificity.
Validation Study: Invitrogen kit exhibited the highest sensitivity and specificity for detection of H1N1 among 4 kits evaluated in validation
study.
Costing Study: Cephied kit was most expnsive with cost/test of Rs.4342, whereas TRUPCR was least expensive with cost/test of Rs. 1660.
Operational Feasibility: Integrated Disease Surveillance Programme (IDSP) assisted lab network of 12 Laboratories are providing laboratory
support in terms of testing, providing viral transport medium and diagnostic reagents. The laboratory network of ICMR-VRDL (30 labs) has also
been activated to test for H1N1 cases. All these labs are currently using real time RT-PCR test for diagnosis of influenza H1N1 using Invitrogen
kit. The present study reconfirms that Invitrogen kit is most cost effective kit for diagnosis of influenza H1N1 with an incremental cost of 355
Rs/test. As the kit uses an open system, it could be used in any real time PCR platform. Already being used in the system, the staff is trained in
using the kit also. Therefore, there will be no addional burden in terms of procuring new platforms, or training of staff and cost of kits.
Cost Effectiveness: If only H1N1 detection (not considering H3N2 and Influenza B) is considered for deciding the cost effectiveness, TRUPCR kit
dominated over Qiagen and Cephied kit with least cost (1660 Rs/test) and highest accuracy (sensitivity 94%, specificity 100%) among these
three kits, and thus Qiagen and Cephied were excluded from cost-effectiveness analysis. While comparing the TRUPCR kit and Invitrogen kit,
later shows higher accuaray with an incremental cost of 355 Rs/test. If accuracy of overall kit is considered including Influenza A and
Influenza B, Cephied kit can detect both subtypes in single reaction including the subtypes also. In addition to detecting both subtypes, the
Cephied kit can provide results in least of the time. The kit is highly automated and thus easiest to be performed among the four kits. But at
the same time, this kit works in a closed system model, that means the kit works only in a given platform and only 1-4 samples can be tested
in one go, depending upon the machine module being used.
Acknowledgement:
The study was conducted by NIV, Pune as a Regional Resoiurce hub for HTAIn Secretariat, DHR, MoHFW
References
1.
Lim FJ, de Klerk N, Blyth CC, Fathima P, Moore HC. Systematic review and meta-analysis of respiratory
viral coinfections in children. Respirol ogy 2016;21:648-55.
2.
Stöhr, K. Influenza—WHOcares. Lancet Infect. Dis. 2, 517 (2002).
3.
Koul PA, Broor S, Saha S, Barnes J, Smith C, Shaw M, Chadha M, Lal RB. Differences in influenza seasonality b latitude, northern India.Emerg Infect Dis. 2014 Oct;20(10):1723-6.
4.
Chadha MS, Potdar VA, Saha S, Koul PA, Broor S, Dar L, Chawla-Sarkar M, Biswas D, Gunasekaran P, Abraham AM, Shrikhande S, Jain A, Anukumar B, Lal RB, Mishra AC. Dynamics of
influenza seasonality at sub-regional levels
in India and implications for vaccination timing. PLoS One. 2015 May 4;10(5):e0124122.

27

<!-- page 47 -->

Decentralized Screening of Hepatitis B & C at
Primary Health Centres in Tamil Nadu.

<!-- page 48 -->

POLICY BRIEF

DECENTRALIZED SCREENING OF HEPATITIS B & C AT
PRIMARY HEALTH CENTRES IN TAMIL NADU
Health Technology Assessment in India
National Institute for Research in Tuberculosis, Chennai

Summary
A Health Technology Assessment (HTA)
was conducted to establish the costeffectiveness of decentralized diagnostic
program for Hepatitis B Virus (HBV) and
Hepatitis C Virus (HCV) implemented in
Tamil Nadu, with specific focus on a
selected key population at increased risk
of HBV and HCV. It was found that
decentralized HBV and HCV diagnosis
followed by early treatment for HBV and
HCV and vaccination for HBV negatives
can save lives and reduce out-of-pocket

Problem Statement

expenditures.

Viral hepatitis is a major public health problem which

RECOMMENDATIONS

accounts for 2.85% of all deaths in India (1). Hepatitis B virus

Decentralized HBV and HCV diagnosis
at Primary Health Care level followed
by early treatment in selected key
population in Tamil Nadu is an
appropriate intervention to reduce
HBV and HCV burden.
Active screening of selected key
population helps in early
identification of persons with chronic
HBV or HCV infection and enables
them to receive the necessary care

(HBV) is predominant in India affecting nearly 50 million
people with an average prevalence of 4% (2). Chronic HBV
infection leads to liver disorder and accounts for 10-20% of
cirrhosis and 40-50% hepatocellular carcinoma (HCC) in
India (3) HCV remains a major public health problem in India
with an estimated prevalence of 0.5-1.5%. HCV prevalence
among blood donors and pregnant women was found to be
0.44% and 0.88% (4) India has initiated the National Viral
Hepatitis Control Program (NVHCP) in 2018 to eliminate
viral hepatitis by 2030. HCV elimination efforts in India aims
to reduce new chronic infections by 90% and mortality by
65% in comparison to 2015 status (5)

and treatment to prevent or delay
progression of liver disease.

Background

Considering vaccination for HBV

The prevalence of HBV was 1.63% and HCV was 0.30% in

negatives in selected key population
in Tamil Nadu is cost-saving and could
reduce transmission.

Tamil Nadu. Three-fourths of HBV and HCV infected people
were males. Prevalence of HBV and HCV was higher in rural
areas. Systematic review of literature identified that key
population including individuals with sexual risk behaviours,

Implementation of this intervention

individuals with STDs, people living with HIV, blood donors

pose practical challenges to policy

and men who have sex with men (MSM) have higher

makers, where there is currently very

prevalence of HBV and HCV. The pooled estimate of HBV

limited access to HBV and HCV

and HCV prevalence among selected key population was 3%

diagnostic and treatment services due

and 1% respectively. Overall burden of HBV and HCV was

to lack of awareness and other barriers.

considerably higher in Tamil Nadu. Majority of people with

Vaccination coverage and increasing

hepatitis are unaware of their infection due to a lack of

access to PHC is essential

knowledge and availability at point-of-care testing services.
Page 128

<!-- page 49 -->

POLICY BRIEF

Delay in the diagnosis of HBV is common due to
asymptomatic nature of the disease and lack of access to
timely screening. At present in India hepatitis diagnosis is
provided at the tertiary health care facility level and for
individuals with abnormal liver functions.

KEY MESSAGES
To achieve the HBV & HCV elimination
goals, one of the key strategy adopted
is to strengthen the decentralized
diagnostics services for HBV & HCV to
ensure early and accurate diagnosis.

At present, under NVHCP there is a gap in providing costeffective diagnostic services at the primary health care

Key population with high prevalence

level.

of HBV & HCV would be highly
benefited through early and accurate

The implementation of decentralized HBV diagnosis strategy

diagnosis at point-of-care facility.

may effectively address the HBV and HCV disease burden in
the state with favorable cost saving for the NVHCP in Tamil
Nadu.6,7 Similarly, individuals test positive for HCV among
selected key population at primary health care level is a cost
saving.

The point-of-care screening strategy
was economically dominant for HBV &
HCV for selected key population is
cost saving to health system.

Decentralized HBC & HCV Diagnositcs

Decentralised diagnostic strategy

The new action plan of Government of Tamil Nadu had
initiated HBV and HCV screening at PHC level will provide a
major opportunity to improve identification and treatment

could avert deaths, gain life years and
reduce out-of-pocket expenditure to
patients.

of persons with chronic hepatitis, and help to achieve the
targets outlined. Active screening and diagnosis of HBV and HCV infection among key population at PHC
level is the gateway for access to both prevention as well as care and treatment services.

Summary of Evidence
Provision of diagnostic services for selected key population
who will be identified by health care providers at primary
health care level. The screened key population with or
without symptoms will be diagnosed using a rapid test kit.
Those who test positive with rapid test will be further
referred to tertiary health care for gold standard ELISA test.
Individuals test positive for ELISA will progress to HBV
treatment. Individuals who test negative for rapid test and
ELISA will progress to HBV vaccination. This decentralised
diagnosis followed by early treatment for HBV and HCV
patients and vaccination for negatives of HBV at primary

3/4th of HBV & HCV infected
people were males

health care level for selected key population in Tamil Nadu
is cost saving.

Early screening and hepatitis B vaccination will provide an opportunity to link to interventions to
reduce transmission and cost to the patients and their family members. HBV infection rates can be
reduced by active screening of key population and increasing HBV vaccination rate and linking
patients with the care cascade.

Page 229

<!-- page 50 -->

POLICY BRIEF

CONCLUSION
The implementation and expansion of decentralized HBV diagnosis strategy may effectively
address the HBV and HCV disease burden in the state with favorable cost saving for the NVHCP in
Tamil Nadu. It will likely identify HBV and HCV infection among asymptomatic cases, prevent
chronic cases and would improve quality of life of HBV and HCV infected individuals and reduce
out-of-pocket expenditure

References
1. World Health Organization. Global Disease
Estimates 2016. World Health Organization,
Geneva. 2016.
2. Ray G. Current Scenario of Hepatitis B and
Its Treatment in India. J Clin Transl Hepatol
2017; 5: 277-296.
3. Kumar A. Current practices in management
of hepatocellular carcinoma in India: results
of an online survey. J Clin Exp Hepatol 2014;
4: S140- 146.
4. Trickey A, Sood A, Midha V, et al. Clustering
of hepatitis C virus antibody positivity within
households and communities in

Punjab,

India. Epidemiol Infect. 2019; 147: e283.
5. World Health Organization. Guidance for
hepatitis programme managers: Analysis and

6. Muniyandi M , Kirti T, Malkeet S, Prakash V,
Karikalan N, Senthilkumar S, Sananthya K, Rajendran
K, Kavitha R, Vivekanandan S, Selvavinayagam TS.
Economic evaluation of implementing a decentralised
Hepatitis B virus diagnostic intervention under
National Viral Hepatitis Control Programme in Tamil
Nadu, South India. Tropical Medicine and
International Health
2020;https://onlinelibrary.wiley.com/doi:10.1111/tm
i.13528
7. Muniyandi M, Karikalan N, Kirti T, Malkeet S,
Prakash V, Senthilkumar S, Sananthya K, Rajendran
K, Kavitha R, Vivekanandan S, Selvavinayagam TS.
Economic evaluation of implementing a rapid pointof-care screening test for the identification of
hepatitis C virus under National Viral Hepatitis
Control Programme in Tamil Nadu, South India.
Under review.

use of health facility data. World Health
Organization, Geneva, Working Document
2019
Page 330

<!-- page 51 -->

Rapid Health Technology Assessment for
Incorporating TrueNat as A Diagnostic Tool
for Tuberculosis Under RNTCP in India.

<!-- page 52 -->

Health Technology Assessment in India
Department of Health Research, MoHFW

Rapid Health Technology Assessment for incorporating
TrueNat as a diagnostic tool for tuberculosis under
RNTCP in India
SUMMARY

India has world’s highest tuberculosis (TB) and multi-

POLICY BRIEF

drug resistant tuberculosis (MDR-TB) burden with the

POLICY RECOMMENDATIONS

incidence

TrueNat is more cost-effective and

rate

of

approximately

2.8

million

annually[i]. Due to the poor diagnostics tool at the

feasible

health care facilities with low sensitivity and low

healthcare

linkage-to-care rates, over 25% of patients who prefer

portability and requirement of less

public sector are neither diagnosed nor started on

sophisticated infrastructure).

treatment[ii]. Hence there is an urgent need for an
affordable and high-sensitivity screening or diagnostic
test which could be installed in peripheral health
facilities with minimal infrastructure and
on

available

preliminary
evidences,

search

this

of

study

literature

aims

to

and

compare

clinical effectiveness of smear microscopy, GeneXpert
and

TrueNat

with

reference

to

for

peripheral

facilities

(due

to

GeneXpert is almost equally good
(in terms of sensitivity as well as
cost)

and

compared

cost-effective
to

other

as

diagnostic

tools like Smear Microscopy and

training.
Based

option

culture

as

gold

can be used at District level and
above due to its ease of use and
less

chances

of

error

(due

to

automation) results.

standard. We also analysed the cost-effectiveness
study conducted by Lee et. al., 2019. The study also
looked in to operational feasibility and challenges of
implementing TrueNat under RNTCP.
If used as a point-of-care (POC) test within primary
healthcare facilities, Truenat could increase treatment
initiation by reducing turnaround time for test results
and decreasing the need for laboratory referrals.
In India, CB NAAT has been used for diagnosis of TB
under RNTCP program. Recently, the Andhra Pradesh
State Government adopted TrueNat for TB diagnosis
at various health levels like CHCs, PHCs and DMCs. A
total of 225 TrueNat Duo modules have been installed
so far in the state. Out of these, 200 have been
installed at CHC level and 25 at PHC level.

TrueNat - MolBio Diagnostics

Apart from published literature on
these devices interviews with program
experts were also conducted. These
experts had been working with TrueNat
and had experience of working with CB
NAAT as well. This exercise was done in
order
to
understand
operational
feasibility of the TrueNat system.
31

<!-- page 53 -->

CONCLUSION
Truenat as compared to GeneXpert is very cost-effective in Indian settings with
ICER: INR 8400 per Life Year saved (against threshold of per capita GDP 1,20,000).
Sensitivity and Specificity of both equipment are comparable but TrueNat is more
sensitive (Difference=3.1%).
As per Lee et al., 2019 deploying Truenat POC instead of GeneXpert increased 5year expenditures by $270 million, due mostly to treatment costs. Cost per test for
both is also comparable but GeneXpert is cheaper. (Difference = Rs. 86 per test).
Budgetary Impact of TrueNat for RNTCP
1. Capex Model (To Install machine in 1 TU): ANNUAL
COST FOR 1 TU = 10,45,738
ANNUAL COST FOR 2698 TUs = 282 Crores
2. Opex Model
(To Install machine in 1 TU): ANNUAL COST FOR 1 TU = 17,72,833
ANNUAL COST FOR 2698 TUs = 478 Crores

Acknowledgement:
The study was conducted by HTAIn Secretariat, DHR, MoHFW
References:
1) World Health Organization. Global tuberculosis report 2017 [Internet]: World Health Organization,
Geneva, Switzerland; 2017.
2) Subbaraman R, Nathavitharana RR, et al. The tuberculosis cascade of care in India’s public sector: a
systematic review and meta-analysis. PLoS Med. 2016; 13: e1002149.

POLICY BRIEF

32

<!-- page 54 -->

Health Technology Assessment of
Automated Resuscitation Device (ARD) for
Neonatal Resuscitation at Point of Delivery in
Indian Healthcare System.

<!-- page 55 -->

Policy Brief
FEBRUARY, 2020 ǀ Health Technology Assessment in India (HTAIn)
Department of Health Research, Ministry of Health & Family Welfare – New Delhi
Kalam Institute of Health Technology – Vishakhapatnam

Health Technology Assessment of Automated Resuscitation
Device (ARD) for Neonatal Resuscitation at point of delivery in
Indian Healthcare System
Executive Summary
Health Technology Assessment of ARD was carried out at
Kalam Institute of Health Sciences, Andhra Pradesh.
Negative Incremental Cost Effectiveness Ratio (ICER) value
implies that the ARD is both clinically and cost effective
compared to the standard of care. Based on the analysis, the
device can be used at a tertiary level healthcare setting in
Andhra Pradesh. However, a pilot study in any part of India
is recommended for a more comprehensive overview of this
intervention. Budget impact modelling for five states in India
with the worst Neonatal mortality rates was also carried out
to find out the impact on the exchequer of these states with
gradual switching to ARD device.

Introduction
Perinatal asphyxia, neonatal asphyxia or birth asphyxia is the
medical condition resulting from deprivation of oxygen to a
newborn infant that if lasted long enough during the birth
process it may lead to brain damage and multiple organ
dysfunction. Birth asphyxia is a serious clinical problem
worldwide and contributes greatly to neonatal mortality and
morbidity [1]. Birth asphyxia is one of the most common
causes of admission to NICU. Approximately 10% of new
born babies fail to initiate effectual breathing at birth; most of
these starts breathing after initial stimulation by the health
personnel, about 3-5% need basic resuscitation, but <1%
require advanced resuscitative effort to achieve efficient
circulation to the vital organs [2].
Among four million neonatal deaths annually about ninetynine percent occur in low middle income countries, mostly
due to home based delivery without a skilled attendant where
the neonate is more prone to asphyxia. Another one million
children who survive birth asphyxia live with chronic neurodevelopmental morbidity, including cerebral palsy, mental
retardation, and learning disabilities, although there is
significant uncertainty regarding this estimate [3]. In India

alone, around one million babies die each year before
they complete their first month of life, contributing to
one-fourth of the global burden [4]. Common risk
factors of birth asphyxia are high/ low maternal age,
prolonged membrane rupture, meconium stained fluid,
multiple births, non-attendance for antenatal care, low
birth weight infants, malpresentation, augmentation of
labor with oxytocin, ante partum hemorrhage, severe
eclampsia and pre-eclampsia, ante partum and
intrapartum anemia) [5].
Birth asphyxia continues to be the leading cause of
morbidities in newborn babies, in spite of many
advances in neonatal care. Systematic review concludes
that mortality and morbidity of Birth asphyxia can be
prevented with appropriate interventions including
skilled resuscitation technique.
State-wise Neo-natal Mortality Rate during 2016 [6]
Sl.No

State

India

India
Andhra
Pradesh
Assam
Bihar
Chhattisgarh
Delhi
Gujarat
Haryana
Himachal
Pradesh
Jammu
and
Kashmir
Jharkhand
Karnataka
Kerala

1
2
3
4
5
6
7
8
9
10
11
12

2016 - 2016 - 2016 Total
Rural
Urban
24
27
14
23

27

11

23
27
26
12
21
22

24
28
27
16
27
24

13
17
20
12
13
16

16

16

15

18

19

15

21
18
6

23
22
7

13
10
4
1

33

<!-- page 56 -->

13
14
15
16
17
18
19
20
21
22

Madhya
Pradesh
Maharashtra
Odisha
Punjab
Rajasthan
Tamil Nadu
Telangana
Uttar Pradesh
Uttarakhand
West Bengal

32

35

20

13
32
13
28
12
21
30
30
17

17
33
13
31
16
25
32
32
17

9
24
12
17
9
15
19
24
14

A Health Technology Assessment (HTA) of the Automated
Resuscitator Device (Fig.2) vis a vis Self Inflating Bag (Fig.
1) was carried out to find out the Clinical and Cost
Effectiveness of the new device as compared to Standard care.

Methods
To assess the cost-effectiveness of the device at the Tertiary
level healthcare setting in Andhra Pradesh, a decision analytic
model was constructed to compare the device to standard of
care- Self Inflating bag. The cost of both the interventions
were considered from a societal perspective, and Disability
Adjusted Life Years (DALYs) to measure the economic
burden. Robustness of the results were checked through
Sensitivity Analysis and Monte-Carlo Simulation. Budget
impact modelling was done for the five states in India having
the worst Neonatal mortality rates.

Why DALY?
 DALY can be thought of as one lost year of "healthy"
life (WHO).
 DALYs for a disease or health condition are calculated
as the sum of the Years of Life Lost (YLL) due to
premature mortality in the population and the Years Lost
due to Disability (YLD) for people living with the health
condition or its consequences. In neonatal resuscitation
patients, premature mortality is the main problem and
disability due to a number of reasons is also important as
highlighted before. [7]
 EQ-5D has been derived from adult scores. For neonates
there is no accepted EQ-5D methodology.

Results
Figure 1: Self-inflating bag

Figure 2: T-piece resuscitation device (with
manometer)

The Incremental Cost Effectiveness ratio (ICER) for the new
device when compared to self-inflating bag was found to be –
1443.16 Rupees per DALY averted. The negative ICER value
implies that the ARD is both clinically and cost effective
compared to the standard of care (Fig. 3). Monte-Carlo
simulations implied that ARD would be cost-effective with
95% probability at Rs 1250/- (Fig.4). Based on the
Incremental Cost Effectiveness ratio value we obtained, the
ARD device reduces both the cost and averts Disability
adjusted life years by the virtue of reducing the number of
severe cases caused due to birth asphyxia. Based on this
analysis, the device was found to be Cost-Effective and can
be used at a tertiary level healthcare setting in Andhra
Pradesh. budget impact modelling for the five states in India
with the worst Neonatal mortality rates to find out what
impact would it have on the exchequer of these states with
gradual switching to ARD device. The Budget impact study
was carried out for Madhya Pradesh, Odisha, Uttar Pradesh

2

34

<!-- page 57 -->

and Rajasthan. It was found that the gradual switch to ARD
from SIB would lead to net cost saving for all the top five
adversely affected states in India by neonatal birth asphyxia.

 Gradual switch to ARD from SIB would leads to net cost
saving strategy for the states having high Neonatal
mortality rate.

Conclusion
Birth asphyxia is one of the most common causes of
admission to NICU and neonatal morbidity and mortality. It
can be prevented with appropriate interventions including
skilled resuscitation technique. Based upon the analysis
ARD could be recommended to be used at a tertiary level
healthcare setting in Andhra Pradesh.

Policy Recommendations
Figure 3: Probabilistic Sensitivity Analysis

 ARD is both clinically and cost effective compared to
the standard of care at a tertiary level healthcare setting.
 The new device would be cost-effective with 95%
probability at Rs. 1250.
 The device can be used at tertiary level healthcare
setting with centralized oxygen supply.
 A pilot study is recommended in other part of India in
order to collect real world data before scaling it up for
the state and later for India.

References

Figure 4: Cost-Effectiveness Acceptability Curve
ARD was also recommended by the practitioners using it,
in a survey conducted, to find out the operational
challenges, due to the features such as automation and
ability to vary PEEP.

1. Pitsawong C, Panichkul P. Risk factors associated with birth asphyxia in
Phramongkutklao Hospital. Thai J Obstet Gynaecol. 2012;19(4):165–171].
2. Aslam HM, Saleem S, Afzal R, Iqbal U, Saleem SM, Shaikh MW, et al. Risk
factors of birth asphyxia. Ital J Pediatr. 2014;40(1):94.
3. World Health Organization. World Health Report 2005.
4. National Health Profile Report, Central Bureau of Health Intelligence,
Ministry of Health and Family Welfare, pp. 9–16, 2010.
5. Kaye D. Antenatal and intrapartum risk factors for birth asphyxia among
emergency obstetric referrals in Mulago Hospital, Kampala, Uganda. East Afr
Med J. 2003;80(3):140–143].
6. State-wise Neo-natal Mortality Rate during 2016, Ministry of Health and
Family Welfare, Source: RAJYA SABHA SESSION - 245 UNSTARRED
QUESTION NO. 4115
7. Metrics: Disability-Adjusted Life Year (DALY) – WHO.

Key Findings
 ICER for ARD compared to self-inflating bag – 1443.16
Rupees per DALY averted.
 Negative ICER value implied ARD is both clinically and
cost effective compared to the standard of care.
 ARD would be cost-effective with 95% probability at Rs
1250/-.
 ARD was found to be Cost-Effective and can be used at a
tertiary level healthcare setting in Andhra Pradesh.

3

35

<!-- page 58 -->

A comprehensive HTA of Project Lifeline – A
Portable ECG Facility at PHCs of Ahmedabad
District of Gujarat.

<!-- page 59 -->

Policy Brief
Health Technology Assessment in India (HTAIn)
Department of Health Research, Ministry of Health & Family Welfare

Regional Resource Centre for HTA, IIPH Gandhinagar

A comprehensive HTA of Project Lifeline – A portable ECG
facility at PHCs of Ahmedabad district of Gujarat
Policy recommendations

Summary
Gujarat

At an additional cost of Rs. 2,299 for saving an additional life

introduced Project Lifeline, 12-lead portable ECG devices

year, the ECG screening facility at primary health centres for

across all Primary Health Centres (PHC) in the district for the

high risk group is cost-effective and acceptable for replication in

screening of cardiac abnormalities among high-risk and

other districts and states. Further, the initiative can be linked with

symptomatic adults for providing primary management and

existing e-Sanjeevani (telemedicine) program which allow the

proper timely referral. Objective of the study was to assess

utilization of physician available on e-Sanjeevani platform.

Background:

Ahmedabad

Zilla

Panchayat,

the cost-effectiveness of portable ECG for the screening of
Cardiovascular Disease (CVD) among high-risk and

INTRODUCTION

symptomatic adults at Primary Health Centre in Ahmedabad,

Cardiovascular diseases (CVD)

Gujarat.

requirement of specific expertise for early diagnosis and referral

Methods: Cost-effective analysis was conducted using a

of the disease at primary health care level. In Gujarat, primary

societal perspective. An incremental costing approach was

health centres (PHCs) are not yet equipped with these facilities.

adapted and cost-effectiveness analysis was done using

With an aim to screen all the high-risk and symptomatic adults,

decision-analytic model. We surveyed seventy-three patients

the District Health Team at Zilla Panchayat Ahmedabad, Gujarat

who were screened positive for cardiac abnormality, to

introduced a 12-lead portable ECG machine across 40 PHCs in

document the type of ECG abnormalities and if they were

the district for the first time in the State. Linkage was established

diagnosed for CVD. The program cost was obtained from the

with a medicine specialist for reading ECG through a web-based

implementers. Transition probabilities were derived from

interface for identification and confirmation of Cardiovascular

primary data supported by expert opinion for the intervention

Diseases and provides primary management (with thrombolytic

arm while systematic search of literature was undertaken to

and anti-platelet like Aspirin) coupled with timely referral.

progress silently. There are

derive transition probabilities for the control arm.
Results: Introduction of ECG screening at PHCs saved 2.90
life years at an incremental cost of 89.97 USD (6,657.47
INR), yielding a cost-effectiveness ratio of 31.07 USD
(2,299.06 INR) per life-year saved which is below the
willingness to pay threshold. Results are sensitive to the
relative risk reduction associated with non-participation and
the cost of initial screening.
Conclusion: Cost-effectiveness analysis clearly shows that
the facility to screen cardiac abnormality at the PHC level is
highly recommended for high-risk adult and symptomatic
cases.

Figure 1: ECG Device used in Project Lifeline

1

36

<!-- page 60 -->

The objective of the present study was to assess costeffectiveness introducing portable ECG facility at PHCs for

Atria or Ventricles
Myocardial Ischemia



the screening of cardiovascular disease among high risk and

Others



Hypertrophy
Myocardial Ischemia or
Infarction
Valvular Issues

symptomatic adults and estimate budgetary implications for
the scale-up of the ECG facility.

Cost data
Both the program cost i.e. the cost borne by the health system

METHODS

for implementing ECG program as well as the direct and

Cost-effectiveness analysis was done using decision-analytic

indirect medical cost incurred by the patients were taken into

modelling with a societal perspective on health care costs and

consideration. All costs were reported in Indian Rupees and

benefits. The target population for the study were high-risk

USD at 74 INR per dollar.

and symptomatic adults which included adults having

For deriving the cost of treatment, physicians were consulted

diabetes, hypertension, cardio-metabolic syndrome, family

for their opinion on the line of treatment. The cost of

history of cardiac disease or signs and symptoms suggestive

interventions (as suggested by the experts) were taken from

of cardiovascular disease. Intervention scenario

viz.

Pradhan Mantri Jan Arogya Yojana (PMJAY) Package.[1]

screening of population with portable ECG machine for early

Since the cost for undergoing diagnostic test was already

detection of cardiac abnormalities at PHC, was compared

included in the PMJAY, we have not added additional

with no intervention scenario/ routine care scenario. Early

diagnostic cost to avoid over-calculation of the treatment

diagnosis, prompt treatment of CVD, and life years saved

cost.

were the outcome measures.
The type of ECG abnormalities identified during screening
were categorised into five major disorders based on the
primary data and expert opinion of the practitioners. The five
cardiovascular disorder reported in the high-risk adults
mentioned in the table 1 were considered for building the
decision tree model. Data of 12,105 individuals screened for
CVD using portable ECG device during 2018-19 were
assessed. Of this, 208 individuals were screened with
abnormality were selected from the database maintained at
Zilla Panchayat, Ahmedabad.

Clinical outcome
Transition probabilities were derived from primary data
supported by expert opinion for the intervention arm while
systematic search of literature was undertaken to derive
transition probabilities for the control arm. Three experts
included two prominent Cardiologists from Gujarat and one
community medicine expert from Maharashtra with
substantive experience in the subject. We used following
indicators for calculating transition probabilities:
1.

Total number of high-risk and symptomatic adults
underwent ECG screening at PHC

Of the 208 patients screened positive, 73 were high risk

2.

symptomatic adults. Further follow-up of 73 high risk

Number of patients referred and underwent
diagnostic test

symptomatic adults led to 54 individuals who were diagnosed

3.

Type of ECG abnormality

positive for CVD.

4.

Type of treatment

Table 1: Categorization of ECG abnormalities
based on expert opinion
Cardiovascular
ECG Abnormalities
Disorders
Arrhythmia
 Supraventricular
Arrhythmia
 Ventricular Arrhythmia
Action Sequence
 Atrioventricular
Conduction Defect
Conduction Defect
(Block)
 Bundle Branch Block
Increase in wall
 Atrial Hypertrophy
thickness or size of
 Ventricular

The data on survival rates for each abnormality were derived
on applying hazard ratio [2] to the survival rates reported in
the published literature for each cardiovascular disorder.

The transition probabilities in the control arm were derived
through systematic search of published literature. Indian data
was used for all the transition probabilities except for survival
rate of Action Sequence Conduction Defect which was
37

<!-- page 61 -->

obtained in global context. In addition to this, due to
unavailability of disorder specific data on QALY, the cost-

Figure 2: Cost-Effectiveness Plane for High
Risk Adults

effectiveness analysis was done using Life Years (LYs) saved

100000

as an outcome indicator.

80000
60000

For the purpose of estimating Life Years saved, the average

40000

age of high-risk adults who underwent the ECG screening

20000

was 54.6 years i.e., average age of cohort in intervention arm.
From literature we found in usual condition mean average age

0
-5 -4.5 -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4 4.5 5
-20000

is 57.5 years as mentioned in the CREATE registry.[3] The

-40000

ECG screening programme resulted in people getting

-60000

diagnosed on an average 2.9 years in advance.

-80000
-100000

Budget Impact Analysis was performed to estimate the cost
for scaling up of the ECG program at the District, State and
National levels at 2020 prices. The Budget Impact Analysis

Figure 2 depicts the Cost-effectiveness plane with ICER

depicted the allocation of budget for 1st year, 2nd year, 5th

(orange dot) lying in the first quadrant as incremental cost of

year and 10th year.

89.97 USD is incurred for saving 2.9 incremental life years.
The intervention is found to be cost-effective as the ICER lies

RESULTS
We surveyed seventy-three patients who screened positive for
abnormality, to document the type of ECG abnormalities as
well as if their further diagnosis was CVD.
Program cost
The annualized cost incurred by the program implementers
was estimated to be 16.92 lakhs. With this investment, around
12,105 patients were screened. The calculated cost per cases
screened amounted to (INR) 139.85. The time-motion study
was used to estimate shared human resource costs. It was
found that an approximate time of 12 minutes of staff nurses
was used towards the ECG program and its estimated annual

well below the CE Plane or willingness to pay threshold
which is fixed at GDP per capita. The intervention is
considered cost-effective. The One-Way Sensitivity Analysis
indicate that parameters have the largest effect on ICER when
they are varied individually.
Budget Impact Analysis (BIA)
While performing BIA, the budget of 1st year incorporated
major capital investment required in the first year of program
scale-up. The budget for 2nd, 5th, and 10th year depicted the
incurred annual implementation cost. In addition, the budget
of 5th year was estimated by taking into account the need for
short refresher training to the health workers.

cost was 209.38 USD (15494.43 INR).
Cost-effectiveness Analysis
The cost of intervention arm was 97.07 USD (7,183.64 INR)
with 14 life years saved, while the cost incurred in the
comparator arm (routine care scenario) was 7.11 USD
(526.16 INR) for 11 life-years saved. The ECG screening
intervention in primary care has proved itself to be extremely
cost-effective for high risk adult and symptomatic population

The state-wide scale up cost across 1,474 PHCs in 33 districts
of Gujarat for the ECG programme is estimated to be around
INR 155.2 million for the first year while nation-wide scale
up cost was calculated for 24,029 PHCs across 720 districts
was INR 2,706 million in the first year. This budget was
calculated by projecting the annualized cost of implementing
in Ahmedabad district.

resulting in saving of around 2.896 life-years at an
incremental cost of approximately 89.97 USD (6657.47 INR)
with ICER of 31.07 USD (2299.06 INR) per life-year saved.

38

<!-- page 62 -->

CONCLUSION
The ECG screening facility at primary health care level for
high risk group is cost effective and can be replicable in other

References
1.

Health

districts and states. It can be linked with program which allow

Benefit

Package.

Available

at

https://pmjay.gov.in/sites/default/files/2020-

the utilization of physician available on e-Sanjeevani
platform.

Ayushman Bharat. Pradhan Mantri Jan Arogya Yojana

01/HBP_2.0-For_Website_V2.pdf
2.

Lindekleiv H, Løchen ML, Mathiesen EB, Njølstad I,
Wilsgaard T, Schirmer H. Echocardiographic screening

A standardized risk-stratification tool (such as Framingham

of the general population and long-term survival: a

risk score or CBAC) may assist in identifying high-risk

randomized clinical study. JAMA internal medicine.

population and only those identified for high risk should be
subjected to ECG. screening. Further, cost data should be
validated on larger cohort on prospective manner.

2013 Sep 23;173(17):1592-8.
3.

Xavier D, Pais P, Devereaux PJ, Xie C, Prabhakaran D,
Reddy KS, Gupta R, Joshi P, Kerkar P, Thanikachalam
S, Haridas KK. Treatment and outcomes of acute
coronary syndromes in India (CREATE): a prospective
analysis of registry data. The Lancet. 2008 Apr
26;371(9622):1435-42.

39

<!-- page 63 -->

Health Technology Assessment of Population
based Screening for Type 2 Diabetes &
Hypertension in India.

<!-- page 64 -->

Health Technology Assessment of Population based
Screening for Type 2 Diabetes & Hypertension in India
Health Technology Assessment in India (HTAIn)
Department of Health Research

POLICY BRIEF
Background

A hybrid decision model comprising of 3 parts was used
The present study involved Health Technology Assessment of
population-based screening for diabetes and hypertension in
India. A systematic review and meta-analysis was undertaken
to assess the diagnostic accuracy of screening tests in

to assess the incremental cost per quality adjusted life
year (QALY) gained as a result of screening. The first
part comprised of the decision tree which predicted

previously undiagnosed population. Primary data was

the number of individuals who would be detected with

collected using standard bottom-up costing methods, from

either prediabetes, diabetes, hypertension, and a co-

Haryana and Tamil Nadu states, to assess the cost of screening.

morbid state. These cases were further classified into

The National Health System Cost Database was used to

true positives, false negative, true negative and false

determine the cost of diagnostic tests as well as the health

negative based on sensitivity and specificity of

system cost of treatment for diabetes and hypertension. The

screening methods. The second part used a Markov

cost of treating complications in tertiary care setting was
obtained from the Cost of Health Services in India (CHSI) study.
Out-of-pocket expenditure for treatment in public and private
sector was assessed by analysing the 71st round of National
Sample Survey data on Health and Morbidity. Primary data was
collected from 954 patients to assess the OOP expenditure in

model to track the transition of diseased individuals
over annual cycles to identify occurrence of diseaserelated complication. The third part comprised of five
separate Markov models for the complications
(retinopathy, nephropathy, foot ulcer, coronary heart

tertiary hospital and quality of life among those affected with

disease, stroke) which predicted the life course in

diabetes, hypertension, co-morbidity, as well as different

terms of life years, QALYs and costs. Several alternative

complications.

screening scenarios were considered depending on the
methods used (random blood glucose, fasting blood
glucose), frequency of screening (annual, every three
or five or ten or fifteen or twenty years and one-time)
and population age group to be screened (30-65 years
or 45-65 years).
Figure 1: Process of HTA conducted

Conclusions
In summary, we report on the current scenario of PBS implementation and explored on the health system challenges and
opportunities in regard to the existing program. Given the escalating dual burden of DM and HTN, and the current
challenges noted in the provision of PBS program, there is a need to focus on addressing the same for providing quality
services to patients with effective strengthening of primary health care. However, there is little empirical information
about the benefits of such population based screening within current health care systems in developing countries.

40

<!-- page 65 -->

Key findings

Policy Recommendations

1. In the absence of screening, there are 9267, 28,206, 2982,

This study explored potential health system
challenges and opportunities that need to be
considered for PBS from the health system
perspective. There are potential challenges existing
in various aspects of PBS; however, some focus
areas as opportunities were also recognized:

3030 and 1239 cases of stroke, myocardial infarction, end
stage renal disease (ESRD), amputation and blindness due to
diabetes and hypertension per 1 lakh population respectively.
With the implementation of annual population based
screening with random blood glucose test followed by fasting
glucose test (as compared to no screening), there is reduction
in 23% (n=2123), 13% (n=3753), 27% (n=807), 40% (1224)
and 35% (n=429) cases of stroke, myocardial infarction, end

- Improving coverage rates for screening,
subsequent referral for confirmatory testing and put
on treatment.

lakh population respectively.

- Focussing on follow up of those who started on
treatment and how to achieve control for the
disease conditions.

2. In the scenario of no screening, for a cohort of 1 lakh

- Assessing cost-effectiveness of annual screening.

population, the lifetime treatment cost of complicated cases

- Assessing on screening for complications.

stage renal disease (ESRD), amputation and blindness per 1

comprised of around 96.5% (INR 7794 million) of the total
cost, followed by cost of treating uncomplicated cases
(3.37%; INR 271 million). In the case of annual screening,
treatment cost of uncomplicated cases constitutes the major
component (64.5%; INR 10929 million), followed by the cost
of treating complicated cases (35%; INR 5980 million). The
cost of implementing screening comprised of 0.5% (INR 65
million) of the total cost.
3. Implementation of annual population-based screening with
random blood glucose test followed by fasting glucose test (as
compared to no screening), lead to gain in 6387 life years,
19,656 quality adjusted life years and reduction in 1259

- Promoting the prevention programs and increasing
awareness for diabetes and hypertension.
- Improving the reporting formats to avoid the
multiplicity in reporting.
- Functioning of NCD clinics to ensure early
treatment.
- Incorporating formats that facilitate in capturing
data regarding incidence and can be of subsequent
policy use.
- Understanding the PBS with equity lens to assess
any improvement in access to vulnerable
populations.

deaths (due to diabetes and hypertension) per one lakh
population respectively.
Acknowledgements
The study was conducted by PGIMER, Chandigarh as a Regional Resource centre for HTAIn, DHR in collaboration with
NIRT, Chennai.
References
1.

2.
3.
4.

Forouzanfar MH, Alexander L, Anderson HR, Bachman VF, Biryukov S, Brauer M, et al. Global, regional, and national
comparative risk assessment of 79 behavioural, environmental and occupational, and metabolic risks or clusters of risks in
188 countries, 1990-2013: a systematic analysis for the Global Burden of Disease Study 2013. Lancet (London, England).
2015;386(10010):2287-323.
Travasso C. High blood pressure is the leading health risk factor in India, finds study. BMJ (Clinical research ed).
2015;351:h5034.
Beran D. The impact of health systems on diabetes care in low and lower middle income countries. Current diabetes reports.
2015;15(4):20.
WHO. World Health Statistics 2015. Geneva: World Health Organization; 2015. 5. WHO. Principles of Screening (Draft).
Geneva: World Health Organization; 2001. 6. Echouffo-Tcheugui JB, Ali MK, Griffin SJ, Narayan KM. Screening for type 2
diabetes and dysglycemia. Epidemiologic reviews. 2011;33:63-87.
41

<!-- page 66 -->

Economic-Evaluation of Percutaneous
Coronary Intervention as Compared to
Coronary Artery Bypass Grafting in Left Main
Coronary Artery Disease.

<!-- page 67 -->

Policy Brief
Health Technology Assessment in India
Department of Health Research, Ministry of Health & Family Welfare

ECONOMIC-EVALUATION OF PERCUTANEOUS CORONARY
INTERVENTION AS COMPARED TO CORONARY ARTERY BYPASS
GRAFTING IN LEFT MAIN CORONARY ARTERY DISEASE

© Shutterstock

Introduction
Cardiovascular diseases (CVDs) are one of the leading causes of
mortality in India. Among CVDs, coronary artery disease (CAD)
is the major cause of cardiovascular mortality and morbidity
globally. Coronary Artery Disease (CAD) refers to the
pathological narrowing of arteries that supply blood to heart
muscles. Individuals with coronary artery disease have different
phenotypic variations. At present, Coronary Artery Bypass
Graft surgery (CABG) and Percutaneous Coronary Intervention
(PCI) are commonly available treatment options for Left Main
coronary artery Disease. Although CABG is considered as a
gold standard treatment for left main coronary artery disease
(CAD). PCI has also gained attention in recent years as an
alternative approach for the treatment of these coronary artery
diseases. However, the best approach for the treatment of
stable patients of these complex coronary artery diseases is still
a subject of debate. This study evaluated the economic and
health outcomes of CABG vs PCI for left main coronary artery
disease over the lifetime of a patient in Indian healthcare
settings. This study is a model based estimation of incremental
costs and QALYs gained in CABG group and percutaneous
coronary intervention group in LMCAD patients (figure1,2,3).
We used two separate Markov models to estimate the overall
costs and health outcome for the comparison. Data pertaining
to the costs, clinical effectiveness and Quality of Life was taken
from the secondary literature.

SUMMARY
Coronary artery disease (CAD) is the major
cause of mortality and morbidity globally,
causing approximately 7 million deaths
annually. Coronary Artery Bypass Graft
surgery (CABG) and Percutaneous Coronary
Intervention (PCI) are commonly available
treatment options for Left Main coronary
artery Disease. Aim of this Study was to
conduct a full economic evaluation of
Percutaneous Coronary Intervention in
patients with stable Left Major Coronary
Artery Disease as compared to Coronary
Artery Bypass Graft in Indian healthcare
setting. CABG is found more clinically effective
and also ost-effective as compared to PCI.

RECOMMENDATIONS
In cases of Left Main Coronary Artery
Disease, the mainstay treatment should be
centered on Coronary Artery Bypass Graft.
PCI may be considered as the second line of
treatment in cases requiring
revascularization as per clinical experts’
opinion.

PAGE 0142

<!-- page 68 -->

Policy Brief

Figure 1. Conceptual framework
for the economic evaluation for
PCI versus CABG

(a)

(b)

Figure 2. Markov's Model used for the (a) PCI Scenario and (b) CABG Scenaria

Results
The analysis was done for both scenarios with four different
time horizons( 1yr,5yr,10yr, lifetime). In the first case, when
estimations were done using a one-year time horizon, these
results are favoring PCI as there are almost the same
mortality and significantly lesser cost than CABG and for a
longer period, especially for the twenty years period, results
actually change. One year and lifetime horizon results per
patient are summarized in the table1.

Table 1:Total cost of PCI versus CABG for one year and
lifetime horizon

Table 2: ICER of PCI versus CABG over four different time horizon
ICER at 1 year

ICER at 5 years

ICER at 10 years

ICER at 20 years

When comparing the costs and QALYs gained, over the
first year; the ICER of PCI versus CABG is -5,22,023,
which is primarily due to more upfront cost of CABG as
compared to PCI and comparatively lesser periprocedural complications in PCI than CABG. In the five
years,10 years, and 20 years’ time horizon, PCI yields
less health outcomes in terms of QALYs lived and has
the incremental costs as shown in the table. Hence, at
five years,10 years, and 20 years’ CABG dominates as
PCI is not a cost-effective strategy as compared to
CABG.
Sensitivity analysis (OWSA) was conducted for life time
horizon by varying key parameters by twenty percent of
their base value; except for mortality of PCI and CABG
follow-up, which was varied to the upper and lower
bound of studies included in the meta-analysis (figure4).
PAGE 02 43

<!-- page 69 -->

Policy Brief

figure4:One Way Sensitivity Analysis results for lifetime horizon

MAIN FINDINGS

CONCLUSION

When estimations were done using one-

As evident from the results of our study, the

year time horizon the results favored the

upfront cost of CABG is more in the first year

PCI as there is almost the same mortality

as compared to PCI with and there is not much

and significantly lesser cost than CABG.

difference in the clinical outcomes of the these
interventions. However, in the subsequent

For a longer period, especially for the

years, i.e. 5 years horizon, 10 years horizon

twenty years period, results changed in

and lifetime (twenty years’ time) horizon;

favor of CABG because of more repeat

CABG is more clinically effective and also cost-

revascularizations required in the PCI

effective as compared to PCI. Although, there is

scenario.

only a marginal difference in the health
outcome of CABG over PCI in management of

In Probabilistic Sensitivity Analysis CABG

stable LM CAD patients in terms of QALYs

was found to be cost-effective than PCI in

gained, the overall cost of CABG is significantly

71.5%

less as compared to PCI due to difference in the
need of repeat revascularization subsequently.

PAGE 03 44

<!-- page 70 -->

Economic Evaluation of Different Treatment
Modalities for Management of Patients with
Multivessel Coronary Artery Disease (MVCAD).

<!-- page 71 -->

Health Technology Assessment in India (HTAIn)
Department of Health Research
Ministry of Health & Family Welfare
Government of India

Policy Brief

Economic Evaluation of Different Treatment Modalities for
Management of Patients with Multivessel Coronary Artery Disease
P o lic y Brief
(MV-CAD)
Summary
A Health Technology Assessment was
conducted to establish the costeffectiveness of the therapies looking
at MV-CAD be used in the treatment
of double and triple vessel diseases
(DVD and TVD respectively).
Conservative therapy of OMT should
thus be the initial therapy to start
treating patients. If the patient does
require invasive therapy for one or the
other reason, CABG should be the
preferred therapy over PCI due to it
being cost-effective as well as costsaving over PCI.
P o lic y R ecommend a t i o ns
To keep the conservative therapy
regimen of OMT alone as the
mainstay treatment with CABG
being the preferred invasive therapy
for cases showing unfavorable or
worsening prognosis with OMT
alone.
PCI might be considered but owing
to its higher costs attributable to the
number of stents to be implanted, it
is not recommended by this study
(as the health gains are not that
prominent as compared to CABG so
as to justify investing in that higher
cost).

The policy brief is based upon the Economic
Evaluation of Different Treatment
Modalities for Management of Patients with
Multivessel Coronary Artery Disease (MVCAD)

Background
MVD is often associated with a higher burden of comorbidities, left
ventricular dysfunction, and cardiovascular risk The goal in the
management of MVD is to reduce angina and heart failure symptoms
and a patient's subsequent risk of adverse cardiovascular events
Patients either undergo: Percutaneous Coronary Intervention (PCI)
with Optimal Medical Therapy (OMT), Coronary Artery Bypass Graft
(CABG) surgery with Optimal Medical Therapy (OMT) OR Optimal
Medical Therapy (OMT) alone.
Studies conducted in western
countries and have focused on
eliciting the difference in
clinical outcomes for patients
with left main coronary artery
disease with or without triple
vessel disease. The existing
data specifically looking at
MV-CAD is quite low and what
studies do exist are dated with
no conclusive response to
which strategy be used in the
treatment of double and triple
vessel diseases (DVD and TVD
Figure 1: Treatment flow followed for patients
respectively).
In addition to that, very little

with MV-CAD

literature exists pertaining to the cost-effectiveness of the therapies.
This is compounded by the scarcity of studies from the South-East
Asian and specifically Indian subcontinent region for clinical
outcomes of OMT alone versus PCI with OMT and CABG with OMT in
MV-CAD treatment. Hence, the present study was undertaken to
bridge a few of these existing gaps and lay the foundation for future
economic evaluations and health technology assessments.
The Research Question in the present study was to find out that what
is the most cost-effective treatment modality available for the
management of patients with multivessel coronary artery disease
(MV-CAD). The aim was to do the full economic evaluation to see
which treatment modality among Invasive Procedures (i.e.
percutaneous coronary interventions or PCI and coronary artery
bypass graft or CABG surgery) and Conservative Therapy (i.e. Optimal

PAGE 0145

<!-- page 72 -->

Policy Brief

Medical Therapy or OMT) is the better alternative for managing
patients with MV-CAD and within invasive procedures which is the
better alternative among PCI and CABG for the same.

Findings
As per the findings, when treating either MV-CAD, the between invasive
and conservative (OMT) therapies, the invasive therapy is highly costineffective with negative net health and monetary benefits. Regarding the
patients that do undergo invasive therapy, CABG proves to dominate PCI
with a positive net health benefit along with being cost-effective (Table I).
The results of the subgroup analysis are illustrated below. Overall,
invasive therapy does have a QALY gain over conservative OMT but when
comparing amongst themselves, CABG had a better gain n QALYs for
diabetics than non-diabetics (Table II).
Table I: Summary of results for MV-CAD patients

Ma jo r Find ing s
Among invasive and conservative
therapies for treating MV-CAD,
invasive therapy was found to be
cost-ineffective with negative net
health and monetary benefits.
MV-CAD patients that undergo
invasive therapy, CABG proves to
dominate PCI with a positive net
health benefit along with being costeffective.
CABG had a better gain n QALYs for
diabetics than non-diabetics.
In the case of invasive vs
conservative therapy, even at a really
high willing-to-pay threshold of
almost INR 60,00,000 invasive
therapy can only have a 50%
probability of being cost-effective.

Table II: Summary of results for Diabetic MV-CAD patients

In case the patient does need to go
for invasive therapy, CABG is the
dominant therapy to choose from
among the two (i.e. PCI and CABG).
In diabetics, the trends seen were
almost similar to those seen in the
general population.

Co nc lus ion
Invasive therapy is not a cost-effective strategy to start treatment of MV-CAD patients. Conservative therapy of OMT should thus be
the initial therapy to start treating patients. If the patient does require invasive therapy for one or the other reason, CABG should be
the preferred therapy over PCI due to it being cost-effective as well as cost saving over PCI. Based on this study, our recommendation
would be to keep the conservative therapy regimen of OMT alone as the mainstay treatment with CABG being the preferred invasive
therapy for cases showing unfavourable or worsening prognosis with OMT alone. PCI might be considered but owing to its higher
costs attributable to the number of stents to be implanted, it is not recommended by this study (as the health gains are not that
prominent as compared to CABG so as to justify investing in that higher cost). In the case of diabetics, our recommendation remains
the same that the mainstay treatment be focussed around OMT alone and the patients be moved to CABG on the discretion of
physician and the patient’s response to OMT therapy.

PAGE 02

46

<!-- page 73 -->

Economic-Evaluation of Percutaneous
Coronary Interventions (PCI) Against
Optimal Medical Therapy (OMT) For
Management of Patients with Single Vessel
Coronary Artery Disease (SV-CAD) Without
Left Main Coronary Artery (LMCA)
Involvement.

<!-- page 74 -->

POLICY BRIEF

ECONOMIC-EVALUATION OF PERCUTANEOUS CORONARY
INTERVENTIONS (PCI) AGAINST OPTIMAL MEDICAL THERAPY
(OMT) FOR MANAGEMENT OF PATIENTS WITH SINGLE VESSEL
CORONARY ARTERY DISEASE (SV-CAD) WITHOUT LEFT MAIN
CORONARY ARTERY (LMCA) INVOLVEMENT
Health Technology Assessment in India Secretariat
Department of Health Research, MoHFW, New Delhi

SUMMARY
Single vessel coronary Artery disease (SV-CAD) is often usually
referred to as the presence of at least a ≥70% stenosis of a
major coronary artery (left anterior descending, left circumflex,
or right coronary arteries) or one of their respective major
branches and associated with a higher burden of comorbidities,
left ventricular dysfunction, and cardiovascular risk. Optimal
medical therapy and revascularization are the required
treatment to alleviate symptoms, avert disease progression,
prevent Cardiovascular events, and decrease mortality. A Health
technology Assessment (HTA) was undertaken to see which
treatment modality between percutaneous coronary
interventions (PCI) with optimal medical therapy (OMT) and
OMT alone is the better alternative for managing patients with
SV-CAD. Overall study suggested PCI is not a cost-effective
strategy for management of SV-CAD as compared to OMT.

POLICY
RECOMMENDATIONS

INTRODUCTION
Coronary artery disease (CAD) disease of the blood vessels

supplying to the heart muscle) are mostly involves single vessel and
OMT would have been the better
multi-vessel coronary artery disease. Single vessel disease (SV-CAD)
option of treatment both clinically
is usually referred to as the presence of at least a ≥70% stenosis of a
and cost-effectiveness wise
major coronary artery (left anterior descending, left circumflex, or
Study recommends that in cases of right coronary arteries) or one of their respective major branches.
SV-CAD, the mainstay treatment be Single vessel disease is often associated with a higher burden of
centered around the use of OMT
comorbidities, left ventricular dysfunction, and cardiovascular risk.
therapy alone.
All patients with CAD first require optimal medical therapy (OMT) to
PCI may be considered as the
second line of treatment in cases
requiring revascularization as per
clinical experts’ opinion.

alleviate symptoms, avert disease progression, prevent Cardio
vascular events, and decrease mortality. Revascularization is
indicated in patients who remain symptomatic despite OMT, for this
the patient may either undergo percutaneous coronary intervention
(PCI) and coronary artery bypass graft (CABG) surgery along with

optimal medical therapy (OMT) or in some cases only OMT. PCI is generally preferred in patients with
single or low risk two vessel. A Health Technology Assessment was conducted to assess which treatment
modality between percutaneous coronary interventions (PCI) with optimal medical therapy (OMT) and
OMT alone is the better alternative for managing patients with SV-CAD. Conceptual framework and
transitions used in the study shown in figure 1 and 2.
47

<!-- page 75 -->

POLICY BRIEF

Figure 1: Conceptual Framework for the processes to be modelled and generated in treatment of patients with SV-CAD with either
PCI + OMT or OMT alone

RESULTS
The results are as summarized in the
table 1. Separate ICERs and Net Benefit
values were calculated as per the prices of
drugs in the Jan Aushadhi list. In terms of
Net Health Benefit (NHB) there is an
overall loss of health benefits if we spend
in providing treatment with PCI + OMT as
opposed to simply treating patients with
OMT alone. There is also a net monetary
loss if an investment is made in PCI rather

Figure 2: Illustration of the Markov model with the various transitions
used in this study

than OMT as per our findings. As per the
sensitivity analysis the parameter most likely to influence results was the rate or revascularization in the
PCI arm followed by hospitalization for ACS in OMT and PCI + OMT arms respectively. The next 7
parameters are listed in the diagram in descending order of their tendency to have an effect on the ICER
values( figure3).
Overall, only 48% of the total generated ICER iterations from the PSA fall in the cost-effective range
as per our cost-effectiveness threshold (kept at one time the current GDP per capita per person of India).
Findings of the study found that the use of PCI + OMT is not something that can be recommended easily
over OMT alone therapy, specifically for SV CAD.
Also, seen that even at a high

Table 1: Results for the base case scenarios

willing-to-pay (WTP) threshold
of INR 8,00,000, the use of PCI
will have a maximum of 60%
chances of being cost-effective.
To sum up, as per our findings,
the ICER is higher than the CEA
threshold which means that
using PCI + OMT to treat SVCAD, as against those treated
with OMT alone, is not a costeffective strategy in India.
48

<!-- page 76 -->

POLICY BRIEF

Figure 3: Tornado diagram illustrating the top 10 parameters likely to influence the ICER values based on changes in
independent values of the parameters

MAJOR FINDINGS

SUMMARY

Using PCI + OMT to treat SV-CAD, as against

As evident from results of our study, PCI is not a

those treated with OMT alone, is not a cost-

cost-effective strategy for management of SV-CAD

effective strategy in India.

as compared to OMT. Even in terms of net
benefits, investing in PCI results in a negative net

Even at a high willing-to-pay (WTP) threshold

health benefit for the patient meaning that OMT

of INR 8,00,000, the use of PCI will have a

would have been the better option of treatment

maximum of 60% chance of being costeffective over OMT.
In terms of NHB, there is an overall loss of
health benefits if we spend in providing
treatment with PCI + OMT as opposed to
simply treating patients with OMT alone.
There is also a net monetary loss if an
investment is made in PCI rather than OMT
for SV-CAD patients.

both clinically and cost-effectiveness wise.
Considering that just for a gain of 0.3 QALYs the
incremental cost per patient is INR 66292, PCI
does not seem to be an effective strategy for
treatment. Thus, this study concluded that in
cases of SV-CAD, the mainstay treatment be
centered around the use of OMT therapy alone.
PCI may be considered as the second line of
treatment in cases requiring revascularization as
per clinical experts’ opinion.

49

<!-- page 77 -->

Health Technology Assessment of Low Cost
Portable Ventilator.

<!-- page 78 -->

POLICY BRIEF

Health Technology Assessment of
Low cost portable ventilator
HEALTH TECHNOLOGY ASSESSMENT IN INDIA
KALAM INSTITUTE OF HEALTH TECHNOLOGY-VIZAG

CONTEXT OF THE STUDY
The Covid-19 crisis highlighted the lack of
adequate ventilators in healthcare
systems all over the world, leading to
panic due to lack of evidence on the
clinical effectiveness of ventilation
systems needed for acute respiratory
failure and other diseases.
This HTA was an initiative to inform the
policymakers on the same issue and help
the exchequer in allocating resources
optimally and make informed investment
decisions on scaling up the most
appropriate respiratory support devices.
As poor choices lead to inappropriate use
or non-use of medical devices and a waste
of resources.

INTRODUCTION
Acute respiratory failure, and the need for ventilation,
remains one of the most common reasons for admission to
the intensive care unit (ICU). The burden of acute respiratory
failure is high in terms of mortality and morbidity as well as
the cost of its principal treatment of ventilation. A medical
ventilator can be a lifesaving as it is used when a person can’t
breathe properly on its own. Ventilators can be of two types
non-invasive ventilator (NIV) and invasive ventilator (IV).
Mechanical ventilation is used to treat 30–40% of patients
admitted to critical care. The growing prevalence of
respiratory diseases and COVID-19 pandemic, low-cost
portable ventilators were introduced in the healthcare
system. As we know India has limited number of ICU beds,
and using a low-cost ventilator for patients would reduce the
burden on healthcare system. Utility of ventilators in
homecare, ambulatory and emergency medical services, are
driving the growth of the portable ventilator segment in the
market.

SUMMARY OF FINDINGS
This new LCPV can be a promising
lifesaving intervention in epidemics like
the current COVID-19 and other disaster
scenarios.
Taking the willingness to pay threshold as
GDP per capita per month and assuming
non-inferiority in terms of clinical
effectiveness, the new ventilator turns out
to be cost-effective.

SUMMARY OF RESEARCH
As part of this technical consultation, the current study was
undertaken to assess the clinical and cost effectiveness on
the use of non-invasive ventilation (NIV) in acute respiratory
failure (ARF) and other diseases. Based upon the available
clinical evidence, we constructed a decision analytic tree,
Incremental Cost Effectiveness Ratio per QALY gained was
calculated. A rigorous sensitivity analysis was undertaken to
check the robustness of our analysis.
50

<!-- page 79 -->

POLICY BRIEF

RESEARCH FINDINGS
Systematic review and meta-analysis on non- invasive
ventilator verses mechanical invasive ventilator was performed
to evaluate the clinical effectiveness of the ventilator. The
forest plot showed Low-cost portable. ventilator (LCPV) was
reducing mortality by 40% when compared to mechanical
invasive ventilation.
We also performed economic modelling and calculated costsaving per Quality Adjusted Life Years (QALYs), assuming noninferiority, the cost- savings if this ventilator is used for
domiciliary purpose.
This intervention is cost-effective at Rs 4845/- per QALY gained,
while the standard of care is cost- effective at Rs 4859/- per
QALY gained. The difference in Incremental Cost Effectiveness
Ratio between the other non-invasive ventilator and the new
ventilator turns out to be approximately Rs. 14 per QALY gained
per patient. The forest plot showed Low-cost portable.
ventilator (LCPV) was reducing mortality by 40% when
compared to mechanical invasive ventilation.

POLICY RECOMMENDATIONS
This LCPV may be particularly useful in the
current situation of COVID-19 pandemic to
overcome ventilator shortage and
resource constraints in India.
LCPV can be used for the patients
requiring long term ventilation.
Ease of accessibility of the device makes it
useful in emergency conditions and it can
be used in ambulance also.
Introduction of LCPV in the Indian
healthcare system appears to be fiscally
sustainable.
Future research should be considered as
data was very limited on which this
analysis was performed.

We also performed economic modelling and calculated costsaving per Quality Adjusted Life Years (QALYs), assuming non-inferiority, the cost- savings if this ventilator is used
for domiciliary purpose. This intervention is cost-effective at Rs 4845/- per QALY gained, while the standard of care
is cost-effective at Rs 4859/- per QALY gained. The difference in Incremental Cost Effectiveness Ratio between the
other non- invasive ventilator and the new ventilator turns out to be approximately Rs. 14 per QALY gained per
patient.

ACKNOWLEDGEMENT
HTAIn Secretariat, Department of Health Research, Ministry of Health & Family Welfare, Government of India.

REFERENCES
HTA on Low-cost portable ventilator (LCPV) by Kalam Institute of Health Technology, Vizag, Andhra Pradesh.

51

<!-- page 80 -->

DEPARTMENT OF HEALTH RESEARCH
MINISTRY OF HEALTH & FAMILY WELFARE
GOVERNMENT OF INDIA
1-REDCROSS ROAD, NEW DELHI
