---
doc_id: "dbdfc9d74c1ff392"
source_url: "https://www.labour.gov.in/static/uploads/2026/05/798bd0d4d7422ae1ca2717675b16f906.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Notification under Section 127 of CoSS, 2020"
date: "2026-05-08"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "fc79946f565c0206"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-09052026-272390
xxxGIDHxxx
CG-DL-E-09052026-272390
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 2266]
No. 2266]

नई दिल्ली, िुक्रवार, मई 8, 2026/वैिाख 18, 1948
NEW DELHI, FRIDAY, MAY 8, 2026/VAISAKHA 18, 1948

श्रम एवं रोिगार मंत्रालय
अजधसूचना
नई दिल्ली, 8 मई, 2026
का.आ. 2357(अ).— कें द्रीय सरकार, सामाजिक सुरक्षा संजिता, 2020 (2020 का 36) की धारा 127 द्वारा प्रित्त
िजियों का प्रयोग करते हुए, जवजनर्ििष्ट करती िै दक संजिता के अधीन संिेय दकसी भी अंििान या दकसी संिेय रकम के जलए,
जनयोिक संजिता के अधीन दकसी रकम के िेय िोने की तारीख से लेकर उसके वास्ट्तजवक संिाय की तारीख तक बारि प्रजतित
प्रजतवर्ि की िर से साधारण ब्याि का संिाय करने का िायी िोगा।

[फा. सं. आर-19025/13/2026-एस एस-I]
आिुतोर् ए .ीी .पेडणेकर, संयुि सजचव

3294 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF LABOUR AND EMPLOYMENT
NOTIFICATION
New Delhi, the 8th May, 2026
S.O. 2357(E).— In exercise of powers conferred by section 127 of the Code on Social Security, 2020 (36 of
2020), the Central Government specifies that for any contribution or any other amount payable under the Code, the
employer shall be liable to pay simple interest at the rate of twelve percent per annum from the date on which any
amount has become due under the Code till the date of its actual payment.

[F. No. R-19025/13/2026-SS-I]
ASHUTOSH A.T. PEDNEKAR, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. SARVESH KUMAR
SRIVASTAVA

Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2026.05.09 01:18:02
+05'30'
