---
doc_id: "da73af7de21bbe76"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/35d0488d195f58ae1dd7de2d8d4e2f19.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Tender Enquiry for Supply office furniture in DST, Technology Bhavan, New Delhi -16"
date: "2016-04-25"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "14936cdda83a5971"
---

<!-- page 1 -->

Government of India
Ministry of Science and Technology
Department of Science and Technology
Administration II (B) Section
Technology Bhavan, New Mehrauli Road
New Delhi-110 016
Tender Enquiry No. D-14013/ 1 /2016 Admin II (B) Part I-Admn II (B)

Date: 25 Apr.,2016.

To,
All Interested & eligible Vendors

Sub: Tender Enquiry for Supply office furniture
in DST, Technology Bhavan, New Delhi -16
Dear Sirs,
For and on behalf of the President of India, sealed tenders are invited from the interested &
eligible firms for Supply of office furniture in the Department of Science & Technology, Technology Bhavan,
New Delhi-16 as per requirements given in the Schedule I to this document.
2.
In case your firm is a manufacturer or valid authorized dealer of the product and interested in the
above said work, you are requested to quote your lowest prices in the enclosed Proforma in a sealed cover.
The sealed cover containing the quotation should be super scribed “Quotation for Supply office furniture
in DST, Technology Bhavan, New Delhi -16” and should be dropped in the tender box kept near the
Reception of the Technology Bhavan on or before the 16th May, 2016 latest by 1500 hours, which will be
opened on the same day at 1530 hrs in Room No.12 Hall-“A”, S & T Block I (Erstwhile WH Block) in the
presence of such tenderers who wish to be present. The Department reserves the right to accept or reject any
quotation/ estimates without assigning any reason thereof.
3.
The sealed envelop must accompanied by a Demand Draft/ Pay order/ banker’s cheque of Nationalized
Bank for Rs.25,000/- (Rupees twenty five thousand only) as earnest money deposit. The earnest money
amount will be returned to the unsuccessful firm immediately after the award of the contract to successful
bidders and the earnest money of the successful tenderer will be returned only after submission of Performance
Security as mentioned in |Annexure “A” to this document.
4.
Tendering firms fulfilling the requirements in this tender document are requested to quote their
competitive lowest prices as per the requirements given in the attached schedules.
Yours faithfully,

(Pawan Sharma)
Under Secretary to the Govt of India
Tel: 26590538

Cont’d…..02/-

<!-- page 2 -->

Page No.02/07
Annexure “A”
IMPORTANT
INFORMATION
& GENERAL INSTRUCTIONS

1.
2.
3.

4.
5.

6.

7.

8.

9.

Purchaser
Single bid system
Firm and fixed rates

THE PRESIDENT OF INDIA
This tender will be processed in single bid system
Prices should be quoted on a firm & fixed price basis. The prices/rates
quoted should be indicated in words as well as in figures and in INR only.
Request for enhancement of contracted rates shall not be considered under
any circumstances. Tenders with variable prices or seeking provision for
enhancement of prices/contracted rates shall be rejected straightaway
without any consideration.
Non-transferability
This tender is non-transferable.
Terms & conditions
Terms & Conditions as set out in this Tender Document shall have to be
complied with by the tendering firm. Offers not complying with such terms
& conditions shall be ignored/ rejected at the discretion of this Department.
Earnest
Money The requisite amount has to be submitted by way of Demand Draft, Pay
Deposit
Order/Banker’s Cheque along with the original copy of the tender submitted
by the firm in the name of DDO, DST, New Delhi. Payment by any other
mode shall not be acceptable. Offers received without EMD shall be
ignored straightaway and will not be considered under any circumstances.
EMD of tendering firms who submit the sealed quotation but withdraw the
same before expiry of the tender validity date may be forfeited.
Performance Security Successful bidders who are awarded the work order for carrying out the
jobs on the basis of this Tender Enquiry shall be required to furnish a
Performance Security for a period of nine months (Warranty period + 03
months) of an amount equal to 10% of the awarded cost of the contract
(excluding statutory duties and taxes) in the form of DD/ Pay order,
Banker’s Cheque, Fixed Deposit Receipt (FDR) in favour of DDO, DST or
Bank Guarantee from any Nationalized Indian Bank within 15 days of the
award of the Contract for a period of nine months. The format for such
Performance Bank Guarantee (PBG) will be provided by DST along with the
work order. In the event of failure on the part of the successful bidder
awarded the Contract to furnish Performance Security, EMD furnished with
the Tender by such firm shall stand forfeited.
Prescribed Forms
Tenders of firms received in the format prescribed in this tender document
shall only be considered. Offers not received in prescribed format shall be
ignored and no correspondence in this regard will be entertained.
Telegraphic/ Telex/ Fax/ E-mail/ Letterhead/ Quotations will not be
accepted and ignored straightaway.
Late/ delayed tenders Tenders received late/ delayed after prescribed closing time due to any
reason whatsoever will not be accepted under any circumstances. In the
event of any confusion, the time set in the clock in the room of Under
Secretary (Admn.II-B) will be taken as standard and decisive. Tenderers
may note that if the date of tender opening given in this Tender Document
is declared a closed holiday by the Central Government, the tender shall be
opened on the next working day at the same timing. In such an event the
closing hours for receipt of tenders in DST will stand automatically extended
up to 1500 hours of the next working day in the Central Government
offices.
Signature of the bidder

Cont’d…..03/-

<!-- page 3 -->

Page No.03/07
10.

Duties & Taxes

Tenderers are requested to enclose a copy of their valid sales tax
certificate/ VAT registration number.
i)
Excise Duty: The tenderers must clearly indicate in their bid the
rate/ quantum of Excise Duty applicable and payable by them
irrespective of the fact whether the quoted prices are inclusive or
exclusive of Excise Duty. If it is intended to ask for excise duty or any
other charges extra, the same must be specifically stated. In absence of
such stipulation it will be presumed that prices are inclusive of all such
charges and no claim for the same will be entertained. They should also
indicate their Excise Duty Registration. In the case of Small Scale
Industrial Units, they should indicate the rates of Excise Duty in various
turnover slabs.
If a tenderer states in his bid that the Excise Duty is nil, he must
intimate the basis for the same and also confirm that no Excise Duty will
be charged by him under any circumstances.
(ii)
Sales Tax/ VAT: Tenderers should indicate in their Bid whether
the prices quoted are exclusive or inclusive of sales tax/ VAT. They
should indicate the rate (s) of VAT/ Local Sales Tax (as may be
applicable) and Central Sales Tax with & without Form-“C”. In case, they
are exempted from payment of sales tax, a copy of the Exemption
Certificate issued by the appropriate authority may be furnished.
The quotation should be addressed to “Under Secretary, Admin II (B)
Section, Department of Science & Technology, Technology Bhavan,
New Mehrauli Road, New Delhi-16 and should be dropped in the
Tender Box of Admn. II B Section kept near Reception Room at the
entrance of Technology Bhavan, New Mehrauli Road, New Delhi on
or before at 1500 hours on 16th May., 2016. In case the sealed
envelope is larger than the mouth of the Tender Box, and cannot be
dropped in the Tender Box, the same may be submitted by hand to
Under Secretary, Admn.II B or S.O. Admn II B, DST.
Authorized representative of DST, New Delhi
Department of Science and Technology (DST), Technology Bhavan,
New Delhi or any party, a Govt. agency, so authorized by DST.
Entitlement Cell, Hall-E, WH Block, DST, Technology Bhavan, New
Delhi-16
Within 30 days of the receipt of confirmed work order by the firm.

11.

Purchaser’s Address

12.
13.

Inspecting Officer
Inspection Authority

14.

Work site

15.

Job
Execution
period
Dispatch
Stores are required to be delivered at the Technology Bhavan
instructions
premises on free delivery to the consignee’s premises/ freight paid
basis.
Payments Terms
100% payment shall be released on successful supply of items in full
satisfaction of the Department. Advance payment will not be made
under any circumstances.
Purchaser’s right
Purchaser reserves the right to reject any tender/all tenders in full or
part thereof without assigning any reasons.
Validity of offer
Up to 90 days from the date of opening of the bid.
Eligibility condition
The manufacturer or the authorized dealer of the firms are only can
participate in the tendering process subject to submission of valid
documents.

16.

17.

18.
19.
20.

Signature of the bidder

Cont’d…..04/-

<!-- page 4 -->

Page No.04/07

21.

Paying Authority

22.

Liquidated Damages

Controller of Accounts or his authorized representative, Pay &
Accounts Office, DST, New Delhi-110016
In case the firm does not complete the work within the work
execution period as stipulated, action will be taken against the firm
to recover from the contractor as agreed liquidated damages
including administrative expenses and not by way of penalty a sum
equivalent to ½ % per week of the price of any stores which the
contractor has failed to execute/ deliver/install within the stipulated
time limit. Where delivery thereof is accepted after expiry of the
aforesaid period, the total damages so claimed shall not exceed
10% of the total contract price.

23.

24.

Evaluation of bid &
Item-wise prices should be quoted and the contractor has offered
Acceptance of offer
the lowest bundled price in the schedule, then the total contract will
be awarded to the contractor.
Warranty
Six months comprehensive from the date of completion of job. Any
complaint shall be attended within a response time of 48 hours on
24X7 basis. Any defects in workmanship or detoriation in the
quality or deviation to tender specifications coming to notice shall be
rectified at site within 72 hours of the reporting of the same to the
contractor. If system is required to be picked up and taken to
your premises for removing the defects, the same shall be picked up
from the consignee latest by the next working day and dropped
back to the consignee within 07 working days. Any component
required to be replaced within the warranty period shall be totally
new component and not reconditioned or repaired component.

Signature of the bidder

Cont’d…..05/-

<!-- page 5 -->

Page No.05/07
Appendix I
Department of Science & Technology
Admin II (B) Section
Contractor’s details

Supporting documents be annexed with the application form (Applications found deficient in
any respect are liable to be rejected without further correspondence)
Sl
No.
01
02
03

04

05

06

07

Description

Information

Name of the Applicant/ Firm
Nationality
Address
Regd. Office
(attach separate paper for
addresses of other offices)
Head office

Telephone Numbers

Landline No.
Mobile No.
Fax No.
E-mail address
Other Details
PAN Details
VAT
Registration
Number
Constitution
Individual
Sole
Proprietorship
Concern
Partnership Firm
Public Ltd. Company
Private ltd. Company/
Public Sector Enterprises
Is
the
Individual/
sole Dismissed Government yes
No
Proprietor/ any Partner of the Servant
Firm/ Director of Company
Removed from approved Yes
No
list of contractors
Demoted to a lower class Yes
No
of contractors in CPWD/
PWDs
Convicted by a court of Yes
No
law
Retired official of Govt of Yes
No
India within last one year
Director or partner of any Yes
No
other company/ firm with
CPWD/ PWDs or any
other Govt Department
Member of Parliament or Yes
No
any State Legislative
Assembly
If answer to any of the above is “Yes”, furnish details on a
separate sheet

Signature of the bidder
Cont’d…..06/-

<!-- page 6 -->

Page No.06/07

Sl
No.
08

09
10
11
12

13

Description

Information

Applying firm is manufacturer/
Authorized
dealer
(if
authorized dealer attach valid
dealership certificated issued
by the manufacturer)
a) Name of the person holding
power of attorney
b) Nationality
Name of the Bankers with full
details/ orders
Place of business
Is any person working with the
applicant a near relative of the
official of DST? If yes, give
details
Certificates
a)
I/ we (including all partners) certify that I/ we have read the
Terms & Conditions mentioned in the tender enquiry form and
shall abide by them
b)
I/ we certify that the information given is true to the best of my/
our knowledge. I/ we also understand that if any of the
information is found wrong/ false at any stage. I/ we are liable
to be deregistered from panel of approved contractors/
banned for doing any business dealings with Government
Departments or blacklisted or subject to any monetary
penalties that be deemed fit and appropriate by DST/
Government.

Signature of the bidder

Cont’d…..07/-

<!-- page 7 -->

Page No.07/07

Department of Science & Technology
Schedule I to TE No.D-14013/ 1 /2016 -Admin II (B) Part I dated 22nd Apr., 2016
Scope of work, specifications, location (s), design, quantity and quality
parameters etc. for supply of office furniture in DST, Technology Bhavan, New Delhi16.
A.

Location: DST, Technology Bhavan, New Delhi-110016.

B.

Scope, specification, quantity and quality parameters:

Technical specification of items:
(i)
Sl
No.
A

Product Manufacturer: M/s Stellar or equivalent manufacturer
Name of the item

Model

Technical Specifications

Visitor Chair

DO-26 or
equivalent

Medium back chair with MS Frame with chromium plating,
fixed base, hard wooden arm, PU seat and back. Black in
colour.

Schedule of supply & abstract of cost: Supply of office furniture in DST, Technology Bhavan,
New Delhi
Group A to Schedule
Sl
No.
a

Description
item
Visitor Chair

b

Total
bundled
price exclusive
taxes etc.
CST/ VAT/ ST
etc.
Total
bundled
price
inclusive
taxes etc.

c
d

of

Make/ Model

Unit

Steller/ DO26
or
equivalent

Each

Unit rate in
Rs.

Qty**

Amount in Rs.

Remarks

60

**Note:- The quantity of chairs may vary during placing of supply order as per requirement of the
Department.

Signature of bidder
