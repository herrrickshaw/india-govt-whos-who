---
doc_id: "daff203e0eef9b43"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/cc69ba7323710c50acc605af86535775.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Reservation Policy for the Scheduled Cast- implementation of"
date: "2025-07-15"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5d6e53d493eb4712"
---

<!-- page 1 -->

..•.
--

,

-=.=:...:.:~.::."-

- .. ---'-_--_.
.--.. _-: - ~~ -.:-~:.----~-_._._~--.--

-

.--.~.
..

~~.'."'"-.

"';A)
::I. (!)
O'r,n
(i) (!)

l~
3 g
-0

;:J

COw
:3 0
=
::l (")
(!)

-- '<

~. 0'
g -,
:;
~(j)

(f)

o

::::T
(j)

0.

c

r0c.

o
[l)

r,n

(0
r,n
[l)

::J

C.
(f)

o
ro
c.

::::T

c

CXl

o
-n

!l
C')

m

:so;

m
~

o
~
Z

o
OJ
(0
C.

'Ci
C

::::T

S

(J,)

(!)

o

~

Z
o

<
(j)

3
0'

CD
."""l

(!)

(0
(0

0.

<XI

N

~

s:
s·
Ul'
:::t

-CD

o
-.
m
o
o
;:J
o

3

!<!.

o

CD
-0
[l)

;::::l.

3
CD

::J
o· .....
Ul

~
~.

o
-.,

......
.....

::::T

to

ro

G)

o
<
CD

:3
3
CD
~

o
-.,
:::J

z
(j)

~

o
(j)

::::T

0.

w
