---
doc_id: "c482015abcdfb1aa"
source_url: "https://powermin.gov.in/static/uploads/2025/06/b271308629d03e019a19f31b13c7ae5a.pdf"
ministry: "Power"
title: "tender 68"
date: "2011-12-12"
pages: 7
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "50d6122e6c0c9161"
---

<!-- page 1 -->

No. 9/10/2011-Adm.lll
Government of India
Ministry of Power
Shram Shakti Bhawan, Rafi Marg, New Delhi-110001
Telephone No. 23715507; FAX No. 23717519 है
Dated: 12.12.2011
To,

As per list attached,

Sub:- Quotation for repair of furniture items in the Ministry of Power for the
year 2012-2013 maintenance on annual contract basis —req.
Sir,

Sealed quotations are invited from registered/ reputed firms for
award of annual maintenance contract for repair/ maintenance of furniture
items in the Office of Ministry of Power located at Shram Shakti Bhawan,
Nirman Bhawan, Residence Office of Hon'ble Minister of Power and
Minister of State for Power for one year i.e. from 01.04.2012 to 31.03.2013
on the terms and conditions mentioned at Annexure-!. Firms interested to

है undertake the above mentioned work, may please submit sealed quotations
in the enclosed proforma (Annexure-ll) addressed to the Under Secretary
(GA), Ministry of Power, Government of India, Shram Shakti Bhawan, New
Delhi. The quotations should be dropped in the “Tender Box’ of the Ministry
of Power located at Gate No. 5 of Shram Shakti Bhawan up to 03.00 P.M.
on 26" December, 2011. The quotation dropped after 3.00 P.M. on *
26.12.2011 will not be entertained. The quotations should be accompanied
with ‘Earnest Money’ of Rs. 10,000/- (Rupees Ten Thousand Only) in the
form of Demand Draft of any nationalized band drawn in favour of the “Pay
& Accounts Officer’, Ministry of Power, Government of India, New Delhi.
The quotations which are not accompanied with the ‘Earnest Money’ will be
summarily rejected. The envelop should be subscribed “QUOTATIONS
FRO REPAIR/ MAINTENANCE OF FURNITURE ITEMS IN THE
MINISTRY OF POWER”.
2 The quotations will be opened at 4.30 P.M. on the same day i.e. 26
December, 2011 in Room No. 22, Ministry of Power Shram Shakti Bhawan,
New Delhi.
Yours faithfully,
by RAW हे
(P.K.SINGH)
Section Officer (Adm.II!)
Tel: 23766463
Cony ta-

<!-- page 2 -->

ANNEXURE-|
TERMS AND CONDITIONS:-
1. The period of contract will be one year i.e. from 01.04.2012 to
31.03.2013. The Ministry may extend the contract on the existing rates and
Terms & Conditions if the services of the firm are found satisfactory. This
Ministry, however, reserve the right to terminate the contract at any time

» without assigning any reasons therefore.
2. The firms should have sufficient experience of the work in
government/State Government Departments.
3. The firm/Contractor should be registered with Delhi Sales Tax
Department. है
4. The work is to be carried out in the Office premises at Shram Shakti
Bhawan, Nirman Bhawan and Residence Office of Hon'ble Minister of
Power and Minster of State for Power.
5: Only such work which cannot be carried out in the office premises
will be allowed to be done outside the office premises and no extra charge
will be paid on such account.
6. No advance payment will be made in any case.
Te One exclusive Carpenter /technician will have to be deployed in the
Ministry of Power on all working days during Office hours and in the
urgency on holidays also, by the successful bidder for repair /maintenance
of furniture items.
8. The successful tenderer will be required to deposit “Performance
Security Deposit” of Rs. 25,000/- (Rupees Twenty Five Thousand only)
which will be refundable after 60 days on successful completion of contract.
The performance Security Deposit will be forfeited if during the period of
contract, the services of the contractor are found unsatisfactory in any
respect or in the event of breach of contract by him before the date of
maturity of the contract.
9. The bidder will indicate the complete address of their firm/office and
residence along with telephone numbers and other related information
strictly as per enclosed proforma (Annexure-li!).
pe

<!-- page 3 -->

40. During the entire period of contract, no request for any increase in
the rates on any account would be entertained and the performance would
be reviewed from time to time. In case, the contractor fails to cope with the
workload or does not render satisfactory service, the contract awarded to
him shall be cancelled forthwith without giving any notice or without
assigning any reason and his security deposit and payment due to the firm,
if any, shall be forfeited. In such circumstances, the work will be got done
from any firm in the field at the risk and cost of the firm awarded the:
contract and payment made for repair/maintenance on this account will be
deducted from the pending bills or “performance Security Deposit” of the
firm. In this connection, the decision of the Ministry of Power shall be final
and binding on the contractor.
41. If the work of the contractor is found unsatisfactory or है
‘Carpenter/Technician deployed by the successful firm is not punctual and
regular, penalty amounting to Rs. 500/- (Rupees five Hundred) per day will
be imposed on the firm and the same will be deducted from the pending
bills/"Performance Security Deposit” of the firm and the contract can be
. terminated by this Ministry at any time without assigning any reasons
therefore. The decision of the Ministry shall be final and binding on the
contractor.
42. This Ministry also reserves the right to reject any quotations (s) in full
or in part without assigning any reasons thereto. हु
While submitting the quotation for this work, the bidder will be
deemed to have read, understood and accepted all the terms and
condition
४

<!-- page 4 -->

Annexure-IT

(|G) WoodenChair ऊल्‍् |
| |
|__| (2)SteelRevolvingChair |
|
|
[4.___|ProvidingofStelBase |
| |
[___|@)OfficeTable |
[T._|ReplacementofHandle
| |
| 9 |;
Opening of Drawers. कमाना
[6. | Providing & fixing of Sunmicatop(psf) | |;
fo
[8.___| Providing & fixing ofnewlocking system | |;
|
[1. |
Replacement of Handle
Minor repairs
Providing of duplicate keys (two)
OpeningofAlmirah || ्रफ््रडर
P/E of new locking system
|__| (5) Steel Compactors
Minor Repair of Compactor
|
[1. | RepairofDoor Closer |
fd
|__| (7) SteelBookCase |
[|
| |
[| |
[| झढझष
____| (8) Wooden furniture with screw & nails ||
fT
P|
|
[ |
| [|
[6. |

ye

<!-- page 5 -->

[

[1 |

[| |
—
(4. Repair of Vertical Blinds श्र
|
(जा

_ |
हि शक पिन पौै।।_|
[Ps |/'ढ
P|
P|
|
Change/Cost of Cloth per meter (Cottarise) San
(8. __| Change/Cost of ‘Leatherite’ per meter (Good Qualtiy) | |
Cost of Cloth per meter (Handloom)
a
li. | Window polish (psqf) [|
Sunmica Top (Table) — psqf

Door Polish — psqf

Removal of old polish — psqf

New liquor polish - psqf

Oil bound distemper -psqf

|
8. |

[9x |

10.

11,

i ——~
Dismantling of old partition [sz
| ृक्‍फऑ'
——~
Providing of White Megnatic Board — psqf
|
कितनी “>ऊ>.>#>्78्ऊ्

—

_ |

|
ker

<!-- page 6 -->

SLNo. [Item —“——..C;Ct Rates
| &£'
-———_ -]
|
je ऊ'
| &£ऊऋ'
jp &£'
po |
Providing & fixing of Teak margin — running feet
Providing & fixing of Teak ply (4 mm) - psqft
Providing & fixing of computer key board

<!-- page 7 -->

ANNEXURE-III
[
|...  झऑऋ|
; |
communication
[
[_....  ्फफ७ऊऊ/फऊफझल्‍ ेव
(6. |
|
Details of EMD Deposit
1. |
Date
ee
wr
