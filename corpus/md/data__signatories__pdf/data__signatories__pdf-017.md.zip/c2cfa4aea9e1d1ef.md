---
doc_id: "c2cfa4aea9e1d1ef"
source_url: "https://financialservices.gov.in/sites/default/files/order-notices/Gazette%2520Notifications%2520%25283%2529_3.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "Gazette%20Notifications%20%283%29_3.pdf"
date: ""
pages: 4
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "8cbdf8210bc2753d"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल. (एन) 04/0007/2003--05 REGD. NO. D. L. (N) 04/0007/2003—05
i y
nN
3९) |
Che G r Indi
2 bazelte of India
सी.जी.-डी.एल.-सा.-24082022-238318
CG-DL-W-24082022-238318
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY

साप्ताहिक

WEEKLY
a 33) नई दिल्ली, अगस्त 14-- अगस्त 20, 2022, शनिवार/ श्रावण 23-- श्रावण 29, 1944
No. 33] NEW DELHI, AUGUST 14—AUGUST 20, 2022, SATURDAY/SRAVANA 23-SRAVANA 29, 1944

इस भाग में भिन्‍न पृष्ठ संख्या दी जाती है जिससे कि यह पृथक संकलन के रूप में रखा जा सके
Separate Paging is given to this Part in order that it may be filed as a separate compilation
भाग 1---खण्ड 3---उप-खण्ड (॥)
PART [1—Section 3—Sub-section (ii)
भारत सरकार के मंत्रालयों (रक्षा मंत्रालय को छोड़कर) द्वारा जारी किए गए सांविधिक आदेश और अधिसूचनाएं
Statutory Orders and Notifications Issued by the Ministries of the Government of India
(Other than the Ministry of Defence)

5373 GI/2022 (1553)

<!-- page 2 -->

1554 THE GAZETTE OF INDIA : AUGUST 20, 2022/SRAVANA 29, 1944 [PART II—SEc. 3(ii)]
वित्त मंत्रालय
वित्तीय सेवाएं विभाग
नई दिल्‍ली, 11 अगस्त, 2022
का.आ. 758.--भारतीय रिजर्व बैंक अधिनियम, 1934, (1934 का 2) की धारा 8 की उप-धारा (4) के साथ
पठित धारा 8 की उप-धारा (1) खंड (ग) के अंतर्गत प्रदत्त शक्तियों का प्रयोग करते हुए, केन्द्रीय सरकार, एतट्टारा, श्री
सतीश काशीनाथ मराठे (जन्म तिथि: 1.2.1950) को इस अधिसूचना की तारीख से अगले चार वर्ष की अवधि के लिए
अथवा अगले आदेशों तक, जो भी पहले हो, भारतीय रिजर्व बैंक के केन्द्रीय बोर्ड में अंशकालिक गैर-सरकारी निदेशक के पद
पर पुनः नामित करती है।
[फा. सं. 6/6/2022-बीओ-1]
संजय कुमार मिश्र, अवर सचिव
MINISTRY OF FINANCE
DEPARTMENT OF FINANCIAL SERVICES
New Delhi, the 11th August, 2022
$.0. 758.—In exercise of the powers conferred under clause (c) of sub-section (1) of Section 8 read with
sub-section (4) of Section 8 of the Reserve Bank of India Act, 1934 (2 of 1934), the Central Government hereby re-
nominates Shri Satish Kashinath Marathe (DOB: 1.2.1950) as part-time, non-official Director on the Central Board of
Reserve Bank of India for a further period of four years, from the date of this notification or until further orders,
whichever is earlier.
[F. No. 6/6/2022-BO-1]
SANJAY KUMAR MISHRA, Under Secy.
नई दिल्‍ली, 11 अगस्त, 2022
का.आ. 759.--भारतीय रिजर्व बैंक अधिनियम, 1934, (1934 का 2) की धारा 8 की उप-धारा (4) के साथ
पठित धारा 8 की उप-धारा (1) खंड (ग) के अंतर्गत प्रदत्त शक्तियों का प्रयोग करते हुए, केन्द्रीय सरकार, एतट्टारा,
श्री स्वामीनाथन गुसुमूर्ति (जन्म तिथि: 4.3.1949) को इस अधिसूचना की तारीख से अगले चार वर्ष की अवधि के लिए
अथवा अगले आदेशों तक, जो भी पहले हो, भारतीय रिजर्व बैंक के केन्द्रीय बोर्ड में अंशकालिक गैर-सरकारी निदेशक के पद
पर पुन: नामित करती है।
फा. सं. 6/6/2022-बीओ-1]
संजय कुमार मिश्र, अवर सचिव

<!-- page 3 -->

[भाग ॥--खण्ड 3(॥)] भारत का राजपत्र : अगस्त 20, 2022/श्रावण 29, 1944 1555
मी  +-८-- न  लनल--->---- न +---------_-त-+----ट--------- कस
New Delhi, the 11th August, 2022

S.0. 759.—In exercise of the powers conferred under clause (c) of sub-section (1) of Section 8 read with
sub-section (4) of Section 8 of the Reserve Bank of India Act, 1934 (2 of 1934), the Central Government hereby re-
nominates Shri Swaminathan Gurumurthy (DOB: 4.3.1949) as part-time, non-official Director on the Central Board of
Reserve Bank of India for a further period of four years, from the date of this notification or until further orders,
whichever is earlier.

[F. No. 6/6/2022-80-1]
SANJAY KUMAR MISHRA, Under Secy.
नई दिल्‍ली, 11 अगस्त, 2022

का.आ. 760.-.भारतीय रिजर्व बैंक अधिनियम, 1934, (1934 का 2) की धारा 9 की उप-धारा (1) और उप-
धारा (3) के अंतर्गत प्रदत्त शक्तियों का प्रयोग करते हुए, केन्द्रीय सरकार, एतट्टारा, प्रो. सचिन चतुर्वेदी (जन्म तिथिः
26.10.1967) को दिनांक 18.9.2022 को उनके वर्तमान कार्यकाल की समाप्ति के पश्चात अगले चार वर्ष की अवधि के
लिए अथवा अगले आदेशों तक, जो भी पहले हो, भारतीय रिजर्व बैंक के पूर्वी स्थानीय बोर्ड में सदस्य के पद पर पुनः
नियुक्त करती है।

[फा. सं. 6/6/2022-बीओ-[]
संजय कुमार मिश्र, अवर सचिव
New Delhi, the 11th August, 2022

S.0. 760-.—In exercise of the powers conferred under sub-section (1) and sub-section (3) of Section 9 of the
Reserve Bank of India Act, 1934 (2 of 1934), the Central Government hereby re-appoints Prof. Sachin Chaturvedi
(DoB 26.10.1967) as Member on the Eastern Local Board of the Reserve Bank of India, for a further period of four
years, after completion of his present tenure on 18.9.2022, or until further orders, whichever is earlier.

[F. No. 6/6/2022-BO-I]
SANJAY KUMAR MISHRA, Under Secy.
नई दिल्‍ली, 11 अगस्त, 2022

का.आ. 761.--भारतीय रिजर्व बैंक अधिनियम, 1934, (1934 का 2) की धारा 8 की उप-धारा (1) के खंड (ख)
के अंतर्गत प्रदत्त शक्तियों का प्रयोग करते हुए, केन्द्रीय सरकार, एतद्दारा, पूर्वी स्थानीय बोर्ड से प्रो. सचिन चतुर्वेदी (जन्म
तिथि: 26.10.1967) को दिनांक 18.9.2022 को उनके वर्तमान कार्यकाल की समाप्ति के पश्चात अगले चार वर्ष की
अवधि के लिए अथवा अगले आदेशों तक, जो भी पहले हो, भारतीय रिजर्व बैंक के केन्द्रीय निदेशक मंडल में अंशकालिक
गैर-सरकारी निदेशक के पद पर पुन: नामित करती है।

[फा. सं. 6/6/2022-बीओ-1]
संजय कुमार मिश्र, अवर सचिव
New Delhi, the 11th August, 2022

S.0. 761.—In exercise of the powers conferred under clause (b) of sub-section (1) of Section 8 of the
Reserve Bank of India Act, 1934 (2 of 1934), the Central Government hereby re-nominates Prof. Sachin Chaturvedi
(DoB: 26.10.1967) from Eastern Local Board as part-time, non-official Director on the Central Board of Directors of
Reserve Bank of India, for a further period of four years, after completion of his present tenure on 18.9.2022, or until

further orders, whichever is earlier.
[F. No. 6/6/2022-BO-I]
SANJAY KUMAR MISHRA, Under Secy

<!-- page 4 -->

1556 THE GAZETTE OF INDIA : AUGUST 20, 2022/SRAVANA 29, 1944 [PART II—SEC. 3(ii)]
नई दिल्‍ली, 11 अगस्त, 2022
का.आ. 762.--भारतीय रिजर्व बैंक अधिनियम, 1934, (1934 का 2) की धारा 9 की उप-धारा (1) और उप-
धारा (3) के अंतर्गत प्रदत्त शक्तियों का प्रयोग करते हुए, केन्द्रीय सरकार, एतट्टारा, सुश्री रेवती अय्यर (जन्म तिथि:
28.5.1954) को दिनांक 18.9.2022 को उनके वर्तमान कार्यकाल की समाप्ति के पश्चात अगले चार वर्ष की अवधि के लिए
अथवा अगले आदेशों तक, जो भी पहले हो, भारतीय रिजर्व बैंक के उत्तरी स्थानीय बोर्ड में सदस्य के पद पर पुनः नियुक्त
करती है।
[फा. सं. 6/6/2022-बीओ-1]
संजय कुमार मिश्र, अवर सचिव
New Delhi, the 11th August, 2022
8.0. 762.—In exercise of the powers conferred under sub-section (1) and sub-section (3) of Section 9 of the
Reserve Bank of India Act, 1934 (2 of 1934), the Central Government hereby re-appoints Ms Revathy lyer (DoB:
28.5.1954) as Member on the Northern Local Board of the Reserve Bank of India, for a further period of four years,
after completion of her present tenure on 18,9.2022, or until further orders, whichever is earlier.
[F. No. 6/6/2022-BO-1]
SANJAY KUMAR MISHRA, Under Secy.
नई दिल्‍ली, 11 अगस्त, 2022
का.आ. 763.---भारतीय रिजर्व बैंक अधिनियम, 1934, (1934 का 2) की धारा 8 की उप-धारा (1) के खंड (ख)
के अंतर्गत प्रदत्त शक्तियों का प्रयोग करते हुए, केन्द्रीय सरकार, एतट्टारा, उत्तरी स्थानीय बोर्ड से सुश्री रेवती अख्यर (जन्म
तिथि: 28.5.1954) को दिनांक 18.9.2022 को उनके वर्तमान कार्यकाल की समाप्ति के पश्चात अगले चार वर्ष की अवधि
के लिए अथवा अगले आदेशों तक, जो भी पहले हो, भारतीय रिजर्व बैंक के केन्द्रीय निदेशक मंडल में अंशकालिक गैर-
सरकारी निदेशक के पद पर पुन: नामित करती है।
[फा. सं. 6/6/2022-बीओ-1]
संजय कुमार मिश्र, अवर सचिव
New Delhi, the 11th August, 2022
S.O. 763.—In exercise of the powers conferred under clause (b) of sub-section (1) of Section 8 of the
Reserve Bank of India Act, 1934 (2 of 1934), the Central Government hereby re-nominates Ms Revathy lyer (DoB:
28.5.1954) from Northern Local Board as part-time, non-official Director on the Central Board of Directors of
Reserve Bank of India, for a further period of four years, after completion of her present tenure on 18.9.2022, or until
further orders, whichever is earlier. °
[F. No. 6/6/2022-BO-I]
SANJAY KUMAR MISHRA, Under Secy.
