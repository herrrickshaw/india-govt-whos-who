---
doc_id: "c0eebc0d031f4dbf"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/36df1dfd9c481d20b454286dcdec4aeb.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer & posting of officers in JAG of ITS Group A-reg"
date: "2024-10-29"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "11c8f2bc7a5b3ee3"
---

<!-- page 1 -->

12-2/2024-STG-I

I/3221962/2024

No. 12-2/2024-STG-1
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi
Dated the 29th October 2024
OFFICE ORDER
Subject: Transfer & posting of officers in JAG of ITS Group ‘A’-reg.
Approval of the competent authority is hereby conveyed for transfer and
posting of following officers in JAG of ITS Group ‘A’ with immediate effect:
S.No. Staff Name of the
No. officer
(Shri/Ms.)

Present
Place of
Posting

Posting on Remarks
Transfer

1. 21002 Manish Kumar J&K LSA
Bansal

DoT HQs

(Own Cost)

2. 21227 Harish Kumar Under
Posting

DoT HQs

-

3. 21184 Atique Ahmed IR Wing,
DoT HQs

BTU Unit,
DoT HQs

Vide DoT OM No. 3034/2024-Admn. Cord., Dated
28.10.2024

2.
Further, approval of the competent authority is also conveyed to withdraw
the transfer / posting order in respect of Shri Pranab Kumar Roy [Staﬀ No.21102]
issued vide this oﬃce order No.12-2/2024-STG-I dated 12/04/2024 (at Sr. No. 32).
Shri Pranab Kumar Roy is hereby retained in BSNL until 31/03/2025.
3.

Charge report may be furnished to all concerned. Hindi version will follow.

(Bijender Singh)
Under Secretary to the Government of India
Tele 011-2303 6282
Copy to:
1. Chairman, DCC/ Member(S)/ Member(T)/ Member(F)/ DG Telecom, DoT;
2. AS (T)/ Administrator USoF / All Advisors, DoT;
3. CMD, BSNL;
4. CVO, DoT HQ;
5. All Sr. DDGs/ DDGs, DoT HQs/ DDG(C&A) DoT Hqrs;
6. ADG (APAR)/AD (STG-I)/AAO (STG-I), DoT HQs;
7. Admin. I- IV/ Cash/ Pension/ Library/ G-I/ G-II/ PF/ PHP/ RTI/ Vig.I Sections DoT

<!-- page 2 -->

12-2/2024-STG-I

I/3221962/2024

Hqrs.;
8. SO, Pay Bill Section/ SO(O&M);
9. Officers concerned;
10. Official Language Section, DoT for Hindi version of the order.
11. Order Bundle/ PA to US(SGT) for uploading this order on DoT website.
