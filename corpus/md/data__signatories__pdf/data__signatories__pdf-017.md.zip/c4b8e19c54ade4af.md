---
doc_id: "c4b8e19c54ade4af"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/d2be83d334d5cbaa616f896ee62ea97c.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Mission Indradhanush guidelines"
date: "2025-12-02"
pages: 80
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0f19f086b359f92b"
---

<!-- page 1 -->

<!-- page 2 -->

Mission Indradhanush:
In PRAGATI, Hon’ble Prime Minister Shri Narendra Modi calls for aggressive
action plan to cover all children for immunization in a specific time‐frame
“Hon’ble Prime Minister, Shri Narendra Modi, has reviewed Mission Indradhanush under ‘PRAGATI’ –
the ICT‐based, multi‐modal platform for Pro‐Active Governance and Timely Implementation” with
Chief Secretaries on 17 February 2016. During the session, he emphasized the need for an organized
and aggressive action plan to cover all children for immunization in a specific time‐frame.

Source:http://pmindia.gov.in/en/news updates/pms‐interaction‐through pragati9/?comment=disable

<!-- page 3 -->

TABLE OF CONTENTS
BACKGROUND........................................................................................................................................... 3
RATIONALE FOR MISSION INDRADHANUSH .................................................................................. 5
OBJECTIVES OF MISSION INDRADHANUSH .................................................................................... 6
STRATEGY FOR MISSION INDRADHANUSH PHASE III ................................................................. 7
COMPONENTS OF MISSION INDRADHANUSH ................................................................................ 9
STEPS FOR ROLL‐OUT OF MISSION INDRADHANUSH............................................................... 16
STATE LEVEL ACTIVITIES FOR MISSION INDRADHANUSH ..................................................... 17
DISTRICT LEVEL ACTIVITIES FOR MISSION INDRADHANUSH ............................................... 20
BLOCK LEVEL ACTIVITIES FOR MISSION INDRADHANUSH .................................................... 24
FREQUENTLY ASKED QUESTIONS FOR MISSION INDRADHANUSH ...................................... 26
STEPS FOR PREPARATION OF MICROPLANS FOR MISSION INDRADHANUSH.................. 33
VACCINES AND LOGISTICS MANAGEMENT ................................................................................... 38
ROLE OF PARTNER AGENCIES .......................................................................................................... 43
MONITORING AND EVALUATION .................................................................................................... 45
KEY POINTS FOR SUCCESSFUL IMPLEMENTATION OF MISSION INDRADHANUSH PHASE
III……… ..................................................................................................................................................... 49
ANNEXURES ............................................................................................................................................ 52

<!-- page 4 -->

LIST OF ACRONYMS
AD

auto-disable

AEFI

adverse event following immunization

ANM

auxiliary nurse midwife

ASHA

accredited social health activist

AVD

alternate vaccine delivery

AWW

Anganwadi worker

BCC

behaviour change communication

BCG

Bacillus Calmette-Guerin vaccine

CBO

community based organization

CES

coverage evaluation survey

CHC

community health centre

CMO

chief medical officer

CSO

civil society organization

DHS

District Health Society

DIO

district immunization officer

DLHS

district level household and facility survey

DPT

diphtheria–pertussis–tetanus vaccine

DTFI

district task force for immunization

DUDA

district urban development agency

EPI

expanded programme on immunization

GoI

Government of India

HMIS

health management information system

HRA

high-risk area

IAP

Indian Academy of Paediatrics

ICDS

Integrated Child Development Services

IEC

information, education and communication

ILR

ice-lined refrigerator

IMA

Indian Medical Association

IPC

interpersonal communication

ITSU

Immunization Technical Support Unit

JE

Japanese Encephalitis

LHV

lady health visitor

MCH

maternal and child health

1
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 5 -->

MCP

mother–child protection (card)

MCTS

mother and child tracking system

MCV-2

measles-containing vaccine second dose

MD (NHM)

Mission Director, National Health Mission

MI

Mission Indradhanush

MOIC

medical officer in-charge

MO

medical officer

MoHFW

Ministry of Health & Family Welfare

NCC

National Cadet Corps

NGO

nongovernment organization

NPSP

National Polio Surveillance Project

NSS

National Service Scheme

NTAGI

National Technical Advisory Group on Immunization

OPV

oral polio vaccine

OVP

open vial policy

PRI

panchayati raj institution

RCH

reproductive and child health

RI

routine immunization

RMNCH+A

reproductive, maternal, newborn, child health and adolescent health

RVV

rotavirus vaccine

SHG

self-help group

SHS

State Health Society

SIO

state immunization officer

SMO

surveillance medical officer

STFI

state task force for immunization

ToT

training of trainers

TT

tetanus toxoid

UIP

Universal Immunization Programme

UNICEF

United Nations Children’s Fund

VPD

vaccine preventable disease

VVM

vaccine vial monitor

WHO

World Health Organization

2
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 6 -->

BACKGROUND
India’s immunization programme, launched in 1985, is one of the largest health
programmes of its kind in the world, catering to a birth cohort of 2.7 crore (27 million)
children annually. The programme provides vaccination against eight life‐threatening
diseases (diphtheria, whooping cough, Haemophilus influenzae type B (Hib) causing
pneumonia and meningitis, tetanus, polio, tuberculosis, measles and hepatitis B) in the
entire country. In addition, vaccination against Japanese Encephalitis (JE) is provided in the
selected endemic districts/states of the country. Recently, rotavirus vaccine (RVV) has been
introduced in the four selected states (Andhra Pradesh, Haryana, Himachal Pradesh and
Odisha).
In spite of all positive changes, there are ongoing
challenges and shortcomings in the national Mission Indradhanush:
immunization
programme.
Despite
being Identify, enlist, mobilize,
vaccinate and track to
operational for the past more than 30 years, only
achieve full immunization
65% of children in India receive all vaccines during
their first year of life, thus contributing to
continued high burden of morbidity and mortality in children from vaccine preventable
diseases (VPDs).
Based on full immunization estimated from routine immunization monitoring and Mission
Indradhanush data, it is estimated that annually, more than 70 lakh (7 million) children in
the country do not receive all vaccines that are available under the UIP—the highest
number compared with any other country in the world. This is majorly due to sub‐optimal
data recording and reporting, as well as the dire need to improve disease surveillance
system. It is critical to identify the districts where focussed efforts, systematic immunization
drive and additional resources will be required for reaching all children with all available life‐
saving vaccines.
The Ministry of Health and Family Welfare, Government of India (MoHFW‐GoI) is committed
to rapidly address the inequity in immunization coverage and consolidate the health
systems strengthening efforts. To strengthen routine immunization planning and delivery
mechanism, the MoHFW, GoI, launched its flagship programme “Mission Indradhanush” in
December 2014 to achieve more than 90% full immunization coverage in the country. As
part of this, the country has implemented two phases of Mission Indradhanush in 2015
through eight rounds in high focus districts. Based on risk prioritization, the country was
categorized into high, medium and low focus districts. Phase I of Mission Indradhanush
targeted 201 high‐focus districts, with four rounds of activity between April and July 2015.
Phase II targeted 352 districts (73 districts repeated from phase I), with four rounds of
activity conducted between October 2015 and January 2016.

3
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 7 -->

This equity‐based programme builds on polio strategies, tools, techniques and manpower to
focus specific attention on identified high‐risk populations with traditionally low coverage,
such as slum dwellers, nomadic populations and migrant families living in brick kilns and
construction sites. The mission also targets the 400,000 high risk areas identified in the polio
programme as well as other underserved areas with inadequate health services (vacant
health sub‐centres, etc.), migrant populations, recent measles/diphtheria outbreaks or high
dropout rates.
Leveraging special strategies developed by the polio teams to access high risk, hard‐to‐reach
and underserved communities, Mission Indradhanush brought in communities that
previously had only been reached for polio vaccination but with limited access to routine
immunization services. Microplanning for Mission Indradhanush focused on improving
coverage and addressing equity issues in access to immunization.
Riding on the success and learnings from Mission Indradhanush in 2015 wherein more than
37 lakh children were fully immunized and about 37 lakh pregnant women were vaccinated,
the GoI has decided to continue with this initiative. The main objective is to accelerate the
momentum by planning to target 50% of estimated 70 lakh partially vaccinated or
completely unvaccinated (missed) children in the next wave of Mission Indradhanush (Phase
III) in 2016. The plan is to reach out to the 216 high focus districts across 27 states/union
territories for achieving 90% coverage earlier than 2020.

4
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 8 -->

RATIONALE FOR MISSION INDRADHANUSH

Evidence shows that unvaccinated and partially vaccinated children are most susceptible to
childhood diseases and disability, and run a three to six times higher risk of death as
compared with fully immunized children.
There are wide variations in the proportion of unvaccinated and partially vaccinated
children within states and districts. Recent evaluations have indicated that the major
reasons for inability to reach with all vaccines to children in the entire country are lack of
awareness among parents about the benefits of vaccination, fear of adverse events
following immunization (AEFI) and operational reasons such as non‐availability of vaccines
or vaccinators during vaccination sessions.
It is critical to identify the unvaccinated or partially vaccinated children and address
programmatic issues with focussed microplanning, provision of additional financial
resources and systematic immunization drives to reach these children with all available life‐
saving vaccines.
2.1 What is Mission Indradhanush?
The MoHFW, GoI, launched Mission Indradhanush in
December 2014 as a special drive to vaccinate all
unvaccinated and partially vaccinated children under
UIP.

Figure 1. Phase III: High‐focus districts, 2016

The Mission focuses on interventions to improve full
immunization coverage for children in India from 65%
in 2014 to at least 90% earlier than 2020, this will be
done through special catch‐up drives.
Under Mission Indradhanush, the government has
identified 216 high focus districts across the country.
The states of Uttar Pradesh (55 high focus districts)
and Bihar (19 high focus districts) account for 38%
and 10%, respectively, of the total missed children.
The states of Maharashtra, Rajasthan, Gujarat,
Madhya Pradesh and Assam, with a total of 61 high focus districts, account for 30% of the
total missed children.
Figure 1 illustrates 216 high‐focus districts identified by the government). Phase III of
Mission Indradhanush will target 216 high‐focus districts. (A list of 216 high‐focus districts
has been provided in Annexure 1).

5
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 9 -->

OBJECTIVES OF MISSION INDRADHANUSH
The main objective of Mission Indradhanush is to ensure high coverage of children and
pregnant women with all available vaccines throughout the country, with emphasis on the
identified 216 high focus districts during phase III.
3.1 Specific objectives
With the launch of Mission Indradhanush, the government aims at:
 Generating a high demand for immunization services by addressing communication
challenges;
 Enhancing political, administrative and financial commitment through advocacy with
key stakeholders; and
 Ensuring that the unvaccinated and partially vaccinated children are fully immunized
as per the national immunization schedule (Annexure 2).
3.2 Areas under focus for Mission Indradhanush Phase III
Mission Indradhanush will be a nationwide drive, with focus on 216 identified high focus
districts. The key areas to be reached through Mission Indradhanush will be:
 Areas with vacant sub centres – no auxiliary nurse midwife (ANM) posted for more
than 3 months.
 Villages/areas with three or more consecutive missed routine immunization sessions
– ANMs on long leave or other similar reasons.
 High‐risk areas (HRAs) identified by the polio eradication programme that are not
having independent routine immunization
sessions and clubbed with some other
routine immunization sessions. These
include populations living in areas such as:
- urban slums with migration
- nomadic sites
- brick kilns
- construction sites
- other migrant settlements (fishermen villages, riverine areas with shifting
populations)
- underserved and hard‐to‐reach populations (forested and tribal populations,
hilly areas, etc.).
 Areas with low routine immunization coverage identified through measles
outbreaks, cases of diphtheria and neonatal tetanus in the last 2 years.

6
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 10 -->

STRATEGY FOR MISSION INDRADHANUSH PHASE III
Mission Indradhanush will be a nationwide intensified routine immunization drive for
ensuring high coverage throughout the country, and will be conducted in 216 high focus
districts.
A total of four rounds will be conducted under each phase of Mission Indradhanush. Upon
completion of each phase, districts must ensure that these sessions are included in regular
routine immunization plans. Targeted beneficiaries will be pregnant women and children up
to 2 years of age; however, children up to 5 years need to be focussed upon to improve
booster dose coverage and if required school campaigns may be conducted.


The priority for conducting Mission Indradhanush sessions should be areas
with weak routine immunization coverage in the district. This will require
deployment of ANM to areas outside of her own sub‐centre and block.



All ANMs should be engaged for 7 working days over and above the regular
routine immunization days excluding Sundays and holidays for conducting
session during Mission Indradhanush. Sub centres having delivery facilities
need to plan ANM deployment accordingly.

4.1 Implementation of Mission Indradhanush
 Mission Indradhanush is a special immunization drive spread over 7 days. These 7 days

do not include the routine immunization days planned in that week. Such routine
immunization sessions should be held as already planned.


All identified areas that require routine immunization strengthening but have
no/infrequent routine immunization sessions must be reached through Mission
Indradhanush sessions.



Planning should be made in such a way that all ANMs in district are involved for 7
working days (in addition to routine immunization days) to visit and cover the areas for
maximum immunization coverage.
 Mission Indradhanush is a drive spread over 7 days.
 These 7 days do not include the routine immunization days planned in that week
 Ensure there is a 7 day plan (in addition to routine immunization days) for all ANMs in
district.



The ANMs should be deployed to other sub‐centre area within the same or adjoining
blocks or urban areas in the same district. The planning for Mission Indradhanush
sessions in district should be done in the following ways:
o ANMs working in rural areas with less than 7 days of involvement in Mission
Indradhanush in their own sub‐centre areas should be deployed to low

7
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 11 -->

performing/coverage areas or vacant sub centers in identified urban areas for
Mission Indradhanush.
o To cover the unreached/vulnerable population groups with limited human resources
availability in urban areas, the DIO and
urban nodal officer should coordinate with Every district should identify urban
block medical officers to pull out the nodal officer(s) for planning and
implementation of activities during
required number of ANMs from adjoining
Mission Indradhanush and routine
blocks to conduct the desired number of immunization.
Mission Indradhanush sessions in these State and district task force to ensure
urban areas.
compliance.


Head count survey is a mandatory activity to
be conducted through house to house visits before the first round of Mission
Indradhanush. This head count survey will be conducted by ASHA/AWW/mobilizer for
estimation of beneficiaries in the catchment area for each of the planned sessions for
Mission Indradhanush.
 Mission Indradhanush sessions should only be held after conducting and
enlisting of beneficiaries through head count survey in the catchment area.
 Enlisting of beneficiaries through head count survey will ensure completeness of
due lists and tracking of beneficiaries.



The head count survey will be utilized for preparation of name‐based due lists for
tracking and mobilization of beneficiaries (Targeted beneficiaries will be pregnant
women and children up to 2 years of age; however, children up to 5 years need to be
focussed upon to improve booster dose coverage).



Due lists for subsequent Mission Indradhanush rounds will be updated using name‐
based immunization coverage recorded in Mission Indradhanush tally sheets during
each round.



Mission Indradhanush will be implemented according to a roster prepared following the
planning process. This includes planning meetings at district and block levels, and
oversight provided by district task force for immunization (DTFI).

8
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 12 -->

COMPONENTS OF MISSION INDRADHANUSH
The two main components of Mission Indradhanush will be:
 Operational planning
 Communication planning
5.1 Operational planning
The following two operational mechanisms will be utilized to reach out to unreached or
poorly reached beneficiaries.
5.1.1 Fixed and outreach sessions
Medical officer in‐charge (MOIC) for the block/urban planning unit will conduct a detailed
planning for the additional sessions to be conducted in the planning unit. In addition,
provision for vaccination should be made at health posts, primary health centres (PHCs) and
district hospitals on all days of Mission Indradhanush.


Sites for vaccination: Primary schools, anganwadi centres, private dispensaries,
nongovernment organization (NGO) sites or any other locations that are easily
accessible and acceptable to the community can be used as immunization sites. In
addition, urban health posts, post‐partum centres, family welfare centres and local
influencers’ premises may be utilized in urban areas.



Availability of human resources: All ANMs in district will conduct Mission
Indradhanush session for 7 working days in addition to routine immunization days.
Other health staff trained for administering injection available from the same or
neighbouring community health centre (CHC)/block/PHC/NGOs (LIONS, Rotary, etc.),
retired health workers and staff available from other government agencies such as
Medical colleges, ANM/nurse training school, Employee’s State Insurance
Corporation, Central Government Health Scheme, Armed Forces, Railways, District
Urban Development Agency (DUDA)/State Urban Development Agency (SUDA) and
community based organizations (CBOs) should be utilized to reach the largest
number of children.

Please note: Under Part C of Programme Implementation Plans (PIP) of NHM, as per
norms there is a provision to hire vaccinators for urban slum/marginalized areas.


Timings: The activity will be conducted from 09:00 to 16:00. However, sessions
should be planned based on availability of the targeted population to maximize the
benefits.



Team: A team will comprise one vaccinator and two mobilizers, payments to both
mobilizers should be made as per financial guidelines (Annexure 7). An additional
vaccinator will be included in the team if the estimated injection load is more than
60–70.

9
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 13 -->

5.1.2 Mobile sessions
Mobile sessions should be planned at places where routine immunization coverage is weak
and the small number of beneficiaries does not warrant an independent session. These
places include peri‐urban areas, scattered slums, brick kilns and construction sites. For these
sessions, alternate means such as mobile vans should be planned in the format given at
Annexure 11. It is important to ensure that the vials of Bacillus Calmette‐Guerin (BCG),
Measles, Rotavirus vaccine, and Japanese Encephalitis (JE) vaccines that are opened at one
site are not used at the next site. The Integrated Child Development Services (ICDS)
department & Rashtriya Bal Swasthya Karyakaram (RBSK) school health teams may support
these mobile sessions through supplementary nutrition services that may be provided to
beneficiaries in these hard‐to‐reach areas.


Include all immunization sessions held under Mission Indradhanush (that are
not part of routine immunization microplan) into routine immunization
microplans.



The budgetary support for the same should be reflected in the district health
action plan (DHAP) and subsequently in the state PIP.

5.1.3 Planning considerations
Based on evidence and best practices from the polio eradication programme, the following
activities will be critical for the planning and successful implementation of Mission
Indradhanush:
 Meticulous planning of immunization sessions at all levels: It is important to plan
sessions for identified areas where the reach of immunization programmes is
inadequate. Ensure availability of sufficient vaccinators and all vaccines during
routine immunization sessions.
 Effective communication and social mobilization efforts: Generate awareness and
demand for immunization services through need‐based communication and social
mobilization activities (mass media, mid media, interpersonal communication, school
and youth networks and corporates).
 Intensive training of health officials and frontline workers: Build capacity of health
officials and workers for routine immunization activities to ensure the highest quality
of immunization services delivery to beneficiaries.
 Establish accountability framework through task forces: Enhance involvement and
accountability/ownership of state and district administrative and health officials
through state and district task forces for immunization. It is important to use
concurrent session monitoring data to plug gaps in implementation.
5.2 Communication planning
 To meet and sustain coverage goals under Mission Indradhanush, a well‐carved
strategic communication plan needs to be in place, reaching out to communities
10
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 14 -->

residing in rural as well as urban areas, hard‐to‐reach populations and building trust
in health‐care services. This calls for identifying communication methods or channels
that are the most appropriate for targeted stakeholders, that are liked and used by
them and can most effectively reach them with programme messages. The
communication plan also needs to take into consideration specific communication
activities at different levels of operation.


A need‐based communication and social mobilization activities should be planned to
achieve the following objectives:
- Demand generation through increased visibility
- Advocacy through media, professional bodies and political leadership
- Capacity building of immunization workforce on communication
- Social mobilization through interpersonal communication, school and youth
networks and corporates
- Concurrent monitoring of communication interventions.

5.2.1 National communication plan
Communication activities initiated at the national level will focus on mass media channels,
their frequency and periodicity, news media outreach and social media activities. The
communication activities will include:
 Launch of Mission Indradhanush Phase III
 National media outreach and management
 Airing of TV and Radio spots on national and regional channels
 Airing of Radio jingles on FM and AIR
 Newspaper advertisements (in leading English and Hindi dailies)
 SMS campaigns
 Social media engagement through Twitter, Facebook and YouTube
 Consolidated progress report on monitoring of communication interventions
5.2.2 State communication plan
Communication plan at the state level will include the following key components. Each
component will have specific communication activities to reach out to a range of
stakeholders with information and messages on various programme components.
 Demand generation
 Capacity building
 Coordination and convergence
 Advocacy and social mobilization
 Media engagement
 Communication monitoring

11
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 15 -->

The communication plan will be rolled out through the following activities:
 Development of state communication action plan using the 360 degree
communication approach where mass media, mid media and interpersonal
communication (IPC) channels would be used.


Capacity building
- Training of state/district officials on operationalization of communication
plan
- Capacity‐building of media spokespersons


Advocacy with
- Other Line departments ( Panchayat department , Rural Development
department , WCD department , Education, WASH)
- Development partners
- CBO and NGOs ( MNGOs)
- Religious institutions (Wakf board, Ramakrishna Mission, BSS, Diocesan
Social Service Societies (DSSS), Jamai‐te‐ulema‐e‐Hind, State Haj
Committees)
- Local political leaders (member of parliament [MPs], member of
legislative assembly [MLAs])
- Professional bodies such as Indian Medical Association (IMA) and Indian
Academy of Paediatrics (IAP)



Mass media
- Airing of TV and radio spots on regional channels
- Radio jingles on local FM
- Newspaper advertisements in state‐level newspapers (English and Hindi)
- SMS campaign



Media engagement through
- Media orientation
- Press briefings
- Media tracking and analysis



Supportive supervision visits to poor performing districts by state officials

5.2.3. District communication plan
The plan details out suggested communication activities and also ways to reach out to
specific populations and groups in high priority or geographically hard‐to‐reach areas. A few
activities have been suggested for hilly/flood prone/desert/jungle/unrest areas/resistant or
underserved pockets/urban slums/tribal areas and mobile/migrant populations. It is left to
the discretion of the states to decide the kind of activities they find appropriate.
At the district level, dedicated communication plans will be made for the following areas:
 High‐priority areas
 Resistant and underserved pockets
 Urban slums
 Tribal areas
12
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 16 -->



Migrant/mobile populations

This plan describes activities to be undertaken at the district level for components similar to
the state plan. Communication activities at the district level will include the following:

Development of district communication action plan using the 360 degree
communication approach where mass media, mid media and interpersonal
communication (IPC) channels would be used.


Capacity building
- Training of district health officials, line departments, e.g., education, PRI
WASH and NGO partners on social mobilization and advocacy
- Training of ANMs, ANM supervisors, LHVs, BEEs and community
mobilizers , ASHA supervisors on IPC skills
- Capacity‐building of media spokespersons for crisis management in case
of AEFIs



Advocacy and Social Mobilization
- Meetings with key influencers for social mobilization
 Religious leaders
 Ward members/councillors
 Panchayati raj institutions (PRI)
 Teachers
 Local doctors, IAP/IMA members
 Civil society organizations (CSOs), National Cadet Corps (NCC) and
National Service Scheme (NSS)
 Local political leaders (MPs, MLAs)
 Institutionalize a reward and recognition system for well
performing ANMs/ASHAs.



District‐level media management, including media orientation and press briefings
(give out updates before and after each round), organize field visits to the media;
take them to the areas where Mission Indradhanush is being organized).



Mass media
- Airing of TV spots on local channels and cable TV
- Radio jingles on local FM channels
- Newspaper advertisements in local regional dailies in local language
- SMS campaign
- Printing of IEC materials



Develop implementation plan for IEC materials e.g. posters, pamphlets, flipbooks,
hoardings, banners, flex boards and balloons.



Monthly district‐level planning and review meetings under chairmanship of DM/
DC with ICDS, PRI and allied departments for intersectoral convergence for
coordination in implementation.



Monthly and quarterly meetings of inter‐agency communications group.



Monitoring of communication activities.
13
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 17 -->

The prototypes for all the communication activities under mass and mid media will be
developed at the national level. The open files of the prototypes will be shared with the
states and the states will further share the prototypes with the districts for translation,
printing and dissemination. The states may also adapt the prototypes according to their
local context.
The calculation for the printing of the IEC (information, education and communication)
materials is based on approximation and the actual figures will depend on the size and the
rate at which the activity will be undertaken at the district level. For example, in a district
with around 2000 Accredited Social Health Activists (ASHAs), 10 000 posters may be printed
@5 posters per ASHA area. This is just an approximation and actual numbers may vary
depending upon the number of ASHAs per district and the rate which is charged for the
printing of the poster.
5.2.4 Block communication plan
This plan describes some indicative communication activities under the different
components on a similar pattern as for the state and district level plans. Under demand
generation, suggested strategic locations for display and dissemination of mid media
materials have also been given for enhanced visibility of messages. The plan also includes
proposed activities for interpersonal communication and community mobilization along
with capacity‐building, coordination, and advocacy and social mobilization initiatives.
Communication activities at the block level will include the following

Capacity building
- IPC skills training of frontline functionaries (ANMs, ASHAs and AWWs)
- Orientation of nodal school teachers on routine immunization
- Orientation of NGO volunteers on routine immunization


Advocacy engagements with religious leaders, PRI members, SHG members and
key influencers such as teachers, local doctors, CSOs, NCC and NSS



Social mobilization
- Community meetings
- Temple/mosque announcements
- Rallies
- Miking
- Nukkad natak/street plays
- Stalls on routine immunization in local gathering (haat, mela, sammelan,
urs)
- Organize health camps in hard‐to‐reach/underserved areas/resistant
pockets
- Social mobilization campaigns through community networks such as
CBOs, community influencers, religious leaders, NGOs, youth volunteers,
SHGs and cooperatives


Monthly meetings (or as is considered necessary) with ICDS, PRI and allied
departments for intersectoral convergence.
14
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 18 -->

5.2.5 Community‐level communication plan
A communication plan should be developed for the sessions planned under Mission
Indradhanush. The following activities may be undertaken to enhance community
awareness for Mission Indradhanush and acceptance for routine immunization:
 Local miking on slow moving vehicles
 Drum beating/munadi
 Announcements from locally situated religious places
 Community radio spots
 Mothers’ meetings
 Self‐help group meeting
 Youth clubs
 Community meetings (with pradhans, ward members, village level influencers)
 Schools, club rallies
 Display of banners and posters
 Home visits by local mobilizers (ASHAs/AWWs) for IPC
5.2.6 Role of the local influencer(s)
Doctors, village pradhans or urban ward members,
On the day of immunization,
panchayat secretary, ration dealers, religious leaders and
mobilisers should be invited to
teachers play an important role in facilitating vaccine inaugurate the session. After
acceptance in community. These influencers play a key role session inauguration, influencers
in creating vaccine awareness and clearing doubts and mobilisers must visit houses of
regarding vaccination, thereby enhancing vaccination beneficiaries as per due list and
coverage. ANM with support from ASHA, AWW and other ensure vaccination of all eligible
mobilisers will identify local influencers for each session beneficiaries in the area.
site. These influencers should be available to help
mobilisers on the day of vaccination and committed to support the team. They may also
support mobilisers in organizing rallies, bulawwa tolis as well as announcement from
mosques and other places.
Names of all identified influencers should be incorporated in micro‐plans. Interface meeting
of mobilisers, vaccinators and influencers should be organized at least one week prior to
immunization day for sensitizing influencers on Mission Indradhanush, importance of their
engagement and sharing beneficiary due list. Responsibility of beneficiary mobilization
should be rationally divided among influencers so that they have manageable workload of
influencing parents of beneficiaries for vaccination.

15
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 19 -->

STEPS FOR ROLL‐OUT OF MISSION INDRADHANUSH
The roll‐out of Mission Indradhanush requires meticulous planning at all levels. Special
sessions under Mission Indradhanush should be conducted in areas that are unreached or
poorly reached for routine immunization services to ensure maximum improvement in full
immunization coverage of states. Prior to conducting these sessions, headcount must be
done in such areas for enlisting beneficiaries and preparing due lists. The steps for rolling
out Mission Indradhanush have been illustrated in Figure 2.
Figure 2. Steps for roll‐out of Mission Indradhanush

16
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 20 -->

STATE LEVEL ACTIVITIES FOR MISSION INDRADHANUSH
The following activities should be undertaken at the state level for the successful
implementation of Mission Indradhanush:
7.1 Meeting of State Task Force for Immunization (STFI)
The task forces for immunization at state and district levels were constituted on the polio
model to critically review the current status of routine immunization, identify programmatic
gaps, decide strategic actions to improve the coverage of UIP and monitor the
implementation of these actions.
This institutional mechanism plays a pivotal role in improving and delivering high quality
immunization coverage across all states. Task forces meet periodically to review routine
immunization programme performance through a detailed review of administrative and
monitoring data, microplanning, training status of frontline workers, and vaccine and cold
chain management, with a special focus on high priority areas. They also identify
operational constraints and ensure corrective operational steps to improve routine
immunization coverage.
Chairperson: Principal Secretary, Health
Co‐chair: Mission Director, National Health Mission (MD NHM)
Member Secretary: State Immunization Officer (SIO)
Responsibility: Director, Family Welfare; SIO
Timeline: First meeting within 2 days after receiving official
communication from the national level. Conduct meetings
following completion of each round to review coverage
data, monitoring feedback and any other issues, and to
plan for the next round.
Frequency: At least one meeting before each Mission
Indradhanush round
Review mechanism: MoHFW will review the activity.
Activities to be conducted:
 Provide technical guidance, including funding and
operational guidelines, and fix timelines for districts
to plan and implement immunization weeks.




Communicate with district magistrates for
conducting meetings of DTFI and district workshop
for Mission Indradhanush after the state workshop.

Critical activity: Mission
Indradhanush preparedness /
progress review
A video conference by Principal
Secretary/Mission Director with
Mission Indradhanush districts
(DM/CMO/DIO/ Urban Nodal
officer/ weak performing Block MO
in charges and partners) will help in
better understanding the progress
in terms of planning and
implementation.
STFI to closely monitor quality of
DTFIs
Frequency: at least once before each
round

Involve other relevant departments including ICDS, PRI and key immunization
17
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 21 -->

partners such as World Health Organization (WHO) India, National Polio Surveillance
Project (NPSP), United Nations International Children’s Fund (UNICEF), Rotary
International, Reproductive, Maternal, Newborn, Child Health and Adolescent Health
(RMNCH+A) lead partners and other organizations at state and district levels. CSOs,
including professional bodies such as IMA and IAP, should also be involved.


Ensure identification of the nodal officer for urban areas in each district. He/she will
facilitate microplanning in urban areas of the district.



Ensure adequate number of IEC materials (as per prototypes) and updated planning
and reporting formats are printed and disseminated to districts in time. Ensure that
these materials are printed in local languages if required.



Deploy senior state‐level health officials to high‐focus districts for monitoring and
ensuring accountability framework. They should visit these districts and provide
oversight to activities for roll‐out of Mission Indradhanush, including participation in
DTFI meetings and assessment of district preparedness.



Track districts for adherence to timelines, including microplanning, indenting of
vaccines and logistics, and roll out of Mission Indradhanush. All districts should
conduct these drives on a common date.



Fix date and time and conduct video conferences with districts and urban local
bodies to review and resolve issues related to microplanning, vaccines and logistics,
human resources availability, training, waste management, AEFI and IEC/BCC.
District participants will include district magistrate, chief medical officer (CMO),
district immunization officer (DIO) and nodal officer for the urban area.



Review each round of Mission Indradhanush and guide corrective actions.



Ensure inclusion of Mission Indradhanush sessions in regular routine immunization
plans.



Minutes and actions taken report of each meeting should be circulated to officials
concerned and communicated to MoHFW, GoI.

7.2 State workshops and review
The objective of state workshops is to build capacity of district officials in cascading trainings
at district and block levels. The trainee officials will be oriented on conducting planning
exercises that emphasize on head count survey and preparation of due list of beneficiaries.
These workshops also aim at strengthening social mobilization among communities, and
ensuring accountability and effectiveness of government programmes.
Responsibility: State Immunization Officer
Technical support: Key development partners such as WHO India NPSP, UNICEF and others
Financial support: Through NHM
18
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 22 -->

Timeline: Within 3‐5 days after receiving official communication from the national level.
Participants: DIO and one MO from each district
Review mechanism: MoHFW will review the activity.
Activities to be conducted:
 Train district‐level trainers on use of updated planning formats for Mission
Indradhanush, reporting and recording tools such as revised immunization
component in mother‐child protection (MCP) card, registers, due lists and tally
sheets, immunization tracking bag (one per session site to be used by ASHA/AWW).
 State health authorities and partners should intensively monitor training for quality
and attendance and share findings with STFI.
 Post district‐wise progress of training status on the website of the state health
department.
 Details of trainings to be conducted at state level are given in Table 1.
Table 1. State‐level workshops and review

S.No.

Trainees/ Participants

Trainers/ facilitators

Duration

Timeline

1

MOs: DIO and one MO from each district
(two persons per district). Also include SMOs
of WHO India NPSP, UNICEF district
coordinators and others such as state
programme manager (NHM), state IEC
consultant, state ASHA coordinator, state
cold chain officer, state data manager, state
M&E coordinator (NHM), state finance &
accounts manager (NHM)

SIO with support from state
cold chain officer, HMIS and
MCTS coordinators, IEC
consultant and partners such
as WHO India NPSP, UNICEF
and others

One‐day
workshop

Within 3‐5
days after
official
notificatio
n from
MoHFW

SIO with support from
UNICEF, Rotary, WHO India
NPSP and other partners,
state IEC consultant and
media officer. Principal
Secretary to chair and MD
NHM to co‐chair the meeting.

Half‐day
workshop

At least 1
week prior
to the
launch

SIO with support from
UNICEF, Rotary, WHO India
NPSP and other partners.
Principal Secretary to chair
and MD NHM to co‐chair the
meeting.

Half‐day
workshop

Between
the rounds

2

Financial support: NHM
Mission Indradhanush media sensitization
meeting: Workshop for sensitization of
media (print/electronic).
Financial support: NHM

3

Mission Indradhanush review workshops:
Review of districts to be done in between
the rounds of Mission Indradhanush by
meetings/ video conferencing.
Financial support: NHM

ASHA: accredited social health activist; DIO: district immunization officer; HMIS: health management information system; IEC:
information, education and communication; MCTS: mother and child tracking system; MD NHM: Mission Director, National
Health Mission; MO: medical officer; SIO: state immunization officer; SMO: surveillance medical officer

19
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 23 -->

DISTRICT LEVEL ACTIVITIES FOR MISSION INDRADHANUSH
The following activities should be undertaken at the district level for the successful roll‐out
of Mission Indradhanush.
8.1 Meeting of District Task Force for Immunization (DTFI)
The District Task Force for Immunization had been constituted to enhance involvement and
accountability/ownership of the district administrative and health machinery in the routine
immunization programme, ensure inter‐sectoral coordination, review the quality of routine
immunization microplans, tracking and mobilization efforts, plan for vacant sub‐centres,
training status and vaccine logistics, with a special focus on high‐risk areas.
Chairperson: District Magistrate
Member Secretary: DIO
Responsibility: DIO
Timeline: Within 3‐5 days of state workshop/ communication from the state level.
Frequency: At least one DTFI meeting should be organized prior to each round of Mission
Indradhanush, and more frequently if required, to review progress in planning and
implementation.
Review mechanism: STFI
Activities to be conducted:
 Provide technical guidance, including funding and
operational guidelines, and fix timelines for blocks to
plan and implement immunization weeks.

Critical activity: Mission
Indradhanush preparedness /
progress review



Involve other relevant departments including ICDS,
PRI and key immunization partners such as WHO India
NPSP, UNICEF, Rotary International, RMNCH+A lead
partners and other organizations at state and district
levels. CSOs, including professional bodies such as
IMA and IAP, should be involved.

A DTFI meeting chaired by DM with
CMO/DIO/ All Block MOIC especially
weak performing Block MOICs,
partners, others will help in
reviewing and providing directions
for better planning and
implementation.



Ensure identification of nodal officer for urban areas
in the district. He/she will facilitate microplanning in
urban areas of the district.



DTFI to ensure identification of
urban nodal officer(s) for planning
and implementation of Mission
Indradhanush and routine
immunization activities.

Ensure adequate number of printed IEC materials (as
per prototypes) and updated reporting and recording
tools (MCP cards, registers, due lists, tally sheets) are printed and disseminated to
blocks/planning units in time. Ensure that these materials are discussed and used in
the sensitization workshops.
20
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 24 -->



Deploy senior district‐level health officials to priority blocks for monitoring and
ensuring accountability framework. They should visit these blocks and provide
oversight to activities for roll‐out of Mission Indradhanush, including participation in
training, monitoring of activity and participation in evening review meetings.



Ensure availability of required doses of all UIP vaccines and other logistics. This will
require a headcount for estimation of beneficiaries in all areas where Mission
Indradhanush sessions are planned.



Track blocks and urban areas for adherence to timelines, including microplanning,
indenting of vaccines and logistics and launch of each round of Mission
Indradhanush.



Communicate to Principal Secretary (Health) in case dates of Mission Indradhanush
rounds need to be changed due to exceptional circumstances.



Review microplans to ensure engagement of all ANMs for 7 working days in addition
to routine immunization days.



Vaccines and logistics, human resources availability, mobility of vaccinators when
conducting session outside sub‐centre area, training, waste management, AEFI and
IEC/BCC.



Review each round and guide corrective actions.



Ensure inclusion of Mission Indradhanush sessions in regular routine immunization
plans



Conduct daily evening feedback meetings during the round at the district for sharing
feedback and initiating corrective actions.



Minutes and action taken report of each meeting should be circulated to officials
concerned and communicated to MoHFW, GoI.

8.2 District workshops
The objectives of district workshops are to train block‐level officers on the strategy of micro‐
planning for Mission Indradhanush, conducting head count survey and preparing due lists.
These medical officers will also be oriented in the field of organizing training for frontline
workers on the immunization aspects for Mission Indradhanush.
Responsibility: DIO. He will prepare a training calendar for each type of district‐level training
as given in Table 2 and communicate the same to DTFI.
Technical support: Key development partners such as WHO India NPSP, UNICEF and others
Financial support: WHO India NPSP will support district workshops for MOs in all 216 high
focus districts. One‐hour training of NHM officials, half‐day trainings of data handlers and
cold chain handlers and media workshop will be financially supported through NHM funds.
21
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 25 -->

Timeline: Before Mission Indradhanush
Participants: Two MOs from each block and urban planning unit
Review mechanism: DTFI and STFI
Activities to be conducted:
 Train block‐level trainers on use of updated planning formats for Mission
Indradhanush, reporting and recording tools such as revised immunization
component in mother‐child protection (MCP) card, registers, due lists and tally
sheets, immunization tracking bag (one per session site to be used by ASHA/AWW).


This pool of trainers will conduct sub‐district level training of the health workforce
including health workers and supervisors (ANMs, lady health visitors [LHVs] and
health supervisors) and community mobilizers (ASHAs, AWWs and link workers).



Sensitize key district‐level NHM officials on Mission Indradhanush.



Submit progress on training status of each level of functionary to the state
immunization officer before the first round of Mission Indradhanush. Repeat
trainings in weak performing areas, with focus on weak performing
vaccinators/mobilizers.



Details of training to be conducted at the district level are given in Table 2.

Table 2. District‐level workshops
S.No. Trainees
1
MOs: Two MOs per block/urban planning
unit. Nominations to be forwarded to DIO.
Others include district programme
manager (NHM), district IEC consultant,
district ASHA coordinator, district cold
chain handler, district data manager,
district M&E coordinator (NHM), district
accounts manager (NHM)

2

Technical and financial support for
workshop: WHO
Programme/Accounts managers (NHM):
District and block programme and
accounts managers and other officials
handling NHM funds
Financial support: NHM

3

Data handlers: One data handler involved
in immunization data entry (HMIS and
MCTS data) per district/block/planning
unit
Financial support: NHM

Trainer
DIO and another MO trained
at state level and partners
(WHO India NPSP, UNICEF and
others)

Duration
One‐day
workshop

Timeline
Within 1
week
after
completi
on of
STFI
meeting

DIO and trained MO, with
support from district
programme manager, district
accounts manager, district
M&E coordinator and partners
(WHO India NPSP, UNICEF and
others)
DIO and other MO trained at
state level. District M&E
Coordinator (NHM) and
partners (WHO India NPSP,
UNICEF and others)

1 hour

After
completi
on of
district
MO
worksho
p
Within 1
week
after
completi
on of
district

Half‐day
workshop

22
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 26 -->

4

5

Vaccine and cold chain handlers:
Block/planning unit to identify and
nominate at least two persons per vaccine
storage point. Nominations to be
forwarded to DIO.
Financial support: NHM
Mission Indradhanush media workshop:
Workshop for sensitization of media
(print/electronic). DIO, with support of
partners, to prepare the agenda and list of
invitees.
Financial support: NHM

DIO and trained MO with
district cold chain handler and
partners (WHO India NPSP,
UNICEF and others)

Half‐day
workshop

worksho
p

DIO with support from
UNICEF, Rotary, WHO India
NPSP and other partners,
district IEC consultant, media
officer. District Magistrate to
chair the meeting.

Half‐day
workshop

At least 1
week
before
launch

ASHA: accredited social health activist; DIO: district immunization officer; HMIS: health management information system;
IEC: information, education and communication; MCTS: mother and child tracking system; NHM: National Health Mission

Note: Refer to Annexures 4a, 4b, 4c and 4d for agenda and tips for trainers at Serials 1, 2, 3 and 4, respectively.

23
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 27 -->

BLOCK LEVEL ACTIVITIES FOR MISSION INDRADHANUSH
The following activities should be undertaken at the block level for roll‐out of Mission
Indradhanush.
9.1 Training of frontline workers
As part of the intensification of routine immunization in India, training of frontline workers
has been further stepped up with the objective of enhancing the operational and
interpersonal skills of these workers. The goal of this training is to improve the coverage and
quality of routine immunization services by reaching children that have missed their due
vaccine doses.
Responsibility: Block MO IC
Technical support: Training will be conducted by two MOs trained at district level with
support from key development partners such as WHO India NPSP, UNICEF and others.
Financial support: These training sessions will be supported through NHM funds as per
guidelines.
Timeline: To be completed within 2–3 days of district workshop
Participants: Health workers (ANMs, LHVs, health supervisors) and social mobilizers (ASHAs,
AWWs and link workers)
Review mechanism: DTFI
Activities to be conducted:
 Training of ANMs/LHVs/health supervisors
‐ In sub‐centres with two ANMs, a clear division of area between the two
ANMs must be done to ensure maximum output and accountability. Sub‐
centre with delivery facilities may plan accordingly.
‐ Updated reporting and recording tools, including Mission Indradhanush
microplanning and reporting forms, revised counterfoil of MCP card, tracking
bag, due lists, tally sheets and registers will be shared during the training
workshops.
‐ One‐page info kit on Mission Indradhanush planning and operationalization
will be provided to ANMs during the training.
‐ Printed IEC materials, including street and session site banners and posters,
will be provided to ANMs for display at session sites.
‐ Preparation of microplans by each ANM for conducting Mission Indradhanush
sessions within own block.

24
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 28 -->

 Training of mobilizers (ASHAs, AWWs and link workers)
‐

‐
‐

‐

‐

Block ASHA coordinator and child development project officer will support
MOs and representatives from partner agencies in conducting these training
sessions.
Mobilizers will be trained on headcount for estimation of beneficiaries.
Mobilizers will be expected to conduct this survey in their assigned area, and
if required, outside their area as well. Financial support will be provided for
conducting this exercise as per norms (Annexure 7).
Financial support will also be disbursed by MO IC of the block for mobilization
of beneficiaries to session sites by mobilizers (ASHAs/AWWs/link workers) as
per attached norms (Annexure 7).
Details of trainings to be conducted at the block level are given in Table 3.

Table 3. Block‐level training workshops/ToTs
S.No. Trainees
Trainers
1
Health workers
District and block master trainers
(ANMs, LHVs, health (DIO and two block‐level MOs trained at
supervisors)
district level)

2

Financial support:
NHM
Mobilizers (ASHAs
and AWWs)

Financial support:
NHM

Training to be conducted in small batches
of 30–40 trainees
District and block master trainers
(DIO and two block‐level MOs trained at
district level, supported by ASHA
coordinators and others)
Training to be conducted in small batches
of 30–40 trainees

Duration
One day for
each
workshop

Half‐day for
each
workshop

Timeline

Within 2 weeks
of completion of
district‐level
workshop

ANM: auxiliary nurse midwife; ASHA: accredited social health activist; AWW: anganwadi worker; DIO: district immunization
officer; LHV: lady health visitor; MO: medical officer

Notes: 1. Refer to Annexures 5 and 6 for agenda and tips for trainers for Serials 1 and 2, respectively.
2. Submit progress report on training status of each level of functionary to DIO.

25
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 29 -->

FREQUENTLY ASKED QUESTIONS FOR MISSION INDRADHANUSH
Q1. What is Mission Indradhanush?
Mission Indradhanush is a flagship programme of the Ministry of Health & Family Welfare. It
aims at improving the full immunization coverage in the country from the current 65% to
more than 90% through special immunization drives, with special attention to 216 identified
high‐focus districts.
Q2. When will Mission Indradhanush drives be conducted during phase III?
Special routine immunization drives under Mission Indradhanush will be conducted across
the country in all districts. Each drive will be conducted for up to 7 days, with a gap of at
least 4 weeks between the two drives. During phase III, four special drives will be conducted
between April and July 2016, with focus on 216 high‐focus districts.
Q3. What areas will be prioritized for coverage in the identified high/medium focus
districts under Mission Indradhanush?
The Mission will focus on the following key areas:
1. Areas with vacant sub‐centres: No ANM posted for more than 3 months.
2. Villages/areas with three or more consecutive missed routine immunization
sessions: ANMs on long leave or other similar reasons
3. High‐risk areas identified by the polio eradication programme that are not having
independent routine immunization sessions and clubbed with some other routine
immunization sessions.
4. These include populations living in areas such as:
 urban slums with migration
 nomadic sites
 brick kilns
 construction sites
 other migrant settlements (fisherman villages, riverine areas with shifting
populations, etc.)
 underserved and hard‐to‐reach populations (forested and tribal populations,
etc.).
5. Areas with low routine immunization coverage (pockets with recent measles or
other VPD outbreaks)
6. Small villages, hamlets, dhanis or purbas clubbed with another village for routine
immunization sessions and not having independent routine immunization sessions.
Q4. Why has my district been included for Phase III of Mission Indradhanush?
A total of 201 high‐focus districts were identified for Phase I of Mission Indradhanush based
on extensive analysis. Subsequently, phase II was conducted in 352 districts (73 districts
repeated from phase I) of the country. High focus (phase I) districts where independent
monitoring indicated that more than 90% children had received all due vaccines have been
excluded, while Phase II districts where less than 60% of the children had received all due
26
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 30 -->

vaccines have been included for Phase III. The 216 high‐focus districts were identified based
on monitoring indicators and feedback from states.
Similar method will be followed for district selection in subsequent phases of the Mission
Indradhanush.
Q5. How will the number of beneficiaries for these drives be estimated?
The beneficiaries for Mission Indradhanush will be estimated based on a head count survey
that will be conducted by ASHA/AWW/link worker in all areas identified to be covered
under Mission Indradhanush. An incentive of Rs 100 is available under NHM for this activity.
For details, see financial guidelines (Annexure 7).
Q6. Will this head count be conducted in the entire district before phase III of Mission
Indradhanush?
No, the head count for estimation of beneficiaries will be conducted only in areas where
Mission Indradhanush sessions will be planned. An incentive of Rs 100 will be given to
ASHA/AWW/link worker for this exercise, once before the first round and once for revision
after the second round.
Q7. All small hamlets, brick kilns, construction sites, nomadic sites, slums etc. in my sub‐
centre area are tagged to the existing session sites. What is the need to conduct additional
sessions in such areas?
Despite tagging of HRAs, it is often observed that beneficiaries do not reach the session
sites. Planning additional sessions close to residences of targeted beneficiaries in HRAs and
other identified areas during Mission Indradhanush rounds provide another opportunity to
immunize children, especially the left outs and drop outs.
Q8. In Mission Indradhanush, is ANM eligible to claim any TA/DA for working outside her
place of posting?
Yes, ANM working outside her place of posting during Mission Indradhanush is eligible to
claim TA/DA as per the state TA/DA rules.
Q9. How will sites like brick kilns or construction sites be covered during these drives?
Sites with a small number of beneficiaries that do not require independent sessions can be
covered by mobile vaccination teams. More than one site may be covered by a mobile team.
However, it must be ensured that vials of BCG, Measles, Rotavirus vaccine (RVV) and JE
opened at one site are discarded and not used at the next site.
Q10. Will any special training be provided for this drive?
Yes, all health workers will be trained on the planning and implementation of Mission
Indradhanush. ASHAs/AWWs/link workers will be trained on conducting the head count
survey for estimation of beneficiaries and communicating with families of beneficiaries.
District/Block level trainers who participated in district Mission Indradhanush workshops
will be responsible for training all frontline workers and mobilizers involved in
implementation of Mission Indradhanush.
27
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 31 -->

In addition, training should be provided to data handlers, cold chain handlers and
supervisors.
Q11. How will immunization sessions be planned during 7 days of the Mission
Indradhanush round?
All ANMs should be involved in conducting sessions for Mission Indradhanush. They should
dedicate 7 working days to Mission Indradhanush sessions, in addition to routine
immunization days. The routine immunization sessions planned in between the 7 days of
Mission Indradhanush should not be disturbed and should be held as planned.
For Mission Indradhanush round, ANM may be deployed within or outside her block in her
district of posting for conducting Mission Indradhanush sessions. This mechanism will tackle
the existing human resource issues within the district.
Q12. What will be the timings of sessions?
The session sites will be operational from 09:00 to 16:00. However, flexibility based on the
availability of beneficiaries or other local conditions is permitted.
Q13. Will all UIP vaccines be provided in Mission Indradhanush rounds?
Yes, all vaccines that are being provided under UIP in the state/district as per the national
immunization schedule will be made available under Mission Indradhanush.
Table 4. National Immunization Schedule

Age

Immunization Schedule

Remarks

(1) BCG vaccine can be given up to 1 year of age.
(2) DPT vaccine can be given up to 5‐6 years (not beyond 7
OPV1/Pentavalent1/RVV1 (in selected
years) of age.
6 weeks
states)
(3) Pentavalent vaccine should be given under 1 year of
OPV2/Pentavalent2/RVV2 (in selected
age. In delayed cases , due doses above 1 year of age can
10 weeks
be given to a child only if a child has received at least one
states)
dose of pentavalent vaccine before his/her first birthday.
IPV*, OPV3/Pentavalent3/RVV3 (in
14 weeks
Due doses should be given at a minimum interval of 4
selected states)
weeks, at the earliest available opportunity.
9 months
MCV1; JE‐1 (where applicable)
(4) Measles vaccine can be given up to 5 years of age.
(5) JE vaccine can be given up to 15 years of age.
MCV2; DPT first booster dose; OPV
(6) IPV* should be given as per immunization schedule
16‐24 months booster dose;
upto 1 year of age.
JE‐2 (where applicable)
‐ single dose of IPV at 14 weeks of age along with OPV3 (in
DPT second booster dose
5‐6 years
28 states/UTs)
‐ two fractional doses of IPV at 6 & 14 weeks (in 8 states
10 years
TT
(Odisha, Maharashtra, Tamil Nadu, Telangana, Karnataka,
Kerala, Puducherry & Andhra Pradesh)
(7) Rotavirus vaccine (RVV) should be given at 6, 10 & 14
16 years
TT
weeks. It can be given up to 1 year of age. (in four states:
Andhra Pradesh, Haryana, Himachal Pradesh and Odisha)
BCG: Bacillus Calmette‐Guerin; DPT: diphtheria‐pertussis‐tetanus; Hep B: Hepatitis B; Hib: Haemophilus
influenzae type b; JE: Japanese Encephalitis; MCV: measles alone or MR/MMR; OPV: oral polio vaccine; TT:
tetanus toxoid; IPV: inactivated poliovirus vaccine; RVV: Rotavirus vaccine
At birth

BCG, OPV‐0, Hep B‐birth dose

28
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 32 -->

Q14. Will IPV vaccine be provided during these drives in states that have introduced the
vaccine?
Yes, the states that have introduced IPV vaccine in the immunization schedule will provide
the vaccine to beneficiaries. Migrant beneficiaries from other states will also be provided all
vaccines being given under UIP. For example, JE vaccines will be given to beneficiaries from
other states in a JE endemic district; IPV vaccine will be given to children (as per GoI
guidelines) from migrant families when they are availing services in a state that has
introduced IPV vaccine. In 28 states/UTs, single dose of IPV will be administered at 14 weeks
of age along with OPV3. However, in 8 states (Odisha, Maharashtra, Tamil Nadu, Telangana,
Karnataka, Kerala, Puducherry & Andhra Pradesh) IPV should be given as two fractional
intradermal doses at 6 and 14 weeks.
Q15. How will all vaccines be delivered to the session sites for Mission Indradhanush?
All vaccines and logistics will be delivered to session sites through alternate vaccine delivery
mechanism. The same mechanism will be used to return all unused and partially used
vaccine vials, along with the session report, to block PHC/urban health post.
Q16. Will any different vaccination card be given to the beneficiaries
of Mission Indradhanush?
No, there is no different vaccination card for Mission Indradhanush.
The MCP card with the revised immunization component used under
the UIP will be used for Mission Indradhanush. If any beneficiary is
getting vaccination for the first time or has lost the previous card, a
new card should be issued.
Q17. Will open vial policy be applicable in Mission Indradhanush?
Yes, open vial policy will be applicable to OPV, IPV, Hepatitis B, DPT,
TT and pentavalent vaccines. Open vial policy is not applicable to BCG, Measles, Rotavirus
vaccine (RVV) and JE vaccines. Do not forget to write the date and time of opening vial on
the label.
Q18. Will ice packs used in the vaccine carriers during
Mission Indradhanush drives be “hard frozen” or
“conditioned”?
Only conditioned ice packs should be used in routine
immunization as well as for Mission Indradhanush drives as
IPV, DPT, Hepatitis B, pentavalent and TT vaccines are freeze‐
sensitive vaccines. When placed in a vaccine carrier with hard
frozen ice packs, these vaccines may freeze and lose their
potency. Also, BCG, OPV, measles and JE vaccines can be
safely transported with conditioned ice packs.
Q19. Will the guidelines for taking out one ice pack during
the routine immunization session be valid for Mission Indradhanush drive as well?
Yes, the vaccinator should take out one ice pack and place vaccines as shown in picture.
29
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 33 -->

Q20. How will these drives be monitored?
These drives will be monitored by independent agencies including WHO, UNICEF, UNDP,
ITSU, JSI, GHS, CORE and other lead partner agencies of RMNCHA in high priority districts.
Besides these agencies, observers from national, state and district levels will also intensively
monitor these drives. Feedback will be provided to the state and district task forces for
immunization to ensure corrective actions.
Based on monitoring and coverage feedback, Mission Indradhanush will closely be reviewed
by District Magistrate/Chief Medical Officer at the district level, Chief Secretary/Principal
Secretary/Mission Director (NHM) at the state level, and Secretary/Additional Secretary &
Mission Director (NHM)/Joint Secretary/Immunization division at the national level. The
progress of Mission Indradhanush is being reviewed periodically by the Prime Minister
Office (PMO) as part of “PRAGATI”.
Q21. How will the reporting of Mission Indradhanush drive take place from ANM to block
to district to state and to national level?
For Mission Indradhanush, the reporting from ANM upwards till state is to be done on a
daily basis. The state will compile district‐level reports and share the compiled report with
national level on the next day.
Q22. Does the district need to include routine
 Mission Indradhanush daily and
immunization coverage report for sessions held
cumulative coverage report should
during Mission Indradhanush round?
only include the coverage done in
Under Mission Indradhanush coverage reporting, the
Mission Indradhanush sessions.
district should not include the coverage of routine
immunization sessions that were held during Mission  This also means that Mission
Indradhanush coverage report
Indradhanush. To explain better, if routine
should be exclusively for Mission
immunization sessions are being held in between the
Indradhanush and should not
Mission Indradhanush drive, the daily coverage report
include the coverage done during
of Mission Indradhanush district will not include the
the routine immunization sessions
routine immunization coverage achieved during those
held in between the Mission
Indradhanush drive.
days, i.e., only immunization coverage achievement
done under Mission Indradhanush session should be forwarded to the next level right up to
30
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 34 -->

national level. Reporting of Mission Indradhanush coverage for every round should be based
on the coverage achieved for that day. The final coverage report of Mission Indradhanush
will include only the coverage of Mission Indradhanush drive.
Q23. Should Mission Indradhanush coverage be reported in the HMIS?
Yes, Mission Indradhanush coverage should be included as Ensure that at the month
part of the monthly coverage reporting in HMIS. In other end Mission Indradhanush
words, it means that the achievement under Mission coverage should be
Indradhanush and routine immunization for that given month included as part of the
should be jointly reported in HMIS as one report. HMIS portal monthly coverage
does not have a separate data entry field for reporting Mission reporting in HMIS
Indradhanush achievement.
Q24. Should planned Mission Indradhanush sessions become a part of routine
immunization microplan?
Yes, planned Mission Indradhanush sessions should be incorporated in routine
immunization microplanning soon after the completion of mission. Mission Indradhanush
microplanning concept is based on potentially weak or priority areas for routine
immunization. State should collect data for such inclusion and inform GoI. This revision in
routine immunization microplanning must be discussed in DTFI and STFI for effective
implementation.
Q25. How should we plan for Mission Indradhanush sessions in vacant sub‐centre areas?
All ANMs in the district will be working for 7 days of Mission Indradhanush, in addition to
the routine immunization days. The ANMs will be deployed, based on need, to the vacant
sub‐centre areas for conducting immunization sessions. After completion of Phase III of
Mission Indradhanush, the additional sessions that are planned in such vacant sub‐centre
areas should be assigned to ANM/s from adjoining sub‐centres or by deploying hired
vaccinators.
Some anticipated scenarios related to Mission Indradhanush
SCENARIO

WHAT SHOULD YOU DO

1. If Mission Indradhanush round start date
coincides with routine immunization day in
state. What needs to be done in such a case?

• In such a case, the planned routine
immunization sessions will not be disturbed
and will be held as planned.
• As per guidelines, ANM should plan to conduct
Mission Indradhanush sessions on 7 working
days in addition to routine immunization days,
excluding Sundays and government holidays.
• Coverage data of routine immunization
sessions will be reported separately from that
of Mission Indradhanush coverage report.
• At the end of month, the Mission
Indradhanush round coverage data and
routine immunization data should be added
and entered together in the HMIS.
31

Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 35 -->

2. How Mission Indradhanush sessions should
be planned at a sub centre where two ANMs
are posted?

 Coverage area should be well demarcated

between two ANMs.
 Each ANM will plan Mission Indradhanush

sessions on 7 working days, excluding routine
immunization days, Sundays and government
holidays.
 Sub‐centres with delivery facilities should plan
accordingly.
 Each of these two ANMs will submit separate
Mission Indradhanush coverage reports each
day.

32
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 36 -->

STEPS FOR PREPARATION OF MICROPLANS FOR MISSION INDRADHANUSH
Microplanning forms the base for the delivery of routine immunization services to the
community. The availability of an updated and complete microplan at a planning unit (urban
and rural) demonstrates the preparedness of the unit and directly affects the quality of
routine immunization services provided.
Microplans developed to make the Mission successful will draw on the lessons learned from
polio eradication towards systems strengthening, vaccine cold chain management, regular
surveillance and monitoring of the plans to reach all children.
Within 2‐3 days of completion of district workshops, the following steps should be
undertaken for preparing a complete microplan for Mission Indradhanush sessions:

Step 1. First block‐level microplanning meeting: Identification of areas that require
sessions under Mission Indradhanush
Facilitators: Two MOs from the block trained at district level, with support from partners
including WHO India NPSP, UNICEF and others. Nodal officer will coordinate this activity in
urban local bodies.
Participants: ANMs/LHVs/health supervisors/key NHM officials at block level
Timeline: To be completed within 2–3 days of district workshop
Activities to be conducted:
 Prepare a master list of all villages/hamlets/HRAs etc. using the existing routine
immunization microplans, polio microplans, census list of villages/hamlets, list of
polio HRAs (slums, nomads, brick kilns, construction sites and other non‐migratory
HRAs), list of areas with measles or diphtheria outbreaks in the last two years (with
any reported measles death) and monitored areas for routine immunization with
sub‐optimal performance.
33
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 37 -->



ANMs will be provided blank microplanning format 1 (Annexure 8) to list all areas
and subsequently identify areas requiring additional sessions under Mission
Indradhanush in their own sub‐centre areas.



During the following 2‐3 days, ANMs should list all HRAs (villages, hamlets, slums,
nomadic sites, brick kilns, construction sites, other high‐risk settlements) on the
ANM microplanning format 1 (Annexure 8). Once all areas are listed, ANMs will
identify areas where the number of unvaccinated (left outs) and partially vaccinated
(drop outs) children up to 2 years of age is high and require additional sessions.
Enlisting of beneficiaries will require ASHA/AWW/link worker support for headcount
survey.

Step 2. Block/Urban health unit microplanning meeting
Facilitators: Two MOs from the block trained at district level, with support from partners
including WHO India NPSP, UNICEF and others. Nodal officer will coordinate this activity in
urban local bodies.
Participants: ANMs/LHVs/health supervisors/key NHM officials at block level
Timeline: To be completed within 2‐3 days of the first block microplanning meeting
Activities to be conducted:
 ANMs will bring filled microplanning format 1 (Annexure 8) during training at the
block level. This will be reviewed by the trainer and amended if required.


Block/health post MO IC will identify areas that require additional routine
immunization sessions from all sub‐centres. MO IC will enlist all such areas in
microplanning format 2 (Annexure 8) and also determine whether these sites will be
covered through outreach sessions or mobile sessions.



Each ANM will prepare a roster using microplanning format 3 (Annexure 10) for
additional sessions in her own sub‐centre area in consultation with the Block MO IC.
For Mission Indradhanush days, she can be assigned areas outside her sub‐centre
area for a maximum of 7 days of Mission Indradhanush activity.



Once the ANM has prepared her roster for areas requiring additional Mission
Indradhanush sessions in her own sub‐centre area, MO IC will identify areas in the
block that require an additional session but have not been included in any ANM’s
roster. This may happen in vacant sub‐centre areas where the ANM is on long leave
or absent for any other reason. MO IC will assign such areas to other ANMs in the
block for the remaining days of the Indradhanush round. This assignment should be
done keeping in mind the travel time and feasibility of this assignment. These
assigned sessions will be included by ANMs concerned in their roster for the round.



Such ANMs working in other sub‐centre areas may be supervised by a different
supervisor.
34
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 38 -->



Plan to engage all ANMs during the Mission Indradhanush drive.



ASHAs/AWWs/link workers will be assigned to each session in consultation with the
block ASHA coordinator. The ASHA manager will ensure that headcount is conducted
for estimation of beneficiaries in additional areas assigned to a mobilizer. Ensure that
this is a time‐bound activity (1 week) and its progress is monitored by DTFI. MO IC
will monitor and provide oversight to this activity.

In urban areas:
 Identify Nodal officer for immunization activities in urban areas for Mission
Indradhanush


Nodal officer will demarcate the urban area into the catchment area of available
health posts. He/she will then identify the available health manpower (ANMs/public
health nurses/health supervisors) in each health post.



Considering 2–3 polio team days as one unit, each health post in‐charge will map and
list each such unit in microplanning format 1 (Annexure 8).



Once all areas are listed, health post in‐charges will identify areas where numbers of
unvaccinated (left outs) and partially vaccinated (drop outs) beneficiaries require
additional sessions (posh colonies/areas with high routine immunization coverage
will not be included in this planning). All such areas will be listed in microplanning
format 2 (Annexure 9).

Step 3. District‐level microplan finalization meeting
Facilitators: CMO/DIO and trained MO with support from partners including WHO India
NPSP, UNICEF and others
Participants: Two MOs from each block and urban nodal officers
Timeline: To be conducted within 2–3 days of block/urban health unit microplanning
meeting
Activities to be conducted:
 Each block medical officer‐in charge (MO IC) and nodal officer (in urban areas) will
carry microplanning Form 2 of his/her block/urban area along with microplanning
Form 3 (ANM roster for Mission Indradhanush) for all ANMs in the block.


Nodal officer in urban areas will discuss the number of sessions that have not been
assigned to any ANM/vaccinator.



DIO will assess the number of sessions in each block and all urban areas that have
not been assigned to any ANM/vaccinator. He/she will also assess the number of
ANM days available with each block/urban area that may be handed over to another
block/urban area.

35
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 39 -->



ANMs with one or more days available during Mission Indradhanush week can be
assigned to another block/urban area for conducting routine immunization sessions
during this drive. This assignment should be done keeping in mind the travel time
and feasibility of this assignment.



These assigned sessions will be included in the ANM roster (microplanning Form 3)
of ANMs by their MO ICs concerned.



Such ANMs working in other sub‐centre areas may be supervised by a different
supervisor.



This meeting will also allow the DIO to review the requirement of mobile units for
conducting vaccination sessions in blocks/urban areas.



DIO will also assess the requirement of hiring vaccinators for conducting sessions
during this drive.

Step 4. Block meeting with ANMs, ASHAs, AWWs and link workers for microplan
distribution
Facilitators: Two MOs from the block trained at district level, with support from partners
including WHO India NPSP, UNICEF and others. Nodal officer will coordinate this activity in
urban local bodies.
Participants: ANMs/LHVs/health supervisors/key NHM officials at block level
Timeline: To be completed within 2 days of district microplan finalization meeting
Activities to be conducted:
 MO ICs of blocks and urban health posts will conduct this meeting with their
ANMs/health workers/hired vaccinators after the district‐level microplanning
meeting.


By this time, each ANM roster (Annexure 10) will be filled with the following:
o



Areas included in ANM’s sub‐centre with weak routine immunization
coverage, where she will conduct routine immunization sessions on the two
routine immunization days designated by the state (as stated in the example
above). Sessions that ANM will conduct in the neighbouring block/urban area
on the remaining days of Mission Indradhanush round. During these days,
she will be supervised by the supervisor designated for that particular area.

The ANM concerned will need to discuss details (how to reach designated area,
where to pick up vaccines) with the supervisor of the area. Details of the mobilizer
(name and contact number) will be available in the ANM roster for Mission
Indradhanush rounds.

36
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 40 -->



Each ANM will send her tally sheet to the block through the alternate vaccine
delivery (AVD) mechanism on a daily basis so that reports can be compiled and
submitted to the district on a daily basis.



Monitoring feedback for the ANM will be shared with the MO IC of the planning unit
where she is working for the day. MO will share feedback of the MO IC of the block
where the ANM is posted.

37
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 41 -->

VACCINES AND LOGISTICS MANAGEMENT
An effective vaccine, logistics and cold chain system is an essential prerequisite for
successful running of an immunization
National switch date is 25 April 2016:
programme. It is critical for immunization
Do not use tOPV after the switch date
services to ensure the availability of appropriate
equipment and an adequate supply of high‐quality vaccines and immunization‐related
materials to all levels of the programme. It is important to ensure correct implementation of
relevant strategies. The key areas of logistics support include vaccine management and
monitoring, cold chain management and immunization safety.
If vaccine, logistics and cold chain programme is well managed, it can help save on
programme costs in ensuring programme
Any new vaccine introduced will be a
implementation efficiently without sacrificing the
part of Mission Indradhanush.
quality of service delivery. Poorly managed
logistics systems can lead to high and/or unnecessary vaccine wastage rates, stock outs, or
improper management of waste, resulting in significant operational programme costs, as
well as a negative impact on public health.
Vaccine stores at all levels (state, regional, district, primary health centers (PHCs),
community health centers, other cold chain storage points) need to forecast their vaccine
needs for the stipulated time period to ensure that the right amount of vaccines, logistics
and cold chain equipment are available to vaccinate all eligible infants at a given time in a
given area. Each of these levels should monitor the stock of vaccine and syringes in order to
assess the lead‐time and re‐ordering levels.
12.1 Estimating vaccines and syringes needed
 Logistics including auto‐disable
Figure 3. Vaccine/Diluent reporting for Mission Indradhanush
(AD) syringes and MCP cards
available under the existing UIP
programme will be used for
Mission Indradhanush.


As each AD syringe is packed
separately, hence, maximum
permissible wastage rate for AD
syringes equal to vaccine doses
supplied including wastage.



Estimation of vaccine and
logistics requirements should be done on the existing formats, based on the estimation
of beneficiaries.

38
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 42 -->



PHCs and districts need to forecast their vaccine needs for the stipulated time period to
ensure that the right amount of vaccine, AD syringes and cold chain equipment are
available to vaccinate all eligible beneficiaries in the identified areas at a given time.



DIO will be responsible for ensuring availability of required stock of vaccine and logistics
for the Indradhanush sessions. Buffer stocks should be maintained as per
recommendations.



In case of any vaccine or logistic shortage at any session during the Indradhanush week,
the ANM will contact the supervisor, who will arrange the required vaccine(s)/logistics
from the nearby session or planning unit. Shortage at the block must promptly be
replenished from the district level. In case of any shortage at district level, SIO will be
informed for necessary action.



The monitoring of vaccines and logistics can be done through eVIN in the states of Uttar
Pradesh, Bihar and Madhya Pradesh.

The reporting chain for vaccines/diluents is given in Figure 3.
12.2 Vaccine wastage
 The existing open vial policy (OVP) guidelines will be applicable to significantly reduce
vaccine wastage. All efforts should be made to minimize vaccine wastage at all levels.


The maximum acceptable wastage for vaccines eligible for reuse under the OVP (such
as pentavalent vaccine, oral polio vaccine (OPV), IPV (inactivated poliovirus vaccine),
hepatitis B, diphtheria‐pertussis‐tetanus [DPT], and tetanus toxoid (TT) vaccine) is 10%.

Summary: Wastage permissible for all vaccines In Routine immunization
Vaccine
Maximum acceptable wastage
BCG
50% and the wastage multiplication factor for calculation is 2.0.
RVV, Measles and JE
25% and the wastage multiplication factor for calculation is 1.33.
IPV, OPV, Pentavalent
10%. for all vaccines eligible for reuse under the open vial policy
Hepatitis B, DPT, TT
The wastage multiplication factor for calculation is 1.11.

12.3 Cold chain space and inventory
The cold chain infrastructure in India is a wide network of cold chain stores consisting of
government medical supply depots (GMSD), state, regional/divisional vaccine stores, and
district and PHC/CHC vaccine storage points. The cold chain network in the country has
been the backbone to ensure that right quantity and right quality of vaccine reaches the
target population.
In states that have introduced the pentavalent vaccine, cold chain space availability has
increased due to the reduced requirement of DPT and hepatitis B vaccines. With this freed
capacity, there is no constraint envisaged on the cold chain capacity for storage of IPV.

39
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 43 -->

The cold chain inventory should be regularly reviewed and status of the same should be
updated in the National Cold Chain Management Information System (NCCMIS).
12.4 Cold chain monitoring
Proper storage of vaccines and maintenance of the
cold chain during storage and distribution are
essential to prevent the loss of potency. Once a
vaccine loses its potency, this cannot be regained.
Damaged vaccines should be discarded according to
the guidelines. Measures should be taken to protect
heat and freeze sensitive vaccines such as
pentavalent and IPV because they lose their potency
when exposed to temperatures outside the range
recommended by the manufacturer. The heat
impact on vaccines is cumulative.
12.5 Vaccine storage
To ensure efficacy of the vaccines, proper storage and packing are essential. The following
are recommended for vaccine storage:
 In top‐opening refrigerators (ice‐lined): store freeze‐sensitive vaccines including DPT, TT,
Hep B, Pentavalent vaccine and IPV and other on top.
 Freeze sensitive vaccines could be damaged if placed in direct contact with frozen ice
packs that were inadequately conditioned. Therefore, water ice packs should be
conditioned before use.
12.6 Conditioning of water ice packs
In order to ensure correct storage of vaccines,
the following procedures should be followed:
 Ensure that the insulated vaccine carriers
are clean before use and at end of the day.
 Use a packing table, and remove ice packs

from freezer and place on table to defrost.
Packs are ready to use when there are
physical signs of thawing; no ice but drops
of water on surface, and liquid is
observed inside.
 Dry the packs and line the walls of the

insulated vaccine carrier with them.
 Place the vaccines inside and ensure that the container is properly closed.

40
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 44 -->

 Allowing ice packs to thaw means that the initial freezing temperature is lost, so the

temperature in the insulated carrier does not drop below 0°C.
 Properly conditioned water ice packs constitute the best method to maintain the

temperature of the insulated carriers and cold boxes.
 There should be sufficient ice packs to ensure that the vaccines are totally surrounded

during transportation.
12.7 Recording and reporting
 Recording and reporting of vaccination during Mission
Indradhanush rounds will be done in the attached
formats on a daily basis to the next higher level, i.e.,
ANM will report to the block PHC in the tally sheet for
Mission Indradhanush (Annexure 13a & 13 b), block
PHC will report to the district, and so on (Figure 3).
 Vaccination will also be reported through the existing

HMIS and mother and child tracking system (MCTS)
portals. Blocks will compile ANM reports (Annexure 14a
& 14b) and districts will compile block reports (Annexure 15a & 15b) and submit to the
state (Annexure 16a & 16b).
 Critical indicators that will be derived from these reports are:
o
o
o
o
o

total beneficiaries immunized
total children fully immunized
total children completely immunized
total beneficiaries vaccinated antigen‐wise
total children vaccinated for first time

 The routine immunization sessions will be held as planned but coverage data of these

sessions will not be included in the Mission Indradhanush coverage report. However, at
the end of month, the Mission Indradhanush round coverage data and routine
immunization data will be entered together in the HMIS.
12.8 Communication materials
It is important to revise and distribute IEC materials for creating awareness among the
community and caregivers before the Indradhanush rounds. The GoI will share prototypes of
IEC materials with all states. The states can adapt these IEC materials as per their
requirements.
12.9 Waste disposal
Keeping in harmony with the “Swaach Bharat Abhiyan” launched by the GoI, each session will
ensure clean surroundings and proper segregation and containment of all immunization waste

41
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 45 -->

generated. The immunization waste will be sent to the PHC for disinfection and finally disposed
of as per norms of the Central Pollution Control Board.

12.10 Launch of Mission Indradhanush
Mission Indradhanush provides states with an opportunity to reach the unvaccinated and
partially vaccinated children and pregnant women and improve the full immunization status. A
well‐publicized launch ceremony for the Mission should be planned to improve general
awareness about the UIP, with a focus on unreached/poorly reached areas as per the criteria
described earlier.
Successful launch of the Mission will include mass media components as well as one‐to‐one
interpersonal contact with beneficiaries to openly respond to queries. To be able to respond
comprehensively, other related government departments, local media and NGOs should be
briefed and brought on board, so that they may also spread the message and motivate the
community to benefit from immunization. The state and district task forces on immunization
should steer the planning, coordination, implementation and monitoring of the programme.
Recording and reporting formats and communication materials should be prepared in local
languages and distributed well in advance to target audiences. Failures in communication
commonly occur because the disseminated materials do not reach the intended targets and/or
the information is not appropriate for the intended audience.

42
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 46 -->

ROLE OF PARTNER AGENCIES
The technical and monitoring support of partner agencies such as WHO, UNICEF, Rotary
International and other stakeholders continues to be of significance in strengthening of
health systems and programmes in India. States must actively engage these partner
agencies in their core areas of strength.
WHO
WHO India will provide technical support to the government by building sustainable
institutional capacity for effective planning and implementation and undertake routine
performance monitoring at district/block level for timely delivery of routine immunization
services. The following are the key thematic areas of support:
 Facilitate preparatory meetings for the development of microplans at district and
block levels.
 Develop training materials and build capacity of district trainers for training of health
personnel.
 Track the progress and implementation of the Indradhanush round.
 Provide monitoring feedback during task force and other review meetings at district,
state and national levels.
 Risk prioritization
UNICEF
 Support state, districts and blocks for social mobilization activities, dissemination of
information and their monitoring through its social mobilization network.
 Provide supportive supervision for cold chain and vaccine management using
standardized checklists and sharing feedback at the national, state and district levels.
 Participate as resource persons in training of health personnel at state and district
levels.
 UNICEF will work collaboratively with Immunization Technical Support Unit (ITSU) to
develop the dissemination plan for Mission Indradhanush at the national, state,
district and block levels.
 Strategic communication unit of ITSU will take a lead on communication plan
activities. ITSU will formalise the communication plan with inputs and support from
UNICEF, Rotary, Global Health Strategies and other partners.
Rotary International
 Advocacy at state and district levels for routine immunization strengthening,
specifically for Indradhanush.
 Supporting the mass awareness campaign through intensified IEC activities and
community mobilization interventions.

43
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 47 -->

Lead partners for call to action (RMNCH+A)
 The RMNCH+A state lead partners will assist with implementation of strategies to
strengthen the Mission in selected high‐focus districts. They will also support
monitoring of immunization drives and share feedback at block, district and state
levels. Any critical support required by the state may be forwarded to the lead
partner agency through the STFI.
Professional bodies and CSOs
Key state and local bodies such as IMA, IAP and CSOs should be actively involved.
These organizations are expected to play a critical role in awareness generation and
advocacy, particularly at the local level. They will participate in district and state level
meetings.

44
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 48 -->

MONITORING AND EVALUATION
A massive framework has been put in place for
rigorous monitoring of one of the largest
immunization programmes of the world.
Oversight of the implementation activities is
crucial at all levels. Supervision should focus on
bringing the gaps identified through the state and
district preparedness assessment checklists.

“Hon’ble Prime Minister, Shri Narendra Modi, has
reviewed Mission Indradhanush under ‘PRAGATI’ –
the ICT‐based, multi‐modal platform for Pro‐Active
Governance and Timely Implementation” with
Chief Secretaries on 17 February 2016. During the
session, he emphasized the need for an organized
and aggressive action plan to cover all children for
immunization in a specific time‐frame.

Critical information on preparedness, including
quality of task forces for Immunization,
deputation of senior officials to priority areas for
monitoring, status of trainings at state, district
and block levels and status of microplanning
activities will be collated by medical officers and
field monitors, and information generated will be shared with the Ministry of Health and
Family Welfare, Government of India on a weekly basis. Information generated from
concurrent monitoring will be utilized at local level during evening debriefing meetings at
block and district level to ensure midcourse corrective actions. Data generated from the
monitoring formats will be collated in a data tool to generate key indicators that will be
shared at all levels with the government.
14.1 Monitoring of operations
The Mission Indradhanush rounds will be intensively monitored in the highest priority areas
by officials from the national, state and district levels. Using the Mission Indradhanush
monitoring formats for session site monitoring and house to house monitoring, all available
monitors from national, state and district levels should be deployed to monitor activity in
the highest priority blocks/urban areas. The monitoring formats should be compiled and
summarized as per normal practices.
National‐level monitors: Officials from MoHFW, GoI and partner agencies
State‐level monitors: Senior state health officials deployed to the Mission Indradhanush
districts by STFI

District‐level monitors: Senior district health officials deployed to high priority blocks by
DTFI
Key indicators derived from monitoring are given below.
Mission Indradhanush Session monitoring indicators
This captures information on vaccine supply and the availability of logistics, functioning of
alternate vaccine delivery (AVD) system, injection practices of ANMs, injection safety and

45
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 49 -->

waste disposal, record keeping and inter‐personal communication of service providers. The
following indicators will be monitored:
 Sessions held as per plan
 Reasons for sessions not held
 Percentage of sessions found held among monitored HRAs (can be generated by
type of HRAs)
 ANMs/ASHAs having due list
 IEC display status
 Availability of vaccines
 Reason analysis on non‐availability of any vaccine
 Indicators on AEFI and implementation of OVP
 Availability of logistics as per microplan
 Indicators on safe injection practices
 Sessions visited by supervisors
 Caregiver responses regarding proactive mobilization efforts
 Reason analysis on non‐availability of any vaccinator
 Dissemination of four key messages to caregivers.
 ANM days planned/ utilized
 Percentage of vacant sub centers saturated with ANM
 Number of Mission Indradhanush sessions held outside the ANM sub‐center
area/block
Mission Indradhanush House‐to‐house monitoring indicators
 Percentage of children due for any vaccine during Indradhanush
 Percentage of children due in Indradhanush that got vaccinated with vaccine(s)
 Percentage of children who received vaccines for the first time in Indradhanush
 Mobilization efforts: percentage awareness by ASHAs/AWWs/ANMs/others.
State /District Immunization Officer
 Have we made any progress towards expanding our microplans after Phase I and Phase II Mission
Indradhanush rounds?
 Have all additional sessions planned during Mission Indradhanush (phase I & II) been included in
the regular routine immunization microplans in district/blocks?
 If yes, have the districts projected their funding requirement accordingly in their project
implementation plans (ASHA incentive, AVD, any district specific activity proposed with
justification)?

46
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 50 -->

State/District Immunization Officer
Prior to next phase of Mission Indradhanush
Critical Microplan Review:
‐ Has the district assigned priority blocks to senior officers?
‐ Have all areas with vacant sub‐centers been included?
‐ Have all areas where no routine immunization sessions planned due to staff on
leave/deputation been included?
‐ Are all Polio HRAs with no routine immunization service delivery included?
‐ Areas where VPD outbreaks reported;
‐ Have all hard‐to reach areas/areas that are part of routine immunization
sessions but with poor mobilization included?
‐ Have areas where routine immunization monitoring shows gaps included?
‐ How many ANMs have been planned to move to other sub center within the
same block or to sub centers outside the block but in the same districts?
‐ Have they been informed about their TA/DA support as per state rules?
‐ In the areas where Mission Indradhanush sessions planned, has head count
survey been conducted?
‐ Following head count survey, have the due lists been made to track the
beneficiaries?
‐ What is the status of IEC material for next phase of Mission Indradhanush?
‐ Has the district made a plan for timely funds transfer to mobilizers?

14.2 Adverse Events Following Immunization (AEFI)
Any community’s perception and acceptance of immunization rests on its safety. Any AEFI
should therefore be reported, investigated and responded to promptly and adequately as
per existing guidelines. All staff should familiarize themselves with these guidelines and
reporting formats. The AEFI management centres will have to be identified with contact
details mentioned in microplans.
14.3 Monitoring of communication interventions
For effective implementation of the communication plan, it is imperative to monitor all
activities mentioned in the communication plan. Periodic monitoring (programme and
finance) of communication interventions provides the policy/programme managers with:
 status of all planned IEC/BCC activities mentioned in the state/district
communication plan
 progress of various IEC/BCC activities at a particular time and at a particular
implementation level
 status of capacity‐building activities as per the training plan

47
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 51 -->




status of dissemination (achieved against planned) and stock position of IEC material
at various levels – state, district, block
status of planned initiatives related to advocacy, coordination, convergence, etc.

The monitoring plan will comprise a list of measurable and quantitative activities from the
final state/district communication plan, previous community needs assessment, data from
evaluations/surveys conducted and protocol/guidelines for monitoring plan implementation
framework. Additionally, states with a robust management information system will be able
to provide accurate, complete and timely data for effective monitoring of IEC/BCC activities
based on HMIS. Feedback must be an integral part of the monitoring plan to provide timely
feedback to data generating units on quality of data.
14.4 Evaluation methodology
A new cross‐sectional survey called Integrated Child Health and Immunization Survey
(INCHIS) was designed to obtain nationally representative data on immunization coverage
and child health during phases I and II of Mission Indradhanush. This survey periodically
collected data at a national level to measure progress related to immunization coverage,
child health and its system determinants. Using an internationally established sampling
methodology, information obtained from selected states has been used to evaluate the
impact of Mission Indradhanush.

48
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 52 -->

KEY POINTS FOR SUCCESSFUL IMPLEMENTATION OF MISSION
INDRADHANUSH PHASE III
An equity‐based programme, Mission Indradhanush launched in 2015, builds on polio
strategies, tools, techniques and manpower to focus specific attention on identified high‐
risk areas with traditionally low coverage, such as slums, and among nomadic populations
and migrant families living in brick kilns and construction sites. The mission also targets the
400,000 high risk areas identified in the polio programme as well as other underserved
areas where there are insufficient health services (gaps or lack in vaccinators, etc.), migrant
populations, recent measles/diphtheria outbreaks or high dropout rates. It uses the special
strategies developed by the polio teams to access these high risk, hard‐to‐reach and
underserved communities.
Government ownership, partnerships and accountability framework
 Led by the government, a rigorous monitoring framework replicating the polio
accountability system was put in place for providing oversight to Mission
Indradhanush implementation activities at the state, district and block levels through
health experts, officials and various partners. The polio programme and now Mission
Indradhanush have the highest levels of political commitment and senior policy
makers being involved personally.
 Task forces for immunization at the state, district and block levels have been
established using the polio model for regular planning and review of the routine
immunization programme. Monitoring data from the field is fed back to the block,
district and state task forces for immediate corrective action and to guide
programmatic decision‐making and actions following the campaigns.
 The core polio partners – WHO, UNICEF, Rotary, CORE, BMGF, and other partners
continue to work closely together with the government on strengthening routine
immunization.
Microplanning for Mission Indradhanush

Detailed district and block microplanning was critical to effective interruption of
polio transmission in India. During campaigns, vaccinators used microplans to track
vaccination activities in each community, and review by district task forces
determined which children were missed and corrective actions taken as part of the
accountability and supervisory system.

Certain “high‐risk” areas have been especially difficult to immunize – barriers due to
geography, poverty, internal mobility/migration, lack of education, variety of
languages cultural diversity and distrust of the government, as well as sheer
population density have required creative and persistent efforts. Mission
Indradhanush brought in communities that previously had only been reached for
polio vaccination but with limited access to RI services. Microplanning for Mission

49
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 53 -->



Indradhanush focused on improving coverage and addressing equity issues in access
to immunization.
Additional immunization sites planned under Mission Indradhanush are being
included into the government system’s Routine Immunization microplans with
support from the WHO & UNICEF polio network to ensure completeness of routine
immunization service reach.

Head count survey and due list preparation
 Head count process to develop session specific due‐list based on head count should
be initiated well in advance, and pre‐round validation of head survey should be done
for improving coverage. There is a need of regular orientation and supervision of
frontline workers for doing head count survey, due list updation and mobilization of
children.
Capacity building of frontline workers
 Frontline workers were trained prior to Mission Indradhanush with brief orientation
during subsequent campaign. These trainings will improve technical and
communication skills of frontline workers.
 Reorientation of frontline workers on IPC skills should also be conducted on a regular
basis.
Supervision of activities
 The STFI and DTFI are essential. Assign national and state level officials for
monitoring Mission Indradhanush rounds. District and sub district supervision should
also be strengthened.
 National and State level officials for monitoring Mission Indradhanush have shown
improved quality of work. District and sub district supervision was patchy and should
be strengthened.
 Review
by MD‐NHM/Secretary/PS ensures strong ownership at the
state/district/block.
 Feedback loop with utilization of technology (video conference/mobile‐sms) found
effective.
Vaccine and cold chain management
 Urgent attention is needed to improve vaccine upkeep to ensure conditioning of ice
packs, maintenance of distribution register, implementation of open vials policy and
its records, and adherence to AVD plan. Focus on cold chain management training.
Social mobilization
 Social mobilization was an issue during first two phases; most of the states did not
prepared IEC materials. However, as a result of financial clarity and regular follow
ups from national level, significant improvement was observed in most of the states.
 IEC is an important factor in creating awareness in community about the importance
of immunization. Therefore, IEC activities should be improved.
50
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 54 -->




o PRI members, ration dealers and local influencers’ involvement should be
strengthened.
Need of standardization of IEC material is required.
Concept of mothers’ meeting, Nukkad Natak, videos in the community, etc., should
be strengthened.

Timing



Special catch up rounds should be planned in a way to ensure better coverage of
migratory populations and HRG sites.
In Mission Indradhanush, day should be fixed and not the date. We should plan from
a day in the week rather than date in the month.

Financial issues
 Communication of financial guidelines for IEC activities should be shared well in
advance. The financial guidelines have to be released well on time for replication.
 Ensure timely payments of incentives to motivate ASHAs/mobilizers.
Data management
 Newly designed tally sheet will help in reporting as well as tracking beneficiaries
during all rounds.
 Ensure completeness and quality of data transmission an issue.

51
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 55 -->

ANNEXURES
Annexure 1. Mission Indradhanush Phase III, 216 High Focus Districts
STATE
ANDHRA PRADESH
(4 districts)
ARUNACHAL PRADESH
(5 districts)
ASSAM
(12 districts)

BIHAR
(19 districts)

CHHATTISGARH
(4 districts)
DELHI
(2 districts)
GUJARAT
(12 districts)
HARYANA
(6 districts)
JAMMU & KASHMIR
(5 districts)
JHARKHAND
(6 districts)
KARNATAKA
(6 districts)
KERALA
(2 districts)
MADHYA PRADESH
(13 districts)

MAHARASHTRA
(12 districts)
MANIPUR
(4 districts)
MEGHALAYA
(3 districts)
MIZORAM
(4 districts)

EAST GODAVARI
KURNOOL
CHANGLONG
LOHIT
BARPETA
DHUBRI
HAILAKANDI
NAGAON
ARARIA
CHAMPARAN WEST
JAMUI
MUZAFFARPUR
SAMASTIPUR
SUPAUL
LAKHISARAI
JASHPUR
SARGUJA

DISTRICTS
GUNTUR

KRISHNA

EAST KAMENG
LOWER SUBANSIRI
BONGAIGAON
GOALPARA
KARIMGANJ
SONITPUR
BEGUSARAI
DARBHANGA
KATIHAR
SARAN
SITAMARHI
GOPALGAANJ

LOWER DIBANG VALLEY
DARRANG
GOLAGHAT
MARIGAON
KOKRAJHAR
CHAMPARAN EAST
GAYA
KISHANGANJ
SAHARSA
BHOJPUR
NAWADA

BIJAAPUR

RAIPUR

NORTH‐EAST

NORTH‐WEST

AHMEDABAD
DAHOD
PANCHMAHALS
BHAVNAGAR
FARIDABAD
PALWAL
DODA
RAJAURI
DEOGHAR
GODDA
BANGALORE (U)
KOPPAL

AHMEDABD CORP.
DANGS
SABARKANTHA
JAMNAGAR
GURGAON
PANIPAT
KISHTWAR
RAMBAN
DHANBAD
PAKUR
BELLARY
RAICHUR

PALAKKAD

MALAPPURAM

ALIRAJPUR
DAMOH
RAISEN
SATANA
VIDISHA
AHMEDNAGAR
DHULE
NANDED
PARBHANI
CHURACHNADPUR
UKHRUL

ASHOKNAGAR
JHABUA
REWA
TIKAMGARH

CHHATARPUR
PANNA
SAGAR
UMARIYA

AURANGABAD
HINGOLI
NASIK
SOLAPUR
SENAPATI

BEED
JALGAON
PALGARH
THANE
TAMENGLONG

EAST KHASI HILLS

WEST GARO HILLS

WEST KHASI HILLS

LAWNGTLAI
SAIHA

LUNGLEI

MAMIT

BANASKANTHA
KUTCH
VALSAD
JUNAGADH
MEWAT
REWARI
PUNCH
GIRIDIH
SAHIBGANJ
GULBARGA
YADGIR

52
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 56 -->

STATE
NAGALAND
(6 districts)
ODISHA
(3 districts)
PUNJAB
(3 districts)
RAJASTHAN
(12 districts)
TAMIL NADU
(1 district)
TELANGANA
(2 districts)
TRIPURA
(3 districts)

DIMAPUR
MON

DISTRICTS
KIPHIRE
TUENSANG

KOHIMA
WOKHA

GAJAPATI

KHURDA

RAYAGADA

GURDASPUR

LUDHIANA

MUKTSAR

ALWAR
CHITTAURGARH
JODHPUR
PRATAPGARH

BARMER
DHAULPUR
KARAULI
SAWAI MADHOPUR

BUNDI
JAIPUR
NAGAUR
TONK

COIMBATORE
ADILABAD

HYDERABAD

DHALAI

TRIPURA NORTH

TRIPURA WEST

UTTAR PRADESH
(55 districts)

AGRA
AMETHI
AZAMGARH
BAHRAICH
BANDA
BULANDSHAHAR
ETAWAH
FEROZABAD
GORAKHPUR
HARDOI
KASGANJ
KUSHINAGAR
MAINPURI
MEERUT
MUZAFFARNAGAR
SHAHJAHANPUR
SHAMLI
SULTANPUR
UNNAO

ALIGARH
AMROHA
BADAUN
BALLIA
BARABANKI
CHITRAKOOT
FATEHPUR
GHAZIABAD
HAPUR
JAUNPUR
KAUSHAMBI
KHERI
MAHARAJGANJ
MIRZAPUR
PILIBHIT
SAMBHAL
SONBHADRA
SRAWASTI

ALLAHABAD
AURAIYA
BADOHI
BALRAMPUR
BAREILLY
ETAH
FARRUKHABAD
GONDA
HATHRAS
KANNAUJ
KANPUR DEHAT
LALITPUR
MATHURA
MORADABAD
RAMPUR
SIDDHARTHNAGAR
SITAPUR
VARANASI

UTTARAKHAND
(1 district)

HARDWAR

WEST BENGAL
(11 districts)

24‐PARGANAS NORTH
BIRBHUM
PURBA MEDINIPUR
ALIPURDUAR

24‐PARGANAS SOUTH
MURSHIDABAD
COOCH BEHAR
BANKURA

BARDHAMAN
UTTAR DINAJPUR
JALPAIGURI

53
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 57 -->

Annexure 2. National Immunization Schedule (NIS) for infants, children and pregnant
women
Vaccine

Due age

Max age

Dose

Diluent

Route

Site

Intra‐
muscular

Upper Arm

For Pregnant Women
TT‐1

Early in
pregnancy

TT‐2*

4 weeks after
TT‐1*

TT‐ Booster

Give as early as
possible in
pregnancy

0.5 ml

NO

0.5 ml

NO

If received 2 TT
doses in a
pregnancy
within the last
3 years*

0.5 ml

NO

Intra‐
muscular

Upper Arm

At birth

till one year
of age

(0.05 ml
until 1
month)
0.1ml
Beyond age
1 month

YES
Manufacturer
supplied
diluent
(Sodium
chloride)

Intra‐
dermal

Upper Arm
‐ LEFT

Hepatitis B ‐ Birth
dose

At birth

within 24
hours

0.5 ml

NO

Intra‐
muscular

Antero‐
lateral side
of mid‐
thigh ‐ LEFT

OPV‐0

At birth

within the
first 15 days

2 drops

‐

Oral

Oral

OPV 1, 2 & 3

At 6 weeks,
10 weeks &
14 weeks

till 5 years of
age

2 drops

‐

Oral

Oral

DPT 1, 2 & 3

DPT 1, 2 & 3 are replaced by Pentavalent 1, 2 & 3

NO

Intra‐
muscular

Antero‐
lateral side
of mid‐
thigh ‐ LEFT
Antero‐
lateral side
of mid‐
thigh ‐
RIGHT
Oral

Intra‐
muscular

Upper Arm

For Infants

BCG

Hepatitis B
1, 2 & 3
Pentavalent
1, 2 & 3†
(Diphtheria+
Pertussis + Tetanus +
Hepatitis B + Hib)

Hepatitis B 1, 2 & 3 are replaced by Pentavalent 1, 2 & 3
At 6 weeks,
10 weeks &
14 weeks**

1 year of age

0.5 ml

IPV # (Inactivated
Polio Vaccine)

At 14
completed
weeks

1 year of age

0.5 ml

NO

Intra‐
muscular

Rotavirus‡
(Where applicable)

At 6 weeks,
10 weeks &
14 weeks

1 year of age

5 drops

NO

Oral

54
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 58 -->

Vaccine

Due age

Measles/MR 1st
dose ##

At 9
completed
months‐12
months.

Japanese
Encephalitis – 1 @
(Where applicable)

Vitamin A
(1st dose)
For Children
DPT Booster‐1

At 9 months‐
12 months @

At 9 months

16‐24 months

Max age

Dose

5 years of age

0.5 ml

15 years of
age

0.5 ml

5 years of age

1 ml
( 1 lakh IU)

7 years of age

0.5 ml

Diluent
YES
Manufacturer
supplied
diluent
(Sterile
water)
YES ‐
Manufacturer
supplied
diluent
(Phosphate
Buffer
Solution)
‐

NO
YES
Manufacturer
supplied
diluent
(Sterile
water)
NO
YES
Manufacturer
supplied
diluent
(Phosphate
Buffer
Solution)

Measles/MR 2nd
dose ##

16‐24 months

5 years of age

0.5 ml

OPV Booster

16‐24 months

5 Years

2 drops

16‐24 months
@

till 15 years of
age

0.5 ml

Vitamin A $
(2nd to 9th dose)

At 16 months.
Then, one
dose every 6
months

Up to the age
of 5 years

2 ml
(2 lakh IU)

‐

DPT Booster‐2

5‐6 years

7 years of age

0.5 ml

NO

TT

10 & 16 years

16 years

0.5 ml

NO

Japanese
Encephalitis – 2 @
(Where applicable)

Route

Site

Sub‐
cutaneou
s

Upper Arm
‐ RIGHT

Sub‐
cutaneou
s

Upper Arm
‐ LEFT

Oral

Oral

Intra‐
muscular

Antero‐
lateral side
of left mid‐
thigh

Sub‐
cutaneou
s

Upper Arm
‐ RIGHT

Oral

Oral

Sub‐
cutaneou
s

Upper Arm
‐ LEFT

Oral

Oral

Intra‐
muscular
Intra‐
muscular

Upper Arm
Upper Arm

* Give TT‐2 or Booster doses before 36 weeks of pregnancy. However, give these even if more than 36 weeks have passed. Give TT to
a woman in labour, if she has not previously received TT. † Pentavalent vaccine is introduced in place of DPT and HepB 1, 2 and 3. ‡
Rotavirus vaccine has been introduced in initially 4 states – Andhra Pradesh, Haryana, Himachal Pradesh and Odisha. # IPV –
fractional dose (0.1ml) intradermal at ages 6weeks and 14 weeks introduced in select states. ## MR vaccine has been
recommended and approved for introduction in place of measles vaccine in the UIP schedule. @ JE Vaccine has been introduced in
nd
select endemic districts. If first dose delayed beyond 12 months ensure minimum 3 months gap between 2 JE doses. $ The 2 to
th
9 doses of Vitamin A can be administered to children 1‐5 years old during biannual rounds, in collaboration with ICDS.

55
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 59 -->

Annexure 3. Agenda for state workshop for Mission Indradhanush
Training materials: Copy of operational guidelines including annexures for each participant
Duration: 1 day

Time

Session

Facilitator

Registration
Welcome and introduction
Introduction to Mission Indradhanush

State Immunization Officer

45 minutes
Remarks by partners
Remarks by Principal Secretary, Health
30 minutes

Overview of immunization programme at national
and state level

WHO India

Tea
1 hour

Operationalization of Mission Indradhanush
 RI microplanning
 Conducting head count and preparing due lists

WHO India

30 minutes

Organizing and conducting trainings

State Immunization Officer/WHO
India

15 minutes

Monitoring and supervision

WHO India

15 minutes

Discussion
Lunch

30 minutes

Exercise on reporting and recording

WHO India & ITSU

30 minutes

IEC, social mobilization and media interaction

UNICEF & ITSU

30 minutes

Adverse events following immunization

WHO India & ITSU

15 minutes

Discussion
Tea

45 minutes

Financial guidelines for Mission Indradhanush

State Immunization Officer

15 minutes

Way forward for Mission Indradhanush – Timeline
of activities and support available

Mission Director

Closing remarks

56
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 60 -->

Annexure 4a. Agenda for district workshop on Mission Indradhanush for medical
officers
Training materials: Copy of operational guidelines including annexures for each participant
Duration: 1 day

Time

Session

Facilitator

Registration
Welcome and introduction
Introduction to Mission Indradhanush

DIO

45 minutes
Remarks by partners
Remarks by District Magistrate
30 minutes

Overview of immunization programme at national
and state level
Tea

WHO India

1 hour

Micro planning for Mission Indradhanush

WHO India

30 minutes

Conducting head count and preparing due lists

DIO/WHO India

30 minutes

Organizing trainings

WHO India

15 minutes

Monitoring and supervision

WHO India

15 minutes

Discussion
Lunch

30 minutes

Exercise on recording and reporting

WHO India & ITSU

30 minutes

IEC, social mobilization and media interaction

UNICEF & ITSU

30 minutes

Adverse events following immunization

WHO India & ITSU

30 minutes

Frequently asked questions

DIO/WHO India

15 minutes

Discussion
Tea

45 minutes

Financial guidelines for Mission Indradhanush

District Accounts Manager/DIO

15 minutes

Way forward for Mission Indradhanush – Timeline of
activities and support available

District Magistrate

Closing remarks

57
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 61 -->

Annexure 4b. Agenda for district orientation of district and block level
programme/accounts managers on financial guidelines for Mission Indradhanush
Participants: District Programme Manager, District Accounts Manager, Block Programme Manager,
Block Accounts Manager and other related officials handling NHM funds
Training materials: Copy of operational guidelines including financial guidelines for each participant
Time: 1 hour

Time

Session

Facilitator

15 minutes

Introduction to Mission Indradhanush

DIO/Partners

30 minutes

15 minutes

Financial guidelines for Mission Indradhanush
 Existing norms
 Change in mode of payment from existing
norms
 Timeline for payments
Way forward for Mission Indradhanush – Timeline of
activities and support available

District Programme Manager
(NHM)/District Accounts Officer
(NHM)

DIO

Annexure 4c. Agenda for district workshop on Mission Indradhanush for data
handlers
Participants: District data handlers and one data handler from block and urban area responsible for
routine immunization data entry at these levels
Training material: Reporting formats for Mission Indradhanush
Duration: Half day

Time

Session

Facilitator

15 minutes

Introduction to Mission Indradhanush

DIO

30 minutes

Planning process and forms

DIO/Nodal officer for urban
area/Partners

15 minutes
45 minutes

15 minutes

Data flow from ANM to district for Mission
Indradhanush
Daily reporting process in Mission Indradhanush and
forms
Day‐wise key indicators generated through reported
data to be submitted to DIO during Mission
Indradhanush round

DIO/Partners
DIO

DIO/WHO India

30 minutes

Role of data handlers in Mission Indradhanush

DIO

15 minutes

Way forward for Mission Indradhanush – Timeline of
activities and support available

DIO

58
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 62 -->

Annexure 4d. Agenda for district workshop on Mission Indradhanush for vaccine
and cold chain handlers
Participants: One cold chain handler from each cold chain point
Training material: Vaccine and cold chain reporting format and open vial policy
Duration: Half day

Time

Session

Facilitator

15 minutes

Introduction to Mission Indradhanush

DIO

15 minutes

Planning process

DIO/Nodal officer for urban
area/Partners

30 minutes

Availability of vaccine and logistics
Issue and receipt of vaccine and logistics for Mission
Indradhanush

DIO/Partners

45 minutes

Planning for alternate vaccine delivery

DIO/Partners

15 minutes

Open vial policy

DIO/Partners

30 minutes

Role of cold chain handlers in Mission Indradhanush

DIO/Nodal officer for urban area

10 minutes
15 minutes

Day‐wise vaccine and diluent utilization report to be
submitted to DIO during Mission Indradhanush round
Way forward for Mission Indradhanush – Timeline of
activities and support available

DIO/Partners
DIO

59
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 63 -->

Annexure 5. Agenda for block/urban area training of health workers for Mission
Indradhanush
Time

Session

Facilitator

Welcome and introduction
15 minutes
Introduction to Mission Indradhanush

Medical Officer‐in charge

Tea
1 hour 30
minutes
15 minutes
15 minutes
10 minutes

Microplanning for Mission Indradhanush
Importance of head count for preparing due list of
beneficiaries
Use of immunization tracking bag and revised
counterfoil of MCP card
Discussion
Lunch

15 minutes

Reporting and recording

15 minutes

IEC and social mobilization

10 minutes

Open vial policy and implications for health workers

15 minutes

Adverse events following immunization

10 minutes

Discussion
Tea

15 minutes

Financial guidelines for Mission Indradhanush

15 minutes

Frequently asked questions

45 minutes

Preparing microplans – prioritizing areas for Mission
Indradhanush sessions

1 hour

Preparing ANM rosters for working in the block

10 minutes

What to do after this workshop: their role in
sensitizing the social mobilizers: ASHAs and AWWs

Medical Officer (trained for Mission
Indradhanush)
Medical Officer (trained for Mission
Indradhanush)
Medical Officer (trained for Mission
Indradhanush)

Block Data Manager

Medical Officer (trained for Mission
Indradhanush)
Medical Officer (trained for Mission
Indradhanush)

Block Accounts Manager

Group work
Medical Officer (trained for Mission
Indradhanush)
Medical Officer (trained for Mission
Indradhanush)

Wrap up

60
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 64 -->

Annexure 6. Agenda for block/urban area training of mobilizers(ASHAs/AWWs/link
workers) for Mission Indradhanush
Time

Session

Facilitator

Welcome and introduction
15 minutes
Introduction to Mission Indradhanush
15 minutes

Current immunization schedule

10 minutes

Conducting head count for preparing due list of
beneficiaries (exercise)
Use of immunization tracking bag and revised
counterfoil of MCP card
Discussion

15 minutes

Frequently asked questions

45 minutes

IEC and social mobilization (role play)

10 minutes

Discussion

10 minutes

What to do after this workshop

15 minutes
15 minutes

Medical Officer‐in charge
Medical Officer (trained for Mission
Indradhanush)
Medical Officer (trained for Mission
Indradhanush)
Medical Officer (trained for Mission
Indradhanush)

Block Community Mobilizer/Any
other official trained for Mission
Indradhanush
Medical Officer (trained for Mission
Indradhanush)

Tea and wrap up

61
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 65 -->

Annexure 7. Financial norms under Mission Indradhanush
For operational activities of routine immunization, funds are available under Part C of Programme
Implementation Plans (PIP) of the NHM. The same will be utilized to carry out operational activities
for Mission Indradhanush.
However, for some of the activities approved under Part C of PIP of immunization, flexibility has
been built in, so that we have greater participation of health workers for Mission Indradhanush.
The following norms remain the same as earlier:
Activity

Approved Norms under Part C routine immunization
(ROP) NHM

To develop sub‐centre and PHC microplans using
@ Rs 100 per sub‐centre (meeting at block level,
bottom up planning with participation of ANMs,
logistics)
ASHAs, AWWs
@ Rs 1000 per block and at district level @ Rs 2000
For consolidation of microplan at PHC/CHC level
per district
Hiring an ANM @ Rs 450 per session for 4
sessions/month/slum of 10 000 population and Rs
Focus on slum and underserved areas in urban
300 per month as contingency per slum, i.e., total
areas
expense of Rs 2100 per month per slum of 10 000
population
ASHA incentive for full immunization per child Rs 100 per child for full immunization in first year of
(up to 1 year of age )
age
ASHA incentive for full immunization per child up
to 2 years of age (all vaccination received Rs 50 per child for ensuring complete immunization
between first and second year of age after up to second year of age of child
completing full immunization at 1 year of age)
@ Rs 250 000 per district for district level officers
(this includes POL and maintenance) per year.
Supervisory visits by state and district level
(Districts need to provide a minimum of Rs 20 000 to
officers for monitoring and supervision of routine
each block for supervision of immunization activity
immunization
from block and PHC.)
By state level officers @ Rs 150 000 per year
Printing and dissemination of immunization
@ Rs 10 per beneficiary
cards, tally sheets, monitoring forms, etc.
Two‐day district level orientation training for
ANMs, multi‐purpose health workers (male),
As per revised norms for trainings under RCH
LHVs, health assistants (male/female) as per
reproductive and child health (RCH) norms
One‐day refresher training of district routine
immunization computer assistants on routine As per revised norms for trainings under RCH
immunization/HMIS and immunization formats
under NHM
Two days cold chain handlers’ training for block As per revised norms for trainings under RCH
level cold chain handlers by state and district
62
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 66 -->

cold chain officers and DIO for a batch of 15–20
trainees and three trainers
One‐day training of block‐level data handlers by
DIO and district cold chain officer to train about As per revised norms for trainings under RCH
the reporting formats of immunization and
NRHM
@ Rs 750 per PHC/CHC per year per district (Rs
Cold chain maintenance
15 000 per year)
POL for vaccine delivery from state to district and
Rs 150 000 per district/year
from district to PHCs/CHCs
Hard‐to‐reach areas
@ Rs 150 per routine
immunization session
Alternative vaccine delivery (AVD)
For routine immunization session in other areas @ Rs
75 per session
Red/black plastic bags, etc.
@ Rs 3/bag/session
Bleach/hypochlorite solution and twin bucket
Rs 1200 per PHC/CHC per year
Safety pits
Rs 5250/pit
Support for quarterly state level review meetings @ Rs 1250/participant/day for 3 persons
of district officers
(CMO/DIO/District Cold Chain Officer)
Quarterly review and feedback meeting
exclusively for routine immunization at district @ Rs 100 per participant for meeting expenses
level with one block MO, ICDS, CDPO and other (lunch, organizational expenses)
stakeholders
@ Rs 50 per participant as honorarium for ASHAs
Quarterly review meeting exclusive for routine (travel) and Rs 25 per person at the disposal of MO IC
immunization at block level
for meeting expenses(refreshments, stationery and
miscellaneous expenses)

Reflecting change in mode of payment from the existing norms:
Activity
Vaccinators and mobilizers

Existing Norms

Line listing of households
done twice a year at six‐ Rs 100 for ASHAs
month interval
Preparation of due list of
children to be immunized to
be updated on a monthly Rs 100 for ASHAs
basis

Mobilization of beneficiaries Rs 150 for ASHAs
to session sites

For Mission Indradhanush
For Mission Indradhanush, this amount may be
paid to the ASHA. If no ASHA is identified or
available, the same may be paid to the link
worker/AWW, subject to a total ceiling of Rs 100.
For Mission Indradhanush, this amount may be
paid to the ASHA. If no ASHA is identified or
available, the same may be paid to the AWW/link
worker subject to a total ceiling of Rs 100.
Two mobilizers will be present at each session
site (ASHA/AWW/link worker). Each mobilizer
may be paid Rs 75 with a maximum limit of Rs
150 per session site.
63

Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 67 -->

Annexure 8. Mission Indradhanush sub‐centre planning (Format 1)
(MO IC to ensure this format is filled for all sub‐centres including vacant sub‐centres)
Name of sub centre:_______________
Block:____________

S.
No

Name of
villages,
hamlet, slum,
migrant area,
etc.

Head
count
done
(Y/N)

Population based
on head count
(Write NA if head
count not done)
0–2
years

Pregnant
women

Do you
require
additional
immunization
session/s to
cover this
area (Yes/ No)

If yes,
number of
immunization
sessions
required

For ANM
Name & mobile number of ANM:__________________
Mention reason
for additional
session*
(Write code)
1/2/3/4/5/6

Location of session
site(s) for additional
session(s)

Name, designation & mobile no of
mobilizers only for areas requiring
immunization sessions (write name of
ASHA, AWW/link worker)

1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
*Code: 1. Vacant sub‐centre; 2. Areas where last three routine immunization sessions not held; 3. Polio high‐risk areas; 4. Areas with low routine immunization coverage, identified
through measles outbreaks or cases of diphtheria/neonatal tetanus in last 2 years; 5. Small villages, hamlets, etc. not having independent routine immunization sessions; 6. Others
Signature of ANM

64
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 68 -->

Annexure 9. Mission Indradhanush: Block/urban area planning (Format 2)
(Compile information from Planning Format 1)
Name of Block:_____________________

Number of sub‐centres:______
Population based on
head count (Write NA

S.
No

Name of
sub‐
centre

Name of areas
requiring
additional
Indradhanush
session(s)

if head count not done)

Head
count
done
(Y/N)

0–2 years

Pregnant
women

No of
immunizati
on sessions
required

For Block/urban planning unit

Number of ANMs:__________ Number of vacant sub‐centres:________

Mention
reason for
additional
session*
(Write code)
1/2/3/4/5/6

If mobile
session, write
“mobile”. For
other sessions,
mention
location of
session site(s).

Name,
designation &
mobile no of
mobilizers
(ASHA, AWW/ link
worker)

Which ANM will conduct
immunization session in
this area
ANM
of
same
sub‐
centr
e

ANM
of
other
sub‐
centre
from
same
block

ANM
from
outsid
e
block

Hired
ANM

1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
1.
2.
1.
2.

* Code: 1. Vacant sub‐centre; 2. Areas where last three routine immunization sessions not held; 3. Polio high‐risk areas; 4. Areas with low routine immunization coverage, identified
through measles outbreaks or cases of diphtheria/ neonatal tetanus in last 2 years; 5. Small villages, hamlets, etc. not having independent routine immunization sessions; 6. Others
Signature of Block MO IC

65
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 69 -->

Round I/II/III/IV

Annexure 10. ANM micro plan roster for Mission Indradhanush (Format 3)

For ANM

(One format for each ANM in the district)

District___________________ Block/ planning unit: ________________________ AEFI management centre name & Tel no: ______________
MO IC (name & mobile): _________________________________ Supervisor (name & mobile): _____________________________________
ANM (name & mobile): ________________________________________ Sub‐centre of ANM _______________________________________
Description of areas selected for Indradhanush session (exclude Sundays and other govt. holidays)
Day 1

Day 2

Day 3

Day 4

Day 5

Day 6

Day 7

Yes / No

Yes / No

Yes / No

Yes / No

Yes / No

Yes / No

Yes / No

Village/ urban area
Sub‐centre
Block & planning unit
Reasons for area selection*
Session site address & timing
Name & Tel no of mobilizer
Designation of mobilizer
Name & Tel no of AVD person
Name of influencer
Estimated 0–2 years beneficiaries
Estimated pregnant women
Estimation based on head counts

* Code: 1. Vacant sub‐centre; 2. Areas where last three routine immunization sessions not held; 3. Polio high‐risk areas; 4. Areas with low routine immunization coverage,
identified through measles outbreaks or cases of diphtheria/ neonatal tetanus in last 2 years; 5. Small villages, hamlets, etc. not having independent routine immunization
sessions; 6. Others
Signature of ANM

Signature of MOIC

Signature of District Immunization Officer

66
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 70 -->

For Block

Annexure 11. Mobile team planning for Mission Indradhanush
(Round I/II/III/IV)
(One format for each mobile team)

District: _________________ Block/planning unit: _____________________
AEFI management centre name & Tel no: ______________________________
Name and mobile no. of MOIC _________________ Supervisor_______________________
ANM_______________________

Day

Vehicle details

1

Site 1

Site 2

Site 3

Site 4

Timing of visit
Name of mobilizer
No. of 0–2 year old children
Name of influencer
No. of pregnant women
Timing of visit
Name of mobilizer
No. of 0–2 year old children
Name of influencer
No. of pregnant women
Timing of visit
Name of mobilizer
Name of influencer
No. of 0–2 year old children
No. of pregnant women
Timing of visit
Name of mobilizer
Name of influencer
No. of 0–2 year old children
No. of pregnant women
Timing of visit
Name of mobilizer
Name of influencer
No. of 0–2 year old children
No. of pregnant women
Timing of visit
Name of mobilizer
Name of influencer
No. of 0–2 year old children
No. of pregnant women
Timing of visit
Name of mobilizer
Name of influencer
No. of 0–2 year old children
No. of pregnant women

2

3

4

5

6

7

Signature of ANM

Signature of DIO

Signature of MOIC
67

Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 71 -->

Annexure 12. Mission Indradhanush: District planning
District:

For DIO

Name of DIO:
Available ANM days utilized

S.No

Name of
block/urban
area

Number
of
ANMs

ANM
days
No. of
available ANM days
required
for
Indradha based on
nush
microplan
(ANM*7)

Within
ANM’s own
sub‐centres

In other
sub‐
centres
within
same block

For
supporting
activity
outside
block

Additional ANM
days required
(need based)
from other
blocks for
conducting
Mission
Indradhanush
sessions

Signature of DIO
68
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization

<!-- page 72 -->

Total
FULL IMUNIZATION ACHIEVED
Male

Total Children vaccinated
Female

9-11 months
12-23 months

Children vaccinated for the first time in life
0-11 months
12-23 months

AD Syringes 0.1ml used
AD Syringes 0.5ml used
5ml Reconstitution Syringes used
Total no. of ORS distributed
Total no. of Zinc Tablets distributed

Prepare two copies of this form (1 for ANM and other to be submitted at the block/Planning unit in the evening)






Signature of ANM

Children less than 1 year should not be given DPT1/Hep B-1, start schedule with pentavalent vaccine only.
Children who have already received Hep B-1 should be given Hep B-2 & Hep B-3 dose, only if the child coming to session site is under one year of age. Hep-B is not to be given beyond one year of age.
69
Children who have already received DPT-1 should be given subsequent doses within or over one year of age as per recommended guidelines.
Children more than 1 year of age coming to session site for the first time (without any vaccination) should be given DPT and not pentavalent vaccine. Other missed vaccination should be given as per guidelines.
Identify,
mobilize,
vaccinate
achieve
full immunization
As per guidelines, subsequent doses of Pentavalent vaccine can be given to a child more than one Mission
year onlyIndradhanush:
if the child has started
withenlist,
Pentavalent
vaccination
withinand
onetrack
year. to
Give
subsequent
dose in the
next possible contact. Do not start Pentavalent vaccination beyond one year of age.

DPT-B
(5-6 years)

Vit A-2

JE-2

Measles2

DPT- B

Vit A-1

JE-1

Measles1

IPV

RVV-3

Penta-3

Hep B-3

*DPT-3

OPV-3

RVV-2

Penta 2

Hep B-2

*DPT- 2

OPV -2

RVV-1

Penta 1

*Hep B-1

*DPT-1

OPV-1

CROSS THE BOX
FOR EACH VACCINE
GIVEN TO THE
BENEFICIARY

Complete
immunization
achieved (Y/N)

Session site address:

OPV-B

Village:

CROSS THE BOX FOR EACH VACCINE GIVEN TO THE BENEFICIARY

BCG

TT- B

TT-2

TT-1

Sex

Father/
husban
d name

Whether child
vaccinated for the
first time in life

Name of
beneficiary

Pregnant
Women

For ANM

Round: I / II / III / IV Date of Activity ______________

Sub center:
Name of mobilizer(s):

Age

S. No

Block/ planning unit:
Name of ANM:

Full immunization
achieved (Y/N)

Annexure 13a: Tally sheet for Mission Indradhanush session

<!-- page 73 -->

Annexure 13b: Tally sheet for Mission Indradhanush session for 8 states (Odisha, Maharashtra, Tamil Nadu, Telangana, Karnataka, Kerala, Puducherry & Andhra Pradesh)
Round: I / II / III / IV Date of Activity ______________
For ANM

Total
FULL IMUNIZATION ACHIEVED
Male

Total Children vaccinated
Female

9-11 months
12-23 months

Children vaccinated for the first time in life

AD Syringes 0.1ml used
AD Syringes 0.5ml used
5ml Reconstitution Syringes used
Total no. of ORS distributed

0-11 months
12-23 months

Total no. of Zinc Tablets distributed

Prepare two copies of this form (1 for ANM and other to be submitted at the Block/Planning unit in the evening)






Signature of ANM

Children less than 1 year should not be given DPT1/Hep B-1, start schedule with pentavalent vaccine only.
70
Children who have already received Hep B-1 should be given Hep B-2 & Hep B-3 dose, only if the child coming to session site is under one year of age. Hep-B is not to be given beyond one year of age.
Children who have already received DPT-1 should be given subsequent doses within or over one year of age as per recommended guidelines.
Children more than 1 year of age coming to session site for the first time (without any vaccination) should
beIndradhanush:
given DPT and not
pentavalent
vaccine.
Other
missed vaccination
be given
per guidelines.
Mission
Identify,
enlist,
mobilize,
vaccinate
and trackshould
to achieve
fullasimmunization
As per guidelines, subsequent doses of Pentavalent vaccine can be given to a child more than one year only if the child has started with Pentavalent vaccination within one year. Give subsequent dose in the
next possible contact. Do not start Pentavalent vaccination beyond one year of age.

DPT-B
(5-6 years)

Vit A-2

JE-2

Measles2

DPT- B

OPV-B

Vit A-1

JE-1

Measles1

IPV-2

RVV-3

Penta-3

Hep B-3

*DPT-3

OPV-3

RVV-2

Penta 2

Hep B-2

*DPT- 2

OPV -2

IPV-1

RVV-1

Penta 1

*Hep B-1

*DPT-1

OPV-1

BCG

CROSS THE BOX
FOR EACH VACCINE
GIVEN TO THE
BENEFICIARY

Complete
immunization
achieved (Y/N)

Session site address:

Full immunization
achieved (Y/N)

Village:

CROSS THE BOX FOR EACH VACCINE GIVEN TO THE BENEFICIARY

TT- B

TT-2

Pregnant
Women

TT-1

Sex

Father/
husband
name

Whether child
vaccinated for the first
time in life

Name of
beneficiary

Sub center:
Name of mobilizer(s):

Age

S. No

Block/ planning unit:
Name of ANM:

<!-- page 74 -->

Annexure 14a: Block daily reporting format for Mission Indradhanush Date of activity:

No. of Zinc tablets distributed

DPT-B(5-6 years)

No. of ORS distributed

Complete immunization achieved

Vit A-2

JE-2

Measles2

DPT- B

Female

12 23
mont
hs

Record number of
vaccinations

OPV-B

9 - 11
mont
hs

Male

Male
Vit A-1

JE-1

Measles1

Female

Full
immunization
achieved

IPV

RVV 3

Penta 3

*Hep B-3

DPT-3

OPV3

RVV 2

Penta 2

*Hep B-2

DPT-2

OPV 2

RVV1

Penta 1

*Hep B-1

DPT-1

OPV1

For Block

I / II / III / IV

Record number of vaccinations for each antigen

BCG

TT- B

TT-2

Pregnant
female

TT-1

12 - 23 mo

Session
site
address

No. of
childre
n
vaccina
ted for
the first
time in
life
0 - 11 mo

Name
of ANM

Round:

No. of children vaccinated

S. No

Block/ planning unit:

______________

Grand
Total

Signature of I/C Block Medical Officer






Children less than 1 year should not be given DPT1/Hep B-1, start schedule with pentavalent vaccine only.
Children who have already received Hep B-1 should be given Hep B-2 & Hep B-3 dose, only if the child coming to session site is under one year of age. Hep-B is not to be given beyond one year of age. 71
Children who have already received DPT-1 should be given subsequent doses within or over one year of age as per recommended guidelines.
Children more than 1 year of age coming to session site for the first time (without any vaccination) should be given DPT and not pentavalent vaccine. Other missed vaccination should be given as per
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization
guidelines.
As per guidelines, subsequent doses of Pentavalent vaccine can be given to a child more than one year only if the child has started with Pentavalent vaccination within one year. Give subsequent dose in
the next possible contact. Do not start Pentavalent vaccination beyond one year of age.

<!-- page 75 -->

Annexure 14b: Block daily reporting format for Mission Indradhanush for 8 states (Odisha, Maharashtra, Tamil Nadu, Telangana,
Karnataka, Kerala, Puducherry and Andhra Pradesh)
Date of activity: ______________
For Block

Grand
Total

Signature of I/C Block Medical Officer






Children less than 1 year should not be given DPT1/Hep B-1, start schedule with pentavalent vaccine only.
Children who have already received Hep B-1 should be given Hep B-2 & Hep B-3 dose, only if the child coming to session site is under one year of age. Hep-B is not to be given beyond one year of age. 72
Children who have already received DPT-1 should be given subsequent doses within or over one year of age as per recommended guidelines.
Children more than 1 year of age coming to session site for the first time (without any vaccination)
should be
given DPT andIdentify,
not pentavalent
Other
missed and
vaccination
should
be given
as per
Mission
Indradhanush:
enlist, vaccine.
mobilize,
vaccinate
track to
achieve
full immunization
guidelines.
As per guidelines, subsequent doses of Pentavalent vaccine can be given to a child more than one year only if the child has started with Pentavalent vaccination within one year. Give subsequent dose in
the next possible contact. Do not start Pentavalent vaccination beyond one year of age.

No. of Zinc tablets distributed

DPT-B(5-6 years)

Vit A-2

JE-2

Measles2

DPT- B

OPV-B

Female

12 - 23
month
s

Record number of
vaccinations

No. of ORS distributed

9 - 11
mont
hs

Male

Male
Vit A-1

JE-1

Measles1

IPV-2

RVV 3

Penta 3

*Hep B-3

DPT-3

OPV3

RVV 2

Penta 2

*Hep B-2

DPT-2

OPV 2

IPV-1

RVV1

Penta 1

*Hep B-1

DPT-1

OPV1

Female

Full
immunization
achieved

Complete immunization achieved

I / II / III / IV

Record number of vaccinations for each antigen

BCG

TT- B

TT-2

Pregnant
female

TT-1

No. of
childr
en
vacci
nated
for
the
first
time
in life
12 - 23 mo

Sessio
n site
addre
ss

Round:

0 - 11 mo

Name
of
ANM

No. of children vaccinated

S. No

Block/ planning unit:

<!-- page 76 -->

Annexure 15a: District daily reporting format for Mission Indradhanush Date of activity:

No. of Zinc tablets distributed

No. of ORS distributed

DPT-B(5-6 years)

Vit A-2

Complete immunization
achieved

JE-2

Measles2

DPT- B

12 23
mont
hs

Record number of
vaccinations

OPV-B

Female

Male
Vit A-1

JE-1

Measles1

IPV

RVV 3

Penta 3

*Hep B-3

DPT-3

OPV3

RVV 2

Penta 2

*Hep B-2

DPT-2

OPV 2

RVV1

Penta 1

DPT-1

OPV1

*Hep B-1

9 - 11
mont
hs

Male

Full
immunization
achieved

Record number of vaccinations for each antigen

BCG

TT- B

TT-2

Pregnant
female

TT-1

12 - 23 mo

0 - 11 mo

No. of
children
vaccina
ted for
the first
time in
life

For District

I / II / III / IV

Female

Round:
No. of children vaccinated

Block
name

No of sessions held

S. No

District name:

_____________

Grand
Total

Signature of Chief Medical Officer






Children less than 1 year should not be given DPT1/Hep B-1, start schedule with pentavalent vaccine only.
Children who have already received Hep B-1 should be given Hep B-2 & Hep B-3 dose, only if the child coming to session site is under one year of age. Hep-B is not to be given beyond one year of age.
Children who have already received DPT-1 should be given subsequent doses within or over one year of age as per recommended guidelines.
73
Children more than 1 year of age coming to session site for the first time (without any vaccination) should be given DPT and not pentavalent vaccine. Other missed vaccination should be given as per
guidelines.
As per guidelines, subsequent doses of Pentavalent vaccine can be given to a child more than one
year only
if the child has Identify,
started with
Pentavalent
vaccination
within
year.
subsequent
dose in the
Mission
Indradhanush:
enlist,
mobilize,
vaccinate
andone
track
toGive
achieve
full immunization
next possible contact. Do not start Pentavalent vaccination beyond one year of age.

<!-- page 77 -->

Annexure 15b: District daily reporting format for Mission Indradhanush for 8 states (Odisha, Maharashtra, Tamil Nadu, Telangana,
Karnataka, Kerala, Puducherry & Andhra Pradesh)
Date of activity: _____________
For District
No. of Zinc tablets distributed

No. of ORS distributed

DPT-B(5-6 years)

Vit A-2

Complete immunization
achieved

JE-2

Measles2

DPT- B

12 23
mont
hs

Record number of
vaccinations

OPV-B

Female

Male
Vit A-1

JE-1

Measles1

IPV-2

RVV 3

Penta 3

*Hep B-3

DPT-3

OPV3

RVV 2

Penta 2

*Hep B-2

DPT-2

OPV 2

IPV-1

RVV1

Penta 1

DPT-1

OPV1

*Hep B-1

9 - 11
mont
hs

Male

Full
immunization
achieved

Record number of vaccinations for each antigen

BCG

TT- B

TT-2

Pregnant
female

TT-1

12 - 23 mo

0 - 11 mo

No. of
childre
n
vaccina
ted for
the first
time in
life

I / II / III / IV

Female

Round:
No. of children vaccinated

Block
name

No of sessions held

S. No

District name:

Grand
Total

Signature of Chief Medical Officer







Children less than 1 year should not be given DPT1/Hep B-1, start schedule with pentavalent vaccine only.
Children who have already received Hep B-1 should be given Hep B-2 & Hep B-3 dose, only if the child coming to session site is under one year of age. Hep-B is not to be given beyond one year of age.
74
Children who have already received DPT-1 should be given subsequent doses within or over one year of age as per recommended guidelines.
Children more than 1 year of age coming to session site for the first time (without any vaccination) should be given DPT and not pentavalent vaccine. Other missed vaccination should be given as per
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization
guidelines.
As per guidelines, subsequent doses of Pentavalent vaccine can be given to a child more than one year only if the child has started with Pentavalent vaccination within one year. Give subsequent dose in the
next possible contact. Do not start Pentavalent vaccination beyond one year of age.

<!-- page 78 -->

Annexure 16a: State daily reporting format for Mission Indradhanush

Date of activity___________________

Grand
Total

Signature of State Immunization Officer






Children less than 1 year should not be given DPT1/Hep B-1, start schedule with pentavalent vaccine only.
Children who have already received Hep B-1 should be given Hep B-2 & Hep B-3 dose, only if the child coming to session site is under one year of age. Hep-B is not to be given beyond one year of age.
Children who have already received DPT-1 should be given subsequent doses within or over one year of age as per recommended guidelines.
75
Children more than 1 year of age coming to session site for the first time (without any vaccination) should be given DPT and not pentavalent vaccine. Other missed vaccination should be given as per
guidelines.
Identify,
mobilize,
vaccinate
and
track
achieve
full immunization
As per guidelines, subsequent doses of Pentavalent vaccine can be given to a child more than oneMission
year onlyIndradhanush:
if the child has started
withenlist,
Pentavalent
vaccination
within
one
year.to
Give
subsequent
dose in the
next possible contact. Do not start Pentavalent vaccination beyond one year of age.

No. of Zinc tablets distributed

No. of ORS distributed

DPT-B(5-6 years)

Vit A-2

JE-2

Measles2

DPT- B

Female

12 - 23
month
s

Record number of
vaccinations

OPV-B

9 - 11
month
s

Male

Male
Vit A-1

JE-1

Measles1

IPV

RVV 3

Penta 3

*Hep B-3

DPT-3

OPV3

RVV 2

Penta 2

*Hep B-2

DPT-2

OPV 2

RVV1

Penta 1

*Hep B-1

DPT-1

OPV1

Female

Full
immunization
achieved

Complete immunization
achieved

I / II / III / IV

Record number of vaccinations for each antigen

BCG

TT- B

TT-2

Pregnant
female

TT-1

12 - 23 mo

No. of
children
vaccinat
ed for
the first
time in
life
0 - 11 mo

No. of children vaccinated

District
name

Round:

No of sessions held

S. No

State name:

For State

<!-- page 79 -->

Annexure 16b: State daily reporting format for Mission Indradhanush for 8 states (Odisha, Maharashtra, Tamil Nadu,Telangana, Karnataka, Kerala,
Puducherry & Andhra Pradesh)
Date of activity___________________
For State

Grand
Total

Signature of State Immunization Officer






Children less than 1 year should not be given DPT1/Hep B-1, start schedule with pentavalent vaccine only.
Children who have already received Hep B-1 should be given Hep B-2 & Hep B-3 dose, only if the child coming to session site is under one year of age. Hep-B is not to be given beyond one year of age.
76
Children who have already received DPT-1 should be given subsequent doses within or over one year of age as per recommended guidelines.
Children more than 1 year of age coming to session site for the first time (without any vaccination) should be given DPT and not pentavalent vaccine. Other missed vaccination should be given as per
guidelines.
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization
As per guidelines, subsequent doses of Pentavalent vaccine can be given to a child more than one year only if the child has started with Pentavalent vaccination within one year. Give subsequent dose in the
next possible contact. Do not start Pentavalent vaccination beyond one year of age.

No. of Zinc tablets distributed

No. of ORS distributed

DPT-B(5-6 years)

Vit A-2

JE-2

Measles2

DPT- B

Female

12 23
month
s

Record number of
vaccinations

OPV-B

9 - 11
month
s

Male

Male
Vit A-1

JE-1

Measles1

IPV-2

RVV 3

Penta 3

*Hep B-3

DPT-3

OPV3

RVV 2

Penta 2

*Hep B-2

DPT-2

OPV 2

IPV-1

RVV1

Penta 1

*Hep B-1

DPT-1

OPV1

Female

Full
immunization
achieved

Complete immunization
achieved

I / II / III / IV

Record number of vaccinations for each antigen

BCG

TT- B

TT-2

Pregnant
female

TT-1

12 - 23 mo

No. of
children
vaccinat
ed for
the first
time in
life
0 - 11 mo

No. of children vaccinated

District
name

Round:

No of sessions held

S. No

State name:

<!-- page 80 -->

Annexure 17. Daily vaccine and diluents utilization reporting format

For Vaccine and Cold Chain Handlers

State / District / Block / Urban Area (encircle the applicable option)

Day

BCG

BCG
Dilue
nt

OPV

DPT

HepB

Penta

RVV

IPV

Measles

Measles
Diluent

TT

JE

JE
Diluent

Vit A

AD
Syring
es
0.1ml

AD
Syring
es
0.5ml

5ml
Reconst
‐itution
Syringes

Day 1
Day 2
Day 3
Day 4
Day 5
Day 6
Day 7
Day 8
Day 9
Day 10

Signature of MOIC

Name and signature of cold chain handler
77
Mission Indradhanush: Identify, enlist, mobilize, vaccinate and track to achieve full immunization
