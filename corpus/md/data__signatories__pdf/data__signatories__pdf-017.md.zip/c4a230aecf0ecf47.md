---
doc_id: "c4a230aecf0ecf47"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/a2edac865cc3c7c7a2a5bcabeef6a2e9.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Year wise and Statewise Breakup of Industrial Entrepreneurs Memorandum Filed"
date: "2012-09-30"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e2d39bcc946337cc"
---

<!-- page 1 -->

1.5 YEARWISE AND STATEWISE BREAKUP OF INDUSTRIAL ENTREPRENURS MEMORANDUM FILED
Name of the State

2008

2009

Andaman & Nicobar

1

Proposed
Investment
(Rs.Cr)
123

Andhra Pradesh
Arunachal Pradesh

377
7

132005
147

313
4

Assam
Bihar

32
29

7428
13577

Chandigarh
Chhattisgarh
Dadra & Nagar
Haveli

0
285

2010

1

Proposed
Investment
(Rs.Cr)
13

Proposed
Investment
(Rs.Cr)

2012(Aug)

0

0

0

0

0

2

104951
1303

175608
848

388
7

103826
1027

230
3

57875
41

1817
26

574265
3366

45
32

2860
13710

8423
65190

32
31

1231
44026

20
14

1039
2035

166
152

20981
138538

0
221863

0
293

0
130630

0
285583

1
114

10
102266

1
63

22
75042

2
1011

32
815384

40

1791

50

1709

11148

55

3885

23

3524

231

22057

Daman & Diu
Delhi

45
12

967
59

39
21

858
289

598
130

21
12

665
68

4
3

19
14

144
67

3107
560

Goa
Gujarat

37
361

1000
125357

46
376

1382
142239

2441
147152

23
541

563
141116

14
325

281
102785

159
2099

5667
658649

Haryana
Himachal Pradesh
Jammu & Kashmir

122
39
29

6429
3972
1115

85
41
23

2423
6065
1223

10309
3568
1234

112
36
21

8660
1533
1523

81
38
22

4443
4539
1293

536
207
118

32264
19677
6388

Jharkhand
Karnataka

74
194

142702
142218

65
179

79502
92054

41549
139218

25
214

3198
94082

16
111

8174
24838

233
959

275125
492410

Kerala
Lakshadweep

15
0

269
0

8
0

171
0

99
0

12
0

3984
0

3
0

0
0

46
0

4523
0

Madhya Pradesh
Maharashtra

305
705

199116
92257

182
593

66669
68069

204286
176194

191
973

104527
133596

84
369

6081
62261

988
3397

580679
532377

Numbers
Filed

Proposed
Investment
(Rs.Cr)

Total

Proposed
Investment
(Rs.Cr)
136

Numbers
Filed

Numbers
Filed

2011

Numbers
Filed

Proposed
Investment
(Rs.Cr)

Numbers
Filed

Manipur

0

0

0

0

0

1

13

1

68

3

81

Meghalaya
Mizoram

18
0

2587
0

10
0

970
0

1733
0

6
1

2574
27

3
0

1807
0

51
1

9671
27

Nagaland
Orissa

0
160

0
253201

0
99

0
167932

0
315772

1
117

38
321032

0
46

0
60417

1
601

38
1118354

Pondicherry
Punjab

24
91

1020
9127

14
68

712
9731

282
6779

8
112

44
13571

3
58

87
2913

63
431

2145
42121

Rajasthan
Sikkim
Tamil Nadu

102
13
289

21899
575
24145

88
8
233

13461
150
66864

29669
795
38587

165
15
255

23488
727
73298

133
7
143

14827
167
17433

610
56
1154

103344
2414
220327

3

68

2

18

3

71

1

5

10

Tripura

<!-- page 2 -->

Tripura

3

68

2

3

71

1

5

10

199
148

16480
6069

176
165

83
10142
9293

18

Uttar Pradesh
Uttarakhand

13756
7997

163
77

43672
6854

95
35

11037
1234

801
642

245
95087
31447

West Bengal
Total

223
3979

95000
1522566

206
3465

44390
1039848

42765
1731731

135
3868

302515
1537710

64
2013

4687
468988

837
17621

489357
6300843
