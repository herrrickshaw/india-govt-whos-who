---
doc_id: "c3bbca56cbbe36ff"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/c0de3cb1bf70b83e8c7ecd15166ed83b.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS Comm no. 837 of 2024: DoT instructions to ISPs dated 25.03.2025"
date: "2025-03-25"
pages: 69
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d9c090260cdd3ca3"
---

<!-- page 1 -->

813-7/25/2024-DS

I/3262381/2025

By Email/DoT Website
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Service Cell)

No. 813-07/LM-39/2024-DS-II

Dated:25-03-2025

To,
All Licensees with Internet Service Authorization

Subject: CS (COMM) 837 of 2024: Star India Pvt. Ltd. Vs. MovieBlast
application and Ors. before the High Court of Delhi.

Kindly ﬁnd enclosed the Hon’ble Delhi High Court order dated26.09.2024
on the subject matter.
2. Please refer to Para 42 and 43 of the said Court order in respect of blocking of
domains/websites [5 nos] enumerated in Document A of the 30th to 34th
additional Aﬃdavits dated 24.03.2025 (1 website/domain in each Aﬃdavit) ﬁled by
the plaintiff.
3. In view of the above, all the Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action for blocking of the said
website, as above, for compliance of the said court order.
Encl: A/A

Director (DS-II)
Email: dirds2-dot@nic.in
Copy to:
i. Sh. V. Chinnasamy, Scientist E (chinnasamy.v@meity.gov.in), Electronics
Niketan, Ministry of Electronics and Information Technology (MeitY) New
Delhi for kind information and with request to take action as per
the Annexure.
ii. Sh. Vivek Kumar <v.kumar@saikrishnaassociates.com> Plaintiﬀ's Counsel
for kind information and requested to take action as per the Annexure.
iii. IT Wing of DoT for uploading this order on DoT websites please.

<!-- page 2 -->

IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
Star India Pvt. Ltd.

.…Plaintiff
versus

MovieBlast Application and Ors.

…Defendants

INDEX
S.
PARTICULARS
NO.
1. Affidavit of Mr. Hitender Adlakha dated 24th
March 2025 with respect to additional list of
Source Domain(s) / Website (s) / URL (s) that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
2. Annexure A: Additional list of Source
Domain (s) / Website (s) / URL
3. Evidence with respect to additional list
Source Domain (s) / Website (s) / URL that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
4. Proof of Service

Place: New Delhi
Date: 24.03.2025

PAGE
NO

1-11

12

13-32

Vivek Kumar
(D/7260/2023)
Saikrishna and Associates
Advocates for the Plaintiff
57, Jor Bagh,
New Delhi – 110003

<!-- page 3 -->

1
IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024

IN THE MATTER OF:

Star India Pvt. Ltd.

.... Plaintiff

versus

MovieBlast Application and Ors.

. .. Defendants

-....AFFIDAVIT OF MR. HITENDER ADLAKHA, S/0 SH. LATE

A "'< A

R.

"t.A\ZP..Np,rf\~
p.dv~ca;.~

''

(
-k P.e7 " :.: ' -~~ ,.-,!-.
t ,.
.l
r ' \ 1t . •'.:;...'
' . \ ? . .... . Cit-"~
' ~
..

.., "~

~., .

-

L.

ADLAKHA,

AGED

53

YEARS,

AUTHORISED

.. p

ESENTATIVE OF PLAINTIFF, STAR INDIA PVT. LTD.

V

G OFFICE AT STAR HOUSE, URMI ESTATE, 95

-1c
I

ATRAO

KADAM MARG,

LOWER PAREL

(W),

/~MBAI 400013, PRESENTLY AT NEW DELHI, INDIA, ON
BEHALF OF THE PLAINTIFF

I, the above-named deponent, do hereby solemnly affirm and
declare as under:
1. That, I am the Authorized Representative of the Plaintiff in the
present suit and as such I am conversant with the facts and
circumstances of the present suit and competent to depose in
respect thereof.

<!-- page 4 -->

2
2. I state that I am aware of the present suit and the order dated
26.09.2024 whereby the Hon'ble Court was pleased to pass
an ex-parte ad-interim order in terms of the following:

"38. In view of the averments noted hereinabove and in
view of the judgment passed in UTV Software
Communication Ltd. (supra), this Court is of the opinion
that a prima facie case is made out in favour of the
plaintiff Balance of convenience is also in favour of the
plaintiff Further, irreparable harm or injury would be
caused to the plaintiff if an interim injunction order is not
passed.
).:. 39. Accordingly defendants No. 1 to 3 (and an such other
+.Uls/websites which appears to be associated with any of
ReJ ;:. : " 1539
'tl,1e defendant apps and websites based on its name,
'
., •
·. 1
1
. ., .,1
>.nJ24
b'randing or the identity of its operator, or discovered to
~
--·~
\J.~
to l i: \3/:LJL!:l
provide additional means ofaccessing, the defendant apps
OJ ;~
and websites, and other domainsldomain/apps/Uls along
~
with their sub domains and subdirectories, owners/website
operators/entities which are discovered to have been
engaging in infringing the plaintiff's exclusive rights),
their owners, partners, proprietors, officers, servants,
employees, and all others in capacity of principals or
agents, acting for and on their behalf, or anyone claiming
through, by or under them are hereby restrained, from, in
any manner hosting, streaming, reproducing, distributing,
making available to the public and/or communicating to
the public, or facilitating the same, on their
Apps/Ulslwebsites, through the internet in any manner
whatsoever,
any
cinematograph
work/content/programme/show in relation to which
plaintiff has a copyright.
ALAKA NAYAI<
t-~,dvo8ate

c

40. The defendants No.4 to 8 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
URLs and the respective U/s as filed along with the suit
(Pg 1 - Voll) (also annexed herewith as annexure- A) and
any other Uls/apps/websites notified by the plaintiff by
filing of an affidavit.

<!-- page 5 -->

3
41. The defendants no. 4 to 8, their directors, partners,
proprietors, officers, affiliates, servants, employees, and
all others in capacity ofprincipal or agent acting for and,
on their behalf, or anyone claiming through, by or under
it, are directed to disclose the following information of the
defendants no. 1 -3 (and any such other websites/Uls
which are discovered during the course ofthe proceedings
and notified on Affidavit by the plaintiff to have been
infringing/ authorizing the infringement of the plaintiff's
exclusive rights, copyrights and broadcast reproduction
rights):
A. Complete details (such as name, address, email
address, phone number, IP address etc.) of the
defendants no. 1 - 3 (and any such other websites/U!s
which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff
to have been infringing/ authorizing the infringement
ofthe plaintiff's exclusive rights, copyrights).
B. Mode ofpayment along with payment details used
for registration ofdomain name by the registrant i.e.,
defendant no. 1 - 3 (and any such other websites/Uls
which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff
to have been infringing/ authorizing the infringement
of the plaintiff's exclusive rights, copyrights).
42. The defendants No. 9 to 17 shall ensure compliance
with this order by blocking defendants no. 1 to 3 websites,
their URLs and the respective Uls as filed along with the
suit (Pg 1- Vol1) (also annexed herewith as annexure- A)
and any other apps/websites notified by the plaintiff by
filing of an affidavit.
43. Defendants no. 18 and 19 are further directed to take
immediate steps and issue requisite notifications within
five working days, calling upon various internet and
telecom service providers registered under them to block
the aforementioned websites/Uls identified by the
plaintiff. "

<!-- page 6 -->

4
3. I state that in order to protect and enforce its exclusive rights in
the Plaintiffs copyrighted content, including but not limited to
the content made available through the Plaintiffs STAR
Channels and Disney+Hotstar, the Plaintiff engaged the
services of an investigation agency, Copyright Integrity
International,

to

identify

and

monitor

other

domains/domain/apps/Uis along with their sub domains and
subdirectories, owners/website operators/entities which are
discovered to have been engaging in infringing the plaintiffs
exclusive rights (in terms of paragraph 39 and 40 of the
aforementioned order dated 26.09.2024) collaborating with the
1said App and/or the other Uis/apps identified in the instant suit
.li . .X~J

,./ ....·

./

~nd gather evidence of their infringing activity. I state that the
1

Source Domain (s) I Website (s) I URL (s) that have been
identified by the investigation agency engaged in illegally
communicating the Plaintiffs copyrighted content, including
but not limited to the content made available through the
Plaintiffs STAR Channels and Disney+Hotstar, through the
Rogue Apps which is annexed herewith Document A.

4. I state that the "HD Streamz" application has been identified
by the investigation agency as an Android-based mobile App
which is engaged in illegally communicating the Plaintiffs
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels. I state
that the 'Blink Streamz" App is ~m Android application that
unauthorizedly makes available for viewing and provides
access to the content shown on TV Channels including live
sporting events, inter alia ongoing IPL 2025 and other Video
on Demand content including that of the Plaintiffs.

<!-- page 7 -->

5
5. I state that the primary intent and purpose of the aforesaid "HD
Streamz" App is to exploit various copyright-protected works,
including but not limited to the Plaintiffs copyrighted content,
free of cost (or at minimal subscription) and without any
authorisation from the right owners including the Plaintiff. In
fact, the very intent of the said "HD Streamz" App is to provide
an alternative to legitimate sources to the user, so that a user
does not have to pay for enjoying the copyright-protected
works. Detailed allegations regarding the "rogue" nature of the
aforesaid App are provided hereinafter.

state that the step-by-step process for downloading the APK
fil for the "HD Streamz" App and running the said mobile App

g.u a computer has been detailed in the evidence filed herewith.

C .

~· I state that it is visible from the evidence filed herewith that the

said "HD Streamz" App (available on https://hdstreamzs.corn!)
is a Rogue App:
a. It is evident from the home page of the said App, "HD
Streamz" App that the primary purpose of this App is to
commit and facilitate copyright infringement, i.e., to
transmit, stream, download, communicate, issue copies
of, cause to be seen or heard by the public on payment
of charges, make available to the public and provide
access to copyright works of various right owners
including that of the Plaintiff, for free and without any
authorisation. The home page of the "HD Streamz" App
displays the said content available for illegal viewing
and streaming free of cost.

<!-- page 8 -->

6
b. "HD Streamz" App has been created as a vehicle of
infringement whose whole business model is designed to
provide members of the public access to copyright
content without authorization. From the evidence on
record, it is evident that the infringing content is made
available on "HD Streamz" App's platform in a
systematic, organised, and intentional manner with
Advocate
Reg. 1\Jo.: 10639

l

* regularity and consistency.

~ Po~{Y?.,~i;. ) The domain(s) through which "HD Streamz" App is
1·'}

--4 :,'

' . 0 - - ,/

being distributed and the domains where the illegal
content is being stored and hosted are all located at
unverifiable locations and no contact details are
available since the said details of the registrants are
masked and no presence or traceable detail is available
either of the creator I registrant.

d. The

"HD

Streamz"

App

provides

easy-to-use

directories, indexes and categories to infringing content
located on their servers for users to navigate and easily
find the said content. The said App has indexed content
under various categories, and also has sub-indexing I
sub-categorisation on the rogue App, through various
genres, etc. The "HD Streamz" App displays various
categories of content on its platform namely - Events,
Live TV etc. The "HD Streamz" hosts approximately
•'

multiple channels.
e. Disregard for copyright by the "HD Streamz" App is
evident from the fact that the said App generally

<!-- page 9 -->

7
provides content of various right owners, including the
Plaintiff without any authorisation.

8. I state that the ex parte ad interim injunction granted vide order
dated 26.09.2024 passed by this Hon'ble Court is applicable to
the aforesaid Rogue App, viz "HD Streamz" App, identified by
the Plaintiffs investigation agency (in terms of para 39 and 40
of the aforementioned order dated 26.09.2024). Accordingly,
the relief granted in terms of paras 3 9 and 40 of the
/'' ~ ~.--

T

4

-. ,~forementioned

order dated 26.09.2024 and the directions

,/ O
ued by the Hon'ble Court to Internet Service Providers (i.e.,
-4\
1* N~~~~~~~ efe~ dant Nos. 9 to 17) and to the DoT and MEITY (i.e.,
ALAKA NAYAK
Rea.

~ ?e/~~,;:
/ •..

9

r:;p;f

.e7dant Nos. 18 and 19) are applicable in relation to user

·· .. · "te rface (UI) domains I websites I URLs identified and

_.,/,.

~ · \ ·;:n otified by the Plaintiff to be infringing and/or authorising

infringement of the Plaintiffs Content through the Rogue "HD
Streamz" App.

9. In light of the above, I state that the following user interface
(UI) domains I websites has been identified by the investigation
agency as engaged in illegally communicating the Plaintiffs
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels,
through the aforesaid Rogue App, viz "HD Streamz" App:
D main I Website

S.

1.

https://global364-srv-prod-dc67ddb992f15dO.skycdn.me/

<!-- page 10 -->

8
1O.I state that from the evidence filed along with the present
Affidavit, it is evident that the above-mentioned UI domains/
websites are hosting and/or streaming and/or providing access
and/or making available for viewing the broadcast ofPlaintiff s
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels,
through the aforesaid Rogue App, viz "HD Streamz" App,

rogue UI domains I websites as either they are anonymous or
have incorrect or incomplete addresses.

12.1 state that the from the evidence filed along with the present
Affidavit, it is evident that the identified Source Domain (s) I
Website (s) I URL(s) is hosting and/or streaming and/or
providing access and/or making available for viewing the
broadcast of Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar. I state that the Plaintiff is the exclusive
right holders for Plaintiffs copyrighted content, including but
not limited to the content made available through the Plaintiffs
STAR Channels and Disney+Hotstar, for the worldwide
territory and the Plaintiff has not authorized the abovementioned websites to communicate and or make available for
viewing the Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar.

<!-- page 11 -->

9
13.1 state that the Plaintiff is not aware of the owner(s) of the
identified rogue Source Domain (s) I Website (s) I URL (s) as
either they are anonymous or have incorrect or incomplete
addresses.

14.1 state that in terms of the following directions passed by this
Hon'ble Court, vide order dated 26.09.2024 (reproduced herein
above) is also applicable on the Source Domain(s) I Website(s)
I URL(s) identified herewith.

40. The defendants No. 4 to 8 shall ensure compliance
with this order by blocking defendants no. 1 to 3
websites, their URLs and the respective Uls as filed
along with the suit (Pg 1 - Vol 1) (also annexed
\ herewith as annexure - A) and any other
fl d~~~~;;g 1c. Ulslapps/websites notified by the plaintiff by filing of
; ·~ ,:,~ 74 <!' n affidavit.
'
:. ,:;;) ,__~
\

"
\

y-C

l~; - ·

.. . .

v·· ............ .

...~;!

....~/
/

42. The defendants No. 9 to 17 shall ensure compliance
with this order by blocking defendants no. 1 to 3
websites, their URLs and the respective Uls as filed
along with the suit (Pg 1 - Vol 1) (also annexed
herewith as annexure -A) and any other apps/websites
notified by the plaintiff by filing of an affidavit.

15 .In light

of the

abovementioned,

the

Department of

Telecommunications (Defendant No. 18) and the Ministry of
Electronics and Information Technology (Defendant No. 19)
are urged to issue a notification to the Internet Service
Providers (Defendant Nos. 9- 17) to block the additional rogue
Source Domain I Website I URL identified in Document- A
hereto.

<!-- page 12 -->

10
16.1 state that the evidence filed along with the present affidavit
was shared by the investigating agency in google drive linlc I
downloaded the same onto the computer (Intel (R) Core (TM)
i5-2520M CPU @ G2010 @ 2.50 GHz 2.50 GHz) which is
regularly used by me in the ordinary course of business and
thereafter, shared the same with the Plaintiff's Counsel.
I

I
\

Appellate Division of High Courts Act, 2015 are complied with
in respect of these documents.

18.In particular, I confirm:a) That the said computer system is regularly used to produce
computer outputs like emails and information from the
World Wide Web (Internet) and store other electronic
records. The relevant information from the websites and
electronic records as mentioned above was downloaded by
me in the course of activity of the Plaintiff. I have a lawful
control over the use of the said computer system by virtue of
my capacity in the organization.

b) That the electronic records mentioned above are downloaded
from the computer system as part of the ordinary course of
activities of the Plaintiff.

<!-- page 13 -->

11

c) That the computer system as used by me has been operating
properly and the electronic records and their accuracy and
contents have not been altered and tampered with in any
manner whatsoever.

~1at the information contained on the computer outputs is

Verified at New Delhi on this the

of March 2025 that the

contents of the above said Affidavit are true to the best of
knowledge, information and belief and nothing material has been
concealed therefrom.
CFRTlFiED TH'~T THE DEP~
I-· n

~:- ;•<'r • 'K ~ Ll .- , - ~
,,dr.tv.nL.,
m .. f ')'CY7':(11-~~.:._· ··
.
S/o,W/o Rio ... ..... ..... ·v~

.... ...... ...... ... ... ..... ... ... ..... .. .

ldentif) , -, '·-::: "·': : ': ··
Has ~.

Dell,;i o.·\.,.. .

2 4 MAR

. ................. .

DE

<!-- page 14 -->

12
Document A: Additional list of Source Domains / Websites /
URLs

S. No.

Source Domain / Website /

Rogue App

URL
1.

https://global364-srv-prod-dc67ddb992f15d0.skycdn.me/

HD STREAMZ
(Proposed
Defendant No. 32)

<!-- page 15 -->

IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
.…Plaintiff
Star India Pvt. Ltd.
versus
…Defendants

MovieBlast Application and Ors.
INDEX
PARTICULARS

S.
NO.
1. Affidavit of Mr. Hitender Adlakha dated 24th
March 2025 with respect to additional list of
Source Domain(s) / Website (s) / URL (s) that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
2. Document A: Additional list of Source
Domain (s) / Website (s) / URL
3. Evidence with respect to additional list
Source Domain (s) / Website (s) / URL that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
4. Proof of Service

Place: New Delhi
Date: 24.03.2025

PAGE
NO

1-9

10

11-34

Vivek Kumar
(D/7260/2023)
Saikrishna and Associates
Advocates for the Plaintiff
57, Jor Bagh,
New Delhi – 110003

<!-- page 16 -->

1
IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
.... Plaintiff

Star India Pvt. Ltd.
versus
MovieBlast Application and Ors.

. .. Defendants

AFFIDAVIT OF MR. HITENDER ADLAKHA, S/0 SH. LATE
R.

L.

ADLAKHA,

AGED

53

YEARS,

AUTHORISED

REPRESENTATIVE OF PLAINTIFF, STAR INDIA PVT. LTD.
VING OFFICE AT STAR HOUSE, URMI ESTATE, 95
·,

ATRAO KADAM MARG, LOWER PAREL

(W),

NmAI 400013, PRESENTLY AT NEW DELHI, INDIA, ON

I, the above-named deponent, do hereby solemnly affirm and
declare as under:
1. That, I am the Authorized Representative of the Plaintiff in the
present suit and as such I am conversant with the facts and
circumstances of the present suit and competent to depose in
respect thereof.
2. I state that I am aware of the present suit and the order dated
26.09.2024 whereby the Hon'ble Court was pleased to pass
an ex-parte ad-interim order in terms of the following:
"38. In view of the averments noted hereinabove and in
view of the judgment passed in UTV Software

<!-- page 17 -->

2
Communication Ltd. (supra), this Court is of the opinion
that a prima facie case is made out in favour of the
plaintiff Balance of convenience is also in favour of the
plaintiff Further, irreparable harm or injury would be
caused to the plaintiff if an interim injunction order is not
passed.
39. Accordingly, defendants No. 1 to 3 (and any such other
Uls/websites which appears to be associated with any of
the defendant apps and websites based on its name,
branding or the identity of its operator, or discovered to
provide additional means ofaccessing, the defendant apps
and websites, and other domains/domain/apps/Uls along
with their sub domains and subdirectories, owners/website
operators/entities which are discovered to have been
engaging in infringing the plaintiff's exclusive rights),
their owners, partners, proprietors, officers, servants,
.. employees, and all others in capacity of principals or
.1- .\ agents, acting for and on their behalf, or anyone claiming
* \through, by or under them are hereby restrained, from, in
any manner hosting, streaming, reproducing, distributing,
making available to the public and/or communicating to
the public, or facilitating the same, on their
Apps/Uls/websites, through the internet in any manner
whatsoever,
any
cinematograph
work/content/programme/show m relation to which
plaintiff has a copyright.
40. The defendants No. 4 to 8 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
URLs and the respective Uls as filed along with the suit
(Pg 1- Vall) (also annexed herewith as annexure- A) and
any other Ulslapps/websites notified by the plaint(ff by
filing of an affidavit.
41. The defendants no. 4 to 8, their directors, partners,
proprietors, officers, affiliates, servants, employees, and
all others in capacity ofprincipal or agent acting for and,
on their behalf, or anyone claiming through, by or under
it, are directed to disclose the following information of the
defendants no. I -3 (and any such other websites/Uls
which are discovered during the course ofthe proceedings
and notified on Affidavit by the plaintiff to have been
infringing/ authorizing the infringement of the plaintiff's

<!-- page 18 -->

3
exclusive rights, copyrights and broadcast reproduction
rights):
A. Complete details (such as name, address, email
address, phone number, IP address etc.) of the
defendants no. 1 - 3 (and any such other websites/Uls
which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff
to have been infringing/ authorizing the infringement
of the plaintiff's exclusive rights, copyrights).

~

:;:1:'
1 1'""·~

Pc
{y ._J

B. Mode ofpayment along with payment details used
for registration ofdomain name by the registrant i.e.,
\ defendant no. 1-3 (and any such other websites/Uls
* )which are discovered during the course of the
/proceedings and notified on Affidavit by the plaintiff
to have been infringing/ authorizing the infringement
of the plaintiff's exclusive rights, copyrights).
42. The defendants No. 9 to 17 shall ensure compliance
with this order by blocking defendants no. 1 to 3 websites,
their URLs and the respective VIs as filed along with the
suit (Pg 1- Vall) (also annexed herewith as annexure- A)
and any other apps/websites notified by the plaintiff by
filing of an affidavit.
43. Defendants no. 18 and 19 are further directed to take
immediate steps and issue requisite notifications within
five working days, calling upon various internet and
telecom service providers registered under them to block
the aforementioned websites/Uls identified by the
plaintiff "
3. I state that in order to protect and enforce its exclusive rights in
the Plaintiffs copyrighted content, including but not limited to
the content made available through the Plaintiffs STAR
Channels and Disney+Hotstar, the Plaintiff engaged the
services of an investigation agency, Copyright Integrity
International,

to

identify

and

monitor

other

domains/domain/apps/Uls along with their sub domains and

<!-- page 19 -->

4
subdirectories, owners/website operators/entities which are
discovered to have been engaging in infringing the plaintiffs
exclusive rights (in terms of paragraph 39 and 40 of the
aforementioned order dated 26.09.2024) collaborating with the
said App and/or the other Uls/apps identified in the instant suit
and gather evidence of their infringing activity. I state that the
Source Domain (s) I Website (s) I URL (s) that have been
identified by the investigation agency engaged in illegally
communicating the Plaintiffs copyrighted content, including
but not limited to the content made available through the
Plaintiffs STAR Channels and Disney+Hotstar, through the
Rogue Apps which is annexed herewith Document A.

;::_' 0 "{ 13

i

/

*

I

4. I state that the 'CricFy TV' App has been identified by the
);;

ihyestigation agency as an Android-based mobile App which is

ALAI<~,~~~,;~~~; engaged in illegally communicating the Plaintiffs copyrighted
,.~

· 18639

I

P.c" · . I i·~- ,:',·,~<~ c,ontent, including but not limited to the content made available
Ft

2.

..... ,... ~.•• J - • ·

# ... : - .

••

••

·ough the Plaintiffs STAR Channels. I state that the 'CricFy

C:'J: C · \.,.~V ' App is an Android application that unauthorizedly makes
available for viewing and provides access to the content shown
on TV Channels including live sporting events, inter alia
ongoing IPL 2025 and other Video on Demand content
including that of the Plaintiffs.
5. I state that the primary intent and purpose of the aforesaid
'CricFy TV' App is to exploit various copyright-protected
works, including but not Umited to the Plaintiffs copyrighted
content, free of cost (or at minimal subscription) and without
any authorisation from the right owners including the Plaintiff.
In fact, the very intent of the said 'CricFy TV' App is to provide

<!-- page 20 -->

5
an alternative to legitimate sources to the user, so that a user
does not have to pay for enjoying the copyright-protected
works. Detailed allegations regarding the "rogue" nature of the
aforesaid App are provided hereinafter.
6. I state that the step-by-step process for downloading the APK
file for the 'CricFy TV' App and running the said mobile App
on a computer has been detailed in the evidence filed herewith.
7. I state that the ex parte ad interim injunction granted vide order
dated 26.09.2024 passed by this Hon'ble Court is applicable to
the aforesaid Rogue App, viz 'CricFy TV' App, identified by

/·--·~:::

·'

D: ·; 1i

t :e"'*i\ hef granted m terms of paras 39 and 40 of the

' .,. ~·:_P-· ·..~~···,G.i:'~:,·;J .~nentioned order dated 26.09.2024 and the directions
,.
~

·,

)'~·

O· ~,..,. '' ·~.s ed by the Hon'ble Court to Internet Service Providers (i.e.,
,. .

__..--- Defendant Nos. 9 to 17) and to the DoT and MEITY (i.e.,
Defendant Nos. 18 and 19) are applicable in relation to user
interface (UI) ·domains I websites I URLs identified and
notified by the Plaintiff to be infringing and/or authorising
infringement of the Plaintiffs Content through the Rogue
'CricFy TV' App.
8. In light of the above, I state that the following user interface
(UI) domains I websites has been identified by the investigation
agency as engaged in illegally communicating the Plaintiffs
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels,
through the aforesaid Rogue App, viz 'CricFy TV' App:

<!-- page 21 -->

6
. No.

1.

Domain I W b it

https://cfyhbcdkdb28.top/

9. I state that from the evidence filed along with the present
Affidavit, it is evident that the above-mentioned UI domains/
websites are hosting and/or streaming and/or providing access
and/or making available for viewing the broadcast ofPlaintiff s

_...,.i 0. I state that the Plaintiff is not aware of the owner( s) of these

rogue UI domains I websites as either they are anonymous or
have incorrect or incomplete addresses.
11.1 state that the from the evidence filed along with the present
Affidavit, it is evident that the identified Source Domain (s) I
Website (s) I URL(s) is hosting and/or streaming and/or
providing access and/or making available for viewing the
broadcast ofPlaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar. I state that the Plaintiff is the exclusive
right holders for Plaintiffs copyrighted content, including but
not limited to the content rriade available through the Plaintiffs
STAR Channels and Disney+Hotstar, for the worldwide
territory and the Plaintiff has not authorized the abovementioned websites to communicate and or make available for

<!-- page 22 -->

7
viewing the Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar.
12.I state that the Plaintiff is not aware of the owner(s) of the
identified rogue Source Domain (s) I Website (s) I URL (s) as
either they are anonymous or have incorrect or incomplete
addresses.
13 .I state that in terms of the following directions passed by this
Hon'ble Court, vide order dated 26.09.2024 (reproduced herein
above) is also applicable on the Source Domain(s) I Website(s)
~, - T A ' f:~RL(s) identified herewith.

I ~ ALAV..A NAYAK

.k
;

~~dv?cJ};

'

40. Th~ defendants No .. 4 to 8 shall ensure compli~nce
· 'u
"'Vflitth thzs order by blockzng defendants no. 1 to 3 websztes,
· . · ? · the r URLs and the respective Uls as filed along with the
ti
. " • , ·
f I
' - · /;..:sillt (Pg 1 - Vol1) (also annexed herewith as annexure) · -· .......-<...~,;.: 'A) and any other Uls/apps/websites notified by the
· · C --· plaintiff by filing of an affidavit.
Rc .,

) J g

1

42. The defendants No. 9 to 17 shall ensure compliance
with this order by blocking defendants no. 1 to 3 websites,
their URLs and the respective Uls as filed along with the
suit (Pg 1 - Vol1) (also annexed herewith as annexureA) and any other apps/websites notified by the plaintiffby
filing of an affidavit.

14.In light

of the

abovementioned,

the

Department of

Telecommunications (Defendant No. 18) and the Ministry of
Electronics and Information Technology (Defendant No. 19)
are urged to issue a notification to the Internet Service
Providers (Defendant Nos. 9- 17) to block the additional rogue

<!-- page 23 -->

8
Source Domain I Website I URL identified in Document- A
hereto.

15 .I state that the evidence filed along with the present affidavit
was shared by the investigating agency in google drive link. I
downloaded the same onto the computer (Intel (R) Core (TM)
i5-2520M CPU @ G2010 @ 2.50 GHz 2.50 GHz) which is
regularly used by me in the ordinary course of business and
thereafter, shared the same with the Plaintiffs Counsel.
1:6.1 am advised to state that the conditions of Sections 63 of the
13haratiya Sakshya Adhiniyam and Order XI Rule 6(3) of the

LAKI NJ\'/'\i<
'

Rc~

f\c\VOC; ='

6 9
;. · ') ::;

; rnmercial Courts, Commercial Division and Commercial

·,~_; _, _".., ,;ApJ ellate Division ofHigh Courts Act, 2015 are complied with
t '

.,..
. . C·

! '

/

J

.

- /.' :·in 'respect of these documents.
17.In particular, I confirm:a) That the said computer system is regularly used to produce
computer outputs like emails and information from the
World Wide Web (Internet) and store other electronic
records. The relevant information from the websites and
electronic records as mentioned above was downloaded by
me in the course of activity of the Plaintiff. I have a lawful
control over the use of the said computer system by virtue of
my capacity in the organization.
b) That the electronic records mentioned above are do-<vnloaded
from the computer system as part of the ordinary course of
activities ofthe Plaintiff.

<!-- page 24 -->

9

c) That the computer system as used by me has been operating
properly and the electronic records and their accuracy and
contents have not been altered and tampered with in any

A--.. . .., manner whatsoever.

~ ~

1 \ the information contained on the computer outputs is

~,----

\
'

I"

VERIFICATION

2 4 ~1AR 20251
Verified at New Delhi on this the

of March 2025 that the

contents of the above said Affidavit are true to the best of
knowledge, information and belief and nothing material has been
concealed therefrom.

<!-- page 25 -->

10
Document A: Additional list of Source Domains / Websites /
URLs

S.
No.
1.

Source Domain / Website /
URL
https://cfyhbcdkdb28.top/

Rogue App
‘CricFy TV’
(Defendant No. 23)

<!-- page 26 -->

IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
Star India Pvt. Ltd.

.…Plaintiff

versus
…Defendants

MovieBlast Application and Ors.
INDEX
PARTICULARS

S.
NO.
1. Affidavit of Mr. Hitender Adlakha dated 24th
March 2025 with respect to additional list of
Source Domain(s) / Website (s) / URL (s) that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
2. Annexure A: Additional list of Source
Domain (s) / Website (s) / URL
3. Evidence with respect to additional list
Source Domain (s) / Website (s) / URL that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
4. Proof of Service

Place: New Delhi
Date: 24.03.2025

PAGE
NO

1-9

10

11-21

Vivek Kumar
(D/7260/2023)
Saikrishna and Associates
Advocates for the Plaintiff
57, Jor Bagh,
New Delhi – 110003

<!-- page 27 -->

1
IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024

IN THE MATTER OF:
Star India Pvt. Ltd.

.... Plaintiff
versus

MovieBlast Application and Ors.

. .. Defendants

AFFIDAVIT OF MR. HITENDER ADLAKHA, S/0 SH. LATE
R.

L.

ADLAKHA,

AGED

53

YEARS,

AUTHORISED

REPRESENTATIVE OF PLAINTIFF, STAR INDIA PVT. LTD.
HAVING OFFICE AT STAR HOUSE, URMI ESTATE, 95

A GANPATRAO

~AI 400013, PRESENTLY AT NEW DELHI, INDIA, ON

;rr

1)>..\<P- t-l.~'

pd'' 0 ~-\ .~

.

.k

. .

l

,

)

KADAM MARG, LOWER PAREL (W),

" .2.''

. r~ ' ~.•• ~'.'J
\.0 .,:I I ~
•

·LF OF THE PLAINTIFF
... I

-:Y
-ft:"-:.t,.., .
~<!"..-~..

!.

I

- ..

,above-named deponent, do hereby solemnly affirm and
/

0 'cff~Uire as under:
1. That, I am the Authorized Representative of the Plaintiff in the
present suit and as such I am conversant with the facts and
circumstances of the present suit and competent to depose in
respect thereof.
2. I state that I am aware of the present suit and the order dated
26.09.2024 whereby the Hon'ble Court was pleased to pass
an ex-parte ad-interim order in terms of the following:

<!-- page 28 -->

2
"38. In view of the averments noted hereinabove and in view
ofthe judgment passed in UTV Software Communication Ltd.
(supra), this Court is ofthe opinion that a prima facie case is
made out in favour of the plaintiff Balance ofconvenience is
also in favour of the plaintiff Further, irreparable harm or
injury would be caused to the plaintiffifan interim injunction
order is not passed.

.'

39. Accordingly, defendants No. 1 to 3 (and any such other
Uls/websites which appears to be associated with any of the
defendant apps and websites based on its name, branding or
the identity of its operator, or discovered to provide
additional means of accessing, the defendant apps and
websites, and other domainsldomain/apps/Uls along with
their sub domains and subdirectories, owners/website
operators/entities which are discovered to have been
engaging in infringing the plaintiff's exclusive rights), their
owners, partners, proprietors, officers, servants, employees,
~!'\{~:~
·f.. and all others in capacity ofprincipals or agents, acting for
-~()
_,, ~d on their behalf, or anyone claiming through, by or under
' "'
. '"'.;\ ,;;: hem are hereby restrained, from, in any manner hosting,
"• -"j '·:.}streaming, reproducing, distributing, making available to the
/. '/ public and/or communicating to the public, or facilitating the
same, on their Apps/Ulslwebsites, through the internet in any
manner
whatsoever,
any
cinematograph
work/content/programme/show in relation to which plaintiff
has a copyright.

0'/ /

40. The defendants No. 4 to 8 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
URLs and the respective U/s as filed along with the suit (Pg
1 - Vol 1) (also annexed herewith as annexure- A) and any
other Uls/apps/websites notified by the plaintiff by filing of
an affidavit.
41. The defendants no. 4 to 8, their directors, partners,
proprietors, officers, affiliates, servants, employees, and all
others in capacity of principal or agent acting for and, on
their behalf, or anyone claiming through, by or under it, are
directed to disclose the following information of the
defendants no. 1 -3 (and any such other websites/Uls which
are discovered during the course of the proceedings and
notified on Affidavit by the plaintiff to have been infringing/

<!-- page 29 -->

3
authorizing the infringement of the plaintiff's exclusive
rights, copyrights and broadcast reproduction rights):
A. Complete details (such as name, address, email address,
phone number, IP address etc.) of the defendants no. 1 - 3
(and any such other websites/Uls which are discovered
during the course ofthe proceedings and notified on Affidavit
by the plaintiff to have been infringing/ authorizing the
infringement of the plaintiff's exclusive rights, copyrights).
B. Mode of payment along with payment details used for
registration of domain name by the registrant i.e., defendant
no. 1 - 3 (and any such other websites/Uls which are
discovered during the course of the proceedings and notified
on Affidavit by the plaintiff to have been infringing/
authorizing the infringement of the plaintiff's exclusive
rights, copyrights).

'•

, '···· '): C

42. The defendants No. 9 to 17 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
flt?Ls ahd the respective Uls as filed along with the suit (Pg
L ~w\ Vol 1) (also annexed herewith as annexure - A) and any
1
oth r appslwebsites notified by the plaintiff by filing of an
J
'd 't

·(Y;~mediate
·± ~. ;:~endants

no. 18 and 19 are fUrther directed to take
steps and issue requisite notifications within five
working days, calling upon various internet and telecom
service providers registered under them to block the
aforementioned websites/Uls identified by the plaintiff. "

3. I state that in order to protect and enforce its exclusive rights in
the Plaintiffs copyrighted content, including but not limited to
the content made available through the Plaintiffs STAR
Channels and Disney+Hotstar, the Plaintiff engaged the
services of an investigation agency, Copyright Integrity
International,

to

identify

and

monitor

other

domains/domain/apps/Uls along with their sub domains and
subdirectories, owners/website operators/entities which are

<!-- page 30 -->

4
discovered to have been engaging in infringing the plaintiffs
exclusive rights (in terms of paragraph 39 and 40 of the
aforementioned order dated 26.09.2024) collaborating with the
said App and/or the other Uis/apps identified in the instant suit
and gather evidence of their infringing activity. I state that the
Source Domain (s) I Website (s) I URL (s) that have been
identified by the investigation agency engaged in illegally
communicating the Plaintiffs copyrighted content, including
but not limited to the content made available through the
Plaintiffs STAR Channels and Disney+Hotstar, through the
Rogue Apps which is annexed herewith Document A.

4. I state that the 'CricPK TV' App has been identified by the
investigation agency as an Android-based mobile App which is
ALAIV-\ Nt-~.Y!\K

:e~aged in illegally communicating the Plaintiffs copyrighted

Re~ · : . '~"' .. ':~9 r entent, including but not limited to the content made available

\or: /. ,' .~ ·~;_ ~~fo ugh the Plaintiffs STAR Channels. I state that the 'CricPK
to 2f 1.1! -~· ""¢·.
./... ·V App is an Android application that unauthorizedly makes

Pt. 1
'-

0

;"r -

r

~

available for viewing and provides access to the content shown
on TV Channels including live sporting events, inter alia
ongoing IPL 2025 and other Video on Demand content
including that of the Plaintiffs.
5. I state that the primary intent and purpose of the aforesaid
'CricPK TV' App is to exploit various copyright-protected
works, including but not limited to the Plaintiffs copyrighted
content, free of cost (or at minimal subscription) and without
any authorisation from the right owners including the Plaintiff.
In fact, the very intent of the said 'CricPK TV' App is to
provide an alternative to legitimate sources to the user, so that

<!-- page 31 -->

5
a user does not have to pay for enjoying the copyright-protected
works. Detailed allegations regarding the "rogue" nature of the
aforesaid App are provided hereinafter.
6. I state that the step-by-step process for downloading the APK
file for the 'CricPK TV' App and running the said mobile App
on a computer has been detailed in the evidence filed herewith.
7. I state that the ex parte ad interim injunction granted vide order
dated 26.09.2024 passed by this Hon'ble Court is applicable to
the aforesaid Rogue App, viz ''CricPK TV' App, identified by
the Plaintiffs investigation agency (in terms of para 39 and 40

/,_ 1 A
..(~0

'

~~~ ALAK~~~c~~.~~

1

1·

Re•, ..

of the aforementioned order dated 26.09.2024). Accordingly,
e 'relief granted in terms of paras 39 and 40 of the
i
'
""/1(

. I (L]39

a ore entioned order dated 26.09.2024 and the directions

"'

lv "- -'

' . _.,,

. ./

::;:.:r:.i~g~.S~e'd by the Hon'ble Court to Internet Service Providers (i.e.,
/'

..

:~·Defendant Nos.

9 to 17) and to the DoT and MEITY (i.e.,

Defendant Nos. 18 and 19) are applicable in relation to user
interface (UI) domains I websites I URLs identified and
notified by the Plaintiff to be infringing and/or authorising
infringement of the Plaintiffs Content through the Rogue
'CricPK TV' App.

8. In light of the above, I state that the following user interface
(UI) domains I websites has been identified by the investigation
agency as engaged in illegally communicating the Plaintiffs
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels,
through the aforesaid Rogue App, viz 'CricPK TV' App:

<!-- page 32 -->

6
. No.

1.

Domain I Web ite

https://lagrahahaibai.site

9. I state that from the evidence filed along with the present
Affidavit, it is evident that the above-mentioned UI domains/
websites are hosting and/or streaming and/or providing access
and/or making available for viewing the broadcast ofPlaintiffs
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels,
ALAKA N. 1YAI ~~tfu·ough the aforesaid Rogue App, viz 'CricPK TV' App, and/or
Arlvoca.te

\

He~:-~~ ; J;~;r~c4
1

-l~ori ~ing in~ingement ofthe Plaintiffs copyrigh~ed content

\J 2 ,., ~~- 2 9 1jy makmg available for download and usage the said App.
"71"'•
' ~.~ .. --:-- ~~·
Pr.

L

{"·

10.I state that the Plaintiff is not aware of the owner(s) of these
rogue UI domains I websites as either they are anonymous or
have incorrect or incomplete addresses.

11 .I state that the from the evidence filed along with the present
Affidavit, it is evident that the identified Source Domain (s) I
Website (s) I URL(s) is hosting and/or streaming and/or
providing access and/or making available for viewing the
broadcast of Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar. I state that the Plaintiff is the exclusive
right holders for Plaintiffs copyrighted content, including but
not limited to the content made available through the Plaintiffs
STAR Channels and Disney+Hotstar, for the worldwide
territory and the Plaintiff has not authorized the abovementioned websites to communicate and or make available for

<!-- page 33 -->

7
viewing the Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar.

12.1 state that the Plaintiff is not aware of the owner(s) of the
identified rogue Source Domain (s) I Website (s) I URL (s) as
either they are anonymous or have incorrect or incomplete
addresses.

13 .I state that in terms of the following directions passed by this
Hon'ble Court, vide order dated 26.09.2024 (reproduced herein
above) is also applicable on the Source Domain(s) I Website(s)

....

/ 0 T A ~i RL(s) identified herewith.
/

ALAKA NtW!\fC

k

R~,.- ~..·:. .:. ~' :·; 'd 4.{J ~ The defendants No. 4 to 8 shall ensure compliance with

1\ "v:.-::11 .

~

r:7t , P "
1
\

'

·~ '

'- . •. ,r-:

\

Q;rder by blocking defendants no. 1 to 3 websites, their
~ ·)UJiLs and the respective Uls as filed along with the suit (Pg
···<··.'• t- Vall) (also annexed herewith as annexure- A) and any
· other Ulslapps/websites notified by the plaintiff by filing of
an affidavit.
.. · • thi

v

42. The defendants No. 9 to 17 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
URLs and the respective Uls as filed along with the suit (Pg
1 - Vol 1) (also annexed herewith as annexure- A) and any
other apps/websites notified by the plaintiff by filing of an
affidavit.
14.In light

of the

abovementioned,

the

Department

of

Telecommunications (Defendant No. 18) and the Ministry of
Electronics and Information Technology (Defendant No. 19)
are urged to issue a notification to the Internet Service
Providers (Defendant Nos. 9- 17) to block the additional rogue

<!-- page 34 -->

8
Source Domain I Website I URL identified in Document- A
hereto.
15 .I state that the evidence filed along with the present affidavit
was shared by the investigating agency in google drive linlc I
downloaded the same onto the computer (Intel (R) Core (TM)
i5-2520M CPU@ 02010 @ 2.50 GHz 2.50 GHz) which is
regularly used by me in the ordinary course of business and
thereafter, shared the same with the Plaintiffs Counsel.

1 A
'·
0
'"'''. 6~1 am advised to state that the conditions of Sections 63 of the
AlA~\'!.~ '

\

~d~\~ 039 Bkaratiya Sakshya Adhiniyam and Order XI Rule 6(3) of the

/

t pc~',: , ', ;,,:;;

.

p.eg • ·J . :.., •• •

(.'1

,0
. i'":f-

I .

A

9

1

oillmercial Courts, Commercial Division and Commercial
'ppellate Division ofHigh Courts Act, 2015 are complied with

C . ' in respect of these documents.
17.In particular, I confirm:a) That the said computer system is regularly used to produce
computer outputs like emails and information from the
World Wide Web (Internet) and store other electronic
records. The relevant information from the websites and
electronic records as mentioned above was downloaded by
me in the course of activity of the Plaintiff. I have a lawful
control over the use of the said computer system by virtue of
my capacity in the organization.
b) That the electronic records mentioned above are downloaded
from the computer system as part of the ordinary course of
activities ofthe Plaintiff.

<!-- page 35 -->

9

c) That the computer system as used by me has been operating
properly and the electronic records and their accuracy and
contents have not been altered and tampered with in any
manner whatsoever.

h ~ the information contained on the computer outputs is
·ct replica and has been produced from the original
Pc r.

).·

~u .::..11

\.

·r ~~::t!,l.eelffon ic record and therefore, reproduces the information
"'I

.....· . .:..J /., .~

_. ..,.. . --·· ,..,- {.,..-,.or.Itained
on the electronic records therein.
,"
' • rt..J
~
"
,.~ -~/
/

contents of the above said Affidavit are true to the best of
knowledge, information and belief and nothing material has been
concealed therefrom.
C':f-;1TiFit::D T1
!·1 i ·rm: DEPON E I.A T,._Jf. •d':3h;-i/;:)mt/Km ..• "' . • I ~ ..q.t:YJ fVvv

S/o,W/o RID ......... . ....... ··:....... . )~)

... ..,. ... .. . .
ld--n: - •

l 'n.

· ''

DEP
1
·W·v-~aTh
-~
jrv--··
'" ·
·· -~ u - '

.

~· ·

L'Gl u •

·
c,
t~r(ve been r·::;·:1d L)~ ·.: .. ::~ .. :.~~n;~-:-·:j to hln1n1s;
are true & corre::.i. to h:s/il~r knowledge

-~ h(:~

I~ -~ r

,

'

2 4 I"IAn LUZ5

' '

I

•

<!-- page 36 -->

10
Document A: Additional list of Source Domains / Websites /
URLs

S.
No.
1.

Source Domain / Website /
Rogue App
URL
https://lagrahahaibai.site
‘CricPK TV’
(Proposed Defendant
No. 31)

<!-- page 37 -->

IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
Star India Pvt. Ltd.

.…Plaintiff

versus
…Defendants

MovieBlast Application and Ors.
INDEX
PARTICULARS

S.
NO.
1. Affidavit of Mr. Hitender Adlakha dated 4th
March 2025 with respect to additional list of
Source Domain(s) / Website (s) / URL (s) that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
2. Document A: Additional list of Source
Domain (s) / Website (s) / URL
3. Evidence with respect to additional list
Source Domain (s) / Website (s) / URL that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
4. Proof of Service

Place: New Delhi
Date: 04.03.2025

PAGE
NO

1-9

10

11-22

Vivek Kumar
(D/7260/2023)
Saikrishna and Associates
Advocates for the Plaintiff
57, Jor Bagh,
New Delhi – 110003

<!-- page 38 -->

1
IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
Star India Pvt. Ltd.

.... Plaintiff
versus

MovieBlast Application and Ors.

. .. Defendants

AFFIDAVIT OF MR. HITENDER ADLAKHA, S/0 SH. LATE
R.

L.

ADLAKHA,

AGED

53

YEARS,

AUTHORISED

REPRESENTATIVE OF PLAINTIFF, STAR INDIA PVT. LTD.

MBAI 400013, PRESENTLY AT NEW DELHI, INDIA, ON
F OF THE PLAINTIFF

-~ 1-'l. \u _,

·"

·•.J! ~""\«.

-- / ••

I

f..,

. 9~ above-named deponent, do hereby solemnly affirm and
t tecfare as under:
1. That, I am the Authorized Representative of the Plaintiff in the
present suit and as such I am conversant with the facts and
circumstances of the present suit and competent to depose in
respect thereof.

2. I state that I am aware of the present suit and the order dated
26.09.2024 whereby the Hon'ble Court was pleased to pass
an ex-parte ad-interim order in terms of the following:
"38. In view of the averments noted hereinabove and in view
ofthe judgment passed in UTV Software Communication Ltd.

<!-- page 39 -->

2
(supra), this Court is of the opinion that a prima facie case is
made out in favour of the plaintiff Balance ofconvenience is
also in favour of the plaintiff Further, irreparable harm or
injury would be caused to the plaintiffifan interim injunction
order is not passed.
39. Accordingly, defendants No. 1 to 3 (and any such other
Uls/websites which appears to be associated with any of the
defendant apps and websites based on its name, branding or
the identity of its operator, or discovered to provide
additional means of accessing, the defendant apps and
websites, and other domainsldomain/apps/Uls along with
their sub domains and subdirectories, owners/website
,
operators/entities which are discovered to have been
., P~_: J. engaging in infringing the plaintiff's exclusive rights), their
\V • ;,,\ ~ O'&ners, partners, proprietors, officers, servants employees,
r v.Y.·
· ,.:,~ ~ tz~d all others in capacity ofprincipals or agents, acting for
?.~.
· .'...... · , «J}.'l' d on their behalj; or anyone claiming through, by or under
?C'·'·~ _, , . .••.• ·~ / :..tf'zem are hereby restrained, from, in any manner hosting,
\u ·
./..:-r: streaming, reproducing, distributing, making available to the
f~
public and/or communicating to the public, or facilitating the
same, on their Apps/Ulslwebsites, through the internet in any
manner
whatsoever,
any
cinematograph
work/content/programme/show in relation to which plaintiff
has a copyright.

'\-

40. The defendants No. 4 to 8 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
URLs and the respective Uls as filed along with the suit (Pg
1 - Vol 1) (also annexed herewith as annexure - A) and any
other Ulslapps/websites notified by the plaintiff by filing of
an affidavit.
41. The defendants no. 4 to 8, their directors, partners,
proprietors, officers, affiliates, servants, employees, and all
others in capacity of principal or agent acting for and, on
their behalf, or anyone claiming through, by or under it, are
directed to disclose the following information of the
defendants no. 1 -3 (and any such other websites/Uls which
are discovered during the course of the proceedings and
notified on Affidavit by the plaintiff to have been infringing/
authorizing the infringement of the plaintiff's exclusive
rights, copyrights and broadcast reproduction rights) :

<!-- page 40 -->

3
A. Complete details {such as name, address, email address,
phone number, IP address etc.) of the defendants no. 1 - 3
(and any such other websites/Uls which are discovered
during the course ofthe proceedings and notified on Affidavit
by the plaintiff to have been infringing! authorizing the
infringement of the plaintiff's exclusive rights copyrights).
B. Mode of payment along with payment details used for
registration of domain name by the registrant i.e., defendant
no. 1 - 3 (and any such other websites/ Uls which are
discovered during the course of the proceedings and notified
on Affidavit by the plaintiff to have been infringing/
authorizing the infringement of the plaintiff's exclusive
rights, copyrights).

,,.

. ..

'

-

42. The defendants No. 9 to 17 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
_URLs and the respective Uls as filed along with the suit (Pg
- Vol 1) (also annexed herewith as annexure - A) and any
tl~er apps/websites notified by the plaintiff by filing of an
,ri!{/Jdavit.

.!2 -~~/

.[\

........

Defendants no. 18 and 19 are further directed to take
· • immediate steps and issue requisite notifications within five
working days, calling upon various internet and telecom
service providers- registered under them to block the
aforementioned websites/Uls identified by the plaintiff. "

3. I state that in order to protect and enforce its exclusive rights in
the Plaintiffs copyrighted content, including but not limited to
the content made available through the Plaintiffs STAR
Channels and Disney+Hotstar, the Plaintiff engaged the
services of an investigation agency, Copyright Integrity
International,

to

identify

and

monitor

other

domains/domain/apps/Uis along with their sub domains and
subdirectories, owners/website operators/entities which are
discovered to have been engaging in infringing the plaintiffs
exclusive rights (in terms of paragraph 39 and 40 of the
aforementioned order dated 26.09.2024) collaborating with the

<!-- page 41 -->

4
said App and/or the other Uislapps identified in the instant suit
and gather evidence of their infringing activity. I state that the
Source Domain (s) I Website (s) I URL (s) that have been
identified by the investigation agency engaged in illegally
communicating the Plaintiffs copyrighted content, including
but not limited to the content made available through the
Plaintiffs STAR Channels and Disney+Hotstar, through the
Rogue Apps which is annexed herewith Document A.

4. I state that the 'GHD Sports' App has been identified by the
investigation agency as an Android-based mobile App which is
e~gaged in illegally communicating the Plaintiffs copyrighted
1 \..l\

~~.:.". ,\(:s
'j\:;'j ')

~ent, including but not limited to the content made available
\

~. ~t ~~. ... c., ~ ..t qugh the Plaintiffs STAR Channels. I state that the 'GHD
pr

'.0 ...• ~.I · ·

c

S-~rts ' App is an Android application that unauthorizedly

/.~~akes available for viewing and provides access to the content
shown on TV Channels including live sporting events, inter
alia ongoing IPL 2025 and other Video on Demand content

including that of the Plaintiffs.

5. I state that the primary intent and purpose of the aforesaid
'GHD Sports' App is to exploit various copyright-protected
works, including but not limited to the Plaintiffs copyrighlt:u
content, free of cost (or at minimal subscription) and without
any authorisation from the right owners including the Plaintiff.
In fact, the very intent of the said 'GHD Sports' App is to
provide an alternative to legitimate sources to the user, so that
a user does not have to pay for enjoying the copyright-protected
works. Detailed allegations regarding the "rogue" nature of the
aforesaid App are provided hereinafter.

<!-- page 42 -->

5
6. I state that the step-by-step process for downloading the APK
file for the ' GHD Sports' App and running the said mobile App
on a computer has been detailed in the evidence filed herewith.

7. I state that the ex parte ad interim injunction granted vide order
dated 26.09.2024 passed by this Hon'ble Court is applicable to
the aforesaid Rogue App, viz "GHD Sports' App, identified by
the Plaintiffs investigation agency (in terms of para 39 and 40
f the aforementioned order dated 26.09.2024). Accordingly,
[\iiY:.'>.\ '" ' f:' (_
/

•

.. f\

.I I(

-

• 1

the , relief granted in terms of paras 39 and 40 of the

C

\

Fs;:' . ~- -': ~.- ~·;: ., . ·for~mentioned order dated 26.09.2024 and the directions
_.... (IIi'··

p~ ~·

·

~...

r

'"
'g

•

~ 1 · .~ .is$Ued by the Hon'ble Court to Internet Service Providers (i.e.,
~-

"'

. f

· 'D efendant Nos. 9 to 17) and to the DoT and MEITY (i.e.,
Defendant Nos. 18 and 19) are applicable in relation to user
interface (UI) domains I websites I URLs identified and
notified by the Plaintiff to be infringing and/or authorising
infringement of the Plaintiffs Content through the Rogue
'GHD Sports' App.

8. In light of the above, I state that the following user interface
(UI) domains I websites has been identified by the investigation
agency as engaged in illegally communicating the Plaintiffs
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels,
through the aforesaid Rogue App, viz 'GHD Sports' App:
Domain I Website

S.No.
1.

httos://Q.hdhskdbscv 1:::. .too/
J

-

•

<!-- page 43 -->

6
9. I state that from the evidence filed along with the present
Affidavit, it is evident that the above-mentioned UI domains/
websites are hosting and/or streaming and/or providing access
and/or making available for viewing the broadcast of Plaintiffs
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels,
through the aforesaid Rogue App, viz 'GHD Sports' App,
and/or authorising infringement of the Plaintiffs copyrighted
content by making available for download and usage the said

""\A

App.

-

1QJ ·-state that the Plaintiff is not aware of the owner(s) of these
LA~' r~ Nf\.'! f-'.K ~
;er-.· ".·~.~~~~~~~9 rpgue. UI domain~ I websites as either they are anonymous or
f',·~:~,;,~ 1 '2 -~_.. l'J'ave mcorrect or mcomplete addresses.
F€;·cu ·-··
:;
,.,.,,.
\') t.. . •
/ .r:··,
, ·~~~

//~-

-· J 1.1 state that the from the evidence filed along with the present

c~

Affidavit, it is evident that the identified Source Domain (s) I
Website (s) I URL(s) is hosting and/or streaming and/or
providing access and/or making available for viewing the
broadcast of Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar. I state that the Plaintiff is the exclusive
right holders for Plaintifr s copyrighted content, including but
not limited to the content made available through the Plaintiffs
STAR Channels and Disney+Hotstar, for the worldwide
territory and the Plaintiff has not authorized the abovementioned websites to communicate and or make available for
viewing the Plaintiffs Content, including but not limited to the
content made available through the Plaintiff's STAR Channels
and Disney+Hotstar.

<!-- page 44 -->

7
12.1 state that the Plaintiff is not aware of the owner(s) of the
identified rogue Source Domain (s) I Website (s) I URL (s) as
either they are anonymous or have incorrect or incomplete
addresses.

13 .I state that in terms of the following directions passed by this
Hon'ble Court, vide order dated 26.09.2024 (reproduced herein
above) is also applicable on the Source Domain(s) I Website(s)
I URL(s) identified herewith.
,,_,r.-'· ~

40. The defendants No.4 to 8 shall ensure compliance with
_/ 0 1·
' this order by blocking defendants no. 1 to 3 websites, their
·lRLs and the respective Uls as filed along with the suit
ALAK~c~~-~~~~l;J{Pg 1 - Vol 1) (also annexed herewith as annexure -A) and
5~
Re~ .~~": ,:,:_~~?~''] any other Uls/apps/websites notified by the plaintiff by
, -~?"';, p, f. ·- '- : - - ~··· ~ _n Jzg of an affidavit.
~ p·

,
--~

ll

/-; •.. ~·rt//..C

/.

l
•4 •, •• • •• • •• • ••• • •

. ----1 ~ ., '42. The defendants No. 9 to 17 shall ensure compliance
•

n

0 ~

with this order by blocking defendants no. 1 to 3 websites,
their URLs and the respective Uls as filed along with the
suit (Pg 1 - Vall) (also annexed herewith as annexure- A)
and any other apps/websites notified by the plaintiff by
filing of an affidavit.

14.In light

of the abovementioned, the Department of

Telecommunications (Defendant No. 18) and the Ministry of
Electronics and Information Technology (Defendant No. 19)
are urged to issue a notification to the Internet Service
Providers (Defendant Nos. 9- 17) to block the additional rogue
Source Domain I Website I URL identified in Document- A
hereto.

<!-- page 45 -->

8
15 .I state that the evidence filed along with the present affidavit
was shared by the investigating agency in google drive linlc I
downloaded the same onto the computer (Intel (R) Core (TM)
i5-2520M CPU@ 02010 @ 2.50 GHz 2.50 GHz) which is
regularly used by me in the ordinary course of business and
thereafter, shared the same with the Plaintiffs Counsel.

,....

·"""'·....

.16.1 am advised to state that the conditions of Sections 63 of the

ji''\ i/ .

~>

B.haratiya Sakshya Adhiniyam and Order XI Rule 6(3) of the
'C:ol\llmercial Courts, Commercial Division and Commercial
I

•

I

_Appel1ate Division ofHigh Courts Act, 2015 are complied with
'. '·I
I
./ in respect ofthese documents .
I

..--· .

(...."'~

--

;

,,<;:

17.In particular, I confirm:a) That the said computer system is regularly used to produce
computer outputs like emails and information from the
World Wide Web (Internet) and store other electronic
records. The relevant information from the websites and
electronic records as mentioned above was downloaded by
me in the course of activity of the Plaintiff. I have a lawful
control over the use of the said computer system by virtue of
my capacity in the organization.

b) That the electronic records mentioned above are downloaded
from the computer system as part of the ordinary course of
activities of the Plaintiff.

<!-- page 46 -->

9

c) That the computer system as used by me has been operating
properly and the electronic records and their accuracy and
contents have not been altered and tampered with in any
I " " j. •,

p.J_A'fJ-..,J'JCC- '"'

J...

r. . 1'1.
r.c~,::~") - ~~),~~!~a! t~T information contained on the computer outputs is
Pc ":~.~ ~~ct replica and has been produced from the original

,. ,. .. _ ~- .!e' ,.,.·r6 nic record and therefore, reproduces the information
.~

• 0 .,· . ontained on the electronic records therein.

r\

\v

r

'

..J t:

. ent who

.

e th;~vl
· \dentlf\ed t~
presence.
nas st·gned. \0 rn'Y

VERIFICATION

2 4 MAR 2025
Verified at New Delhi on this the

of March 2025 that the

contents of the above said Affidavit are true to the best of
knowledge, information and belief and nothing material has been
concealed therefrom.

<!-- page 47 -->

10
Document A: Additional list of Source Domains / Websites /
URLs

S.
No.
1.

Source Domain / Website /
Rogue App
URL
https://ghdhskdbscv12.top/ ‘GHD Sports’
(Defendant No. 25)

<!-- page 48 -->

IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
Star India Pvt. Ltd.

.…Plaintiff

versus
…Defendants

MovieBlast Application and Ors.
INDEX
PARTICULARS

S.
NO.
1. Affidavit of Mr. Hitender Adlakha dated 24th
March 2025 with respect to additional list of
Source Domain(s) / Website (s) / URL (s) that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
2. Document A: Additional list of Source
Domain (s) / Website (s) / URL
3. Evidence with respect to additional list
Source Domain (s) / Website (s) / URL that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
4. Proof of Service

Place: New Delhi
Date: 24.03.2025

PAGE
NO

1-9

10

11-23

Vivek Kumar
(D/7260/2023)
Saikrishna and Associates
Advocates for the Plaintiff
57, Jor Bagh,
New Delhi – 110003

<!-- page 49 -->

1
IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
Star India Pvt. Ltd.

. ... Plaintiff
versus

MovieBlast Application and Ors.

. .. Defendants

AFFIDAVIT OF MR. HITENDER ADLAKHA, S/0 SH. LATE
R.

L.

ADLAKHA,

AGED

53

YEARS,

AUTHORISED

REPRESENTATIVE OF PLAINTIFF, STAR INDIA PVT. LTD.
HAVING OFFICE AT STAR HOUSE, URMI ESTATE, 95

Ap.V.~~
··

~ A

.GANPATRAO KADAM MARG,

::,;.;"':

.

LOWER PAREL

(W),

AI 400013, PRESENTLy AT NEw DELHI, INDIA, ON

Re~ ~ ~JF OF THE PLAINTIFF

-j{

0

0:~-r~c-.c.,...•:'/4~~ above-named deponent, do hereby solemnly affirm and
l

.

.,.--·

declare as under:
1. That, I am the Authorized Representative of the Plaintiff in the
present suit and as such I am conversant with the facts and
circumstances of the present suit and competent to depose in
respect thereof.

2. I state that I am aware of the present suit and the order dated
26.09.2024 whereby the Hon'ble Court was pleased to pass
an ex-parte ad-interim order in terms of the following:

"38. In view of the averments noted hereinabove and in
view of the judgment passed in UTV Software

<!-- page 50 -->

2
Communication Ltd. (supra), this Court is of the opinion
that a prima facie case is made out in favour of the
plaintiff. Balance of convenience is also in favour of the
plaintiff. Further, irreparable harm or injury would be
caused to the plaintiff if an interim injunction order is not
passed.
39. Accordingly, defendants No. 1 to 3 (and any such other
Ulslwebsites which appears to be associated with any of
the defendant apps and websites based on its name,
branding or the identity of its operator, or discovered to
provide additional means ofaccessing, the defendant apps
and websites, and other domains/domain/apps/Uls along
with their sub domains and subdirectories, owners/website
operators/entities which are discovered to have been
engaging in infringing the plaintiff's exclusive rights),
their owners, partners, proprietors, officers, servants,
employees, and all others in capacity of principals or
agents, acting for and on their behalf, or anyone claiming
\ through, by or under them are hereby restrained, from, in
_ ,,
tany manner hosting, streaming, reproducing, distributing,
1
1
pz:,;~.~t ':i: ;•:~ ·;1::~:.:. ~- ~aking available to the public and/or communicating to
t 0 -;-. r;eA'?;j29 . (
.
.. .
.
-·' ·
·
J~
the pubhc, or faclhtatmg the same, on the1r
! "' . ;::
\~ ·~·/ Apps/Ulslwebsites, through the internet in any manner
//
whatsoever,
any
cinematograph
work/content/programme/show in relation to which
plaintiff has a copyright.

*

....

/

40. The defendants No. 4 to 8 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
URLs and the respective Uls as filed along with the suit
(Pg 1 - Vol 1) (also annexed herewith as annexure -A) and
any other Ulslapps/websites notffied by the plaintiff by
filing uf an affidavit.
41. The defendants no. 4 to 8, their directors, partners,
proprietors, officers, affiliates, servants, employees, and
all others in capacity ofprincipal or agent acting for and,
on their behalf, or anyone claiming through, by or under
it, are directed to disclose the following information of the
defendants no. 1 -3 (and any such other websites/Uls
which are discovered during the course of the proceedings
and notified on Affidavit by the plaintiff to have been
infringing/ authorizing the infringement of the plaintiff's

<!-- page 51 -->

3
exclusive rights, copyrights and broadcast reproduction
rights):
A. Complete details (such as name, address, email
address, phone number, IP address etc.) of the
defendants no. 1 - 3 (and any such other websites/Uls
which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff
to have been infringing/ authorizing the infringement
of the plaintiff's exclusive rights, copyrights).
B. Mode ofpayment along with payment details used
for registration ofdomain name by the registrant i.e.,
defendant no. 1-3 (and any such other websites/Uls
which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff
to have been infringing/ authorizing the infringement
of the plaintiff's exclusive rights, copyrights).
42. The defendants No. 9 to 17 shall ensure compliance
with this order by blocking defendants no. 1 to 3 websites,
their URLs and the respective Uls as filed along with the
suit (Pg 1- Vall) (also annexed herewith as annexure- A)
and any other apps/websites notified by the plaintiff by
filing of an affidavit.
43. Defendants no. 18 and 19 are further directed to take
immediate steps and issue requisite notifications within
five working days, calling upon various internet and
telecom service providers registered under them to block
the aforementioned websites/Uls identified by the
plaintiff "

3. I state that in order to protect and enforce its exclusive rights in
the Plaintiffs copyrighted content, including but not limited to
the content made available through the Plaintiffs STAR
Channels and Disney+Hotstar, the Plaintiff engaged the
services of an investigation agency, Copyright Integrity
International,

to

identify

and

monitor

other

domains/domain/apps/Uis along with their sub domains and

<!-- page 52 -->

4
subdirectories, owners/website operators/entities which are
discovered to have been engaging in infringing the plaintiffs
exclusive rights (in terms of paragraph 39 and 40 of the
aforementioned order dated 26.09.2024) collaborating with the
said App and/or the other Uis/apps identified in the instant suit
and gather evidence of their infringing activity. I state that the

. .\ A--~·~ Source Domain (s) I Website (s) I URL (s) that have been
0 . ,:;:~., identified by the investigation agency engaged in illegally
Al<" "' · . 0 ,. ~
·
p_er' p,n·~ ·,e:·:."r, c rruy-unicating the Plaintiffs copyrighted content, including

1

1 (

,

•

·,o Li ;~_,.;I:·_J 2;1J~t·!fiot limited to

..)0..,,..,..

A
'

· C

the content made available through the

- . l aintiffs STAR Channels and Disney+Hotstar, through the
Rogue Apps which is annexed herewith Document A.

4. I state that the 'Rongy TV' App has been identified by the
investigation agency as an Android-based mobile App which is
engaged in illegally communicating the Plaintiffs copyrighted
content, including but not limited to the content made available
through the Plaintiffs STAR Channels. I state that the 'Rongy
TV' App is an Android application that unauthorizedly makes
available for viewing and provides access to the content shown
on TV Channels including live sporting events, inter alia
ongoing IPL 2025 and other Video on Demand content
including that of the Plaintiffs.

5. I state that the primary intent and purpose of the aforesaid
'Rongy TV' App is to exploit various copyright-protected
works, including but not limited to the Plaintiffs copyrighted
content, free of cost (or at minimal subscription) and without
any authorisation from the right owners including the Plaintiff.
In fact, the very intent of the said 'Rongy TV' App is to provide

<!-- page 53 -->

5
an alternative to legitimate sources to the user, so that a user
does not have to pay for enjoying the copyright-protected
works. Detailed allegations regarding the "rogue" nature of the
aforesaid App are provided hereinafter.

6. I state that the step-by-step process for downloading the APK
file for the 'Rongy TV' App and running the said mobile App
on a computer has been detailed in the evidence filed herewith.

7. I state that the ex parte ad interim injunction granted vide order
dated 26.09.2024 passed by this Hon'ble Court is applicable to

,/ 0 1' A
j1
!<

t}:le aforesaid Rogue App, viz ''Rongy TV' App, identified by

tbePlaintiffs investigation agency (in terms of para 39 and 40
.. .

e aforementioned order dated 26.09.2024). Accordingly,
1
relief granted in terms of paras 39 and 40 of the

'7~\ Pc · ~ "' · ''"'~1,; ·

order dated 26.09.2024 and the directions
n·_.h::iaforementioned
...
issued by the Hon'ble Court to Internet Service Providers (i.e.,
Defendant Nos. 9 to 17) and to the DoT and MEITY (i.e.,
Defendant Nos. 18 and 19) are applicable in relation to user
interface (UI) domains I websites I URLs identified and
notified by the Plaintiff to be infringing and/or authorising
infringement of the Plaintiffs Content through the Rogue
'Rongy TV' App.

8. In light of the above, I state that the following user interface
(UI) domains I web sites has been identified by the investigation
agency as engaged in illegally communicating the Plaintiffs
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels,
through the aforesaid Rogue App, viz 'Rongy TV' App:

<!-- page 54 -->

6
. No.
1.

Domain I Web ite
https://csmssb.site/

9. I state that from the evidence filed along with the present
Affidavit, it is evident that the above-mentioned UI domains/

A- ·-. ,)Vebsites are hosting and/or streaming and/or providing access
1

~~NAY:'\~(

ALA

!

.~._ :c'lo:' · co~y ·ighted content, including but not limited to the content

Re" 1... ~• • ,. '1\
'
\

'

and/or making available for viewing the broadcast ofPlaintiff s

, ,

}

~~· ~~.:../,.,.__' tna~1 available through the Plaintiffs STAR Channels,

A~ ·&'ugh the aforesaid Rogue App, viz 'Rongy TV' App, and/or

-·

. r

authorising infringement of the Plaintiffs copyrighted content
by making available for download and usage the said App.

10.I state that the Plaintiff is not aware of the owner(s) of these
rogue UI domains I websites as either they are anonymous or
have incorrect or incomplete addresses.

11.1 state that the from the evidence filed along with the present

Affidavit, it is evident that the identified Source Domain (s) I
Website (s) I URL(s) is hosting and/or streaming and/or
providing access and/or making available for viewing the
broadcast of Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar. I state that the Plaintiff is the exclusive
right holders for Plaintiff's copyrighted content, including but
not limited to the content made available through the Plaintiffs
STAR Channels and Disney+Hotstar, for the worldwide
territory and the Plaintiff has not authorized the abovementioned websites to communicate and or make available for

<!-- page 55 -->

7
viewing the Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar.

12.I state that the Plaintiff is not aware of the owner(s) of the
identified rogue Source Domain (s) I Website (s) I URL (s) as
either they are anonymous or have incorrect or incomplete
addresses.

13 .I state that in terms of the following directions passed by this

.-· v ~ ·'\-~) ·-Hon'ble Court, vide order dated 26.09.2024 (reproduced herein
/ 0
/~
_,

//

oo e) is also applicable on the Source Domain(s) I Website(s)

l

s) identified herewith.

I

/' '-~,· , !". •;·oj

p, ..

1

p~

.. ~ -

<G d.

·,u~~J2o/-

('

·

IJ. The defendants No. 4 to 8 shall ensure compliance with
-~~,<.this order by blocking_ defendants no. 1 to 3 ~ebsites, _their
URLs and the respectzve Uls as filed along wzth the suzt (Pg
1- Vall) (also annexed herewith as annexure- A) and any
other Ulslapps/websites notified by the plaintiff by filing of
an affidavit.
42. The defendants No.9 to 17 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
URLs and the respective Uls as filed along with the suit (Pg
1- Vall) (also annexed herewith as annexure- A) and any
other apps/websites notified by the plaintiff by filing of an
affidavit.

14.In light

of the

abovementioned,

the

Department of

Telecommunications (Defendant No. 18) and the Ministry of
Electronics and Information Technology (Defendant No. 19)
are urged to issue a notification to the Internet Service
Providers (Defendant Nos. 9- 17) to block the additional rogue

<!-- page 56 -->

8
Source Domain I Website I URL identified in Document- A
hereto.

15. I state that the evidence filed along with the present affidavit
was shared by the investigating agency in google drive lin1c I
downloaded the same onto the computer (Intel (R) Core (TM)
i5-2520M CPU@ G2010 @ 2.50 GHz 2.50 GHz) which is
regularly used by me in the ordinary course of business and
I

ereafter, shared the same with the Plaintiffs Counsel.

Bharatiya Sakshya Adhiniyam and Order XI Rule 6(3) of the
Commercial Courts, Commercial Division and Commercial
Appellate Division of High Courts Act, 2015 are complied with
in respect of these documents.

17.In particular, I confirm:a) That the said computer system is regularly used to produce
computer outputs like emails and information from the
World Wide Web (Internet) and store other electronic
records. The relevant information from the websites and
electronic records as mentioned above was downloaded by
me in the course of activity of the Plaintiff. I have a lawful
control over the use of the said computer system by virtue of
my capacity in the organization.

b) That the electronic records mentioned above are downloaded
from the computer system as part of the ordinary course of
activities ofthe Plaintiff.

<!-- page 57 -->

.

9
'

c) That the computer system as used by me has been operating
properly and the electronic records and their accuracy and
contents have not been altered and tampered with in any
manner whatsoever.

14

*

d -That the information contained on the computer outputs is

AlAKA ,,-.
RerJ.

"_::~~i~;~,~~;i~ e ~t replica and has been produced from the original

11
~
\, :~' 3 : [''::,;:;
el ectr~ihic
record and therefore, reproduces the information
• · --'f"'r · r

1

,., F
~ '!I-"• "# ,•

t ·

I t{

f

.

, ~ ··

1

l·;o;~,

,

ci ,iJtai'ned on the electronic records therein.

,.- . --- ,. .

~

_/

r~,

Verified at New Delhi on this the

of March 2025 that the

contents of the above said Affidavit are true to the best of
knowledge, information and belief and nothing material has been r
concealed therefrom.

<!-- page 58 -->

10
Document A: Additional list of Source Domains / Websites /
URLs

S.
No.
1.

Source Domain / Website /
Rogue App
URL
https://csmssb.site/
‘Rongy TV’
(Defendant No. 24)

<!-- page 59 -->

$~35
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 837/2024
STAR INDIA PVT. LTD.
Through:

.....Plaintiff
Mr. Sidharth Chopra, Mr. Yatinder
Garg, Ms. S. Jauhari and Mr. Vivek
Kumar, Advocates.

versus
MOVIEBLAST APPLICATION AND ORS

.....Defendants

Through:

%

CORAM:
HON'BLE MR. JUSTICE AMIT BANSAL
ORDER
26.09.2024

I.A. 40567/2024 (for exemption from certified copies of dim annexures)
1.

Allowed, subject to the plaintiff filing legible copies of the annexures

within four weeks from today.
2.

The application is disposed of.

I.A. 40566/2024 (u/S 12A of Commercial Courts Act)
3.

As the present suit contemplates urgent interim relief, in light of the

judgment of the Supreme Court in Yamini Manohar v. T.K.D. Krithi, 2023
SCC Online SC 1382, exemption from the requirement of pre-institution
mediation is granted.
4.

This is a digitally signed order.

The application stands disposed of.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 1 of 10

<!-- page 60 -->

I.A. 40568/2024 (for exemption from advance service to Defendants)
5.

The present application has been filed on behalf of the plaintiff

seeking exemption from advance service to defendants No. 10 (Bharat
Sanchar Nigam Ltd.), 13 (Mahanagar Telephone Nigam Ltd.), 18
(Department of Telecommunications) & 19 (Ministry of Electronics and
Information Technology) under Section 80 of the Civil Procedure Code,
1908 (CPC).
6.

In view of the urgent ex parte relief sought, the plaintiff is granted

exemption from the requirement of issuing notice to the defendants no. 10,
13,18 and 19 under Section 80 of the CPC.
7.

The application stands disposed of.

I.A. 40569/2024 (O-XI R-1(4) of the Commercial Courts Act)
8.

The present application has been filed on behalf of the plaintiff

seeking leave to file additional documents under the Commercial Courts
Act, 2015.
9.

The plaintiff are permitted to file additional documents in accordance

with the provisions of the Commercial Courts Act, 2015.
10.

Accordingly, the application is disposed of.

CS(COMM) 837/2024
11.

Let the plaint be registered as a suit.

12.

Issue summons.

13.

Summons be issued to the defendants through all modes. The

summons shall state that the written statement(s) shall be filed by the
defendants within thirty days from the date of the receipt of summons.
Along with the written statement(s), the defendants shall also file an
affidavit of admission/denial of the documents of the plaintiff, without

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 2 of 10

<!-- page 61 -->

which the written statement(s) shall not be taken on record.
14.

Liberty is given to the plaintiff to file replication(s), if any, within

thirty days from the receipt of the written statement(s). Along with the
replication(s) filed by the plaintiff, affidavit of admission/denial of the
documents of the defendants be filed by the plaintiff.
15.

The parties shall file all original documents in support of their

respective claims along with their respective pleadings. In case parties are
placing reliance on a document, which is not in their power and possession,
its detail and source shall be mentioned in the list of reliance, which shall
also be filed with the pleadings.
16.

If any of the parties wish to seek inspection of any documents, the

same shall be sought and given within the timelines.
17.

List before the Joint Registrar on 4th December, 2024 for completion

of service and pleadings.
18.

List before the Court on 27th February, 2025.

I.A. 40565/2024 (O-XXXIX Rule 1 & 2 of CPC)
25.

The present suit has been filed for permanent injunction, rendition of

accounts and damages for the infringement of the exclusive rights in the
plaintiff’s original content/work, which is protected under the Copyright
Act, 1957, against defendants no.1-3 which are rogue apps and websites that
substantially indulge in online piracy by making original content available
for download and otherwise providing access to infringing and illegal
content.
26.

It is averred in the plaint that the Plaintiff is a leading entertainment

and media company in India engaged in, inter alia, the production of
popular content broadcast on its STAR channels. The Plaintiff is also an

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 3 of 10

<!-- page 62 -->

exclusive right owner for several works broadcasted on its STAR channels.
Plaintiff, along with its affiliates, is the owner of an extensive portfolio of
more than 70 channels in over nine languages (all channels owned and/or
distributed by Plaintiff are hereinafter collectively referred to as “STAR
Channels”). Plaintiff owns and operates the online audio-visual streaming
platform and website, ‘www.hotstar.com’, and the mobile application,
‘Disney+ Hotstar’, formerly known as ‘Hotstar’ (hereinafter collectively
referred to as “Disney+ Hotstar”). With the widest range of content in India,
Disney+ Hotstar offers over 100,000 hours of TV shows and movies across
8 languages, Disney+ originals, latest American shows, blockbuster
Hollywood movies and content from international studios, exclusive new
content from the Hotstar Specials label, regional and national news, and
coverage of every major global sporting event.
27.

Plaintiff claims to have exclusive rights in the aforesaid works by

virtue of provision of Section 14(d) of the Copyright Act, 1957 including
inter alia the rights to publicly exhibit and communicate the said content
through any medium or mode, including on STAR Channels or Disney+
Hotstar. It is pleaded that by virtue of the exclusive media rights granted to
the Plaintiff, they broadcast, telecast and/or communicate to the public, its
Original Shows / Original Content and the STAR Channels on the digital
platform, Disney+ Hotstar, owned by the Plaintiff.
28.

It is contended that defendants no. 1 to 3, (“defendant websites and

apps”) are online locations and mobile applications whose purpose is to
communicate, make available for viewing and providing access to content of
the Plaintiff free of cost (or at minimal subscription) and without any
authorization. These Rogue Apps are completely illegal mobile applications

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 4 of 10

<!-- page 63 -->

and have no permission or authorisation to reproduce, store, transmit,
communicate, make available for viewing or provide access to any of the
Plaintiff’s Content. It is also submitted that most of the content
communicated through these Rogue Apps does not belong to them. It is also
contended that the download, distribution and use of these Android based
Rogue Apps, occurs through an .APK (“Android Package Kit” / “Android
Application Package”). The primary intent and purpose of these Rogue
Apps is to exploit various copyright-protected works, of the Plaintiff’s
content and to provide an alternative to legitimate sources to the user, such
that the user does not have to pay for enjoying the copyright-protected
works. An illustrative list of illegal content made available by the defendant
websites has been provided in paragraph 9 of the plaint.
29.

In order to protect and enforce their exclusive rights, the plaintiff

investigated

and

monitored

the

defendant’s

Rogue

Apps/UIs/Domains/websites and gathered evidence of their infringing
activities, which has been filed along with the suit.
30.

It is further contended that despite the legal notice calling upon the

concerned defendants to cease from engaging in their infringing activities,
they continue to infringe the rights in the plaintiff’s original content.
31.

In light of the above, it is contended that the defendants nos. 1 to 3 are

liable for infringement of the plaintiff’s copyright works under Section
51(a)(ii), Section 51(b) and Section 51(a)(i) of the Act, for making a copy of
the original content, including storing of it in any medium by electronic or
other means and communicating the original content to the public the
hosting, streaming, reproducing, distributing, making available to the public,
and/or communicating to the public of the original content for streaming and

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 5 of 10

<!-- page 64 -->

downloading, or facilitating the same, without authorization of the plaintiff.
In support of the aforesaid contention, reliance is placed on the decision of
this court in CS(COMM) 724 of 2017 dated 10th April, 2019 titled UTV
Software Communication Ltd. &Anr. v. 1337x.to and Ors.
32.

It is further contended by the plaintiff’s counsel that the creators of

the defendants no. 1-3 Rogue Apps are anonymous and the information
provided in the public domain regarding the owners of their related websites
is either incomplete, incorrect and/or protected behind a veil of secrecy.
These Rogue Apps/UIs/Domains/websites hide behind domain privacy
services offered by various domain name Registrars, which enable a website
owner to hide behind a veil and not disclose any contact details publicly, to
protect his privacy. Defendants no. 4 (Name.com, Inc.), 5 (Spaceship, Inc.),
6 (Hostinger Operations, UAB), 7 (Name Cheap Inc.), 8 (Go Daddy LLC)
are domain name registrars providing domain name registration to the
defendants 1-3.
33.

In order to overcome this, the plaintiff has arrayed various internet

and telecom services providers (ISPs) as the defendants no. 9-17 (hereinafter
"the said ISPs"), DoT as the defendant no. 18, MEITY as the defendant no.
19 in the present suit to ensure the effective implementation of orders passed
by this Court.
34.

Issue notice

35.

Notice be issued to the defendants through all modes.

36.

Reply(ies) be filed within four weeks.

37.

Rejoinder(s) thereto, if any, be filed two weeks thereafter.

38.

In view of the averments noted hereinabove and in view of the

judgment passed in UTV Software Communication Ltd. (supra), this Court

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 6 of 10

<!-- page 65 -->

is of the opinion that a prima facie case is made out in favour of the plaintiff.
Balance of convenience is also in favour of the plaintiff. Further, irreparable
harm or injury would be caused to the plaintiff if an interim injunction order
is not passed.
39.

Accordingly, defendants No. 1 to 3 (and any such other UIs/websites

which appears to be associated with any of the defendant apps and websites
based on its name, branding or the identity of its operator, or discovered to
provide additional means of accessing, the defendant apps and websites, and
other domains/domain/apps/UIs along with their sub domains and
subdirectories, owners/website operators/entities which are discovered to
have been engaging in infringing the plaintiff’s exclusive rights), their
owners, partners, proprietors, officers, servants, employees, and all others in
capacity of principals or agents, acting for and on their behalf, or anyone
claiming through, by or under them are hereby restrained, from, in any
manner hosting, streaming, reproducing, distributing, making available to
the public and/or communicating to the public, or facilitating the same, on
their Apps/UIs/websites, through the internet in any manner whatsoever, any
cinematograph work/content/programme/show in relation to which plaintiff
has a copyright.
40.

The defendants No. 4 to 8 shall ensure compliance with this order by

blocking defendants no. 1 to 3 websites, their URLs and the respective UIs
as filed along with the suit (Pg 1 - Vol 1) (also annexed herewith as
annexure - A) and any other UIs/apps/websites notified by the plaintiff by
filing of an affidavit.
41.

The defendants no. 4 to 8, their directors, partners, proprietors,

officers, affiliates, servants, employees, and all others in capacity of

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 7 of 10

<!-- page 66 -->

principal or agent acting for and, on their behalf, or anyone claiming
through, by or under it, are directed to disclose the following information of
the defendants no. 1 -3 (and any such other websites/UIs which are
discovered during the course of the proceedings and notified on Affidavit by
the plaintiff to have been infringing/ authorizing the infringement of the
plaintiff’s exclusive rights, copyrights and broadcast reproduction rights):
A. Complete details (such as name, address, email address, phone
number, IP address etc.) of the defendants no. 1 - 3 (and any such
other websites/UIs which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff to have been
infringing/ authorizing the infringement of the plaintiff’s exclusive
rights, copyrights).
B. Mode of payment along with payment details used for registration of
domain name by the registrant i.e., defendant no. 1 – 3 (and any such
other websites/UIs which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff to have been
infringing/ authorizing the infringement of the plaintiff’s exclusive
rights, copyrights).
42.

The defendants No. 9 to 17 shall ensure compliance with this order by

blocking defendants no. 1 to 3 websites, their URLs and the respective UIs
as filed along with the suit (Pg 1 - Vol 1) (also annexed herewith as
annexure - A) and any other apps/websites notified by the plaintiff by filing
of an affidavit.
43.

Defendants no. 18 and 19 are further directed to take immediate steps

and issue requisite notifications within five working days, calling upon

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 8 of 10

<!-- page 67 -->

various internet and telecom service providers registered under them to
block the aforementioned websites/UIs identified by the plaintiff.
44.

Further, the plaintiff shall, within one week of having filed such an

affidavit, move an appropriate application for impleadment of the
aforementioned websites/UIs notified by the plaintiff.
45.

Compliance under Order XXXIX Rule 3 of the Code of Civil

Procedure, 1908 (CPC) be done within one week from today.
46.

List before the Joint Registrar on 4th December, 2024 for completion

of service and pleadings.
47.

List before the Court on 27th February, 2025.
AMIT BANSAL, J

SEPTEMBER 26, 2024
kd

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 9 of 10

<!-- page 68 -->

ANNEXURE - A

LIST OF WEBSITES / DOMAINS PROVIDING ACCESS TO THE .APK
FILES OF ROGUE APPS

S.NO

WEBSITES

1.

https://movieblast.rocks/

2.

https://movieshubapk.com/

3.

https://novatv.app/

LIST OF DOMAINS PROVIDING USER INTERFACE (UI) FOR
FUNCTIONING OF THE ROGUE APPS

S.NO

This is a digitally signed order.

WEBSITES

1.

mb.movieblast.rocks

2.

movapp.techmirrorhublinks.site

3.

https://teatv.xyz

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 10 of 10

<!-- page 69 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
