---
doc_id: "c5b2ceba4c75ffb1"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/79b24cd818629d767ad6d17836e90120.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Industrial Development Scheme for Himalayan States - Jammu & Kashmir - amendments made by notification dated 10.10.2018"
date: "2025-06-30"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "079e3a0e426824be"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx I—[k.M 1
PART I—Section 1
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 333]

ubZ fnYyh] cq/okj] vDrwcj 10] 2018@vkf'ou 18] 1940

No. 333]

NEW DELHI, WEDNESDAY, OCTOBER 10, 2018/ASVINA 18, 1940

वािणय और उ ोग मंालय
(औोिगक नीित एवं संवधन िवभाग)
अिधसूचना

नई दली, 10 अ तूबर, 2018
.—के  सरकार ‘जमू और कमीर हेतु औ

ोिगक िवकास योजना, 2017’
2017’
शीषक वाली भारत सरकार क अिधसूचना संया 2(2)/2018-एसपीएस दनांक 23 अ!ैल, 2018 म' िन(िलिखत
सं. 2(2)/2018
)/2018-एसपीएस

संशोधन करती हैः

2.

‘

अिनवाय अपे+ा’ शीषक के पैरा 7 के तहत मौजूदा उप-पैरा 7.5 को एत5वारा िन(ानुसार संशोिधत कया

जाता है:—

इसके थान परः 15.06.2017 को अथवा उसके प8ात उ9पादन आरं भ करने वाली इकाइय< को 30.09.2018
तक डीआईपीपी म' पंजीकरण कराने क अनुमित होगी।
2017 को अथवा उसके प8ात उ9पादन आरंभ करने वाली इकाइय< को 31.10.2018 तक
डीआईपीपी म' पंजीकरण कराने क अनुमित होगी। इसके बाद अितCरD समय !दान नहE कया जाएगा।
यह पढ़ा जाएः 15.06.

डॉ. वंदना कुमार,

5966 GI/2018

(1)

संयु त सिचव

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

MINISTRY OF COMMERCE AND INDUSTRY
(Department of Industrial Policy and Promotion)
NOTIFICATION
New Delhi, the 10th October, 2018
No. 2(2)/2018-SPS.—The Central Government hereby makes the following amendments in the
Government of India Notification No. 2(2)/2018-SPS dated the 23rd April, 2018 titled ‘Industrial
Development Scheme for Jammu and Kashmir, 2017’.
2. The existing sub para 7.5 under para 7 thereof titled ‘Mandatory requirement’, is hereby amended as
under:FOR: Units which have commenced production on or after 15.06.2017 will be allowed to register with DIPP
up to 30.09.2018.
READ: Units which have commenced production on or after 15.06.2017 will be allowed to register with
DIPP up to 31.10.2018. No further extension will be allowed.
Dr. VANDANA KUMAR, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed by SARVESH

SARVESH KUMAR KUMAR SRIVASTAVA
Date: 2018.10.12 19:13:34
SRIVASTAVA
+05'30'
