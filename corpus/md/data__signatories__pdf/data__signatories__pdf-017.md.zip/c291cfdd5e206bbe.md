---
doc_id: "c291cfdd5e206bbe"
source_url: "https://www.moes.gov.in/static/uploads/2025/07/6f200f1643b85a4a46c4ab53ae63a83b.pdf"
ministry: "Earth Sciences (MoES)"
title: "Tender For Hiring Of Vehicles In Ministry Of Earth Sciences"
date: "2013-05-16"
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "270539565e069d60"
---

<!-- page 1 -->

No.MoES/07/19/2007-Prot.(Pt)
Government of India
Ministry of Earth Sciences
Prithvi Bhawan, IMD Campus
Lodhi Road, New Delhi – 3

On behalf of Hon’ble President of India, Ministry of Earth Sciences invites sealed quotations from
registered transporters situated within the National Capital Territory of Delhi having a fleet of four wheelers
(Cars/Mini Vans/Mini Trucks) DL1T, DL1RX, DL1Y and DL1Z OR DL1V Vehicles (as stipulated by Government of NCT
of Delhi) manufactured after 01.01.2009 to be given on hire (2009‐2012 models). The vehicles should be in
excellent condition registered in the name of the firm or the proprietor’s name for supplying on daily basis as and
when required by the Ministry of Earth Sciences, ‘Prithvi Bhavan’, Lodi Road, New Delhi‐110 003 or NCMRWF A‐50,
Institutional Area, Sector‐62, Noida, U.P.‐201307. The quotation should be forwarded in the prescribed tender
document. The Tender form may be obtained directly from Administrative Officer (General) of this
Ministry on payment of Rs.1000/- against demand draft or downloaded from this Ministry’s website
www.moes.gov.in. In later case, the interested firm must submit a draft of Rs.1000/- in f/o DDO, MoES
along with the bids for further consideration.
The complete tender may be submitted to the undersigned within 21 days from the date of publication of
this tender notice in the newspapers. The complete details of the tender are available in the Ministry’s
website (www.moes.gov.in) and CPP portal (www.eprocure.gov.in).
Any corrigendum/addendum regarding this tender will be available in the above said websites only.

Administrative Officer(GA)
Tel:-24669596

<!-- page 2 -->

Tender Document for Hiring of Vehicles
Document Control Sheet
Tender Document No.

MoES/7/19/2007-Prot.(Pt.) dt.

Name of the Ministry

Ministry of Earth Sciences

Date of Issue

25.04.2013

25.04.2013

Last date for sale of tender document

16.05.2013 upto 03.00 pm

Last date for submission of queries, if any
Publication of addendum based on queries on the
website of MoEs
Last Date & Time for Receipt of Bids

06.05.2013 upto 05.00 pm
10.05.2013 at 5.00 pm

Date & Time of Opening of Technical Bids

16.05.2013 at 4.00 pm

Place of Opening of Bids

Conference Hall

Address of Communication

Administrative Officer (GA), Ministry of Earth
Sciences, ‘Prithvi Bhavan’, Lodi Road,
New Delhi-110003

16.05.2013 at 3.00 pm

Note : This tender document is not transferable

Ministry of Earth Sciences

<!-- page 3 -->

F.No.MoES/7/19/2007-Prot(Pt.)
Ministry of Earth Sciences
Government of India
Prithvi Bhavan
Lodhi Road, New Delhi
Dated: 25th April, 2013
NOTICE INVITING TENDER
(Closing date 3.00 PM on 16.05.2013)
Ministry of Earth Sciences (MoES) intends to hire 12-14 vehicles commercial cars
[Category-A:8-9 cars (TATA Indigo / Maruti Swift Dzire/Toyata Etios) and Category-B
(Innova / SX4/ Honda City) 4-5 cars] on monthly basis of its official use. The Ministry may also
hire bigger commercial vehicles like Toyota Innova / Mahindra Scorpio / Chevrolet Tavera, etc.,
on per day basis for temporary duties. Monthly hiring shall be initially for a period of one year.
Authorized tour / taxi operators having no less than 25 commercial vehicles owned / under lease
agreement may drop their tenders latest by 16th April, 2013 before 3.00 PM in the tender box of
Ministry of Earth Sciences kept at Ground Floor, Prithvi Bhavan, Lodhi Road, New Delhi – 110
003.
2.
The bid shall consist of two parts – Technical bid and Price bid. Both the bids are to be
placed in two separate sealed envelopes (clearly superscribing ‘Technical Bid’ and ‘Price Bid’),
which in turn are to be placed in one sealed cover. The Bids of all the parties whose Price Bid is
not in a separate sealed cover or the rates quoted by them are mentioned in their Technical Bid
shall be rejected forthwith. All the information sought under the head ‘Terms and Conditions’
and ‘Information to be supplied with technical bid’ is to be given in Technical Bid while Price
quoted for the same will have to be mentioned ‘only in the Price Bid’. The price bids of only
those parties shall be opened whose Technical Bids are found to be eligible while the
disqualified bidders Price bid shall be returned unopened.
3.
An earnest money amounting to Rs. 2.0 lac (Rs. Two lac only) in the form of Demand
Draft / Pay order drawn in favour of the Drawing & Disbursing officer (DDO), Ministry of Earth
Sciences, payable at New Delhi has to be enclosed with the Technical bid failing which the
Technical bid shall be rejected.
4.
The envelope containing the quotation form must be super scribed “quotation for hiring
of vehicles (TATA Indigo / Maruti Swift Dzire / Toyota Etios / Maruti Sx4/Innove/Honda City,
etc.)” and should be dropped in the tender box on or before the closing date.
5.
The Technical bids shall be opened in room No.1, Ground Floor, Prithvi Bhavan on the
closing date at 4.00 PM in the presence of one representative of each of the bidder who wishes
to be present. The Price shall be opened after evaluation of Technical bid.

<!-- page 4 -->

6.
The rate of hiring of vehicles should be quoted for 2400 kms [for 10 hours a day, 28 days
(for 30 days month) / 29 days (for 31 days month) in a month] per month for vehicles of the
required category. Tenders should quote the rate separately for petrol, Diesel and CNG driven
vehicles. Tenders quoting rates for CNG driven vehicles shall also submit necessary permits /
registration issued by the appropriate authority allowing them to use CNG.
7.
Tenders documents & terms & conditions regarding above may be directly down-loaded
from the Ministry’s website www.moes.gov.in
Terms and Conditions
The interested parties must be capable of providing vehicles on their own on the
following terms and conditions:1. The make of the vehicles should be specified separately & the model should be 2009
or 2010 onward and should be white / grey in colour. All the vehicles must have
valid taxi permit to run in the NCR region. The firm should submit the proof of
having necessary permits. Tenders quoting rates for CNG driven vehicles shall also
submit necessary permits / registration issued by the appropriate authority allowing
them to use CNG.
2. The successful bidder shall have to provide the desired number of vehicles. The
Ministry may require 8-9 cars of category-A and 4-5 cars of Category-B.
3. The bidder should have past experience of providing minimum to vehicles on
monthly hire basis for one year to at least one government organization / PSU during
last three years. Proof of providing the vehicles should be attached with the technical
bid.
4. The vehicles shall be at the disposal of MoES for 6 days a week (Monday to
Saturday). However, the user officers may require vehicles on Sundays also and the
contractor should be able to provide the earmarked vehicles on Sundays or substitute
vehicles in good condition only if the earmarked vehicles are not available due to
servicing / repair etc.
5. Contract charges include monthly hire charges of vehicles alongwith driver, all repair
and maintenance charges of vehicles, insurance, Petrol/Diesel/CNG, engine oil /
lubricants and also any other incidental expenses. Parking / toll charges, if any, may
be claimed by producing valid parking/toll slips alongwith monthly bills.
6. In the case of any accident, all the claims arising out of it shall be met by the
contractor.
7. The vehicles will be kept neat and clean and in perfect running condition and
provided with clean seat covers, curtains, perfume and tissue paper. All vehicles
should have good upholstery.
8. If any vehicle goes out of order, the contractor shall provide a substitute vehicle
immediately. In case the substitute vehicle doesn’t report on time/does not report at
all, the MoES/user officer would have a right to hire a vehicle from the market & the
additional cost incurred by the MoES / user officer will be borne by the contractor.

<!-- page 5 -->

9. Payment shall be made on presentation of the bill on monthly basis.
10. The drivers should have valid driving license & the vehicles should be registered with
the concerned authorities of Central / State Government. A certificate to this effect
should be provided. The drivers of the vehicles should be familiar with Delhi roads,
well disciplined and must follow traffic rules and other regulations prescribed by the
Government from time to time.
11. The contract between the MoES and the contractor can be cancelled by giving prior
notice of at least 45 days by the contractor. The MoES reserves the right to terminate
the contract at any time or stage during the period of contract, by giving seven days
notice in writing without assigning any reason and without incurring any financial
liability whatsoever to the contractor.
12. Penalty for breach of terms & condtions:
(i)

No payment will be made for vehicles supplied by the Service Provider older
than forty eight months on the day of engagement of the vehicles for duty at
MoES.
(ii)
An amount @ Rs. 200/- per driver per day shall be deducted from the monthly
bill if any driver(s) is/are found not wearing the approved uniform while on
duty or not obeying traffic rules or undisciplined / discourteous.
(iii) An amount of Rs. 1000/- per vehicles per occasion would be deducted from
the monthly bill for absence of drivers during duty hours.
(iv)
An amount of Rs. 2000/- per vehicles per occasion would be deducted from
the monthly bill for absence of drivers from duty during extra hours.
(v)
In case the service provider is unable to provide vehicle(s) on any particular
day(s), an amount of Rs. 2000/- per vehicle per day shall be deducted from the
monthly bill in addition to deduction of hiring charges or pro-rata basis.
13. The drivers and supervisors of the service provider engaged for duty at MoES should
be courteous and well behaved while dealing with MoES officers and vehicles users.
In the event of any complaint of misbehaviour against any driver or supervisor of the
service provider, the MoES reserves the right to insist for immediate removal of the
driver / supervisor from the duties of MoES and the service provider shall be under
obligation to comply to such instruction within twenty four hours.
14. The Drivers must observe all the etiquette and protocol while performing the duty.
He must be neatly dressed, should wear proper uniform and must carry a mobile
phone in working condition for which no separate payment shall be made by
Department.
15. The contractor and drivers shall be bound to carry out the instructions of the MoES as
well of the officers assigned to the vehicles.
16. A daily record indicating time and mileage for each vehicle shall be maintained in a
log book. The log book shall be got signed by the user officer or his personal staff
(PA/PS/PPS) on regular basis.
17. Dedicated vehicles & Drivers must be provided and changes will be allowed only in
exceptional circumstances. The vehicles must be available at any time of any day as
desired by the user officer concerned.
18. The MoES reserves the right to accept or reject any or all quotations without
assigning any reasons.

<!-- page 6 -->

19. In the event of the award of the tender and prior execution of the contract, the
contractor shall be required to submit copies of the Registration Certificate &
comprehensive Insurance Policies of the vehicles being offered for hire & particulars
with photographs of the drivers dedicated to each vehicle. He shall also be required
to produce the vehicles in the office of the undersigned for the physical
verification/inspection.
20. This contract will be effective for duration of one year from the date of signing the
contract unless terminated earlier as per clauses No. 11. The contract may be
renewed for a further period of one year as mutually agreed upon, subject to
satisfactory performance.
21. An interest free refundable performance security deposit equal to 8% of the annual
cost of the tender in the form of Bank Guarantee in favour of the Drawing &
Disbursing Officer(DDO), Ministry of Earth Sciences, New Delhi shall be submitted
by the successful bidder at the time of the award of the contract. The performance
Security will remain valid for a period of sixty day beyond the date of completion of
all contractual obligations. The annual cost of the tender for the purpose shall be
calculated on the basis of fixed monthly charges of all vehicles hired by MoES. The
security deposit shall be discharged after satisfactory completion of the contract
period. If the Service Provider fails or neglects any of his obligations under the
contract it shall be lawful for MoES to forfeit either whole or any part of performance
security furnished by the bidder as compensation for any loss resulting from such
failure. The Ministry may also blacklist the service provider due to failure of services
or major negligence in providing service.
22. Rates of hiring the vehicles will be fixed during the period of contract and no request
for revision of rates will be entertained, under any circumstances.
23. Counting of distance will be from the starting point of the user officer and closing at
the point where the user officer completes his/her journey. The distance covered in
each way between reporting address and the garage / normal parking place will be
allowed on actual basis or 8 kilometres, whichever is less.
24. Counting of time will start from the starting point of the user officer and closing at the
point where the user officer completes his/her journey.
25. Duty hours of the vehicles shall be calculated on monthly accumulation basis counted
in the manner prescribed in para 23 above.
26. Total kilometre run by the vehicles shall also be calculated on monthly accumulation
basis counted in the manner prescribed in para 22 above.
27. The contractor shall not deploy vehicles hired by the MoES for any other purpose or
any other business during the validity of the contract.
28. All Govt. Tax / Levy / Duty other than Service Tax for plying the vehicles in Delhi
State will be borne by the Service Provider. The office will deduct income Tax at
Source under Section 194-C of Income Tax Act from the contractor at the prevailing
rates of such sum as income tax on the income comprised therein or any other
statutory tax as applicable.
29. The number of vehicles hired may increase or decrease by 25% depending on actual
requirement.
30. The bid shall remain valid for 180 days from the date of opening of bids. A bid valid
for a shorter period shall be rejected by MoES as non-responsive. A bidder accepting

<!-- page 7 -->

the request of MoES for an extension to the period of bid validity, in exceptional
circumstance, will not be permitted to modify his bid.
31. The earnest money (bid security) may be forfeited:
(i)
If bidder withdraws his bid during the period of bid validity;
(ii)
If the successful bidder fails to sign contract or to furnish performance
security.
(iii) The bid security of unsuccessful bidder will be discharged / returned as early
as possible but not before finalization of contract with the successful bidder.
Debarring Conditions:(i)
(ii)

(iii)

(iv)

No vehicle should be supplied having registration in the name of employee of
MoES or their close relative.
No sub-contracting of the Service allotted is permissible by MoES. The near
relatives of all MoES employees either directly recruited or on deputation are
prohibited from participation in this tender.
The tampering of meter reading, vehicle usage timings, overwriting of
Summary / log sheet and misbehaviour of driver while on duty shall be
viewed seriously, leading to even cancellation of contract.
The contractor shall not engage any person below 18 years of age.

MoES will not have obligation:(i)

No liability whatsoever for payment of wages / salaries other benefits and
allowances to his personnel that might become applicable under any Act or
Order of the Govt. in this regard and the Service Provider shall indemnify
MoES against any / all claims which may arise under the provisions of
various Acts, Government Orders etc. and any breach of such laws or
regulations shall be deemed to be breach of this contract.
(ii)
No direct or indirect liability arising out of such negligent, rash and
impetuous driving which is an offence under section 29 of IPC and any loss
caused to MoES have to be suitably compensated by the contractor.
(iii) Not be responsible for theft, burglary, fire or any mischievous deeds by his
staff.
(iv)
The contractor shall be the employer for his workers and MoES will not be
held responsible fully or partially for any dispute that may arise between the
contractor and his workers.
Arbitration:
In the event of any question, dispute or difference arising under the agreement or
in connection there with (except as to the matters, the decision to which is specifically
provided under this agreement), the same shall be referred to sole arbitration of Secretary,
Ministry of Earth Sciences (MoES) or any other person appointed by him. The award of
the arbitrator shall be final and binding on both the parties. Contractor will have no
objection in any such appointment that arbitrator so appointed is an employee of MoES

<!-- page 8 -->

or a Government Servant or that he has to deal with the matter to which the agreement
relates or that in the course of his duties as MoES employee he has expressed his views
on all or any of the matter in dispute. The adjudication of such Arbitrator shall be
governed by the provisions of the Arbitrator and Conciliation Act 1996, or any statutory
modification or re-enactment three of or any rules made thereof.
The venue of Arbitration proceeding shall be Office of MoES at New Delhi or such other
place as the arbitrator may decide.
The arbitrator may from time to time with the consent of both the parties enlarge
the time frame for making and publishing the award. Subject to aforesaid arbitration and
conciliation Act, 1996 and the rules made three under, any modification thereof for the
time being in force shall be deemed to apply to the arbitration proceeding under this
clause.
The courts at Delhi shall have the jurisdiction to decide any dispute that may arise
in relation to the contract.
Pre-contract Integrity Pact:
The successful bidder shall enter into a pre-contract integrity pact with the
designated officer of the Ministry. Format of the pre-contract integrity pact is given at
Annexure.
Administrative Officer(GA)

<!-- page 9 -->

Technical Bid
(For providing vehicles to MoES on monthly hiring basis)
1. Name & Address of the bidder.
2. Nature of business.
3. Self attested copy of PAN Card and ITR for last three financial years.
4. Self attested copy of Service Tax & Registration No.
5. Number of vehicles owned by the bidder alongwith proof of ownership.
6. Number of vehicles hired by the bidder and lease agreement with the owners
of the hired vehicles at the disposal of the bidder.
7. Annual turnover in the past 3 financial years duly certified by a Chartered
Accountant.
8. An undertaking to the effect that the Agency/Firm has not been blacklisted by
any of the Ministry/Deptt. Or Govt. Agency.
9. Details of vehicles provided to Central / State Government Ministries /
Department / PSUs during last three years.
10. Name and address of other parties to whom vehicles were given on monthly
hire during last three years.

11. Period for which engaged in the business of taxi service / tour operator.
12. Registration details of vehicles proposed to be provided to MoES on monthly
hiring basis.
13. Permit for running of vehicles in Delhi, UP and Haryana.

Note:

1. All documents related to above information should be
signed by the bidder.
2. All pages of technical bid should be serially numbered.

<!-- page 10 -->

PRICE BID
A. The rate for hiring of vehicles should be quoted for 2400 kms (10 hours a day,
28 days(30 days month) / 29 days (31 days month) in a month) per month for
the vehicles of the make of (Tata Indica / Maruti WagonR / TATA Indigo /
Maruti Swift Dzire / Toyota Etios / Maruti Sx4) as per the price bid format.
Price quoted in any other format shall not be considered. The rates for Petrol /
Diesel / CNG run vehicles are to be given separately.
B. Rates for extra km / hours must be separately specified.
C. Rates for cars that may be hired on daily basis must be separately specified for
additional cars required on temporary basis.

<!-- page 11 -->

Price Bid – I
(For providing vehicles to MoES on monthly hiring basis)
Names, Address & telephone No. of bidder:

Sr.

Rate of vehicles to

No.

be

hired

on

RATE in Rs.
Tata Indigo / Toyota
Etios

Monthly basis for

Innova/

Maruti

Sx4/Honda City

Maruti Swift Dzire

2400 kms.

RATE in Rs.

(2009

or

(2009 or later

model only)

model only)

Category - B

later

Category – A
Petrol

1

Diesel

CNG

Petrol

Diesel

CNG

Per month [10 hours
a day and 28/29 days
(for

30/31

days

month) in a month]
2

For

every

Kilometer

extra
beyond

2400 Kms.
3

For every extra hour
beyond 10 hrs. per
day
Note: 1.
2.

Rates should be quoted in both figures and words.
Service Tax extra as applicable.

Signature of the bidder with date and office seal:
Note:

For the purpose of determination of the lowest bidder (L1), grand total of
following rates shall be considered for each category of vehicles for
monthly hiring(a)
Rate for 2400 kms; plus (b) charges for extra 500 kms (beyond
2400 kms); plus (c) charges for extra 50 hours (beyond 10 hours per day).

<!-- page 12 -->

Price Bid – II
(For providing vehicles to MoES on daily hiring basis)
Name, Address & telephone No. of bidder
Sr. No.

:

Rate of vehicles to Rate for Toyota Innova /
be hired on per day Mahindra Scorpio
basis
/ Chevrolet Tavera cars
Description
(2010 or later model)

Rate for Tata Indigo /
Toyota Etios
Maruti Swift Dzire
(2010 or later model)

1

Per day (10 hours /
100 Kms.)
2
For every extra hour
after 10 hours
3
For every extra
kilometre
beyond
100 km.
Note: 1.
Rates should be quoted in both figures and words.
2.
Service Tax extra as applicable.

Signature of the bidder with date and office seal:
Note: For the purpose of determination of the lowest bidder (L1), following rates shall
be considered:
(i)

The rate per day (10 hours / 100 km.); plus (ii) charge for extra 5 hours; plus
(iii) charge for extra 50 km.

<!-- page 13 -->

PRE CONTRACT INTERGRITY PACT
General
This pre-bid pre-contract Agreement (hereinafter called the integrity pact) is made on
___________ day of the month of ___________ 2012, between, on one hand, the
President of India acting through Shri_____________, Designation on the officer,
Ministry / Department, Government of India (hereinafter called the “BUYER”, which
expression shall mean and include, unless the context otherwise requires, his successors
in office and assigns) of the First Part of M/s._________ represented by
Shri____________ Chief Executive Officer (hereinafter called the “BIDDER / Seller”
which expression shall mean and include, unless the context otherwise requires, his
successors and permitted assigns) of the Second Part.

WHEREAS the BUYER proposes to procure (Name of the Stores / Equipment / Item)
and the BIDDER / Seller is willing to offer / has offered the stores and
WHEREAS the BIDDER is a private company / public company / Government
undertaking / partnership / registered export agency, constituted in accordance with the
relevant law in the matter and the BUYER in a Ministry / Department of the Government
of India /PSU performing its functions on behalf of the President of India.
NOW, THEREFORE,
To avoid all forms of corruption by following a system that is far, transparent and free
from any influence / prejudiced dealings prior to, during the subsequent to the currency
of the contract to be entered into with a view to:Enabling the BUYER to obtain the desired said store / equipment at a competitive price
conformity with the defined specifications by avoiding the high cost and the distortionary
impact of corruption on public procurement, and
Enabling BIDDERs to abstain from bidding or indulging in any corrupt practice in order
to secure the contract by providing assurance to them that their competitors will also
abstain from bribing and corrupt practices and the BUYER will commit to prevent
corruption, in any form, by its officials by following transparent procedures.
Commitments of the BUYER
1.1

The BUYER undertakes that no official of the BUYER, connect directly or
indirectly with the contract, will demand, take a promise for or accept, directly or
through intermediaries, any bribe, consideration, gift, reward, favour or any
material or immaterial benefit or any other advantage from the BIDDER, either
for themselves or for any person, organization or third party related to the contract
in exchange for an advantage in the bidding process, bid evaluation, contracting or
implementation process related to the contract.

1.2

The BUYER will during the pre-contract stage, treat all BIDDERs alike, and will
provide to all BIDDERs the same information and will not provide any such

<!-- page 14 -->

information to any particular BIDDER which could afford an advantage to that
particular BIDDER in comparison to other BIDDERs.
1.3

All the officials of the BUYER will report to the appropriate Government office
any attempted or completed breaches of the above commitments as well as any
substantial suspicion of such a breach.

2.

In case any such preceding misconduct on the part of such official(s) is reported
by the BIDDER to the BUYER with full and verifiable facts and the same is
prima facie found to be correct by the BUYER, necessary disciplinary
proceedings, or any other action as deemed fit, including criminal proceedings
may be initiated by the BUYER and such a person shall be debarred from further
dealing related to the contract process. In such a case while an enquiry is being
conducted by the BUYER the proceedings under the contract would not be stalled.

Commitments of BIDDERs
3.
The BIDDER commits itself to take all measures necessary to prevent
corrupt practices, unfair means and illegal activities during any stage of its bid or
during any pre-contract or post-contract stage in order to secure the contract or in
furtherance to secure it and in particular commit itself to the following:3.1
The BIDDER will not offer, directly or through intermediaries, any bribe,
gift consideration, reward, favour, any material or immaterial benefit or other
advantage, commission, fees, brokerage or inducement to any officials of the
BUYER, connected directly or indirectly with the bidding process, or to any
person, organization or third related to the contract in exchange for any advantage
in the bidding, evaluation contracting and implementation of the contract.
3.2
The BIDDER further undertakes that it has not given, offered or promised
to give, directly or indirectly any bribe, gift, consideration, reward, favour, any
material or immaterial benefit or other advantage, commission, fees, brokerage or
inducement to any official of the BUYER or otherwise in procuring the contract
or forbearing to do or having done any act in relation to the obtaining or execution
of the contract or any other contract with the Government for showing or
forbearing to show favour or disfavour to any person in relation to the contract or
any other contract with the Government.
3.3
The BIDDER, either while presenting the bid or during pre-contract
negotiations or before signing the contract, shall disclose any payments he has
made, is committed to or intends to make officials of the BUYER or their family
members, agents, brokers or any other intermediaries in connection with the
contract and the details of services agreed upon for such payments.
3.4
The BIDDER will not collude with other parties interested in the contract
to impair the transparency, fairness and progress of the bidding process, bid
evaluation, contracting and implementation of the contract.
3.5
The BIDDER will not accept any knowledge in exchange for any corrupt
practice, unfair means and illegal activities.
3.6
The BIDDER shall not use improperly, for purposes of competition or
personal gain, or pass on to others, any information provided by the BUYER as

<!-- page 15 -->

part of the business relationship, regarding plans, technical proposals and business
details including information contained in any electronic data carrier. The
BIDDER also undertakes to exercise due and adequate care lest any such
information is divulged.
3.7
The BIDDER commits to refrain from giving any complaint directly or
through any other manner without supporting it with full and verifiable facts.
3.8
The BIDDER shall not instigate or cause to instigate any third person to
commit any of the actions mentioned above.
3.9
If the BIDDER or any employee of the BIDDER or any person acting on
behalf of the BIDDER, either directly or indirectly, is a relative of any of the
officers of the BUYERS, or alternatively, if any relative or an officer of the
BUYER has financial interest / stake in the BIDDER’s firm, the same shall be
disclosed by the BIDDER at the time of filing of tender.
The term ‘relative’ for this purpose would be as defined in Section 6 of the
Companies Act 1956.
3.10 The BIDDER shall not lend to or borrow any money from or enter into
any monetary dealing or transactions, directly or indirectly, with any employee of
the BUYER.
4.

Previous Transgression

4.1
The BIDDER declares that no previous transgression occurred in
the last three years immediately before signing of this integrity Pact, with any
other company in any country in respect of any corrupt practices envisaged
hereunder or with any Public Sector Enterprises in India or any Government
Department of India that could justify BIDDER’s exclusion from the tender
process.
4.2
The BIDDER agrees that if it makes incorrect statement on this
subject, BIDDER can be disqualified from the tender process or the contract, if
already awarded, can be terminated for such reasons.

5.

Earnest Money (Security Deposit)

5.1
While submitting commercial bid, the BIDDER shall deposit an
amount ____________ (to be specified in RFP) as Earnest Money / Security
Deposit, within the BUYER through any of the following instruments:
(i)
Bank Draft or a Pay Order in favour of _______________
(ii)
A confirmed guarantee by an Indian Nationalised Bank, promising
payment of the guaranteed sum to the BUYER on demand within three working
days without any demur whatsoever and without seeking any reason whatsoever.
The demand for payment by BUYER shall be treated as conclusive proof of
payment.
(iii) Any other mode or through any other instruments (to be specified
in the RFP).

<!-- page 16 -->

5.2
The Earnest Money / Security Deposit shall be valid upto a period
of five years or the complete conclusion of the contractual obligations to the
completed satisfaction of both the BIDDER and the BUYER, including warranty
period, whichever is later.
5.3
In case of the successful BIDDER a clause would also be
incorporated in the Article pertaining to Performance Bond in the Purchase
Contract that the provisions of Sanctions for Violation shall be applicable for
forfeiture of Performance Bond incase of a decision by the BUYER to forfeit the
same without assigning any reason for imposing sanction for violation of this
Pact.
5.4
No interest shall be payable by the BUYER to the BIDDER on
Earnest Money / Security Deposit for the period of its currency.
6.

Sanctions for Violations

6.1
Any breach of the aforesaid provisions by the BIDDER or any one
employed by it or acting on its behalf (whether with or without the knowledge of
the BIDDER) shall entitle the BUYER to take all or any one of the following
actions, wherever required:(i)
To immediately call off the pre contract negotiations without
assigning any reasons or giving any compensation to the BIDDER. However, the
proceedings with the other BIDDER’s would continue.
(ii)
The Earnest Money Deposit (in pre-contract stage) and/or Security
Deposit / Performance Bond (after the contract is signed) shall stand forfeited
either fully or partially, as decided by the BUYER and the BUYER and the
BUYER shall not be required to assign any reason therefore.
(iii)
To immediately cancel the contract, if already signed, without
giving any compensation to the BIDDER.
(iv)
To recover all sums already paid by the BUYER, and in case of an
Indian BIDDER with interest thereon at 2% higher than the prevailing Prime
Lending Rate of State Bank of India, while in case of BIDDER from a country
other than India with interest thereon at 2% higher than the LIBOR. If any
outstanding payment is due to the BIDDER from the BUYER in connection with
any other contract for any other stores, such outstanding payment could also be
utilized to recover the aforesaid sum and interest.
(v)
To encash the advance bank guarantee and performance bond /
warranty bond, if furnished by the BIDDER, in order to recover the payments,
already made by the BUYER, along with interest.
(vi)
To cancel all or any other contracts with the BIDDER. The
BIDDER shall be liable to pay compensation for any loss or damage to the
BUYER resulting from such cancellation / recession and the BUYER shall be
entitled to deduct the amount so payable from the money)s) due to the BIDDER.

<!-- page 17 -->

(vii) To debar the BIDDER from participating in future bidding
processes of the Government of India for a minimum period of five years, which
may be further extended at the discretion of the BUYER.
(viii) To recover all sums paid in violation of this Pact by BIDDER(s) to
any middlemen or agent or broker with a view to securing the contract.
(ix)
In case where irrevocable letter of Credit have been received in
respect of any contract signed by the BUYER with the BIDDER, the same shall
not be opened.
(x)
Forfeiture of Performance Bond in case of a decision by the
BUYER to forfeit the same without assigning any reason for imposing sanction
for violation of this Pact.
7.

Fall Clause

7.1
The BIDDER undertakes that it has not supplied / is not supplying
similar products / systems or subsystems at a price lower than that offered in the
present bid in respect of any other Ministry / Department of the Government of
India or PSU and if it is found at an stage that similar product / systems or sub
systems was supplied by the BIDDER at any other Ministry / Department of the
Government of India or a PSU at a lower price, that very price, with due
allowance for elapsed time, will applicable to the present case and difference in
the cost would be refunded by the BIDDER to the BUYER., if the contract has
already been concluded.
8.

Independent Monitors

8.1
The BUYER has appointed independent Monitors (hereinafter
referred to a Monitors) for this Pact in consultation with the Central Vigilance
Commission (Names and Address of the Monitors to be given)
8.2
The task of the Monitors shall be to review independently and
objectively, whether and to what extent the parties comply with the obligations
under the Pact.
8.3
The Monitors shall not be subject to instructions by the
representatives of the parties and perform their functions neutrally and
independently.
8.4
Both the parties accept that the Monitors have the right to access
all the documents relating to the project / procurement, including minutes of the
meetings.
8.5
As soon as the Monitor notices, or has reason to believe, a
violation of this Pact, he will so inform the Authority designated by the BUYER.
8.6
The BIDDER(s) accepts that the Monitor has the right to access
without restriction to all Project documentation of the BUYER including that
provided by the BIDDER. The BIDDER will also grant the Monitor, upon his
request and demonstration of a valid interest, unrestricted and unconditional

<!-- page 18 -->

access to this project documentation. The same is applicable to Subcontractors.
The Monitor shall be under contractual obligation to treat the information and
documents of the BIDDER / Subcontractor(s) with confidentiality.
8.7
The BUYER will provide to the Monitor sufficient information
about all meeting among the parties related to the Project provided such meetings
could have an impact on the contractual relations between the parties. The parties
will offer to the Monitor the option to participate in such meetings.
8.8
The Monitor will submit a written report to the designated
Authority of BUYER / Secretary in the Department / within 8 to 10 weeks from
the date of reference or intimation to him by the BUYER / BIDDER and, should
be occasion arise, submit proposals for correcting problematic situations.
9.

Facilitation of Investigation

In case of any allegation of violation of any provisions of this Pat or payment of
commission, the BUYER or its agencies shall be entitled to examine all the
documents including the Books of Accounts of the BIDDER and the BIDDER
shall provide necessary information and documents in English and shall extend all
possible help for the purpose of such examination.
10.

Law and Place of Jurisdiction

This Pact is subject to Indian Law.
jurisdiction is seat of the BUYER.
11.

The place of performance and

Other Legal Actions

The actions stipulated in this Integrity Pact are without prejudice to any other
legal action that may follow in accordance with the provisions of the extant law in
force relating to any civil or criminal proceedings.
12.

Validity

12.1 The validity of this Integrity Pact shall be from date of its signing
and extend upto 5 years or the completed execution of the satisfaction of both the
BUYER AND BIDDER / Seller, including warranty period, whichever is later. In
case BIDDER is unsuccessful, this Integrity Pact shall expire after six months
from the date of the signing of the contract.
12.2 Should one or renewal provisions of this Pact turn out to be
invalid; the remainder of this Pact shall remain valid. In this case, the parties will
strive to come to an agreement to their original intentions.

<!-- page 19 -->

13.

The parties hereby sign this Integrity Pact at________ on _________

BUYER
Name of the Officer

BIDDER
CHIEF EXECUTIVE OFFICER

Designation
Deptt./ Ministry / PSU

Witness

Witness

1._______________________

1._______________________

2._______________________

2._______________________

*Provision of these clauses would need to be amended / deleted in line with the
policy of the BUYER in regard to involvement of the Indian agents of foreign
suppliers.
