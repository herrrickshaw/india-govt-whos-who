---
doc_id: "c5f1caea55d5d3f7"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/e284b963e2c5c5673bd39183c2db89e4.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Framing of Recruitment Rules to the post of Biomedical Engineer, RHTC Hospital"
date: "2024-11-10"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0f8ed42e9ed1bec3"
---

<!-- page 1 -->

F.No.A. 1 20 1 8 I I 412024-MH-II (FTS:-8259966)

Govemment of India

Ministry of Health and Family Welfare
Department of Health and Family Welfare

Nirman Bhavan New Delhi-ll00ll
Dated 27th September, 2024

NOTICE
This Ministry is examining a proposal for framing of Recruitment Rules
for the posts of Biomedical Engineer in RHTC Hospital, Najafgarh, Directorate
General of Health Services, Ministry of Health & Family Welfare. In this regard,

dralt Recruitment Rules have been approved by the Competent Authority.

2.

Before taking up the proposal for framing the Recruitment Rules with

the DoP&T and other agencies for finalizing the Recruitment Rules, comments,

if any, are invited from all stakeholders in the matter within a period of thirty
days from the date of notification in the website of the Ministry of Health and

Family Welfare. The objections/suggestions received from the stakeholders

within the specified period shall be considered by the Ministry .rs per
rules/requirement.

3.

The comments may be fumished to the undersigned in Room No. 401-D,

D Wing, Nirman Bhawan, New Delhi-l100ll and the soft copy may be sent to
anuradha.ramakrishan@nic.in .

o-k,

J-,y

(Anuradha Ramakrishnan)
Under Secretary to Govt. of India

Teli2306l640

<!-- page 2 -->

GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE
RURAL HEALTH TRAINING CENTRE
NAJAFGARH, NEW DELHI-I I OO43
Notification

G,S,R......-ln exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules regulating the method of recruitment to the post of
Biomedical Engineer, in the Ministry of Health and Family welfare, RHTC Hospital, New Delhi,
namely;

l.

Short title and commencement - (l) These rules may be called the Ministry of Health and
Family Welfare, RHTC Hospital, New Delhi, Bio Medical Engineer (Group-'B' Post) Recruitment
Rules,2024.
(2) They shall come into force on the date oftheir publication in the Ofiicial Gazette.

2.

Number of post, classification, level in pay matrix - The number of the said posl its

classification and level in the pay matrix attached thereto shall be as specified in columns (2) to (4) of
the Schedule annexed to these rules.

3.

Method of rrccruitment, age-limit, qualifications, etc.- The method of recruitment, age-limit,
qualifications and other matters relating to the said post shall be as specified in columns (5) to (13) of
the said Schedule.

4.

Disqualification - No person, 1. who has entered into or contracted a malriage with a person having a spouse living; or

2. who, having a spouse living, has entered into or contracted a marriage with any person,

shall be eligible for appointment to the said post:

Provided that the Central Govemment may, if satisfied $at such marriage is permissible
under the personal law applicable to such person and the other party to the maniage and that there are
other grounds for so doing, exempt any person from the operation ofthis rule.

Power to relax Where the Central Govemment is of the opinion that it is necessary or
expedient so to do, it may, by order, for reasons to be recorded in writing and in consultation with the
Union Public Service Commission, relax any of the provisions of these rules with respect to any

5.

class or category ofpersons.

Saving - Nothing in these rules shall affect reservation, relaxation of age-limit and other
concessions required to be provided for the Scheduled Castes, the Scheduled Tribes, the Other
Backward Classes, the Ex-servicemen and other special categories of person in accordance with the

6.

orders issued by the Centrat Govemment from time to time in this regard.

<!-- page 3 -->

DRAFT SCHEDULE
Recruitment Rules for the post of Biomedical Engineer

AgeJimit for direcl Educational and other
in Whether
qualification required for
pay matrix. selection
recruits.
direct recruits,
post or non

kvel

Nanre of posts. Number ol Classilication.
posts.

selection
post.

(t)

(3)

(z)

Biornedical

*01(2024)

Engineer.

* subject

variation

General Centrall Level 7 inl Not
,"1 Service, Croupl

'B'.

the

payl applicable.

tlon-l matrix (Rs.l

dependent onl Cazetted, Non-l 44900-14241

workload.

Ministerial. 00).
I

I

(7)

(6)

(s)

(4)

l8- 30 Years Degree in
I

Biomedicall

Engineering from ,l
(Relaxable ,",] recognised University o,l
Govemment servantsl insrihrte.
fivel
up to
years
in] Note l: Qualifications arel

I
I

accordance with relaxable at
the instructions or] discretion of
orders issued by the Staff

thel

thel

Selectionl

Centra I

Commission

Govemment).

competent authority f",l

Note : The

oJ

reasons to
crucial in

be recordedl
wriring in the casel

of candidates otherwisel
determining the well qualified.
age-limit shall be
2:
The
as advertised by the Note
date

]

Staff

qualification(s) regarding

Selection
Commission.

experience is relaxable at
the discretion of the Stafll

Selection Commission
or competent authority for
the reasons to be recorded

in writing in the case
of candidates belonging to
Scheduled Castes and
Scheduled Tribes. if at
any stage of selection,

hhe Staff

Selection

lcommirrion or competent
is of the opinion
hhat sufficient number

lauthority
lof

candidates from these

lcommunrtles poss€sstng
[rfr. requisite experience

likely to
lavailable to fill
lare not

be

up

<!-- page 4 -->

he vacancies reserved fo
:hem.

oI ln case of recruitment by promotion lfa
ol Method
Period
Whether
rr by deputation / absorption, grades Departmental
probation, il recruitment
age and
Promotion
whether by lrom
educational rny.
t
Committee
dePutation
which promotion or
direct
qualification
exists, what is
recruitment or by absorption is to be made.
S
its composition.
promotion or
prescribed
by deputation /
for direct
absorption and
recruits will
percentage of the
apply in
vacancies to be
the cas€
filled
of
various
by
promotees.

h Union
mlssron ls
be

nlted in
ing

ritment.

methods.

(e)

(8)
Not
rpplicable.

Direct

Two years I

(12)

l1)

(1 0)
I

recruitment.

Note: fn...l
shall be J Note: Vacanciesl

I

I

Not applicable.

Departmental

ith the Union

confirmation

:blic Service

Committee (
considering

training of atl incumbent beinSl

confirmation)

away

onl

:l

consisting of:

l. Director, Rurall
Health Trainingl

duration fb,'l deputation or long
successful illness or study
I

completion

onsultation

uroup

mandatory | caused by thel
least two weeksl

r3

Centre, Najafgarh-l

leave or under

Chairman;
Hospital /
2.

probation "!
as other

I

I

prescribed by circumstances for
the Central a duration of one
Government.
f"u, o, more may

Medical
Superintendent,

lu" fitled by
ldeputation basis
h.orn officers of
lcentral

I
I
I

I
I
I
I

r.

Member;
I

!. O.puty Director
lAdministration,

lGor..nr"nt ,
I

RHTC Hospital-

Itooking after the
(i)

notaing
analogous

posts on
regular

basis in the

lwork of RHTC.

lHospital

in
lDirectorate General

lof Health Services
l-M"-b"r.
I

ommission is
)t necessary.

<!-- page 5 -->

Department

;or

servlce I

(35400- l r

2400)
and
2.

possessing
the

qualificatio
experience

prescribed
recruits
under

column (7).
