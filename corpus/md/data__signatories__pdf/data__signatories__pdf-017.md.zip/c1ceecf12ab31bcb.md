---
doc_id: "c1ceecf12ab31bcb"
source_url: "https://www.dot.gov.in/static/uploads/2025/12/0299b7906187de1930cfc6708e20a5ba.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "National Communications Academy, Department of Telecommunications, and GSMA Sign MoU to Strengthen Cooperation in Telecom Policy, Research and Capacity Building"
date: "2025-12-24"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "92f6c2734135cd78"
---

<!-- page 1 -->

Press Release:Press Information Bureau

1 of 2

https://www.pib.gov.in/PressReleasePage.aspx?PRID=2183804

Ministry of Communications

National Communications Academy (NCA),
Department of Telecommunications (DoT), and
Indian Institute of Management Calcutta (IIMC)
signed MoU to Strengthen Cooperation in
Telecom Policy, Research and Capacity
Building
Posted On: 29 OCT 2025 4:57PM by PIB Delhi

The National Communications Academy (NCA), Department of Telecommunications (DoT) and
the Indian Institute of Management Calcutta (IIMC) today signed a Memorandum of
Understanding (MoU) at Sanchar Bhawan, New Delhi, in the presence of the Chairman DCC &
Secretary (Telecom), Dr. Neeraj Mittal.
The MoU was formally signed by Prof. Alok Kumar Rai, Director, IIMC, and Shri Atul Sinha,
Director General, National Communications Academy -Technology (NCA-T), Ghaziabad. Prof R
Rajesh Babu, Dean (Executive Education), IIMC, Shri Navneet Chouhan DDG (TS & PR), NCAT and Shri Shashi Shekhar Pandey, Director (Policy Research), NCA-T, were also present on the
occasion.

The MoU establishes a comprehensive collaboration framework between NCA and IIMC. It aims
to promote joint initiatives in capacity building, research, consulting, policy formulation, and
training in emerging domains such as Information and Communication Technologies, Mobile
Communication, and Cyberspace. The MoU underscores a shared commitment to develop
knowledge-driven programs, organize workshops, and creating a platform for policy and advisory
cooperation to strengthen human resource development in the telecommunication sector.
About NCA

29-10-2025, 17:48

<!-- page 2 -->

Press Release:Press Information Bureau

2 of 2

https://www.pib.gov.in/PressReleasePage.aspx?PRID=2183804

The National Communications Academy (NCA), a training institution under Department of
Telecommunications, Ministry of Communications, Govt. of India, engaged in capacity building
of officers/officials belonging to ITS, IRRS cadres and civil service IP&TAFS, contributing to
policy development and human resource capacity for India’s digital growth.
About IIMC
The Indian Institute of Management Calcutta, Kolkata is one of India’s premier business schools
and is renowned for its excellence in management education, research, and entrepreneurship
functioning under the Ministry of Education. IIM Calcutta, the first Indian Institute of
Management established by the Government of India, is a triple-accredited institution and the only
Indian member of the prestigious global CEMS alliance.

Follow DoT Handles for more: X - https://x.com/DoT_India
Insta-https://www.instagram.com/department_of_telecom?igsh=MXUxbHFjd3llZTU0YQ
==
Fb - https://www.facebook.com/DoTIndia
Youtube: https://youtube.com/@departmentoftelecom?si=DALnhYkt89U5jAaa

****
Samrat/Allen
(Release ID: 2183804) Visitor Counter : 59
Read this release in: Urdu , िह�ी

29-10-2025, 17:48
