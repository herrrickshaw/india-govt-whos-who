---
doc_id: "c44db6dc1a4e44da"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/Constitution_102_Amendment636707193978883893.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "The Constitution (One Hundred and Second Amendment) Act, 2018."
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5238e761e2ce14ee"
---

<!-- page 1 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—18

REGISTERED NO. DL—(N)04/0007/2003—18

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 34]

ubZ fnYyh] 'kfuokj] vxLr 11] 2018@ Jko.k 20] 1940 ¼'kd½

No. 34] NEW DELHI, SATURDAY, AUGUST 11, 2018/SHRAVANA 20, 1940 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 11th August, 2018/Shravana 20, 1940 (Saka)
The following Act of Parliament received the assent of the President on the
11th August, 2018, and is hereby published for general information:—

THE CONSTITUTION (ONE HUNDRED AND SECOND
AMENDMENT) ACT, 2018
[11th August, 2018.]

An Act further to amend the Constitution of India.
BE it enacted by Parliament in the Sixty-ninth Year of the Republic of India as follows:—
1. (1) This Act may be called the Constitution (One Hundred and Second Amendment)
Act, 2018.

Short title and
commencement.

(2) It shall come into force on such date as the Central Government may, by notification
in the Official Gazette, appoint.
2. In article 338 of the Constitution, in clause (10), the words, brackets and figures "to
such other backward classes as the President may, on receipt of the report of a Commission
appointed under clause (1) of article 340, by order specify and also" shall be omitted.

Amendment
of article
338.

<!-- page 2 -->

2

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

Insertion of
new article
338B.

3. After article 338A of the Constitution, the following article shall be inserted, namely:—

National
Commission
for Backward
Classes.

“338B. (1) There shall be a Commission for the socially and educationally
backward classes to be known as the National Commission for Backward Classes.
(2) Subject to the provisions of any law made in this behalf by Parliament, the
Commission shall consist of a Chairperson, Vice-Chairperson and three other Members
and the conditions of service and tenure of office of the Chairperson, Vice-Chairperson
and other Members so appointed shall be such as the President may by rule determine.
(3) The Chairperson, Vice-Chairperson and other Members of the Commission
shall be appointed by the President by warrant under his hand and seal.
(4) The Commission shall have the power to regulate its own procedure.
(5) It shall be the duty of the Commission—
(a) to investigate and monitor all matters relating to the safeguards provided
for the socially and educationally backward classes under this Constitution or
under any other law for the time being in force or under any order of the
Government and to evaluate the working of such safeguards;
(b) to inquire into specific complaints with respect to the deprivation of
rights and safeguards of the socially and educationally backward classes;
(c) to participate and advise on the socio-economic development of the
socially and educationally backward classes and to evaluate the progress of
their development under the Union and any State;
(d) to present to the President, annually and at such other times as the
Commission may deem fit, reports upon the working of those safeguards;
(e) to make in such reports the recommendations as to the measures that
should be taken by the Union or any State for the effective implementation of
those safeguards and other measures for the protection, welfare and
socio-economic development of the socially and educationally backward classes;
and
(f ) to discharge such other functions in relation to the protection, welfare
and development and advancement of the socially and educationally backward
classes as the President may, subject to the provisions of any law made by
Parliament, by rule specify.
(6) The President shall cause all such reports to be laid before each House of
Parliament along with a memorandum explaining the action taken or proposed to be
taken on the recommendations relating to the Union and the reasons for the
non-acceptance, if any, of any of such recommendations.
(7) Where any such report, or any part thereof, relates to any matter with which
any State Government is concerned, a copy of such report shall be forwarded to the
State Government which shall cause it to be laid before the Legislature of the State
along with a memorandum explaining the action taken or proposed to be taken on the
recommendations relating to the State and the reasons for the non-acceptance, if any,
of any of such recommendations.
(8) The Commission shall, while investigating any matter referred to in
sub-clause (a) or inquiring into any complaint referred to in sub-clause (b) of clause (5),

<!-- page 3 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

have all the powers of a civil court trying a suit and in particular in respect of the
following matters, namely:—
(a) summoning and enforcing the attendance of any person from any part
of India and examining him on oath;
(b) requiring the discovery and production of any document;
(c) receiving evidence on affidavits;
(d) requisitioning any public record or copy thereof from any court or
office;
(e) issuing commissions for the examination of witnesses and documents;
(f) any other matter which the President may, by rule, determine.
(9) The Union and every State Government shall consult the Commission on all
major policy matters affecting the socially and educationally backward classes.".
4. After article 342 of the Constitution, the following article shall be inserted, namely:—
"342A. (1) The President may with respect to any State or Union territory, and
where it is a State, after consultation with the Governor thereof, by public notification,
specify the socially and educationally backward classes which shall for the purposes
of this Constitution be deemed to be socially and educationally backward classes in
relation to that State or Union territory, as the case may be.

Insertion of
new article 342
A.
Socially and
educationally
backward
classes.

(2) Parliament may by law include in or exclude from the Central List of socially
and educationally backward classes specified in a notification issued under clause (1)
any socially and educationally backward class, but save as aforesaid a notification
issued under the said clause shall not be varied by any subsequent notification.".
5. In article 366 of the Constitution, after clause (26B), the following clause shall be
inserted, namely:—

Amendment
of article 366.

‘(26C) "socially and educationally backward classes" means such backward
classes as are so deemed under article 342A for the purposes of this Constitution;’.
————

DR . G. NARAYANA RAJU,
Secretary to the Govt. of India.

UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110054.
MGIPMRND—1643GI(S3)—11-08-2018.

MANOJ
KUMAR

Digitally signed by
MANOJ KUMAR
Date: 2018.08.11
18:36:06 +05'30'
