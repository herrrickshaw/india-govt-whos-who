---
doc_id: "c5ece68dca7bd66e"
source_url: "https://master-dolr.digifootprint.gov.in/static/uploads/2025/09/09aa82822f6e3711f6b348ba63799fb0.pdf"
ministry: "Department of Land Resources (DLR)"
title: "E-Auction of Air-Conditioner, Photocopiers, Computers, Monitor, UPS, Printer & Miscellaneous items of DoLR"
date: "2019-04-11"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c9069dd5fbd31435"
---

<!-- page 1 -->

ヽ

No D‑27015/1/2014‑Admn
Government oflndia
Ministry of Rural Development
Department of Land Resources

NBO Building, Nirman Bhawan
New Delhi, the ..&tq{afeh"2019

tt wr.t*

E-Auction Notice
Sub.: E-Auction of Air-Conditioner, Photocopiers, Computers, Monitor, UpS, printer
& Miscellaneous items of Department of Land Resources - reg.

The Department of Land Resources intends to e-auction of Air-Conditioner
Photocopiers, Computers, Monitor, UPS, Printer & Miscellaneous items (List enclosed)
on 30th April, 2019 (Tuesday)
02:30 PM through Accurate Auctioneers
(Ph:9868215515). ltems for auction are available for inspection on 22nd to 26th April, 20i9
at NBO Building, Nirman Bhawan, New Delhi & Block 11, 6th Floor, CGO Complex, Lodhi
Road, New Delhi from 11:00 AM to 03:00 PM. Auction will be based on'As is where is
and whatever there is basis".

at

2.

An amount of Rs. 15,0001 should be deposited in the form of Demand Draft in
favour of Pay & Accounts Officer, Department of Land Resources payable at New Delhi
towards EMD before auction. For details of items and terms & condition, pleaqe visit
www.accurateauctioneers. in and www.accurateauctioneers.com.

・ ｀
浩1麻酔

りnder Secretary to the Govt of!ndia

Tei 011‐ 23044635

l N:CI DoLR with a requestto upload the e‐ auction notice on Department's website and
on e― procurement site

<!-- page 2 -->

卜

｀
,2‐・

S.No.

Name ofthe ltem

1

Fax Machine
Scanner

8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23

24

1

5
9
9

Batt堕
window AC

uPs Battery興

1

5
2
2
2
7
7

split AC

Telephone
cOffee Machine
Cooler
Hot Case
Roorn Heater
Cassette PlaYsq

1

2

Etthaust Fan
o‖

Heater

1

十ёlephone SyStem(釘 9*
Steel Rack

UPS

Printer

CPU
Monitor

2
1

11
8
13
15

TV OLD
LCD

5
4

Steel Table

1

Screen

2

ムドヽ

１嗜 ζ ■４ ■ ■

2
3
4
5
6
7

Ouantity

¨
嵯フ●警置■Ｌ饉情ぃＬＥ勝ＦＥ■ＥＥＥ轟ＥＥ種● ■ 一 一 ■

List ofthe items kept at NBO Bui:dinq′ N」菫=聾an Bhawan

<!-- page 3 -->

￨・

「

・
「
´0
/

/
S.No
1

R
W Table

Dispenser

window AC

8
9

TV
PhotocopY Machine

10
11
12
13

Monitor
Keyboard
Printer

CPU

14
15

UPS

16
17
18
19

Intercom Box

20
21
22
24

25
26
27

BattQ壁

Blower
scanner
Server Machine
Cooler
Wooden Table
Wooden Table Long
steel Table
Steel Rack Small + Bia
Steel Table Long
Chair

1
1
1

4

1

3
13
12
22

10
12
4
1

6
6
1
1

2
2
3

一
５

23

Stab‖ izer

4

Ｅυ

split AC

Quantity

５
＾

2
3
4
5
6
7

Items
HOt Case
Coffee Machine

2
1

2
