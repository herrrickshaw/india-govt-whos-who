---
doc_id: "c4dbc63ca8b769af"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/60ae94375e4315867dc52f652874b4ad.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 1116 of 2024 in the Hon’ble High Court of Delhi: DoT instructions dated 15.05.2026 to ISPs"
date: "2026-05-15"
pages: 70
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a46a81d0a2e430d0"
---

<!-- page 1 -->

4-10/2025-DGT/4(PartVIII)

I/3399016/2026

By Email/ DoT Website
File No.: 4-10/2025-DGT/4(Part-VIII)
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
nd
2 Floor, UIDAI HQ, New Delhi -110001
Date:

-05-2026

To
All Licensees with Internet Service Authorization
Subject: CS (COMM) 1116/2024: UNISYS INFOSOLUTIONS PRIVATE LIMITED &
ORS. vs. DESICINEMAS.TV & ORS. in the Hon'ble High Court of Delhi.
Please find enclosed the Hon’ble High Court of Delhi order dated 13.12.2024 and
15.04.2026 in the captioned case.
2.
Please refer to Para 37(g) to 37(j) of the Court Order dated 13.12.2024 along with the
directions contained in the Court Order dated 15.04.2026, regarding blocking access to the 30
websites/domain names (Defendant Nos. 165 to 184), as enclosed herewith.
3.
In view of the above, all Licensees with Internet Service Authorization are hereby
instructed to take immediate necessary action in respect of blocking access to the said
website(s)/domain(s), as enclosed herewith, in compliance with the said court orders.

Encl: A/A

ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court order/
enclosed Annexure pl.
ii.)
Mr. Mansha Mehta (mansha@ncalegal.in) Plaintiﬀ's Counsel- For kind
information and with a request to take action as per the enclosed Annexure pl.

<!-- page 2 -->

4-10/2025-DGT/4(PartVIII)

I/3399016/2026

CS(COMM) No. 1116/2024:
Website(s)/domain(s)
Defendant No.

Websites

<!-- page 3 -->

4-10/2025-DGT/4(PartVIII)

I/3399016/2026

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

^

EMAIL BY REGISTRY - IPD

IN THE HIGH COURT OF DELHI AT NEW DELHI

DHC/Orgl./IPD
From:

The Registrar General
Delhi High Court
New Delhi.
To:

DEFENDANT NO.72 To 102

72.,Godaddy.com, LLC
4th Floor, Statesman House,
Barakhamba Road, Connaught Place,
New Delhi, Central Delhi

Email: grievanceofFieer@godaddy.com
73. Namecheap LLC
4600 East Washington Street Suite 300,
Phoenix, Arizona 85034, USA.

Email; support@nameeheap.com;
grievance.officer@namecheap.com
74. Name.com,Inc.
414 14th Street #200

Denver, Colorado 80202

Email: abuse@name.com

75. Cioudflare, Inc.
Legal Department
101 Townsend St,
San Franciseo, CA 94107

Email: support@eloudflare.com
76. Porkbun LLC

21370 SW Danger Farms Parkway,
Suite-142-429 Sherwood, OR 97140, USA.

Email:support@porkbun.com;
abusegrievance-officer-in@porkbun.com
77. Cloud DNS Ltd

4 Iskar Str, Sofia 1000, Bulgaria
Email: support@cloudns.net
78. Dynadot Inc.
210 S Ellsworth Ave #345

San Mateo, CA 94401 US

Email: info@dynadot.com

Dated...Mk^.i.^

<!-- page 8 -->

K.

79. Spaceship,Inc.
4600 East Washington Street, Suite 300,
Phoenix, AZ 85034, USA

Email: support@spaceship.com
80. Shinjiru Technology Sdn Bhd
No.19-2, Wisma Laxton, Jalan Desa,
Taman Desa, Off Jalan Klang Lama,

58100 Kuala Lumpur, Malaysia.
Email: contactus@shinjiru.com.my
81. Instra Corporation Pty Ltd
GPO BOX 988 Melbourne

Victoria, Australia, 3001

Email: abuse@instra.com
82. Sqnarespace Domains LLC
8 Clarkson St

New York, NY 10014, USA

Email: complaints@squarespace.com
83. Tucows Domains Inc.

96 Mowat Avenue Toronto,
ON M6K 3M1 Canada

Email: info@tueows.com
84. Hostinger Operations, UAB
Svitrigailos str. 34,
Vilnius 03230 Lithuania

Email: domains@hostinger.com
85. NameSilo,LLC
390 NE 191st St

STE 8437 Miami, FL 33179 USA

Email: support@namesilo.com
86. Google LLC.
1600, Amphitheatre Parkway,
Mountain

View, California, 94043, USA

Email: support-in@google.com
87. Atria Convergence Technologies Pvt. Ltd.
99A/113A, Manorayana Palya
R.T. Nagar Bangalore - 560032
Email: nodal.term@aetcorp.in;
nodalofficer.ner@actcorp.in,
jitesh.chathambil@actcorp.in
88. Mahanagar Telephone Nigam Ltd.
5th Floor, Mahanagar Doorsanchar Sadan
9, CGO Complex, Lodhi Road New Delhi- 110003

E-mail:raco.mtnl@gmail.com;mtnlcsco@gmail.com;
gmracomtnl@gmail.com

<!-- page 9 -->

89. Bharat Sanchar Nigam Ltd.

Bharat Sanchar Bhawan, Regulation Cell,
5th floor, Barish Chandra Mathur Lane,
Janpath, New Delhi- 110001.
E-mail: ddg_reg@bsnl.co.in; sbkhare@bsnl.co.in;
averma@bsnl.eo.in
90. Reliance Jio Infocomm Limited

RCP 14(TC 23), Phase 4,
B-Block, 3rd Floor,

C 4 13 0 Twane- Belapur Road,
Gansoli, Navi Mumbai-400701

E-mail: care@jio.com; hitesh.marthak@relianceada.com;
Kapoor.guliani@ril.com; mahipal.singh@ril.com;
sunil.kr.gupta@ril.com; shilpi.kant@ril.com;
jyoti.jain@ril.com;
rudraksha.sinha@ril.com; neelakantan.an@ril.com
91. Shyam Spectra Pvt. Ltd.
PlotNo. 21-22, 3rd Floor,

Udyog Vihar, Phase IV,
Gurugram -122015, Haryana.

E-mail: info@spectra.co; complianee@spectra.co
92. Tata Teleservices Ltd.

A,E & F Blocks Valtas Premises - T. B. Kadam Marg

Chinchpokli, Mumbai-400033, Maharashtra.
E-mail: pravin.jogani@tatatel.eo.in;
anand.dalal@tatatel.co.in;
satya.yadav@tatatel.co.in
93. Vodafone Idea Limited

Yodafone House,Peninsula Corporate Park,
Ganpatrao Kadam Marg,
Lower Pare 1, Mumbai - 400 013 India

E-mail: smitha.menon@vodafoneidea.eom;
pankaj.kapdeo@vodafoneidea.com;
Radhika.gokhale@vodafoneidea.com;
sheena.thukral@vodafoneidea.com;
layati.sairam@vodafoneidea.com
94. Bharti Airtel Ltd.

Airtel Centre, Tower-A,6th Floor
A - Wing,Plot No.16,
Udyog Vihar Phase - IV,
Gurugram - 122016, Haryana.

Email: amit.bhatia@airtel.com
95. Hathway Cable & Datacom Pvt. Ltd.
Rahejas', 4 floor.
Main Avenue, Santaeruz(W),
Mumbai-40054, Maharashtra.

Email: ajay.Singh@hathway.net; dulal@hathway.net;
sudhir.shetye@hathway.net

<!-- page 10 -->

96. Fastway Transmissions Pvt. Ltd.
Grand Walk Mall, 5th Floor,

0pp. Gurdev Hospital, Ferozpur Road,
Ludhiana- 141002,Punjab

Email: nodalofFicer@fastway.in
97. SITI Networks Ltd.

FC- 19, UG Floor,
Sector-16A,Film City,
Noida-201301, Uttar Pradesh.

Email: nodaLbb@siti.esselgroup.eom;
sitieare@sitinetworks.eom
98. Excitel Broadband Pvt. Ltd.

Seeond & Third Floor, Plot No. 48,
Okbla Industrial Estates, Phase -III.
New Delhi, 110020.

Email: nodal@excitel.eom
99. Tikona Infinet Pvt. Ltd.

3A,3rd Floor,'Corpora',
LBS Marg, Bhandup (West),
Mumbai-400078, Maharashtra.

Email: TIL.appellate@tikona.in
100. DEN Networks Ltd.

Unit No. 116,1St Floor,

C Wing, Building No. 2,
Kailas Industrial Complex,
L.B.S. Marg,Park Site, Vikhroli(West),
Mumbai-400079, Maharashtra.
Email: wecare@,denonline.in

101. Department of Telecommunications(DoT)
Through Secretary,
Ministry of Communications and IT,
20, Sanchar Bhawan, Ashoka Road,
New Delhi-110001

Email: seey-dot@nie.in, dirds2-dot@nic.in
102. Ministry of Electronics and Information Technology
(MeitY)
Through Director General(DIT),
Cyber Laws & e-seeurity
Electronies Niketan, 6, COO Complex,
Lodi Road, New Delhi- 110003

E-mail: eyberlaw-legal@meity,gov.in;
gceyberlaw@meity.gov.in;pkumar@meity.gov.in;
sathya.s@meity.gov.in

<!-- page 11 -->

CS(GOMM)- 1116/2024
,.PLAINTIFF(S)

UNISYS INFOSOLUTIONS PVT. LTD.& ORS

Vs

DEFENDANT(S)

DESICINEMAS.TV & ORS.

Sir,

I am directed to forward herewith for information and necessary compliance

a copy of order dated 15.04.2026 passed by Ms. SWATI KATIYAR (DHJS), Joint
Registrar (Judicial) ofthis Court.
Yours faithfully,

cer(JudL)(IPD)
'V

frar General

jiR
End.: 1) Copy of the order dt: 15.04.2026,13.12.2024.
2) Copy ofAmended Memo ofParties

U!
V)
—f

r \

>>

<!-- page 12 -->

a

$-18
*

lil
IN

THE

HIGH COURT

OF DELHI AT

NEW

DELHI

+

CS(COMM)1116/2024
UNISYS INFOSOLUTIONS PRIVATE LIMITED & ORS.
Plaintiff

Through:

Ms. Nikhil Chawla, Adv
(VC).

versus

DESICINEMAS.TV & ORS.
Defendants

Through;

Ms. Anmol Dhindsa and Mr.

Yogesh Singh, Advs for
D-72.

Ms. Vani Kaushik, Adv for

D-86(VC).
Ms. Shweta Sahu and Ms.

Deeksha Pokhriyal, Advs for
D73(VC).
CORAM:

JOINT REGISTRAR(JUDICIAL)MS.SWATIKATIYAR
ORDER
15.04.2026

%

Fresh I.A. 10194/2026 on behalf of plaintiffs for impleadment
of defendants.

1.

The plaintiff is seeking to implead rogue-websites as

defendant nos. 165 to 184 because they have been found to be

indulging in illegally disseminating the cop)nighted material
belonging to the plaintiff. The application has been moved in
terms of the liberty granted by the Hon'ble Court on 13.12.2024,
contained in paragraph 37(g)to 37(j) ofthe said order.

2.

The application is supported by the required affidavit.

Keeping in view the contents of the suit and the application, the
This is a digitally signed order.

The authenticity ofthe order can be re-verified from Delhi High Court Order Portal by scanning the OR code shown above.

<!-- page 13 -->

Of

same is allowed. The pr%^Wefendants are impleaded as
defendant nos. 165 to 184.

3.

The amended memo filed alongwith this lA is taken on

record. Steps be taken to serve the newly impleaded defendants
with summons within two weeks through electronic mode. Process
fee be filed within a week.

4.

The order blocking the rogue-websites and injunction order

passed by the Hon'ble Court on 13.12.2024 shall operate qua the
freshly impleaded defendants as well. Further, the concerned
DNR's are directed to lock and suspend / deactivate the rogue

websites impleaded today. The concemed ISPs /TSPs are directed
to block the rogue websites impleaded today. Plaintiff shall comply
with Order 39 Rule 3 CPC and file compliance affidavit within a
week. lA is allowed and disposed off accordingly.
MS.SWATIKATIYAR,

JOINT REGISTRAR(JUDICIAL)
APRIL 15,2026/M
oelh/7:
V

T,
in
w
LU

•s.

p-l

V

Ihis is a digitally signed order.

The authenticity of the order can be re-verlfled from Delhi High Court Order Portal by scanning the QR code shown above.

<!-- page 14 -->

$-38
IN THE HIGH COURT OF DELHI AT NEW DELHI
+

CS(COMM)1116/2024
UNISYS INFOSOLUTIONS PRIVATE
.Plaintiffs

LIMITED & ORS.

Through:

Mr. Nikhil Chawla and Mr. Om Ram,
Advocates.

versus

.Defendants

DESICINEMAS.TV & ORS.

Through:

Mr. Aditya Gupta and Mr. Sauhard
Alung, Advocates for defendant no.
86/ Google LLC.

CORAM:

HON'BLE MR.JUSTICE AMIT BANSAL
ORDER

%

13.12.2024

LA.48163/2024 (u/s 12A ofCommercial Courts Act, 2015)

1.

As the present suit contemplates urgent interim relief, in light of the

judgment of the Supreme Court in Yamini Manohar v. T.K.D. Krithi, 2023
see Online SC 1382, exemption from the requirement of pre-institution
mediation is granted.

2.

The application stands disposed of.

LA.48164/2024(0-XIR-l(4)ofthe Commercial Courts Act)

3. The present application has been filed on behalf of the plaintiffs
seeking leave to file additional documents under the Commercial Courts
Act, 2015.

CS(COMM)1116/2024
This is a digitaily signed order.

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 1 of36

<!-- page 15 -->

6°

4.

The plaintiffs are permitted to file additional documents in accordance

with the provisions of the Commercial Courts Act, 2015 and the Delhi High
Court(Original Side)Rules, 2018.
5.

Accordingly, the application is disposed of.

I.A. 48165/2024(exemption from filing clear and typed copies)

6.

Allowed, subject to the plaintiffs filing legible/typed copies of the

documents within four weeks from today.

7.

The application stands disposed of.

LA.48166/2024(under Section 80 ofCPO

8.

In view of the urgent relief sought, leave is granted to the plaintiffs to

file the suit without serving the notice under Section 80 of Code of Civil
Procedure, 1908 ('CPC').
I.A. 48167/2024(exemption from filins documents in separate volumes)

9.

This application has been filed on behalf of the plaintiffs seeking

exemption from filing documents in separate volumes.
10.

For the reasons stated in the application, the same is allowed and the

plaintiffs are exempted from filing documents in separate volumes.
11.

The application stands disposed of.

CS(COMM)1116/2024

12.

Let the plaint be registered as a suit.

13.

Issue summons.

14.

Summons are accepted by counsel appearing on behalf of the

defendant no. 86/ Google LLC.

15.

Summons be issued to the defendants no. 1 to 86 through e-mail alone

and to the defendants no. 87 to 103 through all permissible modes. The
summons shall state that the written statement(s) shall be filed by the

CS(COMM)1116/2024
This is a digitaiiy signed order.
The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 2 of36

<!-- page 16 -->

a
MHT ^R-

[il

defendants within thirty days from the date of the receipt of summons.

Along with the written statement(s), the defendants shall also file affidavit
of admission/denial of the documents of the plaintiffs, without which the
written statement(s) shall not be taken on record.

16.

Liberty is given to the plaintiffs to file replications, if any, within

thirty days from the receipt of the written statement(s). Along with the
replications filed by the plaintiffs, affidavit of admission/denial of the
documents ofthe defendants be filed by the plaintiffs.

17.

The parties shall file all original documents in support of their

respective claims along with their respective pleadings. In case parties are
placing reliance on a document, which is not in their power and possession,
its detail and source shall be mentioned in the list of reliance, which shall

also be filed with the pleadings.

18.

If any of the parties wish to seek inspection of any documents, the

same shall be sought and given within the timelines.

19.

List before the Joint Registrar on 19^^ February, 2025 for completion

of service and pleadings.

20.

List before the Court on 2°^ April, 2025.

I.A. 48162/2024 fO-XXXIX Rules 1 and 2 of CPC)

21. The present suit has been filed seeking relief of permanent injunction,
restraining the defendants from committing piracy of the plaintiffs' works,
from infringing the copyright and broadcast reproduction rights of the

plaintiffs and to block access to the defendants no. 1 to 71's rogue
websites/URLs as identified by the plaintiffs, along with other ancillary
reliefs.

CS(COMM)1116/2024
This is a digitaily signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the OR code shown above.

Page 3 of36

<!-- page 17 -->

Qliftl Op

22.

It is submitted that the plaintiffs no.1 to 3 are sister concems/afFiliated

companies. The plaintiffs are engaged in production, acquisition and
distribution of various cinematographic films and audio-visual content in
various Indian languages, in multiple formats worldwide including but not

limited to, theatrical, television, digital and internet platforms, cloud

platforms. The plaintiffs are one of the largest Indian provincial music and
film producer, distributor, and aggregator, and have produced/released over
60+ films either alone or in collaboration with other media and production

houses including but not limited to 'Zindagi Zindabaad', 'Cheta Singh',
'Snowman', 'Kulche Chole', 'Television', 'Posti', 'Maa', 'Warning', 'Ikko

Mikke', 'Happy Go Lucky', 'Manje Bistre', 'The Black Prince', 'Zindagi
Kitni Haseen Hay', among others.

23.

The plaint asserts that the plaintiffs have the exclusive rights to

publicly exhibit and communicate through any medium or mode
(hereinafter, "plaintiffs' works"). The plaintiffs' works are protected as
"Cinematograph Films" under Section 2(f) read with Section 13 of the
Copyright Act, 1957 ("the Act"). The plaintiffs have the exclusive right to
make their works available for being seen or heard, or otherwise enjoyed by

the public, as enumerated under Section 14(d) of the Act, and further, is also
entitled to broadcast reproduction rights in respect of its broadcasts, under
Section 37 of the Act.

24.

It is stated that the plaintiffs exploit their copyrighted Works/content

on Youtube under the label of "Saga Hits", on their own OTT platform
"Kableone" and other third party platforms. It is further submitted that a
major portion of the plaintiffs' business involves the voluntary licensing of
the aforesaid exclusive rights in the plaintiffs' works for exploitation across

CS(COMM)1116/2024
This is a digitaiiy signed order.
The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 4 of36

<!-- page 18 -->

Qijnf o/p

all

modes

and

mediums,

including

websites/platforms, intemet-based service

various

music

streaming

providers, digital service

providers, Over-the-Top (OTT) streaming platforms/service providers,

mobile applications, and the like. It is only by exploiting the copyright in

such a manner that the plaintiffs are able to sustain their creative activities in
the course oftheir business.

25.

It is submitted that the defendants no.l to 71 (hereinafter referred to

as "defendant Websites" / "Rogue Websites",/ "URLs") are essentially

rogue websitesAJRLs which are engaged in displaying pirated content by
blatantly violating third party rights in order to obtain financial benefits. The
nature of these websites is such that they are regularly and consistently

updated with new content which is made available to the public without the
rights-holders' authorisation and is thereby infringing in nature. The entities
who own, operate and manage these rogue websites are unknown as they

have opted for privacy protection services of the registrar and are also
located at unverifiable locations. The locations of the servers of these rogue

websites are unknown and may be located across the world.
26.

It is further submitted that these websites are anonymous in nature,

i.e., it is virtually impossible to locate the owners of such websites or contact
details of such owners, as the information provided in the public domain is
either incomplete, incorrect and/or protected/encrypted/hidden.
27.

It is stated that the defendants no. 70 and 71 are specific infringing

URLs available on cloud storage providers, where the plaintiffs' works are
being exploited.

28.

It is averred that the defendant websites are 'rogue' in terms of the

judgment of this Court in UTVSoftware Communications Ltd. v. 1337x.to

CS(COMM)1116/2024
This is a digitally signed order.

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 5 of36

<!-- page 19 -->

<}p

[il

(2019 see OnLine Del 8002) as they contain vast volume of third-party
content; contain systematic, organized and intentional nature of the
infiingement; and also due to the regularity and consistency with which
content is updated/ uploaded on the said websites.

29.

It is averred in the plaint that the defendants no. 1 to 71

Websites/URLs are not authorised to host, upload, stream, reproduce, make

available for download, distribute, broadcast, make available to the public or

communicate to the public the plaintiffs' works, or facilitate the same,

without permission of the rights owners. Thus, the act of hosting, uploading,
streaming, reproducing, making available for download, distributing,
broadcasting, making available to the public or communicating to the public
the plaintiffs' works in India, or facilitating the same, amounts to
infringement of the plaintiffs' rights under Section 51 ofthe Act.
30.

It is stated that the defendants no. 72 to 85 are Domain Name

Registrars which have been arrayed to block / cancel / suspend the domain
name registration of the defendants no. 1 to 69 (and such other
websites/URLs which are discovered during the course of the proceeding

and notified on Affidavit by the plaintiffs) to have been infringing the

copyright in the plaintiffs' works including the future works, and to disclose
the certain information about the defendant Websites.

31.

It is further stated that plaintiffs have arrayed Google LLC as the

defendant no. 86 for the purpose of de-indexing/ delisting of the domain
names/ websites of such rogue defendant websites (and such other
websites/URLs which are discovered and notified on Affidavit by the

plaintiffs) from the search results produced on the search engine, 'Google',
and for the purposes of blocking the keywords/terms which are a part of

CS(COMM)1116/2024
This is a digitaiiy signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the OR code shown above.

Page 6 of 36

<!-- page 20 -->

'Second Level Domain' of defendant Websites (and such other
websites/URLs which are discovered and notified on Affidavit by the

plaintiffs) from the search results available on search engine 'Google'.
32.

It is submitted that the defendants no. 87 to 100 are Internet Service

Providers which are being arrayed for the purpose of blocking/ restricting

access to the rogue websites identified in the present suit or any other
website subsequently identified by the plaintiffs on affidavit.
33.

It is stated in the plaint that the plaintiffs have arrayed the defendant

no. 101, Department of Telecommunications, and the defendant no. 102,

Ministry of Electronics and Information Technology for the issuance of a
notification to the internet and telecom service providers to disable access to

the defendant Websites identified in the present suit and such other websites

subsequently discovered and identified by the plaintiffs to be infringing the
rights ofthe plaintiffs. The defendant no. 103 is 'John Doe'.

34.

Counsel appearing on behalf of the plaintiffs has drawn the attention

of this Court to the various infringing content which is available on these

rogue websites. The list of the defendant Websites/URLs, and the
corresponding pages of the documents filed along with the present plaint, is
given in document no. 3 of the documents filed along with the plaint.
35.

It is submitted that as the plaintiffs' works enjoy protection as

'cinematograph films' under the Act, the making available and/ or
communication to the public of the plaintiffs' works, without their

authorization, by the defendant websites would amount to a violation of the
plaintiffs' exclusive rights under the Act.
36.

The balance of convenience is clearly against the defendant Websites,

which do not have authorization with respect to the plaintiffs' works.

CS(COMM)1116/2024
This is a digitaiiy signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the OR code shown above.

Page 7 of36

<!-- page 21 -->

a
m

including, inter alia, to host, stream, reproduce, permit download or
distribute, make available to the publie and/or communicate the plaintiffs'
cinematographic films/original content/work, or facilitate the same. It is
submitted that if the illegal activities of the defendant websites are not

restrained during the pendency of the present proceedings, plaintiffs shall
suffer irreparable harm since it is submitted that the defendant Websites
intend to continue to exploit the plaintiffs' property with impunity, thereby,
diminishing and diluting the value ofthe plaintiffs' rights.

37.

Accordingly, till the next date of hearing, the following directions are

issued;

a. The defendants no. 1 to 71 {Annexure-A of the present order), their

owners, partners, proprietors, officers, servants, employees, and all
others in capacity of principal or agent acting for and on their behalf,
or anyone claiming through, by or under them, are restrained from
communicating, hosting, streaming, and / or making available for

viewing and downloading in any manner, without authorization, on
their websites or other platforms, through the internet in any maimer

whatsoever, the plaintiffs' works and content related thereto.
b. The defendants no. 72 to 85 (DNRs) and their directors, partners,

proprietors, officers, affiliates, servants, employees, and all others in
capacity of principal or agent acting for and, on their behalf, or

anyone claiming through, by or through them, are directed to lock and
suspend the domain name registration ofthe defendants no. 1 to 69, as

per the details given in Annexure- B ofthe present order.
c. The defendants no. 72 to 85 (DNRs) are directed to disclose the
following information:

CS(COMM)1116/2024
This is a digitaliy signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 8 of36

<!-- page 22 -->

i. Complete details (such as Name, Address, Email address.
Phone Number, IP Address etc.) of the defendants no. 1
to 69;

ii. Mode of payment along with payment details used for

registration of domain name by the Registrant i.e.,
defendants no. 1 to 69.

d. The defendant no. 86, Google LLC, is directed to de-index / delist the
defendants no. 1 to 69 websites, given as Annexure-A of the present
order.

e. The defendants no. 87 to 100, their directors, partners, proprietors,

officers, affiliates, servants, employees, and all others in capacity of

principal or agent acting for and on their behalf, or anyone claiming

through, by or under it, are directed to block access to the various
websitesAJRLs (defendants no. 1 to 71) identified by the plaintiffs,
details of which are given as Annexure-B andAnnexure - C.
f. The defendants no. 101 and 102 are directed to issue a notification

calling upon the various internet and telecom service providers

registered under them to block access to the defendants no. 1 to 69
(rogue websites) and the defendants no. 70- 71 (URLs), details of
which are given as Annexure- B andAnnexure - C.

g. If during the pendency of the present suit, any further websites are
discovered by the plaintiffs, which are illegally streaming the

infringing content, copyright of which is owned by the plaintiffs, the

plaintiffs are granted liberty to communicate the details of such
websites

to

the

defendant

no.

101

(Department

of

Telecommunications) and the defendant no. 102 (Ministry of

CS(COMM)1116/2024
This is a digitally signed order.

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 9 of36

<!-- page 23 -->

Electronics and Information Technology), for issuance of blocking

orders and simultaneously to the Internet Service Providers ("ISPs")
for blocking the said websites.
h. The DOT and MEITY shall also issue necessary blocking orders

immediately upon the plaintiffs, communicating the details of the
websites, which are illegally streaming the content, over which the
plaintiffs have rights.

i. Upon receiving intimation from DOT/MEITY, the ISPs shall take
steps to immediately block the rogue websites in question.
j. After communication of details ofthe rogue websites to the concerned
authorities, the plaintiffs shall continue to file affidavits with the
Court, in order to ensure that the Court is fully informed of the
websites in respect of which blocking orders are sought.

k. If any website, which is not primarily an infringing site, is blocked

pursuant to the present order, they shall be permitted to approach this
Court by giving an undertaking that it does not intend to engage in

any unauthorized streaming of any content, over which the plaintiffs
have rights.
1. As and when new further websites are discovered by the plaintiffs, the

plaintiffs shall be at liberty to file an application for their
impleadment, which shall be taken up before the Joint Registrar, and
the order passed today shall be extended to the said newly impleaded
website(s) as well.
38.

In view of the fact that there are several defendants involved,

compliance of Order XXXIX Rule 3 of the Code of Civil Procedure, 1908

CS(COMM)1116/2024
This is a digitaliy signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 10 of36

<!-- page 24 -->

[il

(CPC)shall be filed within seven(7) days from today.
39.

Issue Notice.

40.

Notice is accepted by counsel appearing on behalf of the defendant

no. 86/ Google LLC.

41.

Notice be issued to the defendants no. 1 to 85 through e-mail alone

and to the defendants no. 87 to 103 via all permissible modes.

42.

Reply(ies) be filed within four(4) weeks.

43.

Rejoinder(s) thereto, if any, be filed within two(2) weeks thereafter.

44.

List before the Joint Registrar on 19"^ February, 2025 for completion

of service and pleadings.

45.

List before the Court on 2°'^ April, 2025.

AMIT BANSAL,J
DECEMBER 13, 2024
kd

CS(COMM)1116/2024
This is a digitally signed order.

The authenticity of the order can be re~verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 11 of36

<!-- page 25 -->

[U
«uiu

ANNEXURE A - LIST

OF ROGUE

WEBSITES/URLs AND

CORRESPONDING PAGES IN THE LIST OF DOCUMENTS
De

Domain Name of Title of the Plaintiffs' Relevant

fen

Defendant

da

Websites

Work

Page No. in
the List of

nt

Documents

No.

showing
Plaintiffs'
Work

exploited
on

Defendant
Website
1

desicinemas.tv;

Ardaas Karaan

desicinemas.pk;

Manje Bistre 2

62-64

desicinemas.org;
desicinema.ink

Manje Bistre

Needhi Singh
Son of Manjeet Singh
Sucha Soorma
Sucha Soorma

2

tellygossips.net

Ardaas Karaan

movies123.pk

Manje Bistre 2
Manje Bistre
Needhi Singh
Son of Manjeet Singh
Cheta Singh

65-67

Jatt James Bond
Maa

Manje Bistre 2
Television

Warning

CS(COMM)1116/2024
This is a digitaliy signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shovm above.

Page 12 of36

<!-- page 26 -->

©■CM

\Ei

3

cloudy.pk;
cloudy,com.pk

Asees

68-71

Khido Khundi

Warning
Heer Maan Ja

Happy Go Lucky
Dushman

Son of Manjeet Singh
Sucha Soorma
Maa
4

9xmoviesverse.com

Ardaas Karaan

72-76

Jatt James Bond
Laatu

Lock
Maa

Manie Bistre
Mar Gaye Oye Loko
Saadey CM Saab
Sat Shri Akaal England
Heer Maan Ja

methodspoint.com

Maa

Lock

Saadey CM Saab
Mar Gaye Oye Loko
Ardaas Karaan
5

coolmoviez.dr.in;

Kulche Chole

coolmoviez.er.in

Subedar Joginder Singh

77-82

Ardaas Karaan

Manje Bistre 2
Laatu

Asees

Virsa
What the Jatt

Happy Go Lucky

CS(COMM)1116/2024
This is a digitaily signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the OR code shown above.

Page 13 of36

<!-- page 27 -->

OTifli

Haani

Jatt James Bond

coolmoviez.coop.in

Jora:

The

Second

Chapter
6

watch-

Snowman

movies.com.pk

Maa

83-91

Television

Warning
Rang Punjab
Panchhi

Mar Gaye Oye Loko
Nankana

Manje Bistre 2
James Bond
Ikko

Son of Manjeet Singh
Laatu
Asees

Parahuna

Khido Khundi

Subedar Joginder Singh
Sat Shri Akaal England
Manje Bistre
Needhi Singh
25 Kille

Tiger
Bhatinda Express
Faraar

Dil Vil Pyar Vyaar
Gadaar: Te Traitor

PoojaKivenAa
Jatts in Golmaal

Naughty Jatts
Judge Singh TLB
Dushman
Haani

CS(COMM)1116/2024
This is a digitaliy signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 14 of36

<!-- page 28 -->

a
6°

[3

3^

Sucha Soorma
1

yomovies.chat;
yomovies.diy;
yomovies.express;
yomovies,farm;
yomovies.com.in;
yomovies.world;
prmovies.im;

Parchi

yomovies.im

Sat Shri Akaal England

92-97

25 Kille

Asees

Zindagi Kdtni Haseen
Hay
Jatt James Bond
Laatu

Parahuna
Parahuna 2

Subedar Joginder Singh
Ikko Mikke
Ikko Mikke

Son of Manjeet Singh
Warning
Television

Naughty Jatts
Manje Bistre
Manie Bistre 2
The Black Prince
Posti

Jora:

The

Second

Chapter
Snowman
Ardaas Karaan

Do Dooni Panj

Mar Gaye Oye Loko
Nankana

8

Rang Punjab
hindilinks4u.makeu Warning
Manje Bistre
p;
hindilinks4u.digital; Naughty Jatts

hindilinks4u.my;
hindilinks4u.diy;
hindilinks4u.pics;
minoplres.xyz

98-100

Snowman

Posti

Rang Punjab
Maa

CS(COMM)1116/2024
This is a digitaiiy signed order.

The authenticity of the order can be re-verified from Delhi High Court OrderPortal by scanning the QR code shown above.

Page 15 of36

<!-- page 29 -->

Manje Bistre 2
Ikko Mikke
Laatu

9

minoplres.xyz

Warning

putlocker.llc;
putlocker.gay;

Asees

101 - 107

Jatt James Bond

putlockerhulu.com; Ardaas Karaan
123moviesputlocker Ikko Mikke
s.com

Jatts in Gohnaal

Manje Bistre 2
Cheta Singh
Subedar Joginder Singh
Gadaar: The Traitor

Rang Punjab
Tiger
Khido Khundi
Parahuna

Mar Gaye Oye Loko
Manje Bistre
Judge Singh LLB
Warning
Sat Shri Akaal England
Do Dooni Panj
Kille
Kulche Chole
Motor Mitraan Di

Saadey CM Saab
Lock
Haani
10

cinemakick.com

25 Kille

108-111

Bathinda Express
Jatt James Bond

Judge Singh LLB
Lock

Manje Bistre
Motor Mitraan Di

Needhi Sigh

CS(COMM)1116/2024
This is a digitaiiy signed order.
The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 16 of36

<!-- page 30 -->

a

a

^1

Pooja Kiven Aa
Saadey CM Saab
Sayonee
The Black Prince

Tiger
Warning
11

111.90.159.159

Asees

The Black Prince
Laatu

Subedar Joginder Singh
Jatts in Gohnaal

Naughty Jatts
Jatt James Bond

Zindagi

Kitni

Haseen

Hay

Saadey CM Saab
Parchi

Sat Shri Akaal England
Jora

:

The

Second

Chapter
Ardaas Karaan

cgjnf.com

Mar Gaye Oye Loko
Subedar Joginder Singh
Asees

Naughty Jatts
The Black Prince
Parchi

Sat Shri Akaal England
Jora

:

The

Second

Chapter
Mar Gaye Oye Loko
cmlhz.com

Jatts in Gohnaal
Jatt James Bond

Zindagi

Kitni

Haseen

Hay

Saadey CM Saab
Laatu

CS(COMM)1116/2024
This is a digitally signed order.

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 17 of36

<!-- page 31 -->

Ardaas Kamaan
12.

filmywap.com.tr;
filmywap.bar
6filmywap.com

Manje Bistre 2

112-113

Mar Gaye Oye Loko
Nankana

filmywap.com.ht;
filmywap.pm;
filmywapi.cc;

Rang Puniab
Warning
Warning
Warning
Rang Punjab
Rang Punjab
Mar Gaye Oye Loko
Mar Gaye Oye Loko
Nankana
Nankana

13

Rang Punjab
filmyzilla.com.fj;
filmyzilla.com.gr;
Kulche Chole
filmyzilla2023.com;
filmyzilla.cv;
filmy-zilla.org;

114

filmyzilla.com
14

okjatthd.site;
okjatt.sbs

Saade Aaale

115-125

25 Kille
25 Kille
Ardaas Karaan

Cheta Singh
Gumm
Ikko Mikke
Jatt James Bond

Jatt James Bond
Jatts in Golmaal
Khido Khundi
Laatu
Maa

Manje Bistre 2
Manje Bistre
Needhi Singh

CS(COMM)1116/2024
This is a digitaiiy signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 18 of36

<!-- page 32 -->

Q^JUt

a

v-i

Needhi Singh
Rang Punjab
Saadey CM Saab
Saadey CM Saab
Saadey CM Saab
Sat Shri Akaal England
Snowman

Son of Manjeet Singh
Subedar Joginder Singh
Television

Warning
What the Jatt

Do Dooni Panj
Parahuna

Mar Gaye Oye Loko
Asees
The Black Prince

Motor Mitraan Di

Tiger
Tiger
Bathinda Express
Bathinda Express
Judge Singh LLB
Faraar

okjatthd.quest

Saade Aaale

Cheta Singh
Snowman
Maa

Television

Warning
What the Jatt
Faraar

Jatt James Bond

Saadey CM Saab
Bathinda Express
Bathinda Express
Needhi Singh

CS(COMM)1116/2024
This is a digitaiiy signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 19 of36

<!-- page 33 -->

[3

Tiger
25 Kille

Manie Bistre
The Black Prince

Motor Mitraan Di

Sat Shri Akaal England
Khido Khundi

Subedar Joginder Singh
Asees

Khido Khundi
Parahuna

Mar Gaye Oye Loko
Laatu

Son of Manieet Singh
Ardaas Karaan

Jatts in Golmaal

Manic Bistre
Warning
Panchhi

15

mp4filmy.lol

Rang Puniab
Cheta Singh

126-132

Gumm

Shahkot
Posti

Do Dooni Pani
Saade Aale

Jora the Second Chapter
Warning
Rang Punjab
Snowman
Maa

Television

Warning
Ikko Mikke

Subedar Joginder Singh
Subedar Joginder Singh
Ardaas Karaan

CS(COMM)1116/2024
This is a digitaliy signed order.

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the OR code shovi/n above.

Page 20 of36

<!-- page 34 -->

Q-cnt

a

Parahuna

Khido Khundi
The Black Prince
Motor Mitraan Di
Lock
Lock

Needhi Singh
Saadey CM Saab
Tiger
16

Vhitmovies.zone

Sucha Soorma

133-157

Cheta Singh
Asees

Vhitmovies.ing

Tiger
Sat Shri Akal England
Jora

The

Second

Chapter
Do Dooni Panj
Needhi Singh
Saade Aale

Cheta Singh
Posti

Vhitmovies.party

Warning
Tiger
Sat Shri Akal England
Jora

The

Second

Chapter
Do Dooni Pan]
Needhi Singh
Saade Aale

Cheta Singh
Posti

7hitmovies.baby

Warning
Subedar-Joginder-Singh
Panchi

Jatt James Bond

Do Dooni Panj
Maa

CS(COMM)1116/2024
This is a digitaiiy signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portal by scanning the OR code shown above.

Page 21 of36

<!-- page 35 -->

1
[il

Motor Mitran Di

Gadaar: The Traitor

Warning
Manie Bistre 2
Manje Bistre
Son of Manieet Singh
Naughty Jatts
Happy Go Lucky
Asses

Cheta Singh
The Black Prince
Lock
Nankana
Snowman
Snowman

Snowman
17

pagalmovies.net.tr

158-166

Haani

Happy Go Lucky
Ikko Mikke
Jatt James Bond

Manje Bistre
Rang Puniab
Subedar Joginder Singh
Virsa
What the Jatt

pagalmovies.today

Ardaas Karan

pagalmovies.one
pagalmovies.digital

Rang Pan]ah
Son of Manjeet Singh

pagalmovies.com.tr

Ardaas Karan

Rang Punjab
Ikko Mikke

Subedaar

Joginder

Singh
Son of Manjeet Singh
Manje Bistre
Virsa
What The Jatt

CS(COMM)1116/2024
This is a digitaily signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portai by scanning the QR code shown above.

Page 22 of36

<!-- page 36 -->

a

glJHl

[=]

Happy Go Lucky
Haani

Jatt James Bond
18

playlinkhere.online

Gumm

167

Do Dooni Pan]
Snowman
Maa

Warning
Rang Punjab
Ikko Mikke
Jatts in Golmaal
Ardaas Karaan

Son of Manjeet Singh
Laatu

Parahuna
Asees

Sat Shri Akaal England
The Black Prince

Manje Bistre
19

filmyfly.im

Motor Mitraan Di

168-174

Television

filmyfly.ws

Motor Mitraan Di
Television

filmyfly.africa;
filmyfly.biz
20

showlinkhide.click

Motor Mitraan Di
Television

Cheta Singh
Do Dooni Panj
Do Dooni Panj

175-176

Posti
Posti
Saade Aale
Saade Aale

Shahkot
Shahkot
Gumm
Gumm

Jora:

The

Second

CS(COMM)1116/2024
This is a digitaiiy signed order.

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the OR code shown above.

Page 23 of36

<!-- page 37 -->

Chapter
Jora:

21

The

. Second

Chapter
Warning
Warning
Son of Manjeet Singh

flixfox.tv;
flixfox.in;

25 Kille

flixfox.app

Khido Khundi

177-182

Asees

Jatt James Bond

Manie Bistre
The Black Prince

Zindagi Kitni Haseen
Hay

Needhi Singh
Saadey CM Saab
Laatu

Lock

Sat Shri Akaal England
Parahuna

Subedar Joginder Singh
Maa

Warning
Posti
Snowman
Ardaas Karaan

Mar Gaye Oye Loko
22

123moviescom.onli

25 Kille

ne

Khido Khundi

183 -200

Asees

Dil Vil Pyaar Vyaar
What the Jatt

Manje Bistre
Manje Bistre 2
123moviefree.info

Sucha Soorma

fl23moviesputlocke

Sucha Soorma

rs.com

CS(COMM)1116/2024
This is a digitaiiy signed order.
The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 24 of36

<!-- page 38 -->

123moviesff.com

25 Kille
Asees

Dil Vil Pyaar Vyar
Khido Kfiundi

Manje Bistre 2
Manje Bistre
What the Jatt
00123movies.com

Sucha Soorma

gofl23movies.com

Sucha Soorma

123movieshubhd.or

Sucha Soorma

S

123moviesputlocker

Sucha Soorma

s.com

23

lekuluent.et

25 Kille

201 -202

Asees

Khido Khundi
24

surfmovies.biz

25 Kille

203-207

Saadey CM Saab
Asees

Manie Bistre
Manie Bistre 2
Bathinda Express
Sucha Soorma

Cheta Singh
Maa

ffmovieto.net;
fmoviesmx.com;

25 Kille

fmoviesps.com

Asees

Saadey CM Saab
Manie Bistre
Manie Bistre 2
Bathinda Express
Sucha Soorma

Cheta Singh
Maa'
25

movies-show.com

Asees

208-211

25 Kille

Manie Bistre

CS(COMM)1116/2024
This is a digitaily signed order.

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 25 of36

<!-- page 39 -->

[i]

Manje Bistre 2
iwatchmovieshd.co

Asees

m;

Manje Bistre 2

playwatchmovies.co Manje Bistre
m

26

netfilm.city

Cheta Singh, Khedo,

-

Khundi, Sucha Soorma
27

28

Asees
hdtodaytv.fun;
ww3.hdtodaytv.fun; Cheta Singh
hdtodaytv.click;
Sucha Soorma
hdtoday.city
Jatt James Bond
Sucha Soorma
filmyhit.locker

212-215

216-220

Kulche Chole

Cheta Singh
Posti

29

afilmyhit.er.in
afilmyhit.dr.in
ifilmyhit.xyz
cindy-ota.me

Posti
Posti

Cheta Singh
Ardaas Karaan

-

Warning
Rang Punjab
Rang Punjab
Mar Gaye Oye Loko
Khido Khundi
Nankana
Parahuna

Son of Manjeet Singh
Do Dooni Panj
Marije Bistre 2
Manje Bistre
Laatu

Ardaas Karaan

Tkko Mikke
Faraar

Sat Shri Akaal England
Tiger
30

nonrolls.com

Snowman

CS(COMM)1116/2024
This is a digitaliy signed order.
The authenticity ofthe order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

-

Page 26 of36

<!-- page 40 -->

[3

Television

Jora

The

Second

The

Second

Chapter
Jora

Chapter
Manje Bistre
Manje Bistre
Warning
Ardaas Karaan
31

pwr55.xyz

-

-

-

-

'

-

-

-

32

littp://l 85.243.4.76

-

-

-

33

watchfilmy.com.pk

Nankana

221

34

katmoviehd.cab

Sucha Soorma

222

35

mkvcinemas.fit;

Sucha Soorma

223

Cheta Singh

224

Television

225

mkvcinemas.fit
36

olamovies.in;

filmyzilla.olamovie
s.in
37

thekhatrimaza.io;
thekhatrimaza.ad

38

themoviesflix.tv

Sucha Soorma

226

39

themoviesverse.life

Television

227

40

thevegamovies.at
vegamovies.ietzt
vegamovies.do

Kulche Chole

228

41

filmymeet.dr.in;

Cheta Singh

229

42

filmymeet.vip
todaypk.com.pk

Sucha Soorma

230

Sucha Soorma

Cheta Singh

CS(COMM)1116/2024
This is a digitally signed order.

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 27 of36

<!-- page 41 -->

43

playdesi.cc

Sucha Soorma

231

44

worldfree4u.now

Sucha Soorma

232

ibomma.day
46 extramovies.meme;
extramovies,soy
5movierulz.to;
47

Sucha Soorma

233

Sucha Soorma

234

Sucha Soorma

235

45

5movierulz.dev
wwvH.movierulz.i

Sucha Soorma

0

ww7.4movierulz.to

Sucha Soorma

6moviemlz.net

Sucha Soorma

Smoviemlz.live

Sucha Soorma

Sucha Soorma

236

Sucha Soorma

237

50

Iflix.ing
bollyzone.cc
movi.pk

Sucha Soorma

51

bunnyscdn.com

Happy Go Lucky

48
49

-

-

Jatt James Bond

Manje Bistre 2
Dil Vil Pyaar Vyaar
Bathinda Express
Saadey CM Saab
Lock

Tiger
Kille

Needhi Singh
Motor Mitraan Di

Haani
The Black Prince

Sat Shri Akaal England
Judge Singh LLB
Khido Khundi
Asees
Laatu

Subedar Joginder Singh
Son of Manjeet Singh
Waming
DoDooni Pan]

CS(COMM)1116/2024
This is a digitaliy signed order.

The authenticity ofthe order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 28 of36

<!-- page 42 -->

a

[3

Needhi Singh
Mar Gaye Oye Loko
Manje Bistre 2
Laatu

Khido Khundi
Lock

25 Kille
52

h(imovie2.tires;
hdmovie2.anny

Sucha Soorma

238

53

41inks.click

Sucha Soorma

239

54

cinvevood.blog
fulWmovies.express
afilmywap.vu
afilmywap.org.nz

Sucha Soorma

240-241

Sucha Soorma

242-248

Sucha Soorma

249-251

55

56

Sucha Soorma

57

7starhd.ooo

Sucha Soorma

252-257

58

iattfilms.store
gomoviesl.net

Sucha Soorma

258-261

Sucha Soorma

262-267

watehgomovies.co

Sucha Soorma

59

m;

gomoviesplay.com
60

hdmovie2.jetzt;

Sucha Soorma

268 - 270

61

hdmovie2.energy
streamtape.net

Sucha Soorma

271

62

1 kuttymovies.com.c

Sucha Soorma

272

0

lkuttymovies.net

Sucha Soorma

63

3moviesda.com

Sucha Soorma

273-274

64

moviemmm.com;

Sucha Soorma

275

castletvhd.com
65

luxmovies.live

Sucha Soorma

276-280

66

1337x-official.to

Sucha Soorma

281

67

moviespapa.voto

Sucha Soorma

282-290

moviespapa.ehat

Sucha Soorma

68

movieapne.co

Sucha Soorma

69

bilibili.tv

Sucha Soorma

291

70

1024tera.com/sharin Sucha Soorma

292

-

g/link?surl=uIW9T

CS(COMM)1116/2024
This is a digitaliy signed order.

The authenticity of the order can be re-veriTied from Deihi High Court Order Portal by scanning the QR code shown above.

Page 29 of36

<!-- page 43 -->

a
OUBI

XZc_wi5jI8QJBUP
eA

71

gofile.io/d/Jxmo20

Sucha Soornia

293

CS(COMM)1116/2024
This is a digitaily signed order.
The authenticity ofthe order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 30 of36

<!-- page 44 -->

a

Annexure-B: Domain Name Registrars of the Rogue Websites
Domain Name
Defend Domain Name of the Rogue
Registrars
Websites
ant
(DNRs)

Nos.
1

desicinemas.tv

Pomkbun LLC

desicinemas.pk

Cloudflare, Inc.
NameSilo, LLC
Dynadot Ine

desicinemas.ee

desieinema.org
desieinema.ink;

NameCheap,Ine

tellygossips.net
2

movies123.pk

Cloud DNS Ltd

3

cloudy,eom.pk;

Cloudflare, Ine.

eloudy.mom
4

5

eloudy.pk

Cloud DNS Ltd

9xmoviesverse.eom;
methodspoint.eom
eoolmoviez.dr.in;

GoDaddy.eom,
LLC

Dynadot LLC

eoolmoviez.eoop.in;
eoolmoviez.er.in
6

watch-movies,eom.pk

Cloudflare, Ine.

7

yomovies,chat;
yomovies.express;
yomovies,diy;

Nameeheap,Ine.

yomovies.farm

8

9

yomovies.eom.in
yomovies,world
prmovies.im
yomovies.im
hindilinks4u.makeup;
hindilinks4u.digital;
hindilinks4u.my;
hindilinks4u.diy;
hindilinks4u.pies;
minoplres.xyz

putloeker.lle;
putloeker.gay;

Dynadot LLC
Pomkbun LLC

Cloudflare, Ine.
Not identified.

Nameeheap,Ine.

Nameeheap,Ine.

putloekerhulu.com;

CS(COMM)1116/2024
This is a digitaliy signed order.

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.

Page 31 of36

<!-- page 45 -->

a

123moviesputlockers.com
10

cinemakick.com

Namecbeap,Inc.

11

http://lll.90.159.132

Sbinjiru
Technology Sdn
Bbd

cgjnf.com

Name.com,Inc.

cmlhz.com
12

filmywap.com.tr;

Namecbeap,Inc.

filmywap.bar

filmywap.com.ht

Instra

Corporation Pty
Ltd

13

14

6filmywap.com
fihnywap.pm
filmywapi.cc

Spaceship, Inc.
Cloudflare, Inc.
Namecbeap,Inc.

filmyzilla.com.J5;
filmyzilla.com.gr;

Not identified

filmyzilla.cv
filmyzilla2023.com
filmy-zilla.org
filmyzilla.com
okiatthd.site

okjatt.sbs;
15

16

okjatthd.quest
mp4filmy.lol
Vhitmovies.zone;

Dynadot, Inc.
Spaceship, Inc.
Namecbeap,Ine.
Namecbeap,Inc.
Name.com,Inc.
Namecbeap,Inc.

Namecbeap,Inc.

Vhitmovies.baby;
Vbitmovies.ing
17

18

19

pagalmovies.net.tr;
pagalmovies,today;
pagalmovies.one;
pagalmovies.digital;
pagalmovies.com.tr
playlinkbere.online
filmyfly.im
filmyfly.ws
filmyfly.africa
filmyfly.biz

Not identified

Namecbeap,Ine.
Cloudflare, Inc.

Namecbeap,Inc.

CS(COMM)1116/2024
This is a digitaily signed order.
The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 32 of36

HJ

<!-- page 46 -->

IE}

20

showlinkhide.click

Namecheap,Inc.

21

flixfox.tv

Dynadot Inc.

flixfox.in

GoDaddy.com,

flixfox.app
123moviescom.online;
123moviefree.info;

LLC

22

Namecheap,Inc.

fl23moviespiitlockers.com;
123moviesff.com;
00123movies.com;

gofl23movies.com;
123movieshubhd.org;
123moviesputlockers.com
23

lekuluent.et

24

surfmovies.biz;
ffmovieto.net;
fmoviesmx.com;
fmoviesps.com
movies-show.com;
iwatchmovieshd.com;
playwatchmovies.com

25

Dynadot Inc.
Namecheap,Inc.

Namecheap,Inc.

26

netfilm.city

Namecheap,Inc.

27

hdtodaytv.fun;
ww3.hdtodaytv.fun;
hdtodaytv.click;
hdtoday.city

Namecheap,Inc.

28

filmyhit.locker

Namecheap,Inc.

afilmyhit.er.in;
afilmyhit.dr.in

Dynadot LLC

29

ifilmyhit.xyz
cindy-ota.me

Namecheap,Inc.
Name.com,Inc.

30

nonrolls.com

Squarespace
Domains LLC

32

pwr55.xyz
http://185.243.4.99

33

watchfilmy.com.pk

34

katmoviehd.cab

Namecheap,Inc.
Not identified
Cloudflare, Inc.
Dynadot Inc

35

mkvcinemas.fit;

Tucows Domains

31

CS(COMM)1116/2024
This is a digitaiiy signed order.

The authenticity ofthe order can be re-verified from Delhi High Court Order Portal by scanning the OR code shown above.

Page 33 of36

<!-- page 47 -->

QliJll <)p

mkvcinemas.soy

Inc.

olamovies.in;

GoDaddy.com,

filmyzilla.olamovies.in

LLC

thekhatrimaza.io;

GoDaddy.com,

thekhatrimaza.ad

LLC

38

themoviesflix.tv

Dynadot Inc

39

themoviesverse.life

GoDaddy.com,

36

37

LLC
40

41

Dynadot Inc

thevegamovies.at
vegamovies.i'etzt
vegamovies.do

Pomkbun LLC

filmymeet.dr.in;

Dynadot LLC

Not identified

filmymeet.vip
Cloudflarc, Inc.

43

todaypk.com.pk
playdesi.cc

Pomkbun LLC

44

worldfree4u.now

Not identified.

45

ibomma.day

Tucows Domains

42

Inc.

46
47

extramovies.meme;
extramovies.soy
5movierulz.to;

Namcchcap,Inc.
Cloudflarc, Inc.

5movierulz.dev .
ww7.4movierulz.to

Namcchcap,Inc.
Cloudflarc, Inc.

6movierulz.net;

Namcchcap,Inc.

wwvl4.movierulz.io;

8movierulz.live
48
49
50

51
52

Iflix.ing
bollyzone.cc
movi.pk
bunnyscdn.com
lidmovie2.tires;
lidmovie2.army

Spaceship, Inc.
Dynadot Inc
Cloudflarc, Inc.
Cloudflarc, Inc.
Pomkbun LLC

53

41inks.click

54
55

cinvcvood.blog
full4movies.express

Namcchcap,Inc.
Namcchcap,Inc.
Namcchcap,Inc.

56

afilmywap.vu;

Dynadot Inc

afilmywap.org.nz

CS(COMM)1116/2024
This is a digitaily signed order.

The authenticity of the order can be re-veriTied from Deihi High Court Order Portai by scanning the QR code shown above.

Page 34 of36

<!-- page 48 -->

O-Cfll

[e1

57

7starhd.ooo

Dynadot LLC

58

jattfilms.store

Hostinger
Operations, UAB

59

gomoviesl.net;
watchgomovies.com;

Namecheap,Inc.

gomoviesplay.com
60

hdmovie2.jetzt;

Pomkbun LLC

61

hdmovie2.energy
streamtape.net

EasyDNS
Technologies Inc.

62

1 kuttymovies.com.co;

Namecheap,Inc.

lkuttymovies.net
63

3moviesda.com

64

moviemmm.com

Spaceship, Inc.
Name.com,Inc.

castletvhd.com

GoDaddy.com,
LLC

65

luxmovies,live

66

1337x-official.to

67
68

moviespapa.voto
moviespapa.chat
movieapne.co

69

bilibili.tv

NameSilo,LLC
Cloudflare, Inc.
Name.com,Inc.
Namecheap, Inc.
Namecheap,Inc.
Name.com,Inc.

CS(COMM)1116/2024
This is a digitaiiy signed order.

The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 35 of36

<!-- page 49 -->

a

Annexure C;Infringing URLs

Infringing URLs

Defend
ant

No.
70

https://www.1024tera.com/sharing/link?surl=uIW
9TXZc_wi5jI8QJBUPeA

71

gofile.io/d/Jxmo20

CS(COMM)1116/2024
This is a digitaiiy signed order.
The authenticity of the order can be re-verified from Deihi High Court Order Portai by scanning the QR code shown above.

Page 36 of36

<!-- page 50 -->

IN THE HIGH COURT OF DELHI AT NEW DELHI

(Original CommercialJurisdiction)
LA.

of2026
IN

CS(COMM)NO.1116 of2024
IN THE MATTER OF:

UNISYS INFOSOLUTIONS PVT.LTD.& ORS

...Plaintiffs

Versus

DESICINEMAS.TV & ORS.

...Defendants

AMENDED MEMO OF PARTIES

1. Unisys Infosolutions Pvt. Ltd.
1089,New Housing Board Colony Sector -13,
Kamal, Haryana,
India, 132001
Email ID: ashish@unisvsinfo.in
Mobile: 8222098000
...Plaintiff No.l

2. Saga Music Private Limited
House No. 15, Block G,
Pocket No. 11, Sector 15,Rohini,
New Delhi-110085

Email ID: ashish@unisysinfo.in
Mobile: 8222098000
...Plaintiff No.2

3. Seven Colors Broadcasting Private Limited
PlotNo. 234-C,
Sector-3A,HSIIDC,

Kamal,Haryana,India- 132001
Email ID: ashish@unisvsinfo.in
Mobile: 8222098000
...Plaintiff No.3
Versus

1. desicinemas.tv

Also, at:

desicinemas.pk;
desicinemas.ee;

desicinema.org;
desicinema.ink;

<!-- page 51 -->

tellygossips.net
Email: abuse@,porkbun.com
..Defendant No.1

2. moviesl23.pk
Email: abuse@cloudns.net
...Defendant No.2

3. cloudy.com.pk
Also, at:

cloudy.mom
cloudy.pk
Email: abuse@cloudflare.com
.Defendant No.3
4. 9xmoviesverse.com

Also, at:

methodspoint.com
Email: abuse@godaddv.com
...Defendant No.4
5. coolmoviez.dr.in

Also, at:

coolmoviez.coop.in
coolmoviez.er.in

Email: abuse@cloudflare.com
...Defendant No.5

6. watch-movies.com.pk
Email: abuse@cloudflare.com
...Defendant No.6

7. yomovies.chat
Also, at:

yomovies.diy;
yomovies.express;
yomovies.farm;
yomovies.com.in;
yomovies.world;
prmovies.im
yomovies.im
Email: abuse@namecheap.com
...Defendant No.7

8. hmdilinks4u.makeup
Also, at:

hindilinks4u.digital;
hindilinks4u.my
hindilinks4u.diy;
hindilinks4u.pics;
minoplres.xyz
Email: abuse@namecheap.com

<!-- page 52 -->

8
...Defendant No.8

9. putloeker.llc
Also, at:

putlocker.gay;
putlockerhulu.com
123moviesputlockers.com
Email: abuse@namecheap.com
...Defendant No.9

10.einemakick.com

Email: abuse@namecheap.com
..Defendant No.10

11.http://lll.90.159.132
Also, at:

cgjnf.com;
cmlhz.com

Email: abuse@,shiniiru.com.mv:
abuse@name.com
...Defendant No.11

12.filmywap.com.tr
Also, at:

filmywap.bar;
6filmywap.com;
filmywap.pm;
filmywapi.cc;
filmywap.com.ht
Email: email@,filmvwap.pm:
abuse@instra.com;
abuse@spaceship.com
..Defendant No.12

13.filmyzilla.com.fj
Also, at:

filmyzilla.com.gr;
filmyzilla2023.com;
filmyzilla.cv;
filmy-zilla.org;
filmyzilla.com
Email: abuse@shiniiru.com.mv
..Defendant No.13

14.okjatthd.site
Also, at:

okjatt.sbs
okjatthd.quest
Email: abuse@name.com

..Defendant No.14

15.mp4filmy.Iol

<!-- page 53 -->

Email: abuse@namecheap.com
...Defendant No.15

16.7hitmovies.party
Also, at:
Thitmovies.zone;

7hitmovies.ing;
7hitmovies.baby
Email: abuse@namecheap.com
...Defendant No.16

17.pagalmovies.net.tr
Also, at:

pagalmovies.today;
pagalmovies.one;
pagalmovies.digital;
pagalmovies.com.tr
Email: abuse@cloudflare.com
...Defendant No.17

18.playlinkhere.online
Email: abuse@namecheap.com;
abuse@ovhcloud.in
.Defendant No. 18

19.filmyfly.im
Also, at:
fllmyfly.ws;
filmyfly.africa;
filmyfly.biz
Email: abuse@namecheap.com
.Defendant No.19

20.showIinkhide.cIick

Email: abuse@namecheap.com
.Defendant No.20
21.flixfox.tv

Also, at:
flixfox.in;

flixfox.app
Email: complaints@dvnadot.com
.Defendant No.21

22.123moviescom.onIine

Also, at:
123moviefree.info;

fl23moviesputlockers.com;
123moviesff.com;
00123movies.com;

gofl23movies.com;
123movieshubhd.org;

<!-- page 54 -->

10
123moviesputlockers.com
Email: abuse@namecheap.com
...Defendant No.22
23.lekuluent.et

Email: info@dvnadot.com
...Defendant No.23
24.surfmovies.biz

Also, at:
ffmovieto.net;
fmoviesmx.com;

fimoviesps.com
Email: abuse@nameclieap.com
..Defendant No.24
25.movies-show.com

Also, at:
iwatchmovieshd.com;

playwatchmovies.com
Email: abuse@namecheap.com
,..Defendant No.25

26.netfilm.eity
Email: abuse@namecheap.com
...Defendant No.26

27.hdtodaytv.fun
Also, at:

ww3.hdtodaytv.fun
hdtodaytv.click
hdtoday.city
Email: abuse@namecheap.com
...Defendant No.27

28.filmyhitlocker
Also, at:

afilmyhit.er.in
afilmyhit.dr.in;
ifilmyhit.xyz
Email: abuse@namecheap.com;
complaints@dvnadot.com
...Defendant No.28

29.cindy-ota.me
Email: abuse@name.com
...Defendant No.29
30.nonrolls.eom

Email: complamts@,sauarespace.com
...Defendant No.30

31.pwr55.xyz
Email: abuse@namecheap.com

<!-- page 55 -->

11
...Defendant No.31

32.http://185.243.4.99
Email; abuse@ipv4superhub.com
..Defendant No.32

33.watchfilmy.com.pk
Email: abuse@cloudflare.com
...Defendant No.33
34.katmoviehd.cab

Email: info@dvnadot.com
...Defendant No.34
35.mkvcinemas.fit

Also, at:

mkvcinemas.soy
Email: info@tucows.com
.Defendant No.35
36.olamovies.in

Also at:

filmyzilla.olamovies.in
Email: abuse@godaddY.com
.Defendant No.36

37.thekhatrimaza.io

Also, at:
thekhatrimaza.ad

Email: abuse@godaddv.com
...Defendant No.37

38.themoviesfiix.tv

Email: complaints@dvnadot.com
...Defendant No.38

39.themoviesverse.life

Email: abuse@godaddv.com
...Defendant No.39

40.thevegamovies.at
Also, at:
vegamovies.jetzt;
vegamovies.do
Email: complaints@dvnadot.com
...Defendant No.40

41.filmymeet.dr.in
Also, at:

filmymeet.vip
Email: complaints@dvnadot.com
...DefendantNo. 41

42.todaypk.com.pk
Email: abuse@cloudflare.com
...Defendant No.42

<!-- page 56 -->

12
43.playdesi.cc
Email: abuse@porkbun.com
...Defendant No.43
44.worldfree4u.now

Email: worldfi-eeuindinfglgmail.com
...Defendant No.44

45.ibomma.day
Email: info@tucows.com

...Defendant No.45
46.extramovies.meme

Also, at:

extramovies.soy
Email: abuse@,namecheap.com
...Defendant No.46
47.5movierulz.to

Also, at:
Smovierulz.dev;
wwv14.movierulz.io;
ww7.4movierulz.to;
6movierulz.net;
Smovierulz.live

Email: abuse@cloudflare.com;
abuse@,namecheap.com
...Defendant No.47

48.lflix.ing

Email: support@spaceship.com
...Defendant No.48

49. bollyzone.cc
Email: complaints@dvnadot.com
...Defendant No.49

50. movLpk
Email: abuse@cloudflare.com
...Defendant No.50

51. bunnyscdn.com
Email: abuse@cloudflare.com
...Defendant No.51
52. hdmovie2.tires

Also, at:

hdmovie2.army
Email: abuse@porkbun.com
...Defendant No.52
53.41inks.click

Email: abuse@namecheap.com
...Defendant No.53

54.cinvevood.blog

<!-- page 57 -->

13
Email: abuse@namecheap.com
...Defendant No.54

55.full4movies.express
Email: abuse@namecheap.com
.Defendant No.55

56.afilmywap.vu
Also, at:
afilmywap.org.nz
Email: complaints@dvnadot.com
...Defendant No.56
57.Tstarhd.ooo

Email: complaints@dynadot.com
...Defendant No.57

58.jattfilms.store
Email: abuse@hostinger.com
..Defendant No.58

59.gomoviesl.net
Also, at:
watchgomovies.com;
gomoviesplay.com
Email: abuse@namecheap.com
.Defendant No.59

60. hdmoviel.jetzt
Also, at:

hdmovie2.energy
Email: abuse@porkbun.com
...DefendantNo.60

61.streamtape.net

Email: dmca@streamtape.com
...DefendantNo.61

62.lkuttymovies.com.co
Also, at:

lkuttymovies.net
Email: abuse@namecheap.com
...DefendantNo.62
63.3moviesda.com

Email: support@spaceship.com
...Defendant No.63
64. moviemmm.com

Also, at:
castletvhd.com

Email: abuse@godaddv.com
...DefendantNo.64
65.luxmovies.live

Email: abuse@namesilo.com

<!-- page 58 -->

14
...Defendant No.65

66.1337x-official.to

Email: abuse@cloudflare.com
...Defendant No.66

67. moviespapa.vdto

...Defendant No.76

Also, at:

moviespapa.chat
Email: abuse@namecheap.com
...Defendant No.67

68. movieapne.co
Email: abuse@namecheap.com
...Defendant No.68
69.bilibili.tv

Email: abuse@name.com:
...Defendant No.69

70.1024tera.com/sharing/link?surl=urW9TXZc_wi5jI8QJBU
PeA

Email: abuse@kev-svstems.net:

...Defendant No.70

71. gofile.io/d/Jxmo20
Email: abuse@ovs.net
...Defendant No.71

72. Godaddy.eom,LLC
4th Floor, Statesman House,

BarakhambaRoad,Connaught Place,
New Delhi, Central Delhi
Email: grievanceofficer@godaddv.com
...Defendant No.72

73.Naniecheap LLC
4600 East Washington Street Suite 300,
Phoenix, Arizona 85034, USA.
Email: support@namecheap.com;
grievance.officer@namecheap.com
...Defendant No.73

74.Name.com,Inc.
41414th Street #200

Denver, Colorado 80202
Email: abuse@name.com

...Defendant No.74

75. Cloudflare,Inc.

Legal Department
101 Townsend St,
San Francisco, CA 94107

Email: support@cloudflare.com

...Defendant No. 75

<!-- page 59 -->

15
76.Porkbun LLC

21370 SW Langer Farms Parkway,

Suite-142-429 Sherwood,OR 97140,USA':
Email:support@porkbun.com;
abusegrievance-officer-in@porkbun.com
...Defendant No.76

77. Cloud DNS Ltd

4Iskar Str, Sofia 1000,Bulgaria
Email: support@cloudns.net
.Defendant No.77

78.Dynadot Inc.
210 S Ellsworth Ave #345

San Mateo, CA 94401 US
Email: info@dYnadot.com
...Defendant No.78

79.Spaceship,Inc.
4600 East Washington Street, Suite 300,
Phoenix, AZ 85034, USA

Email: support@spaceship.com
...Defendant No.79

SO.Shinjiru Technology Sdn Bhd
No.19-2, Wisma Laxton,Jalan Desa,
Taman Desa, OffJalan Klang Lama,
58100 Kuala Lumpur, Malaysia.
Email: contactus@shiniiru.com.my
.Defendant No.80

81.lustra Corporation Pty Ltd
GPO BOX 988 Melbourne

Victoria, Australia, 3001
Email: abuse@instra.com
...Defendant No.81

82.Squarespace Domains LLC
8 Clarkson St

New York,NY 10014, USA

Email: complaints@squarespace.com
.Defendant No.82
83.Tucows Domains Inc.

96 Mowat Avenue Toronto,
ON M6K 3M1 Canada

Email: info@tucows.com
..Defendant No.83

84.Hostinger Operations, UAB
Svitrigailos str. 34,
V

Vilnius 03230 Lithuania

Email: domains@hostinger.com

<!-- page 60 -->

16
.Defendant No.84

85.NameSilo,LLC
390 NE 191st St

STE 8437 Miami,FL 33179 USA

Email: support@namesilo.com
.Defendant No.85

86. Google LLC.
1600, Amphitheatre Parkway,
Mountain

View, California, 94043, USA

Email: support-in@google.com
...Defendant No.86

87.Atria Convergence Technologies Pvt. Ltd.
99A/113A,Manorayana Palya
R.T.Nagar Bangalore-560032

Email: nodal.term@actcorp.in;
nodalofficer.ncr@actcorp.in,
iitesh.chathambil@actcorp.in
...Defendant No.87

88. Mahanagar Telephone Nigam Ltd.
5th Floor, Mahanagar Doorsanchar Sadan

9, CGO Complex, Lodhi Road New Delhi- 110003
E-mail:raco.mtnl@gmail.com;mtnlcsco@gmail.com;
gmracomtnl@gmail.com
...Defendant No.88

89.Bharat Sanchar Nigam Ltd.

Bharat Sanchar Bhawan,Regulation Cell,
5th floor, Barish Chandra Mathur Lane,
Janpath, New Delhi- 110001.

E-mail: ddg_reg@bsnl.co.in; sbkhare@bsnl.co.in;
averma@bsnl.co.in
...Defendant No.89
90.Reliance Jio Infocomm Limited

RCP 14(TC 23),Phase 4,
B-Block, 3rd Floor,

C 4 13 0 Twane- Belapur Road,
Gansoli,Navi Mumbai-400701

E-mail: care@jio.com; hitesh.marthak@relianceada.com;
Kapoor.guliani@ril.com; mahipal.singh@ril.com;
sunil.kr.gupta@ril.com; shilpi.kant@ril.com;
ivoti.iain@ril.com;
rudraksha.sinha@ril.com: neelakantan.an@ril.com
...Defendant No.90

91.Shyam Spectra Pvt. Ltd.
Plot No.21-22,3rd Floor,

>

<!-- page 61 -->

17
Udyog Vihar,Phase IV,
Gurugram -122015,Haryana.

E-mail: info@spectra.co; compliance@spectra.co
...Defendant No.91
92.Tata Teleservices Ltd.

A,E & F Blocks Valtas Premises - T. B.Kadam Marg
Chinchpokli, Mumbai-400033, Maharashtra.
E-mail: pravin.jogani@tatatel.co.in;
anand.dalal@tatateLco.in;
satva.vadav@tatatel.co.in
...Defendant No.92

93.Vodafone Idea Limited

Vodafone House,Peninsula Corporate Park,
Ganpatrao Kadam Marg,
Lower Pare 1, Mumbai - 400 013 India
E-mail: smitha.menon@vodafoneidea.com;

pankaj.kapdeo@vodafoneidea.com;
Radhika.gokhale@vodafoneidea.com;
sheena.thukral@vodafoneidea.com;
lavati.sairam@vodafoneidea.com
...Defendant No.93
94.Bharti Airtel Ltd.

Airtel Centre, Tower-A,6th Floor
A - Wing,Plot No.16,
Udyog Vihar Phase - IV,
Gurugram -122016,Haryana.
Email: amit.bhatia@airtel.com
...Defendant No.94

95.Hathway Cable & Dataeom Pvt. Ltd.
'Rahejas',4 floor.
Main Avenue,Santacruz(W),
Mumbai-40054,Maharashtra.

Email: ajay.singh@hathway.net; dulal@hathway.net;
sudhir.shetve@hathwav.net
...Defendant No.95

96.Fastway Transmissions Pvt. Ltd.
Grand Walk Mall, 5th Floor,

Opp. Gurdev Hospital,Ferozpur Road,
Ludhiana- 141002,Punjab
Email: nodalofficer@,fastwav.in
...Defendant No.96

97.SITI Networks Ltd.

FC- 19, UG Floor,
Sector-16A,Film City,
Noida-201301,Uttar Pradesh.

<!-- page 62 -->

18
Email: nodal.bb@siti.esselgroup.com;
siticare@sitinetworks.com
...Defendant No.97
98.Excitel Broadband Pvt. Ltd.

Second & Third Floor, Plot No. 48,
Okhla Industrial Estates,Phase-III.
New Delhi, 110020.
Email: nodal@excitel.com
...Defendant No.98
99.Tikona Infinet Pvt. Ltd.

3A,3rd Floor,'Corpora',

LBS Marg,Bhandup(West),
Mumbai-400078,Maharashtra.

Email: TIL.appellate@,tikona.in
...Defendant No.99
100.DEN Networks Ltd.

Unit No. 116, 1st Floor,
C Wing,BuildingNo.2,
Kailas Industrial Complex,

L.B.S. Marg,Park Site, Vikhroli(West),
Mumbai-400079, Maharashtra.
Email: wecare@denonlme.in
...Defendant No. ICQ

101.Department of Telecommunications(DoT)
Through Secretary,

Ministry of Communications and IT,
20, Sanchar Bhawan, Ashoka Road,
New Delhi-110001

Email: secy-dot@nic.in, dirds2-dot@mc.in
...Defendant No.101

102. Ministry of Electronics arid Information Technology
(MeitY)

Through Director General(DIT),
Cyber Laws & e-security
Electronics Niketan,6,COO Complex,
Lodi Road, New Delhi- 110003

E-mail: cyberlaw-legal@meity.gov.in;

gccyberlaw@meity.gov.in;pkumar@meity.gov.in;
sathva.s@meity.gov.in
...Defendant No.102
103. John Doe

...Defendant No.103
104. Hindimovies.to

Email: info@tonicregistrv.to
...Defendant No.104

<!-- page 63 -->

19
105. Usersdrive.com

Email: abuse@godaddy.com;
userdrive.com@gmail.com
...Defendant No.105

106. Gomovies.pk

Email: staff@pknic.net.r)k
...Defendant No.106

107. Ww2.watchfilmy.lat
Email: abuse@namesilo.com
...Defendant No. 107

108. JattfilmS.shop
Email: abuse-tracker@hostinger.com;
abuse@hostinger.com
...Defendant No.108
109. Movies4u.fm

Email: abuse@namecheap.com;
moviespublisher@proton.me
...Defendant No.109

110.Xflixbd.com

Email: abuse@cosmotown.com;
info.bd404@.gmail.com
...Defendant No.110

111.Filmyzillal6.com
Email; abuse@intemet.bs;

abuse-zilla@proton.me
...DefendantNo. Ill

112.Filmyhit.fit
Email: abuse@namecheap.com;
admin@filmvhit.com
...Defendant No.112

113.Filmyhitcasino
Email: abuse@namecheap.com;
admin@filmyhit.com
.Defendant No.113

114. Mlsbd.shop
Email: abuse@,namesilo.com;
mlsbdteam@,gmail.com
...Defendant No.114
115.ltamilmv.se

Email: support@spacedump.se
...Defendant No.115

116.Ibommamovies.top
Email: abuse@,namesilo.com
...Defendant No.116

<!-- page 64 -->

20
117. Vegamovies-nl.men
Email: abuse@porkbun.com;

vegamoviesnl2025@proton.me
...Defendant No.117
118. wwl.mlsbd.tv

Email: abuse@dvnadot.com
...Defendant No.118
119.Zflixco.com

Email: abuse@ownregistrar.com
...Defendant No.ll9

120. Okjatthd.rest

Email: support@namecheap.com
...Defendant No.l20

121. Hdmp4mania2.com
Email: abuse@name.com
..Defendant No.l21

122. Thebollyflix.fun
Email: abuse@godaddv.com:

islldmca@gmail.com
...Defendant No.l22

123.Febspot.com

Email: compliance@domain-inc.net:
office@febspot.com
... Defendant No.123
124.Fuzia.com

Email: abuse-complaints@,squarespace.com:
info@fuzia.com
... Defendant No.124
125. Moviebuff.com

Email: abuse@name.com:

support@.moviebuff.com
...Defendant No.125

126. Open.firstory.me
Email: abuse@godaddv.com
... Defendant No.126
127. Mastibaaz.com

Email: domainabuse@,tucows.com:
admin@mastibaaz.com
...Defendant No.127

128. Nicegram.app
Email: abuse@,godaddv.com
...Defendant No.128
129. Desicinemas.to

Email: info@tonicregistrv.to
...Defendant No.129

<!-- page 65 -->

21
130. Kokahd.com

Email: abuse@dvnadot.com
...Defendant No.130
131. Sattorrent.eom

Email: abuse@godaddv.com
...Defendant No.131

132. Net9ja.com.ng
Email: email@whogohost.com:
net9iacom@gmail.com
...Defendant No.132
133.1337x.to

Email: info@tonicregistrv.to
...Defendant No.133

134.Filepursuit.com
Email: abuse@namecheap.com
...Defendant No.134

135. Megaplex.at
Email: office@,linznet.at
...Defendant No.135
136. Moviefuze.com

Email: abuse-tracker@hostinger.com;
abuse@hostinger.com
...Defendant No.136

137. Todaypk.video
Email: abuse@godaddv.com
.Defendant No.137

138.Punjabimoviez.online
Email: abuse@namecheap.com
...Defendant No.138

139. TeIemetr.io/en/channels/1228274595-

parahunajpunjabi_movie
Email: abuse@godaddv.com
...Defendant No.139

140. Yts.proxyninja.org
Email: domainabuse@tucows.com
...Defendant No.140

141.DaiIyiflix.com
Email: abuse-tracker@hostinger.com;
abuse@hostinger.com
...Defendant No.141

142.111.90.159.132

Email: abuse@,shiniiru.com.mv
...Defendant No.142

143.Pkmovie.video.blog
Email: welcome@mv.blog

<!-- page 66 -->

22
...Defendant No.143
144. Ukdevilz.com

Email: abuse@danesconames.com
...Defendant No.144

145.Hdvogo.com
Email: abuse@namecheap.com
...Defendant No.145

146. Sur.ly/o/okjatt.com
Email: abuse@register.lv
..Defendant No.146

147. Embedpk.net
Email: abuse@namecheap.com
...Defendant No.147

148. Tgstat.com
Email: tld-abuse@rO 1.ru
...Defendant No.148

149. MydownIoadtube.org
Email: abuse@,godaddv.com
...Defendant No.149

150.Yts.unblockninja.com
Email: domainabuse@tucows.com
...Defendant No.150
151.U13.ir

Email: info@nic.ir
...Defendant No.151

152. Telegram
Email: abuse@telegram.org
...Defendant No.152
153. Cosmotown Inc.

Email: abuse@cosmotown.com;

support@.cosmotown.com
...Defendant No.153

154.Internet Domain Service BS Corp
Email: abuse@intemet.bs:
contact-en@intemet.bs

...Defendant No.154

155.SpaceDump IT AB
Email: support@spacedump.se
...Defendant No.155

156. OwnRegistrar Inc.

Email: support@ownregistrar.com:
abuse@ownregistrar.com
...Defendant No.156
157.Domain.com

Email: support@domain-inc.net:

<!-- page 67 -->

23
compliance@,domain-inc.net
...Defendant No.157

158. G054 Limited

Email: support@whoghost.com
...Defendant No. 158

159. Whoghost Limited
Email: emaiI@whoghost.com
...Defendant No.159

160.LinzNet ISP GmbH
Email: office@linznet.at
...Defendant No.160

161. Knock Knock WHOIS There LLC

Email: welcome@mv.blog
...Defendant No.161

162.Danesco Trading Ltd.
Email: info@danesco.com ; abuse@danesconames.com
...Defendant No.162

163. Registrar ROl LLC
Email: tld-adm@r01.ru
..Defendant No.163

164.IRNIC Whois Server

Email: info@nic.ir
...Defendant No.164

165. New3.hdhub4u.fo

Also at: new5.hdhub4u.fo

Email: abuse@immateriali.sm

... Proposed Defendant No.165
166. okjatthd.boats
Also at: okjatt.boats
Email: support@namecheap.com ; abuse@namecheap.com ;
elc83b3a80774a628682e71cl20890cc.protect@iwithheldforpriva
cv-com

... Proposed Defendant No.166
167.filmyhitnow
Also at: filmyhitdelivery
Email: irupp@name.com

... Proposed Defendant No.167
168. moviesleech.zip
Also at: moviesleech.link

Email: domainabuse@tucows.com

... Proposed Defendant No.168

<!-- page 68 -->

24

169. moviezguru.Iiving

Email: a23f9f20c4144deb93a2cb79afl62e2e.protect@withheldforprivac
y.com

Proposed Defendant No.169

170. pnnjabimoviez.website
Email: registrv@namecheap.com;

Ifd0d95cl273452d91e284c346a5cbae.protect@,withheldforpriva
cy.com

... Proposed Defendant No.170
171. mkvcinemas2.eom

Email: abuse@dvnadot.com

... Proposed Defendant No,171
172. vegans4n.eom
Also at: vega-rp.com
Email: abuse@,dvnadot.com

... Proposed Defendant No.172
173. mp4mobil.com
Email: abuse@,dvnadot.com;

https://www.dvnadot.com/domain/contactrequest?domain=mp4mobil.com
... Proposed Defendant No.173
174. moviestwo.com

Email: abuse-

tracker@,hostinger.com

... Proposed Defendant No.174

175.filmybug.com
Also at: aleillmy.com
Email: abuse@dvnadot.com

... Proposed Defendant No.175

176.cinevor.com

Email: abuse@,dvnadot.com

... Proposed Defendant No.176

177.filmycart.com
Email: abuse@dvnadot.com

... Proposed Defendant No.177

178. movielinkhub.top

Email: abuse@cosmotown.com; support@cosmotown.com

... Proposed Defendant No.178
179.filmyzilla30.net
Also at: filmy-zilla.co

Email: support@,spaceship.com ; abuse@spaceship.com
... Proposed Defendant No.179
180.freedrivemovie.cfd

Email: abuse@dvnadot.com

...Proposed Defendant No.180
181.filmyyc.com
Email: abuse@,dvnadot.com

...Proposed Defendant No.181

<!-- page 69 -->

25

182. vegamovies-nl.faith
Also at: vegamovies-nl.stream

Email: info@subreg.cz; vegamoviesnl.faith@fablovkawhoisprotection,com
... Proposed Defendant No.182
183. filmyzillaa.eo
Also at: filmyzillaa.eo

Email: abuse@dynadot.com

^ ^ _ Proposed Defendant No.183

184. movies4u.am
Also at: movies4u.rs

Email:moviespublisher@proton.me
... Proposed Defendant No.184

Date: 4 April 2026

NIKHIL CHAWLA

Place: New Delhi

NIKfflL CHAWLA & ASSOCIATES
Advocates for the Plaintiffs

S Block, 387, Greater Kailash - 1,
NewDelhi-110048
Phone No.: +91-9560353449

Email ID: nikhil@ncalegal.in
D/2216/2015

<!-- page 70 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
