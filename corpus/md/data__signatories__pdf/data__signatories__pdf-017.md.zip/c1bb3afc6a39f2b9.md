---
doc_id: "c1bb3afc6a39f2b9"
source_url: "https://dsel-education.gov.in/static/uploads/2025/09/dbb56add8b0834d7b2047a0604e1453e.pdf"
ministry: "Department of School Education and Literacy (DSEL)"
title: "Notification dated 1st April, 2015 regardiing relaxation under Section 23(2) of RTE Act to the state of West Bengal"
date: "2015-04-01"
pages: 4
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "cffc4f09d88c2521"
---

<!-- page 1 -->

= सं० डी० एल०-33004/99 REGD. NO. D. L.-33004/99
2003
Ra = राजजपतन्र
(5 1
Ck zett Indi
— he Gazette of Gudia
हि असाधारण
हे EXTRAORDINARY
. भाग 1---खण्ड 3--उप-खण्ड (ii)
PART Il—Section 3—Sub-section (ii)
. प्राधिकार से प्रकाशित
io) oy | Ros) चच्च्च्ज््स्स्नन PUBLISHED BY AUTHORITY
* सं. 688] नई दिल्ली, बुधवार, अप्रैल 1, 2015/चैत्र 11, 193)
No. 688] NEW जरा __ू्् APRIL 2OISCHATTRA YH t997 WEDNESDAY, APRIL 1, 2015/CHAITRA 11, 1937
* मानव संसाधन विकास मंत्रालय
(स्कूल शिक्षा और साक्षरता विभाग)
‘ नई दिल्‍्ली,1 अप्रैल, 2015 -: :
का.आ. 918(अ).-जबकि अध्यापक शिक्षा परिषद (जिसे आगे एनसीटीई कहा गया है) ने निःशुल्क एवं
अनिवार्य बाल शिक्षा का अधिकार अधिनियम, 2009 (2009 का 35) (जिसे आगे आरटीई अधिनियम कहा गया है)
के अनुसरण में, किसी व्यक्ति के कक्षा | से कक्षा ७॥ में अध्यापक के रूप मे नियुक्त होने के लिये 25 अगस्त, 2014, :
को भारत के राजपत्र, असाधारण, भाग ॥॥, खण्ड 4 मे प्रकाशित अधिसूचना के द्वारा न्यूनतम अहर्ताएं निर्धारित की
हैं;
2... और जबकि, आरटीई अधिनियम की धारा 23 की उप-धारा (2) में प्रावधान है कि ऐसे मामले में जहां राज्य
के पास अध्यापक शिक्षा में प्रशिक्षण प्रदान करने वाले पर्याप्त संस्थान नहीं है अथवा आरटीई अधिनियम की धारा
23 की उप-धारा (1) के तहत निर्धारित न्यूनतम SEAT रखने वाले अध्यापक पर्याप्त संख्या में उपलब्ध नहीं हैं, केंद्र
सरकार, यदि आवश्यक समझे तो, अध्यापक के रूप में नियुक्त हेतु अपेक्षित न्यूनतम अ्हताओं में ऐसी. अवधि, जो
. पांच वर्ष से अधिक नहीं होगी, के लिये अधिसूचना द्वारा छूट प्रदान कर सकती है और इसे उस अधिसूचना में
विनिर्दिष्ट किया जाएगा; .
3. और जबकि, केन्द्र सरकार ने आरटीई अधिनियम की धारा 35 की उप-धारा (1) के तहत प्रदत्त शक्तियों का
. प्रयोग करते हुए आरटीई अधिनियिम की धारा 23 की उप-धारा (2) के तहत छूट प्रदान करने के लिये केंद्र सरंकार
| को प्रस्ताव प्रस्तुत किये जाने हेतु राज्य सरकारों के वास्ते 8 नवम्बर, 2010 को दिशा-निर्देश निर्धारित किये हैं; थ
| 1497 ठा/2015 ' 0) है
| :

<!-- page 2 -->

= , THE GAZETTE OF INDIA : EXTRAORDINARY a E GAETTE OF INDIA: EXTRAORDINARY __[PART So. 3(4))_ 3601
= i nd
. 4... और जबकि, केंद्र सरकार ने आरटीई अधिनियम की धारा 23 की उप-धारा-(2) के तहत प्रदत्त शक्तियों का
उपयोग करते हुए दिनांक 10.06.2011 को भारत के राजपत्र, असाधारण, भाग-॥, खंड 3, उप-खंड (ii) F
प्रकाशित दिनांक 01.06.2011 की अधिसूचना संख्या का.आ. 1352 (अ) के द्वारा पश्चिम बंगाल राज्य सरकार को
31.03.2014 तक की अवधि के लिए छूट प्रदान की थी; .
5. : और जबकि, पश्चिम बंगाल राज्य सरकार ने.एनसीटीई की 25.08.2010 को भारत के राजपत्र में प्रकाशित
अधिसूचना में इसके द्वारा निर्धारित न्यूनतम अर्ईता मानदंडों में छूट के विस्तार के लिए केंद्र सरकार को दिनांक
23.03.2015 के अपने पत्र द्वारा एक प्रस्ताव भेजा था।
6. atk जबकि, केन्द्र सरकार ने शिक्षा का अधिकार अधिनियम की धारा 23 की उप-धारा (2) के तहत छूट को
है आगे बढ़ाने के लिए पश्चिम बंगाल सरकार के प्रस्ताव की जांच की और उस पर विचार किया;
7. अब, तत्पश्चातू, शिक्षा का अधिकार अधिनियम की धारा 23 की उप-धारा (2) द्वारा प्रदत्त शक्तियों का
“ प्रयोग करते हुए, केन्द्र सरकार ने दिनांक 25.8.2010 की सं. 215 द्वारा भारत के राजपत्र में यथा-प्रकाशित
- एनसीहीई द्वारा कक्षा-+-७॥ के संबंध में अधिसूचित न्यूनतम शिक्षक अर्ईता मानकों के संबंध में पश्चिम बंगाल के
लिए छूट को आगे बढ़ाया है जो इस प्रकार है :-- ,
(क) . वक्षा--४ में शिक्षक की नियुक्ति के लिए प्रारंभिक शिक्षा (चाहे किसी भी नाम से जाना जाए) में 2
वर्षीय डिप्लोमा; और . . : Ss
(ख) वक्षा ४ से ४॥ में शिक्षक की नियुक्ति के लिए शिक्षा (बीएड) में एक वर्षीय स्नातक डिग्री।
टिप्पणी : 1. उपर्युक्त छूट दिनांक 31 मार्च, 2016 तक वैध रहेगी और निम्नलिखित शर्तों के अध्यधीन होगी, .
नामत: --
/*.. जैसा कि एनसीटीई की उपुर्यक्त अधिसूचना में निर्दिष्ट किया गया है, पश्चिम बंगाल सरकार एनसीटीई
द्वांरा दिनांक 11.02.2011 को जारी दिशानिर्देशों के अनुसरण में शिक्षक पात्रता परीक्षा (जिसे आगे टीईटी
: कहा गया है) आयोजित करेगी और टीईटी को उत्तीर्ण करने वाले व्यक्तियों पर ही प्रारंभिक कक्षाओं में
शिक्षक के रूप में नियुक्ति हेतु विचार किया जा सकता है; "
1... राज्य सरकार और अन्य स्कूल प्रबंधक एनसीटीई की उपर्युक्त अधिसूचना द्वारा निर्धारित, न्यूनतम अ्ईता
मानकों के अनुरूप भर्ती नियमों को संशोधित करेंगे। « *
| ii, नियुक्ति के मामले में, राज्य सरकार उन पात्र अभ्यर्थियों को प्राथमिकता देगी जो एनसीटीई की दिनांक
। :.._25.08.2010 की अधिसूचना में निर्धारित न्यूनतम अरईईताएं रखते हैं और इसके पश्चात्‌ ही, पात्र अभ्यर्थियों
| 0 र इस अधिसूचना में निर्धारित छूट प्राप्त अरहताओं के साथ विचार किया जाएगा।
। iv. शिक्षकों की नियुक्ति के लिए विज्ञापन का राज्य और राज्य के.बाहर व्यापक प्रचारं किया जाना चाहिए।
! ४. ' राज्य सरकार और अन्य स्कूल प्रबंधक यह सुनिश्चित करेंगे कि जिन शिक्षकों के पास एनसीटीई की उपर्युक्त
| अधिसूचना में निर्धारित न्यूनतम शैक्षिक और व्यावसायिक अहताएं नहीं हैं वे इन्हें शिक्षा के अधिकार
| अधिनियम की धारा 23 की उप-धारा (2) के तहत निर्धारित' समय सीमा के तहत प्राप्त करेंगे।
| भं.. राज्य सरकार और अंन्य स्कूल प्रबंधक यह सुनिश्चित करेंगे कि जो शिक्षक छूट प्राप्त अर्हताओं के तहत
नियुक्त किए गए हैं वे नियुक्ति के दो वर्षों की अवधि के अंदर एनसीटीई अधिसूचना में निर्धारित न्यूनतम
। अहताएं प्राप्त करेंगे। हा ना

<!-- page 3 -->

oe Heat है हे
छल है
[भाग त-खण्ड 3 (1)] _ भारत Et 3. राजपत्र : असाधारण ere . i 3
2... एनसीटीई द्वारां दिनांक 11 -02.2011 के पत्र द्वारा जारी टीईटी दिशानिर्देशों के पैरा 5 के उप-पैरा (#) के
अनुसरण में, 31.03.2016 तक राज्य में की गई शिक्षकों की नियुकतियों के संबंध में पश्चिम बंगाल सरकार द्वारा
टीईटी की परीक्षा में बैठने के लिए निम्नलिखित Salter ot ora eA are
1. कक्षा | से ४ के लिए - न्यूनतम 50% अंकों के साथ वरिष्ठ माध्यमिक (या समकक्ष)
ii, eT VI AVI के लिए - न्यूनतम 50% अंकों के साथ स्नातक.
eae cece [Rta 1-17/2010-884] -
- 4 मिल रीना रे, अपर सचिव
MINISTRY OF HUMAN RESOURCE DEVELOPMENT. i
. @epartment or School Education and Literacy)’ है
. NOTIFICATION |
/ "New Delhi, the tst April, 2015. we '
हु 8.0. 918(E).—Whereas the National’ Council: for Teacher Education (hereinafter referred to as NCTE), in
pursuance of sub-section (1) of section 23 of the Right of Children to Free and Compulsory Education Act, 2009 (35 of
2009), (hereinafter referred to as the RTE Act), laid down the minimum qualifications for a person to be eligible for
appointment as a teacher in classes I to VII vide ‘Notification No, 215 published in the Gazette of India, Extraordinary, हु
Part III, Section 4 dated the 25 August, 2010; » 9: 11 हु
2. And whereas, sub-section (2) of section 23 ‘of the RTE Act provides that where a‘State does riot have adequate
institutions offering courses or training in ‘teacher education, or teachers possessing minimum qualifications laid down
| = ~—under sub-section (1) of section 23 of the RTE: Act are not available in sufficient rumbers, the Central Government may,
| if it deems necessary, by notification, relax the minimum qualifications required: for appointment as a teacher for such
1 period, not exceeding five years, as may be specified in that notification;
‘ ‘ + fy paced 1
3. And whereas, in exercise of the powers under sub-section (1) of section 35 of the RTE Act, the Central
Government laid down the guidelines on 8' November, 2010 for the State Governments for submitting proposal to the
Central Government for grant of relaxation under sub-section (2) of section 23 of the RTE Act; .
4. And whereas, the Central Government in exercise of the powers under sub-section (2) of section 23 ofthe RTE
Act granted relaxation to the State Government of West Bengal for a Period up to 31" March, 2014 vide notification - **
number S.O. 1352 (B), dated the 1* June, 2011 published in the Gazette of India, Extraordinary, Part I, Section 3, Sub-
section (ii), dated the 10" June, 201 1;
5. And whereas, the State Government of West Bengal vide its letter dated 23" March, 2015 submitted a proposal
to the Central Government for extension of, relaxation of the minimum qualification norms laid down by the NCTE in its
notification published in the Gazette of India on 25" August, 2010; - : .
6. And whereas, the Central Government examined and considered the proposal of the State Government of West .
Bengal for extension of relaxation under sub-section (2) of section 23 of the RTE Act;
7. Now, therefore, in exercise of the Powers conferred by sub-section (2) of section 23 of the RTE Act, the Central
Government hereby extends the relaxation to the State of West Bengal in respect of the minimum teacher qualification
norms notified by the NCTE as published in the Gazette of India vide No. 215 dated 25" August, 2010, in so far as they
relate to classes I-VINl, as under:— : ‘ .
(a) 2-year Diploma ‘in Elementary Education (by whatever name known) for appointment of a teacher in
classes I-V; and ‘ .
“(b) 1-year Bachelors in Education (B. Ed) for appointment of a teacher in classes VI to VII. . कु

<!-- page 4 -->

= .

. . \ ‘

| 4 THE GAZETTE OF INDIA : EXTRAORDINARY [ParT II—SEC. 3(ii)] *

््जश्््््चज्् ््ूु््७_७/शख|ख आआ)आ जन ७ओऊहओ्।)6४अ8ो।।॥७४्ट८ीी अल नहल्‍प७प्क्‍क्‍ऑइअि++

. ~ ‘Note: 1. The aforementioned relaxation shall be valid upto 31" March, 2016 and shall be subject to the following
conditions, namely: —

(i) as specified in the aforementioned notification of the NCTE, the Government of West Bengal shall conduct the

Teacher Eligibility Test (hereinafter referred to as TET) in accordance with the guidelines dated 11th February,

2011 issued by the NCTE and only those persons who pass the TET can be considered for appointment as a
teacher in elementary classes;

(ii) the State Government and otlier school managenients shall amend the recruitment rules to correspond with the

i minimum qualification norms laid down by the aforementioned notification of the NCTE;

(iii) . in the matter of appointment, the State Government shall give priority to those eligible candidates who possess

जे the minimum qualifications specified in the NCTE’s notification dated 25" August, 2010, and only thereafter,

consider the eligible candidates with the relaxed qualifications specified in this notification;

(iv) _ advertisement for appointment of teachers should be given wide publicity, including outside the State;

. (v) the State Government and other school managements shall ensure that ‘teachers not possessing the minimum
academic and professional qualifications laid down in the aforementioned notification of the NCTE shall
acquire the same within the time limit specified under sub-section (2) of section 23 of the RTE Act;

(vi) the State, Government and other school managements shall ensure that teachers who are appointed under the ,
relaxed qualification norms acquire the minimum qualification specified in the NCTE Notification within a
Period of two years from the year of appointment. हे 7
| 2. In accordance with sub-para (iii) of para 5 of the TET guidelines issued by the NCTE vide its letter dated 11th
February, 2011, the following persons shall also be eligible for appearing in the TET conducted by the State Government
| of West Bengal in respect of teacher appointments made in the State upto 31st March, 2016, namely: —
| . हे
| हि (i) for classes I to V - Senior Secondary (or equivalent) with at least 50% marks;
| (0). for-classes VI to VIL - Graduation with at least 50% marks. be
| nO [F. No. 1-17/2010-EE 4]
५
1 RINA RAY, Addl. Secy.
; :
i :
| “
न हु + :
Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-1 10054.
