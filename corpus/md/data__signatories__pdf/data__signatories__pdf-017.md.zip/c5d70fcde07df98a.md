---
doc_id: "c5d70fcde07df98a"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/181e7927ca1684d0f8793abbeb89d675.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Note No. 5 (2009 Series) dated: 14.05.2009 regarding guidelines for Foreign investment in Commodity Exchanges, issued by"
date: "2025-07-22"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "378fe59730eaba41"
---

<!-- page 1 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion
SIA(FC Section)
Press Note No. 5 (2009)
Subject: Guidelines for Foreign investment in Commodity Exchanges
Government of India had laid the guidelines for foreign investment in Commodity Exchanges vide
Press Note 2(2008) dated 12th March 2008. As per the guidelines, a composite ceiling for foreign investment
of 49% was allowed with prior Government approval, subject to the condition that investment under the
Portfolio Investment Scheme will be limited to 23% and that under the FDI Scheme will be limited to 26%.
Further, no foreign investor/entity including persons acting in concert will hold more than 5% of the equity in
these companies.
2.
It had been brought to the notice of the Government that some of the existing Commodity Exchanges
had foreign investment above the permitted level, as on the date of issue of the said Press Note and,
consequently, the Commodity Exchange(s) would be required to divest foreign equity, equal to the amount by
which the cap was being exceeded, in accordance with Press Note 2(2008). Commodity Exchanges were
permitted to avail of transition/complying/correction time for this purpose, up to 30.6.2009, vide Press Note 8
of 2008 dated 19 August, 2008.
3.
Difficulties have been brought to the notice of the government in complying with the provisions of the
Press Note within the stipulated time frame. The Government, on consideration and in order to facilitate the
existing Commodity Exchanges to comply with the guidelines notified vide Press Note 2(2008), has now been
decided to allow a further transition / complying/correction time to the existing Commodity exchange(s)
beyond 30.6.2009. Accordingly, all such Commodity Exchanges are hereby advised to adhere to the
conditions of Press Note 2(2008) by 30.9.2009.
4.
All Commodity Exchanges shall furnish a compliance report informing the foreign investment in the
Commodity Exchange as on 30.9.2009, along with details of equity structure, to the Department of Industrial
Policy & Promotion, Department of Consumer Affairs, Foreign Investment Promotion Board, the Forward
Market Commission and SEBI.
5.
Non-compliance of the conditions of Press Note 2(2008) after 30.9.2009 would be a violation of the
Foreign Exchange Management Act, 1999.
(Gopal Krishna)
Joint Secretary to the Government of India.
D/o IPP F.No. 12(58)/2005-FC dated 14th May 2009
Copy forwarded to:
1. Press Information Officer, Press Information Bureau- for giving wide publicity to the above Press
Note.
2. F.No. 5/10/2006-FC
