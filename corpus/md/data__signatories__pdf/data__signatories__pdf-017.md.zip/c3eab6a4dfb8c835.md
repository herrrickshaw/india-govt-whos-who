---
doc_id: "c3eab6a4dfb8c835"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/3fb7e89dc1aab510d0d952e528d9ff77.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allocation of Location Routing Number LRN to Ms ZVC India Private Limited for Kolkata, Kerala and Gujarat LSAs"
date: "2025-08-11"
pages: 2
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "6ccf16b7a42144b6"
---

<!-- page 1 -->

Government of India/ भारत सरकार
Ministry of Communications/ सचार मत्रालय
Department of Telecommunications/ aaa fert
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001/
संचार भवन, 20 अशोक रोड, नई दिल्ली-110001
(Access Services Wing)
No. 16-09/2024-AS-III/ 150 Dated:|! .07.2025
To,
Mis ZVC India Pvt. Ltd.
Raheja Platinum, Marol.
Andheri East, Mumbai -400059.
Subject: - Allocation of Location Routing Number (LRN) to M/s ZVC India
Private Limited for Kolkata, Kerala and Gujarat LSAs.
In consideration to the request of M/s ZVC India Private Limited for
allocation of LRN codes, it is decided to allocate following LRN codes:
आएएन कोड के | के आवंटन के ings sree sear T age feifies के अनुरोध पर
विचार ws हुए, एलआरएन RR St का su लिया गया है: के
Name of LSA | LRN Code allotted
ZVC India Private Limited Kolkata 3030
ZVC India Private Limited Gujarat 3032
2. These LRN codes are allocated on the condition that this code will be
reverted back to the Licensor automatically after 6 months from the date of
issuance of this letter if not utilized.
ये एलआरएन कोड़ इस शर्त पर आवंटित किए जाते हैं कि यदि इनका उपयोग नहीं किया जाता है तो
यह कोड इस पत्र के जारी होने की तिथि से 6 महीने के बाद स्वचालित रूप से लाइसेंसकर्ता को वापस कर
दिया जाएगा।
Digitally signed by
3. This is issued with the approval of DDG (AS). VAIBHAV JAIN
यह उप महानिदेशक (एएस) के अनुमोदन से जारी किया गया है। Date: 11-08-2025
16:59:07
निदेशक(88-॥॥)
Ph. No. 011-23372488
Copy for kind information and necessary action, if any, to:
सौजन्य सूचन। एवं आवश्यक कार्यवाही हेतु प्रतिलिपि प्रेषित:
1. Secretary, TRAI .
2. Director (T), DGT HQ, DoT with request to convey the allocation to related
LSA field unit.
3. All Access Service Providers

<!-- page 2 -->

4. All MNP Licensees.
5. A copy for upload on DoT website.
