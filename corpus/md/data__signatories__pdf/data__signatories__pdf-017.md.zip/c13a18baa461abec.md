---
doc_id: "c13a18baa461abec"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/11/49d04fdf50b8f9cf8d453919bd94545d.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 27.10.2023 for the upgradation to Group 'A' Panel Counsel, Supreme Court of India"
date: "2023-11-06"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "231b1ae784caeed2"
---

<!-- page 1 -->

F. No, J-11016/8/2023-Judicial (1)
Government of India
Ministry of Law and Justice
Department of Legal Affairs
Gudicial Section)
कक कक
Shastri Bhawan, New Delhi,
Dated the2#October, 2023
ORDER
The President is pleased to upgrade following Advocates as Group ‘A’ Panel Counsel
for conducting Central Government Litigation before Supreme Court of India as mentioned
below, for a period of three years from the date of this order or until further orders,
whichever is earlier:
Supreme Court of India
Upgradation to Group ‘A’ Panel Counsel
51. Name of Advocate (S/Shri) | (०7६३ (S/Shri) Contact alee Enrollment No.
1. | Ms. Mansi Sood Mobile: 9632745265 D/2546/2015
Email: mansi.sood.9@gmail.com |
2. | Ms. Sonali Jain B-6/2, Safdarjung Enclave, New Delhi, | D/5914/2017
110029
hie a Mob: 9654090194 eth
Kartikay Aggarwal Mobile: 9013223344 D/9793/2022
Email: kartika aggarwal@yahoo.com | | |
Varun Chugh 44Kt. Moti Ram Hathi Gate, Amritsar ee D/4294/2019
143001
Mob: 9988799877
| Email: 9988799877 _
2. Consequent upon above up-gradation of the four Advocates their names occurring
at Serial no. 51 (Ms. Mansi Sood) and 52 (Ms. Sonali Jain) of List under the heading Group
‘B’ Panel Counsel and no. 86 (Sh. Kartikay Aggarwal) of Group ‘C’ Panel Counsel of Order
No. J-11017/27/2023-Judl. (3) dated 7 October, 2023, and at serial no. 81 (Sh. Varun
Chugh) in Order No. J-11016/2/2022 dated 06'° September, 2022, stand deleted.
3. The engagement of the aforesaid advocate will be governed by the terms and
conditions at par with Group ‘B’ Panel Counsels as per this Department’s OM No. 21(4)/99-
Jud]. dated 24.09.1999 read with OM no. 26(1)/2014/Judl. dated 01.10.2015 &
instructions issued subsequently through OMs, especially the OM No. J-16/11/2017-Judical
dated 08.02.2018. The aforesaid OMs are available on the website of this Department i.e.,
www. legalaffairs.gov.in in the tab ‘Judicial Section’ under heading ‘Circulars pertaining to
litigations’.
4. Hindi version of this order will follow.
(ee
(Vijay Kumar Sharma)
Senior Adviser
Copy through email to:
1. PS to MoS (1/C) L&J.
2. Sr. PPS to Law Secretary/PSO to AS (RSV)/PSO to AS (RM) / Sr. PPS to AS (ARR) / Sr. PPS
to JS (SA).
3. PS to Attorney General of India/PS to Solicitor General of India.
4. PS to all Additional Solicitor General of India of Supreme Court of India, in the list.
5. The Registrar, Supreme Court of India, New Delhi
6. The In-charge, Central Agency Section, Supreme Court Compound, New Delhi.
7. The Pay and Accounts Office, Department of Legal Affairs, New Delhi.
8. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
To be updated on the website of this Department i.e. www.legalaffairs.gov.in in tab
"Judicial Section’ under the link ‘Orders related to empanelment of Advocates for Uol' for
the information of all concerned.
9. Spare Copies. K Geir
(Kumar Gaurav)
Section Officer (Judicial Section)
Tel: 011-23384945
email: judicial-dla@nic.in
