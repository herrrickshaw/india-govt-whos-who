---
doc_id: "c4fe77bbfb9851ca"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/07/74a1dfb4f337eae01d375b8fe9a6b543.pdf"
ministry: "Tourism"
title: "Instructions regarding Financial Assistance to Institutes/Central Universities for Organizingresearch related events (Meetings/Conference/Workshop/Seminars)"
date: "2024-09-03"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d504e0e64d928779"
---

<!-- page 1 -->

File No.23/1/2020-MRD-Pt
Government of India
Ministry of Tourism
(Research & Analytics Division)
Subject: -Instructions regarding Financial Assistance to Institutes/ Universities for
Organizing research related events (Meetings/Conference/Workshop/Seminars).
1. The guidelines of Market Research – Professional Services activities under CBSP scheme,
which has a provision for providing Support to Institutes/Universities for
Organizing/Conducting Meetings/Conferences/Workshops/Seminars/etc. for the purpose of getting
inputs from Experts, State Governments, Industry, Intellectuals, etc. for development of Tourism.
2. The institutes are selected by the Ministry of Tourism on the basis of their proposals, which should
be submitted at least 3–4 Months prior to the event. While selecting institutes, institutes of
national importance or those affiliated to central ministries are preferred.
3. The Minimum number of participants to the event is restricted to at least 30. In the form
of deliverables, the supported event should display a logo of “Incredible India” in all the
printed material, brochures, banners, posters, podium, kit, etc. Book of abstracts/Report of
proceedings containing Actionable Points/way forward for Ministry of Tourism, Feedback
Report of the participants and proof of logo displayed during the conference. Compendium of
papers are also to be submitted to the Ministry. The logo of Incredible India must be taken from
Ministry of Tourism.
4. Total fund would be released after the event on submission of invoice, details of total
expenditure and deliverables. The invoice should be signed in original and should have a
crossed revenue stamp of Rs.1.
5. The proposal, in the format given in Annexure 1, should be forwarded through the
Principal/Registrar/Head of Institution/etc. Following documents should be submitted along
with the proposal:
i.
An Undertaking as per format given in Annexure 2.
ii. Agency Details as per format given in Annexure 3.
iii. Bank Details as per format given in Annexure 4.
6. An approval letter would be issued by the Ministry of Tourism upon acceptance of the
proposal. The approval letter would contain the exact amount which has been sanctioned.
7. The following deliverables have to be met/furnished: i.
Proof of Display of “Incredible India” logo/any other logo as desired by Ministry of
Tourism in all the printed material. In this regard a copy each of printed material along
with photographs of kit, banners, podium, etc. has to be furnished.
ii.
Book of Abstracts/Report of proceedings and Compendium of papers should be
provided in both hard and soft copy. (at least 2 copies)

<!-- page 2 -->

8. The following needs to be submitted within 2 weeks of the completion of the event.
i. Utilization Certificate of full amount prescribed GFR 12A format as per Annexure 5.
ii. Invoice of the sanctioned amount. The Invoice should be signed in original and contain a
crossed revenue stamp of Rs.1 as per Annexure 6
iii. Total expenditure(detailed)as per Annexure 7
iv. Deliverables as mentioned in para 7.
9.

A University/Institute is eligible for funds for only one, Organizing/Conducting
Meetings/Conferences/Workshops/Seminars/etc. ‟per financial year”. Funds for subsequent
financial year would be sanctioned only upon receipt of UC of the full amount released during
the previous financial years.
*****
Enclosures:
Annexures: 1 to 7

<!-- page 3 -->

Annexure 1
Format for proposal submission
(On letter Head of Institute/University)
[The proposal should be forwarded through the Principal /Registrar/Head of Institution/etc.]
Subject: - Central Financial Assistance from the Ministry of Tourism for organizing research
related ‘Event’.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.

Topic of ‘Event’: Category: Meetings/Conference/Seminar/Workshop [ Tick one]
Introduction to the Topic:
Scope Objectives of the ‘Event’:
Expected Insights:
Venue:
Dates of ‘Event’:
Number of Participants:
Program details: Containing Date/Time Slot/Activity/Session.
Budgetary Estimates: Containing Item Description & approx. Budget.
Any other Information
Nodal Officer Details: Name
Mobile No.:
Email:
Postal Address:

Name of Registrar/Head:
Designation:
Seal:
Address:
Phone Number:

*****

<!-- page 4 -->

Annexure 2
Undertaking
(To be submitted on letter head of the Institute/University by the Nodal officer)
Subject: - Undertaking furnished in respect of the central financial assistance sought from the
Ministry of Tourism under the Market Research Professional Services activities of CBSP scheme for
organizing research related ‘Event’.
Title of the
‘Event’: Category: Duration: It is stated that no UC pendency is with the Institute/University in respect of Central Financial
Assistance (CFA) received from the Ministry of Tourism under MRPS activities of CBSP scheme.
I / We agree to: i.
All the rules/regulations regarding utilization of amount that may be granted by the
Ministry of Tourism to the Institute/University.
ii.
Submit the deliverables within 2 weeks of completion of the ‘Event’:
iii. The Incredible India logo/any other logo as desired by Ministry would be prominently
displayed.
iv. Submit Utilization Certificate of the full amount within 2 weeks of completion of the ‘Event’.
v.
Neither speakers deviate from the given topic nor dwell into any controversial/antinational subject.
Date:

Counter signature of Finance Officer

Signature of the Nodal officer with seal &
designation

*****

<!-- page 5 -->

Annexure 3
Agency Details (On letter Head of Institute/ University)
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.

Agency Name:
Type of Registration:
Act / Registration / No.:
Date of Registration:(DD/MM/YYYY):
Registering Authority:
State of Registration:
PAN No:
Service tax No:
TIN No:
TAN No:

11.
12.

Unique Agency Code:
Address/Communication details
Block No/Building/Village/Name of Premises:
Road/Street/P.O.:
Area/Locality: City:
State:
Dist.:
Pin Code:
Contact Person: Phone no.:
Alternate Phone No./Mobile No.:
Email:

*****

<!-- page 6 -->

Annexure 4
MANDATE FORM
ELETRONIC CLEARING SERVICE (CREDIT CLEARING) REAL TIME GROSS SETTLEMENT
(RTGS)FACILITY FOR RECEIVING PAYMENTS
A. DETAILS OF ACCOUNT HOLDER: NAME OF ACCOUNT HOLDER
COMPLETE CONTACT ADDRESS
TELLEPHONE NUMBER/FAX/EMAIL
B. BANK ACCOUNT DETAILS: BANK NAME
BRANCH NAME WITH COMPLETE ADRESS
TELEPHONE NUMBER AND EMAIL
WHETHER THE BRANCH IS COMPUTERISED ?
WHETHER THE BRANCH US RTGS ENABLED?
IF YES, THEN WHAT IS THE BRANCH’S IFSC
CODE
IS THE BRANCH ALSO NEFT ENABLED ?
TYPE OF BANK ACCOUNT
(SB/CURRENT/CASH/CREDIT)
COMPLETE BANK ACCOUNT
NUMBER(LATEST)
MICR CODE OF BANK
DATE OF EFFECT: I hereby declare that the particulars given above correct and complete If the transaction
is delayed or not effected at all for reasons of incomplete or incorrect information I would not
hold the user institution responsible. I have read the option Invitation letter and agree to
discharge responsibility expected of me as a participant under the scheme.
(…………………………)
Signature of Customer
Date:
Certified that the particulars furnished above are correct as per our records
(Bank’s Stamp)
(… ........................... )
Signature of Customer
Date:
1. Please attach a photocopy of cheque along with the verification obtained from the bank.
2. In case your Bank Branch is presently not “RTGS enable”, then upon graduation to “RTGS
Enabled” branch, please submit the information again in the above Performa to Department
at earliest.
******

<!-- page 7 -->

Annexure 5
GFR 12 – A
[(See Rule 238 (1)]

FORM OF UTILIZATION CERTIFICATE
FOR AUTONOMOUS BODIES OF THE GRANTEE ORGANIZATION

UTILIZATION CERTIFICATE FOR THE YEAR… .................... in respect
of recurring/non-recurring
GRANTS-IN-AID/SALARIES/CREATION OF CAPITAL ASSETS
1. Name of the Scheme......................................................................................
2. Whether recurring or non-recurring grants.......................................................
3. Grants position at the beginning of the Financial year
(i) Cash in Hand/Bank
(ii) Unadjusted advances
(iii) Total
4. Details of grants received, expenditure incurred and closing balances: (Actuals)
Unspent
Balances
of Grants
received
years
[figure as
at Sl. No.
3
(iii)]
1

Interest
Earned
thereon

Interest
deposited
back to
the
Government

2

3

Grant received during
the year

Sanction
No.
(i)

Total Expenditure Closing
Availab incurred
Balances
lefunds
(5-6)
(1+23+4)

4
Date Amount
(ii)

5

6

(iii)

Component wise utilization of grants:
Grant-in-aid–
General

Grant-in-aid–Salary

Grant-in-aid–creationof
capital assets

Details of grants position at the end of the year
(i) Cash in Hand/Bank
(ii) Unadjusted Advances
(iii) Total

Total

7

<!-- page 8 -->

Certified that I have satisfied myself that the conditions on which grants were sanctioned have been
duly fulfilled/are being fulfilled and that I have exercised following checks to see that the money has
been actually utilized for the purpose for which it was sanctioned:
(i) The main accounts and other subsidiary accounts and registers (including assets registers) are
maintained as prescribed in the relevant Act/Rules/Standing instructions (mention the Act/Rules)
and have been duly audited by designated auditors. The figures depicted above tally with the
audited figures mentioned in financial statements/accounts.
(ii) There exist internal controls for safeguarding public funds/assets, watching outcomes and
achievements of physical targets against the financial inputs, ensuring quality in asset creation
etc. & the periodic evaluation of internal controls is exercised to ensure their effectiveness.
(iii) To the best of our knowledge and belief, no transactions have been entered that are in violation
of relevant Act/Rules/standing instructions and scheme guidelines.
(iv) The responsibilities among the key functionaries for execution of the scheme have been assigned
in clear terms and are not general in nature.
(v) The benefits were extended to the intended beneficiaries and only such areas/districts were
covered where the scheme was intended to operate.
(vi) The expenditure on various components of the scheme was in the proportions authorized as per
the scheme guidelines and terms and conditions of the grants-in-aid.
(vii) It has been ensured that the physical and financial performance under… ..... (name of the scheme
has been according to the requirements, as prescribed in the guidelines issued by Govt. of India
and the performance/targets achieved statement for the year to which the utilization of the fund
resulted in outcomes given at Annexure – I duly enclosed).
(viii) The utilization of the fund resulted in outcomes given at Annexure – II duly enclosed (to be
formulated by the Ministry/Department concerned as per their requirements/specifications.)
(ix) Details of various schemes executed by the agency through grants-in-aid received from the same
Ministry or from other Ministries is enclosed at Annexure –II (to be formulated by the
Ministry/Department concerned as per their requirements/specifications).
Date:
Place:

Signature

Signature

Name..........................................................

Name.....................................

Chief Finance Officer (Head of the Finance)

Head of the Organization

(Strike out inapplicable terms)
*****

<!-- page 9 -->

Annexure 6
Name of Institute/University (On letter Head of Institute/University)

PRE-RECEIPTED INVOICE
Subject:-Title of ‘Event’:
Total Sanction cost:
Sanction No: File no. of Approval letter
Date:
Central Financial Assistance (CFA) for the captioned Event
Amount Sanctioned
Ministry of Tourism
(Amount in Rs.)

by Purpose
Title of ‘Event’

Amount Released
Ministry of Tourism
Total Sanction cost
(Amount in Word)

by

PAN No:__________
TIN/TANNO.:------------

Name & Signature of Nodal officer with seal of Institution

Revenue
stamp of
Rs.1.

******

<!-- page 10 -->

Annexure-7
Name of Institute/University (On letter Head of Institute/University)
PAN NO.:------------------------TIN/TAN NO.:-----------Total expenditure (detailed)statement for Central Financial Assistance for organizing
conference/seminar/workshop ------------------------Sr. No. Head
Details
Amount in Rs.
Remark
1
Venue charges
2
Honorarium to the invited
speakers
3
Boarding Lodging of
participants
4
Local
conveyance/Transport
5
Working Lunch/Dinner &
Refreshment charges
6
Stationery kit charges
7
Printed material costs
8
Travel costs of
Participants
TOTAL
PAN No:__________
TIN/TANNO.:------------

Head of the institute/Principal/Registrar/convener of the seminar/authorized signatory

(Seal)
*****
