---
doc_id: "c27fe7fbebde69ea"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/tendercancel.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "Tender Cancellation Notice"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c0a77db0f94c340b"
---

<!-- page 1 -->

i
है Government of India
Ministry of Social Justice & Empowerment
Department of Social Justice & Empowerment
Shastri Bhawan, New Delhi
: Dated the ot December, 2017
>
Tender Cancellation Notice
The Notice Inviting Tender No. D-11020/01/2014-Gen.I dated 23.05.2017 for
hiring of services of Security Guards in the Department of Social Justice & है
Empowerment stands cancelled due to administrative reasons.
(Asokan P K)
Under Secretary to the Govt. of India
Tel: 23382184
