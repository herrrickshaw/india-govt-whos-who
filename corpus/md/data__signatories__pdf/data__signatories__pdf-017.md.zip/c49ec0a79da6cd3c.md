---
doc_id: "c49ec0a79da6cd3c"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_69564438d8cf11.35080432.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Order - UPSC has approved the Select Lists for promotion from State Forest Service of Assam-Meghalaya Joint Cadre (Assam Segment) to the Indian Forest Service for the Select List Year 2021, dated 01-01-2026"
date: ""
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "af3ad605a6f423d1"
---

<!-- page 1 -->

| ey हु
140.17013/24/2022 -178.॥ हु
Government of India :
Ministry of Environment, Forest and Climate Change
: : Indira Paryavaran Bhawan,
. : au 6th Floor, Prithvi Block,
: : Jor Bagh, Ali Ganj, New Delhi-110003
: Date: 01% January, 2026 1
. ORDER [
In exercise of the-provisions contained in Sub-Regulation 3 of Regulation 7
of the Indian-Forest Service (Appointment by Promotion) Regulations, 1966, Union
Public Service Commission:has approved the Select Lists for promotion from State - |
: Forest Service of Assam-Meghalaya Joint Cadre (Assam Segment) to the Indian
Forest Service for the Select List Year 2021 containing the names of the following |
officers:.of the:'State’ Forest. Service of Assam-Meghalaya Joint Cadre (Assam . |
sek Segment), : towards filling .up.of promotion: quota vacancies available in Assam. . I
‘ Segment of Assam-Meghalaya Joint Cadre, of the Indian Forest Service: : i
DS eee me EE od
os] NMP RY |
: हु |
a f
J |
“—Gaunadeep Das 08.08.1966
: a rishna Kamal Deuri 4.09.1966 |
‘ - oe .: “The name’ of the ‘officer at S.No. 2 has been included in the list provisionally {
oc Subject: to clearance: in. the disciplinary proceeding and criminal proceeding ot
pending against him:and grant of Integrity Certificate by the State Government. 1
4. The name of the officer at S.No. 5 has been included in the list provisionally |
subject to grant of Integrity Certificate by the State Government. |
ः |;
. |
| | eae |
8
है (Prem Prakash Maurya) ;
Under Secretary to the Government of India i
Tel:01 1-20819192 |
|
|
. {
४ |
: रत

<!-- page 2 -->

sen, spur diEhesChief Secretary, Govt.of Assam, Dispur- It is requested that the officers :
cossucl Selemaypleasebe: informed.:of.the aforesaid Select. List-under intimation. to this
“hor racnoeteMinistry: The State Governments further requested to forward necessary proposal है
१16 #8 अश्णव्यातक्राणयातांणा:एंण 18 :छॉकां॥७ "0885 to the Indian Forest Service along with the E
naviediately:- following documents to.this Ministry immediately:- 9...
जज veneers i. A declaration as to singular marital status.
often inthe Stati Written:consent for termination of lien in the State. Forest Service on... ‘
bSerdee.y oa: confirmation in the.Indian:Forest Service... Cal gk
‘rman that trereilis-Accertificate:by: the: State:Government that there is no: stay order.of any-court I
ate Forest Geryiceprohibiting thecappointment of: State Forest Service officers-by promotion:to 77:
y Segmant of Ass-the Indian Forest:ServicezAssam Segment of Assam-Meghalaya Joint Cadre \
nemant, thebthendvisA certificate by the:State:Government, that there is no disciplinary/Vigilance. «:
ainst the ofiners reccase pending/contemplated-against the officers recommended for promotion. 5 |
nomerit thatcths.a icA Certificate by.the:state:Government that the officers are in'service as one).
ces, date. :
Government<2.ihe'Principal. Secretary (Forests), Government of:Assam, Dispur. 2° 30:
yom Foresis 3::-The® Principal:Chief. Conservator of Forests &-HoFF, Government: Assam, |
Dispur: .
ce Wommissia4, DheSeeretary, Union Public: Service Commission, ‘New. Delhi... weer nee |
of Meghalaya 52The:Chief Secretary; Government of Meghalaya, Shillong. | : aos |
sv © “Guard FileAvebsite copy. ० लक : |
ce |
: |
i
: |
- |
|
. so |
. . |
-_ '. . . !
|
* |
|
|
|
t
oo Lok |
- |
. ॥
