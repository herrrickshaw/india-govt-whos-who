---
doc_id: "c0d6bee14cf94fb0"
source_url: "https://www.dahd.gov.in/static/uploads/2025/06/df911f1c3d20afcb497a9b9c348405dd.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "In partial modification of Office Order dated 1st July 2024 (copy enclosed), the following officers are assigned the additional Charge of the work, in addition to their present work, with immediate effect till further arrangement is made."
date: "2025-06-27"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c9d218099968211c"
---

<!-- page 1 -->

F.No.A-l 901 1/5/2024-Admn.l (E-2901 6)
Government of lndia
Ministry of Fisheries, Animal Husbandry & Dairying
Department of Animal Husbandry and Dairying
Krishi Bhawan, New Delhi-'110001
Dated, the 4th September 2024
OFFICE ORDER
ln continuation and partial modification of Office Order of even number dated
1"1 July 2024 (copy enclosed), the following officers are assigned the additional
charge of the work as mentioned against their names, in addition to their present
work, with immediate effect till further arrangement is made; S. No.
1

2

3

Name and designation

Additional charge assigned

s. Varsha Joshi, Additiona
ecretary (C&DD)

I matters related to Animal Quarantine and

rtification Services (AQCSS) and Centre
llence for Animal Husbandry (CEAH)
ints '12 and 13 against S.No.3 of
rder dated 01 .07 .2024
AbhUit Mitra, Anima lmatters assigned to NLM Division
ints 1 to 7 against S.No.3 of Office Orde
usbandry Commissioner
aled 01 .07 .2024
Administratio
r
Sha
works related
Suparna
eadquarters)
houri
Points I to 11 against S.No.3 of Offlce Orde
ated 01.07 .2024

r.

I

to

2. This issues with the approval of Secretary, AHD
Encl.: As above
(Sanjib
Deputy Secretary (Admn.)
Tele: 01 1-23389606

Distribution: -

1. Ms. Varsha Joshi, Additional Secretary (Cattle & Dairy Development)
2. Dr. Abhijit Mitra, Animal Husbandry Commissioner (AHC), DAHD.
3. Ms. Sarita Chauhan, Joint Secretary (Livestock Health).
4. Dr. Suparna Sharma Pachouri, Joint Secretary (Coordination/Parl.).
5. Advisor (Statistics).
2t-

<!-- page 2 -->

-2Copy for kind information to:

'1. PS to Hon'ble Minister, MFAHD.

2. Oftice of Hon'ble Minister of State (SPSB), MFAHD.

3. Office of Hon'ble Minister of State (cK), MFAHD.
4. Sr. PPS to Secretary, AHD.
5. PSO to AS&FA.

6. PPS to CCA, DAHD

7. All J Cs/DCs/Directors/DSs/USs/Sections, DAH D.

8. Hindi Section for providing Hindi Version.
9. NlC, DAHD for updating the website of the Department.
10. Guard File.

,

anjib Bhattacha
Deputy Secretary (Admn.)
Tel: 01 1-23389606
(

I

<!-- page 3 -->

?26858 / 20?4 / ADMIN_l-DADF

{60
"6

I
A- 1 e0 1 1/s/2024-A d mi n-tt (E-27 4eq (L-

I

mW \

\
Government of India
/
Ministry of Irisheries, Animal Husbandry afid Dairying
Department of Animal Husbandry and Dairying
*rt*'**

KrishiBhawan, New Delhi - I10001
l)ated, the I't July 2024

OFFICE ORDER
With 0re approval of the Competent Authority and in supersession of Office
Ordcr datcd 22"d March 2A24, thc following arrangcmcnt of work allocation is hcreby
made amongst Animal Husbandry Commissioner (AHC), Additional Secretary (AS),
Jornt Secretaries and Advisor (Stat.) in this Department, rvith immediate ettbct and until
lirrther orders: S.

Namc

and

Work Allocation

No.

Dr. Abhijit Mitra,

Animal }lusbandry
Conrrnissiuner (AHC)

l. All technical matters pertaining to Animal

Llealth and Production, Animal Genetic
Resources, Anirnal Germplasm/ Biodiversity,
Animal Carc & Wclfarc.

2. Tecltnrutl rnattcrs relaling to Bio-sccurity and
Quarantinc issues.

3. Preparation of Animal I{usbandry and Dairy

Manuals tbr Production, Breeding, Animal

r\HC

I lealth and Bio-sccurity

for animal farms.

4. Teclrnical matters Lelated to Veteriuary Council
of lndia.

5. Tecllrrical rrrattcrs relatcd to trade and Sanitaly
Phyto-Sanitary issucs.

6. Tcchnical mattcrs rclatcd to sctting up of
standards for Livestock Products as per Bureau

oflndian Standards.

7. Technical matters related to Monitoring of drugs
and pesticides residues rn livestock products,
meat and dairy products.

8. Technical matters related to coordination with
Department of Biotechnology, Department of

Science & Technology, Department of
Agriculture Research and Education
(DARE)/lndian Council of Agricultural
Research (ICAR) and any other technical issue

with Central Government/ State Covernment
i

,
,

2
File No. A-22or1./l/2o24-Admin-l

(Computer No. 29016)

Generated from eoffice by KUNAL GUPTA, ASO-Admnl, A5O(ADMIN-I), DADF-DEPARTMENT on O,t/09/2o24 o,.:ll pm

<!-- page 4 -->

2268s8 /2024 / ADMIN_1 -DADF

9. All technical matters relating to NIAH.
10. All technical matters related to Avian influenza.
I

I
I

t

l. All matters pertaining to OIE, including reporling
about listed diseases (six monthly and yearly).

12. All technical matters related to coordination for
quality testing of vaccines under National

programmes including timely availability of
animals for the same.
13. All matrers rclated to RDDLs/CDDI,.

14. Technical matters related to One Health matters

I
I

I
I

I
I

i

I

(including World Bank project), AMR and
residue monitoring.

15. All matters related to ECAI{ and regulatory
affairs.

16. Technical matters related to Risk Management
cascs of trade including market access matters
relatcd to t.l{ Division.

17. l'cchnical matters rclated to exotic, emcrging
and re-emerging diseases- Glanders, Rinderpest,
ASI?, l,SD etc.

18. National [rocal Point Ibr Animal f)iscascs

Notification and Vetcrinary Products OIll.
19. AII matters relating to One Flcalth supporl unit.
2.

Ms Varsha Joshi, l. National Dairy Plans.

Additional Sccretary 2. Dairy Development Schemes.
(Cattle & Dairy 3. National Project for Bovine and Dairy
Developrnent)
Development.

4. Administration of field offices, i.e. Cattle &
Dairy Developurent, Central Cattle Breeding

|

I

Farms and Central l{erd Registration Scheme.

Additional Secretary 5. Matters related to Information Technology and

(vo

C&EP (Credit, Extension and Publicity).

6. Establishment matlers of Delhi Milk Scherne and
National Dairy Development Board.

7. All matters related to the credit including Kisan
Credit Card.

8. All matters pertaining to lnass communication.
Inforrration Technology, media outreach and
Investment Promotion Cell, IEC activities and
publicity related activities through all medir"uns
including social media across the country.

9. Chief Vigilancc Officer/ Probity Portal.

3,
Generated from eoffice by KUNAL GUPIA, ASO-Admnl, ASo(ADMIN-1), DADFpEPABTMENT on o+zos,,zoz+ oirr p.

n

ri
L.

<!-- page 5 -->

?268s8 / 2024 / ADMIN-l-DADF

10. Technical matters related to Preparation of
Livestock and Dairy Development Work
Plans and National Livestock Policy'
11. Technical matters related to BMGF project
and its effective implementation'
12. All matters relating to Trade.
13. National Focal Point for Sanitary and Phytosanitary (SPS) matters with WTO and FAO'
14. Coordination with States of Gujarat, Goa,
Arunachal Pradesh, Mizoram, Maharashtra,
Rajasthan, Bihar and all Union Territories
1 (except J&K and Ladakh).
l5.Coordination with Department of Agriculture
Cooperation and Famers' Welfare, Ministry of
Food Processing Industries, Ministry of Rural
Devclopmcnt, Ministry of Panchayati Raj,

Ministry of Skill DeveloPment and

Entrepreneurship, M ini stry of Consumer Affairs,
F'ood & Public Distribution, FSSAI, Department

of Commerce, APEDA.
3.

Shn O.P. ChaudharY
Joint SecretarY
(National l.ivestock
Mission)

Joint SecretarY (OPC)

. Mission Director, National Livestock Mission
subsuming: -

O

PoultrY I)eveloPment;
fu1) Goat and SheeP DevcloPment;

0j0 PiggcrYDeveloPmcnt;
(iv) DcveloPment of Meat Animals;
(y) Rural Slaughter l-Iouse Scheme;
fui Feed and Fodder including Testing;
ftin Livcstock Insurancc Schemes:

(viii) Animal I.lusbandry E'xtension Schemes'
2. Administration (NLM) (work relating to
Regional Fodder Stations, Central Poultry
Development Organizations, Central Poultry

Producis Testing Centte, Gurgaon, Central Sheep
Breeding Farm, I-lissar).

3. All matters related to Rashtriya Kamdhenu
Aayog.
4. Coordination with the States 'of Himachal

Pradesh, Uttarakhand, Punjab, Haryana, Uttar
Pradesh, Madhya Pradesh, UTs of J&K and
Ladakh.

!

/-t

I
J

4
File No. A-22011l1/2o24-Admin-l (Computer No' 29016)
pm
DADF-DEPARTMENT on 04lo9l2o24 04:11
cenerated from eoffice by KUNAL GUprA, Aso-Admnl, Aso(ADMIN-r),

<!-- page 6 -->

2268s8/ 2024/ ADM lN_l_DADF

* /.i

5. Coordination with l\4inistry of Environment &
I,orest, MNRE, Ministry of Electronics ancl
information Technology, Ministry of Jal Shakti,
Ministry of Textiles.
6. All matters relating to Equine Development and
registration of Stud Farms of India.

I

I

I

I

7. All matters relating to Animal Welfare Board
and Project Development Cell (involving Invest

India and AI-IIDF team), all matters related to
DPIIT.

8- Work rclating to cstablishment matters ol.
officers and staff posted in Headquarters

(Establishmenr-Hes).

9. Cash and General Administration_II.
10. All matters relating to reservation in services
in respcct of SCs/STs/ OBCs/ltWSs/pWDs
undcr thc administrativc control of thc
DAHD.

4

Ms Sarita Chauhan
Joint Secretary,
(Livestock I-lealth)

11. Nodal Olficcr - ACC Vacancy Monitoring
System (AVMS).
12. AII mattcrs of Animal euarantinc and
Certification Services (AeCSs).
I3. AII nrattcrs rclating to Centre ol.Ilxccllencc
fbr Aninral [Iusband rY
Ban aklrc.
l. All rnatters relating to livestock Ilealth including
administration of Central Sector schcmc

"l.ivestock l-lealth &
Programme (LllDCp)',.

Discasc Control

2. All matters related to Veterinary Council of
Joint Secrctary (LH)

India.

3. Mission Direcror, National Animal Disease
Control Programmc for FMD and Brucellosis.

4. Nodal Officer, Disaster Management.
5. All administrative marters related to CCS_NIAH,
Baghpat.

5, All matters related to parliament, VIp references,

Wcbsite, Dashboard, Cabinet, matters related to
I-I-I Division.

7. AII Administrative matters related ro
coordination for quality testing of'vaccines under
National
programmes
including tirnely
AV
of
fbr the same.
5
File No. A-zzO11/1,/2024_Admin_t (Computer
No. 290,6)
Generated from eoffice by KUNAL
GUPTA, ASO-Admnl, ASO(ADM|N_|),
DADF-DEPARTMEN

, ',t,,,-

f on 04/Og/2024 o4t11 pm

,:'

j.

.:4..;.'

"

\/

<!-- page 7 -->

22 685 8 / 2O24 / ADM INIDAD F

8

All administrative matters related to One Health

(including World Bank Project)'
cases of
9 Matters related to Risk Management
to
related
truJ" in.tu,ting market access matters
LH Division.
to exotic'
10. Administrative matters related
Glanders'
diseaseemerging and re-emerging
RinderPest, ASF, LSD etc'
West Bengal'
I- l.
-- Coordination with StatesNadu'
Cnnuttisgarh, Odisha, Jharkhand' Tamil
Andhra
and
Kerala
Karnataka,

Telangaia,
Pradesh.

12. Coordination with Ministry of Health

and Family

Welfare, Ministry of Ayush, Ministry of
Pharmace uticals.

Dr, SuParna Sharma

5

Pachouri,

Joint

SecrctarY

(Coordination/Parl.)

Joint SecretarY (SSP)

All matters related to Plan Coordination of the

Departmcnt of Animal Flusbandry &
2. Coordination with NITI AaYog'

Dairying'

3. Nodal Otliocr - On-linc Monitoring of Court

Cases, Swachli Bharat Abhiyan' e-samiksha'
RTl, Public Grievances, DBT'
4. All matters relating to General Coordination'
All matters relating to Official Language and

5.

Parliamcnt.

6. Coordination with States of Assam' Manipur'
lut.gt,utuyer, Tripura, Sikkim and

Nagaland'

of

7. Coordination with DOP&T' Department of
Administrative Reforms & PG' Ministry
Tribal Affairs & DoNEIf'
8. Coordination of legal matters'
'1.

Shri Jagat lTazarrka,

l. AII matters related to Livestock Census, Breed
Census.

Adviser
2

All matters relatcd to basic Animal Husbandry
Statistics.

Adviser (Statistics)

3. Work relating to Staff posted in AHS Division'

4. QualitY Monitoring - National Level Monitors

z.

(Ic) unit would henceforth be
till futher orders'
Secretary (Admn.)lo Secretary, AI{D,

All files relating to lnternational cooperation

submitted through [)eputy

6l)

.'.

::

''i

'o
1.

b
File No. A-22Ollll/2024-Admin-1

(computer No' 2got5)

GeneratedfromeofficebyKUNALGUPTA'ASO-Admnl'ASo(ADMIN-1)'DADF-DEPARTMENTono4/o9l2024o4:llpm

<!-- page 8 -->

22 5858 / 2024

/ ADMTN_l _DADF

-6a

J

This issues with the approvalof Secretary, AHD

(Sanjib Bhattacharya)

Dcputy Secretary (Arlrnn.)
Tel: 0 t t-2338960(r

Distribution: -

l' Dr. Abhr3it Mitra, Animar I-Iusbandry commissioner (AHC), DAHD.

2. Ms. varsha Joshi, Additionar secretary (cattre & Dairy Deveroprnent).

3' Shri o. P. chaudhary, Joint secretary (Nationar Livestock Mission).

4. Ms Sarita Chauhan, Joint Secretary (Livestock Ilcalth).
5' Dr. suparna Sharma pachouri, Joint secrctary (coordinatio,/parr.).
6. Advisor (Statisrics).
Copy for kind information to:

l. PS to Horr'ble Minister, MFAIID.
2. Office of I{on'ble Minister of Statc (SPSB), Mf.AI-lD.
3. Office of Hon,ble Minister of State (GK), MI.-AIID.
4. Sr. PPS to Secretary, AI-ID.
5. PSO ro AS&FA.
6. PPS to CCA, DAI{D
7. Al I JCslDCs/Directors/DSs/uSs/S ections, DA I-lD.
8. Ilindi Section for providing l{indi Version.
9. NIC, DAHD fbr updating the websitc of the Department.
10. Guard File.

. i.i.,

:

-1
".,'....,

(Saniib Bhauacharyaj
Deputy Secrerary (Admn.)

Tel: 0l t-23389606

7
File No. A-2?oillt,/zoz4-Admin_t (Computer
Generated from eoffice by

No. 29ot6)

KUNAL GUPTA, ASO_Admnt,

ASO(ADM|N_I), DADF_DEPARTMEN

f on 04/Os/?Oz1 01:11 pm
