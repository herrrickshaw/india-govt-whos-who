---
doc_id: "c5fce3f692dc2e4a"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/e88e8efcd4b963d723e0ff2302dec4ce.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "The Geographical Indications of Goods (Registration and Protection) Rules, 2002"
date: "2025-06-30"
pages: 71
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0e14045704006c38"
---

<!-- page 1 -->

[Text of The Geographical Indications of Goods (Registration and Protection) Rules,
2002 published in the Gazette of India, Extraordinary,
Part II Section 3, Sub-Section (i) Extraordinary, Dated 8th March, 2002 )
MINISTRY OF COMMERCE & INDUSTRY
(DEPARTMENT OF INDUSTRIAL POLICY AND PROMOTION)

NOTIFICATION
New Delhi, the 8th March, 2002

The Geographical Indications of Goods
(Registration and Protection) Rules, 2002

G.S.R.176(E).- In the exercise of the powers conferred by sub-section 87 of
Geographical Indications of Goods(Registration & Protection)Act,1999, the Central
Government makes the following rules, namely:
PART 1
CHAPTER 1
PRELIMINARY
Short title and commencement.
1.
(1) These rules may be called the Geographical Indications Of Goods (Registration and
Protection) Rules, 2002
(2) They shall come into force on the date on which the Act comes into force.
2(1). Definitions.In these rules, unless the context otherwise requires, a)
b)
c)
d)
e)
f)
g)
h)

"Act" means The Geographical Indications Of Goods (Registration & Protection) Act, 1999.
"agent" means a person authorised under Section 76;
"application for registration of a geographical indication” includes the geographical indication
for goods contained in it;
"appropriate office of the Geographical Indications Registry" means the relevant office of the
Geographical Indications Registry as specified in rule 4;
“business” includes the trading, dealing, production exploitation, making or manufacturing, as the
case may be, of the goods to which geographical indication relates;
“class fee” means the fee prescribed under entry no.1 of the First Schedule;
"Convention Country" means a country notified as such under sub-section (1) of section 84;
"Convention Application" means an application for the registration of a geographical indication
made by virtue of Section 84;

i)
“divisional application” means a divided application made by the division of a single initial
application for registration of a geographical indication for different classes of goods;
j)
“divisional fee” means the fee so prescribed under the First Schedule;
k)
"form" means a form set forth in either the Second or the Third Schedule;

1

<!-- page 2 -->

l)

"graphical representation" means the representation of a geographical indication for goods in
paper form;
m)
"journal" means the Geographical Indications Journal;
n)
"notified date" means the date on which the rules come into force;
o)
“opposition” includes an opposition to the registration of a geographical indication or
authorised user as the case may be;
p)"principal place of business in India" means the relevant place in India as specified in rule 3;
q)
"publish" means publish in the Geographical Indications Journal;
r)
"registered geographical indications agent" means a geographical indications agent whose name is
actually on the Register of Geographical Indications Agent maintained under rule 102;
s) “renewal” means and includes renewal of a geographical indication by the registered proprietor of
geographical indication or of the authorised user of a geographical indication as the case may be;
t)
"Schedule" means a Schedule to the rules;
u)
"section" means a section of the Act;
v)
"Specification" means the designation of goods in respect of which a geographical indication is
registered or proposed to be registered;
w)
All other words and expressions used but not defined in these rules and defined in the Act shall
have the meaning assigned to them in the Act.
(2)
In these rules, except as otherwise indicated, a reference to a section is a reference to that section
in the Act, a reference to a rule is a reference to that rule in these rules, a reference to a Schedule is a
reference to that schedule to these rules and a reference to a form is a reference to that form mentioned in
the second or third schedule, as the case may be.
3.

Principal place of business in India.-"Principal place of business in India" means-

i)

where a person carries on business in the goods concerned bearing a geographical indication
a) if the business is carried on in India at only one place, that place;
b)if the business is carried on in India at more places than one, the place mentioned by him as the
principal place of business in India;
ii)
where a person is not carrying on a business of the goods concerned bearing a geographical
indication a) if he is carrying on any other business in India at only one place, that place;
b) if he is carrying on any other business in India at more places than one, the place mentioned by
him as the principal place of business in India; and
iii)
where a person does not carry on any business in India but has a place of residence in India, then
such place of residence in India.
4. Appropriate office of the Geographical Indications Registry.(I) The "appropriate office of the Geographical Indications Registry" for the purposes of making an
application for registration of a geographical indication under section 11(1) or registration as an
authorised user under section 17(1) or for giving notice of opposition under sub-section (1) of section 14 or
sub-section (3)(e) of Section 17, as the case may be or for filing an application for rectification under
section 27 or for any other proceedings under the Act and the rules shall be –
in relation to a geographical indication for which an application for registration is made on
or after the notified date, the office of the Geographical Indications Registry within whose
territorial limits i) the principal place of business in India of the applicant as disclosed in his application or, in the
case of an association of persons or producers the principal place of business in India of the applicant
whose name is first mentioned in the application, as having such place of business is situate;
ii) where neither the applicant nor any of the association of persons or producers, as the case may
be, has a principal place of business in India, the place mentioned in the address for service in India as
specified in the application is situate.

2

<!-- page 3 -->

(2)
Notwithstanding anything contained in sub-rule (1) all applications, communications, documents or
fee authorised or required by the Act or the rules to be sent, served, left or paid shall be sent or paid at or to
the Head Office of the Registry notified by the Central Government initially and subsequently at the
appropriate office as and when notified,.
5. Jurisdiction of appropriate office not altered by change in the principal place of business or
address for service.- No change in the principal place of business in India or in the address for service in
India, as the case may be, of an applicant or of any of the association of persons or producers for
registration in relation to any geographical indication for which an application for registration is made on
or after the notified date, made or effected subsequent to that date shall affect the jurisdiction of the
appropriate office of the Geographical Indications Registry.
6. Entry of the appropriate office in the Register.- Subject to sub-rule (2) of Rule 4, in respect of every
geographical indication registered after the notified date, the Registrar shall cause to be entered in the
register the appropriate office of the Geographical Indications Registry and the Registrar may, at any time,
correct any error in the entry so made.
7. Leaving of documents, etc.- Save as otherwise provided in sub-rule (2), of rule 4 all applications,
notices, statements or other documents or any fee authorised or required by the Act or the rules to be made,
served, left or sent or paid at or to the Geographical Indications Registry in relation to a geographical
indication shall be made, served, left or sent or paid to the appropriate office of Geographical Indications
Registry.
8. Documents etc. filed or left not at the appropriate office.- Subject to the provisions of rule 7, in an
exceptional case where any application, statement or other document or any fee authorised or required by
the Act or the rules is made, served, left or sent or paid, at or to an office inadvertently which is not the
appropriate office of the Geographical Indications Registry as and when such an office is notified under
this Act by the Central Government under sub-rule 2 of rule 4, the Registrar may on a written request return
such application, statement or document to the appropriate office if he is satisfied that it was a bonafide
error on the part of the applicant in such cases:
Provided the period for which such application, or statement or document is retained by the office
which is not the appropriate office shall be excluded for the purposes of computing the period of
limitation where any of such application, statement or document is required to be presented within
the prescribed period.
Provided before declining any such request the Registrar shall provide an opportunity of being
heard.
9.
Issue of notices, etc:- Subject to sub-rule (2) of rule 4 any notice or communication relating to
any application, matter or proceeding under the Act or the rules shall ordinarily be issued from the
appropriate office of the Geographical Indications Registry but may, nevertheless, be issued by the Head
of Office of any office of the Geographical Indications Registry.
10. Fees:- (1) The fees to be paid in respect of applications, oppositions, registration, renewal or any other
matters under the Act or the rules shall be those specified in the First Schedule, hereinafter referred to as
the prescribed fees.
(2) Where in respect of any matter a fee is required to be paid under the rules, the form or the
application or the request of the petition, therefor, shall be accompanied by the prescribed fee.
(3) Fees may be paid in cash or sent by money order addressed to the Registrar of Geographical
Indications or by a bank draft issued by, or by a cheque drawn on by a scheduled bank at the place where
the appropriate office of the Geographical Indications Registry is situated and if sent through posts shall be
deemed to have been paid at the time when the money order or the properly addressed bank draft or
cheque would be delivered in the ordinary course of post.
(4) Bank drafts and cheques shall be crossed and made payable to the Registrar at the appropriate
office of the Geographical Indications Registry and they shall be drawn on a scheduled bank at the place
where the appropriate office of the Geographical Indications Registry is situate.

3

<!-- page 4 -->

(5) Where a fee is payable in respect of filing of document and either the document is filed
without fee or with insufficient fee, such document shall be deemed to have not been filed for the purposes
any proceedings under the rules.
(6) Where any fee paid by a party is ordered to be returned by the Registrar under any of the
provisions of the Act or the rules the amount may be refunded by money order in which event money order
commission shall be deductible from such amount.
(7) The Registrar may after notification in the Geographical Indications Journal make available
electronic fee transfer facilities subject to such conditions as may be specified on that behalf.
11. Forms:- (1) The forms set forth in the Second and the Third Schedules shall be used in all cases to
which they are applicable and may be modified as directed by the Registrar to meet other cases.
(2) Any form, when filed at the Geographical Indications Registry shall be accompanied by the
prescribed fee.
(3) A requirement under this rule to use a form as set forth in the schedules is satisfied by the use
either of a replica of that form or of a form which is acceptable to the Registrar and contains the
information required by the form as set forth in the schedule and complies with any direction as to the use
of such a form.
(4) The Registrar may after notification in the Geographical Indications Journal specify such
forms as are required to be submitted in machine readable forms. Thereafter, such forms shall be
completed in such a manner as may be specified as to permit an automated input of the content into a
computer such as by character recognition or scanning.
12.
Size, etc of documents:- (1) Subject to any other directions that may be given by the Registrar, all
applications, notices, statements, or other documents except the geographical indication required by the
Act or the rules to be made, served, left or sent, at or to the Geographical Indications Registry shall be
typewritten, lithographed or printed in Hindi or in English in large and legible characters with deep
permanent ink upon strong paper, and except in the case of affidavits, on one side only and of size of
approximately 33 cms by 20 cms and shall have on the left hand part thereof a margin of not less than 4
centimetres.
(2) Duplicate documents including copies of geographical indications shall be filed at the
Geographical Indications Registry if at any time so required by the Registrar.
(3) The Registrar may after notification in the Geographical Indications Journal alter the size of
all applications, notices, statements or other document and forms required under the rules to make it
compatible in machine readable form.
(4) The Registrar may after notification in the Geographical Indications Journal permit the filing
of applications, statements, notices or other documents by electronic means subject to such conditions as he
may specify either generally by published notice in the Journal or in any particular case by written notice to
the persons desiring to file any such documents by such means.
13.
Signing of documents:- (1) An application for the registration of a geographical indication
purporting to be filed by an association of persons or producers shall be signed by the authorised signatory
thereof to sign such documents and a document purporting to be signed by a body corporate or any
organisation or any authority established by or under any law for the time being in force shall be signed by
the Chief Executive, or the Managing Director or the secretary or other principal officer of such
organisation. A document purporting to be signed by a partnership shall be signed by at least one of the
partners. The capacity in which an individual signs a document on behalf of an association of persons or a
body corporate shall be stated below his signature.
(2) Signatures to an application and any other documents shall be accompanied by the name of
the signatory in English or in Hindi and in capital letters.
14. Service of documents:(1)All applications, notices, statements, papers having representations
affixed thereto, or other documents authorised or required by the Act or the rules to be made, served, left
or sent, at or to the Geographical Indications Registry or with or to the Registrar or any other person may
be sent through the post by a prepaid letter.
(2) Any application or any document so sent shall be deemed to have been made, served, left or
sent at the time when the letter containing the same would be delivered in the ordinary course of post.

4

<!-- page 5 -->

(3) In proving such sending it shall be sufficient to prove that the letter was properly addressed
and put into the post.
15. Particulars of address etc. of applicants and other persons:(1) Names and addresses of the
association of persons, producers, authorised users and other persons shall be given in full, together with
their nationality, calling and such other particulars as are necessary for identification.
(2) In the case of a body corporate the full name and nationality of the Board of Directors thereof
shall be stated.
(3) In the case of foreign applicants and persons having no principal place of business in India,
their addresses in their home country shall be given in addition to their address for service in India.
(4) In the case of a body corporate or any organisation or authority established by or under any law
for the time being in force, the country of incorporation or the nature of registration, if any, as the case may
be, shall be given.
16. Statement of principal place of business in India in an application:(1) Every application for
registration of a geographical indication or as an authorised user shall state the principal place of business
in India, if any, of the applicant or the authorised user or in the case of association of persons or producers
of goods such of them as have a principal place of business in India.
(2) Subject to the provisions of rules 17, 18, and 20, any written communication addressed to an
applicant or his agent, or an authorised user or his agent or in the case of association of persons, the person
authorised to act in the matter in connection with the registration of a geographical indication or their
agent, at the address of his principal place of business in India given by him in the application shall be
deemed to be properly addressed.
17. Address for service:- (1) An address for service in India shall be given:(a)
by every applicant for registration of a geographical indication or by an authorised user
of a geographical indication who has no principal place of business in India;
(b)
in the case of an association of persons or producers for registration of a geographical
indication if none of them has a principal place of business in India;
(c)
by the applicant for a geographical indication who had his principal place of business in
India at the date of making the application for registration but has subsequently ceased to have such place,
and
(d)
by every applicant or authorised user in any proceeding under the Act or the rules and
every person filing a notice of opposition, who do not have a principal place of business is India.
(e)
by every person granted leave to intervene under Rule 67 (the intervener)
(f)
Every proprietor of a registered geographical indication which is the subject of an
application to the Registrar for the invalidation or rectification of the registered geographical indication .
(g) by every applicant for cancelling, expunging and varying any entry on the register relating to a
Geographical Indication or of an authorised user under sub-section (1) and (2) of Section 27
(2) Any written communication addressed to a person as aforesaid at an address for service in
India given by him shall be deemed to be properly addressed.
(3) Unless an address for service in India as required in sub-rule (1) is given, the Registrar shall
be under no obligation to send any notice that may be required by the Act or the rules and no subsequent
order or decision in the proceedings shall be called in question on the ground of any lack or non-service of
notice.
18.
Address for service in application and opposition proceedings:- An applicant for registration
of a geographical indication or as an authorised user or an opponent filing a notice of opposition may
notwithstanding that he has a principal place of business in India, if he so desires, may furnish to the
Registrar with an address in India to which communications in relation to the application or opposition
proceedings only may be sent. Such address of the applicant or the authorised user or the opponent shall be
deemed, unless subsequently cancelled, to be the actual address of the applicant or the authorised user or
the opponent, as the case may be, and all communications and documents in relation to the application, or
notice of opposition may be served by leaving them at, or sending them by post to such address of the
applicant or the authorised user or the opponent, as the case may be.

5

<!-- page 6 -->

19.
Non-availability of an address for service:- The Registrar may, at any time when a doubt arises
as to the continued availability of an address for service in India entered in the register, request the person
for whom it is entered by letter directed to any other address entered in the register or if no such address is
entered in the register to the address at which the Registrar considers that the letter would reach him to
confirm the address for service in India and if within two months of making such a request the Registrar
receives no such confirmation, he may strike the entry in the register of the address for service in India and
require such person to furnish a fresh address for service in India or his address at the principal place of
business in India, if he has any at that time.
20. Agency:(1) The authorisation of an agent for the purpose of Section 76 shall be executed on
Form GI-10
or in such other written form as the Registrar may deem sufficient and proper.
(2) In the case of such authorisation, service upon the agent of any document relating to the
proceeding or matter shall be deemed to be service upon the person so authorising him; all communications
directed to be made to such person in respect of the proceeding or matter may be addressed to such agent,
and all appearances before Registrar relating thereto may be made by or through such agent.
(3) In any particular case the Registrar may require the personal signature or presence of an
applicant, opponent, proprietor, authorised user or other person.
21. Classification of goods:- (1) For the purposes of the registration of a geographical indication or as an
authorised user, goods shall be classified in the manner specified in the Fourth Schedule.
(2) The goods mentioned in the Fourth Schedule only provide a means by which the general content of
numbered international classes can be quickly identified. They correspond to the major content of each
class and are not intended to be exhaustive in accordance with the International Classification of Goods.
For determining the classification of particular goods and for full disclosure of the content of international
classification, reference may be made to the alphabetical index of goods if any, published by the Registrar
under sub-section (3) of section 8 or the current edition of International Classification of Goods for the
purpose of registration of trade marks published by the World Intellectual Property Organisation or any
subsequent edition as may be available.
(3) Where goods of more than one class are set out in an application for which only one
application fee has been paid, the Registrar shall require the applicant to amend the application in order to
restrict the goods to a single class.
22. Request to Registrar for search:- (1) Any person may request the Registrar on form GI-5
to
cause a search to be made in respect of specified goods classified in any one class in the Fourth Schedule
in order to ascertain whether any geographical indication is on record which resembles a trade mark or
geographical indication of which two representations accompany the form. The Registrar shall cause a
search to be made and inform the applicant of the result of such search.
(2) If within three months from date of communication of the result of the search aforesaid an application is
made for the registration of the trade mark or geographical indication in question and the Registrar takes
objection on the ground that the mark or the geographical indication resembles a geographical indication,
which was not disclosed in the search, but was on record on the last of the date on which the search was
made the applicant shall be entitled, after withdrawal of the application for the registration of the said trade
mark or the geographical indication, to have repaid to him the fee paid for search in Form GI-5

CHAPTER II
PROCEDURE FOR REGISTRATION OF GEOGRAPHICAL INDICATIONS
23. Form and signing of application.- (1) Every application for the registration of a geographical
indication shall be made in the prescribed form and shall be signed by the applicant or his agent and must
be made in triplicate alongwith three copies of a Statement of Case.
(2) An application to register a geographical indication for a specification of goods included in
any one class shall be made in Form GI-1;

6

<!-- page 7 -->

(3) An application to register a geographical indication under section 84(1) for a specification of
goods included in any one class from a convention country shall be made in Form GI- 1;.
(4) A single application for the registration of a geographical indication for different classes of
goods from a convention country under section 84(1) shall be made in Form GI-1;
(5) A single application for the registration of a geographical indications for different classes of
goods shall be made in Form GI-1;
(6) Every application for the registration of a geographical indication for goods must satisfy the
following conditions:
a) The geographical indication must be defined with sufficient precision so that the right to obtain relief in
respect of infringement of geographical indication can be determined;
b) The graphical representation must be able to stand in place of the geographical indication without the
need for supporting samples;
c) It must be reasonably practicable for persons inspecting the Register or reading the Geographical
Indications Journals to understand from the graphical representation what the geographical indications is
d) An application for the registration of a three dimensional geographical indication shall not be acted upon
as such unless the application for registration contains a statement to that effect;
e) Where a colour combination is claimed as an element of a geographical indication in an application for
the registration, it shall not be acted upon as such unless the application contains a statement to that effect
and specifies the colours;
(7) An amendment to divide an application under proviso to section 15 shall be made in Form
GI-5;
(8) Every application shall be in respect of one geographical indications only for as many class or
classes of goods as may be made.
(9) The Registrar may require a more concise description of a geographical indications if relates to
colour combination, a three-dimensional geographical indication, design which are symbols of definite
concepts, a configuration of goods or packaging to evaluate the substantive rights in the geographical
indications.
(10) Where an applicant files a single application for one or more classes and the Registrar
determines that the goods applied for fall in class or classes in addition to those applied for, the applicant
may restrict the specification of goods to the class applied for or amend the application to add additional
class or classes on payment of the appropriate class fee and the divisional fee. The new class created
through a division retains the benefit of original filing date or in the case of an application from a
convention country, the convention application date under sub-section (1) of section 84 provided the claim
was otherwise properly asserted in the original application.
24. Application under convention arrangement.- (1) Where an application for registration of a
geographical indications is filed by an applicant from a convention country under section 84, a certificate
by the Registry or competent authority of the Geographical Indications Office of the convention country
shall be included in the application for registration under sub-rule (3) or (4) of Rule 23, as the case may be,
and it shall include the particulars of the geographical indication, the country and the date or dates of filing
of the first application in the convention country and such other particulars as may be required by the
Registrar.
(2) Unless such certificate has been filed at the time of the filing of the application for registration,
there shall be filed, within two months of the filing of the application under sub-rule (3) or (4) of rule 23, as
the case may be, certifying or verifying to the satisfaction of the Registrar the date of the filing of the
application, the country, the representation of geographical indication, the class and goods covered by the
application.
(3) The application relied under sub-rule (1) must be the applicants’ first application in a
convention country for the same geographical indications and for all or some of the goods under that
application. The application must include a statement indicating the filing date of the foreign application
relied upon, the convention country where it was filed, the serial number, if available and a statement
indicating the convention application date as claimed.
(4) Where a single application under sub section (3) of section 11 from a convention country is
received in respect of a geographical indications for one or more classes of goods, the applicant must
establish a continuous valid basis for the convention application date in all classes.

7

<!-- page 8 -->

25. Statement of user in applications.An application to register a geographical indication or as an
authorised user shall, contain a statement of the period during which, and the person by whom it has been
used in respect of the goods mentioned in the application. The applicant shall file an affidavit testifying to
such user with exhibits showing the geographical indication as used, the volume of sales under that
geographical indication , the definite territory of the country, region or locality in the country to which
geographical indication relates and such other particulars as the Registrar on perusal of the application
may call for from the applicants.
26. Representation of Geographical Indication .- Every application for the registration of a geographical
indication and where additional copies of the application are required every such copy, shall contain a
representation of the geographical indication in the space provided on the application form for that
purpose provided the size of such representation shall not exceed 33 centimetres by 20 centimetres with a
margin of 4 cm. on the left hand side.
27. Additional representations.- (1) Every application for the registration of a geographical indication
shall, except as hereinafter provided, be made in triplicate and shall be accompanied by five additional
representations of the geographical indication . The representations of the geographical indication on the
application and each of its copies and the additional representations shall correspond exactly with one
another. The additional representations shall in all cases be noted with the specification and class of goods
for which registration is sought, the name and address of the applicant, together with the name and address
of his agent, if any, the period of use, and such other particulars as required under sub-rule 1 to rule 32 by
the Registrar and shall be signed by the applicant or his agent.
(2) Where an application contains a statement to the effect that the applicant wishes to claim
combination of colours as a distinctive feature of the geographical indication , the application shall be
accompanied with three reproduction of the geographical indication in black and white and five
reproduction of the geographical indication in colour.
.
(3)
(i) Where an application for the registration of a geographical indication consist of
shape of goods or its packaging, the reproduction furnished shall consist of at least three different view of
the geographical indication and a description by word of the geographical indication .
(ii) If the Registrar considers the different views and description of the geographical
indication in sub-para (i) still does not sufficiently show the particulars of the shape of goods or its
packaging he may call upon the applicant to furnish a specimen of the goods or packaging, as the case may
be, as sold in respect of the geographical indication .
28. Representations to be durable and satisfactory.-(1)All representations in respect of a geographical
indication shall be of a durable nature, and each additional representation required to be filed with an
application for registration shall be mounted on a sheet of strong paper of the size of approx. 33 cm by 20
cm leaving a margin of not less than 4 centimetres on the left hand part of the sheet.
(2) If the Registrar is not satisfied with any representation of a geographical indication he may at
any time require another representation satisfactory to him to be substituted before proceedings with the
application.
29. Transliteration and translation.-(1) Where a geographical indication contains a word or words in
characters other than Devnagari or Roman, there shall be endorsed on the application form and the
additional representation thereof, a sufficient transliteration and translation to the satisfaction of the
Registrar of each of such words, and every such endorsement shall state the language to which the word
belongs and shall be signed by the applicant or his agent failing which the Registrar shall be under no
obligation to take any action on the application.
(2) Where an application for a geographical indication or authorised user contains a word or words
in a language other than Hindi or English, the Registrar may ask for an exact translation thereof together
with the name of the language, and such translation and name, if he so requires, shall be endorsed and
signed as aforesaid.

8

<!-- page 9 -->

30. Name or description of goods on a Geographical Indication .-Where the name or description of any
goods appears on a geographical indication, the Registrar may refuse to register such geographical
indication .
31. Deficiencies.- Subject to sub-rule (2) of rule 10, where an application for registration of a geographical
indication does not satisfy requirements under section 11 or rule 23, the Registrar shall send notice
thereof to the Applicants to remedy the deficiencies and if within one month from the date of receipt of the
notice, the applicants fails to remedy any deficiency so notified by him the application may be treated as
abandoned.
PROCEDURE ON RECEIPT
GEOGRAPHICAL INDICATION

OF

APPLICATION

FOR

REGISTRATION

OF

A

32(1). Content of application: Every application for the registration of a geographical indication shall be
made in the prescribed forms and shall contain the following:
(1)

(2)
(3)
(4)
(5)

(6)

a statement as to how the geographical indication serves to designate the goods as
originating from the concerned territory of the country or region or locality in the
country, as the case may be, in respect of specific quality, reputation or other
characteristics which are due exclusively or essentially to the geographical
environment, with its inherent natural and human factors, and the production,
processing or preparation of which takes place in such territory, region or locality as
the case may be ;
the class of goods to which the geographical indication relates shall apply;
the geographical map of the territory of the country or region or locality in the
country in which the goods are produced of originate or are being manufactured;
the particulars regarding the appearance of the geographical indication as to whether
it is comprised of the words or figurative elements or both;
A statement containing such particulars of the producers of the concerned goods
proposed to be initially registered. The statement may contain such other particulars
of the producers mentioned in Section 11(2)(f) including a collective reference to all
the producers of the goods in respect of which the application is made.
the statement contained in the application shall also include the following:
a). an affidavit as to how the applicant claim to represent the interest of the
association of persons or producers or any organization or authority established by
or under any law ;
b). The standards benchmark for the use of the geographical indication or the
industry standard as regards the production, exploitation, making or
manufacture of the goods having specific quality, reputation, or other
characteristic of such goods that is essentially attributable to its geographical
origin with the detailed description of the human creativity involved, if any
or
other characteristic from the definite territory of the country, region or
locality in the
country, as the case may be;
c). the particulars of the mechanism to ensure that the standards, quality, integrity
and consistency or other special characteristic in respect of the goods to which the
geographical indication relates which are maintained by the producers, maker or
manufacturers of the goods, as the case may be;
d) three certified copies of the map of the territory, region or locality showing the
title, name of publisher and date of issue along with the application;
(e) the particulars of special human skill involved or the uniqueness of the
geographical environment or other inherent characteristics associated with the
geographical indication to which the application relates;
f) the full name and address of the association of persons or organisation or
authority representing the interest of the producers of the concerned goods;
g)particulars of the inspection structure, if any, to regulate the use of the

9

<!-- page 10 -->

geographical indication in respect of the goods for which application is made in the
definite territory region or locality mentioned in the application;
(h)where the geographical indication is a homonymous indication to an already
registered geographical indication, the material factors differentiating the application
from the registered geographical indications and particulars of protective measures
adopted by the applicant to ensure consumers of such goods are not confused or
mislead or confused in consequence of such registration;
(2). Acknowledgement of receipt of applications.- Every application for the registration of a
geographical indication in respect of any goods shall, on receipt , be acknowledged by the Registrar. The
acknowledgement shall be by way of return of one of the additional representations of the geographical
indication filed by the applicant along with his application with the official number of the application duly
entered thereon.
33. Examination of application.-Upon receipt of an application, the Registrar shall examine the
application and the accompanying Statement of Case as required under rule 32(1) as to whether it meets the
requirements of the Act and the Rules and for this purpose, he shall ordinarily constitute a Consultative
Group of not more than seven representatives chaired by him from organization or authority or persons
well versed in the varied intricacies of this law or field to ascertain the correctness of the particulars
furnished in the Statement of Case referred to in rule 32(1) which shall ordinarily be finalised within three
months from the date of constitution of the Consultative Group. Thereupon, the Registrar shall issue a
Examination Report on the application to the applicant.
34.(1) Objection to acceptance-Hearing.-If, on consideration of the application on merits and of any
evidence of use or of a given quality, reputation or other characteristic of such goods that are essentially
attributable to its geographical origin or of any other matter relevant which the applicant may be required to
furnish, the Registrar has any objection to the acceptance of the application or proposes to accept it subject
to such conditions, amendments, modifications or limitations as he may think right to impose, the Registrar
shall communicate such objection or proposal in writing to the applicant.
(2) If within two months from the date of communication mentioned in sub-rule (1), the
applicant does not amend his application according to the proposal aforesaid, or submit his observations to
the Registrar or apply for a hearing or fails to attend the hearing, as the case may be, the application shall
be dismissed.
35. Decision of Registrar.(1) The decision of the Registrar under rule 34 or rule 37 after a
hearing or without a hearing if the applicant has duly communicated his observations in writing and has
stated that he does not desire to be heard, shall be communicated to the applicant in writing and if the
applicant intends to appeal from such decision he may within one month from the date of receipt of such
communication request the Registrar to state in writing the grounds of, and the materials used by him in
arriving at his decision.
(2) In a case where the Registrar makes any requirements to which the applicant does not object
the applicant shall comply therewith before the Registrar issues a statement in writing under sub-rule (1).
(3) The date when the statement in writing under sub-rule (1) is sent shall be deemed to be the date
of the Registrar's decision for the purpose of appeal.
36. Correction and amendment of application.-An applicant for registration of a geographical
indication may, whether before or after acceptance of his application but before the registration of the
geographical indication, apply on Form GI-5
accompanied by the prescribed fee for the correction of
any error in or in connection with his application or any amendment of his application provided such
proposed amendment does not relates to amendment of the geographical indication or amendment in the
description of goods or to the definite, territory, region or locality, as the case may be, that would have the
effect of substantially altering or substituting the original application.
37. Withdrawal of acceptance by the Registrar.- (1) If, after the acceptance of an application but before
the registration of the geographical indication , the Registrar has any objection to the acceptance of the
application on the ground that it was accepted in error, or that the geographical indication ought not to

10

<!-- page 11 -->

have been accepted in the circumstances of the case, or proposes that the geographical indication should
be registered only subject to conditions or limitations, or to conditions additional to or different from the
conditions or limitations subject to which the application has been accepted, the Registrar shall
communicate such objection in writing to the applicant.
(2) Unless within thirty days from the date of the communication mentioned in sub-rule (1) the
applicant amends his application to comply with the requirements of the Registrar or applies for a hearing ,
the acceptance of the application shall be deemed to be withdrawn by the Registrar, and the application
shall proceed as if it had not been accepted.
(3) Where the applicant intimates the Registrar within the period mentioned in sub-rule (2) that he
desires to be heard, the Registrar shall give notice to the applicant of a date when he will hear him. Such
appointment shall be for a date at least 15 days after the date of the notice, unless the applicant consents to
a shorter notice. The applicant may state that he does not desire to be heard and submit such submissions
as he may consider desirable.
(4) The Registrar may, after hearing the applicant and on considering the submissions, if any, of
the applicant pass such orders as he may deem fit.

ADVERTISEMENT OF APPLICATION
38. Manner of Advertisement.- (1) An application for the registration of a geographical indication
required or permitted to be advertised by sub-section (1) of section 13 or to be re-advertised by sub-clause
(2) of that section shall be ordinarily advertised in the Journal within three months of the acceptance of an
application for advertisement.
(2) The Registrar may after notification in the Journal put the published Geographical Indications
Journal on the internet, website or any other electronic media.
(3) The Registrar may after notification in the Journal make available the Geographical
Indications Journal in CD-ROM on payment of the cost thereof.
39.
Notification of correction or amendment of application.- In the case of an application to which
Para (b) of sub-section (2) of section 13 applies, the Registrar may if he so decides, instead of causing the
application to be advertised again, insert in the Journal a notification setting out the number of the
application, the class in which it was made, the name and address of the principal place of business in
India, if any, of the applicant or where the applicant has no principal place of business in India his address
for service in India, the number of the Journal in which it was advertised and the correction or amendment
made in the application.
40.
Request to Registrar for particulars of advertisement of a Geographical Indication .-Any
person may request the Registrar on Form GI-7
to be informed of the number, date and page of the
Journal in which a geographical indication specified in the form was advertised and the Registrar shall
furnish such particulars to the person making the request.

OPPOSITION TO REGISTRATION
41 (1). Notice of Opposition.-A notice of opposition to the registration of a geographical indication
under sub-section (1) of section 14 or an authorised user under section 17(3)(e) shall be given in triplicate
on Form GI-2
within three months or within such further period not exceeding one month in the
aggregate from the date when such Journal was made available to the public (which date shall be certified
as such by the Registrar) as the case may be, of the application for registration in the Journal. The notice
shall include a statement of the grounds upon which the opponents objects to the registration of the
geographical indication or of the authorised user, as the case may be.

11

<!-- page 12 -->

(2) Where a Notice of Opposition is filed in respect of single application for the registration of a
geographical indication it shall bear the fee in respect of each class
in relation to which the opposition
is filed.
(3) Where an opposition is filed only for a particular class or classes in respect of a single
application made under sub-section (3) of section 11, the application shall not proceed to
registration until a request in Form GI-5
for division of the application together with the
divisional fee is made by the applicant.
(4) Where in respect of a single application for the registration of a geographical indication no
notice of opposition is filed in any class or classes, the application in respect of such class or
classes shall proceed to registration after the division of the application in the class or classes
in respect of which an opposition is pending.
(5) An application for an extension of the period within which a notice of opposition to the
registration of a geographical indication or an authorised user may be given under subsection(1) of section 14, shall be made on Form GI-2 accompanied by the prescribed fee
before the expiry of the period of three months under sub-section (1) of section 14.
(6) A copy of notice of opposition shall be ordinarily served by the Registrar to the applicants
within two months of the receipt of the same by the appropriate office.
42.

Verification of Notice of Opposition
(1)
(2)

The notice of opposition shall be verified by the opponent.
The verification shall specifically state by reference to the numbered paragraphs of the notice of
opposition, what is verified of his own knowledge and what is verified upon information
received and believed to be true.
(3) The verification shall be signed by the person making it and shall state the date and the place at
which it was signed.
43. Counterstatement.- (1) The counter-statement required by sub-section (2) of section 14 shall be sent
in triplicate on Form GI-2
within two months from the receipt by the applicant of the copy of the
notice of opposition from the Registrar and shall set out what facts, if any, alleged in the notice of
opposition, are admitted by the applicant. A copy of the counter-statement shall be served by the Registrar
on the person giving notice of opposition ordinarily within two month from the date of receipt of the same.
(2) The counterstatement shall be verified in the same manner as the notice of opposition as stated
in rule 42.
44. Evidence in support of opposition by the opponents.- (1) Within two months from services on
him of a copy of the counterstatement or within such further period not exceeding one month in the
aggregate thereafter as the Registrar may on request allow, the opponent shall either leave with the
Registrar such evidence by way of affidavit as he may desire to adduce in support of his opposition or shall
intimate to the Registrar and to the applicant in writing that he does not desire to adduce evidence in
support of his opposition but intends to rely on the facts stated in the notice of opposition. He shall deliver
to the applicant copies of any evidence that he leaves with the Registrar under this sub-rule and intimate
the Registrar forthwith in writing of such delivery.
(2) If an opponent takes no action under sub-rule (1) within the time mentioned therein, he shall,
be deemed to have abandoned his opposition.
(3)An application for the extension of the period of one month mentioned in sub-rule (1) shall be
made in Form GI-9
accompanied by prescribed fees before the expiry of the period of two months
mentioned therein.
45. Evidence in support of application by the applicant.-(1) Within two months or within such further
period not exceeding one months thereafter in the aggregate as the Registrar may on request allow, on the
receipt by the applicant of the copies of affidavits in support of opposition or of the intimation that the
opponent does not desire to adduce any evidence in support of his opposition, the applicant shall leave with
the Registrar such evidence by way of affidavit as he desires to adduce in support of his application and
shall deliver to the opponent copies thereof or shall intimate to the Registrar and the opponent that he does
not desire to adduce any evidence but intends to rely on the facts stated in the counterstatement and or on

12

<!-- page 13 -->

the evidence already left by him in connection with the application in question. In case the applicant relies
on any evidence already left by him in connection with the application, he shall deliver to the opponent
copies thereof.
(2)An application for the extension of the period of one month mentioned in sub-rule (1) shall be made in
Form GI-9
accompanied by prescribed fees before the expiry of the period of two months mentioned
therein.
46. Evidence in reply by opponent.- Within one month from the receipt by the opponent of the copies of
the applicant's affidavit or within such further period not exceeding one month in the aggregate thereafter
as the Registrar may on request on Form-GI 9 accompanied by the prescribed fee allow, the opponent may
leave with the Registrar evidence by affidavit in reply and shall deliver to the applicant copies thereof.
This evidence shall be confined to matters strictly in reply.
47. Further evidence.- No further evidence shall be left on either side, but in any proceedings before
the Registrar, he may at any time, if he thinks fit, give leave to either the applicant or the opponent to leave
any evidence upon such terms as to costs or otherwise as he may think fit.
48. Exhibits.Where there are exhibits to affidavits filed in an opposition, a copy of the exhibit or
impression of each exhibit shall be sent to the other party on his request and at his expense, or, if such
copies or impression cannot conveniently be furnished, the original shall be left at the Registry in order
that they may be open to inspection. The original exhibits shall be produced at the hearing unless the
Registrar otherwise directs.
49. Translation of documents. - Where a document in a language other than Hindi or English is referred
to in the notice of opposition or any other proceedings before the Registrar, counter-statement or an
affidavit filed in an opposition, an attested translation thereof in English or Hindi shall be furnished in
duplicate.
50. Hearing and decision.-(1) Upon completion of the evidence (if any), the Registrar shall give notice to
the parties of a date when he will hear the arguments in the case. Such notice shall be ordinarily given
within three months of completion of the evidence. The date of hearing shall be for a date at least one
month after the date of the first notice, unless the parties consent to a shorter notice. Within fourteen days
from the receipt of the first notice, any party who intends to appear shall so notify the Registrar. Any party
who does not so notify the Registrar within the time last aforesaid shall be treated as not desiring to be
heard and the Registrar shall proceed ex-parte in the matter.
(2) If sufficient cause is shown, not more than two request for adjournment for one month each by
either the opponent or the applicant to the proceeding may be considered by the Registrar on a request in
Form GI-9 accompanied with the grounds for such request.
(3) If the applicant is not present at the adjourned date of hearing and has not notified his
intention to appear at the hearing , the Registrar may treat the application as dismissed.
(4) If the opponent is not present at the adjourned date of hearing and has not notified his intention
to appear at the hearing, the Registrar may treat the opposition as dismissed for want of prosecution and the
application may proceed to registration.
(5) In every case of adjournment the Registrar shall fix a day for further hearing of the case and
shall make such order as to cost occasioned by the adjournment or such higher costs as the Registrar deems
fit.
(6) The fact that the agent or advocate on record of a party is engaged in another court, shall not be
a ground for adjournment.
(7) Where illness of an advocate on record or agent or his inability to conduct the case for any
reason is put forward as a ground for adjournment, the Tribunal shall not grant the adjournment unless it is
satisfied that the advocate on record or agent, as the case may be, could not have engaged another agent or
advocate in time.
(8) The Registrar shall take on record written arguments if submitted by a party to the proceeding.
(9) The Registrar shall have powers to limit time for oral arguments.
(10) The decision of the Registrar shall be notified to the parties in writing.

13

<!-- page 14 -->

51. Security for costs.-The security for costs which the Registrar may require under sub-section (6) of
section 14 may be fixed at any amount which he may consider proper, and such amount may be further
enhanced by him at any stage in the opposition or other proceedings.
NOTICE OF NON-COMPLETION OF REGISTRATION
52. Procedure for giving notice.- The notice which the Registrar is required by sub-section(3) of section
16 to give to an applicant, shall be sent on Form –O1 to the applicant at the address of his principal place
of business in India or if he has no principal place of business in India at the address for service in India as
stated in the application but if the applicant has authorised an agent for the purpose of the application, the
notice shall be sent to the agent and a duplicate thereof to the applicant. The notice shall specify twenty
one days time from the date thereof or such further time as the Registrar may allow on a request made in
the prescribed Form GI-9 for completion of the registration.
REGISTRATION
53. Entry in the Register.-(1) Where no Notice of Opposition is filed to an application for the registration
of a geographical indication advertised or re-advertised in the Journal within the period specified in subsection (1) of section 14 or where an opposition is filed and it is dismissed and the appeal period is over,
the Registrar shall, subject to the provisions of sub-section (1) of section 16 enter the geographical
indication in Part A of the register on receipt of a request.
(2) The entry of a geographical indication in the register shall specify the date of filing of
application, the actual date of the registration, the goods and the class in respect of which it is registered,
and all particulars required by sub-section (1) of section 6 including (a) the name and description of the applicant, the address of the principal place of business in
India, if any, of the proprietor of the geographical indication or in the case of an association of persons of
such of the association of persons as have a principal place of business in India.
(b) where the proprietor of the geographical indication has no place of business in India his
address for service in India as entered in the application for registration together with his address in his
home country.
(c) in the case of an association of persons or producers, where none of the association of persons
or producers has a principal place of business in India, the address for service in India as given in the
application together with the address of each of the association of persons or producers in his home
country.
(d) particulars of the trade, business, profession, occupation or other description of the proprietor
or of the association of persons or producers of the geographical indication as entered in the application
for registration;
(e) particulars affecting the scope of the registration or the rights conferred by the registration;
(f)The priority date ,if any, to be accorded pursuant to claim to a right of a convention application
made under section 84;
(g) A summary of the particulars furnished under rule 32 as finally accepted by the Registrar; and;
(h)the appropriate office of the Geographical Indications Registry in relation to the Geographical
Indication.
54. Death of applicant before registration.In case of death of any applicant for the registration
of a geographical indication after the date of his application and before the geographical indication has
been entered in the register, the Registrar may, on proof of the applicant's death and on proof of the
transmission of the interest of the deceased person, substitute in the application his successor in interest in
place of the name of such deceased applicant and the application may proceed thereafter as so amended.
55.
Certificate of registration.- (1) The certificate of registration of a geographical indication or an
authorised user to be issued by the Registrar under sub-section (2) of section 16 shall be on Form-O2,

14

<!-- page 15 -->

with such modification as the circumstances of a case may require, and the Registrar shall annex a copy of
the geographical indication or authorised user to the certificate.
(2) The Registrar may issue a duplicate or further copies of the certificate of registration of a
geographical indication on request by the registered proprietor on Form GI-7
accompanied by the
prescribed fee. An unmounted representation of the geographical indication exactly as shown in the form
of application for registration thereof at the time of registration shall accompany such request.
(3) The certificate of registration referred to in sub-rule (1) shall not be used in legal proceedings
or for obtaining registration abroad.
CHAPTER III
AUTHORISED USER
56. Authorised User. –(1) An application to the Registrar for the registration under Section 17 by a
producer as an authorised user of the registered geographical indication shall be made jointly by the
registered proprietor and the proposed authorised user in Form GI-3 and shall be accompanied by a
Statement of Case of how he claims to be the producer of the registered geographical indication along
with an affidavit.
(2). A copy of the letter of consent from the registered proprietor of the geographical indication may
accompany the application and where such consent letter is not furnished, a copy of the application shall be
endorsed to the registered proprietor for information and the Registrar shall be intimated of due service by
the proposed authorised user.
57.
Upon receipt of an application for the registration as an authorised user in respect of a registered
geographical indication, the Registrar shall cause it to be examined and shall issue a report.
58.
Thereupon, the provision of Rule 34 to 52, and 54 and 55 shall apply mutatis mutandis to further
proceedings in respect of an application for the registration of an authorised user of a registered
geographical indication.
59. Registration of an authorised user entry in the Register.- (1) Where no notice of opposition is filed
to an application advertised or re-advertised in the Journal within the period specified under sub-clause (e)
of sub-section (3) of Section 17 or where an opposition is filed and it is dismissed and the appeal period is
over, the Registrar shall enter the authorised user in Part B of the register on receipt of a request for
issuance of the registration certificate in Form GI-3
together with the prescribed fee.
(2) The entry of an authorised user in the register shall specify the date of filing of application for
registration as an authorised user, the actual date of the registration, the goods and class or classes in
respect of which it is registered, and all particulars required by sub-section (1) of section 6 including:(a)The address of the principal place of business in India, if any, of the registered proprietor of the
geographical indication ,
(b)Particulars of the geographical indication registered including the specification of goods and
the class in which it is registered.
(c)The address of the principal place of business in India, if any, of the authorised user.
(d)Where the authorised user of a registered geographical indication has no place of business in
India his address for service in India as entered in the application for registration together with his
address in his home country.
(e)Particulars of the trade, business, profession, occupation, dealership or other description of the
authorised user of the geographical indication as entered in the application for registration.
(f)The priority date, if any, to be accorded pursuant to a convention application made under
section 84 and;
(g)The appropriate office of Geographical Indications Registry in relation to the geographical
indication .
(3) The Registrar may issue a duplicate or further copies of the certificate of registration as an authorised
user on a request in Form GI-7 accompanied by prescribed fee. An unmounted representation of the of

15

<!-- page 16 -->

the geographical indication exactly as shown in the form of application for registration thereof at the time
of registration shall accompany such request.
CHAPTER IV
RENEWAL OF REGISTRATION AND RESTORATION
60. Renewal of registration.- (1) An application for the renewal of the registration of a geographical
Indication or an authorised user of a registered geographical indication shall be made on Form GI-4 or
Form GI-3
as the case may be and may be made at any time not more than six months before the
expiration of the last registration of the Geographical Indication or the authorised user.
(2) Such application for renewal must be filed by the person who is the proprietor of the
registered geographical indication failing which by any of the authorised users on record, as the case may
be.
(3) If the proprietor, as set forth in the application for renewal is not the same person or the same
legal entity as the registrant shown in the registration, continuity of title from the registrant to the present
owner must be shown in the first instance.
(4) The Registrar may accept an application for renewal from the managing trustee, executors,
administrators and the like, when supported by court order or other evidence of such persons authority to
act on behalf of the present proprietor.
(5) For the removal of doubt, it is clarified that where the registered proprietor of the geographical
indication has ceased to exist, the renewal of the registered geographical indication shall be
effected by any of the authorised users of the registered geographical indication acting collectively
whose name has been entered in Part B of the register on the due date of renewal.
(6)
Before issuing a renewal certificate, the Registrar may call upon the registered proprietor
to file an affidavit concerning the use of the registered geographical indication in India where he has
reasons to believe that the registered geographical indication may not be in use in the market.
61. Notice before removal of Geographical Indication or authorised user from register.-(1) At a date
not less than one month and not more than three months before the expiration of the last registration of a
geographical indication or authorised user, as the case may be, if no application on Form GI-4 or Form
GI-3 as the case may be, for renewal of the registration of a geographical indication or of an authorised
user together with the prescribed fee has been received, the Registrar shall notify the registered proprietor
or the authorised user, as the case may be, or in the case of an association of persons or producers of a
registered geographical indication each of the association of persons, producers registered as registered
proprietors or the person authorised to act on their behalf, if any, in writing on Form O3 or O5, as the case
may be, of the approaching expiration at the address of their respective principal places of business in India
as entered in the register or where such registered proprietor or authorised user has no principal place of
business in India at his address for service in India entered in the Register.
(2) Where, in the case of a geographical indication or authorised user the registration of which (by
reference to the date of application for registration) becomes due for renewal, the geographical indication
or authorised user is registered at any time within six months before the date on which renewal is due, the
registration may be renewed by the payment of the renewal fee within six months after the actual date of
registration and where the renewal fee is not paid within that period the Registrar shall subject to rule 63,
remove the geographical indication or authorised user from the register.
(3) Where, in the case of a geographical indication or authorised user the registration of which (by
reference to the date of application for registration) becomes due for renewal, the geographical indication
or authorised user is registered after the date of renewal, the registration may be renewed by the payment of
the renewal fee within six months of the actual date of registration and where the renewal fee is not paid
within that period the Registrar shall, subject to rule 63, remove the geographical indication or authorised
user from the register.
62. Advertisement of removal of geographical indication or the authorised user from the register.-If
at the expiration of last registration of a geographical indication or an authorised user, the renewal fees has
not been paid, the Registrar may remove the geographical indication or the authorised user, as the case
may be, from the register and advertise the fact forthwith in the Journal.

16

<!-- page 17 -->

Provided the Registrar shall not remove the geographical indication or the authorised
user from the Register if an application is made in Form GI-4 within six months from
the expiration of the last registration of the geographical indication or the authorised user
accompanied by prescribed fees and appropriate surcharge.
63. Restoration and renewal of registration.An application for the restoration of a geographical
indication or authorised user to the register and renewal of its registration under sub-section (5) of section
18, shall be made in Form GI-4
after six months and within one year from the expiration of the last
registration of the geographical indication or the authorised user as the case may be, accompanied by the
prescribed fee. The Registrar shall, while considering the request for registration, have regard to the
interest of the persons who have either applied or registered identical or deceptively similar geographical
indication or other affected persons in the intervening period.
64. Notice and advertisement of renewal and restoration.-Upon the renewal or restoration and renewal
of registration, a notice to that effect shall be sent to the registered proprietor or the concerned authorised
user and the said renewal or restoration and renewal shall be advertised in the Journal.
CHAPTER V
RECTIFICATION AND CORRECTION OF REGISTER
ALTERATION OR RECTIFICATION OF REGISTER
65. Application to rectify or remove a geographical indication from the register.- An application to
the Registrar under Section 27 for the cancelling, expunging or varying of any entry relating to a
geographical indication or of the Statement of Case referred to under rule 32(1) recorded in the Register
of Geographical Indication or an authorised user in the register shall be made in triplicate on Form GI-6
or Form GI-5 , as the case may be, shall be accompanied by a statement in triplicate setting out fully the
nature of the applicant's interest, the facts upon which he bases his case and the relief which he seeks.
Where the application is made by a person who is not the registered proprietor of the geographical
indication in question, the application and the statement aforesaid shall be left at the Geographical
Indications Registry in triplicate. In case there are authorised users, such application and statements shall
be accompanied by as many copies thereof as there are authorised users on the register or alternatively
furnish proof of publication in leading national newspapers circulated widely in the definite territory,
region or locality to which the geographical indication relates notifying to the general public of proposed
application for rectification or removal with full particulars thereof. A copy each of the application and
statement shall be transmitted within two months by the Registrar to the registered proprietor and to any
other person who appears from the register to have an interest in the geographical indication or makes a
request for the same. The application shall be verified in the manner prescribed under Rule 42 for
verification of notice of opposition.
66. Further procedure.-Within two months or within such further period not exceeding two months in the
aggregate from the receipt by a registered proprietor of the copy of the application mentioned in rule 65
from the Registrar, he shall send to the Registrar and to the person making the application on Form GI-2
a counterstatement in triplicate of the grounds on which the application is contested. The Registrar shall
serve a copy of the counterstatement on the person making the application within one month of the receipt
of the same. The provisions of rules 44 to 51 shall thereafter apply mutatis mutandis to the further
proceedings on the application. The Registrar shall not, however, rectify the register or remove the
geographical indication or any authorised user from the register merely because the registered proprietor
or the authorised user has not filed a counterstatement unless he is satisfied that the delay in filing the
counterstatement is wilful and is not justified by the circumstance of the case. In any case of doubt any
party may apply to the Registrar for directions.
67. Intervention by third parties. - Any person alleging interest in a registered geographical indication
in respect of which an application is made under rule 65 may apply on Form GI-6 for leave to intervene,
stating the nature of his interest, and the Registrar may refuse or grant such leave after hearing if so

17

<!-- page 18 -->

required the parties concerned, upon such terms and conditions including undertakings or conditions as to
security for cost as he may deem fit to impose.
68.
Rectification of the register by the Registrar of his own motion.- (1) The notice, which the
Registrar is required be give under sub-section (4) of section 27 shall be sent in writing to the registered
proprietor and to any other person who appears from the register to have any interest in the registered
geographical indication , and shall state the grounds on which the Registrar proposes to rectify the register
and shall also specify the time, not being less than one month from the date of such notice, within which an
application for a hearing shall be made.
(2) Unless within the time specified in the notice aforesaid, any person so notified sends to the
Registrar a statement in writing setting out fully the facts upon which he relies to meet the grounds stated in
the notice or applies for a hearing, he may be treated as not desiring to take part in the proceedings and the
Registrar may act accordingly.
(3) If the Registrar decides to rectify the register he shall communicate his decision in writing.
ALTERATION OF ADDRESS
69.
Alteration of address in register.- (1) A registered proprietor or an authorised user of a
geographical indication the address of whose principal place of business in India or whose address in his
home country, as the case may be, is changed so that the entry in the register is rendered incorrect shall
forthwith request the Registrar on Form GI-5
to make the appropriate alteration of the address in the
register, and the Registrar shall alter the register accordingly if he is satisfied in the matter.
(2) A registered proprietor or an authorised user of a geographical indication , whose address for
service in India entered in the register is changed, whether by discontinuance of the entered address or
otherwise, so that the entry in the register is rendered incorrect, shall forthwith request the Registrar on
Form GI -5
to make the appropriate alteration of the address in the Register, and the Registrar shall
alter the register accordingly if he is satisfied in the matter.
(3) A registered proprietor or an authorised user of a geographical indication the address of
whose principal place of business in India or whose address for service in India is altered by a public
authority, so that the changed address designates the same premises as entered in the register, may make
the aforesaid request to the Registrar on Form GI-5
and if he does so he shall leave therewith a
certificate of the alteration given by the said authority. If the Registrar is satisfied as to the facts of the
case, he shall alter the register accordingly but shall not require any fees to be paid on the forms,
notwithstanding the provisions of sub-rule (2) of rule 10 or sub-rule (2) of rule 11.
(4) (i) Where a registered proprietor makes a request under sub-rule (1), (2) or (3), he shall serve a
copy of the request on the authorised user or users, if any, and inform the Registrar accordingly.
(ii) where the request aforesaid is made by an authorised user, he shall serve a copy thereof on the
registered proprietor and other authorised users, if any or alternatively issue a public notice in at least two
leading local newspapers circulated widely in the definite territory, region or locality to which geographical
indication relates or issue a public notice in at least two leading local newspapers and inform the Registrar
that he had done so.
(5) In case of the alteration of the address of a person entered in the register as the address for
service in India of more than one registered proprietor or authorised users of Geographical Indications, the
Registrar may, on proof that the said address is the address of the applicant and if satisfied that it is just to
do so, accept an application from that person on Form GI-5
amended so as to suit the case, for the
appropriate alteration of the entries of his address as the address for service in the several registrations,
particulars of which shall be given in the form and may alter the entries accordingly.
(6) All applications under this rule shall be signed by the registered proprietor or the authorised
user, as the case may be, or by an agent expressly authorised by him for the purpose of such an application,
unless in exceptional circumstances the Registrar otherwise allows.
CORRECTION OF REGISTER
70.Application under Section 28.-Where an application has been made under Sub-section (1) of section
28 for the alteration of the register by correction, change, cancellation or striking out of goods or for the

18

<!-- page 19 -->

entry of a memorandum in the register, the Registrar may require the applicant to furnish such evidence
by affidavit or otherwise as the Registrar may think fit, as to the circumstances in which the application is
made. Such application shall be made on Form GI-5 as may be appropriate and a copy thereof shall be
served by the applicant on the authorised user or users, if any or issue a public notice in at least two leading
local newspapers under the registration of the geographical indication in question and to any other person
who appears from the register to have an interest in the geographical indication and inform the Registrar
he has done so.
71. Alteration of registered Geographical Indication .- Where the registered proprietor of a
geographical indication applies under section 29 for leave to add to or alter the registered geographical
indication , he shall make the application in writing on Form GI-9 and shall furnish five copies of the
geographical indication as it will appear when so added to or altered. A copy of the application and of the
geographical indication so amended or altered shall be served by the applicant on every authorised users
on the record or issue a public notice in at least two leading local newspapers and inform the Registrar he
has done so.
72.
Advertisement before decision and opposition etc .-(1)The Registrar shall consider the
application and shall, advertise the application in the Journal before deciding it.
(2) Within three months from the date of advertisement under sub-rule (1), or within such period
not exceeding one month in the aggregate any person may give notice of opposition to the application on
Form GI-2
and may also send therewith a statement of his objections. The notice and the statement, if
any, shall be sent in triplicate. In case there are any authorised users under the registration of the
geographical indication in question, such notice and statement may also be accompanied by as many
copies thereof as there are authorised users. A copy each of the notice and statement shall be transmitted
by the person giving notice to registered proprietor and authorised user if any or alternatively issue a public
notice in al least two leading local newspapers circulated widely in the definite territory, region or locality
to which the geographical indication relates. The Registrar shall forward within two months a copy of the
notice and statement to the registered proprietor and within two months from the receipt by the registered
proprietor of such copies from the Registrar, he shall send to the Registrar on Form GI-2 a counterstatement in triplicate of the grounds on which the opposition is contested. If the registered proprietor
sends such a counter-statement the Registrar shall serve a copy thereof on the person giving notice of
opposition within one month and the provisions of rules 44 to 51 shall thereafter apply mutatis mutandis to
the further proceedings on the opposition. The Registrar shall not refuse the application merely because the
registered proprietor has not filed a counterstatement unless he is satisfied that the delay in filing the
counterstatement is wilful and is not justified by the circumstance of the case . In any case of doubt any
party may apply to the Registrar for directions.
(3) If there is no opposition, within the time specified in sub-rule(2), the Registrar shall, after
hearing the applicant if he so desires allow or refuse the application and shall communicate his decision in
writing to the applicant.
73. Decision - Advertisement – Notification.-If the Registrar decides to allow the application he shall alter
the geographical indication in the register accordingly and insert in the Journal a notification that the
geographical indication has been altered. If the application has not been advertised under rule 71, he shall
also advertise in the Journal the geographical indications as altered.
CHAPTER VI
Special Provisions relating to Trade Marks
74(1). Refusal or Invalidation of Registration of Trade Marks.- Where the Registrar of Trade Marks on
his own motion decides to refuse the registration of a trade mark or invalidate a registered trade mark
pursuant to sub-section (a) of Section 25 of the Geographical Indications of Goods (Registration and
Protection) Act, 1999, he shall in writing notify the applicants or the registered proprietor of the trade mark
, as the case may be, stating the reason for the same. Thereafter, the Registrar shall decide the matter after

19

<!-- page 20 -->

giving the applicant or the registered proprietor of the trade mark, as the case may be, an opportunity of
being heard.
(2). A request under sub-section (a) of section 25 to refuse a trade mark or invalidate a registered trade
mark which contains or consists of a geographical indication not originating in the territory of a country, or
a region, or locality in that territory which such geographical indication indicates , which is likely to cause
confusion or mislead persons as to the true place of origin of such goods or class or classes of goods shall
be made in the prescribed form under the Trade Marks Rules, 2002. Thereafter, in case of a request for
refusal the Registrar of Trade Marks shall forward the same to the applicant and provide an opportunity of
being heard to the applicant. In case of a request for invalidation, the Registrar of Trade Marks shall
forward the request to the registered proprietor and the procedure set out in Rule 93 of the Trade Marks
Rules, 2002 shall apply mutatis mutandis to further proceedings on the matter.
75(1). Refusal or Invalidation of Registered Trade Mark Conflicting with a geographical indication
notified under Section 22(2).- Where the Registrar of Trade Marks on his own motion decides to refuse an
application or invalidate the registration of a trade mark pursuant to sub-section (b) of Section 25 of the
Geographical Indications of Goods (Registration and Protection) Act, 1999, he shall notify in writing to the
applicant or the registered proprietor of the trade mark, as the case may be, stating the reasons for the same.
Thereafter, the Registrar shall decide the matter after giving the applicant or the registered proprietor of the
trade mark, as the case may be, an opportunity of being heard.
(2). Refusal or invalidation under Section 25(b) of notified geographical indications .-A request under
sub-section (b) of section 25 to refuse an application for the registration of a trade mark or invalidate a
registered trademark which conflict with or which contains or consists of a geographical indication
identifying goods or class or classes of goods notified under sub-section (2) of section 22 shall be made in
the prescribed form under the Trade Marks Rules, 2002. Thereafter, in case of request for refusal, the
Registrar of Trade Marks shall forward the same to the applicant and provide an opportunity of being heard
to the applicant. In case of request for invalidation , the Registrar of Trade Mark shall forward the request
to the registered proprietor and the procedure set out in Rule 93 of the Trade Marks Rules, 2002 shall
apply mutatis mutandis to further proceedings on the matter.
76(1). Publication of refusal or invalidation of Geographical indications.- The Registrar of Trade
Marks shall record and publish a reference to the refusal or the invalidation of the registration of a trade
mark pursuant to section 25 of the Geographical Indications of Goods (Registration and Protection) Act,
1999 and forwarded a copy of the publication to the Registrar of Geographical Indications.
(2). The publication of the reference to the refusal or the invalidation of the registration of a trademark
pursuant to section 25 of the Geographical Indication of Goods (Registration and Protection) Act, 1999
shall include: –
(a)
(b)
(c)
(d)
(e)
(f)

the representation of the mark;
the application or registration number of the trade mark, as the case may be;
the name and address of the applicant or the registered proprietor, as the case may be;
the date of application or the date of registration in the case of a registered trade mark, as the case
may be;
the list of goods or class of goods in respect of which the trade mark was applied for or was
registered; and
a summary of the ground on which the application for registration of a trade mark had been
refused or the registration of the registered trade mark was invalidated.

20

<!-- page 21 -->

CHAPTER VII
PROCEDURE RELATING TO ADDITIONAL PROTECTION TO CERTAIN GOODS UNDER
SECTION 22(2) OF GEOGRAPHICAL INDICATIONS OF GOODS (REGISTRATION AND
PROTECTION) ACT, 1999
77. Additional protection to certain goods.- An application may be made to the Registrar in respect of
goods notified by the Central Government under sub-section (2) of section 22 for additional protection for
a registered geographical indications in Form GI-9 accompanied by prescribed fee in triplicate along with
a Statement of Case. Such case shall be furnished in triplicate and shall be accompanied with the copy of
the notification issued.
78. The application shall be made jointly by the registered proprietor of the geographical indication in India
and by all the producers of the geographical indication whose name has been entered in the register as
authorised user in Part B.
79. Consideration by the Registrar- The Registrar on receipt of the application for additional protection
for such goods in respect of a registered geographical indication in India shall examine whether there are
measurable attributes to the particular geographical indication in relation to the goods or classes of goods in
question with special regard to the reputation of the goods or classes of goods on a global scale, which
requires the additional protection envisaged under sub-section (2) of section 22 be conferred against
usurpation or imitation of the geographical indication even where the true origin of the goods or classes of
goods is indicated or if the registered
geographical indication is used in translated form or is
accompanied by terms such as “kind”, “type”, “style”, “imitation” or other like expressions.
80(1). Hearing before refusing an application.- If on consideration of the application or any other matter
which the applicant may or may be required to furnish, the Registrar has any objections to the acceptance
of the application or proposes to accept it subject to such conditions, as he may think right to impose, the
Registrar shall communicate such objections or proposals in writing to the applicant.
(2). The decision of the Registrar under sub-rule(1) after a hearing or without a hearing if the applicant has
duly communicated his observations in writing and has stated that he does not desire to be heard shall be
communicated to the applicant in writing and if the applicant intends to appeal from such decisions, he may
within two months from the date of such communication request the Registrar requiring him to state in
writing the grounds and the material used by him in arriving at his decision.
81(1). Entry in the Register.- Where the Registrar decides to allow the geographical indication in respect
of which additional protection is to be provided as envisaged under sub-section (2) of Section 22, he shall
enter in the Register a summary of the grounds and the material used by him in arriving at his decision to
accord additional protection to the notified goods in respect of the relevant geographical indication
application.
(2). The entry in Part A of the Register shall state the date on which the application for additional
protection was made, the name, description and principal place of business in India of the registered
proprietor and if they do not carry on business in India their address for service in India.
CHAPTER VIII
MISCELLANEOUS
82(A) Single application.-(1) Where an application for the registration of a geographical indication for
goods is made under sub-section (3)of section 11, the specification of goods contained in it shall set out the
classes in consecutive numerical order beginning with the lowest number and list under each class the
goods appropriate to that class.
(2) If the specification of goods contained in the original application for the registration of a
geographical indication lists by reference to a class or classes in the Fourth Schedule in which they do not
fall, the Registrar shall require the applicant to divide the application on payment of a divisional fee in

21

<!-- page 22 -->

Form GI – 5 to the class or classes to which the application relates together with such class fee as may be
appropriate.
(3)Applications filed under sub-section 3 of section 11 when ordered to be advertised shall be
published in a separate section of the Geographical Indications Journal.
(4) The Registrar shall issue a single certificate of registration in respect of an application made
under sub-section 3 of section11 which has proceeded to registration.
(B) Divisional Application.-(1)Where an application is made in Form GI-5 under proviso to section 15
for the division of a single application, such an application shall be divided into two or more separate
applications upon the payment of a division fee and such class fees as are appropriate.
(2) At any time before registration an applicant may request the Registrar for a division of his
application for registration (the original applications) into two or more separate applications (divisional
applications),indicating for each division the specification of goods. The Registrar shall treat each
divisional application as a separate application for registration with the same filing date as the original
application.
(3) In the case of a request to divide some, but not all, of the goods in a class, a divisional fee for
separate application to be created by division shall be submitted.
(4) If the request to divide does not include necessary fee or is otherwise deficient, the Registrar
will notify the applicant of deficiency. The applicant must correct any such deficiency within thirty days. If
the applicant fails to correct the deficiency within the time provided, the request will be considered as
abandoned and the application will be proceeded further without regard to the request.
(5) Where a request to divide an application is received, the Registrar shall assign an additional
separate new serial number or numbers, as the case may be, and it will be cross referenced with the original
application . Such additional separate application or applications shall be assigned same filing date as the
original application.
(6) For the removal doubt, it is clarified that no new registration is effected when a single
application is divided. On the contrary, application already filed are merely separated or divided into
individual files.
83.
Extension of time.- (1) An application for extension of time under section 64 (not being a time
expressly provided in the Act or a time for the extension of which provision is made in the rules) shall be
made on Form GI- 9.
(2) Upon an application made under sub-rule (1) the Registrar, if satisfied that the circumstances
are such as to justify the extension of the time applied for, may subject to the provisions of the rules where
a maximum time limit is prescribed and subject to such conditions as he may think fit to impose, extend the
time and notify the parties accordingly and the extension may be granted though the time for doing the act
or taking the proceeding for which it is applied for has already expired.
84. Exercise of discretionary power of Registrar.- The time within which a person entitled under
Section 61 to an opportunity of being heard shall exercise his option of requiring to be heard shall, save as
otherwise expressly provided in the Act or the rules, be one month from the date of a notice which the
Registrar shall give to such person before determining the matter with reference to which such person is
entitled to be heard. If within that month such person is required to be heard, the Registrar shall appoint a
date for the hearing and shall give 10 day's notice thereof.
85.
Notification of decision.-The decision of the Registrar in the exercise of any discretionary power
given to him by the Act or the rules shall be notified to the person affected.
86.
Amendments and correction of irregularity in procedure.- (1) Any document, communication
or other representation respecting a geographical indication or an authorised user may be amended and
any irregularity in procedure which in the opinion of the Registrar, may be obviated without detriment to
the interests of any person, may be corrected, if the Registrar thinks fit and proper on such terms as he may
direct.

22

<!-- page 23 -->

(2) The Registrar may require the amendment of any application or representation of a
geographical indication or any other document or the addition of any matter thereto in order to bring it in
accordance with the formal requirements of the Act.
87.
Directions not otherwise prescribed.- Where in the opinion of the Registrar, it is necessary for
the proper prosecution or completion of any proceedings under the Act or rules for a person to perform an
act, file a document or produce evidence, which is not provided for by the Act or the rules, the Registrar
may by notice in writing require the person to perform the Act, file the document or produce the evidence,
specified in the notice.
88.
Hearings.- (1) Subject to sub-rule (2) of rule 4 in relation to a geographical indication for which
an application for registration is made on or after the notified date, the application as well as any
proceeding under the Act and the rules shall, in the event of a hearing becoming necessary, be heard at the
appropriate office of the Geographical Indications Registry at which such application was made under
sub-section (4) of section 11, or at such place within the territorial jurisdiction of that office as the Registrar
may deem proper.
(2) Where an officer exercising the powers of the Registrar who has heard any matter under the
Act or the Rules, has reserved orders therein, is transferred from one office of the Registry to another or
reverts to another appointment before passing an order or rendering decision therein, he may, if the
Registrar so directs, pass the order or render the decision as if he had continued to be the officer in the
office of the Registry where the matter was heard.
AWARD OF COSTS BY REGISTRAR
Costs in uncontested cases
89.
Where any opposition duly instituted under the rules is not contested by the applicant, the
Registrar in deciding whether costs should be awarded to the opponent shall consider whether the
proceedings might have been avoided if reasonable notice had been given by the opponent to the applicant
before the notice of opposition was filed.
90.
Exception to rule 89.-Notwithstanding anything in rule 89, costs in respect of fees specified
under entries, 7, 8 and 9 of the First Schedule and of all stamps used on and affixed to affidavits used in
the proceedings shall follow the event.
91. Scale of costs.Subject to the provisions of rules 89 and 90, in all proceedings before the
Registrar the Registrar may, save as otherwise expressly provided by the Act, award such costs, not
exceeding the amount admissible therefor, as he considers reasonable having regard to all the
circumstances of the case.
REVIEW OF DECISION BY REGISTRAR
92.
Application for review of Registrar's decision.-An application to the Registrar for the review of
his decision under clause (c) of section 60 shall be made on Form GI-7
within one month from the date
of such decision or within such further period not exceeding one month thereafter as the Registrar may on
request allow, and shall be accompanied by a statement setting forth the grounds on which the review is
sought. Where the decision in question concerns any other person in addition to the applicant, such
application and statement shall be left in triplicate and the Registrar shall forthwith transmit a copy each of
the application and statement to the other person concerned. The Registrar may, after giving the parties an
opportunity of being heard, reject or grant the application, either unconditionally or subject to any
conditions or limitations, as he thinks fit.

23

<!-- page 24 -->

AFFIDAVITS
93.
Form, etc. of Affidavits.- (1) The Affidavits required by the Act and the rules to be filed at the
Geographical Indications Registry or furnished to the Registrar, unless otherwise provided in the Second
Schedule, shall be headed in the matter or matters to which they relate, shall be drawn up in the first person,
and shall be divided into paragraphs consecutively numbered, and each paragraph shall, as far as
practicable, be confined to one subject. Every affidavit shall state the description and the true place of
abode of the person making the same, shall bear the name and address of the person filing it and shall state
on whose behalf it is filed.
(2) Where two or more persons join in an affidavit, each of them shall depose separately to such
facts which are within his personal knowledge and those facts shall be stated in separate paragraphs.
(3) Affidavits shall be taken (a) In India -before any court or person having by law authority to receive evidence, or before any
officer empowered by such Court as aforesaid to administer oaths or to take affidavits,
(b) in any country or place outside India - before a diplomatic or consular officer, within the
meaning of the Diplomatic and Consular Officers (Oaths and Fee) Act, 1948, of such country or place, or
before a notary public, or before a judge or magistrate, of the country or place.
(4) The person before whom an affidavit is taken shall state the date on which and the place where
the same is taken and shall affix his seal, if any, or the seal of the Court to which he is attached, thereto and
sign his name and description at the end thereof.
(5) Any affidavit purporting to have affixed, impressed or subscribed thereto or therein the seal or
signature of any person authorised by sub-rule (3) to take an affidavit, in testimony of the affidavit having
been taken before him, may be admitted by the Registrar without proof of the genuineness of the seal or
signature or of the official character of that person.
(6) Alterations and interlineations shall, before an affidavit is sworn or affirmed, be authenticated
by the initials of the person before whom the affidavit is taken.
(7) Where the deponent is illiterate, blind or unacquainted with the language in which the affidavit
is written, a certificate by the person taking the affidavit that the affidavit was read, translated or explained
in his presence to the deponent, that the deponent seemed perfectly to understand it and that the deponent
made his signature or mark in his presence, shall appear in the jurat.
(8) Every affidavit filed before the Registrar in connection with any of the proceedings under the
Act or the rules shall be duly stamped under the law for the time being in force.
INSPECTION OF DOCUMENTS BY THE PUBLIC
94. Inspection of documents.The documents mentioned in sub-section (1) of section 78 shall be
available for inspection at the Head office of the Geographical Indications Registry. A copy of the register
and such of the other documents mentioned in section 78, as the Central Government may by notification
in the Official Gazette direct, shall be available for inspection at each branch office of the Geographical
Indications Registry as and when established. The inspection shall be on payment of the prescribed fee and
at such times on all the days on which the offices of the Geographical Indications Registry are not closed
to the public, as may be fixed by the Registrar.
95.
Distribution of copies of Journal and other documents.-The Central Government may direct
the Registrar to distribute the journal and any other document which it may consider necessary, to such
places as may be fixed by the Central Government in consultation with the State Governments and notified
from time to time in the Official Gazette.
CERTIFICATES
96. Certified copies of documents.- The Registrar may furnish certified copies of any entry in the register
or certified copies of any documents referred to in sub-section (1) of section 78 or of any decision or order
of the Registrar, or give a certificate other than a certificate under sub-section (2) of section 16 as to any
entry, matter or thing which he is authorised or required by the Act or the rules to make or do, upon

24

<!-- page 25 -->

receipt from any person of an application therefor on Form GI-7 accompanied by the prescribed fee. The
Registrar shall not be obliged to include in any certificate or certified copy a copy of any geographical
indication unless he is furnished by the applicant with a copy thereof suitable for the purpose:
97. Certificate for use in obtaining registration abroad.- (1) Where a certificate relating to the
registration of a geographical indication is desired for use in obtaining registration in any territory outside
India, the Registrar shall include in the certificate a copy of the geographical indication and may require
the applicant for the certificate to furnish him with a copy of the geographical indication suitable for that
purpose, and if the applicant fails to do so, the Registrar may refuse to issue the certificate.
(2) Where a geographical indication is registered without limitation of colour, the copy of the
geographical indication to be included in the certificate, may be either in the colour in which it appears
upon the register or in any other colour or colours and it shall be stated in the certificate that the
geographical indication is registered without limitation of colour.
(3) The Registrar may state in the certificate such particulars concerning the application for registration or
the registration of the geographical indication as may deem fit to him, and may specify the terms and
conditions and other limitation appearing on the Register.
APPEALS TO THE INTELLECTUAL PROPERTY APPELLATE BOARD
98. Time for appeal.(1)An appeal to the Intellectual Property Appellate Board from any decision of
the Registrar under the Act or the rules shall be made within three months from the date of receipt of such
decision or within such further time as the said Appellate Board may allow.
(2) A copy of every application to the said Intellectual Property Appellate Board under the Act or
the rules shall be served on the Registrar.
CERTIFICATE OF VALIDITY
99. Certificate of validity to be noted.-Where the Intellectual Property Appellate Board has certified as
provided in section 72 with regard to the validity of a registered geographical indication , the proprietor
thereof may request the Registrar on Form GI-7 to add to the entry in the register a note that the certificate
of validity has been granted in the course of the proceedings, particulars of which shall be given in the
request. An officially certified copy of the certificate shall be sent with the request, and the Registrar shall
record a note to that effect in the register and publish the note in the Journal.
RETURN OF EXHIBITS AND DESTRUCTION OF RECORDS.
100.
Return of exhibits .- (1) Where the exhibits produced in any matter or proceeding under the Act
or the rules are no longer required in the Geographical Indications Registry, the Registrar may notify the
party concerned to take back the exhibits within a time specified by him and if the party fails to do so, such
exhibits shall be dealt with in the manner mentioned under sub-rule(2) below.
(2)
Where any exhibits have been produced in any proceeding, the Registrar may, if satisfied that it is no
longer necessary to retain them, cause them to be destroyed, after the expiration of six months from the
notified date.
101. Destruction of records.- Where an application for the registration of a geographical indication or an
authorised user has been withdrawn abandoned or refused or the geographical indication or the authorised
user has been removed from the register, the Registrar may, at the expiration of three years after the

25

<!-- page 26 -->

application is so withdrawn or is abandoned or is refused or after the geographical indication is removed
from the register, as the case may be, destroy all or any of the records relating to the application for the
geographical indication or the authorised user concerned.
PART II
REGISTRATION OF GEOGRAPHICAL INDICATIONS AGENT
102. Register of Geographical Indications Agent.- The Registrar of Geographical Indications shall
maintain a Register of Geographical Indications Agents wherein shall be entered the name, address of the
place of residence, address of the principal place of business, the nationality, qualifications and date of
registration of every registered Geographical Indications Agent.
103. Registration of existing registered trade marks agent.-(1) Subject to rule 104 every person
whose name is on the notified date on the Register of Trade Marks Agents maintained under the Trade
Marks Rules, 2002 shall be deemed to be registered as a Geographical Indications Agent under the Act
and the rules.
(2) The continuance fee of Geographical Indication s Agents deemed to be registered under sub rule(1)
shall be payable as and from the notified date.
(3) The Registrar may publish the Dress Code for Registered geographical indications Agent in the
Geographical Indications Journal.
(4) The Registrar may publish in the Journal a code of conduct for registered geographical indications
agents.
104. Qualifications for registration.- Subject to the provisions of rule 105, a person shall be qualified to
be registered as a Geographical Indications Agent if he(i)
is a citizen of India;
(ii)
is not less than 21 years of age;
(iii)
has passed the examination prescribed in rule 108 or is an Advocate within the meaning of the
Advocates Act,1961;
(iv)
is a graduate of any university in India or possess an equivalent qualification; and
(v)
is considered by the Registrar as a fit and proper person to be registered as a Geographical
Indications Agent.
105. Persons debarred from registration.- A
Geographical Indication s Agent if he –
(i)
(ii)
(iii)
(iv)

(v)
(vi)
(vii)

person shall not be eligible for registration as a

has been adjudged by a competent Court to be of unsound mind;
is an undischarged insolvent;
being a discharged insolvent has not obtained from the Court a certificate to the effect that his
insolvency was caused by misfortunate without any misconduct on his part;
has been convicted by a competent Court, whether within or without India of an offence
punishable with transportation or imprisonment, unless the offence of which he has been
convicted has been pardoned or unless on an application made by him, the Central Government
by order in this behalf, has removed the disability;
being a legal practitioner has been held guilty of professional misconduct by any High Court in
India or by any Court beyond the limits of India;
being a chartered accountant, or a company secretary has been held guilty of negligence or
misconduct by a High Court; or
being a registered geographical indication agent has been held guilty of professional
misconduct by the Registrar.

26

<!-- page 27 -->

106. Manner of making application.- Subject to sub-rule (2) of rule 4, all applications under the
provisions of this Part shall be made in triplicate, and shall be sent to or left at that office of the
Geographical Indications Registry within whose territorial limits the principal place of business of the
applicant is situate.
107. Application for registration as a geographical indications agent.-(1) Every person desiring to be
registered as a Geographical Indications Agent shall make an application on Form GI-8.
(2)The applicant shall furnish such further information bearing on his application as may be
required of him at any time by the Registrar.
108.
Procedure on application and qualifying requirements. -(1) On receipt of an application for
the registration of a person as a geographical indications agent, the Registrar, if satisfied that the applicant
fulfils the prescribed qualifications, shall appoint a date in the due course on which the candidate will
appear before him for a written examination in Geographical Indications Law and the Practice and
Procedure in relation thereto and followed by an interview. The candidate will be expected to possess a
detailed knowledge of the provisions of the Act and the rules and a knowledge of the elements on law of
geographical indication.
(2)
The qualifying mark for the written examination and for interview shall be 40 percent and 50 percent
respectively and a candidate shall be declared to have passed the examination only if he obtained an
aggregate of 50 per cent of the total marks.
109. Certificate of registration.-After a candidate has been interviewed and any further information
bearing on his application, which the Registrar may consider necessary has been obtained and if the
Registrar considers the applicant eligible and qualified for registration as a geographical indications agent,
he shall send an intimation to that effect to the applicant and any person so intimated may pay the
prescribed fee in Form GI-8 for his registration as a Geographical Indications Agent. Upon receipt of
the same, fee the Registrar shall cause the applicant’s name to be entered in the register of Geographical
Indications Agents and shall issue to him a certificate on Form O-4 of his registration as a Geographical
Indications Agents.
110. Continuance of a name in the Register of Geographical Indications Agents.-The continuance of a
person’s name in the Register of Geographical Indications Agents shall be subject to his payment of the
fees prescribed in Form GI-8.
111.
Removal of agent’s name from the Register of Geographical Indications Agents.(1) The Registrar shall remove from the Register of Geographical Indications Agents the name of any
registered Geographical Indications Agent(a)from whom a request has been received to that effect ; or
(b) from whom the annual fee has not been received on the expiry of three months from the date on
which it became due.
(2) The Registrar shall remove from the Register of Geographical Indication s Agents the name of any
registered Geographical Indications agent(a)who is found to have been subject at the time of his registration, or thereafter has become subject
to any of the disabilities stated in clauses (i) to(vi) of rule 105; or
(b)
whom the Registrar has declared not to be a fit and proper person to remain in the
Register by reason of any act of negligence, misconduct or dishonesty committed in his professional
capacity;
(c)whose name has been entered in the register by an error or on account of misrepresentation or
suppression of material fact:
Provided that before making such declaration under clause (b) and (c) the Registrar
shall call upon the person concerned to show cause why his registration should not be cancelled and shall
make such further enquiry, if any, as it may consider necessary.

27

<!-- page 28 -->

(3)
(4)

The Registrar shall remove from the Register of Geographical Indications Agents the name of any
registered geographical indications agent who is dead.
The removal of the name of any person from the Register of Geographical Indications Agents shall
be notified in the Official Gazette and in the Journal and shall, wherever possible , be
communicated to the person concerned.

112. Power of Registrar to refuse to deal with certain agents. (1) The Registrar may refuse to
recognise(a)
(b)

any individual whose name has been removed from, and not restored to the Register;
any person, not being registered as a Geographical Indications Agent, who in the opinion of the
Registrar is engaged wholly or mainly in acting as agent in applying for geographical indications
in India or elsewhere in the name or for the benefit of the person by whom he is employed;
(c) any company or firm, if any person whom the Registrar could refuse to recognise as agent in respect
of any business under these rules, is acting as a director or manager of the company or is a partner in the
firm.
(2)
The Registrar shall also refuse to recognise as agent in respect of any business under this rule any
person who neither resides nor has a place of business in India
113. Restoration of removed names. -The Registrar may , on an application made on Form GI-8 within
six months from the date of removal of his name from the Register of Geographical Indications Agent
accompanied by the fee specified in the First Schedule from a person whose name has been removed under
clause (b) of sub-rule(1) of rule 111, restore his name to the Register of Geographical Indications Agent
and continue his name therein for a period of one year from the date on which his last annual fee became
due.
114. Alteration in the Register of Geographical Indications Agents.- (1) A registered
Geographical Indications Agent may apply for alteration of his name, address of the place of residence,
address of the principal place of business or qualifications entered in the Register of Geographical
Indications Agent. On receipt of such application the Registrar shall cause the necessary alteration to be
made in the Register of Geographical Indications Agent.
(2)Every alteration made in the Register of Geographical Indications Agents shall be notified in
the Journal.
115. Publication of the Register of Geographical Indications Agents.The
Register
of
Geographical Indications Agents shall be published from time to time and a complete list thereof at least
once in two years in the Geographical Indications Journal as the Registrar may deem fit, the entries being
arranged in the alphabetical order of the surnames of the registered Geographical Indications Agent and
copies thereof shall be placed on sale.
116. Appeal.- An appeal shall lie to Intellectual Property Appellate Board from any order or decision of
the Registrar in regard to the registration of Geographical Indications Agents under Part II of these rules,
and the decision of the Appellate Board shall be final and binding.

28

<!-- page 29 -->

THE FIRST SCHEDULE
[See rule 10(1)]
No. of Entry
(1)
1A
1B

1C
1D

2A

2B

2C

3A
3B
3C
4A

4B

4C

On what payable

Amount in Rupees

(2)
On application for the registration of a
geographical indication for goods included
in one class [Section 11(1), rule 23(2)].
On application for the registration of a
geographical indication for goods included
in one class from a convention
country[Section 11(1), 84(1), rule 23(3) .
On a single application for the registration
of a geographical indication for goods in
different classes [Section 11(3) rule 23(5)].
On a single application for the registration
of a geographical indication for goods in
different classes from a convention country
[Section 11(3), 84(1), rule 23(4)].
On a notice of opposition to the registration
of a geographical indication under section
14(1) or an opposition to an authorised user
Section 17(3)(e).
On a counter-statement in answer to a notice
of opposition under section 14(2)
or
17(3)(e) for each application opposed and in
answer to an application under section 27 in
respect of each geographical indication or in
answer to a notice of opposition under
section 29.
On application for extension of time for
filing notice of opposition. [Section 14(1),
17(3)(e), 29(2), rule 41(5)]
On application for the registration of an
authorised user of a registered geographical
indication under section 17, Rule 56(1)
On request for issuance of a registration
certificate as an authorised user, Rule 59(1)
For renewal of an authorised user 18(2), rule
60(1)
For renewal under section 18(1) of the
registration of a geographical indication at
the expiration of the last registration. Rule
60(1).
On application under section 18(5) for
restoration of geographical indication or an
authorised user removed from the Register.
rule 63.
On application for renewal under proviso to
section 18(4) Proviso to rule 62 within six
months from the expiration of last

29

(3)
5,000

Corresponding
Numbers
(4)
GI-1

5,000

GI-1

5,000
for each class

GI-1

5,000
for each class

GI-1

1,000
for each class

GI-2

1,000

GI-2

300

GI-2

500

GI-3

100

GI-3

1,000

GI-3

3,000

GI-4

1000
plus applicable
renewal fee

GI-4

3,500

GI-4

Form

<!-- page 30 -->

5A

5B
5C

5D

registration of geographical indication.
On request for alteration of the address of
the principal place of business or of
residence in India or of the address in the
home country abroad in the Register of
Geographical Indications are authorised
user, Section 28, rule 69.
On request to enter change in name or
description of proprietor of geographical
indication upon the Register.
On request for correction of any error in the
name , address or description of the
registered proprietor or the authorised user
of a geographical indication. (Section 28(a)).
On application for the rectification of the
register in Part B for the removal of an
authorised user. Section 27, Rule 65.

300

GI-5

300

GI-5

300

GI-5

1,000

GI-5

5E

On division of goods in a class or on
division of an application made for
registration of a geographical indication in
different classes under proviso to Section
15, rule 23(7).

1,000

GI-5

5F

For a search under rule 22 in respect of one
class.
On application under section 27 for
rectification of the register or removal of a
geographical indication or expunge or vary
the Statement of the Case under rule 32(1)
recorded in the Register or an authorised
user from the register, Rule 65.
On application for leave to intervene in
proceedings relating to the rectification of
the Register or for the removal of a
geographical indication or an authorised user
from the Register. Rule 67 and 80(4).

500

GI-5

1,000

GI-6

500

GI-6

300

GI-7

6A

6B

7A

On request for certificate
[other than a certificate under
Section 69 or 78(1)]. Rule 96

7B

Affidavit in support of statement of case or
other documents required under the Act or
rules.
On request for entry in the Register and
advertisement of a note of certificate of
validity of the Appellate Board. Rule 99.
On application for review of Registrar’s
decision.
On request to registrar for particulars of
advertisement of a geographical indication
On request to Registrar for a duplicate or
further copy of certificate.
Application for registration
of a

7C
7D
7E
7F
8A

of Registrar

30

Nil

GI-7

200

GI-7

500

GI-7

100

GI-7

200

GI-7

1,000

GI-8

<!-- page 31 -->

8B.
8C

8D
9C.
9B.

9A.
10A
10B.
11

12.

13

geographical indications agent. Rule 107.
On request for issuance of certificate as
1,000
geographical indications agent. Rule 109.
For continuance of the name of a person in
1,000
the Register of Geographical Indication
Agent under rule 110;
- For every year (excluding the first
year) to be paid on 1st April in each
year.
- For the first year to be paid along
with the fee for registration, in the
case of a person registered at any
time between the 1st April, and 30th
September.
N.B: A year for this purpose will commence
on the 1st day of April and end on the 31st
day of March following.
On application for restoration of the name of
1,000
a person to the Register of Geographical plus continuance fee
Indications under rule 113
under entry No.8C
On application for extension of time not
300
being a time expressly provided in the Act or
prescribed in the rules. Rule 83.
On application for leave to add or alter a
300
registered geographical indication [except
where the application is made by an or of a
public authority or in consequence of a
statutory requirement. Section 29.
On application to Registrar for additional
25,000
protection to certain goods. Section 22(2),
rule 77(1).
On application for cancellation of an entry in
300
the Register or to strike out goods. (Section
28(c) or (d)).
Form of authorisation of agent in a matter or
Nil
proceedings under the Act. Section 76, Rule
20
On petition (not otherwise charged) for
500
obtaining the Registrar’s order on any
interlocutory matter in a contested
proceeding.
For inspecting the document mentioned in
Section 78(1)a) relating
to
any
particular
100
geographical
indication
or
authorised user thereof for every
hour or part thereof;
b) computer search (when made
100
available) for every 15 minutes;
c) Search of index mentioned in
section 78 for every hour or part
100
thereof.
For copying of documents (photocopy or
10
typed) for every page or part thereof in
excess of one page

31

GI-8
GI-8

GI-8
GI-9
GI-9

GI-9
GI-10
GI-10

<!-- page 32 -->

THE SECOND SCHEDULE
FORMS
[List of forms]
Form No.

Section of the Act

(1)
GI-1

(2)
Section 11(1), rule 23(2)

GI-1

Sections 11(1), 84(1), rule 23(3)

GI-1

Sections 11(3), rule 23(5)

GI-1

Sections 11(3), 84(1), rule 23(4)

GI-2

Sections 14(1), 17(3)(e)
Rule 41

GI-2

GI-3

Section 14(2), 17(3)(e),27 & 29,
rule 43(1), 58, 72(2)
Section 14(1), 17(3)(e), 29(2), rule
41(5), 72(2)
Section 17(1), rule 56(1)

GI-3

Section 18(5), rule 59

GI-3
GI-4

18(2), rule 60(1)
Section 18(4), Rule 60

GI-4

Sections 18(5), rule 63

GI-4

Proviso to section 18(4) Proviso to
rule 62

GI-5

Section 28, rule 69

GI-5

28 (c )

GI-5

28(a)

GI-2

Title
(3)
Application for the registration of a
geographical indication for goods included
in one class
Application for the registration of a
geographical indication for goods included
in one class from a convention country
A single application for the registration of a
geographical indication for goods in
different classes.
A single application for the registration of a
geographical indication for goods in
different classes from a convention country .
Notice of opposition to the registration of a
geographical indication or an opposition or
an authorised user.
Form of counterstatement
Application for extension of time for filing
notice of opposition
Application for the registration of an
authorised user of a registered geographical
indication.
Request for issuance of a registration
certificate as an authorised user.
For renewal of an authorised user
Renewal of the registration of a geographical
indication at the expiration of the last
registration.
Application for restoration of geographical
indication or an authorised user removed
from the Register.
Application for renewal within six months
from the expiration of last registration of
geographical indication.
On request for alteration of the address of
the principal place of business or of
residence in India or of the address in the
home country abroad in the Register of
Geographical Indications are authorised
user.
Request to enter change in name or
description of proprietor of geographical
indication upon the Register.
Request for correction of any error in the
name , address or description of the
registered proprietor or the authorised user

32

Entry
Number
(4)
1A
1B
1C
1D
2A
2B
2C
3A
3B
3C
4A
4B
4C
5A

5B
5C

<!-- page 33 -->

of a geographical indication.
Application for the rectification of the
register in Part B for the removal of an
authorised user.

GI-5

Section 27, Rule 65

GI-5
GI-5

Rule 22
Proviso to Section 15, rule 23(7)

A request for search in respect of one class.
Division of an application made for
registration of a geographical indication in
different classes

5E
5F

GI-6

Section 27

6A

GI-6

Rule 67 and 80(4)

GI-7

Section 69 or 78(1)]. Rule 96.

Application for rectification of the register
or removal of a geographical indication or
expunge or vary the Statement of the Case
under rule 32(1) recorded in the Register
from the register.
Application for leave to intervene in
proceedings relating to the rectification of
the Register or for the removal of a
geographical indication or an authorised user
from the Register.
Request for certificate of Registrar [other
than a certificate under Section 16(2) ].

GI-7

Rule 93

7B

GI-7

72, rule 99

GI-7

63, rule 92

GI-7

Rule 40

GI-7

Rule 55(2)

GI-8

Rule 107

GI-8

Rule 109.

GI-8

Rule 110.

GI-8

Rule 113

Affidavit in support of statement of case or
other documents required under the Act or
rules.
Request for entry in the Register and
advertisement of a note of certificate of
validity of the Appellate Board.
Application for review of Registrar’s
decision.
Request to registrar for particulars of
advertisement of a geographical indication
Request to Registrar for a duplicate or
further copy of certificate.
Application for registration
of a
geographical indications agent
On request for issuance of certificate as
geographical indications agent
For continuance of the name of a person in
the Register of Geographical Indication
Agent under rule 110;
- For every year (excluding the first
year) to be paid on 1st April in each
year.
- For the first year to be paid along
with the fee for registration, in the
case of a person registered at any
time between the 1st April, and 30th
September.
N.B: A year for this purpose will commence
on the 1st day of April and end on the 31st
day of March following.
On application for restoration of the name of
a person to the Register of Geographical

33

5D

6B

7A

7C
7D
7E
7F
8A
8B
8C

8D

<!-- page 34 -->

GI-9

22(2), rule 77

GI-9

29

GI-9

64, rule 83

GI-10

28 ( c ) or (d)

GI-10

76, Rule 20

Indications under rule 113
On application to Registrar for additional
protection to certain goods.
Application for leave to add or alter a
registered geographical indication [except
where the application is made by an or of a
public authority or in consequence of a
statutory requirement]
Application for extension of time not being
a time expressly provided in the Act or
prescribed in the rules.
Application for cancellation of an entry in
the Register or to strike out goods.
Form of authorisation of agent in a matter or
proceedings under the Act.

34

9A
9B

9C
10A
10B

<!-- page 35 -->

THE THIRD SCHEDULE
Forms to be used by the Registrar
LIST OF FORMS
Form No.
0-1
Section16(3)
0-2
Rule 55(1)
0-3
Rule 61 ..
0-4
Rule 102
indications agent.
O-5
Rule 55(1)
user.

Title
..
Notice of non-completion of registration
..
Certificate of registration of geographical indication
Notice of expiration of last registration.
..
Certificate of registration of a person as a geographical
Notice of expiration of last registration of an authorised

35

<!-- page 36 -->

FORM 0-1
GOVERNMENT OF INDIA
GEOGRAPHICAL INDICATION REGISTRY
GEOGRAPHICAL INDICATION OF GOODS (REGISTRATION AND PROTECTION) ACT,1999
Notice of non-completion of registration..
No.............
ice is hereby given as required by section 16(3) that the registration of the geographical indication , in
respect of which application numbered as above was made on the ........day of .....20...., has not been
completed by reason of default on the part of the applicant. Unless registration is completed within twentyone days from the date of this notice, the application will be treated as abandoned.
All communications relating to this application may be sent to the following address in India:Dated this ......day of .....200....
Registrar of Geographical Indications
To,_______________

36

<!-- page 37 -->

FORM 0-2
GOVERNMENT OF INDIA
GEOGRAPHICAL INDICATION REGISTRY
GEOGRAPHICAL INDICATION OF GOODS (REGISTRATION AND PROTECTION) ACT,1999
Certificate of registration of geographical indication under Section 16(1) or of unauthorised user
under section 17(3)(e)
Geographical Indication No....................
Authorised user No … … … … … … … …
Date.........................
Certified that the Geographical Indication (of which a representation is annexed hereto) /authorised user
has been registered in the register in the name of .....in Class.....under NO.......as of the date ..........in
respect of ............
Sealed at my direction this:......day of .....200......
Registrar of Geographical Indications.
Registration is for 10 years from the date first above-mentioned and may then be renewed for a period of 10
years, and also at the expiration of each period of 10 years thereafter. .
This certificate is not for use in legal proceedings or for obtaining registration abroad.

37

<!-- page 38 -->

FORM 0-3
GOVERNMENT OF INDIA
GEOGRAPHICAL INDICATION REGISTRY
GEOGRAPHICAL INDICATION OF GOODS (REGISTRATION AND PROTECTION) ACT,1999
Notice of expiration of last registration under Section 18(4) of Geographical Indications Act 1999
Agent
Registered geographical indication No… … … … …
Class… … … ..…
Notice is hereby given as required in section 18(4) of the Geographical Indication Of Goods (Registration
And Protection) Act,1999 that the registration of the aforesaid geographical indication will expire
on… … … ..…and that the registration can be renewed for a further period of ten years on receipt in the
Geographical Indication Registry of an application in the enclosed Form GI 4 accompanied by prescribed
fee of Rs. 3,000 on or before the said date.
Dated this… … … day
… of … … …
.200_.
Registrar of Geographical Indications

38

<!-- page 39 -->

FORM 0-4
GOVERNMENT OF INDIA
GEOGRAPHICAL INDICATION REGISTRY
GEOGRAPHICAL INDICATION OF GOODS (REGISTRATION AND PROTECTION) ACT,1999
Certificate of registration as Geographical Indication Agent
Rule-109
No...
This is to certify that ..............................................................................
..................................................................................................................................
.............................................................................................................................................
of .........................................................................................................................................
was registered on this .........day of .........200............in the Register of Geographical Indication Agent
maintained under rule-102 Of Geographical Indication of Goods (Registration and Protection) Rules, 2002.
Registrar of Geographical Indications

39

<!-- page 40 -->

FORM 0-5
GOVERNMENT OF INDIA
GEOGRAPHICAL INDICATION REGISTRY
GEOGRAPHICAL INDICATION OF GOODS (REGISTRATION AND PROTECTION) ACT,1999
Notice of expiration of last registration under section 18(4)
Registered authorised user No… … …
.
Notice is hereby given as required under section 18(4) of the Geographical Indication Of Goods
(Registration And Protection) Act,1999 that the registration of the aforesaid authorised user will expire
on… … … …and
… that the registration can be renewed for a further period of ten years on receipt in the
Geographical Indication Registry of an application in the enclosed Form GI 3 accompanied by the
prescribed fee of Rs. 1,000 on or before the said date.
Dated… … … ….day…
… … …
..200-

Registrar of Geographical Indications

40

<!-- page 41 -->

THE FOURTH SCHEDULE
Classification of goods– Name of the classes
(Parts of an article or apparatus are, in general, classified with the actual article or apparatus, except where
such parts constitute articles included in other classes).
Class 1.

Chemical used in industry, science, photography, agriculture, horticulture and forestry;
unprocessed artificial resins, unprocessed plastics; manures; fire extinguishing
compositions; tempering and soldering preparations; chemical substances for preserving
foodstuffs; tanning substances; adhesive used in industry

Class 2.

Paints, varnishes, lacquers; preservatives against rust and against deterioration of wood;
colorants; mordents; raw natural resins; metals in foil and powder form for painters;
decorators; printers and artists

Class 3.

Bleaching preparations and other substances for laundry use; cleaning; polishing;
scouring and abrasive preparations; soaps; perfumery, essential oils, cosmetics, hair
lotions, dentifrices

Class 4.

Industrial oils and greases; lubricants; dust absorbing, wetting and binding compositions;
fuels(includingmotor spirit) and illuminants; candles, wicks

Class 5.

Pharmaceutical, veterinary and sanitary preparations; dietetic substances adapted for
medical use, food for babies; plasters, materials for dressings; materials for stopping
teeth, dental wax; disinfectants; preparation for destroying vermin; fungicides, herbicides

Class 6.

Common metals and their alloys; metal building materials;
transportable buildings of metal; materials of metal for railway tracks; non-electric cables
and wires of common metal; ironmongery, small items of metal hardware; pipes and
tubes of metal; safes; goods of common metal not included in other classes; ores

Class 7.

Machines and machine tools; motors and engines (except for land vehicles); machine
coupling and transmission components (except for land vehicles); agricultural
implements other than hand-operated; incubators for eggs

Class 8.

Hand tools and implements (hand-operated); cutlery; side arms; razors

Class 9.

Scientific, nautical, surveying, electric, photographic, cinematographic, optical,
weighing, measuring, signalling, checking (supervision), life saving and teaching
apparatus and instruments; apparatus for recording, transmission or reproduction of
sound or images; magnetic data carriers, recording discs; automatic vending machines
and mechanisms for coin-operated apparatus; cash registers, calculating machines, data
processing equipment and computers; fire extinguishing apparatus

Class 10.

Surgical, medical, dental and veterinary apparatus and instruments, artificial limbs, eyes
and teeth; orthopaedic articles; suture materials

Class 11.

Apparatus for lighting, heating, steam generating, cooking, refrigerating, drying
ventilating, water supply and sanitary purposes

Class 12.

Vehicles; apparatus for locomotion by land, air or water

Class 13.

Firearms; ammunition and projectiles; explosives; fire works

41

<!-- page 42 -->

Class 14.

Precious metals and their alloys and goods in precious metals or coated therewith, not
included in other classes; jewellery, precious stones; horological and other chronometric
instruments

Class 15.

Musical instruments

Class 16.

Paper, cardboard and goods made from these materials, not included in other classes;
printed matter; bookbinding material; photographs; stationery; adhesives for stationery or
household purposes; artists’ materials; paint brushes; typewriters and office requisites
(except furniture); instructional and teaching material (except apparatus); plastic
materials for packaging (not included in other classes); playing cards; printers' type;
printing blocks

Class 17.

Rubber, gutta percha, gum, asbestos, mica and goods made from these materials and not
included in other classes; plastics in extruded form for use in manufacture; packing,
stopping and insulating materials; flexible pipes, not of metal

Class 18.

Leather and imitations of leather, and goods made of these materials and not included in
other classes; animal skins, hides, trunks and travelling bags; umbrellas, parasols and
walking sticks; whips, harness and saddlery

Class 19.

Building materials, (non-metallic), non-metallic rigid pipes for building; asphalt, pitch
and bitumen; non-metallic transportable buildings; monuments, not of metal.

Class 20.

Furniture, mirrors, picture frames; goods(not included in other classes) of wood, cork,
reed, cane, wicker, horn, bone, ivory, whalebone, shell, amber, mother- of-pearl,
meerschaum and substitutes for all these materials, or of plastics

Class 21.

Household or kitchen utensils and containers(not of precious metal or coated therewith);
combs and sponges; brushes(except paints brushes); brush making materials; articles for
cleaning purposes; steelwool; unworked or semi-worked glass (except glass used in
building); glassware, porcelain and earthenware not included in other classes

Class 22.

Ropes, string, nets, tents, awnings, tarpaulins, sails, sacks and bags (not included in other
classes) padding and stuffing materials(except of rubber or plastics); raw fibrous textile
materials

Class 23.

Yarns and threads, for textile use

Class 24.

Textiles and textile goods, not included in other classes; bed and table covers.

Class 25.

Clothing, footwear, headgear

Class 26.

Lace and embroidery, ribbons and braid; buttons, hooks and eyes, pins and needles;
artificial flowers

Class 27.

Carpets, rugs, mats and matting, linoleum and other materials for covering existing
floors; wall hangings(non-textile)

Class 28.

Games and playthings, gymnastic and sporting articles not included in other classes;
decorations for Christmas trees

Class 29.

Meat, fish, poultry and game; meat extracts; preserved, dried and cooked fruits and
vegetables; jellies, jams, fruit sauces; eggs, milk and milk products; edible oils and fats

42

<!-- page 43 -->

Class 30.

Coffee, tea, cocoa, sugar, rice, tapioca, sago, artificial coffee; flour and preparations
made from cereals, bread, pastry and confectionery, ices; honey, treacle; yeast, baking
powder; salt, mustard; vinegar, sauces, (condiments); spices; ice

Class 31.

Agricultural, horticultural and forestry products and grains not included in other classes;
live animals; fresh fruits and vegetables; seeds, natural plants and flowers; foodstuffs for
animals, malt

Class 32.

Beers, mineral and aerated waters, and other non-alcoholic drinks; fruit drinks and fruit
juices; syrups and other preparations for making beverages

Class 33.

Alcoholic beverages(except beers)

Class 34.

Tobacco, smokers’ articles, matches

43

<!-- page 44 -->

THE FIFTH SCHEDULE
Scale of costs allowable in Rule 91 proceedings before the Registrar
________________________________________________________
Entry Matter in respect of which costs to be awarded
Amount
No.
________________________________________________________
1.
For one day's hearing involving examination
Rs.1000
of witnesses
2.

For one day's hearing when there is no
examination of witnesses

Rs. 500

3.

For adjournment of hearing granted
on the petition of any party.

4.

For striking out scandalous matter
from an affidavit

Rs.500 plus cost of
resummoning the
other parties’ witness who were
due to be examined on the day
Rs.200

5.

For attendance of witnesses Subsistence allowance....
Travelling allowance...

Rs.500 (vide not below) fare by rail or
steamer second class each way and if there
is no rail or steamer communication Rs 5 or
2.50 per km. depending upon the rank and
status of the witness.

Note: the rates of subsistence allowance and travelling allowance for witness shall vary according to the
status of the witness subject to the maximum prescribed above.
--------------------

44

<!-- page 45 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

A
B
1.

(REGISTRATION & PROTECTION) ACT, 1999
(To be filed in triplicate alongwith the Statement of Case accompanied
by five additional representation of the geographical indication)
One representation to be fixed within the space and five others to be send separately
FORM GI-1
Application for the registration of a geographical indication in Part A of
the Register
Section 11(1), Rule 23(2)
Fee: Rs. 5,000 (See entry No.1A of the First Schedule)

Application for the registration of a geographical indication
in Part A of the Register from a convention country

Section 11(1), 84(1), rule 23(3)
Fee: Rs. 5,000 (See entry No.1Bof the First Schedule)
Application is hereby made by (a) ________________ for the registration in Part A of the Register
of the accompanying geographical indication furnishing the following particulars:
- Name of the Applicant:
- Address:
- List of association of persons/producers/organisation/authority:
- Type of goods:
- Specification:
- Name of the geographical indication[and particulars]:
- Description of the goods:
- Geographical area of production and map:
- Proof of origin[ Historical records]
- Method of Production:
- Uniqueness:
- Inspection Body:
- Other:
Along with the Statement of Case in Class (b)__________ (b)_______in respect of
(c)_______________in the name(s) of (d)__________ whose address is
(e)_____________________________________________ who claims to represent the interest of the
producers of the said goods to which the geographical indication relates and which is in continuous
use since __________in respect of the said goods.

2. The application shall include such other particulars called for in rule 32(1) in the Statement of Case
3. All communications relating to this application may be sent to the following address in India:
4.In the case of an application from a convention country the following additional particulars shall also be
furnished
a)
Designation of the country of origin of the geographical indication
b)
Evidence as to the existing protection of the geographical indication in its country of origin, such
as the title and the date of the relevant legislative or administrative provisions, the judicial
decisions or the date and number of the registration, and copies, of such documentation

(5)SIGNATURE
NAME OF THE SIGNATORY
(IN BLOCK LETTERS)

45

<!-- page 46 -->

C

A single application for the registration of a geographical indication
in Part A of the Register for goods falling in different classes
Section 11(3), rule 23(5)
Fee: Rs. 5,000 for each class (See entry No.1C of the First Schedule)
A single application for the registration of a geographical indication
in Part A of the Register for goods falling in different classes from a
convention country
Section 11(3), rule 23(4)
Fee: Rs. 5,000 for each class (See entry No.1D of the First Schedule)
1. 1. Application is hereby made by (a) ________________ for the registration in Part A of the Register
of the accompanying geographical indication furnishing the following particulars:
- Name of the Applicant:
- Address:
- List of association of persons/producers/organisation/authority:
- Type of goods:
- Specification:
- Name of the geographical indication[and particulars]:
- Description of the goods:
- Geographical area of production and map:
- Proof of origin[ historical records]
- Method of Production:
- Uniqueness:
- Inspection Body:
- Other:
along with the Statement of Case in Class
(i)
class a .................................. in respect of b ........................
(ii)
class a .................................. in respect of b ........................
(iii)
class a .................................. in respect of b ........................
in the name(s) of c................... whose address is(d) ....................... who claim (s) to represent the interest
of the producers of the goods to which the geographical indication relates and which geographical
indication is used continuously since .......... in respect of the said goods.

D

2. The application shall include such other particulars called for in rule 32(1) in the Statement of Case
3. All communications relating to this application may be sent to the following address in India:
4. In the case of an application from a convention country the following additional particulars shall also be
furnished
a) Designation of the country of origin of the geographical indication
b) Evidence as to the existing protection of the geographical indication in its country of origin, such as the
title and the date of the relevant legislative or administrative provisions, the judicial decisions or the
date and number of the registration, and copies, of such documentation

(5)SIGNATURE
NAME OF THE SIGNATORY
(IN BLOCK LETTERS)
For instruction please see overleaf

46

<!-- page 47 -->

GI-1A to 1D
The Registrar of Geographical Indications,
The office of Geographical Indications Registry.

a). Strike out whichever is not applicable.
b). The Registrars’ direction may be obtained if the class of the goods is not known.
c). Here specify the goods. Only goods included in one and the same class to be specified.
d). Insert legibly the full name, description (occupation and calling and nationality of the applicant).
In the case of a body corporate or firm the country of incorporation or the names and descriptions
of the partners composing the firm and the nature of registration, if any, as the case may be, should
be stated. See rule 15.
e) Signature of the applicant or his agent

47

<!-- page 48 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

(REGISTRATION & PROTECTION) ACT, 1999
(To be filed in triplicate)
FORM GI-2
Notice of opposition to application for registration of a geographical indication or an
authorized user [Section 14(1), 17(3) (3), rule 41(1)] Fee : Rs.1,000/- for each class
(See entry No.2 (A) of the First Schedule
In the matter of Application No...................by ................. I(or we)' ...................... hereby give notice of my (or our) intention
to oppose the registration of the geographical indication/authorised user advertised under the above number for class
............in the Geographical Indications Journal dated the ............day of.........20......No..............page.........
The grounds of opposition are as follows:3............................. '
All communications in relation to these proceedings may be sent to the following address in India

A

Dated this ....................... day of ........................

20............

4 SIGNATURE
Form of Counterstatement
Sections 2, 14, 17(3),27, Rules 43(1), 66
(To be filed in triplicate)
Fee: Rs. 1,000/(See entry No.2 (B) of the First Schedule)
In the matter of an opposition No...............to application No................in class _____for the registration of a geographical
indication.
I (or we)' ....................the applicant(s) for registration of the above geographical indication, hereby give notice that the
following are the grounds on which I (or we) rely for my(or our) application:-

B

I (or we) admit the following allegations in the notice of opposition................
2 All communications in relation to these proceedings may be sent to the following address in India:
...................................
................................
Dated this ............day of.........20......

2..............................
SIGNATURE
NAME OF SIGNATORY IN BLOCK
LETTERS

48

<!-- page 49 -->

C

Application for extension of time for giving notice of opposition
Section 14(1), 17(3)(e) and 29(2)., Rule 41(5)
Fee: Rs.300.00
(See entry No.2 (C) of the First Schedule)
In the matter of application No................................. in class ..........
I(or
We)
(1)...........................................................hereby
apply
for
extension
of
time
of
(2)............................................. for giving notice of opposition to the registration of the geographical indication or
authorised user under the above number in the Geographical Indications Journal dated the ............day of ......................20..
The reasons for making this application are as follows:-All communications relating to this application may be sent to the following address in India:Dated this .................. day of .......................20 ..
Signature(3)....................
NAME OF SIGNATORY IN
BLOCK LETTERS

For instruction please see overleaf

49

<!-- page 50 -->

GI-2A
To,
The Registrar of Geographical Indications,
The office of Geographical Indications Registry.
1.
2.
3.

State full name and address. An address for service in India should be given if the opponent has
no place of business or of residence in India.
If registration is opposed on the ground that the geographical indication resembles a trade mark
or a geographical indication already on the register the numbers and the journals in which it has
been advertised are to be set out.
Signature of the opponent or of his agent.

GI-2B
1.
State the full name and address as stated in the application for registration
2.

Signature of the applicant or of his agent.

GI-2C
1. State full name & address.
2 Insert the period of execution required which shall not exceed one month beyond these months from the
date of advertisement or re-advertisement, as the case may be, of the application in the Journal.
3. Signature of the applicant or of his agent

50

<!-- page 51 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

A

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-3
Application for the registration of an authorised user

Fee : Rs.500/-

Section 17(1), Rule 56(1)

(To be filed in triplicate accompanied by the agreement, if any, between the
registered proprietor and the proposed authorised user or duly authenticated
copy thereof, and other documents mentioned in rule 56 along with an
affidavit setting forth particulars and statements required by rule 56 and
with two copies of each of the aforesaid documents)
(See entry No.3 (A) of the First Schedule)
Application is hereby made by 1________________who is (are) the registered proprietor(s) of the geographical
indication2___________ registered in class_________ in respect of goods _________ and ____________being the
proposed authorised user in Part B of the Register of the above mentioned registered geographical indication . A
statement of case of hose the applicant claims to be producer is enclosed herewith. A copy of consent letter from the
Registered Proprietor is enclosed/not enclosed .
All communications relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

B

4 ........................
4 SIGNATURE

Request for issuance of Registration Certificate as an
Authorised User
Section 16(2)17(3)(g), Rule 59(1)
Fee: Rs.100 (See entry No.3B of the First Schedule).

The Registrar is hereby requested under Section 17(3)(g)) read with rule 59(1) to issue the Authorised User
Certificate in respect of application No. _________for the registered geographical indication _________
__________under registered No .__________in Class __________in Part B of the Register.

Dated this ............day of.........20......

2..............................
SIGNATURE

For instruction please see overleaf

51

<!-- page 52 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

C

[Fee: Rs.1000.00

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-3
Renewal of registration of authorized user
Section 18(2), rule 60(1)
(See entry No.3C of the First Schedule)

I(or We) (1)...........................................................hereby leave the prescribed fee of Rs............ for renewal of
registration of the authorized user No.................... in class ......... The notice of renewal of registration may be sent
to the following address in India:.
Dated this .................. day of .......................20 ..
Signature(2)....................
NAME OF SIGNATORY IN
BLOCK LETTERS
To
The Registrar of Geographical Indications,
The office of the Geographical Indications Registry.
1.Insert full name and address of the authorized user.
2.Signature of the authorized user or his agent.
3.State the name of the place of the appropriate office of the Geographical Indications Registry – See rule 4
Note – This form will be returned if it is filed more than six months before the expiration of the last registration.

52

<!-- page 53 -->

To
The Registrar of Geographical Indications,
The office of Geographical Indication Registry.
GI-31A
1.
Insert particulars of the registered proprietor.
2.

Insert name and address

3.

Signature of the Registered Proprietor/Producer or his agent

GI-3B
1.

Signature of the Producer

GI-3C
1.
2.

Insert particulars of the registered proprietor
Signature of the producer or his agent

..

53

<!-- page 54 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

A

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-4
Fee: Rs. 3,000 (See entry No.4A of the First Schedule)
Renewal of registration of geographical indication
Section 18(1), Rule 61

I (or we) 2 ...............................................................................................................hereby leave the prescribed fee of
Rs...................for renewal of registration of the geographical indication No................in Class ................... All communications
relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

B

4 ........................

4 SIGNATURE
Restoration of geographical indication or an authorized user removed from the register for
non-payment of renewal fee. Section 18(5) Rule 63.
Fee: Rs.1,000/- plus the applicable renewal fee prescribed in entry Nos. 4A or 3C of the First
Schedule

I (or we) ' ............................................................................hereby apply that the geographical indication
numbered...................................................................in class .................... be restored to the register and the registration of the
said geographical indication in the class aforesaid be renewed, and that the notice of restoration and renewal be sent to the
following address in India.
Dated this ............day of.........20......

C

2..............................
SIGNATURE

Fee: Rs.3500 (See entry No.4C of the First Schedule)
Application for payment of surcharge towards renewal of a geographical indication under
proviso to sub-section (4) of section 18.

I (or we) 1 … … … ….. the
… registered proprietor/s hereby made by apply for the renewal of registration of registered
geographical indications No.… … … ….in…
class … … …which has expired on … … … …and
…tender the prescribed
surcharge in respect thereof and the renewal certificate be sent to the following address in India:-

Dated this … … … … … day
… … … …
of 20…
Signature
Name of signatory in Block Letters
For instructions please see overleaf

54

<!-- page 55 -->

To
The Registrar of Geographical Indications
The Office of the Geographical Indications Registry, Chennai
GI-4A
1.
Strike out whichever is not applicable.
2.
Insert here the name and address of the Registered Proprietor.
3.
Signature of the registered proprietor or of his agent.
GI-4B
1.. Insert full name, address and nationality of the registered proprietor
2. Signature of the registered proprietor or of his agent
GI-4C
1.Insert here the full name and address of the Registered Proprietor.
2.Signature of the registered proprietor or of his agent.

55

<!-- page 56 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

(REGISTRATION & PROTECTION) ACT, 1999
(To be filed in triplicate)
FORM GI-5
Request for alteration of the address of the principal place of business
or of residence in India or of the address in the home country abroad
in the Register of Geographical Indications are authorised user,
Section 28, rule 69.
Fee: Rs. 300/(See entry No.5A of the First Schedule)
In the matter of geographical indication No… … … … … … … … …
.registered
… … …in
Class… … … … … … … … … … … … …

A

I/We… … … … … …..of
………… … … … … … … … … … … …..being
… …the…registered
… … proprietor/
authorised user of the geographical indication numbered as above, request that the address of my(our) principal
place of business (or residence) in India or address in my (our) home country abroad in the Register of
Geographical Indications be altered to … … … … … … …
The change of address was ordered by… … … ..on
… the … … … …..day
… of … … … 20…
… … … … …
. An
…
officiallycertified copy of the order is enclosed herewith.

All communications on this request may be sent to the following address in India.
Dated this ............day of.........20......

2..............................
SIGNATURE

B

Request to enter change of name or description of association of
person or producers or any organisation or authority in whose name
a geographical indication is registered. Section 28(b).
Fee: Rs. 300
(See entry No.5B of the First Schedule)
I (or we) ' ...................................................................hereby request that my (or our) name (s) and description (s) may
be entered in the Register of Geographical Indication as2 proprietor (s)/ authorised user (s) of the geographical
indication No.3................................................... registered in class ..................................
I am (we are) entitled to 3 the said geographical indication.
................... use the said Geographical Indication as authorised user(s). There has been no change in the actual
proprietorships 2/identity of authorised user(s) of the said geographical indication, but 4 ..................
The entry at present standing in the register gives my (or our) name(s) and description (3) as follows:5 A copy of this request has been served upon the authorised user(s)/proprietor(s)
All communications relating to this application may be sent to the following address in India:Dated this ..............day of ......20......

6..........................
SIGNATURE

For instruction please see overleaf

56

<!-- page 57 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-5
Request for correction of any error in the name, address or
description of the registered proprietor or the authorised user of a
geographical indication. Section 28(a)
Fee: Rs.300
(See entry No. 5C of First Schedule)
In the matter of geographical indication No...................................................registered in class
.....................................................................................

C

I (or we) ........................................of ....................................................
being the registered proprietor 2 of the geographical indication numbered as above,
authorised
user
request that the 2address of my (our) principal place of business 2(or residence) in India or address in my(our) home
country abroad in the Register of Geographical Indication be altered to .............
3The change of address was ordered by4 .......................on the .............................
day of ................20...............An officiallycertified copy of the order is enclosed herewith.
All communications relating to this application may be sent to the following address in India:All communications on this request may be sent to the following address in India.
Dated this ............day of.........20......

2..............................
SIGNATURE

D

Application for the rectification of the register in Part B for the
removal of an authorised user. Section 27, and Rule 65.
Fee: 1,000 ((See entry No. 5D of First Schedule)
In the matter of Geographical Indication No............................................................................
registered in the name of ................................ in Class................................
I (or We) ' ................................................................................................ hereby apply that the entry in the register in
respect of the abovementioned authorised user of registered geographical indication No… … … … …
may
…be
(removed)2 (rectified) in the following manner:The grounds of my (our) application are as follows:The 3............Office of the Geographical Indications Registry has been entered in the register as the appropriate
office in relation to this geographical indication.
No action concerning the geographical indication in question is pending in any Court
All communications relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

4 ........................

SIGNATURE

4 SIGNATURE

For instruction please see overleaf

57

<!-- page 58 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

E

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-5
Application for the division of an application made for the
registration of a geographical indication in different classes of goods.
Proviso to Section 15 rule 23(7), 82(B)
Fee: 1000 (See entry 5E of the First Schedule)

In the matter of Geographical Indication No… … … … … in
…Class…
…
… …
.. in the name of … … … ….filed
… on
… … … ….. …
… request the Registrar to divide the application No… … … ..…
or for the division of the
I (or we)1 … … … …hereby
registered geographical indication No. … … …
in class… … … .into
… … … … … …
.or …
for the division of a single
application in… … … class/
… classes into in the following class or classes 2 or to divide the specification of goods
or services in Class … … … … …
... as
…indicated below:
… … … … … … … … …
. … … …
… … … … … … … … …
. … … …
A copy of the Registrar order on the request may be sent to the following address in India :Dated this ............day of.........20......
2..............................
SIGNATURE

F

Fee: Rs.500.00 (See entry No.5F of the First Schedule)
Request for search under rule 22

The Registrar is hereby requested under rule 22 to search in class' ...............in respect of2................. to ascertain
whether any geographical indication are on record which resemble the trade mark sent or geographical indication
herewith in triplicate. (each representation being mounted on a sheet of strong paper approximately 33 centimetres
by 20 centimetres in size.)
All communications relating to this application may be sent to the following address in India:-

Dated this .................day of ......20.........

4 ........................

SIGNATURE

4 SIGNATURE

For instruction please see overleaf

58

<!-- page 59 -->

To
The Registrar of Geographical Indications
The Office of Geographical Indications Registry ,Chennai
GI-5A
1.
Strike out word(s) not applicable.
2.
Insert the name of the public authority ordering the change and the date thereof.
3.
Signature of the registered proprietor/authorised user or of his agent.
GI-5B
1.
Insert present name and address of registered proprietor or authorised user.
2.
Strike out the words that are not applicable.
3.
State the circumstances under which the change of name took place.
4.
Strike out if not applicable.
5.
Signature of applicant or of his agent.
Footnote:
No fee, however, payable where the application for alteration or change of name is made
as a result of an order of a public authority or in consequence of a statutory
GI-5C
1.
2.
3.

Strike out word(s) not applicable.
Insert the name of the public authority ordering the change and the date thereof.
Signature of registered proprietor or of his agent.
Footnote: No fee is, however, payable in case the alteration is made as a result of an order of a
public authority in India.

GI-5D
1.
State full name, address and nationality. An address for service in India should be stated if the
applicant has no place of business or of residence in India.
2.
Strike out the word that is not applicable
3
Signature of the applicant or his agent
GI-5E
1.
2.
3.

Insert the full name, address and nationality of the applicant.
Mention the goods or services and the class or classes in which it is to be registered in ascending
numerical order.
Signature of the applicant or his agent

GI-5F
1.
2.
3.

The Registrar's direction may be obtained if the class is not known.
Here specify the goods (in the class stated) in respect of which the search is to be made.
Signature of the applicant or his agent.

Footnote: No fee is payable in cases where the directions of the Central Government for exemption from
payment of fee have been obtained.

59

<!-- page 60 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-6
Application for the rectification of the register or the removal of a
geographical indication from the register or to expunge or vary the
Statement of Case under rule 32(1) recorded in the Register. section
27, and Rule 65.
Fee: Rs.1,000
(See entry No. 6A in the First Schedule)
In the matter of Geographical Indication No............................................................................
registered in the name of ................................ in Class................................
I (or We) ' ................................................................................................ hereby apply that the entry in the register in
respect of the abovementioned Geographical Indication may be (removed)2 (rectified) in the following manner:-

A

The grounds of my (our) application are as follows:The 3............Office of the Geographical Indication Registry has been entered in the register as the appropriate
office in relation to this geographical indication.
No action concerning the geographical indication in question is pending in any Court
All communications relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

4 ........................

SIGNATURE

4 SIGNATURE
Application for leave to intervene in proceedings relating to the
rectification of the register or the removal of a geographical indication
from the register or the cancellation of an authorised user of a
geographical indication from the register. Rule 67, 80(4).
Fee: Rs. 500
( See entries No.6B of the First Schedule)
In the matter of the Geographical Indication No.......................................................................................... registered in
the name of ....................................................in class .........................
I ( we)'....................................................................................................
hereby apply for leave to intervene in the proceedings relating to the rectification or removal of the entry in the
register in respect of the above mentioned geographical indication/additional protection under section 22(2)or
cancellation of an authorised user.
My (our) interest in the Geographical Indication........................................

B

A copy of the Registrar order on the request may be sent to the following address in India :Dated this ............day of.........20......

2..............................
SIGNATURE

For instruction please see overleaf

60

<!-- page 61 -->

To
The Registrar of Geographical Indications
The Office of Geographical Indications Registry,Chennai
GI-6A
1.
State full name, address and nationality. An address for service in India should be stated if the
applicant has no place of business or of residence in India.
2.
Strike out the word that is not applicable
3.
Signature
GI- 6B
1.
2.

State full name, address and nationality
Signature

61

<!-- page 62 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-7
Request for certificate of the Registrar [Section 78(2)].
Fee: Rs. 300
(See entry No. 7A of the First Schedule)
In the matter ' of geographical indication No. .............................................. registered in Class
......................................................... I (or we)2 ................................................hereby request the Registrar to furnish me (us)
with his certificate to the effect that4 .............................
a certified copy
......................................................... ......................................................... .........................................................
......................................................... 3a certificate of the registration of geographical indication for use in obtaining
registration in5 ......................................
................... The certificate/certified copy be sent to the following address in India A copy of the Registrar order on
the request may be sent to the following address in India :-

A

Dated this ............day of.........20......

2..............................
SIGNATURE

B

Affidavit (only to be furnished where required by the Act or the rules)
(See entry No. 7B of the First Schedule)
I,' ....................................of .................................do hereby solemnly and sincerely declare that the particulars set out in the
statement of case, exhibit marked ....................and left by me in connection with [2]........................... in respect of the
geographical indication No.................in class ......................are true and comprise every material fact and document
affecting the present proprietorship of the geographical indication, to the best of my knowledge, information and belief.
Dated this .................day of ......20.........

4 ........................

SIGNATURE

C

4 SIGNATURE

Request for entry in the register and advertisement of a
notice of certificate of validity by the Appellate Board Under
rule 99

Fee: 200/-(See entry No. 7C of the First Schedule)
In the matter of geographical indication No.....................................registered in class ............... in the name of
....................................
I or(we)' .................................... .................................... hereby request the Registrar to add to the entry relating to the above
numbered geographical indication in the register, and to advertise in the Geographical Indication Journal, a note that in 2
............................
....................................
the Appellate Board certified that the validity of the said registration came into question and was decided in favour of the
proprietor of the geographical indication in the terms of accompanying officiallycertified copy of the certificate of validity.
All communications relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

4 ........................

SIGNATURE

4 SIGNATURE

For instruction please see overleaf

62

<!-- page 63 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-7
Application for review of Registrar's decision
Section 60(c) Rule 92
Fee: 500
(See entry 7D of the First Schedule)
In the matter of '............................................................................
I (or we)2 .................................................... being the ....................... in the above matter hereby apply to the Registrar for
the review of this decision dated the ............. day of ...........20..........., in the above matter.

D

The grounds for making this application are set forth in the accompanying statement
All communications relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

E

4 ........................

4 SIGNATURE
Request to Registrar for particulars of advertisement of a geographical
indication, Rule 40
Fee: 100 (See entry 7E of the First Schedule

I (or we)' .................................................................................... hereby request that I (or we) may be informed of the number,
date and page of the Journal in which the geographical indication sought to be registered under Application No.................in
the name of ....................is advertised
The information may be sent to the following address in India 2Dated this ................day of ..........20.........
3...........................
SIGNATURE

NAME OF SIGNATORY
IN BLOCK LETTERS

F

Fee: Rs. 200 (See entry No. 7F)
Request for duplicate or further copy of the certificate of registration
/authorised user rule 55(2)/59(3).
(If the applicant had furnished a label for advertisement, this Form must be accompanied by one unmounted representation
of the geographical indication exactly as shown in the Form of application at the time of registration)
I (or we)'......................................................................................request the Registrar to furnish me (us) with 3 duplicate
/further copy of the certificate of registration issued to me (us) under sub-section (2) of section 16 in respect of my (our)
geographical indication NO. .............. registered in class ..........in the Register.
Dated this .................day of ......20.........

4 ........................

SIGNATURE

4 SIGNATURE

For instruction please see overleaf

63

<!-- page 64 -->

To
The Registrar of Geographical Indications
The Office of Geographical Indications Registry, Chennai
GI-7A
1.
2.
3.
4.
GI-7B
1.
2.
3.
4.

GI-7C
1.
2.
3.

Insert name, address and nationality of the person making the request.
Set out the particulars which the Registrar is required to certify or state particulars of the
document of which a certified copy is required.
Insert the name of country or state.
Signature
Insert full name, address and nationality of deponent.
Insert particulars of the proceedings concerned.
To be signed here by the person making the declaration.
Signature and title of authority before whom affidavit is taken. In India affidavit may be taken
before any Court or person having by law authority to receive evidence or before an officer
empowered by a Court to administer oath. Outside India affidavit may be taken before a
Diplomatic or Consular Officer within the meaning of the Diplomatic and Consular officers
(Oaths and Fees) Act, 1948, of such country or place or before a Notary of the place if the notarial
acts done by notaries of the place have been recognised by the Central Government under Section
14 of the Notaries Act, 1952.
To be stamped under the law for the time being in force.
State the name and address of the registered proprietor.
State the nature of the proceedings with the names of the parties to them, in which the certificate
was given.
Signature.

GI-7D
1.
Here Insert the words and reference number identifying the matter in respect of which the
application is made.
2.
State full name and address.
3.
Signature.
GI-7E
1.
2.

State full name and address.
Signature.

GI-7F
1.
2.
3.

Insert the name and address of the registered proprietor.
Strike out whichever is not applicable.
Signature of the registered proprietor or the authorised user of his agent.

64

<!-- page 65 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

A

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-8

Application for registration as a Geographical Indications Agent,
Rule 107

To be filed in triplicate)

Fee:Rs. 1,000
( See entry No. 8A of the First Schedule)

I beg to apply for registration as a trade marks agent under THE GEOGRAPHICAL INDICATIONS OF GOODS
(REGISTRATION AND PROTECTION) RULES, 2000
.
1 A certificate of character from................ is enclosed herewith.
I, hereby declare that I am not subject to any of the disabilities stated in clauses (i), (ii),(iii),(iv),(v) and (vi) of rule 105 of the
Geographical Indications of Goods (Registration and Protection) Rules, 2000 and that the information given below is true to
the best of my knowledge and belief.
1. Name in full beginning with surname if any (in capital letters).......................
2. Address of the place of residence...................................................................
3. Principal place of business..............................................................................
4. Father's name.................................................................................................
5. Nationality......................................................................................................
6. Date and place of birth...................................................................................
7. Occupation in full...........................................................................................
8. Particulars of qualifications for registration as a Geographical Indications Agent..........................
9. Whether at any time removed from the Register of Geographical Indications Agent and if so the reason
such removal.
All communications relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

4 ........................
4 SIGNATURE

65

for

<!-- page 66 -->

B

Request for issuance of Certificate as a Geographical
Indications Agent

Rule 109
Fee: Rs.1,000 (See entry No.8B of the First Schedule)
The Registrar is hereby requested under rule 109 to issue the certificate as a Geographical Indication Agent as the
applicant has become eligible and qualified to be a Geographical Indications Agent.
All communications relating to this application may be sent to the following address in India:Dated this ................day of ..........20.........
3...........................
SIGNATURE

NAME OF SIGNATORY
IN BLOCK LETTERS

C

Request for continuance of name in the Register of Geographical
Indications Agent
Rule 110
Fee. 1,000
(See entry 8C of First Schedule)
The Registrar is hereby requested under rule 110 to issue a continuance of the name in the Register of Geographical
Indication Agent for the period from __________to___________
All communications relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

4 ........................

SIGNATURE

D

4 SIGNATURE

Application for the restoration of the name of a person to
the Register of Geographical Indications Agent (Rule 113)
(To be filed in triplicate)
Fee: Rs. 1,000 plus continuance fee under
( See entry No. 8D).

1.......................................................................................................of...............................................................
hereby apply for the restoration of my name to the Register of Geographical Indication Agents in which my name was
entered under No........... My name was removed on.......... under rule 113 of the Geographical Indication of Goods
Rules,2002.
All communications relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

4 ........................

SIGNATURE

4 SIGNATURE

For instructions please see overleaf

66

<!-- page 67 -->

To
The Registrar of Geographical Indications
The Office of Geographical Indications Registry, Chennai
GI-8A to GI-8D
1. The certificate testifying to the character of the candidate should be from a person not related to
the candidate and being a District Magistrate, a Chief Presidency Magistrate or the Chief
Administrative Officer of the District where the candidate usually resides, or from any other
person whom the Registrar may consider fit.
2.

Either original diplomas, certificates and other documents in support of qualifications claimed, or
copies thereof duly attested by a magistrate, a notary public or a J.P. must be sent with the
application.
Particulars such as the amount of experience in the Geographical Indications Registry or with a
commercial firm of repute, may be specified.

3.

Signature

67

<!-- page 68 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

A

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-9

Application for additional protection for certain goods.
Section 22(2), rule 77
Fee: Rs.25,000.00
(See entry No. 9A of the First Schedule)
I(or We) (1)...........................................................being the registered proprietor of the geographical indications
......................... in class ..............hereby apply for additional protection under Section 22(2) of the Act.
The statement of case required to be submitted under rule 77(1) is enclosed with.
All communications relating to this application may be sent to the following address in India:All communications relating to this application may be sent to the following address in India:Dated this .................day of ......20.........

4 ........................

4 SIGNATURE
Application by registered proprietor under Section 29 for an addition or
alteration of a registered geographical indication.
Fee: Rs.300/See entry No.9B of the First Schedule and footnote below.
In the matter of geographical indication No.......................... registered in class ..........
Application is hereby made by (1).......................... being the registered proprietor(s) of the registered
Geographical Indication numbered as above for leave to add or alter the said geographical indication in the following
particulars, that is to say (2)...............................
Five copies of the geographical indication as it will appear when altered are filed herewith.
(3) A copy of this application and a copy of the geographical indication as it will appear when so altered has
been published in two leading newspapers circulated in the area (copy enclosed)
All communications relating to this application may be sent to the following address in India:-

B

Dated this .................. day of .......................20 ..
Signature(4)....................
NAME OF SIGNATORY IN
BLOCK LETTERS

68

<!-- page 69 -->

C

Fee: 300 (See entry 9C of the First Schedule)
Application for extension of time [not being a time
expressly provided in the Act or prescribed by rule)
Section 64 rule 83(1).

In the matter of '.......................................................
I (or we)2........................................................................being the '................................ in the above matter hereby apply
for an extension of time of 3.................for4...............on the following grounds:All communications relating to this application may be sent to the following address in India:Dated this ...................day of .........19.........
5.............................
SIGNATURE
NAME OF SIGNATORY
For instruction please see overleaf

GI-9C
1.Identify the subject matter
2.State full name and address
3.Insert the period of extension required which shall not … ….
4. State the purpose for which extension of time is required

69

<!-- page 70 -->

THE GEOGRAPHICAL INDICATIONS OF GOODS

(REGISTRATION & PROTECTION) ACT, 1999
FORM GI-10
Application by registered proprietor of a geographical indication for
the cancellation of entry thereof in the register or to strike out any
goods or classes of goods from those in respect of which the
geographical indication is registered. Section 28 (c ) or (d).
Fee: Rs. 300
( See entries No.10A of the First Schedule)
In the matter of geographical indication No.......................Class.....................
Name of registered proprietor ........................
Address as entered in the register..................
Application is hereby made by the aforesaid registered proprietor that the entry in the Register of geographical
indication No...........in class ........may be cancelled.

A

2A copy of the application has been served on the Authorised User(s)
All communications relating to this application may be sent to the following address in India:Dated this ................day of .........20.........

B

3..........................
SIGNATURE
NAME OF SIGNATORY IN BLOCK
LETTERS

Form of Authorisation of Agent in a matter or proceeding under the
Act (Section 76 and rule 20)

I(or we)' .................................... .................................... hereby authorise 2 ....................................
.................................... .................................... of .................................... ....................................
.................................... to act as my (or our) agent for 3 ....................................and request that all notices,
requisitions and communications relating thereto may be sent to such agent at the above address,.
I (or we) hereby revoke all previous authorisations, if any, in respect of the proceeding.
All communications relating to this application may be sent to the following address in India:Dated this .............day of ...........20........
4 ....................................

SIGNATURE
NAME OF SIGNATORY
IN BLOCK LETTERS

For instruction please see overleaf

70

<!-- page 71 -->

To
The Registrar of Geographical Indication
The Office of the Geographical Indications Registry, Chennai
GI-10A
1.
Strike out whichever is not necessary.
2.
Strike out if not applicable.
3.
Signature of the registered proprietor or of his agent.
4.
Signature
..

71
