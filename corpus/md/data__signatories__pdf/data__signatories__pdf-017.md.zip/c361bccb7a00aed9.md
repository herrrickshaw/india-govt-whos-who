---
doc_id: "c361bccb7a00aed9"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/366244992afa9691b6aaeed65ec468cd.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Recruitment Rules of RML Hospital New Delhi"
date: "2017-12-31"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a99fecc69cdb66cf"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE
Public Notice on draft-Recruitment Rules for Senior Physiotherapist in Dr. R.M.L.
Hospital, New Delhi.

In compliance with DoPT’s Dy, No. 1174096/CR/16-Estt.(RR). dated 31-05-16,
the draft Recruitment Rules for Senior Physiotherapist in Dr. R.M.L. Hospital, New
Delhi is annexed. .

The stakeholders interested in making any objections/comments or suggestions on
the draft Recruitment Rules may do so in writing, within a period of 30 days from the

‘ date of publication of draft Recruitment Rules to Sh. Thenkholal Baite, Section Officer
(MH-II), Room No. 405A, Directorate General of Health Services, Nirman Bhawan,
_ Maulana Azad Road, New Delhi-110108 or e-mail address: t-baite|2@nic.in
Al
GA ean fi 12477
Under Secretary to the Govt. of India
Tele fax No. 23061436
New Delhi
Dated: 3+ t2+22!7

<!-- page 2 -->

। {TO BE PUBLISHED IN THE GAZETTE OF INDIA PART ll, SECTION 3, SUB-SECTION (i)]
‘ : GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE
Notification
New Delhi, the , 2015

GSR... In exercise of the powers conferred by the proviso to Article 309 of the Constitution

and in supersession of the Safdarjung Hosptial and Dr. Ram Manohar Lohia Hospital, New Delhi

(Senior Physiotherapist) and Lecturer (Physiotherapy), Recruitment Rules, 2000 in so for as they

relate to the post of Senior Physiotherapist in Dr. Ram Manohar Lohia Hospital except os respects

things done or omitted to be done before such supersession, the President herepy makes the
following rules regulating the method of recruitment to the post of Senior Physiotherapist in Dr.

Ram Manohar Lohia Hospital, New Delhi, namely:

1. Short title and commencement. - (1) These rules may be called the Dr, Ram Manohar Lohia
Hospital, New Delhi, Senior Physiotherapist | Group ‘A’ post} Recruitment Rules, 2015 under
Ministry of Health and Family Welfare (2) They shall come into force on the date of their
publication in the Official Gazette.

| 2. Number of posts, classification, pay pand and grade pay or pay scale. ~ The number of the
said post, Its classification, the pay band and grade pay or pay scale attached thereto shall
be as specified in columns {2} to (4) of the Schedule annexed to these rules.

3, Method of recruiimeni, age limit, qualification, etc. - The method of recruitment age-limit,
qualification and other matters relating to the scid post shall be as specified in columns (5) to
(13) of the said Schedule.

4. Disqualification. - No person, -

(a) who has entered into or contracted a mariage with a person having a spouse living ,
or
(b) who, having @ spouse living, has entered into or contracted a marriage with any
person,
shail be eligible for appointment fo the said post:

Provided that the Central Government. may, if satisfied that such mariage is !
permissible under the personal law applicable fo such person and the other party to the
mariage and that there are other grounds for so doing, exempt any person from ihe
operation of this rule.

5, Power to relax. - Where the Central Government is of the opinion that it is necessary or
expedient so fo co, it may, by order, for reasons to be recorded in writing and in consultation
with Union Public Service Commission relax any of the provisions of these rules with respect to
any class or category of persons.

Saving ~ Nothing In these rules shail affect reservation, relaxation of age-limit and other concessions
required to be provided for the scheduled Castes, the Scheduled 11085, Other Backward Classes,
Ex-servicemen and other special categories of person, in accordance with the orders issued by the
Central Government from ime to time in this regard.

<!-- page 3 -->

= Schedule
~ Name of the post. Number of posts. Pay Band and Grace Pay/Pay
Scale ost.
| ऐ  '/ 4
Senior Physiotherapist 2 (2015) General Central , Selection
subject $0 | service, Group PB-2 Rs, 15600-39100
variation ‘A’ Gazetted, GC
dependent ON | Non-Ministerial Plus Rs.5400 as Grade Pay
workload. हे
Agé limit for direct recruits. Educational and other qualifications | Whether age | Period of | Method of
required for direct recruits. and probation, | recruitment,
educational | if any. whether by direct
. qualifications recruitment or by
prescribed promotion or by
for direct है deputation/
recruits — will absorption and
है apply in the percentage of the
. case of vacancies fo be
promotes. filed by various
methods.
: [i की
Not applicable Not applicable Not Two years | By Promotion
applicable
eee ़़़़़ फफफफफफफ ऊऑऊऊःछ&_ल्‍_

<!-- page 4 -->

. in case of recruitment by promotion /deputation/ lf a Departmental Promotion Committee exists, Circumstances in which
~ absorption grade from which promotion /deputation what is its composition Union Public Services
. ° Jabsorplion to be made -
consulted in making
recruitment.
u 12 ek -_|/
Promotion:
Physiotherapist in the pay scale of Rs. 9300-34800: plus | Group ‘A’ Deparimental Promotion Commitiee(for | Consultation witin UPSC
4200 Grade Pay with eight years regular service. promotion} है necessary.
Note 1: Where juniors who have completed their | ). Chairman or Member of UPSC.
qualifying or eligibility service are being considered for Chairman
promotion, their seniors would also be considered | 2. Joint Secretary, Ministry of Health & Family
provided they are not short of the requisite qualifying or | Welfare.
eligibility service by more than half of suchqualifying or Member.
eligibility service or two years, whichever is less, and have | 3. Depuly Director General in charge of
successfully completed probation period for promotion to Medical Hospital Section, Directorate General of
the next higher grade along with their juniors who have | Heallh Services.
already compieted such qualifying or eligibility service. Member
4, Head of Physical Medicine and
Note 2: For the purpose of computing minimum qualifying | Rehabilitation, Dr. Ram Manohar Lohia Hospital
service for promotion, the service rendered on a regular Member
basis by an officer prior to 1.1 (2006 or the date from which
jhe revised pay structure based on the Sixth Central Pay
Commission recommendations has been extended shail
be deemed to be service rendered in the corresponding -
grade pay or pay scale extended based on the
recommendations of the pay commission.
(No. A. 11018/24/2015—-MH Il)
है GB Rag hntr® KG
(Senjey-Per)
Under Secretary to the Government of India
ne  ऋखझःझःऋ
