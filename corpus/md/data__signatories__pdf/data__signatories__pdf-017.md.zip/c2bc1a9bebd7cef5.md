---
doc_id: "c2bc1a9bebd7cef5"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/de66dddb994e9fcacacaaae90a495546.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of short code '1920' to Prayagraj Smart City Ltd"
date: "2019-12-09"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "64eebcac78cd9838"
---

<!-- page 1 -->

File No, 16= 112017-AS~lll/ShortCodes

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No. 16-/2017-AS-IIl/Short codes/ / lf:5 8'/

Dated :4 /12/2019

To,'
All Access Service Providers,
Subject: - Allocation of short code 1920 to Prayagraj Smart City Limited for Magh
.Mela-2020 regarding.
The undersigned is directed to convey the re-allocation of Short Code '1920' to
Prayagraj Smart City Limited for Magh Mela-2020 with following features as under:
· (i) Category-I: Service (i.e. mandatory service to be provided by all the Access
providers.
(ii) Accessibility: Un-restricted i.e. available, on STD also.
(iii), Non-Metered:service
2.

All are requested to take necessary action.

3.

This is issued with the approval ofDDG (AS).

Copy forwarded for information and necessary action to, if any, to:
1.
2.

Secretary, TRAI.
CMD MTNL /CMD BSNL.

3. 0/o Chief Executive Officer, Prayagraj Smart City Limited, 1st Floor, P-Square Mall,
Civil Lines, Prayagraj, Uttar Pradesh-211001 to appoint a nodal officer to implement the
helpline. (The Nodal officer may contact DDG (TERM), TERM Cell, UP (East)).
4. Director (P&N), DoT (HQ) (respective TERM Cells may be asked to co-ordinate with
respective Nodal Officers and TSPs for implementation of Helpline, as and when
approached).
5. A copy for upload on DoT Website.
