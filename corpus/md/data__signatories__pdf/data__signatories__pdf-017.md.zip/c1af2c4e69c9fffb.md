---
doc_id: "c1af2c4e69c9fffb"
source_url: "https://www.niti.gov.in/sites/default/files/2024-05/Manual6_WLR_as%20on%20date%2007.05.2024.pdf"
ministry: "Planning (MoP)"
title: "Manual-6 Rules, regulations, instruction, manuals and records for discharging functions WATER & LAND RESOURCES Vertical (as on 31.03.2024)"
date: "2024-05"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ffe6f96747e07d1b"
---

<!-- page 1 -->

Self-appraisal by Public Authorities on the CIC's Portal

Information under section 4(i) (b) RTI Act, 2005
Information related to WATER & LAND RESOURCES Vertical

Manual 6 - Rules, regulations, instruction, manuals and records for
discharging functions
Title
Rules, regulations,
instruction,
manuals and
records for
discharging
functions

Details of Disclosure
The rules/ regulation etc. as applicable to Central Government
Employees/All India Service Officers and Central Government
Offices are followed for discharging of its functions.
