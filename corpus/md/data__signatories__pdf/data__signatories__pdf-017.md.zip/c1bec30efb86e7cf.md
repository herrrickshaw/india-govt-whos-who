---
doc_id: "c1bec30efb86e7cf"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/BilingDetailedNITept02_13052026.pdf"
ministry: "Department of Space"
title: "SHAR: CMG CIVIL: MAINT: E-Public Tender-02/26-27 Dated: 11.05.2026      1108.36 KB"
date: ""
pages: 7
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "2aaf2b9c1326703e"
---

<!-- page 1 -->

भारत सरकार-अंतररक्ष विभाग / GOVERNMENT OF INDIA-DEPARTMENT OF SPACE
विर्ााण तथा अिुरक्षण सर्ूह, एसडीएससी शार / CONSTRUCTION & MAINTENANCE GROUP, SDSC SHAR
श्रीहररकोटा-524124, आं .प्र. / SRIHARIKOTA-524124, A.P.
विस्तृत ई-विविदा सूचिा/Detailed E- TENDER NOTICE
सं.: शार :सीएर्जी वसविल:अिु: ई-जिविविदा /No: SHAR: CMG CIVIL: MAINT: E-Public Tender-02/26-27

वतवथ / Dt: 11.05.2026

1.भारत के राष्ट्रपतत की ओर से , समान प्रकृतत एवं पररमाण के कार्य का अनुभव रखने वाले पात्र तनतवदाकार /
ं एजेंतसर् ं से तनम्नतलखखत कार्ों के तलए ई-टें डररग के माध्यम से मद-दर तनतवदाएं आमंतत्रत हैं / On behalf of President of India,

online Item Rate tenders are invited through e-tendering for the following works from eligible contractors/ agencies having experience in works of similar nature and magnitude.

वर्णन/Description
कार्ण का नाम /
Title of the work

वववरर्/Details

वववरर्/Details

सुल्लूरुपेटा स्थथत पीएिएि कॉलोिी के C2/D/E/E7 प्रकार के आिासों तथा

सुल्लूरुपेटा स्थथत एसएर्एि और पीएिएि कॉलोविर्ों के पुि:आिंवटत 150 आिासों

पीसीएि कॉलोिी के D2/E/E7 प्रकार के आिासों की बाहरी रं गाई-पुताई (शेष
कार्ा)।

की आं तररक रं गाई-पुताई।

External painting of C2/D/E/E7 type quarters at PNN colony
and External painting of D2/E/E7 type Quarters at PCN
colony, Sullurpeta (Balance Works).

Internal painting of 150 Nos of re-allotted quarters at SMN, PNN
Colony at Sullurpeta.

टी/सी /T/C-26-004

टी/सी /T/C-26-005

` 113.49 लाख / Lakhs

` 37.53 लाख / Lakhs

पूर्ण करने की अवनि /
Period of completion

09 माह/months

12 माह/months

बर्ािा रावश
Earnest
Deposit Rs.

` 2,27,000 /-

` 75,100 /-

ननववदा सं./ Tender No
ननववदा का अनुमाननत
मूल्र् रू. लाख में /
Est. Cost Put to
tender in Rs. Lakhs

जर्ारू./
Money

विविदा दस्तािेज अिुरोध ि डाउिलोड करिे की अिवध / Period during which tender documents can be requested/ downloaded: 12.05.2026, 10:00 बजे/hrs से/to 20.05.2026, 14:30
बजे/hrs
बोली हेतु स्पष्टीकरण/ Bid Clarifications: 12.05.2026, 10:30 बजे/hrs से/to 21.05.2026, 14:30 बजे/hrs

विविदा अपलोड करिे की अंवतर् वतवथ एिं सर्र् / Last date & time for uploading of tenders: 25.05.2026 के/& 14:30 बजे /hrs
विविदा खोलिे की विर्त वतवथ एिं सर्र्/ Due date & time of Opening of tenders: 25.05.2026 के/& 15:00 बजे /hrs

1

<!-- page 2 -->

2. ननववदा दस्तावेज जारी करने हे तु पात्रता मानदं ड / Eligibility Criteria for Issue of Tender Documents:एजेंसी को ननम्ननलखखत शतों को पूरा करना होगा। / The agency shall fulfil the following conditions:
क्र.सं./

पात्रता के नलए दस्तावेजी प्रमार्/Documentary proof for the

पात्रता मानदण्ड/ Eligibility Criteria

Sl.No

ननववदाएं जमा करने की अंनतम नतनि के पूवण ददन समाप्त होने तक वपछले 7 वर्षों के दौरान
नीचे वखर्णत कामको संतोर्षजनक ढं ग से काम पूरा दकर्ा होना चादहए/ Should have
satisfactorily completed the works as mentioned below during the last
7 years ending previous day of last date of submission of bids.
तीन समान प्रकृ नत के कार्ण, खजनकी लागत, अनुमाननत लागत के 40% से कम न हो /
Three similar works each costing not less than 40%of the estimated cost
(र्ा/or)
दो समान प्रकृ नत के कार्ण, खजनकी लागत अनुमाननत लागत के 60% से कम न हो / Two
similar works each costing not less than 60% of the estimated cost
(र्ा/or)
समान प्रकृ नत का एक कार्ण खजसकी लागत अनुमाननत लागत के 80% से कम न हो / One
similar work costing not less than 80% of the estimated cost

a

eligibility(स्व-प्रमाखर्त प्रनतर्ां जमा की जाएँ /Self-attested copies to be
submitted)
i.
कार्ण अनुभव हे तु संबंनित प्रानिकारी द्वारा जारी कार्ण आदे शों एवं कार्ण
पूर्त
ण ा प्रमार्-पत्रों की प्रमाखर्त प्रनत/ Certified copy of work orders and

completion certificates issued by the authority concerned to
establish work experience.
ii.
ननजी पक्षकारों द्वारा जारी कार्ण आदे श और पूर्त
ण ा प्रमार्-पत्रों के
साि टीडीएस (स्रोत पर कर कटौती) प्रमार्-पत्र भी होने चादहए / Completion

certificates for works issued by Private parties shall be supported
by TDS (Tax Deducted at Source) certificates.

समांतर कार्ण से आशर् है दक................ /Similar work shall mean works of....................................
ननववदा सं./Tender No.

समांतर कार्ण से आशर् है दक / Similar work shall mean

टी/सी-26- 004 & 005
T/C-26- 004 & 005

भवन /सुववधाओं में भवन की रं गाई-पु ताई या सामान्य वसववल कायय
Building painting work or General civil works in buildings / facilities.

ननष्पाददत कार्ण के मूल्र् को कार्ण पूर्ण होने की नतनि से बोली हे तु आवेदन प्रानप्त की अंनतम नतनि की अवनि तक के वास्तववक मू ल्र् को वावर्षणक 7% के सरल दर पर बढ़ाकर वतणमान लागत
मूल्र् के स्तर तक लाना होगा/The value of executed works shall be brought to current costing level by enhancing the actual value of work at simple rate of 7% per

annum, calculated from the date of completion to last date of submission of bids.
उप संववदा र्ा संर्ुक्त उद्यम के रूप में ननष्पाददत कार्ण पात्रता / मूल्र्ांकन के नलए मान्र् नहीं होगा।Work executed as sub-contract or joint venture will not merit for eligibility /

evaluation.
केवल अनुरक्षण कार्ों हे तु लागू /Applicable only for maintenance works:-

i.

b

ईपीएफ एवं ईएसआई पंजीर्न अननवार्ण है : उपरोक्त सभी ई-ननववदाओं हे तु ननववदाकार को ननसंदेह ईपीएफ एवं ईएसआई पंजीकरर् की प्रनतनलवपर्ाँ जमा / अपलोड करना
अननवार्ण है ।

Should have EPF and ESI registration: Tenderer should submit / upload EPF and ESI registration copies mandatorily for all the above E-tenders
without fail.

2

<!-- page 3 -->

3. ई-टें डररं ग वेबसाईट www.tenderwizard.com/ISROसे ननववदा दस्तावेज डाउनलोड दकर्ा जा सकता है । ननववदा दस्तावेज डाउनलोड करने मात्र से ही ननववदाकार बोली लगाने के नलए
हकदार नहीं हो जाता। ननववदाकारों द्वारा अपलोड दकए गए दस्तावेजों का ववभाग द्वारा सत्र्ापन दकर्ा जाएगा। र्दद वे अपेक्षानुसार न पाए गए तो उन्हें अस्वीकृ त कर ददर्ा जाएगा
/Downloading of tender documents may be done from e-Tendering website www.tenderwizard.com/ISRO. Downloading of documents alone will not make a

tenderer eligible for participating in the bidding. The documents uploaded by the tenderers will be subjected to verification subsequently by Department. If
found not meeting the requirement, such offers will be rejected.
4. (क) ननववदाओं के साि “लेखा अनिकारी, एसडीएससी शार“ के पक्ष में जारी दकसी अनुसूनचत बैंक के माँग रसीद में जमा/नमर्ादी जमा रसीद/दडमांड ड्राफ्ट के रूप में (र्ा) अनुसूनचत
बैंक द्वारा जारी बैंक प्रनतभूनत के रूप में उपरोक्त पैरा 1 में अंदकत मूल्र् के नलए बर्ाना रानश जमा संलग्न होनी चादहए। िरोहर रानश के मांग ड्राफ्ट के रूप में होने की दशा में , ननववदा
खुलने के तुरंत बाद उसे भुनार्ा जाएगा तिा असफल ननववदाकारों को ववभाग द्वारा इसकी वापसी चेक/इलेक्रॉननक माध्र्म से दकर्ा जाएगा।
ननववदा आमंत्रर् सूचना के प्रकाशन की नतनि के बाद बर्ाना रानश जमा नलर्ा जाए। ननववदा आमंत्रर् सूचना के प्रकाशन की नतनि के पूवण आहररत बर्ाना रानश के साि ननववदा जमा दकए
जाने पर ननववदा अस्वीकृ त की जाएगी। बर्ाना रानश जमा ननववदाओं की प्रानप्त की ननर्त नतनि से 180 ददनों तक वैि होनी चादहए।

(a) Tenders should be accompanied with Earnest Money Deposit as mentioned in para 1 above in the form of Deposit at Call receipt / Term
Deposit Receipt / DD of any Scheduled Bank issued (or) in the form of Bank guarantee issued by a scheduled bank in favour of “Accounts officer
SDSC SHAR”. In case EMD in the form of DD is furnished, the same will be encashed immediately on opening of tenders and refund of EMD for
unsuccessful tenders will be made through cheque / electronically by the department.
The Earnest money deposits should be taken only after the date of publishing of NIT and any tender submitted with Earnest Money Deposits
drawn before the date of publishing of NIT will be rejected. Earnest Money Deposit shall be valid for 180 days from the due date of receipt of
tenders.
ख) एमएसएमई (सू क्ष्म एवं लघु उध्यम) ज तनतवदा दर / ईएमडी से छूट का दावा करते है , क तजला उद्य ग केंद्र (डीआईसी) / खादी और उद्य ग आर् ग (केिीआईबी) / कॉर्र ब डय /
राष्ट्रीर् लघु उद्य ग आर् ग (एिएसआईसी) / हस्ततिल्प और हथकरघा तनदे िालर् र्ा एमएसएमई मंत्रालर् द्वारा तवतनतदय ष्ट् अन्य तनकार् द्वारा जारी एमएसएमई उद्यर् पंजीकरण प्रमाण पत्र
प्रस्तु त करना ह गा। ज्ञापन / प्रमाणपत्र तनतवदा की तनर्ाय ररत र्ा बढाई गई तारीख तक वैर् ह ना चातहए।

(b) The MSEs (Micro & Small Enterprises) claiming exemption of Tender cost/ EMD should submit MSME UDYAM registration certificate issued by District
Industries Centre (DIC) / Khadi & Industries board (KVIB) /Coir board / National small industries commission (NSIC) / directorate of Handicrafts and
handlooms or any other body specified by ministry of MSME. The memorandum/certificate shall be valid as on due date / extended due date of the tender.
िोट:- केवल एमएसएमई (सू क्ष्म एवं लघु उध्यम) ज तजला उद्य ग केंद्र (डीआईसी) / खादी एवं ग्रामीण उद्य ग आर् ग (केिीआईसी) / खादी और उद्य ग ब डय (केिीआईबी) / कॉर्र ब डय / राष्ट्रीर् लघु उद्य ग
आर् ग (एिएसआईसी) / हस्ततिल्प और हथकरघा तनदे िालर् र्ा क ई अन्य तवतनतदय ष्ट् एमएसएमई के मंत्रालर् ईएमडी से छूट का दावा कर सकते हैं ।

Note: Only MSEs (Micro & Small Enterprises) registered with District Industries Centre (DIC) / Khadi & Village Industries Commission (KVIC)/ Khadi &
Industries board (KVIB) /Coir board / National small industries commission (NSIC) / directorate of Handicrafts and handlooms or any other body specified by
ministry of MSME are exempted from EMD.
5. ननववदाएं उपरोक्त पैरा1 में उल्लेखखत ननिाणररत नतनि एवं समर् पर समूह प्रिान/प्रिान, ननमाणर् एवं अनुरक्षर् समूह/प्रभाग के कार्ाणलर् में खोली जाएगी /Tenders will be opened at
the Office of the Group Head/ Head, Construction and Maintenance Group/ Division, SDSC SHAR on the stipulated date and time specified in Para 1 above.

3

<!-- page 4 -->

6. बर्ाना रानश जमा (ईएमडी) का मूल दस्तावेज / एमएसएमई र्ा एनएसआईसी र्ा उद्यम पंजीकरर् इत्र्ादद की र्िा लागू हाडण प्रनत ननववदा खोलने की

ननर्त नतनि एवं समर् पर र्ा उससे पहले व्र्वक्तगत रूप से अिवा डाक से ननम्ननलखखत पते पर जमा दकर्ा जाना चादहए।
Original instrument of Earnest Money Deposit (EMD) / hardcopy of MSME or NSIC or UDYAM registration, etc. as applicable shall be
submitted by hand or by post addressed to the following address on or before due date and time of opening of tender.
समूह प्रिान सीएमजी का कार्ाणलर्,
नसववल अनुरक्षर् अनुभाग,

Office of Group Head CMG,
Civil Maintenance Section,

तकनीकी सेवा भवन

Technical Services Building,

कीपाकम, एसडीएससी शार,

श्रीहररकोटा-524124, आं.प्र. रायर्

Keepakam, SDSC SHAR,
Sriharikota - 524124, AP State

ननववदाकार नलफाफे पर ननववदा का वववरर् अवश्र् नलखे। र्दद ननववदा खोलने की ननर्त नतनि र्ा उससे पहले वैि बर्ाना रानश जमा (ईएमडी) प्राप्त नहीं होती है तो ननववदा प्रस्ताव वबना
ववचार दकए ननरस्त कर दी जाएंगी। डाक पारगमन के कारर् अप्राप्त/दे री के नलए ववभाग खजम्मेदार नहीं होगा।

The tenderer shall write the details of tender on the cover without fail. If valid EMD is not received on or before due date and time of opening of tender, the
tender offer shall be summarily rejected. The department will not responsible for any non/late due to postal transit.
एमएसएमई (सूक्ष्म एवं लघु उध्र्म) र्ूननट, जो ननववदा दर / एमडी से छूट का दावा करते हैं , को उपरोक्त अनुच्छे द4 के अनुसार एमएसएमई उद्यम पंजीकरर् प्रर्ार्पत्र की अनुप्रमाखर्त
हाडण कॉपी (दस्तावेज) प्रस्तुत करना होगी। उपरोक्त ज्ञापन / प्रमार्पत्र की हाडण कॉपी को ननववदा के खुलने की नतनि और समर् को उससे पहले समूह प्रिान / प्रिान, ननमाणर् और अनुरक्षर्
समूह / प्रभाग के कार्ाणलर् में प्रस्तुत करना होगा। र्दद

हाडण कॉपी ननववदा के खुलने की ननिाणररत नतनि र्ा समर् से पहले प्राप्त नहीं होती तो ननववदा प्रस्ताव ननरस्त कर ददर्ा जाएगा।

The MSEs(Micro & Small Enterprises) units claiming exemption of tender cost/ EMD should submit attested hard copy of MSME UDYAM registration
certificate as indicated in Para 4 above. The hard copy of above memorandum / certificate shall be submitted to the office of the Group Director/Group Head/
Head, Construction and Maintenance Group/Division on or before due date and time of opening of tender. If hard Copy is not received on or before due
date and time of opening of tender, the tender offer shall be summarily rejected.
7.ननववदा खोलने की ननर्त नतनि पर वैि बर्ाना रानश जमा (ईएमडी) प्रस्तुत करने वाले ननववदाकारों की तकनीकी एवं वाखर्खयर्क बोली को खोला जाएगा। तकनीकी एवं वाखर्खयर्क बोली
को खोलने के बाद, आगे ववस्तृत संवीक्षा / मूल्र्ांकन दकर्ा जाएगा। तकनीकी-वाखर्खयर्क बोनलर्ों के मूल्र्ांकन के दौरान, ननववदाकारों द्वारा प्रस्तुत दकए गए दस्तावेजों की ववस्तार से जाँच
की जाएगी। र्दद कोई ननववदा जो पात्रता मानदण्ड पूरा नहीं करती है तो उसे इस चरर् पर अस्वीकार कर ददर्ा जाएगा और ऐसे प्रस्तावों पर आगे ववचार नहीं दकर्ा जाएगा। अलग से
ननददण ष्ट नतनि

(अहण पाएं गए ननववदाकारों को सूचना के साि) पर केवल उन्हीं ननववदाकारों की मूल्र् बोली खोली जाएगी जो संवीक्षा एवं तकनीकी मूल्र्ांकन में अहण पाएं जाएंगे तिा

ननववदा प्रदक्रर्ा/अनुबंिों के अनुसार आगे की प्रदक्रर्ा की जाएगी

4

<!-- page 5 -->

On the due date of opening, the Technical & Commercial bid of those tenderers who furnished valid EMD only will be opened. On opening of Technical &
commercial bid, further detailed scrutiny / evaluation will be carried out. During the evaluation of techno-commercial bids, the documents furnished by the
tenderers will be scrutinized in detail. Any tender, found as not fulfilling the eligibility criteria will be rejected at this stage and such offers will not be
considered for further processing. The price bid of only those tenderers who have been qualified during the scrutiny and technical evaluation will be opened
separately on a specified date (with due intimation to the qualified bidders) and further processed, as per tender procedure/ stipulations.
8.सफल तनतवदाकार के बर्ाना रािी क कार्य –तनष्पादन गारं टी के रूप में बदला जाएगा। कार्य पूरा ह ने पर, उसे प्रततभू तत जमा में बदला जाएगा। बर्ाना रािी से छूट वाले मामले में, स्वीकृतत-पत्र/कार्य आदे ि के प्राखि पर तु रंत तनतवदा के अनुमातनत मू ल्य के 2% रािी की कार्य –तनष्पादन गारं टी अलग से जमा करनी ह गी / Earnest money of the successful contractor will be

converted into Performance guarantee. On completion of the work, the same will be converted as security deposit. In cases of exemption for
payment of Earnest money, separate performance guarantee at 2% of the estimated cost put to tender to be submitted immediately on receipt of
letter of acceptance/ work order.
9.इच्छु क तनतवदाकार समूह प्रर्ान, सी.एम.जी./ प्रर्ान,सी.एम.डी./ इं जीतनर्र-एस.जी./ इं जीतनर्र-एस.एफ./ इं जीतनर्र-एस.ई./ इं जीतनर्र-एस.डी.की पूवय अनुमतत से तनतवदाएँ प्रसतु त करने से पूवय
कार्य सथल का तनरीक्षण कर सकते हैं / Intending tenderers may inspect the site before submitting the tenders, with the prior permission of Group Head, CMG/ Head

CMD/ Engineer-SG / Engineer-SF/ Engineer-SE/ Engineer-SD.
10. भारत के राषटर पतत की ओर से तनतवदा सवीकारकताय प्रातर्कारी नर्ूनतम र्ा क ई अनर् तनतवदा सवीकार करने के तलए बाधर् नही ं है और तबना क ई कारण बताए प्रापत तकसी र्ा सभी तनतवदाओं क असवीकार
करने का अतर्कार रखते हैं । सभी तनतवदाएं तजसमें क ई तनर्ाय ररत ितय पूरी नही ं की जाती है र्ा तनतनतवदाकार औपबं तर्क छूट की क ई ितय रखता है त उनहें तबना तवचार तकए असवीकार कर तदर्ा जाएगा/The

tender accepting authority on behalf of President of India is not bound to accept the lowest or any other tender and reserves the authority to reject any or all
the tenders received without assigning any reason. All tenders in which any of the prescribed condition is not fulfilled or any condition including that of
conditional rebate is put forth by the tenderer shall be summarily rejected.
11. भारत के राष्ट्रपतत की ओर से तनतवदा सवीकारकताय प्रातर्कारी कार्य आदे ि जारी करने से पूवय कार्य क्षे त्र में पररवतय न/कार्य की मात्रा क कम करने का अतर्कार भी रखते हैं और तनतवदाकार इस पर तकसी
भी प्रकार का दावा नही ं कर सकता/The tender accepting authority on behalf of President of India also reserves the right to alter the scope/ or reduce quantum of
work before issue of work order and the tenderer shall not have any claim what so ever on this account.
12. भारत के राषटर पतत की ओर से तनतवदा सवीकारकताय प्रातर्कारी समपूणय तनतवदा र्ा तकसी भाग क सवीकार करने का अतर्कार रखते हैं और तनतवदाकार प्रसतातवत दर पर कार्य तनषपादन करने के तलए बाधर्
ह गा /The tender accepting authority on behalf of President of India reserves the right of accepting the whole or any part of the tender and the tenderer shall

be bound to perform the same at the rate quoted.
13. तनतवदा के सं बंर् में प्रतर्क्ष र्ा अप्रतर्क्ष तसफाररि करने पर सखत प्रततबं र् है और ठे केदार ं द्वारा तसफाररि का सहारा लेते हुए प्रसतु त की गई तनतवदाएं असवीकार की जा सकती हैं /Canvassing
directly or indirectly, in connection with tender is strictly prohibited and the tenders submitted by the contractors who resort to canvassing will be liable for
rejection.
14. ननववदा की स्वीकृततदे ने वाले प्रातर्कारी के पास र्ह अतर्कार सु रतक्षत है तक वह सरकार द्वारा समर्-समर् पर जारी नीततर् ं के अनुसार प्रस्ताव ं की वररर्ता में पररवतय न कर सकता है । /The tender
accepting authority reserves the option to give preferences to the offers in accordance with the policies of the Government from time to time.
15. ठे केदार क तवभाग के उस केंद्र तविेष, ज ठे के क प्रदान करने और तनषपातदत करने के तलए उत्तरदार्ी है , के प्रभाग में कार्य करने हे तु तनतवदा करने की अनुमतत नही ं दी जाएगी, जहाँ उसका तनकट
सं बंर्ी कार्यरत ह । उसे उन व्र्खिर् ं के नाम बताने ह ग
ं े ज उसके साथ तकसी भी है तसर्त में कार्य कर रहे हैं र्ातदु परां त उसके द्वारा तनर्ु क्त तकए जाएँ और ज अं तररक्ष तवभाग में तकसी राजपतत्रत अतर्कारी

5

<!-- page 6 -->

के तनकट सं बंर्ी हैं । ठे केदार द्वारा इस ितय के तकसी भी प्रकार के उल्लं घन पर तनतवदा क असवीकार र्ा सं तवदा क रद्द कर तदर्ा जाएगा / The contractor shall not be permitted to tender for

works in the Division of that particular Centre of the Department responsible for award and execution of contracts for which his/her near relative is working.
He/she shall also intimate the names of persons who are working with him in any capacity or are subsequently employed by him and who are near relatives
to any Gazetted Officer in the Department of Space. Any breach of this condition by the contractor would render him liable for rejection of tender or
cancellation of contract.
16. उपर क्त पैरा 1में तनतदय षट तनतवदा की प्राखि की तनर्त तततथ से नर्ू नतम 120 तदन ं की अवतर् तक तनतवदा वै र् ह नी चातहए। र्तद क ई तनतवदाकार वैर्ता अवतर् के अंदर प्रसताव वापस लेता है र्ातन तवदा
के तकसी भी तनर्म और ितय मेंसं ि र्न करता है ज तवभाग द्वारा सवीकार्य नही ं है त सरकार क तकसी अनर् अतर्कार र्ातन वारण के पूवाय ग्रह के तबना बर्ाना राति जमा का 50% (पचास प्रततित) पूणयतर्ा
जब्त करने की छूट है । साथ ही, तनतवदाकार क कार्य की पुन: तनतवदा प्रतिर्ा में भाग लेने की अनुमतत नही ं दी जाएगी/The tender should be valid for minimum period of 120 days from

the due date of receipt of the tender specified in Para 1 above. If any tenderer withdraws the offer within the validity period or makes any modifications in the
terms and conditions of the tender which are not acceptable to the Department, the Government shall without prejudice to any other right or remedy, be at
liberty to forfeit 50% (Fifty Percent) of the Earnest Money Deposit absolutely. Further, the tenderer shall not be allowed to participate in the re-tendering
process of the work.
17.दर क लागू करने के तलए जीएसटी के रूप में और सं बंतर्त तवतर्र् ं के तहत दे र् लेवी ह ना चातहए। जीएसटी के सं बंर् में क ई भी दावा स्वीकार्य नही ं ह गा। अतः तनतवदाकार ं क जीएसटी सतहत दर
उद् र्ृ त करने की सलाह दी जाती है /The rates should be inclusive of GST as applicable and levies payable under respective statutes. Any claim on

account of GST will not be admissible. Hence, tenderers are advised to quote their rates inclusive of GST.
18.इस संबंि में दकसी भी मद, अंक व शब्द दोनों हे तु जगह व रानश ररक्त छोडना र्ा कोई दर उद्धत
ृ नहीं दकर्ा गर्ा, तो र्ह मान नलर्ा जाएगा दक संववदाकार ने इसके/इनके मदों को
अन्र् मदों में नमला ददर्ा। ऐसे मदों का दर शून्र् माना जाएगा। कार्ण को ववननददण ष्ट रूप में ननष्पाददत करना आवश्र्क है / In the event no rate has been quoted for any item(s),

leaving space both in figure(s), word(s), and amount blank, it will be presumed that the contractor has included the cost of this/these item(s) in other items(s).
The rate for such item(s) will be considered as ZERO. The work will be required to be executed as specified.
19.ननववदा तर् होने पर, सफल ननववदाकार के साि एक करार दकर्ा जाएगा / on concluding the tender, an agreement shall be drawn with the successful tenderer.
20.संववदा शतों के अनुसार, संववदाकार आवश्र्क दस्तावेजों जैसे ईएसआई एवं ईपीएफ पंजीकरर्की प्रनतर्ाँ,वैि ईएमडी इत्र्ादद (ववस्तृत एनआईटी में र्िा उल्लेखखत) अननवार्ण रूप से जमा
करें गे। अननवार्ण दस्तावेज प्रस्तुत नहीं करने पर ननववदा प्रस्ताव ननरस्त कर ददर्ा जाएगा। / As per the conditions of contract, the contractor should mandatorily submit

necessary documents like ESI and EPF registration copies, valid EMD, etc., (as mentioned in detailed NIT) without fail. The tender offers without mandatory
documents shall be rejected.

Sd/समूह प्रिान,सीएमजी/ एसडीएससी शार
GROUP HEAD, CMG/ SDSC SHAR
08623-226085/6083/6420

6

<!-- page 7 -->

ननमाणर् तिा अनुरक्षर् समूह, एसडीएससी शार

CONSTRUCTION & MAINTENANCE GROUP, SDSC -SHAR
श्रीहररकोटा/SRIHARIKOTA-524124, आं.प्र. / A.P.

तकिीकी-िावणस्िक बोली के साथ विम्नवलस्खत दस्तािेजों की स्कैि की हुई प्रवत जर्ा करिा होगा ।
SCANNED COPY OF THE FOLLOWING DOCUMENTS SHALL BE SUBMITTED ALONG WITH TECHNO-COMMERCIAL BID:
1. ननववदाकार वचनबंि (ननववदाकारके हस्ताक्षर एवं मोहर सदहत) / Tenderer Undertaking (with sign and seal of the tenderer).
2. चल रहे कार्ण का संबंनित प्रानिकारी द्वारा जारी कार्ण-आदे श ।Work orders issued by the authority concerned to establish work on hand.
3. कार्ाणनुभव हे तु संबंनित प्रानिकारी द्वारा जारी कार्ण-पूर्त
ण ा प्रमार्-पत्र।
Completion certificates issued by the authority concerned to establish work experience.
(अहण ता मानदण्ड के अनुसार,समान प्रकृ नत एवं तुलनात्मक परीमार् के कार्ण के ननष्पादन का दस्तावेजी प्रमार् / Documentary proof for having
executed the work of similar nature and comparable magnitude as per the eligibility criteria.)
4. ननजी पक्षकारों द्वारा जारी कार्ण पूर्त
ण ा प्रमार्-पत्रों के साि टीडीएस (स्रोत पर कर कटौती) प्रमार्-पत्र भी होने चादहए / Completion certificate for works
issued by private parties shall be supported by TDS (Tax Deducted at Source) certificates.
5. *फॉमेट 1: वपछले 07 वर्षों में पूरे दकए गए कार्ों की सूची / FORMAT 1: List of works completed in last 07 years.
6. पैन/दटन / जीएसटीवववरर् / PAN / TIN / GST details.
7. बर्ाना जमा रािी र्ा (एनआईटी के पै रा 4 में र्िाउखल्लखखत एनएसआईसी र्ा एमएसएमई उद्यम पंजीकरण प्रमाण पत्र) / Earnest Money Deposit or (NSIC
or MSME UDYAM Registration certificate as mentioned in Para 4 of NIT)
8. सभी ई-ननववदाओं हे तु ननववदाकार को पीडीएफ प्रारूप में ईपीएफ एवं ईएसआई पंजीकरर् की प्रनतनलवपर्ाँ जमा / अपलोड करना अननवार्ण है /Tenderer
should submit / upload EPF and ESI registration copies mandatorily for all the above E-tenders.
9. वववरर् सदहत कंपनी का प्रोफाईल / Company Profile with details.
10. अततररि दस्तावेज, र्तद क ई ह त / ADDITIONAL Documents, if any.
र्हत्वपूणािोट/IMPORTANT NOTE:- सीडीआर / डीडी / एफडीआर / टीडीआर / बीजी के रूप में बर्ाना रानश जमा (ईएमडी) का मूल दस्तावेज ई-ननववदा सूचना में दी
गई ननववदा खोलने की ननर्त नतनि व समर् पर र्ा उससे पहले “समूह प्रिान सीएमजी कार्ाणलर्, नसववल अनुरक्षर् अनुभाग, तकनीकी सेवा भवन, कीपाकम, एसडीएससी शार,

श्रीहररकोटा-524124, आं.प्र. रायर्“ के पते पर पहुँच जाना चादहए। डाक पारगमन के कारर् अप्राप्त / दे री के नलए ववभाग खजम्मेदार नहीं होगा। ईएमडी अनित्र्ाग का दावा

करने वाले ननववदाकारों को दस्तावेजी प्रमार् के साि हाडण प्रनत में अपना अनुरोि प्रस्तुत करना होगा जो ऊपर दी गई ननववदा खोलने की ननर्त नतनि व समर् पर र्ा उस से
पहले ददए हुए पते पर पहुंच जाना चादहए। र्दद ननववदा खोलने की ननर्त नतनि व समर् र्ा उससे पहले वैि बर्ाना रानश जमा (ईएमडी) र्ा एनएसआईसी / एमएसएमई /
उद्यम पंजीकरर् की प्रनतनलवप प्राप्त नहीं होती है तो ननववदा ननरस्त कर दी जाएगी।

The original instrument of Earnest Money deposit (EMD) in form of (CDR /DD/ FDR / TDR / BG) shall reach “Office of Group Head
CMG, Civil Maintenance Section, Technical Services Building, Keepakkam, SDSC SHAR, Sriharikota - 524124, AP State” on or
before tender opening date and time as stipulated in e-Tender Notice. The Department will not be responsible for any non/late due
to postal transit. Tenderers claiming waiver of EMD shall submit a request letter in hard copy with documentary proof, which shall
reach to the address on or before tender opening date and time as stipulated above. If valid EMD or copy of NSIC/MSME UDYAM
registration fail to reach this office on or before tender opening date and time, the tender will be rejected.

7
