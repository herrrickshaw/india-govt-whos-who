---
doc_id: "c3f1afcdff1c9bf7"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/fdbed72359fb9da191fe689963f3dee3.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "E-TENDER ENOUIRY NO.11.14/2021.22/PUR/L&G P-Purchase of Centerifuse Machine Electric. BIS Ceftified flS 1223:2001) (Ceuterifuse Electric Gerber Machine)."
date: "2022-10-19"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4f68f815e7b213b1"
---

<!-- page 1 -->

\Eret tTT(f,, tnF[ $IrgCT

866ffis€.ilo13il{
D,eE-i)il.fSF

r".i-I?

z
E-TENDER ENQUIRY
E-TENDER ENOUIRY NO. I 1 ;32I2022-23IPUR/L&G
qRiI rr<D't-gGovernm ent of India
frd gu dfr+rnehi Milk Scheme
qRqftq}oqm/ West Patel Nagar, New Delhi-110008
H${rq/ Telephone No. 20838212 and EPBX 25877204120512061208/209 @xtn - 316)
E-Mail: aso.dms@nic.in
Bcid'/Date z 17 .10.2022

Subject:Sir,

Delhi Milk Scheme is a central Govt. Organization under Ministry of Fisheries,
AH&D engaged in supplying high Quality of Milk and Milk Products to the citizens of
National Capital and invites e-Tender Enquiry for purchase of following material/items
with terms & conditions mentioned below.
DESCRIPTION OF STORES
1. Acid-P-Rosalic A/R Fluka

1.

QTY.
25 GramX 01 Nos.

(Make Sigma)

1

On Line Rates/Offer: Only online offer shall be accepted.

3.

Manual offer shall not be accepted.

4.

Offer Validity: your offer should be valid for a period of 90 days
qrf, ckil{ ?ht erdfu S oq eil-tcr o-r qn t, EEftq qur uv-fr sfwY ii cR-{H ei-qE o-r sds ott
cR-{F orqft urTfu d qrqro fler mT ffi6.ri ftrqr qrqr {"fffiiT *qrq wm d \'f,-qn whilo qs
drr f6 s-6 tfr srd s-itro. qr6 qr sq-d rrr-{ d' sfr tfr fr fl-w Eq qra a qRRqfR-d Erffif o1 sqdl
fuT fr-qT GTetqr qE riff{r d' g-d gcq o.r erBm-flq 2% 6 .* 6 qRfrtfRa ETM, {qf, E{ ffiori

otr

Delivery Period is the essence of the purchase order. Therefore, delivery period may be
mentioned in your offer. Acceptance of material after delivery period will be at the sole
discretion of Competent Authority with or without liquidated damages, which may be
maximum @ 2% of the total value of the contract for each month or part thereof of delay.
Acceptance of material with or without LD charges after expiry of Delivery Period depends
upon sole discretion of GM/ authorized officer of DMS.
6. Payment Terms: Payment shall be made through RTGSIPFMS after receipt, inspection,
and acceptance of material. The supplier is required to send Bank Detail alongwith Bill for

making payment.

'7. Bidders/offers not accepting the terms and condition of this e-tender enquiry are liable to
be rejected.

<!-- page 2 -->

(2)
8.

Price Variation Clause: If any party desires price variation clause, the same may be
clearly mentioned in the offer giving price breakup of offered rate as on date of applying
offer/bid. Request for the price variation shall not be accepted at later stage.

9.

Exemption from EMD/Tender Fee: (a). Micro and Small Enterprises registered (for
relevent category of purchase of material/service) with District Industries centers or
I(hadi and Village Industries Commission or Khadi and Village Industries Board or Coir
Board or National Small Industries Corporation or Directorate of Handicrafts and
Handloom or any other body specified by ministry of Micro, small and Medium
Enterprises are exempted from depositing Tender Fees & EMD. These Firms shall be
given due consideration as per Public Procurement Policy for Micro and Small
Enterprises (MSE) order 2012. Proof of registration as Micro and Small Enterprises for
relevant category may be enclosed.

(b). All manufacturers/sunnliers/Dealears/Bidders are requested to register your
firm immediatelv on GeM i,e. Government e marketplace (sem.gov.in) as it is
mandatory to purchase all goods/materials and services form GeM.
10. E-Tender opening: Tender Enquiry containing terms & conditions can be downloaded

from Central Public Procurement - Portal website i.e. eprocure.gov.in/eprocure/app from
20JA.2022 to 09.11.2022. Your Online Tender offer along with terms & conditions shall

beacceptedupto2:30pmon09.ll.2022andthesamesha1lbeopenedonW.at
2:30 PM.
11. As this is e-Tender Enquiry, bidder is required to obtain Digital Signature Certificate
(DSC) for bidding the above Tender.

kd

d t'laflRn tr'+cr d qFnrFr A srkf,ri eta d eTeftq +i
12. gq srgqq c{ BdK {q qlfr ld-4rE,
Jurisdiction: All disputes arising out of raised on this contract, shall be subject to the
Jurisdiction of court'of union territory of Delhi.

r

13. Short Close: General Manager, Delhi Milk Scheme reserves the right to Cancel/short
close the supply order without assigning any reason thereof. The process of leasing out of

DMS is going on. The contract shall be short closed to the extent of supply (Quantity)
received, if DMS is handed over to external agency or closing of DMS activity.

t4. Duly signed scan copy of your Tender Offer on your letter head with
terms & conditions in (.pdl) and Rate (Inclusive of GST, Freight,
Insurance, Govt Levies etc FOR DMS) in financial bid (.XLS) may be
uploaded/placed appropriately on aforesaid CPP- Portal i.e. eprocure.
gov.in/eprocure/app.
15. You may visit DAHD website i.e. yww.dahd.nic.in

Kindly acknowledge the receipt.

,.,.r*:.' ;;

<!-- page 3 -->

IWs. Garg Chemicals
IWs. S.G, Enterprises
IWs. Bright Lab Enterprises
IWs. Chemco,
IWs. Lab Seles Corporation
M7s. Balajee Sales Corporation
IWs. Karmanya Medicos & Scientific Traders
IWs. Doon Chemicals & Scientific Co.
IWs. Glasil Scientific Industries
IWs. Widsons Scientific Works

Copy to:-

,/

Incharge EDP is requested to publish the above e-Tender Enqury on DAHD website
,/1.
'
i.e. dadf@gov.in.

2. Dy.Manager (QCL)
3. SSK (L&G)
4. General Section
5. Hindi Section for Hindi version.
6. Guard File
7. Office Copy
Copy forwarded to General Manager
