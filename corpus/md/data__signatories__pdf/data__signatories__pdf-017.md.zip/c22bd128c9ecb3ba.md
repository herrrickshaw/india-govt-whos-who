---
doc_id: "c22bd128c9ecb3ba"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/d9686ba155805051824c4c2ad7089f8c.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer & Posting of officers in STS grade of ITS Group A- Ms Bhoomika Gaur, Staff no 21418"
date: "2026-08-18"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cfbabde21a1b7466"
---

<!-- page 1 -->

12-1/2026-STG-I

I/3433223/2026

No. 12-1/2026-STG-I
भारत सरकार/ Government of India
संचार मं ालय/Ministry of Communications
दरू संचार िवभाग/ Department of Telecommunications
संचार भवन/ Sanchar Bhawan

*****
Dated the 18th August, 2026
Office Order
Subject: - Transfer & Posting of officers in STS grade of ITS Group ‘A’ -reg.
Approval of the competent authority is hereby conveyed for transfer &
posting of the following oﬃcer in the STS grade of ITS Group 'A' with immediate
effect:
Sl.
No.
1

Staff
No
21418

2.
follow.
3.

Name (Ms.)
Bhoomika
Gaur

Present place of posting Posting on
transfer
Digital Twin Unit, DoT HQs AS Wing, DoT HQs

The charge report may be furnished to all concerned. Hindi version will

This issues with the approval of the competent authority.

(सुनील कुमार//Sunil Kumar)
अवर स चव, भारत सरकार /
Under Secretary to the Government of India
दरू भाष/Tele: 011-2303 6282
ई-मेल/ Email: us.sgt-dothq@gov.in
Copy to:
1. Secretary, Department of Telecommunications;
2 . Member (Finance), Digital Communications Commission, Department of
Telecommunications;
3. Advisor(O)/ Advisor(T) Department of Telecommunications(Headquarters);
4. Chief Vigilance Officer, Department of Telecommunications (Headquarters);
5. Additional Secretary (Telecommunications)/ Administrator, Digital Bharat Nidhi,
Department of Telecommunications;
6. Heads of Licensed Service Areas/ Telecommunication Engineering Centre/
National
Communications
Academy-Technology/
National
Centre
for
Communication Security;
7. Senior Deputy Director Generals and Deputy Director Generals in the
Department of Telecommunications (Headquarters);
8. Officer concerned;

<!-- page 2 -->

12-1/2026-STG-I

I/3433223/2026

9. Chief Administrative Officer / Drawing and Disbursing Officer concerned;
10. G-I/ G-ll/ Admn-I, II, lll, IV / PHP / Pay Bill / Pension / Cash / STG-I, II Section;
11. Oﬃcial Language Section, Department of Telecommunications, for Hindi
version of order;
12. Order bundle / PA to US(SGT), for uploading the order on the website of the
Department of Telecommunications
