---
doc_id: "c18fff7bb4d8ed6b"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/ce91ea0594812aa80e42b034531e54ab.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Chhattisgarh-Order of panel counsels of High Court of Chhattisgarh At Bilaspur, CAT Circuit Bench Bilaspur"
date: "2017-07-24"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "71d3c1b97cf19b40"
---

<!-- page 1 -->

ह F.No.36(5)/2015-Judl.
Ministry of Law & Justice
Department of Legal Affairs
: Judicial Section
eee
Shastri Bhavan, New Delhi
03" March, 2015
ORDER
In supersession of all earlier orders relating to Central Government Counsel for High Court
of Chhattisgarh at Bilaspur and Additional Central Government Standing Counsel, CAT Circuit
Bench at Bilaspur, the President is pleased to engage the following Advocates as Central
Government Counsel before the High Court of Chhattisgarh at Bilaspur and Additional Central
Government Standing Counsel for CAT, Circuit Bench at Bilaspur for conducting the Central
Government cases with immediate effect for a period of three years or until further orders,
whichever is earlier,
HIGH COURT OF CHHATTISGARH AT BILASPUR
CENTRAL GOVT. COUNSEL
SI. Name & Address Contact No. Enrolment No.
No.
Sachin Singh Rajput 09827164803 316/1996
7-Jitendra —Kunj, shesh colony, L-10, .
Vinoba nagar, Bilaspur, Chattisgarh
2 Raj Kumar Gupta 08085737027 1609/95
New Sarkanda, Jabda Para, Bilaspur,
Chhattisgarh
3 Vinay Kr Pandey 09926135403 486/2001
HIG-II, D-21, Abhilasha Parishar, behind
new Bus Stand, Bilaspur, Chattisgarh
Ramakant Pandey 09755758848 1887/96
Kapil Nagar, Sarkanda, Bilaspur,
Chhattisgarh
5 Surendra Kr Dewangan 09329633946 316/2009
-Katiya Para, Junabilaspur, Chhattisgarh
eee: Sep
roel
कु
*
०”)

<!-- page 2 -->

Anil S Pandey 09827188051 3229/1999
Mahamaya Vihar, Ware house Road,
Bilaspur, Chattisgarh
7 Bhupendra Singh 09826119893 2146/2000
H. N.78, Gitanjali Park, Mahirishi Road,
Mangla, Bilaspur Chhattisgarh
Rajesh Kr. Kesharwani 09425206089 438/1990
GORE-VILLA, MIG-I, 51 B, Abhilasha
Parishar, Tifa, Bilaspur, Chhattisgarh
Rajesh Kr Tiwari 09826162173 576/2003
~Nayapara Chakarbhata, Bilaaspur,
Chhattisgarh
Purnima Singh 09827103393 692/1994
-Choti Railway Crossing, Paras Nagar,
Devendra Nagar, Raipur
Ashawini Shukla 09826367844 155/04
Behind Manlgam Bhawan,Kapil nagar,
Sarkanda ,Bilaspur ,Chattisgarh
CENTRAL ADMINISTRATION TRIBUNAL, CIRCUIT BENCH AT BILASPUR ADMINIS TION TRIBUNAL, CIRCUIT BENCH AT BILASPUR
ADDITIONAL CENTRAL GOVT. STANDING COUNSEL IONAL CENT GOVT. STANDING COUNSEL
Shri Vivek Verma, 9300327395 48/2003
Q.No.11, Shailendra Nagar, Ameri,
Bilaspur, Chhattisgarh
2. The engagement of above advocates will be governed by the terms and conditions
contained in this Department’s OM No.26(1)/99-Judl. dated 24" September,1999 read with OM
No.26(1)/2005-Judl. dated 31* January, 2008.
3. Hindi version of this order will follow. me af. (29
MAREN CC och ०)
(Suresh Chandra)
Joint Secretary & Legal Adviser
To =
All the above advocates.

<!-- page 3 -->

. . 3.
Copy to:-
* |. Shri Narendra Kumar Vyas, Assistant Solicitor General, F-13, Subh Regency, Opposite
High Court, Bilaspur (Chhattisgarh) (M)-0982748531
advanupbose54@gmail.com (M) 09438615773
2. The Register, High Court Chhattisgarh, Bilaspur.
3. The Register, Central Administrative Tribunal, Bilaspur.
4. All the former Central Government Counsel for High Court of Chhattisgarh at Bilaspur
is requested to handover all the pending cases to newly engaged Counsels.
5. Cash (LA) Section w.r.t. payment of retainer fee.
6. PS to ML&J/PS to Law Secretary/PS to Legislative Secretary,
7. Hindi unit for Hindi version of this order.
8. Guard File/Judicial Section with 5 s/copies.
\ A
Li -
(B.S. Sharma)
Superintendent(L)
के मे के ०
‘
