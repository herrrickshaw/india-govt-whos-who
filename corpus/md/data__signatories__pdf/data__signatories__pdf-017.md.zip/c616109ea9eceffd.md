---
doc_id: "c616109ea9eceffd"
source_url: "https://doj.gov.in/static/uploads/2025/09/15c3876e63dbcab2d8fcb91831560219.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Justice Syed Qamar Hasan Rizvi and 08 other Additional Judges of the Allahabad High Court as Permanent Judges of that High Court (21.08.2024)"
date: "2024-08-21"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e30ac7179be58a6e"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)
F. No. K-13012/02/2024-US.I
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 OIl.
Dated 21 st August, 2024.

NOTIFICATION
In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint S/Shri Justices (i) Syed
Qamar Hasan Rizvi, (ii) Manish Kumar Nigam, (iii) Anish Kumar Gupta, (iv)
Ms. Nand Prabha Shukla, (v) Kshitij Shailendra, (vi) Vinod Diwakar, (vii)
Prashant Kumar, (viii) Manjive Shukla and (ix) Arun Kumar Singh Deshwal,
Additional Judges of the Allahabad High Court, to be Judges of that High Court
with effect from the date they assume charge of their respective offices.

(Jagann

Srinivasan)

Joint Secretary to the Government ofIndia
Tele: 23383037
To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

-2-

F. No. K-13012/02/2024-US.I

Dated: 21.08.2024.

Copy to:1.

S/Shri Justices (i) Syed Qamar Hasan Rizvi, (ii) Manish Kumar Nigam,
(iii) Anish Kumar Gupta, (iv) Ms. Nand Prabha Shukla, (v) Kshitij
Shailendra, (vi) Vinod Diwakar, (vii) Prashant Kumar, (viii) Manjive
Shukla and (ix) Arun Kumar Singh Deshwal, Additional Judges,
Allahabad High Court through the Registrar General, Allahabad High
Court, Allahabad.
2. The Secretary to Governor, Uttar Pradesh, Lucknow.
3. The Secretary to Chief Minister, Uttar Pradesh, Lucknow.
4. The Secretary to the Chief Justice, Allahabad High Court, Allahabad.
5. The Chief Secretary, Government of Uttar Pradesh, Lucknow.
6. The Registrar General, Allahabad High Court, Allahabad.
7. The Accountant General, Uttar Pradesh, Lucknow.
8. The President's Secretariat, (CA.II Section), Rashtrapati Bhawan, New
Delhi.
9. PS to the Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
10. Registrar (Conf.), 0/0 the Chief Justice ofIndia, 07, Krishna Menon Marg,
New Delhi.
11. PS to the MoS (l/C) L&J I PPS to the Secretary (Justice).
12. Sr. Technical Director, NIC, Department of Justice, with a request to
upload the notification on the website of the Department
(www.doLgov.in).
\.A,J\~~

VV~_c~-r~

(A~ant Kumar)
Under Secretary (Appointments-II)
Tele: 23383087
