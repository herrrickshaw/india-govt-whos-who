---
doc_id: "c1f4bd8d0d0c8bd1"
source_url: "https://mnre.gov.in/static/uploads/2025/07/db932001a06fdb255664c28927329618.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "12.02.2025 Amendments to Solar PV Standard Bidding Guidelines"
date: "2025-02-12"
pages: 5
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "d65dc1c9c7f84f47"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-15022025-260976
xxxGIDHxxx
CG-DL-E-15022025-260976
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग I—खण्ड 1
PART I—Section 1
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 49]
No. 49]

नई दिल्ली, बुधिार, फरिरी 12, 2025/माघ 23, 1946
NEW DELHI, WEDNESDAY, FEBRUARY 12, 2025/MAGHA 23, 1946

जिद्युत मंत्रालय
संकल्प
नई दिल्ली, 12 फरिरी 2025
जिड संबध
ं ी सौर पीिी जिद्युत पररयोिनाओं से जिद्युत की खरीि हेतु टैररफ आधाररत प्रजतस्ट्पधी बोली प्रदिया के जलए
दििाजनिेिों में संिोधन।
सं. 48-19/2/2024-एनआरई:—जिड संबंधी सौर पीिी जिद्युत पररयोिनाओं से जिद्युत की खरीि हेतु टैररफ
आधाररत प्रजतस्ट्पधी बोली प्रदिया के जलए दििाजनिेि भारत के रािपत्र (असाधारण) (भाग 1 - खंड 1) में 28 िुलाई,
2023 को प्रकाजित संकल्प संख्या 27/01/2023-आरसीएम द्वारा अजधसूजित दकए गए हैं। इसके बाि, उक्त दििा -जनिेि
िमि: 17 निंबर, 2023 के संकल्प संख्या 48-19/2/2023-एनआरई और 2 फरिरी, 2024 के संकल्प संख्या 4819/2/2024-एनआरई के माध्यम से संिोजधत दकये गये हैंI
2. कें द्र सरकार एतद्द्वारा 28 िुलाई, 2023 को अजधसूजित एिम् 17 निंबर, 2023 और 2 फरिरी, 2024 को संिोजधत
उक्त दििाजनिेिों में जनम्नजलजखत संिोधन को अजधसूजित करती है:i.

मौिूिा दििा-जनिेिों के खंड 3.2 के बाि एक नया खंड 3.3 िोडा गया है:
“3.3 स्ट्थान-जिजिष्ट बोजलयों के मामले में, िे ता इं टर स्ट्टेट रांसजमिन जसस्ट्टम (आईएसटीएस) / इं रा स्ट्टेट
रांसजमिन जसस्ट्टम (आईएनएसटीएस) में उप-स्ट्टेिन जनर्ििष्ट कर सकता है, िहां जिकासकताि सौर पीिी जिद्युत
पररयोिना को िोडेंगे।”

ii.

दििा-जनिेिों की धारा 6.6 (ख) को जनम्नानुसार संिोजधत दकया गया है:

1092 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC.1]

“यदि उत्पािक, पररयोिना सीओडी के तुरंत बाि 31 मािि को समाप्त होने िाले पहले संजििा िर्ि को छोडकर
लगातार 2(िो) िर्ों के जलए पीपीए में जनर्ििष्ट न्यूनतम सीयूएफ के अनुरूप ऊिाि आपूर्ति बनाए रखने में जिफल
रहता है, तो उत्पािक की िूक (जडफ़ॉल्ट) होगी। उत्पािक का िार्र्िक न्यूनतम सीयूएफ िाजयत्ि 2 िूक (जडफ़ॉल्ट)
िर्ों के िास्ट्तजिक सीयूएफ के औसत तक कम हो िाएगा और उत्पािक खरीिार को िार्र्िक न्यूनतम सीयूएफ
िाजयत्ि में कमी के जलए 24 (िौबीस) माह या िेर् पीपीए अिजध िो भी कम हो, के टैररफ के बराबर एकमुश्त
हिािना िेने के जलए उत्तरिायी होगा।
बिते दक यदि उत्पािक एकमुश्त हिािना िेने में जिफल रहता है, तो उत्पािक की ऐसी जिफलता को
िूक(जडफ़ॉल्ट) की घटना माना िा सकता है और पीपीए समाप्त दकया िा सकता है। पीपीए की समाजप्त की
जस्ट्थजत में, उत्पािक, िे ता को जनधािररत न्यूनतम सीयूएफ के साथ अपनी संजििा की गई क्षमता के जलए 24
(िौबीस) माह या िेर् पीपीए अिजध िो भी कम हो, के टैररफ के बराबर क्षजतपूर्ति का भुगतान करने के जलए
उत्तरिायी होगा।“
iii.

मौिूिा दििा-जनिेिों के खंड 6.7 को जनम्नानुसार संिोजधत दकया गया है:
“जिजध में पररितिन
जिजध में पररितिन संबंधी प्रािधान जिद्युत (जिजध में पररितिन के कारण लागत की समय पर िसूली) जनयम,
2021 और समय-समय पर िारी दकए गए संिोधनों के अनुसार होंगे। इसके अलािा, जिजध में पररितिन
(“सीआईएल”) िब्ि बोली प्रस्ट्तत
ु करने की अंजतम जतजथ से सात (7) दिन पहले पररयोिना से संबंजधत दकसी भी
घटना के प्रघटना को संिर्भित करे गा”

iv.

खंड 9.2 के बाि नया खंड 9.3 िोडा गया है, और संबंजधत नोट को जनम्नानुसार संिोजधत दकया गया है:
“9.3 सामान्य पररजस्ट्थजतयों में, पीपीए और पीएसए (यदि लागू हो) पर हस्ट्ताक्षर एलओए िारी होने से 30
(तीस) दिनों के भीतर पूरा हो िाना िाजहए। इस अिजध को एलओए की जतजथ से 12 माह तक बढाया िा सकता
है, जिसके बाि एलओए रद्द कर दिया िाएगा।
नोट: यह स्ट्पष्ट दकया िाता है दक यदि खरीिार बोली प्रदिया में दकसी भी घटना के जलए 9.3 के अनुपालन के
अध्यधीन ,जिस्ट्ताररत समय िेता है, तो घटना से पहले पूरी की िाने िाली गजतजिजधयों को प्राप्त करने में िेरी के
कारण, या दकसी अन्य कारण से, समय का ऐसा जिस्ट्तार दकसी भी तरह से इन दििाजनिेिों से जििलन के रूप में
नहीं माना िाएगा। “

v.

दििाजनिेिों की धारा 10.4 को जनम्नानुसार संिोजधत दकया गया है:
"अजधजनयम के प्रािधानों के अध्यधीन, जितरण लाइसेंसधारक या मध्यस्ट्थ खरीिार, िैसा भी मामला हो, इन
दििाजनिेिों के अनुसार आयोजित पारििी प्रजतस्ट्पधी बोली प्रदिया के बाि, ई-ररिसि नीलामी या अन्य के
माध्यम से टैररफ जडस्ट्किरी के 30 (तीस) दिनों के भीतर, अजधजनयम की धारा 63 के अंतगित प्राप्त टैररफ लागू
(एडाप्ट) करने के जलए समुजित आयोग से संपकि करेगा ।"

vi.

बयाना िमा राजि स्ट्थाजपत करने के जलए नया प्रािधान धारा 11.1(क) के बाि जनम्नानुसार िोडा गया है:
“11.1(क1) बीमा ज़मानत बांड (इंश्योरें स जसक्यूररटी बांड) जिसका भुगतान जबना दकसी िति के बैंक गारं टी के
समान दकया िाएगा।
अथिा
कें द्र सरकार द्वारा समय-समय पर संिोजधत सामान्य जित्तीय जनयमों में अनुमोदित कोई अन्य साधन ।
अथिा”

vii.

कायिजनष्पािन बैंक गारं टी की स्ट्थापना के जलए धारा 11.2(क) के पश्चात नया साधन जनम्नानुसार िोडा गया है:
“11.2(क1) बीमा िमानत बांड (इं श्योरें स जसक्यूररटी बांड) जिसका भुगतान जबना दकसी िति के बैंक गारं टी के
समान दकया िाएगा।
अथिा
कें द्र सरकार द्वारा समय-समय पर संिोजधत सामान्य जित्तीय जनयमों में अनुमोदित कोई अन्य साधन ।
अथिा”

viii.

दििा-जनिेिों की धारा 11.3 को जनम्नानुसार संिोजधत दकया गया है:
“अन्य जनिानों के साथ,यह पीबीिी (या इन दििा-जनिेिों के अनुसार प्रित्त जिकल्प) पीपीए के संबंध में की दकन्हीं
क्षजतयों/ उत्पािक द्वारा िेय राजियों की िसूली के जलए भुनाई िा सकती है। यह स्ट्पष्ट दकया िाता है दक पीपीए
के अंतगित उत्पािक की िूक होने पर, पीबीिी को भुनाकर मध्यस्ट्थ खरीििार द्वारा प्राप्त की गई क्षजतयों/िेय

<!-- page 3 -->

[भाग I—खण्ड 1]

भारत का रािपत्र : असाधारण

3

राजियों को इन दििा-जनिेिों के खंड 6.3 के अंतगित मध्यस्ट्थ खरीििार द्वारा प्रबंध दकए िाने िाले भुगतान
सुरक्षा कोर् में िमा दकया िाएगा। पीबीिी (या इन दििा-जनिेिों के अनुसार उपलब्ध जिकल्प) पररयोिना की
िास्ट्तजिक आपूर्ति जतजथ से 45 दिनों के अंिर उत्पािक को िापस कर दिया िाएगा । जिद्युत की आपूर्ति के आंजिक
रूप से िालू करने के मामले में, ऐसी आंजिक क्षमता के अनुसार पीबीिी को िस्ट्तजिक आपूर्ति जतजथ से 45 दिनों
के अंिर िापस(ररलीि) दकया िाएगा।”
ix.

मौिूिा दििा-जनिेिों के खंड 15 को जनम्नानुसार संिोजधत दकया गया है:
“15. तकनीकी जिजनिेि
15.1 प्रौद्योजगकी िोजखम को कम करने और पररयोिनाओं से आपूर्ति के समय परआरं भ करने के जलए खरीििार
िाजणजययक रूप से सुस्ट्थाजपत और प्रिालनात्मक प्रौद्योजगदकयों को बढािा िेंगे। सौर पीिी/ऊिाि भंडारण
प्रणाजलयों के जलए जिस्ट्तृत तकनीकी मापिंड एमएनआरई द्वारा समय-समय पर जनर्ििष्ट दकए गए अनुसार होंगे।
15.2 जिकासकताि संबंजधत कें द्रीय सरकारी एिेंसी द्वारा जनर्ििष्ट तकनीकी जिजनिेिों और मानकों के अनुसार
िीपीएस सक्षम स्ट्ििाजलत मौसम स्ट्टेिन (ए डब्ल्यू एस) को स्ट्थाजपत करे गा और उसका रखरखाि करेगा। ऐसे
एडब्ल्यूएस से आंकडों की उपलब्धता भारतीय जिद्युत जिड कोड के प्रािधानों और समय-समय पर उपयुक्त भार
प्रेर्ण कें द्र से जनिेिों के अनुसार, उपयुक्त भार प्रेर्ण कें द्र और अन्य कें द्रीय सरकारी एिेंजसयों द्वारा जनर्ििष्ट अनुसार
सुजनजश्चत की िाएगी।
15.3 तकनीकी मानिंडों में यह सुजनजश्चत करने के प्रािधान िाजमल होंगे दक जिकासकताि साइबर सुरक्षा से
जनपटने िाले कें द्रीय सरकारी प्राजधकरणों द्वारा िारी लागू साइबर सुरक्षा जिजनयमों, जनिेिों और दििाजनिेिों का
अनुपालन करता है।”

x.

मौिूिा दििा-जनिेिों के खंड 16 को इस जनम्नानुसार संिोजधत दकया गया है:
“इन दििा-जनिेिों का उद्देश्य प्रदियाओं में मानकीकरण एिं एकरूपता लाना है तादक खरीििारी में सत्यत और
पारिर्ििता हो। इस तरह, इन दििा-जनिेिों का बोली प्रदिया में सख्ती से पालन दकए िाने की आिश्यकता है
और जिद्युत अजधजनयम की धारा 63 के तहत, ऊिाि भंडारण प्रणाली के साथ। अथिा उसके जबना पररयोिनाओं से
सौर जिद्युत की खरीि के जलए,दकसी भी बोली को, इन दििा-जनिेिों के जिपरीत, िारी नहीं दकया िाएगा।
तथाजप, यदि खरीिार के जलए इन दििा-जनिेिों से/या एसबीडी से जििलन आिश्यक हो िाता है, तो यह बोली
प्रदिया की िुरुआत होने से पूिि ही समुजित आयोग द्वारा अनुमोिन के अध्यधीन होगा। समुजित आयोग ऐसी
याजिका िायर करने के यथोजित समय के भीतर िो दक 60 (साठ) दिनों से ययािा नहीं होगा, बोली िस्ट्तािेिों
को अनुमोदित करे गा या उनमें संिोधन की िरुरत बताएगा।
बिते दक यदि दकसी बोली के जलए, इन संिोधनों की अजधसूिना से पहले जििलन, पहले से ही उपयुक्त सरकार
द्वारा अनुमोदित हैं, तो उस बोली के जलए समुजित आयोग द्वारा नए अनुमोिन की आिश्यकता नहीं होगी।”
हेमंत कु मार पांडेय, मुख्य अजभयंता (आरएंडआर)
MINISTRY OF POWER
RESOLUTION
New Delhi, the 12th February, 2025

Amendment to the Guidelines for Tariff Based Competitive Bidding Process for Procurement of Power from
Grid Connected Solar PV Power Projects
No. 48-19/2/2024-NRE— The Guidelines for Tariff Based Competitive Bidding Process for Procurement of
Power from Grid Connected Solar PV Power Projects have been notified vide Resolution No. 27/01/2023-RCM
published in the Gazette of India (Extraordinary) (Part1 - Section 1) on 28thJuly, 2023. Subsequently, the said
Guidelines were further amended vide resolution No. 48-19/2/2023-NRE dated 17th November, 2023 and resolution
No. 48-19/2/2024-NRE dated 2nd February, 2024 respectively.
2.
The Central Government hereby notifies the following amendment in the said guidelines dated 28 th July,
2023 amended on 17th November, 2023 and 2nd February, 2024 :i.

New clause 3.3 has been added after Clause 3.2 of the existing guidelines:

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC.1]

“3.3 In case of location specific bids, the procurer may specify the sub-station(s) in Inter-State Transmission
System (ISTS)/ Intra-State Transmission System (InSTS), where the developers will connect the Solar PV
Power Project.”
ii.

Section 6.6 (b) of the Guidelines has been modified as under:
“In the event the Generator fails to maintain energy supply corresponding to the minimum CUF as declared
in the PPA for 2(two) consecutive years excluding the first Contract year ending on 31 st March immediately after
Project CoD, the Generator shall be in default. The Generator’s yearly minimum CUF obligation shall get
reduced to the average of actual CUF for the 2 default years and the Generator shall be obligated to pay to the
Procurer lump-sum damages equivalent to 24 (twenty-four) months or balance PPA period whichever is less, of
the tariff, for the reduction in yearly minimum CUF obligation.

Provided that in case the Generator fails to pay the lump sum damages then, such failure of the Generator may
be treated as an event of default and the PPA may be terminated. In the event of termination of PPA, the
Generator shall be liable to pay to the Procurer, damages, equivalent to 24 (twenty-four) months, or balance PPA
period whichever is less, of tariff for its contracted capacity with the stipulated minimum CUF.”

iii.

Clause 6.7 of the existing guidelines has been modified as under:
“CHANGE IN LAW/ REGULATION
The provisions for Change in law shall be in accordance with the Electricity (Timely Recovery of Costs due to
Change in Law) Rules, 2021 and amendments thereof issued from time to time. Further, the term Change in Law
(“CIL”) shall refer to the occurrence of any event related to the project from seven (7) days prior to the last date
of Bid Submission”

iv.

New clause 9.3 has been inserted after clause 9.2 and the associated note has been amended as under:
“9.3 In normal circumstances, the signing of the PPA and PSA (if applicable) should be completed within 30
(thirty) days from the issuance of the LoA. This period may be extended up to 12 months from the LoA date,
beyond which the LoA will be cancelled.
Note: It is clarified that if the Procurer gives extended time, subject to adherence to 9.3, for any of the events in
the bidding process, on account of delay in achieving the activities required to be completed before the event, or
any other reason, such extension of time shall not in any way be construed as deviation from these Guidelines.”

v.

Section 10.4 of the Guidelines has been modified as under:
“Subject to provisions of the Act, the distribution licensee or the Intermediary Procurer, as the case may be,
shall approach the Appropriate Commission for adoption of tariffs discovered, in terms of Section 63 of the
Act, within 30(Thirty) days of the discovery of the tariffs through e-reverse auction or otherwise, after the
transparent competitive bidding process conducted in accordance with these Guidelines.”

vi.
New instrument for establishment of Earnest Money deposit (clause 11.1) has been added after clause
11.1(a):
“11.1(a1) Insurance Surety Bonds which would be paid unconditionally similar to a Bank Guarantee
OR
Any other instrument approved in General Financial Rules as amended from time to time by Central
Government
OR”
vii.
New instrument for establishment of Performance Bank Guarantee (clause 11.2) has been added after clause
11.2(a):
“11.2(a1) Insurance Surety Bonds which would be paid unconditionally similar to a Bank Guarantee
OR
Any other instrument approved in General Financial Rules as amended from time to time by Central
Government
OR”
viii.

Section 11.3 of the Guidelines has been modified as under:

<!-- page 5 -->

[भाग I—खण्ड 1]

भारत का रािपत्र : असाधारण

5

“In addition to the other remedies, this PBG (or alternatives provided thereto as per these Guidelines) can be
encashed to recover any damages/dues of the generator in terms of the PPA. It is hereby clarified that the
damages/dues recovered by the Intermediary Procurer by encashing the PBG, upon the default of the generator
under the PPA, shall be credited to the Payment Security Fund to be maintained by the Intermediary Procurer
under Clause 6.3 of these Guidelines. PBG (or alternatives provided thereto as per these Guidelines) shall be
returned to the generator within 45 days of the actual commencement of supply date of the project. In case of part
commencement of supply of power, PBG corresponding to such part capacity should be released within 45 days
of the actual commencement of supply date.”
ix.

Clause 15 of the existing guidelines has been modified as under:

“15. Technical Specification
15.1 Procurers shall promote commercially established and operational technologies to minimize the technology
risk and to achieve the timely commencement of supply from the Projects. The detailed technical parameters for
Solar PV/Energy Storage Systems shall be as specified by MNRE from time to time.
15.2 The developer shall install and maintain GPS enabled Automatic Weather Station (AWS) as per the technical
specifications and standards specified by relevant central government agency. Availability of the data from such
AWS shall be ensured as specified by the appropriate Load Dispatch Centre and other Central Government
agencies in accordance with the provisions of Indian Electricity Grid Code and instructions from the appropriate
Load Dispatch Centre from time to time.
15.3 The technical criteria shall include provisions to ensure that the developer complies with applicable cyber
security regulations, directives, and guidelines issued by the Central Government Authorities dealing with cyber
security.”
x.

Clause 16 of the existing guidelines has been modified as under:
“The objective of these Guidelines is to bring standardization & uniformity in processes so that there is fairness &
transparency in procurement. As such, these Guidelines need to be strictly followed in the bidding process and no
bid, under section 63 of the Electricity Act, for procurement of Solar power from the Projects with or without
Energy Storage System shall be issued in contravention to these Guidelines. However, in case it becomes
imperative for the Procurer to deviate from these Guidelines and/or the SBDs, the same shall be subject to
approval by the Appropriate Commission before the initiation of bidding process itself. The Appropriate
Commission shall approve or require modification to the bid documents within a reasonable time not exceeding
60 (sixty) days of filing such petition.

Provided that if, for a bid, the deviations are already approved by the Appropriate Government prior to
notification of these amendments, fresh approval by the Appropriate Commission shall not be required for that bid.”

HEMANT KUMAR PANDEY, Chief Engineer(R&R)

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. GORAKHA NATH YADAVA

Digitally signed by GORAKHA NATH
YADAVA
Date: 2025.02.15 10:26:02 +05'30'
