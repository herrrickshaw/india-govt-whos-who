---
doc_id: "c262ffc1ccff18ba"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/03c31c342e7aa52de1540ebac75d09eb.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Inviting nominations for the constitution of National Working Group-3 corresponding to ITU-T Study Group-3 for the Study Period 2025-2028"
date: "2025-01-08"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e2042b4ef6c0d409"
---

<!-- page 1 -->

Government of India
Ministry of Communications

Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi-11001

Training Finance Wing
No. 12-1/2024-Trg.Fin

Date:08-01-2025

Subject: Inviting nominations for the constitution of National Working

Group

(NWG)-3

corresponding

to ITU-T

Study

Group-3

regarding

International Telecommunication/ICT Policy and Economic issues
and Tariff and Accounting matters, for the Study Period 2025-2028.

ITU T Study Group 3 is responsible, inter alia, for studying
international telecommunication/ICT policy and economic issues and tariff
and accounting

matters (including costing principles and methodologies),

with a view to informing the development of enabling regulatory models
and frameworks. Study Group 3 also studies the economic and regulatory
impact of the Internet, new and emerging technologies, convergence
(services or infrastructure) and new services, such as over-the-top (OTT),

on international telecommunication services and networks.
2t

Major subject currently being studied under SG-3 include« Study of economic and policy factors (including Network Slicing in the
International Telecommunication Ecosystem, Guidelines on Tariff and
regulatory aspects of Internet of Things etc.) relevant to the efficient

provision of international telecommunication services
« Development of charging and accounting/settiement mechanisms for
current and future International Telecommunication/ICT Services and
Networks;
« Competition

economic
Networks;
« Economic

policy

aspects
and

and

of

policy

relevant

market

definitions

International

Telecommunication

aspects

Big

of

Data

and

related

to

the

Services

and

Digital

Identity

in

International Telecommunication Services and Networks;
« International Mobile Roaming Issues (including charging, accounting and
settlement mechanisms)

and roaming at border areas;

e Economic
and
policy
issues
telecommunication/ICT services and
Financial Services (MFS); etc.

pertaining
to
international
networks that enable Mobile

<!-- page 2 -->

3.
(NWG)

Corresponding to the ITU-T (SG-3), a National Working Group
is to be constituted under the Chairpersonship of Member (F),

DCC, for the new Study
build consensus, harmonize

Period 2025-2028. NWG shall strive to
the interests of various stakeholders, and

proactively make necessary contributions for the SG-3. Accordingly,
nominations are invited for the membership of the NWG-3. Tentative

composition of the NWG

is attached as Annexure A to this Notice. It is

expected that members would either bring new ideas or contribute to the
ongoing studies in SG-3.

4.
Nominations may be sent by email to dir-trgfin-dot@gov.in by 15 th
January 2025.

This is issued with the approval of the Chairperson, NWG.

)/

o

(Nandlm Palat)
Director (Trg.Fin)

Ph. No.:- 23036059
Email id: dir-trgfin-dot@gov.in

All Stakeholders through DoT Website

<!-- page 3 -->

Annexure A

Tentative Composition of NWG (SG-3)

Number

Designation

Members Representing TEC
Members

kNN

DoT
NCA-F
TRAI
Industry
Academia

(elwlwk

Representing
Representing
Representing
Representing
Representing

Representing ITU-APT Foundation of India (IAFI)

Members Representing Telecommunications Standards
Development Society India (TSDSI)

PR

O

o (N[O

Vs

w|N

|-

of Posts
Vice-Chair
Members
Members
Members
Members
Members

<!-- page 4 -->
