---
doc_id: "c38d6717debbeba0"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/da8ffd8fcdb2e301731d60beff60705e.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment of Recruitment Rules at Central Institute of Psychiatry (CIP) Ranchi, Post of O T Instructresses"
date: "2017-10-31"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "39f85fea46d1f192"
---

<!-- page 1 -->

-r

GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE

Public Notice on draft Recruitment Rules for the post of O.T. tnstructresses in Central lnstitute

of Psychiatry, Ranchi.

ln compliance of DoPT's OM No. AB.14O77l6ll2118-Estt. (RR) dated 13.10.2015, the
draft Recruitment Rules for the post of O.T. lnstructresses in Central Institute of psychiatry,
Ranchi is annexed.

The stakeholders interested in making any objections/comments or suggestions on
the draft Recruitment Rules may do so in writing, within a period of 30 days from the date of
publication of draft Recruitment Rules to Sh. Ajaya Kumar Kp, Under Secretary, Ministry of
Health and Family Welfare, Room No. 521-A, Nirman Bhawan, Maulana Azad Road, New Delhi

- 110108 or e-mail address: aiava59@gmail.com.

(Ajaya Kumar KP

Under Secretary to the Govt. of tndia

Tele:011-23061342
New Delhi
Dated:

<!-- page 2 -->

S.No

As per Schedule

Provision in existing

Revised

Reason tot

RRS

Provisions in
Proposed RRs
o.T.
lnstructresses
1+ (subject to

changes.

1.

Name of Post

O.T. lnstructresses

2.

No. of Posts

2

variation
dependent on
work load)
3. Classification
General Central GeneralCentral
Service Classlv post Service "C", NonNon-Gazetted, Non Gazetted, Non
Ministerial
Ministerial
4. Scale of Pay (Now pay 2"" cPc- 110-3-131
level 2 of pay
in pay matrix)
3'd cPc - 260-326- matrix
EB-8-350

(Rs.19900)

4'h cPc - 950,20-

Whether selection

of DoPT No.
AB,

.Grh cPc PB-1 Gp-

-Estt(RR) dated
7.10.2009.

L4017 /32/2@9

7th cPc- level 2 of
PaY matrix
Not Applicable

post

Age limit for direct
recruits

Replacement

as per 7rh cPc
pay matrix and
also Model RRs

115GEB-25-1500
- s-5 (305075-3950-80-4590)

post or non-selection
6.

been lapsed

srh cPc

Rs.1900

5.

One post has

25 years

Between 18 and
25 years

(relaxable for
Govt. Servants
upto 5 years in
accordance with

instrudions
issued by the
Central

6overnment).
Note: The crucial

date for direct
recruitment for
determining the
age limit shall be

the closing date
of receapt of
application from

<!-- page 3 -->

S.No

At per Schedule

Provision in existing

Revised

Reason for

RRs

Provisions in
proposed RRs

changes,

the candidate in

lndia (and not
the closing date
prescribed for
those in Assam,
Meghalaya,
Arunachal
Pradesh,

Mizoram,
Manipur,
Nagaland,

Tripura, Sikkim.
Ladakh division
of lammu and
Kashmir state,
tahaul and Spiti
District & Pangi
Sub-Division of
Chamba District

of Himachal
Pradesh &

Andaman &
Nicobar lsland
and
LakshadweeD)
7.

(i)Practical training l.Matriculation
qualification required in the trade for 3 2.Practical
Educational and other

for direct recruits

years

{ii)Middle School

traininB in the
trade for 3 years

standard of teneral
education desirable
8.

Whether age and

Matriculation

NO

Not Applicable

2 years

2 years

recruits will apply in

1C

of oirect- 100%,
recruitment: whether By Selection- Nil
by direct recruitment Seniority-cum,
or by promotion or by Fitness - Nil
deputation or by Transfer- Nil
Method

absorption and

qualification
for a Group 'C'

Post must be

educational
qualifications
prescribed for direct
the case of promotes
9. Period of probation, if

Minimum
educational

100% by direct

recruitment

<!-- page 4 -->

S.No

As per Schedule

percentage

of

Provision in existint

Revised

Reason lor

RRs

provisions in

changes.

Proposed RRs

vacancies to be filled
by various methods.
11

ln case of recruitment
promotion/
by
deputation/

Not Applicable

absorption grades

from

which
promotion/deputation

/absorption to

be

made

1i

lf a Oepartmental

Not Applicable

Promotion Committee
exists, what i5 its
composition.
1:

Circumstances in
which Union Pqblic
Service Commission is
be consulted in
making recruitment

to

NotApplicable
