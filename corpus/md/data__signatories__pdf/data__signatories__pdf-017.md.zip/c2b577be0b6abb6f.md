---
doc_id: "c2b577be0b6abb6f"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/06/2767c0b87846c122a93af3c4275299b2.pdf"
ministry: "Tourism"
title: "Tender for inviting bids for construction of India Pavilion at International Luxury Mart, 2019, China."
date: "2019-09-16"
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c14a3990a1b5c417"
---

<!-- page 1 -->

( India Tourism Beijing
| TENDER DOCUMENT
TENDER/ILTM
| Dated: 02/09/2019
Invitation of Bids for Construction of India Pavilion at International
Luxury Travel Mart, 2019, China:

India Tourism Office in Beijing would be participating in Int'l Luxury
Travel Mart, China from October 30 to November 01, 2019. The primary
objective of participation in this fair is to depict India as a destination
for travel and to provide a platform for Indian Tour Operators, Travel
Agents, Hoteliers, Airlines and State Governments to showcase their

| tourism products.

This office requires the services of a professional agency with
previous experience of handling work of similar nature at international
fairs and exhibitions for conceptualization, designing and construction
of the India Pavilion and providing other related ancillary services
during the forthcoming Travel Shows in China.

The details of the shows are as under:

Name of the | Location of | Month of | No. of | Area (in sq.

Show the Show the Show approx co | m)
exhibitors

Intl = Luxury | Shanghai Ochs@ = 14 36

Travel Mart Nov. Ol,

ILTM 2019

A. SCOPE OF WORK

Concepiualization, designing and construction of India Pavilion and

provide other related ancillary services for the Beijing International

Tourism Exposition.

B. SPECIFICATIONS AND ANCILLARY REQUIREMENTS

(1) The “Incredible India” branding should be prominently displayed at

a height (either as hanging from ceiling on a truss or at maximum

permissible height built up from bottom).

(2) The India Pavilion will have individuals table of each 3 to 4 sq.mir. for

co pariicipanis in the Pavilion (No. of table can be adjusted).

<!-- page 2 -->

। (3) The Pavilion should essentially reflect an Indian décor and ambience
with, a professional, business type lay out which is conducive for
conducting buyer — seller meetings and effective Incredible India
branding.
(4) There should be easy accessibility and visible, double sided signage
for all participants / co-exhibitors in the Pavilion.
(5) The pavilion should have:

e Visible and prominently located Reception area at the entrance.

e Alounge comfortable enough to hold press interviews, meetings.

e Individual storage place for all participants / co-exhibitors as well
as a separate larger, covered storage area.

e Well located and visible / easily accessible information counters
and office space.

e A Pavilion plan display in four corners of pavilion indicating the
placement of booths with booth numbers, for facilitating visitors
and business contacts of the co-exhibitors.

e Internet connectivity and individual electric connections.

e Visible fascia for all co — participants.

(6) All photos/images of Incredible India to be displayed as per our
instruction. No duplication of photos/images

(7) Supply of LED Screen and facility to play the Incredible India videos
through Thumb drive.

(8) The space earmarked for common facilities will be restricted to 25 %
of the total area of the Pavilion, whereas 75 % of the area of the Pavilion
will be for booths / areas for co - participants in the Pavilion.

The scope of work will cover providing plants to add a green touch
to the Pavilion, electrical fittings in the pavilion and in all booths of
co-exhibitors as per requirements, as well as daily cleaning of the
pavilion during the course of the exhibition.

(9) The scope of work will also include construction of the pavilion at
site well in time, maintenance activities during the event and
dismantling of the pavilion after the event.

C. GUIDELINES FOR SUBMITTING TENDERS

The tender for construction of India Pavilion at Int'l Luxury Travel Mart
should be submitted in two covers as follows:

Cover-l: Super scribing “Indiatourism Beijing, Travel Shows Technical
Bid”.

To include the following documents / details:

a) Details of the Tender

(i) Profile of the Agency / Company.

(ii) | Details of Technical Manpower and Staff available in — house
outsourced.

<!-- page 3 -->

| Track record - details of involvement in similar events past
| experience.
| b) The technical bids will be judged following the criteria as detailed
below.
(i) Overall Concept / | 50 Marks
Theme and layout of | A. Concept & Design — 25 Marks
the India Pavilion B. Effective Utilization of Space-10
Marks
C. Effective branding — 15 Marks
क्‍ Pavilion and the event
| (iii) Layout of other facilities |} 10 Marks
| & display in India Pavilion,
other attractions etc.
कि
Cover — 2: Super scribing “Indiatourism Beijing, Travel Shows Financial
Bid”.
To include the following documents / details:
1. A Financial Bid, duly dated and clearly indicating the cost against
_ the following heads. . |
(a) Construction, maintenance & dismantling of the pavilion.
(0) Booth management fee, electricity fee & etc requested
& charged by organizing committee.
(c) Expenditure on other activities as listed in the scope of
work above.
(0) Taxes
All bidders should indicate the total cost, inclusive of construction,
transportation, dismantling and any other activities as laid down under
the scope of work. The financial bids will be evaluated on the basis of
total cost (exclusive of faxes).
2. The financial bid (format is attached) should be in RMB.
3. Terms of Payment: No advance payments will be made. Payment
will be made to the successful bidder after completion of event and
receiving the copy of invoice by this office along with photographs of
the India pavilion in different angles.
4. The taxes should be mentioned separately
e This office will make payments only in RMB ( Chinese currency)
e Company should have their bank account in mainland China.
e Any bank transfer will not make outside of mainland.

<!-- page 4 -->

India Tourism will transfer only main company that will have their company
account in mainland china only.
| The two sealed covers, super scribing “Indiatourism Beijing, Travel Shows
Technical Bid” and “Indiatourism Beijing, Travel Shows Financial Bid”
in Covers | and Il respectively should be put up in a separate cover
super scribing “Technical and Financial Bid for Indiatourism, Travel
Shows” and detailing Full Name, Postal Address, Fax, E-mail, Telephone
number of the Tender on the bottom left corner of the cover and
submitted to the Assistant Director, Indiatourism, Beijing, 709, East Tower,
LG Twin Towers, B-12, Jianguomenwai Avenue, Chaoyang District,
Beijing 100022 Tel: +86-10-65686294 before 1600 hrs. on 16/09/2019.
D. SELECTION PROCEDURE
A Constituted Committee will evaluate the Technical Bids received on
the basis of criteria detailed in Section C. While Technical Evaluation
will carry a weightage of 70 marks. The financial bids will carry a
weightage of 30 marks. The agency which scores the highest
aggregate marks on the basis of technical and financial bids (after
adding the scores from the technical and financial evaluation) will be
| awarded the contract for construction of the India Pavilion at the
event.
E. ADDITIONAL INFORMATION
|, Indiatourism, Beijing office reserves the right to reject or accept
any office/bids without assigning any reasons whatsoever.
Il. Incomplete and conditional bids will be rejected outright.
lll. Bids received by email/fax or other means will not be accepted.
IV. Jurisdiction: The contract shall be governed by the Laws of India
ce (Sushil Kumar Singh
ai हल
Assistant Director
India Tourism, Beijing

<!-- page 5 -->

4 s EE 5 वक्ष LE
Financial Bid for Construction of India Pavilion at International Luxury
Travel Mart 2019:

Company:

Contact Person:

Tel:

Email:

Address:

Seal with signature:

Date-Month-2019

oe _—

Booth Construction, maintenance, |

& dismaniling

Booth Management Fee, electricity

fee & etc requested & charged by

organizing committee

Expenditure on other activities as

listed in the scope of work

हि o
—_—- |
