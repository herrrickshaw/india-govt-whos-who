---
doc_id: "c1a4dbe28c9f9b2d"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/vcdaic.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "Vacancy Circular for the post of Financial Advisor, DAIC"
date: ""
pages: 9
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "cfefab8c71ae827f"
---

<!-- page 1 -->

File NO.DAIC-11011/3/2U022-DAIC-ADMIN.
E-Office No.48155:
F.No.11011/DAIC/Admn
Dr. Ambedkar International Centre
Department of Social Justice and Empowerment
Ministry of Social Justice and Empowerment
Govt. of India
15, Janpath, New Delhi
Dated the, 1/8 January, 2022
CIRCULAR
Applications are invited for filling up of the following post in the Dr. Ambedkar
International Centre, Ministry of Social Justice and Empowerment, New Delhi-
110001, on deputation basis from suitable candidates who fulfill the eligibility
conditions as shown below:
310०. Name of |No. of | Pay Scale (Rs.) Eligibility Conditions
Post | Posts
1. Financial Pay Band 4, 37400-\Officers under the Central /or State!
dvisor 7000 + GP Rs. 8700|Govt./Union Territories/ Universities/
Pre revised|Recognized Research Institutions /|
presently itis under [Public Sector
Level — 13 as per |Undertakings/Autonomous, semi
th Central PayjGovt. or Statutory Organizations etc.
ommission). ()Holding analogous posts
Pay Band—4 (Rs. Rs. 37400-
67000) with Grade Pay of Rs.
8700 on regular basis);( Level
13) or
(ii)With five years’ regular|
service in the posts Pay Band-
3 (Rs. 15600 - 39100) with
Grade Pay of Rs. 7600 or
equivalent; or
(iii)With ten years' regular
service in the posts Pay Band-
3 (Rs. 15600 — 39100) with
Grade Pay of Rs. 6600 or
equivalent.
b) Possessing the Following
ducational qualification, experience
Bachelor Degree in any subject from
la_ recognized University with 15

<!-- page 2 -->

File No.DAIC-11011/3/2022-DAIC-ADMIN.
|| SS
dministrative/academic/managerial
xperience.
IDesirable—Experience of accounts)
related/financial advice work.
Preference will be given to the
fficers from any Indian Account
ind Audit services.
2: Period of deputation including in another ex-cadre post held immediately
preceding this appointment in the same organization / department shall ordinarily not
exceed three years. The maximum age limit for appointment by deputation shall not
be exceeding 56 years as on the closing date of receipt of application.
3. The pay of the officer selected will be regulated in accordance with DoPT & OM
No. 6/8/2009-Estt. (Pay-ll) dated 17.06.2010, as amended from time to time.
4. The selected officers will be on deputation for a period of three years initially
which can be curtailed or extended further, depending upon the requirement and with
the consent of the officer and approval of the leading department. The usual
deputation terms will apply.
5. The application in the enclosed proforma (can be down loaded from the official
website of DAIC i.e. daic.gov.in and the official website of Ministry of Social Justice
and Empowerment i.e. socialjustice.nic.in) from eligible officers who can be spared
in the event of the selection may be forwarded through proper channel to the
undersigned on or before 15 March, 2022 / 30 days from publishing in
Employment News Paper which ever is earliest, with (a) up-to-date ACR Dossiers
of the candidate concerned or attested photocopies of the annual confidential reports
for the last five years; (b) Vigilance Clearance Report clearly indicating that no
disciplinary or criminal proceedings are either pending or contemplated against the
officer concerned; (c) Statement showing the minor/major penalties imposed, if any,
and (d) Integrity Certificate.
6. Recruitment Rules (RR) for the post of FA is attached at page 9-10. In case of
any Queries/Clarification the details given at RR shall be considered as final.
7. Application in the prescribed format (As per Annexure- |, II, Ill, IV, and V) may n=
be submitted in the O/o Director, Dr. Ambedkar International Centre, 2™ Floor, 5B UUC«SN
Janpath, New Delhi-110001. /
a ikas Trivedi)
Director, DAIC
To:
1. All Ministries / Department of Government of India. विकास दि vikas TRIVEDI
Dr Ambodear I ene Oe
Mts of Secs Ree ae
istice & Empowerment
Govt of incia, New Boi

<!-- page 3 -->

File No.DAIC-11011/3/2022-DAIC-ADMIN.

2. All Chief Secretaries States/ UTs.

3. All Central / State Universities or Institutions.

4. CGDA, Office of the CGDA, Ulan Batar Road, Palam, Delhi Cantt. — 110010.

5. Controller General of Accounts, Office of Controller General of Accounts,
Ministry of Finance, Lok Nayak Bhawan, Khan Market, New Delhi-110002.

6. Director General of Audit (Central Expenditure), Office of the Director General
of Audit (Central Expenditure). Room no. 206, 2"? Floor, AGCR Building, I.P.
Estate, New Delhi-110002.

7. Comptroller and Auditor General of India, Office of the Comptroller and Auditor
General of India, Pocket-9, Deen Dayal Upadhyaya Marg, New Delhi-110124.

8. Director (CS), DoPT, Lok Nayak Bhawan, Khan Market, New Delhi- with the
kind request to upload this circular on DoPT’s website for wider Circulation.

9. Employment News, Ministry of Information and Broadcasting, East Block-lV,
Level-5, R.K. Puram ——

faora fast / VIKAS TRIVEDI
निदेशक / Director
डॉ. अम्बेडकर अंतर्राष्ट्रीय केन्द्र
Dr, Ambedkar International Centre

सामाजिक न्याय और अधिकारिता मंत्रालय
Ministry of Social Justice & Empowerment

saree Teeny, ad feet

Govt. of India, New Delhi

<!-- page 4 -->

File No.DAIC-11011/3/2022-DAIC-ADMIN.
ANNEXURE-!
Application Form for the Post of FA, DAIC/ Form for the Post of FA, DAIC/f af

1. Name and address (In BLOCK LETTER):

2. Applied for the post of

3. Date of Birth (DD/MM/YY):

4. Whether belong to SC/ST:

5. Gender:

6. Date of retirement under Central/state Government rule:

7. Contact Number:

8. E-mail id:

9. Qualification / and Experience Required as per format given below:
Qualifications Required as per Advertisement|Qualifications possessed by the Officer
Essential
Desirable
Experience Required as per Advertisement Experience possessed by the Officer
Essential
Desirable

11 (a) State clearly in light of entries made by you at para 11 above weather you

qualify for post applied: Yes / No.

12.Details of employment, in chronological order (enclose a separate sheet,

duly authenticated by your signature, if the space below is insufficient
OFFICE/ IPOST HELD IFFROM AY IN THE ATURE OF
INSTITUE/ ND SERVICE/ IPAY BAND/DUTIES
ORGANISATION CADRE TO WHICH RADE PAY
IBELONG AS PER 6th CPC|
AND PAY LEVEL|
S PER 7th CPC
(1)
13.Nature of Present employment, i.e.:

<!-- page 5 -->

File NO.DAIC-11011/3/2022-DAIC-ADMN.
i. Ad-hoc or Contract basis :-
ii, Regular / Permanent or on Temporary basis :-
ili. Basic Pay as per the pay band / Cell and Level as per 7CPC:-
iv.Grade pay as per 6 CPC / Pay level as per 7 CPC drawn:-
14.Additional details about present employment, please state whether
working under:
i. Central Government
ii, State Government
iii. Autonomous Organization
iv.Government Undertaking
v. Universities
15.In case the present employment is held on Deputation/contract basis,
please state:
i. The date of initial appointment
ii, Period of appointment On deputation/contract
iii. Name of the parent office/organization to which you belong
16.Are you in Revised Pay Structure? If yes, give the date from which the
revision took place and also indicate the pre-revised scale.
17.Total emoluments per month now drawn;-
18.Name of Indian Account and Audit service / State Account service/
Government Account Service to which belong:-
19.Details of Duties of Financial Advisor in a Govt Organisation done in the
past ( Period and Name of the Govt Organization:-
20.Additional information, if any, which you would like to mention in support
of your suitability for the post (Enclose a separate sheet, if the space is
insufficient)
It is certified that the above information is / are to the best of my knowledge, In
case of any concealment/ suppression of facts and any information found false
at later stage during the course of selection process. I shall be held responsible
and action as per law may be initiated against me .
(Signature of Candidate)
Date:
Place:

<!-- page 6 -->

File No.DAIC-11011/3/2022-DAIC-ADMN.
ANNEXURE-II
Vigilance Clearance Certificate

Certified that no Vigilance Case of disciplinary proceedings or criminal proceedings is
either pending or contemplated against
who has applied for the post of

eee Te Se कफ नम in Dr.

Ambedkar International Centre, 15, Janpath, New Delhi-110001 on deputation basis.
(Authorised Signatory)

Name & Office Seal:

Date:

(Not below the rank of Deputy Secretary)

<!-- page 7 -->

File No.DAIC-11011/3/2022-DAIC-ADMN.
ANNEXURE-III
Integrity Certificate

After scrutinizing annual Confidential Report/ Annual Performance Appraisal reports
of who has applied for the post of
in Dr.
Ambedkar International Centre, 15, Janpath, New Delhi-110001 on deputation basis,

is certified that his / her integrity is beyond doubt.
(Authorised Signatory)
Name & Office Seal:
Date:
(Not below the rank of Deputy Secretary)

<!-- page 8 -->

File No.DAIC-11011/3/2022-DAIC-ADMN.
ANNEXURE-IV
ACR Documents (Duly Signed by Concerned Authority)

Copy of last 5 years ACR of — Shri / Ms. 7 Mrs.
who has applied for the post of

SFE (अमन कं पम्प in Dr.
Ambedkar International Centre, 15, Janpath, New Delhi-110001 on deputation basis,

is enclosed herewith.

(Authorised Signatory)

Name & Office Seal:

Date:

(Not below the rank of Deputy Secretary)

<!-- page 9 -->

File No.DAIC-11011/3/2022-DAIC-ADMIN.
ANNEXURE-V
No Penalty Certificate

Certified that no minor / major penalty has been imposed during the last 10 years on

who has applied for the post

of in Dr.

Ambedkar International Centre, 15, Janpath, New Delhi-110001 on deputation basis,
is enclosed herewith.

(Authorised Signatory)

Name & Office Seal:

Date:

(Not below the rank of Deputy Secretary)
