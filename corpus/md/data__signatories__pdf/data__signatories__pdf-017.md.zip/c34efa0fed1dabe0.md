---
doc_id: "c34efa0fed1dabe0"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_6ab60ea3bc18b8.33962322.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Offer of appointment - Shri Sandeep Sharma, IFS (HP:2012) appointment to the post of AIGF, MoEFCC, New Delhi on deputation basis under the Central Staffing Scheme of Ministry of Environment, Forest and Climate Change (CSS-MoEF&CC), offer dated 24-09-2026"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b1603d032ccc8e32"
---

<!-- page 1 -->

BY SPEED POST
No: 12026/05/2025-IFS-| [E- 286617]
Government of India

Ministry of Environment, Forest and Climate Change
6" Floor, Prithvi Wing,
Indira Paryavaran Bhawan,
Jor Bagh Road, New Delhi - 110 003.

oa
Dated: 2.५४ September, 2026.

To

The Chief Secretary

Government of Himachal Pradesh

Shimla
Sub: Appointment of Shri Sandeep Sharma, IFS (HP:2012) to the post of AIGF,

MoEFCC, New Delhi on deputation basis under the Central Staffing Scheme of
Ministry of Environment, Forest and Climate Change (CSS-MoEF&CC) -regarding
Sir,

1 am directed to inform that with the approval of the competent authority, Shri
Sandeep Sharma, IFS (HP:2012) has been selected for appointment to the post of AIGF,
MoEFCC, New Delhi on tenure deputation basis under the Central Staffing Scheme of
this Ministry on the following terms and conditions:

(i) He will draw pay as per the scale allowed by the Cadre Controlling Authority

plus allowances as applicable to that grade.

(ii) The central deputation tenure of the officer will be for 04 years from ihe date

of joining the post.

(iii) The headquarters of the post will be at New Delhi; however, the services of

the officer can be utilized anywhere in India.

(iv) Other terms and conditions will be the same as applicable to the other

officers of his grade on deputation to the Central Government and as per CSS-

MoEF&CC.

2. The Government of Himachal Pradesh is, therefore, requested to relieve the
officer with the direction to take up ihe new assignment.
Yours faithfully,
धर
“कह ०
/४०4 ४6
(Phalguni Banerjee)
Under Secretary to the Government of India
Ph. No. 011-20819192
Copy to:
1. PS to Hon’ble Minister, Environment, Forest and Climate Change.
2. PS to Hon'ble Minister of State, Environment, Forest and Climate Change.
3. PPSs to Secretary (EF&CC)/ DGF&SS/ ADGF (WL)) ADGF (FC)/ ADGF (NTCA)/
CEO (CAMPA).
4. The Principal Secretary (Forests), Government of Himachal Pradesh, Shimla.
5. PCCF & HoFF, Government of Himachal Pradesh, Shimla.
