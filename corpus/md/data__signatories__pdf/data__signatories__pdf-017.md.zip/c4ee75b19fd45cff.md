---
doc_id: "c4ee75b19fd45cff"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/c35c8ece7c7b1b01de050fb446e14b57.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of short code '155261' to Department of Agriculture, Cooperation and Farmers Welfare"
date: "2019-11-11"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f9afc49befb00f27"
---

<!-- page 1 -->

File No.16-1/2017-AS-IIl/ShortCodes
Government of India
Ministry of Communications
Department of Telecommunications
. Access Services Wing
20, Ashoka Road, New Delhi-110001
No.16-1/2017/AS-III/Short codes/294/ / ५ 9 6 / Dated: |! /11/2019
To,
All Access Service Providers.
Subject: Allotment of short code ‘155261’ to Department of Agriculture,
Cooperation and Farmers Welfare, Government of India.

The undersigned is directed to convey the approval for allocation of short code
‘155261’ to Department of Agriculture, Cooperation and Farmers Welfare, Government of
India for Pradhan Mantri Kisan Samman Nidhi Yojana (PM-KISAN) with features as:

(i) Category-I: Service (i.e. mandatory service to be provided by all the Access
providers).
(1) Accessibility: Un-restricted i.e. available on STD also.
(iii) Metered service: (It may be taken as Called Party Pays or Calling Party Pays
depending on intimation, to this effect, issued by the agency to which this short
code is allocated in furtherance to this DoT instruction).
2. This is issued with the approval of DDG (AS).
3.  Allare requested to take necessary action.
८22 _ pis
(RK. Soni)
Director (AS-III)
Tel.:011-23711909
Copy forwarded for information and necessary action, if any, to:
1. Secretary, TRAI.
2. CMD MTNL/ CMD BSNL.
3. The Director (FWS), Ministry of Agriculture and Farmers Welfare, Department of
Agriculture, Cooperation and Farmers Welfare, Farmers Welfare Division, 247, Krishi
Bhawan, New Delhi in w.r.t your letter dated 07-11-2019, with a request to appoint a nodal
officer to implement the helpline. The Nodal officer may contact Sr. DDG (LSA), LSA
Unit, Delhi.
4. Director (P&N), DoT (HQ), (respective LSA field unit may be asked to co-ordinate
with respective Nodal Officers and TSPs for implementation of Helpline, as and when
approached).
5.  Acopy for upload on DoT Website
