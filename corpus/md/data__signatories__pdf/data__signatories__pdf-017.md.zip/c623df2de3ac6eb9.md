---
doc_id: "c623df2de3ac6eb9"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/710368f1a25cfdace9b941ea46cbfed6.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 28.01.2025: Engagement of three Advocates as Sr. Arbitration Counsel for conducting arbitration cases before the Arbitrators at Delhi"
date: "2025-01-28"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b8fd34743c3115fb"
---

<!-- page 1 -->

F. No. J-11018/4/2024-Judicial
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
ऋककक
Shastri Bhawan, New Delhi
Dated the 28" January, 2025
ORDER
The President is pleased to engage following Advocates as Senior Arbitration
Counsel for conducting arbitration cases for the Central Government before the Arbitrators
at Delhi, with effect from the date of this order for a period of three years or until further
orders, whichever is earlier:
For Arbitration Cases at Delhi
SENIOR ARBITRATION COUNSEL
53-Ground Floor, World Trade Centre,
i Jagdish Chandra Peronnarig :ease New Gel! 110001 R/720/2006
Email: jagdishsolankip@gmail.com
a Kreda Law Offices, D-47, कर
Ranjeev Khatana South Extension-I, New Delhi-110049 D
2 , Mob: 8586963070 3364/2017
Email: ranjeevkhatana@kredalaw.com
5A, 2° Floor, Jangpura, Mathura Road, New Aan
3. Ajith S. Ranganathan Delhi-110014 TN/1403/2011
Mob: 9899461354
Email: ajithranganathan@akrandassociates.in
Ze The engagement of aforesaid Advocates will be governed by the terms & conditions
of this Department's OM No. 30(3)/99-Judl. dated 24.09.1999 read with OM No.
26(1)/2014/Judl. dated 01.10.2015 & subsequent instructions issued through various OMs
specially the OM No. J-16/11/2017-Judicial dated 08.02.2018 imposing certain
restrictions. The aforesaid OMs are available on the website of this Department i.e.
www. legalaffairs.gov.in in the tab ‘Judicial Section’ under heading ‘Circulars pertaining to
litigations’.
-
3 Hindi version of this order will follow. Bor
(M,C. )
Sr. Government Advocate
Copy (through email) to :-

1. PS to Hon’ble MoS (I/C) L&J.

2. PSO to Law Secretary / All the Additional Secretaries and Joint Secretaries in Main Secretariat
of Department of Legal Affairs.

3. Ld. ASGI, High Court of Delhi.

4, The In-charge, Central Agency / Litigation (High Court/CAT/Lower Court) Sections.

5. One copy of this order is uploaded on website of this Department i.e. www.legalaffairs.gov.in
under tab ‘Judicial Section’ in the link ‘List of empanelled Advocates’ for the information of all
concerned.

6. LIMBS team of Department of Legal Affairs. (wo ८

7. Hindi unit, Department of Legal Affairs for Hindi translation of the order. (26४7४

8. Spare copies. \ 8

(Kumar Gaurva)

Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
