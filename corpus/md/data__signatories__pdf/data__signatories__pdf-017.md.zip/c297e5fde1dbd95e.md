---
doc_id: "c297e5fde1dbd95e"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/35bf5c4d3e6e4557012c6c5474f07f58.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Request for entries of two addresses in theRegister under section 10"
date: "2025-06-30"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2b135b5b4fa88fa9"
---

<!-- page 1 -->

FORM 23
Fee Rs. 200

REQUEST FOR ENTRY OF TWO ADDRESSES FOR
SERVICE IN REGISTER OF DESIGNS
Section 10

1

Insert (in full) name and In the matter of Design No. __________ Class ____________
address.
I (or we)1 ________________________________________
________________________________________________
________________________________________________
________________________________________________
hereby request that the two following addresses for service by
may be entered in the Register of Designs.

2

Insert full address

(a)2 ____________________________________________
________________________________________________
(b)2 ____________________________________________
________________________________________________

Dated this____________day of __________________19
3

To be signed by the
applicant or authorised
agent.

(Signed)3________________________________________
TO
THE CONTROLLER OF DESIGNS,
THE PATENT OFFICE, CALCUTTA.
