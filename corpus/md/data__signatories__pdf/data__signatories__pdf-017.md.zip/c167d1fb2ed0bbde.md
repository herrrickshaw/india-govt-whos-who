---
doc_id: "c167d1fb2ed0bbde"
source_url: "https://mohua.gov.in/static/uploads/2025/11/8da42a656462ae9dc860c66edaa32e90.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of 112,99 00,0001- as 1 installment of Central Assistance to the State Government of Madhya Pradesh for additional attached beneficianes in 34 BLC (New) projects approved in 4T d CSMC meeting held on 25 02 2019 under S- Pradhan Mantri Awas Yo"
date: "2021-02-15"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1c200a6ae16e620a"
---

<!-- page 1 -->

iretox

https://pfths.nic.in/Sanction/Temp1ateAdvice.aspx?AdviceNum

PAO (Sectt)/HUA/Admn/Advice /2020-21//4 Z
GOVERNMENT OF INDIA
PAO(Sectt.), M/o Housing & Urban Affairs
507-C(wing), Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664
To,
The General Manager,
Reserve Bank of India,
Central Accounts Section,
Additional Office Building,
East High Court Road,
NAGPUR - 440 001

Code No: J707
Advice No: J565
Advice Date: 7/02/2o21

Sir,
Please debit our account with Rs.12,99,00,000/- (Twelve Crore Ninety Nine Lakh Only.) by contra
credit to the following accounts of the Governments with the amounts mentioned against each:

Month and Year of Accounts: February,2021
Sl.No. Name of the State
State
Code
1

MADHYA
PRADESH

107

The Amount to be Settled: February,2021
Amount Sanction No. and Date

Scheme Code
1 1989-STATE AND UT
GRANTS UNDER PMAY
(URBAN)

112,99,00,000

N-11011/22/2019-HFA-I-UD
(FTS 9061203) dated
15/02/2021

GRAND TOTAL: 12,99,00,000

Signature of the authorized official

(Pawan Kumar Bhatnagar)
Sr.Accounts Officer
1. 0/0 the Accountant General (A&E) -I, Madhya Pradesh, Rani Jhansi Road Gwalior-474002
?'• Jagdish Prasad, US (HFA-I), M/o HUA, Nirman Bhawan, New Delhi.
J

(1

-

(Pawan Kumar Bhatnaga)
Sr. Accounts Officer

f(k

pto7-)
t iY

f1

I

17-Feb-21, 2:59 PM

<!-- page 2 -->

<!-- page 3 -->

222

t$1 101 1i22i2Oi9HFA44JD (FTS: 9061203)
Government of India
Ministry : of Housing and Urban Affairs
HFA Mission Directorate
(HFA.4 Division)
*****
Nirman Bhàwan New Delhi.
Dated 15th February, 2021

To
Pay and Accounts Officer (Secttj,
Ministry of Housing and Urban Affairs,
Nwman Bhawan, New Delhi -11

S-

Sub Release of 1 12,99 00,0001- as 1 installment of Central Assistance to the State
Government of Madhya Pradesh for additional attached beneficianes in 34
BLC (New) projects approved in 4T d CSMC meeting held on 25 02 2019 under
Pradhan Mantri Awas Yojana (Urban) [PMAY (U)] Mission for the financial year
2020-21 - reg.

Sir,
1 am directed to convey the Sanction of the President of India to release of
12 1 9900 1 000/- (Rupees Twelve Crore and Ninety-Nine Lakh only) to the State
Government of Madhya Pradesh as 1 st . installment of Central Assistance for additional
attached beneficiaries in 34 BLC (New) projects approved in 43 CSMC meeting held
on 2502 2019 held under Pradhan Mantri Awas Yojana (PMAY)- Housing for All (Urban)
Mission (for Other than Scheduled Castes Component and Scheduled Tribes
Component) under Allocation for the FY 2020-21 Details of the projects are as under.
( an lakh)

CSMC Vertical Total No Total
7.7710___ Total No of Amount of jTM
Amount to be
of
Amount of instalment beneficianes
Instalment
released under
Projects Central of Central (other than already other than
approved Assistance Assistance SC and ST) reieased under SCCISTC Head
by CSMC sanctioned approved entered In other than
in CSMC MIS as on
SCC1STC Head
_______ _________
7-1-2021

43 BLC(N)

47

3988050 1595220

13657

689520

129900

q i-'rojea-wise aetaiis•are annexea.

2 Based on decision of CSMC meeting under Pradhan Mantn Awas Yojana (PMAY) Housing for All (HFA) (Urban) Mission and on the recommendations made by MoHUA,
the amount of central grant is being released subject to following conditions alongwith

observations of CSMC
i

Necessary sanctionst approvals/ comphances required under the statutory or
other regulatory regime as applicable would be obtained by the authority(ies)
concerned with the project(s)

ii. The State Government and implementing agency shall put in place a monitoring
system to ensure that the project(s) achieve scheduled milestone and envisaged
outcomes including implementation of reforms and other conditionahties required
under the scheme.

Cofltt2l-

<!-- page 4 -->

-2iii.
iv.
V.

Utilize the grant in accordance with the approved guidelines for the
implementation of the Scheme of Pradhan Mantri Awas Yojana (PMAY) - Housing
for All (HFA) (Urban)
Furnish the Utilization certificates of the Grant released in the presc1bed format as
per GFR - 2017 as provided in the scheme guidelines.
The funds may be Utilized for the purpose and within selected categodsed
beneficiary for Wi*h these are given- Otherwise these Will have to be refunded

along with interest as per provisions for GFR-2017.
vi.. The State mus t ensure .geo-tagging of photographs to monitor progress of the
house construction before release of each instalment to beneficianes

vii The agencies responsible for implementation of PMAY(U) should get themselves
registered on PFMS portal
vul

The State Government should validate the demand assessment data and remove

the ineligible beneficiaries in order to make the housing requirement realistic
ix. State to ensure that adequate infrastructure is ensured including individual water,
sanitation and electric connection
x
State Government to ensure that there is no duplication I change in the identified
beneficiaries..
xi
xii

Transfer of funds to different entities maybe made through PFMS, as applicable,
and where there is an element of cash transfers to individual beneficiaries, the
same may be made through PFMS/DBT mode, as applicable
State Government should ensure that there is no violation of Model Code of
Conduct while releasing funds to Implementing Agencies/ULBslBeneficiaries

3
Payment may kindly be made to the State Government immediately The funds
may thereafter be released to the implementing agencies without any delay failing which
the amounts would be recovered from the State Government with interest for the penod
of default
Additional allocation through 2 nd supplementary Demand for Grants 2020-21 for
PMAV-U as yet to be received Therefore, in pursuance to the DEA OM No 714112019-BA
(Pt 1) dated 06.01202 1 conveying authorization for ancumng excess expenditure of Rs
600000 crore over and above BE allocation for PMAY(U) by invoking Appendix —10 under
4

Rule 61 and 69 of GFR 2017 the expenditure involved will be debated from head
3601 0650201 01.35 (Other than SC/ST Components) under demand No 57 of Ministry
of Housing and Urban Affairs for the year 2020-21 and will be transferred to the following
head of account on regularization after receiving the 2 SDG 2020-21
Major Head:
Sub-Major Head
Minor Head
Sub Head
Detailed Head
Object Head

3601
06
101
31
01
31.01 35

Grants-in-aid to State Governments

Centrally Sponsored Schemes
Central Assistance/Share
Pradhan Mantn Awas Yojana (Urban)

Assistance to State Governments for PMAY(U)
Grants for Creation of Capital Assets

Contd 3/-

<!-- page 5 -->

5.
As per rule 236(1) of SFR, 2017, the relevant accounts of the Grantee
institution(s)/Organization(s) shall be open to inspection by the sanctioning authority and
audit, both by the Comptroller and Author General of India under the provision of CAG
(DPC) Act 1971 and internal audit by the Principal Accounts Office of the Ministry or

<!-- page 6 -->

to

..J

,

to
-

0

AA

<!
10

c

'

41

JO ±

ZZ

I

I

qu

?

-

E•

IL

is

10

}

on

r4

D

0

en

r4
LA

:

:

H
fo
fc

§
co
so

on
4

C

a

An

.

o
4,
44

4;

44
Ae

-

C

0

q

40

wo
45'

454

SJ

0

0
CL

0

a

dn

4n

a
cm

0

a

a

a
444

0
0

4

a

o

44

430

-

w V
-'

4;

-

a

-::Z

SMC
Z

0

0

a

C
ILI >-

tA
c
a

-

..

CJ

—ceo

0
'
a-

-

40

To

c

,tC444

u#44

qn

V14

t-

z
o

-4;
0

Am

An

C
O

2
4;,

-

0
04;
CL

C

C
401

4;

ca

4-2c5'

44
4C6

o go
— 0
-

40

CC.

WO
UCCD

.4

0

4;

4;

4;

4;

4;

<!-- page 7 -->

o

D

f)

-

c

4n

co

co

cc

r.

D

Q

D

z

Go

m

C4

m
ul

as
tn

co

(J

0

F

03

;

:;

4n

tn

g:
.

u

in
q.

Ui

-

'l

I'
CO

(
0:

g
e.4

c

o

o

4n

41

4b
m

,

a

a

a

a

••
.0

= •

o

wl
—

I.J

D

C

fI

6

0
•

um
03
An

m

04

w

to
u

An

so

r,I

f

0

D

(#

,

---

.
-I'J

)

0 W

.!

v4

'

£J

40
W

'

W V

.

.

4A

4A

W V

W V
4w

va it
c

CS

c

c

c

25 fm

m

IQ

Al

An
C

CL
0
tJ

U
40

U

U
do

--T
-77,

C

do

in

<!-- page 8 -->

:
.

lx

.—

.f
.-

-

-

.-

t

to
kD

r4

r4

0

'

£

r—
a

r.4

.

C

•.
C

'J

?

1

C4

w

Q

C

C

e

Q
..l

C
•'

O

•fl

4n

n

.

0

-

a

(T

,

.
Ui

fl

C

to

to

00

0

W

a
rn

C,

:z

In

415
4_4

Go

Go
Lfl

ir

u

a)

4fl
-1

4n
•%

Hn

r

4w

r4
410

AM
g
fw

-.

AV

An

r4

40

r4

o

D

-

c
C6

e

c

a

2
al
4'.

fl

4'a

t4
••4

&fl

.1 %
4_1

4A

40

:D

"
h

1

);

3

-40

C

___3

_V;

!'

—

c
5

—

__3

40

-o
;

3:
_'.I:;

"

AD
vi

41

14

U

z—

CZ

e

e

tJ
tz

03
O

qo

4fl

N
f•-

AT,

C'

%fl
ko

'

.(

r

Q

40

?
40
Q

cc

tc

Tn

r!4,

'

co

qu

40

AJ

Aj

w

£
40

C

.

Aj CL

U

Ae

0
co

to

in

<!-- page 9 -->

C6

k6

0

1-4

In

ID

C4

cc

in

r4

C;
0

eft

05

40
04

m
N

50

05

Ln

2

to

m

04

AD

04

10

04

50

to

0

mt

2

50

05

m

40

US

.4
0

2

US

•0

to

05
N

qt
US
OS

.
0

en

(0

0

en

2

2

2

2

2

0

0

0

0

US

(15

US
54

5.4

0

04

US

0

o

US

US

0

0

?
'o

U'

-'

C l.
04
-

15

C
-0
C CO

m

NU<

N'
f
CU<

C C c

en

- -

C C

C 04 - svrn

0

04

C 04
.(0515

5.4

en

'15

in

04

05

05

2

2

0

0

0

0

(45
5.4

an

115

5.4

04

(0

0
415

0

5.4

5.4

-.
C.

(0

0(0
0

04

(0

003

0
115

f

tu 12

US

-

-

en

C

e

C

C

C Qs

as
404-0
04
..
C 04
rn04U.(0rn

-0
C CO

E
C

C

0 N

C IC C

2—°
o.
C CO
oolSn

03

I-

C

U

C
.o.0(0

4

CL
0304

16

.0

C

.o

E

U

U

U

U

U

U

U

U

04

04

04

04

04

04

04

04

04

5.3
en

US
(.4

50

en

N
5.4

04
5.4

(35
1

0
sn

335

en

.0 CO

C

'

04

C

04

U'

N0

C

US
N.

2

0
AA

13

en

-i
(0
CO

(0

003

fa

US

US

en

tm
cr

5.4

115

OS
N

0

US

5.5

5-4

US
N

US

04

0

US

-4
N.

05

en

en

C CO

<!-- page 10 -->

0
0

1'-

An

AD
('4

17V

w

An

C,

in

At

p.
(0

to

.0
U'

áT
(0

0
0
In

LA

Rr
(0

(0
In

go

in

o

0'

0

rm
At
0 ID -M

0

0

e4

4-4

a

a

I
—

o

0.(

ck

°t
40 10

(

-

'a

07J(0
CICE(.4

!
C

40 U
I

Au

tJ
(0

(0

(0

4j
