---
doc_id: "c1bfbf085b1a76bd"
source_url: "https://mines.gov.in/admin/download/642d104c0a0aa1680674892.pdf"
ministry: "Mines (MoM)"
title: "Reimbursement of Exploration Expenditure Rules, 2022 (1.48 MB)"
date: ""
pages: 26
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7dc884fb86ee62e7"
---

<!-- page 1 -->

रजजस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-04062022-236331
xxxGIDHxxx
CG-DL-E-04062022-236331
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 394]
No. 394]

नई ददल्ली, िुक्रिार, जून 3, 2022/ज्येष्ठ 13, 1944
NEW DELHI, FRIDAY, JUNE 3, 2022/JYAISHTHA 13, 1944

खान मंत्रालय
अजधसूचना
नई ददल्ली, 3 जून, 2022
सा.का.जन. 415(अ).—कें द्रीय सरकार, खान और खजनज (जिकास और जिजनयमन) अजधजनयम, 1957 (1957 का
67) की धारा 10क की उप धारा (2) के खंड (ख) के दूसरे परं तुक के साथ पठठत धारा 13 द्वारा प्रदत्त िजियों का प्रयोग
करते हुए, जनम्नजलजखत जनयम बनाती है, अथाात:् —

अध्याय 1
प्रारं जभक
1. संजिप्त नाम और प्रारं भ—(1) इन जनयमों का संजिप्त नाम खोज व्यय प्रजतपूर्तत जनयम, 2022 है।
(2) ये राजपत्र में उनके प्रकािन की तारीख को प्रिृत्त होंगे।
2. पठरभाषाएं—(1) इन जनयमों में, जब तक दक संदभा से अन्यथा अपेजित न हो,—
(क) "अजधजनयम" से खान और खजनज (जिकास और जिजनयमन) अजधजनयम, 1957 (1957 का 67) अजभप्रेत है;
(ख) "दािा" से आिेदक द्वारा अनुसूची I में ददए गए प्रारूप में खोज व्यय की प्रजतपूर्तत के जलए प्रस्ट्तुत आिेदन अजभप्रेत
है;
(ग) "दािेदार" से दािे का आिेदक जो भूमीिण अनुज्ञापत्र और पूिेिण अनुज्ञजप्त का धारक था और अजधजनयम की
धारा 10क की उपधारा (2) के खंड (ख) के अधीन, यथाजस्ट्थजत, पूिेिण अनुज्ञजप्त के पश्चात् खनन पटा ा या खनन पटा े
का अजधकार अजभप्राप्त करने के जलए अर्तजत दकया था और जजसका उि अजधकार समाप्त हो गया था; और इसमें ऐसे
3782 GI/2022

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

भूमीिण अनुज्ञापत्र या पूिेिण अनुज्ञजप्त के धारक, यथाजस्ट्थजत, सिम न्यायालय के आदेि द्वारा जिजधक प्रजतजनजध,
जिजधपूणा समनुदेजिती, जिजधपूणा अंतठरती या उत्तराजधकारी सजममजलत है, अजभप्रेत हैं;
(घ) "व्यपगत होने की तारीख" से खान और खजनज (जिकास और जिजनयमन) संिोधन अजधजनयम, 2021 के प्रारं भ
होने की तारीख (अथाात, 28 माचा, 2021), जब अजधजनयम की धारा 10क की उप धारा (2) के खंड (ख) के अधीन,
यथाजस्ट्थजत, खनन पटा े के बाद पूिेिण अनुज्ञजप्त के पश्चात् खनन पटा ा या खनन पटा ा अजभप्राप्त करने के जलए भूमीिण
अनुज्ञापत्र या पूिेिण अनुज्ञजप्त धारक का अजधकार उि खंड के दूसरे परं तुक के अधीन समाप्त हो गया था अजभप्रेत
है।
(ङ) "प्रारूप " से इन जनयमों के साथ उपाबद्ध अनुसूची में ददए गए प्रारूप अजभप्रेत हैं।
(2) उन िब्दों और पदों के , जो इन जनयमों में प्रयुक्त है, ककतु पठरभाजषत नहीं है, िही अथा होंगे जो इस अजधजनयम या
इसके अधीन बनाये गए जनयमों में है।
3. प्रयोज्यता. — (1) ये जनयम के िल ऐसे ठरयायत धारकों या आिेदकों पर लागू होंगे, जजन्होंने अजधजनयम की धारा 10क
की उप धारा (2) के खंड(ख) के अधीन, यथाजस्ट्थजत, पूिेिण अनुज्ञजप्त अजभप्राप्त करने के पश्चात् खनन पटा ा या खनन पटा ा
अजभप्राप्त करने के जलए अजधकार उपार्तजत था और जजसका उि अजधकार व्यपगत होने की तारीख को समाप्त हो गया है।

अध्याय 2
दािा प्रदक्रया
4. खोज व्यय के जलए दािा —(1) कोई भी दािेदार, राज्य सरकार को भूमीिण या पूिेिण संदक्रयाओं के जलए दकए गए
व्यय की प्रजतपूर्तत के जलए राष्रीय खजनज खोज न्यास को सूजचत करते हुए इन जनयमों के प्रारं भ होने की तारीख से एक िषा
की अिजध के भीतर इन जनयमों की अनुसूची I में ददए गए प्रारूप में दािा प्रस्ट्तुत कर सकता है:
परं तु ऐसे मामलों में जहां अनुज्ञापत्र या अनुज्ञजप्त की अिजध व्यपगत होने की तारीख से पहले समाप्त नहीं हुई थी —
(क) दािेदार अनुज्ञापत्र या अनुज्ञजप्त की अिजध की समाजप्त या इन जनयमों के प्रारं भ होने की तारीख से एक िषा की
अिजध के भीतर, जो भी बाद में हो, दािा प्रस्ट्तुत कर सकता है; या
(ख) दािेदार राज्य सरकार को ऐसे अनुज्ञापत्र या अनुज्ञजप्त को अभ्यर्तपत करने के पश्चात् व्यपगत होने की तारीख
तक, ऐसे अभ्यपाण या इन जनयमों के प्रारं भ होने की तारीख से एक िषा के भीतर, जो भी बाद में हो, अपने द्वारा
उपगत व्यय का दािा प्रस्ट्तुत कर सकता है।
(2) दािेदार अपने दािे के आिेदन के साथ जनम्नजलजखत संलग्न करे गा, अथाात्:(क) प्रारं भ दकए गए खोज कायाकलापों के जलए उपगत संदाय या व्यय को जसद्ध करने के जलए आिश्यक दस्ट्तािेज,
जैसे बैंक जििरण, जडस्ट्चाजा संदाय पची, जनपटान की पािती के साथ िाउचर या बीजक, या संदाय की रसीदों या ऐसे
अन्य दस्ट्तािेज; और
(ख) चाटाडा एकाउं टेंट का इस संबंध में प्रमाण पत्र दक दािा उसके द्वारा समयक रूप से स्याजपत दकया गया है।
(3) राज्य सरकार उप जनयम (1) में जिजनर्ददष्ट अिजध के पश्चात् प्रस्ट्तुत दकए गए दािों के साथ आगे नहीं बेेगी:
परं तु यदद देरी के कारण दािेदार के जनयंत्रण से परे थे तो राज्य सरकार दािा दायर करने के जलए एक और िषा की अिजध
की अनुमजत दे सकती है।
5. राज्य सरकार द्वारा स्यापन—(1) दािे का आिेदन प्राप्त होने पर, राज्य सरकार जनम्नजलजखत का स्यापन करे गी,
अथाात:् —
(क) दािेदार भूमीिण अनुज्ञापत्र या पूिेिण अनुज्ञजप्त का धारक था जजसने अजधजनयम की धारा 10क की उपधारा
(2) के खंड(ख) के अधीन, यथाजस्ट्थजत, अनुज्ञजप्त अजभप्राप्त करने के पश्चात् खनन पटा ा या खनन पटा ा प्राप्त करने का
अजधकार अर्तजत दकया था और जजसका उि अजधकार व्यपगत होने की तारीख को समाप्त हो गया है; या िह
भूमीिण अनुज्ञापत्र या पूिि
े ण अनुज्ञजप्त के धारक का, यथाजस्ट्थजत, सिम न्यायालय के आदेि द्वारा जिजधक
प्रजतजनजध, जिजधपूणा समनुदेजिती, जिजधपूणा अंतठरती या उत्तराजधकारी है; और
(ख) दािेदार ने राज्य सरकार की संतुजष्ट के जलए, -

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

3

i) कें द्रीय सरकार द्वारा यथा अजधकजथत मापदंडों के अनुसार ऐसी भूजम में खजनज सामग्री की जिद्यमानता को
स्ट्थाजपत करने हेत,ु यथाजस्ट्थजत, भूमीिण संदक्रयाएं या पूिेिण संदक्रयाएं की हैं;
ii) भूमीिण अनुज्ञापत्र या पूिेिण अनुज्ञजप्त के जनबंधनों और ितों का कोई उल्लंघन नहीं दकया है;
iii) अजधजनयम के उपबंधों और उसके अधीन बनाए गए जनयमों के अधीन अपात्र नहीं होना; और
iv) पूिेिण अनुज्ञजप्त या खनन पटा े के अनुदान के जलए भूमीिण अनुज्ञापत्र या पूिेिण अनुज्ञजप्त की समाजप्त के
पश्चात् तीन मास की अिजध के भीतर, यथाजस्ट्थजत, या ऐसी और छह मास से अनजधक की अिजध के भीतर जो
राज्य सरकार द्वारा बेाया जा सकता है, आिेदन करने में जिफल नहीं हुआ हो।
परं तु ऐसे मामले में जहां अनुज्ञापत्र या अनुज्ञजप्त की अिजध व्यपगत होने की तारीख से पहले समाप्त नहीं हुई थी
और दािेदार ने जनयम 4 के उप जनयम (1) के परं तुक के खंड (क) के अधीन अनुज्ञापत्र या अनुज्ञजप्त की समाजप्त के पश्चात्
दािा प्रस्ट्तुत दकया है, खंड (iv) में जिजनर्ददष्ट िता लागू नहीं होगी:
परं तु यदद अनुज्ञापत्र या अनुज्ञजप्त की अिजध व्यपगत होने की तारीख से पहले समाप्त नहीं हुई थी और दािेदार ने
जनयम 4 के उप जनयम (1) के परं तुक के खंड (ख) के अधीन व्यपगत होने की तारीख तक उसके द्वारा उपगत व्यय का दािा
प्रस्ट्तुत दकया है, राज्य सरकार स्याजपत करे गी दक दािेदार द्वारा खंड (i) से (iii) में जिजनर्ददष्ट ितों का अनुपालन दकया
गया था, जहां तक व्यािहाठरक हों, और खंड (iv) में जिजनर्ददष्ट िता लागू नहीं होगी।
(2) उपजनयम (1) के अनुसार समयक स्यापन के पश्चात्, और यह समाधान हो जाने पर दक दािेदार को खनन पटा ा के बाद
पूिेिण अनुज्ञजप्त या खनन पटा ा, यथाजस्ट्थजत, अजभप्राप्त करने का अजधकार था, व्यपगत होने की तारीख से पहले, राज्य
सरकार दािे को इसके अनुबंधों और अन्य सुसंगत दस्ट्तािेजों के साथ प्रजतपूर्तत जनधाारण सजमजत को अग्रेजषत कर सकती है।
6. प्रजतपूर्तत जनधाारण सजमजत - राज्य स्ट्तर पर एक प्रजतपूर्तत जनधाारण सजमजत का गठन दकया जाएगा, जजसमें जनम्नजलजखत
सदस्ट्य होंगे, अथाात:् —
(क) अध्यि के रूप में, अपर मुख्य सजचि या प्रमुख सजचि या राज्य के खनन और भूजिज्ञान के प्रभारी सजचि;
(ख) उप महाजनदेिक (राज्य इकाई), भारतीय भूिैज्ञाजनक सिेिण;
(ग) संबंजधत िेत्र के िेत्रीय खान जनयंत्रक, भारतीय खान ब्यूरो;
(घ) राज्य सरकार के जित्त जिभाग के प्रजतजनजध;
(ड.) राज्य सरकार के जनदेिालय या खनन और भूजिज्ञान जिभाग में जनदेिक (चाहे िह दकसी भी नाम से जाना जाता
हो), सदस्ट्य सजचि के रूप में; और
(च) अपर जनदेिक, खोज और अनुसंधान के जलए परमाणु खजनज जनदेिालय, परमाणु खजनजों के मामले में
सहयोजजत दकया जाएगा।
7. प्रजतपूर्तत जनधाारण सजमजत द्वारा दािे का जनधाारण—(1) जनयम 5 के अधीन राज्य सरकार से दािा प्राप्त होने पर
प्रजतपूर्तत जनधाारण सजमजत व्यपगत होने की तारीख को त्समय प्रिृत्त जनयमों के अनुसार यथाजस्ट्थजत अनुज्ञापत्र धारक या
अनुज्ञजप्तधारी द्वारा, दकए गए काया की परीिा करे गी।
(2) परीिा में यथाजस्ट्थजत अनुज्ञापत्र धारक या अनुज्ञजप्तधारी द्वारा प्रस्ट्तुत ठरपोटा के अनुसार दकए गए काया का तकनीकी
मूल्यांकन, अजधजनयम के उपबंधों और उसके अधीन बनाए गए जनयम के अनुसार दकए गए भूमीिण या पूिेिण संदक्रयाओं
के अनुक्रम के दौरान; इस प्रकार दकए गए काया को करने की आिश्यकता; प्र्येक मद की तका संगतता और लागू जिद्यमान
जनयमों का पालन भी सजममजलत होगा ।
(3) प्रजतपूर्तत जनधाारण सजमजत, दािेदार द्वारा खोज दक्रयाकलापों पर उपगत पर िास्ट्तजिक व्यय के आधार पर प्रजतपूर्तत
रकम का जनधाारण करे गी और उि प्रजतपूर्तत रकम के न्द्रीय सरकार द्वारा जिजनर्ददष्ट ऐसे प्राजधकरणों के प्रभारों की अनुमोददत
अनुसूची में दी गई रकम से अजधक नहीं होगी:
परन्तु प्रभारों की अनुसूची के अधीन नहीं आने िाले जििेष अध्ययनों जैसे हिाई भू भौजतकीय सिेिण या इसी
तरह के जलए प्रजतपूर्तत जनधाारण सजमजत भारतीय भूिैज्ञाजनक सिेिण या खजनज खोज जनगम जलजमटेड या दकसी अन्य
सरकारी अजभकरण द्वारा दकए गए समान काया के आधार पर उजचत प्रजतपूर्तत की जसफाठरि कर सकती है।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(4) प्रजतपूर्तत जनधाारण सजमजत, यदद अपेजित हो, दािेदार से अपने दािे के संबंध में स्ट्पष्टीकरण या अजतठरि जानकारी मांग
सकती है और सजमजत द्वारा अपने जनधाारण में दािा की गई रकम को कम या अस्ट्िीकार दकए जाने की जस्ट्थजत में दािेदार को
सुनिाई का एक युजक्तयुक्त अिसर देगी।
(5) सजमजत द्वारा जनधााठरत रकम में पूिेिण अनुज्ञजप्त या खनन पटा े के जलए आिेदन जमा करने की तारीख से, यथाजस्ट्थजत,
इन जनयमों के प्रारमभ होने की तारीख तक छह प्रजतित िार्तषक की दर से साधारण ब्याज जोडा जाएगा।
6) प्रजतपूर्तत जनधाारण सजमजत उपधारा (5) के अधीन संगजणत ब्याज सजहत यथा जनधााठरत दािेदार को देय प्रजतपूर्तत रकम
को जिजनर्ददष्ट करते हुए अपनी जनधाारण ठरपोटा राज्य सरकार को अग्रेजषत करे गी।

अध्याय 3
आपूर्तत और प्रजतपूर्तत का भुगतान
8. प्रजतपूर्तत—(1) प्रजतपूर्तत मूल्यांकन सजमजत से जनधाारण ठरपोटा प्राप्त होने पर, राज्य सरकार उस पर अपनी जसफाठरिों
सजहत ठरपोटा को अजधजनयम की धारा 9ग के अधीन स्ट्थाजपत राष्ट्रीय खजनज खोज न्यास को अग्रेजषत करे गी।
(2) जनयम 5 के अधीन राज्य सरकार द्वारा दािे के स्यापन, प्रजतपूर्तत जनधाारण सजमजत द्वारा जनयम 7 के अधीन जनधाारण
और राज्य सरकार द्वारा उपजनयम (1) के अधीन अनुमोददत जनधाारण ठरपोटा को न्यास को अग्रेजषत करने की पूरी प्रदक्रया
जनयम 4 के अधीन प्राप्त दािा के तीन मास की अिजध के भीतर पूरी की जाएगी।
(3) राष्ट्रीय खजनज खोज न्यास की तकनीकी-सह-लागत सजमजत यह स्याजपत करे गी दक प्रजतपूर्तत जनधाारण सजमजत द्वारा
जनधााठरत प्रजतपूर्तत रकम जनयम 7 के उपजनयम (3) के अनुसार है या नहीं और जो अपेजित हो ऐसी उपांतरण के साथ देय
प्रजतपूर्तत रकम को अंजतम रूप देगी।
परन्तु जनयम 5 के अधीन राज्य सरकार द्वारा स्याजपत दािेदार की पात्रता अंजतम होगी।
(4) राष्ट्रीय खजनज खोज न्यास, ऐसे स्यापन के पश्चात, जनयम 7 के उप-जनयम (5) के अनुसार संगठठत न्यास के साथ
प्रजतपूर्तत की जाने िाली अंजतम रकम को, न्यास के पास जनजध की उपलब्धता के अध्याधीन राज्य सरकार से जनधाारण
ठरपोटा प्राप्त होने के तीन मास के भीतर राज्य सरकार के जनदेिालय या खनन और भूजिज्ञान जिभाग में जनदेिक (चाहे िह
दकसी भी नाम से ज्ञात हो) के पि में जारी कर सकता है।
(5) राज्य सरकार के जनदेिालय या खनन और भूजिज्ञान जिभाग में जनदेिक (चाहे दकसी भी नाम से ज्ञात हो) राष्ट्रीय
खजनज खोज न्यास से रकम की प्राजप्त के एक मास के भीतर दािेदार को अंजतम रकम जारी करे गा।
9.
प्रजतपूर्तत— (1) दकसी िेत्र के संबंध में दकसी दािे के लजमबत होते हुए भी राज्य सरकार अजधजनयम की धारा 10क
की उप-धारा (घ) और उसके अधीन बनाए गए जनयमों के अनुसार ऐसे िेत्र के संबंध में खजनज ठरयायतें प्रदान करने के जलए
प्रदक्रया िुरू करे गी।
(2)
अजधजनयम की धारा 10 की उपधारा (2) के खंड (ख) के अधीन आने िाले िेत्र के संबंध में समेदकत अनुज्ञजप्त या
खनन पटा े की नीलामी के मामले में जहां—
(i) इन जनयमों के प्रारं भ होने की तारीख के पश्चात जनजिदा आमंजत्रत करने की सूचना जारी की जाती है; और
(ii) जनजिदा आमंजत्रत करने की सूचना जारी की गई है ककतु बोजलयां जमा करने की अंजतम तारीख इन जनयमों
के प्रारं भ होने की तारीख के पश्चात पड रही है,
जनम्नजलजखत ितें जनजिदा दस्ट्तािेज में जिजनर्ददष्ट नीलामी ितों का भाग मानी जाएंगी, अथाात् :—
(क)

अजधमाजनत बोलीदाता प्रजतपूर्तत की गई रकम या जनष्पादन व्यय के जलए प्रजतपूर्तत की जाने िाली राजि को
अजग्रम भुगतान की पहली दकस्ट्त के साथ जमा करे गा या, यथाजस्ट्थजत, राज्य सरकार को जनष्पादन सुरिा,
यदद राष्ट्रीय खजनज खोज न्यास की तकनीकी-सह-लागत सजमजत द्वारा अंजतम रूप ददया गया है; या

(ख)

अजधमाजनत बोलीदाता राज्य सरकार को राष्ट्रीय खजनज खोज न्यास की तकनीकी-सह-लागत सजमजत द्वारा
इसे अंजतम रूप देने के एक मास के भीतर राज्य सरकार के साथ खोज व्यय की प्रजतपूर्तत की जाने िाली
रकम जमा करने के जलए जलजखत रूप में एक िचनबद्धता देगा, यदद रकम को अंजतम रूप ददया जाना बाकी
है ;

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

5

(ग)

अजधमाजनत बोलीदाता जलजखत रूप में एक अजतठरक्त रकम खोज व्यय की प्रजतपूर्तत के जलए प्रस्ट्तुत करने के
जलए िचनबद्धता भी देगा, जजसे पुनरीिण प्राजधकारी द्वारा उपांतठरत या संिोजधत दकया जा सकता है;
और

(3)

उपजनयम (2) में जिजनर्ददष्ट ितों का अनुपालन न करने की जस्ट्थजत में, राज्य सरकार अजग्रम संदाय या
जनष्पादन सुरिा की पहली दकस्ट्त को जब्त करने, यथाजस्ट्थजत और खजनज (नीलामी) जनयम, 2015 के
अनुसार कोई अन्य कारा िाई करने के जलए कारा िाई करे गी।

परं तु परमाणु खजनजों के संबंध में जहां ऐसे खजनज की श्रेणी परमाणु खजनज ठरयायत जनयम, 2016 की
अनुसूची क में कें द्रीय सरकार द्वारा जिजनर्ददष्ट प्रारं जभक मूल्य के बराबर या उससे अजधक है, उप-जनयम (2) में
उजल्लजखत ितों को खजनज ठरयायत देने के जलए पूि-ा ितों के रूप में जिजनर्ददष्ट दकया जाएगा ।
(4) उप जनयम (2) में जिजनर्ददष्ट अजधमाजनत बोलीदाता से खोज व्यय की प्रजतपूर्तत या प्रजतपूर्तत की जाने िाली रकम
प्राप्त होने पर, राज्य सरकार पटा ा जिलेख पर हस्ट्तािर करने से पहले या इसकी प्राजप्त होने के एक मास के भीतर,
जो भी बाद में हो, इसे राष्ट्रीय खजनज खोज न्यास जनजध में जमा करे गी।
(5) यदद नीलामी समाप्त हो गई है या इन जनयमों के प्रारं भ होने की तारीख से पहले बोली जमा करने की अंजतम
तारीख समाप्त हो गई है, तो राज्य सरकार खजनज (नीलामी) जनयम, 2015 के जनयम 13 के उपजनयम (2) के अधीन
पटा ेदार द्वारा जमा की गई लागू रकम (नीलामी प्रीजमयम) से राष्ट्रीय खजनज खोज न्यास जनजध में इन जनयमों के अधीन
प्रजतपूर्तत की गई या प्रजतपूर्तत की जाने िाली रकम को जमा करे गी।
(6) राष्ट्रीय खजनज खोज न्यास इन जनयमों के अधीन प्रजतपूर्तत के जितरण के जलए खान मंत्रालय में कें द्रीय सरकार से
अजतठरि अनुदान के जलए अनुरोध कर सकता है।
(7) राज्य सरकार अजधमाजनत बोलीदाता को खोज के अन्य सबूतों जैसे संरजित कोर, जलथोग्राफ, कोर फोटोग्राफ, जिल
लॉग-बुक और इसी तरह के , यदद उपलब्ध हो या िेत्र की कोई भूिैज्ञाजनक अध्ययन ठरपोटा और दािेदार द्वारा प्रस्ट्तुत
ऐसे अन्य दस्ट्तािेज के साथ ठरपोटा सौंपेगी ।
10. पुनरीिण- राज्य सरकार या उसके अधीन दकसी प्राजधकरण या प्रजतपूर्तत जनधाारण सजमजत या राष्ट्रीय खजनज खोज
न्यास की तकनीकी-सह-लागत सजमजत द्वारा दकए गए जनधाारण, स्यापन या आदेि से व्यजथत कोई भी व्यजि अजधजनयम
की धारा 30 के अधीन पुनरीिण के जलए कें द्रीय सरकार के पुनरीिण प्राजधकरण को आिेदन कर सकता है।
अनुसच
ू ी-I
दािा प्रस्ट्तुत करने के जलए प्रारूप

[जनयम 4(1)देख]ें
भाग-क
सामान्य सूचना
क्र. सं.

मदों के ब्यौरे

जिजिजष्टयां

(1)

(2)

(3)

1

खजनज ठरयायत का प्रकार:
भूमीिण अनुज्ञापत्र / पूिेिण
अनुज्ञजप्त
खजनज ठरयायत धारक का नाम

2क

दािेदार की जिजधक प्राजस्ट्थजत
(मुख्तारनामा/िपथपत्र/रजजस्ट्रीकृ त
जिलेख)
(क) पत्राचार का पता:
(ख) दूरभाष नमबर (कायाालय):
(ग) फै क्स नमबर (कायाालय):

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(घ) मोबाईल नमबर
(ङ) दूरभाष नमबर. (आिास):
(च) ई-मेल आईडी:
इकाई जििरण
नाम
पैन नमबर
आईटीआर ब्यौरे
2ख

(खोज की अिजध के जलए)
आधार नमबर
जीएसटी/ सेिा कर नमबर
ठटन नमबर
पता
बैंक ब्यौरे
खजनज ठरयायत के ब्यौरे
(क) राज्य:
(ख) जजला:
(ग) तालुका:

3क

(घ) गांि:
ब्लॉक का नाम
िेत्रफल हैक्टेयर में.
भारत स्ट्थालाकृ जतक सिेिण सं.:
खजनज
ब्लॉक की जस्ट्थजत (सभी कोने
बबदुओं का अिांि देिांतर, क, ख,
ग, घ आदद)

क) अिांि--- देिांतर ---; ख) अिांि --- देिांतर ---;
ग) अिांि--- देिांतर ---; घ) अिांि.--- देिांतर ---; ङ) अिांि. ----,
देिांतर ---

प्रिासजनक ब्यौरे
अनुदान के जलए आदेि जारी करने
या आिय पत्र जारी करने की
तारीख
भूमीिण अनुज्ञापत्र /पूिेिण
अनुज्ञजप्त के जनष्पादन की तारीख
3क

भूमीिण अनुज्ञापत्र /पूिेिण
अनुज्ञजप्त की अिजध

प्रेषक:

भूमीिण अनुज्ञापत्र / पूिेिण
अनुज्ञजप्त के निीनीकरण की
तारीख यदद कोई हो और अिजध

प्रेषक:

अंजतम भूमीिण अनुज्ञापत्र /
पूिेिण अनुज्ञजप्त ठरपोटा प्रस्ट्तुत
करने की तारीख
श्रेणी और टन भार के साथ

प्रेजषत:

प्रेजषत:

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

7

अनुमाजनत संसाधन
संसाधन की श्रेणी (यूएनएफसी के
अनुसार)
अजभकरण द्वारा जसफाठरि
क्या भूमीिण अनुज्ञापत्र या
पूिेिण अनुज्ञजप्त धारक को
पूिेिण अनुज्ञजप्त या खनन पटा े के
अनुदान के जलए एक आिेदन,
यथाजस्ट्थजत, 12 जनिरी, 2015
से पहले प्रस्ट्तुत दकया गया है
{धारा 10क(2)(ख)के उप खंड (i)
का अनुपालन}
ठटप्पजणयां
बप्रट दकया गया
द्वारा बप्रट दकया गया

द्वारा तैयार दकया:

द्वारा जांचा गया:
द्वारा अनुमोददत दकया:

नाम और हस्ट्तािर
ठटप्पण: भूमीिण अनुज्ञापत्र के अधीन की गई भूमीिण संदक्रयाओं और पूिेिण अनुज्ञजप्त के अधीन की गई पूिेिण
संदक्रयाओं के जलए अलग भाग-क उपबंजधत करें ।
भाग- ख
खोज कायाकलापों का जििरण
दस्ट्तािेजी
प्रमाण के
प्राप्त
क्र सं.

कायाकलाप

इकाई

प्रस्ट्ताजित

दकया
गया

इकाई
लागत

साथ
दकया
गया
िास्ट्तजि
क व्यय

1

हिाई भू-भौजतकीय अध्ययन
(क) हिाई गुरू्ि
(ख) हिाई चुंबकीय
(ग) हिाई चुंबकीय (उच्च
जियोजन)
(घ) हिाई जिद्युत-चुंबकीय
(एईएम)

2

सुदरू संिेदन अध्ययन
(क)

आरपी/पीएल*
ठरपोटा में
संदभा/पृष्ठ
संख्या

ठटप्पजणयां

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]
दस्ट्तािेजी
प्रमाण के

प्राप्त
क्र सं.

कायाकलाप

इकाई

प्रस्ट्ताजित

दकया
गया

इकाई
लागत

साथ
दकया
गया
िास्ट्तजि
क व्यय

(ख)
(ग)
(घ)
3

भूकंपीय सिेिण्

4

2डी भूकंपीय पराितान सिेिण

5

3डी भूकंपीय पराितान सिेिण

6

डीएसआरएस सिेिण

7

जीपीआर सिेिण

8

स्ट्थलाकृ जतक सिेिण

माप:
किर दकया
गया िेत्र
(िगा
दकमी/हेक्टेयर)

9

भूिैज्ञाजनक मानजचत्रण

माप:
किर दकया
गया िेत्र
(िगा
दकमी/हेक्टेयर)

10

सतह / भू-रासायजनक नमूना

किर दकया
गया िेत्र
(िगा
दकमी/हेक्टेयर)

(क) आधार-िैल
(ख) मृदा
(ग) धारा तलछट
(घ) जलांतराल नमूना
(ङ) अन्य कोई
11

गतान

सं.:
उ्खनन:
सीबीएम
नमूना

12

खाई खोदना

सं.:
उ्खनन:
सीबीएम
नमूना

13

सतत भू-भौजतकीय काया

आरपी/पीएल*
ठरपोटा में
संदभा/पृष्ठ
संख्या

ठटप्पजणयां

<!-- page 9 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

9
दस्ट्तािेजी
प्रमाण के

प्राप्त
क्र सं.

कायाकलाप

इकाई

प्रस्ट्ताजित

दकया
गया

इकाई
लागत

साथ
दकया
गया
िास्ट्तजि
क व्यय

सिेिण का प्रकार
(क) गुरु्िाकषाण पद्धजत
(ख) चुंबकीय पद्धजत
(ग) स्ट्ि-संभाजित पद्धजत
(घ) प्रेठरत ध्रुिीकरण पद्धजत
(ङ) जिद्युत प्रजतरोधकता पद्धजत
(च) प्रजतरोधकता
रूपरे खा/प्रजतबबब
(छ) जिद्युत चुंबकीय सिेिण
(ज) मैग्नेटो-टेलुठरक (एमटी)
सिेिण
(I) अन्य कोई
14

15

िेधन
(क) कोर

एमटी

(ख) गैर कोर

एमटी

भूभौजतकीय लॉबगग
(क) आधार लॉग
(ख) एसपी
(ग) प्रजतरोधकता
(घ) दोहरी घन्ि
(ङ) गामा-गामा
(च) न्यूरॉन
(छ) के लीपर
(ज) प्राकृ जतक गामा
(झ) एसपीआर
(ञ) कें दद्रत प्रजतरोधकता
(ट) श्रिण संबंधी
(ठ) तापमान और द्रि चालन
(ड) जिचलन
(ढ) एचआर ध्िजनक टेलीव्यूअर
(िेध-जछद्र में)
(ण) िणाक्रमीय गामा (िेध-जछद्र में)
(त) आईपी (िेध-जछद्र में)
(थ) चुंबकीय संिेदनिीलता (िेधजछद्र में)

आरपी/पीएल*
ठरपोटा में
संदभा/पृष्ठ
संख्या

ठटप्पजणयां

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]
दस्ट्तािेजी
प्रमाण के

प्राप्त
क्र सं.

कायाकलाप

इकाई

प्रस्ट्ताजित

दकया
गया

इकाई
लागत

साथ
दकया
गया
िास्ट्तजि
क व्यय

(द) उथला होल तापमान
(ध) िेध-जछद्र भू-भौजतकीय लॉबगग
16

रासायजनक जिश्लेषण
(क) िेट रासायजनक जिश्लेषण
(ख) एएएस पद्धजत
(ग) आईसीपी-एमएस/ओईएस
पद्धजत
(छ) एक्स आर एफ तकनीकी
(ज) कोई अन्य पद्धजत

17

प्रस्ट्तर जिज्ञान-जिषयक अध्ययन
(क) चटा ान का पतला खंड
(ख) पठरष्कृ त अनुभाग
(ग) तरल द्वारा भारी खजनज
पृथक्करण
(घ)धारा तलछट के नमूनों से भारी
खजनजों का पृथक्करण
(ड.) समुद्र तट रे त खजनज
(बीएसएम) नमूने का खजनज
अध्ययन
(च) कोई अन्य

18

ईपीएमए / एसईएम अध्ययन

19

खजनजों की पहचान के जलए
एक्सआरडी जिश्लेषण

20

सज्जीकरण अध्ययन के जलए नमूना

21

भू-तकनीकी अध्ययन

22

ठरपोटा तैयार करना

23

मात्रा, श्रेणी और प्रिगा के साथ
स्ट्थाजपत संसाधन, यदद कोई हो

24

यदद खनन पटा ा प्रदान करने के जलए
आिेदन दकया गया था तो जी2
स्ट्तर के अधीन स्ट्थाजपत संसाधन
और भंडार स्ट्थाजपत करने िाली पूिा
व्यिहायाता अध्ययन ठरपोटा राज्य
सरकार को प्रस्ट्तुत की गई है या
नहीं।

आरपी/पीएल*
ठरपोटा में
संदभा/पृष्ठ
संख्या

ठटप्पजणयां

<!-- page 11 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

11
दस्ट्तािेजी
प्रमाण के

प्राप्त
क्र सं.

कायाकलाप

इकाई

प्रस्ट्ताजित

दकया
गया

साथ

इकाई

दकया

लागत

गया
िास्ट्तजि

आरपी/पीएल*
ठरपोटा में

ठटप्पजणयां

संदभा/पृष्ठ
संख्या

क व्यय
25

कोई अन्य जजसे धारक जिजनर्ददष्ट
करना चाहे
द्वारा तैयार :

द्वारा जााँचा गया :

द्वारा अनुमोददत:

ठटप्पण: भूमीिण अनुज्ञापत्र के अधीन की गई भूमीिण संदक्रयाओं और पूिेिण अनुज्ञजप्त के अधीन की गई पूिेिण
संदक्रयाओं के जलए अलग भाग-ख प्रदान करें ।

भाग- ग
अनुपालन ब्यौरे

1. धारा 10क (2) (ख) के उपखंड (ii) का अनुपालन (अथाात् अनुज्ञापत्र धारक या अनुज्ञजप्त धारी ने भूमीिण अनुज्ञापत्र या पूिि
े ण
अनुज्ञजप्त के जनबंधनों और ितों का उल्लंघन नहीं दकया है)

(क) खजनज ठरयायत जनयम, 1960 के जनयम 7 के उपबंधों का अनुपालन (भूमीिण अनुज्ञापत्र धारकों के जलए लागू)
उपजनयम / खंड
7 (i)
7 (ii)
7 (iii)
7 (v)
7 (vi)
7 (xi)

7 (2)

ितें
दो िषा पूरे होने के पश्चात और तीन िषा पूरे होने के पश्चात िेत्र
का आिजधक ्याग
अनुदान आदेि में जिजनर्ददष्ट न्यूनतम व्यय प्रजतबद्धता और जिजिष्ट
िास्ट्तजिक ल्यों का पालन
राज्य सरकार, जीएसआई और आईबीएम को सभी डेटा उपलब्ध
कराना
भूमीिण अनुज्ञापत्र धारक द्वारा खातों का रख-रखाि
राज्य सरकार को छमाही ठरपोटा प्रस्ट्तुत करना (जजस अिजध से
िह संबंजधत है, उसकी समाजप्त के तीन मास के भीतर)
प्र्येक िषा अनुज्ञापत्र िुल्क का संदाय

भूमीिण अनुज्ञापत्र में ऐसी अन्य ितें अंतर्तिष्ट हो सकती हैं जो
कें द्रीय सरकार द्वारा लगाई जा सकती हैं

अनुपालन

ठटप्पजणयां

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

राज्य सरकार के न्द्रीय सरकार के अनुमोदन से अनुज्ञापत्र में िते
7 (3)

लगा सकती है जजन्हें िह खजनज जिकास के जहत में आिश्यक
समझे

(ख) खजनज ठरयायत जनयम, 1960 के जनयम 14, 16 और 18 के उपबंधों का अनुपालन (पूिि
े ण अनुज्ञजप्त धारकों के जलए लागू)

जनयम/ उपजनयम /खंड
14(1)(i)

ितें

अनुपालन

ठटप्पजणयां

प्र्येक िषा या िषा के दकसी भाग में पूिेिण िुल्क का
संदाय
राज्य सरकार को छमाही ठरपोटा प्रस्ट्तुत करना (जजस

16(1)

अिजध से िह संबंजधत है, उसकी समाजप्त के तीन मास के
भीतर)

16(2)
18

राज्य सरकार को पूणा ठरपोटा प्रस्ट्तुत करना (अनुज्ञजप्त की
समाजप्त या पठर्याग या समाजप्त के तीन मास के भीतर)
पूिेिण अनुज्ञजप्त धारक द्वारा लेखाओं का

रख-रखाि

(ग) एमसीडीआर, 1988 के उपबंधों का अनुपालन: भूमीिण अनुज्ञापत्र और पूिि
े ण अनुज्ञजप्त धारकों के जलए लागू
जनयम और प्रािधान

जनयम के अनुसार प्रस्ट्तुत करने की देय तारीख

आईबीएममें

ठटप्पणी

प्राजप्त की
तारीख
जनयम 3क/4: भूमीिण योजना/पूिेिण

जनष्पादन की तारीख से 60 ददनों के भीतर।

योजना
जनयम 3ख/5: भूमीिण योजना में

अपेिानुसार

उपांतरण/पूिेिण योजना में उपांतरण
जनयम 3घ/7: भूमीिण /पूिेिण

भूमीिण संदक्रयाओं के प्रारं भ होने की तारीख से 15

संदक्रयाओं के प्रारं भ होने की सूचना

ददनों के भीतर

जनयम 3ड./8: पहले िषा की ठरपोटा

जनष्पादन की तारीख से प्र्येक िषा की समाजप्त के 30
ददनों के भीतर

जनयम 3ड./8: दूसरे िषा की ठरपोटा

जनष्पादन की तारीख से प्र्येक िषा की समाजप्त के 30
ददनों के भीतर

जनयम3ड./8: तीसरे िषा की ठरपोटा

जनष्पादन की तारीख से प्र्येक िषा की समाजप्त के 30
ददनों के भीतर

2. धारा 10क (2)(ख) के उपखंड (iii) का अनुपालन (अथाात अनुज्ञापत्र धारक या अनुज्ञजप्त धारी इस अजधजनयम के उपबंधों के अधीन
अपात्र नहीं है)

<!-- page 13 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

13

अजधजनयम की धारा 5(1) के अनुपालन में एक िपथ-पत्र प्रस्ट्तुत करना।

3. धारा 10क (2) (ख) के उपखंड (iv) का अनुपालन (अथाात अनुज्ञापत्र धारक या अनुज्ञजप्त धारी, भूमीिण अनुज्ञापत्र या पूिेिण
अनुज्ञजप्त, यथाजस्ट्थजत, की समाजप्त के पश्चात, तीन माह की अिजध के भीतर या ऐसी और अिजध के भीतर जो राज्य सरकार द्वारा यथा
जिस्ट्ताठरत, छह माह से अजधक न हो, पूिेिण अनुज्ञजप्त या खनन पटा ा, यथाजस्ट्थजत, प्रदान करने के जलए आिेदन करने में जिफल नहीं
हुआ है)

अजधजनयम की धारा 5(1) के अनुपालन में िपथ-पत्र प्रस्ट्तुत करना।

द्वारा तैयार :

द्वारा जााँचा गया :

द्वारा
अनुमोददत :

भाग-घ

उपाबंधों के ब्यौरे

क्र.सं.

मद

1

भूमीिण अनुज्ञापत्र आिेदन

2

आबंटन पत्र / आिय का पत्र

3

राज्य सरकार के साथ भूमीिण अनुज्ञापत्र
जिलेख/ समझौता

4

प्रगजतिील अधािार्तषक ठरपोटा

5

अंजतम भूमीिण अनुज्ञापत्र ठरपोटा

6

पूिेिण अनुज्ञजप्त आिेदन

7

पूिेिण अनुज्ञजप्त खोज योजना

8

आबंटन पत्र / आिय पत्र

9
10
11

राज्य सरकार के साथ पूिेिण अनुज्ञजप्त जिलेख/
समझौता
प्रगजतिील ठरपोटा
अंजतम पूिेिण
ठरपोटा

अनुज्ञजप्त / भू िैज्ञाजनक

12

खनन पटा े के जलए आिेदन

13

भूमीिण अनुज्ञापत्र को पूिेिण अनुज्ञजप्त /
पूिेिण अनुज्ञजप्त को खनन पटा े में पठरिर्ततत
करने का आिेदन

उपलब्ध (हां/नहीं)

उपाबंध

संख्या

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

14

प्र्येक िषा अनुज्ञापत्र िुल्क की संदाय रसीद

15

आईटीआर ब्यौरे (खोज की अिजध के जलए)

16

एमएमडीआर अजधजनयम, 1957 की धारा
10क (2)(ख) के अधीन अहाता के जलए दािेदार
का स्ट्ि-प्रमाणन

द्वारा तैयार :

द्वारा जााँचा गया :

[PART II—SEC. 3(i)]

द्वारा स्ट्िीकृ त :
[फा. सं. एम.VI-16/51/2021-खानVI]
डॉ. िीणा कु मारी डरमल, संयुक्त सजचि

MINISTRY OF MINES
NOTIFICATION
New Delhi, the 3rd June, 2022
G.S.R. 415(E).—In exercise of the powers conferred by section 13 read with the second proviso to
clause (b) of sub-section (2) of section 10A of the Mines and Minerals (Development and Regulation) Act,
1957 (67 of 1957), the Central Government hereby makes the following rules, namely:—
CHAPTER I
PRELIMINARY
1.
Short title and commencement.— (1) These rules may be called the Reimbursement of
Exploration Expenditure Rules, 2022.
(2) They shall come into force on the date of their publication in the Official Gazette.
2.

Definitions.— (1) In these rules, unless the context otherwise requires,—
(a) “Act” means the Mines and Minerals (Development and Regulation) Act, 1957 (67 of 1957);
(b) “Claim” means application submitted by the applicant for reimbursement of exploration
expenditure in the Form set forth in the Schedule I;
(c) “Claimant” means the applicant of the claim who was the holder of reconnaissance permit or
prospecting licence and had acquired a right for obtaining a prospecting licence followed by a
mining lease or a mining lease, as the case may be, under clause (b) of sub-section (2) of section
10A of the Act and whose said right had lapsed; and includes the legal representatives, lawful
assignee, lawful transferee or successor by the order of a competent court, as the case may be, of
such holder of reconnaissance permit or prospecting licence;
(d) “date of lapse” means the date of commencement of the Mines and Minerals (Development and
Regulation) Amendment Act, 2021 (i.e., 28th March, 2021), when the right of the holder of
reconnaissance permit or prospecting licence for obtaining a prospecting licence followed by a
mining lease or a mining lease, as the case may be, under clause (b) of sub-section (2) of section
10A of the Act had lapsed under the second proviso to the said clause.
(e) “Form” means Form set forth in the Schedule annexed to these rules.

(2)
The words and expressions used in these rules, but not defined, shall have the same meaning as
assigned to them in the Act or the rules made thereunder.
3.
Applicability.— (1) These rules shall be applicable only to such concession holders or applicants
who had acquired a right for obtaining a prospecting licence followed by a mining lease or a mining lease,

<!-- page 15 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

15

as the case may be, under clause (b) of sub-section (2) of section 10A of the Act and whose said right has
lapsed on the date of lapse.
CHAPTER II
CLAIM PROCESS
4.
Claims for exploration expenditure.— (1) A claimant may submit a claim for reimbursement of
expenditure incurred towards reconnaissance or prospecting operations to the State Government in the
Form set forth in Schedule I to these rules within a period of one year from the date of commencement of
these rules with an intimation to the National Mineral Exploration Trust:
Provided that in cases where the period of permit or licence had not expired before the date of
lapse,—
(a) the claimant may submit the claim within a period of one year from the date of expiry of the
period of permit or licence or date of commencement of these rules, whichever is later; or
(b) the claimant may submit a claim of the expenses incurred by it till the date of lapse after
surrendering such permit or licence to the State Government, within the said period of one year
from such surrender or date of commencement of these rules, whichever is later.
(2) The claimant shall enclose with its claim application, the following, namely:—
(a) the documents necessary to prove payments or expenditure incurred towards exploration activities
undertaken, like bank statements, discharged payment slips, vouchers or invoices with
acknowledgement of settlement, or receipts of payment or other such documents; and
(b) certificate of chartered accountant to the effect that the claim has been duly verified by him.
(3) The State Government shall not proceed with the claims submitted after the period specified in sub-rule
(1):
Provided that the State Government may allow a further period of one year for filing a claim, if the
reasons for delay were beyond the control of the claimant.
5.
Verification by the State Government.— (1) On receipt of a claim application, the State
Government shall verify the following, namely:—
(a)

claimant was the holder of reconnaissance permit or prospecting licence who had acquired a
right for obtaining a prospecting licence followed by a mining lease or a mining lease, as the
case may be, under clause (b) of sub-section (2) of section 10A of the Act and whose said
right has lapsed on the date of lapse; or is the legal representative, lawful assignee, lawful
transferee or successor by the order of a competent court, as the case may be, of such holder
of reconnaissance permit or prospecting licence; and

(b)

claimant, to the satisfaction of the State Government, has—
i)

undertaken reconnaissance operations or prospecting operations, as the case may be, to
establish the existence of mineral contents in such land in accordance with the
parameters as laid down by the Central Government in this behalf;

ii)

not committed any breach of the terms and conditions of the reconnaissance permit or
the prospecting licence;

iii)

not become ineligible under the provisions of the Act and rules made thereunder; and

iv)

not failed to apply for grant of prospecting licence or mining lease, as the case may be,
within a period of three months after the expiry of reconnaissance permit or
prospecting licence, as the case may be, or within such further period not exceeding six
months as may be extended by the State Government:

Provided that in case where the period of permit or licence had not expired before the date of
lapse and the claimant has submitted the claim after the expiry of permit or licence under clause (a)
of the proviso to sub-rule (1) of rule 4, the condition specified in clause (iv) shall not be applicable:

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Provided further that in case where the period of permit or licence had not expired before the
date of lapse and the claimant has submitted claim of the expenses incurred by it till the date of
lapse under clause (b) of the proviso to sub-rule (1) of rule 4, the State Government shall verify that
the conditions specified in clauses (i) to (iii) were complied with by the claimant, as far as practical,
till the date of lapse and the condition specified in clause (iv) shall not be applicable.
(2)
After due verification in accordance with sub-rule (1), and on being satisfied that claimant had the
right to obtain prospecting licence followed by mining lease or mining lease, as the case may be, before the
date of lapse, the State Government may forward the claim to the Reimbursement Assessment Committee
along with its annexures and other relevant documents.
6.
Reimbursement Assessment Committee.— A Reimbursement Assessment Committee shall be
formed at the State level comprising of the following members, namely:—
(a)

Additional Chief Secretary or Principal Secretary or Secretary in-charge of Mining and
Geology of the State, as the Chairman;

(b)

Deputy Director General (State Unit), Geological Survey of India;

(c)

Regional Controller of Mines, Indian Bureau of Mines, of the area concerned;

(d)

Representative of Finance Department of the State Government;

(e)

Director in the Directorate or Department of Mining and Geology of the State Government
(by whatever name called), as Member Secretary; and

(f)

Additional Director, Atomic Mineral Directorate for Exploration and Research to be co-opted
in case of atomic minerals.

7.
Assessment of claim by the Reimbursement Assessment Committee.—(1) On receipt of claim
from the State Government under rule 5, the Reimbursement Assessment Committee shall examine the
work done by the permit holder or licencee, as the case may be, in accordance with the rules for the time
being in force as on the date of lapse.
(2)
The examination shall also include technical evaluation of the work carried out as per the reports
submitted by the permit holder or licencee, as the case may be, during the course of reconnaissance or
prospecting operations undertaken in accordance with the provisions of the Act and rules framed
thereunder; the necessity for carrying out the work so done; reasonability of each item and adherence to
applicable extant rules.
(3) The Reimbursement Assessment Committee shall assess the reimbursement amount based on the actual
expenditure incurred by the claimant on the exploration activities and the said reimbursement amount shall
not exceed the amount given in the approved schedule of charges of such authorities as specified by the
Central Government:
Provided that for special studies not covered under schedule of charges, such as Aero Geophysical
Survey or the like, the Reimbursement Assessment Committee may recommend appropriate reimbursement
based on similar work undertaken by the Geological Survey of India or the Mineral Exploration
Corporation Limited or any other Government agency.
(4) The Reimbursement Assessment Committee may seek clarification or additional information from the
claimant regarding its claim, if required and shall give the claimant a reasonable opportunity of being heard
in case the amount claimed is reduced or rejected by the Committee in its assessment.
(5) Simple interest shall be added in the amount assessed by the Committee at the rate of six per cent. per
annum from the date of submission of application for prospecting licence or mining lease, as the case may
be, till date of commencement of these rules.
(6) The Reimbursement Assessment Committee shall forward to the State Government its assessment
report specifying the reimbursement amount payable to the Claimant as assessed by it including the interest
calculated under sub-section (5).

<!-- page 17 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

17

CHAPTER III
PAYMENT OF REIMBURSEMENT AND RECOUPMENT
8.
Reimbursement.— (1) On receipt of assessment report from the Reimbursement Assessment
Committee, the State Government shall forward the report along with its recommendations on the same to
the National Mineral Exploration Trust established under section 9C of the Act.
(2) The entire process of verification of the claim by State Government under rule 5, assessment by
Reimbursement Assessment Committee under rule 7 and forwarding of approved assessment report by the
State Government to the Trust under sub-rule (1) shall be completed within a period of three months from
the date of receipt of the claim under rule 4.
(3) The Technical-cum-Cost Committee of the National Mineral Exploration Trust shall verify whether
reimbursement amount assessed by the Reimbursement Assessment Committee is in accordance with subrule (3) of rule 7 and finalise the reimbursement amount payable with such modification as may be
required:
Provided that the eligibility of the claimant as verified by the State Government under rule 5 shall be
final.
(4) The National Mineral Exploration Trust may, after such verification, release the finalised amount to be
reimbursed along with the interest calculated in accordance with sub-rule (5) of rule 7, in favour of the
Director in the Directorate or Department of Mining and Geology of the State Government (by whatever
name called) of the State Government within three months from the receipt of assessment report from the
State Government, subject to availability of fund with the Trust.
(5)
The Director in the Directorate or Department of Mining and Geology of the State Government (by
whatever name called) shall further release the finalised amount to the claimant within one month from the
receipt of the amount from the National Mineral Exploration Trust.
9.
Recoupment.— (1) Notwithstanding the pendency of any claim in respect of any area, the State
Government shall process for grant of mineral concessions in respect of such area in accordance with
clause (d) of sub-section (2) of section 10A of the Act and the rules framed thereunder.
(2)
In case of auction of composite licence or mining lease in respect of the area covered under clause
(b) of sub-section (2) of section 10 of the Act where—
(i) notice inviting tender is issued after the date of commencement of these rules; and
(ii) notice inviting tender has been issued but the last date of submission of bids is falling after the
date of commencement of these rules,
the following conditions shall be considered part of the auction conditions specified in the tender document,
namely:—
(a)

the preferred bidder shall deposit the amount reimbursed or to be reimbursed towards
exploration expenditure along with the first instalment of upfront payment or, as the case
may be, performance security to the State Government, if the amount has been finalised by
the Technical-cum-Cost Committee of the National Mineral Exploration Trust; or

(b)

the preferred bidder shall give an undertaking, in writing, to the State Government to deposit
the amount to be reimbursed towards exploration expenditure with the State Government
within one month of its finalisation by the Technical-cum-Cost Committee of the National
Mineral Exploration Trust, if the amount is yet to be finalised;

(c)

the preferred bidder shall also give an undertaking, in writing, to furnish such additional
amount to be reimbursed towards exploration expenditure, which may be modified or
amended by the Revisionary Authority; and

(3)
In case of non-compliance of the conditions specified in sub-rule (2), the State Government shall
take action for forfeiture of first instalment of upfront payment or performance security, as the case may be,
and any other action in accordance with the Mineral (Auction) Rules, 2015:

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Provided that in respect of the atomic minerals where grade of such mineral is equal to or above the
threshold value as specified by the Central Government in Schedule A of the Atomic Minerals Concession
Rules, 2016, the conditions mentioned in sub-rule (2) shall be specified as pre-conditions for grant of
mineral concession.
(4)
On receipt of the amount reimbursed or to be reimbursed towards exploration expenditure from the
preferred bidder as specified in sub-rule (2), the State Government shall deposit the same in the National
Mineral Exploration Trust Fund, before signing the lease deed or within one month of its receipt, whichever
is later.
(5) In case where auction has concluded or the last date of submission of bids is over before the date of
commencement of these rules, the State Government shall deposit the amount reimbursed or to be
reimbursed towards exploration expenditure under these rules in the National Mineral Exploration Trust
Fund from the applicable amount (auction premium) deposited by the lessee under sub-rule (2) of rule 13 of
the Mineral (Auction) Rules, 2015.
(6)
The National Mineral Exploration Trust may request for additional grants from the Central
Government in the Ministry of Mines for disbursal of reimbursement under these rules.
(7) The State Government shall hand over to the preferred bidder the reports along with other proofs of
exploration like preserved core, litho graphs, core photographs, drill log-book and the like, if available or
any geological study report of the area and other such documents submitted by the claimant.
10.
Revision.— Any person aggrieved by an assessment, verification or order made by the State
Government or any authority thereunder, or the Reimbursement Assessment Committee or the Technicalcum-Cost Committee of the National Mineral Exploration Trust may apply to the Revisionary Authority of
the Central Government for revision of the same under section 30 of the Act.
SCHEDULE I
Form for Submission of Claim
[See rule 4(1)]
PART-A
GENERAL INFORMATION
Sl. No.

Item Detail

Particulars

(1)

(2)

(3)

1

Type of Mineral Concession:
Reconnaissance Permit / Prospecting
Licence
Name of Holder of the Mineral
Concession
Legal Status of Claimant (Power of
Attorney/Affidavit/Registered Deed)
(a) Postal Address:

2A

(b) Telephone Number (Office):
(c) Fax Number (Office):
(d) Mobile No.:
(e)Telephone Number (Residence):
(f) E-Mail Id:

2B

Entity Details
Name

<!-- page 19 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

Pan Number
ITR Details
(For the period of exploration)
Aadhar Number
GST/ Service Tax Number
TIN Number
Address
Bank details
Details of Mineral Concession
(a) State:
(b) District (s):
(c) Taluka (s):
3A

(d) Village (s):
Block Name
Area in Ha.
Survey of India Toposheet Number
(s):
Minerals
Block Location (Lat Long of all
corner points a, b, c, d etc)

a) Lat. --- Long---; b) Lat. --- Long---;
c) Lat. --- Long---; d) Lat. --- Long---; e) Lat. ----,
Long ---

Administrative Details
Date of issue of order for grant or issue
of Letter of Intent
Date of execution of the
Reconnaissance Permit/ Prospecting
Licence
Period of the Reconnaissance
Permit/Prospecting Licence
3B

From:
To:

Date of Renewal of the Reconnaissance From:
Permit / Prospecting Licence if any and
To:
period
Date of Final Reconnaissance Permit
/ Prospecting Licence Report
Submission
Resource Estimated with Grade &
Tonnage
Category of Resource (as per UNFC)
Recommendation by Agency
Whether an application for Grant of
Prospecting Licence or mining lease to
a holder of a Reconnaissance Permit or

19

<!-- page 20 -->

20

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Prospecting Licence, as the case may
be, has been submitted before the 12th
January, 2015 {Compliance of sub
clause (i) of Section 10A(2)(b)}
Remarks
Printed on
Printed by

Checked By :
Approved By :

Prepared By :

NAME & SIGNATURE

Note: Provide separate Part-A for the reconnaissance operations conducted under reconnaissance permit
and prospecting operations conducted under prospecting licence.

PART-B
DETAILS OF EXPLORATION ACTIVITIES

Sr.
No.

1

Activity

Unit

Areogeophysical Studies
(a) Aero Gravity
(b) Aero Magnetic
(c) Aero Magnetic (High
Resolution)
(d) Aero Electromagnetic
(AEM)

2

Remote Sensing Studies
(a)
(b)
(c)
(d)

3

Seismic Surveys

4

2D Seismic Reflection survey

5

3D Seismic Reflection Survey

6

DSRS Surveys

7

GPR Surveys

8

Topographical Survey

Scale:

Proposed Achieved

Unit
Cost

Actual
Expenditure Reference/
incurred along Page No in
Remarks
with
RP/ PL*
documentary
Report
proof

<!-- page 21 -->

[भाग II—खण्ड 3(i)]

Sr.
No.

Activity

भारत का राजपत्र : असाधारण

Unit

Area
Covered
(Sq
Km/Hectar
e)
9

Geological Mapping

Scale:
Area
Covered
(Sq
Km/Hectar
e)

10

Surface/ Geochemical Sampling

Area
Covered
(Sq
Km/Hectar
e)

(a) Bed Rock
(b) Soil
(c) Stream Sediment
(d) Channel Sample
(e) Any Others
11

Pitting

Nos:
Excavation:
CBM
Samples

12

Trenching

Nos:
Excavation:
CBM
Samples

13

Surface Geophysical Works
Type of Survey
(a) Gravity Method
(b) Magnetic Method
(c) Self-Potential Method
(d) Induced Polarization
Method
(e) Electrical Resistivity
Method
(f) Resistivity
Profiling/Imaging
(g) Electro Magnetic Survey
(h) Magneto-Telluric (MT)
Surveys
(I) Any Other

14

Drilling

Proposed Achieved

21

Unit
Cost

Actual
Expenditure Reference/
incurred along Page No in
Remarks
with
RP/ PL*
documentary
Report
proof

<!-- page 22 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

Sr.
No.

15

Activity

(a) Core

Mt.

(b) Non Core

Mt.

Geophysical Logging
(a) Base Log
(b) SP
(c) Resistivity
(d) Dual Density
(e) Gamma-Gamma
(f) Neutron
(g) Caliper
(h) Natural Gamma
(i) SPR
(j) Focused Resistivity
(k) Sonic
(l) Temperature & Fluid
Conductivity
(m) Deviation
(n) HR Acoustic Televiewer
(In
Borehole)
(o) Spectral Gamma (In
Borehole)
( p) I.P. (In Borehole)
(q) Magnetic Susceptibility (In
Borehole)
(r) Shallow Hole Temperature
(s) Borehole Geophysical
Logging

16

Chemical Analysis
(a) Wet Chemical Analysis
(b) AAS method
(c) ICP-MS/OES method
(d) XRF technique
(e) Any other method

17

Unit

Petrological Studies
(a) Thin section of rock
(b) Polished Section
(c) Heavy mineral separation
by

Proposed Achieved

Unit
Cost

[PART II—SEC. 3(i)]

Actual
Expenditure Reference/
incurred along Page No in
Remarks
with
RP/ PL*
documentary
Report
proof

<!-- page 23 -->

[भाग II—खण्ड 3(i)]

Sr.
No.

भारत का राजपत्र : असाधारण

Activity

Unit

Proposed Achieved

23

Unit
Cost

Actual
Expenditure Reference/
incurred along Page No in
Remarks
with
RP/ PL*
documentary
Report
proof

liquid
(d) Separation of heavy
minerals
from stream sediment samples
(e) Mineralogical studies of
Beach Sand Minerals
(BSM) sample
(f) Any other
18

EPMA / SEM Studies

19

XRD Analysis for Identification
of Minerals

20

Sample for Beneficiation Study

21

Geotechnical Studies

22

Report Preparation

23

Resources Established if any
with quantity, grade & category

24

In case of application was made
for grant of mining lease then
resources established under G2
Level and whether a prefeasibility study report
establishing reserves have been
submitted to the State
Government or not.

25

Any other that the holder may
wish to specify

Nos

Prepared By :

Checked By :

Approved By :

Note: Provide separate Part-B for the reconnaissance operations conducted under reconnaissance permit
and prospecting operations conducted under prospecting licence.

PART-C
COMPLIANCE DETAILS
1.

Compliance of Sub Clause (ii) of Section 10A (2) (b) (i.e. the permit holder or licencee has not
committed any breach of the terms and conditions of the Reconnaissance Permit or the
Prospecting Licence)
(a) Compliance of Provisions of Rule 7 of Mineral Concession Rules, 1960 (Applicable for
Reconnaissance Permit Holders)

Sub-Rule /
Clause

Conditions

Compliance

Remarks

<!-- page 24 -->

24

THE GAZETTE OF INDIA : EXTRAORDINARY

7 (i)

Periodic Relinquishment of area
after the completion of two
years and after the completion
of three years

7 (ii)

Adherence
to
minimum
expenditure commitment and
specific
physical
targets
specified in the grant order

7 (iii)

Making available all data to the
State Government, GSI & IBM

7 (v)

Maintenance of accounts by the
Reconnaissance Permit holder

7 (vi)

Submission of six monthly
report to the state Government
(within three month of the close
of the period to which it relates)

7 (xi)

Payment of permit fees each
year

7 (2)

Reconnaissance Permit may
contain such other conditions as
may be imposed by the Central
Government

7 (3)

State Government may with the
approval
of
the
Central
Government
may
impose
conditions in the permit as it
may think necessary in the
interest of mineral development

[PART II—SEC. 3(i)]

(b) Compliance of Provisions of Rule 14, 16 & 18 of Mineral Concession Rules, 1960 (Applicable for
Prospecting Licence Holders)

Rule/Sub-Rule/
Clause

Conditions

14(1)(i)

Payment of Prospecting Fee
each year or part of the year

16(1)

Submission of six monthly
report to the State Government
(within three month of the close
of the period to which it relates)

16(2)

Submission of full report to the
State Government (within three
month of the expiry or
abandonment or termination of

Compliance

Remarks

<!-- page 25 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : असाधारण

25

the licence)
18

Maintenance of accounts by the
Prospecting Licence holder

(c) Compliance of Provisions MCDR, 1988: Applicable to both Reconnaissance Permit and
Prospecting Licence Holders
Rule and
Provision

Due Date of Submission as per
Rule

Date of Receipt
in IBM

Remark

Rule 3A / 4: Scheme
of Reconnaissance / Within 60 days from the date of
Scheme of
execution.
Prospecting
Rule 3B/5:
Modification in
Scheme of
Reconnaissance /
Modification in
Scheme of
Prospecting

As per requirement

Rule 3D/7: Notice
of Commencement Within 15 days from the date of
of Reconnaissance / commencement
of
Prospecting
reconnaissance operations
Operations
Rule 3E/8: First
Year Report

Within 30 days after expiry of
every year from the date of
execution

Rule 3E/8: Second
Year Report

Within 30 days after expiry of
every year from the date of
execution

Rule 3E/8: Third
Year Report

Within 30 days after expiry of
every year from the date of
execution

2. Compliance of Sub-Clause (iii) of Section 10A (2)(b) (i.e. the permit holder or licencee has not become
ineligible under the provisions of this Act)

To submit an Affidavit in Compliance of Section 5(1) of the Act.

3. Compliance of Sub-Clause (iv) of Section 10A (2)(b) (i.e. the permit holder or licencee has not failed to
apply for grant of prospecting licence or mining lease, as the case may be, within a period of three months
after the expiry of reconnaissance permit or prospecting licence, as the case may be, or within such further
period not exceeding six months as may be extended by the State Government)

<!-- page 26 -->

26

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

To submit an affidavit in compliance of Section 5 (1) of the Act.

Prepared By :

Checked By :

Approved By :

PART-D
DETAILS OF ANNEXURES

Sl. No.

Item

1

Reconnaissance Permit Application

2

Allocation Letter / Letter of Intent

3

Available (Yes/No)

Reconnaissance Permit Deed /
Agreement with State Govt

4

Progressive Half Yearly Reports

5

Final Reconnaissance Permit Report

6

Prospecting Licence Application

7

Prospecting Licence Exploration Scheme

8

Allocation Letter / Letter of Intent

9

Prospecting Licence Deed / Agreement
with State Govt

10
11

Progressive Reports
Final Prospecting Licence / Geological
Report

12

Application for Mining Lease

13

Application of Converting
Reconnaissance Permit to Prospecting
Licence / Prospecting Licence to Mining
Lease

14

Payment Receipt of Permit Fee each year

15

16

Annexure No

ITR Details
(For the period of exploration)
Self-Certification of Claimant for
Qualifying under Section 10A (2)(b) of
the MMDR Act, 1957

Prepared By :

Checked By :

Approved By :
[F. No. M.VI-16/51/2021-Mines VI]

Dr. VEENA KUMARI DERMAL, Jt. Secy.
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ
Digitally signed by
MANOJ KUMAR VERMA

2022.06.04 16:12:45
KUMAR VERMA Date:
+05'30'
