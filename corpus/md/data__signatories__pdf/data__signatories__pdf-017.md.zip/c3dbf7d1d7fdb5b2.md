---
doc_id: "c3dbf7d1d7fdb5b2"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/e45472f042882d58c9c869d42935d62a.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "The draft Industries (Development and Regulation) Penalty, Adjudication and Appeal Rules, 2024"
date: "2025-06-30"
pages: 10
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "4b4a24aee63e1991"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-10092024-257025
xxxGIDHxxx
CG-DL-E-10092024-257025
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—ख ण् ड 3—उ प-खण् ड (i)
PART II—Section 3—Sub-section (i)
प्राजधक ार से प्रक ाजित
PUBLISHED BY AUTHORITY
सं. 511]
No. 511]

न ई दिल्ली, सोमवार, जसतम्बर 9, 2024/ भाद्र 18, 1946
NEW DELHI, MONDAY, SEPTEMBER 9, 2024/BHADRA 18, 1946

वाजणज्य और उद्योग मंत्रालय
(उद्योग संवधधन और आंतररक व्यापार जवभाग)
अधिसूचना
नई दिल्ली, 9 जसतम्बर, 2024

सा.का.जन. 553(अ).— जनम्नजलजखत मसौिा जनयम, जिसे कें द्र सरकार उद्योग (जवकास और जवजनयम)
अजधजनयम, 1951 की धारा 30 की उप धारा (2) के तहत तैयार करने का प्रस्ट्ताव करती है, को इससे प्रभाजवत होने वाले
सभी संभाजवत आम लोगों और अन्य जहतधारकों की सूचना के जलए प्रकाजित दकया िाता है और यह सूचना िी िाती है दक
आजधकाररक रािपत्र में यथाप्रकाजित उक्त अजधसूचना की प्रजतयां आम लोगों को उपलब्ध कराए िाने की तारीख से तीस
दिनों की अवजध के समाप्त होने पर अथवा उसके बाि उक्त मसौिा जनयम पर कें द्र सरकार द्वारा जवचार दकया िाएगा;
मसौिा जनयमों में जनजहत प्रस्ट्तावों पर यदि कोई व्यजक्त आपजि ििध करना चाहे या सुझाव िेना चाहे तो वह उसे
जनधाधररत अवजध के भीतर जलजखत रूप में सजचव, उद्योग और आंतररक व्यापार संवधधन जवभाग, वाजणज्य और उद्योग
मंत्रालय, वाजणज्य भवन नई दिल्ली-110001 को डाक द्वारा या soil-dipp@nic.in और kapil.meena@nic.in पर
इलेक्ट्राजनक रूप से भेि सकता है।
मसौिा जनयम
उद्योग (जवकास और जवजनयम) अजधजनयम, 1951 (1951 का 65) की धारा 30 की उप धारा (2) के खंड
(त त क) और (त त ख) द्वारा प्रिि िजक्तयों का प्रयोग करते हुए, कें द्र सरकार एतद्द्वारा जनम्नजलजखत जनयम बनाती है,
नामतः 5778 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTR AOR DINAR Y

1.

[PART II—SEC. 3(i)]

संज िप्त नाम और आरंभ - (1) इन जनयमों को मसौिा उद्योग (जवकास और जवजनयम) िाजस्ट्त, न्यायजनणध य न और
अपील, जनयम, 2024 कहा िाएगा।
(2) ये जनयम आजधकाररक रािपत्र में इनके प्रकािन की तारीख से प्रवृत्त होंगे।

2.

प ररभाषाएं –
(1) इन जनयमों में, िब तक दक अन्यथा संिभध अपेजित न हो, (क) ‘अजधजनयम’ से उद्योग (जवकास और जवजनयम) अजधजनयम, 1951 (1951 का 65) अजभप्रेत है;
(ख) "न्यायजनणधयन अजधकारी" से अजधजनयम की धारा 24क की उप-धारा (1) के तहत अजधकृ त जिला मजिस्ट्रेट
अथवा अजतररक्ट्त जिला मजिस्ट्रेट अजभप्रेत है;
(ग)

"अपीलकताध" से ऐसा व्यजक्त अजभप्रेत है, िो न्यायजनणधयन अजधकारी के आिेि से असंतुष्ट है और अजधजनयम की
धारा 24ख की उप-धारा (1) के तहत अपीलीय प्राजधकारी के समि अपील प्रस्ट्तुत करता है;

(घ) "अपीलीय प्राजधकारी" से अजधजनयम की धारा 24ख की उप-धारा (1) के तहत प्राजधकृ त अजधकारी अजभप्रेत है;
(ड.) “प्रपत्र” से इन जनयमों में संलग्न प्रपत्र अजभप्रेत है।
(2) इन जनयमों में प्रयुक्त उन िब्िों और अजभव्यजक्तयों, िो जनयम में पररभाजषत नहीं है, परंतु अजधजनयम में
पररभाजषत हैं, का वही अथध होगा, िो अजधजनयम में उनके जलए जनधाधररत है।
3.

िांच करना –

(1)

अजधजनयम की धारा 24क के तहत िाजस्ट्त के न्यायजनणधयन के प्रयोिन के जलए, इसमें जवजनर्िधष्ट दकसी धारा के
दकसी प्रावधान के उल्लंघन को ििाधते हुए दकसी जिकायत के प्राप्त होने पर, न्यायजनणधयन अजधकारी ऐसे व्यजक्त को
प्रपत्र-I में नोरटस िारी करेगा, जिसमें उसे नोरटस में जवजनर्िधष्ट अवजध के भीतर (िो दक तामील की तारीख से सात
दिन की अवजध से कम न हो) कारण बताना अपेजित होगा दक उसके जवरुद्ध िांच क्ट्यों नहीं की िानी चाजहए।

(2)

उप-जनयम (1) के तहत प्रत्येक नोरटस में, दकए गए कजथत उल्लंघन की प्रकृ जत का उल्लेख होगा।

(3)

ऐसे व्यजक्त द्वारा प्रस्ट्तुत दकए गए कारण, यदि कोई हो, पर जवचार करने के बाि, यदि न्यायजनणधयन अजधकारी की
राय है दक िांच की िानी चाजहए, तो वह उस व्यजक्त को नोरटस में यथाजनधाधररत तारीख को व्यजक्तगत रूप से
उपजस्ट्थत होने के जलए या उसके द्वारा जवजधवत रुप से अजधकृ त प्रजतजनजध के िररए उपजस्ट्थत होने के जलए एक
नोरटस िारी करेगा।

(4)

जनयत तारीख को, न्यायजनणधयन अजधकारी, उस व्यजक्त जिसके जवरूद्ध कायधवाही िुरू की गई है, या उसके अजधकृ त
प्रजतजनजध को, उस व्यजक्त द्वारा दकए गए उल्लंघन और जिस उल्लंघन के संबंध में आरोप लगाया गया है उसके
संबंध में अजधजनयम के प्रावधानों के बारे में स्ट्पष्ट रूप से समझाएगा।

(5)

तत्पश्चात, न्यायजनणधयन अजधकारी द्वारा, उस व्यजक्त को प्रपत्र-II के तहत ऐसे िस्ट्तावेि या साक्ष्य प्रस्ट्तुत करने का
अवसर दिया िाएगा, जिन्हें वह िांच के जलए प्रासंजगक समझे और यदि आवश्यक हो, तो सुनवाई को दकसी
आगामी तारीख (पहली तारीख से अजधकतम पंद्रह दिनों तक हो और अजधकतम तीन तारीखों तक) तक स्ट्थजगत
दकया िा सकता है और ऐसे साक्ष्य लेने में न्यायजनणधयन अजधकारी, भारतीय साक्ष्य अजधजनयम, 2023 (2023 का
47) के प्रावधानों का पालन करने के जलए बाध्य नहीं होगा।

(6)

इन जनयमों के अंतगधत िांच करते समय न्यायजनणधयन अजधकारी, मामले के तथ्यों और पररजस्ट्थजतयों से पररजचत
दकसी भी ऐसे व्यजक्त से साक्ष्य िेने या कोई िस्ट्तावेि प्रस्ट्तुत करने की अपेिा कर सकता है तथा उसे बुला सकता है ,
िो न्यायजनणधयन अजधकारी की राय में िांच की जवषय-वस्ट्तु के जलए उपयोगी या संगत हो सकता है।

(7)

यदि कोई व्यजक्त उप-जनयम (3) के अंतगधत दकए गए प्रावधान के अनुसार न्यायजनणधयन अजधकारी के समि
उपजस्ट्थत होने में जवफल रहता है, उपेिा करता है या उपजस्ट्थत होने से इनकार करता है, तो न्यायजनणधयन
अजधकारी, ऐसे व्यजक्त की अनुपजस्ट्थजत में, ऐसा करने के कारणों को ििध करने के बाि, िांच को आगे बढा सकता है।

(8)

यदि, न्यायजनणधयन अजधकारी के समि प्रस्ट्तुत दकए गए साक्ष्य पर जवचार करने पर, न्यायजनणधयन अजधकारी संतु ष्ट
हो िाता है दक व्यजक्त ने उल्लंघन दकया है, तो वह जलजखत आिेि द्वारा, अजधजनयम के अनुसार, ऐसी िाजस्ट्त लगा

<!-- page 3 -->

[भाग II—खण् ड 3(i)]

भारत का रािपत्र : असाधारण

3

सकता है, िो वह उजचत समझे।
(9)

उप-जनयम (8) के तहत दकए गए प्रत्येक आिेि में इस अजधजनयम के उन प्रावधानों को जनर्िधष्ट दकया िाएगा,
जिनके संबंध में उल्लंघन दकया गया है और उसमें िाजस्ट्त लगाने के कारणों को िाजमल दकया िाएगा।

(10) उप-जनयम (8) के तहत दिए गए प्रत्येक आिेि पर तारीख अंदकत होगी और उस पर न्यायजनणधयन अजधकारी के
हस्ट्तािर होंगे।
(11) इस जनयम के तहत दिए गए आिेि की एक प्रजत और कायधवाही की अन्य सभी प्रजतयां उस व्यजक्त को जबना दकसी
िुल्क के िी िाएंगी, जिसके जवरुद्ध िांच की गई थी।
(12) न्यायजनणधयन अजधकारी, उस व्यजक्त जिसके जवरुद्ध िांच की गई थी, को नोरटस िारी करने के छ: माह के भीतर
कायधवाही पूरी करेगा।
(13) इन जनयमों के तहत िारी कोई नोरटस अथवा आिेि जनम्न में से दकसी एक जवजध से उस व्यजक्त को दिया िाएगा,
जिसके जवरुद्ध िांच की िा रही है, नामत: (i)

उक्ट्त व्यजक्त अथवा उसके अजधकृ त प्रजतजनजध को िेना या जभिवाना; अथवा

(ii)

व्यजक्त को उसके आवास पर अथवा उसके अंजतम ज्ञात पते पर अथवा उसके अंजतम व्यावसाजयक पते अथवा
उस कायधस्ट्थल पर िहां वह व्यजक्तगत रूप से कायध करता है अथवा उस पते पर, िहां उसने लाभ प्राजप्त के
जलए अंजतम बार कायध दकया था, इलेक्ट्रॉजनक माध्यम अथवा रजिस्ट्टडध पोस्ट्ट अथवा स्ट्पीड पोस्ट्ट के िररए;
अथवा

(iii) यदि खंड (i) अथवा (ii) में जवजनर्िधष्ट दकसी भी तरीके से नोरटस की तामील नहीं की िा सकती तो उस
पररसर के बाहरी िरवािे पर अथवा जवजिष्ट जहस्ट्से पर उसे जचपकाया िाएगा िहां वह व्यजक्त रहता है
अथवा अंजतम बार रहा है अथवा व्यवसाय दकया है अथवा व्यजक्तगत रूप से करता है अथवा लाभ हे तु कायध
दकया था।
4.

अपीलः-

(1) कोई व्यजक्त, िो इन जनयमों के तहत न्यायजनणधयन अजधकारी के आिेि से असंतुष्ट है तो वह अजधजनयम की धारा
24ख की उप-धारा (2) के तहत अपीलीय प्राजधकारी के समि प्रपत्र III में अपील कर सकता है।
(2) यह अपील, आिेि की तारीख से साठ दिनों के भीतर अपीलीय प्राजधकारी के समि िायर की िाएगी: बिते दक
अपीलीय प्राजधकारी, जिस मामले में साठ दिन की अवजध की समाजप्त के पश्चात भी अपील को न स्ट्वीकार करने का
पयाधप्त कारण मौिूि है, अपील को स्ट्वीकार कर सकता है और वह जलजखत में अवजध के जवस्ट्तार के कारणों को ििध
करेगा।
(3) अपील के साथ जनयम 3 के उप-जनयम (8) के तहत िारी न्यायजनणधयन अजधकारी के आिेि की प्रजत संलग्न होगी तथा
उन तथ्यों का स्ट्पष्ट जववरण प्रिान दकया िाएगा, जिनके जवरुद्ध अपील की गई है, अपील का आधार तथा
अजधजनयम की संगत धारा का उल्लेख होगा।
(4) अपील, अपीलकताध द्वारा स्ट्वयं अथवा जवजधवत रूप से अजधकृ त अपने प्रजतजनजध द्वारा जलजखत रूप से अथवा
रजिस्ट्टडध पोस्ट्ट अथवा स्ट्पीड पोस्ट्ट अथवा इलेक्ट्रॉजनक माध्यम से िायर की िाएगी।
(5) डाक से भेिी गई अपील, अपीलीय प्राजधकारी के समि उस तारीख को िायर मानी िाएगी, जिस तारीख को वह
प्राप्त हुई है।
(6) यदि िांच करने पर अपील सही पाई िाती है, तो इसे स्ट्वीकार कर जलया िाएगा और यदि अपील त्रुरटपूणध पाई
िाती है, तो अपीलीय प्राजधकारी त्रुरट के बारे में अपीलकताध को सूजचत करेगा तथा उसे पंद्रह दिनों के भीतर उस त्रुरट
को ठीक करने की अनुमजत िेगा एवं यदि अपीलकताध इस समयावजध के भीतर ऐसी त्रुरट को ठीक करने में जवफल
रहता है तो अपीलीय प्राजधकारी आिेि द्वारा तथा जलजखत रूप में कारण ििध करके ऐसी अपील को पंिीकृ त करने से
इनकार कर सकता है तथा अपीलकताध को ऐसी अस्ट्वीकृ जत की सूचना सात दिन की अवजध के भीतर िेनी होगी।
अपील स्ट्वीकार होने पर, अपीलीय प्राजधकारी, उस न्यायजनणधयन अजधकारी को अपील की एक प्रजत भेिेग ा, जिसके
जवरुद्ध अपील की गई है, साथ ही एक नोरटस भी िेगा जिसमें अपीलीय प्राजधकारी को उक्त नोरटस में जनधाधररत

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTR AOR DINAR Y

[PART II—SEC. 3(i)]

अवजध के भीतर, िो तीस दिन से अजधक नहीं होगी, अपना उिर प्रस्ट्तुत करने के जलए कहा िाएगा। नोरटस,
व्यजक्तगत रूप से या पंिीकृ त डाक या स्ट्पीड पोस्ट्ट या इलेक्ट्रॉजनक माध्यम से भेिा िा सकता है।
(7) अपील स्ट्वीकार होने पर, अपीलीय प्राजधकारी उस व्यजक्त को अपील की एक प्रजत भेिेगा जिसके जवरुद्ध अपील की
गई है, साथ ही एक नोरटस भी िेगा जिसमें उसे अपीलीय प्राजधकारी द्वारा उक्त नोरटस में जनधाधररत अवजध के भीतर,
िो तीस दिन से अजधक नहीं होगी, अपना उिर प्रस्ट्तुत करने के जलए कहा िाएगा।
(8) नोरटस, व्यजक्तगत रूप से अथवा रजिस्ट्टडध पोस्ट्ट से अथवा स्ट्पीड पोस्ट्ट से अथवा इलेक्ट्रॉजनक माध्यम से उपलब्ध
कराया िाएगा।
(9) अपीलीय प्राजधकारी, संबंजधत न्यायजनणधयन अजधकारी से कायधवाही से संबंजधत अजभलेख मांगवा सकता है।
(10) अपीलीय प्राजधकारी, अपील के पिकारों को सुनवाई का अवसर प्रिान करने के पश्चात, ऐसा आिेि पाररत करेगा
जिसे वह उजचत समझता है।
(11) अपीलीय प्राजधकारी अपील स्ट्वीकार करने की तारीख से साठ दिनों के भीतर अपील का जनपटान कर िेगा।
5.

समयावजध बढाना - न्यायजनणधयन अजधकारी अथवा अपीलीय प्राजधकारी, जलजखत रूप में ििध दकए िाने वाले
कारणों से, िहां कायधवाही करने में जवलंब या जवफल रहने के उजचत कारण मौिूि हैं, इन जनयमों में जवजनर्िधष्ट दकसी
अवजध को तब तक बढा सकता है, जिसे वह उजचत समझता है।

6.

आिेि और िाजस्ट्त –

(1) इन जनयमों के तहत प्रत्येक आिेि पर तारीख अंदकत होगी, हस्ट्तािर दकए िाएंगे तथा सभी पिों को सूजचत दकया
िागा।
(2) इन जनयमों के तहत िाजस्ट्त के िररए वसूली गई समस्ट्त राजि भारत की संजचत जनजध में िमा की िाएगी।
[फा. सं. 9(8)/2020-आईएल]
बालामुरुगन िेवराि, संयुक्त सजचव
प्र प त्र —I
[जनयम 3 का उप-जनयम (1) िेख]ें
सेवा में,
……………………………
……………………………
…………………………..
कारण बताओ नोरटस
जवषय: उद्योग (जवकास और जवजनयमन) अजधजनयम, 1951 का उल्लंघन।
महोिय/महोिया,
दिनांक …….. (प्रजतजलजप संलग्न) को प्राप्त सूचना के अनुसार ................पर उद्योग (जवकास और जवजनयम)
अजधजनयम, 1951 की धारा …………………….. का उल्लंघन दकया गया है
2. उपयुधक्ट्त उल्लंघन के जलए िाजस्ट्त लगाई िा सकती है। अतः, आप यह नोरटस प्राप्त होने से .............दिनों के भीतर
कारण बताएं दक िाजस्ट्त लगाने के जलए उद्योग (जवकास और जवजनयम) अजधजनयम, 1951 की धारा 24क के तहत आपके
जवरुद्ध िांच क्ट्यों न िुरू की िाए। यदि जनधाधररत अवजध के भीतर उत्तर प्राप्त नहीं होता है, तो अजधजनयम के तहत आगे
की कारधवाई की िाएगी।
न्यायजनणधयन अजधकारी
दिनांक और स्ट्थान ………………….

<!-- page 5 -->

[भाग II—खण् ड 3(i)]

भारत का रािपत्र : असाधारण

5

प्र प त्र -II
उल् लंघनकताध द्वारा अथवा उसकी ओर से िस्ट्तावेि अथवा साक्ष्य प्र स्ट्तुत करना
[जनयम 3 का उप जनयम (5) िे ख]ें
सेव ा म ,ें
………………………………….
……………………………………
……………………………………

1. म /ैं हम, …………………………………………………………………………………………
…………………………………………………………………………………………
………………………………………………………………………………………….….,
दिनांक....................... के कारण बताओ नोरटस के संिभध में एतद्द्वारा, जनम्नानुसार बयान प्रस्ट्तुत करते हैं।
….…………………………………………………………………………………………………
………………………………………………………………………………
2. जपन कोड सजहत पूरा पता और राज्य, मोबाइल नंबर और ई-मेल
3. उल्लंघनकताध अथवा उसके अजधकृ त प्रजतजनजध के हस्ट्तािर:
4. हस्ट्तािर करने वाले व्यजक्त का नाम व मोबाइल नंबर
प्र प त्र-III
अप ील
[जनयम 4 का उप-जनयम (1) िेख]ें
सेवा में,
अपीलीय प्राजधकारी,
……………………………………..
……………………………………….
1.

2.

आवेिक का जववरण:
(i)

नाम:

(ii)

पत्राचार का पता:

(iii)

फोन नंबर:

(iv)

ई-मेल:

अपील का आधार:
(न्यायजनणधयन अजधकारी के आिेि की प्रजत संलग्न की िाए)

<!-- page 6 -->

6
3.
4.

THE GAZETTE OF INDIA : EXTR AOR DINAR Y

[PART II—SEC. 3(i)]

न्यायजनणधयन अजधकारी के आिेि की तारीख:
तथ्यों का जववरण:

मैं/हम…………., अपीलकताध यह घोषणा करता हं/करते हैं दक यहां उजल्लजखत तथ्य मेरी/हमारी सवोिम िानकारी,
सूचना और जवश्वास के अनुसार सही हैं।
5. अपीलकताध के हस्ट्तािर और तारीख:
6. अपीलकताध का नाम:

MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
NOTIFICATION
New Delhi, the 9th September, 2024
G.S.R. 553(E).—The following draft rules which the Central Government proposes to make under sub section (2) of section 30 of the Industries (Development and Regulations) Act, 1951 is hereby published for
information of the public and other stakeholders likely to be affected and not ice is hereby given that the said draft
rules will be taken into consideration by the Central Government on or after the expiry of thirty days from the date o n
which copies of this notification as published in the Gazette of India are made available to the public;
Any person interested in making any objection or suggestion on the proposals contained in the draft rules
may do so in writing within the period so specified to the Secretary, Department For Promotion of Industry And
Internal Trade, Ministry of Commerce and Industry, Vanijya Bhawan, New Delhi-110001 by post, or electronically at
soil-dipp@nic.in and kapil.meena@nic.in.
DRAFT RULES
In exercise of the powers conferred by clauses (ppa) and (ppb) of sub-section (2) of section 30 of the
Industries (Development and Regulation) Act, 1951(65 of 1951), the Central Government hereby makes the followin g
rules, namely:1. Short title and commencement. —
(1) These rules may be called the draft Industries (Development and Regulation) Penalty, Adjudication and
Appeal Rules, 2024.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. Definitions. —
(1) In these rules, unless the context otherwise requires, —
(a) "Act" means the Industries (Development and Regulation) Act, 1951(65 of 1951);
(b)"adjudicating officer" means the District Magistrate or the Additional District Magistrate
authorised under sub-section (1) of section 24A of the Act;
(c) "appellant" means a person aggrieved with an order of adjudicating officer and prefers an appeal
before the appellate authority under sub-section (1) of section 24B of the Act;
(d)"appellate authority" means an officer authorised under sub - section (1) of section 24B of the
Act;
(e) "form" means a form appended to these rules.
(2)
The words and expressions used in these rules and not defined, but defined in the Act, shall have the
same meanings respectively assigned to them in the Act.
3. Holding of inquiry. —
(1) For the purpose of adjudication of penalties under section 24A of the Act, on receipt of any complaint
indicating any contravention of any provision of any section specified therein, the adjudicating officer shall,

<!-- page 7 -->

[भाग II—खण् ड 3(i)]

भारत का रािपत्र : असाधारण

7

issue a notice in Form-I to such person, requiring him to show cause within such period as may be specified
in the notice (being not less than seven days from the date of service thereof) why an inquiry should not be
held against him.
(2) Every notice under sub-rule (1) shall indicate the nature of contravention alleged to have been committed.
(3) After considering the cause, if any, shown by such person, the adjudicating officer is of the opinion that
an inquiry should be held, he shall issue a notice requiring the appearance of that perso n personally or
through a representative duly authorised by him on such date as may be fixed in the notice.
(4) On the date fixed, the adjudicating officer shall explain to the person proceeded against or his authorised
representative, the contravention committed by such person and the provision of the Act, in respect of wh ich
contravention is alleged to have been committed.
(5) The adjudicating officer shall, then, give an opportunity to such person to produce such documents or
evidence under Form-II as he may consider relevant to the inquiry and if necessary, the hearing may be
adjourned to a future date (not later than fifteen days from the first date and up to a maximum of three dates)
and in taking such evidence the adjudicating officer shall not be bou nd to observe the provisions of the
Bhartiya Sakshya Adhiniyam, 2023 (47 of 2023).
(6) While holding an inquiry under these rules, the adjudicating officer may require and enforce the
attendance of any person acquainted with the facts and circumstances of the case to give evidence or to
produce any document which in the opinion of the adjudicating officer may be useful for or relevant to the
subject matter of the inquiry.
(7) If any person fails, neglects or refuses to appear as required under sub -rule (3) before the adjudicating
officer, the adjudicating officer may proceed with the inquiry in the absence of such person after recording
the reasons for doing so.
(8) If, upon consideration of the evidence produced before the adjudicating officer, the adjudica ting officer is
satisfied that the person has committed the contravention, he may by order in writing, impose such penalty
under the Act as he considers reasonable.
(9) Every order made under sub-rule (8) shall specify the provision of the Act in respect of which
contravention has been committed and shall contain the reasons for imposing the penalty.
(10) Every order made under sub-rule (8) shall be dated and signed by the adjudicating officer.
(11) A copy of the order made under this rule and all other co pies of proceedings shall be supplied free of
cost to the person against whom the inquiry was held.
(12) The adjudicating officer shall complete the proceeding within six months from the issuance of the notice
to the person against whom the inquiry was held.
(13) A notice or an order issued under these rules shall be served on the person against whom an inquiry is
held, in any of the following manner, namely:(i) by delivering or tendering it to that person or his authorised representative; or
(ii) by sending it to the person through electronic means or by registered post or speed post to the
address of his place of residence or his last known place of residence or the place where he carried
on or last carried on, business or personally works or last worked for gain; or
(iii) If it cannot be served in the manner specified under clauses (i) or (ii), by affixing it on the outer
door or some other conspicuous part of the premises in which that person resides or is known to
have last resided or carried on business or personally works or has worked for gain.
4. Appeal. —
(1) Any person aggrieved by an order of the adjudicating officer under these rules, may prefer an
appeal to the appellate authority under sub-section (2) of section 24B of the Act in Form -III.
(2) The appeal shall be filed with the appellate authority within a period of sixty days from the date
of the order: Provided that, the appellate authority may, where sufficient cause for not preferring the
appeal within such period of sixty days is given, he may admit the appeal and record the reasons fo r
such extension in writing.
(3) The appeal shall be accompanied by a copy of order of adjudicating officer issued under sub rule (8) of rule 3 and a clear statement of facts appealed against, the groun ds for appeal and the
relevant section of the Act.

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTR AOR DINAR Y

[PART II—SEC. 3(i)]

(4) The appeal shall be filed by the appellant in person or by his duly authorised representative in
writing duly appointed in this behalf, or by registered post or speed post or through electronic
means.
(5) The appeal sent by post shall be deemed to have been filed to the appellate authority on th e d a y
it is received.
(6) If on scrutiny, the appeal is found to be in order, it shall be admitted and in case the appeal is
found to be defective, the appella nt authority shall intimate the appellant about the defects and
allow him to rectify the defects within fifteen days and if the appellant fails to rectify such defects
within the time period, the appellant authority may by order and reasons to be recorded in writing,
decline to register such appeal and communicate such refusal to the appellant with a period of seven
days thereof. On admission of the appeal, the appellate authority shall serve a copy of app ea l u p o n
the adjudicating officer against whom the a ppeal is sought along with a notice requiring him to file
his reply thereto, within such period, not exceeding thirty days, as may be stipulated by the
appellate authority in the said notice. The notice may be served by hand or by registered post or
speed post or through electronic means.
(7) On admission of the appeal, the appellate authority shall serve a copy of appeal upon the perso n
against whom the appeal is sought along with a notice requiring him to file his reply thereto, within
such period, not exceeding thirty days, as may be stipulated by the appellate authority in the said
notice.
(8) The notice may be served by hand or by registered post or speed post or through electronic
means.
(9) The appellate authority may call for the records relating t o the proceedings from the respective
adjudicating officer.
(10) The appellate authority may, after giving the parties to the appeal an opportunity of being
heard, pass such orders as he may consider reasonable.
(11) The appellate authority shall dispose of the appeal within sixty days from the date of
admission of appeal.
5. Extension of time. — The adjudicating officer or the appellate authority may, for reasons to be recorded in writin g,
where there is a reasonable cause for the delay or failure to act, extend any period specified in these rules till such
period as he considers reasonable.
6. Order and penalties. —
(1) Every order under these rules, shall be dated, signed and communicated to all the parties.
(2) All sums realised by way of penalties under these rules shall be credited to the Consolidated Fund of
India.
[F. No. 9(8)/2020-IL]
BALAMURUGAN DEVRAJ, Jt. Secy.

Form —I
[See sub-rule (1) of rule 3]
To
……………………………
……………………………
…………………………..
SHOW CAUSE NOTICE
Sub: Contravention of the Industries (Development and Regulation) Act, 1951.
Sir/Madam,
As per intimation …………………….. dated (copy enclosed), a contravention has been committed under
………..…………section of the Industries (Development and Regulation) Act, 1951 at ……………………..

<!-- page 9 -->

[भाग II—खण् ड 3(i)]

भारत का रािपत्र : असाधारण

9

2.
The above contravention is liable for penalty. Therefore, you are required to show cause within a period of
……………. days of service of this notice, why an inquiry should not be initiated against you under section 24A of
the Industries (Development and Regulation) Act, 195 1 for imposition of penalty. In case, no reply is received within
the given period, further action shall be taken under the said Act.
Adjudicating officer
Date and place ………………….

FORM-II
Furnishing of document or evidence by or on behalf of the contravener
[See sub-rule (5) of rule 3]
To
………………………………….
……………………………………
……………………………………

1.

I / we …………………………………………………………………………………………
…………………………………………………………………………………………
………………………………………………………………………………………….hereby give a
statement in reference to the show cause notice dated
….………………………………………………………………………………………
…………………………………………………………………………………………

2.

Complete address including postal index number/code and state along with mobile number and e -mail:

3.

Signature of the contravener or his authorized representative:

4.

Name of the person along with mobile number who has signed:

FORM-III
Appeal
[See sub-rule (1) of rule 4]
To
Appellate Authority,
……………………………………..
……………………………………….
1.

2.

Particulars of appellant:
(i)

Name:

(ii)

Address for correspondence:

(iii)

Contact Number:

(iv)

Email:

Grounds of appeal:
(A copy of order of adjudicating officer to be enclosed)

3.

Date of order of the adjudicating officer:

<!-- page 10 -->

10
4.

THE GAZETTE OF INDIA : EXTR AOR DINAR Y

[PART II—SEC. 3(i)]

Statement of facts:

I/We………, the appellant hereby declare that the facts stated herein a bove are correct to the best of my/our
knowledge, information and belief.
5.

Signature of appellant and date:

6.

Name of appellant:

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

AMIT KUMAR
JAISWAL

Digitally signed by AMIT
KUMAR JAISWAL
Date: 2024.09.10 16:18:08
+05'30'
