---
doc_id: "c2286af4bdfa1ccd"
source_url: "https://steel.gov.in/sites/default/files/2026-03/Shri%20Anurag%20Kapil%2C%20Director%20%28Finance%29%2C%20NMDC.pdf"
ministry: "Steel (MoS)"
title: "Download Appointment orders of Shri Anurag Kapil as Director(Finance), NMDC Limited (PDF, KB)     Download"
date: "2026-03"
pages: 2
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "e47430c9d16d69a8"
---

<!-- page 1 -->

WINo. S-14013/1/2024-BLA
URd UPR/Government of India
Rd HAHa/Ministry of Steel
(बोर्ड स्तरीय नियुक्ति प्रकोष्ठ)|80810 | ०५७। Appointment Cell)
GPOA 3, Netaji Nagar, New Delhi
Date: 18!" March, 2026
ORDER
The President is pleased to appoint Shri Anurag Kapil, IRAS, ED, Finance
Expenditure, Railway Board to the post of Director (Finance), NMDC Limited, on
immediate absorption basis, in the scale of pay of Rs. 1,80,000-3,40,000/-(IDA) for a
period of five (5) years from the date of his assumption of charge of the post, or until
further orders, whichever is earlier.
2. Detailed Terms and Conditions of appointment of Shri Anurag Kapil as
Director (Finance), NMDC Limited will be issued in due course.
Lo b:
_ Abe ge’
(QF a/Subhendu Hota)
उप सचिव, भारत सरकार
Deputy Secretary to the Govt. of India
To
1. Shri Anurag Kapil, ED Finance Expenditure, Railway Board with request to get
relieved from the parent organisation and join the post, immediately.
2. Chairman and CEO, Railway Board, Rail Bhawan, New Delhi with request to
relieve the officer accordingly.
3. CMD, NMDC with request to send a copy of the charge assumption report.
4. Company Secretary, NUDC
5. Secretariat of Appointments Committee of the Cabinet (ACC) [Shri Aman
Kumar Sinha, Under Secretary], Department of Personnel & Training w.r.t. the
communication No. 17/13/2025-EO(ACC) dated 17.03.2026
6. Secretary, Department of Public Enterprises, New Delhi
7. Secretary, Public Enterprises Selection Board (PESB), Block No. 14, PE
Bhawan, CGO Complex, Lodi Road, New Delhi
8. O/o HSM/ MoS (Steel)
9. O/o Secretary (Steel)
10. AS&FA/ JS(AN)/ JS(DNP)/ JS(VKT)/ EA/ JS(SM)/ DDG
11. NMDC Division / Vigilance Division
12. Guard File

<!-- page 2 -->

€- S-14013/1/2024-BLA
भारत सरकार
इस्पात मंत्रालय
(बोर्ड स्तरीय नियुक्ति प्रकोष्ठ)
जीपीओए 3, नेताजी नगर, नई दिल्‍ली
दिनांक : 18.03.2026
आदेश
राष्ट्रपति द्वारा श्री अनुराग कपिल, आईआरएएस, कार्यकारी निदेशक, वित्त व्यय, रेलवे बोर्ड
को एनएमडीसी लिमिटेड में निदेशक (वित्त) के पद पर तत्काल अवशोषण (॥#रता8तांह्वां७ 4050|#0ा)
के आधार पर ₹1,80,000-3,40,000/- (आईडीए) वेतनमान में, उनके पदभार ग्रहण करने की तिथि
से पांच (05) वर्ष की अवधि के लिए या अगले आदेश तक, जो भी पहले हो, नियुक्त किया जाता है।
2. श्री अनुराग कपिल की एनएमडीसी लिमिटेड के निदेशक (वित्त) के रूप में नियुक्ति से
संबंधित नियम एवं शर्तों को अत्रग से सूचित किया जाएगा।
A
(शुभेन्दु होता)
उप सचिव, भारत सरकार
प्रतिलिपि:
1. श्री अनुराग कपिल, आईआरएएस, कार्यकारी निदेशक, वित्त व्यय, रेलवे बोर्ड
2. अध्यक्ष एवं मुख्य कार्यकारी अधिकारी, रेलवे बोर्ड, रेल भवन, नई दिल्‍ली
3. अध्यक्ष एवं प्रबंध निदेशक, एनएमडीसी लिमिटेड
4. कंपनी सचिव, एनएमडीसी लिमिटेड
5. मंत्रिमंडल की नियुक्ति समिति (एसीसी) सचिवालय (श्री अमन कुमार सिन्हा, अवर सचिव),
कार्मिक एवं प्रशिक्षण विभाग को दिनांक 17.03.2026 के पत्र सं. 17/13/2025-£0(७00)
के संदर्भ में।
6. सचिव, लोक उद्यम विभाग, नई दिल्‍ली
7. सचिव, ल्रोक उद्यम चयन बोर्ड (पीईएसबी), ब्लॉक सं. 14, पीई भवन, सीजीओ कॉम्प्लेक्स,
लोधी रोड, नई दिल्‍ली
8. माननीय इस्पात मंत्री का कार्यालय
9. माननीय इस्पात राज्य मंत्री का कार्यालय
10. सचिव (इस्पात) का कार्यालय
11. अपर सचिव एवं वित्तीय सलाहकार/ संयुक्त सचिव (एएन)/संयुक्त सचिव (डीएनपी)/ संयुक्त
सचिव (वीकेटी)/ संयुक्त सचिव (एसएम)/उपमहानिदेशक/आर्थिक सलाहकार का कार्यालय
12. एनएमडीसी प्रभाग/सतर्कता प्रभाग
13. गार्ड फाइल
