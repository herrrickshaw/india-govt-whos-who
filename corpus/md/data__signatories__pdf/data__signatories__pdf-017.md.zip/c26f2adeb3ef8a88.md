---
doc_id: "c26f2adeb3ef8a88"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/b415b401b67a7d4cd2934b2a1ddb16b1.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Guidelines and timeline for recording APARs for the year 2021-22"
date: "2022-03-16"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b60c4b0c44d7c0ad"
---

<!-- page 1 -->

No.22to9t2o22 - CS.l (APAR)
Government of lndia
Ministry of Personnel. Public Grievances & Pensions
Department of Personnel & Training
2"d Floor. A- Wing Lok Nayak Bhawan,

Khan Market, New Delhi-3,
Date: 166 March, 2022.

OFFICE MEMORANDUM

Recording of Annud Performance
Assessment Report (APAR) for the reporting year 2O2l -22 in
respect of Group 'A' and Group 'B' ofiicers - reg.

Subr Timelines for

The undersigned is directed to refer to Do&PT's OM No.220ll/l/2005 - Estt. (A) (Pc

ll) dated 23'd July. 2009 (copy enclosed) and other relevant circulars wherein instructions
regarding timely preparation and recording of the APARs are mentioned.. All Ministries/
Departments pardcipatint in CSS cadre are, therefore. requested to strictly follow the timelines
for recording the online APARs i.r.o. Group'A' and Group'B' officers on SPARROW ponal as
prescribed vide Do&PT's OM under reference.

2-.

Further all Nodal officers for SPARROW of all the cadre units of CSS may take required
urtent action for generation of APAR forms in a timely manner so that the APAR exercise for

the reporting yeer 2021-22 can be initiated in a timely manner

ln
t tJ
(Zar,hariah Thomas)
Under Secretary to the Govt. of lndia

lrr'

To: All Ministries /Departments through DoPT website
Copy for information to: NIC SPARROW (Helpdesk)

<!-- page 2 -->

No. 210111112005-Estt (A) (Pt-II)
Government of India
Ministry of Personnel, Public Grievances and Pensions
(Department of Personnel and Training)
North Block, New Delhi,
23rd July, 2009

Subject:- Preparation
(APAR).

and maintenance

of Annual Performance

Assessment

Reports

The undersigned is directed to invite the attention of the Ministries/Departments to
the instructions contained in this Department's a.M. No. No. 21011/02/2009-Estt.(A)
16/02/2009 and a.M. of even umber dated 14.05.2009 on the subjects of timely
preparation and proper maintenance of APAR and making the AP AR transparent for
representation for upgradation, if any, by the officer reported upon. The matter of
preparation and maintenance of AP AR has been further reviewed in this Department
keeping in view the system in this regard in respect of All India ~ervices (AIS) and the
undersigned is directed to convey the following decisions:(i) All cadre authorities shall include a box in the AP AR for reflecting by the
reporting officer the pen picture of the officer reported upon where the reporting
officer will be required to indicate his comments on the overall qualities of the
officer including areas of strengths and lesser strength and his attitude towards
the weaker sections. A column will also be added in the section relating to the
reviewing authority for giving the reviewing authority's remarks on the pen
picture reflected by the reporting officer. There will be no other separate column
in the AP AR for overall assessment apart from the pen picture.
(ii) A provision may be made in the AP AR in the relevant section for remarks by the
reviewing officer to indicate specifically the differences, if any, with the
assessment made by the reporting officer, and the reasons therefor.
(iii)Numerical grading are to be awarded by reporting and reviewing authorities for
the quality of work output, personal attributes and functional competence of the
officer reported upon. These should be on a scale of 1-10, where 1 refers to the
lowest grade and 10 to the highest. The guidelines given in Annexure- I shall be
kept in mind while awarding numerical gradings.
(iv)The format for the purpose of numerical grading in the three areas of work
output, assessment of personal attributes and assessment of functional
competency is in Annexure-II. For Group 'B' and 'C' officials however, suitable
changes may be made by the concerned cadre authorities in the items of
assessment as per functional requirements of the job and the next promotional
post for them. The overall grade on a score of 1-10 will be based on 40%
weightage on assessment of work output, and 30% each for assessment of
personal attributes and functional competency. The overall grading will be based
on addition of the mean value of each group of indicators in proportion to
weightage assigned.

<!-- page 3 -->

(v) Wherever 'accepting authority' has been prescribed in the existing system in the
cadre, columns may also be provided for such authority to give his comments on
the remarks of the reporting/reviewing authority and details of difference of
opinion, if any, with reasons for the same. In such cases, the accepting authority
will also give overall grade on a score of 1-10.
(vi) A schedule for completion of all activities relating to the APAR is given in
Annexure-III.
2.
The above provisions would be applicable for the APAR from the reporting year
2009-10 onwards. The concerned authorities may accordingly make necessary changes
in the APAR format for numerical grading to be given by reporting and reviewing
officer. This O.M. does not in any way affect the part to be filled in by the officer
reported upon and other existing columns in the APAR format like attitude towards
SC/ST/OBC, relations with public (wherever applicable), integrity, training requirement
etc. for descriptive remarks.
3.
All Ministries/Departments are requested to bring to the notice of all the offices
under them for strict implementation of the above instructions.

",-..jJ

(-~~~=

~~ t

~v---

(C.A. Subramanian)

Director

1. Chief Secretaries of All State Govemments/U.T.s
2. The President's Secretariat, New Delhi.
3. The Prime Minister's Office, New Delhi.
4. The Cabinet Secretariat, New Delhi.
5. The Rajya Sabha Secretariat.
6. The Lok Sabha Secretariat.
7. The Comptroller and Auditor General ofIndia, New Delhi.
8. The Union Public Service Commission, New Delhi.

(i)

All Attached offices under the Ministry of Personnel, Public Grievances and
Pensions.
(ii) Establishment Officer and Secretary, ACC (10 copies).
(iii) All officers and Sections in the Department of Personnel and Training.
(iv) Secretary, Staff Side, National Council (JCM), 13-C, Ferozeshah Road, New
Delhi.
(v) All Staff Members of Departmental Council (lCM).
(vi) All Staff members of the Departmental Council (JCM), Ministry of Personnel,
Public Grievances and Pensions.
(vii) NIC (DoP&T) for placing the Office Memorandum on the WAh-<.:itf' ofn()p.RrT

<!-- page 4 -->

Annexure-I
Guidelines regarding filling up of AP AR with numerical grading
(i) The columns in the AP AR should be filled with due care and attention and after
devoting adequate time.
(ii) It is expected that any grading of 1 or 2 (against work output or attributes or
overall grade) would be adequately justified in the pen-picture by way of specific
failures and similarly, any grade of 9 or 10 would be justified with respect to
specific accomplishments. Grades of 1-2 or 9-10 are expected to be rare
occurrences and hence the need to justify them. In awarding a numerical grade
the reporting and reviewing authorities should rate the officer against a larger
population of his/her peers that may be currently working under them.
(iii)APARs graded between 8 and 10 will be rated as 'outstanding' and will be given
a score of 9 for the purpose of calculating
average scores for
empanelment/promotion.
(iv)APARs graded between 6 and short of8 will be rated as 'very good' and will be
given a score of 7.
(v) AP ARs graded between 4 and 6 short of 6 will be rated as 'good' and given a
score of5.

<!-- page 5 -->

Reporting
Authority

Reviewing
Authority

Initial of
Reviewing
Authority

Reporting
Authority

Reviewing
Authority

Initial of
Reviewing
Authority

i)Accomplishment of planned work/work
allotted as per subjects allotted
ii) Quality of output
iii) Analytical ability
(iv)Accomplishment of exceptional work
/ unforeseen tasks performed
Overall Grading on 'Work Output'

i) Attitude to work
ii) Sense of responsibility
iii) Maintenance of Discipline
iv) Communication skills
v) Leadership qualities
vi) Capacity to work in team spirit
vii) Capacity to work in time limit
viii) Inter-personal relations
Overall Grading on personal attributes

<!-- page 6 -->

Reporting
Authority

i) Knowledge

of Rules I Regulations

IProcedures in the area of function and
ability to apply them correctly.

v) Ability to
subordinates

motivate

Overall
Grading
competency

and

develop

Reviewing
Authority

Initial of
Reviewing
Authority

<!-- page 7 -->

Time schedule for preparation/completion of AP AR
(Reporting year- Financial year)
S.No.
I.

Activity
Distribution
of blank APAR
forms to all concerned (i.e., to
officer to be reported upon where
self-appraisal has to be given and
to reporting officers where selfappraisal is not to be given)

Date by which to be completed
31st March.
(This may be completed even a week earlier).

2.

Submission of self-appraisal to
reporting officer by officer to be
reported upon (where applicable).

15th April.

3.

Submission of report by reporting
officer to reviewing officer

30th June

4.

Report
to be completed
by
Reviewing Officer and to be sent
to
Administration
or
CR
Section/Cell
accepting
or
authority, wherever provided.

31st July

5.

Appraisal by accepting authority,
wherever Drovided
(a) Disclosure
to the officer
reported upon where there is no
accepting authority

31st August

(b) Disclosure
to the officer
reported upon where there is
accepting authority

15th September

7.

Receipt of representation,
onAPAR

15 days from
communication

8.

Forwarding of representations
the competent authority

6.

if any,

01 st September

date

of

receipt

of

to

(a) where there is no accepting
authority for AP AR

21 st September

(a) where there
authority for AP AR

06th October

IS

the

accepting

9.

Disposal of representation
competent authority

by the

Within one month from the date of receipt of
representation.

10.

Communication of the decision of
the competent authority on the
representation by the AP AR Cell

15tllNovember

II.

End of entire AP AR process, after
which the AP AR will be finally
taken on record

30th November
