---
doc_id: "c4fb1be55be2d48c"
source_url: "https://dof.gov.in/static/uploads/2025/08/b8a279e172b3820912d42431c1e8ff9a.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Circular for vacancy of an IT consultant(18-01-2023)"
date: "2023-01-18"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "76c8747adeaa0882"
---

<!-- page 1 -->

F. No. 43011/2/2023 Admn | (E-21685)
Government of India
Ministry of Fisheries, Animal Husbandry and Dairying
Department of Fisheries
41% Floor, Chander Lok Building,
Janpath, New Delhi
Dated the 12" January, 2023
CIRCULAR

Sub: Engagement of One IT Consultant on contract basis in the Department of Fisheries for a

period of one year-reg
Department of Fisheries invites applications for engagement of one IT Consultant on contract
basis initially for a period of one year. The details regarding eligibility criteria, terms of references etc are

as under. -

IT Consultant 1 Essential educational qualification: B.E./B. Tech /M.SC./MCA oI
equivalent in IT & Computer Science stream with at least five years’
experience as mentioned below:-

1. Should have relevant Experience in developing different enterprise|
level applications in .net Platform/PHP, Drupal 8.
2. Should have good knowledge of Model View & Controller (MVC)
3. Should have experience in Entity Framework and Layered
Architecture in MVC using Drupal Framework
4. Should have experience on databases like Sql Server 2012, Sqll
Server 2014 and above.
5. Should have extensive experience in Database objects like: Stored|
Procedure, Views
6. Should have Extensive experience in code debugging and reviews
7. Should have experience in programming and Testing of web,
windows and distributed applications.
8. Should have a high level of aspiration for more challenging and|
responsible work that offers professional growth
9. Candidates are preferred those who are having experience in open
source and Microsoft technology
10. Basic understanding of NIC cloud, working with government
clients, VPN, website and application
development/maintenance/support
2. The Consultant will be engaged initially for a period of one year on fixed remuneration of Rs.
40,000/- per month.
3. Suitable candidates who are eligible and willing to accept the terms and conditions at Annexure |
may send application by E-Mail/post with duly filled Bio-data (Annexure I!) along with the copy of the
relevant educational and experience qualification certificates to the undersigned or at admn-
fishery@dof.gov.in within 15 days from the date of advertisement. Shortlisted “ae will require
attending interview which will be informed to the candidates suitably. aA
(Yogufde )
Deputy Secretary to the Government of India
Tele: 011-2331 0351
E-mail: admn-fishery@dof.gov.in
To,
The STD, NIC, Department of Fisheries, Krishi Bhawan, New Delhi - with a request to upload the same
in the Department website.

<!-- page 2 -->

ANNEXURE-1
GENERAL TERMS AND CONDITIONS

1. The contractual appointment will be attached in Department of Fisheries located in New Delhi.
He/She may preferably be a resident of Delhi only.

2. The consultant will not be entitled for any kind of allowances and residential accommodation.
They will also not be entitled to telephone facilities, transport facilities and staff car.

3. The engagement of the Consultant will be purely on Contract basis.

4. The engagement period for the consultant would be initially for a period of one year. This period
which may be extended or curtailed subject to review, at the sole discretion of this Department.

5. The Consultants shall be eligible for 08 days leave during the calendar year. This leave will not
be carried forward in case the engagement period is extended by this Department. Also, no
payment in lieu of un-utilized leaves will be paid by this Department at the time of expiry of
contract.

6. The candidate will be required to sign a non-disclosure undertaking and declaration for abiding
by the Code of integrity for Public Procurement (CIPP).

7. The Department may terminate the services of Consultants in case he/she is unable to achieve
the assigned works within the time-frame or the work assigned to him/her is not satisfactory to
the Department or he/she is found to be lacking in honesty and integrity.

8. The Department shall also reserve the right to terminate the services of Consultants at any time
without giving any notice and also without assigning any reason. The engagement of consultants
will not confer any right on the part of individual for permanent appointment to the post.

9. The individual Consultant can also seek for termination of the contract upon giving one month's
notice to the Department of Fisheries. Otherwise the remuneration due will be forfeited and no
objection or experience certificate will not be provided.

10. The Consultants may be called to the Office on Saturdays, Sundays and other Gazetted Holidays
or may be asked to sit late in the office after office hours, in case of exigency of work. No extra
allowances will be permissible for the same.

11. No TA/DA shall be admissible to the consultants for attending the interview or for taking up the
appointment. Consultant will not be allowed any foreign travel at Government expenses.

12. If any declaration given or information furnished by the candidate proves to be false or if the
candidate is found to have willfully suppressed any material information, he will be liable for
removal from engagement service and such other action as Government may deem necessary.

<!-- page 3 -->

ANNEXURE-II
Application for engagement as Consultants in Department of Fisheries
Post applied for:-
Affix your

1. Name: passport size

2. Father's Name: photo

3. Date of Birth:

4. Affix your passport size photo

5. Address:

6. Mobile No.:

7. E-mail ID:

8. Date of Retirement:

9. Name of Ministry/Dept from which retired:

10. Last pay drawn (copy of PPO should be enclosed):

11. Educational Qualifications:

12. Detail of Experience:

S.No. | Designation & Ministry/Department | From | To Nature of work
Performed
*attach separate sheet, if necessary.
13. Any other information justifying your engagement as consultant.
| hereby declare that the particulars furnished above are true and correct to the best of my
knowledge and belief. | further declare that | was clear from vigilance angle at the time of my
retirement. No disciplinary or judiciary action is pending against me as on date.
Place and Date:
(Signature of Applicant)
