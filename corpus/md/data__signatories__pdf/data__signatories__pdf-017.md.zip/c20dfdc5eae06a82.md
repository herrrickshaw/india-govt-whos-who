---
doc_id: "c20dfdc5eae06a82"
source_url: "https://doj.gov.in/static/uploads/2025/09/cdb0fdb3689d61a5feecc29984eb7d22.pdf"
ministry: "Department of Justice (DoJ)"
title: "Orders of appointment of Shri Justice Aravind Kumar, CJ, Gujarat HC as a Judge of the SCI (10.02.2023)"
date: "2023-02-10"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bdf754338392dc30"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

F. No. K-130II/01l2023-US.I (ii)
Government of India
Ministry of Law and Justice
Department of Justice
(Appointments Division)
Jaisalmer House,
26, Man Singh Road,
New Delhi-I 10 011,
Dated: io" February, 2023

NOTIFICATION
In exercise of the powers conferred by clause (2) of Article 124 of the
Constitution of India, the President is pleased to appoint Shri Justice Aravind
Kumar, Chief Justice, Gujarat High Court, to be a Judge of the Supreme Court
of India with effect from the date he assumes charge of his office .
.~Ul-

(pravash Prasnuo Paociey)
Joint Secretary to the Government of India
Tel: 2338 1496
To
The Manager,
Government of India Press,
Minto Road,

New Delhi.

<!-- page 2 -->

-2No. K-130l1l01l2023-US.I (ii)

Dated; 10.02.2023.

Copy to:1. Shri Justice Aravind Kumar, Chief Justice, Gujarat High Court through
the Registrar General, Gujarat High Court, at Sola, Ahmedabad.
2. The Secretary to Governor of Gujarat, Gandhinagar,
3. The Secretary to Chief Minister of Gujarat, Gandhinagar.
4. The Secretary to Chief Justice, Gujarat High Court, at Sola,
Ahmedabad.
5. The Chief Secretary, Government of Gujarat,Gandhinagar.
6. The Registrar General, Gujarat High Court, at Sola, Ahmedabad.
7. The Accountant General, Gujarat, Gandhinagar.
8. The President's Secretariat, (CA.II Section),New Delhi.
9. PS to Principal Secretary to Prime Minister, New Delhi.
10. Registrar (Conf.), % Chief Justice of India, 7 Krishna MenonMarg,
New Delhi.
11. PS to MLJ/ PS to MoS(L&J)/ PPS to Secretary (J).
12. Technical Director, NIC, Department of Justice, with a request to
upload on the Website of the Department (www.doj.gov.inJ.

0

~~lQ~u22.
(Aru~~KUI?~~garwal)
Section Officer (Appointments)
Tele: 2338 3037
