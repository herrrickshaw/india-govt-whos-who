---
doc_id: "c3afca72ec5cdc61"
source_url: "https://www.mdoner.gov.in/static/uploads/2025/09/40e59e8ef5b06aeafdd4e0cdb0c53305.pdf"
ministry: "Development of North Eastern Region (MDONER)"
title: "Tender March"
date: "2023-03-01"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7994ea08853fb16d"
---

<!-- page 1 -->

4 SECONDARY & TERTIARY SECTOR

4.1

North Eastern Development Finance
Corporation Ltd. (NEDFi).
The North Eastern Development Finance
Corporation Ltd (NEDFi) was registered and
incorporated as a public limited company
under the Companies Act, 1956 on 9 th
August, 1995 with an authorized capital of
Rs. 500 crores and paid up capital of Rs.
100 crores. It was notified as a public financial
institution in July, 1996 under Section 4-A of
the Companies Act 1956. NEDFi is also
categorized as Non Banking Financial
Company (NBFC) – Loan Company and was
registered with Reserve Bank of India in 2002.
The shareholders of the Corporation are IDBI,
SBI, LICI, SIDBI, ICICI, IFCI, SUUTI, GIC
and its subsidiaries. The management of
NEDFi has been entrusted upon the Board of
Directors comprising representatives from
shareholder institutions, Ministry of DoNER,
State Governments and eminent persons from
the NE Region and outside having wide
experience in industry, economics, finance
and management.
The Mission statement of NEDFi is “to be a
dynamic and responsive organization
catalyzing economic development of the North
Eastern Region of India by identifying and
financing, commercially viable industries,
providing value added advisory & consultancy
services, promoting entrepreneurship through
effective mentoring, skill development and
capacity building of the micro, small and
medium enterprises and generating sustainable
livelihoods through Micro Finance and CSR
activities”

4.2 Activities of NEDFi:
•

NEDFi provides financial assistance micro,
small, medium and large enterprises for setting
up industrial, infrastructure projects in the
North Eastern Region of India and also
Microfinance through MFI/NGOs.

•

Besides financing, the Corporation offers
Consultancy & Advisory services to the state
Governments, private sectors and other
agencies.

•

It conducts sector or state specific studies
under its Techno-Economic Development
Fund (TEDF).

•

NEDFi is the designated nodal agency for
disbursal of Govt. of India incentives to the
industries in the North-East India under
North–East Industrial and Investment
Promotion Policy 2007 (NEIIPP 2007).

•

Since its inception in 1995 the organization
has been taking up various development
activities for promotion of entrepreneurship
in the North East Region through its schemes
such as NEEDS.

•

The promotional activities include NEDFi
Haat, NEDFi Convention Center, NEDFi
Pavilion etc. Special emphasis has been given
in the field of Handloom and handicraft sector
which reflect the rich cultural heritage of
North East. NEDFi Haat set-up in. 2002 is a
permanent exhibition center providing
platform for market linkages to the artisans
and weavers.

Annual Report 2013-14

23

<!-- page 2 -->

Projects developed by the beneficiaries of NEDFi’s loan assistance

24

Ministry of Development of North Eastern Region

<!-- page 3 -->

Low cost machinery established under NEDFi’s loan assistance

•

It also provides support to capacity building
programmes organized for skill upgradation
of the weavers and artisans working in the
handloom, cane and bamboo sectors.

•

Since 2007-08, NEDFi has been making
efforts to identify alternate low cost raw
materials, where the existing skill of craft
persons can be used for making products for
the contemporary market. The irregular supply
of cane and the high cost of procurement of
bamboo was a cause of concern for artisans
in the NER. This led to identification of crafts
based on water hyacinth because of its
abundant availability in the region and
potential for value addition.

4.3

Initiatives of NEDFi for encouraging
entrepreneurship among weaker sections of
society in NER
NEDFi has formulated and is implementing
various first generations entrepreneur friendly
schemes under which loan assistance upto
75% of the project cost and concessional
interest rate of 8% under following schemes
are provided:
•

North East Entrepreneurs Development
Scheme (NEEDS)

4.4

•

Women Enterprise Development Scheme
(WEDS)

•

Scheme for Northeast Handloom and
Handicrafts (SNEHH)

•

Jute Enterprise Development Scheme
(JEDs)

•

Initiative for Development of Entrepreneurs
in Agriculture (IDEA)

•

NEDFi Opportunity Scheme for Small
Enterprises (NOSSE)

•

MICRO FINANCE

Micro Finance
The Micro Finance Scheme, an effective
instrument for financial inclusion, was
launched to meet the needs of smaller
entrepreneurs in the remote areas of the
Region. During the financial year, loans
sanctioned under the scheme aggregated
Rs.85.48 crore and disbursement 84.68 crore,
comparing previous year’s sanction &
disbursement of 67.72 crore and 71.92 crore
respectively.

4.5

Developmental Activities:
TEDF Study
NEDFi conducts various techno economic
feasibility studies for the North Eastern
Region. Over the years NEDFi has undertaken
81 studies out of which 65 studies are already
completed.
Nodal Agency Role
The Corporation is a nodal agency for
disbursement of Central Subsidies under NEIP

Annual Report 2013-14

25

<!-- page 4 -->

year’s sanction of 453.49 crore. Similarly,
364.66 crore was disbursed during the
period, compared to the previous year’s
disbursement of 348.74 crore. Cumulative
sanctions and disbursements as on March
31, 2014 was 3330 crore and 2325 crore
respectively to total 3582 projects.
Some of the important projects in the North
East supported by NEDFi during the year
under its schemes are at Annexure at the
end of the present Chapter.
Ribbon cutting ceremony of an event by NEHHDC

4.7

1997 & NEIIPP 2007, which is administered
by the Deptt of Industrial Policy & Promotion,
Ministry of Commerce, Govt of India. As on
March 31, 2014 an aggregate amount of
3093.81 crore was disbursed in various
subsidies.

North Eastern Handicrafts and Handlooms
Development Corporation plays a key role
in development and promotion of
Handicrafts and Handlooms sectors of
North East by way of providing training to
artisans and weavers through conduct of
awareness Seminars and Workshops,
Design and Technical Development
Workshops and Integrated Design and
Technical Development Projects. The
Corporation also provides marketing support
through procurement of Handicrafts and

NER Databank
The North Eastern Region of India is known
for its vast natural resources and is a
cauldron of different people and cultures.
Information about this Region, though
available from various resources, is
scattered. To mitigate the disadvantage,
NEDFi is maintaining a web based portal
called “NER Databank” with a view to
provide information about North East India
at a single source. Data on various sectors
are being updated regularly.
4.6

Activities of NEDFi during FY 2013-14
During the year under review NEDFi
continued its activities of facilitating setting
up of new industries & service sector projects
in the North Eastern states. During the FY
2013-14, an aggregate amount of 457.50
crore was sanctioned, compared to previous

26

North Eastern Handicrafts And Handlooms
Development Corporation Ltd: Guwahati

Traditional lighting of lamp during the inauguration of an
event by NEHHDC

Ministry of Development of North Eastern Region

<!-- page 5 -->

An exhibition by NEHHDC

Handlooms directly from artisans, weavers,
Self Help Groups at clusters and selling
the same through its Purbashree Emporium
located in Bangalore, Kolkata, Delhi,
Guwahati and Shillong and also through
its Sale Promotion Office at Chennai and
through various exhibitions in the country.
The Corporation also enables artisans and
weavers to sell their products directly
through North East Trade Expos, North East
Crafts Fairs and the exhibitions held in
various parts of the Country. For
development of infrastructure in
Handicrafts and Handlooms sector in
North Eastern Region, Corporation has a
Common Facility Centre for processing of
Bamboo, a Raw Material Bank for Cane
and Cane accessories, a Handicraft Museum
and Handicrafts Design Bank. Corporation
has also set up a Handloom Production Unit
to strengthen the Common Facility Centre
and also to provide training facility to tribal
women weavers.
During 2013-14, the Corporation achieved a
gross turnover of 1200.00 Lac (Prov) till 31st
March,2014.

Media being briefed during an exhibition of NEHHDC

The Corporation conducted 23 exhibitions
and 22 Crafts Bazaars in various Cities and
Towns of the Country and organized 7 North
East Trade Expos in Bangalore, Ahemadabad,
Vadodra, Goa, Indore, Chandigarh and
Shimla providing direct selling benefits to 2650
artisans and weavers from the North Eastern
Region.
•

The Corporation organized five seminars
/workshops at Dimapur, Nagaland,
Namsai, Arunachal Pradesh, Shillong,
Meghalaya Guwahati and Tezpur in Assam
for awareness generation amongst
artisans, weavers and other associated
persons.

•

The Corporation organized 10 Design and
Technical Development Workshops and
4 Integrated Design Projects at various
crafts clusters for training and design
improvement of the artisans.

•

The Corporation also participated in
National Handlooms Expo at Guwahati.

Annual Report 2013-14

27

<!-- page 6 -->

Annexure

Some of the important projects in the North East
supported by NEDFi during under its schemes
S. No

State Project Name

Location

Scheme

1.

(i)

Satyam Ispat (North East) Ltd.

Bandardewa

Term Loan

(ii)

Hotel Namsey

Itanagar

Term Loan

(iii)

Singhik Hotel & Resorts

Daporijo in Upper

Term Loan

Arunachal Pradesh

Subansiri

2.

Assam

(iv)

Aries Corps

Itanagar

NEEDS

(v)

D K Commercial Complex

Itanagar

NEEDS

(vi)

Anga Sisters Enterprise

Itanagar

WEDS

(i)

JJayanti Tea Pvt. Ltd

Dergaon

Term Loan

(ii)

K. D. Cements

Bhomraguri

Term Loan

(iii)

North-East Technical

Guwahati

Term Loan

Education Society (NETES)
(iv)

Parsuram Fly Ash Bricks

Tinsukia

Term Loan

(v)

SRD Bakers

Saloipara,
Mangoldoi,

NOSSE

Darrang

3.

Manipur

(vi)

Arham Packaging Solutions

Sonitpur

NOSSE

(vii)

D.B. Rubber Processing Unit

Goalpara

NEEDS

(viii)

Bhumika Entertainments

Guwahati

WEDS

(ix)

Assam Guest House

Guwahati

NEEDS

(i)

R & K Packaging Industries

Imphal

NEEDS

R.M. Boarding cum Tutorial

Imphal

NEEDS

(ii)

Home & Charitable Trust
4.

Meghalaya

(i)

ERD Foundation

Baridua

Term Loan

(ii)

Captain William Euro School,

Tura, Garo Hills

NOSSE

Garo Hills

28

(iii)

Queen’s Departmental Store, Shillong

Shillong

WEDS

(iv)

Azzets

Laitumkhrah

WEDS

(v)

Oma Store

Mawlai

WEDS

Ministry of Development of North Eastern Region

<!-- page 7 -->

S. No

State Project Name

Location

Scheme

5.

(i)

Mount Olive English School

Lunglei

WEDS

(ii)

S R Kitchen

Lunglei

WEDS

(iii)

Bethany Stone Works

Phunchawng

NOSSE

(iv)

Medplus Diagnostic Centre

Lunglei

NEEDS

(i)

Yehovi Complex

Dimapur

Term Loan

(ii)

SOLVSE

Dimapur

WEDS

(iii)

Tom yum Goong

Dimapur

NEEDS

(iv)

Bendang Handicraft

Mokokchung

WEDS

(v)

Bright Hope Farm

Dimapur

NEEDS

(i)

Mayallyang Homestay

North Sikkim

NEEDS

(ii)

Hotel Tarayana

East Sikkim

NOSSE

(iii)

Munlom Nature Resort

North Sikkim

NEEDS

(iv)

Armando Tours and Travels

North Sikkim

NEEDS

(v)

Hotel Pradhan

South Sikkim

Term Loan

(vi)

Student Tailoring

South Sikkim

Term Loan

(i)

Rainbow Quality Ice Factory

North Tripura

NEEDS

(ii)

Loknath Servicing Centre

North Tripura

NEEDS

(iii)

Maa Studio & Xerox, Dewanpasha

North Tripura

NEEDS

(iv)

Chameli Enterprise

North Tripura

WEDS

(v)

Purnima Beauty Care

North Tripura

WEDS

(vi)

New Sree Krishna Fertilizer

Udaipur Town, Gomati WEDS

(vii)

Craft Imperial

Udaipur Town, Gomati SNEHH

(viii)

Jainab

Sepahijala

6.

7.

8.

Mizoram

Nagaland

Sikkim

Tripura

Annual Report 2013-14

NEEDS

29

<!-- page 8 -->

30

Ministry of Development of North Eastern Region
