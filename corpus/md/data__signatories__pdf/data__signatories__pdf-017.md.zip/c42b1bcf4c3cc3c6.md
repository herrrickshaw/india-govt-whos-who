---
doc_id: "c42b1bcf4c3cc3c6"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/53437e826ada0e58c7c277e825bb113c.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "The Fresh Order after rescinding namely the Footwear made from all-Rubber and all Polymeric material and its components (Quality)"
date: "2025-07-04"
pages: 4
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "9e8c20cc412f4ed7"
---

<!-- page 1 -->

489
467001/2022/LEATHER
रजजस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-03062022-236279
xxxGIDHxxx
CG-DL-E-03062022-236279
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 2473]
No. 2473]

नई ददल्ली, िुक्रवार, जून 3, 2022/ज्येष्ि 13, 1944
NEW DELHI, FRIDAY, JUNE 3, 2022/JYAISHTHA 13, 1944

वाजणज्य रर उ्योगग मं्ालय
(उ्योगग संवधधन रर आंतररक व्यापार जवभाग)

आदेि
नई ददल्ली, 3 जून, 2022
का.आ. 2600(अ).—भारतीय मानक ब्यूरयोग अजधजनयम, 2016 (2016 का 11) की धारा 25 की उप-धारा (3) के
साथ परित धारा 16 द्वारा प्रदत्त िजतियय का प्रययोगग करते ुए, भारतीय मानक ब्यूरयोग के साथ परामिध करने के पश्चात
के न्द्रीय सरकार की यह राय है दक यह लयोगकजहत में ऐसा करना आवश्यक अथवा समीचीन है, जनम्नजलजखत आदेि करती है,
अथाधत:1. संजिप्त नाम रर प्रारं भ - (1) इस आदेि का संजिप्त नामसभी रबड़ रर सभी पॉलीमेररक सामग्री तथा इसके घटक से
जनर्ममत फु टवेयर (गुणवत्ता जनयं्ण) आदेि, 2022 है।
(2) यह 1 जुलाई, 2023 से प्रभावी हयोगगा ।
2.
मानक जचह्न का अजनवायध प्रययोगग- सारणी के स्ट्तंभ (2) में जवजनर्ददष्ट माल या सामग्री सारणी के स्ट्तंभ (3) में
जवजनर्ददष्ट तत्स्ट्थानी भारतीय मानक के अनुरूप ह गे तथा उनमें भारतीय मानक ब्यूरयोग (अनुपालन जनधाधरण) जवजनयम,
2018 की अनुसूची-II की स्ट्कीम-I के अनुसार भारतीय मानक ब्यूरयोग के अनुज्ञजप्त के अधीन मानक जचह्न लगा हयोगगा।
परं तु इस आदेि का कु छ भी जनयाधत की माल या सामग्री पर लागू नहीं हयोगगा।
3.
प्रमाणन रर प्रवतधन प्राजधकरण –भारतीय मानक ब्यूरयोग सारणी के स्ट्तंभ (2) में जवजनर्ददष्ट माल या सामग्री के
संबंध में प्रमाणन रर प्रवतधन प्राजधकरण हयोगगा।
3788 GI/2022

(1)

<!-- page 2 -->

490
467001/2022/LEATHER
2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

सारणी
क्र.सं.

माल या सामग्री

भारतीय मानक

भारतीय मानक का िीर्धक

(1)

(2)

(3)

(4)

1.

इं डजस्ट्रयल रर प्रयोगएजटटव रबड़ आईएस 5557: 2004
नी एवं एंकल बूट्स

इं डजस्ट्रयल रर प्रयोगएजटटवरबड़ नी एवंएंकल
बूट्स – के जलए जवजनदेि

2.

रबड़ के बने गम बूट्स रर एंकल आईएस 5557
बूट्स
(भाग 2): 2018

रबड़ के बने गम बूट्स रर एंकल बूट्स:
भाग 2 पेिेगत प्रययोगजन

3.

मयोगजल्डड सॉजलड रबड़ सयोगल रर आईएस 5676: 1995
हील्स

मयोगल्डेड सॉजलड रबड़ सयोगल रर हील्सके जलए
जवजनदेि

4.

सयोगल्स रर हील्स के जलए रबड़ आईएस 6664: 1992
माइक्रयोगसेल्युलर िीट्स

सयोगल्स रर हील्स के जलए रबड़
माइक्रयोगसेल्युलर िीट्सके जलए जवजनदेि

5.

सॉजलड पीवीसी सयोगल्स रर हील्स आईएस 6719: 1972

सॉजलड पीवीसी सयोगल्स रर हील्सके जलए के
जलए जवजनदेि

6.

पीवीसी सेंडेल

आईएस 6721: 1972

पीवीसी सेंडेलके जलए के जलए जवजनदेि

7.

रबड़ की हवाई चप्पल

आईएस 10702: 1992

रबड़ की हवाई चप्पल के जलए जवजनदेि

8.

जस्ट्लपर, रबड़

आईएस 11544: 1986

जस्ट्लपर, रबड़ के जलए जवजनदेि

9.

पॉलीजवनाइल
टलयोगराइड आईएस 12254: 1993
(पीवीसी) इं डजस्ट्रयल बूट्स

पॉलीजवनाइल
टलयोगराइड
इं डजस्ट्रयल बूट्सके जलए जवजनदेि

10.

पॉलीयूरेथन
े सयोगल, सेमीररजजड

आईएस 13893: 1994

पॉलीयूरेथन
े
जवजनदेि

11.

अनलाइन्द्ड मयोगल्डेड रबड़ बूट्स

आईएस 13995: 1995

अनलाइन्द्ड
जवजनदेि

12.

मयोगल्डेड प्लाजस्ट्टक फु टवेयर- आईएस 16645: 2018
सामान्द्य र्योगजगक इस्ट्तेमाल के
जलए लाइन्द्ड या अनलाइन्द्ड
पॉलीयूरेथन
े बूट्स

मयोगल्डेड प्लाजस्ट्टक फु टवेयर- सामान्द्य
र्योगजगकइस्ट्तेमाल के जलए लाइन्द्ड या
अनलाइन्द्ड पॉलीयूरेथेन बूट्सके जलए जवजनदेि

13.

नगर जनगम के सफाई कायों के
जलए मजहलाओं रर पुरुर् के
जलए फु टवेयर

नगर जनगम के सफाई कायों के
मजहलाओं रर पुरुर् के जलए फु टवेयर

आईएस 16994: 2018

(पीवीसी)

सयोगल,सेमीररजजडके
मयोगल्डेड

रबड़

बूट्सके

जलए
जलए

जलए

रटप्पण : इस सारणी के प्रययोगजन के जलए, समय-समय पर यथा-संियोगजधत भारतीय मानक के नवीनतम संस्ट्करण भारतीय
मानक ब्यूरयोग द्वारा ऐसी अजधसूचना की तारीख से लागू ह गे।
[फा. सं. पी-27025/4/2020-चमड़ा]
राजीव ससह िाकु र, अपर सजचव

<!-- page 3 -->

491
467001/2022/LEATHER
[भाग II—खण्ड 3(ii)]

भारत का राजप् : असाधारण

3

MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
ORDER
New Delhi, the 3rd June, 2022
S.O. 2600(E).—In exercise of the powers conferred by section 16 read with sub-section (3) of
section 25 of the Bureau of Indian Standards Act, 2016 (11 of 2016), the Central Government, after
consulting the Bureau of Indian Standards, is of the opinion that it is necessary or expedient so to do in the
public interest, hereby makes the following Order, namely:1. Short title and commencement. – (1) This Order may be called the Footwear Made from allRubber and all Polymeric Material and its Components (Quality Control) Order, 2022.
(2) It shall come into force with effect from the 1st day of July, 2023.
2. Compulsory use of Standard Mark.- Goods or articles specified in the column (2) of the Table
shall conform to the corresponding Indian Standard specified in the column (3) of the Table and
shall bear the Standard Mark under a licence from the Bureau of Indian Standards as per Scheme-I
of Schedule-II of the Bureau of Indian Standards (Conformity Assessment) Regulations, 2018:
Provided that nothing in this order shall apply to goods or articles meant for export.
3. Certification and enforcement authority. – The Bureau of Indian Standards shall be the
certifying and enforcing authority for the goods or articles specified in the column (2) of the Table.
TABLE
Sr. No.

Goods or articles

Indian Standard

Title of Indian Standard

(1)

(2)

(3)

(4)

1.

Industrial and protective rubber
IS 5557: 2004
knee and ankle boots

Industrial and protective rubber knee
and ankle boots - Specification

2.

All rubber gum boots and ankle IS 5557 (Part 2):
boots
2018

All rubber gum boots and ankle boots:
Part 2 occupational purposes

3.

Moulded solid rubber soles and
IS 5676: 1995
heels

Moulded solid rubber soles and heelsSpecification

4.

Rubber microcellular sheets for
IS 6664: 1992
soles and heels

Rubber microcellular sheets for soles
and heels- Specification

5.

Solid PVC soles and heels

IS 6719: 1972

Specification for solid PVC soles and
heels

6.

PVC sandal

IS 6721: 1972

Specification for PVC sandal

7.

Rubber HawaiChappal

IS 10702: 1992

Rubber Hawai Chappal- Specification

8.

Slipper, rubber

IS 11544: 1986

Specification for slipper, rubber

9.

Polyvinyl chloride (PVC)
industrial boots

IS 12254: 1993

Polyvinyl chloride (PVC) industrial
boots - Specification

10.

Polyurethane sole, semirigid

IS 13893: 1994

Polyurethane sole, semirigidSpecification

11.

Unlined moulded rubber boots

IS 13995: 1995

Unlined moulded rubber boots –
Specification

<!-- page 4 -->

492
467001/2022/LEATHER
4

12.

13.

THE GAZETTE OF INDIA : EXTRAORDINARY

Moulded plastics footwearLined or Unlined polyurethane
IS 16645: 2018
boots for general industrial use
Footwear for men and women
IS 16994: 2018
for municipal scavenging work

[PART II—SEC. 3(ii)]

Moulded plastics footwear- Lined or
Unlined polyurethane boots for general
industrial use- Specification
Footwear for men and women for
municipal scavenging work

Note : For the purposes of this Table, the latest version of Indian Standards, as amended from time to time,
as notified by the Bureau of Indian Standards, shall apply.
[F. No. P-27025/4/2020-Leather]
RAJEEV SINGH THAKUR, Addl. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR
VERMA

Digitally signed by
MANOJ KUMAR VERMA
Date: 2022.06.03
23:13:04 +05'30'
