---
doc_id: "c32cd68acbb41e7d"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/6ce42614570175b0998c23a208805d96.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Order A12034/34/2009-CHS-IV dated 4th August 2010"
date: "2015-03-03"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "53a711e7d1f8ec6c"
---

<!-- page 1 -->

FAX/SPEED POST
No. A.12034/34/2009-CHS.IV
Government of India
Ministry of Health and Family Welfare
(CHS Division)
ee
Nirman Bhawan, New Delhi - 110 108
Dated, the 4" August, 2010
ORDER
In continuation to this Ministry’s Order number A.12034/23/2009-CHS-IV dated
26.11.2009, the rotational posting to Andaman & Nicobar Admn in respect of Dr. Manoj Kumar,
M.O(Medicine), CGHS, Delhi is postponed till further orders.
(er
Under Secretary to the Govt of India
Tele-fax: 23062550
Copy to =
1. The Secretary(health), Govt. of NCT, Delhi, Delhi Secretariat, New Delhi.
2. The Addl. Director, CGHS(HQ), Bikaner House, New Delhi.
3. Dr. Manoj Kumar, MO(Medicine), CGHS, Delhi.
a NIC, M/o H&FW, Nirman Bhawan, New Delhi — for uploading in the Ministry’s
main Website under the head of CHS Division .
5. Order Register/Spare Copy.
