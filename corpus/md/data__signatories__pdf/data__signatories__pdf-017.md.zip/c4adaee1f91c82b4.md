---
doc_id: "c4adaee1f91c82b4"
source_url: "http://www.moef.gov.in/uploads/2018/03/775.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "S.O. 775 (E), दिनांक 19/03/2013 – राष्ट्रीय हरित अधिकरण के विशेषज्ञ सदस्य के रूप में श्री अजय अच्युतो देशपांडे की नियुक्ति।"
date: "2018-03"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7b81c4f3fdc2114c"
---

<!-- page 1 -->

I
. REGD. NO. D. L-33004/99

..

~
I
I
I,

Chi

Q:&e (5a:'£e~ of~ndia
EXTRAORDINARY
m'T I1-~ 3-~-~ (ii)
PART I1~ection 3-Sub-section(ii)
~ ~g,*"f\i'<1
PUBL~HEDBYAUTHORITY

-«. 6801
No. 68()]

~~, "'1<',<11(; 1l'l'Cf 19,2013~ 28,1934
NEW DELill, TUESDAY, MARCH 19, 2013/PHALGUNA 28, 1934

~
~.~, 19 "lTi'f, 2013

cnr.3if. 77S(~).-~m<llR, ~ mtr 3'!f~ 3'!f"lf.p:rq, 2010 (2010 'f;l19) 'Ift"lTU 6 'Ift-acr~
"lTU (J) a:lR (3) (f2:fl "lTU 7 WU~~'f;l m~~, 'l1t 3f'fl!3l""1d<l<l ~,~ 403, ~ 11:-26,
M ~~, ~, blh1"'{~' ~ (~)-400607, ~, q:;'t ~ 18 "lTi'f, 2013 'B '1fq q-.f'lft 31cIfQ .
;t ,full; 'IT ~ ~ Cf'f '1ft 3Wl )111<[, q;'{'j oq:;, t'f'f 'B 'llt lit 'l)'fu1: m, ~ mtr 3'!f~ 3'!f"lf.p:rq ;t ~<I ~
;t "<"'f ll' ~ ~ %I

"

(

MINISTRY OF ENVIRONMENT AND FORESTS
NOTIFICATION
New Delhi, the 19th March, 2013
S.O. 775(E).-In exercise of the powers conferred by sub'sections (I) and (3) of Section 6 and
Section 7 ofthe National Green Tribunal Act, 2010(19 of 2010), the Central Government hereby appoints .
ShriAjay Achyutrao Deshpande, Flat 403, BuildingA-26, Happy Valley Homes, Manpada, Ghodbunder Road,
Thane (W)-400607, Maharashtra, as the Expert Member of the National Green Tribunal with effect from
18th March, 2013 for a period offlve years or till he attains the age of sixty.five years, whichever is earlier.'

[F: No. 17(30)/2012-PL/NGT]
SURJIT SINGH, JI: Secy.
1175 Gl/20!3

I

Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Delhi ll0064
and- Published by the Controller of Public~tions, Delhi-I-I0054.
M
