---
doc_id: "c5d75ce067d9fcab"
source_url: "https://mohua.gov.in/static/uploads/2025/11/b0ba54078b2cb75624ee610540598493.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of Rs. 1,387.20 lakh to State Govt. of Tripura as part amount of 1st installment of Central Assistance for 19 BLC (New Construction) projects under PMAY-U Mission - reg."
date: "2021-03-26"
pages: 7
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "3de53baad44c420c"
---

<!-- page 1 -->

https://pfims.nic. in/Sanction/TemplateA dvice.aspx?AdviceNum=DR
60)
PAO(Sectt.) /HUA/Admin/Advice/2020-21/24 ५८-५४
GOVERNMENT OF INDIA
PAOQ(Sectt.), Ministry of Housing and Urban Affairs
507-C Wing, Nirman Bhawan, New Delhi

Telephone No: 23062664 Fax No: 23062664
To,
The General Manager,
Reserve Bank of India, (Code No: [707 _ j
Central Accounts Section, |Advice No: |886 |
Additional Office Building, [Advice Date:|26/03/2021|
East High Court Road, = ——
NAGPUR - 440 001
Sir,

Please debit our account with Rs.13,87,20,000/- (Thirteen Crore Eighty Seven Lakh Twenty
Thousand Only.) by contra credit to the following accounts of the Governments with the amounts
mentioned against each:

Month and Year of Accounts: March,2021 The Amount to be Settled: March,2021
SI.No.| Name of | State Scheme Code = = No. and Date
the State | Code
1 TRIPURA 120 1989-STATE AND UT 13,87,20,G00 | N-11012/14/2020-HFA-V-UD
GRANTS UNDER PMAY (FTS-9091210) dated
(URBAN) 26/03/2021
GRAND TOTAL: | 13,87,20,000
................ शा
Signature of the authorized official
क्री
(Pawan Kumar Bhatnagar)
Sr. Accounts Officer
2h /o the Dy. Accountant General (A&E), Tripura, P.O. Kunjaban, Agartala-799006
2/Sh. B.K Mandal, US (HFA-V) , M/o Housing and Urban Affairs, New Delhi-110011.
: Pawan Ku: owe Bhatnagar
Sr. Accounts Officer
2
M po-HFA
ips wh
Men Cd
(2) Me |
5
Q Mis nen
wo
\ 2
§
N
Fl 27-03-2021 13:39

<!-- page 2 -->

u No. N-11012/14/2020-HFA-V-UD (FTS-9091210)
e Government of India
-.. Ministry of Housing & Urban Affairs '
: : HFA-V Division
pre
* 5 Room No. 03, Technical Cell, Gate No. 7,
हे Nirman Bhawan, New Delhi
Dated: 96.03.2021
To :
Pay and Accounts Officer (Sectt.),
Ministry of Housing and Urban Affairs,
Nirman Bhawan,
New Delhi -11 :
: Sub: Release of Rs. 1,387.20 lakh to. State Govt. of Tripura as part amount of
a 1% installment of Central Assistance for 19 BLC (New Construction) projects
under PMAY-U Mission — reg.
Sir,
“Tam directed to convey the Sanction of the Competent Authority to the release of Rs.
i -43,87,20,000/- (Rupees Thirteen Crore Eighty Seven Lakh and Twenty Thousand
only) to State Govt. of Tripura as part amount of 1* installment of Central Assistance (sc

3 . -€omponent) for 19 BLC (New Construction) projects for Creation of Capital Assets

के ‘under Pradhan Mantri Awas Yojana — Urban (PMAY-U) for FY 2020-21.

1० 2... The statement showing details of the projects against which the above Central Assistance
is eleased towards part amount of 1* installment of Central Assistance is at Annexure.

2 3.  :Based on decision and recommendations of CSMC under PMAY-U Mission in its 51%
meeting held on 07.08.2020, the amount of Central Assistance is being released subject to the
following conditions:

i. The funds shall be utilized for the purpose and within the selected categorized
beneficiaries, for which these are given. Otherwise these will have to be refunded along
with interest as per provisions under GFR 2017.

: ii. - The expenditure on the implementation of the scheme/projects will be shared between
the Central and the State/ULB/Implementing Agency (IA) as committed. The committed
State share should also be released within 15 days from the date of receipt of Central
Assistance in the SLNA account. In case of shortfall of State/ULB/IA share,
corresponding amount of Central Assistance will be deducted from the subsequent
instalment (s).
iii. The funds including Central Assistance and State share will thereafter be released by the
State Government to the implementing agencies without any delay failing which the
amount would be recovered from the State Government with interest, as applicable, for
the period of default.

iv. Necessary sanctions/approvals/compliances required under the statutory or other

regulatory regime as applicable would be obtained by the authority (ies) concerned with
. the project(s).

v. The State Government and implementing agency shall put in place a monitoring system
to ensure that the project(s), achieve scheduled milestone and envisaged outcomes...
including implementation of reforms and other conditionalities required under the
scheme.

हि Contd..P.2/

<!-- page 3 -->

wo ti

vi. The State Government shall utilize the grant in accordance with the approved guidelines
for the implementation of PMAY-U Mission. हि

vii, _ The State Government shall furnish the Utilization certificates of the Grant released in
the prescribed format as per GFR 2017 as provided in the scheme guidelines.

viii. Where there is an element of cash transfer to individual beneficiaries, the same may be
made.through PFMS/DBT mode as applicable. The State Government shall submit an
authenticated certificate from the bank showing complete details of disbursement of
funds to each beneficiary before release of 2"4installment.

ix. The State Government shall ensure the geo-tagging of all houses approved under BLC
component of PMAY-U Mission and subsequent release by the State Government to
beneficiaries should be made in 3-4 installments depending on the progress/stage of
construction of house.

x, The State Government shall be required to certify that the specifications of the houses
conform to NBC/IS Standards and that requisite infrastructure will be provided by the
State Government/ULB. State Govt. shall also ensure that there should be no
duplication/change in the identified beneficiaries.

xi. The State Government shall submit the Action Taken Report (ATR) on the
observations/recommendations of Third Party Quality Monitoring Agency (TPQMA) for
quality monitoring purpose before release of subsequent instalment.

xii. The State should ensure that Model Code of Conduct is not violated while releasing funds
to Implementing Agencies/ULBs/Beneficiaries.

4. The amount is debitable from the account of the Central Government in the books under

the following Head of Accounts under Demand No. 57 of the Ministry of Housing and Urban

Affairs for the year 2020-21 after duly re-appropriation from the respective NonFunctional
Head to the Functional Head for NE State:
|___3601 __[Grants-in-aid to State Governments
Sub-Major Head | ०6६ | entrally Sponsored Schemes
Minor Head | 769 __ bpecial Component Pan for Scheduled Casts
Pradhan MantsiAwas Yojana (Urban)
[Detailed Head [ _o2 | Assistance to NE States for PMAY
Object Head rants for Creation of Capital Assets
§- The amount will be credited to the State Government’s Account at Reserve Bank of India,
CAS, Nagpur as per procedure laid down by Ministry of Finance, Department of Expenditure in
this regard.
6. This being the first instalment Central Assistance, no UC is required/due for above release.
7. AS per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee
Institution(s)/Organisation(s) shall be open to inspection by the sanctioning authority and
audit, both by the Comptroller and Auditor General of India under the provision of CAG (DPC)
Act 1971 and internal audit by the Principal Accounts Office of the Ministry or Department,
whenever the Institution or Organisation is called upon to do so.

न . 8. This issues with the concurrence of the Finance Division vide their Note No. 36-39 of
even number dated 10.03.2021.

Contd..P.3/

<!-- page 4 -->

ae " ि Fa
है 9... This sanction has been registered at S. No.40)in the Sanction Register of HFA Mission
Directorate of the Ministry of HUA for the year 2020-21.
: Yours faithfully,
eee oles landal)
2 : Pipl व ‘Under Secretary to the Government of India
3 “a Tel No.: 011-23063285
Copy to:
4.. Special Secretary, Urban Development, State Government of Tripura
2. Accountant General (A&E), Tripura
3. Dir. (FD), MoHUA
4. Dir. (HFA-3), MoHUA
5. DS (Budget), MoHUA
it 6. NITI Aayog, SP Divn./DR Divn., New Delhi
7. O/o CGA, Mahalekha Niyantrak Bhavan, New Delhi
8. Dy, Chief (MIS/DRMC), HFA Directorate to place this sanction at appropriate place on
the Website of the Ministry.
9. PMU (MIS), HFA Directorate
10. Sanction folder re R
हे (8.7. dal)
2 हे Under Secretary to the Government of India

<!-- page 5 -->

moe ee en: ee
ee |:
ede lie |e lelelelef ae 72
है 18 16 156 15 8 | 8 | 5 ४ 5
H ५, 1 =
e =] a = > = : : 5
z = $ Zz 3 & +
3 3 a & | 3 z व 3
= डे § न न z
g g | 3 } j é
id 3
i डर g
e BES 1 e & s w Fd g
# | कै 3 181 | | है | ० g
oo oe ie ee Be in a i £
sles sys] 8,818 >
Ss
Q on & 5 @ 2 कटे g z
és] 8] 2 2) 8] 8] 8 3
an wn ae we 2 8 4
EL EUe ele elel 2
8 1818 हर
8 :० 1०४५६ ie 8
111 11]. ।
2
: डर
४ 1 i 3 5
BLE TS ei: g 3
Bq
111 [| i
>
© 2 © 2 © 2 2 © z
g
ELELELELEl ele le हे
8 1 8 3 818 थे
डे
» £
५ | 8 है | #& | ४ | ४|४। 8 डे
डे 2 g./-8 = '
g 2 | 8 g e138 Bee &
81 8 8 18 18 4
2 2 2 2 2 2 2 e &£ 3
| 8181-81 8 3 2/3 | ड़
8 :

glelelé s|8 5 :
ieee s rae 3
है 2 आर 2 0 भा लित0 7207: 775 | | =
aS 4:
i oes ee हे
5 8 pais eet tae] S
5 Boles हि 2 | 8

ey tie Slay ea |

ORT RO) ere eter tee |

<!-- page 6 -->

|p Sirs:
eh sos OES 2 iis Se sak bes eed
Bone ge te Mie gra Sata
[eet eae an gee oe ae
| rao eee eS ene tee 801
1070 83 0 20010: ET 3 2 (76
fe (ono a ie ee के ~
+ (कि कस आह अर 5 2 16 men eed
fel ee etm Cee oe
aoe me pee
oa YT | ह1ह_ै1 है है हि इ
8 8
5 कद 8 3 8 8
81 51 51 51 51 5
: - S sts
ak 2/272 g 2/2) 8 g
gi 8 8
= : 2 a bE 2 a aa bad |
3B a s 8 s g 8 &
: a | 3s
oe ererelelerelelé
: | 8 s
8181 58181 58181 4158
: : 81581 81 561 816 व व
कम मल eg aero स्पा मम कक गत
ठ ज्ञ क्र
दि 8 न डे
; हर हि हा इहइ हा ड्ि
FlElErelelelele
a 2 2. 2 uw ba it a
है | 8 18181 8181 8 |
है हे | 01 प के है ते
3 3
: ड़ ड्र/दप ड्रॉ हर डह्र1ड
3 3
जय पाए के
3 | 981 8151 81 581 $| ४५
- 38 2 | 8 8 $ | 8
हैं | 8 81813 | 31% ।6  #
; हल जे 8 2
be Se : . हे हु
Peer eet 5 £ 5 5 8 &
ee £ a ® 4 2 2 8 7 a
Pe teen ee 8 a 2 3 g £ 2 =
pee ane 2 कर | -> धु a 5 ढ़ टू a =
_ 12 Bee ee) fC lL el ST TT eT EL RS .
ee pe mel egies] es]¢egtis]s]e
Ae : 72] 2]2a]a2]2]a2a]2] 2
128 7:22 वश 1 pee aie ee
. Pe ee कप Patera
I ages ae Gee o 3 a |] तह Bs Pa) 2
; ee a ey S 3 a a a ‘
Se

<!-- page 7 -->

पक 50820 ae oslo ae 2
500 00 दि 2200 8325 if
| Berries se oes ages Sea aa zy
Se ee a ee ase a
a eee 3 कब ee ee si
| ee rea | B
nee! Paar eae ae 4
aay is See ey a | अप
[ et Tart egies ae ie
| : 1 कम E
p See sts ake ae aed Ee
दि
8 oS So पा
2 3 8 8 ie
3 2 Pe
3 3 os &
13
So > So
8158 18 9
3 m a S
a 8 o
o birt
EL ElEG
3 छठ छ
be
:
= 5 R
हु हि हि
a 3 8
3 3 = f
e 3 3s ff
न 8 3
‘ g = 3 ta
2 o BS
s rad डक
as | 2) 2 &
ma g = f@
& ec | 5 g 5}
- oe cep 5 5 s &
E a E aE
Fs See =e ie s s FF
: . 0 1 0: s 24.
डे ep os aed =e ree YY 8 8 =
| कप nae g 4 g
ee ee a a a ff
bers oe ree Ga ae be
fe Sis eee i x a o Fe
ee ee  ती में ये
1 i so
