---
doc_id: "cd5dafea8b54c249"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/b9c4a990a80079f6eb4cde8d0a783543.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS Comm no. 837 of 2024:  DoT instructions to ISPs dated 13.03.2025"
date: "2025-03-13"
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ab992776aed2b505"
---

<!-- page 1 -->

813-7/25/2024-DS

I/3259271/2025

By Email & DoT website
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Services Cell)

No. 813-07/LM-39/2024-DS-II

Dated:13-03-2025

To,
All the Internet Service Licensees
Subject: CS (COMM) 837 of 2024: Star India Pvt. Ltd. versus MovieBlast
Application And Ors. before the High Court of Delhi.
Kindly ﬁnd enclosed the Hon’ble Delhi High Court order dated26.09.2024
on the subject matter.
2. Please refer to Para 42 and 43 of the said Court order in respect ofblocking of
the website(s) [1 no.], enumerated in Document A of the 28th additional Aﬃdavit
dated 12.03.2025 filed by the plaintiff.
3. In view of the above, all the Internet Service Licensees are hereby instructed to
take immediate necessary action for blocking of the said website(s), as above, for
compliance of the said court order.
Encl: AA

Director (DS-II)
Email: dirds2-dot@nic.in
Copy to:
i. Sh. V. Chinnasamy, Scientist E (chinnasamy.v@meity.gov.in), Electronics
Niketan, Ministry of Electronics and Information Technology (MeitY), New
Delhi for kind information and with request to take action as per the Annexure
pl.
ii. Sh. Vivek Kumar <v.kumar@saikrishnaassociates.com>, Plaintiﬀ's Advocate;
for kind information and with request to take action as per the Annexure pl.
iii. IT Wing of DoT for uploading this order on DoT websites please.

<!-- page 2 -->

IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
.…Plaintiff
Star India Pvt. Ltd.
versus
…Defendants

MovieBlast Application and Ors.
INDEX
PARTICULARS

S.
NO.
1. Affidavit of Mr. Hitender Adlakha dated 12th
March 2025 with respect to additional list of
Source Domain(s) / Website (s) / URL (s) that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
2. Document A: Additional list of Source
Domain (s) / Website (s) / URL
3. Evidence with respect to additional list
Source Domain (s) / Website (s) / URL that
are engaged in hosting and/or streaming
and/or providing access and/or making
available for viewing the Plaintiff’s
copyrighted content
4. Proof of Service

Place: New Delhi
Date: 12.03.2025

PAGE
NO

1-9

10

11-24

Vivek Kumar
(D/7260/2023)
Saikrishna and Associates
Advocates for the Plaintiff
57, Jor Bagh,
New Delhi – 110003

<!-- page 3 -->

1
IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM.) NO. 837 OF 2024
IN THE MATTER OF:
Star India Pvt. Ltd.

.... Plaintiff
versus

MovieBlast Application and Ors.

. .. Defendants

AFFIDAVIT OF MR. HITENDER ADLAKHA, S/0 SH. LATE
R.

L.

ADLAKHA,

AGED

53

YEARS,

AUTHORISED

REPRESENTATIVE OF PLAINTIFF, STAR INDIA PVT. LTD.
HAVING OFFICE AT STAR HOUSE, URMI ESTATE, 95
GANPATRAO KADAM MARG, LOWER PAREL

(W),

MUMBAI 400013, PRESENTLY AT NEW DELHI, INDIA, ON
BEHALF OF THE PLAINTIFF
I, the above-named deponent, do hereby solemnly affirm and
declare as under:
1. That, I am the Authorized Representative of the Plaintiff in the
present suit and as such I am conversant with the facts and
circumstances of the present suit and competent to depose in

<!-- page 4 -->

2
Communication Ltd. (supra), this Court is of the opinion
that a prima facie case is made out in favour of the
plaintiff Balance of convenience is also in favour of the
plaintiff Further, irreparable harm or injury would be
caused to the plaintiff if an interim injunction order is not
passed.
39. Accordingly, defendants No. 1 to 3 (and any such other
Uls/websites which appears to be associated with any of
the defendant apps and websites based on its name,
branding or the identity of its operator, or discovered to
provide additional means of accessing, the defendant apps
and websites, and other domains/domain/apps/Uls along
with their sub domains and subdirectories, owners/website
operators/entities which are discovered to have been
engaging in infringing the plaintiff's exclusive rights),
their owners, partners, proprietors, officers, servants,
employees, and all others in capacity of principals or
agents, acting for and on their behalf, or anyone claiming
through, by or under them are hereby restrained, from, in
any manner hosting, streaming, reproducing, distributing,
making available to the public and/or communicating to
the public, or facilitatinf{ the same, on their
Apps/Ulslwebsites, through the internet in any manner
whatsoever,
any
cinematograph
work/content/programme/show in relation to which
plaintiff has a copyright.
40. The defendants No. 4 to 8 shall ensure compliance with
this order by blocking defendants no. 1 to 3 websites, their
URLs and the respective Uls as filed along with the suit
(Pg 1- Vall) (also annexed herewith as annexure- A) and
any other Ulslapps/websites notified by the plaintiff by
filing of an affidavit.
41. The defendants no. 4 to 8, their directors, partners,
proprietors, officers, affiliates, servants, employees, and
all others in capacity ofprincipal or agent acting for and,
on their behalf, or anyone claiming through, by or under
it, are directed to disclose the following information of the
defendants no. 1 -3 (and anJ uch other websites/ Uls
\
Re2.r~·.~:o~-~;;;=~
which m~e discovered dw ·_ing the cours~ of_ the proceedings
1
Perk'c '2 81 06120 ~; / , . ~~nd _ n~tified on ~IJ!davlt b_l f~-ze plamtiff to hen e. b~~n
to 27106t20L.~'
•. .1 mfrzngzng/ authonzrng the mfrmgement of the plamtifj s
!-- ~ )

_______,.,.- - /

<!-- page 5 -->

3
exclusive rights, copyrights and broadcast reproduction
rights):
A. Complete details (such as name, address, email
address, phone number, IP address etc.) of the
defendants no. 1 - 3 (and any such other websites/Uls
which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff
to have been infringing/ authorizing the infringement
of the plaintiff's exclusive rights, copyrights).
B. Mode ofpayment along with payment details used

for registration ofdomain name by the registrant i.e.,
defendant no. 1 - 3 (and any such other websites!Uls
which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff
to have been infringing/ authorizing the infringement
ofthe plaintiff's exclusive rights, copyrights).
42. The defendants No. 9 to 17 shall ensure compliance
with this order by blocking defendants no. 1 to 3 websites,
their URLs and the respective Uls as filed along with the
suit (Pg 1- Vall) (also annexed herewith as annexure- A)
and any other apps/websites notified by the plaintiff by
filing of an affidavit.
43. Defendants no. 18 and 19 are further directed to take
immediate steps and issue requisite notifications within
five working days, calling upon various internet and
telecom service providers registered under them to block
the aforementioned websites/U/s identified by the
plaintiff "
3. I state that in order to protect and enforce its exclusive rights in
the Plaintiffs copyrighted content, including but not limited to
e content made available through the Plaintiffs STAR
els and Disney+Hotstar, the Plaintiff engaged the
investigation agency, Copyright Integrity

<!-- page 6 -->

4
subdirectories, owners/website operators/entities which are
discovered to have been engaging in infringing the plaintiffs
exclusive rights (in terms of paragraph 39 and 40 of the
aforementioned order dated 26.09.2024) collaborating with the
said App and/or the other Uis/apps identified in the instant suit
and gather evidence of their infringing activity. I state that the
Source Domain (s) I Website (s) I URL (s) that have been
identified by the investigation agency engaged in illegally
communicating the Plaintiffs copyrighted content, including
but not limited to the content made available through the
Plaintiffs STAR Channels and Disney+Hotstar, through the
Rogue Apps which is annexed herewith Document A.
4. I state that the 'CricFy TV' App has been identified by the
investigation agency as an Android-based mobile App which is
engaged in illegally communicating the Plaintiffs copyrighted
content, including but not limited to the content made available
through the Plaintiffs STAR Channels. I state that the 'CricFy
TV' App is an Android application that unauthorizedly makes
available for viewing and provides access to the content shown
on TV Channels including live sporting events, inter alia ICC
Champions Trophy, 2025 and other Video on Demand content
including that of the Plaintiffs - content on Star Gold
Romance, Colors etc.
5. I state that the primary intent and purpose of the aforesaid

<!-- page 7 -->

5
In fact, the very intent ofthe said ' CricFy TV' App is to provide
an alternative to legitimate sources to the user, so that a user
does not have to pay for enjoying the copyright-protected
works. Detailed allegations regarding the "rogue" nature of the
aforesaid App are provided hereinafter.
6. I state that the step-by-step process for downloading the APK
file for the 'CricFy TV' App and running the said mobile App
on a computer has been detailed in the evidence filed herewith.
7. I state that the ex parte ad interim injunction granted vide order
dated 26.09.2024 passed by this Hon'ble Court is applicable to
the aforesaid Rogue App, viz 'CricFy TV' App, identified by
the Plaintiffs investigation agency (in terms of para 39 and 40
of the aforementioned order dated 26.09.2024). Accordingly,
the relief granted in terms of paras 39 and 40 of the
aforementioned order dated 26.09.2024 and the directions
issued by the Hon'ble Court to Internet Service Providers (i.e.,
Defendant Nos. 9 to 17) and to the DoT and MEITY (i.e.,
Defendant Nos. 18 and 19) are applicable in relation to user
interface (UI) domains I websites I URLs identified and
notified by the Plaintiff to be infringing and/or authorising
infringement of the Plaintiffs Content through the Rogue
'CricFy TV' App.
8. In light of the above, I state that the following user interface

<!-- page 8 -->

6
. No.
1.

D · main I Website
https://cfyappks26.top

9. I state that from the evidence filed along with the present
Affidavit, it is evident that the above-mentioned UI domains/
websites are hosting and/or streaming and/or providing access
and/or making available for viewing the broadcast of Plaintiffs
copyrighted content, including but not limited to the content
made available through the Plaintiffs STAR Channels,
through the aforesaid Rogue App, viz 'CricFy TV' App, and/or
authorising infringement of the Plaintiffs copyrighted content
by making available for download and usage the said App.
10.1 state that the Plaintiff is not aware of the owner(s) of these
rogue 1TT ciom~ins I wehsite:s RS e:ithe:r they are anonymous or
have incorrect or incomplete addresses.
11.1 state that the from the evidence filed along with the present
Affidavit, it is evident that the identified Source Domain (s) I
Website (s) I URL(s) is hosting and/or streaming and/or
providing access and/or making available for viewing the
broadcast of Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar. I state that the Plaintiff is the exclusive
right holders for Plaintiffs copyrighted content, including but
limited to the content made available through the Plaintiffs
. Channels and Disney+Hotstar, for the worldwide

<!-- page 9 -->

7
viewing the Plaintiffs Content, including but not limited to the
content made available through the Plaintiffs STAR Channels
and Disney+Hotstar.
12.1 state that the Plaintiff is not aware of the owner(s) of the
identified rogue Source Domain (s) I Website (s) I URL (s) as
either they are anonymous or have incorrect or incomplete
addresses.
13 .I state that in terms of the following directions passed by this
Hon'ble Court, vide order dated 26.09.2024 (reproduced herein
above) is also applicable on the Source Domain(s) I Website(s)
I URL( s) identified herewith.

40. The defendants No. 4 to 8 shall ensure compliance
with this order by blocking defendants no. 1 to 3 websites,
their URLs and the respective Uls as filed along with the
suit (Pg 1 - Vol 1) (also annexed herewith as annexureA) and any other Uls/apps/websites notified by the
plaintiff by filing of an affidavit.

42. The defendants No. 9 to 17 shall ensure compliance
with this order by blocking defendants no. 1 to 3 websites,
their URLs and the respective Uls as filed along with the
suit (Pg 1 - Vol 1) (also annexed herewith as annexureA) and any other apps/websites notified by the plaintiffby
filing of an affidavit.

14.1n light

of the

abovementioned,

the

Department of

ers (Defendant Nos. 9- 17) to block the additional rogue

<!-- page 10 -->

8
Source Domain I Website I URL identified in Document- A
hereto.

15 .I state that the evidence filed along with the present affidavit
was shared by the investigating agency in google drive link. I
downloaded the same onto the computer (Intel (R) Core (TM)
i5-2520M CPU @ G20 10 @ 2.50 GHz 2.50 GHz) which is
regularly used by me in the ordinary course of business and
thereafter, shared the same with the Plaintiffs Counsel.
16.1 am advised to state that the conditions of Sections 63 of the
Bharatiya Sakshya Adhiniyam and Order XI Rule 6(3) of the
Commercial Courts, Commercial Division and Commercial
Appellate Division of High Courts Act, 2015 are complied with
in respect of these documents.
17.In particular, I confirm:~)

That the said computer system is regularly used to produce
computer outputs like emails and information from the
World Wide Web (Internet) and store other electronic
records. The relevant information from the websites and
electronic records as mentioned above was downloaded by
me in the course of activity of the Plaintiff. I have a lawful
control over the use of the said computer system by virtue of
my capacity in the organization.
at the electronic records mentioned above are downloaded
the computer system as part of the ordinary course of
ities of the Plaintiff.

<!-- page 11 -->

9

c) That the computer system as used by me has been operating
properly and the electronic records and their accuracy and
contents have not been altered and tampered with in any
manner whatsoever.

d) That the information contained on the computer outputs is
an exact replica and has been produced from the original
electronic record and therefore, reproduces the information
contained on the electronic records therein.

-.

VERIFICATION
Verified at New Delhi on this the

1 2 MAR 202

of March 2025 that the

contents of the above said Affidavit are true to the best of
knowledge, information and belief and nothing material has been
concealed therefrom.

<!-- page 12 -->

10
Document A: Additional list of Source Domains / Websites /
URLs

S.
No.
1.

Source Domain / Website /
URL
https://cfyappks26.top

Rogue App
‘CricFy TV’
(Defendant No. 23)

<!-- page 13 -->

$~35
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 837/2024
STAR INDIA PVT. LTD.
Through:

.....Plaintiff
Mr. Sidharth Chopra, Mr. Yatinder
Garg, Ms. S. Jauhari and Mr. Vivek
Kumar, Advocates.

versus
MOVIEBLAST APPLICATION AND ORS

.....Defendants

Through:

%

CORAM:
HON'BLE MR. JUSTICE AMIT BANSAL
ORDER
26.09.2024

I.A. 40567/2024 (for exemption from certified copies of dim annexures)
1.

Allowed, subject to the plaintiff filing legible copies of the annexures

within four weeks from today.
2.

The application is disposed of.

I.A. 40566/2024 (u/S 12A of Commercial Courts Act)
3.

As the present suit contemplates urgent interim relief, in light of the

judgment of the Supreme Court in Yamini Manohar v. T.K.D. Krithi, 2023
SCC Online SC 1382, exemption from the requirement of pre-institution
mediation is granted.
4.

This is a digitally signed order.

The application stands disposed of.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 1 of 10

<!-- page 14 -->

I.A. 40568/2024 (for exemption from advance service to Defendants)
5.

The present application has been filed on behalf of the plaintiff

seeking exemption from advance service to defendants No. 10 (Bharat
Sanchar Nigam Ltd.), 13 (Mahanagar Telephone Nigam Ltd.), 18
(Department of Telecommunications) & 19 (Ministry of Electronics and
Information Technology) under Section 80 of the Civil Procedure Code,
1908 (CPC).
6.

In view of the urgent ex parte relief sought, the plaintiff is granted

exemption from the requirement of issuing notice to the defendants no. 10,
13,18 and 19 under Section 80 of the CPC.
7.

The application stands disposed of.

I.A. 40569/2024 (O-XI R-1(4) of the Commercial Courts Act)
8.

The present application has been filed on behalf of the plaintiff

seeking leave to file additional documents under the Commercial Courts
Act, 2015.
9.

The plaintiff are permitted to file additional documents in accordance

with the provisions of the Commercial Courts Act, 2015.
10.

Accordingly, the application is disposed of.

CS(COMM) 837/2024
11.

Let the plaint be registered as a suit.

12.

Issue summons.

13.

Summons be issued to the defendants through all modes. The

summons shall state that the written statement(s) shall be filed by the
defendants within thirty days from the date of the receipt of summons.
Along with the written statement(s), the defendants shall also file an
affidavit of admission/denial of the documents of the plaintiff, without

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 2 of 10

<!-- page 15 -->

which the written statement(s) shall not be taken on record.
14.

Liberty is given to the plaintiff to file replication(s), if any, within

thirty days from the receipt of the written statement(s). Along with the
replication(s) filed by the plaintiff, affidavit of admission/denial of the
documents of the defendants be filed by the plaintiff.
15.

The parties shall file all original documents in support of their

respective claims along with their respective pleadings. In case parties are
placing reliance on a document, which is not in their power and possession,
its detail and source shall be mentioned in the list of reliance, which shall
also be filed with the pleadings.
16.

If any of the parties wish to seek inspection of any documents, the

same shall be sought and given within the timelines.
17.

List before the Joint Registrar on 4th December, 2024 for completion

of service and pleadings.
18.

List before the Court on 27th February, 2025.

I.A. 40565/2024 (O-XXXIX Rule 1 & 2 of CPC)
25.

The present suit has been filed for permanent injunction, rendition of

accounts and damages for the infringement of the exclusive rights in the
plaintiff’s original content/work, which is protected under the Copyright
Act, 1957, against defendants no.1-3 which are rogue apps and websites that
substantially indulge in online piracy by making original content available
for download and otherwise providing access to infringing and illegal
content.
26.

It is averred in the plaint that the Plaintiff is a leading entertainment

and media company in India engaged in, inter alia, the production of
popular content broadcast on its STAR channels. The Plaintiff is also an

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 3 of 10

<!-- page 16 -->

exclusive right owner for several works broadcasted on its STAR channels.
Plaintiff, along with its affiliates, is the owner of an extensive portfolio of
more than 70 channels in over nine languages (all channels owned and/or
distributed by Plaintiff are hereinafter collectively referred to as “STAR
Channels”). Plaintiff owns and operates the online audio-visual streaming
platform and website, ‘www.hotstar.com’, and the mobile application,
‘Disney+ Hotstar’, formerly known as ‘Hotstar’ (hereinafter collectively
referred to as “Disney+ Hotstar”). With the widest range of content in India,
Disney+ Hotstar offers over 100,000 hours of TV shows and movies across
8 languages, Disney+ originals, latest American shows, blockbuster
Hollywood movies and content from international studios, exclusive new
content from the Hotstar Specials label, regional and national news, and
coverage of every major global sporting event.
27.

Plaintiff claims to have exclusive rights in the aforesaid works by

virtue of provision of Section 14(d) of the Copyright Act, 1957 including
inter alia the rights to publicly exhibit and communicate the said content
through any medium or mode, including on STAR Channels or Disney+
Hotstar. It is pleaded that by virtue of the exclusive media rights granted to
the Plaintiff, they broadcast, telecast and/or communicate to the public, its
Original Shows / Original Content and the STAR Channels on the digital
platform, Disney+ Hotstar, owned by the Plaintiff.
28.

It is contended that defendants no. 1 to 3, (“defendant websites and

apps”) are online locations and mobile applications whose purpose is to
communicate, make available for viewing and providing access to content of
the Plaintiff free of cost (or at minimal subscription) and without any
authorization. These Rogue Apps are completely illegal mobile applications

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 4 of 10

<!-- page 17 -->

and have no permission or authorisation to reproduce, store, transmit,
communicate, make available for viewing or provide access to any of the
Plaintiff’s Content. It is also submitted that most of the content
communicated through these Rogue Apps does not belong to them. It is also
contended that the download, distribution and use of these Android based
Rogue Apps, occurs through an .APK (“Android Package Kit” / “Android
Application Package”). The primary intent and purpose of these Rogue
Apps is to exploit various copyright-protected works, of the Plaintiff’s
content and to provide an alternative to legitimate sources to the user, such
that the user does not have to pay for enjoying the copyright-protected
works. An illustrative list of illegal content made available by the defendant
websites has been provided in paragraph 9 of the plaint.
29.

In order to protect and enforce their exclusive rights, the plaintiff

investigated

and

monitored

the

defendant’s

Rogue

Apps/UIs/Domains/websites and gathered evidence of their infringing
activities, which has been filed along with the suit.
30.

It is further contended that despite the legal notice calling upon the

concerned defendants to cease from engaging in their infringing activities,
they continue to infringe the rights in the plaintiff’s original content.
31.

In light of the above, it is contended that the defendants nos. 1 to 3 are

liable for infringement of the plaintiff’s copyright works under Section
51(a)(ii), Section 51(b) and Section 51(a)(i) of the Act, for making a copy of
the original content, including storing of it in any medium by electronic or
other means and communicating the original content to the public the
hosting, streaming, reproducing, distributing, making available to the public,
and/or communicating to the public of the original content for streaming and

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 5 of 10

<!-- page 18 -->

downloading, or facilitating the same, without authorization of the plaintiff.
In support of the aforesaid contention, reliance is placed on the decision of
this court in CS(COMM) 724 of 2017 dated 10th April, 2019 titled UTV
Software Communication Ltd. &Anr. v. 1337x.to and Ors.
32.

It is further contended by the plaintiff’s counsel that the creators of

the defendants no. 1-3 Rogue Apps are anonymous and the information
provided in the public domain regarding the owners of their related websites
is either incomplete, incorrect and/or protected behind a veil of secrecy.
These Rogue Apps/UIs/Domains/websites hide behind domain privacy
services offered by various domain name Registrars, which enable a website
owner to hide behind a veil and not disclose any contact details publicly, to
protect his privacy. Defendants no. 4 (Name.com, Inc.), 5 (Spaceship, Inc.),
6 (Hostinger Operations, UAB), 7 (Name Cheap Inc.), 8 (Go Daddy LLC)
are domain name registrars providing domain name registration to the
defendants 1-3.
33.

In order to overcome this, the plaintiff has arrayed various internet

and telecom services providers (ISPs) as the defendants no. 9-17 (hereinafter
"the said ISPs"), DoT as the defendant no. 18, MEITY as the defendant no.
19 in the present suit to ensure the effective implementation of orders passed
by this Court.
34.

Issue notice

35.

Notice be issued to the defendants through all modes.

36.

Reply(ies) be filed within four weeks.

37.

Rejoinder(s) thereto, if any, be filed two weeks thereafter.

38.

In view of the averments noted hereinabove and in view of the

judgment passed in UTV Software Communication Ltd. (supra), this Court

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 6 of 10

<!-- page 19 -->

is of the opinion that a prima facie case is made out in favour of the plaintiff.
Balance of convenience is also in favour of the plaintiff. Further, irreparable
harm or injury would be caused to the plaintiff if an interim injunction order
is not passed.
39.

Accordingly, defendants No. 1 to 3 (and any such other UIs/websites

which appears to be associated with any of the defendant apps and websites
based on its name, branding or the identity of its operator, or discovered to
provide additional means of accessing, the defendant apps and websites, and
other domains/domain/apps/UIs along with their sub domains and
subdirectories, owners/website operators/entities which are discovered to
have been engaging in infringing the plaintiff’s exclusive rights), their
owners, partners, proprietors, officers, servants, employees, and all others in
capacity of principals or agents, acting for and on their behalf, or anyone
claiming through, by or under them are hereby restrained, from, in any
manner hosting, streaming, reproducing, distributing, making available to
the public and/or communicating to the public, or facilitating the same, on
their Apps/UIs/websites, through the internet in any manner whatsoever, any
cinematograph work/content/programme/show in relation to which plaintiff
has a copyright.
40.

The defendants No. 4 to 8 shall ensure compliance with this order by

blocking defendants no. 1 to 3 websites, their URLs and the respective UIs
as filed along with the suit (Pg 1 - Vol 1) (also annexed herewith as
annexure - A) and any other UIs/apps/websites notified by the plaintiff by
filing of an affidavit.
41.

The defendants no. 4 to 8, their directors, partners, proprietors,

officers, affiliates, servants, employees, and all others in capacity of

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 7 of 10

<!-- page 20 -->

principal or agent acting for and, on their behalf, or anyone claiming
through, by or under it, are directed to disclose the following information of
the defendants no. 1 -3 (and any such other websites/UIs which are
discovered during the course of the proceedings and notified on Affidavit by
the plaintiff to have been infringing/ authorizing the infringement of the
plaintiff’s exclusive rights, copyrights and broadcast reproduction rights):
A. Complete details (such as name, address, email address, phone
number, IP address etc.) of the defendants no. 1 - 3 (and any such
other websites/UIs which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff to have been
infringing/ authorizing the infringement of the plaintiff’s exclusive
rights, copyrights).
B. Mode of payment along with payment details used for registration of
domain name by the registrant i.e., defendant no. 1 – 3 (and any such
other websites/UIs which are discovered during the course of the
proceedings and notified on Affidavit by the plaintiff to have been
infringing/ authorizing the infringement of the plaintiff’s exclusive
rights, copyrights).
42.

The defendants No. 9 to 17 shall ensure compliance with this order by

blocking defendants no. 1 to 3 websites, their URLs and the respective UIs
as filed along with the suit (Pg 1 - Vol 1) (also annexed herewith as
annexure - A) and any other apps/websites notified by the plaintiff by filing
of an affidavit.
43.

Defendants no. 18 and 19 are further directed to take immediate steps

and issue requisite notifications within five working days, calling upon

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 8 of 10

<!-- page 21 -->

various internet and telecom service providers registered under them to
block the aforementioned websites/UIs identified by the plaintiff.
44.

Further, the plaintiff shall, within one week of having filed such an

affidavit, move an appropriate application for impleadment of the
aforementioned websites/UIs notified by the plaintiff.
45.

Compliance under Order XXXIX Rule 3 of the Code of Civil

Procedure, 1908 (CPC) be done within one week from today.
46.

List before the Joint Registrar on 4th December, 2024 for completion

of service and pleadings.
47.

List before the Court on 27th February, 2025.
AMIT BANSAL, J

SEPTEMBER 26, 2024
kd

This is a digitally signed order.

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 9 of 10

<!-- page 22 -->

ANNEXURE - A

LIST OF WEBSITES / DOMAINS PROVIDING ACCESS TO THE .APK
FILES OF ROGUE APPS

S.NO

WEBSITES

1.

https://movieblast.rocks/

2.

https://movieshubapk.com/

3.

https://novatv.app/

LIST OF DOMAINS PROVIDING USER INTERFACE (UI) FOR
FUNCTIONING OF THE ROGUE APPS

S.NO

This is a digitally signed order.

WEBSITES

1.

mb.movieblast.rocks

2.

movapp.techmirrorhublinks.site

3.

https://teatv.xyz

CS(COMM) 837/2024

The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/09/2024 at 00:08:53

Page 10 of 10

<!-- page 23 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
