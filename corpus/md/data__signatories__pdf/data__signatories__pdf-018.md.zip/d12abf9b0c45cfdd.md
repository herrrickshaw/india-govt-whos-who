---
doc_id: "d12abf9b0c45cfdd"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2026/05/11b8dd668a69809af0f28cc84c22f6ac.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "National Programme for Control of Blindness & Visual Impairment - Group II Day 2 20 September 2019"
date: "2026-05-13"
pages: 15
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4e0eb534249f92ab"
---

<!-- page 1 -->

National Programme for Control of Blindness &
Visual Impairment

<!-- page 2 -->

Introduction
 National Programme for Control of Blindness (NPCB) launched in

1976.The Trachoma Control Programme started in 1963 was merged
under NPCB in 1976.
 In the beginning, NPCB was a 100% centrally sponsored programme
(now from 12th FYP it is 60:40 in all States/UTs and 90:10 in hilly
states and all NE States).
 Nomenclature of the programme was changed from National
Programme for Control of Blindness to National Programme for
Control of Blindness &Visual Impairment (NPCBVI) in 2017.

<!-- page 3 -->

Burden of Blindness
 Prevalence of Blindness - 1.1%. (Blindness Survey 2001-02).
 Prevalence of Blindness – 1.0%. (Blindness Survey 2006-07).
 Blindness Survey (2015-18) completed. Findings to be released shortly.
 WHO Goal – reduction of prevalence of avoidable blindness to 0.3% by 2020.
 NHP target – to reduce the prevalence of blindness to 0.25% by 2025 and disease burden by one third from current

levels.

Causes of Blindness









Cataract (62.6%)
Refractive Error (19.70%)
Glaucoma (5.80%)
Posterior Segment Disorder (4.70%)
Surgical Complication (1.20%)
Posterior Capsular Opacification (0.90%)
Corneal Blindness (0.90%)
Others (4.19%)

<!-- page 4 -->

Goals & Objectives of the Programme
Goal
 To reduce the prevalence of blindness to 0.3% by the year 2020

Objectives
 Reduce the backlog of blindness through identification and treatment of blind.
 Develop comprehensive eye-care facilities at each level i.e. PHCs, CHCs, Dist. Hospitals,
Medical Colleges and Regional Institutes of Ophthalmology.
 Develop human resources for providing Eye Care Services.
 Improve quality of service delivery.
 Secure participation of Voluntary Organizations/Private Practitioners in eye care services.
 Enhance community awareness on eye care.

<!-- page 5 -->

Summary of Programme activities
NHM Component
S. No

Activities

1

Free Cataract Surgery at district hospitals and identified NGO eye hospitals/ Pvt. Practitioners

2

Eye Screening and Distribution of Free spectacles to School children and elderly

3

Collection of Donated Eyes through network of eye banks and eye donation centres

4

Diagnosis and Treatment of other eye diseases (glaucoma, childhood blindness, squint etc.) at District
Hospitals and identified NGO eye hospitals

5

Procurement and maintenance of Ophthalmic equipments at sub-district/district Hospitals and
Vision Centres (in public sector only from FY 2018-19).

6

Training of Para Medical Ophthalmic Assistants posted at PHC/ District Hospitals

7

Strengthening of eye banks (in public sector only from FY 2018-19).

8

IEC activities on promoting eye health, preventing eye diseases and increasing utilization of services.

<!-- page 6 -->

Summary of Programme activities
Tertiary Eye Care Components
S. No Activities
1

Provision of super specialty and referral eye care services for diabetic retinopathy, Glaucoma, childhood blindness,
retinopathy of prematurity and Keratoplasty (corneal transplantation) etc. at Regional Institutes of Ophthalmology
and Medical Colleges.

2

Construction of modular Eye OTs at RIOs for providing modern and tertiary level eye care services

3

Training of eye surgeons in various specialties of Ophthalmology for skill development

4

Provision for supply of MK Medium to Govt. Eye Banks through Dr. R.P.Centre, AIIMS, New Delhi for preservation
of donated corneas and improve corneal utility rate.

5

Conducting Surveys (blindness & Visual Impairment Survey, Trachoma Survey etc.) through identified institutions.

<!-- page 7 -->

Physical Performance
Total No. of Cataract Surgery
Year
2016-17
2017-18
2018-19
2019-20*

Target

No. of Cataract
operations performed

%
Achievement

66,00,000
66,00,000
66,00,000
67,00,000

64,81,435
64,41,487
66,85,476
16,46,921

98
97
101

Distribution of free spectacles under School Eye Screening
Year

2016-17
2017-18
2018-19
2019-20*

No. of free spectacles provided to school children suffering from
refractive errors
Target

Achievement

9,00,000
9,00,000
9,00,000
10,00,000

7,57,906
7,98,411
8,79,488
82,590

% Achievement

84
88
97

<!-- page 8 -->

Physical Performance …
Collection of donated Eyes for corneal transplantation

No. of donated eyes collected
Target
Achievement

Year
2016-17
2018-19

50,000
50,000
55,000

65,135
71,709
68,007

2019-20*

70,000

19,950

2017-18

% Achievement
130
143
123

Treatment/management of other eye diseases
(Diabetic retinopathy, glaucoma, childhood blindness, keratoplasty etc.)
Year
2016-17
2017-18
2018-19
2019-20*

Target

No. of Cases treated

72,000
72,000
2,00,000
6,00,000

4,04677
5,48,448
6,14,433
1,88,507

* The physical progress report for the year 2019-20 is provisional

%
562
761
307
31.42

<!-- page 9 -->

Physical Performance …
Training of Eye Surgeons:
Year
2016-17
2017-18
2018-19
2019-20

No. of eye surgeons trained in various specialties of
ophthalmology
121
125
129
40

Training / Workshops
 All State & District Program Officers and Ophthalmologists were trained in diagnosis and
treatment of Trachoma in 9 previously trachoma endemic States/UTs
450 Ophthalmologist were trained in two days workshops in early diagnosis and treatment of
Glaucoma during 2016-17 & 2017-18.

<!-- page 10 -->

Major issues
 Low utilization of allotted funds by most of the States except Chhattisgarh and Sikkim
 Poor physical performance by many states Nagaland, Sikkim, Lakshadweep, Meghalaya, J & K

and Jharkhand.
 Delay in NGO payments (for performing cataract and treatment of other eye diseases) by
District Programme Officers inspite of their uploading of data in the MIS of NPCBVI.
 Quality issue: Sporadic episodes of cluster enophthalmities keep coming inspite of circulation
of prescribed eye surgery guidelines.
 Poor nominations for training: Very few nominations of eye specialists are sent by States for
refresher hands on training. This results in inadequate skilled/trained eye surgeons in States.
 Many of the States do not have sanctioned posts of Ophthalmologists at district level.

<!-- page 11 -->

Major issues concerning RIOs
 Utilization certificate for the grant are awaited from most of the RIOs (except Patna and

Cuttack).
 All RIOs need to develop Modular Eye OTs for providing superspeciality eye care services
 All RIO need to conduct training eye surgeons in superspeciality eye care
 Need for setting up of eye banks and improvement in Keratoplasty services
 Physical progress reports has been received from 6 RIOs only.

<!-- page 12 -->

Innovations under NPCBVI
 Introduction of tele-ophthalmology in eye care.

Linkage of lower units
(PHC/vision centres) with nearby higher units (district hospitals/Medical
Colleges) for coverage of hilly and hard to reach areas (Tripura, Andhra
Pradesh, Tamila Nadu).

 Initiating Diabetic Retinopathy Projects at Karnataka, Tamil Nadu, West

Bengal, Madhya Pradesh, Maharashtra etc.).

 Corneal Blindness Backlog free initiative in Punjab.
 Use of digital media in IEC.

12

<!-- page 13 -->

Thank You

<!-- page 14 -->

Funds released to Regional Institutes of Ophthalmology
Rs. In Lakhs
(RIOs)
Sl. No. Name RIOs through respective State
Health Society

2013-14

2014-15

1

RIO, Patna, Bihar

100.00

2
3
4
5
6
7
8
9
10

RIO, Ahmedabad, Gujarat
RIO, Guwahati, Assam
RIO, Amritsar, Punjab
RIO, Thiruvananthapuram, Kerala
RIO, Kolkata, West Bengal
RIO, Minto RIO Bangalore, Karnataka
RIO, Srinagar,J& K
RIO, Cuttack, Odisha
RIO, Dr.R.P.Centre,Delhi

100.00
100.00
100.00
300.00
200.00
100.00
100.00
100.00

100.00

2016-17

2017-18

Grand Total From
2013-14 to 2017-18
100.00

200.00

300.00
100.00
100.00
300.00
600.00
300.00
100.00
100.00
0.00

300.00
200.00

<!-- page 15 -->

Funds released to RIOs under (NPCB&VI) Rs. In Lakhs
Sl. No. Name of Society (RIOs)
11
12
13
14
15
16
17
18
19

*

2013-14

RIO, Chennai
RIO, Allahabad
RIO, Bhopal M.P.
RIO, Raipur,Chhattisgarh
RIO, Jaipur,Rajasthan
RIO, Ranchi, Jharkhand
RIO Rohtak, Haryana
R.IO Mumbai,Maharashtra
RIO, Hyderabad Telangana

Total

2014-15

2016-17

2017-18

100.00
100.00

200.00

100.00
100.00
100.00

During FY: 2015-16 and 2018-19 no funds were released.

300.00
1500.00

400.00

200.00
200.00
200.00
200.00
200.00
1900.00

Grand Total From
2013-14 to 201718
100.00
300.00
0.00
300.00
200.00
200.00
100.00
200.00
500.00
3900.00
