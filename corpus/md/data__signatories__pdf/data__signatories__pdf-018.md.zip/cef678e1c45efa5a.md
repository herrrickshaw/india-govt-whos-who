---
doc_id: "cef678e1c45efa5a"
source_url: "https://powermin.gov.in/static/uploads/2026/05/77538f6e66414b259bb49728c256c545.pdf"
ministry: "Power"
title: "Sixth Amendment dtd 27th March 2025 of SBDs for procurement of Inter-State Transmission Services (ISTS) through Tariff Based Competitive Bidding (TBCB) process"
date: "2025-03-27"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c71064765aa72444"
---

<!-- page 1 -->

F. No.15l4l2O21-Trans

qRd lf{iDf{ / Government of lndia
ft6gdd7rdqT Ministry of Power
fqfrqEf gtlFf f Transmission Division)
*****
erc

rrfr rrfi, ra1 qnf, T{ ffi- r oool
1

Shram Shakti Bhawan, Rafi Marg. New Delhi-l10001

Pqi6': z7qd,2o2s
To,
'l

. Chairperson, Central Electricity Authority, New Delhi

2. Secretary, Central Electricity Regulatory Commission, New Delhi.

3. Additional Chief Secretaries / Pr. Secretaries/ Secretaries of Power/ Energy

Departments of all States/ UTs and Heads of Power Sector Organizations under
States/UTs.
4. Chairman/ Managing Directors of all power sector CPSUs (under Administrative
control of M/o Power).
5. COO, Central Transmission Utility of lndia Limited.
6. Chairpersons of all SERCs/JERCs - for kind information please.
7. CEO, RECPDCL
8. CEO, PFCCL
9. CMDs/MDs, Transcos of all States/UTs.

Subject: Amendment in Standard Bidding Documents for procurement of lnter-State
Transmission Services through Tariff Based Competitive Bidding (TBCB) process regarding
Madam/Sir,

I am directed to refer to Standard Bidding Documents (comprising of Request for
Proposal (RfP) and Transmission Service Agreement (TSA)) for procurement of lnter-State
Transmission Services through Tariff Based Competitive Bidding (TBCB), issued by
Ministry of Power vide O.M. No. 151112017-Trans dated 06th August 2021 and an
amendment issued in revised SBDs vide Letters No. 1514t2021- Trans dated 13th June
2022, and dated 16th June 2023 and to say that representations have been received in this
Ministry from the Transmission developers seeking relaxation in respect of Para 1.6.1.1 of
RfP document and Para 5.1 .4 (a) of TSA document, regarding actual location of
substations, switching stations or HVDC terminal or inverter stations in the scope of
Transmission Service Provider (TSP) which prescribe that these shall not be beyond 3 km
radius (for a Generation Pooling Substation and for Load Serving Substation) / 10 km ( for
Greenfield lntermediate Substation) of the location proposed by the BPC in the survey
report.

2.

The matter has been examined in this Ministry in consultation with the stakeholders
and it has been decided that Para 1.6.'l .'l of RfP document and Para 5.1.4 (a) of TSA
document shall stand modified as under:-

!

5

<!-- page 2 -->

Para I

Document
Para
1.6.1.1 of
RfP

Existing Provisions

To be replaced by

Establishment, operation and Establishment, operation and
maintenance of the Project on build, maintenance of the Project on build,
own, operate and transfer basis and
completion of all the activities for the
Project, including survey, detailed
project report formulation, arranging
finance, project management,
necessary Consents, Clearances
and Permits (way leave, environment
& forest, civil aviation, railway/ road/
river/ canal/ power crossingl pfCC,
etc.), land compensation, design,
engineering, equipment, material,

own, operate and transfer basis and
completion of all the activities for the
Project, including survey, detailed
project report formulation, arranging

finance, project management,

necessary Consents, Clearances and
Permits (way leave, environment &
forest, civil aviation, railwayl road/

riverl canall power crossing/ PTCC,
etc.), land compensation, design,
engineering, equipment, material,
construction, erection, testing & construction, erection, testing &
commissioning. Further, the actual commissioning.
location of Greenfield substations

(Switching Stations or HVDC Further, the actual location of
Terminal or lnverter Stations) for a Greenfield Substation (Switching

lgeneration pooling substation and Station or HVDC Terminal or lnverter
for load serving substations in the Station) in the scope of TSP:
scope of TSP shall not be beyond 3
Km radius of the location proposed
For a Generation Poollng
by the BPC in the survey report.
Substation shall not be beyond
However, actual location of any
Km radius of the locatio
Greenfield lntermediate Substations
proposed by the BPC in thei
in the scope of TSP shall not be
Survey Report.
beyond 10 Km radius of the location
For Load Serving Substation
proposed by the BPC in the Survey
within the scope of TSP shall n
Report.
be beyond 5 Km radius of th
location proposed by the BPC in
their Survey Report

For an lntermediate Substation
shall not be beyond 10 Km radius
of the location proposed by the
BPC in their Survey Report.
Para 5.1.4
(a) of TSA

The TSP shall be responsible for

The TSP shall be responsible for

(a) [To be deleted by the BPC in (a) [To be deleted by the BPC in case
case no land acquisition is involved no land acquisition is involved in the
in the Project and replaced by Project and replaced by "deleted"l
"deleted"l acquisition of land for acquisition of land for location specific
location specific substations, substations, switching stations or

switching stations or HVDC terminal HVDC terminal or inverter stations.
or inverter stations. Also, the actual Also, the actual location of Greenfield
location of Greenfield substations Substation (Switching Station or
HVDC HVDC Terminal or lnverter Station in
lpqitching Stations

or

2

,*\d'

<!-- page 3 -->

Terminal or lnverter Stations) for a the scope of TSP
generation pooling substation and
for load serving substations in the
Generation Pooling
scope of TSP shall not be beyond 3
Substation shall not be beyond 3
Km radius of the location proposed
Km radius
the location

For a

by the BPC in the survey report.
However, actual location of any

Greenfield lntermediate Substations
in the scope of TSP shall not be
beyond 10 Km radius of the location
proposed by the BPC in the Survey
Report.

3.

of

proposed by the BPC in theii
Survey Report.

For Load Serving Substation
within the scope of TSP shall not
be beyond 5 Km radius of the
location proposed by the BPC in
their Survey Report
For an lntermediate Substation
shall not be beyond 10 Km radius
of the location proposed by the
BPC in their Survey Report.

This issues with the approval of the Minister for Power.

.
'
rlYVg
)Srf
Yours faithfully,

orcRc€EEfcr;fro

.}Tfigiittl, qRiITRTFT{

?dfre: zsszsz42
{-*fi: t.ansdesk-mop@nic.in
Copy to:

1. PS to Hon'ble Minister of Power.

2. PS to Hon'ble Minister of State for Power.
3. Sr. PPS/ PPS/ PS to Secretary (Power)/ Addl. Secretaries/JS&FA'/ Economic
Advisor/ All JSs/ All Chief Engineers / All Directors of Ministry of Power.
4. Technical Director, NlC, MoP- with the request to upload the letter on the website of
MoP.

3

'
