---
doc_id: "d0add01c17affe6f"
source_url: "https://www.dot.gov.in/static/uploads/2025/12/629cf583759c21a8fc7a64627c3e3122.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 833 of 2023 in Honble High Court of Delhi - iro Def. No. 77 DoT instructions dated 14.08.2025 to ISPs"
date: "2025-12-24"
pages: 38
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "005eae101b9a5032"
---

<!-- page 1 -->

813-7/25/2024-DS

I/3306391/2025

By Email/DoT Website

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Services Cell)

No. 813-7/25/2024-DS

Dated: 14-08-2025

To,
All Licensees with Internet Service Authorization

Subject: CS (COMM) NO. 833/2023: UNIVERSAL CITY STUDIOS LLC. & ORS.
versus FZTVSERIES.MOBI & ORS in the High Court of Delhi.

Please ﬁnd enclosed the Hon’ble High Court of Delhi orders dated
06.08.2025 and 21.11.2023 in the captioned suit.
2. Please refer to para 1 & 3 of the Court order dated 06.08.2025 and para 32 of
the Court order dated 21.11.2023 in respect of blocking the website aniwave.at ,
impleaded as defendant no. 77 in the captioned suit.
3.
In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access
to the said websites/domains, as above, in compliance with the said court order.
Encl: A/A

Director (DS-II)
Email: dirds2-dot@nic.in
Copy to:
i.) Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in); Requested to take action as per the said Court
order/ enclosed Annexure pl.
ii.) Sh. Pushpit Ghosh (pushpit@saikrishnaassociates.com), Plaintiﬀ's Counsel for
kind information and with a request to take action as per the enclosed Annexure pl.

<!-- page 2 -->

SCHEDULE A [CS COMM 833/2023]
URL of New Mirror
/Rdirect/Alphanumeric
Variation of Injuncted
Website

Domain Name of
IP Addresses of New
Mirror/Redirect/Alphanume Mirror
ric Variation of Injuncted
/Redirect/Alphanum
Website
eric Variation of
Injuncted Website

https://aniwave.at

aniwave.at

172.67.196.243
104.21.41.242

<!-- page 3 -->

Compliance with Order of the Hon’ble Delhi High Court dated 6th August 2025 in Universal City
Studios LLC and Ors. v. fztvseries.mobi & Ors. CS(COMM) NO. 833 OF 2023

Pushpit Ghosh < pushpit@saikrishnaassociates.com >
Wed, 13 Aug 2025 9:26:50 PM +0530

To "secy-dot"<secy-dot@nic.in>,"dirds2-dot"<dirds2-dot@nic.in>,"cyberlaw-legal"<cyberlawlegal@meity.gov.in>
Cc "Mehr Sidhu"<mehr@saikrishnaassociates.com>

WITHOUT PREJUDICE
BY-EMAIL
Date: 13th August 2025
Department of Telecommunications
Through Secretary,
Ministry of Communications and IT,
20, Sanchar Bhawan, Ashoka Road,
New Delhi – 110001
secy-dot@nic.in; dirds2-dot@nic.in
Ministry of Electronics and Information Technology
Through the Director General (DIT) Cyber Laws & e-security),
Electronics Niketan, 6, CGO Complex,
Lodi Road, New Delhi – 110003
cyberlaw-legal@meity.gov.in

Dear Sir,
We act for the Plaintiffs i.e. Universal City Studios LLC, Warner Bros. Entertainment Inc., Columbia Picture
Industries Inc., Netflix Studios LLC., Paramount Pictures Corporation and Disney Enterprises Inc., (“Our
Clients”) in the above-captioned matter. We are under instructions to apprise you of the following:
1. Our Clients are the author and/ or first owner and / or owner of Pictures (“Original Content”) for
which they own exclusive copyrights. Our Clients instituted a Suit against various infringing websites
before the Hon’ble High Court of Delhi, inter alia, for interim injunction restraining violation of its
exclusive statutory rights in relation to the Original Content as well as for other reliefs. Our Clients also
impleaded various internet and telecom service providers, as well as the concerned Government
Departments (Department of Telecommunication (“DOT”) and the Ministry of Electronics and
Information Technology (“Meity”) ), as Defendants, to ensure effective compliance of any orders that
the Hon’ble Delhi High Court was inclined to pass.
2. The above-mentioned matter came up before Hon’ble Miss Justice Prathiba M. Singh, Delhi High
Court on 21st November 2023. The Hon’ble Court was pleased to pass an interim injunction against the
defendant websites and allowing the Plaintiff to implead any mirror/redirect/alphanumeric websites
providing access to the injuncted websites by way of filing an Order 1 Rule 10, CPC application. The
relevant extract of the ex-parte ad interim order is reproduced herewith :
“30. Under these circumstances, the Plaintiffs have established a prima facie case for grant
of an injunction. Balance of convenience is also in favour of the Plaintiffs in view of
unauthorised and illegal use of Copyrighted contents by such rogue websites leading to
significant monetary losses to the Plaintiffs. Irreparable harm and injury is likely to be
caused if the injunction as sought is not granted. Accordingly, Defendant Nos. 1 to 45
arrayed as Annexure A, which are all rogue websites shall stand restrained from streaming,

<!-- page 4 -->

reproducing, distributing, making available to the public and/or communicating to the
public, in any manner, any copyrighted content of the Plaintiffs including future works of the
Plaintiffs.
31. In the facts and circumstances as set out above, an ex parte ad interim injunction is
granted restraining the Defendants, who are all rogue websites, from in any manner
streaming, reproducing, distributing, making available to the public and/or communicating
to the public any copyrighted content of the Plaintiffs including future works of the
Plaintiffs, in which ownership of copyright is undisputed, through their websites identified in
the present suit or any mirror/redirect websites or alphanumeric websites, or any variations
thereof including those websites which are associated with the Defendants’ websites either
based on the name, branding, identity of its operator, or discovered to provide additional
means of accessing the Defendant’s website, and other domains/ domain along with their
sub-domains and sub-directories, owners, website operators/ entities or even sources of
content.
32. Insofar as Defendant Nos. 46-54 are concerned, the said ISPs shall give effect to this
injunction by blocking the said websites. Defendant No. 55 and 56 - Department of
Telecommunications (DOT) and Ministry of Electronics and Information Technology (MeitY)
respectively shall issue blocking orders against the websites within a period of one week
from the release of the order.
33. The Domain Name Registrars (DNRs) of the rogue websites’ domain names, upon being
intimated by the Plaintiffs shall lock and suspend the said domain names. In addition, any
details relating to the registrants of the said domain names including KYC, credit card,
mobile number, etc. be also provided to the Plaintiff.”
A copy of the ex-parte ad interim order dated 21st November 2023 is attached herewith.
In view of the permanent injunction order dated 21st November 2023, Our Clients had filed an
3.
Impleadment Application against the below mentioned websites, for impleading it as Defendant No. 77,
in the said suit:
Defendant Nos.

Defendant Domains

77.

aniwave.at

4. That the Hon’ble High Court of Delhi vide Order dated 6th August 2025, was pleased to implead the
above-mentioned Defendants and has extended the interim injunction dated 21st November 2023 against
the said Defendants. The relevant portion of the Order dated 6th August 2025 is extracted hereinbelow:
“
3. The order blocking the rogue-websites passed by the Hon’ble Court on 21.11.2023
shall operate qua the freshly impleaded defendant as well, in terms of directions
contained in para nos. 31 to 34 of the order dated 21.11.2023. Accordingly, defendant
ISPs shall give effect to the injunction by blocking defendant no. 77. Further concerned
defendants i.e. Department of Telecommunications and Ministry of Electronics and
Information Technology shall issue blocking orders against defendant no. 77 within a
period of one week. The concerned DNR of the newly impleaded defendant shall lock
and suspend the domain name, and also supply necessary details of the domain name
registrant / KYC etc to the plaintiffs. IA is allowed and disposed off accordingly. .”
5. Accordingly, we request you, Department of Telecommunications - DOT (Defendant No. 55) and
Ministry of Electronics and Information Technology - MEITY (Defendant No. 56) to comply with
th August 2025 by blocking the said website,
the order of the Hon’ble High Court of Delhi dated 6
i.e. Defendant No. 77 identified in Annexure-A (separately attached along with the email as list of
domains).

<!-- page 5 -->

6. A copy of the orders dated 21st November 2023 and Order dated 6th August 2025 along with a copy
of the Impleadment Application and Documents as filed before the Hon’ble High Court of Delhi are
being made available through the following link for your perusal and necessary action:
https://drive.google.com/drive/folders/1TXgMHt4uivwC6eNAa0wpqSR85BrwTIw2?usp=drive_link
7.
For your reference, the next date of hearing in the matter is before the Ld. Joint Registrar on
15 December 2025. In view of the above facts and circumstances, we request you to comply with
the Order of the Hon’ble High Court of Delhi dated 6th August 2025 by blocking the Defendant
Websites as mentioned in paragraph 3 of this letter.

If you have any queries, please feel free to contact us.

Pushpit Ghosh
For Saikrishna & Associates,
Counsel for Plaintiffs

1.

Impleadment Application

2.

List of Websites

3.

Order dated 21st November 2023

4.

Order dated 6th August 2025

-Pushpit Ghosh | Associate | Saikrishna & Associates| 57 Jor Bagh, New Delhi,
110003, India | Handphone: +91-9810002289. [D/8939/2024]
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual
Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment &
Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent
Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege, not
being waived or lost by mistaken transmission or receipt. If you have received this mail in error,
please notify us at info@saikrishnaassociates.com immediately by reply email and destroy the
original - any use, disclosure or copying of this mail is unauthorised.

3 Attachment(s)
Order dated 21.11.23-Universa…

2025.08.06 Universal City Stud…

905.1 KB

119.1 KB

Universal vs. Fztvseries Sched…
10.1 KB

<!-- page 6 -->

$~5
*
+

IN THE HIGH COURT OF DELHI AT NEW DELHI
CS(COMM) 833/2023
UNIVERSAL CITY STUDIOS LLC. & ORS.
.....Plaintiff
Through: Ms. Mehr Sidhu and
Mr. Pushpit Ghosh, Advocates
versus
FZTVSERIES.MOBI & ORS
.....Defendant
Through:

None

CORAM:
JOINT REGISTRAR (JUDICIAL) Dr. AJAY GULATI
ORDER
06.08.2025

%

I.A. No. 19031/2025 on behalf of the plaintiffs seeking
impleadment of additional mirrors, redirects, or
alphanumeric variations as defendant no. 77.
1.

The plaintiffs are seeking to implead an additional rogue-

website as defendant no. 77 because it has been found to be
indulging in illegally disseminating the copyrighted material
belonging to the plaintiffs. Keeping in view the contents of the
suit and the application, the same is allowed. The proposed
defendant is impleaded as defendant no. 77. Issue summons to
the newly impleaded defendant.
2.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve the newly impleaded defendant
with summons within a week, through the electronic mode only,
on filing of PF.
3.

The order blocking the rogue-websites passed by the

Hon’ble Court on 21.11.2023 shall operate qua the freshly
impleaded defendant as well, in terms of directions contained in
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/08/2025 at 10:49:34

<!-- page 7 -->

para nos. 31 to 34 of the order dated 21.11.2023. Accordingly,
defendant ISP’s shall give effect to the injunction by blocking
defendant no. 77. Further concerned defendants i.e. Department
of Telecommunications and Ministry of Electronics and
Information Technology shall issue blocking orders against
defendant no. 77 within a period of one week. The concerned
DNR of the newly impleaded defendant shall lock and suspend
the domain name, and also supply necessary details of the
domain name registrant / KYC etc to the plaintiffs. IA is allowed
and disposed off accordingly.
CS(COMM) 833/2023
4.

Rights of defendant nos. 1 to 67 to file a written statement

have already been closed. Defendant nos. 68 to 76 have been
served on 17.04.2025.

However, the maximum extendable

period for these defendants to file a written statement has yet not
expired.
5.

Put up for completion of pleadings on 15.12.2025.

Dr. AJAY GULATI
(DHJS),
JOINT REGISTRAR (JUDICIAL)
AUGUST 6, 2025/sk

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/08/2025 at 10:49:34

<!-- page 8 -->

$~22
*

IN THE HIGH COURT OF DELHI AT NEW DELHI
Date of decision: 21st November, 2023

+

CS(COMM) 833/2023, I.As. 23077/2023, 23078/2023 &
23079/2023
UNIVERSAL CITY STUDIOS LLC. & ORS.
..... Plaintiffs
Through: Mr. Saikrishna Rajagopal, Ms.
Suhasini Raina, Ms. R. Ramya, Ms.
Mehr Sidhu and Mr. Raghav Goyal,
Advocates (M-9845057887))
versus
FZTVSERIES.MOBI & ORS
..... Defendants
Through: None.
CORAM:
JUSTICE PRATHIBA M. SINGH

Prathiba M. Singh, J. (Oral)
1.

This hearing has been done through hybrid mode.

I.A. 23078/2023 (for exemption)
2.

This is an application filed by the Plaintiffs seeking exemption from

filing certified/translated copies of documents with proper margins, etc.
Original documents shall be produced/filed at the time of Admission/Denial,
if sought, strictly as per the provisions of the Commercial Courts Act, 2015
and the DHC (Original Side) Rules, 2018.
3.

Exemption is allowed, subject to all just exceptions. Accordingly, the

application is disposed of.
I.A. 23079/2023 (u/S 80 CPC)
4.

This is an application filed by the Plaintiffs, seeking exemption from

serving notice to Defendant No. 55- Department of Telecommunications
(DoT) and Defendant No. 56- Ministry of Electronics and Information
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 1 of 30

<!-- page 9 -->

Technology (MEITY) under Section 80 of the CPC.
5.

Exemption is allowed. However, Mr. Harish V. Shankar, ld. CGSC

has been requested to accept notice.
6.

Accordingly, application is disposed of.

CS(COMM) 833/2023
7.

Let the plaint be registered as a suit.

8.

Issue summons to the Defendants through all modes upon filing of

Process Fee.
9.

The summons to the Defendants shall indicate that the written

statement to the plaint shall be positively filed within 30 days from date of
receipt of summons. Along with the written statement, the Defendants shall
also file an affidavit of admission/denial of the documents of the Plaintiffs,
without which the written statement shall not be taken on record.
10.

Liberty is given to the Plaintiffs to file the replication within 15 days

of the receipt of the written statement. Along with the replication, if any,
filed by the Plaintiffs, an affidavit of admission/denial of documents of the
Defendants, be filed by the Plaintiffs, without which the replication shall not
be taken on record. If any of the parties wish to seek inspection of any
documents, the same shall be sought and given within the timelines.
11.

List before the Joint Registrar for marking of exhibits on 11 th January,

2024. It is made clear that any party unjustifiably denying documents would
be liable to be burdened with costs.
12.

List before Court on 21st March, 2024.

I.A. 23077/2023(u/O XXXIX Rules 1 & 2 CPC)
13.

Issue notice.

14.

In a continued effort to curb dissemination of pirated content and its

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 2 of 30

<!-- page 10 -->

availability on internet, the Plaintiffs who are well established Hollywood
Studios have approached this Court seeking blocking and removal of their
copyrighted content, from the internet, accessed through rogue websites.
15.

The Plaintiffs in the present matter before this Court are engaged in

the production and distribution of a large volume of original creative content
including cinematograph films, TV series, motion pictures, etc. (hereinafter
‘content’). The list of Plaintiffs in the present petition is set out in the
following table:
Plaintiff No.

16.

Name of the Plaintiff

1.

Universal City Studios LLC.

2.

Warner Bros. Entertainment Inc.

3.

Columbia Pictures Industries, Inc.

4.

Netflix Studios, LLC

5.

Paramount Pictures Corporation

6.

Disney Enterprises, Inc.

The suit is filed against a number of rogue websites who are

unlawfully disseminating and communicating a large quantum of
copyrighted content of the Plaintiffs. For a ready reference of the names of
the Defendant websites, the list of Defendant websites as given in the memo
of parties of this suit is attached to the present order as Annexure A.
17.

The Plaintiffs claim that the content created, produced and distributed

by, or on behalf of the Plaintiffs’ studios, can be accessed and viewed on a
variety of devices including Televisions, Personal Computers, Laptops,
Tablets, Mobile Phones, etc. The said gadgets also permit authorised
streaming and downloading of this content. The Plaintiffs’ studios own
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 3 of 30

<!-- page 11 -->

Copyright in the entire content which is protectable as cinematograph films
and also own rights in various underlying works – which are recognised
under the Copyright Act, 1957 (hereinafter, ‘the Act’). The Plaintiffs also
claim to have devoted enormous resources in the creation, production and
distribution of the content, as also communication of the content so
developed to the public. It is also stated that considerable effort and
resources are used for even marketing and advertising of the content
developed by the Plaintiffs.
18.

Technology has posed a major challenge for entities like the Plaintiffs

as there is a proliferation of a large number of platforms including websites
from where unauthorised, unlicensed and pirated content of the Plaintiffs
can be downloaded, accessed and viewed by customers and viewers. The
process of production of copyrighted content is a continuous one and almost
on a daily basis new content is being added into the bouquet of content of
the Plaintiffs. Thus, the content consisting of films, TV series, shows, etc. is
itself dynamic in nature and the reproduction, hosting, uploading, streaming,
downloading, broadcasting, telecasting or making available of this content in
an unauthorized manner is, apart from constituting infringement of
Copyright also resulting in enormous monetary loss to the Plaintiffs.
19.

The present suit has been filed by the Plaintiffs against various

websites which are permitting the viewing, streaming, accessing and
downloading of such content without any license or authorisation from the
Plaintiffs. The various websites which are impleaded as Defendant Nos. 1
to 45 have different avatars but continue to make available the unauthorised
content of the Plaintiffs and also other copyright holders. Such websites
primarily contain content which is being taken in an unauthorised manner,
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 4 of 30

<!-- page 12 -->

from various platforms including that of the Plaintiffs. Some of the websites
are newer versions of rogue websites which have been injuncted in other
litigation. Some of the glaring features of these rogue websites are as
follows:
i)

No details are available as to the persons or entities who have
registered the domain names and the websites have subscribed to
features like privacy protect, to hide/mask their identity;

ii)

There is no clarity from a perusal of the websites as to who is the
person or entity who is making available the content, which is
being hosted, streamed or viewed on these websites;

iii) There are no contact details and addresses which are available in
most occasions, except e-mails addresses. Some of the websites
are also providing advertising for services such as Virtual Private
Networks (VPNs) and thus, appear to be generating revenue for
themselves;
iv) These rogue websites are also providing different quality and
format options for downloading Copyrighted content of the
Plaintiffs, including High Definition (HD option);
v)

The content hosted or linked on the said websites are also
downloadable on mobile phones;

vi) The websites also have utilized content from OTT platforms and
various regional as also foreign language cinematograph films;
vii) It also appears that the websites encourage users to join the
platforms which support sharing of voluminous content such as
Telegram, etc. in order to be able to communicate and transmit
unauthorised content;
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 5 of 30

<!-- page 13 -->

viii) Some websites give different options to the user and also provide
the genre of the content;
ix) The

FZ

series

of

domain

names

like

fzmovies.net,

fztvseries.mobi, fzstudios.app are making available the pirated
content on a real time basis and the said domain names and
website operators are also using other domain names such as
Mobiletvshows.net;
x)

Some instances of promotion of contents and advertising within
the sites are reproduced herein below:

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 6 of 30

<!-- page 14 -->

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 7 of 30

<!-- page 15 -->

xi) In some instances, these rogue websites are also promoting their
mobile applications and promoting the downloading of the ‘.apk’
files for the same. An example of this is set out below:

20.

The ld. Counsel for the Plaintiffs submits that the Plaintiffs have

issued legal notices to all the Defendant websites, however only few of them
reverted to the notices.
21.

Some

of

the

websites

such

as

raretoonsindia.pro,

raretoonsindia.com.co, and similar extensions thereof are showing children’s
content. A reply was received from the one series of domain names i.e.,
raretoonsindia.pro,

raretoonsindia.watch

raretoonsindia.com.co,

raretoonsindia.tv from the email id- raretoonsindia@proton.me on 3rd
November, 2023 to the effect that all content is deleted. The said reply is
extracted herein below:
“Thanks For Informing Us! All Requested Content is
Deleted!”
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 8 of 30

<!-- page 16 -->

22.

However, immediately thereafter, instead of the four domain names

which were issued a notice, a new domain name being www.raretoons.me
was made available online and the corresponding website had surfaced
having the identical pirated content to that of the earlier four domain names.
23.

It is clear from a perusal of the screenshots that have been placed on

record that the rogue websites have a way of surfacing every time when
notices are issued or blocking orders are issued. This Court has from timeto-time evolved jurisprudence on protecting copyrighted content. One of the
first decisions which took stringent measures against such websites was the
decision authored by Justice Manmohan in UTV Software Communication
Ltd. and Ors v. 1337x.to and Ors, (2019) 78 PTC 375 (Del). In the said
decision, the Court took note of the dynamic nature in which duplication of
websites can happen, especially because mirror websites can spring up
within a matter of a few minutes.
24.

Thereafter, several orders have also been passed by this Court in

respect of rogue websites such as such as in CS(COMM) 157/2022 titled
Star India Pvt. Ltd v. Live Flixhub.Net, CS(COMM) 471/2019 titled Star
India Pvt. Ltd. Vs. Moviemad.biz & Ors, and CS(COMM) 195/2019 titled
Star India Pvt. Ltd. Vs. Extramovies.host & Ors. These orders have clearly
established without any doubt that the ease with which domain names can be
registered and privacy protection on the registration of domains allows the
owners and the operators of these websites to hide and camouflage
themselves behind the said registrations. The said operators are also not
being subject to any monetary damages or compensation due to the privacy
protect feature made available by DNRs. The same in effect gives them an
immunity to continue to engage in privacy of this nature.
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 9 of 30

<!-- page 17 -->

25.

Recently, vide judgement date 9th August, 2023 in Universal City

Studios LLC. & Ors. v. Dotmovies.baby & Ors., 2023:DHC:5842 this Court
has also taken stringent measures to protect Copyright owners from
infringement of their content by rogue websites by issuing a Dynamic+
Injunction. The relevant extract of the said decision in Universal City
Studios LLC. & Ors. (supra) is extracted below:
“11.
The Court had put a question to the ld.
Counsel for the Plaintiffs as to how the dynamic
generation of content can be protected in a suit where
even future works of the Plaintiffs’ can be covered.
Mr. Saikrishna, ld. Counsel has taken the Court
through the decision of this Court in UTV Software
Communication Ltd. and Ors v. 1337x.to and Ors,
(2019) 78 PTC 375 (Del) where this aspect is
considered by the Court as under:
“16. He pointed out that there were at least
122 other movies of the plaintiffs on
www4.fmovies.to. Learned Amicus Curiae
stated that the plaintiffs had not fully checked
their own movies on the said website, let alone
third-party content. He contended that the
least due diligence expected of the plaintiffs
was to provide evidence of at least all of their
own movies, if not of third parties (though
expected) that were illegally available on the
impugned websites.
17.
He submitted that the “three-step
verification test” evolved by the Bombay High
Court in Eros International Media v. BSNL,
Suit No. 751 of 2016, which consisted of
verification by an independent entity,
extensive documents being placed on record
and an affidavit on oath, was not satisfied in
the present case. He contended that the
evidence of the nature envisaged by courts
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 10 of 30

<!-- page 18 -->

was lacking in the present case. The relevant
portion of the orders in Eros International
Media (supra) relied upon by Mr. Hemant
Singh are reproduced hereinbelow:a) Order dated 22nd July, 2016
“2. I am making it clear that I will not
grant an injunction or order to block
URLs that point to websites unless it is
demonstrated that the entirety of the
website contains, and contains only,
illicit material. Without that being
attested to and established on Affidavit,
I will not consider an order that results
in the blocking of an entire website.
b) Order dated 26th July, 2016
“14. Thus, what I have before me now
is a three-step verification. First, a
verification and an assessment by
Aiplex (Plaintiff). This is accompanied
by their letter in writing. There is then
a second level of verification that is said
to have been done by the deponent of
the Affidavit along with the Plaintiffs'
Advocates; and finally all of this
material is placed on Affidavit and is
now on oath. I think this is sufficient
material on which to base an order.”
xxx
xxx
xxx
87. This Court is also of the opinion that it
has the power to order ISPs and the DoT as
well as MEITY to take measures to stop
current infringements as well as if justified
by the circumstances prevent future ones.
xxx
xxx
xxx
107. Keeping in view the aforesaid findings, a
decree of permanent injunction is passed
restraining the defendant-websites (as
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 11 of 30

<!-- page 19 -->

mentioned in the chart in paragraph no. 4(i)
of this judgment) their owners, partners,
proprietors, officers, servants, employees, and
all others in capacity of principal or agent
acting for and on their behalf, or anyone
claiming through, by or under it, from, in any
manner hosting, streaming, reproducing,
distributing, making available to the public
and/or communicating to the public, or
facilitating the same, on their websites,
through the internet in any manner
whatsoever,
any
cinematograph
work/content/programme/show in relation to
which plaintiffs have copyright. A decree is
also passed directing the ISPs to block access
to the said defendant-websites. DoT and
MEITY are directed to issue a notification
calling upon the various internet and telecom
service providers registered under it to block
access to the said defendant-websites. The
plaintiffs are permitted to implead the
mirror/redirect/alphanumeric websites under
Order I Rule 10 CPC in the event they
merely provide new means of accessing the
same primary infringing websites that have
been injuncted. The plaintiffs are also held
entitled to actual costs of litigation. The costs
shall amongst others include the lawyer's fees
as well as the amount spent on Court-fees.
The plaintiffs are given liberty to file on
record the exact cost incurred by them in
adjudication of the present suits. Registry is
directed to prepare decree sheets accordingly.
xxx

xxx

xxx

13.
Piracy and unauthorized reproduction of
copyrighted content is a serious issue the world over.
In view of the easy and affordable access to the
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 12 of 30

<!-- page 20 -->

internet across the globe, copyright owners are forced
to take action in different jurisdictions, that are
material to their revenue in order to seek injunctions
against rogue websites, which offer content in an
unauthorised manner. Courts across the world have
been providing various remedies in order to protect the
rights of copyright owners. For instance, in The
Football Association Premier League v. British
Telecommunications PLC and Ors., [2017] EWHC
480 (Ch), the High Court of Justice, Chancery
Division, U.K., vide judgement dated 13th March, 2017,
had passed orders directing ISPs to block access to the
websites distributing, transmitting and streaming
unauthorised content of the Barclays Premier League
matches. In the said decision, the Court considered
various issues such as proportionality and safeguards
including the avoidance of barriers to legitimate trade
before passing the orders of blocking.
14.
In addition to the decision in The Football
Association Premier League (supra), in several
decisions, various torrent websites such as ‘The Pirate
Bay’, ‘KAT’, ‘Fenopy’ and ‘H33T’ which were
rampantly indulging in copyrights infringement were
directed to be blocked though a series of judgements.
The said series of judgements include Dramatico
Entertainment Ltd v British Sky Broadcasting Ltd
[2012] EWHC 268 (Ch) and EMI Records Ltd v
British Sky Broadcasting Ltd [2013] EWHC 379
(Ch). Further, the High Court of Ireland has in
judgement dated 11th October, 2010 in EMI Records
[Ireland] Ltd & Ors v. UPC Communications Ireland
Ltd, [2010] IEHC 377 highlighted the nature of the
problem being faced by the creative industry as also
the economic issues that arise due to rogue websites.
The relevant extracts of the said judgement are set out
below:
“The Nature of the Problem
8. I am satisfied that the business of the
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 13 of 30

<!-- page 21 -->

recording companies is being devastated by
internet piracy. This not only undermines
their business but ruins the ability of a
generation of creative people in Ireland, and
elsewhere, to establish a viable living. It is
destructive of an important native industry.
While the evidence focussed on the recording
industry, the retail sector must also be
affected
by
this
wholesale
theft.
Furthermore, the evidence presented
convinces me that a substantial portion of
the generation now in their teenage years
and twenties are actively dissuaded by illegal
alternatives from legitimately purchasing
music.
xxx

xxx

xxx

xxx

xxx

Economic Issues
xxx

19. More widely, however, internet piracy is
an economic and a moral problem. Were
men to walk into a cinema and in the dark,
set up a small tripod for a machine to
digitally record the latest movie blockbuster,
to
use
the
appropriate
colloquial
terminology, most right thinking people
would be appalled. To entertain themselves
and their families at home, they would have
to wait three or four months to buy the DVD
on its release and spend about €15 to have
the film and whatever extras were added on
to make it attractive. It is hardly credible
that cinema owners would not be aware of
this problem taking place. If they did
nothing, and allowed people to proceed with
illegally capturing the film, the first step
would have been taken with their
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 14 of 30

<!-- page 22 -->

acquiescence in the undermining of
Copyright. Attendance at the film would
plummet, because a group of friends would
be drawn into deciding that a cheaper
alternative for say five or ten of them,
instead of having to spend between €50 and
€100 on cinema admission, would be to buy
a pirated copy of the film and watch it in the
comfort of their home on the now almost
ubiquitous flat screen television of large size
that graces our home life. If nothing were
done about the men, their camera and their
tripod, their digital reproduction equipment
and their sales, on the release of the DVD of
the film, legal purchases would be minimal.
Similarly, in the week of commencing writing
this, the National Youth Orchestra of Ireland
presented a stirring new composition,
‘Summer Overture’ by Shaun Davey, in the
National Concert Hall. . Nowadays it is
possible to attend a concert and to have CDs
of it legally for sale fifteen minutes after
conclusion. A person could covertly capture
the music on a small digital recorder. If that
individual went out to a van in which he had
a great deal of digital copying equipment,
reproduced it without permission and sold
the CDs to those leaving the concert, it
would rightly be regarded as flagrant abuse
of Copyright. I cannot see how an illegal
recording on site and the subsequent public
or internet offering for free, with no return
to the composer or performer for their
creativity, is anything other than a scandal.
I have no doubt that any responsible cinema
owner, or concert hall owner would stop
internet piracy, if made aware of it. I am
further satisfied that a reasonable person in
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 15 of 30

<!-- page 23 -->

that position would be vigilant to prevent it
in a cinema or in a concert venue. A failure
to address those problems, by those who can
address the abuse, is not excusable. It
constitutes the abuse of the economic
interests of the creative community. This
kind of theft is shameful. Many who see that
activity on the street would shun the
commerce of exploiting the rights of artists
for no return. Peer pressure would prevent
much of it. But the internet allows a
dispensation from shame, as internet thieves
figure that no one will know what is being
done behind the closed doors of internet
access. Essentially, that coupled with the
failure of internet service providers to act
like a responsible cinema or concert venue
owner would act, is why the problem is so
extreme
20. There is no difference between the
public situations I have described and the
piracy of music tracks over the internet. It
has the same consequence. The conduit for
that illegal activity is, however, not the street
or the pavement outside a cinema; it is the
internet service providers. It is clear that
they have an economic and moral obligation
to address the problem. I do not accept any
of the evidence from UPC, referred to later
in this judgment, as to why this has not been
done. Instead, the effect on the market place
of illegal downloads, through the internet, is
to increase the profit levels of internet
service providers. Relevant correspondence
from within UPC is profoundly disturbing as
to the reality of their approach.
21.
The evidence establishes that this
problem is a massive one. This is an
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 16 of 30

<!-- page 24 -->

instance where the multiplication on a huge
scale of small problems has changed the
nature of the issue into a huge pilfering of
the resources of creative artists. For each
individual person, the number of downloads
cannot be regarded as being on a
commercial scale. It is the multiplication of
the problem through millions of individuals
feeling free to use the internet to pirate the
Copyright of creative artists and recording
companies that has created the undermining
of that right on a foundational scale.”
15.
Even in India, regularly orders are being
passed by Courts, against websites which consist of
unauthorized and illegal content, in an effort to combat
the scourge of internet/network piracy. Recently, the
Bombay High Court in Applause Entertainment Pvt.
Ltd. v. Meta Platforms Inc., 2023 SCC OnLine Bom
1034, has directed the blocking of all social media
accounts which were being used for communicating
substantial parts of a web series hosted on an OTT
platform. In the said decision, while apprehending
that continuation of such unauthorised dissemination
using different names and identities, the Court issued
an ex-parte ad-interim dynamic injunction, restraining
even the adoption of different identities to perpetuate
such unauthorised dissemination. The only effective
measure at this stage, which domestic courts are
therefore granting is blocking of these websites and
extension of the injunction to mirror websites even if
they are with alphanumeric variations.
16.
The dynamism of the injunction, by itself, in
one country or another may not, however be sufficient
to protect copyright owners. There is an imminent
need to evolve a global consensus in this regard
inasmuch as despite ISPs blocking these websites, the
said websites can be accessed through VPN servers,
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 17 of 30

<!-- page 25 -->

and other methods to which the long arm of the law
cannot extend etc.
17.
Any injunction granted by a Court of
law ought to be effective in nature. The injunction
ought to also not merely extend to content which is past
content created prior to the filing of the suit but also to
content which may be generated on a day-to-day basis
by the Plaintiffs. In a usual case for copyright
infringement, the Court firstly identifies the work,
determines the Copyright of the Plaintiff in the said
work, and thereafter grants an injunction. However,
owing to the nature of the illegalities that rogue
websites induldge in, there is a need to pass
injunctions which are also dynamic qua the Plaintiffs
as well, as it is seen that upon any film or series being
released, they may be immediately uploaded on the
rogue websites, causing severe and instant monetary
loss. Copyright in future works comes into existence
immediately upon the work being created, and
Plaintiffs may not be able to approach the Court for
each and every film or series that is produced in the
future, to secure an injunction against piracy.”
26.

Having noticed the need for passing effective injunction orders and

observing globally well-settled jurisprudence that such websites primarily
consist of pirated content, which deserve to be injuncted, the Court had
passed a Dynamic+ injunction in the above-mentioned case in the following
terms:
“19.
As innovation in technology continues,
remedies to be granted also ought to be calibrated by
Courts. This is not to say that in every case, an
injunction qua future works can be granted. Such
grant of an injunction would depend on the fact
situation that arises and is placed before the Court.
20.
In the facts and circumstances as set out
above, an ex parte ad interim injunction is granted
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 18 of 30

<!-- page 26 -->

restraining the Defendants, who are all rogue websites,
from in any manner streaming, reproducing,
distributing, making available to the public and/or
communicating to the public any copyrighted content
of the Plaintiffs including future works of the Plaintiffs,
in which ownership of copyright is undisputed, through
their websites identified in the suit or any
mirror/redirect websites or alphanumeric variations
thereof including those websites which are associated
with the Defendants’ websites either based on the
name, branding, identity or even source of content. To
keep pace with the dynamic nature of the
infringement that is undertaken by hydra-headed
websites, this Court has deemed it appropriate to issue
this ‘Dynamic+ injunction’ to protect copyrighted
works as soon as they are created, to ensure that no
irreparable loss is caused to the authors and owners
of copyrighted works, as there is an imminent
possibility of works being uploaded on rogue websites
or their newer versions immediately upon the
films/shows/series etc. The Plaintiffs are permitted to
implead any mirror/redirect/alphanumberic variations
of the websites identified in the suit as Defendants Nos.
1 to 16 including those websites which are associated
with the Defendants Nos. 1 to 16, either based on the
name, branding, identity or even source of content, by
filing an application for impleadment under Order I
Rule 10 CPC in the event such websites merely provide
new means of accessing the same primary infringing
websites that have been injuncted. The Plaintiffs are at
liberty to also file an appropriate application seeking
protection qua their copyrighted works, including
future works, if the need so arises. Upon filing such
applications before the Registrar along with an
affidavit with sufficient supporting evidence seeking
extension of the injunction to such websites, to protect
the content of the Plaintiffs, including future works, the
injunction shall become operational against the said
CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 19 of 30

<!-- page 27 -->

websites and qua such works. If there is any work in
respect of which there is any dispute as to ownership of
copyright, an application may be moved by the affected
party before the Court, to seek clarification.
21.
Insofar as Defendant Nos.17 to 25 are
concerned, the said ISPs shall give effect to this
injunction by blocking the said websites. MeitY and
DoT shall issue blocking orders against the websites
within a period of one week from the release of the
order.
22.
The Domain Name Registrars (DNRs) of the
rogue websites’ domain names, upon being intimated
by the Plaintiffs shall lock and suspend the said
domain names. In addition, any details relating to the
registrants of the said domain names including KYC,
credit card, mobile number, etc. be also provided to the
Plaintiffs.”
27.

Mr. Saikrishna, ld. Counsel for the Plaintiffs, submits that post the

passing of the order of dynamic+ injunction in Universal City Studios LLC.
& Ors. (supra), several of such rogue websites are being blocked on an
international level and not just within the territory of India, which is
therefore having a positive impact to curb piracy on the internet. Ld.
Counsel further submits that the decisions of the Delhi High Court on
curbing of piracy are having vast implications as DNRs are locking and
suspending the domain names, rendering them inaccessible. As per ld.
Counsel, this is leading viewers to avail access to legitimate platforms as
was evident in the recent World Cup Cricket finals 2023 when one of the
OTT platforms had a logging in of more than 5.3 crores, thus multiplying
the viewership for such platforms and curbing viewing of pirated content.

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 20 of 30

<!-- page 28 -->

28.

In the present case, a situation has arisen where several documents

have been placed on record by the Plaintiffs clearly demonstrating a brazen
effort towards continued piracy on the internet. While the internet provides
unimpeded access, one of its challenges is the unrestricted access to such
rogue websites. However, as soon as these websites come to the attention of
any court of law or law enforcement authority, their free access deserves to
be blocked. The rogue websites are offering illegal viewing almost on a realtime basis to Plaintiffs’ content such as Stranger Things, Wonder Woman,
Aquaman, Batman, Spider Man: No Way Home, Top Gun: Maverick, The
Jungle Book, etc.
29.

In the present case, this Court is convinced that a dynamic+ injunction

as was granted in Universal City Studios LLC. & Ors. (supra) deserves to
be granted, failing which, the pirated content will continue to be viewed,
replicated and communicated to the public, causing immense loss to the
economic as also moral rights of the Plaintiffs. In the said process, various
illegalities which are being committed would also get encouraged if no
injunction is granted. Moreover, as is clear from a viewing one of the
infringing websites, coolmoviez.cloud, the clear position that emerges is that
serious illegalities are also sought to be committed by these websites and
unlawful activities are also being encouraged as is clear from the following
screenshots:

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 21 of 30

<!-- page 29 -->

30.

Under these circumstances, the Plaintiffs have established a prima

facie case for grant of an injunction. Balance of convenience is also in
favour of the Plaintiffs in view of unauthorised and illegal use of
Copyrighted contents by such rogue websites leading to significant
monetary losses to the Plaintiffs. Irreparable harm and injury is likely to be
caused if the injunction as sought is not granted. Accordingly, Defendant
Nos. 1 to 45 arrayed as Annexure A, which are all rogue websites shall stand
restrained from streaming, reproducing, distributing, making available to the
public and/or communicating to the public, in any manner, any copyrighted
content of the Plaintiffs including future works of the Plaintiffs.
31.

In the facts and circumstances as set out above, an ex parte ad interim

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 22 of 30

<!-- page 30 -->

injunction is granted restraining the Defendants, who are all rogue websites,
from in any manner streaming, reproducing, distributing, making available
to the public and/or communicating to the public any copyrighted content of
the Plaintiffs including future works of the Plaintiffs, in which ownership of
copyright is undisputed, through their websites identified in the present suit
or any mirror/redirect websites or alphanumeric websites, or any variations
thereof including those websites which are associated with the Defendants’
websites either based on the name, branding, identity of its operator, or
discovered to provide additional means of accessing the Defendant’s
website, and other domains/ domain along with their sub-domains and subdirectories, owners, website operators/ entities or even sources of content.
32.

Insofar as Defendant Nos. 46-54 are concerned, the said ISPs shall

give effect to this injunction by blocking the said websites. Defendant No.
55 and 56 - Department of Telecommunications (DOT) and Ministry of
Electronics and Information Technology (MeitY) respectively shall issue
blocking orders against the websites within a period of one week from the
release of the order.
33.

The Domain Name Registrars (DNRs) of the rogue websites’ domain

names, upon being intimated by the Plaintiffs shall lock and suspend the said
domain names. In addition, any details relating to the registrants of the said
domain names including KYC, credit card, mobile number, etc. be also
provided to the Plaintiffs.
34.

Compliance of Order XXXIX Rule 3 CPC be effected within one

week. Compliance and service is permitted through e-mail owing to the fact
that the exact contact details or addresses of these parties are not known.
35.

Reply to the application be filed within four weeks from the service of

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 23 of 30

<!-- page 31 -->

the present order along with the paper book.
36.

List before the Court on 21st March, 2024.

PRATHIBA M. SINGH
JUDGE
NOVEMBER 21, 2023
Rahul/bh/am

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 24 of 30

<!-- page 32 -->

ANNEXURE A
List of Defendants as per Memo of Parties
S. No.

Domain Name

Defendant No.1
1. fztvseries.mobi

URL

https://fztvseries.mobi

IP Address

104.21.68.98
172.67.193.226

Defendant No.2
2. Mobiletvshows.net

https://mobiletvshows.net

104.21.52.64
172.67.196.53

Defendant No.3
stagatv.com

https://www.stagatv.com

104.21.61.65
172.67.206.242

Defendant No.4
Vexmovies.uno

https://vexmovies.uno

104.21.90.188
172.67.159.200

Defendant No.5
3. coolmoviez.cloud

https://www.coolmoviez.cloud

104.21.51.140

4.

coolmoviez.com.de

https://www.coolmoviez.com.de

104.21.51.238

5.

coolmoviez.com.co

http://www.coolmoviez.com.co

104.21.32.98

https://aniwave.to

172.64.129.32

Defendant No.6
6. aniwave.to

7.

aniwave.bz

https://aniwave.bz

172.67.166.73

8.
9.

aniwave.ws
aniwave.tv

https://aniwave.ws
https://aniwave.tv

172.67.181.176
172.67.145.20

Defendant No.7

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 25 of 30

<!-- page 33 -->

10. animehana.in

https://www.animehana.in

142.251.167.121

Defendant No.8
animesenpai4u.com

https://www.animesenpai4u.com

142.251.167.121

Defendant No.9
gogoanime.is

https://gogoanime.is

104.21.21.203
172.67.200.81

Defendant No.10
11. 123animes.mobi

https://w7.123animes.mobi

104.21.72.172
172.67.187.37

Defendant No.11
12. anix.to

https://anix.to

104.21.73.108

Defendant No.12
13. freemovies2021.com

https://freemovies2021.com

104.21.17.73
172.67.223.59

Defendant No.13
14. freemovieswatch.tv

https://freemovieswatch.tv

104.21.0.234
172.67.128.98

15. freemovieswatch.net

https://freemovieswatch.net

104.21.59.229
172.67.184.212

Defendant No.14
16. medeberiyaa.com

https://medeberiyaa.com

104.21.12.120
172.67.132.36

17. medeberiyas.com

https://medeberiyaa.com

104.21.2.140
172.67.129.73

Defendant No.15
18. kinogo.biz

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

https://kinogo.biz

91.215.43.170

Page 26 of 30

<!-- page 34 -->

Defendant No.16
19. ridomovies.pw

https://ridomovies.pw

104.21.82.243
172.67.209.138

Defendant No.17
20. 1moviestv.com

https://1moviestv.com

104.21.1.218
172.67.128.23

Defendant No. 18
21. moviehax.me

https://moviehax.me

104.21.7.228
172.67.188.17

Defendant No. 19
22. ripcrabbyanime.in

https://ripcrabbyanime.in

104.21.28.121
172.67.146.30

Defendant No. 20
23. moviehunt.us

https://moviehunt.us

104.21.67.48
172.67.213.207

Defendant No. 21
24. mlwbd.rent

https://mlwbd.rent

104.21.21.92

25. mlwbd.digital

https://mlwbd.digital

104.21.92.125

26. mlwbd.love

https://mlwbd.love

104.21.91.26

27. mlwbd.me

https://mlwbd.me

28. mlwbdofficial.com

https://mlwbdofficial.com

104.21.16.122
172.67.212.122
104.21.14.160

29. mlwbd.photos

https://mlwbd.photos

104.21.3.5

https://www.mov.onl

104.21.47.254

Defendant No. 22
30. mov.onl

172.67.175.35
Defendant No. 23
31. nyafilmer.gg

https://nyafilmer.gg

104.21.46.105
172.67.137.197

Defendant No. 24
32. o2tvseries2.com

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

https://o2tvseries2.com

104.21.56.93
172.67.183.186
Page 27 of 30

<!-- page 35 -->

Defendant No. 25
33. projectfreetv.one

Defendant No. 26
34. raretoons.me
35. raretoonsindia.in.net

https://projectfreetv.one

104.21.34.90
172.67.157.157

https://raretoons.me

104.21.44.129

https:// raretoonsindia.in.net

104.21.18.110
172.67.181.156

Defendant No. 27
36. uflix.cc

https://uflix.cc

104.21.54.193
172.67.141.88

Defendant No. 28
37. watchmoviesb.top

https://waatchmoviess.top

104.21.96.131

38. waatchmovies.top

https://waatchmovies.top

104.21.37.124
172.67.208.28

39. watchmoviiess.top

http://watchmoviiess.top

104.21.74.145
172.67.159.95

Defendant No. 29
40. yifymovies.xyz

https://yifymovies.xyz

104.21.86.195
172.67.136.88

Defendant No. 30
41. kickassanime.am

https://kickassanime.am

104.21.34.85
172.67.202.1
104.21.20.172
172.67.193.61

42. kaas.am
Defendant No. 31
43. Kickass.onl

http://kaas.am

https://kickass.onl

104.31.16.123
104.31.16.6

44. Kickass.help

https://ww1.kickass.help

104.21.10.178
172.67.146.41

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 28 of 30

<!-- page 36 -->

Defendant No. 32
45. hindimoviesonline.to

https://hindimoviesonline.to

104.21.75.41
172.67.212.36

Defendant No. 33
46. hindimovies.to

https://www.hindimovies.to

104.21.73.241
172.67.193.117

Defendant No. 34
47. freedrivemovie.lol

https://freedrivemovie.lol

104.21.83.191
172.67.180.221

Defendant No. 35
48. freeseries.watch

https://freeseries.watch

104.21.15.122
172.67.162.153

Defendant No. 36
49. hdmp4mania2.com

https://hdmp4mania2.com

66.154.14.82

50. hdmp4mania1.net

https://hdmp4mania1.net

163.172.110.116

https://genvideos.org

104.31.16.8

Defendant No. 37
51. genvideos.org

104.31.16.121
Defendant No. 38
52. hdflixtor.com

https://hdflixtor.com

104.21.34.104
172.67.159.25

Defendant No. 39
53. 24-hd.com

https://www.24-hd.com

104.26.10.67
104.26.11.67
172.67.75.193

Defendant No. 40
54. 123serieshd.ru

https://123serieshd.ru

104.21.9.120
172.67.189.63

Defendant No. 41
55. anihdplay.com

https://anihdplay.com

104.26.10.123
104.26.11.123
172.67.70.109

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 29 of 30

<!-- page 37 -->

Defendant No. 42
56. Nocensor.cloud

https://nocensor.cloud

57. Nocensor.click

http://nocensor.click

104.21.89.184
172.67.164.68
104.21.80.190
172.67.153.74

Defendant No. 43
58. Showbox-movies.net

https://www2.showboxmovies.net

104.21.18.230
172.67.183.223

Defendant No. 44
59. Moviestowatch.tv

https://moviestowatch.tv

60. Moviestowatch.cc

https://moviestowatch.cc

104.21.28.91
172.67.145.52
104.21.80.168
172.67.151.200

Defendant No. 45
61. Torrentbay.net

https://torrentbay.net

104.21.68.88
172.67.192.127

**********************************************

CS(COMM) 833/2023
Signature Not Verified
Digitally Signed
By:DHIRENDER KUMAR
Signing Date:22.11.2023
17:30:41

Page 30 of 30

<!-- page 38 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
