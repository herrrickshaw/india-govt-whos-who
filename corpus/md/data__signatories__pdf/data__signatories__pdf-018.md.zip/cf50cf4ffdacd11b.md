---
doc_id: "cf50cf4ffdacd11b"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/35037c6c32d33ae12ead8b470a2656c3.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of PMRTS License as on 30.09.2023"
date: "2023-09-30"
pages: 8
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c3613b26eefa20ed"
---

<!-- page 1 -->

Table-1: List of Public Mobile Radio Trunking Service (PMRTS) Licensees
As on 30.09.2023
: Service Area License Number & date of Effective Date of
(Metro/ Circle- Name of Licensee ae eo! eet हा + Date of Expiry
wise) signing Authorization
M/s Arya Omnitalk 311-105/2006-CS dated 13-03-2008 13-03-2028 | Stand-alone
Maharashtra Radio Trunking Services | 13.03.2008 PMRTS License
1. Ltd.
M/s Reliance Jio 20-401/2013-AS-I 20-10-2033 | Under UL
All 22 Service Areas | Infocomm Ltd. Dated:21.10.2013 21-10-2013
2.
M/s Bharat Sanchar /' 28-02-2040 | Under UL
. Nigam Ltd. 20-1206/2020-AS-I Dated: 09.
All 22 Service Areas 10.12.2020 29-02-2020
Bi x
M/s Arya Omnitalk 311-205/2013-CS dated 01-11-2015 13-03-2034 | Under UL
Andhra Pradesh Radio Trunking Services | 13.03.2014
Ltd.
M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
Andhra Pradesh Pvt Ltd 14.08.2014
5.
Andhra Pradesh M/s Quickcalls Private | 311-226/2015-CS dated 04-04-2016 04-04-2036 | Under UL
nahra Prades Limited 08.06.2016
M/s WiWaNet 311-236/2016-CS-I dated 22-12-2016 22-12-2036 | Under UL
Andhra Pradesh Solutions Private 22.12.2016
7. Limited
Bih M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
war PrivateLimited 14.08.2014
M/s Arya Omnitalk 311-205/2013-CS dated 11-03-2016 13-03-2034 | Under UL
Delhi Radio Trunking Services | 13.03.2014
Ltd.
$e Page 10f8

<!-- page 2 -->

Table-1: List of Public Mobile Radio Trunking Service (PMRTS) Licensees
As on 30.09,2023
Service Area है है
(Metro/ Circle- Name of Licensee winded Number 8 date.of Effective Date of Date of Expiry
wise) signing Authorization
. M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
10% मा फिर | NO | a [ns
है
11. Limited 17.05.2016 :
M/s Arya Omnitalk 311-205/2013-CS dated 10-05-2016 13-03-2034 | Under UL
Gujarat Radio Trunking Services | 13.03.2014
12. Ltd.
व M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
Fas Sumo [iret [inonaee | ore [RE Jes
; M/s Airtalk Solutions & | 311-211/2014-CS dated 19-09-2014 19-09-2034 | Under UL
| sume: [Screens [onan | ee | ee [eh '
M/s WiWaNet 311-236/2016-CS-I dated 22-12-2016 22-12-2036 | Under UL
Gujarat Solutions Private 22.12.2016
15. Limited
M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
| न गा [tone | eee | RS [nt
M/s Arya Omnitalk 311-205/2013-CS dated 10-05-2016 13-03-2034 | Under UL
Karnataka Radio Trunking Services | 13.03.2014
17. Ltd.
M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
| 2 न [Meum का | ones | More fet
मु
19. Limited 08.06.2016
M/s Arya Omnitalk 311-205/2013-CS dated 13-03-2014 13-03-2034 | Under UL
Kerala Radio Trunking Services | 13.03.2014
20. Ltd.
ee Page 2 of 8

<!-- page 3 -->

Table-1: List of Public Mobile Radio Trunking Service (PIMRTS) Licensees
As on 30.09.2023
Service Area
(Metro/ Circle- Name of Licensee Heanse Number'& date of Effective Date a Date of Expiry
wise) signing Authorization
M/s WiWaNet 311-236/2016-CS-dated 22-12-2016 22-12-2036 | Under UL
Kerala Solutions Private 22.12.2016
21. Limited
M/s Arya Omnitalk 311-205/2013-CS dated 11-03-2016 13-03-2034 | Under UL
Kolkata Radio Trunking Services | 13.03.2014
22. Ltd.
M/s Arya Omnitalk 311-205/2013-CS dated 05-12-2015 13-03-2034 | Under UL
Madhya Pradesh Radio Trunking Services | 13.03.2014
23. Ltd.
M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
| कार [Miotcum [woe | ee | ee [ES छः
M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
| 2 मान [Mets [ora |e | ees [te
2
26. Services Private Limited | 19.09.2014
2
27. Limited 15.06.2016
M/s WiWaNet 311-236/2016-CS-I dated 22-12-2016 22-12-2036 | Under UL
Maharashtra Solutions Private 22.12.2016
28. Limited
M/s Arya Omnitalk 311-205/2013-CS dated 11-03-2016 13-03-2034 | Under UL
Radio Trunking Services } 13.03.2014
29. Ltd.
३
30. Services Private Limited | 19.3.2014
Page 3 of 8

<!-- page 4 -->

Table-1: List of Public Mobile Radio Trunking Service (PMRTS) Licensees
As on 30.09.2023
Service Area + 2
(Metro/ Circle- Name of Licensee Hicense Number €:datelot Effective! Date oF Date of Expiry | Note
wise) signing Authorization
M/s Bhilwara Telenet 311-224/2015-CS dated 14-03-2016 14-03-2036 | Under UL
31. Services Private Limited | 27.06.2016
32. Limited 15.06.2016
. M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
ssf preted [sora | NO | Bas [te
M/s Arya Omnitalk 311-205/2013-CS dated 13-03-2014 13-03-2034 | Under UL
Rajasthan Radio Trunking Services | 13.03.2014
34. Ltd.
. M/s Inative Networks 311-208/2013-CS dated 14-08-2014. 14-08-2034 | Under UL
| के [tmston निकाल none 1 | MRE [neh
— Te
36. Limited 17.05.2016
M/s Arya Omnitalk 311-205/2013-CS dated 11-03-2016 13-03-2034 | Under UL
Tamil Nadu Radio Trunking Services | 13.03.2014
37. Ltd.
. M/s Inative Networks 311-208/2013-CS dated 14-08-2014 14-08-2034 | Under UL
| आन preemies [aon |e | MRE [Te
2
39. Limited 08.06.2016
M/s WiWaNet 311-236/2016-CS-| dated 22-12-2016 22-12-2036 | Under UL
Tamil Nadu Solutions Private 22.12.2016
Limited
a
41. Private Limited 14.08.2014
Ge Page 4 of 8

<!-- page 5 -->

Table-1: List of Public Mobile Radio Trunking Service (PMRTS) Licensees
As on 30.09.2023
Service Area ; i
७ न किन वि पिया कि aee
. signing Authorization
wise)
M/s Polaron Under UL-VNO
Technologies Private 311- 239/2016-CS-| dated
42. Limited, 13.04.2018 13.04.2018 13.04.2028
a
43. Payment India Pvt. Ltd. | Dated:07.12.2016
Page 5 of 8

<!-- page 6 -->

Table-2: Company wise Licenses: Public Mobile Radio Trunking Service (PMRTS)
As on 30.09.2023
fer eee |
UL-VNO | Alone Licenses
1. | M/s Arya Omnitalk Radio Trunking Services Delhi, Mumbai, Kolkata, Gujarat, 1
Limited Karnataka, Tamil Nadu ,Pune, 10 14
Andhra Pradesh, Madhya Pradesh,
Kerala & Rajasthan
a |
CT 771 झट/'
Pd
Pradesh, Madhya Pradesh,Tamil
Nadu, Karnataka, Haryana, Delhi, 12 12
West Bengal, Odisha &
Maharashtra
M/s Quickcalls Private Limited Andhra Pradesh,
a
7. | M/s WiWa NetSolutions Private Limited Kerala, Andhra Pradesh, Tamil
| |
Ce geen eran] iomcamemennien TI
Limited
a [is efanceoTnfocommita—[AlaaservceAreas | [|
Cd
Dat
a || सो
tat ef शा टच
Page 6 of 8

<!-- page 7 -->

Table-3: Contact Details of Public Mobile Radio Trunking Service (PMRTS) Licences
As on 30.09.2023
ce
1 M/s ADPAY Mobile Payment India Pvt. | Susisummi IT Park, 1st Floor, 290, ‘4th Main Road, Burma Colony, Perungudi, Chennai -
ee का न कक पा
2 M/s Airtalk Solutions & Services C-509,Groma House, Plot No.14C, Sector — 19, Vashi, Navi Mumbai —400703
_—
3 M/s Arya Omnitalk Radio Trunking 34 Floor, Lingfield Plaza, S. No. 66/67, Wanowrie, Salunke Vihar Road, Pune-41.
|
5 M/s Bhilwara Telenet Services Private Essel House, B-10, Lawrence Road, Industrial Area New Delhi-110035.
2 SS Tana
Mumbai-400614
M/s Inative Networks Private Limited | 18, Navjiwan Vihar, New Delhi-17. Other Correspondence Address:-Level 3, Charmwood
| |
7 M/s Polaron Technologies Private Aaditya Bunglow- 16A, Regency Estate Kalyan Sheel Road, Near Jondhale collage,
a tiie |
M/s Procall Private Limited Ist Floor, Block-Il, Old Ishwar Nagar,Coca Cola Godown, Okhla Industrial Estate, New
Delhi-110020.
|
Other address:- 604, 6th Floor, Gauri Complex, Plot No 19, Sector-11 CBD Belapur, Navi
Mumbai-400614
CE Page 7 of 8

<!-- page 8 -->

Table-3: Contact Details of Public Mobile Radio Trunking Service (PMRTS) Licences
As on 30.09.2023
ce
11. | M/s Smart Talk Private Limited Essel House, B-10, Lawrence Road, Industrial Area New Delhi-110035.
Other address:- 604, 6th Floor, Gauri Complex, Plot No 19, Sector-11 CBD Belapur, Navi
Mumbai-400614
15 | M/s WiWa NetSolutions Private 1003, Sobha Daffodil, HSR Layout, 2" Sector, Somasundarapalya, Bangalore-560102
Limited :
AE
SCE OR eH ee CRS CR ACR CACC COR fA kf के मर कर AR SEA A AR AC CAC of oka oo a oR oo RO A Fee EE कक
Corey OS Hi TADAW)
SING!
secre ETTORE TD,,
Ast पा दिया General ~
Deptt ot Fegan om "
Page 8 of 8
