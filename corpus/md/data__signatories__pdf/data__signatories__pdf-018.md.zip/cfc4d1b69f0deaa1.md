---
doc_id: "cfc4d1b69f0deaa1"
source_url: "https://powermin.gov.in/static/uploads/2025/07/6017a109fb81fceab394d721aab15a12.pdf"
ministry: "Power"
title: "Forum of Regulators Rules, 2005"
date: "2005-02-16"
pages: 4
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "ad5121405e75770f"
---

<!-- page 1 -->

रजिस्ट्री सं" डी० एल"-33004/99 4४99५ REGD. NO. D,L.-3300499
॥१
कमर]
Che Gazette of Gudi |
असाधारण
है EXTRAORDINARY
भागगर--खण्ड 3--उप-खण्ड 6)
PART E—Section 3—Sub-section (i)
प्राध्िकार से प्रकाशित .
PUBLISHED BY AUTHORITY
=o) ऋऊ छल्ले बुधवार फवते 1 छान ज़ फ़य ८ 62] नई दिल्‍ली, बुधवार, फरवरी 16, 2005/माघ 27, 1926
No. 62] NEW DELHI, WEDNESDAY, FEBRUARY 16, 200S/MAGHA 27, 1926 :
a रा
विद्युत मंत्रालय
अधिसूचना
'चई दिल्‍ली, 16 फरवरी, 2005
* सातकानि. 75( अ)-- केंद्रीय सरकार, विद्युत अधिनियम, 2003 (2003 का 36) की धारा 166 की
उपधारा(2) और उपधारा(3) के साथ पठित धारा 176 की उपधारा(] द्वारा प्रदत्त शक्तियों का प्रयोग
करते हुए, निम्नलिखित नियेम बनाती है, अर्थात्‌ -
1... संक्षिप्त नाम और प्रारंभ () इन नियमों का संक्षिप्त नाम विनियामक मंच नियम, 2005 ०
a
(2) ये राजपत्र में इनके प्रकाशन की तारीख को प्रवृत्त होंगे ।
2... परिभाषाएं- इन नियमों में जब तक कि संदर्भ से अन्यथा अपेक्षित न हो;
()' मंच" से नियम 3 के अधीन गठित' विनियामक मंच" अभिप्रेत है,
‘ (1) अधिनियम से विद्युत अधिनियम, 2003 (2003 का 36) अभिप्रेत है,
(iii) उन शब्दों और पदों के जो इसमें प्रयुक्त हैं और परिभाषित नहीं हैं किंतु
अधिनियम में परिभाषित है, वहीं अर्थ होंगे जो अधिनियम में उनके हैं ।
3. मंच का गठन (1) मंच में केंद्रीय आयोग का अध्यक्ष और राज्य आयोगों के अध्यक्ष होंगे ।"
* केंद्रीय आयोग का अध्यक्ष विनियामक मंच का अध्यक्ष होगा !
(2) केंद्रीय आयोग का सचिव मंच का पदेन सचिव होगा |
(3) मंच को अनुसचिवीय सहायता केंद्रीय आयोग द्वारा प्रदान की जाएगी |
| मुख्यालय नई दिल्ली में अवस्थित होगा |
522 0/2005 (1) .

<!-- page 2 -->

|
1
2. THE GAZETTEOFINDIA:EXTRAORDINARY __ Parr I-—Sec:3()] |
4. मंच के कृत्य- मंच निम्नलिखित कृत्यों का निर्वहन करेगा अर्थात्‌- ' |
' () केंद्रीय आयोग और राज्य आयोगों के टैरिफ आदेशों और अन्य आदेशों का
विश्लेषण और उक्त आदेशों से उदभूत होने वाले डाटा का संलग्न करना, विशेषकर i
उपयोगिताओं की दक्षता में सुधारों को प्रकाश में लाना; ५ |
(1) विद्युत सेक्टर में विनियमन को सामंजस्ययुक्त बनाना;
(09) अधिनियम के अधीन यथा अपेक्षित अनुज्ञप्तिधारियों के कार्यों के मानकों को
अभिकथित करना;
(५४) सामान्य हित के विभिन्‍न मुद्दों पर मंच के सदस्यों के बीच सूचना और समान |
. afar 4 feet |
(५) विद्युत सेक्टर के विनियमन से सुसंगत मुद्दों पर आंतरिक या बाह्य स्रोतों के माध्यम से !
अनुसंधान कार्य करना; ,
(vi) उपभोक्ताओं के हित के संरक्षण के उपाय ढूँढना और विद्युत सेक्टर की दक्षता, :
मितव्ययता और प्रतियोगिता का संवर्धन; |
(भा) ऐसे अन्य कृत्य को केंद्रीय सरकार द्वारा उन्हें समय-समय पर समानुदेशित कियो
जाए; :
5. wad fe (1) केंद्रीय आयोग मंच के क्रियाकलापों को किए जाने के लिए राज्य आयोगों
से आवश्यक वित्तीय योगदान ले सकेगा |
(2) केंद्रीय आयोग मंच के क्रियाकलापों के लिए पृथक लेखा रखेगा ।
6. मंच की बैठकें- .
(1) मंच वर्ष में कम से कम दो बार बैठकें करेगा | है ‘
(2) मंच बैठक के संचालन के लिए अपने स्वयं के कारोबार नियम विरचित करेगा |
7... वार्षिक रिपोर्ट- विनियामक मंच प्रत्येक वर्ष, ,पूर्व वित्तीय वर्ष के दौरान अपने क्रियाकलापों
का सारांश देते हुए एक वार्षिक रिपोर्ट तैयार करेगा और रिपोर्ट की प्रतियां केंद्रीय आयोग को
अग्रेषित की जायेंगी ।
[फा, सं, 23/35/2003-आर एण्ड आर]
+ . अंजय शंकर, अपर सचिव

<!-- page 3 -->

Cammsere3@) TS TAS (amore 3) Se न्‍न्‍निसताससलत्नत्न्न् भारत का शजपत्र : असाधारण : 3
MINISTRY OF POWER है
हि NOTIFICATION
New Deihi, the 16th February,-2005
GS.R. 75(E).— In exercise of the powers conferred by sub-section (1) of section .
176 read with sub-sections (2) and (3) of section 166 of the Electricity Act, 2003 (No.36
of 2003), the Central Government hereby makes the following rules, namely:-
1. Short title and commencement. — (1) These rules may be called the Forum of
Regulators Rules, 2005.
(2) They shall come into force on the date of their publication in the Official
Gazette. :
है 2. Definitions. - In these rules, unless the context otherwise requires,-
(1) “Forum” means ‘Forum of regulators’ as constituted under rule 3;
(2) “Act” means the ‘Electricity Act, 2003 (No.36 of 2003).
(3) Words and expressions used herein and not defined, but defined in the Act,
shall have the meanings respectively assigned to them in the said Act.
3. Constitution of the Forum.- (1) The Forum shall consist of the Chairperson of
the Central Commission and Chairpersons of the Siaie Couunissions. The
Chairperson of the Central Commission shall be the Chairperson of the Forum of
Regulators, हे
(2) The Secretary to the Central Commission shall be the ex-officio Secretary
to the Forum.
(3) Secretarial assistance to the Forum shall be provided by the Central
Commission.
(4) The headquarter of the Forum will be located at New Delhi.
4. Functions of the Forum.- The Forum shall discharge the following functions,
namely:- -
ay analysis of the tariff orders and other orders of Central Commission and State
Commissions and compilation of data arising out of the said orders,
highlighting, especially the efficiency improvements of the utilities;
(ii) harmonization of regulation in power sector;
(ii) _ laying of standards of performance of licensees as required under the Act.
(iv) sharing of information among the members of the Forum on various issues of
common interest and also of common approach.
(v) undertaking research work in-house or through outsourcing on issues relevant
. to power sector regulation;
(vi) evolving measures for protection of interest of consumers and promotion of
efficiency, economy and competition in power sector; and
, (vii) such other functions as the Central Goverment may assign to it, from time to
time.

<!-- page 4 -->

A
!
|
4 THEGAZETIBOFINDIA:EXTRAORDINARY Pan IS. 300]
5. Finances of the Forum.- (1) The Central Commission may take necessary financial
contributions from the State Commissions for carrying out the activities of the Forum.
(2) The Central Commission will keep separate accounts for the activities of the
Forum. :
6. Meetings of the Forum.- (1) The Forum shall meet at least twice in a year.
(2) The Forum will frame its own rules of business for the conduct of its meetings.
7 Annual Report .- The Forum of Regulators shall prepare every year, an annual /
report, giving a summary of its activities during the previous financial year and copies
of the report shall be forwarded to the Central Government. |
{F. No. 23/35/2003-R&R] i
: AJAY SHANKAR, Addl. Secy. |
: Hl
L
|
* |
> |!
|
oO er, Govt, of India Press, Ring Road, Mayapari, New Delhi-110064 :
Fmd by ee apatliched by whe Conelier of Publications, Dethi-1 10054.
: |
i
