---
doc_id: "d0c93cf0ebad3e1e"
source_url: "https://mohua.gov.in/static/uploads/2025/11/5c3309e40add81fc986ec4c0e36bb3eb.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of Rs. 7.80 lakh to State Govt. of Mizoram as part amount of 1st installment of Central Assistance for 16 BLC (New Construction) projects under PMAY-U Mission - reg."
date: "2021-03-27"
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "bc0166e78cb8109d"
---

<!-- page 1 -->

https://pfms.nic.in/Sanction/TemplateA dvice.aspx?AdviceNum=vk...
62>
PAO(Sectt.) /HUA/Admin/Advice/2020-21/.2532.- 0S
GOVERNMENT OF INDIA
PAO(Sectt.), Ministry of Housing and Urban Affairs
507-C Wing, Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664
To,
The General Manager,
Reserve Bank of India, 707
Central Accounts Section, 191 111 |
Additional Office Building, 27/03/2021
East High Court Road,
NAGPUR - 440 001
Sir,
Please debit our account with Rs.7,80,000/- (Seven Lakh Eighty Thousand Only.) by contra
credit to the following accounts of the Governments with the amounts mentioned against each:
Month and Year of Accounts: March,2021 The Amount to be Settled: March,2021
Name of State Scheme Code Sanction No. and Date
the State Code
1 MIZORAM 121 1989-STATE AND UT 7,80,000 | I-14011/1/2018-HFA-V-UD
GRANTS UNDER PMAY (Comp. No. 9039634) dated
(URBAN) 27/03/2021
Signature of the authorized official
oy
नह
(Pawan Kumar Bhatnagar) _
Sr. Accounts Officer, Nor
af /o the Accountant General (A&E), Mizoram, Izawl-796001 aN
2. Sh. B.K Mandal, US (HFA-V) , M/o Housing and Urban Affairs, New Delhi-110011.
Pawan Kumar Bhatnagar
Sr. Accounts Officer
() है0 "ही
NA 9
} 127 ¢
B Mor Ub BPG
alu] y
°
(4 mis Hh A
oe
. WN
ts
of 27-03-2021 19:15

<!-- page 2 -->

oO? ere ऊप“ऊतात“तस्‍“स्‍त“च,ी:,ट,सञड:कलकल्‍कलूल्‍्चचड:ॉलओन  सअअअ छ आऋखेचेचे से चेतन. टननननननक»५» ५ »»55भभमआआ3+35+ कमाल छा भतभऊआआ मम मम मत
No. I-14011/1/2018-HFA-V-UD (Comp.:.No. 9039634)
Government of India
Ministry of Housing & Urban Affairs
HFA-V Division
eee
Room No. 03, Technical Cell, Gate No. 7,
Nirman Bhawan, New Delhi
Dated:23-.03.2021
To
Pay and Accounts Officer (Sectt.),
Ministry of Housing and Urban Affairs,
Nirman Bhawan,
New Delhi -11

Sub: Release of Rs. 7.80 lakh to State Govt. of Mizoram as part amount of
1* installment of Central Assistance for 16 BLC (New Construction) projects
under PMAY-U Mission — reg.

Sir,

I am directed to convey the Sanction of the Competent Authority to the release of Rs.
7,80,000/- (Rupees Seven Lakh and Eighty Thousand only) to State Govt. of
Mizoram as part amount of 1* installment of Central Assistance (other than SC/ST
Component) for 16 BLC (New Construction) projects for Creation of Capital Assets
under Pradhan Mantri Awas Yojana — Urban (PMAY-U) for FY 2020-21.

2. The statement showing details of the projects against which the above Central Assistance

is released towards part amount of 1* installment of Central Assistance is at Annexure.

3. Based on decision and recommendations of CSMC under PMAY-U Mission in its 32"4

meeting held on 26.03.2018, the amount of Central Assistance is being released subject to the

following conditions:
i. The funds shall be utilized for the Purpose and within the selected categorized
beneficiaries, for which these are given. Otherwise these will have to be tefunded along

with interest as per provisions under GFR 2017.

ii, The expenditure on the implementation of the scheme/projects will be shared between
the Central and the State/ULB/Implementing Agency (IA) as committed. The committed

State share should also be released within 15 days from the date of receipt of Central

Assistance in the SLNA account. In case of shortfall of State/ULB/IA share,

corresponding amount of Central Assistance will be deducted from the subsequent

instalment (s).

iii. _ The funds including Central Assistance and State share will thereafter be released by the
State Government to the implementing agencies without any delay failing which the
amount would be recovered from the State Government with interest, as applicable, for
the period of default.

iv. Necessary sanctions/approvals/compliances required under the statutory or other :
regulatory regime as applicable would be obtained by the authority (ies) concerned with
the project(s).

oak Contd..P.2/

<!-- page 3 -->

e
-2-

v. The State Government and implementing agency shall put in place a monitoring system
to ensure that the project(s) achieve scheduled milestone and envisaged outcomes
including implementation of reforms and other conditionalities required under the
scheme.

vi. The State Government shall utilize the grant in accordance with the approved guidelines
for the implementation of PMAY-U Mission.

vii. | The State Government shall furnish the Utilization certificates of the Grant released in
the prescribed format as per GFR 2017 as provided in the scheme guidelines.

viii. | Where there is an element of cash transfer to individual beneficiaries, the same may be
made through PFMS/DBT mode as applicable. The State Government shall submit an
authenticated certificate from the bank showing complete details of disbursement of
funds to each beneficiary before release of 2"4installment.

ix. The State Government shall ensure the geo-tagging of all houses approved under BLC
component of PMAY-U Mission and subsequent release by the State Government to
beneficiaries should be made in 3-4 installments depending on the progress/stage of
construction of house.

x. The State Government shall be required to certify that the specifications of the houses
conform to NBC/IS Standards and that requisite infrastructure will be provided by the
State Government/ULB. State Govt. shall also ensure that there should be no
duplication/change in the identified beneficiaries.

xi. The State Government shall submit the Action Taken Report (ATR) on the
observations/recommendations of Third Party Quality Monitoring Agency (TPQMA) for
quality monitoring purpose before release of subsequent instalment.

xii. The State should ensure that Model Code of Conduct is not violated while releasing funds
to Implementing Agencies/ULBs/Beneficiaries.

4. _ The amount is debitable from the account of the Central Government in the books under
the following Head of Accounts under Demand No. 57 of the Ministry of Housing and Urban
Affairs for the year 2020-21:
Major Head: | _ ३36० | rants-in-aid to State Governments
ub-Major Head |_ ०6 | ntrally Sponsored Schemes
| 720 [bentral Assistance/Share
[91 Pradhan Mant Awas Yojana (Urban)

etaill Assistance to State Governments for
Botaod Head mar
Object Head rants for Creation of Capital Assets
5. The amount will be credited to the State Government's Account at Reserve Bank of India,
CAS, Nagpur as per procedure laid down by Ministry of Finance, Department of Expenditure in
this regard.
6. This being the first instalment Central Assistance, no UC is required/due for above release.
7 As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee
Institution(s)/Organisation(s) shall be open to inspection by the sanctioning authority and
audit, both by the Comptroller and Auditor General of India under the provision of CAG (DPC)
Act 1971 and internal audit by the Principal Accounts Office of the Ministry or Department,
whenever the Institution or Organisation is called upon to do so.

be Contd..P.3/
deb?

<!-- page 4 -->

-3-
8. This issues with the concurrence of the Finance Division vide their Note No. 14 (E:
9106148) of even number dated 22.03.2021.
9. . This sanction has been registered at S. No.622in the Sanction Register of HFA Mission
Directorate of the Ministry of HUA for the year 2020-21.
Yours faithfully,
Under Secretary to the Government of India
Tel No.: 011-23063285
Copy to:
1. Secretary, Urban Development & Poverty Alleviation, State Government of Mizoram
2. Accountant General (A&E), Mizoram
3. Dir. (FD), MoHUA
4. Dir. (HFA-3), MoHUA
5. DS (Budget), MoHUA
6. NITI Aayog, SP Divn./DR Divn., New Delhi
7. O/o CGA, Mahalekha Niyantrak Bhavan, New Delhi
8. Dy. Chief (MIS/DRMC), HFA Directorate to place this sanction at appropriate place on
the Website of the Ministry.
9. PMU (MIS), HFA Directorate
10. Sanction folder get
(B. andal)
Under Secretary to the Government of India

<!-- page 5 -->

00000 |
eo
al |
|... ह
1... ft
|... 1
ee LLL EL aE
© BA |
ETE |
111 कक |
|
