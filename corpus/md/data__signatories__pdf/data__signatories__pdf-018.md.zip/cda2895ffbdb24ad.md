---
doc_id: "cda2895ffbdb24ad"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/3c55d1b2efe8897033137d4c85769c16.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "FOREIGN DIRECT INVESTMENT (FDI) POLICY"
date: "2025-07-20"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b501e6a905c774f"
---

<!-- page 1 -->

CHAPTER - 1
FOREIGN DIRECT INVESTMENT (FDI) IN INDIA

1.

FOREIGN DIRECT INVESTMENT (FDI) POLICY:

The FDI Policy in India is characterized by its liberal, transparent and investorfriendly nature. As per the extant Policy, FDI up to 100% is allowed on the automatic
approval route in most sectors / activities. The extent Policy on FDI is available in the
form of a consolidated FDI Policy circular in the public domain and can be accessed at
the website of the Department of Industrial Policy & Promotion (http://dipp.nic.in).
