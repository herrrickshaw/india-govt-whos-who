---
doc_id: "ceddaca650d9e6b5"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/7337c8f129133cea9fc9ce8463d8c5cb.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allocation of Telemarkting code 1600 exclusively for service and transactional voice calls to Ms Bharat Sanchar Nigam Ltd for Haryana LSA"
date: "2025-03-11"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "94d3eec8ac139c11"
---

<!-- page 1 -->

16-04/2024-AS-IIl/Part-I 173258151/2025
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
(Access Services Wing)
No. 16-04/2024-AS-III/Part-I/ 4-] Dated: 11.03.2025
To,
M/sBharat Sanchar Nigam Limited
Subject: Allocation of telecommunication identifiers in numbering series
"1600" exclusively for service and transactional voice calls to M/s Bharat
Sanchar Nigam Limited for Haryana LSA.

This is in reference to DoT instructions dated 23.12.2024 regarding
allocation of separate numbering series (1600) for service & transactional voice
calls and your applications received through Saral Sanchar Portal for allotment of पर
telecommunication identifiers in numbering series '1600' for Haryana LSA.

2. In this regard, the approval of competent authority is hereby conveyed for
allocation of telecommunication identifiers in numbering series '1600' to M/s Bharat
Sanchar Nigam Limited as tabulated below: -
TSP Name Name of LSA Allotted codes
(1600-ABC-XXXX)
ote: Value of "XXX" may range from 000 to 999, giving 1000 telecommunication
identifiers for each LSA) oo ५
Digitally signed by
Vaibhav Jain
Date: 11-03-2025
15:52:18
(Vaibhav Jain)
Director (AS-III)
Ph: - 011-23372488
Copy for kind information and necessary action, if any, to:
1. Secretary, TRAI
2. Director (T), DGT, HQ with request to convey the allocation to related LSA
field unit.
3. All MNP Licensees.
4. Acopy for upload on DoT website.
KUMAR ecco
