---
doc_id: "cedb2d2a236ab3e9"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/08/09d65d37f2174308984a6a9c7dfd060f.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 24.08.2026: Acceptance of Resignation of Shri Sandeep Mahapatra, from Arbitration Counsel and CGSC Delhi High Court"
date: "2026-08-31"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "73554aefb81fb186"
---

<!-- page 1 -->

J-18/66/2025-JUDICIAL

I/25864/2026

No. J-18/66/2025-JUDICIAL/ E.161268
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
****
24108, Kartavya Bahwan-2, New Delhi,
Dated the 24th Aug, 2026

ORDER
The President is pleased to accept the resignation of S h r i Sandeep
Mahapatra, Senior Arbitration Panel Counsel at Delhi and Central Government
Standing Counsel before the High Court of Delhi engaged for conducting Central
Government litigation with effect from dated of this order.
Consequently, the name of Shri Sandeep Mahapatra, Advocate ﬁguring at
serial number ‘06’ in the List of this Department’s Order No.J-11018/1/2019-Judicial
dated 07.03.2019 to be read with Order No.J-11018/1/2019-Judicial dated
24.03.2022, and name ﬁguring at serial number ‘05’ under the List 'A' of Order
No. J-11017/19/2025-Judicial dated 11.09.2025, stands omitted.
2 .

3.

Hindi version of this order will follow.

(Manindra Choudhary)
Assistant Legal Adviser
Copy (through email) to:
1. PS to Hon’ble Minister of State (Independent Charge) for Law & Justice.
2. Sr. Pr. PS to LS/AS/JS&LA in main secretariat of Department of Legal Affairs .
3. The Litigation In-charge (High Court), Delhi High Court.
4. The Registrar, Delhi High Court.
5. LIMBS team, Legal Affairs.
6. The above Advocate.
7. To be uploaded on website of this Department i.e. www.legalaffairs.gov.in under tab ‘Judicial
Section’ in the link “Orders related to empanelment of Advocate for Union of India”.

8. Hindi Section, Department of Legal Affairs.

(Ramesh Kairamkonda)
Section Officer (Judicial)
Email: judicial-dla@nic.in
Tel: 011-24016111
