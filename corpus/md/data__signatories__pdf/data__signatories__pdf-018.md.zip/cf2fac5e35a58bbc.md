---
doc_id: "cf2fac5e35a58bbc"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/66e443134375dbb4a91bc917af68d054.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Proposed amendment in Recruitment Rules for various posts in Salt Commissioner Organization, inviting comments/ objections"
date: "2025-07-02"
pages: 30
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e93c3b4f0230898b"
---

<!-- page 1 -->

No. P-18011/ 13/2015-Salt/(E-3024)
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry and Internal Trade
{Salt Section)
Vanijya Bhawan, 16-A Akbar Road
New Delhi, the 6 th May, 2024

OFFICE MEMORANDUM
Subject: Uploading proposed amendment in Recruitment Rules for various posts
in Salt Commissioner Organization (SCO) on Department's website for inviting
comments/ objections - Reg.
The undersigned is directed to enclose herewith proposed draft amendments in
Indian Salt Service Recruitment Rule, 1989 and Recruitment Rule {RRs) for Dy.
Superintendent of Salt/Inspector of Salt in Salt Commissioner Organization (SCO) for
inviting comments/objections from stake holders.
2.
Comments/objections on proposed amendment are invited from stake holders
within 30 days of uploading of this O.M. on official website of DPIIT.
Comments/objections may be sent by email at salt-section@gov.in mentioning subject
as Comments/ objection on RRs for various posts in SCO in email.
3.

This issues with the approval of competent authority.

Encl : as above.

(R. K.S ni)
Under Secretary to the Govt. of I dia
Tele: 011-2303 36

To,
1. All Stake holders
2. The Salt Commissioner, O/o Salt Commissioner, Lavan Bhawan, 2-A Lavan Marg,
Jhalana Doongri, Jaipur, Rajasthan - 302004 - with the request to upload on the
official website of SCO.
Copy to : NIC, DPIIT - with the request to upload this O.M. on official website at
appropriate place for 30 days.
Copy for information to : PPS to AS{RST)/DS(BK)

<!-- page 2 -->

Proposed amendments in respect of various posts of Salt Commissioner's Organization (SCO), an attached office under DPIIT seeking
objections/comments/suggestions.
Note:- The suggestions/objections/comments may kindly be send to salt-section@gov.in / soni.rk68@gov.in
Annexure‐3
Form to be filled by the ministry /Department while forwarding proposal to UPSC while proposing amendment to existing
recruitment rules
1.
2.

Name of Post
Name of the Ministry/Department

3.

Reference number in which Commission’s advice on
Recruitment rules was conveyed.
Date of Notification of the original rules and subsequent Notified originally on 21.11.1989 and amended
amendments (copy of the original rules & subsequent 13.02.1990, 13.04.1994 and 11.02.1997 (Annexure- A)
amendments should be enclosed, duly
Flagged and referenced)

4.

Col.
No.

Name

Provision in the
existing/approved Rules

(1)

(2)
Name of the post
No. of posts
Classification

4.

Scale of Pay

(3)
Salt Commissioner
1(One)
Indian Salt Services, Grade-I,
Group A Gazetted
Rs.5100-150-5700

1
2
3

Salt Commissioner
Ministry of Commerce & Industry, Department for Promotion
of Industry and Internal Trade Salt Commissioner’s
Organization
---

Provision proposed by DPIIT

No Change
No Change
No Change

(4)

Level-13A (Pre-revised Rs.37400-67000 GP
Rs.8900/-)

on

Reasons for
proposing revision
----

(5)

Revision of Pay Scale as
per 7th CPC.
1

<!-- page 3 -->

5.
6.
7.

8.

9.

Age limit for direct Not Applicable
No change
-recruitment
Educational and other Not Applicable
No change
-qualifications
for
direct recruitment
Whether educational Not Applicable
No change
-qualifications and age
limit prescribed for
DR
will apply to promotes
Method of recruitment By promotion failing which by By promotion failing which by transfer on Note shall be deleted as
Whether by DR or by transfer
on
deputation deputation (including short-term contract)
the previous position is
promotion/deputation/ (including short-term contract)
not relevant as per
absorption and
7th CPC.
percentage of the
Note: The Officers who have
vacancy to be filled by been appointed on a regular
various method.
basis to the post in the scale of
Rs.1500-2000 (upgraded scale
Rs.5100-5700) prior to the
notification of these rules, shall
be deemed to have been
appointed to the post in the
upgrade scale.
In case of recruitment By
promotion:
Grade-II By promotion: Grade-II Officers of the Indian In accordance to DoPT
by promotion/
Officers of the Indian Salt Salt Service with 6 year’s regular service in the OM
No.
ABdeputation/absorption Services with 7 year’s regular grade of Deputy Salt Commissioner.
14017/4/2021-Estt.(RR)
grades from which
service in the grade.
dated
20.09.2022,
promotion/deputation/
minimum
qualifying
absorption to be made. Transfer
on
deputation Transfer on deputation (including short term service for promotion
(including short term contract): contract): Officers of Central/State/UT from level 12 to 13A is
Officers
of
Central/State Government
/
Public
Sector 6 years.
Government/Public
Sector Undertakings/Statutory/
Undertakings/Statutory/Autono Autonomous Organisation
mous OrganisationThe
Expenditure
Reforms Commission
2

<!-- page 4 -->

(a)(i) holding analogous posts (a)(i) holding analogous posts on regular basis : (ERC) in its Report in
on regular basis : or
or
December, 2001 had
recommended transfer
(ii) with 3 years regular service (ii) with 2 years regular service in posts in the of
Salt
Testing
in posts in the scale of Rs.4500- scale of Level 13 (Rs. 37400-67000 +GP 8700) Laboratories (STLs) to
5700 or equivalent: or
or equivalent: or
M/o Health & Family
Welfare and closure of
(iii)with 7 years’ regular (iii) with 6 years’ regular service in posts in the SCO after the transfer of
service in posts in the scale of scale of Level 12 (Rs. 15600-39100 +GP 7600) SCO land to State
Rs3700-5000 or equivalent and or equivalent.
Governments
concerned.
(b)possessing the following (b)possessing the following educational
educational qualifications and qualifications and experience :
The present mandate of
experience:
the SCO is mainly
related
to
Land
Essential:
Essential :
management,
its
disposal and handling
(i)Master Degree in Chemistry (i) Master Degree in any discipline from a legal cases related to
from a recognized University recognized University or equivalent
land. Therefore, the
or equivalent :
need for personnel
OR
Desirable:
specialized in chemical
Degree in Chemical Engg.
industry in the present
Technology from a recognized 3 years’ experience in handling land and/ or scenario
is
not
University/Institution
or legal matters.
warranted and personnel
equivalent : and
having experience in
handling land and / or
(ii)10 year’s experience in
legal
matters
are
Chemical Industry (including
desirable.
salt Industry).
Accordingly,
the
Desirable :
changes in essential and
desirable qualifications
Ph.D. Degree in Chemistry or
have been made.
Master’s Degree in Chemical
Engineering/Technology
3

<!-- page 5 -->

relevant to EQ(ii) from a
recognized
University
or
equivalent.

10.

If
Departmental
promotion committee
exists what is its
composition

(Period
of
transfer
on
deputation including period of
deputation in another ex-cadre
post
held
immediately
proceeding this appointment in
the same or same other
organization/ department of the
Central Government shall not
ordinarily exceed 4 years)
DPC for considering
DPC for considering promotion :
promotion:
(i)
Chairman/Member, UPSC –
(i)
Chairman/Member,
Chairman
UPSC-Chairman
(ii)
Additional Secretary, Department
(ii)
Additional
for Promotion of Industry and
Secretary,
Internal Trade-Member
Department
of
(iii)
Joint Secretary, Department for
Industrial
Promotion of Industry and Internal
DevelopmentTrade -Member.
Member
(iii)
Joint
Secretary,
Department
of
Industrial
DevelopmentMember.

Mandatory change in
name of Department i.e.
Department
for
Promotion of Industry &
Internal Trade (DPIIT)

Name, address and telephone number : R K Soni, US, DPIIT, Tel : 23038936/8800369858
of the Ministries representatives with
whom these proposals may be
discussed, if necessary for clarification/early decision.
4

<!-- page 6 -->

Signature of the officer
Sending the proposal

5

<!-- page 7 -->

Annexure‐3
Form to be filled by the ministry /Department while forwarding proposal to UPSC while proposing amendment to existing
recruitment rules
1.
2.

Name of Post
Name of the Ministry/Department

3.

Reference number in which Commission’s advice on
Recruitment rules was conveyed.
Date of Notification of the original rules and subsequent Notified originally on 21.11.1989 and amended
amendments (copy of the original rules & subsequent amendments 13.02.1990, 13.04.1994 and 11.02.1997 (Annexure-A)
should be enclosed, duly
Flagged and referenced)

4.

Col.
No.

Name

Provision in the existing/approved
Rules

(1)

(3)
Name of the post
No. of posts

(3)
Deputy Salt Commissioner
5*(1989)
*Subject to variation dependent on work
load.

1
2

Deputy Salt Commissioner
Ministry of Commerce & Industry, Department for Promotion
of Industry and Internal Trade
Salt Commissioner’s Organisation
---

Provision proposed by
DPIIT

No Change
4

(4)

on

Reasons for proposing
revision
(5)

-The Expenditure Reforms
Commission (ERC) in its
Report in December, 2001 had
recommended closure of SCO
after the transfer of SCO land
to
State
Governments
concerned.
Further,
assessment of manpower in
SCO was conducted by
National
Productivity
Council (NPC) in 2016. As
6

<!-- page 8 -->

3

Classification

4.

Scale of Pay

5.

Age limit for direct Not Applicable
recruitment
Educational and other Not Applicable
No change
-qualifications for
direct recruitment
Whether educational Not Applicable
No change
-qualifications and age
limit prescribed for
DR
will apply to promotes
Method
of
By promotion failing which by transfer on By promotion failing which by Note shall be deleted as the
recruitment Whether deputation (including short-term contract) transfer
on
deputation previous position is not
by DR
or
(including short-term contract) relevant as per 7th CPC.
by
Note: The Officers who have been
promotion/deputatio appointed on a regular basis to the post in
n /absorption
and the scale of Rs.1300-1700 (upgraded scale
percentage
of
Rs.3700-5000) prior to the notification of
the vacancy to be
these rules, shall be deemed to have been
filled by
appointed to the post in the upgrade scale.
various method.

6.
7.

8.

Indian Salt Service.
Grade-II, Group ’A’ Gazetted.
Rs.3700-125-4700-150-5000

No Change

per the recommendations of
NPC, the total staff sanctioned
strength was reduced to 306.
The
present
sanctioned
strength
(as
per
NPC
recommendations) for the post
of Deputy Salt Commissioner
is 4 (four) only.
--

Level 12(Prerevised Rs.15600- Revision of Pay Scale as per
39100 GP Rs.7600/-)
7th CPC.
No change
--

7

<!-- page 9 -->

9.

In case of recruitment
by
promotion/deputation
n/absorption grades
from
which
promotion/deputation
n/absorption to
be made

By promotion: Grade-III The Expenditure Reforms
Officers of the Indian Salt Commission (ERC) in its
Service with 5 year’s regular Report in December, 2001 had
service in the grade.
recommended transfer of Salt
Testing Laboratories (STLs)
Transfer on deputation (including short Transfer
on
deputation to M/o Health & Family
term contract): Officers of Central/State (including
short
term Welfare and closure of SCO
Government
/Public
Sector contract):
Officers
of after the transfer of SCO land
Undertakings/Statutory/Autonomous
Central/State/UT Government / to
State
Governments
Organization.
Public
Sector concerned.
Undertakings/Statutory/Autono
mous Organisation
The present mandate of the
SCO is mainly related to Land
(a)(i) holding analogous posts on regular (a)(i) holding analogous posts management, its disposal and
basis: or
on regular basis : or
handling legal cases related to
land. Therefore, the need for
ii) with 2 year’s regular service in posts in (ii) with 5 year’s regular personnel
specialized
in
the scale of Rs.3000-5000 or equivalent: or service in posts in the scale of chemical industry in the
Level 11 (Rs.15600-39100 GP present scenario is not
(iii)with 5 year’s regular service in posts in Rs.6600) or equivalent : or
warranted
and
personnel
the scale of Rs.3000-4500 or equivalent
having experience in handling
and
land and / or legal matters are
desirable.
(b)possessing the following educational (b)possessing the following
qualifications and experience:
educational qualifications and Accordingly, the changes in
experience:
essential
and
desirable
qualifications have been made.
Essential:
Essential :
(i) Master Degree in Chemistry from a
recognized University or equivalent: or
Bachelor’s Degree in
any
Degree in Chemical Engg./ Technology or discipline from a recognized
equivalent
from
a
recognized University or equivalent
University/Institution or equivalent : and
By promotion: Grade-III Officers of the
Indian Salt Service with 5 year’s regular
service in the grade.

(ii)8 years’ experience in Chemical
8

<!-- page 10 -->

Industry (including salt Industry).
Desirable:

Desirable:

Ph.D. Degree in Chemistry or Master’s 2 years’ experience in handling
Degree
in
Chemical land and/ or legal matters.
Engineering/Technology relevant to EQ(ii)
from a recognized University
or
equivalent.
(Period of transfer on deputation including
period of deputation in another ex-cadre
post held immediately preceding this
appointment in the same or some other
organization/department of the Central
Government shall not ordinarily exceed 4
years)
(** The above position is as per RRs
amended vide corrigendum dt. 13.02.1990
- regular service from 2 years to 5 years)
10.

If
Departmental
promotion committee
exists what is its
composition

DPC for considering promotion:
DPC for considering
Mandatory change in name of
(i)Chairman/Member, UPSC- Chairman
promotion:
Department i.e., Department
(ii) Joint Secretary, Department of (i)Chairman/Member, UPSC- for Promotion of Industry &
Industrial Development-Member
Chairman
Internal Trade (DPIIT)
(iii)Salt Commissioner-Member.
(ii) Joint Secretary, Department
for Promotion of Industry and
Internal Trade-Member
(iii)Salt CommissionerMember.

Name, address and telephone number : R K Soni, US, DPIIT, Tel : 23038936/8800369858
of the Ministries representatives with
whom these proposals may be
9

<!-- page 11 -->

discussed, if necessary for clarification/early decision.
Signature of the officer
Sending the proposal

10

<!-- page 12 -->

Annexure‐3
Form to be filled by the ministry /Department while forwarding proposal to UPSC while proposing amendment to existing
recruitment rules

1.
2.

Name of Post
Name of the Ministry/Department

3.

Reference number in which Commission’s advice on
Recruitment rules was conveyed.
Date of Notification of the original rules and subsequent Notified originally on 21.11.1989 and amended
amendments (copy of the original rules & subsequent 13.02.1990, 13.04.1994 and 11.02.1997 (Annexure-A)
amendments should be enclosed, duly
Flagged and referenced)

4.

Col.
No.

Name

Provision in the
existing/approved Rules

(1)

(2)
Name of the post
No. of posts

(3)
Assistant Salt Commissioner
9* (Nine)(1989)
*Subject to variation dependent on
workload

1
2

Assistant Salt Commissioner
Ministry of Commerce & Industry, Department for Promotion
of Industry and Internal Trade
Salt Commissioner’s Organisation
--

Provision proposed by DPIIT

No Change
3

(4)

on

Reasons for proposing
revision
(5)
The Expenditure Reforms
Commission (ERC) in its
Report in December, 2001 had
recommended closure of SCO
after the transfer of SCO land
to
State
Governments
concerned. Further, assessment
of manpower in SCO was
conducted
by
National
Productivity Council (NPC) in
2016.
As
per
the
recommendations of NPC, the
11

<!-- page 13 -->

3

Classification

4.

Scale of Pay

5.

Age limit for direct
recruitment

6.

Educational and other
qualifications for
direct recruitment

Indian Salt Service Grade-III
Group ‘A’ Gazetted.
Rs.3000-100-3500-125-4500

No Change

total staff sanctioned strength
was reduced to 306. The
present sanctioned strength (as
per NPC recommendations) for
the post of Assistant Salt
Commissioner is 3 (three) only.
--

Level-11 (Pre-revised Rs. 15600- Revision of Pay Scale as per
39100/- Grade Pay Rs. 6600/-)
7th CPC.

40 Years (Relaxable for Government No Change
servant upto 5 years, in accordance
with the instructions or orders issued
by Central Government)

-

Note: The crucial date for
determining the age limit shall be the
closing date for receipt of
application from candidates in India
(Other than those in Andaman &
Nicobar Islands and Lakshadweep)
Essential:
Essential:

The Expenditure Reforms
Commission (ERC) in its
(i)Master’s Degree in Chemistry Bachelor’s Degree in
any Report in December, 2001 had
from a recognized University or discipline
from a recognized recommended transfer of Salt
equivalent
University or equivalent.
Testing Laboratories (STLs) to
Degree
in
Chemical
M/o Health & Family Welfare
Engg./Technology or equivalent Desirable:
and closure of SCO after the
from a recognized University/
transfer of SCO land to State
Institution or equivalent ; and
2 years’ experience in handling Governments concerned.
(ii)5 years’ experience in Chemical land and/ or legal matters.
Industry (including Salt Industry).
The present mandate of the
(iii)Administrative experience.
SCO is mainly related to Land
management, its disposal and
Desirable:
handling legal cases related to
12

<!-- page 14 -->

Ph.D. Degree in Chemistry or
Master’s Degree in Chemical
Engineering/Technology relevant to
EQ(ii)
from
a
recognized
University/Institution of equivalent.
Note 1: Qualifications are relax able
at the discretion of the Commission.
Note2:
The
qualification(s)
regarding experience is/are relaxable
at the discretion of the Commission
in the case of candidates belonging
to Scheduled Castes and Scheduled
Tribes, if, at any stage of selection,
the Commission is of the Opinion
that sufficient number of candidates
from those communities possessing
the requisite experience to fill up the
vacancies reserved for them.

7.

(vide corrigendum of erstwhile
Deptt. of Industrial Development dt.
13.02.1990, added or equivalent
word after University)
Age: No
No Change

Whether
Age and educational
qualifications limit
EQ: Yes
prescribed for Direct
Recruits will apply in the
case of promotees

land. Therefore, the need for
personnel
specialized
in
chemical industry in the
present
scenario
is
not
warranted
and
personnel
having experience in handling
land and / or legal matters are
desirable.
Accordingly, the changes in
essential qualifications have
been made.

--

13

<!-- page 15 -->

8.

9.

Method
of
By promotion failing which by No Change
-recruitment Whether
transfer on deputation (including
by
DR
or
short-term contract) failing both by
by
direct recruitment
promotion/deputation n
/absorption
and
percentage
of
the vacancy to be
filled by
various method.
In case of recruitment by By promotion: Grade-IV Officers of By promotion: Grade-IV Officers (a) In case of recruitment by
promotion/deputation
the Indian Salt Service with 8 years of the Indian Salt Service with 5
promotion,
seeking
n/absorption
grades regular service in the grade.
years’ regular service in the grade
relaxations in number of
from
which
years
of
minimum
promotion/deputation
Transfer on deputation (including Transfer
on
deputation
qualifying service to 5
n/absorption to
short term contract)
(including short term contract):
years, as a special case,
be made
Officers
of
Central/State/UT
for the following reasons:
Officers
of
Central/State Government / Public Sector
Governments/Semi
Undertakings/Statutory/
(i) Since none of the Officers
Governments/Statutory Autonomous Autonomous Organisation
in the organisation will be
Organisationseligible for promotion to
the Pay Level-11, due to
(a)(i)holding analogous posts on a (a)(i)holding analogous posts on a
minimum
qualifying
regular basis; or
regular basis ; or
service, it is suggested to
reduce
minimum
ii) with 5 year’s regular service in ii) with 5 year’s regular service in
qualifying service for
posts in the scale of Rs.2200-4000 or Level 10 (Rs.15600-39100 GP
promotion to 05 years.
equivalent; or
Rs.5400) or equivalent : or
This change will provide
regular Group A from
(iii)with 8 year’s regular service in (iii) with 8 year’s regular service
Indian Salt Service (ISS)
posts in the scale of Rs. 2000-3500 in posts in the scale of Level 7
Cadre.
or equivalent; and
(Rs. 9300-34800/- Grade Pay Rs. (ii) This is highly required for
4600/-) or equivalent and
managing pending court
cases/disposal of other
(b)possessing the qualifications and (b) possessing the qualifications
cases etc., as Estate
14

<!-- page 16 -->

experience prescribed for direct and experience prescribed for
recruits under Column 6.
direct recruits under Column 6.

Officer. About 2668 acres
of land in Mumbai
Region, is pending under
(Period of transfer on deputation (Period of transfer on deputation
the
Public
Premises
including period of deputation in including period of deputation in
(Eviction of Unauthorised
another
ex-cadre
post
held another ex-cadre post held
Occupants) Act, 1971, for
immediately
preceding
this immediately
preceding
this
which the proceedings
appointment in the same or some appointment in the same or some
could not be undertaken
other organization/department of the other organization/ department of
since 2017-18 due to nonCentral Government shall not the Central Government shall not
availability of Estate
ordinarily exceed 3 years)
ordinarily exceed 3 years).
Officer (Group A gazetted
officer)
in
Mumbai
Region.
(iii) SCO is finding it difficult
to protect the interest of
Government of India in
safeguarding the precious
and valuable lands spread
across 9 states worth Rs.
1.14 lakh crores (as on
31.03.2022).

10.

If
Departmental
promotion committee
exists what is its
composition

DPC for considering promotion:

DPC for considering promotion:

(1)
Chairman/Member,
UPSC- (1) Chairman/Member, UPSCChairman
Chairman
(2) Joint Secretary/Department of (2) Joint Secretary/Department for
Industrial Development-Member.
Promotion of Industry and Internal
(3) Salt Commissioner- Member.
Trade-Member
(3) Salt Commissioner- Member.
DPC for considering confirmation:

Departmental

(b) Revision of Pay Scale as
per 7th CPC, in the case of
transfer on deputation.
Mandatory change in name of
Department i.e., Department
for Promotion of Industry &
Internal Trade (DPIIT).

Confirmation
15

<!-- page 17 -->

1.Joint Secretary, Deptt. of Industrial Committee (DCC) for considering
Development –Chairman.
confirmation:
2.Deputy Secretary, Deptt. of
1. Chairman/Member, UPSCIndustrial Development-Member.
Chairman
3.Salt Commissioner-Member.
2. Joint Secretary/Department for
(The Proceeding of the DPC relating Promotion of Industry and Internal
to confirmation shall be sent to the Trade-Member
Commission for approval. If, 3. Salt Commissioner- Member.
however, these are not approved by
the Commission, a fresh meeting of (The Proceeding of the (DCC)
the DPC to be presided over by the relating to confirmation shall be
Chairman or a member of the sent to the Commission for
commission shall be held).
approval. If, however, these are
not approved by the Commission,
a fresh meeting of the DCC to be
presided over by the Chairman or
a member of the commission shall
be held).
Name, address and telephone number : R K Soni, US, DPIIT, Tel : 23038936/8800369858
of the Ministries representatives with
whom these proposals may be
discussed, if necessary for clarification/early decision.
Signature of the officer
Sending the proposal

16

<!-- page 18 -->

Annexure‐3
Form to be filled by the ministry /Department while forwarding proposal to UPSC while proposing amendment to existing
recruitment rules
1.
2.

Name of Post
Name of the Ministry/Department

3.

Reference number in which Commission’s advice on
Recruitment rules was conveyed.
Date of Notification of the original rules and subsequent Notified originally on 21.11.1989 and amended
amendments (copy of the original rules & subsequent 13.02.1990, 13.04.1994 and 11.02.1997 (Annexure-A)
amendments should be enclosed, duly
Flagged and referenced)

4.

Superintendent of Salt
Ministry of Commerce & Industry, Department for Promotion
of Industry and Internal Trade
Salt Commissioner’s Organisation
--

Col.
No.

Name

Provision in the
existing/approved Rules

(1)

(2)
Name of the post
No. of posts

(3)
Superintendent of Salt
No Change
22*(Twenty two)
15
(1989)
*Subject to variation dependent
on workload.

1
2

Provision proposed by DPIIT
(4)

on

Reasons for proposing
revision
(5)
-The Expenditure Reforms
Commission (ERC) in its
Report in December, 2001
had recommended closure of
SCO after the transfer of
17

<!-- page 19 -->

3

Classification

4.

Scale of Pay

5.

Age limit for direct
recruitment

6.

Educational and other
qualifications for
direct recruitment

SCO
land
to
State
Governments
concerned.
Further,
assessment
of
manpower in SCO was
conducted
by
National
Productivity Council (NPC)
in 2016. As per the
recommendations of NPC,
accepted by DPIIT, the total
staff sanctioned strength was
reduced to 306. The present
sanctioned strength (as per
NPC recommendations) for
the post of Superintendent of
Salt is 15(fifteen) only.
--

Indian Salt Service, Grade-IV,
No Change
Group B Gazetted
Rs.2000-60-2300-EB-75-75Level-7 (pre-revised Rs. 9300- Revision of Pay Scale as per
3200-100-3500
34800/- Grade Pay Rs. 4600/-)
7th CPC.
30
Years
(Relaxable
for Upto 35 years
There is severe shortage of
Government servant upto 5 years,
manpower in SCO, since
in
accordance
with
the
there is no direct recruitment
instructions or orders issued by
for this post since 2001. More
Central Govt.)
experienced person will
apply for the post.
Note: The crucial date for
determining the age limit shall be
the closing date for receipt of
applications from candidates in
India (other than those in
Andaman & Nicobar Islands and
Lakshadweep)
Essential :
Essential:
The present mandate of the
SCO is mainly related to
(i)Master’s degree in Chemistry Bachelor’s
degree
in
any Land
management,
its
18

<!-- page 20 -->

from a recognized University or discipline
from
a recognized disposal and handling legal
equivalent ; or
University or equivalent.
cases related to land.
Degree in Chemical Engineering
Therefore, the need for
/Technology or equivalent from a Desirable:
personnel specialized in
recognized University or
chemical industry in the
equivalent.
Bachelor's
Degree
in
Civil present scenario is not
Engineering/ Law/ Architecture warranted.
Desirable :
from a recognized University or its
Experience in a Chemical equivalent
Accordingly, the changes in
Laboratory or in Salt Industry
essential qualifications have
been made.
Note1:
Qualification(s)
are
relaxable at the discretion of the
Commission.

7.

Note2:
The
qualifications(s)
regarding experience is relaxable
at the discretion of the
Commission in the case of
candidates
belonging
to
Scheduled Castes and Scheduled
Tribes, if at any stage of selection,
the Commission is of the opinion
that
sufficient
number
of
candidates
from
these
communities
possessing
the
requisite experience are not likely
to be available to fill up the
vacancies reserved for them.
Whether educational
No, but the promotees Officers, No Change
qualifications and age limit must have at least a Bachelor’s
prescribed for DR
degree in Chemistry or Diploma
will apply to promotes
in Chemical Engineering from a
recognized University/Institution
or equivalent.
However, the

--

19

<!-- page 21 -->

8.

9.

above condition will not apply in
case of promotee officers working
in the department on the date of
commencement of these rules.
Method
of
50% by promotion, failing which 75% by promotion, failing which by The present mandate of the
recruitment Whether by
by transfer on deputation;
transfer on deputation (including SCO is mainly related to
DR
50% by direct recruitment.
short- term contract);
Land
management,
its
or
by
disposal and handling legal
promotion/deputation
^Provided that not more than and 25% by direct recruitment, cases related to land.
/ absorption
and
50% of the substantive posts in failing which by transfer on Therefore, the need for
percentage
of
the grade shall, at any time, be deputation (including short- term personnel specialized in
the vacancy to be filled by held by either category, namely, contract).
chemical industry in the
various method.
direct recruits and promotees.
present scenario is not
warranted and personnel
Note: All vacancies arising during
having qualification in civil
the year 1989; 1990 & 1991 shall
engineering/ law/ architecture
be filled 100% by promotion.
would be desirable.

In case of recruitment by
promotion/deputation
n/absorption grades from
which
promotion/deputation
n/absorption
to be
made

^ Added vide Deptt of Industrial
Accordingly, the changes in
Policy
and
Promotion
qualifications have been
(DIPP)notification of Industry
made.
amendment dated 11.02.1997
(Annex- )
Promotion:
Promotion:
In accordance to DoPT OM
Officers in the grades of Deputy Officers in the grades of Deputy No.
AB-14017/4/2021Superintendent of Salt with 3 Superintendent of Salt with 5 years’ Estt.(RR) dated 20.09.2022
year’s regular service in the regular service in the grade
grade.
Transfer on deputation: Officers
Transfer on deputation:
of Central/State/UT Government /
Public
Sector
Officers under the Central/State Undertakings/Statutory/Autonomous
Government.
Organisation
(a)(i) holding analogous posts on (a) (i)holding analogous posts on a
20

<!-- page 22 -->

a regular basis; or

regular basis; or

(ii)with 3 year’s regular service in (ii) with 3 year’s regular service in
posts in the scale of Rs.1640-2900 posts in the scale of Level-6 (Rs.
or equivalent; and
9300-34800/- Grade pay Rs. 4200/-)
or equivalent; and
(b)possessing the educational
qualifications and experience (b) possessing the following
prescribed for direct recruits educational
qualifications
and
under column 6
experience

10.

(Period of transfer on deputation Essential :
including period of deputation in
another ex-cadre post held Bachelor’s Degree in any discipline
immediately
preceding
this from a recognized University or
appointment in the same or some equivalent
other organization/department of
the Central Government shall not (Period of transfer on deputation
ordinarily exceed 3 years)
including period of deputation in
another
ex-cadre
post
held
immediately
preceding
this
appointment in the same or some
other organization/department of the
Central Government shall not
ordinarily exceed 3 years).
If
Departmental
Departmental Promotion
Departmental Promotion Committee Mandatory change in name of
promotion committee exists Committee (DPC) for considering for considering promotion
Department i.e. Department
what is its composition
promotion
for Promotion of Industry &
1.Joint Secretary, Department of 1.Joint Secretary, Department for Internal Trade (DPIIT)
Industrial Development-Chairman Promotion of Industry and Internal
2.Salt Commissioner-Member
Trade-Chairman
3.Under Secretary, Department of 2.Salt Commissioner-Member
Industrial
Development
– 3.Under Secretary, Department for
Member
Promotion of Industry and Internal
Trade - Member
21

<!-- page 23 -->

DPC for considering
confirmation:
Departmental
Confirmation
1.Joint Secretary, Department of Committee (DCC) for considering
Industrial Development –
confirmation:
Chairman
1.Joint Secretary, Department for
2.Salt Commissioner-Member
Promotion of Industry and Internal
3.Under Secretary, Department of Trade-Chairman
Industrial Development-Member. 2.Salt Commissioner-Member
3.Under Secretary, Department for
(The
proceedings
of
the Promotion of Industry and Internal
Departmental
Promotion Trade - Member
Committee
relating
to
confirmation shall be sent to the (The
proceedings
of
the
commission for approval if, Departmental
Confirmation
however these are not approved Committee relating to confirmation
by the Commission, a fresh shall be sent to the commission for
meeting of the Departmental approval if, however these are not
Promotion Committee to be approved by the Commission, a
presided over by the Chairman or fresh meeting of the Departmental
Member of the Committee shall Confirmation Committee to be
be held).
presided over by the Chairman or
Member of the Committee shall be
held).
Name, address and telephone number : R K Soni, US, DPIIT, Tel : 23038936/8800369858
of the Ministries representatives with
whom these proposals may be
discussed, if necessary for clarification/early decision.
Signature of the officer
Sending the proposal

22

<!-- page 24 -->

Annexure‐3
Form to be filled by the ministry /Department while forwarding proposal to UPSC while proposing amendment to existing
recruitment rules
1. Name of Post

Deputy Superintendent of Salt (Present Post)
Inspector of Salt (Formerly before 6th CPC)
Ministry of Commerce & Industry, Department for Promotion
of Industry and Internal Trade
Salt Commissioner’s Organization (an Attached Office)
--

2. Name of the Ministry/Department

Reference number in which Commission’s advice on
Recruitment rules was conveyed.
4. Date of Notification of the original rules and subsequent Inspector of Salt (1.5.1985, 24.12.2003)- Annexure-B
amendments (copy of the original rules & subsequent
amendments should be enclosed, duly
Deputy Superintendent of Salt (25.03.1992 amended on
Flagged and referenced)
31.03.1995)-Annexure-C
3.

Inspector of Salt merged with Dy Suprintendent of Salt as
per 6th CPC
Col. Name
No.
(1)
(2)
1 Name of the post

Provision in the existing/approved Rules

2

153*
52*(1992)
90
*(Subject to variation *Subject to variation
depending on the dependent on workload
workload)

No. of posts

Inspector of Salt
and/or Chemical
Assistant

Provision proposed by
DPIIT
(3)
(4)
Deputy Superintendent Deputy Superintendent of
of Salt
Salt

Reasons
revision

for

proposing

(5)
As per recommendations of 6th
CPC, name of post has been
renamed
as
Deputy
Suprintendent of Salt.
The Expenditure Reforms
Commission (ERC) in its
Report in December, 2001 had
recommended closure of SCO
after the transfer of SCO land
to
State
Governments
concerned. Further, assessment
23

<!-- page 25 -->

3

Classification

4.

Scale of Pay

5. Selection or
Non‐Selection
6. Age limit for direct
recruitment

of manpower in SCO was
conducted
by
National
Productivity Council (NPC) in
2016.
As
per
the
recommendations of NPC,
approved by DPIIT, the total
staff sanctioned strength was
reduced to 306. The present
sanctioned strength (as per
NPC recommendations) for the
post of Deputy Superintendent
of Salt is 90 only.
General
Central General Central Service General Central Service Post of Inspector of Salt was
Service Group ‘C’ Group
‘B’
Non- Group ‘B’ Non-Gazetted merged with post of Deputy
(Non-Ministerial),
Gazetted,
Non- Non-Ministerial.
Superintendent of Salt w.e.f.
(Non-Gazetted)
Ministerial.
01.01.2006 vide order No. A60011/6/Admn/2008/16141623 dated 15.05.2018 in
accordance with instructions
contained in the Gazetted of
India
(Extraordinary)
G.S.R.622(E), Ministry of
Finance, Deptt. Of Expenditure
Notification dated 20.08.2008.
Rs. 5000-150-8000 Rs.1640-60-2600-EB- Level-6 (pre-revised Rs.
Revision of Pay Scale as per
75-2900.
9300-34800/- Grade Pay Rs. 7th CPC.
4200/-)
Selection
Selection
Selection
Between 18 and 25 N.A.
years (relaxable as
per rules)

Upto 30 years

There is severe shortage of
manpower in SCO, since there
is no direct recruitment for this
post
since
2001.
More
experienced person will apply
for the post.
24

<!-- page 26 -->

7

8.

9.

Whether benefit of
-N.A.
added years of service
admissible under rule
30 of C.C.S. (Pension)
Rules, 1972
Educational and other Degree
of
a N.A.
qualifications for
University or its
direct recruitment
equivalent
with
Chemistry as the
primary subject

-

Whether educational Yes,
educational N.A.
qualifications and age qualification
shall
limit prescribed for DR apply for promotee
will apply to promotes candidates

No Change

-

Essential:

The present mandate of the
SCO is mainly related to Land
Bachelor’s degree in any management, its disposal and
discipline from a
handling legal cases related to
recognized University or land. Therefore, the need for
equivalent.
personnel
specialized
in
chemical industry in the present
Desirable:
scenario is not warranted and
personnel having qualification
Bachelor's Degree in Civil in civil engineering/ law/
Engineering/
Law/ architecture would be desirable.
Architecture
from
a
recognized University or its Accordingly, the changes in
equivalent
qualifications have been made.
---

10 Period of Probation, if
Two years
2 years
No change
-any
11. Method
of
85%
by
direct By Promotion failing 75% by direct recruitment, In view of ban on direct
recruitment Whether recruitment and 15% which by transfer on failing which by transfer on Recruitment since 2001, there
by
DR or
by by promotion failing deputation.
deputation (including short- is a severe shortage of
promotion/
which by direct
term contract);
manpower in SCO leading to
deputation/absorption recruitment.
and 25% by promotion,
more encroachments, litigations
and percentage of the Promotion shall be in
failing which by transfer on and
other
serious
vacancy to be filled by the ratio of 5:1 for
deputation (including short- consequences. In view of the
various method.
Upper
Division
term contract).
above, it is important to initiate
Clerks
and
direct recruitment in SCO.
25

<!-- page 27 -->

Laboratory
Assistants
Further,
the
reduced
respectively. In case
educational qualification for
adequate candidates
promotion will make more
are not available in
departmental
candidates
U.D.C. cadre with
eligible for the post. The
the
prescribed
suggested changes would allow
qualification,
the
filling up of the posts through
quota
shall
be
deputation.
transferred
to
Laboratory Assistant
cadre.
12. In case of recruitment Promotion from the Promotion:
Promotion:
The present mandate of the
by
grades of Upper Chemical
Assistant/ Promotion from the grades SCO is mainly related to Land
promotion/deputation Division Clerks with Inspector of Salt with 5 of Upper Division Clerks, management, its disposal and
n/absorption grades Science Graduate ( years’ regular service in with 05 years regular service handling legal cases related to
from
with Chemistry) and the grade.
having Bachelor’s degree in land. Therefore, the need for
which
Laboratory Assistant
any
discipline from a personnel
specialized
in
promotion/deputation Grade I, both with Transfer on deputation : recognized university or chemical industry in the present
n/absorption to
eight years Regular Officer
under
the equivalent.
scenario is not warranted.
be made
service
and Central Government;
Laboratory Assistant (a)(i) holding analogous Transfer on deputation:
grade II with twelve posts on regular basis; Officers of Central/State/UT
years regular service, or
Government / Public Sector
in the Respective (ii)with 2 years regular Undertakings/Statutory/
grades.
service in posts in the Autonomous Organisation
scale of Rs.1600-2600
or equivalent; or
(a)(i) holding analogous
(iii) with 5 years regular posts on regular basis; or
service in posts in the
scale of Rs.1400(ii) with 5 years regular
2300/2600 or
service in posts in the scale
equivalent; and
of Rs. Level-5 (Rs. 520020200/Grade
Pay
(b)
possessing
a Rs.2800/-) or equivalent;
26

<!-- page 28 -->

Bachelor’s degree with and
Chemistry as one of the
subjects
from
a (b) possessing a Bachelor’s
recognized University degree in any discipline
or
from a
equivalent
and recognized University or
possessing
2 years equivalent.
experience
in
a chemical Lab. or in a The departmental officers in
Salt Industry.
the feeder category who are
in the direct line of
The departmental promotion shall not be
officers in the feeder eligible for consideration for
category who are in the appointment on deputation.
direct line of promotion
shall not be eligible for Similarly,
deputationists
consideration
for shall not be eligible for
appointment
on consideration
for
deputation.
appointment by promotion.
Similarly, deputationists Period
of
deputation
shall not be eligible for including
period
of
consideration
for deputation in another exappointment
by cadre post held immediately
promotion.
preceding this appointment
in the same or some other
Period of deputation organization/department of
including period of the Central Government
deputation in another shall ordinarily not exceed 5
ex-cadre
post
held years with possibility of
immediately preceding extension up to 2 years
this appointment in the based on performance.
same or some other
organization
/department
of
the
27

<!-- page 29 -->

Central
Government
shall ordinarily not
exceed 3 years.
Note: where junior who
have completed their
qualifying/
eligibility
service
are
being
considered
for
promotion, their seniors
would
also
be
considered
provided
they are not short of the
requisite qualifying /
eligibility services by
more than one year and
have
successfully
completed
their
probation period, if
prescribed.
(vide
DPIIT
notification dated 31-31995 above note was
added)
13. If
Departmental Group ‘C’
Group ‘B’ DPC
Departmental Promotion
promotion committee Departmental
Committee for Group ‘B’
exists what is its
Promotion
1.Salt Commissioner- DPC
composition
Committee:Chairman.
1.Salt Commissioner 2.Member from other 1.Salt Commissioner /
- Chairman
Central Government
Director / Dy. Secretary or
2.Dy.
Salt Office- Member.
equivalent of DPIIT Commissioner
– 3.Under Secretary of the Chairman.
Member
Administration Ministry 2.Member from other
3.An officer from of Industry – Member. Central Government Office

Mandatory change in name of
Department i.e. Department for
Promotion of Industry &
Internal Trade (DPIIT)

28

<!-- page 30 -->

other
Central 4.Deputy Salt
Government Office – Commissioner –
Member
Member.
4.Asstt.
Salt 5.Assistant Salt
CommissionerCommissioner –
AdministrationMember.
Member
14. Circumstances in
which UPSC is to be
consulted in making
recruitment

Not Applicable

equivalent to Under
Secretary Member.
3.Under Secretary of DPIIT
– Member.
4.Deputy Salt Commissioner
/ Assistant Salt
Commissioner – Member.

Consultation with UPSC Consultation with UPSC is -is not necessary
not necessary

Name, address and telephone number : R K Soni, US, DPIIT, Tel : 23038936/8800369858
of the Ministries representatives with
whom these proposals may be
discussed, if necessary for clarification/early decision.
Signature of the officer
Sending the proposal

29
