---
doc_id: "d12d0da0b80eda0c"
source_url: "https://www.mdoner.gov.in/static/uploads/2025/08/f90190eead7961deaf3209454fc167b0.pdf"
ministry: "Development of North Eastern Region (MDONER)"
title: "NESIDS ROADS Guidelines (30th-Nov-23)"
date: "2023-11-30"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0b785ac5a06de5bf"
---

<!-- page 1 -->

NEC-11/14/2022-UNDER SECRETARY(A)
Government of India
Ministry of Development of North Eastern Region
Vigyan Bhawan Annexe,
Maulana Azad Road,
New Delhi-110011
November 30, 2023
To
The Chief Secretaries,
All the North Eastern States
Sub: Guidelines for Administration of the North East Special Infrastructure for Administration of the North East Special Infrastructure
Development Scheme(Roads) (NESIDS-Roads) of MDoNER - reg. Scheme(Roads) (NESIDS-Roads) of MDoNER - reg,
Sir/Madam,

Reference this Ministry’s letter No. NEC-11 /14/2022-Under Secretary(A) dated
21.08.2023 and 03.10.2023 under which the guidelines for administration of the subject
scheme was issued.

2. In addition to the Checklist for Project selection under the NESIDS (Road) scheme
mentioned at Annexure- A of the scheme guidelines, it has been decided to include the
following details in the checklist for Project selection:-
e Video recording for the entire alignment/ stretch of the road duly geo-referenced
with latitude and longitude coordinates.
e Date of original construction of road (in case of existing road)
e Details about major repair work done in the last 5 years.
e Whether the road or any stretch of the road had been originally constructed
under any Scheme of MDoNER or any other Ministry of Govt. of India
e In case of proposal for bridges, location and distance of nearest bridge in
upstream/ downstream direction is to be clearly specified
3. This issues with the approval of Secretary (DoNER).
Yours faithfully,
(Silabhadra Das)
Deputy Secretary to the Government of India
Copy to:
i. Chief Executive Officer, NITI Aayog
ii, | Home Secretary,

<!-- page 2 -->

x
iii, Finance Secretary
iv. Foreign Secretary,
vy. Secretary, Department for Promotion of Industry and Internal Trade
vi. Secretary, MoRTH
vii. Secretary, MoRD
viii. Secretary, North Eastern Council.
Copy also to:
1. PS to Hon’ble Minister, DoNER
2. APS to Hon’ble MoS, MDoNER.
3. PPS to Secretary, MDoNER
4, PPS to AS&FA, MDoNER
5. PSs to Sr. EA, JS(AD), JS(HS), JS(AC)
6. All Directors/ Deputy Secretaries/Joint Director in MDoNER
7. Technical Wing, MDoNER
8. Sr. Director, NIC for uploading on the website of the Ministry
3 V2
(Silabhadra Das)
Deputy Secretary to the Government of India
