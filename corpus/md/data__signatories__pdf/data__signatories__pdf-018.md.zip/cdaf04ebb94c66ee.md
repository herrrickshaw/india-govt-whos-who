---
doc_id: "cdaf04ebb94c66ee"
source_url: "https://mines.gov.in/admin/download/68e34ef8e41401759727352.pdf"
ministry: "Mines (MoM)"
title: "Corrigenda (605.03 KB)"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "b57a82cfde44f61a"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

xxxGIDHxxx

सी.जी.-डी.एल.-अ.-03102025-266613
xxxGIDExxx
CG-DL-E-03102025-266613
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 638]

नई दिल्ली, सोमवार, जसतम्बर 29, 2025/आज‍वन 7, 1947
NEW DELHI, MONDAY, SEPTEMBER 29, 2025/ASVINA 7, 1947

No. 638]

खान मंत्रालय
िुजि पत्र
नई दिल्ली, 29 जसतम्बर, 2025
सा.का.जन. 722(अ).––भारत सरकार, खान मंत्रालय की अजधसूचना संखयांक सा.का.जन. 468(अ), तारीख
14 िुलाई, 2025, जिसे भारत के रािपत्र, असाधारण, भाग II, खंड 3, उपखंड (i) में प्रकाजित दकया गया था, के ह ि
ं ी
पाठ में,—
(i) पृष्ठ संखया 10 पर, पंजि 40 में, “जनयम” के स्ट्थान पर “(1) जनयम” पढें;
(ii) पृष्ठ संखया 11 पर, पंजि 5 में, “जनयम” के स्ट्थान पर “(1) जनयम” पढें;
(iii) पृष्ठ संखया 17 पर, पंजि 1 में, “प्रत्येक” के स्ट्थान पर “(1) प्रत्येक” पढें|
[फा. सं. एम-VI-1/10/2024-खान VI]
दिनेि माहुर, संयक्
ु त सजचव

6530 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

MINISTRY OF MINES
CORRIGENDUM
New Delhi, the 29th September, 2025
G.S.R. 722(E).–––In the notification of the Government of India, Ministry of Mines, published in the
Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i) vide number G.S.R. 468(E), dated the 14 th July,
2025, in the English Version,—
(i)

at page number 88, in line 32, for “(16)T he” read “(16) The”;

(ii)

at page number 91, in line 16, for “(16) If” read “(1) If”;

(iii)

at page number 92, in line 25, for “(5) Every” read “(1) Every”;

(iv)

at page number 100, —
(a) in line 16, for “(x) to” read “to”;
(b) in line 18, for “(y) the” read “(x) the”;
(c) in line 21, for “(z) the” read “(y) the”;
(d) in line 26, for “(aa) in” read “(z) in”;

(v)

at page number 108, in line 38, for “(a) Provided” read “Provided”;

(vi)

at page number 110, —
(a) in line 21, for “(2) Any” read “(1) Any”;
(b) in line 43, for “(2) On” read “(1) On”;

(vii)

at page number 111, in line 18, for “(2) All” read “(1) All”;

(viii)

at page number 147, —
(a) in line 10, for “iii.” read “i.”;
(b) in line 12, for “iv.” read “ii.”;

(ix)

at page number 149, in lines 36, 37 and 38, under coloum (1), omit “(i), (i), (ii)”.
[F. No. M.VI-1/10/2024-Mines VI]
DINESH MAHUR, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
Digitally signed by GORAKHA
and Published by the Controller of Publications, Delhi-110054. GORAKHA
NATH YADAVA
2025.10.03 15:39:49
NATH YADAVA Date:
+05'30'
