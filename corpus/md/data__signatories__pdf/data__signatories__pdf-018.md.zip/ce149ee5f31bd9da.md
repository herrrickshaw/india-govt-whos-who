---
doc_id: "ce149ee5f31bd9da"
source_url: "https://doj.gov.in/static/uploads/2025/12/beeafe53e8ea7f56adb9cdd5d560d630.pdf"
ministry: "Department of Justice (DoJ)"
title: "Vidhi Centre for Legal Policy"
date: "2021-11-22"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "538fe6c37a5c6c74"
---

<!-- page 1 -->

SPEED POST
File No. N-9/16/ 2015 - NM
Government of India
Ministry of Law and Justice
(Department of Justice)
Jaisalmer House,
26-Mansingh Road, New Delhi-110 011.
Dated: 6"" September, 2016.
SANCTION ORDER
Sanction of the Competent Authority is hereby accorded to the payment of Rs.7,10,800/-
only (Rupees Seven Lakh Ten Thousand Eight Hundred Only), being 40% of total project cost, to
Vidhi Centre for Legal Policy, New Delhi towards Second Installment of the total project cost of
Rs. 17,77,000/- only (Rupees Seventeen Lakh Seventy Seven Thousand Only) (non-recurring
expenditure) for undertaking project proposal titled “Strengthening Mediation as a Viable Dispute
Resolution Mechanism for India” under the “Scheme of Action Research and Studies on Judicial
Reforms’, as per the terms agreement signed by Vidhi Centre for Legal Policy, New Delhi and
Department of Justice on 03" March, 2016. First installment of Rs.3,55,400/- only (Rupees Three
Lakh Fifty Five Thousand Four Hundred Only) was released to the implementing Agency vide this
Department's sanction order of even no. dated 04" March, 2016. The implementing agency is
requested to utilise this amount within the project timeline period and as per terms of the above
mentioned Agreement.
2. The expenditure involved is debitable to Demand No. 56 during 2016-17 (Plan) under Major
Head 2014-Administration of Justice; 17-National Mission for Justice Delivery and Legal Reforms,
17.02-Action Research and Studies on Judicial Reforms; 17.02.28-Professional Services.
3. This has been entered in the Register of Grants / Expenditure at SI. No. 2 at page No. 29-
30.
4. This issues with the approval of IFD [Law] vide AS & FA Dy. No. 900 dated 30/08/2016.
rPeh-o
(Z#=Khany 7
Under Secretary to the Government of India
To,
Pay & Accounts officer,
Ministry of Law & Justice, Department of Legal Affairs,
Janpath Bhawan, Janpath,
New Delhi.
Copy to:-

4. Section Officer, Cash-I Section, Ministry of Home Affairs, NDCC Building, New Delhi with one
spare copy and a copy of Agreement. It is requested that the payment may be made through
e-payment to Vidhi Centre for Legal Policy, New Delhi.

2. Section Officer, Cash-ll Section, Ministry of Home Affairs, NDCC-II Building, New Delhi.

3. Research Director, Vidhi Centre for Legal Policy, D-21, Lower Ground Floor, Jangpura -
Extension, New Delhi- 110014.

i 4. Section Officer, Administration Unit, Department of Justice, Jaisalmer House, New Delhi.

5. Principal Accounts Office, 4" Floor, Ministry of Law and Justice, Lok Nayak Bhawan, Khan
Market, New Delhi. '

6. Guard File हट 1७०० ~~

7. Spare Copies-5. SRD 2

(ZA Khan)
Under Secretary to the Government of India
