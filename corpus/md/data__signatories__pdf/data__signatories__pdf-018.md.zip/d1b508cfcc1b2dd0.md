---
doc_id: "d1b508cfcc1b2dd0"
source_url: "https://moef.gov.in/uploads/2021/08/Amendment-S.O.-83-E-dated-16.01.2004-on-Matheran-Ecosensitive-Area.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "संशोधन S.O. 83 (E) दिनांक 16.01.2004"
date: "2021-08"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fab8f9666df851fb"
---

<!-- page 1 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY, PART II,
SECTION 3, SUB-SECTION (ii) DATED 16TH JANUARY, 2004]
MINISTRY OF ENVIRONMENT AND FORESTS
NOTIFICATION
New Delhi, the 16th January 2004

S.O. 83 (E) – Whereas by the notification of the Government of India in the Ministry of
Environment and Forests number S.O. 133 (E), dated the 4th February, 2003
(hereinafter referred to as the said notification), the Central Government notified
Matheran and surrounding areas an Eco-sensitive Zone (ESZ) and imposed restrictions
on industries, operations, processes and other developmental activities in the said zone.
Now, therefore, in exercise of powers conferred by sub-section (1) read with
clause (v) of sub-section (2) of section 3 of the Environment (Protection) Act, 1986 (29 of
1986) and clause (d) of sub-rule (3) of rule 5 of the Environment (Protection) Rules,
1986, the Central Government hereby makes the following amendments in the aforesaid
notification, namely :-

1.

In paragraph 2, in line 2, after the words “buffer zone”, the words
“comprising of a total area of 251.56 sq. kms” shall be inserted;

2.

In paragraph 3, the following shall be inserted at the end, namely:“In particular, and without prejudice to the provisions of the said Acts, following
steps shall also be taken:
(a) In any proposal for use of forest area for non-forestry purpose, the
procedure laid down for National Parks and Sanctuaries shall be followed.
(b) Adequate fuel wood plantation shall be undertaken in the surrounding
area to prevent illegal cutting of trees for firewood, etc.
(c) A specific Forest Protection Plan shall be prepared by the Maharashtra
State Forest Department and necessary funds for implementation of the
Protection Plan shall be provided by the State Government on priority basis.”

<!-- page 2 -->

2
3. In paragraph 4,(a)

in sub-paragraph(a), in item (iv),
(i) in line 5, after the words “ground coverage for buildings” the words “in
Matheran Municipal limits” shall be omitted;
(ii) in line 10, for the words “In areas other than Matheran Municipal limits:” the words “In the Eco-Sensitive Zone:-” shall be substituted.

(b)

in sub-paragraph (h), in line 7, for the figure ”4”, the figure ”5” shall be
substituted.

(c)

in sub-paragraph (n), in line 2, for the words “except ambulance and
fire engine and use of tractor for transportation of solid waste”, the
words “except one ambulance and one fire engine and in addition to
one ambulance and one fire engine as standby” shall be substituted.

4. In paragraph 6, after sub-paragraph (3), the following sub-paragraphs shall be
inserted, namely:“(4) It shall be the duty of the Monitoring Committee to inquire into or review
cases of alleged violations of the provisions of the Environment (Protection)
Act, 1986, and the rules made thereunder, and if found necessary in a specific
case, issue directions under section 5 of the said Act.
(5) The Monitoring Committee or any Officer or member of the Monitoring
Committee authorised by it shall be authorised to take action under section
10 of the said Act to verify the facts concerning the issues arising from the
above.”

5. At page 26, in line 1, for the figure and words ” 6. Appeal”, the figure and words
“7. Appeal” shall be substituted.

6. In Annexure–B, in line 2, for the words “MMR” the words “Mumbai Metropolitan
Region (MMR)” shall be substituted.

7. In Annexure-D, sub-paragraph 5.2 shall be omitted.
[F. No. J-20011/1/99-I.A.-III]

Dr. R.R. Khan
Adviser
