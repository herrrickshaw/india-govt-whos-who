---
doc_id: "cf6baa5fb1caea6b"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/1e69254cd80913ffa9d1ec671b219cd8.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment for Tis Hazari Courts, Delhi: Order dated 30.08.2017"
date: "2017-09-04"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "16443bfe57bf0748"
---

<!-- page 1 -->

F.No. J-11017/3/2017-Judl.(Part-2)
Government of India
Ministry of Law and Justice
Department of Legal Affairs
Judicial Section
ik
; Shastri Bhawan, New Delhi,
Dated 30" August, 2017
ORDER
The President is pleased to engage Shri Karanveer Singh Bana, Advocate as Additional
Central Govt. Counsel for conducting Central Government litigation (except the cases of Railways
& Taxation) before Tis Hazari Courts, Delhi, as shown below, for a period of three years from the
date of this order or until further orders, whichever is earlier:
Tis Hazari Courts, Delhi
Additional Central Govt. Counsel |
Name
Karanveer Singh | Chamber No.-X-39A, Civil Wing, Tis | D/455/1996 (R)
Bana Hazari Courts, Delhi-110054.
Mob: 9818020074
Phone: 011-23987732
अर The engagement and professional fee of the aforesaid advocate will be governed by the
terms and conditions contained in this Department's O.M. No, 27(11)/99-Judl. dated 24.09.1999
read with OM No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued subsequently through
OMs. The aforesaid OMs are available on the official website of this Department i.e.
www.legalaffairs.gov.in in the tab ‘Judicial Section’ under heading ‘Circulars pertaining to
litigations’.
3 Hindi version of this order will follow.
5००४-८7
(Inder Kumar)
Additional Secretary
Copy for information to:-
1. PS to ML8&J/PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary/All Additional Secretaries/PS to all |
JS&LA in the Main Sectt.
2. The District Judge, Tis Hazari Courts, Delhi.
3. The Incharge, Litigation (Lower court) Section, Tis Hazari Court campus, New Delhi.
4. Shri Karanveer Singh Bana, Addl. Central Govt. Counsel at the address as mentioned herein above.
5. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
6. Guard File/Judicial Section with 5 spare copies.
7. Office copy.
ee
eo
(D. Srinivas)
Section Officer (Judicial)
Tel.011-23384945
Email: judicial-dla@nic.in
