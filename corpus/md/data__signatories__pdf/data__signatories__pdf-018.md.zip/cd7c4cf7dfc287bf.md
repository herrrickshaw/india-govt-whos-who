---
doc_id: "cd7c4cf7dfc287bf"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/NITM10Corri1_18052026.pdf"
ministry: "Department of Space"
title: "Corrigendum: URSC/C&MG/C/M/10/2026-27 Dated: 27/04/2026      690.63 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "4a879232466ea271"
---

<!-- page 1 -->

भारत सरकार/GOVERNMENT OF INDIA
अंत र

िवभाग/DEPARTMENT OF SPACE

यू.आर. राव उप ह के

U.R. RAO SATELLITE CENTRE

िनमाण व अनुर ण समूह/CONSTRUCTION AND MAINTENANCE GROUP
एच.ए.एल. एयरपोट रोड, बगलू

/ H.A.L. AIRPORT ROAD, BENGALURU-560 017.

(फोन-/Phone -080 2508 4184, 4156)
ईिनिवदा नोिटस सं- /E- Tender Notice No: URSC/C&MG/C/M/10/2026-27 िदनांक/dated: 27/04/2026
Corrigendum-I Dt. 14/05/2026
1. भारत के रा पित की ओर से, िन िल खत काय हे तु बं द मद दर िनिवदाओं को आमंि त िकया जाता है ।
On Behalf of the President of India, sealed, item-rate tenders are invited for the following
work.
.सं.
Sl. No
1.

2.
3.

4.

5.
6.

7.

8.

9.

िववरण/Description
काय शीष/Title of work

िनिवदा म दशाये अनुमािनत लागत/
Estimated cost put to tender
काय आदे श के 15 व िदन से महीनों म काय
समा की अविध/ Period of completion
in months reckoned from the 15th day
of date issue of work order.
अविध, िजसम िनिवदा द ावेज को
डाऊनलोड िकया जा सकता है।/Period
during which the tender document
can be downloaded.
बोली
ीकरण/ Bid clarifications
बोली
ीकरण के िलए उ र दे ने की अंितम
तारीख /Last date of reply to bid
clarification
िनिवदा ा के िलए अंितम िदनांक तथा
समय/Last date and time for receipt of
tenders.
िनिवदा खोलने के िनधा रत तारीख व
समय/Due date and time of opening of
tenders.
अि म धन िन ेप/ Earnest money deposit
(EMD)

ौरा/Details
Contract for Hiring of Shamiyana and other
Allied Items for Main Campus, URSC,
Vimanapura and ISITE Campus, Marathahalli,
Bengaluru
₹12.37 लाख पये / ₹12.37 Lakhs

Twelve Months

Extended upto 25.05.2026, 16.30 Hrs

Extended upto 26.05.2026, 16.30 Hrs
Extended upto 28.05.2026, 17.00 Hrs

Up to 29.05.2026, 14:30 Hrs

Onwards 29.05.2026, 14:31 Hrs
₹ 24,740.00 /- 180 िदनों के िलए
₹ 24,740.00 /- valid for 180 days

All other terms and conditions remain unaltered as in the above tender notice.

Sd/GROUP DIRECTOR, C&MG, URSC
