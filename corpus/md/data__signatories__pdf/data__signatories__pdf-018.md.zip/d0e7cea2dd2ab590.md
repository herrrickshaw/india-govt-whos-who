---
doc_id: "d0e7cea2dd2ab590"
source_url: "https://consumeraffairs.gov.in/public/upload/admin/cmsfiles/corrigendum/Corrigendum_1_corrigendum.pdf"
ministry: "Department of Consumer Affairs (DoCA)"
title: "1. Corrigendum 1"
date: ""
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "97c7c3d6972b21cb"
---

<!-- page 1 -->

Sub: Queries for RFP for engagement of Management Consultant for Strategic Transformation Support for Bureau of Indian
Standards and DoCA
S.
No
1.

Page
No.
32 & 45

Section
3&4

2.

46

4

Clause
No.
3.23 &
4.8

Query
raised by
BCG

4.12

BCG

RFP Statement
Contract Period: The contract
period of the project will be 12
months.
Time Schedule: The DoCA
intends to complete the study
in 9 months. The Draft Project
Report with overall findings of
the project should be submitted
to the DoCA within 10 months
of the work order, and the final
report within one month of the
receipt of the feedback of the
DoCA. The intended plan
implementation along with
handholding of BIS and DoCA
should be completed within 15
months after final report
submission.
Payment

Query/Comments/Suggestion

Response from DoCA& BIS

We request you to clarify the total The contract period of the project will
duration (including implementation be 24 months as indicated in para 4.8
stage) of the project.
of the RFP Statement.
The contract duration is mentioned as

9
months
for
study/
12
months initially
and
is
submission of the plan,
subsequently being changed to 26
recommendations
and
months including the implementation
process of transformation of
stage.
BIS, DoCA

15
months
for
implementation of the plan,
support and handholding
recommendations submitted.
This includes processing of
recommendations and their
acceptance in BIS & DoCA.

We request you to kindly provide (i) 20% of the total payment to be
clarity on the payment terms.
made after
A draft payment schedule - linked to
1. Baselining
completion of topics mentioned in
2. International best practices
Scope of Work – has been provided
3. SDG & green standards study
in Appendix 1.
4. Marketing & Ease of Doing
Business (Within 5 Months)
(ii) Another 30 % to be made after
submission of the study report
(Within 9 Months).
(iii) Final 50% to be made after
acceptance of report /hand holding/

<!-- page 2 -->

3.

44

4, 2 and 6 4.4 (viii),
Annexures 2.8 (vi)
and Forms & Form
11

BCG

4.

50

5

5.2 (1)(b)

BCG

5.

50

5

5.2 (1)(c)

BCG

Eligibility Criteria:
a) Copy of Work Order or
Work
Contract.
The
credentials of the project such
as Name of the Client,
payment details, scope details
etc. shall not be masked.
In case of assignments
completed abroad, the agency
is
required
to
submit
completion
certificate
of
consultancy assignments duly
authenticated or verified by the
Indian mission or embassy of
the said place or country
Past experience of having
completed projects of similar
nature and scale

We request you to accept the selfcertificate
by
MD/CEO/
Authorized signatory for all case
experience/studies sighted in the
RFP, instead of the work order or
embassy certifications. Additionally,
we can provide a description of
client, the nature of services we
performed for them, the duration of
the project and the contract value.
We have signed confidentiality
agreements with our clients that limit
our ability to disclose their names &
the contracts / work orders with them.

We understand that projects of
similar nature and scale mean
business,
strategy,
financial
consulting
and
operational
assignments with standard setting &
related
organizations
(Standard
setting, Testing and conformity
assessment/Accreditation/Regulatory)
of size excluding IT implementation,
Forensic/ Internal Audit/ Risk
Assessment
Kindly confirm.
Past Experience in carrying out We understand that carrying out
Studies in the related sector
studies in related sector means
strategy, transformation assignments
with
Central/
State
Governments/PSUs
in
past
experience for evaluation of this
criteria.

training and implementation.
Embassy Certifications has been
omitted. This has already been taken
care of in para 4.4(viii) and form 11.
Para 2.8(vi) is being revised
accordingly.
However, so far as Work Order is
concerned, it shall be given. The Firm
may mask the payment details.
However, the description of work,
name of the client and execution
certificate etc. is to be furnished.

Project related to Transformation of
any sort and related organizations
(Standard setting, Testing and
conformity
assessment/Accreditation/Regulatory)
of size excluding IT implementation,
Forensic/ Internal Audit/ Risk
Assessment

Projects related to transformation of
Organisation are considered to be of
similar nature.
Assignments
with
Accredited/
certified bodies can also be included.

<!-- page 3 -->

6.

50

5

5.2. (2)
(a)

BCG

7.

51

5

5.2 (1)
(b)

BCG

8.

50

5

5.2 (2)(b)

BCG

9.

75

6

Form 11

BCG

Qualification:
All the team members meeting
the minimum qualification as
per Cl 4.4 (ix) of the RFP
document and either Team
Leader or any of the team
member has PhD: 4 marks
All the team members meeting
the minimum qualification as
per Cl 4.4 (ix) of the RFP
document and both Team
Leader and one of the team
member has PhD:
5 marks
Past experience of having
completed projects of similar
nature and scale

Kindly confirm.
We request you to remove the
marking criteria for PhD and
accept the Post-Graduation in
MBA/PG Diploma/Equivalent from
IIMs/ISB/XLRI/similar educational
institutions in India or abroad.
Typically, Consulting firms have
large pool of resources who are
MBA/PG Diploma/Equivalent from
premium Indian institutions and these
people have experience of working in
various projects across different
sectors.

In addition to the number of projects,
we request you to consider quality
and depth of experience by
including evaluation of 2 case
studies, for 10 marks each (Total 20
marks) of similar transformation/
restructuring projects. Detailed case
studies allow technical evaluation
committee to evaluate consultant’s
approach and outcomes in similar
context.
Relevant
experience
of It is important to understand the
Professional Personnel (Max. expertise of person handling similar
14 Marks)
projects by key personnel while
interacting in the presentation.
Hence, kindly assign 50% of
Professional Personnel marks based
on their participation in the technical
presentation.
Type of Surveys
We understand that this is a strategy

The request of the firm has not been
agreed to. This condition is
appropriately defined and remain as
such.

Detailed case study clearly indicating
the scale and nature can be submitted.

The type of survey involved will
depend on the methodology adopted
by the firm, which is agreed to the
evaluation Committee. Accordingly,
the request of the firm has not be
agreed to.
The request of the firm has not been

<!-- page 4 -->

Annexures
and Forms

10.

51

5

5.2 (3)

BCG

Overall financial strength of
the consultant in terms of
turnover

11.

13

2

2.8.1 (i)

BCG

Single firm or consortium of
firms (Turnover of each
member of consortium will be
accounted for to arrive average
annual financial turnover of
consortium) having average
annual financial turnover, from
consultancy assignments, of ₹
30 Crores in immediate
preceding three financial years
i.e. 2019-2020, 2020-2021 and
2021-2022

assignment which will involve
transformation projects conducted for
similar global assignment
We understand that this does not
involve surveys from specific groups.
Hence, we request you to remove this
column.
Generally, the annual turnover is an
eligibility criterion rather than an
evaluation criterion. This allows
participation by top tier 6-8 relevant
consulting firms.
Hence, we request you to remove
this evaluation criteria and allocate
these 15 marks to the Approach and
Methodology section.
Consulting revenue indicates the
strength of the consulting practice for
the bidders.
We understand that the assignment
requires deep expertise in strategic
organization transformation with
expertise in both Indian as well
global context.
Hence, we request you to increase the
average annual turnover criteria to at
least ₹ 500 Crore from consultancy
business to attract participation by
top tier 6-8 relevant consulting firms.

agreed to.
If applicable, description can be
furnished.

The request of the firm has not been
agreed to.

The request of the firm has not been
agreed to.

<!-- page 5 -->

12.

14,38

2&3

2.8.3,
3.38.5

BCG

Changes
in
Constitution/
financial
stakes/
responsibilities of a Contract’s
Business

Nature of our firm is such that there We have agreed.
are multiple Managing Director and
Partners, therefore it won’t be
possible to give this intimation for
each partner. We can only inform
about changes in partners involved in
the project. Therefore, we request to
modify the clause accordingly and
limit termination to only changes in
such partners directly involved in the
project.

13.

23, 32233

2&3

2.17,
3.24

BCG

Conflict of Interest

After reviewing the RFP, Consultant Person directly involved
is not aware of any actual, apparent, BIS/DoCA can’t be engaged.
or significant potential for an
organizational conflict of interest on
the part of either Consultant’s
organization or its individual
employees at this time. Consultant
will also assure the protection of the
information and data it receives in
performance of this contract from
unauthorized use or disclosure, and
will avoid actions that would cause a
reasonable person to question the
impartiality of Consultant or its
employees in the performance of this
contract and potential participation in
future contracts.
We would like to clarify that as a
standard practice Consultant will not
assign consultants who have worked
with Client to provide services to a
direct competitor of Client where the
services to be provided are
substantially similarto the Services

with

<!-- page 6 -->

14.

27, 31

3

3.4, 3.19

BCG

Confidentiality, Secrecy

Consultant performs for Client under
the Contract. Consultant agrees that
this restriction will last for 12 months
from the conclusion of the
individual’s work with Client on the
Contract. This restriction will not
apply to any senior professionals who
serve as Consultant practice area
leaders (“PALs”), topic leaders, topic
experts or advisors, including data
scientists and Consultant digital,
analytical
data
or
software
developers. Involvement of an
individual in the Contract will not
preclude them from working for other
clients in Client’s industry.
Working in an inter-connected world,
Consultant may have existing/future
clients that maybe directly governed
by BIS standards. It is our longstanding policy not to enter into
exclusive arrangements with any
single organization in a given
industry or sector. To mitigate any
potential concerns, we have an
established set of protocols to help
avoid even the appearance of a
potential conflict of interest between
our private sector and public sector
work.
We agree with the confidentiality The request of the firm has not been
terms and propose the following agreed to.
additions to be incorporated in
Additional Terms–
1) Making the confidentiality clause

<!-- page 7 -->

15.

27

3

3.5

BCG

Publicity

16.

27

3

3.6

BCG

Stamp Duty

mutual and have standard exceptions
2) Additionally, in order to be
compliant with any legal or tax
orders, we request that we are
allowed to retain the copies of the
reports or deliverables submitted by
us as evidence of the work completed
by us under this contract
3) The confidentiality obligations to
last for 3-5 years and not forever
4) There shall be no limitation on
Consultant to share its learning
general knowledge, skills and
experience and know-how, expertise,
ideas,
techniques,
approaches,
concepts, or designs used, developed
or acquired the course of the
Engagement, including, but not
limited to, any know-how, conceptsor
information retained in the unaided
memory of employees or agents.
We request that we have a mutual no The request of the firm has not been
publicity clause to state the following agreed to.
– “Neither Party will make any public
announcement nor press release
regarding any Proposal nor any
activities performed under it without
the prior written consent of the other
Party. Except as required by law, no
reference may be made to Consultant
in any prospectus, proxy statement,
offering memorandum or similar
document or materials prepared for
public distribution.”
Please let us know exact stamp duty The agreement will be signed on the

<!-- page 8 -->

amount to avoid any ambiguity

17.

28,33,48 3 & 4

3.9, 3.25,
4.19

BCG

Documents,
Documents

Ownership

18.

28

3

3.10.2

BCG

Liability of Agency

19.

29

3

3.12

BCG

Abandonment of Work

stamp paper of Rs.100/- and
notarization shall be as per no. of
copies required.
of We
request
that
terms The request of the firm has not been
likeDeliverables and Pre-Existing agreed to.
IPR are defined as follows, to avoid
any ambiguity –
1) Deliverable(s)” means (final
versions of presentations, reports,
prepared during the agreement
2) Pre-Existing IPR - means any IPR:
(i)
developed
by
a
Party
independently of the engagement; or
(ii) owned by a Party, or licensed to
such Party (other than by the other
Party), at the commencement date of
the Engagement, including any and
all derivative works including
modifications or enhancements to the
same made before, during, and after
the engagement.
Add a provision to clarify that any
Pre-Existing IPR in the Deliverables
will be owned by Consultant.
We request that Consultant’s liability The request of the firm has not been
is capped to the contract value and agreed to.
consultant shall also be not liable for
any
indirect,
incidental,
consequential, special or exemplary
damages
arising
from
this
Agreement, such as, but not limited
to, loss of revenue or anticipated
profits or loss business
We request to add a clarification that In case the client decides to abandon
Consultant shall be paid for all or reduce the scope of work, DoCA

<!-- page 9 -->

20.

30

3

3.15

BCG

Extension of Time

21.

30-31

3

3.18

BCG

Indemnity

22.

3132,48

3&4

3.20,
4.20

BCG

Force Majeure

Services rendered till the effective with the approval of the competent
date of abandonment.
authority will decide payment for the
rendered service, only in case of
justified reason.
We request that a clarification is DoCA with the approval of the
added to the extent that if delay is due competent authority will decide
to reasons not attributable to extension of time for justified reason.
Consultant then extension shall be
provided irrespective of decision of
Client without any additional liability
to Consultant
We request that the indemnity The request of the firm has not been
provision is discussed mutually at agreed to. It is self-explanatory and
contract award stage to incorporate well defined
the following –
1) Limit indemnity to thirdparty claims only
2) Limit all indemnities to
limitation of liability clause
3) For indemnity for IP
infringement, we include
certain caveats.
We request any decision w.r.t force Decision of Secretary (CA) is final
majeure event shall be taken mutually
by both parties and not just DoCA,
additionally, we request removing
this language as same is not
applicable to Consulting Services
“PROVIDED FURTHER that if the
performance in whole or part of any
obligation under thiscontract is
prevented or delayed by reason of
any such event for a period exceeding
60 days, either party may at its option
terminate the contract provided also

<!-- page 10 -->

23.

32

3

3.22

BCG

24.

33-34

3

3.26.2

BCG

25.

34

3

3.26.2.5

BCG

that the DoCA shall be at liberty to
take over from the Contractor at a
price to be fixed by Secretary, which
shall be final, all unused, undamaged
and accepted material, bought out
components and stores in course of
manufacture in the possession of the
contractor at the time of such
termination or such portion thereof as
the DoCA elect to retain.”
Changes and Additions in We request, any changes to the scope
Agency’s Scope of Work
are mutually discussed (not solely by
Client) and price is revised in case
the scope is increased.
Termination

Consequences of termination

We request following changes are
incorporated to the Termination
clause –
1) In case of Suspension, price
to be paid shall be mutually
decided based on services
provided
till
date
ofsuspension. Decision to be
taken mutually and not solely
by Client
2) In case of Force Majeure,
both parties shall have right
to terminate
3) Unsatisfactory performance
to be defined as same is very
broad
4) Consultant to also have right
to terminate in case of any
breach on part of client
We request following changes to

In case of addition in the scope of
work having financial bearing, DoCA
with the approval of the competent
authority will decide the demand of
the agency.

Pont 1: Decision will be taken by
Secretary (CA)

Point 2. The request of the firm has
not been agreed to.
Point 3: Non-adherence to the
specified timeline with acceptable
deliverables.
Point 4. The request of the firm has
not been agreed to.

<!-- page 11 -->

26.

34-34

3

3.28

BCG

Dispute Resolution

27.

35,38

3

3.31,
3.38.2

BCG

Independent Audit

consequences of termination –
1) Penalty and LDs to be
charged only if there is a
delay in performance or nonperformance
2) If termination is a result of
failure
to
provide
deliverables as per the
requirements of the contract
then in that case penalty and
LDs should not be charged
and only contract should be
terminated with prior notice
of cure.
3) Consultant to be paid for all
services
rendered
till
effective date of termination.
4) We
request
removing
blacklisting clause from
termination.
Blacklisting
should be considered only in
case of fraud.
We request the clause is revised w.r.t
appointment of 3 arbitrators, one by
each party and then the two
arbitrators to appoint the 3rd
arbitrator.
Additionally,
the
Consultant shall not be liable to
perform
during
the
arbitrationproceedings.
We would like to clarify that scope of
audit should exclude disclosure of
any documents or other material
relating to the profitability or internal
profit and loss/balance sheets

Point 1 to 3 : The request of the firm
has not been agreed to.

Point 4: Blacklisting shall only be
considered in case of fraud.

The request of the firm has not been
agreed to.

All documents related to the project
concerning DoCA and BIS shall be
furnished to the Audit.

<!-- page 12 -->

28.

43

4

4.3 –
Scope of
Work,
point 20

BCG

The agency will be required to
create
detailed
execution
blueprint in line with BIS Act,
2016 for each of the
recommendations made in the
report.

29.

46

4

4.9

BCG

Contract Period

30.

NA

NA

NA

BCG

Additional

Term

-

Re-

associated
with
Consultant’s
business, payroll information, or
information
or
material
that
constitute, in the opinion of
Consultant’s legal counsel, legally
privileged documents or information
that Consultant is bound to maintain
as confidential by written obligation
to a third party.
We request a clarification is added to
this extent in the final contract.
We would like to clarify that the
Consultant does not provide any
legal, regulatory, accounting, or tax
advice that may have a bearing on the
recommendations
provided
by
Consultant.
We would like to propose the
inclusion
of
the
following
clarification that Client shall be
responsible for obtaining its own
legal, regulatory, tax and accounting
advice concerning laws, regulations,
agreements
and
other
legal,
accounting or tax issues related to the
said RFP.
Additionally, Client shall ensure
compliance
with
security
requirements applicable to it.
The defect liability period is not
defined in the RFP, therefore we
request that the contractremains in
force for a specific defined period of
time to make it less ambiguous.
Consultant prepares a deliverable

The request of the firm has not been
agreed to. The said clause of the RFP
is self-explanatory and shall be
abided by the Firm.

The defect liability period will be for
12 months.

The request of the firm has not been

<!-- page 13 -->

distribution of deliverables specifically for the clientas per their agreed to.
with third parties
requirements and instructions, we
urge inclusion of the below, which
shall protect Consultant’s rights
against any third party claims that
may arise from unauthorized redistribution of the deliverable.
“The Client acknowledges and agrees
that the Deliverables are prepared
solely for the Client's internal use.
The Client will not disclose the
Deliverables
or
make
the
Deliverables available for use by any
third party without the prior written
consent of Consultant. The Client
will procure that any third party to
which it wishes to disclose the
Deliverables or any other Consultant
materials or work must first sign
Consultant’s standard form of nonreliance letter. Consultant can
provide the Client with a copy of this
form upon the Client’s request. If
Consultant agrees to the Client
disclosing the Deliverables to third
parties, the Client agrees that
Consultant will not be responsible for
any losses incurred by the Client or
any third party as a result of or in
connection with such disclosure, or
the third party's use of, or reliance on
the Deliverables or any other aspect
of Consultant work.”

<!-- page 14 -->

S.
No

Page
No.

Section

Clause No.

1.

10,17

2

Point 6 &
Clause 2.12

Query
raised
by
EY

RFP Statement

Query

Suggestive Response

Last date of Submission of Request for extension in Recommended date
bids is 17th October 2023, date of bid submission by submission 31 Oct’23
1500 Hrs
2 weeks to prepare a
comprehensive
and
qualitative
proposal
please

2.

16

2

2.11.2

EY

The bidder has to ensure
that the above bid amount
quoted is inclusive of all
manpower support
required for the project
execution and continuous
support during the entire
contract period.

As per the RFP (CPPP
portal), contract period is
730 days (2 Years). It is
requested to include a
clause
related
to
extension of services/
contract for another 2
years
on
mutual
discussion and consent,
subject to 10% increment
in the original Project
cost.

3.

16

2

2.11.2

EY

The bidder has to ensure
that the above bid amount
quoted is inclusive of all
manpower support required
for the project execution
and continuous support
during the entire contract
period.

There is no mention
about OPEs, in case
travel is required to
location outside Delhi or
for development/
deployment of online
tools.

Response from DoCA
of The request of the firm
has not been agreed to.

The date for bid
submission has been
extended
till
26th
October, 1500 Hrs.
It is requested to add The request of the firm
following clause please has not been agreed to.
“The contract duration can
be further extended for
another 2 years on mutual
agreement with escalation
of
10%
per
year.
Additional manpower may
be deployed at pro-rata
basis in case additional
tasks are added to the
Consultant’s scope of
work.
Out of Pocket expenses on BIS has around 40
account
of
boarding/ branch offices outside
lodging or development/ Delhi (within India). Bid
deployment of any online amount should include
tool will be borne by the OPEs.
client on prior approval
and on actuals.

<!-- page 15 -->

4.

32

3

3.23

EY

5.

43

4

4.3 (B)

EY

6.

45

4

4.8

EY

The contract period of the As per the RFP details on
project will be 12 months.
CPPP portal, contract
period happens to be 730
days (2 years) but as per
clause 3.23, contract
period
mentions
12
months.
Transforming DoCA
The scope of work
1. Restructuring of DoCA covered
under
for transforming future Transforming DoCA is
ready for commerce.
extremely
vast
and
2. Preparing plan to require specific skill set
revamp DoCA to make with
Organisation
more Consumer oriented.
Restructuring,
Brand
3. Addressing challenges in Marketing
and
the
emerging
digital Positioning, Assessment
economy
including of
Financial
and
Metaverse.
Logistics operations. It is
4. Any other suggestion for requested to remove this
transformation of DoCA.
scope of services from
the current RFP and
release a separate RFP
with detailed activities to
be
carried
out/
milestones and
team structure.
The DoCA intends to As per the time schedule,
complete the study in 9 the project duration
months. The Draft Project seems to be 24 months.
Report
with
overall
findings of the project
should be submitted to the
DoCA within 10 months of
the work order, and the
final report within one

It is requested to clarify the
project timelines please.
Suggestive timelines are as
given below under Point 6.

The contract period of
the project will be 24
months as indicated in
para 4.8 of the RFP
Statement.

It is recommended to
remove the Transforming
DoCA scope of services
from the current RFP.
Although, reforms required
in working of BIS will still
be part of scope.

In respect of Strategic
transformation support
for DoCA is concerned,
the scope of work is to
be related to DoCA
policy , operational and
administrative
relationship with BIS
only and not related to
other operative division
of the Department of
consumer affairs

The suggestive timelines
are as follows:
T1-T9: Diagnostic Study/
Assessment
T10:
Draft
Report
Submission
T12:
Final
Report
submission
T13-T24: Intended plan

The contract period of
the project will be 24
months as indicated in
para 4.8 of the RFP
Statement.

<!-- page 16 -->

7.

46

4

4.12

EY

8.

47

4

4.15

EY

month of the receipt of the
feedback of the DoCA. The
intended
plan
implementation along with
handholding of BIS and
DoCA
should
be
completed
within
15
months after final report
submission.
100%
payment
of
assignment fee will be paid
to the agency only upon
successful completion of
the project

The DoCA, may, at its own
discretion appoint another
agency
to
vet
the
recommendations made. In

implementation along with
handholding of BIS

As per the clause 8.12
(page 73) of GFR
guidelines, “Payment is
made
to
the
consultant/service
provider
based on a schedule
agreed on in contract,
often based on certain
milestones or outputs”

It is requested to keep the
vetting/ assessment of
recommendations within
the
BIS
experts

It is suggested to keep the (i) 20% of the total
payments/
invoicing payment to be made
timelines as based on after
submission of Monthly
1. Baselining
progress reports or as 1/24
2. International
of the total bid value.
best practices
3. SDG & green
standards study
4. Marketing
&
Ease of Doing
Business
(Within
5
Months)
(ii) Another 30 % to be
made after submission
of the study report
(Within 9 Months).
(iii) Final 50% to be
made after acceptance of
report /hand holding/
training
and
implementation.
It is requested to form a It has been accepted
specialised
review
committee within BIS/
DoCA to vet/ assess the

<!-- page 17 -->

case such an agency makes
any recommendations to
the DoCA regarding any
changes to be made and in
case these are accepted by
the DoCA then the agency
shall incorporate the same
in the final
recommendations
9.

50

5

5.2

EY

10.

50

5

5.2
2a)

(Point EY

11.

28

3

3.10.2

EY

committee. In case it is recommendations instead
necessary to engage a of hiring a third party firm.
third party for the same,
it is requested not to
engage any agency who
could be a potential
compete of the bidder/
project execution firm to
avoid any conflict of
interest.

Team Structure proposes For the seamless and
Team Leader and 5 Lead effective delivery of the
researchers
scope of work, it is
requested to make minor
modifications to the
existing team structure
please. Revised team
structure is as suggested
under annexure 1 for
consideration please.
All the team members It is requested to exclude
meeting the minimum Ph.D.
from
the
qualification as per Cl 4.4 evaluation criteria of the
(ix) of the RFP document core team members (fulland both Team Leader and time deployment) and
one of the team member instead include that as a
has Ph. D
part of non-core team
members
(part-time
deployment) please.
The agency shall be liable It is requested to limit the
to
Client
for
the liability to maximum of
performance of services in the bid value.
accordance
with
the
provision of this Contract

Revised team structure The team structure given
suggested under annexure in the RFP is only
1
indicative.

The request of the firm
has not been agreed to.
This
requirement
ensures that the Team
fulfils the competence
requirement to carry out
the project effectively
on time.
The agency shall be liable
to
Client
for
the
performance of services in
accordance
with
the
provision of this Contract

The maximum limit
shall be decided by the
competent
authority
DoCA as and when the
need arise.

<!-- page 18 -->

and for any loss suffered
by Client as a result of
default of the agency in
such performance.
12.

13

2

2.8.2

EY

and for any loss suffered
by Client as a result of
default of the agency in
such performance subject
to max up to the bid value.

Single firm or consortium
of firms (Turnover of each
member of consortium will
be accounted for to arrive
average annual financial
turnover of consortium)
having average Annual

It is requested to not
allow the consortium
under this tender. The
tender is very specific to
strategic transformation
of BIS, and we request
one single firm must
financial turnover, from handle the scope of
consultancy assignments, work. Sub-contracting
of ₹ 30 Crores in may be allowed.

immediate preceding three

13.

13

2

2.8.2

EY

financial years i.e. 20192020,
2020-2021
and
2021- 2022.
Single firm or consortium
of firms (Turnover of each
member of consortium will
be accounted for to arrive
average annual financial
turnover of consortium)
having average annual
financial turnover, from
consultancy assignments,
of ₹ 30 Crores in
immediate
preceding three financial
years i.e. 2019-2020, 20202021 and 2021- 2022.

It is requested to keep the
turnover to at least INR
200 cr so that big firms
must participate in view
of the complex and
strategic work

The request of the firm
has not be agreed to.
Sub-contracting will not
be allowed as it will not
ensure
quality
and
timely completion of
work.
The consortium should
be at most of 2 parties
with
clear
understanding.

The average turnover
requirement
of
the
applicant may be kept in
line with the circular
No. F 18/13/2020 dated
13th July 2020 Advisory
regarding
turnover
criteria in Consultancy
Contracts.
In view of above, the
request
regarding
increase in eligibility
criteria of minimum
average turnover in last
three financial years has

<!-- page 19 -->

14.

44

4

4.4

EY

15.

1

3

As per
corrigendum
published on
11.10.2023

EY

3.9

EY

16.

28

3

They must be either on
permanent rolls of the
Applicant or must have a
long tenure contract (Two
years or more) to ensure
continuity of the proposed
project team. The CVs of
the resources are to be
submitted for evaluation.
In addition, the Applicant
may also indicate
Last date of Submission of
bids is 24th October 2023,
1500 Hrs

All copyright and other
proprietary rights in the
Works shall vest and stand
assigned to the DoCA and
the
DoCA
shall
consequently
own,
absolutely and exclusively
on a worldwide basis, the
whole of property, rights,
title and interest including
all copyright in the Works,
present or future, vested or
contingent, generally and
without limitation, for the
whole
term
of
the

not be agreed to.
This request from the
firm has not be agreed
as this requirement
ensures continuity of the
project and completion
on time.

It is requested to remove
this clause regarding
employees being on
payroll. This will allow
the bidder to hire experts
from outside the firm
who could add value to
the entire delivery and
strategic transformation.
24th October is a
gazetted holiday for
Dussehra. Request for
extension in date of bid
submission by 1 weeks to
prepare a comprehensive
and qualitative proposal
please.
Request to delete and
replace
with
the
following
suggestion
please.

Recommended date
submission 31 Oct’23

of The request of the firm
has not been agreed to.
The date for bid
submission has been
extended
till
26th
October, 1500 Hrs.

The agency may use data, The request of the firm
software, designs, utilities, has not been agreed to.
tools, models, systems and
other methodologies and
knowhow
(“Materials”)
that it owns in performing
the
Services.
Notwithstanding
the
delivery of any Reports,
the agency retains all
intellectual property rights
in the Materials (including
any
improvements
or
knowledge
developed
while
performing
the

<!-- page 20 -->

17.

30

3

3.16

EY

18.

31

3

3.19

EY

copyright, including the
right to modify and or
make any alterations to the
Works and all the above
rights shall not lapse even
if such rights are not
exercised by the DoCA
during the terms of the
copyright and the agency
shall be required or obliged
to execute any deeds or
documents, as may be
required or considered
necessary, by the DoCA to
give effect to and secure
the above mentioned rights
of the DoCA in the Works.
The agency shall not use or
allow anyone else to use
these
documents
and
without the prior written
permission of the Client
and any such act without
the permission of the
Client shall constitute
violation of Intellectual
Property Rights.
The agency will take all
safety
measures
or
precautions during the
work. Any accident due to
negligence or any other
reason will be to agency
account.
Agency shall not disclose

Services), and in any
working papers that the
agency
compiles
and
retains in connection with
the Services (but not
information provided by
DoCA reflected in them).
Any information, advice,
recommendations or other
content of any reports,
presentations or other
communications
the
agency provides under this
Agreement
(“Reports”),
other than information
provided by DoCA, are for
DoCA's internal use only
(consistent
with
the
purpose of the particular
Services)
including
DoCA's officials and not
for disclosure externally
outside
DoCA’s
organization.

Request for holding
agency accountable only
for accident caused due
to agency’s negligence.

The agency will take all It has been agreed
safety
measures
or
precautions during the
work. Any accident due to
negligence of the agency
will be to agency account.

Request to amend the Agency shall not disclose The request of the firm

<!-- page 21 -->

to any third party, any section to read as the
information,
data, following
suggestion
documents, findings, etc. at please.
any time either in whole or
in part, shall use all
reasonable
efforts
to
preserve the secrecy of the
above information and
shall not use the same for
any other purpose.
19.

34

3

3.26.2.5 (b)

EY

20.

58

Annexure
II

S. No 16

EY

If the selected Contractor
or
Agency
fails
to
complete the assignment,
within the period specified
under the contract, the
Contractor or Agency shall
pay to the DoCA, fixed and
agreed liquidated damages,
and not as penalty, @ 1 %
of the contract fees for
each 01 (week) of delay or
part thereof. The aggregate
maximum of liquidated
damages payable to the
DoCA under this clause
shall be subject to a
maximum of 50 % of the
total contract fees.
Submission of Initiated Bid
Documents under check
list of documents to be
submitted with the bid
(TECHNICAL COVER 1)

Request for reduction in
the amount of maximum
liquidated
damages
payable to the DoCA in
case of default.

Request for clarification

to any third party, any
information,
data,
documents, findings, etc.
provided by the client to
the agency at any time
either in whole or in part,
shall use all reasonable
efforts to preserve the
secrecy of the above
information and shall not
use the same for any other
purpose.
The aggregate maximum of
liquidated
damages
payable to the DoCA under
this clause shall be subject
to a maximum of 5% of the
total contract fees.

has not been agreed to.

The aggregate maximum
of liquidated damages
payable to the DoCA
under this clause shall
be
subject
to
a
maximum of 10% of the
total contract fees.

Please
specify
the This has already been
documents to be enclosed specified in the RFP
as initiated bid document document.
with the bid

<!-- page 22 -->

21.

58

Annexure
II

S. No 20

EY

Submission
of
Team
Details (Form 14) under
check list of documents to
be submitted with the bid
(TECHNICAL COVER 1)

Request for clarification
as it is repetitive in
nature with Clause 4.4
(eligibility criteria –
serial no. 9) on Page 44.

The
requirement
of There is no repetition.
submitting Form 14 may
be deleted from one place
as it is in repetition.

<!-- page 23 -->

S.
No

Page No.

Clause
No.

1.

43

4.4

2.

10

2

Query
raised
by
Administrative
Staff College of
India

RFP Statement

Query

Response of DoCA

The average annual turnover of the
Agency from Consultancy
Assignments During the Last 3 FY,
ending on 31st March 2022, shall not
be less than 30 Crores.

The average annual turnover of Not Accepted
the Agency from Consultancy
Assignments During the Last 3
FY, ending on 31st March 2022,
shall not be less than 20 Crores.

Administrative
Staff College of
India

Last date of Submission of bids is To request a date extension for
17th October 2023,
bid submission to 1 to 2 weeks
1500 Hrs
of time.

The date for bid submission has
been extended till 26th October,
1500 Hrs.
