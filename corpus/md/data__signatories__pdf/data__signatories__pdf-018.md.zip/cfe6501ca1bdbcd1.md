---
doc_id: "cfe6501ca1bdbcd1"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/0703b285dca5edb835faa486548f897d.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "GPF Sanction"
date: "2025-07-02"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3896a7c24d5ba39a"
---

<!-- page 1 -->

Form3
Pro forma

A

for sanction of advance from Provident Funds

PGs - disecesccar
tes cnensswebome
MINISEY Of... 0csisissansnen
To
Accounts Officer

Sir,

I am directed to convey sanction of the Competent Authority underrRule ................ of
the General Provident Fund (Civil Services) Rules, 1960/Contributory Provident Fund Rules
(India), 1962.0... cece
eee eee ees to the advance of a sum of 2

CRUSE

& snew evi siiseereminine only) by Shri oo...

cece eee eee eee (name and designation) from

his Account No. ...........:.:seeeeeeeeeee
en ees to enable him to meet the expenditure on ................
Z.
The advance will be recovered in
. monthly instalments of & ......... each,
commencing from the salary for the month of ................... PaVADIS TO sass si vewswwaccnes
cose ewan
3.
A sum of @....... (Rupees
sanctioned in
below. This amount together with the advance now sanctioned aggregating to =
be recovered in .... monthly instalments of @......... each, commencing from the salary for the
PROUT OF cas vs swaacinnncwnca
«5 ule ES. Dw ccceceessasednaxscmmesenem
4.
The-Dalance.at the credit Of Shri... ssmasiscsesane BG. OT paacsaaww.es
sacs is detailed below:(i) . Balance as per account slip for the year
4
(ii) | Subsequent deposits and refunds of advance
.
at the rate p.m. from .................08. Bardeen
news somes
z
(iii)
Total of Col. Gi) and Gi)
z
(iv)
Subsequent withdrawals and advances if any
<
(v)
Balance as on gate of sanction Col. (ili) — (iv)
4
I
camera

This
EE

ee

issues. with
the
conciifreneé
Of .......5; .assessnawssisanwonenees
ESI ly p= ¢ « ah o> me , dated 2...
cece cece eeee eee ees

vide

Dy

Sanctioning authority
Copy forwarded to:
1.
Drawing and Disbursing Officer.
ps
Shri/Smt.j/Km .........c:ccceee
eee eeeeeee cence es His/her attention is drawn to the provisions of
the Rule 12 of GPF (CS) /CPS (India) Rules and requested that a certificate to the effect that the
advance sanctioned above has been utilized for the purpose for which it has been sanctioned
may, therefore, please be furnished within three months of the disbursement of the money.
2
Sanction File.
4.
Pay and Account Office
