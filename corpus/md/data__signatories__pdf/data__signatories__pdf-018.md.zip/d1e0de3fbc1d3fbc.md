---
doc_id: "d1e0de3fbc1d3fbc"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/af772b553b9256e6a7595dd0adaba432.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Tender-Installation,Testing & Commissioning(I/ T/ C) of 36 Watts LED (2 X 2 Recessed Type) ceiling light fittings with buy back of existing old 2 X 36 Watts CFL ceiling Light fittings (Recessed type 2X2) with Inductive/ Electronic Ballasts"
date: "2018-12-19"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7a4b8d44b86f768f"
---

<!-- page 1 -->

Government of India
Ministry of Science and Technology
Department of Science and Technology
Administration II (B) Section
Technology Bhavan, New Mehrauli Road
New Delhi-110 016
T E No. D-13016/1/3/2015 Admn II (B) Part II
To,

Date: 19 Dec., 2018

All the interested and eligible firms

Sub: Tender Enquiry for Installation, Testing & Commissioning (I/ T/ C) of 36 Watts LED (2’ X
2’ Recessed Type) ceiling light fittings with buy back of existing old 2 X 36 Watts CFL
ceiling Light fittings (Recessed type 2’X 2’) with Inductive/ Electronic Ballasts
in DST, Technology Bhavan, New Delhi -16
Dear Sirs,
For and on behalf of the President of India, sealed limited tenders are invited from all
eligible and interested firms holding valid electrical Licence for Installation, Testing & Commissioning (I/ T/
C) of 36 Watts LED (2’ X 2’ Recessed Type) ceiling light fittings with buy back of existing old 2 X 36 Watts
CFL ceiling Light fittings (Recessed type 2’X 2’) with Inductive/ Electronic Ballasts in DST, Technology
Bhavan, New Delhi -16 as per requirements given in the Schedule I to this document.
2.
In case your firm is interested in the above said work, you are requested to quote your lowest
prices in the enclosed Schedule I in a sealed cover. The sealed cover containing the quotation should be
super scribed “Quotation for Installation, Testing & Commissioning (I/ T/ C) of 36 Watts LED
(2’ X 2’ Recessed Type) ceiling light fittings with buy back of existing old 2 X 36 Watts CFL
ceiling Light fittings (Recessed type 2’X 2’) with Inductive/ Electronic Ballasts in DST,
Technology Bhavan, New Delhi -16 ” and should be dropped in the tender box kept near the Reception
of the Technology Bhavan on or before the 08 Jan., 2019 latest by 1500 hours, which will be opened
on the same day at 1530 hrs in Raman Auditorium (Seminar Hall), S & T Block II in the presence of such
tenderers who wish to be present. The Department reserves the right to accept or reject any quotation/
estimates without assigning any reason thereof.
3.
The sealed envelope must be accompanied by a Demand Draft/ Pay order/ banker’s cheque of a
Nationalized Bank in favour of DDO, DST for Rs.15,000/- (Rupees Fifteen Thousand only) as earnest money
deposit. The earnest money amount will be returned to the unsuccessful firm immediately after the award
of the contract to successful bidders and the earnest money of the successful tenderer will be returned only
after completion of the work to the satisfaction of the Purchaser. The bids received not fulfilling the
eligibility requirement for participation in the tendering process, will be rejected straightway and no
representation in this regard will be entertained by the Department.
4.
Tendering firms fulfilling the eligibility requirement for participation in the Tendering Process in this
tender document are requested to quote their competitive lowest prices as per the requirements given in
the attached schedule I.
Yours faithfully,
(Himanshu Gandhi)
Under Secretary to the Govt of India
Tel: 26590264

<!-- page 2 -->

IMPORTANT
INFORMATION
& GENERAL INSTRUCTIONS
1.
2.
3.

4.
5.
6.

7.

8.

10.

Purchaser
Single bid system
Firm and fixed rates

THE PRESIDENT OF INDIA
This tender will be processed in single bid system
Prices should be quoted on a firm & fixed price basis. The prices/rates
quoted should be indicated in words as well as in figures and in INR only.
Request for enhancement of contracted rates shall not be considered under
any circumstances. Tenders with variable prices or seeking provision for
enhancement of prices/contracted rates shall be rejected straightaway
without any consideration.
Non-transferability
This tender is non-transferable.
Terms & conditions
Terms & Conditions as set out in this Tender Document shall have to be
complied with by the tendering firm. Offers not complying with such terms
& conditions shall be ignored/ rejected at the discretion of this Department.
Earnest
Money The requisite amount has to be submitted by way of Demand Draft, Pay
Deposit
Order/Banker’s Cheque along with the original copy of the tender submitted
by the firm in the name of DDO, DST, New Delhi. Payment by any other
mode shall not be acceptable. Offers received without EMD shall be
rejected and will not be considered under any circumstances. EMD of
tendering firms who submit the sealed quotation but withdraw the same
before expiry of the tender validity date may be forfeited. No firm is
exempted from submission of EMD.
Performance Security Successful bidders who are awarded the work order for carrying out the
jobs on the basis of this Tender Enquiry shall be required to furnish a
Performance Security for a period of six months (Warranty period) of an
amount equal to 5% of the awarded cost of the contract (excluding
statutory duties and taxes) in the form of DD/ Pay order, Banker’s Cheque,
Fixed Deposit Receipt (FDR) or Bank Guarantee from any Nationalized
Indian Bank within 15 days of the award of the Contract for a period of Six
months. The format for such Performance Bank Guarantee (PBG) will be
provided by DST along with the work order. In the event of failure on the
part of the successful bidder awarded the Contract to furnish Performance
Security, EMD furnished with the Tender by such firm shall stand forfeited.
The Performance Security should be made in favour of DDO, DST, New
Delhi. No firm is exempted from submission of Performance Security.
Prescribed Forms
Tenders of firms received in the format prescribed in this tender document
shall only be considered. Offers not received in prescribed format shall be
ignored and no correspondence in this regard will be entertained.
Telegraphic/ Telex/ Fax/ E-mail/ Letterhead/ Quotations will not be
accepted and rejected without assigning any reasons.
Late/ delayed tenders Tenders received late/ delayed after prescribed closing time due to any
reason whatsoever will not be accepted under any circumstances. In the
event of any confusion, the time set in the clock in the room of Under
Secretary (Admn.II-B) will be taken as standard and decisive. Tenderers
may note that if the date of tender opening given in this Tender Document
is declared a closed holiday by the Central Government, the tender shall be
opened on the next working day at the same timing. In such an event the
closing hours for receipt of tenders in DST will stand automatically extended
up to 1500 hours of the next working day in the Central Government
offices.

Signature of the bidder

Cont’d….02/-

<!-- page 3 -->

-0211
12

13

14

15

16

17
18
19
20

Purchaser’s right

Purchaser reserves the right to reject any tender/all tenders in full or part
thereof without assigning any reasons.
Scope of work
i.
The 36 Watts (2’X 2’ Recessed Type) LED ceiling Lights will be
supplied by DST.
ii. The date of fitment should be written on the LED Tube Lights with
indelible ink pen (Permanent Marker).
iii. Dismantling of old 2 X 36 Watts (2’X 2’ Recessed Type) CFL ceiling
tube light fittings with inductive/ electronic ballasts.
iv. Modifications of electrical connections for fitment of new LED ceiling
Lights.
v. Fitment of LED Tube Lights, testing & commissioning including
hanging with metallic chains.
vi. Buy Back of old & dismantled 2 X 36 Watts (2’X 2’ Recessed Type) CFL
Ceiling Light fittings with Inductive/ electronic ballasts irrespective of
serviceable or unserviceable one.
vii. During execution of work any false ceiling area is damaged/ deformed,
shall be made good by the contractor to the satisfaction of the Department
without any extra charge/ cost.
Duties & Taxes
Tenderers are requested to enclose a copy of their valid sales tax
certificate/ GST registration number.
GST (Service Tax): Tenderers should indicate in their Bid whether the
prices quoted are exclusive or inclusive of GST. They should indicate the rate
of GST as per applicable rate.
Eligibility
for
i.
The Proprietor of the firm should be Indian National (Attach Copy
participation in the
AAdhaar Card/ EPIC.)
Tendering Process
ii. Should be Registered with GST (Attach GST Registration
Certificate).
iii. Should be Registered with Tax Department (Attach Copy of PAN).
iv. Should be in possession of a Valid Electrical Licence (Attach Copy).
v. Submission of EMD of requisite amount of EMD in prescribed form.
Purchaser’s Address The quotation should be addressed to “Under Secretary, Admin II (B)
Section, Department of Science & Technology, Technology Bhavan, New
Mehrauli Road, New Delhi-16 and should be dropped in the Tender Box of
Admn. II B Section kept near Reception Room at the entrance of
Technology Bhavan, New Mehrauli Road, New Delhi on or before at
1500 hours on 08 Jan., 2019. In case the sealed envelope is larger
than the mouth of the Tender Box, and cannot be dropped in the Tender
Box, the same may be submitted by hand to Under Secretary, Admn.II B
or S.O. Admn II B, DST.
Earnest Money
Firms shall be required to deposit Earnest Money of Rs.15,000/-. Offers
received without Earnest Money or with Earnest Money lower than the
amount specified will be liable to be summarily ignored. Tenders received
not in conformity with the EMD guidelines instructions/ conditions in the
Tender Enquiry would be liable to be ignored summarily.
Inspecting Officer
Authorized representative of DST, New Delhi
Inspection Authority Department of Science and Technology (DST), Technology Bhavan, New
Delhi or any party, a Govt. agency, so authorized by DST.
Work site
Department of Science & Technology, Technology Bhavan, New Mehrauli
Road, New Delhi-110016.
Job
Execution Within 45 days of the receipt of confirmed work order by the firm.
period

Signature of the bidder

Cont’d….03/-

<!-- page 4 -->

-0321
22
23
24

25
26

Payments Terms

100% payment shall be released on successful execution of the work
complete with installation & commissioning of the equipment, accessories
at site. Advance payment will not be made under any circumstances.
Paying Authority
Controller of Accounts or his authorized representative, Pay & Accounts
Office, DST, New Delhi-110016
Evaluation of bid & Item-wise prices should be quoted. For award of contract, the net
Acceptance of offer
bundled price of the schedule will be considered.
Warranty
Six months comprehensive from the date of completion of job. Any
complaint shall be attended within a response time of 48 hours on 24X7
basis. Any defects in workmanship or detoriation in the quality or
deviation to tender specifications coming to notice shall be rectified at site
within 72 hours of the reporting of the same to the contractor. If system
is required to be picked up and taken to your premises for removing the
defects, the same shall be picked up from the consignee latest by the next
working day and dropped back to the consignee within 07 working days.
Any component required to be replaced within the warranty period shall be
totally a new component and not reconditioned or repaired component.
Validity of offer
Up to 90 days from the date of opening of the bid.
Mandatory
The mandatory Information as given at Annexure I should be filled up in
Information
all respect and submitted with supporting documents. Bids received and
found deficient in any respect are liable to be rejected without further
correspondence.

Signature of the bidder

<!-- page 5 -->

Annexure I
Department of Science & Technology
Admin II (B) Section
Contractor’s details: Mandatory Information, if not filled, the bid will be rejected straightway.

Supporting documents be annexed with the application form (Applications found deficient in any
respect are liable to be rejected without further correspondence)
Sl
No.
01
02
03

Description

Information

Name of the Applicant/ Firm
Nationality
Address
(attach separate paper for
addresses of other offices)

Regd. Office
Head office

04

05
06

07

Telephone Numbers

Landline No.
Mobile No.
Fax No.
E-mail address
Other Details
PAN Details
GST Registration Number
Constitution
Individual
Sole
Proprietorship
Concern
Partnership Firm
Public Ltd. Company
Private Ltd. Company/
Public Sector Enterprises
Is
the
Individual/
sole Dismissed
Government
Proprietor/ any Partner of the Servant
Firm/ Director of Company
Removed from approved
list of contractors
Demoted to a lower class
of contractors in CPWD/
PWDs
Convicted by a court of law

yes

No

Yes

No

Yes

No

Yes

No

Official of Govt of India Yes
No
retired within last one year
Director or partner of any Yes
No
other company/ firm with
CPWD/ PWDs or any other
Govt Department
Member of Parliament or Yes
No
any
State
Legislative
Assembly
If answer to any of the above is “Yes”, furnish details on a
separate sheet
Signature of the bidder
Cont'd….02/-

<!-- page 6 -->

-02-

Sl
No.
08

09
10

11

12

Description

Information

Applying firm should be in
possession of a valid electrical
Licence (Attach certified copy)
is manufacturer/ Authorized
Name of the Bankers with full
details/ orders
Earnest Money Deposit Details a.

Amount in Rs. 15,000/- (Rupees Fifteen Thousand only)

b.

DD/ BC/ PO No.

c.

Date of Issue: -

d.

Name of issuing Bank: -

e.

Address of the issuing Branch: -

Is any person working with the
applicant a near relative of the
official of DST? If yes, give
details
Certificates
a)
I/ we (including all partners) certify that I/ we have read the
Terms & Conditions mentioned in the tender enquiry form and
shall abide by them
b)
I/ we certify that the information given is true to the best of
my/ our knowledge. I/ we also understand that if any of the
information is found wrong/ false at any stage. I/ we are
liable to be deregistered from panel of approved contractors/
banned for doing any business dealings with Government
Departments or blacklisted or subject to any monetary
penalties that be deemed fit and appropriate by DST/
Government.

Signature of the bidder

<!-- page 7 -->

Schedule I
(Refer Para No.1 of Tender Enquiry Notice)
Department of Science & Technology
Scope of work, specifications, location (s), design, quantity and quality parameters
etc. for Installation, Testing & Commissioning (I/ T/ C) of 36 Watts LED (2’ X 2’ Recessed

Type) ceiling light fittings with buy back of existing old 2 X 36 Watts CFL ceiling Light fittings
(Recessed type 2’X 2’) with Inductive/ Electronic Ballasts
in DST, Technology Bhavan, New Delhi -16

A.
Location: Department of Science & Technology, Technology Bhavan, New
Mehrauli Road, New Delhi-110016
B.
Scope of work: As mentioned at Sl No.12 of Important Information & General
Instructions
Schedule of works & abstract of cost for Installation, Testing & Commissioning (I/ T/ C) of 32
Watts LED (2’ X 2’ Recessed Type) ceiling light fittings with buy back of old 2 X 36 Watts CFL
ceiling Light fittings (Recessed type 2’X 2’) with Inductive/ Electronic Ballasts in DST,
Technology Bhavan, New Delhi -16

Sl
Description of Stores
No.

04

Rate
Qty
in Rs.
per
Unit
Dismantling of old 2X 36 Watts (2’X 2’ Recessed Type) CFL Each
715
ceiling light fittings with inductive/ electronic ballast and
Installation, Testing & Commissioning (I/ T/ C) of 36 Watts
LED ceiling Lights (2 ‘X 2’ Recessed Type) in the existing
location including wire, insulation tape, hanging metallic
chains and other items if necessary for functioning of the
light.
Buy Back offer
Existing old & dismantled 2 X 36 Watts (2’X 2’ Recessed Each
715
Type) CFL ceiling light fittings with inductive/ electronic
ballast irrespective of serviceable or unserviceable one
Total bundled price exclusive taxes etc. (Sl No.1
Minus Sl No.2 above)
GST on Sl No.3 above

05

Total bundled price inclusive of taxes etc.

01

02
03

Unit

Amount
in Rs.

*** Note: All the Numbers may vary and in case of variation, the quantity will be calculated on
actuals after execution of work.
Signature of bidder
