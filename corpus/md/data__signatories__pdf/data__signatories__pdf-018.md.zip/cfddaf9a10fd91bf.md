---
doc_id: "cfddaf9a10fd91bf"
source_url: "https://www.dot.gov.in/static/uploads/2026/02/0d57d445431a9eaf03e952d7bb25b74a.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "78 Provisioning of telecommunication services by the licensees through Franchisee, Agents and Distributors - Point of Sale"
date: "2023-08-31"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f2b4010a3ebee754"
---

<!-- page 1 -->

Provisioning of telecommunication services by the licensees through
Franchisee, Agents and Distributors {Point of Sale (PoS)}.

As

Page 1

of4

Clause 39.17(i) of Part-I of UL, inter-alia states that, “The Licensee shall ensure adequate
verification of each and every customer before enrolling him as a subscriber; instructions issued
by the Licensor in this regard from time to time shall be scrupulously followed.”

security of the nation.”

Clause 6.2 of Part-I of UL, inter-alia, states that, “The Licensor shall have the right to direct the
Licensee to warn, penalize or terminate the services of the franchisee or agent or distributor or
employee (servant), after considering any report of conduct or antecedents detrimental to the

“Clause 6.1 of Part-I of UL, inter-alia, states that, “For provision of the service by the Licensee,
the Licensee may appoint or employ franchisee, agents, distributors and employees.”

3.

The relevant conditions in Unified License (UL) for provisioning of services by the
licensee through PoS are as follows:

through PoS.

2.

per the licensing provisions, the licensee may appoint franchisee, agents and
distributors {hereinafter individually as well as collectively referred as ‘Point of Sale (PoS)’}
for provision of services permitted to them under their respective authorizations/ licenses.
Accordingly, it has been decided to regulate the provisioning of services by the licensees

With increasing digitalization of social-economic activities in the country, the use of
telecom resources, including mobile services, is increasing rapidly for availing the online
services. It has come to the notice that sometimes mobile connections, obtained by
fraudsters in connivance with Point of Sale (PoS), are being misused to commit cybercrime/
frauds.

Subject:

<!-- page 2 -->

Each licensee shall ensure indisputable verification of each and every PoS before

8.

Page 2

of4

After indisputable identification of PoS through above mentioned information and
documents, the licensee shall also authenticate PoS (the authorized signatory or person who
is entering into agreement with the licensee) using biometrics which includes facial, finger

7.

Ifdocuments mentioned at 6(a), (c), & (d) are not available with the PoS on the date of
identification by licensee, then affidavit shall be obtained from PoS about non-availability of
the same on that particular date. As and when these documents become available, PoS shall
submit such documents to the licensee immediately.

permitting them to enroll the customers. For this purpose, the licensee shall obtain following
documents and information from PoS: a. Corporate Identity Number (CIN), Limited Liability Partnership Identification
Number (LLPIN) or Business License, or trade/ Registration Number, or
Incorporation Certificate or Certificate issued by authorities
b. Aadhaar or Passport of the authorized signatory or person who is entering into
agreement with the licensee. (mandatory)
c. Permanent Account Number (PAN) of the authorized signatory or person who is
entering into agreement with the licensee
d. Goods & Services Tax (GST) Registration Certificate
e. Unique PoS Identification (PoS ID) number (in case the PoS is already registered
through the process mentioned herein)
f.
Photograph of the authorized signatory or person who is entering into agreement
with the licensee
g. Address ofthe place of business/ working of PoS (mandatory)
h. Local residential address of the authorized signatory or person who is entering into
agreement with the licensee. (mandatory)
i. Any other documents/ information, as deemed fit, for identification of PoS by licensee

6.

separately) before permitting them to enroll the customers.

<!-- page 3 -->

13.

If,

Page 3

of4

any of the information is found false; or documents provided by PoS during
registration is found forged; or directions for termination are received from LEAs/ LSAs, the
agreement with such PoS shall be terminated and PoS ID shall also be blocked within
24 hours of such acknowledgement. All licensees shall ensure that such PoS shall not be able

The licensee shall also maintain an online supply-chain management system of SIM
12.
cards which shall be updated on real time basis by each PoS and employee of the licensee. It
shall include SIM number - MSISDN relationship also. A complete trail about all the
movement of SIM cards i.e., from origination till it reaches to the customers, shall be provided
to the LEAs or licensor, as and when sought by them.

After signing of the agreement(s), if the existing PoS ID is not available, then the
11.
licensee shall assign a new unique ‘PoS ID’ to PoS which shall be unique for all the licensees
across all the LSAs. Only after allocation of PoS ID, the licensee shall allow PoS to enroll
customers as per their written agreement and also intimate the same to the concerned LSA
unit. The unique PoS ID shall be made available by all the licensees across all the LSAs on real
time basis. It is the joint responsibility of all the Licensees to develop a system and
mechanism for generation and sharing of unique PoS ID on real time basis.

The licensee shall ensure that a PoS shall not delegate any of its activity (i.e. scope,
10.
roles, duties and responsibilities etc.) exercised under the written agreement to any other
person (natural or otherwise).

the written agreement(s) signed with the licensee. However, in case of J&K, Assam and North
East LSAs, existing guidelines of police verification shall be followed before signing the
written agreement with PoS(s). The written agreement(s) shall also have specific provisions
relating to enrolment of customers, scope and duties of a PoS (i.e., enrolment of new
customer, requests for SIM change, SIM up-gradation, recharge/ billing, and MNP etc.), area
of operations of PoS (limited within LSA), penal actions for violations including termination
of agreement(s) etc.

<!-- page 4 -->

DG (T), DoT HQ, New Delhi- for circulation among LSA units and also strict monitoring

Page 4 of 4

and compliance of these instructions.
CEO, UIDAI- for kind information.
wnN
Secretary, TRAI- for kind information.
DDG (SA), DDG (AI&DIU) DoT HQ- for kind information and necessary action please.
ar
JS (CIS), MHA-for kind information and necessary action please.

1.

Copy to:

ADG (AS-II)

Lum
uth
(Suresh Kumar)

17. A complete database containing details of new and existing PoS registered by the
licensee as per these instructions may also be shared with LSAs/ LEAs in real-time manner.

16.
Incase, ifa Licensee appoints a PoS for doing recharge/ billing activities only and not
for enrolling the customers, then there is no requirement of registration of such PoS as per
these instructions. However, the licensee shall maintain the list of such PoS and provide the
same to LEAs/ LSAs.

15.

These instructions shall be applicable with effect from 01.10.2023. If the licensee(s)
permit any new PoS ie., after 30.09.2023, to enrol customers without registration, then a
financial penalty of Rs. 10 lakh per PoS per instance shall be imposed by concerned LSA on
each licensee. All mobile connections activated through such un-registered PoS shall also be
re-verified as per the existing instructions. In case of all the existing PoS (PoS existing as on
30.09.2023), each existing PoS shall be registered as per these instructions by 30.09.2024.

14, Asmentioned in para 4 above, it is the responsibility of the licensee to ensure adequate
verification of customers before enrolling them as subscribers and activating their mobile
connections. Accordingly, the licensees shall use suitable advanced IT tools to detect any
unusual/ suspected activities of PoS/ customer, if done by them, so that purpose of adequate
verification of customers and bonafide usage of mobile connections shall not be defeated.
