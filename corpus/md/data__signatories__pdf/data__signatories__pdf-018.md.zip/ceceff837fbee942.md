---
doc_id: "ceceff837fbee942"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_6a755d910adff9.73367720.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Office Order - The additional charge of Director, Directorate of Forest Education, Dehradun is hereby assigned to Shri N.C. Saravanan, IFS (AGMUT:2002), Additional Director, Indira Gandhi National Forest Academy, Dehradun, order dated 23-07-2026."
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b7ba8f7692033527"
---

<!-- page 1 -->

No. 12016/05/2021-IFS.I-Part (1) [E. 285832]
Government of India
Ministry of Environment, Forest and Climate Change
(IFS-I Section)
6! Floor, Prithvi Wing,
Indira Paryavaran Bhawan,
Jor Bagh Road, New eo
Date:__“s\—_ July, 2026.
OFFICE ORDER
In supersession of Office Order of even number dated 19.06.2026, the
additional charge of Director, Directorate of Forest Education, Dehradun is hereby
assigned to Shri N.C. Saravanan, IFS (AGMUT:2002), Additional Director, Indira
Gandhi National Forest Academy, Dehradun with immediate effect and till further
orders or till the joining of new incumbent, which ever is earlier.
2. This issues with approval of the Competent Authority, vv
(बरी At Ww
aA <a
(Pre akash Maurya)
Deputy Secretary to the Govt. of India
Tele. No.: 011-2081 9192
Distribution:
i. PS to Hon'ble Minister of Environment, Forest and Climate Change;
ii. PS to Hon'ble Minister of State Environment, Forest and Climate Change;
iii. PPS to Secretary, MoEF&CC;
iv. PPSs to DGF & SS’ ADGF(WL)/ ADGF(FC)/ ADGF (PT)/ CEO (CAMPA);
v. PSs to All IGFs/ JSs/ Jt, CEO(CAMPA);
vi. The Director, IGNFA, Dehradun;
vii. All DIGFs/ AIGFs;
viii. Concerned officers;
ix. All Regional Offices/RO(HQ);
x. NIC cell for uploading on website;
xi. Reference Folder.
