---
doc_id: "cf715ad24bbbfda0"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/d6e6151b9cacd76d67d0c2afa3e0392b.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code '14407' - Cyber Crime Helpline"
date: "2018-09-14"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3e5f4dc0e55313e2"
---

<!-- page 1 -->

File No.16-3/2013-AS·lll

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No.16-3/2013/AS-III/383!/®f

Dated: l.':\109/2018

To,
All Access Service Providers.

Subject: Allocation of short code '14407' to Criminal Investigation Department, West
Bengal Police regarding.
The undersigned is directed to convey the approval for allocation of short code '14407'
to Criminal Investigation Department, West Bengal Police for Cybercrime helpline with
features as:
(i) Category-I: Service (i.e. mandatory service to be provided by all the Access .
providers.
(ii) Accessibility: Un-restricted i.e. available on STD also.
(iii) Metered service: Calling party pays.

2.

All are requested to take necessary action.

3.

This is issued with the approval ofDDG (AS-I).

Copy forwarded for information and necessary action, if any, to:
Secretary, TRAI.
2.
CMD MTNL/ CMD BSNL.
3. Dy. Inspector General of Police, Cyber Crime, CID, West Bengal, Criminal
Investigation Department, West Bengal, Bhabani Bhawan, Alipore, Kolkata-700027 w.r.t
your letter dated 30-07-2018, with a request to appoint a nodal officer to implement the
helpline. The Nodal officer may contact Sr. DDG (LSA), LSA Unit, Kolkata.
4.
Director (P&N), DoT (HQ), (respective LSA field unit-Kolkata may be asked to co­
ordinate with respective Nodal Officers and TSPs for implementation of Helpline, as and
when approached).
5. A copy for upload on DoT Website.
1.
