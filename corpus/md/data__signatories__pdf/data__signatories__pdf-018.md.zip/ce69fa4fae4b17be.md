---
doc_id: "ce69fa4fae4b17be"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2026/01/40473d52f9ad8c027f1093eaefeca1d5.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Annual Immoveable Property Return (IPR) Submission"
date: "2026-01-01"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "37aa2ad4589c17c1"
---

<!-- page 1 -->

File No.A4501 1/1/2019.CHSVl

No.A4501 1/01/2019-CHS vl

By Speed Post

Government of India
Ministry of Health and Family Welfare
(CHS Division)
Nirman Bhawan, Ne\tr Delhi- 1 1OO0l 1
Dated 2{d January, 2019
Offlce Memorandum
Sub: Annual lmmoveable Property Return (IPR) submission-reg.

The undersigned is diiected to refer to tlis Ministry's oM No
A3201214/ 2016 -CHS III dated 15.12.2018 (copy enclosed) on tl1e above
mentioned subject and to say that Annual Immoveable Property Returns
(lPR) in respect of a large number of CHS ald Dental doctors working under
Ministry of Health and Family Welfare have not been received till date. The
officers concerned are informed that non-submission of IPR within stipulated
period of time would invite the denial of vigilance clearance for confirmation,
empanelment, deputation, applying to sensitive/higher posts and
assignment to training prograrnme (except mandatory training) foreign visits
etc. as the IPR status needs to be checked for ttre said purposes.

2.

All CHS and Dental doctors working under this Ministry are tJrerefore
requested to submit their Annual IPRS for the year 2018 i.e. as on
31.12.2018 latest by 31.01.2019. Annual IPRS submitted aJter 31.01.2019
will not be considered for a]:ly of the purposes as referred in Para 1 above.
The said IPRS may also be furnished by the offrcers concemed at the
following e-mail ids.
(i) sochs2-mohfir@gov.in (CDMO sub-cadre)
(ii) chs3-mohfi^@ric.in (Teaching and Public Health sub-cadre)
(iii) sochs4-mohtu@gov.in (Non-Teaching sub-cadre)
(iv) chs6healthministry@gmail.com (Dental doctors)

3.

Heads of all participating units are requcsted that the contents of this
oM may be widety circulated for information of all concerned.stgnatuo
u"rirt

:i,:"rry!Fs;ru"
(Sarita Nan)
Under Secretary to t}le Govt of India
elefax. No. 2306306a

to

i. All Participating units of CHS (At 1. 1 \'t"x"'e1)
