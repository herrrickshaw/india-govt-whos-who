---
doc_id: "cef21dc6ecbc0c69"
source_url: "https://shipmin.gov.in/sites/default/files/CMO%20Circular%202023_Ministry.pdf"
ministry: "Ports, Shipping and Waterways (MoPSW)"
title: "CMO Circular 2023_Ministry.pdf"
date: ""
pages: 15
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "c357609f2891fe38"
---

<!-- page 1 -->

wH/Phone: 91-22-6656 5656 ED सामान्य प्रशासन विभाग
¢4e/Email: secretary@mumbaiport.gov.in (Ce es
"-3aqs'e/Website:www.mumbaiport.gov.in ons cad Mar 0001
मुंबई Baa wiser शूरजी वल्लभदास मार्ग, बेलार्ड इस्टेट,
Mumbai Port Authority मुंबई - 400 001.
>> eR Larue has General Administration
ou च awe 1 @ Department,
SAGARMALA Mtr लि \ | ey) &) Port House, 24 floor,
oon S.V. Marg, Ballard Estate,
MUMBAI - 400 001.
No.GAD/P/RECT-CMO/ May, 2023
Recruitment Notice
The Chairperson
All Major Port Authorities
Sir/ Madam,
Sub: Filling up the post of Chief Medical Officer
(HoD) by absorption through composite
method in Mumbai Port Authority.
Vacancy will occur in the post of Chief Medical Officer (HoD) in Mumbai

Port Authority on 18.8.2023. The post is in the pay scale of Rs.100000-260000 (pre-
revised Rs.43200-66000/ Rs.18500-23900). The post is to be filled by absorption
through composite method from officers of Major Port Authorities, fulfilling the
eligibility criteria as per Annexure - I.
9. The selection is by merit for which overall grading in the APARs should not be
below “Very Good”.
3. The incumbent will be initially appointed to the HoD post in the scale of pay of
Rs, 100000-260000 (pre-revised Rs.43200-66000/ Rs.18500-23900) and after
completion of three years’ regular service in the post, he/ she will be elevated to the
scale of pay of Rs.120000-280000 (pre-revised Rs.51300-73000/ Rs.20500-26500)
subject to fulfilling the relevant conditions as per the Ministry’s guidelines vide letter
dated 19.11.2019. It may be noted that any changes as directed by the Ministry from
time to time, will automatically be made applicable.
4.1 Applications are invited from cligible and willing officers of all the Major
Port Authorities possessing the prescribed qualifications, experience and other
conditions, for the post of Chief Medical Officer in the pay scale of Rs.100000-
260000 as per Annexure-I. The application may be submitted through
“Online Application Portal (OAP)” of the Ministry of Ports, Shipping and
Waterways website http://onlinevacancy.shipmin.nic.in from 11.5.2023 to
12.6.2023. No application other than OAP shall be accepted.
4.2 The candidate will have to submit the printout of application form
already uploaded in OAP to his administrative Port for onward forwarding.

<!-- page 2 -->

The administrative Ports are required to forward the applications of the
candidates alongwith the following documents on or before 27.6.2023
superscribing “Application for the post of Chief Medical Officer in
Mumbai Port Authority”:

@ certified copies of APARs for the last 5 years (1.4.2017 to
31.3.2022), duly attested by an officer not below the rank of Dy.
HOD on each of the pages;

(ii) a statement showing year-wise availability of APARs and grading
duly signed by the Dy. Chairperson/ Chairperson as per the
Ministry's letter dated 1.2.2007. If APAR for a particular year
during the last 5 years is not available, "No Report Certificate"
may be furnished alongwith APARs of the preceding years;

(ii) attested photocopies of all certificates and proof of educational
qualification, present and past work experience in the respective
post and pay scale.

(iv) No Objection Certificate from the respective Port.

(५) Undertaking of the applicant to the effect that candidature will
not be withdrawn, if selected by Services Selection Committee;
and

(vi) Vigilance and Administrative clearance of the concerned Port, as
per enclosed proforma (Annexure ~II).

(vii) Two passport size photographs.

5.1 As per the Ministry’s guidelines dated 26.9.2019, in case of receipt of
advance copy of application in respect of any applicant by the Port, candidature
of the candidate will not be considered by the Ministry if his application is not
received through proper channel by the Port within 15 days of the last date
of receipt of applications.
5.2 Further, the Ministry vide letter dated 20.9.2022 has issued the
advisory in continuation to its earlier guidelines dated 26.9.2019 regarding
fillimg up the HOD level posts in Major Port Authorities wherein it is inter-
alia stated that-
“In this connection, it is to be clarified that certain documents viz.
obtaining vigilance clearance, APARs of the candidate may take
some time due to administrative formalities. In such scenario, the
ports need to forward the application of the officer with the approval
of the competent authority (i.e. through proper channel) to the port
which has issued advertisement before due date of submission of
application. Such applications through proper channel (even

<!-- page 3 -->

though without APARs, Vigilance etc.) will be taken into
consideration by the Ministry for appointment to HOD level posts,
However, for consideration of candidature of the candidate by the
Selection Committee, the Ports are required to forward the
remaining documents without unnecessary delay.

At various instances, the Ports forward the applications of the
candidates in the last hours. Thus, it becomes impossible for the
applications to reach the Port that issued advertisement before due
date of submission. In such cases, the ports are required to forward
his/her application (through proper channel i.e. forwarding of the
Port alongwith printout of OAP application) via email so that the
candidature of the candidate could be considered for the post.
Subsequently, the complete application of the candidate alongwith
other documents may be forwarded by the Port by registered Post to
the Port that issued advertisement.”

6. The crucial date for eligibility criteria will be the date of arising of
vacancy, ic. 18.8.2023, in terms of Ministry of Shipping's circular No.I-
26/25/2013 PE-I dated 26.9.2019.
% Ifany major or minor penalty has been imposed on the applicant during
the last 10 years, the disciplinary case leading to such penalty alongwith
necessary documents may be sent by the forwarding authority along with the
application. Vigilance report is to be furnished in the format prescribed, vide
Ministry's letter No.A-12023/2/2021-PE-I dated 20.1.2021, copy of which is
attached as Annexure-III.
8. As per the Ministry’s guidelines dated 26.9.2019 regarding filling up the
HoD level posts in Major Port Authorities, Port official, who withdraws his/her
candidature for the post after selection by the Service Selection Committee,
will be liable for debarment from future selection to HOD level posts in all
Major Port Authorities for a period of two years.
9. Incomplete applications or applications not made following the stated
procedure or received after due date will not be considered.

Yours faithfully,

a) —

DA: As above. (Smt. S. G. Patwardhan)

SECRETARY (I/C)

<!-- page 4 -->

No.GAD/P/RECT-CMO/ 225 +
Copy, alongwith accompaniments forwarded to the Secretary to the
Government of India, Ministry of Ports, Shipping & Waterways for
information. Soft copy of the circular is already forwarded on e-mail address:
pravin.s@nic.in and web-ship@gov.in.
(Kind Attn: Shri Sandeep Gupta, Director, PHRD)
(Ref: Your letter Nos. F.No.1-26/9/2013-PE-I dated 17.6.2014 &
A-12023/12/2014-PE-I (pt) dated 19.1.2021)
DA: As above. (Smt. aes
ty SECRETARY (I/C)
4" May, 2023.

<!-- page 5 -->

Agnexvee ©
Sl. [Name of the No. |Classifi- [Scale [Whether |Upper Educational and other [Whether Period [Method of [In case of promotion! Remarks
No. |Post of jeation of Selection |Age limit qualifications prescribed |(a) age lof recruitment absorption/deputation,
i Posts, Pay lor. for direct |for direct recruitment —|(b) educational | Probation |(whether by grades from which it
688.) Non- recruit qualifications —_| (in years) |direct should be made
Selection |ment ((c) experience recruitment
PT = =
recruits will promotion!
apply in the case absorption!
of promotion! deputation)
absorption!
deputation
ie! fass-T]7Rs.100000- [Selection] Bl issential ; 8) No ४.8. |By absorption ‘or absorption
Medical 260000 (tne (b) Yes through through composite
Officer Facet a (G) MBBS degree —_|(c) No composite method, officers holding
Ma sci मन from a recognised method failing |posts in the scale of pay of Rs
he elevated to university, whieh 80000-22000 with three |
the scale of years regular service in the
pay of (ii) A post-graduate by deputation |Medical Department in a
Rs.120000- medical degree and failing both |Major Port ‘Trust shall be
280000 after from a recognised eligible.
aa veas university, by direct
are reeruitment. |For deputation,
: (ii) Post- officer holding
service with qualification analogous posts or
the approval experience of 16 officer holding posts of
lof Central years in a hospital, Chief Medical Officer
Government. and equivalent post
jin Medical Deptt. in scale
lof pay of Re, 18500-23900
(revised Re.100000-260000)
jwith 2 years regular
service in the grade or
officers holding
post of Sr. Dy, Chief
Medical Officer and
equivalent specialist
posts in the scale of pay
lof Rs. 16000-20800 (revised
Rs.80000-220000) and
above in Medical Deptt.
with 5 years regular
service in the grade in
Govt./Semi Govt./PSUs
or Autonomous Bodies
|2 (other than Major Port
Trust) will be eligible.
The Selection
is by merit for which the
bench mark in overall
grading in the ACRs will
not be below
Very Good’,

<!-- page 6 -->

ANNEXURE II

Certificate to be given by Head of Office

Shri/Smt. _ =f ptt

Designation, oan oe tks,

hs It is certified that the particulars furnished by the officer are correct.

2. It is certified that no disciplinary/vigilance case is pending or contemplated
against the applicant and he/she is clear from Vigilance and Administrative
angle.

3. His/ Her integrity is certified.

4. It is certified that no major/minor penalties have been imposed on the applicant
during the last 10 years. If any, kindly indicate details thereof.

5: Attested copies of ACRs for the last five years (1.4.2017 to 31.3.2022) are
enclosed.

6. It is certified that the incumbent meets the requisite eligibility criteria w.r.t.
educational qualification and experience as specified in the Annexure I of the
circular for absorption through composite method. है

SIGNATURE OF THE DY. CHAIRPERSON/
CHAIRPERSON WITH SEAL

<!-- page 7 -->

Format IIT
MUMBAI PORT AUTHORITY
Particulars of ~articulars of the officer for whom Vigilance Comments/Status has been sought officer for whom Vigilance Comments/Status has been sought
enor whom Vigilance Comments/Status has been sought
= Name of Officer Gin full) [is Ree eee eT
2_| Father's name cL eee
3 _|DateofBirth Se vee
4 | Date of Retirement [|
5_| Date of entry into service _ = : cals En
6 | Service to which the officer belongs हू
_| wherever applicable __ i
| Revised Payscale 1. See aie Sl
8 | Whether Annual Property Return (APR) has | : Yes /No
—|beensubmittedintime | Bio snes BAe, awe ts
9_| Date of submission of APR _ Fat eae
aE | the =e Byears) 7 [ aoe
Sl. oe Designation and | Administrative/ From To
No. | (Name in full) | Place of posting | Nodal Ministry/
el ee I tae |! विद, लव Depth | gal whew She eS
11 | Whether any punishment was awarded to the officer during = last | :
10 years and if so, the date ofimposition and details of the penalty.(*) || |
12 | Is any disciplinary / criminal proceedings or Chargeshect pending | :
against the officer as on date (If so, details to be furnished — including
reference number if any of the commission)
13 | Is any action contemplated against the officer as on date (If so details | ;
| 00 व कि या
14 | Whether any complaint with vigilance angle pending against the | :
___Lofficer as on date (Ifyes, details tobe furnished) eel Sa
Date: ——_—_______Gignature of Head of Department) of Head of Department)
=——— ie ead of Department) ||
7 Whether the officer has been placed on the "Agreed List" or oe) of |
! Officers of Doubtful Integrity".(If yes details tobe given) | ii ale
16 | Whether any allegation of misconduct involving vigilance angle was | :
examined against the officer during the last 10 years and if so, with
The applied post being Selection post at the level of Head of Department, the officer is Clear/not clear
from vigilance angle as per the guidelines of DoPT/CVC issued from time to time.
Date: CHIEF VIGILANCE OFFICER
(*) If vigilance clearance had been obtained from the Ministry/CVC in the past, the information may
be provided for the period thereafter.

<!-- page 8 -->

wi/Phone: 91-22-6656 5656 © सामान्य प्रशासन विभाग
¥ic/Email: secretary@mumbaiport.gov.in ey पोर्ट
‘aaate/Website:www.mumbaiport.gov.in ave Sue Pah आय पा
मुंबई Geet ग्राधिकरण शूरजी वल्‍्लभदास मार्ग, बेलार्ड इस्टेट,
Mumbai Port Authority मुंबई - 400 001.
fas Ph a. 57८ ee ~<{| me G Fi. General Administration
7 oe | | 1) , Department,
SASARMALA sere We |" Port House, 24 floor,
i MUMBAI - 400 001.
सं.सा.प्र.वि/पी/भर्ती-मुचिअ/ मई 2023
भर्ती सूचना
अध्यक्ष
सभी महापत्तन प्राधिकरण
महोदय/ महोदया,
विषय : मुंबई पत्तन प्राधिकरण में मिश्रित पद्धति के जरिए समावेशन द्वारा मुख्य
चिकित्सा अधिकारी का (विभाग प्रमुख) पद भरना.
मुंबई पत्तन प्राधिकरण में मुख्य चिकित्सा अधिकारी का पद दि. 18.8.2023 से रिक्त होगा. उसका
वेतनमान रुपये 100000-260000 (पूर्व-संशोधित रुपये 43200-66000/ 18500-23900) है. यह पद
मिश्रित पध्दति के जरिए महा पत्तन प्राधिकरणों से अधिकारियों का समावेश करके भरा जाना है, जिसके लिए
आवश्यक पात्रता मानदंड अनुलग्नक- 1 में है.
2... चयन प्रक्रिया योग्यता के अनुसार होगी, जिसके लिए एपीएआर में समग्र ग्रेडिंग "वेरी गुड" से कम
नहीं होनी चाहिए.
3. दि.19.11.2019 के मंत्रालय के पत्र के दिशा-निर्देशानुसार पदभोगी को शुरु में रुपये 100000-
260000 (पूर्व संशोधित रुपये 43200-66000/ रुपये 18500-23900) के वेतनमान में विभाग प्रमुख के
पद पर नियुक्त किया जायेगा और पद पर तीन वर्ष की नियमित सेवा पूरी होने के बाद संबंधित शर्तों को पूरा
करने के उपरान्त उसे रूपये 120000-280000 (पूर्व संशोधित रुपये 51300-73000/ रुपये 20500-
26500) के वेतनमान पर उन्‍्नयित किया जांएगा. यह ध्यान रखा जाए कि समय-समय पर मंत्रालय द्वारा
निर्देशित किसी भी परिवर्तन को अपने आप लागू किया जाएगा.
4-1. अनुलग्नक-1 के अनुसार रुपये 100000-260000 के वेतनमान में मुख्य चिकित्सा अधिकारी के
पद के लिए निर्धारित योग्यता, अनुभव और अन्य शर्तों के धारक सभी महा पत्तन प्राधिकरणों के पात्र और
इच्छुक अधिकारियों से आवेदन आमंत्रित किए जाते हैं. आवेदन 11.5 -2023 से 12.6.2023
तक पत्तन, पोत परिवहन तथा जलमार्ग मंत्रालय की वेबसाईट http ://onlinevacancy.shipmin.nic.in
के "ऑनलाईन आवेदन पोर्टल (ओएपी)" के माध्यम से प्रस्तुत किया जा सकता है. ओएपी के अलावा कोई भी
आवेदन स्वीकार नहीं किया जाएगा.

<!-- page 9 -->

42 उम्मीदवार को ओएपी में पहले से अपलोड किए गए आवेदन पत्र का प्रिंठआऊट अपने प्रशासनिक
पोर्ट के पास अग्रेषित करने हेतु प्रस्तुत करना होगा. प्रशासनिक पत्तनों को दिनांक 27.6.2023 को या उससे
पहले उम्मीदवारों के आवेदन निम्नलिखित दस्तावेजों के साथ लिफाफे में भरकर लिफाफे पर "मुंबई पत्तन
प्राधिकरण में मुख्य चिकित्सा अधिकारी के पद के लिए आवेदन'' इस प्रकार लिखकर अग्रेषित करने
होंगे: !

(6). पिछले 5 वर्षों की (1.4.2017 से 31.8.2022 तक) वार्षिक निष्पादन मूल्यांकन
रिपोर्टों की प्रमाणित प्रतियाँ, उप विभागप्रमुख स्तर के अधिकारी द्वारा हर एक पन्ने पर
विधिवत प्रमाणित करके;

(४) वार्षिकनिष्पादन मूल्यांकन रिपोर्टो की वर्षवार उपलब्धता तथा श्रेणीकरण दशशनिवाला विवरण
जो मंत्रालय के दिनांक 1.2.2007 के पत्र के अनुसार उपाध्यक्ष/अध्यक्ष द्वारा विधिवत
हस्ताक्षरित हो. पिछले पाँच वर्षो में से यदि किसी विशिष्ट वर्ष/अवधि की वार्षिक निष्पादन
मूल्यांकन रिपोर्ट उपलब्ध न हो, तो उसके बारे में "रिपोर्ट नहीं है प्रमाणपत्र" पूर्ववर्ती वर्षों के
वार्षिक निष्पादन मूल्यांकन रिपोर्टों के साथ प्रस्तुत किया जाए;

(४) संबंधित पद एवं वेतनमान के लिए सभी प्रमाणपत्रों की सत्यापित फोटोकैपीयाँ तथा शैक्षणिक
योग्यता प्रमाणपत्र और वर्तमान तथा पिछले कार्य का अनुभव प्रमाणित करना आवश्यक है.

(५) संबंधित पोर्ट द्वारा अनापत्ति प्रमाण पत्र.
(५) आवेदक को इस आशय का प्रतिज्ञापत्र देना होगा कि यदि सेवा चयन समिति द्वारा चयन किया
गया, तो उम्मीदवारी वापस नहीं ली जाएगी, तथा
(सं) संलग्न प्रोफार्मा (अनुलग्नक-1) के अनुसार संबंधित पोर्ट की सतर्कता और प्रशासनिक
अनापत्तियाँ;
(vit) दो पासपोर्ट साईज फोटोग्राफ.
5.1 पोर्ट द्वारा किसी भी आवेदक के संबंध में आवेदन की अग्रिम प्रति प्राप्त होने के मामले में मंत्रालय के
दिनांक 26.9.2019 के दिशानिर्देशों के अनुसार यदि उसका आवेदन पोर्ट द्वारा उचित माध्यम से आवेदन प्राप्त
ह करने की अंतिम तिथि के 15 दिनों के भीतर तक प्राप्त नहीं हुआ तो मंत्रालय द्वारा उम्मीदवार की उम्मीदवारी
पर विचार नहीं किया जाएगा.
5.2 और मंत्रालय ने अपने दिनांकित 26.9.2019 के पूर्व दिशानिर्देशों के क्रम में दिनांकित 20.9.2022
के पत्र द्वारा महा पत्तन प्राधिकरणों में विभागप्रमुख स्तर के पदों को भरने संबंधी एक परामर्श जारी किया है,
जिसमें अन्य बातों के साथ-साथ यह कहा गया है कि:
"इस संबंध में; वह स्पष्टकिया जाता हैकि ATT PTAA ST. उम्मीदवार की सतर्कता अनापति
वार्षिकिनिष्पावत MAA RAD AIT BRT में प्रशासनिक औपवचारिकताओं & AT PO TAT
लग सकत है. ऐसी प्ररिस्थिति में जिस पत्तन ने।विज्ञापन|दिया है उसका आवेदन के उस्तुतिकरण की

<!-- page 10 -->

अंतिष विधि से Veet ander Daa पत्तों को सयक्ष ग्रषिकारी के अजुगरोदन के खथ (अर्थात
उचित छत से) अधिकारी का आवेदन अग्रेशित करना जरुरी है ऐसे उचित मध्यग्रों से oraz
आवेदनों पर (वार्षिक निष्पवत मूल्यकन रिग्रेटों सतर्कता अनापत्तियाँ आदि के बिता श्री) विभाग
अर स्तर के पदों पर गिग्रक्षित करने हेढ़ स्रालय ब्रा विचार किया जाएगा तथ्ाएि चयन समिति
बार उम्मीदवार की उम्मीदवारी पर/विच्चार।क्िए जाने के लिए. फत्तनों को अनावश्यक्रविलब के बिग
शेष कायजातों को अग्रेशित करना जरुरी है
ऐसे ऊर्शउदहरप है जिसमें प्रन्‍ा आखरी क्षवों वें उम्मीदवारों के आवेदन अग्रेशित करते है.
अत, ऐसे आवेदन जिसने विज्ञफ्त दिया है. उप पत्तन को उ्स्तुतिकरण की अंतिय (तिथि से पहले
खुँच एन असंगव होठ है. ऐसे कगलों में एच्तरों को चाहिए।कि वे उसका आवेदन (उचित ग्ध्यय
से; अर्थात ओएग़ी आवेदन की किट आउट के खाथ एच्तन के अग्रेषय सहित) ई-मेल के जरिए pore
ग़क्ि उ्त पद के लिए उम्मीदवार की उम्मीदवारी पर/।विच्चारहिंक जा सके; बाद में अन्य TAA
a OE एत्ता उम्मीदवार का सर्प आवेदन जिस पत्तर ने विज्ञापर दिया है उसे पंजीकृत डक से
HUTT BR"
6... पत्तन, पोत परिवहन तथा जलमार्ग मंत्रालय के दिनांक 26.9.2019 की पत्र सं-26/25/2013 पीई_
के संदर्भ में पात्रता मानदण्ड के लिए निर्णायक तिथि, पद रिक्त होने तिथि, अर्थात 18.8.2023 होगी.
7... यदि पिछले 10 वर्षो के दौरान आवेदक पर कोई बडा या मामूली दण्ड लगाया गया है तो ऐसे दण्ड
की ओर पहुचनेवाला अनुशासनिक मामला आवेदन के साथ आवश्यक कागजप्रों सहित अग्रेषण प्राधिकारी
द्वारा भेजा जाए. पत्तन, पोत परिवहन तथा जलमार्ग मंत्रालय के दिनांक 20.1 2021 की पत्र सं.७-
12023/2/2021-पीई.1 के तहत सतर्कता रिपोर्ट निर्धारित प्रारूप में प्रस्तुत की जानी है, जिसकी प्रति
अनुलग्नक -1प में संलग्न है.
8. मंत्रालय के दिनांक 26.9.2019 के दिशानिर्देशों के अनुसार महा पत्तन प्राधिकरणों में विभाग प्रमुख
स्तर के पदों को भरने के संबंध में, पोर्ट अधिकारी यदि सेवा चयन समिति द्वारा अपने चयन के बाद पद केलिए
अपनी उम्मीदवारी वापस लेता है तो वह भविष्य में दो वर्षों के लिए सभी महा पत्तन प्राधिकरणों में विभाग प्रमुख
स्तर के पदों के चयन के मामले में रोक के लिए उत्तरदायी होगा.
9... नियत तिथि के पश्चात या निर्धारित प्रक्रिया के बाद आवेदन या अपूर्ण आवेदन या देरी से प्राप्त
आवेदनों का विचार नहीं किया जायेगा.
भवदीया,
ua)
संलग्न: यथोक्त. (श्रीमती शु.गि. पटवर्धन)
सचिव (प्रभारी)
मई 2023
