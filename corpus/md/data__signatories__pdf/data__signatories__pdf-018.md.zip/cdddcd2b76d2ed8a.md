---
doc_id: "cdddcd2b76d2ed8a"
source_url: "https://www.dpe.gov.in/static/uploads/2026/06/61c322f54fad480ebdd11fb89f63d80c.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Alignment of CSR expenditure of Central Public Enterprises (CPSEs) with national priorities - common theme for the FY 2026-27 and 2027-28-regarding."
date: "2026-08-03"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f3c03cdbcdf4eb3a"
---

<!-- page 1 -->

F.No. 8/2/2018-Dir(CSR) (FTS-11223)
Government of India
Ministry of Finance
Department of Public Enterprises
Block No. 14, CGO Complex
Lodi Road, New Delhi-110003
Dated 34 August, 2026
OFFICE MEMORANDUM
Subject: Alignment of CSR expenditure of Central Public Enterprises (CPSEs) with
national priorities - common theme for the FY 2026-27 and 2027-28 - regarding
The undersigned is directed to state that in supersession of this Department's
O.M. of even no. dated 18'" June, 2026 (copy enclosed) on the subject mentioned above,
the competent authority has approved the following themes (with specific areas of
| intervention as indicated below) as the common theme for CSR activities by CPSEs for
the FY 2026-27 and 2027-28:
d Health
a. PM TB Mukt Bharat Abhiyaan
2 Nutrition: Anganwadi infrastructure
a. Construction of Anganwadi Bhawan
b. Provision for functional toilets
हि c. Provision for drinking water
d. Smart TV for early education and learning
e. Boundary walls
f. Child-friendly furniture
3 Development to Sporting Activities
a. Developing Sporting infrastructure
b. Providing equipment
c. Enabling access to professional Coaching
d. Promotion of Sports
e. Nurturing of Sportspersons
Innovative Livelihood Enhancement
a. Support in the form of equipment, infrastructure, digital learning
tools, modern workshops and laboratories, smart classrooms and
digital learning infrastructure in ITIs
b. Adopting one or more of the 100 PMDDKY districts that align with
their operational geograph
5 Water Conservation
a. Installation of different water harvesting and recharge pits for
ground water
b. Promotion recycling of waste water into usable water
c. Reducing the surface runoff of ground water
d._Incorporation of efficient irrigation system among farmers
6 PM Internship Scheme
wal

<!-- page 2 -->

B=
2 All Administrative Ministries/ Departments are requested to bring the above
to the notice of CPSEs under their respective administrative control for information
and compliance.
da! vA ४20": | \ ye :
21%
(Kailash Bhandari)
Joint Director
Tel: 2436-6247
To Secretaries of all administrative Ministries / Departments a
Copy to :-
(i) Prime Minister’s Office (Shri Amrit Agrahari, Director), Seva Teerth, New
Delhi : w.r.t. ID No. 340/31/C/11/2018-FE dated 25' July, 2026
(ii) PS to Hon’ble Finance Minister
(iii) PS to Hon’ble Minister of State (Finance)
(iv) Cabinet Secretariat (Ms. Sweta Mohanty, Director), Seva Teerth, New Delhi :
w.r.t. ID Note No. 252/2/2/2022-CA.IV dated 31* July, 2026
(v) CEO, NITI Aayog, NITI Bhawan, Sansad Marg, New Delhi - 110001.
(vi) Chief Executives of CPSEs
ands
312 २८26
(Kailash Bhandari)
Joint Director
Se

<!-- page 3 -->

F.No. 8/2/2018-Dir(CSR)-FTS(11223)
Government of India
Ministry of Finance
Department of Public Enterprises
Block No. 14, CGO C =
Lodi Road, New Delhi-110002
Dated 18" June, 2026
OFFICE MEMORANDUM
Subject: Alignment of CSR expenditure of Central Public Enterprises (CPSEs} with
national priorities - common theme for the FY 2026-27 and 2027-28
regarding
The undersigned is directed to refer to this Department's O.M. of even no. dated
100 December, 2018 on the subject mentioned above and to inform that the competent
authority has approved the following themes (with specific areas of intervention 2s
indicated below) as the common theme for CSR activities by CPSEs for the FY 202
27 and 2027-28:
(i) Nutrition: Anganwadi infrastructure
a. Construction of Anganwadi Bhawan
b. Provision for functional toilets
c. Provision for drinking water
d. Smart TV for early education and learning
e. Boundary walls
f. Child-friendly furniture
(ii) Development to Sporting Activities
a. Developing Sporting infrastructure
b. Providing equipment
c. Enabling access to professional Coaching
d. Promotion of Sports
e. Nurturing of Sportspersons
(iii) Innovative Livelihood Enhancement
a. Support in the form of equipment, infrastructure, digital learning tools,
modern workshops and laboratories, smart classrooms and digital learning
infrastructure in it.
b. Adopting one or more of the 100 Prime Minister Dhan-Dhaanya Krishi Yojana
(PMDDKY) districts that align with their operational geography.
2. All Administrative Ministries/ Departments are requested to bring the above to
the notice of CPSEs under their respective administrative control for information and
compliance.
1S
Chan ae ton
tepals:
(Kailash Bhandari)
Joint Director
Tel: 2436-6247
पल, Secretaries of all administrative Ministries/Departments

<!-- page 4 -->

pein
Sapy to i-
i) Prime Minisier’s Office (Shri Amrit Agrahari, Director), Seva Teerth, New
Delhi: w.r-t. 1D No. 340/31/C/11/2018-FE dated 6 June, 2026
(i) Cabinet Secretariat (Ms. Sweta Mohanty, Director), Seva Teerth, New Delhi
> wert. ID Note No. 252/2/2/2022-CA.IV dated 10!" June, 2026
Gil) Chief Executives of CPSEs
(v} PS to Hon’bie Finance Minister
(५) PS to Hon'ble Minister of State (Finance)
Sd | ला
(Kailash Bhandari)
Joint Director
