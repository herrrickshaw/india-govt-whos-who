---
doc_id: "cef7d1cae8fa9c10"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/5acc2810d4ce1da06f76772760a9fd3a.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Amended Plywood and Wooden Flush door shutters (Quality Control) Order, 2024"
date: "2025-07-02"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "b0a6b96a242c1afa"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-15032024-253067
xxxGIDHxxx
CG-DL-E-15032024-253067
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 1311]
No. 1311]

नई ददल्ली, िुक्रवार, मार्ध 15, 2024/फाल्गुन 25, 1945
NEW DELHI, FRIDAY, MARCH 15, 2024/PHALGUNA 25, 1945

वाजणज्य और उद्योग मंत्रालय
(उद्योग संवधधन और आंतररक व्यापार जवभाग)
आदेि
नई ददल्ली, 15 मार्ध, 2024
का.आ. 1377(अ).—भारतीय मानक ब्यूरो अजधजनयम, 2016 (2016 का 11) की धारा 16 के साथ परित
धारा 17 और धारा 25 की उप धारा (3) द्वारा प्रदत्त िजियों का प्रयोग करते हुए तथा को प्लाईवुड और लकडी के फ्लि
डोर िटर (गुणवत्ता जनयंत्रण) आदेि, 2023 का अजधक्रमण करते हुए, जसवाय ऐसे कायों के संबंध में िो ऐसे अजधक्रमण
से पहले दकए गए या जिनके दकए िाने से छू ट प्रदान दकया गया, कें द्र सरकार का यह मत है दक यह िनजहत में आवश्यक
अथवा जहतकर है, अत: एतद्द्वारा जनम्नजलजखत आदेि करती है, नामत: 1.संजिप्त िीर्धक और प्रारं भ.-(1) इस आदेि को प्लाईवुड और लकडी के फ्लि डोर िटर (गुणवत्ता जनयंत्रण) आदेि,
2024 कहा िाएगा।
(2) यह आदेि 28 फरवरी, 2025 से लागू होगा:
बिते दक लघु उद्यमों के जलए, िैसा दक सूक्ष्म, लघु और मध्यम उद्यम जवकास अजधजनयम, 2006 (2006 का 27) में
पररभाजर्त दकया गया है, यह आदेि 28 मई , 2025 से लागू होगा।
बिते यह भी दक सूक्ष्म उद्यमों के जलए, िैसा दक सूक्ष्म, लघु और मध्यम उद्यम जवकास अजधजनयम, 2006 (2006 का
27) में पररभाजर्त दकया गया है, यह आदेि 28 अगस्ट्त , 2025 से लागू होगा।

1978 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

2. मानक जर्ह्न का अजनवायध उपयोग.- ताजलका के कॉलम (1) में जवजनर्ददष्ट वस्ट्तुएं या सामान उि ताजलका के कॉलम
(2) में उजल्लजखतत दनुरूपी भारतीय मानक के अनुरूप होंगे तथा उनमें भारतीय मानक ब्यूरो (अनुपालन मूल्यांकन)
जवजनयम, 2018 की अनुसूर्ी-II की स्ट्कीम-I के अनुसार ब्यूरो के लाइसेंस के तहत मानक जर्ह्न लगा होगा।
(2) बिते दक इस आदेि में से कु छ भी, जनयाधत की िाने वाली स्ट्वदेि में जवजनर्ममत वस्ट्तुओं या सामान पर लागू नहीं होगा।
3. प्रमाणन और प्रवतधन प्राजधकारी.- यह ब्यूरो ताजलका के कॉलम (1) में जवजनर्ददष्ट वस्ट्तुओं या सामान के जलए प्रमाणन
और प्रवतधन प्राजधकरण होगा।
4. उल्लंघन के जलए पेनल्टी– इस आदेि के प्रावधानों का उल्लंघन करने वाले व्यजि को भारतीय मानक ब्यूरो
अजधजनयम, 2016 के प्रावधानों के तहत दंजडत दकया िाएगा।
ताजलका
वस्तु या सामान

भारतीय मानक

भारतीय मानक का िीर्धक

(1)

(2)

(3)

प्लाईवुड और लकडी के फ्लि डोर
िटर

303:1989

सामान्य प्रयोिनों के जलए प्लाईवुड

2202 (भाग1):1999

वुडेन फ्लि डोर िटर (िोस प्रकार के )- प्लाईवुड
फे स पैनल

710:2010

मरीन प्लाईवुड

5509:2021

अजिरोधी प्लाईवुड

1328:1996

साि-सज्जा वाले प्लाईवुड

2191 (भाग 2):2022

वुडेन फ्लि डोर िटर(सेलुलर और जछद्र वाले) –
पार्टटकल बोडध और हाडधबोडध फे स पैनल

2191 (भाग 1):2022

वुडेन फ्लि डोर िटर (सेलुलर और जछद्र वाले) प्लाईवुड फे स पैनल

2202(भाग 2): 2022

वुडन फ्लि डोर िटर (िोस प्रकार के ) - पार्टटकल
बोडध, हाई डेंजसटी फाइबर बोडध, मीजडयम डेंजसटी
फाइबर बोडध और फाइबर हाडधबोडध फे स पैनल

4990: 2011

कं क्रीट िटररग कायों के जलए प्लाईवुड –
जवजनदेिन

10701: 2012

स्ट्रक्र्रल प्लाईवुड – जवजनदेिन

नोट: इस ताजलका के प्रयोिन के जलए, भारतीय मानकों के संबंध में िारी संिोधनों सजहत उनके नवीनतम संस्ट्करण,
िैसादक ब्यूरो द्वारा समय-समय पर अजधसूजर्त दकए गए हैं, ऐसी अजधसूर्ना की तारीख से लागू होंगे।
[फा. सं. पी-14031/9/2023-सीआई]
संिीव, संयुि सजर्व
MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
ORDER
New Delhi, the 15th March, 2024
S.O. 1377(E).—In exercise of the powers conferred by section 16 read with section 17 and sub-section (3)
of section 25 of the Bureau of Indian Standards Act, 2016 (11 of 2016) and in supersession of the Plywood and
Wooden flush door shutters (Quality Control) Order, 2023, except as respects things done or omitted to be done

<!-- page 3 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

3

before such supersession, the Central Government, is of the opinion that it is necessary or expedient so to do in the
public interest, hereby makes the following order, namely:1.Short title and commencement. - (1) This order may be called the Plywood and Wooden flush door shutters
(Quality Control) Order, 2024.
(2) It shall come into force with effect from the 28 th February,2025:
Provided that in respect of small enterprise, as defined under the Micro, Small and Medium Enterprises
Development Act, 2006 (27 of 2006), it shall come into force with effect from the 28 th May, 2025:
Provided further that in respect of micro enterprises, as defined under the Micro, Small and Medium Enterprises
Development Act, 2006 (27 of 2006), it shall come into force with effect from the 28 th August, 2025.
2. Compulsory use of Standard Marks.-Goods or articles specified in column (1) of the Table shall conform to the
corresponding Indian Standard specified in column (2) of the Table and shall bear the Standard Mark under a licence
from the Bureau as per Scheme-1 of Schedule-II of the Bureau of Indian Standards (Conformity Assessment)
Regulations, 2018:
Provided that nothing in this order shall apply to goods or articles manufactured domestically meant for export.
3. Certification and enforcing authority.-The Bureau shall be the certifying and enforcing authority for the goods
or articles specified in column (1) of the Table.
4. Penalty for contravention. - Any person who contravenes the provisions of this order shall be punishable under
the provisions of the Bureau of Indian Standards Act, 2016.
TABLE
Goods or articles

Indian Standard

Title of Indian Standard

(1)

(2)

(3)

Plywood and Wooden
flush door shutters

303:1989

Plywood for general purposes

2202 (Part 1):1999

Wooden flush door shutters (solid core type) - Plywood face
panels

710:2010

Marine plywood

5509:2021

Fire retardant plywood

1328:1996

Veneered decorative plywood

2191 (Part 2):2022

Wooden flush door shutters (cellular and hollow core type) Particle board and hardboard face panels ,

2191 (Part 1):2022

Wooden flush door shutters (cellular and hollow core type) Plywood face panels

2202(Part 2): 2022

Wooden Flush Door Shutters (Solid core type) — Particle
Board, High Density Fibre Board, Medium Density Fibre
Board and Fibre Hardboard Face Panels

4990: 2011

Plywood for concrete shuttering works - Specification

10701: 2012

Structural plywood - Specification

Note.- For the purposes of this Table, the latest version of Indian Standards including the amendments thereof, as
notified by the Bureau from time to time shall apply.
[F. No. P-14031/9/2023-CI]
SANJIV, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ
KUMAR
VERMA

Digitally signed by
MANOJ KUMAR VERMA
Date: 2024.03.15 20:21:09
+05'30'
