---
doc_id: "cdab5df4f4744dae"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/fc28458209c10dba9ea2305eab6915f3.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Note No.1"
date: "2025-07-02"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5619e9bb9ef3c0b3"
---

<!-- page 1 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion
********

Press Note No. 1 (2015 Series)
Subject: Mapping of the sector specific FDI Policy in Consolidated FDI Policy 2014 in
terms of National Industrial Classification (NIC)-2008
Chapter VI of the Consolidated FDI Policy 2014 issued vide DIPP circular dated the
17.04.2014 indicates sector specific FDI policy for industrial and other sectors such as
permissibility of the activities under FDI policy, equity cap, whether under automatic or
government approval route and conditions to be fulfilled, if any.
2.
With the objective of improving ease of doing of business, an exercise has been
undertaken to map the activities listed in Chapter VI of the Consolidated FDI Policy, 2014
with the National Industrial Classification - 2008.
3.
Accordingly, a chart indicating mapping of the activities covered under Chapter VI of
the Consolidated FDI Policy 2014 with NIC -2008 is attached.
�

-5..."

Joint Secretary to the Government of India
D/o IPP File No.: No. 7/3/2012-IP dated: 5.01.2015

Copy forwarded to:
1. Press Information Officer, Press Information Bureau- for giving necessary publicity.
2. NIC in the Department of Industrial Policy and Promotion-for uploading the Press
Note on DIPP's website.
3. Hindi Division, DIPP for providing Hindi version.
