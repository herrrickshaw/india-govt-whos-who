---
doc_id: "d17cda03cafc098b"
source_url: "https://dsel-education.gov.in/static/uploads/2025/12/8dd2cbcf28ba3ec1e555b5d237c2e512.pdf"
ministry: "Department of School Education and Literacy (DSEL)"
title: "Guidelines on School Safety and Security issued by Department of School Education and Literacy on 01.10.2021"
date: "2021-10-01"
pages: 93
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4aec66af9dc7aa88"
---

<!-- page 1 -->

T

1%reTT Hc41d^
f^ren 3fk 'dlttiVdl

n 'IKtl T

3Tf&cI)R
ticuAi vra^

^ Reeil - 110115
GOVERNMENT OF INDIA

Santosh Kumar Yadav,

Joint Secretary,

MINISTRY OF EDUCATION
DEPARTMENT OF SCHOOL EDUCATION & LITERACY

Telephone No.011-23387781
E-mail: yadavsk.up@nic.in

SHASTRI BHAVAN
NEW DELHM10115

ci

D.O. No. 17-1/202D-IS-11

New Delhi Dated the i

October, 2021

Prease find enclosed a copy of 'Guidelines on School Safety and Security',

developed by this Department for fixing the accountability of the School Management in the
matter of Safety and Security of Children studying in Government, Government-aided and
Private Schools, in pursuance of the order of Hon'ble Supreme Court in Writ Petition

(Criminal) No. 136 of 2017 and Writ Petition (Civil) No. 874 of 2017; and in line with the
provisions contained in the National Education Policy, 2020.
2.

These guidelines have been prepared by an expert committee and through extensive

consultation with all stakeholders. The State/UT Government, exercising its power u/s 35(2)

of the RTE Act, 2009, CrPC, 1973 and as per its mandate under Rule 93 of the Juvenile
Justice Model Rules, 2016; shall notify these guidelines. The Guidelines are advisory in

nature and States/UTs may incorporate additions/modifications to these guidelines, if deemed
necessary, according to the State/UT specific requirements.

Yours sincerely,
Enclosure: As above

J)
(

(Santosh K^fSrat^Yadav)

1. The Addl. Chief Secretary/Principal Secretary/Secretary,
Department of Education,
All States and UTs as per list attached.
2. Heads of all Autonomous Bodies of DoSEL

ftlfffT c|5I STmcpR
YEARS OP
CELEBRATING
THE MAHATMA

<!-- page 2 -->

Department of School Education & Literacy
Ministry of Education
Government of India

Guidelines on School
Safety and Security

2021
0

<!-- page 3 -->

Department of School Education
State ___________
Notification
In pursuance of the order of Hon’ble Supreme Court in the Writ Petition (Criminal)
No. 136 of 2017 and Writ Petition (Civil) No. 874 of 2017 and decision taken by
Ministry of Education (MoE) to frame guidelines for fixing the accountability of the
School Management in the matter of safety of the children; MoE has recommended
the Guidelines on School Safety and Security (2021) for fixing the accountability of
the School Management in the matter of Safety of the Children studying in all Schools
including Private Schools.
Exercising its power u/s 35(2) of the RTE Act, 2009 and as per its mandate under
Rule 93 of the Juvenile Justice Model Rules, 2016; the State Government notifies the
Guidelines on School Safety and Security for fixing the accountability of the School
Management in the matter of Safety of the Children studying in all Schools including
Private Schools with effect from ____________________________________

1

<!-- page 4 -->

INDEX
Sl. No. Particulars
Page No.
I. Abbreviation…………………………………………………….………………………………………………………………………………6-7
II. Executive Summary …………………………………………………….……………………………………………………………………8-9
1.

Background………………………………………………...,………………………….........................................................10
1.1 Order of the Apex Court …………………………………………………….…………………………………………………….10
1.2 Fixing accountability …………………………………………………….……………………………….............................11
1.3 Three-pronged approach to safety and security of children in schools: ……………………………………11
1.4 Operational Definitions …………………………………………………….………………………………………….............12

2. National and International Context …………………………………………………….…………………………………………..13
2.1 National Education Policy, 2020…………………………………………………….…………………………………………13
2.2 Rights of Children, SDGs, International conventions …………………………………………………….………….13
3. Constitutional Provisions and legal framework……………………………………………....................................15
3.1 Constitutional provisions ………………………………………………………………………………………….................15
3.2 Central Legislation and Policies…………………………………………….......................................................15
3.3 State Specific Provisions …………………………………………………….…………………………………………………….21
3.4 Categories of Negligence………………………………………………………………………………………………………….21
3.5 Legal Provisions in case the offence has been established ……………………………………………………….22
3.6 Interpretations of Legal Provisions …………………………………………………………………………………………..23
4. Accountability Framework: Responsibility of School/School Management/Head of School…………….24
4.1 Accountability ………………………………………………………………………………………………............................24
4.2 Legal Provisions for government and government-aided schools ………………………………...............24
4.3 Legal provisions w.r.t private schools …………………………………………………….………………………………..25
4.4 Ensuring compliance by private/unaided elementary schools ………………………………………………...25
4.5 Ensuring compliance by government/government aided elementary schools ………………………….27

2

<!-- page 5 -->

4.6 Ensuring compliance by government/government aided/private schools of secondary/ senior
secondary level ……………………………………………………………………………...........................................................28
4.7 Rationale for para 4.4, 4.5 and 4.6 regarding fixing accountability…………………………………………..28
4.8 Role of NCPCR and SCPCR ……………………………………………………………………………………………………….30
4.9 Legal provisions w.r.t role of NCPCR and SCPCR ………………………………………………………………………30
4.10 Responsibilities of School/School Management in the accountability framework………….........30
4.11 Responsibility of the State/UT government: SSSA ………………………………………………….................33
5. Whole School Safety Approach………………………………...........................................................................35
5.1 Whole School Safety: Concept…………………………………………………………………..................................35
5.2 Why the Whole School Safety Approach?…………………………..........................................................35
5.3 Whole School Safety: Scope…………………………………………………….………………………..........................35
5.4 Implementation of Whole School Approach……………………………………………………………………………..36
5.5 How will the Whole School Approach be implemented…………………………………………………………….37
5.6 Infrastructure safety and signage …………………………………………………………………………………………….37
5.7 Residential Schools………………………….............................................................................................38
5.8 Pre-School Centres (PSC)…………………………………………………………………………………………………………..39
5.9 Psychosocial Safety…………………………………………………………………………………………………………………..39
5.10 Health and Physical Safety……………………………………………………………………………………………………...40
5.11 Cyber Safety……………………………………………………………………………………………………………………….....40
5.12 Curriculum………………………………………………………………………………………………………………………………41
5.13 Teaching-Learning Process………………………………………………………………………………….....................41
5.14 Assessment and Examination………………………………………………………………………………....................41
5.15 Parent-Teacher Interaction…………………………………………………………………………………………………….42
5.16 Parent-Staff Interactions…………………………………………………………………………………........................42
5.17 Training of School Personnel……………………………………………………………………………………..……………43

3

<!-- page 6 -->

5.18 School Preparedness for Disaster……………………………………………………………………………………………43
5.19 Other recommendations for schools to comply………………………………………………………………………43
5.20 Developing Safe and Secure Schools: System Functionaries……………………………………………………44
5.21 System Functionaries at State and District level: Disaster Management………………………...........45
5.22 COVID-19…………………………………………………………………………………………………………….....................45
6. Whole School Safety Approach: Roles and responsibilities of stakeholders…………………………………….48
6.1 Roles and responsibilities of School/School Management in Whole School Safety…………………..48
6.2 Roles and Responsibilities of Principals/School Heads……………………………………………………………..49
6.3 Roles and responsibilities of Teachers …………………………………………………………………………………….50
6.4 Roles and responsibilities of the Parent……………………………………………………………………………………50
6.5 Roles and responsibilities of Warden……………………………………………………………………………………….50
6.6 Roles and responsibilities of a counsellor…………………………………………………………………………………51
6.7 Roles and responsibilities of students……………………………………………………………………..................51
6.8 Roles and responsibilities of non-teaching staff………………………………………………………………………51
6.9 Roles and responsibilities of School Nurse/ Health Workers/ Visiting Medical
Personnel………………………………………………………………………………………………………………………………………………52
7. Developing a Safe and Secure Society (Multi-sectoral Approach)……………………………………………………53
7.1 Law and Justice……………………………………………………………………………………………………………………….53
7.2 Women and Child Development……………………………………………………………………………………………..53
7.3 Electronics and Information Technology………………………………………………………………………………...54
7.4 Health and Family Welfare ……………………………………………………………………………………..................54
7.5 Home Affairs ……………………………………………………………………………………………...............................55
7.6 Information and Broadcasting ……………………………………………………………………………………………….55
7.7 Panchayati Raj………………………………………………………………………………………………………………………..56
7.8 Urban Development………………………………………………………………………………………..…………………….56
7.9 Higher Education ………………………………………………………..............................................................56

4

<!-- page 7 -->

7.10 Social Justice and Empowerment……………………..……………………………………..………………………….56
7.11 Labour and Employment……………………………………….…………………………………………………………….57
7.12 Sports, Youth and Cultural Affairs………………………………………………………………………………………..57
7.13 Skill Development and Entrepreneurship……………..……………………………………………………………..57
7.14 Drinking Water and Sanitation……………………………………………………………..................................57
8. Implementation Plan……………………………………………………………………………………………………………………….58
List of Annexures………………………………………………………………………………………………………………..…………..61-91
I. State Specific Provisions ……………………………………………………………………………………………………………..61
II. Constitution of Parent Teacher Association……………………………………………….……………………………….72
III. Comprehensive Checklist ………………………………………………………………………………………………………….74
IV. Constitution of School Safety Committee……………. …………….…………………………………………………….83
V. Integrating learning about Safety in School Education………………………………………………..................84
VI. School Safety Pledge …………………………………………….......................................................................91

5

<!-- page 8 -->

I.
CBSE
COTPA
COVID-19
CPCR
CPO
CPR
CPTD
CrPC
CSA
CTE
CWSN
DC
DEO
DIET
DM
DRISHTI
IASE
ICPS
ICSE
ICT
IPC
IT
KVS
MDM
MoE
NCERT
NCPCR
NDMA
NEP
NPC
NVS
POCSO
POSH
PTA
PTM
PSC
RTE
SCERT
SCPCR
SDG
SJPU

ABBREVIATION

Central Board of Secondary Education
Cigarettes and Other Tobacco Products (Prohibition of Advertisement and Regulation
of Trade and Commerce, Production, Supply and Distribution) Act, 2003
Corona Virus Disease 2019
Commission for Protection of Child Rights Act, 2005
Child Protection Officer
Cardio Pulmonary Resuscitation
Child Parent Teacher Dialogue
The Code of Criminal Procedure Act
Child Sexual Abuse
College of Teacher Education
Children with Special Needs
District Collector
District Education Officer
District Institute for Education and Training
District Magistrate
Disseminate, Roll-out, Intervene, Support, Hand-hold, Track and Incentivize
Institute of Advanced Studies in Education
The Integrated Child Protection Scheme
Indian School Certificate Examination
Information and Communication Technology
Indian Penal Code
Information Technology
Kendriya Vidyalaya Sangathan
Midday Meal
Ministry of Education
National Council of Educational Research and Training
National Commission for Protection of Child Rights
National Disaster Management Authority
National Education Policy
National Policy for Children
Navodaya Vidyalaya Samiti
The Protection of Children from Sexual Offences Act and Rules
Prevention, Prohibition and Redressal Act
Parent Teachers Association
Parent Teachers Meeting
Pre-School Centres
The Right of Children to Free and Compulsory Education Act, 2009
State Council of Educational Research and Training
State Commission for Protection of Child Rights
Sustainable Development Goal
Special Juvenile Police Unit

6

<!-- page 9 -->

SM
SMC
SOP
SSC
SSSA
UNCRC
UNESCO
USA
UT
VAC
WHO
WSA

School Management
School Management Committee
Standard Operating Procedure
School Safety Committee
State School Standards Authority
United Nations Convention on the Rights of the Child
United Nations Educational, Scientific and Cultural Organization
United States of America
Union Territory
Violence against Children
World Health Organization
Whole School Approach

7

<!-- page 10 -->

II.

Executive Summary

Aim/Purpose of this guideline:
The purpose of this guideline is:









Firstly, to create an understanding among all stakeholders, including students and parents,
on the need for co-creating a safe and secure school environment for the holistic development
of children.
Secondly, it is to make different stakeholders aware about the acts, policies, procedures and
guidelines already available on different aspects of safety and security i.e., physical, socioemotional, cognitive and specific to natural disasters as well.
Thirdly, it is to empower different stakeholders and enable clarity on their role in the
implementation of this guideline.
Fourthly, it is to fix accountability for keeping children safe and secure in schools (including
while children are transported to and fro, to attend school or go back to their homes in a
school transport) on School Management and Principals and Teachers in Private/Unaided
Schools, and Head/in-charge Head of School, Teachers and education administration in case
of government/government-aided schools.
A key purpose is to emphasize the ‘Zero Tolerance Policy’ against any negligence on the part
of any individual or management when it comes to the safety and security of children in
schools.

An integrated approach to the guidelines:
This Guideline has been developed following an ‘accountability framework’ with the help of
existing legal provisions; ‘whole school approach’ by integrating safety and security aspects in
education itself, by including deliberations upon the health, physical, socio-emotional, psycho-social
and cognitive aspects of school safety and security; and at the same time ‘addressing multi-sectoral
concerns’ to further create a safe society, giving recommendations for the other Ministries and
Departments in addition to Education Department. Some areas that have been integrated are as
follows:
a. This guideline includes Laws and Acts applicable in the context of school safety and security
at the state and national levels for creating awareness among various stakeholders to further
strengthen the implementation of legal provisions in this area. With the first quarter of 21st
Century witnessing a pandemic, COVID-19, that is giving a new challenge of social distancing
and maintenance of health and hygiene protocols at schools, this guideline takes into
cognizance the precautions to be followed for making schools safe and secure from the health
point of view as well. Therefore, this guideline recommends all schools to follow Standard
Operating Procedures/guidelines issued by this Department, the Ministry of Home Affairs,
Health Ministry and also state-level administration from time -to- time on COVID-19 issue.
b. In view of urgency for sensitization, orientation and capacity building of teachers, school
heads, teacher educators, this guideline recommends state-level educational institutions to
come forward to not only conduct special awareness and capacity building programmes for

8

<!-- page 11 -->

school heads, teachers, parents, students and teacher educators but also to integrate
pandemic challenges, concerns and actions into the other regular capacity building
programmes. The national level capacity building programme for elementary school
teachers, i.e., NISHTHA has already integrated a special module on education response to
COVID-19.
c. Further, as this pandemic has forced school education to reflect upon its mode of
transaction/delivery of education, and a gradual shift of a percentage of teaching-learning
towards on-line blended mode appears to be imminent, this guideline also emphasizes
cybersecurity and safety for children and teachers.
d. The guideline is also adequately linked to the guidelines provided by NDMA for compliance
in physical infrastructure and disaster-related issues, and guidelines given by NCPCR for the
compliance of safety issues related to residential schools and CBSE and other school boards
for the accountability framework.
e. The guidelines also include a comprehensive checklist of the essentialities of school safely
and security and actions to be taken by the school in this regard.
f. Finally, in the context of school safety and security, the guideline recognizes that
Accountability is an obligation of the School Management, Principal, and Teacher to adhere
to the Laws/norms/guidelines; accept responsibility towards providing safety conditions for
children in school; account for their activities; to disclose the actions and impacts in a
transparent manner; and most importantly to be held legally responsible in case of any
negligence.

THESE GUIDELINES MUST BE READ ALONG WITH THE FOLLOWING:





National Commission for Protection of Child Rights (NCPCR) has developed a Comprehensive
Manual on Safety and Security of Children in School. The Manual available at
www.ncpcr.gov.inis a compilation of various existing guidelines, circulars, notifications,
Government Orders on safety and security related issues in schools issued from time to time.
NCPCR’s Guidelines for Hostels of Educational Institutions
The National Disaster Management Authority (NDMA) has also formulated and issued the
National Disaster Management Guidelines on School Safety Policy, 2016.

9

<!-- page 12 -->

Chapter 1
Background
1.1

Order of the Apex Court:

In the Writ Petition (Criminal) No. 136 of 2017 and Writ Petition (Civil) No. 874 of 2017 before the
Hon’ble Supreme Court, Petitioners sought guidance to frame guidelines for fixing accountability of
the school managements in the matter of safety of children studying in schools. The order of Hon’ble
Supreme Court in the said petitions, states that being a matter of policy and governance, call ought
to be taken thereon by the Secretary, Department of School Education, Ministry of Human Resource
Development (now Ministry of Education), Government of India, and may obtain and consider inputs
from all relevant sources and take such decision as may be considered appropriate.
Realizing the criticality of safety and security of every child, a meeting was organized by MoE under
the leadership of Secretary (School Education & Literacy) to discuss the problem, its magnitude, the
roles and responsibilities of different stakeholders and different departments that are linked with
the issue; and the modalities for preparation of guidelines for “fixing the accountability in the matter
of Safety of the Children studying in all Schools including Private Schools”. It was decided in the
meeting that draft model guidelines will be prepared by a committee constituted by MoE through
consultations with different stakeholders, across managements, departments and sectors.
In the meeting, it was also noted that various organizations have already issued guidelines on various
aspects of school safety and security. These include a Comprehensive Manual on Safety and Security
of Children in all schools including private schools, issued by National Commission for Protection of
Child Rights (NCPCR) in 2017. The Manual is a compilation of various existing guidelines, issued from
time to time. The National Disaster Management Authority (NDMA) has also formulated the National
Disaster Management Guidelines on School Safety Policy, 2016 with a vision to ensure the creation
of safe learning environment for stakeholders for preparing plans, developing capacity,
incorporating risk reduction in the guidelines. It was issued on 9th January 2017 to State and UT
Governments for further dissemination and implementation at appropriate levels in the State.
It was also decided in the meeting that MoE will take cognizance of each of the existing guidelines
developed by different agencies at the national level and also the measures taken up by different
States like Delhi, Tamil Nadu, Sikkim and others on child safety and security in a broader perspective
and adding teeth to the existing framework by fixing accountability and defining roles and
responsibilities of different stakeholders as the key purpose of redrafting the existing guidelines.
Further, the draft model guidelines prepared by NCPCR earlier in consultation with MoE were
circulated to all States and UTs, Ministry of Women and Child Development, Ministry of Home Affairs,
CBSE, ICSE, NDMA, KVS, NVS, NCPCR & Independent School Federation of India for comments. The
guidelines were also uploaded on the website of MoE for comments/suggestions. As per the

10

<!-- page 13 -->

suggestions from states/UTs and other stakeholders, it was felt that there is a need to prepare a
single guideline/document in a simple implementable format which also incorporates accountability
at various levels.
1.2

Fixing accountability:

When children attend school, where they spend about half a day on every school working day, the
responsibility to ensure their safety and security lies with the school authorities. When a child is in
school, the school has the actual charge or control over a child, and if the school willfully neglects the
child, in a manner likely to cause the child unnecessary mental or physical suffering, it may be treated
as violation of Juvenile Justice Act, 2015. Hence, it is the school i.e., School
Management/Principal/Head of school that has the responsibility of ensuring safety of children in
schools and parents play an important role in monitoring whether the school is fulfilling its
responsibility.
1.3

Three-pronged approach to safety and security of children in schools:

These guidelines are based on a three-pronged approach to the safety and security concerns in
schools as follows:
a. Accountability framework and legal provisions: The legal framework has been discussed
first of all along with an accountability framework for safety and security of children in
schools.
b. Whole School Safety Approach: This approach entails the participation of all stakeholders,
including among others, school management, Principals, teachers, students, parents, nonteaching staff, etc. with clear roles and responsibility towards school safety and security.
c. Multi-sectoral approach: It is not only schools, but also homes and society; not only
Ministry of Education, but also other ministries and departments that need to share the
responsibility of developing safe and secure society in which the school functions.
1.4

Operational Definitions:

Some terms that have been used in these guidelines require a clear understanding; therefore, a set
of operational definitions is given below.

11

<!-- page 14 -->

1.4 Operational Definitions
1. School Safety: Creating safe environment for children, starting from the transportation from
their homes to their schools and back.
2. Safety: A state in which hazards and conditions leading to physical, psychological or material
harm are controlled in order to preserve the health and well-being of individuals and the
community.
3. Security: A condition that is created taking measures in coordination with concerned people
to make the environment free of crime, violence and injury.
4. School Management Committee: To be constituted as per Section 21 (1) of the RTE Act
2009.
5. School Management: In case of Private Schools, School Management refers to an
administrative set up of school system, in which a group of persons like owner/Trustee,
Principal, Vice-Principal, Senior Teacher, Superintendent of Hostel (in case of residential
school), student leader and any other such person, who is entrusted with the duty to
supervise, plan, organize, review and evaluate various aspects of an educational institution
in formal way i.e., school order, notice, duty chart, etc. School Management is also responsible
for monitoring and managing the overall strategic directions, finances, performance and
policies of a school and provides advice and guidance to the principal of the school.
6. Parent Teacher Association: A school-based association of parents and teachers for
promoting closer relations, providing continuous support to the child at home and in school,
and providing feedback to the school for improving the child’s learning environment at
school.
7. Parent Teachers’ Meeting (PTM): PTM refers to class/grade wise meetings called by
schools between parents and teachers to reflect upon and take and give feedback regarding
the progress of the child.
8. Competent Authority: Means an officer who is head of district education department as
applicable in respective States and UTs.
9. Schools: (defined under section 2 (n) of RTE Act, 2009)
"School" means any recognised school imparting elementary education and includes-i.
a school established, owned or controlled by the appropriate Government or a
local authority;
ii.
an aided school receiving aid or grants to meet whole or part of its expenses
from the appropriate Government or the local authority;
iii.
a school belonging to specified category; and
iv.
an unaided school not receiving any kind of aid or grants to meet its expenses
from the appropriate Government or the local authority
10. School Safety Plan: A comprehensive all-hazards plan that takes into account all threats and
hazards for a particular school.
11. Corporal Punishment: means the subjecting of a child by any person to physical
punishment that involves the deliberate infliction of pain as retribution. Right of Children to
Free and Compulsory Education (RTE) Act, 2009, prohibits 'physical punishment' and
'mental harassment' under Section 17(1) and makes it a punishable offence under Section
17(2).

12

<!-- page 15 -->

Chapter 2
National and International context
2.1

National Education Policy, 2020:

The NEP, 2020 lays down the goal of every educational institution – from pre-school to University–
“A good educational institution is one in which each student feels welcomed and cared for, where a
safe and stimulating learning environment exists, where a wide range of learning experiences are
offered, and where good physical infrastructure and appropriate resources conducive to learning are
available to all students. Attaining these qualities must be the goal of every educational institution.”
Para 5.9 of the policy lays down the need for adequate and safe infrastructure, adopting systems to
ensure that teachers and students, including children of all genders and children with disabilities,
receive a safe, inclusive, and effective learning environment, and ensuring that in-service training has
inputs on safety, health and environment at workplace in schools to ensure that all teachers are
sensitized to these requirements. Safety of all inmates of residential hostels, particularly of girl
children is laid down in para 6.9 of the policy.
Para 8.5 (c) gives a framework for ensuring safety in schools. It states as follows: “To ensure that all
schools follow certain minimal professional and quality standards, States/UTs will set up an
independent, State-wide, body called the State School Standards Authority (SSSA). The SSSA will
establish a minimal set of standards based on basic parameters (namely, safety, security, basic
infrastructure, number of teachers across subjects and grades, financial probity, and sound processes
of governance), which shall be followed by all schools. The framework for these parameters will be
created by the SCERT in consultation with various stakeholders, especially teachers and schools.”
The policy is very categorical on the multiplicity of safety issues and their provisioning; it requires
careful attention to be paid to the safety and rights of children and adolescents enrolled in schools,
particularly girl children and the various difficult issues faced by adolescents, such as substance or
drug abuse and forms of discrimination and harassment including violence, with clean, safe, and
efficient mechanisms for reporting and
due process on any infractions against
children’s/adolescents’ rights or safety. It further emphasizes according high priority to the
development of such mechanisms that are effective, timely, and well-known to all students.
2.2

Rights of Children, SDGs, International conventions

Rights of Children are an integral part of the Constitution, reflected in PART I, Fundamental Rights as
well as PART IV, Directive Principles of State Policy. Specifically, Article 39 (f & e) mentions
promoting good health (more details in chapter 3).
A discussion on international context is limited here to the Sustainable Development Goals. The
Sustainable Goals also include those related to Child Rights, and India also commits to the
achievement of these especially the following:
 SDG 3: ‘Ensure healthy lives and promote well-being for all at all ages.’

13

<!-- page 16 -->







SDG 4: ‘Ensure inclusive and quality education for all and promote lifelong learning,
highlighting the importance of knowledge and skills on human rights and the promotion of a
culture of peace and non-violence’ (Target 4.7) as well as ‘the provision of child, gender and
disability sensitive facilities and safe, non-violent, inclusive and effective learning
environments for all’ (Target 4.8).
SDG 5: ‘Promote gender equality and empower all women and girls’ (Target 5.2), ‘eliminate
all forms of violence against all women and girls in the public and private spheres, including
trafficking and sexual and other types of exploitation’ and
SDG 16: ‘Addressing violence against children and promotion of peaceful and inclusive
societies’, under this goal (Target 16.1), states ‘significantly reduce all forms of violence and
related death rates everywhere’ and Target 16.2 states ‘end abuse, exploitation, trafficking
and all forms of violence against and torture of children’.

Action to address school violence and bullying is an essential component of other international
conventions and commitments, including the Convention on Rights of the Child, which obliges states
to ensure that children are protected from violence. Thus, providing safe and secure learning
environment for children at home, in school, in the community and society, becomes a collective
responsibility of all the stakeholders.
The COVID-19 pandemic in the first quarter of the 21st Century across the globe has further posed a
challenge of maintaining health of the entire school fraternity. This has added a new dimension for
social distancing in school, which relates not only to infrastructure and other physical aspects but
also to health, hygiene and mental well-being.

14

<!-- page 17 -->

Chapter 3
Constitutional Provisions and legal framework
3.1

Constitutional provisions:

Provisions of the Constitution of India for the protection and safety of children are as given below:
Constitutional
Provision

Rights

Article 14

Fundamental right to equality and equal protection of the law

Article 15 (3)

Fundamental right to special provisions

Article 21

Fundamental right to life and personal liberty
Right to free and compulsory elementary education for all children in
the 6-14-yearage

Article 21 A
Articles 23 and 24
Article 39 (e)
Article 39 (f)

Article 46

Fundamental right against exploitation
Right to health and freedom from abuse due to economic necessity
Right to development with dignity and guaranteed protection of
childhood and youth against exploitation and against moral and
material abandonment
Right of weaker sections to special educational care and protection
from social injustice and all forms of exploitation

Article 47

Right to nutrition and standard of living and improved public health

Article 51A (k)

Duty of parents or guardians to provide opportunities for education

3.2

Central Legislations & Policies






Further, states under Article 15(3) of the Constitution of India can make any special provision
for women and children.
Included in these constitutional protections, also is the mandate of the State under Article
21A to ensure fundamental right to education. In other words, the Constitutional mandate on
the State requires the State to ensure the right to education and the right of every child to a
safe and protected educational environment.1
As a result, a number of central and state legislations, policies and guidelines are framed from
time to time.
A few key central legislations are highlighted below:

1For a more detailed list: please see “Chapter III: Instruments and Standards for Protection of Child Rights” in the Study on Child Abuse

India 2007, produced by the Ministry of Women and Child Development, Government of India

15

<!-- page 18 -->

Central
Legislation/Polic
y/ Guidelines
Right
to
Education:
Consolidated
guidelines
on
safety
and
security
of
children
dated
11th September,
2017
RTE Act 2009:
Section 31

RTE Act 2009:
Section 32

Overview

In the wake of school safety incidents in 2017, the Department of
School Education & Literacy, MoE, reissued the guidelines on safety
and security of children (earlier sent vide letter dated 9th October,
2014), which has suggested preventive institutional mechanisms and
procedures that should be put in place in the schooling system along
with the relief and redressal strategies in case of any such incidents.

The NCPCR constituted under section 3, or, as the case may be, the
SCPCR constituted under section 17, of the CPCR Act, 2005 (4 of 2006)
shall, in addition to the functions assigned to the Act, also performs the
following functions, namely:
(a) Examine and review the safeguards for the rights provided by or
under any Law related to children and recommend measures for their
effective implementation;
(b) Inquire into complaints relating to child's right to free and
compulsory education; and
(c) Take necessary steps as provided under section 15 and 24 of the
said CPCR Act, 2005.
(2) The said Commissions shall, while inquiring into any matters
relating to child's right under clause (1)(c), have the same powers as
assigned to them under sections 14 and 24 of the said CPCR Act, 2005.
(3) Where the SCPCR has not been constituted the appropriate
Government may, for the purpose of performing the functions
specified in clause (1)(a) to (1)(c), constitute such authority, in such
manner and subject to such terms and conditions, as may be
prescribed.
1) Notwithstanding anything contained in section 31, any person
having any grievance relating to the right of a child under this Act may
make a written complaint to a local authority having jurisdiction.
2) After receiving the complaint under sub-section (1), the local
authority shall decide the matter within a period of three months after
affording a reasonable opportunity of being heard to the parties
concerned.
3) Any person aggrieved by the decision of the local authority may
prefer an appeal to the SCPCR or the authority prescribed under subsection 3 of section 31, as the case may be.
4) The appeal preferred under sub-section 3 shall be decided by
SCPCR or the authority prescribed under sub-section 3 of section 31,
as case may be, as provided under clause (c) of sub-section (1) of
section 31.

16

<!-- page 19 -->

Central
Legislation/Polic
y/ Guidelines

Overview

The
Juvenile
Justice (Care &
Protection
of
Children)
Act
2015 (JJ Act) and
Juvenile Justice
Rules 2016
The
Juvenile
Justice Act, 2015:
Section 75

Founded on the principles of the UNCRC, the JJ Act provides a
framework for the care, protection, treatment and rehabilitation of
children in the purview of the juvenile justice system.

Juvenile
Model
2016

Justice
Rules,

Rule 93 of the Juvenile Justice Model Rules, 2016 "empowers the State
Government to take action against such officer/ institution, statutory
body etc. after due inquiry who fails to comply with the provisions of
the Act and the Rules framed thereunder, and simultaneously make
alternative arrangements for discharge of functions for effective
implementation of the Act."

Juvenile Justice
Act, 2015: Section
109

Section 109 of the Juvenile Justice Act, 2015 also entrusts NCPCR and
SCPCRs with the responsibility of monitoring the Act, in addition to the
functions assigned to them under the CPCR Act, 2005.

Sexual
Harassment
of
Women
at
Workplace
(Prevention,
Prohibition and
Redressal) Act,
2013 (POSH)

An Act to provide protection against sexual harassment of women at
work place and for the prevention and redressal of complaints of
sexual harassment and for matters connected therewith or incidental
thereto.

The Juvenile Justice Act, 2015 under section 75, clearly states that
"Whoever, having the actual charge of, or control over, a child,
assaults, abandons, abuses, exposes or willfully neglects the child or
causes or procures the child to be assaulted, abandoned, abused,
exposed or neglected in a manner likely to cause such child
unnecessary mental or physical suffering, shall be punishable with
imprisonment for a term which may extend to three years or with fine
of one lakh rupees or with both".
If in case of an accident in the School/ school transport during or after,
or before school hours it is found that the school, which has actual
charge of or control over the child when the child is in school, has
willfully neglected the child that has caused the child unnecessary
mental or physical suffering, it may be treated as violation of Juvenile
Justice Act, 2015 and should be referred to the Police by the School
Management/Authority.

17

<!-- page 20 -->

Central
Legislation/Polic
y/ Guidelines
The
National
Policy
for
Children, 2013
(NPC 2013):

The Protection of
Children
from
Sexual Offences
Act and Rules,
2012 (POCSO):

POCSO
2020

Rule,

The
IT
(Reasonable
Security
Practices
and
Procedures and
Sensitive
Personal Data or
Information)
Rules 2011
Right of Children
to
Free
and
Compulsory
Education
Act
2009 (RTE):

Overview

The NPC 2013 drew extensively from and reiterated the commitments
for upholding rights of children already enshrined in the Children’s
Charter and the NPA 2005. Guiding Principle X of the NPC 2013 states
that “safety and security of all children is integral to their well-being
and children are to be protected from all forms of harm, abuse, neglect,
violence, maltreatment and exploitation in all settings including care
institutions, schools, hospitals, crèches, families and communities.”
Places an obligation on the state to prevent sexual violence against
children, identify and respond to such violence and notify guidelines
that must be adhered to by various stakeholders including the
educational institutions. It seeks to protect all children from sexual
assault, sexual harassment and pornography and provides for
stringent penal action against offenders, including presumption of
guilt.
Rule-3 (Awareness generation and capacity building) of POCSO Rule,
2020 provides that Central Government, or as the case may be, the
State Government shall prepare age-appropriate educational material
and curriculum for children, informing them about various aspects of
personal safety. It also provides that any institution housing children
or coming in regular contact with children including schools, creches,
sports academies or any other facility for children must ensure a
police verification and background check on periodic basis, of every
staff, teaching or non-teaching, regular or contractual, or any other
person being an employee of such Institution coming in contact with
the child. Such Institution shall also ensure that periodic training is
organized for sensitizing them on child safety and protection.
Prescribes security standards for personal information stored
electronically.

Section 17 prohibits physical punishment and mental harassment of
children.
Section 29(2)(g) while laying the procedure for curriculum
transactions emphasizes making the child free from fear, trauma and
anxiety and helping the child to express views freely.
Section 19 (1) states that ‘No school shall be established, or
recognized, under Section 18, unless it fulfills the norms and standards

18

<!-- page 21 -->

Central
Legislation/Polic
y/ Guidelines

Overview
specified in the Schedule.’

The Integrated
Child Protection
Scheme
2009
(ICPS):

National Plan of
Action
for
Children, 2005
(NPAC 2005):

The Commission
for Protection of
Child Rights Act
2005:

Section 13(1) of
the Commissions
for Protection of
Child
Rights
(CPCR) Act, 2005

Launched by the Ministry of Women and Child Development,
Government of India, to bring elements of all child protection
programs under one umbrella, it set in place child protection
mechanisms with trained personnel, from national to local level and
for the first time provided budgetary allocations as per the 12th Five
Year Plan.
The NPAC 2005 was formulated and adopted as India’s response to the
UN General Assembly Session on Children, set out in the “World Fit for
Children” outcome document. India became a signatory to this UN
session in May 2002 decisions and the NPAC 2005 re-enforces the
State’s commitment on protection issues highlighted in the outcome
document.
This provides for the constitution of a National Commission and State
Commissions for protection of child rights and children’s courts for
providing speedy trial of offences against children or of violation of
child rights and for matters connected therewith or incidental thereto.
It also ensures the monitoring of implementation of legislation and
policies at all levels of governance for upholding child rights and action
for non-compliance.
This section empowers NCPCR to:
(a) Examine and review the safeguards provided by or under any law
for the time being in force for the protection of child rights and
recommend measures for their effective implementation;
(b) Present to the Central Government, annually and at such other
intervals, as the Commission may deem fit, reports upon the working
of those safeguards;
(c) Inquire into violation of child rights and recommend initiation of
proceedings in such cases;
(d) Examine all factors that inhibit the enjoyment of rights of children
affected by terrorism, communal violence, riots, natural disaster,
domestic violence, HIV/AIDS, trafficking, maltreatment, torture and
exploitation, pornography and prostitution and recommend
appropriate remedial measures;
(e) Look into the matters relating to children in need of special care
and protection including children in distress, marginalized and
disadvantaged children, children in conflict with law, juveniles,
children without family and children of prisoners and recommend
appropriate remedial measures;
(f) Study treaties and other international instruments and undertake
periodical review of existing policies, programmes and other activities
on child rights and make recommendations for their effective
implementation in the best interest of children;

19

<!-- page 22 -->

Central
Legislation/Polic
y/ Guidelines

Section 13(2) of
the Commissions
for Protection of
Child
Rights
(CPCR) Act, 2005
The
National
Charter
for
Children in 2003
(Children’s
Charter):
The
Cigarettes
and
Other
Tobacco
Products
(Prohibition of
Advertisement
and Regulation of
Trade
and
Commerce,

Overview

(g) Undertake and promote research in the field of child rights;
(h) Spread child rights literacy among various sections of the society
and promote awareness of the safeguards available for protection of
these rights through publications, the media, seminars and other
available means;
(i)Inspect or cause to be inspected any juvenile custodial home, or any
other place of residence or institution meant for children, under the
control of the Central Government or any State Government or any
other authority, including any institution run by a social organization;
where children are detained or lodged for the purpose of treatment,
reformation or protection and take up with these authorities for
remedial action, if found necessary;
(j) Inquire into complaints and take suo motu notice of matters relating
to(i) deprivation and violation of child rights;
(ii)Non-implementation of laws providing for protection and
development of children;
(iii) non-compliance of policy decisions, guidelines or
instructions aimed at mitigating hardships to and ensuring
welfare of the children and to provide relief to such children, or
take up the issues arising out of such matters with appropriate
authorities; and
(k) Such other functions as it may consider necessary for the
promotion of child rights and any other matter incidental to the above
functions.
As provided in Section 13 (2) of the Commission for Protection of Child
Rights (CPCR) Act, 2005, the Commission shall not inquire into any
matter which is pending before a State commission or any other
commission duly constituted under any law for the time being in force.
This Charter emphasizes protection from economic exploitation and
all forms of abuse; protection of the girl child; care, protection, welfare
of children of marginalized and disadvantaged communities; and
ensuring child-friendly procedures.
Section 6 of the COTPA Act:
“Prohibition on sale of cigarettes or other tobacco products to a person
below the age of 18 years and in particular area”.
Section 24 of the COTPA Act:
“Punishment for sale of cigarettes or any other tobacco products in
certain places or to persons below the age of 18 years.”

20

<!-- page 23 -->

Central
Legislation/Polic
y/ Guidelines
Production,
Supply
and
Distribution) Act,
2003
The Information
Technology Act,
2000
Scheduled Castes
and
Scheduled
Tribes
(Prevention
of
Atrocities) Act,
1989

3.3

Overview

Section 67 B of the IT Act, 2000:
“Punishment for publishing or transmitting material depicting children
in sexually explicit acts, etc., in electronic form.”
Though the Act is not specific to children or does not have specific
provisions for crimes against children, it does apply to all crimes
committed against SC or ST children.

State Specific Provisions:

Majority of the States and UTs have made provisions relating to management and safety measures in
the State/UT Education Act. The detailed State and UT wise provisions are at Annexure- I.
3.4

Categories of negligence:

It shall be the responsibility of the School Management and Principal in private schools and
Principal/Head of school along with local school administration, be accountable to take preventive
measures against all forms of negligence towards the safety and security aspects of children in
schools. The negligence committed by the School Management/Authorities/Principal/Head of
school/teaching and non-teaching staff may be broadly categorized as follows:
a.

Negligence in establishing a secured infrastructure for the students and children with
special needs.

b.

Negligence to the quality, standard of the food served and portability of water provided
to students in school for consumption.

c.

Negligence related to security measures adopted by the School Authorities for the safety
of students.

d.

Negligence in providing timely medical aid to the students.

e.

Negligence in taking action against a complaint reported by a student.

f.

Negligence on corporal punishment including mental, emotional harassment.

g.

Negligence in preventing bullying, discriminatory actions, substance abuse in the
school premises.

21

<!-- page 24 -->

3.5

h.

No regular monitoring and reporting to appropriate authority as mentioned

i.

Delaying actions in case of crime or disaster.

j.

Suppression of facts and not reporting to the appropriate authority.

k.

Negligence in strict implementation of COVID guidelines resulting in threat or
vulnerability for safety and security of students.

Legal Provisions in case the offence has been established:
Accountability of School
Management
a. Criminal Negligence

Legal Provisions and Rules attracted

Sections 304, 308 etc. of Indian penal Code. Section
75 of Juvenile Justice Act, 2015
b. Medical Aid Negligence
Section 77 of the Juvenile Justice Act, 2015
c. Corporal Punishment
Section 75 of the Juvenile Justice Act, 2015
d. Conspiracy
Section 16 of the POCSO Act, 2012, Section 34 and
120B etc. of the Indian Penal Code, 1860 and Section
87 of the Juvenile Justice Act, 2015
e. Concealment/non-reporting of Section 21 of the POCSO Act and Section 202 of
offence
Indian Penal Code, 1860
f. Tampering Evidence
Section 201, 203 etc. of the Indian Penal Code, 1860
g. Sexual abuse
Section 19 of the POCSO Act, 2012
h. Cyber Safety and Security
Section 67 B of IT Act, 2000 and Sections 13 and 15
of the POCSO Act, 2012
i. Infrastructural Safety and The National Building Code of India, 2004
Security
j. Food Safety
Sections 272, 273 of the Indian Penal Code, 1860
k. Environmental Safety
Section 278 of the Indian penal Code, 1860
l. Sexual harassment and Sexual Section- 4, 6, 8, 10, 12, 14 and 15 of the POCSO Act,
Assault
2012
m. CWSN
i. Legal Rights of CWSN
Section 16, 17, 31 & 32 of the Rights of Persons with
Disabilities Act, 2016
Section 31 of The Persons with Disabilities (Equal
Opportunities, Protection of Rights and Full
Participation) Act, 1995
ii. Punishment for violating the Section 89 of the Rights of Persons with Disabilities
rights of CWSN
Act, 2016
iii. Punishment for offences against Section 5 and 9 of the POCSO Act, 2012 and Section
CWSN
85 of the Juvenile Justice Act, 2015
n. Constitutional
rights
of Article 15 (3), 21 (A), 23, 24, 39 (e), 39 (f), 46, 47
children
and 51A (k) of the Constitution of India

22

<!-- page 25 -->

3.6

Interpretation of Legal Provisions:

(a)
Negligence
with
regard
to
the
Medical-Aid:
If
the
School
Authorities/Management/Teaching and non-teaching staff gives intoxicating liquor or narcotic drug
or psychotropic substance to a child without the advice of the Medical Practitioner, they shall be liable
to be tried under Section 77 of the Juvenile Justice Act, 2015.
(b)
Corporal Punishment to a child: If the School Authorities/Management/Teaching and nonteaching staff are found imposing corporal punishment to a child, they are liable to be prosecuted
under Section 75 of the Juvenile Justice Act, 2015.
(c)
Conspiracy: Conspiracy is said to have committed when two or more persons jointly commit
an act which is against the law. If the School Authorities/ Management/ Teaching and non-teaching
staff are found liable for hatching a criminal conspiracy against a student or on the commission of a
crime they are found suppressing it for any reason, they may be prosecuted under Sections 34, 120B
etc., of the Indian Penal Code, 1980.
(d)
Concealment or non-reporting of an offence: Intentional omission to give information of
offence by the school management or any other concerned person-Whoever, knowing or having
reason to believe that an offence has been committed against the child, intentionally omits to give
any information respecting that offence which he/she is legally bound to give, shall be punished as
per Sections 202 etc. of the Indian Penal Code, 1860.
(e)
Tampering/eradicating the evidence: If the school authorities/ Management/ teaching
and non-teaching staff, to attain any purpose, try to cause disappearance of vital evidence of offence
or produce any false information during investigation or before court, in order to rescue the offender,
they shall be liable to be prosecuted under sections 201, 203
(f)
Mandatory reporting of sexual abuse against a child: Section 21(1) of the POCSO Act,
2012 requires mandatory reporting of cases of child sexual abuse to the law enforcement authorities,
and the same applies to everyone including parents, doctors and school personnel. Failure to report
a suspicion of child abuse is an offence under the Act and the offender may be prosecuted for the
same as per the provisions of POCSO Act, 2012. Any private person who fails to report suspected
child abuse, having acquired the information in the discharge of his or her professional
responsibilities, commits a summary conviction offence.

23

<!-- page 26 -->

Chapter 4
Accountability Framework: Responsibilities of School2/School
Management/Head of school for ensuring safety and security
of children in school

4.1

Accountability:






4.2

Accountability is an obligation of the School Management, Principal, and teachers to adhere
to the Laws/norms/guidelines and accept responsibility towards providing safe conditions
for children in school, account for their activities, disclose the actions and impacts in a
transparent manner and most importantly be aware of their legal responsibility in case of
any negligence.
There are different Laws and Acts (already discussed in Chapter 3) in India, which accord
appropriate punishments to the criminals responsible for crimes against children, including
in schools. Where the offence is established, appropriate action under relevant law shall be
taken; it is also important to focus on measures to prevent any crime against children to occur
in school or while commuting to the school.
In the school education system – School Management, Principal, Head of School,
teacher (in case of any incident during class or under her watch), local administration
supervising the government/government-aided school (particularly w.r.t to safe
infrastructure, mock drills, training, etc.) are accountable for ensuring the safety and
security of the children in school, and responsible for preventing neglect of any aspect
of safety and security of children, or any non-adherence to the safety Guidelines (such
as, the NCPCR’s Manual for Safety and Security of Children in Schools, NCPCR’s
Guidelines for Hostels of Educational Institutions) or any other safety norms
prescribed by the Appropriate Government, recommendations of SMC/PTA, etc.
Legal Provisions for government and government-aided schools:

a. For the purposes of these guidelines, “School Management Committee or SMC”3 will hereon
refer to the SMC formed/to be formed under section 21 of the RTE Act for all schools covered
by sections 2(n)(i), 2(n) (ii) and 2(n)(iii) of the RTE Act, 2009.
b. Section 21 of the RTE Act 2009 provides for “School Management Committee” and it states
that - a school, other than a school specified in sub-clause (iv) of clause (n) of section 2, shall
constitute a School Management Committee consisting of the elected representatives of the
local authority, parents or guardians of children admitted in such school and teachers.
Therefore, schools that are mandated to have School Management Committee include:

2The word ‘School’ here implies that the Principal/Head of School, even if in-charge, will take responsibility of all matters related to

safety and security of the school
3For Kendriya Vidyalayas and Navodaya Vidyalayas, this would mean the Vidyalaya Management Committee

24

<!-- page 27 -->

i.

a school established, owned or controlled by the appropriate Government or
a local authority;
ii.
an aided school receiving aid or grants to meet whole or part of its expenses
from the appropriate Government or the local authority;
iii.
a school belonging to specified category
c. It requires that at least three-fourth of members of such Committee shall be parents or
guardians, proportionate representation is to be given to the parents or guardians of children
belonging to disadvantaged group and weaker section, and that fifty per cent of Members of
such Committee should be women.
d. The said provision lays down the functions of School Management Committee as follows:
 monitor the working of the school;
 prepare and recommend school development plan
 monitor the utilisation of the grants received from the appropriate Government or
local authority or any other source; and
 perform such other functions as may be prescribed.
e. The responsibility for monitoring the actions taken for the safety of child while on school
premises is inherent in the provision, however, states/UTs must undertake its specific
incorporation in their RTE Rules.
f. Every government/government-aided school must call parents to regular Parent Teacher
Meetings (PTM).
4.3

Legal provisions w.r.t private schools:
a. As per section 21 of RTE Act, 2009, private schools covered under section 2(n)(iv) of the Act
are exempted from formulating SMCs in the format laid down by the Act.
b. However,
every
private
school
has
its
own
School
Management
Board/Group/Committee/Trust/etc. which shall herein be referred as “School Management
or SM” for the purpose of these guidelines.
c. Further, under section 18 (1) of RTE Act it is mandatory for all private schools functioning
within the geographical limits/jurisdiction of the state, to obtain recognition by the state in
the manner prescribed.
d. Section 18 (2) of the RTE Act also empowers states to lay down conditions for recognition.
e. Recognition Certificate under section 18 of the RTE Act from the Competent Authority is an
essential requirement to establish a private school. Further, without the Recognition
Certificate, a school cannot apply for affiliation to the Examination Boards.
f. The private schools defined under section 2 (n) (iv) of RTE Act, 2009 should have a Parent
Teachers Association (PTA) as per the composition given in Annexure-II.

4.4

Ensuring compliance by private/unaided elementary schools:
a. Every private elementary school must mandatorily apply under the provisions of RTE
Act for recognition: Section 2(n)(iv) of RTE Act defines a private unaided school as “school” means any recognised school imparting elementary education and includes an

25

<!-- page 28 -->

b.

c.

d.

e.

f.

g.

unaided school not receiving any kind of aid or grants to meet its expenses from the
appropriate Government or the local authority.
States/UTs are empowered to recognize the school with conditions: Recognition is given
to schools by the state/UT government under section 18(1) of the RTE Act and conditions for
recognition can be laid down by the state/UT government under section 18(2) of the Act for
recognition of the school. No elementary school can function in the country without obtaining
such recognition. Under these powers of the RTE Act, all states should ensure that
constitution of PTA is made a mandatory condition for recognition of the school, as PTAs are
an important link in monitoring the safety and security measures in private unaided schools.
The other conditions for recognition may include preparation and implementation of a school
specific accountability framework for every stakeholder in school like, principal, teachers,
non-teaching staffs and members of the school management on all the components given
above. The conditions may also include directions on the constitution of committees that will
be responsible for observing the above components in the schools at different levels. The
Safety Guidelines and Accountability Framework, and compliance with all related laws, rules,
norms, guidelines, etc. should be made an essential condition under section 18(2) of the RTE
Act, 2009 for giving recognition certificate to schools by the state governments.
The conditions for recognition of school u/s 18 can include conditions for fixing
responsibility of safety and security on School Management/Principal/Head of School:
All State/UT governments may also lay down specific conditions fixing responsibility of
safety and security of the children in schools on the School Management/Principal/Head of
School, and also fixing responsibility of the School Management/Principal/Head of School to
be responsive to the suggestions of the PTA, and students, while giving recognition to the
school. States/UTs may review recognitions already given to include such conditions.
Incorporating conditions in laws/rules/bye-laws of Affiliating Boards: In case of private
schools the Affiliating Boards need to ensure that compliance with all conditions laid down
by appropriate government becomes a mandatory condition for affiliation. The
Laws/Rules/Bye-laws of affiliating bodies may be revised accordingly to incorporate the
conditions of the Safety Guidelines as well as the Accountability Framework as laid down by
appropriate government.
Action in case of a criminal offence: If there is commission of a criminal act/offence, it will
be the duty of the Head of School/in-charge Head of School and the School Management to
take necessary action as per provisions of law. In case of negligence in taking appropriate
action, they shall be held responsible. The Block Education Officer should also be informed
simultaneously.
Action in case of non-compliance: If there is non-compliance of Safety and Security
requirements or neglect or abetment by the school, which led to such an offence, the PTA
should approach the Block Education Officer (BEO).
Action in case issue is not addressed at Block level: In case of non-redressal of the
grievances at BEO level the matter should be taken up with District Education Officer (DEO).
If the issues are not addressed by the DEO, the PTA/complainant may take-up the matter with
the District Collector (DC)/District Magistrate (DM). The DC/DM may arrange to hold an
enquiry and based on findings, give directions to the schools as may be deemed fit. After

26

<!-- page 29 -->

enquiry by DC/DM, if it is found that the school has not adhered to the safety guidelines,
and/or has neglected the safety and security of children and thus risked the lives of the
children, following steps may be taken by the DC/DM according to the nature of negligence
by the School:
i.
A fine on school equivalent to 1% of the total revenue generated in the preceding year
for the first time of non-compliance and/or debarring the school for taking admission
in the subsequent academic year;
ii.
3% for second time of non-compliance and/or debarring the school for taking
admission in the subsequent academic year;
iii.
5% for third time of non-compliance and/or debarring the school for taking
admission in the subsequent academic year.
h. Action in case of continued non-compliance: In case of complaint of continued noncompliance of the private elementary schools even after the above directions of the DC/DM,
the DC/DM may escalate the issue to the state/UT School Education Department. The
Department can arrange to conduct an enquiry and if found true, actions ranging from
directing school to fulfill compliance within certain number of days, to penalising the school
to temporary/permanent withdrawal of recognition of the school, as may be deemed fit, can
be undertaken by the state/UT government. (Since there are different categories of private
schools ranging from budget or low-fee schools to high-fee private schools; the fine imposed
should be in proportion to the total revenue generated by the school in the preceding year).
It may be noted that this part of the guidelines is to ensure Safety and security of children in
schools and are meant to be followed as a preventive measure by fixing the accountability of
school management. Further, no student is supposed to suffer due to the action against the
school.
i. Permanent withdrawal of recognition must not be resorted to unless in case of an
exception of extreme cases of repeated non-compliance. However, in case required, it
should be resorted to only after taking care of the interests of all children enrolled and
studying in the school.
j. In case of temporary withdrawal of recognition of the school, the appropriate Government
to take over the Management of the school until school complies with the safety measures
specified in NCPCR's Manual on Safety and Security of Children in Schools and any other
guidelines. Provided that the appropriate Government after taking over the school, shall
appoint administrator not below the rank of Sub-Divisional Magistrate as administrative
head of the school to ensure its smooth functioning. During this period, no further
development shall be taken up in the school except activities related to education and
safety of children.
4.5

Ensuring compliance by government/government aided elementary schools:
a. Action in case of a criminal offence: If there is commission of a criminal act/offence, it will
be the duty of the Head of School/in-charge Head of School and the School Management, if
any, to take necessary action as per provisions of law. On complaint from any parent/student,

27

<!-- page 30 -->

the Head of the school and School Management are expected to act quickly and take necessary
actions under various provisions of law.
b. Action in case of complaint: On non-compliance of safety and security requirements in the
school, the parent/guardian should approach the Block Education Officer (BEO). In case of
non-redressal of the grievances at BEO level the matter should be taken up with District
Education Officer (DEO). If the issues are not addressed by the DEO, the parent/guardian may
take-up the matter with the District Collector (DC)/District Magistrate (DM). The DC/DM may
arrange to hold an enquiry and based on findings, give directions to the schools as may be
deemed fit.
c. Action in case of complaint of continued non-compliance: In case of complaint of
continued non-compliance by the school even after the above directions of the DC/DM, the
DC/DM may escalate the issue to the state/UT School Education Department. The
Department can arrange to conduct an enquiry and if found true, may take appropriate
disciplinary and other administrative action against the erring members, including against
the School Management, if required.
d. Non-compliance of the recommendations of SMC: For Government Schools, in case
of non-compliance of the recommendations of SMC by the school; the SMC should bring it to
the notice of appropriate authority as defined under the respective State RTE Rules. The
Appropriate Authority shall take/recommend action against the responsible officials for noncompliance as per the service rules.
4.6 Ensuring compliance by government/
secondary/senior secondary level:

government

aided/private

schools

of

a. All secondary/senior secondary level schools are affiliated to a secondary school examination
board. The affiliation laws/rules/bye-laws of such boards must include conditions for the
purpose of initial affiliation and continued affiliation relating to compliance of all safety and
security provisions of Appropriate Authority for school children.
b. The state/UT government may also like to frame their own conditions for continuance of
recognition under their own laws/guidelines/etc.
c. If there is commission of a criminal act/offence, it will be the duty of the Head of School/incharge Head of School/PSM to take necessary action as per provisions of law.
d. Violation of conditions of affiliation by private schools should be viewed seriously by the
state/UT government in which the school is located. State/UT government will be expected
to take necessary action under extant laws.
e. Provisions must be made in affiliation laws/rules/bye-laws for strict action in such cases by
affiliating board in consultation with Appropriate Authority.
f. In case of complaint by PTA/parent of non-compliance, actions in accordance with paras 4.4
(d) to 4.5 (i) above may be followed in the case of secondary/senior secondary/composite
schools too.
4.7

Rationale for para 4.4, 4.5 and 4.6 regarding fixing accountability

4.7.1 Rationale based on Juvenile Justice Act, 2015 and Juvenile Justice Model Rules, 2016

28

<!-- page 31 -->





The Juvenile Justice Act, 2015 under section 75, clearly states that “Whoever, having the actual
charge of, or control over, a child, assaults, abandons, abuses, exposes or wilfully neglects the
child or causes or procures the child to be assaulted, abandoned, abused, exposed or neglected
in a manner likely to cause such child unnecessary mental or physical suffering, shall be
punishable with imprisonment for a term which may extend to three years or with fine of one
lakh rupees or with both”
Rule 93 of the Juvenile Justice Model Rules, 2016 “empowers the State Government to take
action against such officer/ institution, statutory body etc. after due inquiry who fails to comply
with the provisions of the Act and the Rules framed thereunder, and simultaneously make
alternative arrangements for discharge of functions for effective implementation of the Act.”

4.7.2 Rationale based on Code of Criminal Procedure, 1973







Section 32 and 33 of the CrPC, 1973 provides that the High Court or the State Government, as
the case may be, confer powers to a person holding an office in the service of the Government.
Section 32 of the CrPC, 1973, states that, in conferring powers under the CrPC, the High Court
or the State Government, as the case may be, may, by order, empower persons specially by name
or in virtue of their offices or classes of officials generally by their official titles.
Further, section 33 defines the powers of officers appointed and as per this, whenever any
person holding an office in the service of Government who has been invested by the High
Court or the State Government with any powers under this Code throughout any local area is
appointed to an equal or higher office of the same nature, within a like local area under the
same State Government, he shall, unless the High Court or the State Government, as the case
may be, otherwise directs, or has otherwise directed, exercise the same powers in the local
area in which he is so appointed.
Also, Section 144 (1) of the CrPC, 1973 states that the Power to issue an order in urgent cases
of a nuisance of apprehended danger if such direction is likely to prevent, or tends to prevent,
obstruction, annoyance or injury to any person lawfully employed, or danger to human life,
health or safety, or a disturbance of the public tranquillity, or a riot, of an affray. As per 144
(1), in cases where, in the opinion of a District Magistrate, a Sub- divisional Magistrate or any
other Executive Magistrate specially empowered by the State Government in this behalf, there
is sufficient ground for proceeding under this section and immediate prevention or speedy
remedy is desirable, such Magistrate may, by a written order stating the material facts of the
case and served in the manner provided by section 134, direct any person to abstain from a
certain act or to take certain order with respect to certain property in his possession or under
his management…

4.7.3 Rationale based on RTE Act, 2009


The RTE Act, 2009 u/s 35(1) empowers the Central Government to issue guidelines to the
appropriate government or, as the case may be, the local authority, as it deems fit for the
purpose of implementation of the provisions of the Act.

29

<!-- page 32 -->



4.8

Section 35(2) empowers the appropriate Government to issue guidelines and give such
directions, as it deems fit, to the local authority or the School Management Committee
regarding implementation of the provisions of this Act.
Role of NCPCR and SCPCR:
NCPCR and SCPCRs, as the case may be, shall be responsible for monitoring the
implementation of the legal aspects of these guidelines.

4.9

Legal provisions w.r.t role of NCPCR and SCPCR:
The provisions with regard to Monitoring a child’s right to education, including the role as
mentioned above in para 3.1 for NCPCR/SCPCR are given in Section 31 and 32 of the RTE Act,
2009 and also in the Section 13(1) of the Commissions for Protection of Child Rights (CPCR)
Act, 2005. Section 109 of the Juvenile Justice Act, 2015 also entrusts NCPCR and SCPCRs with
the responsibility of monitoring the Act, in addition to the functions assigned to them under
the CPCR Act, 2005. Please see these provisions in chapter 3.

4.10

Responsibilities of School/School Management in the accountability framework:

To ensure the effective implementation of safety and security measures in school and to ensure safety
and security of each child in the school, the School/School Management shall have certain specific
roles and responsibilities other than those mentioned in the aforementioned paragraphs, for which
they shall be held accountable, which are as follows:
a. Compliance
with
NCPCR
manual
for
schools:
The
School/School
Management/Principal/Head of School should ensure compliance with the roles and
responsibilities assigned to it under NCPCR's Manual on Safety and Security of Children in
Schools and any other guidelines, as applicable. It shall also ensure analysis of the current
safety and security measures within the schooling system and identify the gaps therein to
undertake remediation. Periodic review of the compliance of this Manual shall be discussed
in the PTA/PTM meetings.
b. Compliance with NCPCR Guidelines for residential schools: The School
Management/Principal/Head of School of the schools with residential facility should ensure
the implementation of NCPCR's Regulatory Guidelines for Hostels of Educational Institutions
for Children. It shall also ensure analysis of the current safety and security measures within
the schooling system and the residential system and identify the gaps therein to undertake
remediation. In residential schools which do not have a PTA, the House Master/Warden/Incharge teacher for the hostel must be taken into confidence for any decision related to safety
and security of students.
c. Including safety components in SDP: School Management/Principal/Head of School
should conduct planning meeting at the beginning of every academic year to develop the
School Safety and Security Plan. The 'School Safety and Security Plan’ of Children should be
included as one of the major components while preparing School Development Plan. The

30

<!-- page 33 -->

d.

e.

f.

g.

h.

i.

Safety and Security components of School Development Plan (SDP) may be shared with SMC
members, PTA/PTM/student representatives for their feedback/suggestions.
Meetings with SMC/PTA/PTM on school safety and security by School/School
Management: School/School Management/Principal/Head of School shall also conduct
meetings with the SMC, teachers, PTA representatives and student representatives at least
once in a quarter, for reviewing the implementation of the School Safety and Security Plan in
the school. The minutes/decisions of the meeting shall be properly recorded and made
available to the School Principal to be put on school's website and notice board so that it is
available to every parent. The School/School Management/Principal/Head of School should
also receive suggestions from parents on safety issues during these meetings and record the
same in minutes for taking appropriate action.
Periodic Safety inspection of school: The School/School Management shall arrange to
carry out thorough inspection of the school at least once in a quarter, during school hours.
The School Inspection Report prepared by this inspection team and duly signed by the team
should be uploaded on the school website for transparency. This quarterly inspection of
schools will look at the compliance of the School Safety and Security Plan, using the checklist
provided in NCPCR's Manual or comprehensive checklist given at Annexure-III of this
guidelines; NCPCR's Regulatory Guidelines for Hostels of Educational Institutions for
Children in case of residential educational institutions; and other guidelines issued from time
to time, and suggest appropriate measures. Appropriate actions to be taken by
schools/school management regarding any gaps pointed out during this exercise.
Safety Walk: The School Management/SMC should designate members including Principal,
teachers and parents, along with student representatives chosen randomly, as the School
Safety Committee, to conduct 'Safety Walk' of the entire school premises, in order to ensure
compliance of standard safety measures. 'Safety Walk' may be conducted once every quarter.
The composition suggested for the School Safety Committee may be seen at Annexure-IV.
Integrate learning about Safety as an activity for students: Learning about safety of
schools may be integrated as an annual learning and awareness exercise for students. The
format suggested at Annexure-V may be considered in this regard.
In-service training of teachers on their roles and responsibilities: The School/School
Management/Authorities
should
organise
periodic
in-service
training/orientation/sensitisation of the teachers on the roles and responsibilities defined in
NCPCR's Manual on Safety and Security of Children in Schools. (Here Authorities refers to the
District Education Officers (DEO), respective State/UT Education Department/respective
SCERT/DIET). The school should use proper training modules and certification systems. In
this
regard,
the
states
may
consider
issuing
guidelines
based
on
guidelines/modules/directions and prescribed mechanism issued by NCPCR/Authorities
from time to time.
Periodicity of in-service training: The in-service training/orientation/sensitization of the
teachers should be conducted at least once every three-years. In case of introduction of any
new guidelines/laws/policies the orientation should be conducted immediately. All new staff
should also be trained immediately on joining.

31

<!-- page 34 -->

j.

Method of in-service training: For training/orientation/sensitization of the teaching as
well as non-teaching staff the schools may follow either/both of the following options:
 Through collaboration with DIETs for preparation of modules and/or conducting
such training. (If required, DIETs may also take services of the NCPCR’s empaneled
agencies/organisations).
 Through the NCPCR’s empaneled agencies/organisations.
k. Display of School Safety and Security Plan: Every school should prepare and display
School Safety and Security Plan. The School Safety and Security Plan should be prepared by
involving not only SMC/PTA, but also children of all grades, by making it an age-appropriate
exercise in developing the competency of understanding the idea of personal safety, school
community safety and security, and the roles and responsibilities of teachers, school
management, peer groups and their own roles and responsibilities in ensuring the same. The
display of the overall plan should be done creatively in a common area of the school, along
with infographics and photo-graphics, etc. so that children of all grades understand it and
management, teaching and non-teaching staff and parents also do. The school Plan can also
have a sub-component of a Classroom Safety and Security Plan. Students can be involved in
displaying the Classroom Safety and Security Plan in a creative manner.
l. Role of individuals/school/school management under section 19 of POCSO Act: All
schools must constitute a Grievance Committee on Child Sexual Abuse (CSA) within a month
of beginning of every academic year. The Committee and school staff should be oriented
about their role under section 19 of POCSO Act, 2012. Section 19 of the Act states that any
person, who has apprehension that an offence under this Act is likely to be committed or has
knowledge that such an offence has been committed, shall provide such information to: a) the
Special Juvenile Police Unit; or b) the local police.
m. Punishment of individual/institution/school management for non-compliance of
section 19 of POCSO Act: There is individual as well as institutional (management) liability
to report commission of an offence under Section 21 of POCSO Act, 2012 as may be seen
below:
 Section 21 (a) states that - if any person, who fails to report the commission of an
offence under sub-section (1) of section 19 or section 20 or who fails to record such
offences under sub-section (2) of section 19 shall be punished with imprisonment
of either description which may extend to six months or with fine or with both.
 Section 21 (b) states that - Any person, being in-charge of any company or an
institution (by whatever name called) who fails to report the commission of an
offence under sub-section (1) of section 19 in respect of a subordinate under his
control, shall be punished with imprisonment for a term which may extend to one
year and with fine.
Therefore, in case of sexual offence against children in the school premises/school transport
during school hours OR after OR before it, and the school management/individual fails to
report the commission of an offence under sub-section (1) of section 19, action may be taken
under POCSO Act, 2012 against school management/individual.
n. Anti- Bullying Committee: An Anti- Bullying Committee may be constituted in school,
comprising of Vice-Principal, a Senior teacher, School Doctor/Nurse/Health worker,

32

<!-- page 35 -->

Counsellor, SMC/PTA representative, School Management representative, senior students
etc. The decisions taken in Anti-Bullying Committee and Grievance Committee on Child
Sexual Abuse (CSA) meetings should be discussed in the meeting of SMC/PTA. The school
should, jointly with SMC/SM/PTM/PTA and student representatives develop bullying
prevention programme and create awareness.
o. Follow all directions from Appropriate Authorities: The School/SMC/SM shall carry
out any other functions as notified/prescribed by appropriate Government, Central
Government, affiliating body, competent authority from time to time in relation to the safety
and security of children in schools.
p. School Safety Pledge: Department of School Education and Literacy has circulated the
School Safety Pledge to all States, Union Territories and Autonomous Bodies for being
displayed on a board or painted on the wall in English/ Hindi or any other regional language
approved by the State/ UT, at a prominent place in every school. The School Safety Pledge
seeks to address the expectations of all stakeholders in the School for providing a safe and
secure learning environment for children. It also has the contact numbers of some of the
important stakeholders like Childline, State Counselling Helpline etc. The Sample of School
Safety Pledge is at Annexure-VI.
q. School Safety Week: School Safety Week can be celebrated in the beginning of the session
to take stock of all the arrangements related to safety and security of children in schools.
4.11

Responsibility of the State/UT government: State School Standards Authority (SSSA)

a. Para 8.5(c) of NEP provides for all schools – public or private – to follow certain minimal
standards, including those on safety and security of children, by setting up a SSSA as follows:
i.
To ensure that all schools follow certain minimal professional and quality standards,
States/UTs will set up an independent, State-wide, body called the State School
Standards Authority (SSSA).
ii.
The SSSA will establish a minimal set of standards based on basic parameters namely, safety, security, basic infrastructure, number of teachers across subjects and
grades, financial probity, and sound processes of governance, which shall be followed
by all schools. The dimensions on which information has to be self-disclosed, and the
format of disclosure will be decided by the SSSA in accordance with global best
practices for standard-setting for schools.
iii.
The framework for these parameters will be created by the SCERT in consultation
with various stakeholders, especially teachers and schools.
iv.
Transparent public self-disclosure of all the basic regulatory information, as laid
down by the SSSA, will be used extensively for public oversight and accountability.
v.
This information will have to be made available and kept updated and accurate by all
schools, on the aforementioned public website maintained by the SSSA and on the
schools’ websites.
vi.
Any complaints or grievances from stakeholders or others arising out of the
information placed in the public domain shall be adjudicated by the SSSA.
vii.
Feedback from randomly selected students will be solicited online to ensure valuable
input at regular intervals. Technology will be employed suitably to ensure efficiency

33

<!-- page 36 -->

and transparency in all work of the SSSA. This will bring down significantly the heavy
load of regulatory mandates currently borne by schools.
b. The states/UTs are therefore expected to detail out the parameters for self-disclosure (including
on safety and security of children), establish an IT based mechanism for online public selfdisclosure, set up the SSSA, and empower it to adjudicate complaints and grievance arising out of
the self-disclosure.
c. The SSSA may be undertaken by states/UTs on priority.

34

<!-- page 37 -->

Chapter 5
Whole School Safety Approach
5.1

Whole School Safety: Concept







5.2

Schools are generally seen as spaces where communities of learners are expected to develop
in a safe and secure environment. School management, principal, teachers, other staff and
students, all spend around 1/3 part of a day and around 220 days in a year in schools across
the states/UTs in India.
Therefore, if classes are held for six hours a day, 220 days a year, and a child is awake on an
average for 16 hours a day, a child spends 22% of her waking time in a year in a day school.
In a residential school on the other hand, a child spends 60% of their life during schooling
years in the school.
Schools are thus accountable for a substantial chunk of the child’s life, and thus have a huge
responsibility to make the stay in schools of all children comfortable, joyful, secure and safe.
Therefore, it is important for the school that everyone concerned with school education
should understand his/her clear roles and responsibility towards school safety and security.
This will lead them to take appropriate action, not only preventive but also developmental,
so that risk of any kind of incident which harms students or staff will be eliminated. The
Whole School Approach (WSA) is based on a humanitarian and developmental approach
integrating a collective sense of responsibility and accountability towards children in
particular and society in general. Thus, involvement and participation of all stakeholders is
the key to WSA.
Why the Whole School Safety Approach?







5.3

Research shows that multi-component whole-school initiatives involving all the school
community are more likely to reduce crimes, violence and bullying behaviours, than singlecomponent programs, such as those involving only classroom curriculum or appointing
counselors.
A whole-school approach recognizes that all aspects of the school community can impact
students’ holistic development including health and wellbeing and that learning and
wellbeing are inextricably linked.
Given that children spend much of their first 15 years in a school environment, school is not
only the focal point of children’s academic development but also their social and emotional
development, since it is where they make friends and develops healthy relationships.
Whole School Safety: Scope



Safety and security are terms often used together to convey the same meaning; however,
these need to be understood separately to further understand the essential steps to ensure
school safety and security as a holistic process.

35

<!-- page 38 -->












‘Safety’ is understood as a protection against undesirable unintentional threats or dangers,
while ‘Security’ is understood as protection from undesirable intentional human behaviours
or actions. A safe school environment is, therefore, one that protects against all dangers and
creates an environment of harmony promoting the physical, socio-emotional and
psychological well-being of all.
The school environment can be understood as the total of all features of school that create
the learning environment or effective learning spaces.
School environment comprises the physical spaces, the norms, practices and culture and
relationships that create the psychosocial environment and links the school activities in such
a way that not only ensures safety and security but also effective and productive education
and achievement of school goals.
School’s physical environment encompasses school buildings, school grounds and
surroundings as well as service systems; the social environment includes the norms of
behavior, the culture, the discipline, the relationships and the interactions; while the
psychological environment encompasses the attitudes, feelings, values and behaviours
manifested and encouraged.
All this put together forms the school climate and is reflected in the perceptions and the
demonstrations of its members, positive interpersonal relationships, recognition of
individuals’ needs, success and even failures, support for and building of self-esteem in
students and staff and health and well-being of entire school community.
It needs the collaborative working of School Management (owners in case of private schools),
PTA, SMC/SMDC (in case of government schools), principals, teachers and all school staff, as
well as parents, students and the wider community.

A whole-school safety approach involves all parts of the school working together
and being committed to taking measures to make the school environment free
of crime and violence, bullying, trauma, anxiety, etc.
It is also about developing a democratic, fear-free and positive school culture
through redefining school beliefs and values, policies and norms of behaviour
and ensuring collective accountability through coordinated efforts in such a way
as to gradually lower the risk of violence and mental stress, etc.
Schools which recognize the importance of a whole-school approach take care
of not only physical infrastructure but also its formal classroom teaching and
learning and many more aspects of the whole-school environment.

5.4

Implementation of Whole School Approach:


Schools and educational authorities are expected to manage school safety appropriately not
only to prevent physical accidents and incidents but also to create an environment that
promotes whole school safety - consisting of physical, emotional and social well-being, both
individually and collectively.

36

<!-- page 39 -->



5.5

How will the Whole School Approach be implemented?










5.6

The other important requirement is to develop a sense of ownership among students and
staff that the place (school) they belong to is under their ownership, so they have to look
after it. This sense is termed as territoriality. Carter and Carter (2001)4point out that the
objectives of territoriality are mainly to increase a sense of pride and ownership felt by
learners, educators and other school personnel and put others on alert that they are coming
into a territory that is owned and cared for. It is about capitalizing on the specific strengths
of the schools while working on the needs.

Para 5.9 of the National Education Policy, 2020 also states that - Adequate and safe
infrastructure, including working toilets, clean drinking water, clean and attractive spaces,
electricity, computing devices, internet, libraries, and sports and recreational resources will
be provided to all schools to ensure that teachers and students, including children of all
genders and children with disabilities, receive a safe, inclusive, and effective learning
environment and are comfortable and inspired to teach and learn in their schools.
For implementing the whole school safety approach, following aspects of the school system
need to be addressed with a mind-set of: (i.) understanding children’ interest and (ii.) making
their stay comfortable and safe in school including outdoor camps, sports activities,
educational fairs and festivals etc.
A whole-school approach is about developing positive ethos and culture of school safety and
security– where everyone feels safe.
It involves working with families and making sure that the whole school community is
welcoming, inclusive and respectful.
It means maximizing children’s learning, providing them with a fear-free environment and
conditions, including infrastructure, which promote mental and physical health and
wellbeing across the school – through the curriculum, counseling support to students,
teacher-student relationship, leadership and a commitment from everybody.
Following paragraphs discuss various aspects of whole school safety approach more in detail.
These are not exhaustive in nature; however, they may be considered as the minimum
requirements.
Infrastructure safety and signage:

a. Under the whole school approach, availability and maintenance of essential physical
resources, is very crucial for making the physical environment of the school safe; mainly to
prevent injuries and securing equipment aimed at securing the school.
b. While this is the responsibility of School Management/Principal to provide safe and
comfortable infrastructure in school as per the norms already in place, however, school
heads, teachers, other staff, students and even parents need to be oriented for critical
observation of infrastructure facilities (entry, classrooms, laboratories, libraries, sports
4Carter, S.P. & Carter S.L. (2001). Planning safe schools. American School & University.

37

<!-- page 40 -->

c.

d.

e.
f.

g.

5.7

grounds, toilets, dispensary, (first aid arrangements), other secluded places and transport in
schools, etc. and reporting if there is a need of additional facility or maintenance of the
existing facility.
Further continuous supervision of every nook and corner in the school as well as access
control, signage, etc. also come under the whole school safety. There should be child safety
posters, POSCO E-Box details and Child helpline number on display in prominent locations of
the school.
Section 19 of the RTE Act, 2009 lays down norms for school buildings in the schedule of the
Act: (a) Schools should have at least one classroom for every teacher and one office cum store
room cum Head’s room (b) Barrier-free access (c) Separate toilet for boys and girls (d) Safe
and adequate drinking water facility for all children (d) Kitchen where Mid-Day Meal is
cooked (f) Playground (g) Arrangement for secure building with a boundary wall or fencing.
These need to be complied by all schools.
Schools should conduct mock drills on emergency preparedness and disaster management
for students and staff at least once a year.
Every school should prepare and display the School Safety Plan including a School Disaster
Management Plan containing classroom wise disaster sub-plans as per the template provided
by NDMA. The school and each classroom/room in the school must display the related
disaster management plan, clearly showing exits, etc.
Every school/school management/state/UT should also undertake/ensure the following:
i.
Display the School Safety Pledge at a prominent place in the school. Sample of School
Safety Pledge is at Annexure-VI.
ii.
Provide barrier-free infrastructural facilities and necessary equipment to differentlyabled children as per state/UT policy.
iii.
Provide sufficient and safe drinking water.
iv.
Provide sufficient number of well-lit, airy toilets with proper fittings, with safe and
secure access for boys and girls.
v.
Ensure compliance with Building Codes.
vi.
Make efforts to design more and more buildings with the provisions for
efficient/renewable energy, such as, solar power, use of solar cookers and biogas.
vii.
Provide boundary wall or a fence to mark the safe area.
viii.
Ensure that the secluded/isolated areas are well lit and there is frequent invigilation
of such areas.
ix.
Regularly monitor communication systems in the school such as landline phones,
safety alarms, etc. for their functionality.
x.
To the extent and only if and wherever possible, CCTV cameras may be installed at
the entry points, exit points and vulnerable locations in the School. Proper monitoring
and storage of recordings in such cases must be ensured.

Residential Schools:
a. Schools should ensure minimum living space for each inmate to be approximately 40 sq. feet
excluding kitchen, toilet and other common space.

38

<!-- page 41 -->

b. Sufficient number of well-lit and airy bathrooms with proper fittings and safe and secure
access;
c. Provision of functional sanitary napkin vending machines and incinerator in girl’s hostels;
d. Wherever hostels have internet facility, internet security provisions for cyber-safe usage may
be provided for.
e. There should be child safety posters, POSCO E-Box details and Child helpline number on
display in prominent locations of the hostel.
f. Every hostel should have a warden/in-charge teacher who can devote time for interacting
with students on a day-to-day basis concerning adolescence problems and other conflicting
situations if any.
g. Warden/in-charge teacher/resident teacher and all other staff/workers working in or
looking after a girls’ hostel should all be females only.
h. Sensitization of other hostel staff- guards, caretaker, staff in the mess, etc. to be done regularly
by the principal and concerned teacher on child and substance abuse.
5.8

Pre-School Centres (PSC):
a. PSC may be located on the ground floor, ensuring a child-friendly access.
b. Provision for a variety of activities like running, jumping, climbing, cycling, sand and water
play, gardening etc. may be made by ensuring the safety of children.

5.9

Psycho-social safety:
Psychosocial safety would entail providing a stress-free environment for conducive teaching
learning in the classrooms, which promotes positive student-teacher relationships, violence
prevention in schools and ensures socio-emotional development in students.
Unusual behaviors, continuous absence from classes or any other signs of stress or
depression, if observed, may be brought to the notice of parents for follow up with the
counselor at nearest Adolescent Friendly Health Clinics (AFHCs) / Health & Wellness Centers
(HWCs).
Schools should make provision for strong action against teaching and non-teaching staff in
case of any involvement in or negligence of physical or sexual violence, bullying and/or
corporal punishment, subjecting the child to physical or psychological harassment (Ref.
Section 17 of the RTE Act 2009 &Protection of Children from Sexual Offences Act, 2012).
Schools should ensure inclusive practices and under no circumstances subject any child to
discriminatory practices on the grounds of caste, creed, religion, disability and gender. (Ref.
Section 8 and 9 (c) of the RTE Act, 2009).
Schools should be sensitive towards the confidentiality of all personal issues shared by
students.
All the efforts, the humane qualities and other talents of the child should be appreciated
rather than just emphasizing on scores to reduce exam-related stress and suicidal tendencies.
As recommended in NEP 2020, group counselling and guidance can be provided through an
online, offline or blended mechanism. Students can also avail counselling through
Manodarpan (https://mhrd.gov.in/covid-19/index.html) an initiative of MoE, which mobilizes
psychosocial support for Mental Health and Well Being of Students during and post COVID

a.

b.

c.

d.

e.
f.
g.

39

<!-- page 42 -->

outbreak. A National Toll-free Tele counselling helpline- 8448440632 has also been
developed under Manodarpan, which should be widely disseminated.
5.10 Health and Physical Safety:
a. Sports, Yoga and physical activities/exercises must be encouraged for each child in an ageappropriate manner. The importance of physical fitness in productivity of an individual must
be explained grade appropriately to the child and the parents.
b. Every school should have a basic medicine/first aid kit and emergency medical care numbers
including ambulance services on display.
c. Schools should conduct health check-ups at least once in a year and maintain health cards.
The school health cards must be comprehensive covering both physical and psycho-social
aspects of child development and also include child’s medical history, any serious
ailment/allergy that child has, or other disability issues.
d. Schools should follow Central/State Govt. notifications/circulars/SOPs on Health and
Physical Safety issued from time to time.
e. Mid-day meal served should be as per the guidelines 5 on calorific value, Food Safety and
Hygiene.
f. Schools should sensitize students and parents on important health issues such as role of
nutrition in physical and mental growth, nutritious alternatives to junk food, the importance
of a balanced diet, etc., and its impact on child behavior and learning.
5.11 Cyber Safety:
a. Computer Education is an integral part of the modern-day education. The COVID-19
pandemic has given further impetus to leveraging technology for education through online
platforms, TV, radio, podcasts, etc. This entails internet access to students at a very young
age, which further warrants ensuring that the children are made aware about safe use of
internet and other aspects of cyber safety, including cyber bullying. Further schools should
also ensure the following as given at serial numbers 5.5.1(e)to 5.5.1(p).
b. Every school should have a clear mandate on access to, usage of internet and its security
checks,
while
the
child
is
within
the
school
premises.
(http://cbseacademic.nic.in/web_material/Manuals/Cyber_Safety_Manual.pdf)
c. Schools should follow the advisories issued by Ministry of Electronics & IT (MeitY) from time
to
time
e.g.,
National
Cyber
Security
Policy
(2013)
of
MeitY
(https://www.meity.gov.in/writereaddata/files/gazette_NCSP_2013.pdf)
d. Awareness of mental health and behavioral aspects of cyber safety along with cautious use of
internet by students should be encouraged.
e. NCERT and UNESCO have jointly developed guidelines on cyberbullying and internet safety,
“Safe Online Learning in Times of COVID-19”, which may be used for such orientation of
students on Do’s and Don’ts and the consequences of engaging in cyber bullying and violence.
(available at https://ncert.nic.in/pdf/announcement/Safetolearn_English.pdf).

5http://mdm.nic.in/mdm_website/Files/Guidelines/2015/Guidelines%20_Food%20Safety%20and%20Hygiene.pdf

40

<!-- page 43 -->

f.

5.12

Awareness may be generated about POCSO e-box and Childline for reporting concerns
relating to physical and cyber safety of students. These may be placed on the school website
and home page of the devices being used in schools as well.
Curriculum:

Curriculum encompasses pedagogy, syllabi, textbooks, all educational activities, assessment and
many other activities in which children participate for their holistic development.
a. It is the responsibility of Principals/School Heads and teachers to carefully analyze syllabi
and textbooks selected by the school (in case school is not following textbooks prescribed by
NCERT/SCERTs) on the following parameters:
i.
it should not promote any kind of discrimination based on caste, class, religion,
gender, ethnicity, language, etc.
ii.
it should promote sensitivity towards environmental protection, gender parity,
inclusion, ethical behaviour, etc.
iii.
it should promote healthy habits of eating, cleanliness and sanitation, reading,
working together, helping each other, collaboration in place of competition, etc.
b. In case school selects books not prescribed by NCERT/SCERT or those not prescribed by
concerned Secondary School Examination Board, the School shall put up a list of books
prescribed/selected by it on its website and notice board. It will also put up a written
declaration on its website, jointly signed by the Manager and the Principal in private schools,
and by the Principal or Head of school in government schools, to the effect that the school
owns the responsibility of having thoroughly checked and having gone through the contents
of the books prescribed by the school with respect to ensuring the parameters mentioned at
para 5.12 (a) above.
c. Further, the routine of the school must include enough space for dialogue, reflection and
discussion on school safety, on-road safety, healthy and nutritious food, adolescence issues, i.e., in the morning assembly, mid-day mealtime, sports ground, during the classes, etc. Space
should also be created in the school schedule for the training and drills to address disaster
management.
5.13

Teaching-learning Processes:

a. Classroom teaching-learning needs to be done in a learner-friendly environment, where no
student should feel that he or she is not respected by the teacher or peer on the grounds of
language, socio-economic background, caste, creed, gender, abilities, etc.
b. Group work, collaborative learning, project work, etc. need to be made regular features of the
classroom to move away from rote methods and bringing in learners’ experiences.
c. Teachers also need to have discussions (formal and informal) with students about school
safety, any emotional disturbance they are going through, any problem of peer, they have
come across, etc.
5.14

Assessment and Examination:

a. Assessment and examination in schools must be non-threatening.

41

<!-- page 44 -->

b. Students’ assessment needs to be seen as a process of appreciating what they have learnt and
bringing further improvement in learning, rather than a process which criticizes students for
what they have not learnt.
c. Moreover, all the assessments and examinations at the school level need to focus not only on
cognitive learning but also on psychomotor and emotional learning.
d. This also has implications for report cards. Report cards need to be transformed to focus more
on student’s strengths rather than on weaknesses. It needs to start with quantitative
statements on psychomotor and emotional learning of students and come to academic aspects
further making linkage among all other aspects. Para 4.35 of the NEP 2020 states that – “The
progress card will be a holistic, 360-degree, multidimensional report that reflects in great
detail the progress as well as the uniqueness of each learner in the cognitive, affective, and
psychomotor domains. It will include self-assessment and peer assessment, and progress of
the child in project-based and inquiry-based learning, quizzes, role plays, group work,
portfolios, etc., along with teacher assessment. The holistic progress card will form an
important link between home and school and will be accompanied by parent-teacher
meetings in order to actively involve parents in their children’s holistic education and
development. The progress card would also provide teachers and parents with valuable
information on how to support each student in and out of the classroom.” All states/UTs and
all schools will ensure moving towards this holistic system of giving feedback to each
child.
5.15

Parent-Teacher Interaction:

a. Since parents and teachers both own a major share of the development of a child’s
personality, both should curb their tendency of criticizing children on any ground –whether
cognitive, affective or psychomotor.
b. Both need to start their interactions by appreciating the strengths of the children. Both
parents and teachers need to work together to bring improvements in the weaknesses they
have observed.
5.16

Principal-Staff Interactions:

a. There should be regular interaction among Principal, teachers and staff on the issues related
to school safety and security.
b. Principals need to carefully examine the report from every teacher and staff about any
problem related to infrastructure safety/students’ safety/emotional/etc. aspects or medical
facility in the school.
c. The Principal should share the infrastructure related report with SMC/SMDC/local
administration (in case of government schools) or School Management (in case of Private
schools) and take immediate action on the essential points without any negligence.

42

<!-- page 45 -->

5.17

Training of School Personnel:

a. It will be the responsibility of School Principals/Heads and Management to ensure that
teachers and other school staff are trained on the whole school approach to safety and
integration of safety and security aspects in education. They should be well aware of all legal
provisions in this regard too.
b. Teachers should also be trained to address unseen situations under different disaster
conditions and keep the children safe.
c. Training of all general teachers on dealing with emotional aspects of children must also be
arranged to provide essential counseling to children. However, it is advisable to also have a
regular qualified counselor in school.
5.18

School preparedness for disaster:

a. Every school must have its own school disaster management plan.
b. The plan must identify the first responders and lay down their roles and responsibilities,
along with the roles and responsibilities of all concerned stakeholders. The first responders
may be given requisite training.
c. The inventory of school resources available for responding to a disaster must be listed.
d. The school disaster plan must be disseminated to all concerned.
e. Utilize the opportunities provided by social media and mobile technologies for dissemination.
f. Drills must be conducted in school to familiarize all to this plan and the plan must be updated
frequently.
g. The CBSE Teachers Handbook at pages 191-198 and CBSE Principal’s Handbook at pages
136-144 give in great detail how planning and capacity building can be done for disaster
preparedness and management. These resources may also be utilized.
(Links: http://cbseacademic.nic.in/web_material/Manuals/Handbook_for_Teachers.pdf and
http://cbseacademic.nic.in/web_material/Manuals/Principals_Handbook.pdf)
5.19 Other Recommendations for schools to comply:
a. Every child in the school should have an identity card on her person that displays the child’s
photo, name, class in which the child is studying, school name, parent name and mobile
number, residential address, blood group, etc., on it.
b. Children and teachers should ensure the identity cards are being worn by the students during
school hours and on their way to and from school.
c. Every school should maintain an updated contact details list of parents/guardian for every
student of the school.
d. Schools can consider establishing Youth Clubs and/or Topic Circles as a platform for
strengthening self-esteem, confidence and empowerment amongst students.
e. Life skill-based education for students across all levels in schools may be taken up
(integration in the curriculum as also stand-alone enhancement programmes).
f. Schools should have a recruitment and verification procedure for all teaching and nonteaching staff including contractual employees.

43

<!-- page 46 -->

g. Parent Teacher Meetings should always start with
discussion on unique things about the Child.
h. All vehicles used by children for transportation to
and from the school should have a fitness certificate
and the school’s name, address and telephone
number should be prominently displayed on these
vehicles.
i. Parents may be encouraged to use school buses
rather than private vans, if found economically
equally or more viable. Schools should also ensure
adequate and regular maintenance of school
vehicles.
j. There should be a responsible staff member
assigned to be in the school bus/vehicle to make a
safe arrangement for transporting, boarding and
deboarding of children to and from the school bus.
5.20

Developing Safe and Secure Schools: System
Functionaries at State, District level and at
school management level:

9-month Diploma in
School Counselling
SCERT Nagaland has
introduced a 9-month
Diploma course in School
Counselling has been
designed and introduced
from 2018 with the primary
objective
to
train
teachers in theory and
practice
of
School
Counselling so as to
ensure that every school
has at least one male one
female School Counsellor.

a. Constitution of a School Management Committee (SMC) in case of a Government School, as
per Section 21 of the RTE Act 2009.
b. As per section 21 of the RTE Act, 2009, private schools are exempted from formulating SMCs.
The private schools defined under section 2 (n) (iv) of the RTE Act, 2009 should have a Parent
Teachers Association; meetings of which should be held regularly.
c. Pre-School Centres (PSCs) should preferably be in the same premises of the primary school
or it should be close to or adjacent to a primary school.
d. Information about NCPCR online helpline, as stated in Rule 26 of the RTE Rules, 2009, to
register complaints regarding violation of rights of the child under the Act, must be
disseminated to all students and all parents.

The National Commission for Protection of Child Rights (NCPCR) has a
dedicated/ transparent Online Complaint System, e-baalnidaan
(http://www.ebaalnidan.nic.in/), to ensure timely/speedy redressal of
complaints of various violations and deprivation of child rights. Further,
NCPCR
has
launched
POCSO
e-Box
(https://www.ncpcr.gov.in/index2.php) for easy and direct reporting
of sexual offences against children as well as timely action against the
offenders under the POCSO Act, 2012.

44

<!-- page 47 -->

e. The school premises should be used only for education and Samajik Chetna Kendra activities
following proper guidelines/SOPs to be issued by state/UT government in this regard.
f. Funding provision should be made by private school management/state governments for
conforming to the provisions of the guidelines for safe and secure schools.
g. Capacity building of Teacher Educators from SCERTs, DIETs, IASEs, CTEs, etc., must be
undertaken on different issues related to safety and security.
h. Capacity building of Principal, Teachers and other Administrative staff must be undertaken
on different issues related to safety and security through SCERTs, DIETs or NCPCR.
i. The UDISE+ and Performance Grading Index of MoE will include parameters on school safety
and security for effective implementation and follow up of the Guideline.
j. For Central Board of Secondary Education and other School Boards and School Affiliating
Agencies:
i. School Affiliation bye-laws need to be revised incorporating safety measures for
schools and hostels keeping in view the whole school safety approach and also the
existing acts, policies and guidelines of appropriate authority.
ii. Reformulated bye-laws need to be disseminated to all the affiliated schools for
compliance in stipulated time decided by the concerned board or agency.
5.21

System Functionaries at State and District level: Disaster Management

a. The State Governments have the basic mandate for management of disasters and executive
actions are taken at the district level with the District Collector playing a pivotal role.
Implementation of the National Disaster Management Guidelines 6 on School Safety Policy
must be ensured by the State and UT Governments and the Private Management Schools
under supervision and monitoring at District level.
b. Compiled quarterly reports should be submitted by the State to NDMA and Department of
School Education and Literacy within one month after the end of the quarter.
c. In case of emergencies, the guidelines/advisories/SOP issued by Ministry of Education;
Ministry of Health & Family Welfare; Ministry of Home Affairs; and/or other concerned
Authority should be followed.
d. For building construction/development works states/UTs to ensure use of Vulnerability
Atlas for reducing the vulnerability in the given area and Tenders may reflect the same,
wherever required. The Vulnerability Atlas created by Building Materials and Technology
Promotion Council (BMTPC) was updated in 2019. This atlas gives the latest information
regarding vulnerability of housing stock to earthquakes, cyclones; floods, landslides and
thunderstorms.
5.22

COVID-19:

a. The COVID-19 pandemic has caused an unprecedented public health emergency, affecting
almost all countries and territories globally since early 2020. The only effective and
6NDMA guidelines, February, 2016

45

<!-- page 48 -->

preventive measure for this disease as suggested by the health ministry is wearing of face
mask, hand hygiene and social distancing.
b. All schools must follow guidelines issued by the Ministry of Health, Ministry of Education and
the State/UT administration, from time-to-time, in this regard.
c. The World Health Organization (WHO) has also developed a document on Mental Health and
psychosocial considerations during the COVID-19 outbreak to help deal with the stress
generated
due
to
the
pandemic
(https://www.who.int/docs/defaultsource/coronaviruse/mental-health-considerations.pdf).

COVID-19 related health and Safety SOP/Guidelines for school
re-opening
After issue of MHA guidelines for unlock-5, on 5th October, 2020, MoE has
issued detailed SOP/guidelines regarding health and safety precautions
for reopening of schools. Part I refers to the health and safety aspects for
reopening schools. These are based on the prevailing instructions of
Ministry of Home Affairs, Ministry of Health and Family Welfare and Ministry
of Education with regard to health and safety protocols, and are to be
implemented by adopting/adapting in accordance with the local
situation in all states/UTs. The guidelines can be accessed at:
(https://www.mhrd.gov.in/sites/upload_files/mhrd/files/SOP_Guidelines_for_
reopening_schools.pdf)

46

<!-- page 49 -->

WHOLE SCHOOL APPROACH
EXAMPLE - FOR SAFETY AND PSYCHOSOCIAL WELLBEING

Availability &
Maintenance of
Physical
Infrastructure

Promoting
Conducive
Environment in
school for
Psychosocial
Wellbeing

Stress and trauma free
school environment (as
per RTE Act 2009)

As per the
guidelines
issued
by
NDMA
and
allied agencies
on
the
availability of
and
maintenance
of
physical
infrastructure

Building
Relationships
with all
Stakeholders for
identification,
and early
Intervention

Promotion of effective
Family-School
Partnership

Exercise/Play/Yoga
(Spiritual Wellbeing)

Forming
Educators
(PER)

Balance Diet /Nutrition
First Aid and CPR training

Peer
Network

Early Identification of
Common
emotional
and
behavioral
problems

Equipped Medical aid
Basic Health Education
Awareness of Child Rights
& Protection

Holistic support of
Special Needs Children

Prevention of Physical,
Emotional and Sexual
Abuse

Well defined Roles
and responsibility of
class
teachers,
counselors, special
educator, etc.

POCSO Act Orientation
and Implementation

Advocacy and
Capacity
Building

Principals
&
Management
Personnel
Teachers
(Ambassadors &
Representative
s)
Conservancy
Staff
(Nonteaching staff)
Parents/
Families
Students (Peer
educators/
Representative)

* Poster, AV, charts and handout need to be developed and maintained along with videos and short films for promotion
and intervention.

47

<!-- page 50 -->

Chapter 6
Whole School Safety Approach:
Roles and responsibilities of stakeholders
This chapter presents guidelines, roles and actions to be taken on the part of school management,
teachers, other school functionaries, community members and parents for implementing the wholeschool approach of safety and security of children in school.
While safety and security of the child is the prime focus, the guidelines emphasize only on concerning
safety issues that are either school-based or are related to school transportation or related to outside
visits organized by the school. Monitoring violence outside school hours/premises can however not
be addressed. Therefore, school safety should not be misinterpreted as moral policing.
Following paragraphs lay down the actionable roles and responsibilities of all major stakeholders
who are responsible for the effective functioning of the whole school safety approach, including the
provisions already mentioned in chapter 4 and 5.
6.1

Roles and responsibilities of School/School Management in Whole School Safety:
a. In case of occurrence of any untoward incidents e.g., physical or sexual violence, bullying,
injury, etc., the school management should report to the concerned authorities and
immediately take necessary action and also corrective measures so that the incident should
not get repeated.
b. In view of the present COVID-19 situation, equipment and material such as thermal scanners,
masks, sanitizers, etc., may be made available in school. Social distancing norms have to be
followed with strict compliance till the COVID-19 situation normalizes.
c. The School Management should ensure safety of physical infrastructure of the school, including:
i.
Emergency maintenance i.e., repair or replacement of facility components or
equipment requiring immediate attention such as school building- roof,
windows; emergency alarm; communication system; potable drinking water
systems; electrification system, etc.
ii.
Routine maintenance, which includes repair, replacement and general upkeep of
the grounds and buildings.
iii.
Preventive maintenance, which is the scheduled maintenance of equipment
installed in schools so as to ensure that equipment is always in working order
and provides safety.
d. Informing competent local authorities and taking necessary action in case of sale of tobacco
or any other intoxicating substances is noticed within 100 yards of the school premises.
e. Ensure that quarterly inspections are conducted following the checklist given in NCPCR’s
Manual on Safety and Security of Children in Schools on indicators for day and boarding
schools and/or comprehensive checklist given at Annexure-III of this guideline and upload
the reports on the school’s website regularly.

48

<!-- page 51 -->

f.

At the beginning of the session, School/School Management should:
i.
Conduct meeting for the development of a School Safety Plan.
ii.
Ensure the constitution of the School Safety Committee (SSC) within one month.
g. Regular conduct of disaster related mock drills in collaboration with experts from
NDMA/NDRF/Fire stations/local appropriate authorities.
h. Ensure maintenance of health cards, basic medicine, first-aid kits and regular check-ups.
i. Declare and monitor School as Corporal Punishment Free School and Zero Tolerance to
Student’s Abuse and Bullying.
j.

Developing a system wherein students can drop their complaints or share observations or
ask questions with regard to child abuse, drug use, anxiety, curiosity (Complaint/Help Box).
It is the role of the Principal to address or arrange to address each of these complaints to
ensure safety and security.
k. No hawkers should be allowed inside the school. However, being vigilant about the presence
of shopkeepers in the school premises, if any.
l. Set norms for maintaining regular hygiene (both personal and school hygiene) and
sanitization routines.
m. School/School Management should ensure the orientation cum training of Principal,
Teachers, Staff, Students and Council members on essential drills related to fire, earthquake,
first-aid and acts such as POCSO, Cyber Security, etc.
n. While government schools in some of the states such as Assam, Goa, Delhi, etc. do follow Code
of Conduct under the State Education Act, management of private schools need to come out
with code of conduct for the members of the management board, PTA, school principal,
teachers and students based on the code of conduct already formulated by these States. Code
of conduct formulated by Kendriya Vidyalaya Sangathan can also be seen in this context.
6.2

Roles and responsibilities of Principal/ School Heads:
a. Orient all teachers and students at the beginning of the session regarding the school safety
plan using the morning assembly platform.
b. Regular meeting with teachers and members of the School Safety Committee to discuss issues
related to school safety and security and decide appropriate actions.
c. Ensure display of the School Safety and Disaster Evacuation plan at prominent places in the
school.
d. Regular health check-ups to be conducted in school and teachers to be instructed to maintain
health cards.
e. Orienting teachers, parents and students on the purpose and process of conducting ParentTeacher Meetings and its impact on all-round development.
f. Sensitizing parents and teachers on releasing child’s stress and anxiety by focusing on
uniqueness, strengths, his/her coping strategies, attitudes and values along with the
academic areas of improvement and making PTMs as Child-Parent-Teacher-Dialogue (CPTD).
g. In case of a complaint against a teacher or other staff of the school, conduct a discreet enquiry
to protect the identity of the victim/complainant.
h. Equipping the school with basic supplements and medicines.

49

<!-- page 52 -->

i.

j.

Daily monitoring of maintenance of sanitation and hygiene particularly in washrooms and
drinking water areas, and generally in the entire school premises, including
classrooms/canteens/laboratories/libraries/etc.
Identifying students with positive leadership qualities and making them part of the AntiBullying Task Force or the School Safety Committee to act as peer counselors and educators
to develop a bullying and violence-free school campus.

6.3

Roles and responsibilities of Teachers:
a. Supporting the Principal in gently orienting students towards the safety and security in
general.
b. Teachers should also help set classroom norms and standards that support child safety and
security.
c. Collaboratively develop (with students) healthy classroom norms and conduct of behavior
which ensures a safe and secure classroom environment.
d. Encourage the habit of inquiry and sharing through placing of ‘Question box’/ ‘Opinion box’
and addressing regularly the curiosity and problems of all children.
e. Conduct relaxation exercises such as mindful breathing/yoga either in assembly or in
between different periods to improve concentration and reduce stress.
f. Being sensitive in the use of language and refrain from passing judgment on child behaviors
to nurture positive attitudes and relationships amongst and with children.
g. Being vigilant and observant about unusual behaviors and signs of stress or depression in
students and informing and holding discussions with parents accordingly.
h. Highlight the strengths of every child not just within the classroom but also in the PTMs so
as to promote self-esteem and confidence. Appreciate efforts more than the scores to reduce
the exam-related stress which is increasingly affecting the child and parent psyche.
i. Engage in inquiry and dialogue in classrooms around challenging stereotypes among
students with regards to gender, caste, class, ethnicity, language, etc.

6.4

Roles and Responsibilities of the Parents:
a. Developing a friendly relationship with the child so as to have hesitation/fear-free dialogues.
b. Connecting with schools and school related activities so as to develop a symbiotic
relationship.
c. Regularly attending the Parent Teacher Meetings and PTA meetings (in case of membership).
d. Following guidelines circulated by the school from time to time on child safety and security.
e. Ensure that their wards leave for schools with masks and sanitizers and are following the
safe distance and hygiene norms during school hours.

6.5

Roles and Responsibilities of Warden:
a. Creating a friendly and trustworthy environment in the hostel and regularly interacting with
students.
b. Implementing rules and code of conduct (provided by the school authority) including timings
for various activities.

50

<!-- page 53 -->

c. Building the capacity of other hostel staff (canteen staff, cleaners, caretakers) on various
aspects of safety and security.
d. Wardens/ Caretakers and House master/Assistant Housemasters to take the onus and
responsibility of work assigned in context of safety and emotional well-being of students.
e. Maintaining Diary with updated phone numbers of School Principal and staff, teachers,
school bus drivers, parents of students, etc.
6.6

Roles and Responsibilities of a Counsellor:
a. Building strong rapport and trust with all students to encourage fear-free interaction and
dialogue.
b. The Counselor should ensure confidentiality of all personal issues shared by students in
confidence.
c. Being vigilant about unusual behaviors and intervening to give professional help.
d. Counselors along with HMs, AHMs, teachers, wardens, should facilitate students to build
personal connectivity/bond with each other, understanding their views and helping them to
clear their confusions and cope with their challenges by realizing their strengths and building
resilience.
e. To support holistic development of the students by empowering them with psycho-social
competencies, instilling responsible behavior and inculcating skills for help seeking so as to
ensure their preventive, curative and developmental needs and a safe and healthy childhood.

6.7

Roles and Responsibilities of Students:
a. Every student needs to follow the guidelines on the safety and security issued by the school
principal and teachers, from time to time.
b. In case, students observe tobacco/drug/related substances supply activities outside the
school premise or inside the premise, they may intimate the school authorities through the
Complaint Box.
c. Senior Students may discuss various issues like bullying and sexual harassment with other
younger students under guidance of teachers.
d. Act as peer support or peer educator for other students, wherever possible.
e. Stay physically active.
f. Not hesitate to seek support from teachers/Counsellors/parents when required.

6.8

Roles and Responsibilities of Non-teaching Staff:
a. Every staff is a stakeholder in protection of child rights and safety.
b. Non-teaching staff to ensure that they are well informed on all aspects of safety and security
of students and comply with all aspects.
c. Being observant to their Inter-personal relationships, disposition towards students and staff,
temperament, effective communication, conflict management, risky behaviors, knowledge,
and awareness of Child rights and safety etc.
d. Be vigilant about infrastructure safety.
e. Inform school head of untoward behaviour by any stakeholder in the system.

51

<!-- page 54 -->

6.9

Roles and Responsibility of School Nurses/Health Workers/Visiting medical personnel:
a. Monitoring and Supervision through regular visits in the school.
b. Nurses/Visiting Doctors/Health workers associated with the school can provide education
on important health issues such as sanitation, hygiene including menstrual hygiene,
substance misuse, mental health and healthy nutrition (alternatives to junk food, importance
of a balanced diet etc.) to the canteen supervisors, students and stakeholders.
c. Nurses/Visiting Doctors/Health Workers associated with the school along with Physical
Education Teachers may promote Yoga and practice of Meditation.
d. Nurses/ Visiting Doctors/Health Workers associated with the school along with Physical
Education Teacher to promote FIT India Campaign by organizing intra class activities.
e. Nurses/Visiting Doctors/Health Workers associated with the school to participate in annual
health check-up of 100% students and maintaining the records of past medical history for all
students and staff.

52

<!-- page 55 -->

Chapter 7
Developing a Safe and Secure Society: Multi-sectoral Approach
It is not only schools, but also homes and society; not only Ministry of Education, but also other
ministries and departments that need to share the responsibility of developing safe and secure
society in which the school functions. This chapter presents recommendations for the departments
and ministries other than School Education.
Developing Safe and Secure Society (Inter - Department Recommendations):

In January, 2019 a state-wide ban on PUBG was issued across
primary schools in Gujarat owing to children’s studies being
adversely affected. Even in the colleges of Mumbai, the users
of Wi-Fi network have been restricted from accessing PUBG
game. The National Commission for Protection of Child Rights
also recommended barring the game for its violent nature.
PUBG has now been banned in India.

7.1
a.

b.
c.

d.

7.2

Law and Justice:
Speedy adjudication and enforcement of Laws that prohibits all forms of violence against
children including corporal punishment, sexual abuse, exploitation of children, physical
violence and bullying, etc.
Speedy adjudication and enforcement of laws relating to harmful substances/products, such
as cigarettes, e-cigarettes, alcohol, firearms, narcotics, etc.
Incorporate changes in existing laws to include bullying and cyber bullying, sexting, addictive
and violent internet video games and exposure to inappropriate content on internet as legal
offence.
Spread awareness about the laws/acts, provisions for support and consequences for
contributing to school-based violence amongst teachers, students and parents/families in
collaboration with other related ministries.
Women and Child Development:

a. Providing specialized help and support for families at risk of violence.
b. Proactively providing support to victims of sexual abuse or violence cases in schools.
c. Conduct of awareness and sensitization programme, preparing e-modules and
disseminating on sexual abuse and violence, parenting, nutrition, safety of girl child, etc.

53

<!-- page 56 -->

The Ministry of WCD is implementing a Centrally Sponsored Scheme,
“Child Protection Services”, under the umbrella scheme of Integrated
Child Development Scheme, to provide Institutional and Noninstitutional safety net for vulnerable children as envisaged under the JJ
Act. The scheme supports 24x7 outreach helpline service for children in
distress. This service is available through a dedicated toll-free number,
1098, which can be accessed by children in crisis or by adults on their
behalf from any place in the geographical location of India. Currently,
CHILDLINE service is functional in 579 locations while Child Help Desk
(CHD) has been set up at 130 major Railway Stations.

7.3

Electronics and Information Technology:
a. Surveillance and censoring of different Apps, Gaming Sites and Digital Serials and Movies for
monitoring offensive and vulgar content encouraging physical or sexual violence and abuse.
b. Formulating cyber security policies appropriate for school and college going children.
c. Organize awareness programmes with Experts/Law Enforcement Officers to explain the
dangers and Implications of flouting the Law.

7.4

Health and Family Welfare:
a. Conduct health safety, fitness and nutrition awareness camps in schools and towns at least
once in a year.
b. Integrate prevention of violence against young children in routine health delivery; engage
with adolescent girls and boys; strengthen referral services.
c. Plan T3 (Test, Treat, Talk) camps on Anemia Mukt Bharat (AMB) campaign.
d. Conduct training programmes for school staff in general first aid and CPR.
e. Ensuring free medicines, supplements and regular health check-up in schools through RBSKs
(Rashtriya Bal Swasthya Karyakram initiated by the Ministry).
f. Visits of ASHA and counsellors from AFHCs/HWCs to local schools for awareness generation
and general interaction with parents.

54

<!-- page 57 -->

Accredited Social Health Activist (ASHA)
The ASHA programme has been in place since 2005 as a part of the National Rural
Health Mission, which in 2013 became National Health Mission by adding Urban areas
as well. Roles of ASHAs includes: facilitating the community to seek care from public
health system, act as an activist to create awareness on entitlements and services
within the health systems and act as community level care provider for basic
ailments. ASHA are volunteers selected from within the community and get
remuneration based on the financial and non-financial incentives as per the tasks
performed. She has helped built trust in the public health systems. The total numbers
of ASHAs (Rural & Urban) are 9.85 lakh as per NHM MIS report dated 31st December,
2020.

7.5
a.

b.
c.
d.
e.
f.

7.6

Home Affairs:
Implementation and enforcement of Laws that prohibits all forms of violence against children
including corporal punishment, sexual abuse, exploitation of children, physical violence and
bullying, etc.
Implementation and enforcement of laws that limit access of students to harmful products,
such as cigarettes, e-cigarettes, alcohol, firearms, narcotics, substance abuse, etc.
Sensitization and orientation programmes for police personnel on approaches to deal with
cases of abuse against women and children.
Administrators, teachers and students must be trained on self-defence practices as a part of
community policing.
Developing an easy and child sensitive approach of enquiry in case of occurrence of child
abuse to encourage children and youths to report crime.
Developing collaborative training programs with schools within local jurisdiction about legal
provisions and support against any kind of abuse and about the process of reporting. This can
also be taken up as a part of community policing.
Information and Broadcasting:

a. Censoring of advertisements, tele-serials and cinema content promoting any kind of
discriminatory practices and provoking physical and sexual violence and/or abuse.
b. Running active media campaigns for generating momentum in the country/society around
Safety and Security of children.
c. Creating special social media/media campaigns through its Media Units about acts related to
child’s safety and security strictly, not only in schools but also in the entire society.

55

<!-- page 58 -->

7.7

Panchayati Raj:
a. Local governance in rural areas can play an important role in linking parents and
communities with ICDS, health, education and child protection services.
b. Dissemination of all children related services with high levels of coverage.
c. Play the role of a nodal agency in rural areas in ensuring universal access to child-related
services; strengthen linkages between them to ensure children’s and women’s safety; work
on campaigns to change social norms around the use of violence, and strengthen institutions
of care and justice.
d. Critically look at the possibility of convergence of schemes and allocation of funds to schools
for improvement of infrastructure, providing barrier free access and ensuring safety and
security of children.

7.8

Urban Development:
a. Local governance in urban centers can play an important role in linking parents and
communities with ICDS, health, education and child protection services.
b. Dissemination of all children related services with high levels of coverage.
c. Play the role of a nodal agency in urban areas in ensuring universal access to child-related
services; strengthen linkages between them to ensure children’s and women’s safety; work
on campaigns to change social norms around the use of violence, and strengthen institutions
of care and justice.
d. Critically look at the possibility of convergence of schemes and allocation of funds to schools
for ensuring safety and security of children.

7.9

Higher Education

a.

b.
c.
d.
7.10

Even though majority of the students in Higher Education institutions are adults, it is the duty
of the Institution to have a Campus Safety and Security Plan in place that is available on the
public domain.
The Plan must include safety assessment by students.
Departments of Higher Education to ensure that such Plans are made and implemented by all
Higher Education Institutions (HEI) in accordance with prevailing laws.
All HEIs to undertake short (2-3 hours) modules on personal and campus safety for all its
students.
Social Justice and Empowerment

a. Making schools aware of the special safety concerns of children with disabilities.
b. Making schools aware about any special provisions for the protection and safety of these
children.
c. Conduct awareness programmes for teachers, parents and students on the harmful effects of
drugs, impact of doping on budding athletes and also about counseling and rehabilitation of
drug addicts.
d. Provide safe transportation facilities to schools for children belonging to tribal belt and rural
remote areas with adequate monitoring.

56

<!-- page 59 -->

7.11

Labour and Employment

a. Conduct awareness programmes for parents and teachers to protect small children from
child labour.
b. In case there are school going children above the age of 16 years supporting their parents by
working at different places, then such students and their parents must be aware of the
provisions related to their safety and security.
7.12

Sports, Youth and Cultural Affairs

a. Create awareness in schools about safety provisions for children participating in state,
national and international level events.
b. Ensure medical facilities to deal with sports injuries are available nearby the schools.
7.13

Skill Development and Entrepreneurship

a. Creating awareness in schools about the safety concerns while dealing with various
vocational courses- job roles-in which field visit, experience in industry, etc. are required.
b. Ensure that job roles approved for schools must not have the use of heavy machines or
dangerous chemicals.
7.14 Drinking Water and Sanitation
a. Ensure supply of Safe piped drinking water to schools.
b. Create awareness among adolescent girls in schools about Menstrual Hygiene and Safe
disposal of Menstrual Waste.
c. Undertake Swachchata drives and related competitions.
d. Develop and provide engaging educational material to create awareness amongst students.

57

<!-- page 60 -->

Chapter 8
Implementation Plan
8.1

DRISHTI:
a. An overall implementation plan for making schools safe and secure ‘DRISHTI’ (acronym
stands for Dissemination, Roll-out, Interventions, Support, Handholding, Tracking,
Incentivizing) has been worked out with seven basic steps as follows:

i.

Dissemination


These guidelines need to be disseminated to all the concerned officials in mentioned
sectors including Education Secretaries in all the states/UTs by the MoE, relevant boards
of education, the state training agencies like SCERTs and DIETs with a request to guide
officials and institutions including schools, to take actions in the line of suggestions given
in the guidelines.

ii.

Roll Out
 These guidelines need to be made available to every government and government-aided
school by the SCERT/Department of Education.
 These guidelines need to be made available to schools under all managements including
government, aided, private, schools under KVS and NVS as also other residential schools
like Ashram schools, Eklavya Model schools and Sainik Schools respectively.
 Along with it, schools should draw flexibility in using contextual approaches in the
implementation and roll-out of the guidelines to ensure need-based interventions.

iii.

Interventions
 Capacity Building of Resource Group members, teachers under all kinds of schools, school
leaders and faculty from SCERTs/ DIETs on school safety and security norms, guidelines
and provisions.
 Designing and developing need-based interventions through a multi-tier system for
prevention, promotion of wellness, professional treatment etc.

iv.

Support
 Support through the development of material and modules, online training material for
building competencies in basic counseling skills as also in enhancing life skills and
ensuring a healthy school climate.

v.

Handholding
 Hand holding of each of the schools, whether affiliated to CBSE or state boards, to be done
by state/UT governments through SCERTs and DIETs in collaboration with DEOs, BEOs,
and through a network of school clusters not only for the implementation of guidelines

58

<!-- page 61 -->

but also for sharing of training resources, guiding awareness programmes and safety
drills, walks and external monitoring of safety norms.
vi.

Tracking
 The UDISE+ includes components on School Safety and Security; with few additional
items, it would be ready for online tracking of the status of school safety and security
across the country with annual Safety Inspection Reports being uploaded by every school.
 DEOs and BEOs may track safety and security measures in schools during their routine
or surprise visits.
 In case of gaps in school security and safety at the school level, Principal of the School
may be informed immediately for taking necessary action. If the gap is due to funding or
state initiative, the state authorities may accordingly be informed by the respective
DEOs/BEOs concerned.

vii.

Incentivizing
 Schools which have gone beyond the prescribed norms in conducting regular Safety
Inspection at their level and during visits are found to have harmonious school climate
could be appreciated through a letter from the DEO/ Collector/ Secretary, School
Education and schools may be given positive titles like SAJAG (Alert) Schools,
SAMVEDANSHEEL (sensitive) schools and/or AATMIYA (Harmonious) schools
(suggestive only). They may be issued a certificate for the same under Samagra Shiksha
by the state authorities or by concerned school boards to which the schools are affiliated.

59

<!-- page 62 -->

Making Schools Safe and Secure:Guidelines for Implementation

School Safety and Security - Plan of Action

Assess

Develop

Implement

Monitoring

Dissemination

 Government departments, SCERTs and DIETs
 Boards of Education and Managements
 All managements of Schools

Roll-out

 All managements of Schools
 Constituting School Safety Committee
 Integrating safety in classroom transactions

Intervention

Support

Hand-holding

Tracking

Incentivizing

Modify

 Capacity building of teachers and students
 Orientation programs for Parents
 Need based interventions
 Counselling
 Preventing the at risks
 Promoting wellness for all
 Support state agencies for clear adherence to norms
 Support teachers and principals through capacity building
 Supports parents and students through awareness and orientation programs
 Schools in conducting safety inspections
 DEO/BEOs for training and capacity building of stakeholders
 Private managements through DIETs and SCERTs
 U-DISE data for submission of safety related data
 Routine and surprise visits to include safety checks
 Progress charts in health and wellness
 States/districts with 100% schools uploading their Safety Inspection report on
their website
 Best Practices of Schools and sharing on national platforms
87
 Awarding Schools with titles like: Alert/Sajag Vidhyalaya,
Sensitive/SamvedansheelVidhyalaya, Harmonious/'AatmiyaVidhyalaya'

<!-- page 63 -->

Annexure-I
STATE SPECIFIC PROVISIONS
State Act (Year)
Andhra
Education
(1982)

Provisions

Pradesh Chapter IV – Primary Education and its Implementation
Act
Section-14 Children not to be employed so as to prevent them from
attending school: - No person shall employ a child in a manner which
shall prevent the child from attending an approved school.
Section-24 Appointment and removal of manager of private
institution: - (1) The management of every private institution shall be
constituted in such manner and shall consist of such number of members
as may be prescribed: (2) …………….
(3)(a) ………….
(b) Where the competent authority is satisfied that the manager alone is
responsible for the lapses or irregularities of the institution, action shall
be taken against him by the management, as recommended by the
competent authority.
(4) ……………
(5) ……………
(6) For the removal of doubts it is hereby declared that any failure or
negligence on the part of a management to take action against the
manager as required under Clause (b) of sub-section (3) or to nominate
another person as manager under sub-section (4) shall constitute an act
of mismanagement and action shall be taken against the private
institution under this Act accordingly.
Section- 25 Duties of manager of private institution
Section-26 Private institution not to be closed down, etc., without
sufficient notice: - (1) Save as otherwise provided in this Act, no private
institution shall be closed down or discontinued, unless a notice of not
less than one academic year expiring with the end of any academic year
and indicating the intention to do so, has been given by the manager to
the officer authorized by the competent authority in this behalf.
(2) If any manager fails to give notice as required under sub-section (1),
he shall, on conviction, be punished with fine which may extend to [five]
thousand rupees or with simple imprisonment which may extend to [one

61

<!-- page 64 -->

State Act (Year)

Provisions
year] or with both and with a fine of [rupees one hundred] for every day
of further default.
Section-30 Parent-teacher association: - (1) There shall be parentteacher association for every educational institution other than an adult
educational centre.
(2) The composition and functions of the parent-teacher association
shall be in accordance with such rules as may be prescribed.
Section-31 Inspection of educational institutions: - (1) The
Government or the competent authority may authorize any officer not
below such rank as may be prescribed to inspect any educational
institution in the State.
(2) The officer authorized under sub-section (1) shall exercise general
powers of inspection over the working of the educational institution.
(3) The manager and the employees of the educational institution shall
at all reasonable times be bound to afford to the aforesaid officer all such
assistance and facilities as may be required for the purpose of such
inspection.
(4) The manager shall comply with such directions or suggestions as may
be given by the competent authority on the report of the aforesaid
officer:
Provided that the manager aggrieved by any such direction or suggestion
may appeal, within thirty days from the date of receipt of such direction
or suggestion to the prescribed authority whose decision on such appeal
shall be final.

The Assam Primary Section-19 Penalty for employment of children or interference with
Education
Act their attendance at school- shall be prosecuted by the education
(1926)
committee, and shall on conviction before a magistrate be liable to a fine
not exceeding rupees ten for a first offence and not exceeding rupees
twenty-five for each subsequent offence.
A. The Assam Non-Government Educational
(Regulation and Management) Act, 2006.

Institutions

Section-3 Power of the State Government to regulate nongovernment educational institutions
1) The State Government may regulate all the non-government
educational institutions in the State of Assam in accordance with the
provisions of this Act and the rules made there under.

62

<!-- page 65 -->

State Act (Year)

Provisions
2) On and from the commencement of this Act, the establishment of
non-government educational institutions or the opening of a higher
class or the closing down of an existing class in any existing nongovernment educational institution in the State, shall be subject to
the provisions of this Act and the rules made thereunder and any
non-government educational institution or any higher class
established or opened otherwise than in accordance with the
provisions of this Act shall not be recognized under section 5 by the
Director and shall be closed down under Section 24.
Section-12 Constitution of Managing Committee
Every non-government educational institution shall constitute a
Managing Committee consisting of Chairman & Members.
Section-13 Power and functions of Managing Committee
Section-14 Scheme of Management
Section- 15 Appointment and disciplinary matters
Section- 16 Code of Conduct for the Employee

Bihar
Education ‘No Provision’ for Management Committee & Safety Measures
Code (1961)
The
Chhattisgarh
Primary Education
‘No Provision’ for Management Committee & Safety Measures
Act (1961)
The Delhi
Education
(1973)

School Section-5 Scheme of management- (1) Notwithstanding anything
Act contained in any other law for the time being in force or in any
instrument having effect by virtue of any such law, the managing
committee of every recognized school shall make, in accordance with the
rules made under this Act and with the previous approval of the
appropriate authority, a scheme of management for such school:
Provided that in the case of a 63recognized private school which does
not “ receive any aid, the scheme of management shall apply with such
variations and modifications as may be prescribed:
Provided further that so much of this sub-section as relates to the
previous approval of the appropriate authority, shall not apply to a
scheme of management for an unaided minority school.
(2) a scheme may be made, in like manner, to add, to vary or modify any
scheme made under sub-section (1).

63

<!-- page 66 -->

State Act (Year)

Provisions
Section-8 Terms and conditions of service of employees of
recognized private schools
Section-9 Employees to be governed by a Code of Conduct- Every
employee of a recognized school shall be governed by such Code of
Conduct as may be prescribed and on the violation of any provision of
such Code of Conduct, the employee shall be liable to such disciplinary
action as may be prescribed.
Chapter VII- Taking Over the Management of School
Section-20 Taking over the management of schools- (1) Whenever
the Administrator is satisfied that the managing committee or manager
of any school, whether recognized or not, has neglected to perform any
of the duties imposed on it by or under this Act or any rule made there
under and that it is expedient in the interests of school education to take
over the management of such school, he may, after giving the managing
committee or the manager of such school, a reasonable opportunity of
showing cause against the proposed action, take over the management
of such school for a limited period not exceeding three years :
Chapter VIII-Miscellaneous
Section-22 Delhi Schools Education Advisory Board- (1) There shall
be an Advisory Board for school education, to be called the “Delhi School
Education Advisory Board” for the purpose of advising the
Administrator on matters of policy relating to the education in Delhi.
(2) The Advisory Board shall be constituted by the Administrator and
shall consist of a Chairman and fourteen other members, to be
nominated by the Administrator.
(3) The Advisory Board constituted under sub-section (2) shall include
a) Heads of recognized private schools;
b) representatives of the organizations of teachers of the recognized
private schools;
c) managers of the recognized private schools;
d) representatives of parents or guardians of students of recognized
private schools;
and
e) Eminent educationists.
(4) The Advisory Board shall regulate its own procedure.

64

<!-- page 67 -->

State Act (Year)

Provisions
(5) The terms of office of every member of the Board and travelling and
other allowances payable to a member of the Board shall be such as may
be prescribed.

The Goa
Education
(1984)

School Section-2(n) “managing committee” means the body of individuals
Act which is entrusted with the management of any recognized private
school;
Section-6 Scheme of Management- Notwithstanding anything
contained in any other law for the time being in force or in any
instrument having effect by virtue of any such law, the managing
committee of every recognized school shall make, in accordance with the
rules made under this Act a scheme of management for such school:
Provided that in the case of a recognized school which does not receive
any aid, the scheme of management shall apply with such variations and
modifications as may be prescribed.
Chapter IV- Terms and conditions of service of employees of
recognized private schools
Section-11 Terms and conditions of service of employees of
65recognized private schools
Section-12 Employees to be governed by a Code of Conduct
Chapter VII-Taking over management of school
Section-20 Taking over management of school
Chapter IX-School Education Advisory Board
Section-24Advisory Board- (1) There shall be constituted an advisory
board to be called the Goa, Daman and Diu School Education Board
(hereinafter referred to as the Advisory Board) for the purpose of
advising the Government on matters of policy relating to education An,
the Union territory.
(2) The composition of the Advisory Board shall be as follows, namely: (a) the Chairman of the Goa, Daman and Diu Board of Secondary and
Higher Secondary Education, ex-officio;
(b) three persons, who are the heads of 65 recognized private schools;
(c) three representatives of organisations of teachers of recognized
private schools;
(d) three representatives of the managements of recognized private
schools;

65

<!-- page 68 -->

State Act (Year)

Provisions
I the Director, who shall be the Secretary to the Advisory Board;
(f) the Principal of one of the colleges in the Union territory;
(g) two members of the Legislative Assembly of the Union territory to be
nominated by the Speaker;
(h) two eminent educationists;
(i) two representatives of the parents and guardians of the students of
recognized private schools; and
(j) two representatives of the students of recognized private schools.

The
Gujarat Section-14 Penalty for employing a child to whom the scheme
Compulsory
applies.
Primary Education
Whenever knowingly takes into his employment, either on his own
Act (1961)
behalf or on behalf of any person, any child in respect of whom the
provisions of Section 9 apply, so as to interfere with the education or
instruction of such child shall, subject to the provisions of section 20, on
conviction, be punished with a fine not exceeding twenty-five rupees and
in case of continuing contravention with an additional fine not exceeding
rupee one for every day during such contravention continues after
conviction for the first of such contravention.
Haryana
Education
(1995)

School Section-2(l) “managing committee” means the body of individuals
Act entrusted with the management of any recognized private school or
schools;
Section-2(o) “private school” means a school which is not run or
sponsored by the Government, Director, a local authority or other
authority designated or sponsored by the Government;
Section-5 Scheme of management
Section-8 Terms and conditions of service of employee of aided schools
Section-9 Employee to be governed by a Code of Conduct.

The
Himachal
Pradesh Board Of
School
Education
Act (1968)

Section-2(g)“Inspecting Officer” means the District Education Officer,
Deputy District Education Officer, Block Education officer or any other
officer appointed for the inspection of schools by the Education
Department of the Himachal Pradesh Government;

The
Jharkhand ‘No Provision’ for Management Committee & Safety Measures
Education Tribunal
Act (2005)

66

<!-- page 69 -->

State Act (Year)

Provisions

Jammu and Kashmir Section-11 No private school to be established or run without
School
Education permission — (1) No private school shall be established, run or
Act (2002)
maintained without permission, in writing, of the Government or the
Competent Authority.
(2) The Government shall prescribe the procedure to be followed for the
grant of permission to establish, run or maintain private schools.
Section-13 Management of private schools — (1) No private school
shall be managed and run by any person other than an educational
agency. The Government shall prescribe the procedure for registration
of educational agencies.
(2) Every educational agency shall appoint a Manager to look after dayto-day running an administration of the school managed and run by such
educational agency.
Section-20 Conditions of service of staff in private schools
Section-22 State Education Advisory Board
The
Karnataka Section-5A Safety and security of students- Every educational
Education
Act institution and an employee of such educational institutions shall take
(1983)
such measures to ensure safety and security of students including
protection from sexual offences, in the manner as may be prescribed.
Chapter VII - management of recognised private educational
institutions and local authority institutions, etc.
Section-42 Managing Committee
Section-46 Powers and functions of the Managing Committee
Chapter XVII Penalties
Section-112A Penalty for contravention of section 5A- (1) Any
employee or member of the management of an educational institution
who contravenes section 5A shall on conviction, be punished with
imprisonment for a minimum term of six months and with a fine which
may extend to one lakh rupees.(2) Whenever any educational institution
is found to be in contravention of section 5A in an enquiry conducted,
after giving an opportunity of being heard, by the District Education
Regulatory Authority, it shall impose a penalty which may extend to ten
lakh rupees. (3) The District Education Regulatory Authority after such
enquiry has found that any educational institution has contravened the
provisions of section 5A shall also recommend to the competent
authority or concerned authority for withdrawal of recognition or
affiliation to such institution.

67

<!-- page 70 -->

State Act (Year)
The
Education
(1958)

Provisions

Kerala Section-5AManagement of Government schools and Aided Schools
Act taken over or acquired by Government: - The Management of every
Government school and that of aided school taken over or acquired by
the Government under section 14 or section 15 as the case may be shall
vest as specified below in the local authority noted against each namely.
Section-12A Disciplinary powers of Government over teachers of aided
schools
Section-14Taking over management of schools

The
Madhya Chapter III-Responsibilities of Institutions and Parent or Guardian
Pradesh Jan Shiksha
Section-2(j) “Parent Teacher Association” means association of the
Adhiniyam (2002)
parents of the students enrolled in a school and teachers of that school.
Section-12 Parent Teacher Association
Section-13 Education Committee—The Education Committee shall
monitor the regular attendance of teachers in schools. The committee
may direct the authority concerned to take action, including withholding
of the disbursement of salary/ honorarium, against the teacher for his
wilful absence or negligence for such period as it may deem fit and refer
the case to the disciplinary authority concerned for further action. The
committee shall also perform such other functions as may be prescribed.
The
Maharashtra This act speaks about the constitution of Board etc. no provision found
Primary Education regarding Management for Private School and the safety measures.
Act (1947)
The
Manipur Section-3(i) “Managing Committee” means a Managing Committee of a
Elementary
and High School or a higher Secondary School;
Secondary
Education
Act
(1972)
The
Meghalaya Section-6 Scheme of management
School
Education
Section-9 Terms and conditions of service of employees of recognised
Act, 1981
private schools
Section-20 Taking over the management of schools
Section-22 Meghalaya School Education Advisory Board
The
Mizoram Section-2(18) “Managing Committee” means anybody of individuals, by
Education
Act whatever name called, in which the management of a school vests;
(2003)

68

<!-- page 71 -->

State Act (Year)

Provisions
Section-5 Managing Committee or Governing Body of Educational
Institutions.
Provided that in the case of a recognized private educational institution
which does not receive any aid from the Government, the scheme of
management shall apply with variation and modification as may be
prescribed.
Section-9 Terms and conditions of Service of Employees of Recognised
Educational Institutions.
Section-10 Employees to be governed by a Code of Conduct
Section-24 Taking over by the Government of the management of
educational institutions.
Section-26 State Advisory Board of Education

The Nagaland Board ‘No Provision’ for Management Committee & Safety Measures
of School Education
Act (1973)
The
Education
(1969)

Orissa Managing Committee or Governing Body of educational institution.
Act
Section-7A Supersession and reconstitution of managing committee or
Government body.
(1) Whenever the prescribed authority is satisfied that the Managing
Committee or, as the case may be, the governing body of any private
educational institution has neglected or failed to perform any of the
duties imposed by or under this Act or the rules or to give effect to
the order or direction issued by the Tribunal under Section 24-A or
has acted in excess of the authority vested in it or in any manner
which is prejudicial to the interest of the educational institution, he
may, after giving the Managing Committee or the Governing Body, as
the case may be, a reasonable opportunity of showing cause,
supersede the Managing Committee or the Governing Body, as the
case may be.
Chapter – III-Advisory Council and District School Board
Section-15 State Advisory Council of Education

The Punjab Primary Section-10 No person shall employ a child in a manner which shall
Education
Act prevent the child from attending an approved School.
(1960)

69

<!-- page 72 -->

State Act (Year)

Provisions

The
Rajasthan Section-22 Appointment and constitution of Committees - (1) The
Secondary
Board shall appoint the following Committees, namely: Education
Act
(a) Committees of courses,
(1957)
(b) An Examination Committee,
(c) A Curriculum Committee,
(d) A Recognition Committee,
(e) An Evaluation Committee,
(f) A Finance Committee, and
(g) Such other Committees, as may be prescribed.
The Sikkim Primary The State of Sikkim has separately framed the provisions in Sikkim
Education
Act Education Act in respect of accountability of the School Management
(2000)
Committee. The abstract of these provisions is annexed as flag –A in the
booklet.
The Tamil
Compulsory
Elementary
Education
(1994)

Nadu Section-6 Competent Authority
1) The Government may, by notification, appoint any officer of the
Education department, not below the rank of District Educational
Act
Officer, to be competent authority for the purpose of carrying into effect
the provisions of this Act and the rules made there under and different
competent authorities may be appointed for different areas.
(2) The competent authority shall exercise such powers and perform
such other functions as may be prescribed.
Section-10 Power of Government to give directions
The Government may, in the public interest, by order, direct the
competent authority to make an enquiry or to take appropriate
proceedings under this Act in any case specified in the order, and the
competent authority shall report to the Government the result of the
enquiry made or the proceedings taken by him within such period as
may be prescribed.

The
Uttaranchal Section-22 Constitution of Committees - (1) The Board shall
School
Education constitute the following Committees as prescribed in the regulations. A
Act (2006)
Difference Committee may be constituted for different areas.
(2) The following shall be the committees of the Board, namely –
(a) Curriculum Committee,
(b) Syllabus Committee,

70

<!-- page 73 -->

State Act (Year)

Provisions
(c) Examinations Committee,
(d) Results Committee,
(e) Recognition Committee, and
(f) Finance Committee.

The Uttar Pradesh ‘No Provision’ for Management Committee & Safety Measures
Basic Education Act
(1972)
The West Bengal ‘No Provision’ for Management Committee & Safety Measures
Primary Education
Act (1973)
Other Provisions
State
of
Pradesh
2017)

Uttar
(April,

Uttar Pradesh Government bans liquor shops near schools, colleges
and religious places

of

Adapting Section 6 of the COTPA Act, 2003, the Maharashtra state
government has passed an act stating that no person shall sell, offer for
sale, or permit sale of, cigarette or any other tobacco product- to any
person who is under eighteen years of age and in an area within a radius
of 100 yards of any educational institution.

State of Tamil Nadu
(2003)

Rule 8 of Tamil Nadu Liquor Vending (In Shops and Bars) Rules, 2003
states that no liquor shop should be established in municipal
corporations and municipalities within a distance of 50 meters from an
existing place of worship or educational institutions and that a minimum
distance of 100 meters should be maintained between such places in all
other local bodies.

State
Maharashtra
(2015)

71

<!-- page 74 -->

Annexure-II
CONSTITUTION OF PARENT-TEACHER ASSOCIATION
As per section 21 of RTE Act, 2009, private schools are exempted from formulating SMCs. In such
schools, PTA should be made mandatory as SMCs and PTAs are an important link in monitoring the
safety and security measures in schools. The private schools defined under section 2 (n) (iv) of RTE
Act, 2009 should have a Parent Teachers Association (PTA).
The following is only a suggestive model for the same.
Composition of Parents-Teachers Association (PTA)
a. There may be only one PTA in every school.
b. The PTA may be formed within one month of the beginning of the academic session and
may be sensitized/ oriented on NCPCR's Manual on Safety and Security of Children in
Schools.
c. Fifty per cent of members of such Committee can be women
d. PTA may consist of two parent representatives from each stage (pre-primary,
elementary, secondary and senior secondary including parents of children with
disability) such that three-fourth of members of such Committee may be parents or
guardians.
e. Out of the 3/4th member parents, 25 percent of the total strength of parent members
could be reserved for parents or guardians of children admitted under section 12 (1) (c)
of the RTE Act, 2009
f.

One teacher from each level of schooling i.e. pre-primary, elementary, secondary and
senior secondary may be nominated by the principal

g. One special invitee member with expertise in any school related fields that would impact
the overall school development;
h. One representative member of the School Management;
i.

Adequate representation of parents from disadvantaged categories may be ensured.

j.

In case, the ward of parent member leaves the school in between the academic session,
another parent/guardian member from that class may be inducted into the PTA within
one-month;

k. The School Management may display/upload the names of PTA Member on their website
and on the notice board.

72

<!-- page 75 -->

Terms of Reference:
a. The term of the PTA should be one academic year.
b. The School Management should display/upload the names of PTA Members on their website
and on the notice board.
c. As per section 21 of RTE Act, 2009 a school, other than a school specified in sub-clause (iv) of
clause (n) of section 2, shall constitute a School Management Committee consisting of the
elected representatives of the local authority, parents or guardians of children admitted in
such school and teacher.

73

<!-- page 76 -->

Annexure-III
MAKING SCHOOLS SAFE AND SECURE: COMPREHENSIVE CHECKLIST
Sr.
No.

Criterion

Satisfactory

A

School Safety and Security Program

1.

Does your School Safety and Security Program include:

a)
b)
c)

d)

e)
f)

g)

h)

Monitoring of certificates for safety and fitness
of school building
Natural or Man-made Disaster management
and Safety Drills
Zero Tolerance about weapons and illegal drugs
in and around school premises (For Adolescent)
Measures for Student Conduct – including
Attendance, Regularity, Punctuality, Respect,
Tolerance, Helping Attitude and also other
disruptive behaviors such as Bullying, Fighting,
Violence, etc.
Measures for Teacher Conduct – Attendance,
Regularity, Punctuality, Respectful and
dignified behaviour to all
Mechanism against harassment, sexual or
verbal abuse, or discrimination of any sorts.
Reporting mechanisms in case of any instance
of harassment, abuse or discrimination.
(Are parents and students aware of these
policies?)
Issuing notification to authorities, parents,
students and staff about security related events

74

Needs Further
Attention

Not
taken up
yet

NA

Remarks

<!-- page 77 -->

Sr.
No.
i)
j)
k)
l)
m)
n)
o)
p)
2.
3.

4.

Criterion

Satisfactory

Measures for dealing with victim, perpetrator,
parents, other stakeholders, police and media in
case of any untoward incident
Clear norms on Acceptable and Unacceptable
use of the internet in school premises
Norms on use of cell phones during school
hours
Monitoring of building entrances, hallways and
classrooms before, during and after school
hours
Emergency Evacuation Plan, its display and
regular drills on this.
Police verification for hiring of teaching, nonteaching, contractual, voluntary and other
staffs?
Performance reviews of employees in
compliance with safety policies and preventive
actions
Are the School Principals/HM, Teachers and
Staff aware of standard Child Protection
Mechanisms
Has the School implemented the Guidelines by
National Disaster Management (NDMA) on
School Safety and emergency preparedness?
Does the school have a viable communication
system in place, e.g., landline phone, safety and
fire alarm, etc.?
Does
your
school
have
suggestion
boxes/question boxes/grievance boxes or any
other mechanism for students/parents to
inform or communicate about any safety
concerns of their children?

75

Needs Further
Attention

Not
taken up
yet

NA

Remarks

<!-- page 78 -->

Sr.
No.
5.
6.
B
7.
8.
9.
10.
11.

12.

13.
14.
15.
16.

Criterion

Satisfactory

Are Students / Teachers /Non-Teaching Staff
oriented to deal with common medical
emergencies?
Do you have the ‘School Safety Pledge’
prominently displayed in your school campus?
School Buildings, Grounds and Facilities
Are the school’s entrances, exits and doorways
clearly marked (Signage)?
Are the school’s entrances, exits and doorways
free of obstruction?
Is there regular maintenance of the Entry-Exit
log for parents/visitors at the main gate?
Is there a Security guard/CCTV/any other
mechanism of surveillance in school?
Are the electric wires and cables insulated with
proper earthing and beyond the reach of
children?
Are exit signs marked on each floor (e.g.,
auditorium, laboratories, big classrooms,
libraries, etc.) to show pathways during
emergency?
Are the fire extinguishers suitably placed in the
school?
Are these fire extinguishers regularly checked
for expiry and functioning?
Are staff and students trained to the use of fire
extinguishers?
Does the school have a Medical/Sick Room with
essential medicines and first aid equipment?

76

Needs Further
Attention

Not
taken up
yet

NA

Remarks

<!-- page 79 -->

Sr.
No.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.

Criterion

Satisfactory

Does the school have a designated parking
area?
Is the School building surrounded by a
boundary wall or fence?
Are hazardous goods and substances
appropriately labeled, stored and kept away
from students’ access?
Are all lighting fixtures securely mounted, and
in working condition?
Are the isolated areas of the School well-lit and
under frequent invigilation?
Is sufficient and safe drinking water available
for the students?
Is regular cleaning and fogging of water tanks
and storage facilities being done?
Are the water tanks and septic tanks well
covered and access blocked for children?
Are separate and functional toilets available for
boys and girls (For Adolescent)
Are separate and functional toilets available for
other staff members?
Does the school have a pre-primary class? If so,
is it located on the ground floor?
Has the school implemented the NCPCR
guidelines for physical and infrastructural
safety for residential schools?
Is there any stagnant water anywhere on the
premises?

77

Needs Further
Attention

Not
taken up
yet

NA

Remarks

<!-- page 80 -->

Sr.
No.

Criterion

C.

Psychosocial Safety and Support

30.

31.

32.

33.

34.

35.

36.

37.

Satisfactory

Does the School have access to qualified
Counsellor on call, as per requirement? (For
Adolescent)
Are the students especially from primary
classes oriented on Personal Safety, e.g., the
difference between ‘Safe touch’ and ‘Unsafe
touch’ (For Children)
Does the school have a Students Council/ Bal
Sansad that deals with students’ issues and
concerns?
Are students oriented on life skills, exam
preparedness and coping skills to manage fear,
anger, peer-pressure, bullying, etc.? (For
Adolescent)
Does the school have regular orientation
sessions with parents on common behavioural
issues of children and adolescents?
Are there opportunities for parents apart from
PTMs to interact with teachers and other
appropriate authorities and inform about any
safety concern?
The school addresses and does not tolerate
issues
of
bullying,
harassment
and
discrimination/prejudice against students on
basis of religion, caste, gender, language,
physique or disability or any other factor?
Misconduct and inappropriate social behavior
is strictly monitored and addressed like stealing
/needless writing on the walls/ harming

78

Needs Further
Attention

Not
taken up
yet

NA

Remarks
