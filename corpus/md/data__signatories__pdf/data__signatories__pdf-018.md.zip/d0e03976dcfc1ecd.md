---
doc_id: "d0e03976dcfc1ecd"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/f02ea1067fc6fd4d411582e016952fbb.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of UL ISP Category ‘C’ Nagpur SSA in Maharashtra Service Area, license no. DS-11/152/2017 - DS-IIl, DATED 12.12.2017 M/s PASSIT MEDIA AND COMMUNICATION PVT. LTD"
date: "2024-05-24"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f5e521f2e13d3c50"
---

<!-- page 1 -->

DS-11/287/2023-DS-II

I/3182187/2024

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20-Ashoka Road, New Delhi-110001
(DS Cell)

No. DS-11/287/2023-DS-II

Dated:24-05-2024

To,
M/s PASSIT MEDIA AND COMMUNICATION PVT. LTD
PLOT NO.65, RAJABAKSHA, MEDICAL CHOWK,
NEAR HANUMAN MANDIR, Nagpur, NAGPUR,
Maharashtra, India, 440003
Email - info@passitmedia.com & dhiraj_godbole@rediffmail.com
CIN- U72900MH2016PTC288258

Sub:- Termination/Revocation/Cancellation of UL ISP Category ‘C’ Nagpur
SSA in Maharashtra Service Area, license no. DS-11/152/2017 - DS-IIl, DATED
12.12.2017 M/s PASSIT MEDIA AND COMMUNICATION PVT. LTD , under
condition of clause 10.2 (i) (Part-I) of the License Agreement.
In respect of no reply received from you to the Show Cause Notice issued
dated 22.11.2023, it is noted that you have not complied with the Financial
conditions of the License as stated in the said show cause notice and it is
understood that you have nothing to say about the said show cause notice.
2.

As such, the competent Authority has decided to terminate/revoke/cancel the
of UL ISP Category ‘C’ Nagpur SSA in Maharashtra Service Area, license
no. DS-11/152/2017 - DS-IIl, DATED 12.12.2017 of M/s PASSIT MEDIA AND
COMMUNICATION PVT. LTD , under condition of clause 10.2 (i) (Part-I) of the
License Agreement. Accordingly, the said license is terminated/revoked/cancelled
w.e.f. 61st calendar day from the date of issue of this letter. You are directed
to terminate and stop all interconnections with all service providers w.e.f. the date
of termination of this License / Authorization.
3.
As per condition 10.2(i) of the said Uniﬁed License Agreement, The
“
Licensee shall be required to give a notice of at least 30 Calendar days to its
customers within this period of revocation order”. Therefore, it is requested to issue
notice of at least 30 Calendar days to all your customers within 30 days from today.
4.
It may be noted that if any other violation of license conditions is reported
against you then necessary action i.r.o said violation may be initiated in due course
of time. The Bank Guarantee(s) submitted against the said license will be released
under clause 11.2 (Part-I) of Uniﬁed License after ensuring clearance of dues
including dues/penalty arising, if any, as a consequence of the aforesaid violation.

<!-- page 2 -->

DS-11/287/2023-DS-II

I/3182187/2024

5. As far as the dues of DS division are concerned the same shall be intimated in
due course of time to O/o CGCA. Further, DG(T), WPC, Concerned CCA, WPF
divisions are requested to ascertain their dues and issue "No Dues Certiﬁcate" /
details of dues to O/O CGCA expeditiously.
6. Kindly acknowledge the receipt.

Director (DS-II)
Email ID:dirds2-dot@nic.in
Meena.sharda@gov.in

Copy to: 1. DG Telecom, DOT (HQ), with a request to instruct the concerned LSA /

LSAs to intimate all Licensees/Infrastructure Providers in their area to
discontinue to provide/obtain any "telecom resources” to/from the M/s
M/s PASSIT MEDIA AND COMMUNICATION PVT. LTD and for issue of
Dues/No Dues Certiﬁcate till the eﬀective date of termination of License
and convey to office of CGCA
2. Sr. DDG MH LSA
3. Sr. Joint CGCA(Revenue), Oﬃce of CGCA (With a request to Release
the Bank Guarantees of the aforesaid company after ensuring dues
from respective sections of DOT as per letter no. vide letter No.190/2012/LF-1(Pt.1) dated 05.09.2018 and letter No.1-8/2017/LFP-1 dated
17.04.2017)
4. Secretary, (TRAI)
5. Wireless Advisor, for issue of Dues/No Dues Certiﬁcate till the eﬀective
date of termination of License and convey to office of CGCA
6. DDG SAT/DDS CS/DDG AS/DDG SA/DDG SPPI /DDG(LFP) , DOT HQ
7. DY. CCA, O/o CCA, MH
8. Director (DS-III),
9. DOT website for all Licensees to discontinue all telecom resources as
per above.
10. F.No . No. DS-11/287/2023-DS-II
