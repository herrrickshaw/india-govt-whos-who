---
doc_id: "ce3030f8aecabc9b"
source_url: "https://mohua.gov.in/static/uploads/2025/12/f563911cd134d00738a81d075b6df62a.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Minutes of the 5th Meeting of the Central Advisory Council constituted under the provisions of the Real Estate (Regulation and Development) Act, 2016 [RERA] held on 4th September 2025 at 02:00 P.M"
date: "2025-09-04"
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "622599459ba5955f"
---

<!-- page 1 -->

Minutes of the 5th Meeting of the Central Advisory Council constituted under
the provisions of the Real Estate (Regulation and Development) Act, 2016
[RERA] held on 4th September 2025 at 02:00 P.M.
-----------------The 5th meeting of the Central Advisory Council (CAC) constituted under the
provisions of the Real Estate (Regulation and Development) Act, 2016 [RERA] was
held in Hybrid mode on 4th September, 2025 under the chairmanship of Hon’ble
Minister of Housing and Urban Affairs in Sankalp Bhawan, K.G. Marg, New Delhi.
The list of participants is Annexed.
2.
Welcoming all the participants to the Meeting, Shri Kuldip Narayan, Joint
Secretary (Housing & HFA) highlighted the vital role of CAC in guiding the
implementation of the Act and addressing emerging issues through policy dialogue
and stakeholder consultations. He emphasized the need to assess the practical
challenges on the ground, share success stories and collectively identify areas
where further strengthening is needed.
3.
Thereafter, the Secretary (HUA), after welcoming all the members, made a
brief presentation before the Council. He highlighted that RERA has played a key
role in regulating and promoting the sector by enhancing accountability &
transparency, facilitating a fast-track grievance redressal mechanism, preventing
fund diversion and ensuring timely delivery along with quality construction. He
further apprised the council that as of 1st September 2025, all States/ UTs except
Nagaland have notified Rules under RERA and established Real Estate Regulatory
Authorities. More than 1.51 Lakh Projects and 1.06 Lakh Agents have been
registered and more than 1.47 Lakh complaints have been disposed by the Real
Estate Regulatory Authorities across the country. In this regard, the Hon’ble
Chairperson directed that total number of cases that are being registered must also
be maintained to ascertain the percentage of complaint disposal. Joint Secretary
(Housing & HFA) replied the information regarding number of registered cases will
also be sought from Regulatory Authorities.
Following this, Secretary (HUA) briefed the council about the previous CAC
meetings and major decisions taken therein. He apprised the Council about key
actions taken on various directions given in the PRAGATI Meeting such as the
constitution of a team to assess challenges in project registration, onboarding of
nodal officers from 29 States/UTs and 28 Regulatory Authorities on the Centralized
Public Grievance Redress and Monitoring System (CPGRAMS) portal to address
homebuyers’ grievances, meetings with developers’ associations to ensure
effective implementation of RERA and circulation of RERA flyers to over 6.6 crore
taxpayers.

<!-- page 2 -->

Subsequently, he acknowledged some persisting issues such as misleading
advertisements, stalled pre-RERA housing projects, non- implementation of RERA
orders, delay in project registration etc. In this regard, he informed the Council
about best practices of various RERAs. He stated that Conciliation Forums in
Gujarat, Uttar Pradesh and Maharashtra are facilitating amicable dispute resolution.
He added that Gujarat RERA has linked fund withdrawal to project data verification,
UPRERA has set up a media team to curb misleading advertisements and
MahaRERA, in collaboration with Advertising Standards Council (ASCI), is tracking
unregistered project advertisements. He pointed out that TNRERA has circulated
consolidated guidelines on advertising which should be looked into for adaptation
by all Regulatory Authorities. He further mentioned that Gujarat RERA and
UPRERA are actively following up on Recovery Certificates with Revenue
Authorities for effective enforcement.
He further elaborated on the issue of Misleading Advertisements which
deceive common people / middle- class homebuyers and undermine investor’s
confidence. He apprised the council that MoHUA has taken cognizance of the
matter and has requested the States / RERA Authorities to take appropriate action
and furnish report. He requested the Council to collectively work to resolve the
matter. Thereafter, he briefed the members about the policy package formulated by
State Government of Uttar Pradesh on the lines of Amitabh Kant Committee Report
on Legacy Stalled Housing projects which has helped revival of stalled projects in
Noida and Greater Noida and also requested other States to consider similar
measures.
In conclusion, Secretary (HUA) stressed the importance of wider
consultations, awareness and effective enforcement to further strengthen RERA.
He highlighted focus areas such as clarity in definitions, preventing delays, reviving
stalled projects, timely grievance redressal and compliance with orders. He stated
that with joint efforts and CAC’s guidance, RERA will become a stronger tool for
transparency, accountability and growth. Subsequently, he requested Shri Tokhan
Sahu, Hon’ble Minister of State (MoS), HUA to share his vision and guide the
council through his address.
4.
The Hon’ble MoS in his remarks stated that implementation of RERA has
helped revive demand and support the growth of Real Estate Sector. He reaffirmed
that the Government remains fully committed for ensuring the effective
implementation of RERA in letter and spirit, with the paramount objective of
safeguarding the interests of homebuyers. He informed the Council about the
dedicated RERA portal which will be inaugurated to enhance transparency, crosslearning and stakeholder engagement. He expressed his confidence that with
collective efforts and CAC’s guidance, RERA will further strengthen as a tool for
accountability and sustainable growth. Thereafter, he invited the Hon’ble
Chairperson to share his insights to further enrich the deliberations.

<!-- page 3 -->

5.
Hon’ble Chairperson welcomed all the members to the 5th meeting of the
CAC, highlighting it as an important gathering that brings together key stakeholders
from across the Real Estate Sector to deliberate on critical issues and collectively
contribute to the sector’s transparent and sustainable development. He emphasized
the significant role of the Real Estate Sector in contributing to the country’s GDP.
He informed the Council that the previous meeting of the Consultative Committee
on MoHUA was focused on discussing the implementation of RERA wherein
members shared valuable insights, raised key concerns and offered suggestions to
enhance the effectiveness of the regulatory framework. He also informed the
Council that RERA’s functioning is being closely monitored by the Hon’ble Prime
Minister, in the PRAGATI Meetings.
Hon’ble Chairperson stressed the need to review the rules being framed by
States at Centre level to bring uniformity across States. He also suggested that the
period of registration should not be expired until the projects are completed. He
further underlined the need to strengthen mechanisms for effective implementation
of RERA orders and stressed the importance of conducting stability audits of
buildings before issuing completion certificate. He also highlighted the problem of
withdrawals from escrow accounts being made without proper permissions and
stressed the need to consider actions that could be taken against banks if such
incidents happen. After addressing the issue of misleading advertisements, the
Hon'ble Chairperson emphasized the importance of resolving the challenges
builders face due to delays in obtaining approvals from local authorities.
Thereafter, Hon’ble Chairperson suggested studying global as well as State
models to adopt best practices for further strengthening the framework and also
raising awareness of RERA. Following this, he invited the members to share their
views on each item on the agenda.
6.
Shri Kekhrievor Kevichusa, Commissioner & Secretary, Urban Development
Department, Government of Nagaland apprised the Council of the status of
implementation of RERA in the State of Nagaland. He informed that RERA has not
yet been implemented in Nagaland due to concerns about its potential implications
on the constitutional provisions under Article 371-A. However, he clarified that the
Committee of the Legislative Assembly of the State has recommended the Urban
Development Department to constitute an inter-departmental committee to examine
the applicability of RERA and propose suitable amendments to ensure it does not
conflict with Article 371-A. He further stated that the said Committee has reviewed
the provisions of RERA with appropriate amendments and that the matter is
currently in the process of being submitted to the Legislative Assembly Committee.
Thereafter, he assured that RERA will be adopted in the State of Nagaland in the
near future.

<!-- page 4 -->

7.
In this context, Shri Kuldip Narayan informed the council that similar
constitutional provisions exist in other North Eastern States as well such as Sikkim
and Manipur, where the rules under RERA have been adopted in accordance with
their specific requirements. Following this, Shri Narayan apprised the Council of the
latest implementation status of RERA across the country and also informed that the
Ministry is taking steps to seek data from other Regulatory Authorities for updating
the unified RERA Portal, enabling Homebuyers to take informed decisions.
Thereafter he invited other members of the Council to give their views with respect
to implementation of RERA.
8.
Shri Sanjay Dubey, Additional Chief Secretary, Housing and Urban
Development, Govt. of Madhya Pradesh recommended that land cost should be
excluded from the construction cost under RERA in cases where the developer
already owns the land, to ensure adequate liquidity for construction purposes.
Thereafter, he highlighted that, due to challenges related to land ownership,
insurance companies are unwilling to provide land title insurance for RERA
projects. Therefore, he suggested that Insurance Regulatory and Development
Authority of India (IRDAI) may be requested to develop an appropriate instrument to
address this gap, with the objective of protecting the interests of both individual
homebuyers and developers. Following this, Shri Dubey suggested that State
Advisory Councils, similar to Central Advisory Council should also be established to
address issues at the State level.
9.
Shri Abhay Upadhyay, President, Forum for People’s Collective Efforts
(FPCE) raised issues relating to non-uniformity of rules, misleading advertisements,
non-updating of annual reports, problems in pre-registration, builders not adhering
to approved layout plans & promised amenities, among other issues. Shri
Upadhyay emphasized that mere disposal of cases is not sufficient. He stressed
that it is essential to ensure that relief is actually provided to the complainant and
that the orders are duly executed. Hon’ble Chairperson also seconded this
suggestion and stated that the problem of non-implementation of RERA orders
should be addressed. In this context, Joint Secretary (Housing & HFA) stated that
this issue will be addressed at the time of amendment of the Act.
Shri Upadhyay also raised the issue that redevelopment projects are not
covered under RERA and noted that such projects often involve a sale component.
The Hon’ble Chairperson clarified that redevelopment projects are primarily carried
out under state government schemes and do not involve a contractual system. Joint
Secretary (Housing & HFA) further clarified that no state law can contradict RERA,
and any redevelopment project with a sale component would fall under its purview.
This view was supported by Shri Niraj Kumar, Joint Secretary, Department of Legal
Affairs.

<!-- page 5 -->

In conclusion, Shri Upadhyay suggested that conference of Homebuyers
may also be organized so as to make awareness among Homebuyers. The Hon’ble
Chairperson welcomed the suggestion and suggested that homebuyers
associations should take initiative with the help of RWAs in conducting such
conferences. Shri Upadhyay also informed the members that the Ministry should
facilitate interactions with Real Estate Regulatory Authorities so that homebuyers
can interact with them directly and their issues can be resolved promptly.
10.
Shri Dipankar Kumar, New Era Flat Owners Welfare Association (NEFOWA)
highlighted the issue of non implementation of Recovery Certificates issued by the
Real Estate Regulatory Authorities, Stalled Housing Projects, non-uploading of
Quarterly Progress Reports (QPRs), among other things. He further highlighted that
some builders are not adhering to the rules and are collecting money outside the
designated escrow account. He also raised the concern that when a subsidiary
company developing a project becomes insolvent, the parent company remains
legally unaffected, thereby adversely impacting the interests of homebuyers.
Hon’ble Chairperson acknowledged this issue and stated that there should be
clarity on where responsibility should lie. Thereafter, Shri Kumar raised the issue of
project de-registration. He noted that some developers, despite having registered
long ago, have neither started work nor complied with audit requirements. He
stressed that it is essential to examine how such cases should be addressed under
Section 8 of RERA.
11.
Following this, Hon’ble Chairperson and Minister, HUA directed the
discussion to the next agenda item, namely the action taken on the
recommendations of the Amitabh Kant Committee report. He invited
representatives of NOIDA and Greater NOIDA to brief the Council regarding the
action taken in their State.
Shri Satish Pal, ACEO, NOIDA apprised the council that out of the 57
defaulting projects, 35 have paid 25% of the total liability and total number of 5,546
registries have also been made. He also apprised the council some builders have
made partial payments and actions have been initiated against those builders who
have not deposited any amount till date. Shri Dipankar Kumar, NEFOWA added
that in NOIDA and Greater NOIDA, 75% of homebuyers have not received any
relief under the Amitabh Kant Committee report. He stated that registries have only
been executed to the extent of the amount deposited by the buyers. He further
observed that the recommendations of the Amitabh Kant Committee have not been
implemented in letter and spirit, and demanded stronger action against builders
who have failed to make the required payments.
In this context, Shri Kuldip Narayan, Joint Secretary (Housing & HFA)
apprised the members that as per the recommendations of Amitabh Kant
Committee, if the builder pays 25% of the amount, the registry will be completed for

<!-- page 6 -->

25% of the flat. As further payments are made, additional portions of the registry will
follow. However, since some cases are currently under court jurisdiction, the matter
has not yet been resolved.
The Hon’ble Chairperson suggested that the unsold units of a project be
hypothecated to address the issue. The funds generated should be used to
complete the project and provide relief to the homebuyers. In this context, Shri
Dipankar added that in many cases, homebuyers have been given possession of
their homes without Occupation Certificate and Completion Certificate. Shri
Upadhyay apprised the members that the recommendations of Amitabh Kant
Committee have not been implemented in many States. He suggested that if the
recommendations of the Amitabh Kant Committee are implemented in letter and
spirit across the country, it would provide significant relief to homebuyers.
12.
Shri G Hari Babu, President, NAREDCO stated that issued of stalled projects
have been reduced significantly post the enactment of RERA. However, he
highlighted that several states have not yet implemented the Land Title Guarantee
Act, resulting in the unavailability of insurance policies for land. He requested that
all states implement the Act to ensure secure land titles and protect buyers. In this
context, Shri Rakesh Kumar Goyal, Chairperson, Punjab Real Estate Regulatory
Authority, highlighted that some builders start projects with very little capital and
take large unsecured loans against the land, often without disclosing this to
homebuyers. Unlike infrastructure projects, which require a minimum 20% capital
before borrowing, real estate sector lacks such safeguards and therefore there may
be a need to ensure greater financial stability in the sector.
Shri Gaurav Gupta, Secretary, CREDAI, stated that projects are launched
only after all promoters have obtained the necessary approvals, including land
ownership and environmental clearances. However, he highlighted that a major
reason for project delays is the slow approval process by urban local bodies and
suggested that these local bodies should also be made accountable to RERA. This
concern was supported by Shri Anand J. Gupta, Chairperson of the Builders’
Association of India, who noted delays in granting Completion and Occupancy
Certificates, particularly by town planning offices in Maharashtra. The Hon’ble
Chairperson observed that the local authorities should be made responsible at least
for projects registered under RERA, to ensure effective implementation of the Act.
Thereafter, Shri Gupta also requested that the definition of “force majeure”
be redefined, as construction is sometimes halted due to government orders, citing
the example of pollution-related restrictions in Delhi. Hon’ble Chairperson also
acknowledged it and stated this should not be treated as delay caused by builder.
Shri AK Singh, Additional Chief Secretary, Town and Country Planning
Department, Govt. of Haryana stated that a meeting was held with developers’

<!-- page 7 -->

associations and the Chief Secretary, Government of Haryana and provisions have
been made to condone delays caused by GRAP orders. Thereafter, he highlighted
that the ‘removal of difficulties’ clause in RERA was valid only for two years, yet
practical challenges are now being faced. In Haryana, even Haryana Shahari Vikas
Pradhikaran (HSVP) plot cases are being entertained by RERA, despite HSVP
having its own statute and appeal mechanism. Therefore he requested the Ministry
to intervene in this matter.
The Hon’ble Chairperson enquired whether government projects are also
required to be registered under RERA. In this context, Shri Shiv Das Meena,
Chairperson, Tamil Nadu Real Estate Regulatory Authority, informed that Section
3(2) of RERA specifies the categories of projects exempted from the Act, and all
other projects are required to be registered under RERA. Shri Arun Kumar,
Chairperson, Haryana Real Estate Regulatory Authority (Gurugram) informed that
granting exemptions to State Development Authorities may exempt 30–40% of
projects from RERA, while Shri A.K. Singh noted that in Haryana only about 20%
would be outside the ambit of RERA. In this regard, Shri Upadhyay stressed that
exempting government projects would not be in homebuyers’ interests. The Hon’ble
Chairperson concluded that Acts must be implemented harmoniously without
conflicting rules.
13.
Shri Rohit Raj Modi, Vice President, CREDAI stated that there should be no
linkage between registration and termination of project. In this context, Shri Arun
Kumar, Chairperson, Haryana RERA (Gurugram), stated that the time duration for
project completion is declared by the promoter at the time of project registration. If
the promoter fails to deliver the project within this timeframe, delay possession
charges will be applicable. The Hon’ble Chairperson directed that a report should
be obtained from all Real Estate Regulatory Authorities detailing the number of
extensions granted to projects and the actions taken in cases where a project
remains incomplete even after three extensions.
In this context, Shri Kuldip Narayan, Joint Secretary (Housing & HFA) stated
that issues regarding the project timeline would not arise if the completion schedule
declared by the promoter before the RERA Authority, the timeline mentioned in the
brochure for handing over possession and the linked payment schedule are all
aligned. Hon’ble Chairperson directed to take steps to bring harmonization in
declared timelines.
Thereafter, Shri Modi raised the issue of non-uniformity in interpretation of
rules under RERA across various states. Hon’ble Chairperson suggested for an
amendment in the act which mandates that rules made by states under RERA shall
be in consonance of the Act.

<!-- page 8 -->

14.
Shri Vinay Tyagraj, NAREDCO Karnataka, suggested that pre-RERA and
post-RERA projects should be segregated in order to assess the effectiveness of
RERA implementation. He emphasized that stalled pre-RERA projects require
focused attention both at the Central and State levels to arrive at workable
solutions. He observed that the problem of stalled projects is particularly acute in
the NCR region owing to issues related to lease land. He further suggested that
funding agencies such as the SWAMIH Fund, which has been performing
effectively, could be involved to address these concerns.
Shir Narayan, Joint Secretary (Housing & HFA) informed the members that
under SWAMIH, assistance is extended to financially viable projects which are
stalled due to cash flow constraints. It was further apprised that the officials
managing the SWAMIH fund are undertaking awareness initiatives across the
country to assist stalled projects, whether pre-RERA or post-RERA, subject to the
fulfilment of certain conditions prescribed for release of funds.
15.
Shri Samir Jasuja, Managing Director & CEO, Prop Equity, P.E. Analytics
Limited, suggested that RERA may involve the other public agencies and private
sector for monitoring of projects through data analytics. He informed that the data
provided by Prop Equity was used to decide establishment of the first SWAMIH
Fund. In this context, he emphasized that in the present age of AI and data
analytics, public private partnerships should be encouraged to assist Regulatory
Authorities in monitoring projects under RERA. He added that it is essential to
validate, correlate and audit the data uploaded by developers to ensure accuracy
and transparency across the real estate ecosystem.
In this context, Hon’ble Chairperson observed that the primary objective of
RERA is to address the concerns of homebuyers as well as those of developers
where issues are beyond their control. RERA ultimately aims at ensuring project
completion and resolution of delays. However, he suggested that all Real Estate
Regulatory Authorities should conduct audits of registered projects to monitor their
progress.
Following this, Joint Secretary (Housing & HFA) added that data available
with State Regulatory Authorities could be standardized at the national level for
better monitoring, including identification of “green” and “amber” projects, and
mentioned that such data would eventually be collected through APIs.
16.
Shri Pankaj Kapoor, Managing Director, Liases Foras Real Estate Rating &
Research Pvt. Ltd., observed that while Real Estate Regulatory Authorities are
collecting data on construction progress, the compliance levels are not adequate.
He suggested that all State Regulatory Authorities may be requested to update
quarterly reports on trends and analysis, to monitor incremental progress in project
construction. He added that such reporting would help not only in determining the

<!-- page 9 -->

actual construction activity taking place in the country but also in assessing the
sector’s contribution to employment and GDP. He further stated that this would also
enable monitoring of State-level and builder-level compliances. It was suggested to
monitor key data fields for developing a robust performance matrix, including
quarterly construction growth (in sqft) by State, District and City, details of top 10
developers and projects by production, number of new & ongoing projects (by type),
projects completed during the quarter and complaints registered and resolved. He
further highlighted that post-COVID, although sales and supply have increased
sharply, the growth in construction activity has remained relatively insignificant. He
emphasized that these reports may be prepared on the lines of the quarterly
Trends and Progress Reports of RBI and NHB, to facilitate identification of
systemic gaps.
Hon’ble Chairperson sought clarity on whether government agencies
concerned with collection of statistics, obtain data from Regulatory Authorities such
as details of registered projects, area, etc. In this regard, Shri Arun Kumar,
Chairperson, Haryana RERA (Gurugram), highlighted that the thrust of RERA lies in
the mandatory disclosure of project details. Further, Shri Shiv Das Meena,
Chairperson, Tamil Nadu RERA, added that work is underway to standardize the
data being sought from builders so that a uniform QPR could be published.
Shri Sanjay Shukla, Managing Director, NHB, apprised the Council about the
Trends and Progress Report released by NHB, which tracks construction activity
and measures the sector’s contribution in a holistic manner, beyond RERA data
alone. Shri Narayan, Joint Secretary (Housing & HFA) supported Shri Pankaj
Kapoor’s view that available data must be systematically analysed, and informed
that this will be a core vision for the unified RERA portal. Hon’ble Chairperson
concluded that AIFORERA should take the lead in developing and operationalizing
standardized QPRs across States.
17.
Thereafter, Shri Arun Kumar, Chairperson, Haryana RERA (Gurugram),
drew attention to the issue of low registration of Real Estate Agents across the
country and urged that efforts should be made to ensure registration of all Real
Estate Agents under RERA. In this context, Shri G. Hari Babu highlighted that many
Real Estate Agents are not registering under RERA due to high GST rate of 18%.
In this regard, Shri Shiv Das Meena suggested that the registration fees of the Real
Estate Agents may be made nominal in order to ensure registration of Agents under
RERA.
In this context, Shri Tarun Bhatia, Vice Chairmen, National Association of
Realtors – India (NAR-INDIA) stated that Real Estate Agents who wish to operate
across multiple states are currently required to register separately in each state,
deposit fees, and have to submit compliance report. He requested to address this
through ‘One Nation, One License’ policy which would help increase the number

<!-- page 10 -->

of registered agents. The Hon’ble Chairperson stated that since ‘Land’ and
‘Colonization’ are State subjects, therefore the Real Estate Agents will have to
register in each state.
18.
Thereafter, at the request of Secretary (HUA), the Hon’ble Minister and
Hon’ble MoS launched the Unified RERA Portal and the Angikar Portal, following
which the Hon’ble Chairperson addressed the Council and gave the concluding
remarks.
19.
The Hon’ble Chair concluded the meeting by appreciating the valuable
suggestions shared by the members. He emphasized that rules framed by the
States should be vetted at the Central level to ensure uniformity. The Chair further
highlighted the importance of making all relevant information easily accessible on
the RERA portal and stressed the need to create greater awareness among
homebuyers about their rights and protections under RERA. It was also suggested
that meetings of the CAC should be convened on an annual basis for effective
review and guidance. He reiterated that the primary aim of the Council is to address
the issues of homebuyers and assist them in fulfilling their dream of owning a
home.
20.
The meeting ended by vote of thanks by Shri Kuldip Narayan, Joint
Secretary (Housing & HFA).

*********

<!-- page 11 -->

Annexure
List of Participants for 5th Meeting of the Central Advisory Council held on 4th
September, 2025 at 02:00 P.M. in Hybrid Mode.

Attendance
[Physically (P) / Video
Conferencing (VC)]

S.No.

Name

Designation / Name of
Organisation

1.

Shri Manohar
Lal

Hon’ble Minister of Housing and
Urban Affairs

Physically

2.

Shri Tokhan
Sahu

Hon’ble Minister of State,
Housing and Urban Affairs

Physically

3.

Shri Srinivas R
Katikithala

4.
5.
6.
7.

Shri Kuldip
Narayan

Secretary, MoHUA
Joint Secretary (Housing & HFA),
MoHUA

Shri Bharat
Additional Secretary, Ministry of
Khera
Consumer Affairs
Shri Sourabh Deputy Secretary, Department of
Singh
Economic Affairs
Shri Niraj
Joint Secretary, Department of
Kumar
Legal Affairs
Managing Director, National
Housing Bank (NHB)

Physically

Physically

VC
Physically
Physically

8.

Shri Sanjay
Shukla

9.

Chairman & Managing Director,
Shri Sanjay
Housing and Urban Development
Kulshreshtha
Corporation Limited (HUDCO)

10.

Shri Sanjay
Dubey

Additional Chief Secretary, Urban
Development & Housing
Department, Government of
Madhya Pradesh

VC

11.

Shri Sanket
Bhondve

Commissioner, Directorate of
Urban Development, Govt. of
Madhya Pradesh

Physically

Physically

Physically

<!-- page 12 -->

12.

13.
14.
15.
16.
17.

18.

19.

20.

Dr. K.
Ilambarithi

Physically

Shri Rakesh Chairperson, Punjab Real Estate
Kumar Goyal
Regulatory Authority

Physically

Commissioner & Secretary,
Shri Kekhrievor Urban Development Department,
Kevichusa
Govt. of Nagaland

Additional Chief Secretary, Town
and Country Planning
Shri AK Singh
Department, Govt. of Haryana
Dr. Lokesh M

22.

Shri Satish Pal

24.

Physically

Shri Aseem
Additional Chief Secretary
Kumar Gupta (Housing), Govt. of Maharashtra
Shri Manoj
Chairperson, Maharashtra Real
Saunik
Estate Regulatory Authority
Shri Sanjay R. Chairperson, Uttar Pradesh Real
Bhoosreddy
Estate Regulatory Authority
Shri Arun
Chairperson, Haryana Real
Kumar
Estate Regulatory Authority
Shri Shiv Das Chairperson, Tamil Nadu Real
Meena
Estate Regulatory Authority

21.

23.

Secretary, Municipal
Administration and UD
Department, Government of
Telangana

Dr. H. R.
Shivakumar
Ms. Nancy
Sahay

CEO, NOIDA

VC
VC

Physically
Physically

VC

VC

VC

ACEO, NOIDA

Physically

Secretary, Karnataka Real Estate
Regulatory Authority

VC

Director, Department of Urban
Development &
Housing, Govt. of Jharkhand

VC

<!-- page 13 -->

Shri G Hari
Babu

President, NAREDCO

26.

Shri Vinay
Thyagraj

Treasurer, NAREDCO Karnataka

27.

Shri Parveen
Jain

Chairman Emeritus, NAREDCO

28.

Shri Gaurav
Gupta

Secretary, CREDAI

29.

Shri Rohit Raj
Modi,

Vice President, CREDAI

30.

Shri G Ram
Reddy

President Elect, CREDAI

25.

31.

32.

33.

34.

35.

Shri Abhay
Upadhyay
Shri Dipankar
Kumar

Shri Dinkar
Panday

Mr. Tarun
Bhatia

Shri Pankaj
Kapoor

President, Forum for People’s
Collective Efforts (FPCE)

New Era Flat Owners Welfare
Association (NEFOWA)

New Era Flat Owners Welfare
Association (NEFOWA)

Physically
Physically

Physically

Physically

Physically

VC

Physically

Physically

Physically

Vice Chairmen , National
Association of Realtors – India
(NAR-INDIA)

Physically

Managing Director, Liases Foras
Real Estate Rating & Research
Pvt. Ltd.

VC

<!-- page 14 -->

36.

Shri Karma
Bhutia

37.

Shri Samir
Jasuja

38.

Shri Anand J.
Gupta

39.
40.

Shri Vinod
Jacob
Shri Sushil
Kumar

Regional Director & Head Legal, ANAROCK Property
Consultant Pvt. Ltd.
Managing Director & CEO,
PropEquity, P.E. Analytics
Limited
Chairperson, Builder’s
Association of India
(BAI)
General Manager, Namma
Bengaluru Foundation
DD, PIB

********

VC

Physically

Physically

VC
Physically
