---
doc_id: "d0bf490f5a50cbed"
source_url: "https://www.dpiit.gov.in/static/uploads/2026/04/624615462d1981947c6ecb5defaa11ca.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Sikkim Logistics Policy 2025"
date: "2026-04-02"
pages: 22
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "32d0faa90fd5e24a"
---

<!-- page 1 -->

<!-- page 2 -->

COMMERCE& INDUSTRIES DEPARTMENT
GOVERNMENT OF SIKKIM.

SIKKIM STATE LOGISTIC POLICY,
2025

2

<!-- page 3 -->

INDEX
Page no:
1. INTROUCTION…………………………………………………………………………….……5-6
2. EXECUTIVE SUMMARY…………………………………………………………………...…7-13
3. DEFINITION, POLICY PERIOD, VISION, MISSION …………………………………….14
4. POLICY OBJECTIVES………………………………………………………………….….….15-18
5. INSTITUTIONAL FRAMEWORK………………………………………………………........19-20
6. INCENTIVE AND INTERVENTIONS IDENTIFIED………….…………………….……..20
7. PROCEDURE FOR AVAILING INCENTIVES………………………….…………………..20-21
8. APPLICIBILITY AND ELIGIBILITY FOR UNITS UNDER THE POLICY……….………21

3

<!-- page 4 -->

LIST OF ABBREVIATIONS

APEDA

Agricultural and Processed Food Products Export Development Authority

CAGR

Compound Annual Growth Rate

CFS

Container Freight Station

CWC

Central Warehousing Corporation

DGFT

Directorate General of Foreign Trade

DONER

Department of Development of North Eastern Region

ETP

Effluent Treatment Plant

FAR

Floor Area Ratio

FCI

Food Corporation of India

FIEO

Federation of Indian Export Organizations

FPO

Farmer Producer Organization

GRIHA

Green Rating for Integrated Habitat Assessment

IFP

Investor Facilitation portal

IQF

Individual Quick Freezing

ISO

International Organization for Standardization (ISO).

LLP

Limited Liability Partnership

MSME

Micro Small Medium Enterprises

NABL

National Accreditation Board for Testing and Calibration Laboratories

NEC

North Eastern Council

NEIIPP

North east Industrial and Investment Promotion Policy

NEIDS

North East Industrial Development Scheme

NGO

Non-Governmental Organization

PPC

Primary Processing Centre

PPP

Public Private Partnership

SIG

Service Improvement Group

SIIP

Sikkim Industrial and Investment Policy 2024

SIMFED

Sikkim State Co-operative Supply and Marketing Federation

SLCC

State level coordination committee

SLPMGC

State Logistics and PM GatiShakti Cell
4

<!-- page 5 -->

STP

Sewerage treatment plant

TFC

Trade Facilitation Center

VHT

Vapor Heat Treatment

WMS

Warehouse Management System

ZED

Zero Defect and Zero Effect

5

<!-- page 6 -->

Introduction
Logistics efficiency is a function of infrastructure, services (digital systems/processes/
regulatory framework) and human resource. The PM Gati Shakti National Master Plan (NMP)
for multimodal connectivity infrastructure to various economic zones has been launched. PM
Gati Shakti National Master Plan is a transformative approach for improving logistics
efficiency and reducing logistics cost, with focus on integration of existing and proposed
infrastructure development initiatives of different agencies, to ensure first and last mile
connectivity, for seamless movement of people and goods. While development of integrated
infrastructure and network planning is envisaged to be addressed through the PM Gati Shakti
National Master Plan, for efficiency in services (processes, digital systems, regulatory
framework) and human resource, the National Logistics Policy is the logical next step. This
will provide a comprehensive agenda for development of entire logistics ecosystem

Strategic Location
Sikkim is a landlocked State spread across 7,096 sq.km located in the North East of India,
that shares 3 (three) international borders with Nepal in the west, Bhutan in the east, Tibet
Autonomous Region of China in the north and Darjeeling and Kalimpong Districts in the State
of West Bengal surround the south of Sikkim. In 2002, it joined the North Eastern Council
(NEC) to become its 8th (eighth) and youngest member.

6

<!-- page 7 -->

State Population
Sikkim is the least populous State of India with a population of 6,10,577 in 2011 and is still
largely rural, over 60%(sixty percent) of the population is directly or indirectly dependent on
agriculture and allied sector. Sikkim's literacy rate had a remarkable jump from less than 7%
(seven percent) in 1951 to 97% (ninety-seven percent) in 2022. The State's per capita
income for 2021-22 is recorded as Rs. 4,72,543 [Rupees four Lakh Seventy-two
Thousand Five Hundred and Forty Three] (at current price) which is the highest in India.

7

<!-- page 8 -->

Executive Summary
Road network:
National highways mainly NH 10 of length 521.95km passes through the state. Over the last
3 (three) decades, the network of roads in the State has increased considerably.

1000
900
800
700
600
500
400
300
200
100
0

935.45
669.22

565.93

165.16

7.61

National
Highway
(NH)

State
Highway
(SH)

Major
District
Roads
(MDR)

1

2

3

Other Other PWD
District
Roads
Roads
(ODR)
4

5

260
Village
Roads

6

Source: Roads and Bridges Department, Government of Sikkim.

Rail network:
The Siliguri- Rangpo railway line will be completed by December 2024 thereby ensuring much
easier passenger and freight movement and also market access. This first rail network will
also link Bagdogra- the nearest functional airport- and will cut down the time to reach the
8

<!-- page 9 -->

State capital of Gangtok. Sikkim at present is connected by road only which runs through very
steep slopes and frequent disruptions during Monsoons. Rail connectivity will provide reliable
source of transportation infrastructure .

Air Network:
Sikkim has one domestic green field airport in Pakyong and has flight operation to Delhi and
Kolkata. The other nearest airport is Bagdogra in Darjeeling district of West Bengal and is
about 112 (one hundred and twelve) kms away from Gangtok.
Sikkim gained the title of “Achiever State” among the North East (NE) States in the LEADS
(Logistic Ease Across Different States) Survey2023 undertake by Ernst &Young under the
aegis of the Department of Promotion of Industry and Internal Trade(DPIIT), Government of
India which ranks states on the score of their logistic services and efficiency that is indicative
of economic growth.

9

<!-- page 10 -->

Source:
Tourism &
Civil Aviation
Department,
Government
of Sikkim.

Industrialization and Economy.
Industry plays a vital role in the economy of the State of Sikkim and has seen a great boom
in the Pharmaceutical and Hydroelectric power sectors in recent years. To attract investment
in industries, more liberalized incentives were enunciated in1991, followed by the incentives
under the Industrial Policy, 1996 and the Industrial promotion and Incentive (SIPI) Act, 2000
and its subsequent amendments in 2003 and 2007.

10

<!-- page 11 -->

11

<!-- page 12 -->

The strategies adopted by the Government of Sikkim to achieve its objectives will be focused
on sectors aligned with Goal 8 “Decent work and Economic Growth” and Goal 9 “Industry
Innovation and Infrastructure” respectively, under the Sustainable Development Goals
adopted by the United Nations in 2015.
The annual average growth of Gross State Domestic Product (hereinafter referred to
as GSDP) of Sikkim at constant prices based on the revised data provided by the CSO, during
2015-16 to 2022- 23 remained healthy at 7.82 percent leaving the pandemic affected year of
2020-21in which the GSDP grew by 0.33 percent. The economy has been on the path of
recovery since then and it grew at a rate of 5.99 percent in 2021-22 and 6.83 percent in 202223. The improvement in GSDP growth is expected to facilitate higher internal revenue
generation
Sikkim has a suitable climate for agricultural and horticultural products. It supports
multiple crops; viz., Rice, Wheat, Maize, Millet, Barley, Urad, Pea, Soya bean, Mustard and
large Cardamom. Sikkim is also the top producer of large cardamom, contributing over 80%
to India’s total production. In August 2019, Sikkim was declared as world’s first 100% organic
state by UN Food and Agriculture (FAO). Cardamom, Tea and Dalle (Chilly ) have obtained
GI (Geographical Indicator) Tags .
The implementation of schemes such as NEIIPP (North East Industrial & Investment
Promotion Policy) 2007, NEIDS (North East Industrial Development Scheme) 2017 and
UNNATI (Uttar Poorva Transformative Industrialization Scheme) 2024 by the Government of
India and the recently notified Sikkim Industrial and Investment Policy, 2024 is expected to
draw investment and employment opportunities for the states aspirational youth. The state
is also a Pharma Hub as a result of NEIIPP 2007 where more than 56 (fifty-six) major
Pharmaceutical companies have been established.
The state suffered a setback with the Glacial Lake Outburst (GLOF) in October,2022
which damaged and washed off major portions of the National Highway thereby cutting off
12

<!-- page 13 -->

the State and affecting supply chains for an extended period of time. This disaster severely
impacted the State’s Tourism Industry as connectivity was severely hampered. Districts of
Mangan and Pakyong were cut off, many families were displaced and required relief and
rehabilitation. However, with the help of the Government of India and the continued and
steadfast efforts of the State Government, the state’s economy is slowly but steadily on the
path of recovery and revival.
Thus, striking a balance between urban growth and environmental preservation
remains a critical challenge taking into consideration of Sikkim’s geographical constraints.
Yet, Sikkim has advanced in sustainable practices, including waste management and
conservation of natural resources, becoming the first state in India to be declared fully organic
in 2016. Now, as cities and urban towns continue to grow, achieving equitable economic and
social growth, promoting ease of doing business and ease of living becomes increasingly
essential to foster sustainable communities, reduce inequalities, and enhance the overall
quality of life of the citizens and fulfil the aspirations of the people of the state.
The State Government also recently announced the development of an Economic
Corridor between India and Nepal through Chewabhanjyang, District Gyalshing /Soreng to
boost trade and tourism in the region. The strengthening of a Logistic hub in the District would
boost and facilitate trade and economic activity.
The Prime Minister of India launched the National Logistics Policy on 17 th, September, 2022
in Vigyan Bhawan, New Delhi with an aim to enhance the livelability quotient of its citizens
and promote the ease of doing Business. The policy aims to lower the cost of logistics from
the current 13-14% and bring it at par with other developed countries. The reduced costs
would enable Indian companies to compete in the international market and also provide value
addition and support the development of enterprises and innovation as a result of the
efficiencies brought about in logistics.
The Sikkim State Logistics Policy, 2025 will support in strengthening its position in the
manufacturing, Services, processing and logistics sector which will be characterized by higher
levels of efficiency, sustainability, competitiveness, reliability, ease of doing business and
innovation. This policy is in synchronization with the guidelines of the Logistics Division of the
Ministry of Commerce and Industry, Government of India as stated in the draft National
Logistics Policy vide resolution No: 63/Logistics/2018/ dated 5/Feb/2019.
Towards this ambition of the State Government, this policy proposes preparation of a State
Logistics Master Plan for a unified and integrated development. A State Logistics and PM
GatiShakti Cell will be set up in the State which will coordinate with various stakeholders or
Industry partners to support, enhance, upgrade or develop the logistic facilities in conjunction
with the Master Plan.
It can be easily inferred that industrial growth and entrepreneurship are the real engines of
economic growth and employment. The Sikkim State Logistics Policy aims to attract
investment in the sectors which will reinforce the state economy, rejuvenate industrial growth,
create employment opportunities and most importantly retain the talent pool within the state.
Sikkim Sate Logistic Policy 2025 envisages integrated and holistic development of the
logistics sector in the State of Sikkim. The policy adopts some unique features such as
13

<!-- page 14 -->

improving utilization of existing infrastructure, single nodal agency for approvals and
grievances, incentives for technology implementation and skilling, sustainability in logistics
etc. to ensure comprehensive growth of the sector.

14

<!-- page 15 -->

1. DEFINITION:
‘Logistics’ means Transportation & handling of goods between points of production
and consumption, storage, value addition and allied services. The logistics
infrastructure comprises of nodes and connections, more recognizable as ports,
stations, Multimodal Logistics Parks (MMLPs), warehouses, and other business
premises, connected by roads, railways, air routes, pipelines, etc., that are used by a
wide range of carriers. This system is operated under a framework through a workforce
with a wide range of knowledge of skills and technologies.
2. POLICY PERIOD,
This Policy will come into force with effect from the date of its Notification and will remain valid
for a period of 5 (five) years or till the declaration of a new policy, whichever comes earlier.
3. VISION
“To facilitate and develop an integrated logistics ecosystem in Sikkim and to enhance
competitiveness, operational efficiency and sustainability through innovation, skilled
manpower, quality and disruptive technologies, thereby positioning Sikkim as a
favourable destination for trade and commerce for its entrepreneurs and businesses”.

4. MISSION:
The following mission goals have been identified for the policy:
I.
II.

III.
IV.
V.
VI.

to create an efficient and competitive logistics ecosystem to support Sikkim’s
industrial growth through regulatory reforms and streamlined processes.
promote and support private investment, Startups and businesses by developing
integrated logistics facilities in the state and enable them to compete in the
Domestic and International market.
reduce logistics cost and enhance efficiency by enabling multi modal transportation,
warehousing in a Hub and Spoke model.
ensure adequate supply of skilled manpower through continuous learning/
upskilling to meet the long term needs of the sector.
decarbonize the sector through adoption of green technology and sustainable
practices.
promote use of technology and innovation for driving operational and cost
efficiencies.

15

<!-- page 16 -->

5. POLICY OBJECTIVES:
Policy identifies clear and targeted objectives for the state along with their
implementation strategies, which are as follows:
5.1

Unified development Policy. This Policy aims to draw up a State Logistic Master Plan
and set up Logistic infrastructure to support the economy primarily in tourism and
hospitality, organic farming, food processing, health and wellness, manufacturing units
etc.
A Unified Development Master Plan for the state will map and identify areas for
intervention or improvement and development in line with use of the PM Gati Shakti
National Master Plan and State Master Plan under Prime Minister Gati Shakti
(PMGS). Mapping of the legal, regulatory and infrastructural facilities will take into
account the capacity and operational bottlenecks of existing logistics facilities, services
and the proposed development of road and rail network in the state to be connected
with the rest of the country. Additionally, it will ensure cognizance of the current
capacity versus future need of logistics infrastructure such as rail network, airports and
logistics facilities.

5.2

Efficient utilization of existing infrastructure facilities: This policy aims at
improving utilization of existing logistics facilities in which are under the control of either
private developers or various state government departments or agencies. The existing
facilities shall be evaluated on various performance parameters to improve their
utilization through relevant stakeholder consultations.

5.3

Development and augmentation of logistics facilities across the state: The policy
promotes development and augmentation of logistics facilities across the state in a
systematic manner as per the statewide mapping document (i.e., aligned with
objectives 4.1 and 4.2 above). Supporting facilities shall be explored for development
of Truck Terminals or Common Facility Centers or Food Godowns or Cold storage and
Processing Centers etc. in coordination with the Transport Department, Agriculture
Department, Food and Civil Supplies Department or SIMFED or Industry Associates
and Trade Partners or Export Councils and other connected departments or Agencies.

5.4

Development and augmentation of Industrial Parks across the State: The Policy
will promote the development of Industrial parks in the state which will serve as hubs
for employment generation, foster an environment of innovation and collaboration,
cultural integration, and create an enabling eco-system for commercialization of
technology, skills and competence at par with global standards. Earmarking of upto
20% Industrial Park will be allotted for Logistic infrastructure within the State based on
specific needs and potential of each industrial park. Detailed guidelines regarding the
applicability and selection criteria will be issued to help stakeholders understand and
comply with this policy.

5.5

Development of storage and Warehousing handling facilities: The policy focuses
on development of existing and upcoming storage and handling facilities at strategic
nodes to improve logistics efficiency in focus sectors such as pharmaceuticals, ecommerce, and agriculture related products etc., to overcome the low density of
organized logistics and warehousing facilities in the smaller towns and cities.
Development of facilities such as agricultural collection centers, processing centers,
cold storage and distribution centers close to farms shall be undertaken through
necessary inter-departmental discussion & coordination. Such development shall aid
16

<!-- page 17 -->

in reducing wastage of food and other perishable commodities, thereby improving
efficiency in the logistics chain. These developments shall be undertaken in
coordination with different government departments or agencies such as Food
Corporation of India (FCI), Central Warehousing Corporation (CWC), Export Councils,
Trade associations and Industry partners across the state.
5.6

Development of Air Freight Stations and Air Cargo Complexes at Pakyong
Airport and Development of Trade Infrastructure at Nathula, Chewabhanjyang
and other locations in the State:
Assessment of air cargo potential, current capacity constraints, air connectivity, etc.
shall be carried out. Accordingly, the development of air cargo terminals and air freight
stations shall be incorporated while mapping the facilities to boost air cargo as well as
in Nathula in East Sikkim and in parts of the State. This development will be carried
out in close consultation with customs authorities and in full alignment with relevant
customs regulations to ensure compliance and improve logistics efficiency.
Availability of space within the existing under-utilized airport/s to create cargo storage
shall be evaluated. Handling facilities, cargo and container handling equipment for
efficient operations, development of parking spaces for trucks and other vehicles to
avoid congestion at approach roads etc., shall also be evaluated, as required.

5.7

Support growth of e-commerce: The Indian e-commerce industry is expected to
grow at a CAGR of 27% between 2019-2043. Logistics would play a critical role in
sustaining and propelling this growth. The e-commerce retail logistics market was
valued at USD1.35 billion in 2018 and is projected to witness a growth of ~36 per cent
between 2018-2043. This policy promotes development of e-commerce hubs in high
movement zones, closer to demand locations and around the periphery of cities and
urban areas. This would address the needs of the e-commerce sector and also prevent
traffic congestion in cities.

5.8

Development of truck terminals, driver rest areas and parking spaces: The policy
aims to promote development of truck terminals for their repair and maintenance, driver
rest areas and parking spaces at strategic locations (national or state highways etc.),
near industrial parks and around the periphery of high cargo density areas. This will
ease out congestion and provide proper waiting areas to trucks during city timing
restrictions.

5.9

Strengthening first & last mile connectivity: This policy aims to expedite projects
related to first and last mile connectivity to existing and upcoming logistics facilities,
existing and upcoming Land Customs Stations, warehouses, grading and sporting
zones etc in a Hub and Spoke model.

5.10

Adoption of Ease of Doing Business: Aligned with the vision of Government of India,
Sikkim State Logistics Policy 2025 aims to improve the attractiveness of logistics
industry for private sector participation through collaboration and support from the
State Government, this policy also adopts “Ease of Doing Business” as one of its key
objectives. Simplification of procedures such as business registration, single source to
check business eligibility for availing incentives or subsidies, availability of desired
information on current processes and procedures, elimination of multiple touch points
in the approval process and reduction in turnaround time of the approval processes
17

<!-- page 18 -->

are some of the identified strategies to enable ease of doing business and eliminate
duplication of efforts.
5.11 Warehousing Policy: To strengthen the storage and supply chain ecosystem, Sikkim
will implement a dedicated warehousing policy focused on developing modern,
scientific, and disaster-resilient storage facilities. The policy will encourage private
sector participation through Public Private Partnership(PPP). Additionally, the use of
advance technologies like Warehouse Management Systems (WMS) and IoT enabled
monitoring will be promoted to optimize operations.
5.12 Industry status to Logistics: As a part of Sikkim State Logistics Policy 2025, the
Logistics sector is officially recognized as an Industry. This recognition ensures that
the logistics sector is treated at par with other industries under Sikkim’s Industrial and
Investment Policy.
5.13 City Logistic Master Plan: To streamline urban logistics operations and to improve
efficiency, the state will develop a City Logistics Master Plan. This plan will focus on
optimizing freight movement within the urban areas, reducing congestion, and
promoting sustainable practices such as green logistics solutions and efficient last-mile
delivery systems. Developed in collaboration with municipal authorities, urban
development department, transport department, stakeholders and the State Logistics
cell, the master plan will ensure a comprehensive approach to urban logistics,
addressing the unique challenges of Sikkim’s urban centers while fostering a more
efficient and sustainable logistics ecosystem.

5.14

Other key initiatives which will be taken under this policy for enhancing the
support system for logistics players are stated below:

1. Develop logistics infrastructure with disaster-resilient designs to withstand natural
calamities such as landslides earthquakes and heavy rainfall, ensuring uninterrupted
supply chain operation in Sikkim’s challenging terrain.

2. Expedite availability of power, water, right of way and other support infrastructure to
logistics facilities developed under this policy through coordination with relevant
departments or agencies
3. Similar support shall also be extended to those existing logistics facilities for enhancing
capacity utilization.
4. Plant and animal quarantine facilities shall be developed in the state to eliminate need for
transportation of cargo to other states for availing certifications, thereby reducing time and
cost.
5. A State Logistics and PM GatiShakti Cell (hereinafter referred to SLPMGC) shall be
constituted with a focused aim of promoting the logistic sector in the state and facilitating
trade and commerce. The SLPMGC, led by the Industries Department shall be the nodal
agency for processing applications received under this policy and shall develop an internal
approval mechanism for the same aided by an Investor Facilitation portal (hereinafter
referred to as IFP) which will function as single window for providing services such as
18

<!-- page 19 -->

statutory clearances, land allotments, application and registration of the units, trade
facilitation and other such support under the Policy. Information dissemination of State’s
logistics sector and regulatory environment on National or State portals will be ensured by
the Cell. The SLPMGC shall also function as the city logistics cell and assist in city logistic
planning, ensuring a comprehensive approach to urban freight management, congestion
reduction, and adoption of sustainable practices.
6. A Grievance Redressal mechanism for providing time bound and effective resolution to
issues and challenges shall also be established under this policy.
7. Similarly, to give a boost to the logistics sector in the state, private sector participation is
encouraged under this policy. The private sector can contribute to the development of
logistics sector by providing capital, technical expertise, management practices and
flexibility in operations.

8. This policy will also promote digitalization of processes at existing and upcoming logistics
facilities. Training for managerial and ground level roles will be essential to upgrade the
overall capability matrix of the workforce involved in logistics. For this, sector specific
skilling programs or courses shall be initiated to build manpower capability in the sector.
This shall be undertaken through tie-ups with national and state level educational
institutions and government bodies.
9. This policy also promotes green or sustainably drive logistics through installation of solar
panels, rainwater harvesting, solid or liquid waste management, scientific disposal
techniques, setting of ETPs or STPs, use of biodegradable items, adopting recycling
techniques and use of renewable energy at logistics facilities. The policy supports
development of new logistics and encourages existing facilities to adhere to Green Norms,
GRIHA norms and other sustainable development norms as prevalent in the logistics
sector.
10. Detailed guidelines including implementation mechanism of schemes and incentives
stated herein to achieve the objectives set under this policy shall be developed by the
State Logistic Cell. An Internal monitoring mechanism for each of the identified objectives
and implementation strategies will also be developed and put in place.

19

<!-- page 20 -->

6. INSTITUTIONAL FRAMEWORK:
(I)

The State Logistics and PM GatiShakti Cell (SLPMGC)comprising of Senior
officials of the Department of Commerce and Industries shall work in tandem
with other Industry and stakeholders for implementation of this policy through
the following mechanism.

(II)

Evaluation of applications and disbursement of incentives proposed under the
policy. The Investor Facilitation Portal (IFP) will be put in place for with
streamlined and time bound processes to facilitate applicants wishing to
avail incentives or support under this policy.

(III)

Once, the investment application is received on IFP, the SLPMGC shall
evaluate it and put forth the recommendations on the proposal to the State
Level Logistics Coordination Committee for approval. Upon approval, the
SLPMGC will disburse the incentives under this policy and provide necessary
support to the unit or project.

The State Logistics Coordination Committee shall also review and suggest amendments
and revision in this policy at regular intervals.
6.1

Enhance utilization of existing facilities. There are various warehouses, cold storage
units and other logistics facilities in the State owned by private parties / project and public
departments or organizations. The SLPMGC, in consultation with relevant stakeholders,
shall work towards enhancing the utilization of these existing facilities. The Committee
would provide overall direction to the growth of the logistics sector in the state.

6.2

A State Level Logistics Coordination Committee (SLCC) consisting of members from
the following departments or agencies will be constituted for sanctioning of assistance with
respect to various proposals received under the policy: 01
02
03
04

05

06

Secretary

Commerce
and
Industries Department
Director
Finance Department
Managing Director
SIDICO
Senior
official
not Planning Department
below the rank of
Additional Secretary
Senior
official
not
below the rank of
Additional Secretary of
the concerned Line
department
Director, (Industries)
Commerce and Industries
Department.

Chairperson
Member
Member
Member

Member

Member Secretary

20

<!-- page 21 -->

6.3

Terms of Reference:
i.

The Committee is authorized for interpretation of any provision and to give
clarification or decision with reference to any provisions under this policy and
associated resolution and it will be final and binding to the applicants. The
committee shall be competent to include or exclude any facility from the ambit of
resolution to ensure all-inclusive growth of the logistics sector in the state.

ii.

The State Level Coordination Committee (SLCC) will approve/examine all
proposals under the policy on the Investor Facilitation Portal (IFP). The State Level
Coordination Committee (SLCC) will ensure all proposals are examined and
decision taken within 90 (ninety) days from the date of filing of application on the
portal.

iii.

The Department of Commerce and Industries, Government of Sikkim reserves the
right to amend any provision(s) including amendment or withdraw any of the
incentives/subsidies as and when necessary for development of export or Logistics
and in the interest of the general people of the State from time to time under the
provision of the policy.

iv.

The Department of Commerce and Industries, Government of Sikkim reserves the
right to review the matter regarding sanction or disbursement of
subsidies/incentives to the eligible unit(s) and in this connection; the State
Government’s decision shall be final and binding.

v.

The State Logistics coordination committee will function as the Service
Improvement Group(SIG) in alignment with the National Logistics Policy. The SIG
will focus on addressing bottlenecks, improving logistics efficiency, and
implementing service enhancements across the logistics sector.

7. INCENTIVES AND INTERVENTIONS IDENTIFIED UNDER THE POLICY.
7.1 Logistics shall be given Industrial status and the Logistic Industry shall avail incentives as
per the Sikkim Industrial and Investment Policy-2024 (SIIP-2024).

8. PROCEDURE FOR AVAILING INCENTIVES.
The following process shall be adopted and outlined for availing policy incentives. Unit
or project shall apply on Investors Facilitation Portal for registration of proposed logistics
facilities.
After taking 100% (hundred percent) possession of the purchased or leased
land, the Unit/ project shall apply on IFP along with the Detailed Project Report or Bank
Appraisal or Bank Sanction The details will be reviewed by the State Logistics and
PM
Gatishakti Cell (SLPMGC) for sanctioning of financial assistance to the project.
The Unit/ project will submit the claim of assistance to the State Logistics and
PM Gatishakti Cell (SLPMGC) in the prescribed Pro forma after commencement of
21

<!-- page 22 -->

Business not more than 18 (Eighteen) months from the date from registration. The
institution shall have to inform the SLPMGC if they have applied for incentives under
any scheme of Government of India or Government of Sikkim.
Amendments to the policy by the State Logistics and PM GatiShakti Cell (SLPMGC),
in consultation with relevant government departments shall have the right to review the
provisions of this policy from time to time and include or amend or delete provisions as
it may deem fit for the growth of this sector.
Once approval is accorded for disbursement of scheme incentives, the same will be
disbursed through SIDICO or State Bank of Sikkim.

9. APPLICABILITY AND ELIGIBILITY FOR UNITS UNDER THE POLICY.
Incentives under the policy shall be applicable to Proprietorial firm, Partnership firm,
Cooperative Societies, Limited liability Companies (LLP), Private Limited Company,
Limited Company, Trust, Non-Government Organization (NGO), State Registered
MSME Units, FPO or FPC as well as such infrastructure created by State Government.
Central Government agency or Public sector undertaking shall not be eligible for any
incentives under the Policy.
The following shall be the essential conditions to be followed for eligibility purposes,
namely: 1.

Industrial Park- A logistic park / Industrial Park should have a single stretch of
minimum 5 (five) acres of land (usable for the purpose).

2.

The minimum fixed capital investment should be ₹1 .00 (Rupees one) Cr for
development of infrastructure in the Logistic Park.

3.

The applicant unit has employment of minimum 80 % people of Sikkimese origin
in the Managerial Cadre and minimum 90% people of Sikkimese Origin in NonManagerial Cadre.

7.

The applicant unit should follow the existing rules and regulations related to
environmental clearances, construction regulations, standard norms, Labour
laws etc. as defined and prescribed by competent authority.

9.

Fixed Capital Investment means and includes investment in plant and
machinery only.

11.

Units availing incentives under the policy shall continue their operation at least
5 (five) years from the date of receipt of the incentives under the policy. In case
of closure of the unit within the stipulated time, the amount so far released as
incentives shall be recovered with prevailing rate of interest within three months.

***********

22
