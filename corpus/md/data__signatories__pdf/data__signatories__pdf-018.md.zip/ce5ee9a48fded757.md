---
doc_id: "ce5ee9a48fded757"
source_url: "https://www.darpg.gov.in/static/uploads/2026/09/dbdb0a48a50f2cc3fb61ff315ce3d41a.pdf"
ministry: "Department of Administrative Reforms and Public Grievances (DARPG)"
title: "Revised Handbook on POSH Act, 2013"
date: "2026-09-28"
pages: 58
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "08cd208533123e61"
---

<!-- page 1 -->

HANDBOOK
On
Sexual Harassment of
Women at Workplace
(Prevention, Prohibition and Redressal) Act, 2013
for Employers / Institutions / Organisations/
Internal Complaints Committee / Local Complaints Committee

Towards a new dawn

Government of India
Ministry of Women and Child Development

NOVEMBER 2015

<!-- page 2 -->

HANDBOOK
on
Sexual Harassment of Women at Workplace
(Prevention, Prohibition and Redressal) Act, 2013
for Employers / Institutions / Organisations/
Internal Complaints Committee / Local Complaints Committee

Government of India
Ministry of Women and Child Development
November 2015

<!-- page 3 -->

<!-- page 4 -->

Contents
SECTION 1: INTRODUCTION

1

1.1

THE MANDATE

3

1.2

THE GENESIS

3

1.3

THE ACT

4

1.4 PURPOSE OF THIS HANDBOOK

5

1.5

WHO IS THIS HANDBOOK FOR?

5

1.6 STRUCTURE OF THE HANDBOOK

5

SECTION 2: WORKPLACE SEXUAL HARASSMENT- WHAT IS IT?
2.1

WHO IS AN AGGRIEVED WOMAN

7
7

2.2 WHAT IS A WORKPLACE?

8

2.3 WHAT IS SEXUAL HARASSMENT AT WORKPLACE?

9

2.4 KEY ELEMENTS OF WORKPLACE SEXUAL HARASSMENT

9

2.5 EXAMPLES OF BEHAVIOURS AND SCENARIOS THAT CONSTITUE SEXUAL HARASSMENT

12

2.6 FORMS OF SEXUAL HARASSMENT

14

2.7 SCENARIOS

14

SECTION 3: PREVENTION & PROHIBITION
3.1

18

PREVENTIVE AUTHORITIES

18

3.2 WHO IS A DISTRICT OFFICER (DO)?

19

3.3 RESPONSIBILITIES OF THE AFOREMENTIONED AUTHORITIES

19

SECTION 4 : REDRESS

23

4.1 WHO CAN COMPLAIN AND WHERE?

23

4.2 WHAT SHOULD THE COMPLAINT CONTAIN?

24

4.3 WHAT CAN AN EMPLOYEE/WORKER EXPECT?

24

4.4 KEY RESPONSIBILITIES

25

4.5 KNOWLEDGE, SKILLS, TRAINING

25

4.6 DO’S AND DON’TS FOR COMPLAINTS COMMITEE

26

4.7 NON-NEGOTIABLES DURING THE INQUIRY PROCESS

27

4.8 THE SEXUAL HARASSMENT COMPLAINT PROCESS

27

4.9 AT A GLANCE

34

SECTION 5: MONITORING

37

SECTION 6: GLOBAL NORMS AND GOOD PRACTICES

39

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

“The meaning and content of the fundamental rights
guaranteed in the Constitution of India are of sufficient
amplitudes to encompass all facets of gender equality….”
Late Chief Justice J.S. Verma, Supreme Court of India, Vishaka v. State of Rajasthan

<!-- page 15 -->

<!-- page 16 -->

S ECTION

1
Introduction
“Whereas sexual harassment results in violation of the fundamental rights
of a Woman to equality ... ”
[Preamble, Sexual Harassment of Women at Workplace (Prevention,
Prohibition & Redressal) Act]

A

s enshrined in the Preamble to the Constitution of India, “equality of status and opportunity”
must be secured for all its citizens; equality of every person under the law is guaranteed by
Article 14 of the Constitution.

A safe workplace is therefore a woman’s legal right. Indeed, the Constitutional doctrine of equality
and personal liberty is contained in Articles 14, 15 and 21 of the Indian Constitution. These articles
ensure a person’s right to equal protection under the law, to live a life free from discrimination
on any ground and to protection of life and personal liberty. This is further reinforced by the UN
Convention on the Elimination of all Forms of Discrimination against Women (CEDAW), which was
adopted by the UN General Assembly in 1979 and which is ratified by India. Often described as an
international bill of rights for women, it calls for the equality of women and men in terms of human
rights and fundamental freedoms in the political, economic, social, cultural and civil spheres. It
underlines that discrimination and attacks on women’s dignity violate the principle of equality of
rights.
Sexual harassment constitutes a gross violation of women's right to equality and dignity. It
has its roots in patriarchy and its attendant perception that men are superior to women and
that some forms of violence against women are acceptable. One of these is workplace sexual
harassment, which views various forms of such harassment, as harmless and trivial. Often, it is
excused as ‘natural’ male behaviour or ‘harmless flirtation’ which women enjoy. Contrary to these
perceptions, it causes serious harm and is also a strong manifestation of sex discrimination at the
workplace. Not only is it an infringement of the fundamental rights of a woman, under Article 19
(1) (g) of the Constitution of India “to practice any profession or to carry out any occupation, trade
or business”; it erodes equality and puts the dignity and the physical and psychological well-being
of workers at risk. This leads to poor productivity and a negative impact on lives and livelihoods.
To further compound the matter, deep-rooted socio-cultural behavioural patterns, which create
a gender hierarchy, tend to place responsibility on the victim, thereby increasing inequality in the
workplace and in the society at large.
1

<!-- page 17 -->

Handbook on Sexual Harassment of Women at Workplace

Though sexual harassment at the workplace has assumed serious proportions, women do not
report the matter to the concerned authorities in most cases due to fear of reprisal from the
harasser, losing one’s livelihood, being stigmatized, or losing professional standing and personal
reputation.
Across the globe today, workplace sexual harassment is increasingly understood as a violation
of women's rights and a form of violence against women. Indeed, the social construct of male
privileges in society continues to be used to justify violence against women in the private and
public sphere. In essence, sexual harassment is a mirror reflecting male power over women that
sustains patriarchal relations. In a society where violence against women, both subtle and direct,
is borne out of the patriarchal values, women are forced to conform to traditional gender roles.
These patriarchal values and attitudes of both women and men pose the greatest challenge in
resolution and prevention of sexual harassment. Workplace sexual harassment, like other forms
of violence, is not harmless. It involves serious health, human, economic and social costs, which
manifests themselves in the overall development indices of a nation.
The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013
was enacted to ensure safe working spaces for women and to build enabling work environments
that respect women’s right to equality of status and opportunity. An effective implementation
of the Act will contribute to the realization of their right to gender equality, life and liberty,
equality in working conditions everywhere. The sense of security at the workplace will
improve women’s participation in work, resulting in their economic empowerment and inclusive
growth.
The full scale of the problem is not known given the difficulties in documenting the experience
of those who have experienced workplace sexual harassment. However, available studies on
sexual harassment show that it is certainly prevalent in India today. This is why the legislation is an
important step forward within the larger architecture of women’s rights, as it tackles this issue to
secure the rights of women workers across the country.
While the official figures for women’s work participation are low, much of the work that women
do is not captured in official data accounts. It is argued 1 that where this is to be captured, women’s
overall work participation would be 86.2 per cent. While the official data 2 shows that women’s
work participation rate is around 25.3 per cent in rural areas and 14.7 per cent in the urban areas,
estimates indicate that there is a huge workforce of women, therefore there is a need to secure
their workplace and entitlements. Given, that 93 per cent of women workers are employed in the
informal sector, they remain unprotected by laws. With no laws or mechanisms to protect them,
proactive measures are required to make their workplaces safe.

1
2

Professor Jayati Ghosh, Paper on ‘What Exactly is Work? http://www.macroscan.org/cur/oct14/pdf/Exactly_Work.pdf
NSSO 2011-12

2

<!-- page 18 -->

Handbook on Sexual Harassment of Women at Workplace

It is well established that ensuring safe working conditions for women leads to a positive impact
on their participation in the workforce and increases their productivity, which in turn benefits the
nation as a whole. Economically, empowered women are key to the nation’s overall development
and this can only be achieved if it is ensured that women’s workspaces across all sectors and all
over the country have a safe and secure environment for work.
It is important as well to ensure that the emphasis is on prevention rather than punitive action.
This calls for widespread awareness on the Act among employers, managers and the workers
themselves. Frequently, women workers may face sexual harassment but may not be aware that
it is a breach of their rights and that there is something they can do about it. They need to know
that they can do something about it. Then there are others, who may believe that it is a personal
matter that needs to be resolved by the people involved. In order to change this order of things, it
is urgent that measures are taken to change mind-sets and attitudes by creating awareness about
what constitutes sexual harassment and the steps that can be taken to address it.
This handbook will serve as an important tool to make workplaces safe and benefit both workers
and employers alike, leading to mutual gains.

1.1 THE MANDATE
Today, all workplaces in India are mandated by law to provide a safe and secure working
environment free from sexual harassment for all women.

1.2 THE GENESIS
In 1992, a rural level change agent, Bhanwari Devi, was engaged by the state of Rajasthan as a
Sathin3 to work towards the prevention of the practice of child marriages. During the course of her
work, she prevented the marriage of a one-year old girl in the community. Her work was met with
resentment and attracted harassment from men of that community. Bhanwari Devi reported this
to the local authority but no action was taken. That omission came at great cost – Bhanwari was
subsequently gang raped by those very men.
The Bhanwari Devi case revealed the ever-present sexual harm to which millions of working women
are exposed across the country, everywhere and everyday irrespective of their location. It also
shows the extent to which that harm can escalate if nothing is done to check sexually offensive
behaviour in the workplace.
Based on the facts of Bhanwari Devi’s case, a Public Interest Litigation (PIL) was filed by Vishaka and
other women groups against the State of Rajasthan and Union of India before the Supreme Court
of India. It proposed that sexual harassment be recognized as a violation of women`s fundamental
right to equality and that all workplaces/establishments/institutions be made accountable and
responsible to uphold these rights.
3

Sathin’ means a friend

3

<!-- page 19 -->

Handbook on Sexual Harassment of Women at Workplace

In a landmark judgment, Vishaka vs. State of Rajasthan (1997) 4, the Supreme Court of India created
legally binding guidelines basing it on the right to equality and dignity accorded under the Indian
Constitution as well as by the UN Convention on the Elimination of All Forms of Discrimination
against Women (CEDAW).
It included:
◆ A definition of sexual harassment
◆ Shifting accountability from individuals to institutions
◆ Prioritizing prevention
◆ Provision of an innovative redress mechanism
The Supreme Court defined sexual harassment as any unwelcome, sexually determined physical,
verbal, or non-verbal conduct. Examples included sexually suggestive remarks about women,
demands for sexual favours, and sexually offensive visuals in the workplace. The definition also
covered situations where a woman could be disadvantaged in her workplace as a result of threats
relating to employment decisions that could negatively affect her working life.
It placed responsibility on employers to ensure that women did not face a hostile environment,
and prohibited intimidation or victimization of those cooperating with an inquiry, including the
affected complainant as well as witnesses.
It directed for the establishment of redressal mechanism in the form of Complaints Committee,
which will look into the matters of sexual harassment of women at workplace. The Complaints
Committees were mandated to be headed by a woman employee, with not less than half of its
members being women and provided for the involvement of a third party person/NGO expert on
the issue, to prevent any undue pressure on the complainant. The guidelines extended to all kinds
of employment, from paid to voluntary, across the public and private sectors.
Vishaka established that international standards/law could serve to expand the scope of India’s
Constitutional guarantees and fill in the gaps wherever they exist. India’s innovative history in
tackling workplace sexual harassment beginning with the Vishaka Guidelines and subsequent
legislation has given critical visibility to the issue. Workplaces must now own their responsibility
within this context and ensure that women can work in safe and secure spaces.

1.3 THE ACT
Having raised the bar of responsibility and accountability in the Vishaka Guidelines, the Supreme
Court placed an obligation on workplaces, institutions and those in positions of responsibility, to
uphold working women’s fundamental right to equality and dignity at the workplace. Three key
obligations were imposed on institutions to meet that standard, namely:
4

(AIR 1997 Supreme Court 3011)

4

<!-- page 20 -->

Handbook on Sexual Harassment of Women at Workplace

◆ Prohibition
◆ Prevention
◆ Redress
In 2013, the Government of India notified the Sexual
Harassment of Women at Workplace (Prevention,
Prohibition and Redressal) Act (referred to as Act
hereinafter). Consistent with the Vishaka judgment,
the Act aspires to ensure women’s right to workplace
equality, free from sexual harassment through
compliance with the above mentioned three elements.
It is important to note that the Act provides a
civil remedy to women and is in addition to other
laws that are currently in force. Consequently,
any woman who wishes to report instances of
sexual harassment at the workplace has the right to
take recourse of both civil and criminal proceedings.

1.4 PURPOSE OF THIS HANDBOOK
This handbook is meant for all workplaces/institutions/organizations to provide a basic
understanding of sexual harassment at places of work. Additionally, it is designed to offer Internal
Complaints Committee/s and Local Complaints Committee/s (Complaints Committee/s) established
under the Act, with simple, user friendly information on sexual harassment; what is expected of
Complaints Committee/s to redress a complaint; and what the inquiry process and outcome should
include.

1.5 WHO IS THIS HANDBOOK FOR
This handbook informs the end user (an employee/worker) about workplace sexual harassment
and their right to an informed complaint process in seeking redress as provided under the Act and
Rules framed thereunder.

1.6 STRUCTURE OF THE HANDBOOK
This Handbook has 6 sections, with each containing information for women, male co-workers as
well as their employers, on how to deal with sexual harassment at the workplace in the context
of the Act.
Section 1 serves as an introduction, as it details the genesis of the Act and the history behind it,
as well as provides a brief description of the Act itself. This section also describes the
purpose of this handbook and who it is designed for.

5

<!-- page 21 -->

Handbook on Sexual Harassment of Women at Workplace

Section 2 sets the context by defining a workplace and sexual harassment. It provides the reader
with key elements, such as examples of sexual harassment as well as scenarios and the
impact of such behaviour.
Section 3 focuses on the key individuals and institutions involved in the prohibition and prevention
processes and their responsibilities.
Section 4 is about redress. This section identifies and defines the key players involved in the
complaint mechanism (including the complainant and the respondent). It details the
stages of the complaint process. Particular attention is paid to the complaints committee
which plays a very important role in this process.
Section 5 describes the monitoring requirements as per the Act.
Section 6 lists the important international frameworks and select best practices on sexual
harassment at the workplace.

6

<!-- page 22 -->

S ECTION

2
Workplace Sexual Harassment- What Is It?
“No woman shall be subjected to sexual harassment at any workplace.”
Section 3(1) of the Sexual Harassment of Women at Workplace
(Prevention, Prohibition and Redressal) Act, 2013

his section defines the aggrieved woman, workplace and sexual harassment as well as
highlights key elements of workplace sexual harassment. It provides examples of behaviours
through which a woman can experience possible professional and personal harm. It presents
the user with scenarios from across-section of work contexts to build clarity on different forms of
sexual harassment as identified under the Act.

T

2.1 WHO IS AN AGGRIEVED WOMAN?
The Act recognizes the right of every woman to a safe and secure workplace environment
irrespective of her age or employment/work status. Hence, the right of all women working or
visiting any workplace whether in the capacity of regular, temporary, adhoc, or daily wages basis
is protected under the Act.
It includes all women whether engaged directly or through an agent including a contractor, with
or without the knowledge of the principal employer. They may be working for remuneration, on a
voluntary basis or otherwise. Their terms of employment can be express or implied.
Further, she could be a co-worker, a contract worker, probationer, trainee, apprentice, or called by
any other such name. The Act also covers a woman, who is working in a dwelling place or house.

7

<!-- page 23 -->

Handbook on Sexual Harassment of Women at Workplace

2.2 WHAT IS A WORKPLACE?
A workplace is defined as “any place visited by the employee arising out of or during the course of
employment, including transportation provided by the employer for undertaking such a journey.”
As per this definition, a workplace covers both the organised and un-organised sectors.
It also includes all workplaces whether owned by Indian or foreign company having a place of
work in India. As per the Act, workplace includes:
-

Government organizations, including Government company, corporations and cooperative
societies;

-

Private sector organisations, venture, society, trust, NGO or service providers etc. providing
services which are commercial, vocational, educational, sports, professional, entertainment,
industrial, health related or financial activities, including production, supply, sale, distribution
or service;

-

Hospitals/Nursing Homes;

-

Sports Institutes/Facilities;

-

Places visited by the employee (including while on travel) including transportation provided by
employer;

-

A dwelling place or house.

The Act defines the Unorganised Sector as:
• Any enterprise owned by an individual or self-employed workers engaged in the production or
sale of goods or providing services of any kind;
• Any enterprise which employs less than 10 workers.
All women working or visiting workplaces, for example:

8

<!-- page 24 -->

Handbook on Sexual Harassment of Women at Workplace

2.3 WHAT IS SEXUAL HARASSMENT AT THE WORKPLACE?
“Sexual Harassment” includes anyone or more of the following unwelcome acts or behaviour
(whether directly or by implication), namely:
1.

Physical contact or advances;

2. A demand or request for sexual favours;
3. Making sexually coloured remarks;
4. Showing pornography;
5. Any other unwelcome physical, verbal or non-verbal conduct of a sexual nature

2.4 KEY ELEMENTS OF WORKPLACE SEXUAL HARASSMENT
Very often situations that start off innocently end up in inappropriate and unprofessional
behaviours. It is important to remember that workplace sexual harassment is sexual, unwelcome
and the experience is subjective. It is the impact and not the intent that matters and it almost always
occurs in a matrix of power. It is possible that a woman may experience a single instance of sexual
harassment or a series of incidents over a period of time. It is important also to remember that
each case is unique and should be examined in its own context and according to the surrounding
circumstances as a whole.
THE FIRST STEP TO PREVENTION IS
The following table highlights the subjective
RECOGNITION
nature of the experience and the impact it may
Workplace Sexual Harassment is
have on the person involved, irrespective of the
behaviour that is
intent of such behaviour.
To enable prevention of sexual harassment at
the workplace, it is critical to recognize and
differentiate between welcome and unwelcome
sexual behaviour. Listed are some examples of
how “unwelcome” and “welcome” behaviour is
experienced.
9

UNWELCOME
SEXUAL in nature
A SUBJECTIVE experience
IMPACT not intent is what matters
Often occurs in a matrix of POWER

<!-- page 25 -->

Handbook on Sexual Harassment of Women at Workplace

UNWELCOME

WELCOME

Feels bad

Feels good

One-sided

Reciprocal

Feels powerless

In-control

Power-based

Equality

Unwanted

Wanted

Illegal

Legal

Invading

Open

Demeaning

Appreciative

Causes anger/sadness

Happy

Causes negative self-esteem

Positive self-esteem

Impact of inappropriate behaviour
The impact of sexual harassment at the workplace is far-reaching and is an injury to the equal
right of women. Not only does it impact her, it has a direct bearing on the workplace productivity
as well as the development of the society. Below is a list of select examples of such negative
impacts.

10

<!-- page 26 -->

Handbook on Sexual Harassment of Women at Workplace

Professional
• Decreased work performance
• Increased absenteeism, loss of pay

Personal
• Depression
• Anxiety, panic attacks
• Traumatic stress

• Loss of promotional opportunities

• Sleeplessness

• Retaliation from the respondent, or

• Shame, guilt, self-blame

colleagues/ friends of the respondent
• Subjected to gossip and scrutiny at work

• Difficulty in concentrating
• Headaches
• Fatigue, loss of motivation

• Being objectified

• Personal Difficulties with time

• Becoming publicly sexualized

• Eating disorders (weight loss or gain)

• Defamation
• Being ostracized
• Having to relocate

• Feeling betrayed and/or violated
• Feeling angry or violent towards the respondent
• Feeling powerless
• Loss of confidence and self esteem
• Over all loss of trust in people

• Job and career consequences
• Weakened support network

• Problems with intimacy
• Withdrawal and isolation

SEXUAL HARASSMENT IS A SUBJECTIVE EXPERIENCE
In 2010, the High Court of Delhi endorsed the view that sexual harassment is a subjective
experience and for that reason held “We therefore prefer to analyze harassment from the
[complainant’s] perspective. A complete understanding of the [complainant’s] view requires...
an analysis of the different perspectives of men and women. Conduct that many men consider
unobjectionable may offend many women... Men tend to view some forms of sexual harassment
as “harmless social interactions to which only overly-sensitive women would object. The
characteristically male view depicts sexual harassment as comparatively harmless amusement.
... Men, who are rarely victims of sexual assault, may view sexual conduct in a vacuum without
a full appreciation of the social setting or the underlying threat of violence that a woman may
perceive.”
Dr. Punita K. Sodhi v. Union of India & Ors. W.P. (C) 367/2009 & CMS 828, 11426/2009
On 9 September, 2010, in the High Court of Delhi

11

<!-- page 27 -->

Handbook on Sexual Harassment of Women at Workplace

2.5 EXAMPLES OF BEHAVIOURS AND
SCENARIOS THAT CONSTITUE SEXUAL
HARASSMENT
Below are examples of behaviour that may or
may not constitute workplace sexual harassment
in isolation. At the same time, it is important
to remember that more often than not, such
behaviour occurs in cluster. Distinguishing
between these different possibilities is not an
easy task and requires essential training and skill
building.
Some examples of behaviour that constitute sexual harassment at the workplace:
1.

Making sexually suggestive remarks or innuendos.

2. Serious or repeated offensive remarks, such as teasing related to a person’s body or appearance.
3. Offensive comments or jokes.
4. Inappropriate questions, suggestions or remarks about a person’s sex life.
5. Displaying sexist or other offensive pictures, posters, mms, sms, whatsapp, or e-mails.
6. Intimidation, threats, blackmail around sexual favours.
7. Threats, intimidation or retaliation against an employee who speaks up about unwelcome
behaviour with sexual overtones.
8. Unwelcome social invitations, with sexual overtones commonly understood as flirting.
9. Unwelcome sexual advances which may or may not be accompanied by promises or threats,
explicit or implicit.

12

<!-- page 28 -->

Handbook on Sexual Harassment of Women at Workplace

10. Physical contact such as touching or pinching.
11. Caressing, kissing or fondling someone against her will (could be considered assault).
12. Invasion of personal space (getting too close for no reason, brushing against or cornering
someone).
13. Persistently asking someone out, despite being turned down.
14. Stalking an individual.
15. Abuse of authority or power to threaten a person’s job or undermine her performance against
sexual favours.
16. Falsely accusing and undermining a person behind closed doors for sexual favours.
17. Controlling a person’s reputation by rumour-mongering about her private life.
Some examples of behaviour that may indicate underlying workplace sexual harassment and
merit inquiry:
1.

Criticizing, insulting, blaming, reprimanding or condemning an employee in public.

2. Exclusion from group activities or assignments without a valid reason.
3. Statements damaging a person’s reputation or career.
4. Removing areas of responsibility, unjustifiably.
5. Inappropriately giving too little or too much work.
6. Constantly overruling authority without just cause.
7. Unjustifiably monitoring everything that is done.
8. Blaming an individual constantly for errors without just cause.
9. Repeatedly singling out an employee by assigning her with demeaning and belittling jobs that
are not part of her regular duties.
10. Insults or humiliations, repeated attempts to exclude or isolate a person.
11. Systematically interfering with normal work conditions, sabotaging places or instruments of
work.
12. Humiliating a person in front of colleagues, engaging in smear campaigns.
13. Arbitrarily taking disciplinary action against an employee.
14. Controlling the person by withholding resources (time, budget, autonomy, and training)
necessary to succeed.
Some examples of workplace behaviours that may not constitute sexual harassment:
1.

Following-up on work absences.

2. Requiring performance to job standards.

13

<!-- page 29 -->

Handbook on Sexual Harassment of Women at Workplace

3. The normal exercise of management rights.
4. Work-related stress e.g. meeting deadlines or quality standards.
5. Conditions of works.
6. Constructive feedback about the work mistake and not the person.

2.6 FORMS OF WORKPLACE SEXUAL HARASSMENT
Generally workplace sexual harassment refers to two common forms of inappropriate behaviour:
• Quid Pro Quo (literally ‘this for that’)
-

Implied or explicit promise of preferential/detrimental treatment in employment

-

Implied or express threat about her present or future employment status

• Hostile Work Environment
-

Creating a hostile, intimidating or an offensive work environment

-

Humiliating treatment likely to affect her health or safety

2.7 SCENARIOS
The following scenarios have been constructed as examples based on real life experiences of
women at workplaces. The scenarios attempt to build an understanding of the two types of
workplace sexual harassment as prescribed by the Act i.e. quid pro quo and hostile environment.
The names in the following examples are fictional and in no way refer to any individual alive or
dead.

A. Examples of scenarios that constitute quid pro quo or ‘this for that’ type of sexual
harassment at the workplace:
SCENARIO EXAMPLE 1
Kamini is a bright young team leader working in a call centre. Known to be forthright, she is
dedicated, hardworking and is a perfectionist.
Kamini stays back at work late one evening with her colleague Ravi to complete work for an
important presentation. Ravi offers to buy Kamini dinner and later drop her home since it’s been
a long day. After dinner, Ravi proposes to Kamini that he would like her to spend the night with
him. Kamini refuses politely but firmly and goes home. Next evening, Ravi repeats his request and
on Kamini’s refusal, threatens her that if she doesn’t give-in, he will tell everyone that she made a
pass at him.

What is Workplace ‘this for that’ Sexual Harassment?
In the above example, Ravi’s threat to Kamini that if she does not agree to his ‘request’ for a sexual
favour, he will in return smear her character at the workplace as a person who wants to use sexual
14

<!-- page 30 -->

Handbook on Sexual Harassment of Women at Workplace

favours to her advantage constitutes quid pro quo form of sexual harassment. Ravi’s behaviour is
unwelcome, sexual, and has a negative impact on Kamini.

SCENARIO EXAMPLE 2
Renuka is employed as a domestic worker where she is expected to take care of all the household
activities, other than cooking. Most of the days, the lady of the
house leaves early. Renuka is therefore left alone in the house
with a male member of the household.
Renuka finds the male member constantly leering at her when
he is at home and often walks around the house wrapped in
nothing but a towel which makes her very uncomfortable. On
one occasion, while she was sweeping, he pinched her bottom.
When she protested that she will complain to the lady of the
house, he threatened to accuse her of stealing, and that he will
ensure that she loses her job.

What is Workplace Sexual Harassment?
In the above example, the male member by threatening Renuka to keep quiet about the unwelcome
physical contact if she wants to continue with her employment commits quid pro quo form of
sexual harassment. His behaviour occurring in a matrix of power, is unwelcome, sexual and has a
negative impact on Renuka.

SCENARIO EXAMPLE 3
Shamima is a lawyer who works as a researcher at an NGO in Delhi since 2013. Dr. Bhavan is the
director of the organisation and has always advocated for the cause of human rights.
During an official field visit to Shimla for 2 days, Dr. Bhavan finds an opportunity to be alone with
Shamima and makes a physical advance. Despite her protests, he forces himself on her while giving
lurid and sexually explicit details of his relationships, both past and present, with women. When
she chastises him and threatens to make his behaviour public, he threatens to destroy her career.

What is Workplace Sexual Harassment?
In the above example, by threatening Shamima with the destruction of her career, Dr. Bhavan
commits quid pro quo sexual harassment. His physical advances and sexual conversation are
unwelcome for Shamima and occur in a matrix of power.

B. Examples of scenarios that constitute a ‘hostile work environment’ type of sexual
harassment at the workplace:
SCENARIO EXAMPLE 1
Jayanthi works in a garment factory in Bangalore.

15

<!-- page 31 -->

Handbook on Sexual Harassment of Women at Workplace

Varghese, Jayanthi’s supervisor, often tries to touch her on one or
the other pretext. For example, he adjusts her dupatta while she
is sewing at her workstation on the pretext of covering her back.
Jayanthi is very uncomfortable with his behaviour. Her colleagues
at the workplace ridicule Jayanthi and mock her for the ‘special
treatment’ by her supervisor. They often gossip about her and
Varghese.

What is a Hostile Workplace Environment Sexual
Harassment?
In the above example, the physical touching by Varghese is
unwelcome and sexual in nature. The gossip, which is based on
Varghese’s behaviour towards Jayanthi at the workplace, is creating a hostile work environment
for Jayanthi.

SCENARIO EXAMPLE 2
Sukhi is a daily wage labourer working at a construction site. Every day at lunch time, Sukhi sits
under the shade of the tree to feed her 16-month old baby. She finds Jaswinder, a worker, staring
at her from the distance. Sukhi feels uncomfortable and asks Jaswinder to stay away from her
while she’s feeding the baby. However, Jaswinder persists and always finds a place near her. The
group of fellow construction workers now constantly catcall and whistle at Sukhi every time she
walks their way to refill the cement or mortar. When she questions them, they tell her they are
only joking amongst themselves.

What is a Hostile Workplace Environment Sexual Harassment?
Ogling, stalking and gossiping against Sukhi in the above example constitute a hostile work
environment, a form of workplace sexual harassment.

SCENARIO EXAMPLE 3
Sumedha is a Captain with the Indian Army. She has refused an offer made by a Senior Officer for a
relationship. Sumedha has kept quiet about this experience, but thanks to the rumour-mongering
by the Senior Officer, she has acquired a reputation of being a woman of ‘easy virtue’. Now she
is being subjected to repeated advances by three of her senior officer colleagues. When she turns
around and protests, she is singled out for additional physical training.

What is a Hostile Workplace Environment Sexual Harassment?
In the above example, Sumedha’s refusal to the sexual advances of her Senior Officer, leads to
her being subjected to rumours, gossip, character assassination, unwelcome sexual advances by
other officers, and arbitrary disciplinary action. This constitutes Hostile Work Environment form of
workplace Sexual Harassment.

16

<!-- page 32 -->

Handbook on Sexual Harassment of Women at Workplace

SCENARIO EXAMPLE 4
Asha is a researcher at a media agency led by Dr. Purshottam, a well-known journalist.
In the first few months of Asha’s employment, Dr. Purshottam is very pleased with her work and
publicly appreciates her. Soon after, Dr. Purshottam frequently summons Asha to his office on the
pretext of work and makes verbal sexual advances and sexually coloured remarks to her. He brushes
aside her protests by saying that they would not be able to work as a team unless she interacted
closely with him and they both got to know each other well. However, once she categorically
rebuffed his sexual advances, he has stopped. Now he ridicules her work and humiliates her in the
presence of colleagues and the staff. He discriminates against her by allotting projects to her and
then arbitrarily withdrawing the work.

What is a Hostile Workplace Environment Sexual Harassment?
In the above example, the workplace actions are a result of Asha rebuffing the unwelcome, sexual
advances of Dr. Purshottam and this constitutes hostile work environment form of workplace
sexual harassment.
This section has listed and illustrated some of the behaviours that constitute the five parameters
of workplace sexual harassment, viz., sexual, subjective, unwelcome, impact and power. This
becomes the basis of the key elements of the Act, Prevention, Prohibition and Redress.

17

<!-- page 33 -->

S ECTION

3
Prevention and Prohibition
“The meaning and content of fundamental rights guaranteed in the
Constitution of India are of sufficient amplitudes to encompass all facets of
gender equality…”
Late Justice J.S. Verma

T

his section describes those who are both responsible and accountable to prevent workplace
sexual harassment in compliance with the Act. It also highlights the role of workplaces in
prohibiting workplace sexual harassment through an effectively communicated policy.

3.1 PREVENTIVE AUTHORITIES
3.1.1 WHO IS AN EMPLOYER?
An employer refers to:
1.

The head of the department, organisation, undertaking, establishment, enterprise, institution,
office, branch or unit of the Appropriate Government or local authority or such officer specified
in this behalf.

2. Any person (whether contractual or not) responsible for the management, supervision and
control of a designated workplace not covered under clause (i).
3. A person or a household who employs or benefits from the employment of domestic worker
or women employees.

18

<!-- page 34 -->

Handbook on Sexual Harassment of Women at Workplace

3.1.2 WHO IS AN APPROPROATE GOVERNMENT?
As per the Act, Appropriate Government means:
i.

In relation to a workplace which is established, owned, controlled or wholly or substantially
financed by funds provided directly or indirectly—
a. By the Central Government or the Union Territory administration, the Central Government;
b. By the State Government, the State Government;

ii. In relation to any workplace not covered under sub-clause (i) and falling within its territory, the
State Government.

3.2 WHO IS A DISTRICT OFFICER (DO)?
State Governments will notify a District Magistrate/Additional District Magistrate/ Collector/
Deputy Collector as a District Officer at the local level. The District Officer will be responsible for
carrying out the powers and functions under the Act at the district levels (including every block,
taluka, tehsil, ward, and municipality).

3.3 RESPONSIBILITIES OF THE AFOREMENTIONED AUTHORITIES
Under the law the employer/DO is obliged to create a workplace free of sexual harassment. It is
the responsibility of the Employer/District Officer in general to:
1.

Create and communicate a detailed policy;

2. Ensure awareness and orientation on the issue;
3. Constitute Complaints Committee/s in every workplace and district so that every working
woman is provided with a mechanism for redress of her complaint(s);
4. Ensure Complaints Committees are trained in both skill and capacity;
5. Prepare an annual report and report to the respective state government;
6. District Officer will also appoint a nodal officer to receive complaints at the local level.

3.2.1 Complaints Committee/s
The Act provides for two kinds of complaints mechanisms: Internal Complaints Committee
(ICC) and Local Complaints Committee (LCC). All Complaints Committees must have 50 per cent
representation of women. ICC or LCC members will hold their position not exceeding three years
from the date of their nomination or appointment.

1) Internal Complaints Committee (ICC)
Every employer is obliged to constitute an ICC through a written order. The ICC will be composed
of the following members:

19

<!-- page 35 -->

Handbook on Sexual Harassment of Women at Workplace

No

Member

Eligibility

1.

Chairperson

Women working at senior level as employee; if not available then
nominated from other office/units/ department/ workplace of the
same employer

2.

2 Members
(minimum)

From amongst employees committed to the cause of women/
having legal knowledge/experience in social work

3.

Member

From amongst NGO/associations committed to the cause of women
or a person familiar with the issue of Sexual Harassment

Where the office or administrative units of a workplace are located in different places, division or
sub-division, an ICC has to be set up at every administrative unit and office.

ICC/LCC ARE MANDATORY
The employee who had a fundamental right to a workplace free of sexual harassment, had
complained about sexual harassment. According to the Court, had the organisation complied
with the Vishaka Guidelines and set up such a Complaints Committee, the preventative benefit
would have been three-fold:
1.

Ensured a place where women employees could seek redress;

2. Sent a clear message to the workplace that such complaints would be enquired into by a
specially designated committee with external expertise;
3. Prevented a series of litigation that followed.
Hence, the Madras High Court awarded Rs. 1.68 crores in damages to an employee for the nonconstitution of a Complaints Committee by the employer, as per the Vishaka Guidelines (at the
time of the complaint, the Sexual Harassment of Women at Workplace Act 2013 had not been
enacted).
Ms. G v. ISG Novasoft Technologies Ltd. Madras High Court (Crl.R.C.No.370 of 2014 order dated
02.09. 2014. Original Petition No.463 of 2012

2) Local Complaints Committee (LCC)
The District Officer will constitute an LCC in every district so as to enable women in the unorganised
sector or small establishments to work in an environment free of sexual harassment. The LCC will
receive complaints:
1.

From women working in an organisation having less than 10 workers;

2. When the complaint is against the employer himself;
3. From domestic workers.
20

<!-- page 36 -->

Handbook on Sexual Harassment of Women at Workplace

No

Member

Eligibility

1.

Chairperson

Nominated from amongst the eminent women in the field of
social work and committed to the cause of women

2.

Member

Nominated from amongst the women working in the block,
taluka or tehsil or ward or municipality in the district

3.

2 Members

Nominated from amongst such NGO/associations/persons
committed to the cause of women or familiar with the issues
relating to sexual harassment, provided that:
•
At least one must be a woman
•
At least one must have a background of law or legal
knowledge

4.

Ex Officio member

The concerned officer dealing with social welfare or women and
child development in the district

*One of the nominees shall be a woman belonging to the SC/ST/OBC/Minority community notified by the Central Government.

3) External Members on the Complaints Committee/s
The Act refers to external members, which generally means persons who have expertise with the
issue of sexual harassment. Given the largely intangible nature of workplace sexual harassment,
there are a range of complexities involved in responding effectively to workplace sexual harassment
complaints. For this reason, external third party/ members on the Complaints Committee/s (from
civil society or legal background) should possess the following attributes:
1.

Demonstrated knowledge, skill and capacity in dealing with workplace sexual harassment
issues/complaints;

2. Sound grasp and practice of the legal aspects/implications.
Such expertise will greatly benefit Complaints Committees in terms of fair and informed handling
of complaints to lead to sound outcomes. These external third party members shall be paid for
their services on the Complaints Committees as prescribed.

Criteria for the External Member
A ‘person familiar with issues relating to women’ would mean such persons who have expertise
in issues related to sexual harassment and may include any of the following:
• At least 5 years of experience as a social worker, working towards women’s empowerment
and in particular, addressing workplace sexual harassment;
• Familiarity with labour, service, civil or criminal law.

21

<!-- page 37 -->

Handbook on Sexual Harassment of Women at Workplace

3.2.2 Sexual Harassment at Workplace Policy
Employers/District Officers are responsible for complying with prohibition, prevention and
redress of workplace sexual harassment. In practice, this means having a policy that: (1) prohibits
unwelcome behaviour that constitutes workplace sexual harassment; (2) champions prevention
of workplace sexual harassment through orientation, awareness and sensitization sessions; and
(3) provides a detailed framework for redress.

3.2.3 Dissemination of Information and Awareness Generation
Employers/ District Officers have a legal responsibility to:
1.

Effectively communicate a policy that prohibits unwelcome behaviour that constitutes
workplace sexual harassment, and provides a detailed framework for prevention, and redress
processes.

2. Carry out awareness and orientation for all employees.
3. Create forums for dialogue i.e. Panchayati Raj Institutions, Gram Sabhas, Women’s Groups,
Urban Local Bodies or like bodies, as appropriate.
4. Ensure capacity and skill building of Complaints Committees.
5. Widely publicize names and contact details of Complaints Committee members.

22

<!-- page 38 -->

S ECTION

4
Redress
“...the time has come when women must be able to feel liberated and
emancipated from what could be fundamentally oppressive conditions
against which an autonomous choice of freedom can be exercised and made
available by women. This is sexual autonomy in the fullest degree”
Late Chief Justice J.S. Verma, Justice Verma Committee Report, 2013

his section is about Redress. It provides helpful information on who can complain, to whom,
and what a complaint should contain. It also gives information and lays out the steps involved
when a complaint has reached the Complaints Committee, in terms of the process, findings
and recommendations.

T

4.1 WHO CAN COMPLAIN AND WHERE?

23

<!-- page 39 -->

Handbook on Sexual Harassment of Women at Workplace

Generally, where there are less than ten workers, any woman employee can complain to the Local
Complaints Committee with the support of the Nodal Officer, when required. It is the responsibility
of the District Officer to designate a person as the Nodal Officer in every block, taluka and tehsil
in rural or tribal areas and wards or municipalities in the urban areas, to receive the complaints
of workplace sexual harassment from women. The Nodal Officer will forward all such complaints
within seven days of its receipt to the concerned Complaints Committee for appropriate action.
In most other workplaces, a woman employee can make a complaint to the Internal Complaints
Committee.

4.2 WHAT SHOULD THE COMPLAINT CONTAIN?
The written complaint should contain a description of each incident(s). It should include relevant
dates, timings and locations; name of the respondent(s); and the working relationship between the
parties. A person designated to manage the workplace sexual harassment complaint is required to
provide assistance in writing of the complaint if the complainant seeks it for any reason.

4.3 WHAT CAN AN EMPLOYEE/WORKER EXPECT?
When it comes to redress for workplace sexual harassment, employee/worker has a right to expect
-a trained, skilled and competent Complaints Committee, a time bound process, information
confidentiality, assurance of non-retaliation, counselling or other enabling support where needed
and assistance if the complainant opts for criminal proceedings.

4.3 A. RIGHTS OF THE COMPLAINANT
• An empathetic attitude from the Complaints Committee so that she can state her grievance in
a fearless environment
• A copy of the statement along with all the evidence and a list of witnesses submitted by the
respondent
24

<!-- page 40 -->

Handbook on Sexual Harassment of Women at Workplace

• Keeping her identity confidential throughout the process
• Support, in lodging FIR in case she chooses to lodge criminal proceedings
• In case of fear of intimidation from the respondent, her statement can be recorded in absence
of the respondent
• Right to appeal, in case, not satisfied with the recommendations/findings of the Complaints
Committee

4.3 B. RIGHTS OF THE RESPONDENT
• A patient hearing to present his case in a non-biased manner
• A copy of the statement along with all the evidence and a list of witnesses submitted by the
complainant
• Keeping his identity confidential throughout the process
• Right to appeal in case not satisfied with the recommendations/findings of the Complaints
Committee

4.4 KEY RESPONSIBILITIES
To effectively address workplace sexual harassment complaints, a Complaints Committees must
first be aware of their key responsibilities, some of which are highlighted below:
1.

Be thoroughly prepared

2. Know the Act, Policy and/or relevant Service Rules
3. Gather and record all relevant information
4. Determine the main issues in the complaint
5. Prepare relevant interview questions
6. Conduct necessary interviews
7. Ensure parties are made aware of the process and their rights/responsibilities within it
8. Analyse information gathered
9. Prepare the report with findings/recommendations

4.5 KNOWLEDGE, SKILLS, TRAINING
Dealing with workplace sexual harassment complaints is often complex. Hence Complaints
Committee/s must possess critical skills/capacity to effectively carry out their role. That includes
a sound grasp of the Act, Vishaka Guidelines, applicable Service Rules, relevant laws and an
understanding of workplace sexual harassment and related issues. Complaints Committee skills
must include an ability to synthesise information i.e. relevant documents, the law and interviews.
They should also be able to communicate effectively, write clearly, listen actively and conduct
interviews. They should be competent at showing empathy, being impartial and being thorough.
They should be able to identify sexual harassment and its impact.
25

<!-- page 41 -->

Handbook on Sexual Harassment of Women at Workplace

A Complaints Committee/s is required to be trained in both skill and capacity to carry out a fair and
informed inquiry into a complaint of workplace sexual harassment. An absence of such training
will lead to unequal and unfair results, which can cost employers, employees, complainants as well
as respondents.

FAIR AND INFORMED INQUIRY
Within 6 months of joining The Statesman newspaper, Rina Mukerhjee lost her job. While
the company alleged that her work was “tardy” and “lacking in quality” it suppressed Rina’s
complaint of sexual harassment against the news coordinator, Ishan Joshi. Within her first
month of work, Rina had taken her complaint directly to the Managing Director, Ravinder
Kumar. Time passed, nothing happened and Rina was fired. In a rare display of social context
insight and clarity, the Industrial Tribunal (West Bengal) rejected the Statesman’s claim that
Rina only referred to “professional” harassment in her complaint to Mr. Kumar. In the Tribunal’s
view, Mr. Kumar’s failure to dig deeper was clearly suspect- “... it becomes clear that there was
no Committee on Sexual Harassment, as per the Honb’le Supreme Court’s direction in Vishaka
vs State of Rajasthan, existing in The Statesman, at that relevant time. to expect-the lady
workman to file a written complaint and not to believe the same, when it has been filed ‘at a
later date’ is sheer bias.” The Statesman was ordered to reinstate Rina and grant her full back
wages.
M/s The Statesmen Ltd. and Smt. Rina Mukherjee. Order of K.K. Kumai, Judge, dated 06.02.2013,
Fourth Industrial Labour Tribunal (West Bengal)

4.6 DO’S AND DON’TS FOR COMPLAINTS COMMITEE
DO’S
1.

Create an enabling meeting environment.

2. Use body language that communicates
complete attention to the parties.
3. Treat the complainant with respect.
4. Discard pre-determined ideas.
5. Determine the harm.
DON’TS
1.

Get aggressive.

2. Insist on a graphic description of the sexual
harassment.
3. Interrupt.
4. Discuss the complaint in the presence of the
complainant or the respondent.
26

<!-- page 42 -->

Handbook on Sexual Harassment of Women at Workplace

4.7 NON-NEGOTIABLES DURING THE INQUIRY PROCESS
During a redress process the Complaints Committee/s are required to assure confidentiality, nonretaliation and recommend interim measures as needed to conduct a fair inquiry.

4.8 THE SEXUAL HARASSMENT COMPLAINT PROCESS
The Complaints Committee/s needs to have information on the six stages (including fifteen steps),
detailed below, for addressing a complaint of workplace sexual harassment.

STAGE ONE: RECEIPT OF THE COMPLAINT
A fair, prompt, and impartial inquiry process starts with a Complaints Committee capable of
creating an environment of trust and confidence throughout the inquiry.

Step 1 : Receive and Acknowledge Receipt of the Complaint
The complainant submits a sexual harassment complaint in writing within three months of the last
alleged incident to the Complaints Committee or any other person designated by the organization/
District Officer (i.e. Nodal Officer) to receive and manage complaints of sexual harassment.

Training and Skill Building : An Institutional Responsibility
It is important that both the Committee and any other person designated by the organization/
District Officer to receive or otherwise handle a sexual harassment complaint has there quired
competency and skill building training formanaging a complaint and/or any concern related to
workplace sexual harassment.
27

<!-- page 43 -->

Handbook on Sexual Harassment of Women at Workplace

Upon receipt, the complaint should be reviewed for:
1.

In the context of workplace that the sexual harassment complaint is to be met with under the
Act, such as, Service Rules, Workplace Policy, Vishaka Guidelines and related laws.

2. Clarity in the complaint.
3. Additional information needed from the complainant.
The complainant will be notified in writing to acknowledge receipt.

Step 2: Meet and Talk to the Complainant to Explore Options for Formal and Informal Resolution
The complainant needs to be informed about the ensuing process and the informal or formal
options available for the redress.
Step 3: Informal Mechanism
If the complainant chooses to adopt the informal process to resolve her complaint/experience
of workplace sexual harassment, then it is the responsibility of the person designated to receive
and manage the Complaints Committee to explore enabling ways to address the complaint. This
can include counselling, educating, orienting, or warning the respondent to promptly stop the
unwelcome behaviour or appointing a neutral person to act as a conciliator between the parties
to resolve the complaint through conciliation.
However, before recommending conciliation, the Committee must assess the severity of the
situation and if necessary, advise and enable the complainant to opt for the formal route. At no
point, the Complaints Committee will advise the complainant to resolve the matter directly with
the respondent. Where such an informal process is successful, such resolution is to be recorded
by the conciliator and forwarded to the ICC/LCC who in turn will forward the same to the
employer/District Officer for further action based on the resolution. Employers/District Officers
are responsible for taking steps to ensure that the complainant is not subject to any backlash.
The choice of a formal process rests with the complainant even if the person responsible for
managing the complaint believes that this can be resolved through an informal process.
Step 4: Formal Mechanism
1.

If the complainant opts for formal redress, or the nature of the complaint is serious which calls
for formal redress, then the Complaints Committee responds to the complaint.
28

<!-- page 44 -->

Handbook on Sexual Harassment of Women at Workplace

2. Complaints Committee/s members must be free of any conflict of interest with either the
concerned parties or with the outcome.
3. Ensure that the independent third party member has sound knowledge, skill, and experience
in dealing with workplace sexual harassment complaints.
Step 5: Respondent and Response
1.

As per the procedure provided in the Service Rule; or in absence of the same

2. Within seven days of receiving a complaint, the Complaints Committee will inform the
respondent in writing that a complaint has been received.
3. The respondent will have an opportunity to respond to the complaint in writing within ten days
thereafter.

STAGE TWO: PLANNING CAREFULLY
Step 6: Prepare the File
A sound inquiry relies on sound preparation. This includes taking into account the following steps:
1. Documentation
Create an independent confidential file of the complaint and all subsequent related documentation.
2. Review Law & Policy
Have a clear knowledge and understanding of the Act/Rules as well as the relevant Service Rules,
Workplace Policy, Vishaka Guidelines, existing practices and related laws.
3. Make a List
Make a list of all the dates and events relating to the written complaint as well as the names of
witnesses, where applicable.

Relevant Witnesses
The complaint may include the names of people believed to have witnessed the alleged incidents
or those who may have been aware of other information directly related to the complaint. The
respondent may also include the names of witnesses. In addition, the C omplaints Committee
also has the discretion to call any person as a witness, who it believes, has something to contribute
to the inquiry process.
4. Supporting Documents
Obtain and review all supporting documents relevant to the complaint, including those
presented by the complainant and the respondent.

29

<!-- page 45 -->

Handbook on Sexual Harassment of Women at Workplace

5. Act Quickly
Create a plan. This can be used as an initial checklist to ensure that all of the critical elements
are covered. It includes:
a.

The names of the parties and witnesses to be interviewed

b.

Any documentary support that needs to be examined

c.

Timeline

Preparing the Plan - Key Elements to Consider
1.

Defining the Issues
What is the complaint
Questions or points that require clarification

2.

Determining a violation of the Policy/Act
What information is needed to determine that there has been a violation

3.

Logistics
Venue for conducting the interviews. Are special logistics required
Creating timelines for each

4.

Critical Information
What documents need to be looked at
Witnesses to be questioned and in what order

5.

Areas of Questioning
Questions for each specific incident and party/witness
Questions for each particular issue
Issues likely to require follow-up

Step 7: Consideration
1. Interim Measures
While a complaint is pending inquiry, a complainant can make a written request for her transfer or
the transfer of the respondent, or for leave (upto 3 months). She can also request the Complaints
Committee to restrain the respondent from reporting on her work performance or writing her
confidential report or supervising her academic activities (in case she is in educational institution).
Even in the absence of such a request, the Complaints Committee must take corrective action. It is
essential to take these actions in order to prevent potential ongoing sexual harassment.

30

<!-- page 46 -->

Handbook on Sexual Harassment of Women at Workplace

2. Support
Maintain clear, timely communication with the parties throughout the process. Provide
complainants with any specific assistance they may require, such as counselling, addressing healthrelated concerns or sanctioning of leave.

STAGE THREE: INTERVIEWS
Step 8: Prepare an Interview Plan for the Hearing: Complainant, Witnesses, Respondent
1.

Based on the results of the previous steps and before conducting interviews, the Complaints
Committee should decide which issues need to be pursued for questioning.

2. Interviews are meant to obtain information that is relevant to the complaint from individuals.
3. Interviews should be conducted with each person separately and in confidence. The complainant
and the respondent should not be brought face to face with each other.

31

<!-- page 47 -->

Handbook on Sexual Harassment of Women at Workplace

Step 9: Assess the Completeness of the Information Collected
At this stage, the Complaints Committee should review the information gathered and their factual
relevance to each aspect of the complaint. This will help determine whether there is enough
information to make a finding on the complaint.

STAGE FOUR: REASONING
Step 10: Once the information and review is complete, the Complaints Committee will make its
reasoned finding(s), which involves having to:• Identify the substance of each aspect of the complaint.
• Determine, whether or not, on a balance of probability, the unwelcome sexual harassment
took place.
• Check that such behaviour/conduct falls within the definition of sexual harassment set out in
the relevant Act/Rules, Policy, Service Rules or law.
• Comment on any underlying factor(s) that may have contributed to the incident.
Step 11: Create a timeline to help establish the sequence of events related to the complaint.
Step 12: Compare similarities and differences within each of the statements made by the
interviewees.

STAGE FIVE: FINDING AND RECOMMENDATION
Step 13: Finding
Based on the above, the Complaints Committee must arrive at a finding of whether the complaint
is upheld, not upheld or inconclusive.
Provided, where both the parties are employees, before finalising the findings, the ICC/LCC shall
share its finding with both the parties and provide them an opportunity to make representation
against it before the Committee.
Step 14: Recommendations
Based on its findings, the Complaints Committee shall then make appropriate recommendations
which may include:
1.

Where the Complaints Committee is unable to uphold the complaint, it shall recommend no
action.

2. Where the Complaints Committee upholds the Complaint, it may recommend such action
as stated within the relevant Policy or Service Rules, which may include a warning to
terminate.

32

<!-- page 48 -->

Handbook on Sexual Harassment of Women at Workplace

In case service rules do not exist, recommended action may include:
• Disciplinary action, including a written apology, reprimand, warning, censure;
• Withholding promotion/ pay raise/ increment;
• Termination;
• Counselling;
• Community service.
3. The Complaints Committee may also recommend financial damages to the complainant, while
deciding the amount they shall take into consideration:
• Mental trauma, pain, suffering and emotional distress caused;
• Medical expenses incurred;
• Loss of career opportunity;
• Income and financial status of the respondent.
If the amount is not paid it can be recovered as an arrear of land revenue.
4. The Complaints Committee can also give additional recommendations to address the underlying
factors contributing to sexual harassment at the workplace.

STAGE SIX: REPORT
Step 15: Writing the Report
The Complaints Committee will prepare a final report that contains the following elements:
• A description of the different aspects of the complaint;
• A description of the process followed;
• A description of the background information and documents that support or refute each
aspect of the complaint;
• An analysis of the information obtained;
• Findings as stated above;
• Recommendations.
An inquiry must be completed within 90 days and a final report submitted to the Employer or
District Officer (as the case may be) within ten days thereafter. Such report will also be made
available to the concerned parties. The Employer or District Officer is obliged to act on the
recommendations within 60 days. Any person not satisfied with the findings or recommendations
of the Complaints Committee or non-implementation of the recommendations, may appeal in an
appropriate court or tribunal, as prescribed under the Service Rules or where no such service rules
exist, in such manner as may be prescribed.

33

<!-- page 49 -->

Handbook on Sexual Harassment of Women at Workplace

Given that most workspaces today are gender unequal and male-dominated, it is important that
complaints by women be treated fairly and not dismissed. The mere inability to substantiate a
complaint or provide adequate proof will not attract legal action against the complainant.
However, making a false or malicious complaint or producing a forged or misleading document is an
offence.

4.9 AT A GLANCE

1) Complaints Committee’s Checklist
•

Review the written complaints and response to complaints

•

Review the applicable policy, the Act/Rules, Vishaka Guidelines and other relevant laws

•

Develop a plan

•

Meet with the complainant

•

Meet with the respondent

•

Meet with the witnesses

•

Record statements and have them dated and signed

•

Review and adapt the plan, as needed

•

Proceed with further interviews, as needed

•

Analyze all the facts to develop reasoning

•

Arrive at the findings

•

Give recommendations

•

Prepare the report

•

Submit the file to the organization or District Officer for implementation of the
recommendations and for safe keeping.

34

<!-- page 50 -->

Handbook on Sexual Harassment of Women at Workplace

INQUIRY PROCESS AT A GLANCE

35

<!-- page 51 -->

Handbook on Sexual Harassment of Women at Workplace

2) Timelines as per the Act
Submission of Complaint

Within 3 months of the last incident

Notice to the Respondent

Within 7 days of receiving copy of the complaint

Completion of Inquiry

Within 90 days

Submission of Report by ICC/LCC to
employer/DO

Within 10 days of completion of
the inquiry

Implementation of Recommendations

Within 60 days

Appeal

Within 90 days of the recommendations

3) Confidentiality
The Act prohibits the publication or making known the contents of a complaint and the inquiry
proceedings. Any breach of confidentiality will result in specific consequences.
The Act prohibits the disclosure of:
• Contents of the complaint;
• Identity and address of complainant, respondent and witnesses; Information pertaining to
conciliatory/inquiry proceedings or recommendations of the ICC/LCC;
• Action taken by the employer/DO.
Accountability: Any person entrusted with the duty to handle or deal with the complaint, inquiry
or any recommendations or action taken under the provisions of this Act.
Consequences: As per the Service Rules or Rs.5,000/ to be collected by the employer.
Exception: Dissemination of information regarding the justice secured without disclosure of name,
address, identity and particulars of complainant or witnesses.
Section 4 completes the details of the Complaints Committee process in addressing formal
complaints. It serves as a guideline to action in providing appropriate redress. The manner in which
a complaint is addressed will make all the difference to the equal rights of working women as well
as the kind of workplace culture being promoted.

36

<!-- page 52 -->

S ECTION

5
Monitoring
“Vishaka was a victory for all women”
Bhanwari Devi

his section refers to ways in which application of the Act at all workplaces is monitored.
Monitoring is a way to ensure compliance of the Act on the ground. As an additional means
of monitoring, the Act mandates the submission of Annual Reports with specific information
as well as specific consequences where compliance is lacking.

T

The Act authorizes Appropriate Government to monitor the implementation of the Act. As per the
Act, Appropriate Government means:
i.

In relation to a workplace which is established, owned, controlled or wholly or substantially
financed by funds provided directly or indirectlya. By the Central Government or the Union Territory administration, the Central Government;
b. By the State Government, the State Government;

ii. In relation to any workplace not covered under sub-clause (i) and falling within its territory, the
State Government;
Thus to monitor the Act, the Appropriate Government has the authority to undertake any of the
following measures:

5.1 Inspection
In relation to workplace sexual harassment, when it is in the public interest or in the interest of
women employees, every employer/District Officer can be ordered by the Appropriate Government
i.e. State and Central Government, to make available any information, record or document,
including opening its workplace for inspection relating to the same.

5.2 Annual Report
The Appropriate Government is entrusted with the monitoring of the implementation of this Act
and for maintaining the data on the number of cases filed and disposed of under it. In particular,
the Act mandates submission of an Annual Report by the ICC/LCC to the employer/District Officer.

37

<!-- page 53 -->

Handbook on Sexual Harassment of Women at Workplace

The District Officer will forward a brief report on the annual reports to the appropriate State
Government. Such reports must include the following information:
a. No. of complaints received;
b. No. of complaints disposed of;
c. No. of cases pending for more than 90 days;
d. No. of workshops/awareness programmes carried out;
e. Nature of action taken by the employer/DO;
The Report of ICC will be forwarded to the DO through the employer.

5.3 Penalties
An employer can be subjected to a penalty of up to INR 50,000 for:
• Failure to constitute Internal Complaints Committee
• Failure to act upon recommendations of the Complaints Committee; or
• Failure to file an annual report to the District Officer where required; or
• Contravening or attempting to contravene or abetting contravention of the Act or Rules.
Where an employer repeats a breach under the Act, they shall be subject to:
• Twice the punishment or higher punishment if prescribed under any other law for the same
offence.
• Cancellation/Withdrawal/Non-renewal of registration/license required for carrying on business
or activities.
Monitoring is a critical yardstick to measure success in terms of compliance with the Act.
Additionally, it highlights those areas, in terms of law and practice, which may require improvement
and/or additional information and guidance at both the State as well as the workplace levels.

38

<!-- page 54 -->

S ECTION

6
Global Norms and Good Practices

ncreasing awareness and compliance with international standards is a reminder that we must not
lose sight of the goal. Over the years, the international community has developed benchmarks
that provide guidance on what the laws around workplace sexual harassment should look like in
practice. The key benchmarks are listed below:

I
1.

Recognition that workplace sexual harassment is a form of human rights violation. i

2. Recognition that sexual harassment is a form of gender-specific violence.ii
3. Equality, dignity and worth of a human person must be emphasized.
4. Gender-based violence includes sexual harassment and impairs the enjoyment by women of
several basic human rights and fundamental freedoms. iii Some of these rights include:
•

The right to life, the right to liberty and security of the person.

•

The right to equal protection under the law.

•

The right to the highest standard attainable of physical and mental health.

•

The right to just and favourable conditions of work.iv

5. Eliminating violence against women and advancing women’s equality includes the right to be
free from workplace sexual harassment.v
6. Legislation on violence against women should define violence to include sexual harassment.
Such legislation should also recognize sexual harassment as a form of discrimination and a
violation of women's rights with health and safety consequences. vi
7. The International Labour Organization (ILO) has also drawn specific attention to domestic
workers, who have a right to “enjoy effective protection against all forms of abuse, harassment
and violence.” vii
In terms of practice, international law and policy frameworks have an important role to play in
encouraging the adoption of an understanding of sexual harassment as a fundamental human
right and equality issue, and not just a problem for labour/employment law to solve.
Converting these concepts into practice involves constant monitoring and adapting to changing
circumstances. As a start, six simple steps to keep in mind and practice in any workplace should
involve the following:

39

<!-- page 55 -->

Handbook on Sexual Harassment of Women at Workplace

1.

Make sure there is a policy that has been “effectively” communicated to all workers, irrespective
of whether they are paid or volunteers.

2. Display details of both informal and formal ways available to a worker to address/complain
about workplace sexual harassment.
3. Undertake orientation on workplace sexual harassment for all workers in respective
organizations, establishments or institutions.
4. A Complaints Committee which is trained in terms of skill and capacity is critical for building
trust.
5. Encourage senior persons/leaders/supervisors or any person who can influence employmentrelated decisions, to become role models.
6. Men and women should be included in building a culture which no longer tolerates workplace
sexual harassment.
Legally, workplace sexual harassment can no longer be dismissed as some moral transgression.
The Vishaka Guidelines raised that bar, when for the first time it recognized “each incident of
sexual harassment” as a violation of the fundamental right to equality. That notion has found its
way into the Act, which promotes the right of women as citizens to a workplace free of sexual
harassment. Complaints Committees at all workplaces are now charged with the role to ensure
that the right remains intact, through a fair, informed, user-friendly process of redress.
Prioritising prevention and establishing a redress mechanism, which comprises of 50 per cent
women, a woman chair and an external third party expert, is India’s innovative model in responding
to working women’s experience of sexual harassment. Assuming adequate changes follow,
in both law and practice to meet global benchmarks, that model can evolve into an exemplary
best practice. To get there, workplaces in India today, must rise to the requirement of promoting
gender equality.

i

General Recommendation 12 of 1989, Committee on the Elimination of All Forms of Discrimination against Women.
General Recommendation 19 of 1992, Convention on the Elimination of All Forms of Discrimination against Women (CEDAW).
iii
Ibid.
iv
Article 3, Declaration on the Elimination of Violence against Women, 1993.
v
The Beijing Platform of Action drawn at the United Nations’ Women’s Conference in Beijing in 1995.
vi
United Nations UN Division for the Advancement of Women Handbook for Legislation on Violence Against Women (UN Handbook).
http://www.un.org/womenwatch/daw/vaw/handbook/Handbook%20for%20legislation%20on%20violence%20against%20women.pdf
ii

vii

Article 5, ILO Decent Work for Domestic Workers Convention, 2011 (No. 189).

40

<!-- page 56 -->

<!-- page 57 -->

<!-- page 58 -->

Towards a new dawn

Government of India
Ministry of Women and Child Development
