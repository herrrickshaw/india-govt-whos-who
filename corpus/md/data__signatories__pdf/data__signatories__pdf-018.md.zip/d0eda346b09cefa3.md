---
doc_id: "d0eda346b09cefa3"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/30581706161081.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "Seeking Comments/views/suggestions from stakeholders on draft proposal for amendment in the Recruitment Rules (RRs) for the post of Deputy Director (Media) in Department of Social Justice & Empowerment- reg."
date: ""
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "231ae0be7f119a03"
---

<!-- page 1 -->

No. A-12018/1/2020-Fstt-I
Government of India
Ministry of Social Justice & Empowerment
(Department of Social Justice & Empowerment)
a a a ok

Room No. 243, A-Wing,

Shastri Bhawan, New Delhi-01

Dated the 24" January, 2024

OFFICE MEMORANDUM

Subject: Secking Comments/views/suggestions from stakeholders on draft i

proposal for amendment in the Recruitment Rules (RRs) for the post of

Deputy Director (Media) in Department of Social Justice & Empowerment-

reg.

The undersigned is directed to say that as per DoP&T’s O.M. No.AB-
14017/61/2008-Estt (RR) — dated 13.10.2015 - the — proposal for
framing/amendment of Recruitment Rules (RRs) are to be uploaded on the
website of respective Ministries/Departments for 30 days for inviting comments
from stakeholders.

Ze Therefore, the draft Recruitment Rules (RRs) to the post of Deputy
Director (Media) are uploaded on the website of Department of Social Justice &
Empowerment for information of stakeholders. All stakeholders are requested to
go through the drafi Recruitment Rules and furnish their comments, if any, to
the undersigned within a period of one month i.e from the date of its uploading
on the website. In case, no comments received till the last date, the Department
will proceed for taking necessary action for amendment of aforementioned draft
Recruitment Rules (RRs).
Encl: As above.
iar’ )

Under Secretary to the Govt. of India

To,
All concerned stakeholders

<!-- page 2 -->

Dale
[TO BE PUBLISHED IN PART II, SECTION 3, SUB SECTION (i) OF THE GAZETTE OF INDIA]
Government of India
Ministry of Social Justice & Empowerment :
(Department of Social Justice & Empowerment)
NOTIFICATION
New Delhi, the a 2024

G.S.R. 69. — In exercise of the powers conferred by the proviso to article 309 of the
Constitution and in supersession of the Department of Social Justice & Empowerment, Deputy
Director (Media) Recruitment Rules, 2017 except as respects things done and omitted to have
been done before such supersession, the President hereby makes the following rules regulating
the method of recruitment to the post of Deputy Director (Media) in the Department of Social
Justice & Empowerment, Ministry of Social Justice & Empowerment, namely:-
ly Short title and commencement. ~ (1) These rules may be called the Ministry of Social
Justice & Empowerment, Department of Social Justice & Empowerment Deputy Director
(Media), Group ‘A’ post Recruitment Rules, 2024.

(2) They shall come into force on the date of their publication in the Official Gazette.
2. Number of post, classification and Level in the pay matrix The number of post, its
classification and the level in the pay matrix attached thereto, shall be as specified in columns
(2) to (4) of the Schedule annexed to these rules.
3, Method of recruitment, age limit, qualifications, ete. The method of recruitment, age
limit, qualifications and other matters relating thereto shall be as specified in columns (5) to
(13) of the aforesaid Schedule.
4, Disqualification. — No person,

(a) who has entered into or contracted a marriage with a person having a spouse

living. or

(b) who, having a spouse living, has entered into or contracted a marriage with any

person, shall be eligible for appointment to the said post:

Provided that the Central Government may, if satisfied that such marriage is
permissible under the personal law applicable to such person and the other party to the
marriage and that there are other grounds for so doing. exempt any person from the
operation of this rule.

<!-- page 3 -->

os
5. Powers to relax - Where the Central Government is of the opinion that it is necessary or
expedient so to do, it may, by order and for reasons to be recorded in writing, relax any of the
provisions of these rules with respect to any class or category of persons.
7. Saving - Nothing in these rules shall affect reservations, relaxation of age limit and other
concessions required to be provided for the Scheduled Castes, the Scheduled Tribes, Other
Backward Classes, Ex-servicemen and other categories of persons in accordance with the orders
issued by the Central Government from time to time in this regard.
SCHEDULE
Name of the No. =| Post. Classification. Pay Matrix as per 7
post CPC (Pay Band 4
Grade Pay as per 6"
an aa 58 RGR O) 8.2 |
a es 3) Eo ey |
Deputy 01* (one) General Central Service, | Level-I1 |
Director (2024) Group ‘A’ Gazetted, Non- | (Rs. 67700-208700) |
(Media) Ministerial.
*Subject. to variation
: ___| dependent on workload. f wo, Se है
| Whether | Age- limit for | Educational and other qualifications required for direct |
| selection post | direct recruits | recruits
| or non-
| selection post_ da de eee wl te am
| 0 ecole ce छः = ale |
Not applicable | Not applicable | Notapplicable eile
Whether age and educational | Period of Method of recruitment whether by direct
qualifications prescribed for | probation, if recruitment or by promotion or by deputation/
direct recruits will apply in any absorption and the percentage of vacancies to
the case of promotees. be filled by various methods
8) OO) (10) a
Not applicable Not applicable | By deputation (including short-term contract)
In case of recruitment by promotion/ deputation/ | If a Departmental | Circumstances — in
absorption, grades from which — promotion/ | Promotion which Union
deputation/ absorption to be made Committee exists. | Public Service
| what is its Commission is to |
| composition be consulted in |
making |
recruitment. |
TD Fai, Wee P| 2 G2) (13)

<!-- page 4 -->

“By deputation (including short-term contract):- | Not applicable. | with
Union Public
I. Officers under the Central or State Governments Service
or Union Territories or Universities or Recognised Commission not
Research Institutions or Semi-Government or necessary
Public Sector Undertakings or Statutory or
Autonomous Organisations:- |
(i) holding analogous posts on a regular basis in the
Pay Level- 11 (Rs 67700-208700) in Pay Matrix as
per 7th CPC, in CDA pattern or equivalent in IDA
pattern in the parent cadre/department, |
OR |
(ii) with two years service in the grade rendered
after appointment thereto on a regular basis in posts
in the Pay Level-10 (Rs. 56100-177500) in Pay
Matrix as per 7th CPC, in CDA pattern or
| equivalent in IDA pattern in the parent cadre/
department; है
OR
(iii) with three years service in the grade rendered |
after appointment thereto on a regular basis in posts |
in the Pay Level-8 (Rs. 47600-151100) in Pay
Matrix as per 7th CPC. in CDA pattern or
equivalent in IDA pattern in the parent cadre/
department;
AND
I]. Possessing the following educational
qualifications:
Essential:
Bachelors Degree in any discipline from a
recognized University.
Desirable: Post Graduate Degree or Diploma in |
Journalism or Mass Communication or Information
Technology. |
OR
Officers holding analogous post or in Level 10 (Rs. |
| 56100-177500) in the pay matrix on a regular basis |
| from the Indian Information Service. |
Note |: Period of deputation (including short-term |
contract) including period of deputation (including |
short-term contract) in another ex-cadre post held |
immediately preceding this appointment in the |
same or some other organisation or department of
the Central Government shall ordinarily not | ise,

<!-- page 5 -->

exceed five years. Baers poe bey 110 7 ५७ हो
Note 2: The maximum age limit for appointment by
deputation (including short-term contract) shall be zi
not exceeding fifty six years as on the closing date
of receipt of applications.
[F. No. A-12018/1/2020-Estt-I]
(Asokan P K)
Under Secretary to the Government of India
