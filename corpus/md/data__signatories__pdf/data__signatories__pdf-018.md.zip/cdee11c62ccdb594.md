---
doc_id: "cdee11c62ccdb594"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/e489be3d3b35419656a62871ad54b770.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment of Shri Aditya Upadhyay, Advocate as Gr. 'C' Panel Counsel for SCI: Order dated 21.01.2021"
date: "2021-01-21"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "04d0b08c1fd223dc"
---

<!-- page 1 -->

F No J-1 1 01 61112020-Judicial
Government of lndia
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)

Shastri Bhawan, New Delhi,
Dated 21't January , 2021

ORDER
The President is pleased to engage Shri Aditya Upadhyay, Advocate as Group'C'
Panel Counsel for conducting Central Government litigation before the Supreme Court of
lndia, as mentioned below, for a period of three years with effect from the date of this order
or untilfurther orders, whichever is earlier:
SUPREME COURT OF INDIA

qR9UP iC', FANEI.' COU,NSEL
NAME (Shri)

Enrl. No.

Contact details

R-41, Gwyer Hall, University of Delhi,
Aditya Upadhyay

Dt4647 12017

Delhi-1 10007

Mob: 9167 147660
Email: adityaupadhyayl 0@gmail com

2.

The terms & conditions of the engagement of aforesaid Advocate will be governed by

this Department's OM No.21(a)/99-Judl. dated 24.09.1999 read with OM No.

26(1)12014/Judl. dated 01.10.2015 & instructions issued subsequently through OMs. The
aforesaid OMs are available on the website of this Department i.e. www.legalaffairs.gov.in in
the tab'Judicial Section' under heading 'Circulars pertaining to litigations'.

3.

Hindi version of this order will follow

(S R Mishra)
Additional Secretary
Copy to:-

1. OSD to ML&J/PS to Law Secretary/PS to Legislative Secretary/All Additional Secretaries/PS to
allJS&LA in the Main Sectt.

2. PS to Attorney General for lndia, PS to Solicitor General of lndia, PS to All Addl. Solicitors
General.

3. The Registrar, Supreme Court of lndia, New Delhi.
4. The lncharge, CentralAgency Section, Supreme Court Compound, New Delhi.
5. The Group'C' panel counsel, as above.
6. The Pay & Accounts Office, Department of LegalAffairs, New Delhi.
7. One copy of this order is uploaded on website of this Department i.e. www.legalaffairs.gov.in

under tab 'Judicial Section' in the link 'List of empanelled Counsel' for the information of all

8.
9.

concerned.
Hindi unit, Department of Legal Affairs for Hindi translation of the order
Guard File/Judicial Section with 5 spare copies.

W
l*
r

Section Officer (Judicial)
Tel 01 1-23384945
Email : judicial-dla@nic. in
