---
doc_id: "ceaea6baa616d859"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/99ead1bfd63ec73cdc634bf27807e486.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of Unified License (UL), bearing no. DS-11/133/2021-DS-III dated 11.08.2021, for Category ‘C’ ISP Authorization for Bangalore SSA in Karnataka Service Area, granted to M/s Kintsol India Pvt. Ltd."
date: "2026-05-31"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "23458f75b4a72dfb"
---

<!-- page 1 -->

DS-11/133/2021-DS-III

I/3403102/2026

WITHOUT PREJUDICE

F. No. DS-11/133/2021-DS-III
Government of India
Ministry of Communications
Department of Telecommunications
(Data Services Cell)
Sanchar Bhawan, 20, Ashoka Road
New Delhi-110001
Dated: 31-05-2026
To,
M/s Kintsol India Pvt. Ltd.
Address: Matrusri Arcade, 2nd Floor, Sy.No.72/1B, Jaraganahalli,
JP Nagar 6th Phase, Bangalore-560078
Email Id: info@kintsol.com

Subject:Termination/Revocation/Cancellation of Uniﬁed License (UL),
bearing no. DS-11/133/2021-DS-III dated 11.08.2021, for Category ‘C’ ISP
Authorization for Bangalore SSA in Karnataka Service Area, granted to M/s
Kintsol India Pvt. Ltd. in terms of clause 10.2 (i) under Chapter-I of Part-I of
the said License Agreement.

Whereas, Department of Telecommunications, Government of India (“the
Licensor”) has granted a Uniﬁed License (UL), bearing no. DS-11/133/2021-DS-III
dated 11.08.2021 (“the License”), to M/s Kintsol India Pvt. Ltd. ("the Licensee").
2.
WHEREAS, the LICENSEE is required to provide the services under the
terms and conditions of the License and instructions issued by the LICENSOR from
time to time.
3.
That for alleged violation of Conditions No. 18.2.1, 20.4, 20.6, 20.9, 21.1,
21.2, 21.3 & 21.4 of the License, a Show Cause Notice, bearing no. DS11/287/2023-DS-II, dated 20.03.2026 (“SCN”), was issued to the Licensee on the
address provided in the License. The aforesaid SCN was sent by way of speed
post bearing ID No. ED897745911IN as well as by an email on the registered email
ID(s) of the Licensee on 01.04.2026. The Licensee was also reminded regarding
the aforesaid SCN vide the email dated 08.05.2026.

<!-- page 2 -->

DS-11/133/2021-DS-III

4.
That the aforesaid SCN was issued to the Licensee to submit its reply, within
21 days, as to why the License granted to it should not be terminated, in terms of
the clause 10.2(i) under Chapter-I of the Part-I of the License.
5.
That despite having given enough time and opportunity to the Licensee to
show cause an explain the alleged violation of terms and conditions of the License
mentioned in the SCN, the Licensee has failed to submit any reply whatsoever to
the Licensor within the time frame allowed to the Licensee.
6.
That the failure of the Licensee to submit any reply or explanation to alleged
violation of terms and conditions of the License mentioned in the SCN implies that
the Licensee has nothing to say in this regard and that the Licensee has failed to
comply with the conditions of the License and therefore, has violated the conditions
of the License as alleged in the SCN.
7.
Therefore, the competent Authority has now decided to terminate/ revoke/
cancel the Uniﬁed License (UL), bearing no. DS-11/133/2021-DS-III dated
11.08.2021, for Category ‘C’ ISP Authorization for Bangalore SSA in
Karnataka Service Area, granted to M/s Kintsol India Pvt. Ltd. in terms of
clause 10.2 (i) under Chapter-I of Part-I of the License and that the said License is
terminated/ revoked/ cancelled w.e.f. 61 st calendar day from the date of issue of
this letter.
8.
That the Licensee is further directed to terminate and stop all
interconnections with all service providers eﬀective from the date of termination of
the License.
9.
That the Licensee is further directed to issue a notice of at least 30 calendar
days to all its customers within 30 days from today in terms of the condition 10.2(i)
under Chapter-I of Part-I of the License Agreement reproduced as under:
“The Licensee shall be required to give a notice of at least 30 Calendar days to its
customers within this period of revocation order”.
10.
That the Licensee shall take note of the clause 11.2 under Chapter-I of
Part-I of the License, which is reproduced as under:
“On revocation or surrender or cancellation of License/Service Authorization(s)
due to reasons whatsoever or expiry of the License, the relevant Bank
Guarantee(s) shall be released to the Licensee only after ensuring clearance of all
dues, which the Licensee is liable to pay to Licensor. In case of failure of the
Licensee to pay the amounts due to the Licensor, the outstanding amounts shall be
realized through encashment of the Bank Guarantees without prejudice to any
other action(s) for recovery of the amounts due to the Licensor without any further
communication to the Licensee”.
11.
That the Licensee shall also take note that in case, it comes to the notice of
the Licensor about any other violation of license conditions by the Licensee,
necessary action in respect of said violation may be initiated by the Licensor in due
course of time.

I/3403102/2026

<!-- page 3 -->

DS-11/133/2021-DS-III

I/3403102/2026

12.
That the Bank Guarantee(s) submitted by the Licensee against the said
license will be released in terms of clause 11.2 under Chapter-I of Part-I of the
License after ensuring clearance of dues, including dues/ penalty arising, if any, as
a consequence of the aforesaid violation.
13.

That the Licensee may acknowledge the receipt.

Director (DS-II)
dirds2-dot@nic.in
jto1ds2-dot@gov.in
Copy to: 1. DG Telecom, DoT, New Delhi, with a request to instruct the concerned
LSA(s) to intimate all Licensees/Infrastructure Providers in their area to
discontinue to provide/obtain any “telecom resources” to/from M/s Kintsol
India Pvt. Ltd.
2. Special DGT, Karnataka LSA, DoT.
3. Sr. Joint CGCA(Revenue), Oﬃce of CGCA with a request to release the
Bank Guarantees of the aforesaid company after ensuring dues from
respective sections of DoT as per letter No. vide 1-90/2012/LF-1(Pt.1) dated
05.09.2018 and letter No. 1-8/2017/LFP-1 dated 17.04.2017. As far as
due(s) of Data Service Cell is concerned, the same will be intimated to O/o
CGCA in due course of time.
4. Secretary, TRAI.
5. Wireless Advisor, for issue of Dues/No Dues Certiﬁcate till the eﬀective date
of termination of License and convey to office of CGCA.
6. Dy. CCA, O/o CCA, Karnataka Circle, DoT.
7. DDG(AS)/DDG(CS)/DDG(SAT)/DDG(SA)/DDG(SPPI)/DDG(LFP)/
DDG(WPF), DoT HQ.
8. Director (IT), DOT HQ for uploading this order on DoT website for information
to all Service Providers.
9. File No.: DS-11/133/2021-DS-III
