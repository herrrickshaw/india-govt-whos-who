---
doc_id: "ce230c2eacf3fb4a"
source_url: "https://mohua.gov.in/static/uploads/2025/12/fcfa3cc0eb1572742f6a5377f73469e0.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Guidelines for preparation of DPRs"
date: "2016-12-07"
pages: 43
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b215bbc4a560ddee"
---

<!-- page 1 -->

Rajiv Awas Yojana (RAY)

Guidelines for
Preparation of Detailed Project Reports
2013 - 2022

Ministry of Housing & Urban Poverty Alleviation
Government of India

<!-- page 2 -->

Guidelines for Preparation of Detailed Project Reports

Table of Contents
Preface………………………………………………………………………………………………………………..i
Abbreviations ............................................................................................................................ ii
Introduction to Guidelines for Preparation of DPR. ....................................................................1
1.

TYPE OF PROJECTS WHICH CAN BE TAKEN UP IN DPR..............................................2

2.

STEPS IN DPR PREPARATION..............................................................................................5
Step (i): Selection of project for the slum: .................................................................................5
Step (ii): Land possession and Land use: ...................................................................................5
Step (iii) : Survey and Mapping of selected Slum : ...................................................................5
Step (iv) : Assessment of Deficiencies in selected slum(s) : ....................................................7
Step (v) : Integration of Social Infrastructure ...........................................................................8
Step (vi) : Establishing Linkages with City-wide infrastructure Network.............................8
Step (vii) : Preparation of Detailed Designs after assessment of Demand / Gap ................9
Step (viii) : Statutory approvals.................................................................................................11
Step (ix) : Estimation of Project Cost......................................................................................11
Step (x) : Implementation and Management arrangements ...............................................12
Step (xi): Operation and Maintenance plan of proposed assets ..........................................13

3.

SUGGESTED CONTENTS OF DETAILED PROJECT REPORT ......................................14

Annexure - A - Check list of Documents / information required in the DPR of RAY ..........20
Annexure - B - Administrative & Technical Checklist ...............................................................21
Annexure - C -Executive Summary ..............................................................................................24
Annexure - D - Undertaking .........................................................................................................26
Annexure – E - Admissible Components .....................................................................................28
Annexure- F - Mitigation measures against Hazards/Disasters ..............................................29
Annexure – G – Modified NBO Formats .....................................................................................31

<!-- page 3 -->

Guidelines for Preparation of Detailed Project Reports
Preface
Rajiv Awas Yojana (RAY) envisages a “Slum Free India" with inclusive and equitable
cities in which every citizen has access to basic civic and social services and decent shelter.
In pursuance of this vision of “Slum free India”, Rajiv Awas Yojana (RAY) was
launched in June 2011 in two phases; the preparatory phase for a period of two years which
ended in June 2013 and implementation phase. Central Government has approved the
implementation phase for the period of 2013-2022.
RAY envisages a two-step implementation strategy i.e. preparation of Slum free City
Plan of Action (SFCPoA) and preparation of projects for selected slums.
RAY Scheme Guidelines issued by the Ministry broadly describe the Scope,
Coverage, Reforms, Implementation Approach, Central Assistance, Administrative and
Implementation structure and Monitoring mechanisms under RAY.
However, to assist States/ULBs to implement RAY, the following operational
guidelines have been prepared by the Ministry:
1. Guidelines for Reforms
2. Guidelines for GIS, MIS and GIS-MIS integration
3. Guidelines for preparation of Slum-free City Plan of Action
4. Guidelines for Community Participation
5. Guidelines for preparation of Detailed Project Reports
6. Guidelines for Project Management
7. Guidelines for Social Audit
8. Guidelines for Capacity Building
9. Quality Assurance Manual
The above mentioned guidelines are uploaded on the Ministry‟s website at
www.mhupa.gov.in.
Operational guidelines provide a general reference framework for implementation under
RAY. Feedback and suggestions are welcome and may be posted at Ministry through RAY
Vaarta (www.mhupa-ray.gov.in), an interactive website which serves as a common
platform for discussions and dissemination of information.

i

<!-- page 4 -->

Guidelines for Preparation of Detailed Project Reports

Abbreviations
BIS
BMTPC

Bureau of Indian Standards
Building Materials and Technology Promotion Council

BOQ

Bill of Quantities

BSUP

Basic Services to Urban Poor

CBO

Community Based Organization

CLTC

City Level Technical Cell

CPHEEO
CSMC

Central Public Health and Environmental Engineering
Organization
Central Sanctioning & Monitoring Committee

CSC

Construction Supervision Consultants

DPR

Detailed Project Report

DMP

Disaster Management Plan

DSC

Design and Supervision Consultants

DU

Dwelling Unit

EIA

Environmental Impact Assessment

ESR

Elevated Storage Reservoir

EWS

Economically Weaker Section

GIS Abbreviations

Geographical Information System

GTS

Great Trigonometric Survey

GoI

Government of India

GPS

Global Positioning System

GLR

Ground Level Reservoir

HUDCO

Housing and Urban Development Corporation Limited

HIG

High Income Group

IHSDP

Integrated Housing and Slum Development Programme

IRC

Indian Road Congress

IS

Indian Standards

JNNURM

Jawaharlal Nehru National Urban Renewal Mission

LIG

Low Income Group

MIS

Management Information System

MoA

Memorandum of Agreement

MoHUPA

Ministry of Housing and Urban Poverty Alleviation

MoEF

Ministry of Environment and Forest
ii

<!-- page 5 -->

Guidelines for Preparation of Detailed Project Reports
MIG

Medium Income Group

NBO

National Building Organization

NGO

Non- Governmental Organization

O&M

Operations and Maintenance

PHED

Public Health Engineering Department

PPP

Public Private Partnership

PMC

Project Management Consultant

PWD

Public Works Department

QA

Quality Assurance

QC

Quality Control

RAY

Rajiv Awas Yojana

RCC

Reinforced Cement Concrete

RWA

Resident Welfare Association

SEIAA

State Environmental Impact Assessment Agency

SFCPoA

Slum Free City Plan of Action

SHG

Self Help Group

SJSRY

Swarna Jayanti Sahari Rojgar Yojana

SLNA

State Level Nodal Agency

SLTC

State Level Technical Cell

SLMSC

State Level Monitoring and Sanctioning Committee

SOR

Schedule of Rates

SSA

Sarva Shiksha Abhiyan

TBM

Temporary Bench Mark

TPIMA

Third Party Inspection and Monitoring Agency

TSS

Total Station Survey

ToR

Terms of Reference

UGR

Under Ground Reservoir

UIDAI

Unique Identification Authority of India

ULB

Urban Local Body

UT

Union Territory

iii

<!-- page 6 -->

Guidelines for Preparation of Detailed Project Reports
Introduction to Guidelines for Preparation of DPR.
The objective of RAY is to make cities slum free adopting „Whole Slum Approach‟. This
requires the existing slums in a city or town to be remodelled so that the residents are
provided with acceptable level of housing and access to social & basic urban infrastructure
of optimum standard. Accordingly, all three (i.e. housing, community facilities and urban)
services require attention. At the same time, an attempt is required to ensure that slums do
not grow in future. For this, adequate and affordable housing with adequate infrastructure
are to be created progressively in a town to meet the demand of poor migrant workers and
others who are compelled to seek shelter in slums or in slum-like conditions. Therefore the
objective requires two simultaneous actions:–
(a) Redevelopment / Up-gradation / Relocation of slums to acceptable living conditions; &
(b) Preventive or pre-emptive action.
The guidelines for RAY provide flexibility to States/UTs and cities in deciding solutions
specific to the requirements of each slum, whether redevelopment, up gradation, or
relocation in consultation with community though In-situ re-development is the
programme of choice.
The preparation of Detailed Project Report(s) DPRs would follow the preparation of the
Slum-Free City Plan of Action (SFCPoA) (Refer “Guidelines for Preparation of Slum Free
City Plan of Action” for details).
On the basis of prioritisation of slums in SFCPoAs, cities would be required to prepare
DPRs covering „whole slum‟. As preparation of SFCPoAs may take some time, States / UTs
have the liberty to submit DPRs for sanction, pending the preparation of SFCPoAs only in
the first year of launch of the scheme. Thereafter implementing agencies are required to
prepare SFCPoA first and then DPR for selected slum.
The Detailed Project Report is a document which deals with all aspects of pre-investment
planning and establishes the need and feasibility of the project. The DPR is needed to seek
assistance under RAY from the Government of India with sufficient details to ensure
appraisal, approval and subsequent financial assistance for implementation in a timely and
efficient manner.
Each DPR would be submitted by the State Level Nodal Agency with the approval of the
State Level Sanctioning & Monitoring Committee for sanction by a Central Sanctioning
and Monitoring Committee (CSMC). The DPRs would be submitted to the Ministry or its
appointed agencies. DPRs would be appraised by appraisal agencies engaged for the
purpose under the supervision of the RAY Directorate prior to placing it before Central
Sanctioning and Monitoring Committee. It is essential that the DPR should conform to
guidelines. A Checklist of documents & information required in DPR and Administrative &
Technical checklist containing details of proposal are placed at Annexure A and B. All
DPRs are required to be submitted with the checklist duly filled for facilitating faster
approval.
These guidelines attempt to describe the process and a step-by-step approach in order to
prepare DPR for selected slum(s) ready for seeking sanction under RAY by the eligible
institutions i.e. Urban Local Bodies (ULBs), Para-Statal bodies and other implementation
agencies.
1

<!-- page 7 -->

Guidelines for Preparation of Detailed Project Reports

1. TYPE OF PROJECTS WHICH CAN BE TAKEN UP IN DPR
1.1
The composition and nature of slums are likely to vary from town to town. In
general, one may expect various degrees of deficiencies with regard to housing, urban
infrastructure and community facilities. Considering that in various cities efforts have
already started to redress the deficiencies with regard to housing and basic urban
infrastructure, it is recommended to prepare an updated status of all slums, both notified
and non-notified in a given town. Those slums which are already provided with pucca
housing with kitchen and toilet facility as per RAY guidelines and basic infrastructure
should not be taken for DPR. In other cases, gaps may exist either in terms of basic urban
infrastructure or in terms of pucca housing. Therefore, typically, Interventions in selected
slums can be as follows to address various levels of deficiencies:
1.
In-situ Re-development – Development of entire slum by providing adequate
housing and infrastructure (civic and social) to the slum dwellers after demolition of the
existing built structures.
2.
In situ Up-gradation: Development of the entire slum by filling gaps in housing
and infrastructure (civic and social) to the slum dwellers without complete demolition of
the existing built structures.
3.
Slum relocation : Intervention in this case would include adequate housing and
infrastructure (civic and social) to the slum dwellers on alternate site. Relocation should be
done only for untenable slums with emphasis on providing mobility and recreating
livelihood linkages.
In-situ slum re-development/ up-gradation should be encouraged to ensure that
development does not lead to loss of shelter of slum dweller and livelihood linkages or
additional commuting hours leading to loss of income.
Temporary transit housing required to accommodate the displaced slum dwellers of
intervened slums shall be proposed in the DPR.
1.2
Depending on the specific requirement of a city / town, all these types of projects
should be included in the DPR in a manner as comprehensive as possible. While selecting
slums, slums located near each other and form a cluster should be preferred, to take full
advantage of the available city-wide network of infrastructure. While selecting slum for
preparation of DPR, it should be ensured by State/ULB that the slum dwellers are residing
in the slum for a period of 5 years. It is likely that out of all slums existing in a city / town,
priority slums are included in the DPR. Slums which are not included as prioritized slums
may be taken up at a later stage depending upon available resources.
1.3
Following type of housing may be considered in all these projects depending on the
need of selected slum

2

<!-- page 8 -->

Guidelines for Preparation of Detailed Project Reports
1. New housing: Slum dwellers without pucca houses should be provided with new
dwelling unit (Single storey or Multi-storied building) of carpet area between 21-27
sqm. with two rooms, kitchen, bathroom, water sealed toilet and individual potable
water connection facility.
2. Rental Housing: Rental housing may be the preferred choice to accommodate
tenants of slums, labourers, floating population and urban homeless. Recognising that
managing such rental premises is challenging, States/UTs will be required to clearly
enunciate mechanisms for managing such premises including fixation of rent,
operation and maintenance, vacancy norms etc. The carpet area of rental DUs is
expected to be between 16-20 Sqm. with shared civic infrastructures. However, rental
DUs with carpet area between 21-27 Sqm can also be proposed in exceptional cases.

3. Incremental housing: Incremental housing may be considered in case the existing
dwelling units built by the slum dwellers need improvement i.e. if the dwelling unit is a
pucca construction but having less than the desired minimum floor space or rooms,
additional provision of rooms, toilets etc. should be considered to meet the minimum
criteria (In case land is not available for expansion, vertical development may be
considered).
1.4
With regard to housing, full flexibility of approach is available for the manner of
construction and arrangement of funds. Following models for execution may be adopted:
a. Beneficiary-led Execution: Beneficiaries may be involved for construction of DUs
which would result in better monitoring and implementation. Implementing agencies
should ensure timely availability of funds required for the smooth progress and
completion of projects. Funds to beneficiary should be released in four installments,
the first of which would be before commencement of construction (10%), second once
construction is up to plinth level (30%), third after construction up to roof level
(40%) and final installment on completion of construction (20%). The exact quantum
may be varied by implementing agencies as per local conditions.
b. Executing Agencies: Execution of housing projects should be taken up preferably
by ULBs. In case, States/UTs decide to execute the projects through Parastatal i.e.
Housing Boards, Development Authorities etc. then consent of the concerned ULB
should be taken before assigning projects to such Parastatals.
1.5
Projects for slums located on lands of Central Government/Central Government
Undertakings /Autonomous bodies created under the Act of Parliament are also eligible
under RAY. The land owning agencies will have the discretion to prepare DPR on its own
or in partnership with State/UT governments and concerned ULBs. In case, DPR is
prepared by the land owning agency on its own and no State share is envisaged, then DPR
may be directly submitted for consideration to Ministry of Housing and Urban Poverty
Alleviation. If DPRs are prepared in partnership with States/ULBs then these should be
submitted through SLNA with approval of the SLSMC.
3

<!-- page 9 -->

Guidelines for Preparation of Detailed Project Reports

1.6
States/UTs are encouraged to come up with innovative projects for which fund is
earmarked. The key objective would be to incentivize innovation and encourage new
approaches and solutions to improve the quality and quantity of shelter and services for
the urban poor/slum dwellers. The innovative approaches may include:


Innovations in planning, demonstrating integrated livelihoods, shelter and services
or convergence



Innovative or cost effective and green building design and technologies



Financial innovation in the delivery of city/state wide programmes (e.g. community
fund, incremental savings etc.)

4

<!-- page 10 -->

Guidelines for Preparation of Detailed Project Reports

2. STEPS IN DPR PREPARATION
Step (i): Selection of project for the slum:
On the basis of description in last chapter, first step in DPR preparation is to decide the
type of project which is suitable to tackle the problem faced by selected slum. While
deciding type of project it is to be ensured that slum dwellers / communities views are
taken into account. After selecting the slum, the preparation of improvement plan of the
selected slum, often called „micro-planning‟, should be done involving the community. This
activity should aim at making the best possible choices with regard to layout, locations of
community facilities and urban infrastructure, keeping in mind the requirements of public
health and safety as per Disaster Management Plan. (Refer “Guidelines for Community
Participation for details)
Step (ii): Land possession and Land use:
Before formulating the project proposal for slums, States must ensure that the land /
project area is under the possession of ULB and free from all encroachment and
encumbrance. The land use of the proposed project land should be residential.
The location of slums should also be examined with reference to following:
1.
Industrial land-use and/or close to hazardous industries
2.
Cultural or religious sites / structures / locations / zones
3.
Heritage sites / structures / locations / zones
4.
Coastal Regulation Zones / Areas
5.
Urban forestry / reserve forest areas / forest land
6.
Waterway of natural drainage courses, Flood-ways
7.
Conserved structures / lakes / rock formations / steep slopes
8.
River-beds or of the stream / river and tank beds
9.
Any other environmentally sensitive location that may fall in restricted area /
prohibited area, such as near landfill sites, within high tide line, Landslide area etc.
If an existing slum is located in any of the above-mentioned areas, it would be required to
be relocated at an appropriate location either in full or in part. However in situ
redevelopment can be taken up after change of land use to residential if applicable or
taking proper mitigation measures.
Step (iii) : Survey and Mapping of selected Slum :
For detailed planning and design of housing and infrastructure within slums, integration
with city-wide network of urban infrastructure, it is required to create detailed plan by
carrying out Total Station Survey1 (Physical survey by Total Station) for the slum(s). The
1

In case if the slum is too congested to carry out Total Station Survey, other method like plane table and auto-levels can
be used to do the in-filling, while establishing the slum boundary and main features using Total Station instrument.

5

<!-- page 11 -->

Guidelines for Preparation of Detailed Project Reports
Survey shall be carried out to generate the following drawings/maps using AutoCAD or
similar software:
1.
Plan to a scale of 1:200 to 1:500 ( i.e. readable, depending on site condition)
showing physical boundary of slum, roads, lanes, sewer/drain manhole positions, roadside
drains, boundary of each dwelling, community property2 (if any), open space and all
surface features like electric poles, trees, telephone poles. Ground Elevations are to be
noted, referenced to GTS datum.
2.
Contour Map showing contours depending upon site conditions and topography,
indicating ground slope and direction of drainage. Survey should extend to existing nallahs
/ drains, capturing ground and invert elevations of such receiving course(s) of drainage.
3.
Using appropriate legend / notation, house type, (such as kutcha, semi pucca,
pucca, dilapidated etc.) shall be noted; each house / dwelling shall be given an
identification number which would be the same as given during socio-economic survey
using modified NBO format.
4.
Infrastructure maps showing existing underground utilities, like water distribution
pipes and their diameter if available, sewer lines and their diameter if available, electric
lines, telephone lines/ cable etc. These drawings may be prepared by plotting
underground services using secondary sources of information or any other method as
appropriate
5.
Surrounding area up to a reasonable distance, say 100 m to depict adjoining road /
property and administrative boundaries like ward boundary, zoning boundary etc. where
applicable. It should be ensured that main drain is surveyed up-to the outfall (Discharge
point) so that connectivity can be ensured.
It may be noted that during survey, representatives of the ULB and / or Utility Authority
(e.g., Water, Sewerage, Electricity etc.) as well as community volunteers should participate
actively and satisfy themselves about the survey being carried out to ensure that nothing is
left out.
The drawings so prepared from TSS shall then be transferred to the GIS database using
software conversion techniques. Slum base map, Digital Elevation Model (DEM)3, Relief
map & slope map of slum shall be prepared using TSS data for cities with population more
than 3 lacs (2011 census) or the cities where work is already started under preparatory
phase. (Refer “Guidelines for GIS, MIS and GIS – MIS Integration” for details).
Relief map shall be used to generate 3D view of the slum base map during the preparation
of DPR. Preparation of 3D view is not mandatory but discretionary. 3D views so generated
may be discussed with the community to help them understand the existing housing &
infrastructure condition and the proposed development models. It is suggested that 2-3
development models may be prepared for facilitating discussion and finalization of the
2
3

This includes common properties like community toilet, community centre, informal markets etc.
DEM will help to analyse ground condition of slum, topography, ground slope and direction of drainage. Further, this
will also help to identify the vulnerable areas like prone to flooding/water logging and landslides (in case of hilly
areas).

6

<!-- page 12 -->

Guidelines for Preparation of Detailed Project Reports
most suitable model for the type of intervention selected for the slum. The process would
yield appropriate and affordable alternatives for layout, re-alignment, spaces for livelihood
etc. Broad plan for realignment may be discussed by the community before the technical
feasibility is carried out so that conflicts can be avoided during the implementation phase
as in this entire process some houses may have to part with some land to allow
infrastructure to be laid out. (Refer “Guidelines for Community Participation for details)
During survey, the identification number is to be given for (a) house / dwelling unit and (b)
household. It may be noted that in one house, two households may be present. Thus
combination of the two IDs (i.e. ID of dwelling unit and household) would pinpoint to each
household and should be used to ensure proper and verifiable linkage of socio-economic
data and housing condition / property data.
Step (iv) : Assessment of Deficiencies in selected slum(s) :
Deficiencies are to be assessed in terms of (a) housing; (b) basic civic and social
infrastructure; and (c) socio-economic conditions. Slum Profile and Household Survey
would establish the existing deficiencies for all these three parameters.
The quantum of housing deficiency (in terms of existing inadequate housing) can be
assessed from the combined results of slum physical survey and slum household survey.
Following the RAY principles, it is to be determined how many dwelling units need to be
provided by replacing or building new housing in lieu of existing inadequate housing using
the criteria of 21-27sqm. carpet area for each dwelling unit with 2 rooms, kitchen and
bathroom and toilet (separate) facility in single story and / or multi-storied building.
During the assessment of housing needs, it may be determined that houses / dwelling units
built by the slum dwellers may need improvement i.e. if the dwelling unit is a pucca
construction but having less than the desired minimum floor space or rooms, additional
provision of rooms, toilets etc. should be considered to meet the minimum criteria so as to
facilitate housing unit up-gradation (In case land is not available for expansion, vertical
development may be considered). Provision of individual water supply, sanitation and
electricity connection should also be considered, where so required. This type of projects
would fall in the category of incremental housing
The assessment of deficiency in social infrastructure should be made by comparing the
requirement of each element (e.g. Anganwadi, Livelihood Centre etc.) according to the
norms of provision as stipulated in the planning norms in the Master Plan or State
Planning norms, whichever is applicable vis-à-vis the actual availability. However, in doing
so, groups or clusters of slums may be taken up, if they exist in close proximity to one
another. This way, optimum use of land and other resources may be achieved.
The infrastructure within slum comprising road/lanes, water supply, sewerage and
sanitation, electrification and storm water drainage should be planned in an integrated
manner connecting with city-wide network. In case of specific problem because of which
7

<!-- page 13 -->

Guidelines for Preparation of Detailed Project Reports
the in-slum infrastructure cannot be connected with city wide network, then standalone
infrastructure components can be considered.
The cost of user charges for water, electricity, and sanitation services as imposed by the
ULBs and/or service providers shall be borne by the individual beneficiaries.
The project would include connection and installation of meters for basic services of water,
electricity and sewage individual connections, which shall not be charged to the
beneficiaries.
Step (v) : Integration of Social Infrastructure
The Project planning should ensure convergence of education, health and social security
with other on-going schemes. It is also to be ensured that operationalizing these
components is also taken care of during project preparation.
Details of existing Education and Health facilities need to be prepared. Based on the data
collected, requirement for Education and Health facilities in the proposal may be assessed.
In case the existing facilities are adequate for the proposed settlement, the same may not
be proposed. Otherwise, provision for these facilities need to be ensured in the proposal. If
adequate land is not available for these facilities at the project site, provision for alternate
arrangements in the adjoining area should be made.
It is reiterated that only pre-schools/ anganwadis and health centres/sub-centres (only if
funds are not available from any other State/Central schemes) are eligible for Central
assistance. Additional education and health facilities required as per norms will have to be
converged with other State/Central scheme and will not be eligible for Central assistance.
Step (vi) : Establishing Linkages with City-wide infrastructure Network
For all types of projects, proposed in-slum infrastructure requires to be linked with citywide infrastructure – these include roads, electricity network, water supply network,
sewerage network, storm water drainage and solid waste management system. When
project sites are located in the developed parts of the town, this may or may not present a
problem as far as system availability is concerned but it is to be checked whether the citywide system is capable to deliver the increased demand exerted by development of slum
and up-gradation. If a shortfall in capacity is determined, a supplementary project may
have to be taken up under other State / Central Government schemes as this cannot be
funded under RAY. The adequacy of existing water supply system in the slum needs to be
checked with respect to increase in water supply to slums (either in-situ development or
relocated slums) from existing status to full city level status @ 135 lpcd. Due to increase in
water supply, there would be a consequent increase in wastewater generation. Clearly, the
wastewater so generated would need treatment. If there is an existing Sewage Treatment
Plant, its rated capacity should be checked against the overall increase in sewage
generation. In case of shortfall, a programme of enhancing or augmenting the capacity
should be taken up. Suitability of the decentralised sewage treatment plant should be
8

<!-- page 14 -->

Guidelines for Preparation of Detailed Project Reports
explored. In such cases, treatment processes shall be so chosen so that their operations
should be simple and maintenance affordable.
Step (vii) : Preparation of Detailed Designs after assessment of Demand / Gap
The assessment of demand of housing and infrastructure shall be made to meet the current
deficiency and also to bridge the gap between the future and the present demand of
housing and infrastructure with due attention to plan the layout (after reconfiguration of
plots, if possible), total sanitation (with provision of individual toilets and water supply to
each household) and provision of adequate green spaces as per (modified, if necessary)
town planning norms.
DPR should be prepared on the basis of assessment of the demand/gap and following the
various technical standards. A list of Admissible components under RAY is placed at
Annexure E
The houses are to be designed by qualified architects and engineers, conforming to the
National Building Code and other relevant Bureau of Indian Standards (BIS) Codes. The
National Building Code (NBC) lays down provisions designed to protect the safety of the
public with regard to structural sufficiency, fire hazards and health aspects of the
buildings. The sizes as per standards for low income housing units in NBC-2005 are as
under:
S.No.
1

Unit

Minimum Area
( Sqm)
9.00

Minimum
width ( m)
2.50

Remark

Living
Total area of both the
room
habitable rooms to be not
less than 15.5 sq.m
2
Bedroom
6.50
2.10
3
Kitchen
3.30
1.50
4
Bath room
1.20
1.00
5
Toilet
0.90
0.90
Total
20.90 ( Say 21.00)
*The minimum width of individual balcony, where provided, shall be 0.9m and shall
not be more than 1.2m and it shall not project beyond the plot line and on roads or
pathways.
With regard to housing, full flexibility of approach is available for the manner of
construction and arrangement of funds for construction viz. to follow a beneficiary-led
housing model, individually or in the case of multi-storied housing by housing
associations, with design and technical support from the ULB/State, or construction of
housing through State parastatals or private partners or by the option of Rental housing or
by delineating a mix of methods.
The design of urban infrastructure should be carried out as per the provisions of Central
Public Health and Environmental Engineering Organization (CPHEEO) manuals, Indian
Road Congress (IRC) codes, BIS codes with relevant amendments and other relevant

9

<!-- page 15 -->

Guidelines for Preparation of Detailed Project Reports
specifications. (For details,
www.bis.org.in be referred).

web

site

www.cpheeo.nic.in

,

www.irc.org.in

and

It is required that the ULB/ Implementation agency to take into account the provisions of
the City Development Plan, City Sanitation Plan etc. to achieve synergy with ongoing
schemes/programmes. Service plans and cross sections of the infrastructure components
need to be clearly indicated on drawing with proper dimensions on an appropriate scale.
The length of link infrastructure for integration with city-wide network should be clearly
marked in the drawings.
For proposed infrastructure components, source (Tube well or Municipal water for water
supply) disposal (Septic tank, Dewats or Municipal sewer for sewerage), storage (GSR/ESR
or individual tanks) etc. should be clearly spelt out in the DPR. Integration of proposed
infrastructure with city level infrastructure should be mentioned.
Conservation of the environment and ecology should be built into the habitat planning,
which includes water conservation through reducing strategies ( use of dual pour cistern
for flushing and low flow plumbing fixtures), handling of household waste ( segregation of
bio-degradable waste for composting), reduced dependency on virgin material (i.e. wood
for doors and windows), use of renewable sources of energy ( i.e. Solar lights), rain-water
harvesting (provision of open spaces and rain water collection system apart from roof
water harvesting), innovative and energy efficient technologies ( i.e. orientation of building
to get maximum benefit of natural light). For green technologies, Green Rating for
Integrated Habitat Assessment (GRIHA) guidelines ( www.grihainida.org) promoted by
Ministry of Non-Renewable Energy and guidelines of Indian Green Building Council
( www.igbc.in) may be referred.
The DPR should include hazard resistant planning and design, taking into account proper
site selection. Housing and infrastructure need to be constructed to avoid loss or threat to
life and economic losses.
There are three basic concerns in disaster management in slum areas –
(i) The shelters/buildings may lack considerations of safety against earthquake, cyclone
etc.
(ii) The area in which slums are located are often prone to disasters like landslides, flood
and man-made hazards such as fire, explosion, chemical release etc. and
(iii) Lack of access for relief and rescue operation in case of an incidence of disaster. Access
of Fire tenders and Ambulances inside slum is often just not available, because the
road/lane is too narrow.

10

<!-- page 16 -->

Guidelines for Preparation of Detailed Project Reports

While buildings are to be designed and built to meet the requirements of general structural
safety against cyclone, earthquake etc., items under (ii) and (iii) require proper planning to
result in provision of adequate space for access roads. This can be done without much
difficulty in case of relocation projects, however for in-situ redevelopment and upgradation of existing slum(s), this requires an involved exercise with communities, because
they will have to agree for re-plotting, providing space for improved access roads, in case
they own the land on which dwellings are located. An attempt should be made to provide
main access road with a minimum width of 6 m to allow entry of fire tenders and
ambulance in to the slum. The ULB should ensure building by-laws being enforced with
regard to minimum width of roads. Disaster Mitigation Measures have also been
mentioned in Annexure- F.
Thus the DPRs should categorically include Disaster Management Plan as per the
requirement of Disaster Management act 2005 for the slum(s) under consideration to
respond to identified disasters (Incidence Response System), provide relief and rescue and
also disaster prevention measures.
“Guidelines on Multi-Hazard Resistant Construction of EWS Housing Projects”,
developed by the Building Materials & Technology Promotion Council (BMTPC), Ministry
of Housing & Urban Poverty Alleviation, Government of India may be referred to for
housing design and construction with relevant IS Codes and updated amendments.
Step (viii) : Statutory approvals.
Statutory approvals as per bye laws, master plan, fire safety norms, Environmental
clearance etc. as applicable for the project are to be taken. The stipulations / regulations
might undergo change. States / ULBs are expected to get the clearance / approval from
appropriate authorities as per amended stipulations / regulations.
It is to be ensured that statutory approvals are obtained before submission of DPR to the
MoHUPA for CSMC approval.
Step (ix) : Estimation of Project Cost
Cost estimates have to be worked out on the basis of detailed bill of quantities (with
detailed measurements of length, breadth, and depth / height for each item), using the
current Schedule of Rates of the State Government or relevant SOR as applicable. If the
applicable Schedule of Rates relates to a year, which is one or more years prior to „current‟
year, an appropriate cost index may be applied to update such rates, as approved by the
competent authority.

11

<!-- page 17 -->

Guidelines for Preparation of Detailed Project Reports
In addition to permanent works, temporary transit accommodation cost may be included
in the estimate of DPR for in-situ redevelopment with new housing.
The DPR shall be submitted duly authenticated and cost estimates shall be certified by
competent technical authority at ULB and State/UT level.
Project Cost Estimate in DPR should include the charges of DPR preparation, Project
Management, Third Party Inspection & Monitoring (TPIM), social audit. These charges
will be shared between Central and State Govt. as per applicable sharing pattern.
The elements of cost such as price escalation, departmental charges of implementing
agencies, any mark-up above current SOR, tender premium, contingencies etc., may form
part of project cost, but GoI contribution will not be admissible for such cost. The State
government/ ULB will have to bear such costs.
The cost estimate should be prepared slum-wise, collating detailed estimates for various
items of work along with quantity, rate and amount using MS Excel or similar software, so
that any revision or modification may be incorporated easily. Each slum should thus have a
Cost Summary sheet. For example, in the DPR, if there were 5 slums, there would be 5
summary sheets. The total figure of such 5 summary sheets should be collated in to the
Main Cost Summary, giving the estimated project cost. Of the Total Project Cost, the share
of the State Government, ULB, Beneficiaries and Government of India should be shown
separately, as admissible. Implementing Agencies preparing the DPRs will have to give the
financial model and commitment of State/ULB share to complete the project.
An Executive Summary indicating physical and financial detail of the project needs to be
included in the DPR as per Annexure „C‟
Step (x) : Implementation and Management arrangements
The DPR should clearly bring out the implementation and management arrangements of
the project, dealing with administrative structure, implementing agencies against various
components of the project. If more than one agency is involved, a clear description of
method to achieve co-ordination among them should be described.
The DPR should provide a time-bound action plan including tendering, appointment of
contractors, construction schedule for transit accommodation and phasing of new housing
in case of in-situ redevelopment, quality assurance & quality control and post-construction
activities, including project delivery. Among other things, the action plan should include,
(i) project schedule in the form of a Gantt chart, showing monthly target; (ii) quarterly
fund requirement to match the project schedule; and (iii) schedule of slum-wise project
delivery
The implementation and management arrangement should mention the role of the State
Level Nodal Agency (SLNA), State Level Technical Cell (SLTC), City Level Mission
Directorate, City Level Technical Cell (CLTC) and Project Management Consultant (PMC).
12

<!-- page 18 -->

Guidelines for Preparation of Detailed Project Reports
After completion, projects should be handed over to the beneficiaries in a timely manner.
As-built drawings of all completed projects should be vetted and handed over to the ULB.
The necessary administrative structure, overseen by the SLNA, should be in place to
ensure successful project delivery to avoid unprofitable expenditure as well as suffering of
people, for whose benefit the project has been undertaken. The ULB should record project
handing over and delivery, and furnish the information to the SLNA. The SLNA, in turn,
should furnish such project completion information to the MoHUPA, GoI.
Step (xi): Operation and Maintenance plan of proposed assets
Operation and Maintenance of assets created under the project has always been a matter of
concern due to lack of resources available to project owners to carry out maintenance.
Although the annual budget requirement for maintenance is miniscule compared to the
project cost, huge investments have simply suffered due to negligence in continued budget
allocation.
Maintenance of the assets created under the scheme should preferably be carried out by
the beneficiary or their group, if necessary in partnership with ULBs. An O&M fund up-to
4% of the project cost is admissible under the scheme. Central Government will contribute
one-time to this O&M fund in the applicable ratio for the city i.e. 50:50 for cities with
population more than 5 lakh, 75:25 for cities with population less than 5 lakh and 80:20
for cities in NE and special category States.
Maintenance Fund should be utilized as a Corpus Fund and placed at the disposal of the
ULB. This fund should be used for implementation of O&M plan as agreed by the
Committee for maintenance of community assets like common structure of multi storey
buildings, community centres etc. As far as the common infrastructure (e.g., roads, water
supply, sewerage, drainage, street lighting etc.) is concerned, the O&M (created as in-slum
assets) should be treated as part of the city-wide infrastructure and the implementing
authority / ULB should look after the O&M of such infrastructure. Furthermore, it is
considered appropriate that the beneficiaries would pay user charges for the infrastructure
and maintenance charges for housing and other buildings, for which the concerned
authorities should work out appropriate user & maintenance charges with suitable cross
subsidization. In addition, the administrative arrangement for attending to complaints and
regular maintenance to ensure on-time maintenance also needs to be worked out.
In the DPR, the component wise details of an annual O&M plan indicating the expenditure
to be incurred vis-à-vis revenue generated from the maintenance charges, summarizing all
these aspects – administrative, financial and operational, should be clearly spelt out.

13

<!-- page 19 -->

Guidelines for Preparation of Detailed Project Reports
3. SUGGESTED CONTENTS OF DETAILED PROJECT REPORT
1. Checklist of Documents / Information required in the DPR (As per Annexure A)
2. Administrative and Technical checklist (As per Annexure B)
3. Executive Summary (As per Annexure C)
4.
Introduction
<General introduction shall include write up on: Rajiv Awas Yojana (RAY): The scope
and status of RAY in the respective state and town, timelines for making slum-free
action plan, and the status of various cells to be constituted under RAY. It may further
include progress made in various Central / State-funded projects in slums like
JNNURM (BSUP, IHSDP), ILCS, SJSRY etc. The contents shall also include list of
slums and a slum map of whole city (where available.>
5.

Salient features of Slum Free City Plan and its Linkage with proposed project and
Justification of project.
<General introduction on status of preparation of SFCPoA. Summary of findings of
SFCPoA. Spatial, demographic and socio-economic profiles of slums; Physical
infrastructure within and in the vicinity of slums and proposed relocation areas
including connectivity infrastructure: road network (within and in the vicinity of
slums), water supply, sewerage, drainage, electricity and communication networks,
and other physical infrastructure facilities. Social infrastructure facilities (education,
health, banking, community hall, livelihoods centres, informal sector markets etc.) in
or near the slum pockets and proposed relocation sites; shelter – existing status with
respect to age, condition and height of structure and proposed changes including
redefined plot boundaries; Tenure Status - analysis of the existing tenure
arrangements between the owners and occupiers or any other parties involved;
proposed tenure arrangements, including assignment of property rights etc.; Choice
of development model for housing and/or infrastructure – PPP, Beneficiary built,
Community-based, Public agency-led, etc.; Resource mobilization strategy;
Implementation strategy, including phasing and monitoring and community
mobilization; Measures for preventing future growth of slums – reservation of land
for EWS/LIG in all future housing colonies, undertaking affordable housing in
partnership, adopting slum-free city policy, addressing regional and urban planning
issues to make the same inclusive, etc..
Prioritization for proposed project as per the deficiency matrix / tenability analysis
and rationale shall be spelt clearly. >

6.

Project Concept and Scope
<Introduction of slum(s), : General description of slum(s) , Age of slum(s), Area of
slum(s), Demographic profile, Social infrastructure etc. as per finding from slum
survey.
14

<!-- page 20 -->

Guidelines for Preparation of Detailed Project Reports
Location of slum, with map showing surrounding areas and trunk infrastructure
available for the integration with proposed infrastructure of the slum.
Tenural Status, Land use and Land Possession status in proposed project area
Existing basic infrastructure i.e. water supply; sewerage, roads, drains, solid waste
management, electrification, available and its coverage.
Strategy adopted for the slum improvement / development i.e. In-situ up-gradation,
In-situ Redevelopment, and relocation (only in unavoidable cases). Brief of proposed
components (Housing and Infrastructure).>
7.

Description of Project and Planning
a)
Slum Survey
<Outcome of Socio economic survey and Livelihood survey integration shall be done
as per modified NBO format circulated by the Ministry on 13th May 2013(As per
Annexure G)>


Physical survey ( TSS)

< Base Map showing Planning boundary / Physical boundaries, open plots, Existing
Physical features like roads, lanes, sewer/drain manhole positions, roadside drains,
boundary of each dwelling (such as kutcha, semi pucca, pucca, dilapidated etc.),
community property (if any), open space and all surface features like electric poles,
trees, telephone poles. Ground Elevations are to be referenced to GTS datum. List and
location of TBM‟s shall be provided on map. Infrastructure maps showing existing
underground utilities, like water distribution pipes, sewer lines, telephone lines, gas
pipelines etc. These drawings may be prepared by plotting underground services using
secondary sources of information or any other method as appropriate. Surrounding area
up to a reasonable distance, say 100 m to depict adjoining road / property and
administrative boundaries like ward boundary, zoning boundary etc. where applicable.>
b) Community Participation
<Micro Planning in the slums, list of institutions and persons involved in Micro
Planning, Description of Slum wise Micro-Planning Process, Focus Group Discussions
for Beneficiaries identification/ UIDAI, Beneficiaries consent for relocation, accepting
DUs on upper floors in multi storied building and financial contribution, Community
involvement from planning stage to allotment, finalisation of layout plan using 3D
models, O&M plan, Beneficiaries contribution and mobilization.>
c)

Provision of Housing

<Planning & Design of Single/ Multi storied building. No. of units, Cost per unit, Unit
design philosophy, Basis for planning, Structural design, Proposed area of the dwelling
15

<!-- page 21 -->

Guidelines for Preparation of Detailed Project Reports
unit, Density of proposed houses , Ground coverage of proposed housing , Area under
roads, green area, detailed housing designs (Plan/ Section/ Elevation / Sectional
Elevation) Type of material / Technology used in housing construction, Local
material used in housing, provision of individual service connections (i.e Water supply,
Sewerage , & Electricity) >
d) Provision of Community Facilities
<Planning & Design of Anganwadi, pre-schools, child care centre, Livelihood Centre,
Multi-purpose Community Centre, Library cum study centre, Training centre for
computer training with internet provisions, Community Park etc. as applicable. Detailed
building designs (Plan/ Section/ Elevation / Sectional Elevation) Type of material /
Technology / Local material used .Justification of providing / Not providing Community
facilities. Deficiency in education and health facilities >
e)

Provision of basic civic Infrastructure & Integration with city wide network

Water Supply:
<Existing water supply system in project and adjoining area. Basis for designing of
proposed water supply system, sources of water supply, quality of water , provision for
treatment of water, length and diameter of water supply line proposed, provision for
rain water harvesting, provision for water meters, provision of storage (ESR / GSR/
UGR), type of material >
Sewerage:
<Existing sewerage system in project and adjoining area. Basis for designing of
proposed Sewerage System and its treatment , length and diameter of sewerage line
proposed, Number of Septic Tanks, Septic tanks shall be designed as per relevant IS
Codes. Manhole etc.(whichever is applicable), Sewage disposal point, type of material >
Storm Water drains:
<Existing storm water drainage system in project and adjoining area. Design & planning
aspects, Length of storm water drains proposed and type of materials used. Drainage
disposal points.>
Roads & Pavements:
<Type / length / width and material of roads & pavements proposed, Road side
plantation etc, >
Street Lighting:

16

<!-- page 22 -->

Guidelines for Preparation of Detailed Project Reports
Total no. of street lighting poles, centre to centre distance from each other, type of wiring
etc. Provision of Transformer if required,
Solid Waste Management:
<Existing solid waste management system . System proposed for collection and
transportation of solid waste and nearest disposal point. Details of proposed Waste
Depots (dhalao) ,Dustbins ,R.C. container >
Parks and Open Spaces:
<Provision of organized open spaces with location marked in the site layout plan.>
Community toilets:
<Existing Community toilets. No. of community toilets/complexes proposed along with
justification of their need and location, Unit design, Design philosophy, Basis for
planning>
f) Adoption of green technology in the project
<Details of any green material / Technology adopted in planning and designs such as
water conservation through reducing strategies, handling of household waste, reduced
dependency on virgin material i.e. wood for doors and windows, use of renewable
sources of energy, rain-water harvesting, innovative and energy efficient technologies
etc.>
g) Disaster Management and Mitigation
<Status of Disaster management plan in State / District / City. Management mechanism
for likely hazards in town/ slum.(Earthquake/ Fire / Flood/ Landslide / Cyclones or any
other risks), Mitigation Strategies adopted for buildings and infrastructure as stipulated
at Annexure F >
h) Statutory approval including environmental clearance ( as applicable)
<Write up on statutory approval requirements of the project as per applicable
guidelines.>
8.

Project Cost Estimate

 Abstract cost estimates
a. Component wise abstract for each slum.
b. Consolidated Component wise abstract for all slums.
 Detailed Estimates
17

<!-- page 23 -->

Guidelines for Preparation of Detailed Project Reports
<Cost estimates worked out on the basis of detailed bill of quantities (with detailed
measurements of Length, Breadth, and Depth / Height for each item), using applicable
Schedule of Rates. If the applicable Schedule of Rates relates to a year which is one or
more years prior to „current‟ year, appropriate cost index may be applied to update
such rates, as approved by competent authority>
9.

Project Implementation & Management Framework
a) Institutional capacity in terms of infrastructure, manpower, experience, with
regard to Project Implementation, etc.
b) Institutional Framework for implementation i.e Creation of RAY Cell comprising
of officials from concerned departments or any other alternate arrangement.
c) Implementation schedule ( Bar Chart )
d) Process proposed to be followed for award of construction work.
e) Quarterly component wise investment schedule vis-a-vis means of finance
(Central/State/ULB/Beneficiaries share)
f) Project Management Set-up
g) Monitoring mechanism at State ,ULB and Community level.
h) Quality Control & Quality Assurance Plan.

10.

Operation & Maintenance Plan
a) Mechanism proposed/adopted for asset management.
b) Details of revenue generation from the assets created through maintenance
charges.
c) Requirement of funds for operation and maintenance of services (component
wise).
d) Identifying and earmarking funds for maintenance of assets.
e) Provision of corpus fund as envisaged in guidelines.
f) Involvement of community in Operation and Maintenance.
g) Responsibility of ULB in O & M

11.

Financing Arrangement:
Component wise financial statement for each slum indicating cost,
Central/State/ULB/Beneficiaries share or/and any other share. One consolidated
statement covering all slums should also be furnished as per format given below
Component

Central
Share

State
Share

ULB
Share

Beneficiary
Share

Total
Project
Cost

Housing
Infrastructure
*O&M charges up-to 4%
*DPR preparation, PM, TPIM, Social
Audit charges
Others
Total
* These charges will be shared between Central and State Govt. as per applicable sharing pattern

18

<!-- page 24 -->

Guidelines for Preparation of Detailed Project Reports
12. Drawings –









Location Plan(s) of city and slum(s), Land use map
Physical survey maps and Contour plans
Photograph covering the entire slum
Existing Slum/Area layout Plan (Foot prints of existing houses and
infrastructure connectivity)
Slum/Area layout Plan (Foot prints of proposed houses and infrastructure
connectivity)
On site Infrastructure service plan (water supply, sewerage, roads, drainage etc.)
and linkage with city wide infrastructure ,
Architectural and Structural Drawings of Buildings
L- Section / Cross section/ Elevation as applicable for roads, Drains, Sewers,
Water supply, Boundary wall, Retaining Wall, Gate etc.

Annexures to DPR:
1. List of Beneficiaries giving their category (GEN/ SC/ST/Minority/ OBC, others)
2. Sample copy of consent of beneficiaries
3. Sample copy of house holds survey.
4. Copy of Act/ Legislation for conferment of tenure rights
5. Sample copy of allotment letter indicating ownership rights.
6. Minutes of SLSMC meeting indicating approval of project.
7. Copy of MoA signed between ULB/parastatals, State and MoHUPA.
8. Reforms – Status and Proposals
9. Undertaking by ULB and SLNA (As per Annexure D)
10. Details of existing educational and health facilities for scheme
11. Copies of statutory approvals
12. Photographs covering existing housing and infrastructure of the entire slum
13. Photo graphs of Micro planning with the community

19

<!-- page 25 -->

Guidelines for Preparation of Detailed Project Reports
Annexure - A - Check list of Documents / information required in the
DPR of RAY
1. State
:
2. City
:
3. Project Name
:
4. Project Cost (Rs in Lacs) :
S. No.
Description
1
Duly authenticated Admin. & Tech. checklist of DPR is
enclosed
2
Duly authenticated Executive Summary is enclosed
3
Duly authenticated Detailed cost estimates are enclosed
4
Following duly authenticated drawings enclosed:
 Location plans
 Survey maps and contour plans
 Existing Slum/ Area layout and service plans
 Building plans, Architectural & Structural drawings
 L- section /Cross-sections/ Elevations as applicable for
roads, drains, sewer etc.
5
Following duly authenticated annexures enclosed:
 Undertaking (signed by ULB/SLNA)
 List of Beneficiaries
 Sample copy of consent of beneficiaries
 Sample copy of household survey
 Sample copy of allotment letter indicating ownership
rights
 Copy of SLSMC approval
 Copies of statutory approval required
 Photographs of existing slum covering housing and
infrastructure conditions and micro-planning
 Certificate regarding “As is where is” basis, if there is no
Master Plan for the region

Signature of the State Level Nodal
Officer

Yes

Signature of the
CEO/Commissioner of ULB/
Implementing Agency
Name & Designation:
Address:
Fax No:
Telephone No.
Mobile No:
E-mail:

Name & Designation:
Address:
Fax No:
Telephone No.
Mobile No:
E-mail:

20

No

<!-- page 26 -->

Guidelines for Preparation of Detailed Project Reports
Annexure - B - Administrative & Technical Checklist
1. Name of the State :
2. Name of the City
:
3. Name of Project
:
4. Project Cost ( Rs in Lacs):
5. Nodal Agency
:
6. Implementing agency
:
7. Total Urban Population of the city as per census 2011:
8. Total Slum Population of the city as per census 2011:
9. Slum(s) population as per census 2011:
10. No of slums covered in the DPR :
S. No.
1. (a)
(b)
(c)
2. (a)
(b)
(c)
3.
4.
5.
6. (a)
6. (b)
7.
8.
9.
10. (a)
(b)
11. (a)
(b)
(c)
12.
13.
14.
15. (a)
(b)
16.
17.
18.
19.
20.
21.
22.

Description
Has the State adopted a policy towards conferring land tenure rights to slum
dwellers ?.
Have the beneficiaries covered in the DPR been provided with lease rights?
Have the beneficiaries covered in the DPR been resident of the slum for 5 years
at the DPR preparation stage.
Has Slum Free City Plan (SFCP) been prepared and forwarded to MoHUPA?
If yes, has the Slum Free City Plan (SFCP) been accepted by MoHUPA?
If not , what is the stage of SFCP preparation?
Has the State Slum Policy been prepared and adopted?
Has MoA for reforms been signed with MoHUPA?
Has State Level Sanctioning and Monitoring Committee (SLSMC) been
Constituted?
Has the DPR been approved by the SLSMC?
If not, has the DPR been forwarded by the designated Nodal Agency?
Is the implementation authority identified with State Govt. approval?
Whether elected Local Body is in Place?
Does a Valid City Master Plan exist?
Has a City Sanitation Plan (CSP) been prepared?
If yes, is the DPR prepared keeping CSP in view?
Has a Disaster Management Plan (DMP) been prepared for the City?
If yes, is the DPR prepared keeping City DMP in view
If no, is a DMP for the slums included in the DPR?
Has the Final List of Slums (with census data) after de-notification been
prepared?
Is the Slum(s) notified or non-notified?
If SFCP is not complete, has tenability & deficiency assessment of slum(s) and
preparation of slum level GIS maps been completed and furnished in the DPR?
Is the Project land in possession of implementing agency and free from any
encroachments and encumbrance?
if not, provide status of proposed land.
Has Socio-economic survey of slum(s) been completed using modified NBO
format circulated by the Ministry on 13th May 2013
Has Physical (Total station) survey of slum(s) been completed?
Have Beneficiaries been identified and is the list enclosed in DPR?
Whether caste-wise breakup of beneficiaries furnished
Has the entire slum(s) has been taken up for housing and infrastructure
improvement while formulating the DPR? ( Whole slum approach adopted)
Have detailed cost estimates been prepared with State Schedule of Rate.
Mention year of SOR?
If cost index is applied on old SoR, has it been certified by Competent

21

YES

NO

<!-- page 27 -->

Guidelines for Preparation of Detailed Project Reports
S. No.

(a)

Description
Authority?
Is the DPR for in situ re-development/ up-gradation?
Is the DPR for relocation?
If Yes, Distance of proposed site from existing location
Whether beneficiaries consent has been obtained for the proposed project
Project Cost (Rs in lacs) and in percentage of Housing to Infrastructure
 Housing
 Infrastructure
Sub-Total
 Contingency
 Escalation
 Departmental charges
 Any other
Total
Has the Cost sharing among State and ULB been formally agreed upon?
Have the tie-ups for beneficiary contribution been indicated?
Central share requested (Rs in lacs)
State share (Rs in lacs) and in percentage
 State Grant
 ULB/Agency‟s own funds
 Beneficiary contribution
 Any other
i) Project Duration
ii) Proposed Date of commencement
No. of DUs New
Up-gradation
Transit
Rental
Dormitories / Any other
If only Infrastructure provided, then give no of DUs benefitted
Carpet area of a DU ( Sqm)
Density (DU/hectare)
Is the Land use of the proposed site residential as per the Master plan?
If not residential, whether change of land use is being proposed?
Coverage area under proposed project components
 Residential
 Commercial
 Facilities
 Green area
 Roads and Pavements
 Any other (Specify)
Status of statutory approvals from :
 Town & Country Planning Deptt.
 Municipal Corporation
 Fire Department
 Pollution Control Board
 Min. of Environment
 Coastal Regulatory Authority etc.
Are Green Technologies or any cost effective technologies being adopted in the
project ?
Has Disaster resistant technology been adopted?
Whether the basic civic infrastructure is connected or proposed to be connected
to City wide infrastructure?
Water Supply

(b)
(c)

Sewerage
Roads

(d)

Storm Water Drains

23.
24. (a)
(b)
(c)
25.

26.
27.
28.
29.

30.
31.

32.
33.
34. (a)
(b)
35.

36.

37.
38.
39.

22

YES

NO

Area
(Sqm)

Area
(%)

<!-- page 28 -->

Guidelines for Preparation of Detailed Project Reports
S. No.
(e)
(f)
(g)
40.

Description
Street lighting
Solid Waste Management
Any Other ( Specify)
Whether provision of following social amenities has been made in the DPR?

(a)

Community centre.

(b)

Livelihood centre.

(c )

Anganwadi.

(d)

Parks & open spaces.

(e)

Any other (Specify).

(a)

Whether provision for convergence of the Central and State Government
Schemes in the following sectors has been made in the DPR:
Health

41.

(b)
(c )

Education
Social Security including accidental and medical insurance, old age pension, old
age homes etc.

42.

Has Separate provision for upkeep and maintenance of public assets to be
created through this project been made?

43. (a)
(b)
44.

Is any component of the project on PPP basis?
If yes, what are the components?
Innovative approaches adopted in the project.

Signature of the State Level Nodal Officer

YES

Signature of the CEO/Commissioner of ULB/
Implementing Agency
Name & Designation:

Name & Designation:

Address:

Address:

Fax No:

Fax No:

Telephone No.

Telephone No.

Mobile No:

Mobile No:

E-mail:

E-mail:

23

NO

<!-- page 29 -->

Guidelines for Preparation of Detailed Project Reports
Annexure - C -Executive Summary
Project Details
1.State
2.City
3.Project Name
4.Project Cost (Rs in lacs)
5.Central Share (Rs in lacs)
6.State Share ( Rs in lacs)
7. ULB Share (Rs in lacs)
8. Beneficiary Share ( Rs in Lacs)
9. Infrastructure cost per dwelling unit
10.SOR Adopted

Project Contributions (Physical + Financial) (Rs. In lacs)

Scheme
Component

Type

Qty.
in
Nos
.

Rate
(in
Rs/U
nit)

Propos
ed
Project
Cost

A. HOUSING
1

New in-situ

2

Up-gradation

3

Rental

4

Transit
Total Housing Cost Sub Total (A)
B. INFRASTRUCTURE

1
(i)
(ii)
(iii)

Roads
BT Road
CC Road
Interlocking Block

(iv)

Culverts

2

Water Supply

(i)

UGSR

(ii)
(iii
)
(iv
)
3

SR
Pipeline (Rising Main
& Distribution)
Pump station & tube
well
Storm Water
Drains
Onsite drain &
Culvert
Sewerage

(i)
4
(i)
5
(i)
6

Pipeline (Main trunk
line & distribution)
and STP
Street Lighting
HT/LT / supply line
works / street light
pole and transformers
Solid Waste
Management

24

Apprais
ed
Project
Cost

Central
share

State
Govt.
Share

ULB
Share

(Rs in
lacs)
Beneficiar
ies Share

<!-- page 30 -->

Guidelines for Preparation of Detailed Project Reports

Scheme
Component

7

Rain water
Harvesting

8

Social
Infrastructure

(i)
(ii)

Parks / boundary wall
/ horticulture
Community Hall cum
Women Training
Centre

(iii)

Livelihood center

(v)

Health Facility

(vi)

Education Facility

(vii
)

Social Security
Provision

Type

Qty.
in
Nos
.

Rate
(in
Rs/U
nit)

Propos
ed
Project
Cost

Apprais
ed
Project
Cost

Central
share

State
Govt.
Share

ULB
Share

(Rs in
lacs)
Beneficiar
ies Share

Any Other
Sub Total (B)
Total (A+B)
Ratio of Housing to Infrastructure
C Operation and Maintenance Cost
* O&M up-to 4% of
project cost
Sub Total (C)
Sub Total
(A+B+C)
1
2

D Other Cost
*DPR Preparation,
PM, TPIM, Social
Audit charges
Contingencies etc.
Sub Total (D)
Grand Total (A+B+C+D)

* These charges will be shared between Central and State Government as per applicable sharing pattern

Signature of the
ULB Level
Competent
Technical Officer
Name &
Designation:
Address:
Fax No:
Telephone No.
Mobile No:
E-mail:

Signature of the
CEO/Commissioner of ULB/
Implementing Agency

Signature of the State
Level Competent
Technical Officer

Name & Designation:

Name & Designation:
Address:
Fax No:
Telephone No.
Mobile No:
E-mail:

25

Signature
of the State
Level Nodal
Officer

Name &
Designation:

<!-- page 31 -->

Guidelines for Preparation of Detailed Project Reports
Annexure - D - Undertaking
(To be signed by ULB and SLNA)
Name of Project: ________________
Project Cost
: Rs _______ lacs
1.
2.
3.

4.

5.

6.

7.

Title of the project land is clear and under the possession of the Urban Local
Body/State Government/Beneficiary.
Land use is residential i.e. in conformity with the Town Planning norms. & the
land is free from all encumbrances.
The estimates have been prepared as per applicable departmental SOR along with
current cost index (if required) certified by competent authority .The estimates
have been signed by the competent Engineer of the ULB and State. The quantity
and estimate calculations as included in the DPR conform to the proposed design /
plan with due adequacy & correctness of design.
Certified that all statutory approvals (such as Environmental clearance, Fire
fighting, Town Planning approval, etc.) as applicable have been obtained from the
competent authorities and project components have been designed in line with the
applicable Municipal Byelaws.
This is to certify that necessary measures will be taken by the Urban Local Body for
safeguarding the spaces from further encroachment. The organized green
spaces/play grounds/public open spaces shown in the layout plan of the slums
shall be developed/ maintained by the ULB.
That the houses not taken up in the project are pucca in nature, i.e. structurally
sound with safe foundation & RCC roof and adequate natural lighting & ventilation
having individual toilet and individual tap water supply connection.
Slums covered under the scheme shall be de-notified after implementation of all
development works and construction of new houses.

8.

Allotment of dwelling space shall be made in the name of the wife or in the joint
name of wife & husband of the identified beneficiary.
9. Whole slum approach has been adopted while formulating the slum development
plan. All Katcha (Temporary) and semi pucca (Semi permanent) houses have been
addressed and taken up for reconstruction/ up-gradation. It is ensured that all the
basic infrastructure facilities i.e. water supply; sewerage, roads, drains, solid
waste management, electrification, etc. have been provided. Other social
infrastructure facilities like health, education and other community facilities have
been adequately provided / converged with existing schemes.
10. Beneficiaries have given their consent for implementation of the project as
proposed in the DPR. All the Beneficiaries have confirmed their willingness to
contribute their financial contribution for the Dwelling Units as proposed in the
DPR.
11. The beneficiary contribution proposed is minimum 12%( Gen Category)/10%
(SC/ST/BC/OBC, PH & Other weaker sections) of Dwelling unit cost. In case of
higher contribution it is certified that the EMI burden (bank/soft loan) does not
exceed 25% of monthly income of beneficiary household.

26

<!-- page 32 -->

Guidelines for Preparation of Detailed Project Reports
12. The project will be implemented in ….. months from the date of sanction from
Govt. of India.
13. All procurement shall be done through a transparent Bidding Process in
conformity with guidelines of the State Govt.
14. Required basic infrastructure (water supply, sewerage, roads, drains, solid waste
management, electrification) are provided at site through integration with city
level network / independent system and in line with master plan.
15. Although comprehensive infrastructure facility within the slum area, covering all
the slum dwellers has been proposed in the DPR, however if any part/component
is left uncovered that will taken up by the ULB from its own resources and no
further demand of funds will be placed with MoHUPA, Govt. of India, for this
purpose.
16. Operation and Maintenance of the assets created (housing and infrastructure)
shall be done by ULB through involvement of beneficiaries/RWA.
17. ULB shall ensure adequate health and education facilities after assessing the
existing facilities in the nearby area of the slum. ULB shall also provide social
security to the beneficiaries through ongoing schemes of State/Central
Government.
18. ULB undertakes to extend all necessary support in terms of manpower,
machineries etc. for smooth operation of all the social infrastructure facilities
proposed under the scheme including health & educational facilities as applicable.
19. The structural safety aspects of the buildings and infrastructure components
proposed in the project have been ensured by designing the as per the
requirements of National Building Code and relevant IS Codes and Manuals.
20. Undertake to constitute a beneficiary committee, which would supervise
construction at various levels; foundation, basement, lintel, roof, completion,
occupation etc. & undertake social audit of the site after completion of the project.
It is also undertaken to ensure quality control systems-both internal and external,
so that the constructions are undertaken with utmost quality.
21. Any escalation in the project cost would be borne by State Govt./ ULB.
22. The project components proposed in the DPR were never taken up / funded under
any Central/State or any other schemes.
Signature of the State Level Nodal
Officer

Signature of the
CEO/Commissioner of ULB/
Implementing Agency

Name & Designation:

Name & Designation:

Address:

Address:

Fax No:

Fax No:

Telephone No.

Telephone No.

Mobile No:

Mobile No:

E-mail:

E-mail:

27

<!-- page 33 -->

Guidelines for Preparation of Detailed Project Reports

Annexure – E - Admissible Components


Housing –
 New dwelling unit (Single story and / or Multi-storied) of carpet area between
21 to 27 sq. m. with two rooms, kitchen, bathroom, water sealed toilet and
individual potable water connection facility.
 Rental dwelling units of carpet area between 16-20 Sqm with shared civic
infrastructure. Rental DUs with carpet area between 21-27 Sqm are also
admissible in exceptional cases.
 Incremental housing - Up-gradation of existing dwelling unit by providing
additional room, kitchen & toilet (either or all). Central support will be limited
to carpet area of 21 to 27 sq. m.. Repair and renewal of existing dwelling units
will not be admissible.



Social Infrastructure –
 Anganwadi, Livelihood centre, Multi-purpose community centre, Library cum
Study centre, Training centre for computer programs with internet provision.
 Informal education centre, Urban health centres/sub-centres (only if funds are
not available from any other State/National schemes).
 Community parks, community toilet and cost of fixed play equipment if a
children‟s playground is being proposed.
 Shops/ kiosks, which are either owned by the State/ULB or by slum community.
 Lift well, Fire-fighting arrangements/equipment & parking



Basic Civic Infrastructure –
 Provision of roads, pathways, water supply, sewerage, drainage, solid waste
management, rain water harvesting, solar and streetlights/ cables, internet
cables etc. within the slum and up to the city-wide network.
 Temporary Transit housing.
 Retaining wall, Fencing and boundary wall.
 Animal pen, cattle/rickshaw /work sheds
 Site development including leveling and landscaping.

Note- There is an upper ceiling of Rs 5 lakh per DU for cities with population more than 5
lakhs. This ceiling would be at Rs 4 lakhs per DU for smaller cities with population less
than 5 lakhs. In North East (NE) and special category States, upper ceiling would be at
Rs 5 lakh per DU irrespective of population of the city. Upper ceilings, as above, would
also include cost of civic infrastructure and social amenities. Cost of civic infrastructure
and social amenities per DU should not exceed 25% of cost.



Other Charges O & M Cost up-to 4% of the project cost.
 DPR preparation, Project Management, Third Party Inspection and Monitoring
(TPIM), Social audit charges will be admissible.

(Note- These charges will be shared between Central and State Government as per
applicable sharing pattern)

28

<!-- page 34 -->

Guidelines for Preparation of Detailed Project Reports
Annexure- F - Mitigation measures against Hazards/Disasters
Type of Hazards/Disasters
Hydrological
Floods and
Hazards
cloud bursts

Mitigation Measures
 It should be ensured that the proposed projects
are not on flood plains.
 If the project area is prone to flooding then proper
remedial measures such as construction of
embankments should be ensured so that no
flooding occurs in project area.
Geological
Earthquakes
 Earthquake-Resistant Design should be ensured
Hazards
Landslides
for Construction of New Structures as per
Mudflow
National Building Code 2005 and other safety
Tsunami
codes.
 Undertaking
mandatory
technical
audits
of
structural designs of major projects by the
respective competent authorities.
 Use of various on-site, in-situ technologies, as
well as satellite observations in monitoring
landslide effects and contributing factors for
early-warning purposes
 Forecasting and providing early warning of
adverse conditions likely to lead to landslide
activity
 Strengthening capacities of communities and
local institutions to cope with landslide hazards
 Preparing contingency recovery plans, including
pre-positioning
of
technical
manpower
and
material resources for likely landslide events
 Mountain conservation methods, including soil
conservation, forest and watershed management,
and appropriate land-use techniques
 Restricting
inappropriate
development
in
landslide / Mudflow prone areas
Human
Terrorism,
 Trash cans and garbage disposal units should be
induced
Industrial and
located as far away for the building as possible,
Hazards
Chemical
with least 10m stand-off at distance.
accidents,
 Parking lots should be located away from highGas leakages
risk buildings to minimize blast effects of
potential vehicle bombs.
 Proper warning system should be placed in
nearby industries for alerting inhabitants in case
of industrial disaster.
Meteorologic
Cyclones,
 The history of meteorological hazards at the
al Hazards
floods,
proposed site should be analysed. In case area is
(Climate and Tropical
prone to
meteorological
hazards
then
risk
weather
storms,
awareness and assessment; early warning systems
related)
Drought,
including forecasting, dissemination of warnings,
climate
preparedness measures and reaction capacities
change
should be properly planned..

29

<!-- page 35 -->

Guidelines for Preparation of Detailed Project Reports
Type of Hazards/Disasters
Atmospheric
Excess rainfall
Hazards
,
Heavy
snowfalls,
High
wind
speeds
Extreme
temperatures

Threats
to
Municipal
Water
Supply
and
storage.
Fire

Other
Measures

Mitigation Measures
 Proper sloping roofs shall be provided in areas of
heavy snowfall and rainfall
 Proper analysis of snow load shall be done in case
of snow fall areas.
 The buildings shall be designed to withstand wind
loads
 Proper insulation materials shall be used in case
of places with extreme temperatures with due
consideration to height of roof and provision of
ventilation.
 Access to water storage tanks and water treatment
plants, through manholes, must be securitycontrolled to prevent deliberate attempts of
contamination.
Also,
regular
inspection
and
testing must be undertaken to ensure that
waterborne are not introduced
 Flammable fuel storages shall be located at a
distance of at least 30m from public access areas,
like entrances parking lots and material loading
areas. Also, access to these areas must be
restricted and always under lock & seal. In a hilly
terrain site, such storages should be placed
downhill of the operational buildings and critical
facilities.
 Common
escape
routes
including
staircases,
lighting facilities should be provided so that
people are able to move within the escape route
from a building during the hours of darkness.
 Proper arrangement for extinguishing fire such as
sand buckets, Fire hydrants and other fire
extinguishers shall be provided.
 Communication
systems
based
on
different
technologies and/or networks shall be put in place
for communicating within the slum and outside.
All communication system equipment and cables
shall be adequately concealed and protected.
 Strengthening
disaster
preparedness
of
all
stakeholders
 Promotion and strengthening of monitoring and
warning systems

30

<!-- page 36 -->

Guidelines for Preparation of Detailed Project Reports
Annexure – G – Modified NBO Formats
(Annexure-II of modified NBO format)
DETAILED HOUSEHOLD SURVEY
I. GENERAL INFORMATION
1. Name of Slum
2. Location - Ward No/Name
3. House/Flat/Door No.
II. HOUSEHOLD LEVEL GENERAL
INFORMATION

4. Name of head of the

family
5. Father‟s name
6. Sex [Male: 01, Female: 02]
7. Caste
[General-01, SC-02, ST-03, OBC-04]
8. Religion
[Hindu-01, Muslim-02, Christian-03, Sikh-04, Jainism-05,
Buddhism- 06, Zoroastrianism-07, Others-49]
9. Minority status (in State/UT)
[Non-minority-01, Minority- 02]

10. If female-headed household then status of female head

Married-01

Widowed-02

Abandoned/Single-03

Divorced-04

Unwed mother-05

Other-49
11. Number of family members

Male
Female
Total

12. Number of illiterate adult members
(Age more than 14 years)

Male
Female
Total

13. Number of children in age-group

Male

31

<!-- page 37 -->

Guidelines for Preparation of Detailed Project Reports
6-14 not attending school

Female
Total

14. Number of handicapped persons

Physically
Mentally
Total

15. If, major earning member is female, whether

Married-01

Widowed-02

Abandoned/Single-03

Divorced-04

Unwed mother-05

Other-49
16. Is your family below poverty line?

Yes-01

No-02

Don‟t know-99
17 a. If 01 in 16, does the family possess BPL card?
17 b. Does your family possess any identification document?

Yes-01

No-02
If 01 in 17 b, specify the type of documentation
Voter I Card-01, Ration Card-02, Electricity Bill-03, Water Bill- 04, Telephone Bill- 05,
Driving Licence -06, Bank Account -07, Passport-08, Aadhar Card-09, Any Other-49
III. HOUSEHOLD LEVEL DETAILED
INFORMATION
18. Land tenure status
[Patta-01, Possession Certificate/Occupancy Right-02,
Private Land Encroached -03, Public Land Encroached -04
Rented – 05, Other-49]
19. Type/structure of the house
[Pucca-01, Semi-Pucca-02, Katcha-03]
20. Type of roof
[Grass/thatched-01, Tarpaulin-02, Wooden -03,
Asbestos/Steel Sheet-04, Tiled-05, CC Slab-06, StoneSlab-07, Other- 49]
21 a.. Type of flooring
[Mud-01, Brick-02, Stone-03, Cement-04, Tiles-05, Other-49]
21 b. Size of existing dwelling unit (built up area in sq meters)

32

<!-- page 38 -->

Guidelines for Preparation of Detailed Project Reports
22. House lighting
[Electricity connection-01, Kerosene-02, Firewood-03, Other-49]
23 Fuel for cooking
[Gas-01, Electricity-02, Kerosene-03, Charcoal-04, Firewood-05, Other-49]
24a Source of drinking water
[Within premises- Tap-01, Tubewell/handpump-02, Open well-03]
[Outside premises- Public tap-04, Tube well/Bore well/Hand pump-05, Open well–06,
Tank/pond-07, River/Canal/Lake/Spring -08, Water tanker–09, Other-49]
24b If piped water supply then duration
[Duration of water supply: Less than 1 hour daily -01, 1-2 hrs daily-02, more than 2 hrs
daily - 03, once a week - 04, twice a week – 05, not regular - 06, no supply - 99)
25. If outside premises, then distance from drinking water source
[Less than 0.5 kms -01, 0.5 to 1.0 km.-02, 1.0 km to 2.0 km. - 03,
2.0 km to 5.0 km. -04, more than 5.0 km.-05]
26. Existence of toilet facility
[Own septic tank/flush latrine-01, Own dry latrine-02, Shared
septic tank/flush latrine - 03, Shared dry latrine-04, Community
septic tank/flush latrine-05, Community dry latrine-06, Open defecation-07]
27. Bathroom facility
[Within premises -01, Outside premises-02, Community bath -03
No bathroom-04]
28. Road in front of house
[Motorable pucca -01, Motorable katcha -02,
Non-motorable pucca -03, Non-motorable katcha-04]
29. Type of pre-school available
[Municipal - 01, Government - 02, Private-03]
30. Type of primary school available
[Municipal - 01, Government - 02, Private-03]
31. Type of high school available
[Municipal - 01, Government - 02, Private-03]
32. Type of health facility access
[Primary Health Centre – 01, Government Hospital-02
Maternity Centre-03, Private Clinic-04, RMP-05, Ayurvedic Doctor/Vaidya-06]
33. Access to welfare benefits by any family member
[Old Age Pension – 01, Widow Pension – 02, Disabled Pension – 03
Health Insurance – 04, General Insurance – 05, Other – 49]
34. Consumer Durables [Yes-01, No-02]

Electric Fan

33

<!-- page 39 -->

Guidelines for Preparation of Detailed Project Reports



Refrigerator



Cooler



Residential Telephone



Mobile Phone



B/W Television



Colour Television



Sewing Machine



Furniture



Bicycle



Rickshaw



Push Cart



Bullock Cart



Two Wheeler



Three Wheeler



Taxi/Car



Car

35. Live Stock [Yes-01, No-02]

Buffalo


Cow



Sheep/Goat



Pig



Hen/Cock



Donkey

IV. MIGRATION DETAILS OF HOUSEHOLD, If
applicable
36. Number of Years of Stay in this Town/City
 0 to 1 year -01,
 1 to 3 years- 02,
 3 to 5 years- 03,
 More than 5 years-04
37 a. . Whether Migrated from:
[Rural Area to Urban Area: 01, Urban Area to Urban Area: 02]

34

<!-- page 40 -->

Guidelines for Preparation of Detailed Project Reports

37 b. If 02 in 37, then whether the family owns a house in any city in the
country
38. Migration Type [Seasonal-01, Permanent-02]
39. Reasons for Migration

Unemployment-01

Low wage-02

Debt-03

Drought-04

Conflict-05

Education -06

Marriage-07

Others-49
IV. INCOME-EXPENDITURE DETAILS OF
HOUSEHOLD
40. Number of earning adult members

Male
Female
Total

41. Number of earning non-adult members

Female
Total

Male

42. Average monthly income of household (in Rs.)
43. Average monthly expenditure of household (in Rs.)
44. Debt outstanding as on date of survey

(in Rs.)

45. Signature/Thumb Impression of Head of Household

35

<!-- page 41 -->

Guidelines for Preparation of Detailed Project Reports
(Annexure-III of modified NBO format)
DETAILED LIVELIHOODS SURVEY
I. Details of Earning Members of the
Household
1. Earning Members:
1a: General Details
Sl.
Name
No.
1

2

Relation
to Head
of Family
3

Age

Sex
(code)

Caste
(code)

5

6

4

Religion
(code)
7

Sex (Code): Male: 01, Female: 02
Caste (Code): General-01, SC-02, ST-03, OBC-04
Religion (Code): Hindu-01, Muslim-02, Christian-03, Sikh-04, Jainism-05, Buddhism06, Zoroastrianism-07, Others-49
1b: Education & Training
Educational Qualification (Code)

Skill Training Acquired
(Code)

8

9

Type of institution from
whom skill training
received (Code)
10

Educational qualification (Code): No education – 01, Primary school – 02, Middle
school – 03, Matriculate – 04, Certificate – 05, Diploma – 06, Graduate – 07, Postgraduate – 08, Technical (e.g. Engineering) – 07, Any Other - 49
Skill training acquired (Code): Pre-employment Training – 01, In-Service Training –
02, Skill Upgradation – 03, Apprenticeship – 04, Soft Skills/Life Skill Programme - 05,
Entrepreneurship - 06, Hereditiary-07, Any Other – 49, No skills training – 99
Type of institution from which skills training acquired (Code): ITI – 01,
Polytechnic – 02, Vocational schools – 03, Technical Schools/Institutes – 04, Any Other –
49
1c: Employment & Earnings

36

<!-- page 42 -->

Guidelines for Preparation of Detailed Project Reports
Employment status
(Code)
11

Place of work
(Code)
12

Time of work
(Code)
13

Monthly earning
(Code)
14

Employment status (Code): Self-employed (01), Salaried (02), Regular wage ((03),
Casual labour (04), Others (05)
Place of work (Code): Within the slum area – 01, Outside the slum area: within distance
Less than 0.5 kms - 02, 0.5 to 1.0 km.- 03, 1.0 km to 2.0 km. - 04, 2.0 km to 5.0 km. -05,
more than 5.0 km-06
Time of work (Code): Whole day- 01, Half day-02, Part time-03, 3 Months in a year- 04,
6 Months in a year-05, Whole year-06
Monthly earning (Code): Less than Rs. 500 – 01, 500 to 1000 – 02, 1000 to 1500 – 03,
1500 to 2000 – 04, 2000 to 3000 – 05, More than 3000 - 06
2. Source of earning/ livelihood (code):
Male earners: Primary occupation
Secondary occupation
Female earners: Primary occupation
Secondary occupation
Unskilled Labour: Agriculture/horticulture - 01, Hawking/street vending - 02,
Domestic servant - 03, Sanitation worker- 04, Rigpicker - 05, Watchman - 06,
Construction worker - 07, Industrial worker - 08, Contract worker - 09, Casual Labourer 10.
Skilled Labour: Electrician -11, Electronics gadget repairing – 12, Plumbing – 13,
Tailoring - 14, Weaving – 15, Artisan / craftsman/ handicraft and cottage based production
work -16, Beautician, hairdressing & related work – 17, Driving – 18, Auto repair/motor
mechanic work –19, Mechanical engineering related works – 20, Chemical engineering
related works – 21, Shoe-making/leather-related work - 22, Photography and related work
– 23, Work related to childcare, nutrition, pre-schools and crèche-24, Health and
paramedical services related work - 25, Office related work – 26, Printing related work 27, Hotel and restaurant related work - 28, Tourism related activity - 29, Security-related
work – 30, Computer-related work – 31, Creative arts / artists – 32, Laundry related work
- 33, Toy-making - 34, Candle-making - 35, Artificial jewellery -36, Embroidery/knitting 37, Cooking-38, Bakery - 39, Mason - 40, Carpenter-41,
Painter-42 Food
processing/preservation-43

37

<!-- page 43 -->

Guidelines for Preparation of Detailed Project Reports
Other Profession: Petty trader-44, Rickshaw puller – 45, Cycle-rickshaw driver-46,
Pushcart driver-47, Auto Rickshaw driver - 48, Retail sale – 49, Pig/Poultry/ Cow/Buffalo
rearing -50, Others - 99
3. Main Reason for Unemployment of Unemployed Member
of the Household (Code):
Illiterate - 01, Lack of vocation skill - 02, Lack of job opportunity - 03, Disability - 04, Low
wage-05, Lack of capital to invest-06, Loss of earlier job-07, Closure of unit-08, Lack of
work in the enterprise (for self-employed person) - 09, Lack of work in the area (for casual
labour)-10, Lay-off without pay-11, Employer harsh-12, Health hazard-13, Other - 49
4. Preferred Area for Training/Skill Enhancement (Code)
Male earners: For Primary occupation
For Secondary occupation
Female earners: For Primary occupation
For Secondary occupation
Mechanical engineering trades-01, electrical and electronic engineering trades-02,
computer trades-03, civil engineering and building construction related works-04,
chemical engineering trades-05, leather related work-06, textile related works-07,
catering, nutrition, hotel and restaurant related work-08, artisan/craftsman/handicraft
and cottage based production work-09, creative arts/artists-10, agriculture and crop
production related skills and food preservation related work-11, non-crop based agriculture
and other related activities-12, health and paramedical services related work-13, office and
business related work-14, driving and motor mechanic work-15, beautician, hairdressing &
related work-16, work related to tour operators/travel managers-17, photography and
related work-18, work related to childcare, nutrition, pre-school and crèche-19, journalism,
mass communication and media related work-20, printing technology related work-21,
Tailoring /weaving – 22, Entrepreneurship Development Programmes-23, other-49
5. Suggestions regarding imparting of Training/Skill Enhancement
programmes

6. Suggestions regarding post-Training/Skill Enhancement programmes – Self
Employment, Market-based Employment etc.

************
38
