---
doc_id: "cfb54c7cae457ed1"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/ac57ea0e9c9eefb3af44f6facf1d9554.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of short code '155368' to State Health Authority to manage Call Centre for Ayushman Bharat Beneficiaries, PMJAY, Government of Uttarakhand-reg."
date: "2020-06-03"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "100306f26f73b591"
---

<!-- page 1 -->

File No.16-10/2018-AS-lll/ShortCodes

Government
Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No. 16-10/2018-AS-III/(Short Codes)/143/

Dated: 03/0612020

To,
All Access Service Providers,
Subject: Allotment of short code '155368' to State Health Authority to manage Call
Centre for Ayushman Bharat Beneficiaries, PMJAY, Government of Uttarakhand-reg.
The undersigned is directed by competent authority to state that short Code ' 155368'
is allocated to Department of Medical, Health & Family Welfare and Medical Education,
Government of Uttarakhand to establish call centre to provide medical treatment to the
Citizen under Ayushman Bharat PMJAY scheme with following features:
i. Category"'I: Service (i.e. mandatory service to be provided by all the Access
providers).
ii. Accessibility: Restricted i.e. with in state only.
iii. Metered Service: (It may be taken as Called Party Pays or Calling Party Pays
depending on intimation, to this effect, issued by the agency to which this short code is
allocated in furtherance to this DoT instruction).
2. All are requested to take necessary action.
3. This is issued with the approval of competent authority.

03.·0t.· ry:>rYo
(Sanchit
m Garg)
ADG (AS-III)
Copy forwarded for information and necessary action, if any, to:
1. Secretary, TRAI.
2. CMD MTNL/ CMD BSNL.
3.
Secretary, Department of Medical, Health & Family Welfare and Medical
Education, Government of Uttarakhand vide letter no. SHA/2020-21/Call Centre/165
dated 02.06.2020 shall appoint the nodal officer to implement the helpline. The Nodal
officer may contact Sr. DDG (LSA), LSA Unit, concerned States/UTs.
4. Director (P&N), DoT (HQ), (respective LSA field unit may be asked to co-ordinate
with respective Nodal Officers and TSPs for implementation of Helpline, as and when
approached).
5. A copy for upload on DoT Website.
