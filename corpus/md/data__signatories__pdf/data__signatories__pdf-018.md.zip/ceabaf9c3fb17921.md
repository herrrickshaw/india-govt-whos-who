---
doc_id: "ceabaf9c3fb17921"
source_url: "https://minorityaffairs.gov.in/WriteReadData/RTF1984/1745325813.pdf"
ministry: "Minority Affairs (MoMA)"
title: "THE MUSSALMAN WAKF (REPEAL) ACT, 2025 Notification"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "6984dbd3fdd61455"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-09042025-262384
xxxGIDHxxx
CG-DL-E-09042025-262384
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं.

1645]

No. 1645]

नई दिल्ली, बुधवार, अप्रैल 9, 2025/चैत्र 19, 1947
NEW DELHI, WEDNESDAY, APRIL 9, 2025/CHAITRA 19, 1947

अल्पसंख्यक कायय मंत्रालय
अजधसूचना
नई दिल्ली, 9 अप्रैल, 2025
का.आ. 1676(अ).— मुसलमान वक्फ (जनरसन) अजधजनयम, 2025 की धारा 1 की उपधारा (2) द्वारा प्रित्त
िजियों का प्रयोग करते हुए, कें द्र सरकार, 09 अप्रैल, 2025 से उि अजधजनयम के प्रावधानों का लागू होना जनधायररत
करती है।

[फा. सं. 12/3/2023-वक्फ]
िेरिा सी िेख मोजहद्दीन, संयक्
ु त सजचव

2451 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF MINORITY AFFAIRS
NOTIFICATION
New Delhi, the 9th April, 2025
S.O. 1676(E).—In exercise of the powers conferred by sub-section (2) of section 1 of The
Mussalman Wakf (Repeal) Act, 2025 (15 of 2025), the Central Government hereby appoints the 9 th day of
April, 2025 as the date on which the provisions of the said Act shall come into force.

[F. No. 12/3/2023-Waqf]
SHERSHA C SHAIK MOHIDDIN, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2025.04.09 18:42:30
+05'30'
