---
doc_id: "d0122eedeea34b1d"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/7a526790428ff842a9e46f60180a0700.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment No. 3 Changes in Annexure 2-A 1800 MHz Carriers"
date: "2015-02-05"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d57838e2e49214d5"
---

<!-- page 1 -->

Annexure 2-A, Amendment 3
Details regarding changes in 1800 MHz band Frequency Spots

(4 pages apart from this page)
(Changes in Andhra Pradesh, Gujarat, Kerela & Punjab LSA)

<!-- page 2 -->

1800
MHz
- Andhra
Details
ofBand
carriers
in the Pradesh
block size of 200 KHz
(in MHz)
Uplink
Downlink
A
1745.4
1840.4
1745.6
1840.6
1745.8
1840.8
1746.0
1841.0
1746.2
1841.2
1746.4
1841.4
1746.6
1841.6
1746.8
1841.8
1747.0
1842.0
1747.2
1842.2
1747.4
1842.4
1747.6
1842.6
1747.8
1842.8
1748.0
1843.0
1748.2
1843.2
1748.4
1843.4
1748.6
1843.6
1748.8
1843.8
1749.0
1844.0

19
Each carrier is associated with 200 KHz bandwidth (100 KHz on both sides) i.e. Carrier 1724.4 MHz is 1724.3-to-1724.5
Block A: Available in December 2015
19

<!-- page 3 -->

1800 MHz Band -Gujarat
Details of carriers in the block size of 200 KHz (in MHz)
A
B
C
D
Uplink
Downlink Uplink
Downlink Uplink
Downlink Uplink
Downlink
1828.0
1828.2
1720.8
1815.8
1859.6
1733.0
1733.2
1764.6
1733.4
1828.4
1721.0
1816.0
1764.8
1859.8
1733.6
1828.6
1733.8
1828.8
1734.0
1829.0
1734.2
1829.2
1734.4
1829.4
1734.6
1829.6
1734.8
1829.8
1735.0
1830.0
1735.2
1830.2
1735.4
1830.4

1
12
2
2
17
Each carrier is associated with 200 KHz bandwidth (100 KHz on both sides) i.e. Carrier 1724.4 MHz is 1724.3-to-1724.5
Block A: Entire Service Area except Ahmedabad, Jamnagar, Vadodara, Bharuch and Rajkot Districts
Block B: Entire Service Area except Ahmedabad, Jamnagar, Vadodara Districts
Entire spectrum available in December 2015

<!-- page 4 -->

MHzinBand
- Kerala
Details of1800
carriers
the block
size of 200
KHz (in MHz)
Uplink
Downlink
A
1746.4
1841.4
1746.6
1841.6
1746.8
1841.8
1747.0
1842.0
1747.2
1842.2

5
5
Each carrier is associated with 200 KHz bandwidth (100 KHz on both sides) i.e. Carrier 1724.4 MHz is 1724.3-to-1724.5

<!-- page 5 -->

1800
MHzinBand
- Punjab
Details of
carriers
the block
size of 200
KHz (in MHz)
Uplink
Downlink
A
1749.2
1844.2
1749.4
1844.4
1749.6
1844.6
1749.8
1844.8
1750.0
1845.0
1750.2
1845.2
1750.4
1845.4
1750.6
1845.6

8
Each carrier is associated with 200 KHz bandwidth (100 KHz on both sides) i.e. Carrier 1724.4 MHz is 1724.3-to-1724.5
8
