---
doc_id: "cd95cba3d19d1fe4"
source_url: "https://www.niti.gov.in/sites/default/files/2020-08/Manual-3.pdf"
ministry: "Planning (MoP)"
title: "Manual - 3 Rules & Regulation of NITI Aayog(Revised as on 31.07.2020)"
date: "2020-08"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "89068f983e40a346"
---

<!-- page 1 -->

manual -B “o
eS See a)
C Revitgol 9% Oh 3107-2020)——"
1.5 | Rules, @Title and nature of the | 1. Record Retention Schedule and
Regulations, record/manual/instructions Manual of Office Procedure,
Instruction | Gi)List_ of Rules, Regulations, | Central Secretariat.
Manuals and instructions manuals and records | 2. Extant Rules & Guidelines
records for issued by Ministry of Finance,
discharge of DoPT and other = Nodal
functions Departments
sein (0) (कार 0
OM (iv) Transfer Policy and Transfer con ताल en Pa pervices
Orders 2. Central Civil Services (CCA)
Rules, 1965,
3. General Financial Rules,, 1963
4. Delegation of Financial
Powers Rules, 1978,
5. Official languages (use for
official purpose of the Union)
Rules, 1976,
6. Official languages Act 1963 as
amended 1967,
7. Manual regarding the use of
official language Hindi.
8. Manual of Hindi Teaching
Scheme.
9. GPF (Rules), 1960.
10. Central Civil Services (LTC)
Rules, 1988.
11. HBA Rules.
12, Medical Attendance
Rules, 1944, .
13. Staff Car Rules.
14. Central Civil Services (Leave)
Rules, 1972.
15, Central Civil Services
(Pension), 1972.
16. Disciplinary Proceedings for
Central Government Staff,
17. Fundamental Rules and
Supplementary Rules.
18. Extant Rules & Guidelines
issued by Ministry of Finance,
DoPT and other पत्ता
Departments.

<!-- page 2 -->

—

a, fy). The rules, regulations, instructions, | The tules/regulation etc. as applicable to Central
| manuals and records, held by it or Government Employees/All India Service Officers
ats under its control or used by its and ena Govern Offices hg flee fcr

i i ina i i lischarging of its unctions. selection,
& 5 5 employees for discharging its functions appointment of contractual engagement for DMEO
a (lateral entry) are done by NITL Aayog. DMEO
adopted the rule and regulation of NITI Aayog. The
selection procedure of DoPT is followed for engaging
Government officers on deputation, selection of
consultants (lateral entry) and young professionals.
Many posts stand encadered for IES and ISS service
officers. DMEO is presently in process of finalizing its
Recruitment Rules/guidelines. .

<!-- page 3 -->

| * leet The rules, regulations, |1.Records, Retention |https://darpg. gov in/sites/default/files/RR

instructions, manuals and | schedule S_WC.pdf
| records, held by it or under
its control or used by its _2.Guidelines for https://evisitors.nic.in/PublicSite/Candid
employees for discharging applying temporary ateLogin.aspx(Temporary) |
its functions, and permanent pass
7 https://validation.mha.gov.in/

| (Permanent)
