---
doc_id: "d0bc01c82cbd1aad"
source_url: "https://financialservices.gov.in/sites/default/files/Order-Notices/2026-06/Notification-dated-11.06.2026---Member-of-DC-of-IAI.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "Notification-dated-11.06.2026---Member-of-DC-of-IAI.pdf"
date: "2026-06"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c8f940a60fb73d33"
---

<!-- page 1 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART-II, SECTION 3,
sUB-SECTTON (ii)l
(iovcrnment of lndia
Ministry, of Finance
(Department of Financial Sen ices)

NOTIFICATION
New Delhi, the I 1rh Jurne" 2026

S.O.------.

In
- exercise of the powers conferred by sub-section ( I ) trf scction 26 of
thc Actuaries Act. 2006 (35 of 2006). the Central Government" hcreby norninates Sl-rri
Dchasish Prusty, Additional Secretary" Depaftnrent of F'inancial Services as a nrember of tlrc
Disciplinary Conrmittee constituted by the Council of the Institute of Actuaries of Irrdia tcr
represellt the Ministrv of l"inance. with immediate effect ancl until further orclers ,ic.e Shri
I)arshant Kttmttr Goy'al, erstwhile. Joint Secretary. Depanment of Financial Services.

[F. No. A-l l0l 310312024-Ins.Il

hLt

(r#^-

(ABDUL GUFRAN)
Under Secretary to the Government of India

Copy to:
1. Shri Debasish Prusty, Additional Secretary, DFS
2. Shri Parshant Kumar Goyal, erstwhile Joint Secretary, DFS
3. P.S. to F.M. / PS to MoS (Finance)
4. Sr. PPS / PPS to Secretary (FS)
5. All Joint Secretaries/ Economic Advisors / DDG, Department of Financial Services
6. chairperson, Insurance Regulatory and Development Authority of India
7. CEO & MD, Life Insurance Corporation of India
8. President, Institute of Actuaries of India
9 . Chairman-cum-Managing Director, AIC ILIGIC-Re/I{IACLAIIC L/OICLTIICL
10. Chief Executive, General Insurance Public Sector Association, New Delhi
I l. NIC cell, with a request to upload the order on the website of DFS
12. Guard File

<!-- page 2 -->

(l{r'td + {rqq{, 3r{rTrrRur. qpr ll, qg 3, 3rcrg (ii) ii rmRrffi)
rrr(d qfs, t

fuf,{*rdq

ffifuG'qrI
{ift-d, il Tr,2026
erlelsr{I

trr.arr.- mqi+-+' 3firfi-qq, 2006 (2006 i6r 35) ff qrr 26 ff 3c?no (r) Era v{f, {rftF{ii 6I s+,r *.d
qfuE, m Ms
$ *1 frd d*ro-q qr cftffFrca
Eq, ffi sc+n, ca-qm, ffiq M tqrnrr * 3{q(
6d + fr q rrrcdq dqir6 rierr+ * qft q< enrrEa nmea vffi * s<e * sq {, f+ftq fu foTr.r
+ ft*ld-{ sg6 sFq, * qrri6 +'qR r}+o * em q<, a-o, s vr+re t 3fu qtrd 3Trm nu, qrftd *-rfr
tt

(I6r.ri c- l, o, 376372924-*cr-r)

rylJ'nu-n(e-<dxwFI)
srqt (fud, r{rd qfsR

cftfrfr:

r. fMsYe1,3{crsf€,dqsqs
z. fr qYridq'cr ril+o, $ rig6 qk{, Sqsqs
:. t+tqfi * Frd qfu{ r fuf, {cq {* + ffi qi{d
a. sfoe GsqO * sftBfimss^Amsq
s. ffiq fu frr+r,r + {rff sg6 sk+s{rF}s s-dr6*,r/*ffi ,
6. qtirqr, ff(fiq *qI frfiqrq-+ sfu ft-c.-rg qrFr6{uT

7 rrr.iftqfi++frqr frqq+*&fr *(siqfthr*
a. s+aqr, rrrfrq *qis-d {ern

s. 3rq{-q6-erirrfitvm, qs{r$Sqriqd,ftftHtA'+qriqdq{r,(,caTr{Swsfu {r{dqF&3Trt3{r€dqm
l 0. qcq Er+srfi , sRtI Mis cks fuEt qdft\,yrc, Ti

frd

r r. r'+qrid+d,

r2. rne$T{d

dqsqs6taqr€q{ siidtsn-*e6(}* o1+nu*uu
