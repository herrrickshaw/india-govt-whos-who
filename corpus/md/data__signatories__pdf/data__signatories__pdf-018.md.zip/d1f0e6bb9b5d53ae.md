---
doc_id: "d1f0e6bb9b5d53ae"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/11ece25caf66f866d5fdcfd5c708b7bd.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification regarding Pneumatic Tyres and Tubes (Amendment) - 09 November 2010"
date: "2025-07-14"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "87be25e432637d21"
---

<!-- page 1 -->

~
--.'

~omo~o-33004/~9

~~
(~F)-r

'(l:he ([Ja~ett

.

e of

~~I~I~UI
EXTRAORDIN,J.RY
'qT1T
IJ-~
~-~
(ii)

PART II-Section 3-Sub-section (ii)

~.i~~J{~ ~~I~'~
PUBLISHEDBY Aurnol..n-y

~---

23301

:=--~.
'i'I("1q.~,~

~~,

~:~330J

~IIUI~ 3tft: ~

q~l~q

(~~.~~)
~

"Of{~i

2010

~ ~i.!~ ~

~
~

OF COMM.ERCE

(Department

of Industrial

S.Q. :2758(E).-.In

';!;1{U
~ ~-~

~

~

~~U::r

(~"ITFd

~ a:t~~.

~--),-~.,!:_~~~if

MINISTRY

AND INDUSTRY

Policy and Promotion)

New Delhi, thc 9th November, 2010

~.1986

(193:;~ 63)~ I-mT14mu~Hm'~~~~

~J~~~

18,1932

ORDER

9~,

~.3tT.27$8(St).-~~~

f4'qllr:i1T~

9, 201C,/~,ffl~18, 1932

~E~ DELHI, TUESDAY.NOVEMBER!~OIO/K~

-cf;
~

"if;T.01L
2953 (31)

lif+"1i~I~{J
~

~

t,

~: ;-

exercise of powers conferred by

S~ction 14 of the Bureau of Indian Standards Act, 1986
(63 ,")f 1986), Lhe Central Government after consulting the
Bureau 01' Indian Standards hereby makes the fulluwhlg
amcndment irt thc notification of the Government ofIndi~
in the Ministry of Commerce and Iodustry (DepirtlnCDt of
tn~~1
Policy and Promotion) No. 8.0. 2.953(E). dated
the 19th Novem-bei'~-';OW. .nmne1y~~

~q;.~

I .q;.~-~

(2) if"360~"

~~ q;) "540 "R;r" 3iCfiq ~

~~

ID sub-clause (2) of Clause I of the Order, for the

m ~1(1~11'i6
~

figures and word "360 days" the figures and word
"540 days" shall be ~ubstituted.

~I
["qiT.
~. 16(72)12005~ 31!\J

~~,.~

fl;afIJT:~
31f~
~ ~ ~
(~)
if
.19 ~,
2009-t ~.3{t. 2953(:sr.)~ ~ ~
~
~
11 oq"{,
2010~ -q1t31T.
1057(31)

~~~;1f~t

~ndia
ROOD.

NO.D.
--- L.-33OO4m

(F. No. 16(72YlOO5-LR]
RENUSHARMA,

It. Secy.

Note :- The Principal notification was issued in the Gazette
of India (Exrraordi11ary) vide S.O- 2953 (E) dated
the 19Lb November
2009 and subsequently
amcndedvidcS.O.
lO57(E) dated l1thMay,201.0.
