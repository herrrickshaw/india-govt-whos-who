---
doc_id: "d0fa8fb5a10f8da4"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/b1127444c8fdc4d2e89df83ad51d5cd3.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "E-tender for purchase of 200 MT White Butter"
date: "2020-10-06"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "aeb699ec2edbba3f"
---

<!-- page 1 -->

SHORT E-TENDER ENQUIRY
No. A-12003/1/2020-21/Proc/WB/02

Government of India

Delhi Milk Scheme
West Patel Nagar

New Delhi-1 10008

Date: 05.08.2020
To,

All State Dairy Federations, NDDB/ Mother Dairy and Government sources
Subject: ‘E’ tendering for purchase of 200 MT White Butter by Delhi Milk Scheme.

Delhi Milk Scheme is Central Government Organization under Department of Animal Husbandry &
Dairying, Ministry of Fisheries, Animal Husbandry & Dairying, Gol engaged in supplying high quality milk
and milk products to the citizens of National Capital and intends to purchase the following material from
State Dairy Federations, NDDB, Mother Dairy & Govt. sources only. Dairy Federations, NDDB, Mother Dairy & Govt. sources only.

S.No. Description of Material Quantity required
1. White Butter manufactured not before 200 MT

February, 2020 & as per BIS standards made

from mixed milk.

2 On Line Rates/ Offer : Your online rates / offer indicating the quantity of White Buller Tor supply online rates / offer indicating the quantity of White Butter for supply

to this office, price payable per kg (for 82% Fat on pro — rata basis) F.0.R. DMS Godown (including taxes,

transportation, insurance, loading/unloading etc) along with delivery schedule should be uploaded well

before the closing date of e-tender. Manual offer shall not be accepted.

3. Offer Validity : Your offer / rate should be valid upto 05.09.2020,

4. Product Quality : White Butter should be as per BIS Standards made from mixed milk and

manufactured not before February, 2020.

5. Quality Inspection: Pre delivery inspection may be carried out by DMS Quality Control Team

before supply of consignment as per DMS requirements. However, final inspection shall be carried out at

Delhi Milk Scheme and shall be considered as final.

6. Quantity : DMS shall have the option to increase/ decrease the above quantity upto 50% at the same

rates, terms & conditions. However, it is compulsory for bidders to offer at least 150 MT of White Butter

against tendered quantity, failing which, their bid shall be treated unresponsive and will be rejected

summarily.

te Delivery Period : Delhi Milk Scheme being Central Govt. Organization is supplying milk & milk

products to the Parliament of India, Hospitals, Defence Installation, institutions etc. Hence Delivery Period is

the essence of the contract / purchase order which must to be adhered to.

8. Tender Opening : Tender Enquiry containing terms & conditions can be downloaded from Central

Public Procurement — Portal website i.e. eprocure.gov.in/eprocure/app from 05.08.2020 to 19.08.2020

(upto 14.00 PM). Your online tender offer alongwith terms & condition shall be accepted upto 14:00 PM till

19.08.2020 and shall be opened next day on 20.08.2020 at 14:00 PM. No manual rates offer shall be

accepted. Scan copy of your Tender Offer alongwith terms & conditions (.pdf) and financial bid (.xls) may be

uploaded/ placed appropriately on aforesaid CPP-Portal before due date & time.

You may also visit DAHD website i.e. www.dahd.nic.in aes
(Jitendra Kumar)
Manager (Proc)
Telephone/Fax: 01 1-20838134
