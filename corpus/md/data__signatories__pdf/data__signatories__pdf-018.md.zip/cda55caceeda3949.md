---
doc_id: "cda55caceeda3949"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/8b9c8c8a3f962e6722dff9d364c39330.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Appointment of Young Professional in Salt Commissioner's Organisation an office under DPIIT"
date: "2025-07-09"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0fab52057badab48"
---

<!-- page 1 -->

.
ADVERTISMENT FOR YOUNG PROFESSIONALS (LAW)

Department for Promotion of Industry and Internal Trade (DPIIT) invites application for the
position of Young Professional (Law) from the candidates who are keen to demonstrate their
proven academic, credential, professional achievements, leadership qualities and legal
valuation.
The criterion to apply in this programme is as under:-
1 Eligibility

1.1. Minimum Qualification : LLB

1.2 Age limit: Candidate should be below 35 years of age as on 1* July 2021.

1.3. Experience: The candidate should have minimum one year work experience at

the time of application.

2 Remuneration: A consolidated amount of Rs.40, 000/- per month (minus

Professional Tax/TDS as applicable) will be paid. There shall be annual increase of

Rs.2500/- subject to satisfactory performance.

3 No. of YPs required and the place of posting-

Jaipur = - One

Mumbai - Four

Chennai - Three
4 Work Description and Responsibility: - The selected Young Professionals will be
responsible for drafting proposal, exploring existing policies, law, rules and regulation and
suggest course of action to protect Government interest in court matters. They will be working
under the concerned Assistant Salt Commissioner/Deputy Salt Commissioner/Salt
Commissioner.
5 Rotation- Depending on the requirement and candidate’s personal skills, they can be
rotated from office/region to other office/region/headquarter of Salt Commissioner's
Organization (SCO), an attached office under DPIIT.
6 Period of engagement- The period of engagement would initially be for 1 year which can
be extended upto 3 years, one year at a time, on the recommendations of their respective
controlling officers. DPIIT may disengage any Professional after giving 15 days’ notice.
Similarly, a Professional can also disengage after giving notice for a similar period.
7 Working Hours/Leave: Working hours shall normally be from 9.30 AM to 06.00 PM during
working days including half an hour lunch break in between 1.30 PM to 2.00 PM. However, in
exigencies of work, they may be required to sit late and may be called on holidays also. They

<!-- page 2 -->

|
|
will be eligible for 08 days leave during the period of one year, subject to the approval of the
controlling Officer. Un-availed leave however cannot be carried forward to the next year.
8 Young Professional will be governed by the Official Secrets Act, 1923, as amended from
time to time; they shall not disclose any information/data that may be supplied to them during
the period of their engagement with SCO/Department to any unauthorized person(s). All such
documents will be property of the Government.
9 This is not an offer for employment in DPIIT and is solely directed towards providing
exposure to young and motivated professional to gain an understanding of formal work
environment, working of government and exposure to the industrial scenario in India, This
opportunity does not confirm any right to the Young Professional to any position or job in DPIIT
or any other wing of the Government on any preference in employment after this programme or
anytime in future.
10 DPIIT reserves its right not to engage any candidate in response to the advertisement
and this is only an invitation to young person (s) to apply for the position of Young Professional.
PROCEDURE FOR APPLICATION AND SELECTION
1. Application complete in all respect should reach SCO within 30 days from the date of
publication of this advertisement on DPIIT’s website (by post / by email). Any incomplete
application/s or application received after the specified date shall be summarily rejected.
2. Any false information in the application shall be liable to rejection and legal action against the
applicant.
3. Application should be signed by the applicant under his own hand.
4. No document needs to be attached with the application. Documents shall be verified at the
time of interview/presentation.
5. Complete application shall be sorted and shortlisted for calling suitable candidates for
presentation.
6. The application should be sent to:
Office of the Salt Commissioner
2-A, Lavan Bhawan, Lavan Marg,
Jhalana Doongari, Jaipur, Rajasthan - 302004.
Ph: 0141-2709568/2705821
Email :- lavan-ri@nic.in

<!-- page 3 -->

7. Candidates will be required to make a presentation about how well they understand the
working of Salt Commissioner's Organization (SCO) and how they can contribute towards the
same. They will be assessed on a scale of 0-100 on the basis of their academic performance
and their presentation to assess them on quality index.

8 The applicants are advised to provide email address for communication of date of
presentation and any other information to avoid delays through postal communication.SCO
SHALL Not be responsible for any non-communication or delayed communication due to postal
delays.

9. Selected candidates shall execute a bond in the format prescribed by the Department to the
effect that if they leave the position of Young Professional before completion of the term of
one year without giving notice of prescribed period, they shall refund SCO the entire amount
of remuneration received by them to Salt Commissioner Office.

10. For any query kindly mail us at (lavan-rj@nic.in)

<!-- page 4 -->

Pro-forma to apply for the post of Young Professional (Legal)
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry & Internal Trade

[Name (_ |

Father's Name Po ० ऑफ |

Mother's Name Paste your

Date of Birth Po atest photograph

|. '|

Email Address [| /$ ऑफ |
Educational Qualification (10" onwards)
Qualification institution [Year of passing | Percentage of _ | Remarks (|f any)

Imarks obtained
PT
[ ७ || झजऊ  ्््ेक_झऑ रईरर |
[  ्-र्ऱ्ेछ /  €$_ ््ऊऑऊऑ#£$ऋऋ |
Professional Qualification
Qualification Institution Year of passing | Percentage of | Remarks (If any)
marks obtained
[
| आस छ छा इस फहख&छ इज इज उस आ  -----तत--ह-----
[PT
Previous Experience (Give Details):
Whether possess basic knowledge of computer: Yes /No
Any other information:
Certification

॥ son/daughter of hereby certify that
the information provided by me is true and correct to the best of my knowledge and
my application can be summarily rejected if it is found incorrect at any stage. Further, | have
read the terms and conditions for above assignment and understood them.
pe | (Signature)}
[Name
