---
doc_id: "ced6cbefcce81b1e"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/cfde401966a6599157afe67328a32b20.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "List of amendments carried out in ILs/Registrations"
date: "2025-07-26"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "00bb475b51402482"
---

<!-- page 1 -->

List of Amendments carried out in Industrial Licences
During January 2001
-------------------------------------------------------------------------------------------------------------------------------S.No. Name of the Company
IL.No.&Date
Amendments carried out
No.&Date
-------------------------------------------------------------------------------------------------------------------------------1.
M/s.Flowerserve Sanmar Limited
CIL:14(76)/2001
Change of name of the Company
CIL:14(76)/2001-Amend
Chennai
17.1.1976
from M/s.Durametallic Sanmar Ltd
Dt:19.1.2001
to M/s.Flowerserve Sanmar Limited
2.
M/s.E.I.Dupont India Ltd
CIL:14(95)/2001
Transfer of Industrial Licence from
CIL:14(95)/2001 -Amend
Gurgaon
1.2.1995
M/s.Dupont South Asia Ltd to M/s.
Dt.15.1.2001
E.I.Dupont India Ltd
3.

The Statesman Fashion
Tirupur

IL:19(96)
22/27.11.96

inclusion of additional location in IL

IL:19(96)/2000-Amend
Dt:Jan,2001

4.

M/s.Bharat Explosives Ltd
Lalitpur,U.P

CIL:77(92)
28.8.92

Shifting of capacity from Lalitpur U.P to CIL:77(92)/2000-Amend
to Waidhan, Madhya Pradesh
Jan,2001

5.

M/s. Mattel Toys(India) Ltd
Nagpur

CIL:14(99)
18.3.1999

relaxation in export obligation

CIL:14(99)/2001-Amend
Dt.4.1.2001

6.

M/s.Sportking Synthetics
Ludhiana

CIL:8(99)
23.2.1999

Implementation of the Il in the name of
M/s.Sportking Processors

CIL:8(99)
Dt.16.1.2001

7.

M/s.Stallion Garments

IL:83(2000)
7.11.2000

Amendment in the item of manufacture
and capacity

CIL:83(2000)/2000-Amend
Dt.5.1.2001

8.

M/s.Kirloskar Electric Co.
Bangalore

L/5(1)/N-40/59
dt.30.7.59
L/5(1)/142/EEI/67

3(24)/2000/IL
dt.8.1.2001

9.

M/s.Nahar Spinning Mills Ltd
Ludhiana

CIL:50(94)
19.5.94

Transfer of licence from M/s.Kirloskar
Systems Limited to M/s.Kirloskar
Electric Company Limited
15.11.67
inclusion of additional locations
in licence

CIL:50(94)/2001-Amend
dt.16.1.2001-03-05
