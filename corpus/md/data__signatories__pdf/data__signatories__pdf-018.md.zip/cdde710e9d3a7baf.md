---
doc_id: "cdde710e9d3a7baf"
source_url: "https://mohua.gov.in/static/uploads/2025/11/248102c93cf663a4654bc19216d62ef8.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Central Advisory Council Notification"
date: "2025-11-07"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "4ef2ef8b742a8202"
---

<!-- page 1 -->

MINISTRY OF HOUSING AND URBAN AFFAIRS.
New Delhi, the 20th November, 2017
S.O. 2666.—In exercise of the powers conferred by sub-section (1) of section 41 of the Real Estate
(Regulation and Development) Act, 2016 (16 of 2016) (hereinafter referred to as the Act), the Central Government
hereby appoints the following persons specified in the table below with effect from the date of its publication in the
Gazette, as members of the Central Advisory Council (hereinafter referred to as the Council), namely:—
TABLE
Hon’ble Minister of State (I/C), Housing and Urban | Chairperson (ex-officio) .
Affairs, Government of India
2. CEO, Niti Aayog, Government of India Member (ex-officio)
ah Secretary, Ministry of Housing and Urban Affairs, | Member (ex-officio)
Government of India
Secretary, Department of Revenue, Ministry of Finance, | Member (ex-officio)
Government of India
Secretary, Department of Economic Affairs, Ministry of | Member (ex-officio)
Finance, Government of India :
Secretary, Department of Industrial Policy and | Member (ex-officio)
Promotion, Ministry of Commerce and Industry,
Government of India
7 Secretary, Department of Consumer Affairs, Ministry of | Member (ex-officio)
Consumer Affairs, Food and Public Distribution,
Government of India
Secretary, Ministry of Corporate Affairs, Government | Member (ex-officio)
of India
Secretary, Department of Legal Affairs, Ministry of | Member (ex-officio)
Law and Justice, Government of India
| 10. _| Managing Director, National Housing Bank (NHB) Member (ex-officio)
ll. Chairman and Managing Director, Housing and Urban | Member (ex-officio)
Development Corporation (HUDCO)
Chief Secretary, Government of National Capital | Member (ex-officio)
Territory of Delhi
13. Additional Chief Secretary / Principal Secretary / | Member (ex-officio)
Secretary, Government of Uttar Pradesh (dealing with
implementation of the Act)
: . मे के "पाक. है.

<!-- page 2 -->

8920 THE GAZETTE OF INDIA : NOVEMBER 25, 2017/AGRAHAYANA 4, 1939 [PART II—SEC. 3(ii)]
14, Additional Chief Secretary / Principal Secretary / | Member (ex-officio)
Secretary, Government of Odisha (dealing with
implementation of the Act)
Additional Chief Secretary / Principal Secretary / | Member (ex-officio)
Secretary, Government of Haryana (dealing with
implementation of the Act)
Additional Chief Secretary / Principal Secretary / | Member (ex-officio)
Secretary, Government of Tamil Nadu (dealing with
implementation of the Act)
17. Chairman, Real Estate Regulatory Authority, | Member (ex-officio)
Maharashtra
Chairman, Real Estate Regulatory Authority, Gujarat | Member (ex-officio)
19. | Chairman, Real Estate Regulatory Authority, Madhya | Member (ex-officio)
Pradesh
20. | Chairman, Real Estate Regulatory Authority, Assam Member (ex-officio)
Chairman, Real Estate Regulatory Authority, Karnataka | Member (ex-officio)
22. President, National Real Estate Development Council | Member (ex-officio)
(NAREDCO) (New Delhi)
23. President. Confederation of Real Estate Developers | Member (ex-officio)
Association of India (CREDAI) (New Delhi)
President. Forum for People’s Collective Efforts | Member
(FPCE). Kolkata (West Bengal)
25. Chairman, Federation of | Apartment Owners | Member
Association (FAOA), Gurgaon, Haryana
Chairperson, National Association of Realtors - India | Member
(NAR-INDIA), Gurgaon, Haryana
27. Chairperson. Central Building and Other Construction | Member (ex-officio)
Workers Advisory Committee (or his nominee),
Ministry of Labour and Employment, Government of
India
28. Founder, Namma_ Bengaluru Foundation (or his | Member
nominee), Bengaluru Karnataka
Sano Wien, las ies Mania Mart
30. | Additional Secretary / Joint Secretary (Housing), | Member Convenor (ex-
Ministry of Housing and Urban affairs, Government of | officio)
India
2. The Chairperson of the Council shall have the power to co-opt any individual or organization, as a technical
representative, to participate in the meetings of the Council.
3, The members at serial numbers 12 to 21 of the table, selected by rotation, as provided under sub-section (3) of
section 41 of the Act, shall hold office as such member for a period of three years, from the date of this notification.
4. The members at serial numbers 22 to 29 of the table. selected as provided under sub-section (4) of section 41 of
the Act, shall hold office as such member for a period of five years, from the date of this notification.
[F. No. O-17024/429/2017-H]
SAILESH JOGIANI, Under Secy.
