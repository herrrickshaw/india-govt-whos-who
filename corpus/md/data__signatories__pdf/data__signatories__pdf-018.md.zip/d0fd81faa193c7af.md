---
doc_id: "d0fd81faa193c7af"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/987a1e8cc2b43047262b24282e1aa07c.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Voluntary retirement from service under Rule 43 of the CCS Pension Rules, 2021- case of Sh. T. Sreenivasan, Staff No. 20448, ITS, presently PGM, Txmm & MM, Kerala Telecom Circle, BSNL-reg."
date: "2025-05-08"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5c9c6c3fa3bca9e9"
---

<!-- page 1 -->

16-6/2025-STG-I

I/3275226/2025

No. 16-6/2025-STG-I
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi
*****
Dated the 08th May, 2025
OFFICE ORDER
Subject: Voluntary retirement from service under Rule 43 of the CCS (Pension)
Rules, 2021- case of Sh. T. Sreenivasan [Staﬀ No. 20448], ITS, presently PGM
(Txmm & MM), Kerala Telecom Circle, BSNL-reg.
The President is pleased to permit Sh. T. Sreenivasan [Staﬀ No. 20448], an
oﬃcer in SAG of ITS Group ‘A’(1993 Batch), presently posted as PGM (Txmm &
MM), Kerala Telecom Circle, BSNL, to retire Voluntarily from Government Service
under Rule 43 of CCS (Pension) Rules, 2021 with effect from 09.05.2025(A/N).
2.
No vigilance case/ disciplinary case is pending against Sh. T. Sreenivasan
as per the records available in Department of Telecommunications.
3.

The charge relinquish report may be furnished to the all concerned.

(Bijender Singh)
Under Secretary to the Government of India
Tele 011-2303 6282
Email: bijender.s83@gov.in
Copy to:
1. PPS to Secretary (T);
2. Member(S) / Member(T) / Member(F)/ DG (T);
3. Additional Secretary (T)/ Advisor(O) / Advisor(T);
4. CVO, DoT (HQs.);
5. CMD, BSNL CO., New Delhi – with request to ensure the compliance of Final
Order issued vide No. 8-17/2014-Vig. II dated 09.01.2018.
6. DDG(C&A)/DDG(Accounts)/DDG(IT)/DDG (Pers)/ DDG (Estt), DoT (HQs);
7. Admin I-IV/ Cash/ Pension/ Library/ G-I/ G-II/ PFP/ PHP/ RTI/ Vig.I Sec, DoT
(HQs);
8. Pay Bill Section, DoT (HQs.);
9. ADG (APAR)/ ADG (Staff)/ US(SNG) /AO(SGT), DoT (HQs);
10. The Officer concerned;
11. PA to US (SGT) – for uploading on the website of DoT; &
12. Order Bundle.
