---
doc_id: "d0cfbbdf69c5146a"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/df3d50dd92bf0880ab0ddbd90b4b63ca.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Office Order dated:14.11.2019 (Shri M. K. sagar is hereby taken on the strength of this Department as Principal Private Secretary in the Level 11 of pay Matrix w.e.f. 08.11.2019 (FN)"
date: "2019-11-14"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "98f801281f3d4395"
---

<!-- page 1 -->

No. A-19011/30/2019-Estt.(Hqrs)
Government of lndia

Ministry of Fisheries, Animal Husbandry and Dairying
Department of Animal Husbandry and Dairying
Kris hi Bhawan, New Delhi-110001

Date: \i.Lt.ZOfg
OFFICE ORDER

ln pursuance of Department of personnel and Training,s Orders No. 3l3lZOIg_
cs.ll (A) dated 01.03.2019 and 3/3/z}rB-cs. il(A)-part(l) dated 31.10.2019 and on being
relieved from Ministry of Jal shakti vide their order No. 22011,/Bl2ot7 -Ad mn dated 07'h
November, 2019, shri M. K. sagar is hereby taken on the strength of this Department as
Principal Private Secretary in the Level 11 of pay Matrix w.e.f. 08.11.2019 (FN).

(Rohit Tewari)
Under Secretary to the Government of lndia
Telephone No. : 23382779

Distribution:-

1.
2.
3.

Shri M. K. Sagar, PPS.
PS to JS (GNS), DAH&D.
The Under secretary (Admn.), Department of water Resources, RD & GR, Ministry of

Jal Shakti, Shram Shakti Bhawan, Khan Market, New Delhi w.r.t their Order No.

4.
5.

7 63 12079 dated 07.11.2019.

The Director (Admn.), central water commission, Ministry of .Jal shakti, sewa Bhawan,
R. K. Puram, New Delhi - 110066. lt is requested that Service Book and LpC of Smt.
Sumita Banerjee may be sent to this Department.

Shri Chirabrata Sarkar, Under Secretary, CS-ll (A), Department of personnel and
Training, 3'd Floor, Lok Nayak Bhawan, Khan Market, New Delhi w.r.t. their orders
d ated 01.03.2019

6.
7
9

and 31.10.2019.

P&AO (Sectt.), Department of Animal Husbandry and Dairying, Krishi Bhawan,
New Delhi.
And Coordination Section/ DDO / H indi Section for providing H indi version.
NlC, DAHD for updating the website of the Department
Service Book/ Guard File/ Spare Copies.

$
