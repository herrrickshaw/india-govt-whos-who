---
doc_id: "cdaab26fbb59874a"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_6a016c5b2b8792.43082000.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Offer of appointment - Shri Sandeep Kujur, IFS(AGMUT:1995) appoint to the post of Deputy Director General of Forests (DDGF), RO, Dehradun on deputation basis under CSS-MoEFCC, offer dated 11-05-2026"
date: ""
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "e6249b87990233f7"
---

<!-- page 1 -->

BY SPEED POST
No. 12026/04/2025-IFS-I[E- 286616]
Government of India
Ministry of Environment, Forest and Climate Change
Prithvi Wing, 6" Floor,
Indira Paryavaran Bhawan,
Jor Bagh Road, New Delhi - 110 003.
Date:11!" May, 2026
To
The Chief Secretary,
Government of Jammu & Kashmir,
Srinagar.
हि Subject: Offer of appointment in respect of Shri Sandeep Kujur, IFS(AGMUT: 1995) to
the post of Deputy Director General of Forests (DDGF), Regional Office, Dehradun on
deputation basis under Central Staffing Scheme of Ministry of Environment, Forest &
Climate Change(CSS-MoEFCC)-regarding.
i
Sir,
| am directed to refer to the subject cited above and to inform that the
Appointments Committee of the Cabinet (ACC) has approved appointment of Shri
Sandeep Kujur, IFS(AGMUT:1995) to the post of Deputy Director General of Forests
(DDGF), Regional Office, Dehradun in level 15 of the Pay Matrix, on deputation basis
under Central Staffing Scheme of Ministry of Environment, Forest & Climate Change
(CSS-MoEFCC) on the following terms and conditions: :
() He will draw pay as per the scale allowed by the Cadre Controlling
. Authority plus Allowances as applicable to that grade.
(ii) The central deputation tenure of the officer will be for a period of 05 years
w.e.f the date of assumption of charge or till attaining the age of superannuation,
or until further orders, whichever is earliest.
(iii) The headquarters of the post will be at New Delhi, however the services
of the officer can be utilized anywhere in India.
{iv) Other terms and conditions will be the same as applicable to the other
officers of his grade on deputation to the Central Government and as per CSS-
MoEFCC.
2. The State Government is requested to relieve Shri Sandeep Kujur,
IFS(AGMUT:1995) at the earliest with the direction to take up his new assignment.
: Yours (ere
Bee
(Prem urys \
Under Secretary to the Govt. of India
Email id- premp.maurya@nic.in
Ph - 011-20819192
fy

<!-- page 2 -->

Copy to:

1. PS to Hon'ble Minister, EFCC, New Delhi;

2. PS to Hon'ble MoS, EFCC, New Delhi;

3. PPS to Secretary(EFCC) / DGFSS / ADGF(FC) / ADGF(WL) / ADGF(PT)
/CEO(CAMPA/AII AS/JS/IGF(IFS)

4. The PCCF(HoFF), Government of Jammu & Kashmir, Srinagar;

5. JS(Admin), MoEFCC, New Delhi;

6. Shri Sandeep Kujur, IFS(AGMUT: 1995). ;

7. Shri Ramesh Chandra Jha, Under Secretary (EO-SM.II), DoPT, Kartavya
Bhawan-3, New Delhi.

8. Pay & Accounts Office, MoEFCC, New Delhi.

9. NIC cell for uploading on website;

10. Personal File/Reference Folder.
