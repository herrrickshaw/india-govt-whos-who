---
doc_id: "d108fc7ffbc36ba4"
source_url: "https://mohua.gov.in/static/uploads/2025/12/74205faea361fad66164e8906b233d67.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Election of Mayor/ Chairperson/ President"
date: "2014-11-14"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0d20e5291bd4f338"
---

<!-- page 1 -->

VIII. Election of Mayor/Chairperson/President
10.

The issue in this regard is as to how would the Mayor/Chairperson/ President of any

Municipality be elected?
(1)

The views of any State Government, in this regard, would be guided by their
political perceptions and traditions prevailing in the State.

(2)

It is noteworthy that in Rajasthan, Himachal Pradesh, Haryana, Karnataka, Kerala,
West Bengal, Maharashtra and Gujarat, the Mayors/Chairpersons are elected from
amongst the elected Councillors, i.e. by an “indirect election”.

(3)

In Andhra Pradesh, Uttar Pradesh, Madhya Pradesh and Tamil Nadu,
Mayors/Chairpersons are elected “directly” through adult franchise.

(4)

The issue in this regard is that there may be situations where the Mayor may not
belong to the party having the majority in the Municipality. Thus, a “direct”
election of Mayor may have difficult political implications.

Provisions Made in the Municipal Law

11.

Clause 23 of the Municipal Law provides that the Mayor/the Municipal
Chairperson/the Municipal President, as the case may be, shall be elected by the
elected Councillors from among themselves.

1
