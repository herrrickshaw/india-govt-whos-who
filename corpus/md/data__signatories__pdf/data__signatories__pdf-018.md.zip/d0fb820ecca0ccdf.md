---
doc_id: "d0fb820ecca0ccdf"
source_url: "https://doj.gov.in/static/uploads/2025/09/c465cedfda8a8c964708e4949314a558.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Sh. Justice Manoj Kumar Tiwari, Judge, Uttarakhand High Court as Acting CJ of Uttarakhand HC (09.10.2024)"
date: "2024-10-09"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2d6b9a4ab62c4eb6"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K-13032/03/2024-USJI
Government of India
Ministry of Law and Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011.
Dated: 09th October, 2024.
NOTIFICATION
In exercise of the power conferred by Article 223 of the Constitution of
India, the President is pleased to appoint Shri Justice Manoj Kumar Tiwari,
Judge of the Uttaralchand High Court, to perform the duties of the office of the
Chief Justice of that High Court with effect from 11.10.2024 consequent upon
the retirement of Ms. Justice Ritu Bahri, Chief Justice, Uttarakhand High Court
on 10.10.2024.

141A
(Jagannth Srinivasan)
Joint Secretary to the Government of India
Tele: 2338 3037
To
The Manager,
Government of India Press,
Minto Road. New Delhi.

<!-- page 2 -->

2

No. K-13032/03/2024-US.II

Dated: 09.10.2024

Copy to:

1.

2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.

Shri Justice Manoj Kumar Tiwari, Judge of the Uttarakhand High
Court through the through the Registrar General, Uttarakhand High
Court, Nainital.
The Secretary to the Governor, Uttarakhand, Dehradun.
The Secretary to the Chief Minister, Uttarakhand, Dehradun.
The Secretary to the Chief Justice, Uttarakhand High Court,
Nainital.
The Chief Secretary, Government of Uttarakhand, Dehradun.
The Registrar General, Uttarakhand High Court, Nainital.
The Accountant General, Uttarakhand, Dehradun.
The President's Secretariat, (CA.II Section), Rashtrapati Bhawan,
New Delhi.
PS to Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
Registrar (Conf), o/o Chief Justice of India, 07, Krishna Menon
Marg, New Delhi.
PS to MoS (I/C), L&J /PPS to Secretary (Justice).
Technical Director, MC, Department of Justice, with a request to
upload the notification on the website of the Department
(www.doj.gov.in).

e.5
21041
(Prehi Chand)
Under Secretary (Appointments-I)
Tele: 2338 2978
