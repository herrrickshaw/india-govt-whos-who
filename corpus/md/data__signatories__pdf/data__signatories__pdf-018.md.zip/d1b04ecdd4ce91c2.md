---
doc_id: "d1b04ecdd4ce91c2"
source_url: "https://www.dst.gov.in/static/uploads/2026/02/06859236113c1115c41e6ffa23ebb52a.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Guidelines for VAIBHAV Fellowship"
date: "2023-07-31"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b3d9fe393073c878"
---

<!-- page 1 -->

VAIshwik BHArtiya Vaigyanik (VAIBHAV) Fellowship (Ist Call)
(For Indian Diaspora)
(For NRI/OCI/PIO)
Starting date: 15th June 2023
Closing Date: 31st July 2023
https://dst.gov.in/

Government of India had organized Vaishvik Bharatiya Vaigyanik (VAIBHAV) Summit to
connect Indian STEMM diaspora with Indian Institutions. The summit was attended by more
than 25,000 attendees. 230 panel discussion sessions were held over 23 days on 18 Verticals
(research areas) and 80 Horizontals (sub-research areas) (see more details in following sections).
Indian STEMM diaspora from more than 70 countries had participated in the deliberations.
In this connection the Government has taken a step further to shape and implement the
VAIBHAV programme and is announcing VAIBHAV Fellowship Call-2023 as a first step.
The Department of Science and Technology (DST), Ministry of Science and Technology,
Government of India, would implement the VAIBHAV Fellowship Program. DST is one of the
Government Departments under Ministry of Science and Technology which plays the role of a
nodal department for organizing, coordinating and promoting S&T activities in the country with
the objective of promoting new areas of Science & Technology.
VAIBHAV Fellowship envisages a collaboration between scientists of Indian Diaspora with
Indian Higher Educational Institutions (HEIs), Universities and/ or public funded Scientific
Institutions. The VAIBHAV Fellow would identify an Indian Institution for collaboration and
may spend up to two months in a year for maximum 3 years.
Emoluments for the Fellowship:
• Fellowship in INR 4 Lakh roughly (equivalent to USD 5000 per month), for minimum 01
month
and maximum up to 02 months per year for a period of maximum 03 years,
• International Travel from place of work in parent institute to place of work in India in
business
class once a year,
• Fully furnished Accommodation in guest house or hotel up to Rs.7500/- per day
Page 1 of 6

<!-- page 2 -->

• Contingency Rs.1,00,000 per year for research expenditure in India
• Domestic Travel (economy class) for academic purposes up to two Indian academic/ scientific
institutes in a year
It may be noted that total eligible grant will be released to Indian host Institute and these
institute would be providing Fellowship amount to the VAIBHAV Fellow and extend other
support.
Expectations from the VAIBHAV fellow:
 Sharing the Best Practices on research and translation of research, incubation etc.
 Build long term connections,
 Connect Indian Students to the foreign faculty/scientists
 New approaches to Research processes and futuristic technologies
VAIBHAV Fellow is expected to give a report to DST within 21 days of completion of travel
indicating work done/initiated, follow up required etc.

Expectations from Host Institution
The host institute will host the scientist and provide office/lab facilities, consumables, access to
lab equipment and facilitation for various infrastructure support. The following activities will be
done by the host faculty/scientist:
 Will start a project/technology translation/start-up/incubation which should be aligned with
the priorities area of the country
 The VAIBHAV fellow would collaborate with the Indian scientist team during his visit and
beyond via online meetings.
 The host institution would implement the project within 3 years in consultation with
VAIBHAV fellow.
 The host Institution would submit the progress report and financial documents to DST at the
end of each year and a project completion report at the end of 3rd year. The reports need to
be jointly prepared by the host and the VAIBHAV fellow.
 Host institute will adapt the shared best practices
 Will build the long-term research connections with the fellow
 Will develop a new approach to research processes and try to develop new
technologies/innovation etc.
In addition to the emoluments to VAIBHAV fellow, the financial support (up to 5 Lakhs per year
for 3 years) will be given to host institution to facilitate the VAIBHAV fellow for research work
as per DST norms. This funding will cover the following expenses in connection with a project;



Consumables and Accessories,
Contingency
Page 2 of 6

<!-- page 3 -->



Institutional Overhead

Justification for budgetary support needs to be provided by the host institute, for which a
project proposal shall be submitted by the Host Institute in consultation with VAIBHAV
fellow as a part of VAIBHAV Fellowship application.
Registration in Public Fund Management System (PFMS) is mandatory for all Host Institute.
In case, Indian Host Institute is a private organisation, registration in Darpan portal of NITI
Aayog is needed.

Research areas under which applications may be submitted
Proposals are sought in select identified verticals and horizontals of VAIBHAV (as mentioned in
the preamble):
1. Quantum Technologies: Quantum Communication; Quantum Computing; Quantum Sensing and
Metrology; Quantum Materials and Devices

2. Artificial Intelligence and Machine Learning: Foundation of AI/ML; AI/ML and Signals;
AI for Social Good; AI and Robotics
3. Computational Sciences: High Performance Computing Architectures; Computational
Atmospheric Sciences; Cyber Physical Systems
4. Data Sciences: Data Science Project Management; Data Science Infrastructure, Deployment
and Hosting; Data Privacy and Security; Data Science Education; Data Science Applications
5. Photonics: Photonic Devices; Optical Imaging and Bio-photonics; Photonic Materials and
Sources; Nano-photonics; Integrated Photonics and Communication
6. Energy: Future Electricity Systems; Sustainable Mobility Technologies; Advanced Fossil
Technologies; Sustainable Future Fuels
7. Electronics and Semiconductor Technologies: Semiconductor Materials and Process
Technologies; Semiconductor Devices: Physics and Technology; Electronic Circuits and
System Design
8. Communication Technologies: Cellular Evolution 5G and Beyond (THz Comm);
Communication Technologies for IoT/CPS; High Speed Optical Communication - backbone
networks; Cognitive Technologies for Futuristic Communication
9. Aerospace Technologies: Aerospace Systems and Design; Propulsion Technologies; Flight
Structure and Integrity; Modeling and Simulations; Unmanned Aerial Systems and
Countermeasures
Page 3 of 6

<!-- page 4 -->

10. Materials and Processing Technologies: Structural Materials; Materials Recycling &
Purification; Advanced & Functional Materials; Catalytic Materials & Processes;
Computational Materials Science
11. Earth Sciences: Atmospheric Science; Polar Science; Ocean Science/Technology; Geo
Science/Technology
12. Environmental Sciences: Air Quality Management; Water Quality Management; Soil and
Waste Management; Carbon Sequestration and Biodiversity Conservation; Climate Change
13. Advanced Manufacturing Technologies: Smart Manufacturing, IoT, Digital
Manufacturing; Additive Manufacturing; Precision/Micro-nano Manufacturing/Surface
Engineering; Industrial Machines, Robotics/Automation; Speciality Products Manufacturing
14. Health, Medical Sciences and Biomedical Devices: Advanced Technologies in Health
Care; Precision Health; Holistic Health; Remote and Rural Health - Reaching the unreached
15. Pharmaceuticals and Bio-Technology: Biotherapeutics and Biosimilars; Industrial
Biotechnology; Infectious Diseases/ Disease biology; Drug Discovery, Repurposing and
Drug delivery
16. Agricultural Sciences: Precision Agriculture; Sustainable and Climate Smart Agriculture;
Food Safety and Nutritional Security; Climate Resilient Livestock, Veterinary Therapeutics
and Zoonoses control, Nanotechnology in sustainable agriculture and metabolic biology,
Modern Fisheries and Aquaculture and seed production, Genome editing, Robotics, farm
automation, Digital Agriculture
17. Social Sciences for SDGs: Behavioral Community Approaches & its impact on Societal
Development; Societal aspect of Technology Development with cause; Socio-Economic
aspect of Development
18. Management: Fostering academic collaborations; Mechanisms to increase R&D outputs
from Indian institutions; Business innovation; Entrepreneurship for growth; Management of
New-Age (Knowledge) Organizations; Making India R&D center of the world / Making
India Center of Practice-Oriented Management Knowledge
Eligibility: (For applicants – VAIBHAV Fellow)
 Non-Resident Indian (NRI), Persons of Indian Origin (PIO) and Overseas Citizen of India
(OCI), currently working abroad
 Ph.D/M.D/M.S/M.Tech degree from a recognized University
 Engaged in active research
 Working/worked in Institute/University of top-200 QS World University Ranking (subjectwise) (in regular/tenure employment) for at least 5 years or more.
OR
Working in Industry or Research Laboratories of repute in abroad for at least 5 years or
more (but should not be PhD or Post-doctoral fellow)
Page 4 of 6

<!-- page 5 -->

Eligibility: (For host Indian Institutions)
 Higher Educational Institutions / University ranked in top 200 in NIRF overall rankings or
having NAAC ‘A+’ grade or above
and/or
 Public funded Scientific Institutes/National Laboratories.
Documents needed to apply
 Statement of Purpose (one-page max.)
 Bio-data of Applicant in prescribed format (two pages max.)
 List of recent publications of applicant (last three years) with impact factors
 Copy of Valid Passport
 Academic Qualification – Copy of certificate for highest degree
 Experience Certificate
 Undertaking by the applicant in prescribed format
 No-objection certificate from the parent institute
 Consent letter from Host Institute in India
 CV of the host scientist /faculty (two pages max.)
 List of recent publications of the host scientist/faculty (last three years) with impact
factors
How to apply
Each application should be submitted to DST. Please note following important application
instructions:







The application should be submitted on-line to DST. Host Scientist need to apply on
behalf of the Indian Diaspora as DST would release the funds to the host Institution
which will be reimbursed to the fellow by the host Institution.
The applicant can download the proposal formats from websites www.dst.gov.in /
https://onlinedst.gov.in/Projectproposalformat.aspx?Id=2317
and
should
submit
completed application form and all relevant information through e-PMS portal of the
DST. Applications would be received in on-line mode only. Physical or e-mail
applications will not be considered.
Any shortcomings in the proposal or non-submission through the e-PMS portal will result
in rejection of the proposal. DST will not be responsible for these shortcomings.
In case applicant could not submit the proposal in time, DST would not entertain that
project offline and also no request to extend the date would be entertained.
It may be noted that after submission, applicant will get Temporary Project Number
(TPN), auto generated by the system, which should be mentioned in all future references.

Important Dates
o Launch of VAIBHAV fellowship at DST websites: June 15, 2023
o Deadline to submit Application in current cycle: July 31, 2023 (5:00 PM IST)
Page 5 of 6

<!-- page 6 -->

Merit Evaluation Criteria and Deliverables
We support research excellence and therefore contributions to research, training and mentoring
are considered and valued as part of the merit review process, with a focus on the quality and
impact of these contributions. Applications must address all of the following criteria in order to
be considered for funding:
o Quality of the proposal and research findings, including significance and originality;
o Relevance and outcomes, including benefit to society;
o Knowledge transfer, exchange, and dissemination;
o Partnership and international collaborations;
o Applicants should submit a consent letter from their parent Institute.
o Expected results, outcomes and appropriateness of budget strategy to achieve them.
Review Process for Evaluation of Applications
o

All applications will be handled in the strictest of confidence.

o

A Review Committee comprised of representatives and independent external reviewers
from India and government departments will examine the proposals.

o

DST may consider inviting the shortlisted applicants for online presentation of their
proposed work as part of the review process. Applications must attain a positive rating to
be considered eligible for funding.

o

The Experts Review Committee will prioritize applicants in given vertical. The final
decision would be taken by the Government on recommendation of the VAIBHAV Apex
Committee.

Contact Details:
For more details the following may be contacted:
Mr. Vinod Kumar Sharma
Under Secretary
VAIBHAV Cell
International Cooperation Division
Technology Bhawan
Department of Science and Technology
Ministry of Science and technology
New Delhi-110016
Email: vaibhav-india@gov.in

Page 6 of 6
