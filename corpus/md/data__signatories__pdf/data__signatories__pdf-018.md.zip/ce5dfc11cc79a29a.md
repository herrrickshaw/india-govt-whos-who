---
doc_id: "ce5dfc11cc79a29a"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/21d4d7abd01d7da6b81c04013c22b708.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 837 of 2024 in the Hon’ble High Court of Delhi: DoT instructions dated 05.08.2026 to ISPs"
date: "2026-08-05"
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "bcab51a4a5c60802"
---

<!-- no text layer: pending OCR -->
