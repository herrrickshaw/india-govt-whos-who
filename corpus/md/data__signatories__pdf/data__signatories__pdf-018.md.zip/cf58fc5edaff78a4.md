---
doc_id: "cf58fc5edaff78a4"
source_url: "https://mnre.gov.in/static/uploads/2025/07/9190a2d5d355bd651018b9de3935625c.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Extension of Pradhan Mantri Urja Suraksha evam Utthaan Mahabhiyaan (PM-KUSSUM)"
date: "2022-08-01"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ae3940a547b90ed5"
---

<!-- page 1 -->

No. 32/645/2017-SPV Division
Government of India
Ministry of New and Renewable Energy
ea a

Atal Akshay Urja Bhawan,

Lodhi Road, New Delhi-110003

Dated: 1 August 2022

ORDER
Subject: Extension of Pradhan Mantri Urja Suraksha evam Utthaan Mahabhiyaan
(PM-KUSUM).

This is in continuation to Order of even number dated 08 March 2019 regarding
issuance of administrative approval of Pradhan Mantri Urja Suraksha evam Utthaan
Mahabhiyaan (PM-KUSUM) and Order of even number dated 04 November 2020 regarding
scale-up and expansion of the PM-KUSUM. Implementation Guidelines of the PM-KUSUM
were issued vide OM dated 22.07.2019. Further, implementation guidelines for Component-
C were issued on 08.11.2019 and for Feeder Level Solarization on 04.12.2020. Based on the
feedback received from the stakeholders, amendments have been issued to these Guidelines
from time to time.

Be The PM-KUSUM Scheme has been extended till 31.03.2026, with targets under
the three components remaining unchanged and allowing inter-se transfer of quantities
across Component-B and Component-C.

3. Along with the extension, the following amendments have been made to the
implementation Guidelines of the Scheme:

i. Under Component-B and Component-C of the Scheme, Central Financial Assistance
(CFA) will be available for pump capacity up to 15 HP to the individual farmers in the
North-eastern States; UT's of Jammu & Kashmir and Ladakh; and the States of
Uttarakhand and Himachal Pradesh. However, the CFA for pumps up to 15 HP will be
restricted to 10% of the total installations.

ii, The condition of the domestic content requirement for solar cells has been waived off
for the feeder level solarization under Component-C for the projects awarded by the
implementing agency on or before 20.06.2023.

iii. | Budgetary allocation of Rs. 10,000 Crore approved by CCEA will be utilized before
accessing the extra-budgetary resources.

4. This Order is issued with the approval of the Competent Authority. ge oe
Ne हम,
(Qeevan Kumar Vethani)
Sr. Director/Scientist-F
To
1. All Central Ministrics and Departments;
2. Principle Director of Audit, Scientific Audit-Il, DGACR Building, I.P. Estate,
Delhi
3. ACS/Principal Secretaries/Scerctaries (Energy Departments) of all States/UTs

<!-- page 2 -->

1. State Implementation Agencies for all three components in all States

3. Pay & Accounts Olficer, MNRE

6. Indian Banks Association (IBA)

Copy to:
I. PS to Hon'ble Minister for Power and New & Renewable Energy
2. Sr, PPS to Seeretary. MNRE/ Sr. PPS to AS, MNRE/ PPS to JS & FA.
MNRE/ PPS to JS(Solar)., MNRE

3. All Advisers & Group Heads

1. Director (NIC) to upload this on the Ministry's website

5. Hindi section for Hindi version _

6. Sanction folder pret

० 0५

(leevan Kumar Jethani)
Sr. Director/Scientist-°
