---
doc_id: "ce3faa95e66def43"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/4d37b08e60c6726fb9412ab618b1f4e8.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification No. GSR 64 (E) Dated 27th January, 1992"
date: "2025-07-15"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3d7c3018ffc265cf"
---

<!-- page 1 -->

.17098/2017/EXP
~

REGD, NO. D.L.,33004[92

armumrr

£XTRA011D!NAR r

,m ~ 3--<n"·!N: (i)
PART JJ-Sedlon 3-Sub-secllon (I)

~'ll'll1!ilfmr

PUBUSIIED :OY AUTHORITY
-i, 41]

!'If lil~'l, til"'f~-.:, .r'llllil 21, ue2/<ITT1 11 uu

"•· 4JJ

!'/Ell OELl:I, MONJlAY, JANUARY 17. 1992/MAGHA 7, 1913

~ "1'[ tf" l',r,,i ~ " " ~ ,.,-di ' l'lrffll' ~ q 8Al'1T ~ oil "
nr 11r ri

Ii'

Scp:irnto ro~iug is ~i·.'en lo this Part In order that It may be llled as a
litlf lllBle c:ompllallon

====('1111!~ mm;

r..-,,,

(~).il."ff,./(.>r) . .-1.~,;. if .. )

..fmj_....,

,t fr;,,,,

>7 lf{H\,

I 092

.. rur,o~. I 68 4 ( Is•~ "'' 4 ) 'l\t !l!TT
~wr ;p-~ '6; fr-l'i l!'Frffrf'{:1T, I.JQf'l'f 'qf,ffll ~ ~ Mr~ lftrr~
"' ,rf!l'.l"'lf "· J/t"/65 .;, ,,rt m<. ( o) [T,;r,; H-GS "'1 qf~-, ~ ~ t'l[

~· "" f.<. ., (") .--,;'17,ftq ~ " '

fj

PTf ~ 1;,f"l'Pi'r 'fir

253

GI/92

1~

(lJ

<!-- page 2 -->

•

,•!(198/2017/EXP

•
2

(PAkC 11-S&:, ~ (i)]

THF. GAZE.TT& OF INDL\ : EXTllAORDINARY

;:::a-=-=-

l1t'ITT " ' ~ 'lffl'I it; -

"' <i1zif~ • II«~

ji;fl,ffl

..

..-.:it, w-t «<n 'l1'IRl ~ qi: 11f.m1 <fliRrr I orr <1'111 FAli ""' 'l'IR~ l! r.rlir.! ~ !{I 'I"''

'l'!)l<?

'{) :

~ lf!f llmfl 'l-l

film"" '{IIJ,i! ,,., ;ml(;r 'Illa\" .,q,rr 'f•r.: .,{{ <mr ,.,~ ,,

;rr'l

ll(r l;'llTt or);
("') '6lr ~ ;i ~ ~

t f<!I{ Iii;

(11) 'l1f.nii it< fir't ..ff.t it; f.1'l ~;
(IT) ;if11 '('!Wlrn ( RA~r llP.st'Wi h im: ~ J ir ~iitir ~ f'l 1! ~. wnrr
(• ) ~ 'lft,r

~ i it lllil'I ~ '11:1iU'I ~ it {f I
(Ii. 1 (a2)/u1·-~NIC!R/n1~r!;
'l.

'It.

m~ , "~.., on~,

MINISTRY OF lNDIJ~'TRY
(Department of Industrial Development)

(D.P.R.jE.G.G.S. Desk)
NOTIFICATION
New Delhi, tht: 27th January, 1992
CJ.S.R. 64(E) .-In exercise of the powers ~onfened by section 6 u! the
Indian EAplosives Act, 1884 (4 of 1884), um! in supctse,;sion of the notification
of the Government of India, Ministry. of Work.l, Housing « Urban lxvclopment No, 3Jl2165-Pil(1X) dated 1-4-1966, the Central (luvcmmcnt i., pk"se<f
to prohibit the manufucture, possession and importation c•f any e,plo~ive
consisting of nr cnnt~ining sulphur or ~-ulplmcct in admixture with chlorate
of potassiwn or 1111:1 <>thcr chlorate :
Provided that !hi, prohibition shall not .·xlcn<l to !he
possession of such explosives :

manufacture

or

(n) in sm~II quanti1ies for scientific purpi;ses ;
(I,) !or the (IUrpose of manufacturinp; hrads nf matches :
(c) for use in toy amorces (paper caps for toy pistols) : or
(d) in percussion caps for use in Railw.:y Fog Signals.

[F. No. 1 (3?,)j91-DPRjEGGSJ
A. P. SINGH. Jt. Secy.
Ptintecl hy th;·~hnagt~,-C:o~( 'i;iia Pu~•~. Ring Read, M:in Puti, New Delhi~
and Published by the Controller of Pvblicn>ions, Delh,-110054, 1992
