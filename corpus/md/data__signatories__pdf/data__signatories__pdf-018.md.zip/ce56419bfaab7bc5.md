---
doc_id: "ce56419bfaab7bc5"
source_url: "https://mohua.gov.in/static/uploads/2025/11/e7f03577021caf0df3c7b6db9bbd53e6.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of Rs. 300.00 lakh to UT Govt. of Puducherry as part amount of 1st installment of Central Assistance for 8 BLC (New Construction) projects under PMAY-U Mission - reg."
date: "2021-03-31"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0a8c75d2a602e145"
---

<!-- page 1 -->

6st
Firefox https://pfms.nic.in/Sanction/TemplateA dvice.aspx?AdviceNum-
PAO (Sectt) /HUA/Admn/Advice /2020-21/ 25 3¢~ 72
GOVERNMENT OF INDIA ना
PAO (Sectt) M/o Housing and Urban Affairs
507-C Nirman Bhawan New Delhi
Telephone No: 23062664 Fax No: 23062664
To,
The General Manager, — oF]
Reserve Bank of India, Code No: _|707
Central Accounts Section, jo55 |
Additional Office Building, Advice Date:/31/03/2021
East High Court Road,
NAGPUR - 440 001
Sir,
Please debit our account with Rs.3,00,00,000/- (Three Crore Only.) by contra credit to the following
accounts of the Governments with the amounts mentioned against each:
Month and Year of Accounts: March,2021 The Amount to be Settled: March,2021
Name of the | State Sanction No. and Date
State Code
1 PUDUCHERRY 127 1989-STATE AND UT 3,00,00,000 | N-11011/46/2020-HFA-V-UD
GRANTS UNDER PMAY (Comp. No. 9100529) dated
(URBAN) 31/03/2021
Signature of the authorized official
(Pawan Kumar Bhatnagar)
Sr. Accounts Officer Ae
14. Director of Accounts & Treasuries, D.A.T., Main Road, Rainbow Nagar, Puducherry Pin - 605}
om B. K. Mandal, US (HFA-V Sec), M/o Housing and Urban Affairs, New Delhi -110011.
Pawan Kuma nagar
Sr. Accounts Officer
O por
Ber eae
QO ron CA wl seal
r
& Hus H ri
\ & Ww
Me
lofl ‘ 31-03-2021, 1

<!-- page 2 -->

No. N-11011/46/2020-HFA-V-UD (Comp. No. 9100529)
Government of India
Ministry of Housing & Urban Affairs
. HFA-V Section .
eRe
Room No. 03, Technical Cell, Gate No. 7,
Nirman Bhawan, New Delhi
Dated: 3 -03.2021
To
Pay and Accounts Officer (Sectt.),
Ministry of Housing and Urban Affairs,
Nirman Bhawan,
New Delhi -11
Sub: Release of Rs. 300.00 lakh to UT Govt. of Puducherry as part amount of

1% installment of Central Assistance for § BLC (New Construction) projects

under PMAY-U Mission — reg.
Sir,

1 am directed to convey the Sanction of the Competent Authority to the release of Rs.
3,00,00,000/- (Rupees Three Crore only) to UT Govt. of Puducherry as part amount of
1* installment of Central Assistance (SC Component) for 8 BLC (New Construction)
projects for Creation of Capital Assets under Pradhan Mantri Awas Yojana — Urban (PMAY-U)
for FY 2020-21.

2. The statement showing details of the projects against which the above Central Assistance

is released towards part amount of 1* installment of Central Assistance is at Annexure.

3. 88९0 on decision and recommendations of CSMC under PMAY-U Mission in its 52"4

meeting held on 20.01.2021, the amount of Central Assistance is being released subject to the

following conditions:

i. The funds shall be utilized for the purpose and within the selected categorized

beneficiaries, for which these are given. Otherwise these will have to be refunded along
with interest as per provisions under GFR 2017.

ii. The expenditure on the implementation of the scheme/projects will be shared between
the Central and the UT/ULB/Implementing Agency (1A) as committed. The committed
UT share should also be released within 15 days from the date of receipt of Central
Assistance in the SLNA account. In case of shortfall of UT/ULB/IA share, corresponding
amount of Central Assistance will be deducted from the subsequent instalment (s).

iii. | The funds including Central Assistance and UT share will thereafter be released by the
UT Government to the implementing agencies without any delay failing which the
amount would be recovered from the UT Government with interest, as applicable, for the
period of default.

iv. Necessary sanctions/approvals/compliances required under the statutory or other
regulatory regime as applicable would be obtained by the authority (ies) concerned with
the project(s).

vy. The UT Government and implementing agency shall put in place a monitoring system to
ensure that the project(s) achieve scheduled milestone and envisaged outcomes
including implementation of reforms and other conditionalities required under the
scheme.
Contd..P.2/
oot

<!-- page 3 -->

-2-

vi. | The UT Government shall utilize the grant in accordance with the approved guidelines
for the implementation of PMAY-U Mission.

vii. | The UT Government shall furnish the Utilization certificates of the Grant released in the
prescribed format as per GFR 2017 as provided in the scheme guidelines.

viii, | Where there is an element of cash transfer to individual beneficiaries, the same may be
made through PFMS/DBT mode as applicable. The UT Government shall submit an
authenticated certificate from the bank showing complete details of disbursement of
funds to each beneficiary before release of 2" installment.

ix. The UT Government shall ensure the geo-tagging of all houses approved under BLC
component of PMAY-U Mission and subsequent release by the UT Government to
beneficiaries should be made in 3-4 installments depending on the progress/stage of
construction of house.

x. The UT Government shall be required to certify that the specifications of the houses
conform to NBC/IS Standards and that requisite infrastructure will be provided by the
UT Government/ULB. UT Govt. shall also ensure that there should be no
duplication/change in the identified beneficiaries.

xi. The UT Government shall submit the Action Taken Report (ATR) on the
observations/recommendations of Third Party Quality Monitoring Agency (TPQMA) for
quality monitoring purpose before release of subsequent instalment.

xii, The UT should ensure that Model Code of Conduct is not violated while releasing funds
to Implementing Agencies/ULBs/Beneficiaries.

4. _ The amount is debitable from the account of the Central Government in the books under

the following Head of Accounts under Demand No. 57 of the Ministry of Housing and Urban

Affairs for the year 2020-21:

Hee rante-in-ald to Union Tentory Governments wi

[Major ad: 3602 legislature

Sub-Major Head | _ ०6 | ntrally Sponsored Schemes

pecial Component Plan for Scheduled Castes

Pradhan Mante awas Yoana (Urban)

il Assistance to Union Territory Govt. for

alle Head puAYU

Object Head | 12.01.35 | rants for Creation of Capital Assets

5. The amount will be credited to the UT Government’s Account at Reserve Bank of India,

CAS, Nagpur as per procedure laid down by Ministry of Finance, Department of Expenditure in

this regard.
6. This being the first instalment Central Assistance, no UC is required/due for above release.
7. As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee
Institution(s)/Organisation(s) shall be open to inspection by the sanctioning authority and
audit, both by the Comptroller and Auditor General of India under the provision of CAG (DPC)
Act 1971 and internal audit by the Principal Accounts Office of the Ministry or Department,
whenever the Institution or Organisation is called upon to do so.
8. This issues with the concurrence of the Finance Division vide their Note No. 18 (E:
9100529) dated 24.03.2021.

Wedd Contd..P.3/

<!-- page 4 -->

-3-
9. This sanction has been registered at S. No.g5fin the Sanction Register of HFA Mission
Directorate of the Ministry of HUA for the year 2020-21.
Yours oer
BK )
Under Secretary to the Government of India
Tel No.: 011-23063285
Copy to:
1. Secretary, Housing, UT Government of Puducherry
2. Accountant General (A&E), Puducherry
3. Dir. (FD), MoHUA
4. Dir. (HFA-3), MoHUA
5. DS (Budget), MoHUA
6. NITI Aayog, SP Divn./DR Divn., New Delhi
7. O/oCGA, Mahalekha Niyantrak Bhavan, New Delhi
8. Dy. Chief (MIS/DRMC), HFA Directorate to place this sanction at appropriate place on
the Website of the Ministry.
9. PMU (MIS), HFA Directorate
10. Sanction folder weet 4 ॥
(B.K. Mandal)
Under Secretary to the Government of India

<!-- page 5 -->

डे See 8 BS
SB [PS pe eo ee Bie |
o fe eS Se
हि ae res =: 2582 ae a
3 Ee ee ae पक 2
S ee
< ees aS
y is Ome eee
“a |; a Sao se Ae
oie ae fg oes
a # a ee
a iE es
S S
Sf s 3 8 3
af = 8 8 8
i | = = 8 8 8
28 : 2 डे Ss 3
2 fo : 3 3 3 s
oso &
7
Sf
ड़ S S
3 8 8 3 8
8 8 s s 8
हे s s s 8
3 3 % 3 2
ठे S 3 3
& g
3 3 8 8 8
3 8 s 8
o s 8 8 5
3 o ७ छठ छ
g
8
8
g
a
" a “ « a
डर
z
2
a a a a
3
: aa है | | |
8
§
s
8
g
8
है
2
<
3 2
E
=
5
is
= 3 8 3 8
2 8 8 3 8
zg 8 8 8 s
a a a 3
a z zs a w
7 a g “ g
8 a
8 S ढ़ ड़
हे ड़ ड़ डे 8
= Ps s
5 3 5 : ड़
3 = g
2
= 2
« 3 3 5
= = = हि रु
2 g 2 s 6
gs © oS 2 Ss
sg 32 2 = &
3 है
2
7 8 ० ७ ७
Sa g y yg yg
es a a a
ES
g
zs
2s
gs a a तल <
as

<!-- page 6 -->

. 2
Soe oe aa
: 2 ost ;
S  =hee | E

Soe 4 ieee | I
te ae SS 7 L
bo ee 5 ]
oe Bi य es =
2 i ee : 2
es 025 7: pees F
4 5 pee foie eae a i
(2 oa | E
Serre dS a ee
i Banner =
| 3 ५ : 3 8 4
3 ee S
Oe g 3 8 5 B
: 8 8 : a
i >- छु 3 2 56 1
8 6 ts! |
४ Z = °o Ea
= xen = 1521
पे 8 Ss =
S S 2
2 oe
8 s 3
3 3 a 4
2 8 3 8
8 3
: a ठ =
oS 3 3 3 3 XY
गा पा बा
8 3
5 3 a Ss कक
3
a चर
“
4 a
= || '
° |_| |
g | |
| |
|_| | | z
8
g 3 g 5
8 3
हु दे 3 के
2 3 a i
o
3 3
हु g s |
= x nN a
2 8 a :
Da a un
8 o
5 E
कु
7 g 5 z
हे न 5 £ हि
3 5 = =
2 =
डर ०९
० ५
x 2 =
का
«
5 .
