---
doc_id: "d217a3ed24ffbf0e"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/d805455f67f1fd3212e91607598e683c.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Notes 7"
date: "2012-09-20"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5e4ef80cc6628efb"
---

<!-- page 1 -->

Government of India
India
Ministry
Ministry of Commerce
Commerce & Industry
Industry
Department
Promotion
Department of Industrial
Industrial Policy & Promotion

Press Note No.7
No. 7 (2012 Series)
Press
Subiect:
Subject:
1.0

Review
of the policy
policy on Foreign
Foreign Investment
Review of
Investment (Fl)
(FI) in compames
companies operating
operating III
m the
the
Broadcasting
Broadcasting Sector
Sector

Present Position:
Position:
Present

1.
As per
per extant
policy, the foreign
1.11
As
extant policy,
foreign investment
investment (Fl)
(FI) limits,
limits, in companies
companies operating
operating in the
the
Broadcasting
Sector,
are
set
out
in
paragraph
Broadcasting Sector,
paragraph 6.2.7
6.2.7 of
'Circular 1 of
of 2012
2012 - Consolidated
Consolidated FDI
of 'Circular
FDI
Policy',
Department oflndustrial
Policy', issued
issued by the Department
of Industrial Policy
Promotion (DIPP),
(DIPP), on 10.04.2012.
10.04.2012.
Policy and Promotion
2.0

Revised Position:
Revised
Position:

2.1
The
India has
has reviewed
2.1
The Government
Government of
of India
reviewed the
position in this regard
and decided
the position
regard and
decided to amend
amend the
the
foreign
foreign investment
investment limits,
limits, in companies
companies engaged
engaged in providing
carriage services,
services, in
in the
providing broadcasting
broadcasting carriage
the
manner
indicated below,
such terms
terms and
and conditions,
manner indicated
below, subject
subject to such
conditions, as may
Ministry of
may be specified
specified by
by the
the Ministry
of
Information
Broadcasting from time
Information and Broadcasting
time to time:
time:
(1)
(1)

Teleports
Teleports (setting
(setting up up-linking
up-linking HUBsffelepo
HUBsffeleports);
Home (0TH);
(DTH); Cable
Cable
rts}; Direct
Direct to Home
Networks
Networks (MSOs
(MSOs operating
operating at National
National or
or State
State or
or District
District level and
and undertaking
undertaking
upgradation
towards digitalization
upgradation of networks
networks towards
digitalization and
and addressabilit
addressability):
y):
Increase
foreign investment
Increase in the foreign
investment (FI) limit
49% to 74%,
subject to:
limit from 49%
74%, subject
(a)
being permitted
(a) Foreign
Foreign investment
investment up to 49%
49% being
automatic route;
permitted under
under the automatic
route; and
and
(b)
Foreign
investment
beyond
49% and up to 74%
(b) Foreign investment beyond 49%
74% being
being permitted
permitted under
under the
the Government
Government
route.
route.

(2)

Mobile
Mobile TV:
Permitting
Permitting foreign
foreign investment
investment (Fl)
(FI) up to 74%, subject
subject to:
(a) Foreign
Foreign investment
investment up to 49%
49% being
automatic route;
being permitted
permitted under
under the automatic
route; and
(b)
Foreign
49% and up to 74% being
(b) Foreign investment
investment beyond
beyond 49%
Government
being permitted
permitted under
under the Government
route.
route.

2.2
The
investment (FI) limit,
limit, in companies
2.2
The foreign
foreign investment
companies engaged
engaged in the aforestated
aforestated activities
activities of
of the
the
I&B
I&B sector,
sector, shall
shall include,
include, in addition
addition to FDI, investment
investment by Foreign
Foreign Institutional
Institutional Investors
Investors (FIis),
(FIls),
Non-Resident Indians
Foreign Currency
Non-Resident
Indians (NRis),
(NRIs), Foreign
Currency Convertible
American Depository
Convertible Bonds
Bonds (FCCBs),
(FCCBs), American
Depository
Receipts
Receipts (ADRs),
(ADRs), Global
Global Depository
Depository Receipts
Receipts (GDRs)
(GDRs) and convertible
convertible preference
shares
preference shares held
held by
by
foreign entities.
foreign
entities.
2.3
The terms
terms and
and conditions
conditions relating
2.3
relating to security
security and
separately be
and other
other conditions,
conditions, will
will separately
be
incorporated
incorporated in the sectoral
sectoral guidelines
guidelines of
of each
each broadcasting
broadcasting carriage
carriage service,
service, as specified
specified in
in
paragraph 3.0 below.
below.
paragraph

<!-- page 2 -->

Accordingly,
paragraph 6.2.7 under
3.0
Accordingly, paragraph
under 'Circular
'Circular 1 of
of 2012-Consolidated
IS
2012-Consolidated FDI
FDI Policy'
Policy' 1s
substituted
substituted with
with the following:
following:
SI. No.

Sector/
Sector/Activity
Activity

6.2.7
6.2.7
6.2.7.1

Broadcastin2
Broadcasting
Broadcasting
Broadcasting Carriage
Carriage Services
Services

6.2.7.1.1
6.2.7.1.1

(1) Teleports
Teleports (setting
(setting up of
of up- 74%
linking
linking HUBs/Telepo
HUBs/Teleports);
rts);
(2) Direct
Direct to Home
Home (DTH);
(DTH);
(3) Cable
Cable Networks
Networks (Multi
(Multi System
System
operators
Os) operating
operators (MS
(MSOs)
operating at
National or State
National
State or District
District
level
level
and
undertaking
undertaking
upgradation
upgradation
of
of
networks
networks
towards
towards
digitalization
digitalization
and
addressability
addressability););
(4) Mobile
Mobile TV;
TV;
(5) Headend-in-t
Headend-in-thehe Sky
Sky
Broadcastin2
Broadcasting Service
Service (HITS)
(HITS)
Cable
Cable Networks
Networks (Other
(Other MSOs
MSOs not 49%
49%
undertaking upgradation
undertaking
of networks
upgradation of
networks
towards
towards
digitalization
digitalization
and
addressability
addressability
Local Cable
and Local
Cable
Operators
Operators (LCOs))
(LCOs»
Broadcasting
Broadcasting Content
Content Services
Services

6.2.7.1.2
6.2.7.1.2

6.2.7.2
6.2.7.2

0/0
%
of FDI
FDI Entry
Entry Route
Route
Cap/Equity
Cap/Equity

Automatic up to 49%
Automatic
49%
Government
Government route
route beyond
beyond 49%
49%
and up to 74%
and
74%

Automatic
Automatic

6.2.7.2.1
6.2.7.2.1

Terrestrial
Terrestrial Broadcasting
Broadcasting FM
FM (FM
(FM 26%
Radio),
Radio), subject
subject to such
such terms
terms and
conditions,
conditions, as specified
specified from time
time to
time, by Ministry
Ministry of
time,
of Information
Information &
Broadcasting,
Broadcasting, for grant
grant of
of permission
permission
for setting
setting up of
of FM Radio
Radio stations
stations

6.2.7.2.2
6.2.7.2.2

Up-linking
Up-linking of
of 'News
'News & Current
26%
Current
26%
Government
Government
Affairs'
Affairs' TV
TV Channels
Channels
Up-linking
Up-linking
of
Non-'News
Non-'News
of
& 100%
Government
Government
Current
Current
Affairs'
Affairs'
TV Channels/
TV
Channels/
Down-linkin
Down-linking 2 of
of TV
TV Channels
Channels
FOi
wn-linking TV Channels
FDI for Up-linking/Do
Up-linking/Down-linking
Channels will be subject
subject to compliance
compliance with the
the
relevant
wn-linking Policy notified
relevant Up-linking/Do
Up-linking/Down-linking
notified by the Ministry
of Information
Ministry of
Information &
&
Broadcasting
Broadcasting from time to time.

6.2.7.2.3
6.2.7.2.3
6.2.7.3
6.2.7.3

6.2.7.4
6.2.7.4
6.2.7.5
6.2.7.5

Government
Government

Foreign
Foreign investment
investment (FI) in companies
companies engaged
engaged in all the aforestated
aforestated services
services will be
subject
subject to relevant
relevant regulations
regulations and such
such terms
terms and conditions,
conditions, as may
may be specified
specified
from time
time to time,
time, by the Ministry
Ministry of
of Information
Information and Broadcasting.
Broadcasting.
The
The foreign
foreign investment
investment (FI) limit
limit in companies
companies engaged
engaged in the
the aforestated
aforestated activities
activities
shall include,
include, in addition
addition to FDI, investment
investment by Foreign
Investors
(FIls),
Foreign Institutional
Institutional Investors (Flis),
Non-Resident Indians
Non-Resident
Indians (NRis
(NRIs),), Foreign
Foreign Currency
Currency Convertible
Convertible Bonds
Bonds (FCCBs),
(FCCBs),

<!-- page 3 -->

American
American Depository
Depository Receipts
Receipts (ADRs),
(ADRs), Global
Global Depository
(GDRs) and
Depository Receipts
Receipts (GDRs)
convertible
preference shares
convertible preference
shares held
held by foreign
foreign entities.
entities.
6.2.7.6

Foreign
broadcasting carriage
Foreign investment
investment in the aforestated
aforestated broadcasting
carriage services
services will
will be subject
subject to
the following
security
following security conditions/ter
conditions/terms:
ms:
Mandatory
Mandatory Requirement
Requirement for
for Key
Key Executives
Executives of
of the
the Company
Company

(i)
(ii)

The
The majority
majority of
of Directors
Directors on the Board
Board of
of the Company
Company shall
shall be Indian
Indian
Citizens.
Citizens.
The
The Chief
Chief Executive
Executive Officer
Officer (CEO),
(CEO), Chief
Chief Officer
Officer In-charge
In-charge of
of technical
technical
network
operations
network operations and Chief
Chief Security
Security Officer
Officer should
should be resident
resident Indian
Indian
Citizens.
Citizens.

Security
Security Clearance
Clearance of
of Personnel
Personnel

(iii)

The
The Company,
Company, all Directors
Directors on the Board
Board of
of Directors
and such
such key
executives
Directors and
key executives
like
like Managing
Managing Director
Director / Chief
Chief Executive
Executive Officer,
Officer, Chief
Chief Financial
Financial Officer
Officer
(CFO),
(CFO), Chief
Chief Security
Security Officer
Officer (CSO),
(CSO), Chief
Chief Technical
Officer (CTO),
(CTO), Chief
Chief
Technical Officer
Operating
Operating Officer
Officer (COO),
(COO), shareholders
shareholders who
who individually
individually hold
hold 10% or more
more
paid-up
paid-up capital
capital in the company
company and any other
other category,
category, as may
be
specified
may
specified by
the Ministry
the
Ministry of
of Information
Information and Broadcasting
Broadcasting from
from time
time to time,
time, shall
shall require
require
to be security
security cleared.
cleared.
In case
case of
of the appointment
appointment of
of Directors
Directors on the
the Board
Board of
of the
the Company
Company and
and such
such
key executives
executives like Managing
Managing Director
Director / Chief
Chief Executive
Officer,
Chief
Executive Officer, Chief
Financial
Financial Officer
Officer (CFO),
(CFO), Chief
Chief Security
Security Officer
Officer (CSO),
(CSO), Chief
Chief Technical
Technical
Officer
Officer (CTO),
(CTO), Chief
Chief Operating
Operating Officer
Officer (COO),
(COO), etc., as may
be
specified
may
specified by
the Ministry
Ministry of
of Information
Information and Broadcasting
Broadcasting from
from time
time to time,
time, prior
prior
permission
permission of
of the Ministry
Ministry of
of Information
Information and Broadcasting
shall have
Broadcasting shall
have to be
obtained.
obtained.
It shall be obligatory
part of
obligatory on the part
of the company
company to also
also take
take prior
prior permission
permission
from
from the Ministry
Ministry of
of Information
Information and Broadcasting
Broadcasting before
before effecting
effecting any
change
change in the Board
Board of
of Directors.
Directors.

(iv)

The Company
Company shall be required
required to obtain
obtain security
security clearance
clearance of
of all foreign
foreign
personnel likely
personnel
likely to be deployed
deployed for more
60
days
in
a
year
by
way
more that
that
days
year by way of
of
appointment,
appointment, contract,
contract, and consultancy
consultancy or in any
any other
other capacity
capacity for installation,
installation,
maintenance, operation
maintenance,
operation or any
any other
other services
services prior
prior to their
their deployment.
deployment. The
The
security
security clearance
clearance shall be required
required to be obtained
every
two
years.
obtained every two years.

Permission
Permission vis-a-vis
vis-a-vis Security
Security Clearance
Clearance

(v)

(vi)

The
permission shall
The permission
shall be subject
subject to permission
perm1ss10n holder/licensee
holder/licensee remaining
remaining
security
cleared
throughout
security cleared throughout the currency
currency of
security
of permission.
permission. In case
case the
the security
clearance
withdrawn the permission
permission granted
clearance is withdrawn
granted is liable
liable to be terminated
terminated
forthwith.
forthwith.
In the event
event of
of security
security clearance
clearance of
of any
any of
of the
the persons
persons associated
associated with
with the
the
permission
permission holder/license
holder/licenseee or foreign
foreign personnel
personnel is denied
for
any
denied or withdrawn
withdrawn
any
reasons
reasons whatsoever,
whatsoever, the permission
permission holder/license
holder/licensee e will
will ensure
ensure that
that the
the

<!-- page 4 -->

concerned person
concerned
person resigns
resigns or his services
services terminated
terminated forthwith
forthwith after
after receiving
receiving
such
directives
such directives from the Governmen
Government,t, failing
failing which
which the permission/license
permission/license
granted shall
be revoked
granted
shall be
revoked and the company
company shall
shall be disqualified
disqualified to hold
hold any
such
/license in future
such Permission
Permission/license
future for a period
or
five
years.
period
years.
Infrastruc
ture/Network/Software related
Infrastructure/Network/Software
related requirement
requirement

(vii)
(vii)

The officers/officials
officers/officials of
The
of the licensee
dealing with
with the
licensee companies
companies dealing
the lawful
lawful
interception
of
Services
interception of Services will be resident
India citizens.
citizens.
resident India
(viii)
Details of
re/network diagram
(viii) Details
of infrastructu
infrastructure/network
(technical details
of the
diagram (technical
details of
the network)
network)
could
be
provided,
on
a
need
basis
could
provided,
need basis only, to equipment
equipment suppliers/m
suppliers/manufactures
anufactures
and the
the affiliate
and
affiliate of
of the licensee
licensee company.
company. Clearance
Clearance from the licensor
licensor would
would be
required
required if
if such
such information
information is to be provided
anybody else.
else.
provided to anybody
(ix)
The
not transfer
transfer the subscribers
(ix)
The Company
Company shall not
subscribers' ' databases
databases to any
any person/place
person/place
outside India
unless permitted
permitted by relevant
outside
India unless
relevant Law.
(x)
The Company
provide traceable
(x)
Company must
must provide
traceable identity
identity of
of their
subscribers. .
their subscribers
Monitorin
Inspection and Submissio
Monitoring,g, Inspection
Submissionn of
Informationn
of Informatio

(xi)
(xi)

The Company
that necessary
The
Company should
should ensure
ensure that
(hardware/software)
necessary provision
provision (hardware/
software) is
available
available in their
their equipment
equipment for doing
doing the Lawful
Lawful interceptio
interceptionn and monitoring
monitoring
from
from a centralized
centralized location
location as an when
Government.t.
when required
required by Governmen
(xii)
The
company. at its own
(xii)
The company,
own costs,
costs, shall,
shall, on demand
demand by the
the government
government or
or its
its
authorized
representative, provide
provide the necessary
authorized representative,
necessary equipment,
equipment, services
services and
and
facilities at designated
facilities
designated place(s)
place( s) for continuous
monitoring or the broadcasting
continuous monitoring
broadcasting
service
by or under
under supervision
service by
supervision of
of the Governmen
Government t or its authorized
authorized
representative.
representative.
(xiii)
Broadcastingg or its
its
(xiii) The
The Governmen
Government t of
of India,
India, Ministry
Ministry of
of Information
Information & Broadcastin
authorized
ive shall have
authorized representat
representative
have the right
right to inspect
inspect the broadcasting
broadcasting
facilities.
/intimation shall be required
facilities. No prior
prior permission
permission/intimation
required to exercise
exercise the right
right
of
representative to carry
of Governmen
Government t or its authorized
authorized representative
carry out
out the inspection.
inspection. The
company will,
will, if
if required
Government its authorized
company
required by the
the Government
authorized representat
representative,
ive,
provide necessary
necessary facilities
provide
facilities for continuous
continuous monitoring
aspect
monitoring for any particular
particular aspect
of the
activities and operations.
of
the company's
company's activities
operations. Continuous
monitoring, , however,
Continuous monitoring
however,
will
be
confined
will be confined only
only to security
security related
aspects, including
including screening
screening of
of
related aspects,
objectionable
objectionable content.
content.
(xiv)
(xiv) The inspection
inspection will ordinarily
ordinarily be carried
carried out
out by the governmen
government t of
of India,
India,
Ministry of
of Information
& Broadcastin
Broadcastingg or its authorized
authorized representative
after
Ministry
Information &
representative after
reasonable
reasonable notice,
notice, except
except in circumstan
circumstances
where giving
giving such
a
notice
ces where
such notice will
will
defeat
the
very purpose
defeat
very
of the inspection.
inspection.
purpose of
(xv)
such information
information with
(xv) The
The company
company shall submit
submit such
with respect
respect to its services
services as may
may
by
required
by
the
Governmen
by required
Government t or its authorized
authorized representative,
format as
as
representative, in the format
may
required, from
may be required,
from time
time to time.
(xvi)
permission holder/licen
(xvi) The
The permission
holder/licensee
shall be liable
liable to furnish
furnish the Governmen
Government t of
of
see shall
India
its authorized
representative or TRAI
India or
or its
authorized representative
TRAI or its authorized
authorized representative,
representative,
such
such reports,
reports, accounts,
accounts, estimates,
estimates, returns
returns or such
such other
other relevant
relevant information
information and
and
at such
periodic
intervals
such periodic intervals or such
such times
times as may
may be required.
required.
(xvii)
(xvii) The
The service
service providers
providers should
should familiarize
familiarize/train
designated officials
the
/train designated
officials or
or the
Governmen
Government t or officials
officials of
of TRAI
TRAI or its authorized
authorized representative(s)
in
respect
representative(s) respect
of
operations/features of
of relevant
relevant operations/features
of their
their systems.
systems.

<!-- page 5 -->

National Security
Security Conditions
Conditions
(xviii) It shall
shall be open
open to the licensor
licensor to restrict
restrict the
the Licensee
Licensee Company
Company from
from operating
operating
(xviii)
in any
any sensitive
sensitive area
area from
from the
Security angle.
angle. The
The Government
Government of
of
National Security
the National
India, Ministry
Ministry of
of Information
Information and Broadcasting
Broadcasting shall
shall have
have the right
right to
India,
public
temporally
suspend
permission
of
permission
holder/Licensee
in
public
holder/Licensee
permission
the
of
permission
the
suspend
temporally
The
may direct.
interest or for national
security for such
such period
direct. The
periods as it may
period or periods
national security
interest
regard
this regard
issued in this
company shall
shall immediately
comply with
any directives
directives issued
with any
immediately comply
company
company
the company
and the
revoked and
failing
shall be revoked
issued shall
permission issued
the permission
which the
failing which
years.
disqualified to hold
hold any such
such permission
permission in further
further for a period
period or five years.
disqualified
identified
are
which
(xix)
The
company
shall
not
import
utilize
any
equipment,
which
identified
as
equipment,
any
utilize
or
(xix) The company shall not import
unlawful
and/or render
security vulnerable.
vulnerable.
network security
render network
unlawful and/or
Other conditions
conditions
Other
(xx)
(xx)
(xxi)
(xxi)

4.0

Licensor reserves
reserves the
the right
right to modify
modify these
these conditions
conditions or incorporate
incorporate new
new
Licensor
public
conditions considered
considered necessary
interest of
of national
security and
and public
national security
necessary in the interest
conditions
services.
broadcasting
of
interest
proper
provision
of
broadcasting
services.
provision
proper
for
or
interest
out by it
Licensee will
will ensure
ensure that
that broadcasting
broadcasting service
service installation
installation carried
carried out
Licensee
statute,
should not
safety hazard
hazard and
and is not
not in contravention
contravention of
of any
any statute,
become a safety
not become
should
policy.
public policy.
rule
and public
regulation and
rule or regulation

The above
above decision
decision will
take immediate
immediate effect.
effect.
will take
The

Joint Secretary to the
D/o
5/5/2012-FC.I dated:
dated: 20 September,
September, 2012
2012
No. 5/5/2012-FC.I
No.: No.
File No.:
D/o IPP File

(A .alii'XAtsro:J)
ent of India

t

Copy forwarded
forwarded to:
Copy

publicity.
giving necessary
necessary publicity.
1. Press
Press Information
Information Officer,
Officer, Press
Press Information
Information BureauBureau- for
for giving
1.
Press
for uploading
2. BE Section
Section in the
of Industrial
Policy and
and PromotionPromotion- for
uploading the Press
Industrial Policy
Department of
the Department
Note
P 's website.
website.
DIPP's
Note on DIP
