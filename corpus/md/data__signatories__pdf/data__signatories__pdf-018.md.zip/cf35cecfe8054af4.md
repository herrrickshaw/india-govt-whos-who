---
doc_id: "cf35cecfe8054af4"
source_url: "https://www.texmin.gov.in/static/uploads/2025/06/4d02dece9fde7de6fef582001c4fb24e.pdf"
ministry: "Textiles (MoT)"
title: "Advertisement for hiring the Company Secretary on contract basis for British India Corporation Limited CPSE under Ministry of Textiles"
date: "2024-11-20"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "96a361de4d84ec90"
---

<!-- page 1 -->

British India Corporation Limited.
(A Govt. Of India Company)
Ministry of Textiles
11/6, Smt. Parv'ati agla Road
Kanpur-2OSOO 1.

BIC invites applications for the position of Company Secretary on
Fixed Term Contract basis for its Head Ofltce in Kanpur.
I

Details are as under:

British India Corporation Limited.
(A Govt. of India Company, Ministry of Textiles)

11/6, Smt. Parvati Bagla Road, Kanpur-208001
BIC, Public Sectors Undertaking requires one Company Secretary on "fixed
term contract" basis the details are as follows:
s.

Name of Position

Company Secretary

Age Limit

Below 40 Years

ltlo

Quallflcation
Essentlal
Qualification

I

Should be an Associate/ Should have fellow
Membership of lnstitute of Company Secretaries of
India
CS+CA (Chartered Accountant)

Preferable
Work Location

Kanpur, Uttar Pradesh (BIC Office)

Experience
(Minimum)

One year post qualification experience in relevan
fields. Experience of working in computerized
environment is essential.
i) Ensure compliance of Companies Act, 1956,
guidelines on Corporate Government norms and
other Corporate Laws applicable to the Company.
ii) Convene Board Meeting, Audit Committee
meeting, other Committee meetings, Annual
General Meeting etc. including preparation of
agenda, minutes, coordination etc.
iii) Maintain books, registers, records etc. as per
the applicable laws including fiting of returns etc.
with concerned authorities.
iv) Compliances of various other statutory
obligations.
v) Liaise/ follow-up with various Government
Department to ensure statutory compliance.

Job-ProIile

I

<!-- page 2 -->

vi) Filing of returns with registrar to companies.

vii) Appointment and fixing of remuneration of
statutory auditors.

Remuneration The selected candidate will get monthly
remuneration of Rs. 70,000.00/-(al1 inclusive).
I

I

Tenure of

One year and on basis of the performance and

Appointment

need his/her services may extended to one more
year.

Leave

He / She shall be eligible for 12 days' leave in a
calendar year on pro-rata basis. Therefore, he/she
shall not draw any remuneration in case ofhis/her
absence beyond 12 days in a year (calculated on
pro-rata basis). Also un-availed leave in a calendar
year cannot be carried forward to next calendar
year.

TA/DA

No TA/DA shall be admissible for joining the
assignment or on its completion. However, in the
course of performing professional duties, if he/she
is deputed to outstation units, the admissible
TA/DA will be at par with Asst. Manager in BIC.

Other allowances

No other facilities like DA, accommodation,
telephone, conveyance/ transport, LTC etc. would be
admissible.

BIC reserves the right not to iill ttre above position without assigning any
reasons.

I

Instructions
1)

2)
3)

Applications giving ful1 particulars along with self-attested copies of
Certificates/testimonials and a recent passport size photograph (nonreturnable) should reach to Director (F&Al BIC By ordinary Post by
O2l OL 12025 on the address SC Gupta, OSD BIC, Room no. 539, Mlnlstry
of Textiles, Udyog Bhawan New Delhi 11OO11. Please superscribe
envelope with the post applied for.
Applications which do not meet the criteria given in this advertisement & /
or incomplete application are 1iable to be summarily rejected.
No correspondence will be entertained with the candidates not short listed
for interview.

<!-- page 3 -->

British India Corporation Limited.
(A Gort. of India Company Ministry of Textiles)
11/6, Smt. Parvati Bagla Road, Kanpur-2080o1
APPLICATION FORMAT

Please paste

self-attested

1) All columns should be fllled in btock letters

recent

2) Incomplete applications/applications without enclosures will b
1

POST APPLItrD FOR :

2

FULLNAME(BLOCKLETTERS)

:

FATHER'S/HUSBAND'S NAMtr :
4

(a)

DATE OF BIRTH :

(b)

AGE :

_(YRS.)_(MTS)_(DS)

(As on the last date of receipt of application)
5

RESIDENTIAL ADDRESS :
(a) CORRESPONDENCE:
ADDRESS

Tele. No.

E-mail ID

(b) PERMANENT ADDRESS:

Tele. No.

E mail ID
Male

6

SEX

7.

MARITAL STATUS

8.

RELIGION

9.

PRESENT OFFICtr ADDRESS :

Female

Trans
Gender

:

Maried

l=l

unmarried

fl

passport size
photograph

<!-- page 4 -->

10. CATEGORY (SC/ST/OBC)

:

(In case PWD, please mention the percentage & category of disability)
(ln case of OBC, please, attach the latest OBC (not more than 6 months otd)
certificate)

i 1.

(a) PRESENT POST HELD:
(b) DATE FROM WHICH HELD:
(c) NAME OF ORGANISATION:
(d) SCALE OF PAY:
(e) PRESENT BASIC PAY (P.M.):
(f) TOTAL EMOLUMENTS (P.M.):
(P1. enclose current salary slip/break-up of salary)

72, DETAILS OF SERVICE
NAME OF THE

POST

NO. ORGANISATION

HELD

sL.
I

SERVED
TO

FROM

LENGTH

WHETHER
REGULAR
OR NOT

OF

SERVICE

NATURE
OF

DUTIES
PERFORM
ED

13.
sL.

EDUCATIONAL QUALIFICATION : (including professional qualifications, if
an
EXAM.
rNsTT./
i SUBJECTS
YEAR OF % AGE OF DIVISIO

NO.

PASSED

UNTVERSITY

I sruorpo

PASSING

MARKS

N

OBTAIN
ED

I

14

PROFICIENCY IN COMPUTER APPLICATIONS (IF ANY):

15

AI.{Y OTHER RELEVANT INFORMATION:

DECLARATION:

I HEREBY DECLARE THAT THE ABOVE STATEMENTS ARE TRUE TO THE BEST OF MY
KNOWLEDGE AND BELIEF. IN THE EVENT ANY INFORMATION IS FOUND TO BE FALSE
OR INCORRECT, MY CANDIDATURE MAY BE TERMINATED WITHOUT NOTICE.

PLACE :
DATE :

SIGNATURE OF THE CANDIDATE
