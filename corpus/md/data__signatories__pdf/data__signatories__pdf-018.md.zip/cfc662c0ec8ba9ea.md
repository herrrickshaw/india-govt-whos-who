---
doc_id: "cfc662c0ec8ba9ea"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/1fa072d413b339e3c54c650db062befd.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "RTI - Departments of Health and Family Welfare - Immunization - Operational Guidelines - AEFI Reports - UIP Vaccination - Causality Assessment of 108 reported serious AEFI cases, Approved by National AEFI Committee"
date: "2015-08-03"
pages: 8
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "db44f3977f819d50"
---

<!-- page 1 -->

|
~ _ Causality assessment report of 108 reported Serious Adverse Events
Following Immunization (AEFI) cases, approved by National AEFI
Committee
The Immunization Division of Ministry of Health & Family Welfare
has taken several steps to improve the National AEFT surveillance system,
both the quality of investigation of cases at state level and their causality
assessment at national level, Considering the importance and critical nature
of the task, SOPs tor causality: assessment (CA) have been laid down as
qualily assurance. The CA subcommittee is housed at Lady Harding
Medical College which is also the National AEFI Technical Collaborating
Centre, The first round of Causality Assessment is undertaken by this sub-
committee.
AEFI deaths, attributed to the vaccine or programme error are |
reviewed ugain by a specially constituted review panel comprising of the
chairs of the 4 subcommittees of the National AEFI Committe (ie.
Cuusality assessment, investigation, media and laboratory subcommittees) |
chaired by Chairman, National AEFI committee. The causulity assessment
reports ire presented to the National AEF] Committee. |
‘The results of the Causality Assessment for 108 cases completed aver
the past few months after thorough review, deliberation und approval by the
National AEF! Committee is placed below (The anonymized line list of the
causality assessment done by the National AEFI Committee as annexure),
Many of the reported serious AEF Is are coincidental (33) and none
have been found to be due to quality defect in manufacturing vaccines.

<!-- page 2 -->

iti
i] 1 111 11: Page
0 ETH
81818 818 8 [8 | 8 8 6 | 8 | 8 | 8 डे a
(81888 88888 [88888 | i ।
HEATER | UE
E/E /E/8 अधि el i
5६६६६ ६६९६६ | 38 | || !
Sid i |
mt व |!
, igi 5
ie il
81818 डर a s g ==
10000 कह  ।#$|*+«&
| 8181 | | {gate
॥1॥॥॥५॥॥
1 नि नि

<!-- page 3 -->

PEEEPEEEEEEECEEL Sy
FARR mL
111 ॥ है की
2818 58 8 6 8 6 | 8 1 888 | 5 111
86666 6666 66666 8 8] qu |
[हक |
alsls 3
EBEBEEBEBBEBBEEE i]
"१०६६० | ००" हैं | | | a3
TERRE) cu |
1111 | | | ॥ | ॥ कई || १३
| | ||
PEERAGE)
| Hl 8 टू
रु डे

हिना

<!-- page 4 -->

|=] s[|=[e|e[s|=[e[e]e[e[e[ele] 8 | ii
TTITIETEISIEIPIRIETEIEEET WEL
6 Fg
है| 1111
3|3 | 88 88 |8 88 | || 8 8 88 1111]
॥ 11611 वि हित हि qu ।
3 31111॥131२ Ea
|
४8६ ६४६६६४ ६४१६४ ६६ | | ६
41111 11 11111॥ न | कक
RRR । है ||
१ ॥| 1 1 8 | /8)8) | it 1
| oy
| |
ही | !
; f 6/8
HAA
sfol fal [offal हि हि वह
a3

<!-- page 5 -->

गिगगगगगगगगगगगगगगग कह]
हि HT
है । | TE
81818 |8 8 | 8 88 | 8 8 8 8 8 | 8 | 8 | है Hu
11॥॥1॥॥॥॥1॥11111|8 वी
4 18 8 8 8 8 8 9 | 8 8 है | 8 1
11111 |
| i
5 2
11116 88 | fog
दिए हक. st
व
| । Wali £
' i A
TERRE]
IAPs
1111110 0110 100 bt
3

<!-- page 6 -->

GEEEEEEEEEETEEGET S Tinie
EERE Way
1 EEE
है 818 8 8 | 8 8 6 | 8 | 8 8 4 8 | 8 8 | HHL
हित शशि कि AY
1 | HE Hot
HE Ht || ।
3
3] 2] |=] 8] | #5] 5] =) 2] [2] | |e i] ४
«व हि | ४
गशिशीिशिहशि | |
| 1] ४
il 23
ie
तक |
é कर्क HAE i i
॥॥॥॥॥॥ 1
ह।
"न गज
3

<!-- page 7 -->

गा ह।|
ओह
010 | 1111।।
85881 8 88 6 18 | 8 | | $ 8 8 | 8 HH
111111111111111118 कह
1 5 518 जि tt E
|
11111 11111 11111116 8 | द
PEE hos
i ii
me || 1
ह 1 | ||
111 111111॥1111 आई
४1 8818 | ta] | 3
PPP P BWR
splot ltelellol fe Bt

<!-- page 8 -->

. $ RREEEEE EERE ढ़
MTA HAN
VATU | 11111:
| |
111] 11 | हि iti :
| है: | 8 | 9 है 5 ag
TT |
ABEGERRET ET किक
PEPPER os
TU] pa
10 | ॥ a /४£
ह ः (1 हे
हि कि
0॥01000100010 (| «४
| हू ४8 8 ]
HA AAD
sotto है
