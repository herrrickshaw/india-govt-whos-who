---
doc_id: "d20a20bab5acfe32"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/09/2381ae426c2e0b2ffe4663f813844594.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Notification of enforcement dated 09.10.2023 under the Mediation Act, 2023"
date: "2024-11-29"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "8ad86947ab19a9ea"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-09102023-249277
xxxGIDHxxx
CG-DL-E-09102023-249277
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 4213]
No. 4213]

नई दिल्ली, सोमिार, अक्तूबर 9, 2023/ आज‍िन 17, 1945
NEW DELHI, MONDAY, OCTOBER 9, 2023/ASVINA 17, 1945

जिजध और न्याय मंत्रालय
(जिजध कायय जिभाग)
अजधसूचना
नई दिल्ली, 9 अक्तूबर, 2023
का.आ. 4384(अ).—मध्यकता अजधजनयम, 2023 (2023 का 32) की धारा 1 की उप-धारा (3) द्वारा प्रित्त
िजियों का प्रयोग करते हुए, कें द्र सरकार एतद्द्वारा 9 अक्टूबर, 2023 को उि अजधजनयम की जनम्नजलजखत धाराओं के
प्रािधान लागू होने की तारीख के रूप में जनधायररत करती है, अर्ायत्:
(1) धारा 1;
(2) धारा 3;
(3) धारा 26;
(4) धारा 31 से 38 (िोनों सजममजलत);
(5) धारा 45 से 47 (िोनों सजममजलत);
(6) धारा 50 से 54 (िोनों सजममजलत); और
(7) धारा 56 से 57 (िोनों सजममजलत);
[फा. सं. ए-60011/45/2023-एडीआर]
डॉ. रािीि मजण, अपर सजचि

6380 GI/2023

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF LAW AND JUSTICE
(Department of Legal Affairs)
NOTIFICATION
New Delhi, the 9th October, 2023
S.O. 4384(E).— In the exercise of the powers conferred by sub-section (3) of section 1 of the Mediation Act,
2023 (32 of 2023), the Central Government hereby appoints the 9 th day of October, 2023 as the date on which the
provision of the following sections of the said Act shall come into force, namely:(1)

Section 1;

(2)

Section 3;

(3)

Section 26;

(4)

Sections 31 to 38 (both inclusive);

(5)

Sections 45 to 47 (both inclusive);

(6)

Sections 50 to 54 (both inclusive); and

(7)

Sections 56 to 57 (both inclusive);

[F. No. A-60011/45/2023-ADR]
Dr. RAJIV MANI, Addl. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR
VERMA

Digitally signed by
MANOJ KUMAR VERMA
Date: 2023.10.09
21:59:32 +05'30'
