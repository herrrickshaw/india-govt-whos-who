---
doc_id: "cf2afcb816c2e1d1"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/adf089f9df13569bcd1f464210cffd0a.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Revised Guidelines for Registration of Infrastructure Providers - Category -I (IP-I) dated 22.12.2021"
date: "2021-12-22"
pages: 11
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "602d8e7193982e6a"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, Ashoka Road, New Delhi-110001
(Carrier Services-III Cell)
No. 10-12/2012-CS-III

Dated:

22.12.2021

Subject: Revised Guidelines for Registration of Infrastructure Providers - Category -I
(IP-I).
Kindly find attached the following documents on the subject mentioned above, for
information and further necessary action:­
(i) Guidelines for Registration of Infrastructure Providers - Category -I (IP-I).
(ii) Application form for IP-1 Registration.
(iii)Check list for the documents to be submitted along with the application for IP-1
Registration.
(iv)Draft Registration Certificate for IP-1 Registration.

This issues with the approval of Competent Authority.
Encl: As above

~)<r~/:
/"o 0vo%~0
(Mohit Bansaff
Assistant Director General (CS-III)
(-.:fl1~~ )
( M O HIT BAN S A L)

~~~ (~ .~ . )
A as l s t a nt Dire ctor G e n e r a l (CS)

~fitowl . ~~

Oeptt. of Tel ecom, Govt . of India
·

~ fittol'ft/N ew D e lhi

<!-- page 2 -->

2

GUIDELINES FOR REGISTRATION OF INFRASTRUCTURE PROVIDERS­
CATEGORY-I (IP-I)
The Infrastructure Providers Category-I are those Infrastructure Providers who provide assets
such as dark fibres, Right of Way, duct space & tower.
The following are the guidelines for the registration of Infrastructure Providers Category-I to
be called IP-I.
1. The applicant must be an Indian company, registered under the Companies Act,
1956/2013.
2. FDI upto 100% under automatic route subject to Para 3.1.1 of FDI policy 2020 (as
amended vide Press Note 3 (2020) series dated 17.04.2020) and observance of
conditions of IP-1 Registration by the company as well as investors as notified by the
Department of Telecommunications (DoT) from time to time.
Notwithstanding with the above provision, foreign investment shall be subject
to following conditions:
(i)
An entity of a country, which shares land border with India or where the
beneficial owner of an investment into India is situated in or is a citizen of any
such country, can invest only under the Government route.
(ii)
In the event of the transfer of ownership of any existing or future FDI in an
entity in India, directly or indirectly, resulting in the beneficial ownership
falling within the restriction/ purview of the clause no. (i) above, such
subsequent change in beneficial ownership will also require Government
approval.
(iii)
Both direct and indirect foreign investment in the applicant company shall be
counted for the purpose of calculating total FDI.
(iv)
The applicant company/ Indian Promoters/ Investment Companies including
their holding companies shall comply relevant provisions of extant FDI policy
of the Government. While approving the investment proposals, the
Government may take into accounts security concerns .
(v)
FDI shall be subject to laws of India and not the laws of the foreign
country/countries. The applicant company shall comply with the relevant
provisions of FDI policy of the Government and such modifications to the
policy as may be issued from time to time.
(vi)
The words, mentioned hereinabove, such as FDI, foreign equity, investment
companies, FIPB, etc., shall have the same meaning as defined by Department
for Promotion oflndustry and Internal Trade (DPIIT) in its FDI Policy.
3. The company shall submit the application for registration in the prescribed form
(Annexure-I) . The documents may be submitted as per checklist at Annexure-II.
4. The applicant company shall make its own arrangement for Right of Way (ROW) .
5. Change in the name of the applicant company or the registered IP-I, as the case may
be, shall be permitted in terms of the provisions under the Companies Act, 1956/2013.

No. 10-12/2012-CS-IIJ/Dec 2021

/

r/

<!-- page 3 -->

3

6. The applicant company shall be informed of the approval or rejection of the
application as far as practicable within 15 days of submission of the application.
7. The registration for IP-I shall be on non-exclusive basis without any restriction on the
number of entrants.
8. The IP-I registered company shall provide dark fibres, Right of Way, duct space,
towers on lease I rent out I sale basis to the licensees of telecom services on mutually
agreed terms and conditions.
9. The IP-I registered company shall submit a copy of an agreement entered into with
the telecom service providers to the DOT within 15 days of signing of such
agreement.
10. IP-I registered company shall provide for the use of infrastructure in a non­
discriminatory manner.
11. The applicant company will be issued a Registration Certificate for IP-I, a draft copy
of which is attached herewith as Annexure-III. The terms & conditions of these
guidelines as well as that of the Registration Certificate will be binding on the IP-1
registered companies.
12. The applicant company shall pay a processing fee of Rs. 5,000/- (non-refundable)
through digital payments like e-transfers/NEFT/RTGS/Debit Card/Credit Card, as per
the
process
given
m
the
user
guide
for
NTRP
at
http://www.dot.gov. in/sites/default/files/2016 12 14%20NTRP-TA-II.pdf
13. The application is to be submitted to the Section Officer, CS-III, Department of
Telecommunications, Room No.713, Sanchar Bhawan, 20, Ashoka Road, New Delhi­
110 001.

******

No. 10-12/2012-CS-IIl/Dec 2021

<!-- page 4 -->

4

ANNEXURE-1
GOVERNMENT OF INDIA
MINISTRY OF COMMUNICATIONS
DEPARTMENT OF TELECOMMUNICATIONS
(CARRIER SERVICES CELL)
SANCHARBHAVAN, 20 ASHOKA ROAD, NEW DELHI-110 001.
APPLICATION FOR REGISTRATION OF INFRASTRUCTURE PROVIDER ­
CATEGORY-I (IP-I)
1.

Name of Applicant Company:

2.

Complete postal address with Telephone/FAX Nos.IE-Mail
i) Corporate Office

ii) Registered Office

3.

Address for correspondence with
Telephone/FAX Nos.IE-mail

4.

Name of Authorised contact
person, his designation, address
and Telephone/FAX Nos./Email

5.

Details of payment of processing fee (Refer para 12 of Guideline)

6.
Certified copy of Certificate of Registration along with Articles of Association and
Memorandum of Association to be attached.
No. 10-12/2012-CS-III/Dec 2021

<!-- page 5 -->

5

(To be certified by the Company Secretary/Statutory Auditor and countersigned by
Authorized Signatory duly authorised by the company)
7.
Details of Promoters/Partners/Shareholder in the Company: The Promoters to be
indicated.
S.No.

Name of Promoter I Partner

Indian I Foreign

Equity %age.

(Complete break-up of 100% of equity must be given. Equity holding upto 5% of the total
equity shared among various shareholder can be clubbed but Indian and Foreign equity must
be separate.)
8.

Equity details
Indian: .............. ..
Foreign:
(i)

Land Border sharing country .. . ........ .. . .

(ii)

Others ............. .

Total ............ ..
(Certificate from Company Secretary/ Statutory Auditor and countersigned by
Authorized Signatory duly authorised by the company to be attached)
9.
Resolution· of Board of Directors I other proof that the person signing the application
is authorized signatory, to be attached. Such resolution should be signed with stamp by a
Director but not by authorized signatory himself clearly mentioning the name of the Director
signing the document.
Certificate/Undertaking:
(I)
I hereby certify that I have carefully read the guidelines, for the registration as
Infrastructure Provider-I and I undertake to comply with the terms and conditions
therein.
(II)
I hereby certify that the norms of extant FOi policy including norms related to
investment from entity/ beneficial owners of the country which shares land border
with India are complied with.
(III) I understand that this application if found incomplete in any respect and/or if found
with conditional compliance shall be summarily rejected.
No. 10-12/2012-CS-III/Dec 2021

<!-- page 6 -->

6

(IV)
(V)

(VI)

I understand that all matters relating to the application will be subject to jurisdiction
of courts in Delhi I New Delhi only.
I understand that if at any time any averments made or information furnished for
obtaining the registration is found incorrect then my application and the registration if
granted thereto on the basis of such application shall be cancelled.
I understand that in case it is decided to grant license under section 4 of Indian
Telegraph Act, 1885 to Infrastructure Provider Category-I (IP-I) instead of
registration, at a later date, the said registration shall stand cancelled after the
prescribed period as decided by the competent authority and the Infrastructure
Provider (IP-I) shall have to apply for grant of specified license/authorisation at that
point of time as per terms and conditions applicable for such license/authorisation.

Date:
Place:
Signature and Name of the
Authorised Signatory
(Company's seal)

No. 10-12/2012-CS-III/Dec 2021

<!-- page 7 -->

7

ANNEXURE-11
CHECK-LIST
The following documents should be submitted along with the application for IP-1
Registration:

s.
No
1.

Particulars

Parameters to be checked

Application form in prescribed format with
Date, sign and Stamp

Signed
by
authorized
signatory with stamp
Date & place mentioned
Presently Rs. 5000/- to be
submitted under the IP-1
Registration head

2.

Processing fee as prescribed.

3.

Resolution of Board of Director that the
person signing the application is authorized
signatory. Such resolution should be signed
with stamp by a Director but not by
authorized signatory himself clearly
mentioning the name of the Director
signing the document.

4.

5.

6.

7.

Status
(YIN)

Contains
name
of
authorized signatory
Signed . with stamp by a
Director
but
not
by
authorized signatory himself
Mentions name of the
Director
s1gnmg
the
document.
Signature of the authorized signatory Suitable Document attached
should be attested by any of the other
Director of the company or company
Secretary as the case may be.
by
Company
Certified
copy
of 'Certificate
of Certified
I
Statutory
Registration' duly certified by Company Secretary
Statutory Auditor and Auditor
Secretary I
countersigned by authorized signatory with Countersigned
by
stamp.
authorized signatory with
stamp
the
required
Certified copy of MOA along with the Contains
required clause duly certified by Company clause*
Secretary I Statutory Auditor and Certified
by
Company
countersigned by authorized signatory with Secretary
Statutory
I
stamp.
Auditor
Countersigned
by
authorized signatory with
stamp
Certified copy of AOA duly certified by Certified
by
Company
Statutory
Company Secretary I Statutory Auditor and Secretary
I

No. 10-12/2012-CS-III/Dec 2021

<!-- page 8 -->

8

8.

9.

10.

countersigned by authorized signatory with Auditor
stamp
Countersigned
by
authorized signatory with
stamp
Equity details of Indian & Foreign Certified
by
Company
(Certified by Company Secretary/Statutory Secretary
I
Statutory
auditor and countersigned by authorized Auditor
signatory with stamp)
Countersigned
by
authorized signatory with
stamp
Certified copy of approval of Government Approval
if
attached,
of India for Foreign Equity (To be applicable
applicable if FDI is from an entity of a Certified
by
Company
country, which shares land border with Secretary
I
Statutory
India or beneficial owner of an Auditor
investment into India is situated in or is Countersigned
by
a citizen of any such country)
authorized signatory with
(Certificate from Company Secretary/ stamp
Statutory Auditor and countersigned by
authorized signatory with stamp to be
attached)
List of Board of Directors along with their Nationality
Status
i.e.
nationality (It should be clearly indicated Resident Indian Citizen/Non
that whether they are Resident Indian Resident
Indian/Foreign
Citizen/NRl/Foreign Nationals).
Nationals mentioned against
each director
Countersigned
by
authorized signatory with
stamp

*

MoA shall contain clause which allows the company to do business related to
provisioning of telecom infrastructure . In case the required clause has been inserted after
incorporation of the company, the revised MoA along with certificate issued by ROC
regarding alteration of MoA is to be submitted. Both of these documents (MoA & certificate
issued by RoC) are to be duly certified by Company Secretary/Statutory Auditor and
countersigned by authorized signatory with stamp.

No. 10-12/2012-CS-III/Dec 2021

<!-- page 9 -->

9

ANNEXURE-111
No. 10-xx/2xxx-CS-III
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhavan, 20, Ashoka Road
New Delhi-110001
Registration Certificate No.: xxx/2xxx

Dated: xx.xx.xxxx

Registration Certificate For Infrastructure Provider Cate ory-1 (IP-I )
This is to certify that M/s ------------------------------- with registered office at ----------­
--------------- is registered as Infrastructure Provider Category I (IP-I) to establish and
maintain the assets such as Dark Fibres, Right of Way, Duct Space and Tower for the purpose
to grant on lease/rent/sale basis to the licensees of Telecom Services licensed under Section 4
of Indian Telegraph Act, 1885 on mutually agreed terms and conditions.
2.0
In no case the company shall work and operate or provide telegraph service including
end to end bandwidth as defined in Indian Telegraph Act, 1885 either to any service provider
or any other customer.
3.0
The company shall submit a copy of an Agreement entered into with the telecom
service providers within 15 days of signing of such Agreement.
4.0

The company shall provide the said infrastructure in a non-discriminatory manner.

5.0
In the event of any question, dispute or difference arising under this Registration, or in
connection thereof, except as to the matter, the decision of which is specifically provided
elsewhere under this Registration, the same shall be referred to the sole Arbitrator appointed
and nominated by the Director General Telecommunications or by whatever designation
Director General Telecom may be called, hereinafter called the "ARBITRAL TRIBUNAL" .
5.1
This Registration Certificate and any dispute thereof shall be governed by the
substantive provisions oflndian law.
5.2
The venue of Arbitration shall be New Delhi or .as may be fixed by the ARBITRAL
TRIBUNAL anywhere in India.
5.3
The arbitration proceedings shall be conducted in accordance with the provisions of
the Indian Arbitration and Conciliation Act, 1996 and rules framed there under or any
modifications or re-enactment thereof made from time to time.

No. 10-12/2012-CS-III/Dec 2021

<!-- page 10 -->

10

6.0
The Registered company can provide the infrastructure as stated above to any licensee
of Telegraph services Licensed under section 4 of the Indian Telegraph Act 1885. The
company shall, in no case, grant in any manner the infrastructure to any erstwhile Licensee
whose license is either terminated or suspended or not in operation at given point of time. In
the event of any infrastructure allowed before hand, then the Registered company shall be
obliged to withdraw the grant of infrastructure and to disconnect or sever connectivity
immediately without loss of time and further, upon receipt of any reference from the Licensor
in this regard, disconnection shall be _made effective within an hour of receipt of such
reference. On the question of disconnectivity, the decision of the Director General Telecom
shall be final.
7.0
The Registered company shall provide necessary facilities depending upon the
specific situation at the relevant time to the Government to counteract espionage, subversive
act, sabotage or any other unlawful activity.
7.1
The Registered company shall make available on demand to the agencies authorized
by the Government of India, full access to the network for technical scrutiny and for
inspection which can be visual inspection or any operational inspection.
7.2
All foreign personnel likely to be deployed by the Registered company for
installation, operation and maintenance of the Registered company network shall be security
cleared by the Government of India prior to their deployment. The security clearance will be
obtained from the Ministry of Home Affairs, Government of India, who will follow standard
norms in the matter.
7.3
The Registered company shall ensure protection of privacy of communication and
ensure that unauthorized interception of messages does not take place.
7.4
The Government shall have the right to take over the equipment and networks of the
Registered company or revoke/terminate/suspend the Registration of the company either in
part or in whole as per directions if any, issued in the public interest by the Government in
case of emergency or war or low intensity conflict or any other eventuality. Provided any
specific orders or direction from the Government issued under such conditions shall be
applicable to the Registered company and shall be strictly complied with. Further, the
Government reserves the right to keep any area out of the operation zone of the service if
implications of security so require.
7.5
Government reserves the right to modify these conditions or incorporate new
conditions considered necessary in the interest of national security and public interest.
7.6
The Registered company will ensure that the Telecommunication installation carried
out by it should not become a safety hazard and is or in contravention of any statue, rule or
regulation and public policy.

No. 10-12/2012-CS-III/Dec 2021

<!-- page 11 -->

11

7.7
In case it is decided to grant license under section 4 oflndian Telegraph Act, 1885 to
Infrastructure Provider Category-I (IP-I) instead of registration, at a later date, the said
registration shall stand cancelled after the prescribed period as decided by the competent
authority and the Infrastructure Provider (IP-I) shall have to apply for grant of specified
license/authorisation at that point of time as per terms and conditions applicable for such
license/authorization.
8.0
Any breach of the above terms will lead to cancellation of the registration without any
further notice.

(
)
ADG (CS-III) I DIRECTOR(CS-111)

To
1\1/S ------------------------­

No. 10-12/2012-CS-IIl/Dec 2021
