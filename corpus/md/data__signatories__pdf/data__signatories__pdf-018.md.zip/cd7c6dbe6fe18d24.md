---
doc_id: "cd7c6dbe6fe18d24"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/2142bb8c8b4a72d46bcaf9f863ab0187.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Appointment of Director of IIIT (PPP) Kalyani, West Bengal"
date: "2019-09-01"
pages: 18
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7f2f9c8bd2cca061"
---

<!-- page 1 -->

Government of India
Ministry of Human Resource Development
Department of Higher Education
Technical Section - I
Appointment of Director of IIIT (PPP) Kalyani, West Bengal
Applications are invited, for appointment to the post of Director of Indian
Institute of Information Technology in Public- Private Partnership mode (IIIT-PPP),
Kalyani.
2.

The Director of an IIIT, being the academic as well as administrative head, is

expected to have proven administrative, teaching and research background (including
significant experience in research guidance at the Ph.D level) with the leadership
qualities to head an Institute of National Importance. The candidate should be a Ph.D
in appropriate branch with an outstanding academic record throughout and a
minimum of 7 years experience as a Professor in a reputed Educational Institute
(relaxable in the case of an outstanding candidate). Applicant should preferably be not
more than 60 years of age. The posts carry a fixed pay of Rs. 2,10,000/- (Fixed) as per
7th CPC plus Special Allowance of Rs. 11,250/- per month with allowances as
admissible under the Rules of the Institute.
3.

The IIIT Kalyani is an autonomous institution established in PPP mode, with

participation from the Central Government, the concerned State Government, and the
Industry Partner(s). The first Director of Institute is being appointed. The Director will
be appointed after obtaining the approval of the Competent Authority based on the
recommendations made by the Search-cum-Selection Committee. The Search-cumSelection Committee will consider applications received in response

to this

advertisement, as well as nominations received from eminent persons. The
appointment will be on contractual basis for a period of five years or till the attainment
of 70 years, whichever is earlier, as per usual terms and conditions.
4.

Interested individuals may apply giving detailed resume in the format available

on the website (www.mhrd.gov.in). The application along with enclosures may be sent

<!-- page 2 -->

by Registered/Speed Post to Under Secretary, Department of Higher Education,
Ministry of Human Resource Development, Room No.203, ‘C’ Wing, Shastri
Bhawan, New Delhi – 110001 so as to reach within 30 days from the date of this
advertisement.
5.

Persons employed in Government Departments, Autonomous Organizations and

Public Sector Undertakings, should send their applications through proper channel
with an Advance Copy to the above address. Envelope containing the application form
should have inscribed on top of it “APPLICATION FOR THE POST OF DIRECTOR,
IIIT(PPP), KALYANI”. One copy (in MS-Word format) of the application must be sent
electronically to praveersaxena.edu@nic.in within the prescribed period.

<!-- page 3 -->

Format of Application for the post of Director of IIIT (PPP) Kalyani

Affix the latest
passport size Photo

(Applicant is requested to type the information in the following format, and can add more lines in
the format wherever required.)

1. General Information of Applicant
Name
(In Capital Letters)
Date of Birth
(Day/Month/Year)
Correspondence
Address

Mobile No. :
Phone No.
Landline No. :
Email

2. Present Position
a.

Designation

b.

Organization

c.

Pay Scale

d.

Date of appointment
to the present post

e.

Total Experience
(In Years and
Months)

<!-- page 4 -->

3. Details of experience possessed as per eligibility criteria:
(7 years’ Professorship)
S.No.

Post held

Pay Scale

Organisation

Nature of duties

Experience
(In Years and
Months)

Educational Qualification (In chronological order from latest to Graduation level)
S.No.

Qualification

University

Year

Subject(s) /
Topic(s)

% Achieved Distinctions etc.

5. Administrative Experience/Post(s) & responsibilities held
S. No. Post

1.
2.

Organization/
University

Duration
From
To
(Date)
(Date)

Experience
(In Years and
Months)

Head of the Department
Chairman, Professional/
Academic Bodies
Member, Board of Studies
Dean of Faculty
Member of Academic
Council/Senate
Member of Executive
Council/BoG
Member of Professional/
Academic Bodies
Others (Specify)

3
4.
5.
6.
7.
8.

6. (a) Academic/Teaching Experience & responsibilities (In chronological order from
latest to oldest)
S. No.

Post

Organization/
University

From
(Date)

Duration
To
(Date)

Experience
(In Years and
Months)

<!-- page 5 -->

b. Participation and contribution in relevant areas in higher education
Organisation

Area of specialisation

Visiting Professor
Resource Person
Others (Specify)
(c) Involvement with formulation of academic programmes:
S.No.

Nomenclature of Innovative Academic Programmes Date of approval by
formulated
Senate

Year of
Introduction

(d) Important MoUs formulated for academic collaborations:
S. No. MoUs formulated

Name of Agencies/Departments
involved

Year of MoU

Name of Agencies/Departments
involved

Period of holding
the Chair

(e) Position of Chairs:
S. No. Name of Chair

7. International academic Exposure, if any
S. No.

Post/
Assignment

Organization/
Institute

Area of Assignment
From

8. Scholarly achievements:

Contribution to Journals and Books:
Details
Books authored
Editor in Chief
Editorships
Peer reviewer for
Member of the International Advisory
Board
Others (Specify)

Duration
To
In Years &
Months

<!-- page 6 -->

Publications:
B.I Kindly provide list of scholarly publications in recognised professional and/or
academic journals:

Total Publications: ………….
S.No.

Date

Title

Name of journal

Refereed
journal or
not

Number of
Citations
(where possible)

B.II List of articles in popular magazines or newspapers

Total Articles: ………..
S.No.

Date

Title

Name of Magazine/
Newspaper

C. Participation and scholarly presentations in conferences:
C.I National
S.No.

Date

Title of Conference or Institution

Title/Subject of presentation (if made)

Title of Conference or Institution

Title/Subject of presentation (if made)

C.II International
S.No.

Date

D. Participation and contribution in National/International Fora in the area of your
academic and professional expertise
Number(s)
Plenary Lectures/Invited Talks
Congresses attended
Examinership etc.

International
National
International
National
International

<!-- page 7 -->

National
International
National

Others (Specify)
9. Research Projects:
S.No. Client/Organisation’s
name

Nature of project

Duration of
project

10. Consulting experience:

List key consulting assignments undertaken:
S.No. Client/ Organisation’s name Nature of assignment

Duration of
assignment

11. Honours /Awards & Fellowships for Outstanding Work:

Sr. No. Name of
Elected/Honorary
Award/Fellowship etc. Fellow

Awarded by

Year of Award

12. No. of Research Scholars successfully guided :

Name of Programme

Awarded (No.) (Under-progress not to be included)

13. Strengths (in 100 words)

14. Your Vision for the Institute (upto 500 Words)

Amount of
grant
(Rupees)

<!-- page 8 -->

15. Details of Referees, if any
S. No.

Name of the Referee Post Held by
Referee

Email

Phone No.

Mobile

I, hereby, declare that all the statements/ particulars made/furnished in this application are true,
complete and correct to the best of my knowledge and belief. I also declare and fully understand that in
the event of any information furnished being found false or incorrect at any stage, my
application/candidature is liable to be summarily rejected at any stage and if I am already appointed, my
services are liable to be terminated without any notice from the post of Director as per Act/ Statutes etc.
and other applicable rules.

Place:
Date:

(Signature of the Applicant)

Note: Total No. of pages (A-4 size) of the application should not exceed 10 pages.

<!-- page 9 -->

भारत सरकार

मानव संसाधन ववकास मंत्रालय
उच्चतर शिक्षा ववभाग
तकनीकी अनुभाग –।

भासूप्रौसं (पीपीपी) कल्याणी, पश्चिम बंगाल में निदे शक की नियुश्‍ि
भारतीय सूचना प्रौद्योगगकी संस्थान, कल्याणी (जन-ननजी भागीदारी प्रणाली) (आईआईआईटी-पीपीपी),
में ननदे िक के पद पर ननयक्ु ‍त के शलए आवेदन आमंत्रत्रत ककए जाते हैं।
2.

अकादशमक के साथ-साथ प्रिासननक प्रमुख होने के नाते भासप्र
ू ौसं के ननदे िक से यह अपेक्षा

की जाती है कक उनकी प्रमाणणत प्रिासननक, शिक्षण और िोध पष्ृ ठभूशम (पीएच.डी स्तर पर िोध

मागगदिगन में महत्वपूणग अनभ
ु व सहहत) होने के साथ राष्रीय महत्व के संस्थान का अध्यक्ष होने के
शलए अपेक्षक्षत नेतत्ृ व क्षमता भी हो। अभ्यथी पूणत
ग या उत्कृष्ट अकादशमक ररकॉडग के साथ उपय‍
ु त

िाखा में पीएच.डी होना चाहहए तथा ककसी प्रख्यात िैक्षणणक संस्थान में प्रोफेसर के रूप में न्यि
ू िम

7 वर्ष का अिुभव प्राप्त हो (उत्कृष्ठ अभ्यथी के मामले में अनुभव मे छूट दी जा सकती है )। 60
वर्ग से कम आयु वाले उम्मीदवारों को वरीयता दी जाएगी। इस पद पर सातवें केंद्रीय वेतन आयोग
के अनुसार संस्थान के ननयमों के अधीन यथा स्वीकायग भत्ते और 11,250/- प्रनत माह के वविेर्
भत्ते सहहत 2,10,000/- (ननयत) का ननयत वेतन ननधागररत ककया गया है ।
3.

भासप्र
ू ौसं कल्याणी, केंद्र सरकार, पक्चचम बंगाल सरकार की सहभागगता से जन-ननजी

भागीदारी प्रणाली में स्थावपत एक स्वायत्त संस्था है । संस्थान के पहले ननदे िक को ननयु‍त ककया
जा रहा है । ननदे िक की ननयुक्‍त खोज-सह-चयन सशमनत द्वारा की गई शसफाररिों के आधार पर

सक्षम प्रागधकारी का अनम
ु ोदन प्राप्त करने के पचचात ् की जाएगी। खोज-सह-चयन सशमनत इस

ववज्ञापन के प्रत्यत्ु तर में प्राप्त आवेदनों के साथ-साथ ववशिष्ट व्यक्‍तयों से प्राप्त नामांकनों पर
ववचार करे गी। यह ननयक्ु ‍त, पांच वर्ग की अवगध के शलए अथवा 70 वर्ग की आयु प्राप्त करने तक,
जो भी पहले हो, सामान्य ननबंधन और ितों के अनुसार संववदात्मक आधार पर की जाएगी।
4.

इच्छुक व्यक्‍त, वेबसाइट (www.mhrd.gov.in) पर उपलब्ध प्रारूप में ववस्तत
ृ वववरण दे ते

हुए आवेदन कर सकते हैं। संलग्नकों सहहत आवेदन अवर सचिव, उच्ििर शशक्षा ववभाग, मािव
संसाधि ववकास मंत्रालय, कमरा िं.203 ‘सी’ ववंग, शास्‍तत्री भवि, िई ददल्ली -110001 को इस
ववज्ञापन की तारीख से 30 हदनों के भीतर पंजीकृत डाक/स्पीड पोस्ट से भेजा जा सकता है ।
5.

सरकारी ववभागों, स्वायत्त संगठनों और सरकारी क्षेत्र के उपक्रमों में ननयोक्जत व्यक्‍त

उपयु‍
ग त पते पर अगिम प्रनत के साथ उगचत माध्यम से अपने आवेदन भेज सकते हैं। आवेदन पत्र

के शलफाफे पर “ननदे िक, आईआईआईटी (पीपीपी), कल्याणी के पद के शलए आवेदन” शलखा होना

<!-- page 10 -->

चाहहए। आवेदन की एक प्रनत ननधागररत अवगध में praveersaxena.edu@nic.in को (एमएस-वडग
प्रारुप में ) इले‍रॉननक रूप में अवचय भेजी जानी चाहहए।

<!-- page 11 -->

भारिीय सूििा प्रौद्योचगकी संस्‍तथाि, कल्याणी के निदे शक के पद के शलए आवेदि का प्रारुप

नवीनतम पासपोटग
आकार का फोटो
गचपकाएं

(आवेदक से अिुरोध ककया जािा है कक निम्िशलखिि प्रारुप में जािकारी टाइप करें , और जहााँ
भी आवचयकिा हो, प्रारुप में और लाइिें जोड़ ले.)
2. आवेदक की सामान्य जािकारी
िाम
(स्‍तपष्ट अक्षरों में )
जन्म निचथ
(ददि /माह / वर्ष)
पत्रािार का पिा

मोबाइल नं. :

फोि िम्बर

लैंडलाईन नं. :
ईमेल
3. विषमाि पद
क.

पदिाम

ख.

संगठि

ग.

वेििमाि

घ.

विषमाि पद पर
नियुश्‍ि की निचथ

<!-- page 12 -->

ड.

कुल अिुभव

(वर्ग और महीनों में )
3. पात्रिा मािदं ड के अिुसार अिुभव का ब्यौरा:
(7 वर्ष की प्रोफेसरशशप)
क्र.सं.

धाररत पद

वेतनमान

संगठन

कायग की प्रकृनत

अनुभव (वर्ग और
महीनों में )

4. शैक्षखणक अहष िा

क्र.सं.

अहषिा

(िवीििम से स्‍तिािक स्‍तिर िक कालािक्र
ु म में )
ववचवववद्यालय वर्ष

ववर्य / शीर्षक प्राप्ि %

ववशेर् योग्यिा
आदद

5. प्रशासनिक अिुभव/ पद और धाररि दानयत्व
क्र.सं.. पद

संगठि /

ववचवववद्यालय से

अवचध
िक

(निचथ) (निचथ)

1.

ववभागाध्यक्ष

2.

अध्यक्ष, व्यावसानयक / िैक्षणणक ननकाय

3

सदस्य, अध्ययन बोडग

4.

संकाय के डीन

5.

अकादशमक पररर्द/ सीनेट के सदस्य

6.

कायगकारी पररर्द/िासी बोडग के सदस्य

7.

व्यावसानयक/िैक्षक्षक ननकाय के सदस्य

8.

अन्य (ननहदग ष्ट करें )

अिभ
ु व (वर्ष और
महीिों में )

<!-- page 13 -->

6. (क) शैक्षखणक/शशक्षण अिुभव और दानयत्व (िवीििम से सबसे पुरािे कालािुक्रम
में )
क्र.सं..

ि.

पद

संगठि /

ववचवववद्यालय

अवचध
से

िक

(निचथ)

(निचथ)

अिभ
ु व (वर्ष

और महीिों में )

उच्ि शशक्षा में संबंचधि क्षेत्रों में भागीदारी और योगदाि
संगठि

भागीदारी का क्षेत्र

अनतगथ प्राध्यापक
संसाधन व्यक्‍त
अन्य (ननहदग ष्ट करें )
(ग) शैक्षखणक कायषक्रमों को िैयार करिे में भागीदारी:
क्र. सं.

िैयार ककए गए िवािारी शैक्षक्षक कायषक्रमों की
िामावली

सीिेट द्वारा अिुमोदि प्रारम्भ करिे
की निचथ

की निचथ

(घ) शैक्षक्षक सहयोग के शलए महत्वपूणष एमओयू:
क्र.सं. िैयार ककए गए एमओयू

शाशमल एजेंशसयों/ववभागों के िाम एमओयू का वर्ष

(ड.) पदों की श्स्‍तथनि :
क्र. सं. पद का िाम

शाशमल एजेंसीयों/ववभागों के िाम धाररि पद की अवचध

<!-- page 14 -->

7. अंिराषष्रीय शैक्षखणक ए‍सपोजर, यदद कोई हो
क्र.सं.

पद /

संगठि/संस्‍तथाि

सौंपे

कायष का क्षेत्र

गए

अवचध
से

कायष

िक

(वर्ष और
महीिों में )

8. ववद्वि ् उपलश्ब्धयां:
पत्रत्रकाओं और पस्‍त
ु िकों में योगदाि:

ब्यौरा

शलखी गई पुस्तकें
मुख्य संपादक
संपादन
सहकमी समीक्षक
अंतरागष्रीय सलाहकार बोडग के सदस्य
अन्य (ननहदग ष्ट करें )
प्रकाशि:
ि.I मान्यिाप्राप्ि व्यावसानयक और/या शैक्षक्षक पत्रत्रकाओं में ववद्विा प्रकाशि की
सूिी प्रदाि करें :
कुल प्रकािन: ………….
क्र.सं.

निचथ

शीर्षक

पत्रत्रका का िाम

पत्रत्रका

उद्धरणों की

<!-- page 15 -->

संदशभषि

संख्या

ककया या

(जहां संभव हो)

िहीं

ि.II लोकवप्रय पत्रत्रकाओं या समािार पत्रों में लेिों की सूिी
कुल लेि: ………..
क्र.सं.

निचथ

शीर्षक

पत्रत्रका/समािार पत्र का िाम

ग. सम्मेलिों में सहभाचगिा और ववद्विापण
ू ष प्रस्‍तिनु ियााँ:

ग.I राष्रीय
क्र.सं. निचथ

सम्मेलि या संस्‍तथा का िाम

प्रस्‍तिनु ि का शीर्षक/ववर्य (यदद की गई हो)

सम्मेलि या संस्‍तथा का िाम

प्रस्‍तिुनि का शीर्षक/ववर्य (यदद की गई

ग.II अंिराषष्रीय
क्र.सं.

निचथ

हो)

घ. आपकी शैक्षखणक और व्यावसानयक ववशेर्ज्ञिा के क्षेत्र में राष्रीय/अंिराषष्रीय मंिों में भागीदारी

और योगदाि
संख्या
प्लेनरी व्याख्यान / आमंत्रत्रत वाताग अंतरागष्रीय
राष्रीय

<!-- page 16 -->

कांिेस क्जसमें भाग शलया

अंतरागष्रीय
राष्रीय

कायग, परीक्षक / आहद

अंतरागष्रीय

अन्य (ननहदग ष्ट करें )

अंतरागष्रीय

राष्रीय
राष्रीय

9. शोध पररयोजिाएं :
क्र.सं. ग्राहक/संगठि का िाम

पररयोजिा की प्रकृनि

पररयोजिा की अिुदाि
अवचध

की राशश
(रुपए)

10. परामशष अिुभव:
ककए गए मुख्य परामशष कायों की सूिी:

क्र.सं. ग्राहक /संगठि का िाम

कायष की प्रकृनि

कायष की अवचध

12. ववशशष्ट कायष के शलए ऑिसष/अवाडष एवं फेलोशशप :
क्र.सं. अवाडष/ फेलोशशप आदद ियनिि/ऑिररी फेलो
का िाम

द्वारा प्रदाि
ककया गया

13. सफलिापव
ष मागषदशशषि ककए गए शोध छात्रों की संख्या :
ू क

प्रदाि ककए जािे का वर्ष

<!-- page 17 -->

कायषक्रम का िाम

प्रदत्त पीं एि डी की संख्या (अभी िल रहे कायषक्रम को शाशमल िहीं
करिा है )

14. निपुणिा ( 100 शब्दों में )

14. संस्‍तथाि के शलए आपकी योजिा ( 500 शब्दों में )

15. रे फरी का ब्यौरा, यदद कोई हो
क्र.सं.

रे फरी का िाम

रे फरी द्वारा
धाररि पद

ईमेल

फोि िंबर

मोबाइल

<!-- page 18 -->

मैं, एतदद्वारा, घोर्णा करता हूं कक इस आवेदन में हदए गए/ भेजे गए सभी कथन / वववरण, मेरी
जानकारी और ववचवास के अनुसार सत्य, पूणग और सही हैं। मैं यह भी घोवर्त करता हूं और पूरी
तरह से समझता हूं कक ककसी भी सूचना को ककसी भी स्तर पर शमथ्या या गलत पाए जाने की
क्स्थनत में , मेरा आवेदन/उम्मीदवारी ककसी भी स्तर पर तत्काल ननरस्त ककया जा सकता है
और यहद मैं पहले से ननयु‍त हूं, तो अगधननयम/संववगधयों आहद और अन्य लागू ननयमों के
अनस
ु ार ननदे िक के पद से ककसी भी नोहटस के त्रबना मेरी सेवाएं समाप्त की जा सकती हैं।

स्थान:

(आवेदक के हस्ताक्षर)

हदनांक:
िोट: आवेदि के कुल पष्ृ ठों की संख्या (A-4 आकार) 10 पष्ृ ठों से अचधक िहीं होिी िादहए।
