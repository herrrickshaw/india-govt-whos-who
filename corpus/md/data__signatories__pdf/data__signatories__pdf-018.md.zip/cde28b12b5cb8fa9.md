---
doc_id: "cde28b12b5cb8fa9"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/4fa5893c6803929dd810cd856f3474da.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "List of amendments carried out in LOIs/Registrations"
date: "2025-07-25"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "34696332e86a63b4"
---

<!-- page 1 -->

4.5 LIST OF AMENDMENTS CARRIED OUT IN THE LETTERS OF INTENT DURING JUNE 2002

S.NO

NAME OF THE COMPANY

LI.NO.&DATE

AMENDMENT CARRIED OUT

NO.&DATE

1.

M/s.Aurobindo Pharma Ltd,

LI:105/2000

LI:105(2000)02

Hyderabad.

Dt.13.7.2000

Inclusion of the item "Drotaverine
Hydrochloride with an annual
capacity of 24 Metric tonnes at
S.No.11 of para 1 of LOI.

M/s.Sportking India Ltd,.

LI:124(93)

LI:124(93)/2002

New Delhi.

Dt.24.3.93

Enhancement of the the capacity of
Acrylic/Synthetic yarn from 6500
Spindles to 10,000 Spindles.

M/s.GTN Textiles Ltd,

LI:109(99)

LI:109(99)200207-10 dt.17.6.02

Hyderabad.

Dt.8.11.99

Enhancement of the the capacity of
100% Grey Combed Carded Cotton
yarn on cones from 28,900 Spindles
to 30,700 Spindles.(After expansion)

M/s.Maimoor Enterpriese
&Consultants, Maharashtra.

LI:42(2001)

Amendment in item of mfg.&
capacity due to clubbing of capacities
of Industrial explosives and SM buklk
explosives.

LI:42(2001)2002
dt.17.6.02

Inclusion of new item Processing of
Fabric (Washing, Dyeing, Printing
etc.) with an annual capacity of 300
Metic tonnes.

LI:52(2000)02

2

3.

4

Dt.8.3.01

5.

M/s.Bhandari Hosiery Exports
Ltd, Ludhiana.

LI:52(2000)
Dt.28.4.00

Dt.14.6.02

Dt.17.6.02

Dt.17.6.02
