---
doc_id: "d082ba14efed27ec"
source_url: "https://powermin.gov.in/static/uploads/2025/07/9679793a906a23a69611f2f7e4a37229.pdf"
ministry: "Power"
title: "Extension of timeline for submission of the comments - Amendments to the Guidelines for TBCB for procurement of power from Grid Connected power projects"
date: "2025-07-01"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "fb081734b40e61b8"
---

<!-- page 1 -->

No.48-19/2/2024-NRE
Government of India
Ministry of Power
2K
Shram Shakti Bhawan, Rafi Marg,
New Delhi, dated the 11°" Nov, 2024
To,
1. Secretary, MNRE, New Delhi
2. Chairperson, Central Electricity Authority, Sewa Bhavan, R.K. Puram,
New Delhi
3. Secretary, Central Electricity Regulatory Commission (CERC), New Delhi
4. Principal Secretaries/Secretaries (Power/Energy) of all State
Governments/UTs
5. Secretaries of All State Electricity Regulatory Commissions/JERCs.
6. Chairman/CMDs of all PSUs under administrative control of Ministry of
Power
7. CMD, SECI, New Delhi
8. CMDs/MDs of Discoms/Gencos of all State Governments
9. CMD, IEX LTD New Delhi & MD/CEO, PXIL , Mumbai
10. DG, Association of Power Producers, New Delhi.
11. President, FICCI, House No. 1, Tansen Marg New Delhi
12. President, Cll, New Delhi
13. President, PHDCCI, New Delhi
14, ASSOCHAM, Chanakyapuri, New Delhi
15. Member, PRAYAS Energy Group, Pune
16. DG, Electric Power Transmission Association (EPTA), New Delhi
17. Chairman Indian Wind Power Association, New Delhi 5
18. Chairman, Indian Wind Turbine Manufacturers Association, New Delhi
19. Director General, National Solar Energy Federation of India (NSEFI), New
Delhi.
Subject: Amendment to the Guidelines for Tariff Based Competitive
Bidding Process for Procurement of Power from Grid connected
Power Projects - Extension of timelines for submission of comments-
reg.
Sir/Madam,
| am directed to inform that the last date for submission of
stakeholders comments on the draft amendment to the Guidelines for Tariff
Based Competitive Bidding Process for Procurement of Power from Grid
connected (i) Solar Power Projects (ii) Wind Power Projects (iii) Wind
Solar Hybrid Projects and (iv) Firm and Dispatchable Power from
Grid connected Renewable Energy Power Projects with Energy
Storage Systems, is extended herewith for 15 days i.e. 24.11.2024. The
comments may be emailed at nre.section-mop@gov.in within the
stipulated timeline.
2 This issues with the approval of Competent Authority.
Yours faithfully,

<!-- page 2 -->

1
Encl: As above. adie gp ok
— |; wnt
(Sunil Sharma)
Director (NRE)
Tel: 011-2306-2914
Copy for information to: PS to Hon'ble Minister for Power and Housing &
Urban Affiars, APS to MoSP, PPS to Secretary (P), Sr. PPS to AS(P), PSO to CE
(R&R), Ministry of Power.
Copy to: Technical Director, NIC Cell for uploading on MOP's website under
“Current Notices” with the heading of “Extension of timeline for seeking
comments on Amendment to the Guidelines for Tariff Based
Competitive Bidding Process for Procurement of Power from Grid
connected Power Projects”,
