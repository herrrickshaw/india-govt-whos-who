---
doc_id: "d0c878b3d97abbec"
source_url: "https://mines.gov.in/admin/download/68073b0fe338c1745304335.pdf"
ministry: "Mines (MoM)"
title: "Notification under second proviso to sub section 1 of section 4 of MMDR Act 1957 (1.66 MB)"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "6fde7428395fb930"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-17042025-262495
xxxGIDHxxx
CG-DL-E-17042025-262495
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 1731]
No. 1731]

नई दिल्ली, बुधिार, अप्रैल 16, 2025/चैत्र 26, 1947
NEW DELHI, WEDNESDAY, APRIL 16, 2025/CHAITRA 26, 1947

खान मंत्रालय
अजधसूचना
नई दिल्ली, 16 अप्रैल, 2025
का.आ. 1764(अ).—के न्द्रीय सरकार, खान और खजनि (जिकास और जिजनयमन) अजधजनयम, 1957 (1957 का
67) की धारा 4 की उपधारा (1) के िूसरे परं तुक द्वारा प्रित्त िजियों का प्रयोग करते हुए और भारतीय गुणित्ता पररषि के
राष्ट्रीय जिक्षा और प्रजिक्षण प्रत्यायन बोडड द्वारा प्रित्त प्रत्यायन के पररणामस्ट्िरूप, भारत सरकार, खान मंत्रालय के तारीख
12 अगस्ट्त, 2021 के आिेि संख्या एम.VI-16/15/2021-खान VI के द्वारा िारी प्रत्याजयत जनिी खोि अजभकरणों को
अजधसूजचत करने के जलए मागडििडक जसद्ांतों के अनुसार "श्रेणी 'क' खोि अजभकरणों" के अधीन मैससड ह ि
ं मेटल
एक्सप्लोरे िन सर्िडसेि प्राइिेट जलजमटेड को अजधसूजचत करती ।ै
2. उि अजभकरण, उि मागडििडक जसद्ांतों में जिजनर्िडष्ट ितों के अनुपालन में पूिेक्षण संदियाएं करेगा।
3. य अजधसूचना रािपत्र में इसके प्रकािन की तारीख से प्रिृत्त ोगी और इसके प्रकािन की तारीख से तीन िषड की
अिजध के जलए या स्ट्िीकृ त प्रत्यायन के अिसान पर या इसके समाप्त ोने तक, िो भी प ले ो, जिजधमान्द्य र ग
े ी।
[फा. सं. एम.VI-16/22/2022-खान VI]
दिनेि माहुर, संयुि सजचि

2578 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF MINES
NOTIFICATION
New Delhi, the 16th April, 2025
S.O. 1764(E).—In exercise of the powers conferred by the second proviso to sub-section (1) of section 4 of
the Mines and Minerals (Development and Regulation) Act, 1957 (67 of 1957) and consequent upon accreditation
provided by the National Accreditation Board for Education and Training of the Quality Council of India, the Central
Government hereby notifies the M/s Hindmetal Exploration Services Private Limited under “Category ‘A’
Exploration Agencies” as per the guidelines for notification of accredited private exploration agencies issued by the
Government of India in the Ministry of Mines, vide order No. M.VI-16/15/2021-Mines VI, dated the 12th August,
2021.
2. The said agency shall carry out prospecting operations in compliance with the conditions specified in the said
guidelines.
3. This notification shall come into force on the date of its publication in the Official Gazette and shall remain valid
for a period of three years from the date of its publication or till the expiry or termination of the accreditation granted,
whichever is earlier.
[F. No. M.VI-16/22/2022-Mines VI]
DINESH MAHUR, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. GORAKHA NATH YADAVA

Digitally signed by GORAKHA NATH
YADAVA
Date: 2025.04.17 15:49:27 +05'30'
