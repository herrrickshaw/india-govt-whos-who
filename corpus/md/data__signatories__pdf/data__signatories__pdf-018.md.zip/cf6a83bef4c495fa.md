---
doc_id: "cf6a83bef4c495fa"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/0a37f743f844c49ccb3430f293044c0f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Guidelines for merger of licences in a service area"
date: "2004-02-21"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "48ba9758128a31f5"
---

<!-- page 1 -->

Government of India
Ministry of Communications and Information Technology
Department of Telecommunications
Sanchar Bhawan, 20 Ashok Road, New Delhi-110 001.
No.20-232/2004-BS.III

Dated, the 21st February, 2004.
OFFICE MEMORANDUM

Sub: Guidelines for merger of licences in a service area.
In keeping with the policy of bringing in sustained reforms in the Telecom
sector in India for making the service available in the most efficient and
affordable manner, Government have decided, after due consideration of the
recommendations of Telecom Regulatory Authority of India, the following
Guidelines for merger of Basic, Cellular and Unified Access Service licences in a
given Service Area for proper conduct of Telegraphs and Telecommunication
services, thereby serving the public interest in general and consumer interest in
particular: 1.

Merger of licences shall be restricted to the same service area.

2.
Merger of licence consequent to mergers/acquisitions or restructuring of
the operations shall be permitted in the following category of licences:
(i)
(ii)
(iii)
(iv)
(v)

Cellular Licence with Cellular Licence;
Basic Service Licence with Basic Service Licence;
Unified Access Services Licence (UASL) with Unified Access Services
Licence;
Basic Service Licence with Unified Access Services Licence;
Cellular Service Licence with Unified Access Services Licence;

In case of a merger of a basic service license with UASL, the basic service
licensee shall pay, at the time of application for merger, the difference of amount
of the entry fee, if any, as per the Guidelines for migration to UASL dated
11.11.2003.
3.
Merger of licences will be permitted subject to the condition that there are
at least three operators in that service area for that service, consequent upon
such merger. It is clarified that Unified Access Service Licensee will be counted
for Basic as well as Cellular service separately while deciding the number of
operators in a given service area.

Final Merger OM 20-232-04(21.2.04)1_0.doc

1

<!-- page 2 -->

4.
Prior approval of the Department of Telecommunications will be necessary
for merger of the licence.
The findings of the Department of
Telecommunications would normally be given in a period of about four weeks
from the date of submission of application.
5.
Any merger, acquisition or restructuring, leading to a monopoly market
situation in the given Service Area, shall not be permitted. Monopoly market
situation is defined as market share of 67 per cent or above within a given
Service Area, as on the last day of previous month. Subscriber base shall be
criteria for computing the market share. For example, if an application is made
on the 10th January, the market share as on 31 st December of the previous year,
shall be taken into account.
For this purpose, the market will be classified as
fixed and mobile separately. The category of fixed subscribers shall include wireline subscribers and fixed wireless subscribers. The number of subscribers shall
be as per the Exchange Data Records. The category of mobile subscribers shall
include limited mobile subscribers and full mobile subscribers. The subscriber
figure, as per the Home Location Register (HLR) and Exchange Data Record shall
be taken into account for the purpose of calculating the number of mobile
subscribers in a given Service Area. Further, the Department is at liberty to
verify these figures from any other source. In case of merger of two Unified
Access Service Licences, the total subscriber base of each will be taken into
account.
6.
Consequent upon the Merger of licences, the merged entity shall be
entitled to the total amount of spectrum held by the merging entities, subject to
the condition that after merger, the amount of spectrum shall not exceed 15 MHz
per operator per service area for Metros and category ‘A’ Service Areas, and 12.4
MHz per operator per service area in category ‘B’ and category ‘C’ Service Areas.
Subject to these limits, the merged spectrum will remain with the merged entity
and would be treated as a starting point for further allocation and revision, as
per the detailed Spectrum Guidelines to be issued separately. The guidelines on
efficient utilization of spectrum and its pricing shall be applicable.
7.
The spectrum utilization charges beyond 10 + 10 MHz for GSM based
system and 5 + 5 MHz for CDMA/ETDMA based systems shall be prescribed
separately. The merged entity will have to pay the prescribed charges from the
date of merger of licences.
8.
Discretion to choose the band to surrender the spectrum beyond the
ceiling will be of the new entity.
9.
All dues, if any, relating to the licence of the merging entities in that given
service area, will have to be cleared by either of the two parties before issue of
the permission for merger of licences.
10.
Subject to the orders of the Telecom Disputes Settlement and Appellate
Tribunal (TDSAT), in Appeal No. 11/2002 (BSNL Vs. TRAI) it may be noted that
Final Merger OM 20-232-04(21.2.04)1_0.doc

2

<!-- page 3 -->

TRAI has already classified an operator having market share greater or equal to
30% of the relevant market as one having “Significant Market Power” (SMP) in
its Reference Interconnect Offer (RIO). In case the merged entity becomes an
SMP post merger, then the extant rules & regulations applicable to SMPs would
also apply to the merged entity.
11.
The dispute resolution shall lie with Telecom Dispute Settlement and
Appellate Tribunal as per TRAI Act 1997 as amended by TRAI (Amendment) Act
2000.
12.
While granting permission for merger of licences, the Licensor may,
suitably amend / relax/waive the conditions in the respective licences relating to
the Clause on holding of ‘substantial equity’.
13.
LICENSOR reserves the right to modify these guidelines or incorporate
new guidelines considered necessary in the interest of national security, public
interest and for proper conduct of telegraphs.
14.
These Guidelines can be reviewed after a period of one year, or earlier if
warranted.

(Sukhbir Singh)
Director (BS.III)

Final Merger OM 20-232-04(21.2.04)1_0.doc

3

<!-- page 4 -->

Government of India
Ministry of Communications and Information Technology
Department of Telecommunications
Sanchar Bhawan, 20 Ashok Road, New Delhi-110 001.
No.20-232/2004-BS.III

Dated, the 17th March, 2004.
MEMORANDUM

Sub: Guidelines for merger of licences in a service area – Clarification regarding
effective date.
In continuation of this office O.M. even number dated 21 st February, 2004
on the above mentioned subject, it is clarified that the duration of licence of the
merged entity will be equal to the duration of Licence of acquiring company.
For example, if licence `B’ is merging with Licence `A’, then the duration of
Licence `A’ will be applicable for merged entity.

(Govind Singhal)
Director (BS.III)

Final Merger OM 20-232-04(21.2.04)1_0.doc

4
