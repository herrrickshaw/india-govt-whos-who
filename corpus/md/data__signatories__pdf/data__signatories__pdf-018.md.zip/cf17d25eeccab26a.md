---
doc_id: "cf17d25eeccab26a"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2026/05/6e3e0703cefbb34b760a36653f64112b.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "The Medical Termination of Pregnancy (Amendment) Bill, 2014"
date: "2026-05-07"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b3d984dbd8a1273"
---

<!-- page 1 -->

<!-- page 2 -->

Department of Health and Family Welfare
DRAFT MEDICAL TERMINATION OF PREGNANCY (AMENDMENT) BILL, 2014

<!-- page 3 -->

Department of Health and Family Welfare
DRAFT MEDICAL TERMINATION OF PREGNANCY (AMENDMENT) BILL, 2014

<!-- page 4 -->

Department of Health and Family Welfare
DRAFT MEDICAL TERMINATION OF PREGNANCY (AMENDMENT) BILL, 2014

<!-- page 5 -->

Department of Health and Family Welfare
DRAFT MEDICAL TERMINATION OF PREGNANCY (AMENDMENT) BILL, 2014

<!-- page 6 -->

Department of Health and Family Welfare
DRAFT MEDICAL TERMINATION OF PREGNANCY (AMENDMENT) BILL, 2014
