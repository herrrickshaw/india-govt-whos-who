---
doc_id: "cea8078cdaeff9fe"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/ba37ee4b303085ae0058f56d6b0011a5.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 937 of 2024 in the Hon’ble High Court of Delhi: DoT instructions dated 22.04.2026 to ISPs"
date: "2026-07-22"
pages: 71
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "064189681605f0d7"
---

<!-- page 1 -->

4-10/2025-DGT/4(Part-VII)

I/3422921/2026

By Email/ DoT Website

File No.: 4-10/2025-DGT/4(Part-VII)
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
nd
2 Floor, UIDAI HQ, New Delhi -110001
Date: 22-07-2026
To
All Licensees with Internet Service Authorization
Subject: CS(COMM) 937 of 2024: Zee Entertainment Enterprises Limited
versus Bollyzone.tv & Ors. in the Hon'ble High Court of Delhi.
Please ﬁnd enclosed the Hon’ble High Court of Delhi order dated
24.10.2024 in the captioned suit.
2.
Please refer to para 41(vi, vii & viii) of the said Court order in respect of
blocking access to the websites/domains [ 59 nos.] enumerated in the 25th, 26th,
27th, 28th ,29th & 30th list of Additional websites, received from the Counsel for
plaintiffs.
3.
In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access
to the said website(s)/domain(s), as per the enclosed list, in compliance with the
said court orders.
Encl: A/A
AD(T)
Email: adt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court
order/ enclosed Annexure pl.
ii.)
Sh. Angad Makkar (angad@saikrishnaassociates.com), Counsel for
plaintiﬀs- For kind information and with a request to take action as per the enclosed
Annexure pl.

<!-- page 2 -->

4-10/2025-DGT/4(Part-VII)

C.S. (COMM.) 937 of 2024

List 25
S.No Damain
1
hdmovieon.com
2
vegamovie.ss
3
5movierulz.limited
4
7starhd.run
5
hhdmovies.study
6
bolly4ux.com
7
123mkv.garden
8
moviezguru.mobi
9
vegamoviesnl.work
10 dotmoov.com
List 26
S.No Damain
1
1tamilmv.report
2
filmyzilla45.com
3
lhfilm.com
4
yomovies.ventures
5
freecouchtuner.com
6
gomovies-online.link
7
0gomovies2.com
8
hdmovie2a.my
9
movieshunt.team
10 5movierulz.software
List 27
S.No Domain
1
movierulzsy.com
2
khatri-maza.com
3
movies4u.mw
4
vega-em.com
5
rogmovies.cv
6
watch-movies.com.pk
7
5movierulzto.com
8
filmyfly.luxe
9
hindidubbedmovies.pk

I/3422921/2026

<!-- page 3 -->

4-10/2025-DGT/4(Part-VII)

List 28
S.No Domain
1
desicinemas.to
2
filmyzilla45.in
3
filmywapn.in
4
go.india4movies.net
5
desicinemas.pk
6
moviesbaba.lol
7
ssrmovies.archi
8
hdmoviesnew.com
9
newhdmovie2.cam
10 vegamovles.dev
List 29
S.No Domain
1
mastibaaz.com
2
1desiremovies.dad
3
mlhbd.fun
4
moviedokan.co
5
new2.hdhub4u.cl
6
mp4bay.com
7
hdmoviehub.recipes
8
moviesjoy.bz
9
filmvdo.com
10 new3.movies4u.finance
List 30
S.No Domain
1
ww8.123movies.com.pk
2
bollyhub.info
3
pakbcnhd.pk
4
hdmovie2r.solar
5
d5.downloadhub.food
6
moviesnation.fans
7
jalshamoviez.diy
8
multimovies.watch
9
desimovies.ru
10 hdtodayz.org

I/3422921/2026

<!-- page 4 -->

List 25
S.No
1
2
3
4
5
6
7
8
9
10

Damain
hdmovieon.com
vegamovie.ss
5movierulz.limited
7starhd.run
hhdmovies.study
bolly4ux.com
123mkv.garden
moviezguru.mobi
vegamoviesnl.work
dotmoov.com

List 26
S.No
1
2
3
4
5
6
7
8
9
10

Damain
1tamilmv.report
filmyzilla45.com
lhfilm.com
yomovies.ventures
freecouchtuner.com
gomovies-online.link
0gomovies2.com
hdmovie2a.my
movieshunt.team
5movierulz.software

List 27
S.No
1
2
3
4
5
6
7
8
9

Domain
movierulzsy.com
khatri-maza.com
movies4u.mw
vega-em.com
rogmovies.cv
watch-movies.com.pk
5movierulzto.com
filmyfly.luxe
hindidubbedmovies.pk

<!-- page 5 -->

List 28
S.No
1
2
3
4
5
6
7
8
9
10

Domain
desicinemas.to
filmyzilla45.in
filmywapn.in
go.india4movies.net
desicinemas.pk
moviesbaba.lol
ssrmovies.archi
hdmoviesnew.com
newhdmovie2.cam
vegamovles.dev

List 29
S.No
1
2
3
4
5
6
7
8
9
10

Domain
mastibaaz.com
1desiremovies.dad
mlhbd.fun
moviedokan.co
new2.hdhub4u.cl
mp4bay.com
hdmoviehub.recipes
moviesjoy.bz
filmvdo.com
new3.movies4u.finance

List 30
S.No
1
2
3
4
5
6
7
8
9
10

Domain
ww8.123movies.com.pk
bollyhub.info
pakbcnhd.pk
hdmovie2r.solar
d5.downloadhub.food
moviesnation.fans
jalshamoviez.diy
multimovies.watch
desimovies.ru
hdtodayz.org

<!-- page 6 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

Fwd: Re: URGENT | Twenty-Fifth, TwentySixth and Twenty-Seventh List of Additional
Websites for Real – Time Blocking in
Compliance of Order dated 24.10.2024
const1.hq< const1.hq-dgt-dot@govcontractor.nic.in >
passed by the Hon'ble High Court of Delhi dgt-dot
in CS(COMM) 937 of 2024: Zee
Entertainment Enterprises Limited versus
Bollyzone.tv & Ors.

Manish Shukla < dirit.hq-dgt-dot@gov.in >
Tue, 14 Jul 2026 10:08:37 AM +0530

To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Kripa Shanker Pandey"
<adt.hq-dgt-dot@gov.in>,"SUNIL KUMAR"<const1.hq-dgtdot@govcontractor.nic.in>,"Arun Kumar"<consnt.hq-dgtdot@govcontractor.nic.in>

हार्दिक शुभकामनाओं के साथ/ With warm regards,
मनीष शुक्ला/ Manish Shukla
निदेशक (टी), डीजीटी मुख्यालय/ Director (T), DGT HQ

============ Forwarded message ============
From: Angad Makkar <angad@saikrishnaassociates.com>
To: <dirit.hq-dgt-dot@gov.in>
Cc: "Vivek Ayyagari"<v.ayyagari@saikrishnaassociates.com>, "Priyansh Kohli"
<priyansh@saikrishnaassociates.com>
Date: Wed, 08 Jul 2026 16:51:13 +0530
Subject: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional
Websites for Real – Time Blocking in Compliance of Order dated 24.10.2024 passed by the
Hon'ble High Court of Delhi in CS(COMM) 937 of 2024: Zee Entertainment Enterprises
Limited versus Bollyzone.tv & Ors.
============ Forwarded message ============
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a company
incorporated under the Companies Act, 1956 and having its registered office at 18th Floor, A Wing,
Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and having its branch office at FC19, Sector 16-A, Noida – 201301 (“Our Client”).

about:blank

1/19

<!-- page 7 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

1. You would recall that in response to blatant, large-scale copyright infringement of content on
Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted before the Hon’ble Delhi
Court against various rogue websites (impleaded as Defendant Nos. 1 to 60) in the captioned matter)
which engage in communicating to the public, hosting, streaming and/or making available to the
public Our Client’s Works without authorization and / or facilitating the same.
2. The suit so instituted was inter alia, for permanent injunction, rendition of accounts and
damages, on account of blatant piracy of Our Client’s Works and infringement of copyright and
broadcast reproduction rights of Our Client and for that purpose, Our Client has impleaded various
Domain Name Registrars (Defendant Nos. 61 to 81), Google LLC (Defendant No. 82), Internet
Service providers (Defendant Nos. 83 to 91) as well as the concerned government departments
(Department of Telecommunication and the Ministry of Electronics and Information Technology)
(Defendant Nos. 92 and 93 respectively), as Defendants, to ensure effective compliance of any orders
that the Hon’ble Delhi High Court may be inclined to pass.
3.
You would recall that the above-mentioned matter came up before Hon’ble Justice Mini
Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble Court was pleased to
issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a prima
facie case for grant of injunction and, in case, no ex parte ad interim injunction is
granted, the plaintiff will suffer an irreparable loss. Further, balance of convenience
also lies in favour of the plaintiff, and against the defendants.
41. Accordingly, till the next date of hearing, the following directions
are issued:
I. The defendant nos. 1 to 60, their owners, partners, officers and all
others in capacity of principal or agent acting for and on their behalf, or anyone
claiming through, by or under it, are restrained from in any manner communicating,
hosting, streaming, and/or making available for viewing and downloading, without
authorization, on their websites or other platforms, through the internet in any manner
whatsoever, the plaintiff’s works so as to infringe the plaintiff’s exclusive rights and
broadcast reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of principal or agent
acting for and, on their behalf, or anyone claiming through, by or under it, are directed
to suspend the domain name registration of the defendant nos. 1 to 60, as per the details
as given in Annexure-B to the present order.
III. The defendant nos. 61 to 81, are directed to disclose the following
information of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone
number, IP address, etc.
b. Mode of payment along with payment details used for registration of
domain name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of principal or agent
acting for and on their behalf, or anyone claiming through, by or under it, are directed
to block access to the various websites identified by the plaintiff, details of which are
given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification
calling upon the various internet service providers registered under it to block access to
the various websites identified by the plaintiff in the instant suit, details of which are
given as Annexure-C.
VI. If during the pendency of the present suit, any further
websites are discovered by the plaintiff, which are illegally streaming the
infringing content, copyright of which is owned by the plaintiff, the
about:blank

2/19

<!-- page 8 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

plaintiff is granted liberty to communicate the details of such websites to
defendant no. 92 (Department of Telecommunications) and defendant no.
93 (Ministry of Electronics and Information Technology), for issuance of
blocking orders and simultaneously to the Internet Service Providers
(“ISPs”) for blocking the said websites.
VII. Upon receiving the said intimation from the plaintiff, the
ISPs shall take steps to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking orders
immediately upon the plaintiff, communicating the details of the websites, which are
illegally streaming the content, over which the plaintiff has rights.
IX. After communication of details of the rogue websites to the
concerned authorities, the plaintiff shall continue to file affidavits with the Court, in
order to ensure that the Court is fully informed of the websites in respect of which
blocking orders are sought.
X. If any website, which is not primarily an infringing site, is blocked
pursuant to the present order, they shall be permitted to approach this Court by giving
an undertaking that it does not intend to engage in any unauthorized streaming of any
content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the plaintiff,
the plaintiff shall be at liberty to file an application for their impleadment, which shall
be taken up before the Joint Registrar (Judicial), and the order passed today shall be
extended to the said newly impleaded website as well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done, within a period of
one week from today.
4. In light of the above, you are hereby requested to comply with the order dated
24th October 2024, passed by the Hon'ble Delhi High Court, by immediately issuing
blocking orders, calling on internet and telecom service providers to immediately block
access to the attached lists of additional websites, which are illegally streaming / making
available Our Client’s Works, over which Our Client has exclusive rights.
5. For your convenience, the Order dated 24th October 2024, passed by the Hon'ble Delhi High
Court is re-attached herewith.
6. The Twenty-Fifth, Twenty-Sixth and Twenty-Seventh Lists of the additional websites are also
enclosed herewith along with the evidence collected qua the said additional rogue streaming websites
(for all the said lists), which is accessible at the link below:
https://drive.google.com/drive/folders/1-CFYQYYDVh-IZEoYAmk3UpuYPkCV08Cn?
usp=sharing
You are hereby requested to confirm the compliance of the Order by issuing the necessary
blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,
Angad Makkar
(D/3579/2021)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited
about:blank

3/19

<!-- page 9 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

-Angad Makkar | Senior Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003|
Handphone: +91-9897896284 | [Enrolment No. D/3579/2021]

• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious

The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege,
not being waived or lost by mistaken transmission or receipt. If you have received this mail in
error, please notify us at info@saikrishnaassociates.com immediately by reply email and
destroy the original - any use, disclosure or copying of this mail is unauthorised.
On Wed, 8 Jul 2026 at 16:44, Angad Makkar <angad@saikrishnaassociates.com> wrote:
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a company
incorporated under the Companies Act, 1956 and having its registered office at 18th Floor, A Wing,
Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and having its branch office at
FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1. You would recall that in response to blatant, large-scale copyright infringement of content
on Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted before the Hon’ble
Delhi Court against various rogue websites (impleaded as Defendant Nos. 1 to 60) in the captioned
matter) which engage in communicating to the public, hosting, streaming and/or making available
to the public Our Client’s Works without authorization and / or facilitating the same.
2. The suit so instituted was inter alia, for permanent injunction, rendition of accounts and
damages, on account of blatant piracy of Our Client’s Works and infringement of copyright and
broadcast reproduction rights of Our Client and for that purpose, Our Client has impleaded various
Domain Name Registrars (Defendant Nos. 61 to 81), Google LLC (Defendant No. 82), Internet
Service providers (Defendant Nos. 83 to 91) as well as the concerned government
departments (Department of Telecommunication and the Ministry of Electronics and Information
Technology) (Defendant Nos. 92 and 93 respectively), as Defendants, to ensure effective
compliance of any orders that the Hon’ble Delhi High Court may be inclined to pass.
3.

You would recall that the above-mentioned matter came up before Hon’ble Justice Mini

Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble Court was pleased
to issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a
prima facie case for grant of injunction and, in case, no ex parte ad interim
injunction is granted, the plaintiff will suffer an irreparable loss. Further, balance of
convenience also lies in favour of the plaintiff, and against the defendants.
41. Accordingly, till the next date of hearing, the following directions
are issued:
I. The defendant nos. 1 to 60, their owners, partners, officers and all
others in capacity of principal or agent acting for and on their behalf, or anyone
claiming through, by or under it, are restrained from in any manner communicating,
about:blank

4/19

<!-- page 10 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

hosting, streaming, and/or making available for viewing and downloading, without
authorization, on their websites or other platforms, through the internet in any
manner whatsoever, the plaintiff’s works so as to infringe the plaintiff’s exclusive
rights and broadcast reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners,
proprietors, officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and, on their behalf, or anyone claiming through, by or
under it, are directed to suspend the domain name registration of the defendant nos.
1 to 60, as per the details as given in Annexure-B to the present order.
III. The defendant nos. 61 to 81, are directed to disclose the following
information of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone
number, IP address, etc.
b. Mode of payment along with payment details used for registration
of domain name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of principal or
agent acting for and on their behalf, or anyone claiming through, by or under it, are
directed to block access to the various websites identified by the plaintiff, details of
which are given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification
calling upon the various internet service providers registered under it to block access
to the various websites identified by the plaintiff in the instant suit, details of which
are given as Annexure-C.
VI. If during the pendency of the present suit, any further
websites are discovered by the plaintiff, which are illegally streaming the
infringing content, copyright of which is owned by the plaintiff, the
plaintiff is granted liberty to communicate the details of such websites to
defendant no. 92 (Department of Telecommunications) and defendant no.
93 (Ministry of Electronics and Information Technology), for issuance of
blocking orders and simultaneously to the Internet Service Providers
(“ISPs”) for blocking the said websites.
VII. Upon receiving the said intimation from the plaintiff,
the ISPs shall take steps to immediately block the rogue websites in
question.
VIII. The DOT and MEITY shall also issue necessary blocking orders
immediately upon the plaintiff, communicating the details of the websites, which are
illegally streaming the content, over which the plaintiff has rights.
IX. After communication of details of the rogue websites to the
concerned authorities, the plaintiff shall continue to file affidavits with the Court, in
order to ensure that the Court is fully informed of the websites in respect of which
blocking orders are sought.
X. If any website, which is not primarily an infringing site, is blocked
pursuant to the present order, they shall be permitted to approach this Court by
giving an undertaking that it does not intend to engage in any unauthorized
streaming of any content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the plaintiff,
the plaintiff shall be at liberty to file an application for their impleadment, which
shall be taken up before the Joint Registrar (Judicial), and the order passed today
shall be extended to the said newly impleaded website as well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done, within a period
of one week from today.

about:blank

5/19

<!-- page 11 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

4. In light of the above, you are hereby requested to comply with the order dated
24th October 2024, passed by the Hon'ble Delhi High Court, by immediately issuing
blocking orders, calling on internet and telecom service providers to immediately block
access to the attached lists of additional websites, which are illegally streaming /
making available Our Client’s Works, over which Our Client has exclusive rights.
5. For your convenience, the Order dated 24th October 2024, passed by the Hon'ble Delhi
High Court is re-attached herewith.
6. The Twenty-Fifth, Twenty-Sixth and Twenty-Seventh Lists of the additional websites are
also enclosed herewith along with the evidence collected qua the said additional rogue streaming
websites (for all the said lists), which is accessible at the link below:
https://drive.google.com/drive/folders/1-CFYQYYDVh-IZEoYAmk3UpuYPkCV08Cn?
usp=sharing
You are hereby requested to confirm the compliance of the Order by issuing the
necessary blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,
Angad Makkar
(D/3579/2021)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited

-Angad Makkar | Senior Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003|
Handphone: +91-9897896284 | [Enrolment No. D/3579/2021]

• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege,
not being waived or lost by mistaken transmission or receipt. If you have received this mail
in error, please notify us at info@saikrishnaassociates.com immediately by reply email and
destroy the original - any use, disclosure or copying of this mail is unauthorised.
On Tue, 1 Jul 2025 at 17:50, Rishabh Rao <rishabh@saikrishnaassociates.com> wrote:
URGENT ACTION REQUIRED
Dear Sir / Madam,

about:blank

6/19

<!-- page 12 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a company
incorporated under the Companies Act, 1956 and having its registered office at 18th Floor, A Wing,
Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and having its branch office at
FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1.
You would recall that in response to blatant, large-scale copyright infringement of content on
Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted before the Hon’ble
Delhi Court against various rogue websites (impleaded as Defendant Nos. 1 to 60) in the
captioned matter) which engage in communicating to the public, hosting, streaming and/or
making available to the public Our Client’s Works without authorization and / or facilitating
the same.
2.
The suit so instituted was inter alia, for permanent injunction, rendition of accounts and
damages, on account of blatant piracy of Our Client’s Works and infringement of copyright
and broadcast reproduction rights of Our Client and for that purpose, Our Client has
impleaded various Domain Name Registrars (Defendant Nos. 61 to 81), Google LLC
(Defendant No. 82), Internet Service providers (Defendant Nos. 83 to 91) as well as the
concerned government departments (Department of Telecommunication and
the Ministry of Electronics and Information Technology) (Defendant Nos. 92
and 93 respectively), as Defendants, to ensure effective compliance of any orders that the
Hon’ble Delhi High Court may be inclined to pass.
3.
You would recall that the above-mentioned matter came up before Hon’ble Justice Mini
Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble Court was
pleased to issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a prima facie case
for grant of injunction and, in case, no ex parte ad interim injunction is granted,
the plaintiff will suffer an irreparable loss. Further, balance of convenience also
lies in favour of the plaintiff, and against the defendants.
41. Accordingly, till the next date of hearing, the following directions are issued:
I. The defendant nos. 1 to 60, their owners, partners, officers and all others in
capacity of principal or agent acting for and on their behalf, or anyone claiming
through, by or under it, are restrained from in any manner communicating,
hosting, streaming, and/or making available for viewing and downloading,
without authorization, on their websites or other platforms, through the internet in
any manner whatsoever, the plaintiff’s works so as to infringe the plaintiff’s
exclusive rights and broadcast reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners, proprietors, officers,
affiliates, servants, employees, and all others in capacity of principal or agent
about:blank

7/19

<!-- page 13 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

acting for and, on their behalf, or anyone claiming through, by or under it, are
directed to suspend the domain name registration of the defendant nos. 1 to 60, as
per the details as given in Annexure-B to the present order.
III. The defendant nos. 61 to 81, are directed to disclose the following information
of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone number, IP
address, etc.
b. Mode of payment along with payment details used for registration of domain
name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners, proprietors, officers,
affiliates, servants, employees, and all others in capacity of principal or agent
acting for and on their behalf, or anyone claiming through, by or under it, are
directed to block access to the various websites identified by the plaintiff, details of
which are given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification calling upon the
various internet service providers registered under it to block access to the various
websites identified by the plaintiff in the instant suit, details of which are given as
Annexure-C.
VI. If during the pendency of the present suit, any further websites are
discovered by the plaintiff, which are illegally streaming the infringing
content, copyright of which is owned by the plaintiff, the plaintiff is
granted liberty to communicate the details of such websites to
defendant no. 92 (Department of Telecommunications) and defendant
no. 93 (Ministry of Electronics and Information Technology), for
issuance of blocking orders and simultaneously to the Internet Service
Providers (“ISPs”) for blocking the said websites.
VII. Upon receiving the said intimation from the plaintiff, the ISPs shall take steps
to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking orders
immediately upon the plaintiff, communicating the details of the
websites, which are illegally streaming the content, over which the
plaintiff has rights.
IX. After communication of details of the rogue websites to the concerned
authorities, the plaintiff shall continue to file affidavits with the Court, in order to
ensure that the Court is fully informed of the websites in respect of which blocking
orders are sought.
X. If any website, which is not primarily an infringing site, is blocked pursuant to
the present order, they shall be permitted to approach this Court by giving an
undertaking that it does not intend to engage in any unauthorized streaming of
any content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the plaintiff, the plaintiff
shall be at liberty to file an application for their impleadment, which shall be taken

about:blank

8/19

<!-- page 14 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

up before the Joint Registrar (Judicial), and the order passed today shall be
extended to the said newly impleaded website as well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done, within a period of one week
from today.
4.
In light of the above, you are hereby requested to comply with the order dated
24th October 2024, passed by the Hon'ble Delhi High Court, by immediately
issuing blocking orders, calling on internet and telecom service providers to
immediately block access to the attached list of additional websites, which are
illegally streaming / making available Our Client’s Works, over which Our Client
has exclusive rights.
5.
For your convenience, the Order dated 24th October 2024, passed by the Hon'ble Delhi High
Court is re – attached herewith.
6.
The Twenty-Fourth List of the additional websites is also enclosed herewith along with the
evidence collected qua the additional rogue streaming websites, which is accessible at the link
below:
https://drive.google.com/drive/folders/1W6oY1qNOc1YFCGVMSsr66O0-N_Wc1Um6?
usp=drive_link
You are hereby requested to confirm the compliance of the Order by issuing the
necessary blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,
Rishabh Rao
(KAR/3753/2023)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited
Rishabh Rao | Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003 |
Mobile: +91 7676612211 | [Enrolment No. KAR/3753/2023]
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
about:blank

9/19

<!-- page 15 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege,
not being waived or lost by mistaken transmission or receipt. If you have received this mail in
error, please notify us at info@saikrishnaassociates.com immediately by reply email and
destroy the original - any use, disclosure or copying of this mail is unauthorised.
On Mon, Jun 30, 2025 at 2:28 PM Rishabh Rao <rishabh@saikrishnaassociates.com>
wrote:
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a company
incorporated under the Companies Act, 1956 and having its registered office at 18th Floor, A
Wing, Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and having its branch
office at FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1.
You would recall that in response to blatant, large-scale copyright infringement of content
on Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted before the
Hon’ble Delhi Court against various rogue websites (impleaded as Defendant Nos. 1 to 60)
in the captioned matter) which engage in communicating to the public, hosting, streaming
and/or making available to the public Our Client’s Works without authorization and / or
facilitating the same.
2.
The suit so instituted was inter alia, for permanent injunction, rendition of accounts and
damages, on account of blatant piracy of Our Client’s Works and infringement of copyright
and broadcast reproduction rights of Our Client and for that purpose, Our Client has
impleaded various Domain Name Registrars (Defendant Nos. 61 to 81), Google LLC
(Defendant No. 82), Internet Service providers (Defendant Nos. 83 to 91) as well as the
concerned government departments (Department of Telecommunication and
the Ministry of Electronics and Information Technology) (Defendant Nos. 92
and 93 respectively), as Defendants, to ensure effective compliance of any orders that
the Hon’ble Delhi High Court may be inclined to pass.
3.
You would recall that the above-mentioned matter came up before Hon’ble Justice Mini
Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble Court was
pleased to issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a prima facie
case for grant of injunction and, in case, no ex parte ad interim injunction is
granted, the plaintiff will suffer an irreparable loss. Further, balance of
convenience also lies in favour of the plaintiff, and against the defendants.

about:blank

10/19

<!-- page 16 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

41. Accordingly, till the next date of hearing, the following directions are issued:
I. The defendant nos. 1 to 60, their owners, partners, officers and all others in
capacity of principal or agent acting for and on their behalf, or anyone claiming
through, by or under it, are restrained from in any manner communicating,
hosting, streaming, and/or making available for viewing and downloading,
without authorization, on their websites or other platforms, through the internet
in any manner whatsoever, the plaintiff’s works so as to infringe the plaintiff’s
exclusive rights and broadcast reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners, proprietors, officers,
affiliates, servants, employees, and all others in capacity of principal or agent
acting for and, on their behalf, or anyone claiming through, by or under it, are
directed to suspend the domain name registration of the defendant nos. 1 to 60,
as per the details as given in Annexure-B to the present order.
III. The defendant nos. 61 to 81, are directed to disclose the following
information of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone number, IP
address, etc.
b. Mode of payment along with payment details used for registration of domain
name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners, proprietors, officers,
affiliates, servants, employees, and all others in capacity of principal or agent
acting for and on their behalf, or anyone claiming through, by or under it, are
directed to block access to the various websites identified by the plaintiff, details
of which are given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification calling upon
the various internet service providers registered under it to block access to the
various websites identified by the plaintiff in the instant suit, details of which are
given as Annexure-C.
VI. If during the pendency of the present suit, any further websites
are discovered by the plaintiff, which are illegally streaming the
infringing content, copyright of which is owned by the plaintiff, the
plaintiff is granted liberty to communicate the details of such
websites to defendant no. 92 (Department of Telecommunications)
and defendant no. 93 (Ministry of Electronics and Information
Technology), for issuance of blocking orders and simultaneously to
the Internet Service Providers (“ISPs”) for blocking the said
websites.
VII. Upon receiving the said intimation from the plaintiff, the ISPs shall take
steps to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking orders
immediately upon the plaintiff, communicating the details of the
websites, which are illegally streaming the content, over which the
plaintiff has rights.
about:blank

11/19

<!-- page 17 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

IX. After communication of details of the rogue websites to the concerned
authorities, the plaintiff shall continue to file affidavits with the Court, in order
to ensure that the Court is fully informed of the websites in respect of which
blocking orders are sought.
X. If any website, which is not primarily an infringing site, is blocked pursuant
to the present order, they shall be permitted to approach this Court by giving an
undertaking that it does not intend to engage in any unauthorized streaming of
any content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the plaintiff, the
plaintiff shall be at liberty to file an application for their impleadment, which
shall be taken up before the Joint Registrar (Judicial), and the order passed
today shall be extended to the said newly impleaded website as well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done, within a period of one
week from today.
4.
In light of the above, you are hereby requested to comply with the order dated
24th October 2024, passed by the Hon'ble Delhi High Court, by immediately
issuing blocking orders, calling on internet and telecom service providers to
immediately block access to the attached list of additional websites, which are
illegally streaming / making available Our Client’s Works, over which Our
Client has exclusive rights.
5.
For your convenience, the Order dated 24th October 2024, passed by the Hon'ble Delhi
High Court is re – attached herewith.
6.
The Twenty-Third List of the additional websites is also enclosed herewith along with the
evidence collected qua the additional rogue streaming websites, which is accessible at the
link below:
https://drive.google.com/drive/folders/1HUBVG_5p-r9KD4EBCVbz1aivDXET3Soa?
usp=drive_link
You are hereby requested to confirm the compliance of the Order by issuing the
necessary blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,

about:blank

12/19

<!-- page 18 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

Rishabh Rao
(KAR/3753/2023)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited
Rishabh Rao | Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003 |
Mobile: +91 7676612211 | [Enrolment No. KAR/3753/2023]
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege,
not being waived or lost by mistaken transmission or receipt. If you have received this mail
in error, please notify us at info@saikrishnaassociates.com immediately by reply email and
destroy the original - any use, disclosure or copying of this mail is unauthorised.
On Fri, Jun 27, 2025 at 11:06 AM Rishabh Rao <rishabh@saikrishnaassociates.com>
wrote:
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a company
incorporated under the Companies Act, 1956 and having its registered office at 18th Floor, A
Wing, Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and having its
branch office at FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1.
You would recall that in response to blatant, large-scale copyright infringement of
content on Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted
before the Hon’ble Delhi Court against various rogue websites (impleaded as Defendant
Nos. 1 to 60) in the captioned matter) which engage in communicating to the public,
hosting, streaming and/or making available to the public Our Client’s Works without
authorization and / or facilitating the same.
2.
The suit so instituted was inter alia, for permanent injunction, rendition of accounts and
damages, on account of blatant piracy of Our Client’s Works and infringement of
copyright and broadcast reproduction rights of Our Client and for that purpose, Our
Client has impleaded various Domain Name Registrars (Defendant Nos. 61 to 81), Google
LLC (Defendant No. 82), Internet Service providers (Defendant Nos. 83 to 91) as well as
the concerned government departments (Department of Telecommunication
and the Ministry of Electronics and Information Technology) (Defendant

about:blank

13/19

<!-- page 19 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

Nos. 92 and 93 respectively), as Defendants, to ensure effective compliance of any
orders that the Hon’ble Delhi High Court may be inclined to pass.
3.
You would recall that the above-mentioned matter came up before Hon’ble Justice Mini
Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble Court
was pleased to issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a prima facie
case for grant of injunction and, in case, no ex parte ad interim injunction is
granted, the plaintiff will suffer an irreparable loss. Further, balance of
convenience also lies in favour of the plaintiff, and against the defendants.
41. Accordingly, till the next date of hearing, the following directions are
issued:
I. The defendant nos. 1 to 60, their owners, partners, officers and all others in
capacity of principal or agent acting for and on their behalf, or anyone
claiming through, by or under it, are restrained from in any manner
communicating, hosting, streaming, and/or making available for viewing
and downloading, without authorization, on their websites or other
platforms, through the internet in any manner whatsoever, the plaintiff’s
works so as to infringe the plaintiff’s exclusive rights and broadcast
reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of principal
or agent acting for and, on their behalf, or anyone claiming through, by or
under it, are directed to suspend the domain name registration of the
defendant nos. 1 to 60, as per the details as given in Annexure-B to the present
order.
III. The defendant nos. 61 to 81, are directed to disclose the following
information of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone number, IP
address, etc.
b. Mode of payment along with payment details used for registration of
domain name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners, proprietors, officers,
affiliates, servants, employees, and all others in capacity of principal or agent
acting for and on their behalf, or anyone claiming through, by or under it, are
directed to block access to the various websites identified by the plaintiff,
details of which are given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification calling
upon the various internet service providers registered under it to block access
to the various websites identified by the plaintiff in the instant suit, details of
which are given as Annexure-C.

about:blank

14/19

<!-- page 20 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

VI. If during the pendency of the present suit, any further websites
are discovered by the plaintiff, which are illegally streaming the
infringing content, copyright of which is owned by the plaintiff, the
plaintiff is granted liberty to communicate the details of such
websites to defendant no. 92 (Department of Telecommunications)
and defendant no. 93 (Ministry of Electronics and Information
Technology), for issuance of blocking orders and simultaneously to
the Internet Service Providers (“ISPs”) for blocking the said
websites.
VII. Upon receiving the said intimation from the plaintiff, the ISPs shall take
steps to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking
orders immediately upon the plaintiff, communicating the details
of the websites, which are illegally streaming the content, over
which the plaintiff has rights.
IX. After communication of details of the rogue websites to the concerned
authorities, the plaintiff shall continue to file affidavits with the Court, in
order to ensure that the Court is fully informed of the websites in respect of
which blocking orders are sought.
X. If any website, which is not primarily an infringing site, is blocked
pursuant to the present order, they shall be permitted to approach this Court
by giving an undertaking that it does not intend to engage in any
unauthorized streaming of any content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the plaintiff, the
plaintiff shall be at liberty to file an application for their impleadment, which
shall be taken up before the Joint Registrar (Judicial), and the order passed
today shall be extended to the said newly impleaded website as well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done, within a period of one
week from today.
4.
In light of the above, you are hereby requested to comply with the order
dated 24th October 2024, passed by the Hon'ble Delhi High Court, by
immediately issuing blocking orders, calling on internet and telecom service
providers to immediately block access to the attached list of additional
websites, which are illegally streaming / making available Our Client’s
Works, over which Our Client has exclusive rights.
5.
For your convenience, the Order dated 24th October 2024, passed by the Hon'ble Delhi
High Court is re – attached herewith.

about:blank

15/19

<!-- page 21 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

6.
The Twenty-Second List of the additional websites is also enclosed herewith along with
the evidence collected qua the additional rogue streaming websites, which is accessible at
the link below:
https://drive.google.com/drive/folders/1sE7PIJIwG6XljPqaxcN6PREc3DXBKAKo?
usp=drive_link

You are hereby requested to confirm the compliance of the Order by issuing the
necessary blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,
Rishabh Rao
(KAR/3753/2023)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited
Rishabh Rao | Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003 |
Mobile: +91 7676612211 | [Enrolment No. KAR/3753/2023]
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional
privilege, not being waived or lost by mistaken transmission or receipt. If you have
received
this
mail
in
error,
please
notify
us
at info@saikrishnaassociates.com immediately by reply email and destroy the original any use, disclosure or copying of this mail is unauthorised.
On Fri, Jun 27, 2025 at 11:02 AM Rishabh Rao
<rishabh@saikrishnaassociates.com> wrote:
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a
company incorporated under the Companies Act, 1956 and having its registered office at 18th
Floor, A Wing, Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and
having its branch office at FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1.

about:blank

16/19

<!-- page 22 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

You would recall that in response to blatant, large-scale copyright infringement of
content on Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted
before the Hon’ble Delhi Court against various rogue websites (impleaded as
Defendant Nos. 1 to 60) in the captioned matter) which engage in communicating to
the public, hosting, streaming and/or making available to the public Our Client’s
Works without authorization and / or facilitating the same.
2.
The suit so instituted was inter alia, for permanent injunction, rendition of accounts
and damages, on account of blatant piracy of Our Client’s Works and infringement of
copyright and broadcast reproduction rights of Our Client and for that purpose, Our
Client has impleaded various Domain Name Registrars (Defendant Nos. 61 to 81),
Google LLC (Defendant No. 82), Internet Service providers (Defendant Nos. 83 to 91)
as well as the concerned government departments (Department of
Telecommunication and the Ministry of Electronics and Information
Technology) (Defendant Nos. 92 and 93 respectively), as Defendants, to
ensure effective compliance of any orders that the Hon’ble Delhi High Court may be
inclined to pass.
3.
You would recall that the above-mentioned matter came up before Hon’ble Justice
Mini Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble
Court was pleased to issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a prima
facie case for grant of injunction and, in case, no ex parte ad interim
injunction is granted, the plaintiff will suffer an irreparable loss. Further,
balance of convenience also lies in favour of the plaintiff, and against the
defendants.
41. Accordingly, till the next date of hearing, the following directions are
issued:
I. The defendant nos. 1 to 60, their owners, partners, officers and all others
in capacity of principal or agent acting for and on their behalf, or anyone
claiming through, by or under it, are restrained from in any manner
communicating, hosting, streaming, and/or making available for viewing
and downloading, without authorization, on their websites or other
platforms, through the internet in any manner whatsoever, the plaintiff’s
works so as to infringe the plaintiff’s exclusive rights and broadcast
reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and, on their behalf, or anyone claiming
through, by or under it, are directed to suspend the domain name

about:blank

17/19

<!-- page 23 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

registration of the defendant nos. 1 to 60, as per the details as given in
Annexure-B to the present order.
III. The defendant nos. 61 to 81, are directed to disclose the following
information of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone number,
IP address, etc.
b. Mode of payment along with payment details used for registration of
domain name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and on their behalf, or anyone claiming
through, by or under it, are directed to block access to the various websites
identified by the plaintiff, details of which are given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification calling
upon the various internet service providers registered under it to block
access to the various websites identified by the plaintiff in the instant suit,
details of which are given as Annexure-C.
VI. If during the pendency of the present suit, any further
websites are discovered by the plaintiff, which are illegally
streaming the infringing content, copyright of which is owned by
the plaintiff, the plaintiff is granted liberty to communicate the
details of such websites to defendant no. 92 (Department of
Telecommunications)

and

defendant

no.

93

(Ministry

of

Electronics and Information Technology), for issuance of
blocking orders and simultaneously to the Internet Service
Providers (“ISPs”) for blocking the said websites.
VII. Upon receiving the said intimation from the plaintiff, the ISPs shall
take steps to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking
orders immediately upon the plaintiff, communicating the
details of the websites, which are illegally streaming the content,
over which the plaintiff has rights.
IX. After communication of details of the rogue websites to the concerned
authorities, the plaintiff shall continue to file affidavits with the Court, in
order to ensure that the Court is fully informed of the websites in respect of
which blocking orders are sought.
X. If any website, which is not primarily an infringing site, is blocked
pursuant to the present order, they shall be permitted to approach this
Court by giving an undertaking that it does not intend to engage in any
unauthorized streaming of any content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the plaintiff, the
plaintiff shall be at liberty to file an application for their impleadment,

about:blank

18/19

<!-- page 24 -->

7/15/26, 10:17 AM

Fwd: Re: URGENT | Twenty-Fifth, Twenty-Sixth and Twenty-Seventh List of Additional Websites for Real – Time Blocking in C…

which shall be taken up before the Joint Registrar (Judicial), and the order
passed today shall be extended to the said newly impleaded website as well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done,

4 Attachment(s)

about:blank

Injunction Order dt. 24.10.202…

27th List of Websites - ZEEL v …

3.6 MB

13.6 KB

26th List of Websites - ZEEL v …

25th List of Websites - ZEEL v …

16.4 KB

16.7 KB

19/19

<!-- page 25 -->

List 25
S.No
1
2
3
4
5
6
7
8
9
10

Damain
hdmovieon.com
vegamovie.ss
5movierulz.limited
7starhd.run
hhdmovies.study
bolly4ux.com
123mkv.garden
moviezguru.mobi
vegamoviesnl.work
dotmoov.com

List 26
S.No
1
2
3
4
5
6
7
8
9
10

Damain
1tamilmv.report
filmyzilla45.com
lhfilm.com
yomovies.ventures
freecouchtuner.com
gomovies-online.link
0gomovies2.com
hdmovie2a.my
movieshunt.team
5movierulz.software

List 27
S.No
1
2
3
4
5
6
7
8
9

Domain
movierulzsy.com
khatri-maza.com
movies4u.mw
vega-em.com
rogmovies.cv
watch-movies.com.pk
5movierulzto.com
filmyfly.luxe
hindidubbedmovies.pk

<!-- page 26 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

Fwd: Re: URGENT | Twenty-Eighth, TwentyNinth and Thirtieth List of Additional
Websites for Real – Time Blocking in
Compliance of Order dated 24.10.2024
const1.hq< const1.hq-dgt-dot@govcontractor.nic.in >
passed by the Hon'ble High Court of Delhi dgt-dot
in CS(COMM) 937 of 2024: Zee
Entertainment Enterprises Limited versus
Bollyzone.tv & Ors.

Manish Shukla < dirit.hq-dgt-dot@gov.in >
Tue, 14 Jul 2026 10:08:41 AM +0530

To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Kripa Shanker Pandey"
<adt.hq-dgt-dot@gov.in>,"SUNIL KUMAR"<const1.hq-dgtdot@govcontractor.nic.in>,"Arun Kumar"<consnt.hq-dgtdot@govcontractor.nic.in>

हार्दिक शुभकामनाओं के साथ/ With warm regards,
मनीष शुक्ला/ Manish Shukla
निदेशक (टी), डीजीटी मुख्यालय/ Director (T), DGT HQ

============ Forwarded message ============
From: Angad Makkar <angad@saikrishnaassociates.com>
To: <dirit.hq-dgt-dot@gov.in>
Cc: "Vivek Ayyagari"<v.ayyagari@saikrishnaassociates.com>, "Priyansh Kohli"
<priyansh@saikrishnaassociates.com>, "Shashwat Singh"
<shashwat@saikrishnaassociates.com>
Date: Thu, 09 Jul 2026 17:45:57 +0530
Subject: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional
Websites for Real – Time Blocking in Compliance of Order dated 24.10.2024 passed by the
Hon'ble High Court of Delhi in CS(COMM) 937 of 2024: Zee Entertainment Enterprises
Limited versus Bollyzone.tv & Ors.
============ Forwarded message ============
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a company
incorporated under the Companies Act, 1956 and having its registered office at 18th Floor, A Wing,
Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and having its branch office at FC19, Sector 16-A, Noida – 201301 (“Our Client”).
about:blank

1/17

<!-- page 27 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

1. You would recall that in response to blatant, large-scale copyright infringement of content on
Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted before the Hon’ble Delhi
Court against various rogue websites (impleaded as Defendant Nos. 1 to 60) in the captioned matter)
which engage in communicating to the public, hosting, streaming and/or making available to the
public Our Client’s Works without authorization and / or facilitating the same.
2. The suit so instituted was inter alia, for permanent injunction, rendition of accounts and
damages, on account of blatant piracy of Our Client’s Works and infringement of copyright and
broadcast reproduction rights of Our Client and for that purpose, Our Client has impleaded various
Domain Name Registrars (Defendant Nos. 61 to 81), Google LLC (Defendant No. 82), Internet
Service providers (Defendant Nos. 83 to 91) as well as the concerned government departments
(Department of Telecommunication and the Ministry of Electronics and Information Technology)
(Defendant Nos. 92 and 93 respectively), as Defendants, to ensure effective compliance of any orders
that the Hon’ble Delhi High Court may be inclined to pass.
3.
You would recall that the above-mentioned matter came up before Hon’ble Justice Mini
Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble Court was pleased to
issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a prima
facie case for grant of injunction and, in case, no ex parte ad interim injunction is
granted, the plaintiff will suffer an irreparable loss. Further, balance of convenience
also lies in favour of the plaintiff, and against the defendants.
41. Accordingly, till the next date of hearing, the following directions
are issued:
I. The defendant nos. 1 to 60, their owners, partners, officers and all
others in capacity of principal or agent acting for and on their behalf, or anyone
claiming through, by or under it, are restrained from in any manner communicating,
hosting, streaming, and/or making available for viewing and downloading, without
authorization, on their websites or other platforms, through the internet in any manner
whatsoever, the plaintiff’s works so as to infringe the plaintiff’s exclusive rights and
broadcast reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of principal or agent
acting for and, on their behalf, or anyone claiming through, by or under it, are directed
to suspend the domain name registration of the defendant nos. 1 to 60, as per the details
as given in Annexure-B to the present order.
III. The defendant nos. 61 to 81, are directed to disclose the following
information of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone
number, IP address, etc.
b. Mode of payment along with payment details used for registration of
domain name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of principal or agent
acting for and on their behalf, or anyone claiming through, by or under it, are directed
to block access to the various websites identified by the plaintiff, details of which are
given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification
calling upon the various internet service providers registered under it to block access to
the various websites identified by the plaintiff in the instant suit, details of which are
given as Annexure-C.
VI. If during the pendency of the present suit, any further
websites are discovered by the plaintiff, which are illegally streaming the
infringing content, copyright of which is owned by the plaintiff, the
about:blank

2/17

<!-- page 28 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

plaintiff is granted liberty to communicate the details of such websites to
defendant no. 92 (Department of Telecommunications) and defendant no.
93 (Ministry of Electronics and Information Technology), for issuance of
blocking orders and simultaneously to the Internet Service Providers
(“ISPs”) for blocking the said websites.
VII. Upon receiving the said intimation from the plaintiff, the
ISPs shall take steps to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking orders
immediately upon the plaintiff, communicating the details of the websites, which are
illegally streaming the content, over which the plaintiff has rights.
IX. After communication of details of the rogue websites to the
concerned authorities, the plaintiff shall continue to file affidavits with the Court, in
order to ensure that the Court is fully informed of the websites in respect of which
blocking orders are sought.
X. If any website, which is not primarily an infringing site, is blocked
pursuant to the present order, they shall be permitted to approach this Court by giving
an undertaking that it does not intend to engage in any unauthorized streaming of any
content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the plaintiff,
the plaintiff shall be at liberty to file an application for their impleadment, which shall
be taken up before the Joint Registrar (Judicial), and the order passed today shall be
extended to the said newly impleaded website as well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done, within a period of
one week from today.
4.
In light of the above, you are hereby requested to comply with the order dated
24th October 2024, passed by the Hon'ble Delhi High Court, by immediately issuing
blocking orders, calling on internet and telecom service providers to immediately block
access to the attached list of additional websites, which are illegally streaming / making
available Our Client’s Works, over which Our Client has exclusive rights.
5. For your convenience, the Order dated 24th October 2024, passed by the Hon'ble Delhi High
Court is re-attached herewith.
6.
The Twenty-Eighth, Twenty-Ninth and Thirtieth Lists of the additional websites are also
enclosed herewith along with the evidence collected qua the said additional rogue streaming websites
(for all the said lists), which is accessible at the link below:
https://drive.google.com/drive/folders/19f2JGRU9J7NmJXs6_zdeuyawcjsLFlKu
You are hereby requested to confirm your compliance with the Order dated 24th October
2024 by issuing the necessary blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,
Angad Makkar
(D/3579/2021)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited

about:blank

3/17

<!-- page 29 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

-Angad Makkar | Senior Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003|
Handphone: +91-9897896284 | [Enrolment No. D/3579/2021]

• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious

The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege,
not being waived or lost by mistaken transmission or receipt. If you have received this mail in
error, please notify us at info@saikrishnaassociates.com immediately by reply email and
destroy the original - any use, disclosure or copying of this mail is unauthorised.

On Wed, 8 Jul 2026 at 16:51, Angad Makkar <angad@saikrishnaassociates.com> wrote:
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a company
incorporated under the Companies Act, 1956 and having its registered office at 18th Floor, A Wing,
Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and having its branch office at
FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1.
You would recall that in response to blatant, large-scale copyright infringement of
content on Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted before the
Hon’ble Delhi Court against various rogue websites (impleaded as Defendant Nos. 1 to 60) in the
captioned matter) which engage in communicating to the public, hosting, streaming and/or
making available to the public Our Client’s Works without authorization and / or facilitating the
same.
2. The suit so instituted was inter alia, for permanent injunction, rendition of accounts and
damages, on account of blatant piracy of Our Client’s Works and infringement of copyright and
broadcast reproduction rights of Our Client and for that purpose, Our Client has impleaded
various Domain Name Registrars (Defendant Nos. 61 to 81), Google LLC (Defendant No.
82), Internet Service providers (Defendant Nos. 83 to 91) as well as the concerned
government departments (Department of Telecommunication and the Ministry of Electronics
and Information Technology) (Defendant Nos. 92 and 93 respectively), as Defendants, to ensure
effective compliance of any orders that the Hon’ble Delhi High Court may be inclined to pass.
3.

You would recall that the above-mentioned matter came up before Hon’ble Justice Mini

Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble Court was
pleased to issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a
prima facie case for grant of injunction and, in case, no ex parte ad interim
injunction is granted, the plaintiff will suffer an irreparable loss. Further, balance
of convenience also lies in favour of the plaintiff, and against the defendants.
41. Accordingly, till the next date of hearing, the following
directions are issued:
about:blank

4/17

<!-- page 30 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

I. The defendant nos. 1 to 60, their owners, partners, officers and
all others in capacity of principal or agent acting for and on their behalf, or
anyone claiming through, by or under it, are restrained from in any manner
communicating, hosting, streaming, and/or making available for viewing and
downloading, without authorization, on their websites or other platforms, through
the internet in any manner whatsoever, the plaintiff’s works so as to infringe the
plaintiff’s exclusive rights and broadcast reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners,
proprietors, officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and, on their behalf, or anyone claiming through, by
or under it, are directed to suspend the domain name registration of the defendant
nos. 1 to 60, as per the details as given in Annexure-B to the present order.
III. The defendant nos. 61 to 81, are directed to disclose the
following information of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone
number, IP address, etc.
b. Mode of payment along with payment details used for
registration of domain name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners,
proprietors, officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and on their behalf, or anyone claiming through, by
or under it, are directed to block access to the various websites identified by the
plaintiff, details of which are given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification
calling upon the various internet service providers registered under it to block
access to the various websites identified by the plaintiff in the instant suit, details
of which are given as Annexure-C.
VI. If during the pendency of the present suit, any further
websites are discovered by the plaintiff, which are illegally streaming
the infringing content, copyright of which is owned by the plaintiff, the
plaintiff is granted liberty to communicate the details of such websites
to defendant no. 92 (Department of Telecommunications) and
defendant no. 93 (Ministry of Electronics and Information
Technology), for issuance of blocking orders and simultaneously to the
Internet Service Providers (“ISPs”) for blocking the said websites.
VII. Upon receiving the said intimation from the plaintiff,
the ISPs shall take steps to immediately block the rogue websites in
question.
VIII. The DOT and MEITY shall also issue necessary blocking
orders immediately upon the plaintiff, communicating the details of the websites,
which are illegally streaming the content, over which the plaintiff has rights.
IX. After communication of details of the rogue websites to the
concerned authorities, the plaintiff shall continue to file affidavits with the Court,
in order to ensure that the Court is fully informed of the websites in respect of
which blocking orders are sought.
X. If any website, which is not primarily an infringing site, is
blocked pursuant to the present order, they shall be permitted to approach this
Court by giving an undertaking that it does not intend to engage in any
unauthorized streaming of any content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the
plaintiff, the plaintiff shall be at liberty to file an application for their
impleadment, which shall be taken up before the Joint Registrar (Judicial), and the
order passed today shall be extended to the said newly impleaded website as well.
XXX
about:blank

5/17

<!-- page 31 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

47. Compliance of Order XXXIX Rule 3 CPC, be done, within a
period of one week from today.
4. In light of the above, you are hereby requested to comply with the order
dated 24th October 2024, passed by the Hon'ble Delhi High Court, by
immediately issuing blocking orders, calling on internet and telecom service
providers to immediately block access to the attached lists of additional websites,
which are illegally streaming / making available Our Client’s Works, over which Our
Client has exclusive rights.
5. For your convenience, the Order dated 24th October 2024, passed by the Hon'ble Delhi
High Court is re-attached herewith.
6. The Twenty-Fifth, Twenty-Sixth and Twenty-Seventh Lists of the additional websites are
also enclosed herewith along with the evidence collected qua the said additional rogue streaming
websites (for all the said lists), which is accessible at the link below:
https://drive.google.com/drive/folders/1-CFYQYYDVh-IZEoYAmk3UpuYPkCV08Cn?
usp=sharing
You are hereby requested to confirm the compliance of the Order by issuing the
necessary blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,
Angad Makkar
(D/3579/2021)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited
-Angad Makkar | Senior Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003|
Handphone: +91-9897896284 | [Enrolment No. D/3579/2021]

• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional
privilege, not being waived or lost by mistaken transmission or receipt. If you have
received
this
mail
in
error,
please
notify
us
at info@saikrishnaassociates.com immediately by reply email and destroy the original any use, disclosure or copying of this mail is unauthorised.
On Wed, 8 Jul 2026 at 16:44, Angad Makkar <angad@saikrishnaassociates.com>
wrote:
URGENT ACTION REQUIRED
about:blank

6/17

<!-- page 32 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a company
incorporated under the Companies Act, 1956 and having its registered office at 18th Floor, A
Wing, Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and having its branch
office at FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1.
You would recall that in response to blatant, large-scale copyright infringement of
content on Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted before
the Hon’ble Delhi Court against various rogue websites (impleaded as Defendant Nos. 1 to 60)
in the captioned matter) which engage in communicating to the public, hosting, streaming
and/or making available to the public Our Client’s Works without authorization and / or
facilitating the same.
2. The suit so instituted was inter alia, for permanent injunction, rendition of accounts
and damages, on account of blatant piracy of Our Client’s Works and infringement of
copyright and broadcast reproduction rights of Our Client and for that purpose, Our Client has
impleaded various Domain Name Registrars (Defendant Nos. 61 to 81), Google LLC
(Defendant No. 82), Internet Service providers (Defendant Nos. 83 to 91) as well as
the concerned government departments (Department of Telecommunication and the Ministry
of Electronics and Information Technology) (Defendant Nos. 92 and 93 respectively), as
Defendants, to ensure effective compliance of any orders that the Hon’ble Delhi High Court
may be inclined to pass.
3. You would recall that the above-mentioned matter came up before Hon’ble Justice
Mini Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble Court
was pleased to issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a
prima facie case for grant of injunction and, in case, no ex parte ad interim
injunction is granted, the plaintiff will suffer an irreparable loss. Further,
balance of convenience also lies in favour of the plaintiff, and against the
defendants.
41. Accordingly, till the next date of hearing, the following
directions are issued:
I. The defendant nos. 1 to 60, their owners, partners, officers
and all others in capacity of principal or agent acting for and on their behalf, or
anyone claiming through, by or under it, are restrained from in any manner
communicating, hosting, streaming, and/or making available for viewing and
downloading, without authorization, on their websites or other platforms,
through the internet in any manner whatsoever, the plaintiff’s works so as to
infringe the plaintiff’s exclusive rights and broadcast reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners,
proprietors, officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and, on their behalf, or anyone claiming through,
by or under it, are directed to suspend the domain name registration of the
defendant nos. 1 to 60, as per the details as given in Annexure-B to the present
order.
III. The defendant nos. 61 to 81, are directed to disclose the
following information of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone
number, IP address, etc.
b. Mode of payment along with payment details used for
registration of domain name by the registrant(s).
about:blank

7/17

<!-- page 33 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

IV. The defendant nos. 83 to 91, their directors, partners,
proprietors, officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and on their behalf, or anyone claiming through,
by or under it, are directed to block access to the various websites identified by
the plaintiff, details of which are given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a
notification calling upon the various internet service providers registered under
it to block access to the various websites identified by the plaintiff in the instant
suit, details of which are given as Annexure-C.
VI. If during the pendency of the present suit, any
further websites are discovered by the plaintiff, which are illegally
streaming the infringing content, copyright of which is owned by the
plaintiff, the plaintiff is granted liberty to communicate the details of
such
websites
to
defendant
no.
92
(Department
of
Telecommunications) and defendant no. 93 (Ministry of Electronics
and Information Technology), for issuance of blocking orders and
simultaneously to the Internet Service Providers (“ISPs”) for
blocking the said websites.
VII. Upon receiving the said intimation from the
plaintiff, the ISPs shall take steps to immediately block the rogue
websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking
orders immediately upon the plaintiff, communicating the details of the
websites, which are illegally streaming the content, over which the plaintiff has
rights.
IX. After communication of details of the rogue websites to the
concerned authorities, the plaintiff shall continue to file affidavits with the
Court, in order to ensure that the Court is fully informed of the websites in
respect of which blocking orders are sought.
X. If any website, which is not primarily an infringing site, is
blocked pursuant to the present order, they shall be permitted to approach this
Court by giving an undertaking that it does not intend to engage in any
unauthorized streaming of any content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the
plaintiff, the plaintiff shall be at liberty to file an application for their
impleadment, which shall be taken up before the Joint Registrar (Judicial), and
the order passed today shall be extended to the said newly impleaded website as
well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done, within a
period of one week from today.
4. In light of the above, you are hereby requested to comply with the order
dated 24th October 2024, passed by the Hon'ble Delhi High Court, by
immediately issuing blocking orders, calling on internet and telecom service
providers to immediately block access to the attached lists of additional websites,
which are illegally streaming / making available Our Client’s Works, over which
Our Client has exclusive rights.
5.
For your convenience, the Order dated 24th October 2024, passed by the Hon'ble
Delhi High Court is re-attached herewith.
6. The Twenty-Fifth, Twenty-Sixth and Twenty-Seventh Lists of the additional websites
are also enclosed herewith along with the evidence collected qua the said additional rogue
streaming websites (for all the said lists), which is accessible at the link below:
about:blank

8/17

<!-- page 34 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

https://drive.google.com/drive/folders/1-CFYQYYDVh-IZEoYAmk3UpuYPkCV08Cn?
usp=sharing
You are hereby requested to confirm the compliance of the Order by issuing the
necessary blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,
Angad Makkar
(D/3579/2021)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited

-Angad Makkar | Senior Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003|
Handphone: +91-9897896284 | [Enrolment No. D/3579/2021]

• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019
& 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport
-2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious

The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional
privilege, not being waived or lost by mistaken transmission or receipt. If you have
received
this
mail
in
error,
please
notify
us
at info@saikrishnaassociates.com immediately by reply email and destroy the original any use, disclosure or copying of this mail is unauthorised.
On Tue, 1 Jul 2025 at 17:50, Rishabh Rao <rishabh@saikrishnaassociates.com>
wrote:
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a company
incorporated under the Companies Act, 1956 and having its registered office at 18th Floor, A
Wing, Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and having its
branch office at FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1.
You would recall that in response to blatant, large-scale copyright infringement of
content on Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted

about:blank

9/17

<!-- page 35 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

before the Hon’ble Delhi Court against various rogue websites (impleaded as Defendant
Nos. 1 to 60) in the captioned matter) which engage in communicating to the public,
hosting, streaming and/or making available to the public Our Client’s Works without
authorization and / or facilitating the same.
2.
The suit so instituted was inter alia, for permanent injunction, rendition of accounts and
damages, on account of blatant piracy of Our Client’s Works and infringement of
copyright and broadcast reproduction rights of Our Client and for that purpose, Our
Client has impleaded various Domain Name Registrars (Defendant Nos. 61 to 81), Google
LLC (Defendant No. 82), Internet Service providers (Defendant Nos. 83 to 91) as well as
the concerned government departments (Department of Telecommunication
and the Ministry of Electronics and Information Technology) (Defendant
Nos. 92 and 93 respectively), as Defendants, to ensure effective compliance of any
orders that the Hon’ble Delhi High Court may be inclined to pass.
3.
You would recall that the above-mentioned matter came up before Hon’ble Justice Mini
Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble Court
was pleased to issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a prima facie
case for grant of injunction and, in case, no ex parte ad interim injunction is
granted, the plaintiff will suffer an irreparable loss. Further, balance of
convenience also lies in favour of the plaintiff, and against the defendants.
41. Accordingly, till the next date of hearing, the following directions are
issued:
I. The defendant nos. 1 to 60, their owners, partners, officers and all others in
capacity of principal or agent acting for and on their behalf, or anyone
claiming through, by or under it, are restrained from in any manner
communicating, hosting, streaming, and/or making available for viewing
and downloading, without authorization, on their websites or other
platforms, through the internet in any manner whatsoever, the plaintiff’s
works so as to infringe the plaintiff’s exclusive rights and broadcast
reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of principal
or agent acting for and, on their behalf, or anyone claiming through, by or
under it, are directed to suspend the domain name registration of the
defendant nos. 1 to 60, as per the details as given in Annexure-B to the present
order.
III. The defendant nos. 61 to 81, are directed to disclose the following
information of defendant nos. 1 to 60:

about:blank

10/17

<!-- page 36 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

a. Complete details such as name, address, email address, phone number, IP
address, etc.
b. Mode of payment along with payment details used for registration of
domain name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners, proprietors, officers,
affiliates, servants, employees, and all others in capacity of principal or agent
acting for and on their behalf, or anyone claiming through, by or under it, are
directed to block access to the various websites identified by the plaintiff,
details of which are given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification calling
upon the various internet service providers registered under it to block access
to the various websites identified by the plaintiff in the instant suit, details of
which are given as Annexure-C.
VI. If during the pendency of the present suit, any further websites
are discovered by the plaintiff, which are illegally streaming the
infringing content, copyright of which is owned by the plaintiff, the
plaintiff is granted liberty to communicate the details of such
websites to defendant no. 92 (Department of Telecommunications)
and defendant no. 93 (Ministry of Electronics and Information
Technology), for issuance of blocking orders and simultaneously to
the Internet Service Providers (“ISPs”) for blocking the said
websites.
VII. Upon receiving the said intimation from the plaintiff, the ISPs shall take
steps to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking
orders immediately upon the plaintiff, communicating the details
of the websites, which are illegally streaming the content, over
which the plaintiff has rights.
IX. After communication of details of the rogue websites to the concerned
authorities, the plaintiff shall continue to file affidavits with the Court, in
order to ensure that the Court is fully informed of the websites in respect of
which blocking orders are sought.
X. If any website, which is not primarily an infringing site, is blocked
pursuant to the present order, they shall be permitted to approach this Court
by giving an undertaking that it does not intend to engage in any
unauthorized streaming of any content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the plaintiff, the
plaintiff shall be at liberty to file an application for their impleadment, which
shall be taken up before the Joint Registrar (Judicial), and the order passed
today shall be extended to the said newly impleaded website as well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done, within a period of one
week from today.
about:blank

11/17

<!-- page 37 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

4.
In light of the above, you are hereby requested to comply with the order
dated 24th October 2024, passed by the Hon'ble Delhi High Court, by
immediately issuing blocking orders, calling on internet and telecom service
providers to immediately block access to the attached list of additional
websites, which are illegally streaming / making available Our Client’s
Works, over which Our Client has exclusive rights.
5.
For your convenience, the Order dated 24th October 2024, passed by the Hon'ble Delhi
High Court is re – attached herewith.
6.
The Twenty-Fourth List of the additional websites is also enclosed herewith along with
the evidence collected qua the additional rogue streaming websites, which is accessible at
the link below:
https://drive.google.com/drive/folders/1W6oY1qNOc1YFCGVMSsr66O0-N_Wc1Um6?
usp=drive_link

You are hereby requested to confirm the compliance of the Order by issuing the
necessary blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,
Rishabh Rao
(KAR/3753/2023)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited
Rishabh Rao | Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003 |
Mobile: +91 7676612211 | [Enrolment No. KAR/3753/2023]
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional
privilege, not being waived or lost by mistaken transmission or receipt. If you have
received
this
mail
in
error,
please
notify
us
at info@saikrishnaassociates.com immediately by reply email and destroy the original any use, disclosure or copying of this mail is unauthorised.

about:blank

12/17

<!-- page 38 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

On Mon, Jun 30, 2025 at 2:28 PM Rishabh Rao
<rishabh@saikrishnaassociates.com> wrote:
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a
company incorporated under the Companies Act, 1956 and having its registered office at 18th
Floor, A Wing, Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013 and
having its branch office at FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1.
You would recall that in response to blatant, large-scale copyright infringement of
content on Zee5 and the Zee Channels (“Our Client’s Works”), a suit was instituted
before the Hon’ble Delhi Court against various rogue websites (impleaded as
Defendant Nos. 1 to 60) in the captioned matter) which engage in communicating to
the public, hosting, streaming and/or making available to the public Our Client’s
Works without authorization and / or facilitating the same.
2.
The suit so instituted was inter alia, for permanent injunction, rendition of accounts
and damages, on account of blatant piracy of Our Client’s Works and infringement of
copyright and broadcast reproduction rights of Our Client and for that purpose, Our
Client has impleaded various Domain Name Registrars (Defendant Nos. 61 to 81),
Google LLC (Defendant No. 82), Internet Service providers (Defendant Nos. 83 to 91)
as well as the concerned government departments (Department of
Telecommunication and the Ministry of Electronics and Information
Technology) (Defendant Nos. 92 and 93 respectively), as Defendants, to
ensure effective compliance of any orders that the Hon’ble Delhi High Court may be
inclined to pass.
3.
You would recall that the above-mentioned matter came up before Hon’ble Justice
Mini Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’ble
Court was pleased to issue the following directions in favour of Our Client:
40. In the above circumstances, the plaintiff has demonstrated a prima
facie case for grant of injunction and, in case, no ex parte ad interim
injunction is granted, the plaintiff will suffer an irreparable loss. Further,
balance of convenience also lies in favour of the plaintiff, and against the
defendants.
41. Accordingly, till the next date of hearing, the following directions are
issued:
I. The defendant nos. 1 to 60, their owners, partners, officers and all others
in capacity of principal or agent acting for and on their behalf, or anyone
about:blank

13/17

<!-- page 39 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

claiming through, by or under it, are restrained from in any manner
communicating, hosting, streaming, and/or making available for viewing
and downloading, without authorization, on their websites or other
platforms, through the internet in any manner whatsoever, the plaintiff’s
works so as to infringe the plaintiff’s exclusive rights and broadcast
reproduction rights.
II. The defendant nos. 61 to 81 and its directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and, on their behalf, or anyone claiming
through, by or under it, are directed to suspend the domain name
registration of the defendant nos. 1 to 60, as per the details as given in
Annexure-B to the present order.
III. The defendant nos. 61 to 81, are directed to disclose the following
information of defendant nos. 1 to 60:
a. Complete details such as name, address, email address, phone number,
IP address, etc.
b. Mode of payment along with payment details used for registration of
domain name by the registrant(s).
IV. The defendant nos. 83 to 91, their directors, partners, proprietors,
officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and on their behalf, or anyone claiming
through, by or under it, are directed to block access to the various websites
identified by the plaintiff, details of which are given as Annexure C.
V. The defendant nos. 92 and 93 are directed to issue a notification calling
upon the various internet service providers registered under it to block
access to the various websites identified by the plaintiff in the instant suit,
details of which are given as Annexure-C.
VI. If during the pendency of the present suit, any further
websites are discovered by the plaintiff, which are illegally
streaming the infringing content, copyright of which is owned by
the plaintiff, the plaintiff is granted liberty to communicate the
details of such websites to defendant no. 92 (Department of
Telecommunications)

and

defendant

no.

93

(Ministry

of

Electronics and Information Technology), for issuance of
blocking orders and simultaneously to the Internet Service
Providers (“ISPs”) for blocking the said websites.
VII. Upon receiving the said intimation from the plaintiff, the ISPs shall
take steps to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking
orders immediately upon the plaintiff, communicating the
details of the websites, which are illegally streaming the content,
over which the plaintiff has rights.

about:blank

14/17

<!-- page 40 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

IX. After communication of details of the rogue websites to the concerned
authorities, the plaintiff shall continue to file affidavits with the Court, in
order to ensure that the Court is fully informed of the websites in respect of
which blocking orders are sought.
X. If any website, which is not primarily an infringing site, is blocked
pursuant to the present order, they shall be permitted to approach this
Court by giving an undertaking that it does not intend to engage in any
unauthorized streaming of any content, over which the plaintiff has rights.
XI. As and when new further websites are discovered by the plaintiff, the
plaintiff shall be at liberty to file an application for their impleadment,
which shall be taken up before the Joint Registrar (Judicial), and the order
passed today shall be extended to the said newly impleaded website as well.
XXX
47. Compliance of Order XXXIX Rule 3 CPC, be done, within a period of one
week from today.
4.
In light of the above, you are hereby requested to comply with the order
dated 24th October 2024, passed by the Hon'ble Delhi High Court, by
immediately issuing blocking orders, calling on internet and telecom
service providers to immediately block access to the attached list of
additional websites, which are illegally streaming / making available Our
Client’s Works, over which Our Client has exclusive rights.
5.
For your convenience, the Order dated 24th October 2024, passed by the Hon'ble
Delhi High Court is re – attached herewith.
6.
The Twenty-Third List of the additional websites is also enclosed herewith along with
the evidence collected qua the additional rogue streaming websites, which is accessible
at the link below:
https://drive.google.com/drive/folders/1HUBVG_5p-r9KD4EBCVbz1aivDXET3Soa?
usp=drive_link
You are hereby requested to confirm the compliance of the Order by issuing the
necessary blocking orders qua the additional websites.
If you have any queries, please feel free to contact us.
You are requested to acknowledge receipt of the present email.
Regards,

about:blank

15/17

<!-- page 41 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

Rishabh Rao
(KAR/3753/2023)
Saikrishna & Associates
Counsels for Zee Entertainment Enterprises Limited
Rishabh Rao | Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003 |
Mobile: +91 7676612211 | [Enrolment No. KAR/3753/2023]
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional
privilege, not being waived or lost by mistaken transmission or receipt. If you have
received
this
mail
in
error,
please
notify
us
at info@saikrishnaassociates.com immediately by reply email and destroy the original any use, disclosure or copying of this mail is unauthorised.
On Fri, Jun 27, 2025 at 11:06 AM Rishabh Rao
<rishabh@saikrishnaassociates.com> wrote:
URGENT ACTION REQUIRED
Dear Sir / Madam,
We continue to act on behalf of our Client, Zee Entertainment Enterprises Limited, a
company incorporated under the Companies Act, 1956 and having its registered office at
18th Floor, A Wing, Marathon Futurex, N.M. Joshi Marg, Lower Parel, Mumbai – 400013
and having its branch office at FC-19, Sector 16-A, Noida – 201301 (“Our Client”).
1.
You would recall that in response to blatant, large-scale copyright infringement of
content on Zee5 and the Zee Channels (“Our Client’s Works”), a suit was
instituted before the Hon’ble Delhi Court against various rogue websites (impleaded
as Defendant Nos. 1 to 60) in the captioned matter) which engage in communicating
to the public, hosting, streaming and/or making available to the public Our Client’s
Works without authorization and / or facilitating the same.
2.
The suit so instituted was inter alia, for permanent injunction, rendition of accounts
and damages, on account of blatant piracy of Our Client’s Works and infringement
of copyright and broadcast reproduction rights of Our Client and for that purpose,
Our Client has impleaded various Domain Name Registrars (Defendant Nos. 61 to
81), Google LLC (Defendant No. 82), Internet Service providers (Defendant Nos. 83
to 91) as well as the concerned government departments (Department of
Telecommunication and the Ministry of Electronics and Information
about:blank

16/17

<!-- page 42 -->

7/15/26, 10:18 AM

Fwd: Re: URGENT | Twenty-Eighth, Twenty-Ninth and Thirtieth List of Additional Websites for Real – Time Blocking in Compli…

Technology) (Defendant Nos. 92 and 93 respectively), as Defendants, to
ensure effective compliance of any orders that the Hon’ble Delhi High Court may be
inclined to pass.
3.
You would recall that the above-mentioned matter came up before Hon’ble Justice
Mini Pushkarna, Delhi High Court, on 24th October 2024, on which date the Hon’b

4 Attachment(s)

about:blank

Injunction Order dt. 24.10.202…

30th List of Websites.xlsx

3.6 MB

13.7 KB

29th List of Websites.xlsx

28th List of Websites.xlsx

13.7 KB

13.7 KB

17/17

<!-- page 43 -->

List 28
S.No
1
2
3
4
5
6
7
8
9
10

Domain
desicinemas.to
filmyzilla45.in
filmywapn.in
go.india4movies.net
desicinemas.pk
moviesbaba.lol
ssrmovies.archi
hdmoviesnew.com
newhdmovie2.cam
vegamovles.dev

List 29
S.No
1
2
3
4
5
6
7
8
9
10

Domain
mastibaaz.com
1desiremovies.dad
mlhbd.fun
moviedokan.co
new2.hdhub4u.cl
mp4bay.com
hdmoviehub.recipes
moviesjoy.bz
filmvdo.com
new3.movies4u.finance

List 30
S.No
1
2
3
4
5
6
7
8
9
10

Domain
ww8.123movies.com.pk
bollyhub.info
pakbcnhd.pk
hdmovie2r.solar
d5.downloadhub.food
moviesnation.fans
jalshamoviez.diy
multimovies.watch
desimovies.ru
hdtodayz.org

<!-- page 44 -->

$~56
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 937/2024 & I.A. 43185/2024, I.A. 43186/2024, I.A.
43187/2024, I.A. 43188/2024, I.A. 43189/2024
ZEE ENTERTAINMENT ENTERPRISES LIMITED
Through:

.....Plaintiff

Mr. Sidharth Chopra, Mr. Vivek
Ayyagari, Mr. Angad S. Makkar, Mr.
Rishabh Rao, and Ms. Chanda
Shashikant, Advocates.
Mob: 7676612211
Email:
rishabh@saikrishnaassociates.com

versus
BOLLYZONE.TV & ORS.
Through:

.....Defendants
Mr. Neel Mason, Advocate with Mr.
Vihan Dang, Mr. Ujjawal Bhargava
and Mr. Aditya Mathur, Advocates
for D-82
Mob: 9399304251
Email:
ujjawal.bhargava@mason.co.in

CORAM:
HON'BLE MS. JUSTICE MINI PUSHKARNA
ORDER
24.10.2024

%

I.A. 43188/2024 ((Exemption from filing certified clearer/ typed copies
of documents)
1.

The present is an application under Section 151 of the Code of Civil

Procedure, 1908 (“CPC”), on behalf of the plaintiff, seeking exemption from

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 1 of 27

<!-- page 45 -->

filing certified clearer/typed or translated copies of documents.
2.

Exemption is granted, subject to all just exceptions.

3.

Plaintiff shall file original, clearer, and translated copies of the

documents, on which the plaintiff may seek to place reliance, before the next
date of hearing.
4.

Accordingly, the present application is disposed of.

I.A. 43189/2024 (Exemption from instituting Pre-Institution Mediation)
5.
The present is an application under Section 12A of the Commercial
Courts Act, 2015, read with Section 151 of CPC, seeking exemption from
undergoing Pre-Institution Mediation.
6.

Having regard to the facts of the present case and in the light of the

judgment of Supreme Court in the case of Yamini Manohar Versus T.K.D.
Keerthi, 2023 SCC OnLine SC 1382, and Division Bench of this Court in
Chandra Kishore Chaurasia Versus RA Perfumery Works Private Ltd.,
2022 SCC OnLine Del 3529, exemption from attempting Pre-Institution
Mediation, is granted.
7.

Accordingly, the application stands disposed of.

I.A. 43186/2024 (Exemption from advance service to the defendant nos.
84, 89, 92 and 93)
8.

The present is an application under Rule 22 of Delhi High Court

Intellectual Property Rights Division Rules, 2022, read with Section 151
CPC, seeking exemption from advance service to defendant nos. 84, 89, 92
and 93.
9.

The plaintiff seeks urgent interim relief. Therefore, in the peculiar

facts and circumstances of this case, exemption from effecting advance
service upon the defendant nos. 84, 89, 92 and 93, is granted.

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 2 of 27

<!-- page 46 -->

10.

For the reasons stated in the application, the same is allowed and

disposed of.
I.A. 43187/2024 (Application seeking leave to file additional documents)
11.

This is an application under Order XI Rule 1(4) read with Section 151

CPC as amended by the Commercial Courts Act, 2015, seeking leave to file
additional documents.
12.

The plaintiff, if it wishes to file additional documents at a later stage,

shall do so strictly as per the provisions of Commercial Courts Act, 2015
and the Delhi High Court (Original Side) Rules, 2018.
13.

The application is disposed of, with the aforesaid directions.

CS(COMM) 937/2024
14.

Let the plaint be registered as suit.

15.

Issue summons.

16.

Summons is accepted by learned counsel appearing for defendant no.

82.
17.

Upon filing of the process fee, issue summons to the other defendants

by all permissible modes. Summons shall state that the written statement be
filed by the defendants within thirty days from the date of receipt of
summons. Along with the written statement, the defendants shall also file
affidavit of admission/denial of the plaintiff’s documents, without which, the
written statement shall not be taken on record.
18.

Liberty is given to the plaintiff to file replication within thirty days

from the date of receipt of the written statement. Further, along with the
replication, if any, filed by the plaintiff, an affidavit of admission/denial of
documents of the defendants, be filed by the plaintiff, without which, the
replication shall not be taken on record. If any of the parties wish to seek

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 3 of 27

<!-- page 47 -->

inspection of the documents, the same shall be sought and given within the
timelines.
19.

List before the Joint Registrar (Judicial) for marking of exhibits, on

17th December, 2024.
20.

List before the Court on 07th March, 2025.

I.A. 43185/2024 (Under Order XXXIX Rules 1 and 2 CPC)
21.

The instant suit is being filed for permanent injunction, rendition of

accounts and damages, on account of blatant piracy of the plaintiff’s works
and infringement of copyright and broadcast reproduction rights of the
plaintiff. The plaintiff, a reputed broadcaster, production house and film
studio, owns and operates the Zee Channels and the digital entertainment
platform/streaming service called ‘Zee5’ respectively.
22.

It is submitted that the plaintiff has the exclusive distribution rights to

publicly exhibit and communicate through any medium or mode, the content
on Zee5 and the Zee Channels produced by the plaintiff or exclusively
licensed/assigned to the plaintiff (“plaintiff’s works”). The plaintiff’s works
are protected as “Cinematograph Films” under Section 2(f) read with
Section 13 of the Copyright Act, 1957 (“the Act”). The plaintiff has the
exclusive right to make the plaintiff’s works available for being seen or
heard, or otherwise enjoyed by the public, as enumerated under Section
14(d) of the Act, and further, is also entitled to broadcast reproduction rights
in respect of its broadcasts, under Section 37 of the Act.
23.

It is submitted that the plaintiff has observed the rampant and large-

scale infringement of the plaintiff’s works by the defendant nos. 1 to 60
arrayed in the present suit, which are rogue websites engaged in
communicating to the public, hosting, streaming and/or making available to

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 4 of 27

<!-- page 48 -->

the public the plaintiff’s works without authorization, and/or facilitating the
same. The plaintiff has come across its original content/television shows/
series, such as Bastar - The Naxal Story, Kakuda, Rautu ka Raaz, Silence 2 The Night Owl Bar Shootout, Kumkum Bhagya, Bhagya Laxmi, Appi
Amchi Collector, Khundali Bhagya, Saatvya Mulichi Saatvi Mulgi,
Idhayam, Sunflower, Ayali, Rangbaaz Season 3, Thalamai Seiyalagam,
Broken News, Paruvu, Murshid, Karenjit Kaur, and Sitara being hosted and /
or streamed on the defendant websites, without any authorisation by the
plaintiff.
24.

It is submitted that defendant nos. 1 to 60 are essentially, ‘rogue

websites’ which are engaged in displaying pirated content in order to obtain
certain financial benefits. The defendant websites are anonymous in nature,
the owners of which are virtually impossible to locate, as the information
provided in the public domain is either, incomplete, incorrect and/or
protected behind a veil of secrecy. The defendant websites’ mala fides are
evident from the vast volume of third-party content available on its websites;
the systematic, organised and intentional nature of the infringement; and
also the regularity and consistency with which content is updated/uploaded
on the websites, as is evident from the documents filed along with the plaint.
Such voluminous evidence of copyright infringement by the said defendants
clearly establishes that the defendant websites are ‘rogue’ in terms of the
judgment of the Hon’ble High Court of Delhi in UTV Software
Communications Ltd. & Anr. v. 1337x.to and Ors. (2019 SCC OnLine Del
8002).
25.

It is submitted that the defendant nos. 61 to 81 are Domain Name

Registrars which have been arrayed for the purpose of blocking access to/

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 5 of 27

<!-- page 49 -->

locking/suspending the defendant websites and to disclose information
related to the registrants of the said websites, such as name, address, email
address, mobile number, payment details etc.
26.

It is submitted that the plaintiff has arrayed Google LLC as defendant

no. 82 for the purpose of de-indexing/delisting of the domain names/
websites of such rogue defendant websites from the search results produced
on the search engine, ‘Google’, owned/operated by the defendant no. 82.
27.

It is submitted that the defendant nos. 83 to 91 are Internet Service

Providers which are being arrayed for the limited purpose of blocking/
restricting access to the rogue websites identified in the present suit or any
other website subsequently identified by the plaintiff on affidavit.
28.

It is submitted that the plaintiff has arrayed defendant no. 92,

Department of Telecommunications, and defendant No. 93, Ministry of
Electronics and Information Technology for the issuance of a notification to
the internet and telecom service providers to disable access to the defendant
websites identified in the present suit and such other websites subsequently
discovered and identified by the plaintiff to be infringing the rights of the
plaintiff. The defendant no. 94 is ‘Ashok Kumar’. No formal relief is sought
against the defendant nos. 61 to 94.
29.

It is submitted that defendant nos. 1-60 are mostly anonymous

websites. Details of their owners are either hidden or are forged/inaccurate.
These websites are vehicles of infringement and engage in flagrant violation
of the intellectual property rights of the plaintiff. Due to the nature of the
internet, which offers anonymity, these websites in a systematic manner,
engage in violation of the intellectual property rights of the plaintiff. The
websites of defendant nos. 1-60 are predominantly engaged in violating third

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 6 of 27

<!-- page 50 -->

party rights.
30.

It is submitted that in view of the aforesaid, the plaintiff has filed the

present suit seeking protection of its exclusive rights under the Act. On
account of being the producer, exclusive licensee and exclusive assignee
having adequate right, and the fact that defendant nos. 1–60 have been
violating the rights of the plaintiff, the plaintiff has established a prima facie
case in its favour. The plaintiff would suffer irreparable harm and injury if
an order of injunction is not passed. The balance of convenience is in favour
of the plaintiff on account of it being the rights-owner and having legitimate
interest which needs protection.
31.

Learned counsel appearing for the plaintiff has drawn the attention of

this Court to the various infringing content which is available on these rogue
sites. The list of the defendant websites, and the corresponding pages of the
documents filed along with the present plaint, is attached as Annexure-A to
the present order.
32.

It is submitted that as the plaintiff’s works enjoy protection as a

‘cinematograph films’ under the Act, the making available and/or
communication to the public of the plaintiff’s works, without their
authorisation, by the defendant websites would amount to a violation of the
plaintiff’s exclusive rights under the Act. The balance of convenience is
clearly against the defendant websites, which do not have authorisation with
respect to the plaintiff’s works, including, inter alia, to host, stream,
reproduce, permit download of/distribute, make available to the public
and/or communicate the plaintiff’s motion pictures, original content
television shows, web-series and other cinematographic works, or facilitate
the same. It is submitted that if the illegal activities of the defendant

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 7 of 27

<!-- page 51 -->

websites are not restrained during the pendency of the present proceedings,
plaintiff shall suffer irreparable harm since it is submitted that the defendant
websites intend to continue to exploit the plaintiff’s property with impunity,
thereby, diminishing and diluting the value of the plaintiff’s rights.
33.

Further, it is submitted that this Court in Zee Entertainment

Enterprises Limited versus Jbomma.Bar and Ors. (CS(COMM) 650/2022),
vide order dated 19th September, 2022, had restrained certain rogue websites
therein from communicating, hosting, streaming and/or making available for
viewing and downloading, without authorization on their websites or other
platforms, through the internet in any manner whatsoever, the plaintiff’s
works. Further, vide its order 27th February, 2024, inter alia, directed the
Domain Name Registrars therein to revoke domain name registrations of
such rogue websites and to furnish complete details of such rogue websites.
Further, this Court in Zee Entertainment Enterprises Limited versus All
Rounder Tv and Ors., (CS(COMM) 921/2023), vide its order dated 12th
January, 2024, guided by the principles laid down in and in furtherance of
the UTV Judgment, restrained third-party mobile applications arrayed as
defendants therein from communicating to the public, hosting, storing,
reproducing, streaming, broadcasting, re-broadcasting, causing, to be seen or
heard by public on payment of charge and/or making available for viewing
the plaintiff’s Works through their websites or apps.
34.

It is submitted that the plaintiff’s entire business depends on the

protection of its invaluable intellectual property and in case the same are
infringed, the entire business model of the plaintiff will be at great risk and
will be adversely affected. The plaintiff has invested huge sums in the
production, promotion, distribution and exploitation of the plaintiff’s works.

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 8 of 27

<!-- page 52 -->

It is submitted that if the infringement thereof is not prevented, it would
result in threatening the very future and existence of respective original
shows/ television shows/original content since production houses would be
unable to raise funds for future works.
35.

At this stage, learned counsel appearing for defendant no. 82, i.e.,

Google, submits that the address of the Google has been incorrectly
reflected in the Memo of Parties.
36.

Let correct address be provided by learned counsel appearing for

defendant no. 82-Google to the plaintiff.
37.

Amended memo of parties shall be filed within a period of one week

from today.
38.

Learned counsel appearing for defendant no. 82 further submits that at

this stage no directions be given to defendant no. 82 for de-indexing/delisting the defendant websites, as the defendant no. 82 being a search engine,
any website which is suspended, is not shown as part of the index published
in the search engine.
39.

He further submits that this may take some time in view of the

technological issues.
40.

In the above circumstances, the plaintiff has demonstrated a prima

facie case for grant of injunction and, in case, no ex parte ad interim
injunction is granted, the plaintiff will suffer an irreparable loss. Further,
balance of convenience also lies in favour of the plaintiff, and against the
defendants.
41.

Accordingly, till the next date of hearing, the following directions are

issued:
I.

The defendant nos. 1 to 60, their owners, partners, officers and all

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 9 of 27

<!-- page 53 -->

others in capacity of principal or agent acting for and on their behalf, or
anyone claiming through, by or under it, are restrained from in any manner
communicating, hosting, streaming, and/or making available for viewing
and downloading, without authorization, on their websites or other
platforms, through the internet in any manner whatsoever, the plaintiff’s
works so as to infringe the plaintiff’s exclusive rights and broadcast
reproduction rights.
II.

The defendant nos. 61 to 81 and its directors, partners, proprietors,

officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and, on their behalf, or anyone claiming
through, by or under it, are directed to suspend the domain name registration
of the defendant nos. 1 to 60, as per the details as given in Annexure-B to the
present order.
III.

The defendant nos. 61 to 81, are directed to disclose the following

information of defendant nos. 1 to 60:
a.

Complete details such as name, address, email address, phone

number, IP address, etc.
b.

Mode of payment along with payment details used for registration of

domain name by the registrant(s).
IV.

The defendant nos. 83 to 91, their directors, partners, proprietors,

officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and on their behalf, or anyone claiming through,
by or under it, are directed to block access to the various websites identified
by the plaintiff, details of which are given as Annexure C.
V.

The defendant nos. 92 and 93 are directed to issue a notification

calling upon the various internet service providers registered under it to

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 10 of 27

<!-- page 54 -->

block access to the various websites identified by the plaintiff in the instant
suit, details of which are given as Annexure-C.
VI.

If during the pendency of the present suit, any further websites are

discovered by the plaintiff, which are illegally streaming the infringing
content, copyright of which is owned by the plaintiff, the plaintiff is granted
liberty to communicate the details of such websites to defendant no. 92
(Department of Telecommunications) and defendant no. 93 (Ministry of
Electronics and Information Technology), for issuance of blocking orders
and simultaneously to the Internet Service Providers (“ISPs”) for blocking
the said websites.
VII. Upon receiving the said intimation from the plaintiff, the ISPs shall
take steps to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking orders
immediately upon the plaintiff, communicating the details of the websites,
which are illegally streaming the content, over which the plaintiff has rights.
IX.

After communication of details of the rogue websites to the concerned

authorities, the plaintiff shall continue to file affidavits with the Court, in
order to ensure that the Court is fully informed of the websites in respect of
which blocking orders are sought.
X.

If any website, which is not primarily an infringing site, is blocked

pursuant to the present order, they shall be permitted to approach this Court
by giving an undertaking that it does not intend to engage in any
unauthorized streaming of any content, over which the plaintiff has rights.
XI.

As and when new further websites are discovered by the plaintiff, the

plaintiff shall be at liberty to file an application for their impleadment, which
shall be taken up before the Joint Registrar (Judicial), and the order passed

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 11 of 27

<!-- page 55 -->

today shall be extended to the said newly impleaded website as well.
42.

Issue notice to the defendants by all permissible modes, upon filing of

process fee, returnable on the next date of hearing.
43.

Notice is accepted by learned counsel appearing for defendant no. 82.

44.

Let notice be issued to the other defendants.

45.

Let reply be filed within a period of four weeks.

46.

Rejoinder thereto, if any, be filed within two weeks, thereafter.

47.

Compliance of Order XXXIX Rule 3 CPC, be done, within a period

of one week from today.
48.

List before the Court on 7th March, 2025.

MINI PUSHKARNA, J
OCTOBER 24, 2024
ak

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 12 of 27

<!-- page 56 -->

Annexure-A

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 13 of 27

<!-- page 57 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 14 of 27

<!-- page 58 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 15 of 27

<!-- page 59 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 16 of 27

<!-- page 60 -->

Annexure-B

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 17 of 27

<!-- page 61 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 18 of 27

<!-- page 62 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 19 of 27

<!-- page 63 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 20 of 27

<!-- page 64 -->

Annexure-C

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 21 of 27

<!-- page 65 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 22 of 27

<!-- page 66 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 23 of 27

<!-- page 67 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 24 of 27

<!-- page 68 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 25 of 27

<!-- page 69 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 26 of 27

<!-- page 70 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 27 of 27

<!-- page 71 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
