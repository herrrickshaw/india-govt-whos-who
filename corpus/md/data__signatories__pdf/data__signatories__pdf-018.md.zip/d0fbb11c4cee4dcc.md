---
doc_id: "d0fbb11c4cee4dcc"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/abf0a6d26711692c519ba168da445c9d.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Note 4 (2019)"
date: "2025-07-02"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3bfcbc73b22c1b8d"
---

<!-- page 1 -->

Government
Government of
of India
India
Ministry
& Industry
Industry
Ministry of
of Commerce
Commerce &
Department
Department for
for Promotion
Promotion of
of Industry
Industry and
and Internal
Internal Trade
Trade
FDI
FDI Policy
Policy Section
Section
Press
(2019 Series)
Series)
Press Note
Note No.
No. 4
4 (2019
Subject:
Subject:

Review
Investment (FDI)
various sectors
Review of
of Foreign
Foreign Direct
Direct Investment
(FDI) policy
policy on
on various
sectors

The
Government of
The Government
of India
India has
has reviewed
reviewed the
the extant
extant FDI
FDI policy
policy on
on various
various sectors
sectors and
and
has
following amendments
has made
made following
amendments in
in the
the Consolidated
Consolidated FDI
FDI Policy
Policy Circular
Circular of
of 2017
2017 (FDI
(FDI
Policy),
effective from
August 28,
amended from
Policy), effective
from August
28, 2017,
2017, and
and as
as amended
from time
time to
to time.
time.
2.
2.

Coal
Coal Mining:
Mining:
amended to
Para
Para 5.2.3.2
5.2.3.2 of
of FDI
FDI Policy
Policy is
is amended
to be
be read
read as
as under:
under:
Sector/
Activity
Sector/Activity

%
% of
of Equity/
Equity/

Entry
Entry Route
Route

FDICap
FDI Cap
5.2.3.2
5.2.3.2
Coal
Coal &
Lignite
& Lignite

100%
100%

Automatic
Automatic

(1)
Lignite mining
mining for
for captive
captive
(1) Coal
Coal &
& Lignite
&
consumption
consumption by
by power
power projects,
projects, iron
iron &
steel
cement units
steel and
and cement
units and
and other
other eligible
eligible
activities
activities permitted
permitted under
under and
and subject
subject to
to
the
the provisions
provisions of
of Coal
Coal Mines
Mines (Special
(Special
Provisions)
Act, 2015
Provisions) Act,
2015 and
and the
the Mines
Mines and
and
Minerals
Minerals (Development
(Development and
and Regulation)
Regulation)
Act,
Act, 1957.
1957.
(2)
Setting up
(2) Setting
up coal
coal processing
processing plants
plants like
like
washeries
washeries subject
subject to
to the
the condition
condition that
that the
the
company
company shall
shall not
not do
do coal
coal mining
mining and
and
shall
shall not
not sell
sell washed
washed coal
coal or
or sized
sized coal
coal
from
from its
its coal
coal processing
processing plants
plants in
in the
the open
open
ll

<!-- page 2 -->

market
market and
and shall
shall supply
supply the
the washed
washed or
or
sized coal
coal to
those parties
who are
sized
to those
parties who
are
supplying
supplying raw
raw coal
coal to
to coal
coal processing
processing
plants
washing or
plants for
for washing
or sizing.
sizing.
(3) For
For sale
sale of
of coal,
coal, coal
coal mining
mining activities
activities
(3)

including
including

associated
associated

100%
100%

Automatic
Automatic

processing
processing

infrastructure subject
infrastructure
subject to
to the
the provisions
provisions of
of
Coal
Act, 2015
2015
Coal Mines
Mines (Special
(Special Provisions)
Provisions) Act,
and
and the
the Mines
Mines and
and Minerals
Minerals (Development
(Development
and
Act, 1957
and Regulation)
Regulation) Act,
1957 as
as amended
amended
from time
time to
to time
Acts
from
time and
and other
other relevant
relevant Acts
on
on the
the subject.
subject.

of Para
Following
Following new
new Clause
Clause 5.2.3.3.2
5.2.3.3.2 (iii)
(iii) is
is added
added under
under other
other conditions
conditions of
Para 5.2.3.3.2
5.2.3.3.2
Policy:
of
of FOi
FDI Policy:
"Associated Processing
Processing Infrastructure"
"Associated
Infrastructure" as
as contained
contained at
at Para
Para 5.2.3.2
5.2.3.2 above
above includes
includes
coal
washery, crushing,
crushing, coal
separation (magnetic
coal washery,
coal handling,
handling, and
and separation
(magnetic and
and non-magnetic)."
non-magnetic)."

3.
3.

Contract
Contract Manufacturing:
Manufacturing:
Para 5.2.5.1
5.2.5.1 of
of FOi
FDI Policy
Policy is
is amended
amended to
to be
be read
read as
as under:
under:
Para

foreign investment
"Subject
"Subject to
to the
the provisions
provisions of
of the
the FOi
FDI policy,
policy, foreign
investment in
in 'manufacturing'
'manufacturing'
sector
sector is
is under
under automatic
automatic route.
route. Manufacturing
Manufacturing activities
activities may
may be
be either
either self
self
manufacturing by
by the
the investee
investee entity
entity or
or contract
contract manufacturing
manufacturing in
in India
India through
through a
manufacturing
a

legally
Agent basis.
legally tenable
tenable contract,
contract, whether
whether on
on Principal
Principal to
to Principal
Principal or
or Principal
Principal to
to Agent
basis.
Further,
a manufacturer
manufacturer is
is permitted
permitted to
to sell
sell its
its products
products manufactured
manufactured in
in India
India
Further, a
through
through wholesale
wholesale and/
and/ or
or retail,
retail, including
including through
through e-commerce,
e-commerce, without
without Government
Government
approval
."
approval."

2
2

<!-- page 3 -->

4.
4.

Single
Single Brand
Brand Retail
Retail Trading
Trading

Para 5.2.15.3 of FOi
FDI Policy is amended to read
read as under:
Sector/
Activity
Sector/Activity

% of
of Equity/
Equity/

·Entry
Entry Route
Route

FOi Cap
Cap
FOi
Single
Single Brand
Brand Product
Product retail
retail trading
trading

100%

Automatic

(1) Foreign Investment in
in Single Brand Product retail
retail trading is aimed at
in production
production and marketing
marketing,, improving
improving the availability of
attracting investments in

such goods for the consumer, encouraging increased
increased sourcing
sourcing of goods from
India, and enhancing competitiveness
competitiveness of Indian
Indian enterprises through access to
global
and management practices.
global designs, technologies and
FDI in
in Single Brand Product retail
retail trading would be subject to the following
(2) FOi

conditions:
(a) Products to be sold
sold should
should be of a 'Single Brand
Brand'' only.
only.
(b) Products should
brand internationally i.e.
should be sold
sold under the same brand
products should
products
should be sold
sold under the same brand
brand in
in one or more countries
other than India.
product-retail trading would cover only products
products which
(c) 'Single Brand' product-retail

are branded
branded during manufacturing.
(d) A

non-resident entity or entities
entities,, whether owner of the brand
brand or

otherwise
otherwise,, shall be permitted
permitted to undertake 'single brand' product retail
retail
trading in
in the country for the specific brand
brand,, either directly by the brand
brand
owner or through a legally tenable agreement executed between the
Indian entity undertaking
undertaking single brand
retail trading and the brand
brand
Indian
brand retail
owner.
(e) In respect of proposals involving foreign investment beyond
%,
beyond 51
51%,
sourcing
sourcing of 30% of the value of goods procured
procured,, will be done from
India, preferably from MSMEs, village and cottage industries, artisans
and
and craftsmen
craftsmen,, in
in all sectors. The quantum of domestic sourcing
sourcing will be

3
3

<!-- page 4 -->

self-certified
self-certified by
by the
the company,
company, to
to be
be subsequently
subsequently checked,
checked, by
by statutory
statutory
auditors,
which the
will be
auditors, from
from the
the duly
duly certified
certified accounts
accounts which
the company
company will
be
required to
required
to maintain.
maintain. This
This procurement
procurement requirement
requirement would
would have
have to
to be
be
instance, as
met,
met, in
in the
the first
first instance,
as an
an average
average of
of five
five years'
years' total
total value
value of
of the
the
goods
beginning 1st
April of
goods procured,
procured, beginning
1st April
of the
the year
year of
of commencement
commencement of
of
SBRT
.e. opening
SBRT business
business (i(i.e.
opening of
of first
first store
store or
or start
start of
of online
online retail,
retail,
whichever
whichever is
is earlier).
earlier). Thereafter,
Thereafter, SBRT
SBRT entity
entity shall
shall be
be required
required to
to meet
meet
the 30%
30% local
local sourcing
sourcing norms
norms on
on an
an annual
annual basis
basis.. For
For the
the purpose
purpose of
of
the

ascertaining
the relevant
entity would
would be
ascertaining the
the sourcing
sourcing requirement,
requirement, the
relevant entity
be the
the
company,
in India,
India, which
which is
is the
the recipient
of foreign
foreign
company, incorporated
incorporated in
recipient of

investment
investment for
for the
the purpose
purpose of
of carrying
carrying out
out single-brand
single-brand product
product retail
retail
trading.
trading.
(f) For
For the
the purpose
purpose of
of meeting
meeting local
local sourcing
sourcing requirement
requirement laid
laid down
down at
at
(f)

para
para (e)
(e) above,
above, all
all procurements
procurements made
made from
from India
India by
by the
the SBRT
SBRT entity
entity
for
for that
that single
single brand
brand shall
shall be
be counted
counted towards
towards local
local sourcing,
sourcing,
in India
irrespective
irrespective of
of whether
whether the
the goods
goods procured
procured are
are sold
sold in
India or
or
exported
entity is
exported.. SBRT
SBRT entity
is also
also permitted
permitted to
to set
set off
off sourcing
sourcing of
of goods
goods
from
from India
India for
for global
global operations
operations against
against the
the mandatory
mandatory sourcing
sourcing
requirement
from India
requirement of
of 30%.
30%. For
For this
this purpose,
purpose, 'sourcing
'sourcing of
of goods
goods from
India for
for
global
from India
for
global operations'
operations' shall
shall mean
mean value
value of
of goods
goods sourced
sourced from
India for
terms) in
global operations
for that
that single
global
operations for
single brand
brand (in
(in INR
INR terms)
in a
a particular
particular
financial
financial year
year directly
directly by
by the
the entity
entity undertaking
undertaking SBRT
SBRT or
or its
its group
group
a
companies
companies (resident
(resident or
or non-resident),
non-resident), or
or indirectly
indirectly by
by them
them through
through a

third
legally tenable
tenable agreement.
agreement.
third party
party under
under aa legally
(g)
An SBRT
(g) An
SBRT entity
entity operating
operating through
through brick
brick and
and mortar
mortar stores
stores can
can also
also
undertake
retail trading
trading through
through e-commerce.
e-commerce. However,
However, retail
retail trading
trading
undertake retail

through e-commerce
can also
also be
through
e-commerce can
be undertaken
undertaken prior
prior to
to opening
opening of
of brick
brick
and mortar
mortar stores,
stores, subject
subject to
to the
the condition
condition that
that the
the entity
entity opens
opens brick
brick
and

and
years from
2 years
and mortar
mortar stores
stores within
within 2
from date
date of
of start
start of
of online
online retail.
retail.
Note:
Note:

(i)
Conditions mentioned
will not
(i) Conditions
mentioned at
at Para
Para 5.2.15.3
5.2.15.3 (2)
(2) (b)
(b) &
& 5.2.15.3
5.2.15.3 (2)
(2) (d)
(d) will
not be
be
applicable
applicable for
for undertaking
undertaking SBRT
SBRT of
of Indian
Indian brands.
brands.

4
4

<!-- page 5 -->

(ii)
Indian brands
brands should
should be
be owned
owned and
and controlled
controlled by
by resident
resident Indian
Indian citizens
citizens
(ii) Indian
and/or
and/or companies
companies which
which are
are owned
owned and
and controlled
controlled by
by resident
resident Indian
Indian citizens
citizens..
(iii)
(iii) Sourcing
Sourcing norms
norms will
will not
not be
be applicable
applicable up
up to
to three
three years
years from
from commencement
commencement
of
business i.e.
start of
of the
the business
i.e. opening
opening of
of first
first store
store or
or start
of online
online retail
retail,, whichever
whichever is
is
earlier
for entities
undertaking single
brand retail
retail trading
trading of
of products
having
earlier for
entities undertaking
single brand
products having
'state-of-art' and
and 'cutting-edge'
'cutting-edge' technology
technology and
and where
where local
local sourcing
sourcing is
is not
not
'state-of-art'

possible.
A
possible. Thereafter,
Thereafter, provisions
provisions of
of Para
Para 5.2.15.3
5.2.15.3 (2)
(2) (e)
(e) will
will be
be applicable.
applicable. A
Committee
with representatives
Committee under
under the
the Chairmanship
Chairmanship of
of Secretary,
Secretary, DPIIT,
DPIIT, with
representatives
from NITI
Aayog , concerned
Administrative Ministry
from
NITI Aayog,
concerned Administrative
Ministry and
and independent
independent technical
technical
expert(s)
subject will
expert(s) on
on the
the subject
will examine
examine the
the claim
claim of
of applicants
applicants on
on the
the issue
issue of
of the
the
products
products being
being in
in the
the nature
nature of
of 'state-of-art'
'state-of-art' and
and 'cutting-edge'
'cutting-edge' technology
technology where
where
for such
local
local sourcing
sourcing is
is not
not possible
possible and
and give
give recommendations
recommendations for
such relaxation
relaxation..

5.
5.

Digital
Digital Media
Media
Following
Following new
new clause
clause 5.2.7.2.3
5.2.7.2.3 is
is added
added under
under para
para 5.2.7.2
5.2.7.2 of
of the
the FOi
FDI policy:
policy:
5.2.7.2.3
5.2.7.2.3
News
Uploading/
of News
Streaming of
Uploading/ Streaming

&
&

Current
Affairs through
Current Affairs
through Digital
Digital Media
Media

26%
26%

Government
Government

.7.2.4
Existing
Existing Para
Para 5.2.7.2.3
5.2.7.2.3 shall
shall be
be renumbered
renumbered as
as 5.2
5.2.7.2.4

6.
6.

The
will take
The above
above decision
decision will
take effect
effect from
from the
the date
date of
of FEMA
FEMA notification.
notification.

Gr

~_b~
(Sumita
(Sumita Dawra)
Dawra)

Joint
Joint Secretary
Secretary to
to the
the Government
Government of
of India
India
DPIIT
DPIIT File
File No.
No.:: 5/3/2019-FDI
5/3/2019-FDI Policy,
Policy, dated
dated 18.09.2019
18.09.2019

5
5

<!-- page 6 -->

Copy
Copy forwarded
forwarded to:
to:

1.
wide publicity
1. Press
Press Information
Information Officer,
Officer, Press
Press Information
Information Bureau:.
Bureau- for
for giving
giving wide
publicity to
to the
the
above
above Press
Press Note.
Note.
2.
2. Joint
Joint

Secretary(l&C),
Secretary(l&C),

Department
Department

of
of

Economic
Economic For
For suitably
suitably incorporating
incorporating the
the

Affairs,
Affairs, North
North Block,
Block, New
New Delhi
Delhi
3.
3.

�

policy
policy changes
changes in
in Foreign
Foreign

Management
Exchange
Reserve
Management
Reserve Bank
Bank of
of India,
India, Foreign
Foreign Exchange
Exchange Department,
Department, Exchange
(Transfer
(Transfer or
or issue
issue of
of security
security
Mumbai
Mumbai

by
by a
person resident
resident outside
outside
a person
India)
India) Regulations,
Regulations, 2000
2000 and
and

the
the

relevant
relevant

schedules
schedules

thereof.
thereof.
for
4.
Industry and
4. NIC
NIC Section
Section in
in the
the Department
Department for
for Promotion
Promotion of
of Industry
and Internal
Internal Trade
Trade -- for

website.
uploading
uploading the
the Press
Press Note
Note on
on DPIIT's
DPIIT's website.
5.
5. Hindi
Hindi Section,
Section, DPIITDPIIT- for
for providing
providing Hindi
Hindi version
version..

6
