---
doc_id: "d1ef8ef46ae4e2d8"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/Notification_DAF.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "Gazette Notification for use of Aadhaar as identity document for availing the benefits under the Schemes being run by DAF"
date: ""
pages: 4
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "f021cf43eac9d805"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (ii)
PART II—Section 3—Sub-section (ii)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 1008]

ubZ fnYyh] 'kqØokj] vçSy 7] 2017@pS=k 17] 1939

No. 1008]

NEW DELHI, FRIDAY, APRIL 7, 2017/CHAITRA 17, 1939

सामािजक याय और अिधका रता मं ालय
(सामािजक याय और अिधका रता िवभाग)

अिधसूचना
नई द ली, 7 vçSy] 2017
का.आ.1134(अ).—जब क, सेवा

अथवा सुिवधा

अथवा सहाय कय को दान करने हेतु पहचान

द तावेज के प म आधार का उपयोग करने से सरकारी प रदान क
याएं सरल हो जाती ह, इसम पारद शता
आती है तथा कायकु शलता बढ़ती है, और लाभा थय को सुिवधाजनक प से तथा िबना कसी क ठनाई के अपनी
पा सुिवधा को सीधे ा करने म सुिवधा होती है तथा आधार से कसी ि क पहचान िस करने हेतु
ब िवध द तावेज को

तुत करने क भी आव यकता नह होती है;

तथा जब क, डॉ. अ बेडकर ित ान (िजसे इसके प ात ित ान कहा जाएगा) क थापना भारत सरकार ारा
सोसाइटी रिज ीकरण अिधिनयम, 1860 के तहत एक पंजीकृ त सोसाइटी के प म 24 माच, 1992 को पूववत क याण
मं ालय (अब सामािजक याय और अिधका रता मं ालय) के त वावधान म क गई थी। सामािजक याय और अिधका रता
मं ालय (िजसे इसके प ात इसे मं ालय कहा जाएगा), भारत सरकार ित ान क कापस िनिध के िलए अंशदान कर रहा है।
इसके अित र , ित ान अपने वयं के संसाधन और िनवेश से भी राज व सृिजत करता है।
तथा जब क, ित ान, िन िलिखत 6 योजना

(िज ह इसके प ात योजनाएं कहा जाएगा) के तहत ‘िच क सा सहायता

के िलए नकद सहायता, अ तरजातीय िववाह के िलए ो साहन, छा

को छा वृि

और अनुसूिचत जाित के अ याचार

पीिड़त को राहत (िजसे इसके बाद लाभाथ कहा जाएगा)’ दान करने हेतु िव ीय सहायता (िजसे इसके प ात लाभ कहा
जाएगा) के िलए योजनाएं संचािलत करता हैःक) डॉ. अ बेडकर िच क सा सहायता योजना।
ख) अ तरजातीय िववाह के मा यम से सामािजक एक करण के िलए डॉ. अ बेडकर योजना।
ग) डॉ. अ बेडकर ित ान रा ीय िनबंध ितयोिगता योजना।
घ) मा यिमक परी ा के िलए डॉ. अ बेडकर रा ीय मेधा पुर कार।
1989 GI/2017

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

ङ) व र मा यिमक परी ा हेतु डॉ. अंबेडकर रा ीय मेधा पुर कार।
च) अनुसूिचत जाित के अ याचार पीिड़त को डॉ. अ बेडकर रा ीय राहत।

तथा जब क, ित ान ारा कायाि वत क जा रही उपयु

योजना

म कया जाने वाला पूण अथवा आंिशक

य भारत क संिचत िनिध से कया जाता है;
अतः, अब, आधार (िव ीय और अ य सहाय कय , सुिवधा और सेवा का लि त प रदान) अिधिनयम,
2016 (2016 का 18) (िजसे इसके प ात उ अिधिनयम कहा जाएगा) क धारा 7 के उपबंध के अनुसरण म,
के ीय सरकार एतद ारा िन िलिखत को अिधसूिचत करती है, नामतः—
1.(1) योजना के तहत लाभ ा करने के इ छु क पा
ि से यह अपेि त है क वह अपने पास आधार माण
प होने का माण तुत कर अथवा आधार माणीकरण कराएं।
(2) योजना

के तहत लाभ ा करने के इ छु क ि , िजनके पास आधार नह है या िज ह ने अभी तक
आधार हेतु नामांकन नह कराया है पर तु वह योजना के अंतगत लाभ ा करने का इ छु क है, से
एतद ारा यह अपेि त है क वह 30 जून, 2017 तक आधार नामांकन हेतु आवेदन करे , बशत क वह
आधार अिधिनयम क धारा 3 के उपबंध के अनुसार आधार ा करने का पा हो और ऐसे ि आधार
के िलए नामांकन कराने हेतु कसी भी आधार नामांकन क (सूची भारतीय िविश पहचान ािधकरण
(यीआईएडीआई) वेबसाइट www.uidai.gov.in पर उपल ध है) म जा सकते ह।

(3) आधार (नामांकन तथा अ तन) िविनयम, 2016 के िविनयम 12 के अनुसार, यह अपेि त है क मं ालय

ित ान िजसे ि
ारा आधार दान करना अपेि त है, के मा यम से उन लाभा थय के िलए आधार
नामांकन सुिवधाएं उपल ध कराए िजनका अभी तक आधार के िलए नामांकन नह आ है तथा ऐसे
मामल म जहां संबंिधत लॉक या तालुका या तहसील म कोई आधार नामांकन क नह है, तो मं ालय
ित ान के मा यम से ऐसे सभी मामल म भारतीय िविश पहचान ािधकरण (यीआईडीएआई) के
मौजूदा पंजीयक के सम वय से सुिवधाजनक थान पर अथवा मं ालय वयं यूआईडीएआई पंजीयक
बनकर आधार नामांकन सुिवधा दान कराए।

बशत क उस समय तक जब लाभाथ को आधार स पा जाता है, तब तक योजना के तहत लाभ ऐसे लाभा थय
को िन िलिखत पहचान संबध
ं ी द तावेज को
(क)

तुत करने के अ यधीन दान कया जाएगा, नामतः—

(i) य द वह नामां कत है तो उसक आधार नामांकन आईडी पच ; या
(ii) पैरा 2 के उप-पैरा (ख) म यथा िविन द आधार नामांकन के िलए उसके

ारा कए गए अनुरोध क

एक ित।
(ख)

(i) फोटो सिहत बक पासबुक, या (ii) भारत के िनवाचन आयोग ारा जारी मतदाता पहचान काड;

अथवा (iii) राशन काड, या (iv) आयकर िवभाग ारा जारी थायी खाता सं या (पैन) काड; अथवा (v) मोटर
वाहन अिधिनयम, 1988 (1988 का 59) के तहत लाइसस ािधकारी ारा जारी कया गया ाइ वंग लाइसस; या
(vi) पासपोट; अथवा (vii) राजपि त अिधकारी

ारा शासक य लैटर हैड पर जारी ऐसे सद य क फोटो क

पहचान का माण-प ; या (viii) मं ालय ारा िविन द कोई अ य द तावेज;
बशत यह भी क, उ
अिधकारी ारा क जाएगी।

द तावेज क जांच, इस

योजनाथ मं ालय अथवा

ित ान

ारा नािमत

बशत यह भी क, जब ‘अनुसूिचत जाित के अ याचार पीिड़त को डॉ. अ बेडकर रा ीय राहत योजना’ के
तहत कसी लाभाथ को समयब

ढंग से अथवा आपातकालीन उपाय के

प म सहायता ा करने क ज रत

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

होती है तब उसे पैरा 1 के उप पैरा (3) म उि लिखत उपयु
पालन करने पर ऐसे लाभ लेने से मना नह कया जाए।

3

अपेि त समय जो तीस दन से अिधक नह है, का

2.
योजना के तहत योजना के लाभा थय को सुिवधाजनक प से और िबना कसी क ठनाई के लाभ उपल ध
कराने के िलए, मं ालय ित ान के मा यम से िन िलिखत व था सिहत सभी अपेि त व था करगेः(क) योजना के तहत आधार क अपे ा के बारे म लाभा थय को अवगत करने के िलए मीिडया और
ि गत नो टस के मा यम से ापक चार सार करना तथा य द उ ह ने पहले से नामांकन नह
कराया है तो 30 जून, 2017 तक अपने े के समीपवत आधार नामांकन के म अपना नामांकन कराने
क सलाह दी जाए। उ ह थानीय प से उपल ध नामांकन के
क सूची (www.uidai.gov.in पर सूची
उपल ध है) उपल ध करायी जाए।
(ख) य द योजना के लाभाथ अपने िनवास के समीप यथा खंड अथवा तालुक अथवा तहसील के भीतर
नामांकन क उपल ध न होने के कारण अपना नामांकन नह करा पाते ह, यह अपेि त है क ित ान
सुिवधाजनक थल पर आधार नामांकन सुिवधाएं उपल ध कराएं और लाभा थय से यह अनुरोध कया
जाए क वे ित ान अथवा मं ालय के संबंिधत का मक को या इस योजनाथ उपल ध वेबपोटल के
मा यम से पैरा 1 के उप-पैरा (3) के परं तुक म यथा िविन द अपना नाम, पता, मोबाइल नं. तथा अ य
यौरा देकर आधार नामांकन हेतु अपना अनुरोध पंजीकृ त कराएं।
3.
यह अिधसूचना असम, मेघालय और ज मू व क मीर रा य को छोड़कर सभी रा य और संघ रा य
के सरकारी राजप म इसके काशन क तारीख से भावी होगी।

े

[फा. सं. 11017/87/2016-एससीडी-1(खंड-2)]
आइ ी अनुराग, संयु

सिचव

MINISTRY OF SOCIAL JUSTICE AND EMPOWERMENT
(Department of Social Justice and Empowerment)
NOTIFICATION
New Delhi, the 7th April, 2017
S.O. 1134(E).––Whereas, the use of Aadhaar as identity document for delivery of services or benefits or
subsidies simplifies the Government delivery processes, brings in transparency, efficiency and enables beneficiaries to
get their entitlements directly to them in a convenient and seamless manner and Aadhaar obviates the need for producing
multiple documents to prove one’s identity.
And whereas, Dr. Ambedkar Foundation (hereinafter referred to as the Foundation) was established by the
Government of India under the aegis of the erstwhile Ministry of Welfare (now Ministry of Social Justice and
Empowerment) on 24th March, 1992 as a registered society under the Societies Registration Act, 1860. The Ministry of
Social Justice and Empowerment (hereinafter referred to as the Ministry), Government of India is contributing towards
corpus funds of the Foundation. Apart from the said contribution of funds by the Central Government the Foundation
generates revenue through its own resources and investments.
And whereas, the Foundation implements the following six Schemes (hereinafter referred to as the Schemes) for
providing financial assistance (hereinafter referred to as the benefit) for Medical Aid, incentives for inter-caste
Marriages, scholarships to students and relief to Scheduled Caste victims of atrocities (hereinafter referred to as the
beneficiaries), namely:a)
b)
c)
d)
e)
f)

Dr. Ambedkar Medical Aid Scheme;
Dr. Ambedkar Scheme for Social Integration through Inter-Caste Marriages;
Dr. Ambedkar Foundation National Essay Competition Scheme;
Dr. Ambedkar National Merit Awards for Secondary Examination;
Dr. Ambedkar National Merit Awards for Senior Secondary Examination; and
Dr. Ambedkar National Relief to Scheduled Caste Victims of Atrocities;

And whereas, the aforesaid Schemes being implemented by the Foundation involves expenditure incurred
partially or fully from the Consolidated Fund of India;

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

Now, therefore, in pursuance of the provisions of section 7 of the Aadhaar (Targeted Delivery of Financial and
other Subsidies, Benefits and Services) Act, 2016 (18 of 2016) (herein after referred to the said Act), the Central
Government hereby notifies the following, namely:–
1. (1) An eligible individual desirous of availing the benefits under the Schemes is required to furnish proof of
possession of Aadhaar number or undergo Aadhaar authentication.
(2) Any individual desirous of availing the benefit under the Schemes, who does not possess an Aadhaar number
or has not yet enrolled for Aadhaar, but desirous of availing the benefits under the Scheme is hereby required to apply for
Aadhaar enrolment by the 30th June 2017, provided he or she is entitled to obtain Aadhaar as per the provisions of section
3 of the said Act and such individuals may visit any Aadhaar enrolment centre (list available at Unique Identification
Authority of India (UIDAI) website www.uidai.gov.in) for Aadhaar enrolment.
(3) As per regulation 12 of the Aadhaar (Enrolment and Update) Regulations, 2016, the Ministry through
Foundation is required to offer Aadhaar enrolment facilities for the beneficiaries who are not yet enrolled for Aadhaar
and in case there is no Aadhaar enrolment centre located in the respective Block, Taluka or Tehsil, the Ministry through
the Foundation is required to provide Aadhaar enrolment facilities at convenient locations in coordination with the
existing Registrars of Unique Identification Authority of India (UIDAI) or the Ministry itself becoming UIDAI Registrar:
Provided that till the time Aadhaar is assigned to the individual, benefits under the Scheme shall be given to such
individual, subject to the production of the following identification documents, namely:–
(a) (i) if he or she has enrolled, his or her Aadhaar Enrolment ID slip; or
(ii) a copy of his or her request made for Aadhaar enrolment, as specified in sub- paragraph (b) of paragraph 2;
and
(b) (i) Bank passbook with photograph; or (ii) Voter identity card issued by the Election Commission of India; or
(iii) Ration Card, or (iv) Permanent Account Number (PAN) Card issued by the Income Tax Department; or (v)
Driving license issued by the Licensing Authority under the Motor Vehicles Act, 1988 (59 of 1988); or (vi)
Passport; or (vii) Certificate of identity having photo of such member issued by a Gazetted Officer on an official
letter head; or (viii) any other documents specified by the Ministry:
Provided further that the above documents shall be checked by an officer specifically designated by the Ministry
or Foundation for that purpose.
Provided further that when a beneficiary needs to avail assistance in a time bound manner or in an emergency
measures, under the Scheme of ‘Dr. Ambedkar National Relief to Scheduled Caste Victims of Atrocities’, he or she shall
not be denied such benefits subject to his or her subsequently complying to above requirement in sub-para (3) of para 1
not later than thirty days.
2.
In order to provide convenient and hassle free benefits to the beneficiaries under the Schemes the Ministry
through the Foundation shall make all the required arrangements including the following, namely:a)

wide publicity through media and individual notices to be given to the beneficiaries to make them aware of the
requirement of Aadhaar under the Schemes and they may be advised to get themselves enrolled at the nearest
Aadhaar enrolment centres available in their areas by 30th June, 2017, in case they are not already enrolled. The
list of locally available enrolment centres (list available at www.uidai.gov.in) shall be made available to them.
b) In case, the beneficiaries are not able to enrol for Aadhaar due to non-availability of enrolment centres in the
near vicinity such as in Block, Taluka or Tehsil, the Ministry through the Foundation is required to facilitate
Aadhaar enrolment facilities at convenient locations, and the beneficiaries may be requested to register their
request for Aadhaar enrolment by giving their names, addresses, mobile numbers with other details as specified
in the proviso to sub-paragraph (3) of paragraph 1, with the concerned official of the Foundation or the Ministry
or through a web portal provided for that purpose.
3.
This notification shall come into effect from the date of its publication in the Official Gazette in all the States
and Union territories except the States of Assam, Meghalaya and the State of Jammu and Kashmir.
[F. No. 11017/87/2016-SCD-I (Pt.II)]
AINDRI ANURAG, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

signed
ALOK Digitally
by ALOK KUMAR
2017.04.12
KUMAR Date:
12:26:10 +05'30'
