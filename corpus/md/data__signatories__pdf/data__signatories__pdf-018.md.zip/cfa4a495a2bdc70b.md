---
doc_id: "cfa4a495a2bdc70b"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/0809c1608ab0e9a1c3337e560a05abc9.pdf"
ministry: "Labour and Employment (MoLE)"
title: "DOP&TS INSTRUCTIONS (Instructions on filling up APARs)"
date: "2009-05-14"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b2659aae42d9b435"
---

<!-- page 1 -->

.~-•
EsttE/ACR matters

No. 210111112005-Estt (A) (Pt-ll)
Government of India
Ministry of Personnel, Public Grievances and Pensions
(Department of Personnel and Training)

North Block, New Delhi, 14th May, 2009
OFFICE MEMORANDUM

Subject:- Maintenance and preparation of Annual Performance Appraisal Reportscommunication of all entries for fairness and transparency in public
administration.
The undersigned is directed to invite the attention of the Ministries/Departments to the
existing provisions in regard to preparation and maintenance of Annual Confidential Reports
which inter-alia provide that only adverse remarks should be communicated to the officer
reported upon for representation, if any. The Supreme Court has held in their judgement dated
12.5.2008 in the case of Dev Dutt vs Union of India (Civil Appeal No.7631 of 2002) that the
object of writing the confidential report and makin~ entries is to give an opportunity to the
public servant to improve the performance. The 2n Administrative Reforms Commission in
their 1Oth Report has also recommended that the performance appraisal system for all services be
made more consultative and transparent on the lines of the PAR of the All India Services.
2. Keeping in view the above position, the matter regarding communication of entries in the
.ACRs in the case of civil services under the Government of India has been further reviewed and
the undersigned is directed to convey the following decisions of the Government:(i) The existing nomenclature of the Annual Confidential Report will be modified as

Annual Performance Assessment Report (AP AR).
(ii) The full AP AR including the overall grade and assessment of integrity shall be
communicated to the concerned officer after the Report is complete with the remarks of
the Reviewing Officer and the Accepting Authority wherever such system is in vogue.
Where Government servant has only one supervisory level above him as in the case of
personal staff attached to officers, such communication shall be made after the reporting
officer has completed the performance assessment.
(iii) The Section entrusted with the maintenance of AP ARs after its receipt shall disclose the
same to the officer reported upon.
(iv) The concerned officer shall be given the opportunity to make any representation against
the entries and the final grading given in the Report within a period of fifteen days from
the date of receipt of the entries in the AP AR. The representation shall be restricted to
the specific factual observations contained in the report leading to assessment of the
officer in terms of attributes, work output etc. 'While communicating the entries, it shall
be made clear that in case no representation is received within the fifteen days, it shall
be deemed that he/she has no representation to make. If the concerned AP AR Section
does not receive any information from the concerned officer on or before fifteen days
from the date of disclosure, the AP AR will be treated as fmal.

<!-- page 2 -->

EsttE/ACR matters

(v)

The new system of communicating the entries in the APAR shall be made applicable
prospectively only with effect from the reporting period 2008-09 which is to be initiated
after 1st April 2009.
· -

(vi) The competent authority for considering adverse remarks under the existing instructions
may consider the representation, if necessary, in consultation with the reporting and/or
reviewing officer and shall decide the matter objectively based on the material placed
before him within a period of thirty days from the date of receipt of the representation.
(vii) The competent authority after due consideration may reject the representation or may
accept and modify the AP AR accordingly. The decision of the competent authority and ·
the final grading shall be communicated to the officer reported upon within fifteen days
of receipt of the decision of the competent authority by the concerned APAR Section.
3.
All Ministries/Departments are requested to bring to the notice of all the offices under
them for strict implementation of the above instructions.

(C.A. Subramanian}
Director
To
All Ministries/Departments of Government of India
Copy to:1.
2.
3.
4.
5.
6.
7.
8.

Chief Secretaries of All State Govemments/U.T.s
The President's Secretariat, New Delhi.
The Prime Minister's Office, New Delhi.
The Cabinet Secretariat, New Delhi.
The Rajya Sabha Secretariat.
The Lok Sabha Secretariat.
The Comptroller and Auditor General of India, New Delhi.
The Union Public Service Commission, New Delhi.

Copy also to:(a)
(b)
(c)
(d)
(e)
(f)
~)

(h)

All Attached offices under the Ministry of Personnel, Public Grievances and Pensions.
Establishment Officer and Secretary, ACC (10 copies).
All officers and Sections in the Department of Personnel and Training.
Secretary, Staff Side, National Council (JCM), 13-C, Ferozeshah Road, New Delhi.
All Staff Members ofDepartmental Council (JCM).
All Staff members of the Departmental Council (JCM), Ministry of Personnel, Public
Grievances and Pensions.
NIC (DoP&T) for placing the Office Memorandum on the web-site of DoP&T.
Hindi Section for Hindi version of the O.M.
