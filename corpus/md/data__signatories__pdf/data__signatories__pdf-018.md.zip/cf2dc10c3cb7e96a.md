---
doc_id: "cf2dc10c3cb7e96a"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/1007_PT_Notice_11092026.pdf"
ministry: "Department of Space"
title: "URSC/GLOBAL TENDER NOTICE NO.E-11/26-27 Dated:10.09.2026      905.42 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "ba38204e89630cc1"
---

<!-- page 1 -->

भारत सरकार, अंतररक्ष तवभाग /GOVERNMENT OF INDIA, DEPARTMENT OF SPACE
यू . आर. राव उपग्रह केन्द्र (यू .आर.एस.सी) U R Rao Satellite Centre [URSC]
(पूवि में इसर उपग्रह केन्द / Formerly known as ISRO Satellite Centre)
एच.ए.एि. एयरप टि र ड, तवमानपुरा प स्ट
HAL Airport Road, Vimanapura Post,
बें गिूरु / BENGALURU
भारत / INDIA

यू.आर.एस.सी./सार्वजनिक निनर्दा सूचिा सं / URSC/GLOBAL TENDER NOTICE NO.E-11/26-27
10.09.2026
भारत के राष्ट्रपतत की ओर से व. प्रधान, क्रय एवं भं डार ई-, यू .आर. राव उपग्रह केन्द्र (यू .आर.एस.सी.), द्वारा तनम्नतिखित
मद ं की आपूतति के तिए केवि प्रापण के जररए तनतवदाएं आमंतित हैं :
On behalf of the President of India, Sr. Head, Purchase & Stores, U R Rao Satellite Centre [URSC] invites
tender ONLY through e-procurement for supply of the following.

दो भाग निनर्दा Two Part Tender
Sl. No.
01.

निनर्दा संदभव TENDER REFERENCE

संनिप्त नर्र्रण BRIEF DESCRIPTION

URSC/PR/IS2026-00-1007-01

मल्टीले यर नचप कैपेनसटर: 2 प्रकार
MULTILAYER CHIP CAPACITORS 2 TYPES

बोली प्रस्तुत करिे हे तु प्रारं नभक नतनि Bid Submission Start Date
बोली स्पष्टीकरण Bid Clarification Date up to
बोली प्रस्तुत करिे की नियत नतनि Bid Submission Due Date
बोली खोलिे की नतनि Bid Opening Date

:
:
:
:

10.09.2026 (17.00 Hrs.)
18.09.2026 (14.00 Hrs.)
08.10.2026 (14.00 Hrs.)
08.10.2026 (14.30 Hrs.)

वै ध तडतजटि हस्ताक्षर प्रमाणपि (डी. एस.सी) प्राप्त इच्छु क तनतवदाकार https://eproc.isro.gov.in पर िॉग इन करके
अपना प्रस्ताव ऑनिाईन भे ज सकते हैं । क ई तनतवदा शुल्क िागू नही ं है ।
Interested Tenderers having valid Digital Signature Certificate [DSC] may login to
https://eproc.isro.gov.in and submit Offers online. No Tender fees applicable.
तनतवदाओं क उपर क्त तनतदि ष्ट् तदनां क पर ि िा जाएगा। अहि तवक्रेताओं के दर ब िी क ि िने की समयसू ची क बाद में
सू तचत तकया जाएगा। ब िी िगाने से सं बंतधत तववरण क इसर ई-प्रापण प टि ि में िातगन करके दे िा जा सकता है ।
Tenders will be opened on the date specified above. Schedule for opening of the Price Bid (in case of
Two-Part Tenders) of Qualified Vendors will be intimated later. Bidding details can be seen by the
participated vendors by logging into ISRO e-procurement portal.
उपर क्त के सं बंध में शुखददपि/अनुशेष, यतद क ई ह , त उसे हमारे ई-प टि ि एवं वे बसाइट पर प्रकातशत तकया जाएगा।
Corrigendum/Addendum, if any, related to above shall be hosted in our e- portal and Website.

Sd/र्. प्रधाि, क्रय र् भंडार / Sr. Head, Purchase & Stores
