---
doc_id: "cdea76fe4991cfdb"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/c9f85eeee4012285d26bc745bb2ddfaf.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Additional Charge to CLS Officers (Office Order- 12/2024)"
date: "2025-05-24"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "955e69f7d8bb4aeb"
---

<!-- page 1 -->

F.No. A-22012/02/2024-CLS.I |
Government of India |
Ministry of Labour & Employment i
है के के के ने के -
. है Shram Shakti Bhawan,
Rafi Marg, New Delhi-110001
Date 24% May, 2024
Officer Order No.12/2024
With the approval of Competent Authority, the additional charge of the vacant posts in
various grades of Central Labour Service (CLS) is entrusted upon the following officers in
addition to their existing duties with immediate effect till the post is filled up on regular basis
or until further orders, whichever is earlier:
: lL JAG
‘Additional Charge entrusted upon to (
No.
(Dy. CLC(C), Nagpur __| Shri Sanjay Dabi, Dy, CLC(C), Mumbai
Dy. CLC(C), Aimer Shri M. A. Khan, Dy. CLC(), Ahmedabad
Dy. CLC(C), Jabalpur Shri Ashok Kumar Mohanta, Dy.CLC(C), Raipur
Dy. CLC(C), Dhanbad__| Shri V.K, Trivedi, Dy. CLC(C), Asansol
Dy. CLC(C), Patna Shri B B Prusty, WC(C), Patna
(6._|Dy.CLC(C), Kanpur__| Shri Hemang Dimngel, Dy. CLC(C), Chandigarh .
। TLWC(C), AtmyHQ__| Shri Tej Bahadur, Dy. CLC (C), HQ New Delhi .
Il, STs
Vacant Posts Additional Charge entrusted upon to :
No.
DLWC(C), CPWD, | Shri $.K. Sahoo, RLC(C), Hyderabad
Hyderabad
DLWC(Q), DLRL, | Shri Bijan Chand Kashyap, DLWC(C), DRDL,
5 DRDO, Hyderabad DRDO, Hyderabad
DWC(C), Karma/Ranchi_| Shri Nayan Manik Tripura, RLC(C), Ranchi
mm. JTS
Additional Charge entrusted upon to
No.
ALC(O), Asansol Shri Sarvesh Kumar, ALC(C), Chaibasa :
Shri Sanjay Kumar, ALC(C), Kolkata
[ALC(C), Hubli _ | Shri R. Prakash, ALC(C), Mangalore
[ALC(C), Nagpur Shri Rabul, ALC(C), Raipur '
ALC(C), Chandrapur Shri Raghavendra Nayakam, ALC(C), Hyderabad,
ALC(C), Kolkata Shri Sanjay Kumar, ALC(C), Kolkata
7. | ALC(C), Siliguri Shri Parineeta, ALC(C), Guwahati
[8. [| ALC(C), Ahmedabad Shri Pramod Kumar Meena, ALC(C), Ajmer

<!-- page 2 -->

[9.__|
Dhanbad
|
[AWC(C),Tirunveli |
.
DRDO, Kochi, Kerala Kerala
Ms. Shradha Srivastava, ALWC(C), SQAE(GS),
Kakinara, 24 North | Hastings, Kolkata
Parganas
2. The aforesaid officers shall not be entitled for any additional remuneration in this
regard. है aa
(Dhananjay Sharma)
हि Under Secretary to the Government of India .
To,
1. The officers concerned
2, PS to Hon’ble Minister for L&E/ PS to Hon’ble MoS(L&Ey PPS to Secretary (L&E)/
Sr. PPS to AS (CLS) PA to JD(BN)
3. CLC(C), Ministry of Labour & Employment, Dwarka, New Delhi
4. DG(LW), Ministry of Labour and Employment
5. LWC(C), DRDO, New Delhi .
6. LWC(C), Ministry of Defence(Army), New Delhi
7. Director General of Works, CPWD, Nirman Bhavan, New Delhi. :
8. -CLS(Vig.) Section, Ministry of Labour & Employment
9. Personal File of the officers concerned/ Office Order bundle/ Spare Copy
