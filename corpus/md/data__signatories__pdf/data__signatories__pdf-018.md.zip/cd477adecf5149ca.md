---
doc_id: "cd477adecf5149ca"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/3fd65a38c02bad56e19c4b0731550efc.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Provisional Result and Frequency Assignment- Spectrum Auction 2023-24"
date: "2024-06-26"
pages: 21
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "574d04c3e490ee8b"
---

<!-- page 1 -->

800, 900, 1800, 2100, 2300, 2500, 3300 MHz & 26 GHz Band Public Report
Auction Result 2024
The Auction results are provisional and subject to approval by the Government.
The following table provides the summary of auction results:
Service Area

Band

Winning Price per Block (In Crore
in INR)
No participation

800
Service Area
Andhra Pradesh

Assam

Band

900(MHz)

900(MHz)

Winning Price
per Block (In
Crore in INR)

Frequency Allocation of Service
Area

Frequency Allocation of Service Area

57.6000 Company Name Frequency
Vodafone Idea
Uplink Start
Limited
908.3
908.1
907.9
907.7
907.5
907.3
907.1
906.9
906.7
906.5
906.3
906.1
12.6000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
896.1
895.9
895.7

Uplink Stop
908.5
908.3
908.1
907.9
907.7
907.5
907.3
907.1
906.9
906.7
906.5
906.3

Downlink Start
953.3
953.1
952.9
952.7
952.5
952.3
952.1
951.9
951.7
951.5
951.3
951.1

Downlink Stop
953.5
953.3
953.1
952.9
952.7
952.5
952.3
952.1
951.9
951.7
951.5
951.3

Uplink Stop
896.3
896.1
895.9

Downlink Start
941.1
940.9
940.7

Downlink Stop
941.3
941.1
940.9

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 2 -->

Bihar

900(MHz)

895.5
895.3
895.1
894.9
894.7
894.5
894.3
894.1
893.9
893.7
893.5
893.3
893.1
892.9
892.7
892.5
892.3
892.1
891.9
891.7
891.5
891.3
29.4000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
901.7
901.5
901.3
901.1
900.9
900.7
900.5
900.3

895.7
895.5
895.3
895.1
894.9
894.7
894.5
894.3
894.1
893.9
893.7
893.5
893.3
893.1
892.9
892.7
892.5
892.3
892.1
891.9
891.7
891.5

940.5
940.3
940.1
939.9
939.7
939.5
939.3
939.1
938.9
938.7
938.5
938.3
938.1
937.9
937.7
937.5
937.3
937.1
936.9
936.7
936.5
936.3

940.7
940.5
940.3
940.1
939.9
939.7
939.5
939.3
939.1
938.9
938.7
938.5
938.3
938.1
937.9
937.7
937.5
937.3
937.1
936.9
936.7
936.5

Uplink Stop
901.9
901.7
901.5
901.3
901.1
900.9
900.7
900.5

Downlink Start
946.7
946.5
946.3
946.1
945.9
945.7
945.5
945.3

Downlink Stop
946.9
946.7
946.5
946.3
946.1
945.9
945.7
945.5

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 3 -->

Jammu &
Kashmir

900(MHz)

900.1
899.9
899.7
899.5
899.3
899.1
898.9
898.7
898.5
898.3
898.1
897.9
897.7
897.5
897.3
897.1
896.9
896.7
896.5
896.3
896.1
895.9
895.7
895.5
895.3
895.1
894.9
3.6000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
900.5
900.3
900.1

900.3
900.1
899.9
899.7
899.5
899.3
899.1
898.9
898.7
898.5
898.3
898.1
897.9
897.7
897.5
897.3
897.1
896.9
896.7
896.5
896.3
896.1
895.9
895.7
895.5
895.3
895.1

945.1
944.9
944.7
944.5
944.3
944.1
943.9
943.7
943.5
943.3
943.1
942.9
942.7
942.5
942.3
942.1
941.9
941.7
941.5
941.3
941.1
940.9
940.7
940.5
940.3
940.1
939.9

945.3
945.1
944.9
944.7
944.5
944.3
944.1
943.9
943.7
943.5
943.3
943.1
942.9
942.7
942.5
942.3
942.1
941.9
941.7
941.5
941.3
941.1
940.9
940.7
940.5
940.3
940.1

Uplink Stop
900.7
900.5
900.3

Downlink Start
945.5
945.3
945.1

Downlink Stop
945.7
945.5
945.3

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 4 -->

899.9
899.7
899.5
899.3
899.1
898.9
898.7
898.5
898.3
898.1
897.9
897.7
897.5
897.3
897.1
896.9
896.7
896.5
896.3
896.1
895.9
895.7
895.5
895.3
895.1
894.9
894.7
894.5
894.3
894.1
893.9
893.7

900.1
899.9
899.7
899.5
899.3
899.1
898.9
898.7
898.5
898.3
898.1
897.9
897.7
897.5
897.3
897.1
896.9
896.7
896.5
896.3
896.1
895.9
895.7
895.5
895.3
895.1
894.9
894.7
894.5
894.3
894.1
893.9

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

944.9
944.7
944.5
944.3
944.1
943.9
943.7
943.5
943.3
943.1
942.9
942.7
942.5
942.3
942.1
941.9
941.7
941.5
941.3
941.1
940.9
940.7
940.5
940.3
940.1
939.9
939.7
939.5
939.3
939.1
938.9
938.7

945.1
944.9
944.7
944.5
944.3
944.1
943.9
943.7
943.5
943.3
943.1
942.9
942.7
942.5
942.3
942.1
941.9
941.7
941.5
941.3
941.1
940.9
940.7
940.5
940.3
940.1
939.9
939.7
939.5
939.3
939.1
938.9

<!-- page 5 -->

Karnataka

Kolkata

900(MHz)

900(MHz)

893.5
893.3
893.1
892.9
892.7
892.5
892.3
892.1
891.9
891.7
891.5
891.3
891.1
890.9
890.7
40.8000 Company Name Frequency
Vodafone Idea
Uplink Start
Limited
908.3
908.1
907.9
907.7
907.5
907.3
907.1
906.9
906.7
906.5
906.3
30.6000 Company Name Frequency
Vodafone Idea
Uplink Start
Limited
906.7

893.7
893.5
893.3
893.1
892.9
892.7
892.5
892.3
892.1
891.9
891.7
891.5
891.3
891.1
890.9

938.5
938.3
938.1
937.9
937.7
937.5
937.3
937.1
936.9
936.7
936.5
936.3
936.1
935.9
935.7

938.7
938.5
938.3
938.1
937.9
937.7
937.5
937.3
937.1
936.9
936.7
936.5
936.3
936.1
935.9

Uplink Stop
908.5
908.3
908.1
907.9
907.7
907.5
907.3
907.1
906.9
906.7
906.5

Downlink Start
953.3
953.1
952.9
952.7
952.5
952.3
952.1
951.9
951.7
951.5
951.3

Downlink Stop
953.5
953.3
953.1
952.9
952.7
952.5
952.3
952.1
951.9
951.7
951.5

Uplink Stop
906.9

Downlink Start
951.7

Downlink Stop
951.9

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 6 -->

North East

Odisha

900(MHz)

900(MHz)

3.2000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
894.3
894.1
893.9
893.7
893.5
12.8000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
896.1
895.9
895.7
895.5
895.3
895.1
894.9
894.7
894.5
894.3
894.1
893.9
893.7
893.5
893.3
893.1
892.9
892.7
892.5
892.3
892.1
891.9
891.7

Uplink Stop
894.5
894.3
894.1
893.9
893.7

Downlink Start
939.3
939.1
938.9
938.7
938.5

Downlink Stop
939.5
939.3
939.1
938.9
938.7

Uplink Stop
896.3
896.1
895.9
895.7
895.5
895.3
895.1
894.9
894.7
894.5
894.3
894.1
893.9
893.7
893.5
893.3
893.1
892.9
892.7
892.5
892.3
892.1
891.9

Downlink Start
941.1
940.9
940.7
940.5
940.3
940.1
939.9
939.7
939.5
939.3
939.1
938.9
938.7
938.5
938.3
938.1
937.9
937.7
937.5
937.3
937.1
936.9
936.7

Downlink Stop
941.3
941.1
940.9
940.7
940.5
940.3
940.1
939.9
939.7
939.5
939.3
939.1
938.9
938.7
938.5
938.3
938.1
937.9
937.7
937.5
937.3
937.1
936.9

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 7 -->

Punjab

Rajasthan

900(MHz)

900(MHz)

891.5
891.3
20.8000 Company Name Frequency
Vodafone Idea
Uplink Start
Limited
906.7
906.5
906.3
906.1
905.9
905.7
27.0000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
906.7
906.5
906.3
906.1
905.9
905.7
905.5
905.3
905.1
904.9
904.7
904.5
904.3
904.1
903.9
903.7
903.5
903.3
903.1
902.9

891.7
891.5

936.5
936.3

936.7
936.5

Uplink Stop
906.9
906.7
906.5
906.3
906.1
905.9

Downlink Start
951.7
951.5
951.3
951.1
950.9
950.7

Downlink Stop
951.9
951.7
951.5
951.3
951.1
950.9

Uplink Stop
906.9
906.7
906.5
906.3
906.1
905.9
905.7
905.5
905.3
905.1
904.9
904.7
904.5
904.3
904.1
903.9
903.7
903.5
903.3
903.1

Downlink Start
951.7
951.5
951.3
951.1
950.9
950.7
950.5
950.3
950.1
949.9
949.7
949.5
949.3
949.1
948.9
948.7
948.5
948.3
948.1
947.9

Downlink Stop
951.9
951.7
951.5
951.3
951.1
950.9
950.7
950.5
950.3
950.1
949.9
949.7
949.5
949.3
949.1
948.9
948.7
948.5
948.3
948.1

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 8 -->

Vodafone Idea
Limited

Tamil Nadu

Uttar Pradesh
(East)

900(MHz)

900(MHz)

Uplink Start
902.7
902.5
44.4000 Company Name Frequency
Vodafone Idea
Uplink Start
Limited
896.9
896.7
896.5
896.3
896.1
895.9
895.7
895.5
895.3
895.1
894.9
894.7
37.2000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
896.1
895.9
895.7
895.5
895.3
895.1
894.9
894.7
894.5
894.3
894.1
893.9
893.7

Uplink Stop
902.9
902.7

Downlink Start
947.7
947.5

Downlink Stop
947.9
947.7

Uplink Stop
897.1
896.9
896.7
896.5
896.3
896.1
895.9
895.7
895.5
895.3
895.1
894.9

Downlink Start
941.9
941.7
941.5
941.3
941.1
940.9
940.7
940.5
940.3
940.1
939.9
939.7

Downlink Stop
942.1
941.9
941.7
941.5
941.3
941.1
940.9
940.7
940.5
940.3
940.1
939.9

Uplink Stop
896.3
896.1
895.9
895.7
895.5
895.3
895.1
894.9
894.7
894.5
894.3
894.1
893.9

Downlink Start
941.1
940.9
940.7
940.5
940.3
940.1
939.9
939.7
939.5
939.3
939.1
938.9
938.7

Downlink Stop
941.3
941.1
940.9
940.7
940.5
940.3
940.1
939.9
939.7
939.5
939.3
939.1
938.9

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 9 -->

Uttar Pradesh
(West)

900(MHz)

893.5
893.3
893.1
892.9
892.7
892.5
892.3
892.1
891.9
891.7
891.5
891.3
Vodafone Idea
Uplink Start
Limited
891.1
890.9
890.7
890.5
890.3
890.1
30.4000 Company Name Frequency
Vodafone Idea
Uplink Start
Limited
906.7
906.5
906.3
906.1
905.9
905.7
905.5
905.3
905.1
904.9
904.7

893.7
893.5
893.3
893.1
892.9
892.7
892.5
892.3
892.1
891.9
891.7
891.5
Uplink Stop
891.3
891.1
890.9
890.7
890.5
890.3

938.5
938.3
938.1
937.9
937.7
937.5
937.3
937.1
936.9
936.7
936.5
936.3
Downlink Start
936.1
935.9
935.7
935.5
935.3
935.1

938.7
938.5
938.3
938.1
937.9
937.7
937.5
937.3
937.1
936.9
936.7
936.5
Downlink Stop
936.3
936.1
935.9
935.7
935.5
935.3

Uplink Stop
906.9
906.7
906.5
906.3
906.1
905.9
905.7
905.5
905.3
905.1
904.9

Downlink Start
951.7
951.5
951.3
951.1
950.9
950.7
950.5
950.3
950.1
949.9
949.7

Downlink Stop
951.9
951.7
951.5
951.3
951.1
950.9
950.7
950.5
950.3
950.1
949.9

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 10 -->

West Bengal

900(MHz)

904.5
904.3
904.1
903.9
903.7
903.5
903.3
903.1
902.9
902.7
902.5
902.3
902.1
901.9
19.8000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
897.9
897.7
897.5
897.3
897.1
896.9
896.7
896.5
896.3
896.1
895.9
895.7
895.5
895.3
895.1
894.9

904.7
904.5
904.3
904.1
903.9
903.7
903.5
903.3
903.1
902.9
902.7
902.5
902.3
902.1

949.5
949.3
949.1
948.9
948.7
948.5
948.3
948.1
947.9
947.7
947.5
947.3
947.1
946.9

949.7
949.5
949.3
949.1
948.9
948.7
948.5
948.3
948.1
947.9
947.7
947.5
947.3
947.1

Uplink Stop
898.1
897.9
897.7
897.5
897.3
897.1
896.9
896.7
896.5
896.3
896.1
895.9
895.7
895.5
895.3
895.1

Downlink Start
942.9
942.7
942.5
942.3
942.1
941.9
941.7
941.5
941.3
941.1
940.9
940.7
940.5
940.3
940.1
939.9

Downlink Stop
943.1
942.9
942.7
942.5
942.3
942.1
941.9
941.7
941.5
941.3
941.1
940.9
940.7
940.5
940.3
940.1

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 11 -->

Vodafone Idea
Limited

894.7
894.5
894.3
894.1
893.9
893.7
893.5
893.3
893.1
Uplink Start
906.7
906.5
906.3
906.1
892.9
892.7
892.5
892.3
892.1
891.9
891.7
891.5
891.3
891.1
890.9
890.7
890.5
890.3
890.1

894.9
894.7
894.5
894.3
894.1
893.9
893.7
893.5
893.3
Uplink Stop
906.9
906.7
906.5
906.3
893.1
892.9
892.7
892.5
892.3
892.1
891.9
891.7
891.5
891.3
891.1
890.9
890.7
890.5
890.3

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

939.7
939.5
939.3
939.1
938.9
938.7
938.5
938.3
938.1
Downlink Start
951.7
951.5
951.3
951.1
937.9
937.7
937.5
937.3
937.1
936.9
936.7
936.5
936.3
936.1
935.9
935.7
935.5
935.3
935.1

939.9
939.7
939.5
939.3
939.1
938.9
938.7
938.5
938.3
Downlink Stop
951.9
951.7
951.5
951.3
938.1
937.9
937.7
937.5
937.3
937.1
936.9
936.7
936.5
936.3
936.1
935.9
935.7
935.5
935.3

<!-- page 12 -->

Service Area
Assam

Bihar

Band

1800(MHz)

1800(MHz)

Winning Price
per Block (In
Crore in INR)

Frequency Allocation of Service Area

6.4000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1756.3
1756.5
1756.7
1756.9
1757.1
1757.3
1757.5
1757.7
1757.9
1758.1
1758.3
1758.5
1758.7
1758.9
1759.1
1759.3
1759.5
1759.7
1759.9
1760.1
16.8100 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1756.3
1756.5
1756.7
1756.9
1757.1

Uplink Stop
1756.5
1756.7
1756.9
1757.1
1757.3
1757.5
1757.7
1757.9
1758.1
1758.3
1758.5
1758.7
1758.9
1759.1
1759.3
1759.5
1759.7
1759.9
1760.1
1760.3

Downlink Start
1851.3
1851.5
1851.7
1851.9
1852.1
1852.3
1852.5
1852.7
1852.9
1853.1
1853.3
1853.5
1853.7
1853.9
1854.1
1854.3
1854.5
1854.7
1854.9
1855.1

Downlink Stop
1851.5
1851.7
1851.9
1852.1
1852.3
1852.5
1852.7
1852.9
1853.1
1853.3
1853.5
1853.7
1853.9
1854.1
1854.3
1854.5
1854.7
1854.9
1855.1
1855.3

Uplink Stop
1756.5
1756.7
1756.9
1757.1
1757.3

Downlink Start
1851.3
1851.5
1851.7
1851.9
1852.1

Downlink Stop
1851.5
1851.7
1851.9
1852.1
1852.3

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 13 -->

Reliance Jio
Infocomm
Limited

1757.3
1757.5
1757.7
1757.9
1758.1
1758.3
1758.5
1758.7
1758.9
1759.1
1759.3
1759.5
1759.7
1759.9
1760.1
1760.3
1760.5
1760.7
1760.9
1761.1
1761.3
Uplink Start
1761.5
1761.7
1761.9
1762.1
1762.3
1762.5
1762.7
1762.9
1763.1
1763.3

1757.5
1757.7
1757.9
1758.1
1758.3
1758.5
1758.7
1758.9
1759.1
1759.3
1759.5
1759.7
1759.9
1760.1
1760.3
1760.5
1760.7
1760.9
1761.1
1761.3
1761.5
Uplink Stop
1761.7
1761.9
1762.1
1762.3
1762.5
1762.7
1762.9
1763.1
1763.3
1763.5

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

1852.3
1852.5
1852.7
1852.9
1853.1
1853.3
1853.5
1853.7
1853.9
1854.1
1854.3
1854.5
1854.7
1854.9
1855.1
1855.3
1855.5
1855.7
1855.9
1856.1
1856.3
Downlink Start
1856.5
1856.7
1856.9
1857.1
1857.3
1857.5
1857.7
1857.9
1858.1
1858.3

1852.5
1852.7
1852.9
1853.1
1853.3
1853.5
1853.7
1853.9
1854.1
1854.3
1854.5
1854.7
1854.9
1855.1
1855.3
1855.5
1855.7
1855.9
1856.1
1856.3
1856.5
Downlink Stop
1856.7
1856.9
1857.1
1857.3
1857.5
1857.7
1857.9
1858.1
1858.3
1858.5

<!-- page 14 -->

Haryana

1800(MHz)

1763.5
1763.7
1763.9
1764.1
1764.3
1764.5
1764.7
1752.7
1752.9
1753.1
1753.3
1753.5
1750.5
1750.7
1748.5
8.2000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1746.5
1746.7
1746.9
1747.1
1747.3
1747.5
1747.7
1747.9
1748.1
1748.3
1748.5
1748.7
1748.9
1749.1
1749.3

1763.7
1763.9
1764.1
1764.3
1764.5
1764.7
1764.9
1752.9
1753.1
1753.3
1753.5
1753.7
1750.7
1750.9
1748.7

1858.5
1858.7
1858.9
1859.1
1859.3
1859.5
1859.7
1847.7
1847.9
1848.1
1848.3
1848.5
1845.5
1845.7
1843.5

1858.7
1858.9
1859.1
1859.3
1859.5
1859.7
1859.9
1847.9
1848.1
1848.3
1848.5
1848.7
1845.7
1845.9
1843.7

Uplink Stop
1746.7
1746.9
1747.1
1747.3
1747.5
1747.7
1747.9
1748.1
1748.3
1748.5
1748.7
1748.9
1749.1
1749.3
1749.5

Downlink Start
1841.5
1841.7
1841.9
1842.1
1842.3
1842.5
1842.7
1842.9
1843.1
1843.3
1843.5
1843.7
1843.9
1844.1
1844.3

Downlink Stop
1841.7
1841.9
1842.1
1842.3
1842.5
1842.7
1842.9
1843.1
1843.3
1843.5
1843.7
1843.9
1844.1
1844.3
1844.5

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 15 -->

Kolkata

1800(MHz)

1749.5
1749.7
1749.9
1750.1
1750.3
1750.5
1750.7
1750.9
1751.1
1751.3
21.8000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1753.3
1753.5
1753.7
1753.9
1754.1
1754.3
1754.5
1754.7
1754.9
1755.1
1755.3
1755.5
1755.7
1755.9
1756.1
1756.3
1756.5
1756.7
1756.9
1757.1

1749.7
1749.9
1750.1
1750.3
1750.5
1750.7
1750.9
1751.1
1751.3
1751.5

1844.5
1844.7
1844.9
1845.1
1845.3
1845.5
1845.7
1845.9
1846.1
1846.3

1844.7
1844.9
1845.1
1845.3
1845.5
1845.7
1845.9
1846.1
1846.3
1846.5

Uplink Stop
1753.5
1753.7
1753.9
1754.1
1754.3
1754.5
1754.7
1754.9
1755.1
1755.3
1755.5
1755.7
1755.9
1756.1
1756.3
1756.5
1756.7
1756.9
1757.1
1757.3

Downlink Start
1848.3
1848.5
1848.7
1848.9
1849.1
1849.3
1849.5
1849.7
1849.9
1850.1
1850.3
1850.5
1850.7
1850.9
1851.1
1851.3
1851.5
1851.7
1851.9
1852.1

Downlink Stop
1848.5
1848.7
1848.9
1849.1
1849.3
1849.5
1849.7
1849.9
1850.1
1850.3
1850.5
1850.7
1850.9
1851.1
1851.3
1851.5
1851.7
1851.9
1852.1
1852.3

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 16 -->

Madhya Pradesh

Odisha

Punjab

1800(MHz)

1800(MHz)

1800(MHz)

1757.3
1757.5
1757.7
1757.9
1758.1
19.8000 Company Name Frequency
Vodafone Idea
Uplink Start
Limited
1763.7
1763.9
1764.1
1764.3
1764.5
1764.7
7.8000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1771.7
1771.9
1772.1
1772.3
1772.5
12.2000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1750.7
1750.9
1751.1
1751.3
1751.5
1751.7
1751.9
1752.1
1752.3
1752.5

1757.5
1757.7
1757.9
1758.1
1758.3

1852.3
1852.5
1852.7
1852.9
1853.1

1852.5
1852.7
1852.9
1853.1
1853.3

Uplink Stop
1763.9
1764.1
1764.3
1764.5
1764.7
1764.9

Downlink Start
1858.7
1858.9
1859.1
1859.3
1859.5
1859.7

Downlink Stop
1858.9
1859.1
1859.3
1859.5
1859.7
1859.9

Uplink Stop
1771.9
1772.1
1772.3
1772.5
1772.7

Downlink Start
1866.7
1866.9
1867.1
1867.3
1867.5

Downlink Stop
1866.9
1867.1
1867.3
1867.5
1867.7

Uplink Stop
1750.9
1751.1
1751.3
1751.5
1751.7
1751.9
1752.1
1752.3
1752.5
1752.7

Downlink Start
1845.7
1845.9
1846.1
1846.3
1846.5
1846.7
1846.9
1847.1
1847.3
1847.5

Downlink Stop
1845.9
1846.1
1846.3
1846.5
1846.7
1846.9
1847.1
1847.3
1847.5
1847.7

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 17 -->

Rajasthan

1800(MHz)

1752.7
1752.9
1753.1
1753.3
1753.5
1753.7
1753.9
1754.1
1754.3
1754.5
1754.7
1754.9
1755.1
1755.3
1755.5
16.8000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1751.7
1751.9
1752.1
1752.3
1752.5
1752.7
1752.9
1753.1
1753.3
1753.5
1753.7
1753.9
1754.1
1754.3
1754.5

1752.9
1753.1
1753.3
1753.5
1753.7
1753.9
1754.1
1754.3
1754.5
1754.7
1754.9
1755.1
1755.3
1755.5
1755.7

1847.7
1847.9
1848.1
1848.3
1848.5
1848.7
1848.9
1849.1
1849.3
1849.5
1849.7
1849.9
1850.1
1850.3
1850.5

1847.9
1848.1
1848.3
1848.5
1848.7
1848.9
1849.1
1849.3
1849.5
1849.7
1849.9
1850.1
1850.3
1850.5
1850.7

Uplink Stop
1751.9
1752.1
1752.3
1752.5
1752.7
1752.9
1753.1
1753.3
1753.5
1753.7
1753.9
1754.1
1754.3
1754.5
1754.7

Downlink Start
1846.7
1846.9
1847.1
1847.3
1847.5
1847.7
1847.9
1848.1
1848.3
1848.5
1848.7
1848.9
1849.1
1849.3
1849.5

Downlink Stop
1846.9
1847.1
1847.3
1847.5
1847.7
1847.9
1848.1
1848.3
1848.5
1848.7
1848.9
1849.1
1849.3
1849.5
1849.7

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 18 -->

Uttar Pradesh
(East)

1800(MHz)

West Bengal

1800(MHz)

1754.7
1754.9
1755.1
1755.3
1755.5
1755.7
1755.9
1756.1
1756.3
1756.5
36.8000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1757.7
1757.9
1758.1
1758.3
1758.5
11.7740 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1732.1
1732.3
1732.5
1732.7
1732.9
1733.1
1733.3
1733.5
1733.7
1748.5
1748.7
1748.9
1749.1

1754.9
1755.1
1755.3
1755.5
1755.7
1755.9
1756.1
1756.3
1756.5
1756.7

1849.7
1849.9
1850.1
1850.3
1850.5
1850.7
1850.9
1851.1
1851.3
1851.5

1849.9
1850.1
1850.3
1850.5
1850.7
1850.9
1851.1
1851.3
1851.5
1851.7

Uplink Stop
1757.9
1758.1
1758.3
1758.5
1758.7

Downlink Start
1852.7
1852.9
1853.1
1853.3
1853.5

Downlink Stop
1852.9
1853.1
1853.3
1853.5
1853.7

Uplink Stop
1732.3
1732.5
1732.7
1732.9
1733.1
1733.3
1733.5
1733.7
1733.9
1748.7
1748.9
1749.1
1749.3

Downlink Start
1827.1
1827.3
1827.5
1827.7
1827.9
1828.1
1828.3
1828.5
1828.7
1843.5
1843.7
1843.9
1844.1

Downlink Stop
1827.3
1827.5
1827.7
1827.9
1828.1
1828.3
1828.5
1828.7
1828.9
1843.7
1843.9
1844.1
1844.3

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 19 -->

Reliance Jio
Infocomm
Limited

1749.3
1749.5
1749.7
1749.9
1750.1
1754.1
Uplink Start
1755.5
1755.7
1755.9
1756.1
1756.3
1756.5
1756.7
1756.9
1757.1
1757.3
1757.5
1757.7
1757.9
1758.1
1758.3
1758.5
1758.7
1758.9
1759.1
1759.3
1759.5
1759.7
1759.9
1760.1
1760.3

1749.5
1749.7
1749.9
1750.1
1750.3
1754.3
Uplink Stop
1755.7
1755.9
1756.1
1756.3
1756.5
1756.7
1756.9
1757.1
1757.3
1757.5
1757.7
1757.9
1758.1
1758.3
1758.5
1758.7
1758.9
1759.1
1759.3
1759.5
1759.7
1759.9
1760.1
1760.3
1760.5

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

1844.3
1844.5
1844.7
1844.9
1845.1
1849.1
Downlink Start
1850.5
1850.7
1850.9
1851.1
1851.3
1851.5
1851.7
1851.9
1852.1
1852.3
1852.5
1852.7
1852.9
1853.1
1853.3
1853.5
1853.7
1853.9
1854.1
1854.3
1854.5
1854.7
1854.9
1855.1
1855.3

1844.5
1844.7
1844.9
1845.1
1845.3
1849.3
Downlink Stop
1850.7
1850.9
1851.1
1851.3
1851.5
1851.7
1851.9
1852.1
1852.3
1852.5
1852.7
1852.9
1853.1
1853.3
1853.5
1853.7
1853.9
1854.1
1854.3
1854.5
1854.7
1854.9
1855.1
1855.3
1855.5

<!-- page 20 -->

1760.5
1760.7
1760.9
1761.1
1761.3
1761.5
1761.7
1761.9
1762.1
1762.3
1762.5
1762.7
1762.9
1763.1
1763.3
1763.5
1763.7
1763.9
1764.1
1764.3
1764.5
1764.7
Service Area
Assam

Jammu &
Kashmir

Band

2100(MHz)

2100(MHz)

Winning Price
per Block (In
Crore in INR)

1760.7
1760.9
1761.1
1761.3
1761.5
1761.7
1761.9
1762.1
1762.3
1762.5
1762.7
1762.9
1763.1
1763.3
1763.5
1763.7
1763.9
1764.1
1764.3
1764.5
1764.7
1764.9

1855.5
1855.7
1855.9
1856.1
1856.3
1856.5
1856.7
1856.9
1857.1
1857.3
1857.5
1857.7
1857.9
1858.1
1858.3
1858.5
1858.7
1858.9
1859.1
1859.3
1859.5
1859.7

1855.7
1855.9
1856.1
1856.3
1856.5
1856.7
1856.9
1857.1
1857.3
1857.5
1857.7
1857.9
1858.1
1858.3
1858.5
1858.7
1858.9
1859.1
1859.3
1859.5
1859.7
1859.9

Uplink Stop
1954.0

Downlink Start
2139.0

Downlink Stop
2144.0

Uplink Stop
1979.0

Downlink Start
2164.0

Downlink Stop
2169.0

Frequency Allocation of Service Area

120.0000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1949.0
40.0000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1974.0

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.

<!-- page 21 -->

North East

Uttar Pradesh
(West)

25.0000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1969.0
360.0000 Company Name Frequency
Bharti Airtel
Uplink Start
Limited
1949.0

2100(MHz)

2100(MHz)

Service Area

Band
2300

Service Area
Bihar

Service Area

Band
2500(MHz)

Band
3300

Service Area

Band
26

Uplink Stop
1974.0

Downlink Start
2159.0

Downlink Stop
2164.0

Uplink Stop
1954.0

Downlink Start
2139.0

Downlink Stop
2144.0

Winning Price per Block (In Crore
in INR)
No participation

Frequency Allocation of Service
Area

Winning Price per
Frequency Allocation of Service Area
Block (In Crore in INR)
Frequency
150.0000 Company Name
Vodafone Idea Limited Start
2545.0

Stop
2555.0

Winning Price per Block (In Crore
in INR)
No participation

Frequency Allocation of Service
Area

Winning Price per Block (In Crore
in INR)
No participation

Frequency Allocation of Service
Area

Note: The Government reserves the right to change the frequency assignment at any point over the duration of the
relevant licences where this is required for harmonising bands and promoting spectrum efficiency.
