---
doc_id: "cd87bf0b6b47aaaf"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/b5e84e9577fbe59f65f60b7cd7efcd0b.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Clarification dated 9.11.2012 on Direction u/s 33P of D&C Act on licensing in generic names only"
date: "2025-11-06"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c951a021b05a6421"
---

<!-- page 1 -->

अति-तत्काल / स्पीड़ पोस्ट द्वारा
MOST IMMEDIATE /BY SPEED POST
सं.एक्स.11011/1/2011-डीएफक्यूसी
No.X.11011/1/2011-DFQC
Nd UH / Government of India
स्वास्थ्य व परिवार कल्याण Aaraa / Ministry of Health & Family Welfare
Fares a uftare Hearor fast / Department of Health & Family Welfare
निर्माण भवन, नई दिल्‍ली
Nirman Bhavan, New Delhi
दिनांक 9 नवम्बर, 2012
dated the 9th November, 2012
To
(i) Principal / Health Secretaries of
all States/Union Territories
(ii) Drugs Controllers of
all States / Union Territories
Subject: Directions under section 33 (P) of Drugs and Cosmetics Act 1940 for grant /
renewal of manufacturing licenses of drug formulations in proper/generic name only — reg
Sir,
| am directed to refer to this Ministry's letter of even number dated 1.10.2012
conveying the directions of the Central Government in pursuance of the provisions
contained in Section 33 (P) of the Drugs and Cosmetics Act, 1940 for grant / renew
licenses by the State / UT drug licensing authorities for manufacture for sale or for
distribution of drugs in proper / generic names only and to say that clarifications have been
sought on various points in connection with the implementation of this statutory direction.
Accordingly, the following clarifications are provided by the Central Government
(i) This direction has prospective effect only.
(ii) This direction has been issued under the Drugs & Cosmetics Act, 1940
(iii) This direction is applicable only for the manufacturing license issued by the drug licensing
authorities under the provisions of the Drugs & Cosmetics Act, 1940.
(iv) This direction does not apply to the various types of certificates, namely, COPP. GMP
Certificate, Free Sale Certificate, etc required for the purpose of export of drugs, as these are not
issued under the Drugs & Cosmetics Act, 1940. The exports have to comply with the regulatory
requirements of the importing countries which require such certificates
(५) This direction is not applicable to grant / renewal of license for import of drugs.
(vi) This direction is not applicable to grant / renewal of license for manufacture and import of
medical devices.
22 2
ee

<!-- page 2 -->

(vii) This Direction is independent of the draft notification GSR 748(E) dated 5.10.2012
issued seeking comments of stakeholders on amending Drugs & Cosmetics Rules, 1945
allowing issuance of licenses of single ingredient drugs in generic / proper names only.
Yours faithfully
eS ee
SS
(तरसेम चंद)
(Tarsem Chand)
निदेशक / 8००7
टेलीफैक्स/ ७।४३०८: 23062352
Copy to: Drugs Controller General (India), FDA Bhavan, Kotla Road, New Delhi for wide
circulation. 7
