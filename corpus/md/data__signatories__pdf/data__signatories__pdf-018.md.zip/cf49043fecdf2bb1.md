---
doc_id: "cf49043fecdf2bb1"
source_url: "https://mnre.gov.in/static/uploads/2025/08/7d90f7fb6aaf7004f5fd5b87324f8130.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Scale Up of Access to Clean Energy Scheme Guidelines"
date: "2018-08-07"
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fcbae5e4701afdb6"
---

<!-- page 1 -->

F. No. 328/7/2017-EAP
Government of India
Ministry of New and Renewable Energy

***

Block No. 14, CGO Complex,
Lodhi Road, New Delhi-110003
Dated: 7 August, 2018

ORDER
Subject: Administrative Approval of "Scale Up of Access to Clean Energy Scheme" for
the period FY 2018-19 and FY 2019-20.
I am directed to convey the sanction of the President of India for launch of "Scale Up
of ccess to Clean Energy" Scheme for the period FY 2018-19 and FY 2019-20. Operational
guidelines for implementation of the Scheme are placed at Annexure.
2.
This Order is for implementation of Scheme on "Scale Up of Access to Clean
Energy" during FY 2018-19 and FY 2019-20 which is one of the four components under
the/ UNDP/GEF Project on Scale Up of Access to Clean Energy for Rural Productive Uses
(India ACE Project) being implemented in the states of Assam, Madhya Pradesh and
Od~sha. The funds for implementation of the Scheme would be met from Plan allocation
ma~e in each financial year during the tenure of the scheme, with an overall Plan Outlay of Rs.
70 Crores.
3.
Year-wise expenditure involved on account of financial support from the Government
oflndia is as given below:
Year
2018-19
2019-20
Total

Sanctioning target Proposed Outlay
(No. of beneficiaries)
(~ in Crore)
15000
30
15000
40
30000
70

4.
The implementation of above mentioned Scheme will come in to effect from the date of
issue of Administrative Approval along with its Operational Guidelines.
5.
This sanction issues in exercise of powers delegated to this Ministry and with the concurrence
ofIFD vide their Dy. No. 232 dated 02.08.2018.
Enclosed: As above.

~

(J. K. Jethani)
Scientist-E

To
The Pay and Accounts Officer
Ministry of New and Renewable Energy
New Delhi
Copy for information and appropriate action to:
1. All Central Ministries and Departments;

\

Page 1 of 2

<!-- page 2 -->

2. Principal Secretaries/Secretaries(Energy Departments) of Assam, Madhya Pradesh
and Odisha
3. State Nodal Agencies of Assam, Madhya Pradesh and Odisha
4. State Rural Livelihood Missions of Assam, Madhya Pradesh and Odisha
5. Municipal Commissioners of Assam, Madhya Pradesh and Odisha
6. CMD, !REDA, first floor, East Court ,Indian Habitat Centre, Lodhi Road, New Delhi
7. D.G., National Institute of Solar Energy Gwal Pahari, Gurgaon, Haryana
Copy also to:
1. PS to Hon'ble Minister for Power and New & Renewable Energy
2. PPS to Secretary, MNRE
3. PPS to AS, MNRE
4. PPS to AS & FA, MNRE
5. All Advisers & Group Heads/JS(GKG)
6. All Directors, PSOs
7. All Under Secretaries in MNRE
8. Director (NIC) to upload this on the Ministry's website
9. CA, MNRE/Cash Section
10. Hindi section for Hindi version
11. Sanction folder

q,~
(J. K. Jethani)
Scientist-E

Page 2 of 2

<!-- page 3 -->

Operational Guidelines for Implementation of Scale-Up Of Access To Clean Energy
Scheme

I. Background:
The Ministry of New and Renewable Energy (MNRE), GoI is implementing a project
titled “Scale Up of Access to Clean Energy (ACE) for Rural Productive Uses”, an initiative
to enhance the use of reliable and affordable renewable energy for rural productive
uses/livelihoods in un-served and under-served areas in 3 states; Assam, Madhya
Pradesh and Odisha for strengthening rural livelihoods, improving income generation
and reduce use of fossil fuels.
The project’s focus is on access to clean energy for rural livelihoods. The project is
based on the premise that lack of access to affordable and reliable energy hinders the
growth of various critical rural livelihoods activities such as poultry, dairy, horticulture,
animal husbandry, fisheries, and other village industries. It is expected that
decentralized renewable energy for electrical, thermal and mechanical applications will
catalyse rural livelihoods activities to reduce poverty, increase employment and
improve the rural quality of life.
The estimated total project cost of this scheme is about US$ 23.04 Million (equivalent
Rs.148 Cr.), with Rs.70 crore being the contribution of Government of India, Rs.31 crore
contribution from GEF and UNDP and Rs.47 crore to be mobilized through sources such
as State Govt. funds, CSR, beneficiary contribution, etc.
One of the goals of the project is reduction of the Green House Gas (GHG) emissions,
which is to be achieved through the objective of enhancing use of reliable and affordable
renewable/clean energy for rural productive uses/livelihoods in un-served and
underserved areas of Assam, Madhya Pradesh and Odisha. This will be achieved by
development and deployment of key Renewable Energy Technology Packages for Rural
Livelihoods (RETPRLs) applications and the integrated removal of key barriers that
prevent the wider adoption of renewable energy (RE) – rural livelihood technology and
services packages in India. The project comprises of the following 4 major components
and corresponding outcomes to be carried out in order to achieve the above mentioned
objectives:
Project Components
Project
Component 1

Outcomes

Development and deployment of
1. Deployment of RE-rural livelihood
key RE - rural livelihood
application packages
application packages

Project
Component 2

Supply chain for RE technology 2. Increased supply of RE technology and
supply and service providers for service providers for rural livelihood
enhancing rural livelihoods
applications.

Project
Component 3

3.1 Inclusion of RE applications in national
Policy and regulatory support for and state level rural livelihoods policies for
RE
rural
livelihoods key livelihood sectors in rural areas
applications
3.2 Future MNRE programs also cater to

<!-- page 4 -->

actions towards enhanced RE utilization in
rural livelihoods
3.3
Improved
interconnection
decentralized RE

tariff
and
regulations

grid
for

4.1. Improved decentralised RE subsidies
and support for rural livelihoods
Project
Component 4

Financial
support
decentralized
RE
livelihoods applications

4.2. Enhanced provision of financial
for
support for decentralized RE in rural
rural
livelihoods applications
4.3 Improved investment risk mitigation
for decentralized RE in rural livelihoods
applications

II.

Scheme:
Salient features of the Scheme on Scale-up of Access to Clean Energy to be
implemented in the States of Assam, Madhya Pradesh and Odisha are given below:
1. Objectives:
(i) To enhance access to reliable and affordable RE for rural livelihoods while
encouraging replacement of fossil fuels.
(ii) To create atmosphere for effective and innovative use of RE applications.
(iii) To encourage innovation in addressing market needs and promoting
sustainable business models.
(iv) To ensure a suitable supply chain for RE technology packages is established
(v) To support capacity building, awareness campaigns and human resource
development.
(vi) To ensure policy and regulatory support for enhanced REpenetration in rural
livelihood applications
(vii) To ensure enhanced financial support for RE for rural livelihood applications
2. Special thrust will be given on important rural livelihoods such as poultry, fishery,
horticulture, dairy, biomass based local businesses, cottage and other village
industries etc. Thrust will also be given on new renewable energy applications like
solar dryers, solar cold storage, solar aerators, etc.
Duration of the Scheme: Scheme will be available for FYs 2018-19 and 2019-20

<!-- page 5 -->

3. Project Component 1: Development and deployment of key RE - rural
livelihood application packages
3.1 Scope of the Scheme:
3.1.1 The scheme will be available for FYs 2018-19 and 2019-20, for promotion of RE
based rural livelihood applications only. The scheme will be implemented in 3 target
states; Assam, Madhya Pradesh and Odisha. Initially, a total of 19 districts have been
identified in the 3 target states for implementation of the Scheme covering 1500
beneficiaries. Subsequent to this, the scheme would be applicable to all districts of the 3
target states covering additional 28500 beneficiaries. The 19 identified districts for the
initial phase are:
Sl.
No.

State

District

1

Barpeta

2

Nalbari

3
4

Assam

Kamrup Rural
Darrang

5

Udalguri

6

Goalpara

7

Hoshangabad

8

Betul

9

Ratlam

10

Madhya Pradesh

Raisen

11

Dhindori

12

Balaghat

13

Sehore

14

Koraput

15

Keonjhar

16
17

Odisha

Khurda
Kalahandi

18

Puri

19

Mayurbhanj

<!-- page 6 -->

An indicative list of RE technologies for enhancement of rural livelihood applications is
as given below:

S. No.

Livelihood Sectors

Renewable Energy Technologies
(A) Solar PV Lighting System and Ventilation for Backyard
Poultry Farm

1

POULTRY

(B) Biogas Plant based on Poultry Litter for captive use in
Layer Farms and Hatcheries
(C) Biomass Waste Briquetting from Poultry Farm

2

DAIRY

(A) Solar PV System for Milk Chilling at Milk Collection
Centres
(B) Biogas Plant based on Cattle Dung for captive use

3

HORTICULTURE

4

FISHERIES

5

6

COTTAGE INDUSTRIES:
(Pottery, Smithy,
Carpentry, Textile,
handicraft, embroidery,
leather, handmade
paper, Production of
building materials)

(A) Solar PV System for Small Cold Rooms
(B) Solar Dryers for drying spices, vegetables and fruits
(A) Solar Aerators
(B) Solar Fish Dryers
(A) Solar PV based power for lighting and powering
equipment at Common Facility Centers for artisans
(B) Biomass Gasifier based on Bamboo Waste
(C) Solar PV based power for lighting and powering
Charkhas at Common Facility Centers
(D) Solar PV based lighting and powering for CFC for
looms

RET microgrid/stand-alone solution to manage multiple
energy-enabled livelihood activities that could include
Rural Industrial Clusters
food processing (vegetables, grains, fruits, etc.), oil
(RIC)
processing, meat processing, herbal processing,
refrigeration, stitching, mechanical workshop, rural BPOs,
DTP &eGov services, irrigation, cold storage, etc.

3.1.2 Training programmes and workshops would be organized in the 3 target states of
Assam, Madhya Pradesh and Odisha for different stakeholders including MNRE officials,
RE technology providers, beneficiaries, representatives from state level agencies, local
self-help groups, etc. These training programmes and workshops would target on
project awareness, capacity building on RETPRLs’ applications, specifications and costs,
testing, etc.

<!-- page 7 -->

3.2 Implementation Arrangements:
3.2.1 Scheme will be implemented through State Renewable Energy Development
Agencies (SNAs) and State Rural Livelihood Missions (SRLMs) as the Implementing
Agencies. A total of 3% of the eligible CFA will be provided as service charges to be
shared amongst the Implementing Agencies. This service charge would be provided by
MNRE in addition to CFA.
3.2.2 Livelihood activities and requirement of RE applications for each state will be
assessed and verified by the SRLMs. SNAs will assess and evaluate the RE technology
and implement the projects in coordination with SRLMs.
3.2.3 The scheme is technology neutral and SRLMs/SNAs may choose any RE
technology for implementation. Procurement shall be done through the tender route.
SNAs will submit the project proposals directly to MNRE for approval/sanction on Scale
Up of Access to Clean Energy Scheme website that would be developed over time. SNAs
will also submit project inspection and project completion reports for installed RETPRL
projects to MNRE through the scheme website. Formats to be used for submission of a
project proposal, project inspection and project completion reports for different
RETPRL projects will be as issued by MNRE from time to time.
3.2.4 SNAs/SRLMs will make effort to involve local self-help groups in implementation
of the Scheme.
3.2.5 The RE systems provider will establish a local service centre at block/district level
and a telephone helpline number at state level for providing necessary operation &
maintenance and after sales services.
An indicative Block Diagram showing the Operational Mechanism of the Scheme is given
below:

Supplier
Supply of
Systems

Tender
Livelihood
Opportunity
Assessment

Proposal

MNRE

SNA

SRLM

Sanction
Beneficiary
Contribution

Supply of
Systems

BENEFICIARY

<!-- page 8 -->

3.3 Funding:
3.3.1 The programme will be implemented through SNAs only by inviting tenders. The
Ministry will provide subsidy to eligible beneficiaries @ 30% of the benchmark cost or
tender cost, whichever is lower for the RE technology system. For new, complex and
non-commercialized RE technology systems, technical specifications and benchmark
costs will be developed separately and an additional financial assistance (over and
above the CFA of 30%) will be worked out as per approval from MNRE.
3.3.2 15% of the total number of RETPRLs supported in each state will be reserved for
beneficiaries from Scheduled Castes and 7.5% of the total number of RETPRLs
supported in each state will be reserved for beneficiaries from Scheduled Tribes.
3.3.3 The CFA from MNRE would not preclude the implementing agencies from
availing other fiscal and financial benefits being provided by State, Central Governments
and any other agency as long as the same is clearly disclosed in the project
report/proposal.
3.4 Release of Funds:
3.4.1 MNRE may release up to 30% of the CFA as advance to SNA on placement of
work order. The balance 70% would be released based on the progress of the project
and submission of Utilization Certificate and other related documents. SNA will provide
the beneficiary details and Aadhaar number for uploading on the DBT Portal.
3.5 Project Duration:
3.5.1 Projects shall be completed in 12 months in General category States and within
15 months in NE States, from the date of sanction. Post this, penalty will be levied.
However, maximum time allowed for completion of projects inclusive of penal period is
16 months in General category States and 19 months in NE States. Purchase Order shall
be placed within six months from date of sanction, failing which the sanction will be
cancelled without notice.
3.5.2 In case of failure to complete the project within stipulated period, penalty will be
imposed on service charges to be given to implementation agency as given below:
i) 30% reduction in applicable service charge for delay of two months in
completion of project over and above the approved project duration.
ii) Further reduction of 30% for delay of two more months.
iii) No service charges for delay in completion of more than 4 months.
3.6 Monitoring, Feedback & Evaluation:
3.6.1 Monitoring and Evaluation studies will be carried out during the period of
implementation of the Scheme as given below:
i) The primary level of monitoring at site will be done by SNAs and MNRE will do
the overall monitoring.
ii) For projects with applications above 10 kW, the system providers would also
make available generation data to MNRE at intervals specified.

<!-- page 9 -->

Online monitoring will be compulsory for all systems more than 10 kWp capacity for PV
and equivalent capacity other systems, the exact benchmark would be specified by
MNRE later. Real time monitoring may be specified by MNRE for large systems and
online monitoring would be eventually extended to smaller systems as well.
Life of systems and products will be specified from time to time and efforts will be made
to ensure that no systems or products are discarded before full life usage.
3.7 Technical Requirements:
3.7.1 All the RETPRLs’ systems should have the minimum technical requirements,
quality standards and specifications for different rural livelihood applications as
specified by MNRE from time to time. For individual beneficiaries, RETPRL systems (for
all RE livelihood applications except Solar Pumps) with a maximum capacity of up to 3
kWp and Solar Pumps (for horticulture) with a maximum capacity of up to 1 HP will be
sanctioned for installation. For community based beneficiaries, RETPRL systems (for all
RE livelihood applications) with a maximum capacity of up to 50 kWp will be
sanctioned for installation.
3.7.2 Only indigenously manufactured PV modules should be used in Solar PV systems
and off-grid PV power plants. However, other imported components can be used,
subject to adequate disclosure and compliance to specified quality norms and
standards.
3.8 Benchmark Cost of RETPRLs:
3.8.1 The benchmark cost would be fixed based on the following two main criteria:
a) Price determined through tenders done by SECI, State Nodal Agencies and other
Government Departments/organizations in 12 months preceding the date when the
committee starts working for determining the benchmark cost for next year.
b) Component wise cost breakup to arrive at an estimated price of each of the products
for which benchmark cost is determined. The committee will collect data about all the
tenders floated with MNRE subsidy. These would then be clubbed into different
categories depending on the product, technology etc. Thereafter, the committee may
develop criteria for arriving at a rate out the price or by calculating median. The
benchmark so determined through tendered price will then be compared with values
arrived at through costing by clubbing the price of various components. In case of wide
difference, the committee may go into the reasons and if need be, apply correction
factor.
3.9 Hybrid Systems:
3.9.1 Based on demand and resource potential, hybrid RE systems may be considered
for implementation on case to case basis. CFA in such cases will be limited to 30% of the
benchmark cost of the individual components of the hybrid system.

<!-- page 10 -->

4. Project Component 2: Supply chain for RE technology supply and service providers
for enhancing rural livelihoods

4.1 Scope of the Scheme:
4.1.1 Initially, 20 RE technology supply and service providers will be supported to
develop RE supply chain and provide the required equipment supply, services, etc.
These RE technology supply and service providers could be equipment manufacturers,
dealers, local entrepreneurs, etc. from the target states preferably from the identified 19
districts as specified in Project Component 1.
4.1.2 Subsequently, 80 additional RE supply and service providers will be selected
(financial support will not be given but will be assisted in developing their business
plans, technical training, etc.) to set up supply chain and provide the required
equipment supply, services, etc. across different districts of the target states.
4.1.3 Training programmes and site tours would be organized to enhance the exposure
of RE technology supply and service providers and enable them to develop RE
technology packages that are in line with livelihoods’ user requirements.
4.2 Implementation Arrangements:
4.2.1 The RE technology supply and service providers will be selected by inviting
applications through an EOI. The EOI and criteria for selection will be as issued by
MNRE.
4.2.2 The RE technology supply and service providers will also be provided with inputs
in preparation of business plans, technical training, access to state level support
schemes, etc.
4.3 Funding:
4.3.1 The financial support for the RE technology supply and service providers, training
programmes and site tours will be provided from the UNDP/GEF share of the EAP
project funds. Only the initial 20 RE technology supply and service providers will be
provided the financial support. The additional 80 RE technology supply and service
providers shall be provided with inputs as specified above under point 4.2.2.
5. Project Component 3: Policy and regulatory support for RE - rural livelihoods
applications
5.1 Scope of the Scheme:
5.1.1 National rural livelihoods mission (NRLM) and State rural livelihoods mission
(SRLM) statements and documents, National and State level rural livelihoods policies
for different states and identified livelihood sectors will be assessed for provision of RE
technologies. Recommendations on potential RE technologies and applications for
convergence with existing policies of NRLM, SRLMs’ existing policies, National and State
level rural livelihoods policies of the target states will be developed.

<!-- page 11 -->

5.1.2 The experiences and lessons from RETPRL based implemented projects as
specified under Project Component 1 will be documented. A project website will be
developed for sharing these project documents and other project related information.
The documentation will also be developed in the form of printed case studies.
5.1.3 Existing MNRE and state level schemes will be assessed in terms of extent and
effectiveness of support for RE for rural livelihood applications.
5.1.4 Assessment of existing tariff structures, regulations, arrangements and barriers for
grid interconnection of small scale captive and off-grid RE applications will be
conducted. Guidelines will be developed based on the assessment for tariff setting,
technical and regulatory aspects for grid interconnection of captive and off-grid RE
applications.
5.1.5 Meetings and workshops with concerned officials from NRLM, SRLMs and
concerned Ministries/Departments of target states will be organized to promote
experiences and recommendations on RE applications for rural livelihoods for existing
policies. Project Staff/Implementing Agencies will be encouraged to participate in
relevant national/international conferences and platform for promotion of experiences
on RE applications for rural livelihoods.
5.2 Implementation Arrangements:
5.2.1 Assessment studies, documentations and development of project website will be
performed through EOI. The EOI will be as issued by MNRE.
5.3 Funding:
5.3.1 The financial support for assessment studies, documentations, project website,
workshops and meetings will be provided from the UNDP/GEF share of the project
funds.
6. Project Component 4: Financial support for decentralized RE - rural
livelihoods applications
6.1 Scope of the Scheme:
6.1.1 Existing RE subsidy schemes and other support models will be assessed in terms
of effectiveness, reach and efficiency. Alternate RE subsidy and support models will be
explored.
6.1.2 Mechanisms will be explored for pooling of financial resources available in form of
subsidies, soft loans, etc. for RE technology providers and users for rural livelihood
applications. Recommendations will be provided for easy access of available financial
benefits for the RE technology providers and users.
6.1.3 Methods for providing investment risks and their mitigation, risk guarantee
methods for renewable energy and rural livelihoods context will be assessed. New
methods for risk guarantee will be developed for RE enterprises and end users in rural
livelihood applications.

<!-- page 12 -->

6.1.4 Meetings and workshops will be organized for promotion of the recommendations,
explored RE subsidy and support models, recommendations on financial resources’
pooling, methods for risk guarantee for RE enterprises and end users, etc.
6.2 Implementation Arrangements:
6.2.1 Assessment studies, exploring new investment risk methods, mechanisms of
financial resource pooling will be performed through EOI. The EOI will be as issued by
MNRE.
6.3 Funding:
6.3.1 The financial support for assessment studies, new methods on investment risk,
financial resource pooling, workshops and meetings will be provided from the
UNDP/GEF share of the project funds.
7. Management Arrangements
7.1 Steering Committee and an Executive Committee formed under the UNDP-GEFMNRE project will oversee the overall implementation of this Scheme. The constitution
and Roles & Responsibilities of the Committees are as given below:
1) Project Steering Committee (PSC): Project Steering Committee is an over-sight
and governance focussed high-level group which includes organizations that are
core supporters and/ or significant co-financiers under the Scheme. Besides MNRE,
UNDP and GEF (through MOEF), this committee also includes NRLM, IREDA, DEA,
MSME as well as representatives of the state-level agencies that bring a significant
contribution to the Scheme. The Secretary, MNRE will chair the SSC meetings. The
Committee will meet at least once a year focussing on the Annual Project
Report/Project Implementation Report (APR/PIR) for the last year, and the review
and formal endorsement of the Annual Work Plan for the upcoming year of the
Scheme operations.
2) Project Executive Committee (PEC): The Project Executive Committee comprises
of all major stakeholders who are actively involved in project activities and who are
interested in the project’s results. The SEC will include representatives of MNRE,
UNDP, NRLM and State representatives. The Joint Secretary, MNRE, will chair the
SEC meetings. This group will meet at least four times a year. The SEC will review
the Quarterly Progress Report (QPR) for the past quarter, and review what practical
implementation steps needed to maximise the activity success in the upcoming
quarter. The group is also expected to act as the forum for resolving major
implementation level issues that may arise between different government
departments or other key stakeholders.
8. Information, Publicity and Trainings
8.1 Financial support used for seminar/symposia, capacity building, awareness
generation, publicity, training and to banks as incentive and studies to be carried out
etc. will be provided through UNDP/GEF share of the Project.

<!-- page 13 -->

8.2 Workshops/Seminars would be organized through UNDP/GEF share of funds for
experts to discuss best practices, debate over issues to overcome bottle necks and
provide effective policy suggestions for ensuring wide spread RETPRL deployment at
the national level.
9. Interpretation of the Guidelines
9.1 In case of any ambiguity in interpretation of any of the provisions of these
guidelines, the decision of the Ministry shall be final.
