---
doc_id: "cd44eac64ce1f71e"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/c8d12f7f4364713d371a5ff7f52d990b.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Posting/Transfer of JTS Officers of CLS (19 sep 2014)"
date: "2014-09-19"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "82e4ddd3990e0487"
---

<!-- page 1 -->

F. No. A-19011/02/2014-CLS-I
Government of India/Bharat Sarkar
Ministry of Labour & Employment/Shram Evam Rozgar Mantralaya
Shram Shakti Bhavan, Rafi Marg
New Delhi, the 19th September, 2014

OFFICE ORDER No.22/ 2014
Subject: Posting/Transfer of JTS Officer of Central Labour Service.

In partial modification of this Ministry's Office Order No. 17/2014
(F. No. A-22013/04/2014-CLS.I) dated 22.08.2014 and Offer of Appointment to JTS
Grade vide letter No. A-19011/02/2014 dated 26.08.2014, Shri Sumit, LEO(C), Jodhpur,
who was earlier posted as ALC(C), Hyderabad is now posted as Assistant Labour
Commissioner (Central), Jalandhar (Punjab) with immediate effect.
2.
Shri Sumit is directed to report to the Dy. CLC(C), Chandigarh and submit the
original Certificates in support of his Educational Qualifications, Date of Birth etc to the
Dy. CLC(C), Chandigarh, who will verify the genuineness of the Certificates and send a
report to this Ministry.
·

3.
4.

::~==s::hc:~:i:i:::~a~i:;:: i:::::~: :~::;;tment remain~
will

(S K S1ngh)
Under Secretary to the Govt. of India
Tel No. 011-23766903
Distribution:-

1.

y

3.
4.
5.
6.
7.

Shri Sumit, LEO(C), Jodhpur.
Dy. CLC(C), Chandigarh (The documents furnished by Shri Sumit, who has been
posted as ALC(C), Jalandhar may be verified from the originals and authenticated
copies of documents as referred in para no. l(vii), 2, 4 & 8 of Offer of
Appointment issued to the Officer may be sent to this Ministry for record.
Dy. CLC(C), Ajmer/Dy. CLC(C), Hyderabad.
PS to LEM/PS to MOS(L&E)/PSO to Secy(L&E)/CLC(C)/JS(AP)/DGLW.
Adm.I/SE Section, 0/o-CLC(C), New Delhi.
CLS.II Section, Ministry of Labour &·Employment.
Personal File of the Officers concerned/ Office order bundle/spare copies.
