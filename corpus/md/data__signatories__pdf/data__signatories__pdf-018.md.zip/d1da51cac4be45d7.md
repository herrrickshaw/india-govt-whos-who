---
doc_id: "d1da51cac4be45d7"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/1d9bd83f7ae9f8fc1b476fc54dd9badc.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "DoT Notification dated 29.08.2018"
date: "2025-07-03"
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4ce81754be640daa"
---

<!-- page 1 -->

��
�

of 12
Page 1 0f

[To
published in
tte oflndia,
[To be
be published
in the Gaz
Gazette
of India, Part I, Section 1]
~ 'TR O DINARY
EXTRAORDINARY
No.
No. 18-10/2017-IP
18-10/2017-IP
Government of India
Ministry
Ministry of Communications
Department
Department of Telecommunications
New Delhi, 29
29th�� August, 2018
2018

Notification
Subject:
Subject:

Public
Public Procurement (Preference to Make in India) Order
Order 2017- Notification of
I com Products,
Product , Services or Works
Telecom
Works - regarding.

Reference:
Reference:

i)
i) Department or
of Industrial
Industrial Policy & Promotion (DIPP) Order No. P-

45021/2/2017-B.
45021/2/2017-B.E.-II
dated 15.06.20
15.06.2017
• .-Il elated
17
Dcpartrn nt off lndu
tria l 'Poli
ii) Department
Industrial
Policy &
& Promotion (DIPP) Order No. P45021/2/2017-PP
45021/2/2017-PP (BE-II) dated 228.05.2018
.0S.2018

The
The Government
Government has
has issued
issued Public
Public Procurement
Procurement (Preference
(Preference to
to Make in India) Order
2017
Department oflndustrial
and Promotion
2017 vide
vide the
the Department
of Industrial Policy
Policy and
Promotion (DIPP)
Order No. P-45021/2/2017P-45021/2/2017(DIPP) Order
B.E.-ll
l 5.06.2017 which
is fu11her
B.E.-1I dated
dated 15.06.2017
which is
further revised vide No. P-4502
P-45021/2/2017-PP
(BE-II) dated
I /2/20 l 7-PP (BE-IL)

28.05.2018 to
to encourage
in India'
India' and
28.05.2018
encourage 'Make
'Make in
and to promote
promote manufacturing and production
production of goods
and
with aa view to enhancing
enhancing income
income and employment.
employment.
and services
services in
in India
India with

2.
2.

DIPP
DIPP has
has identified
identified Department
Department of
of Telecommunications
Telecommunications as
as the
nodal Department
Department for
the nodal

implementing the
of goods,
goods, services or
implementing
the provisions
provisions related
related to
to procurement of
related to the
or works related

telecommunication sector.
telecommunication
sector.
3.
3.

J\ccordingly.
Accordingly, in
in furtherance
furtherance of
of the
the aforesaid Public
Public Procurement (Preference to Make in

f adia). O,dcr
Order), and
ladia).
Order 2017
2017 (hereinafter
(hereinafter called as PPP-MIi
PPP-MII Order),
and in
in supersession
supersession of
of notification of
�
ihis
Policy for
Preferential Market
Access (PMA)
this Deparl.menfs
Department's Policy
for Preferential
Market Access
(PMA) dated
dated 5
5°1 October 2012 and

notification
for value
dated 11 P
2017, the
the Department of
notification for
value addition
addition criterion
criterion dated
I t h11 January
January 2017,
Telecommunications,
hereby notifies
notifies that
that the
Telecommunications, hereby
aforesaid Order
Order shall be applicable for telecom
the aforesaid
products, services
products,
services or
or works
works in
in full
full except
except as specified in this notification.
notification

4.
4.

It is
It
is clarified
clarified that
that this
this notificatio!1
notificatio n shall be
be applicable
applicable to
to all
Central Schemes
Schemes (CS)/
(CS)/ Central
all Central

Sector
for which
Sector Schemes
Schemes (CSS).
(CSS), for
which procurement
procurement is
ismade
made by
by States
States and ILocal
,ocal Bodies, if that project

<!-- page 2 -->

Page
12
Page 2
2 of
of 12

including Universal Service
or scheme is fully or partially
pa1tially funded by the Government of India i11cluding
Obligation Fund (USOF) projects.
5.

ln
Department of
In terms of clai1ses
clauses 2, 33 and l111 of PPP-MMI Order, the Depar~m~nt

Telecommunications has
prepared a list of telecom products, services and works for their
has prepared

purchase prefer
nee from local
upplier fo
te lec ,m pro~
ts, . .
preference
local suppliers
for public procurement. The list of
of telecom
products,

their
India (PMI) and
and theif.~~l:1~
theiil@cal Cont'ent
services and works along with th
ir Preference to Make
fake in Jndia
;·onfeiit ·
(LC) is in Table-A.
Table-A. The local supplier has to manufacture equipment from
from componeflt
component level
level in
India and
and also develop local vendors fot
for procureine11t
procurement ofraw
of raw materials, components and pparts
arts for
for

identified conditions for the inputs to be qualified
increasing local content. The Department has identified
as Local Content and
ahd"maximum
maximum ceiling 'for
for de.sign
design as LC out of total LC which are in Table-B
Table-B

Table-C respectively.
and Table-C
6.

In terms of clauses 3(a) and 11 of the PPP-MIi
PPP-MII Order, it is declared
declared that list of
ot telecom

product, services and works in Table-A
Table-A have sut1icient
sufficient local capacity and
and local
local competition. It

notified that the procuring entities will procure a min.
is hereby notified
imum percentage as indicated
minimum
in India (PMI) of their telecom products, services or works
under Preference to Make
Make in
requirements fulfilling Local Content (LC) criterion prescribed against each item as in
A.
in Table
Table A.
7.

Clause 14 (a) of PPP-Mfl
PPP-MII Ol'der
Order regarding powers to reduce the minimum local
local content

below the prescribed level
level stands withdrawn from Ministries/Departments of Government of
India and the Boards of Directors of Government companies or autonomous bodies. This power
vests only with Standing Committee as constituted under clause l6
L6 of PPP-Mr! Order.
8.

In terms of clause 9(a) of PPP-MIi
PPP-MII Order, the local
local supplier at the time of tender, bidding

or solicitation shall provide self-certification in
in Form-1
Form-1 specifying that the item offei-ed
offered meets

the minimum local
local content and
and shall give details of the location(s) at which the local value
addition is made.
9. Each identified
identified products, services or works as in Table-A
Table-A shall comply with the latest TEC
GR/IR, if such GR/JR
been issued. The procuring entity may ensure that prior experience
GR/IR have been

clause is not too restrictive to exclude all local suppliers of telecom product, services or works.
All Procurement Officers may be required to certify compliance of this order before uploading
tenders on Central Public Procurement Portal (CPPP). Disciplinary action will be taken against
erring officers who insert restrictive tender conditions against local
local suppliers with a malafide
intent or otherwise flout the provisions of PPP-MU Order.

I
�

I
I

<!-- page 3 -->

------ ---

Page 3
3 of
0f 12
12

11 0.
O. For
For compliance
compliance of
of GR/IR
GR/IR or
or any
any national
national standard,
standard, certification
certification from
from Indian
Indian bodies
bodies i.e.
i.e.

mandatory requirement
to be
be
TEC/TSEC, STQC, BIS or
or any
accredited lab
lab by them,
them, is
is aa mandatory
TEC/TSEC.
any accredited
requirement to
submitted by
the bidder.
For any
any telecom
telecom product,
product, service
service and
and work
work as in
in Table-A,
Table-A, the
the procuring
submitted
by the
bidder. For
procuring
any foreign
entity
entity should
should not
not specify
specify to
to bidder
bidder to
to mandatory
mandatory qualify
qualify any
foreign eligibility
eligibility specifications
specifications or
or
certification(s)
certification(s) issued
issued by
by any
any foreign
foreign testing/security
testing/security lab(s).
lab(s).

I1..
11

In case
case aa complaint
In
by the
procuring entity
complaint is
is received
received by
the procuring
entity or
or the
the concerned
concerned

Ministry/Department against
against the
the claim
claim of
of aa bidder
products,
Ministry/Department
bidder regarding
regarding local
local content
content in
in telecom
telecom products,
telecom product,
being procured
procured is
product,
services
services or
or works
works or
or in
in case
case of
of aa question
question whether
whether an
an item
item being
is aa telecom
be covered
under tbe
notification or
products,
service
service or
or work
work to
to be
covered under
the notification
or any
any doubt
doubt in
in respect
respect of
of telecom
telecom products,

services or
or works,
works, reference
reference shall
shall be
made to
Telecommunications Engineering
Engineering Centre
Centre (TEC),
be made
to Telecommunications
services
Department
Department

of
of Telecommunications
Telecommunications

or

technical
technical

auditor
auditor

as
as

accredited
accredited

by the
by
the

Telecommunications Engineering
Engineering Centre
Centre (TEC),
(TEC), Department
Department of
of Telecommunications),
Telecommunications), New
New
Telecommunications
Delhi.
Delhi.
12.
12.

In
clause 9(d)
In terms
terms of
of clause
9(d) of
of PPP-MIT
PPP-MIT Order,
Order, the
the following
following Committee
Committee is
is constituted
constituted for
for

complaints
complaints and
and independent
independent verification
verification of
of self-declarations
self-declarations and
and auditor's/accountant's
auditor's/accountant's
certificates
certificates on
on random
random basis
basis::

i.
11.
ii.
iii.
111.
iv.
iv.
v.
v.
v1.
vi.

DDG(T
) TbC
DDG(TC),
TEC, Ne,
New Delhi
Delhi
Direct r (Technica
l), C-DOT
Director
(Technical),
C-DOT
n other
member(s as
n co-opted
by the
Any
othermember(s)
co-opted by
the chairperson
chairperson
DG,
DG, TEPC
TEPC
Director
Director (Finance),
(Finance), DoT
Do'T
Director.
Director, TE
TEC·

13.
13.

In
by the
the procuring
procuring enti
ty or
complaint is received
received by
entity
or the
the concerned
concerned
In ca
casee aa complaint

1.

-Chairperson
-Chairperson
Member
-- Member
-- Member
Member
-- Mcmbe1
Member·
-- M
mber
Member
-- Convener
Convener

Ministry/Department
against th
the cla
claim
of aa bidder
Mini
try/Department against
im of
bidder regarding
ontent (LC)
regarding Local
Local Content
(LC) in
in aa locally
locally
supplied
telecom
same shall
shall be
referred to
to the
Committee as
as in
upplied te
lecom product,
pr duct sservices
r i ·e or
or vworks,
orks, the
the same
be referred
the Committee
in
weeks, as
as far
far as
as possible,
para
above.
The Committee
dispose
the complaint
complaint within
para 12
12 abo
e. The
ommittee should
hould di
pose of
ofi-he
within 44 weeks,
possible.
the date
receipt or
of complaint
complaint along
along vwith
all necessary
necessary documentation
documentation in
in support
support of
of Local
Local
from the
date of
of receipt
ith all
from
Content
by the
Content claimed
claimed by
the bidder.
bidder.
14.
14.

In
is hereby
(e) of
of PPP-Mil
PPP-MII Order,
Order, itit is
hereby notified
notified that
that there
there will
will be
be aa
In terms
terms of
of clause
clause 99 (e)

Lakh or
or I%
1% of
of the
the value
value of
ofthe
locally supplied
supplied telecom
telecom products,
the locally
products,
minimum complaint
minimum
complaint fee
fee oft
of 22 Lakh
services or
or works
works being
being procured
(subject to
to aa maximum
Lakh), whichever
whichever is
is higher,
higher, to
to
maximum of
of f� 55 Lakh),
services
procured (subject
be paid
paid by Demand
be deposited
ith Telecommunications
be
Demand Draft
Draft or
or online,
online, and
and to
to be
deposited with
Telecommunications Engineering
Engineering

Centre (TEC),
(TEC), as
as the
the case
case may
may be,
or with
with any
any other
other third
third party
testing laboratories
laboratories or
or technical
technical
Centre
be, or
party testing
auditors accredited
accredited by
by TEC
TEC along
along with
the complaint
complaint by the
the complainant.
complainant. In
In case,
case, the
the complaint
complaint
with the
auditors

<!-- page 4 -->

Page
Page 4 of
0f 12
12

is
be incorrect,
be forfeited.
upheld in
is found
found to
to be
incorrect, the
the complaint
complaint fee
fee shall
shall be
forfeited. In
In case,
case, the
the complaint
complaint is
is upheld
in
part or
be refunded
part
or full,
full, deposited
deposited fee
fee of
of the
the complainant
complainant will
will be
refunded without
without any
any interest.
interest.
15.
be the
nodal Department
to monitor
monitor the
the
15. The
The Department
Department of
of Telecommunications
Telecommunications shall
shall be
the nodal
Department to
implementation
this notification
notification for
telecom products,
products, services
works. For
vetting the
the
implementation of
of this
for telecom
services and
and works.
For vetting

restrictive and
and discriminating
discriminating terms
terms and
and conditions
conditions against
against domestic
domestic manufactures of
of telecom
telecom
products; services
products,
services and
and works,
works, aa Committee
Committee is
is constituted
constituted with
with the
the following
following composition:
composition:

16.

i)
i)

JJS (n
(T)

Chairperson
Chairperson

ii)
ii)

DDG(IC)
DDG(I )

Vice-Chairperson
Vice-Chairperson

iii)
iii)

Onerrepresentative
pre enlativ of
ofTE
One
TEC

Member
Member

iv)
iv)

ne repre
One
representative
ntati C of
Of C-DOT
-DOT

Member

v)
v)

Directorr (IP)
Direct
(IP

.

Member
Member Secretary
Secretary

The
Notification comes
The Notification
comes into
into effect
effect immediately
immediately and
and shall
shall remain
remain valid
valid till
till revised.
revised.

k � * * Mk * �
*********

<!-- page 5 -->

Page
Page 55 of
12
of 12

Ta
bJe -A
Table
-A
List
of Telecom
List of
Telecom Products,
Products, Services and Works with PMI and LC

SI. No.
No.
SI.

Telecom
Telecom Products,
and Works
Products, Services
Services and
Works

Encryption/UTM platforms
(TDM and IP)
Encryption/UTM
platforms (TOM
IP/MPLS Core
IP/MPLS
Core routers/
routers/ Edge/
Edge/ Enterprise Router
Managed
equipment
Network equipment
Leased line
Managed Leased
line Network
Ethernet
Ethernet Switches
L3), Hubs
and L3),
Switches (L2
(L2 and
IP
ed Soft
itche IIMS,
IP ba
based
Soft S,.
Switches,
Unifi d Comm1,mication
MS, Unified
Communication
Systems
Systems
Wireless/Wireline
PABXs // IP
Wireless/Wireline PABXs
PBX &
IP PBX
6.
6.
& / Media
Gateways
Media Gateways
in
and
Routers,
Wi-Fi
points
(including
Access
CPE
luding
Wi-Fi
Acee
7. CPE
7.
R uter Media
onvcrt rs). 2G/3G/4O/L
Converters),
2G/3G/4G/LTE
Modem , Lea
T • Modems,
Leased-line
cd-line
Modems.
Modems, NFV/SDN
NFV/SDN CPE
CPE
Set-Top Boxes
Boxes
8.
8. Set-Top
SDH/Carrier-Ethernet/MPL
H/Ca rricr-Elhernct/MPLS9.
S- TP/ Packet
9. SD
Packet Optical
Optical
PTN/ OTN systems
Transport equipment/
Transoort
equ ipment/ PTN/
systems
DWDM/CWDM systems
10.
10, DWDM/CWDM
GPON // XOS-PON.
11.
XGS-PON, NG-PON2
NG-PON2 equipment
(including
equipment (inc
11. GPON
luding
ONT
ONT and
OLT)
and OLT)
12.
Optical/S DI .1/POH Cross
Cross Connect
Connects// OTN Cross-connects
12. Optical/SDH/PDH
and optical
optica l MUX,OADM
MUX,OADM
and
size 22 G/3
Smalll'l size
13.
13. Sma
G GSM
G/3 G
GSM based
Base Station
based Base
Station Systems.
System ,
with its
its various
various derivatives
including rural
derivatives including
with
rural &
disaster
& disaster
response.
response. Macro
Macro & Micro
Micro BTS,
Small Cells,
BTS, Small
Cells, NIB,
NIB, CCRAN
RRH
and RRI--1
BBU and
RAN BBU
GSM based
based Base
14.
14. 22 G/3
G/3 G
Base Station
Station Systems,
its
Systems, with its
G GSM
various
derivatives
various derivatives includi
rural &
including
ng rural
disaster response,
& disaster
response,
Macro
& Micro
Macro &
Micro BTS,
BTS, Small
NIB, C-RAN
Cells, NIB
BBU and
C-RAN BBU
mall Cells,
RRH
RRH
15.
15. Small
TE/ LTE-R Based
Size L
Systems, with its
Small Size
LTE/LTE-R
Mobile
Based Mobi
le Systems,
various
various derivatives
derivatives including
including rnral
rural &
& disaster
disaster
communications,
Macro &
communications, Macro
eNodeB, Small
Small Cells,
Micro eNodeB,
& Micrn
Cells,
EPC.
EPC. NIB
BBU and
RRH ,LTE/LTE-R/4.5 GI
NIB C-RAN
G/ 55
C-RAN BBU
and RRH
G
based broadband
broadband wireless
G based
access systems
systems (eNodeB,
(eNodeB,
wireless access
gNO. EPC,
EPC, etc.)
gNB,
16.
Systems, with its
LTE/LTE-R B·
Mobile Systems,
Based
its various
16 LTE/LTE-R
eel Mobile
derivatives
including rural
derivatives including
rural &
& disaster
communications,
disaster communications,
Macro &
Macro
& Micro
Micro eNode
C-RAN
eNode 8.
Cells, EPC,
Small Cells,
EPC, NIB
B, Small
NIB C-RAN
BBU
LTE/LTE-R/4.5 GI
G/ 55 G
BBU and
and RRH
RRH ,LTE/LTE-R/4,5
based broadband
broadband
G based
wireless
wireless access
(eNodeB, gNB, EPC, etc.)
access systems
systems (eNodeB,
Wi -F i based
17.
ba ed broadband
17. Wi-Fi
wireless access
broadband wireless
access systems
systems
(Including
Access Point,
(Including Access
Block, Core Block),
Point, Aggregation
Aggregation Block,
Integrated
Integrated Broadband
Broadband system
system

1.
1.
2.
2.
3.
3.
4.
4.
5.
5.

PMI
PMI LC
LC
100
100 65
65
50
55
55
50
50
50 55
55
50
50
55
55
100
100 55
55

Year
Year
2019-20
2019-20
onwards
onwards
PMI
PMI LC
LC
100
100 65
65
50 60
50
60
50 60
50
60
50
50 60
60
100
100 60
60

100
100
100
lOO

65
65
45

100
100
100
100

65
65
50
50

50
50
100
100

50
50
65
65

50
50
100
100

55

65
65

50
50
100
100

55
55
55
55

50
50
100
100

60
60
60
60

100
100

55
55

100
100

60
60

100
100

55
55

100
100

60
60

50
50

55
55

50
50

60
60

50
50

55
55

50
50

60

so
50

45
45

50
50

50
50

50
50

50
50

50
50

55
55

Year
Year
2018-19
2018-19

I

<!-- page 6 -->

- - - - - - - - - - - - - - - ------Page
Page 6
6 of
of 12
12

M icrowave Radio
Radio systems
systems (IP/Hybrid),
(IP/Hybrid), Mobile
Mobile Front
Front haul
haul
18.
1 8. Microwave
BBU
Rl. FlexE.
NGFI)
BBU and
and RRH
RRH (CPR
(CPRI,!, eCI
eC PRI,
FlexE, Ro.E,
RoE, NG
FI)
1 9. Software
19.
Software Defined
Defined Radio,
Radio, Cognitive
Cogn itive Radio
Radio systems
systems
20.
20. Repeaters
IBS, and
and Distributed
Distributed
Repeaters (RF/RF-over-Optical),
(RF/RF-over-Optical), !BS,
Antenna
A ntenna system
system
21
Satellite based
21 .. Satellite
VSAT Disaster
ba ed systems
-Hubs, VSAT
Disaster
systems -Hubs,
Communication
Communication Systems
Systems etc.
etc.
Copper access
access systems
systems (DSL/DSLAM),
(DSL/DSLAM), high-speed
high-speed xDSL
xDSL
22. Copper
22.
(G.fast)
(G.fast)
23
Network Management
Management systems
systems (NMS) with
23.. Network
with i1s
its various
various
derivatives
derivatives
24 Security
Security and
and Sur
Surveeillance
Communication Systems
24.
Systems
i l lance Communication
(video
(video and
and sensors
sensors based)
based) including
including Perimeter
Perimeter Security
Security
Systems
Systems
25 . Optical
Optical Fiber
Fiber
25.
Optica
l
Fiber
Cable
Optical
Fiber
Cable
26.
26.
27.
(Including
Power)
27. Telecom
Solar Power)
Telecom Power
Power System
System (Inc
ludi ng Solar
28. Telecom
Telecom Batteries
Batteries (Lead
( Lead Acid
Acid & Li-ion)
Li-ion)
28.
29. IP
29.
phones // IP
IP audio
audio phones
IP video
video Phones/
Phones / Analog
Analog adaptor
adaptor
30.
SDN
Software
Controllers,
NVP
and
CNF
software
30. SDN Software Control lers, NVF and CNF software
Telecom Cloud
Cloud infrastructure,
infrastructure, Telecom
Telecom Data
Data centers
centers
31
31 .. Telecom
way Analog/Digital
Analog/Digita l radio
radio including
i ncluding Walkie-Talkie
Walkie-Talkie &
32
32.. 22 way
Mobile
Mobile Radio
Radio
Batteries
of 2 way
Batteries
of
radio including
including
way Analog/Digital
Analog/Digital radio
33.
33.
Walkie-Talkie
Walkie-Talkie
ng System
Fiber Monitori
Monitoring
System
34.
34 . Fiber
M2M/IOT
Subsystems
JOT Subsystems
35.
35. M2M/
Telecom Services/Works
Services/Works
36.
36. Telecom

100
1 00

50
50

100
1 00

55
55

50
50
100
1 00

50
50
55
55

50
50
100
1 00

55
55
60
60

50
50

35
35

50
50

40
40

50
50

50
50

50
50

55
55

100
1 00

65
65

100
1 00

65
65

100
1 00

35
35

100
1 00

40
40

50
50
75
75
50
50
50
50
50
50
50
50
50
50
50
50

50
50
50
50
50
50
50
50
35
35
50
50
35
35
50
50

50
50
75
75
50
50
50
50
5500
5500
5500
50
50

50
50
55
55
55
55
55
55
40
40
5555
40
40
55
55

50
50

40
40

50

45
45

50
50
50
50
100
1 00

50
50
50
50
70
70

5500
50
50
100
1 00

55
55
55
55
70
70 �

PMl
(of ltotal
tal quantity
being procured)
pro ured) for
PMI =Minimum
=Minimum preferen
preference in
in % (of
quantity being
for Make
Make in
in India
I ndia Telecom
Telecom
Products,
Products, Services
Services or
or Work
Works as
as indicated
indicated against
against each
each 'finnncial
financial year
year
LC
ontent as
as aa per
entage of
01al Bill
rial (cost
(co t of
pr duct ion)
M inimum Local
LC =
= Minimum
percentage
of 1total
B i l l of
of Mat
Material
of product
ion) to
to
Local Content
qualify
lec m Products,
Products Services
or Works
·h financial
financial
qual i fy aas Make
Make in
in India
India Te
Telecom
Services or
Works aas indicated
i ndicated against
against ea
each
year
year

<!-- page 7 -->

--

Page
Page 7
7 of
12
of 12

Table-B
Table-B
Main Inputs /stages
Main
for manufacture
/stages for
manufacture of
telecom products
prod ucts &
of telecom
& conditions
inputs to
conditions for the inputs
be
qualified as Local Content
be qualified

Main Inputs
Inputs /stages
Main
/stages for
for manufacture
of
man ufactu re of
telecom prod
ucts **
telccom
>roducts

lI ) Design
Design
(a)
(a) Hardware
H ardware design
design
(b) Software
Software Design
Desi gn &
& Development
Development

2)
Components
2) Compon
nts
a lmegrated
(a)
Integrated chips
(1Cs) -- Processor,
chips (!Cs)
Processor,
M
mory etc.
Memory
etc..
(b)
(b) Active
com ponents -- Transistors,
Acti e components
Transistors,
Diodes etc.
Diodes
(c)
(c) Passive
Passive Components
Com ponents -- Resistors,
Resistors,
apac itors, Inductors
etc.
Capacitors,
Inductors etc.
3) PCBs
PCBs
3)
(a) PCB
PCB Fabrication
Fabrication
(b)
(b) PCB
PCB population
opulation lusing components
omponents
4)
h
4) Cable:/
Cables/Chassis
etc.
etc.
(a)
Ch,
(a) Chassis
(b) Cables
(b.
'ables
(c)
(c) Rack
Racks
(d) Heat sinks
(e) Enclosures
5)
5) RF
RF Com ponents/Subsystem
ubsystem
Duplexers/Fi l ters
(a) Duplexers/Filters
(b)
Antenna
(b) Antenna

C
Conditions
for the
the inputs
inputs to
to be qualified
nclition for
as
as Local
Local Content
Content

The
maximum Local
The maximum
Local Content
Content (LC)
(LC)
percentage for
be
can be
which can
Design which
for Design
percentage
claimed
by aa Local
claimed by
Local manufacturer
manufacturer for
for the
the
tclccom products
in-house/in
on in-house/in
telecom
products based
based on
country
incurred/amortized
R&D costs
costs incurred/amortized
country R&D
to
to create
Table-C
in India
per Table-C
IPR in
as per
are as
create IPR
India are
subject
condition that:
that:
subject to
to the
the condition
(a)
The Intellectual
(a) The
Property Right
Intel lectual Property
Right
(IPR) resides
(IPR)
India for
in India
for
resides in
Hardware Design,
Hardware
Design,
Copyright is
in India
is in
The Copyright
(b) The
India for the
the
soft.war
Designn &
software Desi
Devel ment.
& Development.

Manufactmed in
i n India
Manufactured
India

India
in India
Manufactured in
Manufactured

I ndia
i n India
Manufactured in
Manufactured

India
in India
Manufactured in
Manufactured

The upper
l i m it of
cei ling limit
The
upper ceiling
Domestic
of Domestic
Local Content
(LC) for
Assembly/
for Assembly/
Local
Content (LC)
Integration/
i n respect
Testing in
of the
respect of
Integration/ Testing
products lIisted
in Tablc-C
telecom products
Table-C
telecom
isted in
would be
would
be II 0%
the total
0% of
of the
total product
product Bill
Bill of
of
Materia
and 36)
25,26
Materiall (e
(except
·c t S. No.
No. 25
,26 and
*• The
of the input/stage
i nput/stage as mentioned above. While
While ca
incl ude some/all
productmay
The prouuct
may include
ome/a ll ofth_e
calculating
lculating
only tho
be calculated
inputs/stages w
calcu lated which
those inputs/stage
only
\ ili l ll be
which are
i nvolved in
i n the manufacturing of these
are involved
telcc Ill produ
telecom
products,
t .
6)
6) Assembly/lntegrat
Assem bly/I ntegration/Testing"
ionrr sting;:

# IInn case
#
case aa system
subsystem isis merely assembled // integrated
its subsystem
of its
system of
integrated // tested,
actual
then actual
tested, then
Local
1 0% on!
shal l be
to 10%
Local Content
Content shall
be taken
taken as
ns uup1 to
of ssystem
cost of
the cost
of the
only of
stem // sub
subsystem.
yslem.

<!-- page 8 -->

Page
Page 88 of
of 12
12

Table-C
Table-C
Maximum ceiling for Design as Local Content out of total LC for Telecom Equipment
SI.
SI.

No.
No.

II
22
33
44
5
66
77
88
99
10
10
11
II
12
12

13
13
14
14
15
15

16
16

17
17
18
18
19
19

20
20

21
21

Telecom
Telecom equipment
equipment Description
Description

Maximum
ceiling
Maximum ceiling
Design as
as
for
for Design
Local
Content out
Local Content
out
of
of total
total LC
LC
Encryption/UTM
platforms (TOM
55
Encryption/UTM platforms
(TDM and
and IP)
I P)
55
40
40
I P/MPLS Core
Core routers/
routers/ Edge/
Edge/ Enterprise
Enterprise Router
Router
IP/MPLS
40
40
Mnnaged
Leased line
Notwork equipment
equipment
Managed Leased
l ine Network
40
Ethernet
40
Hubs
Ethernet Switches
Switches (L2
(L2 and
and L3),
L3), Hubs
40
IP
based Soft
-W
I P based
Soft Switches,
Switches, JMS,
IMS, Unified
Unified Communication
Communication Systems
Systems
45
45
Wireless/Wireline
Wireless/Wireline PABXs
PABXs I/ IP
I P PBX
PBX & / Media
Med ia Gateways
Gateways
CPE
points and
30
Media
CPE (including
(including Wi-Fi
Wi-Fi Access
Access points
and Routers,
Routers, Media
30
Converters), 2G/3G/4G/L
2G/3G/4G/LTE
Modems, Leased-line
Leased-l ine Modems,
Modems,
Converters),
TE Modems,
NFV/SDN
CPE
NFV/SDN CPE
35
35
Set-Top
Set-Top Boxes
Boxes
SDH/Carrier-Ethernet/MPLSSDH/Carrier-Ethernet/MPLS- TP/
TP/ Packet
Packet Optical
Optical Transport
Transport
45
45
equipment/
systems
equipment/ PTN/
PTN/ OTN
OTN systems
DWDM/CWDM
DWDM/CWDM systems
systems
40
40
40
40
GPON
NG-PON2 equipment
luding ONT
GPON I/ XGS-PON,
XGS-PON, NG-PON2
equipment (in
(including
ONT and
and
OLT)
OLT)
40
40
Optical/SDH/PDH
Connects/ OTN
Cross-connects and
Optical/SDH/PDH Cross
Cross Connects/
OTN Cross-connects
and
optical
optical MUX,OADM
MU X,OADM
40
40
Small
based Base
with its
G/3 G
Small size
size 22 G/3
GSM based
Base Station
Station Systems,
Systems, with
its
G GSM
various
disaster response,
response, Macro
Macro
& disaster
various derivatives
derivatives including
including rnral
rural &
&
s, N
NIB,
I B, C-RAN
C-RAN BBU
BBU and
and RRH
RRH
M icro BTS,
BTS, Small
Small Cell
Cel ls,
& Micro
40
40
22 G/3
based Base
with its
its various
G GSM
GSM based
Base Station
Station Systems,
Systems, with
various
G/3 G
derivatives
derivatives including
including rural
rural & disaster
di saster response.
response. Macro
Macro &
M icro
& Micro
BTS,
BTS, Small
Small Cells,
Cel ls, NIB,
N I B , C-RAN
C-RAN BBU
BBU and
and RRH
RRH
40
40
Small
TE/LTE-R Based
Small Size
Size L
LTE/LTE-R
Based Mobile
M obile Systems,
Systems, with
with its
its various
various
derivatives including
including rural
rural & disaster
derivatives
disaster communications,
communications, Macro
M acro
&
Cells,
EPC, NIB
Micro eNode
eNode B,
B, Small
Small Cel
ls, EPC,
NIB C-RAN
C-RAN BBU
BBU and
and
& Micro
RRH
TE/LTE-R/4.55 G/
GI 5
based broadband
broadband wireless
RRH ,L
,LTE/LTE-R/4.
G based
wireless access
access
5G
systems
systems (eNodeB,
(eNodeB, gN
gN B,
B, EPC,
EPC, etc.}
etc.)
35
35
its various
various
with its
Mobile Systems,
LTE/LTE-R
LTE/LTE-R Based
Based Mobile
Systems, with
derivatives
derivatives including
including rural
rural &
disaster communications,
communications, Macro
Macro
& disaster
&
&& Micro
Micro eNodc
eNode B,
B, Small
Small Cells,
Cells, EPC,
EPC, NIB
NIB C-RAN
C-RAN BBU
BBU and
and
RRH
TE/LTE-R/4.5 G/
GI 5 G
based broadband
broadband wireless
access
RRH ,L
,LTE/LTE-R/4.5
G based
wireless access
gNB,
systems
systems (eNodeB,
(eNodeB, gN
B, EPC,
EPC, etc.)
etc.)
35
35
( I nclud i ng
Wi-Fi
based broadband
Wi-Fi based
broadband wireless
wireless access
access systems
systems (Including
I ntegrated
Access Point
Access
Point. Aggregation
Aggregation Block,
Block, Core
Core Block),
B lock), lntegraled
Broadband system
Broadband
system
35
35
Microwave
Radio systems
Microwave Radio
systems (IP/Hybrid),
(IP/Hybrid), Mobile
Mobile Front
Front haul
haul
BBU
and
RRH
(CPRI,
eCPR
I.
FlexE,
Ro
E,
NGFI)
BBU and R RH (CPR I , eCPRI, FlexE, RoE, NGFI)
35
35
Software
Cognitive Radio
Software Defined
Defined Radio,
Radio, Cognitive
Radio systems
systems
40
40
Repeaters
(RF/RF-over-Optical), II BS,
Repeaters (RF/RF-over-Optical),
B S, and
and Distributed
Distributed Antenna
Antenna
system
system
25
25
Sate
Ilite based
based systems
T Disaster
Dis,1 ter Communication
Satellite
systems -Hubs,
-Hubs, VSA
VSAT
Communication
Systems etc.
etc.
Systems
0

<!-- page 9 -->

Page
Page 9
9 ofU
of 12

22
23
24
225
26
26
27
27
28
28
29
29
30
30
31
31
32
32

33
33
34
34
35
35

36
36

Copper access systems (DSL/DSLAM), h igh-speed xDSL
( G . fast)
Network Management systems (NMS) with its various
derivatives
Security and Surveil lance Communication
omrnunicatio11 Systems (video and
rimeter Securil
stems
sensors based) i ncluding, Perimeter
Security Systems
Opt ical Fiber
Optical Fiber Cable
Telecom Power System ( I nclud i ng Solar Power)
Telecom Batteries ( Lead Acid & Li-ion)
IP aud io phones / I P video Phones / Analog adaptor
S DN Software Control lers, N V F and CNF software
ata centers
C loud infrastructure, Data
centers
2 way A nalog/Digital radi,o
Walkie-Talkie &
& Mobile
radio including
i nclud i ng Walkie-TaJkie
Radio
Batteries
way A nalog/Digital radio
rndio including
i ncluding WalkieWalkieBatteries of
of 22 way
Talkie
Talkie
Fiber Monitoring System
M2M/10
M2M/1OT Subsystems
Telecom Services/Works

35
50
50
30
30
N IL
IL
N IL
IL
30
30
30
30
I5
15
15
15
20
20
30
30
30
30
35
35
35
35
NIL
NIL

�

-

<!-- page 10 -->

of 12
10 of
Page 10
12
Page

Form
Form 11
Telecom Product,
Local Content
Content (LC)
(LC) for
Product,
regarding Local
for Telecom
Certification regarding
Self Certification
Format
for Self
Format for
Works
Services
Services or
or Works
Date:
Date:

of
Resident of
_ _ _ _ _ _ _ _ _ , Resident
D/o~ W/o
S/o, D/o,
W/o_
S/o,
under:
hereby solemnly
do hereby
___________
affirm and
and declare
solemnly affirm
as under:
do
declare as
Telecom1i1un
Department of
of Department
ications,
l ecommun ications,
by the
to abide
That
of Te
conditions of
and conditions
terms and
the terms
abide by
agree to
That II agree
dated ........ ...
No: ........... dated
Notification
vide Noti
fication No:
Government
ssued vide
Government oflndia
of India iissued
� � � � � � � � � ��

belieff
of my
to best
hereinafter iiss correct
furnished hereinafter
the info1mation
That
correct to
information furnished
knowledge and
best of
and belie
my knowledge
That the
any
or
procuring entity
before the
produce relevant
undertake to
and
to produce
the procuring
relevant records
entity or any other
records before
other
and II undertake
Depa1tment of
the Department
by the
nominated by
of India
India
Government of
Telecommunications, Government
of Telecommunications,
so nominated
authority so
authority
LC..
the LC
the purpose
for
of assessing
purpose of
assessing the
for the
has
Product/Services/Works has
Telecom Product/Services/Works
inputs which
which constitute
said Telecom
constitute the
the said
LC for
for all
all inputs
That the
the LC
That
therein.
made therein.
claims made
of the
correctness of
for the
responsible for
by me
am responsible
been
the claims
the correctness
and II am
me and
verified by
been verified
LC of
That
Telecom Product/Services/Works
Product/Servi ces/Works mentioned
the Telecom
mentioned herein
of the
herein is
is
the LC
of the
event of
That in
the event
in the
of
based on
norms, based
LC norms,
and not
found to
be inco1Tect
to be
incorrect and
prescri bed LC
found
the prescribed
meeting the
not meeting
on the
assessmen t of
the assessment
by the
an
Telecommunications, Government
of Telecommunications,
India
Department of
Government of
nominated by
of India
the Department
so nominated
authority so
an authority
in
Make
to
(Preference
Procurement
Public
of
(f)
under clause
be liable
will be
and lI will
liable as
clause 99 (f) of Public Procurement (Preference to Make in
as under
and
India)
India) Order
Order 2017.
201 7.
for aa
Company's record
claim for
my claim
regarding my
infonnation regarding
maintain all
to maintain
1I agree
record for
the Company's
in the
all infonnation
for LC
agree to
LC in
authorities.
statutory
any
to
verification
for
available
this
make
shall
and
years
2
period
statutory
authorities.
avai
any
for
make
verification
lable
to
this
shall
years
and
2
period of
of
i.i .
ii.
ii.
iii.
iii.
iv.
iv.
v.
v.
vi.
vi.
vii.
vii.
viii.
viii.
1x.
ix.
x.
x.
xi.
xi.

xii
xii..
xiii.
xiii.

unit
Office, Manufacturing
Local supplier
Name
Name and
and details
details ooff the
the Local
(Registered Office,
supplier (Registered
Manufacturing unit
entity)
legal entity)
location,
of legal
location, nature
nature of
is issued
on which
Date
certificate is
issued
this certificate
which this
Date on
produced
which the
for which
is produced
the certificate
certificate is
Telecom Product/Services/Works
Product/Services/Works for
Telecom
the ce1tificate
whom the
to whom
Procuring
is furnished
furnished
Procuring agency
certificate is
agency to
LC claimed
of LC
Percentage
Percentage of
claimed
manufacturer
of the
unit of
details of
contact details
the unit
of the
the manufacturer
and contact
Name and
Name
product
the product
of the
Sale Price
Price of
Sale
the product
of the
Price of
Ex-Factory
Ex-Factory Price
product
Freight, insurance
handling
and handling
insurance and
Freight,
Material
Total
Total Bill
Bill of
of Material
the Telecom
manufactLIJ'c or
used for
of inputs
value of
total cost
and total
List
cost value
inputs used
List and
for manufacture
o f the
Telecom
Product/Services/Works
Product/Services/Works
LC
locally sourced.
are locally
which are
Please attach
attach LC
sourced. Please
of inputs
List
total cost
cost of
inputs which
and total
List and
in-house.
not
is
input is not in-house.
the input
from local
certificates from
certificates
if the
local suppliers,
suppliers, if
indirectly
which are
inputs which
of inputs
and cost
directly or
imported, directly
or indirectly
are imported,
List and
List
cost of

and on
For
For and
of
on behalf
behalf of

ame of
firm/entity)
of firm/entity)
-----------(_( Name
s

Directors)
Board of
by the
be duly
Authorized signatory
of Directors)
the Board
authorized by
Authorized
(To be
duly authorized
signatory (To
No. and
Designation and
Name, Designation
and Contact
Contact No.
<Insert
and date>
date>
<lnsert Name,

<!-- page 11 -->

Page
of 12
Page 11
11 of
12

SI
No.
SI No.

Acronyms
Acrn
nyms
2/3/4/4.5/5
2/3/4/4.
5/5 G
G

1.
1.
BBU
BBU
2.
2.
BIS
BIS
3.
3.
BTS
4. BTS
4.
C-DoT
5.
5. C-DoT
CN F
6.
6. CNF
CPE
7. CPE
7.
CPRI
CPRI
8.
8.
C-RAN
9. � � C-RAN
9.
CS
10.
1 0. cs
css
11
1 1 .. css
CWDM
12.
1 2. CWDM
DIPP
1 3. DIPP
13.
14. DoT
DoT
14.
DSL
15.
1 5. DSL
DSLAM
16.
16. DSLAM
DWDM
17.
1 7. DWDM
eCPRI
18.
1 8. eCPRI
e-node BB
1 9. c-nocle
19.
EPC
20.
20. EPC
FlexE
21
21 . FlexE
G. fast
fast
22 . G.
22.
23 .
23.
24.
24.
25.
26.
26.
27
27..
28.
28.
29..
29
30.
30.

31
31 ..
32.
32.
33..'
33
34,
34
35.
36.
36.

i;tN
gN B
B
GPON
GPON

GR

GSM
GSM
TBS
JBS
IC
IC
IMS
IMS
!OT
1OT
IP
IP
IPR
IPR
IR
IR

L-2
L-2
L-3
L-3
LC
LC
Li-ion
Li-ion
LTE
LTE
LTE-R
LTE-R
M2M
M2M
M PLS
MPLS
MPLS-TP
M PLS-TP

37.
38.
38.
39.
39.
40.
40.
41 ..
41
42.
42.
MUX
43. MUX
44.
44.

45.
45.
46.
46.
47.
47,
48.
48.

NFV
NEV

NGFI
NGPON2
NG-PON2
NIB
NIB
NMS
NMS

th e no
1 ,ca f1011
L'
ts t ooff Acronyms
ffi
List
Acronyms use
usedrl.m
in the
notification

Expansion
Expansion
Second(fhird/Pou
rth/4.5/Piftfthh Generation
Second/Third/Fourth/4.5/Fi
Generation
Base
Band Unit
Base Band
Unit
Bureau of
Bureau
of Indian
Indian Standard
Standard
Base
Base Transceiver
Transceiver Station
Station
Centre for
for Development
Development ofTelemalics
of Telematics
Centre
Container
/Cloud Network
Container /Cloud
Network Function
Function
Customer Premise
Customer
Premise Equi.pmenl
Equipment
Common Public
Public Radio
Radio Ilnterface
Common
nterface
Cloud/Ce ntrali zed Radio
Radio Access
Cloud/Centralized
Access Network
Network
Central
Central Scheme
Scheme
Central Sector
Central
Sector Scheme
Scheme
Coarse
Coarse Wavelength
Wavelength Division
Division Multiplexing
Multiplexing
Department
al Pol
Policy
Depart ment of
of Industri
Industrial
icy and
and Promotion
Pro1t1otlon
Depa
rtment ofTe.lecommunications
Department
of Telecommunications
Digital
Digi tal Subscriber
Subscriber Line
Line
Di
gital Subscriber
Access Mu
Digital
Subscriber Line
Line Access
Multiplexer
ltiplexer
Dense
length Division
Dense Wave
Wavelength
Division Multiplexing
M ultiplexing
ePublic
Radi,o lnterface
e- Common
Common Publ
ic Radio
Interface
Evolved node
Evolved
node B
B
Evo
lved Pocket
Core
Evolved
Pocket Core
Flexible
Flexible Ethernet
Ethernet
ITU-T
ries recomm
ndations for
ITU-T G
G se
series
recommendations
for Fast
Fast Access
Access to
to Subscribe
Subscri berr
Termina
ls
Terminals
Next Generation
B
Next
Generation Node
Node B
Gi~abit
Gigabit Passive
Passive Optical
Optical Network
Network
Generic
Generic Requirements
Requirements
Global
Global System
System for
for Mobile
Mobile
lntef;trated
Build
in.P: System
System
Integrated Bui
lding
l1nef;trated
Integrated Chip
Chip
IP
ltimed ia Subsystem
IP Mu
Multimedia
Subsystem
Internet
Internet of
of Things
Th i ngs
Protocol
IInternet
nternet Protocol
Intellectual
Property Right
Ri ght
Intel lectual Property
Int
erface Requi
Requirement
Interface
rement
Layer Two
Layer
Two
Layer
Layer Three
Three
Local
Local Content
Content
Lithium-ion
Lithium-ion
L011g Term
Evolu tion
Long
Term Evolution
Long
Long Term
Term Evolution-Railway
Evolution-Railway
Machine
Machine lo
to Machine
M achine
Multiprotocol
Multiprotocol Label
Label Switch
Switching
ingMultiprotocol
Multiprotocol Label
Label Switching-Transport
Switching-Transport Profile
Profile
Mul1iplexe r
Multiplexer
Network
Function Virtual
Network Function
ization
Yinuallzalion
Next
Generation Fronthaul
Front.haul Interfaces
Next Generation
Interfaces
Next Generat
ion Gigabit
Next
Generation
Gigabit Passive
Passive Optical
Optical Network
Network 22
Network in
Network
in Box
Box
Network
Network Management
Management Software
Software

<!-- page 12 -->

Page
Page 12
12 of
of 12
12
49.
49.

50
50..
51
51 ..
52
52 .
53.
53.
54
54.
55.
55.
56..
56
57.
57.
58
58..

NVF
NVF
OADM
OADM
OLT
OLT
ONT
ONT
OTN
OTN
PABX
PABX
PBX
PBX
PCB
PCB
PDH
PDH
PMA
PMA

PMI
59
59.. PMl
PPP-M Il
60
60.. PPP-MU
PTN
61
6 1 .. PTN
R&D
62.
62. R&D
63.
63.
64
64..
65.
65.
66
66..
67.
67.
68.
68.
69.
69.
70.
70.
71
71 ..
72.
72.
73
73..
74
74..
75
75..
76..
76
77
77..

Copy to:
to:
Copy
1I..
2.
2.
3.
3.
4.
4.
5.
5.
6.
7.
7.
8.
8.

RF

RRI-1
RRI

SDH
SDH
SON
SDN

STQC

TDM
TDM
TEC
TEC
TEPC
TEPC
TSEC
TSEC
USOF
USOF
UTM
UTM
VSAT
VSAT
Wi-Fi
Wi-Fi
XDSL
XDSL
XGS-PON
XG S-PON

Network Vi,tual
Function
Network
Virtual Function
Optical Add-Drop
Optical
Add-Drop Multiplexer
Multiplexer
Optical
Optical Line
Line Terminal
Terminal
Optical
Network Terminal
Optical Network
Terminal
Opticol
Optical Transport
Transport Network
Network
Private
Exc hange
Private Auto
Auto Branch
Branch Exchange
Private Branch
Branch Exchange
Exchange
Private
Printed
Board
Printed Circuit
Circuit Board
Plesiochronous
Plesiochronous Digital
Digital Hierarchy
H ierarchy
Preferential
Preferential Market
Market Access
Access
Preforencc
Preference for
for Make
Make in
in India
India
Public
to Make
Make in
in India)
India)
Public Procurement
Procurement ((Pt•eference
Preference to
Packet
Network
Packet Transport
Transport Network
Research
and Development
Research and
Development
Radio
Radio Frequency
Frequency
Remote Radio
Radio Head
Head
Remote
Synchronous
Synchronous Digital
Digital Hicrnrchv
H ierarchy
Software
Network
Software Defined
Defined Network
Standardisation Testing
Quality
Standardisation
Testing and
and Qual
ity Certification
Certification
Ti_
me Division
Division Multiplexing
Mult iplexing
Time
Telecommunication
Centre
Telecommunication Engineering
Engi neering Centre
Telecom
Telecom Exl)or·t
Export Pron10tion
Promotion Council
Council
Technical
fi caLe
Technical Speci
Speci flcal'ion
fication Evaluation
Evaluation Ceni
Certi ficate
Universal
Obligation Fund
Universal Service
Service Obligation
Fund
Unified
Unified Threat
Threat Management
Management
Very
Small
Aperture
Terminal
Very Sma l l Aperture Terminal
Wireless
Fidelity
W ireless Fidelity
different
Digi1al Subscriber
different variations
variations of Digital
Subscriber Linc
Line
10
iga bit Syrnmetrica
Network
Passive Optical
Optical Network
1 0 Ci
Gigabit
Symmetrica Il Passive

--<----~
<.A)
(Amit
(Amit Yadav)
Yadav)
Joint
Joint Secretary
Secretary to
to the
the Government
Governmen t of
of India
India

All
Departments of
of Government
Government ooflndia.
f India.
All Ministries/
Ministries/ Depaztmenls
Cabinet
NITI Aayog
PMO // NITI
Aayog // Comptroller
Comptroller &
& Auditor
Cabinet Secretariat/
Secretariat / PMO
Auditor General
General of
of India.
I nd ia.
PS
to Hon'ble
of Communication
PS to
Hon'ble Minister
Minister of
Comm unications..
PPS
PPS to Secretary
Secretary (Telecom)/Special
(Telecom)/Special Secretary
Secretary (T)/Administrator,
(T)/Administrator, USOF.
USOF.
PPS to
to Member
PPS
Member (T)/Member(S)/Member
(T)/Member(S)/Member (F)/Advisor
(F)/Advisor (T)/Advisor
(T)/Advisor (0).
(O).
Sr.
Bhawan, New
New Delhi.
DDG, TEC,
TEC, Khurshid
Khurshid Lal
Lal Bhawan,
Delhi.
Sr. DOG,
DDsG.
JS (A)/JS
(T)/CVO/AII
JS
A)/J (T)/CV
/AJI DDsG.
All
U /Autonom us bodies
bodies under
All PPSUs/Autonomous
under Department
Department of
of Telecommunications.
Telecommun ications.

-c..----~

(Amit
(Amit Yadav)
Yadav)
Joint Secretary
Secretary to
to the
the Government
Government of
of India
India
