---
doc_id: "d18a4cf5bac2b42a"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/1e029edb25dd0278e3af47e5b4289e05.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Guidelines dated 05.04.2021"
date: "2022-10-06"
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fe0f687b22f561d5"
---

<!-- page 1 -->

F .No.: 18-04/2018-IP(Pt.VI)
Ministry of Communications
Department of Telecommunications
*****

New Delhi, 05 April, 2021
GUIDELINES FOR FUNDING UNDER SUB SCHEME "SETTING UP OF DIGITAL
COMMUNICATION INNOVATION SQUARE (DCIS)" UNDER CHAMPION SERVICES
SECTOR SCHEME
**********************************************************************************************

1.

Name of the Scheme:
Digital Communication Innovation Square (DCIS) under Champion
Services Sector Scheme (CSSS).

2.

Objectives: The objectives of the Schem~ is as under:­

a)

b)

c)

d)

e)
3.

To promote the ecosystem for research , design , development, proof of
concept testing , IPR creation , pilot project and manufacturing i.e.
complete value chain to make India a global hub for production of
telecommunication equipment and a centre for digital communication
services .
To develop and establish standards to meet national requirements and
participate in international standardization bodies to contribute in
formulation of global standards , thereby making India a leading nation
in the area of international telecom standardization .
To promote India specific application development that matches with
behavioral pattern of the masses and adds value to their day-to-day
activities both economic and social.
To create synergies among the Academia , Research Institutes, Start­
ups and Industry for capacity building and development of a balanced
telecom ecosyste·m by organizing workshops/seminar/ webinar etc. for
sharing their views , plans , expectations and concerns in a free and
constructive manner.
Bridge the gap between R&D and commercialization

Focus Areas of the sub-scheme:

Communication services in India are mainly provided by imported
equipment and technologies . The scheme will promote indigenous
innovation
and
incubation
of
future
technologies
and
their

Page 1of18

<!-- page 2 -->

deployment/manufacturing thereof, resulting value addition for the Indian
Telecom Sector. The scheme will be focused mainly in the following areas :
(i)

LTE . Advanced , 5G and future generation access technologies ,
Software Defined Networks (SDNs) and Network Function
Virtualization (NFV), IOT/ M2M , the cloud and data analytics .

(ii)

Backhaul radio and communication technologies ,

(i ii)

Core and edge routers , Soft switches , Ethernet Switches , xDSL ,
modems , routers , dongles, data cards , mobile handsets, wireless
access points , mobile handsets etc.,

(iv)

Security and surveillance equipment, sensors,

(v)

Convergence of telecom , IT and broadcasting technologies ,

(vi)

Over-the-top (OTT) services as drivers for penetration of broadband
services

(vii)

Green and energy efficient technologies I solutions for the telecom
sector and

(viii)

Any other area considered commercially relevant in future .

The main idea of the scheme is translation of research into technology
(product/process) but not to carry out open ended fundamental research .
Investigations must lead to innovation or new product/process ready for
demonstration or pilot scale deployment (not only publication/ patent) .

4.

Name of the Implementing Agency:
Telecom Centre of Excellence (TCOE) India .

5.

Deliverables:
Impact of this Scheme will be measured in terms of :­
(i)

Pilots of innovative ideas converted into full scale operation .

(ii)

Number of Start-ups , MSMEs providing
culminating in getting full fledged orders .

Pa ge 2of18

educational

order,

<!-- page 3 -->

..
<

'

6.

Project Duration:

The duration of the scheme shall be for 3 years i.e. 2019-20 to 2021-22.
7.

Budgetary Outlay:

A total Rs .104 crore from the budgetary support under the Champion Service
Sector fund will be earmarked for the scheme.
7.1

7.2

The scheme has following two components :­

(a)

Project Funding - Rs .87.5 crore will be given for project funding over a
period of 3 years . For this the applicant showing capability, intent, and
promise to be able to produce functional prototypes or to productize
existing technologies will be awarded grants of up to Rs 2 crore strictly
based on a milestone basis .

(b)

Strengthening
of existing
innovation
infrastructures/incubation
centers/academic_institutions I industry institutions or programs with
total budget of Rs .16.5 crores .

The year wise I component wise budget estimate are as under:­
Year

2019-20
2020-21
2021-22
Total

Component
Project Funding
Strengthening of
Innovation cum
(Rs . Cr.)
Incubation Centre
(Rs. Cr)
2.50
15.00
7.00
37 .50
7.00
35 .00
16.50
87.50

Total
(in Rs.
Cr)

17.50
44.50
42.00
104.00

7.3
The year-wise details of disbursement of grant/conditional for component of
Strengthening of Innovation cum Incubation grant, as per EFC approval , are as under:
Year
First
( 1st)
Year

Total
Grant
Rs .2.50
Cr. (#)

Disbursement of Grant
a) 4 innovation/incubation centres will be identified to
strengthen them.
b) Rs . 50 Lakh per innovation/incubation centre will be given.

Page 3of18

<!-- page 4 -->

c) Rs 50 lakh shall be given to team of three [program
manager+2] (eligibility post-doc) to oversee the successful
functioning of projects of startups/SMEs running in these
identified 4 innovation/incubation centres.
Seco
nd
(2nd)
Year

Rs .7 .00
Cr(#)

Third
(3 rd)

Rs.7.00
Cr (#)

a) 6 innovation/incubation centres will be identified to
strengthen them.
b) Rs . 50 Lakh per innovation/incubation centre will be given .
c) Rs .50 lakh shall be given to team of three [program
manager+2] (eligibility post-doc) to oversee the successful
functioning of projects of startups/SMEs running i ~ these
identified 6 innovation/incubation centres .
d) Amount of Rs .3.50 Cr. shall be utilized for giving additional
telecom communication specific test equipments , specific
test instruments , jigs , fixtures etc.
- Same as in 2na year above -

year

# If any amount is remaining//left unutilized in the scheme 'Strengthening of existing
innovation/incubation centres ', then that amount will be adjusted/transferred/used
for project funding.

8.

Administrative set-up for implementation of the sub-scheme:

The sub-scheme will be implemented under the aegis of an Inter-Ministerial Apex
Committee . The Composition of the Inter Ministerial Apex Committee will be as
follows :­
I.

Additional Secretary, Telecom , DoT

Chairperson

II.

Joint Secretary, Telecom , DoT

Member

Ill.

One Member each from Industry, Academia , and
VC to be opted by the Chair

Members

iv.

Advisor (Technology) , DoT

Member

V.

Advisor (Finance) , DoT

Member

VI.

Member

vii .

Representative from NITI Aayog
Representative from Ministry of Electronics & IT

viii .

Executive Director, C-DOT

Member

IX .

Director IP

Member­
Convener

x.

Any other representative(s) from Central Government
Ministry/ Department/ Organization may be co-opted
with the approval of Chairperson
Page 4of18

Memb~r

Members

<!-- page 5 -->

9. Changes in the guidelines: Notwithstanding anything contained in the guidelines ,
any changes may be made in the guidelines with the approval of Secreatry(T) ,DoT.

Devendra Kumar Saini
ADG(IP)
Enclosures:
1.

Annexure-1 Standard Operating Procedure for Grant under Digital
Communication Innovation Square (DCIS) scheme .

2.

Annexure-11 Terms & Conditions for Grant-in-Aid .

Page 5of18

<!-- page 6 -->

Annexure-1
OPERATING PROCEDURE FOR GRANT
ATION INNOVATION SQUARE DCIS SCHEME
1.

UNDER

DIGITIAL

mentation Mechanism & Scope of Implementing Agency

The

E lndiawill implement the Scheme on behalf of the Department of Telecom .
menting Agency will work under the overall supervision of the Apex
and guidelines issued by the DoT.

2.

and responsibility of the Implementing Agency

role and responsibility of the of the Implementing Agency are as under :
2.1
2.1.1 A

echnical Expert Committee (TEC) will be constituted by Implementing Agency
onsultation with Department of Telecom to select beneficiary , recommend
ase of grants/continuity/extension/short- close , periodically steer and review
technical and financial progress of the scheme .etc.

2.1.2 D e diligence of beneficiaries that have received in principle grant approval from
th Apex Committee will be carried out by TEC .
2.1.3 T e due diligence process involves :­
•

Reconfirming eligibility

•

Legal , technical & financial due diligence

•

Confirming how application has tied up all resources : space , equipment,
manpower, advisors , incubation services , equipment etc.

•

Budget utilization plan (usually by providing quotations) ; other requirements of
ESC , if any
Finalization of milestones , budget and payment schedule ; defining clear
milestone targets that are easy to track .

2.2

igning Agreement

2.2.1

allowing due diligence , final grant approval to be provided by Apex Committee
o implementing agency
Page 6of18

<!-- page 7 -->

2.2.2 Aj agreement will be signed between implementing agency and the beneficiary,
defining t rms of association .

2.3

G ant Approval

2.3.1 Fwnd will be released into the dedicated no lien account created by the
b~neficiary for the purpose of this scheme .
2.3.2 F nd disbursement will commence against the milestones as stipulated at para
6 3.

2.4

r onitoring

CDnce the project begins , TEC will periodically monitor progress and review
project. / Beneficiary will submit periodic reports and utilization certificates in the
prescribed format to implementing agency.

3.

·inancial Support to Start-up and MSME

Wnder the scheme , financial support will be provided to those projects/ideas who
1
have r ached at least "Proof of Concept (PoC)" level. Financial support will be provided
to the eneficiary in form of grants. However, implementing agency shall work with other
ventur funds to get them more funding on mutually agreed entry-exit terms .
3.1

ligible expenditure for funding:

Since the focus of the program is to facilitate creating of prototypes and bringing
of pro !ucts /technologies to market, applicants will be encouraged to spend on :­
a) Research & Development
b) Prototyping
c) Testing , Trials and Piloting
W ile , expenses on following not permissible under the funding

a) HR manpower expenses
b) Power
c) Tools & Machineries
d) Office expenses

Page 7of 18

<!-- page 8 -->

3.2

Funding of Projects to be supported

DCIS would aim for supporting Startups/MSMEs/lnnovators to create prototypes
and/or commercialize products/solutions in the area of Telecom Sector.
4.

Eligibility Criteria

4.1

Eligible Beneficiaries :
4.1.1 Startups , as defined and recognized by Department for Promotion of
Industry and Internal Trade (DPllT) , Ministry of Commerce and Industry,
Government of India , working towards innovation , development or improvement
of products or processes or services , or if it is a scalable business model with a
high potential of employment generation or wealth creation.
4.1.2 Any Indian company incorporated under the Companies Act 1956/2013,
primarily a Micro, Small and Medium Enterprises (MSME) as defined in the
MSME Act , 2006 having over 51 % stakes by the Indian Citizen I NRI I OCI and
Head Quarter in India .
4.1.3 Individual Innovators will also be encouraged to apply (research &
academic institutions can use this category to apply). However, release of fund
shall be subjected to compliance of eligibility condition for either Startup or
MSME before agreement signing .

4.2

More than one organization can jointly submit the application in partnership with
consortium , registered societies & Academia

4.3

Collaboration with Academia I R&D Organization are highly encouraged

4.4

Every proposal must clearly identify a Project Lead (PL) who will take
responsibility for the technical and managerial aspects of the project execution . If
an application is selected for funding support, then its Project Leader will be
required to sign the project Agreement on behalf of the applicant(s) .

5.

Application Procedure

5.1
Implementing Agency would be creating a dedicated complete website (e .g.
www.dcis.gov.in ) for this purpose . This website will be complete website for DCIS ·
scheme and support the activities such as Online Application Submission , Project
Status Tracking , Fund Releases , Monitoring/Mentoring , Database of Digital
Communication Technology companies , Event Promotion , Partnership facilitation ,
Regulatory Information etc.

Page 8of18

<!-- page 9 -->

5.2
Ownership of any intellectual property generated by the beneficiary will accrue
sol ly to those participants . DoT has the first right of refusal for preferential access to
theJe technologies for product, go-to-market, and investment.
6.

Program Implementation Methodology

6.1

Selection & Funding Process

6.1.1

All applications will be Initially Scrutinized for the Eligibility Check
and completeness of Application by the Implementing Agency.

6.1.2

Eligible applicants will be considered for the 'Shortlist' by the
Implementing Agency.

6.1.3

Shortlisted applicants will be called to give a detailed presentation
to showcase their idea/product/solution to the TEC.

6.1.4

Recommended applicants by the TEC will undergo with Due­
Diligence process as stipulated at para 2.1.

6.1.5

After due diligence , final grant proposal along with Due-Diligence ,
will be presented by implementing agency to Apex Committee for
approval.

6.1.6

A funding agreement will be signed between implementing agency
and successful applicants .

6.1.7

Fund will be released into the dedicated no lien account created by
the successful applicants for the purpose of this scheme .

6.1.8

Fund disbursement will commence against the milestones of the
project as stipulated at para 6.3 .

6.1.9

Once the project begins , implementing agency through its Expert
Panel will periodically Mentor the project. Beneficiaries will submit
periodic reports and utilization certificates in the prescribed format
to implementing agency.

6.1.10

Implementing agency will Coach I Mentor the project during Project
Completion and two years post completion through its Expert panel.

6.1.11

Implementing Agency will help beneficiaries in Piloting , Testing and
Public Procurement.
Page 9of18

<!-- page 10 -->

6 .2

Indicative Evaluation Criteria
rrhe indicative evaluation criteria for applicants under the scheme are as follows :

S.
Criteria
No.

Details

1

Technical
Feasibility

2

Potential Impact

3

4

5

Indicative
Weightage(%)

Feasibility & reasonability of the
technical claims , methodology used/to
be used for validation , roadmap for
technology development
Market size , customer demographic &
the technology's effect on these

USP(s)
of
the
technology,
IP
associated
with
technology,
the
national importance (if any)
Utilization of technology to create a
Commercialization product/service , its position ing & value
Strategy
add ition for the intended customers,
plan
forgo-to­ market ,
challenges
expected
Technical & business expertise ,
Team
mentors
Novelty

Total

20

20
15

25

20
100%

Selected beneficiaries will be offered funding over a period of maximum 24
months in installments against agreed milestones .
6.3

Milestone based Fund releases

6.3.1 Successful applicants will be offered funding support in the form of a grant of up
to Rs. 50 lakhs I 2 Cr. fo r Startup and MSME respectively . The fund disbursement will be
milestone-based and will be released in 4 installments:
Installment
1st Installment
2nd Installment
3rd Installment
4th Installment

Milestone
Signing of Contract
Completion of 1st Milestone
Completion of 2nd Milestone
Completion of project & submission of
final report with prototype/product
(focusing on Technology Completion of
the project and outcome could be
Technical Success or Failure)
Page 10 of18

Release
40% of Total Grant
20% of Total Grant
20% of Total Grant
20% of Total Grant

<!-- page 11 -->

6.3.2 Timelines for milestones of the project shall be decided between the beneficiary
and Implementing Agency after due-diligence approval.

6.4 Monitoring
6.4 .1 A Project Monitoring Committee(PMC) shall be mandatorily required to be put in
place by the Implementing Agency before release of funds. The PMC will ensure
timely and proper implementation of the project without time and cost overruns .
6.4 .2 The PMC shall have a representative of the
Government of India.

Department of Telecom ,

6.4 .3 The Implementing Agency shall ensure that the PMC shall meet once in every
quarter and submit its report duly signed by the Head of the implementing
agency. This report will be used to review the progress of utilization of the funds
released and will also be taken into account while considering further release of
funds by the department.

7.

Fund Disbursement from DoT to Implementing Agency

7.1

Project Funding
7.1 .1 The funds shall be released to the Implementing Agency for the approved
projects in two or more equal installments
7 .1.2 The 1st installment will be released after approval is accorded to the
projects by the Apex Committee . Further installments may be released based on
the recommendation I ratification of Project Monitoring Committee (PMC) .
7.1.3 Release of further installments shall be subject to furnishing of complete
Utilization Certificate , report of the Project Monitoring Committee (PMC) and the
proof of matching contribution of the funds having been invested by the
Implementing Agency from its own or other sources on pari-passu basis as per
the approved cost sharing .
7.1.4 Apex Committee would approve the startups & MSMEs under the scheme
along with the approved amount of grant, and milestone details for each
7.1 .5 Upon approval of projects by the Apex Committee , Implementing agency
Page llof 18

<!-- page 12 -->

would communicate to the successful applicant and initiate the funding process .
7 .1.6 First installment of payment to be made available to successful applicants
within three weeks
7.1.7 Technical Expert Committee of Implementing Agency would approve each
milestone payment to be made available to startup & MSME ; Implementing
agency to disburse amount within three weeks
7.1.8 Implementing agency will maintain a separate bank account for all
activities related to the scheme
7.1.9 Implementing agency will submit Statement of Expenditure (SE) on
annual basis during beginning of the Financial Year
7 .1 .10 Implementing agency will submit a half-yearly progress report of fund
disbursements
7.1.11 DoT and Implementing agency will conduct an annual review of fund
disbursement, other activities and deliverables to gauge output, and to approve
activities for the forthcoming year.
7.2

Administrative Expenses of Implementing Agency:

The administrative expenses for program are up to Rs .2.50 Cr. per year, broadly
under the sub category as below:

Break of item of Expenditure (in Rs. Cr.) 15 { year
Program Manpower
1.10

2" 0 year
1.10

3ra year
1.10

Online Module Development, Maintenance
etc

0.20

0.20

0.20

Event, Promotion , Outreach , Marketing etc

0.35

0.35

0.35

Project Evaluation , Due-diligence ,
Honorarium , Mentors , Pre-Post Funding
management, Project Tracking etc

0.35

0.35

0.35

Travel , Accommodation , Per-diem etc

0.20

0.20

0.20

Office Establishment (Capex + Opex)

0.10

0.10

0.10

Program Overhead (10%)

0.20

0.20

0.20

Program Administrative Expenses

2.50

2.50

2.50

Page 12of18

<!-- page 13 -->

8.

Assistance and Support

Incubation I Mentoring Support
Selected Startup and MSMEs will be provided mentorship or incubation support
and technical advisory support during entire project development period and additionally
for two years from the date of Technical Completion , by a Facilitation & Mentorship
Team under the Implementing Agency Team along with panel of Experts consisting of
Technical , Financial , Market Development, Legal & Compliance etc. The objective of
this coaching/mentorship is to create success stories in the digital communication space
by offering focused and detailed support individually to each selected projects .
8.1

This incubation support shall be provided by the Incubator Partners , Industry
Partners , Telecom Innovation Hubs etc.
8.2

Scope of Services of Incubators I Mentoring
Each incubator will handhold startups with offerings including ,

a)

Advisory: Strategic support for scaling up of operations & expansion in new
geographies , and product building & enhancement.
Network:
Reach
out
to
relevant
individuals/entities to enable R&D ,
specialized mentorship , partnerships, marketing , etc.
Tapping Resources: Enable startup's participation in grand challenges,
Government. Schemes, incubation/acceleration programs, relevant events , etc.
Pilots: Enabling pilots with corporate , Government, universities, etc.
Business Plan: Guidance on raising capital
Funding Raising: Startup can raise the fund from various sources depending on
the nature of business , viz Grant from other Ministry/Dept, Conditional Grant,
Award , Soft Loan , Loan etc

b)
c)
d)
e)
f)

9.

Success Metrics for the Program

Performance of the mentor will be judged on quarterly basis on clear tangible
outcomes, such as :
a)
b)
c)
d)
e)

f)
g)
h)
i)
j)

Jobs created
Royalty Collection and Corpus Rebuilding
Expansion of startup and MSME into new geographies
Growth in userbase/clientele of startups and MSME
Growth in startup and MSME revenue
Capital raised (equity/debt/grant) , as required
Government incentives availed
Mentorship hours for startup (external specialized mentor)
Feedback of startup and MSME
Pilots conducted
Page 13 .of 18

.,. . .-. ....

,~..._.._,_

<!-- page 14 -->

10.

Pilot Opportunity

10.1 Piloting opportunity for supported Startup and MSME, shall be provided in the
Digital Communications space . For this , DoT along with ITI , BSNL , BBNL, COOT etc.
shall take a proactive approach in allocating experimental licenses , establishing
regulatory sandboxes , facil itating allocation of spectrum for R&D and experimentation at
affordable prices , simplifying and fast-tracking approvals for experimental purposes
through de-licensing and other mechanisms for the shortlisted teams .
10.2 The pilot opportunities will be provided to startups and MSMEs 1n the below
manner,
a)

b)
c)
d)

e)

11.

Any Startup/ MSME desirous of availing the opportunity for pilot, shall be required
to submit a detailed proposal outlining their requirements , scope of work, location
for the pilot, timelines , potential impact, success metrics , etc.
This proposal will be presented to Apex Committee for review & inputs.
Apex Committee shall hold a one-on-one meeting with each interested team to
discuss the proposal and finalize requirements.
ITI.. BSNL, BBNL , COOT can provide strategic inputs in the Apex Committee
evaluations and provide pilot opportunities to the shortlisted startups and MSME.
R&D support from these organizations may be provided to shortlisted startups and
MSME for at least 3 months to help these startups fine-tune their products and
services .
All finalized B2B proposals will be presented to a panel of corporates from Digital
Communications space on a 'Demo Day'. Apex Commitee will facilitate all
experimental licenses and other resources within 30 days of proposal review.
Procurement Opportunity

DCIS shall make appropriate mechanism to ensure that products/ services
developed by startups/MSMEs funded under the project find market and become
financially viable over a period of time .. DoT shall try to work with PSUs for getting them
educational orders and also make available and work with them for technology trials . As
per the Public Procurement Policy for Micro and Small Enterprises (MSMEs) every
Central Ministry/Department/PSU shall set an annual goal of minimum 25 per cent of
the total annual purchases from the products or services produced or rendered by
MSMEs. DoT will sensitize the concerned agencies about the products/services
developed by startups/MSMEs and request for consideration of their proposals ,
submitted i.r.o. their tenders , as per due rules and procedures .

Page 14of18

<!-- page 15 -->

12.

For Incubator Support

12.1 A call for application shall be conducted to select incubators that will be supported
under the scheme . The incubators selected will receive grants from DoT to utilize as
CapEx and OpEx and to create expertise in the field of digital communication .
Implementing agency shall follow similar methodology for call for applications,
shortlisting & selection of incubators , due diligence , disbursement of grants , and
monitoring of progress for incubators as is detailed above for project funding . Fund
management &release, as well as reporting to DoT shall also happen in a similar
manner as detailed above for startup grants.
12.2 Apex Committee may exclude incubator members particularly for evaluating
incubator applications to maintain fair assessment. Post evaluation , the Apex
Committee shall approve a list of incubators to be supported by a grant of Rs 50 Lakhs
each .

13.

Review &Evaluation

13.1 The Scheme would also be subject to midterm review for its efficacy by an
independent third party engaged by DoT for this purpose .
13.2 For the above purpose , expenditure upto a maximum of 2% of the Scheme funds
may be utilized .
14.

Recall of the Central Grant

14.1 The Implementing Agency has to abide by Terms & Conditions for Grant-in-Aid as
per Annexure II.
14.2 Apex committee retains the right to curtail/ recall the central grant along with
applicable interest calcu lated at 3 years SBI MCLR prevailing on the date of
disbursement in case of unsatisfactory use of the grant including compromise with the
quality envisaged , or partial/incomplete implementation of the project.

Pa ge 15of18

<!-- page 16 -->

Annexure -11
Terms & Conditions for Grant-in-Aid

The grant is for the specific project as approved by Department of Telecom (DoT) shall
be subjected to the conditions listed below. The proposal originating industry and
implementing agency shall give an undertaking that they agree to be governed by these
conditions .
1. The grant amount shall be i) spent for the project within the specified time ; and ii)

Any portion of the grant, which is not ultimately required for expenditure for the
approved purposes , shall be duly surrendered to DoT;
2. The implementing agency should adhere to GFR guidelines while incurring
expenditures out of DoT's grant under the project. The Implementing Agency
shall be responsible for ensuring that all procurement of goods , equipments and
services , including works , are through a transparent and competitive bidding
process as per the applicable government rules I guidelines ;
3. The implementing agency shall maintain an audited record 1n the form of a
register in the prescribed proforma for permanent, semi-permanent assets
acquired as solely or mainly out of DoT grant;
4. The assets referred to in (3) above will be property of DoT and should not, without
prior sanction of DoT, be disposed off or encumbered or utilized for the purposes
other than those for which the grant has been sanctioned ;
5. In addition to the ownership of the facility created , preparation and approval of the
DPR , the Implementing Agency shall also be responsible for obtaining all
necessary statutory approvals/clearances including those for environmental
compliance and quality standards as applicable ;
6. The implementing agency shall furnish Utilization Certificate (UC) along with its
request for next release of Grant in Aid certifying that the fund released to them
for which UC has been furnished is as per the objective of the Scheme ;
7. The implementing agency shall render progress-cum-achievement reports at
interval of not exceeding six months on the progress made on all aspects of the
project including expenditure incurred on various approved items during the
period ;

Page 16of18

<!-- page 17 -->

'•

8. The implementing agency shall render an audited statement of accounts to DoT.

9. The audited statement of accounts relating to grants given during financial year
together with the comments of the auditor regarding the observance of the
conditions governing the grant should be forwarded to the DoT within six months
following the end of the relevant financial year;
10.The utilization of grant for the intended purposes will be looked into by the Auditor
of implementing agency according to the directives issued by the Government of
India at the instance of the Comptroller and Auditor General and the specific
mention about it will be made in the audit report;
11 . DoT or its nominee(s) will have the right of access to the books and accounts of
the implementing agency for which a reasonable prior notice would be given ;
12.The implementing agency should maintain separate audited account for the
project. If it is found expedient to keep a part or whole of the grant in a bank
account earning interest, the interest, thus earned should be reported to this
department. All Interest against Grant-in-aid should be mandatorily remitted to the
Consolidated Fund of India immediately after finalization of the accounts. Such
advances should not be allowed to be adjusted against future releases ;
13. Institute may retain the sale proceeds of prototypes , etc fabricated as a result of
the development of the project arising directly from funds granted by the
department. The Institute may use funds thus generated for furtherance of project
objectives ;
14.The Intellectual property and the rights associated with it shall be agreed between
the participating organizations before the st.art of the project. The Industry/
Industry Consortium/ lnstitution(s) will make all efforts to protect intellectual
property generated out of the project. The institution(s)/ industry would submit the
periodic report to DoT for a period of minimum 1 year on the status of IPRs
created/ commercialization under the project. Furthermore , IPR must also reside
in India so that India has access and complete control to these rights in times of
emergency to protect our national interest;
15. Application by implementing agency for any other financial assistance or receipt
of grant/ loan from any other Agency/ Ministry/ Department for this project should
have the prior approval of DoT;

Page 17of18

<!-- page 18 -->

16.The Implementing agency(s) is ~ot allowed to entrust the implementation of this
project for which grant-in-aid is received to another institution and to divert the
grant-in-aid received from DoT as assistance to the later institution ;
17.ln case of any dispute on any matter related to the project during the course of its
implementation , the decision of the Secretary, DoT, shall be final and binding on
the proposal originating industry/ industry consortium and grantee institute;
18. The financial assistance given under the Scheme shall be subject to audit by the
CAG of India ;
19. Implementing Agency will submit a pre-receipt bill for the funds to be disbursed to
it along with certificate that it has not indulged in corrupt practices.

/
Page 18of18
