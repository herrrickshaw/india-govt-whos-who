---
doc_id: "ceec1106d8f9cc8b"
source_url: "https://www.mea.gov.in/images/pdf/6-km-h.pdf"
ministry: "External Affairs (MEA)"
title: "Notifications of Promotion of Shri Kshitij Mohan, as Deputy Secretary of Central Secretariat Service in Ministry (Hindi)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "35686f51aa5a4fe2"
---

<!-- page 1 -->

~~,~R~~~
RGi iCh 6 ~ ("1cHiH , 201 2

.3l'ftl ~

C'tl

ChI~Ch

lJci malUT

fctmcrr c)) RGi iCh

~.'Q" -1901111

12012-tfi.'Q":

31-07-2012

c)) ChI~~&1~ .m-a-~T\~.4/14/2011-~.lRi.1

~c-eJ 'U 'ti ftl ell &I'U ~

(fl~ Q'ti Q'ti)

~~~

<Us(fl~Q'tiQ'ti)

,{1~Qk1,

~

~

~I,{ci~~

~

cH~I&I'U ~

(icP, ~O

15600-39100

~:

~~

(31cR

~,

4706-"(! ChT ~Cllfl~

l(d10Gi ~

3-tR JlI()IICH~ .m-a-~IT

+ ~O 7600

(~

q) c)) ~("1GiCHIGi~

~c-eJ'U 'HfilClI&l~

~ ~

~~

a:rRc=r 'H '{ ChI'( dj)~U II &I'U
lhflC\I~IC\ - t'P\'UIUli I

~

*

cf.

fl~Q'HQ&I

7.8.2012

'ti fil CI)

c)) Q~UIICHfCl*,Q,

3Gichl Qc.)c;-Gik1~

JlTIQR lR,
<Us) c)) ~

(~~~

~

c)) <Us-I

(?J) ~

~

~

~I

c)) ~

'HfilCl
