---
doc_id: "cf444f2fe3df27fb"
source_url: "https://doj.gov.in/static/uploads/2026/04/421705a2a751b2f00b7d09be98722e5d.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of Appointment of (i) Ms. Justice R. Poornima, (ii) Shri Justice M. Jothiraman and (iii) Dr. Justice Augustine Devadoss Maria Clete, Additional Judges of the Madras High Court, as Permanent Judges of the Madras High Court (10.04.2026)"
date: "2026-04-10"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b17c54609d3c6cf5"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)
No. K-13026/01/2026-US.I
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011, Dated: 10" April, 2026.
NOTIFICATION
In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint (i) Ms. Justice R,
Poornima, (ii) Shri Justice M. Jothiraman and (iii) Dr. Justice Augustine
Devadoss Maria Clete, Additional Judges of Madras High Court as Permanent
Judges of the Madras High Court with effect from the date they assume charge of
their respective offices.
i pense bs
(Jagannath Srinivasan)
Joint Secretary to the Government of India
Tele: 2338 3037
To
The Manager,
| Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

-2-

No. K-13026/01/2026-US.1 Dated: 10.04.2026.

Copy to:-

1. (i) Ms. Justice R. Poornima, (ii) Shri Justice M. Jothiraman and (iii)
Dr. Justice Augustine Devadoss Maria Clete, Additional Judges of the
Madras High Court through the Registrar General, Madras High
Court, Chennai.

2. The Secretary to Governor, Tamil Nadu, Chennai.

3. The Secretary to Chief Minister, Tamil Nadu, Chennai.

4. The Secretary to the Chief Justice, Madras High Court, Chennai.

5. The Chief Secretary, Government of Tamil Nadu, Chennai.

. 6. The Registrar General, Madras High Court, Chennai.

7. The Accountant General, Tamil Nadu, Chennai.

8. The President's Secretariat, (CA.II Section), Rashtrapati Bhawan,
New Delhi.

9. PS to Principal Secretary to the Prime Minister, South Block, New
Delhi. ,

10. Registrar (Conf), Supreme Court of India, Room Nos. 1, 2 and 3,
Ground Floor, Supreme Court Main Building, New Delhi - 110001.

11. PS to MoS (I/C), L&J / PPS to Secretary (Justice).

12. Technical Director (NIC), Department of Justice, with a request to
upload the Notification on the website of the Department
(www.doj.gov.in).

a hand)
Under Secretary (Appointments-I)
Tele: 2338 2978
