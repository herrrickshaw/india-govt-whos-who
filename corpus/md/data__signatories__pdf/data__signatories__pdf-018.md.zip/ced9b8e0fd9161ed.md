---
doc_id: "ced9b8e0fd9161ed"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/178468a5471951305c8a201d2946d966.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Ministry of Education to celebrate 4th Anniversary of National Education Policy 2020 with Akhil Bhartiya Shiksha Samagam 2024"
date: "2024-07-28"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ab0d5f2aee5ebb2c"
---

<!-- page 1 -->

Ministry of Education

Ministry of Education to celebrate 4th Anniversary of
National Education Policy 2020 with Akhil Bhartiya
Shiksha Samagam 2024
Posted On: 28 JUL 2024 4:41PM by PIB Delhi

The Ministry of Education will celebrate the 4th anniversary of the implementation of the National Education
Policy 2020 with Akhil Bhartiya Shiksha Samagam 2024 tomorrow in New Delhi’s Manekshaw Centre
Auditorium.
Union Minister for Education, Shri Dharmendra Pradhan, will grace the occasion and share his
insightful experience in spearheading the implementation of the NEP 2020. Minister of State (IC),
Ministry of Skill Development & Entrepreneurship, Shri Jayant Chaudhary and Minister of State for
Education & Development of North Eastern Region, Dr. Sukanta Majumdar and Minister of State for
Education will grace the occasion. It will be attended by several eminent academicians, Vice
Chancellors of the universities, officials, students, etc.
Shri Dharmendra Pradhan will inaugurate several important initiatives of the Department of
Education, such as dedicated TV Channels to facilitate learning of various Indian languages, a
Tamil Channel; Primers for early graders in 25 Indian languages in pursuance to 54 already done;
10 Bagless days Guidelines aimed to transform learning into a fun, stress-free experience in
schools; Career Guidance Guidelines, a massive library of over 500 job cards; NMM & NPST in
Braille and Audio Books; School Innovation Marathon by AICTE & AIM; and Graduation Attributes
and Professional Competencies. Shri Pradhan will also unveil several books and lecture notes
aimed at promoting the Indian Knowledge Systems (IKS) among students and teachers.
Akhil Bharatiya Siksha Samagam (ABSS) has been conceptualized as an event to celebrate the
adoption of National Education Policy 2020 to reinvigorate the commitment of various stakeholders
for its effective implementation and to realize the collective strength for achievement of shared
goals through collaborative efforts. Six Panel discussions will be organised during the day delving
into various initiatives of the Ministry, which will be attended by eminent academicians and
stakeholders.
The first event of ABSS organized in July 2022 at Varanasi was inaugurated by Prime Minister, Shri
Narendra Modi. It was organised with the objective to create scope for all stakeholders to come
together for effective, smooth, and timely implementation of the NEP 2020; establish strong
linkages among various higher educational institutions; and discuss challenges being faced by HEIs
and articulate solutions.
******
SS/AK

(Release ID: 2038126)
