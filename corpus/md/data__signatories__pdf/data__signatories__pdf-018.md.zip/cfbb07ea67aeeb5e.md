---
doc_id: "cfbb07ea67aeeb5e"
source_url: "https://mpa.gov.in/static/uploads/2025/08/c46f4a0900ad43f437253c6548100609.pdf"
ministry: "Parliamentary Affairs (MPA)"
title: "Immovable Property Returns (IPRs) - (02-03-2022)"
date: "2025-08-01"
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "24bf0336159c145f"
---

<!-- no text layer: pending OCR -->
