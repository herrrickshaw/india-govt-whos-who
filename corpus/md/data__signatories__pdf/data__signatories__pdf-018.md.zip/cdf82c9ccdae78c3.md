---
doc_id: "cdf82c9ccdae78c3"
source_url: "https://powermin.gov.in/static/uploads/2026/07/cb5f5ddad4fb89fc50f852121aac3554.pdf"
ministry: "Power"
title: "Inviting comments on draft recruitment rules for the post of Library & Information Assistant, CEA"
date: "2026-07-28"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "04e1d55d06c2a2ff"
---

<!-- page 1 -->

[To be published in the Gazette of India, Part II Section 3 Sub-section (i)]
Government of India
Ministry of Power

DRAFT NOTIFICATION
GSR __. In exercise of the powers conferred by the proviso to article 309 of the Constitution,
the President hereby makes the following rules regulating the method of recruitment to the post
of Library and Information Assistant, in the Headquarters of the Central Electricity Authority,
Ministry of Power namely : 1.

Short title and commencement : -

(i) These rules may be called the Ministry of Power, Central Electricity Authority, Library and
Information Assistant (Group ‘B’ post), Recruitment Rules 2026.
(ii) They shall come into force on the date of their publication in the Official Gazette.
2. Number of post, classification and Level in Pay Matrix :- The number of the said posts,
its classification and Level in the Pay Matrix attached thereto shall be as specified in column 2
to 4 of the said Schedule annexed to these rules.
3. Method of recruitment, age limit and other qualifications etc :- The method of
recruitment, age limit, qualifications and other matters relating thereto shall be as specified in
columns (5) to (13) of the aforesaid Schedule.

4.

Disqualification : No person, -

(i) who has entered into or contracted a marriage with a person having a spouse living or
(ii) who, having a spouse living, has entered into or contracted a marriage with any person
shall be eligible for appointment to the said post:
Provided that the Central Government may, if satisfied that such marriage is permissible under
the personal law applicable to such person and the other party to the marriage and that are
other grounds for so doing, exempt any person from the operation of this rule.
5. Power to relax: Where the Central Government is of opinion that it is necessary or expedient
so to do, it may by order, and for reasons to be recorded in writing and relax any of the provisions
of these rules with respect to any class or category of persons.

<!-- page 2 -->

6. Saving : Nothing in these rules shall affect reservations, relaxation of age limit and other
concessions required to be provided for the Scheduled Castes, the Scheduled Tribes, Other
Backward Classes, Ex Servicemen and other special categories of persons in accordance with the
orders issued by the Central Government from time to time in this regard.
7. Initial Constitution: The employees holding the posts on regular basis in accordance with
the prevailing rules i.e. prior to the commencement of these rules shall be deemed to have been
appointed in accordance with the provisions of these rules.

SCHEDULE

Name
of Post

Number Classification
of Post

1.
Library
&
Informat
ion
Assistant

2.
01*
(2026)

3.
General
Central
Service
*subject (GCS), Group
to
‘B’,
variation (Non-Gazetted,
dependen
Nont on
Ministerial)
workload

Scale
Pay

of Whether
Age limit for direct recruits
Selection
Post
or
NonSelection Post
4.
5.
6.
Level-6 Not applicable Not exceeding 30 years
(Rs.
(Relaxable
for
Government
35400servant
up
to
5
years in
1,12,40
accordance with the instructions or
0/-)
orders issued by the Central
Government).
Note: The crucial date for
determining the age limit shall be
the closing date for receipt of
applications from candidates in
India (and not the closing date
prescribed for those in Assam,
Meghalaya, Arunachal Pradesh,
Mizoram, Manipur, Nagaland,
Tripura, Sikkim, Ladakh Division
of J&K State, Lahaul & Spiti
District and Pangi Sub Division
of Chamba District of Himachal
Pradesh, Anadaman & Nicobar
Islands of Lakshadweep).

<!-- page 3 -->

Educational and other qualifications
required for direct recruits

7.

Whether age
and educational
qualifications
prescribed for
direct
recruits will apply
in the case of
promotees
8.

Essential:
(i)

Bachelor’s Degree in Library
Science or Library and
Information Science of a
recognized
University/
Institute;

Desirable:
(i)
(ii)

Diploma
in
Computer
Application from a recognized
University or Institute.
Two
years'
professional
experience in a Library under
Central/ State Government /
Autonomous
or
Statutory
organization/ PSU/ University
or Recognized Research or
Educational Institution.

Note 1: Qualifications are relaxable at
the discretion of the Competent
Authority in the case of candidates
otherwise well qualified for reasons to
be recorded.
Note 2: The qualification(s) regarding
experience is relaxable at the discretion
of the Competent Authority in the case
of candidates belonging to Scheduled
Castes and Scheduled Tribes if at any
stage of selection, the Competent
Authority is of the opinion that
sufficient number of candidates from
these communities possessing the
requisite experience are not likely to be
available to fill up the vacancies
reserved for them.

Not Applicable

Period
of
probatio
n, if any

Method of recruitment whether by
direct recruitment or by promotion
or.by deputation/ absorption and
percentage of the vacancies to be
filled by various methods.

9.
Two (02)
years

10.
Direct recruitment through SSC.
Note: Vacancies caused by the
incumbent being away on deputation
or long illness or study leave or under
other circumstances for duration of
one year or more may be filled on
deputation basis from officers of the
Central
Government
holding
analogous posts on regular basis and
possessing
the
qualifications
prescribed for direct recruits under
column 7.

<!-- page 4 -->

In case of recruitment on
deputation, grades from which
deputation to be made.

11.
Not applicable

If a Departmental Promotion
Committee exists, what is its
composition.

Circumstances in which
Union Public Service
Commission is to be
consulted in making
recruitment.
12.
13.
Group ‘B’ DPC (For considering Consultation with Union
confirmation)
Public Service Commission is
not necessary.
1. Member, CEA or equivalent officerChairman;
2. Chief Engineer, CEA or equivalent
officer- Member;
3. Deputy
Secretary/
Director
(Administration), MoP- Member;
4. Director
(Administration),
CEAMember.
