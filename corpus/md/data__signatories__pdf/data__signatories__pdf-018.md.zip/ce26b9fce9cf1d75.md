---
doc_id: "ce26b9fce9cf1d75"
source_url: "https://www.dpiit.gov.in/static/uploads/2026/06/58bad702d5698967dd41dc4b6611d53b.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Request for Stakeholder's comments on Draft Quality Control Orders"
date: "2026-06-01"
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a0d4aec1afdd5d49"
---

<!-- page 1 -->

F. No. P-29026/5/2022-LEI
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry and Internal Trade
(Light Engineering Industry Section)
Request for Stakeholder's comments on Draft Quality Control Orders
As you are aware, DPIIT is in the process to formulate Quality Control Orders/ Technical
Regulations for various products in pursuance of Hon’ble Prime Minister’s call for “Zero
Defect- Zero Effect” manufacturing. Accordingly, 05 new draft QCOs for 30
standards/products as given below have been identified and placed at Annexure-1. Stakeholder
Consultation has been scheduled for the following QCOs on below mentioned dates.
S. No.

Title of Draft QCOs

1

Service Valves

No. of
Product
Standards

Meeting date and
time

1

15th June, 2026 at 3
P.M.

VC link for Stakeholder
Consultation

https://railtelindia.webex.com/railteli
ndia/j.php?MTID=m92f52d9db18481
bb62f7c8390ef29cba

2

Bicycles

2

10th June, 2026 at
4:30 P.M.
https://railtelindia.webex.com/railteli
ndia/j.php?MTID=mf7e18ac4b971e5
0ebdc1ca4b8023cf1c

3

Pumps

12

17th June, 2026 at 3
P.M.
https://railtelindia.webex.com/railteli
ndia/j.php?MTID=mbbe24047006bd
aa80291221607d249b2

4

Safety of Hand-held
Motor Operated Electric
Tools

6

17th June, 2026 at 4
P.M.
https://railtelindia.webex.com/railteli
ndia/j.php?MTID=m6d262174e36dce
2f893328bf64831ad5

5

Fire detection and alarm
system

9

18th June, 2026 at 3
P.M.
https://railtelindia.webex.com/railteli
ndia/j.php?MTID=mcc1085eceefbc1
1b6bd83bff59baeeec

In this regard, All the industry, Apex industry/ Associations (CII, FICCI, ASSOCHAM),
Sectoral Industry/ Association, Regional Industry/ Associations, respective Administrative
Ministries, MSMEs, Concerned R & D institutions/ Organizations are requested to furnish their
comments on the draft QCOs to this Department by 13th June, 2026 and make it convenient to
attend the meeting through VC on above mentioned date and time. Kindly furnish your
comments on email address: lei-dpiit@gov.in

<!-- page 2 -->

Annexure-1
[TO BE PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY, PART II,
SECTION 3, SUB-SECTION (II)]
GOVERNMENT OF INDIA
MINISTRY OF COMMERCE & INDUSTRY
DEPARTMENT FOR PROMOTION OF INDUSTRY AND INTERNAL TRADE
ORDER
New Delhi, the---- , 2026
S.O.-------(E).- In exercise of the powers conferred by sub-sections (1) and (2) of
section 16 read with section 17 and sub-section (3) of section 25 of the Bureau of Indian
Standards Act, 2016 (11 of 2016), the central Government, after consulting the Bureau of
Indian Standards, is of the opinion that it is necessary or expedient so to do in the public interest,
hereby makes the following order, namely:1. Short title and commencement. - (1) This order may be called Service Valves (Quality
Control) Order, 2026.
(2) It shall come into force with effect from the date of its publication in the Official Gazette.
2. Compulsory use of Standard Mark.- - Goods or articles specified in column (2) of the
Table shall conform to the corresponding Indian Standard specified in column (3) of the Table
and shall bear the Standard Mark under a license from the Bureau as per Scheme-I of Schedule
II of the Bureau of Indian Standards (Conformity Assessment) Regulations, 2018 from the date
specified in the corresponding entry under column (5) of the Table:
Provided that the micro enterprises and small enterprise, as defined under the Micro, Small and
Medium Enterprises Development Act, 2006 (27 of 2006) shall conform to such Indian
Standards from the date specified in the corresponding entry under columns (6) and (7) of the
Table respectively:
Provided also that nothing in this order shall apply to goods or articles manufactured
domestically for export:
Provided also that nothing in this order shall apply for 200 number of goods or articles imported
for the purpose of research and development by manufacturers of service valves per year with
the condition that such imported goods and articles shall not be sold commercially and can be
disposed of as a scrap and the manufacturer shall maintain a year-wise record of such goods or
articles and furnish to the Central Government
Provided also that nothing in this Order shall apply to goods or articles domestically
manufactured or imported before the date of commencement of this Order by the manufacturer
certified by the Bureau or manufacturer who has applied to the Bureau for certification for the
relevant goods and articles and such manufacturer shall be permitted to sell or display or offer
to sell such declared stock up to 6 months, subject to the condition that such manufacturer shall
made a declaration to this effect to the Bureau.

<!-- page 3 -->

3. Certification and enforcement authority. - The Bureau shall be the certifying and
enforcing authority for the goods or articles specified in the Table.
4. Penalty for Contravention – Any person who contravenes the provisions of this Order
shall be punishable under the provisions of the Bureau of Indian Standards Act, 2016.
TABLE
S. Goods or
No. Articles

Indian
Title of Indian
Standard Standard

Date of
Date of
Date of
implementation in implementation for implementation
General (Other
Small Enterprises for Micro
than Micro and
Enterprises
Small Enterprises)

(1) (2)

(3)

(5)

1

Service Valves IS 19409:
2025

(4)

(6)

Service Valves for 6 months from the
Air Conditioning date of publication
and Refrigeration in e-Gazette
Purposes Specification

(7)

9 months from the 12 months from
date of publication the date of
in e-Gazette
publication in eGazette

Note: For the purposes of this Table, the latest version of Indian Standards including the
amendments issues thereof, as notified by the Bureau of Indian Standards from time to time
shall apply.

F. No. P-…………-LEI

(………)
Joint Secretary to the Govt. of India

<!-- page 4 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY, PART II,
SECTION 3, SUB-SECTION (II)]
GOVERNMENT OF INDIA
MINISTRY OF COMMERCE & INDUSTRY
DEPARTMENT FOR PROMOTION OF INDUSTRY AND INTERNAL TRADE
ORDER
New Delhi, the---- , 2026
S.O.-------(E).- In exercise of the powers conferred by sub-sections (1) and (2) of
section 16 read with section 17 and sub-section (3) of section 25 of the Bureau of Indian
Standards Act, 2016 (11 of 2016), the central Government, after consulting the Bureau of
Indian Standards, is of the opinion that it is necessary or expedient so to do in the public
interest, hereby makes the following order, namely:1. Short title and commencement. - (1) This order may be called Bicycle (Quality Control)
Order, 2026.
(2) It shall come into force with effect from the date of its publication in the Official Gazette.
2. Compulsory use of Standard Mark.- - Goods or articles specified in column (2) of the
Table shall conform to the corresponding Indian Standard specified in column (3) of the Table
and shall bear the Standard Mark under a license from the Bureau as per Scheme-I of Schedule
II of the Bureau of Indian Standards (Conformity Assessment) Regulations, 2018 from the date
specified in the corresponding entry under column (5) of the Table:
Provided that the micro enterprises and small enterprise, as defined under the Micro, Small and
Medium Enterprises Development Act, 2006 (27 of 2006) shall conform to such Indian
Standards from the date specified in the corresponding entry under columns (6) and (7) of the
Table respectively:
Provided also that nothing in this order shall apply to goods or articles manufactured
domestically for export:
Provided also that nothing in this order shall apply for 200 number of goods or articles imported
for the purpose of research and development by manufacturers of Bicycles per year with the
condition that such imported goods and articles shall not be sold commercially and can be
disposed of as a scrap and the manufacturer shall maintain a year-wise record of such goods or
articles and furnish to the Central Government
Provided also that nothing in this Order shall apply to goods or articles domestically
manufactured or imported before the date of commencement of this Order by the manufacturer
certified by the Bureau or manufacturer who has applied to the Bureau for certification for the
relevant goods and articles and such manufacturer shall be permitted to sell or display or offer
to sell such declared stock up to 6 months, subject to the condition that such manufacturer shall
made a declaration to this effect to the Bureau.

<!-- page 5 -->

3. Certification and enforcement authority. - The Bureau shall be the certifying and
enforcing authority for the goods or articles specified in the Table.

4. Penalty for Contravention – Any person who contravenes the provisions of this Order
shall be punishable under the provisions of the Bureau of Indian Standards Act, 2016.
TABLE
S. Goods Indian
No. or
Standard
Articles

Title of Indian
Standard

Date of
implementation in
General (Other than
Micro and Small
Enterprises)

Date of
Date of
implementation for implementation for
Small Enterprises Micro Enterprises

(1) (2)

(4)

(5)

(6)

1

2

(3)

(7)

Bicycles 10613:2014 Cycle Safety
6 months from the date 9 months from the 12 months from the
requirements for of publication in edate of publication date of publication
Bicycles
Gazette
in e-Gazette
in e-Gazette
15533: 2004 Cycle Safety
requirements for
Bicycles for
young children

Note: For the purposes of this Table, the latest version of Indian Standards including the
amendments issues thereof, as notified by the Bureau of Indian Standards from time to time
shall apply.

F. No. P-…………-LEI

(………)
Joint Secretary to the Govt. of India

<!-- page 6 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY, PART II,
SECTION 3, SUB-SECTION (II)]
GOVERNMENT OF INDIA
MINISTRY OF COMMERCE & INDUSTRY
DEPARTMENT FOR PROMOTION OF INDUSTRY AND INTERNAL TRADE
ORDER
New Delhi, the---- , 2026
S.O.-------(E).- In exercise of the powers conferred by sub-sections (1) and (2) of
section 16 read with section 17 and sub-section (3) of section 25 of the Bureau of Indian
Standards Act, 2016 (11 of 2016), the central Government, after consulting the Bureau of
Indian Standards, is of the opinion that it is necessary or expedient so to do in the public interest,
hereby makes the following order, namely:1. Short title and commencement. - (1) This order may be called Pumps (Quality Control)
Order, 2026.
(2) It shall come into force with effect from the date of its publication in the Official Gazette.
2. Compulsory use of Standard Mark.- - Goods or articles specified in column (2) of the
Table shall conform to the corresponding Indian Standard specified in column (3) of the Table
and shall bear the Standard Mark under a license from the Bureau as per Scheme-I of Schedule
II of the Bureau of Indian Standards (Conformity Assessment) Regulations, 2018 from the date
specified in the corresponding entry under column (5) of the Table:
Provided that the micro enterprises and small enterprise, as defined under the Micro, Small and
Medium Enterprises Development Act, 2006 (27 of 2006) shall conform to such Indian
Standards from the date specified in the corresponding entry under columns (6) and (7) of the
Table respectively:
Provided also that nothing in this order shall apply to goods or articles manufactured
domestically for export:
Provided also that nothing in this order shall apply for 200 number of goods or articles imported
for the purpose of research and development by manufacturers of Pumps per year with the
condition that such imported goods and articles shall not be sold commercially and can be
disposed of as a scrap and the manufacturer shall maintain a year-wise record of such goods or
articles and furnish to the Central Government
Provided also that nothing in this Order shall apply to goods or articles domestically
manufactured or imported before the date of commencement of this Order by the manufacturer
certified by the Bureau or manufacturer who has applied to the Bureau for certification for the
relevant goods and articles and such manufacturer shall be permitted to sell or display or offer
to sell such declared stock up to 6 months, subject to the condition that such manufacturer shall
made a declaration to this effect to the Bureau.

<!-- page 7 -->

3. Certification and enforcement authority. - The Bureau shall be the certifying and
enforcing authority for the goods or articles specified in the Table.

4. Penalty for Contravention – Any person who contravenes the provisions of this Order shall
be punishable under the provisions of the Bureau of Indian Standards Act, 2016.
TABLE
S. Goods Indian
No. or
Standard
Articles

Title of Indian
Standard

Date of
Date of
implementation in implementation
General (Other than for Small
Micro and Small
Enterprises
Enterprises)

Date of
implementation
for Micro
Enterprises

(1) (2)

(4)

(5)

(7)

1

(3)

(6)

Pumps 11501:1986 Engine Monoset
6 months from the
9 months from the 12 months from the
Pumps for Clear,
date of publication in date of publication date of publication
Cold, Fresh Water for e-Gazette
in e-Gazette
in e-Gazette
Agricultural Purposes

2

12225:1997 Centrifugal jet pump

3

14106:2018 Direct Action Hand
Pumps

4

14220:2018 Openwell
Submersible
Pumpsets

5

17018 (Part Solar Photovoltaic
1):2018
Water Pumping
Systems - Centrifugal
Pumps

6

6595 (Part
1) :2018

Horizontal
Centrifugal Pumps
for Clear, Cold Water
- Agricultural and
Rural Water Supply
Purposes

7

6595 (Part
2) :1993

Horizontal
centrifugal pumps for
clear, cold water General purposes
other than
agricultural and rural
water supply

8

8035:1999 Handpump - Shallow
Well

<!-- page 8 -->

9

8418:1999 Horizontal
Centrifugal Selfpriming Pumps

10

8472:2019 Centrifugal
Regenerative Pumps
for Clear, Cold Water

11

9079:2018 Monoset Pumps for
Clear, Cold Water for
Agricultural and
Water Supply
Purposes

12

8034: 2018 Submersible
pumpsets

Note: For the purposes of this Table, the latest version of Indian Standards including the
amendments issues thereof, as notified by the Bureau of Indian Standards from time to time
shall apply.

F. No. P-…………-LEI

(………)
Joint Secretary to the Govt. of India

<!-- page 9 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY, PART II,
SECTION 3, SUB-SECTION (II))]
GOVERNMENT OF INDIA
MINISTRY OF COMMERCE AND INDUSTRY
(DEPARTMENT FOR PROMOTION OF INDUSTRY & INTERNAL TRADE)
ORDER
New Delhi, the, -------, 2026
S.O.-------(E).- In exercise of the powers conferred by sub-sections (1) and (2) of
section 16 read with section 17 and sub-section (3) of section 25 of the Bureau of Indian
Standards Act, 2016 (11 of 2016), the central Government, after consulting the Bureau of
Indian Standards, is of the opinion that it is necessary or expedient so to do in the public interest,
hereby makes the following order, namely:
1. Short title and commencement. - (1) This order may be called Safety of Hand-held MotorOperated Electric Tools (Quality Control) Order, 2026.
(2) It shall come into force from the date of its publication in the Official Gazette.
2. Compulsory use of Standard Mark. - - Goods or articles specified in column (2) of the
Table shall conform to the corresponding Indian Standard specified in column (3) of the Table
and shall bear the Standard Mark under a license from the Bureau as per Scheme-I of ScheduleII of the Bureau of Indian Standards (Conformity Assessment) Regulations, 2018 from the date
specified in the corresponding entry under column (5) of the Table:
Provided that the micro enterprises and small enterprise, as defined under the Micro, Small and
Medium Enterprises Development Act, 2006 (27 of 2006) shall conform to such Indian
Standards from the date specified in the corresponding entry under columns (6) and (7) of the
Table respectively:
Provided also that nothing in this order shall apply to goods or articles manufactured
domestically for export.
Provided also that nothing in this order shall apply for 100 number of goods or articles imported
for the purpose of research and development by manufacturers of Safety of Hand-held MotorOperated Electric Tools per year with the condition that such imported goods and articles shall
not be sold commercially and can be disposed of as a scrap and the manufacturer shall maintain
a year-wise record of such goods or articles and furnish to the Central Government
Provided also that nothing in this Order shall apply to goods or articles domestically
manufactured or imported before the date of commencement of this Order by the manufacturer
certified by the Bureau or manufacturer who has applied to the Bureau for certification for the
relevant goods and articles and such manufacturer shall be permitted to sell or display or offer

<!-- page 10 -->

to sell such declared stock up to 6 months, subject to the condition that such manufacturer shall
made a declaration to this effect to the Bureau
3. Certification and enforcement authority. - The Bureau shall be the certifying and
enforcing authority for the goods or articles specified in the Table.
4. Penalty for contravention. — Any person who contravenes the provisions of this order
shall be punishable under the provisions of the Bureau of Indian Standards Act, 2016.
TABLE
S. Goods or
No. Articles

Indian
Title of Indian
Standard Standard

Date of
implementation in
General (Other
than Micro and
Small Enterprises)

Date of
implementation
for Small
Enterprises

Date of
implementation
for Micro
Enterprises

(1) (2)

(3)

(4)

(5)

(6)

(7)

1

IS 4665
(Part

Hand-Held MotorOperated Electric
Tools Safety Part 2
Particular

12 months from the 15 months from
date of notification in the date of
e-Gazette
notification in eGazette

Safety of
Hand-held
MotorOperated
Electric
Tools

2/Sec 1):
2023

IEC
60745-2-1:
2003
2

IS 4665
Hand-held motor(Part 2/Sec operated electric
2): 2023 tools - Safety Part 2
Particular
requirements Section
2 screwdrivers and
IEC
60745-2-2: impact
2003

3

Wrenches

IS 4665
Hand-held motor(Par 2/Sec operated electric
3): 2023 tools - Safety Part 2
Particular
requirements Section
3 grinders polishers
IEC
60745-2- and disk3:2006

4

requirements Section
1 drills and impact
drills

type sanders

IS 4665
Hand-Held Motor(Part 2/Sec Operated Electric
5): 2023
Tools Safety Part 2
Particular
Requirements
IEC
Section 5 Circular
60745-2-5: Saws
2010

18 months from
the date of
notification in eGazette

<!-- page 11 -->

5

IS 4665
Hand-Held Motor(Part 2/Sec Operated Electric
6): 2023 Tools - Safety

IEC
60745-2-6:
2003
6

Part 2 Particular
Requirements
Section 6 Hammers

IS 4665
Safety of Hand-Held
(Part 2/Sec Motor-operated
7): 2023 Electric Tools Part 2
Particular
Requirements
Section 7 Spray
IEC
60745-2-7: Guns for Non1989
Flammable Liquids

Note: For the purposes of this Table, the latest version for Indian Standards including the
amendments issues thereof, as notified by the Bureau of Indian Standards from time to time
shall apply.

(File No. -LEI)
(
)
Joint Secretary to the Govt. of India

<!-- page 12 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY, PART II,
SECTION 3, SUB-SECTION (II)]
GOVERNMENT OF INDIA
MINISTRY OF COMMERCE & INDUSTRY
DEPARTMENT FOR PROMOTION OF INDUSTRY AND INTERNAL TRADE
ORDER
New Delhi, the---- , 2026
S.O.-------(E).- In exercise of the powers conferred by sub-sections (1) and (2) of
section 16 read with section 17 and sub-section (3) of section 25 of the Bureau of Indian
Standards Act, 2016 (11 of 2016), the central Government, after consulting the Bureau of
Indian Standards, is of the opinion that it is necessary or expedient so to do in the public
interest, hereby makes the following order, namely:1. Short title and commencement. - (1) This order may be called Fire detection and alarm
systems (Quality Control) Order, 2026.
(2) It shall come into force with effect from the date of its publication in the Official Gazette.
2. Compulsory use of Standard Mark.- - Goods or articles specified in column (2) of the
Table shall conform to the corresponding Indian Standard specified in column (3) of the Table
and shall bear the Standard Mark under a license from the Bureau as per Scheme-I of Schedule
II of the Bureau of Indian Standards (Conformity Assessment) Regulations, 2018 from the date
specified in the corresponding entry under column (5) of the Table:
Provided that the micro enterprises and small enterprise, as defined under the Micro, Small and
Medium Enterprises Development Act, 2006 (27 of 2006) shall conform to such Indian
Standards from the date specified in the corresponding entry under columns (6) and (7) of the
Table respectively:
Provided also that nothing in this order shall apply to goods or articles manufactured
domestically for export:
Provided also that nothing in this order shall apply for 200 number of goods or articles imported
for the purpose of research and development by manufacturers of Fire detection and alarm
systems per year with the condition that such imported goods and articles shall not be sold
commercially and can be disposed of as a scrap and the manufacturer shall maintain a yearwise record of such goods or articles and furnish to the Central Government
Provided also that nothing in this Order shall apply to goods or articles domestically
manufactured or imported before the date of commencement of this Order by the manufacturer
certified by the Bureau or manufacturer who has applied to the Bureau for certification for the
relevant goods and articles and such manufacturer shall be permitted to sell or display or offer

<!-- page 13 -->

to sell such declared stock up to 6 months, subject to the condition that such manufacturer shall
made a declaration to this effect to the Bureau.
3. Certification and enforcement authority. - The Bureau shall be the certifying and
enforcing authority for the goods or articles specified in the Table.

4. Penalty for Contravention – Any person who contravenes the provisions of this Order
shall be punishable under the provisions of the Bureau of Indian Standards Act, 2016.
TABLE
S. Goods or Indian
Title of Indian
No. Articles Standard Standard

Date of
implementation in
General (Other
than Micro and
Small Enterprises)

Date of
implementation
for Small
Enterprises

Date of
implementation
for Micro
Enterprises

(1) (2)

(5)

(6)

(7)

1

2

(3)

(4)

Fire
IS/ISO
Fire Detection and
detection 7240-10: Alarm Systems
and alarm 2012
Part 10 Point-Type
systems
Flame Detectors
IS/ISO
7240-18
:2017

Fire Detection and
Alarm Systems

IS/ISO
7240-8
:2014

Fire Detection and
Alarm Systems Part 8
Point-Type Fire
Detectors Using a
Carbon

Part 18 Input/Output
Devices

Monoxide Sensor in
Combination
with a Heat Sensor
3

4

5

IS/ISO
7240-21
:2005

Fire Detection and
Alarm Systems

IS/ISO
7240-22
:2017

Fire Detection and
Alarm Systems

IS/ISO
7240-24
:2016

Fire Detection and
Alarm Systems

Part 21 Routing
Equipment

Part 22 SmokeDetection Equipment
for Ducts

6 months from the 9 months from the 12 months from
date of publication in date of publication the date of
e-Gazette
in e-Gazette
publication in eGazette

<!-- page 14 -->

Part 24 Fire Alarm
Loudspeakers
7

8

IS/ISO
7240-25
:2010

Fire Detection and
Alarm Systems

IS/ISO
7240-27
:2018

Fire Detection and
Alarm Systems Part 27
Point Type Fire
Detectors Using a
Smoke; Sensor in
Combination with a
Carbon Monoxide
Sensor and, Optionally,

Part 25 Components
Using Radio
Transmission Paths

One or More Heat
Sensors
9

IS/ISO
7240-29
:2017

Fire Detection and
Alarm Systems
Part 29 Video Fire
Detectors

Note: For the purposes of this Table, the latest version of Indian Standards including the
amendments issues thereof, as notified by the Bureau of Indian Standards from time to time
shall apply.

F. No. P-…………-LEI

(………)
Joint Secretary to the Govt. of India
