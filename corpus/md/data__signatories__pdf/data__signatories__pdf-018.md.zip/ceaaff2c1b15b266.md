---
doc_id: "ceaaff2c1b15b266"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/2ffc16e3554967496826c148b9254984.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Provisional seniority list in the Grade of Engineer in IRRS Cadre of DoT as on 01.01.2025-reg"
date: "2025-01-07"
pages: 10
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a8fa1e5b43f62b39"
---

<!-- page 1 -->

No. A-12028/08/2024-Admn.II
. : ama acer / Government of India
संचार मंत्रालय / Ministry of Communications ड़
दूरसंचार विभाग / Department of Telecommunications
संचार भवन, २०, अशोक मार्ग
Sanchar Bhawan, 20, Ashoka Road
. ag fercit- 220008 / New Delhi- 110001
Dated the 07" January, 2025
OFFICE MEMORANDUM
Sub.: Provisional Seniority List in the Grade of Engineer in IRRS Cadre of DoT as on
01.01.2025 -reg.
The undersigned is directed to circulate herewith the provisional seniority list of Engineers
(JTS Level) of IRRS Cadre of Department of Telecommunications as on 01.01.2025 for intimating
the additions/deletions/discrepancies/objections, if any, on above seniority list received after
22.01.2025 will not be accepted/entertained. The seniority of these Engineers will be finalized
once the issue attains the finality. हम
bros
(Amit Kundan)
Under Secretary to the Govt. of India
To,
1. Wireless Advisor — DoT -for circulation of provisional seniority list among all the
concerned officers.
2. Director (WMO), Pushpa Bhawan, New Delhi — 110062 - for circulation of
provisional seniority list among all the concerned officers.
3. DoT website
4. E-office notice Board
5. OL Section for Hindi translation

<!-- page 2 -->

: at
F, No A-12028/08/2024-Admn II
PROVISIONAL SENIORITY LIST IN THE GRADE OF ENGINEER IN THE INDIAN RADIO REGULATORY SERVICE, DEPARTMENT OF TELECOMMUNICATIONS as
on 01.01.2025
Sr. |Name & Staff Date of Birth |Batch Year / Date of entry into UPSC Ref No. in which appointed
No |Number (DR / P) Group ‘A’ service
[S/Sh./Smt.]
15.02.1956 |P-2015-2016 [29.02.2016 F.1/ 34 (3)/2016-AP.3 Retired on 29.02.2016
2 [Jyoti Sharma 27.10.1993 |DR-2016 05.10.2017 F.1/4/(14)/2016-E, VII
79126
3 [VK Khare 06-09-1958 |P-2015-2016  |08-04-2016 F.1/ 34 (3)/2016-AP.3 Retired on 30.09.2018
79094
4 [Satish Kumar (OBC) [12.11.1987 |DR-2016 12.10.2017 F.1/4(14)/2016-E.VIl
79127
04.06.1956 |P-2015-2016 |18.04.2016 F.1/ 34 (3)/2016-AP.3 Retired on 30.06.16
Parikh Hemendra 30.08.1987 |DR-2016 04.10.2017 F.1/4(14)/2016-E.VIl
Chimanlal (SC)
79128
7 |B.K. Ram (SC) 19.01.1967 |P-2015-16 02.05.2016 F.1/34(3)/2016-AP-3
79096
Vinay Meena (ST) [08.01.1991 |DR-2016 04.10.2017 F.1/4/(14)/2016-E.VIl
79129
“x oe
po

<!-- page 3 -->

22. हु
F. No A-12028/08/2024-Admn II
9 |C.Meenal(Sc) [29.06.1967 |P-2015-16 12.04.2016 ~ |F.1/34(3)/2016-AP-3
79097
10 [Balbir Singh (SC) [15.08.1969 |P-2015-16 08.04.2016 F.1/34(3)/2016-AP-3
79098
11 |G.C. Malick (SC) 26.09.1964 |P-2015-16 11.04.2016 F.1/34(3)/2016-AP-3 Retierment on 30/09/2024
79099
12 |K.V.SunilKumar [20.05.1969 |P-2015-16 25.04.2016 F.1/34(3)/2016-AP-3
(SC)
79100
13 [Amit Gautam 29.01.1988 |DR-2017 11.07.2018 (F/N) No. F.1/4 (14)/2017-E.VIl
79130
31.05.1956 |P-2016-2017 25.10.2016 F.1/34(20)/2016-AP.3 |
15 [Raju Dey 30.09.1990 |DR-2017 09.07.2018 (F/N) No. F.1/4 (14)/2017-E.VIl
79131
16 [Deepak Kumar Pant [25.11.1973 |P-2016-17 27.10.2016 F.1/34(20)/2016-AP.3
79102 F.1/34(23)/2023-AP.3
17 |Madhur Goel 08.11.1991 |DR-2017 21.06.2018 (F/N) No. F.1/4 (14)/2017-E.VIl
79132
18 |Sukhbir Singh 22.01.1973 |P-2016-17 28.10.2016 F.1/34(20)/2016-AP.3
79103 F.1/34(23)/2023-AP.3
.
x
pe

<!-- page 4 -->

et a
F. No A-12028/08/2024-Admn Il
19 |Gnaneshwar K 04.11.1994 |DR-2017 09.07.2018 (F/N) —_|No. F.1/ 4 (14)/2017-E.VIl | OO :
79133
20 |Yogesh Kumar 19.08.1991 |P-2016-17 26.10.2016 F.1/34(20)/2016-AP.3
Sharma F.1/34(23)/2023-AP.3
79104
21 |AnnuAhlawat [23.03.1994 |DR-2017 _—‘[ 22.06.2018 (F/N) No. F.1/4 (14)/2017-E.VIl
79134
22 |K.VS.Vara Prasad |24.01.1970 |P-2016-17 26.10.2016 F.1/34(20)/2016-AP.3
79105 F.1/34(23)/2023-AP.3
23 [Shalini Gupta 03.09.1994 |DR-2017 26.11.2018 No. F.1/4 (14)/2017-E.Vil
79135
“05. - 2016- 25.10.2016 -1/34(23)/2023-AP.3
24 |SSSantaraman 02.05.1961 |P- 2016-2017 [25 F.1/34(23)/ setied onatos.2004
79106
25 |SKGhosh 07.07.1958 |P- 2016-2017 10.11.2016 F.1/34(23)/2023-AP.3 Retired
79107
26 |SubhashriV 15.06.1962 |P-2016-2017 01.12.2016 F.1/34(23)/2023-AP.3 Retired on 30:06.3003
79108
B Bhattacharje 19.12.1956 |P-2016-2017  |01.11.2016 F.1/34(23)/2023-AP.3 Retired 13.12.2016
28 |Nalnish Shrivastava [27.05.1961 |P-2016-2017  |26.10.2016 F.1/34(23)/2023-AP.3 Retired on 31.05.2021
79110
ok
बन्द

<!-- page 5 -->

ele
F. No A-12028/08/2024-Admn II

29 [PN Murthy ~ 10.10.1959 |P-2016-2017 23.12.2016 F.1/34(23)/2023-AP.3

79111
30 [Darshan Singh 12.07.1957 |P-2016-2017 [26.10.2016 F.1/34(23)/2023-AP.3

Rawat
JK Mukharjee 15.01.1957 |P- 2016-2017 |25.10.2016 F.1/34(23)/2023-AP.3 PF |
BD Chattopadhyay [18.06.1957 |P- 2016-2017 02.01.2017 F.1/34(23)/2023-AP.3 fF |
33 |BrahmaPalSingh [01.01.1961 |P-2016-2017 [27.10.2016 F.1/34(23)/2023-AP.3 native on 31.43.9020

79116
34 [R.K. Yadav 15.04.1963 |P-2016-2017 [31.10.2016 F.1/34(20)/2016-AP-3 गिह18090 300/2028

79117
35 |AV.S.Ravikumar [20.06.1969 |P-2016-2017 [26.10.2016 F.1/34(20)/2016-AP-3

79118 F.1/34(23)/2023-AP.3
Nagendra Sharma [18.12.1960 [P- 2016-2017 [25.10.2016 F.1/34(23)/2023-AP.3 Retired on 31.12.2020
37 [Yogesh Nandwani [08.04.1969 |P-2016-2017 [25.10.2016 F.1/34(20)/2016-AP-3

79120 F.1/34(23)/2023-AP.3
38 |P. Subba (ST) 10.01.1968 |P-2016-2017 [28.10.2016 F.1/34(20)/2016-AP-3

79122 F.1/34(23)/2023-AP.3
39 [Rajendra Rajak 01.01.1965 |P- 2016-2017 [20.12.2023 F.1/34(23)/2023-AP.3

69028

bs

<!-- page 6 -->

. 5
F. No A-12028/08/2024-Admn II
40 |8V Murali Manohar |28.08.1966 |P- 2016-2017 [20.12.2023 F.1/34(23)/2023-AP.3 as
69029
41 [R.N.Lahadke 10.10.1967 |P-2016-2017  |20.12.2023 F.1/34(23)/2023-AP.3
69030
02.12.1963 |P- 2016-2017 |20.12.2023 F.1/34(23)/2023-AP.3 Retired on 31.12.2023
43 |PramodD. Shinde  |6.9.1968 P- 2016-2017 [20.12.2023 F.1/34(23)/2023-AP.3
69032
Cheru Kuri Saideep [20.08.1994 |DR-2018 21.02.2020 F.1/34(23)/2023-AP.3 Resigned on 28.02.2020
45 [Vaibhav Chhabra [05.02.1992 |DR-2018 10.10.2019 F.1/4 (14)/2018-E.Vil
79136
Kshitij Gupta 10.01.1990 |DR-2018 09.10.2019 (F/N) F.1/4 (14)/2018-E.VIl
79137
47 |Bhanu Bhai 20.10.1993 |DR-2018 03.09.2019 (F/N) F.1/4 (14)/2018-E.VIl
Richhariya
79138
48 |[Manimala 15.07.1993 |DR-2018 09.09.2019 (F/N) F.1/4 (14)/2018-E.Vil
79139
49 [Priti Kumari 25.10.1991 |DR-2018 01.10.2019 (F/N) F.1/4 (14)/2018-E.Vil
79140
50 [Rahul Sondhara 04.01.1995 |DR-2018 02.09.2019 (F/N) F.1/4 (14)/2018-E.VIl
79141
ee ;

<!-- page 7 -->

-6-
F, No A-12028/08/2024-Admn II

51 |RahulGupta  _—«*4(15.08.1995 _ |DR-2019 13.04.2021 (F/N) F.1/ 4 (14)/2019-E.VIl
79143

52 |Kamal Kant Narang [18.05.1994 |DR-2019 01.06.2021 (F/N) F.1/ 4 (14)/2019-E.VIl
79144

53 [Shivam Kumar 04.04.1995 _|DR-2020 28.02.2022 (F/N) F.1/ 4 (14)/2020-E.Vil
Srivastav
79145

54 [Akshay Kumar Gurujil 10.12.1993 |DR-2020 28.02.2022 (F/N) F.1/ 4 (14)/2020-E.Vl
79147

55 Abhishek Kumar [04.10.1997 |DR-2020 28.02.2022 (F/N) F.1/ 4 (14)/2020-E.Vl
79146

56 |Antrix Gupta 21.04.1995 |DR-2021 13.02.2023 No. 2/5/2019-E.1B dated
79149 (F/N) 13.07.2020

57 |AnnesAbraham _ |13.03.1969 _|P-2017-18 19.12.2023 F,1/34(20)/2016-AP-3
79121

58 [Dimple Singh 69.1997 [DR-2021 25.01.2023 No. 2/5/2019-E.1B dated
Panwar (F/N) 13.07.2020
79148

59. [Ravi Shankar 02.07.1966 |P-2017-18 19.12.2023 F.1/34(20)/2016-AP-3
Srivastava F.1/34(23)/2023-AP.3
79123
per

<!-- page 8 -->

: >
F. No A-12028/08/2024-Admn II
60 |Gupta Vivek 7.12.1997 | DR-2022 21.08.2023 ~~ |No. 02-01/2022-Rech(ESE) — _
Vijaynarayan (F/N)
79150
61 _|Vinod Singh 04.05.1969 |P-2017-18 19.12.2023 ~ |F.1/34(20)/2016-AP-3 re
79124 F.1/34(23)/2023-AP.3
62. [Ankit Kumar 6.2.2000  |DR-2022 28.08.2023 No. 02-01/2022-Rectt(ESE)
79151 (F/N)
63 |Leela Kumari 09.01.1967 |P-2017-18 01.02.2017 F.1/34(20)/2016-AP-3
79125 F.1/34(23)/2023-AP.3
64 |Neha Bharti 21.12.1996 |DR-2022 04.09.2023 No. 02-01/2022-Rectt(ESE)
79152 (F/N)
65 _|J.Devarajulu 26-01-1965 |P-2017-18 20.12.2023 F.1/34(23)/2023-AP.3
69002
Garima Goel 10.6.1997  |DR-2022 06.09.2023 No. 02-01/2022-Rectt(ESE)
79153 (F/N)
67 |Sobhana R. Krishnan |14.05.1966 | P- 2018 20.12.2023 F.1/34(23)/2023-AP.3
69003
Vertika Kushwaha_|17.01.1992 |DR-2022 03.08.2023 No. 02-01/2022-Rectt(ESE)
79154 (F/N)
Tapas Ranjan Ghosh |06.06.1965 |P- 2018 20.12.2023 F.1/34(23)/2023-AP.3
69006
pl

<!-- page 9 -->

-8- .
F. No A-12028/08/2024-Admn II
70 |Sandeep Kumar  |05.06.1995 |DR-2022 “|16.11.2023 © No. 02-01/2022-Rectt(ESE)
79155 (F/N)
71 |C Ramesh Babu 15.08.1969 |P- 2018 20.12.2023 F.1/34(23)/2023-AP.3
69007
72 +|Naresh Bhandari 17.07.1964 |P-2019 31.07.2024 No.1/34(15)/2024-PD-6 Retired on 31.07.2024
69008
73 |Sikha Ghosh 24.01.1966 |P-2019 01.08.2024 No.1/34(15)/2024-PD-6
69007
74 |VSL Prasad 14.07.1965 | P-2020 01.08.2024 No.1/34(15)/2024-PD-6
69011
75 |Hoshiyar Singh 23.02.1967 |P-2021 01.08.2024 No.1/34(15)/2024-PD-6
Dabas
69012
76 |B.D Gaur 03.04.1968 |P-2021 31.07.2024 No.1/34(15)/2024-PD-6
69014
77 [Smitha V 05.04.1971 |P-2021 01.08.2024 No.1/34(15)/2024-PD-6
69016
78 |Snehunshu Kumar [21.06.1965 [P-2021 (01.08.2024 No.1/34(15)/2024-PD-6
Parui
69017
79 |GDRaju 01.07.1965 |P-2022 01.08.2024 No.1/34(15)/2024-PD-6
69018
पे
Yr

<!-- page 10 -->

-9-
F. No A-12028/08/2024-Admn II
80 |AVJeware 22.11.1967 |P-2022 01.08.2024 No.1/34(15)/2024-PD-6 .... |
69019
81 [Poonam Arora 08.03.1971 |P-2023 01.08.2024 No.1/34(15)/2024-PD-6
69020
82 |PramodJiPandey [23.10.1965 |P-2023 01.08.2024 No.1/34(15)/2024-PD-6
69021
83 [CG Rama Rao 06.06.1966 |P-2023 01.08.2024 No.1/34(15)/2024-PD-6
69022
wr
wr
