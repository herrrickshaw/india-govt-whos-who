---
doc_id: "d0ee9e71dcba0a98"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/62edff9bbdf595cd57ea004e6b4ab211.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment to Broadband Policy, 2004"
date: "2004-12-13"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "faa1a7bb8d1ea9eb"
---

<!-- page 1 -->

Government of India
Ministry of Communications & IT
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road
New Delhi-110 001
No.813-7/03-LR Dated:13" December, 2004
OFFICE MEMORANDUM
Subject: Amendment to Broadband Amendment to Broadband Policy 2004
, Amendment to Broadband Policy 2004
The following amendments to the Broadband Policy 2004 are
hereby issued:
है, After 2™ sub-para of para 3.3. the following para is inserted,
namely:
Other wireless installations with antenna height less than 5 metres,
above the rooftop of an authorised building. will also not require
SACHA clearance for such antenna,
2 In para 3.1(¢), the phrase “2.40 — 2.4835 MI Iz” is: substituted with
“2.40 ~ 2.4835 GHz", :
\ Lo
lye agj je]
(Jayant Kumar)
Director(LR-I)
