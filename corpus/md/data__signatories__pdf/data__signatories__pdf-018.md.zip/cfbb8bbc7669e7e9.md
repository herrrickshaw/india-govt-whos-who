---
doc_id: "cfbb8bbc7669e7e9"
source_url: "https://dohe-education.gov.in/static/uploads/2026/01/79c0b3a62c8d503635bdec7c95d9eb8b.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "First Amendment of Academic Bank of Credits in Higher Education Regulations, 2021"
date: "2021-12-28"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b59571690a15b95"
---

<!-- page 1 -->

.PsS- q. A.tr.r.- 33004/99

REGD. No. D. L. -33004/99

ETI

T

@he Gozette of

3 nd I o

cG-DL-E-28122021-23221 5

SRTI T{II

EXTRAORDINARY
SIFI IJI_ETEE 4

PART III-Sedion 4

fiB-{R+ssrfim
PUBLISHED BY AUTHORITY

rr. 6871

T€ffi,

{{ra-{R, ftsqt za, zozrlqtc z, rs,t:
NEW DELHT, TUESDAY, DECEMBER 28,2021/PAUSA 7, 1943

No.687l

frqfrsrcqqg<mqr*rr

qfAg{r
a€ 4..t, za ftqq{, zozr

ffi+re-q q-n-{r< sr+rr (E{il( lmrr + Ci;sR-+, +{ erym *Bq( ft rqrc-{r ft {qrc{) (m{{{nu-o
Rftqq,2021

Er. {.. 1+31/2018 (fffifi-q.-fruft-arrr+ wg{.o qT+{r BTIgG-{q, 19s6
q-nr zo
srr-ffi.r (J ) h ,js (q) eir 1a1 6rr r+r qrftdt qr r*q +G gq, fu*E-flrdq q-f<r-< qrqlrr ;*r rcnr
ryfi-fi + rl-.a-6nr B+rftarra-+ +t<n eT?if{r (r*+r ftren $ q+sft-r +fr 3iTr,*Eeq fi +rryqar 311riTf4{) EftTq, zozr ffirfua {qter< o.(rr
tqaF-{r riqT 14-31/201a 1*+t-rry a+t+

fi

26 q+r6, 20211 (Eq+

t

ff

*

t

qrt,Wffiqq,*sciiti<ftfr), Tr+d:-

{iftF {ft+6 dk ntv.1r1 qa ftffii fr frqft.qrcq argn vri:r (3-gm f,qt,n t !ffi{
48.1qft rrrrrlar fir riqraq) (T+q {.sira-{) ftft:rc, zozt s-t-r qr\nnl
(2) i qna * rr-qr* t eq+ Tsrqr;r ff ar-ftc i clTtfi fi
ar ftffi i afrqq z t:q-ftft+q t h err< q-. fte-c-d cq-ftfrqq m va.q6. ftqr qrqrr,
a'{ -qifu

r

iTrt{: -

(i ) afi{q 1 } 3q-ftftqq 12) ft rd +} 5rr rytr

-'i ftqffii q.i qrq-r qe.rBarqft arn
,Tfrc q;;q t +s,rri fr fr r+rrc n s.rr Errr mft-d 3Tt{ scrfd s-{T{
t
-Gi Aq ".. *
qBfrll'erir Eqlq sq t erfld-t-o ftq rrq *r

76iI GI tolI

(l)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

lP.\R r

lll Sr (.41

ftfi-qq z * w-fr'fi-qq 2 * aa it+r qrurnr
ftft-qq z * w-frfrTq 3, 4, 5 *{ 6 6l frcsr: 2, 3, 4 oltr 5 h F.r ii qgr qrg.nr

frgofr: {o frF-qq }rRC } rmq{, 3rtrurrur rrrq III, riis 4 ii sr. t. r4-31r2o18 (fi,ftff-r) + qrsqq t
n-<io za {q€, zozt fr s-nrlaril frq.rq tr
ft. -q-ffrr+{, qE-q
1tr-*rrr-ru+la-+r I s 5 I t 202 1 -221
.

UNIVERSITY GRANTS COMMISSION

NOTIFICATION
New Delhi, the 28th December.202t

University Grants Commission (Establishment and Operation of Academic Bank of Credits in
Higher Education) (First Am€ndment) Regulations, 2021

F. No. l4-31l2018(CPP-II),_-rn exercise of the powers confen.ed by clauses (f) and (g) of
sub-Section ( l) of Section 26 of the University Grants Comnrission ect. 1956, the Univer.sity
cr.ants
Commission rvith the approval of the Central Govemment hereby makes the following anrendmenr
in the
University Grants Commission {Establishnrent and Operation of Acadenric Bank oi Cre tlirs in Higher
E,h,cation) Regulations, 2021 [Notification No. l4-3 i/2018(cppJl) dared 28,hJuly. 2021] (hereinatier
referred to as 'the Principal Regulations,). narnely:
Short title and commencpment
- (l) These regulations rnay be called the Unir,ersity Grants
Commission (Establishment and Operation of Academic Bank of Ciedits iu Higher Education) (First
Amendment) Regulations, 202 l.
(2) Thcse shall come into force on the dare of its publication in the official Gazelc.
name ly:

In sub rcgulation I of the Rcgulations 7 of thc principal rcgulations follorving shall bc substirutcd.

(l) IJniversities and Autonomous Colleges satisfying sub-regulariol.l (2) of regulation I and the
Institutions of National- Importance as declared by thc Government of lidia and spccially
empowered by an Act of Parliament to confer or grant dcgrees.

The sub regulation 2 of rcgulations 7 shall bc omitted.
Sub regulations 3,4,5 and 6 ofregulation 7 shall be read as 2,3,4 and 5 rcspectivcly.

Note : The principal regulations were published.in the Gazerte oi India, Extraordinary pan III. Section 4
vide F. No. t4-31l201S(Cpp-I) dated 28th July,2021.
Prof-. RAJNISH JAIN, Secy.

IADVT.JIIi4/Exty.,55 I 202 I -22]

upl oaded by Dte. ol Printing at Govcrnmcnt of India Press, Ring Road, Mayapuri, Ncw Dclhi- l 1006".1
and Published by the Controller ofPublicarions. Delhi-l 10054. uno*"*;

<!-- page 3 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[P.AR r

lll

SL( .l

frfr 'q-q z h gq-frft-qq z fr aa ftqr qrl.nr

ftftqq z h sq-frF-qq 3, 4, 5 3lt{ 6 qit frq st : 2, 3, 4 dT 5 } -q i q-rr er.Tnr
ftFqfi; aqAfi-{q rrrrr * rrqrz, 3rfifirrr rrFr nt, ds 4 it $r. ri. 14-31/2018 (*ffi-il) T rTTerrr t
R-q1c za gqrf, 2021 ait rrrfifa ftq rrg tr

fi. -dffrri{, qkq
1ft*rw-r lv+/er+r I 5s 1 t 2021 -22)
.

UNIVERSITY GRANTS COMMISSION

NOTIFICATION
Nerv Delhi. the 28th December. 2021

University Grants Commission (Establishment and Operation of Academic Bank of Cre dits in
Higher Education) (First Amendment) Regulations, 2021

F. No. I4-3I /2018(CPP-II),-In exercise of rhe powers conf'erred by clauses (t) and (g) of
sub-Section ( l) of Section 26 of the University Grants Comnrission Act. 1956, the Uni\ crsitv Gmlrs
Commission with the approval of the Central Govemment hereby makes the follo.rving anren{nrcnt in the
University Granls Commission (Establishment and Operation of Acadcnric Bank O1' Credits in Higher
Education) Regulations, 2021 [Notification No. l4-31/2018(CPPJI) dared 28'r'July. 2021] (hereinafier
referred to as'the Principal Regulations'), namely:
Short title and commencement - (l) These regulations rnay be called the University Grants
Commission lEstablishment and Operation of Academic Bank of Crcdits in Highcr Education) (First
Amendment) Rcgulations, 202 l.
(2) These shall come into force on the date of its publication in thc Official Gazcttc.

In sub regulation I of the Rcgulations 7 of the principal regulations following shall bc substitutcd,
namely:

(l) Universities and Autonomous Collcges satisfying sub-rcgulation (2) of lcgulation I a1d tlrc
Institutions of National Importance as declared by the Governmcnt of India and specially
empoxered by an Act of Parliament to confer or grant degrccs.
The sub regulation 2 ofregulations 7 shall be onitted.
Sub regulations 3, 4, 5 and 6 ofregulation 7 shall be read as 2, 3. 4 and 5 respcctivcly.

Note : The principal rcgulations were published in the Gazette of India, Extraordinary Palt IIl. Section 4
vide F. No. l4-3 l/201 8(CPP-Il) dated 28'h July, 2021.
Prot. RAJNISH JAIN, Secy.
IADVT.lll/.1,'Exry. '55 I 2021 -22]

Uploaded by Dte. ofPrinting at Governmenl of India Press, Ring Road, Mayapuri, Ncw Delhi- l 100(r.l

andPub|ishcdbytheControIlerofPublicati(lns.Dclhi-lI0054.
