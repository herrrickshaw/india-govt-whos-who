---
doc_id: "cd9277f8ef7ba1dc"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/350da62a4180f59b735c9ff7835435e8.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code '1916' - Water Helpline"
date: "2018-09-25"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "48c703fc7298a31f"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No.16-3/2013/ AS-III/387/ ..f.? 8'6 /

Dated:lf:/09/2018

To,
All Access Service Providers.

Subject: Allotment of short code '1916' to Panchayati Raj & Drinking Water Department,
Govt. of Odisha for its "Water Helpline" regarding.
The undersigned is directed to convey the approval for allocation of short code '1916' to
Panchayati Raj & Drinking Water Department, Govt. of Odisha for its " Water Helpline" with
features as:
(i)

Category-I: Service (i.e. mandatory service to be provided by all the Access providers).

(ii)

Accessibility: Un-restricted i.e. available on STD also.

(iii)

Metered Service: Called Party Pays i.e. Call charges to be borne by Govt. of Odisha.

(iv)

Short code can be used for 2-way communications.

2.

All are requested to take necessary action.

3.

This is issued with the approval of DDG (AS-I).

Copy forwarded for information and necessary action, if any, to:
1.
Secretary, TRAI.
2.
CMD MTNL/ CMD BSNL.
3.
Additional Secretary-cum-Director, DWS, Panchayati Raj & D. W Deptt., Govt. of Odisha,
Secretariat, Sachibalaya Marg, Bhubaneshwar-751001, email-prsec.or@nic.in with a request to
appoint a nodal officer to implement the helpline.
4.
Director (P&N), DoT (HQ), (respective LSA field unit-Odisha LSA may be asked to co­
ordinate with respective Nodal Officers and TSPs for implementation of Helpline, as and when
approached).
5.
A copy for upload on DoT Website.
