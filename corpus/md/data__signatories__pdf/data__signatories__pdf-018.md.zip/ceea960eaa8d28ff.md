---
doc_id: "ceea960eaa8d28ff"
source_url: "https://dof.gov.in/static/uploads/2025/11/bb081ea81c034f318d3a04de30da1bae.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Expression of Interest For 'Establishing Nucleus Breeding Centres (NBC) In India' September, 2025"
date: "2025-11-25"
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5f0164940ee1245c"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF FISHERIES, ANIMAL HUSBANDRY & DAIRYING,
DEPARTMENT OF FISHERIES

EOI No. DOF/EOI/NBC/01

Dt. XX.06.2025

Expression of Interest
For

"Establishing Nucleus Breeding Centres (NBC) In India"
September, 2025

Place: New Delhi

Date: XX.04.2025

<!-- page 2 -->

Department of Fisheries
Ministry of Fisheries, Animal Husbandry & Dairying
Government of India
Krishi Bhawan, Dr Rajendra Prasad Road, Central Secretariat, New Delhi-110001
INVITATION FOR EXPRESSION OF INTEREST
Department of Fisheries, Ministry of Fisheries and Animal Husbandry & Dairying,
Government of India invites sealed Proposals from interested and experienced
firms/companies/organizations involved in domestication and breeding programmes of any
potential candidate species for coastal aquaculture to produce Specific Pathogen-Free (SPF)
Brood Stocks of L. vannamei, either independently or through a Joint Venture with the local
partner from India. EOI document containing the details of criteria, submission requirement,
objective, scope of work etc. can be downloaded from the website http://dof.gov.in.
Further details/queries, if any, may be obtained from Fisheries Development Commissioner,
Department of Fisheries, Ministry of Fisheries and Animal Husbandry & Dairying,
Government of India Krishi Bhawan, Dr Rajendra Prasad Road, Central Secretariat, New
Delhi-110001. Telephone No.91-23386379/E-mail: fdc-india@dof.gov.in during working
hours.
This is a rolling EOI. Sealed envelope marked to the below address, containing the proposal
with all relevant documents may be submitted mentioning "Expression of Interest for
establishing Nucleus Breeding Centres (NBC) for L. vannamei in India on the top of the
envelope.
The Joint Secretary (Marine Fisheries)
Department of Fisheries
Ministry of Fisheries and Animal Husbandry & Dairying
Government of India
Krishi Bhawan, Dr Rajendra Prasad Rd, Central Secretariat, New Delhi-110001

Fisheries Development Commissioner
Department of Fisheries,
Ministry of Fisheries and Animal Husbandry & Dairying, Government of India,
Krishi Bhawan, Dr Rajendra Prasad Rd, Central Secretariat, New Delhi-110001

<!-- page 3 -->

1. Objective
The Government of India aims to promote establishment of Nucleus Breeding Centres
(NBCs) for development of genetically superior and disease-free broodstock for fish and
shrimp species including L. vannamei in the country. This initiative is crucial for enhancing
aquaculture production, ensuring sustainability, and supporting seafood exports and in line
with ATMA NIRBHAR BHARAT. The program will encourage private sector participation
to set up domestication and breeding programs to produce Specific Pathogen-Free (SPF)
broodstock especially L. Vannamei. This effort aligns with the broader vision of improving
India's self-sufficiency in aquaculture and reducing dependence on foreign imports.
2. Background and Rationale
2.1 India's seafood exports have been growing at an average rate of 15% annually, reaching an
all-time high of USD 7.38 billion in 2023-24, a nearly 30% increase from 2020-21, with
brackish water shrimp as the leading commodity. The country has an estimated 12.40 lakh
hectares of potential brackish water for aquaculture, but only 15% is currently utilized,
demonstrating significant untapped potential.
2.2 The demand for L. vannamei broodstock from the commercial hatcheries in India is currently
estimated at 250,000 broodstock per annum. India's commercial hatcheries currently depend
on imported broodstock, quarantined at the Aquatic Quarantine Facility (AQF) in Chennai,
leading to higher costs and supply chain vulnerabilities. Three Broodstock Multiplication
Centres (BMCs) are operational in India to supply L. vannamei shrimp broodstock, but
domestic capacity needs further development. Ensuring biosecurity and disease-free
broodstock is critical to maintaining a sustainable and profitable aquaculture industry.
2.3 In pursuance of Section 3 of the Coastal Aquaculture Authority Act, 2005 (24 of 2005),
Guidelines for establishment and operation of Nucleus Breeding Centre and Broodstock
Multiplication Centres in India has been notified in Gazette vide 15th March, 2024 of India by
Department of Fisheries, Government of India
2.4 In the Union Budget 2024-25 Hon'ble Finance Minister announced financial support for
setting up a network of Nucleus Breeding Centres. The proposed NBCs will focus on
improving broodstock quality for key species, including Litopenaeus vannamei
3. Scope of Work & Project Goals
The establishment of NBCs will involve
3.1 Development of Genetically Superior Stocks: Creation of Specific Pathogen-Free (SPF).
broodstock.
3.2 Selective Breeding Programs: Implementation of advanced genetic selection techniques to
improve disease resistance, reproductive performance, and growth rates of broodstock
3.3 Private Sector Participation: Domestic and international firms with expertise in breeding
programs are encouraged to participate independently or via joint ventures with Indian
partners.
4. Eligibility Criteria: The CAA amendment rules provides for the followings:
(i) The Nucleus Breeding Centres and Broodstock Multiplication Centres shall be established for
increasing production and productivity of the coastal aquaculture sector in India by any

<!-- page 4 -->

existing producers of specific pathogen free broodstock as well those involved in
domestication and breeding programmes of any potential candidate species for coastal
aquaculture either from India or from overseas either independently or through a joint venture
with the local partner from the India.
(ii) An applicant organization possesses in the requisite experience and capabilities required
for establishment and operation of Nucleus Breeding Centres or Broodstock Multiplication
Centres may apply in Form-F-1 either individually (as sole organisation) or as lead partner
of a consortium of organisations (as lead partner) as per the extant rules, regulations and
procedure in force.
(3) The Applicants shall individually or collectively possess the following technical capacity
and experience, namely:(i) have successfully designed and operated a Nucleus Breeding Centres or
Broodstock Multiplication Centres for Litopenaeus vannamei or any such other
fish or shrimp species which has developed and maintained a minimum of 5
generations; and
(ii) have successfully developed and managed a minimum of 50 families of
Litopenaeus vannamei or any such other fish or shrimp species, through its own
research and development activities, in the last ten years.
(4) The applicants must have been engaged in the establishment and operation of at least one
Nucleus Breeding Centres or Broodstock Multiplication Centres assignment within the last five
years preceding the date of application and submit details thereof.
(5) The Genetic Improvement Programs and Nucleus Breeding Centre under the Government
shall be encouraged through Indian Council of Agricultural Research under the Department of
Agricultural Research and Education on a convergence mode with the other Ministries and
Department of Government of India including organization and other entities under them, the
State or union territory Governments and private entrepreneurs,
5. Prior permission for establishing Nucleus Breeding Centres or Broodstock Multiplication
Centres.5.1. The prior permission for establishing the Nucleus Breeding Centres or Broodstock
Multiplication Centresupon an application made under rule 11 of the said rules of CAA shall be
granted by the Central Government in the Department of Fisheries, Ministry of Fisheries
Animal Husbandry and Dairying, based on the recommendations of the following Project
Screening Committee:
(i)
(ii)
(iii)
(iv)
(v)
(vi)
(vii)

Joint Secretary (Marine Fisheries), Department of Fisheries
Secretary, Coastal Aquaculture Authority
Director, ICAR-National Bureau of Fish Genetic Resources
Director, Indian Council of Agricultural Research-Central
Institute of Brakishwater Aquaculture
Director, Indian Council of Agricultural Research - Central
Marine Fisheries Research Institute
Representative from Department of Economic Affairs or
Corporate Affairs
Project Director, Marine Product Export Development
Authority - Rajiv Gandhi Centre for Aquaculture

:
:
:
:

Chairperson/Chairman
Member
Member
Member

: Member
: Member
: Member

<!-- page 5 -->

5.2 The application under rule, 11 of CAA amendment rules shall contain but not limited to the
following, namely:
(i) general hackground and overview of the individual firm or consortium,
(ii) statement of qualification;
(iii) understanding of the assignment and scope;
(iv) work methodology:
(v) detailed mile stones;
(vi) domestic and international experience in design and operation of a Nucleus
Breeding Centre or a breeding programme (if any);
(vii) professional and local partners (if any);
(viii) technical team strength,
(ix) details of technology
(x) valid certificates of freedom from disease from the competent authority of the
Government issued in accordance with the World Organization for Animal Health
Code, for the facilities operated by the applicants.
5.3. The Project Screening Committee shall be assisted by a Technical and Inspection
Committee to be constituted by an order of the Central Government.
5.4. The Project Screening Committee shall scrutinize the applications received from time to
time and subject project site for physical verification and on-site inspection by the Technical
and Inspection Committee
5.5. The Technical and Inspection Committee shall conduct a physical verification and on-site
inspection and submit its report on the suitability of the site proposed for establishment of
Nucleus Breeding Centres or Broodstock Multiplication Centres before the concept
presentation by the applicant.
5.6. The Project Screening Committee shall scrutinize the applications received from time to
time and evaluate them through a concept presentation made by the applicant on the scheme of
development covering the following aspects, namely:
(i) brief background of the applicants and the details of Nucleus Breeding Centres or
Broodstock Multiplication Centres being operated by the applicants, as well as
experience, if any, of having provided services in any other project;
(ii) conceptual plans of the project including preliminary lay out and site plan, floor
plans, elevations, sections wherever necessary:
(iii) indicative area allocation for the different zones of the Nucleus Breeding Centres or
Broodstock Multiplication Centres,
(iv) expected features and functionalities of the proposed Nucleus Breeding Centres or
Broodstock Multiplication Centres;
(v) preliminary cost estimates for the development of project;
(vi) proposed selective breeding strategy that the applicant seeks to implement
including physical growth, freedom from disease with disease tolerance characteristics
and reproductive performance,
(vii) analysis of the historical outcomes of the research & development undertaken by
the applicants;

<!-- page 6 -->

(viii) presentation of the Standard Operating Procedure and manuals to be prepared for
the project by the applicants and the procedure to be adopted for developing distinct
families with least inbreeding
(ix) advantages of the technology and hio-security being provided by the applicants and
the rationale and benefits of such an approach.
5.7. The Project Screening Committee shall make its recommendation based on the report of
the Technical and Inspection Committee and the concept presentation to the Department of
Fisheries for grant of prior permission or otherwise by the competent authority to establish
Nucleus Breeding Centres or Broodstock Multiplication Centres.
5.8. The decision of the competent authority shall be conveyed to the applicant within ninety
days from the date of receipt of application.
6. General requirements:- (i) There shall be no aquaculture activities or Fish Landing Centres
or any other source of direct contamination within a radius of 1000 meters (one kilometer)
from the site selected for the establishment of the Nucleus Breeding Centres or the Broodstock
Multiplication Centres
(ii) The Nucleus Breeding Centres and Broodstock Multiplication Centres shall be in separate
locations and in case there is substantial cause, they may coexist within the same site with
adequate physical separation and isolation from each other with independent water supply and
discharge
(iii) There shall be adequate biosecurity measures to analyze and manage risks in the life and
health of candidate species including associated environmental risk for the prevention of
diseases in aquaculture.
(iv) The Nucleus Breeding Centres and Broodstock Multiplication Centres shall comply with
the requirements for biosecurity, in-house biosecurity audit, in house health monitoring and
disease surveillance and chain of custody sampling and testing as specified in the Guidelines
for the Health Monitoring, Disease Surveillance and Specific Pathogen Free Certification of
Coastal Aquaculture Units and Stocks in India and Aquatic Animal Health Code of World
Organisation for Animal Health.
7. Application Submission & Evaluation Process
7.1 Applications can be submitted individually or as Lead partner. The proposal must include
company background, qualifications, methodology, technology details, and disease-free
certification.
7.2 Shortlisted proponents must provide a 60 - minute presentation covering:
Background and experience
Presence in India and seed supply chain
Available Germplasm, its origin and performance indicators
Conceptual plans, layout, and site selection
Selective breeding strategies and expected outcomes
Biosecurity measures and technological advantages
Projected economic benefits and scalability potential
Training and skill development plans for NBC/ hatchery staff
7.3 The Project Screening Committee (PSC) constituted for this purpose will evaluate and
recommend the potential applicants.

<!-- page 7 -->

8. Support from Government of India:
8.1 The Government of India will provide support as follows:
(i) Pradhan Mantri Matsya Sampada Yojana (PMMSY)
The Pradhan Mantri Matsya Sampada Yojana (PMMSY) has been implemented as an
umbrella scheme provides for funding support for NBC under the sub component of Genetic
Improvement Programmes and Nucleus Breeding Centers (NBCs):
(ii) Fisheries and Aquaculture Infrastructure Development Fund (FIDF)

(a) Interest Subvention: Up to 3% per annum for all EEs for development of identified
fisheries-based infrastructure facilities including establishment of Nucleus Breeding
Centres (NBCs) for development of genetically superior and disease-free broodstock for
fish and shrimp species.
(b) Lending Rate of Interest: Not lower than 5% per annum for all EEs for development of
identified fisheries based infrastructure facilities.
(c) Repayment period: 12 years with moratorium of 2 years for re-payment of principle
amount.
(d) FIDF provides 25% credit guarantee facility to the projects of entrepreneurs, individual
farmers and cooperatives to be approved under FIDF during the extended period of 3
years from 2023-24 to 2025-26 from the existing credit guarantee fund of Infrastructure
Development Fund of Department of Animal Husbandry and Dairying.

8.2 The Department of Fisheries, Government of India, will also facilitate the allotment of
suitable sites for the selected proponents through the State Governments concerned.

8.3 Research & Development Collaboration: The initiative will encourage R&D partnerships
between the Government, private sector, and academic institutions. The Support of
research institution in India in the field of Fisheries will also be extended on all possible
areas of collaboration.
9. Conclusion
This initiative aims to boost India's aquaculture industry by ensuring high-quality, diseaseresistant broodstock for shrimp and fish farming. The Government of india seeks
participation from experienced firms, research institutions, and aquaculture specialists to
establish NBCs and enhance domestic breeding programs. Interested applicants are
encouraged to submit proposals as per the guidelines to contribute to India's expanding
aquaculture sector and strengthen the country's global seafood market presence. This effort
is expected to create a self-reliant, robust, and sustainable aquaculture ecosystem in India.
******

<!-- page 8 -->

Form- F-1
Application for prior permission to establish Nucleus Breeding Centre or Broodstock
Multiplication Centre
I.
II.
III.
1.
2.
3.
4.
5.
6.
IV.
1.
2.
3.
V.
1.
2
3.
4.
5.
6.
7.
8.
9.
10.
11.
VI
1.
2.
3.
4.
5.
6.
7.
VII

Name of the candidate species
Prior permission sought to establish Nucleus Breeding Centre or
Broodstock Multiplication Centre
Details of the proposing firm or consortium:
Name of the applicant (s) or firm (s) (Separate sheet may be attached for each
member in case of consortium)
Address
Date of incorporation and registration details
Field of operation
Details of Board of Directors and Managing Director with copy of
Memorandum of Association or Memorandum of Article
Certified a Audited financial statement of the firm for the last three years
Statement of qualification
Number of years of experience in the operation of Nucleus Breeding Centre or
Broodstock Multiplication Centre
Number of Nucleus Breeding Centre or Broodstock Multiplication Centre
designed or operated, candidate species and Number of families developed
and maintained in the last ten years (attach separate sheet)
Number of families developed and maintained through own research and
development activities in the last ten years
Details of source material:
Name of the overseas Specific Pathogen Free Facility
Address (including email ID)
Details of the firm:
Country of registration
Location of the facility
Terms and conditions of agreement with the Indian firms
Details of extent of commercial supply of Specific Pathogen Free broodstock
Details of any other Nucleus Breeding Centre or Broodstock Multiplication
Centre operated in anyother country
Reproductive performance of Specific Pathogen Free broodstock of the firm
in terms of Size at maturity, latency period for maturation, fecundity, Number
of spawning per female, hatching rate and survival rate at different stages
Performance of the stock in commercial culture for growth and disease
Copy of the Memorandum of Understanding or agreement indicating a firm
commitment for the supply of source material as per the requirement is to be
enclosed.
Detailed infrastructure and personnel of overseas Specific Pathogen Free
facility
Lay-out plan of the Specific Pathogen Free facility
(attach diagram with explanation)
Water treatment and supply
Rearing facilities
Laboratory facilities
Biosecurity (disinfection protocol, shower room, fencing, etc.)
Number of technical staff and details of their expertise (Attach biodata)
Financial status for last three years alongwith audited statement
Disease surveillance at the Specific Pathogen Free facility

<!-- page 9 -->

1.
2.
3.

List of pathogens excluded in the facility
Methodology followed for the diagnosis (or diagnostic protocolsfollowed)
Certificate (issued by Government) of disease free nature of the facility for the
last two years to be enclosed
4.
Frequency of surveillance
5.
Details of the diagnostic reports during the recent surveillance from a
Government authorised or World Organisation for Animal Health referral
laboratory
VIII. Details of selective breeding programme
1.
Source of Founder population (Number of geographic location or number of
Specific Pathogen Free facilities sourced)
2.
Genetic divergence of the population (Number of families from eachlocation
or each Specific Pathogen Free facility.
3.
Frequency of introduction of further families into founderpopulation
4.
Type of selection programme followed
5.
Number of lines and Number of families maintained
6.
Number of generations raised
7.
Minimum effective population size over the generations
8.
Traits considered for selection
9.
Genetic gain over the generations
10.
Name and brief bio-data of the geneticist involved in draftingthe breeding
plan
11.
Breeding plan indicating the specific details to avoidinbreeding
IX
Details of Indian Broodstock Multiplication Centre facility
1.
Annual capacity proposed (Number of broodstock per year)
2.
Requirements of Specific Pathogen Free Post Larvae and the frequency of
import
3.
Number of months of rearing proposed
4.
Survival anticipated during rearing from Post Larvae to broodstock
X.
Infrastructure facilities proposed
1.
Land area
2.
Location
3.
Whether any existing facility is being remodeled as Broodstock Multiplication
Centre? If so, indicate its prior use and the present condition
4.
Distance between the nearest hatchery or farm
5.
Lay-out plan of the posed facility indicating the quarantine, water intake and
treatment, rearing tanks under closed conditions, biosecurity features, Effluent
Treatment System, etc., indicate the capacity and number of tanks (attach
diagram with explanation)
6.
Details of the diagnostic laboratory facility
7.
Brief cost estimates and source of funding
8.
Technical staff proposed to be involved in the operation of Broodstock
Multiplication Centre and their brief bio-data indicating their area of expertise
9.
List of pathogens proposed to be tested in the Broodstock Multiplication
Centre and thesurveillance protocol to be followed
10.
Sampling details
11.
Frequency of sampling and testing
XI.
Any other particulars or details
****
