---
doc_id: "ced9d510d0c35eea"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/11/5786882786475663ac70ea858f6fc58e.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 20.10.2023 for the engagement of Shri Vinayaka S Pandit and Shri Ajay Prabhu M, Advocates as Central Govt. Counsel in the High Court of Karnataka (PB) at Bengaluru"
date: "2023-11-06"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "94090b016bfe9bfc"
---

<!-- page 1 -->

F. No. J-11017/28/2023-Judicial (2)
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
eK
Shastri Bhawan, New Delhi,
Dated the 20" October, 2023
ORDER
The President is pleased to engage following Advocates as Central Government
Counsel for conducting Central Government litigation before the High Court of Karnataka
(PB) at Bengaluru, as shown in the table below, for a period of three years with effect from
the date of this order: or until further orders, whichever is earlier:
HIGH COURT OF KARNATAKA (PB) AT BENGALURU
CENTRAL GOVERNMENT COUNSEL
i No. [Name of|Contact Details fa No.
[Advocates
(S/Shri)
1. Vinayaka S Pandit |14, SK Prerana, 1% Floor, KAR/215/2021
Nagappa Street, Near Sheshadripuram
College, Sheshadripuram, Bengaluru
Mob. 9449070521
Email: advocate.vinayakaspandit@gmail.com
2a Ajay Prabhu M_ [2680 A, 1% Floor, 11° Main Road, D KAR/1716/2018
Block, 2" Stage, Rajajinagar,
Bangalore- 560010
Mob: 8495966610
Email: ajayadv18@gmail.com
2. The engagement and professional fee of the aforesaid advocate: will be governed
by the terms & conditions contained in this Department's OM No. 26(2)/99-Judl. dated
24.09.1999 read with OM No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued
subsequently through OMs, especially the OM No. J-16/11/2017-Judical dated
08.02.2018.The aforesaid OMs are available on the website of this Department i.e.
www.legalaffairs.gov.in in the tab ‘Judicial Section’ under heading ‘Circulars pertaining to
litigations’.
3: Hindi version of this Order will follow. Lap \o १७१७
(Vijay Kumar Sharma)
Senior Adviser
Copy through email to:
1, PS to MoS (I/C) L&J.
2. Sr. PPS to Law Secretary/PSO to AS (RSV)/PSO to AS (RM) / Sr. PPS to AS (ARR) / Sr. PPS
to JS (SA).
3. PS to Attorney General of India/PS to Solicitor General of India/Addl. SGI for High Court of
Karnataka at Bengaluru.
4, The Incharge, Branch Secretariat, Bengaluru.
5. The panel counsel as above.
6. The Pay and Accounts Office, Department of Legal Affairs, New Delhi.
7. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
8. To be updated on the website of this Department i.e. www.legalaffairs.gov.in in tab
‘Judicial Section’ under the link 'Orders related to empanelment of Advocates for Uol' for 3
the information of all concerned. (०८६0४
9. Spare Copies. (0९५५1 2? 7
(Kumar Gaurav)
Section Officer (Judicial Section)
Tel: 011-23384945
Email: judicial-dla@nic.in
