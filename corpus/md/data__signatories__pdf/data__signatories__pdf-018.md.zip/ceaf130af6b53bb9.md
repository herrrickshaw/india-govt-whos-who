---
doc_id: "ceaf130af6b53bb9"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/788fdb4a309774c73ffb1b5b6f8d0e29.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Result of the Interview for appointment as Notary for the State of Maharashtra (held on 08.10.2018 to 30.10.2018)"
date: "2019-02-28"
pages: 228
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bcedf08c786dbda9"
---

<!-- page 1 -->

Government of India
Ministry of Law and Justice
Department of Legal Affairs
Notary Cell
****
Notary Cell, Department of Legal Affairs had conducted Interviews for
appointment as notaries for the State of Maharashtra from 08.10.2018 to 30.10.2018 at
Mumbai. The candidates were assessed keeping in view their competency, legal
knowledge and other relevant factors related to the selection of Notary as per
requirement of the Notaries Act, 1952, the Notaries Rules, 1956 and the relevant
guidelines by the Interview Board constituted for the purpose by the Central
Government. On the basis of the performance of the candidates before the Interview
Board, the Interview Board has recommended names of the following candidates for
appointment as notaries for the State of Maharashtra.

2.

All the successful candidates, whose names appear in the below mentioned list,

will be issued Appointment Letters for appointment as Notary shortly. The candidates
are strictly advised not to visit this Office personally for submission of any document or
for issue of certificate of practice. Only after receiving appointment letter from this
Department, the concerned candidate is required to send the documents mentioned in
the appointment letter. The certificate will be issued in due course of time.
BY THE ORDER OF THE
COMPETENT AUTHORITY
NOTARY CELL
28.02.2019

<!-- page 2 -->

S.No.

Interview
Sl.No.

Name

Category

Date of
App'n

Area Of
Practice

Father's Name

Address

1

1

Mrs.Yogini
Dinkar Kanade

OBC

18.08.14

Pune City

Dinkar
Bhagwantrao
Kanade

2

2

Nivangune
Ashok Suresh

Gen

20.08.14

Pune City

Nivangune Suresh
Shripati

3

3

Ms.Manjusha
Shashishekhar
Taday

Gen

21.08.14

Pune City

Shashishekhar
Shashank Taday

4

6

Ms.Vandana
Ghamanrao
Bhosale

Gen

12.08.14

Pune City

Ghamanrao
Narayanrao
Bhosale

5

7

Sandeep
Baburao Barve

SC

25.08.14

Nerul, Navi
Mumbai

Baburao Kondaji
Barve

6

9

Suhas Malhari
Surve

SC

22.08.14

Pune City

Malhari Rudrappa
Gotsurve

7

11

Muzaffar
Bashir Shaikh

Gen

Nil

Pune Distt.

Lt.Sh. Bashir
Ismail Shaikh

61, Hrishiyog, Near
Sahawas Hall, Panmala,
Pune Maharashtra-411030
Flat No.10, Kudale Patil
Towers S.No.30, Near
Anandnagar Telephone
Exchange, Sinhgas Road,
Vadgaon Bk.Pune
Maharashtra-411051
Flat No.101, B/5, Green
Fields, Near Antariksha
Society, Vastu Udyogm
Pimpri, Pune Maharashtra411018
706, Trimurtisangam, Bhagat
Marg, Sangamwadi, Pune
Maharashtra-411003
Flat No.201, A-Wing, Sun
Darshan Chs Ltd. 2nd Floor,
Plot No.8 To 10, Sector-10A, Behind Sai Baba Hotel
Nerul West Navi Mumbai
Maharashtra-400706
S.No.35/2, House No.1559,
Siddharth Niwas,
Dhankawdi, Pune
Maharashtra-411043
Plot No.16, Gulistan Building
3rd Floor, New Era Society,
Market Yard, Pune
Maharashtra-411037

Enrol. No.
MAH/1700/1991
Dt.10.10.91

MAH/1203/2002
Dt.25.06.02

MAH/1025/2001
Dt.11.04.01

MAH/362/1988
Dt.14.03.88

MAH/4393/2007
Dt.17.08.07

MAH/4723/2004
Dt.22.12.04

MAH/289/1985
Dt.26.02.85

<!-- page 3 -->

8

12

Pophale Dipak
Sitaram

Gen

26.08.14

Pune Distt.

Sitaram Ganpat
Pophale

9

13

Mahesh Vijay
Taware

SC

22.08.14

Satara Tehsil
And Distt.

Vijay Mahadev
Taware

10

14

Ms.Jyoti
Shirishkumar
Diwakar

Gen

22.08.14

Satara Tehsil
And Distt.

Shirishkumar
Shashikant
Diwakar

11

15

Sunil Tyagi

Gen

27.08.14

Bandra East
Mumbai

Lt.Sh.Yashvir
Singh

12

16

Hari Nath
Sharma

Gen

16.08.14

Bhayander
Thane

Ramajor Sharma

13

19

Ms. Vaishali
Jagdish
Harwadekar

Gen

28.08.14

Andheri West
Mumbai

Jagdish
Harwadekar

14

20

Asha Narayan
Landge

SC

25.08.14

Byculla (W)
Satara

Narayan Vitthal
Landge

15

21

Namdeo Gopal
Thardak

OBC

26.08.14

Daryapur Tehsil

Lt.Gopal Motiramji
Thardak

Survey No.84/165,
P.M.C.Colony, 6/3,
Shastrinagar, Near Police
Station, Paud Road,
Kothrud, Pune Maharashtra411038
At.Post Nagthane, Tehsil
And Distt. Satara
Maharashtra-415519
Radhey Plot No-62,
Arkashala Nagar, Shahupuri,
Satara Maharashtra-415002
706, 7th Floor, 'A'wing
Nityanand Sagar Chs Ltd.
Opp, Evershine Enclave,
Sheetal Nagar, Mira Road
East Distt.Thane
Maharashtra-401107
B/110, Nirmal Park No.6,
Co-Op.Hsg.Society
S.V.Road, Bhayander East
Distt.Thane Maharshtra401105
D/201, Bldg.No.9, 2nd Floor,
Laxmi Ratan Hasg. Society,
Ratan Nagar 4 Bunglows,
Andheri (W) Mumbai-400053
2/44, B.I.T.Chawl,
Opp.Godrej Tower,
K.K.Marg, Satrasta, Byculla
(W), Mumbai Maharashtra400011
Civil Line Daryapur,
Tq.Daryapur Distt.Amravati
Maharashtra-444803

MAH/3454/2004
Dt.23.08.04

MAH/1510/2007
Dt.03.07.07
MAH/352/1996
Dt.31.01.96

MAH/1621B/1990
Dt.08.09.90

MAH/1378/1994
Dt.10.08.94

MAH/555/2000
Dt.02.03.2000

MAH/920/1996
Dt.30.03.96

MAH/1134/1999
Dt.27.03.99

<!-- page 4 -->

16

22

Powar
Subhash
Shankarrao

17

23

Shri Sunil
Mulchandani

Gen

21.06.14

Distt.Thane/Kal
yan

Ludanaml
Kalyandas
Mulchandani

18

24

Pradip
Uttamrao
Shinde

Gen

Nil

Local Nanded
Distt.

Uttamrao Dhondji
Shinde

19

25

Supriya R.Patil

Gen

22.08.14

Islampur

Ranjit Shamrao
Patil

20

26

Gupta Dinesh
Kumar

OBC

16.08.14

Nagpur City

Mansaram

21

29

Jitendra
Subhash Wani

Gen

01.09.14

Jalgaon Distt.

Subhash
Vishvanath Wani

22

31

Jayprakash
Mihsra

Gen

04.09.14

Vasali
Nallasopara
Virar Thane

Shambhunath
Mishra

23

32

Nitin Sushil
Kumar Bhat

Gen

01.09.14

Nagpur

Sushil Kumar Bhat

24

34

Rajesh
Ramchandra
Patil

OBC

03.09.14

Dhule

Ramchandra
Pandit Patil

Gen

22.08.14

Kolhapur Distt.

Powar Shankarrao
Dada

4/229, Powar Galli, Mothe
Tale, Ichalkaranji Tal.
Hatakanangale
Distt.Kolhapur MaharashtraFlat No.11-12, Neelam CoOperative Housing Society
Ltd. O.T.Section Ulhasnagar
Distt.Thane Maharashtra421003
At.Village Bachegaon, Post
Dhanora (Bk) Via Kherkheli,
Tq. Dharmabad, Distt.
Nanded MaharashtraPatil Galli, Near Siddnath
Temple, Urun Islampur
Tal.Walwa Distt. Sangli
MaharashtraShivshakti Timki Bazar,
Nagpur Maharashtra-440018
Sitakunj, Nashirabad,
Tal.And Dist. Jalgaon
Maharashtra-425309
G/702, 7th Floor, Reliable
Complex, Phase No-Ii,
Nagarpalika Road, Near
Rajiv Gandhi School,
Nallasopara (W), Tal.Vasai
Distt.Thane Maharashtra401203
193-B, Pande Layout,
Khamla Nagpur
Maharashtra-440025
34, Shrikrushna Colony
Deopur Dhule Tal And
Distt.Dhuve Near Akaswani
Kendra Maharashtra-424005

MAH/893/1986
Dt.21.07.86

MAH/1789/1991
Dt.20.10.91

MAH/ 2357/2002
Dt.27.08.02

MAH/3874/2001
Dt.07.11.01
MAH/2142/2005
Dt.15.07.05
MAH/1343/2003
Dt.18.06.03

MAH/2833A/2002
Dt.14.09.02

MAH/1860/1993
Dt.16.09.93
MAH/442/1997
Dt.08.08.97

<!-- page 5 -->

25

35

Pawar
Himmatrao
Akaram

Gen

05.09.14

Distt.Sangli

Pawar Akaram
Ramchandra

26

36

Nirmala
Kantilal Vyas

Gen

31.05.14

Mahim, Mumbai

Kantilal
Dwarkadas Vyas

27

37

Pravinkumar
Keshav
Tapase

OBC

05.09.14

Nagpur Distt.

Keshavrao Tapase

28

38

Prashant
Vishnu Tikare

OBC

05.02.14

Throughout
Maharashtra
State

Vishnu Baburao
Tikare

29

40

Lankesh
Ashok
Gajbhiye

SC

09.09.14

Tah.Kalmeshwa
r

Ashok Natthuji
Gajbhiye

30

41

Gen

09.09.14

Mukhed Tq.
Mukhed
Distt.Nanded

31

43

SC

00.08.14

Mumbai

32

44

OBC

19.08.14

Nagpur

Manikrao
Pundlikrao
Subhedar
Ghanshyam
Baburav
Sonawane
Shankarrao
Sakharamji
Supare

33

50

OBC

Nil

Distt.Thane

Yeshwant
Manikarao
Subhedar
Abhaya
Ghanshyam
Sonawane
Ravindra
Shankarrao
Supare

Bapu Holambe

Vitthalrao

A/P.Ranjani, Tal.Kavathe
Mahankal, Distt.Sangli
Maharashtra-416411
21-A, 2nd Floor, Mawji
Mansion 15-Balamiya Lane,
Mahim Mumbai
Maharashtra-400016
457, Chandan Nagar, Near
Medical Square, Nagpur
Maharashtra-440009
3/22/B, Swati Manor,
J.K.Sawant Marg, Dadar
(West), Mumbai
Maharashtra-400028
At-Mhasepthar, Po-Mohpa,
Tehsil Kalmeshwar,
Distt.Nagpur Maharashtra441502
Shivaji Nagar Mukhed
Tq.Mukhed Distt.Nanded
Maharashtra-431715
168-C-10, Kiran CHS Gorai2, Borivali West Mumbai
Maharashtra-400092
149, Chandramouli, Ganesh
Nagar Nagpur Maharashtra440009
Room No.18, Vishnu Patil
Bhuvan, Navapada,
Subhash Road, Dombivali
(W) Taluka Kalyan
Distt.Thane Maharashtra-

MAH/1937/2001
Dt.31.07.01
MAH/2651/2005
Dt.04.08.05
MAH/2799/1995
Dt.15.11.95
MAH/2694/1995
Dt.10.10.95

MAH/190/2005
Dt.24.01.05
MAH/5349/1999
Dt.25.10.99
MAH/646/2005
Dt.21.02.05
MAH/744/1999
Dt.27.03.99

MAH/569/2005
Dt.21.02.05

<!-- page 6 -->

34

51

Krishna Dutta
Dwivedi

Gen

Nil

Andheri
Vileparle
Santacruz

Umanath Dwivedi

35

52

Metar Abdul
Suleman

OBC

05.09.14

Goregaon West
Mumbai

Metar Suleman
Kasam

36

53

Arun Siwach

Gen

15.09.14

Union Of India

Umed Singh

37

55

Yogesh
Devidas
Hatagade

OBC

11.09.14

Pune Distt.

Devidas
Shankarrao
Hatagade

38

56

Revati Amol
Shelar

OBC

09.09.14

Pune Distt.

Amol Pandurang
Shelar

39

57

Gen

11.09.14

Pune Distt.

Raghu Namdeo
Salunke

40

58

Gen

06.09.14

Pune Distt.

Laxman Narayan
Ladkat

41

60

OBC

06.09.14

Distt.Osmanaba
d

Gurao Ramrao
Hanmantrao

Pandurang
Raghu
Salunke
Narendra
Laxman
Ladkat
Gurao
Khanderao
Ramrao

Bldg. No.12/C, Room
No.107, Gokul Niwas,
Sangharsh Nagar,
Chandivali, Andheri East
Mumbai Maharashtra400072
A/1102 Shepherd Residency
Chs.Ltd.Opp. Bmc School,
Mitha Nagar, Goregaon
West Mumbai Maharashtra400104
204 Charkop Safalya CHS
Ltd. Sector-03, Charkop
Kandivali West Mumbai
Maharashtra-400067
Adarsh Chawl, Rajeev
Gandhi Nagar, Near
Ramrajya School Upper
Bibwewadi, Pune
Maharashtra-411037
Shelarwada Near Ganpati
Mandir Katrajgaon Pune
Maharashtra-411046
6/4 Pleasant Park,
Bhairobanala, Pune
Maharashtra-411013
Flat No.6, Pandhare Heights,
203/204, Somwar Peth,
Pune Maharashtra-411011
H.No.18, 19 Ward No.4, Shri
Ram Niwas Near Hanuman
Temple Omerga Tq. Omerga
Distt.Osmanabad
Maharashtra-413606

MAH/1128/B/19
83 Dt.01.08.83

MAH/3629/2007
Dt.02.08.07

MAH/1549A/1994
Dt.05.09.94

MAH/2104/2004
Dt.15.07.04

MAH/2434/2006
Dt.15.07.06
MAH/3650/2002
Dt.19.12.02
MAH/1352/1999
Dt.27.03.99

MAH/2028/2003
Dt.31.07.03

<!-- page 7 -->

42

61

Vilas
Madanrao
Dhamne

43

62

Jayant
Sudhakarrao
Dani

Gen

12.09.14

Nagpur Distt.

Sudhakarrao
Vinayakrrao Dani

44

64

Kagade Jairam
Haridas

Gen

06.08.14

Ghatkopar
West Mumbai

Kagade Haridas
Bhaurao

45

65

Balaji
Chandrakant
Deshmane

OBC

04.09.14

Tuljapur Distt.
Osmanabad

Chandrakant
Mukundrao
Deshmane

46

66

Vijay Murlidhar
Wagh

Gen

12.09.14

Dhule Division
Distt.

Murlidhar Ganpat
Wagh

47

67

Gen

15.09.14

Taluka-Pathardi
Distt.
Ahmednagar

Sambhaji Kundik
Shirsat

48

69

OBC

06.09.14

Nagpur

Babanrao
Narayanrao Ghate

49

71

Limbaji Sirsat

SC

09.09.14

Kalamnuri And
Revenue
Courts At

Laxman Sirsat

50

72

Bhaskar
Kisanraoji
Kautikkar

SC

01.09.14

Achalpur
Distt.Amravati

Kisanraoji
Motiramji
Kautikkar

51

76

Sandipkumar

Gen

25.09.14

Parbhani Distt.

Balkishanji Bajaj

Surekha
Pandurang
Sawant
Mrunal
Babanrao
Ghate

Gen

03.09.04

Aurangabad

Madanrao Sanduji
Dhamne

95, Near Mata Mandir,
Pisadevi, Tq.And
Distt.Aurangabadmaharashtr
aMangalwari Peth, Umrer,
Tq.Umrer Distt.Nagpur
Maharashtra-440001
Shivkrupa Chawl, No.4,
Room No.8/B, Indira Nagar
No.1 Sainath Road,
Ghatkopar West Mumbai
MaharashtraA/P Tuljapur (Khurd)
Tq.Kuljapur
Distt.Osmanabad
Maharashtra-413601
7, Govind Hari Apartment,
Plot No.60, Janki Nagar,
Wadi Bhokar Road, Deopur
Dhule Maharashtra-424002
35/3, Dipak Niwas, Nr.Sai
Apartment, Vittalwadi,
Akurdi, Pune Maharashtra314, Hanuman Nagar, Near
Mahatma Gandhi Garden
Nagpur Maharashtra-440009
Shastri Nagar, Kalamnuri Tq.
Kalamnuri Distt.Hingoli
Maharashtra-431702
At.Savali Datura, Post,
Dhotarkheda Ta.Achalpur
Distt.Amravati Maharashtra444805
Hotel Rohit Inn Near Bus
Stand, Parbhani
Maharashtra-431401

MAH/2582/2003
Dt.11.08.03
MAH/533/1998
Dt.15.05.98

MAH/632/1991
Dt.26.06.91

MAH/2472/2007
Dt.17.07.07

MAH/669/1996
Dt.12.03.96
MAH/2176/2004
Dt.15.07.04
MAH/5490/2005
Dt.20.12.05
MAH/2644/1995
Dt.10.10.95
MAH/2521/2001
Dt.04.09.01
MAH/1121/2004
Dt.19.04.04

<!-- page 8 -->

52

77

Nilesh Naresh
Bagul

Gen

25.09.14

Distt.Pune

Naresh Shamrao
Bagul

53

79

Jayabhaye
Manoj Vishnu

OBC

16.09.14

Ahmednagar
Distt,

Jayabhaye Vishnu
Ranoji

54

80

Nitin Sahebrao
Shingate

Gen

06.09.14

Vilaspur Godoli
Satara

Sahebrao Sitaram
Shingate

55

81

Aniruddha
Arvind Joshi

Gen

05.09.14

Shivnagar
SambhajinagarSatara

Arvind Ganesh
Joshi

56

82

Mamta
Chandrakant
Parab

Gen

08.09.14

Maharashtra

Chandrakant
Vishnu Parab

57

83

Ravindra
Traymbak
Sonawane

OBC

30.09.14

Amalner
Distt.Jalgaon

Tryambak Manga
Sonawane

58

84

Prashant
Popatrao
Khamkar

Gen

05.09.14

Shahunagar
Godoli Satara

Popatrao Narayan
Khamkar

59

89

Mahendra
Arvind
Nangare

OBC

25.09.14

Distt.Pune

Arvind Sitaram
Nangare

Flat No.13, B Wing Arjun
Baug, Raikar Mala, Dhayari
Gaon, Dhayari Pune
Maharashtra-411041
Flat No.211, Shilavihar,
Vasant Tekadi, Shriram
Chouck, Pipeline Road,
Savedi, Tal.Nagar
Dist.Ahmednagar
MaharashtraPlot No.7, Sitaram Sadan
Giridarshan Grahanirman
Co-Op.Hsg.Soc., Godoli,
Behind Hotel New Ajantha
Vilaspur Godoli Satara
Gujarat-415004
Amoghsiddhi Plot No.3,
Shivanagar Colony,
Sambhajinagar Satara
Maharashtra-415004
401, Vrindavan, Behind
Canara Bank,Bangur Nagar,
Goregaon Maharashtra400104
Kumbhar Tek, Amalner
Tal.Amalner Distt.Jalgaon
Maharashtra-425401
Saksh Plot No.38,
Sr.No.170/C, Hill Top
Garden Soc.Charbhinti
Shahunagar Godoli Satara
Maharashtra-415002
161/16 Gokhale Nagar
Taluka-Haveli Distt.Pune
Maharashtra-411016

MAH/2309/2004
Dt.15.07.04

MAH/2826/2001
Dt.17.09.01

MAH/175/1999
Dt.25.01.99

MAH/113/2003
Dt.08.01.03

MAH/3170/2001
Dt.01.10.01
MAH/3561/2002
Dt.04.12.02

MAH/1721/2001
Dt.04.07.01

MAH/1684/2006
Dt.07.07.06

<!-- page 9 -->

60

90

Ganesh
Vasudeo
Mukane

61

91

Poonam
Palwade

OBC

12.09.14

Parli Vaijnath
Distt.Beed

Dattatraya
Palwade

62

92

Satywan
Bharat Shinde

SC

16.09.14

Parel Mumbai

Bharat Shivram
Shinde

63

93

Shefali Desai

Gen

29.05.14

Andheri West
Mumbai

Krishnakant Desai

64

94

Sanjay
Ramrao
Deshmukh

Gen

09.09.14

Latur Distt.

Ramrao
Ganpatrao
Deshmukh

65

95

Kiran Karan
Chawla

Gen

Nil

Greater
Mumbai And
Distt.Thane

Karan Ramesh
Chawla

66

96

Damodar
Maruti
Bhalerao

SC

24.09.14

Nashik Distt.

Maruti Abaji
Bhalerao

SC

16.09.14

PanvelDistt.Raigad

Vasudeo Baburao
Mukane

Krishna Aangan Plot No.7ab,
Flat No.201,202, Survey
No.41/2, Devad, Tal.Panevel
Distt.Raigad Maharashtra410206
Dattakrupa Nath Nagar,
Nath Road, Parli V.Tq.Parli
V.Distt.Beed Maharashtra431515
Municipal Transits Camp
Chawl No.2, Room No.19,
Jerbai Wadia Road, Behind
Sasural Hotel, Parel
Bhoiwada, Parel Mumbai
Maharashtra-400012
A/58/1208, Azad Nagar,
Veera Desai Road Andheri
West Mumbai-400058
Kulswamini Niwas, In Front
Of Ganesh Tel Vikri Kendra
Prakash Nagar Latur
Maharashtra-413531
Flat No.12, A Wing E
Bldg.Apsara Apartment,
Gawde Nagar S.N.Dubey
Road, Rawalpada, Dahisar
East Mumbai Maharashtra400068
8, Dharmanath Housing
Society, Bhimnagar, Jail
Road, Nashik Road
Maharashtra-422101

MAH/4419/2007
Dt.17.09.07

MAH/1477/2001
Dt.04.07.01

MAH/5052/2007
Dt.02.09.07

MAH/2188/2001
Dt.31.07.01
MAH/4458/1999
Dt.18.08.99

MAH/1198/2007
Dt.17.05.07

MAH/1225/1995
Dt.18.04.95

<!-- page 10 -->

67

103

Chandrakant
Shankar Dalvi

Gen

18.08.14

Maharashtra
State

Shankar Sadashiv
Dalvi

68

104

Tayade
Pradnyashil
Dalpatrao

SC

23.09.14

Jalgaon Distt.

Tayade Dalpatrao
Supadu

69

105

OBC

12.09.14

Additional Distt.
And Session
Court Darwha

Ambadas
Shankarrao Kathle

70

108

Gen

30.09.14

Distt.Pune

Balshiram Mahadu
Chaskar

71

112

Ashok Harish
Chandra
Asthana

Gen

00.09.14

Andheri West
Mumbai

Lt.SH.Harish
Chandra Asthana

72

116

Rakesh
Goverdhandas
Chandnani

Gen

09.10.14

Washim Distt.

Goverdhandas
Virumal
Chandnani

73

117

Deepa
Ghanshyamda
s Khatwani

Gen

09.10.14

Washim Distt.

Ghanshyamdas
Ishwarlal Khatwani

74

118

Walmik
Mahadeo
Mhatre

SBC

14.08.14

Tal And Dist.
Thane Navi
Mumbai

Mahadeo Sitaram
Mhatre

Santoshi
Ambadas
Kathle
Santosh
Balshiram
Chaskar

504, Prabhu Ashish Chs Ltd.
Old Mhb Colony, Gokhale
College Road, Borivali West
Mumbai Maharashtra400091
Plot No.11, Dhammadip
Sambhaji Nagar, Near
Gadgebaba Chowk, Jalgaon
Tal.Distt.Jalgaon
Maharashtra-425002
East Vardhaman Nagar
Darwha Distt.Yavatmal
Maharshtta-445202
At/Post-Mahalunge Padwal,
Tal-Ambegaon, Distt.Pune
Maharashtra-410515
Flat No.701, 7th Floor,
Building No-4B,
Patliputranagar, Link Road
Oshiwara, Jogeshwari West
Mumbai Maharashtra400102
Behind Honda Showroom, In
Front Of Zilla Parishad
School, Washim
Tq.Distt.Washim
MaharashtraSantoshi Mata Nagar, In
Front Of Z.P.Akola Naka
Road, Washim Tq.Distt.
Washim MaharashtraTalwali Gao Near Hanuman
Mandir Po.Ahansoli Tal And
Distt.Thane Navi Mumbai
Maharashtra-400701

MAH/113/1987
Dt.21.01.87

MAH/4343/2004
Dt.06.10.04

MAH/851/1997
Dt.17.11.97
MAH/2397/2004
Dt.15.07.04

MAH/153E/1977
Dt.12.02.77

MAH/4099/2004
Dt.14.09.04

MAH/1294/2004
Dt.19.04.04

MAH/1059/2002
Dt.11.06.02

<!-- page 11 -->

75

121

Rajvilas
Devanand
Bhimte

76

122

Shammi Vinad

Gen

13.08.14

Distt.Nagpur

Abdul Ghani Vinad

77

123

Dhanashree
Charuchandra
Nirantar

Gen

08.10.14

Pune City

Charuchandra
Keshav Nirantar

78

124

Ms.Sunanda
Rajaram Patil

Gen

08.10.14

Karad
Distt.Satara

Rajaram Rau Patil

79

125

Gen

26.09.14

Mangalwedha

Chandrakant
Krishnaji Jadhav

80

126

Gen

16.10.14

Nagpur

Prashant
Purushottam
Chobe

81

128

Ratan Kumar
Singh

Gen

31.07.14

Andheri
Mumbai

Shitala Prasad
Singh

82

129

Osmany Ali
Azam
Mohd.Zamin

Gen

Nil

All Maharashtra

Mohd.Zamin Ali
Azam

83

130

Mukhtar
Amirjan Saiyed

Gen

01.10.14

Trombay
Mumbai

Amirjan Peer
Saiyed

Dhananjay
Chandraknat
Jadhav
Pranita
Prashant
Chobe

SC

23.01.14

Kamptee Tehsil
Nagpur Distt.

Devanand
Badrinath Bhimte

Plot No.103, Yashodhara
Nagar, Near Madi Mandir,
Ghorpad Road, Kamptee
Tehsil Kamptee Distt.Nagpur
Maharashtra-441002
Rai Gulmohar Apartment,
Wing-2, Flat No.2, Near
Teka Naka, Nagpur
Maharashtra-40000
Survey No.85/1/1, Suman
Shilp Phase-1, B-704,
Parande Nagar, Pune Alandi
Road, Dighi Pune
Maharashtra-411015
Vishranti A 11/01 Near
Urban Bazar Koyana
Vasahat, Tal-Karad DisttSatara Maharashtra-415539
Arohi Nagnewadi
Mangalwedha Distt.Solapur
Maharashtra-413305
D-30, State Bank, Colony,
Rajnagar Katol Road,
Nagpur Maharashtra-440013
Pragati Nagar, Collector
Compound, Mahakali Caves
Road Andheri East Mumbai400093
79/3, Baliani Gaon, Taluka
Kalyan Distt.Thane
Maharashtra-400070
Noor House, Paily Pada,
Near Masjid, Trombay
Mumbai Maharashtra-88

MAH/961/2005
Dt.22.03.05

MAH/2012/2001
Dt.31.07.01

MAH/3304/2007
Dt.02.08.07

MAH/2024/1994
Dt.09.11.94
MAH/538/1993
Dt.02.04.93
MAH/1052/1992
Dt.25.06.92
MAH/44-A/1993
Dt.09.01.93
MAH/663/1999
Dt.27.03.99
Dt.31.01.96

<!-- page 12 -->

131

Mrunal
Govindrao
Tambe

Nil

Nashik Distt.

Govindrao
Ramchandra
Tambe

85

133

Shaha Rajesh
Hiralal

Gen

10.10.14

Peth Vadgaon
TalHatkanangale
Distt. Kolhapur

Shaha Hiralal
Popatlal

86

134

Sudha Sunil
Jain

Gen

01.10.14

Dhule Distt.

Sunil P.Jain

87

137

Alase Shabbir
Mohammad
Imam

OBC

08.10.14

Sangli Distt.

Alase Imam Kasim

88

139

Neeta Dipak
Chavan

Gen

07.04.14

Kolhapur Distt.

Dipak Shankarrao
Chavan

89

141

Narayan
Baburao
Bhandigare

Gen

14.11.14

Kolhapur Distt.

Baburao Tukaram
Bhandigare

90

142

Amruta Anil
Patole

Gen

14.11.14

Kolhapur Distt.

Anil Vinayak
Patole

91

143

Sudhakar
Baburao
Dhonde

OBC

11.09.14

Ahmednagar
City

Baburao Kundlik
Dhonde

84

Gen

Flat No-1, Kasturi Yog
Society, Shankar Nagar,
Takli Road, Dwarka, Nashik
MaharashtraYash Basti Road Peth
Vadgaon Tal-Hatkanangale,
Dist.Kolhapur Maharashtra416112
22-A, Shivshankar Colony,
Chitod Road, Dhule
Maharashtra-424001
Nadives, Koli Galli, Shastri
Chowk, Miraj Tal.Miraj
Distt.Sangli Maharashtra416410
A/P.Suyash Nivas Behind
Sadhana High School
Gadhinglaj, Tal.Gadhinglaj
Distt. Kolhapur MaharashtraA/P.735/6 Plot No.2,
Radhika Gharkul Yojana
Nale, Colony, Sambhaji
Nagar Kolhapur
Distt.Kolhapur Maharashtra416007
A/P.54/E Ward, Patolewadi,
In Front Of India Auto
(Ruikar Colony) Kolhapur
Distt.Maharashtra-416005
Plot No.14, Suryodaya
Vivekanand Colony, Near
Bhide Hospital, Savedi,
Ahmednagar Maharashtra414003

MAH/3281/2000
Dt.27.11.2000

MAH/363/1991
Dt.12.03.91
MAH/818/1993
Dt.12.06.93
MAH/1364/1995
Dt.06.06.95

MAH/1087/2002
Dt.11.06.02

MAH/437/1997
Dt.08.08.97

MAH/151/1997
Dt.26.04.97

MAH/676/1982
Dt.25.06.82

<!-- page 13 -->

92

146

Rajurkar Rajan
Madhavrao

93

147

Singapure
Balaji
Venkatrao

OBC

29.10.14

Distt.Latur

Singapure
Venkatrao
Madhavrao

94

149

Rishi Rao
Sonawane

OBC

11.11.14

Jalgaon Distt.

Prakash Rao
Sonawane

95

151

Kishor Kanha
Patil

OBC

18.10.14

Raigad Distt.

Kanha Dharma
Patil

96

152

Madanrao
Kundlikrao
Undal

OBC

18.10.14

Risod
Distt.Washim

Kundlikrao
Govindrao Undal

97

153

Sadashiv
Marutirao
Maradkar

Gen

06.11.14

Distt.Latur

Marutirao
Maradkar

98

154

Narendra
Mohan Mishra

Gen

29.10.14

Distt.Court
Taluka And
Distt.Thane
Navi Mumbai

Yamuna Mishra

99

161

Ranjeet Robert
Pereira

OBC

17.10.14

Saloli Vasai
Distt.Palghar

Robert Nicholas
Pereira

100

164

Pinjari Suresh
Manohar

OBC

19.11.14

Tal.Madha,
Distt. Solapur

Pinjari Manohar
Bhiva

SC

06.09.14

Taluka And
Dist.Nanded

Rajurkar
Mahavrao Kondiba

Nagsennagar, Post
Yashwantnagar
Tq.Distt.Nanded
Maharashtra-431602
Sewabhumi, Mataji Nagar,
Ring Road, Latur Tq.And
Distt. Latur Maharashtra413512
Plot No.85, Nehru Nagar
Mohadi Road, Jalgaon
Maharashtra-425001
H.No.275, Murbi Village,
Sector-19, Kharghar, Navi
Mumbai, Taluka Panvel,
Distt.Raigad Maharashtra410210
Matru Kuti Plot No.40, Anant
Colony, Risod Tq.Risod
Distt. Washim Maharashtra444506
Wasangaon Tq.And
Distt.Latur Maharashtra413531
Apartment No.B-2/23/5,
Sector-16, Vashi Navi
Mumbai Maharashtra400703
Maria, In Front Of Rationing
Shop, Dolbhatwadi, Saloli,
Vasai (W) Distt.Palghar, (Old
Thane) MaharashtraA/P-Madha, Tal-Distt.
Solapur Maharashtra413209

MAH/2095/2006
Dt.15.07.06

MAH/1462/2007
Dt.03.07.07
MAH/53/2006
Dt.24.01.06

MAH/4797/2006
Dt.23.09.06

MAH/1105/1987
Dt.03.09.87
MAH/430/2001
Dt.24.04.01
MAH/656FF/2000
Dt.12.02.2000
MAH/3527/2006
Dt.09.08.06
MAH/1208/2002
Dt.25.06.02

<!-- page 14 -->

101

165

Sachin Omkar
Bansod

SC

22.11.14

Gondia

Omkar Lahanu
Bansod

102

166

Bhalerao
Sangharsh

SC

21.11.14

Distt.Latur

Bhalerao Ramesh
Sambhaji

103

168

Milind
Shamrao
Chavan

Gen

13.12.14

Rajapur
Distt.Ratnagiri

Shamrao Maruti
Chavan

104

169

Shyamsunder
Vishwambhar
Dangat

Gen

30.10.14

Maharashtra
State

Vishwambhar
Nagorao Dangat

105

173

Bhushan
Vitthalrao
Behare

OBC

14.11.14

Warud
Amrawati

Vitthalrao
Laxmanrao
Behare

106

180

Vasant
Prabhakar
Katarnavare

SC

Nil

Ambernath
Dist.Thane

Prabhakar Ganpat
Katarnavare

107

184

Ukla Babsaheb
Ingawale

Gen

19.11.14

Pune

Babasaheb
Ingawale

108

188

Ms.Shilpa
Aviraj Pol

SC

19.11.14

Pune City

Aviraj Pol

109

190

Ms.Pallavi
Totala

Gen

08.11.14

Jalgaon Distt.

Vishal

Ramabai Ward, Ambatali,
Gondia Tehsil Gondia
Maharashtra-441614
Coil Nagar Zopadpatti,
Building No.C Room No.1 To
3, Back Side Rajasthan High
School Latur Maharashtra
1078 Sai Nagar, Kodavali,
Tal. Rajapur Distt.Ratnagiri
Maharashtra-416702
02, Devi Krupa Chs, Plot
No.131, Sector-4 Airoili Navi
Mumbai Maharashtra400708
Indira Chowk, Warud
Tq.Warud Distt.Amrawati
Maharashtra-444906
Flat No.302, Aries
Apartment, Nr.Bethel
Church, Ambernath (W)
Tal.Ambernath Distt.Thane
Maharashtra-421501
Pimple Nilakh, Gouri
Shankar Complex, 3rd Floor,
Pune Maharashtra-27
Sr.No.12/1, Yashodeep
Building, Next To
Yashodeep Flour Mill,,
Pawar Nagar, Theraon,
Chinchwad Pune
Maharashtra-411033
Prem Plot No.12/3,
Vallabhnagar Nr.Church And
Collector Bunglow Jalgaon
Maharashra-425002

MAH/3495/2007
Dt.02.08.07
MAH/3453/2007
Dt.02.08.07
MAH/3316/1999
Dt.05.05.99
MAH/1704/2004
Dt.15.07.04
MAH/6187/2008
Dt.08.11.08

MAH/1964/2000
Dt.29.08.2000

MAH/529/2000
Dt.02.03.2000

MAH/3734/2007
Dt.02.08.07

Mah/5429/2005
Dt.20.12.05

<!-- page 15 -->

110

191

Suresh
Vishvanath
Jadhav

111

193

Shahin Sharif
Shaikh

Gen

08.11.14

Pune City

Sharif Hussain
Shaikh

112

194

Mumtaz
Rajekha
Shaikh

Gen

Nil

Pune City

Rajekha Rasul
Shaikh

113

197

Shankar
Sheenappa
Karkera

Gen

26.11.14

MulundMumbai

Sheenappa
K.Karkera

114

198

Vinay Gotiram
Patil

OBC

18.11.14

Mumbai/Thane

Gotiram Gauru
Patil

115

199

Jadhav
Ramesh
Mahadev

Gen

Nil

Thtoughout
Solapur Distt.

Jadhav Mahadev
Yeshwan

116

200

Dodha Doulat
Ahire

SC

19.11.14

Bhandup And
Mulund And Gr
Mumbai

Doulat Budha
Ahire

117

203

Kulkarni
Renukadas

Gen

13.11.14

Risod

Devidas
Ganpatrao

OBC

07.11.14

Pune Distt.

Vishvanath Vitthal
Jadhav

Shewale Niwas, S.No.198,
Near Lakadi Wakhar,
Sadesatra Nali, Hadapsar,
Pune Maharashtra-411028
P-1, Nasheman Villa, Survey
No.62, Saibabanagar, Near
Ashoka Summit, Kondhwa
Khurd Pune Maharashra411048
Kamal Niwas, Dattanagar
Kiwale, Dehu Road, Pune
Maharashtra-412101
3/D, Heritage Apartment Chs
Ltd Flat No.501/502/503 5th
Floor, Rohidas Nagar,
Ganesh Gawade Road,
Mulund West Mumbai
Maharashtra-400080
R.No.3, Shree Ganesh
Niwas, Opp.Mulund Court,
J.S.D.Road Mulund (W)
Mumbai Maharashtra400080
A/P- Sangramnagar, Tal.
Malshiras Dist.Solapur
Maharashtra-413101
D/27, Nav-Yashodhara CoOp.Housing Soc. Bhandup
Village East Mumbai
Maharashtra-400042
Near St.Stand Samarth
Nagar Risod Tq.Risod Distt.
Washim Maharashtra444506

MAH/1778/2007
Dt.03.07.07

MAH/3022/2007
Dt.17.07.07

MAH/360/1994
Dt.14.02.94

MAH/2151/1993
Dt.08.11.93

MAH/2900/2002
Dt.24.10.02

MAH/94/1983
Dt.19.01.83
MAH/1184/1990
Dt.21.08.90

MAH/1975/1999
Dt.27.03.99

<!-- page 16 -->

118

204

Dhoke Dinesh
Yashwant

Gen

19.09.14

Nashik Distt.

Dhoke Yashwant
Laxman

119

205

Ansari Afzal
Ahemad
Ab.Majeed

OBC

12.12.14

Nashik Distt.

Abdul Majeed
Mohd.Yusuf

120

207

Bhagawan
Karpa Sable

OBC

27.10.14

Mangrulpir

Karpa Rangarao
Sabale

121

208

Awachate
Gaurishankar
Dewaji

OBC

02.12.13

Gondia Distt.

Dewaji G.
Awachate

122

209

Anil Jaideo
Mahakal

OBC

02.12.14

Akola Distt.

Jaideo Ganpat
Mahakal

123

215

Ishwar
Ramsing Patil

Gen

05.12.14

Chopda
Tal.Distt.Jalgao
n

Ramsing Amrut
Patil

124

218

Bhagat Vishnu
Babadev

Gen

01.12.14

Pune Distt.

Bhagat Babadev
Ganpati

125

225

Bhaskar
Govindrao
Deshpande

Gen

14.10.14

Digras Darwha
Distt.Yavatmal

Lt.Govindrao
Rajeshwarrao
Deshpande

126

228

Shinde
Bhagyashri
Babji

Gen

02.12.14

Pune City

Shinde Babji
Ganpat

Plot No.38, Shiv Nagar, Near
Talathi Colony, Dindori
Road, Meri Panchavati,
Nashik Maharashtra-422004
H.No.149, Bhudwar Ward,
Teen Kandil, Malegaon
Dist.Nashik Maharashtra423203
Washim Road, Near Shinde
Colony, Mangrulpir, Tq.
Mangrulpir, Dist. Washim
Maharashtra-444403
Tadgaon.Arjuni/Mor.
Tah.Arjuni/Morgaon
Distt.Gondia Maharashtra441701
Vanmala Bakal Residency,
Ranpise Near Sawant Wadi,
Akola Maharashtra-444005
Gat No.1132/1, Plot No.35
Shivaji Nagar, Yawal Road,
Chopda Dist.Jalgaon
Maharashtra-425107
Flat No.2, Stilt Floor,
Samarth Elegance,
S.,No.38, Kaleoadal,
Hadapsar, Pune
Maharashtra-411028
Ambika Nagar, Digras
At.Po.Digras Tq. Digras
Dist.Yavatmal Maharashtra445203
At./Post Hiware Tarfe
Narayangaon, Tal- Junnaer
Distt.Pune Maharashtra410504

MAH/712/1997
Dt.23.10.97

MAH/954/1984
Dt.26.07.84

MAH/2652/1995
Dt.10.10.95

MAH/4628/2004
Dt.28.11.04
MAH/108/1984
Dt.16.01.84
MAH/1327/1993
Dt.06.08.93

MAH/2108/2000
Dt.29.08.2000

MAH/546/1987
Dt.21.05.87

MAH/4288/2007
Dt.17.08.07

<!-- page 17 -->

127

229

Barsawade
Murudula
Purushottam

Gen

04.12.14

Pune City

Barsawade
Purushottam
Krishnaji

128

231

Pandurang
Vitthal
Nimbalkar

Gen

06.12.14

Punr City

Vitthal Maruti
Nimbalkar

129

233

Kavita Sharma

Gen

24.11.14

Greater
Mumbai

Sharadkumar
Sharma

130

234

Sharma
Tribhuwannath

Gen

20.12.13

Court Andheri
(E)

Ganga Prasad
Sharma

131

235

Krishn Kant
Shukla

Gen

12.07.12

Kandivali (W),
Greater
Mumbai

Ram Nayen
Shukla

132

236

Sushil
Laltaprasad
Mishra

Gen

12.07.12

Kandivali (W),
Greater
Mumbai

Lt.Sh. Laltaprasad
Mishra

133

237

Suhas
Dattaram
Ghag

Gen

21.08.14

Greater
Mumbai Region

Dattaram

134

239

Adkar Vijay
Kumar Pandit

Gen

09.12.14

Tal.Madha,
Distt. Solapur

Adkar Pandit
Soudagar

Survey No.51, Neraji
Subhashchandra Marg,
Road No.3, Bhairav Nagar,
Dhanori Road, Vishwantwadi
Pune Maharashtra-411015
S.No.77/1/2/5, Azad Colony
No.3, Jyotiba Nagar,
Kalewadi Pimpri Pune
Maharashtra-411017
C-26, Hiramani C.H.Soc.
Dadabhai Cross Road-2
Anhderi West Mumbai
Maharashtra-400058
Prakash Wadi, Room No.5,
Andheri Kurla Road, Andheri
(E) Mumbai Maharashtra400093
Room No.7, Laxmi Estate,
Near Church, Khirani Road,
Sakinaka, Mumbai-400072,
Maharashtra
Flat No.507, Bldg. No.15,
Subham Co-Op. Hsg. Soc.
Ltd., Csc (Mhada), Kandivali
(W), Mumbai-400067
504, Sea Crest Bldg. No.1,
5th Floor, 7 Bunglow,
J.P.Road, Andheri West
Mumbai Maharashtra400061
A/P-Madha Tal-Madha
Dist.Solapur Maharashtra413209

MAH/1001/1998
Dt.06.08.98

MAH/3129/2003
Dt.16.09.03

MAH/6074/2007
Dt.03.11.07

MAH/36/2000
Dt.27.01.2000

MAH/1385/2001
Dt.16.06.01

Mah/2309/1995
Dt.17.08.95

MAH/1419/1982
Dt.03.12.82

MAH/147/2004
Dt.06.01.04

<!-- page 18 -->

135

241

Suresh
Sadashiv
Meshram

SC

15.12.14

Nagpur

Sadashiv
Raghunath
Meshram

136

242

Kale Vaijanath
Narayanrao

OBC

20.12.14

Taluka
Manwath
Dist.Parbhani

Kale Narayan
Tatyaba

137

243

Rajesh Kumar
Singh

Gen

Nil

Bandra East
Mumbai

Akhand Pratap
Singh

138

244

Shailesh
Mohan
Deshpande

Gen

15.12.14

Ajara Tal.Ajara
Distt.Kolhapur

Mohan Shankar
Deshpande

139

245

Shivaji Baliram
Sathe

Gen

16.12.14

Latur Distt. And
Pune City

Baliram Sopan
Sathe

140

248

Dilip Vitthal
Wagh

SC

Nil

Mumbai/Thane

Vitthal Kalu Wagh

141

249

Deepa Mani

OBC

07.11.14

Mumbai

Manikuttan E.J.

142

250

Gyanendra
Kumar Tiwari

Gen

12.12.14

Greater
Mumbai And
Thane Distt.

Chandrabhushan
Tiwari

Rani Durgawati Square, NIT
Complex, Flat No.A-5, 1st
Floor, Nagpur-17
MaharashtraNear I.T.I Gate, Pathri Road,
Manwath Taluka Manwath
Distt.Parbhani Maharashtra431505
Gurudatta Koli Samaj,
Ramgad Near Raheja
Hospital, Opp. New Police
Colony, Building No-1,
Mahim West Mumbai
Maharashtra-400016
At.Ganpat Galli, Ajara,
Tal.Ajara Dist. Kolhapur
Maharashtra-416505
Suraj Behind ICICI Bank 3rd
Road, Ram Nagar Latur
Maharashtra-413531
Panchasheel Nagar, Patil
Chawl, Behind Mulund Court
Mulund West Mumbai
Maharashtra-400080
63/701, B-Wing, Metro
Residency, Tilak Shanti
CHSL Tilak Nagar Chembur
Mumbai Maharashtra400089
Flat No.201, 2nd Floor,
Sargam Tower, Gaurav
Galaxy-1, Near Nityanand
Nagar Mira Road East
Thane Maharashtra-401107

MAH/710/1998
Dt.01.07.98

MAH/1189/1993
Dt.30.07.93

MAH/3672D/1999
Dt.12.07.99

MAH/166/1991
Dt.24.01.91
MAH/1453/1987
Dt.07.11.87
MAH/2986/2001
Dt.01.10.01

MAH/5818H/1999
Dt.30.12.99

MAH/1644/2002
Dt.12.07.02

<!-- page 19 -->

252

Kankaria
Nemichand
Dagduramji

Gen

16.12.14

Patoda

Kankariya
Dagduram

144

254

Nipane
Ashwini
Narendra

Gen

26.12.14

Kolhapur Distt.

Nipane Narendra
Hanmantrao

145

255

Gen

16.12.14

Loha, Tq.Loha
Distt Nanded

Raosaheb
Gaikwad

146

260

Gen

09.01.15

Ahmednagar

Gandhi Bansilal
Bhagwandas

147

263

Vijaysinha
Rane

Gen

18.08.14

Yavatmal Distt.

Narayansinha
Rane

148

264

Kekan
Shamrao
Shrimat

OBC

26.12.14

Ahmednagar
Distt.

Kekan Shrimant
Sayaji

149

267

Bora
Bhagyashree
Sunil

Gen

15.12.14

Shirur Pune
And
Ahmednagar
Area

Lt.Sh.Chandrakant
Chunilal Kothari

150

268

Ratnamala
Vikrant Tigote

SC

29.12.14

Pune City

Vikrant Vishnu
Tigote

151

269

Suresh
Babanrao
Rankhame

SC

23.12.14

Pune Distt.

Baburao
Pandurang
Kamble

152

273

Satish Bhaskar
Mahajan

OBC

14.01.15

Jalgaon Distt.

Bhaskar Sadashiv
Mahajan

143

Bhagwan
Raosaheb
Gaikwad
Gandhi
Ghewarchand
Bansilal

At/Po.Patoda.Tq. Patoda
Dist.Beed Maharashtra414204
Plot No.44, Mukta Sainik
Vasahat, Post Market Yard,
Kolhapur Maharashtra416005
Shivkalyan Nagar, Loha, Tq.
Loha Dist. Nanded
Maharashtra-431708
3335, Burudlane Corner
Dharti Chowk Ahmednagar
Maharashtra-414001
14, Chhatrapati Nagar
Waghapur, Post Waghapur
Tq. And Distt. Yavatmal
Maharashtra-445001
Plot No.20, Yashashree,
Lekha Nagar, Pipeline Road,
Ahmednagar Maharashtra1742/4/3 Barmecha Plaza,
Pabal Phata, Shirur Tal.Shirur Dist.Pune
Maharashtra-412210
2172, New Modikhana,
Camp, Pune Maharashtra411001
18th Queens Garden,
Building C, Room No.13,
Gen.Arunkumar Vaidya
Marg, Camp, Pune
Maharashtra-411001
2, Pratap Nagar, Khajamiya
Road Jilha Peth, Near Petrol
Pump Jalgaon Maharashtra425001

MAH/566/1974
Dt.24.09.74
MAH/1734/1998
Dt.23.11.98
MAH/5645/1999
Dt.22.12.99
MAH/13/1969
Dt.03.01.69
MAH/1096/1980
Dt.01.10.80
MAH/2500/2001
Dt.04.09.01
MAH/1836/2004
Dt.15.07.04
MAH/1043/2000
Dt.20.06.2000

MAH/289/1998
Dt.26.03.98

MAH/1214/1992
Dt.18.07.92

<!-- page 20 -->

153

276

Bhausaheb
Bhagwanrao
Latpate

OBC

Nil

Beed

Bhagwanrao
Wamanrao
Latpate

154

277

Ms.Jagjeet
Kaur B.Gill

Gen

03.01.15

Chandrapur
Distt.

Balkar Singh Gill

155

279

Milind
Prabhakar
Ovhal

SC

08.01.15

Pune Distt.

Prabhakar
Shantaram Ovhal

156

282

Varsha
Subhash
Takawale

Gen

09.01.15

Pune Distt. And
City

Subhash Tukaram
Takawale

157

283

Rajendra
Narayanrao
Shinde

Gen

03.01.15

Pune Distt.

Narayanrao
Laxmanrao Shinde

158

285

Anant Satupa
Kamble

Gen

07.01.15

Taluka
Chandgad Distt.
Kolhapur

Satupa Rukmana
Kamble

159

289

Krishna Hujara
Tagtode

SC

18.12.14

Solapur Distt.

Hujara Babu
Tagtode

160

290

Trupti
Shashikant
Rotkar

Gen

26.12.14

Wardha

Shashikant
A.Rotkar

161

291

Kashmira
Suryakant
Kurani

Gen

18.12.14

Nagpur

Suryakant Haridas
Kurani

Latpate Niwas, Balepeer,
Amrai Nagar Road, Beed Tq
And Distt. Beed
Maharashtra-431122
Pawan Heritage Appt. Flat
No.G-1 Omkar Nagar Haweli
Garden Road Chandrapur
MaharashtraAt And Post-Milindnagar,
Tehsil Vadgaon- Maval
Dist.Pune Maharashtra412106
C/O Gadre, 90/751,
Laxminagar, Parvati, Near
Gajanan Maharaj Math Pune
Maharashtra-411009
Torna Kamdhenu Esate,
C/4, Hadapsar Pune
Maharashtra-411028
1351, Yashoda Nivas,
Vinayaknagar Chandgd
Taluka Cahndgad
Dist.Kolhapur Maharashtra416509
Pandharpur Road, Sambhaji
Nagar, Near Gas Godown,
Mohol, Tal-Mohol, Distt.
Solapur Maharashtra413213
Near Sai Mandir, M.G.Road,
Wardha Tehsil And Distt.
Wardha Maharashtra442001
Ashok Bhawan, Pothi Lane,
New Itwari Road, Nagpur
Maharashtra-440002

MAH/865/1997
Dt.17.11.97

MAH/1390/2001
Dt.16.06.01

MAH/6402/2007
Dt.23.11.07

MAH/2777/2007
Dt.17.07.07
MAH/1822/1990
Dt.08.11.90

MAH/204/1991
Dt.31.01.91

MAH/1372/1995
Dt.06.06.95

MAH/518/2001
Dt.08.01.01
MAH/1425/1998
Dt.08.09.98

<!-- page 21 -->

162

294

Quazi
Sagiruddin
Hamiduddin

163

295

Shilpa Rajesh
Sutar

Gen

23.12.14

Kolhapur Distt.

Rajesh Maruti
Sutar

164

298

Jayant Eranna
Gajool

SBC

18.12.14

Pune Distt.

Eranna Narayan
Gajool

165

303

Jyotsna
Sambhaji
Kamble

SC

17.12.14

Pimpri City

Sambhaji
Ramchandra
Kamble

166

304

Thombare
Sunil Mahadeo

SBC

17.12.14

Ghodegaon Tal.
Ambegaon
Distt.Pune

Thombare
Madadeo Tukaram

167

306

OBC

23.12.14

Aurangabad

Nagorao Nabaji
Wankhede

168

309

Gen

19.11.14

Thane

Dunstan Philip
Dias

169

310

Rahul
Krishnarao
Desai

Gen

20.12.14

Kolhapur Distt.

Krishnarao
Ramchandra
Desai

170

311

Gajanan
Appaso Patil

Gen

22.12.14

Kolhapur City
And Distt.

Appaso Babanna
Patil

Shankar
Nagorao
Wankhede
Mrs.Gwendilen
e Michael
D'mello

Gen

19.12.14

Aurangabad

Quazi Hamiduddin
Muniruddin

H.No.3/1/69, New Building
Opp. Masjid, Barudgar Nala,
Aurangabad Maharashtra431001
Mangalmurti R.S. No.75/12,
15, Plot No.17, Bharati
Nagar Morewadi, TalKarveer, Dist.Kolhapur
Maharashtra-416013
193, Rukmini Apartment,
Flat No.2, Rasta Peth, Pune
Maharashtra-411011
Maruti Complex, B Building
Room No.23, Near Ashok
Theatre Pimpri Pune
Maharashtra-411017
A/P-Manchar ( Near Maruti
Mandir), Tal. Ambegaon,
Dist.Pune Maharashtra410503
Galli No.1, Suryawadi,
Jadhavwadi, Tq.And Dist.
Aurangabad MaharashtraC-1/57 B-7, Shreerang
Society Thane (W)
Maharashtra-400601
204, Vastushree Gardens,
Behind Telephone Bhavan,
Tarabai Park, Kolhapur
Maharashtra-416003
A/P.Mugali, Tal. Gadhinglaj,
Dist. Kolhapur Maharashtra416551

MAH/3758/2003
Dt.17.11.03

MAH/2706/2006
Dt.29.07.06

MAH/1137/1991
Dt.01.08.91
MAH/48/2003
Dt.08.01.03

MAH/458/1993
Dt.12.03.93
MAH/3171/2003
Dt.16.06.03
MAH/2791/2000
Dt.16.10.2000
MAH/1876/1999
Dt.17.01.99
MAH/750/2001
Dt.01.03.01

<!-- page 22 -->

13.10.14

Tal.And Distt.
Thane CBD
Navi Mumbai

Ram Sambhaji
Pandit

26.12.14

Andheri East At
Greater
Mumbai And
Thane Distt.

Tilak Dhari
Sharma

313

Ms. Vaishali
Ram Pandit

314

Rajesh
Sharma

173

315

Mukund
Vasantrao
Nalkande

OBC

01.08.14

Daryapur

Vasantrao
Narayanrao
Nalkande

174

316

Riyaz Harun
Ghaniwale

Gen

01.08.14

Daryapur

Harun Umar
Ghuniwale

175

319

Girdhari
Sadaranglal
Baisani

Gen

31.12.14

Yavatmal Tq
And Distt.

Sadaranglal
Lahrumal Baisani

176

322

Rahul
Balasaheb
Raje

Gen

10.09.14

Risod City

Balasaheb
Nilkanthrao Raje

177

323

Vipula
Dhondiram
Haridas

Gen

27.01.15

Pune City

Dhondiram
Ganesh Haridas

178

325

Santosh Gopal
Chavhan

SC

25.11.15

Kalyan City And
Distt. Thane

Gopal Anand
Chavhan

171

172

SC

Gen

A-302, Prince Palace
Building, Sector-II, Plot
No.14/15 Kharghar
Maharashtra-4102010
Bldg. No.B/5, Flat No.404,
Rashmi Star City, Juchandra
Road, Naigaon East
Distt.Thane Maharashtra401208
Mrudgandh Main Road,
Banosa Daryapur Tq.
Daryapur Distt. Amrawati
Maharashtra-444803
Ward No.1 Shivaji Nagar
Banosa, Daryapur
Tq.Po.Daryapur
Distt.Amrawati Maharashtra444803
Opp. Ayurwedi College,
Shivaji Nagar, Yavatmal Tq
And Distt. Yavatmal
Maharashtra-445001
At + Wanoja Post-Asegaon
Pen.Ta.Rbod Distt.Washim
Maharashtra-444506
B-18, Pradnyesh Apt.Near
Gananjay Society, Unit-4,
Shastrinagar Kothrud Pune
Maharashtra-411038
Room No.2747, Santosh
Grain Stores, Near Nagnath
Mandir, Methal Nagar,
Ambernath (W), Tal.
Ambernath Distt. Thane
Maharashtra-

MAH/1066/2007
Dt.09.04.07

MAH/3358A/1999
Dt.10.05.99

MAH/281/2002
Dt.04.02.02

MAH/2588/2000
Dt.16.09.2000

MAH/662/1991
Dt.25.06.91
MAH/3049/2008
Dt.08.07.08
MAH/1624/2005
Dt.24.06.05

MAH/3187/2006
Dt.29.07.06

<!-- page 23 -->

OBC

19.12.14

Majalgaon
Distt.Beed

Sirajuddin

Gen

13.01.15

Mhaswad

Lt.Sh. Shantaram
Bhimaji Dombe

Dadaji
Bapurao
Gedam

ST

12.01.15

Pune City

Bapurao Deorao
Gedam

346

Indrajit Ashok
Dongre

Gen

Nil

Pune Distt.And
Session Court

Ashok Vasantrao
Dongre

183

347

Ramesh
Nilkanthrao
Datir

OBC

16.01.15

Yavatmal Distt.

Nilkanthrao Punjaji
Datir

184

352

Supriya
Santosh
Patange

Gen

30.01.15

Pune City

Santosh Manohar
Patange

185

360

Nilesh Mohan
Harale

SC

22.01.15

Ahmednagar
Distt.

Mohan Dagadu
Harale

186

361

Sukhada
Sachin Dipnaik

Gen

22.01.15

Ahmednagar
Distt.

Sachin Sahadeo
Dipnaik

187

362

Santosh
Anandrao
Kharat

Gen

27.01.15

Jalna

Anandrao

179

334

180

335

181

345

182

Syed
Naimoddin
Uttam
Shantaram
Dombe

Raj Galli Mahalgaon Distt.
Beed Maharashtra-431131
A/P-Mhaswad, Tal-Man,
Dist. Satara Maharashtra415509
S.No.191, Nagpur Chawl,
Near Sai Baba Mandir,
Yerwada Pune Maharashtra411006
S.No.137/4/2, Trishul Nagar,
Nanded Phata, Sinhgad
Road, Dhayari Pune
Maharashtra-411041
Near Shrikrushna Talkies
Digras, Tq. Digras
Dist.Yavatmal Maharashtra445203
525, Rasta Peth, Daruwalla
Bridge Pune Maharashtra411011
Sr.No.207/3/1, Bhingardive
Mala, Bhutkar Wadi,
Ahmednagar Maharashtra414001
Plot No.6, Hari Priya Colony,
Behind Asara Society, Near
Janta School, Opp. Yashoda
Nagar, Pipeline Road,
Savedi Ahmednagar
Maharashtra-414003
Near Chanakya Complex,
Opp. Faisal Complex, Old
Court Road, Old Jalna
Maharashtra-431213

MAH/584/2000
Dt.02.03.2000
MAH/1629/1990
Dt.12.10.90
MAH/3657/2003
Dt.17.11.03

MAH/1915/1998
Dt.10.11.98

MAH/1124/2000
Dt.20.06.2000
MAH/1023/2006
Dt.10.04.06
MAH//627/2007
Dt.01.03.07

MAH/66/2002
Dt.17.01.02

MAH/1630/1999
Dt.27.03.99

<!-- page 24 -->

188

364

Babasaheb
Kashinath
Londhe

189

366

Shaikh Parvez
Ahmed Nisar
Ahmed

OBC

17.01.15

Distt.Dhule

Nisar Ahmed Sher
Mohammed

190

367

Pradnya Salil
Amrute

Gen

09.01.15

Pune Distt.And
Session Court

Salil Amrute

OBC

04.02.15

HUDCO At
Aurangabad

Lt.Motilal Kisanrao
Amadate

Gen

02.02.15

Kolhapur Distt.

Mangave
Shivkumar
Nilkanth
Keshawarao
Santoshrao
Helonde

191

368

192

370

Manjusha
Motilal
Annadate
Mangave
Umesh
Shivkumar

SC

21.01.15

Aurangabad
Taluk And Distt.

Kashinath
Tukaram Londhe

OBC

09.03.15

Shrikrishna
Nagar, Falilpura
Katol, Tehsil
Distt. Nagpur

193

371

Nilesh
Keshawarao
Helonde

194

372

Abdul Jaleel
Abdul Razak

Gen

13.12.13

Parbhani

Abdul Razak Sk.
Maheboob

195

374

Ms.Reshma
J.Yadav

Gen

28.09.14

Greater
Bombay And
Thane Distt.

Jaishreeram
Yadav

375

Smt.Naina
Yogesh
Hundiwala

Akola Distt.

Lt.Sh.Yogesh
Padmakar
Hundiwala

196

Gen

16.12.13

C/O Thube Niwas, Plot No.5,
Laxmi Colony, Mahalaxmi
Chowk, N-2, CIDCO,
Aurangabad Maharashtra431001
35, Avishankar Colony,
Chalisgaon Road, Dhule
Maharashtra-424001
16, Maik Apartment,
Sudarshan Nagar, Chichwad
Pune Maharashtra-411033
House NO.B26/3, N-I1,
Hudco Aurangabad
Maharashtra1141 E Ward, Sykes
Extension, Kolhapur
MaharashtraShrikrishnanagar, Failpura,
Katol Tehsil.Katol, PostKatol Dist.Nagpur
Maharashtra-441302
Dr, Iqbal Nagar, Dadarao
Plot, Parbhani Maharashtra
Flat No.B/404, Bldg.No.95,
Taragagan CHS, Road No13, Near Hanuman Temple,
Chembur Tilak Nagar
Mumbai Maharashtra400089
Padmatara Complex,
Jawahar Road, Akot, Tq.
Akola Distt.Akola
Maharashtra-444101

MAH/790/2000
Dt.07.04.2000

MAH/4005/2004
Dt.14.09.04
MAH/1612/1999
Dt.27.03.99
MAH/2039/1994
Dt.29.11.94
MAH/664/1997
Dt.03.10.97
MAH/249/2007
Dt.05.02.07
MAH/1952/2000
Dt.29.08.2000

MAH/4720/2005
Dt.06.10.05

MAH/674/2000
Dt.15.03.2000

<!-- page 25 -->

197

377

Sutar Anil
Janurao

SC

13.01.15

Beed Distt.

Sutar Janurao
Mesaji

198

378

Dilip M.Nimkar

OBC

18.2.15

Yavatmal Distt.

Mahadeo Narayan
Nimkar

199

381

Dilip Uttamrao
Dalvi

SC

16.01.15

Beed Distt.

Uttamrao Dalvi

200

387

Mahadeo
Govind Patil

Gen

12.03.15

Kolhapur Distt.

Govind Dadu Patil

201

388

Shah Anant
Kanhaiyalal

Gen

18.12.14

Navapur Taluka
Distt.

Lt.Shah
Kanhaiyalal
Shamlal

202

391

Brijeshwar
Nath Pandey

Gen

09.10.14

Greater
Bombay And
Thane Distt.

Lt.Sh.Sukhdev
Prasad Pandey

203

393

Fassioddin
Walioddin
Shaikh

Gen

07.02.15

Ta.Palam
Distt.Parbhani

Walioddin
Kamaloddin

204

394

Baviskar
Bhupesh
Vishram

SC

23.01.15

Jalgaon Distt.

Baviskar Vishram
Tukaram

Balaghat Teachers Colony,
Canal Road, Beed Tal.
Distt.Beed Maharashtra4131122
Kaveri Nagar, Plot No.18,
Darwha Tq.Darwha,
Distt.Yavatmal Maharashtra445202
Near Water Tank, Rajiv
Gandhi Chowk, Shriram
Nagar, Nagar Road, Beed
Tal. Distt Beed Maharashtra413122
Plot No.179/C-1, A,
Anusaya-Govind Shivneri
Colony, Pachgaon Tal.
Karveer Distt.Kolhapur
Maharashtra-416013
H.No.200, Dubhash Chawl,
Nr. Urdu Marathi School
Navapur Distt. Nandurbar
Maharashtra-425418
Chhabinath Pandey
Compound, Marol Naka
Airport Road, Andheri East
Mumbai Maharashtra400059
Near Post Office, Palam
Tq.Palam Distt.Parbhani
Maharashtra-431720
Behind , D.L.Hindi High
School, Gandhi Nagar,
Bhusawal, Tal. Bhusawal,
Distt.Jalgaon Mahrahstra425201

MAH/568/1994
Dt.22.03.94

MAH/2811/2003
Dt.27.08.03

E/22252277/1990
Dt.09.04.90

MAH/462/1991
Dt.10.04.91

MAH/1803/2001
Dt.18.07.01

MAH/1549D/1994
Dt.24.08.94
MAH/2020/1999
Dt.27.03.99

MAH/550/2004
Dt.20.02.04

<!-- page 26 -->

17.02.15

Nagbhid Tehsil
Nagbhid
Distt.Chandrap
ur

Ganesh Bapurao
Choudhari

205

395

Ravindra
Ganeshrao
Choudhari

206

396

Mane Sunil
Tukaram

Gen

20.12.14

Nilanga
Distt.Latur

Mane Tukaram
Tatyarao

207

398

Mrs.Varsha
Vijay Mandora

Gen

13.12.14

Jalgaon Distt.

Vijay Jagdish
Mandora

208

399

Prakash
Dharmaji
Tembhurne

SC

25.02.15

Chandrapur
Distt.

Dharmaji Keshrao
Tembhurne

209

401

Mitkari
Dayanand

Gen

04.03.15

Latur Distt.

Mitkari Shivmurti

210

403

Satyajeet
Vishwasrao
Patil

OBC

15.12.14

Jalgaon Distt.

Vishwasrao
Keshavrao Patil

211

404

Atul Kumar
Ramashray
Rai

Gen

25.02.15

Vasai
Nallasopara
Virar Palghar

Ramashray Rai

212

405

Mrs.Vandana
Bhaskar Pise

Gen

10.03.15

Nagpur Distt.

Prabhakarrao
Badrinarayan
Deshmukh

213

408

Ms.Dang
Surekha
Kawalraj

Gen

23.02.15

Pune Distt.

Kawalraj
Sardarchand Dang

OBC

At.Po.Tehsil Nagbhid,
Vidhya Nagar
Distt.Chandrapur
Maharashtra-441205
At.Post.Ansarwada
Tq.Nilanga Distt.Latur
Maharashtra-413521
Plot No.18, Anand Mangal
Soc. Pimprala Jalgaon
Maharashtra-425002
Peth Ward, Near Railway
Crossing Bramhapuri, Tehsil
Bramhapuri
Distt.Chandrapur
Maharashtra-441206
Shiv Niwas, Savewadi,
Trimurti Nagar, Latur
Distt.Maharashtra-413531
9, Ji Chambers, Opp. Distt.
Court Jalgaon Maharashtra425001
G-202, Rashmi Complex,
Achole Talav, Nallasopara
East Taluka Vasai
Distt.Palghar MaharashtraChikhali (Dev.) Abhinav
Gharkul Yojana, Nit, Building
No-J-S-3 Beside Kalamana
West Gate Nagpur
Maharashtra-440035
Flat No.105, Raviraj
Colorado S.No.44, Kondhwa
Khurd Pune Maharashtra411048

MAH/493/1997
Dt.28.08.97
MAH/2181/2002
Dt.27.08.02
MAH/1727/2006
Dt.07.07.06

MAH/5517/2005
Dt.20.12.05

MAH/4107/1999
Dt.22.07.99
MAH/1592/2006
Dt.24.06.06
MAH/4561A/2004
Dt.30.10.04
MAH/2708B/2000
Dt.05.09.2000

MAH/1954/2000
Dt.29.08.2000

<!-- page 27 -->

214

411

Mrs.Rafat
Khatib

215

415

Rajendra
Ganpat Kadu

Gen

12.03.15

Pune Distt.

Ganpat Narayan
Kadu

216

416

Savita
Pradeep
Kumar Rokade

SC

05.03.15

Pune City

Pradeep Kumar
Babanrao Rokade

217

417

Ms.Archana
Shivraj
Bhikane

OBC

04.03.15

Pune City

Shivraj Anirudha
Bhikane

218

418

Murlidhar
Baburao
Shinde

SC

Nil

Pune Distt.

Baburao
Ramchandra
Shinde

219

419

Pawan
Jagdishprasad
Pande

Gen

09.02.15

Akola Distt.

Jagdishprasad
Ramgopal Pande

220

422

Mrs.Shilpa
Nagesh Patil

OBC

06.02.15

Distt.Judge
Alibag Raigad

Suresh Kashinath
Patil

221

431

Chandrakant
Pandurang
Pandav

Gen

13.02.15

Hatkanangle
Distt.Kolhapur

Pandurang
Ramchandra
Pandav

222

432

Dhananjay
Annasaheb
Dalvi

Gen

05.02.15

Jaysingpur
Kolhapur Distt.

Annasaheb
Appasaheb Dalvi

Gen

16.01.15

Raigad Distt.

Nazir G.M.Khatib

Captain House Plot No.2,
Road No.10, Sector-11, New
Panvel East Distt.Raigad
Maharashtra-410206
127/8, Shivdarshan Vasahar
Parvati Pune Mahrashtra411009
At/Post Nia, Balewadi TalHaveli Dist.Pune
Maharashta-411045
B-18, Sai Amar Society,
Tukaram Tupe Nagar,
Mahadev Nagar, Manjri Bk.
Hadapsar Pune
Maharashtra-412307
Manjul House No.795,
S.No.31, Near Dhankwadi
Post Office, Dhankwadi
Pune Maharashtra-411043
Goyanka Nagar, Murtizapur
Po.And Tq. Murtizapur,
Dist.Akola Maharashtra444107
No.3, Rudraksh Apartment,
Brahmin Ali, Near Ram
Mandir Alibag Raigad
Maharashtra-402201
Hatkanangle Tal.
Hatkanangle Distt.Kolhapur
Maharashtra-416109
Plot No.586/1, Bhagirthi
Sudarshan Chowk,
Shahunagar Jaysingpur Tal.
Shiroi Distt.Kolhapur
Maharashtra-416101

MAH/931/1991
Dt.12.07.91
MAH/874/1991
Dt.11.07.91
MAH/1695/2007
Dt.03.07.07

MAH/3259/2007
Dt.02.08.07

mah/1223/2005
Dt.13.04.05

MAH/3394/2000
Dt.18.12.2000

MAH/3906/2006
Dt.09.08.06
MAH/228/2005
Dt.24.01.05

MAH/222/2005
Dt.24.01.05

<!-- page 28 -->

223

434

Shaikh
Mumtaz
Amirsab
Bagwan

224

435

Sadiya
Naseem Jamil
Ahmad

Gen

27.01.15

Nagpur Distt.

Jamil Ahmad

225

436

Mrs.Suramanja
ri Rajesh
Latkar

Gen

08.12.14

Kolhapur Distt.

Rajesh Bharat
Latkar

226

438

Ashok
Dnyanoba
Lokhande

Gen

24.02.15

Latur Distt.

Dnyanoba Maruti
Lokhande

227

440

Jaysing Bhikaji
Bankar

OBC

20.11.14

Bhandup
Village East
Mumbai

Bhikaji Laxman
Bankar

228

441

Watve
Vijaykumar
Raghunath

Gen

11.02.15

Miraj Taluka
Sangli Distt.

Raghunath
Puroshttam Watve

229

447

Ms.Daksha
Shah

Gen

30.01.15

Mumbai
Suburban Distt.

Manharlal
Jaichand Shah

230

450

Abdul Rahim
Abdul Sattar
Khan

Gen

11.12.14

Mumbai And
Thane

Abdul Sattar
Kamruddin Khan

OBC

25.02.15

Ahmednagar
Distt.

Amirsab
Fattemohmad
Bagwan

Gondhawani Near
Marutinagar Ward No.1,
Shrirampur, Tal.Shrirampur
Distt.Ahmedngar
Maharashta-413709
Plot No.168 Ayyappa Nagar,
Behind Shyam Lawn Jafar
Nagar Katol Road Nagpur
Maharashtra-440013
Flat No.303/517/A/1-3/1-4,
Vastushree Vrindavan
Housing Society, E Ward,
Shivaji Park Kolhapur
Distt.Maharashtra-416003
At.Katpur, Post Babhalgaon,
Tq.Dist.Latur Maharashtra413531
A/204, Shiv Shrusti
Chs.Ashok Kedare Chowk,
T.P.Road, Bhandup West
Mumbai Maharashtra400078
Behind Ramling Datta
Temple Brahmanpuri, Miraj
Tal.Miraj Dist.Sangli
Maharashtra-416410
C-702, Shubh Shanti
Complex, Mg Road
Dahanukar Wadi, Kadnivli
West Mumbai Maharashtra400067
501/501, Hill Zone Tower
Behind Old Nasheman
Colony Kausa Dist.Thane
Maharashtra-400612

MAH/2402/2002
Dt.13.09.02

MAH/1317/1999
Dt.27.03.99

MAH/2407A/2003
Dt.18.07.03
MAH/67/2002
Dt.17.01.02

MAH/1994/1995
Dt.18.07.95

MAH/702/1998
Dt.01.07.98

MAH/758/1992
Dt.02.05.92

MAH/525/2002
Dt.06.03.02

<!-- page 29 -->

231

452

Akhtar Ali
Meesam

OBC

19.03.15

Nagpur Distt.

Shabbir Ali
Meesam

232

454

Harendra
Arvind Rajgor

Gen

04.02.15

Ghatkopar
West Mumbai

Arvind Dayaram
Rajgor

233

455

Savita
Gaikwad

Gen

05.12.14

Satrasta
Mumbai

Vilas Gaikwad

234

458

Rizvi Sayed
Abbas Danyal

Gen

12.03.15

Greater
Mumbai Thane
Distt.

Ehteram Hussain

235

459

Asha Chetan
Shah

Gen

16.03.15

Mumbai Tall
Distt.

Chetan Shantilal
Shah

236

461

Merukar
Avinash
Gajanan

OBC

20.03.15

Pune Distt.

Merukar Gajanan
Harichandra

463

Vivek
Hanumant
Borade

Gen

26.03.15

Sangamner
Distt.Ahmednag
ar

Hanumant
Baburao Borade

238

467

Vishal
Haribhau
Santoshwar

OBC

19.03.15

Distt.Court
Chandrapur

Haribhau Dadaji
Santoshwar

239

468

Santosh Janak
Jadhav

SC

16.03.15

Nashik

Janak Dhondiram
Jadhav

237

512/A, Takiya Mehboob
Shah Mominpura, Nagpur
Maharashtra-440018
E/27, Vrindavan Lbs Road
Ghatkopar West Mumbai
Maharashtra-400086
56 I/8, Rasul Jiwa
Compound Sane Marg,
Satrasta Mumbai
Maharashtra-400011
Noble House
Co.Op.Hsg.Society Ltd.
A/201, Dongre Nagar Behind
Sahil Hotel Kausa Teumbra
Thane Maharashtra-400612
3/A, 704, Shraddha Chs
Mhada Colonu Chandivali
Mumbai Maharashtra400072
446 Ghorpade Peth Pune
Maharashtra-411002
Atharv Banglow, Govind
Nagar Sangamner Tal.
Sangamner
Distt.Ahmednagar
Maharashra-422605
Sai Baba Ward, Civil Lines
Chandrapur Distt.
Maharashtra-442401
Janlaxmi Niwas, Kadwa
Nagar Dindori Tal-Dindori
Distt.Nashik Maharashtra422202

MAH/5747/2007
Dt.03.11.07
MAH/1134/2004
Dt.19.04.04
MAH/5169/2007
Dt.02.09.07

MAH/1296/1998
Dt.08.09.98

MAH/1212/1993
Dt.30.07.93
MAH/786/2000
Dt.07.04.2000

MAH/213/1995
Dt.11.01.95

MAH/102/2007
Dt.05.02.07
MAH/1330/2007
Dt.03.07.07

<!-- page 30 -->

240

475

Mrs. Govinwar
Anjali
Shankarrao

Gen

31.03.15

Pune Distt.

Rajkuntwar Sanjay
Shankarrao

241

477

Pathan
Azimuddin
Hasankhan

Gen

27.03.15

Pune Distt.

Pathan
Hasankhan Fakir
Khan

242

479

Manisha
Marotrao
Sathone

OBC

27.03.15

Nagpur Distt.

Marotrao Sathone

243

480

Sudhir Amar
Sutar

OBC

08.04.15

Kolhapur Distt.

Dr. Amar Madhav
Sutar

244

483

Bhumini
Vitthaldas
Bhawsar

OBC

04.04.15

Nashik

Vitthaldas
Hiraman Bhaswar

245

484

Kshama
Prabodhi
Jaiswal

Gen

Nil

Wardha

Prabodh Pralhad
Jaiswal

246

485

Yashwant
Pandurang
Gore

OBC

19.03.15

Pune Distt.

Pandurang
Shankar Gore

247

489

Ms.Vidhisha
Devidas
Gaikwad

SC

23.03.15

Pune City

Devidas
Chandrappa
Gaikwad

B/3 Dharmnagri Taware
Colony Pune Maharashtra411009
Survey No.49/1/3, Goodwill
Vrindavan Co.Op. Housing
Society, Flat No.5 F-Wing
1st Floor Vadgaon Sheri
Maharashtra-411014
C/O Dr. Prakash V.Ghyshe
Plot No.K-9, Bharat Nagar
Opp.Lit College Amravati
Road, Nagpur Maharashtra440033
C.S.No.777/2, Royal
Gateway Apt. Flat No.Bf-11,
Opp.Ranuka Mandir E Ward
Kasaba-Bavada Kolhapur
Maharashtra-416006
Flat No.9, Guru Residency
Appartment, Near Fulsunder
Estate, Takail Road Behind
Gandhi Nagar Nashik
Maharashtra-422006
Near Post Office Gandhi
Ward Civil Lines Hinganghat
Maharashtra
Opp.Grampanchayat Office
Kamshet, Tal- Maval
Distt.Pune Maharashtra410405
Flat No.504, Shriwardhan
Apartment Trilok
Hsg.Society Warje Pune
Maharashtra-411058

MAH/1452/2003
Dt.26.03.03

MAH/688/1999
Dt.27.03.99

MAH/220/2001
Dt.22.01.01

MAH/1827/2002
Dt.24.07.02

MAH/1444/1994
Dt.26.08.94

MAH/2008/1994
Dt.29.11.94
MAH/1360/1989
Dt.25.08.89

MAH/189/2001
Dt.22.01.01

<!-- page 31 -->

At.Po. Plot No.41 Jai Hind
Colony Pachora Road
Bahagaon Tal. Bhadgaon
Distt. Jalgaon Maharashtra424105
Sant Kabir Nagar Opp.
Railway Station Udgir
Tq.Udgir Distt.Latur
Maharashtra-413517

248

490

Kulkarni
Hemant Ashok

Gen

23.03.15

Bhadgaon

Kulkarni Ashok
Hanumanta

249

491

Suryawanshi
Balaji Shripati

SC

02.03.15

Udgir
Distt.Latur

Suryawanshi
Shripatirao Panda

250

492

OBC

23.02.15

Udgir
Distt.Latur

Manohar
Vishwanath Hibare

Hibare Niwas, Dam Road
Udgir Maharashtra-413517

MAH/5006/1999
Dt.21.09.99

251

493

Gen

20.03.15

Pune Distt.

Ghodke
Ramchandra
Balwant

51/398, Laxminagar Parvati
Pune Maharashtra-411009

MAH/187/1996
Dt.15.01.96

20.02.15

Pune Distt.

Khedkar
Namdevrao
Krishnaji
Anantrao
Janardhanpant
Khond

Unmesh
Manohar
Hibare
Ghodke
Sachin
Ramchandra

495

Khedkar Vilas
Namdevrao

253

496

Shrikant
Anantrao
Khond

Gen

21.04.15

Samadhi Ward
Chandrapur

254

498

Ms. Vaishali
Dinesh
Bagade

OBC

09.04.15

Nagpur Distt.

Dinesh Mahadev
Bagade

255

500

Nirmal Mahesh
Kondabarao

Gen

09.04.15

Pusad
Tq.Pusad
Distt.Yavatmal

Nirmal Kondbarao
Harji

256

502

Mohammed
Nurul Islam
Khan

Gen

26.03.15

Thane Distt.

Mohammed
Naseer Khan

252

OBC

3047, Dattakrupa Mumbai
Bazar Shirur Tal.Shirur
Distt.Pune Maharashtra412210
Opp.Of Govind Swami
Mandir Samadhi Ward
Chandrapur Maharashtra442402
47, Pardhi Nagar, Hingna
Road, Nagpur Maharashtra440016
Brahamandnayak Near Hotel
Bhakti Ganesh Ward Pusad
Tq.Pusad Distt.Yavatmal
Maharashtra-445204
Flat No.302 3rd Floor, Noor
Mahal Bldg., Kk.Road 1st
Rabodi, Thane West
Maharashtra-400601

MAH/1327/2003
Dt.18.06.03

MAH/672/2001
Dt.01.03.01

MAH/425/1981
Dt.07.04.81

MAH/2155/1994
Dt.15.12.94
MAH/5873/2006
Dt.11.11.06
MAH/4576/2004
Dt.28.11.04

MAH/1983/1990
Dt.13.12.90

<!-- page 32 -->

257

505

Ashok Nawaji
Pagare

258

506

Raghunath
Shankarrao
Jadhav

Gen

24.04.15

Himayatnagar
Taluka

Shankarrao
Raghunath Jadhav

259

508

Jainendra
Kumar
Chowbey

Gen

31.03.15

Thane Distt.

Lt.Sh. Bujhawan
Chowbey

260

509

Sunil
Appasaheb
Teli

OBC

02.05.15

Kolhapur Distt.

Appasaheb Maruti
Teli

261

510

Mrs.Bhavana
Palikundwar

Gen

23.04.15

Ahmednagar
Distt.

Jitendra

262

511

Anil
Shankarrao
Shinde

OBC

06.05.15

Malegaon
Distt.Washim

Shankarrao
Panduji Shinde

263

513

Jadhav Shivaji
Sopanrao

Gen

28.04.15

Taluka Paranda
And
Osmanabad
Distt.

Jadhav Sopanrao
Janardhan

264

516

Zubair Abdul
Jabbar Shaikh

OBC

25.05.15

Madanpura

Abdul Jabbar
Shaikh

265

517

Jitendat
Ganpat Bhagat

Gen

07.05.15

Pune

Ganpat Kanhu
Bhagat

266

518

Shantaram
Somaji
Waghmare

OBC

07.05.15

Pune Distt.

Somaji Savleram
Waghmare

SC

13.04.15

Manmad
Distt.Nashik

Nawaji Kondaji
Pagare

Ambedkar Chowk, Malegaon
Naka Po.Manmad Tal.
Nanddgaon Dist.Nashik
MaharashtraHimayatnagar Tq.
Himayatnagar Distt.Nanded
Maharashtra-431802
Flat No.202, Shivani
Apartment Kalpuviksha Chs
Pandurang Nagar
Chichpada Kalyan East
Distt.Thane Maharashtra421306
At/Post-Hasuchampu TalGadhinglaj Distt.Kolhapur
Maharashtra-416501
B-4 Vinayaknagar Nagar
Pune Road Ahmednagar
Maharashtra-414001
Near Civil Court Malegaon
Taq. Malegaon Distt.Washim
Maharashtra-444503
Vakil Galli, Mandai Peth
Paranda Tal.Paranda
Distt.Osamanabad
Maharashtra-413502
212/214, Majidhiyah Manzil
Room No.11, M Azad Road
Madanpura Mumbai
Maharashtra-400008
20/21, Jain Building 3td
Floor Balaji Dhankawadi
Pune Maharashtra-411043
S.No.8/7/1 Lane No.3,
Chhava Colony Karvenagar
Pune Maharashtra-411052

MAH/1099/1988
Dt.16.08.88
MAH/3016/2000
Dt.19.10.2000

MAH/3032A/2000
Dt.19.10.2000

MAH/707/1995
Dt.01.02.95
MAH/2556/1999
Dt.27.03.99
MAH/2786/2006
Dt.29.07.06
MAH/3866/2003
Dt.06.12.03

MAH/1261/1989
Dt.14.08.89
MAH/878/1995
Dt.23.02.95
MAH/2382/2002
Dt.13.09.02

<!-- page 33 -->

267

520

Ms.Chaudhari
Raksha Hari

OBC

07.05.15

Pune City

Gurjar Ajaykumar
Panditrao

268

521

Rakesh
Sudhakar
Akole

Gen

30.04.15

Chikhaligaon
Tal. Haveli
Distt.Pune

Sudhakar Pundalik
Akole

530

Sudarshan
Pandurang
Deshmukh

29.05.15

Mahagaon

Pandurang
Khandbarao
Deshmukh

531

Kiran Devidas
Kolpe

00.06.15

Civil Court At
Washi,
Distt.Osmanaba
d

Devisad
Sakharam Kolpe

271

533

Gyan Chandra
Tiwari

Gen

16.06.15

Andheri
Santacruz

Rajnarayan Tiwari

272

534

Rajanish
Kumar Tripathi

Gen

16.06.15

Santacruz Khar
Bandra

Omprakash
Tripathi

273

535

Anil Kumar
Tiwari

Gen

16.06.15

Kandivali Malad
Goregaon

Shripal Tiwari

274

537

Rajkumar
Kachruji Ubale

SC

19.05.15

Kachruji
Gopalrao Ubale

Kachruji Gopalrao
Ubale

269

270

Gen

OBC

C/O.A.P.Gurjar S.No.38/1/1,
Flat No.5, 1st Floor Bldg.
No.B-7, Mata Vaishnavi Devi
Raj Park, Sai Raj Residency
Vidhya Nagar Pimple Gurav
Pune Maharashtra-411061
Chikhaligaon Tal. Haveli
Distt.Pune Maharashtra411062
C/O Laxman Damkondawar,
Sambhaji Nagar Mahagaon
Tq.Mahagaon Distt.Yavatmal
Maharashtra-445205
At.Post Terkheda Tq. Washi
Distt.Osmanabad
Maharashtra-413525
83/20, Satya Niwas Bldg. J.B
Nagar Andheri East Mumbai
Maharashtra-400059
Flat No.C-403, Bldg.No.4,
Khandwala Chs.Vakola
Bridge D.M.Road Santacruz
East Mumbai Maharashtra400055
Flat No.201, Ashray-B,
Shivshakti Chs. Near
Santoshi Mata Mandir Road,
Kurar Village Malad East
Mumbai Maharashtra400097
N-9, H-129/3, Shrikrushna
Nagar, Hudco Aurangabad
Maharashtra-431003

MAH/61/2006
Dt.24.01.06

MAH/1660/2000
Dt.04.08.2000
MAH/3713/2001
Dt.23.10.01

MAH/928/2006
Dt.24.03.06
MAH/2721/2002
Dt.30.09.02
MAH/1608B/2002
Dt.13.07.02

MAH/3189B/2002
Dt.19.10.02

MAH/999/2007
Dt,09.04.07

<!-- page 34 -->

275

538

Sachin
Dnyaneshwar
Nimbalkar

OBC

26.05.15

Pune Distt.

Dnyaneshwar
Laxmanrao
Nimbalkar

276

543

Sunil Babusing
Naik

OBC

Nil

Mahagaon
Taluka

Babusing
Mansusing Naik

277

546

Vijay Kumar
Pandey

Gen

20.06.15

Bandra East
Mumbai

Lt.Bhagirathi
Pandey

278

548

Shailendra
Kumar Singh

Gen

18.06.15

Mahim Matunga
Dadar Mumbai

Girjabaksh Singh

279

549

Amit Kantilal
Gujar

Gen

08.06.15

Throughout
Maharashtra

Kantilal
Khemchand Gujar

280

562

Parag
Jagannath
Ghuge

Gen

13.05.15

Pune, Satara
Sangli,
Kolhapur And
Ahmednagar

Jagannath
Gopinath Ghuge

281

563

Mohammed
Javed Hussain
Shaikh

Gen

16.05.15

Pune Distt.

Mohammed
Hussain Hassan
Shaikh

282

565

Abhay
Dinkarrao
Thorat

Gen

07.05.15

Kaulkhed Akola

Dinkarrao
Shankarrao Thorat

S.No.206, Tukai Darshan
Hadapsar Pune
Maharashtra-411028
Sambhaji Narwade Layout,
Behind Mseb And Rest
House Mahagaon Tq.
Mahagaon Distt.Yavatmal
Maharashtra-445205
Jagdeo Mishra Ki Chawl, 3rd
Floor Golibar Santacruz East
Mumbai Maharashtra400055
19-B, Room No.954, 4th
Floor Fisherman Colony,
Mahim Mumbai
MaharashtraB/5, Shri Niwas Sankul
Apartment, Sangam Mahuli
Phata Satara Maharashtra415003
Flat No.2, 2nd Floor
Arunoday Society, S.No.8,
Talaji Pathar Dhankawadi
Pune Maharashtra-411043
Flat No.1 And 2 Building
No.B-3, Pragati Park B-3/B4, Co-Op.Hsg. Society Ltd.
S.No.8-A, Kondhwa Khud
Pune Maharashtra-411048
New Khetan Nagar Near
Vaishnavi Apartment
Kaulkhed Akola Tq And
Distt.Akola Maharashtra444003

MAH/2452/2004
Dt.15.07.04

MAH/2513/1995
Dt.13.09.95

MAH/5557/1999
Dt.22.11.99
MAH/1006A/1996
Dt.31.03.96
MAH/159/2002
Dt.17.01.02

MAH/1194/2005
Dt.13.04.05

MAH/2046/2003
Dt.31.07.03

MAH/597/1997
Dt.19.09.97

<!-- page 35 -->

283

566

Mrs.Nileema
Gorakhnath
Musale

284

574

Tryambak
Sadashiv
Pagar

OBC

05.01.15

Nashik Distt.

Sadashiv Dharmaji
Pagar

285

580

Kusum Kiran
Gharat

OBC

18.05.15

Raigad
Distt.And Navi
Mumbai

Kiran Sadaanand
Gharat

286

586

Rodge
Balasaheb

Gen

23.06.15

Sailu
Distt.Parbhani

Rodge Ankushrao

287

588

Smt.Smita
Vitthalrao
Deshmukh

Gen

18.06.15

Rahata
Distt.Ahmednag
ar

Vitthalrao
Nathurao
Deshmukh

288

590

Gangadhar
Ramji Vaidya

SC

23.06.15

Aurangabad

Ramji Manikrao
Vaidya

289

591

Gajabi Sanjay
Rameshchandr
a

Gen

25.06.15

Throughout
Maharashtra

Gajabi
Rameshchandra
Nandkishor

290

594

Gopaldas
Murlidhar
Malpani

Gen

26.06.15

Malkapur
Distt.Buldana

Murlidhar
Tansikhdas
Malpani

Gen

12.05.15

Distt.Court
Ahmednagar

Gorakhnath
Kashinath Musale

Dhruv Bangalow Plot No.3,
Kinetic Chowk Nagar Pune
Road Ahmednagar
Maharashtra-414001
At.Post Talegao Tal.And
Distt.Nashik Maharashtra4222143
PL-5 Type, Building No.8,
Room No.4, Sector-1
Khanda Colony Panvel TalPanvel Distt.Raigad
Maharashtra
At.Post Ravalgaon Tq.Sailu
Distt.Parbhani Maharahstra431503
Pravaranagar, Paper Mill
Dairy Road (Nehru Nagar),
Tal-Rahata
Distt.Ahmedanagar
Maharashtra-413712
M-2, 9/1, 10th Scheme,
Tanaji Nagar Near
Ramnagar N-2, CIDCO
Aurangabad Maharashtra8/1520/1/1, Kamal-Kunj
Building Near Madhuban
Society. Sangli Road
Ichalkaranji Tal.
Hatkanangale Distt.Kolhapur
Maharashtra-416115
Radhakisan Chawal
Malkapur Tal. Malkapur
Distt.Buldana Maharashtra443101

MAH/132/2000
Dt.27.01.2000
MAH/271/1987
Dt.25.02.87

MAH/4836/2006
Dt.23.09.06

MAH/3257/2004
Dt.30.07.04

MAH/369/2003
Dt.23.01.03

MAH/2837/2000
Dt.16.10.2000

MAH/170/1996
Dt.15.01.96

MAH/960/1996
Dt.10.04.96

<!-- page 36 -->

291

595

Kalidas Daga
Thakur

ST

03.07.15

Jalgaon Distt.

Daga Motiram
Thakur

292

596

Ramesh R.Pal

SC

14.05.15

Palghar Distt.

Ramdavar Pal

293

597

Navnath
Baban Karale

Gen

16.06.15

Pune Distt.

Lt.Baban Sahadu
Karale

Gen

10.06.15

Pune City

Murlidhar Bapurao
Dashrathey

OBC

12.06.15

Latur Distt.

Bhanudas

Mrs.Varsha
Murlidhar
Dashrathey
Haque
Homkar
Dhananjay

294

600

295

602

296

603

Sanjay Ashok
Taware

OBC

18.05.15

Wai

Lt.Sh.Ashok
Shamrao Taware

297

606

Paldewar
Varsha
Gangadharrao

Gen

17.06.15

Latur Distt.

Paldewar
Gangadhar
Venkartraman

298

607

Nazareth
Sylvester
Correia

Gen

18.05.15

Mumbai

Sylvester Luis
Correja

299

611

Vinay Jawahar
Gugad

Gen

11.06.15

Pimpri
Chinchwad And
Pune Distt.

J.B.Dugad

Swaminarayan Nagar Savda
Tal. Raver Distt.Jalgaon
Maharashtra-425502
102, 1st Floor, Shri Ganesh
Apartment Behind Aryan
High School, Palghar Taluka
Palghar Distt.Thane
Maharashtra-401404
Jaulake Bk.Tehsil-Khed
Rajgurunagar Distt.Pune
Maharashtra-410112
Flat No.601, Lara Prestige
S.No.140/3, Near Nilash
Lawn,S Pashan Sus Road
Pune Maharashtra-411021
Bodhe Nagar Latur
Maharashtra-413512
A/P-Wali Tal. Wai
Distt.Satara Maharashtra412803
Vijaya Niwas Ketaki
Sangmeshwar Society, Near
Bangali Chowk, Degloor
Road, Udgir Tq.Udgir
Distt.Latur Maharashtra413517
Pushpadeep Vatar Adle
Po.Agashi Taluka Vasai
Distt.Thane, Via-Virar
(W.Rly) Maharashtra-401301
Plot No.373, Sector-24, Tilak
Road, Pradhikaran, Nigdi
Pune Maharashtra-411044

MAH/6024/2006
Dt.11.11.06

MAH/5248/2005
Dt.29.11.05

MAH/1795/2004
Dt.15.07.04
MAH/913/2003
Dt.10.04.03
MAH/1561/1990
Dt.27.09.90
MAH/590/2002
Dt.18.03.02

MAH/2891/2000
Dt.16.10.2000

MAH/1323/2005
Dt.13.04.05
MAH/2209/2001
Dt.31.07.01

<!-- page 37 -->

300

612

Rajendra
Prasad Mishra

Gen

11.06.15

Andheri East
Mumbai

Ramdeo Mishra

301

613

Mohammad
Ishaque Ansari

OBC

06.06.15

Kamptee
Distt.Nagpur

Mohammad Ismail
Ansari

302

614

Balkrishna
Ganpat
Sonawane

Gen

15.06.15

Pune Distt.

Ganpat Narayan
Sonawane

303

615

Madhav
Appasaheb
Avachar

Gen

18.06.15

Pune Distt.

Appasaheb
Dadasaheb
Avachar

304

622

Prakashchandr
a Mishra

Gen

20.06.15

Santacruz Khar
Bandra

Mayashankar
Mishra

305

623

Prashant
Vishnupant
Patil

Gen

05.06.15

Kolhapur City

Vishnupant

306

627

Mrs.
Gayatridevi
Chetan Patil

Gen

04.06.15

Pune City

Chetan
Babruwahan Patil

B-306, Blue Nile, Pacific
Enclave, Next To
Hiranandani Hospital Powai
Mumbai Maharashtra400076
C/O.Ansari's Nursing Home,
Indora, Sri Complex
Kamptee Road, PostJaripatka Nagpur
Maharashtra-440014
S.No.29, Katraj Kondhwa
Road, Mauli Nagar,
Prathmesh Bldg. Flat No.19
And 20 Pune Maharashtra411046
At/Post Deulgaon Raje, TalDaund Distt.Pune
MaharashtraRoom No.13, Ram
Shiromani Pandey Chawl,
Jai Hind Nagar Khar East
Mumbai Maharashtra400051
Shardendu 34 A Ward
Shardendu Corner Shivaji
Peth Near Padmaraje
Garden Rankala
Radhanagari Rasta Kolhapur
Maharashtra-416012
Flat No.B-2/43, Daffodils
Hsg. Society, Kate Wasti,
Bharat Pertol Pump, Pimple
Saudagar Pune
Maharashtra-411027

MAH/840/1991
Dt.11.07.91

MAH/1549/2006
Dt.24.06.06

MAH/254/2000
Dt.27.01.2000

MAH/1508/2002
Dt.05.07.02
MAH/122A/1991
Dt.13.01.91

MAH/1599/1999
Dt.27.03.99

MAH/1851/2005
Dt.15.07.05

<!-- page 38 -->

307

628

Dnyaneshwar
Arjun Kamthe

Gen

28.05.15

Pune Distt.

Arjun Baburao
Kamthe

308

629

Sureshchandra
U.Pandey

Gen

24.11.14

Thane Distt.And
Session Court

Udayraj Pandey

309

630

Jalindar
Govindrao Lad

Gen

23.04.15

Malegaon

Govindrao
Anandrao Lad

310

631

Ashok Raoji
Desai

Gen

04.05.15

Mumbai And
Navi Mumbai
Thane

Raoji Visram
Desai

311

632

Shagufta
Parveen
Qureshi

Gen

Nil

Mumbai

Abdul Rahim
Qureshi

312

633

Mrs.Vijaya
Vishwanath
Shinde

Gen

05.08.15

Nashik Distt.

Vishwanath
Tukaram

313

634

Anjani Nandan
Mishra

Gen

22.07.15

Vasai
Nallasopara
Virar Palghar

Lt.Sh. Sarvajeet
Mishra

At/Post Dhayari Near
Dhayari Grampanchayat
Karyalay Tal- Haveli
Distt.Pune Maharashtra411041
Bldg. No.R-5, Flat No.511,
Satyam CHS Ltd. MMRDA
Colony, Ram Mandir Road,
Goregaon West Mumbai
Maharashtra-400104
Shov Chowk Malegaon Ta.
Malegaon Distt.Washim
Maharashtra-444503
Flat No.1 Plot No.37 Sector10A, Vashi Navi Mumbai
Taluka And Distt.Thane
Maharashtra-400703
Alfa Arcade House Near
H.D.Marbles Works Davry
Nagar Gate No.1, Opp.
Vakola Police Station
Santacruz East Mumbai
Maharashtra-400055
Vishwavijay Bungalow Plot
No.19, S.No.36/1, Balwant
Nagar Annadavalli Gangapur
Road Nashik Maharashtra422013
C-404, Shiv Shrusti
Complex, Near Dubey
Medical College Nallasopara
East Taluka Vasai
Distt.Palghar Maharashtra-

MAH/34/2005
Dt.14.01.05

MAH/1124/2004
Dt.19.04.04

MAH/1015/2001
Dt.11.04.01
MAH/3412/1999
Dt.24.06.99

MAH/3257/2002
Dt.09.11.02

MAH/2180/1998
Dt.17.11.98

MAH/2013D/1990
Dt.29.12.90

<!-- page 39 -->

314

635

Rajneesh
Dwivedi

Gen

22.07.15

Vasai
Nallasopara
Virar Palghar

Sabhajeet Dwivedi

315

636

Diwakar
Radhey
Krishna Dubey

Gen

17.07.15

Dombivali
Thane Mumbai

Radhey Krishna
Dubey

316

637

Akhilesh
Kumar Tripathi

Gen

30.07.15

Kalyan Thane

Laxmi Narayan
Tripathi

317

641

Mithilesh
Kumar
Upadhyay

Gen

28.07.15

Thane Mumbai

Satyadev
Upadhyay

318

642

Sudhir Shivaji
Kotwal

OBC

22.07.15

Nashik

Shivaji Eknath
Kotwal

319

646

Mrs.Neeta
Sawant

Gen

Nil

Taluka
Sawantwadi
Distt.Sindhudur
g

Shridhar Sawant

320

647

Bhaskar Dutta

Gen

20.06.15

Mira Road,
Bhayander,
Naigaon Thane

Devi Prasad

201, I- Wing, 2nd Floor
Rashmi Complex, Near
Achole Talav Gate No.2
Lotus Marg, Nallasopara
East Taluka- Vasai
Distt.Palghar Maharahshtra401209
Flat No.201, 2nd Floor A
Wing, Astavinayak Chs. Nr.
Baleshwar Residence, Opp.
Balaji Mandir Road,
Gofraswadi, Dombivali East
Distt.Thane Maharashtra421201
H.No.3770, Sai Krupa
Chawl, Chawl No.5, Room
No.2 Behind Chetna School
Kalyan East Distt.Thane
MaharashtraFlat No.A-102, Prathamesh
Complex, Chakradhar Nagar
Nallasopara West
Distt.Thane Maharashtra2, Sanjeevan, Ramanand
Housing Society, Ltd. Tidke
Colony Nashik Maharashtra422001
Anand Van Society, Flat
No.1, Salaiwada
Sawantwadi Tal.Sawantwadi
Distt.Sindhudurg
Maharashtra-416510
Sonam Heights, B-Wing Flat
No.902, New Golden Nest,
Bhayander East Distt.Thane
Maharashtra-

MAH/2681A/2002
Dt.14.09.02

MAH/3067B/1999
Dt.03.04.99

MAH/2928B/2001
Dt.17.09.01
MAH/3672F/1999
Dt.30.05.99
MAH/1190/1988
Dt.17.08.88

MAH/1095/1994
Dt.12.07.94

MAH/2159D/1992
Dt.14.11.92

<!-- page 40 -->

321

649

Anil Sadashiv
Zanak

322

654

Arun Pratap
Singh

Gen

Nil

Greater
Mumabi And
Distt.Palghar

Sirtaj Bahadur
R.Singh

323

657

Jayashri
Shivaji
Ghodake

Gen

25.06.15

Solapur Distt.

Shivaji Ghodake

324

658

Babaso
Mhadgaon
Patil

Gen

29.06.15

Kolhapur Distt.

Mahadgonda
Babgonda Patil

325

660

Ram Pratap
Singh

Gen

25.06.15

Bandra Borivali
Mumbai

Dan Bahadur
Singh

326

663

Gen

21.04.15

Canada Corner
Nashik

Chandulal
Bhagwandas Shah

327

666

SC

02.07.15

Beed Tq And
Distt.

Sanjiy Sitaram
Veer

328

667

Gattani
Sandeep
Vijaykumar

Gen

01.07.15

Tq.Mangrulpir

Gattani
Vijaykumar
Bhagirathji

668

Krishnat
Ganpati
Lavhate

Gen

01.08.15

Kolhapur City

Ganpati Bhiva
Lavhate

329

Suyog
Chandulal
Shah
Mrs.Sangita
Ramrao
Bhutawale

OBC

21.05.15

Risod Tehsil
And Distt.

Sadashiv Dagduji
Zanak

Ramkrushna Behind Talikes,
Anandi Chowk, Risod Tehsil
Risod Distt.Washim
Maharashtra-444506
C/201, Shree Ram Shankul
Beside HDFC Bank Achole
Road, Nallasopara East Tal.
Vasai Distt.Palghar
MaharashtraAt.Malegaon R Vaya
Gaudgaon Ta Barshi
Distt.Solapur Maharashtra413406
17/77, Swami Vivekanand
Colony, Ichalkarnji TalKatkanangle Distt.Kolhapur
Maharashtra-4160115
Room No.1, Ram Sumer
Gupta Chawl, Goraswadi,
Malad West Mumbai
Maharashtra-400064
Swapnayog 101 D' Souz
Colony, College Road
Nashik Maharashtra-422005
Panchshil Nagar, Palwan
Road, Beed Tq. And
Distt.Beed MaharashtraRoom/ Build No.M.I.G.3
Village Post Mangrulpir
Taluka Mangrulpur Road
Bus Stand Distt.City Washim
Maharashtra-444404
A/P. Kotoli Tal.Panhala
Distt.Kolhapur Maharashtra416230

MAH/3079/2008
Dt.18.07.08

MAH/1006B/1996
Dt.31.03.96

MAH/2540/2001
Dt.04.09.01

MAH/1857/2001
Dt.13.07.01
MAH/1203A/1998
Dt.13.08.98
MAH/2471/2004
Dt.15.07.04
MAH/4150/2004
Dt.14.09.04

MAH/3060/2005
Dt.26.08.05

MAH/3727/2001
Dt.23.10.01

<!-- page 41 -->

330

669

Mrs.Veena
Pravin Wagle

Gen

09.07.15

Navi Mumbai

Pravin Manjunath
Wagle

331

671

Subhash
Balasaheb
Chormunge

Gen

08.07.15

Ahmednagar
Distt.

Balasaheb Bapuji
Chormunge

332

672

Shivaji Krishna
Farakate

Gen

24.07.15

Mira Road East
Distt.Thane

Krishna Gundu
Farakate

333

675

Chandrakant
Rane

Gen

05.05.15

Vikhroli East
Mumbai

Baburao Rane

334

676

Sudhir Popatlal
Kotak

Gen

31.07.15

Greater
Mumabai

Lt.Sh.Popatlal
Kotak

677

Ganesh
Balkrishna
Desai

23.07.15

Elphinston,
Lower Parel
Mahalaxmi
Mumbai

Balkrishna
Mahadeo Desai

01.08.15

Charkop
Kandivali West
Greater
Mumbai And
Thane Distt.

Parasnath
S.Dubey

335

336

678

Laltaprasad
P.Dubey

Gen

Gen

C-2/24/3-1, Sector-16, Vashi
Navi Mumbai Distt.Thane
Maharashtra-400703
At.Satral Po.Songaon, Tal.
Rahuri Distt.Ahmednagar
Maharashtra-413711
Flat No.405, 4th Floor Sun
Flower Bulding Shree
Rameshwar Chs Ltd.
Laxminagar Ghatkopar East
Mumbai Maharashtra400075
222/8675, Nurse Welfare
Co.Op.Hsg. Soc.Ltd.
Kannamwar Nagar-1, B
Wing Vikhroli East Mumbai
Maharashtra-400083
Room No.3, Bunnglow,
Shree Kutchi Lohana Niwas,
Shivdas Champsi Marg,
Mazgaon Mumbai
Maharashtra-400010
Room No.39, Chawl No.2,
Rajuji Manaji Chawl,
Jamsandekar Marg, Lower
Parel West Mumbai
Maharashtra-400013
005/9, Shri Sai Co-Op.Hsg
Soc.Ltd.Chhatrapati Shivaji
Raje Complex Ekta Nagar
Charkop Kandivali West
Mumbai Maharashtra400067

MAH/3097/2001
Dt.01.10.01
MAH/2315/1995
Dt.17.08.95

MAH/2045/2000
Dt.29.08.2000

MAH/3410/2001
Dt.23.10.01

MAH/1475/1989
Dt.21.09.89

MAH/599/1995
Dt.01.02.95

MAH/911/1999
Dt.27.03.99

<!-- page 42 -->

337

680

Sarjerao
Ashok Mohite

Gen

17.07.15

Sangli Distt.

Ashok Pandurang
Mohite

338

681

Ms.Chavan
Rvpali Rajesh

Gen

02.07.15

Wai, Khandala
And Satara
Distt.

Chavan Rajesh
Maruti

339

684

Ms. Jyoti
Ashok
Wadhwani

Gen

09.07.15

Pune Distt.

Ashok Rochiram
Wadhwani

340

688

Bhandane
Bhalchandra
Narayan

OBC

09.07.15

Pune Distt.

Narayan Manikrao
Bhandane

341

690

Shaikh Ashfak
Ahmed

Gen

13.07.15

Nanded Distt.

Iqbal Ahmed

691

Rajesh
Shankarrao
Wevhal

07.07.15

CJJDE And
JMFC
At.Manther
Ta.Mantha
Distt.Jalna

Shankarrao
Rajaram Wevhal

343

692

Ansari
Qumaruddin
Badruddin

OBC

09.06.15

Thane

Ansari Badruddin

344

693

Medha R
Jaiswal

Gen

15.07.15

Mumbai Distt.

Roopesh
R.Jaiswal

342

SC

A/P.1135, Khanbhag Kanse
Galli Near Panchmuki
Maaruti Mandir Sangli Tal.
Miraj Distt.Sangli
Maharashtra-416416
Matoshri Behind Hotel
Satkar Garden At.Post Svrur
Tal-Wai Distt.Satara
Maharashtra495, Bhawani Peth, Near
Poona College Pune
Maharashtra-411042
Gangabharti Krupa Niwas,
Behind Bank Of Maharashtra
Narhe Road , Narhegaon
Pune Maharashtra-411041
Jawahar Nagar Near Baba
Nagar Nanded Maharashtra431602
Ghree Colony Mantha
Ta.Mantha Distt.Jalna
Maharashtra-431504
City Light CHS, 2nd Floor,
Flat No.7/8, Kismat Colony
007, Krishna Apt. Amrut
Nagar Mumbra Thane
Maharshtra-400612
B/6-2 Navy Colony, Near
Liberty Garden Malad West
Mumbai Maharashtra400064

MAH/170/2005
Dt.24.01.05

MAH/5505/2007
Dt.21.09.07
MAH/1943/2004
Dt.15.07.04
MAH/3215/2004
Dt.30.07.04
MAH/2080/2000
Dt.29.08.2000

MAH/636/2005
Dt.21.02.05

MAH/1885A/1991
Dt.10.12.91

MAH/3032/2000
Dt.19.10.2000

<!-- page 43 -->

345

694

Priya Prakash
Tendulkar

Gen

26.06.15

Nandivali
Dombivli And
Kalyan

Kundal Kali Ghosh

346

697

Mrs.Anita
Pratap Patil

OBC

Nil

Taluka And
Distt.Thane

Pratap Baban Patil

347

702

Kharsade
Sandeep
Sambhaji

Gen

20.07.15

Osmanabad
Distt.

Kharsade
Sambhaji
Khushalbhau

703

Bhayasaheb
Sudam
Waghmare

22.07.15

Pune Distt.And
Session Court
And Pimpri
Chichwad
Municipal Area

Sudam Haribhau
Waghmare

348

SC

349

704

Ajay Vitthal
Patil

OBC

23.07.15

Borivali East
Mumbai

Vitthal Daji Patil

350

708

Rajesh
Ramchandra
Lohande

OBC

21.07.15

Akola Distt.

Ramchandra
Bikram Lokhande

Block No.4, B Wing Ground
Floor Nac Smit CHSL Near
Prabhukunj Bungalow P.And
T Colony Nandivali Dombivli
East Village Nandivali
Panchanand Taluka Kalyan
Distt.Thane Maharashtra421204
At.Gothivali, Post Ghansoli,
Near Vittal Rukmini Mandir
Sudarshan House House
No.347, Navi Mumbai
Maharashtra-400701
New Samarth Nagar Behind
Back Of Office Taluka
Inaspacter Land Record
Bhoom Tq.Bhoom
Distt.Osmanabad
Maharashtra-413504
Near Boudha Vihar Gandhi
Nagar Pimpri Pune
Maharashtra-411018
D/09/01, Ashmita Jyoti CoOp.Hsg. Soc.Ltd.Charkop
Naka Marve Road, Malvani
Malad West Mumbai
Maharashtra-400095
Near Civil Court Hingna
Shelad Road, Belapur Tah.
Balapur Distt.Akola
Maharashtra-444302

MAH/80/2002
Dt.17.01.02

MAH/576/2000
Dt.02.03.2000

MAH/2147/2004
Dt.15.07.04

MAH/508/2004
Dt.20.02.04

MAH/771/2005
Dt.01.03.05

MAH/2059/2001
Dt.31.07.01

<!-- page 44 -->

351

709

Ashok Anand
Rao

Gen

04.03.15

Mumbai

Anandrao
Thamayya
Shervegar

352

713

Mrs.Purnima
Singh

Gen

19.08.15

Andheri Borivali
Area

Captain Padmakar
Singh

353

714

Umesh
Ayodhyaprasa
d Tiwari

Gen

11.08.15

Umarkhed
Taluka

Ayodhyaprasd
Ramlal Tiwari

354

717

Smt.Geeta
Laxman
Chavan

Gen

22.07.15

Otur Area TalJunnar
Distt.Pune

Lt.Laxman Suraj
Chavan

355

718

Sachin Arvind
Chavan

OBC

23.07.15

Pune Distt.

Arvind Balasaheb
Chavan

356

721

Krishna
Tekade

OBC

03.08.15

Nagpur Distt.

Shrawan Govindaji
Tekade

357

722

Santosh
Ramchandra
Bhosale

Gen

03.08.15

Pune Distt.

Ramchandra
Mansingrao
Bhosale

358

723

Hude
Shyamkumar
Baburao

Gen

01.08.15

Latur Distt.

Hude Baburao
Anandrao

Flat No.603, B-Wing, 6th
Floor, Ramnivas Building
Rani Sati Marg, Tapovan
Malad East Mumbai
Maharashtra-400097
E-603, Serenity Complex,
Off New Link Road Behind
Oshiwara Police Station
Jogeshwari West Po.
Andheri West Mumbai
Maharashtra-400102
Near Sai Temple, Patil
Nagar Umarkhed
Distt.Yavatmal Maharashtra445206
Ambika Palace, Dhamale
Mala, At.Post Otur,
Tal.Junnar Distt.Pune
Maharashtra-412409
163a/1a/15, Near Bank Of
Maharashtra Solapur Road
Hadapsar Pune
Maharashtra-411028
165, Matruchhaya, Balaji
Nagar West Maneswada
Road Nagpur Maharashtra440027
Bramchaitanya Behind Sant
Krupa Mangal Karyalaya
At/Post Dehu Tal-Haveli
Distt.Pune MaharashtraAt. And Post Kawthala Tq.
Deoni Distt.Latur
Maharashtra-413519

MAH/778/1995
Dt.23.02.95

MAH/1563/2000
Dt.04.08.2000

MAH/4666/1999
Dt.18.08.99

MAH/3120/2001
Dt.01.10.01

MAH/2784/2005
Dt.04.08.05

MAH/1619/2008
Dt.14.06.08

MAH/299/2003
Dt.23.01.03
MAH/1595/1991
Dt.13.09.91

<!-- page 45 -->

Pune Distt.And
Sessions Court
And Sangvi
Distt.Pune

Narayanrao Dhore

724

Pandurang
Dhore

360

725

Dattu Baburao
Jadhav

Gen

29.07.15

Pune Distt.

Baburao Baliram
Jadhav

361

728

Smt.Parvati
Jinde

Gen

13.07.15

Maharashtra
State

Ashok Jinde

362

729

Suhil Kumar
Machchindra
Saravade

SC

09.12.14

City Civil And
Session Court
Fort Mumbai

Machchindra
P.Saravade

363

732

Dilip Eknath
Bodade

OBC

02.04.15

Varangaon
Tal.Bhusawal
Distt.Jalgaon

Eknath Pandurang
Bodade

364

733

Joshi Arvind
Ganesh

Gen

27.07.15

Thane Distt.
Navi Mumbai

Joshi Ganesh
Narayan

365

737

Vilas Piraji
Jadhav

Gen

24.07.15

Distt.Court
Maharashtra

Piraji Sayanna
Jadhav

366

738

Mrs.Aishwarya
Krishna

OBC

28.07.15

Tal.Maval And
Distt.Pune
Lonavala

Krishana Mahadeo

359

Gen

01.08.15

Janai Niwas Shitole Nagar
Sangvi Pune Maharashtra411027
S.No.14/4, Jannai Sadan,
426/6 Tapodham Parisar,
Lane No.4, Warje Pune
Maharashtra-411058
A-204, Ayodhaya Chs,
Sector-5 Plot No.10,
Ghansoli Navi Mumbai
Maharashtra-400701
Dhondai Smurti Flat No.201,
2nd Floor Plot No.286/287,
Near Rupshree Vidyalaya
Sector-1 Ghansoli Navi
Mumbai Maharashtra400701
2, Shivaji Nagar, Varangaon
Tal. Bhusawal Distt. Jalgaon
Maharashtra-425305
A-104, Pratik Society,
Sector-10, Diva Nagar Airoli
Navi Mumbai Maharashtra400701
A/P Hrushiksh Banglow,
Sainik Society, C.T.Road
Bora College Oad Ghodnadi
Tal- Shirur Distt. Pune
Maharashtra-412210
Ward No.42, Lendghar Chal,
Bhangerwadi, Lonavala
Maharashtra-410401

MAH/1731/1994
Dt.07.10.94

MAH/805/1999
Dt.27.03.99

MAH/9946/1999
Dt.18.08.99

MAH/4937/2005
Dt.29.10.05

MAH/47/1992
Dt.03.01.92
MAH/1371/1991
Dt.21.08.91

Mah/108/1994
Dt.05.01.94

MAH/481/2003
Dt.02.07.03

<!-- page 46 -->

367

739

Vijay Chunilal
Gupta

Gen

21.07.15

Pune Distt.

Chunilal Bhagwat
Gupta

368

743

Pravin
Sitaramji
Chitlange

Gen

27.07.15

Distt.Court
Akola Tq. And
Distt. Akola

Sitaram Ramgopal
Chitlange

369

744

Faruk Gulab
Mujawar

Gen

17.08.15

Sangli Distt.

Gulab Babalal
Mujawar

370

745

Amol Ashokrao
Bhujade

OBC

25.06.15

Bhandra
Tah.Distt.

Ashokrao
Shamraoji
Bhujade

371

747

Mrs. Nandita
Nilesh
Chaudhari

Gen

07.08.15

Akola Distt.

Nilesh
Purshottamji
Chaudhari

372

748

Subhash
Pandurang
Dhule

OBC

11.08.15

Jatharpeth Area
Of Akola

Pandurang
Namdevrao Dhule

373

750

Mrs.Aarti
Prasad
Kulkarni

Gen

01.08.15

Thane Distt.

Prasad Narayan
Kulkarni

374

751

Vilas
Wamanrao
Jawanjal

Gen

11.08.15

Akola Distt.

Wamanrao
Tulshiramji
Jawanjal

Kunjirwadi, Pune Solapur
Highway Tal. Haveli
Distt.Pune Maharashtra412201
202, Godawari Apartment,
Vijay Housing Society,
Gaurakshan Road, Akola
Maharashtra-444004
322, Somwar Peth, Near
Post Office Madhavnagar
Tal.Miraj Distt.Sangli
Maharashtra-416406
Tilak Ward Behind Pande
Mahal Bhandra
Maharashtra-441904
C-30, Lal Lajpatrai Society,
Gokul Colony Jawahar
Nagar Akola
Distt.Maharashtra
Flat No.S-4, Chintamani
Apartment, Opp. Dr.Topale
Hospital Umari Road
Jatharpeth Akola
Maharashtra-444005
8, Nanda Deep Devrishi
Nagar Panchpakhadi Thane
West Taluka Thane
Distt.Thane Maharashtra400602
Sai Nagar, Telhara Tq.
Telhara Distt.Akola
Maharashtra-444108

MAH/1177/2000
Dt.30.06.2000

MAH/2229/2004
Dt.15.07.04

MAH/2430/1995
Dt.07.09.95
MAH/64296/200
6 Dt.13.12.06
MAH/241/2001
Dt.22.01.01

MAH/2774/2000
Dt.16.10.2000

MAH/1404/1991
Dt.21.08.91

MAH/2860/1995
Dt.21.11.95

<!-- page 47 -->

375

759

Nawin Kumar
Thakur

Gen

14.08.15

Session Court
Mumbai Basai
Thane And
Palghar Court

376

761

Rajesh
Damodar Salvi

SC

16.05.15

Maharashtra
State

Damodar
Gangaram Salvi

377

762

Santosh
Achutrao
Pawar

Gen

20.07.15

Beed Distt.

Achut Tukaram
Pawar

378

765

Shaikh Zainab
Bi

Gen

19.08.15

Greater
Mumbai Distt.

Dost Mohammed
Shaikh

379

768

Ms.Snehal
Chandrashekh
ar Sawant

Gen

06.08.15

Vikhroli Court
Centre Of
Mumbai
Distt.Thane

Madhukar Suryaji
Satam

380

769

Yamuna
Prasad Singh

Gen

Nil

Metropolitan
Mag. Court
Vikhroli Mumbai

Kedar Singh

381

772

Arjun
Tulshiram Patil

OBC

19.08.15

Jalgaon Distt.

Tulshiram
Kashiram Patil

382

774

Mrs.Rohini
Santosh
Bhadavkar

OBC

12.08.15

Dindoshi Court
Malad West

Sanotsh
M.Bhadavkar

Ram Chandra
Thakur

Radha Swami Niwas,
Adarsh Seva Sangh Shree
Ram Nagar, Cutting No.5,
Malad East Mumbai
Maharashtra-400097
3rd Floor, Room No.34
Gavdevi Dardhan Building
Ravi Darshan Lane
Gofraswadi, Patherli Road
Dombivli East Distt.Thane
Maharashtra-421201
Shivaji Nagar Bank Colony
Ambajogai Tq.Ambajogai
Distt.Beed Maharashtra431517
Sapna Co.Op.Hsg.Society
Hanif Kawal Chawl, Cama
Road, Gaondevi Dongari
Andheri West Mumbai
Maharashtra-400058
102, Rudra Sagar
Co.Op.Hsg.Soceity.Gqyanpa
da Mulund East Mumbai
Maharashtra-400081
H-A-29/17, A.H.Marg, Gr-17
Near Shivsena Office, Powai
Road Surya Nagar Vikhroli
West Mumbai Maharashtra400083
Ward No.1, Near Kumbhar
Wada Bodwada Tal. Bodwad
Distt.Jalgaon Maharashtra145/99, M.H.B.Colony,
Malvanj -8 Malad West
Mumbai Maharashtra400095

MAH/3201/1999
Dt.05.05.99

MAH/301/2001
Dt.01.10.01

MAH/3711/2002
Dt.19.12.02

MAH/725/2008
Dt.19.03.08

MAH/675/2000
Dt.15.03.2000

MAH/269A/1993
Dt.13.02.93
MAH/1581/2006
Dt.24.06.06
MAH/700/2006
Dt.08.03.06

<!-- page 48 -->

383

778

Nikhilkumar
Sudamrao
Khose

384

781

Ahuja Manjeet
Singh

Gen

12.08.15

Pune Distt.

Ahuja Gurcharan
Singh

385

782

Ulhas Tukaram
Patil

OBC

27.07.15

Thane Distt.

Tukaram Namdeo
Patil

386

784

Arun Shridhar
Punde

Gen

20.08.15

Ahmednagar
Distt.

Shridhar Bajirao
Punde

786

Mohammad
Nadim Siddiqui

06.09.15

Malda And
Borivali
Distt.Mumbai
Thane

Mohammad Akmal
Siddiqui

388

787

Mrs.Rekha
Kishor Howale

SC

15.06.15

Cbd Belapur
Thane
Distt.Navi
Mumbai

Kishor Sitaram
Howale

389

790

Ms.Pooja
Sudama
Prasad Dubey

Gen

04.08.15

Nagpur

Sudama Prasad
Dubey

390

791

Sanjay Budhaji
Khobragade

SC

28.07.15

Chandrapur
Tehsil And
Distt.

Budhaji
Madhavrao
Khobragade

387

Gen

17.08.15

Pune Distt.

Sudamrao
Govindrao Khose

Gen

102/B, Nisarg Akruti Near
Pmt Bus Stop Pimpale
Nilakh Pune Maharashtra411027
Block No.4, Shree Niwas
Building Vithalwadi Akurdi
Pune Maharashtra-411035
H.No.921/002, At And Post
Ghansoli Village Near
Bhavani Mandir Tal. And
Distt.Thane Navi Mumbai
Maharashtra-400701
A/P.Rashin Tal. Karjat
Distt.Ahmednagar
Maharashtra-414403
Flat No.608/B, Malwani
Phulanfi CHS Ltd. Green
View Bldh. Plot No.67
Malwani Malad West
Mumbai Maharashtra400095
Flat No.204, Diwale Gaon
Sector-14 Cbd Belapur Navi
Mumbai Maharashtra400614
Near Sambhaji Kasar Mandir
Maskasath Nagpur
Maharashtra-440002
Near Majer Geat, Vinayaka
App.No.1 Tadoba Road
Chandrapur Tehsil And
Distt.Chandrapur
Maharashtra-442401

MAH/1996/2004
Dt.15.07.04
MAH/3400/2001
Dt.23.10.01

MAH/1151/1994
Dt.26.07.94

MAH/784/1983
Dt.23.06.83

MAH/498/2003
Dt.11.02.03

MAH/46/1997
Dt.10.04.97
MAH/176/2006
Dt.24.01.06

MAH/2399/2005
Dt.04.08.05

<!-- page 49 -->

391

792

Mrs.Sampada
S.Mokal

OBC

23.02.15

Uran
Distt.Raigad
Navi Mumbai

392

793

Awad
Vivekanand
Yuwraj

Gen

20.07.15

Palghar
Distt.Thane

Awad Yuwraj
Shriram

393

794

Mohan
Sakhahari
Shinde

Gen

Nil

Chakur Taluka
And Latur Distt.

Sakhahari
Dhondiram Shinde

394

796

Bharat Lakhu
Machhi

OBC

27.07.15

Palghar Distt.

Lakhu Raju
Machhi

395

798

Avhad
Bhagwan
Vithoba

Gen

31.08.15

Pune Distt.

Avhad Vithoba
Dagadu

396

800

Kripashankar
Singh

Gen

Nil

Mumbai

Lxmi Narayan
Singh

397

805

Mangala
Narayan
Wakhare

Gen

18.08.15

Pune City

Narayan Namdeo
Wakhare

810

Bhore Shivai
Bhagwan

21.08.15

Osmanabad
Distt.Court And
Osmanabad
Distt.

Bhore Bhagwan
Ganpati

398

Gen

Sandesh B.Mokal

H>No.1509, Tandal Nagar
Uran Karanja Road, Near To
Chanje Phata, Tal-Uran
Distt.Raigad Navi Mumbai
Maharashtra-400702
Flat No.102, Bldg-F, Wing-C,
Mahavir Kunj Katkar Pada,
Boisar Tq. Palghar
Distt.Thane Maharashtra401501
At.Post Mahalangi
Ta.Chakur Distt.Latur
MaharashtraAt-Po. Taluka Dahanu
Sonapur Lane Distt.Palghar
Maharashtra-401601
Flat No.404, Gracia, Opp.
Forest County Eon, It Park
Kharadi Pune Maharashtra411014
Sarvodya Kendra Building,
Harsha Pantry 122. Dr.
Maheshwar Road Dongri
Mumbai Maharashtra400009
Wakhare Niwas S.No.49,
Plot No.29, Opp. Awari
Hospital Chandannagar
Nagar Road Pune
Maharashtra-411014
Bhagwan Niwas,
Mukteshwari Nagar Behind
Dyaneshwar Mandir
Osmanabad Maharashtra413501

MAH/413/2005
Dt.10.02.05

MAH/2881/2001
Dt.17.09.01

MAH/1468/1998
Dt.08.09.98
MAH/627/2005
Dt.21.02.05
MAH/6461/2007
Dt.23.11.07

MAH/5125E/1999
Dt.19.08.99

MAH/1427/2004
Dt.16.06.04

MAH/552/1989
Dt.04.04.89

<!-- page 50 -->

399

811

Rajesh
Sahebrao
Sable

SC

10.08.15

Vikhroli East
Mumbai

Lt.Mr.Sahebrao
Damu Sable

400

812

Vinayak
Sopanrao
Jadhav

Gen

18.06.15

Throughout
Maharashtra

Sopanrao Baburao
Jadhav

401

813

Rajesh
Manoharrao
Akotkar

OBC

Nil

Akola Distt.

Manohar
Marotirao Akotkar

402

818

Vikas Bharat
Jagtap

SC

30.06.15

Pimpri
Chinchwad
Area

Bharat Akash
Jagtap

819

Ms.Priyanka
Yogeshrao
More

25.08.15

Baramati
Daund And
Indapur City
Area Of Pune
Distt.

Yogeshrao
Vasantrao More

404

821

Ajay
Chandrahas
Kapile

OBC

25.08.15

Pune Distt.

Chandrahas Hari
Kapile

405

822

Harishchandra
Vitthal Khirid

Gen

17.08.15

Pune Distt.

Vitthal Ganpat
Khirid

403

OBC

Dr.Babasaheb Ambedkar
Nagar Room No.52, Tilak
Nagar Road No.3, Near
Reliance Energy Ltd.Tilak
Nagar Chembur East
Mumbai Maharashtra400089
Varsha Near Gurunanak
School Hanuman Mandir
Chowk Shahu Nagar Beed
Tq.And Distt.Beed
Maharashtra-431122
Godobole Plots Dabki Road
Akola Tq. And Distt.Akola
Maharashtra-444002
Survey No.59/2a/2a,
Vrundavan Colony Near
Laxmibai Tapkir Junior
College Shrinagar Rahatni
Pune Maharashtra-411017
At/P-Nora Tal- Purandhar
Distt.Pune MaharashtraS.No.65, Sindhuchandra
Behind Santoshi Mata
Temple, Santoshnagar
Katraj Pune Maharashtra411046
Survey No.7/2, Raigad
Colony Lane No.10,
Karvenagar Pune
Maharashtra-411052

MAH/551/2005
Dt.21.02.05

MAH/632/2001
Dt.01.03.01

MAH/2292/1999
Dt.27.03.99

MAH/316/2007
Dt.05.02.07

MAH/5560/2006
Dt.11.11.06

MAH/1723/2004
Dt.01.07.04

MAH/951/1996
Dt.30.03.96

<!-- page 51 -->

406

826

Arun Vishnu
Pando

407

830

Ms.Sau Sarika
Prabodh
Ghirnikar

Gen

Nil

Old City Area
Of Akola

Prabodh Anil
Ghirnikar

408

831

Gangadhar
Shsirinivas
Anchan

Gen

00.08.15

Kalwa West
Distt.Thane

Shrinivas A.Kotian

409

834

Rajesh Sundar
Shirke

Gen

21.03.15

Navi Mumbai
Thane

Sundar Bajirao
Shirke

410

839

Shailendra
Keshavrao
Kamble

SC

10.09.15

Beed Distt.

Keshavrao Ranuji
Kamble

411

843

Padmakar
Shankar
Swami

OBC

27.08.15

Miraj Tehsil Of
Sangli Distt.

Shankar
Siddramayya
Swami

412

844

Ms.Jayshree
Lahuji Jawale

SC

04.09.15

Vashi

Lahuji Jagnnath
Jawale

413

846

Nagesh
Kumbre

Gen

20.08.15

Sengaon
Tq.Sengaon
Distt. Hingoli

Chilappa Kumbre

414

852

Mrs.Syed
Sajiya Azim

OBC

18.09.15

Ahmednagar
Distt.

Sayed Farook
Sattar

OBC

26.08.15

Aurangabad
Distt.

Vinshu Govinda
Pando

Flat No.6, K.K.Tower Srpf
Camp Road Satara
Khandoba Aurangabad
Maharashtra-431002
Shriram Sankul, Dabki Road
Godbole Plot Old City Akola
MaharashtraA/2, Flat No.8, Vivek Nagar
Chs Ltd. Near Simming Pool
Manisha Nagar Kalwa West
Distt.Thane Maharashtra400605
A/301 Krishna Kanhaiya Chs
Plot No.21, Sector-8, Airoli
Navi Mumbai Maharashtra400708
Yash Niwas Telephone
Colony Dhanora Road Near
Water Tank Beed Tq And
Distt.Beed Maharashtra431122
Somwar Peth, Near Kolekar
Math Miraj Distt.Sangli
Maharashtra-416410
B-2, 11/16, Sector-16, Vashi
Navi Mumbai Maharashtra400703
At.Po. Apankanergaon Tq.
Sengaon Distt.Hingoli
Maharashtra-431542
18, Rehamaniya Colony
Behind New Distt.Court
Building Fakirwada
Ahmednagar Maharashtra-

MAH/4769/2006
Dt.23.09.06
MAH/793/2001
Dt.01.03.01

MAH/1601/1988
Dt.18.10.88

MAH/512/1999
Dt.16.03.99

MAH/4513/2008
Dt.02.08.08

MAH/1945/2002
Dt.06.09.02
MAH/1136/2004
Dt.19.04.04
MAH/1303/1999
Dt.27.03.99
MAH/1712/2003
Dt.07.07.03

<!-- page 52 -->

415

854

Ms.Pravina
Dhanaji
Sawant

416

856

Gaud Rakhee
Ramesh

Gen

08.05.15

Navapur

Gaud Ramesh
Chunilal

417

860

Ravikiran
Manikrao
Pawar

Gen

15.09.15

Pune Distt.

Manikrao
Shankarrao Pawar

418

863

Shaikh Tahir
Husen Shah
Aziz

Gen

09.09.15

Throughout
Maharashtra

Shaikh Shah Aziz
Balasaheb

419

866

Sushil Khemraj
Chaurasia

Gen

07.09.15

Girgaon
Mumbai

Khemraj Jhurilal
Chaurasia

420

868

Gen

15.09.15

Satara Distt.

Balasaheb
Dhondiram Nikam

421

869

Gen

08.09.15

Pune City

Lt.Sh.Gajanan
Nilkanth Chivate

422

870

Atul Joshi

Gen

08.09.15

Andheri
Mumbai

Bhal Chandra
Joshi

423

872

Fakhrul Hasan

Gen

08.09.15

Court At
Andheri East
Mumbai

Mohammed
Tayyab Shaikh

Amol
Balasaheb
Nikam
Mrs.Sunita
Gajanan
Chivate

Gen

16.09.15

Solapur Distt.

Dhanaji Nankumar
Sawant

Taraanand Nivas, Gandhi
Nagar Uplai Road Near
Govt.Godown Barshi TalBarshi Distt.Solapur
Maharashtra-413411
31, 32, Manda Society
Navapur Distt.Nandurbar
Maharashtra-425418
S.No.45, Flat No.J-701,
Hutown Countrywoods
Tilekar Nagar Kondhwa
Katraj Road Kondhwa Bk
Pune Maharashtra-411048
Behind Ashirwad Clasees
More Colony Jath Tal.Jath
Distt.Sangli Maharashtra416404
158/160, Chaurasia Mansion
3rd Floor R.No.12/13, Sant
Sena Maharaj Marg, Mumbai
Maharashtra-400004
At.Post Shere Tal. Karad
Distt.Satara Maharashtra415108
678/17, Shri Sant Eknath
Society Part-Ii, Bibvewadi,
Pune Maharashtra-411037
2D/503, Casabella CHS Ltd.
Patil Putra Nagar Oshiwara
Jogeshwari West Mumbai
Maharashtra-400102
302, New Fatima Bldg. Near
Peter Churuch Koliwada
Tal.Vasai Distt.Palghar
Maharashtra-

MAH/805/2005
Dt.09.03.05

MAH/1727/2004
Dt.15.07.04

MAH/1737/2005
Dt.15.07.05

MAH/3666/1999
Dt.24.06.99

MAH/3053/2002
Dt.24.10.02
MAH/3453/2003
Dt.13.10.03
MAH/1651/1992
Dt.25.08.92
MAH/1667A/1990
Dt.05.10.90
MAH/1468C/1985
Dt.07.11.85

<!-- page 53 -->

424

873

Manoj Kumar
Mishra

425

876

Mahmood
Ahmad

Gen

Gen

07.09.15

Andheri East
And West In
Greater
Mumbai

Jagnarayan
Mishra

08.09.15

Greater
Mumbai

Masood Ahmad

Chandrabali
Dubey

426

877

Raghvendra

Gen

07.09.15

Saki Naka
Andheri East
At.Greater
Mumbai

427

879

Aniruddha
Ramchandra
Deshpande

Gen

01.09.15

I-U Dd Area

Ramchandra
Vinayakrao
Deshpande

428

880

Sunil
D.Satarkar

SC

08.10.15

Mumbai

Dashrath
L.Kamble

429

881

Shaikh
Shafiyodin
Shamshodin

OBC

03.10.15

Taluka And
Distt.Nanded

Shaikh
Shamshodin Abdul
Khadar

430

882

Vijaykumar
Bhagwan
Shinde

Gen

28.09.15

Paranda Distt.
Osmanabad

Bhagwan Vitthoba
Shinde

431

884

Malik Aslam
Abdul Ganj

Gen

Nil

Greater
Mumbai

Abdul Ganj Malik

Chandrabali Yadav Chawl,
Jijamata Road Pump House
Andheri West Mumbai
Maharashtra-400093
297, Pathanwadi Hutment
Passpoli Filterpada Post
Nitie Aarey Colony Road
Powai Mumbai Maharashtra400087
Room No.2, Santi Seva
Sangh Hanuman Mandir
Galli, Netaji Nagar Khadi
No.3, 90 Ft. Road Sakinaka
Kurla West Mumbai
Maharashtra-400072
Awadhoot Plot No.6 I-U-D-PColony Washim
Maharashtra-444505
Deonar Municipal Colony F5/20, Govandi Mumbai
Maharashtra-400043
Mitra Nagar, Near Halima
Sadiya Masjid Mitra Nagar
Nanded Tq.And
Distt.Nanded MaharashtraA/P. Narshingnagar Paranda
Tal- Paranda
Distt.Osmanabad
Maharashtra-413502
Probunder Building B/20, 3rd
Floor Chiragnagar
Ghatkopar West Mumbai
Maharashtra-400086

MAH/930F/2000
Dt.24.04.2000
MAH/211A/1985
Dt.12.02.85

MAH/930GG/2000
Dt.16.06.2000

MAH/3979/2005
Dt.26.08.05
MAH/956/2005
Dt.22.03.05
MAH/2432/2007
Dt.13.08.07

MAH/2211/2001
Dt.31.07.01

MAH/528/1999
Dt.17.03.99

<!-- page 54 -->

432

885

Gajanan
Suryabhanji
Telgote

433

886

Naik Sunil
Narayanrao

Gen

24.08.15

Jalna

Nail Narayanrao
Vishwanath

434

887

Vijayaratna
Nivant
Atpadkar

OBC

19.09.15

Kavath
Mahankal

Nivant Satwappa
Atpadkar

435

889

Raghuvanshi
Arvind Singh

Gen

20.06.15

Andher East
Mumbai

Sunder Singh

436

892

Mrs.Sahana
Pradeep
Shetty

Gen

16.06.15

Powai Mumbai

Pradeeo
Jayarama Shetty

437

893

Mrs.Vandana
Vinay Waikar

Gen

23.07.15

Greater
Mumbai
Met.Region

Vinay Maruti
Waikar

438

895

Dattatraya
Madhavrao
Goshik

SBC

23.09.15

Jalna Distt.

Madhavrao
Ramayya Ghoshik

25.08.15

Jogeshwari
East And
Greater
Mumbai And
Thane

439

896

S.Syed
Amanulla

SC

22.09.15

Akola Distt.

Suryabhanji Ramji
Telgote

OBC

Syed Mehaboob

Mangal Murti Appartment,
Ambikanagar Malkapur
Road Akola Maharashtra444004
Plot No.22, Shiv Nagar Near
Ghati Railway Gate, Old
Jalna Maharashtra-431213
At.Vithuryachiwadi
Po.Hingangaon Tal-Kavathe
Mahankal Distt.Sangli
Maharashtra-416405
11/J1/206, Shivam Apts.
Sangharsh Nagar Chandivali
Farm Road Chandivali
Andheri East Mumbai
Maharashtra-72
B-106, Blue Nile Pacific
Enclave Chs Ltd.Opp.
Hiranandani Hospital Powai
Mumbai Maharashtra400076
2/9, Navjeevan Co.Op.Hsg.
Indira Nagar, Kanjurmarg
East Mumbai Maharashtra400042
Madhav Kruoa Brahman
Galli, Kadrabad Jalna Taluka
And Distt.Jalna
Maharashtra-431203
Q Block Room No.86, Jhula
Maidan Road Bandra Plot
Jogeshwari East Mumbai
Maharashtra-400060

MAH/1360/2005
Dt.30.04.05
MAH/2846/2003
Dt.27.08.03
MAH/2659/2006
Dt.29.07.06

MAH/3652E/2003
Dt.18.10.03

MAH/3835/2001
Dt.07.11.01

MAH/3306/2001
Dt.01.10.01

MAH/447/1982
Dt.30.03.82

MAH/1862/1991
Dt.27.11.91

<!-- page 55 -->

440

898

Smt.Vidya
M.Naik

441

899

Sanjay
Vishwasrao
Deshmukh

OBC

28.05.15

Katol
Distt.Nagpur

Vishwasrao
Madhorao
Deshmukh

442

900

Sandeep
Janardan More

SC

19.08.15

Mumbai
Suburban Area

Janardan Ravji
More

443

902

OBC

07.09.15

Pune City
Taluka Haveli
Distt.

Manohar
Shankarrao Patil

444

903

Gen

19.09.15

Pune Distt.

Tukaram Haribhau
Patankar

445

904

Ms.Rhuta
Shreesh
Pandit

Gen

14.09.15

Pune Distt.

Shreesh
Shrikrishna Pandit

446

906

Rajesh Kumar
Pandey

Gen

29.09.15

Andheri East
Greater
Mumbai

Kamta Nath
Pandey

447

910

Kalyan
Shivajirao
Lomte

Gen

01.10.15

Beed Distt.

Shivajirao
Kishanrao Lomte

Mrs.
Tarkeshwari
Manohar Patil
Sanjay
Tukaram
Patankar

Gen

25.08.15

Navi Mumbai

Mallu Balkrishna
Naik

Flat No.104, 1st Floor Plot
No.14, New Bombay Safalya
Chs Ltd. Sector-7, Airoli Navi
Mumbai Maharashtra400708
Near Dhantoli Park, Katol
At.And Post Katol
Distt.Nagpur Maharashtra441302
Flat No.101, Shubh Ashish
Chs Plot No.129, Model
Town Off.J.P.Road Opp.
Versova Metro Station
Andheri West Mumbai
Maharashtra-400053
D-303, J.K.Hill Park, Ganesh
Nagar Dhairy Pune
Maharashtra-411041
At/Post Nanvij Tal. Daund
Distt.Pune Maharashtra413801
Plot No.12, Vrindavan
Sector-C, Panchawati
Pashan Pune Maharashtra411008
Flat No.203 C 12 Ajanta
Naigaon East Palghar And
117-A, Apli Ekta Hsg.
Society, 1st Floor Opp.
Bharat Hotel N.I.P.T.Road
Andheri East Mumbai
Maharashtra-400059
Gound Galli, Ambajogai
Distt.Beed Maharashtra431517

MAH/556C/2002
Dt.02.03.02

MAH/685/1988
Dt.15.06.88

MAH/1065/2008
Dt.09.04.08

MAH/2032/2004
Dt.15.07.04
MAH/1215/1993
Dt.30.07.93
MAH/1746/2003
Dt.07.07.03

MAH/2041/1994
Dt.29.11.94

MAH/2485/2002
Dt.13.09.02

<!-- page 56 -->

448

913

Razia Tayeb
Jahagirdhar

449

914

Deepak Sinkar

OBC

23.09.15

Amravati
Tq./Distt.

Sadashibrao
Sinkar

450

915

Sandhya
Sarjerao Owal

SC

25.09.15

Navi Mumbai
And Mumbai

Sarjerao
Sakharam Owal

451

919

Vikas
Premchand
Mahajan

Gen

15.06.15

Malkapur Distt.

Premchand
Kasturchand
Mahajan

452

920

Sambhaji
Gopinath
Munde

OBC

07.10.15

Aurangabad
Distt.

Munde Gopinath
Kishan

453

921

Vivek Bhaskar
Sudade

SC

28.09.15

Mumbai/Thane

Bhaskar Krishna
Sudade

454

924

Phad Vasant

OBC

19.09.15

Throughout
Maharashtra

Phad Sitaram
Bamji

455

925

More Venkat
Dhanraj

Gen

23.09.15

Beed Distt.

More Dhanraj
Nagorao

Gen

15.10.15

Greater
Mumbai Distt.

Tayeb Jahagirdhar

B/702, Magnum Apartment,
Bandivali Hill Road
Jogeshwar West Mumbai
Maharashtra-400102
Devas Apartment, Durga
Vihar Post-H.V.P.M.Amravati
Tq.Distt.Amravati
Maharashtra-444605
Vashi Village, Sector-31-A,
Vashi Navi Mumbai
Maharashtra-400703
Ahinsa Marg, Near Jain
Mandir, Malkapur
Tq.Malkapur Distt.Buldana
Maharashtra-443101
Sai Sankul, Phase-Ii,
Uttaranagari Behind Dhoot
Hospital Jalna Road
Aurangabad Maharashtra431006
Building No.92, Room
No.2600, Kannamwar No.2,
Vikhroli East Mumbai
Maharashtra-400083
Manik Smruti Vaidyanath
Bank Colony Ambajogai
Road Parli-V, Tq.Parli-V,
Distt.Beed Maharashtra431515
Shvneri Niwas
Grampanchyat Road,
Morewadi Post Chanai Tq.
Ambajogai Distt.Beed
Maharashtra-431517

MAH/2506/2000
Dt.15.09.2000

MAH/1666/1991
Dt.10.10.91
MAH/4771/2008
Dt.12.08.08
MAH/2802/1995
Dt.15.11.95

MAH/6148/2006
Dt.11.11.06

MAH/809/2000
Dt.07.04.2000

MAH/497/1997
Dt.28.08.97

MAH/3246/2002
Dt.09.11.02

<!-- page 57 -->

456

927

Ramakant
Raghuraj
Yadav

457

928

Nilkanth
Vinayakrao
Deshmukh

Gen

15.09.15

Risod Tq.And
Risod Distt.And
Washim Distt.

Vinayakrao
Nivruttirao
Deshmukh

458

930

Qureshi Iqbal
Ur Rehman

Gen

27.08.15

Greater
Mumbai

Mumtaz Ahmed

459

931

Pratap Sharad
Patwardhan

Gen

05.10.15

Sangli Distt.

Sharad Ganesh
Patwardhan

460

933

Ms.Santoshi
Ravan
Zombade

SC

06.10.15

Pune City

Ravan Sambhaji
Zombade

461

935

Ms.Leena
Jeevankumar
Bansode

SC

05.10.15

Pune City

Jeevankumar
Madhukar
Bansode

462

937

Rajinder
Kumar

Gen

08.10.15

Mumbai

Beli Ram

463

938

Rajendra
Singh Jadaun

Gen

13.10.15

Mumbai Thane
And Palghar

Ram Bharose
Singh Jadaun

Gen

23.09.15

Goregaon East
Mumbai

Raghuraj Yadav

11/A, Ram Niwas, Aarey
Road Tilak Nagar Nr.
Hanuman Mandir Goregaon
East Mumbai
Mahaharashtra-400063
Loni Road Wadar Wada,
At.Po. Tq.Risod
Distt.Washim Maharashtra444506
Flat No.215,2nd Floor, Zia
Complex Umer Wadi,
Quresh Nagar Kurla East
Mumbai Maharashtra400070
439, Gaon Bhag, Sangli
Mahrashtra-416416
Flat No.202, Sant Sankul
Building S.No.32/8, Abhinav
College Road Narhe Pune
Maharashtra-411041
40/1, Near Dr.Bhor Hospital
Dattanagar Ambegaon Bk,
Pune Maharashtra-411046
Building No.99, Room
No.402, Chaitnya CHS Ltd.
New Mahada Colony
Mankhurd Mumbai
Maharashtra-400071
C/O. Reeta Brine Montero In
Front Of Hanuman Mandir,
Uttan Village Bhayander
West Distt.Thane
Maharashtra-401106

MAH/1805/1995
Dt.12.07.95

MAH/2553/2002
Dt.13.09.02

MAH/1446/1988
Dt.23.09.88
MAH/155/2005
Dt.24.01.05
MAH/2912/2008
Dt.18.07.08
MAH/3425/2007
Dt.02.08.07

MAH/783/2005
Dt.01.03.05

MAH/1594H/2004
Dt.08.06.04

<!-- page 58 -->

939

Dandekar
Shripad

Gen

14.08.15

Dapoli

Ganesh

465

943

Ms.
Rajeshwari
Yogesh
Rajmane

Gen

15.10.15

Pune City

Yogesh Shivling
Rajmane

466

944

Bharat P.Alhat

OBC

09.10.15

Pune City

Pandurang Sopan
Alhat

467

947

Balaji Maroti
Waghmare

SC

08.07.15

Thane
Distt.Court

Maroti Shatiba
Waghmare

468

948

Ms.Asha
Shrirang
Paranjape

Gen

13.08.15

Dombivali
Kalyan Area
Kalyan Taluka
Distt.Thane

Hanumant
Balwant Limhan

469

949

Vinayak
Rajaram Patil

OBC

28.09.15

Amalne
Distt.Jalgaon

Rajaram Chindha
Patil

470

950

Mrs.Jayashree
Dilip Halande

Gen

Nil

Thane Distt.

Dilip Dhondiba
Halande

471

951

Madhukar
Mahadeo Tate

Gen

14.10.15

Indapur Area

Mahadeo
Rangnath Tate

464

H.No.117/1 Behind Mehata
Petrol Pump Dapoli
Distt.Ratnagiri Maharashtra415712
G/7, Building Flat No.4,
Sakalnagar Gate No.1,
S.No.82/A, 83/A, Near
Yashda Baner Road Pune
Maharashtra-411007
At.Post Moshi Panchashil
Road Tal. Haveli Distt.Pune
MaharashtraSiddhivinayak Apartment
2nd Floor, Room No.10,
Post Ghansoli Navi Mumbai
Maharashtra-400701
Re-13, Shubhashree
Bunglow, Gymkhana Road,
Opp.S.T.Depot, Dombivali
East Distt.Thane
Maharashtra-421203
Rajgarh 19/A, Gurukripa
Colony At.Post Amalner
Distt.Jalgaon Maharashtra425401
B1/304, Kalpataru CoOp.Hsg.Society Sector-8b,
Cbd Belapur, Near Durga
Temple Above Rajiv Gandhi
Maidan Navi Mumbai
Tal.And Distt.Thane
Maharashtra-400614
Flat No.7, Nath Complex,
Thorat Nagar, A/P-Bhigwan,
Tal. Indapur Distt.Pune
Maharashtra-413130

MAH/254/1987
Dt.25.02.87

MAH/2632/2008
Dt.18.07.08

MAH/1623/1993
Dt.01.09.93
MAH/893/2002
Dt.06.05.02

MAH/3722/2007
Dt.02.08.07

MAH/2993/1995
Dt.19.12.95

MAH/1162/1998
Dt.06.08.98

MAH/309/1992
Dt.05.02.92

<!-- page 59 -->

952

Shankar
Dnyandev
Erande

473

953

Ms.Saraswati
C.Gharwade

SC

29.09.15

Met.Mag.Court,
Kannamwar
Nagar Vikhroli
East

474

954

Ajay Bharatlal
Gangorti

Gen

19.10.15

Nagpur Distt.

Bharatlal
Koyaliram
Gangotri

475

956

Ramakant
Chandrakant
Kumbhar

OBC

16.10.15

Bhosari
Distt.Pune

Chandrakant
Mahadeo
Kumbhar

476

957

Mohd.Shakir
Ismail Khan

OBC

17.10.15

Pune Distt.

Ismail Maheboob
Khan

477

958

Shkati Suman
Kumar

Gen

19.10.15

Nagpur Distt.

Suman Sidhak
Kumar

478

959

Ms.Bhosale
Sunanda
Chimaji

SC

08.10.15

Nanded Distt.

Bhosale Chimaji
Gyanuji

479

962

Babasaheb
Raosaheb
Kashid

Gen

29.10.15

Mumbai

Raosaheb
V.Rashid

472

Gen

13.10.15

Asalfa Village
Sakinaka
Mumbai

Dnyandev
Sambhaji Erande

Chhaburao
D.Ghardwade

Bhimshankar Warkari Hsg.
Society, Room No.1,
Dhobighat, Pipeline, Asalfa
Village Sakinaka Mumbai
Maharashtra-400072
Building No.198, Room
No.7793, Kannamwar
Nagar-1, Vikhroli East
Mumbai Maharashtra400083
Hansapuri Chohti Khadan
Near Gitanjali Talkies Squar
Nagpur Maharashtra-440018
S.No.98/2, Plot No.31,
Gaumukh Residency Flat
No.10, Guruvihar Colony
Panjarpol, Bhosari Pune
Maharashtra-411039
228/1, Ghorpade Peth,
Behind Post Office Pune
Maharashtra-411042
Plot No.198, Jai Durga
Housing Society No-1,
Narendra Nagar Nagpur
Maharashtra-440015
Nd 41, B2-02/04, Sambhaji
Chowk, Cidco New Nanded
MaharashtraRoom No.378/Bldg.No.12,
Mankhurd Sadguru Krupa
CHS./Lrd. PMGP. Colony
Mankhurd Mumbai
Maharashtra-400043

MAH/2028/2000
Dt.29.08.2000

MAH/3592/2005
Dt.26.08.05

MAH/379/1997
Dt.08.08.97

MAH/271/2005
Dt.03.02.05

MAH/91/2006
Dt.24.01.06
MAH/1486/2001
Dt.04.07.01
MAH/4738/2006
Dt.23.09.06

MAH/390/2004
Dt.20.02.04

<!-- page 60 -->

480

963

Ms.Geeta
Ashok Patil

Gen

00.07.15

Mulund Mumbai

Ashok Kashinath
Patil

481

964

Lal Bahadur
Prajapati

OBC

27.08.15

Naigaon Vasai
Nallasopara
Distt.Thane

Budhiram
Prajapati

482

965

Hindurao
Bhausaheb
Deshmukh

Gen

27.10.15

Mohol Taluka
And Solapur
Distt.

Bhausaheb
Yashwantrao
Deshmukh

483

967

Ms.Chhaya
Rahmin
Laddha

Gen

23.10.15

Akola Distt.

Rashmin Ramesh
Loddha

968

Mohammed
Ilyas
Mohammed
Haroon
Shekhani

OBC

07.10.15

Akola Distt.

Mohammed
Haroon Abdul
Karim Shekhani

485

976

Deepak
Nandlal
Sachdev

Gen

07.11.15

Mulund Mumbai

Nandlal
Kishanchand
Sachdev

486

978

A.Majid Hasan
Banderkar

Gen

27.10.15

Dongri Chinch
Bunder South
Mumbai

Hasan Usman
Banderkar

487

979

Mohammad
Aftab Alam
Khan

Gen

15.10.15

Dongri Chinch
Bunder South
Mumbai

Mohammad Tahir
Khan

484

Indira Sahakar Nagar No.3,
Shree Ganesh Chawl, Near
Ashok Nagar Police Beat,
Nahur Road, Mulund West
Mumbai Maharashtra400080
Flat No.301, Bldg, No.C-8,
Star City, Juchandra
Naigaon East Distt.Thane
Maharashtra-401208
A/P. Mohol, Tal. Mohol
Distt.Solapur Maharashtra413213
Janki Apartment, Durga
Chowk Akola Tq.And
Distt.Akola Maharashtra444005
Near Bohra Masjid,
Mohammed Ali, Road Akola
MaharashtraBlock No.11, Room No.1,
Mulund Colony Mulund West
Mumbai Maharashtra400082
Room No.34/35 Awwal
Manzil, Nouroji Hill Road
Chinch Bunder Dongri
Mumbai Maharashtra400009
625, Rabia Bai Compound
Nr.Ekta Backary Pipe Road
Kurla West Mumbai
Maharashtra-4000070

MAH/3945/2005
Dt.26.08.05

MAH/3378D/2001
Dt.08.09.01
MAH/741/2001
Dt.01.03.01
MAH/1306/2005
Dt.13.04.05

MAH/4443/2008
Dt.02.08.08

MAH/654/2003
Dt.12.03.03

MAH/480/2003
Dt.11.02.03

MAH/4749/2005
Dt.06.10.05

<!-- page 61 -->

488

980

Ms.Prachi
Narsinha
Heela Joshi

Gen

24.11.15

Ratnagiri

Narsinha Vithal
Joshi

489

981

Patil Ramesh
Rajaram

Gen

18.08.15

Kolhapur Distt.

Patil Rajaram
Dada

490

982

Smt.Mahajan
Rekha
Rajendra

OBC

03.10.15

Nashik Distt.

Mahajan Rajendra
Eknath

491

983

Ms.Priti Arvind
Dahotre

OBC

06.12.14

Greater
Mumbai And
Thane Distt.

Arvind Bandoba
Dahotre

492

984

Ms. Geeta
Mohan Bhoir

Gen

19.12.12

Mahim (W)

Mohan Gangaram
Bhoir

493

986

Rakesh Kumar
Yadav

OBC

23.09.15

Kurla West
Mumbai

Ram Deo Yadav

494

987

Mohd.Qasim
Ansari

Gen

05.12.15

Malegaon
Distt.Nashik

Ehsanullah

495

990

Dinesh Babu
Mishra

Gen

28.09.15

Sewri East
Mumbai

Ram Jiyavan
Mishra

3152, Tilak Lane Ratnagiri
Maharashtra-415612
Chavare Tal-Hatkanagale
Distt.Kolhapur Maharashtra416112
C/O.Rajendra E.Mahajan
Om Sai Bunglow-2, Ganesh
Nagar, Sharayu Park Nashik
MaharashtraBK-357/8, Section-32, Ulhas
Nagar, Distt.Thane
Maharashtra-421004
Room No-2 Shanti Chs Near
(D),Bldg Mogal Lane Mahim
West, Mumbai Maharashtra400016
Raj Narayan Shri Niwas
Chawl No.1, Room No.14,
Near Ganesh Maidan, Kaju
Pada Pipe Line Saki Naka
Kurla West Mumbai
Maharashtra-400072
S>No.171/1, H.No.62,
Mohallah Firdos Ganj,
Nayapura Ward Malegaon
Distt.Nashik Maharashtra423203
Room No.95, Phamabai
Chawl, Sewri Koliwada
Sewree East Mumbai
Maharashtra-400015

MAH/987/2007
Dt.09.04.07
MAH/1309/1998
Dt.08.09.98
MAH/1620/1992
Dt.25.08.92
MAH/3424/2003
Dt.13.10.03
MAH/1189/2002
Dt.25.06.02

MAH/4913A/2008
Dt.09.08.08

MAH/285/1988
Dt.15.02.88

MAH/3760C/2001
Dt.05.10.01

<!-- page 62 -->

496

993

Shriniwas
Bhargavram
Ghaisas

497

996

Smt.Kunda
Nana Patil

Gen

13.10.15

Jalgaon

Nana Bandu Patil

498

997

Rakesh
Naresh Malap

Gen

16.10.15

Andheri West

Naresh Subhrao
Malap

499

1000

Nilkanth
Bapurao
Kadam

Gen

17.10.15

Biloli Taluka Of
Nanded Distt.

Bapurao Devrao
Kadam

Gen

03.11.15

Thane/Mumbai

Bhagravram Anant
Ghaisas

Andheri West
Veera Desai
Road And
Areas Of
Andheri
Washi City And
Washi Taluka In
Osmanabad
Distt.

500

1002

Nagesh
Laxman
Mendon

OBC

15.10.15

501

1003

Smt.Shanta
Raghunath
Deshmukh

Gen

07.11.15

502

1004

Ms.Hema/Hem
lata Dalchand
Sharma

Gen

05.11.15

Chalisgaon Tal.
Distt.Jalgaon

Dalchand
Habbalal Sharma

503

1006

Archana
Ramesh
Mendule

Gen

27.08.13

Nagpur

Ramesh Shamrao
Mendule

Laxman Korga
Mendon

Raghunath
Govindrao
Deshmukh

Rm No.3, Gr.Flr, Sai Niketan
Bldg. Behind Hotel Satkar
Old Mumbai Agra Road Lbs
Road Thane West Mumbai
Maharashtra-400602
C/O. B.G.Deshmukh Plot
No.19, Indraprasth Nagar,
Dudh Feration Road Jalgaon
Tq. And Distt.Jalgaon
Maharashtra-425001
38/1509, D.N.Nagar Andheri
Mumbai Maharashtra400053
At.Biloli Swarajya Tukaram
Nagar Biloli Post-Biloli Tq.
Biloli Distt.Nanded
Maharashtra-431710
Flat No.5, Bldg No.C-2,
Darpana Building CHS.Ltd.
Veera Desai Road Andheri
West Mumbai Maharashtra400058
Naikwadi Galli, Washi
Tq.Washi Distt.Osmanabad
Maharashtra-413503
A/P Chalisgaon Distt.
Jalgaon Maharashtra424101
Behind Khobragade
Hospital, Shri Ganesh
Bhawan,
Ganeshpeth,Nagpur
Maharashtra-440018

MAH/1813/1994
Dt.25.10.94

MAH/3000/2008
Dt.18.07.08

MAH/2973/2004
Dt.30.07.04
MAH/825/1997
Dt.17.10.97

MAH/3123/1999
Dt.05.05.99

MAH/436/2004
Dt.20.02.04
MAH/2119/1994
Dt.15.12.94

MAH/630/2001
Dt.01.03.01

<!-- page 63 -->

504

1007

Rajendra
Prabhakar
Sonawane

505

1008

Ms.Swati Vikas
Giranje

Gen

21.11.15

Pune City

Vikas Waman
Giranje

506

1012

Ms.Gayatri
Tukaram Naik

Gen

18.11.15

Pune City

Tukaram
Aannappa Naik

507

1013

Madhavrao
Jaysingrao
Shinde

Gen

16.11.15

Kolhapur Distt.

Jaysingrao
Sarejerao Shinde

508

1016

Prataprao
Sukhdeo Patil

Gen

01.12.15

Throughout
Maharashtra

Sukhdeo Bajrang
Patil

509

1019

Girjashankar
Pandey

Gen

01.12.15

Kandivali And
Borlivali
Distt.Mumbai
Thane

Umapati Pandey

510

1020

Ms.Chhaya
Prashant
Deshmukh

Gen

15.09.15

Pusad Tq.Pisad
Distt.Yavatmal

Prashant
Shankarrao
Deshmukh

511

1024

Ramesh
Laxman
Bhandari

OBC

29.10.15

Pune Distt.

Laxman Ramayya
Bhandari

Gen

27.11.15

Nashik Distt.

Prabhakar Chagan
Sonawane

C/O. Sachin Gulabrao Pawar
Dhandai Karn Nagar Plot
No.126, Opp. Rto Office
Peth Road Panchwati
Nashik Maharashtra-422004
Sainath Complex, Flat
No.B/3, Near Police Station,
At/Post-Bhigwan Tal Indapur
Distt.Pune MaharashtraA-44, Anand Park Society
S.No.49/1/2, Ganesh Nagar
Vadgaonsheri Pune
Maharashtra-411014
Plot No.23, Indira Hsg
Society Ltd.Jaysingpur, Tal.
Shirol Distt.Kolhapur
Maharashtra-416101
At.Post Anajana Nivas
Kurduwadi, Tal, Madha
Distt.Solapur Maharashtra413208
A/1-506, Krishnadham
Tapovan Pathanwadi Opp.
W.E.Highway Malad East
Mumbai Maharashtra400097
Matoshri Near Siddhi
Vinayak Mandir Vivekanand
Society Shrirampur
Tq.Pusad Distt.Yavatmal
Maharashtra-445215
S.No.223, Parijat Colony
Sirum Company Road
Akashwani Hadapsar Pune
Maharashtra-28

MAH/717/1998
Dt.01.07.98

MAH/1812/2002
Dt.24.07.02

MAH/4178/2008
Dt.02.08.08

MAH/1049/2003
Dt.09.05.03

MAH/1370/1987
Dt.15.10.87

MAH/2415/2001
Dt.04.09.01

MAH/648/1998
Dt.16.6.98

MAH/2213/1994
Dt.15.12.94

<!-- page 64 -->

1026

Ms.Nisha
Suresh
Gaikwad

513

1030

Sunil Shivling
Honrao

Gen

16.10.15

514

1036

Ms. Pratima
Yogesh Torpe

Gen

16.10.15

515

1037

Mukund
Dhondopant
Tambekar

Gen

Nil

Pune Distt.

Dhondopant
Ambaji Tambeka

516

1038

Ms. Hajrabanu
Amirkhan
Pathan

Gen

06.11.15

Latur Distt.

Amirkhan
Dulekhan Pathan

517

1039

Vijay Tukaram
Akotkar

OBC

06.11.15

Washim
Malegaon Distt.

Tukaram Jijeba
Akotkar

518

1040

Surendra
Namdeo
Mitegaonkar

Gen

21.10.15

Latur Distt.

Namdeo
Sangappa
Motegaonkar

519

1048

Ms.Sheetal
Mahendra
Tribhuvan

Gen

25.11.15

Pune City

Mahendra Devram
Tribhuvan

512

SC

28.10.15

Pune City
Pune Distt. And
Pimpri
Chinchwad
Area
Pune Distt. And
Pimpri
Chinchwad
Area

Suresh Shankar
Gaikwad

Yogesh Madhav
Torpe

Yogesh Madhav
Torpe

191, Radha Nagar, Opp.
Pcmc Sewage Plant Avove
Sbi Atm, Old Sangvi Pune
Maharashtra-411027
B-702, Queens Town Opp.
Chinchwad Railway Staiton
Chinchwad Pune
Maharashtra-411033
85/1, Co.Op.Housing
Society, M.Phule Nagar
Sector, No.18, Chinchwad
Pune Maharashtra-411019
Flat No.9, Krushna Kala
Society, Dahanukar Colony
Lane No.7, Kothrud Pune
Maharashtra-411029
New Bharat Restaurant
Near, Kedar Xerox, Opp..
Tehsil; Office Main Road
Latur Maharashtra-413512
At.Post Rajura Rao Tq.
Malegaon Distt.Washim
Mahrashtra-444503
C/O Ale Niwas, Near
Ganesh Mandir Shyam
Nagar Latur Tq.And Distt.
Latur Maharashtra-413531
Flat No.303, Sainik
Residency Phase-9, Road
No.10, Ganeshnagar
Bopkhel Pune Maharashtra41101

MAH/2739/2007
Dt.17.07.07

MAH/1135/1988
Dt.16.08.88

MAH/388/1997
Dt.08.08.97

MAH/708/1981
Dt.23.06.81

MAH/1031/1996
Dt.25.04.96
MAH/2912/2005
Dt.26.08.05
MAH/1912/2004
Dt.15.07.04

MAH/3740/2005
Dt.26.08.05

<!-- page 65 -->

520

1051

Hemant
Govind
Tanpure

Gen

21.11.15

Pune Distt.

Govind Kondiba
Tanpure

521

1054

Manjit Singh
Jolly

Gen

16.12.15

Mumbai

Charanjit D.Singh
Jolly

522

1058

Yogesh
Tulshiram
Sonawane

Gen

30.11.15

Chalisgaon Tal.
Distt.Jalgaon

Tulshiram Ambar
Sonawane

523

1059

Mevalal
Ramyagya
Verma

OBC

10.12.15

Mumbai Distt.

Ramyagya Verma

524

1072

Mrs.Sanjana
Sachin Mane

Gen

05.12.15

Pune City

Sachin Krishna
Mane

525

1073

Rameshchand
Bhagchand
Sancheti

Gen

00.11.15

Kolhapur Distt.

Bhagchand
Ramkaran
Sancheti

526

1074

Shrinarayan
Jairam Mishra

Gen

16.12.15

Various Court
Of Mumbai And
Thane Distt.

Jairam Mishra

S.No.16, H.No.1780,
Vakratund Niwas, Near Sai
Siddhi Chowk, Om Sai
Nagar Ambegaon Pathar
Katraj Pune Maharashtra411046
Manish Nagar Bldg.No.39,
Flat No.13, 4-Bunglows, J.P
Road Andheri West Mumbai
Maharashtra-400053
Plot No.15, Shital Shivshakti
Nagar Bhadgaon Road Takli
P.C.Tal. Chalisgaon
Distt.Jalgaon MaharashtraFlat No.409, Mulchand
Zaverchand Sra Chs
Ltd.Kumbharwada,
S.T.Road, Chembur Mumbai
Maharashtra-400071
Nadhenagar Jay Malhar
Chowk, Near Radha Krishna
Temple, Kalewadi Pimpri
Pune Maharashtra-411017
Old Ward No.9/472 Kumbhar
Galli New Ward No.11/36
Kumbhar Gali Behind Renval
Bank Ap/ Ichalkaranji
Distt.Kolhapur Maharashtra416115
Jairam Mishra Chawl,
Gamdevi Road, Poisar,
Kandivali East Mumbai
Maharashtra-400101

MAH/2195/2005
Dt.15.07.05

MAH/1593/2000
Dt.04.08.2000

MAH/3660/1999
Dt.24.06.99

MAH/466A/1992
Dt.15.02.92

MAH/91/2002
Dt.17.01.02

MAH/370/1986
Dt.10.03.86

MAH/436/1994
Dt.02.03.94

<!-- page 66 -->

527

1075

528

1076

529

1077

530

1081

Rajbahadur
Yadav
Ms.Anita
Vijayrao
Bhandale
Ms.Priyanka
Panjabrao
Padghan
Chandrakant
Kamble

Gen

15.12.15

Greater
Mumbai

Banshidhar Yadav

OBC

28.12.15

Manora
Tq.Manora
Distt.Washim

Vijayrao
Sakharam
Bhandale

Vanse Compound
Maheshwar Nagar
Appapada Kurur Village,
Malad East Mumbai
Maharashtra-400097
Vasantnagar Manora
Tq.Manora Distt.Washim
Maharashtra-

SC

28.12.15

Mangrulpir
Distt.Washim

Panjabrao Deoji
Padghan

New Sonkhas Jamb Road
Mangrulpir Maharashtra

MAH/3971/2007
Dt.02.07.07

SC

08.12.15

Khadki

Deoram

442 Old Bazar Khadki Pune
Maharashtra-411003
C.T.S.No.15a/10, Flat No.4,
Shefali Building Erandwane,
Karve Road, Pune
Maharashtra-411004
Om, 672, Ganesh Colony,
Belthikangar 16no. Bus Stip,
Thergaon Tal.Sub Div Mulshi
Distt.Pune Maharashtra411033
Flat No.9, Swapnaraj Park,
Behind Darshan Hall, Tanaji
Nagar Chinchwad Pune
Maharashta-411033
Vasudev Niwas, Opp.
Sakubai Niwas Balkum Pada
No.3 Thane West
Maharashtra-400608
In Front Of Gujarati National
High School, Rail-Toly
Gondia Tehsil And Distt.
Gondia Maharashtra-441614

MAH/549/1981
Dt.28.04.81

531

1082

Ms.Aditi
Ravindra
Kulkarni

Gen

16.12.15

Pune City

Ravindra
Prabhakar
Kulkarni

532

1084

Maid Vijay
Gorakhnath

OBC

14.12.15

Thergaon Tal.
Mulshi
Distt.Pune

Maid Gorakhnath
Baburao

533

1085

Narsinh
Krishna Ingale

Gen

16.12.15

Pimpri
Chinchwad And
Pune Area

Krishna Sadashiv
Ingale

534

1086

Jayesh
Purushottam
More @ Shroff

Gen

07.11.15

Thane Distt.

Purushottam
Ganpat More

535

1087

Sandipkumar
Vinjrajbhai
Khanted

Gen

23.11.15

Gondia Distt.

Vinjraj Chunilal
Khanted

MAH/767/1996
Dt.27.03.96

MAH/5388/2006
Dt.23.09.06

MAH/4269/2005
Dt.23.09.05

MAH/1635/2003
Dt.07.07.03

MAH/782/1999
Dt.23.03.99

MAH/60/1994
Dt.05.01.94

MAH/1503/2003
Dt.26.06.03

<!-- page 67 -->

536

1088

Kalyan
Shesherao
Bhosale

Gen

19.12.15

Udgir
Distt.Latur

Shesherao
Madhavrao
Bhosale

537

1089

Jairaj
Pandurang
Jadhav

SC

Nil

Ausa Taluka
And Latur Distt.

Pandurang Mesaji
Jadhav

538

1090

Mrs.Veena
Shivcharan
Yadav

Gen

19.12.15

Malad East
Mumbai

Veena Jigari
Yadav

539

1099

Nitin Ram
Pardhi

OBC

17.12.15

Nagpur

Ram Madhavrao
Pardhi

540

1100

Ms.Naik
Snehal Kalidas

Gen

21.12.15

Throughtout
Pune Distt.

Badave Tukaram
Vasudev

541

1101

Parashuram
Dnyanoba
Shinde

Gen

19.12.15

Pune City

Dnyanoba Joti
Shinde

542

1102

Ms.Vaijayanti
Mukund
Mahashabde

Gen

19.12.15

Pune City

Mukund Gajanan
Mahashabde

543

1104

Ramakant
Maruti Patil

Gen

Nil

Kavathe
Mahankal
Taluka

Maruti Bharmu
Patil

544

1108

Ms.Manisha
Dinkerrao
Palve

Gen

21.12.15

Pune City

Dinekerrao
Savleram Palve

Bhosale Niwas, Nai Abadi
Shashtri Nagar Behind
Nagar Parishad Udgir
Tq.Udgir Distt.Latur
Maharashtra-413517
At.Bhim Nagar, Ausa Ta.
Ausa Distt.Latur
Maharashtra-413520
B-3/A, Ashiyana Apartment,
Upper Govind Nagar Mala
East Mumbai Maharashtra400097
Plot No.73-B, Ambika Nagar
Near Hanuman Mandir
Manewada Road Nagpur
Maharashtra-440024
Sneh-Sadan, Siddheshwar
Lane, Baramati Tal-Baramati
Distt.Pune Maharashta413102
S.No.24/2/4, Ambegaon
Pathar, Opp. Swami
Samarth Math Pune
Maharashtra-411046
370, Sadashiv Peth, B-5
Vyankatesh Apartments,
Pune Maharashtra-411030
A/P.Jayagavhan Tal.
Kavathe Mahankal
Distt.Sangli Maharashtra2, Nandan Apartment, Plot
No.81, Right Bhusari Colony
Paud Road Kothrud Pune
Maharashtra-411038

MAH/2523/2002
Dt.13.09.02

MAH/2009/2007
Dt.03.07.07
MAH/3988/2005
Dt.02.08.08

MAH/1184/2002
Dt.25.06.02

MAH/538/1992
Dt.06.03.92

MAH/2373/1998
Dt.14.12.98
MAH/803/1989
Dt.04.07.89
MAH/169/2005
Dt.24.01.05
MAH/754/2006
Dt.08.03.06

<!-- page 68 -->

545

1109

Ms.Urmila
Tulshiram
Kalbhor

Gen

18.12.15

Pune City

Lt.Tulshiram
Namdeo Kalbhor

546

1111

Kailash
Vinayak
Ahiwale

SC

22.12.15

Pune Distt.

Vinayak Dagadu
Ahiwale

547

1115

Dnyaneshwar
Shrawan
Mahajan

OBC

04.09.15

Dhule Distt.

Shrawan Tanaji
Mahajan

548

1116

Laxmanrao
Panditrao Patil

OBC

22.12.15

Dhule Distt.

Panditrao Daulat
Patil

549

1119

Dadapatil
Bhivrao
Jadhav

OBC

27.01.16

Ahmednagar
Distt.

Bhivrao Murlidhar
Jadhav

550

1120

Ms.Deepmala
Maniksha
Sawant

SC

20.01.16

Thane

Maniksha
Tukaram Sawant

551

1121

Gen

31.01.16

Aurangabad

Marutirao
Dhondiram
Gaikwad

552

1123

SC

11.02.16

Nashik Distt.

Vijay Waman
Tuplondhe

SC

19.02.16

Aurangabad

Marutirao Subrao
Gangachari

553

1125

Rajeev
Marutirao
Gaikwad
Mrs.Kanchan
Vijay
Tuplondhe
Pagare
Shrinivas
Marutirao
Gangachari

Yamunateer Tuljadevi Vasti
Near Bank Of Maharashtra411035
H.No.1423, Milind Nagar
Near Raju Vahile Chawl,
At.Post Vadgaon Maval RalMaval Distt.Pune
Maharashtra-412106
A/P. Plot No.65-A, Gawale
Nagar Nr.At/Post Dhanur
Tal.And Distt.Dhule
Maharashtra-424005
12-A, Marchant Bank
Colony, Dhule Maharashtra424001
Nimbhari Post- Pachegaon
Tal-Newasa
Distt.Ahmednagar
Maharashtra-413725
Flat No.402, Khushboo
Apartment Bhusar Ali Road
Near Swami Samarth
Kendra Kalwa West Thane
Maharashtra-400605
H.No.R23/6 Tornagad Nagar
Cidco N-2, Aurangabad
Maharashtra-431003
6, Suvarna Apartment
Shrikrishna Nagar Satpur
Colony Nashik Maharashtra422007
Plot No.21 Gat No.112
Venkatesh Niwas Venkatesh
Nagar Beed By Pass Road
Aurangabad Maharashtra431010

MAH/528/1994
Dt.02.03.94

MAH/1022/1993
Dt.23.07.93

MAH/1432/2003
Dt.26.06.03
MAH/351/1994
Dt.14.02.94
MAH/1522/2004
Dt.1606.04

MAH/4672/2008
Dt.12.08.08

MAH/4143/2004
Dt.14.09.04
MAH/2105/2005
Dt.15.07.05

MAH/2452/2006
Dt.15.07.06

<!-- page 69 -->

24.03.16

Nashik Distt.

Jayram Shankar
Khalate

Gen

04.05.15

Shirpur City
Dist. Dhule

Gujarathi
Jagnnath
Fulchand

Gen

18.08.15

Suratwala
Building Area

Dinkar Anant
Adawadkar

OBC

05.03.16

Ahmednagar
And Pune Cities

Bhanudas

Gen

09.02.16

Kolhapur

Vyankatrao
Ramchandra
Khamkar

Ravindrakant
Mahadeo
Gujar

Gen

09.04.16

Pune Distt.

Mahadeo G.Gujar

1141

Chandrapraka
sh Shukla

Gen

09.02.16

Kalyan Distt.

Adyaprasad
Shukla

1142

Prabhakar
Rampyare
Shukla

Gen

27.02.16

Mumbai

Rampyare Shukla

1145

Sachin
Parashram
Kale

Gen

23.03.16

Nashik Distt.

Parashram
Karbhari Kale

1129

555

1131

556

1133

557

1134

558

1137

559

1140

560

561

562

Smt.Vijaya
Jaywant
Jagtap
Gujarathi
Gajendra
Jagannath
Adawadkar
Lalitagauri
Dinkar
Yuvraj
Bhanudas
Pote
Vijay
Yankatrao
Khamkar

Gen

554

6 Govind Nagar Vinchur
Road,Lasalgaon,Tal
Niphad,Nashik -422306
At. Po. 2361 Gujarathi Gally
Shirpur Tah Shirpur Dist.
Dhule Maharashtra
14, Viduyt Nagar Colony No.
1 Opp. Railway Station
Dhule - 424001
504 Civil Hudco Savedi
Road Ahmednagar
Maharashtra
Vivekanand Nagar Malbagh
Korochi Tal Hatkangale
Kolhapur Maharashtra
Building No.8, Blocj No.30,
Sharad Sahakari
Punarvasan Sanstha
Maryadit, Off Senapati Bapat
Road, Shivajinagar Pune
Maharashtra-411016
2/2, Rajkaran Shukla Netaji
Subhash Nagar Asalpha
Village Ghatkopar West
Mumbai Maharashtra400084
Flat No.203 A5, Shankar
Pawshe Road Saibaba
Nagar Katemanewali Kalyan
East Thane Maharashtra421306
Flat No.2, Pushparang
Co.Op. Hsg Soc. Trambak
Nagar Jai Bhawani Road
Nashik Road Maharashtra422101

MAH/3029/1999
Dt.27.03.99
Mah/517/1996
Dt.02.03.96
MAH/
MAH/4102/2008
Dt.02.08.08
MAH/1738/2003
Dt.07.07.03

MAH/951/1984
Dt.26.07.84

MAH/1325/1999
Dt.27.03.99

MAH/186A/1980
Dt.09.02.80

MAH/1691/2003
Dt.07.07.03

<!-- page 70 -->

563

1148

Prasanna
Vansat Bhoir

564

1152

Shripad
Ganpat Bari

565

1153

566

1154

567

1155

568

1156

Makarand
Madhao
Pathak
Ramesh
Dongar Gujar
Punam
Pandharinath
Moon
Kadam
Siddharth
Chandrakant
Alandikar
Ganesh
Machhindranat
h

SC

18.02.16

Thane

Vasant Dewoo
Bhoir

OBC

16.03.16

Dahanu(M.S)

Ganpat Mangal
Bari

Gen

27.04.16

Bhgwannagarn
agpur
Maharashtra

OBC

14.04.16

Dhule

SC

11.01.16

Nagpur

Pandharinath
Bhaduji Moon

SC

10.01.16

Bhokar Distt.
Nanded

Kadam
Chandrakant
Madhavrao

Pune

Alandikar
Machhindranath
Baburao

Malegaon

Ingale Bhaurao
Jibhau

569

1157

570

1158

Ingale Shrikant
Bhaurao

Gen

571

1160

Khandeshe
Mugdha Milind

Gen

03.03.16

Ambegaon

Khose Nivrutti
Girju

572

1162

OBC

15.02.16

Buldana Distt.

Atmaram
Daulatrao Bhagile

573

1167

Gen

24.02.16

Ahmednagar

Mohan Eknath
Ghan

574

1169

OBC

13.03.16

Aurangabad

Madhukar Vitthal
Kathar

Ramesh
Atmaram
Bhagile
Anagha Vilas
Chiplukar
Bhushan
Madhukar
Kathar

OBC

21.04.16

Madhao
Purushottam
Pathak
Dongar Namdev
Patil

S.Sawarkar Marg Near
Boyes Hostel At.Post-Tal.
Jawhar Distt.Palghar Thane
Maharashtra-401603
At Khara Kumbhar Wada
Dahanu Road Tal Dahanu
Palghar-401601
Plot No. 100, Bank Colony
Bhagwan Nagar Post Parvati
Nagar Nagpur-440027
Plot No. 15,Vakil Colony
Shirpur-425405
H.No. F-39, Sadiqabad
Colony, Besides Passport
Office, Nagpur-13
H.No. 59, Nanda(Patti
Mahisa) Post Matul Tq
Bhokar-431801
At Post Someshwarnagar
(Karanjepul) Tal Baramati
Distt Pune Maharashtra412306
Shripranel Arunoday Colony
College To Soygaon Road,
Malegaon
Bankhele Complex,
Opposite St Stand Manchar
Taluka Ambegaon-410503
Aras Layout Ward No.20
Buldana Maharashtra443001
Plot No. 132, Dharmadhikari
Mala, Savedi-414003
Sahyadri Opposite Shivaji
High School, Khokadpura431001

MAH/1824/1995
Dt.12.07.95
MAH/65/1993 Dt
13.01.1993
MAH/3645/2001
Dt.23.10.01
MAH/1307/2003
Dt.18.06.06
MAH/4896/2007
Dt.02.09.07
MAH/3208/2005
Dt.26.08.05
MAH/3836/2008
Dt.02.08.08
MAH/1272/1990
Dt.21.08.1990
MAH/866/2001
Dt.14.03.2001
MAH/3388/2006
Dt.29.07.06
MAH/1074
Dt.19.04.2004
MAH/4312/2008
Dt.02.08.08

<!-- page 71 -->

575

1170

Jitendra

SC

07.03.16

Dighi

Jayram

576

1171

Mangal

SC

08.03.16

Aurangabad
Distt.

Laxmanrao

577

1172

Gen

24.03.16

Jaysingpur
Maharashtra

Kagawade
Baburao Narsappa

578

1173

SC

Nil

Nashik

Ramchandra
Shankar Jadhav

Greater
Mumbai

Sumant Bharghav
Ghaisas

Kagawade
Rajesh
Baburao
Rajesh
Ramchandra
Sulochana
Jadhav

579

1176

Mrs. Varsha
Sumant
Ghaisas

580

1179

Gajanan
Dinkarrao
Hingmire

Gen

16.03.16

Tehsil
Hinganghar In
Wardha Distt.

Dinkarrao Bhaurao
Hingmire

581

1180

Kailash Rathod

OBC

19.05.16

Pusad

Amarprem Rathod

582

1181

Ms. Pradnya
Pravin Killekar

Gen

09.04.16

Alibag Distt.
Raigad

Pravin Dattatreya
Killekar

Gen

Plot No 66 Blodg No E Flat
No 1, B U Bhandari Skyline
Cooperative Housing
Society, Ground Floor Datta
Nagar Dighi-411015
Gulab Vishwa Society, Flat
No. 12, 4th Floor, A Wingh,
Pethe Nagar, Aurangabad
Maharashtra
Plot No 52, Yashwant
Housing Society Jaysingpur
Tal Shirol
Flat No. 13/2nd Floor
Sunflower Residency, Near
Narayan Bapu Nagar, Jail
Road Nashik Road-422101
Flat No.203, Phatak Bldg.
Chs Nehru Rd.Above
Saraswat Bank Vileparle
East Mumbai Maharashtra400057
Gandhi Ward Main Road,
Hinganghar Tehsil
Hinganghat Distt.Wardha
Maharashtra-442301
Amarprem Niwas Behind
Warsha Ice Factory
Shrirampur Pusad Yavatmal
Maharashtra-445215
Prabha Shankar Housing
Society, Pnp Nagar Building
4 Block No.16, B Wing 2nd
Floor Near Hotel Ramakant
Alibag Tal. Alibag
Distt.Raigad Maharashtra402201

MAH/6414/2008
Dt.13.12.08

MAH/634/2009
Dt.21.02.09
MAH/697/1996
Dt.12.03.96
MAH/797/2006
Dt.24.03.06

MAH/1423/1987
Dt.15.10.87

MAH/3093/2005
Dt.26.08.05

MAH/2611/2000
Dt.16.09.2000

MAH/4759/2006
Dt.23.09.06

<!-- page 72 -->

583

1184

Sagar Subhas
Pisal

Gen

01.04.16

Kolhapur Distt.

Subhash
Ramchandra Pisal

584

1185

Ms.Shourya
Suresh Pawar

Gen

05.04.16

Sangli Distt.

Mehbub Kasam
Attar

585

1186

Sagar
Sadashiv
Sathe

Gen

02.02.16

Sadashiv Peth

Sadashiv Keshav
Sathe

586

1187

Ms.Kavita
Mahadev
Waghmare

SC

10.04.16

Mumbai

Mahadev
Waghmare

587

1188

Chetan Amrut
Kale

Gen

15.04.16

Pune Distt.

Amrut Maruti Kale

588

1189

Jaswinder
Singh A.
Oberoi

Gen

05.05.16

Pune

Amarjit Singh
Oberoi

589

1191

Aher Vasant
Parashram

Gen

05.03.16

Nashik Distt.

Aher Parashram
Ramchandra

590

1194

Mrs.Seema
Kiran Bhosale

Gen

31.03.16

Khadki Pune

Rangnath M Babar

591

1196

Prashant
Vitthal Thakare

OBC

18.03.16

Nashik City

Vitthal

1953, B Ward Mangalwar
Peth Kolhapur Maharashtra416012
Gourav Lengare Road
Yashwant Nagar Vita Tal
Khanapur Distt.Sangli
Maharashtra-415311
Cts No.1357 Sathe Wada
Sadashiv Peth Pune
Maharashtra-411030
1, Saibaba Chawl,
Maharashtra Nagar,
Mankhurd, Near Mhada
Colony, Mumbai
Maharashtra-400088
Plot No.13 Shahajiraje
Co.Op. Housing Society
Survey No.159-A, Hadapsar
Near Amar Cottage Pune
Maharashtra-411028
Bunglow No.12, Kahun Road
Near Army Supply Depot
Camp Pune Maharashtra411001
At Post-Naydongri TalNandgaon Distt.Nashik
Maharashtra-424109
453/9, Old Bazar Hule Chawl
Near Ram Mandir Khadki
Pune Maharashtra-411003
Indrayani Niwas Vidya Nagar
Station Road Lasal Gaon
Taluka Niphad Nashik
Maharashtra-422306

MAH/1523/2002
Dt.05.07.02
MAH/205/1996
Dt.22.01.96
MAH/159/2004
Dt.06.01.04

MAH/4207/2007
Dt.17.08.07

MAH/1376/2002
Dt.25.06.02

MAH/1343/2005
Dt.30.04.05
MAH/359/1983
Dt.17.03.83
MAH/756/1999
Dt.27.03.99
MAH/1735/2006
Dt.07.07.06

<!-- page 73 -->

592

1197

Dhananjay
Vishwasrao
Ambatkar

OBC

Nil

Saoli Tehsil

Vishwasrao
Sakharamji
Ambatkar

593

1198

Ms. Manisha
Ganpat Koli

OBC

09.04.16

Uran And
Panvel Court

Gapat Damu Koli

594

1199

Ms. Anita
Pratarprao
Deshmukh

Gen

13.04.16

Yavatmal Distt.

Prataprao
Shankarrao
Deshmukh

595

1200

Ms. Arati
Vishwasrao
Kale

OBC

05.03.16

Distt.Court
Pune

Vishwasrao

596

1203

Manoj
Mohanrao
Jagtap

Gen

17.03.16

Aurangabad

Mohanrao
Jayavantrao
Jagtap

597

1210

Amar Vithalrao
Pawar

Gen

13.05.16

Latur Distt.

Vithalrao Bapurao
Pawar

598

1211

Laxmikant
Kailas Shinde

OBC

07.04.16

Jalgaon

Kailas Sonu
Shinde

599

1213

Balasaheb R
Patil

Gen

24.05.16

Kolhapur

Rudragonda B
Patil

1217

Vikal
Omprakash
Chachra

Gen

13.04.16

Nagpur Distt.

Om Prakash
Chachra

600

At.Po.Tehsil Saoli
Distt.Chandrapur
Maharashtra-441225
85-1094-A, Mora Koli Wada
Uran Raigad Maharashtra400704
Gandhi Nagar Behind Naik
Bunmglow Pusad Tq Pusad
Yavatmal Maharashtra445204
Row House No.24, Konark
Pooram Kondhwa Kurdh
Pune Maharashtra-411048
AAI N-7 L1-17, Maharana
Pratap Housing CIDCO
Aurangabad Maharashtra431003
C/O Dt.S.B.More Jaial
Heritage Near
A.R.T.O.Office Babhlggaon
Road Latur Tq And Distt.
Latur Maharashtra-413512
Raje Shivaji Chouk Raver
Tal Raver Jalgaon
Maharashtra-425508
2733 D Ward Shukrawar
Peth Near Jain Math
Kolhapur Maharashtra416002
Flat No.503 B Pioneer
Regency C-6 Near
K.T.Nagar Katol Road
Nagpur Maharashtra-440013

MAH/392/2007
Dt.05.02.07
MAH/3765/2007
Dt.02.08.07
MAH/3996/2004
Dt.03.09.04
MAH/3562/2004
Dt.23.08.04
MAH/3487/2003
Dt.13.10.03

MAH/1183/1999
Dt.27.03.99

MAH/2108/2008
Dt.18.07.08
MAH/42/1989
Dt.11.01.89

MAH/3069/2005
Dt.26.08.05

<!-- page 74 -->

601

1218

Rajesh
Shankarrao
Ghuge

602

1219

Dinesh
Janardhan
Zilte

SC

23.07.16

Hinganghat
Distt.Wardha

Janardhan
Chintaman Zilte

603

1220

Ms.Surekha

Gen

27.02.16

Mawal

Jeevan

604

1222

Subhash
Chandrabhan
Gadekar

Gen

19.04.16

Thane City And
Thane
Distt.Court

Chandrabhan
Narayan Gadekar

605

1223

Ms. Vispute
Sadhana
Laxman

OBC/PH

22.04.16

Ulhasnagar

Vispute Laxman
Chintaman

606

1228

Ms.Jyostana
Chandrakant
Tawate

OBC

02.05.16

CJJD And
JMFC Shirur
Kasar

Chandrakant
Baburao Tawate

607

1229

Abdul Gani
Chunawala

Gen

06.05.16

Thane Distt.

Kader Chunawala

608

1240

Arun Shriniwas
Bodhani

Gen

05.07.16

Pune

Shriniwas
Dattatray Bodhani

Gen

20.08.16

Aurangabad

Shankarrao
Laxmanrao Ghuge

Plot No.24/2, H.No.3-18-138,
Banjara Colony, Near Datta
Temple Prem Niwas
Aurangabad Haryana431001
Hanuman Ward Hinganghat
Teshil Hinganghat
Distt.Wardha Maharashtra442301
Plot No.42, Vishvajit
Rajgurav Colony Talegaon
Station Taluka Mawal Pune
Maharashtra-410507
Andumber Chhaya CHS Ltd.
3rd Floor Flar No.13, Kopri
Colony, Thane East
Maharashtra-400603
203, 204, Ashirwad Aptm
Opp. Police Line Near
No.14, School Ulhasnagar
Maharashtra-421004
Junawada Chowk At.Post
Tq.Shirur Kasar Distt.Beed
Maharashtra-413249
Umair Baug Flat No.5 BWing Ground Floor Near AlNadi-Ul-Dfalah English
School Opp. Minar Regency
Kausa Mumbra Thane
Maharashtra-400612
B-34 Motiram Park Opp.
Kothrud Bus Stand Kothrud
Pune Maharashtra-411038

MAH/3078/2009
Dt.18.07.09

MAH/1086/2007
Dt.17.05.07

MAH/5968/2008
Dt.08.11.08

MAH/4501/2004
Dt.25.10.04

MAH/3536/2008
Dt.02.02.08
MAH/1438/2008
Dt.03.06.08

MAH/4923/1999
Dt.21.09.99

MAH/667/1992
Dt.11.04.92

<!-- page 75 -->

609

1243

Patil
Pradipsing
Durgadas

610

1244

Ms.Deepa
Sadashiv
Godse

Gen

02.05.16

Thane

Sadashiv Nana
Godase

611

1245

Ms.Patil
Sharayu
Pramod

Gen

31.03.16

Kolhapur

Pawar Subhash
Sadashiv

612

1246

Patil Pramod
Vasantrao

Gen

31.03.16

Kolhapur

Patil Vasantrao
Narhar

613

1248

Ms.Wagh
Swati
Fulchand

Gen

31.03.16

Pune

Fulchand

614

1249

Ms. Rachana
Joshi

Gen

14.04.16

Khamla Nagpur

Dattatraya Joshi

615

1250

Gopichand
Adhar Patil

OBC

09.04.16

Mumbai And
Thane

Adhar Patil

616

1253

Gen

16.04.16

Cjjd Gangapur

Subhashrao
Eknath Shinde

617

1256

Gen

14.04.16

Jalgaon Dhule
And Nashik

Rameshwar
Ramchandra
Sharma

Bhagwan
Subhashrao
Shinde
Shailesh
Rameshwar
Sharma

Gen

30.06.16

Nandurbar

Patil Durgadas
Ganpat

Plot No.29 Kamnath
Mahadev Nagar Back Essar
Petrol Pump Nandurbar Tal.
Distt. Nandurbar
Maharashtra-425412
12 Abhishek Apt. Near Shri
Krida Mandal Sawarkar
Nagar Thane West
Mahrashtra-400606
Ar.Junwad Tal Shirol
Distt.Kolhapur Maharashtra416120
At Post Arjunwad Tal Shirol
Kolhapur Maharashtra416120
F-304, Highbliss Rajyog
Colony Behind D Y Patil
College Walhekarwadu
Chinchwad Pune
Maharashtra-411033
164, Flat No.S-1 Om Aptt.
Pande Layout Khamla Near
Datta Meghe's House
Nagpur Maharashtra-440025
702/B, Shreeyanad Shivaji
Nagar Bcabin Road
Naupada Thane
Maharashtra-400602
Laxmi Colony Gangapur
Aurangabad Maharashtra431109
Bhavsar Galli Main Road
Chopda Jalgaon
Maharashtra-425107

MAH/1519/2006
Dt.19.06.06

MAH/3617/1999
Dt.01.09.99
MAH/3669/1999
Dt.24.06.99
MAH/1521/1998
Dt.23.09.98

MAH/1975/2003
Dt.18.07.03

MAH/317/2006
Dt.24.01.06

MAH/12/2001
Dt.22.01.01
MAH/3212/2004
Dt.30.07.04
MAH/1349/2003
Dt.18.06.03

<!-- page 76 -->

618

1257

Ms.Zample
Anuradha
Shivajirao

619

1259

Balasaheb
Dattatraya
Ambad

Gen

26.05.16

Beed Distt.

Dattatraya
Rambhau Ambad

620

1260

Ms.Thakor
Manisha
Durgadas

ST

24.05.16

Satana Tasl
Baglan
Distt.Nashik

Pawar Jaywant
Dilip

621

1261

Ms.Mubeena
Mansoor
Jahagirdar

Gen

25.06.16

Ahmednagar
Distt.

Mansoor
Jahagirdar

622

1262

Kiran Eknath
Vatsala Patil

OBC

20.06.16

New Panvel

Eknath Narayan
Patil

623

1263

Kadam
Sandeep
Ambadas

Gen

02.04.16

Deolali Camp
Nashik Road

Ambadas Shankar
Kadam

624

1264

Anilkumar
Lodha

Gen

23.02.16

Nandurbar

Khushalchand
Loda

OBC

26.04.16

Jayastambha
Tal.
Distt.Ratnagiri

Sudesh

Gen

05.01.16

Thane

Santosh Anandrao
Jadhav

625

1265

626

1266

Mrs.
Samruddhi
Sudesh
Mayekar
Ms.Vandana
Santosh
Jadhav

Gen

07.06.16

Latur Distt.

Shivajirao Zample

Block No.7, Chanaykay
Appt.Trimurti Nagar
Savewadi, Latur Mahrashtra413531
Muktai Niwas Yashwant
Nagar Morewadi Ambajogai
Tq.Ambajogai Distt.Beed
Maharashtra-431517
Anil Niwas Tilak Road
Satana At Post Satana Tal
Baglan Distt. Nashik
Maharashtra-423301
H.No.1719 Zhendigate Near
Saidu Karanja Masjid
Ahmednagar Maharashtra414001
C-5/2/1-1, Sector-18 New
Panvel Raigad Maharashtra410206
Rest Camp Road Opp. Devi
Mandir Deolali Camp
Maharashtra-422401
Plot No.128, Vrindawan
Colony Nandurbar
Maharashtra-425412
H.No.1034, Opp.
Jayastambha Ratnagiti Hotel
Manglad Near S.T.Stand Rig
Maharashtta-415612
B-704, Nature Glory Parsik
Nagar Kharegaon Kalwa
Thane Mahrashtra-400605

MAH/788/2000
Dt.07.04.2000

MAH/4739/1999
Dt.18.08.99

MAH/1845/2006
Dt.07.07.06

MAH/2394/2007
Dt.17.07.07
MAH/4152/2006
Dt.09.08.06
MAH/3763/2003
Dt.17.11.03
MAH/2117/1996
Dt.16.08.96
MAH/3362/2002
Dt.09.11.02
MAH/947/2005
Dt.22.03.05

<!-- page 77 -->

627

1267

Ms. Monali
Gajnan Shete

OBC

22.07.16

Thane Distt.

Gajanan Dhondu
Shete

628

1269

Ms. Dipali

OBC

04.06.16

Pune Distt.

Bhagavantrao

629

1271

Manik Pralhad
Dusunge

SC

03.06.16

Haveli

Pralhad Laxman
Dusunge

630

1273

Ms. Mote
Ranjana Lala

OBC

07.05.16

Baramati

Yedage Pratap
Babasaheb

631

1274

Sanjay Gore

OBC

Nil

Washim
Malegaon Distt.

Ramkrushna Gore

632

1275

Sayaji Ishwar
Nalwade

Gen

30.06.16

Vita

Ishwar Natha
Nalwade

633

1276

Santoshkumar
Narayan
Jadhav

Gen

30.06.16

Vita

Narayan
Dnyandev Jadhav

634

1277

Sanjay
Shridhar
Nagargoje

OBC

04.07.16

Pune

Shridhar Kondiba
Nagargoje

Flat No.301, B Wing Noori
Baug Apartment Nori Baba
Darga Road Makhmali Talao
Thane West Thane
Maharashtra-400601
C/O. Antranga Savant
Mahadev Savant Row
H.No.7/5, Narayan Hut Hsg
Society Jaiganesh
Samarajya Spine Road
Panjarpol Pune
Maharashtra-412105
H.NO./Ota No.25,
Shivadarshan Parvati Pune
Maharashtra-411009
AP Mkalad Tal. Baramati
Distt.Pune Maahrashtra413102
Krishna Kunj Niwas Jadhav
Nagar Lakhala Washim
Maharashtra-444505
Karad Road Near
Manmandir Hospital Vita
Tal.Khanapur Sangli
Maharashtra-415311
Samsruddhi Yashwantnagar
Lengre Road Near Andhra
Banglow Vita Tal. Khanapur
Sangli Maharashtra-415311
Sr.No.80 BU Bhandari
Skyline Housing Society Ltd.
Plot No.63, Building K. Flat
No.3, Dighi Tal.Haveli Pune
Maharashtra-411015

MAH/4135/2007
Dt.17.08.07

MAH/3480/2007
Dt.02.08.07

MAH/1566/2003
Dt.07.07.03
MAH/388/2009
Dt.21.02.09
MAH/1693/2004
Dt.15.07.04
MAH/861/2001
Dt.14.03.01

MAH/1928/2004
Dt.15.07.04

MAH/1591/2003
Dt.07.07.03

<!-- page 78 -->

635

1278

Narhar
Vasudeo
Kulkarni

Gen

04.07.16

Pune Distt.

Vasudeo
Vishwanath
Kulkarni

636

1279

Ms. Sangeeta
Ashok Bhagat

Gen

14.06.16

Market Yard

Ashok Babanrao
Bhagat

637

1280

Sachin
Shivajirao
Misal

Gen

04.07.16

Cjjd Gangapur

Shivajirao
Jagannath Misal

638

1282

Ms. Aprajita
Kulthe

OBC

28.02.16

Thane Distt.

Ratnakar Kuthe

639

1283

Ms.Nutan
V.Hegde

Gen

23.06.16

Kalyan Distt.

Vishwanath.S.Heg
de

640

1284

Indru Ganesh
Madnani

Gen

05.08.16

Mumbai

Ganesh Madnani

641

1285

Ms. Sampada
Sadashiv
Kesarkar

Gen

23.08.16

Gadhinglaj

Sadashiv Bhairu
Kesarkar

642

1287

Khabade
Narendra
Dasharatha

SC

03.07.16

Kolhapur

Khavadr Dashatha
Aba

B-7, Atharva Complex S
No.11, Suncity Road
Vadgaon Bk Tal.Haveli Pune
Maharashtra-411051
S.No.8/6/7/8, Flat No.1
Wing-B, Arunoday
Gruharachana Society
Dhankawadi Near Talaji
Mandir Opp. Spring Hills
Society Pune Maharashtra411043
At.Amalner Post. Kaigaon
Aurangabad Maharashtra431110
103, Padmavati Hsg. Soc.
Near Bharat Dairy Shivaji
Nagar Road Naupada B
Cabin Thane West
Distt.Maharashtra-400602
B-109, New Nityanand
Chhaya Co.Op. Hsg Society
Rambaug Lane No.4, Kalyan
West Thane
Distt.Maharashtra-421301
B/007, Dahisar Accord CHS
J.S.Road Dahisar East
Mumbai Maharashtra400068
Muktangan Doctors Colony
Gadhinglaj Kolhapur
Maharashtra-416502
H.No.1907/E, Sawant Appt.
Flat No.29, Rajarampuri 11th
Lane Kolhapur Maharashtra416008

MAH/990/1999
Dt.27.03.99

MAH/1655/1990
Dt.12.10.90

MAH/1089/2005
Dt.22.03.05

MAH/3119/2001
Dt.01.10.01

MAH/1544A/2000
Dt.28.07.2000

MAH/772/1984
Dt.28.06.84
MAH/1468/2007
Dt.03.07.07
MAH/1216/2009
Dt.24.04.09

<!-- page 79 -->

643

1289

Bharati Nitin
Gavali

644

1292

Ashok Deoram
Bag

Gen

31.08.16

Jmfc Bhadgaon

Deoram Ukha Bag

645

1293

Bhosale Savita
Bhausaheb

SC

19.08.16

Kolhapur

Ashok Balwant
Karnik

646

1294

Vivek Maruti
Ghodekar

OBC

19.04.16

Thane

Maruti Narayan
Ghodekar

647

1295

Ms.Vishakha
Bhaskar Lade

SC

20.08.16

Lashkaribagh
North Nagpur

Bhaskar Bhaurao
Lade

648

1297

Ms. Sheikh
Rano Sabir
Hussain

Gen

24.09.16

Pune

Sabir

649

1299

Dham
Pandurang
Bawale

OBC

22.06.16

Khed Pune

Pandurang
Budhaji Bawale

1305

Prakash
Janardan
Kedari

OBC

27.07.16

Pashan Pune

Janardan
Sakharam Kedari

650

gen

06.09.16

Pune

Nitin

Flat No.1, Aakansha
Apartment Plot No.33CDC
Purnanagar Chinchwad
Pune Maharashtra-411019
At.Post Bhadgaon Peth
Jalgaon Maharashtra424105
787/5K, Layout No.1, Plot
No.51, Morya Niwas Baba
Jarag Nagar Kolhapur
Maharashtra-416012
B/12, Shramik Vishram CHS
Wadeghar Sapad Road
Kalyan West Thane
Maharashtra-421301
Plot No.1, Bhoslewadi Near
Sangam School
Lashkaribagh Nagpur
Maharashtra-440017
Flat No.304, 3rd Floor,
Haleema Apartment
Mithanagar Kondhawa
Khurd Pune Maharashtra411048
Omkar Plaza Office No.2,
Near Session Court
Rajgurunagar Tal-Khed
Distt.Pune Maharashtra410505
Vaijantai 7/8, Nimhan Lane
Behind Shree Sharada
Pashan Pune Maharashtra411021

MAH/2576/2006
Dt.08.01.06
MAH/1250/1990
Dt.21.08.90
MAH/949/1997
Dt.22.12.97

MAH/4170/2008
Dt.02.08.08

MAH/878/1991
Dt.11.07.91

MAH/2842/2009
Dt.18.07.09

MAH/274/2007
Dt.05.02.07

MAH/4075/2001
Dt.15.12.01

<!-- page 80 -->

651

1306

Rameshkumar
Baburao Nage

Gen

01.09.16

Haveli Pune

Baburao Vishnu
Nage

652

1307

Sanap
Ajaykumar
Shankarrao

OBC

31.08.16

Dhule

Sanap Shankarrao
Vitthalrao

653

1308

Katti Vilas

Gen

26.08.16

Andheri
Mumbai

Pralhadrao

654

1309

Ms. Gondhale
Surekha
Vinayak

OBC

02.09.16

Pune Distt.

Vinayak

655

1310

Shankar
Murlidhar
Walekar

Gen

02.09.16

Nandgaon Tal.
And
Distt.Nashik

Lt. Sh.Murlidhar
Gangadhar
Walekar

656

1311

Ojha
Rajendraprasa
d Krishnadutt

Gen

19.09.16

Andheri
Suburban

Ojha Krishnadutt
Gayadin

657

1313

Ojha Hiraman
Krishnadutt

Gen

19.09.16

Jogeshwari
Mumbai
Suburban

Ojha Krishnadutt
Gayadin

658

1314

Kedar Kishor
Bhusari

Gen

03.11.16

Jalgaon Distt.

Kishor Narayan
Bhusari

S.No.25, Manjari Farm Sitai
Nagar Hake Wasti Manjari
Bk Tal.Haveli Pune
Maharashtra-412307
Plot No.70 B Shivaji Nagar
Wadibhokar Road Deopur
Dhule Maharashtra-424002
Flat No.C/1002, Opp. Apna
Bazar Off J.P Road
D.N.Nagar Andheri West
Mumbai Maharashtra400053
D-22, Pillar Home Housing
Society Behind Barker
Company Viman Nagar
Pune Maharashtra-411014
At.Dheku Bk Post Dheku Kh.
Tal.Nandgaon Distt.Nashik
Maharashtra-423106
Room No2, 1st Floor
Chandrakant Bhavan
Chimmatpada Marol Naka
Anhderi-Kurla Road Andheri
East Mumbai Suburban
Maharashtra-400059
Room No2, 1st Floor
Chandrakant Bhavan
Chimmatpada Marol Naka
Anhderi-Kurla Road Andheri
East Mumbai Suburban
Maharashtra-400059
Plot No.42, Vishal
Appartment Yashwant
Colony Ring Road Jalgaon
Maharashtra-425001

MAH/657/1986
Dt.24.06.86
MAH/2368/2004
Dt.15.07.04

MAH/3121/1999
Dt.05.05.99

MAH/1525/2009
Dt.04.07.09
MAH/3669/2005
Dt.26.08.05

MAH/1207/1989
Dt.04.08.89

MAH/71/1995
Dt.11.01.95

MAH/1365/2003
Dt.18.06.03
