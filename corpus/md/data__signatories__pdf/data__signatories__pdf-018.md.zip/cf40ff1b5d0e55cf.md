---
doc_id: "cf40ff1b5d0e55cf"
source_url: "https://www.dot.gov.in/static/uploads/2026/02/ade7f424c15ef3fab6341db97111f5f7.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfers and Posting in the SAG & above of Indian P&T Accounts and Finance Service Group A"
date: "2026-02-02"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "e05709cfba50bbe8"
---

<!-- page 1 -->

No. 05-05/2025-SEA-I
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road
New Delhi-110001
Dated: 2-02.2026
ORDER
Sub: Transfers/Postings in the SAG & above of Indian P&T Accounts
and Finance Service Group ‘A’ (IP&TAFS Gr. ‘A’).
The following transfers/postings of Senior Administrative Grade &
above level officers of Indian P&T Accounts and Finance Service Group ‘A’
(IP&TAFS Gr. ‘A’) are ordered with immediate effect:-
Higher Administrative Grade+ (HAG+): :
S| Name of the officer | Present posting
No.
1 | 83033 | Sh. Awadhesh | Addl. CGCA, O/o| Advisor (F),
Kumar CGCA New Delhi | DoT Hq.
Higher Administrative Grade (HAG):
[ss | Name of the officer | Present posting
No.
1 83043 | Ms. Madhavi Das DG NCA-F FA (Telecom),
DoT Hq.
2 83068 | Sh. Kumar Sanjay | Pr. CCA Mumbai] Sr. DDG
Bariar (LFA), DoT HQ
Senior Administrative Grade (SAG):
[ss | Name of the officer | Present posting
No.
1 83121 | Sh. Shivendu Gupta | DDG (WPF), DoT | DDG
HQ (Finance), DoT
HQ
2. Necessary charge reports may be sent to SEA Section, DoT Hq.
3. This is issued with the approval of the Competent Authority.
ca
TAN ove
(Venkata Praveen Pogiri) a)
Director (SEA)
Ph: 011-23036059
Page 1|2

<!-- page 2 -->

Copy to: -
1. PS to Hon’ble MoC.
2. PS to Hon’ble MoS (C).
3. PSO to Secretary (T), DoT.
4. PSO to Member (F)/Member (T), DCC
5. PS to CGCA
6. PS to Member (Personnel), DoP Hq
7. Officers concerned.
8. PSO/ CS to Advisor(F)/ AS (T), DoT Hq./Addl. CGCA
9. Sr DDG (LFA) DoT HQ / Sr. DDG (PAF) DoP Hq/ DG (NCA-F)/FA(T)
DoT Hq/ All Pr. CsCA
10.CVO, DoT Hq.
11.All DDsG, Accounts & Finance side, DoT Hgqs./DDG C&A/ut.
Administrator (F), DBN/ All CsCA
12. Jt. CsCA (IC)
13.ACAO (SEA-II), DoT Hqs-for uploading the order on DoT website.
14.SO Pay Bill/G-I/ G-II/ Library/ PHP/ Cash Section, DoT HQ
15.OL Section, DoT for Hindi Version.
16.Guard File/Spare.
Page 2|2
