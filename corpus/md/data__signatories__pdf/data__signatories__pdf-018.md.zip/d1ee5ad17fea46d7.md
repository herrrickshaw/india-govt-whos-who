---
doc_id: "d1ee5ad17fea46d7"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_68402e372d9ec1.25197473.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "G.S.R 807(E) [30-10-2023] प्लास्टिक अपशिष्ट प्रबंधन (दूसरा संशोधन) नियम, 2023"
date: ""
pages: 9
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "109ac31bdad4d8c3"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-30102023-249793
xxxGIDHxxx
CG-DL-E-30102023-249793
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 628]

नई दिल्ली, सोमवार, अक्तूबर 30, 2023/कार्ताक 8, 1945
NEW DELHI, MONDAY, OCTOBER 30, 2023/KARTIKA 8, 1945

No. 628]

पर्ाावरण, वन और िलवार्ु पररवतान मंत्रालर्
अजधसूचना

नई दिल्ली, 30 अक्तूबर, 2023
सा.का.जन. 807(अ).—कें द्रीर् सरकार, प्लाजस्ट्िक अपजिष्ट प्रबंधन जनर्म, 2016 (जिसे इसमें इसके पश्चात् "उक्त जनर्म"
कहा गर्ा है) पर्ाावरण, वन और िलवार्ु पररवतान मंत्रालर् में पर्ाावरणीर् स्ट्वच्छ रीजत में िेि में प्लाजस्ट्िक अपजिष्ट प्रबंधन के जलए
कानूनी ढांचा प्रिान का उपबंध करने के जलए सा. का. जन. 320 (अ), तारीख 18 माचा, 2016 द्वारा अजधसूजचत दकर्ा गर्ा था।
और जनर्मों के प्रभावी कार्ाान्वर्न को और सिक्त बनाने के क्रम में प्रस्ट्ताव दकर्ा िा रहा है, जिसमें अन्र् बातों के साथ-साथ
राज्र् और स्ट्थानीर् प्राजधकरण स्ट्तर पर अपजिष्ट प्रबंधन के जवजभन्न चरणों में बहु-चरणीर् मैनुअल ररपोर्ििंग और डेिा संग्रहण के स्ट्थान
पर ऑनलाइन ररपोर्ििंग के जलए सूचना प्रौद्योजगकी उपकरणों का उपर्ोग सजममजलत है; मूल्र् की खोि के जलए रजिस्रीकृ त प्लाजस्ट्िक
अपजिष्ट संसाधक द्वारा उत्पन्न दकए गए प्रमाण पत्रों के व्यापार के जलए ऑनलाइन इलेक्रॉजनक रेडडंग प्लेिफॉमा प्रिान करना;
और के न्द्रीर् सरकार की रार् है दक उक्त जनर्मों में संिोधन करना िनजहत में आवश्र्क और समीचीन है;
अत:, अब, कें द्रीर् सरकार, पर्ाावरण (संरक्षण) अजधजनर्म, 1986 (1986 का 29) की धारा 3, 6, और 25 द्वारा प्रित्त
िजक्तर्ों का प्रर्ोग करते हुए, प्लाजस्ट्िक अपजिष्ट प्रबंधन जनर्म, 2016 का संिोधन करने के जलए जनम्नजलजखत जनर्म बनाती है,
अथाात:् 1.

(1)

6892 GI/2023

इन जनर्मों का संजक्षप्त नाम प्लाजस्ट्िक अपजिष्ट प्रबंधन (िूसरा संिोधन) जनर्म, 2023 है।

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(2)

र्ह रािपत्र में उनके प्रकािन की तारीख से प्रवृत्त होंगे।

2.

प्लाजस्ट्िक अपजिष्ट प्रबंधन जनर्म, 2016 (जिसे इसमें इसके पश्चात उक्त जनर्म का गर्ा है) में, उप-जनर्म (2) के पश्चात्

जनर्म 2 में, जनम्नजलजखत उप-जनर्म अंतःस्ट्थाजपत दकर्ा िाएगा, अथाात:् “(3)

जनर्म 9 का उप-जनर्म (1) जविेष आर्थाक क्षेत्र अजधजनर्म, 2005 (2005 का 28) के अधीन कें द्रीर् सरकार द्वारा

अजधसूजचत जविेष आर्थाक क्षेत्रों में जनर्ाातोन्मुख इकाइर्ों र्ा इकाइर्ों और प्लाजस्ट्िक पैकेडिंग बनाने वाली अन्र् इकाइर्ों र्ा जनर्ाात
आिेि के जलए जनर्ाात हेतु पैकेडिंग उत्पािों के जलए उपर्ोग की िाने वाली प्लाजस्ट्िक पैकेडिंग पर लागू नहीं होगा:
परं तु र्ह उप-जनर्म ऐसी इकाइर्ों द्वारा उत्पन्न पूवा-उपभोक्ता प्लाजस्ट्िक पैकेडिंग अपजिष्ट पर लागू नहीं होगा”।
3.

उक्त जनर्मों के जनर्म 3 में, -

(i)

खंड (ग) के स्ट्थान पर जनम्नजलजखत खंड रखा िाएगा, अथाात्:-

‘(ग) "कै री बैग" से प्लाजस्ट्िक सामग्री र्ा कं पोस्ट्ि र्ोग्र् प्लाजस्ट्िक र्ा िैव जनम्नीकरणीर् प्लाजस्ट्िक से बने बैग अजभप्रेत हैं, जिनका उपर्ोग
वस्ट्तुओं को ले िाने र्ा जवतररत करने के उद्देश्र् से दकर्ा िाता है, जिनमें एक स्ट्व-वहन सुजवधा होती है, लेदकन इसमें ऐसे बैग
सजममजलत नहीं होते हैं िो पैकेडिंग का एक अजभन्न अंग होते हैं र्ा बनाते हैं जिसमें सामान को उपर्ोग से पहले बंि दकर्ा िाता है ";
(ii) खंड (ध) के स्ट्थान पर जनम्नजलजखत खंड रखा िाएगा, अथाात्:‘(ध) "उत्पािक" से प्लाजस्ट्िक पैकेडिंग के जनमााण में लगे व्यजक्त अजभप्रेत है";’.
4.

उक्त जनर्म के जनर्म 4 में उप-जनर्म (1) में, "बहु-स्तरीर् पैकेडिंग" िब्िों के स्थान पर "प्लाजस्ट्िक पैकेडिंग" िब्ि रखा

िाएगा।
5.

उक्त जनर्म के जनर्म 5 में, उप-जनर्म (1) में, "िहरी स्ट्थानीर् जनकार्" िब्िों के स्थान पर "स्ट्थानीर् जनकार्" िब्ि रखा

िाएगा।
6.

उक्त जनर्म के जनर्म 9 में, उप-जनर्म (6) में, "बहु-स्तरीर् पैकेडिंग" िब्िों के स्थान पर "प्लाजस्ट्िक पैकेडिंग" िब्ि रखा

िाएगा।
7.

उक्त जनर्म के जनर्म 11 में, उप-जनर्म (1) के स्ट्थान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अथाात:् -

“(1) प्रत्र्ेक प्लाजस्ट्िक पैकेडिंग में जनम्नजलजखत िानकारी अंग्रेिी में मुदद्रत होगी, अथाात्:(क) 1 िुलाई, 2024 से ठोस प्लाजस्ट्िक पैकेडिंग के मामले में, प्लाजस्ट्िक पैकेडिंग के जलए अनुसूची II में जनर्िाष्ट कें द्रीकृ त ऑनलाइन
पोिाल के माध्र्म से उत्पािक र्ा आर्ातक र्ा ब्राण्ड स्ट्वामी के जलए उत्पन्न दकए गए नाम और रजिस्ट्रीकरण प्रमाण पत्र संख्र्ा,
प्लाजस्ट्िक की थैली र्ा पाउच सजहत जवजभन्न प्रकार के प्लाजस्ट्िक के साथ एक से अजधक स्ट्तर वाली बहु-स्ट्तरीर् लचीली प्लाजस्ट्िक
पैकेडिंग और बहु-स्ट्तरीर् प्लाजस्ट्िक पैकेडिंग;
(ख) प्लाजस्ट्िक की थैली र्ा पाउच (र्दि एकल स्ट्तर), प्लाजस्ट्िक िीि र्ा प्लाजस्ट्िक िीि से बने कवर और प्लाजस्ट्िक िीि, कै री बैग सजहत
एकल स्ट्तर वाली लचीली प्लाजस्ट्िक पैकेडिंग के मामले में प्लाजस्ट्िक पैकेडिंग और मोिाई के जलए अनुसूची II में जनर्िाष्ट कें द्रीकृ त
ऑनलाइन पोिाल के माध्र्म से उत्पािक र्ा आर्ातक र्ा ब्राण्ड स्ट्वामी के जलए उत्पन्न नाम और रजिस्रीकरण प्रमाण पत्र संख्र्ा;
(ग) 1 िनवरी, 2025 से प्लाजस्ट्िक पैकेडिंग के जलए अनुसूची II में जनर्िाष्ट कें द्रीकृ त ऑनलाइन पोिाल के माध्र्म से उत्पािक र्ा
आर्ातक र्ा ब्राण्ड स्ट्वामी के जलए नाम और रजिस्ट्रीकरण प्रमाण पत्र संख्र्ा और प्लाजस्ट्िक िीि र्ा पैकेडिंग और प्लाजस्ट्िक पैकेडिंग के
जलए उपर्ोग दकए िाने वाले कै री बैग के मामले में उप-जनर्म (4) के खंड (ि) के अधीन िारी प्रमाण पत्र की संख्र्ा, िैसा दक लागू
होता है;
(घ) प्लाजस्ट्िक िीि र्ा पैकेडिंग और प्लाजस्ट्िक पैकेडिंग के साथ-साथ कै री बैग और िैव जनम्नीकरणीर् से बनी वस्ट्तुओं के मामले में
उप-जनर्म 4 के खंड (ि) के अधीन िारी नाम और प्रमाण पत्र संख्र्ा:

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

परन्तु इस उप-जनर्म के उपबंध जवजधक माप जवज्ञान पैकेज्ड कमोजडिीज़ जनर्म 2011 के जनर्म 26 के अधीन आने वाली प्लाजस्ट्िक
पैकेडिंग पर और प्लाजस्ट्िक पैकेडिंग के मामलों के संबंध में लागू नहीं होंगे, िहााँ इलेक्रॉजनक और आईिी उत्पािों के जलए बीआईएस
अजनवार्ा रजिस्ट्रीकरण र्ोिना के अधीन मानक जचह्न और लेबडलंग की आवश्र्कताओं के उपर्ोग के जलए दििाजनिेिों में दिए गए
जवजनिेिों के अनुसार अपेजक्षत िानकारी मुदद्रत करना तकनीकी रूप से व्यवहार्ा नहीं है;
परं तु पहले परं तुक के अधीन प्लाजस्ट्िक पैकेडिंग को कें द्रीर् प्रिूषण जनर्ंत्रण बोडा द्वारा अनुमोदित दकर्ा िाएगा:
परं तु र्ह भी दक पहले और िूसरे परं तुक के अधीन प्लाजस्ट्िक पैकेडिंग के संबंध में सुसंगत िानकारी पैकेडिंग पर मुदद्रत की िाएगी िो
सामान की व्यजक्तगत इकाइर्ों र्ा पैकेडिंग की व्यजक्तगत इकाइर्ों को एक साथ रखती है।”
8.

उक्त जनर्मों के जनर्म 12 में, -

(क) उप-जनर्म (1) के स्ट्थान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अथाात:् “(1) दकसी संघ राज्र्क्षेत्र के संबंध में के न्द्रीर् प्रिूषण जनर्ंत्रण बोडा, राज्र् प्रिूषण जनर्ंत्रण बोडा और प्रिूषण जनर्ंत्रण सजमजत इन जनर्मों
के उपबंधों को लागू करने के प्राजधकारी होंगे।;
(ख)

उप-जनर्म (2) के स्ट्थान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अथाात:् -

“(2) राज्र् सरकार र्ा संघ राज्र्क्षेत्र के अजतररक्त मुख्र् सजचव र्ा प्रधान सजचव र्ा नगरपाजलका प्रिासन के जलए उत्तरिार्ी प्रिासन
जवभाग के संबंजधत प्रभारी सजचव अपजिष्ट उत्पािक द्वारा अपजिष्ट प्रबंधन से संबंजधत इन जनर्मों के उपबंधों को लागू करने, प्लाजस्ट्िक
कै री बैग के उपर्ोग पर प्रजतबंध र्ा जनषेध, प्लाजस्ट्िक िीि र्ा ऐसी प्लाजस्ट्िक िीि और प्लाजस्ट्िक पैकेडिंग से बने कवर और वस्ट्तुओं को
राज्र् र्ा संघ राज्र्क्षेत्र के िहरी क्षेत्रों में इन जनर्मों के जनर्म 4 के अधीन जनजषद्ध करने के जलए प्राजधकरण होगा।”;
(ग)

उप-जनर्म (3) के स्ट्थान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अथाात:् -

“(3) राज्र् सरकार र्ा संघ राज्र्क्षेत्र के अजतररक्त मुख्र् सजचव र्ा प्रधान सजचव र्ा पंचार्ती राि संस्ट्थान के जलए उत्तरिार्ी प्रिासन
जवभाग के संबंजधत प्रभारी सजचव अपजिष्ट उत्पािक द्वारा अपजिष्ट प्रबंधन से संबंजधत इन जनर्मों के उपबंधों के प्रवतान, प्लाजस्ट्िक कै री
बैग के उपर्ोग पर प्रजतबंध र्ा जनषेध, प्लाजस्ट्िक िीि र्ा ऐसी प्लाजस्ट्िक िीि और प्लाजस्ट्िक पैकेडिंग से बने कवर और वस्ट्तुओं को
राज्र् र्ा संघ राज्र् क्षेत्र के ग्रामीण क्षेत्र में इन जनर्मों के जनर्म 4 के अधीन जनजषद्ध करने के जलए प्राजधकरण होगा।”;
(घ)

उपजनर्म (4) के स्ट्थान पर जनम्नजलजखत उपजनर्म रखा िाएगा, अथाात्: -

“(4) उपजनर्म (1), (2) और (3) में जनर्िाष्ट प्राजधकारी इन जनर्मों के उपबंधों के प्रवतान के संबंध में संबंजधत जिले के क्षेत्राजधकार की
प्रािेजिक सीमाओं के भीतर ग्रामीण क्षेत्रों के जलए जिला मजिस्ट्रेि र्ा उपार्ुक्त और िहरी क्षेत्रों के जलए नगर जनकार् के कार्ाकारी प्रमुख
र्ा ग्रामीण क्षेत्रों के जलए जिला स्ट्तरीर् पंचार्तों के मुख्र् कार्ाकारी अजधकारी की सहार्ता लेंगे”।
9.

उक्त जनर्म के जनर्म 13 में,-

(क) उप जनर्म (2) के स्ट्थान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अथाात:् “(2)

प्रत्र्ेक उत्पािक र्ा आर्ातक र्ा ब्राण्ड स्ट्वामी एक बार रजिस्रीकरण के प्रर्ोिन से अनुसूची II में जनर्िाष्ट कें द्रीकृ त ऑनलाइन

पोिाल के माध्र्म से प्ररूप I में आवेिन करें गे। (i)

संबंजधत राज्र् प्रिूषण जनर्ंत्रण बोडा र्ा संबंजधत संघ राज्र्क्षेत्र की प्रिूषण जनर्ंत्रण सजमजत, र्दि एक र्ा िो राज्र्ों र्ा संघ
राज्र्क्षेत्रों में कार्ा कर रही है; र्ा

(ii)

(ii) के न्द्रीर् प्रिूषण जनर्ंत्रण बोडा, र्दि िो से अजधक राज्र्ों र्ा संघ राज्र्क्षेत्रों में कार्ा कर रहा है।”;

(ख)

उप जनर्म (3) के स्ट्थान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अथाात:् -

“(3)

अपजिष्ट का पुनचाक्रण र्ा प्रसंस्ट्करण करने वाला र्ा प्लाजस्ट्िक अपजिष्ट का पुनचाक्रण करने र्ा संसाजधत करने का प्रस्ट्ताव करने

वाला प्रत्र्ेक व्यजक्त एक बार रजिस्रीकरण के प्रर्ोिन से अनुसूची -2 में जनर्िाष्ट कें द्रीकृ त ऑनलाइन पोिाल के माध्र्म से प्ररूप II में
संबंजधत राज्र् प्रिूषण जनर्ंत्रण बोडा र्ा प्रिूषण जनर्ंत्रण सजमजत को आवेिन करे गा।”;

<!-- page 4 -->

4
(ग)

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

उप-जनर्म (5) के स्ट्थान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अथाात्:-

“(5) राज्र् प्रिूषण जनर्ंत्रण बोडा र्ा प्रिूषण जनर्ंत्रण सजमजत प्लाजस्ट्िक अपजिष्ट पुनचाक्रण र्ा प्रसंस्ट्करण इकाइर्ों को रजिस्ट्रीकरण
प्रिान नहीं करे गी िब तक दक इकाई के पास िल (प्रिूषण जनवारण और जनर्ंत्रण) अजधजनर्म, 1974 (1974 का 6) और वार्ु
(प्रिूषण जनवारण और जनर्ंत्रण) अजधजनर्म, 1981 (1981 का 14) के अधीन वैध मंिूरी न हो और जिला उद्योग कें द्र र्ा इस संबंध
में अजधकृ त दकसी अन्र् सरकारी एिेंसी द्वारा िारी रजिस्ट्रीकरण प्रमाण पत्र न हो।”;
(घ)

उप-जनर्म (9) का लोप दकर्ा िाएगा.

(ङ)

उप-जनर्म (11) का लोप दकर्ा िाएगा.

10.
“16.

उक्त जनर्म के जनर्म 16 के स्ट्थान पर जनम्नजलजखत जनर्म रखा िाएगा, अथाात:् राज्र् स्ट्तरीर् जनगरानी सजमजत- (1) राज्र् सरकार र्ा संघ राज्र्क्षेत्र प्रिासन, इन जनर्मों के कार्ाान्वर्न की प्रभावी जनगरानी

के प्रर्ोिन से, एक राज्र् स्ट्तरीर् जनगरानी सजमजत का गठन करे गा, जिसमें जनम्नजलजखत व्यजक्त सजममजलत होंगे, अथाात:् (क)

राज्र् सरकार र्ा संघ राज्र्क्षेत्र के अजतररक्त मुख्र् सजचव र्ा प्रधान सजचव र्ा नगरपाजलका
प्रिासन के जलए उत्तरिार्ी प्रिासन जवभाग के संबंजधत प्रभारी प्रधान सजचव

अध्र्क्ष;

(ख)

राज्र् सरकार र्ा संघ राज्र्क्षेत्र के अजतररक्त मुख्र् सजचव र्ा प्रधान सजचव र्ा पंचार्ती राि
संस्ट्थाओं
के
जलए
उत्तरिार्ी
प्रिासन
जवभाग
के
संबंजधत
प्रभारी

सह-अध्र्क्ष;

सजचव
(ग)

राज्र् सरकार र्ा संघ राज्र्क्षेत्र के अजतररक्त मुख्र् सजचव र्ा प्रधान सजचव र्ा िहरी जवकास के
जलए उत्तरिार्ी प्रिासन जवभाग के संबंजधत प्रभारी सजचव र्ा उनके नाजमत प्रजतजनजध

सिस्ट्र्;

(घ)

राज्र् सरकार र्ा संघ राज्र्क्षेत्र के अजतररक्त मुख्र् सजचव र्ा प्रधान सजचव र्ा ग्रामीण जवकास के
जलए उत्तरिार्ी प्रिासन जवभाग के संबंजधत प्रभारी सजचव र्ा उनके नाजमत प्रजतजनजध

सिस्ट्र्;

(ङ)

राज्र् सरकार र्ा संघ राज्र्क्षेत्र अजतररक्त मुख्र् सजचव र्ा प्रधान सजचव र्ा पर्ाावरण के जलए
उत्तरिार्ी प्रिासन जवभाग के
संबंजधत प्रभारी सजचव र्ा उनके नाजमत प्रजतजनजध

सिस्ट्र्;

(च)

राज्र् प्रिूषण जनर्ंत्रण बोडा र्ा प्रिूषण जनर्ंत्रण सजमजत के सिस्ट्र् सजचव

सिस्ट्र्;

(छ)

िस लाख र्ा उससे अजधक िनसंख्र्ा वाले िहरों के नगर आर्ुक्त

सिस्ट्र्;

(ि)

िस लाख र्ा उससे अजधक िनसंख्र्ा वाले िहरों के अलावा अन्र् िहरों से एक नगर आर्ुक्त

सिस्ट्र्;

(झ)

जिला स्ट्तरीर् पंचार्तों के एक मुख्र् पररचालन अजधकारी

सिस्ट्र्;

(ञ)

अपजिष्ट प्रबंधन में सजममजलत गैर-सरकारी संगठन से एक जविेषज्ञ को राज्र् सरकार र्ा संघ
राज्र्क्षेत्र प्रिासन द्वारा नाजमत दकर्ा िाएगा

सिस्ट्र्;

(ि)

राज्र् सरकार र्ा संघ राज्र्क्षेत्र प्रिासन द्वारा नाजमत दकए िाने वाले उद्योग संघ के एक

सिस्ट्र्;

प्रजतजनजध
(ठ)

उद्योग क्षेत्र से एक जविेषज्ञ को राज्र् सरकार र्ा संघ राज्र् क्षेत्र प्रिासन द्वारा नाजमत दकर्ा

सिस्ट्र्;

िाएगा
(ड)

राज्र् सरकार र्ा संघ राज्र् क्षेत्र प्रिासन द्वारा नाजमत दकए िाने वाले जिक्षाजविों से एक जविेषज्ञ

सिस्ट्र्;

(ढ)

पंचार्ती राि संस्ट्थाओं के जलए उत्तरिार्ी राज्र् सरकार र्ा संघ राज्र् क्षेत्र प्रिासन के प्रभारी

सिस्ट्र्

जनिेिक
(ण)

नगरपाजलका प्रिासन के जलए उत्तरिार्ी राज्र् सरकार र्ा संघ राज्र् क्षेत्र प्रिासन के प्रभारी
जनिेिक

सिस्ट्र् सजचव

<!-- page 5 -->

[भाग II—खण्ड 3(i)]
(2)

भारत का रािपत्र : असाधारण

5

राज्र् स्ट्तरीर् जनगरानी सजमजत छह महीने में कम से कम एक बार बैठक करे गी और र्दि आवश्र्क समझे तो जविेषज्ञों को

आमंजत्रत कर सकती है।”
11.

उक्त जनर्मों की अनुसूची II में, -

(क)

पैरा 6 में, खंड (6.3) के स्ट्थान पर जनम्नजलजखत खंड रखा िाएगा, अथाात्:-

“(6.3) खंड (6.1) के अधीन रजिस्रीकरण करने के जलए बाध्र् संस्ट्थाएं कें द्रीर् प्रिूषण जनर्ंत्रण बोडा द्वारा जवकजसत ऑन-लाइन कें द्रीकृ त
पोिाल के माध्र्म से खंड (6.1) के अधीन रजिस्रीकरण करने की बाध्र्ता रखने वाली दकसी भी गैर-रजिस्रीकृ त इकाई से संव्यवहार
नहीं करे गी।”;
(ख)

पैरा 10 में, खंड (10.6) में, परं तुक में, "31 अक्िू बर 2023" िब्िों और अंकों के स्ट्थान पर जनम्नजलजखत िब्ि और अंक रखे

िाएंगी, अथाात्:"30 नवंबर 2023”;
(ग)

पैरा 12 में, खंड (12.8) के पश्चात्, जनम्नजलजखत खंड अंतःस्ट्थाजपत दकए िाएंग,े अथाात्:-

"(12.9) कें द्रीर् सरकार उत्पािकों, आर्ातकों और ब्राण्ड स्ट्वाजमर्ों को खंड 10.6 के अधीन और प्लाजस्ट्िक अपजिष्ट प्रसंस्ट्करणकतााओं को
खंड 11.2 के अधीन नौ महीने से अजधक की अवजध के जलए वार्षाक जववरणी प्रस्ट्तुत करने की अनुमजत प्रिान कर सकती है।”
(घ)

पैराग्राफ 15 के पि्चात्, जनम्नजलजखत पैराग्राफ अत:स्ट्थाजपत दकर्ा िाएगा, अथाात्:-

“15क जवजभन्न श्रेजणर्ों से जवस्ट्ताररत उत्पािक उत्तरिाजर्त्व प्रमाण पत्र की खरीि.(1)

के न्द्रीर् प्रिूषण जनर्ंत्रण बोडा उन श्रेजणर्ों के जलए जवस्ट्ताररत उत्पािक उत्तरिाजर्त्व प्रमाण-पत्र खरीिने की अनुमजत िे सकता

है िहााँ उस श्रेणी के जवस्ट्ताररत उत्पािक उत्तरिाजर्त्व िाजर्त्व पर अजधिेष जवद्यमान है जिससे ऐसी श्रेणी के जवस्ट्ताररत उत्पािक
उत्तरिाजर्त्व िाजर्त्व को पूरा दकर्ा िा सके िहााँ कमी है।
(2)

ऐसे मामलों में, के न्द्रीर् प्रिूषण जनर्ंत्रण बोडा प्लाजस्ट्िक पैकेडिंग अपजिष्ट की जवजभन्न श्रेजणर्ों के संग्रह, पृथक्करण और

प्रसंस्ट्करण की उपलब्धता और लागत के आधार पर उस श्रेणी के जवस्ट्ताररत उत्पािक उत्तरिाजर्त्व िाजर्त्व को पूरा करने के जलए िहााँ
अजधिेष जवद्यमान है, उस श्रेणी के जवस्ट्ताररत उत्पािक उत्तरिाजर्त्व प्रमाणपत्रों की मात्रा जनधााररत करे गा, िहााँ अजधिेष जवद्यमान है।
(3)

इस पैरा का उपबंध वषा 2025-2026 की समाजि पर लागू नहीं होगा”।

[जम. सं 12/31/2023 –एचएसएम]
नरे ि पाल गंगवार, अजतररक्त सजचव
रिप्पण : मूल जनर्म भारत के रािपत्र, सा.का.जन. 320(अ). तारीख 18 माचा, 2016 द्वारा प्रकाजित दकए गए थे और तत्पश्चात
इनमें अजधसूचना संख्र्ा सा.का.जन. 285(अ) तारीख 27 माचा, 2018, अजधसूचना संख्र्ा सा.का.जन. 571(अ) तारीख
12 अगस्ट्त, 2021, अजधसूचना संख्र्ा सा.का.जन. 647(अ) तारीख 17 अगस्ट्त, 2021, अजधसूचना संख्र्ा
सा.का.जन. 133(अ) तारीख 16 फरवरी, 2022, और अजधसूचना संख्र्ा सा.का.जन. 522(अ) तारीख 6 िुलाई, 2022.,
और अंत में अजधसूचना संख्र्ा सा.का.जन. 318(अ) तारीख 27 अप्रैल, 2023 के द्वारा संिोधन दकर्ा गर्ा था।

MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 30th October, 2023
G.S.R. 807(E).—WHEREAS the Plastic Waste Management Rules, 2016 (hereinafter referred to as the
“said rules”) were notified by the Central Government in the Ministry of Environment, Forest and Climate Change
vide G.S.R. 320 (E), dated the 18 th March, 2016 to provide statutory framework for plastic waste management in the
country in an environmentally sound manner;

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

AND WHEREAS in order to further strengthen the effective implementation of rules amendments are being
proposed inter alia including use of information technology tools for online reporting replacing multi-step manual
reporting and capturing of data at various stages of waste management at state and local authority level; provide for
online electronic trading platform for trading of certificates generated by registered plastic waste processors for price
discovery;
AND WHEREAS the Central Government is of the opinion that it is necessary and expedient in public
interest to amend the said rules;
NOW, THEREFORE, in exercise of the powers conferred by sections 3, 6, and 25 of the Environment
(Protection) Act, 1986 (29 of 1986), the Central Government hereby makes the following rules further to amend the
Plastic Waste Management Rules, 2016, namely:1.
(2)

(1)

These rules may be called Plastic Waste Management (Second Amendment) Rules, 2023.

They shall come into force on the date of their publication in the Official Gazette.

2.
In the Plastic Waste Management Rules, 2016 (hereinafter referred to as the said rules), in rule 2 after subrule (2), the following sub-rule shall be inserted, namely:“(3)
Sub-rule (1) of rule 9 shall not apply to the export oriented units or units in special economic zones, notified
by the Central Government under the Special Economic Zones Act, 2005 (28 of 2005), and to other units
manufacturing plastic packaging or on plastic packaging used for packaging products for export against an order for
export:
Provided that this sub-rule shall not apply to pre-consumer plastic packaging waste generated by such units.”.
3.

In rule 3 of the said rules, -

(i)

for clause (c), the following clause shall be substituted, namely:-

‘(c) “carry bags” mean bags made from plastic material or compostable plastic or biodegradable plastic, used for the
purpose of carrying or dispensing, commodities, which have a self-carrying feature but do not include bags that
constitute or form an integral part of the packaging in which goods are sealed prior to use”;’;
(ii) for clause (s), the following clause shall be substituted, namely:‘(s) “producer” means persons engaged in manufacture of plastic packaging”;’.
4.
In rule 4 of the said rules. in sub-rule (1), for the words “multi-layered packaging”, the words “plastic
packaging” shall be substituted.
5.
In rule 5 of the said rules, in sub-rule (1), for the words “urban local bodies” the words “local bodies” shall be
substituted.
6.
In rule 9 of the said rules, in sub-rule (6), for the words “multilayered packaging” the words “plastic
packaging” shall be substituted.
7.

In rule 11, of the said rules, for sub-rule (1), the following sub-rule shall be substituted, namely: -

“(1) Each plastic packaging shall contain the following information, printed in English, namely:(a) name and registration certificate number for producer or importer or brand owner generated through centralized
online portal specified in Schedule II for plastic packaging, in case of, rigid plastic packaging with effect from 1
July,2024, multilayer flexible plastic packaging having more than one layer with different types of plastics, including
plastic sachet or pouches, and multi-layered plastic packaging;
(b) name and registration certificate number for producer or importer or brand owner generated through centralized
online portal specified in Schedule II for plastic packaging and thickness in case of flexible plastic packaging of single
layer including plastic sachet or pouches (if single layer), plastic sheets or like and covers made of plastic sheet, carry
bags;
(c) name and registration certificate number for producer or importer or brand owner generated through centralized
online portal specified in Schedule II for plastic packaging with effect from 1 January, 2025 and number of certificate
issued under clause (h) of sub-rule (4) in case of plastic sheet or like used for packaging and plastic packaging as well
as carry bags commodities made of compostable plastic, as applicable;
(d) name and certificate number issued under clause (h) of sub-rule 4 in case of plastic sheet or like used for
packaging and plastic packaging as well as carry bags and commodities made of biodegradable plastic:

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

7

Provided that the provisions of this sub-rule shall not apply to plastic packaging covered under rule 26 of the Legal
Metrology Packaged Commodities Rules, 2011, and in respect of plastic packaging cases where it is technically not
feasible to print the requisite information, as per specifications given in the Guidelines for use of Standard Mark and
labelling requirements under BIS Compulsory Registration Scheme for Electronic and IT Products;
Provided further that the plastic packaging under the first proviso shall be approved by the Central Pollution Control
Board:
Provided also that the relevant information in respect of plastic packaging under the first and second proviso shall be
printed on the packaging that holds together individual units of goods or the individual units of packaging.”.
8.

In rule 12 of the said rules , -

(a) for sub-rule (1), the following sub-rule shall be substituted, namely :“(1) The Central Pollution Control Board, State Pollution Control Board and Pollution Control Committee in respect
of a Union territory shall be the authority for enforcement of the provisions of these rules;
(b)

for sub-rule (2) the following sub-rule shall be substituted, namely: -

“(2) The concerned Additional Chief Secretary or Principal Secretary or Secretary in charge of the Department of the
State Government or a Union territory Administration responsible for municipal administration shall be the authority
for enforcement of the provisions of these rules relating to waste management by waste generator, restriction or
prohibition on use of plastic carry bags, plastic sheets or like, covers made of plastic sheets and plastic packaging and
items prohibited under rule 4 of these rules in the urban areas of the State or a Union territory.”;
(c)

for sub-rule (3), the following sub-rule shall be substituted, namely: -

“(3) The concerned Additional Chief Secretary or Principal Secretary or Secretary in charge of the Department of the
State Government or a Union territory Administration responsible for Panchayati Raj Institutions shall be the
authority for enforcement of the provisions of these rules relating to waste management by the waste generator,
restriction or prohibition on use of plastic carry bags, plastic sheets or like, covers made of plastic sheets and plastic
packaging and items prohibited under rule 4 of these rules in the rural area of the State or a Union territory.”;
(d)

for sub-rule (4), the following sub-rule shall be substituted, namely: -

“(4) The authorities referred to in sub-rule (1), (2) and (3) shall take the assistance of the District Magistrate or the
Deputy Commissioner and executive Head of Municipal Body for urban areas or Chief Executive Officer of the
District level Panchayats for rural areas within the territorial limits of the jurisdiction of the concerned district in
respect of the enforcement of the provisions of these rules”.
9.

In rule 13 of the said rules,-

(a) for sub rule (2), the following sub-rule shall be substituted, namely:“(2)
Every producer or importer or brand-owner shall for the purpose of one –time registration make an application
in Form I through the centralized online portal specified in Schedule II , to (i)

the State Pollution Control Board or the Pollution Control Committee of the Union territory concerned, if
operating in one or two States or Union territories; or

(ii)

the Central Pollution Control Board, if operating in more than two States or Union territories.”;

(b)

for sub rule (3), the following sub-rule shall be substituted, namely:-

“(3)
Every person recycling or processing waste or proposing to recycle or process plastic waste shall for the
purpose of one-time registration make an application to the concerned State Pollution Control Board or the Pollution
Control Committee in Form II through Centralized online portal specified in Schedule –II.”;
(c)

for sub-rule (5), the following sub-rule shall be substituted, namely:-

“(5) The State Pollution Control Board or the Pollution Control Committee shall not grant registration to plastic
waste recycling or processing units unless the unit possesses a valid consent under the Water (Prevention and
Control of Pollution) Act, 1974 (6 of 1974) and the Air (Prevention and Control of Pollution) Act, 1981 (14 of
1981) and a certificate of registration issued by the District Industries Centre or any other Government agency
authorised in this regard.”;
(d)

Sub-rule (9) shall be omitted.

(e)

Sub-rule (11) shall be omitted.

<!-- page 8 -->

8
10.

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

For rule 16 of the said rules, the following rule shall be substituted, namely: -

“16. State Level Monitoring Committee.- (1) The State Government or the Union territory Administration shall, for
the purpose of effective monitoring of implementation of these rules, constitute a State Level Monitoring Committee,
consisting of the following persons, namely:(a)

Additional Chief Secretary or Principal Secretary or Secretary in charge of the
Department of the State Government or Union territory Administration responsible
for municipal administration

Chairman;

(b)

Additional Chief Secretary or Principal Secretary or Secretary in charge of the
Department of the State Government or Union territory Administration responsible
of Panchayati Raj Institutions

Co- Chairman;

(c)

Additional Chief Secretary or Principal Secretary or Secretary in charge of the
Department of the State Government or Union territory Administration responsible
of
Urban
Development
or
his
nominee

Member;

(d)

Additional Chief Secretary or Principal Secretary or Secretary in charge of the
Department of the State Government or Union territory Administration responsible
of
Rural
Development
or
his
nominee

Member;

(e)

Additional Chief Secretary or Principal Secretary or Secretary in charge of the
Department of the State Government or Union territory Administration responsible
of Environment or his nominee

Member;

(f)

Member Secretary of the State Pollution Control Board or Pollution Control
Committee

Member;

(g)

Municipal Commissioners of cities having population of one million or more

Member;

(h)

One Municipal Commissioner from cities other than cities having population of one
million or more

Member;

(i)

One Chief Executive Officer of the District Level Panchayats

Member;

(j)

One expert from Non-Governmental Organisation
involved in Waste
management to be nominated by the State Government or Union territory
Administration

Member;

(k)

One representative of an industry association to be nominated by the State
Government or Union territory Administration

Member;

(l)

One expert from the field of Industry to be nominated by the State Government or
Union territory Administration

Member;

(m)

One expert from academia to be nominated by the State Government or Union
territory Administration

Member;

(n)

Director in charge, Department of the State Government or a Union territory
administration responsible for Panchayati Raj Institutions

Member

(o)

Director in charge, Department of the State Government or a Union territory
administration responsible for municipal administration

Member
Secretary.

(2)
The State Level Monitoring Committee shall meet at least once in six months and may invite experts, if it
considers necessary.”
11.

In schedule II to the said rules, -

(a)

in paragraph 6, for clause (6.3) the following clause shall be substituted, namely:-

“(6.3)The entities obligated to register under clause (6.1) shall not deal with any un-registered entity having
obligation to register under clause (6.1) through on-line centralized portal developed by the Central Pollution Control
Board”;

<!-- page 9 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

9

(b)
in paragraph 10, in clause (10.6), in the proviso, for the words and numbers “31st October 2023”, the
following words and numbers shall be substituted, namely:“30th November 2023”;
(c)

in paragraph 12, after clause (12.8), the following clauses shall be inserted, namely:-

“(12.9) The Central Government may permit filing of annual returns by Producers, Importers and Brand owners
under clause 10.6 and by Plastic Waste Processors under clause 11.2 for a period not exceeding nine months for the
reasons to be recorded in writing.”
(d)

after paragraph 15, the following paragraph shall be inserted, namely:-

“ 15A Purchase of extended producer responsibility certificate from different categories.(1)
The Central Pollution Control Board may allow purchase of extended producer responsibility certificates for
those categories where surplus exists over the extended producer responsibility obligation of that category for
fulfilment of extended producer responsibility obligation of such category where deficit exists.
(2)
In such cases, the Central Pollution Control Board shall prescribe the quantum of extended producer
responsibility certificates of the category required to be procured, where surplus exists, for fulfilment of extended
producer responsibility obligation of the category where deficit is present, based on the availability and cost of
collection, segregation and processing for different categories of plastic packaging waste.
(3)

The provision of this paragraph shall cease to apply at the end of 2025-2026.”.
[F. No. 12/31/2023 –HSM ]
Naresh Pal Gangawar, Addl. Secy.

Note : The principal rules were published in the Gazette of India, vide number G.S.R. 320(E), dated the 18th March,
2016 and subsequently amended vide notification number G.S.R. 285(E), dated the 27th March, 2018, vide
notification number G.S.R. 571(E), dated the 12th August, 2021, vide notification number G.S.R. 647(E),
dated the 17th August, 2021, vide notification number G.S.R. 133(E) , dated the 16th February 2022, vide
notification number G.S.R. 522(E) , dated the 6th July 2022 and lastly amended vide notification number
G.S.R. 318(E) , dated the 27th April 2023.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR
VERMA

Digitally signed by
MANOJ KUMAR VERMA
Date: 2023.10.30
23:02:02 +05'30'
