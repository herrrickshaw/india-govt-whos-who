---
doc_id: "ceedbdee220f1e75"
source_url: "https://master-dopt.digifootprint.gov.in/static/uploads/2025/08/019604804497b0062cb7a4bd7e9abfce.pdf"
ministry: "Department of Personnel and Training (DoPT)"
title: "The Lokpal and Lokayuktas (Amendment) Act, 2016"
date: "2016-08-10"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ddddab0b7b4f150f"
---

<!-- page 1 -->

F.No.407/16/2016-AVD-IV(LP)
Government of India
Ministry of Personnel, Public Grievances & Pensions
Department of Personnel & Training
North Block, New Delhi
Dated: the 10th August, 2016
OFFICE MEMORANDUM
Subject:

The Lokpal and Lokayuktas (Amendment) Act, 2016 .

The undersigned is directed to forward herewith a copy of the Lokpal and
Lokayuktas (Amendment) Act, 2016 published in the Gazette of India on 30 th July, 2016 for
information.
End: as stated above
It . I C
(Anil Bajpai)
Under Secretary to the Government of India

To
1.
2.
3.

All Secretaries to the Govt. of India (as per standard mailing list)
All Chief Secretaries of State Governments
All Administrators of the Union Territories

Copy to:
(i)Secretary General, Lok Sabha
(ii)Secretary General, Rajya Sabha
(iii)Comptroller and Auditor General of India
(iv)Secretary, Election Commission of India
1(

1-(
(AnilBajp)

Under Secretary to the Government of India

<!-- page 2 -->

14° t° 70°--(cri)04/0007/2003-16

REGISTERED NO. DL—(N)04/0007/2003-16

WPM 'WM
the Gatette of 4ndia
317itITPT

EXTRAORDINARY
%TM II — igus 1
PART II — Section 1

PUBLISHED BY AUTHORITY
746 44]
No. 44]

fq 'qtri-417, TOTt 30, 2016/ NT-4vi 8, 1938 (W)
NEW DELHI, SATURDAY, JULY 30, 2016/ SHRAVANA 8, 1938 (SAKA)

'FW Tff
*TEF TgIT AT Tr* I
ITFT fiT9' IrEEC *YU sgitif
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 30th July, 2016/Shravana 8, 1938 (Saka)

The following Act of Parliament received the assent of the President on the
29th July, 2016, and is hereby published for general information:—

THE LOKPAL AND LOKAYUKTAS (AMENDMENT) ACT, 2016
No. 37 OF 2016
[29th July, 20161

An Act to amend the Lokpal and Lokayuktas Act, 2013.
BE it enacted by Parliament in the Sixty-seventh Year of the Republic of India as
follows:—
1. (1) This Act may be called the Lokpal and Lokayuktas (Amendment) Act, 2016.
(2) It shall be deemed to have come into force on the 16th day of January, 2014.

2. On and from the date of commencement of the Lokpal and Lokayuktas

1 of 2014.

Short title and
commencement
Amendment of

Act, 2013 (hereinafter referred to as the principal Act), for section 44, the following section section 44.
shall be substituted, and shall be deemed to have been substituted, namely:-

"44. On and from the date of commencement of this Act, every public servant Declaration of
shall make a declaration of his assets and liabilities in such form and manner as may be
prescribed.".

assets.

<!-- page 3 -->

2
Amendment of
section 59.

THE GAZE"' 1E OF INDIA EXTRAORDINARY [PART II— SEC. 11

3. On and from the date of commencement of the principal Act, in section 59, in subsection (2), for clause (k), the following clause shall be substituted, and shall be deemed to
have been substituted, namely:—
"(k) the form and manner of declaration of assets and liabilities by public servants
under section 44:

Provided that the rules may be made under this clause retrospectively from the
date on which the provisions of this Act came into force;".

DR. G NARAYANARAJU,
Secretary to the Govt. of India.

Digitally signed
MANOJ
MANOJ byKUMAR
Date: 2016.07.30
KUMAR 23:26:09
+05'30'

PRINTED BY THE GENERAL MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI-2016.
GMG1PMRND-203201(S3)-30-07-2016.
