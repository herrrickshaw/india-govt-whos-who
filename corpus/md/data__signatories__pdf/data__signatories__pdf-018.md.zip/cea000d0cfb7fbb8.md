---
doc_id: "cea000d0cfb7fbb8"
source_url: "https://morth.gov.in/backend/documents/uploaded/1780393238_EG4C1KRo1S.pdf"
ministry: "Road Transport and Highways (MoRTH)"
title: "Improvement, Operation and Maintenance, Rehabilitation and Strengthening of Existing 2-lane Road and Widening to 4-lane divided Highway of Mahua Jaipur Section of National Highway-11 (NH-11) from km 120.000 to km 228.000 in the State of Rajasthan on Build, Operate and Transfer (BOT) basis. Proposal "
date: ""
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0429a3c60a0d35e5"
---

<!-- page 1 -->

e eat
a भारतीय राष्ट्रीय राजमार्ग प्राधिकरण
। bs (सड़क परिवहन एवं राजमार्ग मंत्रालय, भारत सरकार )
कक National Highways Authority of India Sy é
(Ministry of Road Transport & Highways, Govt of India)
परियोजना कार्यान्वयन इकाई, बिल्डिंग नं. 01, लूप नं. 2, भाण्डारेज इन्टरचेंज 181+450, दिल्ली मुम्बई एक्सप्रेसबे |(६-4, दौसा-303303 ( राज. )
Project Implementation Unit, Building No. 01, Loop No. 2, Bhandarej Interchange at Ch, 181450, Delhi Mumbai Expressway NE-4, Dausa-303303 (Raj.)
FAT Telephone : 01427-224918 $-AC/ E-mail: dausa@nhai.org, nhaidausa2021@gmail.com
No. 23011/26/ PIU/DAU/NOC/PHEDCh.163+000/1175 Date: 01.06.2026
INVITATION OF PUBLIC COMMENTS
सार्वजनिक टिप्पणियों का आमंत्रण
Sub.: Improvement, Operation and Maintenance, Rehabilitation and Strengthening of Existing
2-lane Road and Widening to 4-lane divided Highway of Mahua - Jaipur Section of
National Highway-11 (NH-11) from km 120.000 to km 228.000 in the State of Rajasthan on
Build, Operate and Transfer (BOT) basis. Proposal for grant of permission for laying
HDPE pipe of water pipe line along the highway at Km. 163.000 to 163.075 RHS side,
Km. 149.880 to 150.000 RHS side, and crossing at Km. 163.075 (RHS to LHS), 135.670
(RHS to LHS) & 134.600 (RHS to LHS), 155.100(RHS to LHS), 150.000 (RHS to LHS),
147.070 (RHS to LHS) by HDD method on NH-21Tehsil Dausa, Distt Dausa in the state
of Rajasthan.- reg.
Ref.: 1. IE letter no.3709 dated 15.05.2026
2. This office letter no. 24324 dated 05.02.2025
3. PHED, Sohela letter dated 29.01.2025
It, is to inform all concern that Executive Engineer PHED, Sohela vide letter cited under
ref. (3) above has submitted a Proposal for grant of permission for laying HDPE pipe of water
pipe line along the highway at Km. 163.000 to 163.075 RHS side, Km. 149.880 to 150.000 RHS side,
and crossing at Km. 163.075 (RHS to LHS), 135.670 (RHS to LHS) & 134.600 (RHS to LHS),
155.100(RHS to LHS), 150.000 (RHS to LHS), 147.070 (RHS to LHS) by HDD method on NH-
21Tehsil Dausa, Distt Dausa in the state of Rajasthan. (Jaipur-Mahua Section) in the state of
Rajasthan. And Independent Engineer submitted the above vide letter under ref. (1) for
approval of Competent Authority Highway Administration.
सभी संबंधितों को सूचित किया जाता है कि कार्यपालक अभियंता, एप्तछ), सोहेला ने ऊपर संदर्भ (3) के
तहत उल्लिखित पत्र के माध्यम से, राजस्थान राज्य के दौसा जिले की दौसा तहसील में 1गात-21 (जयपुर-महुआ
ws) 0% HDD विधि द्वारा जल्न पाइपल्राइन के लिए प्ला?5 पाइप बिछाने की अनुमति हेतु एक प्रस्ताव प्रस्तुत
किया है। यह पाइपलाइन राजमार्ग के 1६9. 163.000 से 163.075 (रात्र७ की ओर), या. 149.880 से 150.000
(रात्5 की ओर) तक बिछाई जाएगी, तथा 1७8. 163.075 (रात @ LHS), 135.670 (RHS से 19), 134.600
(RHS # LHS), 155.100 (RHS & LHS), 150.000 (RHS से 15) और 147.070 (RHS @ LHS) W
राजमार्ग को पार करेगी। स्वतंत्र अभियंता ने, सक्षम प्राधिकारी (राजमार्ग प्रशासन) के अनुमोदन हैतु, संदर्भ (1)
के तहत उल्लिखित पत्र के माध्यम से उपर्युक्त प्रस्ताव प्रस्तुत किया है। .
2. The proposal is grant of permission for laying HDPE pipe of water pipe line along the
highway at Km. 163.000 to 163.075 RHS side, Km. 149.880 to 150.000 RHS side, and crossing at
Km. 163.075 (RHS to LHS), 135.670 (RHS to LHS) & 134.600 (RHS to LHS), 155.100(RHS to LHS),
150.000 (RHS to LHS), 147.070 (RHS to LHS) pertaining to Jaipur-Mahua project.
यह प्रस्ताव जयपुर-महुआ परियोजना के संबंध मैं, हाईवे के किनारे 101. 163.000 से 163.075 (RHS
की ओर) और 1<ण. 149.880 & 150.000 (RHS #1 HR) पर पानी की पाइपलाइन के लिए प्ला)?5 पाइप
बिछाने की अनुमति देने का है; साथ ही 1. 163.075 (श्र से 1115), 135.670 (0रात्र७ से 19), 134.600
मुख्यालय : जी-5 एवं 6, सेक्टर - 10, द्वारका, नई दिल्‍ली - 110075 : टेलफोन : 011.25074100, 25074200
Corporate Office : G-5 & 6, Sector-10, Dwarka, New Delhi-110075 : Telephone : 011-25074100 & 25074200
Web : www.nhai.gov.in

<!-- page 2 -->

(RHS @ LHS), 155.100 (RHS @ LHS), 150.000 (RHS @ LHS) HW 147.070 (RHS @ LHS) पर
क्रॉसिंग की अनुमति भी इसमें शामित्र है।
3. As per para-4 of Ministry's guideline No. RW/NH-33044/ '29/2015S&R(R) dated
22.11.2016 the application shall be put out in the public domain for 30 days for seeking claims
and objections (on grounds of public inconvenience, safety and general public interest).
मंत्रालय के दिशानिर्देश संख्या आरडब्ल्यू/एनएच-33044/29/2015एस एंड आर(आर) दिनांक 22.11.2016
के पैरा-4 के अनुसार आवेदन को दावे और आपत्तियां (सार्वजनिक असुविधा, सुरक्षा और सामान्य सार्वजनिक
हित के आधार पर) मांगने के लिए 30 दिनों के त्रिए सार्वजनिक डोमेन में रखा जाएगा।
4. In view of the above, before conveying approval of the Competent Authority, the
comments/ objections of affected public is hereby invited with reference to the Ministry's circular
dated 22.11.2016, for NOC from National Highway/Expressway permission for laying HDPE
pipe of water pipe line along the highway at Km. 163.000 to 163.075 RHS side, Km, 149.880 to
150.000 RHS side, and crossing at Km. 163.075 (RHS to LHS), 135.670 (RHS to LHS) & 134.600
(RHS to LHS), 155.100(RHS to LHS), 150.000 (RHS to LHS), 147.070 (RHS to LHS) The
objections/comments may be addressed to the below mentioned address upto 30.06.2026.
beyond due date, no comments/ objections will be accepted.
4. उपरोक्त को ध्यान में रखते हुए, सक्षम प्राधिकारी की मंज़ूरी देने से पहले, मंत्रालय के दिनांक
22.11.2016 के सर्कुलर के संदर्भ में, प्रभावित जनता से टिप्पणियाँ/आपत्तियाँ आमंत्रित की. जाती हैं। यह 1४0९
राष्ट्रीय राजमार्ग/।एक्सप्रेसवे से संबंधित है, जिसमें राजमार्ग के किनारे (9. 163.000 से 163.075 (रत की
ओर), 169. 149.880 से 150.000 (रात्र& की ओर) तक HDPE oir की पाइपलाइन बिछाने की अनुमति मांगी
गई है; साथ ही 1६9. 163.075 (रत्र5 से 1.9), 135.670 (रातत5 @ LHS), 134.600 (रात्र5 से 15), 155.100
(रात5 से 115), 150.000 (रात से 1.15), और 147.070 (रात्र5 से 1.8) पर क्रॉसिंग की अनुमति भी मांगी
गई है। आपत्तियॉ/टिप्पणियाँ नीचे दिए गए पते पर दिनांक 30.06.2026 तक भेजी जा सकती हैं। निर्धारित
तिथि के बाद, कोई भी टिप्पणी/आपत्ति स्वीकार नहीं की जाएगी।
The Project Director, NHAI-Dausa
National Highway Authority of India
Project implementation unit Dausa,
Building no. 01, Loop no. 2, Bhandarej Interchange at Ch. 181+450
Delhi-Mumbai Expressways NE-4, Dausa-303303
Tel-01427-224918, Email-dausa@nhai.org teers
( क्षाराराप्रा, पकाई-दौसा
Copy to:
1, Web-Admn. NHAIL HQ New Delhi- for uploading in NHAI website[web-
admin@nhai.org].
2. Director, NIC, New for uploading in Ministry's website[mansoor@nic.in].
3. SE PHED Sohela.( eepsoyla.ton. phed@rajasthan.gov.in)

<!-- page 3 -->

SIVA D
oP 49 (/] कर CT: VT T
(>. “@\ (LN. MALVIYA INFRA PROJECTS PVT. LTD.
4 Pe z 0255-78»
a ० 8
(9.2/००५५४ ५६ 1/73 Housing Board Colony Khan Bhakri Road Dausa -303303
Lad sy Mo- 01427- 294145 _E mail — Indausa@zmail.com
enn nimtesimnae-sconier te 1 .
LNM/Dausa/O&M/IE/05/2025/3709 भाराणप्रा प. Rak Gey Date: 15.05.2026 Lee
हि Wet x. पिमांक ——————
The Project Director, pc I mylar. sms he
National Highways Authority of India 'विषय:- “Mo 5 Jed b Himes
Project Implementation Unit, Dausa, —___
87, Ganga Vihar Coiony, Behind Hotet Rawat Palac an
Dausa, Rajasthan — 303303 ] leaoe T 4
, 'प्रब्धक (वक)-1| SOY wn
Sub: Independent Engineer services during the Operation-& Maintenance stage of 4/6 laning of Agra Jaipur
(Agra — Bharatpur from Km 17.756 to Km 62.295, Bharatpur-Mahua section from Km 62.295 to Km
119.695, Mahua — Jaipur from Km 119.695 to Km 228) of NH 11 (New NH-21) under NHDP Phase —
IIIA in the state of Rajasthan & Uttar Pradesh. Proposal for grant of permission for laying HDPE pipe
~ of water pipe line along the highway at km. 163.000 to 163.075 RHS side, Km. 149.880 to 150.000
Ne RHS, and Crossing at km. 163.075 (RHS to LHS) 135.670 (RHS to LHS) & 134.600 (RHS to LHS)
Qe 155.100 ( RHS to LHS) , 150.000 ( RHS to LHS) , 147.070 ( RHS to LHS) by HDD Method on NH-21
Tehsil Dausa ; Distt Dausa in the state of Rajasthan.
Ref:
1, NHAI letter no, 23011/26/PIU/DAU/NOC/PHED Sohela163.000/430, dated 09.04.2026
2. PHED letter dated 18.03.2026
3. NHAI letter no. 23011/26/PIU/DAU/NOC/PHED Sohela163.000/3636, dated 30.01.2026
4, Our letter no. LNM/Dausa/O&M/IE/07/2025/3527, dated 19.01.2026
Dear Sir,
This is with reference to above cited subject and your letter no 430 dated 09.04.2026 vide which it
has been requested to examine the Proposal for grant of permission for laying HDPE pipe of water pipe
line along the highway at km. 163.000 to 163.075 RHS side, Km. 149.880 to 150.000 RHS, and Crossing at km.
163.075 (RHS to LHS) 135.676 (RHS to LHS) & 134.600 (RHS to LHS} 155.100 ( RHS to LHS) , 150.000 ( RHS to.
LHS) , 147.070 ( RHS to LHS) by HDD Method on NH-21 Tehsil Dausan Distt Dausa in the state of Rajasthan.,
in light of MoRT&H guideline dated 22.11.2016.
In this regards we have examined the above said proposal in light of MoRT&H guideline dated
22.11.2016 & 17.04.2023 and our comments/observations are as mentioned below:-
1. The applicant has been submitted the proof of online submission.
2. The applicant submitted for HDD & open trenches locations GPR report as per MORTH
guidelines dated 17.04.2023
3. The applicant has been submitted the safety plan.
4. The drawing and checklist dully verified and signed as per site condition.
5. Drone video, NSV survey video and as-built drawing enclosed (as per Instruction of RO NHAI Jaipur
letter no. 1057, dated 13.08.2024).
GaP
The above said proposal has been prepared in light of MORT&H guide fine RW/NH-33 & for S.\ PER
dated 22.11.2016 vide which applicant shall paid license fee for use of highway land. __ ais = a) %
TO Head Office: 4)
Ill" Floor, City Centre, Press Complex, Plot No. -1, M.P.Nagar Zone —I,Bhopal (M.P.), 469 .
Tel/Fax: 0755-4295421, Mob. 098264527 11,09977004686,9926050707 Vv) Ke
Email: Inmalviya@rediffmail.com, website www.|ninfra.com
CIN No. U45201MP2010PTC024316
मै ow
3
ab

<!-- page 4 -->

co’ 1¥4 थे
> 2: F R P
le ®\ L.N. MALVIYA INFRA PROJECTS PVT. LTD.
ag. 2 SST eatiomnisiatanca canaries
‘¢> BHOPAL 1/73 Housing Board Colony Khan Bhakri Road Dausa -303303
Laa s3> Mo- 01427- 294145 _E mail — jndausa/@email.com
In light of above, the permission of lying of water pipe line can be given only in utility corridor of the Project
Highway subject to the following conditions:
1. The stability & structure safety of the bridge/structure embankment/road crust etc while laying water
pipeline shall be ensured by the concerned department.
2. Before starting any work, PHED should obtain necessary clearance for cut /shifting from Forest
Department or other concerned department and then execute the actual work at site. .
3. The concerned department will carry out the work of shifting /relocation of above water supply pipe
line whenever required in further by NHAI at their own cost as per requirement & direction of NHAI.
4. No damage to avenue plantation shall be done during laying work. In case of damages, the applicant
shail restore the same at its own cost, by replacing the plants/trees of same age & height and growth.
5. Any other utility (OFC,Pipeline...etc) is already laid within the ROW. Before starting the work please
concern with respective authority.
6. The applicant may strictly be advised to bring in shape the ROW after laying of Pipeline as it was prior to
laying work.
7. In case of any damages to ongoing road work due to laying of pipeline within ROW, all costs pertaining
to repair & the claims likely be raised by the independent Engineer shall be borne by the PHED
8. The applicant shall execute the work with utmost care as not to damage the existing utilities and shall
be fully responsible for any damage to the existing utilities
The applicant shall be responsible for any damage to the existing utility of any agency & department during
the laying of water pipe line and shall compensate to the concerned agency for its repair /reaction if any
damage.
For five years license fee is Rs. 3,29,050/- and Bank Guarantee amount is Rs.79,525/- for recovery of any
kind of damages occurred due to Water pipe line along the project highway ( NH-21).
In view of the above the proposal is generally satisfy ministry guideline RW/NH-33044/29/2015/S&R/(R)
dated 22.11.2016, and it is recommended for grant of permission of laying water pipeline.
The check list and drawing have been verified and signed.
Yours sincerely,
For LN Malviya infra Projects
Saka P 3
©
BN FUSE} -y
Z all KIL
RAs nf Se er
Enc शी
cc:
1, Project Manager, Rajadhok Toll Plaza, Bassi
2. Anil Saxena , Director Project, LNM, Bhopal
Head Office:
I Floor, City Centre, Press Complex, Plot No. -1, M.P.Nagar Zone —I,Bhopal (M.P.), 462011
Tel./Fax: 0755-4295421, Mob. 098264527 | 1,09977004686,9926050707
Email: Inmalviya@rediffmail.com, website www.Ininfra.com
CIN No. U45201MP2010PTC024316

<!-- page 5 -->

gaia] s elele sg 4 1
ताजा
i
Hing is a iM a a हि
ड४ 88 27 हा
8s a
हुई 8 88816 [88 ga
tell = (E/E me) 5
१418 8 |8 | 5 8 68 11 | 8 <3
eg ,gei 2 2/2] 2/8] 3]2
Hal g lelelelalg/ae
gse 2 |elelelelelelale|8
a3 8 |s/elslelalslale
ह
22) a.
3 fig 3 ३88 88
a
ge a lele g
= a 8/8/83
i pL EERIE:
5o;—
s3) § | 2 lelelelelele
5 ३ 8 8 8 88 ६
ali है | है है है || |
| |" * ०)
| ३ |*|*|*|० ० «|
BSeo_
Bes
et alae ड़
32 | 6| 9५ 2
3 AOE:
है ् ‘
25 S
zs € ६ै। 51815 EV ELE
ge | 8 ls] 8lslsslélé
छ
है | है है 88 88858
yl 4 /8|8 eas
i Hl
2 « 5
[०० [०००० |
