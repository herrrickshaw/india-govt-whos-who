---
doc_id: "90daaabed15ea053"
source_url: "https://www.dhr.gov.in/static/uploads/2025/09/fd410345f63abaff846b8a26f4ff457c.pdf"
ministry: "Department of Health Research (DHR)"
title: "Draft Recruitment Rules (RRs)"
date: "2018-04-12"
pages: 12
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "4d0649fd9b6e303d"
---

<!-- page 1 -->

No. V.25011/265/2012-HR (Part II) / E-Office: 3146708
Government of India
Ministry of Health & Family Welfare
Department of Health Research
2™ Floor, IRCS Building,
1, Red Cross Road, New Delhi -- 110001
Dated: \\** April, 2018
NOTICE
All stakeholders are requested to offer their comments/suggestions, if any, in respect of
the draft ‘Notification’, as annexed herewith, prescribing draft Recruitment Rules (RRs) in
respect of the posts of Scientist ‘E’, Scientist ‘D’ and Scientist <C’ in the Department of Health
Research, New Delhi within 30 days of the uploading of this notice and the same may be sent
in hard copy to Shri Vinod Kumar, Under Secretary, Department of Heatth Research,
2nd Floor, IRCS Building, Red Cross Road, New Delhi — 110001 as well as in soft copy
via email at <js-sm-dhr@gov.in>. L OK
n\4
(Om Parkas!
Under Secretary to the Government of India
Tel: 23736090

<!-- page 2 -->

TO BE PUBLISHED IN THE GAZETTE OF INDIA
PART IL, SECTION 3, SUB-SECTION (i)
Government of India
Ministry of Health & Family Welfare
(Department of Health Research)
New Delhi dated ...........-
NOTIFICATION

GSR........ In exercise of the powers conferred by the proviso to article 309 of the
Constitution, the President hereby makes the following rules regulating the method of
recruitment to the Group ‘A’ (non ministerial Scientific and Technical) posts in the
Ministry of Health & Family Welfare (Department of Health Research), namely:

1. Short title, commencement and application: -

(i) These rules may be called the Ministry of Health & Family Welfare (Department

of Health Research) Group ‘A’ Gazetted posts (non ministerial Scientific and

Technical) Recruitment Rules, 2018.

(ii) They shall come into force on the date of their publication in the Official Gazette.

(iii) They shall apply to the posts of Scientist ‘E’, Scientist ‘D and Scientist ‘C’.

"2, Number of posts, classification and Level in Pay Matrix: The number of
posts, their classification and the Level in Pay Matrix attached thereto shall be
as given in column (2) to (4) of Schedule attached to these Rules.

3. Method of Recruitment, age limit, other qualifications etc.: The method of
recruitment, age limit, qualifications and other matters relating to the said post
shall be as specified in Columns (5) to (13) of the said Schedule.

4. Disqualifications: - No person:

(a) who has entered into or contracted a marriage with a person having a spouse
living; or

(b) who, having a spouse living, has entered into or contracted a marriage with any
person, shall be cligible for appointment to the posts under these rules:
Provided that the Government may, if satisfied that such marriage is permissible
under the personal law applicable to such person and the other party to the
marriage and that there are other grounds for so doing, exempt any person from
the operation of this rules.

<!-- page 3 -->

5. Powers to Relax: Where the Central Government is of the opinion that it is
necessary or expedient so to do, it may, by order for reasons to be recorded in
writing and in consultation with Union Public Service Commission, relax any of
the provisions of these rules with respect to any class or category of person.

6. Saving:- Nothing in these rules shall affect reservations, relaxation of age-limit
and other concessions required to be provided for the Scheduled Castes, the
Scheduled Tribes, Ex-servicemen and other special categories of persons, in
accordance with the orders issued by the Central Government from time to time
in this regard.

<!-- page 4 -->

) Annexure-1 (Draft 13-column Schedule of the proposed RRs)
Name of | Number of | Classification | Level! in | Whether Age limit for | Educational and other qualifications required
Post Post (s) Pay Selection direct for direct recruits

Matrix Post or Non- | recruits
Selection
Pot 2 a ै रे 4 र आय फ 8 8 |
2* (2018) | General Level 11 Non-selection | Not exceeding | Post Graduate degree (MD/MS/DNB) with one year
* Subject Central (Rs.67700- 40 years R&Diteaching experience or Postgraduate diploma
to variation | Service, 208700) (Relaxable for | in medical subjects with two years R&D/teaching
depending | Group ‘AY Government | experience in the required subject from recognized
on Gazetted, servants upto | university
workload. | Non- five years in Or
ministerial accordance MBBS degree recognized by MCI or equivalent
with the | degree from recognized University with 4 years
instructions or | R&D/Teaching experience in the required subject
orders issued | after MBBS degree
by the Central or
Government.) | BDS/B.V.Sc & AH degree recognized by DCI/VCI
with 5 years R&D/Teaching experience in the
Note: The | relevant subject after BDS/B.V.Sc Degree
crucial date Or
for B.Tech degree in relevant Engineering subject with
determining six years R&D/Teaching experience in the relevant
the age-tmit | subject after B.Tech degree
shall be as Or
advertised by | First Class Master's degree in the relevant subjects
the UPSC. from a recognized university with 4 years
R&D/teaching experience in the relevant subject
after 1* Class Master's degree
Or
Second class M.Sc + PhD degree in the relevant
subject from a recognized University with 4 years
R&D/teaching experience in the relevant subject
after M.Sc + PhD.
{

<!-- page 5 -->

) Desirable qualifications:
() Doctorate or M. Tech Degree in relevant
science or engineering subject or MD in the
relevant subject from a recognized university for
candidates with first class relevant degree
(3) Additional Post-doctoral research/ teaching
experience in relevant subjects in recognized
institute(s)
Gi) Knowledge of Computer Applications or
Business Intelligence tools/ Data Management
Notes:
1. Candidates with Post Graduate Degree in
medical subjects/Doctorate Degree in Life
Sciences/relevant subjects shall be recruited as
Scientist ‘C’ after requisite training under Talent
Search Scheme as per Schedule-IV
2. MD/MS/MDS/PhD in the relevant subject shail
be treated equivalent to three years’ experience.
3 Postgraduate Diploma in medical
subjects/M.Tech/ M.V.Sc in the relevant subjects
shall be treated equivalent to two years’
experience.
4. The exact qualifications and areas of experience
shall be specified according to the functional
requirement of the Department by the Secretary of
the Department.

<!-- page 6 -->

Whether age | Period of | Method of recruitment ; In case of recruitment by promotion or deputation/ | If Circumstances
) and Probation, | whether by direct | absorption, grades from which promotion or | Departmental | in which the
educational if any recruitment or by | deputation/ absorption to be made Promotion Union Public
qualifications promotion or by Committee Service
prescribed for deputation/absorption exists, what | Commission is
direct recruits and percentage of is its | to be
will apply in vacancies to be filled composition | consulted in
the case of by various methods making
promotees recruitment
Not Applicable {One year | By deputation (including | The officers of Central State Government, Union | Not Applicable | Consultation
in the case | short-term contract) | Territories, autonomous / statutory organizations / PSUs with the Union
of — direct | failing which by direct | / University/ Recognised Research Institutions Public Service
recruits recruitment Commission is
(a) (i) holding analogous post on a regular basis in the necessary in all
parent cadre or department; occasion.
Or
{i)With 5 years’ service rendered after appointment to
the post on a regular basis in Level 10 (Rs.56100-
177500) in the Pay Matrix or equivalent in the parent
cadre or department; and
(b) possessing the qualifications and experience
prescribed for direct recruitment under Col. No.7
Notes:
(The period of deputation (including short term
contract) including the period of deputation in another
ex-cadre post held immediately preceding this
appointment in the same or some other
organisation/department of the Central Government
shall ordinarily not exceed three years.
(ii) The maximum age limit for appointment by
deputation (ISTC) shall be ‘Not exceeding 56 years’ as
on last date of receipt of applications.

<!-- page 7 -->

न |
Name of | Number | Classification | Level in} Whether | Age limit for | Educational and other qualifications required for direct
) Post of Posts Pay Matrix | Selection | direct recruits.
Post or | recruits |
Non- }
Selection
Post
po 1 __ डटैू | 3 (4 | ठ॑ | 6 | एऑ+ 7 ३ 0फहोल्‍ल |
2* (2018) | General Level 12 | Non- Not (i) Past Graduate degree (MD/MS/DNB) with one year
* Subject | Central (Rs.78800- | selection | exceeding 50 | R&D/teaching experience or Postgraduate diploma in
to Service, 209200) years medical subjects with six years R&D/teaching experience in
variation Group ‘A, (Relaxable for | the required subject from recognized university
depending | Gazetted, Government Or
on Non- servants upto | MBBS degree recognized by MCI or equivalent degree from
workload. | ministerial five years in | recognized University with 8 years R&D/Teaching experience
accordance in the tequired subject after MBBS degree
with the ५ Or
instructions or | BDS/B.V.Sc& AH degree recognized by DCI/VCI with 5
orders issued | years R&D/Teaching experience in the relevant subject after
by the Central | BDS/B.V.Sc Degree
Government.) ‘ Or
B.Tech degree in relevant Engineering subject with ten years
Note: The | R&D/Teaching experience in the relevant subject after
crucial date | B.Tech degree
for Or
determining First Class Master's degree in the relevant subjects from a
the age-limit | recognized university with 4 years R&D/teaching experience
shall be as | in the relevant subject after 1° Class Master's degree
advertised by Or
the UPSC. PhD degree in the relevant subject from a recognized
University with 8 years R&D/teaching experience in the
relevant subject after M.Sc + PhD.
(il) Out of above 2 years in a managerial position to handle
R&D projects in a team effectively in a directing capacity
Desirable qualifications:

<!-- page 8 -->

|

(i) Dogtorate or M. Tech Degree in relevant science or
) engineering subject or MD in the relevant subject from a

recognized university for candidates with first class relevant

degree

(ii) Additional Post-doctoral research/ teaching experience in

relevant subjects in recognized institute(s)

(iii) Knowledge of Computer Applications or Business

Intelligence tools /Data Management

Notes:

1. MD/MS/MDS/PHD in the relevant subject shall be treated

equivalent to three years’ experience.

2. Postgraduate Diploma in medical subjects/M.Tech/M.V.Sc

in the relevant subject shall be treated equivalent to two

years’ experience.

3. The exact qualifications and areas of experience shall be

specified according to the functional requirement of the

Department by the Secretary of the Department.

<!-- page 9 -->

) Whether age | Period of | Method Of|in case of recruitment by promotion or deputation/ | If Circumstanc
and Probation | recruitment absorption, grades from which promotion or deputation/ | Department | es in which
educational! |, if any whether by direct | absorption to be made al the Union
qualification recruitment or by Promotion Public
$s prescribed promotion or by Committee | Service
for direct deputation/absor exists, what | Commission
recruits will ption and is its|is to be
apply in the percentage of compositio | consulted in
case of vacancies to be n making
promotees filled by various recruitment

methods
ls OS COSA a8
Not applicable ] One year | By deputation | The officers of Central/State Government, Union Territories, Not Consultation
in the case j (including short | autonomous / statutory organizations / PSUs / University / | applicable with the Union
of direct | term contract), | Recognised Research Institutions Public Service
recruits failing which by Commission
direct recruitment | (a) (i) holding analogous post on a regular basis in the parent is necessary
cadre or department; in all
or occasion.
(i) With 5 years’ service rendered after appointment to the post on
a regular basis in the Level 11 (Rs.67700-208700) in the Pay
Matrix or equivalent in the parent cadre or department; and
{b) possessing the qualifications and experience prescribed for
direct recruitment under Col. No.7
Notes:
() The period of deputation (including short term contract)
including the period of deputation in another ex-cadre post held
immediately preceding this appointment in the same or some
other organisation/department of the Central Government shall
ordinarily not exceed three years. ह
(ii) The maximum age limit for appointment by deputation (ISTC)
shall be ‘Not exceeding 56 years’ as on’'last date of receipt of
applications. ,

<!-- page 10 -->

: i
) Name of | Number | Classification | Level in | Whether | Age limit for | Educational and other qualifications required for
Post of Posts. Pay Matrix | Selection | direct directlrecruits
Post or | recruits |
Non-
Selection
Post
हक 2 | 3 ( $ [(( 5 |1|_ ७6 '
Scientist ‘E’ | 2* (2018) | General Level 13 | Non- Not (i) Post Graduate degree (MD/MS/DNB) with seven year
* Subject | Central (Rs.123100- | selection | exceeding 50 | R&DAeaching experience or Postgraduate diploma in
to Service, 216900) years medical subjects with eight years R&D/teaching
variation | Group ‘A, (Relaxable experience in the required subject from recognized
depending | Gazetted. for university
on Non- Government ‘ Or
workload. | ministerial servants upto | MBBS. degree recognized by MCI or equivalent degree
five years in | from recognized University with ten years R&D/Teaching
. accordance experience in the required subject after MBBS degree
with the Or
instructions BDS/B.V.Sc & AH degree recognized by DCI/VCI with 11
or orders | years R&D/Teaching experience with the relevant subject
issued by the | after BDS/M.V.Sc Degree
Central Or
Government.) | B.Tech degree in relevant Engineering subject with ten
years R&D/Teaching experience in the relevant subject
Note: The | after B.Tech degree
crucial date Or
for First Class Master's degree in the relevant subjects from a
determining recognized university with 10 years R&D/eaching
the age-limit | experiénce in the relevant subject after 1% Class Master's
shall be as | degree
advertised by Or
the UPSC. Second Class M.Sc + Ph.D degree in the relevant subject
from a recognized University with 10 years R&D/Teaching
experience in the relevant subject after M.Sc + Ph.D.
(ii) Out of above 3 years in a managerial position to handle
R&D ptojects in a team effectively in a directing capaci
