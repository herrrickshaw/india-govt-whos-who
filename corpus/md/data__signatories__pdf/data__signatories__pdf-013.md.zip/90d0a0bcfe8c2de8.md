---
doc_id: "90d0a0bcfe8c2de8"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/c3e4496325d944d9d11880fe58e8adc2.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Child Labour Rules (Act & Rules)"
date: "2025-06-25"
pages: 11
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ba2031ae79854615"
---

<!-- page 1 -->

iF
- |
|
|
|
। |
4 a a”
al
| |
i | THE CHILD AND ADOLESCENT LABOUR |
, | (PROHIBITION AND REGULATION) RULES, 19881
हे In exercise of the powers conferred by sub-section (1) Of section 18 of the Child
Labour (Prohibition and Regulation) Act, 1986 (61 of 1986), the Central Government
4 hereby makes the following rules, namely:— ह
1. Short title and commencement.—(1) These rules may be called the >[Child
| and Adolescent Labour] (Prohibition and Regulation) Rules, 1988,
(2) They shall come into force on the date? of their Publication in the Official
Gazette. as
2. Definitions —In these rules, unless the context otherwise requires — i
j ‘[(a) “Act" means the Child and Adolescent Labour (Prohibition and
Regulation) Act, 1986 (61 of 1986); |
(b) “Committee” means the Technical Advisory Committee constituted
है under sub-section (1) of section 5 of the Act;] |
' (c) “Chairman” means the Chairman of the Committee appointed under j
i sub-section (2) of section 5 of the Act; |
q (d) “Form” means a Form appended to these rules; i
मे 5[(da) “Fund” means the Child and Adolescent Rehabilitation Fund
| constituted under sub-section (1) of section 14B of the Act;]
4 5[(db) “Inspector” means the Inspector appointed by the Central Government |
i under section 17;]
1 5I(de) “Municipality” means an institution of self-Government constituted
j under article 243Q of the Constitution;]
i (e) “register” means the register required to be maintained under
- | section 11 of the Act;
{ 5I(ea) “Panchayat” means a Panchayat constituted under article 243B of
i the Constitution,]
| (f) “Schedule” means the Schedule appended to the Act;
(g) “section” means a section of the Act.
i 5[(h) words and expressions used in these tules, but not defined therein
} and defined in the Act, shall have the meanings as assigned to them
: in the Act.]
sgl. Vide GSR. 847(B), dated 10th August, 1988, published in the Gazette of India, Extra., Pt, u, |
“Sec. 3(i), dated 10th August, 1988. ॥
2. Subs. by G.S.R. 543(B), dated 2nd June, 2017, for "Child Labour" (w.e.£. 2-6-2017).
3. Came into force on 10-8-1938,
| 4. Subs. by GSR. 543(E), dated 2nd June, 2017, for clauses (a) and (b) (wet, 2-6-2017)
; Clauses (a) and (b), before substitution, stood as under:
4 ‘(@) “Act” means the Child Labour (Prohibition and Regulation) Act, 1986 (61 of 1986);
यु (0) “Committee” means the Child Labour Technical Advisory Committee constituted under
sub-section (1) of section 5 of the Act; ~ |
5. Ins. by G.S.R. 543(B), dated 2nd June, 2017 (w.e4. 2-6-2017), |
| 19 [1
| i
= |

<!-- page 2 -->

— ee a
20 The Child and Adolescent Labour (Prohibition and [Rule 2A
Regulation) Rules, 1988
1/24, Awareness on prohibition) of employment of child and adolescents in
contravention to Act.—The Central Government, to ensure that the children and
adolescents are not employed or permitted to work in any occupation or process
in contravention to the provisions of the Act, through appropriate measures,
shall—
(a) arrange public awareness campaigns using folk and traditional
media and mass media including television, radio, internet based.
न application and the print media to make the general public, including
the employers and the children and adolescents who may be
employed in contravention to the provisions of the Act, aware about .
the provisions of the Act, and thereby discourage employers or other
persons from engaging children and adolescents in any occupation
or process in contravention of the provisions of the Act;

(b) promote reporting of enterprises or instances of employment of
children or adolescents in contravention to the provisions of the Act, by
developing and advertising easily accessible means of communication
to authorities specified by the Central Government;

(c) display to the possible extent the provisions of the Act, these rules
and any other information relating thereto in railway coaches, at
railway stations, major bus stations, toll plazas, ports and port
authorities, airports and other public places including shopping
centers, markets, cinema halls, hotels, hospitals, Panchayat offices,
police stations, resident welfare association offices, industrial areas,
schools, educational institutions, court complexes, and offices of all
authorities authorised under the Act;

(d) promote through appropriate method the inclusion of the provisions
of the Act in learning material and syllabus in school education;
and

(e) promote inclusion of training and sensitisation material on the
provisions of the Act and the responsibilities of various stakeholders
thereto, in Central Labour Service, police, judicial and civil service
academies, teachers training and refresher courses and arrange
sensitisation programmes for other relevant stakeholders including,

Panchayat members, doctors and concerned officials of the
Government.]
1[2B. Child to help his family without affecting education—(1) Subject to
the provisions of section 3, a child may, without affecting his school education,
in any manner,—
(a) help his family in his family enterprise, subject to the condition that
such help,—
(i) shall not be in any hazardous occupation or process listed in
Part A and Part B of the Schedule to the Act;
i (ii) shall not include work or occupation or process at any stage
of the manufacturing, production, supply or retail chain
1. Ins. by GSR. 543(B), dated 2nd June, 2017 (wef. 2-6-2017).

<!-- page 3 -->

|
1 .
|
4 e
| Rule 28] The Child and Adolescent Labour (Prohibition and 21 |
| Regulation) Rules, 1988
|
| that is remunerative for the child or his family or the family
| enterprise;
(iii) shall only be allowed to help in his family, or in a family
enterprise, where his family is the occupier;
(iv) shall not perform any tasks during school hours and between 7
i p.m. and 8 a.m.;
(v) shall not be engaged in such tasks of helping which hinders
or interferes with the right to education of the child, or his
attendance in the school, or which may adversely affect his
५ education including activities which are inseparably associated
to complete education such as homework or any extra-curricular
activity assigned to him by the school;
(vi) shall not be engaged in any task continuously without rest which ~
may make him tired and shall be allowed to take rest to refresh
his health and mind, and a child shall not help for more than |
1 three hours excluding the period of rest in a-day; |
i (vii) shall not include in anyway substitution of the child for an
| | adult or adolescent while helping his family or family enterprise;
and
1 (viii) shall not be in contravention to any other law for the time being |
i in force:
4 (b) aid or assist his family in such manner which is not incidental to 1
| any occupation, work, profession, manufacture or business, or for |
; any payment or benefit to the child or any other person exercising |
1 control over the child, and which is not detrimental to the growth, |
{ education and overall development of the child. 1
- 1 Explanation 1.—For the purposes of this rule, only—
(a) biological brother and sister of the child;
1 (b) brother or sister of the child through lawful adoption by parents of
1 the child; and
7 (c) biological brother and sister of parents of the child,
: shall be included for comprising the family of a child.
J Explanation 2.—For the purposes of Explanation 1, it is hereby clarified
that preliminarily, any doubt as to whether a person is a biological brother or
_ sister, may be removed by examining the pedigree of such person issued
*% by. the concerned Municipality or Panchayat, as the case may be, or any
other legal document issued by concerned authority of the appropriate |
Government. |
1 (2) Where a child receiving education in a school remains absent consecutively |
for thirty days without intimation to the Principal or Head Master of the
| school, then, the Principal or Head Master shall report such absence to the
concerned nodal officer referred to in clause (i) of sub-rule (1) of rule 17C for
information.] |
| “hy ||
| 1।' _ जज  फफफफ |

<!-- page 4 -->

SES" a
4
22 The Child and Adolescent Labour (Prohibition and [Rule 2c
Regulation) Rules, 1988
गृ2ट, Child to work as an artist.—(1) Subject to the provisions of section 3,
a child may be allowed to work as an artist subject to the following conditions,
namely:—

(a) no child shall be allowed to work for more than five hours in a day,
and for not more than three hours without rest;

(b) any producer of any audio-visual media production or any
commercial event involving the participation of a child, shall
involve a child in participation only after obtaining the permission
from the District Magistrate of the district where the activity is to
be performed, and shall furnish to the District Magistrate before
starting the activity an undertaking in Form C and the list of child
participants, consent ‘6f ‘parents or guardian, as the case may be,
name of the individual from the production or event who shall be
responsible for the safety and security of the child;and ensure that
all screening of his films and television programmes shall be made
with a disclaimer specifying that if any child has been engaged in
the shooting, then, all the measures were taken to ensure that there
has been no abuse, neglect or exploitation of such child during the
entire process of the shooting;

(c) the undertaking referred to in clause (b) shall be valid for six months
and shall clearly state the provisions for education, safety, security
and reporting of child abuse in consonance with the guidelines and
protection policies issued by the Central Government from time to
time for such purpose including—

() ensuring facilities for physical and mental health of the child;
(ii) timely nutritional diet of the child;
(iii) safe, clean shelter with sufficient provisions for daily necessities;
and
(iv) compliance to all laws applicable for the time being in force for
the protection of children, including their right to education,
care and protection, and against sexual offences;

(d) appropriate facilities for education of the child to be arranged so as
to ensure that there is no discontinuity from his lessons in school
and no child shall be allowed to work consecutively for more than
twenty-seven days;

ec (e) one responsible person be appointed for maximum of five children
हु for the production or event, so as to ensure the protection, care and
best interest of the child;

(f) at least twenty per cent, of the income earned by the child from
the production or event to be directly deposited in a fixed deposit
account in a nationalised bank in the name of the child which may
be credited to the child on attaining majority; and

(g) no child shall be made to participate in any audio visual and sports
activity including informal entertainment activity against his will
and consent. हु

1. Ins. by G.S.R. 543(E), dated 2nd June, 2017 (w.e.f. 2-6-2017).

<!-- page 5 -->

a  खखखयरय<<-रः्ः्ःझखः Fe
I
4 I
Rule 8] The Chile’ and Adolescent Labour (Prohibition and 23 |
Regulation) Rules, 1988 नि
|| (2) For the purposes of clause (c) to the Explanation to sub-section (2) of
i section 3, the expression “such other activity” contained therein, shall mean— i
(i) any activity where the child himself is participating in a sports if
competition or event or training for such sports competition or k
event; 1
(ii) cinema and documentary shows on television including reality दि
shows, quiz shows, talent shows; radio and any programme in or i
any other media; Hig
(iii) drama serials; f
(iv) participation as anchor of a show or events; and I
(v) any other artistic performancéS which the Central Government permits |!
in individual cases, which shall not include street performance for कि
monetary gain.] ae रे
१ 3. Term of office of the members of the Committee.—(1) The term of office =
of the members of the Committee shall be one year from the date on which their u
appointment is notified in the Official Gazette: [
Provided that the Central Government may extend the term of office of the |
member of the Committee for a maximum period of two years: I
हे Provided further that ‘the member shall, notwithstanding the expiration of a
his term, continue to hold office until his successor enters upon his office. |;
हे (2) The members appointed under sub-rule (1) shall be eligible for re- es
न appointment. ae
4. Secretary to the Committee.—The Central Government may appoint an at
‘ officer not below the rank of an Under Secretary to the Government of India as FH
; Secretary of the Committee. न
| 5. Allowances to non-official members.—The non-official members and कु
हु | Chairman of the Committee shall be paid such fees and allowances as may be |
i admissible to the officers of the Central Government drawing a pay of rupees |
: four thousand and five hundred or above. i
j 6. Resignation.—(1) A member may resign his office ty writing under his fi
7 hand addressed to the Chairman. |
| 7 (2) The Chairman may resign his office by writing under his hand addressed }
to the Central Government. हर
(3) The resignation referred to in sub-rule (1) and sub-rule (2) shall take ।
प्र + ¢effect from the date of its acceptance or on the expiry of thirty days from the
1 date of receipt of such resignation, whichever is earlier, by the Chairman or the |
, Central Government, as the case may be. |
| 7. Removal of Chairman or member of the Committee——The Central |
{ Government may remove the Chairman or any member of the Committee at "
any time before the expiry of the term of office after giving him a reasonable
5 opportunity of showing cause against the proposed removal.
| 8. Cessation of membership.—If a member—
1 (a) is absent without leave of the Chairman for three or more consecutive
4 meetings of the Committee; or

<!-- page 6 -->

,
4
24 The Child and Adolescent Labour (Prohibition and [Rule 8
Regulation) Rules, 1988
(b) is declared to be of unsound mind by a competent court; or
(c) is or has been convicted of any offence which, in the opinion of the
Central Government, involves moral turpitude; or
(d) is, or at any time, has been adjudicated insolvent or has suspended
his debts or has compounded with his creditors,
shall cease to be member of the Committee,

9. Filling up of casual vacancies.—In case a member resigns his office under
tule 6 or ceases to be member under tule 8, the casual vacancy thus caused shall
be filled up by the Central Government and the member so appointed shall hold
office for the unexpired portion of the term of his predecessor.

10. Time and place of meetings.—The Committee shall meet at such times
and places as the Chairman may fix in this behalf. ae है

11. Notice of meetings.— The Secretary to the Committee shall give at least
seven days’ notice to every member of the Committee of the time and place
fixed for each meeting alongwith the list of business to be transacted at the
said meeting.

12. Presiding at meetings.—The Chairman shall preside at every meeting of
the Committee at which he is present, if, however, the Chairman is unable to
attend a meeting, any member elected by the members present among themselves
shall preside at the meeting.

13. Quorum.—No business shall be transacted at a meeting of the Committee
unless at least three members of the Committee other than the Chairman and
the Secretary are present:

Provided that at any meeting in which less than three of the total members"
are present, the Chairman may adjourn the meeting to a date as he deems fit and
inform the members present and notify other members that the business of the

- scheduled meeting shall be disposed of at the adjourned meeting irrespective of
the quorum and it shall be lawful to dispose of the business at such adjourned
meeting irrespective of the number of members attending the meeting.

14. Decision by majority.—All questions considered at a meeting of the
Committee shall be decided by a majority of votes of the members present and
voting and in the event of equality of votes, the Chairman, or in the absence of
Chairman, the member presiding at the meeting, as the case may be, shall have
a second or casting vote.

. 15. Sub-Committees.—The Committee may constitute one or more Sub-
°y Committees, whether consisting only of members of the Committee or partly
of members of the Committee and partly of other persons as it thinks fit, for
such purposes, as it may decide and any Sub-Committee so constituted shall
discharge such functions as may be delegated to it by the Committee.
4[15A. Hours of work.—Subject to the provisions of section 7, no adolescent
shall be required or permitted to work in an establishment in excess of such
number of hours of work as is permissible under the law for the time being in
| force regulating the hours of work of the adolescent in such establishment.]
1. Ins. by G.S.R. 543(E), dated 2nd June, 2017 (w.e.f. 2-6-2017).

<!-- page 7 -->

Re
। । नि
4 | Rule 17] The Child and Adolescent Labour (Prohibition and 25 i
i Regulation) Rules, 1988 i
| 16. Register to be maintained under section 11 of the Act.—(1) Every i
| occupier of an establishment shall maintain a register in respect of '[adolescents] I
employed or permitted to work, in Form A. E
j (2) The register shall be maintained on a yearly basis but shall be retained i
1 by the employer for a period of three years after the date of the last entry made ts
i therein. Ei
| °[16A. Payment of amount to child or adolescent from and out of Child and
Adolescent Labour Rehabilitation Fund.—(1) The amount credited, deposited हे
or invested, as the case may be, under sub-section (3) of section 14B to the Child 4
and Adolescent Labour Rehabilitation Fund and the interest accrued on it, shall i
be paid to the child or adolescent in whose favour such amount is credited in a
the following manner, namely:— oy Fi
(i) the Inspector or the nodal officer having jurisdiction shall, under > i
his supervision, ensure that an account of such child or adolescent B
i is opened in a nationalised bank and inform the bank in which the E
amount of the Fund is deposited or, as the case may be, to the officer i
responsible to invest the amount of the Fund under sub-section (3) Fd
of section 14B; I
i (ii) the interest accrued on the proportionate amount of the Fund in My
favour of the child or adolescent shall be transferred every six 3
: months to the account of the child or adolescent, as the case may Is
धर be, by the bank or officer responsible to invest the amount under i
4 information to the Inspector; ry
i (iii) when the concerned child or adolescent completes the age of F
i eighteen years, then, as soon as may be possible forthwith or within e
| a period of three months, the total amount credited, deposited or |
invested in favour of the child along with interest accrued thereon ta
j remaining in the bank or remaining so invested under sub-section i
(3) of section 14B, shall be transferred to the said bank account of हि
य child or adolescent, as the case may be; and &
4 (iv) the Inspector shall prepare a report of the amount transferred under ।
2 clause (ii) and clause (iii) with particulars of the concerned child or I
| | adolescent sufficient to identify him and send a copy of the report
1 annually to the Central Government for Information.
(2) Any amount recovered by way of fine or for composition of offences in
pursuance of an order or judgement of a Court in favour of a child or adolescent |
x for the contravention of the provisions of the Act, shall also be deposited in the
Fund and shall be spent in accordance with such order or judgement.]
| 3[17. Certificate of age—(1) Where an Inspector has an apprehension that
any adolescent has been employed in any of the occupation or processes in
a 1. Subs. by G.S.R. 543(E), dated 2nd June, 2017, for "children" (w.e.f. 2-6-2017).
| 2. Ins. by G.S.R. 543(E), dated 2nd June, 2017 (w.ef. 2-6-2017).
3. Subs. by G.S.R. 543(E), dated 2nd June, 2017, for rule 17 (w.e-f. 2-6-2017). Rule 17, before
* substitution, stood as under:
Contd. on next page

<!-- page 8 -->

a
7 |
26 The Child and Adolescent Labour (Prohibition and [Rule 17 |
की04०/4॥/०7) 1095, 1988
which he is prohibited to be employed under section 3A of the Act, he may
require the employer of such adolescent to produce to the Inspector a certificate
of age from the appropriate medical authority.
(2) The appropriate medical authority shall, while examining an adolescent
for issuing the certificate of age under sub-rule (1), take into account—

(i) the Aadhar card of the adolescent, and in the absence thereof;

(ii) the date of birth certificate from school or the matriculation or
equivalent certificate from the concerned examination Board of the
adolescent, if available, and in the absence thereof;

(iii) the birth certificate of the adolescent given by a corporation or a
municipal authority or a Panchayat;

and only in the absence of any ofthe methods specified in clauses (i) to (iii),
the age shall be determined by such medical authority through an ossification
test or any other latest medical age determination test. a

(3) The ossification test or any other latest medical age determination test shall
be conducted on the order of the appropriate authority of the rank of Additional
Labour Commissioner, as may be specified by the Central Government in this
behalf, and such determination shall be completed within fifteen days from the
date of such order:

1 (4) The certificate of age referred to in sub-rule (1) shall be issued in
Form B.

(5) The charges payable to the medical authority for the issue of the
certificate of age shall be same as specified by the Central Government or the
State Government, as the case may be, for their Medical Boards.

(6) The charges payable to the medical authority shall be borne by the
employer of the adolescent whose age is determined under this rule.

7 Explanation —For the purposes of this rule—

(i) “medical authority” means a Government medical doctor not
below the rank of an Assistant Surgeon of a District or a regular
doctor of equivalent rank employed in Employees’ State Insurance
dispensaries or hospitals;

Contd. from previous page हि

"17. Certificate of age-—(1) All young persons in employment in any of the occupations

set-forth in Part A of the Schedule or in any workshop wherein any of the processes setforth
in Part B of the Schedule is carried on, shall produce a certificate of age from the appropriate
सर medical authority, whenever required to do so by an Inspector. fi |
4 (2) The certificate of age referred to in sub-rule (1) shall be issued in
Form B.
(3) The charges payable to the medical authority for the issue of such certificate shall be
the same as prescribed by the State Government or the Central Government, as the case may
be, for their respective Medical Boards.
(4) The charges payable to the medical authority shall be borne by the employer of the
| young person whose age is under question.
\ Explanation —For the purposes of sub-rule (1), the appropriate “Medical Authority” shall
: be Government medical doctor not below the rank of an Assistant Surgeon of a District or
a regular doctor of equivalent rank employed in Employees’ State Insurance dispensaries or
hospitals.”. |

<!-- page 9 -->

SN . |
i,
‘4 Rule 17C] The Child and Adolescent Labour (Prohibition and 27 Hi
Regulation) Rules, 1988 ib
(ii) “adolescent” means an adolescent as defined in clause (i) of section | |
2 of the Act. i
417A. Persons who may file complaint—Any person who may file a
complaint under the Act for commission of any offence include school teachers |
and representatives from school management committee, child protection ! I
committee, Panchayat or Municipality, who shall be sensitised to file complaint, iy es
in the event that any of students in their respective schools is employed in HF |
contravention to the provisions of the Act.] te
4117B. Manner of compounding offences.—(1) An accused person,— i
(i) who commits an offence for the first time under sub-section (3) of uh |
section 14; or Me
(ii) who being parent or a guardian, commits an offence under the said i
section, जा he fg
may file an application to the District Magistrate having jurisdiction for I
compounding the offence under sub-section (1) of section 14D. | |
(2) The District Magistrate shall after hearing the accused person and i
the Inspector concerned, on an application filed under sub-rule (1), dispose He |
of such application, and if the application is allowed, issue the certificate of lk |
compounding, subject to— He
(i) the payment of a sum of fifty per cent; of the maximum fine provided it | |
for such offence within a period to be specified in such certificate; i
or fi fe
(ii) the payment of an additional sum of twenty-five per cent; of it |
the maximum fine provided for such offence together with the i i
compounding amount specified under clause (i), if the accused a
person fails to pay the compounding amount under the said clause | |
within the specified period, and such delayed payment shall be te |
’ made within a further period as may be specified by the District |
Magistrate, which shall not exceed the period specified in that 1 |
clause. i
(3) The compounding amount shall be paid by the accused person to the ff
Central Government. |! |
(4) If the accused person fails to pay the compounding amount under sub- al da
rule (2), then, the proceeding shall be continued as specified under sub-section ie
(2) of section 14D.] :
1[17C. Duties of District Magistrate—(1) The District Magistrate shall— tk |
S ही (i) specify such officers subordinate to him, as he considers necessary, ne |
to be called nodal officers, who shall exercise all or any of the |
powers and perform all or any of the duties of the District Magistrate ih
conferred and imposed on him by the Central Government under ity
section 17A: "
(ii) assign such powers and duties, as he thinks appropriate, to a nodal F
officer to be exercised and performed by him within his local limits if
of jurisdiction as subordinate officer; i
1. Ins. by GSR. 543(B), dated 2nd June, 2017 (wef, 2-6-2017),

<!-- page 10 -->

IES “seta,
a
28 The Child and Adolescent Labour (Prohibition and [Rule 17C
Regulation) Rules, 1988
(iii) preside over as chairperson of the Task_Force-to be formed in a

district consisting of— दा .

(a) Inspector appointed under section 17 for the purposes of his
local limits of jurisdiction;

(b) Superintendent of Police for the purposes of his local limits of
jurisdiction;

(c) Additional District Magistrate for the purposes of his local limits
of jurisdiction;

(9) nodal officer referred to under clause (i) for the purposes of his
local-limits Of jurisdiction;

(e) Assistant Labour Commissioner (Central) for the purposes of his
local limits of jurisdiction;

(0) two representatives each from a voluntary organisation involved
in rescue and rehabilitation of employed children ‘in the district
on rotation basis for a period of two years;

(g) a representative of the District Legal Services Authority to be
nominated by the District Judge;

(h) a member of the District Anti-trafficking Unit;

(i) Chairperson of the Child Welfare Committee of the District;

(j) District Child Protection Officer in the District under the Integrated
Child Protection Scheme of the Ministry of the Government of

है India dealing with women and child development;

(k) District Education Officer;

() any other person nominated by the District Magistrate;

(m) Secretary of the Task Force shall be any of the nodal officers
referred to in clause (i) and nominated by the Chairperson.

हु (2) The Task Force referred to in clause (iii) of sub-rule (1) shall meet at least
once in every month and shall make a comprehensive action plan for conducting,
the rescue operation, taking into account the time available, point of raid in
accordance with the law for the time being in force, confidentiality of the plan,
protection of victims and witnesses and the interim relief, in accordance with the
guidelines for rescue and repatriation issued by the Central Government from
time to time; and the Task Force shall also cause to upload the minutes of such

meeting on the portal created for such purpose by the Central Government.
1 (3) In addition to the duties referred to in sub-rule (1), the District Magistrate
we shall ensure through nodal officers that the children and adolescents who are
employed in contravention of the provisions of the Act are rescued and shall

be rehabilitated—
(a) in accordance with the provisions of—

(i) the Juvenile Justice (Care and Protection of Children) Act, 2015
(2 of 2016) and the rules made there under;

(ii) the Bonded Labour System (Abolition) Act, 1976 (19 of 1976);

(iii). the Central Sector Scheme for Rehabilitation of Bonded Labourers,
2016;
