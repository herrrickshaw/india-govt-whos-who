---
doc_id: "90c8aa6e7cb7ffb3"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/416294cad444cabecbd1d7d429b6c0dc.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Promotion/Tramsfer of officers of Central Labour Service- reg (23 oct 2020) (Office Order- 22/20)"
date: "2020-10-23"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5f5eae3d5f30973d"
---

<!-- page 1 -->

No. A-22012/01/2020- CLS.I
Government of India
Ministry of Labour and Employment
Shram Shakti Bhawan, Rafi Marg
New Delhi, dated 23rd October, 2020

OFFICE ORDER No.22/2020
Subject: - Promotion and Transfer/Posting of Central Labour Service Officers
In partial modification of this Ministry's Office Order No. 10/2020 dated 1st June, 2020 on the
above subject, the transfer /posting of following officer of Junior llme Scale(JTS) is ordered with
immediate effect:-

SI
No.
(1)

Name of the Officer
(Shri/Smt)
(2)

Designation and
Present Place of
Posting
(3)

Posting ordered
vide Office
Order dated 1st
June, 2020

ALWC (c), HEF, OF,
Pune

DLWC (C), OF,
Bhusawal,
Maharashtra
(On promotion
to STS)

Revised Place of
Posting

(5)

(4)
1.

Shri Sagar Pradhan

RLC (C), Vododra

2.

The above officer is not entitled for TTA/Joining Time as per relevant rules.

3.
The concerned Organization is requested to relieve the above mentioned officer immediately
to enable him to join his place of new posting. The officer concerned is directed to submit his joining
report to this Ministry through the respective organization of his posting.

4.

This issues with the approval of the Competent Authority.

~
(S ~

Deputy Secretary
Tele No:- 23766904
Distribution :-

1. The officer concerned
2.
3.
4.
5.
6.
7.

The Estts/Organization Concerned
CLC (C), Ministry of Labour and Employment, New Delhi
DGLW, Ministry of Labour and Employment, New Delhi
CLS - II (Vig.) Section, Ministry of Labour and Employment
Personal file of the Officers Concerned/Office Order bundle/spare copies
IT Cell, MoLE - for uploading the office order on MoLE's website
