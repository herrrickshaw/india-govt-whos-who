---
doc_id: "90fe5d5ebf4c6bea"
source_url: "https://www.dpiit.gov.in/static/uploads/2026/03/d72416aac71f8c22cf68e990bc3e4e44.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Non-Official Member order dated 15.03.2026"
date: "2026-03-23"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d79f28cccba53380"
---

<!-- page 1 -->

F.No. P-65016/2/2019-Internal Trade
URI UHR / Govornment of India
वाणिज्य एवं उद्योग HATA / Minist Ser Commorco and Industry
उद्योग संवर्धन और आत॑रिफ व्यापार विभाग
Departmont for Promotion of Industry & Intornal Trade
Vanijya Bhawan, New Delhi
Dated; 15" March, 2026
ORDER
In pursuance of the Department for Promotion of Industry and Internal Trade Notification
of even number dated 26" July, 2019 and the Notification No. of even number dated 17%
December 2019, the following five persons representing Trade Association/Sate/Union Territory
are nominated as non-official Members of the NTWB for a period of two years or until further
orders, whichever is earlier, with effect from the date of issue of this order:
aa
Sh. Alok Tibrewala State : West Bengal
2 5 . tade Assn, : Federation of All India Distributor
ISh. Krishna Chigullapally Associations (FAIDA)
3 IShri R.K. Gaur tade Assn.: Federation of All India Vyapar
Mandal (FAIVM)
Shri Raj Kumar Khandelwal State: Odisha
5 (Sh. Rajeev Aneja State: Punjab
2. Further, in partial modification of the Order of even number dated 21% January 2026, the
following will cease to be members of the NTWB with immediate effect :
1. [Shri Sushil Poddar est Bengal
2. Shri Pritesh Shah Maharashtra
3. The Board shall meet at least once in every quarter. Quorum of the meeting shall be one-
third of the total Members of the Board.
4. Travelling/dearness Allowances to the Members of the Board others than Official
members shall be regulated as per M/o Finance, department of Expenditure’s OM No.
19047/1/2016-E-IV dated 14"" September, 2017. Sor 6
Yee
(Thingom Lalit\Kumar Singh)
Deputy Secretary to the Government of India
1. Chairperson and Non-Official Members. NTWR

<!-- page 2 -->

3. Secretary, Department of Financial Services

4. Secretary, Department of Agriculture Cooperation and Farmer Welfare
5. Secretary, Ministry of Housing and Urban Affairs

6. Secretary, Department of Revenue

7. Secretary, Ministry of Labour and Employment

8. Secretary, Ministry of Micro, Small and Medium Enterprises
9. Secretary, Ministry of Electronics and Information Technology
10. CEO, NITI Aayog

11. Secretary, DPIIT

12. Finance Wing, DPIIT.

13. Vigilance Desk, DPIIT.

14. PS to CIM.

15. PS to JS (S).

16. Director, E-IIl Section, DPIIT.

17. Guard File.
