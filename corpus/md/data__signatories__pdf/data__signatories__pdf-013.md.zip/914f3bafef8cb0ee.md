---
doc_id: "914f3bafef8cb0ee"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/09/3b806eb03631ff3ec9db4d20c980332a.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order No. 41/2008"
date: "2008-05-23"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0e98c5caeac312ee"
---

<!-- page 1 -->

F.No.A.60011/37/2008-Admn.I (LA)
Government of India
- Ministry of Law and Justice
Department of Legal Affairs
Eat
Shastri Bhawan New Delhi,
Dated the) “May, 2008
: ORDER NO.41/2008
Shri B.S. Meena, Joint Secretary & Legal Adviser, posted as
Arbitrator in the Department of Public Enterprises, is retiring
from Govt, service on superannuation on 31.5.2008. Accordingly,
as per the orders of the Competent Authority, Dr. Santokh Singh,
Joint Secretary & Legal Adviser will hold the additional charge of
Arbitrator in the Department of Public Enterprises in addition to
his normal duties with effect from 1.6.2008 until further orders.
2. This issues with the approval of Law Secretary.
or /
(Sandeep Saxena)
Section Officer
> Shri B.S. Meena, Joint Secretary & Legal Adviser;
>» Dr. Santokh Singh, Joint Secretary & Legal Adviser;
> The Secretary, Department of Public Enterprises, CGO
Complex, New Delhi; :
> The Secretary, Department of Telecommunication;
> PS to MLJ/PS to MSLJ/PPS to Law Secretary/PS to AS/PA to
JS(A)/PA to Director (Estt.)/PA to DS(A)/US(G)/ US(J)/US(A);
> Admn.II/IV(LA) Section/Cash (LA) Section/Vig. Unit/CR
Asstt. / Personal File;
> Rajbhasha Anubhag, Department of Legal Affairs, with a
request to translate this ‘Order’ into Hindi; and
> NIC, D/o Legal Affairs with the request to hoist this on this
Ministry’s Website.
