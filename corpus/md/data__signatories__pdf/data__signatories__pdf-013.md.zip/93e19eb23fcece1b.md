---
doc_id: "93e19eb23fcece1b"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/09/394fae28c3574912912beba92a468dc9.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "O.M. No. W.11037/48/2024-RD dated 02.4.2024 regarding inclusion of four (04) Diseases under Para 6.2 of National Policy lor Rare"
date: "2024-04-02"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5cf99e29865e79c6"
---

<!-- page 1 -->

%,;;8,',JJ*?rsrfl'&3

Ministrv oi Health & Fqpily Wel{are
oijpdi'im'ent oLnea[[S t#iii, werf are

*,, *

or?i!,)P;
"F

i R l'? # ,l?
Dated: 02.04.2024

OFFICE MEMORANDUM

under Para 6'2 or
ftX?,,f,"ji Jt,,$igfl.Bt,Ff,l8"3i|.f,gf,?,i,i82,g','B8orizarion

ffi
d,,ltift,iqlnilff
Technical
Committee tor F .d:sttu:ffi:#iii"=?.itiffi "g"trJi'":,rtrtr
urlder
[p-oiIeo-.sLientrtiCdata, have been includ'ed

sEiu"rcli5'rdiii.cHSr otleo"iii
in'ejibli,irji',fs6u"piil ,iiiolije'niToeniiti-eo-aiio-caiegorized bv experts based on
their clinical experlence:

Group 1: Disorders amenable to one-time curative treatment:

al
bi
ct

ConoenitalHvperinsulinemicHypoglycemia(CHl)
FamllialHomozygousHypercholesterolemia
Mannosidosis
sex Development due to 5 atpha reductase deticiency,
p'artial androgen insensitivity syndrome

iv'bi;rEi;t

;i

2.
The inancial assistance to the patients sufferrnq rom the.a!qv-e mentioned
'12re oiirjisijl'iifiill; 6r;vi"de[ is ilei ihJ flrovisrofls ot tne rue-Rq, 202'1 and
io-iit Centles ol Excellence (CoEs) vide this
hiiii..-ri'iii
f

f

"",ii-JrcjceOuleiisliriO
dated 1 1 .08.2022.
Ministry's letter

3.
4.

This comes into effect lrom the date ot issue o{ this otfice Memorandum.
This issues wilh the approval of the Secretary (Health & FW)'
Signed by
Swarnendu Singha

,.ffi;$ffi-2$ffi;l{fr8:20

Under Secretary to the Gwernm:AglBB,i
Email : swarnendu.singha@nic.in

To,
1. The Secretary, Department of Biotechnology, Ministry ol Science and
Technoloov.
Governm6ht of lndia;
Alfairs, Government of lndia:
z ttre Seiretarv. Ministrv of Corporate
S
S;ai;i;i{,. Deoartinentof 'Health Resedrch/Director General. lndian Council
lor
Medical Research. New Delhi;
4. ThtseCrettrv, Department ol Pharmaceuticals. Shastri Bhawan. lew Delhi :
5. The Secretarl, Debartment ol Promotion of lndustry and lnternal Trade. Udyog
Bhawan, New Delhi;'
O. Tne Seireiaiy, Department of Revenue, Ministry of Finance, Government oi

ili;

lndra:
7. The Chairman. National Pharmaceutical Pricinq Authoritv. 3 rd /5th Floor. YMCA
Cultural, Centre Building 1. Jai Singh Road, NewDelhi;

<!-- page 2 -->

8 The Druos Controller General ol lndia, FDA Bhawan,-New Delhi, ^.
g Tne Dire."ctor General. Directorate General ol Health Servtces ano L,nalrman oI
erCno. Niiman Bhawan, New Delhi:
ici laliti.iiiiith'eiSliietdrie'slprtnCipat Secretaries/Commissioner (Health) of all
Slate Governments/UT Administration
iil'di66i<iiitn cndiqe. centres of Excellence (as per list attached):
12. The Nodal OflicEr, all the 12 CoEs (as per list attached).

Copy for information to:
1. PPS to Secretary (H);
2. PPS to AS (Rare Diseases):
3. lF Division. MoHFW:
I. Fps io'oiibCioi ieuhl & Addl. DDG, Dte.GHS, Nirman Bhawan, New Delhi.

(Swarnendu Sinqha)
Under Secretary lo the Government of Indih

list ol 12 (twelvq) Centres ol Excellence

of Genetics, Department of Pediatrics.
mail: neerja l 7@gmail.com,

Professor. Divrsion of Genetics.
Department of Pediatrics, MAMC, New Delhi
Email: meenakshibothra@gmail.com

lnstitute of Medical Sciences.

Department ol Medical Genetics, San.jay

<!-- page 3 -->

4

5

6

7

9

Postgraduate lnstitute of Medical Scrences.
Lucknow, lndia-2260 1 4
Phone : 9839220 1 99, 91 522-2494325
E-mail : shubharaophadke@gmail.com
Post craduate lnstitute of
Dr. Flanj,l Pal Singh Bhogal, Assistant
Medical Education and
Professor.
Flesearch, Chandigarh
Deputy Medical Superintendent,
Department of Hospilal Administration.
Conracl No. 7087002089
Email: majorbhogall 984@gmail.com
Centre tor DNA Fingerprinting
Dr. Ashwin Dalal,
& Diagnostics with Nizam's
Head, Diagnostics Division
lnstitute of Medical Sciences,
Email: ashwindalal@gmail.com
Hyderabad
Contact No. 040 -zt 21 61 47
King Edward Medical
Dr. Akash Shukla,
Hospital, Mumbai
Mobile No. 9869256376
Email id: drakashshukla@yahoo.com
lnstttute of Post-Graduale
Proi Suchanda Mukherlee, HoDIeonelology
Medical Education and
Contact No.9831485596
Research, Kolkata
Email: drsmukherjeeT0@gmail.com
lahlar f^r lDr. Sanjeeva GN,
enetics(CHG) with lndira
Associate Professor,
andhi Hospital, Bengaluru
lndira Gandhi lnstitute of Child Heatth.
Bengaluru
Mob:9945657034
Email: saniu.gn2g@gmail.com
lnslitute ol Child Heallh
Dr. Anuradha.
Hospital for Children (lCH & CH), M.D,DCH, phd.
Chennai
Mob: 9444340166
Email: anuradha.iit@gmail.com

and

10 All lndia lnstitute of Medicat Dr. Kutdeep Singh, professor & Head.
Sciences (AllMS), Jodhpur Department o{ Pediatrics,
AllMS, Jodhpur.
Basni lndustrial Area, phase-ll,
Jodhpur, Rajasthan - 342005.
Contact: 0291 -28331 49/ 9003996940

i

1 sree Avittam rhirunat Hospitat S=rl"li1!f9:ff,""'i3$.'"," proressor ot
(SAT), Government

Medical Pediatrics & Geneticist, SAT, Government

corese, rhiruvananthapuram yffl:i] g"Ji:j;h@smair.com)
Phone number : 9349930828

12 Atl lndia lnstitute ol MedicalProf (Dr.) Ajay Singh, Executive Director
Sciences (AllMS), Bhopal
AttMS, Saket Nagar, Bhopal - 462020.
.(Email: director@aiimsbhopal.edu.in)
Phone number: 07 55-267 2317
