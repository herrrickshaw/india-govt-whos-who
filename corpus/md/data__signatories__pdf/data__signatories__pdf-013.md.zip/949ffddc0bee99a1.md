---
doc_id: "949ffddc0bee99a1"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_6a210b09bb4b60.08236532.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Notification- Appointment by Promotion from State Forest Service to Indian Forest Service of Gujarat cadre of the Select List the year 2025, notification dated 03-06-2026"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3063c4ad45a063d4"
---

<!-- page 1 -->

(To be published in Part I Section 2 of the Gazette of India)
No.17013/02/2026-1 FS-11

m«r 'ti'lCfil'l I Government of India
q:efjq'(vl, qif' ~ \51<'ictl'Q.,, q~qd01 Ji'll<'l<Q

Ministry of Environment, Forest & Climate Change

Indira Paryavaran Bhawan,
6th Floor, Prithvi Block,
Jor Bagh, Ali Ganj, New Delhi-110003
Dated the 03rd June, 2026
NOTIFICATION

In exercise of the provisions conferred by Rule 8 of the IFS
(Recruitment) Rules, 1966, read with sub-regulations (1) of Regulation 9 of the IFS
(Appointment by Promotion) Regulation, 1966, the President is pleased to appoint
with immediate effect the following Thirty Seven (37) Officers of the State Forest
Service of Gujarat Cadre to the Indian Forest Service on the basis of inclusion of their
name in Select List-2025 by the Selection Committee in its meeting held
on 23.03.2026, on probation until further order and to allocate them to Gujarat Cadre
of Indian Forest Service under sub-rule (1) of Rule 5 of the Indian Forest Service
(Cadre) Rules, 1966:
Select List 2025
Date of Birth
S.No. Name of the officer (Shri/Ms.)
31.01.1988
1. Shreyaskumar Dineshbhai Patel
Jayankumar
Raiendrabhai
Patel
05.01.1984
2.
19.09.1978
3. Dineshkumar Nathubhai Rabari
29.07.1982
4. Raideep Narendrasinh Jhala
Renuka
Jagdishbhai
Desai
12.01.1986
5.
05.08.1985
6. Rushiraj Sunilkumar Puwar
21.09.1987
7. Miteshkumar Hasmukhbhai Patel
30.12.1986
Yuvraisinh
Shaktisinh
Jhala
8.
22.09.1985
9. Dhananjaykumar Kanaiyalal Sadhu
30.08.1987
10. Rupak Bharatbhai Solanki
10.09.1986
11. Nevilkumar Virsanqbhai Chaudharv
28.09.1982
12. Govindsinh Dilavarsinh Sarvaiva
10.12.1985
13. YoQeshkumar Amrutbhai Desai
25.01.1984
14. Tushar Bhailalbhai Patel
14.01.1987
15. Ravirajsinh Vaiubha Rathod
04.02.1987
16. Amitkumar Bhavanishankar Navak
02.12.1985
17. Harsh Jaswantlal Thakkar
19.08.1985
18. Pareshkumar Jivrambhai Chaudhari
19. Hareshkumar Vajesanqbhai Makawana 21.11.1978
01.06.1980
20. Bharatbhai Motibhai Patel
14.11 .1974
21. Namrata Dahvabhai Italian
11.01 .1983
22. Nikunjkumar Jamsinh Parmar
11.05.1979
23. Riteshkumar Prahladbhai Gelot
28.01.1983
24. Vishnukumar Meqharaibhai Desai

<!-- page 2 -->

25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.
37.

Dhavalkumar Fattesinh Gadhavi
Gaurav Natvarlal Prajapati
Ushma Dineshkumar Nanavati
Minal Deepakkumar Jani
Bindu Navan Patel
Urvashibahen lshwarbhai Prajapati
Radhika Bhimajibhai Parsana
Vinodkumar Ramanbhai Damor
Chandreshkumar Mohanlal Shanadre
Brijeshkumar Devsingbhai Chaudhari
Bhavnabahen Baldevbhai Desai
Mahendrasinh RaisinQbhai Rathwa
Vibhaben Nayangiri Goswami

07.07.1987
21.08.1986
09.05.1986
26.08.1987
28.09.1983
12.07.1976
16.04.1987
22.10.1978
30.08.1977
11.11.1981
20.06.1984
13.11.1979
13.04.1986

The Select List of 2025 will be subject to the outcome of the SLP (C) No.
6521/2021 filed by Vijaybhaimadhubhai Chaudhary & Ors. Versus Gujarat Public
Service Commission & Ors. before the Hon'ble Supreme Court of India.

\:),_§;.yo,h
ob\

~ o~
(Prem Prakash Maurya)
Under Secretary to the Government of India
Tele: 011-20819192
To,
The Manager,
Government of India Press,
Minto Road, New Delhi.
Copy to:
1.The Chief Secretary, Government of Gujarat, Gandhinagar.
2.The Principal Secretary (Forests), Government of Gujarat, Gandhinagar. The
proposal for year of allotment of the officer may be sent to this Ministry for further
necessary action in prescribed proforma (Enclosed).
3. The Principal Chief Conservator of Forests (HoFF), Government of Gujarat,
Gandhinagar
4. The Secretary, Union Public Service Commission, New Delhi.
5.0fficer concerned (through the Government
6. Hindi Section for Hindi translation of Notification.
7. Guard file/Website copy.

of

Gujarat,

Gandhinagar)
