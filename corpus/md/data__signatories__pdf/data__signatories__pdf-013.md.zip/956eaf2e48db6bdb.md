---
doc_id: "956eaf2e48db6bdb"
source_url: "https://www.dot.gov.in/static/uploads/2026/03/eed10991edcbc0a6ba4cd375c6415b49.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Extension of additional charge of the post of Director (Finance), ITI Ltd"
date: "2026-03-20"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "64260bfbad260261"
---

<!-- page 1 -->

No. E-14-1/2024-PSA-Part(1)
Government of India
Ministry of Communications
Department of Telecommunications
20, Ashoka Road,
Sanchar Bhawan, New Delhi — 110 001
Dated 26° March, 2026
ORDER
In continuation to this Department's order of even number dated
14.10.2025, it is conveyed that the Appointments Committee of the Cabinet has
approved the proposal of the Department of Telecommunications for extension of
additional charge of the post of Director (Finance), IT! Ltd. assigned to Shri
Ramana Babu C V, Director (Marketing), ITI Ltd for a further period of six months
w.e.f. 15.04.2026, or till assumption of charge of the post by the regular incumbent,
or until further orders, whichever is the earliest.
2. During the period of holding additional charge, Shri Ramana Babu C V will
not be entitled to any additional remuneration.
(Auth:- DoPT (ACC) communication No. 24/08/2019-EO (ACC) dated
17.03.2026)
isi
mat
(Amit Kundan)
Under Secretary to the Govt. of India
Tel. 2303 6884
Copy to:-
1. Sh. Ramana Babu C V, Director (Finance), !T! Ltd., IT| Bhawan, Dooravani
Nagar, Bangaluru-560016.
2. O/o the Establishment Officer & Additional Secretary, ACC, DoP&T, New
Delhi-01.
3. The Secretary, PESB, CGO Complex, Lodi Road, New Delhi-03
4. PS to Hon’ble MoC, Sanchar Bhawan, New Delhi.
5. PS to Hon'ble MoSC, Sanchar Bhawan, New Delhi.
6. PSO to Secretary (T), DoT, Sanchar Bhawan, New Delhi.
7. PPS to All Member(s), Digital Communications Commission, Sanchar
Bhawan, New Delhi.
8. Sr. PPS to Addl. Secretary (T), DoT, Sanchar Bhawan, New Delhi.
9. The Company Secretary, ITI Ltd., Tl Bhawan, Dooravani Nagar, Bengaluru.
10. Sr. PPS/PPS to JS (A), DDG (C&A), DDG (SU), DoT, Sanchar Bhawan, New
Delhi.
11. CMD (s) MTNL/BSNL/BBNL/TCIL.

<!-- page 2 -->

12. Web Administrator for uploading on the website of DoT.
13. Dy. Director (OL), DoT, Sanchar Bhawan, New Delhi with the request to
provide Hindi Translation of the order.

14. Office order/Guard file.
Digitally signed by
Amit Kundan
Date: 20-03-2026
10:41:02
