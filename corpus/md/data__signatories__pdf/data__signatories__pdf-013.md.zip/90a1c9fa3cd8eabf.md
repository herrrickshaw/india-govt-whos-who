---
doc_id: "90a1c9fa3cd8eabf"
source_url: "https://master-dopt.digifootprint.gov.in/static/uploads/2025/08/12c83d8e0c23f448a5572c787abea544.pdf"
ministry: "Department of Personnel and Training (DoPT)"
title: "Appointment of Chief Information Commissioners in the Central Information Commission - Part 2 (09/04/2018)"
date: "2018-04-09"
pages: 153
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d694363ac2cceef7"
---

<!-- page 1 -->

Disclosure of Information is subject to exemptions•
under Section 8(i)(j) and Section 10(1) of the Ru Act,
2005.

<!-- page 2 -->

Chief Information Commissioner and Information Commissioners in CIC

SLNo.

Name

Date of Birth

Date of
Appointment

Date of
completion
of tenure

Field of
Excellence

I.

ShriR.K. Mathur, Chief
Information Commisioner, AS

25.11.1953

04.01.2016

24.11.2018

Administration

2.

Shri Basant Seth

16.02.1952

01 .03.2012

15.02.2017

Management

12.03.1954

22.11.2013

21.11.2018

Administration

23.09.1952

22.11.2013

22.09.2017

Administration

16.01.1953

22.11.2013

15.01.2018

Administration

01.01.1952

22.11.2013

31 .12.2016

Law

10.11.1956

22.11.2013

21.11.2018

Law

12.01 .1955

11 .06.2015

11.01 .2020

Administration

02.12.1953

25.02.2016

01.12.2018

Administration

Banker
3.

Shri Yashovardhan Azad
PS, M.P.

4.

Shri Sharat Sabharwal
IFS

5.

Ms. Manjula Prasher
I PoS

6.

Shri M.A. Khan Yusufi

us
7.

ShriMadabhushiSridhar
Ac/i aryu/ u
Professor, Law

3.

Shri Sudhir Bhargava
lAS, RJ

9.

ShriAmitava Bhattacharya
lAS

10.

5hri Bimal julka
AS

27.08.1955

25.02.2016

26.08.2020

Administration

1.

Shri Divya Prakash Sinha

26.09.1955

25.02.2016

25.09.2020

Administration

I PS

Vacancies are marked in bold.
Vacancies likely to arise are underlined.

<!-- page 3 -->

Confidential

PRIME MINISTER'S OFFICE
South Block,
New Delhi- 110011
Subject: Appointment of Information Commissioners in
Central Information Commission - reg.
Reference is invited to DOPT's note dated 18.07.2018 at page
21/N of File No. 4/9/20 18 - JR on the subject cited above.
2.

Prime Minister has approved the following:a) The constitution of the Search Committee for selection of Chief
Information Comirnssioner and Information Commissioners
with the following composition:-

ii.
111.

r.
iv.
V.

vi.

Chairman
Cabinet Secretary
Additional Principal Secretary to PM Meiiiber
Merriber
Secretary (PersonneJ
Secretary (I&B)
Member
Member
Secretary (Expenditure)
Dr. Manoj Panda (Director), Institute Member
of Economic Growth, Delhi
University

b) The nomination of Shri Arun Jaitley, Minister as member of
the Committee, headed by Hon'ble PM, to be constituted under
Section 12(3) of RTI Act.
\

3.

DoPT's File No. 4/9/20 18 JR is returned herewith.

(Nandini Paliwal)
Director
Tel. No. 2301 3132

Secretary, Department of Personnel & Training
Dated 13.08.20 18
PMO ID no. 4877064/PMO/2018-ES.2

iJ3(Oi -

<!-- page 4 -->

F. NO. 4/9/2018-lR
Government of India
Ministry of Personnel, Public Grievances and Pensions
(Department of Personnel and Training)
North Block, New Delhi
26th
Dated:
July, 2018
Subject: Appointment of Information Commissioners in the Central Information Commission.
Under the Right to Information Act 2005, the Government of India has constituted the
Central Information Commission which is located in New Delhi. The powers and functions of the
Information Commissioner in the Central Information Commission are as per the RTI Act, 2005.
2.
It is proposed to appoint Information Commissioners in the Central Information
Commission.
3.
The Act provides that the Information Commissioner: (i) shall be a person of eminence in public life with wide knowledge and experience in law,
science and technology, social service, management, journalism, mass-media or
administration and governance.
(ii) shall not be a Member of Parliament or Member of the Legislature of any State or Union
Territory, as the case may be, or hold any other office of profit or connected with any
political party or carrying on any business or pursuing any profession. It is clarified that
cessation/termination of holding of office of profit, pursuing any profession or carrying
any business is a condition precedent to the appointment of a person as Information
Commissioner.
4.

Persons who have attained the age of 65 years shall not be eligible for appointment.

The salary, allowances and other terms and conditions of service of the Information
5.
Commissioners shall be as may be specified at the time of appointment of the selected
candidate/s.
Persons fulfilling the criteria and interested for appointment to the post of Information
6.
Commissioner may send their particulars in the enclosed proforma, by post, to Under Secretary
(RTl), Department of Personnel and Training, North Block, New Delhi or through e-mail to usrti31st August, 2018. Persons who are
15t
August, 2018 and
dopt@nic.in so as to reach between
serving under the State/Central Government or any other Organization, should send their
particulars through proper channel (administrative Ministry/Department/State/UTs).
\J
(Varsha Sinha)
Director (IR)
Tel: 23092755
Note:
1. Persons who may have applied earlier in response to advertisement dated 02.09.2016 are
requested to apply afresh, if eligible.
2. RTI Act, 2005 and Rules thereunder may be referred to by intending applicants for general
familiarization, as could be appropriate.

<!-- page 5 -->

Proforma for sending particulars for consideration for the post of Information Commissioner in the
Central Information Commission

Please affix the
latest passport
size photograph

1. Name
2. Date of Birth
3. Present Address
4. Contact No.
a)

Telephone (along with STD code)

b)

Mobile

c)

Fax

5. E-mail Address
6. Educational Qualification
7. Area of Eminence
8. Present Occupation
9. Achievements/Work Experience
(As per Annexure)

Date:
Place:

Signature:
Name:

<!-- page 6 -->

Annexure
Details of Achievements/Work Experience in respect of candidates applying for the post of
Information Commissioner

Sr.
No.

2

3

4

5

Post

Organisation

Period
From

Details of achievements/experience
To

(in brief)

<!-- page 7 -->

4/9/20 1 8-3n3Trt
-1T1 4.J4c1k
fIId Tff tTT

JCR

3T frnTT mT)

(cc

26.07.2018

oflch:
:

r1T31r*it1o1i 31Idf411I

-z4o-1 cbl 3iI.

2005

3T9

tafl 3frftJT ci,I T5

-t1i 3-ITZñJT

+1a1J 31V1d 1

1rr

T? -t4ofl

c11I 3t

3TtTr, 2005 * 311-k I
2.

1t.lo-1I 3-1TT

1tla-U 31I*d'

3.

3ffr *

cnw

(I)

Q11o:f 3

4i f{d
j

-dc

c*T

ç

3-fTT fr rr

TRT

t

YTZIT ¶

c

a-

mi
¶31

cIt.I

4) 1HId, -tfl 3-U

Z

3H tTT 4i
TF FfT *lT

-ucii

II

4

. TT

fi

-d

c1) , ¶

41c1

r

1fl
Lcl Ic 11 * el') tJIId

3TZT

ii)

c

2018 -i

I'l.l 3

fEf (-j-fl

c

*usrtidoptnic.in
*c

3ft

c
c1 .4 ç daft.r
ffQ
cIicli 3flT crfTtJi jflT
T5l Tf 3-IIco1 1 3TT * 31 32T,

-iIau) t

e-c) ct1, 3T1T

id.UI/3Th

II(Ld

rr

fi 31I dl

L

i1 65 c

* 3T'T* ¶uj

ci3

*r

9T til

1to1I 3i4cfc1

6.

1RTT

1t

3TT

5.

T-t-Tr lIccb ZT *

*

3fT Et 3TZ1 RTT

ft l I

t

cT

MTT

Iff t1IL'i

(U)

4.

RTr41

T

* c1ILi 5T1T 3T 3T
c

I

ç )1)

(114cb

ct,R 3f

c/1rRJ4/*

f

3Z

T3rzr

-d5c

* 4

ç-

,

3tlT

)

'1_ R - 1
T)

(

1T:23092755
i?i

1.

02.09.2016

1i1i

31Jq,, ,ii 31i

2.
3Tf

J1

T R3 *1

, .jtJuj

*
T

* 31I

1T ,

3T1

31Z1F, 2005 3tt 3T

<!-- page 8 -->

1i

I 3f

la1I 31R?rT

w ft 5rrk

d

v

fT

d

1

oc)aIc1H
chj

1. alld-1
2.
3.

1ITT 1-dI

.

cRT'

6.

(a

-1E5- QdQdl

7.
8.

FEkT[T cQ4c4-1H

9.

qT/r
(3T

3R)

l'kI.1I

/
/

<!-- page 9 -->

0
*L 1UII 3iI ,ct-d

t 31To1 ctrJa

34fcP1TIc4,i

z5J-elc1H

31

1iJT

j

Oci

5qI31

3fE11I
__

1.

2.

3.

4.

5.

cUI

(t

. T

;r

<!-- page 10 -->

Confidential

PRIME MINISTER'S OFFICE
South Block,
New Delhi - 110 011
Subject: Appointment of Chief Information Commissioner in
the Central Information Commission-reg
Reference is invited to DOPT's note dated 12.10.20 18 at page
1-2/N of File No. 4/13/2018-JR on the subject cited above.
2.
The constitution of Search Committee and nomination of
the Union Minister on the Selection Committee, has already been
approved and conveyed to DoPT vide PMO ID no.4877064/PMO/20 18-ES-Il dated 13.08.2018.
3.
In view of above, the undersigned is directed to return the
proposal with a request to go ahead with the advertisement for
the post of Chief Information Commissioner.
4.

DoPT's File No. 4/13/2018-IR, is returned herewith.

(Nandini Paliwal)
Director
Tel. No. 2301 3132

Secretary, Department of Personnel & Training
Dated: 22.10.2018
PMO ID No.L930444/PMO/2018E&S-2

<!-- page 11 -->

2 2-

Confidential

PRIME MINISTER'S OFFICE
South Block,
New Delhi - 110 011
Subject: Appointment of Information Commissioners in
Central Information Commission - reg.
Reference is invited to DOPT's note dated 18.07.20 18 at page
21/N of File No. 4/9/2018 - JR on the subject cited above.
2.

Prime Minister has approved the following:a) The constitution of the Search Committee for selection of Chief
Information Commissioner and Information Commissioners
with the followin.g composition:i.
ii.
iii.
iv.
v.
vi.

Cabinet Secretary
Chairman
Additional Principal Secretary to PM Member
Member
Secretary (Personnel)
Member
Secretary (I&B)
Member
Secretary (Expenditure)
Dr. Manoj Panda (Director), Institute Member
Delhi
Growth,
Economic
of
University

b) The nomination of Shri Arun Jaitley, Minister as member of
the Committee, headed by Hon'ble PM, to be constituted under
Section 12(3) of RTI Act.

k

3.

DoPT's File No. 4/9/20 18 - JR is returned herewith.

(Nandini Paliwal)
Director
Tel. No. 2301 3132
Xrr
V Secretary, Department of Personnel & Training
Dated 13.08.20 18
PMO ID no. 4877064/PMO/2018-ES.2

iJ318(O3 2-

<!-- page 12 -->

Most Immediate
F.No. 4/13/2018-IR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated:3 October, 2018
To
Director
Directorate of Advertising and Visual Publicity
Soochana Bhavan
Phase-IV, CGO Complex
Lodhi Road
New Delhi-110003
(Kind Attn: Mr. Shahid Rahman, Campaign Officer)
Subject: Publishing of Advertisement on 24.10.2018 - regarding
Sir,
I am directed to state that it is intended to fill up the post of the Chief Information
Commissioner in the Central Information Commission. For the purpose, the enclosed
advertisement [English and Hindi] is to be published in four newspapers viz. 'The Hindu' and
'Times of India' (in English); 'Dainik Bhaskar' and 'Hindustan' (In Hindi) and all their editions
in India. The size of the advertisement would be 9x12 cm.
You are requested to take steps to ensure that the advertisement is published
24th October, 2018 in all the above mentioned newspapers and their editions.
positively on

2.

Thereafter a bill may be sent for enabling this Department to make the necessary payment.

Yours faithfully,

(Varsha Sin ha)
Director— IR
Tel.2379 2755
e-mail: dirrti-dopt@nic.in

<!-- page 13 -->

0

GOVERNMENT OF INDIA
MINISTRY OF PERSONNEL, PUBLIC GRIEVANCES AND PENSIONS
(DEPARTMENT OF PERSONNEL AND TRAINING)

Applications are invited for filling up the post of Chief Information
Commissioner in the Central Information Commission, located at
New Delhi.
The details of eligibility conditions and the proforma for sending
particulars for consideration for the post of Chief Information
Commissioner in the Central Information Commission may be
downloaded from the Department of Personnel and Training
website: www.persmin.nic.in The last date for receipt of the
completed applications in the Department is 12.11.2018.

<!-- page 14 -->

rR

*IitI'(

cbIl4, eI' ct fciIqç1 T1T
(ct)I1

a1, i~c

fTF bç

311J-çl

,iic1

;ick '.-Itla1I 3dI
MI*1I

if1

31Icai'l

a-i

'-Iza1i 31Icld

310

I
d-It

1c1 ,.UI 3ft

www.persmin.nic.in

fjvr t1TJr)

3

'-1tJa1I 31dI

FT J1(Il'1

1ci,&ui

SI3a1cu1S

-c11ct,i cl&o1

c1 1tii

ftC1O1I 31Ict- 1

rt
fQ

31ilJ-J 1f

çi
IT '1c*,c1

chlicI, 3

I

12.11.2018

ch'.oI

[t d

clf191JT f1TT 41

'H 1TiJT
I

fiflr

c1

'-ii

<!-- page 15 -->

\k.J\

n—n-

T-c54 nn "ii -Ui'.-, 'usC,i

.

ngaedtswosstcl.bedoheonseals tn-.Mhliltand anti.
-. ly aftet the elections in
tar Pradosh as:well,
Chhatttsgarh Madhya Pra
ssa d
As per .rtipitls doing te desh Mizorath,Rajasthan
r) . andTelaogace.
.
fllstnoit4.e Monday.

St 'tint) ctlI4)thf'c)l gf

5T
ilal Ftot f
1it
&q'tfSt ?1cbin
GOVERNMENT OF INDIA
T ti1P,O9.11.2O18 ('Ti If0J
MINISTRY OF PER5ONNEL; PUBLIC GRIEVANCES AND PENSIONS
y4orl1 ~cict 1574
• -- l'ID41. tiqat'l
I. ftnlP,ftt f)?J
(DEPARTMENT OF PERSONNELAND TRAINING)

°'

- -

BJI?- may drop majori
ofMLAsinRa
cut athi-incumberc
BJP ycerth wing to

•Akhi1eshSin8k
®timestrOUp.COm

........................

..

..

hold condave in

New fleihit ten' is set to ft.. ..........•.

pith SiP keen to gain
nalise candidates for upco.
ming polls by-:Novembei.'llrbundlhtheSoutherfl
flrstweekwitha otronpos- states wherethepartyhas
sibuityof dropihgrnajori- Idt a presence, Its youth....
tt of sitting MLAs in Rn- wing—BJYM—issetto
justhan and Madhya.Pra- organiseathree-dayiinega
ileshtobeatanti-jncdmben- sumrnit"in poll-bound
cy, a trend the parry hds Telanganastarttngfriday,
fdflowed in deciding its no- wtschwill be addressed by
mineesforCtliatttsgdih.- . partychietArnitShah onthe
Senior'léàders are conch concluding day. '(usa
dent of retaiithg pbdiett in Mahadhiveshsn'willbe - thrgesthtes-ondgainingdia- - Inaugurated byhome
jorityin Milordin although minister Rajanth Singh sn..:
sources said the lastSayaftetds'opping
Centra,lElectionCotnsssrtee 44 sitting MLs including a

•(CEC),inthepresenceofPM p-minister Sourcet said three
Narendra Moth said party morewill be replaced In the
chIef Ahiit Shah. vyjil finals- next list- The party tins 48
• sesno4tbfthe:canthdateson MLAS .i Chhsttlogarh of
Novetnberl2forwNchtnifi- - Which 17:40111 be dropped, di.
al exerciselof -preparing a mo 5% of thesttength of
list of potent!hlcattdidated sitting MLAs. Sources said
has been -completed. The the proportion of dropped
portyreleasndtheflrsilistof .MLAs will be much more
77 candidates Chhatlisgarh for MP and ttajasthan. . -

an-: Give more mb on
Licrat-corporate nexus
You have nt tiñdérstood the court nor
have read the judges: CJI to advocate

•r

wrong.footedadvo6ate
Prasharrtflhushantwice
benchheadedhnian
GngsiooTuesday during
hearing oltwosuccessioe PlLs— ooeseekinganixdependent
ar(pointmentof
CECand ECs andthe second osa
merhdiiisrn far
PiLon alleged politiriah'bureaucrat-rsrporute nexus.
- Wlienthebenchatarteddictating its orderin the
appbintmentofCECandECs. Bhushanlhoughtthebertchwas
yaingto dismiss the PlLandwantedto advance mare
argumenls.TheCJt, before referrinqthe PILtO alive-judge
bench, said, Mr khudhan, you xeverandersnoodthis court.
Plehsetry and undersndad." A strniiarsituation arosewhenthe
courtstarted dictatingthe.order jothe PiLonthenexus issueand
the Cii said, 'in spiteof ajotef yearsspentintheSC,yau have net
.:..
readthe judges." ghanaoiayuahapatoa ITrN

slay In .fsvmstor hotels and
showered them-with eirpensivegjftsiogettheirwoikdo.
ne in the government; 'It

constitutes b: clear offetice
under thePrenention of CorruptionAct." hesaid. :

FuU report oiiwww.Wiin

1

(
f,
...(oJEe.2oIaJ. a•;- .

No: OJ EE-18/470

I3ate-2211012018

The detailsof eligibility conditions snd.the proform...for sending -Detailed Schedule for Spet Round C6udkelIInfnrBAMSIBHMS
leeping in view, the cut-off - date of- admission to
A M S/BH MS coureen preadribed by -appropriate
particulars for consideration for the post of Chief Information
ttiilhorily, the Spot Round counsellihg-cnm-ndrnission for
Commissioner in the Central Information Commission may be tltl'd notified Inslilutes in Odidhu shall be-conducted as pr
he following schedule
lownloaded from the Department of Personnel and Training All
the registered 'All India NEET' rant holderiihierested
'5ebsite www per5m10 mc in The last date for receipt of the it dice part in spa) round counseltlrghavo to report as per the
tirhelablegivdnbeloch.

.complettd applications in th Dpártinent is 12.11.2018.

F.
-

27.15-iou

-r

0,055 onnseeon
zr.us-asnie.-aaau'sn cannon 27.10.2018 - 2:OOPM000:SOPM ..- lsaeslroaoaaat
asaoai1orcstaa
In-Ia-inn - isinsojorto 11.uoAM

1 OJEE CELL

Opening (if online registration O.IO
Closing of online registration - 28.11.2018

ALL INDIA INSTITUTE OF MEDICAL SCIENCES

•

•i

•

Goardwound.
-

-

'

evasotle&lojtjjialnoitnd Inns, Indian Citineno by lIe Director. SiMS. far tile lallawino Coolly Deals if Asuisloni
Pmtr on roes/yr Owns - •
10101
oenersolloe
Pont Can"' ol 018 POnt
101

Sc

40511. ProtOn tlorlaoi IlirrelolOgy

t2

01

02

51

nec

boon, P151.01 vhealnutsugy

el

-

on
01
•sonmai tems&candi000s nod prescr,trd lenoarnmt ruloo etc. tsr eu elaroserd pesis cr11 be aeaitoblr inure PJIMS, fliwDoihi
wubellos www.allmnoflufn,trt and vnew.allmnedu.
Director
davy 17112110l0055/10i5 -

5.;TiONALCOUUCftFORHO1E

-MANAGEMENtANbCATER(NGiECHNOLoG

lrniscfThurism0 Governmei'noflndla
—A-34SeCtor 62,No,da Prn,2OI3O9 T420259D60O-62
'nchenctadmn@grnail
coon website wniwnchnthic U
E-mail

NC NM CT

INVITES APPLICATIONS FOR THE POST OF PRINCIPAL,
INSTiTUTE OF HOTEL MANAGEMENT, SRINAGAR
Post&ScaleotPay: PRINCiPAL(Paymatrixlevel 13).
No. of Peal & Method or Recruitment: 01 Post (Unreserved). To be tiled by direct recruitment
and short term coetraclldepulabon.
.
-Required Minimum Educational Qsafificatibd and experience: As per copy otRecruimmeni
Rule placed in Ihewebsile wo,w.nchm.nic.in and w-vrw.ihmsrivagarorg
Age limit:Notexceedine 53years. (Age reisxalion uspergovernmentnnrrnswilll be applicable
for other categories. Relaxable for employees working in autonomous bodies usdor the Minislry
of Tourisnlsp to5 years in accordance with tie instmclions or orders issued by the Central
Government) -- '..
General: (1) The prescribed Application Format ii given on tie inslitutv website
www.nchm.nic.ifldridwww.ihmsrtnagur.org and islerestedleligib:v candidates want apply in
the prescribed format- only lattach all the rolevast docsmsnls in support ot quelificeton,
expetienco, dateat birth and category 10 which belong). 12) The csndidales employed in the
Govt. I Quasi or Semi God. I autonomous organizations wino are applying for the p051 on direct
!Pcisilmasthasio, mUst apply lhrough proper channel. (3) TIne spplicabsn should hvaddrnssmd
to Chdirmdi-i,Inatitute at Hotel Maaagement Catering -Technology & Applied l'lutrttion, Raj
Bagh, srinagir(J&X) iyaoaa, ssbocribing on the topof the envelope Application brIbe Post
of "Principal1 IHMCT&AN, Srinagor". (4) Application along with all enclosures must reach the
inalitiilé lalestby23' November 2018. to caseof delay in for-warding lbs application ttrrosgh
respedtive daparhnienl. advanoecopy along with all the documents must reach will'en theitme
limit, (5) No TA/IDA will be paid to the candidate who will be called for interview. (6) The Itosilute
reservesttne rightlo short islttne applicatov/tll ornottolili the vacancy.
- -

-

.0!

ri....

al.uo.oane 51.05.0510.

115-lOAM TO 11:50AM

'1:00AM Tn 12 eloela
O:55P0070 3:50 PM

reaonsnn grate,
950001500 A000t
frnozsc0sl,a55llod500ten.000- I

CHAIRMAN, weE 2018

ADVERTISEMENT NO. 0412018-(FC)

05511. Panf, of Hetnta-Pnthobgy

•

-

For farther dethrlo, p055 h5al 10 a

--

ANSARI NAGAR, NEW DELHi -110029

51
02'
Os

:t

assenT

-.

dnp 32201/11/0007f 1819

:11

,th,d ,at.

www.ñchm.riic.in

rilci:-

-

• theycsn.ccttethatitwouldbe October2klnl-lyderubad.
atoughflghtinRajasthan

Pa

T -

pp)tcatlons are invited for filling up tht post of Chief Information
Commissioner in the Central Information Commission, located â-t
New Delhi.

-

.-.NARYANA STA E1CTJON COMMJSION r4
AVS 1110 87-70 S1OR.Z PANCHKULAt134151
fté:jlsso.lnid,,.
'hoñeNbM72'5143i0O,
Public Notice
--

ltelernine of Calsing nato for Sabemnslnn of Online Applirol:oc lot
varloas pesta SI Poliae Oepartmant, Advertisement Nc. .312t10 arid for
opdeting nldntaivtheopPlivuti0000rml
Relrrence 1-/atyava SIan Selnvlicr Cerorniasrdo'o AdvI. fOrt 312015, dalnd
1604 20r0 wtvclr oas yvbhshed in v000Us roenspapers ant? tl 2t01 cod
Cern000drrrr dares an nsort scone 2cm Ode otvnvehdvernsemertl onlIne
dppl:calon tortes were ,nviled In' zooms POStS at Police Oapaisrtenr Harya'iz
lflruvgh keryana aloe 0e1er1:or Conrniss:nns wehs:ln i.e. -'So- 005c govin
roe 20.t4.2t18 to ouoe.2t1uard2t.es2t15 to ta.07.atnOt
2. Now ode knee Deparlrnenl. 5ohyca1:vr doled 25th Auguot. 7015 lie
lollezrng amendment has brernledr.
InIhePoicoSules, 1030 orulol2.nt.tvsub-vJel9l'.
lv clause tat mr sub'clause 14, Ore following nub-claus, Sflll be
1
nubsnrrured.nomeiy-.
'II Five 1021 marlin shall be niven 1 no pa-mao trom arr.nrtgv: Ihe
appi:san)o laUrel, mnlirer, apovse, biolherlil Sod sAInt .swnuslnag

bone a regular employer ,n any Daparlernol 000rd. Csr2aral:rn,
Company. 5latuiory eady Csmrnrss:on er Authority vi Horyara
0aoeirmon1sranya1her51a1e0oeemmen1010ovem.ortenlollnta" - Per the eesbng omens 01 lie end, the loilonony pmrmvu ot,ell I,, svbnlilvrnd. nateely:'ProvIded Oral 00 applicant sInaI be fiunn male lien lee lrut prns -P
urder ad orcvmslannrS mr secla.000nen'ra citeS and erperrerr.o'In view of above said am000moolS cow/niosran hos decidod to vine
another opper150ity te sandrdalesto opylyfenall the catpgorirsofAdol.No
dl2cit i.e. Cat Na I Male corretoble lGenerl Orrtyl, Cat en. 2 Female
Constable lOrnecal 00101. cat No 3 moo Reserve 0a001:onn nO 000yarra
State Mole Constable lsenerol lvty), Cdt rOe. 4 sal inspector IMalol. Cal - -5a.5 Sub lnnpeulor yemoiel. The etiarbie aandrdaten who sovid ratapty
0010cr were allowed to apply online through eta Hary000 Start 5n10n110'v
Cotrrnissior websime i.rsean,hrsonovirr troer le.ls.2SfO to 22.lt.2110 liii
1055 P.M and accordingly. the closIng date for deposIt 00 tee tree
25.10.2t15 thy 5:00 P.M.l.
Keeping In 5:00 the 0005errenne a' lOt oard.dalre. Inn lost dale lint
apply,rg arena against Ibis Ad-ri :11201 is hereby extended an to 2d111
October, 2t15 till 01:50 P.1.1, 10r0v50 1-lary000 Slalt 5e10otvn cenrrr,vslol
Webv,le ,e.,. hsse o.yv.,n. thereolior. ooboiir trot. soil be disabled The 1051 dods
fordepmn:t nIle, italsneaterdea op to 20th October, 2010 Iby srt pl.Tim
candidates who hove already applied aoaixst the said 5001. & went lt
updote the relovant field olthe applIcation ir clew etlha aenendr000t of
mentianod abono. tie delete Opdole there oppllcat/Ox has been Eef.nafltl
te25.10.2018 IOn 11:5t P.M.l.
•
- .. ..
....
soc,erao5
:.
Place l Ponohltala
Ha,yaoa Slat1 Seleclier C000n,18119t1;
Sated. she 22nd Octiber. 2015
'- Poecltlnula: <.
s,,sornvgr.oeQo,rra.raiyion.rfrrrss:lt,nlsrinl.'rvrStltallstale
:'. . • .1
.I.

<!-- page 16 -->

DU
'I.EFrrNTDU

Dl5CLAlecRi F;eadtisaienql-aird Tb

0uSd: 23 10.201k
-Smiled -lerideru dr invited (or the - purchose el-vrkstsfjvn'.
Fo.i •Deta,!:s. please vi 0 Institute -webeite:
www.iitr.ae.inladecFniutrationlppgeslTenderu EOI & CPP Portal
re/aoei. Sealed benders
b.Lturnjj'zpLQsae (5-eeoc. in/On
shouldroochtatestbyll:kohoursen 15/1112018:.-.- -::- .. ..- -i -- Officer on Special Duly (MM)
--:.

.N-n1100UoO6661Ml-17lIlnRl2ol8-ngutvskslubo.nlpr01J200
TENDER NOTICE -- -- -

an advertisemenT boipre wpnndv no
P'Jtalnso'uT LTD.,nbePvl,mncrO
pm Ca ancl050relces Li no teO bin
nbc bairn Pablaher. evver. 1dm, Dxcompany he meld renpenoulellrabie in
ordmgemloradorndeonennhn

amnenie. Ee OIeT,C CT nrC neesavnni

TO ADVERTISE
P LEASE CONTACT
Mr N SELVA KUMAB
2, .iPA:-98203 50725'

The Exvcuhce Enginkar,jiranSi Divisioto, PWD (R&8(, Jiranily, Went Tripuna, invites c-lender againsl press NIT No. 131E5-JRNIUDDI2OlD19 Dated loll 012010 . - .
For donstrnctionol ROC Bridge over riven Hownah en Old Agantalo
to Chondnaper cr0 Baldalnunal at Ch. 3.00 Ken lUeder NAeARO) ISH,.
lmprlyvenrenlof approtoches by providing WBM,PMC,CD etc. (2nd
i. : - ..-:
Call).
.DNIT NO,155IRIIINITJSE-1512017-15
- . .

I km ptt h dcv
Mr GAURAVSEHGAL
--

-

2

-

-

Himachal Pradesh Public Works Department
"NOTICE INVITING TENDER"

uealed I rrnotvtevd 0 dm0608 r xdedbytheExenss elsrg en Ma diD so (do llI-1PP003 M die
lhxfullodotgwoiss&ntheppndvedandeliibiethpDaclorsxohioledinRP:PWDsoasloieadnishisoticxv30r
- beldre 23.11.201t upt&'tl;DOkM and cdli be opened an md sainrn day al 3:30 P.M in Inn presence olinleresivg
mnl?acospelreiniulhddzed rdpcesenlafioesiidno'may like In beresenl. IIit happen to be holdayot9se tender
- will be opern on next woriring day. The opplicabori for oblainind the Ienden.lnrrn drill be ceceixed U to 1:00 P.M en
- f9.lt2O18andEM001nrnudbeattadneddjrtnglheiibrnisdiunolappioaUonforthtniimingthelendeclnnn,wtthcut
EMO aplicaton alt not be apled and Die tende)orm rtn be had from Ibis ofian against cash peynleni (Non
Tel dad) p1 5000 I 19112018
The names mm
lb shape o bobs 01 S r Ce ic. 'lm
doDcsilacm0uhts'sadr.haccouhlmr in, if rhep sloffica arid Banks of Hlnnathal Pradedh duty pledged in favour ci
dm0, burr nrusl amorolpeny site eat ft I r toirdiuc cal tender and Ore lender acamued torweui canned money ala
sloaldbealtaohednanlhvpptioaton Theofferofthetendtrolnallbekepl
surrrnar.iybkre(eoted.Theearrnes
epenlor 12002, .ThoEoecutueEngnunnnnssrsenilneni6ghtivre(ecllhelendenwithouta5signlnganynea007...
Sn.
No. .:

ilaeealdark ''
- :-2 . .--

- .:
- -

- -.- - .
r
-

1. Spedal nepair iv Sdds;anlic-ne E"141a7 -'I Irma 61200,
- DIstiL Mann )H.P)ISFIIClO ..I .2 Ixa, 0Orage marS
and pibdiding paii0rn&slkin erleo xe Le.repairworh(

Estnneiod

END

Cccl Eligibli -- Semo
at
aiof
fund
Teder Conon
237325- 4000- 3007- 01 loG One
MemO
-. :.
.: .....
-: II .2 ..... -i
--

050ERALC000mONSi.
.-. . - :.
.
.
- -. . . 1. Thelenderfonersalllnolbessuedlolhooécarrlract&sndhadeperlonnnenceisnolfoundku3sfoolory.
:2..The onmlradoms whoue edesareabnoanaly lank may be esked to famish the full jusbtcaton of ha eats 105n0
uandnhewiffbedebuiredlnmmpele hnlorderfng IonfounmonSnk.
''
.
.
3. The centmnidorwill mmdl mdcc more llmarilwoworksin hondatthe Irne of londerand anlyap locompinbonetworli
salisiantbrytvduding adhurerca logically purumelersfarlheramnrh call ha awarded Is him. 001 underlalring sliM
heiunothauingrnonctndotwoworkoinhandnruotberecerdedintheapplicoton. : -.-. : - .
..
.
- SW.
-Executive EnsloenrO
Mandi Dinislore No.11,
HPIPWD Mardi
Hpo2gl6lle:lg : .. - -.

GOVERNMENT

is

MINISTRY OF PEF -ONNEL

,PH:S981 1006590
gourav sehgailHthehindu coils

11IL,idfl\DL

Estimated cost
Rs 5011 5400
1611
E
B 5011200
y
06(5 (en tl
Toni IC p10
Last Date of bidding fur bids —1301112018 apto 15.008cc.
Foe'000re details kindly visit: https:Iltdporatnders.gsv.im -

iCA-C -1489/18

HIMACHAL PRADESH P(JBUC WORKS DEPARTMENT t-ProcurementNottce
. .,.
. - 0
INVITATION FOR BIDS am).
'. l.Theitanuosne.,moinnenyPpldboatsiov,Fatrlrrvr,pinitriangiaH.Poebvhdllotpo-ue:rarorflPinrulr050a
enlinvbidsunermrale,indleclronvclendonngsynlern.in2CaoéritVslumlorllreondnrrmrenivnddbuid.noworks.
lromlreelitibleardsppeeliedeeniraniers/Firrnsregldleredsilll llPPW000parlinenI1- - - .'. -- - --'. -.. - lied Cost Eligihia
- - Estimated END
Or.
--flarnee of wads
Umir of ' ntass of
No......- .......-Cost .:
.
- - Tender Confrartor
--;
- - - - A
1.. Cxnolcmnlon of Gout hal Ganoath in reid: 1 228640611. 2622001- Two 88601- lndaraDisltkargrdtHP)iSl-l'-Convhnvlovol
- i.:-- yale
-holding portal, .Walnn Supply S -Sanitary - -:
...0'
- Inslaliaton, Seplic Tank and of Rain Watnt-----hanvesinn salem)
...........
...... - - ,

Dais otOnl,ncpu5liss1onio07,lt.2Oloal l000hrs.Doerrnenlibiddntmnloadslcrtand endd01e51n07.10.2018
o110 30 his 1029,11.2015 upls 1700 len.Tcthniorl bid & Ioi0000l hi soul bmopened 0 33.11,2018 al tt.O0
ask 0.12.20t8 respecdvely.'fhc lender maims and xlvi delai1e0 comrd0ans ran be $ cv 8mm thit 055064
201- Eaeoabvn Eeelneari
servo hptends.gex.ir.
HPPWO Dinidion Fotehpun, Dine. kaagra H.P.,
- HIM SUCHNA - AVAdAJan4SAf.tpdilt
Oeboflslrorsseemoieluimaerrsrpesdesh
HPl2064liP-ti

OF- INDIA' -.

PUBLIC GRIEVANCES AND PENSIONS E.

(DEPART LENT OF PERSONNELAND TRAINING)

-

NATIONAL SCHOOL OF DRAMA

REPERTORY COMPANY

-

-

eased on 'Fiddler on the Roof' - -

KHAMOSHI SILl SILl.
Applidations are invited for filhhg-up the post of Chief Informat(or
iCommisioneriii the Central (rformation Commission, located at New Delhi:

-

Writlnn 0y Joseph Stein
Adaptation By P.oC All Hairier

-

- Donian & Direction by Si. Saresh Sharnra
20,27620 OCtober, 2010 St 6.30 p.m. Additional Show 27620Cm .3010 an 3.00 p.m.

The details of eligibility conditions and the profomia for sendin .
drticuIars for consideration for the post of chief Information
iCommissioner in the Central Information Commission may be-

-

Abhimanch Auditorium
natrawalvur noose, otmagw000as Read.
New oolhi-110001
heRein IRs. 200, roo, 50?.) are aua,lable vi rIbS nepeirony, eonaoxlpa Mason,
8hagwandas Road horn 24 Ocreter. 2018 enwsrds mm 11 Olin 10 1 pm & 2 pm lv

own loaded from. - the Department - of Personnel and Training (
-Ion Sesame a be made 01 02260rm050. children balenO yearn. Mabmie, Camamr.
-.
...
ebsite: www.persmin.nic.in, The last date for receipt of the completed- (ri. Handoagaund aoiable are noi permitted.
.
- "
DAVP oni3ollllodllllera
Era., elr.23303a20, 23031105
ippIicatiöns in the Department is 12.11.2018.

davp 322O1Ii1IO007I181
ii ---we n.

.. . -

Gist.

-

- louT aud050mous hisbLulien under Mmnionry em CollaTe. GOut olindmv)

For and on behall or Oooenmar elmamini.m
a-bids in tam lozi oamer sm0lem trom,6,
0a00m0n1 ion inn sPannIng nova:
550 Noma ofefleWorri :-Aneaalmointnnance Conreaoe.t.
1
or Main Belier n ue or S elMD,d
The nnmpinle mendam deanmunl In aualla
deCumvnn, sank uanlflCauona via suamom
aomlainnqualiiying aniteda lvi bidders Op
ii Dale and ernie eldo-0n100d1nq1501e
IlL Dole & lOire on Oradino Qmnvnes!ya
I) Luor Dale 0 lOne 01 Rid Uplaa0irrd
Cl bare Cr Seomionron vi nerd Cretin
ci Dole 0 lime vi Cs'rrxneranol/iechnii

iii

Dale &Titere ol Finunana Bidicasa

0001cr e-b,d Daaumenm
-aol Arrnount 01 Eaneum Money DvpOnill
lot Canplemlon Tine
el Oudnnl Head- NeilMS rot E2.42n1r0-1170.na.2200-2050
Deled:.tt.102016
Nd-SIMS 20t,
Sated,. 20.to.1018
-

<!-- page 17 -->

'

9

1GccIIGf

243J?2O18

ea11

I (3 TI

-

5i

Stfl UJI UIlL&l

)iI

thfitci 3TTT1Td1I
IIc10 o1T.31IU

fle1)1dil i) • e

zllecl auiofcDcu cc.)ci e eieøie
umicii
ii a1 J1IU
trt

i1tJ3llQ13 ,o a ftoio4

Jur

30404 1à014IeI
*2TidIo11

-.

77T7 I34

111lI

1197O
12O17

4187131 09501

-

19l4

A

1040431111114

04o1os 0431, 8144(1414
0454141 04s, 404o 304014411

3ll71

1lth

A

044111(909013015511441 1911

04101404145

0015

840149044804540011 s55o

14(31I

003U04 ostom

5l 5100

3IfItLrc1hl

01110113

ail

21421144 195141413550119
'141I4l 41T
3i3Il10 31T T01 04 01014

0105414504$

41s31101014141

m15411512015 44131

2011

481411508114041104(1118150
49te1 851981491111131101

11131

11130111411
0155711114101311101
09T1490 14409359111
491044135141
5545599190111410 yTq1021111l(
.110101119T101101r01 404so'14i
3043114310411119010 .04(1494
14090159
90T5itli13590i13 1431451515144

010044401

r14rlm
3011191
0144 010904 010
041109 ITO! 58045404 st
9114091411401 44111911355571111
flTos 0441l144lt 4'
1111140 355 1ITT0R

.90114511

.11104115045

094951041

2

9110

.3013490 1(1
811115131148401t

31101014

55104411

04914131141319190414
3050111411011448571011 4014
14114045181510511111110

044I0401ITR 3509141050113T1444 .1191589093,09091
541434100914 3551011
4550410101004

412011 4 3091(1 94144 siit 4

44

7111141 !j549 0149
1134409T0 ol

4149531*1

311991O5

11141,

1l

11040911
450(1150
31410111415449111 o 10 5 ol1
141111091441 Sf sisw 04

13014ll0

10f318,1984

9113131el0

14 10400 oso 8495

14905001
•

c1ITfTT'

111(4301953410009

09101141,54513140959101113(1004

4I01f110S7114l11t

.011t10145416444140414111414
0440311,01(84041
• 954I( '1101481114970115415

44*441

4118404318431410190 sn(1l91f41IlT101lTtI
3041404 310941114043811019
3495141 11•IT to 301101
8495314404T4814411591111111
(1,1910(184(11441 o(1oolu84 3(1 101109104 13914
10I4 84 (4558 3111144 010 141134113 1441111 550941301504
541141041 I4i11T'TlTT* I 4148441101084 15110481001513, *40411110
18141010414043154410301911 84(1'
f4'i 04(10,01 3011 381071141 10

-

11191015711140141410404014,

84 11111 4111155111 84 o( (11
(01

41411554101114*1313411141151)
14110710151 9514 5131
145111031(40117 4414 (04)70 3404119570451111110 84 844* 44191114091311(1 '91141
131484 1'1lclTi 3(1 1101114104 84
04 8Il0
11104141411 0415484
4,11157 411041151 14 5504 4111000 40171101040141(I19lo40it34t84
1901118411 14104(11
00141395719590094940 09,31 811 3111 III .84381 Ii
101(0119010
120
io8404th84t t

40TlTW lI'T10Ttlf48114114l41T1

411-10sit9144090431155413401

II' Cl III 13 141 814 417141150
0413141431315181- 7411404T158111

(1

1014',84 144084131 1404114 44
4l01 31440134155114 1411111
044045509(1190141!
401355101101011514811044415

t

30111390171,00, 84389584

o954*4*4i44959584

L ALLAHABAD BANK

0471 414& ,,.17h.838I.l8,8, - - - - .
15013114)
111l (oo85 015385,000041 om *1
o157 .85,,.8 1113114118.41901 11 10,4410, 04101,
114100 3, .o4, ,4148s,
0900,3101991451
11 00010 480011
55 1,1441
-

111140101,471101015114454101110 01o0151491*..011345

344,., 85, p04.. 4.o0451 344 .01. 'Ito, *..4I .444444 *. 'Ijo,
401404 4
444 W P*o' 4014 151O4 01014111 C.s.o 4491.4

0414040813814309011304109431(1 31951*11001100110090415119

04 lo 1091o44ll114411o101 01111.11

04131404(1001sT 1804 34o7184 18491391001 711111104'11441q4
411 4811(1 10 3148
41
*3.,904s9..1tor , 0411,0011114 o,9540o Iso

041134910 fo,' 04

8114139114 953(81*70001114 0401*31719504(09595,

011141114

IiI,1
84814441810955*55

009504(17091101917041119208011'O 7094489079443,014o#4

014144431119034180940*

11304953583409119013155

99415451oo4o0335155040

*'I4o515300319044011104
8851910040495801137

51045844131141141004,T1T04

*441310011314*84095
44o*1smo4it001101

*109'l14414412101955444
01895040983055810451

480414511414113143103191001014190131401041$ISIii0011

7435553140449541510115114

*4401019530843144355

9551953854195tS4*40
g 1050445114 40310408,0,0510
4 0414010183*0011113*

*afove3i35l*40314114
41134100901108101409341157

9574 .o55l49n,o84 0oo19

81107095397004140491.0

s8395444j

3(010*01404(190415341,

1

444113850114139*

$043131; 05.10.2010

1054109: 0414.11141151114 30415110/201044
490044 dII10C111 0417155155151117

354114 1tZS

201895 toN $11Cel01C10451$8ItO101
3410004 10,35Tooiov09T04l7954372oT848s34',vo8404R34T11Tp34v14Oc11409M I
339T4e4981f14,ova(20533071310111954045 40304010 009011 095)4100'

44

,

u14o151 8041013112.11.2310016 7101Cc, 00115119 3111035104 I,,vlc.11 3355 440 *95 351090
1101051 711)0451 319581,04
34144901*310300004

1451404485oio,'1,l

10983903101' ,:55,':.- 1.i34C900491cR

DELHI MEDICAL COUNCIL
48710101010181113111

DelhI Medical Coono) rt04Er1s approved IflSl,l,I,onal 00
CommercIal 011100 53900 01 6000 Sq. Fl. SO 10,000 11. FL
Doll, ,nool,Igflldi0000Puvh.0000loogIemo Lease bas,s
01,101 d,8 Prelened II! p950001,1O oomplelely by 31n.que.
(No cash 8ansa0300). Inlaresled p3111.0 requIred Iv send
prop010y cod p0090caldolaaeelollcoaddroeo.0r
01,1.8 T9agi
RegIstrar, Delhi Modloel CouncIl.

5110,41
01

91811085411011801051,
171014101101,
.0110011,01014 ,,444110,,8
84171141141330
1144101014411
l014311$1000$1141119093014'1011101184110041t01fl4191418!
0,
140111teI10lI14
.,1,o0440l,
'i.,,l 010 31*0144-04,01111
119014015010111 101484110111 409415 0144911.0111..
91,11010 Ill!
411101159144

010140111.401.0411

4**mo%#1111bd11

4101
.401101401-0 4118 01

.,4

01.

101011

-- ------------------------------------

714111035

ct31f451*3,

(br4
1154k

%

II, 131141051411,, 144 44301- 110001

f0514T 3(TEIIT

01011485R

31471 00115014 0106 013004 513114111341481850010091 aol',
0110o9141er5*u*000018o405094441I0144440r*l

02 1719091143 09'l 1110 : 1100 34
• I91-441

.

.04.-,

9•1TT• toJc*I1(

54

10194 4110111, 1,0401801143 04 011514 03144100,40101

01001510040550 024441 2018

0101
010101011111441

0114 0 311812004100451090 18314391390018

ff3441511031 1411.4(04*101

00 1501817101

9719:0310
04 0100110110011 5434111 00.01041014114, 1016014.
11 II '5311111 110553 9519 '55 10101

99010 44 44 44 Pr,,, 01911 '1111 95, orr *"i 43 5,5130

01001900190010

-

f c*01141 'T2J;T

I.i (114Ic1111

3fTivrfwr)
ao0l.00550, 58 1884 511841045 men, 04 00 o11os 415 *5 011 30009
-0414855390411. ooleel,iq114ll *oo'8 410404444144304
41104, 1313001 000,04310 1,'r81501 551148440,1090411111

iir 3iTlor lo1 1j

95 111*:.

*9551 58j5195 094490440 (0Om 445311 3514Tj514T 0411051 04 (4414155 otso04 04
f44144o134of9555roT ;(151%'581040
04igf04w°r *04i1015858T i9
*tflfflo 355fl T(111104'l(11 9504*401z www.persmin.nic.in
9404
55q,ç51(5ff(1fftj 12.11.2O18I

1040154,, v0001 10007101 100110 4;

33
01585108530144110
00451 404m

06

nlltcIrl,1 41851005104509

SI

055140,,11014,r,13010,orom

v0o 04189 *40003101 4190. 1*30
0113 84 95 044 3114,1049044,,
854'4 354 41441 101011111 '9111 441 4471

41 553, 8' TOm I

510400
50118

01 02 04

085151001071,11504044101

32201/11/0007/1819

r,,ra,01,0004/1014

0100,5 1801841101

4vl1coft

44143,

'o'coilelllil3ou.r1411444c,lI 8430oen311421991140821031109 3115041001841411113511511011

(44W*

I
4 4. o
0141401014101*9114101 OmIT
-'
82,507734081 44 *.4811...11W114114..*..*11.51

3111 10 41149 3,10709 04,

9011114131151094044111458(0401

104

0451151 losT siT 71111 'lOT '11481 04,0781115041100107841
3091(149919510950911495 T3(2)71l1J4113(1)(it)
(1011095,
71010110042018,

$CiiIIc1I

713 8409o441v458914847341(
84to(1384ocf441l55
4514043444431044
4915144114 071'1T951144111018
13111104401401 3995195, 50311

9510114104 4 1441(14ed,14 15

10

951033051*515

1rT

105 4114310411100108410 T4,8~1 04414 0141 440 1141353111 14 014
1114 304, 399419115515410404 4449108471117041404415810
00 51041114 I 14111(110157 4 85004151111
'ITO 41,7,48,8404471917111 811043114 '91 evIl,011 011701101134

105831,384
311401459110

141371,10 051441115004111

3810014004
404101841101315541554119144110

dI

s1cdl
41,7105-844f1-1314 s44

3101441038110000300400101010145115(004400090143504

0104 95 'TI 1311411411 11111113(1

311301

E1TdICI1
.0114141311013109

54091 OOOOIOSII 4411143141Sf

4404s44 (1(44111(1,10,710
53113148050143,1001TI 38101101141

11091411551143510704! 0141
STill (3103011 'iT 0141104
411010010415 s014* '8

4041148490
(11411498471101111

094,45151 0800:804114TOnf3,1001104011119500811101

141014411*401054140340911350940011114930514139141

410(101(1144143195 114411
404 04314 (400913111109 4109 041

111149444401915058 oi,

043!1301
os11si

01031411101

43

SITS 81515143109131091004410

84049114101444441

aftu

3131710 a44f,o714 90381*
41344191410101404 85111I'

'00704111,0308148,f04019149;0313'000 71005405101110
91.04510,00811,

<!-- page 18 -->

tFT.t. 4/13/2018 -3Tr31T

31RI

ii'

fiiii QT TT

1HIl

fraTur fr)

(c,i1, 3th

1ct, ;T

lT
OjI4,:

'ci *iiuii 3jIdI

i:

r 3T1EfT

,Hlo1l

frr

24.11.2018

i~o-iIct

Qur
3.

1iii 3
3fr

trr

r ic-i -i)

trr tll11,! 3T

i1

rr f4

r

ci

65

5.

-j&

t 31T
ticii

,1ILd

d-lld-Ic'lI

w'T

cflçfl a

t1T

3T1ET

C-4II MTE1T

T[f

1IdI

'I

31I ,chi

cfc1 1111cI

do1, §

3

1Er rrT
ft

q

3Th1c4-d

iTc*, o1

iftTuT 11PT,

12 o-icct't, 2018
3ç-Idjçj ct)Id

'1cii *r 3

çj
3

1?c

c1 E1Tf o

rr1r ?r

1r

ci

¶ftT d-llalc

ft q{

1c1

ciç'1 34

-iii (3lT31R) cbd.I T. 215tr/UI,

sict ccikI 3TT usir-doptnic.in
,-jcI( 3TTT ¶It

-II

t .-i-i 5:00

oç-1l

4

iii

-

4-JdIOo-1

q?
T tI1

'Hc1

4
a-Il

111k1

1T

[TU[,

ca1 ctk

t
dk

&1Ii

'c1O1

cj1Icf

3T1T 1bT) ciYk EIt 'dd-IIc1, J-H&1 'dt1all 3-INc1-d

4.

9Tf

-T

t - 3-wr

9T tlII Z1

ciieii a1)

1

6.

cbIdI, J -d4III 31TE1T 1T1.f[T

3T 1u

r,

c

I

iii

-ic dc-I 3TElT f

(ii)

1d-li1 ctI,

411141,

-c1Ic1

T

31k-Ic-d

-jtfrfJ

+itloll 31klctd-

cIYct .lIa1 311 3TTT tZ1

1k1a1

c4c1

d-$

I1c1I 3ft

'Itlolt 31Nc1-ct

I

a1I 31N'fcl 1r IId

d-

,1I

J1s

10-1I 31kI'ldl dI~d

&Id-IYo1 tR 1cd1la1 d-t

TEI1TFf c4c1I

3ifl1

()

31a1I'&

cblcbIc1

i,tla1! 3lkIk

c

4c4,j

31a-ddjd

i 4içi '1tioiI 31N)dl

1.rr

3R 3T 1ZIR, 2005
2.

23 3iqci, 2018

loll 3iiqqci *t Il1cli

3-111ZflT, 2005

ft oi3 i~c'-cii

,

J

1?cfl

3N[[

(T: '.I'y--R1 'tkrl

cUl id RT-2lcJ-I

3r4EIT f4lcf

ic)

19T 1I1

I
e

(iifl
i;

)

(311$3lT)

23092356
¶ufl:
2005 3

vci 31l44cb

c1l'U 'IIa1ioq lIai4*fl

3lddjd 1oi1

T

t,

1ii T ki'1'dl

1I .Ic1

t, '1lalI

T 3rlT

3r1ifflT,

<!-- page 19 -->

1 *lc1I 3I'qdI

1.

a1I'J-I

2.

s,lad-I

3.

ctçd-IIa1 qi

4.

*L)

).

â11 'la1I 3iqci

1f

èc4)a1 (L1

•). J-iici
T).

( cN1

5.

-j

q9T

6.

i1i1, 41d4c1I

7

, &,L1I1 :I

8.

clçd-IIa1 c4cl'i.-4k4

9.

3qJ/c0j

31

(3icdoicb

31a1k)

1~aiict :

r th

c4 '1S

i1)

f flR c1 i 11L. fciui &)r*

<!-- page 20 -->

3ja1do1cl,

I

*ioii 3i1'qqci

'i
3TR1T

t 31I4o1 qj

jtl-J.fl4cIR1

5P-11i4i'

T

3trr1eJ?UIc1,I

ir fcu1

r.
dct
1.

2.

3.

4.

5.

3TTT

(tr)

<!-- page 21 -->

1Rr
TT J1IteI'q

fciiiici F1T
(chI1

i$ 1~

frr

31Id$d

bc

311T

i-

ftta1I

fvr tiTr)

tIo1I

d 31Id

t[

31N-lcl-d

,jjç

ki '1tla1I 3i1i

d-kS1 '-Itlo-tI 31NcI-cl

cO

www.persmin.nic.in

'v 31ia1i It 'c1c

f9oT ¶ç 4

4L4:4

4çj

cta1

si

3i1

1T

11f

-ict,c1

12.11.2018

fiT

¶1TT
I

<!-- page 22 -->

.__
eatan ;J itland and. dgscatswouldbedoneontlaj..Prpdesls as:well, l's.- ly after the ellections in
Clthatlasgarh Madhya Pra
nsa ti
As per toils doing the desh, Mjzoram, Rajasthan
fl(1a5
,15')d.c 539.0
) anri'rntangana.

BJP may drop.imijority
ofMLAsinRaj,MPto
cut anfi-.incumbency
®timesgraup.com

RIP winth winn hi

_..___I____

noiu cunuave in nyd

New DeThi BJP Is sot to Ii- .
nalise candidates for upon- 1 A leb RIP keen to gain
groündlnthe
southern
V
V
icing polib by November
firstweekwithastrongpos- statetwheretheparty has
slbilityofdroppingmajori- little presence, Its youth
ty of sittsisg MLAs.in Its- wing—B,JVM—isaetto
jasthan and MacOwn Pra- orgaziiaeathree-daymega
deshtobeatanti-incumben- summirin p08-bound
C% a trend the party has Telangandstarting Friday.
foll.owed-in dectdingithno- whlchwil! beaddressed by.
partychidfAigitShah nnthe
minéesförchliattisgarh.
concluding day. 'Vuva
SeniorIeaclets are confl
dent of retaining ponven In Mahadhiveshan' will be
threestates and gaining ma- Inaugurated by home
jorityin MiZoram although minister RajanthSingh on
thoycoftcedathatitwuldbe October26 in Hyderabad.
àthughflgbtinRsjasthan....
. said the last Satsirniny after dropping
Pgty
CentralRlectlonCrnnmslttee 14 sit" MLAs including a
(COG). intliepreoenceof PM msnistoc Sotnrta said three
Narendra, Moth add party more will be replaced In the
48 .
chief Anilt Shdh, wllifmall• next list. Thj pngy
seniñstbf tbe.candithtos on Mt.As in Chitattisgarh of
Novembel-forwhichiniti : wlsithl7.wiltbe dropped, alat exercise of -preparing a moat 25% of the atrength of
llstonf potentia1candidates sitting MLAs. Sources said
has been noinpieted. The the proportion of dropped
partyreleaeedthsfirstllstof MLAa will be much more
'17 csndidatea Clthlttisgarh for MI' and Itajasthan.

an: Give more mfo on
Licrat-corporate nexus
-Yàu have nOt uflderstood the cOurt nor
have read the judges: Cii to advocate
"°'h'ebenèh headed b'cJl Ranjan Gogoi onTudsday
wrong-IootedadvocatePraahaotBhushantwiceduring
hearing of two auccessive Pus — one seeking an Independent
mechanismforajn'poiistnsrentofCeCand ECsandthe second ona
Pitonalleged politician-bureaucrat-corpsratenexse,
Whenthe benchatarted dictating itsorder in the appoiritmentofCECasECa, Bhashanthoughtthe beiichwas
goingtodismissthe,piLandwastedtoadvance more.
arguments. TheCJl, before referringthe PiLtoafive-judge
bench, said, "Mr Bhushan, you neverusderstood this court.
Pleasetry and understand." Asimilarsituation arose when the
courtatarteddictatingtheorderintheplLonthenexus issueand
theOilaaid,"ln spiteof alotofyearsspentintheSC,you have not
read the judges."
-..
ofiananlayMahapahs ITch
stay in five-star hotels anuS constitutes a clear offence
showered them with expen- under the Prevention of Coraivegiftstogettheirworkdo- ruptlonAct,"hesaid.
ne in the government. "It
Full re port rinwwus tot in

r'"-"-' ."

5 ft)) n

F'tf

fISTIT

TT ti5T

i5

GOVERItIMENT Of tNDIA
MINISTRY OF PERSONNEL, UBUCGRIEVANCES AND PENSIONS
(DEPARTMENT OF DERSONNELANDTINING)

,O9.1t2018
M 1l f
I f'Is fur ni
T T°W
tPth: www.ñchm.riic.in - .

ru ApIictiOn are inited fO ltiñg upth post of Chief Informatior
Commissioner in the Centrl Information Commission located at

JOINT ENTRANCE EXAMINATION2OI8,00IS$A
WJE4Oi8

New Delhi.
The details of eligibility conditions and the proforma for sending
particulars for consideration for the post of Chief Information.
Commissioner ir the Cent al Information Commission may be
downloaded from the De artment of Personnel and Training'
website: www.persmin.nic in The last date for receipt of the
ompleted applications in the Department is 12.11.2018.
daep 32201/11/0007/1819

- •Oate-22/10/2018
P40: OJEE-18/470 - - - .
Oritalied Schedule for Spot Round Courtsetline for RAMSIEHMS
fieping in view, the cut-off- date of- atiroission to
RMS/SHMS courses prescribed by appropriate
,j(hority,- the Spot Round cn3u0ae11ii19-cum-adiniisston for
Rh noiifned lnslilutea (nOdidha thai be conducted as per
- hhfollpwlng.schoclule.
..
j'the reglatered 'All Indio NEST' rank holders iriterested
to part In spot round counsalling have to report as per lila
iptetabte given below.
ALLINCIIANEET
- REPOOTINOTiME
DATE
VENUE
--

salt-oslo 1000AM TO 1100AM
0000010 150500
02.10-2015 - rl.O2AM '0610 NOON
assess TO 5:00PM . 1S0001 TO 400005
07-It-OSlO
utt*'tOil.nOAM' 400251 TOlos050
7200t1'dOSSStOS
05-rd-Sins ln:sOAMI050005N
200PM.103'OOPM
955055A50A0050
n-no-ante
Foe turthon dttorio. ple000 login Ia0000.niee.nln.lsiooaoo.odtcooje..enn

- n, 0)00 CELL,
--Gondenro0de
•.

Closing of online registration - 28.11.2018

ALL INDIA INSTITUTE OF MEDICAL SCIENCES
ANSARI NAGAR N DEthl-110029
ADVERTISEMENT NO. 0412018-(FCI
0stinausolleatlenLu1LiunIlgfren Indian Cltzgnu by the Dlwstsr. AIIMS for One following tucsltv Dests Di eaalntant
PTgl050en eQ reaulsrbeetnz Rtoev5Ilatt
15131 - Pact item. of the Pact
Code
- .'...
.Pos._
-- sac
51
en
Sc
03
Amtt-Pnot.Ololnlnaiflomntologn
52
01
51
I
...
a2..
.
02
as aaoltnnsfofeemeto-Pothoi055
. 01 01
lasttProl.otetneumatnsqy
03
- en
Total'
en
m
enn.foroma.foresaid
psstswfl
be
satiable
in
Set
135.08w
StIll
- tenersllarms&mndaonomd prgucobed rnuninnhntnIm
wsbsltmnewwAnms000me.arg end ann.0Oe,n.Adni.
Difector
davpllll2/lll005allels

- NATIONAL COUNCIL FOR HOTEL MANAGEMENT AND CATERING TECHNOLOGY
NCHMCT

(Ministry of Touriam, Government of India)
A-34, Sector- 62, Noida, Pin-201309, Tel.: 012O-290600-623
E-meil: nchmctadmn@grnail.com website: www,nchm.nic,in

lNvr1s APPLICAT ONS FOR ThE POST OF PRINCIPAL,
INSTITUTE OF OTELMANAGEMENT, SRINAGAR
Post & Scale of Pay: PRINCIPAL (P. matrix level 13).
No. of Post & Method of Recruitment: 01 Post(lJnreserved). To be filled by direct recruilnient
and sborttermcontracUdepulaion.
Required Minimum Educalional Qahflcation and experience: As par copy of Recruitnlent
Rule placed in ihewebsite www.nchrn.nic.In and www.ihmsrinsgar.org
Age ilmitf Not exceeding 53 years. (Age relaxation as pergovernmesi norniswill be applicable
farolhercategoriea. Relaxablo for enployees working in autonomous bodies under the Mininlry
of Tourism up to5 years in occordalce wulh the issiructons or orders issued by the .Cenlral
Government). ' .- .
General: (1) Tue prescribed Application Format is given on the insfitule website
www.nchm.nic.In and www.ihmsripagar.org and interested/eligible candidates must apply in
the presriribed formal ooly (attach F all the relevant documents in support of qualification.
experience, dale' of birth and calegry to whictn belong). (2) The condidales employed in tI'S
Govt. I Quasi or Semi Govl. / autono(sous organizations who are applyirro for the posi on direct
recruitment basis, must apply lhroug(t proper channel. (3) The application should ho addressed
lo Chain tan, Inatituto of Hotel Ma'agement Catering -Technology &Applied Nutrition, Raj
Bagh, Srinagar(J&K) 190808, subscribing onthe top of the envelope Application forthe Post
of "Prirtclpal, IHMCT&AN, Srinaga". (4) Application along with all enclosures must reach the
Institute laleil by 23a NcovemberO18. In case of delay in lorwardieg tho spplicalion ihrough
rospechee department, advance copy along with all the documents must reach within tinelime
limit (5) trio TA/DAwlil ba paid to tile candidate who Will be called for interview. (6) The Institute
reservas the right to short list lheapp icaton/Ill orrnotlolill the vacancy.

- SD!CHAIRMAN. OJEE 2018
HARYANA STAFF SELECTION COMMISSION
BAYS NO. 67-70, SECTOR-2, PANCHKULA.134151
Phone No. 0172-5143700, Websito 35fygJI95c,ggj in

Public- Notice
lEctenoioo t Closing Dots far Subnrieslan of Online App!ioef:nn In,
00,1005 pests of Pniioe Department, AdVe,tisenrOot Na. 30510 ovd ton
updating of data in the aypincalinn tanni
.Relerenso Hogan, Staff Selnolion Conrrnissrua's 04sf. Rn: 312010, dated
I6.54.2s18 writS was psbhshnd in auto/rn newspapnno on 17.04 2t18 and
corrigenda,, doled 20.052510 & 10,002015. I/dc abnvepatue105ennnnl ovine
npplioalan forms Were mvitad br various posts 01 Polite Oepanl,rrnvl. Havana
through -Inryarna hail Selector Cemrnlsssn's weanile in. rnynwllsscyidja
from 20.t4.osleta I4.tt,2sloarrd2O.05.2OltfO 02.57.2015
2. Now uida Home Deparlmnnl. I4olitxalius dared 2nlh A/fgvsl. 2010 rile
loluveng amencrnrent has been nrade.
..
.InIhePoiceRules, 1034100dn12.lO,lntub'rulelgl In douse lal for sos-clause Ill, Inn lollowna sot-daysnsrrall be
nubsth,'led, rrownly:1/I Five 1451 marlIn shall be niuno if no person from aw.ungsi Urn
applIcants lather, mailer. spouse. brothers-) andsrlst svosthas
been a regale, ereployna an eras Ooparlaeenl, Board. Carporaliun.
Company, Slanotury 0ud0, CommissIon or Aurtrvrrty ul henyanv
oaaernmentonanyotlrerltolu 000emmenilor000errvrentullndia."
II. For the eustIn5 prsuiuo 01 the end. tine followIng pfovlsv droll Ian
subsiluled. norrrelylProadod Warns app000vt shall be 0i505 morn than len 1151 maria
underanyareumsraneen torsoulu'eunnamIcurilen/aanunapavnnvo,'
In slew af shone Said amendments Commission Imas dscldod to gins
analheeoppontseitytnnondidateo toapply fee all nbc uofngoniesofAdvtNs
312518 i.e. Cot No I Mole Censtablo 10000001 OeIyl. Cot Na. 2 Female
Constoble IGenerol oatyl. Cut Na. 3 india Reserve eaaelione ot Haeyaeo Stole Male denStubla loenerol oetyi, Cdl 8n. 4 nab Inspector ltdolal. cot -, No.000b lnspecton(Feealel. Iha oligibla oommdldotas who could net opplp
earlier were allowed to apply online through tine Haryonu Oral! laleviloirm
Commission webslte l.eycoyn.fyass,goy.iirl,nnr 10.15.2010 to 22ts.2n10 lilt
11.59 P.M and accordingly, In0 closing dofo for depnstt of tee Wee
25.10.2t10 lby 5:00 P.M.).
..
Keeping in vow the cunvunnnvn ol Ide cand:dales, lhn loon dale tar
apptyng oniinn agvinSl Ills 544. 3/2015 iS hereby entended up to lailj
Ootobee, 2010 tIll 1105 PM, lhrovgh 1-loryana SIan 5elnvbun Coremisnl.ln Websilevnunw.hoSo roam. Pheroollor, Webnile ink will be dl020lod The luSt dais
tordapnsll otfee isalsnounnndndoptn29th Ounober. 2010 lbns:00 P.td.l.'lh,
candidatos who in O0 alnoady applied onolest lIfe said Adet. & wont Id
opdote mo rel500ni Cold of the applIcatIon in ulow of the ooraedmonf V
moontl000d abeam, nba dota no apdofo them applicoiime hes been EoI.onttri to 20.10.2110 lby 1109 P,M.l.
,
soeeonony,
PboeolPannhlrulo
Ho,yana5taffaoteCtinocslfmlNnlflt -.
Doled, the 02nd October, 2010
Pogotbato.......- . . .
v,,sroo,.sbceeaae1ucaIvavnyn rrsaarrvlslrmsquunr:ualr053re
•'.
. . -.

<!-- page 23 -->

8.

IN WAN INSTITUTE OF TECHNOLOGY ROORKEE
80008EE. 808(0589 - 247687.880101080

Dated: 23.10.2018
No.11066688M-17!111082018-l9Ndodcsta0out0lthi2l6
- TENDER NOTICE
- . - Seisledd Teriddrn"ore iesttod for. the porrnhaso- of 'Worirstotion'.
Fw
Detott!s 81e8 Ce yIsit institute website:
www.tltr.ac.tn!adreistrotioniougeslTendurs CCI & CPP Porte)
bflniUomzec,u.rov.inJeorocereiaeá. Sealed tenders
slseuidreachmatestbyl T:OOhoursofl15/17J2018-.:'.
•
. Officer on SpciaI Duty (MM)

'IplE

DU:

ascoeierir Reedetsore IrS ented to
oetleer,deepeidtee wren to
sttwvdternsebe55orttheVeroOtYof
oh othoe,ssreent belts, renporsoin so
.i,eerb1wiwdtC.r*.s S C
ftiflhiSeleC POT LW, the Usher &
thwnerMth.s,,evsp. ,.doeserrresrh
=
ve=
s
o
o0eotoe C rosoersow
00
the Owner Pedwlre.Prntsr. t toe, Do
#to,/s. owpto,ens of th w.0550 pert

tdiood.rroge todoeisnCre

Himachal Pradesh
Public Works Department
"NOTICE INVITING TENDER"

Federated
Cost .

•-

237325

1. Spedat lepan to Shoslen House Bedding otlama Mandi,
Diotfi. Mend! (HP) (OH: P30 aired tsr-reeler stoewge tank
wndpiisnddingpainthigdistOmpertngandotherrepairwoob)

..

EMD

.'Mr.N.SELVA KUM'AR:. Pft- 98203 50726
s i oiosamorn@theh ducote

gaurav sehgaF0tthehinde coin

II1NDU

FHt

Soated8emraieieo,deronioom6&8ue nvetedby8oeExecotbveEvgineer MandIDmwor4io hOP POleD M rid for
theio8osteugwbemthoappeovodaodebpbecoptraclonseu10tedmFiP P000 soos(ireaduiohoofflceono
bet re20 112flltiuptalt 308.Mandeelibeopenedontk samedayat338PM nth+presenceotmteres800
cooniractwrooqile rsuthoorzed representabvoswhanrayfke to be present 8iihappentobe hotdayottthetender
eel be spat on fleet woddrig day The appbcafforo torobtiinhn 8-fl tender 10rm writ be re4e1ved upto 1 00 PM on
19 lliol8avo(Bl4flslrcuiobeallacdreddonorgthesubrTssnenntapp0catonfOfobtaow hetendenfumi without
EMt) apptrStloo will dot be accepted thidlhe iendeilbtni can be had from 8-id oftEx ofinst casir payment (Non
rolondabhe)uplo'5:OOP.Mon19.11.2018.....
: ..
.
The earnest motley er the shape o Nabonai(Savmg CertflcatelTirne
deponitaccountaisasinqaccosjjit(nonyotthe pontotilceand BanksotHirnachaiPraddo 'utypledgedinfavoUrot
On 000 motel 0050nopdoy Wino 005tdtendeloondioowel order orrd the tender doolnedhs(lt00000amnethtttotioyeolil
sororna lyberojected meeainestnioreysinceidheattachedssrthapplcabon TheotfeofthetendershaIibekept
00101120dayn.mehtveEr8nesrreseovesthelifl4httdrojectthelenderelorwot ni9nrngoorytewsoO
. tterreofw(oelo' .
.. .0.

PLEASE-cONTACT-.

Mr7GAURAV 5EHGAL
PH 98110Q6590

II

Sr.
No. -'.

-- TO ADvERTisE

ont tflginie
Totes
-if
cleneof
Urrit
'enden Contootor

4800- (54!- 1Y ta C One
..........Month
.
.-

GENERALCONDfllONS:- .
.
: Theteedertoennndatbeissuedrwthoneountsrctumrspetownanesseetfourvteebstwot.
-2. The conioactotn whose rates are abroorsnittyiosil may be asked to (ratt sh,the toil jusliilmtco of his rots bOng
wtwdnheeodtbedebarredb,ornnpetebstendewng forheireronthir
3. The,ennbwctwrwitinothivemorelhaudteowoshsishandaithhdmeof tonderandanlyupiucomnptetcnof worn
,.0 txnlbrytnd t8 g dtoano rot quoltyp eurrretoroturltr rwnrtnrrellbe wodwdtphnn St d nob 8th I
heionothaoirgmomthdnbnowo8-sinhatdtlostbethesrtedintheapgiicatóo.- -.
o
.''• .
., Sot!••.
...
.
.f
Executive Engtnedr.
0
.
' Moedt DIvision No. Ii,
i-lP/291e,le-15 :
HPdPWD Meedi
•.
.
4

Tire Executive Engisiser, Jirani Division, PWD (R&Bl, Jitonta, West
Tdpurs, invites n-tender ugainsi press NIT NO. I3IEE.JR910001201815 DemO 19t10!2Oi8. - . - - 0 For Censlruclibn at RCC Bridge over river Howswtn on Ok! Adantale
I Ch drop 5, BId kin i iCh 350K,rn(U d t.tABA.ROi!nH
impaivénneniofiprdothes by froviding WBM.PMG,Coetr (2nd
:
.
- Cat!)
DNITNO.I5OIDNITiSE'tVtZisltl-iB
-

Rn 50 Ii 15400
Estlrnutod cost
--'. s.5Q,ljZ65''.
EaneestMes6ey --: - - 66 (Six) eseethv, -TIme of Completion.
Last Date.of btding For bids— 1211112018 upto 15.O6Hrs.
For more details kindly visit: https:I!tripurotenders.gov.in

ICA-C -1489118

- -

-

-

-,
HIMACHAL PRADESH PUBUC WORKS DEPARTMENT
---- - - E.Pdocdedmnt-Noetip - - -'
- -- - - -- - -- - - INVITATiON pan rnflro (IFE)- - - - - 0"-- -- - -1,The EeeOTtioe EnqiovvrhlpPWfl Diotsion. ratshovrDtotit0aeqtwH.PonbetrattotGovonrotrfltt.Pisdiestho
out brdsonfemrate m ersirsosote do rgsystem s2CooerSyoiamtwrtheurderne uosedbsHengeorin
horntheerettieondopt*ooediontruotsestptrresleoiotetedvotth kPPWDoepathneroi.--- - - ------- Eot)neotid EMD
lies Cost Bit9lbto'
- Heetoefwodr
Sr.
:
- :. 10,11 of - ctase'ot
Coot ,,, Ho. Terder Codiracior
A
I.- Cwnwksotos nfl Soul. iTI ci Gargath is Tehsi - 229e.i88-ib- 2t22C5ti- -Two .5000)- irdothDieitKangry(HP)lSttoChorohrte8orot - - '-, - yearn - '
-:
-.
bulding- p0000n.-oWoter Supply 0' Saoty
- ------ - .- -. tontaftation, Septic- root and at Rain Water-:'--', -- -.
-. - - hamnnsungsyoiesi)..-0
,
-

-- -

-

DateotOniinePubllcabonrnO7 it 2oleat t0000rn 0ccanneni01d4ov1ni0ad5tadande0d4at08r807 (12010
uttO30hrsto29.11,2S18optxt700tho.TectmnicatbidaytaineOit11dsdo)beopen0doe'30,il20t8 atti.
torsO 0.t210t8 respenbvsoyThic tender torsos end 01w! detotwd condOnes winbe seed (torn the orebste
- .SdOEee000tiveEaoleedtt
- .
w000eepiends.gov.ts. - ...
- kiM SUCt-IPiA HPPwDfllvtnlon Foletrpar, Dielt kueghe H.P.,
.
Oebehs)fofotvienrerrelttterdohal Phadoidh
Hpix804imo.19 - . - - ABbot JAN SAMPARK

SHER-I-

,._ o0*.5__

'(iERNMENT°bFINDIA........... ":

MINISTRY OF PERSONNEL PUBLIC GRIEVANCES AND PENSIONS

ty

NATIONAL SCHOOL OF DRAMA - - -

REPERTORY COMPANY - - (Don ouroesme000s lesUto100s Ceder klie)stmy ot Cuttono. Goof. 01 IndIa) -

(DEPARTMENT OF PERSONNEL AND TRAINING)

Based Os Ftddier on 8-. 0001°'

KHAMOSHI' SILl SILl
Applications are invited for

fifing - up

lenSes By Joseph Stein
..Adsptstlon By Wail All COder ,

the post of Chief Information

he. deta'ds

of

-

Dentge & Direcelon by Sm. Sotesh Shanmso

Commtsstoner in the Central Information Commissior located at New Delhi.

- 20,27 & 26 Ontobue, 2510 it 6.30 p.m. Additteset show 27820001.2000 at 3.00 p.m.
eligibility conditions and the roforma for sending

articulars for consideration

for

-

the poat of chief, Information

ommissioner in the Central Information Cbmmtssidn may be
own)oaded ' from 'the Department 'of Personnel and Training

'ebsite: www.persmin.nic.in. The last date for reeipt of -the completed
I plications in the Department is 12 11 2018

avp. 32201/11/0007/1819

0

Abhimanch AudItorium

Bee000i010l tlo000e, flheBeraedeo Road.
New Deihl-l1000l
-'nottoto tee. 200. tOO. 5Ot- ore oneltobls-e '100 flopbmleo3m, eat,ewolpotr Chose.
ohxgeoeedas Road horn 24 October, 2018 onwards horn ti.omto 1 pm 82 pm to
4 pnn end fleealteble otw hour batoje the show's) me Audlmetisme. oettee broOmS
ticket or all dohomtnertemn sOil be asahhibto we omwo.bohkhiyskdnr.rarn. !dmy!nq500
forthe same to he made dl 022614-45050. Chhldten befOwn yemen: Mnbihv, Cernemas,
H Oboe and labi
Ip mnnittod
En,; 011.23353420, 23031105
.' - DAVP 09130115t006511818
- -

-

Ci

For end we bebalt or oroetehr otlomeor C I
e-bldo in bar )02i dover system Irwin, othdoeoieerttonthetohtowlegwodts:
Of
0.60. Come of CrC WaiteA000uoimalrteeeecsceetrao5fer
- ofwrelesolre000ujeeeflt(tMen'
The romplorororder doojmmnant loans
dnoumnet, 55db dartlOati000 oed nubmelot
rorleonsquahit9lrrgooitarla trekiddems, Op
dereiro;
-Dote ord Urns or dosnvtoadlegltiale
0) - Dote & lime 01 aldiring ooeeor
liii - Last note & tiers otoidUyira.nilot - 0010 eiSubmlsolne ot hand ,.n,rnr,s r
bate & lIme otCwmehervloUlrrlirmidvi

Dali &Thnmv otfinardat 8idlCovrr1

dii Cost ore-bid Dovumert
dlii 001005101 Earnest Horny 0epuor
to) cnenpleOwniie,e
ni, Ovdgeti-teed- NeI.0tMSt2302A3tttt-tttt.70.0051-2t00 - ii
Dstad:-ticth.2flut
Nd:tSlMS 2019,
"0
Oiled:. 23.00.2018

<!-- page 24 -->

9

UI 9011 UIUIC IC1I WI C1UIIU.I

hGc(1Ic4

ur'TI

• UUU • 24 3M4 2018

• i1aiT 3ttt ift aiiewidh4 •

fTPJ dildieli 3ITT cict uitiiiU

ie

• flauIfcDcU cc)cit eita'ie
i1t)1IU UOkil

t1t

Udllt!11G1* 31f rCICl
oIlo*lI550io'1

30IUI
8T8I35181l43
ie43f
T111115131124 ft
40100101
3110108119)9 / 0 '1 198480124
3oi1804o1
8011818150

30501010104301 . -.
\. —
— 20154
011045024
000104118
'..- ''014 6 0115012450141 r
0111801044311511
o 81114180
505011322040481210
o0104I18s4
s41o5088045 50481050
015104 3011010414811100481
01
34100201510011 41111821°I111I821424910148
0100401500231041 00 420422
0404
503310440104
20401844
5001131484
002150040010003515
81500198150
121042017

p0100110 £0410100
11 48150500100 s

5150110

•

I

31o80010448 010100104
31102T111 f10150 50501 311'l
50502104*1

3140100410

1115194931
915550448011
03014
931019981124500194013901
4001I50sl 3421801882400 s4
321040404381110
8041 i240448 011911280121
34818001500114050982180
o404q 300311110110241310104
01120114 341140 *41248 31118 41
5140014014128011150011014
50431012490110101

311400

011.3919151103185
0202014818140
322011481804
f00s150o0411 04944350ls01
904110011840014 50
312911718013131141W 3000181441
.4450915105024 12043os1181
.0100428
341l1113891804
31313180121001121
'50101150820124
11035010124
014819
502241184013040 *410001010411

2

24251081

011501* £4111110001018241811028200
02 1150211
04
3014011801010
30500104
11131503001010100
0418 4044s
'U £40101101
'Ur01 24, to
£4
0150111*1 4j141 82
1101041051

81t2050

040449950I
.010100310500
011

010440501*

1148*0110243150110
311000l0001I

31515000181 001010020433530

2Tid5c1 d1IdIETEdICIt

1UU

UI4d,1MW8

•31901111118001'U
2 430074224
08,400444
215915118
482404,2104011524
M18I321oT04
31904501185
0180311401

014024

04

1015181
51*0411
3150111011

*24304114
8110111024115
4s408224
I2400r 4014510181011000 4i
3511181150001
0410150180111245101101182401
185031150
4111110101
0112011021

11510111040818280104 5000101
01.8112 ols 401101
'ft
£4110100485090 24 04200
411104311501
05004
01111101104315013150101148104
101148481

I81

q50ç24'U 311511002802011

£415104, 011801480418
503181311150111311131115001
3004 '0121443140
0121111110450030004800
4318 I18Rl31l1100115118008
38o5010i5001 1804 s08i 04
31011431401151111 UI
11141284121241111 1880s128
503125050118 2404 0413
011145004.483101011041412
31110311

4009880

5124

48483814911041100141*400015051
30110100180404
0111101112818398150401141503107011
*1011110100*180318110110131800
5118801 8815421 1191* 1501815191 5118
01101019101-500143184991118310411

11p85001991*r48 4189121
511804011101011119011'100801501101
01151101 1001001-52110'51900 3o48

1151201015080(00003014)181014 • 2404180444*4951511400
1100*40+1801829159101
*50110501041818111
298850950*10482501150 • 041804124041001001
04040015151400041180404
004000*
940101501950982503004015082
50040040004049001 5191895011450140040401
83104 180100250 .57001 3019147 '111
00*1
011504891044000148483024,
411804 9100 1804 *11990409891 0191408050040401195004

041 (4) 01s04ift4f 180414110 00 189104 *41511 940
0400
1882 00 0185100
*19100 50 50990 4 01 95114948 00

to £50040401 'U,1800 00914304 11014411

01325111130418,113818013411840
509533141453,42485501104502448071890401011120110
5028 50 3)05 8050 04 45001 24 4404 11 041101
10414819
3540, 000,r0449100lto0841
10 1930511191110131515001103180000145084101119005112100
499 0404 19144118901215 52100
2483924 01881501119 00 04w 24 11491124 453 I
3198201014051',,480004210804
00 00111412299501015051 040098000 0011k400400104 0419111101850,8104044000
51
501490184011350824140404 00 too 8231981900019181101151 24(019010104*1040448
150 109982 81o,o118'44150 50 41I 9401)4 501314404311404 3404 304 50 04 30809941 01.
482404 01 80109 0184450 11 419914 18119 450 91949 1891029911002 08111201qTl50614091I51*91901T18l
5051 9101* 0111 39218110 00411 11011811 50150101482 99501405148152111
31010104500411505101
0494 0410104
1210014128, .5001111851505191041 312111240450180148305940000
11800
509501501*1
0194100*00500104*110
to) 309914182045914013014149 18*0101 5011914
922011498229* oort'U 0099(889
2480151814424118*40410415
50430440500104950500451 040418440094 184001040 4490104 0490049104I

4404
040004102400502404
44913891504240404
311* 509 50 3043104*111111*
010118111104900604,5081
04002440404505031019198 21101124 5011 01 0121118
01001810100034315000,118242250
01 2)111 3228301880' 51100 24 0108914
911318103118300401

14i?TiJT UDto1 JI1T1T2T'
.5110043151410191*11101050 5001409101901001804r*504
1119181800 85010 31,115304
04043040404910
01100043101100080501818101911221
• 2915001 30130488
9111384.389503119-9110051511
811411851189131
_____
- 4142*9203017040509098200
11001467.4085514710048
4050010100045111010050040310 011181001 f*1411191*l
0404 30810448905011010*
0004*850045001*11101811101
olls00 1810501 51091380 oIl
s's 04, 00w40 00
£10 si,
91150508 01111011145119183114*,50 10104040150345000048
81111911141*130805018848825001111
,o.480140480018 94111044004110
151101150118 811812100 8115118 13410 to 8114,1040914 40 10151 04910118

31Th1F1% Ieiiei

0104
04. 0104 f04o
3dI 2210.004300054504411241110

'

04182504140048182904

eli1t

44 f91449831110091810000149043034001494044019511010093012404011024101.1804931

1018'100 0400101 010110*0 301 444400501o01'o4510
120
5082
008090204314 00
s104 1111110051011 '1501111151 00, 5050113419150 '54 511917 0140
5011415141400119 £s01 4154 2101*2241820051041850*404 53(2)341111501j13(1> (00)
00418011018051500414409050
82510038118 3140 2018 I

50981

0104 505191104 01* 04 00
9404
41 r 04040400
5115000301122245130014

3014010414410150450

0148040401450011341919
2804045044513110485801
7 97 0015101 401)1850310114 '009954
380 94 11010
3)40350 300013 11401 19 11185011800
019200 24 300 90821054 1350191118
0404500081500310924
88911000 08 50 304 *131179 019
50513170144041508534180

9409815041042104
40 çlolo 390301*4,480411885

0404,110048198509

9530128800190445131011024119
1099241180)1 3110431124300
21 so4014 10535051311
040410109502435104

5010120785 #o44'o 11

404810000044330*0050

000318001104914444181
50440141401*)

2448131101 oo40o9ojs00
810401934833080855040181

.1151130. 9149151f '4.-i00.
5040148,14,051/451932911099/200824

'1215105. 00. 20 lB

(2250549.93 koi* 84019079 oolcololo1 31101519 90143 17 81849010151
20189148 1841193332I41lo19111540I*$I-)
39150*04, rswo,n04 07 00,0,120180400i41,100041734oi0143n0410483114118 I
3011115151150*13039.0203311*59911410 10SV9,4 50454101114514 194082/510141 4,401112804
4004*o491101184929(qlkolo 4sR0091o04o 004 181500140118 04 04 0098
5884/018251810 12,11.2018 0135 11111010 1111t1)550 34141108048 1.151050.81391519121018191*34101211
505011830103101150104101)94 31950g171311 yo)s1151101103811*311040045150317150

0511,51101*853114150041

547110439 4410415318111

330799804,1,0999950

4340o1440041'rslti

DELHI MEDICAL COUNCIL

00055511011 01 815 IF 05011
110,111 101-600,111051011,1111110,1110111812111151111012111121.

1015011!1805 1510,1115 lln.lIlssll5l02

ciicii
500li

•

81i

15. 2II-0012110008 LIII,).

ALLAHABAD BANK

48 .500,1048*400
(o14' 01015140420034851011 0)0)01004

* 1,00'5140*011111'5)

o,,18 .o9sso,,9 011331,0850191448 nQn9404. 110041140101011 sTh'sjll ,91,1514,09341015'S
1010 21 8 Ok 10111+40 $o SIll 19115008554 480 02100.) 511100011 1000 01 345 0

0110015010101,41*4050011401151
*u4889,8*w*0,404 98)48181.84000
119e,,044
9148*00*84081484fw10*.+4488144-P450 184*4 48
k8401,4101848*W8481u81*T 8,404
*81* s.,. 143450011830111115100114 15010,501515181*
401*81*I810Q 81* ,.,sw
82318,17440.08 4IWI81810
48 *w,

15150 59 40 54 10 3148 011144 7145 .14 04 1001 'III 15 I
40111 .191, 05 11r'moo 4090111,110110 8 811,1327 5115010 0411500081'1lllll 150111

0110518,14810111.8015111,101510005101104 0'I014,l101002 1015 09 I00o 8111
40 ,o4o, 01115500148015015015014711190101001155011* 1l 40-9',4041

89,0,

I• 211-121340181

Dolhi Mo.3icol Coono4, loqo24ron opprovod lflnblol0500l 0,
Co,,smo,00l 08100 14180,076000 Sq. Fl. to 10.000 Sq. 15.00

41s,000,250o,o,m 81504080101034*3140 0050$.dk*.010*os,1009
15011011185

84,,
W*8181W'0081WW**'& .0040000-6 40.IL4801118.
-48*
o 84

81* :** 1100o 5*
I,'

Do lb) on oobighldi,00l 09,108 810 01 long to5 10180 81,1 Ii,.
SIbyl 41048 151010,04 and p041500) 13 consplllnly by shoque.
(No 501811 Irofl,S5130fl). 1112501114 0tI1108 1813,0104 010 lend

loopo,lysndplopololdel8ilso1010000ddronl.
GIIlnh lysgl
R.gl.tror, oolhi M,511091 Coons)).

00,0051 310012010.Il5tt0505 50101 03010018

7404 '4119P7 99793
('41011 915017, 0040 1,191011 81 0140 50 111745 110101)
I1,'11418841940,'I4l19911*- 110001
'911045* 30119181415441 91111811*119 11(3 89181
0290 511)7 7911 00,0 114 40 000001090 1257', 01 040 1050 1454 001)
485091 ,1414809550490110I1110015'110015*I
'I 511015011341853 021150351120181
02 01*5919500150 01911111051*
Os 1148101,11115110 100192141154
148,50 *9, 159040 51210'S, 31481201.

1,5411, '11144 s40
110101 0508 9000

1011) 1140480,19041' 11500)
"1 In '+4 04', oIo *9 00 405100

04

01s82,,510910000,

RT 14c18-814

34k4ns1 7114311871311480-4434183171

04

04371 013941 31T19t71

371

3915418

3101041110122.04184)1011-1106001

vrjpi)

(ci28ir4cs

.00

104 4j99541 301549104 5451

11,1105*,.
s,* 04

81 f04

04014854 4104T 2091511011 * 50 111,11I 39104511804

l3141f*5l90) 0431k %1 14107)1 9lI104 1149I 311 4)9094011 4131)9

1150

501ff134 34R ofsT18rJr 104911111(3 *54ssiz www.persmin.nicin

80(3 1Sf Ff8510118 12.11.2018

814240240 hon',. 00100,0-150181 ,0.'l 80.0091 10'1'11745'I 8s
1511111, 18.50190 0,510,0110', 00n54t50 04194481050481191

ij304t "iI *1

SI&1141?1821 1)8,14,718 kll1sa * I 91818 f04I1T

01022002251. 0011190115004581 00 440040977001010

42418

8)t 5,91(371(3

I

011
so3lonluls4.8 (04)
1000104

01

50201915001505050

06

51t513.Sf3. 32201/11/0007/1819

I
25084904400401198200.8180491111

51

48443021 011 0010111

50019041118001, V. 5414719041198
3181005011 40o'o 10115409450401
121150118 305 04 0001 01497,05 04
000511 3500 04 502010111 10954 *4 18401
100105*3150)

*8100
311151

01

01

02

00500 051)11 00 8142 94110 18110 I
--

22

.300,5750511010 10100,01 0001119,

80.18.
44

Os

s10' -1218
,
41(915 9141( 3uq

4208*4 '75121111005411859

85004151181040604)

481
'8401 sol 50 9.50 04 8115018 915 0100 flon, 50 40101 8ojo51101901 1110001010901 5190 81 510011181
190410000052

<!-- page 25 -->

J_

'
BT lI
riiin llf
f9tqIguR
fbrl9lrf 911101EN11 FT 1 R1
cttti ilhiWoiR
t r Riqq oioitoiif
iiqi
joiw
3TT
3I9(T1
9
9e
tO(cfflTl
114Eh1 11? 12
I91I1 1RTI T3( fhhFfl 9IR191 RI11
19
1rggt 021
u'l at

iici 34k$c4l- aa
I

t

St

30 fD1 vtts 0 I9IRl1

strg

tf

grzicr

9

rgr

qap

rgr*Ioitiz

il91Ril
_______________

SIO sto0lubsI)T09 oiRwiwow/ur Ibsuro ortm9ui
900 wal
01oteib t -fibRet Rvitb27.11.2010 5* hat othtes vituac sit

fciici fttii 'ci'i

1iTCD,

3UTT)

fr

fc'
r Idk

i9T .3i1T

bigot

r ti
i 1R t1!

i

-It;*i

ftft

T f

!

j

I(

fl

af c u
riir

j

cuj

fp

twww persmin we in

:

3t

i'1

--

kie

ff1

Tf 1

4913.3ç

*1

007/1819

I
4UiT

(I)tcUt1?1,

ir, p.T

.1cD

51
WI

Dr. Ram Dayal Muuda Tribal Welfare Research Institute,
Rancln 834008
Ref no. -773
Ranchi, Dated 23.102018
ression of Interest
Dr. Rata Dayal Muida Tribal WelfareReseaseb Ji stitote (TR Ranàhi invitia lixprension of macrest (901)
from inleeestedUniveesitiruDepart ntbfuasiveesitius /Govt. Organization! Nan -Gavt.,Orgnoizazion/
Research Organizations for undertaking various National! State level Research Projects of TRi,.Ranahi
daringtheyear2Ol8202O..........
tnterested.sgencies ate hereby requestectlo fubmitlitipiession of interest (901) along with technical giving
relevant details of the orgaitization necessary for evaluating the cornpetenciea on or before 19/11/2019 by
4.3ORM.
The intending agencies may submit their bid in seated envetopuon orbefore 1550 duo date. recliitical
prepaaalobeuldbnsnatritina separsteettvclopeclearlymarkedinflOLfl 'TECHNICkLPROFOSAL

FOR " RESEARCh OF LIFE AND WORKS OF SARERI) -TANA BIL4CAT-/sNl) MAHftrThlA
CANONS" written outbe top of the envetope. These envelopes ore lobe addressed lathe Director, Dr.
Raw Doysil Muada Tribal Welfare Research lnntttute(TRI), Morabadl, Runebi-934008. TRI wilt not
berusposaibtefoidelayin trwssitsordamogesorloss uftenderdocumetatseetbypost.

Togicsforthereteorchworlc
.1.
Mahalnia Gandhi and-Saheesi Jatra Tanafihugat: Philosophy. of Dlsnbedfeaee, Nan.
Cooperation, Nnnvltslence Saiyagrah and DIalogue
2. - Unification of movement led-by Mabaiaoia Gandbiand Sahieed Thno Bhagat and their
effect.

-

-

-

-

-

The totalperiod nfthepsoject shall be 12 months with Intel projooicas
. Topio-t-Rs.2,50,000,/-ouly - .
.
Topic2 Rs.3,5O,000,/-nnty
•
• - •
.
Technical Bid will beopeueslon27/11t201&at3.00P.M intheoffice oftheDirector,TRI,Ras,ch1
Only those atiunths rl,khfaifiuitethaiea!e,*eria willbeConsideredforprusentaeionofprojecn
Terms of Reference (TaR) and other details can bepbtained from the odhice of tlteTRl no any working day
during offIce hour to meetcencerned Nodnlperobüand the annie can also be dowotooded from the website
www.lriJharkhaod.eomuudeglendersiotineaection. •
----- • - TRI, Raaclsi reserves all righit to accept or reject alt arany of cite EOI', at any siege without
assignIng alsyreasoas.TRJ, Ranclsi-also -reserves the rIght taeagnge/empanelnne ormore firm
dependiagonreqolrement,.
-

P.Rl94294-WefrarC(1049)D - - -

JI.erqyi$t.ju

•1•..__._

•

-

4Ie-

s) hoet

4 .ø... 2

.

(fsreoau)

flfT 12.1.2O18 ti-

TTt • ..

•

1Iitgli

Vi

nhT

iiI.

at?-lroittib'i)drt0'tsr'roear v0oPr911

ibwlOtibeto0unt4hn4ttt9ewwwieepsgorin*5g
sisdirta
iioz.zuio : --------sic i
asnsmeTsafl aees z 3nise.o, ao5m

I

-

On
i vlalu'j190 ei4nh l5*hnz fun natoLl rod Ee'ltth etfln
4011lf9t(s1tsft btr.:lro.'nIio ,e.iih
*
52.000/-v fr
05t'h$40( 0t'roth iterod
tdindr5*rovi-tarsfu
5qb3Srm/0h!04s90hii*'1f.
2rslsshaa*Ism4ib9rono5*aaolta
tibo9fu9tRso

•

Director

- --.-:

-:

:,. -- -

0it$.dl..r Ol/tttts4/sit-142 •
-. -rit us 0000q'yn.u9lonm/55ans91 seTtit iflt). tsidritt m
vittin,90ane019srdrt-l. 'i'altat-rtanz ibi1t-doj--eatesa
I us wfdrtvtrst 190stklitsrt
rvs:90titifi e,.)sl Ret-it
: -.
•
- a ItncT99lt9tr9I0tl3s12OMWuJisluOMW)
0ti00lt 65MW)
4.drt(ta66
- -. - - s'15noitts27.5sMwe2o24.2aMwl
.i_
- -.
&nitzetrtl,2&t4MWa241a.asusvt titsriolkIRie-5/Ptf90Ieisi5oT IfIt20155ibt7;005s
-

ftyforf n'*41 n eonok5* efitlishhlfro oon l3ltao,a ott iron
Fs14rro1sibot'IBtBiototspi - -- - . : ecetinpnj/bb,nis.proe.abepsoems cam'ttiwom bbwb go I

(c11Str82- Cr. P.C.

1Ft)

Pr orPr9qi1 nt's (s) RI°ss n.iie s aft
'list fiql0hl-'soe-5-te. 5th/sb. onsee-fkN 5*ot. oneno prc Rot
(2) allstosy @)-.ibm 'roll sIlo 'sb (4) 91'5* odfu 55559 4i.4
5191/5554. 0190 fh5stIst. 001001159 thlfl * 00.3tt5Sl9, 004
347/lI. 55190400-9/409/34 'IL09I. 'sT -'5*9sit. Rot

orb Rsst9Thtoei
919f.5* ils Roestllct Ret otto *
reRoot fibflleqi.g 4k'ae. SOR5*IT99 r541Thor'r0119* E abs
otI'l9r1s4 sre nlllfor one Ret nor ib fit 311113sot Rib-s ej'iss
ory5*ar (si stflietisYlit ste
sIten.s,
ES5*flfqrtlij oiR4us0
orqs.nsraste. unto 347/Il nreo 458-9/405/3401.0.91 estte allot
01rLRuiI * otfitfisss libiliC llt•n 4. alIbvilol. 005*91 ott orsill
sib

fb599124II.201a5*00009SstRer34Re*t
-

DPl789/SH0l18

-

e.n'll ufFobn 51901100. 0EJst tosIftasir!
5*510. 50. Ilt094l Rflgor
nemeei 5*51. ftuil-a:

::...i-tu. :0

<!-- page 26 -->

A

Pages 25 - 45 has personal details of the
applicants which are exempted from
disclosure under Section 8(1) (j) of the
RTI Act, 2005. However, a list of names
of applicant is given

<!-- page 27 -->

Applications for the post of Chief
Information Commissioner
S. No.
Name
1

Lakshmi Prasanna Ch odavarapu*

2

Narendra Ku mar Si nha*

3
4
5

VipulVijoy*
Rohit Nandan*
Jatinder Kumar Sharma*

6
7

Sudhir Ch owdhary*
Gurugubelli Surya Prakasa Rao*

8
9
10
11

Neeraj Kumar Gupta*
SanjayBasu
Kishore Madavi
Yashvant Singh Jowhari

12
13

Dr. U grasen*
Dr. Rajendra Singh Sikarwar*

14
15

Dr. V. Sekar*
Mani Shankar Prasad Sinha

16
17
18

Vineet Chawdhry*
Dr. D. Bhalla*
Sh. Dharurkar Dilipkumar Laxmikant

19
20
21
22
23
24
25
26
27
28
29
30
31
32
33

Leena N air*
R. Ra jasekharan*
DSSaksena,IRS*
Deendayal Prajapat
Yudhishter Sharma*
Akshay Kumar Rout*
K.V.Sreenivasan
Dr. Y.P. Rai*
Bishwamitra P andey*
Rajendra Sharma
DeepakSingh
Sunil Kumar Si ngh*
BimaiJulka
G.K Suresh Babu*
K. Ratna Prabha

<!-- page 28 -->

34
35
36
37
38

Dr. Lalit Varma
Ajay Kumar La1*
Jadab Kumar P a1*
Anil Kumar Singh
Jagdish Prasad M eena*

39
40

Arun S rivastava*
Anoop Kumar S rivastava*

41
42
43
44
45
46
47
48
49

Dr. S. A mbigaidass*
Divya Prakash Sinha

50
51
52
53
54

Sheo Sharan Srivastava
I. Ganesan
Ajay Mittal
F. Sheheryar
Dr. Ish Kuma r*
SudhirBhargava
Narender Kumar Bhola*
Uma Kant Lal
Seema Bahag u na*
UpendraSah
Manish Shivahare
K.BNarayana

55

Lt. Gen Naresh Kumar Mehta

56

Mahesh Chander Bagarwal

57
58
59
60

Lamba Tejpal Singh

61
62
63
64

Dr. Vijay Satbir Singh
Pukhraj Singh M a lik*
Anil Kumar Upadhyay*
Shobha Upadhyay*
Dr. Jayesh G Mecwan
Dr. Kush Verma
Navneet Kumar Gupta*

<!-- page 29 -->

0
Late Applications
Name

S. No.
1

H.KDas

2

G.RAloria

3

M.S Dagur

4

Deepak Mishra

<!-- page 30 -->

Note reqarding selection of Chief Information Commissioner (CIC)
•

As per Section 12 (3) of the RTI Act, the Chief Information Commissioner and
Information Commissioners shall be appointed by the President on the
recommendation of the Committee consisting of:(i)
(ii)
(iii)

The Prime Minister, who shall be Chairman of the Committee
The Leader of the Opposition in the Lok Sabha
A Union Cabinet Minister to be nominated by the Prime Minister

Explanation:- For the purposes of removal of doubts, it is hereby declared
that where the Leader of Opposition in the House of the People has not been
recognized, as such, the Leader of the Single largest group in opposition of
the Government in the House of the people shall be deemed to be Leader of
Opposition. Copy of the RTI Act is enclosed.
•

There is no time limit for intimation regarding meeting of the Selection Committee in
the Act or Rules.

•

In the past, when the Chief Information Commissioner was selected in the year
2015, two meetings of the Selection Committee were held. The first meeting was
conducted on 11th December, 2015. The following attended the meeting:(i)

Hon'ble Prime Minister Shri Narendra Modi

(ii)

Shri Mallikarjun Kharge, Leader of Indian National Congress, the single
largest party in opposition in Lok Sabha.

(iii) Shri Arun Jaitley, Finance Minister
•

The Second Meeting of the Selection Committee was held on 16th December,
2015. (Copy of the minutes of the meeting are enclosed).

•

At present, there are vacancies for one post of CIC and four posts of lCs. Two
more posts of ICs will fall vacant on 21st November, 2018 and one more on 1st
December, 2018.

•

A list of applicants who have applied for the post of CIC is enclosed.

(Dr. C. Chandramouli)
Secretary (Personnel)
20th November, 2018
Additional Principal Secretary to the Prime Minister

<!-- page 31 -->

Note reqardinq selection of Chief Information Commissioner (CIC)
•

As per Section 12 (3) of the RTI Act, the Chief Information Commissioner and
Information Commissioners shall be appointed by the President on the
recommendation of the Committee consisting of:(i)
(ii)
(iii)

The Prime Minister, who shall be Chairman of the Committee
The Leader of the Opposition in the Lok Sabha
A Union Cabinet Minister to be nominated by the Prime Minister

Explanation:- For the purposes of removal of doubts, it is hereby declared
that where the Leader of Opposition in the House of the People has not been
recognized, as such, the Leader of the Single largest group in opposition of
the Government in the House of the people shall be deemed to be Leader of
Opposition. Copy of the RTI Act is enclosed.
•

There is no time limit for intimation regarding meeting of the Selection Committee in
the Act or Rules.

•

n the past, when the Chief Information Commissioner was selected in the year
2015, two meetings of the Selection Committee were held. The first meeting was
conducted on 11th December, 2015. The following attended the meeting:(i)

Hon'ble Prime Minister Shri Narendra Modi

(ii)

Shri Mallikarjun Kharge, Leader of Indian National Congress, the single
largest party in opposition in Lok Sabha.

(iii)

•

Shri Arun Jaitley, Finance Minister

The Second Meeting of the Selection Committee was held on

16th December,

2015. (Copy of the minutes of the meeting are enclosed).
•

At present, there are vacancies for one post of CIC and four posts of lOs. Two
21st
November, 2018 and one more on 1st
more posts of lCs will fall vacant on
December, 2018.
A list of applicants who have applied for the post of CIC is enclosed.

(Dr. C. Chandramouli)
Secretary (Personnel)
20th November, 2018
Additional Principal Secretary to the Prime Minister

<!-- page 32 -->

F.No.4/13/20 18-JR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November21, 2018

Meeting Notice

The process for filling up the vacancies that have arisen/likely to arise at the
level of Chief Information Commissioner in the Central Information Commission and
Information Commissioners in the Central Information Commission has been taken
up.
2.
I am directed to convey that a meeting of the Committee constituted as per
Section 12(3) of the Right to Information Act, 2005 is scheduled to be held on
27.11.2018 at 7.30 PM at 7 Lok Kalyan Marg, New Delhi under the Chairmanship of
the Prime Minister of India.
3.

The Agenda of the meeting will be sent shortly.

4.
Kindly apprise the Hon'ble Finance Minister to make it convenient to attend the
meeting.

(Lok Raiani\\
Additional Secretary
Te1.23 094010

P.S. to Minister of Finance, Government of India.
Copy to:
1. Private Secretary to the Hon'ble Prime Minister
2. ..S.toMoS(PP)
PSO to Secretary(P)

<!-- page 33 -->

F.No.4/13/2018-IR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 21, 2018

Meeting Notice

The process for filling up the vacancies that have arisen/likely to arise at the
level of Chief Information Commissioner in the Central Information Commission and
Information Commissioners in the Central Information Commission has been taken
up.
I am directed to convey that a meeting of the Committee constituted as per
2.
Section 12(3) of the Right to Information Act, 2005 is scheduled to be held on
27.11.2018 at 7.30 PM at 7 Lok Kalyan Marg, New Delhi under the Chairmanship of
the Prime Minister of India.
3.

The Agenda of the meeting will be sent shortly.

Kindly apprise the Hon'ble Finance Minister to make it convenient to attend the
4.
meeting.

(Lok Ranjan\1\\
Additional Secretary
Tel.23094010

P.S. to Minister of Finance, Government of India.
Copy to:
1. Private Secretary to the I-ion'ble Prime Minister
2. P.S. to MoS(PP)
3. PSO to Secretary(P)

<!-- page 34 -->

F. NO. 4/13/2018-JR
Government of India
Ministry of Personnel, Public Grievances and Pensions
(Department of Personnel and Training)
North Block, New Delhi
Dated: 2..3-tQ-2018
Subject: Appointment of Chief Information Commissioner in the Central Information

Commission.
Under the Right to Information Act 2005, the Government of India has constituted the
Central Information Commission, which is located in New Delhi. The powers and functions of
the Chief Information Commissioner in the Central Information Commission are as per the Rh
Act, 2005.
2.
It is proposed to appoint the Chief Information Commissioner in the Central Information
Commission, to succeed the present incumbent on completion of the tenure likely on
24.11.2018.
3.

The Act provides that the Chief Information Commissioner -

(I) shall be a person of eminence in public life with wide knowledge and experience in law,
science and technology, social service, management, journalism, mass-media or
administration and governance.
(ii) shall not be a Member of Parliament or Member of the Legislature of any State or Union
Territory, as the case may be, or hold any other office of profit or connected with any
political party or carrying on any business or pursuing any profession. It is clarified that
cessation/termination of holding of office of profit, pursuing any profession or carrying
any business is a condition precedent to the appointment of a person as Chief
Information Commissioner.
4.

Persons who have attained the age of 65 years shall not be eligible for appointment.

The salary, allowances and other terms and conditions of service of the Chief
5.
lnformation Commissioner shall be as may be specified at the time of appointment of the
selected candidate.
Persons fulfilling the criteria and interested for appointment to the post of Chief
6.
Information Commissioner may send their particulars in the enclosed proforma, by post, to
Under Secretary (IR), Room No. 215 A/Ill, Department of Personnel and Training, North Block,
New Delhi or through e-mail to usir-dopt@nic.in so as to reach before 5:00 PM on
November, 2018. Persons serving under the State/Central Government or any other
Organization, should send their particulars through proper channel (administrative
Ministry/Department of State-UT/ Central Government or the Controlling Office respectively).
(

(Rajbir Singh)
Under Secretary (IR)
Tel: 23092356
Note:

Rh Act, 2005 and Rules thereunder may be referred to by intending applicants for

general familiarization, as could be appropriate.

<!-- page 35 -->

Proforma for sending particulars for consideration for the post of Chief Information Commissioner in
the Central Information Commission

Please affix the
latest passport
size photograph

1. Name
2. Date of Birth
3. Present Address
4. Contact No.
a) Telephone (along with STD code)
b) Mobile
c)

Fax

5. E-mail Address
6. Educational Qualification
7. Area of Eminence
8. Present Occupation
9. Achievements/Work Experience
(As per Annexure)

Date:
Place:

Signature:
Name:

<!-- page 36 -->

F.No.4/1 3/201 8-JR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 21, 2018

Meeting Notice

The process for filling up the vacancies that have arisen/likely to arise at the
level of Chief Information Commissioner in the Central Information Commission and
Information Commissioners in the Central Information Commission has been taken•
up.
2.
I am directed to convey that a meeting of the Committee constituted as per
Section 12(3) of the Right to Information Act, 2005 is scheduled to be held on
27.11.2018 at 7.30 PM at 7 Lok Kalyan Marg, New Delhi under the Chairmanship of
the Prime Minister of India.
3.

The Agenda of the meeting will be sent shortly.

4.
Kindly apprise the Hon'ble Finance Minister to make it convenient to attend the
meeting.

(Lok Ranjan
Additional Secretary
Tel.23 094010

P.S. to Minister of Finance, Government of India.
Copy to:
U<'rivate Secretary to the Hon'ble Prime Minister
2. P.S. to MoS(PP)
3. PSO to Secretary(P)

\P\ '

<!-- page 37 -->

• F.No.4/1 3/2018-IR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 21, 2018

Meeting Notice

The process for filling up the vacancies that have arisen/likely to arise at the
level of Chief Information Commissioner in the Central Information Commission and
Information Commissioners in the Central Information Commission has been taken
up.
1 am directed to convey that a meeting of the Committee constituted as per
2.
Section 12(3) of the Right to Information Act, 2005 is scheduled to be held on
27.11.2018 at 7.30 PM at 7 Lok Kalyan Marg, New Delhi under the Chairmanship of
the Prime Minister of India.
3.

The Agenda of the meeting will be sent shortly.

Kindly apprise the Hon'ble Finance Minister to make it convenient to attend the
4.
meeting.

(Lok Ranjan)\\ '
Additional Secretary
Tel.23094010

P.S. to Minister of Finance, Government of India.
Copy to:
1. Private Secretary to t
'-2.S. to MoS(PP)
3. PSO to Secretary(P)

i'ble Prime Minister

<!-- page 38 -->

F.No.4/13/20 18-JR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November21, 2018

Meeting Notice

The process for filling up the vacancies that have arisenllikely to arise at the
level of Chief Information Commissioner in the Central Information Commission and
Infoiuiation Commissioners in the Central Information Commission has been taken
up.
2.
I am directed to convey that a meeting of the Committee constituted as per
Section 12(3) of the Right to Information Act, 2005 is scheduled to be held on
27.11.2018 at 7.30 PM at 7 Lok Kalyan Marg, New Delhi under the Chairmanship of
the Prime Minister of India.
3.

The Agenda of the meeting will be sent shortly.

4.

You are kindly requested to make it convenient to attend the meeting.

(Lok Ranjan')
Additional Secretary
Tel.23 0940 10

Shri Mallikarjun Kharge,
Leader of the single largest Party in Opposition in Lok Sabha,
9, Safdarjung Road,
New Delhi-i 10011

<!-- page 39 -->

F. NO. 4/13/2018-JR
Government of India
Ministry of Personnel, Public Grievances and Pensions
(Department of Personnel and Training)
North Block, New Delhi
Dated: 2..3-Q-2018
Subject: Appointment of Chief Information Commissioner in the Central Information

Commission.
Under the Right to Information Act 2005, the Government of India has constituted the
Central Information Commission, which is located in New Delhi. The powers and functions of
the Chief Information Commissioner in the Central Information Commission are as per the RI!
Act, 2005.
2.

It is proposed to appoint the Chief Information Commissioner in the Central Information
Commission, to succeed the present incumbent on completion of the tenure likely on
24.11.2018.
3.

The Act provides that the Chief Information Commissioner -

(i) shall be a person of eminence in public life with wide knowledge and experience in law,
science and technology, social service, management, journalism, mass-media or
administration and governance.
(ii) shall not be a Member of Parliament or Member of the Legislature of any State or Union
Territory, as the case may be, or hold any other office of profit or connected with any
political party or carrying on any business or pursuing any profession. It is clarified that
cessation/termination of holding of office of profit, pursuing any profession or carrying
any business is a condition precedent to the appointment of a person as Chief
Information Commissioner.
4.

Persons who have attained the age of 65 years shall not be eligible for appointment.

5.
The salary, allowances and other terms and conditions of service of the Chief
Information Commissioner shall be as may be specified at the time of appointment of the
selected candidate.
6.
Persons fulfilling the criteria and interested for appointment to the post of Chief
Information Commissioner may send their particulars in the enclosed proforma, by post, to
Under Secretary (lR), Room No. 215 A/Ill, Department of Personnel and Training, North Block,
New Delhi or through e-mail to usir-doptnic.in so as to reach before 5:00 PM on 12th
November, 2018. Persons serving under the State/Central Government or any other
Organization, should send their particulars through proper channel (administrative
Ministry/Department of State-UT/ Central Government or the Controlling Office respectively).
(

(Rajbir Singh)
Under Secretary (IR)
Tel: 23092356
Note:

RTI Act, 2005 and Rules thereunder may be referred to by intending applicants for

general familiarization, as could be appropriate.

<!-- page 40 -->

7

Proforma for sending particulars for consideration for the post of Chief Information Commissioner in•
the Central Information Commission

Please affix the
latest passport
size photograph

1. Name
2. Date of Birth
3. Present Address
4. Contact No.
a) Telephone (along with STD code)
b) Mobile
c)

Fax

5. E-mail Address
6. Educational Qualification
7. Area of Eminence
8. Present Occupation
9. Achievements/Work Experience
(As per Annexure)

Date:
Place:

Signature:
Name:

-

<!-- page 41 -->

37

Annexure
Details of Achievements/Work Experience in respect of candidates applying for the post of•

Chief Information Commissioner

Sr.
No.
1

2

3

4

5

Post

Organisation

Period
From

To

Details of achievements/experience
(in brief)

<!-- page 42 -->

F. NO. 4/13/2018-IR
Government of India
Ministry of Personnel, Public Grievances and Pensions
(Department of Personnel and Training)
North Block, New Delhi
Dated: 2..3tQ-2018
Subject: Appointment of Chief Information Commissioner in the Central Information
Commission.

Under the Right to Information Act 2005, the Government of India has constituted the
Central Information Commission, which is located in New Delhi. The powers and functions of
the Chief Information Commissioner in the Central Information Commission are as per the RTI
Act, 2005.
2.
It is proposed to appoint the Chief Information Commissioner in the Central Information
Commission, to succeed the present incumbent on completion of the tenure likely on
24.11.2018.
3.

The Act provides that the Chief Information Commissioner -

(I) shall be a person of eminence in public life with wide knowledge and experience in law,
science and technology, social service, management, journalism, mass-media or
administration and governance.
(ii) shall not be a Member of Parliament or Member of the Legislature of any State or Union
Territory, as the case may be, or hold any other office of profit or connected with any
political party or carrying on any business or pursuing any profession. It is clarified that
cessation/termination of holding of office of profit, pursuing any profession or carrying
any business is a condition precedent to the appointment of a person as Chief
Information Commissioner.
4.

Persons who have attained the age of 65 years shall not be eligible for appointment.

The salary, allowances and other terms and conditions of service of the Chief
5.
Information Commissioner shall be as may be specified at the time of appointment of the
selected candidate.
6.
Persons fulfilling the criteria and interested for appointment to the post of Chief
Information Commissioner may send their particulars in the enclosed proforma, by post, to
Under Secretary (IR), Room No. 215 A/Ill, Department of Personnel and Training, North Block,
New Delhi or through e-mail to usir-doptnic.in so as to reach before 5:00 PM on 12th
November, 2018. Persons serving under the State/Central Government or any other
Organization, should send their particulars through proper channel (administrative
Ministry/Department of State-UT/ Central Government or the Controlling Office respectively).
'3.\o
(Rajbir Sngh)
Under Secretary (IR)
Tel: 23092356
Note:
Rh Act, 2005 and Rules thereunder may be referred to by intending applicants for
general familiarization, as could be appropriate.

<!-- page 43 -->

Proforma for sending particulars for consideration for the post of Chief information Commissioner in•
the Central Information Commission

Please affix the
latest passport
size photograph

1. Name
2. Date of Birth
3. Present Address
4. Contact No.
a) Telephone (along with STD code)
b) Mobile
c)

Fax

5. E-mail Address
6. Educational Qualification
7. Area of Eminence
8. Present Occupation
9. Achievements/Work Experience
(As per Annexure)

Date:
Place:

Signature:
Name:

<!-- page 44 -->

6'o

Annexure
Details of Achievements/Work Experience in respect of candidates applying for the post of
Chief Information Commissioner

Sr.
No.
1

2

3

4

5

Post

Organisation

Period
From

To

Details of achievements/experience
(in brief)

<!-- page 45 -->

F.No.4/1 3/2018-JR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 21, 2018

Meeting Notice

The process for filling up the vacancies that have arisen/likely to arise at the
level of Chief Information Commissioner in the Central Information Commission and
Information Commissioners in the Central Information Commission has been taken
up.
2.
I am directed to convey that a meeting of the Committee constituted as per
Section 12(3) of the Right to Information Act, 2005 is scheduled to be held on
27.11.2018 at 7.30 PM at 7 Lok Kalyan Marg, New Delhi under the Chairmanship of
the Prime Minister of India.
3.

The Agenda of the meeting will be sent shortly.

4.
Kindly apprise the Hon'ble Finance Minister to make it convenient to attend the
meeting.

(Lok RanjanJ\\
Additional Secretary
Tel.23 0940 10

P.S. to Minister of Finance, Government of India.
Copy to:
U<'rivate Secretary to the Hon'ble Prime Minister
2. P.S.toMoS(PP)
3. PSO to Secretary(P)

<!-- page 46 -->

F.No.4/13/2018-IR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 21, 2018

Meeting Notice

The process for filling up the vacancies that have arisenllikely to arise at the
level of Chief Infonnation Commissioner in the Central Information Commission and
Infonnation Commissioners in the Central Infounation Commission has been taken
up.
I am directed to convey that a meeting of the Committee constituted as per
2.
Section 12(3) of the Right to Information Act, 2005 is scheduled to be held on
27.11.2018 at 7.30 PM at 7 Lok Kalyan Marg, New Delhi under the Chaiiuianship of
the Prime Minister of India.
3.

The Agenda of the meeting will be sent shortly.

4.

You are kindly requested to make it convenient to attend the meeting.

(Lok Ranjari')
Additional Secretary
Te1.2309401 0

Shri Mallikarjun Kharge,
Leader of the single largest Party in Opposition in Lok Sabha,
9, Safdarjung Road,
New Delhi-110011
—

<!-- page 47 -->

F.No.4/1 3/20 18-1R
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 21, 2018

Meeting Notice

The process for filling up the vacancies that have arisen/likely to arise at the
level of Chief Information Commissioner in the Central Information Commission and
Information Commissioners in the Central Information Commission has been taken
up.
2.
1 am directed to convey that a meeting of the Committee constituted as per
Section 12(3) of the Right to Information Act, 2005 is scheduled to be held on
27.11.2018 at 7.30 PM at 7 Lok Kalyan Marg, New Delhi under the Chairmanship of
the Prime Minister of India.
3.

The Agenda of the meeting will be sent shortly.

Kindly apprise the }Ion'ble Finance Minister to make it convenient to attend the
4.
meeting.

(Lok Ranjani' \ P \ '
Additional Secretary
Te1.23094010

P.S. to Minister of Finance, Government of India.
Copy to:
1. Private Secretary to t
to MoS(PP)
3. PSO to Secretary(P)

'ble Prime Minister

<!-- page 48 -->

Aqenda Note

Appointment of Chief Information Commissioners in the Central Information Commission:
Rule Position:
As per section 12 (2) of the Right to Information Act, 2005, the Central

1.

Information Commission shall consist of the Chief Information Commissioner and such
number of Central Information Commissioners, not exceeding ten, as may be deemed
necessary. The tenure of the present incumbent Chief Information Commissioner is getting
over on 24.11.2018.
Section 1 2 (3) of the Act stipulates that the Chief Information Commissioner in the

2.

Central Information Commission shall be appointed by the President on the
recommendation of a Committee consisting of the following:(i)

the Prime Minister who shall be the Chairperson of the Committee;

(ii)

*the Leader of the Opposition in the Lok Sabha; and

(iii)

a Union Cabinet Minister to be nominated by the Prime Minister.

*where the Leader of Opposition in the House of the People has not been recognized as
such, the Leader of the single largest group in opposition of the Government in the House
of the People shall be deemed to be the Leader of Opposition.
3.

As per Section 12(5) of the RTI Act, 2005, the Chief Information Commissioner shall

be persons of eminence in public life with wide knowledge and experience in "law,
science and technology, social service, management, journalism, mass media or
administration and governance."
4.

Section 12(6) of the RTI Act, 2005 mandates that the Chief Information

Commissioner shall not be a Member of Parliament or Member of the Legislature of any
State or Union Territory, as the case may be, or hold any other office of profit or
connected with any political party or carrying on any business or pursuing any profession.

5.

Section 13(1) of the RTI Act, 2005 provides that the Chief Information Commissioner

shall hold office for a term of five years from the date on which he enters upon his office
and shall not be eligible for reappointment; Provided that no Chief Information
Commissioner shall hold office as such after he has attained the age of sixty-five years.

<!-- page 49 -->

Process

As per past practice, the process of selection of Chief Information Commissioner
6.
involves following steps:(i) Particulars of interested persons are invited through advertisements in newspapers
and through DoPT's website.
(ii) Particulars of applicants are tabulated by DoPT and sent to a Search Committee
chaired by Cabinet Secretary.
(iii) Names shortlisted are sent to the Committee constituted under Section 12(3)
headed by the Hon'ble Prime Minister.
(iv)Person recommended by the Committee constituted under Section 12(3) is
appointed by the Hon'ble President.

7.

The competent authority has approved the constitution of Search Committee for

selection of Chief Information Commissioner with the following composition:-

(b)

Cabinet Secretary

Chairman

ii.

Additional Principal Secretary to PM

Member

iii.

Secretary (Personnel)

Member

iv.

Secretary (l&B)

Member

v.

Secretary (Expenditure)

Member

vi.

(Director),
Panda
Dr.
Manoj
Institute of Economic Growth, Delhi
U niversity

Member

The competent authority has also nominated Shri Arun Jaitley, Union Cabinet

Minister as member of the Committeeto be constituted under Section 12(3) of RTI Act.
(c)

An advertisement was posted on the DOPT's website on

23.10.2018 inviting

particulars of the interested persons for the post of Chief Information Commissioner in the
Central Information Commission. The last date of receipt of applications was 12.11.2018
(before 5:00 PM). An advertisement was also published in 4 leading newspapers- The
Hindu' and 'Times of India'(in English); 'Dainik Bhaskar' and 'Hindustan' (in Hindi) and their
editions throughout India by the Directorate of Advertising & Visual Publicity (DAVP).

<!-- page 50 -->

8.

The applications received for the post of Chief Information Commissioner were

been placed before the Search Committee. The Search Committee were recommend
the names of suitable persons to the Committee headed by the Prime Minister for
recommendation for appointment of Chief Information Commissioner in the Central
Information Commission. The names recommended by the Search Committee will be
placed before the Committee constituted under Section 12(3) of the RTI Act 2005 in he
meeting.

9.

The Agenda note is submitted for kind consideration of the Committee. The

Committee may kindly recommend the name of candidate for the post of Chief
Information Commissioner in the Central Information Commission.

10.

A copy of the Right to Information Act 205 and the guidelines on the subject

"Setting up of Search Committees/Search-cum-Selection Committees" are annexed for
information.

<!-- page 51 -->

F.No.4/13/20 18-JR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 22, 2018
Meeting Notice

Meeting of the designated Search Committee for recommending panel
of names to the Committee constituted under Section 12(3) of the Right to
Information Act for the appointment of Chief Information Commissioner in the
Central Information Commission has been scheduled to be held under the
chairmanship of Cabinet Secretary on 24.11.2018 at 4.00 PM in the Committee
Room, Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2. Kindly make it convenient to attend the meeting.
ncl: As-rb\L

(Varsha Sinha)
Director (IR)
Ph: 23092755

(

1. Cabinet Secretary, Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2. Additional Principal Secretary to PM, Prime Minister's Office, South Block,
New Delhi.
3. Secretary (Personnel), D/o Personnel & Training, North Block, New Delhi.._k'
4. Secretary (I&B), Room No. 655, 'A' Wing, Shastri Bhavan, New Delhi.
rA
5. Secretary, (Expenditure) Ministry of Finance, North Block, New Delhi. 7
6. Dr. Manoj Panda, (Director), Institute of Economic Growth, Delhi University
Enclave, Delhi 110007. E-mail:- rnanojiegindia.org
Copy to:PPS to Cabinet Secretary — to provide secretarial assistance to the Search
Committee.

<!-- page 52 -->

Chief Information Commissioner and Information Commissioners in CIC

SI.No.

Name

Date of Birth

Date of
Appointment

Field of
Date of
completion Excellence
of tenure

1.

ShriR.K. Mathur, Chief
Information Commisioner, lAS

25.11.1953

04.01.2016

24.11.2018

Administration

2.

Shri Basant Seth

16.02.1952

01 .03.2012

15.02.2017

Management

1 2.03.1 954

22.11 .201 3

21. 11.2018

Administration

23.09.1952

22.11.2013

22.09.2017

Administration

1 6.01 .1 953

22.11 .2013

15.01.2018

Administration

01 .01.1952

22.11.2013

31.12.2016

Law

10.11.1956

22.11.2013

21.11.2018

Law

12.01 .1955

11 .06.2015

11 .01 .2020

Administration

02.1 2.1953

25.02.201 6

01. 12.2018

Administration

27.08.1955

25.02.2016

26.08.2020

Administration

26.09.1955

25.02.2016

25.09.2020

Administration

Banker
3.

Shri Yashovardhan Azad
PS, M.P.

4.

Shri Sharat Sabharwal
IFS

5.

Ms. Manjula Prasher
I PoS

6.

ShriM.A. Khan Yusufi
I IS

7.

ShriMadabhusanam Sridhar
Acharyuiu
Professor, Law

8.

Shri Sudhir Bhargava
AS, RJ

9.

Shri Amitava Bhattacharya
AS

10.

Shri Bimal Julka
AS

11.

Shri Divya Prakash Sinha
I PS

Vacancies are marked in bold.
Vacancies likely to arise are underlined.

<!-- page 53 -->

0
F.No.4/ 13/20 18-JR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 22, 201 8
Meeting Notice

Meeting of the designated Search Committee for recommending panel
of names to the Committee constituted under Section 12(3) of the Right to
Information Act for the appointment of Chief Information Commissioner in the
Central Information Commission has been scheduled to be held under the
chairmanship of Cabinet Secretary on 24.11 .201 8 at 4.00 PM in the Committee
Room, Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2. Kindly make it convenient to attend the meeting.
End: As above.

(Varsha Sinha)
Director (IR)
Ph: 23092755

1. Cabinet Secretary, Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2 Additional Principal Secretary to PM Prime Minister's Office, South Block,
New Delhi.
3. Secretary (Personnel), D/o Personnel & Training, North Block, New Delhi.
4.
ecretary (I&B), Room No. 655, 'A' Wing, Shastri Bhavan, New Delhi.
Secretary, (Expenditure) Ministry of Finance, North Block, New Delhi. 229
Dr. Manoj Panda, (Director), Institute of Economic Growth, Delhi University
Enclave, Delhi 110007. E-mail:- rnanojiegindia.org
Copy to:PPS to Cabinet Secretary — to provide secretarial assistance to the Search
'v-e2J&1 Committee.
'1

<!-- page 54 -->

-i3i
cc

2LJ çrf

CONFIDENTIAL
No. 8/18/2018-CS (A)
CABiNET SECRETARIAT
Subject: Appointment to the post of Chief Information Commissioner
and Information Commissioners -reg.
A meeting of the Search Committee for shortlisting the applicants
for the post of Chief Information Comrnisstoner is scheduled to be held
at 4:00 P.M. on 241t2018, in the Commfttee.. Room, Cabinet
Secretariat, Rashtrapati Bhawan, New Delhi. This will be followed by
the meeting for shortlisting the applicants for the posts of Information
Commissioner.
All the members of the Search Committee may kindly be
2.
requested to attend the meeting.

(Richa ciaharwar)
Director
22.112018

Department of Personnel & Training
(Dr. C.Chandramouli, Secretary)

<!-- page 55 -->

/
Chief Information Commissioner and Information Commissioners in CIC

Sl.No.

Name

Date of Birth

Date of
Appointment

Date of
completion
of tenure

Field of
Excellence

1.

ShriR.K. Mathur, Chief
Information Commisioner, lAS

25.11.1953

04.01 .2016

24.11.2018

Administration

2.

Shri Basant Seth

16.02.1952

01 .03.2012

15.02.2017

Management

12.03.1954

22.11.2013

21.11.2018

Administration

23.09.1952

22.11.2013

22.09.2017

Administration

16.01.1953

22.11.2013

15.01 .2018

Administration

01 .01.1952

22.11.2013

31.12.2016

Law

10.11.1956

22.11.2013

21.11.2018

Law

12.01 .1955

11 .06.2015

11 .01 .2020

Administration

02.1 2.1 953

25.02.201 6

01. 12.2018

Administration

Banker
3.

Shri Yashovardhan Azad
PS, M.P.

4.

Shri Sharat Sabharwal
IFS

5.

Ms. Manjula Prasher
I PoS

6.

ShriM.A. KhanYusufi
I LS

7.

Shri Madabhusanam Sridhar
Ach an/u/u
Professor, Law

8.

Shri Sudhir Bhargava
lAS, RJ

9.

Shri Amitava Bhattacharya
AS

10.

Shri Bimal Julka
lAS

27.08.1955

25.02.2016

26.08.2020

Administration

11.

Shri Divya Prakash Sinha

26.09.1955

25.02.201 6

25.09.2020

Administration

I PS

Vacancies are marked in bold.
Vacancies likely to arise are underlined.

<!-- page 56 -->

72
Chief Information Commissioner and Information Commissioners in CIC

Sl.No.

Name

Date of Birth

Date of
Appointment

Date of
completion
of tenure

Field of
Excellence

1.

ShriR.K. Mathur, Chief
Information Commisioner, lAS

25.11.1953

04.01 .2016

24.11.2018

Administration

2.

Shri BasantSeth

16.02.1952

01.03.2012

15.02.2017

Management

12.03.1954

22.11.2013

21.11.2018

Administration

23.09.1952

22.11.2013

22.09.2017

Administration

1 6.01 .1 953

22.11 .201 3

15.01.2018

Administration

01.01.1952

22.11.2013

31.12.2016

Law

10.11.1956

22.11.2013

21.11.2018

Law

12.01.1955

11.06.2015

11.01.2020

Administration

02.12.1953

25.02.2016

01. 12.2018

Administration

Banker
3.

Shri Ycishovardhan Azad
IPS, M.P.

4.

Shri SharatSabharwal
IFS

5.

Ms. Manjula Prasher
I PoS

6.

ShriM.A.KhanYusufi
I IS

7.

Shri Madabhusanam Sridhar
Acharyulu
Professor, Law

8.

ShriSudhir Bhargava
AS, RJ

9.

Shri Amitava Bhattacharya
lAS

10.

Shri Bimal Julka
AS

27.08.1955

25.02.2016

26.08.2020

Administration

11.

Shri Divya Prakash Sinha

26.09.1955

25.02.2016

25.09.2020

Administration

I PS

Vacancies are marked in bold.
Vacancies likely to arise are underlined.

<!-- page 57 -->

F.No.4/13/2018-IR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 22, 2018
Meeting Notice

Meeting of the designated Search Committee for recommending panel
of names to the Committee constituted under Section 12(3) of the Right to
Information Act for the appointment of Chief Information Commissioner in the
Central Information Commission has been scheduled to be held under the
chairmanship of Cabinet Secretary on 24.11.2018 at 4.00 PM in the Committee
Room, Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2. Kindly make it convenient to attend the meeting.
End: As above.

(Varsha Sinha)
Director (IR)
Ph: 23092755

1. Cabinet Secretary, Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2. Additional Principal Secretary to PM, Prime Minister's Office, South Block,
New Delhi.
3. Secretary (Personnel), DIo Personnel & Training, North Block, New Delhi.
4. Secretary (1&B), Room No. 655, 'A' Wing, Shastri Bhavan, New Delhi.
5. Secretary, (Expenditure) Ministry of Finance, North Block, New Delhi.
6. Dr. Manoj Panda, (Director), Institute of Economic Growth, Delhi University
Enclave, Delhi 110007. E-mail:- manojiegindia.org
Copy to:PPS to Cabinet Secretary — to provide secretarial assistance to the Search
Committee.

<!-- page 58 -->

CONFIDENTIAL
F.No. 4!9/2018-IR (Pt.-II)
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated : 22 November, 2018
Meeting Notice
The second Meeting of the Search Committee for recommending panel of
names to the Committee constituted under Section 12(3) of the RTI Act, 2005 for
appointment of Information Commissioners in the Central Information Commission is
scheduled to be held under the chairmanship of Cabinet Secretary on 24.11.2018 at
04:00 P.M in the Cabinet Secretariat, Rashtrapati Bhawan.
2.

Kindly make it convenient to attend the meeting.

(Varsha Sinha)
Director (IR)
Tel: 2309 2755
Email: varsha.sinha©nic.in
1. Cabinet Secretary. Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2. Additional Principal Secretary to PM, Prime Minister's Office, South Block, New DelhJ
\O
3. Secretary, Department of Personnel & Training, North Block, New Delhi.
4. Secretary, Ministry of Information & Broadcasting, Room No. 655, A Wing, Sha'\. '1/?
'—hawan, New Delhi
5. Secretary, Department of Industrial Policy & Promotion, Udyog Bhawan, New Delhi. E
6. Dr. Manoj Panda, Director, Institute of Economic Growth, Delhi University Enclave?k
Delhi- 110 007.
Copy to:, PPS to Cabinet Secretary to provide secretarial assistance to the Search Committee.

<!-- page 59 -->

Chief Information Commissioner and Information Commissioners in CIC

Sl.No.

Name

Date of Birth

Date of
Appointment

Field of
Date of
completion Excellence
of tenure

1.

Shri R.K. Mathur, Chief
Information Commisioner, lAS

25.11.1953

04.01 .2016

24.11.2018

Administration

2.

Shri Basant Seth

16.02.1952

01.03.2012

15.02.2017

Management

12.03.1954

22.11.2013

21.11.2018

Administration

23.09.1952

22.11 .201 3

22.09.2017

Administration

16.01.1953

22.11.2013

15.01.2018

Administration

01.01.1952

22.11.2013

31.12.2016

Law

10.11.1956

22.11.2013

21.11.2018

Law

12.01.1955

11.06.2015

11.01.2020

Administration

02.12.1953

25.02.2016

01.12.2018

Administration

Banker
3.

Shri Yashovardhan Azad
IPS, M.P.

4.

Shri Sharat Sabharwal
IFS

5.

Ms. Manjula Prasher
I PoS

6.

ShriM.A. KhanYusufi
115

7.

ShriMadabhusanamSridhar
Ac haryulu
Professor, Law

8.

ShriSudhirBhargava
AS, RJ

9.

Shri Amitava Bhattacharya
lAS

10.

Shri Bimal Julka
lAS

27.08.1955

25.02.2016

26.08.2020

Administration

11.

Shri Divya PrakashSinha

26.09.1955

25.02.2016

25.09.2020

Administration

I PS

Vacancies are marked in bold.

<!-- page 60 -->

75

CONFIDENTIAL
F.No. 4!9/2018-IR (Pt.-!!)
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated : 22' November, 2018
Meeting Notice
The second Meeting of the Search Committee for recommending panel of
names to the Committee constituted under Section 12(3) of the RI! Act, 2005 for
appointment of Information Commissioners in the Central Information Commission is
scheduled to be held under the chairmanship of Cabinet Secretary on 24.11.2018 at
04:00 P.M in the Cabinet Secretariat, Rashtrapati Bhawan.
2.

Kindly make it convenient to attend the meeting.

(Varsha Sinha)
Director (IR)
Tel: 2309 2755
Email: varshasinha©nic.in
1. Cabinet Secretary, Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2. Additional Principal Secretaryto PM, Prime Minister's Office, South Block, New Delh
\O
3. Secretary, Department of Personnel & Training, North Block, New Delhi.
4. Secretary, Ministry of Information & Broadcasting, Room No. 655, A Wing, Sha\'1/2
hawan, New Delhi
5. Secretary, Department of Industrial Policy & Promotion, Udyog Bhawan, New Delhi.
6. Dr. Manoj Panda, Director, Institute of Economic Growth, Delhi University Enc!ave,
Delhi- 110 007.
Copy to:PPS to Cabinet Secretary: to provide secretarial assistance to the Search Committee.

<!-- page 61 -->

F&ENDA

FOR sEf1c'4 cornpiIrrEr

INDEX
S. No.

Item

Page number

1.

Meeting Notice

1

1.

Agenda Note

2-4

2.

Incumbency Position in CIC

5

3.

6-21

4.

List of 64 applicants for the post of Central
Information Commissioner in CIC
List of applicants received after the last date

5.

Eminence-wise list of applicants

23-40

6.

Profiles of the applicants

Separate

7.

RTI Act

8.

RTI Rules

9.

Guidelines for Search Committe

22

<!-- page 62 -->

F.No.4/1 3/2018-JR
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
North Block, New Delhi
Dated November 22, 2018
Meeting Notice

Meeting of the designated Search Committee for recommending panel
of names to the Committee constituted under Section 12(3) of the Right to
Information Act for the appointment of Chief Information Commissioner in the
Central Information Commission has been scheduled to be held under the
chairmanship of Cabinet Secretary on 24.11.20 18 at 4.00 PM in the Committee
Room, Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2. Kindly make it convenient to attend the meeting.
End: As above.

(Varsha Sinha)
Director (IR)
Ph: 23092755

1. Cabinet Secretary, Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
2. Additional Principal Secretary to PM, Prime Minister's Office, South Block,
New Delhi.
3. Secretary (Personnel), D/o Personnel & Training, North Block, New Delhi.
4. Secretary (I&B), Room No. 655, 'A' Wing, Shastri Bhavan, New Delhi.
5. Secretary, (Expenditure) Ministry of Finance, North Block, New Delhi.
6. Dr. Manoj Panda, (Director), Institute of Economic Growth, Delhi University
Enclave, Delhi 110007. E-mail:- manojiegindia.org
Copy to:PPS to Cabinet Secretary — to provide secretarial assistance to the Search
Committee.

<!-- page 63 -->

Aqenda Note

Appointment of Chief Information Commissioners in the Central Information Commission:
Rule Position:
As per section 12 (2) of the Act, the Central Information Commission shall consist

1.

of the Chief Information Commissioner and such number of Central Information
Commissioners, not exceeding ten, as may be deemed necessary. At present, the Central
Information Commission has the Chief Information Commissioner and 6 (six) Information
Commissioners.
Section 12 (3) of the Act stipulates that the Chief Information Commissioner and

2.

the Information Commissioners shall be appointed by the President on the
recommendation of a Committee consisting of the following:(i)

the Prime Minister who shall be the Chairperson of the Committee;

(ii)

*the Leader of the Opposition in the Lok Sabha; and

(iii)

a Union Cabinet Minister to be nominated by the Prime Minister.

*where the Leader of Opposition in the House of the People has not been recognized as
such, the Leader of the single largest group in opposition of the Government in the House
of the People shall be deemed to be the Leader of Opposition.
3.

As per Section 1 2(5) of the RTI Act, 2005, the Chief Information Commissioner and

Information Commissioners shall be persons of eminence in public life with wide
knowledge and experience in

law, science and technology, social service,

management, journalism, mass media or administration and governance."
4.

Section 12(6) of the RTI Act, 2005 mandates that "The Chief Information

commissioner or an Information Commissioner shall not be a Member of Parliament or
Member of the Legislature of any State or Union territory, as the case may be, or hold any
other office of profit or connected with any political party or carrying on any business or
pursuing any profession."

<!-- page 64 -->

Process
5.
As per past practice, the process of selection of Chief Information Commissioner
involves following steps:(I) Particulars of interested persons are invited through advertisements in newspapers
(two English and two Hindi) and through DoPT's website.

(ii) Particulars of applicants are tabulated by DoPT and sent to a Search Committee
chaired by Cabinet Secretary.
(iii) Names shortlisted are sent to a Selection Committee constituted under Section
12(3) headed by the Hon'ble Prime Minister.
(iv) Person recommended by the Committee constituted under Section 12(3) is
appointed by the Hon'ble President.
6.

PMO vide ID no. 4930444/PMO/2018-E&S-2 dated 22.10.2018 have conveyed

approval to go ahead with the advertisement for the post of Chief Information
Commissioner. They have also stated that the constitution of Search Committee and
nomination of the Union Minister on the Selection Committee is same as conveyed vide
PMO ID No - 4877064/PMO/20 18-ES-Il dated 13.08.2018.
PMO vide ID No - 4877064/PMO/2018-ES-II dated 13.08.2018 conveyed the
approval of the Prime Minister for following:
(a) The constitution of Search Committee for selection of Chief Information
Commissioner and Information Commissioners with the following composition:-

(b)

Cabinet Secretary

Chairman

ii.

Additional Principal Secretary to PM

Member

iii.

Secretary (Personnel)

Member

iv.

Secretary (l&B)

Member

v.

Secretary (Expenditure)

Member

vi.

(Director),
Panda
Manoj
Dr.
Delhi
Growth,
of
Economic
Institute
University

Member

The nomination of Shri Arun Jaitley, Minister as member of the Committee, headed

by Hon'ble PM, to be constituted under Section 12(3) of RTI Act.

<!-- page 65 -->

7.

As per past practice, an advertisement was posted on the DOPT's website on

23.10.2018 inviting particulars of the interested persons for the post of Chief Information
Commissioner in the Central Information Commission. The last date of receipt of
applications was 12.11.2018 (before 5:00 PM). An advertisement was also published in the
4 leading newspapers- The Hindu' and Times of lndia'(in English); 'Dainik Bhaskar' and
Hindustan' (in hindi) by the Directorate of Advertising & Visual Publicity (DAVP) and their
editions throughout India.
8.

In response, a total no. of 64 applications for the post of Chief Information

Commissioner in the Central Information Commission have been received by the last date
i.e. 12.11.2018. Out of these, two applications were received at 5:01 PM and 5.12 PM on
12.11.2018.
9.

Accordingly, all these 64 applications have been broadly categorised into 7

categories of knowledge and experience, as stated in section 12(5) above. For the sake
of categorisation, only the main field of knowledge and experience have been
mentioned. Details on the basis of such categorisation is tabulated and placed at
Annexure-I.
10.

As per past practice, the Search Committee would recommend the names of

suitable persons to the Selection Committee headed by the Prime Minister for
recommendation for appointment of Chief Information Commissioner in the Central
Information Commission.

<!-- page 66 -->

Annexure I
The category-wise distribution of the applications is as under:Category
Law
Science & Technology
Social Service
Management
Journalism
Mass Media
Administration and Governance
Multiple Categories
Total

No. of applications
10
4
2
5
1
1
27
14
64 *

<!-- page 67 -->

Chief Information Commissioner and Information Commissioners in CIC
(Incumbency Statement as on 23.11.2018)

SI.No.

Name

Date of Birth
-.

Date of
Date of
Field of
completion
Excellence
Appointment
of tenure

1.

ShriR.K. Mathur, Chief
Information Commisioner, lAS

25.11.1953

04.01.2016

24.11.2018

Administration

2.

Shri Basant Seth

16.02.1952

01.03.2012

15.02.2017

Management

12.03.1954

22.11.2013

21.11.2018

Administration

23.09.1952

22.11.2013

22.09.2017

Administration

16.01.1953

22.11.2013

15.01.2018

Administration

01.01.1952

22.11.2013

31.12.2016

Law

10.11.1956

22.11.2013

21.11.2018

Law

12.01 .1955

11 .06.2015

11.01 .2020

Administration

02.12.1953

25.02.2016

01.12.2018

Administration

Banker
3.

Shri Yashovardhan Azad
IPS, M.P.

4.

Shri Sharat Sabharwal
IFS

5.

Ms. Manjula Prasher
IPoS

6.

Shri M.A. Khan Yusufi
I IS

7.

ShriMadabhusanam Sridhar
Acharyulu
Professor, Law

8.

Shri Sudhir Bhargava
AS, RJ

9.

ShriAmitava 8hattacharya
lAS

10.

Shri Bimal Julka
lAS

27.08.1955

25.02.2016

26.08.2020

Administration

11.

Shri Divya Prakash Sinha

26.09.1955

25.02.2016

25.09.2020

Administration

IPS

Vacancies are marked in bold.
Vacancies likely to arise are underlined.

<!-- page 68 -->

Pages 84 - 119 has personal details of
the applicants which are exempted from
disclosure under Section 8(1) (j) of the
RTI Act, 2005. However, a list of names
of applicant is given

<!-- page 69 -->

4 t,

Applications for the post of Chief
Information Commissioner
S. No.
Name
1

Lakshmi Prasanna Chodavarapu*

2

Narendra Ku mar Si nha*

3
4
5

Vipul Vij oy*
Rohit N andan*
Jatinder Kumar Sharma*

6
7

Sudhir Chowdhary*
Gurugubelli Surya Prakasa Rao*

8
9
10
11

Neeraj Kumar G upta*
SanjayBasu
Kishore Madavi
Yashvant Singh Jowhari

12
13

Dr. U grasen*
Dr. Rajendra Singh Sikarwar*

14
15

Dr. V. S ekar*
Mani Shankar Prasad Sinha

16
17
18

Vineet Ch awdhry*
Dr. D. Bhalla*
Sh. Dharurkar Dilipkumar Laxmikant

19
20
21
22
23
24
25
26
27
28
29
30
31
32
33

Leena N air*
R. Ra jasekharan*
DSSaksena,IRS*
Deendayal Prajapat
Yudhishter Sharma*
Akshay Kumar Rout*
K.V.Sreenivasan
Dr.Y.P.Rai*
Bishwamitra P andey*
Rajendra Sharma
DeepakSingh
Sunil Kumar Si ngh*
BimaiJulka
G.K Suresh Babu*
K. Ratna Prabha

<!-- page 70 -->

34

P 5
36
37
38

Dr. Lalit Varma
Ajay Kumar L aI*
Jadab Kumar P a1*
Anil Kumar Singh
Jagdish Prasad M eena*

40

Arun Srivastava*
Anoop Kumar S rivastava*

41

Dr. S. A mbigaidass*

42
43

Divya Prakash Sinha
Sheo Sharan Srivastava

44

t. Ganesan

45

Ajay Mittal

46
47

F. Sheheryar
Dr. Ish K umar*

48

Sudhir Bhargava

49

Narender Kumar Bh ol a*

50
51

Uma Kant Lal
Seema Ba haguna *

52

Upendra Sah

53

Manish Shivahare

54

K.B Narayana

55

Lt. Gen Naresh Kumar Mehta

56

Mahesh Chander Bagarwal

57

Lamba lejpal Singh

58
59

Dr. Vijay Satbir Singh
Pukhraj Singh M a lik*

60

Anil Kumar Up a dhyay*

61

Shobha Up a dhyay*

62

Dr. Jayesh G Mecwan

63

Dr. Kush Verma

64

Navneet Kumar Gupta*

39

<!-- page 71 -->

Late Applications
Name

S. No.
1

H.KDas

2

G.RAloria

3

M.S Dagur

4

Deepak Mishra

<!-- page 72 -->

120
CONFIDENTIAL

•

Minutes of the Meeting of the Search Committee held on 24.11.2018 for shortlisting
candidates for appointment as Chief Information Commissioner in the Central
Information Commission
Present:
(i)
(ii)
(iii)
(iv)

Shri P.K. Sinha, Cabinet Secretary
Dr. P.K. Mishra, Additional Principal Secretary to Prime Minister
Dr. C. Chandramouli, Secretary, Department of Personnel & Training
Dr. Manoj Panda, Director, Institute of Economic Growth, Delhi
University

(Shri A.N. Jha, Secretary, Department of Expenditure and Shri Amit Khare, Secretary,
Ministry of Information and Broadcasting could not attend the meeting)

The Search Committee was apprised of the statutory provisions related to the
post of Chief Information Commissioner in Central Information Commission. The RTI
Act provides that Chief Information Commissioner shall hold office for a term of five
years from the date on which he enters upon his office and shall not be eligible for
reappointment, provided that no Chief Information Commissioner shall hold office as
such after he has attained the age of sixty-five years. It was further apprised that the
candidates shortlisted by the Search Committee shall be placed for consideration of the
Committee constituted under Section 12(3) of the RTI Act.
The Search Committee was informed that present Chief Information
2.
Commissioner Shri R.K. Mathur will complete his tenure on 24.11.2018. It was further
informed that Department of Personnel & Training (DoPT) had issued an advertisement
for filling up the post of Chief Information Commissioner on 23.10.20 18, against which
64 applications were received upto the last date for receipt of applications, i.e.,
12.11.2018.
Apart from the applications received by DoPT, the Search Committee also
3.
considered the names of Serving/Retired Civil Servants as well as other names suggested
by Members of the Search Committee. After taking into consideration the overall
experience profile as well as suitability for the post, the Search Committee shortlisted the
following panel (in alphabetical order) for consideration of the Committee constituted
under Section 12(3) of the RTI Act, for the post of Chief Information Commissioner in
Central Information Commission:
(i)
(ii)
(iii)

Shri Sudhir Bhargava, (DoB: 12.01.1955), lAS (Ri: 1979) (Retd.) Information
Commissioner in Central Information Commission
Shri Madhav Lal, (DoB:04.06.1955) lAS (JK: 1977) (Retd.) former Secretary,
Ministry of Micro, Small and Medium Enterprises
Dr. S.K. Nanda, (DoB: 01.02.1956) lAS (GJ: 1978) (Retd.) former Additional
Chief Secretary, Gujarat

<!-- page 73 -->

121

S
(iv)
(v)

Shri Alok Rawat, ( DoB: 15.07.1955) lAS (SK: 1977) (Retd.) former Secretary,
Department of Administrative Reforms & Public Grievances
Shri R.P. Watal, (DoB: 08.02.1956) lAS (AP: 1978) (Retd.) former Secretary,
Department of Expenditure (at present Principal Adviser, NITI Aayog)

(Manoj Panda)

C. Chandramouli)

(P.K. Mishra)

(P.K. Sinha)

<!-- page 74 -->

22.

File No. 29/03/201 8/CIC/AdmnlPension
-Hl3fRu1T
Central Information Commission
ll iFffZflT, Pii /Baba Gangnath Marg, Munirka
-

-°°s/New Delhi —110067

Date:

24.11.2018

OFFICE ORDER
Shri Radha Krishna Mathur, Chief Information Commissioner, CIC, demits office as
Chief Information Commissioner on completion of his tenure on 24.11.2018 (AN)

1::

;

(S.P. Beckr
Joint Secretary (Admn)
Copy to:
1. Shri Radha Krishna Mathur, Chief Information Commissioner
2. PPStoICs
3. Secretary (P), M/O Personnel, Public Grievances & Pensions, North Block, New Delhi.
4. Secretary, President Secretariat, Rashtrapati Bhawan, New Delhi.
5. Under Secretary (IR), Department of Personnel & Training, North Block, New Delhi.
6. Addl. Secretary/ Registrar/JS (P&B), JS(MR), JS(Law)/JS(A)
7. IFA to CIC, Office of Controller of Accounts, Ministry of Personnel, Public Grievances &
Pensions, 3' floor, Lok Nayak Bhawan. New Delhi.
8. All Dy Secretaries/Dy. Registrars
9. PAO, CAT, Old JNU Campus, New Delhi.
10.Cash Section/DDO/Financial Consultant/Library/Central Registary.
11.Personal File/Service Book.
12.NIC, CIC for uploading the orders on ClC website.

<!-- page 75 -->

https://rnail.gov.in/iwcstatic/layout/shell.html?lang=en&3 .0.1 .2.0...

Subject: Fw: Letter to PMO meeting
To: "Iok.ranjan@nic.in" <lok.ranjan@nic.in>,
"jssvl-dopt@nic.in" <jssv1-doptnic.in>

Date: 11/22/18 08:35 PM
From: narayanans raman <apsnda@yahoo.com>
Reply-To: 'apsnda@yahoo.com" <apsnda@yahoo.com>

Sent from Yahoo Mail on Android

Forwarded message
To: "Narayanans Raman" <apsnda@yahoo.com>
Cc:
Sent: Thu, 22 Nov 2018 at 20:32
Subject: Letter to PMO
R. Narayanan
Private Secretary. 0/0 Chairman PAC

Respected sir,

Kindly refer to the meeting notice dated 21-11-2018 of Department of Personnel and Training requesting Shri Mallikarjun
Kharge, MR Lok Sabha and leader of the largest party in Lok Sabha for the meeting of the Committee constituted for the
selection to the posts of Central Information Commissioner! Information Commissioners scheduled on 27-11-2018 at 7.30 pm
at 7 Lok Kalyan Marg, New Delhi under the Chairmanship of Honbie Prime Minister.

I am desired by Honble Mallikarjun Kharge to inform you that he, being the Chairman of Public Accounts Committee is
leading the Committee on a study visit to Hyderabad and other places from 26th to 28th November 2018 and that the
aforesaid study visit was fixed around 15 days before and the Member of PAC have already confirmed their attendance. In
view of the above Shri Mallikarjun Kharge has regretted his inability to attend the meeting.

He had also requested you to kindly postpone the meeting on any date after a gap of ten days.

Since Honble Kharge is away from HOrs, I am desired by him to inform you of the above position.

With kindest regards and Happy New Year to you,

Yours sincerely,

R. Narayanan
P.S. to the Chairman PAC

To

Shri Alok Ranjan
Addi. Secretary DOP&T

Sent from Yahoo Mail on Android

of I

23-11-2018, 13:11

<!-- page 76 -->

'

ZTiE
No 9. Safdarjung Road
New Delhi- 110011
91-.11-.237p3ij
23793062

MALLIKARJIJN KHARGE
MEMBER OF PARLIAMENf
Loader of the Congress Party
ln the Lok Sahha

23.11.2018
Respected Prime Minister,
have received a meeting notice dated 2l ° November, 2018 of
Department of Personnel and Training, requesting me to attend the
meeting of the Committee constituted for the selection to the posts of
Central Information Commissioner / Information Commissioners, scheduled
27th November, 2018 at 7.30 PM at New Delhi.
on
In this connection, I would like to mention that Public Accounts
261h to 28th
Committee study visit to southern parts of India fixed from
November, 2018. The aforesaid Study Visit was fixed around 15 days back
and Members have already confirmed their participation. As Chairman,
PAC I have to attend the said study visit. In view of the fact mentioned
above, I may not be able to attend meeting on 27 November, 2018.
Therefore, I request you kindly to fix some other day during the First
or Secori'd week of December, 2018.
With kind regards,
Yours sincerely1
SdF

(MALLIKARJUN KHARGE)
SHRI NARENDRA MOD1 JI
Hon'ble Prime Minister of India,
7, Lok Kalyan Marg,
New Deihi-ilO011.
Copy for information to: Additional Secretary, Department of Personnel &
Training. Government of India, North Block. New Delhi.
/-

1' 2—T

(MLLIKARJVJ KHARGE)
Ka1aburag: Lurnbmi, AiWan-E-Shah Area. Gulbarga - 585 102, Karnataka. Ph. 08472-2555
Bengafuru : #289. 17th Cross, Sadashivanagar. Sengaluru - 560 080. Ph 080-23815555

I

<!-- page 77 -->

/2c

f-r 4

3t5(c--.( U9)4 O{517 Oi)t

he

N0t4 0007 2003

Rt.lSilRll) NO. Dl.

aefte ofnctia
1Xt RAOkt)INARV
T1T

4i'1 II

PARt' II

Section

PUI3LISIILI) t\' •\FJ IOR ITY
R

T99J

i 200Y?

3L 1927

Nh\\' DELl IL ItESELX. JUNk 2 l. 20(D:JYAISl'l \ 31

No

r -t

f4rT 1t OJ:

f

Separate paging is given to this Part ir i'der that

27

jf •

75

fl\ he fleci i a

eparaie conpiIziiion.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
Note Del/i,, the 2] St bite, 2005t1vaistha31, 1927 (Scika)
The follo inc Act of Parliament received the assent of the President oTi the 15th June.
2005, and is hereby pnhhshed for ceneral nIortnation:

THE RIGHT TO INFORMATION ACT. 2005
No. 22 of 2005
[15th Juize. 2005.1
An Act to provide for setting oni. the practical reginle ol tight to information for
ctiiens to secure access to information under the control of public
authorities, in order tu promote transparencY mnd accountability in the
working of every public authority, the constitution of a Central Information
Commission and State Information Commissions and for mattet's connected
therew ith or incidental thereto.
\\ 1-lEREAS the Constitution of India has established democratic Republic:
AN!) \\ HEREAS democracy requires an informed citizenry and transparency
ot inlormation \ hich are vittil tO its luncuoninui amid also to cofllzlifl corruption and
to hold Govetnituents and their instrumentalities accountable to the governed:
AND WHEREAS revelation of information in acwal practice is likely to conflict
with other public interests including efficient operations of the Governments, optimum
use of 11n1ued fiscal resources and the preservation ol confidentiality of sensitive
in formation

<!-- page 78 -->

126

2

THE GAZE f IL OF INDIA EXTRAORDINARY

[PART 11-

A'l) \
hkl-:AS it is ieceseir\ to harinonise these conflicting interests
'ahile presers ing the p:iraniountc\ ol the denioci atic ideal
NO\V. THERER)RE. it is expedient to provide for famishing certain
toloritiation to citizens who desire to have it.
RI: it enacted by Parliament in the H lis -sixth Year of the Republic of India
us tol lows: ---CHAPTER 1

Preliminary
1. // Thi5 Act flue lie culled [lie Riht to Information Act. 201)5.
i2> It C\[cltds [0 lie 55 hole it Iiidia

I )eOiii

ii

\Ct the State il Jammu and Kashniti.

(.. The pois i'ioil5 of sub-section (I ) ol section 4. sub-sections (1) and
of 5ection .5. sections 12, I . 15,lo. 24.27 and 28 shall come. into lorce at once. and
the renlainuip provisions 01 this Act shall conic into totce on the one hundred
and tss entieth da of its enactment.
2. In this Act. unless the contest othcr'a isC requirc.----

io) appropriate (io\ernnicni' mcan in relation 10 a public authority which
is estuhiisliesl. e nsiitntd, o'anecl. controlled or substantially financed h\ lunds
joovided hire lv iii indireeti---h bc Ce:itr:il (.ioscritrncnt or the I mon territory adniinitratoti, the
('nit:al (i's er:itetL:
Hi
h\ the State (his criiiiicnt. the State (invernirient:
'Central lrilorinaiin (.'oinnusstoit' means the (,enlrai Iniormation
Coinnu.5sion constituted under sub-section I H ot sectioil 12:
ci Ceutiu Puhio lntbrtitatton Olbcer" [leans the Central Public I n t'o rn iatiot i
Ott eer desunatcJ under sub-section 0 and includes a Ceiitral Assistant Public
lnfoi'inatiun (.)Hccr dcsienatcd as such tinder sub-section 2> of section 5:
Li)
h'r hit rmaton Con itnss:onei' and "Inlbrniation Coniniissionet' rflcui
the ('hiet lnb'tmation Conininsionerand lnlonnatiou (Tomiriissionerappointed tinder
suln-sii'tion >3) of section 12:

o:iipetent ;iuthorlt\ means
(it

the Speaker iii the case ol the House ol [lie People or the Legislat is e
Assembly ol a State or a Lnion territory having such r\ssenthis and the
( haontait iii the case ol the Couiicii of States or Lecislative Cotiiieil 01
ii S tate.
!:; the (hid Justice f india n [lie case of the Supreme Cuuit:
iii the Uncf Jnstice ol the limb Court in the case ol:t thuli Court:
iv die President or the Goseruor, as the case iliay he, in the case 01 other
authorittes established Iii constituted he ir under the Constitution:
the adtiuislrat r appointed under ardcle 230 ol' the Cnstitnition:
'flit
0
flHtioii
ne:ino a; material in cur tortn including records.
dsi-uicnt.;nicniios. e-nicils. pi miss. ajsiccs, prcs releases, ciicuiars.
rd,'rs hsho:k'.. vontruc[s reports. papers. samples. models. data
n:nerhii held ii :iinr electronic to rio and inlorniat ion relutine to aur

<!-- page 79 -->

17

SEC. I

THE GAZETTE OF INDIA EXTRAORDINARY
private body which can be accessed by a public authority under any
other law foi' the time being in force;
(g "prescribed" means prescribed by rules made under this Act by the
appropriate Government or the competent authority, as the case maybe:
(It) ''pLiblic authority'' means any authority or body or institution of
sd f-government established or constituted--

by or under the Constitution:
by any other law made by Parliament;
c) by any other law made by State Legislature:
(d) by notilication issued or order made by the appropriate Government.

(a)

(b)

and includes any-(i)
(ii)

body owned, controlled or substantially financed;
non-Govermnent organisation substantially financed,

directly or ndirect]v by tLInd provided by the appropriate Government:
ti) ....ecoi•d includes--a)

any document, manuscript and file:

b

any nicrolilin. microfiche and facsimile copy of a document:
an reproduction of image or images embodied in such
microFilm (whether
enlarged or not): and
any other material produced by a corn puter or any other device:

(c)

(d)

(7) "right to information" means the right to information accessible undet
this Act which is held by or under the control of any public authority
and includes the right to—
(1

Inspection of work. documents, records:

(ii)

taking notes, extracts or certified copies of documents or records:

liii)

taking certified samples of material:

(ii')

obtaining intortnation in the form of disketies, floppies, tapes.
video cassettes ot' in any other electronic mode or through print
outs where such information is stored in a computer or in an
other device:

Slate Information Commission" means the State In formation
Commission constituted under sub-section (I) of section 15:
(1)

''State Chief Information Commissioner'' and "State InFormation
Commissioner'' nean the State Chief Information Commissionet' and
the State Information Commissioner appointed under sub-section (3
of section 15:

(in) ''State Public Information Officer'' means the State Public Information
OfFicer designated under sub-section (1 and includes a State Assistant
Public Information Officer designated as such under sub-section (2) of
section 5:
(n) "third party'' means a person other than the citixcn making a request for
inlormation and includes a public authority.

3

<!-- page 80 -->

THF GAZE !'lE OF INDIA EXTRAORDINARY

[PART II—

CHAPTER II
Right to information and obligations of public authorities
3. Subject to the provisions of this Act, all citizens shall have the right to information.
4. (1) Every public authority shall--

a) maintainall its records duly catalogued and indexed in a manner.and
the form which facilitates the right to information under this Act and ensure
that all records that are appropriate to be computei'ised are, within a
reasonable time and subject to availability of resources, computerised and
connected through a network all over the country on different systems so
that access to such records is facilitated:
b) publish within one hundred and twenty days from the enactment of
this Act,—
i)
the par ticulars of its organisation. functions and duties:
ii)
the powers and duties of its officers and employees:
(of)
the procedure followed in the decision making process,
incluring channels of supervision and accOlLntability;
(Ic)
the norms set by it for the discharge of its functions:
,)
the rules, regulations, instructions, manuals and records, held by
it or under its control or used by its employees for discharging its
tunctions:
ii)
a statement of the categories of documents that aie held by it or
under its control:
(vii)
the particulars of any arrangement that exists for consultation with,
or representation by. the members of the public in relation to the
lonnulation of its policy or implementation thereof:
viii) a statement of the boards, councils, committees and other
bodies consisting of two or mote persons constituted as its part or
for the purpose of its advice. and as to whether meetings of those
boards. councils, committees and other bodies are open to the
public, or the minutes of such meetings are accessthle for public:
(ix)
a directory of irs officers and employees:
the monthly remuneration received by each of its officers and
1 v)
employees, including the s\'stem of compensation as provided in
its regulations:
(xi)
the budget allocated to each of its agency, indicating the
particulars of all plans. proposed expenditures and reports on
disbursements made:
the manner of execution of subsidy programmes. including the
(xii)
amounts alloctted and the details of beneficiaries of such
programmes:
(xiii) patliculars of recipients of concessions. permits or authorisations
granted by it;
(xiv) details in respect of the information, available to or held by it.
reduced in an electronic form;
the particulars of facilities available to citizens for obtaining
(xv)
information, including the working hours of a library or reading
room, if maintained for public use;
(xvi) the names, designations and other particulars of the Public
information Officers;
(xiii) such other information as may be prescribed; and thereafter update
these publications every year;
c) publish all relevant facts while formulating important policies or
announcing the decisions which affect public;
d) provide reasons for its administrative or quasi-judicial decisions to
affected persons.

Right to
information
