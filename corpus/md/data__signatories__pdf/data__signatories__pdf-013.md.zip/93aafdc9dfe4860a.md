---
doc_id: "93aafdc9dfe4860a"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/03/ac81252aaff333a0fde25dcea37b94f6.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 24.02.2026 regarding resignation of Shri. Hanish Pal Grover, ASGC, District Courts, Hanumangarh, Rajasthan"
date: "2026-02-24"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "63438d802cc18a7a"
---

<!-- page 1 -->

F. No. J-11017/1/2026-Judicial/ E. 173732
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
ok KKK
Shastri Bhawan, New Delhi,
Dated the 24* February, 2026
ORDER

The President is pleased to accept the resignation of Shri Hanish Pal

Grover, Additional Standing Government Counsel, District & Subordinated

Courts, Hanumangarh, Rajasthan, with effect from 20.02.2026.

2. Consequently, the name of Shri Hanish Pal Grover, Advocate figuring

at serial number ‘29’ in the List of this Department’s Order No.

J-11017/1/2026-Judicial/ E. 173732 dated 04.02.2026, stands omitted.

उ., Hindi version of this order will follow.

(Madhab Charan Prusty)
Senior Government Advocate

Copy (through email) to:

1. PS to Hon'ble MoS (I/C) L&J.

2. PSO to Law Secretary/All Additional Secretaries and Joint Secretaries in the main
secretariat of Department of Legal Affairs.

3. Shri Bharat Vyas, ASGI, Rajasthan High Court.

4. Sh. Karni Singh, St. Govt. Counsel, District Court-Hanumangarh, Rajasthan.

5. The Registrar, District Court-Hanumangarh, Rajasthan.

6. Shri Hanish Pal Grover, Advocate.

7. To be uploaded on website of this Department i.e. www.|legalaffairs.gov.in under tab
‘Judicial Section’ in the link “Orders related to empanelment of Advocate for Union of
India”.

8. Hindi Section, Department of Legal Affairs, for translation of this order.

9. Office/spare copies.

a
कक
-/ 14७9
aq!
2
(Niranjan Prasad)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
