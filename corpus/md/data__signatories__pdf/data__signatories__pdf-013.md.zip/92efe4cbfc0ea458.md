---
doc_id: "92efe4cbfc0ea458"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/fce2f932f8d61b106e2703adbbca68f2.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "New Pension System introduced by Pension Fund Regulatory and Development Authority(PFRDA)-Guideline-236.pdf"
date: "2010-02-16"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "19a9181aee15cdeb"
---

<!-- page 1 -->

F. No, 2(131)/09-DPE (WC) (डे
Government of India
Ministry of Heavy Industries & Public Enterprises
Department of Public Enterprises

Public Enterprises Bhawan

Block 14, CGO Complex,

~ Lodi Road, New De!h!- 110003

Dated :} G4¥eb:. «vy, 2010

OFFICE MEMORANDUM हु
Subject:- New Pension System introduced by Pension Fund Regulatory and Developi.cs
Authority (PFRDA).

The undersigned is directed to forward herewith a brochure on the salient feature of the Nex
Pension Scheme and to state that the New Pension System (NPS) was introduced by the Central
Government for all New Employees w.e.f. 01.01.2004 and NPS has also been notified by the 23
State Governments in respect of their employees. Pension Fund Regulatory and Developmert
Authority (PFRDA) has, based on Government advice, also extended NPS to all citizens of Indiz
(between the age of 18-60 years) on voluntary basis froin 01.05.2009.

2 All administrative Ministries/ Departments are requested to bring the contents of the NPS
regulated by the PFRDA, to the notice of the Central Public Sector Enterprises (CPSEs) under their
administrative contro! tor necessary action and guidance at their end.
Encl: As above. bs है
Ue jn eee
a
( Mick ar}
Under See. tary
To
All the administrative Ministries / Departments of the Goverainent of India,
Copy to: Chief Executive of Central Public Sector i:nierprises. है
Copy also to : Shri Puske! Upadhyay, Genera! Manager, PFEDA, |* ‘loor, ICADR Building, Pi:
No. 6, Vasant Kunj Institutional Arca, Phase-Il. New Delhi - 110 070 with reference
to letter No, 9/51/2009/PFRDA dated 19.01.2010.
a Ey
