---
doc_id: "90ff91d7efccac09"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/08/9111635eaeb893afa8c5c727ada33e04.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Draft Quality Control Order for Miscellaneous Steel Products."
date: "2025-08-25"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "591e38f5f2a194a3"
---

<!-- page 1 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY, PART II, SECTION 3, SUBSECTION (II)]

GOVERNMENT OF INDIA
MINISTRY OF COMMERCE & INDUSTRY
DEPARTMENT FOR PROMOTION OF INDUSTRY AND INTERNAL TRADE
ORDER
New Delhi, dated the….., 2023
S.O. (E).- In exercise of the powers conferred by section 16 read of the Bureau of Indian
Standards Act, 2016 (11 of 2016), the Central Government, after consulting the Bureau of Indian
Standards, is of the opinion that it is necessary or expedient so to do in the public interest,
hereby makes the following Order, namely:1. Short title and commencement.- (1) This order may be called the Miscellaneous Steel Products
(Quality Control) Order, 2023.
(2) It shall come into force on the expiry of six months from the date of publication of this
notification in the Official Gazette:
Provided that in relation to micro and small enterprises, as deﬁned in clauses (h) and (m),
respectively of section 2 of the Micro, Small and Medium Enterprises Development Act, 2006 (27
of 2006), it shall come into force on the expiry of twelve months from the date of publication of
this notification in the Official Gazette.
2. Compulsory use of Standard Mark.- Goods or articles specified in the Column (1) of the
Table below shall conform to the corresponding Indian Standard mentioned in Column (2) of the
Table and shall bear the Standard Mark under a licence from the Bureau of Indian Standard as per
Scheme-1 of Schedule-II of the Bureau of Indian Standards (Conformity Assessment)
Regulations, 2018:
Provided that nothing contained in this order shall apply to goods or articles manufactured
domestically for export.
3. Certification and enforcement authority.- The Bureau of Indian Standard shall be the
certifying and enforcing authority for the goods or articles specified in the Column (1) of the
below Table.
4. Penalty for Contravention. – Any person who contravenes the provisions of this order shall
be punishable in accordance with the provisions of the Bureau of Indian Standards Act, 2016.

<!-- page 2 -->

Goods or articles
(1)
Miscellaneous Steel
Products

TABLE
Indian Standard
Title of Indian Standard
(2)
(3)
15155:2020
Bar or wire Wrapped Steel Cylinder
Pipes with Mortar Lining and
Coating
Including
Specialsspecifications
16651:2017
High strength deformed stainless
steel bars and wires for concrete
reinforcement
6392: 2020
Steel Pipe Flanges
6913:1973
Stainless steel tubes for the food
and beverage industry

Note: For the purposes of this Table, the latest version of Indian Standards including the
amendments thereof, as notiﬁed by the Bureau of Indian Standards from time to time shall
apply.
(F. No. P- 29026/24/2023-LEI)

(Sanjiv)
Joint Secretary to the Government of India
