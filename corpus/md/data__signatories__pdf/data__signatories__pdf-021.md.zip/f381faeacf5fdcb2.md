---
doc_id: "f381faeacf5fdcb2"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/fe25586fd78ec894e4cfc2bc129b2d3f.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "List of amendments carried out in ILs/Registrations"
date: "2018-08-07"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a0a8d32df9617bb6"
---

<!-- page 1 -->

LIST OF AMENDMENTS CARRIED OUT IN THE INDUSTRIAL LICENCES DURING MARCH 2004
S.NO

NAME OF THE
COMPANY

ILNO.&DATE

AMENDMENT CARRIED
OUT

NO.&DATE

1.

M/s Biltube India Limited,

IL;12(95)

IL:12(95)

1099 -B, Flat
No.5,’Shreeban.’,Babsgree
Housing Society, Model
colony Road, Shivajinagar,

Dt 25.9.1995

Change of name from M/s.Bi
limited to M/s.Biltube India
Limited.

Merger of Textool Company
Limited with the M/s.Lakshmi
Machine works Ltd

CIL;46(2001)

Dt.5.4.2004

PUNE-411 016
2.

M/s.Lakshmi Mchine works
Ltd,34-A, Kamaraj Road,
Coimbatore.

CIL:46/2001
Dt..20.12.2001

Dt.8.3.2004.
