---
doc_id: "f16d580aace1ace2"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/00d0360e91ac7447224dff9f1ccf5563.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Clarifications regarding exemptions under Quality (Control) Order, 2009 - (Runflat Tyres)"
date: "2025-07-02"
pages: 7
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "871770d34fc59f8a"
---

<!-- page 1 -->

सं.16 (72)/2005-एलआर
भारत सरकार

वा णज्य और उद्योग मंत्रालय
औद्यो गक नी त और संवधन वभाग

(एलआर अनभ
ु ाग)
****

उद्योग भवन, नई दल्ली दनांक : 13 दसम्बर 2011
कायालय ज्ञापन

वषय: आटोमो टव वाहनों के न्यम
( नयंत्रण) आदे श, 2009 के
ू े टक टायर तथा ट्यब
ू गणवत्ता
ु
संबध
ं में
स्पष्टीकरण |

अधोहस्ताक्षरी को यह कहने का नदे श हुआ है क आटोमो टव वाहनों के
न्यम
ु वत्ता ( नयंत्रण) आदे श, 2009 को इस वभाग द्वारा
ू े टक टायर तथा ट्यब
ू गण

19.11.2009 को अ धसू चत कया गया था। उक्त आदे श अब 13.5.2011 से प्रभा वत हो गया
है । उक्त गुणवत्ता ( नयत्रण
ं ) आदे श में न हत उपबंध, सवाए खड
ं 3 (क) से 3 (च) के, उन
न्यम
( नयत्रण)
ं
आदश,
े 2009 की
ू े टक टायर और ट्यबों
ू के लए लागू हैं िजनके लए गणवत्ता
ु
अनस
ु ची
ू में यथा न हत बीआईएस मानक व न दष्ट कए गए हैं। यह भी स्पष्ट कया जाता है
े 2009 के तहत नम्न ल खत प्रकार के टायर शा मल नहीं हैं: क उक्त गुणवत्ता ( नयंत्रण) आदश,
(i)

(ii)

(iii)

(iv)
—

वा णिज्यक वाहनों के टायर कुछ प्रकार के टायर िजन्हें 80 क. मी./घटा
ं से नीचे की ग त सक
ं े तों

<!-- page 2 -->

द्वारा चिन्हत कया जाता है और ग त संकेतों जस
ै े A (A1 से A8 ), B, C, D अथवा E से चिन्हत कया
जाता है ।

सड़क के अलावा दसर
ू े स्थानों पर चलने वाले टायर सड़क से हटकर दसर
ू े स्थानों पर चलने
वाले वाहनों में प्रयोग कए जाने वाले वशेष टायर िजन पर टायर ट्रड
े कोड की मा कग होती है जस
ै े क
-

C(C1, C2), E(E1 से E4, E7), G (G1 से G4), L(L2 से L5, L3S से LSS), IND अथवा NHS.

रन फ्लैट टायर - RF अथवा इसी प्रकार की मा कग वाले टायर िजन पर होता ह।ै
कोलेप्सीबल मनी टायर ।

तदनसार
टायर उक्त गणवत्ता
( नयत्रण
ं ) आदे श, 2009 के उपबंधों से मक्त
हैं।
ु , उपयक्त
ु
ु
ु
संलग्नक : यथोप र
का संकेत बना

девти

1.

उपभोक्ता मामले वभाग

(श्री अशोक जन
ै , नदे शक (बीआईएस)

कृ ष भवन, नई दल्ली
फैक्स स.ं 011-23386322
(बाबू लाल) नदे शक

दरू भाष सं. 23063212

2.

<!-- page 3 -->

3.

नदे शक (सीमा शल्क
ु )

केंद्रीय उत्पाद शल्क
और सीमा शल्क
बोड
ु
ु
राजस्व वभाग, द् वतीय तल,
,

नॉथ ब्लाक, नई दल्ली
महा नदे शक वदे श व्यापार,

( सुश्री शभ्रा,
डीजीएफटी),
ु संयक्त
ु
वा णज्य वभाग, उद्योग भवन,
फैक्स स.ं 011-23232661
4.

भारतीय मानक ब्यरू ो

5.

6.

7.

8.

<!-- page 4 -->

9.

(ध्यानाथः श्री शरद गप्ता,
महा नदशक),
े
ु

मानक भवन, 9, बहादरु शाह जफर माग, नई दल्ली
फैक्स स.ं 011-23235414

सड़क प रवहन और राजमाग मत्रालय
ं
(श्री आनंद प्रकाश, नदशक),
े
कमरा संख्या 531, प रवहन भवन,

1, पा लयामट
ें स्ट्रीट, नई दल्ली - 1
आटोमो टव टायर मैन्यफक्चरस
एसो सएशन (एटीएमए)
ु ै
(श्री राजीव बद्धराजा,
महा नदशक),
े
ु
पीएचडी हाऊस, (चौथा तल), ए शयन गेम्स वलेज के सामने,

सीरी फोट, इंस्टीट्यश
ू नल ए रया, नई दल्ली- ।

सोसाइटी ऑफ इं डयन आटोमोबाइल मन्य
ै फ
ु ै क्चरस (एसआईएएम ),
(श्री के. क.
े गांधी, कायकारी नदे शक (तकनीकी),
कोर 4- बी, पांचवां तल, इं डया है बटे ट सेंटर,
लोदी रोड, नई दल्ली

-

110003

ऑल इं डया टायर डीलस फेडरे शन,

( श्री एस. पी. सहं, संयोजक ),

865/32, गरू
माग,
ु नानक हाउस, एस.पी. मखज
ु
नई दल्ली - 110006
इं डया टायर टै िक्नकल एडवाइजरी क मटी (आईटीटीएसी),

(श्री टी. चक्रवत , महास चव ),
पीएचडी हाउस (चौथा तल),

अगस्त क्रां त माग,
,

नई दल्ली
-

110016.
G

<!-- page 5 -->

No. 16(72)/2005-LR Government of India
Ministry of Commerce & Industry Department of Industrial Policy & Promotion
(LR Section)

Udyog Bhawan, New Delhi Dated: 13" December, 2011.

Subject:

OFFICE MEMORANDUM
Quality (Control) Order, 2009 for Pneumatic tyres and Tubes for Automotive Vehicles - clarifications regarding.

The undersigned is directed to say that a Quality (Control) Order, 2009 for Pneumatic Tyres and Tubes for Automotive
Vehicles was notified by this Department on 19.11.2009 The said Order has now come into effect w.e.f. 13.05.2011 The
provisions contained in the said Quality (Control) Order, except the requisite exemptions provided under Clauses 3 (a)

to 3(f). are applicable to such pneumatic tyres and tubes for which BIS standards as contained in the Schedule to the Quality
(Control) Order, 2009 have been prescribed. It is further clarified that the following types of tyres are not covered
under the said Quality (Control) Order, 2009 (0)

(11)

Commercial Vehicle Tyres - Certain types of tyres identified by Speed Symbols corresponding to speed below 80 km/h
marked with Speed Symbols as A (A1 to A8), B. C. D or E.

Off The Road Tyres - The specific type of tyres used for Off The Road (OTR) vehicles carrying Tyre Tread Code
marking such as C(C1, C2), E(E1 to E4, E7), G(G1 to G4). L(L2 to L5, L3S to L5S), IND or NHS.
Run Flat Tyres - Tyres marked RF or similar marking and carrying the Symbol

(iv)
Collapsible Mini Tyres

Accordingly, the above tyres are exempt from the provisions of the said Quality (Control) Order, 2009,

<!-- page 6 -->

Department of Consumer Affairs. (Shri Ashok Jain, Director (BIS),
Krishi Bhavan, New Delhi FAX No. : 011-23386322

(BABU LAL) Director
Tele No. 23063212

2.

Director (Customs).
-2-

Central Board of Excise & Customs, Department of Revenue, 2nd Floor, North Block, New Delhi.

Director General of Foreign Trade
3

(Ms. Shubhra, Joint DGFT),

4.

5.

6.

<!-- page 7 -->

7.

8.

Department of Commerce,
Udyog Bhawan, New Delhi.
FAX No.011-23232661
Bureau of Indian Standards

(Kind Attn: Shri Sharad Gupta, Director General)
Manak Bhavan,

9 Bahadur Shah Zafar Marg.
New Delhi.
FAX No. 011-23235414

Ministry of Road Transport and Highways.

(Shri Anand Prakash, Director),
Room No. 531. Transport Bhawan,
1, Parliament Street, New Delhi-1

Automotive Tyre Manufacturers' Association (ATMA), (Shri Rajiv Budhraja, Director General).
PHD House. (4" Floor), Opp. Asian Games Village.
Siri Fort Institutional Area, New Delhi-110016

Society of Indian Automobile Manufacturers (SIAM). (Shri K.K. Gandhi, Executive Director (Tech),
Core 4-B, 5th Floor, India Habitat Centre,
Lodi Road, New Delhi-110003

All India Tyre Dealers Federation,
(Shri S.P. Singh, Convenor),
865/32, Guru Nanak House, S.P. Mukherjee Marg. New Delhi - 110006.
Indian Tyre Technical Advisory Committee (ITTAC).
9.

(Shri T. Chakravarthy, Secretary General),

PHD House (4" Floor).
August Kranti Marg.
New Delhi - 110016.
