---
doc_id: "f2bfddbd773ac762"
source_url: "https://www.mea.gov.in/images/pdf/Vacancy_Circular_for_DPO_Jammu.pdf"
ministry: "External Affairs (MEA)"
title: "Vacancy circular for the post of Deputy Passport Officer at Passport Office, Jammu on deputation basis"
date: ""
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "5390704c01c7766c"
---

<!-- page 1 -->

: ; No. V.1V/575/22/2017
Government of India
Ministry of External Affairs
CPV Division
Patiala House Annexe,
Tilak Marg, New Delhi-110001,
Dated: 11.08.2017
VACANCY CIRCULAR
The Ministry of External Affairs (CPV Division) intends to fill the following post in
Passport Office at stations indicated below amongst officers under the Central Government
including officers of All India Services / Central Secretariat Service in the Ministries /
Departments of the Government of India , on deputation basis:-
| umber of Posts ae Scale of Seen
ame of Passport
ne ik Boe jo spe
Deputy 1 (One): Pay Band 3,| Officers under the Central
Passport Rs. 15,600- | Government including officers of All
Officer 1 Post ~Passport | 39,100 + | India Services:
Office, Grade Pay |
Jammu. Rs. 6,600/-. | (i) holding analogous Posts on
(Pre-revised) | regular basis in the parent cadre or
| | department; or |
| (ii) with five years’ service in the |
| | Grade rendered after appointment
| thereto on a regular basis in posts in
Pay Band-3 (Rs. 15,600-39,100) and
| Grade Pay of Rs. 5,400 (Pre-revised)
| or equivalent in the Parent cadre or
| Department; and
| (b) possessing the following
| | educational qualification and
experience:
(i) Bachelor’s degree from 7
recognized University in India or
Association of Indian Universities
recognized degrees of foreign
| । Universities:
| (ii) One year experience in passport
|or Consular or Emigration or
| Administration or Finance or
so de | ___| Accounts or Vigilance work.
Note 1: The Departmental Officers in the feeder category who are in the direct line of
promotion will not be eligible for consideration for appointment on deputation. Similarly,
deputationists shall not be eligible for consideration for appointment by promotion.
wee

<!-- page 2 -->

+ Note 2: Period of deputation including period of deputation in another ex-cadre post held
immediately preceding this appointment in the same or some other organization or department
of the Central Government shall ordinarily not to exceed three years.

Note 3: The maximum age limit for appointment by deputation shall not be exceeding fifty
six years as on the closing date of receipt of applications.
Note 4: For the purpose of appointment on deputation basis, the service rendered on a regular
basis by an officer prior to the 1“ January, 2006 or the date from which the revised pay
structure based on the Sixth Central Pay Commission recommendations has been extended,
shall be deemed to be service rendered in the corresponding grade pay or pay scale extended
based on the recommendations of the Pay Commission except where there has been merger
of more than one pre-revised scale of pay into
one grade with a common grade pay or pay scale, and where this benefit will extend only for
the post for which that grade pay or pay scale is the normal replacement grade without any
upgradation
2 The selected officers will be on deputation for a period of three years initially which
can be curtailed or extended further, depending upon the requirement, and with the consent
of the officer and approval of the lending department. The usual deputation terms will apply.
3. All Ministries/Departments of Government of India are requested to circulate the
above posts among the officers under the Central Government including officers of All India
Services/ State Government, working with them and forward the application (in prescribed
pro forma Annexure A) of eligible and interested officers, along with their dossiers and a
certificate to the effect that they are clear from vigilance angle, to the undersigned by 11%
September, 2017.
\wo ee
(Mohammad Naseem)
Deputy Passport Officer (PVA & Cadre)
Ph. No. 011-23388648
To,
1. All Ministries/ Department of Government of India
2. All Chief Secretaries to the State Governments.
Copy to:-
1. Ministry of External Affairs-[Kind attn. to: Joint Secretary (Admn)}.
2. Director (XP), Ministry of External Affairs, Shastri Bhawan, New Delhi- with the |
request to upload this circular on the MEA’s website.
3. Director(PSP), Ministry of External Affairs, CPV Division, New Delhi -with the
request to upload this circular on the Passport Seva website
4. Director (CS), DoPT, Lok Nayak Bhawan, Khan Market, New Delhi- with the kind
request to upload this circular on DoPT’s website for wider circulation.
5. All Passport Offices.
6. Branch Secretariat at Chennai, Kolkata, Guwahati, Hyderabad.
7. Spokesman, JCM, MEA, New Delhi. हु
8. O/o IS (PSP) & CPO, CPV Division, MEA, New Delhi.

<!-- page 3 -->

ANNEXURE — A
CURRICULAM VITAE PROFORMA
Affix
Passport Size
Photograph
1. Name (in Block letters) xceoepulpenesosessasityeasestse
Designation (Batch) Dae areata renee antec भरता
2. Applied for the post of pateaiveieen ses nccselcestsuess
(i) Place (Name of Station/s in order) (8 की
(0-००
Cleese
3. Date of Birth (in Christian era) es Hee g ote hose eRe ccm
(i) Age as on 11.09.2017
[closing date of circular] wn banda day Seesaw
4. Date of retirement under Central/
State Government Rules cageuersurree neat eewnavaes
5. Educational Qualifications caleuniean vay sah vaeiaby pee ne
6. Whether belongs to SC/ST paged Rubee riwecvedapestoss
7 (a). Educational qualifications and experienced possessed
Qualification/
Experience possessed
by the officers
Essential (1)
(2)
(3)
Desired (1)
(b). Language Known (Mother Tongue):- <+२००६० ०-6 tae GFE ie wavs wisslconie cw ove |
Contd......2

<!-- page 4 -->

25
8. Details of service, in chronological order.
Enclose a separate sheet, duly authenticated *
by your signature, if the space is insufficient ...
Office/ Post held From To Grade Scale of | Nature of
Institution Pay Pay and | Duties (in
Basic Pay | details)
een eae le teal Aa ees
Leal ed
9. Contact details:
(A) Present Add:-
(i) Tel. No. (व कअ २ कक शुअभ४ ४8० ७+०#
(ii) Mob. No. Pa eee nate aat
(iii) E-mail- siheaeienevasvacdseeee
(B) Office Add(with office name):-
(i) Tel. No. oe को अे+२>म++२+«>5»७
(ii) Mob. No. Be on ai mma a कम ३ सडक
(iii) E-mail- 1028 ७२७ ३३७ ७४७६४४७०७७४७४:००
10. In case the present post is held
on deputation / contract basis, please state
(a) Name of Office / Organization
and address (with Tel. No.) eee eee
(b) The date of initial appointment satagrecusnanuece esse
(c) Period of appointment on deputation Ragetieve swpescetnares |
(d) Name of the parent office / organization
to which you belong teers sere
Contd....3

<!-- page 5 -->

. 3+
I have carefully gone through the vacancy circular and | am well aware that the
Curriculum Vitae duly supported by documents submitted by me will also be assessed by the
Selection Committee at the time of selection for the post.
Signature of the candidate
AddreSS.......000cceeeeereee
Dated .<sccs0e. tees
It is certified that Shri/MS..........ccccceccesseseesseeseeeessrerseeedS Clear from vigilance
angle and in case of selection, he/she will be relieved.
(Signature of Head of Office / Cadre Controlling with Seal)
