---
doc_id: "f2e62bfebab63bc4"
source_url: "https://mohua.gov.in/static/uploads/2025/11/94a1795796b4c9de58ae415c455c4171.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Guidelines for Twinning of Cities 2014"
date: "2025-11-03"
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "99e9a16d757e3b62"
---

<!-- page 1 -->

No.N-11025/26/2011-UCD
Government of India
Ministry of Urban Development
GUIDELINES FOR TWINNING OF CITIES, 2014
I.

INTRODUCTION:

(a) “Twinning of Cities” refers to the development of strategic partnership between two
or more communities in an effort to exchange information, ideas, technical assistance,
training and other pertinent activities related to sustainable development. Such
partnerships have great potential of mobilizing development resources, providing
opportunities for the exchange of knowledge and ideas, improving the capacities of
cities worldwide, and promoting cross-cultural understanding.
(b) An increasing number of development practitioners are embracing the benefits and
potential of “Twinning of Cities” in complementing innovative development
approaches. Twinning of Cities holds much promise not only in providing solutions,
but also in serving as a breeding ground for fostering innovation and change, as the
communities compare and share strategies adopted by them.
(c) Successful Twinning arrangements between cities require several key ingredients,
which include:
 Local political and administrative leadership.
 Local non-government and community-based organizational leadership.
 Development of public-private partnership between the local government and
community-based non-government organizations and corporations.
 Strategic recognition and financial support to City-to-City partnerships and
programmes by international, national and local development agencies.
 Evaluation of projects and partnerships and dissemination of best practices.
 Visibility of City-to-City cooperation as a viable development model.
(d) The opportunities and challenges of the 21st Century require a local governance
system, which is capable of delineating critical issues, offering appropriate policy
alternatives, seeking feedback on which policies to adopt, implementing the agreed
upon policy, and ensuring adequate monitoring and assessment. City-to-City cooperation in this context has the potential of substantially the strengthening local
governments. Through strategic pairs, communities can develop an effective work
plan that focuses on issues of good governance, which is one of the cornerstones for
effective local economic development, besides integrating the local communities into
the global arena.

Page 1 of 9

<!-- page 2 -->

II.

COVERAGE

(a) In view of the rapid transformation that has been happening in the urban sector,
Twinning has become increasingly relevant to all cities. However, twinning proposals
will be processed in respect of Statutory Towns, as notified under relevant law by the
State / Union Territory Government concerned and have duly constituted
municipalities in place.
(b) The categorization of the Indian cities and the maximum number of foreign cities
/provinces/States with which they may be twinned is as under:
S. No
1.
2.
3.
4.
5.
III.

Categorization of Indian Cities
(Population as per Census 2011)
>10 million
5-10 million
1-5 million
0.1 – 1 million
Rest of the cities

Existing

Proposed

4
4
2
1

15
10
5
3
2

OBJECTIVES
The objectives of twinning arrangements should be:

(a) to strengthen bonds of friendship between a city in India and the twinned city in
another country;
(b) the twinning arrangement may not be necessarily monetary
(c) to exchange the expertise and co-operation in the fields of service delivery, civic
administration, land use planning & management, transport, shelter, education,
culture, sports, waste water & solid waste management, infrastructure, environment,
public health, science & technology, tourism, heritage management, urban renewal,
urban and regional planning and related matters;
(d) to promote exchange visits of experts and practitioners in the fields indicated above;
(e) to encourage the study of culture, art, literature and language of twinned cities for
better understanding between citizens;
(f) to invite people of the twinned cities to undertake visits, and specifically encourage
families or associations in the cities to accept the families from other cities as guests
in order to observe the life style of citizens closely and to identify common problems
and solutions;
Page 2 of 9

<!-- page 3 -->

(g) to encourage establishment of links between non-governmental organizations and
associations functioning in the relevant fields in the twinned cities; and
(h) to promote international understanding, goodwill and enrichment of culture, gender
equity, social inclusion and sustainable development.
IV.

NATURE OF TWINNING ARRANGEMENTS
The Twinning Arrangements may be established between an Indian city, and city/
state / province of a foreign country. The twinning arrangement may also associate
multilateral agency; and government agency/ community-based non-government
organization of respective country.

V.

PROCEDURE TO BE FOLLOWED BY STATE GOVERNMENTS
(a) The State Government concerned should obtain the formal consent of the local
government of the foreign city to be twinned.
(b) After it is agreed to twin a foreign city with an Indian city, an agreement may be
reached on specific objectives of twinning within the broad framework of objectives
mentioned above. The said agreement may also spell out the specific activities to be
undertaken, such as visits by citizens, supply of educational and other material
cultural exchanges, support of non-governmental organizations, host families, etc..
(c) Template of the Agreement for the Twinning Arrangement is at Annexure.

VI.

RECEIPT OF PROPOSALS
The Local Self Government (LSG) Division of the Ministry of Urban Development,
Government of India (MoUD) shall receive proposals submitted by the State
Government concerned. The proposals shall be submitted to Director (LSG), Ministry
of Urban Development, Government of India.

VII.

PROCESSING AND APPROVAL OF TWINNING PROPOSALS.

(a) The Ministry of Urban Development, Government of India is the nodal Ministry for
the Scheme Twinning Arrangements.
(b) After scrutiny of the proposal submitted by State Government, the MoUD shall seek
the concurrence from Ministries concerned including the Ministry of External Affairs.
After the ministries concerned give their concurrence to the proposal, the MoUD shall
process the proposal for Final Approval.

Page 3 of 9

<!-- page 4 -->

(c) Final Approval to the Twinning Proposal shall be accorded by the MoUD with the
approval of the Minister of Urban Development. Subsequently, it would be upto the
State Government/Local Body concerned to make necessary arrangements for signing
of the Agreement and implementing the same.

VIII.

GENERAL ISSUES

(a) The Twinning Agreement shall remain in force for period of three years subject to
renewal. It can, however be terminated even earlier, if either Party gives a written
notice to the other Party of its intention to terminate the Agreement at least three (03)
months in advance. The termination an existing Agreement shall not affect
completion of the ongoing projects carried out under the existing Agreement.
(b) All existing Twinning Agreements/MoUs, which do not indicate the duration / life of
the Twinning Agreement/MoU, shall be deemed to have expired, if older than three
years, unless renewed by mutual consent of the two cities/parties and their respective
State Governments.
(c) The Twinning Agreement shall not create binding obligations among the Parties.
(d) Nothing in the Agreement should preclude either of the Parties from exercising any
measures and satisfying any obligations prescribed under the laws of their respective
jurisdiction.
(e) The Parties to the Twinning Agreement should ensure that financial resources and due
procedural approvals to support any activities are available prior to undertaking them.
(f) The Twinning Agreement may be amended at any time by written agreement among
the Parties.
(g) Any dispute arising out of the interpretation, application or implementation of the
Twinning Agreement shall be settled amicably through consultation or negotiation
between the Parties.
(h) All proposals for twinning links should clearly spell out the financial implications,
especially the foreign exchange involved, at the stage of formulation of the
agreement. Where the twinning links involve grant of major financial assistance by
any of the parties/cities, whether in cash or in kind, it should be approved in advance
by the Department of Economic Affairs, Ministry of Finance, Government of India.
(i) The twinning links will be at the local body level and expenditure involved, if any, in
establishing the twinning links would be borne by the concerned local body. There
will be no financial commitment on the part of the Government of India.
Page 4 of 9

<!-- page 5 -->

(j) Visits of foreign delegation in pursuance of the twinning arrangements will follow
established procedures relating to visits and obtaining clearance from authorities
concerned of the Government of India.
(k) The MoUD and the State Government concerned should be kept informed about the
implementation of the twinning arrangements and they may also informally monitor
the various outcomes of the twinning arrangements.
(l) The signatory to the Twinning Agreement should preferably be the Chief Executive of
the City government / Municipality i.e Mayor /Chairperson etc.
(m) After signing the Twinning Agreement, the State Government should place a copy of
the same on their website and also of the city / municipality concerned, besides
providing a copy of the same to the Ministry of Urban Development and Ministry of
External Affairs, Government of India.
(n) The State Government should appoint a Nodal Officer for twinning matters.
(o) The Indian High Commission/ Embassy should be kept informed of the agreement
and the follow up action taken after the cities have been twinned.
(p) The Indian city that is twinned with any foreign city should maintain proper
documentation regarding the various activities undertaken in pursuance of the
agreement. It should send annual reports to the State Government concerned and
Ministry of Urban Development and Ministry of External Affairs, Government of
India besides placing on the relevant website.

********

Page 5 of 9

<!-- page 6 -->

Annexure
TEMPLATE FOR TWINNING AGREEMENT
AGREEMENT ON THE ESTABLISHMENT
OF FRIENDSHIP AND COOPERATION
BETWEEN
_______________________________________
AND
_______________________________________

1) Introduction
The Municipal Corporation / Council / Committee/ Municipality of ________City, (the
State), Republic of India and the _________ (_______) (hereinafter referred to as the
“Parties”),
In furtherance of their desire to establish friendship and cooperation between the two Parties,
thus contributing to the enhancement of the relations of strategic partnership between
_______ and India,
Have agreed to the following
2) Purpose
The purpose of this Agreement is to
(a) establish friendship & cooperation and create mechanisms for its implementation
within the framework of their respective jurisdiction, on the basis of mutual respect,
equality and mutual benefit, in conformity with the laws and policies of _______ and
India as well as the international agreements inked by the two countries;
(b) maintain regular contacts including between the designated authorities;
(c) To the above ends, to undertake exchanges involving delegations, interaction
between institutions, and sharing of experiences in the areas of mutual interest.

3) Areas of Cooperation
To exchange the expertise and co-operation in the fields of service delivery, civic
administration, land use planning & management, transport, shelter, education, culture,
sports, waste water & solid waste management, infrastructure, environment, public
health, science & technology, tourism, heritage management, urban renewal, urban and
regional planning and related matters.

Page 6 of 9

<!-- page 7 -->

4) Roles of Parties
In order to implement the activities mentioned above, the Parties will carry out their work
assignments as described below:
I.

Role of Municipal Corporation / Council / Committee/ Municipality of
________City (the Republic of India)

(d) Solicit the support of Urban Development Department, Government of (State
Government) for implementing all relevant aspects of this Agreement.
(e) Undertake all works according to the highest professional and ethical standards.
(f) Create and operationalize a Twinning Cell at the City level.
(g) Form a Committee to support the Twinning Cell and give technical advice.
(h) Support the organization of activity related workshops etc.
(i) Conduct community participation activities and coordinate with concerned.
(j) Maintain proper documentation regarding the various activities undertaken in
pursuance of this agreement and send annual reports to the State Government
concerned and Ministry of Urban Development and Ministry of External Affairs,
Government of India, besides placing on the relevant website
(k) Ensure, after signing of the Twinning Agreement, to place a copy of the same on the
website of City and the State Government, besides formally providing a copy of the
same to the Ministry of Urban Development and Ministry of External Affairs
Government of India.
(l) Any other specific role/s as agreed among Parties.
II.

Role of ___________________________(Foreign City/Province)

(a) Solicit the support of __________, Government of (Foreign Government)
implementing all relevant aspects of this Agreement.
(b) Undertake all works according to the highest professional and ethical standards.
(c) Create and operationalize a Twinning Cell at the City /Province level.
(d) Form a Committee to support the Twinning Cell and give technical advice.
(e) Support the organization of activity related workshops, study tours etc.
(f) Conduct community participation activities and coordinate with concerned.
(g) Any other specific role/s as agreed among Parties.

for

5) Obligations of Parties
The Parties shall
(a) Conduct regular meetings to communicate on all programmes, projects and activities
that are to be undertaken under this Agreement.
(b) Develop an annual „Joint Action Plan‟ and project proposals/activities.
(c) Ensure that financial resources to support exchanges and activities are available prior
to undertaking them.

Page 7 of 9

<!-- page 8 -->

(d) Develop modalities of financial obligations and establish financial agreement for
implementation of activities in the remit of the Joint Action Plan.
(e) Develop modalities of financial obligation between the Parties to cover the domestic
travel and hospitality national and availability of international experts for the
implementation of the projects/activities.
(f) Jointly develop modalities of international collaboration with international cities and
regions in remit of this Agreement.
(g) Inform their respective national governments periodically about the activities being
undertaken under this Agreement.
6) Statutory Compliance
(a) This Agreement shall not create binding obligations among the Parties. Nothing in the
Agreement shall preclude either of the Parties from exercising any measures and
satisfying any obligations prescribed under the laws of their respective jurisdiction.
(b) This Agreement is not intended to create a legal binding obligation to expend funds or
resources by either party, but is a statement of bona fide intent of the participants. It
sets forth the entire understanding of the participants in respect of the collaboration
considered.

7) Implementation of the Agreement
(m) The Parties shall, within the remit of their respective capacities, mandates and
resources, make the necessary arrangement to ensure mutually satisfactory
implementation of this Agreement.
(n) The Parties shall publicize this Agreement by mentioning such cooperation in any
relevant documents and materials related to the activities implemented under this
Agreement.
8) Amendment
This Agreement may be amended at any time by written agreement among the Parties.

9) Duration & Termination of Agreement
The Twinning Agreement shall remain in force for three years subject to renewal or
unless either Party gives a written notice to the other Party of its intention to terminate the
Agreement at least three (03) months in advance. The termination of an existing
Agreement shall not affect completion of the ongoing projects carried out under such
Agreement.

Page 8 of 9

<!-- page 9 -->

10)

Nodal Officers
The Nodal Officers for this Agreement shall be as under:-

I.

For the Municipal Corporation / Council / Committee/ Municipality of ________City
(the Republic of India) - __________________________

II.

For the ___________________________(Foreign
_____________________

11)

City/Province,

Country)-

Settlement of Disputes
Any dispute, controversy or claim arising out of the agreement or the breach, termination
or invalidity thereof which could not be settled through direct negotiations would be
amicably settled through conciliation and discussions.

For and on behalf of

For and on behalf of

......................................

.......................................

Dated:................

Page 9 of 9
