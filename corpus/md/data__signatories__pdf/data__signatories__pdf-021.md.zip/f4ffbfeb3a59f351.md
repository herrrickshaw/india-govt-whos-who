---
doc_id: "f4ffbfeb3a59f351"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/ceee233681865ae93c792c5bea9c221b.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Implementation of the recommendations of Technical Sub-committee constituted by DST under the aegis of the Geospatial Guidelines issued by DST on 15.02.2021"
date: "2022-12-21"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "73414fa150e4a49e"
---

<!-- page 1 -->

Dated the 21st December, 2022

No. SM/25/04/2021
To,
1. All Central Ministries/Departments
2. State Govts/UTs
3. Other data producing Agencies (as per list)

Sub: Implementation of the recommendations of Technical Sub-committee
constituted by DST under the aegis of the Geospatial Guidelines issued by DST
on 15.02.2021.

Sir/Madam
I am directed to refer to the above-mentioned subject and to say that under
the provisions of Geospatial Guidelines dated 15.02.2021, a Technical Subcommittee constituted by DST to advise on doubts related to technological matters,
address any gaps related to the implementation of the Guidelines and suggest
technological solutions for easy compliance of the Guidelines.
2.
The Tech sub-committee has given various recommendations which have
been accepted by GDPDC. The competent authority in DST has approved the
recommendation in Chapter-6 of the tech Sub-committee report i.e. National
Horizontal, Vertical, Gravity Framework should be adopted for all public
funded geospatial/gravity surveys, for implementation.
3.
You are, therefore, requested that the above-mentioned recommendation
related to adoption of National Horizontal, Vertical, Gravity Framework may be
implemented in all further surveys.
Yours faithfully

(Unni Krishnan)
Under Secretary to the Govt. of India
Tel.: 011-26590422

<!-- page 2 -->

सं. एस.एम./25/04/2021
सेव में ,

दिन ंक 21 दिसंबर 2022

1.सभी केन्द्रीय मंत्र लय/ववभ ग

2.र ज्य सरक र/संघ श ससत प्रिे श

3.अन्द्य आंकड़ सज
ू ी अनस
ु र)
ृ क असभकरण (सच
विषय: विज्ञान और प्रौद्योगिकी विभाि द्िारा दिनाांक 15.02.2021 को जारी भस्
ू थाननक दिशाननिे शों के
तत्िाधान में डीएसटी द्िारा िदित तकनीकी उप-सममनत की अनश
ां ाओां का कायाान्ियन।
ु स
महोिय/महोिय
मझ
ु े उपयक्
ु त ववषय क उल्लेख करने और यह कहने के सलए ननिे सशत ककय गय है कक दिन ंक

15.02.2021 के भ-ू स्थ ननक दिश ननिे शों के उपबंध के तहत, तकनीकी म मलों से संबधं धत संिेहों पर सल ह

िे ने, दिश ननिे शों के क य ुन्द्वयन से संबधं धत ककसी भी अंतर ल पर ध्य न िे ने और दिश ननिे शों के आस न
अनप
ु लन क तकनीकी सम ध न सझ
ु ने के सलए तकनीकी उप-ससमनत डीएसटी द्व र गदित की गई है ।
2.

तकनीकी उप-ससमनत ने ववसभन्द्न ससफ ररशें िी हैं जजन्द्हें जीडीपीडीसी ने स्वीक र कर सलय है । डीएसटी

में सक्षम प्र धधक री ने तकनीकी उप-ससमनत की ररपोटु के अध्य य-6 में की गई ससफ ररश को अनम
ु ोदित कर
दिय है अथ ुत र ष्ट्रीय क्षैनतज, ऊध्व ुधर, गरु
ु त्व प्र ध र को सभी स वुजननक ववत्त पोवषत भ-ू स्थ ननक/गरु
ु त्व
सवेक्षणों के सलए क य ुन्द्वयन की दृजष्ट्ट से अपन य ज न च दहए।
3.

अतः अनरु ोध है कक राष्ट्रीय क्षैतिज, ऊर्ध्ााधर, गरु
ं ी उपरोक्त उजल्लखखत
ु त्् प्राधार के असभग्रहण संबध

अनश
ं ओं को भ वी सभी सवेक्षणों में क य ुजन्द्वत ककय ज ए।
ु स

भविीय,

(उजणण कृष्ट्णन टी.)

अवर सधचव, भ रत सरक र
िरू भ ष: 011-26590422
