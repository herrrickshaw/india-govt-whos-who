---
doc_id: "f3ec7f460dfceaef"
source_url: "https://master-dolr.digifootprint.gov.in/static/uploads/2025/09/1065a8de6c619e05531c658d244adf40.pdf"
ministry: "Department of Land Resources (DLR)"
title: "Inviting Research Proposals for undertaking Research from reputed National/International Institutions and Individuals"
date: "2024-03-07"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bb4ce848f0bb2b88"
---

<!-- page 1 -->

No 28012/92/2024-LRD -LRD
Government of India
Ministry of Rural Development
Department of Land resources
Inviting Research Proposals for undertaking Research from reputed
National/International Institutions and Individuals
Department of Land Resources (DoLR), Ministry of Rural Development invites research
proposals from individuals/ institutions for “Land Administration”. Accordingly, research
proposals are invited on following topics from relevant and experienced National/International
Institutions and Individuals: i.
Land administration
ii.

Land policies, laws and regulations

iii.

Monitoring land governance and land tenure security

iv.

Land and socio-economic development

v.

Land use management

vi.

Land markets, land value, land transactions

vii.

Geospatial technology in land governance

viii.

Innovative land management tools and techniques

2.
The detailed guidelines for Institutional and Individual Research Grant for Land
Administration Domain including eligibility criteria, selection process and prescribed
application formats etc., are given at the official website of this Department i.e.
https://dolr.gov.in/. Interested experienced National/International Institutions and Individuals
may send their proposals duly signed (scanned / PDF) through e-mail at
navalsingh.meena@nic.in & neebha.2002@gov.in only. The last day of receiving research
proposals is one month from the date of publication of the Advertisement.
Sd/-

Deputy Director (LR)
Department of Land Resources,
Ministry of Rural Development
Government of India, New Delhi
