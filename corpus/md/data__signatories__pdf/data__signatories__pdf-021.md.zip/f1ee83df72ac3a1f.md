---
doc_id: "f1ee83df72ac3a1f"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/06/c614b5011cefeb616b7119b209a57891.pdf"
ministry: "Tourism"
title: "Guidelines for Approval of Guest Houses"
date: "2025-08-04"
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7e8993a3caa01de6"
---

<!-- page 1 -->

Government of India
Ministry of Tourism
(H&R Division)
GUIDELINES FOR APPROVAL OF GUEST HOUSES
(Revised – December 2009)
In order to meet the rising demand of hotel accommodation for budget tourists both
domestic and foreign, Ministry of Tourism has decided to standardize and ensure good, clean,
hygienic, fair and upgraded facilities and practices in the large number of Guest Houses and
unregulated accommodation units that spring up in cities and towns. These measures may not
only augment hotel accommodation in budget category but also generate employment and
revenue for the States. With this aim in view, Govt. of India, Ministry of Tourism has a
voluntary Scheme for approval of Guest Houses in the country.
Guest Houses seeking approval should have the following features:I. Necessary Requirement
(i)

(ii)
(iii)
(iv)
(v)
(vi)
(vii)
(viii)

(ix)
(x)

(xi)
(xii)
(xiii)
(xiv)

(xv)
(xvi)

Minimum 6 (six) lettable rooms with proper ventilation and 6 meters approach road
for Taxi / Ambulance (the road width of minimum 6 metres would not be mandatory
in those cities, where Guest Houses on road width of less than 6 metres are
permitted as per bye-laws/ local rules)
Minimum size of the room should be 120 sq. ft. for double bed (or more). For single
bed room, the minimum size of the room should be 80 sq.ft.
Minimum size of the bathroom should be 30 sq. ft. for double room. For single bed
room, the minimum bathroom size should be 20 sq.ft.
25% of the rooms should have air–conditioning / heating facilities
Sufficient lighting, wardrobe, shelves, opaque curtains or screening on all windows
Western W.C. toilet
Reception facility with telephone
Dining room serving breakfast and dinner with proper cutlery and glassware (dining
room would not be mandatory in cases where the local bye-laws of the concerned
State / local body do not permit dining room in Guest houses. (Similarly, bar would
not be mandatory in cases where the local bye-laws of the concerned State / local
body do not permit dining room in Guest Houses)
Segregated wet and dry garbage disposal system should be available
Cleanliness & Hygiene: Front areas/ public areas, rooms, kitchen, store, pantry,
refrigerator, dining area/ bar (where applicable as per bye-laws), garbage area,
staff facilities and back areas including maintenance areas
(Note: Minimum 60% marks are required under criteria No. 6 of the Mark
Sheet regarding Cleanliness/ Hygiene)
Tie-up with nearby Hospital or Doctor-on-Call facility
Safe- keeping facilities at the reception
Fire and emergency measures
RO treated/UV treated water / Branded bottled water to be made available for
guests. Availability of 24 hours water. RO treated/UV treated water to be used for
cooking
Facility for adequate parking space
Pest control of all front of the house, guest rooms, kitchen (where permitted), staff
facilities and back areas to be done regularly

1

<!-- page 2 -->

(xvii)

Registration with local authorities like Police, Municipality, Electricity, Water, Fire,
State Tourism Department or Corporation
(xviii) CCTV in public areas with data backup is mandatory

II.

DESIRABLE SERVICES

(i)

Staff quality with 10% of the staff experienced or one year certificate course from
the Catering / Hotel Management Institute
Recycling of waste water
Dishwasher
Coffee, tea dispenser
Credit Card facilities
Tie-up with travel agents / nearby Hospital or Doctor-on-Call facility
Room, ramp and dedicated public restroom for the physically challenged persons

(ii)
(iii)
(iv)
(v)
(vi)
(vii)

The Hotel & Restaurant Approval & Classification Committee (HRACC) inspects and
assesses the Guest Houses based on facilities and services offered. For approval of Guest
Houses, application along with the requisite fees may be sent to the Regional Director,
Indiatourism Office in whose region the Guest House is located:
1. Regional Director
Indiatourism
West & Central Region
23, M. Karve Road
Mumbai-400020
Tel: 022-22033144/5
E-mail: indiatourism@mtnl.net.in

2. Regional Director
Indiatourism
Northern Region
88, Janpath
New Delhi-110001
Tel: 011-23320342
Email:goitodelhi@tourism.nic.in

2. Regional Director
Indiatourism
Southern Region
154 Anna Salai,
Chennai- 600 002
Tel: 044-8461459
E –mail: indtour@dataone.in

4.Regional Director
Indiatourism
Eastern Region
Embassy, 4
Shakespeare Sarani
Kolkata -700 071
Tel: 033-22821402
Email: indtour@cal2.vsnl.net.in

5. Regional Director,
Indiatourism
North Eastern Region
Amarawati Path
Christian Basti
G. S. Road, Guwahati - 781 005
Tel: 0361- 2341603
E-mail indtour@asm.nic.in

2

<!-- page 3 -->

Government of India
Ministry of Tourism
(H&R Division)
GUIDELINES FOR APPROVAL OF GUEST HOUSES
(Revised – December 2009)

General Terms and Conditions- Application Format For Approval of Guest Houses
Guest Houses applying for approval must provide the following documentation:1. Name of the Guest House
2. Name and address of the promoters/ owners with a note on their business antecedents
3. Complete postal address of the Guest House with Telephone No. / Fax / E-mail
4. Status of the owners/ promoters
(i) If public /private limited company with copy of Memorandum and Articles of
Association
(ii) If partnership, a copy of Partnership Deed and Certificate of Registration
(iii) If proprietor concern, name and address of proprietor/ certificate of registration
5. Date on which the Guest House became operational
6. Distance of Guest House (in kms.) from:
a. Airport
b. Railway Station
c. City centre
d. Downtown shopping area
7. Details of the Guest House:
(i)
Area (in sq. meters) with title- owned/ leased with copies of sale/ lease deed
(ii)
Copy of Land Use Permit / Licence to run Guest House from appropriate authority /
Registration from local authorities
(iii)
Number of rooms
(iv)
Public restroom facilities for ladies and gents
(v)
Details of public areas, lobby, bar (where applicable), parking facilities (the area for
each facility should be indicated in sq. ft.)
(vi)
Facilities for the physically challenged persons (dedicated room with bathroom,
ramps and access to public areas)
(vii)
Eco-friendly practices and any other additional facilities (water harvesting, solar
heating)
(viii) Details of Fire Fighting Measures/ Hydrants, etc.
(viii) Details of measures for energy saving / water conservation and other initiatives.
(ix)
Details of air-conditioning.
(ix)
Facilities for power back–up (generators etc.)

3

<!-- page 4 -->

(x)

Details of CCTV with data backup (mandatory for all public areas)

8. Certificates / No Objection Certificates (attested copies).
(i)

(ii)
(iii)
(iv)
(v)
(vi)
(vii)
(viii)
(ix)
(x)

Certificate / licence from Municipality/ Corporation to show that the establishment is
registered as a Guest House including Clearance by competent authority to the
establishment on sanitary / hygienic point of view.
Certificate/ licence from concerned police department authorizing the running of a
Guest House.
No Objection Certificate with respect to fire fighting arrangements from the Fire
Service Department (Local Fire Brigade Authorities).
Public liability insurance (Desirable)
Bar Licence (required where permissible as per local laws and regulations)
Money Changers Licence (if any).
Sanctioned building plans/ occupancy certificate.
If approved earlier, a copy of the earlier Certificate of Approval issued by
Ministry of Tourism.
Segregation of areas for smoking, non- smoking under the rules.
Any other Clearance / Licence required from local authority.

Note: The above mentioned approvals/ No Objection Certificates are the responsibility of the
owners/ promoters/ concerned Company as the case may be. The Ministry’s approval is no
substitute for any statutory approval and the approval given is liable to be withdrawn without
notice in case of any violations or misrepresentation of facts.
9. All applications for approval of Guest Houses must be complete in all respects- application
form, application fee, prescribed clearances, NOCs, Certificates etc. Incomplete application is
liable to be rejected.
10. The application fee payable for approval and renewal of a Guest House is Rs. 5000/-. The
demand draft maybe made payable to "Pay & Accounts Officer, Ministry of Tourism, New
Delhi".
11. The Committee for approval of Guest Houses will consist of the following:(i)

(ii)
(iii)
(iv)

The Committee will be chaired by the Regional Director, Indiatourism Office of the
concerned region; Director, State Tourism Department or his nominee; IATO; TAAI;
IHM. In addition, a nominee of the Guest House Federation will be a member. The
recommendations will be sent to HRACC Division, Ministry of Tourism, Govt. of India
within 3 weeks.
The Chairman and any 3 members will constitute a quorum.
The minutes will be approved by the Chairman (HRACC).
The quality of facilities and services will be evaluated against the mark sheet.

12. The Guest House is expected to maintain required standards at all times. The Approval
Committee may inspect a Guest House at any time without previous notice.

4

<!-- page 5 -->

13. Any deficiencies/ rectification pointed out by the HRACC during inspection, must be
complied within the stipulated time. Failure to do so will result in rejection of the
application.
14. The Guest House must be able to convince the committee that they are taking sufficient
steps to conserve energy and water, garbage segregation and disposal/ recycling as per
Pollution Control Board (PCB) norms and other Eco-friendly measures.
15. Any changes in the plans for management of the Guest Houses should be informed to
the HRACC, Govt. of India, Ministry of Tourism within 30 days otherwise the approval will
stand withdrawn/ terminated.
16. Applicants are requested to go through the check list of facilities and services contained
in this document before applying.
17. Incomplete applications will not be considered. As far as possible, cases of approval
would be finalized within 3 months of the application being made.
18. Guest Houses seeking approval should apply 3 months prior to the expiry of the current
period of approval.
19. Approval will be valid for five (5) years from the date of issue of orders or in case of reapproval from the date of expiry of the last approval provided that the application has been
received within the stipulated time mentioned above, along with all valid documents.
Incomplete applications will not be accepted.
20. In case of any dissatisfaction with the decision of HRACC, the Guest House may appeal
to Secretary (T), Government of India for review and reconsideration within 30 days of
receiving the communication regarding approval/ renewal. No requests will be entertained
beyond this period.
21. The Govt. of India, Ministry of Tourism reserves the right to modify the ‘Guidelines/
Terms and Conditions’ from time to time.
*****

5

<!-- page 6 -->

FORMAT FOR UNDERTAKING
(To be furnished on official Letter Head)

To
The Regional Director
Indiatourism
New Delhi/ Mumbai/ Kolkata/ Chennai/ Guwahati

Undertaking

I have read and understood all the terms and conditions mentioned above with respect to
approval of Guest House and hereby agree to abide by them. The information and documents
provided by me are correct and authentic to the best of my knowledge.

Signature
Name in block letters
Seal

Place:
Date:

6

<!-- page 7 -->

Government of India
Ministry of Tourism
(H&R Division)
GUIDELINES FOR APPROVAL OF GUEST HOUSES
(Revised – December 2009)
Mark Sheet for Assessment by HRACC
Inspection Date: _____________________________________________________________
Name of the Guest House: ______________________________________________________
Address: _____________________________________________________________________
Telephone no. & Fax No. _________________________________________________________
E-mail:

______________________________________________________________

S.
No.

Criteria & Questions

Maxi
mum
Marks

1.

Location & décor
10
(Please give brief description, environment, etc.)

10

2.

Dining facilities
Breakfast/lunch / dinner room service/ self service

10

3.

Crockery/ Glassware/ tableware/ linen

10

4.

Maintenance of kitchen/ utensils (3 Tier-Washing
system should be applied)

10

5.

Cold storage facilities

5

6.

* Cleanliness/Hygiene
Front areas/ public areas, rooms, kitchen, store,
pantry,
refrigerator, dining area/bar (where applicable as
per by-laws), garbage area, staff facilities and
back areas including maintenance areas
(*Note: Minimum 9 marks (60%) in this
criteria are required to qualify for approval)

15

7.

Pest Control
front of the house, guest rooms, kitchen and F&B
areas, back areas, stores (where permitted), staff
facilities and back areas

10

8.

Staff (Please give list of staff with percentage of
trained/
experienced employees)

10

9.

Uniform and staff facilities (smart & clean
uniforms, staff lockers etc.)

5

Marks
obtained

Answers/ Details of
the facilities
offered

7

<!-- page 8 -->

10.

RO treated/UV treated water / Branded bottled
water to be made available for guests.
Availability of 24 Hour water . RO treated/UV
treated water to be used for cooking

5

11.

Parking facilities
(There should be adequate space for parking)

5

12.

Safety and Security
CCTV in public areas with data
backup

5

13.

Other facilities/
categories

amenities

under

desirable

Total Marks:

5

100

Note:
Minimum 9 marks (60%) is required under criteria No. 6 – Cleanliness/ Hygiene- to qualify
for approval.
Overall minimum qualifying marks required
for approval

60

Comments:___________________________________________________________________________
_____________________________________________________________________________________
_____________________________________________________________________________________
_____________________________________________________________________________________
_____________________________________________________________________________________

S. No.

Members

Name & Designation

1.

Chairman

2.

Director State
Dept./ nominee

3.

IATO

4.

TAAI

5.

IHM

6.

Nominee of Guest House
Federation

Signature

Tourism

8

<!-- page 9 -->

9
