---
doc_id: "f3a9f9365ffdb7ea"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/045273aa7b2f0e5de491755521651946.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Age of retirement of employees of Public Sector Enterprises."
date: "2001-08-22"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4349bf781802f95e"
---

<!-- page 1 -->

Age of retirement of employees of Public
Sector Enterprises.(DPE O.M. No. 18(10)/99GM-GL-33 dated 22nd August, 2001)
[Amended vide O.M. dated 1.4.2005 (GL-62)
at S. No. 33]
CHAPTER II
PERSONNEL POLICIES
(c) Service Matters
59.
Age of retirement of employees of Public Sector Enterprises.

DPE/Guidelines/II(c)/25

The undersigned is directed to refer this Department’s O.M. of even number dated 1.1.2001 on the
subject mentioned above wherein the decision of the Government that proposals for roll back of age
of retirement of employees of sick/unviable PSEs for which rehabilitation/revival packages are
under consideration, which are duly approved by the Board of Directors and also the Minister-incharge of the administrative Ministry need not be brought before the Cabinet was communicated.
2. The Government has further considered the question of extending the above decision to all PSEs
and all categories of employees, both Board level and below Board level, and it has been decided
that henceforth the Minister-in-charge of the administrative Ministry will have the authority to
approve proposals for roll back of age of superannuation from 60 years to 58 years for all PSEs and
all categories of employees, both Board level and below Board level, which are duly approved by
their Board of Directors.
3. As a consequence of the above decision, the Government has also decided as under:
(i) To fix another cut-off age of 56 years for recruitment to Board level posts in respect of those
PSEs where the age of retirement is 58 years so that a minimum of 2 years residual length of service
before retirement is available on the same principle of the cut-off age of 58 years for recruitment to
board level posts in respect of PSEs where the age of retirement is 60 years. This is in partial
modification of this Department’s O.M. No. 18(6)/98-DPE (GM) dated 3.2.1999.
(ii) To revert back the upper age limit for recruitment by the method of direct open competitive
examination to below board level posts in the case of PSEs where the age of retirement is rolled
back to 58 years. This would be in partial modification of this Department’s O.M. No. 18(6)/98-GM
dated 28.6.1999. A reasonable period of at least 3 months will be given for the reduced upper age
limit to have effect.
4. All the administrative Ministries/Departments are requested to kindly take note of the above
decisions for information and necessary action. This may also be brought to the notice of all PSEs
under this administrative control for appropriate necessary action.
(DPE O.M. No. 18(10)/99-GM-GL-33 dated 22nd August, 2001)
[Amended vide O.M. dated 1.4.2005 (GL-62) at S. No. 33]
***

<!-- page 2 -->
