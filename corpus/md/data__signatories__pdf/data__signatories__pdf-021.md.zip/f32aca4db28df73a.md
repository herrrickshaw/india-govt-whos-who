---
doc_id: "f32aca4db28df73a"
source_url: "https://dohe-education.gov.in/static/uploads/2026/03/0a3a411ab32d89759e323307bf0124bd.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Instruction Manual"
date: "2026-03-31"
pages: 39
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "df3a33b28f904be2"
---

<!-- page 1 -->

Pradhan Mantri Uchchatar Shiksha Protsahan Yojana
SPECIAL SCHOLARSHIP SCHEME FOR THE
STUDENTS OF UTs OF JAMMU & KASHMIR AND LADAKH
ACADEMIC SESSION 2025-26

SSSJKL Registration & Joining Process
Implemented By
ALL INDIA COUNCIL FOR TECHNICAL EDUCATION,
NELSON MANDELA ROAD, VASANT KUNJ New Delhi-110070

<!-- page 2 -->

Eligibility of Students for Registration under SSS JK&L
•
•

Resident of UTs of J&K or Ladakh (Domicile Certificate)
Note: For JKBOSE Students: Kindly Add Prefix Code before your 12th Roll Number (For Eg:-15AJTP1234567)
Note: For CBSE Students : Kindly Add prefix 24 before your 12th Roll Number if your year of passing is 2023-2024 and 25 if your
year of passing is 2024-2025 (For Eg: If your roll number is 12345678 then for 2023-2024 it will be written as 2412345678 and for 202425 it will be written as 2512345678)
Note: If you are already registered in last year 2024-2025 counselling, please register with your new email address and mobile number
for the current year 2025-2026 counselling.

•

Passed 10+3 Diploma from JKSBOSE (Passed/Appearing in academic year 2023 or 2024)

•

Family Income is upto Rs. 8.00 Lakhs (Family Income Certificate issued by Govt. J&K or Ladakh - not more than 6 months old)

•

Reservation Policy as per the norms decided by the J&K Govt.

•

Active Aadhaar Number – seeded with saving Bank Account of the student will only be accepted

•

Valid Mobile Number & Email ID for future communication (Important)

•

Candidate, Mother & Father Name exactly as per Matric Certificate

<!-- page 3 -->

Steps for Registration
• Open https://www.aicte-jk-scholarship-gov.in/ in the browser (use google chrome preferably ) or
scan the QR code in the right hand side corner of the slide.

• Go through the Frequently Asked Questions available on the AICTE website.
• Click on the button Registration for SSS JK&L Academic Year 2025-26 – HSC (12th)
• Click on the button Registration for SSS JK&L Academic Year 2025-26 - Lateral Entry-Diploma
Holders (directly in 2nd year in Engineering Stream only)

• Fill up the Registration Form and Submit
• Correct the errors (if any)
• On Successful registration, you will receive an Email/SMS on registered email ID/Mobile
• Click on Verification Link
•
Registration is Completed

<!-- page 4 -->

SSS JK&L Webportal (https://www.aicte-jk-scholarship-gov.in/ )

<!-- page 5 -->

<!-- page 6 -->

Registration Form

<!-- page 7 -->

Registration Initiated

<!-- page 8 -->

Registration Confirmation : Email and SMS

• This will be an automated Email ; SMS sent to the candidate

<!-- page 9 -->

Registration Successful

<!-- page 10 -->

Error Handling

• Read the error carefully and correct the information so that registration process can be
completed.

• Contact JKBOSE / CBSE / JKSBOTE if still unable to register
• Contact AICTE on 011-29581051,07,08/43 or email to jkadmission2025@aicte-india.org in
case email/SMS have not been received by you.

<!-- page 11 -->

Important Points
• Enter Genuine e-Mail and Mobile Number of the candidate, since these will be used for

future communication
• Always remember your username and password for future purpose
• Active Aadhaar Seeded Bank account are mandatory for Direct Benefit Transfer
• For updates Visit AICTE / SSS JK&L web-portal regularly.
• The students are advised to fill the right caste category in the application form as per their
certificate. Any discrepancy found later may result in cancelation of
admission/scholarship and other legal consequences.

• All the stakeholders who are applying for scholarship under SSS JK&L for J&K and

Ladakh may note that entire data captured on SSS JK&L Portal during registration will be
provided to National Scholarship Portal (NSP) maintained by MeITY, Govt. of India for
de-duplication and the students who are found by the NSP gaining scholarship from other
Govt. Schemes as well as SSS JK&L in previous years are likely to be rejected and the
decision of the NSP will be final. For details, please visit AICTE SSS JK&L website.

<!-- page 12 -->

SSS JK&L
Application Submission

<!-- page 13 -->

Pre-requisites for Application Submission
Self Attested Scan copy of (in jpg/png not more than 2mb)

• Domicile Certificate
• SSC(10th Class) Mark sheet
• Family Income Certificate (Issued by Tehsildar or equivalent)
• Aadhaar Card
• Reservation /Physically disabled certificates (if any)
Other attachments (in jpg/png not more than 10kb–50 kb)

• Passport Size photo ( 200 x 230 pixels - preferred)
• Passport Size photo of Father/Guardian ( 200 x 230 pixels - preferred)
• Passport Size photo of Mother/Guardian ( 200 x 230 pixels - preferred)
• Signature (140 x 60 pixels - preferred)

<!-- page 14 -->

Steps for Application Submission

• Open https://www.aicte-jk-scholarship-gov.in/ on the browser
• Login through your existing username and password
• Fill up the form i.e. Personal, Address, Family and Income, Educational
Details.

• Upload the attachments.
• Refresh the browser and read the information filled by you carefully.
• Preview. Enter the preferences and Grievance Centre Details
• Click on “Submit Application” button. (Correct errors if any)
• Application is Submitted
• Print Application Report and Visit the facilitation Centre along-with
supporting documents(Originals) given in Application report for
Document Verification

<!-- page 15 -->

Login

• Open https://www.aicte-jk-scholarship-gov.in/ on the browser
and login through email and password.

• Now login and Proceed for Application Submission

<!-- page 16 -->

Personal Details

<!-- page 17 -->

Address Details

<!-- page 18 -->

Family & Income Details

<!-- page 19 -->

Education Details

<!-- page 20 -->

Upload the Attachments

<!-- page 21 -->

Format of Undertaking

<!-- page 22 -->

Application Preview

<!-- page 23 -->

Submit the application

<!-- page 24 -->

Print Application Form

<!-- page 25 -->

Print Application Form

<!-- page 26 -->

Document Verification Instructions for Students
• Candidate is requested to get his/her documents verified from any of the designated Facilitation-cum-Document
Verification Centers(FDVC) established for admission under J&K Special Scholarship Scheme.

• Please visit www.aicte-jk-scholarship-gov.in to get list of Facilitation Centers and Facilitation-cum-Document
Verification Centers(FDVC).

• Original Documents to be produced at the time of Verification at FDVC.
✔ X th Standard Mark sheet

✔ Domicile certificate
✔ Aadhaar card
✔ Family Income Certificate (Issued by Tehsildar or equivalent)
✔ Valid Caste certificate for SC/ST/SEBC (Claiming reservation, if any).
✔ Valid differently abled/Divyangjan/PWD Certificate (If any).

• After document verification from the FDVC candidate should collect the copy of document verification report
without fail.

• Candidates should submit one set of Photocopies (Xerox) of all the documents produced at the time of Verification
to the FDVC.

• Candidate should not submit any Original document at the FDVC.

<!-- page 27 -->

Important Instruction for Students

• Don’t Share User ID / Password with any body. It is highly Confidential.
• Always take the student copy from the FDVC positively.
• For any technical issues please raise the grievance on https://css.aicteindia.org/login or jkadmission2025@aicte-india.org

• Contact AICTE on 011-29581051/07/08/43 between office hours.

<!-- page 28 -->

SSSJKL
Choice Filling Process by the
Students

<!-- page 29 -->

Steps for Choice Filling

• Login through the portal.
• Explore the list of colleges you are eligible for by using filters of Category,
Region , State, Type of Institution etc.

• Know the details of the College on pop up on the Institute name.
• Add colleges of your choice by pressing the + button.

• Arrange colleges you have selected based on priority of getting seat

<!-- page 30 -->

Student Login Page

<!-- page 31 -->

STUDENT REGISTRATION PORTAL

<!-- page 32 -->

EXPLORING LIST OF COLLEGES BASED ON FILTERS

<!-- page 33 -->

College Selection Display in Portal Upon Clicking

<!-- page 34 -->

ARRANGING COLLEGES BASED ON PRIORITY

<!-- page 35 -->

SSS J&K AND LADAKH
CONFIRMATION OF ALLOTTED
SEAT BY THE STUDENT

<!-- page 36 -->

SEAT ALLOTMENT
• The choices submitted by the candidates will be processed centrally and seats will be allotted in the order of
merit, scheme guidelines and on the basis of the locked choices, also keeping in view reservation policy.
• After the allotment , the candidate has to give confirmation on the allotted seat using 2 buttons :

<!-- page 37 -->

RULES FOR SEAT ALLOCATION TO
CANDIDATE


The choices submitted by the candidates will be processed centrally and seats will be allotted in the
order of merit, scheme guidelines and on the basis of the locked choices, also keeping in view reservation
policy.



Once the candidate has confirmed her/his seat by using freeze option with respect to allotted course and
college, Welcome Letter will be received by her/him from the college itself.



Choices filled by candidate would be locked automatically after respective period is over. Prior every
round of counseling, choice filling option will be opened based on the vacant seats where candidate can
fill their preferences i.e each candidate has to fill fresh choices for next round of counselling.



Candidates who have not opted any of the choice for confirming (freeze)/surrendering (float)/ not
interested in PMSSS their seat will be cancelled automatically and the same will be offered to the next
candidate as per merit and vacancy.



If the candidate has opted for the float option with a specific course and college in any round, then
she/he will not get the same combination (course & college) during subsequent rounds of counseling.

<!-- page 38 -->

GENERAL INSTRUCTIONS TO
CANDIDATE


Candidate should positively ensure uploading of joining report on the portal of AICTE on or before the last
date of joining, which will be verified by the Institute, after which DBT application will be opened by the
eligible candidates.



Candidate who will not upload their joining report on the portal of AICTE on or before the last date of joining, their
seats under the scheme will be cancelled automatically and will be allotted to the students in the next/subsequent
rounds of counselling (if any).



Candidates are required to report for admission at allotted University / Institution on the date specified as per
the counselling schedule along with the original documents / testimonials / certificates required at the time of
admission.



Nodal Officer may guide the candidate during her/his stay in the college campus.



Candidates are advised to visit AICTE website (www.aicte-india.org-> https://www.aicte-india.org/bureaus/jk>https://www.aicte- india.org/bureaus/jk/2025-2026 ) for all PMSSS updates.



NO fresh registrations shall be allowed in next/subsequent rounds of counselling.



Candidates must bring the ORIGINAL and one set of SELF-ATTESTED photocopies of the documents at the time
of reporting for final admission in allotted University / Institute



The candidates are advised to refer the fees structure and other details of Institute before freezing of seat.

<!-- page 39 -->

DETAILS OF THE SCHEME / IMPORTANT
LINKS
IMPORTANT LINKS
Institutions not having username
and password for PMSSS should fill
online form linked at

https://www.aicte-jk-scholarship- gov.in/institutes/login.php

Details of the Scheme

https://www.aicte-india.org/bureaus/jk

Grievance Portal

https://www.aicte-jk-scholarship-gov.in/

For any other registration and
technical related query

jkadmission2025@aicte-india.org

Helpline Number for Grievances

011-29581051 , 011-29581007/43/10 (Timings 09:30hrs to
17:30 hrs
Monday -Friday)
