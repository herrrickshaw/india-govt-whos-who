---
doc_id: "f5e177bfb571bcce"
source_url: "https://mines.gov.in/admin/download/6a6dc2117aed91785578001.pdf"
ministry: "Mines (MoM)"
title: "The Atomic Minerals Concession (Amendment) Rules, 2026 (1.35 MB)"
date: ""
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "9bfa55b27dfa7147"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-30072026-274991
xxxGIDHxxx
CG-DL-E-30072026-274991
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 623]

नई दिल्ली, बृहस्ट्पजतिार, िुलाई 30, 2026/श्रािण 8, 1948
NEW DELHI, THURSDAY, JULY 30, 2026/SHRAVAN 8, 1948

No. 623]

खान मंत्रालय
अजधसूचना
नई दिल्ली, 30 िुलाई, 2026
सा.का.जन. 685(अ).— कें द्रीय सरकार, खान और खजनि (जिकास और जिजनयमन) अजधजनयम, 1957 (1957
का 67) की धारा 11ख द्वारा प्रित्त िजियों का प्रयोग करते हुए, परमाणु खजनि ररयायत जनयम, 2016 का और संिोधन
करने के जलए जनम्नजलजखत जनयम बनाती है, अर्ाात:् —
1. संजिप्त नाम और प्रारं भ. - (1) इन जनयमों का संजिप्त नाम परमाणु खजनि ररयायत (संिोधन) जनयम, 2026 है।
(2) ये जनयम 1 अगस्ट्त, 2026 को प्रिृत्त होंगे।
2. परमाणु खजनि ररयायत जनयम, 2016 में, जनयम 37 के स्ट्र्ान पर, जनम्नजलजखत जनयम रखा िाएगा, अर्ाात:् -

5865 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

“37. िाजस्ट्त. - िो कोई भी इन जनयमों के उपबंधों का उल्लंघन करे गा, िह धारा 25क और धारा 25ख और उसके
अधीन बनाए गए जनयमों (अर्ाात; खान और खजनि िाजस्ट्त का न्यायजनणायन जनयम, 2026) के उपबंधों के
अनुसार िाजस्ट्त के जलए उत्तरिायी होगा।”
[फा. सं. एम.VI.-16/51/2026-खान VI (भाग-3)]
कु लिीर ससह यािि, संयुि सजचि
रिप्पण.— मूल जनयम भारत के रािपत्र, असाधारण, भाग 2, खंड 3, उपखंड (i) में अजधसूचना संख्या सा.का.जन. 677(अ),
तारीख 11 िुलाई, 2016 द्वारा प्रकाजित दकए गए और िो तत्पश्चात जनम्नानुसार संिोजधत दकए गए र्े,
अर्ाात:् 1.

सा.का.जन. 126(अ), तारीख 19 फरिरी, 2019;

2.

सा.का.जन. 134(अ), तारीख 20 फरिरी, 2019;

3.

सा.का.जन. 693(अ), तारीख 5 निंबर, 2020;

4.

सा.का.जन. 682(अ), तारीख 22 जसतंबर, 2023; और

5.

सा.का.जन. 106(अ), तारीख 14 फरिरी, 2024।

MINISTRY OF MINES
NOTIFICATION
New Delhi, the 30th July, 2026
G.S.R. 685(E).— In exercise of the powers conferred by section 11B of the Mines and Minerals
(Development and Regulation) Act, 1957 (67 of 1957), the Central Government hereby makes the following rules
further to amend the Atomic Minerals Concession Rules, 2016, namely: —
1. Short title and commencement: — (1) These rules may be called the Atomic Minerals Concession (Amendment)
Rules, 2026.
(2) They shall come into force on the 1st day of August, 2026.
2.

In the Atomic Minerals Concession Rules, 2016, for rule 37, the following rule shall be substituted, namely: —
“37. Penalty. – Whoever contravenes the provisions of these rules shall be liable to penalty in accordance
with the provisions of section 25A and 25B and the rules made thereunder (i.e., the Mines and Minerals
Adjudication of Penalties Rules, 2026).”.

[F. No. M.VI -16/51/2026-Mines VI (Part 3)]
KULVEER SINGH YADAV, Jt. Secy.

Note: – The principal rules were published in the Gazette of India, Extraordinary, Part II, Section
3, Sub-section (i), vide notification number G.S.R. 677 (E) dated the 11th July, 2016 and
were subsequently amended as follows: –
1. G.S.R. 126 (E), dated the 19th February,2019;
2. G.S.R. 134 (E), dated the 20th February, 2019;

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

3. G.S.R. 693 (E), dated the 5th November, 2020;
4. G.S.R. 682 (E), dated the 22nd September, 2023; and
5. G.S.R. 106 (E), dated the 14th February, 2024.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2026.07.30 23:55:22 +05'30'
