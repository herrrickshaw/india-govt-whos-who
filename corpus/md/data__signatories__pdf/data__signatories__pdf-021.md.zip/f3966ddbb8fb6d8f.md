---
doc_id: "f3966ddbb8fb6d8f"
source_url: "https://doj.gov.in/static/uploads/2025/09/5f5af0898b5489d66610e4fbd323d3fc.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Sh. Justice Sandeep Mehta, CJ of Gauhati HC as a Judge of Supreme Court (09.11.2023)"
date: "2023-11-09"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a4fe71373f74ae9a"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K-13011/04/2023-USJ (iii)
Government of India
Ministry of Law and Justice
Department of Justice
(Appointments Division)

Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011, dated 09th November, 2023.

NOTIFICATION
In exercise of the powers conferred by clause (2) of Article 124 of the
Constitution of India, the President is pleased to appoint Shri Justice Sandeep Mehta,
Chief Justice of the Gauhati High Court, to be a Judge of the Supreme Court of India
with effect from the date he assumes charge of his office.

(01/411;
(Rajinder Kashyap)
Special Secretary to the Government of India
Tel: 2338 3037

To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

2

No. K-13011/04/2023-US.I(iii)

Dated: 09.11.2023.

Copy to: 1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21

Shri Justice Sandeep Mehta, Chief Justice of the Gauhati High Court through
the Registrar General, Gauhati High Court, Guwahati.
The Secretary to Governor, Assam, Dispur.
The Secretary to Governor, Arunachal Pradesh, Itanagar.
The Secretary to Governor, Mizoram, Aizawal.
The Secretary to Governor, Nagaland, Kohima.
The Secretary to Chief Minister, Assam, Dispur.
The Secretary to Chief Minister, Arunachal Pradesh, Itanagar.
The Secretary to Chief Minister, Mizoram, Aizawal.
The Secretary to Chief Minister, Nagaland, Kohima.
The Secretary to the Chief Justice, Gauhati High Court, Guwahati.
The Chief Secretary, Government of Assam, Dispur.
The Chief Secretary, Government of Arunachal Pradesh, Itanagar.
The Chief Secretary to Government, Mizoram, Aizwal
The Chief Secretary to Government, Nagaland, Kohima.
The Registrar General, Gauhati High Court, Guwahati.
The Accountant General, Assam, Dispur.
The President' s Secretariat, (CA.II Section), Rashtrapati Bhavan, New Delhi.
PS to Principal Secretary to the Prime Minister, PM's Office, South Block,
New Delhi.
Registrar (Conf.), 0/0 Chief Justice of India, 7, Krishna Menon Marg, New
Delhi.
PS to MoS (L&J) (TIC) / PPS to Secretary (J).
Technical Director, NEC, Department of Justice, with a request to upload on
the website of the Department (www.doi.2ov.in).

09
V 2-3
(Prem (hand)
Under Secretary to the Government of India
Tele: 2338 2978
