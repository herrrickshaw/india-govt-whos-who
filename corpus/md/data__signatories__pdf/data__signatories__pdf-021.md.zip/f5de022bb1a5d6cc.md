---
doc_id: "f5de022bb1a5d6cc"
source_url: "https://doj.gov.in/static/uploads/2025/12/c0f576895ce514ab8d9dc46b80527d3b.pdf"
ministry: "Department of Justice (DoJ)"
title: "National Law University, Gandhinagar"
date: "2021-11-22"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c60183a5f408df85"
---

<!-- page 1 -->

File No. N-9/25/2018-NM
Government of India
Ministry of Law and Justice
(Department of Justice)
Jaisalmer House,
26-Mansingh Road, New Delhi-110011
Dated: 18" December, 2018
SANCTION ORDER
Sanction of the Competent Authority is hereby accorded to the payment of Rs. 3,98,000/- only (Rupees Three
Lakhs Ninety Eight Thousand Only) to National Judicial Academy Bhopal towards First Installment (being 20%) out
of the total project cost of Rs. 19,90,000/-( Rupees Nineteen Lakhs Ninety Thousand Only ) (non-recurring
expenditure) for undertaking research project titled “An analysis of Pendency of cases in Family Courts of Madhya
Pradesh and methods to Reduce Pendency” submitted by National Judicial Academy Bhopal vide letter no.
NJA/Dir./PSC/2018/2696 dated 18.06.2018 under the Scheme of Action Research and Studies on Judicial Reforms
and as per the agreement signed by National Judicial Academy Bhopal with Department of Justice on 18" December,
2018.The implementing agency is requested to adhere to the timeline mentioned in the approved proposal and
agreement dated 18.12.2018
2. The expenditure involved is debitable to Demand No. 61 during 2018-19 (Plan) under MH 2014-Administration of
. justice, 17-National Mission for Justice Delivery and Legal Reforms; 17.02-Action Research and Studies on Judicial
Reforms, 17.02.28-Professional Services.
3. This has been entered in the Register of Grants/Expenditure at SI. No. 1 at page No 147-148.
4. This issues with the concurrence of AS & FA [Law] vide their Note No. 17 dated 27.11.2018 and approval of
Secretary (Justice) vide Note No. 19 dated 27.11.2018 in eOffice/Computer File No. 4318
( ae Khan)
Under Secretary to the Government of India
Telefax: 23072139
To. a
Pay & Accounts Officer,
Ministry of Law & Justice, Department of Legal Affairs,
Janpath Bhawan, Janpath,
New Delhi
Copy to:-
1. Cash Section, Department of Justice with one spare copy and a copy of Agreement. It is requested
4 that the payment may be made through e-payment to National Judicial Academy Bhopal .
Ei 2. Under Secretary (Admin-II), Department of Justice, Jaisalmer House, New Delhi.
F | onic IFD/Budget Division, Ministry of Law and Justice. Legislative Department, Shastri Bhawan, New Delhi.
| IC, Jaisalmer House, New Delhi for uploading on the Department of Justice website.
5. National Judicial Academy Bhopal, (Kind FeO eae (Shri) G. Raghuram, Director) Bhadbhada Road, Suraj
Nagar, P. O. Bhopal-462044, Madhya Pradesh with a signed copy of agreement dated 18.12.2018
6. Section Officer, Admn.Unit, Department of Justice, Jaisalmer House, New Delhi
7. Principal Accounts Office, 4" Floor, Ministry of Law and Justice, Lok Nayak Bhawan, Khan Market,
New Delhi
8. Guard File
9. Spare Copies-5.
:
b
है
