---
doc_id: "f17fd5c8ce7b4fc8"
source_url: "https://mnre.gov.in/static/uploads/2026/10/622496b04df444a8427a122fd77d3f05.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Advisory – Submission of requests for time-extension for commissioning beyond 01.06.2026 through DCR Portal"
date: "2026-06-01"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d0d18197809e59a5"
---

<!-- page 1 -->

ADVISORY

Subject: Submission of requests for time-extension for commissioning beyond 01.06.2026
through DCR Portal

All Renewable Power Developers are hereby informed that, pursuant to MNRE’s Office
Memorandum No. 283/63/2025-GRID SOLAR dated 25.05.2026 regarding compliance to
ALMM List-II and protection of investments already made, requests seeking consideration for
time-extension for commissioning beyond 01.06.2026, in line with provisions of aforesaid
O.M. dated 25.05.2026, shall be submitted only through the dedicated DCR Portal along
with all requisite supporting documents and evidence as prescribed by MNRE.
Developers falling under the eligible categories specified in the aforesaid Office Memorandum
are advised to submit their claims on or before the timelines stipulated by MNRE.
The DCR Portal can be accessed at:
https://solardcrportal.nise.res.in/
No physical applications will be entertained. Developers are requested to ensure that all
information and documentary evidence uploaded on the portal are complete, accurate, and duly
authenticated.
This issues for information and necessary action by all concerned Renewable Power
Developers.
