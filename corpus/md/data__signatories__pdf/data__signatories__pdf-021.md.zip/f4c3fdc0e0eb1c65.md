---
doc_id: "f4c3fdc0e0eb1c65"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/02/ae5f0f812e64a6ec68616e6e61bccdce.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Re-iteration of provisions contained in the Notaries Act, 1952 and the Notaries Rules, 1956"
date: "2026-01-23"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d12f138d027eea77"
---

<!-- page 1 -->

No.: N-15011/320/2025-NC
Government of India
Ministry of Law & Justice
Department of Legal Affairs
Notary Cell
4th Floor, Janpath Bhawan,
New Delhi, 23 January, 2026
Notice
Subject: Re-iteration of provisions contained in the Notaries Act, 1952 and the Notaries
Rules, 1956 — regarding.

The profession of Notaries is regulated by the Notaries Act, 1952 and the
Notaries Rules, 1956. A Notary may do all or any of the functions by virtue of his office
as listed in Section 8 of the Notaries Act, 1952. The manner in which a Notary shall
transact his business is laid down in Rule 11 of the Notaries Rules, 1956. The
maximum amount of fees chargeable for Notarial Acts is prescribed in Rule 10 of the
Notaries Rules, 1956.

2: It is brought to the notice of all concerned that the provisions contained in the

Notaries Act, 1952 and the Notaries Rules, 1956, including the provisions indicated

above, are statutory provisions and need to be scrupulously followed. Any deviation

in this regard by a Notary may be construed as a professional misconduct and may
attract action against him/ her under Rule 13 of the Notaries Rules, 1956.

nn Ye

(Devanshu Kumar)

Under Secretary to the Govt. of India
