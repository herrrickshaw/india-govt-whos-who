---
doc_id: "f54edd1f2b9d2de1"
source_url: "https://dof.gov.in/static/uploads/2025/09/b634b5bc5b88d9f2a96d9f9697c916d8.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Guidelines for quarantine facilities for laboratory animals like mice,  rats,  rabbits  and  hamster  imported  for  conducting Research and Development purposes on 04-05-2018"
date: "2018-05-04"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7f6a3ad81f495afc"
---

<!-- page 1 -->

Guidelines for quarantine facilities for laboratory animals like
mice, rats, rabbits and hamster imported for conducting
Research and Development purposes.
The DADF is regulating import of live animals including the laboratory
animals like rats, mice, rabbits, hamsters, guneapigs used for Research and
Development (R&D) to prevent ingress of diseases. India has several R&D
organizations/institutions carrying out research work on these imported
laboratory animals.
2. These imported animals are housed in the animal house facility of the R&D
organizations for which the Committee for the Purpose of Control and
Supervision on Experiments on Animals (CPCSEA), Ministry of Environment,
Forest and Climate Change has framed guidelines dated 7th January,2010
vide June, 2005 and may be issued from time to time. These are
comprehensive guidelines which provide specifications for animal handling,
bio-security, breeding, feeding, quarantine, separation, stabilization and
disposal of the animals. Specific details of each areas of laboratory animal
facility have also been laid down in the guidelines namely “CPCSEA
Guidelines for Laboratory Animal Facility” published by CPCSEA and
available at https://www.aaalac.org/resources/SOP_CPCSEA.pdf
3. Department of Animal Husbandry, Dairying and Fisheries has issued
notification vide S.O. 1495(E) dated 10th June, 2014 under Section 3 of the
Livestock Importation Act.1898 laying down the procedure and their
quarantining as per health certificate condition for import of live animals
including lab animal viz. rats, mice, rabbits, guineapig used for R&D purposes.
Presently, the laboratory animals are not being quarantined at Animal
Quarantine and Certification Services (AQCS) stations. There is a risk of
ingress of potentially dangerous organisms even through Laboratory Animals
for different reasons such as wrong human handling, during transportation
and other contamination. Therefore, there is a need for ensuring their post
import supervision by officers of AQCSs during their quarantine at animal
house facilities of R&D organizations established as per CPCSEA guidelines.
4. Therefore, in order to have effective quarantining for imported laboratory
animals by the R&D organizations, these animals will be kept in the biosecured quarantine establishment of the R&D organizations in isolation before
entering into the actual laboratory facility where the quarantine officer shall
have the jurisdiction to supervise the quarantine process. In this regard, the
quarantine officer of DADF may inspect the premises of the R&D organization
for seeing quarantine facilities as per standard established, if required.
5. To ensure quarantine of the imported animals following guidelines are
further issued as a supplementary to CPCSEA guidelines:
a) On arrival, the Quarantine Officer shall initially identify the animals at the
airport and verify the health certificate. Thereafter, the animals will be shifted
to the facility of the R&D organization through secure container.

<!-- page 2 -->

b) Imported animals must remain in the quarantine premises of the R&D
centre for the stipulated period prescribed in the health certificate or for at
least 7 days. The animals can be used for R&D purpose only after successful
completion of the quarantine period.
c) During the quarantine, no transfer of animals or offspring (if any) from one
facility to another should be done.
d) The quarantine officer has right to collect random samples for testing to
rule out pathogens. However, if any animal under quarantine shows signs of
illness, unusual behaviour or in case of disease outbreak or mortality, the
quarantine officer may collect the samples for testing to establish the cause of
illness or death and further follow up actions, if necessary.
e) In case of mortality during the quarantine period, incidence should also be
reported to the Quarantine Officer and post mortem should be carried out
mandatorily by the veterinarian of the animal house facility and the post
mortem report should be made available to the quaranti ne officer, if required.
The disposal of dead animals and their waste should be done in isolation area
by adopting scientific procedures.
f) After successful completion of the quarantine for the stipulated period, the
quarantine officer will issue final quarantine certificate after examining the
clinical sheet and other findings, if any at quarantine period and thereafter
animals should be released for R&D purposes.
-x-
