---
doc_id: "f5a6d9d94de07daa"
source_url: "https://mohua.gov.in/static/uploads/2025/11/ed48b51d5a4fab4a1d5e5a95557a261f.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of Rs. 268.80 lakh to State Govt. of Nagaland as part amount of 1st installment of Central Assistance for 8 BLC (New Construction) & 7 BLC (Enhancement) projects under PMAY-U Mission - reg."
date: "2021-03-26"
pages: 7
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d43a1fb60169c8ab"
---

<!-- page 1 -->

https://pfms.nic.in/Sanction/TemplateA dvice.aspx?AdviceNum=955...
है 596
PAO(Sectt.)/HUA/Admin/Advice/2020-21/2 462-63
GOVERNMENT OF INDIA
PAO(Sectt.), Ministry of Housing and Urban Affairs
507-C Wing, Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664
To,
The General Manager,
Reserve Bank of India, CodeNo: [707
Central Accounts Section, Advice No:
Additional Office Building, Advice Date:
East High Court Road,
NAGPUR - 440 001
Sir,
Please debit our account with Rs.2,68,80,000/- (Two Crore Sixty Eight Lakh Eighty
Thousand Only.) by contra credit to the following accounts of the Governments with the amounts
mentioned against each:
Month and Year of Accounts: March,2021 The Amount to be Settled: March,2021
Name of the | State Scheme Code Amount | Sanction No. and Date
State Code a
1 NAGALAND 1989-STATE AND UT 2,68,80,000 | N-11012/51/2019-HFA-V-UD
GRANTS UNDER PMAY (Comp. No. 9067554) dated
(URBAN) 26/03/2021
Signature of the authorized official
—_ (Pawan Kumar pe 7
Sr. Accounts Officer
Eo /o the Accountant General, Nagaland, Kohima - 797001
Sh. B.K. Mandal, US (HFA-V) , M/o Housing and Urban Affairs, New Delhi-110011,
Pawan Kumar Bhatnagar
Sr. Accounts Officer
2) ७-८ -proagy
on (s NO y)
(2 N1é- HFA
so पर
5 4 a
of 1 26-03-2021 17:08

<!-- page 2 -->

हु No. N-11012/51/2019-HFA-V-UD (Comp. No. 9067554)
: Government of India :
: Ministry of Housing & Urban Affairs
-HFA-V Section
हि * + eee
Room No. 03, Technical Cell, Gate No. 7,
: Nirman Bhawan, New Delhi
है Lane a : Dated: 24.03.2021
To
- Pay and Accounts Officer (Sectt.),
. Ministry of Housing and Urban Affairs,
Nirman Bhawan,
New Delhi -11 a
Sub: Release-of Rs. 268.80 lakh to State Govt. of Nagaland as part amount of
5 1 installment: of Central Assistance for 8 BLC (New Construction) & 7 BLC
(Enhancement) projects under PMAY-U Mission — reg.
Sir,
». Lam directed to convey the Sanction of the Competent Authority to the release of Rs.
: i :, 2,68,80,000/- (Rupees Two Crore Sixty Eight Lakh and Eighty Thousand only) to
State Govt. -of -Nagaland as. part amount of 1*installment of Central Assistance (ST
: Component) for 8 BLC (New Construction) & 7 BLC (Enhancement) projects for
Creation of Capital Assets under Pradhan Mantri Awas Yojana — Urban (PMAY-U) for FY 2020-
21.
2. The-statement showing details of the projects against which the above Central Assistance
‘ is released towards part amount of 1* installment of Central Assistance is at Annexure.
: 3: Based. on decision and recommendations of CSMC under PMAY-U Mission in its 44%
Meeting held on 28.06.2019, the amount of Central Assistance is being released subject to the
following conditions:
i. The funds shall be utilized for the purpose and within the selected categorized
beneficiaries, for which these are given. Otherwise these will have to be refunded along
with interest as per provisions under GFR 2017.

ii: The expenditure on the implementation of the scheme/projects will be shared between
the Central and the State/ULB/Implementing Agency (IA) as committed. The committed
State share should also be released within 15 days from the date of receipt of Central
Assistance in the SLNA account. In case of shortfall of State/ULB/IA share,
corresponding amount of Central Assistance will be deducted from the subsequent
instalment (s).

iii, | The funds including Central Assistance and State share will thereafter be released by the
State Government to the implementing agencies without any delay failing which the
amount would be recovered from the State Government with interest, as applicable, for
the period of default.

iv. Necessary sanctions/approvals/compliances required under the statutory or other
regulatory regime as applicable would be obtained by the authority (ies) concerned with
the project(s).

Contd..P.2/
ot

<!-- page 3 -->

-2- हू
vy. The State Government and implementing agency shall put in place a monitoring system
to ensure that the project(s) achieve scheduled milestone and envisaged outcomes
including implementation of reforms and other conditionalities required under the
scheme.

vi, . The State Government shall utilize the grant in accordance with the approved guidelines
for the implementation of PMAY-U Mission.

vii. The State Government shall furnish the Utilization certificates of the Grant released in
the prescribed format as per GFR 2017 as provided in the scheme guidelines.

viii.“ Where there is an element of cash transfer to individual beneficiaries, the same may be
made through PFMS/DBT mode as applicable. The State Goverament shail submit an
authenticated certificate from the bank showing complete details of disbursement of
funds to each beneficiary before release of 2"4installment.

ix. . The State Government shall ensure the geo-tagging of all houses approved under BLC
component of PMAY-U Mission and subsequent release by the State Government to
beneficiaries should be made in 3-4 installments depending on the progress/stage of
construction of house.

x. The State Government shall be required to certify that the specifications of the houses
conform to NBC/IS Standards and that requisite infrastructure will be provided by the
State Government/ULB. State Govt. shall also ensure that there should be no
duplication/change in the identified beneficiaries.

xi. The State Government shall submit the Action Taken Report (ATR) on the
observations/recommendations of Third Party Quality Monitoring Agency (TPQMA) for
quality monitoring purpose before release of subsequent instalment.

xii. The State should ensure that Model Code of Conduct is not violated while releasing funds
to Implementing Agencies/ULBs/Beneficiaries.

4. . The amount is debitable from the account of the Central Government in the books under

the following Head of Accounts under Demand No. 57 of the Ministry of Housing and Urban

Affairs for the year 2020-21:

[Major Head: | _ ३6० |] rants-in-aid to State Governments

\Sub-Major Head | ०6 | ‘entrally Sponsored Schemes

ntral Assistance/Share

Pradhan Mant was Yojana (Orban)

3 Assistance to State Governments for

Detailed Heed PMAY-U

[ si:01.35 [Grants for Creation of Capital Assets

5. The amount will be credited to the State Government’s Account at Reserve Bank of India,

CAS, Nagpur as per procedure laid down by Ministry of Finance, Department of Expenditure in

this regard.

6. This being the first instalment Central Assistance, no UC is required/due for above release.

7. As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee

Institution(s)/Organisation(s) shall be open to inspection by the sanctioning authority and

audit, both by the Comptroller and Auditor General of India under the provision of CAG (DPC)

me Act 1971 and internal audit by the Principal Accounts Office of the Ministry or Department,
whenever the Institution or Organisation is called upon to do so.
Contd..P.3/
yo

<!-- page 4 -->

5 oy
3 8. This issues with the concurrence of the Finance Division vide their Note No. 11-13 (E:
है 9106676) of even number dated 23.03.2021.
9. This sanction has been registered at S. No.$9in the Sanction Register of HFA Mission
Directorate of the Ministry of HUA for the year 2020-21.
: है Yours faithfully,
Under Secretary to the Government of India
a Tel No.: 011-23063285
Copy to:
1, ‘Secretary, Urban Development & Municipal Affairs, State Government of Nagaland
2. Accountant General (A&E), Nagaland
3. Dir. (FD), MoHUA
4. Dir. (HFA-3), MoHUA
5. DS (Budget), MoHUA
6. NITI Aayog, SP Divn./DR Divn., New Delhi
: 7. 0/0 CGA, Mahalekha Niyantrak Bhavan, New Delhi
8. Dy. Chief (MIS/DRMC), HFA Directorate to place this sanction at appropriate place on
the Website of the Ministry.
9. PMU (MIS), HFA Directorate
10, Sanction folder yet D
(B.K. dal)
Under Secretary to the Government of India

<!-- page 5 -->

1]
g = r Loa
na

: ae i S [ ie
| ee JEBBUBEE
i i 1 7
5 e. ae | :
¥ €

| ee |e
7.
| oe Ce
care
3 4 4 ४8181918 इक!
i ड़ z

| A 3 8) 3 a/R] 8) 378 cL
i = B/E] s
i : १111 Us हि
की TTF el elf

<!-- page 6 -->

HET ETEEEIALE
: oo ee रा
pe | पा
ace
{ae ry
[ae
a ४ A
हे 5. = :
s&s | +
g ५ 2
| ae 81111 115 8
3 & = sis 3 Ss 56 छठ Ss
ee
की वा
g ea |
eee
g ied
oe re
3 23° x
ee
का |
5 न es
‘a 5
ee ee
eo
‘el
: डे 5 31 61115 i

<!-- page 7 -->

ase on :
