---
doc_id: "f4afbd7d0a2d45ba"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/e25e05015d41e2d5f28d068a497a01c5.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of NOC for Sale /Rent of International SIM Card / Global Calling Cards of Foreign Operators in India - As on 31-03-2022"
date: "2022-05-11"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "716d5a4f1995f68a"
---

<!-- page 1 -->

List of NOC for Sale / Rent of International SIM Card / Global Calling Cards of Foreign
Operators in India. (As on 31.03.2022)

S.
No.
1.

2.

Name and Address of the Company

NOC valid
Upto
th
M/s GigSky India Private Limited, Aditya Plaza, N-33, 10 Main, Jeevan 29.08.2022
Bhima Nagar Main Road, LIC Colony, Sector-11, HAL-II Stage, Banglore560075
M/s Maisha Infotech Private Limited,802, Pearl Best Heights-1, 8th Floor, 10.11.2022
Netaji Subhash Place, Pitampura, New Delhi-110034

3.

M/s NextCellular Private Limited, India,
Kalawad Road, Rajkot-360005 (Gujrat)

“Manhar” 3B Shaktinagar, 01.03.2023

4.

M/s Uniconnect SIM Pvt. Ltd., 602-604, Midas Chambers, Plot No A-11, 05.07.2023
Opp. Laxmi Ind. Estate, OFF-Link Road, Andheri (West), Mumbai-400053

5.

M/s Matrix Cellular (International) Services Pvt. Ltd., 7, Khullar Farms, 21.07.2023
Mandi Road, Mehrauli, New Delhi-110030.

6.

M/s Stay Connect Cellular Services Pvt. Ltd., Flat No.33, Plot No. E-12, 22.08.2023
Imperial-II, Royal Garden Estate, Sector-61, Noida, U.P-201301.

7.

M/s Connect Global Namaste Private Limited, G - 32, Ground Floor, A 10.09.2023
Wing , Express Zone, Western Express Highway, Malad - East, Mumbai –
400097 (MH)

8.

M/s Falcon Business Resources Pvt. Ltd., D-1588, Okhla Industrial Area, 19.09.2023
Phase-I, New Delhi-110020.

9.

M/s Tata Communications Ltd, Videsh Sanchar Bhawan, Mahatma Gandhi 26.09.2023
Road, Fort Mumbai-400001

10.

M/s 360 Degree SIMs Private Limited, Dilquish Manzil, Maddarsa Lane, 21.11.2023
Thiruvananthapuram-695010

11.

M/s Globus Roaming Services Pvt. Ltd., 582/2, First Floor, Lado Sarai, 01.12.2023
Near the Crescent at the Qutab, New Delhi-110030.

12.

M/s Earthroam Communications Pvt. Ltd. 65-A, Third Floor, Ompro 27.02.2024
Tower, Kalu Sarai, New Delhi-110016

<!-- page 2 -->

S.
No.
13.

Name and Address of the Company

NOC valid
Upto
M/s Wireless Communication Services India Private Limited, B 7/1,Second 15.04.2024
Floor, Safdarjung Enclave Extension,Delhi-110029,India.

14.

M/s Roam1 Telecom Limited, S-101, Panchsheel Park New Delhi-110 017 22.04.2024

15.

M/s Techants Private Limited, D-5-Flat-502, Purva Windermere, 04.07.2024
Thiruvalluvar Salai, Pallikaranai, Chennai-600100 (Tamilnadu)

16.

M/s Sunlibra Enterprises Private Limited, House No.108, Sadhu 09.10.2024
VasvaniKunj, Ward No.6/B, Adipur, Gandhidham, Kachchh, Gujrat370205

17.

M/s Warm Connect Solutions Pvt Limited, 3508, Ambrosia Dosti 04.11.2024
Acres,S.M.D. Road, Near Antop Hill,Wadala (East), Mumbai-400037
(Maharshtra)

18.

M/s Inext Connect Private Ltd., 301 Vastubh Apartment, Dattapada Cross 05.11.2024
Road No.1, Boriwali (E) Mumbai-400066.

19.

M/s Prune Digital Consumer Solutions Private Limited, C-146, DLF 08.03.2025
Capital Greens,New Delhi-110015

20.

M/s TSIM Communications Services Private Limited,Balaji Darshan, 10.03.2025
TilakRoad, Santacruz (West), Mumbai-400054 (Maharashtra)

The NOC shall be issued initially for a period of three year and shall be renewed on the request
of the Company for a further period of three year at a time.
