---
doc_id: "f13c9a2a01bbeea2"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_69eefba5146e73.24540849.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Third Amendment Rules, 2024"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "fdf95071fff2fab9"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-12112024-258591
xxxGIDHxxx
CG-DL-E-12112024-258591
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 640]
No. 640]

नई दिल्ली, मंगलवार, नवम्बर 12, 2024/कार्ताक 21, 1946
NEW DELHI, TUESDAY, NOVEMBER 12, 2024/KARTIKA 21, 1946

पर्ाावरण, वन और िलवार्ु पररवतान मंत्रालर्
अजधसूचना
नई दिल्ली, 12 नवम्बर, 2024
सा.का.जन. 699(अ).—िन जवश्वास (उपबंधों का संिोधन) अजधजनर्म, 2023 (2023 का 18), अन्र् बातों के
साथ-साथ पर्ाावरण (संरक्षण) अजधजनर्म, 1986 (1986 का 29) के अधीन अपराधों को आपराजधक श्रेणी से मुक्त करने
के जलए उक्त अजधजनर्म का संिोधन करता है;
और कें द्रीर् सरकार का मत है दक ई-अपजिष्ट(प्रबंधन) जनर्म, 2022 का संिोधन करना लोकजहत में आवश्र्क
और समीचीन है;
और पर्ाावरण (संरक्षण) जनर्म,1986 के जनर्म 5 का उप-जनर्म (4) र्ह उपबंध करता है दक िब भी कें द्रीर्
सरकार को र्ह प्रतीत होता है दक ऐसा करना लोकजहत में है, तो वह पर्ाावरण (संरक्षण) जनर्म, 1986 के जनर्म 5 के
उप-जनर्म (3) के खंड (क) के नोरटस की अपेक्षा से अजभमुजि िी िा सकती है;
और कें द्रीर् सरकार का मत है दक ई-अपजिष्ट (प्रबंधन) जनर्म, 2022 का संिोधन करने के जलए पर्ाावरण
(संरक्षण) जनर्म, 1986 के जनर्म 5 के उप-जनर्म (3) के खंड (क) के अधीन नोरटस की अपेक्षा से अजभमुजि िेना
लोकजहत में है;
अत: अब, कें द्रीर् सरकार पर्ाावरण (संरक्षण) जनर्म, 1986 के जनर्म 5 के उप-जनर्म (4) के साथ परित पर्ाावरण
(संरक्षण) अजधजनर्म, 1986 (1986 का 29) की धारा 6, धारा 8 और धारा 25 के अधीन प्रित्त िजिर्ों का प्रर्ोग
करते हुए, ई-अपजिष्ट(प्रबंधन) जनर्म, 2022 का और आगे संिोधन करने के जलए जनम्नजलजखत जनर्म बनाती है,
अथाात: 7278 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

1. (1) इन जनर्मों का संजक्षपत नाम ई-अपजिषट (प्रबंधन) िूसरा संिोधन जनर्म, 2024 है।
(2)
2.

र्े रािपत्र में उनके प्रकािन की तारीख को प्रवृतत होंगे।
ई-अपजिष्ट (प्रबंधन) जनर्म, 2022 के जनर्म 23 के स्ट्थान पर जनम्नजलजखत जनर्म रखा दकर्ा िाएगा, अथाात: ‘‘23. उल्लंघन हेतु कारावाई –कोई भी व्र्जि िो इन जनर्मों के उपबंधों का पालन करने में असफल रहता है र्ा
इनका उल्लंघन करता है, इस अजधजनर्म की धारा 15 के उपबंधों के अनुसार िाजस्ट्त के जलए िार्ी होगा।”
[फा. सं. 12/136/2021-एचएसएमडी]
वेि प्रकाि जमश्रा, संर्क्
ु त सजचव

रटप्पण –मूल जनर्म भारत के रािपत्र, असाधारण, भाग II, खंड 3, उप-खंड (i) में सा.का.जन. 801(अ),
तारीख 02 नवंबर, 2022 द्वारा प्रकाजित दकए गए थे और तत्पश्चात सा.का.जन. 61(अ),
तारीख 30 िनवरी, 2023; सा.का.जन. 534(अ), तारीख 24 िुलाई, 2023 और सा.का.जन. 164(अ),
तारीख 8 माचा, 2024 द्वारा इनमें संिोधन दकए थे।
MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 12th November, 2024
G.S.R.699(E).—WHEREAS the Jan Vishwas (Amendment of Provisions) Act, 2023 (18 of 2023) inter alia
amends the Environment (Protection) Act, 1986 (29 of 1986) for decriminalising the offences under the said Act;
AND WHEREAS the Central Government is of the opinion that it is necessary and expedient in the public
interest to amend the E-Waste (Management) Rules, 2022;
AND WHEREAS sub-rule (4) of the rule 5 of the Environment (Protection) Rules, 1986 provides that
whenever it appears to the Central Government that it is in the public interest to do so, it may dispense with the
requirement of notice under clause (a) of sub-rule (3) of rule 5 of the Environment (Protection) Rules, 1986;
AND WHEREAS the Central Government is of the opinion that it is in the public interest to dispense with
the requirement of notice under clause (a) of the sub-rule (3) of rule 5 of the Environment (Protection) Rules, 1986 for
amending the E-Waste (Management) Rules, 2022;
NOW, THEREFORE, in exercise of the powers conferred by sections 6, 8 and 25 of the Environment
(Protection) Act, 1986 (29 of 1986) read with sub-rule (4) of rule 5 of the Environment (Protection) Rules, 1986, the
Central Government hereby makes the following rules further to amend the E-Waste (Management) Rules, 2022,
namely: 1.

(1) These rules may be called the E-Waste (Management) Second Amendment Rules, 2024.
(2) They shall come into force on the date of their publication in the Official Gazette.

2.

In the E-Waste (Management) Rules, 2022, for rule 23 the following rule shall be substituted, namely: ‘‘23. Action for contravention. - Any person who fails to comply or contravenes the provisions of these
rules shall be liable to a penalty in accordance with the provisions of section 15 of the Act.”.
[F. No. 12/136/2021-HSMD]
VED PRAKASH MISHRA, Jt. Secy.

Note. -The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i),
vide number G.S.R. 801(E), dated the 2 nd November, 2022, and subsequently amended vide numbers
G.S.R. 61 (E), dated the 30th January, 2023; G.S.R. 534 (E), dated the 24th July, 2023 and G.S.R. 164(E).,
dated the 8th March, 2024.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
