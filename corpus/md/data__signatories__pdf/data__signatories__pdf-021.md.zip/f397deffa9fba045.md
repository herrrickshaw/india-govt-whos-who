---
doc_id: "f397deffa9fba045"
source_url: "https://consumeraffairs.gov.in/public/upload/files/2026.02.13%20PCR%201st%20COO%20Filter%20on%20e-commerce%20websites_1771231030.pdf"
ministry: "Department of Consumer Affairs (DoCA)"
title: "Download The Legal Metrology (Packaged Commodities) (Amendment) Rules, 2026 dated 13.02.2026"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "54c0c25153759abe"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-13022026-270123
xxxGIDHxxx
CG-DL-E-13022026-270123
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 122]
No. 122]

िई दिल्ली, िुक्रर्ार, फरर्री 13, 2026/माघ 24, 1947
NEW DELHI, FRIDAY, FEBRUARY 13, 2026/MAGHA 24, 1947

उपभोक्ता मामले, खाद्य और सार्विजिक जर्तरण मंत्रालय
(उपभोक्ता मामले जर्भाग)
अजधसूचिा
िई दिल्ली, 13 फरर्री, 2026
सा.का.जि. 128(अ).— के न्द्रीय सरकार, जर्जधक मापजर्ज्ञाि अजधजियम, 2009 (2010 का 1) की धारा 52 की
उपधारा (2) के खंड (ञ) और (थ) द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, जर्जधक मापजर्ज्ञाि (पैकि में रखी र्स्ट्तुएं) जियम,
2011 का और संिोधि करिे के जलए जिम्नजलजखत जियम बिाती है, अथावत् :1. संजिप्त िाम और प्रारं भ - (1) इि जियमों का संजिप्त िाम जर्जधक मापजर्ज्ञाि (पैकि में रखी र्स्ट्तुए)ं संिोधि जियम,
2026 है।
(2) ये तारीख 1 िुलाई 2026 को प्रर्ृत्त होंगे ।

1107 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

2. जर्जधक माप जर्ज्ञाि (पैकि में रखी र्स्ट्तुए)ं जियम, 2011 के जियम 6 के उप-जियम (10) के पश्चात, जिम्नजलजखत
उप-जियम अंत: स्ट्थाजपत दकया िाएगा, अथावत:् "(10क) आयाजतत उत्पािों का जर्क्रय करिे र्ाली प्रत्येक ई-कॉमसव इकाई ऐसे आयाजतत उत्पािों की उत्पाि सूजचयााँ, मूल िेि
को जिर्िवष्ट करिे र्ाले खोि योग्य और क्रमबद्ध दफल्टर में उपलब्ध कराएगी”

[फा. सं. I-9/5/2023- डब्ल्यू एंड एम]
अिुपम जमश्रा, अपर सजचर्

टटप्पण: मूल जियम, भारत के रािपत्र, असाधारण, भाग II, खंड 3, उपखंड (i) में

संख्या सा.का.जि. 202 (अ),

तारीख 7 माचव, 2011 द्वारा प्रकाजित दकए गए थे और अंजतम बार संख्या सा.का.जि. 881 (अ) तारीख 2 दिसंबर,
2025 द्वारा संिोजधत दकए गए थे।

MINISTRY OF CONSUMER AFFAIRS, FOOD AND PUBLIC DISTRIBUTION
(Department of Consumer Affairs)
NOTIFICATION
New Delhi, the 13th February, 2026
G.S.R. 128(E).— In exercise of the powers conferred by sub-section (1) read with clauses (j) and (q) of
sub-section (2) of section 52 of the Legal Metrology Act, 2009 (1 of 2010), the Central Government hereby makes the
following rules further to amend the Legal Metrology (Packaged Commodities) Rules, 2011, namely:1. Short title and commencement. – (1) These rules may be called the Legal Metrology (Packaged Commodities)
Amendment Rules, 2026.
(2) They shall come into force on the 1st day of July, 2026.
2. In the Legal Metrology (Packaged Commodities) Rules, 2011, in rule 6, after sub-rule (10), the following sub-rule
shall be inserted, namely:“(10A) Every e-commerce entity selling imported products shall provide the product listings of such imported products
in a searchable and sortable filter specifying the country of origin.”.
[F. No. I-9/5/2023-W&M]
ANUPAM MISHRA, Addl. Secy.
Note: The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i) vide
number G.S.R. 202 (E), dated the 7th March, 2011 and was last amended vide number G.S.R. 881(E),
dated 2nd December, 2025.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
SARVESH KUMAR
SRIVASTAVA
and Published by the Controller of Publications, Delhi-110054.

Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2026.02.13 23:05:57 +05'30'
