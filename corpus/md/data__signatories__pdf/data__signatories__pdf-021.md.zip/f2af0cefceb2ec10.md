---
doc_id: "f2af0cefceb2ec10"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/422c4d2147b9402f2d31a356f193c983.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment to the Cellular Mobile Telephone Service Licence Agreement issued in 2001 or thereafter for Roll-out Obligations (10.02.2009)"
date: "2009-02-10"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ab05f773b7de621c"
---

<!-- page 1 -->

Government of India
Ministry of Communications and IT
Department of Telecommunications

(AS-II Cell)

Sanchar Bhawan, 20, Ashok Road, New Delhi-110117
No.842-320/2005-VAS-II (Vol.II1}/26 Dated: 10" Feb, 2009
To

1. M/s. Bharti Airtel Limited (Service Areas — Gujarat, Haryana, Kerala,
Madhya Pradesh, Maharashtra, Tamil Nadu, UP (West), Mumbai
Metro.)

2 M/s. Idea Cellular Ltd. (Service Area — Delhi Metro.)

a M/s. Vodafone Essar South Ltd. (Service Areas — AP, Karnataka and
Chennai Metro.)

Subject: Amendment to the Cellular Mobile Telephone Service Licence Agreement
issued in 2001 or thereafter for Roll-out Obligations.

The issues regarding Roll-Out Obligations and imposition of Liquidated
damages in various service areas have been under consideration of the Licensor and
the undersigned is directed to convey that in exercise of the power vested in the
Licensor under clause 5.1 of Cellular Mobile Telephone Service (CMTS) Licence
Agreement and Clause 5.1 of Universal Access Service License Agreement, inter-alia,
reserving the right to modify at any time the terms and conditions of the LICENCE, in
public interest, security of the nation or proper conduct of the SERVICE, the Licensor
has prescribed the following criteria for Roll-out obligations and imposition of
Liquidated Damages , from the effective date of the license by amending clauses
8.1,36 and 37 of the CMTS License/8.1, 34 and 35 of UAS Licence:-

(i) _ Roll-out obligations shall apply for wireless network only and not for
wireline network.

(ii) | The Licensee shall ensure that metro service area of Delhi, Mumbai,
Kolkatta and Chennai are covered within one year of date of allocation
of start up spectrum.

(iii) In non-metro service areas, the licensee shall ensure that in first phase
of roll-out obligation at least 10% of DHQs where startup spectrum has
been allocated are covered within one year of such spectrum. The date
of migration or date of allocation of frequency whichever is later shall
be considered for computing a final date of roll-out obligation.

(iv) Further, in second phase of roll-out obligation, the licensee shall ensure
that at least 50% of DHQs, where start up spectrum has been allocated
are covered within three years of date of allocation of such spectrum in
non-metro service areas.

(v) | While computing the period of one year under sub-paras (ii) to (iv)
above the average delay in SACFA clearance shall be excluded.

Page 1/2 aL 8)0४५ _--
vere

<!-- page 2 -->

<~
|

(vi) | Coverage of a DHQ/town shall mean that at least 90% of the area
bounded by the Municipal limits shall get the required street level
coverage.

(vii) The date of application for SACFA or date of allocation of frequency,
whichever is later, shall be taken into account for the purpose of
calculating average delay in SACFA clearance.

(viii) The Licensee is permitted to cover any other town in the District in
lieu of the District Headquarters.

(ix) _ In-building coverage shall not to be considered for roll-out obligations
as mentioned in sub-paras (ii) to (iv) above and for imposition of
liquidated damages.

(x) For calculation of number of DHQs to be covered, the fraction which
comes to 0.5 or above shall be rounded off to the next whole number
and if the fraction is less than 0.5 it shall be ignored.

(xi) Date of registration by TEC/TERM is to be treated as date of meeting
the roll-out obligation in case of coverage criterion is met for roll-out
obligation on testing.

(xii) | PBG shall be encashed to the extent of the Liquidated Damages.

anova
(B.L. Panwar)
ADG(VAS-II)
Copy to:
iL. Secretary, TRAI, New Delhi
2: Wireless Advisor, WPC Wing, New Delhi
3. Sr.DDG(WPF), DoT, New Delhi
4, DDG(Security), DoT, New Delhi
के DDG(AS-I), DoT, New Delhi
6. DDG(LF), DoT, New Delhi
7. DDG(C&A), DoT for posting on the DoT website
Page 2/2
