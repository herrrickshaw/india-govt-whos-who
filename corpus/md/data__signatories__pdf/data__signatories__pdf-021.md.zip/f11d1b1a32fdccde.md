---
doc_id: "f11d1b1a32fdccde"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/1c16fe4a191f75a6de222b5e2cf0c47c.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "RTI - Departments of Health and Family Welfare - CHS VI - Dental post requirement rules, 2019"
date: "2019-06-12"
pages: 22
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d72546f2def29268"
---

<!-- page 1 -->

rF€ q" d. gf,o-:loo+lqg

RECD NO. D. L.--3-1004/99

ffi
ETIT
?rgfE a{tit

Ohe 6az ette of Swdio
3I{ITEIr{UI

I'XTRAOITDINAITY

qrq II-€!g 3-3q-utrg (i)
PART II-Section 3-Sub-section (i)
qrlcrfrR t [fir&rd
PUBLISHED tsY AUl'HORIl'Y
T$ m,

Tr. 367)
No.3671

gslt[R, 61 19, zotel'+E 29, 1g4i

NEW DELHI, WEDNESDAY, JUNE 19,

^OI,|JYAISTHA

29, I94I

rnsr +(qftqr( s-qpr {Trs{
(urs qkqft{r<sqrurfurO
sfuqa{r
q-{ R-"fr, 12

W, 2019

sr.t.fr. 430(q).-rryqfr +ifrerm + q-iEaE gog h q-{=Sd ar{r e-{fl rrRnt'i * a4p q-,G
gq *{ <o frB.sr q< qfi fr{q, tggz fr sc {rf,l + fr-4rq ?dfffii( rG gg, GG W ?df}sq,rT
+ q-{A fuql Tfl-t qr ryG w q}q fr:+r rm *, q-* .l{ !{fr fi q-afr anr frF-+qq s!-t + frq
ffi"rfur frTq ffirt {, ewfu t. {ftr;nq *r rrtq: (1) q-{ ffi

+r riffa-qrq rrqr€zq +{ cft-.qr{ 6c.zrrrr-riT;a{, rqrEzq

3rt{ q-fuqR s-€{rq- Rsrrq', {f, rr{ }rfr frTq, zot o

(2)

{

r

t rrqq-+ t sfi FFraFr fi ilft'q fr r6t frirr

qrsm, s+or crff+_iur 3iT Ei-fl
2. qq-fur, TrffTr-r dR +f,{ +ffm fr w<- sm q-s}
qr
it
ttrffi rm ta-+qm A drn .ft la
t e.rr{a 3r--ffi* h nisr 1zy t r.iw 1+y t Gfrffiu ir

Mf

fi

til{

[fi fr Taft, qRI.;ftqr, {ffi qrR- sm r( T{ '-r-fr fr caR-, qrg-frqr, q-fu, 3i-{ Bq-+
fti&-n q;q aft a ilft fr s.tl .T-iq+ h rctrr (s) t (r ay fr frfrffiu fir
3.

+.

ffim- T{qtu(s) Crsi q+

qfr fr fr-q-mr qR zn Crq-fi c-* fifrn t, fr-sr6 frqr t; qr fr-n-f, fi

Tifr<r fr t qr
2912 G1t20t9

<!-- page 2 -->

2

THE CAZETTE OF INDIA : EXTRAORDINARY

IPART II-Sr1c.3(i)]

(q)trr{ri stqi cfr qr Brrfr Tfr + frA-d-{-.at gq G.fr a+fr t fr4ra ftqr t, qr G"]E

fi+rAEr*t

s-s rl-( qT fr.{ft. E[r qTa c-S

+rn:

fi

fi

s. Rrftq t,G
lrfu- s-{t }*frq rGsR W {rq e ft; tqr mrfl 3il-{al=F qr qffirq t, +a
eE ts-q+ frq fr sr{q-t, 3-€ AE-q-d ryG, een Tiq +d. +{r qrfr{r rqrqcf +(t e-{
+
w"iq s] ftffi +.t qr ys.i + 4-RFq1fi or-+o, qrtq a-<r flslf*q qffir

ffi

t

ffi

fi

*

6. qr{R- qq fr-irq}
er;q
+t{ oro, tcr qnwuir, arg-fi'qr q.
er x+;4
frc-{T }-fi-q rr.drr drcr {fl dzier ii uru-{qzr ca qrrt ftq ,lI iltsrl + qrrn
3t-{qR-d qrffii, q-ffc-{ q-i-srmi, eFq fr-ai Ertr,
Td-$ €ffii air.r ei--q Er.}o-e-{Ti h
+ frq srqer n-cm ertflfo tr

qffi,

t

*.

ffi

ffi

qffii

qr{fr
Yfr+

ttiil[,IqFI

T{flq,<ul

riqr

a-fr{

q?FT T<

tEffi

fra rfiftSsr+ rr+ fre Ttr fts qri {r+ qfriil + ftq qSkd

{
Tqfi

*qr

dw<

a'qa1

qffi + ftS qrg- *ft-rdrrq-qq-fu

v<
(1)

qrtri{trr

(4)
q'im

(201 s)

a-ffq t{r,

+En

tfw'm'

(s61 00-

rrccfra-

'1

fuurt:frqfrt+r

-h.n q.t q<i +r "nr{rrrr

3rrj-{ ffift(

*;rapq*m;-

(3)

32.

t2t

t. r+rfc

i 3irerg

3r-{1vffiq

rIr

17500

-.) t
.dr-10

(i) iffiq qr+,rr qffirrqr
frqfl-25

(6)

(7)

n ,rf:-r.n ilfi

(+flq {-.rr. err

{g{-qrrq r. qfi E-rt

w rrg<til qr .j{rirri {

?,i-flrr q-ffffr iT4ii +

fir.{iq q.i a-{ fDrf,fq
fferr.r,fiir)

ft-,{r
q+,mtr

E4l[?N

(s)

qFIilfr

(ii) si. {rq rfrdr

forrq'

qT1-{Trr

rqrrrF-a a-{ + frI
M,Im {rfi-,e tTfr{ i1

frB{r-4
(iii) q5fl"irr

F.rs ffi{

(<-tr)

-{

Trf{

1948 (1948

TJ 16) m'+m I rrffi++ EFqTI ,rB Td ,r.;q
qr++ fi qfm; :n

(ii)fi ftft:,q.r-3rf}fi-Tq, 1948 (i948 {,r 16)

ft -fi{* a 'rr.r tt h "r#{ 1-1-1972 4i
qT-lifl crn eil r.l-,{r rrr fi il rr rr frE-;'n
arf}ft.zrq 1948 (1948 6r t6) ff rffi i.+nr
lll i rrtftr r'4q 4Til'+rrr..rT qzr 13-8-2009 {fr
.rrr{T 6 ilTf|i4; TT 111-4 ft',,n qrm
?,
q-rf-n+rqT qprolr+ etrr 3r{zr qTq"IT qrFI

'rim c-rs ff i; rr tFl€ ,{fr :n ,rrrr+ *r
i, frrfr -+Jrr l*m a "rt, li frqir
r,.tha,r6q-6ng {Irrftm
qFsftd-frrn; 3ii- Fr{d 13-8-2000
q c..rrff
,ftq ilrrr4 erfir (a ;rr*-frr q-,tzpr fiF+m, zoog i, r1ap,
=11oft e-s ?ifrq {frq t'r {nqtuprfiq-tinrfffia,

frquf: <a roiq +r
v-a gm uFrftr
+-ftfa sz +q-<ift
e-$-{

1i1 rrfrfi-,+a;erf}fr'{q,

3I'tri',ffi 'r 3rafi TrE

3f€r{rq-3

{ilo{r, if,

qr4rzFrF

qqr,ru,
:drIq,
srF{Iir.{ c?cr,
qtrr5r.,
ffi.q,

Tftrq tzm F-$-{,

qrg a arftr r6q 'i
rqrq ,42, eqrqq

ft;q'e, 4-d ft qr+:r ftI 3.TF,{fd q;.rrt di.r
a,.irft-€Fr ffii + ra{:{ffi xf}re1m'r;
{t'i.rc-{ q i T-r fltrr frr

?i?rm 'i{ir fr-drat-.

ft'qq, :rfu w;+,rr TcrPn -jrrrffri ff arn i
T{ 6rrwi { frn .rqa fr-,n nt nq -{E; naT
3nTtT h C"-{,r{qrr fc-rl'fi ff w qffi

ilrn-"1-i, El]rr, frF4q

(rFr5q{-fi) d-.

r<qr + r+rr.rr+ qt
-.lrFd Fr.? il,;r qr4rfta m cift rr,'i3

wrqqkr+tff,M

t qrrr4tfrTr qmr
+,

(iii) fr3Trftflt 1afr+rd ora-ff xflrelm) a rrr

ac q-, Cqr 3ru{'fi Fr'ri fiqni{r? -r,t fr rf,

fiq qr rte+frq +

r

;p-rffif h frtr trCd

ft.r€ irl

fr* Tff ftq qr+ qr+ cft+wrffffie,cfrfrtil

qffi t fts Rqc

qrg df{ dftr rtdrq
mrdqM ffc{Tri

rfi ft c-dR, c-ff ff*
q-aRfr rr<r rft w+ sr-fi

ffi m ffi era qr cRftdtr<r+ffi sp nq1 ftfos
ftffi fi cfr{rfrdr

cmdt.ft

8

qArfrztrrr

I

qqe{

10

frtrrrrff.

.r<qrt t Tftm16 rn i;fi ffi aT qe?rq"r Z8 ar A,+ :6a1 qftft"1ffii fr ra
gf qr rqn ;rFr+ qefi h ftu +ra- ra h q;nur zt ftfu,ai ffi,{ q,=5;1? rr -rrr

<!-- page 3 -->

IqFl Il-uu-s 3(i)]

elKf, tF-l {lEFl-t : 3I{ilqRUr
eiq,rai {r ri'{ lTF{ erii h afffi|ct q n
n qTqrr q{ .rft qr qinftr
(+) (i)qq i"-f qr B+rrr c
rfierr r. q1el r11 '.fi,-qr 6r € a; Tr

clam:
ffiil
(ii) q< {af rr firrrq q nd-{ tEtr ii r+r 8 ,n rr{,,r n ffiir sn--rrr .r. erft
ffi h q,+m ffi i fi 4,i q-4r ff a; d(q) Eiiq 7 + ?dpi-{ fl?ff raff t fu, BeT g}arftr+ rfa-rri :i-r :r5v+ rqa f,i1
({a<z anr ffiffi er,l f+{R-, + frq ql'.r.T,d-q qq-ffTr aFm 4S + ?fa"; ii}
i.fr
ffinrBffionm+rr

qR fr'qrft{ *nft ffifr t, * sf,S rirs-{r

Er(rrfiffc{rrti
nFr{i
ffi

rffrGtR;qcftR{Md

{s +{+{r qrftr+rfi&Rf
ft-qrqrgrnr

imRnrRftgfrrar+rr

ftcrwsfi
(1 1)

(13)

(121

ri-i.Iilff Zrdr

qT{ " trarFnq fFrfr {frR (gE+ {i'ieri Aqrr r,.{i, fr'r.y ffiiFa+ i fra r,.
atrft:-

-{r{ 4* 7T{TI

riTr.fl
- .,tl.l+el
h*qrr+lr r-+r+rqd-c-{r
- rr<E r
3.sc-{ft-s, p-<req*rqft{r.{,qq1u1ri?Frq -l6ar

qif q< rr:r + ftrT {iq iir6
+4r' qrfr{r fr r11gei 6rfl

1. riTm irR-4, r+rcur qtr qF qr. +-rqrrr

2. F'iqr+,

,l

2. 6ffs
EFF
rS-+ 1a-r)

2

4

3

JZ

qrrr.q

ZFFT

(201e)

idrc n-ql,

qTZZH

' 6r{",nl * qrfi{ qa qpq-fr{ frqr w qF
r+-m{r
ft-cor, (d r*;r

5

6

qTilq<

iTI{Iilff Er{T

7

oFI ilfr F)-dT

'+"

-rs.TB'd
3rf,{qFrfi7r

t r< gm uffia

3rr4{rrd el

(67700208700

r)i-<r-

Eft6d 32 + €i ft +iqr <-d q-s-{

11

ofts €rs rf{ ({d) (cq.r1m.$r.fr.)

qt ffi e-+{ t qrrqqkrm ff,m n

qrrrffft{rqmrir

I

8

qUi-fraTr

mu fttdrdr

10

ftffi { ftq ir!,4rr+ q; fr+r -+.*,r-ri ,i qrrrn .r- c'rtrfi e;1Tr

11

12

crqti:

sEe '+' fu+nfu

qfl {d't-S-{ffi ffi.rvtttg6

q-rrqqt q;r+r qmerm .rff

*r qF-+rr +-.qfqf riTrfl

3.iiTs-qF{q, r*rcuqrfircf{{r6"{rqq={r.rq -t({zr

2
I

ri'{ qt+, +4r 3{EriT t

- tlre;qzr
2 +-+re+qlmqarftiqrrrqisrrarRsrd(++fi) - rr<Er

1

3

4

32',

qlPr-rq'

(201e)

i*rt +ur,

e?Ft

1

3 raffiqfa
(a-{)

1. sTSr qFfi, r-+feq

13

I

q.frfr €r*ft -al,rm t *itrr t G-{r- {,+ + Rr)

G-qtffifu(tfrqwatft:-

i r+r g t ffi
qrr z{ft-qR-d i{r fiii;
(561 00-1 77500 a.)

ffi

. fitrr * qrcrn q. qtqft'{ ftqr w
q+-m*r

5
?ZFI qE

6
er.1

7

r.i zrrr

;ni.I{dt p.r{

qf.--.F
(78800209200

rrrrd'6'
rrqcBd-,

q-i-{qffi,r

r.) q Ed,
12

ftlqur: <t q+{ sT T( Sq qF{R-f, F{rf,e

32 + r<t ff Tircq-r, e-{ Ed-{, +ftg F.rs
E$-{ (ft) lrf+1wqe-fr) air a-a cd'q i
r<rqqkrdr ff ffi t clrrft ftqr qmr ir

I

qrXi-frildr

I

qr{i-fi+d-i

10

ftfui { fu irfi:1a h B;n r+r.,rri
h.{rar q-r ffierrTr

<!-- page 4 -->

THE GAZETTE oF INDIA : EXTRAORDINARY

4
11

Ip^Rr Il-sr)c. 3(i)]

't2

13

ffi, td-{tEfl $7,tOO- e-nq " fu{r{ftq sffi qfrft (R-pdri frqft } ;4?rl t fr-{zrG + frq fr.+n
208700 F.) i il{r mfrs EE
ffiftr*ft-.rrrqtrft:{d-{ (sd) Br}qq,miciq
1. 3rT. qfuE, r+rcq *r qfr{rt 6-"{rlr riTffiq
- qrAer
46ffid'i-{rff4,
2 Fdr€qu{r{drfr?qnmqqiqq7rftaer.+;(fi.ffr) - T-rzr
3. {gs{E-{,

,|

raF,:rfr1qft-ar a-,anqr FTr+I

2

+emqfr

32'*

(.{)

(2019)

3
qrqT{ur

- qrftrrr * qrem qt qFa-&r

qrr+m*r

4

E;qr

5

6
qTII

.lqtt

mlrfrz.rrr

Ei-fli

215900 r.)
q -+. ta

rt.qqft-{,

7

ilfi

( 1 231 00-

,

+z+r iapqr{fi ilfr }1

- q<Er

nd-{tB-H

?dq'
q6"

(r,+qrqq'fr1

,iq qrfi +{r qrir t qrrqrt

3r-ryrffir

ft"c"r' (d uda +r q< A,er vFrrfta
F4-fd 32 + q<t ft {@r dd s-f{,
+ftg Ers q-f-{ ({d) (qrr5.qs-fi)
3t{ Ed s-f{ q-rrqqkrm h,}fi

i

t

rrrfffr+rqr+rBr

I

8

qFIi-fr4-n

10

ffirii + ftn -:r1+rrt ?, fu{r F4E,{1T + tlrt-, .t,
ffiarrrr

drti-ff ?.i-dr

11

12

ffi: i-r-rtftw (78,800-209200 ..) + vp'+' furrrft+ ffi qfrfr (r4rqr+ ffi a iidsr n G-{rr E-,rd +
pa1
rffi nqr
12

rzrq Ff{ (<+) ftrq+

!i

,rryfrq qr' +i'Fprfr{ imr

ff Err

I

frq) frrtft,xftfurifu.{ mr airft:-

't3

{'{ .ir6 +a"r 3rgrrr +
'l'rqf +Tilr qrzrezrr ilfi

ir

t erqr qftq, rapq fir qftap +;q-frr ri=rrq-q - 7lAel
z. c+rcsa +{r q-{fit{rcq

t srr6rfr?cm (frffi) - €Eq

3. q-Sd qk{, qfrzq -ifr qi-+f.;rrzlTrr

2

1

5 ,i( ITf{

32'

+

(201 e)

3
{ITBITTq

+dqt+r

rmqgkrdr

TF.6'

' +r$qrr * 3n$rr T(
fr-qr irT

qffi{

.trq.TB_d,

4

+d-{{l}ffi

riTr;i-T

5
?am

- qzE{

6

7

il{a-fra,rtT

ir{ilfra"7

(144200-

218200 E.) c

qrr 14

3r-.r1qffiq

r+-mir
Eqor, s-d qfn {,T T<

ger qffia
32 * qii

*1rr
fi {ETr <n

s-f{, 6F-s FaFF
r*t 166y
(1rfl'grfr) +i ia'
q.$-c t q-{rqskrdr h
m i clrrff ftqr
q.fr+, rarr

erc-r tr

I

rtFIifrAf,T

I
glrl i-fr Er-dl

10

I

frffii h ftT 3i-{dtri'i; ft-+r q*qfi h qrrn q. *.rqAemr

<!-- page 5 -->

IqFr rr-uo-s 3(i)]

qRf, S-T {t$tDI : 3IffqRuT

5

(12)

(1 1)

(13)

i'qf+ - +d-{ nEfl (1231O0-2 j s900r.) t FcT qqd'5' Ar+Fftq qi;nft qfrft (ffi t
13 t tqr F.ffi F*{ (rt) (q+qqrS$l Grci
+i=icr t frqrt {,ri t Flqy ftrqi
mir 4{ ffid tqr fr A qr +dqrq-t r{6
Fqfttuottn-

qq iil+r i-{r rirrrrl { rqqqi r.rr.n+cT6 Tfr )

"+"qsif z0 af ffinterfifr:

t. qfrE, F{r. qft. z6pqrq riap.Ta-3axqg1

fuqq: ti

2. rrgrft?qr+ q-apz1 fu

em trf+ (,iir) fi ffi

29.10.2008 ei?rk

E1

ffFft Fff'q + 3Tclt{ 4fts6

csrmn-fr,hftn+ qrq-<i* r<rt6{i fi affi=q

qi'

ffir

t

irrata tr{ i-aq fu-s *rrq io-+
7600 tcg ar tr+qm srtr{ 6{ Q
{rdTfr

t

cT -3rqr

q5ift9;5sa;p2qfu -qEs+
3. r-apg{ +{ CtrflT +qTr,rr riTrqq ii

q;f{ qq<sfus -R€zr

riEsr 53 iltrq 03.02.199s anr afffi+r ll-ff

ffii + sq-ai,ii t rgrrr inRr eri Qir sqrt

Crqt+ *r5,fi rfiq rrftrq 29.10.2008 +
dIfi{ sm? {ir E-r"c;r It+r frr
2

1

6

${r{6

3

04- (Tr() 2019

3rrdrf

-a;r&nr t dilcrr{ q.'{ftrf-{

ftqr qT €.Fil

ir
ft-qaT:- i.S 6rE{ tt-+o +i+q, ;rt

4

STEIII'q'

+fr{

hfi-q t-qr,

+En

Irlfd'6"
qrrqcBi'

(67700-

5

+o af

+dT

(hft+ wzr-r anr qcr-qc{.r nrfi
frq .n1 t?qri qr qr<rn t or{rr.
F.+ri) Hr *,ft1 S af r+ firFra

208700

ffi + a-ryma t; i rar-

frl q-ff ilr ,r-c1+l qr;iftr B-qr or+r ir

t erflr.r. q-frr

fierr+ftir)

fu-rrrT 3flT-frqr rrrrtrF-a r,{4 + Fin

11

ft,rTiq-{ ilfiq rrnr q arTf.ffi }

r,rfi.n fird f;li * ftI G_T{ fi €
3ift'q afi".l dr{ftt ({ ft aa zif?-q

2. r{Pr{ 3THr{ 6T.r< 3a-vFtft-r rff-r,o
qr €i qrecr h fi-da tr6q5 qrar$, 16-

fi

ilrftl? n rrq, ir+r"rq, rrrrfqE y?tr,

qTqr{, qTqr-d 3Tt{ 3nflf (qftra xqn+ftq;
,dufr) 6

6

rrFI ilfr-

ft-+iq, qFqi, flTr+s, A-1lr, frEf,
qrq-;rpdi-r rr.q h q-{rrE rE, EqrfiT

ic t clrrff flqr qrilr *r

c?lr i.a6.6a rrtr rftfr fui T.,rr q*trT-

Gr+ +'rift :'ris, ftqra artr ft-q,i..rr
flq qr azrfrq h qrqFftn + F+r BEr

ft.tf*r)
7

mq{{d: (1) i( frft,H{; 3{f}fr{q i94B (1948nr 16) il

errqftr qr;qm xrqt <e sr"{ F{r+m ff 3a{Tr

8

'rFT

1n

I

eftfr{q, 1948 (1948 61 16) 3r-fl+ h .,rm lt h
3t?h4 1-1-72 {m qTqirr yrw <n :r&n fl.d fi
A qr m frfrim
:rleifrqq 1948 mr 16 fi irfl* h liFr ilt + 3rdt{ h,{m rril rrn(

zn <-d frB-ffim

nq 13.8.2009 azr trr.il 6 ilTtrr. air erg{.d B-qr smr *, q-r=+m
rn'a rrftrflnr qr rirrrF 6lTr !rt((T rr{tr Tr.< fi *, m e;r$ azrfu

i T* * ilrftT * frteft arfin r.*m d efla {t ffi n6T t.fu:
Frti 13.08.2009 i r-g.a-+<-fi-+ v-i.1aror + erlun ar+#+ rftawr h
qvn am{rt rfieruT Bfr+q 2009 h 3r1rrt Eir-fift{ TftqrT ff
q-fteflT.frrf ffdir
(2) TFzrilr fiw AqqBrrcq qr rirr{F fr cfl?r+1-dr Bfi;

(3) rrrr

t ft+ft rr"q d( cft,r< qr erBmor h s-RT {}l4fd +{r

,rqilfi zrnr

9

r+ at'

10

fi"fiq-ff:-

f+qor:- r<crdl fi

fff

sftfiTfti rr ?i*

zn q'",tln T? +r ft;fr :r;+

qft.Fsfirii q ,f+ a.t rn erri s{fq-6F qafd

i

Ffu

h ft q anr rai 6rrrrr d
| +frq
q1TT. qT -F,{ {ra1t qr rir+ rr"q aH h

ffi-F< crfffi n + xFrffi i
qTPI". qlrrtwqffir
(i) T.r .iat qr frrrrq n ffi{
3ilFJrr tr. {(lI

ftq*r

II{ '.Jrr ur

(ii) if,{ tBffi (56i00-172s00
r.) i Edr 10 q riq 4{
Fr+fua q+r fi zl
,r hrr
furrrr- TFrFEjt 71*11 m

arftgr

-.r|tr+ a,+r qr-{-trrqr 3n+fi

(a) qrr{dr qrrf, i{rqrr{ ftqr+ fr qtfko r+rr+t<-< qt'il h qsqrd
l*er+ qr ft-<sk qr r.ft-.-qr qr qFF, rqft+ q-reflqa * -q c Belqfr:

?,iftT ddlq 56 4f q ?dff+; {fr i,ftr

3 ef aa{q-a5r 31$6q1

E@f 1- 3i-fu, 3r;{rn t3{fr 3rrqffii fi <qn t e+ .nrl"ri } ftq
s] nt-q-d frq qqr riq +n t-{r qdr"q + Gnsr{sr fq-rfuq fi qr

Trfitr

rrq {,ri 'ft

<!-- page 6 -->

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II-SEC. 3(i)I

B{ur 2- 3r{:rE"{'ddt 3r--,dr (q-idn1) sr 6r.'fr + ft--1 ql AE"E fr;q
ilq ds -{ffi +{r 3n+iT h B+{-,risr 3rflfu{ qrfui 3{t q-fik{
s-.rcrftqih 3{rqffrifi Esn ii(q frtF.m ff qr rffi * qa qtt*

hff rmc qr +i'r fr+ t'{r 3{rfr{r fi qA -rq e ft; 3-i-fi ftr 3rrfeTd
Fft1t m
ftI ertB-r iry-< r,qi afi r+ r5<r+r *
'rG +
qr,+ffii* qqtw
+irc+r t sre"er fri fi rirrr++r a-fr ir
12

11

qr.Ia-Sftr

q-F' Errrnq nlFrft {ftft gB * {na i fr"rr +;,i + fr11 frm+ ffirfu-+ n
E-d+-{qilft:-

13

I

q< rrt h fii-rr *i'{ .ilfr
+Er' 3rr,i{ rt,r-rqqi +-rr
:454q5 |1

t. erq't qB{, Farrzq efu qfu{rr +-"qrq ri?rtr{

-?{sqer

2 sapzqfayq6tft|qrr+qiis.rrdrfrisr+(*+ff)

-rftq1

3. {3.ff qFfi, l-arrq aft1 qftar {"{rur

't1

riTrq-{

- .r(Fzr

12

qr{rfre}-rrr

13

q6 " fr'+rfnr ffi

.r< rri

qftR (58 h ri-iE i

h ftI .iq .ii{; +{r 3ndi.r n .1-4qsi 4:r4y

3tr49qz5 *l

Rsrl qG + ft.r) trrqd

ffi"rfur i

ft-.rtr

E+ff'1. qq-r qfua, --+pz,r -:tt

'Tft-41r T,-TrEr dTl.ru

- qsqel

2.

Fz{T.FzzI n"T
q

rErfr?qrr{{

wr6,rftlq6. (+ffi)
.1r{€{T

3. rigart qBa, r+rrzrt
3ft{ ctr.q-r ;r.z+rq

r*6fl

- tr{€II

,|

2

3

qrerr<or :i-ftq +ar,

EPc;

M- (Tr{) 2019

3rTqr4

-*a{"* + 3[qT{ rR ({6'+"
.rtrqcR-fr

qfta-i{ftqrwtfril*r

ft"q"r:- rrrq-q 3{rqrd sr
q-<
W qFFR-d F4-T-d

Ti{T{tftdrEn+fi-ir{

qflrq-a 3{rqr{, 3{rqrf 3i?

3{ril{ Fftq qqmft+;

,ffi1 * n< n qirrff Gi{r

qmr*l

s-d-iffi-ffq

4

EiFI

5

tFrn

(78800-209200

r.; i r+r-12

6

qr{ Tfrerdl

<!-- page 7 -->

I rTrr If-E.U-g 3(i)]

s]Ifd sT {1uN7 : 3I{ITTII{u]

I

7

qrta-frel+rr

I

qr,Ii-frfri1

1
10

qFIilfr Eral

ft.fui:5 ftq rta-t h E-+r r+r,+rc t qT..j1,E irdft-

rr{r
12

11

13

iqfr:- +il{ *t* (ozzoo- qa'+' Errnftq iErft (frfr 1tt=rfr'rar+m h {zier { ft-fl.ili * Rr) qtr EIF6 qzn -qr]l-rrr q
rrrqqi 6.ilr qmqq+ a-#
208700 r.) i Fil<-t t fr qErq-m ftrqFqfur t ft-r+'< eilft:3nqr4frriAiEf ffid+4r

t. erq{ {fuq, c+req llil< qR-{rr +-a+q

fffrr

rizrcq

-;,reqe{

z.q-€ra+{rrr6rF?qrr"rqiisr{6fiesrf; (++fr)
3. riTfiT {Rq, csrccq +( cR:{r{ +-,a+rq

2

1

8 3nqrd'

_rr<Er

rizrrq

3

- *r<ar

4

5

04- (ilr) 2019

mrrrmr ;ifrq *m

+il{ i-E+q (23100- iz;I

-fl-ftrR + qrgrrr qr qfu{fi{

Fr{E'6"
qrrqcB-d

21 5900 t.) c rd-,-l 3

ft:,+rorr+m*r
ft-qur:- e-drffi 3{rqrf sr r< T{
rrFqftddrfdqrt q-<tftTi@r

aqilfrFldr

3rf,{iTffiq

h *or qEr+fi 3rrqr{, 16-3{r<r{,

3rrcrt' 3rt{ qTqrd 1aft-ea

cqrmft{ ffi) h }-s t s.qrff
ft,+r er+r ir

I

7

11

+d-{ nefl

(78,800-

't2

't3

vq5'+' E=rrnfu sffi qfrft 1r+-r-ri h ri'irr t E-{rr +G il ft"y ffi

qq .i-rT ffir. qT,n r q r5,-rqoi
C;rfi 'fiEgqa nfj it

1. 3r.tt qfrq, r+r;r.a gtr qft:{r rdrrrr

narftAtr

10

ftfuia ft-c .rt-ar;aft{r E{E.,{rt i rnrrnq-' rr.afifnr

dFIa-fr A-dT

i rrr 12 re. ffit*rtft-q-d-.ahft.ffi qrr 4S fr{fud

209200 {.)
3ir-{rd

9

er{ierAr+r

iTr,I a-fr Etfi

F{r.{q

-q?frp-r

l.qarpzqlrrqdrft?rnFrqisq-sf,Tfterrf;(+ffi) -r54er
3. {g-ffi {R-q, r+r=zq efr{ cR.{n +"qrrrr

2

1

9. B{rqrf
(4fts4
cqnqft-6

,m)

04" (qrr) 2018

'6r{,Trr i rilqrr r{T Tm{

ftqrqrF+ilr}r

fa'{ur'- {f,,rq-{ eir<r{ +,r.r<

qftqft(dffiqrrriifi{qr3n
h $-da qer++ qrqrd, q-e.3ir-qrt', 3tT-qtf ertr lrarf 1aft.ea

rlnqft-fi ,Mr) + i-s t c.-rrff
B;qIqr{ril

riTrrq

3

qprrq +frq iqr,
+r{e'm"

rrrccE-d

ffi1vMq

- {rcF{

4

?iFI

+Drq

q

,4t-14 (1442OO218200 r.\

5

b

?zFT

qT.ITfi a-ilr

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

I

7

ertc-fiddrr

10

ftftrnmftI ir1'iE i frrrra r',+ria "{rrrr .1.xi.nfter.T

12

nr< ttrcq (1 23 1 oo-21 59oo
r.1

9

dr{rfr z,rtrr

vFIildt Etrr

11

IPARr U-SEC. 3(i)l

13

qp'r' furnftr ffi {frfr lraari h {;ier i E-qn qiG + RT) fr,rc -iq et+ r+r qT,rFT i

hw13iqTn'r"iffit ft*rftfue tfraqreilft:-

rrrqqi +zat:rasq-+ rfr tr

qmedffi-{+arfiE}r

1. qr< qR-q, rsr.oq er( qft{r{ f"{M

riTrd{

-sTs,Ter

2. +ftq F{rrrr,i4r q6ft}q66qfr rap,:q i-+rsii + q-a ecRe.FF - rraEr

s. {g-6 qR?, qrE?4 Sla qftanr +-c{rur

2

1

10. dft6r
Ea rf-r

3

4

1- (q6)

vnrrrrrri*q

(201e)

t'{r,sn6'6',

+r+{R + 3lrtlrr q( trqqE?,
vffiaftqqrffiilrfi1
st-{-{flffiq
ftr.ruT._ iifif+r

rtzrdq

- {<qr

5

fd-{n[+q +

ilr{ilfr anT

<r-1'1,

6

ffi

t:- 40 4f i3rfu{T*

(i,fl1 r-+p zrr-r qrc-+r{ cr {rft
-f,{qr
flrnq rp1 -alaorf ,11 :rftcrT

i
t frn qiq a{ a-.5 fr-1f,.I-d
ftwrr,fii1r

(67700-2087OO

q"a1ff Hi

r.)

tq {d-{ 6r

frqrrfi 2:- 'ar3-fiFr :iz-.rrF? q;.;r h
ftr., MTfi ndlrq.r1r.{ i arzffi1 q

q<,;if+rytqrd-q,

;ift-+rSrq q.$-{ taft.s

3ttifi Trrd {,ra + ftI ftqd ft r€
:ijAq mfta atr ( a ft +a ifiq arn r

ar{qrr) sift-+r5u

1ergfu-+rrluflt
.iftqr1urSrvrqftd

.,tqq, ir.r6q, .q'afia4 1ztl,
ft-irrq, ilrnA-r, E-Ir, f+EF, TEI+*fir rrsT |.iErq' {-.s, ftqr=aq q?r1 fi
q-rdla -3n? rfrfr'Fra a"n qr+r- ffi a
qf

gor4-5,aq+.rch $-ar

Tqrfutfrqrqr{r

cffi . r,,js, 3iic'rc 3ia ftqiraF *-r sT
qerft'{ { qprf}Hi n fra A'en ff ,i?
tsr)

I

7

qr{FFm-

qtrfri.n-rr

(i) rr Rfufl-o 3rfufr'qq, 1948 (1948 61 16) +.+m-r

qrerfl lltr iirq-f{ qrns ff 3ridr

t qffi"m

I
rrs ?rI

10

*tffrrfiarrr

c-ffrrt fi rftmd qr rrrft ffi
qez-qq

ari qr

qT

<T Rfr-drfi srlsR-{q, 1948 (1948 sr 16)
3reft{ 1-1 .72 ilfr {rq-ilr s-rF ?i( €dr sr8

ff 3{-{T* il qFr-il +

ff 6I;

ztt

rt Rfr-flr 3lfttft{q, I 948 (1 948 fir 6) ft q-{q* } rrr.r-t tt * qft{
+s-f, arq qrrr ;tzr 13.08.2009 dzr rtrrd + ilrTft-fi an' rgcr ftu'
orrr t, qrqm qrr crfi-+{'r qr {r*{F arn iracr erfm w ft d; qr
+{ qfr * rrrq rr qr{rfufi l, Rt$ srf+r rear * eil-r dr *or B rr
3-fr,i frqr fr *{ trrrri ii 13.8.2009 ;i r5 arrfi-r qtelnr t

qr

Ufr,rr ft* vftBq56 U.,-

rlri zrFr+ -rqFr q,f4r 4q r;

h +n:rr Ef ftR-,qi ifm ,r{-r,r. Tr Trrr
wan+ tt.iq.r.q e.H + -rrflf-lrffi

i

fi-fr1ft .1. "{r'rr, rrr E4t;tl-rrr rr

ffi

c-rflPlrrft ar.r rrft qr qirftr

1

rEwr-fi-r qteflr ftRqq-am, 2009 E{ri-ft{ q-tet"r ft c-0tn sf,rri

fffn;
(ii) rrrqnr Jns fuaft-{56q

({) (i) T.r ,i'rrt ,rr B,+rq + ftzrft-{
1fifir Y qiq T? e-1frql T,7 * a; zff
(ii) {d-{ +Bffi (56100-175500 -.) {

r+r t0 ii S +.i ffir

(q) F?i,T 7 { 3rfr{ firn ',r-fi h f+tr

t Tc {S4 fr?iffiff i 3{.{fu ..'trer'{

ti<Rft-srqnrqim erfim;

tttrFl-{ rrfu lfr' alra -<i 6f

RqT :- ffiffi

ii i

I am+tt-r + r,ar< 5ra ertr frft-+r 5re d f,ra +{ ar 3r{84 3|-.

1

errr FrSf+ + fil
firr i.na-r+ rrs t'i ff
ltlq o) a.fia,it ?rflrdil&fFft
3rFr+-dc arg

1

ia fi a:

<!-- page 9 -->

lsTrT Il_tsu-s 3(i)l
(iv) rrp6 q

lll-{d 6] {lEitD{ : 3{{{ItlRq

9

.,-u qft.tT-{ {r 3ra-6irr t ifrS-gr 6r-+r areqr

fttqq li rfu, :r++r {sr[n ?d+qFmi fi sqn i ir 6"RUii.+ ftI
n nE-q-d fu eq'iq.+n +Er 3nftr 161+,r{rilr lq)ft-.{ fi qr

qq-fttr

fuur zr +gu-+ {'ifr 3r€dr (3r&flrg) s+ mrqi + ftI dI +q-{d fu
qrq iq qtm rrEr qr-qt{r h frn6-r{sr{ q-{qkd qrfuit/q-SqF-d
e-i-flftii + 3{aqFi{i ff <qn it a-s fr}Fh.ff w m-ft d qq Tfi t
ft;ft Trq r{ Hq q-.+R/+iq +fi q-{r 3rTfr.r ff {d,Tq * ft 3-i-d
fr1 qrtfurftRFt'i +1 tr{i+ ftq w}fld-a er5rr+ rr+} atw n-5<r.+t
h 3nqffit * q-qiq ,irqr t sril"tr Ai ff qrrn++r rfi tr
11

12

qrla-Ed-mr

saE " fu{r.ftq

't3

ffi qftfr tTE n {'jq + E-qr 4-i i ftT)

ffi"rkrtft-q+rqilft:-

qq -ird +fl'3lrc'rq q r{Tcqi T,-{r

t. er.r< qfrs; c+req sia cR-Er.56Trrrr riTr(fi

- ztlAer

-.{r4rTd

*t

2.tsrzq+ar{drftaqrrcqitgqq-erfiasr.r(++*) - q{ar
3. s-gtr {fr--{, r+r..q.*r qfrqr" r",rrrr rizr,rq
- Tir{
2

1

tl ;ift'+rWrd-t
(4fts+d-ffr+)

4

3

1. (c6)

qrTrflTr +r*-q

*aq*Eryh-r-

(201s)

q-m, q-{z'+"

12, (78,800-209200

-r{*o h 3{rerr. q-(qM? fr{rqr
Il-qcft'{,
rrm{r
sin-iqffi{
ftqur'- liftr+T {.q {d'{ sr qa,

5

?Tq

Tr{

6

T.+

frmr

5\

;ift-+r Ee sf-{, sift"+-l'Tq qf{
(sfts +f,{ rqnqft-m ,m) +;ift-nr
q-f-{ ff

qm-d g,o -fi16 rr5 v-<

h fra-r rqrftTftqr elqr

7

I

8

qqa-fr1tnr

qr{r#reimr

10

frft-di + frq zrlzia i fr+ ra.,rm i qrgrr, 'r

el;q

cfrmerrrr
11

12

cffid:

Eirt tEtr (67700-2o8zood.) +
ca-r-t t

i ifitfir Era s-fr{ Fr{i A

ef ftqfr-d'i-qrfifrr

q{a '+' Br+nftq ffir cftft (r-+pni ffi
ft,FRfud + ft-q-mr. Ehft.1 .

qr6 qft-a; *-+rccq *{ .{ft{rr Terrur ri.rqT

.iq t'irF {?T 3tT,IfrT n
q-{Tqrl {,r;il 3{r4e2l;6

- q?.7:tr

(++ift) - {er?r
ri?rcfi - rriEq-

2 FdrF:4i-q-rr{rfraqn-qqi3q{a.rftecr6
3. q5m qR{, r+r+zq eir qfi.arr t;Trur

12. lift-{r {q ffi{
tr-.ryqrrrfrl

13

h d,irr t E-qr 6ri + ftI)

+c+fi1;6;

1. (qfi)
(201e)

*sr, {qa'+,

FtrT- M 13,

r;r{Tr-} enarr qa qF-{i{ ft;+t w q-r,m

ilqqE(,

(123100,

er

frq'ur'- Giftffir tq {fr{ fl'rr<, ciftrfir Ts

qf{, "ifsf,r {q {S-{ (+fts }ra-<my
"iftr+t y+ (q1f!-{ qs-q ,m) + cif.F+;r
tq e-$-{ qqRd t-{ F+Fe qfl Tr fi
Tire{r

+ fi-m s-lrft-il fr;sr qrqr

q-{iqffiq

215900 r.)

"ir-t {.fi
ndr

<!-- page 10 -->

r0

[Panr II-Snc. 3(i)l

THE CAZETTE OF INDIA : EXTRAOT{DINARY

I

7

I

10

qr{;rdi Z.idlt

eAc-fi*drr

cr{+f,r et-arr

11

fr.ftF,{i h ftrr 365aU i, frar +'+errm h 3ilaT- rrr

cftfi-{ftrrn

12

ciqti:

13

qe " G'+nftq iffi qftft (r+,'+a cffi i; rizia i

drrl ildt EI{n

Rqrr fi-.i + Rn) ffi.rF.+ei q ft.r+r aiift 1 31qrqfuq, qpzq 4rqfras

i'{ drm +er 3{PiFr q rFTqqi {,rnr

:

|5q frffi 167790-208700 F.) h cil{ t Z ii
irrr ;ift-r,r Eq ffi{ 4fts +ilfirq ffi qri:
<f i+rfifrr

qr4rr+; a-fitr

'!rLlrzr

2 t.qr€Lq t{r qf,,rft?srrd{ ir 3.{q7fi<rrd (frfl-fi) Ir{Fq
3 }TTd qB{, F{rE,4 3iF rrF-Tp v.;tfiul qar-rr- 1r?;or

2

1

13.

q-fi{

iifiiqr t?c

(qqqfi)

4

3
{I9JTITT

(201e)

h,-p{+dl,

+lfrrr< h qrem qr qFa-d-d h,{r

qw'f,"

(144200-

Irq.Ta-{,

218200F.)

qrFff,r*l

fuq-q:- iifffir Ts s-Sq fiT !q,
sifls-tr tq qdq, cifir+T W q-S-{

5

id-{ien}

1- (q6)

6

cqtrfr e.rdlt

4{{

kI.-14,

3m{qffiq

Ffts te+qml dfir+r te.
(3rfftrr6 +aa ffi1 + EifS-dT W
ufq qFrRr w cfi-m q< t
$-mq-qrR(fr-qrqrqr

8

7

cr{+fr;rmt

a-Irfrat-mr

9

10

I

or{rt; zi.nr

ftfui h fta aaaq a; frm -+,''ni il qprg
'rr

12

11

ffi:-

|6q tRtr 1123100-215900 6.) h
trfrr-1 3 i' Efi ciilifir t"s s-d-{
(qrqs'qtrq) R-qi{raqf

i-+rftdr

qftm frrr

ffid

+q6 " fo*nfu

ffi qftfr (r+',+r+ ffi il ri'i:t i E-qrr tri

+ftn;ffifrmtft-d{r4hfi-

13

q.{.{iT +4 ?T+.r ! '5qqsi a-a1
qragqa afr tr

- ',r'.-q?l
1. qfta rapzq fir qft.{rr 6-{r'rr q+raa
z r+rlq t+rsii * rqr-fr?srmlt{r.'r{ iarcii h q-a -r{r- -frrrd
-+r{EI
3. F{r€cq 3i-. qRqrt f"TroT {Trf,ct?irt 4qrqBs

- rrTqr
[.5r.Ti. q.1201 BtO1t2011-frn3 -\-q Vl]

{mfi fr,n, -r1-f, qf}4

MINISTRY OF HEALTH AND FAMILY WELFARE
(Department of Health and Family Welfare)

NOTIFICATION
New Delhi, the l2tr'June, 2019

G.S.R. 436(E).-In exercise of the power conferretl by the proviso to article 309 of the Constitution ancl in
supersession of the Dental Posts Recruitntent Rules, 1997, except irs rcspects things done or ontittetl to be clone before
such supersession, the President hereby makes the fbllowing rules regulating the Inethod of recruitruent of Dental Posts.

namely:-

<!-- page 11 -->

ell.fd ql {Fltlfl : gI{TTEI{I

[lrFr rr-uu-s 3(i)]

l.

lt

Short title and commencemcnt.,

l' These rules may- be called the Ministry of Health and Fanrily weltare, Departnrent of Health ancl Fanrily
Welfare, Dental Posts Recr-uitnrent Rules, 2019.

2. They shall come into tbrce fiom the clate of their publication in the OtTicial Gaz-ette.

2'
Number of posts, classification and level in pay matrix.- The number of saicl posts. their classification and
their level in the pay matrix attached thereto. shall be as specilied in Colum (2) to (4) ol the Schedule
annexecl to these

rules.

3 Method of recruitment, ageJimit and other qualifications, etc,- The method of recruitmept. age- li6it.
qualifications and other nratters relating theleto shall be as specified in colunrns (5) to (13)
ofthe sai4 Schedulc.

4. Disqualification.- No person,.-

(a) Who has entered into or contracted a man'iage with a person having a spouse living: or(b) Who, having a spouse living, has entered into or contlactecl a marliage with any per.so1,
shall be eligible fbr appointment to any of the said posts

Provided that the covernment may, if satisfied that such nrarriage is pernrissible under
the personal law
applicable to such person and other party to the marriage and that there are other.grouncls fbr
so doing, exernpt
any person fiom the operation of this rule.

5' Power t0 relax.- Whele the Central Government is of the opinion that it is necessary or expedient so to
do, it may, by
order, fbr reasons to be recorded in writing, and in consultation with the Llnion Public Service
Cornnrission. 1.ela^ any oi

the provisions of these rules with r-espect to any class or catcgo'y .f perso,s.

6' Saving.- Nothing in these rules shall afl'ect reservations. relaxation ol age-limit and othcr concessions required t, be
provided for the Schedulecl Castes, the Scheduled Tlibes the Othel Backwalcl Classes,
the Ex-serviceme, and special
categories of persons in accordance with the orders issued by the Government ti.om timc
to tinre in this resard.
SCHEDULE
Name of Dost

Number of posts

I

2

L Dental
Surgeon

( llassificstirrn

32*(2019)

Cenelal Centlal service

Group'A' Gazetlccl

* Subject to variation dependent on workload.
Note-l: Institution wise allocation of posts will be as uncler:_

(i)
(ir)
(iii)

Non- Ministerial

Central Govt. Health Scheme - 25
Dr'. Ram Manohar Lohia Hospital - 4

SafdarjungHospital-3

Note-2: The post of Dental Surgeon is to be operated in the gratle of Dental
Surgeon, Junior Staff Surgeon, .StafT Surgeorr (Dental). Stafl' Surgeon
(DentalXNFSG) and Consultant in Dental Surgery within the toral conrbined
sanctioned sh'ength of 32.

Level in Pay Matrix

Whether

Age limit fbr direct recluits

Selection

or non-Selcction Jrost
4

Level l0 in the pay matrix (Rs. 56100177500)

6

Not applicable

Not Exceeding 35 years

Note-1: Relaxable tirr Covernnteltt servilnts

upto five ycars in accordancc with the
instructions or orclers issued bv tlre Centr.al
Govelnnrent.

Note-2: The crucial clirte tirr deterntininc the
agc limit shall be the closing date for. r.eccipt
ol applications lionr candiclates in lndia antl
not the closing date plescribed firr-those in

<!-- page 12 -->

t2

THE GAZETTE OF INDIA : EXTRAORDINARY

IPARr II-SEC. 3(i)l

Assam. Meghalaya. Arunachal pradesf,.
Mizoranr, Maniput, Nagalancl, Tripur.a,
Sikkim. Ladakh. divisron of J ancl K Srate.
Lahaul & Spiti District and pangi sr,rb

clivision of Charnba. distr.ict of Himaclral
Praclcsh. Andaman anrl Nicobar Islancls or
Edur:ati,nal and ,ther qualifitationi required f.,r dlr...,t ,rc...rtts

l_
n
I Dssenltat:
(r) A re'"'ogni.r.d
I thc Denrisrs
Pj:Pt of Dentar Sr-rrgery clegree quarificarion incrudetr in part-Lf
Act. 1948 ( t6 of l94g).
I

Whether age and
educational qualilication
prescribed for direct recruits
will apply in the case of
_ __ promotrcs.
8

Nol applicablc

I

lo*
A.recognised

Dental qualification obtained upto ol.ll.lL)72 under part-ll of the

schedule ro the Dcntists Act. l94g ( l6 of l94g;.
OR
A-recognised Dental qualification granted by authority ol institution
outsicle lnclia only
when granted to a citizen of India upto 13.08.2009 under part-lll
ol thc Schedule to lhe
Dentists Act, 1948 (16 of 1948).
OR

Any person who is citizen of India possessin_[ tbreign quarir,ication ancr has
appeared
and passecl the Sc'eening Test Examination as per scrree,ing Test
Regulatio, 2009
w.e.f. 13.08.2009.
(ii)Shoulcl be regisrered with any State Dental council
or Tribunal in Inclia.

(iii) completion of cRl (compulsory rotating internship)-candidates who
nray not have
completed CRI ue also eligible to appear' fbr selection proviclecl
that, if selected, they
shall have satisfactorily completed the compulsory internihip belbre
appointment.
Note:- Qualifications are relaxable at the discretion of the Union public
Serviccs
Commission fbr reasons recorded in writing in case ol' candidates
otlre'wise well

qualified.

Period of Methd of Recruitment whether uy oiffi
Probation,

if anv

or by deputation/ absorptio, and percentage of vacancies to he riiled bv
various methods.

In case of recruitnrent
lr.v prontotiotr or
dcputation or absorptiun

grades trom

which

promotion or deputation

0r absorption to be
9

One year'

to

l Direct recruitme
Not., Vu.uncies caused by the incumbent being away on tr-ansf.er or
I

deputation or long illness or on study leave or unde*ther e'ircunrstances
fbr
a duration of one year or more may be fiiled by the appointing authority
on
transf-er on deputation basis fionr officers o1' Central Gover.nment

o, Stut"
CoveLnments or Union Tenitor.ies.
(a) (i) Holding analogous posts on regura'basis. in the parent cacrre or
departnrent; or
(ii) with two years service in the grade rencle'ecl aftcr. appoir.rtnrenr th.r-eto
on a regular basis in Level 8 in the pay matrix ur equivalent in the
parent cadre/departnlent; And
(b) Possessing the educational qualifications ancl experie,ce prescribecl for
direct recruits under coluntn 7.
(The maximum age limit for appointnrent by creputation shar be
not
exceeding 56 years as on the closing date of r.eceipl ol.applications by
the

Ministry).

matle.

ll
Not iipplicablr:

<!-- page 13 -->

IqFr rl-qu-s 3(i)]

sllfd 4-l {lsItEI : 3T{ITriI{Ur

If Departmental Promotion Committcc effi

r3

Circunrstanccs in which Union public

what is its composition

Service Commission is to be consulted in making

recruitment.

t2
uroup A Departmental promotion committee (fbr
considering confir-mation) consisting of;

|.

Joint Secretary, Ministry of Health and
Family Welfare

13

Consultation wirh Union puutic
fbl filling up the posr.

se@

- Chairntan;

2. Director', Central

Govelnment Health

Schenre

- Member:

3. Deputy Secretary, Ministry of Health and
Family Welfare

-Member.

I

2

2. Junior Staff Surgeon

1

32*(2019)

Ceneral Ce ntral Selvice Cr.oup .A'
Gazetted Non- Ministcrial

(Dental)
*Subject to variation depenclent

uu woLklourl.

Note:- The post of Dental Surgeon is to be
opelated in the grade of Dental Surgeon, Junior.
Staff Surgeon. SrafT Sur.geon (Dcntal). Stal.l'

Surgeon (Dental)(NFSC) and Consulranr in
Dental Surgery within the kXal combinecl
sanctioned strength of 32.
4
r r rn the pay marrix (Rs. 67700_Z0gj00)

5

6

Selection Post

7

Not Applicable

8

Not Applicable

I9l4,plrcable

9

r0

Not applicable

By Pronrotion on in-situ basis *ithuui linkage to
vacancies.

ll
Promotion:

Dental Surgeon with fbur yeitrs
regular service in the grade i.e. Level

l0 in the pay matrix (Rs. 56l0G

177 500).

12

Group A D.p

l3

considering in-situ promotion) consisting of:--l. Additional Secretary Ministry of Health antl Fanrily

Consultation with Union Public Serr[e Comnrissi,rn ,ut
necessary.

Wellare
_ Chairman:
2. Deputy Director General (DDG) of'Health Services
in Dte.GHS.
_ Member.:
3. Joint Secretary. Ministry of Health and family
wellare
_ Member..
I
3. StaU Sulgcon

(Dental)

2

32*(2019)

1'Subject to variation clepenclent olt
wolkload.

Note:- The post of Dental Surgeon is to
be operated in the grade of Dental Surgc:on.

3

General Central Ser"vice Gr-oup A Gazettccl Non-

Ministerial

<!-- page 14 -->

l4

THE CAZETTE OF INDIA

EXTRAORDINARY

IPARr II-SEC. 3(i)l

Junior Staff Surge-n- TGtt- S*g*
(Dental), Staff Sur-geon (pentatxNpSC)
ancl Consultant in Dental Surgery within
the total contbined sanctioned strenqth ol
32.

l.evel l2inthepayffi

7

8

Nnf

Not Appl]cable

By Promotion on ir-situ basi, without linkage
to vacancies.

Promotion:
Junior Staf1 Surgeon (Dental) with five years regular
servicc in the gracle Level I I in the pay nratrix (Rs.

67700 201i700).

Group A r.ro

^:... promotion)
-- situ
consisting of:---

I

2
3

Additional Secretary Ministry of Health ancl Fanrily

welfare

Consultation *ittr tlri-, pul^* l;.-i."
Commission ntlt necessary.

_ chairman.

Deputy Director General (DDG) of Health Services in

Dte.GHS.
_ Menrber.
Joint Secretary, Ministry of Health ancl lamily welfare

4, Staff Snrgeon (Denraf

32*(2019)

(NFSG)

Ciereral Cen[al $-rvict Gnup A

'iSubject to variation depenclent on wor.klorcl.
Note:- The post of Dental Surseon is to be operated in
the grade of Dental Surgeur, Junior. StatT Sur.geon,
Statf

Cazetted Non- Mi rristerial

Surgeon (Dental). Srall surgeon (Dental)(NiSG) ancl

Consultant in Denral Surgery within the lotal conrbrnecl
sanctioned stlength of 32.

Level l3 of the pay ,rr"tr* (Rs.
r 23

Not Applicable

t00-2 15900).

9

Not applicable.

il)

Dy rronlotlon on rn_situ lnsis withor.rt
Iinkage to vacancies.

II
Promotion:
StafF Surgeon (Dental) with lour years
regular service in the grade Lcvcl l2 in thc
pay matrix (Rs. 78800-209200).

<!-- page 15 -->

lqFr rl-qu-s 3(i)l

eiRd s'I {Istrlll : 3IqrqRUr

Group . O
Consultation wittr U n,,,nTuUli.
Selvice Commission not

promotion ) consisting of:-

I
2
3

Additional Secretary, Ministry

of Hearth and Ifunriry werare

necessafy.

Deputv Directr-rr Generar (DDG) of Hearrh
Services in Dte.cHS. iliJ,l'itJr,
Joint Secretary, Ministry of Health onO nunrify
_ Menrber.
Welflir.e

5. Consultant in
Dcntal Sulgery.

*Subject to variation

clepenclent on workload.

General Cetrtral Ser-vice C.uL,p a
Gazctttrrl Ntrn- Ministcrial

Note:- The post of Dentil Surgcon is to be ofc,rated

of Dental Surgeon. Junior. StalT Si,rgeon.
I tf.SrlOe
Staff
Surgeon (Dental), Sraff Su.g".un

(Dental) (NFSG) and Consultanr in Denrat
SJrgery
within the total conrbined sanctionecl stlens(h 01':12.

L.rel l4inthepay@

Not applicablu
9

Not
applicable

l0
By Promotion on in-

situ basis without
linkage to vacancies.

stafr Sugeon (Dentar) (NFSC) with seven years .egurar service in Level
l.r in
the pay matrix (Rs. 123 100-2r59001 or 20 years of regurar
service in a gr-o,p A
post in the streant.
Note: Promotion of .Staff .Su.geon (Dentar) drawing the pay
scare i, pB-3 +
GP-7600/- on reg,lar basis as on 29.10.200g i.e. rhe crite o1
cxtending rhe
be,efit upto SAC g.ade untrer DACp scheme shall continue to be govJr.ned
with the provisions ol notilied RRs vide G..S.R. No.
-53 dated 0-1.02. 1998
provided they have not optecl fbr the benefit under DACp
schenre dated
29.t0.2008.

Group ' A'Departme"ffi

l2
(for t:onsidering In-

situ promotion) consisting of:L Secretary Ministr-y of Health and Family Weltare - Chairmarr:

tl

Consultation w;ttr Union put,ti. Seruice
Comnrission uot necessal.y.

2. Director. General of Health Ser.vice.s ol Additional Dir.ector.
General of Health Services

- Mcnrbcr:

Welfare

- Menrber.

3. Any Additional Secretary in Ministry of Health and Fanrily

6. Assistant
Plol'essor

xSubject to variati
Note:

on o.o.ro.J1,\0T3,.-,ffJ

"

L All the fbur posts are ailocated rbr Lady Hardinge Mccricar coilege. New
Delhi.

2. The post of Assistant Prcfessor is to be oper-ated in the gracle of Assistant
Prot'essor, Associate Prof'essor, professor and prrf'essor (sAG) within
the
total combined sanctioned strength of 4.

Genr:r-al Ccntral

service Croup-

'A'Cazettetl
Non- Ministerral

<!-- page 16 -->

t6

THE GAZETTE OF INDIA : EXTRAORDINARY
4

5

Level I I in

Not

the pay

lPanr II-SEc. 3(i)l

(,

applicable

matrix (Rs.
67'7(n208700)

Not exceeding 40 years.
Note:- (relaxable fbr Govelnment scrvants r-rpto 5 yeals in accorclance with the

instructions or orders issued by the Central Government )

Note:- The crucial date firl determining the age limit shall be the closing clate lirr reccipt
of applications from candidates in India and not the closing date prescribed for those ip
Assam, Meghalaya, Alunachal Pradesh, Mizoram, Manipur, Nagarand, Tripura, sikkirr,
Ladakh, division of J and K State. Lahaul & Spiti District and pangi su'b diuision of
Chamba, ciistrict of Hinrachal Pradesh, Anclanran ancl Nicobar lslancls irr Lakshadwcep.
7

Essential :

8

(i) A recognised Bachelor of Dental Surgery clegree clualif icatiorr inclucled in par-t-I ol'

Not applicable

the Dentists Act, 1948 ( l6 of 1948).

OR

A recognised Dental qualification obtained upto 01. I 1.1972 uncler.Par.r-Il of thoschedule to
the Dentists Act, 1948 (16 of 1948.
OR
A recognisecl Dental qualification grantecl by tuthority ol institution outsile Intlia only
when granted to a citizen of India upto 13.08.2009 uncler Part-lll ol the Scheclule to rhe
Dentists Act, 1948 (16 of 1948).
OR

Any person who is citizen of India possessing fbreign qualilication ancl has appeared and
passed the scleening Test Examination as per Screening Test Regulation 2009 w.e.f.

-

r3.08.2009.

(ii) A post- graduate degree in Dental Surgery fr.om a recognised university or
lnstitution.

(iii) Should be legistered with any state Denral council or Tribur.ral i, Inrlia.
(iv) 3 years' teaching experience in the specialty as Tutor or Demonstrator or Registral

or Senior Resident or lrcturer after requisite post Craduilte rlualilication fionr;i
recognised teaching i nstitution.

Note:

I- Qualifications are relaxable at the cliscretion of the Union Public Service Conrnrissiori for
reasons to be recorded in writing in case of candidates otherwise well clualifierl.
Note. 2.- The qualification(s) regarding expelience is or are relaxable at lhe discretion of the

Union Public Service Contntission fbr leasons to be recorrierl in writing in the case of
candidates belonging to Scheduled Castes or Scheduled Tribes if at any stagc ol'sclection
the Union Public Service Commission is of the opinion thar sufTicient nimbei of candiclates
from these Communities possessing the requisite expelience ale not likcly to be availablt: to

till up the vacancies reserved fbr them.
9
One year

l0
Dilect recluitment
Note: Vacancies caused by the incumbent bcing away on
transf'er on deputation or long illness or on study lelve or
under other circumstances for a duration of one year or
more may be filled by the appointinr authority on transf'er
on deputation basis fiom oflicer.s of Ccntral Gover.nmcnr or.
State Governments or Union Territories.
(a) (i) Holding analogous posrs on regular basis, in the
parent cadle or depar.tment; or

(ii) with 5 yeals' regular service in Level l0 ol'the pay
matlix (Rs. 56100- I77500).

(b) Possessing the educational qualilications and
experience prescribecl for dir-ect recruits under- colurtrn
7.

Note: The nraxinrunt age-limit for appointtnent on
deputation shall be not exceeding 56 years as on the closing
date of receipt of applications.

II
Not applicablc

<!-- page 17 -->

Ivn n-uo-s t1i;]

el[{d 4] Is[r]-l : 3ru{Tt{I{ul

t1

t2

j

Group 'A' Deparlmental plomotion C,rmmittee (f-

uorlsultatlon wrth Union Public Services Contmission is
necessary fbr filling up of post.

confirmation) consisting of:l. Additional Secretary Ministry of Health and
Family welfare.
- Chairman

2. Deputy Direcror General (DDG) ol Health
Services in Dte.CHS.
_ Member.
3. Joint Secretar.y Ministry of Health and Family
Weltare.
- Member.

I

2

7. Associate Prof'essor

04 (Four)* (2019)

3

Cenelal Cerrtral service Gr.oup .A' Cazetted Non-

*Subject to variation depenclent

Ministerial
on

workload.

Note:-

The post of Assistant
Prof'essor is to be operated in the

grade of Assistant prof'essor,

Associate Prof'essor, Prof'essor arrd

Professor (SAG) within the total
combined sanctioned strength ol
fbur.
4

Level l2 in the pay marrix (Rs.78800-209200)

7

5

6

Sclection

Not Applicable

*

Not Applicable

Not Applicable

9

10

Not applicable

By Promotion on In-situ basis

ll
Promotion

without linkage to vacancies.
Assistant Protessor with two years regular service in the Level
I I in the pay nrarrix (Rs. 67700-208700).

t2

t3

Group ' A' Departmental pr.omotion

Consultation with

Plomotion) consisti ng of:-

l.

Additional Secretar.y ---Ministry of Health and

family Welfare.

Union public

Selvices comntission is not necessary.
_ Chairman

2. Deputy Director Ceneral (DDG) of Health Services in
Dte.cHS.
_ Member.
3. Joint Secretary, Ministry of Health ancl Family welfare _ Member
I

2
04 (Four)* (2019)

8. Prof'essor

3

'kSubject to variation dependent on wor.kloacl.
Note:- The post of Assistant prof'essor. is to be oper.ated in the

General Central service Group
'A' Cazetted Non- Ministerial

grade of Assistant Professor, Associate prof'essor, prof'essor and
Professor (sAG) within the total combinecr sarrctioned strensth of

four.

4

Level I 3 in the pay matr.ix (Rs. I 23 100-2 I 5900)

Selection

Not Applicable

<!-- page 18 -->

r8

THE GAZETTE OF INDIA : EXTRAORDINARY

IPARr II-SEC. 3(i)l

7

{t

Not Applicable

Not Applicable

9

l0

Not
applicable

By Promotion on In-sitr.r

ll

Associate Prof'essor with fbur years regula.@
matrix (Rs. 78800-209200).

basis without linkage to
vacancies.

l2

Group ' A' Departmental Promotion Committee (f'or
considering In-situ Pr.omotion) consisting of:-

I

l-3

Consultation with Union Pr-rblic Services C.lr.r-issi* is rutt
necessaly.

Additional Secretary, Ministry
of
Health and Family Welfar.e. - Chairman.
Deputy Direoor General (DDG) of Health

2

Services

3.

in Dte.GHS

- Member.

Joint Secretary, Ministry of Health ancl

Farnily Welfare.

- Member

t

2

9. Prof'essor

3

04 (fbur)* (2019)

General Central Service Group A Gazcttccl Non-

*Subject to variation dependent on

(sAG).

Ministerial

workload.

Note:- The post of Assistant Professor is
to be operated in the gr-ade of Assistant
Prof'essor, Associate Pr.of'essor, pr-of'essor

and Professor (SAG) within the total
combined sanctioned stlength of four-.

4

5

Level l4 in the pay matlix (Rs. 144200-21.8200)

Not- Applicablc

7

It

Not Applicable

Not applicable

r0

9

NotApplicable

By Prornotion on In-situ basis

6

I

Sclcction

11

Promotion:-

wilhout linkuge to vacllrrcies.
Prof'essor with seven years r.egular ser-vice in the Level l3 in the pay

matrix (Rs. 123 100-2t5900).

t2

Group ' A' Departmental Promotion Committee 6or

considering In-situ Promotion) consisting of:-

l.

Secretary, Ministry of health and Family

Welfare
- Chairman.
2. Director Cener.al of Health Services/
Additional Direcror General of Health
Services
- Member
3. Any Additional Secr.etary in the Ministry of
health and Family
- Member..

l3
Consultation with Union Public Services Commission is not
necessary.

<!-- page 19 -->

I qtrr Il-uu-s 3(i)]

t O.

qrfd sT {T-qqi . 3rgrqRul

UaxitltrfaciaE*geon

0l (one)(20I9)'r-

*Subject to var.iation

cleperrrlerrt upon wor.kloatl

Note:- The post of Maxilloflcial Surgeon
is to be operated
in the grade of Maxiilofaciul
sr.e.r-r,'i;,;l,lri*,.,
Sur.geon
(Sr. Scate), Max i Iofaciar
Srrg.,r". fNe!6i I' iau^,,,urn.,u,
(SAG)
within the totai conrbinecl ,*._,i"r",i

:i:fl:"
Level ll inthe

Not

pay matrix (Rs.
67100-208700)

applicable.

General Cent.t se,
^*e
Cloup-'A' Gazettecl Non_

Ministerial.

srrengrh

Not exceed
Note I:- Relaxable for G,o::tnT"'t

servants upto 5 years rn
vears in accordance with the
instrrrr:ri^nc
instructions ,rr,--r^-.
or orders ,-irr,,"a uy
Nore 2:- The c'uciar uu,..r:,r
.r.,.,,r,irirg',;. ,*.'i,rr, shail bc
rhe cr.sirrg trare rrr.
receipt ,r'applicati,ns ri.rn
cantridatc. rn'rn,rio?i nor
rhc crusing cratc pi:scribcd
fbr those in Assanr.

ir,l'i;;#trJJjffi

,.on"l:Ir, A,,,;;.;;i';;0..i. ,,.*.,,r.

Manipur. Nrgrrr,,,r,

Illirl'l;Jl,ilil;,':it*:lll:l
:iill',iil Laha,, and Spiri Dis,rc, rd
;,;;
iffin: flHff : * ; ;;; ;,,, i,;: ,;,.i:i"i#ifi fl :.:ij I i [,^li.l,;il"l
a

;,

(i) A recognised Bachelor of
pafi_I of the Denrisrs

OR

:,

Dentar surgery_..degree quarification
inclucred in

Not applicatrle

Ao, t94g tiO-"irC+Sl

rf*'ffi.1;:i.?'J;1,:'fllh[i,?oi?'iilr;o,, ot

r te]2

OR

rrncrer pa,-rr or ,he

A recognised Dental ou:

:
ililt*i-l:Hl[*H;1i11,::'il::,'i#i1"#'L::,r']:T:t;ilt,iliii;,J;fl
OR
Any person who is citizen
of India possessing lbrei
cltralil)cation anti has appeared
and passecl rhe Screenin.s
_ Tesl Exanrination is p"._s.r..ni,,.ni._i.ii.*rii,,1,"

w.e.f. r.3.08.2009

:,,]
"'
.

i;'ilfi::.",i:'j':."t"1:j{

,oo,

: 3',i!",;)iiilfllldllll'ffifl,.l.l,nj.nr,:r,,,.
"i"i#.
il-'.'
"]

;*. .::*i:i
]' l'Jhe'esisrerecr
(iv) Should
',;il :;:i'
*itnrny

J,: i

l

MD

s i, o,a,

: l ill l ll l i

l -,,
l,,

stat. Denrar
""" councir orTriburral irr Inrria.
Nute' r- Quarirication',s
are reraxabre.,,i" 0ir"..,,,n
ol.rhe Uni.n pubric Ser.vicc
,'trt't'eas,rs tu
u. ,..r.t",t];;il;;

frTli,'J}t'*

case of cartritrares orherwise

wc,

Note. 2.- The qualificatio
u n i on pu br i c J;;J

il H;:i:#,i"i ::ffi:J,f #".:: lffi H,. ;,ji,ffi

cundidares belonging

:

ro Scheduled cr,,i".'*,ilie.luled

:il : jX., :;

Triie*.ii..ri ,nr,,r,rs.
v.,,,ri. ,,,

r,ti
i. n,
di:j,i |l. H#, [:'J :, :JH,S:I ru :::.: : :i :f ;,] J',ex;,e,
ience are

;iJ[,:;::,,.,,e

Note: Vacancies caused

,r rf.',il
,..;:; ;; ffi; ,II:.T.lill,I.TJ1.J;,1,.l,iil:::j,:ll
utrrEl ('lrellnlstltnces lbr.
one
ilJ"H,1,,::,:,:i^,it:l.lol
year or nlore nti.tv
a duralion ol.
rhe
,p;ruirrting authoriry on
,i.priuiiun"iuri, itrr',lnll
..t"':9^o'
rransl'er on
tcers of Centr.al Crver.nment
Union

Territories.

((at (i) Holding analogous posts
iio.,,.rrtsrrt

o, State Cur.,lnrl.,li, ,r,.

on regular basis, in the parent

caclre or

Not applicable

<!-- page 20 -->

z0

THE CAZETTE oF INDIA : EXTRAORDINARY

[PART II-SEC

(ii) -fi

(b) Possessing the educational

qualifications ancl expenencc
pr.escribed tbr

direct recruits under colunrn 7.
Nol:: Th,: max_imum age lim.it for

appointment on deputation shall

be nor

plications.

1. Additional Secr.etary Ministr.y of

Corsultation *,th-Dni* public-

Health and Family weltare.

2' Depury Direffor Generar (DDG) of Hearth Ser.vice,
3. Joint Secretary Minisrry of Health and Family

t t. Maxillotac,at

(Senior Scale r

Surc;;

Services Cornmission necessarv

,,,

filling up rhe post.

;l:lim.

*.,rrr.-_Yil]rlii,

0t (one[2Qf9;i--.--.---.--.--.--._._'r'Subject to variation clependent

Ceneral Centraf serri..

upon workloatl

Group-'A' Gazettecl Non-

Note:- The post of Maxilkfacial

in the grade of Maxillofbcial Surgcon is to be operate(i

Sur_geon. Maxillotacial
Surgeon (Sr. Scale). M
Maxi,ofrri"r sa,,,.^^^.,11r]t3laciat Surgeon (NFSG) a
y:l:1,.:r-.:,
:, u,s. on ( c ;' ; ilr " ii;-. iJ,. I *i.l:,uo],.t

sanctloned strength of

ffi
9

Nil

il

r

I

"

one.

5
6

Selection

(Rs. 78800-209200)

M;ppi.'"b1"

BrE#*.l^,il--Eil
without linkage to uacancies.

lI

---.---.-..--..--.--------.-_

Promotion
l\4axillolacial Sur-ueun with

lwo ycat.s regular servicc

iidj.

in

Oro"O *

L Additional secrerarv
of Health and Fanrily wcifare. _
2. o"o*r "ii,..#ary-A4inistry
Chairman
:neral (DDG) of Healrh
S".ri.", in il;;r:
3. Joinr Secrerary Ministry of Health
and Family Welfare.
,y:#:,

Maxillofacial
Surgeon

(NFSG)

0r

tirr

Ct,nsuItal i,rri*i thGiun_-

Public Scr.vices Cornrrrissiorr

(om

var.iarion depc n tten r

upon wor.k oltl
y,.,.
^,t,,1rlj"IJ1l
Tn. post of M;fii;f*;;r;1ilJil,:;,,1,, bc ,,ncr:r,.,, i.. +1.
Hli*,iiliidfi::.,il,,y:^,rr,ro.'r,i'lui:l;; ",';:";:::l,l"J['^,ii;,'l:,:ii
I

sanctioned stren*,n orrn.l"'ofacial 'Sur''qeonlsncr within the total combincil

Cereral eEnt, al
service Croup-'A.
Gazeilerl Non-

Minisrerial.

is

<!-- page 21 -->

lqFr Il-qu-s 3(i)l

qrcd s-r {rqqt . 3T{ITgIRUI

Level l3 in ttre pai matrix (tfr
r 23 I 00-2 I

5900)

Ur aro-urro,
Promotion
Maxi llt-rlacial Surgeon (Sr.
Scale) with fbur-years
regular service in the Levcl
l2 in rhe pay matrix (Rs.

Orour 'O'
plomotion) consisting of:l. Addirional Secretary Ministry

consulta@
Commission is not necessary.

of Health and Family wellhre.

2. Deputy Dir.ecror. General (DDG) of ,.",,n
Dte.GHS.

3. Joint Secretary Ministry of Health and
t3. Maxiilofbiial

,.."rlli,jr,li]

Fanrilf,H:lrT:

t{one[7dfi[-

Surgeon (SAG)

Uene-ral Central serui.EEilp-

^)uDJcct to variation depenclent

upon workloccl.
Nole:. The posr or rr,Iaxirrula..t;.-il;_;t,,

opelared in rhe srade

XX
li:'::r l,l.:t: :l t' :
(NFfC)

frlax,lfnfr.ilf
^of
or'). M;; ;;liu.,

'A' Gazctrcd Non_ Ministcrial.

is to be
"'S,,.g.,rr.

o, -"r,,.*.,,

and Maxillofaciat Surgeon
^s.,
(SAC) within
"""' "1
combined sanctioned strength
of

4

Level 14 l, tGlay- matrix
(Rs. 144200_21 8200).

onc. '

,rll';il]

5
6

S.l..tion

N"t ,ppll.rbl.

Ur r.on
Promotion

Maxillofacial Surgeon (NFSG)
with
seven yeal.s r.egu.lar. service
in the Levcl

the pay rnarr.ix (Rs. tZ3 tOO_
]]-.:l
2t5900).

g%

<!-- page 22 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

Group'A' DepaillentalT.onloti,on
(fbr considering In-situ pronrotion) consisting

IPARr II-SEC. 3(i)l

Cunsrltati

of:-

l.

Secretary Ministry of Health and
Family welfare
Chairman

2. Director Ceneral of Health
Selvices/Additional Director
General of Health Service s
3. Any Additional Secretar.y
in the
Ministry of Health ancl Family
Welfare.
- Membei.
Menrber.

[F.No. A. I 20 I StOt /2011 -CHS-VI]

GAYATRI MISHRA, Jt. Secy.

Uploaded by Dte. of printing ut Gore.r,

and published by the Conrroller ot. pubticatirlns,

o.it,i iiiioJ+.

'

,OrO,

Disitary siened by

VERMA

re:48:18 +0s,30,

KUMAR H],%lyHL*'"^
