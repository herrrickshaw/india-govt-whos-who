---
doc_id: "f42acacd5af2ba4b"
source_url: "https://master-dolr.digifootprint.gov.in/static/uploads/2025/09/583966c372ca15a952e7bbc1bbcca22f.pdf"
ministry: "Department of Land Resources (DLR)"
title: "Guidelines for the Digital Land Governance Iconic Village and Panchayat Award"
date: "2025-09-19"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "71ccc4af90ccd721"
---

<!-- page 1 -->

Revised Guidelines for the Digital Land Governance Iconic Village & Panchayat
Award

ili Department of Land Resources, under the theme “Village with Good
Governance” plans to give away — Digital Land Governance Iconic Village &
Panchayat Award to local Revenue Officials /Authority shortly, to all Villages where

i. 100% Records of Rights (RoRs) of the village are Computerized,

ii, 100% Cadastral Maps are Digitized and Geo-referenced,

iii 100% (all) land parcels are assigned Unique Land Parcel Identification Number
(ULPIN), and

iv. 100% (all) deeds/documents have been Registered using National Generic

Document Registration System (NGDRS) or equivalent software applications
(which should include basic Eleven (11) NGDRS module as minimum).
2 Following action may be taken up on priority and within timelines:

1. Information in respect of all Villages & Panchayats (Block/Tehsil wise/district
wise alphabetically) which have completed saturation/100% coverage in terms of
the above-mentioned four components in attached format inExcel only should
be sent through email to prasad-upsc@gov.in, neeraj.kumar06@nic.in by
15.04.2022 positively. Since 15.04.2022 may be a Gazetted holiday in many
States/UTs, kindly ensure to send the above information by the assigned date
either on the last working day prior to 15.04.2022 or on the cut off time/date of
5:00 PM of 15.4.2022. This is a time bound exercise and your overview on the
entire exercise is requested so that error free listing is finalized for the prestigious
awards,

i. ACS/PS/Secretary Revenue/Registration (Nodal Officer) of State/UT will certify
and recommend factual information/data in the Excel Sheet(Annexed) and will be
responsible for authenticating. If in future, it is found that wrong/factually incorrect
information had been provided (for any reasons) then the Award will be
cancelled/withdrawn and the matter will be informed to the competent authority in

<!-- page 2 -->

the State/UT Govt; since for all practical purposes, the list of Villages
&Panchayats finalized by ACS/PS/Secretary Revenue would be the basis of the
Award. The State/UT Govt Nodal Officer is requested to maintain highest level of
scrutiny and purity for a zero error recommended list of eligible Villages &
Panchayats to avoid any last minute dispute/cancellation of Award

iii. | The Patwari ( or functionary equivalent) of the village achieving saturation will be
awarded. A Certificate will be presented to the Awardee/Village Patwari.
Similarly, if saturation is achieved in all the villages of the Gram Panchayat then
the Sarpanch or local Panchayat functionary (as the case may be) of the Gram
Panchayat will be presented with Certificate Award, additionally.

iv. A Committee in Department of Land Resources chaired by Secretary, DoLR will
finalize/select the Award winners on the basis of recommendations of State/UT
Govt (ACS/PS/Secretary Revenue/Registration-Nodal Officer). The decision of
the aforesaid Committee will be final and binding

v. Finally selected Awardees will be awarded a Certificate which would be sent
electronically

vi. SI. No.1(i), (ii) and (iii) are self explanatory. With reference to SI. No.1(iv), it is
desired that there are “no deeds/documents pending to be registered” by
15.04.2022. The Eleven(11) modules to be performed online are as follows:

1 - M01 - Configuration Management
2  - M02 - User Management

3. - M03 - Administration

4 - M04 - Appointment for Registration
5 - MOS - Property Valuation

6 - M06 - Public data entry

7 - M07 - Registration

8 - M08 - Dashboard

9 - MO9 - Document Search

10 - M10 - Case Monitoring

11 - M11 - Stamp Duty & fee calculator

<!-- page 3 -->

i. The Award Certificate will be co-signed by Joint Secretary Land Resources
(DoLR) and ACS/PS/Secretary Revenue/Registration-Nodal Officer of State/UT
Govt. It would be our endeavour to mail the final list along with Certificate signed
by Joint Secretary Land Resources (Government of India) by 20" April, 2022.
Hence, all complete recommendations from State/UT Govts necessarily should
reach on or before 15" April, 2022

ii Revenue Department/Registration Department of State/UT Govt are requested to
undertake massive publicity of the Digital Land Governance Iconic Village &
Panchayat Award; as the objective is saturation of computerization and
digitization of land records/maps which will immensely benefit the public
especially rural India
