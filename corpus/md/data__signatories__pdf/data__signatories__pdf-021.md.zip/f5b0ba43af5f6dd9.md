---
doc_id: "f5b0ba43af5f6dd9"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/9a97fa6af8ac6c7a713a6dd1ab3a74b2.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Ms. Nupur Sharma, Gr. 'B' Panel Counsel, Supreme Court: Order dated 21.03.2018"
date: "2018-03-21"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0c545965212c53b4"
---

<!-- page 1 -->

F. No, J-11016/1/2017-Judicial(Part-6)
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
ee
Shastri Bhawan, New Delhi,
Dated 21% March, 2018
ORDER
The President is pleased to engage Ms. Nupur Sharma, Advocate as Group ‘B’
Panel Counsel for conducting Central Government litigation before Supreme Court of
India, as mentioned below, for a period of three years from the date of this order or until
further orders, whichever is earlier:
SUPREME COURT OF INDIA
GROUP ‘B’ PANEL COUNSEL
Name of Contact details Enrollment No. |
Advocate
Ms. Nupur 406, Nilgiri Apartments, 9 Barakhamba D/2494/2010
Sharma Road, New Delhi-110001
Mob: 9711860881
Email: adv.nupursharma@gmail.com
2: The terms & conditions of the engagement of aforesaid Advocate will be governed
by this Department's OM No. 21(4)/99-Judl. dated 24.09.1999 read with OM No.
26(1)/2014/Judl. dated 01.10.2015 & instructions issued subsequently through OMs. The
aforesaid OMs are available on the website of this Department i.e. www.legalaffairs.gov.in
in the tab ‘Judicial Section’ under heading ‘Circulars pertaining to litigations’.
3. Hindi version of this order will follow.
phe aye
IZ. 3
(Inder Kumar)
Additional Secretary
Copy to:-
1. PS to ML&J/PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary/All Additional
Secretaries/PS to all JS&LA in the Main Sectt.
2. PS to Attorney General, PS to Solicitor General, PS to All Addl. Solicitors General
3. The Registrar, Supreme Court of India, New Delhi.
4. The Incharge, Central Agency Section, Supreme Court Compound, New Delhi.
5. All the Branch Secretariats Mumbai, Kolkata, Bengaluru & Chennai.
6. Ms. Nupur Sharma, Group ‘B’ panel counsel, as above.
7. The Pay & Accounts Office, Department of Legal Affairs, New Delhi.
8. One copy of this order is uploaded on website of this Department i.e. www.legalaffairs gov in
under tab ‘Judicial Section’ in the link ‘List of empanelled Counsel’ for the information of all
concerned.
9. Hindi unit, Department of Legal Affairs for Hindi translation of the order. |
10. Guard File/Judicial Section with 5 spare copies. ao _ ok
tC
(D. Srinivas)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
