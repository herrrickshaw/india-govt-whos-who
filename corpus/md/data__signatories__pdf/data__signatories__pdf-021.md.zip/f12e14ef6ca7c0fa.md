---
doc_id: "f12e14ef6ca7c0fa"
source_url: "https://www.legislative.gov.in/static/uploads/2025/06/d91e578574bd2a838a60e604b1531b86.pdf"
ministry: "Legislative Department (LD)"
title: "2018"
date: "2018-03-26"
pages: 52
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1f53886ad3d366f8"
---

<!-- page 1 -->

REGULATIONS 2018

1. The Daman And Diu Municipalities (Amendment) Regulation, 2018
2. The Dadra and Nagar Haveli Municipal Council (Amendment) Regulation, 2018
3. The Andaman And Nicobar Islands (Municipal) Amendment Regulation, 2018

<!-- page 2 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—18

REGISTERED NO. DL—(N)04/0007/2003—18

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 13]

ubZ fnYyh] lkseokj] ekpZ 26] 2018@ pS= 5] 1940 ¼'kd½

No. 13]

NEW DELHI, MONDAY, MARCH 26, 2018/CHAITRA 5, 1940 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 26th March, 2018/Chaitra 5, 1940 (Saka)

THE DAMAN AND DIU MUNICIPALITIES (AMENDMENT)
REGULATION, 2018
NO. 1 OF 2018
Promulgated by the President in the Sixty-ninth Year of the Republic of India.
A Regulation further to amend the Daman and Diu Municipalities Regulation, 1968.
In exercise of the powers conferred by article 240 of the Constitution, the President is
pleased to promulgate the following Regulation made by him:—
1. (1) This Regulation may be called the Daman and Diu Municipalities (Amendment)
Regulation, 2018.
(2) It shall come into force at once.
Reg. 7 of
1969.

2. Throughout the Daman and Diu Municipalities Regulation, 1968 (hereinafter referred
to as the principal Regulation), for the words “servant” and “servants”, wherever they occur,
the words “employee” and “employees” shall respectively be substituted, and such other
consequential amendments as the rules of grammar may require shall also be made.

Short title
and
commencement.
Substitution
of reference
of certain
expressions by
certain other
expressions.

<!-- page 3 -->

2
Amendment
of section 1.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

3. In section 1 of the principal Regulation, for sub-section (2), the following
sub-section shall be substituted, namely:—
“(2) It extends to the whole of the Union territory of Daman and Diu.”.

Amendment
of section 2.

4. In section 2 of the principal Regulation, for clause (33), the following clause shall
be substituted, namely:––
‘(33) “officer or employee of the Council” means an officer or employee appointed
by the Chief Officer or the Government and includes any Government officer or employee
who is for the time being serving under the Council;’.

Amendment
of section 9A.

5. In section 9A of the principal Regulation,––
(i) in sub-section (2), for the word “one-third”, the word “one-half” shall be
substituted;
(ii) in sub-section (3), for the word “one-third”, the word “one-half” shall be
substituted.

Amendment of
section 13.

6. In section 13 of the principal Regulation,––
(i) in sub-section (1), after the words “by ballot”, the words “or by Electronic
Voting Machine” shall be inserted;
(ii) after sub-section (2), the following sub-section shall be inserted, namely:––
‘(3) Notwithstanding anything contained in this Regulation or the rules
made thereunder, the giving or recording of vote by Electronic Voting Machine
may be adopted in such ward or wards of the Council as the Election Commission
may, having regard to the circumstances of each case, specify.
Explanation.—For the purposes of this section, “Electronic Voting
Machine” means any machine or apparatus whether operated electronically or
otherwise, used for giving or recording of vote and any reference to a ballot box
or ballot paper in this Regulation or the rules made thereunder shall, save as
otherwise provided, be construed as including a reference to such Electronic
Voting Machine wherever such Electronic Voting Machine is used at any
election.’.

Amendment
of section 16.

7. In section 16 of the principal Regulation, in sub-section (1), after clause (l), the
following clauses shall be inserted, namely:––
“(m) is so disqualified by or under any law for the time being in force for the
purposes of election to the House of the People; or
(n) is disqualified on ground of defection under Schedule X.”.

Amendment
of section 23.

8. In section 23 of the principal Regulation, in sub-section (3), the following proviso
shall be inserted, namely:––
“Provided that no symbol allotted under this Regulation to a candidate shall
be deemed to be a religious symbol or a national symbol for the purposes of this
sub-section.”.

Substitution
of new
section for
section 24.

9. For section 24 of the principal Regulation, the following section shall be substituted,
namely:––

Prohibition of
public
meeting
during period
of forty-eight
hours ending
with hour
fixed for
conclusion of
poll.

‘24. (1) No person shall––
(a) convene, hold or attend, join or address any public meeting or
procession in connection with an election; or
(b) display to the public any election matter by means of cinematograph,
television or other similar apparatus; or
(c) propagate any election matter to the public by holding, or by arranging
the holding of, any musical concert or any theatrical performance or any other
entertainment or amusement with a view to attracting the public thereto,
in any polling area during the period of forty-eight hours ending with the hour fixed for the
conclusion of the poll for any election.

<!-- page 4 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

(2) Any person who contravenes the provisions of sub-section (1) shall, on
conviction, be punished with imprisonment for a term which may extend to two years,
or with fine, or with both.
Explanation.—For the purposes of this section, the expression “election matter” means
any matter intended or calculated to influence or affect the result of an election.’.
10. In section 25 of the principal Regulation, in sub-section (2), for the words “with
fine which may extend to two hundred and fifty rupees”, the following shall be substituted,
namely:––

Amendment
of section 25.

“with imprisonment for a term which may extend to six months, or with fine which
may extend to two thousand rupees or with both”.
11. In section 51 of the principal Regulation,––
(i) in sub-section (3), in clause (u), for the letters, figures and words “Rs. 200 and
the total expenditure during the year does not exceed Rs.1000”, the words “such
amount as may be notified in the Official Gazette by the Government and the total
expenditure during the year does not exceed such amount as may be notified in the
Official Gazette by the Government” shall be substituted;
5 of 1898.
2 of 1974.

Amendment
of section 51.

(ii) in sub-section (5), in clause (a), for the words, letters and figures “Chapter
XXXIV of the Code of Criminal Procedure, 1898”, the words, letters and figures “Chapter
XXV of the Code of Criminal Procedure, 1973” shall be substituted.
12. In section 52 of the principal Regulation,––
(i) for sub-section (2), the following sub-section shall be substituted, namely:—

Amendment
of section 52.

“(2) On the constitution of a Council under this Regulation, the Collector
shall convene a special meeting of the Councillors for election of a President and
a Vice-President in such manner as may be prescribed,”;
(ii) sub-section (3), sub-section (4) and sub-section (5) shall be omitted;
(iii) for sub-section (8), the following sub-section shall be substituted, namely:—
“(8) If there is a vacancy in the office of the President or Vice-President
due to any reason whatsoever, the vacancy shall be filled at the same procedure
as provided in sub-section (2).”.
13. In section 54 of the principal Regulation, in sub-section (2), for the word “receipt”,
the word “acceptance” shall be substituted.
14. In section 56 of the principal Regulation,—
(i) in sub-section (1), the following proviso shall be inserted, namely:—
“Provided that no such resolution shall be moved within a period of
six months from the date of the assumption of office by the President or
Vice-President, as the case may be.”;
(ii) in sub-section (2), for the word “one-fourth”, the word “one-third” shall be
substituted;
(iii) in sub-section (3), for the word “Director”, wherever they occur, the word
“Collector” shall be substituted.
(iv) for sub-section (4), the following shall be substituted, namely:—
“(4) Every President or Vice-President of the Council may be removed
from his office if a resolution of the Council expressing want of confidence in him
is passed by a majority of the total members of the Council present at a meeting
specially convened for the purpose:

Amendment
of section 54.
Amendment
of section 56.

<!-- page 5 -->

4

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

Provided that no such resolution shall be moved unless,—
(a) a notice of the intention to move the resolution has been given
within such period as may be prescribed and signed by a majority of
one-third of members of the Council; and
(b) it contains a proposal for election of a new President or
Vice-President of the Council.
(5) At any meeting of the Council, while any resolution for removal of the
President from his office is under consideration, the President, or while any
resolution for removal of the Vice-President from his office is under consideration,
the Vice-President, shall not, though he is present, preside.
(6) The meeting shall be presided over by the Vice-President if the motion
is against the President and by the President if the motion is against the
Vice-President.
(7) At any meeting of the Council, while any resolution for electing a
successor to the office of the President is under consideration, the candidate to
the office of the President, or while any resolution for electing a successor to the
office of the Vice-President is under consideration, the candidate to the office of
the Vice-President, shall not, though he is present, preside.
(8) The President or Vice-President shall have right to speak in, and
otherwise to take part in the proceeding of such meeting of, the Council while
any resolution for removal from his office is under consideration in the Council
and shall be entitled to vote only in the first instance on such resolution or on
any other matter during such proceeding but not in the case of an equality of
votes.
(9) The provisions of sub-sections (6), (7) and (8) shall apply mutatis
mutandis to the person contesting the election for the post of President or
Vice-President of the Council.
(10) The procedure to be followed for the meeting shall be such as may be
prescribed.”.
Amendment
of section 58.

15. In section 58 of the principal Regulation, in sub-section (4), for the words
“two thousand rupees”, the words “five thousand rupees” shall be substituted.

Amendment
of section 59.

16. In section 59 of the principal Regulation, in sub-section (1), in clause (d), for the
words “servants of the Council”, the words “employees of the Council through Chief Officer”
shall be substituted.

Amendment
of section 63.

17. In section 63 of the principal Regulation,—
(a) in sub-section (1), for the words “appoint such Subjects Committees”, the
words “appoint not more than three Subjects Committees” shall be substituted;
(b) in sub-section (2), after the word “Councillors”, the words “or five members
whichever is more” shall be inserted;
(c) in sub-section (3), for the words “five members, as it may determine”, the
words “three members” shall be substituted;
(d) in sub-section (4),—
(i) in clause (a), after the words “Standing Committee”, the words “and
allocating one or more than one subject to the Standing Committee and Subjects
Committees” shall be inserted;

<!-- page 6 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

5

(ii) for clause (b), the following clause shall be substituted, namely:—
“(b) determining the number of member of the Subjects Committee
or Committees, if any, to be appointed, and if more than one such
Committees are to be appointed, the Subjects Committees of which the
Vice-President shall be ex officio Chairman.”;
(iii) in clause (c), the following proviso shall be inserted, namely:—
“Provided that no Councillor shall be eligible to be elected to more
than one Subjects Committees.”.
18. In section 64 of the principal Regulation,––
(a) for the words “the last preceding section”, the word and figures “section 63”
shall be substituted;

Amendment
of section 64.

(b) in clause (c), after the words “elected by the Councillors”, the words “excluding
President, Vice-President and members of any Subjects Committee or Committees”
shall be inserted;
(c) proviso shall be omitted.
19. For section 65 of the principal Regulation, the following section shall be substituted,
namely:––

Substitution
of new
section for
section 65.

“65. A Council may, from time to time, refer to a Subjects Committee appointed
under section 63 such special subjects or matters relating to the purposes of this
Regulation, for opinion or inquiry as the Council may think fit and it may direct such
Subjects Committee to submit its report either to it or to the Standing Committee.”.

Reference of
special
subjects or
matters to
Subjects
Committee.

20. For section 68 of the principal Regulation, the following section shall be substituted,
namely:––

Substitution
of new
section for
section 68.

“68. Each Council shall make bye-laws specifying the powers to be exercised by
the Standing Committee and the Subjects Committees, if any, including the subjects to
be allotted to such Committees.”.

Powers of
Standing
Committees
and Subjects
Committees.

21. In section 69 of the principal Regulation, for the words, letters and figures “not
exceed Rs.50,000 and Rs.10,000 respectively”, the words “not exceed such amount as may be
notified in the Official Gazette by the Government” shall be substituted.

Amendment
of section 69.

22. In section 72 of the principal Regulation,––
(i) in sub-section (4), for the word “Council”, the word “Government” shall be
substituted;

Amendment
of section 72.

(ii) in sub-section (5), in clause (b), the words, brackets, letters and figures
“, whose minimum salary (exclusive of allowance) is not less than Rs.225/- per month”
shall be omitted.
23. For section 73 of the principal Regulation, the following section shall be substituted,
namely:––
“73. (1) A Council may, with the sanction of the Director, create such post
of officers and employees other than those specified in sub-sections (1) and (2) of
section 72 as it shall deem necessary for efficient execution of its duties under this
Regulation.
(2) The qualifications, pay, allowances, and other conditions of service and
method of recruitment of any such officers and employees shall, by general or special
order, be made by the Government in this behalf.

Substitution of
new section
for section 73.
Appointment
of other
officers and
employees.

<!-- page 7 -->

6

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(3) The power of making appointment to any post referred to in sub-section (1)
shall vest in the Chief Officer with the prior approval of the Director.”.
Amendment
of section 74.

24. In section 74 of the principal Regulation, in sub-section (1),––
(i) in clause (a), for the word “President”, the word “Council” shall be substituted;
(ii) in clause (b), after the word “Council”, the following shall be inserted,
namely:—
“and the Standing Committee:
Provided that if it appears to the Chief Officer that any decision or resolution
is against public interest or harmony, or is otherwise ultra vires, he shall refer the
decision or resolution to the Collector for clarification or decision, and after a
clarification or decision in this regard is received from the Collector, unless
otherwise directed to do so in writing by the Collector, the Chief Officer shall
implement the decision or resolution;”;
(iii) after clause (h), the following clause shall be inserted, namely:––
“(i) undertake such minor repair or maintenance work as may be notified in
the Official Gazette by the Government within the financial limits.”.

Amendment
of section 75.

25. In section 75 of the principal Regulation, for the words “Standing Committee”, the
words “Chief Officer” shall be substituted.

Substitution of
new section
for section 76.

26. For section 76 of the principal Regulation, the following section shall be substituted,
namely:––

Punishment of
officers and
employees.

“76. (1) Without prejudice to the provisions of any law for the time being in
force, the following penalties may, for good reasons, be imposed upon any officer or
employee of the Council,––
(a) minor penalties—
(i) censure;
(ii) withholding of promotion;
(iii) recovery from his pay of the whole or part of any pecuniary
loss caused by him to the Council by negligence or breach of orders;
(iv) withholding of increments of pay;
(b) major penalties—
(i) reduction to a lower post on a fixed pay or a time scale or to a
lower stage in a time scale;
(ii) removal from the service, which does not disqualify from future
employment;
(iii) dismissal from the service, which ordinarily disqualifies from
future employment.
(2) The major penalties mentioned in clause (b) of sub-section (1) may be imposed
on an officer or employee of the Council by the authority competent to make the
appointment of the officer or employee:
Provided that the minor penalties mentioned in clause (a) of sub-section (1) may
be imposed on an officer other than an officer belonging to the common cadre specified
in sub-section (5) of section 72 or an employee of the Council, by the Chief Officer:
Provided further that suspension of an officer or employee pending inquiry into
the allegations against such officer or employee shall not be deemed to be a penalty
and shall be ordered only by the authority competent to make appointment to the post
held by such officer or employee.
(3) No officer or employee shall be imposed major penalties mentioned in
clause (b) of sub-section (1) unless he has been given a reasonable opportunity of
showing cause against such penalties:

<!-- page 8 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

7

Provided that this sub-section shall not apply where a person is reduced, removed
or dismissed on the ground of conduct which has led to his conviction on a criminal
charge.
(4) No major penalty mentioned in clause (b) of sub-section (1) shall be imposed
on any officer or employee appointed under sub-section (3) of section 73 without the
prior approval of the Director.
(5) In every case referred to the Director under sub-section (4), the Director shall
not refuse to give his approval unless he is satisfied that––
(i) the finding at the inquiry is perverse; or
(ii) the major penalty imposed is severe.
(6) Where the Director informs the Chief Officer that the finding at the inquiry is
perverse, no further proceeding shall be taken against the officer or employee concerned
in respect of the same matter.
(7) An appeal against any order imposing any penalty mentioned in
sub-section (1) may be made—
(i) in case if an order imposing any minor penalty mentioned in clause (a)
of sub-section (1), to the Director;
(ii) in case if an order imposing any major penalty mentioned in clause (b)
of sub-section (1), to the authority specified in this behalf by the Administrator
by an order.
(8) No such appeal may be entertained if not preferred within one month from the
date of receipt of the order appealed against by the officer or employee concerned.
(9) The appellate authority referred to in sub-section (7), within six months of
the date of the order passed, may at any time, either on his or its own motion or
otherwise, call for the records of any inquiry and revise any order made for reduction
to a lower post or rank or removal or dismissal from the service, and may—
(i) confirm, modify, reduce, enhance or set aside the order; or
(ii) remit the case to the authority which made the order to or any other
authority directing such authority to make such further enquiry as he or it may
consider proper in the circumstances of the case; or
(iii) pass such orders as he or it may deem fit.
(10) The Administrator may, at any time, either on his own motion or otherwise,
review any order passed under this section, when any new material or evidence which
could not be produced or was not available at the time of passing the order under
review and which has the effect of changing the nature of the case, has come, or has
been brought, to his notice.”.
27. After section 77 of the principal Regulation, the following Chapter shall be inserted,
namely:––

Insertion of
new Chapter
VA.

“CHAPTER VA
OMBUDSMAN FOR COUNCIL
77A. (l) The Government shall, by notification in the Official Gazette, establish
an authority to be known as the Ombudsman for making investigations and inquiries,
in respect of charges on any action involving corruption or maladministration or
irregularities in the discharge of administrative functions by the members of the Council
under this Regulation:
Reg. 4 of 2012.

Provided that the Government may designate the Ombudsman appointed under
the Daman and Diu Panchayat Regulation, 2012 to discharge the functions of the
Ombudsman under this Regulation.

Establishment,
term of office
and conditions
of service of
Ombudsman.

<!-- page 9 -->

8

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(2) The Ombudsman shall consist of one member to be appointed by the
Administrator, on the recommendation of a Committee referred to in sub-section (4).
(3) The Ombudsman shall not be a Government employee.
(4) The Committee referred to in sub-section (2) shall comprise of the following,
namely:––
(a) Director, Municipal Administration of Daman and Diu;
(b) a retired District Judge;
(c) a retired civil employee who has held a post in the Central Government
or State Government not below the rank of a Joint Secretary to the Government
of India; and
(d) two persons of impeccable integrity from the civil society nominated
by the Administrator.
(5) A person appointed to be the Ombudsman shall, before he enter upon his
office, make and subscribe before the Administrator or any other officer appointed in
that behalf by him, an oath or affirmation according to the form set out below:––
‘I, A. B. having been appointed as the Ombudsman for the
__________________ Council under the Daman and Diu Municipalities
Regulation, 1968, do swear in the name of God / Solemnly affirm that I will bear
true faith and allegiance to the Constitution of India and I will duly and faithfully
and to the best of my ability, knowledge and judgment perform the duties of my
office without fear or favour, affection or ill-will’.
(6) A person appointed as Ombudsman shall hold office for a term of three years
from the date on which he enters upon his office:
Provided that––
(a) the Ombudsman may, by writing under his hand addressed to the
Administrator, resign his office; and
(b) the person appointed as Ombudsman may be removed from his office
in the manner provided in section 77B.
(7) The salary and allowance payable to, and the other terms and conditions of
service of, the Ombudsman shall be such as may be prescribed.
(8) On expiry of his term of office as Ombudsman, he shall not be eligible for
re-appointment as Ombudsman or for further appointment to any office under the
Union territory Administration or in any corporation, company, society or university
by or under the control of the Union territory Administration.
Removal of
Ombudsman.

77B. (1) The Ombudsman may be removed from his office, by an order of the
Administrator, on the ground of proved misbehaviour or incapacity.
(2) The procedure for the removal of the Ombudsman under sub-section (1) and
for the investigation and proof of the misbehaviour or incapacity of the Ombudsman
shall be such as may be prescribed.

Staff of
Ombudsman.

77C. (1) The Government may, in consultation with the Ombudsman, provide the
officers and staff to assist the Ombudsman in the discharge of his functions under this
Regulation.
(2) The salaries, allowances and other conditions of service of the officers and
staff provided to the Ombudsman shall be such as may be prescribed.
(3) The Ombudsman may require the assistance of any officer of any Government
Department in order to ascertain the veracity of an allegation under investigation and
such officer shall be bound to render such assistance in addition and without detriment,
to his official duties.

Reg. 7 of 1969.

<!-- page 10 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

9

(4) The Ombudsman may utilise the services of any person having experience
and expertise in any particular subject in deciding the questions before it.
77D. (1) The Ombudsman shall perform all or any of the following functions,
namely:––

Functions of
Ombudsman.

(i) investigate into any allegation contained in a complaint or on a reference
from the Government, or that has come to the notice of the Ombudsman;
(ii) inquire into any complaint in which corruption or maladministration of
a member or a Council is alleged;
(iii) pass an order on the allegation in the following manner, namely:––
(a) where the irregularity involves a criminal offence committed by
a member of the Council, the matter shall be referred to the appropriate
authority for investigation;
(b) where the irregularity causes loss or inconvenience to a citizen,
direct the Council to give him compensation and to reimburse the loss
from the person responsible for such irregularity;
(c) where the irregularity involves loss or waste or misuse of the
fund of the Council, realise such loss from those who are responsible for
such irregularity; and
(d) where the irregularity is due to omission or inaction, cause to
supply the omission and to rectify the mistake.
(2) In addition to the functions enumerated in sub-section (1), the Ombudsman
may pass interim order restraining the Council from doing anything detrimental to the
interest of the complainant if it is satisfied that much loss or injury shall be caused to
the complainant due to the alleged act.
(3) The Ombudsman may, if it is of opinion that the irregularity involves corrupt
practice for personal gain, by order impose penalty in addition to compensation.

5 of 1908.

77E. (1) The Ombudsman shall, for the purpose of any investigation or inquiry
under this Regulation, have the same powers as are vested in a civil court while trying
a suit under the Code of Civil Procedure, 1908 in respect of the following matters,
namely:––
(a) summoning and enforcing the attendance of any witness and examining
him on oath;
(b) requiring the discovery and production of any document;
(c) receiving evidence on affidavits;
(d) requisitioning any public record or document or copy of such record
or document from any office;
(e) issuing commissions for the examination of witness or documents; and
(f) any other matter which may be prescribed.
(2) Where the Ombudsman finds that the allegation contained in a complaint is
without any substance or trivial in nature, it may, by order, direct the complainant to
pay to the opposite party so much of the amount specified in the order by way of cost.
(3) Where the allegation contained in a complaint is about the loss or waste or
misapplication of the fund of the Council or in respect of the loss or inconvenience
caused to a citizen, the Ombudsman may, during inquiry, collect evidence, determine
the loss and direct in its order the amount to be realised from the person responsible.
(4) If the amount payable as per the order passed by the Ombudsman under
sub-section (2) or sub-section (3) is not paid within the period specified by it, the same
shall be recoverable as if it were an arrears of land revenue.

Powers of
Ombudsman.

<!-- page 11 -->

10

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

Service of
Government
Departments.

77F. The Government may, at the request of the Ombudsman, make available the
services of officers and employees of the Government including police personnel to
assist the Ombudsman in the conduct of investigation and inquiry, and in respect of
such functions, such officer or employee shall be deemed to be the officer or employee
of the Ombudsman.

Investigation.

77G. (l) The Ombudsman may, in accordance with the provisions of this
Regulation, investigate into any complaint filed before it under this Regulation.
(2) Notwithstanding anything contained in this Regulation, the Government
may refer any allegation of corruption or maladministration against a Council or a
member of the Council which is within its knowledge or brought to its notice, to the
Ombudsman and the Ombudsman shall investigate into it as if, it was a complaint filed
under this Regulation.
(3) The Ombudsman may, on receipt of a complaint, conduct an investigation in
the matter and where there is a prima facie case it may conduct a detailed inquiry
under section 77H.
(4) The Ombudsman shall not investigate or inquire into matters relating to,––
(a) any matter in respect of which a formal and public inquiry has been
ordered by the Government;
(b) any matter in respect of which a remedy is available from the Court for
Council;
(c) any matter in respect of which an inquiry has been ordered under the
Commission of Inquiries Act, 1952 or any matter pending before a Court;
(d) any complaint filed after the expiry of three years from the date on
which the matter complained against have taken place:
Provided that the Ombudsman may entertain such complaint, if the
complainant satisfies that he had sufficient reason for not filing the complaint
within the specified period.

Inquiry.

77H. (1) After an investigation, if the Ombudsman is satisfied that––
(a) the complaint is frivolous or vexatious or is not made in good faith; or
(b) there is no sufficient ground to initiate proceedings; or
(c) other remedies are available to the complainant and it shall be more
beneficial for the complainant to avail of such remedies in view of the
circumstances of the case,
it may, after recording its findings and stating the reason therefor, dispose of the
complaint and communicate the same to the complainant.
(2) If the Ombudsman is of the opinion that there is a prima facie case against a
member of the Council complained of, it shall record its findings to this effect and send
notices of the proposed inquiry to the complainant and to the opposite party.
(3) Subject to the provisions of this Regulation and rules made thereunder, the
Ombudsman shall regulate its own procedure for the purpose of holding its meeting
(including time and place of sitting).
(4) In any proceeding before the Ombudsman, no legal practitioner shall be
permitted to represent any person, unless the Ombudsman by an order, for the reasons
to be recorded, permits a person to be represented by a legal practitioner.

Existing cases
to be
transferred to
Ombudsman.

77-I. (1) Notwithstanding anything contained in any other law for the time being
in force, any proceeding relating to a member of the Council which is pending before
any authority under this Regulation before the establishment of the Ombudsman
under sub-section (1) of section 77A, shall, on such establishment, be transferred to
the Ombudsman and the Ombudsman shall decide the proceedings in accordance with
the provisions of this Regulation.

60 of 1952.

<!-- page 12 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

11

(2) All cases, with regard to the loss, wastage and misappropriation of any land
of the Local Self Government Institution, pending before the Government or any other
authority shall be transferred to the Ombudsman and the Ombudsman shall dispose of
the proceedings in accordance with the provisions of this Regulation.
77J. (1) If, after an investigation or inquiry, the Ombudsman finds that there is a
prima facie case against the accused, the Ombudsman may, for the reasons to be
recorded in writing, refer the complaint to a competent authority to initiate prosecution.

Initiation of
prosecution.

(2) The competent authority referred to in sub-section (1) shall conduct a detailed
inquiry, and if necessary, shall frame the charge.
77K. (1) The Ombudsman may consider and dispose of complaints other than
those involving criminal offences in the following manner, namely:––

Disposal of
complaints.

(i) award of compensation to a citizen in case of loss or grievance;
(ii) order the recovery of loss caused to the Council from the person
responsible;
(iii) order the supply of omission or rectification of defects due to inaction;
(iv) order the recovery of loss from the accused failing which, order
realisation through revenue recovery proceedings; and
(v) order other necessary remedial measures considering the facts and
circumstances of the case.
(2) Where the Ombudsman finds that the procedure or practice regarding the
administration of the Council gives room for complaint, it may give suggestions to the
Government or the Council relating to the measures for avoiding the recurrence of
such complaint.
(3) The Ombudsman shall give annually a detailed report regarding the
performance of its functions under this Regulation to the Government.
77L. (1) The Government may make rules to carry out the provisions of this
Chapter.
(2) In particular, and without prejudice to the generality of the foregoing power,
such rules may provide for all or any of the following matters, namely:––

Power to
make rules
under this
Chapter.

(a) the salary and allowances payable to, and other terms and conditions
of service of, the Ombudsman under sub-section (7) of section 77A;
(b) the procedure for the removal of the Ombudsman and investigation of
proof of the misbehavior or incapacity under sub-section (2) of section 77B;
(c) the salary and allowances payable to, and other terms and conditions
of service of, the officers and staff provided to the Ombudsman under
sub-section (2) of section 77C; and
(d) any other matter which is required to be or may be prescribed.”.
28. In section 81 of the principal Regulation, in sub-section (2), for the word “President”,
wherever it occurs, the word “Director” shall be substituted.

Amendment
of section 81.

29. In section 86 of the principal Regulation, in sub-section (2), in clause (f), after the
word and figures “section 72”, the following shall be inserted, namely:––
“and the officers belonging to the Government Department posted on deputation
to the Council”.

Amendment
of section 86.

30. In section 89 of the principal Regulation,––
(i) in sub-section (2), in clause (c), for the words, letters and figures “an expenditure
exceeding Rs.1500”,the words “an expenditure exceeding such amount as may be
notified in the Official Gazette by the Government” shall be substituted;

Amendment
of section 89.

<!-- page 13 -->

12

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(ii) in sub-section (3), in clause (b), for the words “exceeding five hundred
rupees shall be in writing and shall be sealed with the common seal of the Council”, the
words “exceeding such amount as may be notified in the Official Gazette by the
Government, shall be in writing” shall be substituted;
(iii) in sub-section (6),––
(a) for the words “one thousand rupees give notice by advertisement in a
local newspaper, inviting tenders for such contract”, the following shall be
substituted, namely:––
“such amount as may be notified in the Official Gazette by the
Government give notice by advertisement, inviting tenders for such
contract and follow the procedure laid down by the Government”;
(b) in the proviso, the words “in the newspaper” shall be omitted.
Amendment of
section 101.

31. In section 101 of the principal Regulation, in sub-section (1), in clause (a), after the
words “municipal area”, the words “other than those belonging to the Government or Central
Government,” shall be inserted.

Amendment of
section 104.

32. In section 104 of the principal Regulation, in clause (a), for the words and figures
“Motor Vehicles Act, 1939”, the words and figures “Motor Vehicles Act,1988” shall be
substituted.

Amendment of
section 108.

33. In section 108 of the principal Regulation, in sub-section (1), in the proviso, in
clause (b), the words “increase or” shall be omitted.

Amendment of
section 125.

34. In section 125 of the principal Regulation, in sub-section (3), for the words “fifty
rupees”, the words “two thousand rupees” shall be substituted.

Amendment of
section 162.

35. In section 162 of the principal Regulation, in the second proviso, for the words
“one hundred rupees”, the words “fifty thousand rupees” shall be substituted.

Amendment of
section 174.

36. In section 174 of the principal Regulation,––
(i) in sub-section (2), for the words “fine which may extend to one hundred
rupees, and in the case of a continuing contravention with further fine which may
extend to twenty rupees”, the following shall be substituted, namely:––
“simple imprisonment for a term which may extend to six months and fine
which may extend to fifty thousand rupees, and in the case of a continuing
contravention with further fine which may extend to five hundred rupees”;
(ii) in sub-section (8),––
(a) for the words “one hundred rupees”, the words “fifty thousand rupees”
shall be substituted;
(b) for the words “twenty rupees”, the words “five hundred rupees” shall
be substituted.

Amendment of
section 175.

37. In section 175 of the principal Regulation, in sub-section (7), for the words “with
fine which may extend to one hundred rupees and in the case of a continuing offence with
further fine which may extend to twenty rupees”, the following shall be substituted, namely:—
“with simple imprisonment for a term which may extend to six months and fine
which may extend to fifty thousand rupees and in the case of a continuing offence with
further fine which may extend to five hundred rupees”.

Amendment of
section 176.

38. In section 176 of the principal Regulation, in sub-section (3), for the words “with
fine which may extend to one hundred rupees, and in the case of continuing offence with
further fine which may extend to twenty rupees”, the following shall be substituted, namely:—
“with simple imprisonment for a term which may extend to three months and fine
which may extend to fifty thousand rupees and in the case of continuing offence with
further fine which may extend to five hundred rupees”.

IV of 1939.
59 of 1988.

<!-- page 14 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

13

39. In section 178 of the principal Regulation, in sub-section (6), for the words
“one thousand rupees”, the words “ten thousand rupees” shall be substituted.

Amendment
of section 178.

40. In section 180 of the principal Regulation, in sub-section (2), for the words
“fifty rupees”, the words “ten thousand rupees” shall be substituted.

Amendment
of section 180.

41. In section 181 of the principal Regulation, in sub-section (3), for the words
“one hundred rupees”, the words “ten thousand rupees” shall be substituted.

Amendment
of section 181.

42. In section 182 of the principal Regulation, in sub-section (2), for the words
“fifty rupees”, the words “five thousand rupees” shall be substituted.

Amendment
of section 182.

43. In section 183 of the principal Regulation, in sub-section (2), for the words
“fifty rupees”, the words “five thousand rupees” shall be substituted.

Amendment
of section 183.

44. In section 184 of the principal Regulation,––
(i) in sub-section (9), for the words “with fine which may extend to
five thousand rupees”, the following shall be substituted, namely:––

Amendment
of section 184.

“with simple imprisonment for a term which may extend to six months and
fine which may extend to one lakh rupees”;
(ii) in sub-section (10), for the words “twenty-five rupees”, the words
“five thousand rupees” shall be substituted.
45. In section 187 of the principal Regulation, in sub-section (5),—
(i) for the words “one hundred rupees”, the words “ten thousand rupees” shall
be substituted;

Amendment
of section 187.

(ii) for the words “ twenty-five rupees”, the words “five hundred rupees” shall
be substituted.
46. In section 188 of the principal Regulation, in sub-section (3), in clause (b), for the
words “with fine which may extend to five hundred rupees, and in the case of continuing
contravention or non-compliance with further fine which may extend to twenty-five rupees”,
the following shall be substituted, namely:––

Amendment
of section 188.

“with simple imprisonment for a term which may extend to six months and fine
which may extend to one lakh rupees and in the case of continuing contravention or
non-compliance with further fine which may not be less than one thousand rupees”.
47. In section 189 of the principal Regulation, in sub-section (2),—

Amendment
of section 189.

(i) for the words “five hundred rupees”, the words “fifty thousand rupees” shall
be substituted;
(ii) for the words “ten rupees”, the words “five hundred rupees” shall be
substituted.
48. In section 197 of the principal Regulation,––
(i) in sub-section (1), in clause (a), for the words “fifty feet”, the words
“fifty meter” shall be substituted;
(ii) after sub-section (2), the following sub-section shall be inserted, namely:––
“(2A) Notwithstanding anything contained in any provision of this
Regulation, the owner of any building shall connect such building to the sewage
in the area where underground sewage system exists, failing which, the Chief
Officer may, by notice in writing, direct the owner of such building to connect
the building to the underground sewage within such period as may be specified
in the notice.”;

Amendment
of section 197.

<!-- page 15 -->

14

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(ii) for sub-section (3), the following sub-section shall be substituted, namely:—
“(3) Whoever fails to comply with the notice issued by the Chief Officer
under sub-section (1) or sub-section (2) or sub-section (2A), as the case may be,
he shall be punished with fine which may extend to fifty thousand rupees and in
case of continuing offence with further fine which may extend to five hundred
rupees for every day after the first during which such offence continues.”.
Amendment
of section 205.

49. In section 205 of the principal Regulation, in sub-section (3), for the words “with
fine which may extend to one hundred rupees”, the following shall be substituted, namely:—
“with imprisonment which may extend to three months and fine which may
extend to fifty thousand rupees and in the case of continuing contravention with
further fine which may extend to five hundred rupees for every day after the first
during which such contravention continues”.

Amendment
of section 206.

50. In section 206 of the principal Regulation, in sub-section (2), for the words “with
fine which may extend to one hundred rupees”, the following shall be substituted, namely:—
“with imprisonment which may extend to three months and fine which may
extend to fifty thousand rupees and in the case of continuing contravention with
further fine which may extend to five hundred rupees for every day after the first
during which such contravention continues.”.

Amendment
of section 210.

51. In section 210 of the principal Regulation,––
(i) in sub-section (4), for the words “one hundred rupees”, the words
“five thousand rupees” shall be substituted;
(ii) in sub-section (7), for the words “three hundred rupees”, the words
“fifteen thousand rupees” shall be substituted.

Amendment
of section 211.
Amendment
of section 212.

52. In section 211 of the principal Regulation, in sub-section (2), for the words
“one hundred rupees”, the words “five thousand rupees” shall be substituted.
53. In section 212 of the principal Regulation, in sub-section (2),—
(i) for the words “fifty rupees”, the words “ten thousand rupees” shall be
substituted;
(ii) for the words “five rupees”, the words “five hundred rupees” shall be
substituted.

Amendment
of section 218.
Amendment
of section 220.

54. In section 218 of the principal Regulation, in sub-section (2), for the words
“two hundred and fifty rupees”, the words “ten thousand rupees” shall be substituted.
55. In section 220 of the principal Regulation, in sub-section (2),—
(i) for the words “fifty rupees”, the words “ten thousand rupees” shall be
substituted;
(ii) for the words “ten rupees”, the words “five hundred rupees” shall be
substituted.

Amendment
of section 221.

56. In section 221 of the principal Regulation, in sub-section (2),—
(i) for the words “five hundred rupees”, the words “one lakh rupees” shall be
substituted;
(ii) for the words “twenty-five rupees”, the words “one thousand rupees” shall
be substituted.

Amendment
of section 223.

57. In section 223 of the principal Regulation,––
(a) in sub-section (1),––
(i) after the words “other rubbish”, the words “or garbage” shall be inserted;
(ii) for the words “one hundred rupees”, the words “ten thousand rupees”
shall be substituted;

<!-- page 16 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

15

(b) in sub-section (2), for the words “with fine which may extend to one hundred
rupees”, the following shall be substituted, namely:––
“with simple imprisonment for a term which may extend to one month and
fine which may extend to ten thousand rupees.”.
58. In section 224 of the principal Regulation, for the words “with fine which may
extend to one hundred rupees”, the words “with simple imprisonment for a term which may
extend to one month and fine which may extend to ten thousand rupees” shall be substituted.
59. In section 225 of the principal Regulation,––
(i) for the words “one hundred rupees”, the words “ten thousand rupees” shall
be substituted;

Amendment
of section 224.

Amendment
of section 225.

(ii) for the words “twenty rupees”, the words “five hundred rupees” shall be
substituted.
60. Section 226 of the principal Regulation shall be omitted.
61. In section 227 of the principal Regulation, for the words “one hundred rupees”,
the words “ten thousand rupees” shall be substituted.
62. In section 230 of the principal Regulation, in sub-section (2),––
(i) for the words “one hundred rupees”, the words “ten thousand rupees” shall
be substituted;

Omission
of section 226.
Amendment
of section 227.
Amendment
of section 230.

(ii) for the words “ten rupees”, the words “five hundred rupees” shall be
substituted.
63. In section 240 of the principal Regulation,––
(i) in sub-section (1),––

Amendment
of section 240.

(a) for the words “two hundred rupees”, the words “ten thousand rupees”
shall be substituted;
(b) for the words “twenty rupees”, the words “five hundred rupees” shall
be substituted;
(ii) in sub-section (2),––
(a) for the words “one thousand rupees”, the words “fifty thousand
rupees” shall be substituted;
(b) for the words “fifty rupees”, the words “one thousand rupees” shall be
substituted.
64. In section 243 of the principal Regulation, in sub-section (5), for the words “ten
rupees”, the words “five thousand rupees” shall be substituted.

Amendment
of section 243.

65. In section 245 of the principal Regulation, in sub-section (3), for the words “five
hundred rupees”, the words “fifty thousand rupees” shall be substituted.

Amendment
of section 245.

66. In section 247 of the principal Regulation, in sub-section (3), for the words “two
hundred and fifty rupees”, the words “ten thousand rupees” shall be substituted.

Amendment
of section 247.

67. In section 248 of the principal Regulation, in sub-section (2), for the words “one
hundred rupees”, the words “five thousand rupees” shall be substituted.

Amendment
of section 248.

68. In section 252 of the principal Regulation, for sub-section (2), the following
sub-section shall be substituted, namely:––

Amendment
of section 252.

“(2) Whoever uses or allows to be used any place for any of the purposes
specified in sub-section (1), without a licence, or in contravention of any conditions
subject to which a licence may have been granted under sub-section (1) shall, on

<!-- page 17 -->

16

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

conviction, be punished with simple imprisonment for a term which may extend to three
months and fine which may extend to fifty thousand rupees if the contravention is of
clause (i) or clause (ii) of sub-section (1) and with fine which may extend to
ten thousand rupees if the contravention is of clause (iii) of that sub-section, and in the
case of continuing contravention of the said clause (i) or clause (ii), with further fine of
five thousand rupees, and of the said clause (iii), with further fine of one thousand
rupees, for every day after the first during which such contravention continues.”.
Amendment
of section 254.

69. In section 254 of the principal Regulation, in sub-section (2), for the words “with
fine which may extend to one hundred rupees”, the following shall be substituted, namely:—
“with simple imprisonment for a term which may extend to one month and with
fine which may extend to ten thousand rupees”.

Amendment
of section 257.

70. In section 257 of the principal Regulation, in sub-section (3), for the words “with
fine which may extend to fifty rupees”, the following shall be substituted, namely:––
“with simple imprisonment for a term which may extend to three months and fine
which may extend to fifty thousand rupees”.

Amendment
of section 259.

71. In section 259 of the principal Regulation, in sub-section (3),––
(i) for the words “five hundred rupees”, the words “one lakh rupees” shall be
substituted;
(ii) for the words “fifty rupees”, the words “one thousand rupees” shall be
substituted.

Amendment
of section 260.

72. In section 260 of the principal Regulation, in sub-section (3),––
(i) for the words “five hundred rupees”, the words “one lakh rupees” shall be
substituted;
(ii) for the words “fifty rupees”, the words “one thousand rupees” shall be
substituted.

Amendment
of section 261.

Amendment
of section 263.

73. In section 261 of the principal Regulation, in sub-section (3),––
(i) for the words “five hundred rupees”, the words “one lakh rupees” shall be
substituted;
(ii) for the words “fifty rupees”, the words “one thousand rupees” shall be
substituted.
74. In section 263 of the principal Regulation, in sub-section (3), for the words “with
fine which may extend to one thousand rupees”, the following shall be substituted, namely:—
“with simple imprisonment for a term which may extend to three months and fine
which may extend to fifty thousand rupees and in the case of continuing contravention
with further fine which may extend to one thousand rupees for every day after the first
during which such contravention continues”.

Amendment
of section 264.

Amendment
of section 265.

75. In section 264 of the principal Regulation, in sub-section (2),—
(i) for the words “fifty rupees”, the words “ten thousand rupees” shall be
substituted;
(ii) for the words “five rupees”, the words “five hundred rupees” shall be
substituted.
76. In section 265 of the principal Regulation, in sub-section (3), for the words “with
fine which may extend to five hundred rupees, and in the case of continuing offence with
further fine which may extend to fifty rupees”, the following shall be substituted, namely:—
“with simple imprisonment for a term which may extend to one month and fine
which may extend to fifty thousand rupees, and in the case of continuing offence with
further fine which may extend to one thousand rupees”.

<!-- page 18 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

17

77. In section 266 of the principal Regulation, in sub-section (3), for the words “with
fine which may extend to two hundred rupees, and in the case of continuing offence with
further fine which may extend to twenty rupees”, the following shall be substituted, namely:—

Amendment
of section 266.

“with simple imprisonment for a term which may extend to one month and fine
which may extend to ten thousand rupees, and in the case of continuing offence with
further fine which may extend to five hundred rupees”.
78. In section 270 of the principal Regulation, in sub-section (3),––
(i) for the word “imprisonment”, the words “simple imprisonment” shall be
substituted;

Amendment
of section 270.

(ii) for the words “five hundred rupees”, the words “five thousand rupees” shall
be substituted.
79. In section 275 of the principal Regulation, in sub-section (3), for the words
“one hundred rupees”, the words “ten thousand rupees” shall be substituted.
80. In section 276 of the principal Regulation,––
(i) in sub-section (1),––

Amendment
of section 275.
Amendment
of section 276.

(a) in clause (i), for the words “three hundred rupees”, the words
“ten thousand rupees” shall be substituted;
(b) in clause (ii), for the words “five hundred rupees”, the words
“twenty thousand rupees” shall be substituted;
(ii) in sub-section (2), in clause (a), for the words “two hundred and fifty rupees”,
the words “ten thousand rupees” shall be substituted.
81. In section 277 of the principal Regulation,––
(i) in clause (a), for the words “one hundred rupees”, the words “ten thousand
rupees” shall be substituted;

Amendment
of section 277.

(ii) in clause (b), for the words “two hundred and fifty rupees”, the words
“twenty thousand rupees” shall be substituted.
82. In section 279 of the principal Regulation, in sub-section (2), for the words
“ fifty rupees”, the words “ten thousand rupees” shall be substituted.

Amendment
of section 279.

83. In section 280 of the principal Regulation, in sub-section (2), for the words
“one hundred rupees”, the words “two thousand rupees” shall be substituted.

Amendment
of section 280.

84. In section 281of the principal Regulation,––
5 of 1898.
2 of 1974.

(i) in sub-section (4), for the words and figures “section 248 of the Code of
Criminal Procedure,1898”, the words and figures “section 257 of the Code of Criminal
Procedure, 1973” shall be substituted;

5 of 1898.
2 of 1974.

(ii) in sub-section (5), for the words and figures “Code of Criminal
Procedure,1898”, the words and figures “Code of Criminal Procedure,1973” shall be
substituted;

Amendment
of section 281.

(iii) in sub-section (6),––
(a) for the word “one-fourth”, the word “one-half ” shall be substituted;
(b) for the words “two hundred and fifty rupees”, the words “ten thousand
rupees” shall be substituted.
85. In section 284 of the principal Regulation, in clause (d),––
(i) for the words “one hundred rupees”, the words “ten thousand rupees” shall
be substituted;

Amendment
of section 284.

<!-- page 19 -->

18

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(ii) for the words “ten rupees”, the words “one thousand rupees”shall be
substituted.
Amendment
of section 285.

86. In section 285 of the principal Regulation, for the words “two hundred and
fifty rupees”, the words “five thousand rupees”shall be substituted.

Amendment
of section 313.

87. In section 313 of the principal Regulation, in sub-section (1), in the proviso, in
clause (c), for the words “seven and a half per cent.”, the words “fifteen per cent.” shall be
substituted.

Amendment
of section 314.

88. In section 314 of the principal Regulation, for the words “fifty rupees”, the words
“ten thousand rupees” shall be substituted.

Amendment
of section 321.

89. In section 321 of the principal Regulation, in sub-section (2), in clause (b), for the
words and figures “Code of Criminal Procedure, 1898”, the words and figures “Code of
Criminal Procedure, 1973” shall be substituted.

5 of 1898.
2 of 1974.

Amendment
of section 330.

90. In section 330 of the principal Regulation, in clauses (c) and (d), for the words and
figures “Goa, Daman and Diu Village Panchayats Regulation, 1962”, wherever they occur, the
words and figures “Daman and Diu Panchayat Regulation, 2012” shall be substituted.

Reg. 9 of 1962.
Reg. 4 of 2012.

Insertion of a
new Schedule.

91. After Schedule IX of the principal Regulation, the following Schedule shall be
inserted, namely:––
“SCHEDULE X
[See section 16 (1) (n)]
Provisions as to disqualification on ground of defection
1. Disqualification on ground of defection.—(1) Subject to the provisions of
paragraph 2, a Councillor of the Council belonging to any political party shall be
disqualified for being a Councillor of the Council ––
(a) if he has voluntarily given up his membership of such political
party; or
(b) if he votes or abstains from voting in the Council contrary to any
direction issued by the political party to which he belongs or by any person or
authority authorised by it in this behalf, without obtaining, in either case, the
prior permission of such political party, person or authority and such voting or
abstention has not been condoned by such political party, person or authority
within fifteen days from the date of such voting or abstention.
Explanation.––For the purposes of this sub-paragraph, a Councillor of
the Council shall be deemed to belong to the political party, if any, by which he
was set up as a candidate for election as such a Councillor.
(2) A Councillor of the Council who has been elected as such otherwise than as
a candidate set up by any political party shall be disqualified for being a Councillor of
the Council if he joins any political party after such election.
(3) Notwithstanding anything contained in sub-paragraphs (1) and (2), a person
who, on the commencement of the Daman and Diu Municipalities (Amendment)
Regulation, 2018 is a Councillor of the Council shall,––
(i) where he was a member of a political party immediately before such
commencement, be deemed, for the purpose of sub-paragraph (1) of this
paragraph, to have been elected as a Councillor of such Council as a candidate
set up by such political party;
(ii) in any other case, be deemed to be a Councillor of the Council who
has been elected as such otherwise than as a candidate set up by any political
party for the purpose of sub-paragraph (2) of this paragraph.

<!-- page 20 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

19

2. Disqualification on ground of defection not to apply in case of merger.––(1)
A Councillor of the Council shall not be disqualified under sub-paragraph (1) of
paragraph 1 where his original political party merges with another political party and
he claims that he and any other Councillors of his original political party—
(a) have become members of such other political party or, as the case may
be, of a new political party formed by such merger; or
(b) have not accepted the merger and opted to function as a separate
group, and from the time of such merger, such other political party or new
political party or group, as the case may be, shall be deemed to be the political
party to which he belongs for the purposes of sub-paragraph (1) of paragraph
1 and to be his original political party for the purposes of this sub-paragraph.
(2) For the purposes of sub-paragraph (1), the merger of the original political
party of a Councillor of the Council shall be deemed to have taken place if, and only
if, not less than two-thirds of the Councillors of such political party in the Council
concerned have agreed to such merger.
3. Decision on question as to disqualification on ground of defection.—(1) If
any question arises as to whether a Councillor of the Council has become subject to
disqualification under this Schedule, the question shall be referred to the Administrator
and the decision of the Administrator thereon shall be final.
(2) Before giving any decision on any such question referred under
sub-paragraph (1), the Administrator shall obtain the opinion of the Election
Commission referred to in section 5.
4. Rules.–– The Administrator may make rules for giving effect to the provisions
of this Schedule, and in particular and without prejudice to the generality of the
foregoing powers, such rules may provide for—
(a) the maintenance of registers or other records as to the political parties,
if any, to which different Councillors of the Council belong;
(b) the report which the leader of a political party in relation to a Councillor
of the Council shall furnish with regard to any condonation of the nature referred
to in clause (b) of sub-paragraph (1) of paragraph 1 in respect of such Councillor,
the time within which and the authority to which such report shall be furnished;
(c) the report, which a political party, shall furnish with regard to admission
to such political party of any Councillor of the Council and the officer of the
Council to which such report shall be furnished; and
(d) the procedure for deciding any question referred to in paragraph 3
including the procedure for any inquiry which may be made for the purpose of
deciding such question.”.
————
RAM NATH KOVIND,
President.
————
DR. G. NARAYANA RAJU,
Secretary to the Govt. of India.
UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110 002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110 054.
MGIPMRND—5132GI(S3)—26-03-2018.

<!-- page 21 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—18

REGISTERED NO. DL—(N)04/0007/2003—18

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 14]

ubZ fnYyh] lkseokj] ekpZ 26] 2018@ pS= 5] 1940 ¼'kd½

No. 14]

NEW DELHI, MONDAY, MARCH 26, 2018/CHAITRA 5, 1940 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 26th March, 2018/Chaitra 5, 1940 (Saka)

THE DADRA AND NAGAR HAVELI MUNICIPAL COUNCIL
(AMENDMENT) REGULATION, 2018
NO. 2 OF 2018
Promulgated by the President in the Sixty-ninth Year of the Republic of India.
A Regulation further to amend the Dadra and Nagar Haveli Municipal Council
Regulation, 2004.
In exercise of the powers conferred by article 240 of the Constitution, the President is
pleased to promulgate the following regulation made by him:—
1. (1) This Regulation may be called the Dadra and Nagar Haveli Municipal Council
(Amendment) Regulation, 2018.

Short title and
commencement.

(2) It shall come into force at once.
Reg. 2 of
2004.

2. Throughout the Dadra and Nagar Haveli Municipal Council Regulation, 2004
(hereinafter referred to as the principal Regulation), for the words "servant" and "servants",
wherever they occur, the words "employee" and "employees" shall respectively be substituted
and such other consequential amendments as the rules of grammar may require shall also be
made.

Substitution of
references to
certain
expressions by
certain other
expressions.

3. In section 2 of the principal Regulation, for clause (35), the following clause shall be
substituted, namely:—-

Amendment
of section 2.

<!-- page 22 -->

2

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

'(35) "officer or employee of the Council" means an officer or employee appointed
by the Chief Officer or the Government and includes any Government officer or
employee who is for the time being serving under the Council;'.
Amendment
of section 9.

4. In section 9 of the principal Regulation, in sub-section (2), for clause (i), the following
clause shall be substituted, namely:—
"(i) two persons who are not less than twenty-five years of age and who have
special knowledge or experience in municipal administration to be nominated by the
administrator:
Provided that the persons nominated under this clause shall have no right to
vote in the meetings of Council;".

Amendment
of section 10.

5. In section 10 of the principal Regulation,—
(i) in sub-section (2), for the word "one-third", the word "one-half" shall be
substituted;
(ii) in sub-section (3), for the word "one-third", the word "one-half" shall be
substituted.

Amendment
of section 14.

6. In section 14 of the principal Regulation,-—
(i) in sub-section (1), after the words "by ballot", the words "or by Electronic
Voting Machine" shall be inserted;
(ii) after sub-section (2), the following sub-section shall be inserted, namely:—
‘(3) Notwithstanding anything contained in this Regulation or the rules
made thereunder, the giving or recording of vote by Electronic Voting Machine
may be adopted in such ward or wards of the Council as the Election Commission
may, having regard to the circumstances of each case, specify.
Explanation.—For the purposes of this section, "Electronic Voting
Machine" means any machine or apparatus whether operated electronically or
otherwise used for giving or recording of vote and any reference to a ballot box
or ballot paper in this Regulation or the rules made thereunder shall, save as
otherwise provided, be construed as including a reference to such Electronic
Voting Machine wherever such Electronic Voting Machine is used at any
election.'.

Amendment
of section 16.

7. In section 16 of the principal Regulation, in sub-section (1), for the words
"twenty-five years", the words "twenty-one years" shall be substituted.

Amendment
of section 17.

8. In section 17 of the principal Regulation, in sub-section (1), after clause (l), the
following clauses shall be inserted, namely:—
"(m) is so disqualified by or under any law for the time being in force for the
purposes of election to the House of the People;
(n) is disqualified on the ground of defection under Schedule IX.".

Amendment
of section 24.

9. In section 24 of the principal Regulation, in sub-section (3), the following proviso
shall be inserted, namely:—
"Provided that no symbol allotted under this Regulation to a candidate shall be
deemed to be a religious symbol or a national symbol for the purposes of this
sub-section.".

Substitution of
new section
for section 25.

10. For section 25 of the principal Regulation, the following section shall be substituted,
namely:—

Prohibition of
public meeting
during period
of forty-eight
hours ending
with
hours
fixed
for
conclusion of
poll.

'25. (1) No person shall—
(a) convene, hold or attend, join or address any public meeting or
procession in connection with an election; or
(b) display to the public any election matter by means of cinematograph,
television or other similar apparatus; or

<!-- page 23 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

(c) propagate any election matter to the public by holding, or by arranging
the holding of, any musical concert or any theatrical performance or any other
entertainment or amusement with a view to attracting the public thereto,
in any polling area during the period of forty-eight hours ending with the hours fixed
for the conclusion of the poll for any election.
(2) Any person who contravenes the provisions of sub-section (1) shall, on
conviction, be punished with imprisonment for a term which may extend to two years,
or with fine, or with both.
Explanation.—For the purposes of this section, the expression "election matter"
means any matter intended or calculated to influence or affect the result of an election.'.
11. In section 26 of the principal Regulation, in sub-section (2), for the words "with
fine which may extend to two hundred and fifty rupees", the following shall be substituted,
namely:—

Amendment
of section 26.

"with imprisonment for a term which may extend to six months, or with fine
which may extend to two thousand rupees or with both".
12. In section 52 of the principal Regulation, in sub-section (3), in clause (u), for the
words "rupees two hundred and the total expenditure during the year does not exceed
rupees one thousand", the words "such amount as may be notified in the Official Gazette by
the Government and the total expenditure during the year does not exceed such amount as
may be notified in the Official Gazette by the Government" shall be substituted.
13. In section 53 of the principal Regulation,—
(i) for sub-section (2), the following sub-section shall be substituted, namely:—

Amendment
of section 52.

Amendment
of section 53.

"(2) On the constitution of a Council under this Regulation, the Collector
shall convene a special meeting of the Councillors for election of a President
and a Vice-President in such manner as may be prescribed.";
(ii) sub-section (3), sub-section (4) and sub-section (5) shall be omitted;
(iii) for sub-section (6), the following sub-section shall be substituted, namely:—
"(6) If there is a vacancy in the office of the President or Vice-President
due to any reason whatsoever, the vacancy shall be filled at the same procedure
as provided in sub-section (2).".
14. In section 55 of the principal Regulation, in sub-section (2), for the word "receipt",
the word "acceptance" shall be substituted.
15. In section 57 of the principal Regulation,—
(i) in sub-section (1), the following proviso shall be inserted, namely:—
"Provided that no such resolution shall be moved within a period of
six months from the date of the assumption of office by the President or
Vice-President, as the case may be.";
(ii) in sub-section (2), for the word "one-fourth", the word "one-third" shall be
substituted;
(iii) in sub-section (3), for the word "Director", wherever it occurs, the word
"Collector" shall be substituted;
(iv) for sub-section (4), the following shall be substituted, namely:—
"(4) Every President or Vice-President of the Council may be removed
from his office if a resolution of the Council expressing want of confidence in
him is passed by a majority of the total members present at a meeting specially
convened for the purpose:

Amendment
of section 55.
Amendment
of section 57.

<!-- page 24 -->

4

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

Provided that no such resolution shall be moved unless,—
(a) a notice of the intention to move the resolution has been given
within such period as may be prescribed and signed by one-third members
of the Council, and
(b) it contains a proposal for election of a new President or
Vice-President of the Council.
(5) At any meeting of the Council, while any resolution for removal of the
President from his office is under consideration, the President, or while any
resolution for removal of the Vice-President from his office is under
consideration, the Vice-President, shall not, though he is present, preside.
(6) The meeting shall be presided over by the Vice-President if the motion
is against the President, and by the President if the motion is against the
Vice-President.
(7) At any meeting of the Council, while any resolution for electing a
successor to the office of the President is under consideration, the candidate
to the office of the President, or while any resolution for electing a successor to
the office of the Vice-President is under consideration, the candidate to the
office of the Vice-President, shall not, though he is present, preside.
(8) The President or Vice-President shall have right to speak in, and
otherwise to take part in the proceeding of such meeting of the Council while
any resolution for removal from his office is under consideration in the Council
and shall be entitled to vote only in the first instance on such resolution or on
any other matter during such proceeding but not in the case of an equality of
votes.
(9) The provisions of sub-sections (6), (7) and (8) shall apply mutatis
mutandis to the person contesting the election for the post of President or
Vice-President of the Council.
(10) The procedure to be followed for the meeting shall be such as may
be prescribed.".
Amendment
of section 59.

16. In section 59 of the principal Regulation, in sub-section (4), for the words "two
thousand rupees", the words "five thousand rupees" shall be substituted.

Amendment
of section 60.

17. In section 60 of the principal Regulation, in sub-section (1), in clause (d), for the
words "servants of the Council", the words "employees of the Council through the Chief
Officer" shall be substituted.

Amendment
of section 64.

18. In section 64 of the principal Regulation,—
(a) in sub-section (1), for the words "appoint such Subjects Committees", the
words "appoint not more than three Subjects Committees" shall be substituted;
(b) in sub-section (2), after the word "Councillors", the words "or five members
whichever is more" shall be inserted;
(c) in sub-section (3), for the words "five members, as it may determine", the
words "three members" shall be substituted;
(d) in sub-section (4),—
(i) in clause (a), after the words "Standing Committee", the words "and
allocating one or more than one subject to the Standing Committee and Subjects
Committees" shall be inserted;
(ii) for clause (b), the following clause shall be substituted, namely:—

<!-- page 25 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

5

"(b) determining the number of member of the Subjects Committee
or Committees, if any, to be appointed, and if more than one such
Committees are to be appointed, the Subjects Committees of which the
Vice-President shall be ex officio Chairman;";
(iii) in clause (c), the following proviso shall be inserted, namely:—
"Provided that no Councillor shall be eligible to be elected to more
than one Subjects Committees.".
19. In section 65 of the principal Regulation,—
(i) for the words "the last preceding section", the word and figures "section 64"
shall be substituted;

Amendment
of section 65.

(ii) in clause (c), after the words "elected by the Councillors", the words
"excluding President, Vice-President and member of any Standing Committee or
Subjects Committees" shall be inserted;
(iii) the proviso shall be omitted.
20. For section 66 of the principal Regulation, the following section shall be substituted,
namely:—

Substitution of
new section
for section 66.

"66. A Council may, from time to time, refer to a Subjects Committee constituted
under section 64 such special subjects or matters relating to the purposes of this
Regulation, for opinion, or inquiry and report, as the Council may think fit, and it may
direct such Subjects Committee to submit its opinion or report either to it or to the
Standing Committee.".

Reference of
special
subjects or
matters to the
Subjects
Committee.

21. For section 69 of the principal Regulation, the following section shall be substituted,
namely:—

Substitution of
new section
for section 69.

"69. Each Council shall make bye-laws specifying the powers to be exercised
by the Standing Committee and the Subjects Committees, if any, including the subjects
to be allotted to such Committees.".

Powers of
Standing
Committees
and Subjects
Committees.
Amendment
of section 70.

22. In section 70 of the principal Regulation, for the words "rupees fifty thousand and
rupees ten thousand respectively", the words "such amount as may be notified in the
Official Gazette by the Government" shall be substituted.
23. In section 73 of the principal Regulation,—
(i) in sub-section (4), for the word "Council", the word "Government" shall be
substituted;

Amendment
of section 73.

(ii) in sub-section (5), in clause (b), the words and brackets, "whose minimum
salary (exclusive of allowance) is not less than rupees two thousand per month" shall
be omitted.
24. For section 74 of the principal Regulation, the following section shall be substituted,
namely:—

Substitution
of new
section for
section 74.

"74. (1) A Council may, with the sanction of the Director, create such posts of
officers and employees other than those specified in sub-sections (1) and (2) of
section 73 as it shall deem necessary for efficient execution of its duties under this
Regulation.

Appointment
of other
officers and
employees.

(2) The qualifications, pay, allowances, and other conditions of service and
method of recruitment of any such officers and employees shall, by general or special
order, be made by the Government in this behalf.

<!-- page 26 -->

6

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(3) The power of making appointment to any post referred to in sub-section (1)
shall vest in the Chief Officer with the prior approval of the Director.".
Amendment
of section 75.

25. In section 75 of the principal Regulation, in sub-section (1),—
(i) in clause (a), for the word "President", the word "Council" shall be
substituted;
(ii) in clause (b), after the word "Council", the following shall be inserted,
namely: —
"and the Standing Committee:
Provided that if it appears to the Chief Officer that any decision or
resolution is against public interest or harmony, or is otherwise ultra vires, he
shall refer the decision or the resolution to the Collector for clarification or
decision, and after a clarification or decision in this regard is received from the
Collector, unless otherwise directed to do so in writing by the Collector, the
Chief Officer shall implement the decision or resolution;";
(iii) after clause (h), the following clause shall be inserted, namely:—
"(i) undertake such minor repair or maintenance work as may be notified
in the Official Gazette by the Government within the financial limits.".

Amendment
of section 76.

26. In section 76 of the principal Regulation, for the words "Standing Committee", the
words "Chief Officer" shall be substituted.

Substitution of
new section
for section 77.

27. For section 77 of the principal Regulation, the following section shall be substituted,
namely:—

Punishment of
officers and
employees.

"77. (1) Without prejudice to the provisions of any law for the time being in
force, the following penalties may, for good reasons, be imposed upon any officer or
employee of the Council:—
(a) minor penalties—
(i) censure;
(ii) withholding of promotion;
(iii) recovery from his pay of the whole or part of any pecuniary
loss caused by him to the Council by negligence or breach of orders;
(iv) withholding of increments of pay;
(b) major penalties—
(i) reduction to a lower post on a fixed pay or a time scale or to a
lower stage in a time scale;
(ii) removal from the service, which does not disqualify from future
employment;
(iii) dismissal from the service, which ordinarily disqualifies from
future employment.
(2) The major penalties mentioned in clause (b) of sub-section (1) may be
imposed on an officer or employee of the Council by the authority competent to make
the appointment of the officer or employee:
Provided that the minor penalties mentioned in clause (a) of sub-section (1)
may be imposed on an officer other than an officer belonging to the common cadre
specified in sub-section (5) of section 73 or an employee of the Council, by the Chief
Officer:

<!-- page 27 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

7

Provided further that suspension of an officer or employee pending inquiry
into the allegations against such officer or employee shall not be deemed to be a
penalty and shall be ordered only by the authority competent to make appointment to
the post held by such officer or employee.
(3) No officer or employee shall be imposed major penalties mentioned in
clause (b) of sub-section (1) unless he has been given a reasonable opportunity of
showing cause against such penalties:
Provided that this sub-section shall not apply where a person is reduced,
removed or dismissed on the ground of conduct which has led to his conviction on
a criminal charge.
(4) No major penalty mentioned in clause (b) of sub-section (1) shall be imposed
on any officer or employee appointed under sub-section (3) of section 74, without
the prior approval of the Director.
(5) In every case referred to the Director under sub-section (4), the Director
shall not refuse to give his approval unless he is satisfied that—
(i) the finding at the inquiry is perverse; or
(ii) the major penalty imposed is severe.
(6) Where the Director informs the Chief Officer that the finding at the inquiry
is perverse, no further proceeding shall be taken against the officer or employee
concerned in respect of the same matter.
(7) An appeal against any order imposing any penalty mentioned in
sub-section (1) may be made—
(i) in case if an order imposing any minor penalty mentioned in clause (a)
of sub-section (1), to the Director;
(ii) in case if an order imposing any major penalty mentioned in clause (b)
of sub-section (1), to the authority specified in this behalf by the Administrator
by an order.
(8) No such appeal may be entertained if not preferred within one month from
the date of receipt of the order appealed against by the officer or employee concerned.
(9) The appellate authority referred to in sub-section (7), within six months of
the date of the order passed, may at any time, either on his or its own motion or
otherwise, call for the records of any inquiry and revise any order made for reduction
to a lower post or rank or removal or dismissal from the service, and may—
(i) confirm, modify, reduce, enhance or set aside the order; or
(ii) remit the case to the authority which made the order to or any other
authority directing such authority to make such further inquiry as he or it may
consider proper in the circumstances of the case; or
(iii) pass such orders as he or it may deem fit.
(10) The Administrator may, at any time, either on his own motion or otherwise,
review any order passed under this section, when any new material or evidence
which could not be produced or was not available at the time of passing the order
under review and which has the effect of changing the nature of the case, has come,
or has been brought, to his notice.".
28. After section 78 of the principal Regulation, the following Chapter shall be inserted,
namely:—

Insertion of
new Chapter
VA.

<!-- page 28 -->

8

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

"CHAPTER VA
OMBUDSMAN FOR COUNCIL
Establishment,
term of office
and conditions
of service of
Ombudsman.

78A. (1) The Government shall, by notification in the Official Gazette, establish
an authority to be known as Ombudsman for making investigations and inquiries, in
respect of charges on any action involving corruption or maladministration or
irregularities in the discharge of administrative functions by the members of the Council
under this Regulation:
Provided that the Government may designate the Ombudsman appointed under
the Dadra and Nagar Haveli Panchayat Regulation, 2012 to discharge the function of
the Ombudsman under this Regulation.

Reg. 5 of 2012.

(2) The Ombudsman shall consist of one member to be appointed by the
Administrator, on the recommendation of a committee referred to in sub-section (4).
(3) The Ombudsman shall not be a Government employee.
(4) The Committee referred to in sub-section (2) shall comprises of the following,
namely:—
(a) Director, Municipal Administration of Dadra and Nagar Haveli;
(b) a retired District Judge;
(c) a retired civil employee who has held a post in the Central Government
or State Government not below the rank of Joint Secretary to the Government
of India; and
(d) two persons of impeccable integrity from the civil society nominated
by the Administrator.
(5) A person appointed to be the Ombudsman shall, before he enters upon his
office, make and subscribe before the Administrator or any other officer appointed in
that behalf by him, an oath or affirmation according to the form set out below:—
“I, A. B. having been appointed as the Ombudsman for the
_______________Council under the Dadra and Nagar Haveli Municipalities
Council Regulation, 2004, do swear in the name of God/Solemnly affirm that
I will bear true faith and allegiance to the Constitution of India and I will duly
and faithfully and to the best of my ability, knowledge and judgment perform
the duties of my office without fear or favour, affection or ill-will.”.
(6) The Ombudsman shall hold office for a term of three years from the date on
which he enters upon his office:
Provided that—
(a) the Ombudsman may, by writing under his hand addressed to the
Administrator, resign his office; and
(b) the person appointed as Ombudsman may be removed from his office
in the manner provided in section 77B.
(7) The salary and allowance payable to, and the other terms and conditions of
service of, the Ombudsman shall be such as may be prescribed.
(8) On expiry of his term of office as Ombudsman, he shall not be eligible for reappointment as Ombudsman or for further appointment to any office under the Union
territory Administration or in any corporation, company, society or university by or
under the control of the Union territory Administration.
Removal of
Ombudsman.

78B. (1) The Ombudsman may be removed from his office, by an order of the
Administrator, on the ground of proved misbehavior or incapacity.

Reg. 2 of 2004.

<!-- page 29 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

9

(2) The procedure for the removal of the Ombudsman under sub-section (1)
and for the investigation and proof of the misbehavior or incapacity of the Ombudsman
shall be such as may be prescribed.
78C. (l) The Government may in consultation with the Ombudsman, provide the
officers and staff to assist the Ombudsman in the discharge of its functions under
this Regulation.

Staff of the
Ombudsman.

(2) The salaries, allowances and other conditions of service of the officers and
staff provided to the Ombudsman shall be such as may be prescribed.
(3) The Ombudsman may require the assistance of any officer of any Government
Department in order to ascertain the veracity of an allegation under investigation and
such officer shall be bound to render such assistance in addition and without detriment,
to his official duties.
(4) The Ombudsman may utilise the services of any person having experience
and expertise in any particular subject in deciding the questions before it.
78D. (1) The Ombudsman shall perform all or any of the following functions,
namely:—

Functions of
the
Ombudsman.

(i) investigate into any allegation contained in a complaint or on a
reference from the Government or that has come to the notice of the
Ombudsman;
(ii) inquire into any complaint in which corruption or maladministration
of a member of the Council is alleged;
(iii) pass an order on the allegation in the following manner, namely:—
(a) where the irregularity involves a criminal offence committed by
a member of the Council, the matter shall be referred to the appropriate
authority for investigation;
(b) where the irregularity causes loss or inconvenience to a citizen,
direct the Council to give him compensation and to reimburse the loss
from the person responsible for such irregularity;
(c) where the irregularity involves loss or waste or misuse of the
fund of the Council, realise such loss from those who are responsible for
such irregularity; and
(d) where the irregularity is due to omission or inaction, cause to
supply the omission and to rectify the mistake.
(2) In addition to the functions enumerated in sub-section (1), the Ombudsman
may pass interim order restraining the Council from doing anything detrimental to the
interest of the complainant if it is satisfied that much loss or injury shall be caused to
the complainant due to the alleged act.
(3) The Ombudsman may, if it is of opinion that the irregularity involves corrupt
practice for personal gain, by order, impose penalty in addition to compensation.

5 of 1908.

78E. (1) The Ombudsman shall, for the purpose of any investigation or inquiry
under this Regulation, have the same powers as are vested in a civil court while
trying a suit under the Code of Civil Procedure, 1908 in respect of the following
matters, namely:—
(a) summoning and enforcing the attendance of any witness and
examining him on oath;
(b) requiring the discovery and production of any document;

Powers of the
Ombudsman.

<!-- page 30 -->

10

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(c) receiving evidence on affidavits;
(d) requisitioning any public record or document or copy of such record
or document from any office;
(e) issuing commissions for the examination of witness or documents;
and
(f) any other matter which may be prescribed.
(2) Where the Ombudsman finds that the allegation contained in a complaint is
without any substance or trivial in nature, it may, by order, direct the complainant to
pay to the opposite party so much of the amount specified in the order by way of
cost.
(3) Where the allegation contained in a complaint is about the loss or waste or
misapplication of the fund of the Council or in respect of the loss or inconvenience
caused to a citizen, the Ombudsman may, during inquiry, collect evidence, determine
the loss and direct in its order the amount to be realised from the person responsible.
(4) If the amount payable as per the order passed by the Ombudsman under
sub-section (2) or sub-section (3) is not paid within the period specified by it, the
same shall be recoverable as if it were an arrears of land revenue.
Service of
Government
Departments.

78F. The Government may, at the request of the Ombudsman make available the
services of officers and employees of the Government including police personnel to
assist the Ombudsman in the conduct of investigation and inquiry, and in respect of
such functions, such officer or employee shall be deemed to be the officer or employee
of the Ombudsman.

Investigation.

78G. (1) The Ombudsman may, in accordance with the provisions of this
Regulation, investigate into any complaint filed before it under this Regulation.
(2) Notwithstanding anything contained in this Regulation, the Government
may refer any allegation of corruption or maladministration against a Council or a
member of the Council which is within its knowledge or brought to its notice, to the
Ombudsman and the Ombudsman shall investigate into it as if it was a complaint filed
under this Regulation.
(3) The Ombudsman may, on receipt of a complaint, conduct an investigation
in the matter and where there is a prima facie case,he may conduct a detailed inquiry
under section 78H.
(4) The Ombudsman shall not inquire into matters relating to,—
(a) any matter in respect of which a formal and public inquiry has been
ordered by the Government;
(b) any matter in respect of which a remedy is available from the Court for
Council;
(c) any matter in respect of which an inquiry has been ordered under the
Commission of the Inquiries Act, 1952 or any matter pending before a Court;
(d) any complaint filed after the expiry of three years from the date on
which the matter complained against have taken place:
Provided that the Ombudsman may entertain such complaint if the
complainant satisfies that he had sufficient reason for not filing the complaint
within the specified period.

Inquiry.

78H. (1) After an investigation, if the Ombudsman is satisfied that,—
(a) the complaint is frivolous or vexatious or is not made in good faith; or

60 of 1952.

<!-- page 31 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

11

(b) there is no sufficient ground to initiate proceedings; or
(c) other remedies are available to the complainant and it shall be more
beneficial for the complainant to avail of such remedies in view of the
circumstances of the case,
it may, after recording his findings stating the reason therefor, dispose of the complaint
and communicate the same to the complainant.
(2) If the Ombudsman is of the opinion that there is a prima facie case against
the member or the Council complained of, it shall record its findings to this effect and
send notices of the proposed inquiry to the complainant and to the opposite party.
(3) Subject to the provisions of this Regulation and the rules made thereunder,
the Ombudsman may regulate its own procedure for the purpose of holding its meeting
(including time and place of sitting).
(4) In any proceeding before the Ombudsman, no legal practitioner shall be
permitted to represent any person, unless the Ombudsman, by an order, for reasons
to be recorded in writing, permits a person to be represented by a legal practitioner.
78-I. (1) Notwithstanding anything contained in any other law for the time
being in force, any proceeding relating to a member or the Council which is
pending before any authority under this Regulation, on such establishment under
sub-section (1) of section 78A shall on such establishment, be transferred to the
Ombudsman and the Ombudsman shall decide the proceedings in accordance with
the provisions of this Regulation.

Existing cases
to be
transferred to
Ombudsman.

(2) All cases, with regard to the loss, wastage and misappropriation of any land
of the Local Self Government Institution, pending before the Government or any
other authority shall be transferred to the Ombudsman and the Ombudsman shall
dispose of the proceedings in accordance with the provisions of this Regulation.
78J. (1) If, after an investigation or inquiry, the Ombudsman finds that there is
a prima facie case against the accused, the Ombudsman may, for the reasons be
recorded in writing, refer the complaint to a competent authority to initiate prosecution.

Initiation of
prosecution.

(2) The competent authority referred to in sub-section (1) shall conduct a
detailed inquiry, and if necessary, shall frame the charge.
78K. (1) The Ombudsman may consider and dispose of complaints other than
those involving criminal offences in the following manner, namely:—
(i) award of compensation to a citizen in case of loss or grievance;
(ii) order the recovery of loss caused to the Council from the person
responsible;
(iii) order the supply of omission or rectification of defects due to in action;
(iv) order the recovery of loss from the accused failing which, order
realisation through Revenue Recovery Proceedings; and
(v) order other necessary remedial measures considering the facts and
circumstances of the case.
(2) Where the Ombudsman finds that the procedure or practice regarding the
administration of the Council gives room for complaint, it may give suggestions to
the Government or the Council relating to the measures for avoiding the recurrence of
such complaint.
(3) The Ombudsman shall give annually a detailed report regarding the
performance of its functions under this Regulation to the Government.

Disposal of
complaints.

<!-- page 32 -->

12
Power to
make rules
under this
Chapter.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

78L. (1) The Government may make rules to carry out the provisions of this
Chapter.
(2) In particular, and without prejudice to the generality of the foregoing power,
such rules may provide for all or any of the following matters, namely:—
(a) the salary and allowances payable to, and other terms and conditions
of service of, the Ombudsman under sub-section (7) of section 78A;
(b) the procedure for the removal of the Ombudsman and investigation of
proof of the misbehaviour or incapacity under sub-section (2) of section 78B;
(c) the salary and allowances payable to, and other terms and conditions
of service of, the officers and staff provided to the Ombudsman under
sub-section (2) of section 78C; and
(d) any other matter which is required to be or may be prescribed.".

Amendment
of section 82.

29. In section 82 of the principal Regulation, in sub-section (2), for the word "President",
wherever it occurs, the word "Collector" shall be substituted.

Amendment
of section 87.

30. In section 87 of the principal Regulation, in sub-section (2), in clause (f), after the
word and figure "section 73", the following shall be inserted, namely:—
"and the officers belonging to the Government Departments posted on
deputation to the Council".

Amendment
of section 90.

31. In section 90 of the principal Regulation,—
(i) in sub-section (2), in clause (c), for the words "rupees fifteen thousand", the
words "such amount as may be notified in the Official Gazette by the Government"
shall be substituted;
(ii) in sub-section (3), in clause (b), for the words "five hundred rupees", the
words "such amount as may be notified in the Official Gazette by the Government"
shall be substituted;
(iii) in sub-section (6),—
(a) for the words "one thousand rupees give notice by advertisement in
a local newspaper, inviting tenders for such contract", the following shall be
substituted, namely:—"such amount as may be notified in the Official Gazette by the
Government and give notice by advertisement, inviting tenders for such
contract and follow the procedure laid down by the Government";
(b) in the proviso, the words "in the newspaper" shall be omitted.

Amendment of
section 102.

32. In section 102 of the principal Regulation, in sub-section (1), in clause (a), after the
words "municipal area,", the words "other than those belonging to the Government or
Central Government," shall be inserted.

Amendment of
section 108.

33. In section 108 of the principal Regulation, in sub-section (1), in clause (b), the
words "increase or" shall be omitted.

Amendment of
section 125.

34. In section 125 of the principal Regulation, in sub-section (3), for the words "fifty
rupees", the words "two thousand rupees" shall be substituted.

Amendment of
section 158.

35. In section 158 of the principal Regulation, in the second proviso, for the words
"one hundred rupees", the words "fifty thousand rupees" shall be substituted.

Amendment of
section 170.

36. In section 170 of the principal Regulation,—

<!-- page 33 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

13

(i) in sub-section (2), for the words "fine which may extend to one hundred
rupees, and in the case of a continuing contravention with further fine which may
extend to twenty rupees", the following shall be substituted, namely:—
"simple imprisonment for a term which may extend to six months and fine
which may extend to fifty thousand rupees, and in the case of a continuing
contravention with further fine which may extend to five hundred rupees";
(ii) in sub-section (8),—
(a) for the words "one hundred rupees", the words "fifty thousand
rupees" shall be substituted;
(b) for the words "twenty rupees", the words "five hundred rupees" shall
be substituted.
37. In section 171 of the principal Regulation, in sub-section (7), for the words "fine
which may extend to one hundred rupees and in the case of continuing offence with further
fine which may extend to twenty rupees", the following shall be substituted, namely:—

Amendment of
section 171.

"simple imprisonment for a term which may extend to six months and fine which
may extend to fifty thousand rupees and in the case of continuing offence with
further fine which may extend to five hundred rupees".
38. In section 172 of the principal Regulation, in sub-section (3), for the words "fine
which may extend to one hundred rupees, and in the case of continuing offence with further
fine which may extend to twenty rupees", the following shall be substituted, namely:—

Amendment of
section 172.

"simple imprisonment for a term which may extend to three months and fine
which may extend to fifty thousand rupees and in the case of continuing offence with
further fine which may extend to five hundred rupees".
39. In section 174 of the principal Regulation, in sub-section (6), for the words "one
thousand rupees", the words "ten thousand rupees" shall be substituted.

Amendment of
section 174.

40. In section 176 of the principal Regulation, in sub-section (2), for the words "fifty
rupees", the words "ten thousand rupees" shall be substituted.

Amendment of
section 176.

41. In section 177 of the principal Regulation, in sub-section (3), for the words "one
hundred rupees", the words "ten thousand rupees" shall be substituted.

Amendment of
section 177.

42. In section 178 of the principal Regulation, in sub-section (2), for the words "fifty
rupees", the words "five thousand rupees" shall be substituted.

Amendment of
section 178.

43. In section 179 of the principal Regulation, in sub-section (2), for the words "fifty
rupees", the words "five thousand rupees" shall be substituted.

Amendment of
section 179.

44. In section 180 of the principal Regulation,—
(i) in sub-section (9), for the words "fine which may extend to five thousand
rupees", the following shall be substituted, namely:—

Amendment of
section 180.

"simple imprisonment for a term which may extend to six months and fine
which may extend to one lakh rupees";
(ii) in sub-section (10), for the words "twenty-five rupees", the words "five
thousand rupees" shall be substituted.
45. In section 185 of the principal Regulation, in sub-section (5),—
(i) for the words "one hundred rupees", the words "ten thousand rupees" shall
be substituted;
(ii) for the words "twenty-five rupees", the words "five hundred rupees" shall
be substituted.

Amendment of
section 185.

<!-- page 34 -->

14
Amendment of
section 186.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

46. In section 186 of the principal Regulation, in sub-section (3), for the words "fine
which may extend to five hundred rupees, and in the case of continuing contravention or
non-compliance with further fine which may extend to twenty-five rupees", the following
shall be substituted, namely:—
"simple imprisonment for a term which may extend to six months and fine which
may extend to one lakh rupees and in the case of continuing contravention or noncompliance with further fine which may not be less than one thousand rupees".

Amendment of
section 187.

47. In section 187 of the principal Regulation, in sub-section (2),—
(i) for the words "five hundred rupees", the words "fifty thousand rupees"
shall be substituted;
(ii) for the words "ten rupees", the words "five hundred rupees" shall be
substituted.

Amendment of
section 195.

48. In section 195 of the principal Regulation,—
(i) in sub-section (1), in clause (a), for the words "fifty feets", the words "fifty
meters" shall be substituted;
(ii) after sub-section (2), the following sub-section shall be inserted, namely:—
"(2A) Notwithstanding anything contained in any of the provisions of
this Regulation, the owner of any building shall connect such building to the
sewage in the area where underground sewage system exists, failing which, the
Chief Officer may, by notice in writing, direct the owner of such building to
connect the building to the underground sewage within such period as specified
in the notice.";
(iii) for sub-section (3), the following sub-section shall be substituted, namely:—
"(3) Whoever fails to comply with the notice issued by the Chief Officer
under sub-section (1) or sub-section (2) or sub-section (2A), as the case may
be, shall be punishable with fine which may extend to fifty thousand rupees
and in case of continuing offence with further fine which may extend to five
hundred rupees for every day after the first during which such offence
continues.".

Amendment of
section 203.

49. In section 203 of the principal Regulation, in sub-section (3), for the words "fine
which may extend to one hundred rupees", the following shall be substituted, namely:—
"imprisonment which may extend to three months and fine which may extend to
fifty thousand rupees and in the case of continuing contravention with further fine
which may extend to five hundred rupees for every day after the first during which
such contravention continues".

Amendment of
section 204.

50. In section 204 of the principal Regulation, in sub-section (2), for the words "fine
which may extend to one hundred rupees", the following shall be substituted, namely:—"imprisonment which may extend to three months and fine which may extend to
fifty thousand rupees and in the case of continuing contravention with further fine
which may extend to five hundred rupees for every day after the first during which
such contravention continues".

Amendment of
section 208.

51. In section 208 of the principal Regulation,—
(i) in sub-section (4), for the words "one hundred rupees", the words "five
thousand rupees" shall be substituted;
(ii) in sub-section (7), for the words "three hundred rupees", the words "fifteen
thousand rupees" shall be substituted.

<!-- page 35 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

15

52. In section 209 of the principal Regulation, in sub-section (2), for the words "one
hundred rupees", the words "five thousand rupees" shall be substituted.
53. In section 210 of the principal Regulation, in sub-section (2),—
(i) for the words "fifty rupees", the words "ten thousand rupees" shall be
substituted;

Amendment of
section 209.
Amendment of
section 210.

(ii) for the words "five rupees", the words "five hundred rupees" shall be
substituted.
54. In section 216 of the principal Regulation, in sub-section (2), for the words "two
hundred and fifty rupees", the words "ten thousand rupees" shall be substituted.
55. In section 218 of the principal Regulation, in sub-section (2),—
(i) for the words "fifty rupees", the words "ten thousand rupees" shall be
substituted;

Amendment of
section 216.
Amendment of
section 218.

(ii) for the words "ten rupees", the words "five hundred rupees" shall be
substituted.
56. In section 219 of the principal Regulation, in sub-section (2),—
(i) for the words "five hundred rupees", the words "one lakh rupees" shall be
substituted;

Amendment of
section 219.

(ii) for the words "twenty-five rupees", the words "one thousand rupees" shall
be substituted.
57. In section 221 of the principal Regulation,—
(i) in sub-section (1),—

Amendment of
section 221.

(a) after the words "other rubbish", the words "or garbage" shall be
inserted;
(b) for the words "one thousand rupees", the words "ten thousand
rupees" shall be substituted;
(ii) in sub-section (2), for the words "fine which may extend to one thousand
rupees", the following shall be substituted, namely:—
"simple imprisonment for a term which may extend to one month and fine
which may extend to ten thousand rupees".
58. In section 222 of the principal Regulation, for the words "fine which may extend to
one thousand rupees", the following shall be substituted, namely:—

Amendment of
section 222.

"simple imprisonment for a term which may extend to one month and fine which
may extend to ten thousand rupees".
59. In section 223 of the principal Regulation,—
(i) for the words "one thousand rupees", the words "ten thousand rupees"
shall be substituted;

Amendment of
section 223.

(ii) for the words "two hundred rupees", the words "five hundred rupees" shall
be substituted.
60. Section 224 of the principal Regulation shall be omitted.
61. In section 225 of the principal Regulation, for the words "one thousand rupees",
the words "ten thousand rupees" shall be substituted.
62. In section 228 of the principal Regulation, in sub-section (2),—

Omission of
section 224.
Amendment of
section 225.
Amendment of
section 228.

<!-- page 36 -->

16

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(i) for the words "one thousand rupees", the words "ten thousand rupees"
shall be substituted;
(ii) for the words "hundred rupees", the words "five hundred rupees" shall be
substituted.
Amendment of
section 238.

63. In section 238 of the principal Regulation,—
(i) in sub-section (1),—
(a) for the words "two hundred rupees", the words "ten thousand rupees"
shall be substituted;
(b) for the words "twenty rupees", the words "five hundred rupees" shall
be substituted;
(ii) in sub-section (2),—
(a) for the words "one thousand rupees", the words "fifty thousand
rupees" shall be substituted;
(b) for the words "fifty rupees", the words "one thousand rupees" shall
be substituted.

Amendment of
section 241.

64. In section 241 of the principal Regulation, in sub-section (5), for the words "ten
rupees", the words "five thousand rupees" shall be substituted.

Amendment of
section 243.

65. In section 243 of the principal Regulation, in sub-section (3), for the words "five
hundred rupees", the words "fifty thousand rupees" shall be substituted.

Amendment of
section 245.

66. In section 245 of the principal Regulation, in sub-section (3), for the words "two
hundred and fifty rupees", the words "ten thousand rupees" shall be substituted.

Amendment of
section 246.

67. In section 246 of the principal Regulation, in sub-section (2), for the words "one
hundred rupees", the words "five thousand rupees" shall be substituted.

Amendment of
section 250.

68. In section 250 of the principal Regulation, for sub-section (2), the following
sub-section shall be substituted, namely:—
"(2) Whoever uses or allows to be used any place for any of the purposes
specified in sub-section (1), without a licence, or in contravention of any condition
subject to which a licence may have been granted under sub-section (1) shall, on
conviction, be punished with simple imprisonment for a term which may extend to
three months and fine which may extend to fifty thousand rupees if the contravention
is of clause (i) or clause (ii) of sub-section (1) and with fine which may extend to ten
thousand rupees if the contravention is of clause (iii) of that sub-section, and in the
case of continuing contravention of the said clause (i) or clause (ii), with further fine
of five thousand rupees, and of the said clause (iii) with further fine of one thousand
rupees, for every day after the first during which such contravention continues.".

Amendment of
section 252.

69. In section 252 of the principal Regulation, in sub-section (2), for the words "fine
which may extend to one hundred rupees", the following shall be substituted, namely:—
"simple imprisonment for a term which may extend to one month and fine which
may extend to ten thousand rupees".

Amendment of
section 255.

70. In section 255 of the principal Regulation, in sub-section (3), for the words "fine
which may extend to fifty rupees", the following shall be substituted, namely:—
"simple imprisonment for a term which may extend to three months and fine
which may extend to fifty thousand rupees".

Amendment of
section 257.

71. In section 257 of the principal Regulation, in sub-section (3),—

<!-- page 37 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

17

(i) for the words "five hundred rupees", the words "one lakh rupees" shall be
substituted;
(ii) for the words "fifty rupees", the words "one thousand rupees" shall be
substituted.
72. In section 258 of the principal Regulation, in sub-section (3),—
(i) for the words "five hundred rupees", the words "one lakh rupees" shall be
substituted;

Amendment of
section 258.

(ii) for the words "fifty rupees", the words "one thousand rupees" shall be
substituted.
73. In section 259 of the principal Regulation, in sub-section (3),—
(i) for the words "five hundred rupees", the words "one lakh rupees" shall be
substituted;

Amendment of
section 259.

(ii) for the words "fifty rupees", the words "one thousand rupees" shall be
substituted.
74. In section 261 of the principal Regulation, in sub-section (3), for the words "fine
which may extend to one thousand rupees", the following shall be substituted, namely:—

Amendment of
section 261.

"simple imprisonment for a term which may extend to three months and fine
which may extend to fifty thousand rupees and in the case of continuing offence with
further fine which may extend to one thousand rupees for every day after the first
during which such offence continues".
75. In section 262 of the principal Regulation, in sub-section (2),—
(i) for the words "fifty rupees", the words "ten thousand rupees" shall be
substituted;

Amendment of
section 262.

(ii) for the words "five rupees", the words "five hundred rupees" shall be
substituted.
76. In section 263 of the principal Regulation, in sub-section (3), for the words "fine
which may extend to five hundred rupees, and in the case of continuing offence with further
fine which may extend to fifty rupees", the following shall be substituted, namely:—

Amendment of
section 263.

"simple imprisonment for a term which may extend to one month and fine which
may extend to fifty thousand rupees, and in the case of continuing offence with
further fine which may extend to one thousand rupees".
77. In section 264 of the principal Regulation, in sub-section (3), for the words "fine
which may extend to two hundred rupees, and in the case of continuing offence with further
fine which may extend to twenty rupees", the following shall be substituted, namely:—

Amendment of
section 264.

"simple imprisonment for a term which may extend to one month and fine which
may extend to ten thousand rupees, and in the case of continuing offence with
further fine which may extend to five thousand rupees".
78. In section 268 of the principal Regulation, in sub-section (3),—
(i) for the word "imprisonment", the words "simple imprisonment" shall be
substituted;

Amendment of
section 268.

(ii) for the words "five hundred rupees", the words "five thousand rupees"
shall be substituted.
79. In section 273 of the principal Regulation, in sub-section (3), for the words "one
hundred rupees", the words "ten thousand rupees" shall be substituted.
80. In section 274 of the principal Regulation,—

Amendment of
section 273.
Amendment of
section 274.

<!-- page 38 -->

18

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(i) in sub-section (1),—
(a) in clause (i), for the words "three hundred rupees", the words "ten
thousand rupees" shall be substituted;
(b) in clause (ii), for the words "five hundred rupees", the words "twenty
thousand rupees" shall be substituted;
(ii) in sub-section (2), in clause (a), for the words "two hundred and fifty
rupees", the words "ten thousand rupees" shall be substituted.
Amendment of
section 275.

81. In section 275 of the principal Regulation,—
(i) in clause (a), for the words "one hundred rupees", the words "ten thousand
rupees" shall be substituted;
(ii) in clause (b), for the words "two hundred and fifty rupees", the words
"twenty thousand rupees" shall be substituted.

Amendment of
section 277.

82. In section 277 of the principal Regulation, in sub-section (2), for the words "fifty
rupees", the words "ten thousand rupees" shall be substituted.

Amendment of
section 278.

83. In section 278 of the principal Regulation, in sub-section (2), for the words "one
hundred rupees", the words "two thousand rupees" shall be substituted.

Amendment of
section 279.

84. In section 279 of the principal Regulation, in sub-section (6),—
(i) for the word "one-fourth", the word "one-half" shall be substituted;
(ii) for the words "two hundred and fifty rupees", the words "ten thousand
rupees" shall be substituted.

Amendment of
section 282.

85. In section 282 of the principal Regulation,—
(i) for the words "one hundred rupees", the words "ten thousand rupees" shall
be substituted;
(ii) for the words "ten rupees", the words "one thousand rupees" shall be
substituted.

Amendment of
section 283.

86. In section 283 of the principal Regulation, for the words "two hundred and fifty
rupees", the words "five thousand rupees" shall be substituted.

Amendment of
section 307.

87. In section 307 of the principal Regulation, in sub-section (1), in the proviso, in
clause (c), for the words "seven and a half per cent.", the words "fifteen per cent." shall be
substituted.

Amendment of
section 308.

88. In section 308 of the principal Regulation, for the words "fifty rupees", the words
"ten thousand rupees" shall be substituted.

Amendment of
section 323.

89. In section 323 of the principal Regulation, in clause (c), for the words and figures
"the Dadra and Nagar Haveli Panchayat Regulation, 1965", the words and figures "the
Dadra and Nagar Haveli Panchayat Regulation, 2012 " shall be substituted.

Insertion of a
new Schedule.

90. After Schedule VIII of the principle Regulation, the following Schedule shall be
inserted, namely:—
"SCHEDULE IX
[ See section 17(1)(n)]
Provisions as to disqualification on ground of defection
1. Disqualification on ground of defection.—(1) Subject to the provisions of
paragraph 2, a Councillor of the Council belonging to any political party shall be disqualified
for being a Councillor of the Council—

Reg. 3 of 1965.
Reg. 5 of 2012.

<!-- page 39 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

19

(a) if he has voluntarily given up his membership of such political party; or
(b) if he votes or abstains from voting in the Council contrary to any direction
issued by the political party to which he belongs or by any person or authority
authorised by it in this behalf, without obtaining, in either case, the prior permission
of such political party, person or authority and such voting or abstention has not
been condoned by such political party, person or authority within fifteen days from
the date of such voting or abstention.
Explanation.—For the purposes of this sub-paragraph, a Councillor of the
Council shall be deemed to belong to the political party, if any, by which he was, set
up as a candidate for election as such a Councillor.
(2) A Councillor of the Council who has been elected as such otherwise than as a
candidate set up by any political party shall be disqualified for being a Councillor of the
Council if he joins any political party after such election.
(3) Notwithstanding anything contained in sub-paragraphs (1) and (2), a person who,
on the commencement of the Dadra and Nagar Haveli Municipal Council (Amendment)
Regulation, 2018 is a Councillor of the Council shall,—
(i) where he was a member of a political party immediately before such
commencement, be deemed, for the purposes of sub-paragraph (1) of this paragraph,
to have been elected as a Councillor of such Council as a candidate set up by such
political party;
(ii) in any other case, be deemed to be a Councillor of the Council who has
been elected as such otherwise than as a candidate set up by any political party for
the purposes of sub-paragraph (2) of this paragraph.
2. Disqualification on ground of defection not to apply in case of merger.—(1) A
Councillor of the Council shall not be disqualified under sub-paragraph (1) of paragraph 1
where his original political party merges with another political party and he claims that he
and any other Councillors of his original political party—
(a) have become members of such other political party or, as the case may be,
of a new political party formed by such merger; or
(b) have not accepted the merger and opted to function as a separate group,
and from the time of such merger, such other political party or new political party or
group, as the case may be, shall be deemed to be the political party to which he
belongs for the purposes of sub-paragraph (1) of paragraph 1 and to be his original
political party for the purpose of this sub-paragraph.
(2) For the purposes of sub-paragraph (1) of this paragraph, the merger of the original
political party of a Councillor of the Council shall be deemed to have taken place if, and only
if, not less than two-thirds of the Councillors of such political party in the Council concerned
have agreed to such merger.
3. Decision on question as to disqualification on ground of defection.—(1) If any
question arises as to whether a Councillor of the Council has become subject to
disqualification under this Schedule, the question shall be referred to the Administrator and
the decision of the Administrator thereon shall be final.
(2) Before giving any decision on any such question referred under sub-paragraph (1),
the Administrator shall obtain the opinion of the Election Commission referred to in
section 5.
4. Rules.—The Administrator may make rules for giving effect to the provisions of
this Schedule, and in particular and without prejudice to the generality of the foregoing
powers, such rules may provide for—

<!-- page 40 -->

20

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II— SEC. 1]

(a) the maintenance of register or other records as to the political parties, if any,
to which different Councillors of the Council belong;
(b) the report which the leader of a political party in relation to a Councillor of
the Council shall furnish with regard to any condonation of the nature referred to in
clause (b) of sub-paragraph (1) of paragraph 1 in respect of such Councillor, the time
within which and the authority to which such report shall be furnished;
(c) the report, which a political party, shall furnish with regard to admission to
such political party of any Councillor of the Council and the officer of the Council to
which such report shall be furnished; and
(d) the procedure for deciding any question referred to in sub-paragraph (1) of
paragraph 3 including the procedure for any inquiry which may be made for the
purpose of deciding such question.".
————
RAM NATH KOVIND,
President.
————
DR. G. NARAYANA RAJU,
Secretary to the Govt. of India.

UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110 002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110 054.
MGIPMRND—5133GI(S3)—26-03-2018.

<!-- page 41 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—18

REGISTERED NO. DL—(N)04/0007/2003—18

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 15]

ubZ fnYyh] lkseokj] ekpZ 26] 2018@ pS= 5] 1940 ¼'kd½

No. 15]

NEW DELHI, MONDAY, MARCH 26, 2018/CHAITRA 5, 1940 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 26th March, 2018/Chaitra 5, 1940 (Saka)

THE ANDAMAN AND NICOBAR ISLANDS (MUNICIPAL)
AMENDMENT REGULATION, 2018
NO. 3 OF 2018
Promulgated by the President in the Sixty-ninth Year of the Republic of India as
follows:—
A Regulation to amend the Andaman and Nicobar Islands (Municipal)
Regulation, 1994.
In exercise of the powers conferred by article 240 of the Constitution, the President is
pleased to promulgate the following Regulation made by him:—
1. (1) This Regulation may be called the Andaman and Nicobar Islands (Municipal)
Amendment Regulation, 2018.

Short title and
commencement.

(2) It shall come into force on the date of its publication in the Official Gazette.
Reg. 5 of 1994.

2. Throughout the Andaman and Nicobar Islands (Municipal) Regulation, 1994
(hereinafter referred to as the principal Regulation), for the words "servant" and "servants",
wherever they occur, the words "employee" and "employees" shall respectively be
substituted, and such other consequential amendments as the rules of grammar may require
shall also be made.

Substitution
of reference
of certain
expressions
by certain
other
expressions.

3. In section 2 of the principal Regulation, in clause (26), after the words "Official
Gazette", the following shall be inserted, namely:—

Amendment
of section 2.

'and the expression "notified" shall be construed accordingly'.

<!-- page 42 -->

2

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

Amendment
of section 12.

4. In section 12 of the principal Regulation, in sub-section (2), after the word
"Constitution", the words "or on the ground of defection specified in the Schedule" shall be
inserted.

Amendment
of section 17.

5. In section 17 of the principal Regulation, for sub-sections (4), (5), (6), (7), (8), (9) and
(10), the following sub-sections shall be substituted, namely:—
"(4) Every Chairperson or Vice-Chairperson of the Municipality may be removed
from his office if a resolution of the Municipality expressing want of confidence in him
is passed by a majority of the total members of the Municipality present at a meeting
specially convened for the purpose:
Provided that no such resolution shall be moved unless,—
(a) a notice of the intention to move the resolution has been given within
such period as may be prescribed and signed by a majority of one-third members
of the Municipality; and
(b) it contains a proposal for election of a new Chairperson or
Vice-Chairperson of the Municipality.
(5) At any meeting of the Municipality, while any resolution for removal of the
Chairperson from his office is under consideration, the Chairperson, or while any
resolution for removal of the Vice-Chairperson from his office is under consideration,
the Vice-Chairperson, shall not, though he is present, preside.
(6) The meeting shall be presided over by the Vice-Chairperson if the motion is
against the Chairperson and by the Chairperson if the motion is against the
Vice-Chairperson.
(7) At any meeting of the Municipality, while any resolution for electing a
successor to the office of the Chairperson is under consideration, the candidate to the
office of the Chairperson, or while any resolution for electing a successor to the office
of the Vice-Chairperson is under consideration, the candidate to the office of the
Vice-Chairperson, shall not, though he is present, preside.
(8) The Chairperson or Vice-Chairperson shall have right to speak in, and
otherwise to take part in the proceeding of such meeting of the Municipality while any
resolution for removal from his office is under consideration in the Municipality and
shall be entitled to vote only in the first instance on such resolution or on any other
matter during such proceeding but not in the case of an equality of votes.
(9) The provisions of sub-sections (6), (7) and (8) shall apply mutatis mutandis
to the person contesting the election for the post of Chairperson or Vice-Chairperson
of the Municipality.
(10) The procedure to be followed for the meeting shall be such as may be
prescribed.".

Substitution of
new section
for section 27.

6. For section 27 of the principle Regulation, the following section shall be substituted,
namely:—

Punishment of
officers and
employees.

“27. (1) Without prejudice to the provisions of any law for the time being in
force, the following penalties may, for good reasons, be imposed upon any officer or
employee of the Municipality,—
(a) minor penalties—
(i) censure;
(ii) withholding of promotion;
(iii) recovery from his pay of the whole or part of any pecuniary loss
caused by him to the Municipality by negligence or breach of orders;
(iv) withholding of increments of pay;

<!-- page 43 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

(b) major penalties—
(i) reduction to a lower post on a fixed pay or a time scale or to a
lower stage in a time scale;
(ii) removal from the service, which does not disqualify from future
employment;
(iii) dismissal from the service, which ordinarily disqualifies from
future employment.
(2) The major penalties mentioned in clause (b) of sub-section (1) may be imposed
on an officer or employee of the Municipality by the authority competent to make the
appointment of the officer or employee:
Provided that the minor penalties mentioned in clause (a) of sub-section (1) may
be imposed by the Secretary (Urban Development), Andaman and Nicobar
Administration:
Provided further that suspension of an officer or employee pending inquiry into
the allegations against such officer or employee shall not be deemed to be a penalty
and shall be ordered only by the authority competent to make appointment to the post
held by such officer or employee.
(3) No officer or employee shall be imposed major penalties mentioned in
clause (b) or sub-section (1) unless he has been given a reasonable opportunity of
showing cause against such penalties:
Provided that this sub-section shall not apply where a person is reduced, removed
or dismissed on the ground of conduct which has led to his conviction on a criminal
charge.
(4) An appeal against any order imposing any penalty mentioned in
sub-section (1) may be made—
(i) in case if an order imposing any minor penalty mentioned in clause (a)
of sub-section (1), to the Secretary (Urban Development), Andaman and Nicobar
Administration;
(ii) in case if an order imposing any major penalty mentioned in clause (b)
of sub-section (1), to the Administrator.
(5) No such appeal may be entertained if not preferred within one months from
the date of receipt of the order appealed against by the officer or employee concerned.
(6) The appellate authority referred to in sub-section (4), within six months of
the date of the order passed, may at any time, either on his or its own motion or
otherwise, call for the records of any inquiry and revise any order made for reduction
to a lower post or rank or removal or dismissal from the service, and may—
(i) confirm, modify, reduce, enhance or set aside the order; or
(ii) remit the case to the authority which made the order to or any other
authority directing such authority to make such further enquiry as he or it may
consider proper in the circumstances of the case; or
(iii) pass such orders as he or it may deem fit.
(7) The Administrator may, at any time, either on his own motion or otherwise,
review any order passed under this section, when any new material or evidence which
could not be produced or was not available at the time of passing the order under
review and which has the effect of changing the nature of the case, has come, or has
been brought, to his notice.”.

<!-- page 44 -->

4
Insertion of
new Chapter
IIIA.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

7. After section 31 of the principal Regulation, the following Chapter shall be inserted,
namely:—
"CHAPTER IIIA
OMBUDSMAN FOR MUNICIPALITIES

Establishment,
term of office
and conditions
of service of
Ombudsman.

31A. (1) The Government shall, by notification in the Official Gazette, establish
an authority to be known as the Ombudsman for making investigations and inquiries,
in respect of charges on any action involving corruption or maladministration or
irregularities in the discharge of administrative functions by the members of the
Municipality under this Regulation.
(2) The Ombudsman shall consist of one member to be appointed by the
Administrator, on the recommendation of a committee referred to in sub-section (4).
(3) The Ombudsman shall not be a Government employee.
(4) The Committee referred to in sub-section (2) shall comprise of the following,
namely:—
(a) Secretary (Urban Development), Andaman and Nicobar Administration;
(b) a retired District Judge;
(c) a retired civil employee who has held a post in the Central Government
or State Government not below the rank of a Joint Secretary to the Government
of India; and
(d) two persons of impeccable integrity from the civil society nominated
by the Administrator.
(5) A person appointed to be the Ombudsman shall, before he enters upon his
office, make and subscribe before the Administrator or any other officer appointed in
that behalf by him, an oath or affirmation according to the form set out below:—
'I, A.B. having been appointed as the Ombudsman for the ______________
Municipality under the Andaman and Nicobar Islands (Municipal)
Regulation, 1994, do swear in the name of God/Solemnly affirm that I will bear
true faith and allegiance to the Constitution of India and I will duly and faithfully
and to the best of my ability, knowledge and judgment perform the duties of my
office without fear or favour, affection or ill-will'.
(6) The Ombudsman shall hold office for a term of three years from the date on
which he enters upon his office:
Provided that—
(a) the Ombudsman may, by writing under his hand addressed to the
Administrator, resign his office; and
(b) the person appointed as Ombudsman may be removed from his office
in the manner provided in section 31B.
(7) The salary and allowance payable to, and the other terms and conditions of
service of, the Ombudsman shall be such as may be prescribed.
(8) On expiry of his term of office as Ombudsman, he shall not be eligible for
re-appointment as Ombudsman or for further appointment to any office under the
Government or in any corporation, company, society or university by or under the
control of the Government.

Removal of
Ombudsman.

31B. (1) The Ombudsman may be removed from his office, by an order of the
Administrator, on the ground of proved misbehaviour or incapacity.

<!-- page 45 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

5

(2) The procedure for the removal of the Ombudsman under sub-section (1) and
for the investigation and proof of the misbehaviour or incapacity of the Ombudsman
shall be such as may be prescribed.
31C. (1) The Government may, in consultation with the Ombudsman provide
such officers and staff to assist the Ombudsman in the discharge of its functions
under this Regulation.

Staff of
Ombudsman.

(2) The salaries, allowances and other conditions of the service of the officers
and staff provided to the Ombudsman shall be such as may be prescribed.
(3) The Ombudsman may require the assistance of any officer of any Government
Department in order to ascertain the veracity of an allegation under investigation and
such officer shall be bound to render such assistance in addition and without detriment,
to his official duties.
(4) The Ombudsman may utilise the services of any person having experience
and expertise in any particular subject in deciding the questions before it.
31D. (1) The Ombudsman shall perform all or any of the following functions,
namely:—

Functions of
Ombudsman.

(i) investigate into any allegation contained in a complaint or on a reference
from the Government, or that has come to the notice of the Ombudsman;
(ii) inquire into any complaint in which corruption or maladministration of
a member of a Municipality is alleged;
(iii) pass an order on the allegation in the following manner, namely:—
(a) where the irregularity involves a criminal offence committed by a
member of the Municipality, the matter shall be referred to the appropriate
authority for investigation;
(b) where the irregularity causes loss or inconvenience to a citizen,
direct the Municipality to give him compensation and to reimburse the
loss from the person responsible for such irregularity;
(c) where the irregularity involves loss or waste or misuse of the
fund of the Municipality, realise such loss from those who are responsible
for such irregularity; and
(d) where the irregularity is due to omission or inaction, cause to
supply the omission and to rectify the mistake.
(2) In addition to the functions enumerated in sub-section (1), the Ombudsman
may pass interim order restraining the Municipality from doing anything detrimental to
the interest of the complainant, if it is satisfied that much loss or injury shall be caused
to the complainant due to the alleged act.
(3) The Ombudsman may, if it is of the opinion that the irregularity involves
corrupt practice for personal gain, by an order, impose penalty in addition to
compensation.

5 of 1908.

31E. (1) The Ombudsman shall, for the purpose of any investigation or inquiry
under this Regulation, have the same powers as are vested in a civil court while trying
a suit under the Code of Civil Procedure, 1908 in respect of the following matters,
namely:—
(a) summoning and enforcing the attendance of any witness and examining
him on oath;
(b) requiring the discovery and production of any document;
(c) receiving evidence on affidavits;

Powers of
Ombudsman.

<!-- page 46 -->

6

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(d) requisitioning any public record or document or copy of such record
or document from any office;
(e) issuing commissions for the examination of witness or documents; and
(f) any other matter which may be prescribed.
(2) Where the Ombudsman finds that the allegation contained in a complaint is
without any substance or trivial in nature, it may, by order, direct the complainant to
pay to the opposite party so much of the amount specified in the order by way of cost.
(3) Where the allegation contained in a complaint is about the loss or waste or
misapplication of the fund of the Municipality or in respect of the loss or inconvenience
caused to a citizen, the Ombudsman may, during inquiry, collect evidence, determine
the loss and direct in its order the amount to be realised from the person responsible.
(4) If the amount payable as per the order passed by the Ombudsman under
sub-section (2) or sub-section (3) is not paid within the period specified by it, the same
shall be recoverable as if it were an arrears of land revenue.
Service of
Government
Departments.

31F. The Government may, at the request of the Ombudsman make available the
services of officers and employees of the Government including police personnel to
assist the Ombudsman in the conduct of investigation and inquiry, and in respect of
such functions, such officer or employee shall be deemed to be the officer or employee
of the Ombudsman.

Investigation.

31G. (1) The Ombudsman may, in accordance with the provisions of this
Regulation, investigate into any complaint filed before it under this Regulation.
(2) Notwithstanding anything contained in this Regulation, the Government
may refer any allegation of corruption or maladministration against a Municipality or a
member of the Municipality which is within its knowledge or brought to its notice, to
the Ombudsman and the Ombudsman shall investigate into it as if, it was a complaint
filed under this Regulation.
(3) The Ombudsman may, on receipt of a complaint, conduct an investigation in
the matter and where there is a prima facie case, it may conduct a detailed inquiry
under section 31H.
(4) The Ombudsman shall not investigate or inquiry into matters relating to,—
(a) any matter in respect of which a formal and public inquiry has been
ordered by the Government;
(b) any matter in respect of which a remedy is available from the Court for
Municipality;
(c) any matter in respect of which an inquiry has been ordered under the
Commission of Inquiries Act, 1952 or any matter pending before a Court; and
(d) any complaint filed after the expiry of three years from the date on
which the matter complained against has taken place:
Provided that the Ombudsman may entertain such complaint, if the
complainant satisfies that he had sufficient reason for not filing the complaint
within the specified period.

Inquiry.

31H. (1) After an investigation, if the Ombudsman is satisfied that—
(a) the complaint is frivolous or vexatious or is not made in good faith; or
(b) there is no sufficient ground to initiate proceedings; or
(c) other remedies are available to the complainant and it shall be more
beneficial for the complainant to avail of such remedies in view of the
circumstances of the case,

60 of 1952.

<!-- page 47 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

7

it may, after recording its findings and stating the reason therefor, dispose of the
complaint and communicate the same to the complainant.
(2) If the Ombudsman is of the opinion that there is a prima facie case against a
member of the Municipality complained of, it shall record its findings to this effect and
send notices of the proposed inquiry to the complainant and to the opposite party.
(3) Subject to the provisions of this Regulation and rules made thereunder, the
Ombudsman shall regulate its own procedure for the purpose of holding its meeting
(including time and place of sitting).
(4) In any proceeding before the Ombudsman, no legal practitioner shall be
permitted to represent any person, unless the Ombudsman, by an order, permits a
person to be represented by a legal practitioner for reasons to be recorded.
31-I. (1) Notwithstanding anything contained in any other law for the time being
in force, any proceeding relating to a member of the Municipality which is pending
before any authority under this Regulation before the establishment of the Ombudsman
under sub-section (1) of section 31A, shall, on such establishment, be transferred to
the Ombudsman and the Ombudsman shall decide the proceeding in accordance with
the provisions of this Regulation.

Existing cases
to be
transferred to
Ombudsman.

(2) All cases, with regard to the loss, wastage and misappropriation of any land
of the Local Self Government Institution, pending before the Government or any other
authority shall be transferred to the Ombudsman and the Ombudsman shall dispose of
the proceeding in accordance with the provisions of this Regulation.
31J. (1) If, after an investigation or inquiry, the Ombudsman finds that there is a
prima facie case against the accused, the Ombudsman may, for the reasons to be
recorded in writing, refer the complaint to a competent authority to initiate prosecution.

Initiation of
prosecution.

(2) The competent authority referred to in sub-section (1) shall conduct a detailed
inquiry and if necessary, shall frame the charge.
31K. (1) The Ombudsman may consider and dispose of complaints other than
those involving criminal offences, in the following manner, namely:—

Disposal of
complaints.

(i) award of compensation, to a citizen in case of loss or grievance;
(ii) order the recovery of loss caused to the Municipality from the person
responsible;
(iii) order the supply of omission or rectification of defects due to inaction;
(iv) order the recovery of loss from the accused failing which, order
realisation through revenue recovery proceedings; and
(v) order other necessary remedial measures considering the facts and
circumstances of the case.
(2) Where the Ombudsman finds that the procedure or practice regarding the
administration of the Municipality gives room for complaint, it may give suggestions
to the Government or the Municipality relating to the measures for avoiding the
recurrence of such complaint.
(3) The Ombudsman shall give annually a detailed report regarding the
performance of its functions under this Regulation to the Government.
31L. (1) The Government may make rules to carry out the provisions of this
Chapter.
(2) In particular, and without prejudice to the generality of the foregoing power,
such rules may provide for all or any of the following matters, namely:—
(a) the salary and allowances payable to, and other terms and conditions
of service of, the Ombudsman under sub-section (7) of section 31A;

Power to make
rules under this
Chapter.

<!-- page 48 -->

8

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(b) the procedure for the removal of the Ombudsman and investigation of
proof of the misbehaviour or incapacity under sub-section (2) of section 31B;
(c) the salary and allowances payable to, and other terms and conditions
of service of, the officers and staff provided to the Ombudsman under
sub-section (2) of section 31C; and
(d) any other matter which is required to be, or may be, prescribed.".
Amendment
of section 32.

8. In section 32 of the principal regulation, after sub-section (2), the following
sub-section shall be inserted, namely:—
"(3) Notwithstanding anything contained in this Regulation or the rules made
thereunder, the giving or recording of vote by Electronic Voting Machine may be
adopted in such ward or wards of the Municipality as the Election Commission may,
having regard to the circumstances of each case, specify.
Explanation.—For the purposes of this section, "Electronic Voting Machine"
means any machine or apparatus whether operated electronically or otherwise, used
for giving or recording of vote and any reference to a ballot box or ballot paper in this
Regulation or the rules made thereunder shall, save as otherwise provided, be construed
as including a reference to such Electronic Voting Machine wherever such Electronic
Machine is used at any election.".

Amendment
of section 47.

9. In section 47 of the principal Regulation, for clause (b), the following clause shall be
substituted, namely:—
"(b) subject to the provisions of this Regulation, the Chairperson shall have
general powers of inspection and may call any record of the Municipality from the
Secretary and the same shall be made available to him and shall be returned by him
within fifteen days from the date they are made available to him.".

Amendment
of section 52.

10. In section 52 of the principal Regulation, after sub-section (3), the following
sub-section shall be inserted, namely:—
"(4) The Secretary shall exercise all the powers of the Head of the Department as
per the provisions of the General Financial Rules in respect of the Departments of
Union territory.".

Amendment
of section
108.

11. In section 108 of the principal Regulation, in sub-section (2), for the words "shall
be punishable with fine which may extend to twenty rupees and with a further fine not
exceeding ten rupees", the words "shall be liable to pay fine which may extend to such
amount as may be notified by the Government and with a further fine not exceeding such
amount as may be notified by the Government" shall be substituted.

Amendment
of section
115.

12. In section 115 of the principal Regulation, for the words "shall be punishable with
fine which may extend to fifty rupees", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government" shall be substituted.

Amendment
of section
116.

13. In section 116 of the principal Regulation, for the words "shall be punishable with
fine which may extend to twenty rupees", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government" shall be substituted.

Amendment
of section
119.

14. In section 119 of the principal Regulation, in sub-section (4), for the words "shall
be punishable with fine which may extend to ten rupees", the words "shall be liable to pay
fine which may extend to such amount as may be notified by the Government" shall be
substituted.

Amendment
of section
121.

15. In section 121 of the principal Regulation, in sub-section (2), for the words "shall
be punishable with fine which may extend to twenty rupees", the words "shall be liable to
pay fine which may extend to such amount as may be notified by the Government" shall be
substituted.

Amendment
of section
123.

16. In section 123 of the principal Regulation, for the words "shall be punishable with
fine which may extend to fifty rupees", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government" shall be substituted.

<!-- page 49 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

9

17. In section 124 of the principal Regulation, for the words "shall be punishable with
fine which may extend to fifty rupees", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government" shall be substituted.

Amendment of
section 124.

18. In section 125 of the principal Regulation, in sub-section (2), for the words "shall
be punishable with fine which may extend to two hundred rupees", the words "shall be liable
to pay fine which may extend to such amount as may be notified by the Government" shall be
substituted.

Amendment
of section
125.

19. In section 127 of the principal Regulation, in clause (c), for the words "shall be
punishable with fine which may extend to twenty rupees", the words "shall be liable to pay
fine which may extend to such amount as may be notified by the Government" shall be
substituted.

Amendment of
section 127.

20. In section 129 of the principal Regulation, in sub-section (4), for the words "shall
be punishable with fine which may extend to fifty rupees", the words "shall be liable to pay
fine which may extend to such amount as may be notified by the Government" shall be
substituted.

Amendment
of section
129.

21. In section 130 of the principal Regulation, in sub-section (2), for the words "shall
be punishable with fine which may extend to ten rupees", the words "shall be liable to pay a
fine which may extend to such amount as may be notified by the Government" shall be
substituted.

Amendment
of section
130.

22. In section 137 of the principal Regulation, in sub-section (4), for the words "shall
be punishable with fine which may extend to fifty rupees and in the case of continuing
offence with a further fine which may extend to ten rupees", the words "shall be liable to pay
a fine which may extend to such amount as may be notified by the Government and in the
case of continuing offence, with a further fine which may extend to such amount as may be
notified by the Government" shall be substituted.

Amendment of
section 137.

23. In section 138 of the principal Regulation, for the words "shall be punishable with
fine which may extend to rupees fifty", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government" shall be substituted.

Amendment
of section
138.

24. In section 141 of the principal Regulation, in sub-section (2), for the words "rupees
one hundred and in the case of continuing failure, with a further fine which may extend to ten
rupees", the words "such amount as may be notified by the Government and in the case of
continuing failure, with a further fine which may extend to such amount as may be notified by
the Government" shall be substituted.

Amendment
of section
141.

25. In section 144 of the principal Regulation, for the words "shall be punishable with
fine which may extend to twenty rupees and in the case of continuing offence with further
fine which may extend to five rupees", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government and in the case of continuing
offence, with further fine which may extend to such amount as may be notified by the
Government" shall be substituted.

Amendment of
section 144.

26. In section 145 of the principal Regulation,—
(i) for the words "shall be punishable with fine which may extend to twenty-five
rupees", the words "shall be liable to pay fine which may extend to such amount as
may be notified by the Government" shall be substituted;

Amendment of
section 145.

(ii) in the Explanation, for the word "punishable", the word "fined" shall be
substituted.
27. In section 146 of the principal Regulation, for the words "shall be punishable with
fine which may extend to twenty rupees", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government" shall be substituted.

Amendment
of section
146.

<!-- page 50 -->

10

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

Amendment
of section
150.

28. In section 150 of the principal Regulation, in sub-section (1), for the words "shall
be punishable with fine which may extend to fifty rupees", the words "shall be liable to pay
fine which may extend to such amount as may be notified by the Government" shall be
substituted.

Amendment
of section
155.

29. In section 155 of the principal Regulation, for the words "shall be punishable with
fine which may extend to ten rupees", the words "shall be liable to pay fine which may extend
to such amount as may be notified by the Government" shall be substituted.

Amendment
of section
156.

30. In section 156 of the principal Regulation, for the words "shall be punishable with
fine which may extend to twenty rupees", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government" shall be substituted.

Amendment
of section
157.

31. In section 157 of the principal Regulation, in sub-section (2), for the words "shall
be punishable with fine which may extend to twenty rupees", the words "shall be liable to
pay fine which may extend to such amount as may be notified by the Government" shall be
substituted.

Amendment
of section
158.

32. In section 158 of the principal Regulation, for the words "shall be punishable with
fine which may extend to twenty rupees", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government" shall be substituted.

Amendment
of section
159.

33. In section 159 of the principal Regulation, for the words "shall be punishable with
fine which may extend to twenty rupees", the words "shall be liable to pay fine which may
extend to such amount as may be notified by the Government" shall be substituted.

Amendment
of section
160.

34. In section 160 of the principal Regulation,—
(i) in sub-section (1), for the words "shall be punishable with fine which may
extend to fifty rupees", the words "shall be liable to pay fine which may extend to such
amount as may be notified by the Government" shall be substituted;
(ii) in sub-section (2), for the words "one hundred rupees", the words "ten
thousand rupees" shall be substituted.

Amendment
of section
203.

35. In section 203 of the principal Regulation,—
(a) in sub-section (2), after clause (a), the following clause shall be inserted,
namely:—
"(aa) the period of notice under clause (a) of proviso to sub-section (4) of
section 17;
(ab) the procedure for the special meeting under sub-section (10) of
section 17;";
(b) in sub-section (3), for the words "shall be punishable with fine which may
extend to fifty rupees", the words "shall be liable to pay fine which may extend to such
amount as may be notified by the Government" shall be substituted.

Insertion of
new Schedule.

36. After Chapter XIV of the principal Regulation, the following Schedule shall be
inserted, namely:—
“THE SCHEDULE
[See section 12(2)]
Provision as to disqualification on ground of defection
1. Disqualification on ground of defection.—(1) Subject to the provisions of
paragraph 2, member belonging to any political party shall be disqualified for being a
member—
(a) if he has voluntarily given up his membership of such political party; or
(b) if he votes or abstains from voting in the Municipality contrary to any
direction issued by the political party to which he belongs or by any person or

<!-- page 51 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

11

authority authorised by it in this behalf, without obtaining, in either case, the
prior permission of such political party, person or authority and such voting or
abstention has not been condoned by such political party, person or authority
within fifteen days from the date of such voting or abstention.
Explanation.—For the purposes of this sub-paragraph, a member shall be
deemed to belong to the political party, if any, by which he was set up as a
candidate for election as such a Member.
(2) A member who has been elected as such otherwise than as a candidate set up
by any political party shall be disqualified for being a Member if he joins any political
party after such election.
(3) Notwithstanding anything contained in sub-paragraphs (1) and (2), a person
who, on the commencement of the Andaman and Nicobar Islands (Municipal)
Amendment Regulation, 2018 is a Member shall,—
(i) where he was a Member of a political party immediately before such
commencement, be deemed, for the purpose of sub-paragraph (1) of this
paragraph, to have been elected as a member of such Municipality as a candidate
set up by such political party;
(ii) in any other case, be deemed to be a member who has been elected as
such otherwise than as a candidate set up by any political party for the purpose
of sub-paragraph (2) of this paragraph.
2. Disqualification on ground of defection not to apply in case of merger.—(1)
A member shall not be disqualified under sub-paragraph (1) of paragraph 1 where his
original political party merges with another political party and he claims that he and
any other Members of his original political party—
(a) have become Members of such other political party or, as the case may
be, of a new political party formed by such merger; or
(b) have not accepted the merger and opted to function as a separate
group, and from the time of such merger, such other political party or new political
party or group, as the case may be, shall be deemed to be the political party to
which he belongs for the purposes of sub-paragraph (1) of paragraph 1 and to
be his original political party for the purposes of this sub-paragraph.
(2) For the purposes of sub-paragraph (1), ther merger of the original political
party of a member shall be deemed to have taken place if, and only if, not less than twothirds of the Members of such political party in the Municipality concerned have
agreed to such merger.
3. Decision on question as to disqualification on ground of defection.—(1) If
any question arises as to whether a member has become subject to disqualification
under this Schedule, the question shall be referred to the Administrator and the decision
of the Administrator thereon shall be final.
(2) Before giving any decision on any such question referred under subparagraph (1), the Administrator shall obtain the opinion of the Election Commission.
4. Rules—The Administrator may make rules for giving effect to the provisions
of this Schedule, and in particular and without prejudice to the generality of the foregoing
powers, such rules may provide for—
(a) the maintenance of registers or other records as to the political parties,
if any, to which different members belong;
(b) the report which the leader of a political party in relation to a member
shall furnish with regard to any condonation of the nature referred to in

<!-- page 52 -->

12

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II— SEC. 1]

clause (b) of sub-paragraph (1) of paragraph 1 in respect of such member, the
time within which and the authority to which such report shall be furnished;
(c) the report, which a political party, shall furnish with regard to admission
to such political party of any member and the officer of the Municipality to
which such report shall be furnished; and
(d) the procedure for deciding any question referred to in paragraph 3
including the procedure for any inquiry which may be made for the purpose of
deciding such question.”.
————

RAM NATH KOVIND,
President.

————

DR. G. NARAYANA RAJU,
Secretary to the Govt. of India.

UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110 002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110 054.
MGIPMRND—5134GI(S3)—26-03-2018.
