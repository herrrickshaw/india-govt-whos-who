---
doc_id: "f20fe4ba6c2dd2a2"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/cd6625797f025e2ac39414d703c05f75.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Sanction Dated 29th September, 2023 Release of an amount to Rs. 71,7212,328"
date: "2025-07-14"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2e46a85dc5d2f18d"
---

<!-- page 1 -->

No. 3(2)/2021-SSS (E.55244)
£overnment of india
Ministry of Commerce & Industry
Department for Promotion of Industry & Internal Trade
(Special Scheme Section)

Udyog Bhawan, New Delhi
Dated: 29th September, 2023

To
The Accounts Officer,
Pay & Accounts Office,

Department for Promotion of Industry & Internal Trade,
Udyog Bhawan,
New Delhi.

Sub: Release of an amount of Rs. 71,72,12,328/- (Rs. Seventy One Crore Seventy Two Lakh
Twelve Thousand Three Hundred Twenty Eight only) as Central Capital Investment Incentive
for access to credit (CCIIAC) Subsidy during the year, 2023-24 in favour of SIIDCUL.
Sir,

The undersigned is directed to convey sanction of the President to the release of an amount

of Rs.71,72,12,328/- (Rs. Seventy One Crore Seventy Two Lakh Twelve Thousand Three
Hundred Twenty Eight only) for payment of Central Capital Investment Incentive for access to
credit (CCIIAC) under Industrial Development Scheme (IDS) 20 17 for the financial year 2023-24
in respect of 36 beneficiary units of Uttarakhand (as per list enclosed at Annexure), on the basis
of recommendations of the State Level Committee concerned and as per existing terms and
conditions of the scheme.
2.
As per the Notification No.2(2)/2018-SPS dated 23'd April,20 18, SIIDCUL has been
notified as the nodal agency for disbursal of central incentives in the state of Uttarakhand
under IDS, 2017.

3.
Vide mail dated 02.08.2023, SIIDCUL informed that no unspent amount is pending of
disbursement under the IDS, 2017.
4.
Also, it is hereby informed that the subsidy in r/o the claims of the units mentioned at s.
nos. (9), (12), (14), (18), (21) and (27) at annexure may be released only after the furnishing of
requisite details/documents by the said units to the DPIIT, as suggested by the IPAI (copy
enclosed) in their audit report. Further, details of units that have changed their bank accounts, if
any, may also be shared with the DPIIT so as to subsequently take approval of the Competent
Authority on the same before releasing subsidy to them.

„,„=,„,Mg&Cb%.~„„,„RE
an nfbg/Under Seueta,y
dIRt\d 3l1 BEhT fqRq/Min. of C. & I.

MT

MttH 3h{ :#RftB aFm nvq/Oepu. for PI & IT
TE1TTT

Ud'/co

A

cH

fF)

I •r

r 1 ;1

:

!

!

! \ r /

I

v I

il

<!-- page 2 -->

-25. '

The sanctioned amount may be released in favour of State Infrastructure & Industrial
Development Corporation of Uttarakhand Ltd.(SIIDCUL), Dehradun to their Bank Account
No.705020110000513, Name of Account SIIDCUL (IDS), Bank of India, Main Branch,
Dehradun MICR Code: 248013002. IFSC/RTGS Code BKID0007050.
6.

The due date for submission of UC in respect of this release is within twelve months of the
closure of the financial year.

7.
This is the first release under this object would be Rs. 71,72,12,328/- (Rs. Seventy One
Crore Seventy Two Lakh Twelve Thousand Three Hundred Twenty Eight only) during the
current financial year 2023-24.
8.

The expenditure is debit to the following Head of Account:-

2885 Other Outlay on Industries & Minerals (Major Head)
02
Development of Backward Areas (Sub Major Head)
02.101 Subsidies (Minor Head)
18.01 –
Industrial Development Scheme for the States ofHimachal Pradesh and
Uttarakhand, 2017

18,01.33 Subsidies

Under Demand No. 11 for the year, 2023-24.
Release of the above-mentioned amount to SIIDCUL is subject to the following terms and
conditions:
SIIDCUL will maintain a separate account of the fUnds released by this Department
towards “Central Capital Investment Incentive for access to credit (CCIIAC) under
Industrial Development Scheme (IDS) 2017” for disbursal of subsidy to the beneficiary
units as per details enclosed.
9

1

ii.

SIIDCUL shall verify each & every claim before disbursement and shall disburse the
incentive to the 'eligible units immediately on receipt funds from DPIIT.

Iii.

The disbursal made by SIIDCUL from the Grant shall be open to inspection and audit by
the sanctioning authority.

I V.

After disbursement of incentive for the purpose for which it has been sanctioned,
SIIDCUL, shall submit to the Department for Promotion of Industry & Internal Trade, New
Delhi the Utilization certificate within twelve months of the closure of the financial year
as per GFR,2017 and no further funds will be released unless the entire amount previously
released is fully utilized and utilization certificates are furnished. The Utilization
Certificate will be signed by the Managing Director, SIIDCUL.

<!-- page 3 -->

'1
MJ

n

V.

L
tRalso
the names of the
beneficiaries, the amount of subsidy released to each unit, the date of their application, the
date of approval of the SLC, the date ofdisbursal of subsidy etc, shall be furnished by
SIIDCUL to this Department by the 10th day of the month following the end of each quarter.

Vl.

SIIDCUL would devise a suitable mechanism to ensure adequate transparency and fairness
in the disbursal of subsidy. SIIDCUL shall furnish an undertaking that they have been
following the provision of Rule-4 (1)(a) and (b) of RTI Act, 2005.

ViI.

SIIDCUL would furnish a performance-cum-achievement report at the end of each
financial year highlighting the number of units set up in the State, investment made and the
employment generated etc., and the quantitative vis-a-vis qualitative outcome achieved out
of Central Capital Investment Incentive for access to credit (CCIIAC) under Industrial
Development Scheme (IDS) 20 17 Scheme including suggestions/policy reform initiatives
for further refinement of the Scheme.

vlil.

SIIDCUL to ensure that amount is released to individual unit(s) only after verifying that
these units have not been paid earlier.

IX.

SIIDCUL to ensure that payment to beneficiaries units should be made through PFMS
directly to their account within 10 days.

10.

The undersigned acts as DDO for purpose of this sanction.

11 .

This issues with the concurrence of AS&FA vide Note# 86 dated 28.09.2023 and approved

by Secretary, DPIIT vide Note#87 dated 29.09.2023 .
Yours faithfully,

.@,)),,A
(Ganesh H. Nikhare)

Under Secretary to the Govt. of India

r) t =

F P r i n C iIP a 1 D i re C t O r O f :

U ! i ! ) E C O n 0 m iC an d S e W i C e S :=::tgggg§

rFI bfI

2) Director of Industries, Directorate of Industries, Govt. of Uttarakhand, with the request
to seek and forward requisite documents/information in r/o the units mentioned at s.
nos. (9), (12), (14), (18), (21) and (27) at annexure to this Department.
3) Finance-II Section, Integrated Finance Wing, Department for Promotion of Industry &
Internal Trade.
4) CCA, DIPP-with the request to audit 10% cases after disbursement by SIIDCUL.
5) The Managing Director, SIIDCUL
6) Budget & Accounts Section.

<!-- page 4 -->

No. 3(2)/2021-SSS (E.55244)

Dated: 22-d September, 2023
Annexu re

List of 36 Units
S.No

Name of the

IDS Number

Industrial
Unit

Date of
SLC
Submission DATE
of Claim
on Portal

Amt

Amt

approved
by SLC
(Rs.)

approved

8629949

5235044+

(in Rs.)

1.

M/s Graphix

IDS/UK/1127 25.02.202 1

27. 12.202 1

2.

Shree Kunj
Bihari Food

IDS/UK/ 160

17.04.2019

06.06.2022 678749

678749

Products
3.

Shrigee Agro
Foods

IDS/UK/326

23.05.2019

06.06.2022

15871901

15871901

4.

Adarsh Poly

IDS/UK/139

23.05.2019

04.08.2022

1191754

1191754

Shirdi
Organics Pvt
Ltd
Devarpan
Foods pvt
Ltd
M/S
Mahalaxmi
Polypack Pvt
Ltd
Shuklambara
Papers Pvt
Ltd
Up Alums
Pvt Ltd
Banke Bihari
Buidcon

IDS/UK/488

07.09.2019

06.06.2022

39848 17

39848 17

IDS/UK/114

19.09.2019

04.08.2022

25627581

25627581

IDS/UK/026

29.09.20 19

06.06.2022 48693 121

48693 121

IDS/UK/949

07. 1 1.2019

06.06.2022 34513663

345 13663

IDS/UK/075

25.11.2019

04.08.2022 .9205 144

9205 144

ID-S/UK/016

18.02.2020

04.08.2022 7236876

7236876

11.

Parksons

IDS/UK/238

29.02.2020

06.06.2022 36658174

36658 174

12.

Packaging
Ltd
Dwarika
Food
Products

IDS/UK/050

09.03.2020

06.06.2022 50000000

50000000

13.

Aurangabad

IDS/UK/284

19.05.2020

04.08.2022

12506242

Pack
5.

6.

7.

8.

9.
10.

Auto
Engineering
pvt Ltd

12506242

<!-- page 5 -->

S/UK/408

22

jj::" :'"“=* '*.:::::: -:::::::: ::===1:
::===::

Unit Of

Ghaziabad
Precision

Products PW

Ltd)

16. 1Devrishi

m m

Papers pW
1 7.

m

18.

Obeetee

Ltd

m O
e:pw /IDS/UKm m 9
qe+
m m

5

Ltd

1

8

Ltd

I

2

2 1•

/

I
Components

pVt. Ltd.

22' Kaiin

1na;uk;iii:sg

„„,„,

„*„.;,

„„

:;*„..,

LLP
23'

Mv–NII
Industries

Th

0

Printers

Im

25.

T

Foods

26- o

o

industries
I[DS m K9

Pvt
Ltd(Unit.II

27.

111

IFM
Grou I

28.northern
Plywood
Products

1

io 2 3 9 3 1

ID S n1bJK72

0 52

m. 7./>/F
ViVI

qq. fqRgT+/GANESH A. NIKHARE
Tanfin/Under Secretary

gIRt\at a? sth! Hdt,iq/Min. ,t c. & I.

wh

1 1o 2 3 9 3 1

Tfqdq ait af3ft6 nrqr? thin/Depu.for PI & IT
TT?FT mR. He R?d\-110nr1
!Jclvoa [RhaYden. blaT : .'::: '. . _ .311

<!-- page 6 -->

29. 1Murliwala I IDS/UK/223 121.06.2021 104.08.2022 15208461 15208461
Sto

Industry
Limited

8

1

1

Herbal

1

/

2

0

63

Heritage
Projects Pvt

Ltd

r

1a

Steels

Private
Limited

r
Spintex
Private
Limited

ov

2

Limited Unit
11

2

raa
erbaria

r

a

Ltd
7

Total
+ Actual approved amount of M/s GRAPHIX is Rs. 8629949/-(Placed at sl. no.1) but due to non
availability of funds, part payment of Rs. 33,94,904/- was already released vide sanction dated
26.03.2022 . The balance amount of the said unit Rs. 52,35,044/. is being paid.

glaidl,sL__
