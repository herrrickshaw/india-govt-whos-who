---
doc_id: "f5b29ffa8abfd620"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/SC_advisory_COVID_2021637556816552307687.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "COVID - 19 - Advisory for Senior Citizens"
date: ""
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a72fed5fc341707c"
---

<!-- page 1 -->

(©)
aaa
Ministry of Social Justice and Empowerment
Government of India
The 27" April, 2021
Advisory for Senior Citizens during COVID-19
Senior citizens above the age of 60 years face an increased risk in COVID times. This is an
advisory for Senior Citizens and their caregivers on how to protect them from increased health
tisk during this period.
RUA OM Caso me ARAM TO Leo 1 2
Pos | nts  | s

1. Stay within the house all the time. 1. Don’t come in close contact with

someone who is having

2. Avoid having visitors at home. fever/cough/breathing difficulty.

3. If meeting is essential, maintain a distance | 2. Don’t shake hands or hug your friends

of 2 yard. and near ones.

4. If living alone, one can consider depending | 3. Don’t go to crowded places like parks,

on healthy neighbours for acquiring markets and religiousplaces.
essentials for home.
4. Don’t cough or sneeze into your bare

5. Avoid small and large gatherings at allcost. hands.

6. Remain actively mobile within thehouse. 5. Don’t touch your eyes, face, nose and

tongue.

7. Consider doing light exercise and yoga at
home. 6. Don’t self-medicate.

8. Practice meditation. 7. Don’t go out unless it is absolutely

essential.

9. Maintain hygiene by washing hands. a हे हे
Especially before having meals and after | 8. Don’t invite family members andfriends
using the washroom. This can be done by at home.
washing hands with soap and water for at
least 20 seconds. 9. Don’t go to hospital for routine checkup

or follow up.

10. Clean frequently touched objects with
disinfectant regularly. 10.As_ far as possible make _ tele-

consultation with your healthcare

11. Sneeze and cough either into your elbow or provider.
into tissue paper/handkerchief. After
coughing or sneezing dispose of the tissue

<!-- page 2 -->

paper in a closed bin/wash your
handkerchief and hands.
12. Ensure proper nutrition through home
cooked fresh hot meals, hydrate frequently
and take fresh juices to boost immunity.
13.Take your daily prescribed medicines
regularly.
14. Monitor your health. If you develop fever,
cough and/or breathing difficulty or any
other health issue, immediately contact
nearest health care facility and follow the
medical advice.
15. Talk to your family members (not staying
with you), relatives and friends via call or
video conferencing, take help from family
members if needed.
16. Postpone your elective surgeries (if any).
Due to Summer, avoid dehydration. Consume an adequate amount of water.
(Caution for individuals with pre-existing Heart and Kidney disease)
Advisory for Caregivers of dependent Senior Citizens
pO | Don’ts
1. Wash your hands before helpingthe older 1. Don’t go near senior citizens if
individual. suffering from fever/cough/breathing
difficulty.
2. Cover nose and mouth adequately while
attending on the senior citizen. 2. Don’t keep senior citizens completely
bed-bound.
3. Clean the surfaces which are frequently
used. These include spectacles, walking | 3. Don’t touch senior citizens without
cane, walker, wheel-chair,bedpan etc. washing hands.
4. Assist the older individual and help
her/him in washing hands.
5. Ensure proper food and water intake by
senior citizens.
6. Monitor his/her health.

<!-- page 3 -->

¢ Contact helpline if the older adult has the following symptoms:
o Fever, with or without body ache.
o New-onset, continuous cough, shortness of breath.
o Unusually poor appetite, inability to eat,
dvisory for Senior Citizens on mental well-bein:
|. '"* | | ?”"७४.“ |'|
1. Communicate with relatives at home. 1. Don’t isolate yourself.
2. Communicate with neighbours, provided | 2. Don’t confine oneself in a room.
social distancing is followed, and gathering
of people is avoided. 3. Don’t follow any sensational news or
social media posts.
3. Provide a peaceful environment.
4. Don’t spread or share any unverified
4. Rediscover old hobbies like painting, news or information further.
listening to music, reading etc.
5. Avoid tobacco, alcohol and other
5. Make sure to access and believe only the drugs to avoid loneliness or
most reliable sources of information. boredom.
6. If you have an already existing mental
illness, call helpline number
(08046110007).
e Contact helpline in case of:
o Change in mental status, such as excessively drowsy during the day, not
responding, speaking inappropriately.
o New onset of inability to recognise relative which he/she could do before.
structions for NGOs running Old Age Homes/Senior Citizen Homes:
All the Implementing Agencies, NGOs and Regional Resource Centres are advised to take precautionary
measures as given below:
(1) NGOs must regularly take body temperature of all senior citizens in the Home and check their
respiratory symptoms.
(2) NGOs must ensure that such people maintain proper hygiene and physical distancing.
(3) Ensure proper cleaning and frequent sanitization of the premises, particularly the frequently
touched surfaces.
(4) Ensure regular supply of hand sanitizers, soap and running water in the washrooms.

<!-- page 4 -->

(5) Discourage entry of visitors in the premises/complex.

(6) Place hand sanitizer at the entry of the premises.

(7) Shaking hands and hugging as matter of greeting to be avoided.

(8) For immediate medical attention, please call State Helpline number or 24x7 Helpline number of

Ministry of Health and Family Welfare, Government of India at 011-23978046.
(Guidance on correct use of Masks/Face Shields:

(1) _ Perform hand hygiene before putting on the mask.

(2) Do not use a damaged mask.

(3) Avoid touching the mask while wearing it. If the mask is accidently touched, perform hand
hygiene.

(4). Mask should cover from the bridge of the nose to below the chin and cheeks on either side of the
mouth.

(5) | Remove the mask using the appropriate technique. Do not touch the front of the mask, but rather
untie it from behind.

(6) Replace the mask as soon as it becomes damp with a new clean, dry mask.

(7) Perform hand hygiene immediately afterward discarding a mask.

(8) Do not remove the mask to speak.

(9) Do not share your mask with others.

(10) Wash fabric masks in soap or detergent and preferably hot water at least once a day.

(11) Face shields are to be considered to provide a level of eye protection only and should not be
considered as an equivalent to masks with respect to respiratory droplet protection and/or source
control.

(12) Face shields are to be used for eye protection in combination with a medical mask or a respirator.

(13) Follow the practice of ‘Safai, Dawai and Kadai’, meaning cleanliness, medication (as prescribed)
and following the preventive measures strictly.

RRR
