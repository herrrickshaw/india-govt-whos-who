---
doc_id: "f38ea43c1cc3cdab"
source_url: "https://dof.gov.in/static/uploads/2025/08/93f1d0dd89af72e1ec1fdc12c9983bed.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Comments/suggestions are invited on the Draft Rules for Sustainable Harnessing of Fisheries in the EEZ of India"
date: "2025-07-31"
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4d4a9c5dc0a4b2a4"
---

<!-- page 1 -->

<!-- page 2 -->

MINISTRY OF EXTERNAL AFFAIRS
NOTIFICATION
New Delhi, the [Day] June, 2025
G.S.R. No.
(E).—In exercise of the powers conferred by section 15 of the Territorial
Waters, Continental Shelf, Exclusive Economic Zone and Other Maritime Zones Act, 1976
(80 of 1976), the Central Government hereby makes the following Rules for the exploration,
exploitation, conservation, and management of fisheries resources in the Exclusive
Economic Zone of India, namely:
Sustainable Harnessing of Fisheries in the Exclusive Economic Zone of India Rules,
2025
1. Short Title, Application, and Commencement
(1)
These Rules may be called the Sustainable Harnessing of Fisheries in the
Exclusive Economic Zone of India Rules, 2025.
(2)
These Rules shall apply to all fishing and fishing-related activities conducted by
Indian fishing vessels in the Exclusive Economic Zone of India.
(3) They shall come into force on the date of their publication in the Official Gazette.
2. Definitions
(1) In these Rules, unless the context otherwise requires:
(a)

“Access Pass” means a pass issued by the Issuing Authority under
these rules to an Indian fishing vessel for fishing and fishing-related activities in the
Exclusive Economic Zone of India.

(b)

“Act” means the Territorial Waters, Continental Shelf, Exclusive
Economic Zone and Other Maritime Zones Act, 1976 (80 of 1976).

(c)

“Adjudicating Officer” means an officer of the State Fisheries
Department, not below the rank of Assistant Director of Fisheries, notified by the
concerned State under its Marine Fishing Regulation Act.

(d)

“Authorized Officer” means an officer of the Indian Coast Guard,
Indian Navy, Indian Customs, State Fisheries Department, or any other officer
notified by the Central Government for boarding and inspection of fishing vessels in
the Exclusive Economic Zone for the purposes of these rules.

(e)

“Appellate Authority” means a designated officer, not below the rank
of Joint Secretary in the Department of Fisheries, Ministry of Fisheries, Animal
Husbandry & Dairying, Government of India, for the purposes of these rules.

<!-- page 3 -->

(f) “Base Port” means the port of operation of the fishing vessel indicated in the
Access Pass
(g)

“Catch Certificate” means an official document, validated by the
competent authority notified by the Central Government, accompanying a
consignment of fish or fishery products to provide accurate and verifiable
information about fish in the supply chain.

(h)

“Destructive Fishing Practices” means fishing practices that cause
damage to habitats or the sustainability of fisheries, as notified by the Central
Government.

(i)

“Export Inspection Council (EIC)” means the export certification
body established under section 3 of the Export (Quality Control and Inspection) Act,
1963 (22 of 1963).

(j) “Fish” means finfish, molluscs, crustaceans, and all other forms of marine animals
and plants, excluding marine mammals, reptiles, and seabirds.
(k)

“Fishers” means fishermen and fisherwomen engaged in fishing and
fishing- related activities for livelihood or profit, including fish workers.

(l) “Fisheries” means fishing and fishing-related activities, including the utilization,
conservation, and management of marine fishery resources.
(m)
“Fishing” means searching for, trailing, pursuing, attracting, catching,
taking, or harvesting fish by any method.
(n)

“Fishing-related Activities” means landing, packaging, marketing,
processing, preserving, storing, live transportation of fish, transshipping, or
transporting fish not previously landed at a port, or any other related operations.

(o)

“Illegal, Unreported, and Unregulated Fishing (IUU Fishing)”
means activities identified as illegal, unreported, or unregulated fishing in the
National Plan of Action notified by the Central Government under rule 13.

(p)

“Indian Fishing Vessel” means an Indian fishing boat as defined and
registered under the Merchant Shipping Act, 1958 (44 of 1958), or any other law
for the time being in force in India.

(q)

“Issuing Authority” means an officer in the Department of Fisheries
in the Central Government, designated for issuing Access Passes to Indian fishing
vessels for fishing in the Exclusive Economic Zone of India.

(r)

“Mariculture” means the culture of marine aquatic organisms,
including fish, molluscs, crustaceans, and aquatic plants.

(s) “Mechanized Fishing Vessel” means a fishing vessel with an engine fitted to the
hull, using machine power for propulsion and fishing operations such as casting
and pulling nets or operating lines.
(t) “Mother Vessel” means a vessel, also termed as a carrier vessel, receiver vessel,
or factory vessel, that supports fishing vessels at sea by receiving, storing,

<!-- page 4 -->

processing, and preserving catch, and transporting it to port, and may provide fuel,
food, water, medical needs of crew, or other assistance.
(u)

“Motorized Fishing Vessel” means a fishing vessel with an engine,
fitted inside or outside, used solely for propulsion and not for fishing operations.

(v)

“Marine Products Export Development Authority (MPEDA)” means
the authority established under the Marine Products Export Development Authority
Act, 1972 (13 of 1972).

(w)
“Notification” means a notification published in the Official Gazette,
and the term “notify” shall be construed accordingly.
(x)

“Oceanic Fisheries Resources” means living marine resources in the
open ocean, beyond the continental shelf.

(y)

“Operator” means an individual or enterprise, or Fish Farmer Producer
Organisations or Fisheries Cooperatives (including multi-state cooperatives),
controlling or managing a fishing vessel or assuming responsibility for its operation.

(z)

“Owner” means a person, including an individual, partnership, Fish
Farmer Producer Organisations, Fisheries Cooperatives (including multistate cooperatives), or public or private body, whether incorporated or not, to
whom a fishing vessel or a share in it belongs.

(aa) “Port” means a port, fishing harbour, or fish landing centre designated by the
Central or State Government by notification in the Official Gazette for the purposes
of these rules.
(ab) “Prescribed” means prescribed by rules notified under the Act.
(ac) “Registration and Licensing of Fishing Craft (ReALCRaft)” means the webenabled online application portal established by the Central Government for
registering fishing vessels and issuing fishing licences, Access Passes, and LOA
under relevant laws or rules or guidelines.
(ad) “Regional Fisheries Management Organization (RFMO)” means an
intergovernmental fisheries organization or agreement to which India is a party,
with competence to establish conservation and management measures.
(ae) “Specified Area” means an area specified for fishing or fishing-related activities
in the Exclusive Economic Zone of India as specified by the Issuing Authority in the
Access Pass.
(af) “Skipper,” also termed as master, means a person having command or charge
of a fishing vessel or responsibility for its operation.
(ag) “State” means a State Government or Union Territory administration with a
coastal location.

<!-- page 5 -->

(ah) “Transponder” means an electronic device fitted on an Indian fishing vessel that
utilizes a satellite communication system to receive and transmit vessel-related
data, including location and operational status.
(ai) “Verifying Officer” means an officer of a State Government, notified by the
Central Government in consultation with the State, responsible for verifying
documents and physically inspecting fishing vessels for the grant of an Access
Pass.
(2) Words and expressions used but not defined in these rules, and defined in the
Territorial Waters, Continental Shelf, Exclusive Economic Zone and Other Maritime
Zones Act, 1976 (80 of 1976), and the Merchant Shipping Act, 1958 (44 of 1958),
shall have the meanings assigned to them in those Acts.

3. Regulation of Fishing and Fishing-related Activities
(1) Access Pass Requirement
(a)

All mechanized fishing vessels and those motorised fishing vessels
exclusively engaged in fishing for tuna and tuna-like species or motorised fishing
vessels of 24 meters overall length and above shall obtain an Access Pass for fishing
and fishing- related activities in the Exclusive Economic Zone of India beyond territorial
waters.

(b) No Access Pass shall be required for motorised fishing vessels of less than 24 metres
overall length, except those engaged in tuna and tuna-like species;
Provided that such vessels shall comply with the sea safety requirements, monitoring,
control, and surveillance, and conservation and management measures, while
operating in the Exclusive Economic Zone.
(c) The application for an Access Pass shall be submitted online in the format specified
in Schedule I, accompanied by the prescribed documents and processing fee.
(2) Process for Issuing Access Pass
(a) The owner or operator of an Indian fishing vessel shall apply for an Access Pass online
through the ReALCRaft portal.
(b) The grant of an Access Pass shall be subject to the fitness and seaworthiness of the
fishing vessel as per the provisions of the Merchant Shipping Act, 1958, and
submission of prescribed documents and the processing fee.
(c) The Verifying Officer of the concerned Port of Registry shall verify the application,
including the validity and authenticity of documents, within two weeks and forward it
to the Issuing Authority.

<!-- page 6 -->

(d) The Issuing Authority shall issue the Access Pass within five to ten working days,
subject to satisfactory verification, in the form specified in Schedule II, which shall be
downloadable by the applicant.
(e) The Access Pass shall specify the applicable terms and conditions to be complied
with by the fishing vessel, operator, or owner.
(f) The operator shall ensure that the original Access Pass, in physical or digital form, is
prominently displayed on board the fishing vessel and produced upon demand by any
Authorised Officer.
(3) Validity and Renewal of Access Pass
(a) An Access Pass shall remain valid for a period of three years from the date of
issuance.
(b) The owner or operator may apply for renewal at least 30 days prior to the expiry of the
existing Access Pass, for a further period of three years.
(c) The reasons for refusal of issuance or renewal of an Access Pass shall be recorded
in writing by the Issuing Authority or Verifying Officer and communicated to the
Applicant.
(d) An Access Pass shall be non-transferable, non-assignable, and shall be vesselspecific, issued only for a fishing vessel registered on the ReALCRaft portal. The
Access Pass shall not be sold, leased, or otherwise conveyed for any other purpose.
4. Monitoring, Control, and Surveillance (MCS)
(a) The fishing vessels with an Access Pass shall operate from and return to their Base
Port for fish landing.
(b) In the event of a fishing vessel intending to enter any port other than that referred to
in para 4 (a), it shall intimate to the Registrar of the fishing vessels, the Issuing
Authority, and the Authorized Officers.
(c) In case an Indian fishing vessel is confiscated by the authorities of any other country,
and the issuing authority is intimated to this effect, the Issuing Authority shall
deactivate the transponder fitted on such Indian fishing vessel.
(e) Fishing vessels, operators, and owners shall comply with the minimum provisions of
sea safety, manning, and MCS provisions prescribed under the Merchant Shipping
Act, 1958, that may inter alia include but not be limited to the following:
(i)
Fishing vessels must carry light and sound signals in accordance with
Rule 26 of the COLREGS.

<!-- page 7 -->

(ii)
The operator is responsible for ensuring the safety and security of both
the fishing vessel and its crew by providing approved communication and safety
equipment, as required by applicable national and international regulations or
conventions. Specifically, the operator must ensure that the following minimum
provisions are available on the vessel:
a. Automatic Identification System (AIS)
b. Satellite-based Vessel Monitoring System (VMS)/Vessel Communication and
Support System (VCSS)
c. Distress Alert Transmitter (DAT) or
d. Emergency Position Indicating Radio Beacon (EPlRB)
e. Life Buoys
f. Life Jackets - 150% of the authorized crew capacity
g. 25-watt VHF Radio/Satellite voice communication
h. Radar Reflectors
(iii)
The VMS and AIS units must be continuously operational whenever
the vessel is at sea, and they shall not be tampered with. The vessel must transmit
its details (including vessel identification, current geographic position, and date and
time) via VMS to the designated national Fisheries Monitoring Center (FMC) at least
every 4 hours.
5. Inspection and Enforcement
(a) The Authorised Officer shall be responsible for monitoring, control, and surveillance
of fishing vessels out at sea and by using the digital tools, including AIS/VMS/VCSS
etc., to oversee and enforce the compliance of the provisions of these rules, the terms
and conditions of the Access Pass and other such related matters.
(b) The Authorized Officer shall report any violations in writing to the Issuing Authority,
the Adjudicating Officer and the Registrar of the fishing vessels concerned, in such
manner as notified by the Central Government.
6. Fisheries Management Plans (FMPs)
(a) The Central Government, in consultation with scientific institutions, Coastal States,
and fishers and their associations, shall notify Fisheries Management Plans (FMPs)
for sustainable fisheries in the Exclusive Economic Zone, which shall be based on the
best available scientific information, including fishing mortality or stock biomass levels
consistent with management objectives such as Maximum Sustainable Yield (MSY).
Maricultre including seaweed cultivation in the EEZ shall also be promoted as an
additional measure to reduce fishing pressure, creation of additional livelihood and
enhancing production from the sea.

<!-- page 8 -->

(b) All Fishing Vessels engaged in fishing and fishing-related activities in the EEZ shall
comply with the notified FMPs. The notified FMP may include, but not be limited to,
the following management actions:
(i) Spatial and temporal fishing closures;
(ii) Fishing gear restrictions;
(iii) Minimum legal size of fish for capture;
(iv) Limits on the number of fishing vessels or participants in a fishery;
(v) Bycatch reduction measures;
(vi) Optimum utilization of conventional and non-conventional oceanic fisheries
resources such as Oceanic squids, Myctophids, etc.
(vii) Measures to address marine pollution, abandoned, lost, or discarded fishing
gear (ALDFG) or ghost gear;
(viii)

Skilling and capacity building for sustainable fishing for deepsea and oceanic resources, and onboard fish handling.

(ix) Best practices for reducing post-harvest losses on board the fishing vessels;
(x) Identification and protection of Essential Fish Habitat (EFH), including
spawning, breeding, and feeding grounds.
7. Origin of Catch
a) Fish harvested by Indian fishing vessels operating in the EEZ of India shall be treated
to be of “Indian Origin” and shall not be subject to any import duty, cess, or levy when
landed at a port located within the territory of India.
b) Fish caught in the EEZ of India by Indian fishing vessels and landed at foreign ports
shall be classified as exports and shall be governed by applicable Indian export laws
and regulations.
c) The Registrar of the fishing vessels concerned and any such other authority as notified
by the Central Government shall be responsible for the verification of the catch-related
data, duly authenticated by the Skipper of the vessel and recorded in the manner as
prescribed under rule 10.
8. Catch and Health Certificates
(a) For the Indian fishing vessels having Access Pass issued under these rules, the Catch
Certificates shall be issued by the Marine Products Export Development Authority (MPEDA) ,
and the Health Certificates shall be issued by the Export Inspection Council (EIC), for the
purposes of traceability, compliance with sanitary standards, and eco- labelling, in
accordance with applicable national and international regulations.

<!-- page 9 -->

(b) Applications for Catch and Health Certificates shall be submitted through designated
online portals of the respective agencies, which shall be duly integrated with the
ReALCRaft portal for verification and processing of vessel and catch-related
information.
9. Mid-Sea Transhipment
(a) The operators or owners of fishing vessels with an Access Pass may undertake midsea transhipment to a mother vessel in accordance with the applicable measures of
the RFMO concerned and the relevant guidelines of the Reserve Bank of India as
promulgated from time to time.
(b) The operators or owners shall intimate the Issuing Authority, the Registrar of the
fishing vessels, and the Indian Coast Guard at least 48 hours in advance, providing
details of the mother vessel, quantity of catch, species, and transhipment date, time,
and coordinates, in the form specified in Schedule III.
10.

Catch Reporting

The Central Government may, by notification, require the Indian fishing vessels to furnish
such fishery data to the Registrar of the fishing vessels, Authorised Officer, Issuing
Authority, or other authorities in digital form and at such periodical intervals as may be
specified in that notification. The notification shall also specify the formats for voyage
reports for different types of fishing vessels, which may inter alia include the details of fish
catch, fish species, numbers, weight, fishing areas, and trip duration.
11.

Fishers and Crew Identity

Every fisher and crew member on board a fishing vessel in the Exclusive Economic Zone
shall carry a QR-coded Aadhaar card or a Marine Fishers Digital Identity Card, as notified
by the Central Government.
12.
Zones

Prohibition of Destructive Fishing, Juvenile Fishing, and No-Fishing

The Central Government, in consultation with the States and scientific institutions, shall, by
notification, regulate, restrict, and prohibit, including the following:
(i) use of dynamite, explosives, poisons, noxious chemicals, or other destructive
materials or methods;
(ii) use of artificial lights for certain fishing methods, to catch or destroy fish;
(iii) capture of juvenile fish or related activities’;
(iv) Fishing in No Fishing Zones as notified from time to time.

<!-- page 10 -->

13.

Prohibition of Illegal, Unreported, and Unregulated Fishing

The Central Government shall notify a National Plan of Action to prevent, deter, and
eliminate illegal, unreported, and unregulated (IUU) fishing, which the vessels operating in
the EEZ shall comply with.
14.

Compliance with RFMO and International Instruments

The Fishing and fishing-related activities in the Exclusive Economic Zone shall be carried
out in compliance with the conservation and management measures (CMMs) adopted by
Regional Fisheries Management Organisations (RFMOs) to which India is a party, including
the Indian Ocean Tuna Commission (IOTC). Such applicable measures shall be appended
to the Access Pass and updated periodically.
15 Adjudication Process
On the receipt of a report from the Authorised Officer regarding contraventions of the
provisions of these rules, notifications, or Access Pass conditions, the Adjudicating Officer
shall conduct an inquiry, giving all the concerned parties a reasonable opportunity to be
heard.
16. Violations and Penalties
(a)

The Adjudicating Officer, after inquiry under rule 15, may impose penalties
for contraventions of the rules 3, 4, 6, 9, 10, 11, 12, 13, and 14, or the notifications
issued under these rules, or Access Pass conditions, as follows:

Category of Fishing Vessel

First
Offence

Second
Offence

Third and Subsequent
Offences

(i) Motorised vessels, and
(ii) Mechanised fishing vessels of
less than 15 m overall length

Fine up to
₹5,000

Fine up to
₹10,000

Fine up to ₹20,000

Mechanised fishing vessels of 15
m to less than 24 m overall length

Fine up to
₹10,000

Fine up to
₹20,000

Fine up to ₹50,000

Mechanised fishing vessels of 24 m Fine up to
and above overall length
₹30,000

Fine up to
₹50,000

Fine up to ₹1,50,000

<!-- page 11 -->

(b) In addition to penalties under sub-rule (a), the Adjudicating Officer, based on the
reasons and grounds to be recorded, may:
(i) Suspend the Access Pass for a specified period not exceeding 6 months;
(ii) Cancel or revoke the Access Pass;
(iii)
Recommend to cancel or revoke the Registration Certificate of the
fishing vessel.
(c) The Issuing Authority may suspend or cancel an Access Pass in the interest of law
and order, maritime security, or public interest, without prejudice to other penalties.
(d) In the case of suspension of an Access Pass, the operator shall immediately ensure
that fishing or fishing-related activities of such vessel is stopped until the suspension
is revoked in writing.
(e) The suspended or cancelled Access Pass shall no longer be used. The status of such
suspended or cancelled Access Pass shall be updated on ReALCRaft by the Issuing
Authority.
(f) The pecuniary penalties imposed by the Adjudicating Officer under these rules shall
be recovered by the State as arrears of public revenue due on land, with the exercise
of powers of the Collector and District Magistrate under the land revenue laws of the
respective States.
17. Appeals
(a) Any person aggrieved by an order of the Issuing Authority or Verifying Officer refusing,
cancelling, or suspending an Access Pass or penalties imposed under rule 16 may
appeal to the Appellate Authority within 30 days of the communication of the order.
(b) The Appellate Authority shall hear the appeal after giving a reasonable opportunity to
the party to be heard and issue a final order expeditiously.
(c) The Appellate Authority may review records of orders passed by the Adjudicating
Officer, against which no appeal has been filed within the period of three months, to
ensure legality, propriety, or procedural regularity, provided no prejudicial order is
passed without giving the affected person a reasonable opportunity to be heard.
(d) The Orders of the Appellate Authority shall be final.
18. Powers of Adjudicating Officer and Appellate Authority
The Adjudicating Officer and Appellate Authority, while holding inquiries, shall require the
owner or operator or the Authorised Officer to produce the documents and records of the
fishing vessel, and obtain any such evidence related to the offences as deemed fit.

<!-- page 12 -->

19. Protection of Action Taken in Good Faith
No suit, prosecution, or legal proceeding shall lie against the Authorising Officer,
Adjudicating Officer, Issuing Authority, Appellate Authority, or any person, or the
Government for actions taken in good faith under these rules.
20. Remittance of Revenue
All revenue earned under these Guidelines shall be remitted to Bharat Kosh.
21. Institutional Mechanism
The Central Government shall, by notification, establish an Inter-Ministerial Committee and
advise the States to constitute State-level Committees to oversee the implementation of
these rules for the sustainable harnessing of marine fisheries resources in the Exclusive
Economic Zone.

<!-- page 13 -->

SCHEDULE I
Application Format for Access Pass
1.

Name of the company/ operator/ FFPO/
Fisheries Cooperative
2. Registration No. of the Company/ FFPO/
Fisheries Cooperatives
3.
Address of the company / operator/
FFPO/ Fisheries Cooperative
4.
Aadhaar Card No.
5.
PAN Card No.
6.
Mobile No.
7.
Email
8.
Website
9. Name of the fishing vessel
10. Registration No. of Fishing Vessel:
11. IMO No. (as applicable)
12. International Call Sign (as applicable)
13. MMSI No. / AIS No.
14. Transponder No.
15. Type of fishing or fishing-related activities
proposed: (i). Purse Seine fishing (ii). Long Line
fishing (iii). Gillnet cum Longline fishing (v). Gillnet
fishing (v). Pole and line fishing (vi). Handline fishing
(vii). Trolling fishing (viii). Mid-water pelagic trawling
(ix). Squid jigging, (x). Others_ please specify
16. Access Pass duration
17 Base Port
18. Specifications of Fishing Vessel: (i). Overall Length
(ii). Breadth
(iii). HP of the Engine
(iv). Gross Tonnage
(v). Net Tonnage
(vi). Fish Hold capacity
(vii). Engine Details
(viii). Fuel capacity

:

:

:
:

: From ………… To …………

:
:
:
:
:
:
:

<!-- page 14 -->

(ix). Year of Built

:

Declaration
We, M/s [Name], undertake that our vessel(s) will not engage in destructive fishing
practices, including pair trawling (bull trawling), juvenile fishing, use of artificial light or LED
fishing, or fishing of endangered species as notified under the Wildlife (Protection) Act,
1972. The vessel(s) will operate only for the type and area of fishing permitted under these
rules and comply with applicable conservation and management measures adopted by the
concerned RFMO in keeping with the United Nations Law of the Sea Convention 1982,
United Nations Fish Stock Agreement 1995, and other such international instruments to
which India is party. In case of violation, the Government may impose penalties as per the
Rules and suspend or cancel the Access Pass.
I confirm that the information provided is true and correct to the best of my knowledge.
……………………………

……………………………..

Signature of the Applicant

Date and Place

Application Processing Fee (to be submitted Online_ReALCRaft portal)
(a) Mechanized fishing vessels of less than 15 m OAL and motorised fishing vessels: ₹3,000/(b) Mechanised fishing vessels of 15–23.9 m OAL: ₹5,000/(c) Mechanised fishing vessels of 24 m OAL and above: ₹7,500/-

<!-- page 15 -->

SCHEDULE II
Format for Access Pass
Access Pass No.: [Number]
Valid From: [Date] To: [Date]

Vessel & Operator Details
1.

Name of the owner/ operator

:

2.

Address & Mobile No

:

3.

Name and Registration No. of the
Vessel

:

4.

Port of Registry

:

5.

Overall Length

:

6.

Base Port

:

Conditions of Access Pass
This vessel is permitted to operate solely for the type of fishing and area specified, within
the Exclusive Economic Zone of India, under the Sustainable Harnessing of Fisheries in
the Exclusive Economic Zone of India Rules, 2025.
Prohibited Activities
A. Shrimp trawling (where applicable)
B. Pair trawling (bull trawling)
C. Fishing of endangered species as notified under the Wildlife (Protection) Act, 1972
Any violation of these conditions or the provisions of the rules or notifications issued under
the rules, will result in penalties, including suspension or cancellation of the Access Pass.
Issuing Authority
Authorised Signatory:
Designation:
Seal and Signature

<!-- page 16 -->

Date of Issue:
Place:

SCHEDULE III
Details of Mother Vessel, Quantum of Catch, and Species for Transhipment
1. Name of the Mother
vessel

:

2. Access Pass No.

:

3. Name of the Donor
Vessel/s

:

4. Access Pass No/s.

:

5. Name & Contact of
the Operator /
Owner of the
Mother Vessel

:

6. Proposed Date and
Time of
Transhipment

:

7. Coordinates
(Latitude &
Longitude)

:

8. Port of Landing

Details of Catch
Name of Species

Quantity (in Tonnes)

Preservation Method

Declaration
We declare that the above details are true and accurate and that the transhipment complies with all
relevant rules, including the Reserve Bank of India Guidelines and the Sustainable Harnessing of
Fisheries in the Exclusive Economic Zone of India Rules, 2025.

<!-- page 17 -->

Signature of the Donor Vessel
Owner

Signature of the Mother Vessel
Owner

Name

Name
