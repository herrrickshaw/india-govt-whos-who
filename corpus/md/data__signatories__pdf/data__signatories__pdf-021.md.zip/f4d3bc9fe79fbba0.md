---
doc_id: "f4d3bc9fe79fbba0"
source_url: "https://mines.gov.in/admin/download/66a365f6473071721984502.pdf"
ministry: "Mines (MoM)"
title: "Relaxation Order under Sec. 31 VER Halite from Auction Rules. (1.62 MB)"
date: ""
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "59238524e8df3e2d"
---

<!-- page 1 -->

M.IV-2306/10/2024-Mines IV
Government of India
Ministry of Mines
Shastri Bhawan, New Delhi
Dated: 26 June, 2024
ORDER
Whereas, the Mines and Minerals (Development and Regulation) Act, 1957 (hereinafter, 'the
Act') was enacted to provide for development and regulation of mines and minerals in the country.
2. And whereas, the Mineral (Auction) Rules, 2015 (hereinafter, 'the Auction Rules') are
framed under Section 13 of the Act to provide for the manner of auction and grant of minerals
concessions and related matters.
3. And whereas, Rule 2(1)(m) of the Auction Rules defines the term ‘value of estimated
resources’ (hereinafter, ‘VER’) to mean an amount equal to the product of, -
(i) the estimated quantity of mineral resources for which the mineral block is being
auctioned, expressed in metric tonne; and
(ii) the average price per metric tonne of such mineral as published by Indian Bureau of
Mines for the relevant State for a period of twelve months immediately preceding the month
of computation of the VER.
oy Thus, value of all the minerals available in a mineral block is included in the calculation of
VER of the mineral block.
3. And whereas, VER forms the basis of calculation of the bid security, performance security,
upfront payment and determination of eligibility of the bidders (net-worth requirement) in the
auction of mining lease and composite licence under various provisions of the auction rules.
4. And whereas, section 11D of the Act empowers the Central Government to conduct
auction for grant of mining lease or composite licence in respect of critical and strategic minerals
specified in Part D of First Schedule of the Act. Vide Gazette Notification number G.S.R. 860(E),
dated the 16th December, 2021 read with Gazette Notification number G.S.R. 3890(E), dated the
Page 1 of 4

<!-- page 2 -->

1% September, 2023 of the Ministry of Mines, the Central Government has, infer alia, delegated
power of to conduct auction under section 11D of the Act to the Designated Officer.
Ds And whereas, the Designated Officer issued notice inviting tender on 29" February, 2024
for inviting bids for 18 blocks of critical and strategic minerals. The Designated Officer has
informed that out of these 18 blocks, 2 blocks in Rajasthan contains Potash and Halite minerals.
Calculation of VER of these blocks are as under:
Resources VER Total VER
Potash and
Halite Block —_
2 |Lakhasar Rajasthan | Bikaner [CL] 1830.06 11,26,028.68
Potash and 5
6010 | 1 लि स्किल फिक्ज |
6. And whereas, it is noted that resources of Halite mineral in the blocks is high and
accordingly, VER of Halite in the blocks is very high as compared to VER of Potash mineral in
the block and accordingly total VER of the blocks is extremely high. The Designated Officer has
informed that no bid was received till the last date of bidding for these blocks despite 106 days
were given to the bidders to submit bids.
7. And whereas, under the Auction Rules, net worth requirement is capped at 2200 Cr. for
yy / the auction of mining lease and 2100 Cr. for the auction of composite licence. Similarly, bid
yy security amount is also capped at 250 Cr. for auction of both mining lease and composite licence.
Further, vide amendment dated 21‘ January, 2024, Rules 11, 12 and 19 of the Auction Rules were
amended to provide a cap of $500 Cr. on the upfront amount, a cap of $500 Cr. on the amount of
performance security for mining lease and a cap of 2250 Cr. on the amount of performance
security for composite licence. These caps were introduced to encourage participation of bidders
in auction of mineral blocks in view of very high VER in certain blocks.
8. And whereas, it is noted that despite the above caps being applied on the key bidding
parameters to encourage participation of bidders in the blocks having high VER, no bidder has
participated in auction of blocks containing Potash and Halite. Designated authority has also
informed that apart from above-mentioned two blocks, there are several other blocks containing
Potash and Halite in Rajasthan where VER of Halite is significantly higher as compared to VER
Page 2 of 4

<!-- page 3 -->

of Potash. Due to such high VER of Halite, the minerals blocks are becoming unattractive for the
bidder.
9. And whereas, Potash is a critical and strategic mineral included in Part D of the First
Schedule of the Act. India is completely dependent on imports for Potash which is majorly used
as a fertilizer in agriculture. Recently the price of Potash has substantially increased. Indigenous
mining of potash is in the national interest that would lead to reduction of imports. The Potash
blocks discovered in India is deep seated and can be mostly mined by underground mining method
which is difficult and capital extensive. However, there is requirement of encouraging indigenous
mining of potash.
10. And whereas, Rajasthan alone contributes 91% to the total resources of Potash in the country
and most of discovered potash blocks in Rajasthan contains substantial amount of Halite mineral.
Thus, major portion of the production of Potash in the country will have to come from these blocks
containing Halite. .
11. And whereas, under the Auction Rules, the successful bidder is required to pay auction
premium (percentage quoted of the value of mineral dispatched) on actual dispatch of minerals
from the leased area per month. Similarly, payment of amount towards royalty, District Mineral
Foundation, National Mineral Exploration Trust, etc. are not dependent on VER of the block, but
are paid on the value of minerals actually dispatched.
12. And whereas, it is noted from the available Potash and Halite blocks that VER of the
available Potash in the blocks is sufficiently high. Thus, even if the VER of Halite is ignored in
calculation of the total VER of the block, then also the resultant bid security, performance security,
upfront amount, etc. would be sufficient to act as monetary guarantee of performance of the
successful bidder. Further, these blocks are to be auctioned for grant of composite licence, where
after completing the detailed exploration, the successful bidder will arrive at the actual minable
quantity and quality of Potash and Halite in the block. In case, if the successful bidder produces
and dispatches minerals, it will have to pay the applicable auction premium, royalty, etc. on the
value of all the minerals dispatched including on Potash and Halite.
9४

pr 13. And whereas, Section 31 of the Act provides that the Central Government may, if it is of
opinion that in the interests of mineral development it is necessary so to do, by order in writing
and for reasons to be recorded, authorise in any case the grant, renewal or transfer of any mineral

Page 3 of 4

<!-- page 4 -->

concession, or the working of any mine for the purpose of searching for or winning any mineral,
on terms and conditions different from those laid down in the rules made under section 13.
14. And whereas, in view of the above mentioned circumstances, the Central Government
consider it necessary to make the Potash and Halite blocks auctionable by disregarding the VER
of Halite in the block in calculation of the total VER of the blocks. This will allow in keeping the
total VER of the Potash and Halite blocks to a reasonable level and increase participation of the
bidders in the auction. Auction and mining of Potash blocks in the country is essential to reduce
the import of this critical and strategic mineral.
15. Now therefore, in exercise of the powers conferred under Section 31 of the Act, the Central
Government, in the interests of mineral development, hereby relaxes the provisions of Rule
2(1)(m) of the Mineral (Auction) Rules, 2015 to allow auction of Potash and Halite blocks by not
including the VER of Halite in calculation of the total VER of the blocks for the purpose of auction
for grant of composite licence. However, the lessee will pay the applicable auction premium,
royalty, etc. on the value of all the minerals dispatched including on Potash and Halite
067
(Dheeraj Kumar)
Dy. Secretary to the Government of India
To,
Joint Secretary (Policy) and Designated Officer under the MMDR Act,
Ministry of Mines,
Government of India
New Delhi.
Page 4 of 4
