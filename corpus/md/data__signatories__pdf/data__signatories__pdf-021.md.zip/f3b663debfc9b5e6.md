---
doc_id: "f3b663debfc9b5e6"
source_url: "https://mines.gov.in/admin/download/6523accddc55f1696836813.pdf"
ministry: "Mines (MoM)"
title: "Commencement Notification of the OAMDR Amendment Act, 2023 (856.51 KB)"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "0d06e8da7aa8599c"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-17082023-248164
xxxGIDHxxx
CG-DL-E-17082023-248164
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 3526]
No. 3526]

नई दिल्ली, बृहस्ट्पजतिार, अगस्ट्त 17, 2023/श्रािण 26, 1945
NEW DELHI, THURSDAY, AUGUST 17, 2023/SHRAVANA 26, 1945

खान मंत्रालय
अजधसूचना
नई दिल्ली, 17 अगस्ट्त, 2023
का.आ. 3685(अ).—के न्द्रीय सरकार, अपतट क्षेत्र खजनि (जिकास और जिजनयमन) संिोधन अजधजनयम,

2023 (2023 का 17) की धारा 1 की उपधारा (2) द्वारा प्रित्त िजियों का प्रयोग करते हुए 17 अगस्ट्त 2023
को उस तारीख के रूप में जनयत करती है जिसको उि अजधजनयम प्रिृत होगा।

[फा. सं. एम.VI-1/1/2022-खान -VI भाग(1)]

संिय लोजहया, अपर सजचि

5315 GI/2023

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF MINES
NOTIFICATION
New Delhi, the 17th August, 2023
S.O. 3685(E).—In exercise of the powers conferred by sub-section (2) of section 1 of the Offshore
Areas Mineral (Development and Regulation) Amendment Act, 2023 (17 of 2023), the Central Government
hereby appoints the 17th day of August, 2023 as the date on which the said Act shall come into force.

[F. No. M.VI-1/1/2022-Mines VI-Part(1)]
SANJAY LOHIYA, Addl. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. MANOJ
VERMA
Digitally signed by MANOJ KUMAR
VERMA
Date: 2023.08.17 21:41:34 +05'30'
