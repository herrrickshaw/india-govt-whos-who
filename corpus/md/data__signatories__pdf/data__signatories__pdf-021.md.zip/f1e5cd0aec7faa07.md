---
doc_id: "f1e5cd0aec7faa07"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/d6de89e2cabe8d2538228161fe1daefb.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Resignation of 5 panel counsel for various courts/tribunal: Order dated 27.03.2019"
date: "2019-04-01"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "06acf64be57dbaea"
---

<!-- page 1 -->

F. No. J-11/2/2018-Judicial (Part-1)
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi,
Dated 27" March, 2019
ORDER
The President is pleased to accept the resignations of following Advocates who
figure in various categories of the panel counsel for various courts/tribunal as mentioned
under column Ill, with effect from the dates as mentioned under column-V in table ‘A’
below, consequently, their names occurring in various orders of this Department as
mentioned under column-IV in table ‘A’, stand deleted:
Table ‘A’
fe Name of | Name of | Detail of the order(s) | Date of |
No. | Advocate Court/Tribunal & | No. of empanelment acceptance of
(S/Shri) Category of Panel resignation
1 Ms. Prachi CAT, Ahmedabad | 36(8)/2015-Judl. dated | 30.10.2018
Upadhyay Bench as Addl. CGSC | 06.04.2015
2 Dashrath Singh | District & Subordinate | J-11015/1/2016-Judl. 08.12.2018
Chauhan Courts, Etawah (UP) | dated 28.12.2016
as Addl. SGC
| 3. Ramesh Singh High Court of Delhi as | J-11017/22/2018-Judl 20.12.2018
| | Sr. Panel Counsel | dated 18.12.2018
4. P. Parameswaran | Supreme Court of | J-11016/1/2019-Judl. 27.02.2019
Nair India as Group ‘A’ Dated 01.02.2019
| Panel! Counsel
5. Dr. V. Venkatesan | High Court of Madras | J-11017/20/2018-Judl. 04.03.2019
at Chennai as Sr. | Dated 06.08.2018
| Panel Counsel
2 Hindi version of this order will follow.
<a
(S. R. Mishra)
Additional Secretary
-1/2-

<!-- page 2 -->

F. No. J-11/2/2018-Judicial (Part-1) Dated : 27.03.2019
Copy for information to:

1. PS to MLJ/ PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary.

2. The Incharge Central Agency Section, Supreme Court of India, New Delhi

3. The Incharge, Litigation (High Court) Section, High Court of Delhi, New Delhi.

4. The Incharge, Branch Secretariat, Chennai |

5. Shri Devang Vyas, Asst. SGI, Gujarat High Court, Anmedabad.

6. The Registrar, CAT, Ahmedabad Bench.

7. The District Judge, City Civil Courts, Etawah (UP).

8. Shri Ghanshyam Kishore Bajpai, Standing Govt. Counsel, R/o 740, Vivekanand Marg, Civil Lines,

Etawah, U. P.
9. All the five Advocates mentioned in the table ‘A’ above.
10. To be uploaded on website of this Department i.e. www.legalaffairs.gov.in under tab ‘Judicial
Section’ in the link ‘List of empanelled Counsel’
11. Hindi Section, Department of Legal Affairs, for translation of this order.
12. Guard File with 5 spare copies.
५७ A
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
-2/2-
