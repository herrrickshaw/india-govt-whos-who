---
doc_id: "f2412fefd7dad88c"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/1ea5790e4948328aa820f8518e509acb.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Nomination for receiving United Nation's Populations Award 2024 - OM Dated 15-12-2023"
date: "2023-12-15"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "60284c4aeed7eebe"
---

<!-- page 1 -->

Z-28015/236/2023-IH
I/3636481/2023

No. Z-28015/236/2023-IH {FTS No. 8253649}
Government of India
Ministry of Health & Family Welfare
Department of Health & Family Welfare
(International Health Division)
****
504-D, Nirman Bhavan, New Delhi
Dated the 15th December, 2023
OFFICE MEMORANDUM
Subject: Nomination for receiving United Nations Population Award 2024 - reg.
The undersigned is directed to enclose a copy of United Nations
Population Fund (UNFPA)'s communication dated 31.10.2023 on the subject
cited above and to request to recommend, with adequate reasons recorded in
writing, an individual / institution, if any, in the proforma, for proposing her / his
/ its nomination for the United Nations Population Award 2024.
2. It may please be noted that such recommendation should reach IH Division
of this Ministry by 20th December, 2023.
Encl: As above.

(D. Ramesh Babu)
Under Secretary to the Govt. of India
Email: dramesh.babu@nic.in

i. DGHS, Nirman Bhawan, New Delhi
ii. All Additional Secretaries / Joint Secretaries of M/o Health & FW
iii. Ms. Anu Nagar, Joint Secretary, D/o Health Research, IRCS Building, New

Delhi
iv. NIC, MoHFW - with a request to publish the OM on Ministry's website.
