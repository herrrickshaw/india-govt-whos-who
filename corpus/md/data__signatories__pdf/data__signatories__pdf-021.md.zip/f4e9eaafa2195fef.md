---
doc_id: "f4e9eaafa2195fef"
source_url: "https://www.mdoner.gov.in/static/uploads/2025/08/18b891eb1b6fdcc72126a2e3dad26ee4.pdf"
ministry: "Development of North Eastern Region (MDONER)"
title: "SCHEMES OF NEC Guidelines (5th-May-2021)"
date: "2021-05-05"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "3caca89893d58329"
---

<!-- page 1 -->

No. NEC-17/10/2021-O/o US(SS)
Government of India
Ministry of Development of North Eastern Region
Vigyan Bhawan Annexe, New Delhi
Dated 5" May, 2021
To
The Secretary,
North Eastern Council,
Nongrim Hills,
Shillong
Subject: Amendment in NEC General Guidelines, 2020
Sir,
| am directed to refer to the above mentioned subject and to say that after careful
consideration of all the facts and keeping in view the advice of DoE in OM No. 72(04)/PF-
1/2017 dated 13.04.2021, it has been decided with the approval of competent authority that
the procedures/mechanism/authorities laid down by Ministry of Finance, Department of
Expenditure contained in their O.M. No. 24(35)/PF-II/2021 dated 05.08.2016, as amended
from time to time, shall be followed for appraisal/approval of projects/sub-schemes costing
above Rs. 15 crore under Schemes of NEC.
2. Accordingly, keeping in view the existing delegation of powers to Secretary NEC for
appraisal/approval of projects under Schemes of NEC, the competent authority is pleased
to prescribe the following Appraisal and Approval Authorities for the Projects/sub-schemes
under “Schemes of NEC”. Accordingly, the relevant Clauses under the NEC General
Guidelines 2020, in particular Clauses 9 and 10, stand modified to that extent and may be
substituted with the following :
Para 9.1 : NEC shall follow an SFC Mechanism for appraisal of the projects/sub-schemes
costing between Rs 5-15 Crores.
Para 9.2 : The procedure/mechanism/authorities laid down by Ministry of Finance,
Department of Expenditure contained in their O.M. No. 24(35)/PF-II/2021 dated 05.08.2016,
as amended from time to time, shall be followed for appraisal/approval of projects/sub-
schemes costing above Rs. 15 crore under Schemes of NEC
Para 9.3 : Designated authorities for appraisal and approval of projects/sub-schemes under
“Schemes of NEC” shall be as following :
Designated appraisal_and approving authorities for _projects/sub-schemes (hereinafter nated appraisal and approving authorities for rojects/sub-schemes (hereinafter
referred to as projects) under “Schemes of NEC” to as projects) under “Schemes of NEC”
Description|Appraisal Pproving Remarks
[Authority uthority = di
Ls Ut Projects|FA of NEC Secretary NEC The procedure fo
Upto Rs 5 | prioritizing of projects:
a iehe ee ee i 00 by SEC of NEC as per,

<!-- page 2 -->

ae For oo Chaired by a NEC |Secretary NEC Ee Guidelines :
labove Rs 5 be followed before
| |r, but upto) appraisal and
Rs 15 cr. approval. Thereafter,
concerned division o
| NEC will process the
| project proposal(s) on
| merits, and if found in
| | order, will place before
| the FA/SFC chaired by
Secretary NEC for
appraisal. SFC will
have representative!
| from M/o Finance, M/o
। DoNER and Line
| Ministries. The|
Planning Adviser,
Financial Adviser,
Economic Adviser,
(E&M) and concerned
Sector Head of NEC
| as members. |
| For | S&FA, M/o DONER Secretary, M/o| After following _ the|
labove Rs! IDoNER procedure fo
45 cr, bu prioritization 0
।७।४० २५ 100 projects by SEC of
Icr. NEC, proposals from
NEC will be sent to the|
PD of M/o DoNER
with the approval o'
Secretary, NEC fo
Appraisal and
Approval . If PD, afte
doing a_ preliminary|
scrutiny of the}
proposal, finds it in
order, will send the’
same to JS&FA/IFD)
M/o DoNER fo!
appraisal by JS&FA. |
considered
necessary, JS&F;
may seek comments|
of NITI
Aayog/Concerned
Line
Ministries/Technical
wing proposals. IFD
M/o DoNER will
render the necessary|
की Ss ae _Secretariat_ assistance!

<!-- page 3 -->

Pore oak Like se wanes 5 inthis regard. __]
| डेप Projects\SFC/DIB chaired by Secretary, Minister, M/o| After following |
above  Rs\M/o DoNER,|DoNER | procedure ल्‍
100 cr, but! prioritization of projects|
upto Rs 500) by SEC of NEC|
Icr. proposals from NEC
will be sent to the PD o
M/o DoNER with the
| approval of Secretary,
| NEC for Appraisal and
Approval . If PD, afte:
doing a__ preliminary
| scrutiny of the!
| proposals, finds it in|
order, will send the
same to NITI
Aayog/concerned Line.
Ministries/IFD/Technical
Wing M/o DoNER et
for comments/inter-
Ministerial
consultations, and
place it before the SFC
along with such)
| comments as per)
| instructions issued by
D/o Expenditure and
M/o DoNER from
i ie Be 22 em अ आउट ale time. SAS
iS. |For i Chaired by |Minister M/o| After following _ the!
labove Rs\Secretary, Expenditure, except |DoNER and | procedure fo
500 cr, but\departments/Schemes/projects |Finance Minister, | prioritization ०
upto Rsjfor which special dispensation |except where | projects by SEC o
1000 cr. has been notified by the (special powers | NEC, proposals from|
competent authority. have been | NEC will be sent to the)
delegated by the} PD of M/o :
Finance Ministry. with the approval of
= i Secretary, NEC fo
6. |For Projects! Cabinet/Committee | Appraisal and
above Rs lof the 4 Approval. If PD, afte
1000 cr. concerned with the | doing a_ preliminary
‘subject. scrutiny of the)
proposal, finds it in
order, will send the
same to NITI
Aayog/Concerned
Line. Ministries /IFD)
‘Technical Wing M/o)
DoNER etc 2
comments/inter-
z | हद i: i _ Ministerial ie

<!-- page 4 -->

——— re eee pee कल +--+77हे
| consultations and}
| there after, PD on

| send it to DoE for
Placing before 3
EFC along with such
comments as_ pe
instructions issued by|
D/o Expenditure and
| | M/o DoNER from time
| to time. |
eeuceslememeee se ci SE OE teen |
Note: In all cases under SL. No. 1 and 2 above, AFS will be vetted by and sanctions issued with
the concurrence of FA, NEC. In cases under SL. No. 3 to 6, AFS will be vetted by and sanctions
issued with the concurrence of JS&FA, M/o DoNER before its formal issuance by NEC
Para 10 : All small projects costing upto Rs 5 Crores shall also be processed in the same
Spirit as projects between Rs 5-15 Crores. The appraisal and approval
procedure/mechanism/authority for projects up to Rs 5 Crores shall be as given under para
9 above.
3. Appraisal/Approval procedure under other schemes implemented by NEC (like
NERSDS) will be governed by Schemes Specific Guidelines.
4. NEC is requested to take further appropriate action in the matter for issuance of the
above mentioned amendment under the NEC General Guidelines, 2020 on priority basis
and convey to all NE States and all concerned. The other contents of the Guidelines
remain unchanged.
5. This issues with the approval of the Hon'ble MOS(I/C), MDoNER.
Yours leh —
(Sandeep Sin§h)
Under Secretary to the Gawt76f Ind|
Email: Sandeep.singh68@nic.in
Copy to:
1. OSD to Hon’ble MOS (॥0), MDoNER
2. PPS to Secretary, MDoNER
3. JS&FA, MDoNER
4. Deputy Secretary, IFD&BDG, MDoNER
