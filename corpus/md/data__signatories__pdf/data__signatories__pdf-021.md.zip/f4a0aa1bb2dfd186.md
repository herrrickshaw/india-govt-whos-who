---
doc_id: "f4a0aa1bb2dfd186"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/c29787700aa1d9059c64d6311a440b76.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of UL(ISP) Category 'C' license no. 821- 310/2015-DS dated 04.12.2015 for Ghaziabad SSA' & 'Moradabad SSA' in UP(West) and 'Sonipat SSA' in Haryana Service Area of M/s Shop India Now Online Sales Pvt. Ltd."
date: "2023-05-23"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a64ccda745c11fad"
---

<!-- page 1 -->

821-310/2015(Vol.III)
I/3103437/2023

WITHOUT PREJUDICE
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20-Ashoka Road, New Delhi-110001
(DS Cell)
No. 821-310/2015(Vol.III)

Dated:-23-05-2023

To
M/s Shop India Now Online Sales Pvt. Ltd
26, Panchsheel Colony, Civil Lines,
Moradabad-244001,UP
Email- sommayjain@gmail.com, stepinmbd@gmail.com
Sub:- Termination/Revocation/Cancellation of UL(ISP) Category 'C' license no. 821310/2015-DS dated 04.12.2015 for Ghaziabad SSA' & 'Moradabad SSA' in UP(West) and
'Sonipat SSA' in Haryana Service Area of M/s Shop India Now Online Sales Pvt. Ltd. ,
under condition of clause 10.2 (i) (Part-I) of the License Agreement.
In view of no reply received from you to the Show Cause Notice issued on
dated 22.03.2023 and its reminder dated 25.04.2023, it is noted that you have not
complied with the Financial conditions of the License as stated in the said show
cause notice dated 25.04.23 and it is understood that you have nothing to say
about the said show cause notice.
2.
As such, the competent Authority has decided to terminate/revoke/cancel the category
UL(ISP) Category 'C' license no. 821-310/2015-DS dated 04.12.2015 for Ghaziabad SSA'
& 'Moradabad SSA' in UP(West) and 'Sonipat SSA' in Haryana Service Area of M/s Shop
India Now Online Sales Pvt. Ltd., under condition of clause 10.2 (i) (Part-I) of the License
Agreement. Accordingly, the said license is terminated/revoked/cancelled w.e.f. 61st
calendar day from the date of issue of this letter. You are directed to terminate and stop all
interconnections with all service providers w.e.f. the date of termination of this License /
Authorization.
3.
As per condition 10.2(i) of the said Uniﬁed License Agreement, “ The Licensee shall be
required to give a notice of at least 30 Calendar days to its customers within this period of
revocation order”. Therefore, it is requested to issue notice of at least 30 Calendar days to all
your customers within 30 days from today.
4.
The Bank Guarantee(s) submitted against the said license, if not already encashed, will
be released under clause 11.2 (Part-I) of Unified License after ensuring clearance of dues.
5.
As far other dues of Data Services Cell are concerned there are no Non-Financial dues
with regard to this licensee as on date. Further, DG T, WPC, Concerned CCA, WPF
divisions are requested to ascertain their dues and issue "No Dues Certiﬁcate" or details of
dues to O/O CGCA expeditiously.
6. Kindly acknowledge the receipt.

Director (DS-II)

<!-- page 2 -->

821-310/2015(Vol.III)
I/3103437/2023

Tel: 011-2303 6860
Email: dirds2-dot@nic.in
Copy to: -

1. DG Telecom, DOT (HQ), With a request to instruct the concerned LSA / LSAs to
intimate all Licensees/Infrastructure Providers in their area to discontinue to
provide/obtain any "telecom resources” to/from the M/s Shop India Now Online
Sales Pvt. Ltd and for issue of Dues/No Dues Certificate till the effective date of
termination of License and convey to office of CGCA
2. Sr. Joint CGCA(Revenue), Oﬃce of CGCA (With a request to Release the Bank
Guarantees of the aforesaid company after ensuring dues from respective
sections of DOT as per letter no. vide letter No.1-90/2012/LF-1(Pt.1) dated
05.09.2018 and letter No.1-8/2017/LFP-1 dated 17.04.2017)
3. Secretary, (TRAI)
4. Wireless Advisor, for issue of Dues/No Dues Certiﬁcate till the eﬀective date of
termination of License and convey to office of CGCA
5. DDG(LFP).
6. CCA (UP-West)
7. Sr DDG (UP-West) LSA
8. Director (DS-III),
9. DOT Website for information of all Licensees for disconnection of
network resources as per above.
10. F.No . 821-310/2015-DS
