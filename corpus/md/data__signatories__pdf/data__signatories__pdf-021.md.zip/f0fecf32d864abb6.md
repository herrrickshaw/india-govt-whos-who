---
doc_id: "f0fecf32d864abb6"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_68dcc917bb55c8.66879597.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Gazette Notification of Cadre Review of Rajasthan Cadre of Indian Forest Service, dated 08-09-2025"
date: ""
pages: 15
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "2ccdc7215f7fdf62"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-09092025-266024
xxxGIDHxxx
CG-DL-E-09092025-266024
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 565]
No. 565]

नई दिल्ली, सोमिार, जसतम्बर 8, 2025/भार 17, 1947
NEW DELHI, MONDAY, SEPTEMBER 8, 2025/BHADRA 17, 1947

कार्मिक, लोक जिकायत तथा पेंिन मंत्रालय
(कार्मिक और प्रजिक्षण जिभाग)
अजधसूचना
नई दिल्ली, 8 जसतम्बर, 2025
सा.का.जन. 609(अ).— भारतीय िन सेिा (संिगि) जनयमािली, 1966 के जनयम 4 के उप-जनयमों (1) और (2) के
साथ पठित अजखल भारतीय सेिा अजधजनयम, 1951 (1951 का 61) की धारा 3 की उप-धारा (1) द्वारा प्रित्त िजियों का
प्रयोग करते हुए, के न्द्र सरकार, रािस्ट्थान सरकार के परामिि से भारतीय िन सेिा (संिगि पि संख्या का जनधािरण) जिजनयमन,
1966 में और संिोधन करने के जलए जनम्नजलजखत जिजनयमन बनाती है, नामत:
1.

(i) इन जनयमों को भारतीय िन सेिा (संिगि पि संख्या का जनधािरण) चौथी संिोधन जिजनयमन, 2025 कहा िाएगा।
(ii) िे सरकारी रािपत्र में उनके प्रकािन की तारीख को प्रिृत्त होंगे।

2.

भारतीय िन सेिा (संिगि पि संख्या का जनधािरण) जिजनयमन, 1966 की अनुसूची में िीर्िक “रािस्ट्थान” तथा उससे

संबंजधत प्रजिजियों के जलए जनम्नजलजखत को प्रजतस्ट्थाजपत दकया िाएगा, नामतः

5956 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

”रािस्ट्थान“
राज्य सरकार के अंतगित िठरष्ठ ड्यूटी पि

93

प्रधान मुख्य िनसंरक्षक एिं िन बल प्रमुख

1

प्रधान मुख्य िन संरक्षक (िन्द्यिीि)

1

अपर प्रधान मुख्य िन संरक्षक (जिकास) ियपुर

1

अपर प्रधान मुख्य िन संरक्षक (बाह्य सहायता प्राप्त पठरयोिना)ियपुर ,

1

अपर प्रधान मुख्य िन संरक्षक(प्रिासन एिं प्रजिक्षण), ियपुर
अपर प्रधान मुख्य िन संरक्षक एिं नोडल अजधकारी एफसीए

1

अपर प्रधान मुख्य िन संरक्षक एिं सीईओ ,सीएएमपीए

1

अपर प्रधान मुख्य िन संरक्षक (संरक्षण) एिं (एम एंड ई)

1

अपर प्रधान मुख्य िन संरक्षक (आईटी एिं ई-गिनेंस)

1

मुख्य िन संरक्षक, अिमेर

1

मुख्य िन संरक्षक, भरतपुर

1

मुख्य िन संरक्षक, बीकानेर

1

मुख्य िन संरक्षक, ियपुर

1

मुख्य िन संरक्षक, िोधपुर

1

मुख्य िन संरक्षक, कोटा

1

मुख्य िन संरक्षक, उियपुर

1

मुख्य िन संरक्षक (संरक्षण), ियपुर

1

मुख्य िन संरक्षक (कायियोिना एिं िन बंिोबस्ट्त), ियपुर

1

मुख्य िन संरक्षक, जिकास

1

मुख्य िन संरक्षक, प्रिासन

1

मुख्य िन संरक्षक, अनुसंधान एिं पिेन राज्य िनपाल(जसल्िीकल्चठरस्ट्ट)

1

मुख्य िन संरक्षक, मुरा संरक्षण, ियपुर

1

मुख्य िन संरक्षक, पठरयोिना जनमािण एिं जनगरानी एिं मूल्यांकन

1

मुख्य िन संरक्षक, बाह्य सहायता प्राप्त योिनाएं
मुख्य िन संरक्षक एिं जनिेिक आरएफडब्लल्यूटीआई

1

मुख्य िन संरक्षक, आईटी एिं ई-गिनेंस, ियपुर

1

मुख्य िन संरक्षक मुख्यालय, ियपुर

1

िन संरक्षक, ियपुर, कोटा, िोधपुर, बीकानेर, उियपुर, अिमेर, भरतपुर

7

सीएफ और फील्ड जनिेिक ,एसटीआर

1

सीएफ और फील्ड जनिेिक, एमएचटीआर

1

िन संरक्षक, सीएएमपीए

1

िन संरक्षक, एफडी आरिीटीआर

1

िन संरक्षक, एफसीए

1

िन संरक्षक, समन्द्िय

1

1

1

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

3

भारत का रािपत्र : असाधारण

िन संरक्षक, िन्द्यिीि, ियपुर एिं पीसीसीएफ (डब्लल्यूएल) के कायिकारी सहायक

1

िन संरक्षक और पीसीसीएि (एचओएफएफ) ियपुर के कायिकारी सहायक

1

िन संरक्षक, िन्द्यिीि, भरतपुर

1

िन संरक्षक, आईटी एिं ई-गिनेंस

1

िन संरक्षक, एम एंड ई, ियपुर

1

िन संरक्षक एिं क्षेत्र जनिेिक, आरटीआर

1

उप िन संरक्षक, िन्द्यिीि एिं जनिेिक, के एनपी, भरतपुर

1

उप िन संरक्षक एिं उप क्षेत्र जनिेिक, रणथम्भौर टाइगर ठरििि-1, सिाईमाधोपुर

1

उप िन संरक्षक एिं उप क्षेत्र जनिेिक, रणथम्भौर टाइगर ठरििि, सठरस्ट्का

1
33

उपिन संरक्षक, प्रािेजिक, जिला मुख्यालय: अिमेर, अलिर, बारां, बाड़मेर,
बांसिाड़ा, भरतपुर, भीलिाड़ा, बीकानेर, बूि
ं ी, जचत्तौड़गढ़, चुरु, िौसा, धौलपुर,
डू ंगरपुर, हनुमानगढ़, ियपुर, िैसलमेर, िालौर, िोधपुर, झालािाड़, झुंझुन,ू
करौली, कोटा, पाली, नागौर, प्रतापगढ़, रािसमंि, सीकर, जसरोही, श्री गंगानगर,
सिाईमाधोपु
डीसीएफ एिंर, टोंक,
कायि उियपु
योिनार। अजधकारी, पीसीसीएफ (डब्लल्यूपी एिं एफएस)

4

कायािलय
उप िन संरक्षक एिं उप क्षेत्र जनिेिक, मुकंिरा टाइगर ठरििि, सठरस्ट्का

1

उपिन संरक्षक, िैजिक उद्यान, ियपुर

1

उपिन संरक्षक, िन्द्यिीि, िैसलमेर

1

उप िन संरक्षक, ई-गिनेंस, ियपुर

1

उपिन संरक्षक, एफसीए-1

1

उपिन संरक्षक, जनगरानी एिं मूल्यांकन

1

उपिन संरक्षक, जिकास

1

1.

कु ल िठरष्ठ ड्यूटी पि

93

2.

के न्द्रीय प्रजतजनयुजि ठरििि, िो उपयुिि मि 1 के 20 % से अजधक नहीं होगा

18

3.

राज्य प्रजतजनयुजि ठरििि, िो उपयुिि मि 1 के 25 % से अजधक नहीं होगा

23

4.

प्रजिक्षण ठरििि, िो उपयुिि मि 1 के 3.5 % से अजधक नहीं होगा
छु ट्टी ठरििि और कजनष्ठ पि ठरििि, िो उपयुि
ि मि 1 के 16.5 % से अजधक नहीं
होगा

03

6.

भारतीय िन सेिा (भती) जनयमािली, 1966 के जनयम 8 के अन्द्तगित पिोन्नजत
द्वारा भरे िाने िाले पि, िो उपयुिि मि 1,2,3 और 4 के 331/3 % से अजधक
नहीं होंगे

45

7.

सीधी भती द्वारा भरे िाने िाले पि (मि 1+2+3+4+5-6)

107

कु ल प्राजधकृ त पि संख्या ( उपयुि
ि मि 6+7)

152”

5.

15

[फा. सं. 16016/02/2023 - एआईएस-II (क)]
कजिता चौहान, अिर सजचि

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

ठटप्पणी -1: इस अजधसूचना के िारी होने से पूि,ि रािस्ट्थान के भारतीय िन सेिा संिगि की कु ल प्राजधकृ त पि संख्या 145 थी।
ठटप्पणी-2: प्रधान जिजनयमन,भारतीय िन सेिा (संिगि पि संख्या का जनधािरण) जिजनयमन, 1966 में िीएसआर संख्या 1072
के माध् यम से दिनांक 31.10.1966 की अजधसूचना संख्या 6/1/66-एआईएस (IV) के माध्यम से अजधसूजचत दकए गए थे तथा
बाि में जनम्नजलजखत अजधसूचनाओं के माध्यम से इन्द्हें संिोजधत दकया गया थाःक्रम सं.

सा.का.जन.सं .

प्रकािन की जतजथ

क्रम सं.

सा.का.जन. सं.

1

प्रकािन की जतजथ

1673

30.10.66

77.

836

14.11.87

2

17

7.1.67

78.

432(अ)

6.4.88

3

653

6.5.67

79.

546(अ)

4.5.88

4

654

6.5.67

80.

834(अ)

3.8.88

5

689

13.5.67

81.

352(अ)

10.3.89

6

1083

8.6.68

82.

553(अ)

16.5.89

7

1887

9.8.69

83.

455

1.7.89

8

80

17.1.70

84.

832

11.11.89

9

485

21.3.70

85.

916

16.12.89

10

545

4.4.70

86.

933

30.12.89

11

1802

24.10.70

87.

590

22.9.90

12

135

24.1.75

88.

603

29.9.90

13

136

24.1.71

89.

728

8.12.90

14

665

8.5.71

90.

730

8.12.90

15

45(अ)

20.1.72

91.

125(अ)

5.3.91

16

47(अ)

20.1.72

92.

246

13.4.91

17

48(अ)

20.1.72

93.

473

24.8.91

18.

478(अ)

4.12.72

94.

527

14.9.91

19.

192(अ)

2.4.73

95.

565

5.10.91

20.

321(अ)

27.6.73

96.

584

19.10.91

21.

391(अ)

10.8.73

97.

538(अ)

6.8.93

22.

142

24.1.71

98.

685(अ)

4.11.93

23.

28(अ)

8.5.71

99.

687(अ)

4.11.93

24.

273(अ)

11.1.72

100.

514

22.10.94

25.

300(अ)

20.1.72

101.

513

22.10.94

26.

812

29.4.72

102.

321(अ)

31.3.95

27.

2227

16.8.75

103.

213

29.4.95

28.

71

17.1.76

104.

278

10.6.95

29.

407(अ)

16.6.76

105.

264

6.6.95

30.

1064

24.7.76

106.

339

22.7.95

31.

444(अ)

6.7.76

107.

375

12.8.95

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

5

भारत का रािपत्र : असाधारण

32.

750(अ)

3.8.76

108.

480

18.11.95

33.

93(अ)

26.2.77

109.

479

18.11.95

34.

631(अ)

5.10.77

110

503

2.12.95

35.

13(अ)

6.1.78

111

537

9.12.95

36.

360(अ)

13.7.78

112

75(अ)

5.2.96

37.

436(अ)

29.8.78

113

77(अ)

5.2.96

38.

486(अ)

25.8.80

114

231

8.6.96

39.

562(अ)

30.9.80

115

233

8.6.96

40.

626(अ)

3.11.80

116

589(अ)

26.12.96

41.

631(अ)

4.11.80

117

587(अ)

26.12.96

42.

21(अ)

17.1.81

118

585(अ)

26.12.96

43.

31(अ)

23.1.81

119

17(अ)

17.1.97

44.

84(अ)

27.2.81

120

413

20.12.97

45.

456(अ)

9.5.81

121

741(अ)

31.12.97

46.

360(अ)

23.5.81

122

40

29.1.98

47.

276(अ)

2.6.81

123

617(अ)

14.1.98

48.

386(अ)

9.6.81

124

372

10.12.99

49.

602(अ)

16.11.81

125

374

10.12.99

50.

604(अ)

17.11.81

126

824(अ)

21.10.2000

51.

653(अ)

10.12.81

127

827(अ)

21.10.2000

52.

657(अ)

11.12.81

128

830(अ)

21.10.2000

53.

294(अ)

1.4.82

129

141

27.4.2002

54.

354(अ)

26.4.82

130

143

27.4.2002

55.

356(अ)

27.4.82

131

139

27.4.2002

56.

778(अ)

31.5.82

132

145

27.4.2002

57.

530(अ)

20.8.82

133

147

27.4.2002

58.

24(अ)

12.1.83

134

372

21.9.2002

59.

126(अ)

28.2.85

135

173

26.4.2003

60.

308(अ)

26.3.85

136

34(अ)

24.1.2006

61.

327(अ)

29.3.85

137

287(अ)

16.05.2006

62.

489(अ)

12.6.86

138

289(अ)

16.05.2006

63.

266

12.4.86

139

562(अ)

15.09.2006

64.

654

30.8.86

140

564(अ)

15.09.2006

65.

763

20.9.86

141

566(अ)

15.09.2006

66.

798

27.9.86

142

724(अ)

23.11.2006

67.

796

27.9.86

143

703(अ)

12.08.2007

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

68.

835

4.10.86

144

765(अ)

12.12.2007

69.

837

4.10.86

145

609(अ)

26.08.2008

70.

880

18.10.86

146

109(अ)

21.02.2008

71.

164

14.3.87

147

610(अ)

26.08.2008

72.

407

30.5.87

148

716(अ)

03.10.2008

73.

619

15.3.87

149

748(अ)

21.10.2008

74.

802

31.10.87

150

190(अ)

24.03.2009

75.

826

7.11.87

151.

500(अ)

07.07.2009

76.

835

14.10.87

MINISTRY OF PERSONNEL, PUBLIC GRIEVANCES AND PENSIONS
(Department of Personnel and Training)
NOTIFICATION
New Delhi, the 8th September, 2025
G.S.R. 609(E).— In exercise of the powers conferred by sub-section (1) of Section 3 of the All India Service

Act, 1951 (61 of 1951), read with sub-rules (1) and (2) of Rule 4 of Indian Forest Service (Cadre) Rules, 1966,
the Central Government in consultation with the Government of Rajasthan hereby makes the following
regulations further to amend the Indian Forest Service (Fixation of Cadre Strength) Regulations, 1966,
namely:1. (i) These regulations shall be called the Indian Forest Service (Fixation of Cadre Strength) Fourth
Amendment Regulations, 2025.
(ii) They shall come into force on the date of their publication in the Official Gazette.
2.
In the Indian Forest Service (Fixation of Cadre Strength) Regulations, 1966, in the Schedule, for the
heading "Rajasthan" and the entries relating thereto, the following shall be substituted, namely :“RAJASTHAN
SENIOR DUTY POSTS UNDER THE STATE GOVERNMENT
Principal Chief Conservator of Forests & Head of Forest Force
Principal Chief Conservator of Forests (Wildlife)

93
1
1

Additional Principal Chief Conservator of Forests (Development) Jaipur
Additional Principal Chief Conservator of Forests (External Aided Project), Jaipur
Additional Principal Chief Conservator of Forests (Administration & Training), Jaipur
Additional Principal Chief Conservator of Forests & Nodal Officer FCA
Additional Principal Chief Conservator of Forests & CEO, CAMPA
Additional Principal Chief Conservator of Forests (Protection) and (M&E)
Additional Principal Chief Conservator of Forests (IT & E- Governance)

1
1
1
1
1
1
1

Chief Conservator of Forests, Ajmer
Chief Conservator of Forests, Bharatpur
Chief Conservator of Forests, Bikaner

1
1
1

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

1.
2.
3.
4.
5.

7

भारत का रािपत्र : असाधारण

Chief Conservator of Forests, Jaipur
Chief Conservator of Forests, Jodhpur
Chief Conservator of Forests, Kota
Chief Conservator of Forests, Udaipur
Chief Conservator of Forests (Protection), Jaipur
Chief Conservator of Forests (Working Plan and Forest Settlement), Jaipur
Chief Conservator of Forests, Development
Chief Conservator of Forests, Administration
Chief Conservator of Forests, Research & Ex-officio State Silviculturist
Chief Conservator of Forests, Soil Conservation, Jaipur
Chief Conservator of Forests, Project Formulation & Monitoring & Evaluation
Chief Conservator of Forests, Externally Aided Projects
Chief Conservator of Forests & Director RFWTI
Chief Conservator of Forests , IT & E-Governance, Jaipur
Chief Conservator of Forests Head Quarter, Jaipur

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1

Conservator of Forests, Jaipur, Kota, Jodhpur, Bikaner, Udaipur, Ajmer, Bharatpur
CF & Field Director, STR
CF & Field Director, MHTR
Conservator of Forests, CAMPA
Conservator of Forests, FD RVTR
Conservator of Forests, FCA
Conservator of Forests, Co-ordination
Conservator of Forests, Wildlife, Jaipur & Executive Assistant to PCCF(WL)
Conservator of Forests & Executive Assistant to PCCF(HoFF) Jaipur
Conservator of Forests, WL, Bharatpur
Conservator of Forests, IT & E-Governance
Conservator of Forests, M&E, Jaipur
Conservator of Forests & Field Director, RTR

7
1
1
1
1
1
1
1
1
1
1
1
1

Deputy Conservator of Forests, Wildlife & Director, KNP, Bharatpur
Deputy Conservator of Forests & Dy. Field Director, Ranthambore Tiger Reserve-I,
Sawaimadhopur
Deputy Conservator of Forests & Dy. Field Director, Saraiska Tiger Reserve, Sariska]
Deputy Conservator of Forests, (Territorial), District Headquarters at:
Ajmer, Alwar, Baran. Barmer, Banswara, Bharatpur, Bhilwara, Bikaner. Bundi,
Chittorgarh, Churu, Dausa, Dholpur, Dungarpur, Hanumangarh, Jaipur, Jaisalmer,
Jalore, Jodhpur, Jhalawar, Jhunjhuna, Karauli, Kota, Pali, Nagaur, Praiapgarh,
Rajsamand, Sikar, Sirohi, Sri Ganganagar, Swaimadhopur, Tonk, Udaipur.
DCF & Working Plan Officer, O/o PCCF(WP & FS)
Deputy Conservator of Forests & Dy. Field Director, Mukundra Tiger Reserve, Sariska
Deputy Conservator of Forests, Biological Park, Jaipur
Deputy Conservator of Forests, Wildlife, Jaisalmer
Deputy Conservator of Forests, E Governance, Jaipur
Deputy Conservator of Forests, FCA-I
Deputy Conservator of Forests, Monitoring & Evaluation
Deputy Conservator of Forests, Development

1
1

Total Senior Duty Posts
Central Deputation Reserve not exceeding 20% of Item 1 above
State Deputation Reserve not exceeding 25% of Item 1 above
Training Reserve not exceeding 3.5% of Item 1 above
Leave Reserve and Junior Posts Reserve not exceeding 16.5% of Item 1 above

1
33

4
1
1
1
1
1
1
1
93
18
23
3
15

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

6.
7.

[PART II—SEC. 3(i)]

Posts to be filled by promotion under Rule 8 of the Indian Forest Service
(Recruitment) Rules 1966 not exceeding 33 1/3 % of Item 1, 2, 3 and 4 above
Posts to be filled up by Direct Recruitment (Item 1+2+3+4+5-6)
Total Authorised Strength (Item 6+7 above)

45
107
152”

[F.No.16016/02/2023 - AIS-II (A)]
KAVITA CHAUHAN, Under Secy.
Note-1: Prior to the issue of this Notification, the Total Authorized Strength of the IFS cadre of Rajasthan was
145.
Note-2: The Principal regulations were notified vide notification No.6/1/66-AIS (IV), dated 31-10-1966 vide
GSR No.1072 in the Indian Forest Service (Fixation of cadre strength) Regulations, 1966, and subsequently
been amended, vide notifications given below:Sl. No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.
37.

GSR No.
1673
17
653
654
689
1083
1887
80
485
545
1802
135
136
665
45(E)
47(E)
48(E)
478(E)
192(E)
321(E)
391(E)
142
28(E)
273(E)
300(E)
812
2227
71
407(E)
1064
444(E)
750(E)
93(E)
631(E)
13(E)
360(E)
436(E)

Date of Publication
30.10.66
7.1.67
6.5.67
6.5.67
13.5.67
8.6.68
9.8.69
17.1.70
21.3.70
4.4.70
24.10.70
24.1.75
24.1.71
8.5.71
20.1.72
20.1.72
20.1.72
4.12.72
2.4.73
27.6.73
10.8.73
24.1.71
8.5.71
11.1.72
20.1.72
29.4.72
16.8.75
17.1.76
16.6.76
24.7.76
6.7.76
3.8.76
26.2.77
5.10.77
6.1.78
13.7.78
29.8.78

Sl. No.
77.
78.
79.
80.
81.
82.
83.
84.
85.
86.
87.
88.
89.
90.
91.
92.
93.
94.
95.
96.
97.
98.
99.
100.
101.
102.
103.
104.
105.
106.
107.
108.
109.
110
111
112
113

GSR No.
836
432(E)
546(E)
834(E)
352(E)
553(E)
455
832
916
933
590
603
728
730
125(E)
246
473
527
565
584
538(E)
685(E)
687(E)
514
513
321(E)
213
278
264
339
375
480
479
503
537
75(E)
77(E)

Date of Publication
14.11.87
6.4.88
4.5.88
3.8.88
10.3.89
16.5.89
1.7.89
11.11.89
16.12.89
30.12.89
22.9.90
29.9.90
8.12.90
8.12.90
5.3.91
13.4.91
24.8.91
14.9.91
5.10.91
19.10.91
6.8.93
4.11.93
4.11.93
22.10.94
22.10.94
31.3.95
29.4.95
10.6.95
6.6.95
22.7.95
12.8.95
18.11.95
18.11.95
2.12.95
9.12.95
5.2.96
5.2.96

<!-- page 9 -->

[भाग II—खण्ड 3(i)]

38.
39.
40.
41.
42.
43.
44.
45.
46.
47.
48.
49.
50.
51.
52.
53.
54.
55.
56.
57.
58.
59.
60.
61.
62.
63.
64.
65.
66.
67.
68.
69.
70.
71.
72.
73.
74.
75.
76.

9

भारत का रािपत्र : असाधारण

486(E)
562(E)
626(E)
631(E)
21(E)
31(E)
84(E)
456(E)
360(E)
276(E)
386(E)
602(E)
604(E)
653(E)
657(E)
294(E)
354(E)
356(E)
778(E)
530(E)
24(E)
126(E)
308(E)
327(E)
489(E)
266
654
763
798
796
835
837
880
164
407
619
802
826
835

25.8.80
30.9.80
3.11.80
4.11.80
17.1.81
23.1.81
27.2.81
9.5.81
23.5.81
2.6.81
9.6.81
16.11.81
17.11.81
10.12.81
11.12.81
1.4.82
26.4.82
27.4.82
31.5.82
20.8.82
12.1.83
28.2.85
26.3.85
29.3.85
12.6.86
12.4.86
30.8.86
20.9.86
27.9.86
27.9.86
4.10.86
4.10.86
18.10.86
14.3.87
30.5.87
15.3.87
31.10.87
7.11.87
14.10.87

114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151.

231
233
589(E)
587(E)
585(E)
17(E)
413
741(E)
40
617(E)
372
374
824(E)
827(E)
830(E)
141
143
139
145
147
372
173
34(E)
287(E)
289(E)
562(E)
564(E)
566(E)
724(E)
703(E)
765(E)
609(E)
109(E)
610(E)
716(E)
748(E)
190(E)
500(E)

8.6.96
8.6.96
26.12.96
26.12.96
26.12.96
17.1.97
20.12.97
31.12.97
29.1.98
14.1.98
10.12.99
10.12.99
21.10.2000
21.10.2000
21.10.2000
27.4.2002
27.4.2002
27.4.2002
27.4.2002
27.4.2002
21.9.2002
26.4.2003
24.1.2006
16.05.2006
16.05.2006
15.09.2006
15.09.2006
15.09.2006
23.11.2006
12.08.2007
12.12.2007
26.08.2008
21.02.2008
26.08.2008
03.10.2008
21.10.2008
24.03.2009
07.07.2009

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. GORAKHA NATH Digitally signed by GORAKHA
YADAVA

NATH YADAVA
Date: 2025.09.09 14:27:16 +05'30'

<!-- page 10 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-09092025-266025
xxxGIDHxxx
CG-DL-E-09092025-266025
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 564]
No. 564]

नई दिल्ली, सोमिार, जसतम्बर 8, 2025/भार 17, 1947
NEW DELHI, MONDAY, SEPTEMBER 8, 2025/BHADRA 17, 1947

कार्मिक, लोक जिकायत तथा पेंिन मंत्रालय
(कार्मिक और प्रजिक्षण जिभाग)
अजधसूचना
नई दिल्ली, 8 जसतम्बर, 2025
सा.का.जन. 608(अ).— अजखल भारतीय सेिा अजधजनयम, 1951 (1951 का 61) की धारा 3 की उपधारा- (1) द्वारा
प्रित्त िजियों का प्रयोग करते हुए के न्द्र सरकार, रािस्ट्थान सरकार के परामिि से भारतीय िन सेिा (िेतन) जनयमािली, 2016
में आगे और संिोधन करने के जलए एतद्दिारा जनम्नजलजखत जनयम बनाती है, नामत:
1.(i) इन जनयमों को भारतीय िन सेिा (िेतन) चौथी संिोधन जनयमािली, 2025 कहा िाएगा।
(ii) िे सरकारी रािपत्र में उनके प्रकािन की तारीख से प्रिृत्त होंगे।

2.

भारतीय िन सेिा (िेतन) जनयमािली, 2016 में:(क) अनुसूची II-क में, राज्य सरकारों के अधीन भारतीय िन सेिा में समय-मान से ऊपर िेतन िाले पिों में, ताजलका
में, पहले कॉलम में आने िाली "रािस्ट्थान" प्रजिजि और िूसरे कॉलम में उससे संबंजधत प्रजिजियों के जलए, जनम्नजलजखत
को प्रजतस्ट्थाजपत दकया िाएगा, नामत:

5955 GI/2025

(1)

<!-- page 11 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

"रािस्ट्थान
प्रधान मुख्य िनसंरक्षक एिं िन बल प्रमुख

िेतन मैट्ररक्स में स्ट्तर 17

प्रधान मुख्य िन संरक्षक (िन्द्यिीि)

िेतन मैट्ररक्स में स्ट्तर 16

अपर प्रधान मुख्य िन संरक्षक (जिकास) ियपुर

िेतन मैट्ररक्स में स्ट्तर 15

अपर प्रधान मुख्य िन संरक्षक (बाह्य सहायता प्राप्त पट्ररयोिना)ियपुर ,

िेतन मैट्ररक्स में स्ट्तर 15

अपर प्रधान मुख्य िन संरक्षकियपुर ,(प्रिासन एिं प्रजिक्षण)

िेतन मैट्ररक्स में स्ट्तर 15

अपर प्रधान मुख्य िन संरक्षकएिं नोडल अजधकारी एफसीए

िेतन मैट्ररक्स में स्ट्तर 15

अपर प्रधान मुख्य िन संरक्षक एिं सीईओकै म्प ,

िेतन मैट्ररक्स में स्ट्तर 15

अपर प्रधान मुख्य वन संरक्षक (संरक्षण) एवं (एम एंड ई)

िेतन मैट्ररक्स में स्ट्तर 15

अपर प्रधान मुख्य वन संरक्षक (आईटी एवं ई-गवनेंस)

िेतन मैट्ररक्स में स्ट्तर 15

मुख्य िन संरक्षकअिमेर ,

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षकभरतपुर ,

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षकबीकानेर ,

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षकियपुर ,

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षकिोधपुर ,

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षककोटा ,

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षकउियपुर ,

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक ,(संरक्षण)ियपुर

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक ,(कायियोिना एिं िन बंिोबस्ट्त)ियपुर

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक, जिकास

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षकप्रिासन ,

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक, अनुसंधान एिं पिेन राज्य िनपाल(जसल्िीकल्चट्ररस्ट्ट)

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक, मुरा संरक्षणियपुर ,

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक, पट्ररयोिना जनमािण एिं जनगरानी एिं मूल्यांकन

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक, बाह्य सहायता प्राप्त योिनाएं

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक एिं जनिेिक आरएफडब्लल्यूटीआई

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक, आईटी एिं ई-गिनेंस, ियपुर

िेतन मैट्ररक्स में स्ट्तर 14

मुख्य िन संरक्षक मुख्यालय, ियपुर

िेतन मैट्ररक्स में स्ट्तर 14

िन संरक्षक, ियपुर, कोटा, िोधपुर, बीकानेर, उियपुर, अिमेर, भरतपुर

िेतन मैट्ररक्स में स्ट्तर 13 क

सीएफ और फील्ड जनिेिक, एसटीआर

िेतन मैट्ररक्स में स्ट्तर 13 क

<!-- page 12 -->

[भाग II—खण्ड 3(i)]

3

भारत का रािपत्र : असाधारण

सीएफ और फील्ड जनिेिक, एमएचटीआर

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक, सीएएमपीए

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक, एफडी आरिीटीआर

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक, एफसीए

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक, समन्द्िय

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक, िन्द्यिीि, ियपुर एिं पीसीसीएफ (डब्लल्यूएल) के कायिकारी सहायक

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक और पीसीसीएि (एचओएफएफ) ियपुर के कायिकारी सहायक

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक, िन्द्यिीि, भरतपुर

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक, आईटी एिं ई-गिनेंस

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक, एम एंड ईियपुर ,

िेतन मैट्ररक्स में स्ट्तर 13 क

िन संरक्षक एिं क्षेत्र जनिेिकआरटीआर ,

िेतन मैट्ररक्स में स्ट्तर 13 क”

ख) अनुसूची-II ख में, रािस्ट्थान प्रजिजि के जलए समय मान में िेतन के अजतट्ररि-जििेष िेतन िाले पिों सजहत राज्य सरकारों
के अधीन भारतीय िन सेिा के िट्ररष्ठ िेतनमान में िेतन िाले पिों के जलए जनम्नजलजखत को प्रजतस्ट्थाजपत दकया िाएगा,
नामत:

“उप िन संरक्षक, िन्द्यिीि एिं जनिेिक, के एनपी, भरतपुर
उप िन संरक्षक एिं उप क्षेत्र जनिेिक, रणथम्भौर टाइगर ट्ररििि-1, सिाईमाधोपुर
उप िन संरक्षक एिं उप क्षेत्र जनिेिक, रणथम्भौर टाइगर ट्ररििि, सट्ररस्ट्का
उप िन संरक्षक, प्रािेजिक, जिला मुख्यालय: अिमेर, अलिर, बारा, बाड़मेर, बांसिाड़ा, भरतपुर, भीलिाड़ा,
बीकानेर, बूंिी, जचत्तौड़गढ़, चुरु, िौसा, धौलपुर, डू ंगरपुर, हनुमानगढ़, ियपुर, िैसलमेर, िालौर, िोधपुर,
झालािाड़, झुंझुनू, करौली, कोटा, पाली, नागौर, प्रतापगढ़, रािसमंि, सीकर, जसरोही, श्री गंगानगर,
सिाईमाधोपुर, टोंक, उियपुर।
डीसीएफ एिं कायि योिना अजधकारी, पीसीसीएफ (डब्लल्यूपी एिं एफएस) कायािलय
उप िन संरक्षक एिं उप क्षेत्र जनिेिक, मुकंिरा टाइगर ट्ररििि, सट्ररस्ट्का
उप िन संरक्षक, िैजिक उद्यान, ियपुर
उप िन संरक्षक, िन्द्यिीि, िैसलमेर
उप िन संरक्षक, ई-गिनेंस, ियपुर
उप िन संरक्षक, एफसीए-1
उप िन संरक्षक, जनगरानी एिं मूल्यांकन
उप िन संरक्षक, जिकास”
[फा. सं. 16016/02/2023– अ.भा.से-II (ख)]
कजिता चौहान, अिर सजचि

<!-- page 13 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

नोट:
प्रधान जनयम, भारत के रािपत्र, असाधारण में दिनांक 28 जसतंबर, 2016 के सा.का.जन. सं. 924 (अ) के माध्यम से
प्रकाजित और बाि में जनम्नजलजखत सा.का.जन.सं. एिंदिनांक द्वारा संिोजधत दकए गए थेेःक्रम सं.

सा.का.जन.सं.

दिनांक

1.

1105अ

30.11.2016

2.

1107

30.11.2016

3.

172 अ

27.02.2017

4.

180 अ

28.02.2017

5.

206 अ

08.03.2017

6.

262 अ

17.03.2017

7.

1003(अ)

08.08.2017

8.

1036(अ)

18.08.2017

9.

1452(अ)

27.11.2017

10.

1537(अ)

21.12.2017

11.

1587(अ)

27.12.2017

12.

511(अ)

29.05.2018

13.

289(अ)

04.04.2019

14.

338 (अ)

23.05.2025

15.

408(अ)

24.06.2025

16.

575(अ)

25.08.2025

MINISTRY OF PERSONNEL, PUBLIC GRIEVANCES AND PENSIONS
(Department of Personnel and Training)
NOTIFICATION
New Delhi, the 8th September, 2025
G.S.R. 608(E).— In exercise of the powers conferred by sub-section (1) of section 3 of the All India Services Act,
1951 (61 of 1951) the Central Government, in consultation with the Government of Rajasthan hereby makes the following
rules further to amend the Indian Forest Service (Pay) Rules, 2016 namely:1.

(i) These rules shall be called the Indian Forest Service (Pay) Fourth Amendment Rules, 2025.
(ii) They shall come into force on the date of their publication in the Official Gazette

<!-- page 14 -->

[भाग II—खण्ड 3(i)]
2.

5

भारत का रािपत्र : असाधारण

In the Indian Forest Service (Pay) Rules, 2016:-

(a) In Schedule II- A Posts carrying pay above the Time Scale in the Indian Forest Service under the State
Governments, in the Table, for the entry “Rajasthan” appearing in the first column and the corresponding entry in the second
column, the following shall be substituted, namely:“RAJASTHAN
Principal Chief Conservator of Forests & Head of Forest Force

Level 17 in the Pay Matrix

Principal Chief Conservator of Forests (Wildlife)

Level 16 in the Pay Matrix

Additional Principal Chief Conservator of Forests (Development) Jaipur

Level 15 in the Pay Matrix

Additional Principal Chief Conservator of Forests (External Aided
Project), Jaipur

Level 15 in the Pay Matrix

Additional Principal Chief Conservator of Forests (Administration &
Training), Jaipur

Level 15 in the Pay Matrix

Additional Principal Chief Conservator of Forests & Nodal Officer FCA

Level 15 in the Pay Matrix

Additional Principal Chief Conservator of Forests & CEO, CAMPA

Level 15 in the Pay Matrix

Additional Principal Chief Conservator of Forests (Protection) and
(M&E)

Level 15 in the Pay Matrix

Additional Principal Chief Conservator of Forests (IT & E- Governance)

Level 15 in the Pay Matrix

Chief Conservator of Forests, Ajmer

Level 14 in the Pay Matrix

Chief Conservator of Forests, Bharatpur

Level 14 in the Pay Matrix

Chief Conservator of Forests, Bikaner

Level 14 in the Pay Matrix

Chief Conservator of Forests, Jaipur

Level 14 in the Pay Matrix

Chief Conservator of Forests, Jodhpur

Level 14 in the Pay Matrix

Chief Conservator of Forests, Kota

Level 14 in the Pay Matrix

Chief Conservator of Forests, Udaipur

Level 14 in the Pay Matrix

Chief Conservator of Forests (Protection), Jaipur
Chief Conservator of Forests (Working Plan and Forest Settlement),
Jaipur

Level 14 in the Pay Matrix

Chief Conservator of Forests, Development

Level 14 in the Pay Matrix

Chief Conservator of Forests, Administration

Level 14 in the Pay Matrix

Chief Conservator of Forests, Research & Ex-officio State Silviculturist

Level 14 in the Pay Matrix

Chief Conservator of Forests, Soil Conservation, Jaipur

Level 14 in the Pay Matrix

Chief Conservator of Forests, Project Formulation & Monitoring &
Evaluation

Level 14 in the Pay Matrix

Chief Conservator of Forests, Externally Aided Projects

Level 14 in the Pay Matrix

Chief Conservator of Forests & Director RFWTI

Level 14 in the Pay Matrix

Chief Conservator of Forests , IT & E-Governance, Jaipur

Level 14 in the Pay Matrix

Chief Conservator of Forests Head Quarter, Jaipur

Level 14 in the Pay Matrix

Conservator of Forests, Jaipur, Kota, Jodhpur, Bikaner, Udaipur, Ajmer,
Bharatpur

Level 13A in the Pay Matrix

CF & Field Director, STR

Level 13A in the Pay Matrix

CF & Field Director, MHTR

Level 13A in the Pay Matrix

Conservator of Forests, CAMPA

Level 13A in the Pay Matrix

Conservator of Forests, FD RVTR

Level 13A in the Pay Matrix

Conservator of Forests, FCA

Level 13A in the Pay Matrix

Conservator of Forests, Co-ordination

Level 13A in the Pay Matrix

Level 14 in the Pay Matrix

<!-- page 15 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Conservator of Forests, Wildlife, Jaipur & Executive Assistant to
PCCF(WL)

Level 13A in the Pay Matrix

Conservator of Forests & Executive Assistant to PCCF(HoFF) Jaipur

Level 13A in the Pay Matrix

Conservator of Forests, WL, Bharatpur

Level 13A in the Pay Matrix

Conservator of Forests, IT & E-Governance

Level 13A in the Pay Matrix

Conservator of Forests, M&E, Jaipur

Level 13A in the Pay Matrix

Conservator of Forests & Field Director, RTR

Level 13A in the Pay Matrix”

(b) In Schedule-II B, Posts carrying pay in the Senior Scale of the Indian Forest Service under the State Governments
including posts carrying special pay in addition to pay in the Time Scale for the entry Rajasthan, the following shall be
substituted, namely:“Deputy Conservator of Forests, Wildlife & Director, KNP, Bharatpur
Deputy Conservator of Forests & Dy. Field Director, Ranthambore Tiger Reserve-I, Sawaimadhopur
Deputy Conservator of Forests & Dy. Field Director, Saraiska Tiger Reserve, Sariska]
Deputy Conservator of Forests, (Territorial), District Headquarters at:
Ajmer, Alwar, Baran. Barmer, Banswara, Bharatpur, Bhilwara, Bikaner. Bundi, Chittorgarh, Churu, Dausa,
Dholpur, Dungarpur, Hanumangarh, Jaipur, Jaisalmer, Jalore, Jodhpur, Jhalawar, Jhunjhuna, Karauli, Kota,
Pali, Nagaur, Praiapgarh, Rajsamand, Sikar, Sirohi, Sri Ganganagar, Swaimadhopur, Tonk, Udaipur.
DCF & Working Plan Officer, O/o PCCF(WP & FS)
Deputy Conservator of Forests & Dy. Field Director, Mukundra Tiger Reserve, Sariska
Deputy Conservator of Forests, Biological Park, Jaipur
Deputy Conservator of Forests, Wildlife, Jaisalmer
Deputy Conservator of Forests, E Governance, Jaipur
Deputy Conservator of Forests, FCA-I
Deputy Conservator of Forests, Monitoring & Evaluation
Deputy Conservator of Forests, Development”
[F.No.16016/02/2023 - AIS-II (B)]
KAVITA CHAUHAN, Under Secy.
Note: The Principal Rules were published in the Gazette of India, Extraordinary, vide number GSR 924 (E) dated
the 28th September, 2016 and subsequently amended by the following GSR No. and date:Sl.No.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.

GSR No.
1105E
1107
172 E
180 E
206 E
262 E
1003(E)
1036(E)
1452(E)
1537(E)
1587(E)
511(E)
289(E)
338 (E)
408(E)
575(E)

Date
30.11.2016
30.11.2016
27.02.2017
28.02.2017
08.03.2017
17.03.2017
08.08.2017
18.08.2017
27.11.2017
21.12.2017
27.12.2017
29.05.2018
04.04.2019
23.05.2025
24.06.2025
25.08.2025

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
signed by GORAKHA
and Published by the Controller of Publications, Delhi-110054. GORAKHA NATH Digitally
NATH YADAVA
YADAVA

Date: 2025.09.09 14:25:32 +05'30'
