---
doc_id: "f5dfec286ebc80bc"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/5d5323cb1bd6c0eda022140ab16f9bbc.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Advisory issued to all Universities/Institutes with regard to appointment of Research Assistants and Ph.D Scholars under SPRIHA."
date: "2025-07-15"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "95d210fb725f9823"
---

<!-- page 1 -->

P-24029/45/2018-IPR-VII
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry and Internal Trade
IPR - Copyright Section
Udyog Bhawan, New
Dated the 21" of February, 2022
To,
Vice Chancellor/Registrars of University or Institute
As per list enclosed
Subject — Appointment of Research Assistants and Ph.D Scholars in the active IPR Chair
Universities/Institutes under the SPRIHA Scheme - reg.
Sir/Mam,

Kind reference is invited to this Department's Letter No. P-24029/49/2018-IPR-VII dated
20/12/2021 regarding intimation/communication to _ this Department in respect of
appointment/termination/resignation of Research Assistants/Ph.D Fellows working under the
IPR Chairs under the SPRIHA Scheme.

ii) Recently, it has been noticed that certain IPR Chairs have sought approval of this
Department regarding appointment of Research Assistants/Ph.D Fellows. In this context, kind
attention is invited to first Para of Para 7.2 and 8.1 of the SPRIHA Guidelines wherein IPR Chair
has been designated as the appointing authority of the Research Assistants/Ph.D Fellows.
Operational Guidelines of SPRIHA has only indicated the qualification and remuneration of
those professionals engaged under the SPRIHA Scheme.
ili) The objective of designating IPR Chairs as the appointing authority of Research
Assistants/Ph.D Fellows is to provide a greater autonomy for better functioning of the day to day
activities including IPR related research and training programs as the top priority. There is no
need for seeking approval of this Department to engage Research Assistants/Ph.D Fellows as
per the SPRIHA Guideline Norms.
iv) However, this Department expects that the mode of hiring the Research Assistants/Ph.D
Fellows shall be just and transparent in order to promote IPR related research by the best
eligible candidate engaged through open competition. Besides, the letter of this Department
dated 20/12/2021 aims to prevent any kind of interruption in the day to day functioning of the
IPR Chairs and to promote efficient budgetary management of the SPRIHA Scheme.
v) It is once again reiterated that IPR Chairs are the Competent Authority to decide the
process of selection of the Research Assistants/Ph.D Fellows and the Chairs shall ensure that
the process of such engagement under SPRIHA shall be just and fair.
bi Bikram Nath
(Deputy Director)

<!-- page 2 -->

LIST

| S. No. [Name of University/institute | काका

oe  तत---+-++ जय न्चतललनस्च्च्च्त्त्न Delhi

a
ee “्7॒7ा॒खग॒“ख।ण |
eS
ce
[| 8 |
[97
<i
| 12 |
[| 14 |
