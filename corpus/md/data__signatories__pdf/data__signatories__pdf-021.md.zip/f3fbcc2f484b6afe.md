---
doc_id: "f3fbcc2f484b6afe"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/ce1a26592648ab10f1f0aaac1ecee359.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Gazette Notification dated 17-7-2012"
date: "2016-04-11"
pages: 2
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "b1c19fe5fadd8aa9"
---

<!-- page 1 -->

a . mo lin (2५ i
मु 5:
रजिस्ट्री सं० डी० एल०-33004/99 Sie: _REGD. NO. D.13300499
i
The Gazett visita { Gudia
4 है असाधारण
EXTRAORDINARY ,
+ . प्राग 1--खण्ड 1
PART I—Section 1” हु ,
प्राष्िकार से प्रकाशित
: ee | PUBLISHED BY AUTHORITY
a. 163] नई , मंगलवार, 47, 2012/आबाह़ु 26, 1934
No.163]__"__NEWDELET, TUESDAY, SUN, MUA + + NEW.DELHI, TUESDAY, JULY 17, 2012/ASADFIA 26, 1934
स्वस्थ्य और efter rarer. Tet अतः अब केंद्र सरकार एतद़रा साकाल प्रभाव से निम्मलिखित
a ‘ उपायों के कार्याव्वयन का आदेश देती है :--
( स्वास्थ्थ और घरिकर कल्थाण )
‘ G) स्थाही मिटाने तथा नेल पॉलिश रिमूवर, दोनों प्रयोजनों :
ः अधिसूचना से तथा ऐसे अन्य प्रयोजनों से किसी तरह के रासायनिक
aa संघटन के बोतलबंद करेक्‍्शन फ्लूड तथा बोतलवंद .,
नई दिल्‍ली, 17 जुलाई, 2012 धिनर की ख्युदरा छिक्रो के लिए निर्माण पर रोक
'फा, सं. एक्स, 11029/6/2010 -डीडीएपी.--यठः 3010 लगाना ।
की सिविल Re याचिका सं. 1332-व्यक्षित विकास केन्द्र बनाम भारत (a) स्याही मिटाने तथा नेल पॉलिश रिपृवर, दोनों प्रयोजनों
संघ एवं अन्य पें माननीय पंजाब एवं हरियाणा उच्च न्यायालय, से तथा ऐसे अन्य प्रमेजनों से किसी तरह के ससायनिक
चंडीगढ़ के दिनोक 25-11-2011 के आदेशों के अनुसार, सामान्यतः संघरन के बोतलबंद करेक्‍्शन फ्लूंड तथा बोतलनंद
कार्यालयों a ee wa wie 'थिमर की बिक्री पर रोक लगाता । 1
ae आए करे को लिए संस में अंदर one (ii) कलमों या ऐसी युक्तियों जिनमें इस्तेपाल करते समय
परदार्थ/द्वा के रूप में व्यापक रूप से दुरुपयोग किए जाने की सूचना सीमित मान में ससावनिक wand wee Feed
के रूप में स्याहों मिटाने के प्रयोजनार्थ तथा नेल
मिला है, कौ बिक्री को विनियित एवं नियंत्रित करने के लिए उणय fom fred, दोनों को रूप में इस्तेशाल क॑ लिए
निकालने हेतु स्वास्थ्य एव परिषार EAT aT Bd कार्व किसी ठरह के रासायनिक संघटन के करेषेशन फ्लूड
दल गठित किया गया था । फ्लू
तथा थिनर की बिक्री कौ अनुपत्ति देना 1
और जबकि ऐसे रासायनिक थिनर का इस्तेमाल नेल पॉलिश Guy करेंबिटंग फ्लूड/धिनर कौ अनुप्रयोग युक्तियों (कलम;
रिपूवर जैसे कई अन्य प्रयोजनों के लिए विभिन्न अन्य खुदा उत्पादों. या अन्यथा) पर उनमें निष्वित काष्प को हु
में भी किया जाता है । f अन्तःश्वसन/रसायतों को सेवन से स्थास्थ्य पर पड़ने
और जबकि कार्य दल॑ ने दितांक 1 2-1-2012 एवं 20-1-2012 चाले प्रभावों फे संबंध में अनिवार्य चेतावनी प्रदर्शित
को आयोजित अपनी बैठकों में इस मुद्दे पर विस्ताएपूर्वक विचार-विमर्श की जानी चाहिए ।
किया तथा उनका सर्वसम्मत विचार यह था कि इस समस्या a आदेश दिया जाता है कि इन तपायों का संबंधित सरकारी
फिय॑चित काने में प्रभावी हो सकने वाले ऊहपायों में एक उपाय इन खिभामों/प्राधिकारियों, कादून एप व्यवस्था संसंधी फभिकारियोँ, ल्यापपर
शसायनों कौ ब्रोतलबंद रूप में खुदरा बिक्री पर रोक लगाना तथा. एवं उद्योग द्वारा तत्काल प्रभाव है अनुपालन एवं कार्या्वेसन क्रिया
कलंप या ऐसी ही युक्ति के रूप में उनकी बिक्री की अनुमति at oI :
सकता है । अरूण के. पण्डा, संगुनत रचित
2619 01॥7912 दे a

<!-- page 2 -->

Ne
८ » 2____THE GAZETTE OF INDIA: EXTRAORDINARY _[Parr}“Sr™]
MINISTRY OF HEALTH AND BAMUELY WELFARE @ Banning of production of bowled Corection
@epa ‘1 Fluids as well as bottled Thinners, of any
wtment oFFiealth aad Family Welfare) : chemical compasition, both ipeink érasing
NOTIFICATION purposes as well as for usc as Naii Polisi
: removers and similar oth for retail
New Delhi the 17th July, 2012 oe rem and similar other purposes for retai
BR Ne. x. 11029/6201049D AP.— Whereas as pet @ Banning of sale of bottled Correction Fluids
the Orders dated 25-12-2011 of the Hon'ble Punjab-& as well as bottled Thinners, of any chemical
Haryana High Court, Chandigarh in the CWP No. 1332 of composition, both for ink erasing purposes
| 2010-Vyakti Vikas Kender Vs. Union of India and Odhets, as well as for use as Nai] Polish removersand =~
Task Force was constituted by the Ministry of Hedlth® & similar other purposes.
il 7 regulate’ aid ता 1
Family Welfare to devise ways and means to regulate nti’ .
control the sate of correction flzid und thimner, which lire (a) * Permitting sale of Correction Fluids as well as
chemical substances generally used in offices‘ but Thinners, of any chemical composition, both
reportedly being widely misused by chiidren/otheer for ink erasing purposes as well as foruse ay *
children as intoxicating substence/drig by inhaling them Nai! Polish removers and similar other
to get stimulating effects like drugs. aA purposes in the form of pens or similar devices
ical thinners" है : which allow limited amounts of the chemicals
And whereas such chemi thinners are also tiied to come out of those devices when used. :
in various otfier retail products for various other purpases
like nail polish remover, “4a, (iv) Mandatory waming should be made on the
“And whereas the Task Force in its meetings beta oA application devices (pens ar otherwise) of
121-2012 and 20-1-20012 deliberated on the issue iin correcting fluids/thinners regarding the effecis,
detail and was of the unanimous view that one’ <a he or health on ination of vaporiconsumption ;
measures which nay be effective in controlling the p¥ubTe of the chemicals contained therein.
may be to ban retail sale of these chemicals in bottied form : Ordered that these measures are to be complied with
and permit their sale in pen or similar form of devigay.. - ‘end implemented, with immediate effect, by concemed
Now, therefore, the Cettral pariah toby Government Departments/Authorities, law and order
orders the implementation of the following measumgp with _-—Aulthorities, trade and industry, j
immedi —
immediate effect ARUN K. PANDA, Jt.Secy.
i :
Printed bythe Manager, Goverament of India Press, Ring Road, Mayapuri, New Dethi-1 141064
and Pubfished by the Controller of Publications, Oethi-1 10054
