---
doc_id: "f1ffc4fc0005ac9d"
source_url: "https://doj.gov.in/static/uploads/2025/09/b1c9f9affeaaf77ab6f460b417a0396d.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Justice Budi Habung and 01 other, Additional Judges of the Gauhati High Court as Permanent Judges of that High Court (29.08.2025)"
date: "2025-08-29"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "986bcbc605fefcbc"
---

<!-- page 1 -->

(TO BE PUBLISHED

IN THE GAZETTE

OF INDIA, PART 1 SECTION 2)

F.No.K.130l8/02/2025-US.II (i)
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-l 10 011.
Dated 29th August, 2025.

NOTIFICATION

In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint S/Shri Justices (i) Budi
Habung and (ii) N. Unni Krishnan Nair, Additional Judges of the Gauhati High
Court, to be Judges of that High Court with effect from the date they assume
charge of their respective offices.

(Jagan7a~~!n)

Joint Secretary to the Government oflndia
Tele: 2338 3037
To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

-2 F.No.K.13018/02/2025-US.II

(i)

Dated: 29.08.2025.

Copy to:1.

2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.

S/Shri Justices (i) Budi Habung and (ii) N. Unni Krishnan Nair,
Additional Judges through the Registrar General, Gauhati High
Court, Guwahati.
The Secretary to Governor, Assam, Dispur.
The Secretary to Governor, Arunachal Pradesh, Itanagar.
The Secretary to Governor, Mizoram, Aizawl.
The Secretary to Governor, Nagaland, Kohima.
The Secretary to Chief Minister, Assam, Dispur.
The Secretary to Chief Minister, Arunachal Pradesh, Itanagar.
The Secretary to Chief Minister, Mizoram, Aizawl.
The Secretary to Chief Minister, Nagaland, Kohima.
The Secretary to the Chief Justice, Gauhati High Court, Guwahati.
The Chief Secretary, Government of Assam, Dispur.
The Chief Secretary, Government of Arunachal Pradesh, Itanagar.
The Chief Secretary to Government, Mizoram, Aizawl
The Chief Secretary to Government, Nagaland, Kohima.
The Registrar General, Gauhati High Court, Guwahati.
The Accountant General, Assam, Dispur.
The President's Secretariat, (CA.II Section), Rashtrapati Bhavan,
New Delhi.
PS to the Principal Secretary to the Prime Minister, PM's Office,
South Block, New Delhi.
Registrar (Conf.), 0/0 the Chief Justice oflndia, Room Nos. GF 1,2
and 3, Ground Floor, Supreme Court Main Building, New Delhi.
PS to the MoS (l/C) Law & Justicel PPS to the Secretary (Justice).
Technical Director, NlC, Department of Justice, with a request to
upload the notification on the website of the Department
(www.doj.gov.in).
~

rM"'~~

tJJf ·171

,.y)

(Anant Kumar)
Under Secretary to the Govt. of India
Tele: 011-2338 3087
