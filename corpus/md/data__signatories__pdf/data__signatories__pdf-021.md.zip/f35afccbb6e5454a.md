---
doc_id: "f35afccbb6e5454a"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/ba49bedc7e6ab6d90f1d1a81b8ab8470.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Corrigendum to RFP on Survey Agencies for Measurement of Cost of Regulation in India"
date: "2025-07-01"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "750eb40a52b489ca"
---

<!-- page 1 -->

Section
File
P-25020/9/2023-EODB Section
No. P-25020/9/2023-EODB
File No.
India
of India
Government
Government of
Industry
and Industry
Commerce and
of Commerce
Ministry
Ministry of
Trade
Internal Trade
and Internal
Industry and
of Industry
Department for
Promotion of
for Promotion
Department
EODB
Section
EODBSection

Delhi
New Delhi
Bhawan, New
Vanijya
Vanijya Bhawan,
2023
Dated
April,
April, 2023
Dated
CORRIGENDUM
CORRIGENDUM
appointment
for appointment
RFP for
the RFP
to the
This
reference to
with reference
is with
This is
of
Cost of
of Cost
of "Survey
Measurement of
for Measurement
Agencies for
"Survey Agencies
for
Department for
the Department
by the
published by
Regulation
India" published
in India"
Regulation in
on
18.04.2023 on
on 18.04.2023
Trade on
Internal Trade
and Internal
Industry and
of Industry
Promotion
Promotion of
Gem
(https://gem.gov.in).
Portal (https://gem.gov.in).
Gem Portal

(Bid
NO.-GEM/2023/B/3365255,
Bid No.-GEM/2023/B/3365255,
GEM/2023/B/3365179, Bid
No.- GEM/2023/B/3365179,
(Bid No.GEM/2023/B/3365355,
No.- GEM/2023/B/3365355,
Bid No.Bid No.GEM/2023/B/3365316,_Bid
No.- GEM/2023/B/3365316,
Bid No- GEM/2023/B/3365402)
GEM/2023/B/3365402)
of
exigency of
to exigency
due to
that due
informed that
is informed
In this
it is
regard, it
this regard,
2.
In
2.
"Survey
of "Survey
on appointment
RFP on
the RFP
for the
work, pre-bid
appointment of
meeting for
pre-bid meeting
work,

India"
in India"
Regulation in
of Regulation
Cost of
of Cost
Agencies for
Measurement of
for Measurement
Agencies
Bhawan,
Vanijya Bhawan,
in Vanijya
AM in
scheduled
11.00 AM
at 11.00
28.04.2023 at
for 28.04.2023
scheduled for
3.00
at 3.00
28.04.2023 at
for 28.04.2023
rescheduled for
New Delhi
Delhi has
been rescheduled
has been
New
Delhi.
New Delhi.
Bhawan, New
PM, in
in Room
Vanijya Bhawan,
218, Vanijya
No. 218,
Room No.
PM,
regretted.
is regretted.
Inconvenience is
Inconvenience

thali)
Deva thali)
(Supriya
(Supriya Deva
Director
Director
23038863
011- 23038863
Tele:
Tele: 011-
