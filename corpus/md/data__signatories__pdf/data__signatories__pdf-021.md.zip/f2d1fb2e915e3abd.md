---
doc_id: "f2d1fb2e915e3abd"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/00c94ce6fe480e00dd950ef172981871.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Transfer or Posting of STS Officers (31 dec 2015)"
date: "2015-12-31"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4848c5a19dc9695e"
---

<!-- page 1 -->

F. No. A-22012/2/2015-CLS.I
Government of India
Ministry of Labour & Employment
Shram Shakti Bhawan , Rafi Marg
New Delhi, dated 31 st Decembe r, 20 15

OFFICE ORDER NO. 38/2015
Subject: Transfer/ Posting of STS Grade Officers of CLS.
The transfer /posting of the following Senior Time Scale (STS)
Officers of Central Labour Service is ordered with immediate effe ct
aga i nst the post indicated as under:

Sl.
No.

Name of Officers
(Sh./Smt.)

Present place of posting

1.

Smt. Vas Devi K.
Kundnani,

Regional Labour
Commissioner((), Raipur

2.

Amarkant Goyal

3.

K.C. Sethi

4.

Kamaljeet Singh,

5.

P. L. Rajendran

6.

R.K. Panda

7.

Nazzer A.

8.

G.K. Mohapatra

Regional Labour
Commissioner((), CLC(C)
HQ, New Delhi
Deputy Labour Welfare
Commissioner( C),
Small Arms Factory, Kanpur
Regional
Labour
Deputy Labour Welfare
Commissioner((), Safardjung Commissioner( C), Ajmer
Hospital, New Delhi
Deputy Labour Welfare
Regional
Labour
Commissioner( C),
Commissioner( C), Madurai
Ordnance Parachute Factory,
Kanpur
Deputy Labour Welfare
Deputy Labour Welfare
Commissioner( C),
Commissioner( C),
Metal & Steel Factory,
Eastern Naval Command
Ishapore (WB)
(MO), Visakhapatnam
Deputy Labour Welfare
Deputy Labour Welfare
Commissioner( C),
Commissioner( C),
Cordite Factory, Aruvankadu Southern Naval Command,
Kochi
Regional Labour
Deputy Labour Welfare
Commissioner((), Raipur
Commissioner( C),
GIF, Jabalpur

Posted to

Deputy Labour Welfare
Commissioner((), Grey Iron
Factory (GIF), Jabalpur
Deputy Labour Welfare
Commissioner( C),
CPWD, Chandigarh
Regional
Labour
Commissioner((), Asansol

1

<!-- page 2 -->

9.

Shakuntala Patnaik

10.

Kulwant Singh
Guru

11.

R.G. Meena

Deputy Labour Welfare
Commissioner( C),
CPWD, New Delhi
Deputy Labour Welfare
Commissioner((), Ordnance
Factory, Dehradun

ur

Regional Labour
Commissioner( C),
CLC C H , New Delhi
Deputy Labour Welfare
Commissioner((), Ordnance
Depot, Shakurbasti, Delhi
Regional Labour
Commissioner C , Vadodara

2.
In partial modification to this Ministry's Office Order No. 05/2015
dated 25.03. 2015, the following transfer/posting of Senior Time Scale
Officers are also ordered with immediate effect:

Name of Officers
Sl.
No.
1.
P. Arun Kumar

2.

B.B. Rath

Place of posting
Assistant Labour
Commissioner (Central)
Chennai
Assistant labour Welfare
Commissioner (Central)
DRDO, PXE, Balasore
Chandi ur

Posted to
Deputy Labour Welfare
Commissioner( C),
515, Army Base Workshop,
Ban alore
Deputy Labour Welfare
Commissioner( C),
Ordnance Factory, Badmal,
Bolan ir

3.
All concerned Organizations are requested to relieve the Officers immediately for
enabling them to join their place of postings. The Officers concerned are directed to
submit their joining report to this Ministry through the respective Organizations of their
postings, at the earliest. In case any Officer fails to join the new place of posting within
a period of 30 days from the date of issue of this Order, appropriate action will be taken
against him.
4.
The STS Officers will not be entitled for TTA/joining time, except S.No 10 of para
1, since their transfers are based on personal requests.
5.

This issues with the approval of the Competent Authority.

(S.K. Singh)
Under Secretary to the Government of India
~ 011-23766903

2

<!-- page 3 -->

Distribution: 1. The Officers concerned.
2. The Estts/Organizations concerned.
3. PS to MOS(Independent Charge), L&E/PSO to Secretary(L&E)/
4. CLC(C), New Delhi
5. Joint Secretary (DK)
6. DGLW/ Dir.(SS)
7. Admn.I, 0/o-CLC(C), New Delhi
8. CLS.II (Vigilance) Section, Ministry of Labour & Employment
9. Personal file of the Officers concerned/Office Order bundle/spare copies.

3
