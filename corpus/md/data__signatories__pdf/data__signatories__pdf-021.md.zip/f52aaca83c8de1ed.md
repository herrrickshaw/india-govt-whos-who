---
doc_id: "f52aaca83c8de1ed"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/f2b0fde368a7b5ff1c36b23eae89d83e.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 266 of 2025 in Honble High Court of Delhi- 50th Addl List: DoT instructions dated 28.05.2025 to ISPs"
date: "2025-05-28"
pages: 28
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4dd05f4f6c38ecaf"
---

<!-- page 1 -->

813-7/25/2024-DS

I/3280860/2025

By Email/DoT Website

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Services Cell)

No. 813-7/25/2024-DS

Dated: 28-05-2025

To,
All Licensees with Internet Service Authorization

Subject: CS(COMM) 266 of 2025: Star India Private Limited versus
https//crichdplayer.org & Ors in the High Court of Delhi.

Please ﬁnd enclosed the Hon’ble High Court of Delhi order dated
25.03.2025 in the captioned suit.
2. Please refer to para 33 (i & j) of the said Court order in respect of blocking
access to the websites/domains [4 nos.] enumerated in the 50th additional list
of websites, received from the plaintiff.
3. In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access
to the said websites/domains, as above, in compliance with the said court order.
Encl: A/A

Director (DS-II)
Email: dirds2-dot@nic.in
Copy to:
i.) Sh. V. Chinnasamy, Scientist E (chinnasamy.v@meity.gov.in), Electronics
Niketan, Ministry of Electronics and Information Technology (MeitY), New Delhi for
kind information and with request to take action as per the enclosed Annexure pl.
ii.) Sh. Priyansh Kohli (priyansh@saikrishnaassociates.com), Plaintiﬀ's Counsel for
kind information and requested to take action as per the enclosed Annexure pl.

<!-- page 2 -->

50th Additional List

Websites

http://safelive.jkkllmm.info
https://crichdplaylist.extratvteam.workers.dev
https://mut100.mylife1.top
https://beautifulpeople.lovecdn.ru

<!-- page 3 -->

From: Priyansh Kohli <priyansh@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Ram Meena"<dirds2-dot@nic.in>, "Cyber Law Legal"<cyberlawlegal@meity.gov.in>, "Dr. Sandip Chatterjee"<gccyberlaw@meity.gov.in>, "Prafulla Kumar"
<pkumar@meity.gov.in>, <sathya.s@meity.gov.in>, "Abhinesh Meena"<jto2ds2-dot@gov.in>
Cc: "ashok.yadav1@jiostar.com"<Ashok.Yadav1@jiostar.com>, "Yatinder Garg"
<yatinder@saikrishnaassociates.com>, "Akshay Maloo"<amaloo@saikrishnaassociates.com>
Date: Wed, 28 May 2025 08:45:29 +0530
Subject: URGENT | DOT and MEITY | Fiftieth List of Additional Websites for Real – Time Blocking of in
Compliance of the Order dated 25.03.2025 passed by the Hon’ble Delhi High Court in Star India Private
Limited vs. https//crichdplayer.org & Ors. CS(COMM)- 266/2025
============ Forwarded message ============
Dear Sir,
We act on behalf of Star India Private Limited (‘Star’), having their offices at Star House, 95 Ganpatrao Kadam Marg,
Lower Pawel (W), Mumbai- 400013, (hereinafter referred to as “Our Client”).
This is regarding immediate and real-time blocking of access to the additional websites identified during the live telecast of
the ongoing Tata IPL 2025 (“IPL 2025”).
Our Client instituted the above-captioned Suit against various ‘rogue’ websites before the Hon’ble High Court of
Delhi, inter alia, seeking ex-parte ad-interim injunction restraining violation of its exclusive statutory rights in relation to
the IPL 2025 as well as for other reliefs.
Our Client has also arrayed various Domain Name Registrars (Defendant No.6-10), Internet and Telecom Service Providers
(ISPs / TSPs), (Defendant No. 11 – 19) as well as the concerned Government departments i.e. Department of
Telecommunication (DoT) (Defendant No. 20) and the Ministry of Information and Technology (MEITY) (Defendant No.
21), to ensure effective compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
You would recall that in the captioned matter, Hon’ble Mr. Justice Saurabh Banerjee of the Delhi High Court was pleased
to issue the following directions on 25th March 2025:
33. Accordingly, in view of the aforesaid, as also keeping in mind the existing position of law, as also to keep pace with
the changing times coupled with the changing technology, till the next date of hearing:
a. Any person/ entity including, but not limited to, the defendant nos.1 to 5 being “rogue websites”, as also their
owners, partners, officers, and all others in capacity of principal or agent acting for and on their behalf, or
anyone claiming through, by or under them, are restrained from communicating, hosting, streaming, and/ or
making available for viewing and downloading, any part of the TATA IPL 2025 matches on any electronic or
digital platform in any manner whatsoever without authorization, so as to infringe the plaintiff’s intellectual
property rights qua TATA IPL 2025;
b.
Defendant no. 6 being DNR namely Hosting Concepts B. V. is directed to block and suspend the
website https://mobicric.org/ within 72 hours, after being supplied with a copy of this order by the learned
counsel for the plaintiff;
c.
Defendant no. 7 being DNR namely PKNIC is directed to block and suspend the
website https://crictime.pk/ within 72hours, after being supplied with a copy of this order by the learned counsel
for the plaintiff;
d.
Defendant no. 8 being DNR namely TUCOWS, INC. is directed to block and suspend the
website https://crichdplayer.org/ within 72 hours, after being supplied with a copy of this order by the learned
counsel for the plaintiff;
e.
Defendant no. 9 being DNR namely CV. Jogjacamp is directed to block and suspend the
website https://bsports.moviesflixter.com within 72 hours, after being supplied with a copy of this order by the
learned counsel for the plaintiff;
f.
Defendant no. 10 being DNR namely Namecheap is directed to block and suspend the
website https://cricktv.site within 72 hours, after being supplied with a copy of this order by the learned counsel
for the plaintiff;

<!-- page 4 -->

g.
Defendant nos.6 to 10 being the DNRs are also directed to provide details of the registrants of the “rogue
websites” such as their names and contact details upon being requested by the learned counsel for the plaintiff;
h. Defendant nos.11 to 19 being the ISPs are also directed to block access to the abovenamed “rogue websites”
as mentioned in para 21.11 above, within 72 hours, after being supplied with a copy of this order by the learned
counsel for the plaintiff;
i.
‘Dynamic+’ injunction is granted in favour of the plaintiff to protect its copyrighted works as soon as they
are infringed/ created. Consequently, during the currency of the TATA IPL 2025 if, any further websites, such as
mirror/ redirect/ alphanumeric variations of the “rogue websites” are discovered which are illegally streaming
and communicating content over which the plaintiff has rights, the plaintiff will be at liberty to communicate the
details of these websites to their concerned DNRs, if available, or in the alternative to the defendant nos.11 to 19
being the ISPs for blocking the said websites. As such, upon receiving the said intimation from the plaintiff, the
concerned ISP(s) shall take steps to immediately block the said “rogue websites” on real time basis;
j.
Defendant nos.20 and 21 shall take steps to ensure that defendant nos.11 to 19, being the ISPs, comply with
the aforesaid directions, through appropriate communications and notices sent to the said ISPs which are
registered with them;
k.
However, after communicating the details of the “rogue websites” in terms of the above, the plaintiff shall
continue to file affidavits with this Court in order to ensure that this Court is informed of the said “rogue
websites”.
In light of the above, the list of additional rogue websites discovered till date during the IPL 2025 is attached herewith.
These websites are illegally streaming and communicating the IPL 2025 over which Our Client has exclusive rights.
You are hereby requested to comply with the order dated 25th March 2025 by immediately issuing notification to all the
ISPs to block access to the identified rogue websites during the course of the match, on a real-time basis so that there is no
delay.
For your convenience, the Order dated 25th March 2025 is re-attached herewith.
List of the additional websites is also enclosed herewith and the evidence against the websites is available in the link below:
https://drive.google.com/drive/folders/1d-AVlx2M-pey-LzpovZFx8MJcE7hYGxP?usp=sharing
You are hereby requested to confirm immediate compliance of the Order by issuing notification to all the ISPs.
If
you
have
any
queries
regarding
following: priyansh@saikrishnaassociates.com

this

matter,

please

feel

free

to

reach

out

to

the

Please acknowledge a safe receipt.
Sincerely,
Priyansh Kohli
Saikrishna & Associates
Counsels for Star India Private Limited
Priyansh Kohli | Associate | Saikrishna & Associates, 57, Jorbagh, New Delhi - 110003, India | Tel: +91-1140244360 | Handphone: +91-7987503554 | Enrolment Number - D/2514/2022
The Information contained in this e-mail and/or in any of the attached files is confidential and proprietary information of
Saikrishna & Associates and also the subject of legal professional privilege. This privilege is not waived or lost by mistaken
transmission or receipt. If you are not the intended recipient, any use, disclosure or copying of this mail is unauthorised. If
you have received this mail in error, please notify us at info@saikrishnaassociates.com immediately by reply email and
destroy the original.

2 Attachment(s)

Download as Zip

Add To

<!-- page 5 -->

Order dated 25.03.2025.pdf
1.8 MB

50th Additional List.xlsx
12.9 KB

<!-- page 6 -->

$~35
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 266/2025
STAR INDIA PRIVATE LIMITED
.....Plaintiff
Through: Mr. Sidharth Chopra, Mr. Yatinder
Garg, Mr. Akshay Maloo and Mr.
Priyansh Kohli, Advs
versus

HTTPS//CRICHDPLAYER.ORG/ & ORS.
Through: None.
CORAM:
HON'BLE MR. JUSTICE SAURABH BANERJEE

.....Defendants

ORDER
25.03.2025

%

I.A. 7773/2025- Pre-institution mediation
1.

Vide the present application filed under Section 12A of the

Commercial Courts Act, 2015, read with Section 151 of the Code of Civil
Procedure, 1908 (‘CPC’), the plaintiff seeks exemption from pre-litigation
mediation.
2.

Considering the averments made in the present application, as also

since the plaintiff is simultaneously seeking ex parte ad interim injunction,
and in view of the order passed by the Hon’ble Supreme Court in Yamini
Manohar v. T.K.D. Krithi 2024 (5) SCC 815, which has been followed by
a Division Bench this Court in Chandra Kishore Chaurasia v. R. A.
Perfumery Works Private Limited 2022:DHC:4454-DB, the plaintiff is
exempted from instituting pre-litigation mediation.
3.

Accordingly, the present application stands disposed of.

CS(COMM) 266/2025

Page 1 of 16

<!-- page 7 -->

I.A. 7770/2025-Exp
4.

Exemption allowed, subject to all just exceptions.

5.

The application stands disposed of.

I.A. 7771/2025-Exp. from issuing notice to D-12, D-15,D-20 and D-21
6.

Vide the present application filed under Section 80, read with

Section 151 of the CPC, the plaintiff seeks exemption from the
requirement of advance service upon the defendant nos.12, 15, 20 and 21,
namely Bharat Sanchar Nigam Limited (‘BSNL’), Mahanagar Telephone
Nigam Limited (‘MTNL’), Department of Telecommunications (‘DoT’)
and Ministry of Electronics and Information Technology (‘MEITY’)
respectively, on the ground that no formal remedy/ relief as prescribed
under the Copyright Act, 1957 (‘Act of 1957’), is being claimed against
them, as also since they are only being arrayed to ensure compliance with
any orders that may be passed by this Court.
7.

For the reasons stated in the present application, as also taking into

account the aforesaid factors, and since it would be in the interest of
justice, the plaintiff is granted exemption from effecting advance service
upon the aforesaid defendant nos.12, 15, 20 and 21, being BSNL, MTNL,
DoT and MEITY respectively.
8.

Accordingly, the present application stands disposed of.

I.A. 7772/2025-Addl.doc.
9.

Vide the present application filed under Order XI Rule 1(4) read

with Section 151 of the CPC, the plaintiff seeks leave of this Court to file
additional documents.
10.

The plaintiff will be at liberty to file additional documents at a later

stage, albeit, after initiating appropriate steps, strictly as per the provisions
CS(COMM) 266/2025

Page 2 of 16

<!-- page 8 -->

of the Commercial Courts Act, 2015 read with Section 151 of the CPC and
the Delhi High Court (Original Side) Rules, 2018.
11.

Accordingly, the present application stands disposed of.

CS(COMM) 266/2025
12.

The plaintiff, by way of the present plaint, seeks permanent

injunction and damages for infringement of copyright under the Act of
1957, as also appropriate directions to the arrayed authorities.
13.

Let the plaint be registered as a suit.

14.

Upon filing of the process fee, issue summons of the suit to the

defendants through all permissible modes, returnable before the learned
Joint Registrar on 11.07.2025.
15.

Needless to say, it shall be specified in the summons that the written

statement(s) shall be filed by each of the defendants within a period of
thirty days from the date of the receipt of the summons. Written
statement(s) shall be accompanied by affidavit(s) of admission/ denial of
documents of the plaintiff, without which the written statement(s) shall not
be taken on record.
16.

Replication(s) thereto, if any, be filed by the plaintiff within a

period of fifteen days from the date of receipt of written statement(s). The
said replication(s), if any, shall also be accompanied by affidavit(s) of
admission/ denial of documents filed by the defendants, without which the
replication(s) shall not be taken on record within the aforesaid period of
fifteen days.
17.

If, and when, any of the parties wish to seek inspection of any

document(s), the same shall be sought and given within the requisite
timelines.
CS(COMM) 266/2025

Page 3 of 16

<!-- page 9 -->

18.

List before the learned Joint Registrar for marking exhibits of

documents on 11.07.2025. It is made clear that if any party unjustifiably
denies any document(s), then such party would be liable to be burdened
with costs.
19.

List before the Court 20.08.2025.

I.A. 7769/2025-O.XXXIX r.1 and 2 CPC, ad interim injunction
20.

The present application under Order XXXIX, Rules 1 and 2 of the

CPC has been filed by the plaintiff seeking the following reliefs:
i.

Pass an order of temporary injunction restraining the
Defendant Nos. 1 to 5 (and such other websites which are discovered
during the course of the proceedings and notified on Affidavit by the
Plaintiff to have been infringing the Plaintiff’s exclusive rights and
broadcasting rights), their owners, partners, officers, and all others in
capacity of principal or agent acting for and on their behalf, or
anyone claiming through, by or under it, from in any manner
communicating, hosting, streaming, and/or making available for
viewing and downloading, without authorization, on their websites or
other platforms, through the internet in any manner whatsoever, the
Plaintiff’s Works and content related to TATA IPL 2025, so as to
infringe the Plaintiff’s exclusive rights;

ii.

Pass an order directing Defendant Nos. 6 to 10, its directors,
partners, officers, affiliates, and all others in capacity of principal or
agent acting for and, on their behalf, or anyone claiming through, by
or under it, to suspend the domain name registration of the Defendant
Nos. 1 – 5, as well as any additional infringing websites discovered
during the course of the IPL 2025 matches and notified by the Plaintiff
on Affidavit on real time basis. Specific Domain Name Registrars for
each website are disclosed under para 44 of the Plaint.

iii.

Pass an order interim injunction directing the Defendant No. 610 to disclose the following information of the Defendant Nos.1 – 5
(and such other websites which are discovered during the course of
the proceedings and notified on Affidavit by the Plaintiff to has been
infringing the Plaintiff’s exclusive rights and broadcast reproduction
rights):

a) Complete details such as name, address, email address, phone
number, IP address etc.
CS(COMM) 266/2025

Page 4 of 16

<!-- page 10 -->

b)

Mode of payment along with payment details used for
registration of domain name by the registrant(s).
iv.

Pass a temporary order directing the Defendant Nos. 11 to 19,
their directors, partners, proprietors, officers, affiliates, servants,
employees, and all others in capacity of principal or agent acting for
and on their behalf, or anyone claiming through, by or under it, to
block access to the various websites identified by the Plaintiff in the
instant suit (at S. No. 1 of the Documents),as well as any additional
infringing websites discovered during the course of the IPL 2025
matches and notified by the Plaintiff on Affidavit on real time basis.

v.
Pass an order directing the Defendant Nos. 20 and 21 to issue a
notification calling upon the various internet service providers
registered under it to block access to the various websites identified
by the Plaintiff in the instant suit (at S. No. 1 of the Documents), as
well as any additional infringing websites discovered during the
course of the IPL 2025 matches and notified by the Plaintiff on
Affidavit on real time basis.”

21.

As per the pleadings, the brief facts are that:-

21.1. The plaintiff, namely Star India Private Limited, is a company
incorporated under the Companies Act, 1956, having its registered office
at Mumbai, as well as a local office at Janpath, New Delhi-110 001, and is
a leading entertainment and media company engaged, inter alia, in the
production of popular content broadcasted on its channels. The plaintiff,
along with its affiliates, is also an exclusive right owner for several works
broadcasted on its channels, such as, Star Sports 1, Star Sports 2, Star
Plus, Star Movies, National Geographic, etc., and many of such channels
broadcast sporting events in the fields of Cricket, Football, Formula1,
Badminton, amongst others.
21.2. The plaintiff has acquired exclusive television broadcasting rights
with respect to the Indian Premier League (‘IPL’) matches in India for a
period of five years, starting from 2023 till 2027, from the event
CS(COMM) 266/2025

Page 5 of 16

<!-- page 11 -->

organizer, i.e., the Board of Control for Cricket in India (‘BCCI’) vide
Agreement dated 27.06.2022.
21.3. Vide another Agreement, also dated 27.06.2022 between Viacom 18
Media Private Limited and BCCI, exclusive media rights in India and
television rights overseas in relation to the said IPL matches were
acquired by BCCI, which were then transferred to the plaintiff vide a
composite arrangement.
21.4. The said composite arrangement was then approved by the National
Company Law Tribunal, Mumbai vide order dated 30.08.2024 wherein
media operations of Viacom 18 Media Private Limited and Digital 18
Media Limited were transferred to the plaintiff, including the right to use
the IPL logos and other associated marks.
21.5. The said IPL matches were agreed to be exclusively streamed on
the Plaintiff’s Over-the-Top (‘OTT’) platform, i.e., JioHotstar and its
channels.
21.6. In light of the above, the plaintiff, being a right holder of ‘original
works’ as envisaged under Section 37 of the Act of 1957, is entitled to the
protection available therein.
21.7. The cause of action first arose on 19.03.2025 when the defendant
nos.1 to 5 being “rogue websites” unlawfully streamed sporting events in
which the plaintiff had exclusive rights without authorization from the
plaintiff or the owner of rights of the said sporting events, such as the
recently concluded Women’s Premier League, 2025.
21.8. To this effect, an affidavit of Mr. Nagesha P., Senior Manager of
Monitoring and Enforcement at Copyright Integrity Advisory (India)
Private Limited, appointed as Inspector by the plaintiff, has been filed. It
CS(COMM) 266/2025

Page 6 of 16

<!-- page 12 -->

is stated therein that such “rogue websites” use the technique of URLredirection/ domain-redirection to avoid detection and circumvent any
orders passed directing the blocking of such website domains/ URLs.
21.9. The cause of action is a continuous one as, seeing the precedent of
unlawful activity, and also that their very business model appears to be
illegally streaming content in which third-parties have exclusive rights,
the plaintiff has full conviction that the said “rogue websites” will once
again indulge in illegal streaming of the upcoming IPL Matches of 2025,
i.e., TATA IPL 2025, which recently commenced on 22.03.2025, and
apprehends that irreparable harm will be caused to the plaintiff if it is not
granted an ex parte ad interim injunction against the said “rogue
websites” and their aids at the earliest.
21.10.This Court has jurisdiction to entertain the present application as
per Section 20(c) of the Act of 1957, as the cause of action for the
accompanying plaint has arisen within its territorial jurisdiction, with the
infringing actions of the “rogue websites” and their facilitators targeting
viewers situated within the precincts of this Court, where the said “rogue
websites” are also available.
21.11.Defendant nos.6 to 10 being Domain Name Registrars (‘DNRs’)
with respect to the said “rogue websites” have provided platform access
to them, and are also responsible for withholding and retaining
information qua their creators, such as name(s), address(es), and the like.
The list of such “rogue websites” and respective DNRs is as follows:
Defendant Rogue Website

Defendant

No.

No.

CS(COMM) 266/2025

DNR

Page 7 of 16

<!-- page 13 -->

1

https://mobicric.org/

6

Hosting
Concepts
B.V.

2

https://crictime.pk/

7

PKNIC

3

https://crichdplayer.org/

8

TUCOWS,
INC.

4

https://bsports.moviesflixter.com 9

CV.
Jogjacamp

5

https://cricktv.site

10

Namecheap

21.12. Since the defendant nos.11 to 19 are Internet Service Providers
(‘ISPs’) and, hence are instrumental in the functioning of the said “rogue
websites”, being responsible for provision of internet services across India,
they have been arrayed as such. The said defendant nos.11 to 19 have a
responsibility to ensure that no violation of third-party intellectual property
rights takes place through their networks.
21.13. It is noteworthy that each of the said DNRs (defendant nos.6 to 10)
and ISPs (defendant nos.11 to 19) have been served advance caution notices
on behalf of the plaintiff prior to the institution of the present suit, urging
them to block access to the said “rogue websites” and to not facilitate illegal
streaming of TATA IPL 2025.
21.14. The DoT and the MEITY have also been arrayed as defendant nos.20
and 21 respectively, for the purposes of assistance and ensuring compliance
with any orders that may be passed by this Court.
CS(COMM) 266/2025

Page 8 of 16

<!-- page 14 -->

21.15.John Doe has also been arrayed as defendant no.22 in the form of a
generic identity to protect the plaintiff against infringement by any other
party which may be discovered at a later stage/ spring up in the spur of the
moment even during live telecast of the IPL matches from TATA IPL
2025, to infringe their content.
21.16.Interestingly, prior to the institution of the present suit, in as many
as eighteen (18) cases, real time live blocking relief has been granted by
this Court in favour of the same plaintiff, i.e. Star India Private Limited, in
similar matters. In fact, recently in a case bearing no. CS (COMM)
136/2025 entitled Star India Pvt. Ltd. v. webcrichd.com & Ors. decided
on 17.02.2025, this Court has also granted dynamic injunction for the
event of “ICC Champions Trophy 2025”. Particulars of such cases have
been reproduced on page 6 of the present application, which the learned
counsel for the plaintiff has taken this Court through.
22.

Placing reliance thereon, learned counsel for the plaintiff, while

addressing arguments, stresses on the urgent need to arrive at a real time
solution which protects the plaintiff from websites that could, plausibly,
instantaneously telecast entire sports events and related matches from
TATA IPL 2025, as and when they take place, thereby impinging upon the
rights of the plaintiff with impunity, and under such circumstances,
waiting for the respective affidavits to be filed before this Court would
lead to a huge time lag, thereby rendering the rights guaranteed to the
plaintiff under the Act of 1957 infructuous.
23.

To

further

substantiate

the

plaintiff’s

apprehensions

qua

infringement of its rights, learned counsel for the plaintiff submits that the
“rogue websites” have an evident disregard for the provisions of the Act
CS(COMM) 266/2025

Page 9 of 16

<!-- page 15 -->

of 1957, which is clearly discernible from the manner in which they
stream copyrighted content without any authorization in which thirdparties, including the plaintiff herein, are right holders.
24.

This Court has heard the submissions of the learned counsel for the

plaintiff and perused the judgments and pleadings on record.
25.

In effect, the plaintiff is seeking a ‘dynamic+’ injunction, a form of

injunctive relief which is being granted by Court(s) in similar matters in
the recent years, primarily with a view to protect parties like the plaintiff
herein against rapidly developing online infringement platforms. For
instance, the Bombay High Court, in a case bearing no. I. A. (Lodging)
10257/2023 entitled Applause Entertainment Private Limited v. Meta
Platforms Inc. & Ors., which was a case involving audio-visual extracts
of certain “web-series” being streamed illegally on multiple platforms,
granted real time relief in the form of a ‘dynamic+’ injunction to the
plaintiff therein. Similarly, a Coordinate Bench of this Court in Universal
City Studios LLC v. Dotmovies.baby 2023:DHC:5842 has, also while
granting such a ‘dynamic+’ injunction, observed that any injunction
granted by this Court ought to be effective in nature.
26.

Therefore, the position of law apparent therefrom, which has since

developed with the passage of time, clearly reflects that the rights of a
plaintiff, who is an intellectual property right holder, cannot be rendered
otiose in this world of rapidly developing technology and for that,
enforcement of intellectual property rights on any social platform,
including but not limited to, the internet as well alongwith the real world,
ought to be visible and effective.

CS(COMM) 266/2025

Page 10 of 16

<!-- page 16 -->

27.

The upcoming technology and the technological advances

association

therewith,

have

their

own

implication(s)

and/

or

ramification(s), which are not only reachable far and wide, but are also
unpredictable. With the immense degree of freedom enjoyed by
developers and innovators globally today, all and sundry, especially those
intellectual property right holders like the plaintiff herein, are prone to/
may be exposed and/ or vulnerable to the actions of the “rogue websites”
herein, more so, if such right holders like the plaintiff herein, are not
accorded proper protection from them. On one hand, though such
intellectual property right holders like the plaintiff herein, can proceed in
the normal manner, however, on the other hand, without any proper
channelization, their intellectual property rights are prone to get effected
by such “rogue websites”, who have no right, title and/ or interest therein.
This would lead them and their facilitators to freely and blatantly exploit
the rights of the right holders like the plaintiff herein, causing irreparable
loss, damage and injury to them as also leaving them struggling on the
fence exposed dangerous edge of technology.
28.

This so-called dangerous edge has become even sharper with the

fast-paced evolution of certain “hydra-headed” websites, which, even if
blocked/ deleted, have the incredulous potential to resurface in multitudes
as alphanumeric or mirror websites, with only minor, mechanical changes
within seconds. Such “hydra-headed” websites, under the garb of privacy,
are able to mask their registration/ contact details perfectly, making it
virtually impossible to locate and contact their operators to, if necessary,
demand cessation of infringing conduct.

CS(COMM) 266/2025

Page 11 of 16

<!-- page 17 -->

29.

In essence, as per the case set up by the plaintiff, the “rogue

websites” are in flagrant infringement/ facilitation of infringement as is
evident from the unabashed streaming and advertising of the copyrighted
content on such “rogue websites”, of which the plaintiff herein, is the
right holder. Moreover, the systematic, organised and intentional nature of
the infringement, and the regularity and consistency with which the said
content is being updated/ uploaded on the said “rogue websites” shows
the extent of the violation of the rights of the plaintiff in real time. The
said “rogue websites” are also employing the URL-redirection and
identity masking methods as noted above, putting the plaintiff in an even
more precarious condition to defend itself against their infringing actions.
Under such circumstances, the defendants’ silence/ inaction to notices
demonstrates the “hydra-headed” nature of these “rogue websites” which,
even if blocked, multiply and resurface as alphanumeric or mirror
websites within seconds.
30.

Thus, in light of the violations that have already been committed by

the “rogue websites” herein, this Court sees every likelihood that such
“rogue websites” will continue to stream copyrighted works to the public
during the currency of TATA IPL 2025 without authorization or license
from the plaintiff.
31.

In view of the aforesaid circumstances, discussions and analyses,

this Court is of the view that the plaintiff has been able to make out a
prima facie case with the balance of convenience in its favour for grant of
an ex parte ad interim injunction, not only qua the present but also qua the
future, without which the plaintiff will likely suffer irreparable harm,

CS(COMM) 266/2025

Page 12 of 16

<!-- page 18 -->

loss, injury and prejudice which will not be compensable in terms of
money.
32.

Furthermore, such a relief is called for in the present matter,

especially, in view of the fact that these are T-20 matches and any delay in
blocking these “rogue websites” would, in fact, result in irreparable loss
and injury to the plaintiff and cause violation of the intellectual property
rights of the plaintiff.
33.

Accordingly, in view of the aforesaid, as also keeping in mind the

existing position of law, as also to keep pace with the changing times
coupled with the changing technology, till the next date of hearing:
a.

Any person/ entity including, but not limited to, the

defendant nos.1 to 5 being “rogue websites”, as also their
owners, partners, officers, and all others in capacity of principal
or agent acting for and on their behalf, or anyone claiming
through, by or under them, are restrained from communicating,
hosting, streaming, and/ or making available for viewing and
downloading, any part of the TATA IPL 2025 matches on any
electronic or digital platform in any manner whatsoever without
authorization, so as to infringe the plaintiff’s intellectual property
rights qua TATA IPL 2025;
b.
V.

Defendant no. 6 being DNR namely Hosting Concepts B.
is

directed

to

block

and

suspend

the

website

https://mobicric.org/ within 72 hours, after being supplied with a
copy of this order by the learned counsel for the plaintiff;
c.

Defendant no. 7 being DNR namely PKNIC is directed to

block and suspend the website https://crictime.pk/ within 72
CS(COMM) 266/2025

Page 13 of 16

<!-- page 19 -->

hours, after being supplied with a copy of this order by the
learned counsel for the plaintiff;
d.

Defendant no. 8 being DNR namely TUCOWS, INC. is

directed

to

block

and

suspend

the

website

https://crichdplayer.org/ within 72 hours, after being supplied
with a copy of this order by the learned counsel for the plaintiff;
e.

Defendant no. 9 being DNR namely CV. Jogjacamp is

directed

to

block

and

suspend

the

website

https://bsports.moviesflixter.com within 72 hours, after being
supplied with a copy of this order by the learned counsel for the
plaintiff;
f.

Defendant no. 10 being DNR namely Namecheap is

directed to block and suspend the website https://cricktv.site
within 72 hours, after being supplied with a copy of this order by
the learned counsel for the plaintiff;
g.

Defendant nos.6 to 10 being the DNRs are also directed

to provide details of the registrants of the “rogue websites” such
as their names and contact details upon being requested by the
learned counsel for the plaintiff;
h.

Defendant nos.11 to 19 being the ISPs are also directed to

block access to the abovenamed “rogue websites” as mentioned
in para 21.11 above, within 72 hours, after being supplied with a
copy of this order by the learned counsel for the plaintiff;
i.

‘Dynamic+’ injunction is granted in favour of the

plaintiff to protect its copyrighted works as soon as they are
infringed/ created. Consequently, during the currency of the
CS(COMM) 266/2025

Page 14 of 16

<!-- page 20 -->

TATA IPL 2025 if, any further websites, such as mirror/ redirect/
alphanumeric variations of the “rogue websites” are discovered
which are illegally streaming and communicating content over
which the plaintiff has rights, the plaintiff will be at liberty to
communicate the details of these websites to their concerned
DNRs, if available, or in the alternative to the defendant nos.11
to 19 being the ISPs for blocking the said websites. As such,
upon receiving the said intimation from the plaintiff, the
concerned ISP(s) shall take steps to immediately block the said
“rogue websites” on real time basis;
j.

Defendant nos.20 and 21 shall take steps to ensure that

defendant nos.11 to 19, being the ISPs, comply with the aforesaid
directions, through appropriate communications and notices sent
to the said ISPs which are registered with them;
k.

However, after communicating the details of the “rogue

websites” in terms of the above, the plaintiff shall continue to file
affidavits with this Court in order to ensure that this Court is
informed of the said “rogue websites”.
34.

Upon filing of process fee, issue notice to the defendants through all

permissible modes, including through email, returnable before the learned
Joint Registrar on 11.07.2025.
35.

Reply be filed within eight weeks with advance copy to counsel for

plaintiff. Rejoinder thereto, if any, be filed on or before the next date of
hearing.
36.

The provisions of Order XXXIX Rule 3 of the CPC be complied

with within one week.
CS(COMM) 266/2025

Page 15 of 16

<!-- page 21 -->

37.

List before the learned Joint Registrar on 11.07.2025 for completion

of service and pleadings.
38.

List before this Court on 20.08.2025.

MARCH 25, 2025
Ab

CS(COMM) 266/2025

SAURABH BANERJEE, J.

Page 16 of 16

<!-- page 22 -->

<!-- page 23 -->

<!-- page 24 -->

<!-- page 25 -->

<!-- page 26 -->

<!-- page 27 -->

<!-- page 28 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
It is observed that a number of
issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially i
s, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by
