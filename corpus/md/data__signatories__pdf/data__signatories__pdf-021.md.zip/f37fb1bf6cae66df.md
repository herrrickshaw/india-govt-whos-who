---
doc_id: "f37fb1bf6cae66df"
source_url: "https://powermin.gov.in/static/uploads/2025/07/d66369eccbb91da72f5296830c58a153.pdf"
ministry: "Power"
title: "Electricity Distribution Accounts and Additional Disclosure Rules 2024."
date: "2024-10-10"
pages: 31
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "bf1dee38eaf2afab"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-24102024-258200
xxxGIDHxxx
CG-DL-E-24102024-258200
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 579]

नई दिल्ली, सोमिार, अक्तूबर 14, 2024/ आजिन 22, 1946

No. 579]

NEW DELHI, MONDAY, OCTOBER 14, 2024/ ASHVINA 22, 1946

जिद्युत मंत्रालय

अजधसूचना
नई दिल्ली, 10 अक्तूबर, 2024
सा. का. जन. 635(अ).—कें द्रीय सरकार, कं पनी अजधजनयम, 2013 (2013 का 18) की धारा 129 की उपधारा
(1) के िूसरे परं तुक के साथ पठित जिद्युत अजधजनयम, 2003 (2003 का 36) की धारा 176 की उपधारा (1) और उपधारा
(2) के खंड (य) के अनुसरण में, जनम्नजलजखत जनयम बनाती है, अथाात् :-1.

संजिप्त नाम और प्रारं भ--(1) इन जनयमों का संजिप्त नाम जिद्युत जितरण (लेखा और अजतठरक्त प्रकटीकरण) जनयम,
2024 है ।
(2) ये रािपत्र में उनके प्रकािन की तारीख को प्रिृत्त होंगे ।

2.

लागू होना--ये जनयम जनर्िाष्ट इकाई को लागू होंगे ।

3.

पठरभाषा--(1) इन जनयमों में, िब तक संिभा से अन्यथा अपेजित न हो,-(क) “अजधजनयम” से जिद्युत अजधजनयम, 2003 (2003 का 36) अजभप्रेत है ;
(ख) “अजतठरक्त प्रकटीकरण जििरण” से इन जनयमों से संलग्न अनुसूची में यथाउपबंजधत जिजिजष्टयां प्रकट करने िाले
कथन अजभप्रेत है ;
(ग) “कं पनी अजधजनयम” से कं पनी अजधजनयम, 2013 (2013 का 18) अजभप्रेत है ;

6653 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(घ) “जित्तीय जििरण” से कं पनी अजधजनयम की धारा 129 के साथ पठित धारा 2 के खंड (40) में यथा जिजनर्िाष्ट
जित्तीय जििरण अजभप्रेत है ;
(ङ) “जित्तीय िषा” से कं पनी अजधजनयम की धारा 2 के खंड (41) में यथा जिजनर्िाष्ट जित्तीय िषा अजभप्रेत है ;
(च) “अनुसच
ू ी” से इन जनयमों से संलग्न अनुसूची अजभप्रेत है ;
(छ) “जिजनर्िाष्ट इकाई” से जितरण अनुज्ञजप्तधारी अजभप्रेत है, जिसमें के न्द्रीय और राज्य सरकार के सरकारी जिभाग,
बोडा और जनगमों या अन्य एिेंजसयां, िैसे सैन्य इं िीजनयरी सेिाएं, नगर जनगम, पत्तन, पठरिहन उपक्रम,
िामोिर घाटी जनगम, सजममजलत नहीं हैं, जिन्हें अजधजनयम की धारा 14 के अंतगात अनुज्ञजप्तधारी समझा गया है ;
(ि) “टैठरफ सहाजयकी” से राज्य सरकार द्वारा दकसी जिजनर्िाष्ट इकाई को, अजधजनयम की धारा 65 के अधीन
यथापठरभाजषत उपभोक्ताओं की कजतपय श्रेजणयों को सहाजयकी िरों पर जिद्युत के जिक्रय के जलए प्रिान की गई,
सहाजयकी अजभप्रेत है ;
(झ) “व्यापार प्राप्य” से कारबार के सामान्य उपक्रम में जिद्युत के जिक्रय या प्रिान की गई संबंजधत सेिाओं के मद्दे प्राप्य
कोई रकम अजभप्रेत है ।
(2) उन िब्िों और पिों के , िो यहां प्रयुक्त हैं और इन जनयमों में पठरभाजषत नहीं हैं, के िहीं अथा होंगे, िो ऐसे िब्िों
और पिों के , यथाजस्ट्थजत, इस अजधजनयम या कं पनी अजधजनयम या उनके अधीन बनाए गए जनयमों कें क्रमि:
दिए गए हैं ।
4.

रािस्ट्ि की पहचान--टैठरफ के माध्यम से िसूली योग्य होने िाले िािों या रकम के जलए, ऐसी िस्ट्तुओं और रकमों की,
जिनका टैठरफ आिेिों में िसूली योग्य के रूप में उपबंध दकया गया है, जित्तीय जििरणों में रािस्ट्ि के रूप में पहचान
की िाएगी :
परं तु दकसी रकम, जिनका टैठरफ आिेिों में उपबंध नहीं दकया गया है, की जित्तीय जििरणों में भजिष्य के टैठरफ से
िसूली योग्य रािस्ट्ि या आय के रूप में पहचान नहीं की िाएगी ।
स्ट्पष्टीकरण--इन जनयमों के प्रयोिनों के जलए, यह स्ट्पष्ट दकया िाता है दक,-(i)

रािस्ट्ि से अनुसूची के अजतठरक्त प्रकटीकरण जििरणों में यथा उपबंजधत जित्तीय जििरणों में रािस्ट्ि के रूप
में िर्िात होने िाली मिें या रकम अजभप्रेत है ।

(ii) टैठरफ सहाजयकी की पहचान और गणना इस संबंध में बनाए गए जनयमों के अनुसार की िाएगी ।
5.

व्यापार प्राप्य का उपबंध दकया िाना--दकसी जिजनर्िाष्ट इकाई के जलए उपभोक्ताओं के सभी प्रिगों से उसके व्यापार
प्राप्यों के जलए जित्तीय जििरणों में न्यूनतम उपबंध अपेिाएं नीचे िी गई सारणी के प्ररूप में जनम्नानुसार होगी
सारणी

भुगतान की जनयत तारीख से जनम्नजलजखत अिजध
के जलए बकाया व्यापार प्राप्य

उपबंध का %
जि.ि. 2024-25

जि.ि. 2025-26

जि.ि. 2026-27 और
उसके पश्चात्

0 से 90 दिन तक

-

-

-

90 दिन से अजधक और 180 दिन तक

5%

10%

15%

180 दिन से अजधक और 1 िषा तक

20%

25%

30%

1 िषा से अजधक और 2 िषा तक

35%

40%

45%

2 िषा से अजधक और 3 िषा तक

55%

60%

75%

3 िषा से अजधक

75%

80%

100%

स्ट्थायी रूप से कटे हुए कनेक्िनों के उपभोक्ताओं से
बकाया

75%

75%

75%:

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

परं तु इस जनयम में अंतर्िाष्ट कोई बात जनम्नजलजखत को लागू नहीं होगी :-(i) सरकारी उपभोक्ताओं से व्यापार प्राजप्तयां ; या
(ii) जनर्िाष्ट इकाई जिसका व्यापार प्राप्य दिन कु ल आधार पर नब्बे दिन से कम या उसके बराबर है :
परं तु उपयुक्त आयोग राज्य सरकार द्वारा गठित सजमजत, जिसमें प्रधान सजचि (जिद्युत), प्रधान सजचि (जित्त) और
जिजनिष्ट संस्ट्था के अध्यि और प्रबंध जनिेिक सिस्ट्य के रूप में सजममजलत होंगे, की जसफाठरिों पर उच्चतर उपबंध की
आिश्यकता जनधााठरत कर सकता है ।
स्ट्पष्टीकरण--इस जनयम के प्रयोिनों के जलए,-(i)

सरकारी उपभोक्ताओं पि से राज्य सरकार और के न्द्रीय सरकार के स्ट्िाजमत्ि िाले या संबंजधत जिभाग, िहरी
स्ट्थानीय जनकाय, ग्रामीण स्ट्थानीय जनकाय, सािािजनक िेत्र के उपक्रम और ऐसे ही उपक्रम अजभप्रेत हैं ; और

(ii) व्यापार प्राप्य दिन पि से जित्तीय िषा के अंत में व्यापार प्राप्य प्रजत दिन औसत रािस्ट्ि से जिभाजित अजभप्रेत है ।
6.

अजतठरक्त प्रकटीकरण जििरणों की सामग्री और रूप--(1) कं पनी अजधजनयम के अधीन दकए गए िैधाजनक प्रकटीकरण
के अलािा, जनर्िाष्ट इकाई अनुसूची में प्रिान दकए गए रूप और तरीके से प्रत्येक जित्तीय िषा के जलए अजतठरक्त
प्रकटीकरण जििरण भी तैयार करे गी ।
स्ट्पष्टीकरण--इस जनयम के प्रयोिनों के जलए, यह स्ट्पष्ट दकया िाता है दक जनर्िाष्ट इकाई के जिद्युत से संबंजधत कारबार
के जलए अजतठरक्त प्रकटीकरण जििरण तैयार दकए िाने की आिश्यकता है ।
(2) अजतठरक्त प्रकटीकरण जििरण जनर्िाष्ट इकाई द्वारा तैयार दकए गए जित्तीय जििरणों का जहस्ट्सा होंगे और जित्तीय
जििरणों के खातों के जलए नोट्स के अधीन 'अजतठरक्त प्रकटीकरण जििरण' िीषाक िाले अंजतम प्रकटीकरण के रूप में
जित्तीय जििरणों से िुडे होंगे :
परं तु अजतठरक्त प्रकटीकरण जििरण तैयार करने के पहले िषा में, जनर्िाष्ट इकाई के पास िार्षाक ठरपोटा या जित्तीय
जििरणों में अजतठरक्त प्रकटीकरण जििरण सजममजलत करने का जिकल्प होगा ।
(3) अजतठरक्त प्रकटीकरण जििरणों में जनम्नजलजखत कथन सजममजलत होंगे, अथाात् :-(i)

जित्तीय जििरणों के अनुपरू क प्रकटीकरण ;

(ii) जिद्युत क्रय और ऊिाा लेखांकन ब्यौरे ;
(iii) आपूर्ता की औसत लागत - औसत रािस्ट्ि प्राप्त अंतर का जििरण ;
(iv) सकल तकनीकी एिं िाजणजज्यक हाजन का जििरण ; और
(v) जिजनिष्ट जनकाय का जनष्पािन सारांि ।
स्ट्पष्टीकरण--िंकाओं को िूर करने के जलए, यह स्ट्पष्ट दकया िाता है दक अजतठरक्त प्रकटीकरण जििरणों की तैयारी के
पहले िषा के जलए, जपछले जित्तीय िषा के तुलनात्मक आंकडे िैकजल्पक होंगे।
7.

अनुपालन का जििरण--अनुपालन का एक जििरण जनर्िाष्ट इकाई के प्रबंधन द्वारा अजतठरक्त प्रकटीकरण जििरणों के
प्रारं भ में, यह पुजष्ट करते हुए दिया िाएगा दक अजतठरक्त प्रकटीकरण जििरण तैयार दकए गए हैं और अनुसूची में प्रिान
दकए गए रूप और तरीके से प्रस्ट्तुत दकए गए हैं।
अनुसच
ू ी: अजतठरक्त प्रकटीकरण जििरण (एडीएस)
अजतठरक्त प्रकटीकरण जििरण 1: जित्तीय जििरणों के जलए अनुपरू क प्रकटीकरण

1.
जििरण

प्रचालन से रािस्ट्ि :
31 माचा, 2020 को समाप्त
िषा के जलए
..

31 माचा, 2020 को समाप्त
िषा के जलए
..

(चालू िषा)

(जपछला िषा)

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

(1)

(2)

(क) ऊिाा के जिक्रय से रािस्ट्ि
अपने उपभोक्ताओं को जबिली का जिक्रय जनम्न िाब
(एलटी), उच्च िाब (एचटी) और अजतठरक्त उच्च िाब
(ईएचटी))
ईंधन समायोिन िुल्क (एफएसी)/ ईंधन लागत समायोिन
(एफसीए)/ ईंधन और जबिली क्रय लागत समायोिन
(एफपीपीसीए)/ जबिली क्रय समायोिन चािा (पीपीसीए)
जितरण फ्रैंचाइिी को जिक्रय
िूसरों को जबिली का जिक्रय (िैसे अंतर-राज्यीय
जिक्रय/ऊिाा व्यापार/अजनधााठरत अंतर-पठरितान
(यूआई)/जिचलन जनपटान तंत्र (डीएसएम)/अंतर जडस्ट्कॉम
जिक्रय, आदि)
उपभोक्ताओं से प्राप्त अन्य प्राजप्तयां (िैसे मीटर दकराया,
सेिा दकराया, जबिली चोरी और अनाचार के जलए िसूली,
आदि)
(i) कु ल
घटाएँ: उपभोक्ताओं को ठरबेट (यदि कोई हो, नकि छू ट के
अजतठरक्त) (ii)
टैठरफ सहायकी के जबना ऊिाा के जिक्रय से रािस्ट्ि (i-ii)
िोडें: उपभोक्ताओं को दिया िाने िाला जबिली िुल्क/अन्य
कर
घटाएँ: जबिली िुल्क/सरकार को िेय अन्य कर
ऊिाा के जिक्रय से प्राप्त रािस्ट्ि का उप-योग
(ख) अन्य पठरचालन आय
चक्रण चािा
खुली पहुंच चािा
अन्य
(ग) सहायकी
जिद्युत (जद्वतीय संिोधन) जनयम, 2023 के अनुसार राज्य
सरकार द्वारा िेय सहायकी, ऊिाा खातों के अनुसार
सहायकी प्राप्त श्रेजणयों को आपूर्ता की गई इकाईयों की
संख्या के अनुसार प्रजत यूजनट सहायकी से गुणा की िाती है
प्राप्त सहायकी
पठरचालन से कु ल रािस्ट्ि (क+ख+ग)
ठटप्पण: रािस्ट्ि को इन जनयमों के जनयम 4 के अनुसार मान्यता िी िाएगी।

[PART II—SEC. 3(i)]

(3)

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

5

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

7

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

5. अन्य आय :
जििरण

31 माचा, 20.. को समाप्त िषा
के जलए
(चालू िषा)

31 माचा, 20.. को समाप्त िषा
के जलए
(जपछला िषा)

(2)

(3)

(1)
ब्याि आय
(i) बैंक िमाराजियां
(ii) अन्य
लाभांि आय
दकराये की आय
जिलंब से भुगतान अजधभार
अन्य गैर-पठरचालन आय (प्रकृ जत जिजनर्िाष्ट कर सकते हैं)
कु ल

ठटप्पण : स्ट्तंभ (1) में जिलंब से भुगतान अजधभार उपकर या जिलंजबत भुगतान प्रभार का अथा है जनर्िाष्ट इकाई द्वारा लगाई
गई रकम, यदि इसके द्वारा लगाए गए जिद्युत जबल का भुगतान जबल पर जनर्िाष्ट जनयत तारीख के भीतर नहीं दकया िा रहा
है ।
6. उपभोक्ता श्रेणीिार टैठरफ सजब्सडी प्राप्य :
जििरण

31 माचा, 20.. की जस्ट्थजत के अनुसार.. (चालू और जपछला िषा के जलए)

उपभोक्ता श्रेणी

(1)

िषा के िौरान प्राप्त टैठरफ
सजब्सडी

ओपननंग
बैलस
ें

िषा के िौरान
टैठरफ
सजब्सडी का
जबल

चालू िषा के
जलए

जपछला िषों के
जलए

(2)

(3)

(4)

(5)

क्लोनिंग
बैलस
ें
(6)

घरेलू
िाजणजज्यक
कृ जष
उद्योग-प्रधान
अन्य (श्रेणी जिजनर्िाष्ट कर सकते हैं)
कु ल
ठटप्पण : स्ट्तंभ (3) में सजब्सडी जबल का लेखा-िोखा मानक प्रचालन प्रदक्रया अथिा जिद्युत मंत्रालय द्वारा समय-समय पर
िारी दििा-जनिेिों के अनुसार दकया िाएगा ।
7. सकल व्यापार प्राप्य :
31 माचा, 20.. की जस्ट्थजत के अनुसार ।
(चालू िषा)

जििरण

(1)
अपने उपभोक्ताओं (एलटी, एचटी और
ईएचटी) को जिद्युत की जबक्री के जलए

31 माचा, 20.. की जस्ट्थजत के
अनुसार ।
(जपछला िषा)

चालू

गैर-चालू

कु ल

चालू

गैर-चालू

कु ल

(2)

(3)

(4)

(5)

(6)

(7)

<!-- page 9 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

9

जितरण फ्रेंचाइिी के जलए जबक्री के जलए
िूसरों को जिद्युत की जबक्री के जलए (िैसे
अंतर-राज्यीय जबक्री/ऊिाा
व्यापार/यूआई/डीएसएम/अंतर जडस्ट्कॉम
जबक्री आदि)
जिद्युत िुल्क/अन्य कर
जिलंब से भुगतान अजधभार
अन्य
कु ल
8. सकल व्यापार प्राजप्तयां- ऊिाा की जबक्री के जलए उपभोक्ता श्रेणी के अनुसार :

जििरण

(1)
घरेलू
िाजणजज्यक
कृ जष
उद्योग-प्रधान
अन्य :
लोक सडक प्रकाि व्यिस्ट्था
लोक िल संकमा
रे ल
थोक आपूर्ता
जितरण फ्रेंचाइिी
अंतरराज्य/व्यापार/यूआई/डीएसएम
प्रकीणा
(i) कु ल
(i) में से, सरकारी उपभोक्ताओं
से संबजं धत है
राज्य सरकार के जिभाग
कें द्रीय सरकार के जिभाग
सरकारी उपभोक्ताओं से
संबजं धत कु ल व्यापार प्राजप्तयां

31 माचा, 20.. की जस्ट्थजत के अनुसार..

31 माचा, 20.. की जस्ट्थजत के अनुसार..

(चालू िषा)

(जपछला िषा)

ओपननंग
बैलस
ें

रािस्ट्ि
जबल

प्राप्त
रािस्ट्ि

क्लोनिंग
बैलस
ें

ओपननंग
बैलस
ें

रािस्ट्ि
जबल

प्राप्त
रािस्ट्ि

क्लोनिंग
बैलस
ें

(2)

(3)

(4)

(5)

(6)

(7)

(8)

(9)

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

<!-- page 11 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

11

10. आयु-िार संिेय व्यापार
जिजिष्टयाँ

1 िषा से कम

3 िषा से अजधक

कु ल

(3)

(4)

1 - 2 िषा
2 - 3 िषा
(1)

(2)

जबिली खरीि
राज्य की अपना उत्पािन
स्ट्ितंत्र जिद्युत उत्पािक (आईपीपी) - राज्य के
भीतर
स्ट्ितंत्र जिद्युत उत्पािक (आईपीपी) अंतरराज्यीय उत्पािन स्ट्टेिन
कें द्रीय सािािजनक िेत्र उद्यम (सीपीएसई) राज्य के भीतर
सीपीएसई अंतर-राज्यीय उत्पािन स्ट्टेिन
जद्वपिीय
आिान- प्रिान
संचारण िुल्क
राज्य की अपनी संचारण कं पनी
राज्य स्ट्ितंत्र पारे षण पठरयोिनाएं
अंतर-राज्यीय स्ट्ितंत्र संचारण पठरयोिनाएं
सीपीएसई संचारण कं पनी
अन्य
कु ल
11. संिेय व्यापार का ब्यौरा
31माचा, 20 तक ..

31माचा, 20 तक ..

(चालू िषा)

(जपछले िषा)

जिजिष्टयाँ
प्रारं
जभक
िमा

(1)

जबिली खरीि
राज्य की अपना उत्पािन
स्ट्ितंत्र जिद्युत उत्पािक (आईपीपी) - राज्य के भीतर
स्ट्ितंत्र जिद्युत उत्पािक (आईपीपी) अंतर-राज्यीय उत्पािन स्ट्टेिन

(2)

िषा
के
िौरा
न
पठरि
धान

िषा
के
िौ
रान

(3)

(4)

ि
मा
िे
ष

प्रारं
जभक
िमा

िषा
के
िौरा
न
पठरि
धान

िषा
के
िौ
रान
संिे
य

ि
मा
िे
ष

(5
)

(6)

(7)

(8)

(9
)

संिे
य

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

कें द्रीय सािािजनक िेत्र उद्यम (सीपीएसई) - राज्य के भीतर
सीपीएसई अंतर-राज्यीय उत्पािन स्ट्टेिन
जद्वपिीय
आिान- प्रिान

संचारण िुल्क
राज्य की अपनी संचारण कं पनी
राज्य स्ट्ितंत्र पारे षण पठरयोिनाएं
अंतर-राज्यीय स्ट्ितंत्र संचारण पठरयोिनाएं
सीपीएसई संचारण कं पनी
अन्य
कु ल
अजतठरक्त प्रकटीकरण जििरण 2 : जिद्युत क्रय ब्यौरे
एसई का स्ट्ियं उत्पािन (यदि लागू हो) :
तापीय

निीकरणीय
ऊिाा

िल

नाजभकीय

अन्य

कु ल

सकल उत्पािन

एमयू

क

सहायक उपभोग

एमयू

ख

िुद्ध उत्पािन

एमयू

ग=क-ख

कु ल उत्पािन लागत

करोड रु.

घ
िीघाकाजलक जिद्युत क्रय :
तापीय

िल

निीकरणीय
ऊिाा
नाजभकीय

अन्य

कु ल

मात्रा

एमयू

ङ

जनयत प्रभार

करोड रु.

च1

ऊिाा प्रभार

करोड रु.

च2

कु ल जिद्युत क्रय लागत

करोड रु.

च=च1+च2

िेर से संिाय अजधभार (एलपीएस)

करोड रु.

छ

एलपीएस सजहत िीघाकाजलक
जिद्युत क्रय लागत

करोड रु.
ि= च+छ
मध्यकाजलक जिद्युत क्रय :
तापीय

मात्रा

िल

निीकरणीय
ऊिाा

नाजभकीय

अन्य

कु ल

एमयू

झ

जनयत प्रभार

करोड रु.

ञ1

ऊिाा प्रभार

करोड रु.

ञ2

<!-- page 13 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

13

करोड रु.

ञ=
ञ1+ञ2

िेर से संिाय अजधभार (एलपीएस)

करोड रु.

ट

एलपीएस सजहत मध्यकाजलक
जिद्युत क्रय लागत

करोड रु.

कु ल जिद्युत क्रय लागत

ि=ञ+ट
अल्पकाजलक जिद्युत क्रय :
तापीय

िल

निीकरणीय
ऊिाा

नाजभकीय

अन्य

कु ल

मात्रा-जद्वपिीय

एमयू

ड

जिद्युत क्रय लागत-जद्वपिीय
मात्रा-जिजनमय
जिद्युत क्रय लागत-जिजनमय
कु ल जिद्युत क्रय लागत

करोड रु.
एमयू
करोड रु.
करोड रु.

ढ
ण
त
थ=ढ+त

सकल जनिेि ऊिाा
एसई की पठरजध के बाहर बेची गई ऊिाा
अंतरााजज्यक पारेषण हाजनयां
अंतरराजज्यक पारे षण हाजनयां
एसई की पठरजध पर उपलब्ध ऊिाा
एसई की पठरजध के भीतर जिक्रीत ऊिाा
जितरण हाजन
जबनलंग ििता
कु ल जिद्युत क्रय लागत
कें द्रीय पारे षण उपयोजगता (एसटीयू) और प्रािेजिक भार पारे षण कें द्र
(आरएलडीसी) प्रभार
राज्य पारे षण उपयोजगता (एसटीयू) और राज्य भार पारे षण कें द्र
(एसएलडीसी) प्रभार
जिद्युत क्रय और पारेषण की कु ल लागत

एमयू
एमयू
एमयू
एमयू
एमयू
एमयू
एमयू
%
करोड रु.
करोड रु.

ि=ग+ङ+झ+ड+ण
ध
न
प
फ= ि-ध-न-प
ब
भ=फ–ब
ख.ङ= ब/फ*100
म= घ+ि+ि+थ

करोड रु.

यक
यख= म+य+यक

एसई के जलए औसत क्रय जिद्युत लागत
एसई के जलए औसत क्रय जिद्युत लागत (पारेषण हाजन के पश्चात्)

रु./दक िा.घं
रु./दक िा.घं

यग= यख*10/ि
यघ= यख*10/फ

य
करोड रु.

अजतठरक्त प्रकटीकरण जििरण 3 : आपूर्ता की औसत लागत का जििरण (एसीएस) औसत रािस्ट्ि िसूल करना (एआरआर)
अंतर :

क्र. सं.

मानिंड

इकाई

जििरण

31 माचा,
20.... को
समाप्त िषा के
जलए (ितामान
िषा)

(1)

(2)

(3)

(4)

(5)

(i)

सकल जनिेि ऊिाा

(ii)

कु ल व्यय

एमयू
करोड रु.

एसई का स्ट्िंय उत्पािन – सहायक
उपभोग + क्रय की गई ऊिाा (सकल)
लाभ और हाजन के जििरण के
अनुसार कु ल व्यय (असाधारण व्यय

31 माचा,
20.... को
समाप्त िषा के
जलए (पूिि
ा ती
िषा)
(6)

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

और उपबंधों सजहत)
करोड रु.

लाभ और हाजन के जििरण के
अनुसार कु ल रािस्ट्ि

(iii)

कु ल रािस्ट्ि

(iv)

आपूर्ता की औसत
लागत (एसीएस)

रु./दक
िा.घं

(ii)*10/क

(v)

औसत िसूली रािस्ट्ि
(एआरआर)

रु./दक
िा.घं

(iii)*10/क

(vi)

एसीएस – एआरआर
अंतर

रु./दक
िा.घं

(iv)-(फ)

(vii)

समायोजित कु ल
रािस्ट्ि

रु./दक
िा.घं

नीचे दिए गए ठटप्पण के अनुसार

(viii)

समायोजित औसत
िसूली आय
(एआरआर)

रु./दक
िा.घं

(vii)*10/क

(ix)

समायोजित एसीएस –
एआरआर अंतर

रु./दक
िा.घं

(iv)-(viii)

ठटप्पण : (i) स्ट्तंभ (2) से सकल जनिेि ऊिाा से क्रय की गई ऊिाा और जििेष इकाईयों का स्ट्ियं उत्पािन, यदि
कोई हो (सहायक उपभोग का िुद्ध) अजभप्रेत है;
(ii) स्ट्तंभ (2) में समायोजित कु ल रािस्ट्ि की गणना जनम्नानुसार की िाएगी:
जिजिजष्टयां

31 माचा, 20.... को समाप्त
िषा के जलए (ितामान िषा)
(2)

(1)

31 माचा, 20.... को समाप्त िषा
के जलए (पूिि
ा ती िषा)
(3)

लाभ और हाजन के जििरण के अनुसार कु ल रािस्ट्ि
उपरोक्त कु ल रािस्ट्ि में सजममजलत िस्ट्तओं
ु का
समायोिन
कम : टैठरफ सहायकी जबल और प्राप्त नहीं
कम : सकल व्यापार प्राजप्तयों में िृजद्ध
िोडे : सकल व्यापार प्राजप्तयों में कमी
कम : अन्य सरकारी सहायकी (रािस्ट्ि प्रकृ जत का
अनुिान यदि कु ल रािस्ट्ि में सजममजलत है ककं तु प्राप्त
नहीं हुआ है)
कम : पूंिीगत प्रकृ जत के सरकारी अनुिान (यदि कु ल
रािस्ट्ि में सजममजलत हैं )
समायोजित कु ल रािस्ट्ि
अजतठरक्त प्रकटन जििरण 4 : सकल तकनीकी और िाजणजज्यक हाजन का जििरण (एटी और सी):

क्र.सं.

मानिंड

यूजनट

(1)

(2)

(3)

क

सकल इनपुट ऊिाा

एमयू

िणान

(4)
एसई का स्ट्ितः उत्पािन-सहायक
उपभोग + क्रय की गई ऊिाा

31 माचा,
20.. को
समाप्त होने
िाला िषा
(चालू िषा)
(5)

31 माचा,
20.. को
समाप्त होने
िाला िषा
(पूिा िषा)
(6)

<!-- page 15 -->

[भाग II—खण्ड 3(i)]

क्र.सं.

मानिंड

भारत का रािपत्र : असाधारण

यूजनट

िणान

15
31 माचा,
20.. को
समाप्त होने
िाला िषा
(चालू िषा)

31 माचा,
20.. को
समाप्त होने
िाला िषा
(पूिा िषा)

(5)

(6)

(सकल)
ख1
ख2
ग

अंतरााजज्यक जिक्रय/व्यापाठरक
ऊिाा/यूआई
पारे षण हाजनयां
िुद्ध इनपुट ऊिाा

एमयू
एमयू
एमयू

ग=क-ख1-ख2
व्यापाठरक ऊिाा/अंतरााजज्यक
जिक्रय/यूआई की यूजनटों को
अपिर्िात करते हुए सभी प्रिगों के
उपभोक्ताओं को जिक्रय की गई
ऊिाा
सभी प्रिगों के उपभोक्ताओं को
ऊिाा के जिक्रय से रािस्ट्ि (जिसके
अंतगात टैठरफ सहायकी प्राजप्त भी
है) ककं तु व्यापाठरक
ऊिाा/अंतरााजज्यक जिक्रय/यूआई से
रािस्ट्ि अपिर्िात है ।

घ

जिक्रय की गई ऊिाा

एमयू

ङ

टैठरफ सहायकी प्राजप्त के
आधार पर ऊिाा के जिक्रय से
रािस्ट्ि

रुपए
करोड
में

च

आरं जभक व्यापार प्राप्य

रुपए
करोड
में

व्यापार प्राप्य अनुसूची के अनुसार
सकल आरं जभक व्यापार प्राप्य

छ

अंजतम व्यापार प्राप्य

रुपए
करोड
में

(i) व्यापार प्राप्य नोट के अनुसार
सकल अंजतम व्यापार प्राप्य
(ii) िषा के िौरान (i) से प्रत्यि
अपजलजखत कोई रकम

ि

ऊिाा के जिक्रय के जलए
समायोजित अंजतम व्यापार
प्राप्य

रुपए
करोड
में

छ(i)+छ(ii)

झ
(1)

संग्रहण ििता
(2)

%
(3)

ञ

जबनलंग ििता

%

ट
ि

िसूलीकृ त यूजनट
गैर िसूलीकृ त यूजनट
सकल तकनीकी और
िाजणजज्यक हाजनयां

एमयू
एमयू

(ङ+च-छ)*100/ङ
(4)
अजतठरक्त प्रकटन जििरण 2 से
जलया गया मूल्य
घ*झ
ग-ट

%

ि*100/ग

ड

ठटप्पण: (i) स्ट्तंभ (2) में संग्रहण ििता की उच्चतम सीमा 100% होगी ।
(ii) सकल तकनीकी और िाजणजज्यक हाजन, रािस्ट्ि और व्यापार प्राप्यों की संगणना के जलए के िल
जनम्नजलजखत िाजमल होंगे:
(क) एलटी, एचटी और ईएचटी उपभोक्ताओं को जिद्युत के जिक्रय, उपभोक्ताओं को िुद्ध पर बट्टा;

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(ख) उपभोक्ताओं से अन्य प्राजप्तयां (िैसे दक मीटर दकराया, दकराए की सेिा, ऊिाा की चोरी और
अनाचार के जलए िसूलीयां आदि);
(ग) एफएसी/एफसीए/एफपीपीसीए/पीपीएसी ।
(iii) सकल तकनीकी और िाजणजज्यक हाजन, रािस्ट्ि और व्यापार प्राप्यों की संगणना के जलए जनम्नजलजखत
अपिर्िात होंगे:
(क) जिद्युत िुल्क और अन्य कर;
(ख) ऊिाा का संचरण;
(ग) खुली पहुंच िाला जिक्रय;
(घ) अंतरााजज्यक जिक्रय/व्यापाठरक ऊिाा/यूआई/डीएसएम/अंतर जडस्ट्कॉम जिक्रय के माध्यम से जिद्युत का
जिक्रय;
(ड) जिलंजबत संिाय अजधभार/िेर से संिाय अजधभार ।
अजतठरक्त प्रकटन जििरण 5 : जिजनर्िाष्ट अजस्ट्तत्ि के संपािन का सार :
मि

यूजनट
(1)

संिेय

जिजिजष्टयां

(2)
दिनों की
संख्या

(3)
उत्पािनकताा कं पजनयों को
पारे षण की कं पजनयों को
अन्य को

राज्य सरकार द्वारा
ग्रहण की गई हाजन

रुपए
करोड में

िषा के िौरान पठरचालन अंतराल जनजधकरण

समाजश्रत िाजयत्िप्रत्याभूजतयां

रुपए
करोड में

बकाया कु ल रकम जिसके जलए प्रत्याभूजतयां
िारी की गई हैं ।

राज्य सरकार/ राज्य
पीएसयू जिजनर्िाष्ट
अजस्ट्तत्ि के जनजमत्त
प्रत्याभूजत िेती है ।

रुपए
करोड में

सरकारी कायाालयों की
पूिासंित्त मीटररं ग

सं.

कु ल सरकारी कायाालय

सं.

पूिासंित्त पर सरकारी
कायाालयों की प्रजतितता

%

संचयी पोषक मीटररं ग
संचयी जितरण
रांसफामार (डीटी)
मीटररं ग
लेखे

पूिा िषा के जलए ग्रहण की गई हाजन

बकाया कु ल रकम जिसके जलए प्रत्याभूजतयां ली
गई हैं ।

%

कु ल पोषकों को संचयी मीटरों के साथ पोषकों
की प्रजतितता

%

कु ल डीटी को संचयी मीटरों के साथ डीटी की
प्रजतितता

हस्ट्तािर
की

क्यू 1 के जलए तीमाही संपरीजित लेखों को
तैयार करना

चालू िषा

पूिा िषा

(4)

(5)

<!-- page 17 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

तारीख

क्यू 2 के जलए तीमाही संपरीजित लेखों को
तैयार करना
क्यू 3 के जलए तीमाही संपरीजित लेखों को
तैयार करना
क्यू 4 के जलए तीमाही संपरीजित लेखों को
तैयार करना
पूिा जित्तीय िषा के जलए संपरीजित िार्षाक लेखों
को तैयार करना
क्यू 1 के जलए तीमाही ऊिाा लेखों को तैयार
करना

ऊिाा लेखे

हस्ट्तािर
की
तारीख

क्यू 2 के जलए तीमाही ऊिाा लेखों को तैयार
करना
क्यू 3 के जलए तीमाही ऊिाा लेखों को तैयार
करना
क्यू 4 के जलए तीमाही ऊिाा लेखों को तैयार
करना
पूिा जित्तीय िषा के जलए ऊिाा िार्षाक लेखों को
तैयार करना

टैठरफ आिेिों के ब्योरे
टैठरफ याजचका फाइल
करने की तारीख

तारीख

टैठरफ आिेि िारी करने
की तारीख

तारीख

ट्रू-अप याजचका फाईल
करने की तारीख

तारीख

ट्रू-अप आिेि िारी
करने की तारीख

तारीख
सं.

कमाचारी

आरं जभत

सं.

क. स्ट्थायी

सं.

ख. संजििाकारी/ नैजमजत्तक

सं.

िषा के िौरान भती

सं.

क. स्ट्थायी

सं.

ख. संजििाकारी/ नैजमजत्तक

सं.

िषा के िौरान सेजिजनिृजत्त/ पृथक्करण

सं.

ग. स्ट्थायी

सं.

घ. संजििाकारी/ नैजमजत्तक

सं.

अंजतम

17

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

आरपीओ

सं.

ङ. स्ट्थायी

सं.

च. संजििाकारी/ नैजमजत्तक

एमयू

लक्ष्य

एमयू

उपलजब्ध

[PART II—SEC. 3(i)]

टैठरफ आिेि मूल्यांकन
िार्षाक रािस्ट्ि अपेिा

याजचका

अनुमोदित

अननुज्ञात के जलए कारण

याजचका

अनुमोदित

अननुज्ञात के जलए कारण

ट्रू-अप आिेि मूल्यांकन
िार्षाक रािस्ट्ि अपेिा

[फा.सं. 06/03/2021- यु. आर. एंड. एस. आई-II]
श्रीकांत नागुलापल्ली, अपर सजचि
MINISTRY OF POWER
NOTIFICATION
New Delhi, the 10th October, 2024
G.S.R. 635(E).—In pursuance of sub-section (1) and clause(z) of sub-section (2) of section 176 of the
Electricity Act, 2003 (36 of 2003)read with second proviso to sub-section (1) of section 129 of the Companies Act,
2013 (18 of 2013),the Central Government hereby makes the following rules, namely:1.

Short title and commencement.-(1) These rules may be called the Electricity Distribution (Accounts and
Additional Disclosure) Rules, 2024.
(2) They shall come into force on the date of their publication in the Official Gazette.

2.

Applicability.-These rules shall be applicable to Specified Entity.

3.

Definition-(1) In these rules, unless the context otherwise requires,(a) “Act” means the Electricity Act, 2003 (36 of 2003);
(b) “Additional Disclosure Statements” means the statements disclosing particulars as provided in Schedule
annexed to these rules;
(c) “Companies Act” means the Companies Act, 2013 (18 of 2013);
(d) “Financial Statement” means Financial Statements referred to in clause (40) of section 2 read with section
129 of the Companies Act;
(e) “financial year” means the financial year referred to in clause (41) of section 2 of the Companies Act;
(f) “Schedule” means the Schedule annexed to these rules;

<!-- page 19 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

19

(g) “Specified Entity” means distribution licensees excluding Government Departments, Boards and
Corporations or other agencies of the Central and State Government such as the Military Engineering
Services, Municipal Corporations, Ports, Transport Undertakings, Damodar Valley Corporation, which are
deemed licensees under section 14 of the Act.
(h) “tariff subsidy” means the subsidy provided by the State Government to any specified entity for sale of
power at subsidised rates to certain categories of consumers as defined under section 65 of the Act.
(i) “trade receivable” means an amount receivable on the account of sale of power or related services rendered
in the normal course of business.
(2) The words and expressions used herein and not defined in these rules, shall have the meanings respectively
assigned to such words and expressions in the Act or the Companies Act or the rules made there under, as
the case may be.
4.

Recognition of revenue.-For claims or sums to be recoverable through tariff, such items and sums which have
been provided in the tariff orders as recoverable shall be recognised as revenue in the Financial Statements:
Provided that any sum which has not been provided in the tariff orders shall not be recognised as revenue or
income recoverable from future tariff in the Financial Statements.
Explanation.- For the purposes of these rules, it is hereby clarified that,(i) revenue means the items or sums appearing as revenue in the Financial Statements as provided in Additional
Disclosure Statements of the Schedule.
(ii)tariff subsidy shall be recognised and accounted for as per rules made in this regard.

5.

Provisioning of trade receivables.-The minimum provisioning requirement for a Specified Entity on its trade
receivables from all category of consumers in the Financial Statements shall be as follows in the form of table
given below:
Table
Trade receivables outstanding for following periods
from due date of payment

% of Provisioning
FY 2024-25

FY 2025-26

FY 2026-27 and onwards

0 and up to 90 days

-

-

-

Exceeding 90 days and up to 180 days

5%

10%

15%

Exceeding 180 days and up to 1 year

20%

25%

30%

Exceeding 1 year and up to 2 years

35%

40%

45%

Exceeding 2 years and up to 3 years

55%

60%

75%

More than 3 years

75%

80%

100%

dues from permanently disconnected consumers

75%

75%

75%:

Provided that nothing contained in this rule shall apply to:(i) trade receivables from Government Consumers; or
(ii) Specified Entity having trade receivable days less than or equal to ninety days on aggregate basis:
Provided further that the appropriate Commission may set a higher provisioning requirement on the
recommendations of a Committee set up by the State Government which shall consist of Principal Secretary
(Power), the Principal Secretary (Finance) and the Chairman and Managing Director of the Specified Entity as
members.
Explanation.-For the purposes of this rule, the expressions,(i) Government consumers means the departments, urban local bodies, rural local bodies, public sector
undertakings and the like owned or belonging to the State Government and the Central Government; and
(ii) Trade receivable days means trade receivables at the end of the financial year divided by average revenue
per day.
6.

Content and form of Additional Disclosure Statements- (1) In addition to the statutory disclosures as mandated
under the Companies Act, the Specified Entity shall also prepare the Additional Disclosure Statements for each
financial year in the form and manner as provided in the Schedule.
Explanation.-For the purposes of this rule, it is hereby clarified that the Additional Disclosure Statements are
required to be prepared for the power related business of the Specified Entity.
(2) The Additional Disclosure Statements shall be part of the Financial Statements prepared by the Specified Entity
and are to be annexed to the Financial Statements as the last disclosure titled ‘Additional Disclosure Statements‘
under the notes to accounts of the Financial Statements:

<!-- page 20 -->

20

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Provided that in the first year of preparation of Additional Disclosure Statements, the Specified Entity shall have
the option to include Additional Disclosure Statements either in the annual report or in the Financial Statements.
(3) The Additional Disclosure Statements shall comprise the following statements, namely:(i) supplementary disclosures to Financial Statements;
(ii) power purchase and energy accounting details;
(iii) statement of Average Cost of Supply-Average Revenue Realised gap;
(iv) statement of Aggregate Technical and Commercial loss; and
(v) performance summary of Specified Entity.
Explanation.- For the removal of doubts, it is hereby clarified that for the first year of preparation of Additional
Disclosure Statements, comparative figures of previous financial year shall be optional.
7.
Statement of compliance.- A statement of compliance shall be given by the management of Specified Entity at the
beginning of the Additional Disclosure Statements confirming that the Additional Disclosure Statements are
prepared and presented in the form and manner provided in the Schedule.
Schedule: Additional Disclosure Statements (ADS)
Additional Disclosure Statement 1: Supplementary disclosures to Financial Statements
1. Revenue from operations:
Particulars
(1)
(a) Revenue from sale of energy
Sale of power to own consumers (Low Tension (LT), High Tension
(HT) and Extra High Tension (EHT))
Fuel Adjustment Charge (FAC)/ Fuel Cost Adjustment (FCA)/ Fuel
and Power Purchase Cost Adjustment (FPPCA)/ Power Purchase
Adjustment Charge (PPAC)
Sale to Distribution Franchisee
Sale of power to others (such as inter-State sale/ energy
traded/Unscheduled
Inter-change
(UI)/Deviation
Settlement
Mechanism (DSM)/inter DISCOM sale, etc.)
Other receipts from consumers (such as meter rents, service rentals,
recoveries for theft of power and malpractices, etc.)
(i) Total
Less: rebate to consumers (if any, other than cash discount) (ii)
Revenue from sale of energy without tariff subsidy (i-ii)
Add: electricity duty/ other taxes billed to consumers
Less: electricity duty/ other taxes payable to Government
Sub-total of revenue from sale of energy
(b) Other operating income
Wheeling charges
Open access charges
Others
(c) Subsidy
Subsidy payable by State Government in accordance with the
Electricity (Second Amendment) Rules, 2023 as per the number of
units supplied to subsidized categories according to energy accounts
multiplied by the per unit subsidy
Subsidy received
Total revenue from operations (a + b + c)
Note: Revenue to be recognised in accordance with rule 4 of these Rules.

For the year ended
31st March, 20..
(current year)
(2)

For the year ended
31st March, 20..
(previous year)
(3)

<!-- page 21 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

21

<!-- page 22 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

<!-- page 23 -->

[भाग II—खण्ड 3(i)]
5.

भारत का रािपत्र : असाधारण

23

Other income:

Particulars

For the year ended
31st March, 20..

For the year ended
31st March, 20..

(current year)

(previous year)

(2)

(3)

(1)
Interest Income
(i) Bank deposits
(ii) Others
Dividend income
Rental income
Late payment surcharge
Other non-operating income (may specify nature)
Total

Note:In column (1) late payment surcharge cess or delayed payment charges means the amounts levied by Specified
Entity, if the electricity bill raised by it is not being paid within the due date specified on the bill.
6.

Consumer category wise tariff subsidy receivables:
As on 31st, March 20.. (For Current and Previous Year)

Particulars

Consumer category

(1)

Tariff subsidy received
during the year

Opening
balance

Tariff
subsidy
billed during
the year

For current
year

For previous
years

(2)

(3)

(4)

(5)

Closing
balance

(6)

Domestic
Commercial
Agricultural
Industrial
Others (may specify category)
Total
Note: In column (3) accounting for subsidy billed shall be as per standard operating procedure or guidelines issued by
Ministry of Power in this regard from time to time.
8.

Gross trade receivables:
As at 31st March, 20..

As at 31st March, 20..

(current year)

(previous year)

Particulars

(1)
For sale of power to own consumers
(LT, HT and EHT)
For sale to distribution franchisee
For sale of power to others (such as

Current

Noncurrent

Total

Current

Noncurrent

Total

(2)

(3)

(4)

(5)

(6)

(7)

<!-- page 24 -->

24

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

inter-State sale/energy
traded/UI/DSM/inter DISCOM sale,
etc.)
Electricity duty/ other taxes
Late payment surcharge
Others
Total
8.

Gross trade receivables– consumer category wise for sale of energy:

Particulars

(1)
Domestic
Commercial
Agricultural
Industrial
Others:
Public street
lighting
Public water works
Railways
Bulk supply
Distribution
franchisee
Inter-State/
trading/UI/DSM
Miscellaneous
(i) Total
Out of (i) above,
related to
Government
consumers
State Government
departments
Central
Government
departments
Total trade
receivables related
Government
consumers

As on 31st, March 20..

As on 31st, March 20..

(current year)

(previous year)

Opening
balance

Revenue
billed

Revenue
received

Closing
balance

Opening
balance

Revenue
billed

Revenue
received

Closing
balance

(2)

(3)

(4)

(5)

(6)

(7)

(8)

(9)

<!-- page 25 -->

(1)

Particulars

Details of borrowings:

Total borrowing: un-secured

Total borrowing: secured

(n…)

(ii)

(n…)
Bonds (specify name of bonds along
with purpose of loan)
(i)

(ii)

(n…)
Short term loans banks/NBFC/others(Specify name
along with purpose of loan)
(i)

(ii)

Opening
balance
(7)

Closing
balance
(6)=(2)+(3)(5)

Repayments

(5)

Due for
payment
(4)

Additions

(3)

Opening
balance
(2)

As at 31st March, 20..
(current year)

(8)

Additions

(9)

Due for
payment
(10)

Repayments

As at 31st March, 20..
(previous year)

(11)=
(7)+(8)(10)

Closing
balance

भारत का रािपत्र : असाधारण

Note:In column (2), (6), (7) and (11) opening balance and closing balance of borrowings in above table reflects total borrowings including current maturities of long-term borrowings.

Total borrowing (secured + un-secured)

(d)

(c)

(b)

(n…)
Long term loans –Government(specify
name along with purpose of loan)
(i)

(ii)

Borrowings(bifurcate between secured and
un-secured)
Long term loans – banks/NBFC/
(a) others (specify name along with purpose
of loan)
(i)

9.

[भाग II—खण्ड 3(i)]

25

<!-- page 26 -->

26

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

10. Trade payables age-wise:
Particulars
(1)

Less than 1Year
1 - 2 Years
2 - 3 Years

More than 3 Years

Total

(2)

(3)

(4)

Power purchase
State's own generation
Independent Power Producers (IPP)- within
the State
Independent Power Producers (IPP) inter-State
generating station
Central Public Sector Enterprises (CPSE)within the State
CPSE inter-State generating station
Bilateral
Exchange
Transmission charges
State's own transmission company
State independent transmission projects
Inter-State independent transmission projects
CPSE transmission company
Others
Total
11. Details of trade payables:
As at 31stMarch, 20..
(current year)
Opening
balance

Addition
during
the year

Paid
during
the
year

Closing
balance

Opening
balance

Addition
during
the year

Paid
during
the
year

Closing
balance

(2)

(3)

(4)

(5)

(6)

(7)

(8)

(9)

Particulars

(1)
Power purchase
State's own generation
State IPP
IPP ISGS
CPSE State
CPSE ISGS
Bilateral
Exchange
Transmission charges
State's own transmission
company
State independent
transmission projects
Inter-State independent
transmission projects
CPSE transmission
company

As at 31stMarch, 20..
(previous year)

<!-- page 27 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

27

Others
Total
Additional Disclosure Statement 2: Power purchase details:
Own generation of SE (if applicable):
Thermal

Hydro

Renewable
energy

Nuclear

Others

Total

Gross generation

MU

A

Auxiliary consumption

MU

B

Net generation

MU

C =–A B

Total generation cost

Rs. Cr

D

Long term power purchase:
Thermal

Hydro

Renewable
energy

Nuclear

Others

Total

Quantum

MU

E

Fixed charges

Rs. Cr

F1

Energy charges

Rs. Cr

F2

Total power purchase cost

Rs. Cr

F=
F1+F2

Late Payment Surcharge (LPS)

Rs. Cr

G

Long term power purchase cost
including LPS

Rs. Cr

H= F+G

Medium term power purchase:
Thermal

Hydro

Renewable
energy

Nuclear

Others

Total

Quantum

MU

I

Fixed Charges

Rs. Cr

J1

Energy Charges

Rs. Cr

J2

Total power purchase cost

Rs. Cr

J = J1+J2

Late Payment Surcharge (LPS)

Rs. Cr

K

Medium term power purchase cost
including LPS

Rs. Cr

L = J+K

Short term power purchase:
Thermal

Hydro

Renewable
energy

Nuclear

Others

Total

Quantum - bilateral

MU

M

Power purchase cost – bilateral

Rs. Cr

N

Quantum - exchange

MU

O

Power purchase cost – exchange

Rs. Cr

P

Total power purchase cost

Rs. Cr

Q=N+P

Gross input energy

MU

R=C+E+I+M+O

Energy sold outside SE's periphery

MU

S

Inter-State transmission losses

MU

T

Intra State transmission losses

MU

U

Energy available at SE's periphery

MU

V= R-S-T-U

<!-- page 28 -->

28

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Energy sold within SE's periphery

MU

W

Distribution loss

MU

X=V–W

Billing efficiency

%

B.E = W/V*100

Total power purchase cost

Rs. Cr

Y= D+H+L+Q

Central Transmission Utility (CTU)&Regional Load Despatch Centre
(RLDC) charges

Rs. Cr

Z

State Transmission Utility(STU)&State Load Despatch Centre (SLDC)
charges

Rs. Cr

ZA

Total cost of power purchase &transmission

Rs. Cr

ZB= Y+Z+ZA

Average power purchase cost for SE

Rs./kWh

ZC= ZB*10/R

Average power purchase cost for SE (after transmission loss)

Rs./kWh

ZD= ZB*10/V

Additional Disclosure Statement 3: Statement of Average Cost of Supply (ACS) –Average Revenue Realised
(ARR)gap:

S.No.

Parameter

Units

(1)

(2)

(3)

(i)

Gross input energy

MU

(ii)

Total expenses

Rs. crore

(iii)

Total revenue

Rs. crore

(iv)
(v)
(vi)
(vii)
(viii)
(ix)

Average Cost of
Supply (ACS)
Average Realizable
Revenue (ARR)
ACS - ARR gap
Adjusted total
revenue
Adjusted Average
Realizable Revenue
(ARR)
Adjusted ACS ARR Gap

Description

(4)
SE’s own generation - auxiliary
consumption + energy purchased
(Gross)
Total expenses as per statement of
profit and loss(including
extraordinary expenses &
provisions)
Total revenue as per statement of
profit and loss

Rs/kwh

(ii)*10/A

Rs/kwh

(iii)*10/A

Rs/kwh

(iv)-(v)

Rs. crore

As per note below

Rs/kwh

(vii)*10/A

Rs/kwh

(iv)-(viii)

For the year
ended
31st March,
20..
(current year)
(5)

For the year
ended
31st March,
20..
(previous
year)
(6)

Note:(i) In column (2) gross input energy means sum of energy purchased and special entity’s own generation, if any
(net of auxiliary consumption);
(ii) In column (2) adjusted total revenue to be calculated as below:
Particulars

(1)
Total revenue as per statement of profit and loss
Adjustments of items included in total revenue
above
Less: tariff subsidy billed and not received

For the year ended
31st March, 20..
(current year)
(2)

For the year ended
31st March, 20..
(previous year)
(3)

<!-- page 29 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

29

Less: increase in gross trade receivables
Add: decrease in gross trade receivables
Less: other Government subsidy/ grant of revenue
nature (if included in total revenue but not
received)
Less: Government grants of capital nature (if
included in total revenue)
Adjusted total revenue
Additional Disclosure Statement 4: Statement of (Aggregate Technical & Commercial (AT and C) loss:

S.No.

Parameter

(1)
A

(2)
Gross input energy

Unit

Description

(3)

(4)
SE’s own generation - auxiliary
consumption + energy purchased
(gross)

MU

B2
C

Inter-State sale/ energy
traded/UI
Transmission losses
Net input energy

D

Energy sold

MU

E

Revenue from sale of energy
on tariff subsidy received basis

Rs.
crore

F

Opening trade receivable

Rs.
crore

G

Closing trade receivables

Rs.
crore

I
(1)

Adjusted closing trade
receivable for sale of energy
Collection efficiency
(2)

Rs.
crore
%
(3)

J

Billing efficiency

%

K
L
M

Units realized
Units un-realized
AT&C losses

MU
MU
%

B1

H

For the
year ended
31st March,
20..
(current
year)
(5)

For the
year ended
31st
March, 20..
(previous
year)
(6)

(5)

(6)

MU
MU
MU

C= A-B1-B2
Energy sold to all categories of
consumers excluding units of
energy traded/ inter-State
sales/UI
Revenue from sale of energy to
all categories of consumers
(including tariff subsidy
received) but excluding revenue
from energy traded/ inter-State
sales/UI
Gross opening trade receivable
as per trade receivable schedule.
(i) Gross closing trade
receivables as per trade
receivable note
(ii) Any amount written off
during the year directly from (i)
G(i)+G(ii)
(E+F-H)*100/E
(4)
Value to be taken from
Additional Disclosure Statement
2
D*I
C-K
L*100/C

Note:(i) In column (2) collection efficiency to be capped at 100%.
(ii)For calculation of AT&C loss, revenue and trade receivables shall include only:
(a)Sale of power to LT, HT and EHT consumers net of rebate to consumers;

<!-- page 30 -->

30

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(b)Other receipts from consumers (such as meter rents, service rentals, recoveries for theft of
power and malpractices, etc.);
(c)FAC/FCA/ FPPCA/PPAC.
(iii)For calculation of AT&C loss, revenue and trade receivables shall exclude:
(a) Electricity duty/other taxes;
(b) Wheeling of energy;
(c) Open access sale;
(d) Sale of power through inter-State sale/ energy traded/UI/DSM/ inter DISCOM sale;
(e) Delayed payment surcharge/ late payment surcharge.
Additional Disclosure Statement 5: Performance summary of Specified Entity:
Item
(1)

Unit
(2)

Payables

No. of
Days

Loss taken over by
State Government

Rs.
Crore

Contingent liabilities guarantees
State Govt./ State PSUs
guarantees on behalf of
specified entity
Prepaid metering of
Government offices
Total Govt. offices
% of Govt. offices on
prepaid
Communicable feeder
metering
Communicable
Distribution
Transformer (DT)
Metering

Rs.
Crore
Rs.
Crore

Particulars
(3)
To generating companies
To transmission companies
To others
Operational gap funding during the year
Loss taken over for previous year
Outstanding total amount against which guarantees
have been issued
Outstanding total amount against which guarantees
have been taken

Nos.
Nos.
%
%

%

Accounts

Date of
signing

Energy accounts

Date of
signing

Details of tariff orders
Date of filing of tariff
petition
Date of issuance of
tariff order

Date
Date

% of feeders with communicable meters to total
feeders

% of DTs with communicable meters to total DTs
Preparation of quarterly audited accounts for Q1
Preparation of quarterly audited accounts for Q2
Preparation of quarterly audited accounts for Q3
Preparation of quarterly audited accounts for Q4
Preparation of audited annual accounts for last
financial year
Preparation of quarterly energy accounts for Q1
Preparation of quarterly energy accounts for Q2
Preparation of quarterly energy accounts for Q3
Preparation of quarterly energy accounts for Q4
Preparation of annual energy accounts for last
financial year

Current
Year
(4)

Previous
Year
(5)

<!-- page 31 -->

[भाग II—खण्ड 3(i)]
Date of filing of true-up
Petition
Date of issuance of
true-up order

Employees

RPO

भारत का रािपत्र : असाधारण

31

Date
Date
No.
No.
No.
No.
No.
No.
No.
No.
No.
No.
No.
No.
MU
MU

Opening
a. Permanent
b. Contractual/ casual
Recruitment during the year
a. Permanent
b. Contractual/ casual
Retirement/ separation during the year
a. Permanent
b. Contractual/ casual
Closing
a. Permanent
b. Contractual/ casual
Target
Achievement

Tariff order analysis
Annual Revenue
Requirement (ARR)

Petition

Approved

Reason for disallowance

Petition

Approved

Reason for disallowance

True-up order analysis
Annual Revenue
Requirement (ARR)

[F. No. 06/03/2021-UR&SI-II]
SRIKANT NAGULAPALLI, Addl. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
GORAKHA NATH
YADAVA

Digitally signed by GORAKHA NATH YADAVA
Date: 2024.10.24 14:33:01 +05'30'
