---
doc_id: "f200b9e1ccb7a8ad"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/2026000993_20082026.pdf"
ministry: "Department of Space"
title: "URSC/PUBLIC TENDER NOTICE NO. E-06/26-27 Dated:19.08.2026      273.2 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a8cb84aa45b7bbfb"
---

<!-- page 1 -->

भारत सरकार, अंतररक्ष नर्भाग /Government of India, Department of Space
यू.आर. रार् उपग्रह केन्द्र (यू.आर.एस.सी.)/ U R Rao Satellite Centre [URSC]
(पूर्व में इसरो उपग्रह केन्द्र/ (Formerly known as ISRO Satellite Centre)
एच.ए.एि. एयरपोटव रोड, नर्मािपुरा पोस्ट,
HAL Airport Road, Vimanapura Post,
बेंगिूरु/Bengaluru - 560 017

यू.आर.एस.सी./सार्वजनिक निनर्दा सूचिा सं / URSC/PUBLIC TENDER NOTICE NO. E-06/26-27

19.08.2026

भारत के राष्ट्रपनत की ओर से र्. प्रधाि, क्रय एर्ं भंडार, यू.आर. रार् उपग्रह केन्द्र(यू.आर.एस.सी.),द्वारा निम्न निखित मद की
आपूनतव के निए केर्ि ई-प्रापण के जररए निनर्दाएं आमंनित हैं
On behalf of the President of India, Sr. Head, Purchase & Stores, U R Rao Satellite Centre [URSC] Invites
tenders ONLY through e-procurement for supply of the following.

दो भाग निनिदा/ Two Part Tender
क्र.सं .
Sl. No.

01

निनिदा संदभभ
TENDER REFERENCE

URSC/CE/PDMSA/2026000993

संनिप्त नििरण
BRIEF DESCRIPTION
कण संसूचक हे तु प्रस्फुरक

Scintillators for particle detectors

बोिी प्रस्तुत करिे की प्रारं नभक नतनि/Bid Submission Start Date

:20.08.2026 (17.00 Hrs.)

बोिी स्पष्ट्ीकरण की नतनि /Bid Clarification Date up to

:27.08.2026 (16.00 Hrs.)

बोिी प्रस्तुत करिे की नियत नतनि/Bid Submission Due Date

:10.09.2026 (14.00 Hrs.)

बोिी िुििे की नतनि/Bid Opening Date

:10.09.2026 (14.30Hrs.)

र्ैध नडनजटि हस्ताक्षर प्रमाणपि (डी.एस.सी) रििेर्ािे इच्छु क निनर्दाकार https://eproc.isro.gov.in

पर िॉग-इि

करके अपिा प्रस्तार् ऑििाईि भेज सकते हैं । कोई निनर्दा शुल्क िागू िही ं है ।
Interested Tenderers having valid Digital Signature Certificate [DSC]
https://eproc.isro.gov.in and submit Offers online. No Tender fees applicable.

login

may

to

निनर्दाएँ उपयुवक्त नर्निनदव ष्ट् नतनि पर िोिी जाएँ गी। पाि नर्क्रेताओं की दर बोिी (दो-भाग निनर्दाओं के मामिे में) िुििे की
समय सूची बाद में सूनचत की जाएगी। बोिी-संबंधी नर्र्रण प्रनतभागी नर्क्रेताओं द्वारा इसरो ई-प्रापण पोटव ि पर िॉग-इि करके
दे िे जा सकते हैं ।
Tenders will be opened on the date specified above. Schedule for opening of the Price Bid (in case of
Two-Part Tenders) of Qualified Vendors will be intimated later. Bidding details can be seen by the
participated vendors by logging into ISRO e-procurement portal.
उपयुवक्त के संबंध में यनद कोई शुखददपि/अिुशेष होगा, तो उसे हमारे ई-पोटव ि एर्ं र्ेबसाइट पर प्रकानशत नकया जाएगा।
Corrigendum/Addendum, if any, related to above shall be hosted in our e- portal and Website.

Sd/ि. प्रधाि, क्रय ि भंडार / Sr. Head, Purchase & Stores
