---
doc_id: "f165e1abc3e1fff3"
source_url: "https://www.labour.gov.in/static/uploads/2026/09/2b0f1dbbd3769fc388416186ec145328.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Gazette Notification- Cabinet Approves Higher EPFO Wage Ceiling of Rs. 25,000, Expanding Mandatory Coverage"
date: "2026-09-17"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "9c391b5ab0965b86"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-17092026-276299
xxxGIDHxxx
CG-DL-E-17092026-276299
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 4918]
No. 4918]

नई दिल्ली, बृिस्ट्पजतवार, जसतम्बर 17, 2026/भाद्र 26, 1948
NEW DELHI, THURSDAY, SEPTEMBER 17, 2026/BHADRA 26, 1948

श्रम और रोिगार मंत्रालय
अजधसूचना
नई दिल्ली, 17 जसतम्बर, 2026
का.आ. 5109(अ).— कें द्रीय सरकार, सामाजिक सुरक्षा संजिता, 2020 (2020 का 36) की धारा 2 के खंड (89) द्वारा प्रित्त
िजियों का प्रयोग करते हुए और श्रम और रोिगार मंत्रालय, भारत सरकार की अजधसूचना संखयांक का.आ. 2702(अ) तारीख 29 मई,
2026 को, उन बातों के जसवाय अजधक्ांत करते हुए जिन्िें ऐसे अजधक्मण से पूवव दकया गया िै या करने का लोप दकया गया िै, इस
अजधसूचना के रािपत्र में प्रकािन की तारीख से, उि संजिता के अध्याय 3 के प्रयोिनों के जलए पच्चीस ििार रुपए (25,000 रू.) प्रजत
मास को मििूरी सीमा के रूप में अजधसूजचत करती िै।

[फा. सं. आर-12025/01/2026-एसएस-II]
तेिस्ट्वी एस. नायक, संयक्
ु त सजचव

7136 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF LABOUR AND EMPLOYMENT
NOTIFICATION
New Delhi, the 17th September, 2026
S.O. 5109(E).— In exercise of the powers conferred by clause (89) of section 2 of the Code on
Social Security, 2020 (36 of 2020) and in supersession of the notification of the Government of India in the
Ministry of Labour and Employment, number S.O. 2702(E) dated 29th May 2026, except as respects things
done or omitted to be done before such supersession, the Central Government hereby notifies rupees twentyfive thousand (₹25,000) per month as the wage ceiling for the purposes of Chapter III of the said Code, with
effect from the date of publication of this notification in the Official Gazette.

[F. No. R-12025/01/2026-SS-II]
TEJASWI S. NAIK, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
BHABAJIT DEKA

Digitally signed by BHABAJIT DEKA
Date: 2026.09.17 19:48:30 +05'30'
