---
doc_id: "f4dfbb2aa22fdb7b"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/8021c31c37d136a01e24c66c253df965.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Sanction letter dated 26.11.2021 under NEIIPP (CCIS)"
date: "2025-06-24"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4ac989ae64b59041"
---

<!-- page 1 -->

P-44018/112021-DBA-ll
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry and Internal Trade
(NERS Section)

--

Udyog Bhawan, New Delhi-11 10011
Dated: 26th November, 2021
To
The Accounts Officer,
Pay & Accounts Office,
Department of Industrial Policy & Promotion,
Udyog Bhawan, New Delhi.
Subject:- Release of Rs. 42,16,38,456/- (Rupees Forty Two Crore Sixteen Lakh Thirty
Eight Thousand Four Hundred Fifty Six only) to NEDFi under the Capital
Investment Subsidy Scheme for disbursement to eligible industrial units of NER.
Sir,
I am directed to convey the Sanction of the President to the payment of a sum of
Rs. 42,16,38,456/- (Rupees Forty Two Crore Sixteen Lakh Thirty Eight Thousand Four
Hundred Fifty Six only) to North Eastern Development Finance Corporation Ltd. (NEDFI),
NEDF1 House, G.S. Road, Dispur, Guwahati, Assam, Pin - 781 006 for disbursement of
subsidy to eligible industrial units of Assam under the Central Capital Investment Subsidy
Scheme on the basis of decision of Empowered Committee in its meeting held on
22.02.2021 and as per existing terms and conditions of the Scheme, as amended from time
to time. NEDFi will furnish the requisite utilization certificate in Form 12-C of GFR, 2017 to
this Department within one year from date of receipt of sanction.
2.
NEDFi will release the subsidy to the eligible units in accordance with the provisions
of the Central Capital Investment Subsidy Scheme notified by this Department, as amended
from time to time. NEDFi will also ensure that the payment to the beneficiary unit is made
through EAT module. The list of beneficiary units is enclosed with this sanction.
NEDFi vide their letter no. NEDFI/HO/CS/03-01/Vol.20/2020-21/77 dated 08.04.2021
3.
informed that no unspent amount is lying with NEDFI under Central Capital Investment
Subsidy Scheme for the year 2019-20.
Utilization of the above mentioned amount by the NEDF1 will be subject to the
4.
following terms and conditions as per norms prescribed in GFR 2017 as well as the
Scheme notifications I guidelines:NEDFi will disburse the subsidy to the eligible industrial units listed at Annexure of
0)
this sanction letter within one month from date of receipt of sanction. In cases where NEDF1
is not able to disburse the subsidy claims within one month, the same should be reported to
DIPP with reason(s).
NEDF1 will maintain a separate account of funds released by this Department
(ii)
towards release of subsidy to eligible units recommended by the State Level Committee
under the Central Capital Investment Subsidy Scheme.

<!-- page 2 -->

P-4401811/2 0 21-DBA-11
(iii)
The expenditure incurred shall be open to inspection by the sanctioning authority /
CAG / Internal Audit Party of the Chief Controller of Account, Ministry of Commerce &
Industry, Department of Industrial Policy & Promotion, New Delhi.
(iv)
The funds released by this Department shall be utilized for the purpose for which it
has been sanctioned.
(v)
NEDFI shall not park the funds with them and shall release the due amount without
delay after completing all necessary formalities as per the Scheme guidelines and relevant
GFR norms.
(vi)
NEDFi will furnish the Utilization Certificate for the funds being released in GFR 12-C
Format to this Department by 01.04.2023.
(vii)
NEDFi will give an undertaking that they have been following the provisions of Rule
4(1)(a) & (b) of RTI Act, 2005.
(viii) A detailed expenditure statement shall be furnished by NEDFi to this Department on
monthly basis.
The amount may be released in favour of North Eastern Development Finance
5.
Corporation Ltd. (NEDFi) to their A/c No. 32683367872, State Bank of India, Guwahati
Medical College Branch, G.S. Road, Bhangagarh, MICR Code - 781002012 and IFSC
Code - SBIN0007700.
The undersigned will act as Drawing and Disbursing Officer for the purpose of this
6.
sanction.
7.

The expenditure is debitable to the following Head of Accounts:

Major Head "2885" - Other Outlays on Industries & Minerals (Major Head)
02 - Development of Backward Areas (Sub Major Head)
02.101 - Subsidies (Minor Head)
- Industrial Development of Backward and Remote Area
15
15.08 - Capital Investment Subsidy.
15.08.33- Subsidies. Under the Demand No. 11 - Department for Promotion of
Industry and internal Trade during the year 2021-22.
The necessary funds amounting to Rs. 42,16,38,456/- may be provided by way of
8.
internal re-appropriation of Rs. 42,16,39,000/- from the "Major Head-2552.00.238.09.02 NEIIPP, 09.02.33-Subsidies to 2885.02.101.15.08 - Central Capital Investment Subsidy
Scheme, 15.08.33-Subsidies".
/

H

<!-- page 3 -->

-3P-4'lOiB/l 12021 -DRAft

9.
This issues with the approval of Integrated Finance Wing, Department for Promotion
of Industry and Internal Trade vide their Diary No. 50870 dated 18.11.2021.
Yours faithfully,
-.
(P. Dasgôpta)
Director
Tel. 2306 1688

Copy to:1.
The Chairman & Managing Director, North Eastern Development Finance
Corporation Ltd., (NEDFi), NEDFi House, G.S. Road, Dispur, Guwahati, Assam-781006.
The Principal Director of Audit, Economic and Services Ministries, A.G.C.R. Building,
2.
lndraprastha Estate, New Delhi.
Finance - II Section, Integrated Finance Wing, DPIIT
3.
4.
Accounts Officer, Principal Accounts Office, DPI IT
Principal Secretary / Secretary (Industries), Govt. of Assam.
5.
Commissioner! Director (Industries), Govt. of Assam.
6.
7.
Budget & Accounts Section.
8.
Sanction Folder.
Guard File.
9.

(P. Dasgupta)
Director
Tel. 2306 1688

<!-- page 4 -->

Annexure to Sanctionletter No. P44018/1/2021-DBA-lt dated 26.11.2021

S.No.

2
3

4

Name of the
unit

{State

SLC date

Amount
approved by
Empowered
Committee

Amount
already
released to
vide
Sanction
letters dated
27.02.2021
and
28.10.2021.

Amount to be
released in
the present
sanction

Emami 17td,
Assam
Kamrup®
Hotel Meg hna,
Assam
Chirang
Jericho
Assam
Chemicals LLP,
Kamrup®
Asclepius
Assam
Hospitals and
Health Care
Pvt. Ltd.
Total

15.05.2019

28,36,93240

19,53,04326

8,83,88,914

15.05.2019

6,84,39,595

4,99,66,007
184,73,588

15.05.2019

12,51,00,000

9,13,32,329
3,37,67,671

10.10.2019

19,19,51,206

26,29,20,000
7,09,68,794
92,61,22,460

,

'.

.

24,99,84,004

42,16,38,456
