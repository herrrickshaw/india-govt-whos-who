---
doc_id: "57aefc7b21dfda5c"
source_url: "https://www.isro.gov.in/media_isro/pdf/Publications/Tenders/GCC-Amendment%20No.01.pdf"
ministry: "Department of Space"
title: "Amendment No.1     PDF - 12 KB"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "91f49ac09d7161b3"
---

<!-- page 1 -->

ISRO HQ
CEPO

Item Rate Indivisible Works Contract – General Conditions of Contract
AMENDMENT NO.01

No. CEPO/CPG/Gen-34/Contract

26.05.2015

Sub: Amendment to DOS GCC – Schedule A, Para 2
*******
Consequent to Government notification No.6/2015-Service Tax dated 01.03.2015
withdrawing the exemption of service tax for Government works, the relevant
portion of DOS GCC has been amended as below,

Reference

Existing

Schedule `A’ - Schedule Being an indivisible
of Quantities
Government
Works
contract, service tax is
General notes - Para 2
not applicable, unless
specifically mentioned.

Modified
The offered rates shall also
include service tax payable
under
the
respective
statutes. Any claim on
account of service tax will
not be admissible.
