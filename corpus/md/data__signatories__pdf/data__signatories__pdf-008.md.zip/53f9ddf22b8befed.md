---
doc_id: "53f9ddf22b8befed"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/6457fc2703ee6082366c4a958b6473a8.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Consolidated FDI Policy Circular of 2020"
date: "2025-06-30"
pages: 111
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4a45c0e95064e7b4"
---

<!-- page 1 -->

Department for Promotion of Industry and Internal Trade
Ministry of Commerce and Industry
Government of India

Consolidated FDI Policy
(Effective from October 15, 2020)

<!-- page 2 -->

1

Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry and Internal Trade
(FDI Division)

Consolidated FDI Policy Circular of 2020
Subject: Consolidated FDI Policy
The “Consolidated FDI Policy” is attached.
2. This Circular will take effect from October 15, 2020

(Shailendra Singh)
Additional Secretary to the Government of India
DPIIT File Number 5(2)/2020-FDI Policy Dated the October 15, 2020

Copy forwarded to:
1.
2.
3.
4.
5.

Press Information Officer, Press Information Bureau- for giving wide publicity
to the above circular.
NIC, DPIIT for uploading the Circular on DPIIT's website.
Department of Economic Affairs, Ministry of Finance, New Delhi.
Reserve Bank of India, Mumbai.
Hindi Section for Hindi Translation.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 3 -->

2

CONTENTS
Chapter 1: Intent and Objective ............................................................................................................ 5
1.1 Intent and Objective.......................................................................................................................... 5
Chapter 2: Definitions…………………………………………………………………………………..7
2.1 Definitions………………………………………………………………………………………………...7
Chapter 3: General Conditions on FDI……………………………………………………….……...14
3.1 Eligible investors ............................................................................................................................... 14
3.2 Eligible investee entities................................................................................................................... 15
3.3 Instruments of investments, issue/transfer of shares etc............................................................ 18
3.4 Entry Routes for Investment............................................................................................................ 18
3.5 Caps on Investments......................................................................................................................... 20
3.6 Entry Conditions on Investment..................................................................................................... 20
3.7 Other Conditions on Investment besides Entry Conditions....................................................... 20
3.8 Foreign Investment into/downstream Investment by eligible Indian entities ........................ 20
3.9 Remittance, Reporting and Violation………………………………………………..……………23
Chapter 4: Procedure for Government Approval…………………………………………………..24
4.1 Competent Authority ....................................................................................................................... 24
4.2 Cases which do not require Fresh Approval................................................................................. 26
4.3 Online Filing of Applications for Government Approval........................................................... 27
Chapter 5: Sector Specific Conditions on FDI …………………………………………………….28
5.1 Prohibited Sectors ............................................................................................................................. 28
5.2 Permitted Sectors .............................................................................................................................. 28
Agriculture ………………………………………………………………………………………….…..30
5.2.1 Agriculture & Animal Husbandry .............................................................................................. 30
5.2.2 Plantation Sector............................................................................................................................. 31
Mining and Petroleum & Natural Gas............................................................................................... 31
5.2.3 Mining.............................................................................................................................................. 31
5.2.4 Petroleum & Natural Gas.............................................................................................................. 33
Manufacturing ........................................................................................................................................ 34
5.2.5 Manufacturing:............................................................................................................................... 34
5.2.6 Defence ............................................................................................................................................ 34
Services Sector ........................................................................................................................................ 36

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 4 -->

3

5.2.7 Broadcasting ................................................................................................................................... 36
5.2.8 Print Media ..................................................................................................................................... 37
5.2.9 Civil Aviation ................................................................................................................................. 39
5.2.10 Construction Development: Townships, Housing, Built-up Infrastructure........................ 42
5.2.11Industrial Parks ............................................................................................................................. 45
5.2.12 Satellites- establishment and operation .................................................................................... 45
5.2.13 Private Security Agencies ........................................................................................................... 45
5.2.14 Telecom Services .......................................................................................................................... 46
5.2.15 Trading .......................................................................................................................................... 47
5.2.16 Railway Infrastructure................................................................................................................. 56
Financial Services................................................................................................................................... 57
5.2.17 Asset Reconstruction Companies .............................................................................................. 57
5.2.18 Banking- Private Sector ............................................................................................................... 58
5.2.19 Banking- Public Sector................................................................................................................. 58
5.2.20 Credit Information Companies (CIC) ....................................................................................... 59
5.2.21 Infrastructure Company in the Securities Market................................................................... 59
5.2.22 Insurance ....................................................................................................................................... 61
5.2.23 Pension Sector............................................................................................................................... 63
5.2.24 Power Exchanges ......................................................................................................................... 64
5.2.25 White Label ATM Operations .................................................................................................... 64
5.2.26 Other Financial Services.............................................................................................................. 65
Others ....................................................................................................................................................... 65
5.2.27 Pharmaceuticals............................................................................................................................ 65
Annexures……………………………………………………………………………………………….68
Annexure-1 Types of Instruments ........................................................................................................ 68
Annexure-2 Provisions Relating to Issue/Transfer of Shares…………………………………………..71
Annexure-3 Specific Conditions in Certain Cases.............................................................................. 84
Annexure-4 Total Foreign Investment i.e. Direct and Indirect Foreign Investment in eligible Indian
entities....................................................................................................................................................... 88
Annexure-5 Remittance, Reporting and Violation………………………………………………..…93
Annexure-6 Conditions for Broadcasting Sector ............................................................................ …97
Annexure-7 Conditions for Industrial Parks..................................................................................... 101

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 5 -->

4

Annexure-8 Permissible limits under portfolio investment schemes through stock exchanges for
/FPIs and NRIs...................................................................................................................................... 103
Annexure – 9 Certificate to be furnished by the Prospective Investor as well as the Prospective
Recipient Entity ..................................................................................................................................... 106
Abbreviations…………………………………………………………………………………………….107

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 6 -->

5

CHAPTER 1: INTENT AND OBJECTIVE
1.1

Intent and Objective

1.1.1 Foreign Direct Investment (FDI) is considered as a major source of non-debt financial
resource for the economic development. FDI flows into India have grown consistently
since liberalization and are an important component of foreign capital since FDI infuses
long term sustainable capital in the economy and contributes towards technology
transfer, development of strategic sectors, greater innovation, competition and
employment creation amongst other benefits. Therefore, it is the intent and objective of
the Government of India to attract and promote FDI in order to supplement domestic
capital, technology and skills for accelerated economic growth and development. FDI, as
distinguished from Foreign Portfolio Investment, has the connotation of establishing a
‘lasting interest’ in an enterprise that is resident in an economy other than that of the
investor.
1.1.2 The Government has put in place a policy framework on FDI, which is transparent,
predictable and easily comprehensible. This framework is embodied in the Circular on
Consolidated FDI Policy, which may be updated on an annual basis, to capture and keep
pace with the regulatory changes, effected in the interregnum. The Department for
Promotion of Industry and Internal Trade (DPIIT), Ministry of Commerce & Industry,
Government of India makes policy pronouncements on FDI through Consolidated FDI
Policy Circular/Press Notes/Press Releases which are notified by the Department of
Economic Affairs (DEA), Ministry of Finance, Government of India as amendments to
the Foreign Exchange Management (Non-Debt Instruments) Rules, 2019 under the
Foreign Exchange Management Act, 1999 (42 of 1999) (FEMA). These notifications take
effect from the date of issue of Press Notes/ Press Releases, unless specified otherwise
therein. In case of any conflict, the relevant Notification under Foreign Exchange
Management (Non-Debt Instruments) Rules, 2019 will prevail. The payment of inward
remittance and reporting requirements are stipulated under the Foreign Exchange
Management (Mode of Payment and Reporting of Non-Debt Instruments) Regulations,
2019 issued by the Reserve Bank of India (RBI). The regulatory framework, over a period
of time, thus, consists of FEMA and Rules/Regulations thereunder, Consolidated FDI
Policy Circular, Press Notes, Press Releases, Clarifications, etc.
1.1.3 The present consolidation subsumes and supersedes all Press Notes/Press
Releases/Clarifications/Circulars issued by the DPIIT, which were in force as on
October 15, 2020 and reflects the FDI Policy as on October 15, 2020. This Circular
accordingly will take effect from October 15, 2020 and will remain in force until

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 7 -->

6

superseded in totality or in part thereof. Reference to any statute or legislation made in
this Circular shall include modifications, amendments or re-enactments thereof.
1.1.4 Notwithstanding
the
rescission
of
earlier
Press
Notes/Press
Releases/Clarifications/Circulars, anything done or any action taken or purported to
have been done or taken under the rescinded Press Notes/Press
Releases/Clarifications/Circulars prior to October 15, 2020, shall, in so far as it is not
inconsistent with those Press Notes/Press Releases/Clarifications/Circulars, and
applicable provisions under the FEMA and Rules/Regulations thereunder, be deemed to
have been done or taken under the corresponding provisions of this circular and shall be
valid and effective.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 8 -->

7

CHAPTER 2: DEFINITIONS
2.1

DEFINITIONS

2.1.1

‘AD Category-I Bank’ means a bank (Scheduled Commercial, State or Urban
Cooperative) which is authorized under Section 10(1) of FEMA to undertake all
current and capital account transactions according to the directions issued by the
RBI from time to time.

2.1.2

‘Authorized Bank’ shall have the meaning assigned to it under the Foreign
Exchange Management (Deposit) Regulations, 2016.

2.1.3

‘Authorized Dealer’ means a person authorized as an authorized dealer under subsection (1) of section 10 of FEMA.

2.1.4

‘Automatic route’ means the entry route through which investment by a person
resident outside India does not require the prior approval of the Reserve Bank of
India or the Central Government.

2.1.5

‘Capital’ means equity shares; fully, compulsorily & mandatorily convertible
preference shares; fully, compulsorily & mandatorily convertible debentures and
warrants.
Note: The equity shares issued in accordance with the provisions of the Companies
Act, as applicable, shall include equity shares that have been partly paid. Preference
shares and convertible debentures shall be required to be fully paid, and should be
mandatorily and fully convertible. Further, ‘warrant’ includes Share Warrant issued
by an Indian Company in accordance with the regulations by the Securities and
Exchange Board of India (SEBI) and the provisions of the Companies Act, 2013.

2.1.6

‘Capital account transaction’ means a transaction which alters the assets or
liabilities, including contingent liabilities, outside India of persons resident in India
or assets or liabilities in India of persons resident outside India, and includes
transactions as per Section 6 of FEMA.

2.1.7

‘Competent Authority’ means the concerned Administrative Ministry/Department
empowered to grant government approval for foreign investment under the extant
FDI Policy and FEMA Rules/Regulations.

2.1.8

‘Control’ shall include the right to appoint a majority of the directors or to control
the management or policy decisions, exercisable by a person or persons acting

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 9 -->

8

individually or in concert, directly or indirectly, including by virtue of their
shareholding or management rights or shareholders agreements or voting
agreements. For the purposes of Limited Liability Partnership, ‘control’ will mean
right to appoint majority of the designated partners, where such designated
partners, with specific exclusion to others, have control over all the policies of the
LLP.
2.1.9

‘Convertible Note’ means an instrument issued by a startup company
acknowledging receipt of money initially as debt, which is repayable at the option
of the holder, or which is convertible into such number of equity shares of such
startup company, within a period not exceeding five years from the date of issue of
the convertible note, upon occurrence of specified events as per the other terms and
conditions agreed to and indicated in the instrument.

2.1.10

‘Depository Receipt’ (DR) means a foreign currency denominated instrument,
whether listed on an international exchange or not, issued by a foreign depository
in a permissible jurisdiction on the back of eligible securities issued or transferred to
that foreign depository and deposited with a domestic custodian and includes
‘global depository receipt’ as defined in the Companies Act, 2013.

2.1.11

‘Domestic Custodian’ means a custodian of securities registered with the SEBI in
accordance with the SEBI (Custodian of Securities) Regulations, 1996.

2.1.12

‘Domestic Depository’ means a custodian of securities registered with the SEBI and
authorised by the issuing entity to issue Indian depository receipts.

2.1.13

‘ESOP’ means ‘Employees’ stock option’ as defined under the Companies Act, 2013
and issued in accordance with the Companies Act, 2013 and SEBI regulations, as
applicable.

2.1.14

‘Erstwhile Overseas Corporate Body’(OCB) means a company, partnership firm,
society and other corporate body owned directly or indirectly to the extent of at
least sixty percent by non-resident Indians and includes overseas trust in which not
less than sixty percent beneficial interest is held by non-resident Indians directly or
indirectly but irrevocably and which was in existence on the date of commencement
of the Foreign Exchange Management (Withdrawal of General Permission to
Overseas Corporate Bodies (OCBs) Regulations, 2003 and immediately prior to such
commencement was eligible to undertake transactions pursuant to the general
permission granted under the regulations under FEMA.

2.1.15

‘Foreign Currency Convertible Bond’ (FCCB) means a bond issued under the Issue
of Foreign Currency Convertible Bonds and Ordinary Shares (Through Depository

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 10 -->

9

Receipt Mechanism) Scheme, 1993, as amended from time to time.
2.1.16

‘FDI’ or ‘Foreign Direct Investment’ means investment through capital instruments
by a person resident outside India in an unlisted Indian company; or in ten per cent
or more of the post issue paid-up equity capital on a fully diluted basis of a listed
Indian company;
Note:- In case an existing investment by a person resident outside India in capital
instruments of a listed Indian company falls to a level below ten percent, of the post
issue paid-up equity capital on a fully diluted basis, the investment shall continue
to be treated as FDI;
Explanation: - Fully diluted basis means the total number of shares that would be
outstanding if all possible sources of conversion are exercised

2.1.17

‘Foreign Investment’ means any investment made by a person resident outside
India on a repatriable basis in capital instruments of an Indian company or to the
capital of a LLP;
Explanation: - If a declaration is made by a person as per the provisions of the
Companies Act, 2013 about a beneficial interest being held by a person resident
outside India, then even though the investment may be made by a resident Indian
citizen, the same shall be counted as foreign investment;
Note:- A person resident outside India may hold foreign investment either as FDI or
as FPI in any particular Indian company;

2.1.18

‘FDI linked performance conditions’ means the sector specific conditions for
companies receiving foreign investment.

2.1.19

‘FEMA’ means the Foreign Exchange Management Act, 1999 (42 of 1999).

2.1.20

‘Foreign Portfolio Investment’ means any investment made by a person resident
outside India through capital instruments where such investment is less than ten
percent of the post issue paid-up share capital on a fully diluted basis of a listed
Indian company or less than ten percent of the paid-up value of each series of
capital instrument of a listed Indian company.

2.1.21

‘Foreign Portfolio Investor’ (FPI)1 means a person registered in accordance with the
provisions of Securities and Exchange Board of India (Foreign Portfolio Investors)
Regulations, 2019, as amended from time to time.

1

For details please refer to SEBI (FPI) Regulations, 2019, as amended from time to time and the Foreign Exchange
Management (Non-Debt Instruments) Rules, 2019 as amended from time to time. Foreign Portfolio Investor/FPI wherever

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 11 -->

10

2.1.22

‘FVCI’ means a Foreign Venture Capital Investor incorporated and established
outside India and registered with the SEBI under the Securities and Exchange Board
of India (Foreign Venture Capital Investors) Regulations, 2000, as amended from
time to time.

2.1.23

‘Government Approval’ means the approval from the erstwhile Secretariat for
Industrial Assistance (SIA), Department for Promotion of Industry and Internal
Trade, Government of India and/ or the erstwhile Foreign Investment Promotion
Board (FIPB) and/ or Competent Authority (Administrative Ministry/Department)
of the Policy, as the case may be.

2.1.24

‘Government Route’ means the entry route through which investment by a person
resident outside India requires prior Government approval and foreign investment
received under this route shall be in accordance with the conditions stipulated by
the Government in its approval

2.1.25

‘Group Company’ means two or more enterprises which, directly or indirectly, are
in a position to:
(i)exercise twenty-six percent or more of voting rights in other enterprise; or
(ii) appoint more than fifty percent of members of Board of Directors in the other
enterprise.

2.1.26

‘Holding Company’ shall have the same meaning as assigned to it under the
Companies Act, as amended from time to time.

2.1.27

‘Indian Company’ means a company incorporated in India under the Companies
Act, as applicable.

2.1.28

‘Investment’ means to subscribe, acquire, hold or transfer any security or unit
issued by a person resident in India.
Explanation:(i) Investment shall include to acquire, hold or transfer depository receipts issued
outside India, the underlying of which is a security issued by a person resident in
India;
(ii) for the purpose of LLP, investment shall mean capital contribution or acquisition
or transfer of profit shares;

used in this document, shall have the meaning and implications as specified under the said regulations/Rules, particularly
during the transition period as prescribed in these Regulations.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 12 -->

11

2.1.29

‘Investment Vehicle’ shall mean an entity registered and regulated under relevant
regulations framed by SEBI or any other authority designated for the purpose and
shall include (i)Real Estate Investment Trusts (REITs) governed by the SEBI (REITs)
Regulations, 2014, (ii)Infrastructure Investment Trusts (InvIts) governed by the SEBI
(InvIts) Regulations, 2014, and (iii)Alternative Investment Funds (AIFs) governed
by the SEBI (AIFs) Regulations, 2012

2.1.30

‘Investing Company’ means an Indian Company holding only investments in other
Indian company(ies), directly or indirectly, other than for trading of such
holdings/securities.

2.1.31

‘Investment on repatriable basis’ means investment, the sale or maturity proceeds
of which, net of taxes, are eligible to be repatriated out of India and the expression
‘investment on non-repatriable basis’ shall be construed accordingly.

2.1.32

‘Joint Venture’ (JV) means an Indian entity incorporated in accordance with the
laws and regulations in India in whose capital a non-resident entity makes an
investment.

2.1.33

‘Limited Liability Partnership or LLP’ means a Limited Liability Partnership firm,
formed and registered under the Limited Liability Partnership Act, 2008.

2.1.34

‘Listed Indian company’ means an Indian company which has any of its equity
instruments or debt instruments listed on a recognised stock exchange in India and
the expression “unlisted Indian company” shall be construed accordingly.

2.1.35

‘Manufacture’, with its grammatical variations, means a change in a non-living
physical object or article or thing- (a) resulting in transformation of the object or
article or thing into a new and distinct object or article or thing having a different
name, character and use; or (b) bringing into existence of a new and distinct object
or article or thing with a different chemical composition or integral structure.

2.1.36

‘Non-resident entity’ means a ‘person resident outside India’ as defined under
FEMA.

2.1.37

‘Non-Resident Indian’ (NRI) means an individual resident outside India who is a
citizen of India.

2.1.38

‘OCI’ or ‘Overseas Citizen of India’ means an individual resident outside India
who is registered as an Overseas Citizen of India Cardholder under section 7A of
the Citizenship Act, 1955 (57 of 1955).

2.1.39

A company is considered as ‘Owned’ by resident Indian citizens if more than 50% of
the capital in it is beneficially owned by resident Indian citizens and / or Indian

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 13 -->

12

companies, which are ultimately owned and controlled by resident Indian citizens.
A Limited Liability Partnership will be considered as owned by resident Indian
citizens if more than 50% of the investment in such an LLP is contributed by
resident Indian citizens and/or entities which are ultimately ‘owned and controlled
by resident Indian citizens’ and such resident Indian citizens and entities have
majority of the profit share.
2.1.40

‘Person’ includes(i) an individual,
(ii) a Hindu undivided family,
(iii) a company,
(iv) a firm,
(v) an association of persons or a body of individuals whether incorporated or not,
(vi) every artificial juridical person, not falling within any of the preceding subclauses, and
(vii) any agency, office, or branch owned or controlled by such person.

2.1.41

‘Person resident in India’ means(i) a person residing in India for more than one hundred and eighty-two days
during the course of the preceding financial year but does not include(A) A person who has gone out of India or who stays outside India, in either
case(a) for or on taking up employment outside India, or
(b) for carrying on outside India a business or vocation outside India, or
(c) for any other purpose, in such circumstances as would indicate his
intention to stay outside India for an uncertain period;
(B) A person who has come to or stays in India, in either case, otherwise than(a) for or on taking up employment in India; or
(b) for carrying on in India a business or vocation in India, or
(c) for any other purpose, in such circumstances as would indicate his
intention to stay in India for an uncertain period;
(ii) any person or body corporate registered or incorporated in India,
(iii) an office, branch or agency in India owned or controlled by a person resident
outside India,

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 14 -->

13

(iv) an office, branch or agency outside India owned or controlled by a person
resident in India.
2.1.42

‘Person resident outside India’ means a person who is not a Person resident in
India.

2.1.43

‘RBI’ means the Reserve Bank of India established under the Reserve Bank of India
Act, 1934.

2.1.44

‘Resident Entity’ means ‘Person resident in India’ excluding an individual.

2.1.45

‘Resident Indian Citizen’ shall be interpreted in line with the definition of ‘person
resident in India’ as per FEMA, 1999, read in conjunction with the Indian
Citizenship Act, 1955.

2.1.46

‘SEBI’ means the Securities and Exchange Board of India established under the
Securities and Exchange Board of India Act, 1992.

2.1.47

‘SEZ’ means a Special Economic Zone as defined in Special Economic Zone Act,
2005.

2.1.48

‘Startup Company’ means a private company incorporated under the Companies
Act, 2013 and identified under G.S.R. 127(E) dated 19th February, 2019 issued by the
DPIIT, Ministry of Commerce and Industry.

2.1.49

‘Sweat Equity Shares’ means sweat equity shares defined under the Companies
Act, 2013.

2.1.50

‘Total Foreign Investment’ means the total of foreign investment and indirect
foreign investment and the same will be reckoned on a fully diluted basis.

2.1.51

‘Transferable Development Rights’ (TDR) shall have the meaning assigned to it in
the regulations made under subsection (2) of section 6 of FEMA.

2.1.52

‘Unit’ shall mean beneficial interest of an investor in an Investment Vehicle

2.1.53

‘Venture Capital Fund’ (VCF) means a fund established in the form of a trust, a
company including a body corporate and registered under the Securities and
Exchange Board of India (Alternative Investment Funds) Regulations, 2012.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 15 -->

14

CHAPTER 3: GENERAL CONDITIONS ON FDI
3.1

ELIGIBLE INVESTORS

3.1.1

(a) A non-resident entity can invest in India, subject to the FDI Policy except in
those sectors/activities which are prohibited. However, an entity of a country,
which shares land border with India or where the beneficial owner of an investment
into India is situated in or is a citizen of any such country, can invest only under the
Government route. Further, a citizen of Pakistan or an entity incorporated in
Pakistan can invest, only under the Government route, in sectors/activities other
than defence, space, atomic energy and sectors/activities prohibited for foreign
investment.
(b) In the event of the transfer of ownership of any existing or future FDI in an
entity in India, directly or indirectly, resulting in the beneficial ownership falling
within the restriction/purview of the para 3.1.1(a), such subsequent change in
beneficial ownership will also require Government approval.

3.1.2

NRIs resident in Nepal and Bhutan as well as citizens of Nepal and Bhutan are
permitted to invest in the capital of Indian companies on repatriation basis, subject
to the condition that the amount of consideration for such investment shall be paid
only by way of inward remittance in free foreign exchange through normal banking
channels.

3.1.3

OCBs have been derecognized as a class of investors in India with effect from
September 16, 2003. Erstwhile OCBs which are incorporated outside India and are
not under the adverse notice of RBI can make fresh investments as incorporated
non-resident entities in accordance with the FDI Policy and Foreign Exchange
Management (Non-Debt Instrument) Rules, 2019.

3.1.4

A company, trust and partnership firm incorporated outside India and owned and
controlled by NRIs can invest in India with the special dispensation as available to
NRIs under the FDI Policy.

3.1.5

Foreign Portfolio Investors (FPI) may make investments in the manner and subject
to the terms and conditions specified in Schedule II of Foreign Exchange
Management (Non-Debt Instruments) Rules, 2019.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 16 -->

15

3.1.6

Registered FPIs and NRIs can invest/trade through a registered broker in the
capital of Indian Companies on recognised Indian Stock Exchanges as per the
applicable Schedule under the Foreign Exchange Management (Non-Debt
Instruments) Rules, 2019, as amended from time to time.

3.1.7

A Foreign Venture Capital Investor (FVCI) may make investments in the manner
and subject to the terms and conditions specified in Schedule VII of Foreign
Exchange Management (Non-Debt Instruments) Rules, 2019.

3.1.8

An NRI or an OCI may subscribe to National Pension System governed and
administered by Pension Fund Regulatory and Development Authority (PFRDA),
provided such subscriptions are made through normal banking channels and the
person is eligible to invest as per the provisions of the PFRDA Act. The annuity/
accumulated saving will be repatriable.

3.2

ELIGIBLE INVESTEE ENTITIES

3.2.1 Indian Company
Indian companies can issue capital against FDI.
3.2.2 Partnership Firm/Proprietary Concern
(i)

A Non-Resident Indian (NRI) can invest in the capital of a firm or a proprietary
concern in India on non-repatriation basis provided;
(a)

Amount is invested by inward remittance or out of NRE/FCNR(B)/NRO
account maintained with Authorized Dealers/Authorized banks.

(b)

The

firm

or

proprietary

concern

is

not

engaged

in

any

agricultural/plantation or real estate business or print media sector.
(c)

Amount invested shall not be eligible for repatriation outside India.

(ii) Investments with repatriation option: NRIs may seek prior permission of
Reserve Bank for investment in sole proprietorship concerns/partnership firms
with repatriation option. The application will be decided in consultation with
the Government of India.
(iii) Investment by non-residents other than NRIs: A person resident outside India
other than NRIs may make an application and seek prior approval of Reserve
Bank for making investment in the capital of a firm or a proprietorship concern

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 17 -->

16

or any association of persons in India. The application will be decided in
consultation with the Government of India.
(iv) Restrictions: An NRI is not allowed to invest in a firm or proprietorship
concern engaged in any agricultural/plantation activity or real estate business
or print media.
3.2.3

Trusts
Investment by a person resident outside India is not permitted in Trusts other than
in ‘VCF’ registered and regulated by SEBI and ‘Investment vehicle’.

3.2.4

Limited Liability Partnerships (LLPs)
Foreign Investment in LLPs is permitted subject to the following conditions:
(i)

Foreign Investment is permitted under the automatic route in Limited Liability
Partnership (LLPs) operating in sectors/activities where 100% FDI is allowed
through the automatic route and there are no FDI-linked performance
conditions.

(ii) An Indian company or an LLP, having foreign investment, is also permitted to
make downstream investment in another company or LLP in sectors in which
100% FDI is allowed under the automatic route and there are no FDI-linked
performance conditions.
(iii) Conversion of an LLP having foreign investment and operating in
sectors/activities where 100% FDI is allowed through the automatic route and
there are no FDI-linked performance conditions, into a company is permitted
under automatic route. Similarly, conversion of a company having foreign
investment and operating in sectors/activities where 100% FDI is allowed
through the automatic route and there are no FDI-linked performance
conditions, into an LLP is permitted under automatic route.
(iv) Foreign Investment in LLP is subject to the compliance of the conditions of LLP
Act, 2008.
3.2.5

Investment Vehicle
An entity being ‘investment vehicle’ registered and regulated under relevant
regulations framed by SEBI or any other authority designated for the purpose

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 18 -->

17

including Real Estate Investment Trusts (REITs) governed by the SEBI (REITs)
Regulations, 2014, Infrastructure Investment Trusts (InvIts) governed by the SEBI
(InvIts) Regulations, 2014, Alternative Investment Funds (AIFs) governed by the
SEBI (AIFs) Regulations, 2012 is permitted to receive foreign investment from a
person resident outside India (other than an individual who is citizen of or any
other entity which is registered / incorporated in Pakistan or Bangladesh) in the
manner and subject to the terms and conditions specified under Schedule VIII of the
Foreign Exchange Management (Non-Debt Instruments) Rules, 2019.
3.2.6

Startup Companies
Start-ups can issue equity or equity linked instruments or debt instruments to FVCI
against receipt of foreign remittance, as per the Schedule VII of Foreign Exchange
Management (Non-Debt Instruments) Rules, 2019. In addition, start-ups can issue
convertible notes to person resident outside India subject to the following
conditions:
(i) A person resident outside India (other than an individual who is citizen of
Pakistan or Bangladesh or an entity which is registered/incorporated in Pakistan
or Bangladesh), may purchase convertible notes issued by an Indian startup
company for an amount of twenty-five lakh rupees or more in a single tranche.
Explanation: For the purpose of this Regulation, a ‘startup company’ means a
private company incorporated under the Companies Act, 2013 or Companies
Act,1956 and recognised as such in accordance with notification number G.S.R.
127(E) dated 19th February, 2019 issued by the DPIIT, Ministry of Commerce and
Industry, and as amended from time to time.
(ii) A startup company engaged in a sector where foreign investment requires
Government approval may issue convertible notes to a non-resident only with
approval of the Government.
Explanation: For the purpose of this regulation, the issue of shares against such
convertible notes shall have to be in accordance with the Schedule I of the.
Foreign Exchange Management (Non-Debt Instruments) Rules, 2019.
(iii) A startup company issuing convertible notes to a person resident outside India
shall receive the amount of consideration by inward remittance through banking
channels or by debit to the NRE / FCNR (B) / Escrow account maintained by the
person concerned in accordance with the Foreign Exchange Management
(Deposit) Regulations, 2016, as amended from time to time.
Provided that an escrow account for the above purpose shall be closed
immediately after the requirements are completed or within a period of six

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 19 -->

18

months, whichever is earlier. However, in no case continuance of such escrow
account shall be permitted beyond a period of six months.
(iv) NRIs may acquire convertible notes on non-repatriation basis in accordance with
Schedule IV of the Foreign Exchange Management (Non-Debt Instruments)
Rules, 2019.
(v) A person resident outside India may acquire or transfer, by way of sale,
convertible notes, from or to, a person resident in or outside India, provided the
transfer takes place in accordance applicable pricing guidelines under FEMA.
Prior approval from the Government shall be obtained for such acquisitions or
transfers in case the startup company is engaged in a sector which requires
Government approval.
(vi) The startup company issuing convertible notes shall be required to furnish
reports as prescribed by the RBI.
3.2.7

Other Entities
FDI in resident entities other than those mentioned above is not permitted.

3.3 INSTRUMENTS OF INVESTMENTS, ISSUE/TRANSFER OF SHARES ETC.
3.3.1

Types of instruments for investment and provisions relating to issue/ transfer of
shares are given at Annexure 1 & Annexure 2 respectively. Further, specific
conditions of compliance for certain cases are given in Annexure-3.

3.4

ENTRY ROUTES FOR INVESTMENT

3.4.1

Investments can be made by non-residents in the equity shares/fully, compulsorily
and mandatorily convertible debentures/fully, compulsorily and mandatorily
convertible preference shares of an Indian company, through the Automatic Route
or the Government Route. Under the Automatic Route, the non-resident investor or
the Indian company does not require any approval from Government of India for
the investment. Under the Government Route, prior approval of the Government of
India is required. Proposals for foreign investment under Government Route, are
considered by respective Administrative Ministry/Department.

3.4.2

Foreign investment in sectors/activities under government approval route will be
subject to government approval where:
(i)

An Indian company is being established with foreign investment and is not
owned by a resident entity or
Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 20 -->

19

(ii) An Indian company is being established with foreign investment and is not
controlled by a resident entity or
(iii) The control of an existing Indian company, currently owned or controlled by
resident Indian citizens and Indian companies, which are owned or controlled
by resident Indian citizens, will be/is being transferred/passed on to a nonresident entity as a consequence of transfer of shares and/or fresh issue of
shares to non-resident entities through amalgamation, merger/demerger,
acquisition etc. or
(iv) The ownership of an existing Indian company, currently owned or controlled
by resident Indian citizens and Indian companies, which are owned or
controlled by resident Indian citizens, will be/is being transferred/passed on
to a non-resident entity as a consequence of transfer of shares and/or fresh
issue

of

shares

to

non-resident

entities

through

amalgamation,

merger/demerger, acquisition etc.
(v) It is clarified that foreign investment shall include all types of foreign
investments, direct and indirect, regardless of whether the said investments
have been made under Schedule I (FDI), II (FPI), III (NRI), VI (LLPs), VII
(FVCI), VIII(Investment Vehicles) and IX (DRs) of Foreign Exchange
Management (Non-Debt Instruments) Rules, 2019. FCCBs and DRs having
underlying of instruments which can be issued under Schedule IX, being in the
nature of debt, shall not be treated as foreign investment. However, any equity
holding by a person resident outside India resulting from conversion of any
debt instrument under any arrangement shall be reckoned as foreign
investment.
(vi) Investment by NRIs under Schedule IV of Foreign Exchange Management
(Non-Debt Instruments) Rules, 2019 will be deemed to be domestic investment
at par with the investment made by residents.
(vii) A company, trust and partnership firm incorporated outside India and owned
and controlled by non-resident Indians will be eligible for investments under
Schedule IV of Foreign Exchange Management (Non-Debt Instruments) Rules,
2019 and such investment will also be deemed domestic investment at par with
the investment made by residents.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 21 -->

20

3.5

CAPS ON INVESTMENTS

3.5.1

Investments can be made by person resident outside India in the capital of a
resident entity only to the extent of the percentage of the total capital as specified in
the FDI policy. The caps in various sector(s) are detailed in Chapter 5 of this
Circular.

3.6

ENTRY CONDITIONS ON INVESTMENT

3.6.1

Investments by non-residents can be permitted in the capital of a resident entity in
certain sectors/activity with entry conditions. Such conditions may include norms
for minimum capitalization, lock-in period, etc. The entry conditions in various
sectors/activities are detailed in Chapter 5 of this Circular.

3.7

OTHER CONDITIONS ON INVESTMENT BESIDES ENTRY CONDITIONS

3.7.1

Besides the entry conditions on foreign investment, the investment/investors are
required to comply with all relevant sectoral laws, regulations, rules, security
conditions, and state/local laws/regulations.

3.7.2

Establishment of branch office, liaison office or project office or any other place of
business in India shall be governed by the Foreign Exchange Management
(Establishment in India of a branch office or a liaison office or a project office or any
other place of business) Regulations, 2016. Further, acquisition or transfer of
immovable property in India by citizens of certain countries shall be regulated as
per the relevant provisions under the Foreign Exchange Management (Non-Debt
Instruments) Rules, 2019, as amended from time to time.

3.8 FOREIGN INVESTMENT INTO/DOWNSTREAM INVESTMENT BY ELIGIBLE
INDIAN ENTITIES
3.8.1

The Guidelines for calculation of total foreign investment, both direct and indirect
in an Indian company/LLP, at every stage of investment, including downstream
investment, have been detailed in Annexure-4.

3.8.2

For the purpose of this chapter,
(i)

‘Downstream investment’ means indirect foreign investment, by an eligible
Indian entity, into another Indian Company/LLP, by way of subscription or

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 22 -->

21

acquisition. Annexure-4 provides the guidelines for calculation of indirect
foreign investment, with conditions specified in paragraph 1.2 (v).
(ii)
3.8.3

‘Foreign Investment’ would have the same meaning as in Annexure-4.

Foreign investment into an Indian company engaged only in the activity of
investing in the capital of other Indian company(ies) (regardless of its ownership
or control):

3.8.3.1 Foreign Investment in Investing Companies registered as Non-Banking Financial
Companies (NBFC) with the RBI, being overall regulated, would be under 100%
automatic route.
3.8.3.2

Foreign Investment in Core Investment Companies (CICs) and other investing
companies, engaged in the activity of investing in the capital of other Indian
company(ies)/LLPs, is permitted under Government approval route. CICs will have
to additionally follow RBI’s regulatory framework for CICs.

3.8.3.3

For undertaking activities which are under automatic route and without foreign
investment linked performance conditions, Indian company which does not have
any operations and also does not have any downstream investments, will be
permitted to have infusion of foreign investment under automatic route. However,
approval of the Government will be required for such companies for infusion of
foreign investment for undertaking activities which are under Government route,
regardless of the amount or extent of foreign investment. Further, as and when such
a company commences business(s) or makes downstream investment, it will have to
comply with the relevant sectoral conditions on entry route, conditionalities and
caps.

Note:

Foreign investment into other Indian companies/LLPs would be in accordance/
compliance with the relevant sectoral conditions on entry route, conditionalities and
caps.

3.8.4

Downstream investment by an eligible Indian entity which is not owned and/or
controlled by resident entity(ies)

3.8.4.1

Downstream investment by an eligible Indian entity, which is not owned and/or
controlled by resident entity(ies), into another Indian company, would be in
accordance/compliance with the relevant sectoral conditions on entry route,

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 23 -->

22

conditionalities and caps, with regard to the sectors in which the latter Indian
company is operating.
Note:

Downstream investment/s made by a banking company, as defined in clause(c) of
Section 5 of the Banking Regulation Act, 1949, incorporated in India, which is
owned and/or controlled by non-residents/a non-resident entity/non-resident
entities, under Corporate Debt Restructuring (CDR), or other loan restructuring
mechanism, or in trading books, or for acquisition of shares due to defaults in loans,
shall not count towards indirect foreign investment. However, their 'strategic
downstream investment' shall count towards indirect foreign investment. For this
purpose, 'strategic downstream investments' would mean investment by these
banking companies in their subsidiaries, joint ventures and associates.

3.8.4.2

Downstream investments by eligible Indian entities/LLPs will be subject to the
following conditions:
(i)

Such an entity is required to notify its downstream investment to RBI in
Form DI as well as on Foreign Investment Facilitation Portal in the form
available at www.fifp.gov.in within 30 days of such investment, even if
capital instruments have not been allotted along with the modality of
investment in new/existing ventures (with/without expansion programme);

(ii) Downstream investment by way of induction of foreign investment in an
existing Indian Company to be duly supported by a resolution of the Board
of Directors as also a share-holders agreement, if any;
(iii) Issue/transfer/pricing/valuation of capital shall be in accordance with
applicable FEMA/SEBI guidelines;
(iv) For the purpose of downstream investment, the eligible Indian entities
making the downstream investments would have to bring in requisite funds
from abroad and not leverage funds from the domestic market. This would,
however, not preclude downstream companies/LLPs, with operations, from
raising debt in the domestic market. Downstream investments through
internal accruals are permissible, subject to the provisions of paragraphs 3.8.3
and 3.8.4.1. For the purposes of foreign investment policy, internal accruals
will mean as profits transferred to reserve account after payment of taxes.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 24 -->

23

3.9

REMITTANCE, REPORTING AND VIOLATION

3.9.1

The Government has provided elaborated scheme for remittance, reporting and
violation of FDI policy. These are available at Annexure-5.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 25 -->

24

CHAPTER 4: PROCEDURE FOR GOVERNMENT APPROVAL
4.1

COMPETENT AUTHORITY

4.1.1 Following are the Competent Authorities for grant of approval for foreign investment
for sectors/activities requiring Government approval:
S. No.

Activity/ sector

Administrative

Ministry/

Department
(i)

Mining

(ii)

Defence

Ministry of Mines

a) Items requiring Industrial Licence under the Department

of

Defence

Industries (Development & Regulation) Act, 1951, Production,

Ministry

of

and/or Arms Act, 1959 for which the powers have Defence
been delegated by Ministry of Home Affairs to DPIIT
b) Manufacturing of Small Arms and Ammunitions Ministry of Home Affairs
covered under Arms Act 1959
(iii)

Broadcasting

Ministry of Information &

(iv)

Print Media/Digital Media

Broadcasting

(v)

Civil Aviation

Ministry of Civil Aviation

(vi)

Satellites

Department of Space

(vii)

Telecommunication

Department

of

Telecommunications
(viii)

Private Security Agencies

Ministry of Home Affairs

(ix) (a) Applications involving investments from an entity of Concerned

Administrative

a country, which shares land border with India or Ministry/Department
where the beneficial owner of an investment into identified by the DPIIT
India is situated in or is a citizen of any such country
{as required in terms of Press Note 3 of 2020 read
with Foreign Exchange Management (Non-debt
Instruments)

Amendment

Rules,

2020

dated

22.04.2020}

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

as

<!-- page 26 -->

25

(ix)(b)

Cases

pertaining

to

sectors/activities

under Nodal

Administrative

Government approval route requiring security Ministries/Departments
clearance as per the extant Foreign Exchange
Management (Non-Debt Instruments) Rules, 2019,
FDI Policy and security guidelines, as amended from
time to time
(x)

Trading (Multi Brand Retail Trading and Food Department for Promotion of
Product retail trading)

(xi)

Industry and Internal Trade

FDI proposals by Non-Resident Indians (NRIs)/
Export Oriented Units requiring approval of the
Government

(xii)

Applications relating to issue of equity shares under Concerned

Administrative

the FDI policy under the Government route for Ministry/Department

as

import of capital goods/machinery/equipment identified by the DPIIT
(excluding second-hand machinery)
(xiii)

Applications relating to issue of equity shares for
pre-operative/pre-incorporation expenses (including
payments of rent etc.)

(xiv)

Financial services activity which are not regulated by
any Financial Sector Regulator or where only part of
the financial services activity is regulated or where
there is doubt regarding the regulatory oversight

(xv)

Department

of

Economic

of

Financial

Applications for foreign investment into a Core Affairs
Investment Company or an Indian company
engaged only in the activity of investing in the
capital of other India Company(ies)

(xvi)

Banking (Public and Private)

Department
Services

(xvii)

Pharmaceuticals

Department

of

Pharmaceuticals
4.1.2

In respect of sectors/activities which are presently under automatic route but
required Government approval earlier as per the extant policy during the relevant
Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 27 -->

26

period, concerned administrative Ministry/Department would be the Competent
Authorities for the grant of post-facto approval for foreign investment.
4.1.3

In respect of applications in which there is a doubt about the Administrative
Ministry/Department concerned, DPIIT shall identify the Administrative
Ministry/Department where the application will be processed.

4.1.4

Proposals for foreign investment would be examined by Competent Authorities as
per the Standard Operating Procedure laid down by DPIIT (available at
http://www.fifp.gov.in/Forms/SOP.pdf).

4.1.5

In case of proposals involving total foreign equity inflow of more than Rs 5000 crore,
Competent Authority shall place the same for consideration of Cabinet Committee on
Economic Affairs (CCEA).

4.1.6

The CCEA would also consider the proposals which may be referred to it by the
Minister-in-charge of the concerned Competent Authority.

4.1.7

In respect of proposals where the Competent Authority proposes to reject the
proposals or in cases where conditions for approval are stipulated in addition to the
conditions laid down in the FDI policy or sectoral laws/regulations, concurrence of
DPIIT shall compulsorily be sought by the Competent Authority. 2

4.1.8

The monitoring of the compliance of conditions under the FDI approvals, including
the past cases approved by the Government, shall be done by the concerned
Administrative Ministries/Departments.

4.2
4.2.1

CASES WHICH DO NOT REQUIRE FRESH APPROVAL
Companies may not require fresh approval of the Government for bringing in
additional foreign investment into the same entity, in the following cases:
(i) Entities, the activities of which had earlier required the prior approval of the
Government and which had, accordingly, earlier obtained the prior approval of
the Government for their initial foreign investment but subsequently such
activities/sectors have been placed under automatic route;
(ii)Entities, the activities of which had sectoral caps earlier and which had,
accordingly, earlier obtained the prior approval of the Government for their

2

Please refer to clarification dated 27.04.2018 issued by DPIIT in this regard which can be accessed at
https://fifp.gov.in/Forms/SOP_Clarification.pdf

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 28 -->

27

initial foreign investment but subsequently such caps were removed/increased
and the activities placed under the automatic route; provided that such
additional investment along with the initial/original investment does not exceed
the sectoral caps;
(iii) Additional foreign investment into the same entity where the prior approval of
the Government had been obtained earlier for the initial/original foreign
investment due to requirements of Press Note 18 of 1998 or Press Note 1 of 2005
and the prior approval of the Government under the FDI policy is not required
for any other reason/purpose; and
(iv) Additional foreign investment up to cumulative amount of Rs 5000 crore into
the same entity within an approved foreign equity percentage/or into a wholly
owned subsidiary.

4.3

ONLINE FILING OF APPLICATIONS FOR GOVERNMENT APPROVAL

4.3.1

Guidelines for e-filing of applications, filing of amendment applications and
instructions to applicants are available at the Foreign Investment Facilitation Portal
(www.fifp.gov.in).

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 29 -->

28

CHAPTER 5: SECTOR SPECIFIC CONDITIONS ON FDI
5.1 PROHIBITED SECTORS
FDI is prohibited in:
a)

Lottery Business including Government/private lottery, online lotteries, etc.

b)

Gambling and Betting including casinos etc.

c)

Chit funds

d)

Nidhi company

e)

Trading in Transferable Development Rights (TDRs)

f)

Real Estate Business or Construction of Farm Houses
‘Real estate business’ shall not include development of townships, construction of
residential /commercial premises, roads or bridges and Real Estate Investment
Trusts (REITs) registered and regulated under the SEBI (REITs) Regulations 2014.

g)

Manufacturing of cigars, cheroots, cigarillos and cigarettes, of tobacco or of tobacco
substitutes

h)

Activities/sectors not open to private sector investment e.g.(I) Atomic Energy and
(II) Railway operations (other than permitted activities mentioned in para 5.2).
Foreign technology collaboration in any form including licensing for franchise,
trademark, brand name, management contract is also prohibited for Lottery
Business, Gambling and Betting activities.

5.2 PERMITTED SECTORS
a)

In the following sectors/activities, FDI up to the limit indicated against each
sector/activity is allowed, subject to applicable laws/regulations; security and other
conditionalities. In sectors/activities not listed below, FDI is permitted up to100% on
the automatic route, subject to applicable laws/regulations; security and other
conditionalities. Wherever there is a requirement of minimum capitalization, it shall
include share premium received along with the face value of the share, only when it is
received by the company upon issue of the shares to the non-resident investor. Amount

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 30 -->

29

paid by the transferee during post-issue transfer of shares beyond the issue price of the
share, cannot be taken into account while calculating minimum capitalization
requirement.
b)

Sectoral cap i.e. the maximum amount which can be invested by foreign investors in an
entity, unless provided otherwise, is composite and includes all types of foreign
investments, direct and indirect, regardless of whether the said investments have been
made under Schedules I (FDI), II (FPI), III (NRI), VI (LLPs), VII (FVCI), VIII(Investment
Vehicles), and IX (DRs), respectively, of Foreign Exchange Management (Non-Debt
Instruments) Rules, 2019. FCCBs and DRs having underlying of instruments which can
be issued under Schedule IX, being in the nature of debt, shall not be treated as foreign
investment. However, any equity holding by a person resident outside India resulting
from conversion of any debt instrument under any arrangement shall be reckoned as
foreign investment under the composite cap.

c)

Foreign investment in sectors under Government approval route resulting in transfer of
ownership and/or control of Indian entities from resident Indian citizens to nonresident entities will be subject to Government approval. Foreign investment in sectors
under automatic route but with conditionalities, resulting in transfer of ownership
and/or control of Indian entities from resident Indian citizens to non-resident entities,
will be subject to compliance of such conditionalities.

d)

The sectors which are already under 100% automatic route and are without
conditionalities would not be affected.

e)

Notwithstanding anything contained in paragraphs a) and c) above, portfolio
investment, up to aggregate foreign investment level as permitted under Schedule II of
Foreign Exchange Management (Non-Debt Instruments) Rules, 2019 will not be subject
to either Government approval or compliance of sectoral conditions, as the case may be,
if such investment does not result in transfer of ownership and/or control of Indian
entities from resident Indian citizens to non-resident entities. Other foreign investments
will be subject to conditions of Government approval and compliance of sectoral
conditions as laid down in the FDI policy.

f)

Total foreign investment, direct and indirect, in an entity will not exceed the
sectoral/statutory cap.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 31 -->

30

g)

Any existing foreign investment already made in accordance with the policy in
existence would not require any modification to conform to amendments introduced
through Press Note 8 (2015 Series).

h)

Wherever the foreign investor wishes to specify a particular auditor/audit firm having
international network for the Indian investee company, then audit of such investee
companies should be carried out as joint audit wherein one of the auditors should not
be part of the same network.

i)

The onus of compliance of above provisions will be on the investee company.

AGRICULTURE

5.2.1 AGRICULTURE & ANIMAL HUSBANDRY
% of Equity/

Sector/Activity

FDI Cap

a) Floriculture, Horticulture, and Cultivation of

100%

Entry Route
Automatic

Vegetables & Mushrooms under controlled
conditions;
b) Development and Production of seeds and
planting material;
c) Animal Husbandry (including breeding of
dogs), Pisciculture, Aquaculture, Apiculture;
and
d) Services related to agro and allied sectors
Note: Besides the above, FDI is not allowed in
any other agricultural sector/activity

5.2.1.1 OTHER CONDITIONS
I.

The term “under controlled conditions” covers the following:
(i) ‘Cultivation under controlled conditions’ for the categories of floriculture, horticulture,
cultivation of vegetables and mushrooms is the practice of cultivation wherein rainfall,
temperature, solar radiation, air humidity and culture medium are controlled

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 32 -->

31

artificially. Control in these parameters may be effected through protected cultivation
under green houses, net houses, poly houses or any other improved infrastructure
facilities where micro-climatic conditions are regulated anthropogenically.

5.2.2 PLANTATION SECTOR
% of Equity/

Sector/Activity

FDI Cap

5.2.2.1

100%

Entry Route
Automatic

(i) Tea sector including tea plantations
(ii) Coffee plantations
(iii) Rubber plantations
(iv) Cardamom plantations
(v) Palm oil tree plantations
(vi) Olive oil tree plantations
Note: Besides the above, FDI is not allowed in
any other plantation sector/activity.

5.2.2.2 OTHER CONDITION
Prior approval of the State Government concerned is required in case of any future land use
change.
MINING AND PETROLEUM & NATURAL GAS

5.2.3 MINING
% of Equity/

Sector/Activity

FDI Cap

5.2.3.1

100%

Entry Route
Automatic

Mining and Exploration of metal and non-metal
ores including diamond, gold, silver and precious
ores but excluding titanium bearing minerals and its
ores;

subject

to

the

Mines

and

Minerals

(Development & Regulation) Act, 1957.
5.2.3.2

100%

Automatic

Coal & Lignite

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 33 -->

32

(1) Coal & Lignite mining for captive consumption
by power projects, iron & steel and cement units
and other eligible activities permitted under and
subject to the provisions of Coal Mines (Special
Provisions) Act, 2015 and the Mines and Minerals
(Development and Regulation) Act, 1957.
(2) Setting up coal processing plants like washeries
subject to the condition that the company shall not
do coal mining and shall not sell washed coal or
sized coal from its coal processing plants in the
open market and shall supply the washed or sized
coal to those parties who are supplying raw coal to
coal processing plants for washing or sizing.
(3) For sale of coal, coal mining activities including
associated processing infrastructure subject to the
provisions of Coal Mines (Special Provisions) Act,
2015 and the Mines and Minerals (Development and
Regulation) Act, 1957 as amended from time to time
and other relevant Acts on the subject.
5.2.3.3

100%

Government

Mining and mineral separation of titanium
bearing minerals and ores, its value addition and
integrated activities
5.2.3.3.1
Mining and mineral separation of titanium bearing
minerals & ores, its value addition and integrated
activities subject to sectoral regulations and the
Mines and Minerals (Development and Regulation
Act 1957).

5.2.3.3.2 OTHER CONDITIONS
(i) FDI for separation of titanium bearing minerals & ores will be subject to the following
additional conditions viz.:

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 34 -->

33

(A) value addition facilities are set up within India along with transfer of technology;
(B) disposal of tailings during the mineral separation shall be carried out in accordance with
Rules framed by the Atomic Energy Regulatory Board such as Atomic Energy (Radiation
Protection) Rules, 2004 and the Atomic Energy (Safe Disposal of Radioactive Wastes)
Rules, 1987.
(ii) FDI will not be allowed in mining of “prescribed substances” listed in the Notification
No. S.O. 61(E), dated 18.1.2006, issued by the Department of Atomic Energy.
(iii) “Associated Processing Infrastructure" as contained at Para 5.2.3.2 above includes coal
washery, crushing, coal handling, and separation (magnetic and non-magnetic)

CLARIFICATION:
(1) For titanium bearing ores such as Ilmenite, Leucoxene and Rutile, manufacture of
titanium dioxide pigment and titanium sponge constitutes value addition. Ilmenite can be
processed to ‘produce 'Synthetic Rutile or Titanium Slag as an intermediate value-added
product.
(2) The objective is to ensure that the raw material available in the country is utilized for
setting up downstream industries and the technology available internationally is also
made available for setting up such industries within the country. Thus, if with the
technology transfer, the objective of the FDI Policy can be achieved, the conditions
prescribed at (i) (A) above shall be deemed to be fulfilled.

5.2.4 PETROLEUM & NATURAL GAS
% of Equity/

Sector/Activity

Entry Route

FDI Cap
5.2.4.1
Exploration activities of oil and natural gas fields,
infrastructure related to marketing of petroleum

100%

Automatic

products and natural gas, marketing of natural gas
and petroleum products, petroleum product
pipelines,

natural

gas/pipelines,

LNG

Regasification infrastructure, market study and
formulation and Petroleum refining in the private
sector, subject to the existing sectoral policy and
regulatory framework in the oil marketing sector

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 35 -->

34

and the policy of the Government on private
participation in exploration of oil and the
discovered fields of national oil companies.
5.2.4.2
Petroleum

49%
refining

by

the

Public

Automatic

Sector

Undertakings (PSU), without any disinvestment or
dilution of domestic equity in the existing PSUs.

MANUFACTURING

5.2.5 MANUFACTURING
5.2.5.1 Subject to the provisions of the FDI policy, foreign investment in ‘manufacturing’
sector is under automatic route. Manufacturing activities may be either self-manufacturing
by the investee entity or contract manufacturing in India through a legally tenable contract,
whether on Principal to Principal or Principal to Agent basis. Further, a manufacturer is
permitted to sell its products manufactured in India through wholesale and/or retail,
including through e-commerce, without Government approval.
5.2.5.2 Notwithstanding the FDI policy provisions on trading sector, 100% FDI under
Government approval route is allowed for retail trading, including through e-commerce, in
respect of food products manufactured and/or produced in India.

5.2.6 DEFENCE
% of Equity/

Sector/Activity

Entry Route

FDI Cap
5.2.6.1

Automatic up to

Defence Industry subject to Industrial license under
the Industries (Development & Regulation) Act,
1951 and Manufacturing of small arms and
ammunition under the Arms Act, 1959

100%

74%
Government
route beyond 74%
wherever it is
likely to result in
access to modern
technology or for

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 36 -->

35

other reasons to
be recorded

5.2.6.2 OTHER CONDITIONS
(i) FDI up to 74% under automatic route shall be permitted for companies seeking new
industrial licenses.
(ii) Infusion of fresh foreign investment up to 49%, in a company not seeking industrial license
or which already has Government approval for FDI in Defence, shall require mandatory
submission of a declaration with the Ministry of Defence in case change in equity
/shareholding pattern or transfer of stake by existing investor to new foreign investor for
FDI up to 49%, within 30 days of such change. Proposal for raising FDI beyond 49% from
such companies will require Government approval.
(iii) Licence applications will be considered by the Department for Promotion of Industry and
Internal Trade, Ministry of Commerce & Industry, in consultation with Ministry of Defence
and Ministry of External Affairs.
(iv) Foreign investment in the sector is subject to security clearance by the Ministry of Home
Affairs and as per guidelines of the Ministry of Defence.
(v) Investee company should be structured to be self-sufficient in the areas of product design
and development. The investee/joint venture company along with the manufacturing
facility, should also have maintenance and life cycle support facility of the product being
manufactured in India.
(vi) Foreign Investments in the Defence Sector shall be subject to scrutiny on grounds of
National Security and Government reserves the right to review any foreign investment in
the Defence Sector that affects or may affect national security.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 37 -->

36

SERVICES SECTOR

5.2.7 BROADCASTING
5.2.7.1 BROADCASTING CARRIAGE SERVICES
Sector/Activity

% of Equity/

Entry Route

FDI Cap
5.2.7.1.1
(1)Teleports(setting

up

of

up-linking

100%

Automatic

100%

Automatic

HUBs/Teleports);
(2)Direct to Home (DTH);
(3)Cable Networks (Multi System operators (MSOs)
operating at National or State or District level and
undertaking upgradation of networks towards
digitalization and addressability);
(4)Mobile TV;
(5)Headend-in-the Sky Broadcasting Service(HITS)
5.2.7.1.2
Cable Networks(Other MSOs not undertaking
upgradation of networks towards digitalization and
addressability and Local Cable Operators (LCOs))
Note:
Infusion of fresh foreign investment, beyond 49% in a company not seeking
license/permission from sectoral Ministry, resulting in change in the ownership pattern
or transfer of stake by existing investor to new foreign investor, will require
Government approval.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 38 -->

37

5.2.7.2 BROADCASTING CONTENT SERVICES
% of Equity/

Sector/Activity

Entry Route

FDI Cap
5.2.7.2.1 Terrestrial Broadcasting FM (FM Radio),

49%

Government

49%

Government

26%

Government

100%

Automatic

subject to such terms and conditions, as specified
from time to time, by Ministry of Information &
Broadcasting, for grant of permission for setting up
of FM Radio stations
5.2.7.2.2
Up-linking of ‘News & Current Affairs’ TV
Channels
5.2.7.2.3
Uploading/Streaming of News & Current Affairs
through Digital Media
5.2.7.2.4
Up-linking of Non- ‘News & Current Affairs’ TV
Channels/ Down-linking of TV Channels

5.2.7.3 Detailed guidelines on the Broadcasting Sector are given in Annexure-6.

5.2.8 PRINT MEDIA
% of Equity/

Sector/Activity

FDI Cap

5.2.8.1

Entry Route

26%

Government

26%

Government

Publishing of newspaper and periodicals dealing
with news and current affairs
5.2.8.2
Publication of Indian editions of foreign magazines
dealing with news and current affairs

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 39 -->

38

5.2.8.2.1 OTHER CONDITIONS
(i) ‘Magazine’, for the purpose of these guidelines, will be defined as a periodical publication,
brought out on non-daily basis, containing public news or comments on public news.
(ii) Foreign investment would also be subject to the Guidelines for Publication of Indian
editions of foreign magazines dealing with news and current affairs issued by the Ministry of
Information & Broadcasting on 4.12.2008, as amended from time to time.
% of Equity/

Sector/Activity

FDI Cap

5.2.8.3

Entry Route

100%

Government

100%

Government

Publishing/printing of scientific and technical
magazines/specialty journals/ periodicals, subject
to compliance with the legal framework as
applicable and guidelines issued in this regard from
time to time by Ministry of Information and
Broadcasting.
5.2.8.4
Publication

of

facsimile

edition

of

foreign

newspapers
5.2.8.4.1 Other Conditions
(i) FDI should be made by the owner of the original foreign newspapers whose facsimile
edition is proposed to be brought out in India.
(ii) Publication of facsimile edition of foreign newspapers can be undertaken only by an
entity incorporated or registered in India under the provisions of the Companies Act,
as applicable.
(iii) Publication of facsimile edition of foreign newspaper would also be subject to the
Guidelines for publication of newspapers and periodicals dealing with news and
current affairs and publication of facsimile edition of foreign newspapers issued by
Ministry of Information & Broadcasting on 31.3.2006, as amended from time to time.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 40 -->

39

5.2.9 CIVIL AVIATION
5.2.9.1 AIRPORTS
% of Equity/

Sector/Activity

Entry Route

FDI Cap

(a) Greenfield projects

100%

Automatic

(b) Existing projects

100%

Automatic

5.2.9.2 AIR TRANSPORT SERVICES
% of Equity/

Sector/Activity

Entry Route

FDI Cap
Automatic up to

(1) (a) Scheduled Air Transport Service*/ Domestic
Scheduled Passenger Airline

49%

100%

(Automatic up to

(b) Regional Air Transport Service

100% for NRIs)

Government
route beyond 49%
(2) Non-Scheduled Air Transport Services

100%

Automatic

(3) Helicopter services/seaplane services requiring

100%

Automatic

DGCA approval
*As per Schedule XI of Aircraft Rules, 1937, Air Operator Certificate to operate Scheduled air
transport services (including Domestic Scheduled Passenger Airline or Regional Air Transport
Service) may be granted to a company or a body corporate provided that: (a) it is registered and has its principal place of business within India;
(b) the Chairman and at least two-thirds of its Directors are citizens of India; and
(c) its substantial ownership and effective control is vested in Indian nationals

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 41 -->

40

5.2.9.3 OTHER SERVICES UNDER CIVIL AVIATION SECTOR
% of Equity/

Sector/Activity

Entry Route

FDI Cap
(1) Ground Handling Services subject to sectoral

100%

Automatic

100%

Automatic

regulations and security clearance
(2) Maintenance and Repair organizations; flying
training

institutes;

and

technical

training

institutions.

DEFINITIONS: The Civil Aviation sector includes Airports, Scheduled and Non-Scheduled
domestic passenger airlines, Helicopter services/Seaplane services, Ground Handling
Services, Maintenance and Repair organizations; Flying training institutes; and Technical
training institutions.
For the purposes of the Civil Aviation sector:
(i)

“Airport” means a landing and taking off area for aircrafts, usually with runways and
aircraft maintenance and passenger facilities and includes aerodrome as defined in
clause (2) of section 2 of the Aircraft Act, 1934;

(ii) “Aerodrome” means any definite or limited ground or water area intended to be used,
either wholly or in part, for the landing or departure of aircraft, and includes all
buildings, sheds, vessels, piers and other structures thereon or pertaining thereto;
(iii) “Air transport service” means a service for the transport by air of persons, mails or any
other thing, animate or inanimate, for any kind of remuneration whatsoever, whether
such service consists of a single flight or series of flights;
(iv) “Air Transport Undertaking” means an undertaking whose business includes the
carriage by air of passengers or cargo for hire or reward;
(v) “Aircraft component” means any part, the soundness and correct functioning of which,
when fitted to an aircraft, is essential to the continued airworthiness or safety of the
aircraft and includes any item of equipment;
(vi) “Helicopter” means a heavier-than-air aircraft supported in flight by the reactions of the
air on one or more power driven rotors on substantially vertical axis;

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 42 -->

41

(vii) “Scheduled air transport service” means an air transport service undertaken between the
same two or more places and operated according to a published time table or with
flights so regular or frequent that they constitute a recognizably systematic series, each
flight being open to use by members of the public;
(viii)“Non-Scheduled air transport service” means any service which is not a scheduled air
transport service;
(ix) “Seaplane” means an aeroplane capable normally of taking off from and alighting solely
on water;
(x)“Ground Handling” means (i) ramp handling, (ii) traffic handling both of which shall
include the activities as specified by the Ministry of Civil Aviation through the
Aeronautical Information Circulars from time to time, and (iii) any other activity
specified by the Central Government to be a part of either ramp handling or traffic
handling.

OTHER CONDITIONS
(a) Air Transport Services would include Domestic Scheduled Passenger Airlines; NonScheduled Air Transport Services, helicopter and seaplane services.
(b) Foreign airlines are allowed to participate in the equity of companies operating Cargo
airlines, helicopter and seaplane services, as per the limits and entry routes mentioned
above.
(c) Foreign airlines are also allowed to invest in the capital of Indian companies, operating
scheduled and non-scheduled air transport services, up to the limit of 49% of their paidup capital. Such investment would be subject to the following conditions:
(i) It would be made under the Government approval route,
(ii) The 49% limit will subsume FDI and FPI investment,
(iii) The investments so made would need to comply with the relevant regulations of
SEBI, such as the Issue of Capital and Disclosure Requirements (ICDR)
Regulations/Substantial Acquisition of Shares and Takeovers (SAST) Regulations,
as well as other applicable rules and regulations,

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 43 -->

42

(iv) All foreign nationals likely to be associated with Indian scheduled and nonscheduled air transport services, as a result of such investment shall be cleared
from security view point before deployment and
(v) All technical equipment that might be imported into India as a result of such
investment shall require clearance from the relevant authority in the Ministry of
Civil Aviation.
(d) In addition to the above conditions, foreign investment in M/s Air India Ltd. shall be
subject to the following conditions:
(i) Foreign investment(s) in M/s Air India Ltd., including that of foreign airline(s)
shall not exceed 49% either directly or indirectly except in case of those NRIs, who
are Indian Nationals, where foreign investment(s) is permitted up to100% under
automatic route.
(ii) Substantial ownership and effective control of M/s Air India Ltd. shall continue to
be vested in Indian Nationals as stipulated in Aircraft Rules, 1937.
(e) FDI in Civil Aviation is subject to provisions of Aircraft Rules, 1937, as amended from
time to time.

NOTE:
(i) The FDI limits/entry routes mentioned at paragraph 5.2.9.2(1) and 5.2.9.2 (2) above, are
applicable in the situation where there is no investment by foreign airline. Any
investment by foreign airlines in companies operating in Air Transport Services,
including in M/s Air India Limited, shall be subject to para (b) and (c) above.
(ii) The dispensation for those NRIs, who are Indian Nationals regarding FDI up to 100%
will also continue in respect of the investment regime specified at para (c) (ii) and (d)
above.

5.2.10 CONSTRUCTION DEVELOPMENT: TOWNSHIPS, HOUSING, BUILT-UP
INFRASTRUCTURE
Sector/Activity

% of Equity/

Entry Route

FDI Cap
5.2.10.1

100%

Automatic

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 44 -->

43

Construction-development projects (which would
include development of townships, construction of
residential/commercial premises, roads or bridges,
hotels, resorts, hospitals, educational institutions,
recreational facilities, city and regional level
infrastructure, townships)

5.2.10.2
Each phase of the construction development project would be considered as a separate
project for the purposes of FDI policy. Investment will be subject to the following conditions:
(A) (i) The investor will be permitted to exit on completion of the project or after
development of trunk infrastructure i.e. roads, water supply, street lighting, drainage
and sewerage.
(ii) Notwithstanding anything contained at (A) (i) above, a foreign investor will be
permitted to exit and repatriate foreign investment before the completion of project
under automatic route, provided that a lock-in-period of three years, calculated with
reference to each tranche of foreign investment has been completed. Further, transfer
of stake from one non-resident to another non-resident, without repatriation of
investment will neither be subject to any lock-in period nor to any government
approval.
(B) The project shall conform to the norms and standards, including land use requirements
and provision of community amenities and common facilities, as laid down in the applicable
building control regulations, bye-laws, rules, and other regulations of the State
Government/Municipal/Local Body concerned.
(C) The Indian investee company will be permitted to sell only developed plots. For the
purposes of this policy “developed plots” will mean plots where trunk infrastructure i.e.
roads, water supply, street lighting, drainage and sewerage, have been made available.
(D) The Indian investee company shall be responsible for obtaining all necessary approvals,
including those of the building/layout plans, developing internal and peripheral areas and
other infrastructure facilities, payment of development, external development and other
charges and complying with all other requirements as prescribed under applicable rules/byelaws/regulations of the State Government/Municipal/Local Body concerned.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 45 -->

44

(E) The State Government/Municipal/Local Body concerned, which approves the
building/development plans, will monitor compliance of the above conditions by the
developer.

NOTE:
(i) It is clarified that FDI is not permitted in an entity which is engaged or proposes to
engage in real estate business, construction of farm houses and trading in transferable
development rights (TDRs).
“Real estate business” means dealing in land and immovable property with a view to
earning profit there from and does not include development of townships, construction
of residential/ commercial premises, roads or bridges, educational institutions,
recreational facilities, city and regional level infrastructure, townships. Further, earning
of rent/ income on lease of the property, not amounting to transfer, will not amount to
real estate business.
(ii) Condition of lock-in period at (A) above will not apply to Hotels &Tourist Resorts,
Hospitals, Special Economic Zones (SEZs), Educational Institutions, Old Age Homes and
investment by NRIs.
(iii)Completion of the project will be determined as per the local bye-laws/rules and other
regulations of State Governments.
(iv) It is clarified that 100% FDI under automatic route is permitted in completed projects for
operation and management of townships, malls/ shopping complexes and business
centres. Consequent to foreign investment, transfer of ownership and/or control of the
investee company from residents to non-residents is also permitted. However, there
would be a lock-in-period of three years, calculated with reference to each tranche of FDI,
and transfer of immovable property or part thereof is not permitted during this period.
(v) “Transfer", in relation to FDI policy on the sector, includes—
(a) the sale, exchange or relinquishment of the asset; or
(b) the extinguishment of any rights therein; or
(c) the compulsory acquisition thereof under any law; or

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 46 -->

45

(d) any transaction involving the allowing of the possession of any immovable
property to be taken or retained in part performance of a contract of the nature
referred to in section 53A of the Transfer of Property Act, 1882 (4 of 1882); or
(e) any transaction, by acquiring shares in a company or by way of any agreement or
any arrangement or in any other manner whatsoever, which has the effect of
transferring, or enabling the enjoyment of, any immovable property.
(vi) Notwithstanding anything contained in Para 5.2.10 above, it is clarified that real-estate
broking service does not amount to real estate business and 100% foreign investment is
allowed in the activity under automatic route.

5.2.11 INDUSTRIAL PARKS
% of Equity/

Sector/Activity

FDI Cap

Industrial Parks -new and existing

100%

Entry Route
Automatic

5.2.11.1 Other conditions for investment in Industrial Parks are at Annexure-7.

5.2.12 SATELLITES- ESTABLISHMENT AND OPERATION
% of Equity/

Sector/Activity

FDI Cap

Satellites- establishment and operation, subject to
the

sectoral

guidelines

of

Department

100%

Entry Route
Government

of

Space/ISRO

5.2.13 PRIVATE SECURITY AGENCIES
Sector/Activity
Private Security Agencies

% of Equity/
FDI Cap
74%

Entry Route
Automatic up to
49%
Government

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 47 -->

46

route beyond
49% and up to
74%

5.2.13.1 OTHER CONDITIONS
(1) FDI in Private Security Agencies is subject to compliance with Private Security Agencies
(Regulation) (PSAR) Act, 2005, as amended from time to time.
(2) For the purposes of FDI policy on the sector, terms “Private Security Agencies”, “Private
Security” and “Armoured Car Service” will have the same meaning as provided under
PSAR Act, 2005, which is reproduced as under:
"Private Security Agency" means a person or body of persons other than a government
agency, department or organisation engaged in the business of providing private security
services including training to private security guards or their supervisor or providing
private security guards to any industrial or business undertaking or a company or any
other person or property;
"Private Security" means security provided by a person, other than a public servant, to
protect or guard any person or property or both and includes provision of armoured car
service;
"Armoured Car Service" means the service provided by deployment of armed guards
along with armoured car and such other related services which may be notified by the
Central Government or as the case may be, the State Government from time to time.

5.2.14 TELECOM SERVICES
% of Equity/

Sector/Activity

FDI Cap

Telecom Services

100%

(including Telecom Infrastructure Providers

Entry Route
Automatic up to
49%

Category-I)
All

telecom

services

including

Telecom

Government

Infrastructure Providers Category-I,

viz. Basic,

route beyond

Cellular, United Access Services, Unified License
(Access

Services),

Unified

49%

License,

National/International Long Distance, Commercial
V-Sat, Public Mobile Radio Trunked Services

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 48 -->

47

(PMRTS), Global Mobile Personal Communications
Services (GMPCS), All types of ISP licenses, Voice
Mail/Audiotex/UMS, Resale of IPLC, Mobile
Number

Portability

Services,

Infrastructure

Provider Category-I (providing dark fibre, right of
way, duct space, tower) except Other Service
Providers.

5.2.14.1 OTHER CONDITION
FDI in Telecom sector is subject to observance of licensing and security conditions by licensee
as well as investors as notified by the Department of Telecommunications (DoT) from time to
time, except “Other Service Providers”, which are allowed 100% FDI on the automatic route.

5.2.15 TRADING
% of Equity/

Sector/Activity

Entry Route

FDI Cap
5.2.15.1

100%

Automatic

Cash & Carry Wholesale Trading/Wholesale
Trading (including sourcing from MSEs)

5.2.15.1.1 DEFINITION: Cash & Carry Wholesale trading/Wholesale trading, would mean
sale of goods/merchandise to retailers, industrial, commercial, institutional or other
professional business users or to other wholesalers and related subordinated service
providers. Wholesale trading would, accordingly, imply sales for the purpose of trade,
business and profession, as opposed to sales for the purpose of personal consumption. The
yardstick to determine whether the sale is wholesale or not would be the type of customers to
whom the sale is made and not the size and volume of sales. Wholesale trading would
include resale, processing and thereafter sale, bulk imports with ex-port/ex-bonded
warehouse business sales and B2B e-Commerce.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 49 -->

48

5.2.15.1.2 GUIDELINES FOR CASH & CARRY WHOLESALE TRADING/WHOLESALE
TRADING (WT):
(a) For undertaking WT, requisite licenses/registration/ permits, as specified under the
relevant Acts/Regulations/Rules/Orders of the State Government/Government
Body/Government Authority/Local Self-Government Body under that State Government
should be obtained.
(b) Except in case of sales to Government, sales made by the wholesaler would be considered
as ‘cash & carry wholesale trading/wholesale trading’ with valid business customers, only
when WT are made to the following entities:
(I) Entities holding applicable tax registration; or
(II) Entities holding trade licenses i.e. a license/registration certificate/membership
certificate/registration under Shops and Establishment Act, issued by a Government
Authority/Government Body/Local Self-Government Authority, reflecting that the
entity/person holding the license/ registration certificate/ membership certificate, as
the case may be, is itself/ himself/herself engaged in a business involving commercial
activity; or
(III) Entities holding permits/license etc. for undertaking retail trade (like tehbazari and
similar license for hawkers) from Government Authorities/Local Self Government
Bodies; or
(IV) Institutions having certificate of incorporation or registration as a society or
registration as public trust for their self-consumption.

Note: An entity, to whom WT is made, may fulfill any one of the 4 conditions at
(b) (I) to (IV) above.
(c) Full records indicating all the details of such sales like name of entity, kind of entity,
registration/license/permit etc. number, amount of sale etc. should be maintained on a day
to day basis.
(d) WT of goods would be permitted among companies of the same group. However, such
WT to group companies taken together should not exceed 25% of the total turnover of the
wholesale venture.
(e)WT can be undertaken as per normal business practice, including extending credit facilities
subject to applicable regulations.
Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 50 -->

49

(f) A wholesale/cash & carry trader can undertake retail trading, subject to the conditions as
applicable. An entity undertaking wholesale/cash and carry as well as retail business will
be mandated to maintain separate books of accounts for these two arms of the business and
duly audited by the statutory auditors. Conditions of the FDI policy for wholesale/cash
and carry business and for retail business have to be separately complied with by the
respective business arms.

5.2.15.2 E-COMMERCE ACTIVITIES
% of Equity/

Sector/Activity

Entry Route

FDI Cap
E-commerce activities

100%

Automatic

5.2.15.2.1 Subject to provisions of FDI Policy, e-commerce entities would engage only in
Business to Business (B2B) e-commerce and not in Business to Consumer (B2C) e-commerce.

5.2.15.2.2 DEFINITIONS:
i) E-commerce- E-commerce means buying and selling of goods and services including digital
products over digital & electronic network.
ii) E-commerce entity- E-commerce entity means a company incorporated under the
Companies Act 1956 or the Companies Act 2013 or a foreign company covered under section
2 (42) of the Companies Act, 2013 or an office, branch or agency in India as provided in
section 2 (v) (iii) of FEMA 1999, owned or controlled by a person resident outside India and
conducting the e-commerce business.
iii) Inventory based model of e-commerce- Inventory based model of e-commerce means an
e-commerce activity where inventory of goods and services is owned by e-commerce entity
and is sold to the consumers directly.
iv) Marketplace based model of e-commerce- Marketplace based model of e-commerce
means providing of an information technology platform by an e-commerce entity on a digital
& electronic network to act as a facilitator between buyer and seller.

5.2.15.2.3 GUIDELINES FOR FOREIGN DIRECT INVESTMENT ON E-COMMERCE SECTOR
i) 100% FDI under automatic route is permitted in marketplace model of e-commerce.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 51 -->

50

ii) FDI is not permitted in inventory-based model of e-commerce.

5.2.15.2.4 OTHER CONDITIONS
i) Digital & electronic network will include network of computers, television channels and
any other internet application used in automated manner such as web pages, extranets,
mobiles etc.
ii) Marketplace e-commerce entity will be permitted to enter into transactions with sellers
registered on its platform on B2B basis.
iii)E-commerce marketplace may provide support services to sellers in respect of
warehousing, logistics, order fulfillment, call centre, payment collection and other services.
iv) E-commerce entity providing a marketplace will not exercise ownership or control over
the inventory i.e. goods purported to be sold. Such an ownership or control over the
inventory will render the business into inventory-based model. Inventory of a vendor will
be deemed to be controlled by e-commerce marketplace entity if more than 25% of
purchases of such vendor are from the marketplace entity or its group companies.

v) An entity having equity participation by e-commerce marketplace entity or its group
companies, or having control on its inventory by e-commerce marketplace entity or its
group companies, will not be permitted to sell its products on the platform run by such
marketplace entity.
vi) In marketplace model goods/services made available for sale electronically on website
should clearly provide name, address and other contact details of the seller. Post sales,
delivery of goods to the customers and customer satisfaction will be responsibility of the
seller.
vii) In marketplace model, payments for sale may be facilitated by the e-commerce entity in
conformity with the guidelines of the Reserve Bank of India.
viii) In marketplace model, any warrantee/ guarantee of goods and services sold will be
responsibility of the seller.

ix) E-commerce entities providing marketplace will not directly or indirectly influence
the sale price of goods or services and shall maintain level playing field. Services
should be provided by e-commerce marketplace entity or other entities in which ecommerce marketplace entity has direct or indirect equity participation or common

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 52 -->

51

control, to vendors on the platform at arm's length and in a fair and non-discriminatory manner. Such services will include but not limited to fulfilment,
logistics, warehousing, advertisement/ marketing, payments, financing etc. Cash back
provided by group companies of marketplace entity to buyers shall be fair and nondiscriminatory. For the purposes of this clause, provision of services to any vendor on
such terms which are not made available to other vendors in similar circumstances
will be deemed unfair and discriminatory.
x) Guidelines on cash and carry wholesale trading as given in para 5.2.15.1.2 above will
apply on B2B e-commerce.

xi) e-commerce marketplace entity will not mandate any seller to sell any product
exclusively on its platform only.
xii) E-commerce marketplace entity with FDI shall have to obtain and maintain a report
of statutory auditor by 30th of September every year for the preceding financial year
confirming compliance of the e-commerce guidelines.
Subject to the conditions of FDI policy on services sector and applicable laws/regulations,
security and other conditionalities, sale of services through e-commerce will be under
automatic route.

5.2.15.3 SINGLE BRAND PRODUCT RETAIL TRADING
Sector/Activity

% of Equity/

Entry Route

FDI Cap
Single Brand Product Retail Trading

100%

Automatic

(1) Foreign Investment in Single Brand product retail trading is aimed at attracting
investments in production and marketing, improving the availability of such goods for the
consumer, encouraging increased sourcing of goods from India, and enhancing
competitiveness of Indian enterprises through access to global designs, technologies and
management practices.
(2) FDI in Single Brand product retail trading would be subject to the following conditions:
(a) Products to be sold should be of a ‘Single Brand’ only.
Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 53 -->

52

(b) Products should be sold under the same brand internationally i.e. products should be
sold under the same brand in one or more countries other than India.
(c) ‘Single Brand’ product-retail trading would cover only products which are branded
during manufacturing.
(d) A non-resident entity or entities, whether owner of the brand or otherwise, shall be
permitted to undertake ‘single brand’ product retail trading in the country for the
specific brand, either directly by the brand owner or through a legally tenable agreement
executed between the Indian entity undertaking single brand retail trading and the
brand owner.
(e) In respect of proposals involving foreign investment beyond 51%, sourcing of 30% of the
value of goods purchased, will be done from India, preferably from MSMEs, village and
cottage industries, artisans and craftsmen, in all sectors. The quantum of domestic
sourcing will be self-certified by the company, to be subsequently checked, by statutory
auditors, from the duly certified accounts which the company will be required to
maintain. This procurement requirement would have to be met, in the first instance, as
an average of five years’ total value of the goods procured, beginning 1st April of the
year of the commencement of SBRT business (i.e. opening of the first store or start of
online retail, whichever is earlier). Thereafter, SBRT entity shall be required to meet the
30% local sourcing norms on an annual basis. For the purpose of ascertaining the
sourcing requirement, the relevant entity would be the company, incorporated in India,
which is the recipient of foreign investment for the purpose of carrying out single-brand
product retail trading.
(f) For the purpose of meeting local sourcing requirement laid down at para (e) above, all
procurements made from India by the SBRT entity for that single brand shall be
counted towards local sourcing, irrespective of whether the goods procured are sold in
India or exported. SBRT entity is also permitted to set off sourcing of goods from India
for global operations against the mandatory sourcing requirement of 30%. For this
purpose, ‘sourcing of goods from India for global operations’ shall mean value of goods
sourced from India for global operations for that single brand (in INR terms) in a
particular financial year directly by the entity undertaking SBRT or its group companies

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 54 -->

53

(resident or non-resident), or indirectly by them through a third party under a legally
tenable agreement.
(g) An SBRT entity operating through brick and mortar stores can also undertake retail
trading through e-commerce. However, retail trading through e-commerce can also be
undertaken prior to opening of brick and mortar stores, subject to the condition that the
entity opens brick and mortar stores within 2 years from date of start of online retail.

NOTE:
(i) Conditions mentioned at Para 5.2.15.3 (2) (b) & 5.2.15.3 (2) (d) will not be applicable for
undertaking SBRT of Indian brands.
(ii) Indian brands should be owned and controlled by resident Indian citizens and/or
companies which are owned and controlled by resident Indian citizens.
(iii)Sourcing norms will not be applicable up to three years from commencement of the
business i.e. opening of the first store or start of online retail, whichever is earlier for
entities undertaking single brand retail trading of products having ‘state-of-art’ and
‘cutting-edge’ technology and where local sourcing is not possible. Thereafter,
provisions of Para 5.2.15.3 (2) (e) will be applicable. A Committee under the
Chairmanship of Secretary, DPIIT, with representatives from NITI Aayog, concerned
Administrative Ministry and independent technical expert(s) on the subject will examine
the claim of applicants on the issue of the products being in the nature of ‘state-of-art’
and ‘cutting-edge’ technology where local sourcing is not possible and give
recommendations for such relaxation.

5.2.15.4 MULTI BRAND RETAIL TRADING
Sector/Activity

% of Equity/

Entry Route

FDI Cap
Multi Brand Retail Trading

51%

Government

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 55 -->

54

(1) FDI in multi brand retail trading, in all products, will be permitted, subject to the
following conditions:
(i) Fresh agricultural produce, including fruits, vegetables, flowers, grains, pulses, fresh
poultry, fishery and meat products, may be unbranded.
(ii) Minimum amount to be brought in, as FDI, by the foreign investor, would be US $ 100
million.
(iii)At least 50% of total FDI brought in the first tranche of US $ 100 million, shall be invested
in 'back-end infrastructure' within three years, where ‘back-end infrastructure’ will
include capital expenditure on all activities, excluding that on front-end units; for
instance, back-end infrastructure will include investment made towards processing,
manufacturing, distribution, design improvement, quality control, packaging, logistics,
storage, ware-house, agriculture market produce infrastructure etc. Expenditure on land
cost and rentals, if any, will not be counted for purposes of backend infrastructure.
Subsequent investment in backend infrastructure would be made by the MBRT retailer as
needed, depending upon its business requirements.
(iv) At least 30% of the value of procurement of manufactured/processed products
purchased shall be sourced from Indian micro, small and medium industries, which have
a total investment in plant & machinery not exceeding US $ 2.00 million. This valuation
refers to the value at the time of installation, without providing for depreciation. The
‘small industry’ status would be reckoned only at the time of first engagement with the
retailer, and such industry shall continue to qualify as a ‘small industry’ for this purpose,
even if it outgrows the said investment of US $ 2.00 million during the course of its
relationship with the said retailer. Sourcing from agricultural co-operatives and farmers
co-operatives would also be considered in this category. The procurement requirement
would have to be met, in the first instance, as an average of five years’ total value of the
manufactured/processed products purchased, beginning 1st April of the year during
which the first tranche of FDI is received. Thereafter, it would have to be met on an
annual basis.
(v) Self-certification by the company, to ensure compliance of the conditions at serial nos. (ii),
(iii) and (iv) above, which could be cross-checked, as and when required. Accordingly,
the investors shall maintain accounts, duly certified by statutory auditors.
(vi) Retail sales outlets may be set up only in cities with a population of more than 10 lakh as
per 2011 Census or any other cities as per the decision of the respective State
Governments, and may also cover an area of 10 kms around the municipal/urban
agglomeration limits of such cities; retail locations will be restricted to conforming areas

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 56 -->

55

as per the Master/Zonal Plans of the concerned cities and provision will be made for
requisite facilities such as transport connectivity and parking.
(vii) Government will have the first right to procurement of agricultural products.
(viii) The above policy is an enabling policy only and the State Governments/Union
Territories would be free to take their own decisions in regard to implementation of the
policy. Therefore, retail sales outlets may be set up in those States/Union Territories
which have agreed, or agree in future, to allow FDI in MBRT under this policy. The list of
States/Union Territories which have conveyed their agreement is at (2) below. Such
agreement, in future, to permit establishment of retail outlets under this policy, would be
conveyed to the Government of India through the Department for Promotion of Industry
and Internal Trade and additions would be made to the list at (2) below accordingly. The
establishment of the retail sales outlets will be in compliance of applicable State/Union
Territory laws/ regulations, such as the Shops and Establishments Act etc.
(ix) Retail trading, in any form, by means of e-commerce, would not be permissible, for
companies with FDI, engaged in the activity of multi-brand retail trading.
(2) List of States/Union Territories as mentioned in Paragraph 5.2.15.4(1)(viii)
1. Andhra Pradesh
2. Assam
3. Delhi
4. Haryana
5. Himachal Pradesh
6. Jammu & Kashmir
7. Karnataka
8. Maharashtra
9. Manipur
10.Rajasthan
11.Uttarakhand
12.Daman & Diu and Dadra and Nagar Haveli (Union Territories)

5.2.15.5 DUTY FREE SHOPS
Sector/Activity

% of Equity/

Entry Route

FDI Cap
Duty Free Shops

100%

Automatic

(i) Duty Free Shops would mean shops set up in custom bonded area at International

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 57 -->

56

Airports/International Seaports and Land Custom Stations where there is transit of
international passengers.
(ii) Foreign investment in Duty Free Shops is subject to compliance of conditions
stipulated under the Customs Act, 1962 and other laws, rules and regulations.
(iii) Duty Free Shop entity shall not engage into any retail trading activity in the
Domestic Tariff Area of the country.

5.2.16 RAILWAY INFRASTRUCTURE
% of Equity/

Sector/Activity

FDI Cap

Railway Infrastructure

100%

Entry Route
Automatic

Construction, operation and maintenance of the
following:
(i) Suburban corridor projects through PPP, (ii)
High speed train projects, (iii) Dedicated freight
lines, (iv) Rolling stock including train sets, and
locomotives/coaches

manufacturing

and

maintenance facilities, (v) Railway Electrification,
(vi) Signaling systems, (vii) Freight terminals, (viii)
Passenger terminals, (ix) Infrastructure in industrial
park pertaining to railway line/sidings including
electrified railway lines and connectivities to main
railway

line and (x)

Mass Rapid Transport

Systems.

NOTE:
(i) Foreign Direct Investment in the abovementioned activities open to private sector
participation including FDI is subject to sectoral guidelines of Ministry of Railways.
(ii)Proposals involving FDI beyond 49% in sensitive areas from security point of view,
will be brought by the Ministry of Railways before the Cabinet Committee on Security
(CCS) for consideration on a case to case basis.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 58 -->

57

FINANCIAL SERVICES
Foreign investment in other financial services, other than those indicated below, would
require prior approval of the Government.

5.2.17 ASSET RECONSTRUCTION COMPANIES
% of Equity/

Sector/Activity

Entry Route

FDI Cap
5.2.17.1‘Asset Reconstruction Company’ (ARC)

100%

Automatic

means a company registered with the Reserve
Bank of India under Section 3 of the Securitisation
and Reconstruction of Financial Assets and
Enforcement of Security Interest Act, 2002
(SARFAESI Act).

5.2.17.2 OTHER CONDITIONS
(i) Persons resident outside India can invest in the capital of Asset Reconstruction
Companies (ARCs) registered with Reserve Bank of India, up to 100% on the automatic
route.
(ii) Investment limit of a sponsor in the shareholding of an ARC will be governed by the
provisions of Securitisation and Reconstruction of Financial Assets and Enforcement of
Security Interest Act, 2002, as amended from time to time. Similarly, investment by
institutional / non-institutional investors will also be governed by the said Act, as
amended from time to time.
(iii) The total shareholding of an individual FPI shall be below 10% of the total paid-up
capital.
(iv) FPIs can invest in the Security Receipts (SRs) issued by ARCs. /FPIs may be allowed to
invest up to 100 per cent of each tranche in SRs issued by ARCs, subject to
directions/guidelines of Reserve Bank of India. Such investment should be within the
relevant regulatory cap as applicable.
(v) All investments would be subject to provisions of the Securitisation and Reconstruction
of Financial Assets and Enforcement of Security Interest Act, 2002, as amended from
time to time.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 59 -->

58

5.2.18 BANKING- PRIVATE SECTOR
% of Equity

Sector/Activity

FDI Cap

5.2.18.1

74%

Entry Route
Automatic up
to 49%

Banking- Private Sector

Government
route beyond
49% and up
to 74%.

5.2.18.2 OTHER CONDITIONS
(1) This 74% limit will include investment under the Portfolio Investment Scheme (PIS) by
/FPIs, NRIs and shares acquired prior to September 16, 2003 by erstwhile OCBs, and
continue to include IPOs, Private placements, GDR/ADRs and acquisition of shares
from existing shareholders.
(2) The aggregate foreign investment in a private bank from all sources will be allowed up
to a maximum of 74 per cent of the paid-up capital of the Bank. At all times, at least 26
per cent of the paid-up capital will have to be held by residents, except in regard to a
wholly-owned subsidiary of a foreign bank.
(3) The stipulations as above will be applicable to all investments in existing private sector
banks also.
(4) Other conditions in respect of permissible limits under portfolio investment schemes
through stock exchanges for /FPIs and NRIs, setting-up of a subsidiary by foreign banks
and limits in respect of voting rights are at Annexure-8.

5.2.19 BANKING- PUBLIC SECTOR
% of Equity/

Sector/Activity

Entry Route

FDI Cap
5.2.19.1 Banking- Public Sector subject to Banking
Companies

(Acquisition

&

Transfer

20%

Government

of

Undertakings) Acts 1970/80. This ceiling (20%) is

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 60 -->

59

also applicable to the State Bank of India and its
associate Banks.

5.2.20 CREDIT INFORMATION COMPANIES (CIC)
% of Equity/

Sector/Activity

FDI Cap

Entry Route

5.2.20.1
Credit Information Companies

100%

Automatic

5.2.20.2 OTHER CONDITIONS
(1) Foreign investment in Credit Information Companies is subject to the Credit Information
Companies (Regulation) Act, 2005.
(2) Foreign investment is permitted subject to regulatory clearance from RBI.
(3) Such /FPI investment would be permitted subject to the conditions that:
(a) A single entity should directly or indirectly hold below 10% equity.
(b) Any acquisition in excess of 1% will have to be reported to RBI as a mandatory
requirement; and
(c) /FPIs investing in CICs shall not seek a representation on the Board of Directors
based upon their shareholding.

5.2.21 INFRASTRUCTURE COMPANY IN THE SECURITIES MARKET
% of Equity

Sector/Activity

FDI Cap

5.2.21.1 Infrastructure companies in Securities

49%

Entry Route
Automatic

Markets, namely, stock exchanges, commodity
exchanges, depositories and clearing corporations,
in compliance with SEBI Regulations

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 61 -->

60

5.2.21.2 OTHER CONDITIONS
(i) Foreign investment, including investment by FPIs, will be subject to the Securities
Contracts (Regulations) (Stock Exchanges and Clearing Corporations) Regulations 2012, and
Securities and Exchange Board of India (Depositories and Participants) Regulations, 1996 as
amended from time to time, and other Guidelines/Regulations issued by the Central
Government, SEBI and the Reserve Bank of India from time to time.
(ii) Words and expressions used herein and not defined in these regulations but defined in
the Companies Act, 2013 (18 of 2013) or the Securities Contracts (Regulation) Act, 1956 (42 of
1956) or the Securities and Exchange Board of India Act, 1992 (15 of 1992) or the Depositories
Act, 1996 (22 of 1996) or in the concerned Regulations issued by SEBI shall have the same
meanings respectively assigned to them in those Acts/ Regulations.

DEFINITIONS:
(1) Futures trading in commodities are regulated under the Forward Contracts (Regulation)
Act, 1952. Commodity Exchanges, like Stock Exchanges, are infrastructure companies in the
commodity futures market. With a view to infuse globally acceptable best practices, modern
management skills and latest technology, it was decided to allow foreign investment in
Commodity Exchanges.
(2) For the purposes of this chapter,
(i)“Commodity Exchange” is a recognized association under the provisions of the
Forward Contracts (Regulation) Act, 1952, as amended from time to time, to provide
exchange platform for trading in forward contracts in commodities.
(ii) “recognized association” means an association to which recognition for the time being
has been granted by the Central Government under Section 6 of the Forward
Contracts (Regulation) Act, 1952
(iii)“Association” means any-body of individuals, whether incorporated or not,
constituted for the purposes of regulating and controlling the business of the sale or
purchase of any goods and commodity derivative.
(iv)“Forward contract” means a contract for the delivery of goods and which is not a
ready delivery contract.
(v) “Commodity derivative” means-

 a contract for delivery of goods, which is not a ready delivery contract; or
Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 62 -->

61

 a contract for differences which derives its value from prices or indices of prices of
such underlying goods or activities, services, rights, interests and events, as may be
notified in consultation with SEBI by the Central Government, but does not include
securities.

5.2.22 INSURANCE
% of Equity/

Sector/Activity

FDI Cap

5.2.22.1

Entry Route

49%

Automatic

100%

Automatic

Insurance Company
5.2.22.2
Intermediaries

or

Insurance

Intermediaries

including insurance brokers, re-insurance
brokers,

insurance

consultants,

corporate

agents, third party administrator, Surveyors
and Loss Assessors and such other entities, as
may be notified by the Insurance Regulatory
and Development Authority of India from time
to time.
5.2.22.3 OTHER CONDITIONS
(a) No Indian Insurance company shall allow the aggregate holdings by way of total foreign
investment in its equity shares by foreign investors, including portfolio investors, to
exceed forty-nine percent of the paid-up equity capital of such Indian Insurance
company.
(b) The foreign investment up to forty-nine percent of the total paid-up equity of the Indian
Insurance Company shall be allowed on the automatic route subject to
approval/verification by the Insurance Regulatory and Development Authority of India.
(c) Foreign investment in this sector shall be subject to compliance with the provisions of
the Insurance Act, 1938 and the condition that Companies receiving FDI shall obtain
necessary license /approval from the Insurance Regulatory & Development Authority of
India for undertaking insurance and related activities.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 63 -->

62

(d) An Indian Insurance company shall ensure that its ownership and control remains at all
times in the hands of resident Indian entities as determined by Department of Financial
Services/ Insurance Regulatory and Development Authority of India as per the
rules/regulation issued by them from time to time.
(e) Foreign portfolio investment in an Indian Insurance company shall be governed by the
provisions contained in Chapter-IV, Rule 10 and 11 read with Schedule II of Foreign
Exchange Management (Non-Debt Instruments) Rules, 2019 and provisions of the
Securities and Exchange Board of India (Foreign Portfolio Investors) Regulations, 2019.
(f)

Any increase in foreign investment in an Indian Insurance company shall be in
accordance with the pricing guidelines specified by Reserve Bank of India under the
FEMA Regulations.

(g) The foreign equity investment cap of 100 percent shall apply on the same terms as above
to insurance brokers, re-insurance brokers, insurance consultants, corporate agents, third
party administrator, Surveyors and Loss Assessors and such other entities, as may be
notified by the Insurance Regulatory and Development Authority of India from time to
time. However, the condition of Indian owned and controlled, as specified in Clause (d)
above, shall not be applicable to Intermediaries and Insurance Intermediaries and
composition of the Board of Directors and key management persons shall be as specified
by the concerned regulators from time to time.
(h) The foreign direct investment proposals shall be allowed under the automatic route
subject to verification by the Authority and the foreign investment in intermediaries or
insurance intermediaries shall be governed by the same terms as provided under rules 7
and 8 of the Indian Insurance Companies (Foreign Investment) Rules, 2015, as amended
from time to time:
Provided that where an entity like a bank, whose primary business is outside the
insurance area, is allowed by the Insurance Regulatory and Development Authority of
India to function as an insurance intermediary, the foreign equity investment caps
applicable in that sector shall continue to apply, subject to the condition that the
revenues of such entities from their primary (i.e., non-insurance related) business must
remain above 50 percent of their total revenues in any financial year.
(i) The insurance intermediary that has majority shareholding of foreign investors shall
undertake the following:
i. be incorporated as a limited company under the provisions of the Companies Act,
2013;
ii. at least one from among the Chairman of the Board of Directors or the Chief
Executive Officer or Principal Officer or Managing Director of the insurance
intermediary shall be a resident Indian citizen;
iii. shall take prior permission of the Authority for repatriating dividend;

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 64 -->

63

iv. shall bring in the latest technological, managerial and other skills;
v. shall not make payments to the foreign group or promoter or subsidiary or
interconnected or associate entities beyond what is necessary or permitted by the
Authority;
vi. shall make disclosures in the formats to be specified by the Authority of all
payments made to its group or promoter or subsidiary or interconnected or
associate entities;
vii. composition of the Board of Directors and key management persons shall be as
specified by the concerned regulators;
(j)

The provisions of paragraphs (i) (b) and (d) of Annexure 8 relating to ‘Banking-Private
Sector’, shall be applicable in respect of bank promoted insurance companies.

(k) Terms ‘Control’, ‘Equity Share Capital’, ‘Foreign Direct Investment’ (FDI), ‘Foreign
Investors’, ‘Foreign Portfolio Investment’, ‘Indian Insurance Company’, ‘Indian
Company’, ‘Indian Control of an Indian Insurance Company’, ‘Indian Ownership’,
‘Non-resident Entity’, ‘Public Financial Institution’, ‘Resident Indian Citizen’, ‘Total
Foreign Investment’ will have the same meaning as provided in Notification No. G.S.R
115 (E), dated 19th February, 2015 issued by Department of Financial Services and
regulations issued by Insurance Regulatory and Development Authority of India from
time to time.

5.2.23 PENSION SECTOR
% of Equity/

Sector/Activity

FDI Cap

Pension Sector

49%

Entry Route
Automatic

OTHER CONDITIONS
(i) Foreign investment in the Pension Funds is allowed as per the Pension Fund Regulatory
and Development Authority (PFRDA) Act, 2013.
(ii) Foreign Investment in Pension Funds will be subject to the condition that entities
bringing in foreign equity investment as per Section 24 of the PFRDA Act shall obtain
necessary registration from the Pension Fund Regulatory and Development Authority
and comply with other requirements as per the PFRDA Act, 2013 and Rules and
Regulations framed under it for so participating in Pension Fund Management activities
in India.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 65 -->

64

(iii) An Indian pension fund shall ensure that its ownership and control remains at all times
in the hands of resident Indian entities as determined by the Government of
India/PFRDA as per the rules/regulation issued by them from time to time.

5.2.24 POWER EXCHANGES
% of Equity/

Sector/Activity

FDI Cap

5.2.24.1

49%

Entry Route
Automatic

Power Exchanges registered under the Central
Electricity Regulatory Commission (Power Market)
Regulations, 2010.

5.2.24.2 OTHER CONDITIONS
(i) No non-resident investor/entity, including persons acting in concert, will hold more than
5% of the equity in these companies; and
(ii) The foreign investment would be in compliance with SEBI Regulations; other applicable
laws/regulations; security and other conditionalities.

5.2.25 WHITE LABEL ATM OPERATIONS
Sector/Activity
White Label ATM Operations

% of Equity/
FDI Cap
100%

Entry Route
Automatic

OTHER CONDITIONS
(i)

Any non-bank entity intending to set up WLAs should have a minimum net worth of Rs.
100 crore as per the latest financial year’s audited balance sheet, which is to be
maintained at all times.

(ii) In case the entity is also engaged in any ‘Other Financial Services’ as laid down at Para
5.2.26 below, then the foreign investment in the company setting up WLA, shall also
have to comply with the minimum capitalization norms, if any, for foreign investments
in such ‘Other Financial Services’.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 66 -->

65

(iii) FDI in the WLAO will be subject to the specific criteria and guidelines issued by RBI
vide Circular No. DPSS.CO.PD.No. 2298/02.10.002/2011-2012, as amended from time to
time.

5.2.26 OTHER FINANCIAL SERVICES
% of Equity/

Sector/Activity

FDI Cap

5.2.26.1

100%

Entry Route
Automatic

Financial Services activities regulated by financial
sector regulators, viz., RBI, SEBI, IRDA, PFRDA,
NHB or any other financial sector regulator as
may be notified by the Government of India.

5.2.26.2 OTHER CONDITIONS
i.

Foreign investment in 'Other Financial Services' activities shall be subject to
conditionalities, including minimum capitalization norms, as specified by the concerned
Regulator/Government Agency.
ii. ‘Other Financial Services' activities need to be regulated by one of the Financial Sector
Regulators. In all such financial services activity which are not regulated by any
Financial Sector Regulator or where only part of the financial services activity is
regulated or where there is doubt regarding the regulatory oversight, foreign investment
up to 100% will be allowed under Government approval route subject to conditions
including minimum capitalization as may be decided by the Government.
iiii. Any activity which is specifically regulated by an Act, the foreign investment limits will
be restricted to those levels/limit that may be specified in that Act, if so mentioned.
iv. Downstream investments by any of these entities engaged in "Other Financial Services"
will be subject to the extant sectoral regulations and provisions of Foreign Exchange
Management (Transfer or Issue of Security by a Person Resident outside India)
Regulations, 2000, as amended from time to time.

OTHERS
5.2.27 PHARMACEUTICALS
Sector/Activity

% of Equity/
FDI Cap

Entry Route

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 67 -->

66

5.2.27.1

100%

Automatic

100%

Automatic up

Greenfield
5.2.27.2
Brownfield

to 74%
Government
route beyond
74%

5.2.27.3 OTHER CONDITIONS
(i) ‘Non-compete’ clause would not be allowed in automatic or government approval route
except in special circumstances with the approval of the Government.
(ii) The prospective investor and the prospective investee are required to provide a certificate
along with the application for foreign investment as per Annexure-9.
(iii) Government may incorporate appropriate conditions for FDI in brownfield cases, at the
time of granting approval.
(iv) FDI in brownfield pharmaceuticals, under both automatic and government approval
routes, is further subject to compliance of following conditions:
(a) The production level of National List of Essential Medicines (NLEM) drugs and/or
consumables and their supply to the domestic market at the time of induction of FDI,
being maintained over the next five years at an absolute quantitative level. The
benchmark for this level would be decided with reference to the level of production of
NLEM drugs and/or consumables in the three financial years, immediately preceding
the year of induction of FDI. Of these, the highest level of production in any of these
three years would be taken as the level.
(b) R&D expenses being maintained in value terms for 5 years at an absolute quantitative
level at the time of induction of FDI. The benchmark for this level would be decided
with reference to the highest level of R&D expenses which has been incurred in any of
the three financial years immediately preceding the year of induction of FDI.
(c) The administrative Ministry will be provided complete information pertaining to the
transfer of technology, if any, along with induction of foreign investment into the
investee company.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 68 -->

67

(d) The administrative Ministry (s) i.e. Ministry of Health and Family Welfare, Department
of Pharmaceuticals or any other regulatory Agency/Development as notified by Central
Government from time to time, will monitor the compliance of conditionalities.

NOTE:
i. FDI up to 100%, under the automatic route is permitted for manufacturing of medical
devices. The above mentioned conditions will, therefore, not be applicable to greenfield
as well as brownfield projects of this industry.
ii.

Medical device means (a) any instrument, apparatus, appliance, implant, material or other article, whether
used alone or in combination, including the software, intended by its manufacturer
to be used specially for human beings or animals for one or more of the specific
purposes of (i) diagnosis, prevention, monitoring, treatment or alleviation of any disease or
disorder;
(ii) diagnosis, monitoring, treatment, alleviation or assistance for, any injury or
disability;
(iii)investigation, replacement or modification or support of the anatomy or of a
physiological process;
(iv) supporting or sustaining life;
(v) disinfection of medical devices;
(vi) control of conception,
(vii) and which does not achieve primary intended action in or on the human body
or animals by any pharmacological or immunological or metabolic means, but
which may be assisted in its intended function by such means;
(b) an accessory to such an instrument, apparatus, appliance, material or other
article;
(c) in-vitro diagnostic device which is a reagent, reagent product, calibrator, control
material, kit, instrument, apparatus, equipment or system, whether used alone or in
combination thereof intended to be used for examination and providing information
for medical or diagnostic purposes by means of examination of specimens derived
from the human bodies or animals.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 69 -->

68

ANNEXURES
Annexure-1
Types of Instruments
1.

Indian companies can issue equity shares, fully, compulsorily and mandatorily convertible
debentures and fully, compulsorily and mandatorily convertible preference shares subject
to pricing guidelines/valuation norms prescribed under FEMA Regulations. The
price/conversion formula of convertible capital instruments should be determined upfront
at the time of issue of the instruments. The price at the time of conversion should not in
any case be lower than the fair value worked out, at the time of issuance of such
instruments, in accordance with the extant FEMA rules/regulations [as per any
internationally accepted pricing methodology on arm’s length basis for the unlisted
companies and valuation in terms of SEBI (ICDR) Regulations, for the listed companies].

1.1 Optionality clauses are allowed in equity shares, fully, compulsorily and mandatorily
convertible debentures and fully, compulsorily and mandatorily convertible preference
shares under FDI scheme, subject to the following conditions:
(a) There is a minimum lock-in period of one year which shall be effective from the date of
allotment of such capital instruments.
(b) After the lock-in period and subject to FDI Policy provisions, if any, the non-resident
investor exercising option/right shall be eligible to exit without any assured return, as per
pricing/valuation guidelines issued under FEMA from time to time.
2.

Other types of Preference shares/Debentures i.e. non-convertible, optionally convertible
or partially convertible for issue of which funds have been received on or after May 1, 2007
are considered as debt. Accordingly, all norms applicable for ECBs relating to eligible
borrowers, recognized lenders, amount and maturity, end-use stipulations, etc. shall
apply. Since these instruments would be denominated in rupees, the rupee interest rate
will be based on the swap equivalent of London Interbank Offered Rate (LIBOR) plus the
spread as permissible for ECBs of corresponding maturity.

3.

The inward remittance received by the Indian company vide issuance of DRs and FCCBs
are treated as FDI and counted towards FDI.

4.

Acquisition of Warrants and Partly Paid Shares - An Indian Company may issue
warrants and partly paid shares to a person resident outside India subject to terms and
conditions as stipulated by the Reserve Bank of India in this behalf, from time to time.

5.

Issue of Foreign Currency Convertible Bonds (FCCBs) and Depository Receipts (DRs)

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 70 -->

69

a) FCCBs/DRs may be issued in accordance with the Scheme for issue of Foreign
Currency Convertible Bonds and Ordinary Shares (Through Depository Receipt
Mechanism) Scheme, 1993 and DR Scheme 2014 respectively, as per the guidelines
issued by the Government of India there under from time to time.
b) DRs are foreign currency denominated instruments issued by a foreign Depository in a
permissible jurisdiction against a pool of permissible securities issued or transferred to
that foreign depository and deposited with a domestic custodian.
c) In terms of Foreign Exchange Management (Non-Debt Instruments) Rules, 2019 as
amended from time to time, a person will be eligible to issue or transfer eligible
securities to a foreign depository, for the purpose of converting the securities so
purchased into depository receipts in terms of Depository Receipts Scheme, 2014 and
guidelines issued by the Government of India thereunder from time to time.
d) A person can issue DRs, if it is eligible to issue eligible instruments to person resident
outside India under relevant Schedules under Foreign Exchange Management (NonDebt Instruments) Rules, 2019, as amended from time to time.
e) The aggregate of eligible securities which may be issued or transferred to foreign
depositories, along with eligible securities already held by persons resident outside
India, shall not exceed the limit on foreign holding of such eligible securities under the
relevant regulations framed under FEMA, 1999.
f) The pricing of eligible securities to be issued or transferred to a foreign depository for
the purpose of issuing depository receipts should not be at a price less than the price
applicable to a corresponding mode of issue or transfer of such securities to domestic
investors under the relevant regulations framed under FEMA, 1999.
g) The issue of depository receipts as per DR Scheme 2014 shall be reported to the
Reserve Bank by the domestic custodian as per the reporting guidelines for DR Scheme
2014.
6. (i) Two-way Fungibility Scheme: A limited two-way Fungibility scheme has been put in
place by the Government of India for ADRs/GDRs. Under this Scheme, a stock broker in
India, registered with SEBI, can purchase shares of an Indian company from the market for
conversion into ADRs/GDRs based on instructions received from overseas investors. Reissuance of ADRs/GDRs would be permitted to the extent of ADRs/GDRs which have
been redeemed into underlying shares and sold in the Indian market.
(ii) Sponsored ADR/GDR issue: An Indian company can also sponsor an issue of ADR/GDR.
Under this mechanism, the company offers its resident shareholders a choice to submit
their shares back to the company so that on the basis of such shares, ADRs/GDRs can be
issued abroad. The proceeds of the ADR/GDR issue are remitted back to India and

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 71 -->

70

distributed among the resident investors who had offered their Rupee denominated shares
for conversion. These proceeds can be kept in Resident Foreign Currency (Domestic)
accounts in India by the resident shareholders who have tendered such shares for
conversion into ADRs/GDRs.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 72 -->

71

Annexure-2
Provisions Relating to Issue/ Transfer of Shares
1.

The capital instruments should be issued within 60 days from the date of receipt of the
inward remittance received through normal banking channels including escrow
account opened and maintained for the purpose or by debit to the NRE/FCNR (B)
account of the non-resident investor. In case, the capital instruments are not issued
within 60 days from the date of receipt of the inward remittance or date of debit to the
NRE/FCNR (B) account, the amount of consideration so received should be refunded
within fifteen days from the date of completion of sixty days to the non-resident
investor by outward remittance through normal banking channels or by credit to the
NRE/FCNR (B) account, as the case may be. Non-compliance with the above
provision would be reckoned as a contravention under FEMA and would attract penal
provisions. In exceptional cases, delay in refund of the amount of consideration may
be considered by the RBI, on the merits of the case.

2.

Issue price of shares
Price of shares issued to persons resident outside India under the FDI Policy, shall not
be less than –
a. the price worked out in accordance with the SEBI guidelines, as applicable, where
the shares of the company are listed on any recognised stock exchange in India;
b. the fair valuation of shares done by a SEBI registered Merchant Banker or a
Chartered Accountant as per any internationally accepted pricing methodology on
arm’s length basis, where the shares of the company are not listed on any
recognised stock exchange in India; and
c. the price as applicable to transfer of shares from resident to non-resident as per the
pricing guidelines laid down by the Reserve Bank from time to time, where the
issue of shares is on preferential allotment.
However, where non-residents (including NRIs) are making investments in an Indian
company in compliance with the provisions of the Companies Act, as applicable, by
way of subscription to its Memorandum of Association, such investments may be
made at face value subject to their eligibility to invest under the FDI scheme.

3.

Foreign Currency Account
Indian companies which are eligible to issue shares to persons resident outside India
under the FDI Policy may be allowed to retain the share subscription amount in a
Foreign Currency Account, in accordance with RBI guidelines..

4.
(i)

Transfer of shares and convertible debentures
Subject to FDI sectoral policy (relating to sectoral caps and entry routes), applicable
laws and other conditionalities including security conditions, non-resident investors

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 73 -->

72

can also invest in Indian companies by purchasing/acquiring existing shares from
Indian shareholders or from other non-resident shareholders. General permission has
been granted to non-residents/NRIs for acquisition of shares by way of transfer
subject to the following:
(a) A person resident outside India (other than NRI and erstwhile OCB) may
transfer by way of sale or gift, the shares or convertible debentures to any person
resident outside India (including NRIs). Government approval is not required
for transfer of shares in the investee company from one non-resident to another
non-resident in sectors which are under automatic route. In addition, approval of
Government will be required for transfer of stake from one non-resident to
another non-resident in sectors which are under Government approval route.
(b)

NRIs may transfer by way of sale or gift the shares or convertible debentures
held by them to another NRI.

(c)

A person resident outside India can transfer any security to a person resident in
India by way of gift.

(d)

A person resident outside India can sell the shares and convertible debentures of
an Indian company on a recognized Stock Exchange in India through a stock
broker registered with stock exchange or a merchant banker registered with
SEBI.

(e)

A person resident in India can transfer by way of sale, shares/ convertible
debentures (including transfer of subscriber’s shares), of an Indian company
under private arrangement to a person resident outside India, subject to the
guidelines given in para 5.2 and Section 1 of this Annexure.

(f)

General permission is also available for transfer of shares/convertible
debentures, by way of sale under private arrangement by a person resident
outside India to a person resident in India, subject to the guidelines given in para
5.2 and Section 1 of this Annexure.

(g)

The above General Permission also covers transfer by a resident to a nonresident of shares/convertible debentures of an Indian company, engaged in an
activity earlier covered under the Government Route but now falling under
Automatic Route, as well as transfer of shares by a non-resident to an Indian
company under buyback and/or capital reduction scheme of the company.

(h)

The Form FC-TRS should be submitted to the AD Category-I Bank, within 60
days of transfer of capital instruments or receipt / remittance of funds whichever
is earlier. The onus of submission of the Form FC-TRS within the given
timeframe would be on the resident transferor/transferee or the person resident
outside India holding capital instruments on a non–repatriable basis, as the case
may be. Transfer of equity instruments on a recognised stock exchange by a

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 74 -->

73

person resident outside India shall be reported by such person in Form FC-TRS.
However, in cases where the NR investor, including an NRI, acquires shares on
the stock exchanges under the FDI scheme, the person resident outside India
would have to file form FC-TRS with the AD Category-I bank.
(ii)

The sale consideration in respect of equity instruments purchased by a person
resident outside India, remitted into India through normal banking channels, shall
be subjected to a Know Your Customer (KYC) check by the remittance receiving AD
Category-I bank at the time of receipt of funds. In case, the remittance receiving AD
Category-I bank is different from the AD Category-I bank handling the transfer
transaction, the KYC check should be carried out by the remittance receiving bank
and the KYC report be submitted by the customer to the AD Category-I bank
carrying out the transaction along with the Form FC-TRS.

(iii)

A person resident outside India including a Non-Resident Indian investor who has
already acquired and continues to hold the control in accordance with the SEBI
(Substantial Acquisition of Shares and Takeover) Regulations can acquire shares of
a listed Indian company on the stock exchange through a registered broker under
FDI scheme provided that the original and resultant investments are in line with the
extant FDI policy and FEMA regulations in respect of sectoral cap, entry route,mode
of payment, reporting requirement, documentation, etc.

(iv)

Escrow: AD Category-I banks have been given general permission to open Escrow
account and Special account of non-resident corporate for open offers/exit offers
and delisting of shares. The relevant SEBI (Substantial Acquisition of Shares and
Takeovers) Regulations, 2011 (SAST) Regulations or any other applicable SEBI
Regulations/provisions of the Companies Act, as applicable will be applicable. AD
Category-I banks have also been permitted to open and maintain, without prior
approval of RBI, non-interest bearing Escrow accounts in Indian Rupees in India
on behalf of residents and/or non-residents, towards payment of share purchase
consideration and/or provide Escrow facilities for keeping securities to facilitate
FDI transactions subject to the73terms and conditions specified by RBI. SEBI
authorised Depository Participants have also been permitted to open and maintain,
without prior approval of RBI, Escrow accounts for securities subject to the terms
and conditions as specified by RBI. In both cases, the Escrow agent shall
73necessarily be an AD Category-I bank or SEBI authorised Depository Participant
(in case of securities’ accounts). These facilities will be applicable for both issue of
fresh shares to the non- residents as well as transfer of shares from/to the nonresidents.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 75 -->

74

(v)

In case of transfer of shares between a resident buyer and a non-resident seller or
vice-versa, not more than twenty five per cent of the total consideration can be paid
by the buyer on a deferred basis within a period not exceeding eighteen months
from the date of the transfer agreement. For this purpose, if so agreed between the
buyer and the seller, an escrow arrangement may be made between the buyer and
the seller for an amount not more than twenty five per cent of the total
consideration for a period not exceeding eighteen months from the date of the
transfer agreement or if the total consideration is paid by the buyer to the seller, the
seller may furnish an indemnity for an amount not more than twenty five per cent
of the total consideration for a period not exceeding eighteen months from the date
of the payment of the full consideration.
Provided the total consideration finally paid for the shares must be compliant with
the applicable pricing guidelines.

5. Prior permission of RBI in certain cases for transfer of capital instruments
5.1

Except cases mentioned in paragraph 5.2 below, the following cases require prior
approval of RBI:
(i) Transfer of capital instruments from resident to non-residents by way of sale
where:
(a) Transfer is at a price which falls outside the pricing guidelines prescribed
under Foreign Exchange Management (Non-Debt Instruments) Rules, 2019
from time to time and the transaction does not fall under the exception given
in para 5.2.
(b) Transfer of capital instruments by the non-resident acquirer involving
deferment of payment of the amount of consideration. Further, in case
approval is granted for a transaction, the same should be reported in Form
FC-TRS, to an AD Category-I bank for necessary due diligence, within 60
days from the date of receipt of the full and final amount of consideration.
(ii) Transfer of any capital instrument, by way of gift by a person resident in India to
a person resident outside India. While forwarding applications to Reserve Bank
for approval for transfer of capital instruments by way of gift, the documents
mentioned in Section 2 of this Annexure should be enclosed. Reserve Bank
considers the following factors while processing such applications:
(a) The proposed transferee (donee) is eligible to hold such capital instruments
under the relevant Schedules under Foreign Exchange Management (Non-Debt
Instruments) Rules, 2019, as amended from time to time.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 76 -->

75

(b) The gift does not exceed 5 per cent of the paid-up capital of the Indian
company/each series of debentures/each mutual fund scheme.
(c) The applicable sectoral cap limit in the Indian company is not breached.
(d) The transferor (donor) and the proposed transferee (donee) are close relatives as
defined in Section 2 (77) of Companies Act, 2013, as amended from time to time.
The current list is reproduced in Section 3 of this Annexure.
(e) The value of capital instruments to be transferred together with any capital
instruments already transferred by the transferor, as gift, to any person residing
outside India does not exceed the rupee equivalent of USD 50,000 during the
financial year.
(f)

Such other conditions as stipulated by Reserve Bank in public interest from time
to time.

(iii) Transfer of shares from NRI to non-resident.

5.2

In the following cases, approval of RBI is not required:
A.

Transfer of shares from a Non-Resident to Resident under the FDI scheme
where the pricing guidelines under FEMA, 1999 are not met provided that:
i. The original and resultant investment are in line with the extant FDI policy and
FEMA regulations in terms of sectoral caps, conditionalities (such as minimum
capitalization, etc.), reporting requirements, documentation, etc.;
ii. The pricing for the transaction is compliant with the specific/explicit, extant and
relevant SEBI regulations/guidelines (such as IPO, Book building, block deals,
delisting, exit, open offer/substantial acquisition/SEBI SAST, buy back); and
iii. Chartered Accountants Certificate to the effect that compliance with the relevant
SEBI regulations/guidelines as indicated above is attached to the form FC-TRS to
be filed with the AD bank.

B.

Transfer of shares from Resident to Non-Resident:
i) where the transfer of shares requires the prior approval of the Government as
per the extant FDI policy provided that:
a) the requisite approval of the Government has been obtained; and
b) the transfer of shares adheres with the pricing guidelines and documentation
requirements as specified by the Reserve Bank of India from time to time.

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 77 -->

76

ii) where the transfer of shares attract SEBI (SAST) Regulations subject to the
adherence with the pricing guidelines and documentation requirements as
specified by Reserve Bank of India from time to time.
iii) where the transfer of shares does not meet the pricing guidelines under the
FEMA, 1999 provided that:
a) The resultant FDI is in compliance with the extant FDI policy and FEMA
rules/regulations in terms of sectoral caps, conditionalities (such as minimum
capitalization, etc.), reporting requirements, documentation etc.;
b) The pricing for the transaction is compliant with the specific/explicit, extant and
relevant SEBI regulations/guidelines (such as IPO, Book building, block deals,
delisting, exit, open offer/substantial acquisition/SEBI SAST); and
c) Chartered Accountants Certificate to the effect that compliance with the relevant
SEBI regulations/guidelines as indicated above is attached to the form FC-TRS to
be filed with the AD bank.
iv)where the investee company is in the financial sector provided that:
a) Any ‘fit and proper/due diligence’ requirements as regards the non-resident
investor as stipulated by the respective financial sector regulator, from time to
time, have been complied with; and
b) The FDI policy and FEMA rules/regulations in terms of sectoral caps,
conditionalities (such as minimum capitalization, pricing, etc.), reporting
requirements, documentation etc., are complied with.
6.
(i)

Conversion of ECB/Lump sum Fee/Royalty etc. into Equity
Indian companies have been granted general permission for conversion of External
Commercial Borrowings (ECB) (excluding those deemed as ECB) in convertible
foreign currency into equity shares/fully compulsorily and mandatorily convertible
preference shares, subject to the following conditions and reporting requirements:
(a) The activity of the company is covered under the Automatic Route for FDI
or the company has obtained Government approval for foreign equity in the
company;
(b) The foreign equity after conversion of ECB into equity is within the sectoral
cap, if any;
(c) Pricing of shares is as per the provision of para 2 above;
(d) Compliance with the requirements prescribed under any other statute and
regulation in force; and

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 78 -->

77

(e) The conversion facility is available for ECBs availed under the Automatic or
Government Route and is applicable to ECBs, due for payment or not, as
well as secured/unsecured loans availed from non-resident collaborators.
(ii)

General permission is also available for issue of shares/preference shares against
lump sum technical know-how fee, royalty due for payment, subject to entry route,
sectoral cap and pricing guidelines (as per the provision of para 2 above)and
compliance with applicable tax laws. Further, issue of equity shares against any
other funds payable by the investee company, remittance of which does not require
prior permission of the Government of India or Reserve Bank of India under FEMA,
1999 or any rules/ regulations framed or directions issued thereunder, or has been
permitted by the Reserve Bank under the Act or the rules and regulations framed or
directions issued thereunder is permitted, provided that:
(I) The equity shares shall be issued in accordance with the extant FDI guidelines
on sectoral caps, pricing guidelines etc. as amended by Reserve bank of India,
from time to time;
Explanation: Issue of shares/convertible debentures that require Government
approval in terms of paragraph 3 of Schedule I of Foreign Exchange
Management (Non-Debt Instruments) Rules, 2019 or import dues deemed as
ECB or trade credit or payable against import of second hand machinery shall
continue to be dealt in accordance with extant guidelines;
(II)The issue of equity shares under this provision shall be subject to tax laws as
applicable to the funds payable and the conversion to equity should be net of
applicable taxes.

(iii) A wholly owned subsidiary set up in India by a non-resident entity, operating in a
sector where 100 percent foreign investment is allowed in the automatic route and
there are no FDI linked conditionalities, may issue equity shares or preference
shares or convertible debentures or warrants to the said non-resident entity against
pre-incorporation/ pre-operative expenses incurred by the said non-resident entity
up to a limit of five percent of its capital or USD 500,000 whichever is less, subject to
the condition that within thirty days from the date of issue of equity instruments
but not later than one year from the date of incorporation or such time as the
Reserve Bank permits, the Indian company shall report the transaction to the
Reserve Bank as per the reporting requirements as specified by the Reserve Bank..
(iv) Issue of equity shares for sectors requiring Government approval under the FDI
policy is allowed under the Government route for the following:
(I) import of capital goods/ machinery/ equipment (excluding second-hand
machinery), subject to compliance with the following conditions:
(a) Any import of capital goods/machinery etc., made by a resident in India, has to
be in accordance with the Export/Import Policy issued by Government of
India/as defined by DGFT/FEMA provisions relating to imports.
Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 79 -->

78

(b)

The application clearly indicating the beneficial ownership and identity of the
Importer Company as well as overseas entity.
(c) Applications complete in all respects, for conversions of import payables for
capital goods into FDI being made within 180 days from the date of shipment of
goods.
(II) pre-operative/pre-incorporation expenses (including payments of rent etc.), subject
to compliance with the following conditions:
(a) Submission of FIRC for remittance of funds by the overseas promoters for the
expenditure incurred.
(b) Verification and certification of the pre-incorporation/pre-operative expenses by
the statutory auditor.
(c) Payments should be made by the foreign investor to the company directly or
through the bank account opened by the foreign investor as provided under
FEMA Regulations.
(d) The applications, complete in all respects, for capitalization being made within
the period of 180 days from the date of incorporation of the company.

General conditions:
(i) All requests for conversion should be accompanied by a special resolution of the
company.
(ii)Government’s approval would be subject to applicable pricing guidelines under
FEMA and appropriate tax clearance.
(iii)For sectors under automatic route, issue of equity shares against import of capital
goods/ machinery/ equipment (excluding second-hand machinery) and preoperative/pre-incorporation expenses (including payments of rent etc.) is
permitted under automatic route subject to compliance with respective
conditions mentioned above, and reporting to RBI in form FC-GPR as per
procedure prescribed under the FDI policy.
SECTION 1
Terms and conditions for Transfer of Shares/Convertible Debentures, by way of Sale, from a
Person Resident in India to a Person Resident Outside India and from a Person Resident
Outside India to a Person Resident in India
1.1 In order to address the concerns relating to pricing, documentation, payment/ receipt and
remittance in respect of the shares/convertible debentures of an Indian company, in all sectors,
transferred by way of sale, the parties involved in the transaction shall comply with the
guidelines set out below.
1.2 Parties involved in the transaction are(a) seller (resident/non-resident), (b) buyer
(resident/non-resident), (c) duly authorized agent/s of the seller and/or buyer, (d) Authorised

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade

<!-- page 80 -->

79

Dealer bank (AD) branch and (e) Indian company, for recording the transfer of ownership in its
books.
2. Pricing Guidelines
2.1 The under noted pricing guidelines are applicable to the following types of transactions:
i.
Transfer of shares by way of sale under private arrangement by a person resident in India
to a person resident outside India.
ii. Transfer of shares by way of sale under private arrangement by a person resident outside
India to a person resident in India.
iii. Exit by non-resident investor on exercising option/right in shares or compulsorily &
mandatorily convertible preference shares or fully, compulsorily & mandatorily convertible
debentures.
2.2 Transfer by Resident to Non-resident (i.e. to foreign national, NRI, , FPI and incorporated
non-resident entity other than erstwhile OCB) Price of shares transferred by way of sale by
resident to a non-resident where the shares of an Indian company are:
(a) listed on a recognized stock exchange in India ,shall not be less than the price at which the
preferential allotment of shares can be made under the SEBI guidelines , as applicable,
provided the same is determined for such duration as specified therein, preceding the
relevant date, which shall be the date of purchase or sale of shares,
(b) not listed on a recognized stock exchange in India, shall not be less than the fair value to be
determined by a SEBI registered Merchant Banker or a Chartered Accountant as per any
internationally accepted pricing methodology on arm’s length basis. The price per share
arrived at should be certified by a SEBI registered Merchant Banker or a Chartered
Accountant.
2.3 Transfer by Non-resident (i.e. by incorporated non-resident entity, erstwhile OCB, foreign
national, NRI, , FPI)to Resident
Sale of shares by a non-resident to resident shall be in accordance with the provisions of Rule 9
(2) of Foreign Exchange Management (Non-Debt Instruments) Rules, 2019which shall not be
more than the minimum price at which the transfer of shares can be made from a resident to a
non-resident as given at para 2.2 above.
2.4 After the lock-in period, as applicable above, and subject to FDI Policy provisions, if any, in
this regard, the non-resident investor exercising option/right in shares or convertible
debentures issued under FDI Scheme shall be eligible to exit without any assured return, as per
pricing/valuation guidelines issued by RBI from time to time.
3. Responsibilities / Obligations of the parties
All the parties involved in the transaction would have the responsibility to ensure that the
relevant rules/regulations under FEMA are complied with and consequent on transfer of shares,

Consolidated FDI Policy 2020
Department for Promotion of Industry and Internal Trade
