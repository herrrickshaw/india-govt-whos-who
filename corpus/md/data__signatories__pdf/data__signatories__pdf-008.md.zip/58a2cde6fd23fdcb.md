---
doc_id: "58a2cde6fd23fdcb"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/56424b8cb43a48c7393599a65a2fe644.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Promotion/Tramsfer of officers of Central Labour Service- reg (23 oct 2020) (Office Order- 23/20)"
date: "2020-10-23"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3d06481db86cdeb4"
---

<!-- page 1 -->

No. A-22012/01/2020- CLS.I
Government of India
Ministry of Labour and Employment
Shram Shakti Bhawan, Rafi Marg
New Delhi, dated 23rd October, 2020
OFFICE ORDER No.23/2020

Subject: -Promotion and Transfer/Posting of Central Labour Service Officers
The transfer /posting of following Senior Time Scale (STS) officers of Central Labour Service
is ordered with immediate effect against the post indicated as under:SINo.
(1)
1.

Name of the Officer
(Shri/Smt)
(2)
Shri Tej Bahadur

2

Shri Hemant Singh

2.

Designation and Present
Place of Posting
(3)
(C),
RLC
0/0 Dy. CLC,
Jeevandeep Building, New
Delhi
DLWC (C), Ram Manohar
Lohia Hospital New Delhi

Posted to
(4)
DLWC (C), Ram Manohar Lohia
Hospital, New Delhi
RLC
(C),
CLC,
0/o Dy.
Jeevandeep Building, New Delhi

The above officers are entitled for TTA/Joining Time as per relevant rules.

3.
The concerned Organizations are requested to relieve the above mentioned officers
immediately to enable them to join their place of new posting. The officers concerned are directed to
submit their joining reports to this Ministry through their respective organizations of their posting.

4.

This issues with the approval of the Competent Authority.

y
(S K Kalra)
Deputy Secretary
Tele No :- 23766904

Distribution :1. The officers concerned
2. The Estts/Organizations Concerned
3. CLC (C), Ministry of Labour and Employment, New Delhi
4. DGLW, Ministry of Labour and Employment, New Delhi
5. CLS - II (Vig.) Section, Ministry of Labour and Employment
6. Personal file of the Officers Concerned/Office Order bundle/spare copies
7. IT Cell, MoLE - for uploading the office order on MoLE's website
