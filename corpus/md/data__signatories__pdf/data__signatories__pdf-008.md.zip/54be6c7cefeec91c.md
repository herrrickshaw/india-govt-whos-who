---
doc_id: "54be6c7cefeec91c"
source_url: "https://financialservices.gov.in/sites/default/files/vacancy/vacancy-circular-DRAT-Chennai-for-the-post-of-Assistant.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "vacancy-circular-DRAT-Chennai-for-the-post-of-Assistant.pdf"
date: ""
pages: 7
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "2a6a462b8bb4f033"
---

<!-- page 1 -->

exp
No.15/01/2020/DRAT
Government of India
Ministry of Finance
Department of Financial Services A 4
DEBT RECOVERY APPELLATE TRIBUNAL 2 है
(SOUTHERN REGION) — pm
(Telephone: 044-28311296, 28311297 & 28311298) ty a ४ Fa
: ‘cos | E-mail: dratchennai-dfs@nic.in “is WY
: suivatiseee we
a3 JUN 701 | 4" Floor, Indian Bank Zonal Office,
~ . 55, Ethiraj Salai, Chennai-600 008
fare \or
_— |b.
>> rd
oe Dated the 23 June, 2021
VAGANCY CIRCULAR
Applications are invited from suitable candidates from Central Government/
State Government/ Tribunal for appointment to the following posts on deputation basis
in the Debt Recovery Appellate Tribunal (DRAT) / Debt Recovery Tribunals (DRTs)
under the jurisdiction of DRAT, Chennai. The maximum age of the Applicant should
not exceed 56 years on the closing date. Qualifications/experience and service
conditions required for appointment to the posts are given below:
कक अमल Ty
कक ताक न न अनणा
Place of vacancy Chennai-3; Bangalore-6; Coimbatore-1; Ernakulam-1; and
Madurai-1
Scale of Pay [| Level-6 in Pay matrix - Rs.35400-112400/-
Mode of Recruitment | By Deputation
Eligibility Officers under the Central Government or State
Government or Tribunals:-
(i) Holding analogous post on a regular basis in the
parent cadre or department; or
(ii) With ten years service in the grade rendered after
appointment thereto on a regular basis in Level-4 in
the pay matrix (Rs.25500-81100) or equivalent, in
the parent cadre or department.
2. Accounts Group -B
Assistant
RevefFost [27a झऊ_ऊॉ
Place of vacancy [| Chennai-2; Bangalore-2; Coimbatore-1; and Ernakulam-2
Scale of Pay [| Level-6 in Pay matrix - Rs.35400-112400/-
Mode of Recruitment [| By Deputation

<!-- page 2 -->

Eligibility Officers under the Central Government:-
(a) (i) Holding analogous post on regular basis in the
parent cadre or department; or
(ii) with ten years regular service in the grade rendered
after appointment thereto on a regular basis in Level-4
in the pay matrix (Rs.25500-81100) or equivalent, in the
parent cadre or department; and
(b) Who have undergone training in cash and accounts
work in Institute of Secretariat Training and
Management or equivalent Institute of Central
Government.
3. Stenographer || &छा0५० - 3
Grade-i
| : | 17 (Seventeen) Posts
है Place of vacancy i Chennai-5; Bangalore-4; Coimbatore-2; Ernakulam-4; and
Madurai-2
[|
[|
Eligibility Officers under the Central Government or State
Government or Tribunals:-
(i) Holding analogous post on a regular basis in the
parent cadre or department; or
(ii) With ten years service in the grade rendered after
appointment thereto on a regular basis in Level-4 in
the pay matrix (Rs.25500-81100) or equivalent, in
the parent cadre or department.
4. Upper Division a Group — C
Clerk (UDC. -
[|
Place of vacancy a Chennai-1; Bangalore-4; Coimbatore-1; Ernakulam-1; and
Madurai-1
[: |
CA
Eligibility Officers under the Central Government or State
Government or Tribunals:-
(i) Holding analogous post on a regular basis in the
parent cadre or department; or
(ii) Lower Division Clerk with eight years service in the
grade rendered after appointment thereto on a
regular basis in Level-2 in the pay matrix (Rs.19900-
63200) or equivalent, in the parent cadre or
department. 5
2. The Debt Recovery Appellate Tribunal/ Debts Recovery Tribunal are quasi-
judicial bodies set up under the provisions of the Recovery of Debts due to Banks and
Financial Institutions Act, 1993.

<!-- page 3 -->

3. The selected candidate will be appointed on deputation basis initially for a
period of four years, which may be extended as per norms subject to satisfactory
performance and other terms and conditions. The terms of deputation shall be
regulated in accordance with the Department of Personnel and Training
O.M.No.6/8/2009-Estt(Pay-Il) dated 17.02.2016, as amended from time to time.
4. The departmental officials in the feeder grade who are in direct line of
Promotion, shall not be eligible for consideration for appointment on deputation.
Similarly, a deputationist in the DRAT/DRTs under the jurisdiction of DRAT, Chennai
shall not be eligible for consideration for absorption or promotion.
5. The applications of the willing and eligible candidates in the prescribed Pro-
forma at Annexure-| & II along with attested photocopies of APARs for the last five
years and who could be spared immediately, may be forwarded to this Tribunal, so as
to reach “The Secretary/Registrar, Debt Recovery Appellate Tribunal, No.55,
Ethiraj Salai, an Floor, Indian Bank Zonal Office, Egmore, Chennai — 600 008”
through proper channel on or before 23.07.2021 at 05:30 PM.
6. The applicant should clearly indicate the service particulars, experience,
educational qualification and place of posting for which applied for in the prescribed
format at Annexure-I. No action will be taken on advance copy. While forwarding the
application, the parent office / Department shall issue the certificate to the effect that
the official is clear from vigilance point of view and no disciplinary case is
pending/contemplated against him/her, as given in the pro-forma at Annexure-ll,
enclosed herewith. The department while forwarding the applications may please
ensure that the officials who volunteer for the post shall not be allowed to withdraw
their names later on.
rR, Avi (०६०७
aajb/s¢
(N. SRINIVASAN)
Section Officer
To
1. All Departments/ Ministries of Government of India. It is requested that this
circular may please be given wide publicity.
2. The Under Secretary (CS Division), Department of Personnel & Training, North
Block, Lok Nayak Bhawan, New Delhi - with a request to upload this circular in
DoP&T website under vacancies.

<!-- page 4 -->

3. The Under Secretary (DRT),Department of Financial Services, Ministry of
Finance, Jeevan Deep Building, Parliament Street, New Delhi — with a request to
upload the circular in DoFS website.

4. The Registrars of all DRATs/DRTs

5. The Registrar, Central Administrative Tribunal, City Civil Court Additional Building,
4 & 2"7 Floor, High Court Campus, Chennai — 600 104.

6. Admin Departments of State Government of Tamil Nadu/ Central Government
Offices in Tamil Nadu.

7. Notice Board and Web site of DRAT, Chennai/ DRTs under the jurisdiction of
DRAT, Chennai

६
“प्र

<!-- page 5 -->

Annexure-|
PROFORMA
Affix latest
Passport size
APPLICATION FOR THE POST OF “ ”
PLACE OF POST FOR APPLIED:
Name & Designation and Office
ener
2 ० &£&£& ० ० ० & फईढऊ
Pp
4. | Date of retirement under Central/State
a Government rules Date of retirement है
under Central
ET
a
pee ed
PO  आआछऋ आ ऋ ऑईई')
a
| 6. |
Office/ Institution Post held Reysed| Pay Nature of suis
D | Seettisuuon
Po र_॒_ [२ स्‍ू्स्‍्ई॒1ट [| [ [| | |
"्््॒रट$ फ$फटुह ६ | [ |
कि शा कि
7. |Nature of present employment
ff |
| 8. |
|__| (a) The date of initial appointment [:[ ss '
| | (b) Period of appointment on i
deputation:
(c) Name of the present
| | office/organization to which you
belong:
|| Please state whether working |
under
|@) Central Govemment S| [SSS
[I (b) State Govemment [|
[Ho Trbunais र 7777्7््््-_]]

<!-- page 6 -->

10. | Additional information, if any,
which you would like to mention in
support of your suitability for the
post. Enclose a separate sheet, if
the space is insufficient with
signature
Whether belongs to SC/STIOBC [:| SSS
12. | Complete official address of the
candidate including telephone
number
The information/details provided by me above are correct and true to the best
of my knowledge and no materials facts having a bearing on my selection has been
suppressed/withheld.
Place:
Date: Signature of the Candidate
है Address:
Mobile No.
Email-ID:

<!-- page 7 -->

Annexure-ll
CERTIFICATE TO BE FURNISHED BY THE EMPLOYER/ HEAD OF OFFICE/
FORWARDING AUTHORITYBY PARENT OFFICE/CONTROLLING AUTHORITY
Office of the
Certified that the information furnished by Shri/Smt./Km.
are found to be correct and he/she possesses the educational qualifications and
experience mentioned in the vacancy circular.
Also certified that:
(i) There is no vigilance case pending/ contemplated against him/her.
(ii) — The integrity of Shri/Mrs./Ms. is beyond doubt.
(iii) | No Major/Minor penalties have been imposed on him/her during the last 10
years.
(iv) This office has no objection that in the event of selection, the official will be
relieved immediately.
(v) | Copies of APARs for the last 5 years duly attested on each page.
(vi) List of major penalties imposed on him/her during the last 10 years is
enclosed.
(Strike out which is not applicable)
Place: Signature
Date:
Name & Designation of the employer
(with office seal)
