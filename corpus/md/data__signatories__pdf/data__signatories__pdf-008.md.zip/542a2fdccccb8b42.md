---
doc_id: "542a2fdccccb8b42"
source_url: "https://www.mea.gov.in/images/4-guidelines-new.pdf"
ministry: "External Affairs (MEA)"
title: "Guidelines for Registration as RAs. Revised Form"
date: ""
pages: 13
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c41f515d13ac2a28"
---

<!-- page 1 -->

- No.Z-11011/01/2015-PGE. |
Government of India
Ministry of Overseas Indian Affairs |
Akbar Bhawan, Chanakyapuri
New Delhi, dated 06.04.2015
OFFICE ORDER
It has come to the notice of the Competent Authority that a number of O.M.’s
loffice orders have been issued without corresponding notification’ amendment of ।
the Rules. This has led to a situation of a number of queries being raised and
additional procedures not mandated in the Rules being followed leading to
pendency in disposal of applications. In supersession of all earlier orders issued on
the Subject, it has been decided to comprehensively lay down the procedure to be
followed for handling issue of Registration certificates, henceforth. A two stage
process is being recommended as Annexure-1 to this O.M. The POE inspection will
be done as prescribed in Annexure-ll.
2. Documents in respect of Stage-l will be submitted in the Office of Protector
General of Emigrants and in respect of Stage-Il in the respective jurisdictional
Protector of Emigrants. Time line as mentioned in the annexure will be strictly
adhered to.
3. Registering Authority will designate an officer to conduct personal appearance
| of the applicants.
4. Onsatisfactory completion of the revised procedure as laid down in column 4 of
the O.M., the Registering Authority will issue a registration certificate to the
applicant.
5 The above orders will be effective from the date of issue of this Office
Memorandum and will also apply to all applications pending as on 01.04.2015 and
all future applications.
6. This issues with the approval of Secretary, Ministry of Overseas Indian Affairs.
al
[oo ipa ५४
(M.Sooriyanarayanan)
Under Secretary to the Government of India
Tel. No.24675142
10
4. All POEs/Concerned Officers/Sections in the Ministry
Copy for information to: 1. Sr.PPS to Secretary, MOIA
2. NIC fr aploactias — wy he Web sg be he
Fees

<!-- page 2 -->

नस o_o
(/)
है हि
न 2 0 1-7
| * 0 + |m
a lS 2 2
, “oT cCli> 1
OVD os i ए। श्र [7
0५ 9 कफ हे >>
gees a= 3.|5 a
= a as D : ०165 =
० पे _ “८ ना
J) wo SQ ५5 O
© 9) 0. QO ~ > नर
9! “< (2 S 0
TPs ~*~ ५»
नर 02> > A
Oo 26 ५? S
a 9c Q S = ()
9) 1 O © गा
S| 2am a. as a
हि 5 ° ”
='O = z
a प्र a
(7206
९ ६२ n O
=" = 9 ना
कक 5 >
cS5 oO नए
५ फजूढ्र a. a
७9 22 =
+" 6 ()
= A >
Ae = S
co oD ze
o2=2 > O
ct
Sa) seein छा =
> —. 9) OV a *< ~
no —| 2.
2a ७ (9 (010७) nN
oO ६ 0) ८+ 69% 5 (2
et o-— oO Sos A
pe = (2
> Ooo SS le प्र
@ a = & ~-ale =
(9 हक [5 0 6)
के To 35 0०।168 6)
5 Sos =
oe (0 3| ८
Pas So a6 av
35 = ® +169 >
oe BOO
O > Os >
५
> ()
San > Oo 25/18.

5235 9909588 g Soleggs =
eG ees 38308 OP =.o +|० 81356 584 oO
Wy < ९). ध्टे के 0 हे के क 312 ae ()
as =} OAS हो 2<, २ 2 3 = >
“ aoa ss 8 KS बन Plo o Of: £o3 &. m
—! >9 8 116 86 3० है * SL ao Oo ®
© $983 ois 50 aise @ =o 3S कर

a (0 9 4 Oo ७919 a O56 99
0 ठ59 >! 65020 ह 4 हु है| 57५4७ a
9 cee ara ss SSS ®|3 9 6 “ हुँ 15 °
५) OD Oo. 5 ठ O = a. sid
5 2०088 78 8५86 ० तप है ३63 हि
0) ee Ag: Pe oe + ¢ Oo Pond
— 5 OF 2 ALBDy oO = 9) @ “3

opa°%cR. 7 oa +506 tA
9) डिक न © o| of st a
0 PRO 3G 59% oo 2 ० + = S38 = ७
० ora aM my VS oc; 2a So: ५
(0 > oO SSB3oR2 @ 30. बट 52 पक 5
श्र ४३ 58 89 0.55 65 हर a, 5129 op
9 Jos C00 Sos 2. JT! Oo a
Ss दिल a8 O53 kGO5 ~| 92 G=o m |Z
CS" opeos a 5 N 0 ofcos =~
o ft OO 6 = ० >| goa] ® ° a |m

95 D099 220.0 4) = a eee O20 2 5: 9<
= 283225 28388 0 5 e's गज cic
et OSF6 as. oe < (0 5“ (0 7 = —
st ee | है “| BNF 5

INAH CO @O 065 =F = = < [T
(9 oe Ooo 6 » a> ॥

= SO Snes HO 3] aes a.
oO = E00 539 a 9a] =!
a =o नल Sone rs
a =< = > ah a NO
> OO OO 8०6 aan
9 ॥ >- 3 OS aa

<!-- page 3 -->

a eccsaeaicee 5
|
ह 9) ८ Oo =
2 © at 53.22 6८ > -|
oO D © ४5७०५ |
Ne 2o 9 sao +" 3 0
a @ 5 s203 ५26 Ole,
+ TS O25 BS
So oO = to a |/O
ana o = 0.65) .. ७ 9 2७177
oe 9) S
© Coe > QE Dlay
29 Ne! 25e2e Og ० टए
DO oS; @” gs As 4/0
@ a ot 0 eo a2 2 ¢|U
a © = 3 O ७9 ७ <| 5
co 20 05 a ee Re
c = — + 9 oOolm
o 2 o9 OF ००
os Os! Borge, = <j
O +>
N St =o +o oO
No ® <a oF 07> >|
~— Oo छ्ज +# तो ०0155
m S| G&2a 9958 70
> ao] 2 eS Co5/S
5 @ ०935-65 ~2o
9) ० "2 6 O'S. =
ct. a = o*~ ®
2 a =O 3.
D c G35 a 6
STOoOAS> sz OTCO > oO QQ
5° 32455 9 3X0 906
दा +28ec Mo 1 OS oS
Us +255 55 96% N 3.
Q®e Fa HGgrxe ५५३3 SOS
7-55 "0 “I >. ™~ oS.
MELore Fo c 9 3 5
<too5 . ७ 5 es
A 2 (9 ७? £ ”* og > =p
RI Oy 2a 5 = Be
92 @c SHO + Qs a
N "0 a= = o @ a = = >
=> Sa Tw ” —. ©
न ही & «& 7308 c=
S3al2e090700 ४.०9 33
0 ५0 = © 206
= 5 =. ©: = O oO +:
ae + © nO a
pa hos se. ass Nv
® FAO 62% oe cat 006
>५०-<-+-5-+9 ९२5७ am 9५
a ~~ — == = -> 55 2० 0 ®D PT Oo) oO = =
oa B=g00
e Ge oa ee og Sols S58 O19 23 ५2 91 8 5:8 ५०8
उक्रद्व 63889 6| 5356 25% ७ 9 9 ९७हें ४ ०। 4९6 हे
30०90 9 7०४५“ 53565 0S AIQT>O R53] /“>ऊ: ce ms
0 38-19 5 06199 ४५% 9 2७ ? ०४ 58189& Oo © ao 2 =
5ध्य86-18 ते < 9199 OQ 55016 .. _0|5 625 98%» aofag
—O Oo <32 5S 02g >2 o2- जुक QQ — oO < 2S
हे  2asr< 5 0 noe 9O2eT/SO So PS aa
“5 +- 3 ह# हे छ &#%.5615.25%09 < 45370 » ४905 +> छत
Free a Zo FS T2°8Q) S22 Fu SS BQ 50५५०
a5 3G कक जे “le Bad § e@asS2jioggo7- FFG
SPO RPacwmoheoae 6° 2 o|> = > Uo i
ब3>8है५ 055 5 हु 6०० 8 5: 3 5 किक & अर जे ड्ते लि
ies 347223 _/9 S26 PAP PtH eS QS55
CDW 5 ६ 5 090 कि 4 0फछहद 3%5+95[9 5+>55689५ M S:= oO
Oo O 030% 0 YO +O In > =. = =
= Oo 2 FoNOUNGSG +
=Y%® oO =. 9 “I st 6 ० %9 0 80% 989 0० ते छ Foas
Seas S56 SG BO] 4 61696 &+3+5० =h
BGZRAAE” oO += 35 o =F 28a 8sr9 29 9o
— on =~ > —,
o°?5.,c0280x Gg 9758७ के ODDO =f SRE
oon Sx aan 8 os = छल 82159 ४9 के "जा
ak ote ५9) a = ‘
m@FR2eecq_ Ber geo aie os e's Ro SS.
Qg?_ 325095 SOG fe 28/35 2095 86०86
9053 e2° ०| ०४३५७५+५४| ७ Ter se Rae 3०७50.
90 8 9%क 9 ड चर ० 528५० s2eq >56 86868 न
a3 0xF003¢g BS29/ @oae 338 xe 2cog
BaPw FS dono Fes 8598०| 250,55 oe Ss
PtH =02S2008 0 mm “०5:०७ -+| 52099 5770७ 0H OD

<!-- page 4 -->

>
< =.
a5 >
| Aas oa
हु 81 22% 65 S of
OG =a 5 — O om
we = 5 ५ (9
— (9
Oo =e @ 3
> On
— 3 ast
Oi के —'
८) ५9 ५ Dm =
— 5 a oc =.
ee < Oo a
0 (9 "7 Ga
—_ ot
= oo Oo +
© 9) पका पाया
=~ O 09
To ana हे
56 cs 9)
Oo 3 5, co
=. oo a Oo
@ ५४ ao
s+ = (00) —
O a =a ५0
S D =
5 2 = ©
DO i © 5
= Q
(9 कह
५) ५, 27 ५) — 508 %:२क6५5५५3०
sh g GR ARSRSSS ERTS Rss
© oO 4 502 oO आज, oo = Oo
5 0AEING QaQan >~S=505308
Of; ५०५०८ 56 5 5 क 3 1ल के
=. 9 seSEa 5 ५56०9 कठ 6 8 2
3 5 Zo SOS +i Oo 3743,
oS o> J >>AMD + O oo उ्यु = rt o
a ५ ठ 37 ASE. F -
+ ae <
a © (0 + ते ५) 9 a> +
9 Qo ही. को कु =~ oF
Ao =< = oO 90 9 (9
w 5 3s $$ £25 0 “So oo Uo
26 Soe FoOrFo SFO ™ © © ®
a ef के Saas पे नि
~ N @ <= © 9 09 9) ८ ) 5
© +O| fC_RGS 5 के हे. है mn & 8
eS mS TIS0RA*OMASH
6 8-4 = SOS
Q. Q: SSO2ZICLUS5
O 70I5 360 2
SOS 26 9&2 छ059%5%6 ०
656 6 386 हू 39५59 9 >66& 5.
O= 0 कक 5 ५) One Lo oO 0
4 तो :४ ७० िट Sos 3s 90 5
वर हे a 2 ae =. © 2s>3D
9 —- oo 3%5%8 ० फिण ह३:
Qo = 3 =. & Somollaod_o
ne Pal re a2 also 92S
: = _- ५)
om Oo 5 a ठे हें ढ 518 ह# 5 6 क
9) पक © Oe at तह
OO c o=
os! o Be ठे 9 f2IS af
S20} 3&sa SO 3 ola co oS
@ ® < @ 2s. S22 O|/=DTq e
Q2 °F] Qs »>SQalseoms
Bo °| Bo me oaes esa
C Q. > “=O + = —e
26m O26 a ae Se
» v8 » 2.5 B58 S\5 53 § 2
+O मु wey as n° 8 ee SO
nv nats st ~~ — ०0 > (9
+ — awe oO Rod 60 <०७०७
d< | 2 ७ NO2O tT OH
259] 2,8 ee Os] am
“o> 0 a 5 Big SS
(0 O o a <5»
(2 oC “= < n2 J a oS a
RY a St 9 G3 & 998.09
2380] B8oa oO) » sa8
glo) Foo ५,581 <ago
YON os > 3 0
Soo SO =
o°o 90 (9

<!-- page 5 -->

< = =
| | dd
OO UN CeDon NATZ_ I>
के eS © 9० DO = = 5 92a 5
oO 4+ 0 ५. 5७292 |
marine 3 © o so ©* ०019
= o> toaog3/ S° 22
3 3 9) Oo 0 2,.2.° |
aS a 0 9 ० 98 ५ oa3 p/m
oO = Saat SOC DID
” ५) 2D wm uw oo
90 a 3622| -> 55 एज नए
a =
n os 5 ०८०७० 6) >
3 8 ae) 82358) gr aRle
> अ+ —- FO ~/
or Oc m nD /> (3) 0 ४: 1
७-५ a4 72 o@ “wa Nia
aa oT ००93... No Olm
5७ §) < D> > S Ocvly
os 9 © OT, के eS TlH
~N — “+ €& 9 O56
rs) @ > oe ० 7, six
= &, o > S206 0 FalD
iS O © Oo 5 9 Sin
< Oi = ee
mM a ७09 ७5696 5दक6फए। क्र
Q. © 9) | > oo >
= qos a9 o> ५४ ० ७ |
(3 9 ४! 5 HQ
9) Os a ९ ०5०५
6 a <2 a
5 ® 5 a5 § So
9 56 21००६ ७9 0696
हक तल कठठकुफपक
ax =
C®S503 09 6)
Be Si 2§sgys है586| SOs
+." 3 © onr< QADG Qn 3
eFS>°G 390 हे के ५३ oof
Fo DD" Fo > ® 2. e =<.
<2N2 ०४5 > 5 0 39
vis. हूँ oe =
£ Qax=s 90 oO =
SER2B0EG 0 @ fo
तह ?! »& 65०63 900
"eet oe 8B 4 3.0. = >
H-OSQ2 $5 5. 365
P2035 D = ०.
29% S. य 5- 0 ~-@ 3 = O<
SFTHHTHOS Dy x 3
"A A2nAAGwWEA a= 0 ५९
56) ()
aa
efse<.fnan95f$a SePTcu.setion Faz
SSESSSSR8S [RG SSisagoaa zis =§ 3S
8१46 6 S$ seRegs8 secs ges — 8 Be
न हज 433 1686 8०65 (FESS o
i a aos "le os 3 I>, 20D
. e C } —
S35 > <®ofsh ७ डे: 9 893983869५।स Fs o
S=S59R0 0,285 $a = 2/928 2 ३ 9 30<s0
— ae ae —? ee ae Ss.
ofS ets as SO foaalasaad2o क्र 0
oP ese FQ7 MS <2! a p28 Soe
SURO Sa REDD, 2350 =e o 5 8.9 ० 0०0
o20 gs GFz5TQ 2D ® Gas 30 ss
9 ००५७८ a8 sas ० 5 TS2Z65 2 O95
+ .oCIS San OS} +07” o| aos
AOS ZB 200883 == 35727 8596
= oAo = —=: 0 @ © Cc +> 5
S-S <0 ठ = 0 9 =o 2) CAO
PeR7BSe SSRIS PSs] Rese BETO
2P OV eB ०५. a So ye ia s COO vw ck ey ce
ठ 5०५०9 > Oo 927 QMO 0 + 551
5 0 oe SS ov0/ ९. sO "के
ZP=ZEHRDFaATG 2 (0 a —_— = => 9) 7A =
~fome t2"25 ee) SS 3_3/ aAso
~®OGa5S O O=O5 2Ove QHGQE के ४क१ठ
9 FaeSase3 35 ५? 55866 79 Oo oe 2 Oo 6
«४०9दठद8-6%क9ठ5फ +» 3592 @fce2<s TSM SSG
०५८६ FSZSESSAg| BGR | GSEs S223
५० ८. Oo ५0 Qo 0 oox 5 = ©
9 >> .0 0 2 = Sees] sae eo s
2287 a2 HE5 560 22702) a@2@B is —oD7
=2O "SH =20208 oOo" Fs} 0920280 QO>Qoa

<!-- page 6 -->

"
— oO ~_— (09) > वात —.
o=2a] 5 $5 As?
> = Qa 2 = O No
ssrA 2 ५9 8 = Sow
=® Oo (9 > O @3 = => ८+
aia.” Oo < 5 — = ©
oO =N'O @ Do
a © = vU nS O
® U-~ oOo +3] 0 —- @
5 5 oz co 230.
“ के 6 | = < ¢ oe
= >a — 00 O 5 a.
a O Oa 9 6
o9>S>5/ x “a ats
5: 3 अऋ 1 Oo 5
Ee —s on —~ (OQ
+o Oo « oP m4, ५?
OoAN< ® es =.
62
Sz 9) Oo => =h ©
= = = re }
ODaF 0) a3 3
90०6 ५2 ५)
6065 ले o 2 > O
बच ४“+ ध. ८+
YP yd O Neo Oo”
On 5) No "हे
3 at x ca 2
= — asi a
6 o| =D 0a
oO ~ me हि
व दि
[mal
ASS “SI © TIO AD HAH AD
alo 0 & 6 दे >6 8588 &650895%५%>
५ %|५ 4 ५5120 :56 0 < 0 €-+529989 6 ८
= B/2 8 68 aks a= S589 98
SSIS S2S5Fa00 0G ७ ८ >> | ५. “65
क ४०७७5 ७ ४58० 60<० ४ 69 ध्य
a ~|n > 30०9 yags a &
om + OQ Q. o = + #+ Oo
(9 (9 © =O a ~_
५“. 51० 5 c Oo a = Vos F.
© > (0 Os Oo
w c™MIco< 3 = Q 23 9) oz
5 56 S$) <5५8543:8734 8 ५ क
SoISo =: Oo sh ~. "oO w
>@SQOf) SSe798,% 29 Vo
5) ता a oe & ae oe ७ 8०५००
N N 3 co & 0 ऊ 9) - 5. 9
t + © So oe ig 6) -3 |  ,. ¢€09
1 em 95979 09 -+ 7+ 9 5 0 5 छ 9 6 04
6 65 5 ७5 53 ८० & 51.83 =e OIC
= =O 95:06 ons 222.
6 2ITS. alo 5.5 «00 7Qle
=
391 65691 % 69 acm 9/2
09) 5/0 +10 pes >» © —|2.
“im [oF <n DI —, @ T= SU ole
9 op|D OVD ON o छठ
D = = = + V9aordix
= 2 ५9 (५२. (0 ono = 34/M
SO 9 Qa 9 2 * Oo OQ Slo
9) 3.10 “# 0०9 +#05 0 “4८-+ ५+ 60 £
= (5 ४6106, ० ० 9 ०0:०5 9109
4 उठ मि + 58 5 छठ Low I #15.
o ®@is¢ Bois ho Reo 02
T+DO%lDO% NFP gy SIS
Olea 5S Elass o°9 7 OF
o|\3 c=lI3 c= Q So . dS
O<clD< ऊ P3055 10
S12 Qg2%10 5? | 9 <s/=
ols — Oo — |
or 9) 9) as — |
MOP oOwM®sI oO. «slo
N N me हा ता
51% 61% NG पल आओ
क 9 ५ 019 ५ 60 33352
207 Sjoas 9 5 oO
@ |D (0-3 (9 2099 +
wR QalyM~MoQa » ००
QO DW QO DW > (9
(0 O
~+fo @fCh5 Oc ©Zou
SIO - O10°' Oo DOOA
=
9) “| ५) 9) ७ ५5 0
(00 (5 (20 = O 32“ ५9० «<
o/®@ > 5. 5“91 9 5. 02 3 06 यो ०
ale 2 ० रे ७२ ७ 857२6
©0535 3/0 3 3 78a

<!-- page 7 -->

on
ट् ठ
7 — Qo — © Ni => O0oUb a>
261 दृएश58६686%० VFZ_lzZ| Baloo 235
5 हक 00590 % नि 60| 9७७ छल की
ae 70001 १५9५ 5659 8625 0919| “>|*5-< ५ ठे'
न 38651 69%0०0+5 0०९2.?९७७५। 8| 55 9०.2
O a 053 0 =- > m (0 5 ५६
5 a7 Sq =3) © UiO — के 26 3६५
_ = 91 ०0 न पे,
a = a ०.6 ७ ७ 9TH" es = 9 5
9 513.5868%| oa, sslo| oF] 22 32
” Ian O ty a O
OQ 9 9०9 58 oO =. Ch lee + at at 345
SElama Vs! FOSGID aol sa o £0
= og | = ५० (2 o> “I> ans = 3 3G
co 6 ० ० /“+ Q2q|/Z) क> So ४ oO =
= 0 oO. 5S > Oc = (0065 S 2s
O ClH oy Oo +S <. 0 ® =
हु ४. 9. 2 ४5 | 29 =f ० 0
>५ <F/G325 tO ®o| +f 2,
™ COR OO = > oO aM. Q.
— ४9 lew o3 aa 0 > OG
गा o0n2O 5 a Do 2 कक
0. 9 ot o2g 52) o39 ० अं
| Q= 05 =< OB QO rv © 7 3 2.
8 a8" oe - 9 3। ७0० a 2
9 3 5 O ०00५० = ( Sm @
=. % 2 < 2 >3 ०? —< sh की = wo
= =
9 fa oa a 6 क ५, = ae as
Oo > g
o.2 TUDO oO< at ae
Qo fQAD oO Qn 2. Oo = Oo =
(2 > 5 0 Z COS _. © sas SD
‘a ५ ०५ =O = 99 25
५ % OFS 5 हार @ a al a
"cee ° oo oe
= = re a‘ a‘<
(9 9) OQ => हो - ©
0) | —: QO a 5 o 69
o (9 (५0 = © Sh a iy
» 3 ००५० _.2 (छ 5 0
509 ei & = i 7 ~
oD > व © ®
o 8 = ई O< oO. ०.
५० 8 a= o 2
aT TY ए (9)
कह हू, कक कल oS) 86 06
62S as Oo fro 2goao +0 < नऋ a
< a —s as) See “= A =p
a0/82 9 2 ठ 8-5 358 97 oa, 22 oo 9
Oo t/C [a 3 ५9 1४ MP a ५० a © Q (9
>५|० ०8९85 ' थेछएि ७ 90 9 390| Qe o>
<@| °Q°> ae i om S|) 9a x 9 O
55.1. 2. = 9 x
> 2a FES ४9४ 36590 31 ०98 20 8
81 65 S Oo; CR E53 Oo} 2B » 20
oO] Q@& F353 © an = Ar ५७ =.
= a0 =i o
oan a कं ९४0 6 | 5s Oss
9० <0650590 QO no - =. =. a
a> > (0 —s a O o= = =
= Oo ५2 ९० 6 (5 o| < 3 ey
0 Oo 36 +8 ०. a a a9
5 > ०85 Q 9 ७ oOo ® = 0) 6)
रह 1 0 लि न ऑल = _* of »
© oO =. cago o| 2 ® ५९.४ ५
oe = 25 9) — = cm | NO nN
ठ =Oo —| O09 @ o| @9 Do OO
> तन + 20 + © © +
= oO an 9 a
81 5०.6 2.| 58. > o| oD god
S| 7298 = On F <| 009 000
2 xs bo है) 50०0“ 6 @ ta 3 ha
- A — 6 ५| 9B as खरा 9 eon
ct OM < 6 ठ्कऊ्र+ o A » 2
>>| छापा Ss = TOoOOS ol sx £ दि छल,
3 soo ™ — oO - O TO?
«| 3990 >% ९, 58 = ५ के
= o> =. 35 © 0. 95 9५
25) ५» =| Aso 0. 6 ७ 50
ले 59955
0 ia = +O =F 0 = 9
छठे a > = ठ ठ 0
90| aa®s o| orQoe? = & o =

<!-- page 8 -->

= <. aie
| <
S af =
So| Bae o>
oO < =33 छठ
oe =”
0 — a (9 a =
०0५ o 4 +5
oy oO ¢ O m
3 o & ७ (9
तठ हा os
2 = 2 0 00
() oe > a
° 0) QO: 3 (9
ठ ca Q
a So 8०५.
<
3 o = 39
> <— = ge
© ® © 38
3 = OQ pa
ao ec
e c 3 >
9) 3 UO a oO
OQ Q 0) (9
= As = ©
a aS cn
Oo oO o 2
5 O — Se
>
= oO A
O = @
2 a2
Sh SF QIN® Sos ae
= + यम
ठ 9 Sees eeQSaS®aSess
ow Oe a geSseseessas
“" fr % ५. 5 5: ५ oo. = ०2559 “1 प्य
= 9 eslaragteog zi fa Q so eaeaece
so) S23] ते ठेढे हे है 6 53 80.*.8 92 %०१५१५२2.०5 66
95 2 6 oR? a3 0¢ O75 re 3733 Se
e2| F331 goo »* v0age®i< e287 28° §$o
(9 oo 2 Oo —~ Qaon™ nh a O > oa 3 0
90061 “5 ८ oo cma 59 =o ee 9
N <a) « Oo O56 Ze? wo S oe s2e2"* 6
है ठ ४५९ # 68 5 2. <2 no & =: NO oO =
So on 3 2239 eg09°%% yo Ss =e == *
2 5 0 0 = .8528 5 ® ५ भा
0 aa a ठे ८ 5 O29 wy Se=sape
Oo = S6oa0S8a “+ — 2 OO =
N : ch sd os ~ = Oo os’ oO
© 0. = econ @ & & 39 2. 0-20
- ©® 3 a 2 Oo 2 ध्ट See FOC
me en 2 =~ oT c < क्र फ कफ ८:%द८
2. 65 छह 4293 छे» 50४ Qe? Flo
=| &5 0 ७ oO ता 9 9 9 5५5
०2%०| =oo GS ea net tel Dal की
S| ol 35 HICSS S
Sq} 0 2y $3 91S 537959852233
ct oO o <. saj= Oo 3009 Ho ९
> 2 at < oO: 3 < oO — O
o2| sO 60 8 9 | % : 296 6966 9 a
५) (9 ५0 a”
=—=4) af 0 69५9४ >669 569 6 5
9 9 oo >. 06 (5 0 ४ oS O53
+O a 22 ohio ee ee’ ss =
®o|l ak 97 o|nsa< ० 2 =
sO) Fad o2o|\Qeac =
५9 जाप 2205/2 => oO. Go aoOo
< 5 +S alo @aA7G aa? =
o = c= += O|S —2 =f St _. 9
Qo 225 eS ease asO8<5° 8
9 © 5० 6)% $7 5150 Sm S2<33Q"
N o = ob T< 59 ५० 20०2५ = on 3
"QO on? ५०० [६८55 a, 0%
+O} 0०५०० a ects ses ™ os 2
O (४9 — ct seeleooSs3 > ©
O w oO N Q|0< 9) a> 2,
0° 5 2 9०9 091 35 22 Sa me
= O > ¢ SOR) gtaeeadt *
aot car (9 ५) co =" => np -Q
oa 9 656 ०. 00 cf o225 ट 8 9 €< 5.
धर = oe 3S O $42 33324
-~ आए 357 o©oa 8-59 ४ ॥ है ७ 6.५
| O8 & es eae 3७5० ०.
है| 2 6 है 68 298 _ F< 338
a| 22a S8El Suns hPGR8s
oO = = 9 ५) ath ON, ee 5८०9 9७94 ४५. -+
= ao 320 8095 568 8 "85
- aoe coach —- =
5 =i. 3@qQ O DS S28 Se8 aa
= = Soo SO-82973R08
50d on a :%»०53+<

<!-- page 9 -->

| | 2
5.:55%5 8 है & ऊे 219५ 2 < 3060०160०[16 ७56 & ैए|65+<29
>56£23५68 Ole oe a§7|§s| Sa ~saglSsxs
sEzE524¢53 0/99 0 =<o<sl 8.45 28 9 (७
S<>5 छ ५996 wle B 2 oo 5 e323) 2.6 =
> fF 7G 3|9 oO = OS *“| BoM | Sas
9) (9 = an Sie oS मर © O = oO © Oo +S
0 Gr 3-3७ ७3६०३ +n 6 qea-| of
© | 6 _ 5 ०७ +51 0 00 ५ ४५७७
पक + =O (0 9) < oP? के
छे (0 =.0 = © Sie ms ०0७

or 0०0 0०0 252 ५०८६ = » ठै. >> 5| ०-९४
०? ्+- 1 82%: om] ऋक 0 0 >9.0| ०५ 6
~200|00 # oM}| 8 > os 7 2.
9TH SKS 2 (9 on Pf 5 5 =°0
oma —:
S=plF< 5 oo] & mw & 2 2
Oe QAalaw < ro = So ha ToS
125 ¢ ऋ 0 50 के +! oO oo ५3 ४०७७
<oa-5 ~|\2 028 - ५5 S545. .2/ 2=56
9 “oF og Pol a +o p>?! O55,
oo 9 323 (9 a+ 9 ene =QN
oa Bigg ५ ou! ५० a383 ©
on OH मी 5 352 Do 5 0 %०206590 ०५2२०
= 5 Dole (0) < +h = jy =: th aA बक
3 w | =. ५2 J = ® @ 2
20 ” —|® 2 o QO} 5 6 = 56%
स्ऊे ८+ 99 (“5 (9 & oO ce > = 5 + Q
®OnNxl 35 Ss 7 oo Jo oO
130 4 © = oF = = sh OS oars
=
O
a
“Tl
O
A
>
.
00 है.
p>
“U
"U
है
()
>
=
z Z
5 6 oO sus 2 Fz oD =
“i 60 >72.|. oO 6 0 ५965
a e ogo?! © +O ५ 0
हर = 3 ७ श्र > 2 5 2
c =< a as 95
cn 910 ५) 0 @ a
8 8 231 0 =O » ©
9. a. = ( ¢
<= 0 Oo 5
aces =
5 9) ५0 (३ 0 ०
५) a a =.
av >-* 0५2 = ©
= 5 33) 83
“ 3S ०. 90, 52.
न ०. 9) ५9 +>+
al 5 oS * 98
Oo ni oO Oo
ns 00 ® > @
A) 9) 2
© o a 2 ते
Q Oo 53 0 +
Cc < Qo > 2
— oO (9 —
5 5
8 न _ 8
‘ © छः ©
= © a
=" Oo = |
५) = ©
- <, हु
Q
= o ®
5' 9 5
०

<!-- page 10 -->

क्‍ | | :
a — — -_— 9)
mM of een On ous s
५2 एड. oO oo 36l=s5
Z| plz9geS mO|° ® S
< 235035392 © 3a
< 9O30002 Me हे
[7 rho Oo -
0) ofeas%m® f| oF
a 33 °9935 Flo oh.
eke 3 oF 21 Oo
rE BOSD 6 गा
0 &553+5 51 90०0
Ofc o0 &. 5
©. ie ee P - =
o ARORS पका Beds
< Og” के (90 o—
fo @ € 3 S| &
Oo > = 3 Qo
ST हा का हे or xX
= = = sh 9) (9
0 © + 0
os + = +
५१ (0 = 00०
oO a =
o (0
Qa ५9 6 ®
To = ie aS
+ TO a <
0 = (9 oO Oo
9 3 3) @ >
_ 2 oO 0 < @
no >> &Sogo cw
2p Py 53. “++ का oo
of om 2500! oF
(2 oF P=VD ++ Sow
aA*r>o oOo. ae 0
Q = —-. ७ 9 5० छ VS
Ve OG “ S35 6 Cc
9) > oD = 99%
Os zs 9 OS ®
2 ” > oc —~c
3 oc 5. a ND =:
५0 +O > = ‘aot SF
(9 +> 2 em
(9 oO (9
(9 OQ. ८ 7०9०७ =
Oo on<| S3
of Oo ©
22a 5 a0 U =
oc 25 0५७९) +
os =. TH
0 0 a oF 5
ono. = > 09 DADO DV
®og ane = 9 || 26०9 5 (८३ z
na2TSTHMO — 203240 m 0
oo z= 9» o Gn 02 5
= Ss ao = @ 0 ५७ ot ५9 09) ड QO
Ss Psa Go @ ० 9 - ० 9) हट क्र
99 छ के w 0 ना 8 9 Q<s 3
9 =.= MU = * @9@ as>"°2OS ५
a R=Eo 8 0 — —" & (9
TO “ 90
237096 ह ढ़ 8॥| ढे 8०558
93 (00 = ०-25 + = (0 (20.
3 aad (9 nat Oo oa
ठ पक 9 O ०. 6 जीफछ 9 न
02.2034 ca0o2D
ह =P5Mo o> ५22 ५० न च5
= ee > Oo - (0 5
0) < oh ७
ov [1 —
6 6 95 > 3=06
=Ars yl Oral
० ०6४३९ o| 3oe73
6 © 25:9 cues ५) 3 7# (८:
= n= गा +> OO%AV06
onate 25 cs =
oRO5 s| oS <SS
007 ** Otome. =
<5553869%. 59029030
= “: Oo 0 © = ow
So OG = =. 9 :5 0०9५ mi
७9 ० ८०. >>) © ०५४७9 590
Sa ठ = 3° ODT
Nea@eoe 9) = ey
Son = ~ ~O =O
oS oo "B30
५) ५) Cc + ©
210 30 5 ठ ऊ ७ 65
Qo< a o28o25
