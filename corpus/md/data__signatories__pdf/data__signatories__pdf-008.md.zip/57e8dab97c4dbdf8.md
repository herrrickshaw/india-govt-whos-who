---
doc_id: "57e8dab97c4dbdf8"
source_url: "https://dof.gov.in/static/uploads/2025/08/536c87901718c12882c2d5d7a1cdf9a9.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Appointment of Shri J.R Rishi Keshav 2nd PA in personal staff of Hon'ble MoS (Dr. L. Murugan)-reg"
date: "2021-12-02"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7f405a975711ba33"
---

<!-- page 1 -->

No. A-1 1012 I 06 I 2OL9 - Adm n' l- Part( 1)

Hl{dS{E')R
Government of lndia

]{cF[qr(,r{, q{qloq 3fu g{l{t ri7rcq
Ministry of Fisheries, Animal Husbandry and Dairying

qgqreHBl{Fr

Deoartment of Fisheries

1't Floor, Chander Lok Building
36 JanPath, New Delhi
Dated the

,2021
I

Lt"A, Dgu'"nlP^"

OFFICE ORDTR

with the approval of the competent Authority, shri I'

R' Rishi Keshav is appointed as
& Dairying
Minister of State for Fisheries, Animal Husbandry
2nd pA in personal staff of Hon'ble
w'e'f 01'09'2021 (FN) on co-terminus
(Dr. L. Murugan) in Pay Level- 7 (Rs. 44,900- L,42,40O/-)
basis with the Hon,ble Minister or till he

ceases to function as 2nd PA to Hon'ble

Minister or

until further orders, whichever is earlier'

M,
\

(Yogir
U nde r Secreta ry

to the .

Ti"il]lr:lrrli

E-mail- ad m n-fishery@dof ' gov'i n

Distribution:-

1. ShriJ. R. Rishi Keshav, 2nd PA to Hon'ble MoS (FAHD)' DoF'
& Dairying

2. PS to Hon,ble Minister for Fisheries, Animal Husbandry
& Dairying (Dr' L'
3. PS to Hon'ble Minister of state for Fisheries, Animal Husbandry
Murugan).

4. ps to Hon,ble Minister of State for Fisheries, Animal Husbandry

& Dairying (Dr' sanjiv

Kumar BalYan).

5. PSO to SecretarY (Fisheries)'
6. PS to JS (MF).
7. PS to JS (l&A).
8. NlC, DoF, Krishi Bhawan'
9. PAO, Sectt-I, DoF, Krishi Bhawan' New Delhi'
10. US(CASH/Budset/l FD) / US(Ad' I l/vie')/D
11. All Officers / Sections in DoF'
12. Personal File/ Service Book'
13. Guard File.

Do'

+
