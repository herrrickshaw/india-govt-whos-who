---
doc_id: "565e1adaa10cbef7"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/fe3ad961faed8670d736d8c969b0629f.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "National Programme for Prevention and Control of Non Communicable Diseases (NP-NCD) Guidelines-Operational Framework Management of Common Cancers"
date: "2020-03-20"
pages: 44
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0772ab728d1dcc0b"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

HEALTH M

O
ISSI N

NATION

AL

Operational Framework
Management of Common Cancers

Ministry of Health and Family Welfare
Government of India

<!-- page 4 -->

<!-- page 5 -->

Message
I am happy that my ministry has developed an operational framework for screening and
management of common cancer. On June 22nd this year. I had released guidelines for prevention,
control and population level screening of diabetes, hypertension and common cancer. This
framework provides mechanisms to operationalise screening and management of common
cancer at field level. The framework fulfils the need of complex requirements for screening and
management of common cancer viz. breast, oral and cervical cancer.
2. Early detection of cancer can lead to better health outcomes. This initiative of implementing
population level screening for common cancer can save many precious lives and improve quality
of life of many more. Population level screening envisages screening for risk factors, which will
generate awareness on healthy living, thereby focussing on prevention of the diseases. Cancer
share common risk factors with several other common Non-Communicable Diseases, such as
diabetes and heart diseases. Therefore, preventive efforts shall address other Non-Communicable
Diseases as well.
3. Our ambition to deliver high quality health care is to be matched by an equal commitment
to deliver on the ground. Support to frontline workers and primary health care providers and
strengthening of our secondary care services are necessary to provide early detection and
follow-up services.
4. I urge States to take up the issue of cancer prevention, screening and treatment as a crusade
and to use this framework to create the mechanisms needed to provide effective screening, care
and treatment to all.

(Jagat Prakash Nadda)

<!-- page 6 -->

<!-- page 7 -->

Message
Cancer has direct effects on individuals, their families and society as a whole. Premature
deaths, the economic burden due to lost productivity and the costs associated with illness and
therapy take a toll at the individual and population level.
This operational framework lays out the broad guidance for treatment of common cancers
and is to implemented in continuum with and build on the recently issued screening guidelines
for common non-communicable diseases.
We must consider how to most effectively use available resources in providing treatment
for common cancers. Various social protection schemes of the State and the Centre will need to
be synergized to address the costs of treating cancer.
There are other actions we need to take in addition to prevention and treatment. We must
strengthen cancer registries and undertaking research in studying the burden and pattern of
cancers, their impact on the poor, and strategies to address risk factors in different contexts and
among sub populations.
Operationally States would need to adapt some of the delivery strategies, but the
fundamental principles of access, affordability and university must underpin treatment for those
with cancer.
Implementing a programme outlined in this operational framework, such as this signifies
a change in the way our services are delivered. It will place stress on our health system, but with
several new schemes that have just been announced, including for free drugs and diagnostics
and strengthening district hospitals, and with the country moving forward on chronic disease
care, I am confident that States will be able to meet this challenge.
(C. K. Mishra)

<!-- page 8 -->

<!-- page 9 -->

Dated: 26/08/2016

Message
Cancer is a growing public health problem concern in India. There are about 30 Lakh cases
of cancer in India and about 13 lakhs occur every year. One-third of all cancers are preventable
including tobacco use related cancers. Another one-third can be treated effectively if detected
well in time. One third of cancer cases are seen in advanced stages and successful treatment
may not be possible. Efforts from Govt, and community are required so that the cancer cases are
detected and treated effectively in early stages.
In India, cancer control is a part of a comprehensive strategy for the prevention and
control of non-communicable diseases that simultaneously promotes population-level health
promotion and disease prevention and actively targets groups and individuals at high risk, while
maximizing population coverage with effective treatment and care.
‘Operational Framework: Screening and Management of Common Cancers’ has been
developed with series of meeting with experts and bearing in mind the feasible strategies
in early detection of common cancers namely breast, cervical and oral cancers. States are
expected to use the guidelines to build upon the implementation of NPCDCS while integrating
into Health systems.

(Dr. Jagdish Prasad)

<!-- page 10 -->

<!-- page 11 -->

Message
A country such as ours, with the ongoing epidemiological and demographic transition
and significant diversity, needs to consider not just how care can be delivered within the
context of local health systems but also conform to the highest medical standards.
Therapeutic advances in chemotherapy, surgery and radiotherapy have helped in
reducing cancer related mortality. But the disease necessitates long term follow-up, a critical
component of care in chronic diseases and one with which our service providers, especially at
primary and secondary care levels, are not yet familiar.
The recently launched operational guidelines for screening and prevention for common
non-communicable diseases including cancer could be seen as a cornerstone of India’s
approach to cancer. This operational framework for management of common cancers builds
on and is to be seen in continuum with the screening and prevention programmes.
We need to develop and mount a unique approach to dealing with cancer. The framework
is one of a series of guidance documents for addressing non-communicable diseases. The focus
on these three cancers is based on the fact that they are common, amenable to early detection
and have a high potential for cure. However, it also lays the blueprint for a broad approach to
treatment of other cancers.
The operational framework is just the beginning. States need to fill in the framework
with local adaptions, create referral networks, and build partnerships with community and
community based organizations not just for care but for support, rehabilitation and palliative
care for cancer survivors and their families.

<!-- page 12 -->

Under the umbrella of the National Health Mission, we have made progress in reducing disparities
associated with access to care for maternal and child health services. We need to use those
lessons to ensure that even as we initiate such treatment programmes, we are mindful of the fact
that these disparities can be exacerbated in cancer diagnosis and treatment. We need to tailor
strategies so that the poorest and the most vulnerable have equal access to cancer prevention,
screening and treatment services.

(Arun K Panda)
AS&MD, National Health Mission

<!-- page 13 -->

FOREWORD

26th August 2016

The challenges to caring for cancer patients and cancer survivors are multiple and complex. The data
from India reveal low cancer incidence rates but relatively high age specific death rates indicating
that we need to strengthen early detection of cancers and appropriate and timely treatment.
This operational framework lays out broad programmatic guidelines and screening and
management algorithms for three common forms of cancer- namely oral, breast and cervix that
constitute a public health priority and should be understood and implemented in consonance with
the Guidelines on Screening for Diabetes, hypertension and common cancers issued recently.
In the past decade, states have effectively used support from the National Health Mission to
strengthen their health systems, supplementing and complementing state budgets. The rolling
out of screening and treatment programmes for cancer will test the resilience of these systems and
administrators and implementers alike will need to be mindful of the challenges this will pose.
Treatment for cancer is not to be seen as a vertical intervention. Under the National Health Mission,
support is being provided for programmes such as the National Programme for Prevention and
Control of Cancer, Diabetes, Cardiovascular Diseases and Stroke, the population based Screening
programme for prevention, screening and control of non- communicable diseases (NPCDCS) and
the National Programme for the Health-Care of the Elderly (NPHCE).
The approach that is highlighted in the framework which is distinct yet complementary to
the programmes mentioned above is the emphasis on the primary and secondary health care
services as the key points for screening and diagnosis for cancer.
While strengthening our tertiary level, regional cancer centres is important, innovations in treatment
in a few states demonstrate that it is possible, with appropriate training and support to provide
care for patients at the district hospital. The framework provides for strengthening district level
histopathology facilities, and to create local hubs for timely diagnosis. States must consider innovative
ways to partner with and collaborate with credible cancer care and support organizations.
Patients with cancer face multiple barriers. This framework is an attempt to address some barriers
related to treatment, by clarifying levels of care at which confirmation of diagnosis, treatment
and management need to take place.
Successful implementation of this framework rests with the state governments. We look to
them to leverage and supplement existing resources in tandem with what the framework offers
to provide timely, effective and quality treatment to those who seek care in the public health
system, thereby building the community’s confidence and trust in the system.
Finally, I would like to thank the technical experts who spared no effort, in ensuring that the
protocols and algorithms articulated in this framework are consistent with existing evidence and
appropriate for the context of health systems of our country.
(Manoj Jhalani)

<!-- page 14 -->

<!-- page 15 -->

List of
Contributors

1. Mr. C. K. Mishra, Secretary, Ministry of Health and Family Welfare
2. Dr. (Prof.) Jagdish Prasad, DG, Directorate General of Health Services
3. Dr. Arun K. Panda, Additional Secretary (Health), Ministry of Health and Family
Welfare
4. Mr Manoj Jhalani, Joint Secretary (Policy), Ministry of Health and Family Welfare
5. Ms Limatula Yaden Director (Nation Health Mission - I), Ministry of Health and
Family Welfare
6. Mr Rajeev Kumar Director (NCD) Ministry of Health & Family Welfare
7. Dr Rajani R. Ved, Advisor (Community Processes), National Health Systems
Resource Centre, New Delhi
8. Dr Garima Gupta, Senior Consultant (Community Processes), National Health
Systems Resource Centre, New Delhi
9. Dr Mayank Sharma, Consultant, Ministry of Health and Family Welfare

Operational Framework : Management of Common Cancers | xiii

<!-- page 16 -->

<!-- page 17 -->

List of Technical
Experts

1. Ms. Vini Mahajan Principal Secretary, Health, Government of Punjab
2. Dr. Veena Dhawan, Maternal Health Division, Ministry of Health and Family Welfare
3. Dr. Mohammed Shaukat, Deputy Director General, MoHFW
4. D
 r. Sudhir Gupta, Additional Deputy Director General, Ministry of Health and
Family Welfare
5. Dr. Bela Shah, Sr. Deputy Director General, Indian Council of Medical Research (ICMR)
6. P
 rof. Arvind Rajwanshi, HOD Gynaecology Pathology, Postgraduate Institute of
Medical Education and Research (PGIMER), Chandigarh
7. Dr. N. V. Kamat, Principal Advisor, Indian Medical Association
8. Dr. Sudeep Gupta, Deputy Director, Tata Memorial Centre (TMC), Mumbai
9. Dr. Prashant Mathur, Director, National Centre for Diseases Informatics and
Research(NCDIR), Indian Council of Medical Research (ICMR)
10. Dr. A Nandakumar, Director in-charge, NCDIR, Indian Council of Medical
Research (ICMR)
11. Dr. Amar Bhatnagar, HOD Cancer Surgery, Safdarjung Hospital
12. Dr. D K Shukla, Scientist G, Indian Council of Medical Research (ICMR)
13. Dr. Tanvir Kaur, Scientist F, Indian Council of Medical Research (ICMR)

Operational Framework : Management of Common Cancers | xv

<!-- page 18 -->

14. Dr. Ravi Mehrotra, Director, National Institute of Cancer Prevention and Research
15. Dr. Roopa Harisprasad, ICPO, Indian Council of Medical Research (ICMR).
16. Dr. Shalini Gupta, CDER, All India Institute of Medical Sciences (AIIMS)
17. Prof. G K Rath, Chief, Dr. B.R. Ambedkar Institute-Rotary Cancer Hospital, All India
Institute of Medical Sciences (AIIMS)
18. Dr. Neeraja Bhatla, Professor, Department of Obstetrics and Gynaecology, All
India Institute of Medical Sciences (AIIMS)
19. Prof Anurag Srivastava, Department of Surgical Disciplines, All India Institute of
Medical Sciences (AIIMS)
20. Prof Lalit Kumar, Dr. B.R. Ambedkar Institute-Rotary Cancer Hospital, All India
Institute of Medical Sciences (AIIMS)
21. Dr. Naseem Shah, Centre for Dental Education and Research, All India Institute of
Medical Sciences (AIIMS)
22. Prof. Mahesh Verma, Director- Principal, Maulana Azad Institute of Dental
Sciences (MAIDS)
23. Dr. Sangeeta Talwar, Prof HOD, Maulana Azad Institute of Dental Sciences
(MAIDS)
24. Dr. Renu Garg, Regional Advisor, SEARO, World Health Organization (WHO)-India
25. Dr. Atreyi Ganguli, National Professional Officer, World Health Organization
(WHO)-India
26. Dr. Fikru Tullu, Acting Coordinator Health Programs, WHO Country Office India
27. Dr. Pratima Mittal, Professor and Head, Department of Obstetrics and
Gynaecology, VMMC-Safdarjung Hospital
28. Prof. J S Thakur, Professor, School of Public Health, Postgraduate Institute of
Medical Education and Research (PGIMER)
29. Dr. R. K. Grover, Director and CEO, Delhi State Cancer Institute
30. Dr. K. K. Aggarwal, Honorary Secretary General, Indian Medical Association

xvi | Operational Framework : Management of Common Cancers

<!-- page 19 -->

31. Dr. Puspha Singh, Professor and Head, Department of Obstetrics and
Gynaecology, Dr. Ram Manohar Lohia Hospital
32. Dr. Preet K. Dhillon, Epidemiologist, Centre for Chronic Conditions and Injuries
(CCCI), Public Health Foundation of India (PHFI)
33. Dr. P. Raghu Ram, Association of Breast Surgeon of India, Hyderabad
34. Dr. O. P. Kharbanda, Dental Surgeon, All India Institute of Medical Sciences
(AIIMS)

Operational Framework : Management of Common Cancers | xvii

<!-- page 20 -->

<!-- page 21 -->

Contents

List of Abbreviations

xxi

Introduction

1

Rationale

3

Objectives of the Framework document

5

Section 1: Organization of referral and treatment services

6

Section 2: Human Resource Requirements 

11

Section 3: Training strategy

11

Section 4: Behavior Change Communication 

13

Section 5: Programme Monitoring 

13

Section 6: Financing­­­­

14

Annexures

15

Annexure 1a: Screening and Management Algorithm for breast cancer

15

Annexure 1b: Screening and Management Algorithm for cervical cancer

16

Annexure 1c: Screening and Management Algorithm for oral cancer

17

Operational Framework : Management of Common Cancers | xix

<!-- page 22 -->

<!-- page 23 -->

List of
Abbreviations

ANM

Auxiliary Nurse Midwife

ASHA

Accredited Social Health Activist

CBE

Clinical Breast Examination

CHC

Community Health Center

CVD

Cardiovascular disease

DH

District Hospital

GoI

Government of India

HPE

Histopathology Examination

IEC

Information, Education and Communication

LEEP

Loop Electro-surgical Excision Procedure

LMIC

Low/Middle Income Countries

MO

Medical Officer

MPHW

Multipurpose Health Worker

NCD

Non Communicable Diseases

Operational Framework : Management of Common Cancers | xxi

<!-- page 24 -->

NPCDCS

National Programme For Prevention and Control of Cancer, Diabetes,
Cardiovascular Disease and Stroke

OVE

Oral visual examination

PHC

Primary Health Centre

SC

Sub Centre

TCC

Tertiary Cancer Center

VIA

Visual Inspection with Acetic Acid

xxii | Operational Framework : Management of Common Cancers

<!-- page 25 -->

Introduction

The International Agency for Research on Cancer, the GLOBOCAN project1 has predicted
that the cancer burden in India will rise from nearly one million new cases in 2012 to
over 1.5 million i e., 1,569,196 by 2035. These projections also indicate that the absolute
numbers of cancer deaths will also rise from about 680,000 to about 1.2 million in the
same period. Estimates from the data of the National Cancer Registry Programme (NCRP),
Indian Council of Medical Research indicate that there are about 14 lakh incident cases,
38 lakh prevalent cases and 7 lakh cancer related deaths per year2.
Costs of care for cancer treatment are high, and studies show that almost three quarters
of cancer expenditure in India is paid out of pocket, despite many welfare schemes
for cancer treatment from both state and central governments3. The odds of incurring
catastrophic hospitalization expenditures are about 160% higher with cancer than
for hospitalization costs for a communicable disease condition. The odds of incurring
catastrophic spending with cancers are nearly double compared to accidents and CVD4.
The financial catastrophe experienced by the cancer patient and her/his family on
diagnosis and treatment, could likely result in psychosocial stress.
1.	Ferlay J, Soerjomataram I, Ervik M, et al. GLOBOCAN 2012 v1.0, Cancer Incidence and Mortality
Worldwide: IARC Cancer Base No.11. Lyon, France: International Agency for Research on Cancer, 2013.
http://globocan.iarc.fr
2.	Indian Council of Medical Research.Three year report of Population Based Cancer Registries, 2012-2014.
Bangalore: National Centre for Disease Informatics and Research/National Cancer Registry Programme,
2013, 2016
3.	Pramesh CS, Badwe RA, Borthakur BB et al. Delivery of affordable and equitable cancer care in India.
LancetOncol. 2014 May;15(6):e223-33.
4.	Ajay Mahal et al 2010, The Economic Implications of Non-Communicable Disease for India,
accessed from http://siteresources.worldbank.org/HEALTHNUTRITIONANDPOPULATION/
Resources/2816271095698140167/EconomicImplicationsofNCD for India.pdf

Operational Framework : Management of Common Cancers | 1

<!-- page 26 -->

Several states have developed schemes for early detection of cancer, and access to
treatment through social protection schemes. The National Programme for Cancer,
Diabetes, Cardiovascular Diseases and Stroke (NPCDCS), programme which is also
funded through the National Health Mission, began with screening and early diagnosis,
through an opportunistic screening approach at the level of the Community Health
Centre and the District Hospital, with treatment being provided at the Regional Cancer
Care Centres or medical colleges.
The three most commonly occurring cancers in India are those of the breast, uterine
cervix and oral cavity. Together they account for approximately 34% of all cancers, and
hence are a public health priority in India1.

1.	Ferlay J, Soerjomataram I, Ervik M, et al. GLOBOCAN 2012 v1.0, Cancer Incidence and Mortality
Worldwide: IARC Cancer Base No.11.Lyon, France: International Agency for Research on Cancer, 2013.
http://globocan.iarc.fr

2 | Operational Framework : Management of Common Cancers

<!-- page 27 -->

Rationale

Survival rates for all three cancers are good, provided they are detected and treated in
the early stages5. Thus for example, the five year survival rates for early stage cancers are
60.2%, 76.3% and 73.2% for oral, breast and cervical cancers respectively. The prognosis
for advanced stage on the other hand is poor, with five year survival rates being 3.3%,
14.9%, and 7.9% for these cancers.
According to GLOBOCAN 2012, India accounts for 7.2% of global cancer incidence, but
in terms of mortality, India accounts for 8.3% of global mortality. This highlights the fact
that cancers in India tend to be detected late, leaving little opportunity for effective
management and patient survival.
Each of these three cancers is amenable to early detection and treatment, reducing the
burden of cancer related mortality and morbidity. Additionally, cancers of the oral cavity
and cervix are amenable to secondary prevention because they can be detected and
addressed at precancerous stages through screening using cost effective techniques.
Oral cancers are preceded by disorders that can be readily detected in the oral cavity
because of an easy access of the site. Early detection of these lesions is possible during
routine general health check-ups/screening by doctors/dentists/health workers or by
self-examination. Clinical Breast Examination (CBE) performed by trained paramedical
personnel such as female health workers is a low-cost approach to breast cancer
screening for low and middle income countries. It has been suggested that given the
late stage of diagnosis, average size of tumour at detection and socio-economic realities
of a developing country such as India, CBE may be a viable modality for initial, baseline
5.	Sankaranarayanan R, Swaminathan R, Brenner H, et al. Cancer survival in Africa, Asia, and Central
America: a population-based study. Lancet Oncology, 2010; 11: 165–73.

Operational Framework : Management of Common Cancers | 3

<!-- page 28 -->

screening of breast cancer. Cervical cancer is preventable if precancerous lesions are
detected and treated, thus preventing their progression to invasive cancer. Cervical
cancer incidence reduces dramatically when effective screening programs linked with
access to treatment are in place and are readily accessible. For this reason, cervical
cancer screening programs are life-saving and cost-saving interventions that can greatly
improve the quality of life for the women of India. Of the available visual screening tests,
visual inspection using acetic acid (VIA) has been most widely investigated and accepted
as a potential alternative to cytology in low resource settings.
The current strategy under the NPCDCS programmes relies on opportunistic screening.
However in our country given the significant information asymmetry that exists and
low levels of health awareness, screening for diseases where there are no obvious
symptoms is perceived to be an unnecessary process, particularly so amongst the
poor, for whom a day’s visit to the secondary or tertiary facility for screening, might
mean the loss of a day’s wages.
Instituting population based screening at the sub centre for these three cancers would be
particularly beneficial to women, given current levels of care seeking among women and
limited access to health services. Under NHM, population based screening including for the
three cancers is being initiated as part of comprehensive care which would complement
the NPCDCS. Recent increases in institutional delivery and improved use of contraception,
notwithstanding, attention to other aspects of women’s health has historically been low.
Such screening programmes would also address the issue of equity, since population
based screening would also enable reach to the marginalized, who are also excluded from
health care services on account of poverty and other forms of marginalization.
Thus in order for screening programmes to be easily accessible, particularly for women
and other vulnerable groups, they need to be decentralized to a level of care as close
as possible, and be undertaken on a population wide level for particular age categories.
Population based screening programmes also serve the purpose of increasing awareness
in the community about cancers, risk factors and the need for periodic screening. It also
enables an understanding of better health and avoidance of risk factors in the general
community. Effective and accessible cancer screening program ensure early detection
and increase in cancer survival rates.
However, screening programmes are not an end unto themselves. Screening programmes
for cancer, just as screening programmes for any other condition, require the assurance
of high quality treatment at affordable costs, regular follow up and accessible followup management as and when required. Cancer screening programmes require assured

4 | Operational Framework : Management of Common Cancers

<!-- page 29 -->

linkages at every level, with mechanisms in place for clinical handover and follow
up, including high quality documentation processes that are accessible at any level
of care at which the patient presents. Cancer screening programmes also require a
well-designed information communication strategy that focuses not only on increasing
cancer awareness and the benefits of screening programmes, but also on risk reduction
strategies. Providers also need to be sensitized at every level on the necessity of screening
for cancers opportunistically, and the importance of regular follow up at facility and
community level. Finally, mechanisms would need to be established, in order to link the
screening programmes to cancer registries across the country, for better information on
incidence and prevalence of cancer and related morbidities. States would need to ensure
that there is adequate linkage between the early detection strategy and the confirmatory
diagnosis and subsequent treatment. They must also enable expanded access to care by
providing cancer treatment at district level hospitals, and regional centers, rather than
locate treatment centers in metro cities and medical colleges alone.
The extent, to which cancer deaths and morbidity and consequences to family,
community and country can be mitigated, depends upon framing of adequate public
health policies and effective implementation.

Objectives of the Framework Document
This framework is intended to provide guidance to states for the management of these
three common cancers in rural and urban areas. This framework is not a stand-alone
document. It builds on the Operational Guidelines for Prevention, Screening and
Control of Common Non -Communicable Diseases: Hypertension, Diabetes Mellitus, and
Common Cancers, (Ministry of Health and Family Welfare, June 2016), referred to hereafter
as “OGs for screening for common NCDs”, in this document. The operationalization of
the framework also rests on the National Non Communicable Diseases monitoring
Framework and the National NCD Action Plan. For operationalization, the framework
relies on the existing health systems strengthening effort under the National Health
Mission (NHM). The objective of the framework document is to provide guidance to
states on the next steps after screening at the level of the sub centre/Primary Health
Centre for the three common cancers. States should adapt this guidance to their
contexts. They could also refer to other programme documents and guidelines that are
intended to provide a road map for cancer treatment6,7.
6. http://apps.who.int/iris/bitstream/10665/94830/1/9789241548694_eng.pdf
7. http://screening.iarc.fr/doc/WHO_India_CCSP_guidelines_2005.pdf

Operational Framework : Management of Common Cancers | 5

<!-- page 30 -->

The format is as follows: In Section 1, we present the broad principles for service
organization for referral and treatment. In Section 2, we discuss the Human resource
requirements and in Section 3, the training strategy. We discuss the principles on which
a behavior communication package should be designed in Section 4, Section 5 includes
a monitoring plan, and Section 6 discusses financing. Several of these components are
already included in existing programmes such as the NPCDCS and other components
of NHM. So far as possible existing HR is to be utilized, but in areas where RCH loads are
high, additional staff would be required, but this would vary on a case to case basis.

Section 1: Organization of referral and treatment services
A paradigm shift proposed in the OGs for Screening for common NCDs is to bring
screening programmes close to the community but retaining a balance between skill mix,
infrastructure and equipment availability and above all a strong and viable referral linkage
to diagnosis and treatment centers at secondary or tertiary levels. Once the screening is
undertaken and the service providers at the SC/PHC level identifies suspicious lesions,
they would:
¾¾

Ensure timely referral of suspicious cases to the PHC/CHC/DH for further
examination and confirmation by a surgeon, gynaecologist or dental surgeon,
as appropriate.

¾¾

Undertake appropriate and timely follow-up of those with positive or abnormal
results so that they access the services required.

¾¾

Support and enable referral of confirmed cases to cancer treatment services.

In a normative population of 1000 per village, the following age categories are to
be screened:
¾¾

Oral cancer: all adult men and women over 30 years.

¾¾

Cervical and Breast Cancers: all women over 30 years.

Based on Census 2011, this works out to be 37% of women and men in this age category
(188 men and 182 women). For breast cancers a much higher yield is obtained when
screening women over forty years, however for programmatic and operational purposes
the age for screening is being retained at 30 years for all common cancers. In the case
of oral cancers, evidence from studies8 demonstrate greater benefit in screening those

8.	Sankaranarayan R et al. Effect of Screening on Oral Cancer Mortality in Kerala, India: A Cluster-Randomized Trial, Lancet 2005; 365 (9475): 1927-33.

6 | Operational Framework : Management of Common Cancers

<!-- page 31 -->

who use tobacco in any form. Service providers involved in screening programmes will
be trained to prioritize screening among those with such behaviours and also include
people of younger age groups in screening programmes.
(i)

As has been described in the OGs for Screening for common NCDs, the first
level screening is to be undertaken by the ANMs/Mid level providers at the
Health and Wellness Centers (Sub centers), and by staff nurses at the PHCs. The
aim is to ensure that screening for all cancers is provided as close to the home
as possible by competently trained personnel in well equipped facilities and
ensuring privacy. Working towards this aim, in every district, a mix of PHCs and
sub centers/Urban PHCs/Urban CHCs would be selected so that the population
coverage envisaged annually over the three-year time frame is achieved.

(ii)

ANMs would be trained in Visual examination of the oral cavity and clinical
breast examination. They would also be trained in Visual inspection using Acetic
Acid (VIA) for CaCx screening. In those PHCs where screening will be conducted,
MOs and Staff nurses would also be trained. Staff Nurses and Medical Officers at
all facilities: PHC,CHC and DH would also be trained in these methods, so as to
serve as mentors and trainers to the next lower level and also assist when there
are shortages/absences.

Table 1: Screening and follow up processes
Type of
Cancer

Age of
beneficiary

Method of
Screening

Frequency of
screening

If positive

Oral

30 -65 years

Oral Visual
Examination
(OVE)

Once in 5years Referred to Surgeon/Dentist/ENT
specialist/Medical officer at CHC/
DH for confirmation* and biopsy.

Cervical

30-65 years

Visual
Inspection
with Acetic
acid (VIA)

Once in 5years Referred to the PHC/CHC/DH for
further evaluation and management
of pre-cancerous conditions where
gynecologist/trained Lady Medical
Officer is available.

Breast

30-65 years

Clinical Breast Once in 5years Referred to Surgeon at CHC/DH for
Examination
confirmation using a Breast ultra
(CBE)
sound probe followed by biopsy as
appropriate.

*The biopsy specimen either to be sent to the nearest Medical college or using the mechanism under the
Free Diagnostics Initiative under NHM,to the nearest NABL certified laboratory.

Operational Framework : Management of Common Cancers | 7

<!-- page 32 -->

(iii)

Where providers are trained and competent to perform cryotherapy for cancer
cervix, such facilities would be strengthened to provide cryotherapy for those
who are eligible based on accepted standards. Depending on state context
this could be at the level of a CHC/DH where the gynecologist trained in the
procedure is available. If the state chooses they could also train Lady Medical
Officers at the level of the PHC to perform cryotherapy. Training of such medical
officers would need to be undertaken at a tertiary centre under the supervision
of a gynecologist and the medical officer would need to be certified as being
competent. The session on level where cryotherapy is offered rests with the state
and is based on service provider availability. All CHCs in the district would be
strengthened to provide confirmatory tests for those screened and suspected of
abnormal test results. We expect higher false positive rates in the first two years,
until peripheral service providers gain confidence. Colposcopes and ultrasound
breast probes will be provided at CHC/DH level as appropriate to state context
and depending on availability of a trained provider.

(iv)

In order to roll out this component at scale, it would first need to be implemented
in different contexts for better estimates of how to organize work processes in
different contexts and the allocation of roles and responsibilities.

(v)

Implementation of this programme would be through the regular health system,
supported by the District NCD cell for planning, monitoring and reporting. The
first six months of the programme will be dedicated to planning details of the
roll-out, including HR recruitment as required, developing IEC strategy, building
capacity and planning implementation details specific to the state, including
phasing. The key principle here is that when screening is initiated, forward and
backward referral linkages must be instituted at the same time, so that there
are no delays in sending those detected as positive during screening to the first
level referral site for confirmation and then to the tertiary site.

(vi)

The state can roll out the program initially in selected districts (well performing
NPCDCS districts) and then expand to other districts in a phased manner
depending on the availability of human resources and infrastructure for
screening.

(vii) Once a district is selected, the state could decide based on levels of readiness,
HR and geography, those centers at sub center and PHC levels that need to
be developed as screening centers for cancer screening. These centers will
be equipped to provide basic level of services, including VIA, OVE and CBE,
breast health awareness, and service providers to be trained as appropriate.

8 | Operational Framework : Management of Common Cancers

<!-- page 33 -->

The principle is that the DH and CHC in the district would be equipped for
confirmation and first line of management and follow up. Till such time the CHC
are equipped with the equipment and consumable required for evaluation
and confirmation of screen positives, individuals with positive screening
results will be sent to DH for confirmation. (Flow charts for the entire process
from screening through management of all 3 cancers are at Annexes 1a-c).
(viii) Phased coverage could be planned as follows:
Table 2: Target population for screening year-wise, level-wise and type of cancer9
Phasing Year
1st year
50% coverage
2nd year
65% coverage
(1st year + 15%)
3rd year
80% coverage
(2nd year + 15%)

Level

Oral cancer ( men and Cervical and breast cancer
women) 30-65 years
(all women) 30 -65 years

Village

185

91

Sub Centre

925

455

Village

240

118

Sub Centre

1200

590

Village

296

146

Sub Centre

1480

730

(ix)

Linkage of each screening site to facilities with diagnosis and treatment should
be ensured. Therefore, each individual screened positive at the SC should be
referred to the PHC/CHC/DH as relevant for confirmation, additional investigation
and appropriate management.

(x)

District hospitals should be strengthened as the ‘First referral’ point from CHC/
PHC/SC. The District Hospital is expected to have the capacity to provide
diagnostic breast ultrasound, Colposcopy, Cryotherapy, Loop Electro Surgical
Excision Procedure (LEEP) and additional diagnostic services, including biopsy.
In some states where the CHC has the full complement of specialists, they could
also serve to undertake similar functions.

(xi)

The DH will serve as the training hub for staff of SC and PHC. The dentist/surgeon/
gynecologist will be (re) trained at the Medical Colleges. Medical officers would
be trained in cryotherapy in tertiary centers/medical colleges.

9. One district (based on 20,00,000 population).

Operational Framework : Management of Common Cancers | 9

<!-- page 34 -->

(xii) Every District hospital would be linked with the nearest tertiary center or
medical college so as to facilitate referral and follow up and also as a mentoring
cum support institutions.
(xiii) Training for the team at the periphery would need to include, in addition
to competencies in undertaking the screening procedure itself, skills in
communication. Frontline workers and service providers need to be able to
communicate not just signs and symptoms for early detection but also skills in
communicating reassurance and support to individuals and family members.
(xiv) Medical Colleges will provide training for providers from CHC and DH in appropriate
management of patient referred from the screening process. These centers will
provide advanced care and assessments for those referred from the district with
suspicious lesions and/or confirmed cancer, initial and on-going therapy for cancer
including surgical approaches, chemotherapy, and radiation therapy.
(xv) Currently very few districts in the country have histopathology facilities. There
are a few options that states could exercise to ensure that biopsy facilities can
be undertaken at the level of the district itself. A histopathology lab could be set
up for a cluster of districts and serve as a hub for nearby facilities. Alternatively,
facilities under the Free Diagnostics Services scheme could be utilized to
send the specimens to the designated centers. No matter what the choice the
fundamental principle should be that the patient does not have to travel too far
from her/his home, else the loss to follow up will be high. States could, in the first
few years elect to enter into partnerships with credible agencies to undertake
biopsy for confirmation, but the local context will determine the modality.
(xvi) In those districts where there are no specialists are available, states could
consider the possibility of including these districts in later phase after training
the existing manpower in screening or recruiting specialists in these centres.
(xvii) For confirmed cancer patients, the state will need to ensure admission/treatment
at the tertiary center. Follow up of such patients would be undertaken at the
DH/CHC. The principle of partnership with NGO or private sector should also be
followed for treatment.
(xviii) While screening for every individual would be undertaken once every five years,
community level awareness should aim to ensure that any individual at any age
group who develops symptoms should be screened at the PHC at any time. Any
individual, who approaches the health facility for screening, will not be denied
on any grounds.

10 | Operational Framework : Management of Common Cancers

<!-- page 35 -->

(xix) Cancer patients: under treatment, and survivors and their family/care-givers
also need support. In addition to treatment in facilities, states are encouraged
to explore partnerships with organizations that provide community based
palliative and rehabilitative care. States are also encouraged to create cancer
support groups at the community level, with active engagement of frontline
service providers, representatives of Panchayati Raj Institutions (PRI) and local
community based groups.

Section 2: Human Resource Requirements
The success of the scheme is dependent on the requisite HR being in place at all levels.
While the broad requirements are suggested in the table below, states would need to
review the available HR and redeploy or reallocate so that the screening caseloads are
adequately resourced.
Table 3: Human resource deployment for screening programmes linked to activity
Level

HR in place

Required

Activity

PHC

Medical
Officer/Staff
Nurse/ANM

One additional staff
nurse to support
the sub center
teams.

CHC

Surgeon/
NCD cell staff could
Gynecologist/ be redeployed
Dentist/Nurse within the facility
to manage the
increased workload.
Surgeon/
Nodal officer
Gynecologist/ for NCD, NCD
ENT
cell staff could
specialist/
be redeployed
Pathologist/
within the facility
Dentist/Nurse to manage the
increased workload.

VIA; hub for population records; nodal
management for all Sub Centres in its coverage
area; cryotherapy if there is a trained Lady
Medical Officer, and to serve as a, hub for
monitoring and supervision and support
Evaluation for all positives referred from
periphery, Biopsy for Oral Ca; Breast ultrasound
scan for suspected lumps, For VIA positive:
Cryotherapy, Colposcopy

DH

(only if not possible at CHC) Evaluation for all
positives referred from periphery, Biopsy for
Oral Cancer Ultrasound probe for abnormal
breast findings For VIA positive: Cryotherapy,
Colposcopy, LEEP Will serve as a training hub
and a centre to confirm cases, refer to tertiary
centre for treatment

Section 3: Training Strategy
(i)

A cascade approach to training would be followed for all cadres of service
providers. The goal is to ensure that key competencies are built for the provider
at each level of facility, to undertake the required screening or confirmatory
Operational Framework : Management of Common Cancers | 11

<!-- page 36 -->

procedure. In addition, providers would need to be trained in the skills of
communication of positive results and reassurance to patient and family for
those detected to be positive at the screening. Frontline providers particularly
need training in support and follow up for cancer patients, since those treated
for cancer would need follow up care at these peripheral levels.
(ii)

Training would cover the following areas:
¾¾ Understanding the concepts and operational details of the programme at
all stages.
¾¾ Understanding cross linkages with existing programmes and skills in
leveraging resources across programmes.
¾¾ Building skills and competences in skills for screening and for confirmatory
tests for those who would be undertaking the procedures.
¾¾ Communication and counseling skills
¾¾ Work flow processes at various levels
¾¾ Recording and Reporting
¾¾ Referrals
¾¾ Follow up at community level

(iii)

Three cadres of trainers are envisaged: national, state and district:
¾¾ National Trainers: These would be a cadre of trainers drawn from Medical
College/Research Institutes across the country: -Gynecologists, Surgeons,
Dentists. Through a two day programme, they would be oriented to the
programme and trained in standardizing their own skills and being able
to build capacity in these competencies for their counterparts at state
levels. Nodal agencies for the training at the national level would include
the Directorate General Health Services, the National Institute for Cancer
Prevention and Research (NICPR), National Institute of Health and Family
Welfare, and the National Health Systems Resource Center.
¾¾ State Trainers: These would include gynecologists, surgeons, pathologists,
dentists and staff nurses from the tertiary level institute/Medical college
training Centre of the State and also from the districts. These trainers would
need to undertake training of district and sub district teams. A team of

12 | Operational Framework : Management of Common Cancers

<!-- page 37 -->

about four trainers per three districts should be identified. The State level
Trainers would be trained at a state medical college for about ten days in
programmatic orientation, including supervision of training in districts,
and orientation for standardization of technical and clinical skills and skills
in training district trainers.
¾¾ For Lady Medical Officers, selected to undertake cryotherapy, a six-day
training with hands on practice in a tertiary center under the supervision
of a gynecologist.
¾¾ Orientation of State and District Level Officials and Stakeholders: This
involves training of stakeholders who would be involved in rolling out of
the initiative in their respective states and districts. This would require the
organization of a one day orientation workshop on the oral, breast and
cervical cancer diagnostic and management modalities and the linkages to
the screening programme. The participants of these State and District Level
Orientation meetings will be the Health and Medical Education Directorate
officials, State RCH/RMNCH+A Officials, Civil Surgeons, Dy. Civil Surgeons,
Facility in charges, District Programme Managers.
Standard treatment guidelines would be updated and disseminated periodically.

Section 4: Behavior Change Communication
While the OGs for Screening for Common NCDs address the issue of BCC in general, a
communication strategy for those who are suspected of cancers would be included.
Such individuals need to be aware of issues such as Treatment options and levels
of care, Social protection schemes and other treatment options that would cover
the costs of care, support networks and programmes to address habits such as
tobacco and alcohol consumption, and likely complications of their conditions.
Effective interpersonal communication would be part of training programmes for all
providers. Increasing levels of literacy allow for use of patient education leaflets to be
distributed at the screening sites. This is to be complemented by person-to-person
and group health education, and using platforms such as the Village Health and
Nutrition Day (VHND).

Section 5: Programme Monitoring
The monitoring framework for NPCDCS already includes key indicators for measuring
programmatic progress and these would be adapted to the framework. Large scale

Operational Framework : Management of Common Cancers | 13

<!-- page 38 -->

periodic surveys such as the National Family Health Survey (NFHS), National Sample
Survey Organization (NSSO), District Level Household Surveys (DLHS), etc., would be
used to assess effectiveness of the programme through cancer incidence and cancer
related mortality rates, access to screening, changes in tobacco and alcohol consumption,
population obesity levels, etc.

Section 6: Financing
The NPCDCS programme already provides support for several interventions proposed
in this framework. Additional costing details for this initiative would be provided to
states separately. States are also encouraged to leverage existing schemes under
NHM and state level health protection schemes and to protect end users from any
financial hardship.

14 | Operational Framework : Management of Common Cancers

<!-- page 39 -->

ANNEXURES
Annexure 1a: Screening and Management Algorithm for
breast cancer
Clinical Breast Examination
(CBE) at subcentre/PHC by ANM

CBE Negative

CBE Positive (Lump)
Evaluation by surgeon at CHC /DH
including Ultrasound scan

Re- entry in to primary
screening schedule

Benign lump on USG

Suspicious or malignant
lump /suspected nipple discharge*

More frequent follow
up as per the discretion
of the surgeon

**Excisional Biopsy of
the lump/nipple d/s
cytology at DH

Malignancy
Benign on HPE/ cytology
Note:
*Mammography, if available, should also be done in age 35
and above in addition to ultrasound.
**Preferably core biopsy; if not possible, fine needle cytology
with arrangement for sending to higher level for diagnosis.

Refer to medical college
or RCC for staging and
treatment as per standard
guidelines

Operational Framework : Management of Common Cancers | 15

<!-- page 40 -->

Annexure 1b: Screening and Management Algorithm
for Cervical cancer
Visual examination using acetic acid (VIA)

VIA Negative

VIA Positive

Repeat VIA after 5 yrs

Refer to Gynecologist/Lady Medical Officer
wherever available PHC/CHC/DH

Lesions not eligible for
cryotherapy**

Lesions eligible for
cryotherapy*

Biopsy (naked eye or
colposcopic guided)
Cryotherapy

Follow up after
one year with VIA

Low grade (CIN 1)

High grade
(CIN 2 & 3)

Cancer

Cryotherapy

LEEP

Refer to TCC

Please Note: The accuracy of VIA decreases in
postmenopausal women. However, in facilities where there
are no resources for Pap, women may be screened using VIA
till 65 years of age.

Follow up after
one year with VIA

*Eligibility for cryotherapy:
¾¾ The lesion should not be spread over more than 2 quadrant of cervix
¾¾ The entire lesion is located in the ectocervix without extension to
the vagina and/or endocervix
¾¾ The lesion is visible in its entire extent
¾¾ The lesion can be adequately covered by the largest available
cryotherapy probe
¾¾ There is no suspicion of invasive cancer

**Cryotherapy not recommended if:
Symptoms:
1. Postcoital bleeding
2. Postmenopausal bleeding
Examination:
3. Overt cervical growth
4. Irregular surface
5 Bleeds on touch

16 | Operational Framework : Management of Common Cancers

<!-- page 41 -->

Annexure 1c: Screening and Management Algorithm
for oral cancer
5
Y
e
a
r
S
c
r
e
e
n
i
n
g
S
c
h
e
d
u
l
e

ASHA/ Health workers collect responses from people
Fill and Issue Oral health cards/ Self-Administered Questionnaire

Individuals with history of
tobacco/arecanut/ alcohol habit
irrespective of age

All Individuals with known
risks for cancer;
Age 30 years and above

Tobacco Cessation Centers [TCC] &/
or Alcohol Deaddiction Centre
at nearest Medical/Dental college

Screening by NCD Nurse /
ANMs /Male Health Workers:
Oral Visual Examination

Normal findings on Oral Visual
Examination

Any abnormality on Oral
Visual Examination

Evaluated by the Dentist/surgeon/
ENT specialist/MO at PHC/CHC/DH
Sensitization and education of private dentists

Potentially Malignant
Lesions

Suspected Oral Cancer

Elimination of Etiological
factors and Tobacco Cessation
[Observe for 6 weeks]
Regression

Clinically Diagnosed
Oral Cancer

Detailed Intraoral Examination and biopsy
[if required] Histo-pathological reporting.
Intervention will be decided based on the
presence of dysplasia. CHC/DH

No change/
Progression

Medical Management
• Reinforced counseling
• Follow up and monitoring

Non dysplastic

Dysplastic & needs
surgical intervention
Referral to Tertiary Cancer Care
Centres /Medical colleges

Operational Framework : Management of Common Cancers | 17

<!-- page 42 -->

<!-- page 43 -->

<!-- page 44 -->

20 | Operational Framework : Management of Common Cancers
