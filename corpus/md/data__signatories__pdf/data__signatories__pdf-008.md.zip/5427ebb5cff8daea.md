---
doc_id: "5427ebb5cff8daea"
source_url: "https://www.mdoner.gov.in/static/uploads/2025/09/0f7299087cbf57132af17b7decc19ca5.pdf"
ministry: "Development of North Eastern Region (MDONER)"
title: "Corrigendum - Letter of Intent a third-party evaluation of the ongoing schemes"
date: "2017-05-12"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "45cb59edcb5284de"
---

<!-- page 1 -->

F.No.NEC-16/3/2017-O/o

DIR (NEC)

Government of India
Ministry of DoNER

CORRIGENDUM

Sub:
Third Party evaluation of Sch
emes of the
Notice for holding of pre-bid
meeting and

extension

of date for submission

M/o

DONER-

of bid- regarding

The M/o DoNER
issued an Lol dated 2.5.2017 to
seven designated
publically funded institutes of Delhi
/NE Region. A copy of the Lol
has
been uploaded on the website
of the Ministry (Kindly see at
What's
New in the opening Ppage?).

2..
The representatives from some
of the designated institutes have
been raising queries and seeking
Clarifications of different kinds inclu
ding
on the

implications of the TORs etc.

3.
Accordingly, it has been deci
ded to hold a Pre-Bid meet
ing on
16.05.2017 at 12:00 hrs in the
Committee Room (Room no. 243
A) to
Clarify doubts, if any. The inte
rested Bidding agencies may
atte
nd
the
Pre-Bid Meeting at the Ministry
OR join through Video-Conference
(VC)
from NEC HeadQuarters,
Nongrim Hills, Shillong. Alternat
ively, the
agency may request for conn
ecting through the VC facil
ities available at
their own premises. Such an agen
cy may provide their VC IP addr
ess at
email- webmaster.northeast@n
ic.in positively by 11:00 hrs on
15th
May 2017 and address any quer
y in this regard to the Project
manager
at 9013878507.

4. The bidding agency should
submit a separate bid for each
scheme
and quote the bid value in Rupe
e terms only (not as a % age
of the
outlay of the scheme or any thro
ugh any other such parameter)
5. The date for submission
at 17:30 hrs,

6.

of bids

has

been

extended

to 19.05.2017
:

This has the approval of Secretar
y, DoNER.

—_—————*

\2z\

oS"

(Dr. Harmeet

aot

Singh)
Director

To

1. All the 7 Designated Agencies
(IIPA/IEG/IIT
Shillong ;IIT Guwa hati;Assam Unive
rsity Tezpur)

at

New

Delhi;IIM/NEHU

:
