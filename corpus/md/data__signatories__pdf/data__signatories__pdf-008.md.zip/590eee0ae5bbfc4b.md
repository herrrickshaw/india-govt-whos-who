---
doc_id: "590eee0ae5bbfc4b"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/b8241e8ef71d4fe22efe9b90ec5c231c.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment in PLI Telecom Scheme Guidelines for allowing PLI Beneficiaries for quarterly disbursement of incentive dated 14 June, 2024"
date: "2024-06-14"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d49106b8621c4550"
---

<!-- page 1 -->

5-20/2024-IP

I/3187294/2024

F.No. 13-01/2020-IC
Ministry of Communications
Department of Telecommunications
Investment Promotion Division
……
1209, Sanchar Bhawan, New Delhi
Dated the May, 2024
OFFICE MEMORANDUM
Subject: Production Linked Incentive (PLI) Scheme for Telecom and Networking
Products- Amendment in Scheme Guidelines for allowing PLI Beneficiaries for
quarterly disbursement of incentive- reg.
Reference:
I.
II.

PLI Scheme Notification No. CG-DL-E-24022021-225442 dated 24th February,
2021 in Part-1, Section 1 of the Gazette of India (Extraordinary).
Guidelines for the PLI Scheme for promoting Telecom & Networking Products
Manufacturing in India dated 3rd June, 2021 as amended on 18th June, 2021,
20.06.2022 and 07.03.2023.
………

The Department of Telecommunications has notified PLI Scheme for manufacturing of
Telecom and Networking products on 24th February 2021. In order to facilitate disbursement
of incentive on quarterly basis, following amendments are being made in the guidelines of
PLI Scheme with effect from 01.04.2024.
Clause
Existing
No.
3.4
For the purpose of determining
eligibility of an Applicant with
respect to Incremental Investment
for any year, the cumulative value
of investment done till such year
(including
the
year
under
consideration) from 01.04.2021 or
01.04.2022 as applicable, shall be
considered. Even if the entire
committed investment is made by
the Applicant in less than 4 years,
the incentive will be disbursed
to
the
eligible
annually
Applicants based on the annual
threshold
investment
communicated in the letter of
approval.
4.1.4

For any particular year, heads of

Amended Clause w.e.f. 01.04.2024
For the purpose of determining eligibility
of an Applicant with respect to
Incremental Investment for any year, the
cumulative value of investment done till
such year (including the year under
consideration) from 01.04.2021 or
01.04.2022 as applicable, shall be
considered. Even if the entire committed
investment is made by the Applicant in
less than 4 years, the incentive
disbursement will be considered on the
basis of Cumulative Annual threshold
Investment as communicated in the letter
of approval. Further, the incentive claim
can be made for the concerned year on
quarterly basis subject to achievement of
aforesaid cumulative threshold Investment
at the time of such claim.
For any particular year, heads of

<!-- page 2 -->

5-20/2024-IP

I/3187294/2024

12.2

15.3

Investment, based on which
eligibility for selection and
annual claim of incentive, is
being determined, must be
capitalized in the books of
accounts of the Applicants, in
that year.
Applicant shall submit claim for
disbursement of incentive after
the end of financial year to which
the claim pertains, but not later
than 9 months from the end of the
said financial year.
An Applicant shall submit its
latest shareholding pattern to the
PMA, along with the annual
incentive claim, if there is any
change in the shareholding pattern
during the year, after up-dation
with the Registrar of Companies
(RoC).

Investment, based on which eligibility for
selection and quarterly claim of incentive,
is being determined, must be capitalized in
the books of accounts of the Applicants,
during the period for which the
incentive is claimed.
Applicant shall submit claim for
disbursement of incentive after the end of
financial year to which the claim pertains,
but not later than 9 months from the end of
the said financial year. The Quarterly
claim application shall be submitted
within 3 months of the completion of
respective quarter.
An Applicant shall submit its latest
shareholding pattern to the PMA, along
with the quarterly incentive claim, if there
is any change in the shareholding pattern
during the year, after up-dation with the
Registrar of Companies (RoC).

2.
The Quarterly payment of incentive is subject to meeting of yearly minimum
thresholds of Net Incremental Sales and Cumulative Incremental Investment for that
Financial Year and submission of required documents along with the Claim Application.
3.
These amendments shall be read along with the Scheme Guidelines incorporating the
above changes wherever applicable.

(Ashok Kumar Jain)
Deputy Director General (IP)

Project Management Agency, i.e., SIDBI for vide circulation to the beneficiaries.
