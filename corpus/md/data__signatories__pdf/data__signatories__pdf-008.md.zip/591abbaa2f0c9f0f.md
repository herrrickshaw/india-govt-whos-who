---
doc_id: "591abbaa2f0c9f0f"
source_url: "https://dof.gov.in/static/uploads/2025/08/374e92cdddba9ddc8dca1ad998ba608e.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Office of Appellate Authority in the Fishery Department-reg"
date: "2021-08-11"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b204dc6481bd89d2"
---

<!-- page 1 -->

Government of India
Ministry of Fisheries, Animal Husbandry and Dairying,
Department of Fisheries
Chanderlok Building,
1st Floor, 36, fanpath Road,

New Delhi,

Dated

the August, ZOZ1,.

Office Memorandum

subiect: - Nomination of Appellate Authority in the Fishery

l(-fi.
Department-reg.

In partial notification to the earlier office orders of even number,

shri I.A.

siddiqui, Deputy commissioner (Fy) in the Department
of Fisheries is nominated as the
Appellate Authority to deal with the RTI Appeal matters
in place of Dr. p. paul pandian,
DC, superannuated recently.
This issues with the approval of Deputy Secretary(RTI).

(Yo$tfflffer kumar)
Under Secretary to the GoW. of India

l./ Sh, I.A.Siddiqui, DC(Fy)
lT.Divisi^on [to upload the order on the website).
,f!3. Admn-l
Section.
