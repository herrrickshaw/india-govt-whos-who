---
doc_id: "56060bbda1fabf0a"
source_url: "https://powermin.gov.in/static/uploads/2026/05/5d23c5d1091d867be83ca7579493dcd8.pdf"
ministry: "Power"
title: "Second Amendment dtd 16th June 2023 of SBDs for procurement of Inter-State Transmission Services (ISTS) through Tariff Based Competitive Bidding (TBCB) process"
date: "2023-06-16"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e9e3e66ee51eec31"
---

<!-- page 1 -->

610850/2023/TRANSMISSION SECTION

F. No. 151412021-Trans

r{RdgfiDT[/ Government of lndia
Ministry of power
trgadTffiq/
(trRquf gr{FI

/ Transmission Division)
*****

erqq[fr rFF[, ratqFf, T{ftd- 11ooo1
Shram Shakti Bhawan, Rafi Marg, New Delhi-l10001

Eqio: 16 q;I, 2oz3
To,

1. Chairperson, Central Electricity Authority, New Delhi
2. Secretary, Central Electricity Regulatory Commission, New Delhi.
3. Additional Chief Secretaries / Pr. Secretaries/ Secretaries of Power/ Energy

Departments of all States/ UTs and Heads of Power Sector Organizations under
States/UTs.
4. Chairman/ Managing Directors of all power sector CPSUs (under Administrative
control of M/o Power).
5. COO, Central Transmission Utility of lndia Limited.
6. Chairpersons of all SERCs/JERCs - for kind information please.
7. CEO, RECPDCL
8. CEO, PFCCL
9. CMDs/MDs, Transcos of all States/UTs.

Subject Amendment in Standard Bidding Documents for procurement of lnter-State
Transmission Services through Tariff Based Competitive Bidding (TBGB) process regarding
Madam/Sir,

I am directed to refer to Standard Bidding Documents (comprising of Request for
Proposal (RfP) and Transmission Service Agreement) for procurement of lnter-State
Transmission Services through Tariff Based Competitive Bidding (TBCB), issued by
Ministry of Power vide O.M. No. 15t1t2017-Trans dated 13th August 2021 and an
amendment issued in revised SBDs vide Letter No. 1 5t412021- Trans dated 13th June 2022
and to say that representations have been received in this Ministry from the transmission
developers seeking relaxation in respect of Para 1.6.1.1 of RfP document and Para 5.1.4
(a) of TSA document, regarding actual location of substations, switching stations or HVDC
terminal or inverter stations in the scope of Transmission Service Provider (TSP) which
prescribe that these shall not be beyond 3 km radius of the location proposed by the BPC in
the survey report.

2.

The matter has been examined in this Ministry in consultation with the stakeholders
and it has been decided that Para 1.6.1.1 of RfP document and Para 5.1.4 (a) of TSA
document shall stand modified as under:-

7

1
File No. 15/4/2021-Trans (Computer No. 260382)
Generated from eOffice by SACHIN, ASO (SACHIN), ASSISTANT SECTION OFFICER, Ministry Of Power on 29/04/2025 01:46 pm

6e

1e/6/pBJ_

<!-- page 2 -->

610850/2023/TRANSMISSION SECTION

Para I

Existing Provisions
To be replaced by
Document
Para
Establishment, operation and Establishment, operation and maintenance
1.6.1.1 of
cf the Project on build, own, operate and
maintenance of the Project on
RfP
lransfer basis and completion of all the
build, own, operate and transfer
activities for the Project, including survey,
basis and completion of all the
Cetailed project report formulation, arranging
activities for the Project, including
[inance, project management, necessary
survey, detailed project report
(way
formulation, arranging finance, Consents, Clearances and Permits
Ieave,
environment
&
forest,
civil
aviation,
project management, necessary
roadl river/ canal/ power crossingr
Consents, Clearances and railway/
PTCC,
etc.),
land compensation, design,
Permits (way leave, environment

equipment, material,
& forest, civil aviation, engineering,
construction,
erection,
testing 8
railway/ road/ river/ canall power
Further, the actuat
crossing/ PTCC, etc.), land commissioning.
location
of
Greenfield
compensation, design, (Switching Stations or HVDC subsfafions
Terminal or
engineering, equipment, material,
generation
lnverter
Stations)
for
a
construction, erection, testing &

pooling subsfafion and for load seruing
commissioning. Further, the substations
in the scope of TSP shall not
actual location of substations, be
beyond
3
Km radius of the location
switching stations or HVDC proposed
by the BPC in the suruey
terminal or inverter stations in the
report. However, actual location of any
scope of TSP shall not be Greenfield lntermediate
Subsfafions in
beyond 3 Km radius of the
fhe
scope
of
TSP
shall
not
be beyond 1(
location proposed by the BPC in
Km radius of the location proposed by
the suruey report.
the BPC in the Suruev Report.
Para 5.1.4 The TSP shall be responsible for
(a) of TSA
(a) [To be deleted by the BPC in

case no land acquisition is
involved in the Project and

replaced by "deleted"] acquisition
of land for location specific
substations, switching stations or
HVDC terminal or inverter
stations. Also, the actual location
of substations, switching stations
or HVDC terminal or inverter
stations shall not be beyond 3
Km radius of the location

proposed by the BPC in the
suruey report;

2

2
File No. 15/4/2021-Trans (Computer No. 260382)
Generated from eOffice by SACHIN, ASO (SACHIN), ASSISTANT SECTION OFFICER, Ministry Of Power on 29/04/2025 01:46 pm

dwboze

trfiP

<!-- page 3 -->

610850/2023/TRANSMISSION SECTION

3.

This issues with the approval of the Hon'ble Minister for Power and New &

Renewable Energy.

Yours

c#

sltRT[fuq, qRdgttFT{,

tdtrw: 2332 s242

t-tgt transdesk- mop@ nic.in
Copy to:

1. PS to Hon'ble Minister of Power and NRE.
2. PS to Hon'ble Minister of State for Power.
3. Sr. PPS/ PPS/ PS to Secretary (Power)/ Addl. Secretaries/AS&Ftu Economic
Advisor/ All JSs/ All Directors of Ministry of Power.

4. Technical Director, NlC, MoP- with the request to upload the letter on the website of
MoP.

3

3
File No. 15/4/2021-Trans (Computer No. 260382)
Generated from eOffice by SACHIN, ASO (SACHIN), ASSISTANT SECTION OFFICER, Ministry Of Power on 29/04/2025 01:46 pm
