---
doc_id: "57ebcf2d26ecbb7e"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/a204a81bf0adba6981510de3ef0fcc85.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Order regarding transfers & posting in JAG of P&T BWS Group A Electrical"
date: "2024-12-27"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5cc7ec762fae70b8"
---

<!-- page 1 -->

No. 6-1/2014-EW(E)
Government of India
Ministry of Communications

Department of Telecommunications
(A&E Section)
618-A, Mahanagar Doorsanchar Bhawan
Jawahar Lal Nehru Marg, New Delhi - 110 002

Dated: 27.12.2024
ORDER

The following transfers & postings in Junior Administrative Grade(JAG) of P&T
BWS Group ‘A’ (Electrical) are hereby ordered with immediate effect and until further

orders:

S.No.
1

Name of the

(S?nf?lg?-lrri)

Present Posting

Musaphir Ram

J& KLSA, Jammu

L

P-?fat:"; N
*NTIPRIT, IM

Division (Non-

Vice Shri Arun Dwivedi

MP LSA

Against
(own costvacant
transfer)post

popartmentef

|
" Shri - Awadhesh
Vice
.
Kumar Singh

Training)
2

adi
Arun Dwivedi

NTIPRIT, TM
Ay )(Non—
%;Iiﬁi?\g

3 | Mukesh Wadhwa | Assam LSA,

Remarks

4

Ashima

f

i
Director
(EW-I), DoT
HQs

Director:
Electrical), TEC,
#\lew
Delhl)

5

|Awadhesh

Director (Electrical),

I(DEIIr:gttPi{:al

DoT | @nd additional c%arge

Kumar Singh

TEC,

Ha,

Delhi

6

:
Arvind Kumar
Chaudhary

Department of
Posts,
SE
(Elect), Bengaluru

:
Dir. (EW-I), DoT
g
HQs

i
:
Vice Smt Ashima

7

\C(;:éirbdra Kumar

Eﬁyb:\neshwar

Odisha LSA

Against vacant post.

8

Subhash R.
Devasthali

Bengaluru

Karnataka LSA,

Department of

_

9

o
Tarun Bairathi

MTNL, Mumbai n

Department of

-

10

gmﬂg aBhanu

New

Delhi

Department of

| pocts.

(Elect), Delhi

SE

i

9.

New

‘Against vacant

Posts

Posts

post

of Director (EW-II),

DoT HQs

U.P. (East) LSA | Against vacant post.

* The posting of the officer shall be as per OM No. 06-01/2024-EW dated 30.04.2024
and in IM division of NTIPRIT against diverted post. The officer shall not be eligible for
training allowance.
2.

Charge report may be furnished to all concerned. Hindi version will follow.

3.

This issues with the approval of the Competent Authority.

(Awadhesh Kumgr%il%ﬁsy\
Director (Electrical)

Ph:011-23258925
E-mail: direlect-dot@nic.in

<!-- page 2 -->

©® N

SOhON =

Copy to:
PSO to Secretary (Posts)
PSO to Secretary (T)
PSO to Member (S), DoT

Director General Telecom, DoT Hg.
CMD, BSNL/CMD, MTNL
Heads of Assam LSA, J&K LSA, M.P. LSA, Karnataka LSA, Odisha LSA,
U.P.(East), LSA
Member (Infrastructure), Department of Posts

Sr. DDG (BW)/DG (NTIPRIT)/Sr DDG (TEC)/DDG (Estt)

Chief Engineer (Electrical), Department of Posts
10 Director (Civil)/ Director (Architecture)

11. Officers concerned.
12.80(Pay Bill)/ Pay & Account Officer (Hgrs), DoT
13.S0(0L), DoT for Hindi version
14. Director (EW) — for uploading on DoT website

15.0rder bundle.
