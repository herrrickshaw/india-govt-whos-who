---
doc_id: "55e4ecd5da9dfab5"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/cac9be7c6a119994618e792a85b58b7b.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "President pleased to appoint Ms. Veena Raina Dhar, an officer of Indian Statistical Service, as Joint Director in Junior Administrative Grade of ISS"
date: "2017-11-07"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5830f7098cfbedfc"
---

<!-- page 1 -->

(To be published in Part-l Section-ll of the Gazette of lndia
Government of lndia
Ministry of Agriculture & Farmers Welfare
Department of AnimalHusbandry & Dairying
Krishi Bhavan, New Delhi.
Dated thelq Jvlarch, 2019
NOTIFICATION

No. A-1901'l/23/201S-Admn.l

The president is pleased to

appoint
Ms. Veena Raina Dhar,an officer of lndian statistical service-as Joint Director in
Junior Administrative Grade of lSS, Level - 12 of the pay Matri{ on regularbasisin
this Department, w.e.f. the forenoon of lSIh February, 2Olg in puisuance with
Ministry of Statistics and Programme lmplementation,s Office Order
No.120151021201 9-lSS dated 14.2.2019.

(Rohit T
Under Secretary to the Govt. of India
Telephone No. 23383340
To

The Manager,
Government of lndia Press,
Faridabad (alongwith Hindi version)

)y

<!-- page 2 -->

Distribution:

Ms. Veena Raina Dhar, Joint Director
Sr. PPS to Secretary, AH&D
O/o Advisor (Stat.), D/o AH&D

The Deputy Director (lSS), Ministry of Statistical and Programme
lmplementation, Sardar Patel Bhawan, New Delhi
P&AO (Sectt.), D/o AHD, Krishi Bhawan,
Cash & Coordination Section/DDO/Cashier/Admn.ll/Library (DOAC).
Serv
BooUPersonal File/Guard File
/ParliamenWigilance/Reception Officer
NIC for uploading on the website.
