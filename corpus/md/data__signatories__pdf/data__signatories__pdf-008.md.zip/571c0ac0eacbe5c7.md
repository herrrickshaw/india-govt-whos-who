---
doc_id: "571c0ac0eacbe5c7"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/6980fe00925e8bebcda8bb303b5cb7ae.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment in Recruitment Rules for the post of MTS(Multi Tasking staff), LHMC & SSKH,New Delhi."
date: "2019-04-19"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d15f7c8bcb191c16"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE

Public Notice on draft Recruitment Rules for the post of Multi-Taking Staff (MTS) in Dr.

RML Hospital, New Delhi.

In compliance with DoPT's OM. No. AB-1401716112008-Estt(RR) dated
13.10.2015, the draft Recruitment Rules for post of Multi-Taking Staff (MTS) in Dr.

RML Hospital, New Delhi is annexed.
The stakeholders, interested in making any objections/comments or suggestions on
the draft Recruitment Rules may do so in writing, within a period of 30 days from the
publication
date
of
of
draft Recruitment Rules to
Section Officer (MH-II), Room No.405A, Directorate General of Health Services,
Nirman Bhawan, Maulana Azad Road, New Delhi-110108 or at e-mail address:
medical hospital6l@gmail.com.

/rL-

(G.P. Samanta )
Under Secretary to the Govt. of India
Tele fax No. 23061521

New Delhi
Dated:

<!-- page 2 -->

.,'

lTo BE PUBLTSHED tN THE GAZETTE OF tNDtA, PART il, SECTTON 3, SUB-SECTION (i) l

A

GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE

New Delhi, the

r

2019.

Notificolion
G.S.R.....- ln exercise of the powers conferred by the proviso to orticle 309 of ihe Constilution, ond

in supersession of ihe Willingdon Hospilol ond Nursing Home (Closs lV posts) Recruilment Rules,
1973, in so for os they relote to lhe post of Doftri, Peon, Heod Securily Guord, Securiiy Guord,
Chowkidqr. Chowkidor cum Cleoner, Goie Orderly, Cleoner, Chowkidoor cum sweeper,
Sweeper/sweepresses, fVillingdon Hospitol ond Nursing Home (Supervisor) Recruilmenl Rules,
1977 ond Dr. Rom Monohor Lohio Hospitol ond Nursing Home (Group D), Recruitment Rules,
1979; in so for os they relote to the posl of Gestetner Operotor, except os respects things done or
omitted to be done before such supersession, the President hereby mokes the following rules

reguloting the melhod of recruitment to Dr. Rom Monohor Lohio Hospitol ond Nursing
Home(Group 'D'), New Delhi, nomely:-

l. Short litle ond commencement. - (l) These rules moy be colled the Dr. Rom Monohor'Lohio
Hospitol,MultiToskingStoff(MTS),NewDelhi,RecruitmentRules,2o19..,'.
:

(2) They sholl come into force on the dote of their publicotion in the Officiol Gozette.

2.

Number of post. clossificotion, level in lhe poy moirix or poy scole. - The number of llte
soid post, its clossificotion ond level in lhe. poy motrix or poy scole ottoched thereto shoil be os
specified in columns (2) b @ of the Schedule onnexed to these rules.

3. Method of recruitment, oge-limit, quolificotions, etc. - The method of tecruilment.'oge-limit,
quolificotions ond olher motters reloting to'the ioid post sholl be os specified iniolurnns'(5) to
(13) of the soid Schedule.

i

4. Disquolificoiion. - No person, (o) who hos entered into or conlrocled o morrioge wiih o person hoving o spouse living; or
(b) who, hoving o spouse living, hos entered into or controcted o morrioge with ony person,
sholl be eligible for ocpoinlment to the soid post:

. Provided thot the Centrol Government moy, if sotisfied thot such morioge islpbrnrissible
under the personol low opplicoble to such person ond lhe other porty to the morrioge ond tholl
there ore other grounds for so doing. exempt ony person from the operotion of lhis rule.

5. power to relox. - Where the Centrol Government is of lhe opinion thot it is necessory 9r
expedient so to do, it moy, by order, for reosons to be recorded in writing relox otry of the
provisions of these rules with respect to ony closs or cotegory of persons.

6. Soving.- Nothing in lhese rules sholl offect reservotion, reloxotion of oge-limit.'ond oiher

concessions required to be provided for the Scheduled Costes, the Scheduled Tribes. Exservicemen ond other speciol cotegories of person in occordonce wilh the orders issued by the
Centrol Government from time lo time in this regord.

<!-- page 3 -->

Schedule

Nome of post

Number of the
post

Level rn pqy
motrix or poy

Clossificotion

scole

(l)

.

selecfion post
or nonseleciion '
(s)

(4)

(3)

12\

:Whether' ,'

Generol Centrol Level-l (i8000. Not
Servrce, group 56900) in the opplicoble.

Mulii

Tosking Chowkidqr (29)
.Stoff (MTS).
Security Guord(6)
Doftri(2)

'

'C',

Gestetner
Operotor(l)
Goie Orderly(2)
Cleoner(l )

Non-

poy motrix.

Gozetted,
Non-Ministeriol.

Heod

Security
Guord(1)
Supervisor (10)
Chorvkidor cum
Cleoner. (l ).
Peon (15)
Chowkidoor cum
sweeper (3)
Sweeper/
sweepresses (173)

244* (2019)

*Subject

to

voriotion

dependent on
worklood.

Age limit for direct recruits

Educotionol ond other quolificotions required

fordirectrecruits .,. ,. .:,

:

,

(7)

(6)

Between l8 ond 27 yeors.
fReloxoble for Governmeni servonts upto the
oge of forty yeors in the cose of generol

.,

Motriculotion from o recognised boord:
''.'.i-.

Note l: Quotificotions ore relcixoble oi' ihe
yeors
discretion of the Stoff Selection Commission
condidotes ond upto forty-five
condidotes belonqinq to the Scheduled for the reosons to be recorded in writing in

<!-- page 4 -->

Costes or

the Scheduled Tribes in cqse of condidotes othenarise well quolified.

occordonce with the instructions or orders
issued by the Centrol Governmeni from time
to time).

Note:.l. The cruciol dote for d.etermining the
oge limit sholl be the closing dote for receipt
of opplicotions from condidotes in lndio
except the closing dote prescribed for those
in Assom, Megholoyo, Arunochol Prodesh,
Mizorom, Monipur, Nogolond, Tripuro, Sikkim,
Lodokh Division of Jommu ond Koshmir Stote,

Note 2: Quolificotions regording experience
ore reloxoble of the discr.etion of the Stoff
Selection Commission for Jhe reosons to be
recoided in writing in the cose of Condidoies
belonging to the Scheduled Costes or ihe
Scheduled Tribes, if, of ony stoge of selection
the Stoff Selection Commission is of the
opinion thot sufficient number of condiclotes
belonging to these comrnunities possessing
the requisite experience ore not. likely, lo be
ovoiloble to fill up the voconcles reserved for

division of Chombo District of Himochol
Prodesh, Andomon ond Nicobor lslonds or them.
Lokshdweep).

Note 2. The cruciol dote for determining the
oge limit in the cose of condidotes from
Employment Exchonge sholl be the lost dote
up to which the Employment Exchonge is
osked to submit the nomes

Whether oge ond Period of probotion, if Meihod of recruitment, whether by direct
educotionol
quolificotions

recruitment or by promotion or by depuiotion
or obsorption ond percentoge of the
voconcies to be filled by vorious methods

ony

prescribed for direct
recruits will opply in
the iose of

i

promotees
(8)

(e)

Not opplicoble.

Two yeors.

(10)

By direct recruitment.

..

'

.

<!-- page 5 -->

ln cose of recruitment by lf o Deportmentol Promotion Circumstonces in
'promotion or deputotion Committee exists, whot is its which , Unioni Pubtic
or obsorption grode from composition
Services Commission is
which promotion or
to ,be consulted in
deputotion or obsorption
moking recruitment.
to be mode

(il)
Not opplicoble.

(lsl

(12)
De portmentql C onf irmotion

Not opplicoble

l. Additionol Medicql Superintendent,
Dr. Rom Monohor Lohio Hospitol,
New Delhi
- Choirmon
:'

l:

2. Deputy- Director Administrotion. of
Dr. Rom Monohor Lohio Hospitol, New
Delhi

- Member

3. Deputy Director in chorge of the
Medicol Hospitol Section, Directorote
Generol of Heolth Services '
- Member
.

:

lA. l l018/0712014-MH lrl

.:
:

.

._..

, 3.:(G. P Somonto)
.

'Under.Secretorylo the Government of; jndio,i ..
j.'
