---
doc_id: "562ef7e8e2bf1aef"
source_url: "https://morth.gov.in/backend/documents/uploaded/1784284400_g6J65t4wnI.pdf"
ministry: "Road Transport and Highways (MoRTH)"
title: "Scheme Guidelines on Rah-Veer ::"
date: ""
pages: 8
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "10bb45def3e95f4b"
---

<!-- page 1 -->

RT-25035/27/2021-RS, 1/4067510/2026
No. RT- 25035/27/2021-RS (195777)
Government of India
Ministry of Road Transport & Highways
(Road Safety Division)
Transport Bhawan, New Delhi-110001
Dated: 17th July, 2026
To,
Principal Secretary (Home) / Secretary (Transport) /
Secretary(Health) / Transport Commissioner of all States/UTs
Subject: Scheme Guidelines on Rah-Veer.
Sir,
| am directed to inform that this Ministry has continued the“Rah-Veer”
Scheme (erstwhile Good Samaritan Scheme) during theXVith Finance
Commission Cycle (2026-27 to 2030-31). A copy of the Scheme Guidelines is
enclosed herewith. The same is also available on the website of this Ministry.
2. As per Para 9.1 of the Scheme Guidelines, MoRTH shall provide an initial
grant of 25.00 lakh to the Office of the Transport Commissioner/Department of
Transport of the concerned State/UT for making payment to Rah-Veers (Good
Samaritans). The initial grant already released to a State/UT under the Scheme
shall be adjusted while calculating the admissible initial grant for that State/UT. The
funds under the Scheme shall be disbursed as per the Central Nodal Agency
(CNA) — Model 1 prescribed by the Department of Expenditure for implementation
of Central Sector Schemes.
3. As per Para 9.3 of the Scheme Guidelines, details of the Rah-Veers (Good
Samaritans) awarded under the Scheme shall be entered in the eDAR portal
developed by MoRTH by the concerned officials of the State/UT Transport
Department. It shall also be ensured that such details are uploaded on the portal
before submission of the claim for reimbursement/next instalment to this Ministry.
The details and operational modalities of the said portal shall be communicated
separately in due course.
4. It is further informed that enabling Aadhaar authentication of beneficiaries
under the Rah-Veer Scheme on the eDAR platform is presently under process.
Accordingly, as an interim arrangement, States/UTs may proceed with
disbursement of %25,000/- per beneficiary upon receipt of duly submitted
1
File No. RT-25035/27/2021-RS (Computer No. 195777)

<!-- page 2 -->

RT-25035/27/2021-RS, 1/4067510/2026
applications containing the Accident ID, Aadhaar details, and bank account details
of the beneficiaries. Once the eDAR portal is suitably enabled to capture Rah-Veer
beneficiary details and facilitate Aadhaar authentication, the provisions contained in
Clauses 9.2 and 9.3 of the Rah-Veer Scheme Guidelines shall be complied with in
full.

5. It is requested to publicise the Scheme appropriately among the general
public. Further, as the Scheme shall come into effect w.e.f. 17th July, 2026, a copy
of the Scheme Guidelines may be circulated immediately among all stakeholder
departments, including DM/SSP/SP Offices, Health Departments (including
Hospitals), Police Departments, etc.
Yours faithfully,
Encl: As above. Digitally signed by
MIRTYUNJAY KUMAR
Date: 17-07-2026
11:27:45
(Mirtyunjay Kumar)
Under Secretary to the Government of India
Tel:23739074
Copy to: NIC (with a request to upload the guidelines on the Ministry's website.
2
File No. RT-25035/27/2021-RS (Computer No. 195777)

<!-- page 3 -->

RT-25035/27/2021-RS, 1/4067510/2026
Subject: Scheme Guidelines on Rah-Veer
1. Background:
1.1 Road safety is a complex issue of concern, considering its magnitude and
gravity and the negative impacts on the economy, public health and the general
welfare of the people, particularly those with low income. Although, various road
safety improvement programs are being implemented, these have not had the
required impact, and the number of road accidents and fatalities continue to rise.
With motorization witnessing a 10% compound growth every year and expanding
road network, travel risks and traffic exposure grow at a much faster rate. Today,
road traffic injuries are one of the leading causes of deaths, disabilities and
hospitalizations, with severe socio-economic costs across the world.
1.2 The main thrust of accident prevention and control across the world has been
on 4 E’s, vis. (i) Education, (ii) Enforcement, (iii) Engineering and (iv) Environment
and Emergency care of road accident victims. The Government of India has been
focusing on all these four approaches in its policies and programmes.
1.3 As per provisions under Section 134A of the Motor Vehicle Amendment Act
2019, Rules for Good Samaritan have been notified by the Ministry of Road
Transport and Highways vide Notification No. GSR 594E dated
2gth September, 2020. Basically the rules provide legal protection to the people
who give reasonable assistance those who are, or who they believe to be, injured,
ill, in peril, or otherwise incapacitated.
1.4... Now, it has been felt that there is a need to motivate the general public,
“through cash awards and certificates’, to help the road accident victims in
emergency situation and to boost their moral, and also to inspire and motivate
others to save lives of the road accident victims.
2. Name of the Scheme:
The scheme shall be called as the “Rah-Veer”.
३... Period of Operation of the Scheme
The scheme will remain operational till the completion of the 16 Financial Cycle,

3
File No. RT-25035/27/2021-RS (Computer No. 195777)

<!-- page 4 -->

RT-25035/27/2021-RS, 1/4067510/2026

ie. till 318t March, 2031.
4. Objective of the scheme:
To motivate the general public to help the road accident victims in emergency
situation, inspire and motivate others to save innocent lives.
5. — Eligibility:
Any individual who has assisted a victim of a serious accident involving a motor
vehicle by administering immediate assistance and rushing the victim to a
Hospital/Trauma Care Centre within the Golden Hour of the accident for medical
treatment.
5.1 Definition of Golden Hour:
As per Motor Vehicle Act section 2(12A) “golden hour” means the time period
lasting one hour following a traumatic injury during which there is highest likelihood
of preventing death by providing prompt medical care
5.2 Definition of Serious Accident:
Any Road accident involving motor vehicle leading to any of the following
conditions during treatment to victim and certificate of fatality/seriousness by
Hospital:

a. Major surgery involved

b. Minimum three day of hospitalization

c. Brain injuries

d. Spinal cord injuries

e. Death of the victim during treatment
6. Financial Assistance (in the form of Award).
6.1 The amount of award for each Rah-Veer (Good Samaritan) would be Rs.
25,000/- per incident, subject to the following provisions:

a. If one Rah-Veer (Good Samaritan) saves life of one or more victims of a

single serious accident involving a motor vehicle, amount of award will be Rs.
4
File No. RT-25035/27/2021-RS (Computer No. 195777)

<!-- page 5 -->

RT-25035/27/2021-RS 1/4067510/2026
25,000/- only.

b. If more than one Rah-Veer (Good Samaritan) save life of one victim of a
serious accident involving a motor vehicle, amount of award i.e. Rs. 25,000/-
will be divided equally among them.

c. If more than one Rah-Veer (Good Samaritan) saves life of more than one
victims of a serious accident involving a motor vehicle, amount of award will
be Rs. 25,000/- per victim saved subject to maximum Rs. 25,000/- per Good
Samaritan.

6.2 Every cash award would be accompanied with a “Certification of
Appreciation”.
7. Procedure to be followed for Selection:
7.1. Incase the incident is informed to the police at the first hand by the Rah-Veer
(Good Samaritan), after verifying details from Doctor the police shall provide an
Acknowledgment to such Rah-Veer (Good Samaritan), on official letter pad,
mentioning the name of the Rah-Veer (Good Samaritan), his mobile number and
address, place, date and time of incident and how the Rah-Veer (Good Samaritan)
has helped in saving the life of the victim etc. The copy of the Acknowledgement
would be sent to the Appraisal Committee formed at District Level under the
Chairmanship of District Magistrate by the concerned police station, with a copy
marked to the Rah-Veer(s) / Good Samaritan(s). A standard and uniform format for
the acknowledgement to be provided to the Rah-Veer (Good Samaritan) by the
local police should be used throughout India as per Annexure — A.
7.2 In case the Rah-Veer (Good Samaritan) takes the victim to the hospital
directly, the concerned hospital shall provide all the details to concerned police
station. The police shall provide an Acknowledgment to such Good Samaritan, on
Official letter pad, mentioning the name of the Rah-Veer (Good Samaritan), his
mobile number and address, place, date and time of incident, how the Rah-Veer
(Good Samaritan) has helped in saving the life of the victim, etc. The copy of the
Acknowledgement would be sent to the Appraisal Committee formed at District
Level under the Chairmanship of District Magistrate with a copy marked to the Rah-
Veers / Good Samaritan(s).
7.3. The Appraisal Committee at the District Level would comprise District
Magistrate, SSP, CMOH, RTO (Transport Department) of the concerned District.
5
File No. RT-25035/27/2021-RS (Computer No. 195777)

<!-- page 6 -->

RT-25035/27/2021-RS, 1/4067510/2026
A State Level Monitoring Committee under Chairmanship of Principal
Secretary (Home) and having Commissioner (Health) & ADGP (Traffic & RS) as
members and Commissioner (Transport) as member Secretary shall do Quarterly
Meetings to monitor the proper implementation of scheme.
74 On receipt of communication from the Police Station/Hospital, District Level
Appraisal Committee shall review and approve the proposals on a monthly basis.
This list would be sent to the Transport Commissioner of the concerned State / UT
Transport Department for further necessary action. The payment for selected Rah-
Veer (Good Samaritan) would be made online through PFMS in their Bank Account
directly by the O/o Transport Commissioner, Transport Department of the
State/UT. Reimbursement against the utilization of the initial grant/additional grant
shall be provided by MoRTH to the State/UT Transport Department upon
exhaustion of the said grant(s) and submission of the Utilization Certificate in
respect thereof .
7.5 Any provision of these guidelines would not come as a barrier for the
Notification issued by this Ministry on 29.09.2020 for the Good Samaritan (copy
enclosed).
76 The information provided by the Rah-Veer (Good Samaritan) voluntarily
would be used exclusively for the processing of proposal for award under the
scheme and not for any other purpose. Also, Rah-Veer (Good Samaritan), who are
not willing to disclose their details, would not be awarded under the scheme.
7.7 An individual Rah-Veer (Good Samaritan) can be awarded maximum
5 times in a year.
7.8 State Government will publicize this scheme through various means like print
& social media, etc.
8. As financial implication has been worked out based upon various
assumptions. Eligibility Criteria, Definition of Serious accident and financial
implications may be reviewed by Ministry after two years.
9. Release of financial assistance by MoRTH:

9.1 MoRTH will provide Rs. 25.00 Lakhs as initial grant to the Office of Transport
Commissioner, The initial grant already released to a State/UT under the scheme
6

File No. RT-25035/27/2021-RS (Computer No. 195777)

<!-- page 7 -->

RT-25035/27/2021-RS 1/4067510/2026
will be adjusted while calculating the initial grant to that State/UT. Department of
Transport of the State/UT for making payment to the Rah-Veers (Good
Samaritans). The funds under the Scheme shall be disbursed as per the Central
Nodal Agency (CNA) — Model 1 prescribed by the Department of Expenditure for
implementation of Central Sector Schemes.
9.2 The Deputy Commissioner / Collector / District Magistrate who is also the
Chairperson of the District Road Safety Committee, shall, on the recommendations
of the Appraisal Committee, upload the details of the beneficiary of the Rah-Veer
award scheme along with the Aadhar Number or bank Account Number on the e-
DAR platform and the Award shall be disbursed by the O/o Transport
Commissioner, Department of Transport of the State/UT through PFMS directly to
the beneficiary awardee online in their Bank Account within 7 days of the uploading
of beneficiary details. The amount would be reimbursed by the MoRTH on demand
from the O/o Transport Commissioner, Department of Transport of the State/UT
with UC of the earlier release(s) and details of Rah-Veers (Good Samaritans)
awarded against that release(s) to the Ministry. Further, the use of Aadhaar
Number for establishing the identity of Rah-Veers has been notified by the Ministry
vide Notification No. RT-25035/46/2022-RS dated 04.02.2026 (copy enclosed).
9.3 The details of the Rah-Veer (Good Samaritan) who have been awarded shall
be entered in the eDAR portal developed by MoRTH by the concerned Officials of
the State/UT Transport Department and they will also ensure that the details have
been uploaded on the portal before submitting of demand for next instalment to this
Ministry for necessary reimbursement.
9.4 As provisioned under Section 134A of the Motor Vehicles (Amendment)
Act, 2019 and Rules for Good Samaritan notified vide Notification No. GSR 594E
dated 29'" September, 2020, no Rah-Veer (Good Samaritan) would be subjected
to any legal proceedings without their consent. In case of any breach of protection
provided to Good Samaritans / Rah-Veer under the aforementioned rules, the Rah-
Veer / Good Samaritan would approach the Grievance Redressal Committee to be
established by the States / UTs under chairmanship of concerned Deputy
Commissioner / Collector / District Magistrate.
10. The revised Scheme would be effective w.e.f . 17th July, 2026.

7
File No. RT-25035/27/2021-RS (Computer No. 195777)

<!-- page 8 -->

RT-25035/27/2021-RS, 1/4067510/2026
Annexure-A
Form for Acknowledgement for Rah-Veer / Good Samaritan Award
(To be given by the Police Station)
Acknowledgement for the act performed by Rah-Veer / Good Samaritan under
the “Rah-Veer” Scheme of Ministry of Road Transport and Highways, Govt of India
PERSONAL DETAILS
Name of the Rah-Veer / Good Samaritan
(Pls use separate sheet for each Good Samaritan, in case it is more than one individual)
Mobile Number [|
-
Place of Accident (with detailed address) [|
Date & Time of Accident [|
Bank Account Details
Bank Name (with address):
Number;
Account Holder Name: IFSC
Code:
[CERTIFICATION BY POLICE DEPARTMENT
Name of the Police Station (with address & Tel No.): ||
IName and Mobile number of the In-charge of the concerned police station L
Description of the Incident
(explain in brief the act performed by Rah-Veer / Good Samaritan that has assisted the}
victim) and to confirm that the aid was provided by the Rah-Veer / Good Samaritan within]
the stipulated time of Golden Hour
CERTIFICATION BY HOSPITAL
Name of the Doctor who attended first (with the Name and address of the Hospital) ||
Name and Telephone number of the Hospital Head (MD/Director/Superintend, etc.) [|
Brief Reason as to why it has been treated as serious accident and to confirm that the aid]
Iwas provided by the good Samaritan within the stipulated time of Golden Hour
Signature of Authorized Official (with official seal) |
Date:
Place:
(Signature of the Authorized signatory)
[Name and Designation of the Authorized Signatory]
8
File No. RT-25035/27/2021-RS (Computer No. 195777)
