---
doc_id: "56a4fabaf5f0a21c"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/967e2a21c4691374165a2992e6decc92.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Amendment in the Registration and licensing of Industrial undertakings Rules, 1952"
date: "2025-07-14"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0c3109faf19aa700"
---

<!-- page 1 -->

| भाग 1 खण्ड 50) | भारत का राज़पत्र : असाधारण ‘ 3 |
(Department of Industrial Policy and Promotion)
NOTIFICATION
New Delhi, the 4th October, 2012

GS.R. 740(F).— WHEREAS ‘certain draft rules further to amend the
Registration and Licensing of Industrial Undertakings Rules, 1952, were published,
as required by sub-section (1) section 30 of the Industries (Development and
Regulation) Act, 1951 (65 of 1951), in the Gazette of India, Extraordinary, vide
notification of the Government of India in the Ministry of Commerce and Industry
(Department of Industrial Policy and Promotion) number G.S.R. 624 (E), dated the
8” August, 2012, inviting objections and suggestions from all persons likely to be
affected thereby, before the expiry of a period thirty days from the date on which the
coptes of the Official Gazette in which the said notification is published are made
available to the public;

AND WHEREAS the said notification was made available to the public on 8”
August. 2012;

AND WHEREAS no objections or suggestions have been received by the
Central Government on the said draft rules;

NOW, THEREFORE, in exercise of the powers conferred by section 30 of the
Industries (Development and Regulation) Act, 1957 ( 65 of 1951), the Central
Government hereby makes the following rules further to amend the Registration and

* Licensing of Industrial Undertakings Rules, 1952, namely :-

1 (1) These rules may be called the Registration and Licensing of
Industrial Undertakings (Amendment) Rules, 2012 .

(2) They shall come into force on the date of their publication in the
Official Gazette.

2 In the Registration and Licensing of Industrial Undertakings Rules,

1952, in rule 10, for sub-rule (2), the following sub-rule shall be substituted.

namely -

“(2) The Central Government may, by notification in the Official
Gazette. appoint one or more committees. consisting of such number of
members as it may think fit to represent the Ministries or Departments of the
Central Government dealing with-

<!-- page 2 -->

4 THE GAZETTE OF INDIA : EXTRAORDINARY [Parr I See. 3}
ee
(a) the Industrial Policy and Promotion; |
(b) the Industry specified in the First Schedule to the Act; |
(c) Home Affairs;
(d) | Commerce, (Director General of Foreign Trade);
(e) Micro, Small and Medium Industries :
Provided that the Central Government may, if it deems fit, include in such
committee any other member to represent any other Ministry or Department”.
| F. No. 7(1)/2012-1P]
SHUBHRA. SINGH, Jt. Seey
Note :The principal notification was published in the Gazette of India
Extraordinary, Part ll, Section 3. vide notification number S.R.O. 1141, dated the
9” July, 1952 and was subsequently amended by -
1. Notification No. S.R,0.1856, dated the 1" October, 1953;
2. Notification No. S.R.O. 691, dated the 1%’ March, 1957;
3. Notification No.G.S.R. 1781, dated the 11" December, 1964;
4. Notification No. G.S.R, 2187, dated the 6” December, 1968;
5. Notification No. G.S.R. 270 (E). dated the 14" June, 1974;
6. Notification No. G.S.R. 274( E), dated the 19" June, 1974;
7. Notification No.G.S.R. 284( E), dated the 25" June, 1974;
8 Notification No. G.S.R. 369/€), dated the 17" August, 1974;
9. Notification No. G.S.R. 392( E), dated the 17'" September, 1974:
10. Notification No. G.S.R. 399( E), dated the 23'° September, 1974:
11. Notification No.G.S.R. 599( E), dated the 15" November, 1975:
12. Notification No.G-S.R. 719( E), dated the 26” September, 1981,
13, Notification No,G.S.R. 66( E), dated the 14” February, 1984
14. Notification No. G.S.R. 100( €), dated the 18" February, 1987:
15, Notification No. S.O. 926( E), dated the 3° December, 1993.
irnted by the Manager, Government af India Press, Ring Ruad, Mayaputi, New Dethi-} LOlbd
and Published by the Controtier of Publications, Delhe-1 10054
