---
doc_id: "5472e3b2ccdbc7ee"
source_url: "https://financialservices.gov.in/sites/default/files/Act-Policies/2026-01/Draft-Rules-29-8-2025-Indian-Insurance-Companies--Foreign-Investment--Amendment-Rules-2025.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "Draft Indian Insurance Companies (Foreign Investment) Amendment Rules, 2025"
date: "2026-01"
pages: 4
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "fca93df238295d1d"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-29082025-265792
xxxGIDHxxx
CG-DL-E-29082025-265792
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 547]
No. 547]

नई दिल्ली, िुक्रिार, अगस्ट्त 29, 2025/भाद्र 7, 1947
NEW DELHI, FRIDAY, AUGUST 29, 2025/BHADRA 7, 1947

जित्त मंत्रालय
(जित्तीय सेिाएं जिभाग)
अजधसूचना
नई दिल्ली, 29 अगस्ट्त, 2025
सा.का.जन. 591(अ).— भारतीय बीमा कं पनी (जििेिी जनिेि) जनयम, 2015 में संिोधन करने के जलए प्रारूप
जनयम, जिसे कें द्रीय सरकार बीमा अजधजनयम, 1938 की धारा 2 के खंड (7क) के उपखंड (ख) के साथ पठित धारा 114 की
उप-धारा (2) के खंड (ककक) द्वारा प्रित्त िजियों का प्रयोग करते हुए बनाने का प्रस्ट्ताि करती है, एतद्द्वारा ऐसे सभी व्यजियों
की िानकारी जिनके इससे प्रभाजित होने की संभािना है, के जलए प्रकाजित दकए िाते हैं, और एतद्द्वारा सूचना िी िाती है
दक उि प्रारूप जनयम को उस तारीख से पंद्रह दिनों की अिजध की समाजि के पश्चात भारत के रािपत्र में प्रकािन के जलए
जलया िाएगा, जिस तारीख को प्रारूप जनयमों की प्रजतयां िनता को उपलब्ध कराई िाती हैं।
उन व्यजियों, जिनके प्रभाजित होने की संभािना है, से आपजत्तयां या सुझाि, यदि कोई हों, सजचि, जित्त मंत्रालय,
जित्तीय सेिाएं जिभाग, िीिन िीप भिन, तृतीय तल, संसि मागग, नई दिल्ली 110001 को भेिे िा सकते हैं।
प्रारूप जनयमों के संबंध में उपयुगि अिजध के भीतर प्रभाजित होने िाले संभाजित व्यजियों से प्राि होने िाली
आपजत्तयों या सुझािों पर कें द्र सरकार द्वारा जिचार दकया िाएगा।

5795 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

प्रारूप जनयम
1.

संजिि नाम और प्रारं भ:
(1) इन जनयमों को भारतीय बीमा कं पनी (जििेिी जनिेि) संिोधन जनयम, 2025 कहा िाएगा।
(2) ये आजधकाठरक रािपत्र में उनके प्रकािन की तारीख से लागू होंगे।

2.

भारतीय बीमा कं पनी (जििेिी जनिेि) जनयम, 2015 (इसके बाि मूल जनयम के रूप में संिर्भगत) में, जििेिी जिजनमय

प्रबंध (भारत से बाहर के जनिासी व्यजि द्वारा प्रजतभूजत का अंतरण या जनगगम) जिजनयमािली, 2000 के सभी संिभों को
जििेिी जिजनमय प्रबंध (गैर-ऋण जलखत) जनयम, 2019 (इसके बाि फे मा (एनडीआई) जनयम के रूप में संिर्भगत) के साथ
प्रजतस्ट्थाजपत दकया िाएगा, और फे मा जिजनयम 2000 के सभी संिभों को फे मा (एनडीआई) जनयमों से प्रजतस्ट्थाजपत दकया
िाएगा।
3.

मूल जनयम में, जनयम 2 के उप-जनयम (1) में,
(क) खंड (च) में, िब्ि, कोष्ठक और आंकडे " जिजनयमन 5 के उप जिजनयमन (1) के खंड (i)" और िब्ि और अिर
"जिजनयमन 6" का लोप दकया िाएगा।
(ख) खंड (ि) में, िब्ि, कोष्ठक और आंकडे "जिजनयम 5 के उप-जिजनयमन (2), (2क), (3) और (8)" का लोप दकया
िाएगा।

4.

मूल जनयम में, जनयम 3 में, िब्ि "ऐसी भारतीय बीमा कं पनी की प्रित्त इदिटी पूंिी के चौहत्तर प्रजतित से अजधक

करने के जलए" िब्िों को "बीमा अजधजनयम, 1938 द्वारा यथा जनधागठरत सीमा से अजधक करने के जलए" िब्िों के साथ
प्रजतस्ट्थाजपत दकया िाएगा।
5.

मूल जनयम में, जनयम 4 के उप-जनयम (1),
(क) खंड (क) का लोप दकया िाएगा।
(ख) खंड (ख) का लोप दकया िाएगा।
(ग) व्याख्या का लोप दकया िाएगा।

6.

मूल जनयम में, जनयम 4 के उपजनयम (2) का लोप दकया िाएगा।

7.

मूल जनयम में, जनयम 4क का लोप दकया िाएगा।

8.

मूल जनयम में, जनयम 5 को जनम्नजलजखत के साथ प्रजतस्ट्थाजपत दकया िाएगा, अथागत: —
“5. भारतीय बीमा कं पनी के जििेिी जनिेि प्रस्ट्तािों को बीमा अजधजनयम, 1938 द्वारा यथा जनधागठरत प्रित्त इदिटी
पूंिी के जलए भारतीय बीमा विवियामक और विकास प्राविकरण द्वारा सत्यापि के अध्यिीि स्ट्िचाजलत मागग पर
अनुमजत िी िाएगी।”।

9.

मूल जनयम में, जनयम 7 में, िब्िों, कोष्ठकों और अंकों "के जिजनयम 5 के उप-जिजनयमन (2), (2क), (3) और (8)"

का लोप दकया िाएगा।

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

10.

भारत का रािपत्र : असाधारण

3

मूल जनयम में, जनयम 9 के उप-जनयम (3) में, खंड (ii), (iii), (v) और (vii) का लोप दकया िाएगा।

[फा. सं. 13011/19/2013-बीमा-II]
प्रिांत कु मार गोयल, संयुक्त सजचि

ठटप्पणी: मूल जनयम को भारत के रािपत्र, असाधारण, भाग II, खंड 3, उपखंड (i) में अजधसूचना संख्या सा.का.जन.115(अ),
दिनांक 19 फरिरी, 2015 द्वारा प्रकाजित दकए गए थे और बाि में इसे अजधसूचना संख्या सा.का.जन.534(अ),
दिनांक

3

िुलाई,

2015,

सा.का.जन.314

(अ),

दिनांक

16

माचग,

2016,

सा.का.जन.619(अ)

दिनांक 2 जसतंबर, 2019 और सा.का.जन. 337(अ), दिनांक 19 मई, 2021 द्वारा संिोजधत दकया गया था।

MINISTRY OF FINANCE
(Department of Financial Services)
NOTIFICATION
New Delhi, the 29th August, 2025
G.S.R. 591(E).— Draft rules to amend the Indian Insurance Companies (Foreign Investment) Rules, 2015,
which the Central Government proposes to make in exercise of the powers conferred by clause (aaa) of sub-section (2)
of section 114 of the Insurance Act, 1938, read with sub-clause (b) of clause (7A) of section 2 of the said Act, are hereby
published for information of all persons likely to be affected thereby, and notice is hereby given that the said draft rules
will be taken for publication in the Gazette of India after the expiry of a period of fifteen days from the date on which
the copies of the draft rules are made available to the public.
Objections or suggestions, if any, from persons likely to be affected may be addressed to the Secretary, Ministry
of Finance, Department of Financial Services, Jeevan Deep Building, 3rd floor, Sansad Marg, New Delhi 110001.
Objections or suggestions that may be received from persons likely to be affected with respect to the draft rules
within the aforesaid period shall be considered by the Central Government.

DRAFT RULES
1. Short title and commencement:
(1) These rules may be called the Indian Insurance Companies (Foreign Investment) Amendment Rules, 2025.
(2) They shall come into force from the date of their publication in the Official Gazette.
2. In the Indian Insurance Companies (Foreign Investment) Rules, 2015 (hereinafter referred to as the principal rules),
all references to Foreign Exchange Management (Transfer or Issue of Security by a Person Resident Outside India)
Regulations, 2000 shall be substituted with Foreign Exchange Management (Non-Debt Instrument) Rules, 2019
(hereinafter referred to as the FEMA (NDI) Rules), and all references to FEMA Regulations 2000 shall be substituted
with FEMA (NDI) Rules.
3. In the principal rules, in sub-rule (1) of rule 2,
(a) in clause (f), the words, brackets and figures “clause (i) of sub regulation (1) of regulation 5 of” and the
word and letter “Regulation 6 of” shall be omitted.
(b) In clause (h), the words, brackets and figures “sub-regulations (2), (2A), (3) and (8) of regulation 5 of”
shall be omitted.

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

4. In the principal rules, in rule 3, the words “to exceed seventy-four percent of the paid- up equity capital of such Indian
Insurance Company” shall be substituted with the words “to exceed the limit as stipulated by the Insurance Act,1938”.
5. In the principal rules, sub-rule (1) of rule 4,
(a) clause (a) shall be omitted.
(b) clause (b) shall be omitted.
(c) Explanation shall be omitted.
6. In the principal rules, sub-rule (2) of rule 4 shall be omitted.
7. In the principal rules, rule 4A shall be omitted.
8. In the principal rules, rule 5 shall be substituted with the following, namely:—
“5. The Foreign Investment proposals of the Indian Insurance Company shall be allowed on the automatic route
for the paid–up equity capital as stipulated by the Insurance Act, 1938 subject to verification by the Insurance
Regulatory and Development Authority of India.”.
9. In the principal rules, in rule 7, the words, brackets and figures “sub-regulations (2), (2A), (3) and (8) of regulation 5
of” shall be omitted.
10. In the principal rules, in sub-rule (3) of rule 9, clause (ii), (iii), (v) and (vii) shall be omitted.

[F. No. 13011/19/2013-Ins.II]
PARSHANT KUMAR GOYAL, Jt. Secy.

Note: The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i), vide
notification number G.S.R. 115 (E), dated the 19 th February, 2015 and were subsequently amended by
notification numbers G.S.R. 534(E), dated the 3 rd July, 2015, G.S.R. 314(E), dated the 16th March, 2016,
G.S.R. 619(E), dated the 2nd September, 2019 and G.S.R. 337(E), dated the 19 th May, 2021.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH KUMAR
SRIVASTAVA
Date: 2025.08.29 21:43:15 +05'30'
