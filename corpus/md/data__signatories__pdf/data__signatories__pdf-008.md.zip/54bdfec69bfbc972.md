---
doc_id: "54bdfec69bfbc972"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/e09bf891ee869eb4db30ad2864f58b33.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "E-tender notice for lifting of torn bits / waste paper etc. in Udyog Bhawan - regarding cancellation of e-tender notice"
date: "2025-06-30"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7a40450604157624"
---

<!-- page 1 -->

No.D-27017/1/2017-SEO
Government of India
Ministry of Commerce and Industry
Department of Industrial Policy and Promotion

****

Udyog Bhawan, New Delhi
Dated the2,9, December, 2017.

NOTICE
Subject: E-tender notice for lifting of torn bits/waste paper etc. in Udyog Bhawan- regarding
cancellation of e-tender notice.

The undersigned is directed to refer to this Department's e-tender notice of even number
dated 20 th November, 2017 on the subject cited above and to say that the above e-tender notice
has been cancelled as only one online pre-qualification/technical bid was received on
http://eprocure.gov.in/eprocure/app Portal in this Department.
2.
The applicant is requested to collect the EMO submitted from SEO Cell, DIPP, Room No.
28, Udyog Bhawan, New Delhi.

(S. ts~

Copy to:-

Under Secretary to the Govt. of India.
Tel. No. 23063697

1. NIC, DIPP with the request to upload the above notice in the website of DIPP and
http://eprocure.gov.in/eprocure/app for wide publicity.
