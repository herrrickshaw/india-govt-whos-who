---
doc_id: "47faaed56f74c5ef"
source_url: "http://www.moef.gov.in/uploads/2017/08/ERF-2024.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "G.S.R.34(E), [15/01/2020]: Environment Relief Fund Scheme, 2008 – फंड मैनेजर की नियुक्ति"
date: "2017-08"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "939cab06bd911d4d"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. NO. D. L.-33004/99

xxxGIDHxxx

सी.जी.-डी.एल.-अ.-16012020-215489
xxxGIDExxx
CG-DL-E-16012020-215489
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 32]
No. 32]

नई ददल्ली, बुधवार, िनवरी 15, 2020/पौर् 25, 1941
NEW DELHI, WEDNESDAY, JANUARY 15, 2020/PAUSHA 25, 1941

पयाावरण, वन और िलवायु पररवतान मंत्रालय
अजधसूचना
नई ददल्ली, 15 िनवरी, 2020
सा.का.जन. 34(अ).—कें द्रीय सरकार ने लोक दाजयत्व बीमा अजधजनयम, 1991 (1991 का 6) की धारा 7क
द्वारा प्रदत्त िजियों का प्रयोग करते हुए, तत्कालीन पयाावरण और वन मंत्रालय में अजधसूचना संख्या सा.का.जन.
768(अ), तारीख 4 नवंबर, 2008 द्वारा पयाावरण राहत जनजध स्ट्कीम, 2008 नामक स्ट्कीम को अजधसूजचत दकया है;
और पयाावरण राहत जनजध स्ट्कीम, 2008 के पैरा 4 के उप-पैरा (1) में उपबंध दकया गया दक यूनाइटेड इं जडया
इं श्योरें स कं पनी जलजमटेड उक्त स्ट्कीम की अजधसूचना की तारीख से पांच वर्ा की अवजध के जलए उक्त स्ट्कीम का
जनजध प्रबंधक होगी;
उक्त जनजध प्रबंधक की पांच वर्ा की अवजध 3 नवंबर, 2013 को समाप्त हो गई थी;
और कें द्रीय सरकार ने भारत सरकार के तत्कालीन पयाावरण और वन मंत्रालय की अजधसूचना संख्या
सा.का.जन. 497(अ), तारीख 10 िुलाई, 2014 द्वारा यूनाइटेड इं जडया इं श्योरें स कं पनी जलजमटेड को आगे 31
ददसंबर, 2014 तक की अवजध के जलए जनजध प्रबंधक के रूप में पुन: जनयुक्त दकया था;
और कें द्रीय सरकार ने भारत सरकार के पयाावरण, वन और िलवायु पररवतान मंत्रालय की अजधसूचना संख्या
का.आ. 287(अ), तारीख 30 िनवरी, 2015 द्वारा यूनाइटेड इं जडया इं श्योरें स कं पनी जलजमटेड को आगे 30 िून,
2015 तक की अवजध के जलए जनजध प्रबंधक के रूप में पुन: जनयुक्त दकया था;
292 GI/2020

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

और कें द्रीय सरकार ने भारत सरकार के पयाावरण, वन और िलवायु पररवतान मंत्रालय की अजधसूचना संख्या
का.आ. 1878(अ), तारीख 13 िुलाई, 2015 द्वारा यूनाइटेड इं जडया इं श्योरें स कं पनी जलजमटेड को आगे 31 ददसंबर,
2015 तक की अवजध के जलए जनजध प्रबंधक के रूप में पुन: जनयुक्त दकया था;
और भारत सरकार ने पयाावरण, वन और िलवायु पररवतान मंत्रालय की अजधसूचना संख्या का.आ. 256(अ)
तारीख 27 िनवरी, 2016 में संिोधन द्वारा आगे 31 माचा, 2016 तक की अवजध के जलए जनजध प्रबंधक की अवजध
बढा दी थी;
और कें द्रीय सरकार ने भारत सरकार के पयाावरण, वन और िलवायु पररवतान मंत्रालय की अजधसूचना संख्या
सा.का.जन. 606(अ), तारीख 16 िून, 2016 द्वारा यूनाइटेड इं जडया इं श्योरें स कं पनी जलजमटेड को आगे 31 माचा,
2019 तक की अवजध के जलए जनजध प्रबंधक के रूप में पुन: जनयुक्त दकया था;
और भारत सरकार ने पयाावरण वन और िलवायु पररवतान मंत्रालय की अजधसूचना संख्या सा.का.जन.
419(अ), तारीख 13 िून, 2019 द्वारा आगे 30 िून, 2019 तक की अवजध के जलए जनजध प्रबंधक की अवजध बढा दी
थी;
और भारत सरकार ने पयाावरण वन और िलवायु पररवतान मंत्रालय की अजधसूचना संख्या सा.का.जन.
538(अ), तारीख 31 िुलाई, 2019 द्वारा आगे 15 अगस्ट्त, 2019 तक की अवजध के जलए जनजध प्रबंधक की अवजध
बढा दी थी;
अत:, अब, कें द्रीय सरकार, पयाावरण राहत जनजध स्ट्कीम, 2008 के पैरा 4 के उप-पैरा (2) के अनुसरण में और
अजधसूचना संख्या सा.का.जन. 606(अ), तारीख 16 िून 2016 को, उन बातों के जसवाय जिन्हें ऐसे अजधक्ांत करते
हुए अजधक्मण से पहले दकया गया है या करने का लोप दकया गया है, 15 अगस्ट्त, 2024 तक की अवजध के जलए
पयाावरण राहत जनजध स्ट्कीम, 2008 के अधीन जनजध प्रबंधक के रूप में यूनाइटेड इं जडया इं श्यारें स कं पनी जलजमटेड को
पुन: जनुयक्त करती है।
[फा.सं. 18-13/91-पीएल-एचएसएमडी]
गीता मेनन, संयुक्त सजचव
रटप्पण : मूल अजधसूचना सा.का.जन. 768(अ), तारीख 4 नवंबर, 2008 द्वारा भारत के रािपत्र में प्रकाजित की गई
थी।
MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 15th January, 2020
G.S.R. 34(E).—Whereas, in exercise of the powers conferred by section 7A of the Public Liability
Insurance Act, 1991 (6 of 1991), the Central Government in the erstwhile Ministry of Environment and Forests
vide notification number GSR 768(E), dated the 4th November, 2008, notified a scheme, namely, the
Environment Relief Fund Scheme, 2008;
And whereas, sub-paragraph (1) of paragraph 4 of the Environment Relief Fund Scheme, 2008 provided
that the United India Insurance Company Limited shall be the Fund Manager of the said scheme for a period of
five years from the date of notification of the said scheme;
And whereas, the five year term of the said Fund Manager expired on 3rd November, 2013;
And whereas, the Government of India in the erstwhile Ministry of Environment and Forests vide a
notification number G.S.R. 497 (E), dated the 10th July, 2014, the Central Government reappointed the United
India Insurance Company Limited as a Fund Manager for a further period upto 31st December, 2014;

<!-- page 3 -->

भाग II खण्ड

(i)

भारत का रािपत्र : असाधारण

3

And whereas, the Government of India in the Ministry of Environment, Forest and Climate Change vide
notification number S.O. 287 (E), dated the 30th January, 2015, the Central Government reappointed the United
India Insurance Company Limited as a Fund Manager for a further period upto 30th June, 2015;
And whereas, the Government of India in the Ministry of Environment, Forest and Climate Change vide
notification number S.O. 1878 (E), dated the 13th July, 2015, the Central Government reappointed the United
India Insurance Company Limited as a Fund Manager for a further period upto 31st December, 2015;
And whereas, the Government of India in the Ministry of Environment, Forest and Climate Change by an
amendment to notification number S.O. 256 (E), dated the 27th January, 2016, extended the tenure of Fund
Manager for a further period upto 31st March, 2016;
And whereas, the Government of India in the Ministry of Environment, Forest and Climate Change vide
notification number GSR 606 (E), dated the 16th June, 2016, the Central Government reappointed the United
India Insurance Company Limited as a Fund Manager for a further period upto 31st March, 2019;
And whereas, the Government of India in the Ministry of Environment, Forest and Climate Change vide
notification number GSR 419 (E), dated the 13th June, 2019 extended the tenure of Fund Manager for a further
period upto 30th June, 2019 ;
And whereas, the Government of India in the Ministry of Environment, Forest and Climate Change vide
notification number GSR 538 (E), dated the 31st July, 2019, extended the tenure of Fund Manager for a further
period upto 15th August, 2019;
Now, therefore, in pursuance of sub-paragraph (2) of paragraph 4 of the Environment Relief Fund
Scheme, 2008, and in supersession of notification number G.S.R. 606(E), dated the 16th June, 2016, except as
respects things done or omitted to be done before such supersession, the Central Government hereby reappoints
the United India Insurance Company Limited as a Fund Manager under the Environment Relief Fund Scheme,
2008, for a period upto 15th August, 2024.
[F. No. 18-13/91-PL-HSMD]
GEETA MENON, Jt. Secy.

Note: The principal notification was published in the Gazette of India vide number G.S.R. 768 (E), dated the
4th November, 2008.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR VERMA

Digitally signed by MANOJ KUMAR
VERMA
Date: 2020.01.16 22:21:26 +05'30'
