---
doc_id: "48b5cbce9ba0db46"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/d5e0a7cbf1f39351ee77180c7c6ad4a4.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Notice Seeking Stakeholders Comments on Draft for Comment of Indian Telecom Security Assurance Requirements - ITSAR for 5G Disaggregated RAN gNB CU, DU & RU"
date: "2024-05-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "228ed08b5d0e52f6"
---

<!-- page 1 -->

Subject: Notice for seeking stakeholder inputs on the DFC (Draft For Comments) of Indian Telecom
Security Assurance Requirements (ITSAR) for 5G Disaggregated RAN gNodeB (CU, DU & RU)

Dear Stakeholders,
In exercise of the powers conferred by Section 7 of the Indian Telegraph Act, 1885 (13 of 1885), the
Central Government amended the Indian Telegraph Rules, 1951 to insert Rule 528 to 537 in Part XI under
the heading Testing & Certification of Telegraph. The new rules provide that every telecom equipment
must undergo prior mandatory testing and certification.
Telecom Engineering Centre (TEC) came out with Procedure for Mandatory Testing and
Certification of Telecommunication Equipment (MTCTE) in December 2017. The MTCTE document
outlines the procedure to operationalize the new Rules.
The testing and certification described in the MTCTE procedure document requires that the
equipment meets the Essential Requirements (ER). Security Requirement is part of ER for which the
equipment must be tested and certified against. The responsibility for framing Security requirements and
for Security testing and certification lies with National Centre for Communication Security (NCCS), a
centre under Department of Telecommunications headquartered at Bengaluru.
Security Assurance Standards (SAS) vertical under NCCS is responsible for drafting and finalizing
ITSARs for communication equipment. In this regard, an online meeting is scheduled for discussion with
the stakeholders (TSPs, M2M service providers, Application service providers, Device manufacturers,
OEMs, prospective labs, industry bodies, and academia) on the Draft for Comment ITSAR for 5G
Disaggregated RAN gNodeB (CU, DU & RU). The details of the online meeting and registration link are
as follows:
 Date of meeting: To be notified later
 Meeting link: will be shared later
The comments received from stakeholders will form the basis for discussion. Stakeholders are hereby
requested to participate in the above meeting & send their suggestions/comments/inputs to the
following e-mail addresses on or before 24.05.2024
1.
2.

Shri N Janardhan, Director (SAS-III), NCCS – dirsas3.nccs-dot@gov.in
Shri Ashutosh Diwakar, ADG (SAS-III), NCCS – adg3sasf.nccs-dot@gov.in

Draft for Comment ITSAR for 5G Disaggregated RAN gNodeB (CU, DU & RU) along with Cryptographic
Controls for ITSAR can be downloaded from NCCS website (https://nccs.gov.in).
In case of any queries, please call Sh. N Janardhan, at +919449080282 or Sh. Ashutosh Diwakar at
+919448173144

Thanks and regards
N Janardhan
Director (SAS-III)
O/o Sr DDG(NCCS), NCCS, DoT, Bengaluru-27.
