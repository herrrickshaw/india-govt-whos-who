---
doc_id: "4c6e06d9cfebad49"
source_url: "https://www.dahd.gov.in/static/uploads/2025/06/807f6c848d27ee18515964e6e8ce1db0.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "The work related to Gender Budgeting, Child Budgeting, and DDG in this Department is transferred to Budget Division of this Department with immediate effect."
date: "2024-12-05"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "347dac757dbc1372"
---

<!-- page 1 -->

A-11018/1 0/2024-Gen_Cord/(E-27

812)

Government of India
Ministry of Fisheries, Animal Hus
bandry and Dairying
Department Animal Husbandry and
Dairying

Krishi Bhawan, New Delhi-110001

Dated, the
OFFICE
2

With

the approval

of the

5" December, 2024

ORD
URVER
ER

Competent

Authority,

the work

related to Gender
Budgeting, Child Budgeting, and
DDG in this Departme nt is transferred
to Budget
Division of this Department with imm
ediate effect.
LR oA g

(Vikash Kumar Vikrosy)
Under Secretary to the Government of India
Tel: 011-23382779
To

N

LA

W~

Budget Division, DAHD

PSO to AS&FA, DAHD
US(Budget)/US(GC/PC)

All the officers of DAHD- through website/e-of
fice of DAHD
DDO/Cash/Genera!Nigilance/APAR/RTI/IT/IC
/ParliamentlHindi
Office Order Bundle/Spare Copies
NIC, DAHD-for uploading on the website and
E-office of DAHD
