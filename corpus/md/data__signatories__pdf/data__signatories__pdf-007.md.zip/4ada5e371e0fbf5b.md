---
doc_id: "4ada5e371e0fbf5b"
source_url: "https://mnre.gov.in/static/uploads/2025/07/d70555b33fdca77d1e465414ac6225e5.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Scheme Sanction and Corrigendum Order of GEC-I"
date: "2017-12-20"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "42f5cc43e05270b7"
---

<!-- page 1 -->

F. No. 9/3/2014-EFM

Government of India
Ministry of New & Renewable Energy
Block No. 14, CGO Complex, Lodhi Road,
NewDelhi-110003, Dated: -31.10.2017
To
The Pay & Accounts Officer,
Ministry of New & Renewable Energy,
Pt. Deen Dayal Antyodaya Bhawan,
New Delhi- 110003.

Sub:- Corrigendum-National Clean Energy Fund (NCEF) support for creation oflntraState Transmission System in the State of Andhra Pradesh, Himachal Pradesh,
Gujarat, Karnataka, Madhya Pradesh, Maharashtra, Rajasthan and Tamil Nadu
under Green Energy Corridor project.
Sir,
This is in reference to the Administrative Approval with no. 11/7/2015-EFM, dated
30.09.2015 for National Clean Energy Fund (NCEF) support for creation of Intra-State
Transmission System in the State of Andhra Pradesh, Himachal Pradesh, Gujarat, Karnataka,
Madhya Pradesh, Maharashtra, Rajasthan and Tamil Nadu under Green Energy Corridor
project.
2.

The first line be read as:

"I am directed to convey sanction ofthe President/or providing NCEF support ofRs.4056.67
crore for creation of intra-state transmission system in the States of Andhra Pradesh,
Himachal Pradesh. Gujarat, Karnataka, Madhya Pradesh, Maharashtra and Rajasthan in
a span of 5 years from 2015-16 to 2019-20, and in the State of Tamil Nadu in a span of 3
years from 2014-15 to 2016-17, under the Green Energy Corridor project."
instead of

''for creation of intra-state transmission system in the States ofAndhra Pradesh, Himachal
Pradesh. Gujarat, Karnataka, Madhya Pradesh, Maharashtra, Rajasthan and Tamil Nadu
in a span of 5 years from 2015-16 to 2019-20."
In continuation of the above, I am also directed to convey the sanction of the
President for extension of the commissioning time line for the creation of intra-state
transmission system in the State of Tamil Nadu by two years, i.e. up to 31.03.2019. The
3.

Implementing Nodal Department of the State of Tamil Nadu is directed to complete the project
within the said extension in all the aspects, including submission of three months performance

Page 1 of 2

<!-- page 2 -->

testing and certification of synchronization of grid so as to complete the project financially,
latest by 31.03.2019.
4.

This sanction issues in exercise of powers delegated to this Ministry and with the

approval of competent authority and concurrence of IFD vide their Diary. No. 600 dated
31.10.2017.

Yours faithfully,

"~~

(Girish Kumar)
Director
Copy to:
1. Principal Director of Audit, CW & M.II (Science Audit), DACR Building, IP Estate, New
Delhi-110002.
2. The Principal Director (Local Bodies Accounts), Office of the Comptroller and Auditor
General oflndia, 9 Deen Dayal Upadhyay Marg, New Delhi- 110 002
3. Principal Accountant General of Tamil Nadu, Office of the Principal Accountant General
(General & Social Sector Audit), Lekha Pariksha Bhavan, 361, Anna Salai, Teynampet,
Chennai-600018.
4. Shri Vikram Kapur, Principal Secretary, Energy Department, Secretariat, Chennai600009.
5. Dr. M. Saikumar, Chairman, Tamil Nadu Transmission
(TANTRANSCO), 144, Anna Salai, Chennai-600002.

Corporation

Ltd.

6. PPS to Secretary, MNRE.
7. PPS to AS, MNRE
8. PPS to JS & FA/ PPS to JS(JNS), MNRE
9. IFD, MNRE

( Girish Kumar)
Director

Page 2 of 2

<!-- page 3 -->

F. No. 1117/20 IS-EFM
Government of India
Ministry of New and Renewable Energy
Block no. 14, CGO Complex.
Lodhi Road, New Delhi-I 10003
Dated: 30th September, 2015
To
The Pay & Accounts Officer
Ministry of New and Renewable Energy
New Delhi
Subject:

National Clean Energy Fund (NCEF) support of Rs 4056.67 crore for
creation of intra-state transmission system in the States of Andhra Pradesh,
Himachal Pradesh, Gujarat. Karnataka, Madhya Pradesh, Maharashtra.
Rajasthan and Tamil Nadu under Green Energy Corridor project.

Sir.
I am directed to convey sanction of the president for providing NCEF support of Rs
4056.67 crore for creation of intra-state transmission system in the States of Andhra Pradesh,
Himachal Pradesh. Gujarat, Karnataka, Madhya Pradesh, Maharashtra, Rajasthan and Tamil
Nadu under Green Energy Corridor project in a span of 5 years from 2015-16 to 2019-20.
2.
The Cabinet Committee on Economic Affairs (eCEA) in its rneeting held on 10
December 2014 and 16 July 2015 has approved the NCEF support for these projects. The
State-wise project cost and year-wise NCEF support is enclosed at Annexure-I.
3.
The project will be implemented in the States by the respective State '1ransmission
Utility. The terms & condition for release ofNCEF support are given at Annexure-H.
4.
The funds for implementation of the above scheme would be met from Demand No.
69-Ministry of Ne v,,' & Renewable Energy; Major Head: 2810- New and Renewable Energy;
00 - (Sub Major Head), 101 - Grid Interactive and Distributed Renewable Power, 01- Grid
Interactive Renewable Power, 05 - Green Energy Corridors, 31- Grants-in-Aid General for
the year 20 15-16(Plan).
5.
This sanction issues in exercise of powers delegated to this Ministry and with the
approval of competent authority and concurrence of IFD vide their Dv. No. 458 dated
30.09.2015.
»,

»,

-.

Enclosed: As above.
Yours faithfully,

(lK. Jethani)
Scientist-D

<!-- page 4 -->

Copy to:
1. Principal Director of Audit, CW &NLII, (Science Audit), DACR Building, IP Estate, New
Delhi -110 002.
2. Principal Secretary (Energy), Government of Andhra Pradesh!Himachal Pradesh!Gujarat/
KarnatakaIMadhya PradeshIMaharashtraIRajasthanlTamil
Nadu.
3. State Transmission Utility of Andhra PradeshlHimachal Pradesh!GujaratiKamatakal
Madhya PradeshfMaharashtralRajasthanlTamil
Nadu.
Copy also to:
1. PS to Hon'ble Minister, NRE
2. PSO to Secretary, MNRE
3. All Group Heads, MNRE
4. Cash Section
5. Sanction Folder

.i->:
(J.K.lethani)
Scientist-D

p'

". '

<!-- page 5 -->

")

Intra

I S.

b FInanced from NCEF
state T ransmissron sivstem proiects un der Green Enerzv Corrr ors - t~~~
Name of Scheme

\

I l~O.
System
1 Intra-State Transmission
for Renewable Power Evacuation
in Tamil Nadu
System
2 Intra-State Transmission
for Renewable Power Evacuation
in Rajasthan
System
3 Intra-State Transmission
for Renewable Power Evacuation
in Andhra Pradesh
System
4 Intra-State Transmission
for Renewable Power Evacuation
in Himachal Pradesh

Project
Cost
1593.00

NCEF Support
(in Cr.)
637.20

1018.30

Year Wise NCEF Support Re uired (in Cr.)
2015-16

2016-17

2017-18
.-

2018-19

2019-20

382.32

254.88

407.32

122.20

203.66

81.46

1289.25

515.70

128.93

257.85

128.93

910.52

364.21

91.05

182.10

91.05

1963.00

785.20

79.79

166.58

213.87

207.08

117.88

906.00

362.40

20.00

105.22

87.68

87.68

61.82

2100.00

840.00

84.00

420.00

336.00

361.61

144.64

41.60

67.02

26.06

9.96

10141.68

4056.67

949.89

1657.31

965.06

304.72

.-.

System
5 Intra-State Transmission
for Renewable Power Evacuation
in Gujarat
6 Intra-State Transmission System
for Renewable Power Evacuation
in Karnataka
7 Intra-State Transmission System
for Renewable Power Evacuation
in Madhya Pradesh
8 Intra-State Transmission System
for Renewable Power Evacuation
in Maharashtra
Total

179.70

<!-- page 6 -->

Annexure-Il
The terms & condition for release of NCEF support to the States of Andhra
Pradesh, Himachal Pradesh, Gujarat, Karnataka, Madhya Pradesh, Maharashtra,
Rajasthan and Tamil Nadu for creation of intra-state transmission system in under
Green Energy Corridor project
1. The States to ensure that the intra-state transrmssion
support caters to the renewable energy projects.

system developed from NCEF

2. The release of NCEF support will be linked to the progress and the respective State
Transmission Utility will submit physical and financial progress report in respect of the
NCEF support released for the project to enable subsequent release of NCEF support.
3. Respective State Transmission Utilities to submit monthly progress report of the project
in the format prescribed to the Ministry of New & Renewable Energy.
4. The State to ensure that transmission capacity is not left unutilised.
