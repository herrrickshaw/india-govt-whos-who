---
doc_id: "47dbb65e46f8cfab"
source_url: "https://www.dpiit.gov.in/static/uploads/2026/10/b1a31909c80cd86d4b14eb66d067ed3c.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Scanned GSTLI 6th Sanction 1(22)2026-SSS E-236330 amt 457959"
date: "2026-10-19"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3a5de98a54ba0f49"
---

<!-- page 1 -->

No. 1(22)/2026-SSS (E-236330)

Government of India

Ministry of Commerce & Industry

Department for Promotion of Industry & Internal Trade
(Special Scheme Section)

Vanijya Bhawan, New Delhi
Date: 17th September, 2026
To
The Accounts Officer,
Pay & Accounts Office,

Department for Promotion of Industry & Internal Trade,
GPOA-3, New Delhi

Subject: Release of an amount Rs. 4,57,959 (Rupees Four Lakhs Fifty Seven Thousand Nine
Hundred Fifty Nine only) as GSTLI under New Central Sector Scheme (NCSS), 2021 for
Industrial Development of J&K during the year 2026-27 in favour of Jammu & Kashmir
Development Finance Corporation Ltd. (JKDFC)

Sir,

-

reg.

I am directed to convey the sanction of the President for release of an amount Rs. 4,57,959

(Rupees Four Lakhs Fifty Seven Thousand Nine Hundred Fifty Nine only) in respect of 1
Goods & Services Tax Linked Incentive (GSTLI) claim of one industrial unit as per details at
Annexure under New Central Sector Scheme (NCSS), 2021 for Industrial Development of UT of
J&K.
2.

As per the Notification F.No.1(1)/2020-SSS dated 19th February 2021, J&K Development

Finance

Corporation Ltd (JKDFC) has been notified as the Nodal Agency for disbursal of

incentives under various scheme components.

3.

This is the 6th release under GSTLI component of the scheme during the current FY

2026-27. Including this present sanction, the total release under this head is Rs. 197,65,67,304
during the current financial year as against the budgetary allocation of Rs. 260 Crore in BE 2026-

27 and no utilization certificate under this component is pending from the JKDFC.
as per GFR 2017 rules, the due date for the submission of UC is within

It is stated that

12 months of the closure

of the financial year, so as no previous UC is pending with JKDFC.

The sanctioned amount may be released in favour of Jammu & Kashmir Development
No. 42741871542, State Bank
Finance Corporation Ltd. (JKDFC) to their Bank Account A/c

4.

Paray

मानस

AR ROY

ASH KUM

/ MAN
कुमार राय

etary
er Secr

IT
/Und
विभाग /DPI
रिक व्यपारn of C. B
त
ं
आ
र
औ
न
रालय / Mi ndia
उपयोग संवर्ध
उद्योग मं/त्
t. of Iin
र Gov
ाणिय और

व

का

भारत सर
0011
eih-11
New D
Vanijya

<!-- page 2 -->

of

India,

Branch

SBIN0006894.
5.

Railway

Station, Jammu RTGS/MICR No.180002006 IFSC Code

The Expenditure is debitable to Demand No. 11 of the Department for Promotion of

Industry & Internal Trade for the financial year 2026-27 under the following head:
2885-

0202.1011919.0419.04.33

Other Outlay on Industries & Minerals (Major Head)

Development of Backward Areas (Sub Major Head)
Subsidies (Minor Head)
Industrial Development of UT of Jammu & Kashmir
Goods & Services Tax Linked Incentive (GSTLI)
Subsidies

6.
Release of the above-mentioned amount to JKDFC is subject to the following terms
and
conditions:
1.

JKDFC will maintain a separate account of the funds released by this Department towards

"Capital Investment Incentive" for disbursal of Incentive to the beneficiary units as per the
details enclosed.

II.

III.

IV.

JKDFC shall verify every claim before disbursement and shall disburse the incentive to the

eligible units immediately upon receipt of funds from DPIIT.
The expenditure incurred shall be open to inspection by the sanctioning
authority/CAG/Internal Audit Party of the Chief Controller of Account, Ministry of
Commerce & Industry, Department for Promotion of Industry & Internal
Trade.
After disbursement of subsidy for the purpose for which it has been sanctioned,
JKDFC
will submit to the Department for Promotion of Industry and Internal

Trade, New Delhi,
the Utilization as per GFR 12-A within twelve months of the closure of financial
year and
no further funds will be released unless the
entire amount previously released is fully
utilized and utilization certificates are furnished within time.
V.

A detailed statement of the incentive disbursed indicating the

names of the

and the amount of incentive released to each on the date of approva
furnished by JKDFC along with the Utilization Certificate.

VI.

l of the SLC shall be

JKDFC would devise a suitable mechanism to ensure adequate transpar
in the disbursal of subsidies. JKDFC shall furnish
an

VII.

beneficiaries,

ency and fairness

undertaking that they have been

following the provision of Rule-4 (I)(a) and (b) of the RTI Act, 2005.

JKDFC to ensure that the amount is released to the individual unit(s) only after verifying

that these units have not been paid earlier.

Payment to units should be made through Electronics Money Transfer directly to their

account.

0

7

मानस कुमार राय / MANASH KUMAR ROY

1

VIII.

अवर सचिव Under Secretary
उपयोग संवर्धन और आंतरिक व्यपार विभाग/DPIT
वाणिज्य और उद्योग मंत्रालय / Min of C. & i
भारत सरकार /Govt of Inudia

नई दिला 110017

Vanijya, New Dolhi 11О

<!-- page 3 -->

<!-- page 4 -->
