---
doc_id: "4ce66edaf8b147df"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/07238f5cf600dd0ad570172a80ad1e63.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Retirement on Superannuation of officer of P and T BWS Group A Service  Mr  K G Garg"
date: "2026-02-27"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "fa9f40b6167f7b95"
---

<!-- page 1 -->

F. No. 34-04/2024-EW
Government of India
Ministry of Communications
Department of Telecommunications
(A&E Section)
618-A, Mahanagar Doorsanchar Bhawan,
J.L. Nehru Marg, New Delhi- 110002
Date: 27.02.2026
ORDER
On attaining the age of superannuation, Shri Krishan Gopal Garg (Staff
No. 96508), Sr. DDG (BW), DoT HQs, an officer of P&T BWS Gr ‘A’ is permitted
to retire from Government Service w.e.f. 28.02.2026 (A/N). The officer is struck
off from the strength of Department of Telecommunications Headquarters (DoT
HQ) w.e.f. 28.02.2026 (A/N).
2: As per record, no vigilance/disciplinary proceedings is pending against the
above-mentioned officer.
3. A copy of the charge relinquished report may be forwarded to all concerned.
saa eH ea Kuma Stinghh
Director (Electrical)
Ph: 011-23218925
Copy forwarded to:
1. PSO to Secretary(T)/ Secretary (Posts)
2. PSO to Member (S)/ Member(T)/ Member(F), DoT
3. Shri Krishan Gopal Garg, Sr. DDG (BW), DoTHQs
4. Sr DDG (Estt.)/ DDG(C&A), DoT
5. DDG (EW), DoT HQs.
6. Director (Accounts)/Director (IT), DoT
7. Director (Civil)/ Director (Architecture), DoT HQs.
8. SO (Pay Bill/ Cash/ Pension/ PFP/ PAO/ Admn-I, Il, Ill, 1V/ G-l/G- II/Lib/PHP
Section), AO (STG) DoT HQ
9. OL Section, DoT HQ-for Hindiversion
10. Director (EW), DoT HQs for uploading on DoT website.
11. Order Bundle
