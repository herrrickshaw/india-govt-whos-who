---
doc_id: "4c6b9eda0d0e33db"
source_url: "https://rural.gov.in/static/uploads/2024/02/13xyz.pdf"
ministry: "Rural Development (MoRD)"
title: "D.O letter in respect of all the Officers/ Officials of DoRD to register themselves on i-GOT Portal and to complete Level 1- Online Course on Emerging Technologies, 01 May, 2023"
date: "20230428"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e2d7247a3f1945dc"
---

<!-- page 1 -->

File No. M-12017/01/2019-Trg (Computer No. 368856)

862612/2023/Administration

1
Generated from eOffice by RABISH KUMAR, Research Officer(TRAINING), RESEARCH OFFICER, MORD on 01/05/2023 11:50 AM

<!-- page 2 -->

File No. M-12017/01/2019-Trg (Computer No. 368856)

858245(17)/2023/TRAINING

1
Generated from eOffice by RABISH KUMAR, Research Officer(TRAINING), RESEARCH OFFICER, MORD on 01/05/2023 11:53 AM

<!-- page 3 -->

File No. M-12017/01/2019-Trg
M-12017/01/2019-Trg
(Computer No. 368856)

847525(47)/2023/TRAINING
858245(17)/2023/TRAINING

2
Generated from eOffice by RABISH KUMAR, Research Officer(TRAINING), RESEARCH OFFICER, MORD on 01/05/2023 11:53 AM

355/395

<!-- page 4 -->

File No. M-12017/01/2019-Trg
M-12017/01/2019-Trg
(Computer No. 368856)

836822(44)/2023/TRAINING
847525(47)/2023/TRAINING
858245(17)/2023/TRAINING

1
3
Generated from eOffice by RABISH
RAKESH KUMAR,
KUMAR, Research
EO(Training)
Officer(TRAINING),
RK, EO, MORD RESEARCH
on 10/03/2023
OFFICER,
02:28 MORD
PM
on 01/05/2023 11:53 AM

356/395

<!-- page 5 -->

File No. M-12017/01/2019-Trg
M-12017/01/2019-Trg
(Computer No. 368856)

836822(44)/2023/TRAINING
847525(47)/2023/TRAINING
858245(17)/2023/TRAINING

2
4
Generated from eOffice by RABISH
RAKESH KUMAR,
KUMAR, Research
EO(Training)
Officer(TRAINING),
RK, EO, MORD RESEARCH
on 10/03/2023
OFFICER,
02:28 MORD
PM
on 01/05/2023 11:53 AM

357/395

<!-- page 6 -->

File No. M-12017/01/2019-Trg
M-12017/01/2019-Trg
(Computer No. 368856)

835032(3)/2023/O/o SECRETARY (RD)
836822(44)/2023/TRAINING
847525(47)/2023/TRAINING
858245(17)/2023/TRAINING

3
5
Generated from eOffice by RABISH
RAKESH KUMAR,
KUMAR, Research
EO(Training)
Officer(TRAINING),
RK, EO, MORD RESEARCH
on 10/03/2023
OFFICER,
02:28 MORD
PM
on 01/05/2023 11:53 AM

328/330
358/395

<!-- page 7 -->

File No. M-12017/01/2019-Trg
M-12017/01/2019-Trg
(Computer No. 368856)

835032(3)/2023/O/o SECRETARY (RD)
836822(44)/2023/TRAINING
847525(47)/2023/TRAINING
858245(17)/2023/TRAINING

4
6
Generated from eOffice by RABISH
RAKESH KUMAR,
KUMAR, Research
EO(Training)
Officer(TRAINING),
RK, EO, MORD RESEARCH
on 10/03/2023
OFFICER,
02:28 MORD
PM
on 01/05/2023 11:53 AM

329/330
359/395

<!-- page 8 -->

File No. M-12017/01/2019-Trg
M-12017/01/2019-Trg
(Computer No. 368856)

835032(3)/2023/O/o SECRETARY (RD)
836822(44)/2023/TRAINING
847525(47)/2023/TRAINING
858245(17)/2023/TRAINING

5
7
Generated from eOffice by RABISH
RAKESH KUMAR,
KUMAR, Research
EO(Training)
Officer(TRAINING),
RK, EO, MORD RESEARCH
on 10/03/2023
OFFICER,
02:28 MORD
PM
on 01/05/2023 11:53 AM

330/330
360/395
