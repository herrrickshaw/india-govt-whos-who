---
doc_id: "4c5ae2ac6fac3ce5"
source_url: "https://mnre.gov.in/static/uploads/2025/07/6d985b96deede55f4a6eaed966858e2c.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Programme on Energy from Urban, Industrial, Agricultural Wastes/Residues and Municipal Solid Waste” and “Scheme to Support Promotion of Biomass Based Cogeneration in Sugar Mills and Other Industries in The Country”- Notification of new guidelines-reg"
date: "2021-05-13"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ae00876b4bac049c"
---

<!-- page 1 -->

File No: 20/222/2016-17/WTE
Government of India
Ministry of New and Renewable Energy
(Waste to Energy Division)
CGO Complex, Lodhi Road,
New Delhi,
13.05.2021
OFFICE MEMORANDUM
Subject: “Programme on Energy from Urban, Industrial, Agricultural Wastes/Residues
and Municipal Solid Waste” and “Scheme to Support Promotion of Biomass Based
Cogeneration in Sugar Mills and Other Industries in The Country”- Notification of new
guidelines-reg.
The scheme to support promotion of biomass-based cogeneration in sugar mills and other
industries was notified vide OM 3/141/2017-CPG dated 11.05.2018 and the Programme on
Energy from Urban, Industrial, Agricultural Wastes/Residues and Municipal Solid Waste was notified
vide OM 20/222/2016-17-WTE dtd 28.02.2020. The schemes were valid till 31.03.2021.

2. In this regard, it is to inform that proposal for continuation of the above-mentioned
schemes is under review. Accordingly, guidelines for the period of FY2021-22 to FY2025-26
in respect of these schemes will be notified in due course after the process of obtaining
necessary
approvals
from
the
competent
authorities
are
completed. Necessary notifications regarding the same will be uploaded on MNRE website.
3.

This has the approval of competent authority.

(Vijay Bharti)
Scientist ‘C’
Email: vijay.mnre@gov.in
To,
All Concerned
Copy to:
1. Sr PPS to Secretary, MNRE
2. PPS to JS (Bioenergy), MNRE
3. Director (Bioenergy)
4. NIC MNRE with a request to upload it on the website.
