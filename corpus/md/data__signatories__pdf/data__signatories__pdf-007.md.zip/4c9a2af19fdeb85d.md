---
doc_id: "4c9a2af19fdeb85d"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/c4a3ace233ddd59749dcfe164a20d6e1.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Appointment of Vice-Chancellor of Visva-Bharati (A Central University)"
date: "2018-04-26"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "62863d29cf0e80d7"
---

<!-- page 1 -->

3

Government of India
Ministry' of Human Resource Development
Department of Higher Education
Appointment of Vice-Chancellor of Visva-Bharati (A Central University)
Visva-Bharati is an Institution of National Im portance.
The Vice-Chancellor, being the academic as well as administrative head, is
expected to be:
•

A visionary with proven leadership qualities, administrative capabilities as well as
teaching and research credentials.

•

Having outstanding academic record throughout and a minimum of to years’
experience as a Professor in a University system or in an equivalent position in a
reputed research and/or academic administrative organisation.

•

Preferably not more than 65 years of age as on the closing date of receipt of
applications of this advertisement.

Salary and Service Conditions
•

The post carries a pay of Rs. 2,10,000/- (Fixed) per month with Special Allowance
of Rs. 5000/- and other usual allowances.

•

The terms and conditions of the services will be those as set forth in the Act,
Statutes and Ordinances of the University.

Procedure for appointment
•

Appointment will be made from a panel of names recommended by a Committee
constituted under the provisions of Visva-Bharati Act.

•

The advertisement and the format of application are available on the websites
http://mhrd.gov.in and www.visvabharati.ac.in

•

The applications in the prescribed proforma should reach within 30 days from
the date of the publication of this advertisement, by Registered/Speed Post to:
Shri Surat Singh, Deputy' Secretary',
Department of Higher Education, Ministry of IIRD,
Room No.325, ‘C’ Wing, Shastri Bhawan, New Delhi-110115

“Application for the post of Vice Chancellor, Visva-Bharati”, should be
super-scribed on the envelope.
This D epartm ent is not responsible for postal delay.
*****

<!-- page 2 -->

RTRcT RRRRR
RTRR RRTfaR fcTcp'M RWfcTR
1%STT f/)'R 111

ft?R-RRcft (RNto f^cjf^Tdil) ifc SgerqfrT R>t Prgfaef
fcT^-RTRcrt Tfcp

R^?R R>1 RR-SJTR 11

si^ R to ? g* RTPR-Rim wsrraPto jrg®r wfif <& rrrot. ^erqfrr Rt m
•

g>t wicfr %
■■

f&g iRjcR r> ■rpoff ofNr rruf Pi* erRcrrsrf % '^<w rr>

<# war f^raror afk rtHi

rcrt?tr> itoT i

•

fc|?qfc|£<lcra P I T # if MTWR R> RiR if '•/{;kM 10 RR R> 3TJRR R> RTTaj ^3?cps: SIRRRfircp
f^pM RR /PTT RT ^SRlfcT RT^cT RTlkT/3TR7R#RP 5T?TR#PP TPTOR if RFHJRq RR RR # T f I

•

?Rf fcT^TFR if 3RRRR Rlf^T $1 FHIRH ferf§f RR 65 Rif cj5t 3TTg ^ 3T^TSp 3TRg RR F$f # !T

3#? ^RT rf !
•

fRt RR RR 2 ,1 0 .0 0 0 /- RRRR {f^rf^Rcf) RfafTTF R5 RTW 5 , 0 0 0 / - RRRR RR

W

3fk

3RJ WfFR RoTf m ^TcTFI FfcTT 11
•

^RT3ff R> ffpR£R 3fk Rf3 R f # ifl vjft feRerf^ErTero R> afftf^RFH, Tilfcrf^mt cT2R 3TSRi/ ri} if
t M

t i

fa g fo r %% RfeRT
•

R1 f^gfeRT RF^pJ f?t?c|fctelMR

2009 R> RTRWFTT R> 3TcPfcT FfecT ^

STCT f^TWf^T f ^ iTTT RIFT # ^

•

•

^Tef if Rf R§t «mpfl |

R?
R siim
affc sfickH
rr
RR5f
vvw w . v isv a b h a ra t i. a c . in RR ^nteW 11
HR5ptf if OT^eFT

cirfi^ c

h ttp ://m h rd .g o v .in

REJECT ftfF, ^3R RTf^R,

P c!?R %5Tf f^RFT, RTRR RRfTOR f^RRRT WTeTR,
feWP# RR 'RgcIRlcr ^ RR

R f f^RTR. ^IRP f?Tei*R

f^T, W ^ \ FRR,

fte e ft- 110 115

SfT^RR - f^R-RTReff' RRRfeffecf ?tRT

f&r^%RIR

3ik

fcfsJTCR <fc RR>T?H eft ferfsT F 30 fcp=T R5 dteR ^ f/rR ^ f/? 4 te

RT'Rf gTRT fipR Ref RR RtfiF? xfT%/

R>*RT RTO 325, #

FfirfeT

11

|

<!-- page 3 -->

Format of Application for the post of Vice-chancellor of Visva-Bharati

Affix the latest
passport size Photo

(Applicant is requested to type the information in the following format, and can add more lines in the
format wherever required.)
1. General Information of Applicant
Name
(In Capital Letters)
Date of Birth
(Day/Month/Year)
Correspondence
Address

Mobile No. :
Phone No.
Landline No. :
Email

2. Present Position
a.

Designation

b.

Organization

c.
d.

Pay Scale
Date of
appointment to
the present post
Total Experience
(In Years and
Months)

e.

3. Details of experience possessed as per eligibility criteria:
(10 years’ Professorship or equivalent as per UGC Regulations on Minimum Qualifications for
Appointment of Teachers and other Academic Staff in Universities and Colleges and Measures
for Maintenance of Standards in Higher Education 2010 and subsequent modifications)
S.No.

Post held

Pay Scale

Organisation

Nature of duties

Experience
(In Years and
Months)

<!-- page 4 -->

#
4.Educational Qualification (In chronological order from latest to Graduation level)
S.No.

Qualification

University

Year

Subject(s) /
Topic(s)

%
Achieved

Distinctions
etc.

5. Administrative Experience/Post(s) & responsibilities held
S.
No.

Post

1.

Head of the Department
Chairman, Board of
Studies
Member, Board of
Studies
Dean of Faculty
Member of Academic
Council
Member of Executive
Council
Member of Professional/
Academic Bodies
Others (Specify)

2.
3

4.
5.
6.
7.
8.

Organization/
University

From
(Date)

Duration
To
(Date)

Experience
(In Years and
Months)

6. (a) Academic/Teaching Experience & responsibilities (In chronological order from latest to oldest)
S. No.

Post

Organization/
University

From
(Date)

Duration
To
(Date)

Experience
(In Years
and Months)

(b) Participation and contribution in relevant areas in higher education
Organisation

Area of specialisation

Visiting Professor
Resource Person
Others (Specify)
(c) Involvement with formulation of academic programmes:
S.No.

Nomenclature of Innovative Academic
Programmes formulated

Date of approval by
Academic Council

Year of
Introduction

<!-- page 5 -->

(d) Important MoUs formulated for academic collaborations:

s.

MoUs formulated

No.

Name of Agencies/Departments
involved

Year of MolJ

Name of Agencies/Departments
involved

Period of holding
the Chair

(e) Position of Chairs:
S. No. Name of Chair

7. International academic Exposure, if any
S. No.

Post/
Assignment

Organization/
University

Area of Assignment
From

Duration
To
In Years &
Months

8. Scholarly achievements:

A. Contribution to Journals and Books:
Details
Books authored
Editor in Chief
Editorships
Peer reviewer for
Member of the International Advisory
Board
Others (Specify)
B. Publication:

B.I Kindly provide list of scholarly publications in recognised professional and/or academic journals:
Total Publications: ..................
S.No.

Date

Title

Name of journal

Refereed
journal or
not

Number of
Citations
(where possible)

<!-- page 6 -->

-4
B.II List of articles in popular magazines or newspapers
Total A r tic le s :...............
S.No.

Date

Title

Name of Magazine/
Newspaper

C. Participation and scholarly presentations in conferences:
C.I National
S.No.

Date

Title of Conference or Institution

Title/Subject of presentation (if made)

Title of Conference or Institution

Title/Subject of presentation (if made)

C.II International
S.No.

Date

D. Participation and contribution in National/International Fora in the area of your academic and
professional expertise
Number(s)
Plenary Lectures/Invited Talks
Congresses attended
Examinership etc.
Others (Specify)

International
National
International
National
International
National
International
National

9. Research Projects:
S.No.

Client/Organisation’s
name

Nature of project

Duration of
project

10. Consulting experience:

List key consulting assignments undertaken:
S.No.

Client/ Organisation’s
nam e

Nature of assignment

Duration of
a s s ig n m e n t

Amount
of grant
(Rupees)

<!-- page 7 -->

11.

Honours /Awards & Fellowships for Outstanding Work:

Sr.
No.

12.

Name of
Award/Fellowship
etc.

Awarded by

Year of Award

No. of Research Scholars successfully guided :

Name of Programme

13.

Elected/Honorary
Fellow

Awarded (No.) (Under-progress not to be included)

Strengths (in 100 words)

14. Your Vision for the University (upto 500 Words)

15. Details of Referees, if any
S. No.

Name of the
Referee

Post Held by
Referee

Email

Phone No.

Mobile

I, hereby, declare that all the statements/ particulars made/furnished in this application are true, complete and
correct to the best of my knowledge and belief. I also declare and fully understand that in the event of any
information furnished being found false or incorrect at any stage, my application/candidature is liable to be
summarily rejected at any stage and if I am already appointed, my services are liable to be terminated
without any notice from the post of Vice-Chancellor as per Act/ Statutes etc. and other applicable rules.

Place:
Date:
Note:

(Signature of the Applicant)

Total No. of pages (A-4 size) of the application should not exceed 10 pages.
