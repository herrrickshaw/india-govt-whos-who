---
doc_id: "4a2bbc1bc0507dba"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/69deb22e4cab0b58f58a0bb211bf9149.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allocation of separate numbering series exclusively for service and transactional voice calls as per TCCCPR 2018 notified under TRAI Act-1997"
date: "2024-12-23"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "bec31bd76ecb3a79"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
(Access Services Wing)
No. 16-072024-48-ा /४ Dated: 28.05.2024
To,
M/s RingCentral India Private Ltd.,
05-163, WeWork, DLF Forum,
Cyber City, DLF Phase-III,
Gurugram, Haryana-122002.
Subject:- Allocation of Signalling Point (SP) Codes regarding.
In consideration to the request of M/s RingCentral India Private Limited, the undersigned
is directed to convey the approval of competent authority for allocation of SP Code as below:-
IS. | Name of LSA Network {Address where \Proposed
INo.| TSP Element _|NE is to be Installed ISP code
Ms Karnataka |Dialogic RingCentral India Pvt. Ltd., C/o 12166
[RingCentral [Distribution ISTT-DC03, 1 Floor Hall 2, Plot
India Pvt. Ltd. Ltd. Softswitch} 49.145p, EPIP, KIADB, Whitefield,
and Medial IBangalore, Karnataka-560066
\Gateways
\(RingCentral
Internal name|
IBLRO1CSD02)
2. |M/s Mumbai {Dialogic IRingCentral India Pvt. Ltd., C/o Tata ]12167
RingCentral (Metro) Distribution ISTT DC, Tower B, 5‘ Floor, IDC
India Pvt. Ltd. Ltd. Softswitch }ya1) 2, Plot C-21 & C-36, G Block,
टिक [Bandra Kurla Complex, Vidyanagari
(RingCentral [Post Office, Mumbai-400098
Internal name
IBOM01CSD02
2. An allocated SP codes should be utilized within a period of 6 months from the date of
allocation. If the allocated SP codes are not utilized within this period, then the same should be
reported to DoT and surrendered.
3. Similarly, if a network element to which SP code was allocated has been decommissioned and
its further use is not planned within a period of next 6 months, the allocated SP code should be
surrendered.
—Wikarn
(Trilok Chandra)
Director (AS-III)
Ph 011-23372063
Copy forwarded for information and necessary action, if any, to:
1. Secretary, TRAIT.
2. CMD MTNL/ CMD BSNL.
3. DG, COAT.
4, Director (T), DGT, HQ with request to circulate the sanction to related LSA
Cells.
5. All TSPs.
6. Copy for upload on DoT website.
