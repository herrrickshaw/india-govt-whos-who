---
doc_id: "48a31e64bcbfdfd4"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/977a4c5363b1139b6a1270eaaeeded0e.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "RFQ-cum-RFP for appointment of Media Agency"
date: "2025-07-01"
pages: 54
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ba0422d454e334ce"
---

<!-- page 1 -->

DEPARTMENT OF INDUSTRIAL POLICY AND PROMOTION
Ministry of Commerce and Industry, Government of India

National Competitive Bidding (NCB)

APPOINTMENT OF MEDIA AGENCY
FOR
DEPARTMENT OF INDUSTRIAL POLICY AND PROMOTION
REQUEST FOR
QUALIFICATION –CUMREQUEST FOR PROPOSAL

JUNE 2015

Page 1 of 54

<!-- page 2 -->

NOTICE INVITING REQUEST FOR QUALIFICATION – CUM - REQUEST
FOR PROPOSAL
DEPARTMENT OF INDUSTRIAL POLICY AND PROMOTION

REQUEST FOR QUALIFICATION (RfQ) CUM REQUEST FOR PROPOSAL (RfP)
FOR SELECTION OF MEDIA AGENCY FOR DEPARTMENT OF INDUSTRIAL
POLICY AND PROMOTION
NATIONAL COMPETITIVE BIDDING
The Department of Industrial Policy and Promotion (DIPP)

had invited

proposals from interested applicants through Request for Qualification-cumRequest for Proposal (RfQ-cum-RfP) for appointment of Media Agency, floated
on Central Public Procurement Portal on 22.5.2015. The last date for submitting
proposal was 12.6.2015. The Competent Authority in the DIPP has decided to
cancel the above said tender process and call for fresh proposals for
appointment of Media Agency.
Department of Industrial Policy and Promotion, Ministry of Commerce and Industry,
Government of India, intends to undertake a 360 degree media

campaign

for

promotion of the Make in India initiative to brand India as an investment destination
across the world. The objective of the campaign is to generate awareness about the
investment opportunities and prospects of the country, to promote India as a preferred
investment destination in the source markets overseas and to increase India‘s share of
global FDI. The salient features of the project, eligibility criteria and prescribed formats
for submission can be accessed in the RfQ – cum - RfP document uploaded on Central
Public

Procurement

Portal

(http://eprocure.gov.in)

and

on

the

website:

http://dipp.nic.in.
Interested applicants are requested to submit their responses to the “RFQ –
Cum -RFP” on Central Public Procurement Portal (http://eprocure.gov.in) on
or before July 13th, 2015, 3:00 PM.
The submissions must be addressed to:
Deputy Secretary (BE-III),
Department of Industrial Policy and Promotion
Ministry of Commerce & Industry, Government of India
Udyog Bhawan
New Delhi-110011

Page 2 of 54

<!-- page 3 -->

Disclaimer
1.

This RfQ – cum - RfP document is neither an agreement nor an offer by Department of
Industrial Policy and Promotion, Ministry of Commerce and Industry, Government of
India (hereinafter referred to as DIPP) to the prospective Applicants or any other
person. The purpose of this RfQ – cum - RfP is to provide information to the interested
parties that may be useful to them in the formulation of their proposal pursuant to this
RfQ – cum - RfP.

2.

DIPP does not make any representation or warranty as to the accuracy, reliability or
completeness of the information in this RfQ – cum - RfP document and it is not
possible for DIPP to consider particular needs of each party who reads or uses this
RfQ – cum - RfP document. This RfQ – cum - RfP includes statements which reflect
various assumptions and assessments arrived at by DIPP in relation to the statement
of work. Such assumptions, assessments and statements do not purport to contain all
the information that each Applicant may require. Each prospective Applicant should
conduct its own investigations and analyses and check the accuracy, reliability and
completeness of the information provided in this RfQ – cum - RfP document and
obtain independent advice from appropriate sources.

3.

DIPP will not have any liability to any prospective Applicant/ Firm/ or any other person
under any laws (including without limitation the law of contract, tort), the principles of
equity, restitution or unjust enrichment or otherwise for any loss, expense or damage
which may arise from or be incurred or suffered in connection with anything contained
in this RfQ – cum - RfP document, any matter deemed to form part of this RFQ – cum
- RFP document, the award of the Assignment, the information and any other
information supplied by or on behalf of DIPP or their employees, any Media Agency or
otherwise arising in any way from the selection process for the Assignment. DIPP will
also not be liable in any manner whether resulting from negligence or otherwise
however caused arising from reliance of any Applicant upon any statements contained
in this RfQ – cum - RfP.

4.

DIPP will not be responsible for any delay in receiving the proposals. The issue of this
RfQ – cum - RfP does not imply that DIPP is bound to select an Applicant or to appoint
the Selected Applicant, as the case may be, for the services and DIPP reserves the
right to accept/reject any or all of proposals submitted in response to this RfQ – cum RfP document at any stage without assigning any reasons whatsoever. DIPP also
reserves the right to withhold or withdraw the process at any stage with intimation to
all who submitted the RfQ – cum - RfP Application.

Page 3 of 54

<!-- page 4 -->

5.

The information given is not exhaustive on account of statutory requirements and
should not be regarded as a complete or authoritative statement of law. DIPP accepts
no responsibility for the accuracy or otherwise for any interpretation or opinion on the
law expressed herein.

6.

DIPP reserves the right to change/ modify/ amend any or all provisions of this RfQ–
cum - RfP document. Such revisions to the RfQ – cum - RfP / amended RfQ –cum RfP will be made available on the website of DIPP and CPPP portal.

Page 4 of 54

<!-- page 5 -->

Section 1. Letter of Invitation
New Delhi
Date: 23rd June, 2015
1.

Introduction

Department of Industrial Policy and Promotion (DIPP), Ministry of Commerce and Industry,
Government of India, intends to undertake 360 degree international and national promotion and
Media Campaign across the world to brand India as an investment destination. The objective of
the campaign is to generate awareness about the investment opportunities and prospects of
the country, to promote India as a preferred investment destination in the source markets
overseas and to increase India‘s share of global FDI. For this development of an interactive
portal is also planned to be undertaken.
The endeavour of DIPP is to target the traditional and important source markets overseas from
where the country receives a large number of investment proposals.
DIPP intends to release its campaign in the overseas and domestic market, portraying the
strengths of and opportunities in the Indian economy for investment and highlighting the
comparative advantages India has over other investment destinations.
The detailed scope of services is provided in the Terms of Reference.
2.

Objectives

The Department of Industrial Policy & Promotion, Ministry of Commerce and Industry,
Government of India, following a successful launch of the Make in India initiative and a rapid
buildup of social media followers and widespread public output, will be undertaking 360 degree
international and domestic Media Campaigns under the ‗Make in India‘ brand line.
The primary objective of these campaigns is to reach out to global media, manufacturers,
investors & institution to attract investment, foster innovation and develop skills helping
transform India into a world-class manufacturing hub.
The Key target groups of the initiative are :
1) Global manufacturers and investors – help alleviate concerns regarding red tape,
consistency of policies, lack of skills and infrastructure.
2) Industrialists based in India – help convert them to brand ambassadors for Make in India
and become evangelists for world-class manufacturing in India.
3) Indian Youth – harness their support & energy and turn Make in India into a popular
cultural movement.
3.

The Media Agency will be selected on the Combined Quality cum Cost Based
Selection process with 70 per cent weightage to quality and 30 percent
weightage to cost.

The RFQ – cum - RFP includes the following documents:
SECTION 1: Letter of Invitation
SECTION 2: Instructions to Applicants
Page 5 of 54

<!-- page 6 -->

SECTION 3: Pre – Qualification and Technical Proposal - Standard Forms
SECTION 4: Financial Proposal - Standard forms
SECTION 5: Terms of Reference
SECTION 6: Standard format of Work Order

All clarifications/ corrigenda will be published on the website of DIPP and on Central
Public Procurement (CPP) Portal. The official website for accessing the information
related to this RFQ – cum - RFP is: www.dipp.nic.in (the “Official Website”) along
with Central Public Procurement Portal (eprocure.gov.in/eprocure/app).

Yours sincerely,

Deputy Secretary (BE-III)
DIPP

Page 6 of 54

<!-- page 7 -->

Section 2. Instructions to Applicants
2.1

Introduction

2.1.1 The Client named in the Data Sheet will select an organization in accordance with the
method of selection specified in the Data Sheet. Applicants are advised that the
selection of Media Agency shall be on the basis of an evaluation by Client through the
selection process specified in this RFQ – cum - RFP (the ―
Selection Process‖).
Applicants shall be deemed to have understood and agreed that no explanation or
justification for any aspect of the Selection Process will be given and that Client‘s
decisions are final without any right of appeal whatsoever.
2.1.2 The Applicants are invited to submit Pre-Qualification, Technical and Financial
Proposals (collectively called as ―
the Proposal‖), as specified in the Data Sheet, for the
services required for the Assignment. The Proposal will form the basis for grant of
work order to the selected the Media Agency shall carry out the assignment in
accordance with the Terms of Reference of this RFQ – cum - RFP (the ―
TOR‖).
2.1.3 The Applicant shall submit the Proposal in the form and manner specified in this RFQ
– cum - RFP. The Proposal shall be submitted as per the forms given in relevant
sections herewith.
2.1.4 Applicants shall bear all costs associated with the preparation and submission of their
proposals, and their participation in the Selection process, and presentation including
but not limited to postage, delivery fees, expenses associated with any demonstrations
or presentations which may be required by Client or any other costs incurred in
connection with or relating to its Proposal. The Client is not bound to accept any
Proposal, and reserves the right to annul the selection process at any time prior to
grant of work order, without thereby incurring any liability to the Applicants.
2.1.5 Client requires that the Applicant hold Client‘s interests‘ paramount, avoid conflicts
with other assignments or its own interests, and act without any consideration for
future work. The applicant shall not accept or engage in any assignment that may
place it in a position of not being able to carry out the assignment in the best interests
of Client and the Project.
2.1.6 It is the Client‘s policy to require that the Applicants observe the highest standard of
ethics during the Selection Process and execution of work/assignment. In pursuance
of this policy, the Client:
(i) will reject the Proposal for award if it determines that the Applicant has engaged in
corrupt or fraudulent activities in competing the work order in question;
(ii) will declare an Applicant ineligible, either indefinitely or for a stated period of
time, to be awarded any contract or work order if it at any time determines that
the Applicant has engaged in corrupt or fraudulent practices in competing for
and in executing the work order.
2.1.7 Arbitration: If any dispute or difference of any kind whatsoever arises between the
parties in connection with or arising out of or relating to or under this RFQ – cum RFP, the parties shall promptly and in good faith negotiate with a view to its
amicable resolution and settlement. In the event no amicable resolution or settlement
is reached within a period of thirty (30) days from the date on which the abovementioned dispute or difference arose, such dispute or difference shall be finally
settled by Secretary, DIPP, whose decision shall be final.
2.1.8 Termination of Assignment: Client will have the right to terminate the assignment by
Page 7 of 54

<!-- page 8 -->

giving 30 (thirty) days written notice. In the event of termination for no fault of
Applicant, the Client will reimburse all the expenses incurred by the Applicant (upon
submission of proof) including closing-up of the project. If the assignment is terminated
due to the fault of the Applicant or in case of termination of the assignment by the
Applicant for reasons not attributable to the Client, the Client will forfeit the
performance security of the Applicant.
2.1.9 The Applicant shall submit his proposal in four covers containing details of EMD, PreQualification Proposal, Technical Proposal and Financial Proposal respectively
on Central Public Procurement Portal (http://eprocure.gov.in/eprocure/app). The
submissions for Pre-Qualification shall be evaluated first as specified in this RFQ-cumRFP. Subsequently the technical evaluation as specified in this RFQ-cum-RFP will be
carried out only for those Applicants who meet the Pre- Qualification criteria. Based on
this technical evaluation, a list of technically qualified Applicants shall be prepared in
the order of their merit.
2.1.10 The evaluation will be done in accordance with procedure given in Clause 2.6
2.1.11 Number of Proposals: No Applicant shall submit more than one Application.
2.1.12 Right to reject any or all Proposals:
(i) Notwithstanding anything contained in this RFQ – cum - RFP, the Client
reserves the right to accept or reject any Proposal and to annul the Selection
Process and reject all Proposals, at any time without any liability or any
obligation for such acceptance, rejection or annulment, and without assigning
any reasons thereof.
(ii) Without prejudice to the generality of above, the Client reserves the right to
reject any Proposal if:
a) at any time, a material misrepresentation is made or discovered, or
b) the Applicant does not provide, within the time specified by the Client, the
supplemental information sought by the Client for evaluation of the Proposal.
(iii) Such misrepresentation/ improper response by the Applicant may lead to the
disqualification of the Applicant. If such disqualification/ rejection occurs after the
Proposals have been opened and the highest ranking Applicant gets
disqualified/ rejected, then the Client reserves the right to consider the next best
Applicant, or take any other measure as may be deemed fit in the sole discretion
of the Client, including annulment of the Selection Process.
2.1.13 Acknowledgement by Applicant
(i) It shall be deemed that by submitting the Proposal, the Applicant has:
a) made a complete and careful examination of the RFQ – cum - RFP;
b) received all relevant information requested from the Client;
c) accepted the risk of inadequacy, error or mistake in the information provided
in the RFQ – cum - RFP or furnished by or on behalf of the Client;
d) satisfied itself about all matters, things and information, including matters
herein above, necessary and required for submitting an informed Application
and performance of all of its obligations there under;
e) acknowledged that it does not have a Conflict of Interest; and
f) agreed to be bound by the undertaking provided by it under and in term hereof.
(ii) The Client and/ or its advisors/ consultants shall not be liable for any omission,
mistake or error on the part of the Applicant in respect of any of the above or on
account of any matter or thing arising out of or concerning or relating to RFQ –
cum- RFP or the Selection Process, including any error or mistake therein or in
any information or data given by the Client and/ or its consultant.

Page 8 of 54

<!-- page 9 -->

2.1.14
2.2

The proposal of the applicant shall be valid for 60 (sixty) days from the proposal
due date.
Clarification and amendment of RFQ – cum - RFP documents
Applicants may seek clarification on this RFQ – cum - RFP document, within four (4)
days of the date of issue of this RFQ – cum - RFP document. Any request for
clarification must be sent by standard electronic means (PDF and word file)/ fax to the
Client‘s office addressed to:
Deputy Secretary (BE-III),
Department of Industrial Policy and Promotion
Ministry of Commerce & Industry, Government of India
Udyog Bhawan
New Delhi-110011
Email:sahni.palka@nic.in
The Client will endeavour to respond to the queries prior to the Proposal Due Date.
The Client will post the reply to all such queries on its official website and CPPP portal.

2.2.1 At any time before the submission of Proposals, the Client may, for any reason,
whether at its own initiative or in response to a clarification requested by a prospective
Applicant, modify the RFQ – cum - RFP documents by an amendment. All
amendments/ corrigenda will be posted on the Client‘s Official Website and on Central
Public Procurement Portal. In order to afford the Applicants a reasonable time for
taking an amendment into account, or for any other reason, the Client may at its
discretion extend the Proposal Due Date.
2.2.2 Date of Pre-Bid Meeting and venue is mentioned in Data Sheet. Applicants willing to
attend the pre-bid should inform client beforehand in writing and email. The maximum
no. of participants from an applicant, who chose to attend the Pre-Bid Meeting, shall
not be more than two per applicant. The representatives attending the Pre-Bid Meeting
shall accompany with an authority letter duly signed by the authorized signatory of
his/her organization (In Form 3E).
2.3

Earnest Money Deposit

2.3.1 A Earnest Money Deposit in the form of a Demand Draft/ Bank Guarantee, from a
scheduled Indian Bank in favour of Pay and Account Officer, DIPP, New Delhi‘,
payable at New Delhi, for the sum of Rs 10,00,000/- (Rupees Ten Lakhs Only) shall
be required to be submitted by each Applicant. The Bank Guarantee shall be in the
format of Form 3F.
2.3.2 The Demand Draft/ Bank Guarantee in original shall be placed in an envelope and
marked as ―
EMD– [name of assignment]‖ and ―
Not to be opened except in the
presence of evaluation committee‖. In addition, a scanned copy (in pdf format) shall
also be uploaded on Central Public Procurement Portal (hereinafter referred to as
CPPP). Bids received without the specified Earnest Money Deposit Bid Security will be
summarily rejected.
2.3.3 Client will not be liable to pay any interest on Earnest Money Deposit. Bid security of
Pre-Qualified but unsuccessful Applicants shall be returned, without any interest, within
one month after grant of the work order to the Selected Applicant or when the selection
process is cancelled by Client. The Selected Applicant‘s Earnest Money shall be
returned, without any interest upon the Applicant accepting the work order and
furnishing the Performance Security in accordance with provision of the RFQ – cum RFP and work order.
Page 9 of 54

<!-- page 10 -->

2.3.4 Client will be entitled to forfeit and appropriate the Earnest Money Deposit as mutually
agreed loss and damage payable to Client in regard to the RFQ – cum - RFP without
prejudice to Client‘s any other right or remedy under the following conditions:
(i) If an Applicant engages in a corrupt practice, fraudulent practice, coercive
practice, undesirable practice or restrictive practice as envisaged under this RFQ
– cum - RFP (including the Standard Form of work order);
(ii) If any Applicant withdraws its Proposal during the period of its validity as specified
in this RFQ – cum - RFP and as extended by the Applicant from time to time,
(iii) In the case of the Selected Applicant, if the Selected Applicant fails to accept the
work order or provide the Performance Security within the specified time limit, or
(iv) If the Applicant commits any breach of terms of this RFQ – cum - RFP or is found
to have made a false representation to Client.
Performance Security equivalent to the amount indicated in this RFQ – cum - RFP
shall be furnished before start of work on assignment in form of a Bank Guarantee
substantially in the form specified in the RFQ – cum - RFP / work order.
For the successful bidder the Performance Security shall be retained by Client until the
completion of the assignment by the Applicant and be released 60 (Sixty) days after
the completion of the assignment.
2.3.5 Any entity which has been barred by the Central Government, any State Government,
a statutory authority or a public sector undertaking, as the case may be, from
participating in any project and the bar subsists as on the date of the Proposal Due
Date, would not be eligible to submit a Proposal.
2.3.6 An Applicant should have, during the last 3 (three) years, neither failed to perform on
any agreement, as evidenced by imposition of a penalty by an arbitral or judicial
authority or a judicial pronouncement or arbitration award against the Applicant or its
Associate, nor been expelled from any project or agreement nor have had any
agreement terminated for breach by such Applicant or its Associate.
2.4

Preparation of proposal

2.4.1 Applicants are requested to submit their Proposal in English language and strictly in
the formats provided in this RFQ – cum - RFP. The Client will evaluate only those
Proposals that are received in the specified forms and complete in all respects.
2.4.2 In preparing their Proposal, Applicants are expected to thoroughly examine the RFQ
cum - RFP Document.
2.4.3 The technical proposal should provide the documents as prescribed in clause 2.6.
along with photocopy of PAN Card and latest income-tax return. No information
related to financial proposal should be provided in the technical proposal.
2.4.4 Failure to comply with the requirements spelt out above shall lead to the deduction of
marks during the evaluation. Further, in such a case, Client will be entitled to reject the
Proposal. However, if any information related to financial proposal is included in the
technical proposal the applicant shall be disqualified and his proposal will not be
considered.
2.4.5 The Proposals must be digitally signed by the Authorized Representative (the
―
Authorized Representative‖) as detailed below:
(i) by the proprietor in case of a proprietary firm;
(ii) by a partner, in case of a partnership firm and/or a limited liability partnership; or
(iii) by a duly authorized person holding the Power of Attorney, in case of a Limited
Page 10 of 54

<!-- page 11 -->

Company or a corporation; or
2.4.6 Applicants should note the Proposal Due Date, as specified in Data Sheet, for
submission of Proposals. Except as specifically provided in this RFQ – cum - RFP, no
supplementary material will be entertained by the Client, and the evaluation will be
carried out only on the basis of Documents received by the closing time of Proposal
Due Date as specified in Data Sheet. Applicants will ordinarily not be asked to provide
additional material information or documents subsequent to the date of submission,
and unsolicited material if submitted will be summarily rejected. For the avoidance of
doubt, the Client reserves the right to seek clarifications in case the proposal is nonresponsive on any aspects.
2.4.7 Financial proposal: While preparing the Financial Proposal, Applicants are expected
to take into account the various requirements and conditions stipulated in this RFQ –
cum - RFP document. The Financial Proposal should be a lump sum Proposal
inclusive of all the costs including but not limited to all taxes associated with the
Assignment. While submitting the Financial Proposal, the Applicant shall ensure the
following:
(i) All the costs associated with the Assignment shall be included in the Financial
Proposal including unit costs wherever indicated in scope of works mentioned
under Section 5, Terms of Reference. The total amount indicated in the Financial
Proposal shall be without any condition attached or subject to any assumption,
and shall be final and binding. In case any assumption or condition is indicated in
the Financial Proposal, it shall be considered non-responsive and liable to be
rejected.
(ii) The Financial Proposal shall take into account all the expenses and tax liabilities
and cost of insurance specified in the work order, levies and other impositions
applicable under the prevailing law. For the avoidance of doubt, it is clarified that
all taxes, excluding service tax, shall be deemed to be included in the cost
shown under different items of Financial Proposal. The Applicant shall be paid
only service tax over and above the cost of Financial Proposal. Further, all
payments shall be subjected to deduction of taxes at source as per Applicable
Laws.
2.4.8 The proposal should be submitted as per the standard Financial Proposal submission
forms prescribed in this RFQ – cum - RFP.
2.4.9 Applicants shall express the price of their services in Indian Rupees only.
2.5

Submission, receipt and opening of proposals

2.5.1

The Proposal shall be submitted through e-procurement portal CPPP. The procedure
for filing of e-tender is provided on the portal. Files uploaded on the portal should have
file name in accordance to following format [form_name.applicant_name]. Applicant
name should contain only first two words of its name.

2.5.2

The Authorized Representative of the Applicant should authenticate EMD Details, PreQualification, Technical and Financial proposal using his digital signatures. The
Authorized Representative‘s authorization should be confirmed by a written power of
attorney by the competent authority accompanying the Proposal (Pre-Qualification
Proposal).

2.5.3

The Applicant shall submit his proposal in four covers containing details of EMD,
Pre-Qualification Proposal, Technical Proposal and Financial Proposal
respectively.

2.5.4

No proposal shall be accepted after the closing time for submission of Proposals.
Page 11 of 54

<!-- page 12 -->

2.5.5

After the deadline for submission of proposals the Earnest Money Deposit detail and
Pre-Qualification Proposal shall be opened by the Evaluation Committee to evaluate
whether the Applicants meet the prescribed Minimum Qualification Criteria. The RFP
details containing the Technical and Financial Proposals shall remain closed.

2.5.6

After the Proposal submission until the grant of the work order, if any Applicant wishes
to contact the Client on any matter related to its proposal, it should do so in writing at
the Proposal submission address. Any effort by the firm to influence the Client during
the Proposal evaluation, Proposal comparison or grant of the work order decisions
may result in the rejection of the applicant‘s proposal.

2.6

Proposal Evaluation

2.6.1

As part of the evaluation, the Pre-Qualification Proposal submission shall be checked
to evaluate whether the Applicant meets the prescribed Minimum Qualification Criteria.
Subsequently the Technical Proposal submission, for Applicants who meet the
Minimum Qualification Criteria (―
Shortlisted Applicant‖), shall be checked for
responsiveness in accordance with the requirements of the RFQ-cum-RFP and only
those Technical Proposals which are found to be responsive would be further
evaluated in accordance with the criteria set out in this RFQ-cum-RFP document.

2.6.2

Prior to evaluation of Proposals, the Client will determine whether each Proposal is
responsive to the requirements of the RFQ – cum – RFP at each evaluation stage as
indicated below. The Client may, in its sole discretion, reject any Proposal that is not
responsive hereunder. A Proposal will be considered responsive at each stage only if:

RFQ Stage
(i)

The Pre-Qualification Proposal is received in the form specified in this RFQ cum- RFP;

(ii)

it is received by the Proposed Due Date including any extension thereof in terms
hereof;

(iii)

it does not contain any condition or qualification; and

(iv)

it is not non-responsive in terms hereof.

(v)

it is accompanied by the Earnest Money Deposit as specified in this RfQ-cum-RfP.

RFP Stage
Technical Proposal
(i)

the Technical Proposal is received in the form specified in this RFQ-cum-RFP;

(ii)

it is received by the Proposed Due Date including any extension thereof in terms
hereof;

(iii)

it does not contain any condition or qualification; and

(iv)

it is not non-responsive in terms hereof.

Financial Proposal
(i)

The Financial Proposal is received in the form specified in this RFQ cum RFP;

(ii)

it is received by the Proposed Due Date including any extension thereof in terms
Page 12 of 54

<!-- page 13 -->

hereof;
(iii)

it does not contain any condition or qualification; and

(iv)

It is not non-responsive in terms hereof.
The Client reserves the right to reject any Proposal which is non-responsive and no
request for alteration, modification, substitution or withdrawal will be entertained by the
Client in respect of such Proposals. However, client reserves the right to seek
clarifications or additional information from the applicant during the evaluation process.
The Client will subsequently examine and evaluate Proposals in accordance with the
Selection Process detailed out below.

2.6.3

As part of the evaluation, the Pre-Qualification Proposals submitted [in Form 3A]
should fulfill the Minimum Qualification Criteria. In case an Applicant does not fulfill the
Minimum Qualification Criteria, the Technical Proposal [in Form 3G] of such an
Applicant will not be opened and evaluated further. In such cases, the RFP details
containing the Technical Proposal and Financial Proposal will not be opened after
completion of evaluation of Pre-Qualification.

2.6.4 Minimum Qualification Criteria
S No
1.
2.

3.

4.

Minimum qualification criteria
The Media Agency must have been in operation for a
minimum of 3 years, as on 31st March, 2015, in Media &
Marketing Services (supporting documents to be attached)
The Media Agency must have a cumulative gross revenue
from media work of Rs 100 crore and above in the last three
financial years (2012-13, 2013-14, 2014-15). A certificate
from Chartered Accountant must be submitted
The Media Agency should have handled international duties
of over Rs. 5 crores, in the last 12 months and handled at
least one account in any sector, with gross revenue of over
Rs. 2 crore in any one of the last three years. (A certificate
from Chartered Accountant must be submitted)
The Media Agency should have separate, specialized team
setups & structures for Media Planning & Buying, Activation,
Analytics, Digital – with a separate setup for Social Media,
Search, & Online Relationship Management

Form
Form 3 B
Form 3C

Form 3C

Form 3D

2.6.5 Technical Evaluation: The evaluation committee (―
Evaluation Committee‖) appointed
by the Client will carry out the evaluation of Proposals on the basis of the following
evaluation criteria and points system. If required, the Client may seek specific
clarifications from any or all Agency(ies) at this stage. The Client shall determine the
Agency that qualifies for the next phase after reviewing the clarifications provided by
the Agency(ies). Each evaluated Proposal will be given a technical score (St) as
detailed below. The maximum points/ marks to be given under each of the evaluation
criteria are:

Page 13 of 54

<!-- page 14 -->

S No
1.
2.

3.

4.
5.
6.
7.

Evaluation Criteria
Strategy in line with the proposed Brand Vision
presented for DIPP, including innovative ideas &
suggestions.
Profile & Track record of the agency, including
experience in the fields related to Print, Outdoor,
Electronic Media, Activation, Analytics & Digital Media
with separate emphasis on Social Media amplification reference client work
International clients handled along with the size of
accounts handled on Print, Outdoor, Electronic Media,
Activation, Analytics & Digital Media including social
media amplification.
Credentials of Media & Marketing team identified to
work with DIPP.
Identification of Key Success Metrics, Design &
Concept of evaluation, tracking & course correction
plan for KPIs with specific timelines & tools deployed.
Design & Concept of ORM plan with specific input
parameters & tool deployment.
Total

Points
20

Form
3H

20

3I

20

3J

15

3K

15

3L

10

3M

100

The minimum technical score required to qualify technical evaluation is 60 points out of
100. A proposal will be considered unsuitable and will be rejected at this stage if it does
not respond to important aspects of RFQ – cum - RFP Document and the Terms of
Reference or if it fails to achieve the minimum technical score. The Client will notify
Applicants who fail to score the minimum technical score about the same and return
their Financial Proposals will remain unopened.
2.6.6 The proposal of the Agency who have cleared the minimum qualification score shall be
ranked on the basis of technical score (St) and their financial proposal will be opened.
2.6.7 Financial Evaluation: In this process, the financial proposal of the Agency declared
qualified shall be opened by indicating the date and time set for opening of its Financial
Proposal. The information of this date and time may be sent by registered letter,
facsimile, or electronic mail.
2.6.8

Selection Procedure
The cost indicated in the Financial Proposal shall be deemed as final and reflecting
the total cost of services and should be stated in INR only. Omissions, if any, in
costing of any item shall not entitle the Applicant to be compensated and the liability
to fulfill its obligations as per the Terms of Reference within the total quoted price
shall be that of the Applicant. The evaluation shall exclude those taxes, duties, fees,
levies and other charges imposed under the Applicable Law as applicable on foreign
and domestic inputs. The lowest Financial Proposal (Fm) will be given a financial
score (Sf) of 100 points. The financial scores (Sf) of the other Financial Proposals
will be determined using the following formula:
Sf = 100 x Fm/F;
in which Sf is the financial score, Fm is the lowest Financial Proposal, and F is the
Financial Proposal (in INR) under consideration.
Proposals will be finally be ranked in accordance with their combined technical (St)
Page 14 of 54

<!-- page 15 -->

and financial (Sf) scores:
S = St x Tw + Sf x Fw;
where S is the combined score, and Tw and Fw are weights assigned to Technical
Proposal and Financial Proposal that will be 0.70:0.30.
2.6.9

The Applicant achieving the highest combined technical and financial score will be
considered to be the successful Applicant and will be issued the work order (the
―
Successful Applicant‖)

2.7

Grant of Work Order

2.7.1

After selection, a Work Order will be issued, in duplicate, by the Client to the Successful
Applicant and the Successful Applicant shall, within 3 (three) days of the receipt of the
work order, sign and return the duplicate copy of the work order in acknowledgement
thereof. In the event the duplicate copy of the work order duly signed by the Successful
Applicant is not received by the stipulated date, the Client may, unless it consents to
extension of time for submission thereof, appropriate the Earnest Money Deposit of
such Applicant as mutually agreed genuine pre-estimated loss and damage suffered by
the Client on account of failure of the Successful Applicant to acknowledge the work
order, and the next highest ranking Applicant may be considered.

2.7.2

The Successful Applicant would have to provide a Quarterly Work Plan for the first year
to the DIPP, within 7 days after receipt of the Work Order.

2.7.3

Performance Security: Performance Security equivalent to 15 (fifteen) percent of the
total cost of Financial Proposal shall be furnished from a Nationalized/Scheduled Bank,
before start of work on assignment, in form of a Bank Guarantee substantially in the
form specified at Annexure of the work order. For the successful bidder the
Performance Security will be retained by Client until the completion of the assignment
by the Applicant and be released 60 (Sixty) Days after the completion of the
assignment.

2.8

Confidentiality
Information relating to evaluation of proposals and recommendations concerning grant
of the work order shall not be disclosed to the applicants who submitted the proposals
or to other persons not officially concerned with the process, until the winning firm has
been notified that it has been given the work order.

2.9

Fraud and corrupt practices

2.9.1

The Applicants and their respective officers, employees, agents and advisers shall
observe the highest standard of ethics during the Selection Process. Notwithstanding
anything to the contrary contained in this RFQ – cum - RFP, the Client will reject a
Proposal without being liable in any manner whatsoever to the Applicant, if it
determines that the Applicant has, directly or indirectly or through an agent, engaged in
corrupt practice, fraudulent practice, coercive practice, undesirable practice or
restrictive practice (collectively the ―
Prohibited Practices‖) in the Selection Process. In
such an event, the Client will, without prejudice to its any other rights or remedies,
forfeit and appropriate the Earnest Money Deposit, as mutually agreed genuine preestimated compensation and damages payable to the Client for, inter alia, time, cost
and effort of the Client, in regard to the RFQ – cum - RFP, including consideration and
evaluation of such Applicant‘s Proposal.

Page 15 of 54

<!-- page 16 -->

2.9.2

Without prejudice to the rights of the Client under this Clause, hereinabove and the
rights and remedies which the Client may have under the work order or the Agreement,
if an Applicant or Media Agency, as the case may be, is found by the Client to have
directly or indirectly or through an agent, engaged or indulged in any corrupt practice,
fraudulent practice, coercive practice, undesirable practice or restrictive practice during
the Selection Process, or after the issue of the work order or the execution of the
Agreement, such Applicant or Media Agency shall not be eligible to participate in any
tender or RFQ – cum - RFP issued by the Client during a period of 2 (two) years from
the date such Applicant or Media Agency, as the case may be, is found by the Client to
have directly or through an agent, engaged or indulged in any corrupt practice,
fraudulent practice, coercive practice, undesirable practice or restrictive practice, as the
case may be.

2.9.3

For the purposes of this Clause, the following terms shall have the meaning hereinafter
respectively assigned to them:

2.9.3.1 ―
corrupt practice‖ means (i) the offering, giving, receiving, or soliciting, directly or
indirectly, of anything of value to influence the action of any person connected with the
Selection Process (for avoidance of doubt, offering of employment to or employing or
engaging in any manner whatsoever, directly or indirectly, any official of the Client who
is or has been associated in any manner, directly or indirectly with the Selection
Process or the work order or has dealt with matters concerning the Agreement or
arising there from, before or after the execution thereof, at any time prior to the expiry
of one year from the date such official resigns or retires from or otherwise ceases to be
in the service of the Client, shall be deemed to constitute influencing the actions of a
person connected with the Selection Process; or (ii) save as provided herein, engaging
in any manner whatsoever, whether during the Selection Process or after the issue of
the work order or after the execution of the Agreement, as the case may be, any person
in respect of any matter relating to the
Project or the work order or the Agreement, who at any time has been or is a legal,
financial or technical consultant/ adviser of the Client in relation to any matter
concerning the Project;
a)
―
fraudulent practice‖ means a misrepresentation or omission of facts or
disclosure of incomplete facts, in order to influence the Selection Process;
b)
―
coercive practice‖ means impairing or harming or threatening to impair or
harm, directly or indirectly, any persons or property to influence any person‘s
participation or action in the Selection Process;
c)
―u
ndesirable practice‖ means (i) establishing contact with any person connected
with or employed or engaged by the Client with the objective of canvassing,
lobbying or in any manner influencing or attempting to influence the Selection
Process; or (ii) having a Conflict of Interest; and
d)
―re
strictive practice‖ means forming a cartel or arriving at any understanding or
arrangement among Applicants with the objective of restricting or manipulating
a full and fair competition in the Selection Process.
2.10

Pre-Bid Meeting

2.10.1 Pre-Bid Meeting of the Applicants will be convened off-line at the designated date, time
and place. A maximum of two representatives of each Applicant will be allowed to
participate on production of an authorization letter from the Applicant [In Form 3D].
2.10.2 During the course of Pre-Bid Meeting, the Applicants will be free to seek clarifications
and make suggestions for consideration of the Client. The Client will endeavour to
provide clarifications and such further information as it may, in its sole discretion,
Page 16 of 54

<!-- page 17 -->

consider appropriate for facilitating a fair, transparent and competitive selection
process.
2.11

Miscellaneous

2.11.1 The Selection Process shall be governed by, and construed in accordance with, the
laws of India and the Courts at New Delhi shall have exclusive jurisdiction over all
disputes arising under, pursuant to and/or in connection with the Selection Process.
2.11.2 The Client, in its sole discretion and without incurring any obligation or liability, reserves
the right, at any time, to:
2.11.2.1
2.11.2.2
2.11.2.3
2.11.2.4

suspend and/or cancel the Selection Process and/or amend and/or
supplement the Selection Process or modify the dates or other terms and
conditions relating thereto;
consult with any Applicant in order to receive clarification or further
information;
retain any information and/or evidence submitted to the Client by, on behalf
of and/or in relation to any Applicant; and/or
Independently verify, disqualify, reject and/or accept any and all
submissions or other information and/or evidence submitted by or on behalf
of any Applicant.

2.11.3 It shall be deemed that by submitting the Proposal, the Applicant agrees and releases
the Client, its employees, agents and advisers, irrevocably, unconditionally, fully and
finally from any and all liability for claims, losses, damages, costs, expenses or
liabilities in any way related to or arising from the exercise of any rights and/or
performance of any obligations hereunder, pursuant hereto and/or in connection
herewith and waives any and all rights and/ or claims it may have in this respect,
whether actual or contingent, whether present or future.
2.11.4 All documents and other information provided by Client or submitted by an Applicant to
Client shall remain or become the property of Client. Applicants and the Media Agency,
as the case may be, are to treat all information as strictly confidential. Client will not
return any Proposal or any information related thereto. All information collected,
analyzed, processed or in whatever manner provided by the Applicant to Client in
relation to the assignment shall be the property of Client.
2.11.5 The Client reserves the right to make inquiries with any of the clients listed by the
Applicants in their previous experience record.
2.12

Tentative schedule for selection process

The Client will endeavour to follow the following schedule:
Date of issue of RFQ – cum – RFP
Last date for receiving queries/requests for clarifications
Pre-Bid Meeting

June 23rd, 2015
June 29th, 2015
July 2nd, 2015

Client‘s response to queries/requests for clarifications
Proposal Due Date
Opening of Pre-Qualification Proposals (after the bid
submission time i.e. 3:00PM)

July 3rd, 2015
July 13th, 2015
July 13th, 2015

Presentation by the Technically Qualified Applicants

To be notified

Page 17 of 54

<!-- page 18 -->

2.13

Data Sheet
Reference
Section 1,
Point 2

Description
The objective of the campaign is to generate awareness about the
investment opportunities and prospects of the country, to promote India
as a preferred investment destination in the source markets overseas
and to increase India‘s share of global FDI.

Section 1,
Point 3

The method of selection is Combined Quality cum Cost Based Selection
criteria using 70:30 weightage for quality and cost respectively.

2.1.1

The name of Client is: ―
Department of Industrial Policy and Promotion,
Ministry of Commerce and Industry, Government of India‖
The proposal of the applicant shall be valid for 60 (sixty) days from the
Proposal Due Date.
Clarification must be requested on or before June 29th , 2015.
Applicants shall share the MS Word file in soft copy of pre-bid queries at
the time of
requesting clarifications. The address for requesting clarification is:

2.2

Deputy Secretary (BE-III),
DIPP
Udyog Bhawan,
New Delhi-110011
2.2.2

Date & Time of pre bid meeting – July 2nd , 2015 at 11.00 am, at the
Official Address:
Committee Room (Room No. 152), DIPP, Udyog Bhawan, New
Delhi-110011

2.4.9

The applicant to state cost in Indian Rupees only.

2.5.3

Applicants must submit:
 Pre-Qualification Proposal
 Technical proposal
 Financial proposal

2.5.4

The last date of submission of Proposal is July 13th , 2015 before
3:00 pm (IST). The proposal will be submitted on CPPP. The address for
submission of EMD/Bank Guarantee is,
Deputy Secretary (BE-III),
DIPP
Udyog Bhawan,
New Delhi-110011

New Delhi-110011
Page 18 of 54

<!-- page 19 -->

Section 3. Pre-Qualification and Technical Proposal – Standard Forms
Form 3A:

Pre – Qualification Proposal Submission Form

Form 3B

Self-certification of Operation for minimum 3 years

Form 3C

Format for Pre-Qualification Proposal (Cumulative Turnover of
Applicant and one account handled)

Form 3D

Format for having separate, specialized team setups & structures

Form 3E:

Format for Power of Attorney for Authorized representative

Form 3F:

Format of Bank Guarantee for Earnest Money Deposit

Form 3G:

Technical Proposal Submission

Form 3H

Format for strategy in line with the proposed Brand Vision presented for
DIPP, including innovative ideas & suggestions.

Form 3I

Format for Profile & Track record of the agency

Form 3J

Details of International clients handled

Form 3K

Details of Credentials of Media & Marketing team identified to work with
DIPP

Form 3L

Details of Identification of key success metrics, Design & Concept of
evaluation, etc.

Form 3M

Details of Design & Concept of Online Reputation
Management (ORM) Plan

Page 19 of 54

<!-- page 20 -->

Form 3A: Pre-Qualification Proposal Submission Form
[Location, Date]
To
Deputy Secretary (BE-III),
DIPP
Udyog Bhawan,
New Delhi-110001
RFQ – cum - RFP dated [date] for selection of Media Agency for [name of
assignment]
Dear Madam,
With reference to your RFQ – cum - RFP Document dated [date], we, having examined
all relevant documents and understood their contents, hereby submit our PreQualification Proposal for selection as [name of assignment]. The Proposal is
unconditional and unqualified.
We are submitting our Proposal as [name of the Applicant].
We understand you are not bound to accept any Proposal you receive.
Further:
1.

We acknowledge that Client will be relying on the information provided in the
Proposal and the documents accompanying the Proposal for selection of the
Media Agency, and we certify that all information provided in the Proposal and
in the supporting documents is true and correct, nothing has been omitted
which renders such information misleading; and all documents accompanying
such Proposal are true copies of their respective originals.

2.

This statement is made for the express purpose of appointment as the Media
Agency for the aforesaid Project.

3.

We shall make available to Client any additional information it may deem
necessary or require for supplementing or authenticating the Proposal.

4.

We acknowledge the right of Client to reject our application without assigning
any reason or otherwise and hereby waive our right to challenge the same on
any account whatsoever.

5.

We certify that in the last 3 (three) years, we have neither failed to perform on
any assignment or contract, as evidenced by imposition of a penalty by an
arbitral or judicial authority or a judicial pronouncement or arbitration award
against the Applicant, nor been expelled from any project, assignment or
contract by any public authority nor have had any assignment or contract
terminated by any public authority for breach on our part.

6.

We declare that:
a) We have examined and have no reservations to the RFQ – cum - RFP,
including any Addendum issued by the Authority;
b) We do not have any conflict of interest in accordance with the terms of the
RFQ – cum - RFP;
Page 20 of 54

<!-- page 21 -->

c) We have not directly or indirectly or through an agent engaged or indulged
in any corrupt practice, fraudulent practice, coercive practice, undesirable
practice or restrictive practice, as defined in the RFQ – cum - RFP
document, in respect of any tender or request for proposal issued by or any
agreement entered into with Client or any other public sector enterprise or
any government, Central or State; and
d) We hereby certify that we have taken steps to ensure that no person acting
for us or on our behalf will engage in any corrupt practice, fraudulent
practice, coercive practice, undesirable practice or restrictive practice.
7.

We understand that you may cancel the selection process at any time and that
you are neither bound to accept any Proposal that you may receive nor to
select the Media Agency, without incurring any liability to the Applicants.

8.

We declare that we are not a member of any other Consortium/JV applying for
selection as a Media Agency.

9.

We certify that in regard to matters other than security and integrity of the
country, we or any of our affiliates have not been convicted by a court of law or
indicted or adverse orders passed by a regulatory authority which would cast a
doubt on our ability to undertake the Project or which relates to a grave offence
that outrages the moral sense of the community.

10.

We further certify that in regard to matters relating to security and integrity of
the country, we have not been charge-sheeted by any agency of the
Government or convicted by a court of law for any offence committed by us or
by any of our affiliates. We further certify that neither we nor any of our
consortium members have been barred by the central government, any state
government, a statutory body or any public sector undertaking, as the case may
be, from participating in any project or bid, and that any such bar, if any, does
not subsist as on the date of this RFQ – cum - RFP.

11.

We further certify that no investigation by a regulatory authority is pending
either against us or against our affiliates or against our CEO or any of our
Managers/ employees.

12.

We hereby irrevocably waive any right or remedy which we may have at any
stage at law or howsoever otherwise arising to challenge or question any
decision taken by Client in connection with the selection of Media Agency or in
connection with the selection process itself in respect of the above mentioned
Project.

13.

We agree and understand that the proposal is subject to the provisions of the
RFQ – cum - RFP document. In no case, shall we have any claim or right of
whatsoever nature if the Project is not awarded to us or our proposal is not
opened or rejected.

14.

We agree to keep this offer valid for 60 (sixty) days from the PDD specified in
the RFQ – cum - RFP.

15.

A Power of Attorney in favour of the authorized signatory to sign and submit this
Proposal and documents is attached herewith.

16.

The Technical and Financial Proposal is being submitted in a separate cover.
This Pre- Qualification Proposal read with the Technical and Financial Proposal
shall constitute the application which shall be binding on us.
Page 21 of 54

<!-- page 22 -->

17.

We agree and undertake to abide by all the terms and conditions of the RFQ –
cum - RFP Document.

We remain,

Yours sincerely,
Authorized Signature [In full and
initials]: Name and Title of Signatory:
Name of Firm:
Address:
Telephone:
Fax:
(Name and seal of the Applicant/Member in Charge)

Page 22 of 54

<!-- page 23 -->

Form 3B: Self-certification of Operating for minimum 3 years
[Location, Date]

Here give a certificate that the Media Agency have been in operation for a minimum of 3
years as on 31st March, 2015 in providing Media & Marketing Services.

Page 23 of 54

<!-- page 24 -->

Form 3C: Format for Pre-Qualification Proposal {should have cumulative gross revenue
from media work of Rs 100 crore and above in the last three financial years (2012-13,
2013-14, 2014-15)}
SN

Financial years

Revenue

1.
2.
3.

2012-13
2013-14
2014-15
Cumulative Gross Revenue

from

Media(INR)

Certificate from the Statutory Auditor
This is to certify that [name of company] [registered address] has received the
payments shown above against the respective years.
It is also certified that [name of the company] has handled Media assignment of
1.

International duties worth Rs…………………. During the last 12 months

2.

[name of the client] with gross revenue of Rs……..….. in the year …………

Name of Authorized
Signatory Designation
Name of firm
Signature of Authorized
Signatory Seal of Audit firm

Note:
1. In case the Applicant does not have a statutory auditor, it may provide the certificate
from its Chartered Accountant.

Page 24 of 54

<!-- page 25 -->

Form 3D: Format for having separate, specialized team setups & structures for Media
planning & buying, activation, analytics, digital

Here give details of having separate, specialized team setups & structures for
Media Planning & Buying, Activation, Analytics, Digital – with a separate setup for
Social Media, Search, & Online Relationship Management

Page 25 of 54

<!-- page 26 -->

Form 3E: Format for Power of Attorney for Authorized Representative
Know all men by these presents, We, [name of organization and address of the
registered office] do hereby constitute, nominate, appoint and authorize Mr / Ms [name],
son/ daughter/ wife of [name], and presently residing at [address], who is presently
employed with/ retained by us and holding the position of [designation] as our true and
lawful attorney (hereinafter referred to as the ―
Authorized Representative‖), with power
to sub- delegate to any person, to do in our name and on our behalf, all such acts,
deeds and things as are necessary or required in connection with or incidental to
submission of our Proposal for and selection as Media Agency for [name of
assignment], to be developed by DIPP (the ―
Authority‖) including but not limited to
signing and submission of all applications, proposals and other documents and writings,
participating in pre-bid and other conferences and providing information/ responses to
the Authority, representing us in all matters before the Authority and undertakings
consequent to acceptance of our proposal and generally dealing with the Authority in all
matters in connection with or relating to or arising out of our Proposal for the said
Project and/or upon award thereof to us until accepting the work order with the
Authority.
AND, we do hereby agree to ratify and confirm all acts, deeds and things lawfully done
or caused to be done by our said Authorized Representative pursuant to and in exercise
of the powers conferred by this Power of Attorney and that all acts, deeds and things
done by our said Authorized Representative in exercise of the powers hereby conferred
shall and shall always be deemed to have been done by us.
IN WITNESS WHEREOF WE, [name of organization], THE ABOVE NAMED PRINCIPAL
HAVE EXECUTED THIS POWER OF ATTORNEY ON THIS [date in words] DAY OF
[month]
[year in ‗yyyy‘ format].

For [name and registered address of organization] [Signature]
[Name]
[Designation]
Witnesses:
1.

[Signature, name and address of witness]

2.

[Signature, name and address of Witness]

Accepted
Signature] [Name]
[Designation] [Address]
Notes:
1.

The mode of execution of the Power of Attorney should be in accordance with
the procedure, if any, laid down by the applicable law and the charter
documents of the

Page 26 of 54

<!-- page 27 -->

2.

3.

executant(s) and when it is so required the same should be under seal affixed in
accordance with the required procedure.
Wherever required, the Applicant should submit for verification the extract of the
charter documents and other documents such as a resolution/power of attorney
in favour of the person executing this Power of Attorney for the delegation of
power hereunder on behalf of the Applicant.
For a Power of Attorney executed and issued overseas, the document will also
have to be legalized by the Indian Embassy and notarized in the jurisdiction
where the Power of Attorney is being issued. However, the Power of Attorney
provided by Applicants from countries that have signed The Hague Legislation
Convention, 1961 are not required to be legalized by the Indian Embassy if it
carries a conforming Apostille certificate.

Page 27 of 54

<!-- page 28 -->

Form 3F: Format of Bank Guarantee for Earnest Money Deposit
BG No.
Date:
1.

In consideration of you, Department of Industrial Policy and Promotion, Ministry
of Commerce and Industry, Government of India, Udyog Bhawan, New Delhi —
110 011 (hereinafter referred to as the ―
Authority‖ which expression shall, unless
repugnant to the context or meaning thereof, include its administrators,
successors and assigns) having agreed to receive the proposal of [Name of
company], (hereinafter referred to as the ―
Bidder‖ which expression shall unless
it be repugnant to the subject or context thereof include its successors and
assigns), for appointment as Media Agency for [name of assignment] pursuant
to the RFQ – cum - RFP Document dated [date] issued in respect of the
Assignment and other related documents including without limitation the draft
work order for services (hereinafter collectively referred to as ―
RFQ – cum - RFP
Documents‖), we [Name of the Bank] having our registered office at [registered
address] and one of its branches at [branch address] (hereinafter referred to as
the ―
Bank‖), at the request of the Bidder, do hereby in terms of relevant clause
of the RFQ – cum - RFP Document, irrevocably, unconditionally and without
reservation guarantee the due and faithful fulfillment and compliance of the
terms and conditions of the RFQ – cum - RFP Document by the said Bidder and
unconditionally and irrevocably undertake to pay forthwith to the Authority an
amount of Rs. [in figures] ([in words]) (hereinafter referred to as the
―
Guarantee‖) as our primary obligation without any demur, reservation,
recourse, contest or protest and without reference to the Bidder if the Bidder
shall fail to fulfill or comply with all or any of the terms and conditions contained
in the said RFQ – cum - RFP Document.

2.

Any such written demand made by the Authority stating that the Bidder is in
default of the due and faithful fulfillment and compliance with the terms and
conditions contained in the RFQ – cum - RFP Document shall be final,
conclusive and binding on the Bank. We, the Bank, further agree that the
Authority shall be the sole judge to decide as to whether the Bidder is in default
of due and faithful fulfillment and compliance with the terms and conditions
contained in the RFQ – cum - RFP Document including, Document including
without limitation, failure of the said Bidder to keep its Proposal valid during the
validity period of the Proposal as set forth in the said RFQ – cum - RFP
Document, and the decision of the Authority that the Bidder is in default as
aforesaid shall be final and binding on us, notwithstanding any differences
between the Authority and the Bidder or any dispute pending before any court,
tribunal, arbitrator or any other authority.
We, the Bank, do hereby unconditionally undertake to pay the amounts due and
payable under this Guarantee without any demur, reservation, recourse, contest
or protest and without any reference to the Bidder or any other person and
irrespective of whether the claim of the Authority is disputed by the Bidder or
not, merely on the first demand from the Authority stating that the amount
claimed is due to the Authority by reason of failure of the Bidder to fulfill and
comply with the terms and conditions contained in the RFQ – cum - RFP
Document including without limitation, failure of the said Bidder to keep its
Proposal valid during the validity period of the Proposal as set forth in the said
RFQ – cum - RFP Document for any reason whatsoever. Any such demand
made on the Bank shall be conclusive as regards amount due and payable by
the Bank under this Guarantee. However, our liability under this Guarantee shall

3.

Page 28 of 54

<!-- page 29 -->

be restricted to an amount not exceeding Rs. [in figures] ([in words]).
4.

This Guarantee shall be irrevocable and remain in full force for a period of 60
(sixty) days from the Proposal Due Date and a further claim period of thirty (30)
days or for such extended period as may be mutually agreed between the
Authority and the Bidder, and agreed to by the Bank, and shall continue to be
enforceable until all amounts under this Guarantee have been paid.

5.

The Guarantee shall not be affected by any change in the constitution or
winding up of the Bidder or the Bank or any absorption, merger or amalgamation
of the Bidder or the Bank with any other person.

6.

In order to give full effect to this Guarantee, the Authority shall be entitled to
treat the Bank as the principal debtor. The Authority shall have the fullest liberty
without affecting in any way the liability of the Bank under this Guarantee from
time to time to vary any of the terms and conditions contained in the said RFQ –
cum - RFP Document or to extend time for submission of the Proposals or the
Proposal validity period or the period for conveying of Letter of Acceptance to
the Bidder or the period for fulfillment and compliance with all or any of the
terms and conditions contained in the said RFQ
– cum - RFP Document by the said Bidder or to postpone for any time and from
time
to time any of the powers exercisable by it against the said Bidder and either to
enforce or forbear from enforcing any of the terms and conditions contained in
the said RFQ – cum - RFP Document or the securities available to the Authority,
and the Bank shall
not be released from its liability under these presents by any exercise by the
Authority of the liberty with reference to the matters aforesaid or by reason of
time being given to the said Bidder or any other forbearance, act or omission on
the part of the Authority or any indulgence by the Authority to the said Bidder or
by any change in the constitution of the Authority or its absorption, merger or
amalgamation with any other person or any other matter or thing whatsoever
which under the law relating to sureties would but for this provision have the
effect of releasing the Bank from its such liability.

7.

Any notice by way of request, demand or otherwise hereunder shall be
sufficiently given or made if addressed to the Bank and sent by courier or by
registered mail to the Bank at the address set forth herein.

8.

We undertake to make the payment on receipt of your notice of claim on us
addressed to [Name of bank along with branch address] and delivered at our
above branch which shall be deemed to have been duly authorized to receive
the said notice of claim.

9.

It shall not be necessary for the Authority to proceed against the said Bidder
before proceeding against the Bank and the guarantee herein contained shall be
enforceable against the Bank, notwithstanding any other security which the
Authority may have obtained from the said Bidder or any other person and
which shall, at the time when proceedings are taken against the Bank
hereunder, be outstanding or unrealized.

10.

We, the Bank, further undertake not to revoke this Guarantee during its currency
except with the previous express consent of the Authority in writing.

11.

The Bank declares that it has power to issue this Guarantee and discharge the
obligations contemplated herein, the undersigned is duly authorized and has full
power to execute this Guarantee for and on behalf of the Bank.
For the avoidance of doubt, the Bank‘s liability under this Guarantee shall be
restricted to Rs. [in figures] ([in words]). The Bank shall be liable to pay the said

12.

Page 29 of 54

<!-- page 30 -->

amount or any part thereof only if the Authority serves a written claim on the
Bank in accordance with paragraph 8 hereof, on or before [date].

Signed and Delivered by [name of bank]

By the hand of Mr. /Ms. [name], it‘s [designation] and authorized official.

(Signature of the Authorized Signatory)
(Official Seal)

Notes:
 The Bank Guarantee should contain the name, designation and code number of the
officer(s) signing the Guarantee.
 The address, telephone number and other details of the Head Office of the Bank as
well as of issuing Branch should be mentioned on the covering letter of issuing
Branch.

Page 30 of 54

<!-- page 31 -->

Form 3G: Technical Proposal Submission Form
[Location, Date]
Deputy Secretary (BE-III),
DIPP,
Udyog Bhawan,
New Delhi-110011
RFQ – cum - RFP dated [date] for selection for [name of assignment]
Madam,
With reference to your RFQ – cum - RFP Document dated [date], we, having examined
all relevant documents and understood their contents, hereby submit our Technical
Proposal for selection as [name of assignment]. The Proposal is unconditional and
unqualified.
We are submitting our Proposal as [name of the applicant].
If negotiations are held during the period of validity of the Proposal, we undertake to
negotiate in accordance with the RFQ – cum - RFP. Our Proposal is binding upon us,
subject only to the modifications resulting from negotiations in accordance with the
RFQ – cum - RFP.
We understand you are not bound to accept any Proposal you receive.
Further:
1.

We acknowledge that Client will be relying on the information provided in the
Proposal and the documents accompanying the Proposal for selection of the
Media Agency, and we certify that all information provided in the Proposal and
in the supporting documents is true and correct, nothing has been omitted
which renders such information misleading; and all documents accompanying
such Proposal are true copies of their respective originals.

2.

This statement is made for the express purpose of appointment as the Media
Agency for the aforesaid Project.

3.

We shall make available to Client any additional information it may deem
necessary or require for supplementing or authenticating the Proposal.

4.

We acknowledge the right of Client to reject our application without assigning
any reason or otherwise and hereby waive our right to challenge the same on
any account whatsoever.

5.

We certify that in the last 3 (three) years, we have neither failed to perform on
any assignment or contract, as evidenced by imposition of a penalty by an
arbitral or judicial authority or a judicial pronouncement or arbitration award
against the Applicant, nor been expelled from any project, assignment or
contract by any public authority nor have had any assignment or contract
terminated by any public authority for breach on our part.

Page 31 of 54

<!-- page 32 -->

6.

We declare that:
a) We have examined and have no reservations to the RFQ – cum - RFP,
including any Addendum issued by the Authority;
b) We do not have any conflict of interest in accordance with the terms of the
RFQ – cum - RFP;
c) We have not directly or indirectly or through an agent engaged or indulged
in any corrupt practice, fraudulent practice, coercive practice, undesirable
practice or restrictive practice, as defined in the RFQ – cum - RFP
document, in respect of any tender or request for proposal issued by or any
agreement entered into with Client or any other public sector enterprise or
any government, Central or State; and
d) We hereby certify that we have taken steps to ensure that no person acting
for us or on our behalf will engage in any corrupt practice, fraudulent
practice, coercive practice, undesirable practice or restrictive practice.

7.

We understand that you may cancel the selection process at any time and that
you are neither bound to accept any Proposal that you may receive nor to
select the Media Agency, without incurring any liability to the Applicants.

8.

We certify that in regard to matters other than security and integrity of the
country, we or any of our affiliates have not been convicted by a court of law or
indicted or adverse orders passed by a regulatory authority which would cast a
doubt on our ability to undertake the Project or which relates to a grave offence
that outrages the moral sense of the community.

9.

We further certify that in regard to matters relating to security and integrity of
the country, we have not been charge-sheeted by any agency of the
Government or convicted by a court of law for any offence committed by us or
by any of our affiliates. We further certify that neither we nor any of our
consortium members have been barred by the central government, any state
government, a statutory body or any public sector undertaking, as the case may
be, from participating in any project or bid, and that any such bar, if any, does
not subsist as on the date of this RFQ – cum - RFP.

10.

We further certify that no investigation by a regulatory authority is pending
either against us or against our affiliates or against our CEO or any of our
Managers/ employees.

11.

We hereby irrevocably waive any right or remedy which we may have at any
stage at law or howsoever otherwise arising to challenge or question any
decision taken by Client in connection with the selection of Media Agency or in
connection with the selection process itself in respect of the above mentioned
Project.

12.

We agree and understand that the proposal is subject to the provisions of the
RFQ – cum - RFP document. In no case, shall we have any claim or right of
whatsoever nature if the Project is not awarded to us or our proposal is not
opened or rejected.

13.

The Financial Proposal is being submitted in a separate cover. This Technical
Proposal read with the Financial Proposal shall be binding on us.

Page 32 of 54

<!-- page 33 -->

14.

We agree and undertake to abide by all the terms and conditions of the RFQ –
cum - RFP Document.

We remain, Yours sincerely,

Authorized Signature [In full and
initials]: Name and Title of Signatory:
Name of
Firm:
Address:
Telephone:
Fax:
(Name and seal of the Applicant/Member in Charge)

Page 33 of 54

<!-- page 34 -->

Form 3H: Strategy in line with the proposed Brand Vision for Make in India, including
innovative ideas & suggestions.

[Location, Date]

Page 34 of 54

<!-- page 35 -->

Form 3I: Profile and track record of the agency
[Location, Date]
Here give details of Profile & Track record of the agency, including experience in the
fields related to Print, Outdoor, Electronic Media, Activation, Analytics & Digital Media
with separate emphasis on Social Media amplification - reference client work



Brief Profile of Agency (in one page)



Number of offices with locations
o
o



Number of employees
o
o



In India
Overseas

In India
Overseas

Details of Partners / Affiliates / Associates
o
o

In India
Overseas



In-house facilities including different units / divisions within the Agency



Sources through which the Agency will access required inputs for the Media
requirements of DIPP



Experience with reference case work of large brands handled by the Agency, with focus
on integration and delivery of above and below the line activities

Page 35 of 54

<!-- page 36 -->

Form 3J: Details of International clients handled
[Location, Date]

Page 36 of 54

<!-- page 37 -->

Form 3K: Credentials of Media & Marketing team identified to work with DIPP.
[Location, Date]

Page 37 of 54

<!-- page 38 -->

Form 3L: Details of Identification of key success metrics, design & concept of
evaluation, etc.

Here provide details of identification of key success metrics, Design & Concept of evaluation,
tracking & course correction plan for Key Performance Indicators (KPIs) with specific timelines
& tools deployed.

Page 38 of 54

<!-- page 39 -->

Form 3M: Details of design & concept of Online Reputation Management plan
[Location, Date]
Here provide the details of Design & Concept of Online Reputation Management (ORM)
plan with specific input parameters & tool deployment.

Page 39 of 54

<!-- page 40 -->

Section 4. Financial Proposal – Standard Forms

Form 4A:

Financial Proposal Submission

Form 4B:

Summary of Costs

Page 40 of 54

<!-- page 41 -->

Form 4A: Financial Proposal Submission Form
[Location]
[Date]
To
Deputy Secretary (BE-III),
DIPP,
Udyog Bhawan,
New Delhi-110011
Dear Madam,
Subject: Services for [name of assignment].
We, the undersigned, offer to provide the services for [name of assignment] in accordance
with your Request for Qualification – cum - Request for Proposal dated [date] and our
Proposal. Our attached Financial Proposal is for the sum of [amount(s) in words and figures].
Our Financial Proposal shall be binding upon us subject to the modifications resulting from
arithmetic correction, if any, up to expiration of the validity period of the Proposal, i.e. [date].
We undertake that, in competing for (and, if the award is made to us, in executing) the above
assignment, we will strictly observe the laws against fraud and corruption in force in India
namely ―
Prevention of Corruption Act 1988‖.
We understand you are not bound to accept any Proposal you receive.
Yours
sincerely,

Authorized Signature [In full and initials]:
Name and Title of Signatory:
Name
Address:

of

Firm:

Page 41 of 54

<!-- page 42 -->

Form 4B: Summary of Costs
Item

Amount in
words

Cost
Amount in figures

Costs of Financial Proposal
(including all other taxes)

Service Tax
Total cost of Financial
Proposal (including service tax)

The agency will include following items in cost for one year without giving any break up in
the table.
A. Annual retainership fee
B. CPM Cost per unit for ad serving fees
The evaluation of the financial bid will be done based on total cost for one year for works
mentioned under Section 5, Terms of Reference which would be sum total of A & B as
mentioned above. The retainership fee will cover costs/expenses of the Media Agency for
undertaking work as detailed in the Scope of Work.
Service tax would be payable at the applicable rates as may be in force from time to time.

Page 42 of 54

<!-- page 43 -->

Section 5. Terms of Reference
SCOPE OF WORK
Providing a media and marketing vision for the Make in India campaign for the next 3 years
(2015-16, 2016-17 and 2017-18). The agency would initially be engaged for 2 years and
based on performance review, its term of engagement may be extended for third year.
The Make in India campaign will play a crucial role in driving the manufacturing industry‘s
overall contribution to India‘s GDP.
A. RETAINERSHIP ITEMS:
I. Communication & Media Strategy for Make in India:
Formulating a Communication & Media strategy in line with the Make in India vision with the
GOI & the Creative agency for the next 3 years. Identify key themes and map overall
development and evolution of the campaign from 2015-16 to 2017-18.
This will also include mapping sectors to geographies & audience profile, identifying relevant
events and opportunities globally and amplifying Media and Marketing communication &
messaging through planning and implementation of Marketing & Media activity across both
Paid Media and Non-Paid media avenues through 360 degree communication approach for
the 3 years.
II. Market & Audience Mapping:
1. Identifying priority markets for targeted industries, in line with the overall sector
prioritization for Make in India.
2. Identification of key stakeholders and opinion leaders to guide means and tone of
communication
3. Understanding of key competitive nations and their value propositions and overall
conversation around industries.
These will feed in to customized Make in India country and sector specific propositions for
each key market.
III. Media Prioritization:
Evaluating and prioritizing key media for each activity. Choosing between Social, influencer
outreach, mass media for each initiative, depending on markets, audience and desired
outcome.
IV. Amplification through Paid Media:
1. Providing professional inputs and support in buying of media for Print, Digital, Electronic,
Out Of Home for Make in India campaign in the International markets on
themes/subjects to be decided in consultation with ‗Department of Industrial Policy &
Promotion‘. This would entail assistance and supervision of buying of the media slots by
‗Department of Industrial Policy & Promotion‘ to ensure best of rates and negotiations
directly from the media owner.
2. Identify, recommend and manage the right events, exhibitions and fairs in line with MII
priorities globally and amplifying MII‘s participation locally and globally.
3. Out of Home media production would be executed by the Out of Home agency who
should include unit-wise cost for the same in the bid proposal.
4. Executing the media and Marketing strategy, planning and undertaking post campaign
reporting.
Page 43 of 54

<!-- page 44 -->

Please note:
*Creatives for Media campaign:- For the above media and marketing campaigns the creative
units will be provided by Department of Industrial Policy & Promotion. (and
production/resizing/adaptation etc. will be out of the scope of this RFP).
**Ad Serving fee – Any third party Ad Serving such as DoubleClick, Mediamind etc. if
applicable for implementation of rich media creative will be responsibility of the agency and
Cost Per thousand Impression (CPM) cost for the same needs to be included in the
proposal.
V. Amplification through Non- paid Digital Campaigns & Activities
Planning and Executing a ―
Key Influencer Program‖ on Digital platforms
 The Influencer program will aim at engaging top influencers (minimum total of 2500) in
key markets
 The identification of influencers will have to be done by a well-established social
listening tool.
 The influencer‘s identification should be done as per the sectors of Make in India
Campaign.
 This programme will also include engagement with influencers who have already been
identified by DIPP during the previous year‘s campaign.
 The Influencer program will have a customized outreach program in all key markets
 The Influencer will aim to focus on blogs & forums and other social channels.
 The Influencer program will aim to generate content for social channels and blogs, web
listings, directory submissions etc. and spread awareness about ―
Make in India‖ theme.
Planning and Executing a ―
Social Media Monitoring Program‖ on Digital platforms
The Social Media Monitoring Program will undertake monitoring across all keywords in all
priority markets.
Social Media Monitoring Program will create and manage a Monitoring platform which will be
both predictive and reactive in approach
The key Languages to be monitored will be in English as well as other key global business
languages in line with market requirements (Mandarin, Spanish, German, French, etc)
VI. Online Reputation Management:
Managing, tracking and tweaking Make in India‘s online presence in real time in order to
swiftly react/ respond to both macro and micro environmental changes. Clear guidelines will
be setup at the start of campaign to enable swift response timings.
VII. Evaluation Metrics:
Identifying key success metrics for each component of the Make in India campaign. Putting
in place an ongoing evaluation & tracking program for all key performance indicators in order
to facilitate constant measurability and course correction when required- both on a monthly
as well as on a quarterly basis.
B. CPM Cost per unit for ad serving fees.

Page 44 of 54

<!-- page 45 -->

Section 6. Standard Form of Work Order

STANDARD FORM OF WORK ORDER
FOR APPOINTMNET OF MEDIA
AGENCY

Between

[Name of client]

[Name of MEDIAAGENCY]

[Date]

Page 45 of 54

<!-- page 46 -->

I.

Form of Work Order

Work order to undertake [name of assignment]
The Department of Industrial Policy and Promotion, Ministry of Commerce and Industry,
Government of India, Udyog Bhawan, New Delhi-110001, India, hereinafter referred to as the
―
Client‖ which expression unless repugnant to context or meaning thereof shall include its
successors, affiliates and assigns) has:
a)

requested the Media Agency to provide certain services as defined in this work order
(hereinafter called the ―
Services‖); and

b)

The Media Agency, having represented to the Client that they have the required
professional skills, personnel and technical resources, have agreed to provide the
services on the terms and conditions set forth in this assignment.

NOW THEREFORE the Client hereto hereby agrees as follows:
1. The following documents attached hereto shall be deemed to form an integral part of this
work order:
Appendix A: Terms of reference containing, inter-alia, the Description of the Services and
reporting requirements,
Appendix B: Cost Estimate
Appendix C: Copy of Bank Guarantee for Performance Security [in the format given in
Annexure A]
2.

The mutual rights and obligations of the Client and the Media Agency shall be as set forth in
the work order; in particular:
a) The Media Agency shall carry out the Services in accordance with the provisions of the
work order; and
b) Client will make payments to the Media Agency in accordance with the provisions of the
work order.

3

Commencement, completion, modification and termination of work order

3.1.1 Effectiveness of work order: This Work order shall come into effect on the date the work
order is assented to by the Media Agency, or such other date as may be stated.
3.1.2 Commencement of Services: The Media Agency shall commence the Services from any
date notified by the Client.
3.1.3 Expiration of work order: Unless terminated earlier pursuant to relevant clauses in this work
order hereof, this work order shall expire when Services have been completed and all
payments have been made at the end of such time period after the Effective Date.
3.1.4 Modification: Modification of the terms and conditions of this work order, including any
modification of the scope of the Services or of the work order Price, may only be made by
written agreement between the Parties.

Page 46 of 54

<!-- page 47 -->

3.1.5 Force Majeure
Neither party will be liable in respect of failure to fulfill its obligations, if the said failure is
entirely due to Acts of God, Governmental restrictions or instructions, natural calamities or
catastrophe, epidemics or disturbances in the country. Force Majeure shall not include (i) any
event which is caused by the negligence or intentional action of a Party or by or of such
Party‘s agents or employees, nor (ii) any event which a diligent Party could reasonably have
been expected both to take into account at the time of being assigned the work, and avoid or
overcome with utmost persistent effort in the carrying out of its obligations hereunder.
A Party affected by an event of Force Majeure shall immediately notify the other Party of
such event, providing sufficient and satisfactory evidence of the nature and cause of such
event, and shall similarly give written notice of the restoration of normal conditions as soon as
possible.
3.1.5.1 No Breach of Work order: The failure of a party to fulfill any of its obligations under the
Work order shall not be considered to be a breach of, or default under this Work order insofar
as such inability arises from an event of Force Majeure, provided that the Party affected by
such an event:
a)

has taken all precautions, due care and reasonable alternative measures in order to
carry out the terms and conditions of this Work order, and

b)

has informed the other party as soon as possible about the occurrence of such an
event.

c)

the dates of commencement and estimated cessation of such event of Force Majeure;
and

d)

the manner in which the Force Majeure event(s) affects the Party‘s obligation(s) under
the Work order.

3.1.5.2 Neither Party shall be able to suspend nor excuse the non- performance of its obligations
hereunder unless such Party has given the notice specified above.
3.1.6 Extension of Time: Any period within which a Party shall, pursuant to this Work order,
complete any action or task, shall be extended for a period equal to the time during which
such Party was unable to perform such action as a result of Force Majeure.
3.1.7 Payments: During the period of their inability to perform the Services as a result of an event
of Force Majeure, the Media Agency shall be entitled to continue to be paid under the terms
of this Work order, as well as to be reimbursed for additional costs reasonably and
necessarily incurred by them during such period for the purposes of the services and in
reactivating the services after the end of such period.
3.2

Termination

3.2.1 By the client: The Client may terminate this Work order, written notice of termination to the
Media Agency, to be given after the occurrence of any of the events specified in this clause:
a)
b)

if the Media Agency do not remedy a failure in the performance of their obligations
under the Work order, within a period of seven (7) days, after being notified or within
such further period as the Client may have subsequently approved in writing;
within fifteen (15) days, if the Media Agency become insolvent or bankrupt;

c)

if, as the result of Force Majeure, the Media Agency are unable to perform a material
portion of the Services for a period of not less than fifteen (15) days;

d)

within fifteen (15) days, if the Media Agency fails to comply with any final decision
reached as a result of arbitration proceedings pursuant to relevant clauses hereof;
Page 47 of 54

<!-- page 48 -->

e)

within seven (7) days, if the Media Agency submits to the Client a false statement
which has a material effect on the rights, obligations or interests of the Client. If the
Media Agency places itself in position of conflict of interest or fails to disclose promptly
any conflict of interest to the Client;

f)

within seven (7) days, if the Media Agency, in the judgment of the Client has engaged
in Corrupt or Fraudulent Practices in competing for or in executing the Work order;

g)

if the Client, in its sole discretion and for any reason whatsoever, within a period of
fifteen (15) days‘ decides to terminate this Work order.

3.2.2 Payment upon termination: Upon termination of this Work order, the Client will make the
following payments to the Consultants:
a)

Remuneration pursuant to relevant clauses for Services satisfactorily performed prior
to the effective date of termination;

b)

If the Work order is terminated pursuant to Clause 3.3.1a), b), d), e) or f), the Media
Agency shall not be entitled to receive any agreed payments upon termination of the
Work order. However, the Client may consider to make payment for the part
satisfactorily performed on the basis of the quantum merit as assessed by it, in its
sole discretion, if such part is of economic utility to the Client. Under such
circumstances, upon termination, the Client may also impose liquidated damages as
per the provisions of relevant clauses of this Work order. The Media Agency will be
required to pay any such liquidated damages to Client within 30 days of termination
date.

3.2.3 Disputes about Events of Termination: If either Party disputes Termination of the work order
under relevant clauses hereof, such Party may, within forty-five (45) days after receipt of
notice of termination from the other Party, refer the matter to arbitration under relevant
clauses hereof, and this Work order shall not be terminated on account of such event except
in accordance with the terms of any resulting arbitral award.
3.3

Obligations of the Media Agency

3.3.1 General: The Media Agency shall perform the Services and carry out their obligations
hereunder with all due diligence, efficiency and economy, in accordance with generally
accepted professional techniques and practices, and shall observe sound management
practices, and employ appropriate advanced technology and safe methods. The Media
Agency shall always act, in respect of any matter relating to this Work order or to the
Services, as faithful advisers to the Client, and shall at all times support and safeguard the
Client‘s legitimate interests in any dealings with Sub- consultants or third parties.
3.3.2 Conflict of interest
3.3.2.1 Prohibition of Conflicting Activities: Neither the Media Agency nor their Sub-consultants
nor the Personnel shall engage, either directly or indirectly, in any of the following activities:
a)

during the term of this Work order, any business or professional activities which would
conflict with the activities assigned to them under this Work order; and

b)

after the termination of this work order, such other activities as may be specified.

3.3.3 Confidentiality: The Media Agency, their Sub-consultants, and the Personnel of either of them
shall not, either during the term or within two (2) years after the expiration of this Work order,
disclose any proprietary or confidential information relating to the Project, the Services, this
Contact or the Client‘s business or operations without the prior written consent of the Client.
3.3.4 Documents Prepared by the Media Agency to be the Property of the Client: All designs,
Page 48 of 54

<!-- page 49 -->

reports, other documents and software submitted by the Media Agency pursuant to this work
order shall become and remain the property of the Client, and the Media Agency shall, not
later than upon termination or expiration of this Work order, deliver all such documents and
software to the Client, together with a detailed inventory thereof. The Media Agency may
retain a copy of such documents and software. Restrictions about the future use of these
documents and software, if any, shall be specified in the SC.
3.3.5 Liability of the Media Agency: Subject to additional provisions, if any, in this work order the
Media Agency‘s liability under this Work order shall be as provided by the Applicable Law.
3.3.6 Professional Liability Insurance: Media Agency will maintain at its expense, Professional
Liability Insurance including coverage for errors and omissions caused by Media Agency ‗s
negligence, breach in the performance of its duties under this Work order from an Insurance
Company permitted to offer such policies in India, for a period of one year beyond completion
of Services commencing from the Effective Date, (i) For an amount not exceeding total
payments for Professional Fees made or expected to be made to the Media Agency
hereunder or (ii) the proceeds, the Media Agency may be entitled to receive from any
insurance maintained by the Media Agency to cover such a liability, whichever of (i) or (ii) is
higher with a minimum coverage of [insert amount and currency].
3.4

Obligations of the client

3.4.1 Assistance and Exemptions: the Client will use its best efforts to ensure that the Government
will provide the Media Agency with work permits and such other documents as necessary to
enable the Media Agency to perform the Services:
3.4.1.1 issue to officials, agents and representatives of the Government all such instructions as
may be necessary or appropriate for the prompt and effective implementation of the Services;
3.5

Payments to the Media Agency
3.5.1 Advance payment will not be considered.
3.5.2 The payment to the Agency would be made on quarterly basis against satisfactory
execution of quarterly work plan as decided in beginning of the year. The Agency will
submit pre-receipted invoices in triplicate, complete in all respects, on the last working
day of each quarter, for necessary settlement. The invoices should be submitted along
with complete details of the work undertaken during the quarter, supporting documents
and bills as well as copies of the creative and publicity material designed / produced
during the quarter, for which the bills are submitted. A reconciliation sheet pertaining to
the bills will be submitted every quarter.
3.5.3 The final payment, shall be released only after completion of the required work for the
year and on submission of a statement of work having been executed as per the
requirements detailed in the RFP Document, or communicated subsequently by
‗DIPP‘.
3.5.4 The Service Tax/ VAT shall be paid as applicable.
3.5.5 For facilitating Electronic transfer for funds the selected agency will be required to
indicate the name of the Bank and Branch, account number (i.e. bank names, IFSC
Code and Bank A/c No.) and also forward a cheque leaf duly cancelled to verify the
details furnished. These details should also be furnished on the body of every bill
submitted for payments by the selected agency.
3.5.6 Currency: The price is payable in local currency i.e. Indian Rupees.
3.5.7 Payment for Additional Services: For the purpose of determining the remuneration due
for additional services as may be agreed under relevant clauses for modification in this
work order.
Page 49 of 54

<!-- page 50 -->

3.6

Settlement of disputes

3.6.1 Amicable Settlement: The Parties shall use their best efforts to settle amicably all disputes
arising out of or in connection with this Work order or its interpretation.
3.6.2 Disputes Settlement: Any dispute between the Parties as to matters arising out of and
relating to this Work order that cannot be settled amicably within thirty (30) days after receipt
by one Party of the other Party‘s request for such amicable settlement may be submitted by
either Party for settlement in accordance with the provision specified in the SC.
3.7

Responsibility for accuracy of project documents

3.7.1 General
3.7.1.1 The Media Agency shall be responsible for accuracy of the estimate and all other details
prepared by him as part of these services. He shall indemnify the client against any
inaccuracy in the work, which might surface during implementation of the project.
3.8

Liquidated damages

3.8.1.1 If the selected Consultant fails to complete the Assignment, within the period specified
under the work order, or in case of underperformance and undue delays in performance by
the agency, the Performance Guarantee is liable to be forfeited in full or part besides other
action, including blacklisting of the agency, as may be deemed fit by ‗DIPP‘.
4

Miscellaneous

4.1

Assignment and Charges

4.1.1 The Work order shall not be assigned by the Media Agency save and except with prior
consent in writing of the Client, which the Client will be entitled to decline without assigning
any reason whatsoever.
4.1.2 The Client is entitled to assign any rights, interests and obligations under this Work order to
third parties.
4.1.3 Indemnity: The Media Agency agrees to indemnify and hold harmless the Client from and
against any and all claims, actions, proceedings, lawsuits, demands, losses, liabilities,
damages, fines or expenses (including interest, penalties, attorneys‘ fees and other costs of
defence or investigation (i) related to or arising out of, whether directly or indirectly, (a) the
breach by the Media Agency of any obligations specified in relevant clauses hereof; (b) the
alleged negligent, reckless or otherwise wrongful act or omission of the Media Agency
including professional negligence or misconduct of any nature whatsoever in relation to
Services rendered to the Client; (c) any Services related to or rendered pursuant to the Work
order (collectively ―In
demnified matter‖). As soon as reasonably practicable after the receipt by
the Client of a notice of the commencement of any action by a third party, the Client will notify
the Media Agency of the commencement thereof; provided, however, that the omission so to
notify shall not relieve the Media Agency from any liability which it may have to the Client or
the third party. The obligations to indemnify and hold harmless, or to contribute, with respect
to losses, claims, actions, damages and liabilities relating to the Indemnified Matter shall
survive until all claims for indemnification and/or contribution asserted shall survive and until
their final resolution thereof. The foregoing provisions are in addition to any rights which the
Client may have at common law, in equity or otherwise.
4.1.4 Notices: Unless otherwise stated, notices to be given under the Work order including but not
limited to a notice of waiver of any term, breach of any term of the Work order and termination
of the Work order, shall be in writing and shall be given by hand delivery, recognized
international courier, mail, telex or facsimile transmission and delivered or transmitted to the
Parties at their respective addresses specified in the SC. The notices shall be deemed to have
been made or delivered (i) in the case of any communication made by letter, when delivered
by hand, by recognized international courier or by mail (registered, return receipt requested) at
Page 50 of 54

<!-- page 51 -->

that address and (ii) in the case of any communication made by telex or facsimile, when
transmitted properly addressed to such telex number or facsimile number.
4.1.5 Severability: If for any reason whatever any provision of the Work order is or becomes
invalid, illegal or unenforceable or is declared by any court of competent jurisdiction or any
other instrumentality to be invalid, illegal or unenforceable, the validity, legality or
enforceability of the remaining provisions shall not be affected in any manner, and the Parties
will negotiate in good faith with a view to agreeing upon one or more provisions which may be
substituted for such invalid, unenforceable or illegal provisions, as nearly as is practicable.
Provided failure to agree upon any such provisions shall not be subject to dispute resolution
under the Work order or otherwise.
4.1.6 Professional Liability Insurance: Media Agency will maintain at its expense, Professional
Liability Insurance including coverage for errors and omissions caused by Media Agency ‗s
negligence, breach in the performance of its duties under this Work order from an Insurance
Company permitted to offer such policies in India, for a period of one year beyond completion
of Services commencing from the Effective Date, (i) For an amount not exceeding total
payments for Professional Fees made or expected to be made to the Media Agency
hereunder or (ii) the proceeds, the Media Agency may be entitled to receive from any
insurance maintained by the Media Agency to cover such a liability, whichever of (i) or (ii) is
higher with a minimum coverage of [insert amount and currency].
4.1.7 Performance security
4.1.7.1 The Consultant shall prior to the Effective Date and as a condition precedent to its
entitlement to payment under this Work order, provide to the Client a legal, valid and
enforceable Performance Security in the form of an unconditional and irrevocable bank
guarantee as security for the performance by the Consultant of its obligations under this
Work order, in the form set out in this work order, in an amount equal 15 (fifteen) percent of
the total cost of Financial Proposal under this Assignment. Further, in the event the term of
this Work order is extended, the Consultant shall at least fifteen (15) days prior to the
commencement of every Subsequent Year or at least thirty (30) days prior to the date of
expiry of the then existing bank guarantee, whichever is earlier, provide an unconditional
and irrevocable bank guarantee as Performance Security for an amount equivalent to 15
(fifteen) percent of the total cost of Financial Proposal under this Assignment.
4.1.7.2 The Performance Security shall be obtained from a scheduled commercial Indian bank, in
compliance with Applicable Laws (including, in case the Consultant is a non-resident, in
compliance with applicable foreign exchange laws and regulations). {In the event the
Consultant is a joint venture consortium, the Performance Security may be provided by any
Member; provided that such Performance Security shall mention the details of this Work
order and the other Members.}
4.1.7.3 The Performance Security shall be extended accordingly such that the Performance
Security remains valid until the expiry of a period of 60 (Sixty) Days from the date of
completion of the assignment. If the Client shall not have received an extended/
replacement Performance Security in accordance with this clause at least thirty (30) days
prior to the date of expiry of the then existing Performance Security, the Client shall be
entitled to draw the full amount of the bank guarantee then available for drawing and retain
the same by way of security for the performance by the Media Agency of its obligations
under this Work order until such time as the Client shall receive such an extended/
replacement Performance Security whereupon, subject to the terms of this Work order, the
Client will refund to the Media Agency the full amount of the bank guarantee, unless the
Client has drawn upon the Performance Security in accordance with the provisions of this
Work order, in which case only the balance amount remaining will be returned to the Media
Agency; provided that the Client will not be liable to pay any interest on such balance. The
Client will return the bank guarantee provided as Performance Security to the issuer thereof
for cancellation promptly upon receipt of any extension/ replacement thereof. Subject to
satisfactory completion of all deliverables under this Work order, the Performance Security
will, subject to any drawdowns by the Client in accordance with the provisions hereof, be
Page 51 of 54

<!-- page 52 -->

released by the Client within a period of 60(Sixty) Days from the date of completion of the
services.
5

The Client shall have the right to claim under the Performance Security and appropriate the
proceeds if any of the following occur:
a)

the Consultant becomes liable to pay penalty;

b)

occurrence of any of the events listed in sub-clauses (a) through (f) of Clause 6.3.1
of the GCC;
any material breach of the terms hereof; and/or
without prejudice to paragraph above, the Consultant fails to extend the validity of
the Performance Security or provide a replacement Performance Security in
accordance with the provisions of this Work order.

c)
d)

Page 52 of 54

<!-- page 53 -->

Annexure A: Form of Bank Guarantee for Performance Security
(To be stamped in accordance with Stamp Act if any, of the country for issuing bank)
Ref.:

Bank Guarantee:

Date: Dear
Sir,
In consideration of Department of Industrial Policy and Promotion, Ministry of Commerce and
Industry, Government of India (hereinafter referred as the ‗Client‘, which expression shall, unless
repugnant to the context of meaning thereof include its successors, administrators and assigns)
having awarded to M/s [name of Media Agency] a [type of company], established under laws of
[country] and having its registered office at [address] (hereinafter referred to as the ‗Media
Agency‘ which expression shall unless repugnant to the context or meaning thereof, include its
successors, administrators, executors and permitted assigns), an Assignment for preparation of
[name of assignment] Work order by issue of Client‘s Work order Letter of Award No. [reference]
dated [date] and the same having been unequivocally accepted by the Media Agency, resulting in
a Work order valued at Rs. [amount in figures and words] for (Scope of Work) (hereinafter called
the ‗Work order‘) and the Media Agency having agreed to furnish a Bank Guarantee amounting to
Rs. [amount in figures and words] to the Client for performance of the said Agreement.
We [Name of Bank] incorporated under [law and country] having its Head Office at
[address](hereinafter referred to as the Bank), which expression shall, unless repugnant to the
context or meaning thereof, include its successors, administrators executors and assigns) do
hereby guarantee and undertake to pay the Client immediately on demand an or, all monies
payable by the Media Agency to the extent of Rs. [amount in figure and words] as aforesaid at
any time up to [date] without any demur, reservation, contest, recourse or protest and/ or without
any reference to the Media Agency. Any such demand made by the Client on the Bank shall be
conclusive and binding notwithstanding any difference between the Client and the Media Agency
or any dispute pending before any Court, Tribunal, Arbitrator or any other authority.
We agree that the Guarantee herein contained shall be irrevocable and shall continue to be
enforceable until the Client discharges this guarantee.
The Client shall have the fullest liberty without affecting in any way the liability of the Bank under
this Guarantee, from time to time to vary the advance or to extend the time for performance of the
Work order by the Media Agency nor shall the responsibility of the bank be affected by any
variations in the terms and conditions of the work order or other documents. The Client shall have
the fullest liberty without affecting this guarantee, to postpone from time to time the exercise of
any powers vested in them or of any right which they might have against the Client and to
exercise the same at any time in any manner, and either to enforce or to forbear to enforce any
covenants, contained or implied, in the Work order between the Client and the Media Agency any
other course or remedy or security available to the client. The Bank shall not be relieved of its
obligations under these presents by any exercise by the Client of its liberty with reference to the
matters aforesaid or any of them or by reason of any other act or forbearance or other acts of
omission or commission on the part of the Client or any other indulgence shown by the Client or
by any other matter or thing whatsoever which under law would but for this provision have the
effect of relieving the Bank.
The Bank also agrees that the Client at its option shall be entitled to enforce this Guarantee
against the Bank as a principal debtor, in the first instance without proceeding against the Media
Agency and notwithstanding any security or other guarantee that the client may have in relation to
the Media Agency‘s liabilities.

Page 53 of 54

<!-- page 54 -->

This Guarantee shall be irrevocable and shall remain in full force and effect until discharge by the
Bank of all its obligations hereunder.
This Guarantee shall not be affected by any change in the constitution or winding up of the Media
Agency /the Bank or any absorption, merger or amalgamation of the Media Agency /the bank with
any other Person.
Notwithstanding anything contained herein above our liability under this guarantee is limited to
Rs. [amount in figure and words] and it shall remain in force up to and including [date] and shall
extend from time to time for such period(s) (not exceeding one year), as may be desired by M/s
[name of MediaAgency] on whose behalf this guarantee has been given. Date this [date in words]
day [month] of [year in ‗yyyy‘ format] at [place].
WITNESS
1. [signature, name and address]
2. [signature, name and address]

[Official Address]

Designation

[With Bank Stamp]

Attorney as Per Power of Attorney No.
Dated
Strike out, whichever is not applicable.
The date will be fixed as indicated in S.C.C.
The stamp papers of appropriate value shall be purchased in the name of bank which issues the
‗Bank Guarantee‘. The bank guarantee shall be issued either by a bank (Nationalized/Scheduled)
located in India or a foreign bank through a correspondent bank (scheduled) located in India or
directly by a foreign bank which has been determined in advance to be acceptable to the Client.

Page 54 of 54
