---
doc_id: "4c3efca3fddd4663"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_6ad0b9e54ae361.34533805.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Vacancy Circular for inviting nominations for appointment of IFS officers in the National Compensatory Afforestation Fund Management and Planning Authority as Joint Chief Executive Officer (Jt. CEO) at the level of IGF, on deputation basis."
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1533501b72f75743"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

ANNEXURE-I
Application Form for Central Deputation postings under the National Compensatory
Afforestation Planning and Management Authority for Indian Forest Service Officers for
the posts of Joint Chief Executive Officer (Jt.CEO) [at the levels of IGF] at New Delhi.
Part-I (to be filled in by the applicant)
1.
2.
3.
4.
5.
6.
7.
8.

The level at which deputation is sought
Name of the applicant
Batch/year of allotment
Cadre
Date of Birth
Present pay scale with date of commencement of
scale of pay
Present post held
Full Address for correspondence:
(phone/fax/mobile/e-mail)

9.
Educational qualification
S.No.
Degree/Diploma

University/Institute

Year

Subject(s)

10.

Details of postings for the last 10 years: (in descending order)
Years
Main responsibilities
Special
Name of the
S.No.
(from–
Post held
in the post
attributes/
Organization
to)
(in about 100 words) achievements

11.

Details of all deputation postings (in descending order):
Years
Main areas of
S.No.
Post held
Organisation
(from–to)
responsibilities in the post

12.

Date of return to Cadre from last deputation, if applicable:

Station:
Name:
Date:

Signature:
Phone/Mob:
Email address:

<!-- page 4 -->

Part-II (to be filled in by the concerned State/UT Government)

1.
2.
3.
4.
5.
6.
7.
8.
9.

Name of the applicant
Cadre
Year of allotment
Date of superannuation
Whether the officer is clear from vigilance angle
Is there any disciplinary proceedings pending against
the officer (only the cases where charge sheets have
been served)
Has the officer ever been reprimanded/penalized or
debarred from deputation, if so the details thereof
Whether original/copies(attested) of ACRs of last
eight years enclosed
Central Deputation Reserve (in figures) as on date of sponsorship:

Authorized
10.

Filled

Filled

State Deputation Reserve (in figures) as on date of sponsorship:

Authorized

Filled

Filled

11.
It is certified that the particulars given above about the officer are correct and that in
the event of the officer being selected for posting under the National Authority CAMPA of the
MoEFCC, the Services of the officer shall be placed at the disposal of the Central Government.
Name & designation of the Head of the
Forest Department of the State/UT or the
Authorized Officer
Date:
Place:
Signature of the officer concerned
In the State Government/UT Government

<!-- page 5 -->

Annexure II
CHECK LIST
1.
2.

3.
4.
5.

Whether the application has been signed by the officer applying for deputation?
Whether Part II has duly been filled and signed by:
(i)
Head of Forest Department, Department of the State/UT or the Autonomous
Offices
(ii)
Officer concerned in the State Government/UT Government.
Whether the original/duly attested APARS for respective level posts (in accordance
with CSS-MoEFCC) are attached.
Whether State Government’s Vigilance Clearance is enclosed.
Whether Updated Executive Record Sheet is enclosed.
*************
