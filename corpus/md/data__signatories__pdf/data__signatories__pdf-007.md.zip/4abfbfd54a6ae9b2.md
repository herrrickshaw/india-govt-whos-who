---
doc_id: "4abfbfd54a6ae9b2"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/4bd9152f67156c364ee28a2a57f89764.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Tamil Nadu--Order for Madras High Court dated 21.06.2016"
date: "2016-10-04"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "96617ffa81af8c96"
---

<!-- page 1 -->

F.No. J-11017/9/2016-Judl.
Government of India
Ministry of Law and Justice
Department of Legal Affairs
Judicial Section
Shastri Bhawan, New Delhi,
dated 21", June, 2016
ORDER
The President is pleased to engage Shri C. V. Ramachandra Murthy, Advocate as Senior
Pane! Counsel for conducting Central Government litigation before Madras High Court, as
mentioned below, for a period of three years from the date of this order or until further
orders, whichever is earlier:-
| Name | Address & Mobile Number
Madras High Court
Senior Panel Counsel
C.V.Ramachandra | 19, Periyar Salai, Teynampet, Chennai- 1106/1994
Murthy 600018.
as Mob: 9884338218 7
2. The engagement and professional fee of the aforesaid advocate will be governed by the
terms and conditions contained in this Department's OM No. 25(03)/99-Judl. dated 24.09.1999
read with OM No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued subsequently
through OMs. The aforesaid OMs are available on the website of this Department (re _
www. lawmin.nic.in under heading ‘Circulars pertaining to litigations’. sy
3. Hindi version of this order will follow. [॥ Ds
2°
(6. S. Yadav)
Joint Secretary & Legal Adviser to the Government of India
Copy to:-
1. PS to ML&J/PS to Law Secretary/PS to Legislative Secretary/All Additional
Secretaries/PS to all JS&LA in the Main Sectt.
2. Sh. G. Rajagopalan, ASG, Madras High Court, Swananda Bhawan, F-3, Whispering Height,
New No, 132, St. Mary's Road Alwarpet, Chennai- 600018.
3. Shri Su. Srinivasan, Asstt. SG Madras High Court (Benches), 19/10, Pattammal Street, Raja
Annamalai Puram, Chennai-600028.
4. Sh. G. R. Swaminathan, Asstt. SG, Madras High Court (Madurai Bench), A-12-A, Pandian
Street, Alagappannnagar, Madurai-625003.
5. The Registrar, Madras High Court, Chennai (Tamil Nadu).
6. Shri C. V. Ramachandra Rao, Sr. Panel Counsel as above.
7. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
8. NIC cell, Department of Legal Affairs with the request to upload this order on the
website of this Department.
9. Guard File/Judicial Section with 5 spare copies.
Sos
—— तो
(D. Srinivas) \
Section Officer (Judicial Section)
