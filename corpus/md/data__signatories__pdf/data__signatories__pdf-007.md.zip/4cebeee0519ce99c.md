---
doc_id: "4cebeee0519ce99c"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/022018d08cea05e2072b637e7c15f0de.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "CPIOs & FAAs order dated 20.07.2015"
date: "2015-07-20"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c6cdc45d35346ac0"
---

<!-- page 1 -->

; \
i ye
Pe?
4
F.No.21(673)20141C
Government of India
Ministry of law & Justice
Department of Legal Affairs
Implementation Cell
हें Shastri Bhawan, New Delhi
Dated 20.7.2015
Office Order Mo. 12015 2
Subject: Designation of Central Public Information Officers (CPIOs) and First Appellate
‘Authorities for the purpose of RTI in respect of the Main Secretariat-regarding.
ween
In supersession of this Department's Officer Order No. 88/2014 dated 6.1.2015 issued under
the even No. and in exercise of powers conferred by sub-section (1) of Section 5 and sub-section (1)
of Section 19 of the Right to Information Act, 2005, the competent Authority designates the
following officers of Department of Legal Affairs as Central public Information Offices (CPIO’s) and
First Appellate Authorities for the subject matters mentioned against each for the purpose of Right to
Information Act, 2005.
No | Division? | Name & Address | Link Officer of | First Appellate | Link Officer of
Section of CPIO cPIO Authority First Appellate
: Authorit
a
Section Srivastava, DLA | DLA Chandra Yadav
: PhNo. 23387543 | Ph.No. 23388763 | Ph.No. PhNo.
R.No. 424-A RNo. 433-A 23387806 23071014
Ro. 419-A__| R.No. 422-A
Z, | Notary Ms. Poonam Suri, | Sh. RK. Shri G.S. Yadav, | Sh. G.C. Mishra,
Section DLA Srivastava, DLA | JS&LA JS&LA
PhNo. 23388763 | Ph.No. 23387543} Ph.No. PhNo.
Ro. 433-A R.No. 424-A 23384630 23384446
R.No. 406 B(A) | R.No. 406-B
Tmplement [Sh YK Singh, [Sh. TK. Malik, | Sh. TN. Tiwari, | Shri G.S.Yadav,
ation Cell | DLA DLA AS JS&LA
Ph.No, 23383255 | Ph.No. 23386260 | Ph.No. PhNo.
RNo. 413-D Ro. 415 C(A) | 23384204 23384630
R.No. 409-A__| R.No. 406 B(A)
ShKGiakhan | Smt. Asha Sota, | Sh. T-N. Tiwari, | Shri G.S. Yadav,
Thang, DS US, Admn.IV AS JS&LA
Ph.No. 23384706 | Ph.No. 23389127 | Ph.No. Ph.No.
RNo. 422A (A) | R.No.410D 23384204 23384630
R.No.409-A__| R.No. 406 BAY
1 । , :
‘

<!-- page 2 -->

oh घर
हि |
7 a
5 Thavice Av] Dr. RS. Shrinet, | Ms. Arti Chopra, | Shri GS.Yadav. a | G.C. Mishra,
i B,C ALA | ALA JS&LA JS&LA
Sections | Ph.No. 23386260 | Ph.No, 23381116 Ph.No. Ph.No.
RNo.415C(A) | RNo. 41S C (Ar | 23384630 23384446 |
R.No. 406 B- | R.No. 406-B
| ५)
है हम द्व के उमा छणछ | Sh. D Choudhury. | Sh. D. Sh. Suresh
Vigilance _ | Joshi, DS. US, Bhardwaj, Chandra,
Section Admn.l Ph.No, 23383051 | Additional JS&LA
Ph.No. 23384109 | R.No. 417-A Secretary Ph.No.
‘ R.No. 418 A Ph.No. 23387806
23384101 Ro. 419-A
RNo. 411-4
7-1 Ramm] Sh: K:Ginkhan | Smt. Asha Sota, | Shri G.S-Yadav, | Sh. G.C. Mishra,
Thang, DS US, Admn.IV JS&LA JS&LA
Ph.No. 23384706 | Ph.No. 23389127 | Ph.No. Ph.No.
RNo. 422 A(A)_ | R.No. 410D 23384630 23384446
: Ro. 406B- | R.No. 406-B
: Al
डक | Sh. D Choudhury, |Sh. Anil Kumar | Sh. D. ‘Sh. Suresh
us, Joshi, DS, Bhardwaj, Chandra,
Ph.No. 23383051 | Admn.I Additional JS&LA
Ro. 417-4 Ph.No. 23384109 | Secretary PhNo.
RNo. 418 A Ph.No. 23387806
23384101 Ro. 419-A
R.No. 41]-A
Admn-lV | Smt. Asha Sota, Sh. K.Ginkhan [ShRamayan — | Sh. D.
US, Admn.IV | Thang, CPIO Yadav, JS&LA | Bhardwaj,
Ph.No. 23389127 | Ph.No. 23384706 | Ph.No. Additional
RNo. 410D Ro. 422A (A) | 23071014 R.No. | Secretary
422-4 Ph.No.
23384101
R.No. 411-A
Library & | Sh. VK. Singh, | Sh. TK. Malik, | Shri G.S.Yadav, | Sh. G.C. Mishra,
Research | DLA DLA JS&LA JS&LA
Section ° | Ph.No. 23383255 | Ph,No. 23386260 | Ph.No. Ph.No.
RNo. 413-D RNo. 415 C (A) | 23384630 23384446
. R.No. 406 B-(A_| R.No. 406-8
P.G Cell | Sh. KGinkhan | Smt. Asha Sota, | Shri G.S.Yadav, | Sh. G.C. Mishra,
‘Thang, DS US, Admn.IV IS&LA JS&LA
Ph.No. 23384706 | Ph.No. 23389127 | Ph.No. PhNo.
RNo, 422A (A) | R.No.410D 23384630 23384446
1२.10. 406 B-(A_| R.No. 406-B
: 12, | Cash Sh. K.Ginkhan | Smt. Asha Sota, /Sh.Ramayan | Sh. D. -
. Section Thang, DS US, Admn.IV | Yadav, JS&LA | Bhardwaj,
Ph.No. 23384706 | Ph.No. 23389127 | Ph.No. Additional
Ro. 422A (A | R.No.410D 23071014 R.No. | Secretary
422-4 Ph.No. a
23384101
R.No, 411-4
1
a

<!-- page 3 -->

SR URINE
/ |
Pr |
|
/ ae \
/ Shri GS. Yadav. \
/ | HL ri (0.9. .
/ Shri Vijay ShN.s.Aswal, Sh. TN. Tiwart, SSeLA |
1B. Singh Meena, | AD as PhNo. \
DD PhNo. 23070744 | Ph.No. ret | |
pho. 23385383 | R.No. 4t1-D 23384204 0068) |
RNo. 435-A R.No. 409-A. Ne 40 eps
Litigation | Sh. P-K. Behera, Satish Kr. Singh. i TN. Tiwari, pao Yadav,
(HcycaT | DLA Supdi(L), A PhNo.
Cell/ Lin HC) Section | Lit(HC) sae मु न, 2984630
Litigation | Ph.No, 23383874 Ph.No. 23: 25384000 | RN 4064 a)
(Lc)
: Litigation Sh. PK. Behera, | Jiwan Ram, STN. Tiwari, | Shri G.S.Yadav,
. 6.0 DLA Supdt.(L), AS है .
Section Lit(LC) Section | DLA Ph.No. PhNo.
Ph.No. Lit(LC) Seotion | 23384204 23384630
23831110 Ph.No. RNo. 409-A Ro. 406 B-(A)
23919238
हु 0
(Asha Sota)
Under Secretary.
Tel. No. 23389127
Copy to:
“4. PSto Hon'ble Minister of Law & Justice,
2. PPS to Law Secretary,
3. AllOfficer & Sections in the Department of Legal Affairs
4, Shri B.K-Prasad, ‘Additional Government Advocate, Central Agency Section, Supreme Court
Compound, New Delhi.
5, Shri PK.Behera, Deputy Legal Adviser, Litigation (HC) Section, Room No. 444, Lawyers
Chambers, Delhi High Court, New Delhi-110003.
6, Shri P.K.Behera, Deputy Legal Adviser, Litigation (LO) Section, Tis Hezari, New Delhi.
7. Shri Niraj Kumar, ALA, Branch Sectt., 2° Floor, ‘Aayakar Bhawan Annexe, New Marine
Lines, Mumbai.
, a. Shri Jay Prakash Dubey ALA, Branch Secretariat, , 3" Floor, Middle Building, 11 Strand
Road, Kolkata-700001.
9, Shri S.Joseph Balasunder, ALA, Branch Secretariat, 3rd Floor, (Rear Wing), Shastri Bhawan
‘Annexe, 26 Haddows Road, Chennai-600006.
40. Shri R.Ganesh Voltair, DLA, Branch Secretariat, D Wing, Kendriya Sadan,
Koramangla,Bengalaru-560034.
42, Shei Rakesh Kumar, CPIO, ATFE, Janpath, New Delhi.
12. NIC Cell with the request that this OM may kindly te put up on Department of Legal Affairs website
a:
