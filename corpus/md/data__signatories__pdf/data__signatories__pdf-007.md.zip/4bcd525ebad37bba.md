---
doc_id: "4bcd525ebad37bba"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_684016f8ddbaf5.95730798.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "G.S.R 285(E) [27-03-2018] प्लास्टिक अपशिष्ट प्रबंधन (संशोधन) नियम, 2018"
date: ""
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "961d5ccda9c98d45"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. No. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)

izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 185]

ubZ fnYyh] eaxyokj] ekpZ 27] 2018@pS=k 6] 1940

No. 185]

NEW DELHI, TUESDAY, MARCH 27, 2018/CHAITRA 6, 1940

पयावरण, वन और जलवायु परवतन मंालय
अिधसूचना

नई दली, 27 माच, 2018
सा.का.िन.

के ीय सरकार, पयावरण (संरण) िनयम, 1986 के िनयम 5 के उप िनयम (4)

285(अ).
85(अ).—
(अ).—

के साथ प%ठत पयावरण (संरण) अिधिनयम, 1986 (1986 का 29) क+ धारा 6, धारा 8 और धारा 25 -ारा
.द/त शि1य2 का .योग करते 5ए, भारत के राजप9, असाधारण म: सा.का.िन. 320(अ) तारीख 18 माच, 2016
के -ारा .कािशत, अपिश<ट >लाि?टक िनयम, 2016 का, पूवABत िनयम2 के िनयम 5 के उप िनयम (3) के खंड (क)
के अधीन सूचना क+ अपेा को, लोकिहत म: अिभमुBत करने के पEचात, संशोधन करने के िलए िनFनिलिखत िनयम
बनाती है, अथात् :1.

(1)

इन िनयम2 का संि>त नाम अपिश<ट >लाि?टक .बंधन (संशोधन) िनयम, 2018
है।

(2)

2.

ये राजप9 म: इनके .काशन क+ तारीख से .वृ/त ह2गे।

अपिश<ट >लाि?टक .बंधन िनयम, 2016 िजसे इसम: इसके पEचात् उBत िनयम कहा गया है, के िनयम 3
म:,i

1822 GI/2018

खंड (क) के पEचात् िनFनिलिखत खंड अंत:?थािपत कया जाएगा :-

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

अनुकिपक उपयोग’ से कसी सामQी का उस .योजन से िभन, िजसके िलए उसक+ प%रकपना
क+ गई थी, ऐसा उपयोग अिभ.ेत है, जो इसिलए फायदा.द है, Bय2क इससे संसाधन काय कु शलता म:
‘‘(क ख) ‘

अिभवृिT होती है।’’;
(ii)

खंड (छ) के पEचात् िनFनिलिखत खंड अंत:?थािपत कया जाएगा अथात् :-

ऊजा क+ पुन: .ािW’ से अपिश<ट से ऊजा क+ पुन: .ािW अिभ.ेत है, जो क िविभन .XयाY,
िजनके अंतगत दहन, गैसीयकरण, उ/ताप िवZछेदन (पाइरोलाइजेशन), िनवात उपचारण (एनेरोिबक
डाइजेशन) और ख/ते से गैस क+ पुन: .ािW भी ह[, के मा\यम से अपिश<ट माल का .योग यो]य उ<मा,
िव^ुत या _धन म: संप%रवतन कया जाना है;’’।
‘‘(छ क)’’ ‘

3.

उBत िनयम2 के िनयम 9 के , उप िनयम (3) म: ‘‘पुन:चX+करण न क+ जा सकने यो]य ब5?तरीय पैकेbजंग
का िविनमाण एवं उपयोग, यद कोई हो’’ के ?थान पर, ब5सतहीय >लाि?टक, जो गैर पुन:चXणीय हो या
िजससे पुन: ऊजा .ा>त न क+ जा सके , या िजसका कोई अनुकिपक उपयोग न हो’’ शcद रखे जाएंगे।

4.

उBत िनयम2 के िनयम 13 के उप िनयम (2) के ?थान पर िनFनिलिखत उप िनयम रखा जाएगा, अथात :‘‘(2

) ./येक उ/पादक या dाeड – ?वामी रिज?fीकरण या रिज?fीकरण के नवीकरण के .योजन

के िलए .gप 1 म:,(i)

(ii)

संबT राhय .दूषण िनयं9ण बोड या संघ राhय े9 क+ .दूषण िनयं9ण सिमित यद एक या दो
राhय2 या संघ राhय े92 म: Xयाशील है; या
के ीय .दूषण िनयं9ण बोड, यद दो से अिधक राhय2 या संघ राhय े92 म: Xयाशील है, को
आवेदन करे गा।

5.

उBत िनयम2 के िनयम 15 का लोप कया जायेगा।
[फा.सं. 17-2/2001-एचएसएमडी]

%रतेश कु मार bसंह, संयुBत सिचव
टपण : मूल िनयम, भारत के राजप9, असाधारण, भाग II, खंड 3, उप खंड (i) म: संयांक सा.का.िन. 320(अ)

तारीख 18 माच, 2016 -ारा .कािशत कये गये थे।

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(i)º

Hkkjr dk jkti=k % vlk/kj.k

3

MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 27th March, 2018
G.S.R. 285(E).—In exercise of powers confirmed by sections 6, 8 and 25 of the Environment (Protection)
Act, 1986 (29 of 1986), read with sub-rule (4) of rule 5 of the Environment (Protection) Rules, 1986, the Central
Government hereby makes the following rules to amend the Plastic Waste Management Rules, 2016, published in the
Gazette of India, Extraordinary, vide number G.S.R. 320(E), dated the 18th March, 2016, after having dispensed with
the requirement of notice under clause (a) of sub-rule (3) of rule 5 of the aforesaid rules in public interest, namely :1.

2.

(1)

These rules may be called Plastic Waste Management (Amendment) Rules, 2018.

(2)

They shall come into force on the date of their publication in the Official Gazette.

In the Plastic Waste Management Rules, 2016 (hereinafter referred to as the said rules), in rule 3,i.

after clause (a), the following clause shall be inserted, namely:-

“(ab) ‘alternate use’ means use of a material for a purpose other than for which it was conceived, which is
beneficial because it promotes resource efficiency;”;
ii.

after clause (g), the following clause shall be inserted, namely:-

“(ga) ‘energy recovery’ means energy recovery from waste that is conversion of waste material into usable heat,
electricity or fuel through a variety of processes including combustion, gasification, pyrolisation, anaerobic
digestion and land fill gas recovery;”.
3.

In the said rules, in rule 9, in sub-rule (3), for the words “non-recyclable multilayered plastic if any”, the words
“multi-layered plastic which is non-recyclable or non-energy recoverable or with no alternate use” shall be
substituted.

4.

In the said rules, in rule 13, for the sub-rule (2) the following sub-rule shall be substituted, namely: “(2)
Every producer or brand-owner shall, for the purpose of registration or renewal of registration,
make an application, in Form 1 to,(i) the concerned State Pollution Control Board or Pollution Control Committee of the Union territory, if
operating in one or two states or Union territories; or
(ii) the Central Pollution Control Board, if operating in more than two States or Union Territories.”.

5.

In the said rules, the rule 15 shall be omitted.
[F. No. 17-2/2001-HSMD]
RITESH KUMAR SINGH, Jt. Secy.

Note : The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i), vide
number GSR 320(E), dated the 18th March, 2016.

RAKESH
SUKUL
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

Digitally signed by
RAKESH SUKUL
Date: 2018.03.31 12:47:34
+05'30'
