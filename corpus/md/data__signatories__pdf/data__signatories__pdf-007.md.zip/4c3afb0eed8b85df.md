---
doc_id: "4c3afb0eed8b85df"
source_url: "https://www.dot.gov.in/static/uploads/2025/12/2f1e74524e5245245c7250f7804c272f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer & Posting of officers in the grade of JAG of ITS Group A - reg"
date: "2025-12-25"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ceadf7ccbee90182"
---

<!-- page 1 -->

12-3/2025-STG-I

I/3317832/2025

No. 12-3/2025-STG-I(i)
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi
*****
Dated the 22 nd September, 2025
OFFICE ORDER
Subject: - Transfer & Posting of oﬃcers in grade of SAG of ITS Group ‘A’
- reg.
Approval of the competent authority is hereby conveyed for transfer &
posting of the following oﬃcers in the grade of SAG of ITS Group ‘A’ with
immediate effect:
Sl.
No

Staff
No

Name (Sh/Shri/Ms.) Place of Posting Posting on
Transfer

1.

20385 D. Bhaskara Rao

2.
3.

20805 Mohd. Mahmood Ur
Rehman
20293 Rajasekhar K.

4.

20841 Y Sreenivasa Rao

5.

20978 P S
Subramanyam
20943 Kuldeep Kumar
Saharawat

6.

WB LSA
(at Sri Vijaya
Puram)
WB LSA
(at Sikkim)
NCA-T

AP LSA

Under Posting

J&K LSA

DoT HQs

AP LSA
(Own Cost)
Under Transfer to WB LSA
Kerala LSA
(at Sri Vijaya
Puram)
Under Posting
BSNL

2.
The oﬃcers at Sr. no. 5 and 6 have reported to DoT HQs on 21.08.2025
(F/N) and 01.09.2025 (F/N) respectively. The period between their date of
reporting to DoT HQs and date of issue of this order shall be treated as
compulsory wait and Pay & allowances for the said period may be paid by the
BSNL and J& K LSA respectively.
3.
The charge report may be furnished to all concerned. Hindi version will
follow.

<!-- page 2 -->

12-3/2025-STG-I

I/3317832/2025

3.

This issues with the approval of the competent authority.

Copy to:

(Bijender Singh)
Under Secretary to the Govt. of India
Tele 011-2303 6282
Email: bijender.s83@gov.in

1. PS to Hon'ble MOC;
2. PS to Hon'ble MOSC;
3. PPS to Secretary (T);
4. Member(S) / Member(T) / Member(F)/ DG (T);
5. Additional Secretary (T)/ Advisor(O) / Advisor(T);
6. CVO, DoT (HQs.);
7. CMD, BSNL CO./ MTNL CO.;
8. DDG(C&A)/DDG(Accounts)/DDG(IT)/DDG (Pers)/ DDG (Estt.), DoT

HQs;
9. Admin. I-IV/Cash/Pension/Library/G-I/G-II/PFP/PHP/RTI/Vig.I Sec., DoT
(HQs);
10. Pay Bill Section, DoT (HQs);
11. ADG (APAR)/ ADG (Staff)/ US(SNG)/ AO(SGT), DoT (HQs);
12. The officers concerned;
13. Order Bundle /PA to US (SGT) – for uploading on the website of DoT.
