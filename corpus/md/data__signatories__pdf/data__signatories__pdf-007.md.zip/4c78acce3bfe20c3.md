---
doc_id: "4c78acce3bfe20c3"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/757f1530bc7f4efb141ee3dd53b5ea3b.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of Unified License issued by AS Wing as on 31-03-2023"
date: "2023-05-04"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "55fc2a9ffe443603"
---

<!-- page 1 -->

List of UL Licences as on 31.03.2023
S
Name of Company
NO

1 Vodafone Idea Limited

License number

20-363/2012 AS-I/vol-II

2 Reliance Jio Infocomm Ltd

20-401/2013 AS-I

3 Sify Technologies Limited

20-408/2013 AS-I

4
Hughes Communications India Limited

20-413/2013 AS-I

Date of grant
Authorisation detail
of Unified
Service
Service Area
Licence
Access Service
Assam
Access Service
West Bengal
Access Service
Kolkata
Access Service
North East
Access Service
Tamil Nadu (incl Chennai)
Access Service
J&K
Access Service
Orissa
Access Service
Maharashtra
Access Service
Gujarat
Access Service
Andhra Pradesh
Access
Service
Madhya Pradesh
11-10-2013
Access Service
Kerala
Access Service
Haryana
Access Service
UP (West)
Access Service
Punjab
Access Service
Karnataka
Access Service
Delhi
Access Service
Bihar
Access Service
Himachal Pradesh
Access Service
Mumbai
Access Service
Rajasthan
Access Service
UP(East)
Access Service
All Circles
NLD
National Area
ILD
National Area
VSAT
National Area
21-10-2013
PMRTS
National Area
INSAT MSS-R
National Area
ISP-"A"
National Area
Resale IPLC
National Area
ISP Category-A
National Area
27.06.2014
NLD Service
National Area
ILD Service
National Area
CUG VSAT
National Area
01.08.2014

Date of
Date of
signing of
Authorisation
UL/AA

11-10-2013

12.12.2015
12.12.2015
19.12.2015
15.12.2015
12.12.2015
12.12.2015
12.12.2015
04.04.2016
04.04.2016
23.05.2018
23.05.2018
23.05.2018
23.05.2018
23.05.2018
23.05.2018

11-10-2013

22.07.2015

23.05.2018

21-10-2013

21-10-2013

27.06.2014

27.06.2014

01.08.2014

01.08.2014

<!-- page 2 -->

Hughes Communications India Limited

5 Sprint Telecom India Private Limited

20-413/2013 AS-I

01.08.2014

20-419/2014 AS-I

29.08.2014

20-430/2014 AS-I/39

16.10.2014

6 Bharti Airtel Limited
20-430/2014-AS-I
(additional
authorisation)

7 Bharti Hexacom Limited

8 Reliance Telecom Limited

20-469/2015 AS-I

20-473/2015 AS-I

03.03.2014

24.07.2015

17.08.2015

9 Andhra Pradesh State FiberNet Limited

20-491/2015 AS-I

08.03.2016

10 RailTel Corporation of India Limited

20-517/2016 AS-I

18.10.2016

20-494/2015 AS-I

NLD
ISP-A
NLD
ILD
ISP Category-A
Access Service
Access Service
ISP-"A"
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
NLD
ILD
Access Service
Access Service
Access Service
Access Service

National Area
National Area
National Area
National Area
National Area
Delhi
Kolkata
National Area
Andhra Pradesh
Himachal Pradesh
Punjab
Karnataka
Tamil Nadu
Gujarat
Haryana
Madhya Pradesh
Maharashtra
Mumbai
Uttar Pradesh (West)
Kerala
National Area
National Area
Rajasthan
North East
Himachal Pradesh
West Bengal

29.11.2021
14.03.2022
22.04.2016
12.12.2015
12.12.2015
12.12.2015

Access Service

Orissa

12.12.2015

17.08.2015

Access Service

Assam

12.12.2015

17.08.2015

Access Service

Madhya Pradesh

12.12.2015

17.08.2015

Access Service

Bihar

12.12.2015

17.08.2015

North East
Andhra Pradesh
National Area
Andhra Pradesh
National Area
National Area
Andhra Pradesh

12.12.2015

17.08.2015

08.03.2016

08.03.2016

18.10.2016

18.10.2016

02.11.2016

02.11.2016

Access Service
Access Service
NLD
ISP-B
ILD
ISP-A
Access Service

02.09.2014
30.06.2015

02.09.2014
21.07.2015

29.08.2014

29.08.2014

29.11.2014
30.11.2014
03.03.2014
12.12.2015
12.12.2015
12.12.2015
15.02.2016

16.10.2014

24.07.2015
24.08.2021

28.09.2021

24.07.2015
17.08.2015
17.08.2015

<!-- page 3 -->

Access Service
Access Service
Access Service
Access Service

20-494/2015-AS-I
(additional Authorisation)
11 Tata Teleservices Ltd

02.11.2016

12 Tata Teleservices (Maharashtra) Ltd

20-495/2015 AS-I

02.11.2016

13 Smartx Services Limited

20-529/2016 AS-I

27.12.2016

14 Ishan Netsol Pvt Ltd
Bharti Digital Networks Pvt Ltd (OLD
15
name-Tikona Digital Networks Pvt Ltd)

821-22/2013-DS

22.06.2015

20-551/2017 AS-I

25.04.2017

16 Power Grid Corporation Of India Limited

20-532/2016 AS-I

02.05.2017

17 Reliance Communications Limited
18 Quadrent Televerntures Limited

20-550/2017 AS-I
821-125/2014-DS

31.07.2017
06.01.2015

19 V-Con Mobile & Infra Private Ltd

DS-11/250/2018-DS-III

03.12.2018

20 Lightstorm Telecom Connectivity Pvt Ltd

20-1212/2020-AS-I

28.08.2020

21

Assam Electronics Development
Corporation Ltd.

22 Bharat Sanchar Nigam Limited

Delhi
Gujarat
Karnataka
Tamil Nadu

20-579/2018-AS-I
20-579/2018-AS-I
(additional
authorisation)

30.12.2017

20-1206/2020-AS-I

29.02.2020

23 Mahanagar Telephone Nigam Ltd MTNL 821-43/2013-DS
(additional

07.02.2019

Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
ISP-A
NLD
ISP-A
NLD
Access Service
ISP-A
NLD
ISP-A
Access Service
Access Service
Access Service
NLD
ISP 'A'
NLD
ILD

Delhi
Gujarat
Karnataka
Tamil Nadu
Mumbai
Maharashtra
National Area
National Area
National Area
National Area
Rajasthan
National Area
National Area
National Area
Gujarat
Punjab
Punjab
National Area
National Area
National Area
National Area

ISP Category-A
NLD

National Area

ILD
Access Service
NLD Service
ILD Service
PMRTS Service
VSAT CUG Service
INSAT MSS-R Service
Access Service

National Area
National Area
All Circles
National Area
National Area
National Area
National Area
National Area
Delhi

11.03.2021

11.03.2021

02.11.2016

02.11.2016

27.12.2016

27.12.2016

14.02.2017

14.02.2017

25.04.2017

25.04.2017

02.05.2017

02.05.2017

30.09.2017
30.09.2017
22.01.2019
19.01.2021

29.09.2017
22.01.2019
19.01.2021

28.08.2020

28.08.2020

30.12.2017
29.07.2021

12.10.2020
29.07.2021

29.02.2020

10.12.2020

06.04.2019

28.07.2021

<!-- page 4 -->

24 Inviolable Technology Pvt. Ltd.
25

Oneweb India Communications Pvt Ltd

26 Ring Central India Pvt. LTD.

(additional
Authorisation)
20-1249/2021-AS-I

24.08.2021

20-1254/2021-AS-I

24.08.2021

20-1244/2021-AS-I

31.08.2021

DS-11/243/2019-DS-III
(Additional
authorisation)
27 Yotta Network Services Pvt. Ltd.
16.10.2021
10-77/2015-CS-III
(Additional
authorisation)
28 NTT Communications India Network Services
Pvt. Ltd.
02.12.2015
821-78/2014-DS
29 Tata Communications Limited
24.01.2014
(Additional
authorisation)
30 Lumen Communications India Private
20-1255/2021-AS-I
28.01.2022
Limited (Erstwhile Centurylink
Communications India Pvt. Ltd. )
31 Jio Satellite Communications Ltd.
32 Powergrid Teleservices Limited

20-1286/2021-AS-I
20-1302/2022-AS-I

09.03.2022
11.05.2022

33 OneOTT Intertainment Limited

821-52/2013-DS
(additional auth.)
20-1307/2022-AS-I

27.05.2014

34 Telangana Fiber Grid Corporation
Limited
35 Extreme Infocom Pvt. Ltd.
36 M/s Nelco Limited

37 Adani Data Networks Limited

Access Service

Mumbai

Access Service
NLD
GMPCS
Access Service

Mumbai Metro Area
National Area
National Area
Mumbai Metro Area

Access Service

Karnataka

NLD

National Area

ILD

National Area

NLD

24.08.2021
24.08.2021
21.04.2022

24.08.2021
24.08.2021
21.04.2022

31.08.2021

31.08.2021

National Area

29.11.2021

29.11.2021

ISP-A
NLD
ILD

National Area
National Area
National Area

29.11.2021
01.01.2022
01.04.2022
28.01.2022

29.11.2021
08.12.2021
08.12.2021
28.01.2022

ISP - A
ILD
NLD
GMPCS
NLD
ILD
ISP-A

National Area
National Area
National Area
National Area
National Area
National Area
National Area
National Area

09.03.2022
11.10.2022
11.05.2022
11.05.2022
11.05.2022

09.03.2022
11.10.2022
11.05.2022
11.05.2022
11.05.2022

23.05.2022

23.05.2022

10.06.2022
17.06.2022

10.06.2022
17.06.2022

NLD

National Area
National Area

26.07.2022
26.08.2022

26.07.2022
26.08.2022

ILD
ISP-B
Access Service

National Area
Gujarat
Andhra Pradesh

10.10.2022

10.10.2022

NLD
10.06.2022

20-1320/2022-AS-I

17.06.2022

10-29/2021- CS-III
(additional auth.)

01.11.2021

20-1327/2022-AS-I

26.08.2022

Andhra Pradesh
Access Service
NLD
ISP-A
VSAT
ISP Category ‘A’

National Area
National Area
National Area

<!-- page 5 -->

38 Webex Communications (India) Pvt. Ltd. 20-1306/2022-AS-I
39 ZVC India Private Limited
20-1309/2022-AS-I
40 Web Werks Internet Services Pvt. Ltd.
41 P2P Innovations Pvt. Ltd.
Tejays Dynamic Limited
42

09.09.2022
18.11.2022

DS-11/527/2021-DS-III 14.06.2022
(additional auth.)
20-1386/2022-AS-I
12.01.2023
821-45/2013-DS
(additional
authorisation)

06.10.2016

Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
NLD
NLD
ISP Category ‘C’
NLD

Gujarat
Karntaka
Rajasthan
Tamil Nadu
Mumbai
All Circles
Mumbai Metro
Andhra Pradesh
National Area
National Area
Ghaziabad SSA
National Area

09.09.2022
18.11.2022

09.09.2022
18.11.2022

04.01.2023

04.01.2023

12.01.2023

12.01.2023

23.03.2023

23.03.2023
