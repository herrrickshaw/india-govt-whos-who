---
doc_id: "49fb5dc7ffb87dba"
source_url: "https://mohua.gov.in/static/uploads/2026/10/3d9837715108d19ff0d62f0bddbc8145.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Amendment, Impacted Rule : Rule No. 15, 17, 18, 44 and 73 of the CGGPRA Rules, 2017, Amendment, Change in Substance, Applicable Section/Rule : Rule No. 15, 17, 18, 44 and 73 of the CGGPRA Rules, 2017, Date of Applicability : 15/10/2026, Impact : Acti"
date: "2026-10-15"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "ebb126a7b813b122"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.-

REGD. No. D. L.-

सी.जी.-डी.एल.-अ.-15102026-277178
xxxGIDHxxx
CG-DL-E-15102026-277178
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं.

]

No.

]

नई ददल्ली, बृहस्ट्पजतवार, अक्तूबर , 202 /आज‍वन , 194
NEW DELHI, THURSDAY, OCTOBER
ASVINA

आवासन और िहरी कार्य मंत्रालर्
(संपदा जनदेिालर्)
अजधसूचना
नई ददल्ली,
सा.का.जन.

अक्तूबर,

(अ).— राष्ट्रपजत, संजवधान के अनुच्छे द

कें द्रीर् सरकार साधारण पूल आवाजसक वास जनर्म

के परं तुक द्वारा प्रदत्त िजिर्ों का प्रर्ोग करते हुए,

का और संिोधन करने हेतु जनम्नजलजखत जनर्म बनाते हैं,

अर्ायत:् इन जनर्मों का संजिप्त नाम कें द्रीर् सरकार साधारण पूल आवाजसक वास (संिोधन) जनर्म

है।

र्े रािपत्र में इनके प्रकािन की तारीख से प्रवृत्त होंगे।
2. कें द्रीर् सरकार साधारण पूल आवाजसक वास जनर्म 2017 में,
(क) जनर्म

में उप-जनर्म (

के स्ट्र्ान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अर्ायत्:-

वास के आवंटन का प्रस्ट्ताव आवंटन प्राप्तकताय द्वारा स्ट्वचाजलत प्रणाली र्ा मैनअ
ु ल आवंटन प्रणाली के
माध्र्म से र्र्ाजस्ट्र्जत, वास के आवंटन की तारीख से आठ ददनों के भीतर स्ट्वीकार दकर्ा िाएगा, ऐसा न

GI/202

<!-- page 2 -->

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC

i)]

करने पर आवंटन प्राप्तकताय को अगले दो ददनों के भीतर आवंटन स्ट्वीकार करने के जलए एक अनुस्ट्मारक भेिा
िाएगा।";
(ख) जनर्म

में उप-जनर्म (

के स्ट्र्ान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अर्ायत:् -

“(1) र्दद कोई आवंटटती दकसी आवासीर् वास के आवंटन की तारीख से दस ददनों के भीतर उस वास का
आवंटन स्ट्वीकार करने में जवफल रहता है, र्ा प्राजधकरण पत्र प्राप्त होने की तारीख से पांच कार्य ददवसों के
भीतर उस वास पर कब्िा लेने में जवफल रहता है, तो आवंटन रद्द कर ददर्ा िाएगा और वह उस प्रकार के
वास के जलए एक महीने का साधारण अनुज्ञजप्त िुल्क संदार् करने के अधीन आवंटन स्ट्वीकार न दकए िाने की
तारीख से तीन महीने की अवजध के दौरान, दकसी भी अन्र् आवासीर् वास के जलए आवेदन करने से वंजचत हो
िाएगा।";
(ग) जनर्म

में खंड (क) में "आठ" िब्द के स्ट्र्ान पर "दस" िब्द रखा िाएगा।

(घ) जनर्म

में, उप-जनर्म (

में, "आठ" िब्द के स्ट्र्ान पर "दस" िब्द रखा िाएगा; और

(ङ) जनर्म

में उप-जनर्म (

के स्ट्र्ान पर जनम्नजलजखत उप-जनर्म रखा िाएगा, अर्ायत्:-

"( ) िहां वास र्ा वैकजल्पक वास का आवंटन स्ट्वीकार कर जलर्ा गर्ा है, वहां अनुज्ञजप्त िुल्क की देर्ता वास के आवंटन की
तारीख के इकसठवें ददन से र्ा वास पर भौजतक कब्िे की तारीख से िुरू होगी, िो भी पहले हो।"

[फा. सं. 12035/4/2026/नीजत.II]
रजव कु मार अरोडा, संर्ुि सजचव

टटप्पण: कें द्रीर् सरकार साधारण पूल आवासीर् वास जनर्म

भारत के रािपत्र, असाधारण, भाग , खंड

उप-

खंड (i) में अजधसूचना संख्र्ा सा.का.जन.

(अ), तारीख

िून

द्वारा प्रकाजित दकए गए र्े और

अजधसूचना संख्र्ा सा.का.जन.

फरवरी

सा.का.जन.

(अ), तारीख

सा.का.जन.

(अ), तारीख

सा.का.जन.

(अ), तारीख

(अ), तारीख
िुलाई
फरवरी

सा.का.जन.

(अ), तारीख

द्वारा पश्चातवती संिोजधत दकए गए र्े।

जसतंबर

नवंबर
और

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण
MINISTRY OF HOUSING AND URBAN AFFAIRS
(Directorate Of Estates)
NOTIFICATION
New Delhi, the

th October

G.S.R. 88 (E).— In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules to further amend the Central Government General Pool Residential
Accommodation Rules, 2017, namely:1.
(1) These rules may be called the Central Government General Pool Residential Accommodation
(Amendment) Rules, 2026.
(2) They shall come into force on the date of their publication in the Official Gazette.
2.

In the Central Government General Pool Residential Accommodation Rules, 2017,(a) in rule 15, for sub-rule(1), the following sub-rule shall be substituted, namely:“ An offer of allotment of an accommodation shall be accepted by the allottee within eight days from
the date of allotment of the accommodation through automated system or by manual system of allotment,
as the case may be, failing which a reminder shall be sent to allottee to accept the allotment within
another two days.”;
(b) in rule 17, for sub-rule (1), the following sub-rule shall be substituted, namely:“
If any allottee fails to accept the allotment of a residential accommodation within ten
days from the date of allotment of the said accommodation, or fails to take possession of that
accommodation within five working days from the date of receipt of the letter of authorisation, the
allotment shall be cancelled and he shall be debarred to apply for accommodation for a period of three
months from the date of non-acceptance of allotment subject to payment of normal licence fee of one
month for that type of accommodation ”;
c in rule 8 in clause a for the word “eight” the word “ten” shall be substituted;
(d) in rule 44, in sub-rule

for the word “eight” the word “ten” shall be substituted; and

(e) in rule 73, for sub-rule (1), the following sub-rule shall be substituted, namely:“
Where allotment of accommodation or alternative accommodation has been accepted, the liability for
licence fee shall commence on sixty first day from the date of allotment of the accommodation or from the date of
physical occupation of accommodation whichever is earlier ”

[F. No. 12035/4/2026/Pol.II]
RAVI KUMAR ARORA, Jt. Secy.
Note: The Central Government General Pool Residential Accommodation Rules, 2017 were published in the Gazette
of India, Extraordinary, Part II, Section 3,Sub-section (i) vide notification number G.S.R. 598(E), dated the
th
June, 2017 and subsequently amended vide notification number G.S.R 99(E), dated the 4 th February, 2019,
G.S.R 883(E), dated the 27th November, 2019, G.S.R 489(E), dated the 30 th July, 2020, G.S.R.593(E) dated the
th
September, 2020 and G.S.R.114(E), dated the 17 th February, 2021.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhiand Published by the Controller of Publications, DelhiSARVESH KUMAR
SRIVASTAVA

Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2026.10.15 19:13:51 +05'30'
