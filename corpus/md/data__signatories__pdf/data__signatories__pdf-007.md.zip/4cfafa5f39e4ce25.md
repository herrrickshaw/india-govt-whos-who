---
doc_id: "4cfafa5f39e4ce25"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/f5e00b30612004ac3a993a6f93d68d95.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Report of Committee constituted in compliance to the direction of Hon'ble High Court, Allahabad, Lucknow Benchon issues relating to Electromagnetic Field (EMF) radiation-Acceptance and decisions"
date: "2022-12-23"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4f754e8e1bc93536"
---

<!-- page 1 -->

Govt. of India
Ministry of Communications & IT
Department of Telecommunications
713, Sanchar Bhawan, 20-Ashoka Road, New Delhi-110001.
(Carrier Services Cell)

No. 17-63/2011-CS-lll

Dated: 27.02.2014

OFFICE MEMORANDUM
Subject: Report of the Committee constituted in compliance to the directions of
the Hon'ble High Court, Allahabad, Lucknow Bench on issues relating ·to
Electromagnetic Field (EMF) radiation ---Acceptance and decisions regarding:

~.

=

0

-

.,--_

In compliance to the directions of Hon'ble High Court, Allahabad, Lucknow
Bench vide its order dated 1O'h January, 2012, the Committee was setup by the
Government which has submitted its Report on 17.01.2014 on issues relating to EMF
radiations from cell phone towers and mobile handsets. In consideration to the Report of
the Committee, the following decisions are hereby conveyed:­

1) The present prescribed norms for the EMF radiation limits are as follows:
a)

Limits/levels for antennae (Base Station) EMF Emissions for general
public exposure :
Frequency
Range

E-Field Strength
(Volt/Meter (Vim))

H-Field
Strength
(Amp/Meter (Nm))

400MHz to
2000MHz
2GHz
to
300GHz

0.4341 y,

0.00111 y,

Power
Density
(Watt/Sq.Meter
(W/Sq.m))
f/2000

19.29

0.05

1
(f =frequency in MHz)

The above prescribed limits for EMF radiations from Base Station in India
are one-tenth (1/10'h) of internationally prescribed limits (ICNIRP).

Page 1of4

'
(I_)

<!-- page 2 -->

b)

For Mobile Phones:
Specific Absorption Rate (SAR) levels for mobile handsets adopted in
India are 1.6 Watt/Kg averaged over a mass of 1gram of human tissue.

The Department of Telecom has already prescribed stricter precautionary limits
for EMF radiation from mobile tower as well as from mobile handset/phones
applicable as on date.
After due consideration of the human health concerns on account of EMF
radiation recently being raised in public and the Report of the Committee, it has
been decided that the present prescribed precautionary EMF safe exposure
limits are adequate and need no further change at this stage.

2) Department of Telecom has already taken adequate steps in regard to granting of
permission for siting of mobile towers in its recent guidelines to State governments
and Telecom Enforcement, Resource & Monitoring (TERM) cells in different licence"­
service areas effective from 01-08-2013. In order to make the deterrence stronger,
the penalty for violation of prescribed stricter EMF norms from BTS tower by telecom
service providers has been increased from Rs. 5 Lakhs to Rs. 10 Lakhs per BTS, per
incidence per operator w.e.f. 20 1h November, 2013.
In order to ensure compliance to the prescribed stricter precautionary norms of EMF
from BTS tower, the extensive audit of comprehensive self-certificates and sites for
compliance to EMF radiations safe limits being submitted by telecom service
providers shall be carried out by TERM Cells of DoT for the purpose of limiting the
EMF radiation exposure and keeping general public areas in the vicinity of towers
safe, as per the procedure prescribed from time to time in their respective License
Service Areas.

3) The Department of Science and Technology and Indian Council of Medical Research
(ICMR) shall carry out I facilitate extensive studies, on the Indian conditions with
special focus on prolonged use of mobile phone, to conclusively determine sensitivity
of EMF Radiation I possible health hazard risk of EMF radiation, which at present is
not proven. These Indian specific scientific studies should aim at generating
scientifically credible data and evidences by involving Ministry of Science and
Technology, ICMR, Ministry of Environment & Forest, DoT and other relevant
organisation. The Government of India shall make available funds to ensure
Page 2 of4

f /

,, y

(I I)

<!-- page 3 -->

extensive long term/short term research and studies on possible health effects of
EMF radiation on life (Human, Living organism, Flora & Fauna & Environment).

4) Concerned departments of Government like Department of Telecom, Health,
Environment etc. shall step up efforts to spread public awareness on EMF and above
precautions regarding mobile phones (Handsets) to allay undue apprehensions in
regard to possible health effects of EMF radiation largely caused due to
misinformation being peddled by certain sections in public. This can be done through
print media/electronic media and other communications channels and tools along
with conducting market research I survey, workshops and seminars etc.

5) Annual discussion, meetings/seminars shall be conducted by the Government by
inviting experts from various academic and research institutions for continual
evaluation of scientific evidence published worldwide with an aim to monitor the
progress in research on the effects of EMF radiation.

=

<

-

-:-.

6) In order to get latest updates on EMF radiation related issues, DoT will actively
participate in the deliberations of various International standards bodies, including
WHO, involved in the study of EMF radiation.

7) Department of Telecom will create national EMF web portal to provide public access
to the status of compliance, of the prescribed EMF norms, of all BTSs/ mobile towers
in the country and related relevant information.
This issues with the approval of MOC&IT.

Copy to:
I)

11)

~
IV)
V)
VI)
VII)

PS to Hon'ble MOC&IT
PS to Hon. MOS (C&IT)-D
PS to Hon. MOS (C&IT)-P
PPS to Secretary (T), DoT
PSs to Member (T)/Member (F)/ Member (S)
PS to Addi. Secy.
Advisor (Technology)
Page 3 of 4

(iilJ

<!-- page 4 -->

VIII)

Sr.DOG (TERM)/Sr. DOG (TEC)/ DOG (AS-I)/ JS(A)/ DOG (CS)/ DOG (PG)/
Wireless Adviser, WPC, DoT for taking necessary action.

Copy for action as appropriate to:
I)
Secretary, Ministry of Environment & Forests
II)
Secretary, Department of Science & Technology
Ill)
Secretary, Department of Health & Family Welfare
IV)·
Diredor General, Indian Council of Medical Research

'

Page 4 of4

•

UUJ
