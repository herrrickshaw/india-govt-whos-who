---
doc_id: "4a8cebfcb5b87e60"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_68d4f51706a293.04721553.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Offer of appointment - Shri Amit Kumar, IFS (BH:2008) appointment to the post of DIGF, Regional Office, MoEFCC, Lucknow on deputation basis under CSS-MoEFCC, offer dated 25-09-2025"
date: ""
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a90c69fb9e0cbd49"
---

<!-- page 1 -->

BY SPEED POST
Computer No: 253223
File No: 12026/05/2024-IFS-|
: Government of India
__ Ministry of Environment, Forest and Climate Change

Prithvi Wing, 6th Floor,

Indira Paryavaran Bhawan,

Jor Bagh Road, New Delhi - 110 003.
me September, 2025. |
To ।
The Director |
Indira Gandhi National Forest Academy (IGNFA) |
New Forest, Dehradun - 248006 - |
Subject: Appointment of Shri Amit Kumar, IFS (BH:2008) to the post of DIGF, Regional
Office, MoEFCC, Lucknow on deputation basis under the Central Staffing Scheme of |
Ministry of Environment, Forest and Climate Change (CSS-MoEFCC) -regarding i
|
Sir, |
| am directed to inform that with the approval of the competent authority, Shri i
Amit Kumar, IFS(BH:2008) has been selected for appointment to the post of DIGF, |
Regional Office, MoEFCC, Lucknow on tenure deputation basis under the Central |
Staffing Scheme of this Ministry on the following terms and conditions:
i
() He will draw pay as per the scale allowed by the Cadre Controlling Authority |
plus allowances as applicable to that grade. i
(ii) The central deputation tenure of the officer will be up to 31.01.2026 from the ।
date of joining to the post. |
(iii) The headquarters of the post will be at Lucknow, however the services of the |
officer can be utilized anywhere in India. |

(iv) Other terms and conditions will be the same as applicable to the other

officers of his grade on deputation to the Central Government and as per CSS-

MoEF&CC.
2. The IGNFA, Dehradun is, therefore, requested to relieve the officer with the I
direction to take up his new assignment. i
Yours faithfully |
Sh
A

(Prem (QE |
Under Secretary to the Government of India |
011-20819192 |
Copy to: |
1. PS to Hon’ble Minister, Environment, Forest and Climate Change. i
2. PS to Hon’ble Minister of State, Environment, Forest and Climate Change. |
3. PPSs to Secretary (EF&CC)/ DGF&SS/ ADGF (WL)/ ADGF (FC)/ ADGF (NTCA)/ |
CEO (CAMPA) |
4. The Chief Secretary, Government of Bihar, Patna.
5. The Principal Secretary (Forests), Government of Bihar, Patna. |
|

<!-- page 2 -->

6. PCCF & HoFF, Government of Bihar, Patna.
7. DDGF, Regional Office, MoEFCC, Lucknow.
8. Shri Amit Kumar, IFS (BH:2008), Additional Professor, IGNFA, Dehradun.
9. NIC and IT Cells for uploading on the website
10. Guard file/ Spare copies.
|
|
|
|
|
|
|
|
॥
. |
|
|
|
|
i
|
|
|
. |
|
|
I
