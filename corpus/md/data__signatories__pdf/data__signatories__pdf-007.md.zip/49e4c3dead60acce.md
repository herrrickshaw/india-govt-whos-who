---
doc_id: "49e4c3dead60acce"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/c9478f285504814594d2ee84a2e3e550.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Voluntary retirement from service under Rule 43 of the CCS Pension Rules, 2021- Case of Sh. Sunil Kumar, Staff No. 20031, presently CGM, Haryana Telecom Circle, BSNL-reg."
date: "2025-03-21"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c15875d02f7e6f36"
---

<!-- page 1 -->

16-4/2025-STG-I

I/3261245/2025

No. 16-4/2025-STG-I
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi
*****
Dated the 21 March, 2025
OFFICE ORDER
Subject: Voluntary retirement from service under Rule 43 of the CCS (Pension)
Rules, 2021- Case of Sh. Sunil Kumar [Staff No. 20031], presently CGM, Haryana
Telecom Circle, BSNL-reg.
The President is pleased to permit Sh. Sunil Kumar [Staﬀ No. 20031], an
ITS oﬃcer of 1989 Batch, presently posted as CGM, Haryana Telecom Circle,
BSNL to retire Voluntarily from Government Service under Rule 43 of CCS
(Pension) Rules, 2021 with effect from 07.04.2025(A/N).
2.
No vigilance case/ disciplinary case is pending against Sh. Sunil Kumar as
per the records available in Department of Telecommunications.
3.

The charge relinquish report may be furnished to the all concerned.

(Bijender Singh)
Under Secretary to the Government of India
Tele 011-2303 6282
Email: bijender.s83@gov.in
Copy to:
1. PPS to Secretary (T);
2. Member(S) / Member(T) / Member(F)/ DG (T);
3. Additional Secretary (T)/ Advisor(O) / Advisor(T);
4. CMD, BSNL CO/MTNL CO.;
5. CVO, DoT (HQs.);
6. DDG(C&A)/DDG(Accounts)/DDG(IT)/DDG (Pers)/ DDG (Estt), DoT (HQs);
7. Admin I-IV/ Cash/ Pension/ Library/ G-I/ G-II/ PFP/ PHP/ RTI/ Vig.I Sec, DoT
(HQs);
8. Pay Bill Section, DoT (HQs.);
9. ADG (APAR)/ ADG (Staff)/ US(SNG) /AO(SGT), DoT (HQs);
10. The Officer concerned;
11. PA to US (SGT) – for uploading on the website of DoT; &
12. Order Bundle.
