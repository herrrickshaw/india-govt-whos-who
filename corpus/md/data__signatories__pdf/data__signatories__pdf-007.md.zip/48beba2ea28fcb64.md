---
doc_id: "48beba2ea28fcb64"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/8ef5f0c3e8837235d875ed2826985e0d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment in the Unified License |Virtual Network Operator| |UL-VNO| Agreement for change in interest rate, penalty and interest on penalty on delayed payment of License Fee or any other dues"
date: "2021-10-01"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b29f0d2863a434cf"
---

<!-- page 1 -->

Government oflndia
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi-110001
(Access Services Wing)
No.20-271/2010-AS-I (Vol-IV)
Dated: 01.10.2021
To
All UL (VNO) Licensees
Subj~tt: Amendment in Unified License (Virtual Network Operator) {UL(VNO)}

Agreement for change in interest rate, penalty and interest on penalty on
delayed payment of License Fee or any other dues - regarding.
As per the Condition 5.1 of Chapter-I of UL (VNO) License Agreement, the
Licensor reserves the right to modify at any time the terms and conditions of the
License, if in the opinion of the Licensor it is necessary or expedient to do so in public
interest or in the interest of the security of the State or for the proper conduct of the
telegraphs. In pursuance of this condition, the Licensor hereby amends/appends the
following in the UL (VNO) License Agreement:
Existin!!: Clause

I Amended Clause

PART-I, CHARTER III,
FINANCIAL CONDITIONS

PART-I, CHARTER Ill,
FINANCIAL CONDITIONS

20.6 Any delay in payment of License
Fee or any other dues payable under the
License, beyond the stipulated period will
attract interest at a rate which will be 4%
above the one year Marginal Cost of
Lending Rate (MCLR) of State Bank of
India existing as on the beginning of the
Financial Year (namely 1st April) in
respect of the license fees or any other
dues pertaining to the said Financial
Year. The interest shall be compounded
monthly and part of the month shall be
reckoned as a full month for the purpose
of calculation of interest. A month shall
be reckoned as an English calendar
month.

20.6 Any delay in payment of License
Fee or any other dues payable under the
License, beyond the stipulated period will
attract interest at a rate which will be 2%
above the one year Marginal Cost of
Lending Rate (MCLR) of State Bank of
India existing as on the beginning of the
Financial Year (namely 1st April) in
respect of the license fees or any other
dues pertaining to the said Financial Year.
The interest shall be compounded
annually. A part of the month shall be
reckoned as a full month for the purpose
of calculation of interest. A month shall be
reckoned as an English calendar month.

<!-- page 2 -->

Existing Clause

Amended Clause

PART-I, CHARTER III,
FINANCIAL CONDITIONS

PART-I, CHARTER III,
FINANCIAL CONDITIONS

20.8 Final adjustment of the License fee
for the year shall be made on or before
30th June of the following year. Based on
the gross revenue figures, the minimum
License Fee shall be submitted by the
Licensee, duly certified by the AUDITORS
of the Licensee in accordance with the
provision of the Companies' Act, 2013. In
case the total amount paid as quarterly
license fee for the four quarters in the
financial year falls short by more than
10% of the payable license fee and such
short payment is made good by the
licensee on its own within this 90 days
from the last day of financial year, no
penalty shall be imposed. However, in
case the demand for such shortfall is
made by the DoT after assessment and
verification, the shortfall amount shall be
made along with the penalty at the rate
50% of the shortfall amount along with
interest on the penalty amount applicable
from the due date till the date of issue of
final demand notice. In this case, the due
date may be taken as the date next to the
date of completion of the financial year
for which assessment is made, i.e., 1st
April.

2 0.8 Final adjustment of the License fee
for the year shall be made on or before
30th June of the following year. Based on
the gross revenue figures, the minimum
License Fee shall be submitted by the
Licensee, duly certified by the AUDITORS
of the Licensee in accordance with the
provision of the Companies' Act, 2013.

2.
This amendment comes into effect from 01.10.2021 and will be applicable
to the dues which arise from the operations of the Licensee after the said date.
3.
This amendment shall be part and parcel of the UL (VNO) Agreement and other
Terms & Conditions shall remain unchanged.
t.:\_

:.J ~

~l

\•lG·<a-0

(Anil Kumar Gehlot)
Director (AS-I)
For and on behalf of the President of India
Ph. No. 23036864
Copy to:
1. Secretary (TRAI).
2. DGT, DoT (HQ)/CGCA.
3. Advisor (Economics)/ Wireless Advisor/ Sr. DDG (TEC).

<!-- page 3 -->

•

4. DOG (CS)/DDG(DS)/DDG(Satellite)/DDG (LFP)/ DDG (LFA)/ DOG (SPPI)/ DDG(SA)/
DDG(WPF)/ DDG(A/C) for kind information please.
5. All Directors of AS Wing.
6. Director (IT) may kindly arrange to upload this letter on the website ofDoT.
