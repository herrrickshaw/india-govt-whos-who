---
doc_id: "4bfa9ac8d9ceaaf8"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/cd23c876fb1bffcf405ac3f52daa31f4.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Seeking stakeholders comments on the amendments of RRs of Technician & UDC of CRI, Kasauli. Download For Technician"
date: "2022-11-26"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2ecf6f4e46df9b62"
---

<!-- page 1 -->

[To be published in the Gazette of India. Part II, Section

3, Sub-section (i)]

Covernntent of'lndia
Ministry of Health and Farnill'Weltare
(Departrrerrt of Health and Family Welfare)

Notification
New Delhi. the '..

...,2022-

ln exercise ol'the powers conferred by the proviso to article 309 of tlre Constitution,the
preside,t hereby rlakes tlic fbllowing rules to anrend the Ministry of Health and Fanrily welfare. Central
nanely:'
Research Institute. KasaLrli, Techrrician (CroLrp 'C' Post) Recruitnrent Rules, 2021.

C.S.R.

l. (l) These rules nray be called the Ministry of Health and Farnily welfare, central llesearch Instittrte.

l(asaLrli. Technician (Group 'C' Post) Recruittrent (Arrendment) Rtrles'

2022.

(2) 1'hcy shallcome inro fbrce on the clate of their publication irr the Official Cazette'

2. l, the Mi,istry of Health arrd Farnily welflare. Central Researclr Institute. Kasauli'Cl' Post) Recruitment Rules' 2021-(a) i, the Sched,le, in column(12). ibr the colunrn heacling and thc entries relating

Technician (GroLrp

thereto' the fbllo$'irrs

colirurp heacling atrd entries shall be sLrbstittrtec'l. natrtel\':-

(

l) Assistant Director (Non-Meclical). Ce ntral ltesearch lnstittrte. Kasarrli - Chairtnatr:

Kasauli - Mcmber;
lnstittrte" Kasauli-Mernber:
Research
central
(Administration)"
(3) Administrative ofllcer/ oftrcer-in-chargc
Ktulqligi !ri1$eprqsgnrat!vs---tv!e11Q91'
i+jCo,rl,r,u,",,ting Ofticer, Mi]l1aly Hospital"
(2) Dep,ty Assistant ljirector (Non-N{cclical). Oentral l{esearch Institirtc.

[F. No. A- 1201810412022'EPt)

(Prem Narain)

Undcr Secretarl' to the Covernment o1'lndia
Class lV posts) Recruitment Rtrles' 1965 rvere
Note: "flre Cerrtral Research Institute. Kasatrli (Class Il and
(i), dated the l4'l' August. 1965' t'ide
publishecl in the Cazette of lntlia' Part-l[' Section 3' Sub-Section
l6ti'
arrd rvas last atnended vide number GSR 78, dated tlie
,',r',,',.,ber. C.S.R. 1167. datecl the 3"i 'lttlr'' 1965

.luli.202l.
