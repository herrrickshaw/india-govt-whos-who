---
doc_id: "4ab292dbee2eb2db"
source_url: "https://www.mea.gov.in/images/pdf/equal_opprtunity_policy.pdf"
ministry: "External Affairs (MEA)"
title: "Equal Opportunity Policy of the Ministry of External Affairs consequent upon enactment of Rights of Persons with Disabilities Act 2016"
date: ""
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c9cfca705aa86247"
---

<!-- page 1 -->

७ EQUAL OPPORTUNITY POLICY
Apolicy adopted by the Ministry of External Affairs to give effect to the principles
enshrined in the United Nations Convention on Rights of Persons with Disabilities
(2006), Rights of Persons with Disabilities Act, 2016, and the Rights of Persons with
Disabilities Rules, 2017.
1. PREAMBLE
The Ministry of External Affairs recognizes the value of a diverse work force, and an
inclusive and enabling work environment. We are committed to ensuring equal
opportunities for people with disabilities, and to providing an environment and work
culture which is inclusive of them. We seek to act proactively to facilitate their full
participation in the work of the Ministry. We are also committed to ensuring that
individuals with disabilities can interact with the Ministry in an environment which is
optimal for the needs.
I SCOPE
This policy shall apply to all those Indian citizens who are employees of the Ministry
of External Affairs.
This policy will apply to all properties and buildings under the ownership and/or
functional contro! of this Ministry, located both within and outside India.
I, DEFINITIONS
In this policy, unless the context otherwise requires —
(a) “barrier means any factor including communicational, cultural,
economic, environmental, institutional, political, social, attitudinal or
structural factors which hampers the full and effective participation of
persons with disabilities in society;
(b) “care-giver” means any person including parents and other family
Members who with or without payment provides care, support or
assistance to a person with disability;
(c) “communication” includes means and formats of communication,
languages, display of text, Braille, tactile communication, signs, large
print, accessible multimedia, written, audio, video, visual displays, sign
language, plain-language, human-reader, augmentative and
alternative modes and accessible information and communication
technology;
(d) “discrimination” in relation to disability, means any distinction,
exclusion, restriction on the basis of disability which is the purpose or
effect of impairing or nullifying the recognition, enjoyment or exercise

<!-- page 2 -->

७छ
! an equal basis with others of all human rights and fundamental
freedoms in the political, economic, social, cultural, civil or any other
field and includes all forms of discrimination and denial of reasonable
accommodation;
(e) ‘Ministry’ refers to Ministry of External Affairs, including diplomatic
Missions and Posts abroad; attached and subordinate offices,
autonomous bodies including Indian Council for Cultural Relations and
its field offices both within and outside India; Regional Passport
Offices; Protector General of Emigrants’ Offices;
(f) “person with disability’ means a person with long term physical,
mental, intellectual or sensory impairment which, in interaction with
barriers, hinders his full and effective participation in society equally
with others;
(g) “public building” means a Government or private building, used or
accessed by the public at large, including a building used for
educational or vocational purposes, workplace, commercial activities,
public utilities, religious, cultural, leisure or recreational activities,
medical or health services, law enforcement agencies, reformatories or
judicial foras, railway stations or platforms, roadways bus stands or
terminus, airports or waterways;
Vv. POLICY FRAMEWORK
The Ministry of External Affairs is committed to providing the following for people
with disabilities:

(a) This Ministry will ensure that the work environment is free from any

discrimination against persons with disabilities, and that no opportunity is denied to

persons with disabilities, only on the ground of the disability,

(b) The Ministry shall provide reservation in appointments, as per Government

of India instructions issued from time to time.

(c) The Ministry shall supportively consider, to the extent possible, the request of

persons with disabilities with respect to intra-transfer/posting, for optimally utilising

their services.

(d) The Ministry shall give preference, to the extent possible, to the requests by

persons with disabilities for allotment of appropriate residential accommodation.

(e) In substantive public dealing and public interfaces, the Ministry will

endeavour to make public buildings, accessible to people with disabilities in the

following manner:

<!-- page 3 -->

i) Provide barrier free access and assistive devices, including, but not
७ limited to, ramp facilities, where feasible, at entrances; braille enabled signage;
handrails and guardrails; accessible counters; and, accessible elevators and
stairs.
ii) Ensure that there are adequate public facilities for the use of people with
disabilities, including but not limited to, enabled washrooms, and availability of
potable water on all floors.
iii) Designate dedicated parking spots near suitable access points for the
exclusive use of people with disabilities.
iv) Ensure that caregivers (when people with disabilities have to be
accompanied by caregivers) are provided with requisite access or facilities to
enable them to assist the said person.
(f) ‘The Ministry shall, by giving appropriate directions, ensure that the above
mentioned provisions of this clause are also applied in buildings and properties
which are used for public dealings of the Ministry via outsourced agencies.
(g) The Ministry will endeavour to ensure that all public documents, including
websites, are in accessible formats.
(h) The Ministry will endeavour to provide suitable facilities and amenities to
persons with disabilities for the effective discharge of their functions, including, but
not limited to, braille enabled computer systems, height adjustable desks,
accessible plug sockets, tactile paving, desktop enabled biometric attendance
system in offices of people with disabilities
(i) The Ministry will endeavour to ensure that people with disabilities are enabled to
participate in government meetings in a convenient mode of communication.
(j) The Ministry shall consider supportively requests from persons with disabilities
for additional staffing assistance on a priority basis.
(k) The Ministry shall ensure that the provisions for equal opportunity are enjoyed
equally by women with disabilities.
(I) The Ministry shall include awareness and sensitization training programmes for
employees.
(m) This Policy shall be given appropriate publicity by being displayed prominently
on websites of the Ministry.
Vv. GRIEVANCE REDRESSAL
The Ministry of External Affairs shall appoint a Gazetted Officer as the designated
‘Grievance Redressal Officer’. The Officer shall be the nodal point for receiving and
disposing of all grievances filed under this policy. The Grievance Redressal Officer

<!-- page 4 -->

= .
छ
| investigate the complaint and shall take up the matter with the establishment
for corrective action. Further, every complaint shall be enquired within two weeks
of its registration.
The Officer shall maintain a record of complaints.
Individuals filing grievance shall be given an adequate opportunity of being heard
by the Grievance Redressal Officer. If necessary, the hearing should be in the
presence of the authority mandated by the Ministry for implementation of relevant
suggestion/request.
Vi. EMPOWERED COMMITTEE
The Ministry shall notify the constitution of an empowered committee comprising
chairperson, and such other members as may be necessary from time to time. The
Ministry shall ensure due representation to various categories of beneficiaries,
including but not limited to, people with disabilities ie, SC, ST, economically
backward sections, and women.
The empowered committee shall be chaired by AS (AD) and shall comprise JS(AD),
JS(Establishment) and Director (Finance) as members. JS (Welfare) shall be the
member-convener of the committee. Administrative and secretarial support shall be
provided by US (Welfare).
The Chairman, acting through Convener, shall ensure that more than 90 days do
not elapse between two meetings of the Committee.
The committee shall have the following functions:

(a) To provide directions, general or specific, to the concerned administrative
authorities for implementation of various measures for the welfare of persons
with disabilities;

(b) To record its general observations about adherence to and compliance of
various provisions of this policy read with the Rights of Persons with
Disabilities Act, 2016, and the Rules thereunder;

(c) To take stock of the efficacy of the grievance redressal machinery; and

(d) To present a report, from time to time, to the Foreign Secretary on the above
mentioned aspect.
