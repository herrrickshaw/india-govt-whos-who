---
doc_id: "4a2bdbc4ff1938fa"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/03/7eaad48dc04ecfbeb56bd2bbb2e5e77a.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 05.02.2026: Revised Fee payable to various categories of Central Government Counsel."
date: "2026-02-05"
pages: 10
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "67eb2f8547afe44c"
---

<!-- page 1 -->

No.J-1201 1/6/2025-Judicial/E.158060
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi,
Dated the 05" February, 2026
Office Memorandum
Subject - Revision of fee payable to various categories of Central Government
Counsel — reg.

In partial modification to this Department's various OMs issued from time to
time, the undersigned is directed to convey approval of Competent Authority for the
revision of the fee structure applicable to Government counsels of all categories with
effect from i.e.01.02.2026 as per the details given below: -

Table ‘A’
The fee structure applicable to Group ‘A’, 'B' and 'C' panel Counsel in Supreme
Court
Item of work Group ‘A’ Group
(Counsel ‘B’&‘C’
Counsel

Petitions (for final hearing) per case per da) 5

All defended Admission matters (SLP/TP, writ|14400/- 17200/-

petitions & other misc. matters for admission)} ~~~ 7"> -

er case per da’

|
pplications (per case)
| FT
er case)
है. [Drawing Written Submission (percasey) >> झट
7. |Drafting or Appearance in Miscellaneous 800/-
: pplications (including mentioning the case
: Caveat / Clearance/ obtaining the number and
aking date for the hearing) (per case basis)
a दा
i Daily fee for services out of Headquarters!
40. Entitlement for travel / hotel expenses for|
services availed outside Headquarters perform journey outside _ the|
ess
6 118

<!-- page 2 -->

"आता
headquarter in the course of his}
duties (official purpose), he shall
be paid or reimbursed travelling)
land on boarding and lodging as
per the level — 12 of 7" CPC o}
he Central Government.
a आर नी झढ'
| in identical/ connected cases: If substantially|
If matter is contested (per case) identical SLP/Petitions|
If matter is disposed ofjof Appeal/Counte!
ithout contest (per case) Affidavits
(in terms of clause 8 (ii) in chapter ‘lincluding stay|
hereinabove) applications ar
drafted in connected|
cases, only one
drafting fee will be|
payable in the |
lcase and no separate
drafting fee will be
lpayable in connected|
cases
lapplicabl
le
All other terms and conditions applicable to Group ‘A’, ‘B’ and ‘C’ Panel Counsel
in Supreme Court in the pre-revised OM No. 21(04)/1999-Judl. dated 24.09.1999 read
with OM No. 21(05)/2011-Judl. dated 01.10.2011 shall continue to remain applicable
unless specifically revoked/revised.
~ Table-B हु
या हु All the High Courts and Tribunals oe

(Except Principal Benches of High Court of Bombay and Calcutta)

The Fee structure applicable to Deputy Solicitors General of all High Courts and
its Benches, Counsels of all the High Courts and Tribunals (except Principal Benches
of High Court of Bombay and Calcutta alongwith CAT Mumbai and Kolkata Benches)
as per the following rates:
हे जि | of work Dy.SG, Sr. CGC, Addl. CGSC
1५०. (0650, 0050, |&GP

' land SPC
1. |Retainership fee (per month) 14400/- 3
[admissible to all the Deput
Solicitors General of India; Sr. CGSC|
land CGSC (DHC)}
AO
ZN

<!-- page 3 -->

ele
2. |Suits, Writ Petitions, and Appeals,
including oral Applications for Leave to
ppeal to the Supreme Court in Writ]
Petitions along-with Criminal Revision|
Applications, Criminal Reference}
matters, Contempt Petition =
Misc. Criminal cases, Bail Applications
tc. (per case per day)
(a) 14400/- (a) 3600/-
(a) For effective hearing (bb) 2400/- (0) 720/-
(b) for non-effective hearing (maxiensiny
live non-effective hearings in a case o
lbunch of cases.
3. [Application for Leave to Appeal to}4800/
Supreme Court in Writ Petitions
er case)
4800/- Ed
5. Drafting of pleadings, counter =i 12160/-
returns / answer to writ petitions
rounds of appeal and application fo!
leave to appeal to the Supreme Court
lexcept in cases where
fee on ad valorem basis has been
prescribed (per leading)
Drafting of civil __ miscellaneou 11800/-
applications to petitions under the
Indian Succession Act, contempt o
Icourt proceedings and othe
proceedings of an original nature (pe!
etitions)
Original suits, civil appeals from S per concerned|
lecrees in suits and proceedings respective High Court
including 27° appeal and _ land| |General है
lacquisition appeal except LPA from rules/procedure.
lpetitions under article 226 and 227of the
Constitution i.e. Ad Valorem/regulation
fee
(It is a lump sum fee per case including|
drafting fee
Miscellaneous Application _4800/- ._______ |
IGonference fee* (per conference) 1 440/- \720/- -
Subject to :
(i) for — setting|
pleadings : one
conference .
(1) In respect “o
hearing of Wri
matters, Suits
L ohrsiat
CNS

<!-- page 4 -->

नाना
lappeals and
Ere Courts}
llsave applications
jetc. a thre
Iconferences
_ _. (maximum)
हे | Entitlement for travel / hotel ~., <paas\WVhere a CounsellWhere a Counsel is|
or services availed outsidelis required tolrequired to perform
Headquarters perform journeyjourney outside the|
loutside thelheadquarter_ in the
headquarter in the|course of his duties
course of __his(official purpose), he
juties (officiallshall be paid o
purpose), he shall reimbursed travelling
be paid orand on boarding and
reimbursed lodging as per the|
ravelling and onjlevel — 41. of 7
boarding and|CPC of the Central
lodging as per the|Government.
level — 12 of 7*
CPC of the
Central
Government.
LT
42. |Fee in identical / connected cases:
(a) If matter is contested -
(a)1500/- (a) 600/-
When the Counsel filed Separate and|
materially different, affidavits
applications or grounds of appeal etc. in
more than one case but the argument is}
heard in the main case and the othe! “
cases are decided accordingly, the}
Counsel shall be paid the full fee in the}
main case and Rs.150/-in each of th
connected cases. (b)750/- (b)300/-
(b) If matter is disposed of without
contest -
. hen the main case has been contested|
las in (a) above, but in the connected
cases either affidavits or grounds of an
appeal or petition similar to the one in|
2 the main case or nothing at all has been|
drafted by the Counsel, he shall be paid} (c)1/3rd_ fee in(c)1/3rd fee in main|
the full fee in the main case andRs.75/-main case and Rs.|case and Rs. 600/-in
lonly in each of the connected case. 4500/-in_each_o'
iN OX, \ab
ORS 4

<!-- page 5 -->

“Be
the connectedleach of the
(c) | When substantially _differentimatters connected matters.
affidavits are drafted in each connected
case but all the cases are disposed of
ithout contest, the Counsel shall ge
4/3rd fees in the main case and Rs.150/- .
in each of the connected cases. (d)1/3rd fee in (d)1/3rd fee in main|
main case and Rs|case and Rs. 300/-in|
(d) When the Counsel has drafted the\750/-in each of theleach of the}
affidavit, petition or ground of appeal inleonnecd matters. connected matters.
the main case and has not drafted them|
in the connected cases or the drafts in
the connected cases are substantiall
similar to the one in the main case and|
he cases are disposed of withou
contest, the Counsel shall get 1/3rd fees|
in the main case and Rs.75/- in each o
the connected cases
13. |Out of pocket and Misc. expenses As per actual and subject to satisfaction
lof Ministry / Department concerned
All other terms and conditions applicable to Counsel in various High
Courts/CAT Benches (excluding the High Court of Bombay and Calcutta) in to this
Department's OM No. 24(02)/99-Judl. OM No. 26(01)/99-Judl., OM No. 25(03)/99-
Judi. and OM No. 26(02)/99-Judl. all dated 24.09.1999 read with OM No. 26(01)/2005-
Judi. dated 31.01.2008 and OM No. 26(01)/2011-Judl dated 01.10.2011 shall
continue to remain applicable unless specifically revoked/revised.
Table ‘C’
High Courts (Principal Benches) as well as CAT & Other Tribunals Benches of
se पु Bombay and Calcutta =
The Fee structure applicable to Counsels of High Courts (Principal Benches)
as well as Central Administrative Tribunal & Other Tribunals Benches in Bombay and
Calcutta as per the following rates:
Item of work Rates of fee
Special |Senior Senior _ |Jr. Counsel
ICounsel |Counsel |Counsel Advocate on
Group -1!_|Group - Il record.
4. \Suits, Appeals, Writ/Revision 44400/- 9600/- 6000/- 2880/-
Petitions including Special
civil. Application in High|
Court along-with Criminal
Revision Applications,
Criminal Reference matters,
AER

<!-- page 6 -->

जा
Contempt Petition (Criminal), |
Misc. Criminal cases, Bail
Applications etc.
| _[Per conference/ consultation\1440/- 4200/- sor _(r20-
24 pplication including interimA4BOo! - 3600/- 2160/-
Motions, Notices, sopeas|
Leave Application,
Arbitration, Company Matter.)
Criminal revision and othe
Land Acquisition References :
(Per day per effective
hearin
Per canference/Consultation
3. |Drafting or Settling4800/- 2880/- 2400/- 1680/-
Pleadings, and Affidavits (pel
lpleading)
peacsnrerenceIConsukaton raaor- 2007. (e80—(r20F 77
| ppearance beforel12000/- |9600/- |6000/- 3600/-
rbitration and Tribunal et:
‘and Courts other than High|
Courts (Per day per effective
hearing) Per conference.
Consultation
por eonierenceiConsutation W440 [72007 B60 [rao
5 \Chamber Application, 12400/- 1440/- 960/-
including Adjournmen
Application per day inclusive}
lof consultation
Written opinions and written} 6000/- 3600८ 12160/- 1680/-
ladvice including advice on|
levidence (inclusive रण
consultation)
| for Travel 910५४108 9 Counsel is required to\Where a Counsel
Hotel expenses for services|perform journey outside thelis required to
availed out of headquarter headquarter in the course of hisjperform —journe’
duties (official purpose), he shallloutside the|
be paid or reimbursed travellinglheadquarter in the
land on boarding and lodging asjcourse of his
per the level — 12 of 7" CPC ofjduties (official
he Central Government. purpose), he shall
lbe paid 0|
reimbursed
travelling and on
boarding and|
lodging as per the
level — 11 of 7%
ICPC of the Central
Government.
a aia’
5

<!-- page 7 -->

-7 ii
All other terms and conditions applicable to the Counsels of High Courts as well
as CAT Benches of Bombay and Kolkata in the pre-revised OM No. 23(02)/2001-Judl.
& OM No. 22(02)/2001- dated 14” July 2001 read with OM No. 23(02)/2011-Judl.
dated 1 October 2011 shall continue to remain. applicable* unless specifically i
revoked/revised. to
Note: There will be no celling on the number of conference/consultation in the case
of Special Counsel, however in the case of other categories of Counsels, the number
' of conferences per cases will be limited to four (relaxable to six) at the discretion of
ae the Incharge (Litigation) of Branch Se*retariat, Mumbai/Kolkata.
Table - 0
All the District & Subordinate Courts throughout the Country
The fee structure applicable to Standing Government Counsel and Additional
Standing Government Counsel in all the District & Subordinate Courts throughout the
Country as per the following rates:
No. all figures are in Indian Rupees)
1. |Retainership fee admissible to} 9600/-
‘Standing Governmen
Counsel’ only (per month)
(except in Delhi)
icase per day)
3, IFee for non-effective hearing
(per case per day for maximum
five non-effective hearings in a
case
4.|\Fee for drafting Written 2400/-
Statement, Grounds of Appeal,
jetc.
er pleading)
lof misc. nature (per pleadin:
Fee per Conference* 1440/- |
(Subject to maximum five|
conferences in a case or group
of identical cases है
Daily fee for out oO 3600/-
हि Headquarters (per da ) हे
Entitlement for travel / hotellWhere a Counsel is required to perform journe)
lexpenses for services availedjoutside the headquarter in the course of his
lout of Headquarters duties (official purpose), he shall be paid_o'
he
ER

<!-- page 8 -->

=8 +
— travelling and on boarding and
lodging as per the level — 8 of 7" CPC of the
Central Government.

Clerkage 10% of total fee 8400/-
excluding miscellaneous and
lout of pocket expenses
Fee in identical/connected| 4200/-
हे cases _ _ ee wa 7
.« °l4tlOut of pocket and Misc) ®2 Ver actual and subject to satisfaction of
| L__lexpenses — Ministry / Department concemed
All other terms and conditions applicable to above mentioned Counsels in to
this Departments’ OM No. 27(11)/1999-Judl dated 24.09.1999 read with OM No. 27
(25)/2011- Judi. dated 01.09.2011, shall continue to remain applicable unless
specifically revoked/revised.
Table -E
Panel Counsel for conducting arbitration cases before the arbitrators and
arbitration tribunals
The fee structure applicable to counsel for conducting arbitration cases before
the arbitrators and arbitration Tribunals as per the following rates:
si.
No. Senior Junior
Arbitration Arbitration
\Counsel Counsel
Fee for effective hearing (per appearance 3600: __ 2408 ]_]|

2. \Fee for Non-effective hearing 7 20/- 480/- है
(per appearance and for maximum four hearings|
in a case) .

aoe ——«(r200e |

i Conference fee 7 20/- \480/-

(subject to a maximum oO
three conferences in a case)

360/-
| for travel / hotel expenses(fo Where alWhere al
services availed out of Headquarters) Counsel is\Counsel is

required tojrequired t
perform journeyjperform journey|
loutside theloutside the|
~ |neadquarter in headquarter in|
the course of hisithe course of his}
: duties (officiallduties (official
purpose), helpurpose), hel
shall be paid orfshall be paid o1

reimbursed reimbursed

hy 3
PaR\A

<!-- page 9 -->

= ~ 9 ~
_ Bes and onltravelling and on
boarding — and|boarding and
lodging as perlodging as pe
the level — 12 ofthe level — 11 o
th F CPC of thel7" CPC of the
Central —_ |Central
Government. (Government.
7 \Clerkage (NEW ITEM) लता “171% of total fee in a case subjec
_ ito a maximum of Rs. 2880/-

All other terms and conditions applicable to OM No. 30(3)/99-Judl. dated
24.09.99 read with OM No. 26(1)/2005/Judl. dated 31.01.2008, shall continue to
remain applicable unless specifically revoked/revised.

2. The above revised fee will be effective from 01.02.2026.
3. The counsels will be paid fee at the old rates in respect of their appearance in
the Court etc. and other work done by them prior to 01.02.2026 and at the revised
rates in respect of the work done by them on/ after 01 02.2026.
4. This issues with the approval of the Ministry of Finance, Department of
Expenditure E.II(B) Branch, ID Note No.9/8/2025-E.II(B) dated 02.03.2015 and
12.01.2026.
Bea > se
Cm
. (MC Prusty)
Senior Government Advocate
Copy to:
1 Ail Ministries/Departments to the Government of India” ~
2 Incharge. Central Agency Section, Litigation (HC) Section, Litigation Lower
Courts Section, All Groups-A, B & C panel counsel of Supreme Court through
Incharge.
3: Nodal Officer of Legal Cell, all Ministries/Departments to the Government of
India
4. All Senior Panel Counsel of High Courts/ CATs through concerned Deputy
‘Solicitors General in High Courts/Sr. CGSC of CATS Benches.
5. All Deputy Solicitors General in various High Courts/Sr CGSC of CATs Benches
6. All Central Government Standing Counsel/Central Government Pleaders of
Delhi High Court :
7. All Deputy Solicitors General/Central Legal Adviser of various High Courts
8: All Senior Central Government Standing Counsel/Addl. Central Government
Standing Counsel of various CAT Benches.
9. All Standing Govt. Counsel and Additional Standing Govt. Counsel before
various District and Subordinate Courts as per the list.
10. All Senior/Junior Counsel of the Arbitration Panel.

<!-- page 10 -->

=f{O —
AA. All Special Counsel, Senior Counsel Group-1, Senior Counsel Group-It and
Junior Counsel of High Courts as well as CATs Benches of Bombay and Kolkata
through the concerned Incharge of Branch Secretariat of Bombay and Kolkata.
12. Incharge, Branch Secretariats Mumbai/Kolkata/Chennai/ Bangalore.
13. All Sections of Department of Legal Affairs.
14. Legal Advisor, Railway Board, New Delhi (with 5 spare copies).
AS. Department of Personnel and Training (AT Section), New Delhi (with 5
s/copies.)
16. Joint Secretary (Legal), Department of Revenue, Ministry of Finance, New
Delhi (with 5s/copies)
17. CBDT, Department of Revenue, Ministry of Finance, New Delhi (with
5s/copies).
18. Ministry of Urban Development, Nirman Bhawan, New Delhi
19. Department of Expenditure, Ministry of Finance, New Delhi w.r.t. their ID Note
No, 9/8/2025-E.1I(B) dated 12.01.2026
20. . DGS&D, New Delhi
21. NIC Gell with the request to upload the same in the website of this Department
22, Judicial Section with 50 spare copies.
23. O.L. Section for Hindi translation
pe, ia
(Ramesh Kairamkonda)
Section Officer
Tele — 23384945
Mail — judicial-dla@nic.in
