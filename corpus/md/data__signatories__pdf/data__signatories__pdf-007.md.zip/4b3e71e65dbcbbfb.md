---
doc_id: "4b3e71e65dbcbbfb"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/bd315a1eeff920249ffe927e53299cf6.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allocation of short code 14441 to National Informatics Centre"
date: "2016-10-24"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ea699c17bc0a2b48"
---

<!-- page 1 -->

Go\'ernment of India
Depa rf" ITI en t (l r T elecom m II n iea I ions

Ac cess Services V\1 ing
20, Ash oka Road, Ne'' De lh i- I JOOOi
No . J6-3/20 J 3/AS- m (Par1 Ul)/J 64t.'lfl

s

I

Dated :24/! 0/2016

To.
A ll Access Servi ce Provi ders.
Subjec t :- A ll ocation of Sho r t C ode '1 4441 ' to N ational Informati cs C entre (NIC) .

T he unclersignecl is cl irectecl to co nve: the apprci\ ·n i of co mpetent autho r it: tu all ocate Short
Code '14.+ 41' ro Natio na l l n fo rnrnti cs Centr e for voic e and SfVJS with fo ll o1vi11g feat ures:­

(il

Catego1·:-- I: Se r v ice ( i. e.111a nda to 1·y serv ice to be prov ided b: all rhe Access
prov ide rs.

I i i)

Access ib ili ty: U n-restr icted i.e. ava il ab le 011 STD also for both voice and
SMS.

(i i: )

2.

IVleterecl : Ca ll ed party pays.

."\ II are requ ested to take necessa ry act ion.

s.~~

~?--~ ';t:::1

( S anc~1i1 Kr. Garg) b

ADET (AS-III)
Tel.: 2303 6444
C op) forwa rde d for inform at ion and necessa r:- action. if a n ~. to :

I.

Secretar:. T RA I.
See m a K hann::i . Tec hnica l D irec wr. N IC. A -Bl oc k. C.G (l Co111ple -.. . Lodhi Rl1acl l\: e1·\ Delhi­
i ! ()()():'. \1 ith rek 1·ence l <• \O ur len er dmecl 14 ·1(1 ':2(116 ( it is 1·equesre ci

\ (1

ap11n i!l! a noda l

, 1fli cer ll > i111pie111en l th e hel pl in e. a:-- anc \\ hen dec iclecl).

.3

Clvl D r-vJTN I.. · BSNL. .

.:l

D irec to1 ITE.R iVl -1 ). DoT (HQJ (A ll TERM Ce ll s m a>· be as k ed to co-o rcl inate w ith res pec t ive
Nocla.i OHi ce rs and TS Ps fo1· im p lem entat ion of Help lin e, as and w hen appmac hecl ).

5.

.- \i)(_; ( IT ) wi th request to k in cl l) upload on DoT Websi te.
