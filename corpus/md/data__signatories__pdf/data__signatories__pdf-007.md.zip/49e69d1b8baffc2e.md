---
doc_id: "49e69d1b8baffc2e"
source_url: "https://www.meity.gov.in/static/uploads/2026/01/b894cf6c228a76e703b698842c31dc71.pdf"
ministry: "Electronics and Information Technology (MeitY)"
title: "Series Guidelines for Extended Reality Products (Augmented Reality, Virtual Reality, Mixed Reality, etc."
date: "2026-01-05"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6bc338bf23426b24"
---

<!-- page 1 -->

Series Guidelines: Extended Reality Products (Augmented Reality (AR), Virtual Reality
(VR), Mixed Reality (MR) etc.)

Same type of products may be clubbed together in a series (Separate series to be formed for
AR product, VR Product and MR product)
2.

Maximum 10 models can be accommodated in a series subjected to the following:
I.

Same energy source (Power Adapter, Mains Operated, Battery Operated) and safeguard
system
a) External Energy Source (Power Adapter/ Power Bank/ Other Input Devices)
i) Alternate models of the power adapter may be included as part of main product’s
evaluation but the main product itself must share the same power requirement
ii) Registered power adapter/ power bank is to be provided, with a capacity greater than
or equal to the rated capacity
b) Mains Operated with Internal Power Supply:
i) The mains layout or the SMPS (Switched Mode Power supply) board layout must be
the same.
ii) Power transformer (if applicable) must have the same design and insulation system.
c) Battery (Internal) Operated:
i) Models with different battery capacities can come in series, provided the lead model
is tested with the highest battery capacity.
ii) Battery to be treated as component (Alternate sources of battery may be evaluated
as part of the main product.)

II.

Same class of construction.

III.

Same enclosure (The same enclosure material must be used, with an exception for
differences that are purely decorative (e.g., colour, minor styling variations).

IV.

Same PCB layout design.

V.

Same type of Display (LED/LCD/AMOLED etc)

VI.

Same IP Rating.

3.
In cases where an external energy source is not supplied with the product, the
specifications and ratings of the external energy source (e.g., power adapter, power bank, etc.)
shall be clearly stated on the product /catalogue.

**********
