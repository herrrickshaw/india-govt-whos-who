---
doc_id: "4d204efbe1ad6fb3"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/E04_26_03082026.pdf"
ministry: "Department of Space"
title: "Corrigendum:URSC/GLOBAL TENDER NOTICE NO. E-04/26-27 Dated:31.07.2026      891.98 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a542b3b4b4d30fd3"
---

<!-- page 1 -->

भारत सरकार, अंतररक्ष तवभाग /GOVERNMENT OF INDIA, DEPARTMENT OF SPACE
यू . आर. राव उपग्रह केन्द्र (यू .आर.एस.सी) U R Rao Satellite Centre [URSC]
(पूवि में इसर उपग्रह केन्द / Formerly known as ISRO Satellite Centre)
एच.ए.एि. एयरप टि र ड, तवमानपुरा प स्ट
HAL Airport Road, Vimanapura Post,
बें गिूरु / BENGALURU
भारत / INDIA

शुद्धि-पत्र संख्या Corrigendum No. 02
यू.आर.एस.सी./वैश्विक श्विश्ववदा सूचिा सं / URSC/GLOBAL TENDER NOTICE NO. E-04/26-27

31.07.2026

भारत के राष्ट्रपतत की ओर से व. प्रधान, क्रय एवं भंडार ई-, यू.आर. राव उपग्रह केन्द्र (यू.आर.एस.सी.), द्वारा तनम्नतिखित मद ं की
आपूतति के तिए केवि प्रापण के जररए तनतवदाएं आमं तित हैं :
On behalf of the President of India, Sr. Head, Purchase & Stores, U R Rao Satellite Centre [URSC] issues
corrigendum to tender ONLY through e-procurement for supply of the following.
दो भाग श्विश्ववदा Two Part Tenders
Sl. No.
01.

श्विश्ववदा संदभभ TENDER REFERENCE

संश्विप्त श्वववरण BRIEF DESCRIPTION

URSC/PR/IS2026-00-0435- 01

अल्ट्र ा स्टे बि ऑतसिे टर (यूएसओ)
Ultra Stable Oscillator (USO)

के स्थाि पर In Place of

पढ़ा जाय

To be read as

बोली प्रस्तुत करिे हे तु प्रारं श्वभक श्वतश्वथ
03.07.2026 (16.00 Hrs.) 03.07.2026 (16.00 Hrs.)
Bid Submission Start Date
10.07.2026; 16:00 hrs
10.07.2026; 16:00 hrs
बोली स्पष्टीकरण Bid Clarification Date upto
07.08.2026 (14.00 Hrs.)
बोली प्रस्तुत करिे की श्वियत श्वतश्वथ Bid Submission Due Date 31.07.2026; 14:00 hrs
बोली खोलिे की श्वतश्वथ Bid Opening Date

31.07.2026; 14:30 hrs

07.08.2026 (14.30 Hrs.)

वैध तडतजटि हस्ताक्षर प्रमाणपि (डी. एस.सी) प्राप्त इच्छु क तनतवदाकार https://eproc.isro.gov.in पर िॉग इन करके अपना प्रस्ताव
ऑनिाईन भेज सकते हैं । क ई तनतवदा शुल्क िागू नहीं है ।
Interested Tenderers having valid Digital Signature Certificate [DSC] may login to https://eproc.isro.gov.in and
submit Offers online. No Tender fees applicable.
तनतवदाओं क उपर क्त तनतदि ष्ट् तदनां क पर ि िा जाएगा। अहि तवक्रेताओं के दर ब िी क ि िने की समयसूची क बाद में सूतचत तकया
जाएगा। ब िी िगाने से संबंतधत तववरण क इसर ई-प्रापण प टि ि में िातगन करके दे िा जा सकता है ।
Tenders will be opened on the date specified above. Schedule for opening of the Price Bid (in case of Two-Part
Tenders) of Qualified Vendors will be intimated later. Bidding details can be seen by the participated vendors by
logging into ISRO e-procurement portal.

Sd/व. प्रधाि, क्रय व भंडार / Sr. Head, Purchase & Stores
