---
doc_id: "4a44aea0eb37ad9d"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_69898ae3258e37.69798245.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Office Order (I)- IFS Officers of the Joint AGMUT Cadre of Indian Forest Service are hereby promoted to the Grade of PCCF(Pay Level-16), order dated 09-02-2026"
date: ""
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "e7eef33f17b959fa"
---

<!-- page 1 -->

C.No.136577
F.No.32012/5/2019-IFS-1 (AGMUT)
Government of India
Ministry of Environment, Forest and Climate Change

Indira Paryavaran Bhawan, 6" Floor, Prithvi Wing,

Jor Bagh Road, Aliganj, New Delhi-— 110 003.

Date: of February, 2026 '
OFFICE ORDER()

The following officers of the Joint AGMUT Cadre of Indian Forest Service are
hereby promoted to the grade of PCCF (Level-16 in the Pay Matrix of Rs. 2,05,400 — Rs.
2,24,400/-) with immediate effect, on assumption of charge to the post in the same
segment: -
oa Name = (Shri/Smt./Ms.),/Present —_[Post/level after Promotion
INo. {Batch of the officer and/posting

Date of Birth of the/before
officer promotion
~ Ravichandran, irector, roforma Promotion w.e.f. the date o!
(AGMUT:1996) FM, lassumption of charge to the post of
15.10.1967 Bhopal PCCF by Shri Ravi Horo, IFS
[CDR] (AGMUT:1996)
‘avi loro, pecan | P P evel-16 in the Pay Matrix o'
|(AGMUT:1996) Rs.2,05,400-Rs.2,24,400/-)
20.12.1967
2. The officers are promoted in situ against overall vacancies of PCCF (Level-16 in
the Pay Matrix of Rs. 2,05,400-— Rs. 2,24,400/-) in Joint AGMUT Cadre. The
Transfer/Posting of the promoted officers will be issued separately. The above-
mentioned officers, who are posted in cadre, are requested to send a copy of the charge
assumption report to this Ministry.
3. The above promotion is subject to the condition that when a senior officer on
deputation joins the cadre, the junior most officer in the rank will be reverted. a ak
4. This issues with the approval of the competent authority. (eR as
6१
(Prem h Maurya)
Under Secretary to the Government of India
Tele:011-20819192
E-mail: ifs@nic.in
Distribution:
1. PS to Hon'ble Minister, Environment, Forests & Climate Change, New Delhi.
2. PS to Hon'ble Minister of State, EF&CC, New Delhi
3. PPS to Secretary, (EF&CC), New Delhi /PPS to DGF & SS, MoEF&CC, New Delhi.
4. The Chief Secretary, A&N Islands Administration, Port Blair.

<!-- page 2 -->

5. The Chief Secretary, Government of Goa, Panjim
6. The Chief Secretary, Government of Mizoram, Aizawl
7. The Chief Secretary, Government of Arunachal Pradesh, Itanagar.
8. The Chief Secretary, Government of NCT of Delhi, Dethi
9. The Chief Secretary, Government of Puducherry, Puducherry.
10. The Chief Secretary, Govt. of UT of J&K, Srinagar/Jammu.
11. The Adviser to LG, UT of Ladakh, Leh
iM 2. The Administrator, Administration of Daman & Diu and Dadra & Nagar Haveli,
aman.
13. The Administrator, Administration of Lakshadweep, Kavaratti.
14. The Administrator, Administration of UT of Chandigarh, Chandigarh.
ae The Principal Chief Conservator of Forests and HoFF, Govt. of Arunachal Pradesh,
lanagar.
16. The Principal Chief Conservator of Forests and HoFF, Govt. of UT of J&K,
Srinagar/Jammu.
17. The Principal Chief Conservator of Forests, Government of Mizoram, Aizawl
18. The Principal Chief Conservator of Forests, A&N Islands Administration, Port Blair
19. The Principal Chief Conservator of Forests, Government of Goa, Panaji
20. The Principal Chief Conservator of Forests, Government of NCT of Delhi, Dethi
21. The Additional Principal Chief Conservator of Forests, UT of Ladakh
22. The Chief Conservator of Forests, Administration of Daman & Diu and Dadra &
Nagar Haveli, Daman.
23. The Conservator of Forests, Puducherry, Puducherry.
24. The Deputy Conservator of Forests, Administration of Lakshadweep, Kavaratti
25. The Chief Conservator of Forests, Administration of the UT of Chandigarh,
Chandigarh.
26. Concerned officers/departments as mentioned above through IFS website.
27. AS (Admn.)/IGF (IFS), MoEF&CC.
28. Civil List (US, IFS-II)/US (Vigilance Section)/ Guard File.
29. NIC Cell (Shri Irshad)- for placing on the IFS website.
30. IT Division, MoEF&CC- for placing on the Ministry's website. wy
(A
(Prem Prakash Maurya)
Under Secretary to the Government of India
Tele: 011-20819192
E-mail: ifs@nic.in
