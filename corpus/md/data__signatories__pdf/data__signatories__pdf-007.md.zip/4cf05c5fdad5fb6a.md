---
doc_id: "4cf05c5fdad5fb6a"
source_url: "https://dof.gov.in/static/uploads/2025/09/8cbe615d9a4c2f1926fca61c71174222.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Vacancy Circular for applying for the post of Assistant Director (Aquatic Quarantine)(27-12-2022)"
date: "2022-12-27"
pages: 7
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "bf829f4c4bbd67ed"
---

<!-- page 1 -->

F. No. 12025/2/2022 Admn I (e-21548)
Government of India
Ministry of Fisheries, Animal Husbandry and Dairying
Department of Fisheries
1* Floor, Chander Lok Building,
Janpath, New Delhi
Dated the 20" December, 2022
To,
1. All Ministries/Departments of Government of India,
2. Chief Secretaries of All State Government/UT Administrations
3. Indian Council of Agricultural Research
4. Commissioners/Secretaries dealing with Fisheries Departments of all State Government
5. The Registrar of Universities
6. The Director, All the Recognized Research Institutions/Public Sector undertaking/ Semi
Government/Autonomous Bodies/Statutory Organisations/sub-ordinate of DoF
Subject: Recruitment to one post of Assistant Director (Aquatic Quarantine) in Level 10 of the Pay Matrix
(Pay Band-3 Rs. 15600-39100 plus Grade Pay of Rs. 5400 pre-revised) in the Department of Fisheries,
Ministry of Fisheries, Animal Husbandry and Dairying, Krishi Bhawan, New Delhi on Composite Method
[Deputation (including Short Term Contract) Plus Promotion] -regarding
Sir/Ma’am,
|.am directed to say that one post of Assistant Director (Aquatic Quarantine) in Level 10 of the Pay
Matrix (Pay Band-3 Rs. 15600-39100 plus Grade Pay of Rs. 5400 pre-revised) in the Department of Fisheries,
Ministry of Fisheries, Animal Husbandry and Dairying, Krishi Bhawan, New Delhi is proposed to be filled up on
Composite Method [Deputation (including Short Term Contract) Plus Promotion] from amongst the Officers of
the Central Government or State Governments or Union Territories or Universities or recognized Research
Institutions or Public Sector undertakings or Semi Government organizations or Autonomous or Statutory
bodies:-
a. (i) holding analogous post on regular basis in the parent cadre or Department; or
(ii) with two years' service in the grade rendered after appointment thereto on regular basis in Level 8of
Pay Matrix (revised)[PB-2, Rs. 9300-34800 with Grade Pay of Rs. 4800 (pre-revised)] or equivalent in the
parent cadre or Department; or
(iii) with three years' service in the grade rendered after appointment thereto on regular basis in Level 7
of Pay Matrix (revised)[PB-2, Rs. 9300-34800 with Grade Pay of Rs. 4600 (pre-revised)] or equivalent in
the parent cadre or Department; and
(iv) with eight years' service in the grade rendered after appointment thereto on regular basis in Level 6
of Pay Matrix (revised)[PB-2, Rs. 9300-34800 with Grade Pay of Rs. 4200 (pre-revised)] or equivalent in
the parent cadre or Department; and
b. possessing the following educational qualifications and experience:
Essential:
a. Master’s Degree in Zoology or Fisheries Science from a recognized University or Post
Graduate Diploma in Fisheries Science from Central Institute of Fisheries Education, Mumbai
b. three years’ experience in the field of fisheries research and development such as monitoring,
surveillance, reporting of aquatic animal diseases in any government department or in a
recognized research and development organization dealing with aquatic animal health issues.
Note: The departmental Fishery Research Investigator (Quarantine) in the Level 6 of Pay Matrix (revised) [PB-
2, Rs. 9300-34800 with Grade Pay of Rs. 4200 (pre-revised)] with eight years’ regular “AL

<!-- page 2 -->

would also be considered along with outsiders. In case he/she is selected for appointment to the post, the
same shall be deemed to have been filled by promotion.

Note 1: The departmental officers in the feeder category who are in the direct line of promotion will not be
eligible for consideration for appointment on deputation. Similarly, deputationist shall not be eligible for
consideration for appointment by promotion. (Period of deputation (ISTC) including period of
deputation(ISTC) in other ex-cadre post held immediately preceding this appointment in the same or some
other organization or department of the Central Government shall ordinarily not exceed three years. The
maximum age limit for appointment by deputation (including short term contract) shall be not exceeding 56
years as on the closing date for receipt of applications).

Job description:

The Assistant Director (Aquatic Quarantine) will assist Deputy Director (Aquatic Quarantine) in all matters
including issues relating to aquatic quarantine, risk analysis, examination import proposals involving aquatic
animals and their products, issuing permission of import and sanitary import permits, aquatic animal disease
monitoring and reporting.

The initial place of posting will be at New Delhi

2. The pay of the official selected will be governed by the provisions laid down in the Department of
Personnel and Training's O.M.No.6/8/2009-Estt (pay Il) dated 17" June 2010 as amended from time to
time.

3. Applications from eligible officers in the enclosed proforma (in duplicate) may be forwarded through
Proper channel to Shri Yoginder Kumar, Under Secretary (Admn), 1* Floor, 36, Chander Lok Building,
Janpath, New Delhi- 110001 within a period of 60 days from the date of publication of this
advertisement in the Employment News along with copies of up-to-date ACR/APARs for the last five
years, duly attested by an officer of the level of Under Secretary or above, vigilance clearance and
integrity certificate. Cadre controlling authority may also kindly ensure that while forwarding the
application they should verify and certify that the particulars furnished by the officer are correct. It
may also be certified that no major or minor penalty was imposed on the officer during the last 10
years of his service.

4. Applications received after the due date or without ACRs or otherwise found nie will not be
considered.

(Yogi ar)
Under Secretary to the Governfnent of India
Tel: 011-2331 0351
E-Mail: adm nyfishery@dof-goy ire
Under Secretary (Fy.)

Copy to: न मा ह Dairying
1. Director of Fisheries of all States/UT's तक Bulent Not Dethi-t10001
2. All Sections/Units/Desks of Department of Department of Fisheries -

3. All Sections/Units/Desks of Department of DAHD
4. All the subordinate/attached offices in Department of Fisheries
5. Director, NIC with the request to upload this circular on the website of this department.
de
Under Secretary to the Government of India
Tel: 011-2331 0351
E-Mail: admn-fishery@dofgoyrinvR
Under Secretary (Fy-)
Department of Fisher आय जज
Chander Lok Building

<!-- page 3 -->

ANNEUXURE-I
BIO-DATA/CURRICULUM VITAE PROFORMA
Letters)
Po
PT
ii) Date of retirement under
Central/State Government Rules
pT
5. Whether Educational and
other qualifications required for
the post are satisfied. (if any
qualification has been treated as
equivalent to the one prescribed
in the Rules, state the authority
for the same)
Qualifications/ Experience required as | Qualifications/experience possessed by the
mentioned in the advertisement/vacancy | officer
circular
5.1 Note: This column needs to be amplified to indicate Essential and Desirable
Qualifications as mentioned in the RRs by the Administrative Ministry/Department/Office at
the time of issue of Circular and issue of Advertisement in Employment News.
5.2 In the case of Degree and Post Graduate Qualification Elective/main subjects and
subsidiary subjects may be indicated by the candidate.
6. Please state clearly whether in the light of
entries made by you above, you meet the
requisite Essential Qualifications and work
experience of the post.
6.1 Note: Borrowing Departments are to provide their specific comments/views confirming
the relevant Essential Qualification/ Work experience possessed by the Candidate (as
indicated in the Bio-data) with reference to the post applied.

<!-- page 4 -->

7. Details of Employment, in chronological order. Enclose a separate sheet duly
authenticated by your signature, if the space below is insufficient.
Office/Institution | Post held on | From To *Pay Band and | Name of
regular basis Grade Pay/Pay | Duties (in
Scale of the post | details)
held on regular | highlighting
basis experience
required for
the post
applied for
*Important: Pay-band and Grade Pay granted under ACP/MACP are personal to the officer
and therefore, should not be mentioned. Only Pay Band and Grade Pay/Pay Scale of the
post held on regular basis to be mentioned. Details of ACP/MACP with present pay Band
and Grade Pay where such benefits have been drawn by the Candidate, may be indicated as
below;
Office/Institution Pay, Pay Band, and | From To
grade pay drawn
under ACP/MACP.
Scheme
8. Nature of present
employment i.e;
Adhoc or Temporary
or Quasi-Permanent
or Permanent
9. In case the present
employment is held on
deputation/ contract
basis, please state-
a) The date of initial | b) Period of|c) Name of the} d) Name of the post
appointment appointment on | parent and Pay of the post
deputation/contract | office/Organization held in substantive
to which the | capacity in the
applicant belongs. parent organization
PT
9.1 Note: In case of Officers already on deputation, the applications
of such officers should be forwarded by the parent
cadre/Department along with Cadre Clearance, Vigilance Clearance
and Integrity Certificate.

<!-- page 5 -->

9.2 Note: Information under Column 9(c) & (d) above must be given
in all cases where a person is holding a post on deputation outside
the cadre/organization but still maintaining a lien in his parent
cadre/ organization.
10. If any post held on Deputation in the past by the applicant, date ; |
of return from the last deputation and other details.
11. Additional details about present employment:
Please state whether working under (indicate the name of your
employer against the relevant column)
a. Central Government
b. State Government
c. Autonomous Organization
d. Government Undertaking
e. Universities
f. Others
12. Please state whether you are working in the same Department
and are in the feeder grade or feeder to feeder grade.
13. Are you in revised Scale of Pay? If yes, give the date from which | |
the revision took place and also indicate the pre-revised scale
15. In cases the applicant belongs to an Organisation which is not following the Central
Government Pay-Scales, the latest salary Slip issued by the Organisation showing the
following details may be enclosed.
Basic Pay with scale of | Dearness Pay/interim relief / other | Total Emoluments
pay and rate  of| Allowances etc., (with break-up
increment details)
16. A Additional information, if any, relevant to the post you
applied for in support of your suitability for the post.
(This among other things may provide information with regard
to (i) additional academic qualifications (ii) Professional training
and (iii) work experience over and above prescribed in the
vacancy Circular/Advertisement)
(Note: Enclose a separate sheet, if the space is insufficient)
16. B Achievements:
The candidates are requested to indicate information with
regard to;
(i) Research publications and reports and special projects
(ii) Awards/Scholarships/Official Appreciation
(iii) Affiliation with the professional bodies/institutions
/societies and;
iv) Patents registered in own name or achieved for the

<!-- page 6 -->

organization
(v) Any research/ innovative measure involving official
recognition vi) any other information.
(Note: Enclose a separate sheet if the space is insufficient)
17. Please state whether you are applying for deputation
(ISTC)/Absorption/Re-employment Basis. #(Officers under
Central/State Governments are only eligible for “Absorption”.
Candidates of non-Government Organizations are eligible only
for Short Term Contract)
# (The option of ‘STC’ / ‘Absorption’/’Re-employment’ are
available only if the vacancy circular specially mentioned
recruitment by ‘STC’ or “Absorption” or “Re-employment”).
Po
| have carefully gone through the vacancy circular/advertisement and | am well
aware that the information furnished in the Curriculum Vitae duly supported by the
documents in respect of Essential Qualification/Work Experience submitted by me will also
be assessed by the Selection Committee at the time of selection for the post. The
information / details provided by me are correct and true to the best of my knowledge and
no materials fact having a bearing on my selection has been suppressed/withheld.
(Signature of candidate)
Address--------------------—------
Date----------------------

<!-- page 7 -->

Certification by the Employer/Cadre Controlling Authority

The information /details provided in the above application by the applicant are true
and correct as per the facts available on records. He/she possesses educational
qualifications and experience mentioned in the vacancy Circular. If selected, he/she will be
relieved immediately.
2. Also certified that;
i) There is no vigilance or disciplinary case pending/contemplated against
Shri/Smt..
ii) His/Her integrity is certified.
iii) His/Her CR Dossier in original is enclosed / photocopies of the ACRs for the last 5
years duly attested by an officer of the rank of Under Secretary of the Govt. of India or
above are enclosed.
iv) No major/minor penalty has been imposed on him/her during the last 10 years Or A
list of major/minor penalties imposed on him/her during the last 10 years is enclosed. (as
the case may be)

countersigned
(Employer/cadre controlling authority with seal)
