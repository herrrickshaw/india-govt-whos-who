---
doc_id: "4cef8f05b99bfe0e"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/35334f7c00928d316ed1590ba0f49c41.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment to the License Agreement for security related concerns for expansion of Telecomm Services in various zones of the country (dated 15.12.2009)- All MNP Service Licensees."
date: "2009-12-15"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "1730326a2f0b4b43"
---

<!-- page 1 -->

oo
ca
yew G toflndia ”
oy न overnment of India
“oo ~ yo" | “4 है Ministry of Communications & IT
a“ a न : fish Department of Telecommunications
eon ye (AS¢1 Cell)
छा \ pe Sanchar Bhavan, 20, Ashoka Road, New Delhi - 110 001.
ee है
No. 800-67/2009-VAS Dated: 15" December, 2009
To
All MNP Service Licensees
Subject: Amendment to Licence Agreement for security related concerns for expansion
of Telecom Services in various zones of the country
With reference to the amendments issued vide Department of Telecommunications
No. 800-67/2009-VAS dated 9" December, 2009 on the above subject, this is to clarify to all
MNP service licensees that amendments mandating the licensee to apply to the Licensor for
security clearance, before placement of the final purchase order for procurement /
upgradation of equipment / software for provisioning of telecommunications services under
the licence shall also include any such activity by the franchisee, agents or persons of that
licensee.
Neh ०1]
(Vinod Kumal
Director(AS-I1}
Tele: 23718054
Copy to:
1. Secretary, TRAY, New Delhi ~
2. Wireless Advisor, WPC Wing, New Delhi
3. Sr.DDG(WPF), DoT, New Delhi
4, DDG(Security) / DDG(AS-ID / DDG(AS-D / DDG(LF) / DDG(CS), DoT, New Delhi
>: DDG(C&A), DoT, New Delhi for publishing on the DoT website |
6. Respective licence agreement files
4
0
yA Vy
yee
