---
doc_id: "4c9ddda3f1ed5af3"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/307245ce06ea663dc6384f0b176013df.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of ILD Licensees as on 30.09.2022"
date: "2022-10-28"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "653b86266efa4f03"
---

<!-- page 1 -->

List of ILD Licensees as on 30.09.2022

1

SUMMARY
S. No.
1
2
3
4

Type of License
Standalone ILD
UL(ILD) authorization
Total No of ILD
UL(ILD) VNO authorization
Under insolvency/surrender/wound up

No. of licensee
16
15
31
10
5

1. List of Companies having ILD Service License before UL regime.
Sr. Name of Company
No.

License No.

Effective Date
of License

1
2

10-10/2002-BS-I (ILD-01)
10-17/2006-BS-I (ILD-06)

25.02.2002
11.07.2006

10-43/2006-BS-I (ILD-07)

09.10.2006

10-08/2006-BS-I(ILD-13)

08.08.2007

10-07/2007-CS-III (ILD-14)

03.01.2008

10-82/2007-CS-III (ILD-16)
10-32/2002-BS-I (ILD-17)
10-78/2007-CS-III(ILD-18)

28.02.2008
18.06.2008
20.06.2006

10-71/2008-CS-III(ILD-20)

03.10.2008

10-90/2008-CS-III(ILD-22)
10-68/2010-CS-III(ILD-26)

05.03.2009
11.10.2011

3
4

5
6
7
8

9
10
11

M/s Reliance Communications Limited
M/s BT Global Communications India Pvt. Ltd
(Formerly M/s i2i Enterprises Ltd.)
M/s AT&T Global Network Services India Pvt.
Ltd.
M/s Vodafone Idea Limited (previously held by
M/s Spice Communications Limited has been
transferred)
M/s Verizon Communications India Private
Limited
M/s P3 Technologies Pvt Ltd.
M/s Mahanagar Telephone Nigam Ltd.
M/s Orange Business Services India Network Pvt.
Ltd (Formerly Equant Networks Private Ltd).
M/s Shyam Spectra Pvt. Ltd. (Erstwhile M/s
Citycom Networks Pvt. Ltd)
M/s Singtel Global (India) Private Ltd.
M/s Telstra Telecommunications Pvt. Limited

2. List of Companies having ILD Service authorization under UL regime.
Sr. Name of Company
No.

License No.

1
2
3
4
5

M/s Reliance Jio Infocomm Limited
M/s Sprint Telecom India Private Limited
M/s Sify Technologies Limited
M/s Rail Tel Corporation of India Ltd.
M/s NTT Communications India Network Services
Private Limited
M/s Lightstorm Telecom connectivity Pvt. Ltd.
M/s Bharat Sanchar Nigam Ltd.

20-401/2013(AS-I)
20-419/2014-AS-I
20-408/2013-AS-I
20-517/2016-AS-I
10-77/2015-CS-III dated
02.12.2015
20-1212/2020-AS-I
20-1206/2020-AS-I

M/s Assam Electronics Development Corporation
Ltd.

20-579/2018-AS-I dated
30.12.2017

6
7

8

ADG(CS-III), Carrier Services Wing, DoT HQ �

Effective
Date of
Authorization
21.10.2013
29.08.2014
27.06.2014
18.10.2016
25.08.2020
28.08.2020
29.02.2020
Date of signing
10.12.2020
29.07.2021

<!-- page 2 -->

List of ILD Licensees as on 30.09.2022

9
10

M/s Ringcentral India Pvt. Ltd.
M/s Bharti Airtel Ltd

20-1244/2021-AS-I
20-430/2014-AS-I dated
03.03.2014

11

M/s Tata Communications Ltd.

821-78/2014-DS dated
24.01.2014

12
13
14
15

M/s Centurylink Communications India Pvt. Ltd.
Ms/ Datawave Networks Private Limited
M/s Powergrid Teleservices Limited
M/s Adani Data Networks Limited

20-1255/2021-AS-I
10-71/2020-CS-III
20-1302/2022-AS-I
20-1327/2022-AS-I

2
31.08.2021
14.03.2022
Date of signing
24.08.2021
01.04.2022
Date of signing
08.12.2021
28.01.2022
29.03.2022
11.05.2022
26.08.2022

3. List of Companies having ILD Service authorization under UL(VNO) regime.
Sr. Name of Licensee
No.

License No.

1.

M/s NTT Communications India Network Services
Private Limited
M/s West Unified Communications India Pvt Ltd
M/s Velrush Business Networks Private Limited
M/s Bharti Airtel Ltd
M/s Tata Communications Ltd.
M/s GPX India Services Pvt Ltd

20-537/2016-AS-I

Effective
Date of
Authorization
20.08.2020

20-592/2018 AS-I
20-1233/2020-AS-I
20-1218/2020-AS-I
20-1246/2021-AS-I
20-1277/2021-AS-I

31.07.2019
24.06.2021
21.10.2021
26.11.2021
01.02.2022

M/s Simple Telecom Private Limited
M/s ZVC India Private Limited
M/s Webex Communications (India) Private
Limited
M/s Veeno Communications Private Limited

20-1281/2021-AS-I
20-1310/2022-AS-I
20-1214/2020-AS-I

25.03.2022
24.05.2022
25.05.2022

20-1176/2019-AS-I

09.09.2022

2.
3.
4.
5.
6.
7.
8.
9.

10.

4. List of ILD Licensee which are under insolvency/ wound up/applied for surrender
Sr.
No.
1.

Name of Licensee

License No.

M/s Dishnet wireless Limited

10-04/2006-BS-I(ILD-10)

2.

M/s Tulip Telecom Ltd.

10-29/2006-BS-I(ILD-12)

3.

M/s Etisalat DB Telecom Pvt Ltd (formerly M/s
Swan Telecom Pvt. Ltd.)
M/s Videocon Telecommunications Ltd
(formerly M/s Datacom Solutions Private
Limited)
M/s Unitech Long Distance Communications
Services Ltd.

10-86/2008-CS-III(ILD-21)

4.

5.

10-31/2008-CS-III(ILD-23)

10-41/2008-CS-III(ILD-24)

********
ADG(CS-III), Carrier Services Wing, DoT HQ

Effective Date
of License
13.12.2006
(Under
insolvency)
08.08.2006
(Wound up)
06.10.2008
(Wound up)
18.03.2009
(Under
insolvency)
28.04.2009
(Applied for
Surrender)
