---
doc_id: "4a2abbe42b75cbe9"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/Public_Tender_Notice_1114_15102026.pdf"
ministry: "Department of Space"
title: "URSC/PUBLIC TENDER NOTICE No.29/B/2026-27 Dated:05-10-2026      202.98 KB"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "051cc6f1ab66f36a"
---

<!-- page 1 -->

भारत सरकार, अंतररक्ष तवभाग/Government of India, Department of Space
यू.आर. राव उपग्रह केन्द्र (यू.आर.एस.सी.)/U R Rao Satellite Centre [URSC]
(पूवि में इसरो उपग्रह केन्द्र/(Formerly known as ISRO Satellite Centre)
एच.ए.एि. एयरपोटि रोड, तवमानपुरा पोस्ट,
HAL Airport Road, Vimanapura Post,
बेंगिूरु/Bengaluru - 560 017
भारत/India

URSC/PUBLIC TENDER NOTICE No.29/B/2026-27

05-10-2026

भारत के राष्ट्रपतत की ओर से व. प्रधान, क्रय एवं भं डार, यू .आर. राव उपग्रह केन्द्र (यू .आर.एस.सी.) तनम्न मद
की आपूतति के तिए केवि ई-प्रापण के जररए तनतवदाएं आमंतित करते हैं ।:
On behalf of the President of India, Sr. Head, Purchase & Stores, U R Rao Satellite Centre
[URSC] invites tenders ONLY through e-procurement for supply of the following.
दो भाग निनिदा/ Two Part Tender
क्र.सं .
Sl. No.

निनिदा संदभभ
TENDER REFERENCE

01

URSC/CE/FACILITIES/2026001114

संनिप्त नििरण
BRIEF DESCRIPTION
128-चैिल डे टा अनिग्रहण प्रणाली
128-Channel Data Acquisition System

बोली प्रस्तुत करिे की प्रारं नभक नतनि/Bid Submission Start Date

:05.10.2026 (12.35 Hrs.)

बोली स्पष्टीकरण की नतनि /Bid Clarification Date up to

:19.10.2026 (17.00 Hrs.)

बोली प्रस्तुत करिे की नियत नतनि/ Bid Submission Due Date

:26.10.2026 (10.00 Hrs.)

बोली खोलिे की नतनि/Bid Opening Date

:26.10.2026 (10.30 Hrs.)

वैध तडतजटि हस्ताक्षर प्रमाणपि (डी.एस.सी) रखने वािे इच्छु क तनतवदाकार https://eproc.isro.gov.in
पर िॉग इन करके अपना प्रस्ताव ऑनिाईन भेज सकते हैं । कोई तनतवदा शुल्क िागू नहीं है ।
Interested Tenderers having valid Digital Signature Certificate [DSC] may login to
https://eproc.isro.gov.in and submit Offers online. No Tender fees applicable.
उपरर-तनतदि ष्ट् तदनां क पर तनतवदाएँ खोिी जाएँ गी। योग्य तवक्रेताओं की दर-बोिी (दो भाग तनतवदाओं के
मामिे में) खुिने की समय-सूची बाद में सूतचत की जाएगी। प्रततभागी तवक्रेताओं द्वारा बोिी-संबंधी तववरण
इसरो ई-प्रापण पोटि ि में िॉतगन करके दे खे जा सकते हैं ।

Page 1 of 2

<!-- page 2 -->

Tenders will be opened on the date specified above. Schedule for opening of the Price
Bid (in case of Two-Part Tenders) of Qualified Vendors will be intimated later. Bidding
details can be seen by the participated vendors by logging into ISRO e-procurement
portal.
उपयुिक्त के सं बंध में शुद्धिपि/अनुशेष, यतद कोई होगा, तो उसे हमारे ई-पोटि ि एवं वेबसाइट पर प्रकातशत
तकया जाएगा।
Corrigendum/Addendum, if any, related to above shall be hosted in our e- portal and
Website.

-sdव. प्रधान, क्रय व भंडार / Sr. Head, Purchase & Stores

Page 2 of 2
