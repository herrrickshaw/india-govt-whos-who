---
doc_id: "4a5b9ae2a5f1d5be"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/45f4620a7704fb1a6ee5aaf21624dd7a.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Enhancing S&T-Based Entrepreneurship: The Role of Incubators and Public Policy"
date: "2018-05-16"
pages: 145
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5924f6f1524c37d7"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

1

<!-- page 4 -->

II

<!-- page 5 -->

ACKNOWLEDGMENTS
The authors would like to acknowledge with deep gratitude the various
individuals – too numerous to be listed here individually – who gave freely
of their time and expertise to help us develop a deeper and more nuanced
understanding of incubators in the country. We particularly would like to
thank the chief executives (as well as their colleagues) of the case–study
incubators for opening their doors and minds to us.
The authors also would like to acknowledge the Department of Science
and Technology for its generous financial support for the project through
the DST Center for Policy Research at IIT Delhi. The authors also gratefully
acknowledge Professor Venkatesh Narayanamurti at the Science,
Technology, and Public Policy (STPP) Program at the Belfer Center for
Science and International Affairs at Harvard Kennedy School (HKS) for the
support to Kavita Surana through a post-doctoral fellowship.

III

<!-- page 6 -->

<!-- page 7 -->

III

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

DST CENTRE FOR POLICY RESEARCH INDIAN INSTITUTE OF TECHNOLOGY

AUTHORS
Kavita Surana is an Associate at the Belfer Center for Science and International Affairs at Harvard Kennedy School, where she was previously a
Postdoctoral Fellow in the Science, Technology, and Public Policy Program.
Her research interests are at the intersection of early-stage technological
innovation and public policy, with a particular focus on clean energy technologies. She currently serves as a consultant to the World Bank and other
organizations on issues related to innovation policy and clean energy.
Kavita worked at the French Atomic and Alternative Energies Commission
(CEA) during her Ph.D. in Materials Science and Engineering from the
Institut Polytechnique de Grenoble (INP-Grenoble), France. She was an
Erasmus Mundus scholar at Paul Sabatier University, Toulouse, France and
holds a B.Sc. in Physics from St. Stephen’s College, Delhi University, India.
Anuraag Singh currently works for Honda R&D Japan in Tokyo. He is part of
a small team, called THINK Lab, which helps create long term strategy for
the company with a focus on understanding people’s minds and their lives.
After completing his undergraduate studies in Mechanical Engineering
at IIT Delhi, he joined as an automotive interior designer at the Honda
R&D automobile headquarters. While at DST-CPR he did innovation
policy research, particularly innovation assessment and incubators. He
is currently focused on understanding the dynamics of complex systems
and interested in questions relating to human cognition, product design,
robotics and the interplay between technologies, individuals and societies.
Ambuj Sagar is the Vipula and Mahesh Chaturvedi Professor of Policy
Studies and the founding Head of the School of Public Policy at the
Indian Institute of Technology Delhi. Ambuj’s interests broadly lie at the
intersection of technology and development. His recent work has focused
on innovation policy for meeting sustainability and inclusivity challenges,
energy innovation policy and strategies (in areas such as bio-fuels, clean
cookstoves, coal power, automobiles, and institutional mechanisms such
as climate innovation centers), climate change policy and politics, capacity
development, and higher education policy.
Ambuj did his undergraduate studies in Mechanical Engineering at IIT
Delhi. He subsequently received an M.S. in Aerospace Engineering from
the University of Michigan and then an M.S. in Materials Science, a
Ph.D. in Polymer Science, and an M.S. in Technology and Policy from the
Massachusetts Institute of Technology.

ix

<!-- page 12 -->

<!-- page 13 -->

DST CENTRE FOR POLICY RESEARCH INDIAN INSTITUTE OF TECHNOLOGY

CONTENTS
Executive Summary
1.
Introduction
2.
Methodology
3.
Innovation, Entrepreneurship, and Economic Development
Background
The role of public policy
Incubation as a policy instrument
Innovation, startups, and incubation around the world
4.
Incubation and S&T Innovation-based Entrepreneurship in India
Barriers to innovation and consequences for startups
Landscape of S&T-based innovation and incubation
Evolution of incubation from a policy perspective
Incubators and other actors in the innovation system
Government departments
Incubators
Incubator partners
External partners and networks
5.
Insights from Case Studies: Factors for Favorable Incubator Outcomes
Identifying and attracting good ideas
Strategic choice of incubator model
Addressing investment gaps for startups
Focus on sustainable incubator models
Access to multi-faceted networks
Centrality of leadership
6.
Lessons Learnt and Recommendations
Broadening and deepening the pipeline of entrepreneurs
Incubator strategy, management, and operations
Overcoming market failures
System-level support and coordination
7.
Conclusions
8.
Bibliography
9.
Appendices
Appendix A: List of interviewees
Appendix B: International examples of incubator programs
Appendix C: List of incubators with government support
Appendix D: Government initiatives to support incubators and startups
Appendix E: Case Studies
E-1: Center for Innovation Incubation and Entrepreneurship (CIIE) Indian

1
9
11
12
12
13
14
15
17
17
19
20
22
22
25
26
27
28
28
30
30
31
31
32
33
33
34
35
37
43
44
49
51
52
54
60
63
65

Institute of Management, Ahmedabad
E-2: Centre for Cellular and Molecular Platforms (C-CAMP), Bengaluru
E-3: Incubator at IKP Knowledge Park (IKP), Hyderabad
E-4: Technology Business Incubator at Kongu Engineering College

77
85
93

(TBI@KEC), Erode
E-5: Society for Innovation & Entrepreneurship IIT Bombay (SINE), Mumbai
E-6: Startup Village (SV), Kochi

117
123

xi

<!-- page 14 -->

<!-- page 15 -->

EXECUTIVE
SUMMARY

<!-- page 16 -->

<!-- page 17 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

EXECUTIVE
SUMMARY

ship in India. The most prominent actors include,
among others, incubator program managers from
different government departments, incubator managers, and incubatees. The analysis builds on insights
from semi-structured interviews and a workshop
with participation from various incubators across
the country, desk research (from policy documents,
public and private reports, and newspaper articles),
collated data on publicly-funded incubators, and
detailed case studies (of incubators seen as prominent in meeting their individual goals and contributing to building the entrepreneurial ecosystem).
The report finds that public policy goals for
incubation and S&T-based startups evolved over the
past three decades, even though publicly-funded
incubators continue to share several characteristics.
The initial public policy focus on promoting self-employment changed to prioritizing academia-industry
linkages, promoting technology transfer, and eventually to focusing on creating innovative enterprises. Most incubators continue to be not-for-profit
entities with a host partner that is often a public or
private academic (or research) institute, established
primarily through programs run by the Department
of Science and Technology (DST) and to a lesser
extent from Department of Biotechnology (DBT). The
majority of incubators are located in clusters around
metropolitan Tier I cities of Hyderabad, Chennai,
Bangaluru, Delhi, and Ahmedabad, albeit with a
few exceptions. Incubators receive public financial
support for their operations from multiple government departments; however, the most prominent
support comes for an initial five years from the DST
after which incubators are expected to sustain their
own business. These publicly-funded incubators also
facilitate financing for incubatees through several
public funding channels. Since 2010, new publicprivate models have emerged increasing private
sector financing and industry linkages for these
incubators. Overall two sectors—i.e., information
technology (IT) and life sciences (or biotechnology)—dominate in terms of policy priorities for
sector-specific innovation and incubation.

S&T-based entrepreneurship is likely to play an
increasingly important role in India’s innovation
landscape, given the increasing focus on this in public policy, the evolution of the country’s innovation
ecosystem, and the burgeoning interest among
scientists and engineers to explore this pathway.
In the past three decades, incubators have been
the most prominent public policy tool used by the
Government of India to promote S&T-driven entrepreneurship. These incubators act as intermediary
agents designed to nurture startups with innovative,
risky ideas into marketable products by providing
infrastructure and support services, and by providing rich linkages to other actors of the innovation
system. Yet, despite three decades of experiences
with incubators, the impacts of public policy interventions for promoting S&T-driven entrepreneurship
have been mixed. Policymakers’ recently renewed
efforts to strengthen innovative S&T- and knowledge-based startups—such as Startup India and the
Atal Innovation Mission announced in 2014-2015—
will double the existing number of incubators. While
these initiatives will take a few years to pay off, a
systematic analysis of the rich experiences from
various incubator programs is imperative for making
existing and new policy efforts more effective.
This report provides a detailed analysis of the
historical experience and current landscape of publicly-funded incubation for S&T-driven entrepreneur-

3

<!-- page 18 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Insights from case studies indicate the following
characteristics common to generating effective,
successful outcomes from existing publicly-funded
incubators:

managers (and incubator founders or trustees)
who bring experience beyond academia, or have
the skills to actively leverage different actors
beyond academia

• investing time and resources in building,
identifying, and attracting good ideas—for
example, by training students and researchers
to innovate, by identifying research with
commercialization potential, or by attracting
talented innovators to the incubator

The report recommends actionable steps for policy-makers, incubator managers, and other actors
to address four key aspects that can strengthen
publicly-funded
incubators
and
S&T-based
entrepreneurship (Table ES.1).
1. Broadening and deepening the pipeline of S&T
talent can bolster human capacity for incubatees
in the form of S&T-based startups.

• operating on business models that reflect an
understanding of markets (in one or more
sectors) and with clear goals to purposefully
target specific market demands that may not be
fully addressed by the private sector

2. Purposefully aligning strategy, design, and
operations of the incubator with the context of
the incubator (geographical location, sectoral
scope, market opportunities, etc.) can create
more favorable outcomes for incubators and
incubatees.

• facilitating investments for startups—especially
early-stage investments—by administering
funding for startups from government bodies, by
managing their own seed funds or venture capital
funds, or by helping attract external investment.

3. Incubators addressing specific market failures
(such as those related to areas with high societal
benefits but low commercial returns) can help
S&T-based startups connect to financial markets
or other services.

• creating business models that ensure long-term
financial sustainability and a secure flow of
income for the incubator beyond the five-year
period of initial public financing

4. System-level coordination and assessment can
exploit synergies/ benefits between individual
incubators/ programs activities that are not
undertaken by any single entity to provide a
larger, ‘systems-level’ perspective.

• providing startups access to multi-faceted
networks for knowledge (technical, strategic,
operational, and market knowledge), mentorship,
finance, and private sector markets
• being led by dynamic, entrepreneurial incubator

Table ES. 1: Recommendations to address different gaps and barriers related to incubators and S&T-driven
entrepreneurship in India (for policymakers and program managers in white boxes, and for incubators in
light blue boxes)

1 PIPELINE OF S&T TALENT
Students lack skills in S&T driven entrepreneurship and innovation
Fund the development of new courses to build the ability to apply S&T skills to market needs:
• courses on innovation based on specific problems including those that fulfill social needs—for
example energy services, sanitation, rural areas, etc.—where students first analyze the problem
context and then apply theoretical, experiential, and practical knowledge to find S&T-driven
solutions

4

<!-- page 19 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

• courses on interdisciplinary subjects—combining medicine and engineering, technology and
society, etc. to improve understanding of market needs while generating ideas
Expand faculty-training programs on S&T-driven innovation and entrepreneurship to generate
faculty who can design and teach relevant courses for students in different specializations
• Develop entrepreneur-in-residence programs with university campuses to bring in S&T
entrepreneurs with real world experiences of creating and managing challenges associated
with product-based S&T startups
• Offer students internships, projects, and other opportunities to engage more deeply with
startups and incubators that are co-located with their university
Faculty have limited knowledge of industry and have few incentives to launch startups
Revise HR policies and UGC rules to incentivize faculty engagement in innovation and
entrepreneurship:
• flexible hiring and promotion policies where entrepreneurial activities are valued along with
academic publications and research projects
• revising UGC rules for sabbaticals or ‘study leave’ to include external employment in the
“problem environment” so faculty can interact with end-users such as healthcare institutions,
rural workers, etc.; revising UGC rules to support and fund sabbaticals for launching startups
Faculty and students have poor perception of entrepreneurship
Increase the visibility of scientists in startups through the following to ease risk perceptions about
careers in S&T-driven startups and increase interactions with university S&T researchers
• offering awards for startup scientists to encourage research with commercialization focus
• creating forum for startup scientists to share their experiences on university campuses
Revise external- and self-evaluation criteria of university success by including both corporate
placements and student-launched startups to encourage students to consider entrepreneurship
and commercialization of ideas in the same light as taking up salaried employment

2 INCUBATOR STRATEGY, MANAGEMENT, & OPERATIONS
Incubator activities are misaligned with poorly-defined incubator goals
Require incubators to define goals, along with preliminary activities and self-evaluation metrics
as part of the application procedure. These goals could include a combination of—sectoral
development, geographical development, co-location with academia, startup stage (i.e., idea
stage, early stage, or growth stage) etc.
Offer periodic guidance to incubators in articulating and adapting goals and activities to the
changing context of innovation and market needs

5

<!-- page 20 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Mandate regular self-evaluation exercises based on metrics designed to evaluate performance in
relation to goals
Incubatees lack skills in entrepreneurship
Create competitive cohort programs for incubatees on regular intervals—e.g., sector-based
accelerators—to build community, strengthen networks with industry or investors, and provide
mentoring in a more targeted manner
Offer incubatees training on a range of skills useful for entrepreneurs—e.g., startup business
models, writing business proposals, applying for grants, developing communication skills, etc.
Incubator management can be weak
Identify, invite, and train experienced professionals with business, market, and S&T experience in
incubation management to make S&T innovation-based incubation market-driven rather than
champion-driven
Incentivize talented professionals (or academics) to take up incubation management as a career
and to alleviate perceived risks, particularly in universities—for example by showcasing career
paths of prominent managers from other incubators, integrating incubator managers in university
management, etc.
Hire experienced (or well-trained) incubator managers (or CEOs) with an ability to connect
business, markets, and S&T-innovation, strong skills in leadership and marketing, and passion for
S&T-innovation Offer continued support for the entire incubator management team
(and not just managers) through systematic training, access to advisors, etc. relevant for the
incubator’s local context
Incubator funding from government sources may be insufficient
Offer flexible incubator financing (based on well-defined region- or sector-based goals and
performance indicators) instead of fixed, five-year financing through the following:
• expanding well-performing incubators and strengthening their linkages with other incubators
• offering long-term performance-based support to incubators that meet performance
requirements or have sectors with longer innovation and development cycles
• phasing out funding to incubators that fail
Initiate and incentivize public-private models for incubator financing
• supporting incubator managers in leveraging local industry or other networks to use CSR funding
for entrepreneurship
• using competitive tendering processes by public sector to select private partners for setting up
joint incubators

6

<!-- page 21 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

3 MARKET FAILURES
Startups / incubatees lack support services to validate S&T-based ideas
Create mechanisms for testing and validation of new technologies that are developed in startups
but have no established standards or mechanisms for validation
Establish centralized support services—i.e., technical services, legal and patenting services,
market research, etc.—by pooling resources to benefit regional, sectoral startup clusters (e.g.,
Hyderabad and Bengaluru with life sciences / biotech)
Facilitate connections between publicly-funded startups and public sector (central and local)
to secure advanced market commitments including provisions for public procurement of
technologies
Private sector underinvests in sectors with high societal benefits
Create a larger seed fund to support the needs of S&T-driven innovation by leveraging public
funding seed money and inviting private investments
Provide tax breaks to corporate firms for investing in incubators to increase private investments
by replacing (or complementing) CSR funding for incubators that has so far been perceived by
corporates as an additional tax
Partner with local bodies that work on societal issues and draw S&T-driven entrepreneurs to
address problems related to public goods or areas with high societal benefits but low commercial
returns where private sector will not invest, or is less likely to invest
Extend incubator network resources in regions with less developed innovation ecosystems by
partnering with local industry associations or with other industry networks to compensate for
insufficient private capital or linkages with markets
Leverage alumni networks to create venture funds for supporting startups in areas of expertise of
the university or of the incubator

4 SYSTEM-LEVEL COORDINATION AND ASSESSMENT
Actors involved with incubation have weak coordination and no formal networks
Organize meetings for different actors in publicly-funded incubators to strengthen coordination:
• annual conference for all incubatees to promote community building, share experiences, and
strengthen networks
• periodic meetings between incubator managers and program managers to enhance systematic
knowledge sharing and coordination
• meetups between sector-specific incubator and incubatee meetups through “networks of
incubators” for sharing resources, best practices, and for generating new ideas

7

<!-- page 22 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Maintain (and update) a centralized registry of all incubators that receive public-sector funding
to improve accountability of incubator performance, help government departments coordinate
incubator support efforts, and increase visibility of incubators for potential incubatees
Create open repositories of projects and problems to strengthen linkages between innovators
and markets:
• database of research projects from knowledge networks can promote collaboration for new
entrepreneurial ideas, find potential applications, or find potential customers
• database of problems identified with private companies, foundations, government departments,
etc. can attract potential innovators to find solutions
Build and maintain centralized online databases of support services and partners for startups and
facilitate startup engagements with these services:
• support services (testing and validation services, legal support for intellectual property and
patenting, technical infrastructures, etc.)
• industry and finance partners willing to work with startups
Build regional innovation ecosystems outside of metropolitan cities by mandating incubators to
include experts from regional companies or industry associations in their management
Government-led incubator programs lack systematic data or analysis on incubator activities
Develop (and regularly evaluate) sectoral and regional innovation maps to identify the landscape
of actors, their linkages, and the dynamics of innovation and to help incubators define their goals,
strategies, and activities
Conduct systematic, annual assessment of incubators and incubatees to assess performance, to
improve accountability, and to assess the long-term effectiveness of incubation programs:
• Develop a new set of indicators to analyze incubator and incubatee performance based on
innovation inputs, outputs, and outcomes and be designed to reflect the goals of the incubator
(e.g., regional development, sector-specific, etc.)
• Use a common template with indicators to collect information on incubators and incubatees
Increase the understanding of different incubator business models used in publicly funded
incubators under different contexts and goals—i.e., differences in incubator management (publicor private-sector managed), technology or startup stages (idea to early stage, early stage to
growth stage, growth to expansion stage); other goals (sector-specific, sector-agnostic, regional
development, etc.)
• Conduct a detailed assessment of different incubator business models used in publicly funded
incubators
• Make the assessment available to incubator managers and use it to advise existing and new
incubators on modifying their business models

8

<!-- page 23 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Introduction
The Government of India announced in the period
2014-2016 a set of ambitious national- and state-level initiatives to promote innovation-driven entrepreneurship through startups. At the national level,
Startup India (launched in 2016), primarily targeted
the practical barriers to innovation through: (i) easing
of complex, lengthy regulatory processes for startups, (ii) providing high-risk funding and tax incentives
to startups (with a total budget of INR 10,000 crores
to be distributed by 2020), and (iii) promoting industry-academia linkages including through 70 new
incubators, startup centers, and research parks. Also
at the national level, the Atal Innovation Mission
(AIM, launched in 2015), aimed to address socioeconomic issues through innovation by: (i) building
the capacity to innovate in middle- and high-school
students through 500 new maker-spaces known as
Atal Tinkering Labs, (ii) creating 100 new sector- or
technology-specific incubators, and (iii) extending
support for existing incubators. At the state-level, 15
state governments introduced specifically designed
startup policies between 2014 and 2016.

over three decades, formally initiated through the
establishment of the National Science and Technology Entrepreneurship Development Board (NSTEDB)
in 1982. The involvement of government in
stimulating startup activity has been motivated by
multiple public policy goals that include generating
economic growth, creating employment opportunities, and supporting regional development.
Incubators have been central to public-policy
engagement with S&T startups in India. Between
1985 and 2014, over 140 incubators were established
across India with public funding1. These incubators
were established to act as intermediary agents that
reinforce the innovation system and link its interrelated groups of actors, i.e., governments, universities,
and firms, operating under an institutional context
(where institutions refer to policies, cultural norms,
etc.). Incubators therefore operate with the aim of
providing a conducive environment to help convert
innovative, risky ideas into enterprises.
The outcomes of three decades of public-policy
interventions to support S&T driven innovation and
entrepreneurship in India have been mixed. On the
one hand, despite the public sector support for
incubators, it is the private sector that has
produced an exponential rise in the number of startups in recent years. Estimates on the number of pri-

While recent policy initiatives acted as a much-needed catalyst to build the Indian startup ecosystem and
to strengthen the broader innovation system, the
government’s association with startups is not new.
Public policy support for innovation- and science and
technology (S&T)-based startup creation extends to

Author calculations with incubator data from DST, NSTEDB, DeitY, DBT, DSIR, and MoMSME.

1

9

<!-- page 24 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

vate sector incubators and accelerators indicate a
37.5% increase from 80 in 2014 to 110 in 2015 while
estimates on the number of startups indicate a 71%
increase from 700 in 2013 to 1200 in 2015 (NASSCOM, 2015). On the other hand, while India has
the third largest number of startups in the world,
as per estimates from NASSCOM, India lags behind
in several indicators of innovation and in linking innovation to markets. For example, the business and
innovation environment in India is generally poor
demonstrated by the relatively weak ranking on the
ease of doing business index (130/189) and on the
global innovation index (66/128) (Cornell University
et al., 2016; World Bank, 2016).
As policymakers renew goals for promoting innovative S&T- and knowledge-based enterprises—including by nearly doubling the number of publicly-funded incubators—a systematic analysis of three
decades of incubation experiences can offer useful
lessons. This report on publicly funded incubators in
Indiaaims to (1) understand the factors that effectively
contributed to building and strengthening the
startup ecosystem and innovation system, and
(2) provide evidence-based recommendations
to strengthen incubator activities for S&T-based
innovation and entrepreneurship. This report analyzes how incubator activities evolved over time
under different policy objectives, drawing on a
number of semi-structured interviews with a
range of experts and practitioners (see Appen-

dix A, page 51), six detailed case studies (see
Appendix E) on different incubators, the authors
own analysis, and insights from a workshop with
representatives from a number of incubators.
Through this, we specifically aim to address the
following questions: (a) How have the goals and
activities of policymakers and other actors evolved
in the context of incubation and startup creation?
(b) How have the outcomes and determinants of
success of incubators been shaped by goals and activities of different actors?
The rest of this report is structured as follows.
Chapter 2 describes the methodology. Chapter 3
offers a detailed review of the scholarly literature on
the role of public policy in supporting innovation and
entrepreneurship through incubators. Chapter
4 provides the landscape of policies, the most
relevant actors, and their activities and how these
have evolved over time for promoting S&T-based
innovation and entrepreneurship in the Indian
context. Chapter 5 discusses the findings from case
studies of six publicly-funded incubators in India
and identifies factors that contribute to successful
incubation outcomes. Chapter 6 discusses the most
pressing gaps for incubators and provides concrete,
actionable recommendations for policymakers
and for incubators to strengthen S&T-driven
innovation, incubation, and entrepreneurship.
Chapter 7 concludes.

10

<!-- page 25 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Methodology
This report on analyzing and strengthening publicly funded incubators for S&T-based entrepreneurship is based on the following six steps drawing on
desk research, semi-structured interviews, and case
studies. First, we conducted high-level interviews to
understand key priorities, challenges, and needs related to publicly-funded incubators and S&T driven
entrepreneurship in India (see Appendix A for list of
interviewees). Second, we conducted a detailed review of public policy involvement inincubators and
incubation programs in countries around the world,
and on how these programs are designed and analyzed. Third, we assessed the current and historical
landscape of S&T driven entrepreneurship, innovation, and incubation in India using policy documents,
public and private reports, and high-level interviews.
Fourth, with the help of experts, we identified six
incubators that exhibit particularly favorable incubation outcomes.We conducted detailed case
studies on these incubators using semi-structured
interviews with a variety of personnel involved with
these incubators (i.e., incubator managers, incubatees, members of the management team, etc.).
Fifth, we identified common factors from these six
incubators that determine successful incubator outcomes. Sixth, based on our insights from interviews
and case studies, we developed recommendations
to strengthen S&T driven innovation and incubation

in India. We further refined these recommendations
based on consultations with various incubator representatives in a workshop that discussed the findings of this report.
There is no formal (and regularly maintained)
database of incubators making it difficult to
systematically assess over time all incubators, their
interactions with government and other actors, or
their changing goals, priorities, outputs, outcomes
etc. We address this issue in three ways. First, we
created our own database of all publicly funded
incubators and analyzed the different channels of
public funding from 1985-2014. Second, because
the focus of this report is on incubators, our
interactions with other actors of the innovation
system—i.e., funding agencies, incubatees and
startups, investors, universities, national and statelevel policymakers, etc.—were aimed at developing
a broad perspective on incubators (see Appendix A).
Third, while our interviews and six case studies are by
no means an exhaustive representation of incubation
activities in India, they represent incubators with
access to different types of resources (e.g., location
in metropolitan Tier 1 city vs. location in a Tier III
city), different sector-related priorities (e.g., biotech
vs. information technology), and different university
partners (e.g., engineering school vs. business school).

11

<!-- page 26 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Innovation, Entrepreneurship,
and Economic Development
Before exploring the state of incubators and
S&T-driven entrepreneurship in India, we review
(i) key literature on the importance of innovation
and entrepreneurship for economic development,
(ii) why and how public policy plays a role in shaping
these, (iii) what incubators do and why incubators
are a commonly used policy tool for innovation, and
(iv) how incubators have been used by policymakers
in the rest of the world to promote innovation.

Background
In this report, the term ‘innovation’ encompasses the
creation or adaptation of new technologies, products,
processes, and business ideas and their translation
into practical application. Effective innovation is a
product of a well-developed innovation system—
aset of actors (e.g., governments, universities,
and firms) that collaborate and interact under an
institutional context (where institutions include

policies, social and cultural norms).
The interactions between innovation, entrepreneurship, and economic development are well
documented (OECD, 2013a; Szirmai et al., 2011).
As actors central to the innovation system,
entrepreneurs contribute to innovation by creating
new enterprises (or startups) that commercialize
new technologies, bring new technologies to market,
or create new ways of using existing knowledge.
Entrepreneurs discover and exploit opportunities,
transfer resources towards more productive uses
and increase efficiency, thus creating and adding
economic value (Acs and Storey, 2004; Audretsch
et al., 2007; Shane and Venkataraman, 2000).
The coupling of innovation and entrepreneurship
through startups can create new opportunities for
employment and increase industrial competitiveness,
thus driving regional economic development and
growth. To this end, efforts to replicate the Silicon
Valley model have emerged around the world.

Box 1: What is a startup?
While there is no single definition of the world “startup”, the term startups has been used broadly to new enterprises that
are associated with a combination of market impact (high-growth, job creation, gazelles), innovation content (innovation
from research and development, new processes, etc.) (OECD, 2013). Startups are formed after the initial idea or seed stage,
followed by growth, and expansion. The government of India defines starts-up as follows (Ministry of Commerce and Industry,
Government of India, 2016):
A startup is an entity, incorporated or registered in India not prior to five years, with annual turnover not exceeding INR 25
crore in any preceding financial year, working towards innovation, development, deployment or commercialization of new
products, processes or services driven by technology or intellectual property.

12

<!-- page 27 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Globally, innovation-driven economic growth is
widely accepted as an underpinning foundation to
meet socio-economic development challenges (e.g.,
(Audretsch et al., 2007; OECD, 2013a, 2013b). Technological innovation and technological change have
been instrumental in meeting human development
goals while simultaneously supporting sustainable
growth and shaping current societies. The synergies
between innovative startups and economic growth
are widely declared by policymakers, investors, and
academics as an engine for innovation-led growth in
developing countries.
However, while many countries and regions associate entrepreneurship with innovation and they design policies to facilitate one or the other in hopes
of achieving economic growth, not all entrepreneurs
innovate (Audretsch et al., 2007; Autio et al., 2014).
A recent study on 60 countries indicates that the
share of innovative ventures among new enterprises varies from 20% to 30%, and in certain cases, high
entrepreneurial activity may even accompany lower
innovation (Kelley et al., n.d.). Spurring innovation
based enterprise creation therefore requires policymakers to consider “not whether entrepreneurs
innovate, but rather, when and where they do so”
(Autio et al., 2014). This means consideration and
manipulation of the context that may have key differences between industry sectors and regions.
The emergence of innovative startups therefore
requires favorable conditions reflected in the
strength and quality of the innovation system. In
developing countries—where the potential to benefit from innovative startups is particularly high—
institutions and markets are often underdeveloped
and unpredictable, in what is known as “institutional
voids” (Khanna and Palepu, 1997). The immature
innovation system in developing countries often
means that startups face barriers related to limited human and financial resources, have poor
infrastructures, and have limited access to markets
where they can sell their products.

13

The role of public policy
The role of the government and public policy is key
in strengthening the innovation system and in creating enabling conditions favorable to startups for innovation-led economic growth. However, S&T-driven startups have a particularly high likelihood of
failure because of their inherently risky ideas that
require human resources with strong S&T foundations, a business-friendly environment, often a focus
on physical products whose development, manufacture, and sales require a large supporting cast of
characters, and access to high-risk financial capital.
The combination of these factors exacerbates barriers for S&T innovators who may not be well connected with business- and market-related aspects
of their startups. For example, the S&T innovator
or entrepreneur is often familiar with the limits of
technology while the investor is better connected
with markets and customers; innovators who get
grants or seed funding from the public sector at the
idea stage need a well-developed financial sector
that can support the startup through different stages
for expansion and growth; innovators often lack the
business or entrepreneurial skills to convert their
invention into an innovative product through an
effective business plan. The success of startups
therefore depends in significant part on the quality
of the innovation system and the strength of its networks and linkages between different actors.
Creating enabling conditions for startups by policymakers therefore requires building an innovation
system that allows the development of new knowledge and technologies or their integration into
markets and offers sufficient opportunities for
smooth knowledge flows between different actors.
This requires a mix of policies that depend on the
country- and region-specific context and conditions,
as there is no “one size fits all” solution.
Across the world, public-policy instruments and
governments have supported startups through different stages, in particular at the earliest stage.

<!-- page 28 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Direct government-driven initiatives for startups
include programs for university-based startups and
technology-based economic development (e.g.,
incubators, accelerators, science parks, etc.) and
formal programs for direct financing or grants such
as the Small Business Innovation Research (SBIR) in
the US (Grimaldi et al., 2011). Under the right mix
of policies, government participation can help to
absorb risks associated with early-stage startups
while sending signals to the private sector to invest
as these startups grow. Indirect government-driven
activities that underlie successful startups include
building capacity and human resources through
universities, technology transfer offices, and provision of entrepreneurial training. More broadly, governments manage the regulatory framework and
business environment under which startups operate and can greatly facilitate startup investments by
creating supportive conditions for angel investors
and venture capitalists. Overall, public policy plays a
central role in directly or indirectly strengthening the
linkages between startups and other actors of the
innovation system.

Incubation as a policy
instrument
Incubation is a long standing policy tool used worldwide to create favorable conditions for promoting
innovation-based startups. Incubators are formally

organized entities that support the conversion of individual ideas from early stage innovation to marketable enterprises and they facilitate startup activity
by strengthening the context (or ecosystem) under
which startups operate. They also act as intermediaries that link startups with other actors of the
innovation system—i.e., entrepreneurs, universities,
researchers, government officials, policymakers,
investors, etc.—with the aim of correcting market
failures where the private sector fails to provide
investment (or other support) to expand new ideas
(Dutt et al., 2015).
Incubators provide a combination of support
services for startups that includes infrastructure
(working space and associated basic physical infrastructure, workshops), finance, business capability
(mentoring, training, consulting), and access to networks. (Amezcua et al., 2013; Cohen, 2013; Dee et
al., 2011; Dutt et al., 2015; Hackett and Dilts, 2004).
Incubators can be linked to several related configurations that include science parks, business parks,
innovation centers, accelerators, etc. (Table 1).
Incubators provide long duration support for new
enterprises (up to five years) and often generate
revenues by renting out space; in comparison
accelerators are primarily driven by investments and
returns, they support enterprises in batches with
intervals of three months, and are inherently more
competitive (Cohen, 2013).

Table 1: Characteristics of incubators, accelerators, and hybrids (based on Cohen, 2013; Hathaway, 2016)
Characteristics

Incubators

Accelerators

Hybrids

Duration

1 year – 5 years

3 months – 6 months

3 months – 2 years

Cohorts

No

Yes

No

Business model

Non-profit

Investment; can be non-profit

Investment; can be non-profit

Selection

Non competitive

Competitive; cyclical

Competitive; ongoing

Venture stage

Early or late stage

Early

Early

Mentorship

Minimal

Intense

Staff expert support;
Moderate mentoring

Location

On-site

Off-site (virtual incubation)

On-site Off-site;
(virtual incubation)

14

<!-- page 29 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Although typically incubators are not-for-profit and
often receive varying levels of assistance from public
funding bodies (Cohen, 2013; Dee et al., 2011; Hackett and Dilts, 2004), in recent years there also has
been a rise of commercial incubators.
While incubators provide specific support services for startups, effective incubation has three requirements. First, incubators require access to human resources that have the capacity to innovate,
engage in entrepreneurial activity, and create startups. To this end, incubators often have close linkages with universities and research centers, often
in regional hubs. Universities provide incubators
access to knowledge-based assets—such as technically-trained students and faculty—and incubators
thus benefit from localized knowledge spillovers
(e.g., Jaffe et al., 1993; Rothaermel and Thursby,
2005a). Linkages with universities are found to help
in startup survival (Rothaermel and Thursby, 2005b)
and with developing networks (McAdam and McAdam, 2008). Furthermore, the concentration of startups in a region can promote entrepreneurial culture,
information sharing, and knowledge spillovers within and across firms and academia, thus resulting in
additional innovations (Saxenian, 1996). Second,
incubators require the ability to provide exit mechanisms for their startups to graduate and make way
for new startups. Startups can graduate through
several exit mechanisms—i.e., startups may receive
additional financing from investors, startups experience other forms of validation from markets, or they
can declare bankruptcy and close down—and incubators must be able to help startups in identifying
and managing the right exit opportunity. Third, incubators require the capacity to manage activities that
support startups. Once a startup enters the incubator, it benefits from services in the form of infrastructures (i.e., space, power and internet, technical
equipment, financing, etc.) and business capabilities
(mentors, training, etc.). Effective incubators therefore require managerial staff with the capacity to
provide adequate business and technical mentoring

15

to startups, build their linkages with markets, while
simultaneously managing incubator finances.
Besides assessing the three key requirements of
incubators listed above, ananalysis of incubator activities requires an understanding of the underlying
goals under which a particular incubator was set up
(Bergek and Norrman, 2008). These goals may be,
among others, to promote a particular technological sector, build a regional technological cluster,
transform research to innovative products, generate
employment opportunities, or contribute to development of a suburban area. The activities and outcomes of incubators have been subject to extensive
scrutiny worldwide with the aim to understand best
practices. Much of the extant analysis on incubators
focuses on their formation and functioning, their
performance outputs and outcomes, and on their
linkages with public and private actors (Bergek and
Norrman, 2008; Dee et al., 2011; Hackett and Dilts,
2004; Phan et al., 2005).

Innovation, startups, and
incubation around the world
Developed countries like Switzerland, Finland, Israel,
and USA rank high in various indicators of innovation
as they invest more heavily in human capital and
research, have stronger institutions and markets,
and have greater outputs in terms of knowledge,
technology, and creativity (Figure 1) (Cornell University et al., 2016). In contrast, with the notable exception of China, emerging economics rank low in
innovation, with low budgets for research, few R&D
personnel to innovate or to develop new technologies, less developed infrastructures, and less sophisticated markets. India, while seen as an ‘achiever,’ scores particularly low in terms of institutions
(i.e., political, regulatory, and business environment), human capital and research (i.e., education
and R&D), and creative outputs (i.e., intangible assets, creative goods and services, online creativity).

<!-- page 30 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Figure 1: India scores low in various indicators of innovation compared with other major industrialized and developing countries.
Brackets next to countries show country ranking in the Global Innovation Index, 2016. (Cornell University et al., 2016).

Many of these countries have used incubators as a
policy instrument for creating an enabling environment for startups. Appendix B illustrates how incuba-

tion has been used as a policy instrument for around
the world, with examples from Brazil, Chile, China,
Mexico, Finland, Israel, and the United States..

16

<!-- page 31 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Incubation and S&T Innovationbased Entrepreneurship in India
Barriers to innovation and
consequences for startups
The most pressing social and economic barriers for
Indian S&T innovators—and consequently for S&Tinnovation-based entrepreneurship among students and academics—are (1) the lack of capacity to
innovate in academia, (2) low support for failure,
(3) underdeveloped markets, and (4) bureaucratic
and regulatory barriers (Cornell University et al., 2016;
GIZ, 2012; GoI, 2012; LeBlanc, 2012, Interviews).
First, S&T students and researchers often lack the
capacity to innovate. The prioritization of theoretical
knowledge in higher education offers limited practical knowhow to students. While research is often
not on the cutting-edge in a majority of universities
outside of the few high ranking institutions, researchers also have had few interactions with industry or markets. This means that research outcomes
rarely translate to marketable products or services.
Second, support mechanisms for engaging in high risk
activities or for managing failure are weak—and risk
and failure together are characteristic of S&T-driven
innovation. Social and institutional support for failure in India is low while cultural aversion to risk is
high. This translates to limited innovation-based entrepreneurial activity in high-risk S&T sectors. Often,
incentives for students and researchers to engage
in innovation-based activity are misaligned with the

17

priorities of the university. For example, students’
or researchers’ activities that focus on innovation—
and thus divert from ‘traditional’ productive activities—are perceived as a waste of time and may be
associated with failure. Similarly, university success
is primarily measured through student placements
with little consideration of startup activity; universities therefore rarely encourage graduating students
to engage in innovation for creating risky startups.
Furthermore, S&T students—widely acknowledged
as key innovators in countries across the globe—are
hesitant to give up salaried jobs in favor of launching their own startups, for example over concerns
on their ability to repay student loans or because
replacing high salaries for equity shares in a startup is uncommon in India (although this has changed
somewhat in recent years). This means that innovators who do start their own ventures are unfamiliar
with the challenges of startups and often lack experience from previous failures. The reluctance of students to engage in S&T innovation-based entrepreneurship is further exacerbated by the lack of role
model innovators or startup success stories, with
few startups actually reaching an IPO stage outside
the IT sector.
Third, markets in India are underdeveloped and do
not support the discovery of new products or the
diffusion of innovation. Under developed markets
affect innovators who need stronger linkages with
the innovation system for locating mentors, inves-

<!-- page 32 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

tors, or customers, or for finding a form of market
validation for their idea (for example, additional
rounds of financing, IPOs, university spinoffs, etc.).
Regions outside of major metropolitan cities (or Tier
I cities) face the greatest obstacles. In the largest
metropolitan cities, the private sector is relatively
mature with large availability of customers, investors, and mentors for startups. However, suburban
areas or smaller towns (or Tier II and Tier III cities)
may suffer from a lack of potential investors or buyers, particularly in sectors outside of IT. Underdeveloped markets there fore particularly restrict innovation for non-IT or product-based startups (more
than service-based startups) where scaling up technology, receiving financing, and connecting to markets is difficult. Scaling up technology is particularly
challenging for non-IT startups that have no established supply chain to bring in parts and no established avenues for validation of their products (i.e.,
no quality assessment or testing opportunities).
Similarly, the availability of financing is exacerbated
for non-IT sectors due to a combination factors. On
the one hand, traditional actors in India with a high
appetite for risk—i.e., venture capital networks, high
net worth individuals, etc.—prefer investing in lowrisk fast-growth startups with late stage deals. Most

startups are therefore associated with the IT sector
outside of which there is a shortage of early stage
capital and few high profile exits of new S&T-based
enterprises. On the other hand, banks unlikely to
lend to small, new S&T-based enterprises because
of the high-risks involved. Innovators also prefer financing from venture capital rather than banks because high transaction costs with banks make them
less attractive for those who require small amounts
of capital (GIZ, 2012).
Fourth, in the event of actual innovation with commercialization potential, complex bureaucratic procedures and paperwork involved in patenting, procurement, starting or closing a company etc.put
additional pressures for time and resources on innovators and innovation-based startups (NITI Aayog,
2015). The times required to start or to close a business—i.e., 29 days to start and over 4 years to close
a failing business (World Bank, 2016)—illustrate
long regulatory delays faced by innovators and startups already strapped for resources. The costs and
lengthy procedures associated with shutting down a
business mean that many entrepreneurs keep their
defunct businesses alive on paper.

Box 2: Examples of challenges for startups in non-IT sectors
Hardware products or non-IT innovations face a lack of testing or validation mechanisms before they go to market. The usual
validation and quality control mechanisms (e.g., ISI marks of the Bureau of Indian Standards) fail as there are no standards
or precedents for new technologies and there is little capacity to test these new technologies. In a culture that is already
risk-averse, lack of product testing and validation mechanisms further limits linkages to a potential market, resulting in a lack
of buyers.
Three anecdotal examples illustrate this issue (authors’ interview with Harkesh Mittal, 2015). First, a with “startup” developed
a super-specialty wire that met highly specific requirements of the Indian Railways. Before being used in the market, the
wires needed to comply with 15,000 hours of initial product testing. With no facilities available for accelerated testing, the
startup waited for two years (and 15,000 hours) before commercializing the product. Second, an innovator created a portable
diagnostic lab in a briefcase that could perform multiple medical tests at a nominal cost. Despite commercialization potential,
the innovator could not find customers for the untested technology up until he donated five portable labs following a natural
disaster and demonstrated the effectiveness of this product. Third, a serial entrepreneur installed five cameras on a van to
gather data, monitor, and categorize condition of roads, visibility of billboards etc. The public sector was a potential market
for the product. Yet, public sector enterprises were unwilling to buy a new untested technology that had not been validated
elsewhere.
The biotechnology sector, albeit better developed, still faces issues on testing and validation. For example, startups and incubatees hosted at IKP moved abroad, citing difficulties in conducting trials, the lack of understanding of life sciences in the
venture community in India, and the consequent lack of funding.

18

<!-- page 33 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Similarly, the weak intellectual property regime
and the long-wait to process a patent application
discourages researchers from valorizing their innovation—it takes seven years or more to process a
patent application in India compared to two years
in the United States (NITI Aayog, 2015). Furthermore, laws and regulations on foreign capital flows,
foreign ownership, and equity investment are often
restrictive, limiting financing opportunities for startups. The business environment is unfavorable for
startups as India ranks 130 of 189 countries (and the
lowest among BRIC countries) on the ease of doing
business index (World Bank, 2016). However, despite these challenges, it is important to note that
new regulations announced in 2016 are expected to
reduce procedural barriers to innovation—for example, a new bankruptcy law will allow entrepreneurs
to easily close down defunct businesses.

tors. Since the early 1980s, government has been
involved inincubator-building activities primarily
through the National Science and Technology Entrepreneurship Development Board (NSTEDB). Between 1985 and 2014, over 140 incubators were established with public funding from different sources
(see Table 2 for different estimates on the number
of incubators). The NSTEDB provided INR 200 crores
in funding for incubators, evolving from around INR
20 lakhs for each incubator in the late 1980s, to an
average of INR 3 crores by 2015 (personal interview
with Anita Gupta, 2015). Public policy support for
incubation resulted in an increase in private sector
activities, too. Between 2010 and 2014, over 40 privately funded incubators were established. Between
2014 and 2016, government programs specifically
targetedstartup creation and innovation—Startup
India, National Entrepreneurship Policy, Make in
India, Atal Innovation Mission, etc. While recent efforts will take a few years to pay off, India performed
poorly in the context of linking innovation to new
enterprises and markets despite three decades of
experiences with incubators. In this context, we examine how incubators in India can be strengthened
to bring S&T-based innovation to market with the
help of startups.

Landscape of S&T-based
innovation and incubation
Indian public officials were pioneers in the developing world in using incubation as a policy tool as
much of public policy efforts in enabling S&T-innovation in startups were channeled through incuba-

Table 2: Key outcomes of incubators reflected in different reports. In addition to the data in this table, NASSCOM reports 110 incubators in India with 4200 startups in 2015. Our calculations show 146 publicly funded incubators (including those with MoMSME)
with at least 2000 startups from 1982 through 2014 (DST, 2014, 2009; NITI Aayog, 2015).

Description

Niti Aayog 2015

TBI 2014

TBI 2009

Incubators

120

54 reported

36 reported
(full or partial data)

Employment
generated

40,000

32,000+

13,400+

Startups

800+ (graduated since 1982)
500 supported annually

2000+ (incubated)
950 +(graduated)

1170+ (incubated)
486+ (graduated)

Total turnover

INR 4000+ crore turnover of
graduates and incubatees;
INR 1500 crore (total value)

INR 1500+ crore turnover
by incubatee and graduate
companies in 2012-2013

INR 1100+ crore by
incubatee and graduate companies

Other outcomes

450 patents/copyrights

19

<!-- page 34 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Evolution of incubation from a
policy perspective

promoting self-employment to strengthening academia-industry linkages, promoting technology
transfer, and creating innovative enterprises (see
Table 3).

Public policy goals for incubation and S&T-based
startups evolved over the past three decades from

Table 3: Evolution of public policy goals for S&T-based entrepreneurship and incubators in India. Source: Authors’ compilation from
FYP reports and other sources

Year

Public policy goals

Announced plans,
policies, and events

Source

1980
1981
1982

NSTEDB established

1983

First STEP established

1984
1985
1986
1987

Employment generation / self-employment for DBT set up
S&T students and personnel
Three pilot incubators with
UN Fund for S&T

Sixth Five
Year Plan

Seventh
Five Year
Plan

1988
1989
1990
1991
1992

Economic reforms

1993

Employment generation / self-employment for
S&T students and personnel;

1994

STEPs;

1995

Entrepreneurship training to for biotech;
Commercializing indigenous technology

1996
1997

Annual Plan
Annual Plan
Eighth
Five Year
Plan

Ninth

Regional development;
Entrepreneurship training

TBI established

Five Year
Plan

Academia, R&D, industry interfaces;

ISBA - Incubator Association;

Tenth

TDB seed fund

2004

Training in IT for remote, rural populations for
entrepreneurship/ self-employment;

Five Year
Plan

2005

grassroots innovation;

2006

Biotech: creation of venture capital fund, commercialization of technologies, incubators and
science parks

1998
1999
2000
2001
2002
2003

20

<!-- page 35 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

2008

Technology- and knowledge-based
entrepreneurship;

2009

Academia-industry linkages;

2010

Incubators for commercializing technology
developed at universities;

2007

2011

Biotech: incubators, parks, and clusters
through PPPs;

Service tax exempt for
NSTEDB incubators and incubatees (turnover less than
INR 50 lakhs);

Eleventh Five
Year Plan

TIDE scheme for electronics,
ICT

Venture funding and tax incentives;

2012
2013
2014
2015
2016

Attracting talent through flexible salaries,
startup grants
Building an inclusive innovation ecosystem
across sectors for entrepreneurship, growth;
Biotech: incubators, parks, and clusters to
technology transfer and management; Funding schemes through PPP, BIRAC

SME exchange

Twelfth

BIRAC as a Section-25 notfor-profit company;
BIG program launched;

Five Year
Plan;

DST, MoMSME incubators
qualify for CSR;

Public reports

Science, Technology, and
Innovation Policy;
Revision of bankruptcy laws;
Support for venture capital,
angel investors;
State governments’ startup
policy
Atal Innovation Mission
Startup India Action Plan
In the early 1980s, policymakers considered incubation and entrepreneurship as tools to create employment in individuals with S&T backgrounds (i.e.,
students and academics) and to counter large-scale
unemployment. Over time, policymakers’ goals for
incubation shifted towards building academia-industry linkages, encouraging technology transfer and
commercialization, building public-private linkages,
creating entrepreneurial activity in the biotech sector, and most recently towards building an innovation system and inclusive innovation.
Indian support for entrepreneurship and innovation
started in 1982 after the formation of the NSTEDB.
The evolution of public policy goals—reflected in

21

different five year plans—influenced incubator activities. The first incubators were set up as Science
and Technology Entrepreneurs Parks—or STEP—for
generating employment in S&T-trained personnel.
While 16 STEPs were established between 1984 and
1995—in a period where the economy was closed
and high technology was difficult to import—it is
regular enterprises (and not startups) that primarily
benefitted from STEPs (Mittal, 2015). STEPs attracted
new enterprises by offering access to infrastructures
(e.g., an improved supply of water and electricity).
However, incubated firms faced financial restraints
and did not contribute to STEP revenues—by 2001,
only 6 of 16 STEPs demonstrated promising results
and financial sustainability. Many STEPs engaged in

<!-- page 36 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

offering training and skill development workshops as
a source of revenue. Such capacity building activities generated awareness on the benefits of entrepreneurship, however the outcomes were primarily
new brick-and-mortar enterprises and not technology-driven startups (Mittal, 2015). These enterprises—with access to good infrastructures—were reluctant to vacate the STEP premises and graduate as
incubatees.
In 2001, policymakers initiated a shift from STEPs
to Technology Business Incubators (or TBI) for high
technology ventures. This shift was a product of
multiple factors, including learning from past incubator experiences and broader economic factors.
Besides the experience with STEPs, during 19871990, three pilot TBIs had been established with
support from the UN Fund for Science and Technology. However, government financial support proved
to be insufficient and the incubators failed despite
making progress in providing business plans, training, and workspace to incubatees (Lalkaka, 2002).
Furthermore, liberalization reforms after 1991 improved the availability of technology while the dotcom bubble of the late 1990s-2000 led to return of
IT-talent from outside India (Mittal, 2015). Policy
priorities shifted towards building academia-industry linkages, encouraging technology- and knowledge-based enterprise or startup creation. In 2004,
following a global conference with infoDev, the Technology Development Board (TDB) set up a seed fund
to provide grants to startups. An incubator association was created to build networks for incubators
and to share best practices (Ministry of Science and
Technology, 2004).
New incentives to create incubators for entrepreneurial and startup activities emerged after 2007.
In 2007, publicly funded incubators and their tenant incubatees became exempt from service tax. In
2013, corporate expenditure on publicly-funded incubators was recognized under the Corporate Social
Responsibility (or CSR) program. The CSR program
required corporate companies with high net worth
and profits to spend 2 percent of their profits on so-

cial issues (Companies Act). CSR funding provided
new opportunities for incubators to generate additional income and strengthen industry linkages.
Most of the publicly funded incubators were set up
with academic partners as not-for-profit entities. Between 1985 and 2014, over 140 incubators were established. Private sector participation in incubators
grew only after 2010 with over 40 privately funded
incubators and with emergence of new public-private models.
Policymakers primarily promoted two sectors for
innovation-based startups—information technology (IT) and life sciences (or biotechnology). The Department of Electronics and Information Technology
(DeitY) launched the Technology Incubation and Development of Entrepreneurs (TIDE) scheme in 2008
for promoting electronics and ICT. The Department
of Biotechnology’s goals of building public-private
partnerships in biotechnology, supporting entrepreneurs, and building an innovation system, culminated in the creation of the Biotechnology Industry
Research Assistance Council (BIRAC) in 2012. Within
a year, BIRAC had awarded 21 grants (Biotechnology
Ignition Grant) and set up 5 incubators (BIRAC).
Between 2014-2015, specific programs targeted enterprise creation and innovation – Make in India, Startup
India, and the National Entrepreneurship Policy.

Incubators and other actors in
the innovation system
Incubators are part of the innovation system where
they interact with other actors, including different
government departments, incubatees (i.e., entrepreneurs, innovators, startup founders), academic
institutions, private sector industry, etc.

Government departments
The dual needs to promote S&T-based enterprises
and to generate employment drive government involvement in incubation in India. The Department

22

<!-- page 37 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

of Science and Technology (DST), through the National Science and Technology Entrepreneurship Development Board (NSTEDB), is the primary support
body for incubators. At the national level, at least
four more departments of the central government
besides the DST are involved in implementing policies to facilitate innovative startups through incubators(Appendix D). Of these, only the DST’s NSTEDB
and the Department of Biotechnology’s (DBT) Biotechnology Industry Research Assistance Council
(BIRAC) set up new incubators. Other government
departments support established incubators with
specific mandates for promoting a particular sector
(e.g., IT) or a particular agenda (e.g., promotion of
micro, small, and medium enterprises or MSMEs).
Public policy support for entrepreneurs extends beyond incubation to provide incubatees with financing at different stages of innovation for taking ideas
to market especially because the private sector that
should fulfill this function is underdeveloped and inefficient in bringing the most viable of innovations
to market2. This direct government financing for
startups—through grants, low interest loans, or equity shares—is administered through publicly-funded incubators. Government financing for innovation-based startups targets project survival until the
demonstration or prototype stage so that startups
can get external validation from the private sector
and expand into the market.
a) Department of Science and Technology (DST)
The DST is the most prominent government department that actively promotes S&T-based startup creation through the NSTEDB3 . In the last three decades,
the NSTEDB funded over 86 Technology Business

Incubators (TBI) and Science and Technology Entrepreneurs Parks (STEP) (DST, 2014). The primary goals
of NSTEDB include the creation of S&T-based startups and enabling of technology transfer.
NSTEDB supports incubators with a partner institute
(i.e., an academic, technical, or R&D center). In its
approval process for new incubators, NSTEDB evaluates applications from potential hosts based on,
among others, the strength of the regional innovation system, demands of the geographic location,
experience of managers, incubation business model,
resources offered by the host partner etc. (NSTEDB,
2012a). Once approved, the NSTEDB provides initial five years of financial support for setting up and
managing the incubator. In addition, DST provides
funding for startups located in its incubators through
the Technology Development Board (TDB) and the
Seed Funding Scheme (SSS) that provide financial
assistance—through debt, equity share, or a share
of royalties—to technology-focused startups physically located in government-approved incubators
(NSTEDB, 2012b).
b) Department of Biotechnology (DBT)
The DBT supports innovation through BIRAC, its
public sector enterprise. BIRAC’s mandate specifically targets creating biotechnology-based startups
and converting research into products. BIRAC implements several policy instruments relevant for creating linkages between innovation and markets. Of
direct relevance for incubators is the Bio-incubators
Support Scheme (BISS) that strengthens existing and
established incubators with proven infrastructures
and business development capabilities. BISS aims to
create new incubators that can provide necessary

Additionally, the laws and regulations on foreign capital flows, foreign ownership, and equity investment are considered restrictive, and there are
restrictions on blended capital (GIZ, 2012).

2

3
The DST also oversees the National Innovation Foundation (NIF), which unlike the NSTEDB, prioritizes the informal sector, focusing on grassroots
technological innovations with societal benefits. In addition, it also provides funding for technology commercialization projects through the Micro
Venture Innovation Fund (MVIF).

23

<!-- page 38 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

equipment and support for academic-industry linkages and technology transfer. BIRAC also provides financial support for entrepreneurial activity through
several funding mechanisms—from the Biotechnology Ignition Grant (BIG) for developing early stage
proof-of-concepts to the Small Business Innovation
Research Initiative (SBIRI) for validation of early
stage ideas and for helping them grow.

Outreach cum Cluster Innovation Centers—implement the PRISM program and are responsible for
evaluating, monitoring, and coordination of grants
for startups, in addition to providing mentoring support(DSIR). The PRISM program provides funding to
individual innovators for creating early stage prototypes, technology transfer, and for late stage for
scaling up of innovation and startup creation.

Box 3: Biotechnology Industry Research Assistance Council (BIRAC)
BIRAC is a Section-25 Not-for-Profit company setup by the DBT to function as an industry-academia interface. BIRAC administers the Biotechnology Ignition Grant (BIG) that aims to bridge the gap between discovery and invention by spurring commercialization of research. BIG provides very early stage grants to scientist entrepreneurs from research institutes, academia,
and start-ups. To prevent misuse of funds, BIG requires applicants to be an incubatee in an eligible DBT incubator or to have
a registered company with a functional R&D laboratory. BIG innovators receive up to INR 50 lakh (approximately $100K) for
their research projects with commercialization potential for up to 18 months.

DBT incubator interventions (through BIRAC) differ
from DST activities due to the unique challenges
of the life sciences and biotech industry, including
(i) long gestation period of startups (about five
years) requiring longer-term incubation compared
to other sectors such as IT; (ii) high capital intensity
of startup technologies; (iii) need for highly-skilled,
trained manpower to operate technical equipment;
and (iv) lack of business models with proven financial sustainability of biotech incubators. The startups
that DBT incubators manage, coordinate, and often
host receive funding from BIRAC. Over three years
between 2012 and 2015, BIRAC supported approximately 186 startups and individual entrepreneurs
either directly (as resident incubatees) or indirectly
(as virtual incubatees or grantees) through 12 incubators (BIRAC, 2015).
c) Department of Scientific and Industrial
Research (DSIR)
The Department of Scientific and Industrial Research
(DSIR) prioritizes industry-centric research and innovation. DSIR manages a grants funding program for
incubators—Promoting Innovations in Individuals,
Startups and MSMEs, or PRISM. DSIR-financed incubation centers with experience in technology-based
innovation—i.e., TOCICs, originally known as TePP

d) Department of Electronics and Information
Technology (DeitY)
The Electronics and IT Department (DeitY) focuses
on its goals to build electronics and IT-related industries and digital services). While DeitY does not
engage in setting up of new incubators, it offers financial support to existing incubators (or their host
academic partners) by offering new financing opportunities and low interest loans for incubatees
(through the TIDE scheme). DeitY aims to generate
product-oriented growth and enhance startup linkages with markets.
e) Ministry of Micro Small and Medium
Enterprises (MoMSME)
The Ministry of Micro Small and Medium Enterprises (MoMSME) has broad goals of generating
self-employment, entrepreneurship, and employment
through SMEs (or startups), executing strategic plans
for developing clusters, and strengthening manufacturing competitiveness. These goals underpin
MoMSME’s involvement with S&T-based incubators.
Since 2008, like the DST, the MoMSME collaborated
with host institutes (academic, technical, or R&D) to
designate incubator-like entities that encourage early-stage ideas in a range of sectors (biotechnology,
nanotechnology, fruit processing, ceramics, surgical

24

<!-- page 39 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

instruments, etc.) (MoMSME, 2010). The MoMSME
also provides small amount of funding for the incubator host in addition to small grants for innovative ideas; MoMSME grants operate in a public-private-partnership (PPP) model that expects a partial
share of funding to come from the SME.
Many other incubators receive support from other central government departments (such as the
Ministry of New and Renewable Energy) and more
notably through state governments as well. Other
government departments—for example, the Department of Industrial Policy & Promotion (DIPP)
of the Ministry of Commerce and Industry—are responsible for industrial policy and new initiatives like
Startup India.

Incubators
The objectives of incubators supported by different
government departments converge on S&T-driven
innovation, startup creation, and linking innovation
to markets. Incubators therefore provide a range of
facilities that support market infrastructure development (basic infrastructures, finance, and space),
build business capabilities (mentoring and networks), and provide technology infrastructures (laboratory facilities and hardware).
Most incubators are funded through the NSTEDB.
The NSTEDB has provided funding for 86 Technology
Business Incubators (TBI) and Science and Technology Entrepreneurs Parks (STEP)(DST, 2014), out of
146 incubators (or entities that function as incubators) that receive public funding through different
central government agencies (See Appendix C).
Publicly-funded incubators share several characteristics.. First, incubators operate as a not-for-profit
entity (as a registered society), or as a Section-25
company that is required to reuse profits or income,
and cannot provide any dividends to shareholders.
Second, all incubators are set up with a host partner that is often an academic institute or a R&D lab.
Together with the hosts, incubators can provide

25

some of the technology infrastructures relevant for
S&T-based innovation in different sectors along with
space and basic facilities. Third, incubators facilitate financing for incubatees through several public
funding channels that prioritize startups located in
government-approved incubators; incubators also
strengthen networks with private investors, angel
investors, venture capital, etc. Fourth, incubators
receive five years of financial support from the DST,
after which they are expected to sustain their own
business (DST, 2014). DeitY, MoMSME, DSIR and DBT
also have some provisions for incubators to manage
their expenses (Appendix D, Figure 2). Most incubators generate revenues by renting out infrastructures and providing services to tenant enterprises.
And fifth, all incubators are eligible for tax incentives—incubators and incubatees with net profits
lower than INR 50 lakhs, are exempt from paying
service tax.
The majority of incubators are located in clusters
around metropolitan Tier I cities of Hyderabad,
Chennai, Bangalore, Delhi, and Ahmedabad, albeit with a few exceptions. The presence in clusters
stresses the importance of networksin cities where
industrial partners may be present and more active.
Outside of these clusters, incubators are expected
to contribute to regional development while generating S&T-innovation based startups. However,
even though incubators partner with universities or
research institutes, supporting in stitutions may not
be regionally inclusive, as some regions may have a
more developed innovation system.
The role of the manager is particularly central as
they are responsible for sustaining the incubator
and generating its own income beyond a period of
five years. Once the incubator is sanctioned by the
NSTEDB, managers choose their own business models and manage seed funds provided to incubatees.
The managerial staff is expected to oversee everyday operations, mentor early-stage startups, and
administer funds provided to the incubator through
different schemes designed to deliver early-stage financial assistance to enterprises.

<!-- page 40 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Incubator partners
Nearly all incubators partner with academia, laboratories, or R&D host institutes—among the NSTEDB
incubators alone, 84 percent of incubators have
such a partner, and 50 percent of partner hosts
come from the private sector, including private
universities (DST, 2014). Therefore, while publicly-funded incubators remain strongly connected to
academia, private sector academic bodies and R&D
centers are active in supporting incubation. Further-

more, besides formally recognized incubators, many
academic institutes have entrepreneurship cells that
fulfill a similar purpose as that of an incubator. Incubator hosts are expected to provide a supply of innovators or incubatees by building an entrepreneurial
spirit and innovation capacity among academics and
students, and to provide a channel for technology
transfer of ideas that have been developed.

Figure 2: Network of publicly funded in incubators in India with circles representing government or incubators and lines representing the linkages between them. Red dots represent government funding, dark grey dots represent incubators in Tier-I cities
(Delhi NCR, Hyderabad, Bangalore, Mumbai, Kolkata, Ahmedabad, Pune), light grey dots represent incubators in other cities or
towns. The size of the dots reflects different sources of funding for incubators – bigger dots represent funding from more sources.

Incubators in close proximity to academia expect
access to good incubatees—i.e., entrepreneurs with
good ideas through S&T trained students and faculty. However, most incubators welcome external
incubatees and do not limit tenancy to their academic affiliates or alumni. Furthermore, the quality
of incubatees or of their innovative ideas remains a
cause for concern, given the risk-averse nature of
students, academics, and society at large. While re-

cent public policy initiatives intend to improve the
quality of incubatees—for example under the Kerala
Startup Policy, universities would build the capacity
and enthusiasm for innovation and entrepreneurship—such initiatives are few and need more comprehensive assessment of outcomes.
The unavailability of consistent data (Table 2) prevents a more rigorous assessment on incubators

26

<!-- page 41 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

and their incubatees—i.e., who are the innovators,
to what extent are they linked with the host partner
that the incubator represents, etc.

External partners and networks
Incubators are designed to act as intermediaries to
connect new technology innovations with markets
and industry. However, few incubators are actually
associated with the industry, or have direct linkages.
Efforts have been made to improve private sector
industry involvement in incubation. For example,
corporate expenditure on publicly-funded incubators was recognized to meet CSR requirements since
2013, providing opportunities for incubators to
generate additional income, and to strengthen industry linkages4 . However, in the absence of alignment between corporate priorities and government
priorities, publicly-funded incubators did not immediately benefit from CSR financial flows. Most corporates may prefer to finance with CSR other, more
popular, social values in support of government initiatives, and are unaware of the benefits of incubators. There have been few exceptions—for example,
the Manipal Institutes accessed close to INR 20 lakhs

from local industries (personal interview with Anita
Gupta, 2015).
Incubators leverage private sector industry typically through large multinational corporates, and
not through Indian PSUs or other smaller domestic
firms. International companies that support domestic incubators are often interested in developing domestic technologies for strengthening their supply
chain networks. Examples of private sector support
for incubators includes Intel (business plan competition); Boeing (workshops for strengthening supply chain); Reliance and Economic Times (Power of
Ideas competition); GE, and Alstom (PPP model).
Additionally, investing in entrepreneurial ventures is
part of the business activities of companies like Reliance and Mahindra (personal interview with Anita
Gupta, 2015). Public-private partnerships are prominent particularly among DBT programs that foster
industry linkages (Aggarwal and Chawla, 2013).
Incubators also benefit from linkages with other incubators and their extended networks. For example,
a majority of DST incubators are part of the Indian
STEPs & Business Incubators Association (ISBA).

Since 2012, corporate companies with high net worth and profits are mandated to spend 2 percent of their profits as part of the Corporate Social
Responsibility Program [Section 135, Companies Act].

4

27

<!-- page 42 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Insights from Case Studies: Factors
for Favorable Incubator Outcomes
With the help of interviews with experts, we identified six incubators—out of 146 publicly-funded incubators—that were seen as prominent in meeting
their individual goals and contributing to building
the entrepreneurial ecosystem and the innovation
system. We conducted detailed case studies on
these incubators using semi-structured interviews
(see Appendix A: List of interviewees for list of interviewees). These incubators (listed in Table 4) repre-

senta spectrum of goals, locations, and partners—
for example, incubators in well-connected business
schools in entrepreneurial clusters (i.e., CIIE), incubators with sector-specific goals (i.e., IKP), incubators outside of metropolitan cities (i.e., TBI@KEC)
(see Appendix Efor detailed case studies). Building
on insights from interviews and case studies, the following sections outline six major factors that determine favorable incubator outcomes.

Table 4: Incubator case studies

Incubator

Location

Host or partner

Center for Innovation Incubation and Entrepreneurship (CIIE)

Ahmedabad

Indian Institute of Management,
Ahmedabad (IIMA)

Centre for Cellular and Molecular Platforms
(C-CAMP)

Bangalore

Bangalore Biotech Cluster

Incubator at IKP Knowledge Park (IKP)

Hyderabad

IKP Foundation

Technology Business Incubator - Kongu
Engineering College (TBI@KEC)

Perundurai, Erode

Kongu Engineering College (KEC)

Society for Innovation & Entrepreneurship
(SINE)

Mumbai

Indian Institute of Technology,
Bombay (IITB)

Startup Village (SV)

Kochi

MobME

Identifying and attracting
good ideas
Investing time and resources in building, identifying,
and attracting good ideas—for example, by training
students and researchers to innovate, by identifying

research with commercialization potential, or by
attracting talented innovators to the incubator—isa
key priority common to all six incubators. All six incubators recognize that efforts to attract and nurture
good incubatees—i.e., good innovators and good
entrepreneurs—increase the likelihood of success

28

<!-- page 43 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

of the incubator. These incubators therefore engage
in activities to strengthen innovation capacity in the
short-term while ensuring flow of good talent andideas in the long-term.
For incubators with sector-specific focus or
strengths—e.g., IKP and C-CAMP in the life sciences (biotechnology or pharmaceutical sectors)—the
proximity to research and industry clusters with
innovative S&T ideas ensures access to scientific
innovation and S&T-based entrepreneurs. IKP and
C-CAMP further reinforce their access to entrepreneurial talent by managing and distributing grants
for innovative early-stage ideason behalf of the
government or other foundations where grantees
also often become incubatees in these incubators.
For example, IKP and C-CAMP both manage the Biotechnology Ignition Grant (BIG) Scheme of the DBT
and distribute grants; IKP also partners with the Bill
& Melinda Gates Foundation to manage Grand Challenges Exploration, an initiative that supports and
funds innovative ideas to address global health challenges.
Other incubators build their pool of S&T ideas and
innovators with help of resources of their host engineering institutes and local industry—for example, SINE at IITB and TBI@KEC at Kongu Engineering
College. SINE—the incubator at IITB—has access to
top engineering students, researchers, and alumni
networks along with strong financial, investor, and
mentor networks in metropolitan Mumbai. SINE
provides affiliates of IITB a platform for commercialization of technology created at IITB prioritizing ideas
with a strong technology component and a potential to generate intellectual property. SINE ensures a
flow of good ideas and good entrepreneurs through
rigorous screening of incubatee applications by domain experts, industry, and more experienced entrepreneurs. In contrast, TBI@KEC, a regional engineering college in the small town of Perundurai—has
less prominent S&T resources and limited investor
or mentor networks. TBI@KEC supports long-term,
market-driven ideas by organizing workshops for

29

students and researchers to strengthen skills in specific IT areas (e.g., VLSI design, embedded technologies, wireless DSP, etc.) while providing training
in entrepreneurship. TBI@KEC compensates for its
location away from a metropolitan area by actively
leveraging local industry associations near Perundurai and participating in industry specific events,
such as trade fairs, that provide visibility to the incubator and help TBI@KEC attract new talent.
Incubators with strengths in business and markets—
like CII Eat the business school, IIMA—use their
knowledge of markets rather than in S&T to bring
new ideas and entrepreneurs. CIIE attracts entrepreneurs not only from within IIMA but also from the
rest of the country. Within IIMA, CIIE creates conditions for students to develop their ideas and engage
in entrepreneurship. For example, CIIE allows IIMA
students to intern at the incubator and experience
entrepreneurship as a profession. To ease student
concerns about paying off education loans under
the uncertainty of entrepreneurship, CIIE provides
a fellowship and prototype grant for entrepreneurs.
CIIE and IIMA also offer courses and trainings—e.g.,
mock fund management, technology and design,
etc.—to build innovation capacity among students.
CIIE attracts ideas from outside IIMA and from different parts of the country by hosting competitive programs—for example, Power of Ideas—or by managing sector-based accelerator programs that address
market-specific needs.
Incubators also prioritize the long-term flow of ideas
by building innovation capacity. For example, Startup Village (SV), Kochi partnered with the Kerala state
government to formulate the Kerala Innovation Policy that makes building innovation capacity a priority
for the state. Under the innovation policy, the Kerala Technology University incentivizes students to
explore innovative ideasby providing ‘grace marks’
for students who engage in entrepreneurship during college. Furthermore, SV recognizes that the absence of practical technical training in schools and
universities results in few product-based ideas or

<!-- page 44 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

startups; SV distributed Arduino kits for to school
children to encourage them to experiment with
electronics and coding and to build products.

totypes that have already been built, and help find
a product-market fit through validation by potential
stakeholders, customers, or investors.

Strategic choice of
incubator model

Addressing investment gaps
for startups

All six incubators reflect in their business models an
understanding of markets (in one or more sectors)
and have clear goals to purposefully target specific
market demands that maynot be fully addressed by
the private sector.

All six incubators facilitate investment in startups—
especially early-stage investments—by administering funding for startups from government bodies, by
managing their own seed funds or venture capital
funds, and also by helping attract external investment because of their high profile and activities.

Sector-focused incubators in the life sciences—i.e.,
C-CAMP and IKP—recognize the need for sector-specific requirements and business models. Life
science innovations may need special laboratory
facilities or may need a longer time horizon to demonstrate market potential compared to IT innovations.
Furthermore, most innovators in the life sciences
have limited industry or business experience. Both
incubators therefore offer mentoring, equipment,
technical expertise, and industry linkages to address
specific challenges for life sciences startups.
Incubators that target regional development and
operate in regions without existing high-technology sectors benefit from identifying specific market
demands and building capabilities to address these
demands. For example, TBI@KEC built expertise on
electronics and information technologies (including
VLSI design, embedded systems, digital signal processing, etc.) to prioritize product-driven startups
over service-driven startups or apps.
In sector-agnostic incubators like CIIE, identifying
the viability of new products in underdeveloped
sectors is more critical than focusing on developing
S&T aspects. Through its various accelerator programs, CIIE uses its deep understanding of business,
markets, and market failures, to build depth across
sectors with high societal impacts—including agriculture, water, and clean energy. These accelerator
programs bring in innovators with products or pro-

Some incubators—e.g., IKP and CIIE that are registered investors with SEBI—directly invest in incubatee startups to support them in their early stages. This investment makes incubators more deeply
engaged in startup success, makes incubators more
sensitive to sector-specific demands, and sends
positive signals to potential late-stage investors.
For example, the CIIE runs its own seed fund where
over 80 percent of the incubatees have received
follow-on financing from venture capital or angel investors within two years of incubation. As of 2015,
for every rupee invested by CIIE, its portfolio ventures had raised on an average INR 14 from other
investors. CIIE also runs its own venture capital fund,
Infuse Ventures, to provide early stage funding for
clean energy startups. Similarly, IKP collaborated
with NASSCOM to set up the India Innovation Fund
for investing in early-stage innovative startups in the
life sciences and addressing sector-specific issues, including the longer periods required to develop technology before engaging in business development.
Other incubators provide startup investments
through loans, equity, or revenue share or through
external financial networks. On the one hand, SINE’s
location in Mumbai—thefinancial hub of the country—and proximity to the emerging startup cluster
in Powai provides easy access to venture capital for
startups, with more 50 percent of incubatees with
investments from angels, venture capital, and finan-

30

<!-- page 45 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

cial institutions. On the other hand, TBI@KEC only
offers loans to startups through the DST and does
not take equity.
Incubators in the life sciences—i.e., IKP and
C-CAMP—also provide BIRAC grants for incubatees
that are early stage-startups (BIG) or other small industries (SBIRI and BIPP).

Focus on sustainable incubator
models
All six incubators have business models that ensure long-term financial sustainability and a secure
flow of income for the incubator. The sustainability of incubator finances is important because the
DST provides financial support for incubators only
for the first five years of operations. After the initial
five-year period, incubators are expected to generate their own income through different activities including partnerships with the private sector, equity
shares in startups that graduate, renting space and
equipment, providing training, etc. While other government agencies also occasionally provide some
additional financial support to incubators, such programs are scattered with mixed impacts on incubator operations.
Generating revenues within five years is particularly
challenging for incubators that support S&T-based
ideas beyond service-based IT—early-stage startups are risky by definition and need time to develop
their products. Furthermore, equity investment in
startups take several years to yield results and most
private equities that invest in risky ideas have a tenyear fund, and consequently, a ten-year investment
horizon. Consequently, incubators struggle to be financially sustainable after five years, and prioritize
short-term revenue-generating activities over incubating risky, innovative ideas.
The six incubators generate revenues in different
ways while maintaining the quality of incubatees and
of incubator activities. Rather than charging rents,

31

many incubators are transitioning to taking a share
of equity or share of revenues as they stand to benefit more from supporting and graduating successful
startups. Incubators with their own seed fund (e.g.,
IKP, CIIE, and SV) charge a management fee from incubatees to ensure sustainable revenue generation.
IKP and C-CAMP cross-subsidize expenses on their
incubation activities by income generated through
other sources. For example, IKP charges a fee from
foundations for managing grants and from companies that need technology services or equipment to
run tests. Similarly, C-CAMP charges a licensing fee
from users of its technology platforms. CIIE and SV
manage financing their incubator activities by effectively leveraging private sector investments. For
example, CIIE launched one of the first accelerator
programs in India—iAccelerator—where financial
support from Microsoft complemented CIIE’s knowhow in incubation.Similarly, SV raised nearly INR 5
crores of investment from the private sector. Incubators like TBI@KEC engage in lean operations—i.e.,
less staff members with multi-facetted skills—to
minimize costs and maximize revenues.
The business models of incubators are most effective in incubators where activities and outcomes are
regularly assessed and adjusted. In the absence of
formal and standard reporting requirements on incubator performance by DST, some incubators engage in rigorous external evaluations or internal assessments. For example, CIIE holds regular internal
reviews and self-assessment that serve as guidelines
for changes in its activities in accordance to market
needs. DB Trigorously monitors the performance of
incubators such as IKP and C-CAMP, resulting in efforts to develop metrics for self-assessment and to
find opportunities for improvement.

Access to multi-faceted
networks
All six incubators provide startups access to multi-faceted networks for knowledge (including technical, strategic, operational, and market knowledge),
mentorship, finance, and private sector markets.

<!-- page 46 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Access to networks is key for startups and incubators provide this access by strengthening their own
industry linkages or by organizing events, camps,
and forums to foster startup linkages with mentors,
investors, and private sector customers. For example, CIIE makes use of IIMA’s brand and networks to
support incubatees. CIIE’s MentorEdge program is
particularly useful for first time entrepreneurs who
lack the right connections and offers startups access
to mentors with expertise in multiple sectors. SINE
requires all incubatees to have one mentor on board
from their mentor pool. C-CAMP emphasizes on
market linkages and exposure to business ideas for
its incubatee scientists and academics through mentor forums and events, while IKP connects incubated
companies with markets through the India Innovation Fund. Incubators like IKP and CIIE offer access to
knowledge networks by supporting business plans,
technology licensing, compliance requirements,
intellectual property, etc. Incubatees at TBI@KEC
benefit from its close linkages with Coimbatore District Small Industries Association (CoDISIA), where a
member of CoDISIA serves on the board of the incubator. This incubator-industry association alliance
provides visibility to incubatees at TBI@KEC despite
its location nearly 300 km away from the closest major metropolitan city. For example, with the help of
CoDISIA networks, the first product launched out of
the incubator was an industrial vacuum cleaner in
partnership with Hacko, Germany.
IKP and CIIE also offer virtual incubator services,
where incubatees benefit from mentorship and networks provided by the incubator, but do not need to
be physically hosted.

Centrality of leadership
All six incubators have dynamic, entrepreneurial managers (and founders or trustees) that bring
experience beyond academia, or have the skills to
actively leverage different actors beyond academia.
Incubator leadership is critical to incubator success
because while incubators manage high-risk startups,
incubators managers are often academics or professors with little understanding of risk. Academic incubator managers are particularly common in university-affiliated incubators because incubator salaries
are often insufficient to attract managers with startup experience in the private sector. Such academic
managers may possess strong technical expertise
that is useful for scaling-up or managing technology, but they may lack the business experience that
is necessary to connect with markets and may have
limited skills to manage high-risk activities.
The managers of the six incubators have established
credibility with their past experiences—for example,
by working in the private or public sectors or by graduating from a top-ranked school with strong alumni
networks—and have a demonstrated capability to
work cohesively with different government departments, innovators, academics, and local industries
to develop the innovation system. These managers
have the vision and salesmanship to invite good ideas and incubatees to help build new incubators; they
have the attention to detail and leadership skills necessary to build strong teams and support systems to
help sustain incubators; and they have the skills to
make connections, strengthen networks, and help
the incubator to grow.

32

<!-- page 47 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Lessons Learnt and
Recommendations
Broadening and deepening the
pipeline of entrepreneurs
S&T-driven entrepreneurship requires strengthening
S&T-based innovation capacity and strengthening
the innovation system. These in turn require building
robust technical foundations among researchers and
students—in many cases, through deep expertise in
a specific area—as well as through building some appreciation of the innovation process.
While both government-led efforts to build innovation capacity and recent startup success-stories are
increasing in India, two key issues remain for broadening and deepening the pipeline of entrepreneurs.
First, many public policy initiatives are scattered and
do not address systemic issues related to lack of S&T
capacity. For example, plans to build 500 Tinkering
Labs will cover less than 0.7% of 72,000 senior secondary schools andp lans to build 300 university-affiliated incubators will cover less than 40% of over 770
universities. Furthermore, it is not clear to what extent such activities by themselves actually enhance
entrepreneurship. Therefore, while these initiatives
represent positive developments for enhancing the
pipeline of entrepreneurs, they are still unlikely to
benefit a large number of students and researchers.
Second, despite the growing number of successful
startups and entrepreneurs in India, there is little
recognition that not all entrepreneurs innovate.
Most commercially-successful Indian startups—for

33

example, Naukri.com, Flipkart, Ola, Snapdeal, Zomato—have used established business ideas with
proven international success and adapted them in
the Indian market (see Raghavan, 2016). While such
startups generate revenues, create employment,
and are important for supporting economic growth,
they represent business model innovations rather
than S&T-based innovation.
Talent emerging from Indian universities is limitedand according to most of our interviewees, there
is a relative paucity of innovative, cutting-edge,
technical ideas and of startups emerging from academic institutions. India’s experience with academic entrepreneurship stands in contrast to that of the
US where universities and academic research act as
the primary source of talent for new technical ideas
creating the largest and most successful S&T-driven
entrepreneurship ecosystem. In many cases, Indian
students are seen as lacking the training to come
up with new technical ideas as they have limited
understanding of key issues in particular sectors.
Unusually (in comparison to other major entrepreneurial economies) there is a greater generation
of startups by undergraduates than post-graduate
students or post-doctoral researchers. In other
cases, even faculty and doctoral researchers are
unequipped or lack the incentives to generate or
support market-driven ideas as faculty hiring and
promotion is based on UGC guidelines that prioritize degrees and publications, and there are few

<!-- page 48 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

institutional channels or programs to inspire or
enable innovation (UGC, 2016, 2013)5 .
Increasing the interactions between incubators, established entrepreneurs, and engineering schools
may help create conditions for students and faculty
to strengthen the quality of their S&T-driven ideas
and to look beyond new business models(see for
example, MIT, 2016; Stanford, n.d.)6 . Such interactions would help students (i) complement theoretical or academic knowledge from universities,
(ii) get guidance for their ideas from closer linkages
to markets, and (iii) find role models outside of service-based startups that are predominant in India.
Our study of key incubators and our conversations
with other experts and practitioners suggest that
measures to support innovation, to generate enthusiasm, and to train faculty and students in entrepreneurship have shown favorable outcomes. Examples
of such measures that are already in place in individual incubators include provisions for gap years for
students to pursue their own ideas, internships for
students to work in incubators, designing courses in
entrepreneurship, or inviting successful entrepreneurs who act as role models for students. However,
these efforts are scattered. Ultimately, strengthening the capacity to innovate will require a paradigm
shift in the education system through reforms that
target developing skills in S&T, fostering creativity,
promoting experimentation to complement theoretical concepts, minimizing rote learning, as well as
greatly upgrading the quality of research programs.

Incubator strategy,
management, and operations
Incubators—led by managers—that approach the
design of the incubator and its activities strategically and purposefully, giving due consideration to the
context of the incubator and available market opportunities, obtain more favorable out comes. The
context of the incubator includes considerations of
geographical location, host institutions, networks of
incubator managers and partners, characteristics of
the local or regional economy, sector-specific expertise, etc. Market opportunities might include needs
of local industry, sectoral possibilities (e.g., energy,
health, agriculture, ICTs), or needs of specific user
groups (such as the poor or women). For example,
the requirements of, and opportunities available to,
incubators in metropolitan cities like Delhi, Mumbai,
Ahmedabad, etc. are markedly different from those
in semi-urban areas, in less developed regions of
the country, or in industrial clusters with expertise
in specific technologies. Similarly, the requirements
of biotech or life science startups will differ from
those in clean energy or IT sectors in terms of infrastructure, mentorship, and incubation periods.
While an incubation period of less than a year may
be sufficient for some IT startups, biotech industries
and other high tech enterprises may require more
than five years of incubation. Overall, understanding
requirements of the local industry and local market
conditions, designing incubators to address these
specific market gaps and opportunities, and regularly monitoring and evaluating incubator outcomes
can greatly improve their performance.

In 2016, UGC guidelines for evaluation or promotion focused on publications and included patents, but did not specify entrepreneurship or startups
as favorable indicators of success for faculty evaluation and promotion. Also, UGC rules for ‘study leave’ mainly support research projects only and
do not allow full- or partial- employment with any organization during the study leave period, possible due to potential conflict of interest.

5

US universities engage in different activities to promote entrepreneurship among students by increasing interactions with successful entrepreneurs.
For example, MIT invited successful alumni entrepreneur for one year (entrepreneur-in-residence) to guide students interested in founding startups
in the developing world. Another example is the Mayfield Fellows Program at Stanford University that brings undergraduate students to Silicon Valley
by offering them courses, mentoring and networking activities, and a paid internship at a startup in Silicon Valley.

6

34

<!-- page 49 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

The quality of entrepreneur incubatees—and their
successes and failures can define incubator outcomes. But as many incubatees may not be trained
in business or market-related areas outside of S&T,
it is the role of the incubator to provide access to
mentoring or training services to develop these
skills in incubatees. In this context, sector-specific
incubators—rather than those that offer incubation
services to all startups—can help in providing targeted mentorship to startups and help address specific
market gaps and opportunities. Similarly, accelerator programs can speed up the startup cycle while
providing mentoring or training to entrepreneurs in
batches or cohorts. Accelerators built on the lines of
famous Silicon Valley institutions such as Y-Combinator have increasingly become popular because of
the frantic pace of innovation where startups need
to get to market quickly or play catch up. These
accelerators impart minimum business training to
entrepreneurs and help them attain a market fit for
their products.
Incubator managers—and their leadership skills and
capabilities—are key to successful operations and
revenue generation for publicly funded incubators.
All successful incubators are led by individuals with
strong business and management capabilities that
can help connect S&T innovations to markets, provide strong networks and mentorship, and manage
operations of the incubators. Efforts to reinforce existing incubators, or create new ones, fundamentally
depend on the availability of talented managers.
However, the challenges in finding talented mangers
and incubatees are exacerbated for incubators that
are unable to sustain their finances due to limited
ideas, little market-linked research, or poor ability to
connect ideas to market. This is particularly common

in incubators located outside major metropolitan areas that operate with regional development goals.
The current five-year public funding for incubators
endorses a one-size fits all approach even though
incubators have different goals and priorities. The
five years of financial support provided by the government are therefore insufficient for many publicly-funded incubators to start generating their own
revenues, and many incubators make training as
their primary activity for revenue generation (which
distracts from fundamental incubation objectives).
In contrast, private venture capital funds are aware
of the risk and timelines associated with startups
and operate with a ten-year horizon for investments.
While publicly-funded incubators operate as not-forprofit Section-25 Companies (or as Registered Societies) the more successful publicly-funded incubators
are able to leverage the private sectorand develop
public-private partnerships as a way to strengthen
their financial position7. Similarly, other resources, such as technical resources, may be leveraged
through other networks, for example, through partnerships with academia, government labs, and/or
industry.

Overcoming market failures
According to economic theory, in a well-functioning
market, goods and services are efficiently allocated through price signals. Thus, private actors have
an incentive to invest in goods for which there is a
high demand (and therefore, a strong price signal).
But in many cases, markets may not work well or by
themselves do not fulfill societal goals, leading to
what is termed as ‘market failures.’ These may be
in cases where there are barriers to organization
of efficient markets, for example, due to lack of information, lack of resources, regulatory hurdles, or
unattractive risk/return ratios, which lead to the

Competitive tendering processes have been used to finance public-private incubators. The government of Karnataka (GoK) organized a competitive
tendering process to set up the GoK Incubator for Tech Start-ups (GIfTS) with a private partner. in Israel, the government implemented a publicprivate model for incubators by providing licenses to private equity, venture capital, angel investors, other industry, etc. through a competitive
process. These incubator license holders financed 15% of the budget for a startup, and the government provided grants for the remaining 85%.

7

35

<!-- page 50 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

‘institutional voids’ mentioned earlier. In other cases, such as public goods (e.g., education and clean
environment), the private sector tends to underinvest even with large societal benefits since it cannot
appropriately monetize these benefits in the absence of public policy to help do so. And in yet other
cases, there may also be under investment in areas
where the beneficiaries do not have paying capacity.
In many of these areas relating to public goods or
other societal benefits (such as sustaining and creating can impede such innovation.
Furthermore, S&T-based entrepreneurship may
also face its own particular market challenges. S&Tbased startups have livelihoods, S&T-based innovation and entrepreneurship can play a particularly key
role and therefore these market failures insufficient
resources to connect to the markets, both in terms
of finding financing and other necessary services to
help them develop their products and take them to
market (e.g., testing and validation services for new
products, legal support for intellectual property and
patenting etc.). There is a growing venture capital
investment in startups in India, with $9 billion raised
by startups in 2015 alone. This is not surprising since
the private sector is better positioned to take on
the risk to support and provide follow-on financing to startups. But much of the venture capital
investment is primarily in new business ideas that
operate with service-based IT or new business
models that are already proven or are easier to test,
possibly because the private sector perceives the risks
associated with S&T-driven startups as too high, or

the rewards as too low, even if there are significant
societal benefits. Such perceptions exist because
S&T-based startups often need longer timescales to
create prototypes, to test unproven technologies,
and to demonstrate market acceptance8; they also
have to manage supply chains and physical distribution of the product. All of these factors increase the
risks for private investors, especially where the large
and growing market still offers substantial options for
IT- or business model-based entrepreneurship.
As intermediaries between startups and market or
industry, publicly-funded incubators (with the help
of public policies) can help overcome these various
market failures for S&T-based entrepreneurship. Incubators can help procure early-stage financing in
high-risk S&T startups (for example, underway in BIRAC). They can facilitate collaborative relationships
between startups and the government to take on
some of the initial risk and to provide positive signals to private investors for follow-on financing9.
Publicly-funded incubators can be particularly useful
in linking S&T-driven innovation to markets in areas
related to public goods or areas with high societal
benefits but low commercial returns (such as energy services, sanitation, rural areas, energy services,
water, housing, agriculture, livelihood creation) as
they can facilitate collaborations between government bodies or NGOs working with these issues
and S&T-driven entrepreneurs10 . In less developed
regional innovation ecosystems, incubators can
facilitate linkages between startup incubatees
and industry by closely aligning with local industry
associations or with other industry networks.

The validation of the technical performance of a new product by a government laboratory could help mitigate the perceived risk of investing in
such a technology. For example, the Comprehensive Initiative on Technology Evaluation (CITE) is a USAID-funded program, where researchers at MIT
develop consumer reports for new products (e.g., solar lanterns) provided by international aid agencies or private companies, to help consumers
make informed choices of their purchases.

8

Collaborative networks of startups with governmental partners—where government acts as a partner for technology- or market development—
have demonstrated positive outcomes in terms of innovation and follow-on financing in the case of cleantech startups in the US (Doblinger, Surana,
and Diaz, forthcoming).

9

10
For example, the Chicago CleanWeb Challenge hackathon provided city data to innovators and invited them to create technological solutions for
environmental issues. In another example, the city government of Helsinki, helped startups by using technologies from cleantech startups including
energy efficiency, low emissions public transport, waste management, district heating, water and air quality. Similarly, the local government in Sao
Paolo, Brazil eased pre-qualification conditions for procurement tenders in favor of SMEs and startups. Sao Paolo also prioritizes procurement from
startups as long as their bids are no higher than 10% of bids from non-startups.

36

<!-- page 51 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

System-level support
and coordination
While individual incubators—and programs to support these—can be much helped through a careful
approach of incubator design as well as supporting
public policy, it is also necessary to pay attention
to the larger ecosystem that ultimately links these
individual activities and to exploit synergies/
benefits that might be available through a larger,
‘systems-level’ perspective. Of particular interest are
activities that will be beneficial for individual incubators/programs but are unlikely to (and sometimes
cannot) be undertaken by any single entity. In a
sense, therefore, addressing such ecosystem issues
could be seen as a ‘public good’ and therefore particularly appropriate for public policy interventions.
To start with, systematic information-sharing and
coordination between different government agencies can greatly help improve the effectiveness of
individual programs by minimizing overlaps and
maximizing synergies. Exchanging knowledge and
experiences between different incubators and
programs—through meetings between incubator
managers and program managers—would help in
learning from success stories and from assessment
approaches and contribute to more effective design and management of incubators with different
goals and priorities11. This coordination between incubator programs is critical as the most successful

incubators tap into multiple resources—i.e., DST,
DBT, MoMSME, DeitY, etc., and also bring in additional financing from the private sector. Similarly,
meetings between all incubatees—or those involved
in specific sectors—would not only engender enthusiasm and excitement among like-minded participants, but also provide an opportunity to collaborate and generate new ideas12.
Expanding local initiatives (programs in academic
institutions, building networks with key actors, etc.)
across the country is imperative for developing a
“pipeline” of innovators and entrepreneurs and enhancing their capacity to innovate – such activities
may be more effectively supported jointly than individually by individual incubators or agencies.
Lastly, as with any activity, monitoring and assessment is central to improvement. As the management
adage goes “what is not measured is not improved.”
This is as true for individual incubators as for the incubator programs run by different agencies. Tracking progress is also important for other reasons: it
forces the managers (whether of an incubator or
the program) to think about the key outcomes that
represent and capture their objectives and the metrics through which to measure these. It also sends a
signal to the incubatees as to the expectations from
them. A systematic approach to examining and assessing incubator programs jointly may also reveal
gaps that are not apparent otherwise.

The Indian STEPs & Business Incubators Association (ISBA) already organizes such meetings, but these meetings need expansion and could be
formalized to require all managers.
11

For example, the World Bank’s Climate Innovation Centers are present in seven countries around the world and are now establishing a network of
incubators to share best practices. Similarly, the Clean Energy Incubators Network in the US aims to highlight best practices on incubation techniques
and clean energy technologies through workshops that bring together start-ups, incubators, investors, and industry participants working on clean
energy.
12

37

<!-- page 52 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Table 5 presents a list of specific recommendations to address the four areas mentioned above.
Table 5: Recommendations to address different gaps and barriers related to S&T-driven entrepreneurship in
India (for policymakers and program managers in white boxes, and for incubators in light blue boxes)

1 PIPELINE OF S&T TALENT
Students lack skills in S&T driven entrepreneurship and innovation
Fund the development of new courses to build the ability to apply S&T skills to market needs:
• courses on innovation based on specific problems including those that fulfill social needs—for
example energy services, sanitation, rural areas, etc.—where students first analyze the problem
context and then apply theoretical, experiential, and practical knowledge to find S&T-driven
solutions
• courses on interdisciplinary subjects—combining medicine and engineering, technology and
society, etc.—to improve understanding of market needs while generating ideas
Expand faculty-training programs on S&T-driven innovation and entrepreneurship to generate
faculty who can design and teach relevant courses for students in different specializations
Develop entrepreneur-in-residence programs with university campuses to bring in S&T
entrepreneurs with real world experiences of creating and managing challenges associated with
product-based S&T startups
Offer students internships, projects, and other opportunities to engage more deeply with
startups and incubators that are co-located with their university
Faculty have limited knowledge of industry and have few incentives to launch startups
Revise HR policies and UGC rules to incentivize faculty engagement in innovation and
entrepreneurship:
• flexible hiring and promotion policies where entrepreneurial activities are valued along with
academic publications and research projects
• revising UGC rules for sabbaticals or ‘study leave’ to include external employment in the
“problem environment” so faculty can interact with end-users such as healthcare institutions,
rural workers, etc.
• revising UGC rules to support and fund sabbaticals for launching startups
Faculty and students have poor perception of entrepreneurship
Increase the visibility of scientists in startups through the following to ease risk perceptions about
careers in S&T-driven startups and increase interactions with university S&T researchers
• offering awards for startup scientists to encourage research with commercialization focus
• creating forum for startup scientists to share their experiences on university campuses
Revise external- and self-evaluation criteria of university success by including both corporate
placements and student-launched startups to encourage students to consider entrepreneurship
and commercialization of ideas in the same light as taking up salaried employment

38

<!-- page 53 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

2 INCUBATOR STRATEGY, MANAGEMENT, & OPERATIONS
Incubator activities are misaligned with poorly-defined incubator goals
Require incubators to define goals, along with preliminary activities and self-evaluation metrics
as part of the application procedure. These goals could include a combination of—sectoral
development, geographical development, co-location with academia, startup stage (i.e., idea
stage, early stage, or growth stage) etc.
Offer periodic guidance to incubators in articulating and adapting goals and activities to the
changing context of innovation and market needs
Mandate regular self-evaluation exercises based on metrics designed to evaluate performance in
relation to goals
Incubatees lack skills in entrepreneurship
Create competitive cohort programs for incubatees on regular intervals—e.g., sector-based
accelerators—to build community, strengthen networks with industry or investors, and provide
mentoring in a more targeted manner
Offer incubatees training on a range of skills useful for entrepreneurs—e.g., startup business
models, writing business proposals, applying for grants, developing communication skills, etc.
Incubator management can be weak
Identify, invite, and train experienced professionals with business, market, and S&T experience
in incubation management to make S&T innovation-based incubation market-driven rather than
champion-driven
Incentivize talented professionals (or academics) to take up incubation management as a
career and to alleviate perceive risks, particularly in universities—for example by showcasing
career paths of prominent managers from other incubators, integrating incubator managers in
university management, etc.
Hire experienced (or well-trained) incubator managers (or CEOs) with an ability to connect
business, markets, and S&T-innovation, strong skills in leadership and marketing, and passion for
S&T-innovation
Offer continued support for the entire incubator management team (and not just managers)
through systematic training, access to advisors, etc. relevant for the incubator’s local context
Incubator funding from government sources may be insufficient
Offer flexible incubator financing (based on well-defined region- or sector-based goals and
performance indicators) instead of fixed, five-year financing through the following:
• expanding well-performing incubators and strengthening their linkages with other incubators
• offering long-term performance-based support to incubators that meet performance
requirements or have sectors with longer innovation and development cycles
• phasing out funding to incubators that fail

39

<!-- page 54 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Initiate and incentivize public-private models for incubator financing
• supporting incubator managers in leveraging local industry or other networks to use CSR
funding for entrepreneurship
• using competitive tendering processes by public sector to select private partners for setting up
joint incubators

3 MARKET FAILURES
Startups / incubatees lack support services to validate S&T-based ideas
Create mechanisms for testing and validation of new technologies that are developed in startups
but have no established standards or mechanisms for validation
Establish centralized support services—i.e., technical services, legal and patenting services,
market research, etc.—by pooling resources to benefit regional, sectoral startup clusters (e.g.,
Hyderabad and Bengaluru with life sciences / biotech)
Facilitate connections between publicly-funded startups and public sector (central and local)
to secure advanced market commitments including provisions for public procurement of
technologies
Private sector underinvests in sectors with high societal benefits
Create a larger seed fund to support the needs of S&T-driven innovation by leveraging public
funding seed money and inviting private investments
Provide tax breaks to corporate firms for investing in incubators to increase private investments
by replacing (or complementing) CSR funding for incubators that has so far been perceived by
corporates as an additional tax
Partner with local bodies that work on societal issues and draw S&T-driven entrepreneurs to
address problems related to public goods or areas with high societal benefits but low commercial
returns where private sector will not invest, or is less likely to invest
Extend incubator network resources in regions with less developed innovation ecosystems by
partnering with local industry associations or with other industry networks to compensate for
insufficient private capital or linkages with markets
Leverage alumni networks to create venture funds for supporting startups in areas of expertise of
the university or of the incubator

40

<!-- page 55 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

4 SYSTEM-LEVEL COORDINATION AND ASSESSMENT
Actors involved with incubation have weak coordination and no formal networks
Organize meetings for different actors in publicly-funded incubators to strengthen coordination:
• annual conference for all incubatees in to promote community building, share experiences, and
strengthen networks
• periodic meetings between incubator managers and program managers to enhance systematic
knowledge sharing and coordination
• meetups between sector-specific incubator and incubatee meetups through “networks of
incubators” for sharing resources, best practices, and for generating new ideas
Maintain (and update) a centralized registry of all incubators that receive public-sector funding
to improve accountability of incubator performance, help government departments coordinate
incubator support efforts, and increase visibility of incubators for potential incubatees
Create open repositories of projects and problems to strengthen linkages between innovators
and markets:
• database of research projects from knowledge networks can promote collaboration for new
entrepreneurial ideas, find potential applications, or find potential customers
• database of problems identified with private companies, foundations, government departments,
etc. can attract potential innovators to find solutions
Build and maintain centralized online databases of support services and partners for startups and
facilitate startup engagements with these services:
• support services (testing and validation services, legal support for intellectual property and
patenting, technical infrastructures, etc.)
• industry and finance partners willing to work with startups
Build regional innovation ecosystems outside of metropolitan cities by mandating incubators to
include experts from regional companies or industry associations in their management
Government-led incubator programs lack systematic data or analysis on incubator activities
Develop (and regularly evaluate) sectoral and regional innovation maps to identify the landscape
of actors, their linkages, and the dynamics of innovation and to help incubators define their
goals, strategies, and activities
Conduct systematic, annual assessment of incubators and incubatees to assess performance, to
improve accountability, and to assess the long-term effectiveness of incubation programs:
• Develop a new set of indicators to analyze incubator and incubatee performance based on
innovation inputs, outputs, and outcomes and be designed to reflect the goals of the incubator
(e.g., regional development, sector-specific, etc.)
• Use a common template with indicators to collect information on incubators and incubatees

41

<!-- page 56 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Increase the understanding of different incubator business models used in publicly funded
incubators under different contexts and goals—i.e., differences in incubator management
(public- or private-sector managed), technology or startup stages (idea to early stage, early
stage to growth stage, growth to expansion stage); other goals (sector-specific, sector-agnostic,
regional development, etc.)
• Conduct a detailed assessment of different incubator business models used in publicly funded
incubators
• Make the assessment available to incubator managers and use it to advise existing and new
incubators on modifying their business models

42

<!-- page 57 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Conclusions
S&T-based entrepreneurship is likely to play an increasingly important role in India’s innovation landscape, given the increasing focus on this in public
policy, the evolution of the country’s innovation
ecosystem, and the burgeoning interest among scientists and engineers to explore this pathway. Incubators can play a critical role in this process by
nurturing startups through provision of infrastructure and support services as well as rich linkages to
other actors. Public support for such incubators can
help the government both advance its goal to enhance S&T-base entrepreneurship and also allow the
achievement of various public goods objectives.

43

Our research and analysis indicates that there is
much that can be done to strengthen publicly-funded
incubators through a range of activities. Accordingly,
we have a set recommended actionable steps that
could be considered by policy-makers, incubator
managers, and other actors. But these should be
seen only as first step in the long road to strengthen incubation and entrepreneurship in India. There
clearly is much more research needed to better understand various aspects of these activities in the
country and to use that learning to move even further down this road. But one step at a time.

<!-- page 58 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Bibliography
Acs, Z., Storey, D., 2004. Introduction: Entrepreneurship and Economic Development. Reg. Stud. 38, 871–
877. doi:10.1080/0034340042000280901
Aggarwal, A., Chawla, S., 2013. Promoting Innovation Through Public-Private Partnership- An Assessment of
the SBIRI/BIPP Programmes. Wadhwani Foundation.
Akçomak, I.S., 2009. Incubators as tools for entrepreneurship promotion in developing countries. UNU-WIDER, Helsinki.
Audretsch, D.B., Grilo, I., Thurik, A.R., 2007. Handbook of Research on Entrepreneurship Policy. Edward Elgar
Publishing.
Autio, E., Kenney, M., Mustar, P., Siegel, D., Wright, M., 2014. Entrepreneurial innovation: The importance of
context. Res. Policy 43, 1097–1108. doi:10.1016/j.respol.2014.01.015
Bergek, A., Norrman, C., 2008. Incubator best practice: A framework. Technovation 28, 20–28. doi:10.1016/j.
technovation.2007.07.008
BIRAC, 2015. BIRAC Resource Facilities.
BIRAC, n.d. BIRAC - About Us [WWW Document]. URL http://www.birac.nic.in/about_us.php (accessed
4.29.16).
Chandra, A., Fealey, T., 2009. Business Incubation in the United States, China and Brazil: A Comparison of
Role of Government, Incubator Funding and Financial Services. Int. J. Entrep. 13, 67–86.
Chandra, A., Silva, M.A.M., 2012. Business Incubation in Chile: Development, Financing and Financial Services. J. Technol. Manag. Innov. 7, 1–13. doi:10.4067/S0718-27242012000200001
Cohen, S., 2013. What Do Accelerators Do? Insights from Incubators and Angels. innovations 8, 19–25.
Companies Act, n.d.
Cornell University, INSEAD, WIPO, 2016. The Global Innovation Index 2016: Winning with Global Innovation.
Fontainebleau, Ithaca, and Geneva.

44

<!-- page 59 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Dee, N.J., Livesey, F., Gill, D., Minshall, T., 2011. Incubation for Growth. NESTA.
DSIR, n.d. Promoting Innovations in Individuals, Start-ups and MSMEs (PRISM) [WWW Document]. URL
http://www.dsir.gov.in/12plan/prism/prism.htm (accessed 4.9.15a).
DSIR, n.d. TePP Outreach cum Cluster Innovation Centres (TOCICs) [WWW Document]. URL http://www.dsir.
gov.in/12plan/prism/prism_tocics.htm (accessed 4.9.15b).
DST, 2014. Fuelling Entrepreneurship - The Story of Technology Business Incubation in India. NSTEDB, Department of Science & Technology (DST), GoI & Indian STEP and Business Incubator Association (ISBA).
DST, 2009. First Status Report on Technology Business Incubation in India. NSTEDB, Department of Science
& Technology (DST), GoI & Indian STEP and Business Incubator Association (ISBA).
Etzkowitz, H., 2002. Incubation of incubators: innovation as a triple helix of university-industry-government
networks. Sci. Public Policy 29, 115–128. doi:10.3152/147154302781781056
FAQ- ANPROTEC [WWW Document], n.d. . ANPROTEC. URL http://anprotec.org.br/site/en/menu/incubadoras-e-parques/perguntas-frequentes/ (accessed 4.27.16).
GIZ, 2012. Enablers for Change - A Market Landscape of the Indian Innovation Enterprise Ecosystem. GIZ,
New Delhi.
GoI, P.C., 2012. Creating a Vibrant Entrepreneurial Ecosystem in India - Report of the Committee on Angel
Investment & Early Stage Venture Capital. Government of India, Planning Commission, New Delhi, India.
Grimaldi, R., Kenney, M., Siegel, D.S., Wright, M., 2011. 30 years after Bayh–Dole: Reassessing academic entrepreneurship. Res. Policy, Special Issue: 30 Years After Bayh-Dole: Reassessing Academic Entrepreneurship
40, 1045–1057. doi:10.1016/j.respol.2011.04.005
Guo, D., Guo, J., Jiang, K., 2014. Government Subsidized R&D and Innovation Outputs: An empirical Analysis
of China’s Innofund Program. Stanf. Cent. Int. Dev. Work. Pap. Ser. 494.
Gupta, A., 2015.
Hackett, S.M., Dilts, D.M., 2004. A Systematic Review of Business Incubation Research. J. Technol. Transf. 29,
55–82. doi:10.1023/B:JOTT.0000011181.11952.0f
Hathaway, I., 2016. Accelerating growth: Startup accelerator programs in the United States (No. 81), Advanced Industries Series. The Brookings Institution.
INBIA, n.d. Business Incubation FAQs [WWW Document]. URL https://www.inbia.org/resources/business-incubation-faq (accessed 4.29.16).
Jaffe, A.B., Trajtenberg, M., Henderson, R., 1993. Geographic Localization of Knowledge Spillovers as Evidenced by Patent Citations. Q. J. Econ. 108, 577–598. doi:10.2307/2118401
Karsten, J., West, D.M., 2015. Start-Up Chile: A “start-up for start-ups” in Chilecon Valley. Brook. Inst.

45

<!-- page 60 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Kelley, D., Singer, S., Herrington, M., n.d. Global Entrepreneurship Monitor - 2015/16 Global Report.
Khanna, T., Palepu, K.G., 1997. Why focused strategies may be wrong for emerging markets. Harv. Bus. Rev.
Lalkaka, R., 2002. Technology business incubators to help build an innovation-based economy. J. Change
Manag. 3, 167–176. doi:10.1080/714042533
LeBlanc, R., 2012. The Indian Start-up Ecosystem: On the Cusp?
Mahmood, N., Jianfeng, C., Jamil, F., Munir, H., Jintao, L., Khan, M., Cai, Y., 2015. Snapshot of Technology
Business Incubators in China. Int. J. U- E-Serv. Sci. Technol. 8, 235–242.
McAdam, M., McAdam, R., 2008. High tech start-ups in University Science Park incubators: The relationship between the start-up’s lifecycle progression and use of the incubator’s resources. Technovation 28,
277–290. doi:10.1016/j.technovation.2007.07.012
Ministry of Commerce and Industry, Government of India, 2016. Startup India Action Plan.
Ministry of Science and Technology, 2004. Global Forum on Business Incubation – A backgrounder.
MIT, 2016. For MIT students, an entrepreneur in residence with developing world experience. MIT Sloan
Newsroom.
Mittal, H., 2015.
MoMSME, 2010. Scheme for “Support for entrepreneurial and managerial development of SMEs through
incubators”- an NMCP Scheme. Government of India.
NASSCOM, 2015. Start-up India – Momentous Rise of the Indian Start-up Ecosystem. NASSCOM.
NITI Aayog, 2015. Report of the Expert Committee on Innovation and Entrepreneurship. New Delhi.
NSTEDB, 2012a. Technology Business Incubator (TBI) - General Guidelines and Proforma for Submission of
Proposals. Government of India, Ministry of Science & Technology, Department of Science & Technology,
National Science & Technology Entrepreneurship Development Board, New Delhi.
NSTEDB, 2012b. Seed Support System (SSS) for Start-ups in Incubators. Government of India, Ministry of Science & Technology, Department of Science & Technology, National Science & Technology Entrepreneurship
Development Board, New Delhi.
OECD, 2013a. Start-up Latin America, Development Centre Studies. OECD Publishing.
OECD, 2013b. Innovation for Development.
Phan, P.H., Siegel, D.S., Wright, M., 2005. Science parks and incubators: observations, synthesis and future research. J. Bus. Ventur., Special Issue on Science Parks and Incubators 20, 165–182. doi:10.1016/j.
jbusvent.2003.12.001

46

<!-- page 61 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Raghavan, A., 2016. For Indian Start-Ups, Tenacity Beats High Tech. N. Y. Times.
Rothaermel, F.T., Thursby, M., 2005a. Incubator firm failure or graduation?: The role of university linkages.
Res. Policy, The Creation of Spin-off Firms at Public Research Institutions: Managerial and Policy Implcations
34, 1076–1090. doi:10.1016/j.respol.2005.05.012
Rothaermel, F.T., Thursby, M., 2005b. University–incubator firm knowledge flows: assessing their impact on
incubator firm performance. Res. Policy 34, 305–320.
Saxenian, A., 1996. Regional Advantage. Harvard University Press.
Shane, S., Venkataraman, S., 2000. The Promise of Entrepreneurship as a Field of Research. Acad. Manage.
Rev. 25, 217–226. doi:10.5465/AMR.2000.2791611
Stanford, n.d. Mayfield Fellows Program [WWW Document]. URL http://stvp.stanford.edu/mayfield-fellows-program/
Start-up Brasil, n.d. Start-Up Brasil. Acelerando o ecossistema nacional de startups.
Szirmai, A., Naudé, W., Goedhuys, M. (Eds.), 2011. Entrepreneurship, Innovation, and Economic Development. Oxford University Press.
UGC, 2016. University Grants Commission (Minimum Qualifications for Appointment of Teachers and other
Academic Staff in Universities and Colleges and Measures for the Maintenance of Standards in Higher Education), No.F.1-2/2016(PS/Amendment).
UGC, 2013. Revised Guidelines for Grant of Study Leave, No.F.1-6/2012(PS).
World Bank, 2016. World Development Indicators.

47

<!-- page 62 -->

<!-- page 63 -->

APPENDICES

<!-- page 64 -->

<!-- page 65 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Appendix A: List of interviewees
1.

Dr. Harkesh Mittal, Adviser, Member Secretary, National Science & Technology Entrepreneurship
Development Board (NSTEDB), Department of Science and Technology (DST), Government of India

2.

Dr. Anita Gupta, Associate Head /Scientist-F, National Science & Technology Entrepreneurship
Development Board (NSTEDB), Department of Science and Technology (DST), Government of India

3.

Dr. Renu Swarup, Managing Director, Biotechnology Industry Research Assistance Council (BIRAC)

4.

Rajneesh Kumar, Senior Manager-IP & Technology Management, Biotechnology Industry Research
Assistance Council (BIRAC)

5.

Dr. Raghunandan Rajamani, Executive Director, Indian STEPs & Business Incubators Association (ISBA)

6.

Deepanwita Chattopadhyay, Chairman & CEO, IKP Knowledge Park

7.

Dr. Sangita Sen Majee, Head-Life Science Incubator, IKP Knowledge Park

8.

Dr. Kiran K Sharma, Director- Platform for Translational Research & Chief Executive Officer- Agribusiness
and Innovation Platform, The International Crops Research Institute for the Semi-Arid Tropics (ICRISAT)

9.

S.M. Karuppanchetty, Chief Operating Officer - Innovations and Partnerships Program (INP),
Agribusiness and Innovation Platform (AIP), The International Crops Research Institute for the SemiArid Tropics (ICRISAT)

10.

Dr. B.S. Ramakrishna, Administrative coordinator, Technology Business Incubator (TBI), University of
Hyderabad (UoH)

11.

Prof. V. Venkata Ramana, Co-ordinator, TBI-UoH & Professor, School of Management Studies University of Hyderabad (UoH)

12.

Sujil Pokkavayalil, Manager Incubation and Projects, The IIIT Hyderabad Foundation

13.

Dr. Taslimarif Saiyed, Director and COO, Centre for Cellular and Molecular Platforms (C-CAMP)

14.

Pratibha Boga-Kamat, Project Manager, Centre for Cellular and Molecular Platforms (C-CAMP)

15.

Asgar Ahmed, Director, Student Entrepreneurship Development (SED)

16.

Kunal Upadhyay, Chief Executive, Centre for Innovation Incubation and Entrepreneurship (CIIE)

17.

S. Balamurugan, Executive Director, Technology Business Incubator (TBI), Kongu Engineering College (KEC)

18.

P. S. Kannan, Senior Manager, Technology Business Incubator (TBI), Kongu Engineering College (KEC)

19.

Poyni Bhatt, Chief Administrative Officer, Society for Innovation and Entrepreneurship (SINE), Indian
Institute of Technology - Bombay

20.

Sanjay Vijaykumar, Chairman, Startup Village - Kochi

21.

Gautham, COO, Entrepreneurship, Sales, Marketing and Product, Startup Village - Kochi

22.

Ganapathy Venugopal, CEO, Axilor Ventures

23.

Prof. Tarun Khanna, Professor, Harvard Business School

51

<!-- page 66 -->

THE ROLE OF INCUBATORS AND PUBLIC POLICY

Appendix B: International examples
of incubator programs
Brazil: Brazil’s innovation policy has several instruments in place to catalyze an enabling environment
for startups at the national, state, and local levels.
Incubators—primarily affiliated with universities—
feature prominently in the support for startups, and
Brazil has the third largest number of incubators in
the world (following USA and China) following several incubation models (Akçomak, 2009). Brazil’s
incubators reflect a ‘triple-helix’ model of synergies
between university, industry and government (Etzkowitz, 2002). Many of the incubators in Brazil are
set up with support from multiple government partners and the private sector, for example, National
Incubation Support Program (PNI) provides financial
support to set up new incubators or expand existing
ones (Chandra and Fealey, 2009). The number of incubators in Brazil increased from 2 in 1988 to 384 in
2011, and the primary prerequisite for startups to be
hosted in these incubators has been innovation. The
incubators currently in operation host 2640 companies and generate employment for over 16000 jobs.
Over 2500 companies have already graduated that
generate revenues of over R$4 billion and support
over 16000 jobs (“FAQ - ANPROTEC”). Other examples of public support include the PRIME program
of FINEP—a corporation affiliated to the Ministry of
Science, Technology, and Innovation—that provides
grants co-financed of up to USD 70000 per startup
through anchor incubators, and supplements grants
with interest free loans (OECD, 2013a). The Startup
Brazil program launched in 2013, plans to support
150 startups with a budget of B$150 million (Startup Brasil).
China: Chinese innovation policy makes specific provisions for creating enabling conditions for innovative high-technology enterprises, as demonstrated
through the Torch Program (started in 1988) by the

government’s Ministry of Science and Technology
(MOST). The Torch Program invested heavily by providing funds for construction of S&T industrial parks
and incubators. Between 1988 and 2012, the Torch
Program supported the establishment of 1200 incubators, including 435 incubators at the national level. These incubators hosted over 70,000 startups of
which 50,000 graduated and 180 became listed companies. In addition, the Chinese government runs
the Innofund—a program to support innovation in
the private sector. The Innofund provided grant appropriation for startups ($150-$200k), low interest
lows, or equity investments. From 1999 to 2011, the
Innofund provided over 19.17 billion RMB (over USD
$2 billion) to over 30,000 projects, primarily through
grants appropriation, and induced external financing
from local governments, private equity, and venture
capital of 1:11. Typically, Innofund provides up to
20% of the capital for the investee company (Guo et
al., 2014; Mahmood et al., 2015).
Chile: Chile places a growing emphasis on startups,
by having a chain of policies in place to create an
enabling environment by building finance, management skills, and a legal framework. Between 1992
and 2012, 27 incubators were established in Chile,
many with strong university linkages (Chandra, Corfo). CORO has also been key to startup growth an
expansion since 1998, financing venture capital
funds. The Startup Chile program launched in 2010,
through Fondacion Chile and CORFO, provides USD
40000 as seed capital for local and international entrepreneurs and provides them with basic infrastructures for one year, with the aim of creating a critical
mass of entrepreneurs. Between 2010 and 2015,
with the support of Startup Chile, 1200 startups
from 72 countries graduated, raised over $100 million USD and created over 1500 jobs (Chandra and

52

<!-- page 67 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

Silva, 2012; Karsten and West, 2015; OECD, 2013a).
USA: Government support for incubators in the
United States is evidenced in the form of funding
through government grants, state economic development agencies, or state legislative allocations
(Chandra and Fealey, 2009), and programs include
the SBIR, Startup America, etc. According to the National Incubator Business Association, the number
of incubators increased from 12 in 1980 to 1,250 incubators in 2012 (INBIA).
Israel: Israel’s innovation policy has been a catalytic force in creating an enabling environment for the
success of high technology startups in Israel, particularly in the life sciences, cleantech and ICT sectors. The government was instrumental in absorbing
risk for early-stage technology startups. The licenses
to set up incubators were given out through competitive processes to among others, private equity,
venture capital, angel investors, and other corporations. These incubator license holders financed 15%
of the budget for a startup, and the government financed the rest 85%, where startup budget amounts
to $0.6 million USD per firm. The government thus

13

See more at: http://www.incubators.org.il/

53

absorbed most of the risk by giving out grants that
were paid back in the form of a small percentage of
annual revenues generated, only valid in the case of
startup success. The government’s initial investment
in risky, innovative startups contributed to mobilizing sizeable investments from the private sector.
Between 1991 and 2012, government invested USD
$650 million in 1700 startups, hosted in 24 incubators. Over 1500 startups graduated from incubation
programs, and these startups had raised USD $3.5
billion private investments. The availability of private
sector capital was boosted by the launch of Yozma in
the early 1990s, a program that led to the establishment of several venture capital funds13.
Finland: Among OECD countries, Finland is one of
the most active in its policy support for startups.
Tekes—Finland’s main innovation-support agency—
offers seed capital to young, innovative companies
up to USD $1.3 million per company. Finnerva, a
public agency, has helped in the creation of more
than 3600 companies through loans and guarantees
to develop and internationalize Finnish companies.
The Vigo accelerator program aims to invite international talent to create startups in Finland (OECD,
2013a).

<!-- page 68 -->

Icrisat - Agri Business Incubator

Composites Technology Park - TBI

Kongu Engineering College - TBI

Vellore Institute of Technology - TBI

IKP Knowledge Park - TBI

National Design Business Incubator- TBI

National Institute of Technology Calicut - TBI

Mitcon - TBI

Bits Pilani - TBI

IIT Bombay - Society for Innovation and
Entrepreneurship

Thapar University - STEP

Technopark - TBI

University of Madras - TBI

Periyar Maniammai University - TBI

IIT Madras - Rural Technology and Business
Incubator

National Chemical Laboratory - TBI

9

10

11

12

13

14

15

16

17

18

19

20

21

22

23

24

ISS Academy of Technical Education-STEP

8

National Institute of Technology KarnatakaSTEP

5

PSG College of Technology-STEP

IIT Kharagpur-STEP

4

Basaveshwar Engineering College-STEP

Trichirapalli Regional Engineering CollegeSTEP

3

6

University of Pune-STEP

2

7

Sri Jayachamarajendra College of
Engineering -STEP

Name

1

ID

54
Pune

Chennai

Thanjavur

Chennai

Trivandrum

Patiala

Mumbai

Pilani

Pune

Calicut

Ahmedabad

Hyderabad

Vellore

Perundurai

Bangalore

Hyderabad

Noida

Bagalkot

Coimbatore

Mangalore

Kharagpur

Trichy

Pune

Mysore

City

Maharashtra

Tamil Nadu

Tamil Nadu

Tamil Nadu

Kerala

Punjab

Maharashtra

Rajasthan

Maharashtra

Kerala

Gujarat

Andhra Pradesh

Tamil Nadu

Tamil Nadu

Karnataka

Andhra Pradesh

Uttar Pradesh

Karnataka

Tamil Nadu

Karnataka

West Bengal

Tamil Nadu

Maharashtra

Karnataka

State

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

DST
NSTE
DB

a

a

a

a

a

a

DeitY
TIDE

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

Mo
MSME

a

a

a

a

DBT

a

a

a

a

a

a

a

a

a

a

a

DST
TDB

a

a

a

DSIRPRISM

a

a

a

a

a

a

a

a

a

a

a

a

DSIR
TePP

2007

2006

2006

2006

2006

2005

2005

2004

2004

2004

2004

2006

2003

2003

2003

2003

2000

1999

1998

1994

1986

1986

1986

1985

Year

52

1020

78

160

4500

64

1063

70

100

417

141

1093

205

230

1500

280

1120

2900

1000

1000

550

175

722

2050

Employ
ment
(last 5
Years)
2014

23

35

10

-

137

23

46

-

-

40

44

34

22

45

73

40

66

11

128

5

76

-

63

36

Incubaters
and
Graduates
(Total) 2014

Appendix C: List of incubators with government support

THE ROLE OF INCUBATORS AND PUBLIC POLICY

<!-- page 69 -->

Ekta Incubation Centre - TBI

IIIT Hyderabad - TBI

Amrita Vishwa Vidyapeetham - TBI

Amity University - TBI

IIM Ahmedabad - Centre for Innovation
Incubation and Entrepreneurship

IIT Kanpur - TBI

University of Delhi - TBI

Mudra Institute of Communications -Design
Business Incubator

National Dairy Research Institute - Society for Karnal
Innovation and Entrepreneurship

Ehealth - TBI

Dattajirao Kadam Education Society - TBI

Kalinga Institute of Industrial Technology
- TBI

St. Peter’s Engineering College - TBI

IIT Benares Hindu University - TBI

University of Hyderabad - TBI

Global Incubation Services - TBI

Shriram Institute - TBI

Indian Angel Network - TBI

Manipal University - TBI

Veltech - TBI

PCCE - Centre for Innovation & Business
Accelerator

Tamil Nadu Agricultural University - TBI

Adhiyamaan College of Engineering - TBI

College of Engineering Trivandrum - TBI

27

28

29

30

31

32

33

34

35

36

37

38

55

39

40

41

42

43

44

45

46

47

48

49

50

Trivandrum

Hosur

Coimbatore

Verna

Chennai

Manipal

Delhi

Delhi

Bengaluru

Hyderabad

Varanasi

Chennai

Bhubaneshwar

Ichalkaranji

Bengaluru

Ahmedabad

Delhi

Kanpur

Ahmedabad

Noida

Kollam

Hyderabad

Kolkata

Ghaziabad

Krishna Institute of Engineering Technology
- TBI

26

Erode

Bannari Amman Institute of Technology - TBI

25

Tamil Nadu

Kerala

Tamil Nadu

Tamil Nadu

Goa

Tamil Nadu

Karnataka

Delhi

Delhi

Karnataka

Andhra Pradesh

Uttar Pradesh

Tamil Nadu

Orissa

Maharashtra

Karnataka

Haryana

Gujarat

Delhi

Uttar Pradesh

Gujarat

Uttar Pradesh

Kerala

Andhra Pradesh

West Bengal

Uttar Pradesh

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

2012

2011

2011

2011

2010

2010

2010

2010

2010

2010

2009

2009

2009

2009

2009

2009

2009

2009

2008

2008

2008

2008

2008

2007

2007

2007

27

-

30

93

36

1

55

134

160

125

25

5

40

192

349

120

11

16

22

900

1200

3500

-

180

40

188

-

-

5

11

15

11

43

-

39

-

11

-

26

33

16

5

9

9

44

72

16

-

30

45

22

13

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

<!-- page 70 -->

IIT Delhi

IIIT, Bangalore

ABV-IIITM, Gwalior

IIIT, Allahabad

IIM, Bangalore

Dhirubhai Ambani Institute of Information
and Communication Technology

IIT Guwahati

Central University of Rajasthan

IIT Roorkee

IIT Gandhi Nagar

MANIT Bhopal

IIT Ropar

IIT Madras

Banasthali Vidya Peeth

Sardar Vallabhbhai National Institute of
Technology

North Eastern Regional Institute of Science
and Technology (NERIST)

Vivekanand Institute of Biotechnology

Central Institute of Plastic Engineering &
Technology (CIPET)

Galgotias College of Engineering and
Technology

National Afforestation & Eco-Development
Board

MEPCO SCHLENK Engineering College

57

58

59

60

61

62

63

64

65

66

67

68

69

70

71

72

73

74

75

76

Bits Pilani Hyderabad - TBI

54

IISc. Bangalore

Indian Telecom Innovation Hub - TBI

53

55

Villgro - TBI

52

56

Technovate India Innovations - TBI

51

56
Sivakashi

Kolkata

Noida

Lucknow

Pagrana

Itanagar

Surat

Jaipur

Chennai

Ropar

Bhopal

Gandhinagar

Roorkee

Ajmer

Guwahati

Gandhinagar

Bangalore

Allahabad

Gwalior

Bangalore

Bangalore

New Delhi

Hyderabad

Kochi

Chennai

Bengaluru

Tamil Nadu

West Bengal

Uttar Pradesh

Uttar Pradesh

West Bengal

Arunachal
Pradesh

Gujarat

Rajasthan

Tamil Nadu

Punjab

Madhya Pradesh

Gujarat

Uttarakhand

Rajasthan

Orissa

Gujarat

Karnataka

Uttar Pradesh

Madhya Pradesh

Karnataka

Karnataka

Delhi

Andhra Pradesh

Kerala

Tamil Nadu

Karnataka

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

2013

2013

2001

2012

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

1523

3803

18

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

39

19

-

-

-

-

-

-

-

THE ROLE OF INCUBATORS AND PUBLIC POLICY

<!-- page 71 -->

Konark Institute of Science & Technology

Inderprastha Engineering College

Xavier Institute of Management

Institute of Engineering & Technology

Business Planning and Development Unit

Mahatma Gandhi Institute for Rural
Industrialization

Central Institute for Research on Cotton
Technology (CIRCOT)

Nagaland Mini Tool Room & Training Centre

95

96

97

98

99

100

101

102

Management Studies & Research Centre

89

J.N.T.U.H. College of Engineering Hyderabad

Research and Technology Development
Centre

88

94

VNS Group of Education

87

GMR Institute of Technology

Lakshmi Narayan College of Technology

86

Nizam College of Engineering & Technology

Indian School of Mines

85

93

Maharaj Vijayaram Gajapathi Raj College of
Engineering

84

92

Padmasri Dr. B.V. Raju Institute of Technology Medak

83

Dalmia Institute of Scientific and Industrial
Research

Jadavpur University

82

91

Ramrao Adik Institute of Technology

81

Gujarat Energy Research and Management
Institute

C.V.Raman College of Engineering
Bidyanagar

80

90

National Institute of Science & Technology

79

Orissa

Tamil Nadu

Gujarat

57
Dimapur

Mumbai

Wardha

Anand

Alwar

Bhubaneshwar

Ghaziabad

Khurda

Hyderabad

Srikakulam

Nalgonda

Sundargarh

Gandhinagar

Bokaro

Noida

Bhopal

Indore

Dhanbad

Vizianagaram

Kolkata

Mumbai

Nagaland

Maharashtra

Maharashtra

Gujarat

Rajasthan

Orissa

Uttar Pradesh

Orissa

Andhra Pradesh

Andhra Pradesh

Telangana

Orissa

Gujarat

Jharkhand

Uttar Pradesh

Madhya Pradesh

Madhya Pradesh

Jharkhand

Andhra Pradesh

Andhra Pradesh

West Bengal

Maharashtra

Bhubaneshwar Orissa

Behrampur

Madurai

Lady Doak College

78

Ahmedabad

Xavier Research Foundation

77

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

<!-- page 72 -->

Modern Engineering & Management Studies

Alwar Institute of Engineering & Technology

CCS Haryana Agriculture University

Indian Agriculture Research Institute

Majhighaririani Institute of Technology and
Science (MITS)

Sri Krishna College of Engineering and
Technology

123

124

125

126

Entrepreneurship Development Cell

115

122

Centre for Integrated Rural Development

114

121

Innovation Lab, Tedex Tech Park

113

Coimbatore Institute of Engineering and
Technology

Central Institute of Fisheries Technology

112

120

Krishi Vigyan Kendra AT Durgapur (Badnera)

111

Gokaraju Rangaraju Institute of Engineering
& Technology

Rajdhani College of Engineering and
Management

110

119

Radharaman Institute of Research & Technology
(RIRT)

109

Aditya Institute of Technology and
Management

Gandhi Institution of Management Studies

108

118

Shri Sant Gajanan Maharaj College of
Engineering

107

Institute of Technical Education & Research,
S.O.A.University

Government College of Engineering

106

117

Business Planning & Development Unit

105

Indian Veterinary Research Institute

D J College of Engineering & Technology

104

116

NIFT-TEA College of Knitwear Fashion

103

Tamil Nadu

Madhya Pradesh

Orissa

Maharashtra

Maharashtra

Madhya Pradesh

Uttar Pradesh

Andhra Pradesh

Kerala

Kerala

Maharashtra

58
Coimbatore

Rayagada

New Delhi

Hisar

Alwar

Balasore

Coimbatore

Hyderabad

Tekkali

Bhubaneshwar

Izatnagar

Tamil Nadu

Orissa

Delhi

Haryana

Rajasthan

Orissa

Tamil Nadu

Andhra Pradesh

Andhra Pradesh

Orissa

Uttar Pradesh

Thiruvananthapuram Kerala

Vishakapatnam

Kathrikkadavu

Cochin

Amravati

Bhubaneshwar Orissa

Bhopal

Raigada

Buldhana

Aurangabad

Jabalpur

Ghaziabad

Tirupur

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

THE ROLE OF INCUBATORS AND PUBLIC POLICY

<!-- page 73 -->

Society for Biotechnology Incubation Centre
– SBTIC

B.V. Patel Pharmaceutical Education &
Research Development (PERD) Centre

CSIR-Central Scientific Instruments
Organization (CSIO)

Central Mechanical Engineering Research
Institute

Acharya Nagarjuna University

TOCIC-NEIST

CSIR-Central Glass Ceramic Research Institute
(CGCRI)

CSIR- Institute of Himalayan Bioresource
Technology

University Science Instrumentation Centre
(USIC), University of Kashmir

Sri Padmavati Mahila Visvavidyalayam (SPMV) Tirupati

College of Technology and
Engineering(CTAE)

ERDC Campus

Chhatisgarh Swami Vivekanand Technical
University

Uttarakhand State Council for Science &
Technology (UCOST)

CSIR- National Environmental Engineering
Research Institute

CSIR-Central Electronics Engineering Research
Institute

National Institute of Technology

Sri Siddhartha Institute of Technology-STEP

129

130

131

132

133

134

135

136

137

138

139

59

140

141

142

143

144

145

146

Tumkur

Silchar

Pilani

Nagpur

Dehradun

Bhilai

Ambala

Udaipur

Srinagar

Palampur

Kolkata

Jorhat

Guntur

Durgapur

Chandigarh

Ahmedabad

Hyderabad

Bangalore

Centre for Cellular and Molecular Platforms
(C-CAMP)

128

Kanpur

Harcourt Butler Technological Institute
(H.B.T.I.)

127

Karnataka

Assam

Rajasthan

Maharashtra

Uttarakhand

Chattisgarh

Haryana

Rajasthan

Tamil Nadu

Jammu &
Kashmir

Himachal Pradesh

West Bengal

Assam

Andhra Pradesh

West Bengal

Chandigarh

Gujarat

Andhra Pradesh

Karnataka

Uttar Pradesh
a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

a

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

<!-- page 74 -->

60

DBT – Dept. of
Biotechnology

DST – NSTEDB
and TDB

Department

Biotechnology
Ignition Grant
(BIG)

Bio-incubators
Support Scheme
(BISS)

NSTEDB – Seed
Support Scheme

TDB fund

NSTEDB Technology
Business
Incubators (TBI)

Name of
initiative

Government programs

50 lakhs

50 lakhs

25 lakhs

(INR lakhs)

Max.
support

-

PPP model
(contribution
from startup)

Grant [BISS
incubators manage
incubatees]

[for incubatees
affiliated to TBI/
STEP]

Loan, equity, or
sharing royalty

Loan, equity
[for incubatees
affiliated to TBI/
STEP]

Loan conditions/
details

For startups/incubatees

Only up to proofof-concept

Product
development,
prototyping,
scale-up, testing,
marketing, IPR

Developing new
products or
processes

Target startups

-

Support for
first 5 years

Infrastructure,
administration
(INR lakhs)

Biomedical
devices, biotech
incl. agriculture,
energy,
healthcare,
diagnostics, etc.

Priority
Sectors

For incubators

Appendix D: Government initiatives to support
incubators and startups

THE ROLE OF INCUBATORS AND PUBLIC POLICY

<!-- page 75 -->

MoMSME –
Ministry of
Micro Small
and Medium
Enterprises

DeitY – Dept.
of Electronics
and
Information
Technology

DSIR – Dept.
for Scientific
and Industrial
Research

50 lakhs

Prism Phase II

MoMSME Grant

61
[10
grants/
incubator]

6.25 lakhs

[6 grants/
incubator]

25 lakhs

20 lakhs

Prism Phase I
Cat II [individual
innovators]

Technology
Incubation and
Development of
Entrepreneurs
(TIDE)

2 lakhs

Prism Phase I
Cat I [individual
innovators]

12-15%

20%

At least 50%

At least 10%

At least 10%

[affiliated to host
incubator]

Grant

Combination of
loan and equity [for
incubateesaffiliated
to TIDE centre]

[DSIR incubators –
TOCICs –support
and monitor
startup progress]

Grant

New products or
services

Scaling-up and
enterprise
creation

Demonstration,
IPR, tech
transfer

Proof-of-concept
[individual
innovators]

4 lakhs

30 lakhs

- 10% of
grants for
innovators
to monitor
projects

- 12 lakhs/
year for
expenses

High tech
(nanotechnology,
biotech, IT, etc.),
others (food
processing,
ceramics, etc.)

ICT products and
packages

(excl. software,
basic research)

Green
Technology,
Clean Energy,
smart materials,
Waste to wealth,
healthcare, water,
management;

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

<!-- page 76 -->

<!-- page 77 -->

Appendix E:
Case Studies

<!-- page 78 -->

<!-- page 79 -->

DST CENTRE FOR POLICY RESEARCH, INDIAN INSTITUTE OF TECHNOLOGY

APPENDIX E-1

Center for Innovation Incubation and
Entrepreneurship (CIIE)
Indian Institute of Management, Ahmedabad

This case study mainly presents CIIE’s history and activities until end of 2015. Subsequent developments including updates around collaboration
with other state governments, shift towards a national focus etc. are not discussed in detail here.
14

65

<!-- page 80 -->
