---
doc_id: "47e0dd0f1ddce9ae"
source_url: "https://doj.gov.in/static/uploads/2025/09/6c34d511162bc52955516e265c081209.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Justice Robin Phukan, Addl. Judge of Gauhati High Court as a Permanent Judge of Gauhati High Court (13.05.2023)"
date: "2023-05-13"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9fbe6fdb3b00d9b5"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K-13018/02/2023-US.II
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011.
Dated: 13th May, 2023.

NOTIFICATION
In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint Shri Justice Robin
Phukan, Additional Judge of the Gauhati High Court, to be a Judge of the Gauhati
High Court, with effect from the date he assumes charge of his office.

/3017-ns
(Rajinder Kashyap)
Special Secretary to the Government of India
Tele: 2338 3037

The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

-2
No. K-13018/02/2023-USJI

Dated: 13.05.2023

Copy to:1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.

Shri Justice Robin Phukan, Additional Judge of the Gauhati High
Court through the Registrar General, Gauhati High Court, Guwahati.
The Secretary to Governor, Assam, Dispur.
The Secretary to Governor, Arunachal Pradesh, Itanagar.
The Secretary to Governor, Mizoram, Aizawal.
The Secretary to Governor, Nagaland, Kohima.
The Secretary to Chief Minister, Assam, Dispur.
The Secretary to Chief Minister, Arunachal Pradesh, Itanagar.
The Secretary to Chief Minister, Mizoram, Aizawal.
The Secretary to Chief Minister, Nagaland, Kohima.
The Secretary to the Chief Justice, Gauhati High Court, Guwahati.
The Chief Secretary, Government of Assam, Dispur.
The Chief Secretary, Government of Arunachal Pradesh, Itanagar.
The Chief Secretary to Government, Mizoram,Aizwal
The Chief Secretary to Government, Nagaland, Kohima.
The Registrar General, Gauhati High Court, Guwahati.
The Accountant General, Assam, Dispur.
The President's Secretariat, (CA.II Section), Rashtrapati Bhavan,
New Delhi
PS to Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
Registrar (Conf.), o/o Chief Justice of India, 7, Krishna Menon Marg,
New Delhi.
PS to ML&J/ Sr.PPS to MoS (L&J)/ PPS to Secretary (J).
Technical Director, MC, Department of Justice, with a request to
upload on the website of the Department (www.doi.gov.in).

9
14
(Prem Chand)
Under Secretary (Appointments-I)
Tele: 011-23382978
