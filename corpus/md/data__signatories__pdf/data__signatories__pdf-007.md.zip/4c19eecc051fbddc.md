---
doc_id: "4c19eecc051fbddc"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/71d2106deb84d4c5f7ac34baec361441.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment of two advocates for Supreme Court of India: Order dated 18.10.2019"
date: "2019-10-18"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b565ef08fa9cc37d"
---

<!-- page 1 -->

F. No, J-11016/4/2019-Judicial(Part-1)
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
ie
Shastri Bhawan, New Delhi,
Dated 18” October, 2019
ORDER
हर पल is pleased to engage following two Advocates for conducting Central Government
of three years e the Supreme Court of India, as mentioned below, from the date of this order for a period
years or until further orders, whichever is earlier: o थे
SUPREME COURT OF INDIA
Sl.No. | NAME (Shri Contact details [Enri.No. |
Group ‘A’ Panel Counsel
Neeraj Kumar Res. #9/401, Aashiyana Homes, D/757/2007
Basai Brahmuddin Nagar, Sector-70,
NOIDA-201301
Mob: 9650841871
Email: adv.neerajkumar@gmail.com
Group ‘B’ Panel Counsel
2 Purnendu Bajpai Delhi CG-1, 706, Supertech Cape UP/5200/2015
Town, Sector-74, NOIDA, Uttar
Pradesh-201301
Mob: 8077118198
Email: purnendu.bajpai@gmail.com
Ze The terms & conditions of the engagement of aforesaid Advocates will be governed by this
Department's OM No. 21(4)/99-Judl. dated 24.09.1999 read with OM No. 26(1)/2014/Judl. dated
01.10.2015 & instructions issued subsequently through OMs. The aforesaid OMs are available on the
website of this Department i.e. www.legalaffairs.gov.in in the tab ‘Judicial Section’ under heading
‘Circulars pertaining to litigations’.
vd Hindi version of this order will follow. oye
EX
(S. R. Mishra)
Additional Secretary
Copy to:-
4. PS to ML&J/PS to Law Secretary/PS to Legislative Secretary/Alll Additional Secretaries/PS to all JS&LA in the
Main Sectt.
2. PS to Attorney General, PS to Solicitor General, PS to All Addl. Solicitors General
3. The Registrar, Supreme Court of India, New Delhi
4. The Incharge, Central Agency Section, Supreme Court Compound, New Delhi
5. Allthe Branch Secretariats Mumbai, Kolkata, Bengaluru & Chennai
6. The two panel counsel, as above
7. The Pay & Accounts Office, Department of Legal Affairs, New Delhi
8. One copy of this order is uploaded on website of this Department i.e. www. legalaffairs.gov.in under tab
“Judicial Section’ in the link ‘List of empanelled Counsel for the information of all concerned.
9. Hindi unit, Department of Legal Affairs for Hindi translation of the order
40. Guard File/Judicial Section with 5 spare copies. =
(D. Srinivas)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
