---
doc_id: "4b2e6c8adcfe5fee"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/8d99cca52bf4cdf810275220610f7e4f.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment of Ms. Krishnamoni Phukan, Advocate as CGC for Gauhati High Court (PB) Guwahati: Order dated 12.10.2022"
date: "2022-10-12"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "5f2f7c10f6ee8d08"
---

<!-- page 1 -->

F. No. J-11017/6/2022-Judicial (Part-1)
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi,
Dated the |) October, 2022
ORDER
The President is pleased to engage Shri Krishnamoni Phukan, Advocate as Central
Government Counsel for conducting Central Government litigations before the Gauhati High -
Court (PB) at Guwahati, as shown below, for a period of three years with effect from the date *
of this order or until further orders, whichever is earlier:
GAUHATI HIGH COURT (PB) AT GUWAHATI
CENTRAL GOVERNMENT COUNSEL
Name of Advocate Contact details Enrollment No.
Ms. Krishnamoni Dwarka Nagar, Hem Baruah Path, 49 of 1997
Phukan House No. 9, PO-Assam Sachivalaya,
Dispur, Guwahati-6.
कै The engagement and professional fee of the aforesaid advocate will be governed by
the terms and conditions contained in this Department's OM No. 26(1)/1999-Judl. dated
24.09.1999 read with OM No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued
subsequently through OMs. The aforesaid OMs are available on the website of this
Department i.e. www.legalaffairs.gov.in under the tab ‘Judicial Section’ and in the link
‘Circulars pertaining to litigations’.
3. Hindi version of this order will follow. UU
erate \o\%
\ Kumar Sharma)
Joint Secretary & Legal Adviser
Copy for information to:-
1. PS to Hon'ble MLJ/ Sr. PPS to Hon’ble MSLJ.
2. Sr. PPS to Law Secretary/PSO to AS (RSV)/PSO to AS (RM)/Sr. PPS to AS (ARR)/ Sr. PPS to
Sr. G.A. (MK)/Sr. PPS to JS&LA (SA).
3. The Incharge, Branch Secretariat at Kolkata.
4. Shri Ranjit Kumar Dev Choudhury, Deputy SGI, Gauhati High Court (PB) at Guwahati.
5. The Registrar, Gauhati High Court (PB) at Guwahati, Assam.
6. Ms. Krishnamoni Phukan, CGC as above.
7. To be uploaded on the website of this Department i.e. www.legalaffairs.gov.in under the t
‘Judicial Section’ in the link ‘List of empanelled Counsel’ for the information of all concerned. |)
8. Hindi unit, Department of Legal Affairs for Hindi translation of the order. A Loh
9. Guard File/Judicial Section with 5 spare copies. WX out
> Vat oft
(Lakka Muneswara Rao)
Section Officer (Judicial)
Phone: 011-23384945
Email: Judicial-dla@nic.in
