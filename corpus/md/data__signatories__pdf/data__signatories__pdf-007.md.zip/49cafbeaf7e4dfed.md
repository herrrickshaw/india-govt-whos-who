---
doc_id: "49cafbeaf7e4dfed"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/2e719480c2d8592f5eed5a6fbe52f8ef.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Centrifugally Cast (Spun) Iron Pipes (Quality Control) Order, 2021"
date: "2025-07-01"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "56ac74478bc0ee8c"
---

<!-- page 1 -->

155
286935/2021/LEI
रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

xxxGIDHxxx

सी.जी.-डी.एल.-अ.-12012021-224351
xxxGIDExxx
CG-DL-E-12012021-224351
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं.

96]

No. 96]

नई ददल्ली, मंगलवार, िनवरी 12, 2021/पौर् 22, 1942
NEW DELHI, TUESDAY, JANUARY 12, 2021/PAUSHA 22, 1942

वाजणज्य रर उ्योगग मं्ालय
(उ्योगग संवधधन रर आंतररक व्यापार जवभाग)
आदेि
नई ददल्ली, 12 िनवरी, 2021
का.आ. 116(अ).—भारतीय मानक ब्यूरयोग अजधजनयम, 2016 (2016 का 11) की धारा 25 रर धारा 17 के साथ
परित धारा 16 द्वारा प्रदत्त िजियों का प्रययोगग करते हुए, कें द्र सरकार का ब्यूरयोग के साथ परामिध करने के बाद यह मत है
दक यह िनजहत में आवश्यक अथवा जहतकर है, अत: एतद्द्वारा जनम्नजलजखत आदेि करती है, नामत: 1. संजिप्त िीर्धक रर प्रारंभ - (1) इस आदेि कयोग सेंररफ्युगली कास्ट्ट (स्ट्पन) आयरन पाइप्स (गुणवत्ता जनयं्ण) आदेि,
2021 कहा िाएगा।
(2) यह 01 अगस्ट्त, 2021 से प्रभावी हयोगगा।
2. मानक का अनुपालन रर मानक जिह्न का अजनवायध प्रययोगग- ताजलका के कॉलम (1) में जवजनर्ददष्ट वस्ट्तुएं या सामान
उक्त ताजलका के कॉलम (2) में उजल्लजखत तद्नुरूपी भारतीय मानक के अनुरूप होंगे तथा उनमें भारतीय मानक ब्यूरयोग
(अनुपालन मूल्यांकन) जवजनयम, 2018 की अनुसूिी-II की स्ट्कीम-I के अनुसार ब्यूरयोग के लाइसेंस के तहत मानक जिह्न लगा
हयोगगा।
बिते दक इस आदेि में से कु छ भी जनयाधत की िाने वाली वस्ट्तुओं या सामान पर लागू नहीं हयोगगा।
3.
प्रमाणन रर प्रवतधन प्राजधकरण – यह ब्यूरयोग ताजलका के कॉलम (1) में जवजनर्ददष्ट वस्ट्तुओं या सामान के संबंध में
प्रमाणन रर प्रवतधन प्राजधकरण हयोगगा।
166 GI/2021

(1)

<!-- page 2 -->

156
286935/2021/LEI
2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

ताजलका
वस्ट्तु या सामान

भारतीय मानक

भारतीय मानक का िीर्धक

(1)

(2)

(3)

आईएस 1536: 2001

पानी, गैस रर सीवेि के जलए सेंररफ्युगली कास्ट्ट (स्ट्पन) आयरन
प्रेिर पाइप्स- जविेर्ताएं

आईएस 3989: 2009

सेंररफ्युगली कास्ट्ट (स्ट्पन) आयरन जस्ट्पगॉट रर सॉके ट सॉयल, वेस्ट्ट,
वेंरटलेटटग रर रे नवॉटर पाइप्स, दिटटग्स रर एक्सेसरीि –
जविेर्ताएं

सेंररफ्युगली कास्ट्ट
(स्ट्पन)
आयरन पाइप्स

आईएस 15905: 2011 हबलेस सेंररफ्युगली कास्ट्ट (स्ट्पन) आयरन पाइप्स, दिटटग्स रर
एक्सेसरीि – जस्ट्पगॉट श्ृंखला – जविेर्ताएं
नयोगट :

इस ताजलका के प्रययोगिन के जलए, उनके संबंध में िारी संियोगधनों सजहत भारतीय मानकों के नवीनतम संस्ट्करण,
िैसा दक ब्यूरयोग द्वारा समय-समय पर अजधसूजित दकए गए हैं, ऐसी अजधसूिना की तारीख से लागू होंगे।
[िा. सं. पी-29026/3/2020-एलईआई]
अजनल अग्रवाल, संयुक्त सजिव

MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
ORDER
New Delhi, the 12th January, 2021
S.O. 116(E).—In exercise of the powers conferred by section 16 read with section 17 and section
25 of the Bureau of Indian Standards Act, 2016 (11 of 2016), the Central Government, after consulting the
Bureau, is of the opinion that it is necessary or expedient so to do in the public interest, hereby makes the
following Order, namely:1. Short title and commencement. – (1) This Order may be called the Centrifugally Cast (Spun) Iron
Pipes (Quality Control) Order, 2021.
(2) It shall come into force with effect from the 01st day of August, 2021.
2. Conformity to standard and compulsory use of Standard Mark.- The goods or articles specified in
the column (1) of the Table shall conform to the corresponding Indian Standard specified in column (2) of
the said Table and shall bear the Standard Mark under a licence from the Bureau as per Scheme-I of
Schedule-II of the Bureau of Indian Standards (Conformity Assessment) Regulations, 2018:
Provided that nothing in this Order shall apply to goods or articles meant for export.
3. Certification and enforcement authority.- The Bureau shall be the certifying and enforcing authority
for the goods or articles specified in the column (1) of the Table.
TABLE
Goods or
articles.
(1)
Centrifugally cast
(Spun)
iron pipes.

Indian
Standard.
(2)
IS 1536: 2001
IS 3989: 2009

Title of Indian Standard.
(3)
Centrifugally cast (Spun) iron pressure pipes for water, gas and
sewage – Specification.
Centrifugally cast (Spun) iron spigot and socket soil, waste,
ventilating and rainwater pipes, fittings and accessories –
Specification.

<!-- page 3 -->

157
286935/2021/LEI

[भाग II—खण्ड 3(ii)]

3

भारत का रािप् : असाधारण

IS 15905: 2011

Hubless centrifugally cast (Spun) iron pipes,
fittings and accessories - Spigot series –
Specification.

Note : For the purposes of this table, the latest version of Indian Standards including the amendments
issued thereof, as may be notified by the Bureau from time to time, shall apply from the date of
such notification.
[F. No. P-29026/3/2020-LEI]
ANIL AGRAWAL, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
