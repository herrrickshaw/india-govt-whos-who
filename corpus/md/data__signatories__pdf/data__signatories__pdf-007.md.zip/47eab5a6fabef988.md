---
doc_id: "47eab5a6fabef988"
source_url: "https://doj.gov.in/static/uploads/2025/09/3e4f84e774116e4d73d1d2d2a56e39c8.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Justice Biswaroop Chowdhury & others, Additional Judges of the Calcutta High Court as Add. Judges of that HC for a fresh term of 1 year w.e.f.31.08.2024 (05.08.2024)"
date: "2024-08-05"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "17f99e039a01bac3"
---

<!-- page 1 -->

(TO BE PUBLISHED

IN THE GAZETTE

OF INDIA, PART 1 SECTION 2)

No. K-1301S/03/2024-US.II
Government of India
Ministry of Law & Justice

Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 OIl.
Dated os- August, 2024.

NOTIFICATION
In exercise of the power conferred by clause (1) of Article 224 of the
Constitution of India, the President is pleased to appoint S/Shri Justices (i)
Biswaroop Chowdhury, (ii) Partha Sarathi Sen, (iii) Prasenjit Biswas, (iv) Uday
Kumar, (v) Ajay Kumar Gupta, (vi) Supratim Bhattacharya, (vii) Partha Sarathi
Chatterjee, (viii) Apurba Sinha Ray and (ix) Md. Shabbar Rashidi, Additional
Judges of Calcutta High Court, to be Additional Judges of the Calcutta High
Court, for a fresh term of one year w.e.f. 31.08.2024.

II

Z'"

(Jagannat
rinivasan)
Joint Secretary to the Government of India
Tele: 23383037

To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

-2-

Dated: 05.08.2024.

No. K-13015/03/2024-US.II

Copy to:1.

S/Shri Justices (i) Biswaroop Chowdhury, (ii) Partha Sarathi Sen, (iii)
Prasenjit Biswas, (iv) Uday Kumar, (v) Ajay Kumar Gupta, (vi) Supratim
Bhattacharya, (vii) Partha Sarathi Chatterjee, (viii) Apurba Sinha Ray and
(ix) Md. Shabbar Rashidi, Additional Judges, Calcutta High Court through
the Registrar General, Calcutta High Court, Kolkata.
2. The Secretary to Governor, West Bengal, Kolkata.
3. The Secretary to Chief Minister, West Bengal, Kolkata.
4. The Secretary to the Chief Justice, Calcutta High Court, Kolkata.
5. The Chief Secretary, Government of West Bengal, Kolkata.
6. The Registrar General, Calcutta High Court, Kolkata.
7. The Accountant General, West Bengal, Kolkata.
8. The President's Secretariat, (CA.II Section), Rashtrapati Bhawan, New
Delhi.
9. PS to the Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
10. Registrar (Conf.), % the Chief Justice of India, 07, Krishna Menon Marg,
New Delhi.
11. PS to the MoS, L&J (IIC)/ PPS to the Secretary (Justice).
12. Sr. Technical Director, NIC, Department of Justice, with a request to
upload the notification on the website of the Department
(www.doj.gov.in).
.A . ~.d;\wJ\~J\__--------

~

o, . t)~~~;'-

'V'-1

(An ant Kumar)
Under Secretary to the Govt. of India
Tele: 23072138
