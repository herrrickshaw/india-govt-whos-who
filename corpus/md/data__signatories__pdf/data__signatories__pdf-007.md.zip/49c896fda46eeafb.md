---
doc_id: "49c896fda46eeafb"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/030da2a55bf6a9bc5725fd2032cad1cc.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Clarification on FDI Policy for uploading/streaming of news and current affairs through Digital Media"
date: "2025-07-04"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7b8d4c4c3d4d8312"
---

<!-- page 1 -->

Government of India
India
Industry
Ministry of Commerce & Industry
Department for Promotion of Industry
Internal Trade
Industry & Internal
Clarification on
on FDI
FDI Policy for uploading/streaming of news
news and
and current affairs
affairs
through Digital
Digital Media
through

Vide Press
otc 4 of 2019 dated 18.09.2019, the Central Government had
Press Note
had decided to
to
liberalise
the
FOi
regime
for
entities
engaged
in
the
New
Digital
Media
Sector.
Accordingly.
liberalise
FDI regime
in
News Digital
Accordingly,
in uploading/streaming of news
news and
and current affairs through digital
digital media
entities engaged in
have been
been permitted FOi
FD! up
up to
to 26% through the Government approval
approval route.
route.
2.
Department had
had received
received representations
representations from
from stakeholders seeking clarifications
2.
The Department
clarified
on certain aspects of the aforesaid decision. After due consultations. itit is clari
ftcd as under:

(i)
The decision of permitting 26% FOi
FD! through Government route would
would apply to
to
following
following categories of Indian
Indian entities. registered
registered or located
located in
in India:
India:
(a)

digital
treaming/uploading new
digital media entity streaming/uploading
news and
and current affairs on
on websites. apps or
other platform
platforms:

(b)

and distributes/transmits news. directly or
news agency which gathers. writes and
digital media entities and/or news
news aggregators; and
indirectly, to digital

(c)

aggregator, being an entity which, using software or web application. aggregates
news aggregator.
uch aas news
news content from
from various sources. such
news websites.
websites, biogs.
blogs, podcasts.
podeasts, video
video
location.
biogs.
submitted link
biogs, user submitted
links.. etc in
in one location.

(ii)
Entities covered under (i) above would
Entities
would be
be required
required to align
align their FOi
FDI to
to the 26% level
level
Government. within
with the approval
approval of the Central
Central Government,
within one year from
from the date of issue
issue of this
this
clarification.
3.
Compliance with the FOi
FD! Policy
Policy and the applicable FEMA
FEMA Notification
3.
otification (including the
Notification S.O. 4355 (E) dated 5th December.
December, 2019)
2019) would be
be the re
responsibility
the
Notification
ponsibility of the
investee
investee entity. Further, the entity would
would adhere to
to the following
following conditions:
(a)
(a)

The majority of Directors
Directors on the Board of the company shall
shall be Indian
Indian citizens;
citizens:

(b)
(b)

The Chief Executive Officer shall
be an Indian citizen;
shall be

(c)
(e)

The entity shall
hall be required to obtain security clearance of all
personnel likely
all foreign
foreign personnel
likely
to
than 60 days
day in
to be deployed for more than
in a year by way of appointment. contract or
consultancy or in
in any other capacity for functioning
functioning of the entity prior to their
In the event of security clearance of any of the foreign
foreign personnel
personnel being
deployment. In
denied or withdrawn for
ll ensure that
for any reasons whatsoever. the investee
investee entity wi
will
person
resigns or his/her scr
services
arc terminated
terminated forthwith
forthwith after
on resigns
ices are
the concerned per
from the Government.
receiving such
uch directives from

G:1,
«1I-1,.
0

((Nikhil
ikhil Kumar Kanodia)
Director
Director (FOi)
(FDI)
o: 5(4)/2019-FDIPolicy dated 16.10.2020
DPIIT File
File No:
16.10.2020
