---
doc_id: "4abe6f34097badda"
source_url: "https://www.dsir.gov.in/static/uploads/2025/10/85f4036e38723cb91bf01571a7972010.pdf"
ministry: "Department of Scientific and Industrial Research (DSIR)"
title: "Instructions and Application Format [15/07/2025]"
date: "2025-07-15"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f174a3be2a5d95c4"
---

<!-- page 1 -->

Instructions for Online Application of PFRI Fresh and Renewal of Registration
Submission
1. Applicants may refer Public Funded Research Institute (PFRI) guidelines for the
scheme details and follow the instructions thoroughly..
2. For Online Applications, applicants are advised to keep required information and
documents ready for upload. Form fields of the applications are mentioned below this
document for ready reference.
3. For submission, the applicant shall be taken to the service plus portal at
https://serviceonline.gov.in/dbt
4. The applicant shall first have to register for accessing the schemes on the service plus
portal.
5. For the PFRI scheme, applicants are required to register in the name of the
organization. Applicant organization name should preferably be the parent
Legal entity with the research achievements of all the institutions operating
under the legal entity and the recognition is valid for all.
6. After registering, the applicant organization can log in with the registered login
Credentials.
7. After log in, PFRI scheme can be reached through Apply for Services --> View all
Available services --> Public Funded Research Institute (PFRI) (Search PFRI for
quick access)
8. After su bmission , the applicant organization will receive an Acknowledgement
receipt where it will have the Application Reference Number (App Ref No.).
9. Applicant may check the application status as: Login --> View Application status -->
Track Application status -->App Ref No. --> Get Data.
10. It's advisable to keep saving data by clicking on DRAFT while filling the form.
11. Once it saves in Draft, applicant will get a pop-up notifying App Ref No.
12. This App Ref No. will be used to further track the Draft Application as: View status
of Application --> View Incomplete Application.
13. Applicants can manage the profile after registering.
14. The applicant is required to fill all the required fields and upload all the relevant
documents.
15. Applicants are advised to observe patience as draft saving/submission may take little
time on many occasions.
16. The auto-fill fields have to be clicked for proper insertion.

<!-- page 2 -->

17. For issues like Data tampering, Data loss, etc. refer possible solutions below:
Problem Criteria
Data Tampering Issue

 Compress ‘all’ pdf files to be uploaded and

Possible Solution

To Avoid Data Loss

 Clear Browser cache & history and tryagain
 Check Network and Firewall settings.
 Frequently use the draft button to save the data.

Session Time out

 On few occasions, server takes time to save the data and

‘rename ‘’ them without spaces in the file name.

Disappearing of the
collapsing fields

View uploaded
document
Registration in the
name of the
Organization

get timed-out.
 Have patience, keep trying and keep the page active.
 Re-click the dropdown and select “Please Select”
(default option) and then re-select the required
option as per the
case for reappearance of collapsing field.
 In case of viewing issue of uploaded document, it
is suggested to reattach the documents under doubt.
 Profile details can be modified before submission
of application.
 Edit and change the Name of Profile (from person
to Organisation’s Name).

18. All attachments to the online applications must be in the .pdf file format only.
19. DSIR reserves the right to summarily reject the application at any stage, if it is
convinced that the application is not properly filled or the relevant information is not
provided.
20. For any queries regarding the submission of online proposals under PFRI, please
email to the Member Secretary, PFRI.
21. Form fields of the applications are appended below.

<!-- page 3 -->

8/29/23, 12:59 AM

ServicePlus- Public Funded Research Institute (PFRI) Registration

Language

Government of India
Ministry of Science and Technology
Department of Scientific and Industrial Research
Technology Bhavan, New Mehrauli Road New Delhi - 110 016
Public Funded Research Institute (PFRI)
Refer Guidelines before filling Application Form

1. Registration
Whether the application is for *

Please Select

2. Institute Details
2.1 Name of the Institution *

2.2 Address *
Address Line 1 *

Address Line 2

Address Line 3

Country *

State *

District

Please Select
Please Select
Please Select

Postal / Zip Code *

2.3 Mobile Number *

2.4 E-Mail *

2.5 Fax /Telex /Grams

3. Legal Status
https://serviceonline.gov.in/configurescheme/renderApplicationForm.do?serviceId=15990001&UUID=0866308c-8e94-4c59-bc90-0c13fee688a3&…

1/8

<!-- page 4 -->

8/29/23, 12:59 AM

ServicePlus- Public Funded Research Institute (PFRI) Registration

3.1 Legal status of the Institution *

3.2 Enclose copy of the Act , amended MOA or relevant
notification *

Please Select
Additional doc
Choose File

3.3 Upload Gazette notification/ relevant notification to establish
legal status . *

Additional doc
Choose File

3.4 Upload UGC notification

No file chosen

No file chosen

Additional doc
Choose File

No file chosen

4. Contact Details
Name & Designation of the Head (Vice Chancellor/ Director/ Dean/
Registrar) of the Institution *
4.1 Name *

4.2 Designation *

Coordinator Details *
4.3 Name *

4.4 Address Line 1 *

Address Line 2

Address Line 3

Country *

State *

District

Please Select
Please Select
Please Select

Postal / Zip Code *

4.5 Mobile Number *

4.6 E-Mail *

5. Research Area
5.1 Broad Areas of Research & major Research Programs *

https://serviceonline.gov.in/configurescheme/renderApplicationForm.do?serviceId=15990001&UUID=0866308c-8e94-4c59-bc90-0c13fee688a3&…

2/8

<!-- page 5 -->

8/29/23, 12:59 AM

ServicePlus- Public Funded Research Institute (PFRI) Registration

5.2 Enclose copy of the latest annual report *

Additional doc
Choose File No file chosen

5.2.1 Enclose copy of latest financial statement/ annual account
of organization for (R&D/ education)/ sanction letters from the
funding agency)

Additional doc
Choose File No file chosen

6. Research Advisory Committee
6.1 Composition of Research Advisory Committee *
S.No *

Name *

Designation Internal /
External *
*

OrganisationE-Mail

Mobile

*

Number

Enclose copy of the minutes of the most recent meeting *

Additional doc
Choose File

No file chosen

7. R and D Programs
7.1 Details of R&D Programmes/ Projects ( Ongoing ) *
S.No *

Title and
Year in
Scope of the which
R&D Project started *

Capital (in
Lakhs) *

Recurring Total (in
(in Lakhs) * Lakhs) *

Sponsoring
Agency *

*

Upload details of Ongoing Projects *

Additional doc
Choose File No file chosen

7.2 Details of Proposed R&D work ( for the next three years ) *
S.No *

Title and

Duration of Capital ( in

Scope of the the Project ( Lakhs ) *
Project
in months)
proposed * *

Recurring Total (in
(in Lakhs) * Lakhs) *

List of
Remarks *
specialised
equipment
required to
be
purchased
and indicate
thier cost *

https://serviceonline.gov.in/configurescheme/renderApplicationForm.do?serviceId=15990001&UUID=0866308c-8e94-4c59-bc90-0c13fee688a3&…

3/8

<!-- page 6 -->

8/29/23, 12:59 AM

ServicePlus- Public Funded Research Institute (PFRI) Registration

Upload details of Proposed R&D work (for the next 3 years) *

Additional doc
Choose File

No file chosen

8. Staff Engaged in Research
8.1 Staff Details *
No. of Scientific
Staff *

No. of Technical
staff *

No. of
Total No. *
Administrative
staff *

Enclose total list of scientific personnel / faculty ( department
wise , total no.) working in the Institution , engaged in research
activities along with their designation , qualifications ) *

Additional doc
Choose File No file chosen

9. Infrastructure
9.1 Details of Infrastructure available for research *
S.No Equipment Name Cost of
Equipment (in
*
*
Lakhs) *

9.2 Enclose list of equipment and facilities available with the
Institution for undertaking research activities *

Additional doc
Choose File No file chosen

10. Sources of Funding
Sources of funding to the Institution *

https://serviceonline.gov.in/configurescheme/renderApplicationForm.do?serviceId=15990001&UUID=0866308c-8e94-4c59-bc90-0c13fee688a3&…

4/8

<!-- page 7 -->

8/29/23, 12:59 AM

ServicePlus- Public Funded Research Institute (PFRI) Registration

Sources of Funding *
Sources of funding Name of Agency
to the Institution

Amount
sanctioned
(Financial Year 1)

Amount
sanctioned
(Financial Year 2)

i) Central
ii) State
iii) UT Gove
iv) Self-Fin
v) Any Oth

Enclose the statement of receipts & recurring expenditure of the
Institution along with sample copies of last sanction orders
issued by the concerned Government Department for release of
grants for non-plan recurring expenditure of the Institution and
a letter from the concerned central/state/UT Govt. Department
regarding the commitment to meet atleast 50% of the recurring
expenses of the Institution. *

Additional doc
Choose File

No file chosen

11. R and D Budget
Annual Budget for research for last two years ( in Rs. Lakhs ) *

11.1 Annual Budget for research for last two years ( in Rs. Lakhs )
Year *

Capital (R&D) *

Revenue (R&D) *

Total (R&D) *

Total Budget of the
Institution /
university *

11.2 State whether the Budget includes staff salaries *

Please Select

12. R and D Infrastructure
12.1 Average yearly import / domestic purchases of goods for
R&D ( in Rs. Lakhs ) *
12.2 Enclose copies of half-yearly returns of import / domestic
purchases from the date of last registration *

Additional doc
Choose File No file chosen

https://serviceonline.gov.in/configurescheme/renderApplicationForm.do?serviceId=15990001&UUID=0866308c-8e94-4c59-bc90-0c13fee688a3&…

5/8

<!-- page 8 -->

8/29/23, 12:59 AM

ServicePlus- Public Funded Research Institute (PFRI) Registration

13. Publication
13.1 Number of papers published during last two years *

13.2 Enclose list of publications of last 3 years , their authors ,
journals/journal pages and the year in which they were
published along with the copy of selected research papers with
high Imapct Factor *

Additional doc
Choose File

No file chosen

14. Patent
List of patents filed and granted during last five years *

(a) Indian *
No. of Patent Filed No. of Patent
Granted *
*

Upload Patents

Additional doc
Choose File No file chosen

(b) Foreign *
No. of Patent Filed No. of Patent
Granted *
*

Upload Patents

Additional doc
Choose File No file chosen

15. Awards / Linkage with Industry
15. (a) Awards and any other Recognitions won by the Institution
S.No Details of Award
achievements

https://serviceonline.gov.in/configurescheme/renderApplicationForm.do?serviceId=15990001&UUID=0866308c-8e94-4c59-bc90-0c13fee688a3&…

6/8

<!-- page 9 -->

8/29/23, 12:59 AM

ServicePlus- Public Funded Research Institute (PFRI) Registration

15. (b) Linkage with Industry
S.No Linkage with
Industry

Type of Linkage

16. Any Other Information
Any other information you may like to provide *

17. Declaration
Undertaking *
17. I hereby certify that the information given above is correct . I
also undertake :
(i) to utilise the customs duty exemption facility in terms of Notfn
. Nos . 51/96- Customs dt. 23.7.1996, as amended from time to
time for research purposes only.
(ii) not to avail / utilize the customs duty exemption / GST facility
in terms of Notfn. Nos. 51/96- Customs dt. 23.7.1996 , as amended
from time to time for hospitals* or patient care activities . (The
definition of hospital may be seen in the notification)
(iii) to provide separate budget for research activities, which will
be spent according to the approvals by the Research Advisory
Committee (RAC) and imports as well as domestic purchases will
be made out of budgets for research.
(iv) to submit half-yearly returns of goods imported by availing
customs duty exemption facility in terms of Notfn. Nos. 51/96Customs dt. 23.7.1996, amended from time to time, to the
Department of Scientific & Industrial Research every year ( by
December 31 and June 30 ) and to provide all such information
and documentation to DSIR as requested by the Department , as
also access of DSIR officials/ teams sent by DSIR to my
Institution , in order to have continuity of and maintain the
registration.
I Agree *
Signature *

Please upload coloured scan of above undertaking (ink -signed
by the PI and Head / Chief Executive of Organisation /
Institution) on the Letter Head of the Organisation. *

.

Choose File

No file chosen

Additional doc
Choose File No file chosen

Name *

Designation *

https://serviceonline.gov.in/configurescheme/renderApplicationForm.do?serviceId=15990001&UUID=0866308c-8e94-4c59-bc90-0c13fee688a3&…

7/8

<!-- page 10 -->

8/29/23, 12:59 AM

ServicePlus- Public Funded Research Institute (PFRI) Registration

E-Mail *

Mobile Number *

Telephone(s) *

Date & Time *

Word verification

Please enter the characters shown above

Draft

Submit

Close

Reset

https://serviceonline.gov.in/configurescheme/renderApplicationForm.do?serviceId=15990001&UUID=0866308c-8e94-4c59-bc90-0c13fee688a3&…

8/8
