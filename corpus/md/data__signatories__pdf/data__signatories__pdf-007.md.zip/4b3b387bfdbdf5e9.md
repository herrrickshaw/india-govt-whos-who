---
doc_id: "4b3b387bfdbdf5e9"
source_url: "https://mnre.gov.in/static/uploads/2025/11/61612ee42f5cb46ca9d15d34804b793e.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Notification published in the Gazette of India regarding the constitution of the Hindi Salaahkar Samiti on August 01, 2025."
date: "2025-08-01"
pages: 9
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "67793b1d6e5db4a2"
---

<!-- page 1 -->

jftLVªh la- Mh,y—¼,u½ 04@0007@2003&&25

REGISTERED No. DL—(N) 04/0007/2003—25

सी.जी.-डी.एल.-सा.-18082025-265467
xxxGIDHxxx
CG-DL-W-18082025-265467
xxxGIDExxx

lkIrkfgd@WEEKLY

çkf/kdkj ls çdkf'kr
PUBLISHED BY AUTHORITY

la- 33]

ubZ fnYyh] 'kfuokj] vxLr 16—vxLr 22] 2025 ¼Jko.k 25] 1947½

No. 33]

NEW DELHI, SATURDAY, AUGUST 16—AUGUST 22, 2025 (SRAVANA 25, 1947)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
(Separate paging is given to this Part in order that it may be filed as a separate compilation)

fo"k;&lwph
i`"B laHkkx I—[k.M&1—¼j{kk ea=ky; dks NksM+dj½ Hkkjr ljdkj ds
ea=ky;ksa vkSj mPpre U;k;ky; }kjk tkjh dh
xbZ fof/krj fu;eksa] fofu;eksa] vkns'kksa rFkk
ladYiksa ls lEcfUèr vfèlwpuk,a. .............. 373
Hkkx I—[k.M&2—¼j{kk ea=ky; dks NksM+dj½ Hkkjr ljdkj ds
ea=ky;ksa vkSj mPpre U;k;ky; }kjk tkjh dh
xbZ ljdkjh vf/kdkfj;ks a dh fu;q fDr;ks a ]
inksU ufr;ks a ] Nq fê;ks a vkfn ds lEcUè es a
vfèlwpuk,a. ................................................ 783
Hkkx I—[k.M&3—j{kk ea=ky; }kjk tkjh fd, x, ladYiksa
vkSj vlkafof/kd vkns'kksa ds lEcU/k esa
vfèlwpuk,a. ................................................
7
Hkkx I—[k.M&4—j{kk ea=ky; }kjk tkjh dh xbZ ljdkjh
vf/kdkfj;ks a dh fu;q fDr;ks a ] inks U ufr;ks a ]
Nqfê;ksa vkfn ds lEcU/k esa vfèlwpuk,a. ..... 4193
Hkkx II—[k.M&1—vf/kfu;e] v/;kns'k vkSj fofu;e. .............
¹
Hkkx II—[k.M&1d —vf/kfu;eks a ] v/;kns' kks a vkS j fofu;eks a
dk fgUnh Hkk"kk esa izkf/kd`r ikB. .................
¹
Hkkx II—[k.M&2—fo/ks;d rFkk fo/ks;dksa ij izoj lfefr;ksa
ds fcy rFkk fjiksVZ. .....................................
¹
Hkkx II—[k.M&3—mi [k.M ¼i½—Hkkjr ljdkj ds ea=ky;ksa
¼j{kk ea =ky; dks NksM+ dj½ vkSj dsUnzh;
izkf/kdj.kksa ¼la?k 'kkflr {ks=ksa ds iz'kkluksa dks
NksM+dj½ }kjk tkjh fd, x, lkekU; lkafofèd
fu;e ¼ftuesa lkekU; Lo:i ds vkns'k vkSj
mifof/k;ka vkfn Hkh 'kkfey gaS½. ..................
¹
Hkkx II—[k.M&3—mi [k.M ¼ii½—Hkkjr ljdkj ds ea=ky;ksas
¼j{kk ea =ky; dks NksM+ dj½ vkSj dsUnzh;
izkf/kdj.kksa ¼la?k 'kkflr {ks=ksa ds iz'kkluksa dks
¹vkadM+s izkIr ugha gq,A
1-191 GI/2025

(373)

i`"B laNksM + d j½ }kjk tkjh fd, x, lka fof/kd
vkns'k vkSj vf/klwpuk,a. .............................
¹
Hkkx II—[k.M&3—mi [k.M ¼iii½—Hkkjr ljdkj ds ea=ky;kssa
¼ftlesa j{kk ea=ky; Hkh 'kkfey gS½ vkSj dsUnzh;
izkf/kdj.kksa ¼la?k 'kkflr {ks=ksa ds iz'kkluksa dks
NksM+dj½ }kjk tkjh fd, x, lkekU; lkafof/kd
fu;eksa vkSj lkafof/kd vkns'kksa ¼ftuesa lkekU;
Lo:i dh mifofè;ka Hkh 'kkfey gSa½ ds fgUnh
izkf/kd`r ikB ¼,sls ikBksa dks NksM+dj tks Hkkjr
ds jkti= ds [k.M 3 ;k [k.M 4 esa izdkf'kr
gksrs gS½a . .......................................................
*
Hkkx II—[k.M&4—j{kk ea=ky; }kjk tkjh fd, x, lkafof/kd
fu;e vkSj vkns'k. .......................................
*
Hkkx III— [k.M&1 — mPp U;k;ky;ks a ] fu;a = d vkS j
egkys[kkijh{kd] la? k yksd lso k vk;ksx]
jsy foHkkx vkSj Hkkjr ljdkj ls lEc)
vkSj v/khuLFk dk;kZy;ksa }kjk tkjh dh xbZ
vfèlwpuk,a. ................................................ 2707
Hkkx III—[k.M&2—isVsaV dk;kZy; }kjk tkjh dh xbZ isVsUVksa vkSj
fMtkbuksa ls lEcfU/kr vf/klwpuk,a vkSj uksfVl
¹
Hkkx III—[k.M&3 —eq [; vk;qD rks a ds izk f/kdkj ds v/khu
vFkok }kjk tkjh dh xbZ vfèlwpuk,a. .......
¹
Hkkx III—[k.M&4—fofo/k vf/klwpuk,a ftuesa lkafof/kd fudk;ksa
}kjk tkjh dh xbZ vf/klwpuk,a] vkns'k] foKkiu
vkSj uksfVl 'kkfey gSa. .................................
1
Hkkx IV—xSj&ljdkjh O;fDr;ksa vkSj xSj&ljdkjh fudk;ksa }kjk
tkjh fd, x, foKkiu vkSj uksfVl. ............ 4059
Hkkx V—vaxzsth vkSj fgUnh nksuksa esa tUe vkSj e`R;q ds vkadM+ksa
dks n'kkZus okyk lEiwjd. .............................
¹

<!-- page 2 -->

374

THE GAZETTE OF INDIA, AUGUST 16, 2025 (SRAVANA 25, 1947)

[PART I—SEC. 1

CONTENTS
Page
No.

Page
No.
PART I—SECTION 1—Notifications relating to NonStatutory Rules, Regulations, Orders and
Resolutions issued by the Ministries of
the Government of India (other than the
Ministry of Defence) and by the Supreme
Court ..................................................... 373
P ART I—S E CT I ON 2—Notifications regarding
Appointments, Promotions, Leave etc. of
Government Officers issued by the
Ministries of the Government of India
(other than the Ministry of Defence) and
by the Supreme Court ............................. 783
P ART I—S ECTI ON 3—Notifications relating to
Resolutions and Non-Statutory Orders
7
issued by the Ministry of Defence...........
P ART I—S E CTI ON 4—Notifications regarding
Appointments, Promotions, Leave etc. of
Government Officers issued by the
Ministry of Defence ............................... 4193
P ART II—S E CT I ON 1—Acts, Ordinances and
Regulations....................................................
*
PART II—SECTION 1A—Authoritative texts in Hindi
language, of Acts, Ordinances and
Regulations ............................................
*
PART II—SECTION 2—Bills and Reports of the Select
Committee on Bills ..................................
*
P ART II—S ECTION 3—S UB -S ECTION (i)—General
Statutory Rules (including Orders, Byelaws, etc. of general character) issued by the
Ministry of the Government of India (other
than the Ministry of Defence) and by the
Central Authorities (other than the
Administration of Union Territories) ........
*
PART II—SECTION 3—SUB -SECTION (ii)—Statutory
Orders and Notifications issued by the
Ministries of the Government of India

*Folios not received.

(other than the Ministry of Defence) and by
the Central Authorities (other than the
Administration of Union Territories) ....
PART II—SECTION 3—SUB-SECTION (iii)—Authoritative
texts in Hindi (other than such texts,
published in Section 3 or Section 4 of the
Gazette of India) of General Statutory Rules
& Statutory Orders (including Bye-laws of
a general character) issued by the Ministries
of the Government of India (including the
Ministry of Defence) and by Central
Authorities (other than Administration of
Union Territories) ...................................
PART II—SECTION 4—Statutory Rules and Orders
issued by the Ministry of Defence ..........

*

*
*

PART III—SECTION 1—Notifications issued by the High
Courts, the Comptroller and Auditor General,
Union Public Service Commission, the
Indian Government Railways and by
Attached and Subordinate Offices of the
Government of India ............................... 2707
PART III—SECTION 2—Notifications and Notices issued
by the Patent Office, relating to Patents
and Designs ..........................................

*

PART III—SECTION 3—Notifications issued by or under
the authority of Chief Commissioners ......

*

PART III—SECTION 4—Miscellaneous Notifications
including Notifications, Orders,
Advertisements and Notices issued by
Statutory Bodies ....................................

1

PART IV—Advertisements and Notices issued by Private
Individuals and Private Bodies ................ 4059
PART V—Supplement showing Statistics of Births and
Deaths etc. both in English and Hindi .....

*

<!-- page 3 -->

Hkkx I—[k.M 1]

Hkkjr dk jkti=] vxLr 16] 2025 ¼Jko.k 25] 1947½

375

Hkkx I—[k.M 1
[PART I—SECTION 1]

[¼j{kk ea=ky; dks NksM+dj½ Hkkjr ljdkj ds ea=ky;ksa vkSj mPpre U;k;ky; }kjk tkjh dh
xbZ fofèrj fu;eksa] fofu;eksa] vkns'kksa rFkk ladYiksa ls lacaf/kr vf/klwpuk,a]
[Notifications relating to Non-Statutory Rules, Regulations, Orders and
Resolutions issued by the Ministries of the Government of India
(other than the Ministry of Defence) and by the Supreme Court]
——————
शिक्षा मंत्रालय
(उच्चतर शिक्षा शिभाग)
नई दिल्ली, दिनांक 30 जुलाई 2025
सं.10-9/2025-यू.3(ए):—जबदक, अमृता शिश्व शिद्यापीठम (सम शिश्वशिद्यालय), कोयंबटूर, तशमलनाडु ने यूजीसी (सम शिश्वशिद्यालय
संस्थान) शिशनयम, 2023 के अनुसार, जगतीतपुर, कनखल, हररद्वार, उत्तराखंड में एक ऑफ-कैं पस कें द्र प्रारं भ करने हेतु यूजीसी पोटटल पर एक
ऑनलाइन आिेिन प्रस्तुत दकया।
2. और जबदक, यूजीसी ने दिनांक 17.06.2025 के अपने पत्र संख्या 40-4/2025 (सीपीपी-I/डीयू) के माध्यम से सूशित दकया दक
स्थायी सशमशत द्वारा आिेिन की जााँि की गई। संस्थान द्वारा प्रस्तुत दकए गए िस्तािेज़ों के आधार पर, सशमशत ने कु छ ितों के साथ
अमृता शिश्व शिद्यापीठम (सम शिश्वशिद्यालय), कोयंबटूर, तशमलनाडु को आिय पत्र [एलओआई] जारी करने की अनुिंसा की।
3. और जबदक, यूजीसी शिशनयम, 2023 के खंड 8 (6) द्वारा प्रित्त िशिय़ों का उपयोग करते हुए, मंत्रालय ने यूजीसी की सलाह पर,
अमृता शिश्व शिद्यापीठम (सम शिश्वशिद्यालय), कोयंबटू र, तशमलनाडु को इस ितट पर आिय पत्र (एलओएल) जारी दकया दक सम शिश्वशिद्यालय
संस्थान, जगजीतपुर, कनखल, हररद्वार, उत्तराखंड में ऑफ-कैं पस िुरू करने से पहले 3 िर्ट की अिशध के भीतर छात्र की संख्या के अनुसार
आिश्यक फनीिर, पुस्तकें , कं प्यूटर उपकरण आदि की खरीि का िैध प्रमाण प्रस्तुत करे गा।
4. और आगे, जबदक, रशजस्रार, अमृता शिश्व शिद्यापीठम (सम शिश्वशिद्यालय), कोयंबटूर, तशमलनाडु ने दिनांक 04.07.2025 के पत्र
द्वारा आिय पत्र की ितों की पूर्तट के संबंध में अनुपालन ररपोटट प्रस्तुत की, शजसे सत्यापन और सलाह हेतु यूजीसी को प्रेशर्त दकया गया। यूजीसी
ने दिनांक 18.07.2025 के पत्र संख्या 40-4/2025 (सीपीपी-I/डीयू) के माध्यम से सूशित दकया दक स्थायी सशमशत द्वारा अनुपालन ररपोटट स्िीकार
कर ली गई।
5. अब, इसशलए, यूजीसी अशधशनयम, 1956 की धारा 3 के तहत प्रित्त िशिय़ों का उपयोग करते हुए, शिक्षा मंत्रालय, एितद्वारा
यूजीसी की सलाह पर, अमृता शिश्व शिद्यापीठम (सम शिश्वशिद्यालय), कोयंबटूर, तशमलनाडु को जगजीतपुर, कनखल, हररद्वार, उत्तराखंड में एक
ऑफ-कैं पस कें द्र िुरू करने का अनुमोिन प्रिान करता है।
6. इस मंत्रालय की पूिट अशधसूिनाओं तथा समय-समय पर जारी यूजीसी और अन्य सांशिशधक पररर्ि़ों के शनयम़ों/शिशनयम़ों में
उशल्लशखत अन्य सभी ितों का अमृता शिश्व शिद्यापीठम (सम शिश्वशिद्यालय), कोयम्बटूर, तशमलनाडु द्वारा पालन दकया जाना जारी रहेगा।
पूणेंिु दकिोर बनजी
संयुि सशिि
निीन और निीकरणीय ऊजाट मंत्रालय
नई दिल्ली-110003, दिनांक 1 अगस्त 2025
संकल्प
सं. 27-11011/2/2020-हहंिी—निीन और निीकरणीय ऊजाट मंत्रालय की हहंिी सलाहकार सशमशत के कायटकाल की समाशि पर,
भारत सरकार एतद्द्वारा निीन और निीकरणीय ऊजाट मंत्रालय की हहंिी सलाहकार सशमशत का शनम्नानुसार पुनगटठन करती है:1)

गठन:
इस सशमशत के शनम्नशलशखत सरकारी एिं गैर-सरकारी सिस्य ह़ोंगे:—
निीन और निीकरणीय ऊजाट मंत्री

अध्यक्ष

निीन और निीकरणीय ऊजाट राज्य मंत्री

उपाध्यक्ष

<!-- page 4 -->

376

Hkkjr dk jkti=] vxLr 16] 2025 ¼Jko.k 25] 1947½

[Hkkx I—[k.M 1

गैर-सरकारी सिस्य
क)

संसिीय कायट मंत्रालय द्वारा नाशमत संसि सिस्य:
i.

श्री बलभद्र माझी, संसि सिस्य (लोक सभा)

सिस्य

ग्राम ि डाकघर-फाटकी, शजला-नबरं गपुर, ओशडिा-764077
ii.

श्री लुम्बाराम िौधरी, संसि सिस्य (लोक सभा)

सिस्य

302, सरस्िती अपाटटमेंट, डॉ बी.डी. मागट, नई दिल्ली-110001
iii.

श्री नरहरी अमीन, संसि सिस्य (राज्य सभा)

सिस्य

एबी-89, िाहजहां रोड, नई दिल्ली-110011
iv.

श्रीमती ममता मोहंता, संसि सिस्य (राज्य सभा)

सिस्य

डाकखाना-नंगलबेंटा पोखररया, शजला-मयुरभंज, ओशडिा-757033
ख)

संसिीय राजभार्ा सशमशत द्वारा नाशमत संसि सिस्य:
v.

डॉ. अशनल सुखिेिराि ब़ोंडे, संसि सिस्य (राज्य सभा)

सिस्य

फ्लैट नं० सी-304, स्िणट जयंती सिन, डॉ. बी. डी. मागट,
नई दिल्ली-110001
vi.

डॉ. सुमेर हसंह सोलंकी, संसि सिस्य (राज्य सभा)

सिस्य

सी-603, स्िणट जयंती सिन, डॉ बी.डी. मागट, नई दिल्ली-110001
ग)

के न्द्रीय सशििालय हहंिी पररर्ि के प्रशतशनशध:
vii.

श्रीमती ममता गांधी,

सिस्य

ओ-39, लाजपत नगर-2, अपर ग्राउं ड फ्लोर, नई दिल्ली-110024
घ)

शिश्ि हहंिी पररर्ि के प्रशतशनशध:
viii.

श्री राहुल िेि,

सिस्य

एस-32, प्रथम तल, व्यािसाशयक पररसर, ग्रीन पाकट , नई दिल्ली-110016
ड़)

निीन और निीकरणीय ऊजाट मंत्रालय द्वारा नाशमत सिस्य:
ix.

डॉ. िाई. एस. रायबागी,

सिस्य

738/3, िेर्ाशगरी, िाई. एस. कॉलोनी, शिद्याशगरी, धारिाड-580004
x.

श्री उमेि पुरोशहत

सिस्य

द्वारा टी. आर. पारटल, 111, शसल्िर टाउन, गोकु ल रोड, हुबली, कनाटटक-580030
xi.

डॉ. गायत्री खंडते,

सिस्य

द्वारा शिजय डी. क्षीरसागर, प्लॉट नं० 43, डॉ. राधाकृ ष्णन नगर,
गोकु ल रोड, हुबली, कनाटटक-580030
xii.

डॉ. सुधीर पाण्डेय,

सिस्य

55-शसद्धाथट अपाटटमेंट, इंिर एंक्लेि, पशिम शिहार, नई दिल्ली-110087
ि)

राजभार्ा शिभाग, गृह मंत्रालय द्वारा नाशमत सिस्य :
xiii.

डॉ पिलूर अिोकन,

सिस्य

जेए शनिास, पिलूर, शतरूिनंतपुरम, के रल-695027
xiv.

श्री िेतन मोहन जोिी,
152 के शसया, ओमेक्स फे ज 3, न्यू िंडीगढ़, शजला एस.ए.एस. नगर, पंजाब-140901

सिस्य

<!-- page 5 -->

Hkkx I—[k.M 1]

Hkkjr dk jkti=] vxLr 16] 2025 ¼Jko.k 25] 1947½
xv.

श्री आयुर् िमाट,

377
सिस्य

एफ-158, सुभार् नगर, ईस्ट एक्सटेंिन, भीलिाड़ा (राजस्थान)-311001
अन्य सरकारी सिस्य
xvi.

सशिि, निीन और निीकरणीय ऊजाट मंत्रालय

सिस्य

xvii.

सशिि, राजभार्ा शिभाग

सिस्य

xviii.

अपर सशिि, निीन और निीकरणीय ऊजाट मंत्रालय

सिस्य

xix.

संयुक्त सशिि, राजभार्ा शिभाग

सिस्य

xx.

महाशनिेिक, राष्रीय सौर ऊजाट संस्थान, गुरुग्राम, हररयाणा

सिस्य

xxi.

महाशनिेिक, राष्ट्रीय पिन ऊजाट संस्थान, िेन्नई, तशमलनाडु

सिस्य

xxii.

महाशनिेिक, सरिार स्िणट हसंह राष्रीय जैि ऊजाट संस्थान, कपूरथला, पंजाब

सिस्य

xxiii.

अध्यक्ष एिं प्रबंध शनिेिक, भारतीय अक्षय ऊजाट शिकास संस्था शलशमटेड,

सिस्य

नई दिल्ली
xxiv.

अध्यक्ष एिं प्रबंध शनिेिक, सोलर एनजी कॉपोरे िन ऑफ इंशडया शलशमटेड,

सिस्य

नई दिल्ली
xxv.

संयुि सशिि/िैज्ञाशनक ’जी’/उप महाशनिेिक, निीन और निीकरणीय

सिस्य सशिि

ऊजाट मंत्रालय नई दिल्ली
2)

सशमशत का कायट:
यह सशमशत सरकारी प्रयोजऩों के शलए शहन्िी के प्रगामी प्रयोग और सम्बद्ध मामल़ों पर निीन और निीकरणीय ऊजाट मंत्रालय
को सलाह िेगी।

3)

सशमशत का कायटकाल:
सशमशत का कायटकाल उसके पुनगटठन की शतशथ से तीन िर्ट के शलए होगा, परं तु;
(क)

सशमशत में नाशमत संसि सिस्य उनकी संसि की सिस्यता समाप्त होने पर इस सशमशत के सिस्य नहीं रहेंगे।

(ख)

सशमशत के पिेन सिस्य उस समय तक ही सशमशत के सिस्य रहेंगे जब तक दक िे उस पि पर रहेंगे शजसके कारण िे
सशमशत के सिस्य बने हैं; और

(ग)

सशमशत के कायटकाल के मध्य उत्पन्न हुई ररशिय़ों के शलए शनयुि दकए गए सिस्य का कायटकाल, तीन िर्ट के कायटकाल
की के िल िेर् अिशध तक ही रहेगा।

4)

सामान्य:
सशमशत का मुख्यालय नई दिल्ली में होगा और सशमशत की बैठकें के िल दिल्ली में ही आयोशजत की जाएंगी ।

5)

यात्रा तथा अन्य भत्ते:
राजभार्ा शिभाग, गृह मंत्रालय के दिनांक 03 फरिरी, 2006 के कायाटलय ज्ञापन सं.11/20034/04/2005-रा.भा. (नीशत-2)
के अंतगटत यह उल्लेख दकया गया है दक िूंदक कें द्रीय मंत्रालय़ों/शिभाग़ों द्वारा गरठत हहंिी सलाहकार सशमशतेय़ों में नाशमत 15
गैर-सरकारी सिस्य़ों में 06 संसि सिस्य होते हैं, अत: यात्रा/िैशनक भत्ता प्रािधान को अशधक स्पष्ट करते हुए शनम्न प्रािधान
दकया जाता है :—
(क)

सशमशत में नाशमत सांसि़ों को ''संसि सिस्य (िेतन, भत्ता एिं पेंिन) अशधशनयम, 1954'' के प्रािधाऩों एिं समयसमय पर जारी दकए गए संिोधऩों तथा उनके अधीन बनाए गए शनयम़ों के अनुसार यात्रा भत्ता तथा िैशनक भत्ता दिया
जाएगा।

<!-- page 6 -->

378

Hkkjr dk jkti=] vxLr 16] 2025 ¼Jko.k 25] 1947½
(ख)

[Hkkx I—[k.M 1

सशमशत के अन्य गैर-सरकारी सिस्य़ों को राजभार्ा शिभाग के दिनांक 22 जनिरी, 1987 के कायाटलय ज्ञापन
सं.11/22034/04/86-रा.भा. (क-2) में शनशहत दििाशनिेि़ों के अनुरूप और भारत सरकार द्वारा समय-समय पर
यथासंिोशधत शनधाटररत िऱों एिं शनयम़ों के अनुसार यात्रा भत्ता तथा िैशनक भत्ता िेय होगा।
आिेि

आिेि दिया जाता है दक संकल्प की एक प्रशत निीन और निीकरणीय ऊजाट मंत्रालय की शहन्िी सलाहकार सशमशत के सभी सिस्य़ों,
सभी राज्य सरकाऱों और संघ राज्य क्षेत्ऱों के प्रिासऩों, राष्रपशत सशििालय, उप-राष्रपशत सशििालय, प्रधानमंत्री कायाटलय, मंशत्रमंडल
सशििालय, संसिीय कायट मंत्रालय, लोक सभा सशििालय, राज्य सभा सशििालय, संसिीय राजभार्ा सशमशत, नीशत आयोग, भारत के शनयंत्रक
एिं महालेखा परीक्षक, महालेखाकार, भारत शनिाटिन आयोग, संघ लोक सेिा आयोग और भारत सरकार के सभी मंत्रालय़ों और शिभाग़ों को
भेजी जाए।
यह भी आिेि दिया जाता है दक इस संकल्प को सामान्य जानकारी के शलए भारत के राजपत्र में प्रकाशित दकया जाए।
डॉ. पंकज सक्सेना
िैज्ञाशनक ‘जी’
——————

<!-- page 7 -->

PART I—Sec.1]

THE GAZETTE OF INDIA, AUGUST 16, 2025 (SRAVANA 25, 1947)

379

MINISTRY OF EDUCATION
(DEPARTMENT OF HIGHER EDUCATION)
New Delhi, the 30th July 2025
No.10-9/2025-U.3(A)—Whereas, Amrita Vishwa Vidyapeetham (Deemed to be University), Coimbatore, Tamil
Nadu submitted an online application on the UGC Portal to start an off-campus centre at Jagjeetpur, Kankhal, Haridwar,
Uttarakhand as per the UGC (Institutions deemed to be Universities) Regulations, 2023.
2. And whereas, UGC, vide its letter No.40-4/2025 (CPP-l/DU) dated 17.06.2025, informed that the application was
examined through a Standing Committee. The Committee, after presentation of the Institution and based on the documents
submitted, recommended for issuance of Letter of Intent (LoI) to Amrita Vishwa Vidyapeetham (Deemed to be University),
Coimbatore, Tamil Nadu with certain conditions.
3. And whereas, in exercise of the powers conferred by Clause 8 (6) of UGC Regulations, 2023, the Ministry, on the
advice of UGC, issued Letter of Intent (Lol) to Amrita Vishwa Vidyapeetham (Deemed to be University), Coimbatore, Tamil
Nadu with condition that the Institution deemed to be University shall submit valid proof of purchase of required furniture,
books, computers equipment etc. as per the student intake within a period of 3 years before starting an off-campus at Jagjeetpur,
Kankhal, Haridwar, Uttarakhand.
4. And further whereas, the Registrar, Amrita Vishwa Vidyapeetham (Deemed to be University), Coimbatore, Tamil
Nadu, vide letter dated 04.07.2025, submitted compliance report in respect of fulfilment of the conditions of the LoI which was
then sent to UGC for verification and advice. UGC, vide letter No. 40-4/2025 (CPP-l/DU) dated 18.07.2025, conveyed that the
compliance report was accepted by the Standing Committee.
5. Now, therefore, in exercise of the powers conferred under Section 3 of the UGC Act, 1956, the Ministry of
Education, on the advice of UGC, hereby accords approval to Amrita Vishwa Vidyapeetham (Deemed to be University),
Coimbatore, Tamil Nadu to start an off -campus centre at Jagjeetpur, Kankhal, Haridwar, Uttarakhand.
6. All other conditions mentioned in the earlier Notification(s) of this Ministry as well as the Rules / Regulations of
UGC and other Statutory Councils, issued from time to time, shall continue to be adhered by Amrita Vishwa Vidyapeetham
(Deemed to be University), Coimbatore, Tamil Nadu.
PURNENDU KISHORE BANERJEE
Joint Secretary
MINISTRY OF NEW AND RENEWABLE ENERGY
New Delhi – 110003, the 1st August 2025
RESOLUTION
No. 27-11011/2/2020-Hindi—On conclusion of tenure of the Hindi Advisory Committee of the Ministry of New and
Renewable Energy, the Govt. of India hereby reconstitutes the Hindi Advisory Committee of the Ministry of New and
Renewable Energy as under:1)

Composition:
The following will be the Official and Non-official Members of the Samiti:
Minister for New and Renewable Energy

Chairman

Minister of State for New and Renewable Energy

Vice-Chairman

Non-Official Members
a)

Members of Parliament nominated by the Ministry of Parliamentary Affairs:
i.

Shri Balabhadra Majhi, Member of Parliament (Lok Sabha)
Village and PO: Phataki, District-Nabarangpur, Odisha, 764077

Member

ii.

Shri Lumba Ram Choudhary, Member of Parliament (Lok Sabha)
302, Saraswati Apartment, Dr.B. D. Marg, New Delhi-110001

Member

iii.

Shri Narhari Amin, Member of Parliament (Rajya Sabha)
AB-89, Shahjahan Road, New Delhi-110011

Member

iv.

Smt. Mamata Mohanta, Member of Parliament (Rajya Sabha)
PO: Nangalbenta Pokharia, Dist.: Mayurbhanj, Odisha–757033

Member

<!-- page 8 -->

380

THE GAZETTE OF INDIA, AUGUST 16, 2025 (SRAVANA 25, 1947)
b)

c)

Members of Parliament nominated by Committee of Parliament on Official Language:
v.

Dr. Anil Sukhdeorao Bonde, Member of Parliament (Rajya Sabha)
Flat No. C-304, Swarn Jayanti Sadan, Dr. B.D. Marg,
New Delhi-110001

Member

vi.

Dr. Sumer Singh Solanki, Member of Parliament (Rajya Sabha)
Flat No. C-603, Swarn Jayanti Sadan, Dr. B. D. Marg,
New Delhi-110001

Member

Representative of Kendriya Sachivalaya Hindi Parishad:
vii.

d)

Smt. Mamta Gandhi,
O-39, Lajpat Nagar-2, Upper Ground Floor, New Delhi-110024

Member

Representative of Vishwa Hindi Parishad:
viii.

e)

[PART I—Sec.1

Shri Rahul Dev
S-32, First Floor, Commercial Complex, Green Park, New Delhi-110016

Member

Members nominated by the Ministry of New and Renewable Energy:
ix.

Dr. Y. S. Raibagi

Member

738/3, Sheshagiri, Y. S. Colony, Vidyagiri, Dharwad-580004
x.

Sh. Umesh Purohit,

Member

C/o T. R. Patil, 111, Silver Town, Dr. Radhakrishnan Nagar, Gokul Road,
Hubli, Karnataka-580030.

f)

xi.

Dr. Gayatri Khandate,
C/o Vijay D Kshirsagar, Plot No. 43, Gokul Road,
Hubli, Karnataka-580030

Member

xii.

Dr. Sudhir Pandey,
55- Siddharth Apartment, Inder Enclave, Paschim Vihar,
New Delhi-110087

Member

Members nominated by Deptt. of Official Language,
Ministry of Home Affairs:
xiii.

Dr. Pachalloor Asokan
JA Nivas, Pachalloor, Thiruvananthapuram, Kerala-695027

Member

xiv.

Shri Chetan Mohan Joshi
152, Cassia, Omaxe Phase 3,
New Chandigarh, District S.A.S. Nagar, Punjab-140901

Member

xv.

Shri. Ayush Sharma
F-158. Subhash Nagar, East Extension, Bhilwara, Rajasthan-311001

Member

Other Official Members
xvi.

Secretary, Ministry of New and Renewable Energy

Member

xvii.

Secretary, Department of Official Language

Member

xviii. Addl. Secretary, Ministry of New and Renewable Energy

Member

xix.

Joint Secretary, Department of Official Language

Member

xx.

Director General, National Institute of Solar Energy, Gurugram, Haryana

Member

xxi.

Director General, National Institute of Wind Energy, Chennai, Tamil Nadu

Member

xxii.

Director General, Sardar Swarn Singh National Institute of Bio-Energy,
Kapurthala, Punjab

Member

<!-- page 9 -->

PART I—Sec.1]

2)

THE GAZETTE OF INDIA, AUGUST 16, 2025 (SRAVANA 25, 1947)

381

xxiii. Chairman and Managing Director, Indian Renewable Energy Development
Agency Ltd. New Delhi

Member

xxiv. Chairman and Managing Director, Solar Energy Corporation of India Ltd.,
New Delhi

Member

xxv.

Member Secretary

Joint Secretary/ Scientist ‘G’/ Dy. Director General,
Ministry of New and Renewable Energy

Functions of the Samiti:
The Samiti shall advise the Ministry of New and Renewable Energy on matters relating to the progressive use
of Hindi for official purposes.

3)

Tenure of the Samiti:
The term of the Samiti will be three years from the date of its formation, provided that:

4)

(a)

A Member of Parliament nominated to the Samiti shall cease to be a member of the Samiti as soon as
he/she ceases to be a Member of Parliament;

(b)

Ex-officio members of the Samiti shall continue as members so long as they hold the office by virtue
of which they are members of the Samiti; and

(c)

Members appointed against mid-term vacancies shall hold office only for the residual period of the
three year's tenure.

General
The Headquarters of the Samiti shall be at New Delhi and meetings of Samiti will be held in Delhi only.

5)

T.A. and Other Allowances:
The Department of Official Language, Ministry of Home Affairs, Government of India, vide their Office
Memorandum no.II/20034/04/2005-OL (Policy-2) dated 3rd February, 2006 has stated that as the 15 non-official
members include 6 Members of Parliament, nominated in the Hindi Salahkar Samitis constituted by Central
Ministries/Departments, so the following provision has been made to clarity about travelling/daily allowances:(a)

The Members of Parliament nominated in the Samiti will be paid Travelling Allowance and Daily
Allowance as per the provisions of the “Member of Parliament (Salary, Allowance and Pension) Act,
1954”, as amended from time to time and rules made accordingly.

(b)

Travelling Allowance and Daily Allowance to other non-official members of the Samiti will be paid as
per guidelines contained in the Department of Official Language O.M. No. /22034/04/86-OL (A-2)
dated 22nd January, 1987 and in accordance with the prescribed rates and rules as amended from time
to time by the Government of India.
ORDER

It is ordered that a copy of the Resolution be communicated to all the members of the Hindi Salahkar Samiti of
the Ministry of New and Renewable Energy, all State Governments and U.T. Administrations, President’s Secretariat,
Vice-President’s Secretariat, Prime Minister's Office, Cabinet Secretariat., Ministry of Parliamentary Affairs, Lok Sabha
Secretariat, Rajya Sabha Secretariat, Committee of Parliament on Official Language, NITI Aayog, Comptroller and Auditor
General of India, Accountant General, Election Commission of India, Union Public Service Commission and all Ministries and
Departments of the Govt. of India.
It is also ordered that a copy of this Resolution be published in the Gazette of India for general information.
Dr. PANKAJ SAXENA
Scientist-‘G’

egkizca/kd] Hkkjr ljdkj eqn.z kky;] feUVks jksM] ubZ fnYyh&110002 }kjk viyksM ,oa izdk'ku fu;a=d] fnYyh&110054 }kjk bZ&izdkf'kr+
UPLOADED BY THE GENERAL MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI-110002
AND E-PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI-110054
KSHITIZ
Digitally signed
by KSHITIZ
MOHAN

Date: 2025.08.18
MOHAN 16:32:19
+05'30'
