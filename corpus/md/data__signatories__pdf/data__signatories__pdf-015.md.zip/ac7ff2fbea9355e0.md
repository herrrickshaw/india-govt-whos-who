---
doc_id: "ac7ff2fbea9355e0"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/b60c1106dbdeeaafa46cd6b3d9657952.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Appointment of Shri G. Suresh Reddy, ITS, Staff No. 21097, as Joint Advisor in TRAI RO Hyderabad on deputation basis - reg."
date: "2025-07-07"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bfa2b2a78379087d"
---

<!-- page 1 -->

391-04/2025-STG-III-Part(2)

I/3293667/2025

No. 391-04/2025-STG-III (Pt.II)
Government of India
Ministry of Communications
Department of Telecommunications
Room No. 419, Sanchar Bhawan
20 Ashoka Road, New Delhi 110001
Dated: 07.07.2025
Office Memorandum
Subject: Appointment of Shri G. Suresh Reddy, ITS (Staﬀ No. 21097) as Joint
Advisor in TRAI RO Hyderabad on deputation basis - reg.
The undersigned is directed to refer to TRAI letters No. 1-03/2025-A&P
dated 19.06.2025 on the subject mentioned above and to say that Shri G. Suresh
Reddy, ITS (Staﬀ NO. 21097) Director in Assam LSA, has been selected as Joint
Advisor in TRAI RO Hyderabad initially for a period upto 31.03.2028 or until further
orders whichever is earlier.
2.
The terms and conditions as laid down in the DoP&T OM No. 2/6/2016- Estt.
(Pay-II) dated 17.02.2016 and OM No. 14017/30/2006-Estt. (RR) dated 29.11.2006
as amended from time to time are applicable in the case of deputation of aforesaid
oﬃcer to the post of Joint Advisor in TRAI RO Hyderabad. Anything not covered in
these OMs will be decided as per the policy of borrowing organization.
3.
Therefore, aforesaid oﬃcer may be relieved immediately with instructions
to take up his new assignment in TRAI RO Hyderabad.
4.

This issues with the approval of the Competent Authority.
(Sunil Kumar)
Under Secretary to the Govt. of India
Tele No. 23036226

To,
The DGT,
New Delhi.
Copy to:
1. PS to Hon’ble MoC/ PS to Hon’ble MoS(C).
2. PS to Secretary (T)/Member(S).
3. The Addl DGT, Assam LSA, Guwahati.
4. Shri Durgendra Singh Jadaun, Sr. R.O., TRAI, New Delhi.
5. Officer concerned.
6. AO, STG-I/ADG(APAR)/SO (Pay Bill).
7. Order Bundle/ Spare Copy.
