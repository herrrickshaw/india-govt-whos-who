---
doc_id: "acb6d7ae97a9b44a"
source_url: "https://www.dot.gov.in/static/uploads/2026/09/3fe18e259149199cd346f0074a7213f0.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Reference back of DOT to TRAI recommendations dated 16-04-2012 on Guidelines for Unified Licence,class licence and migration of existing licences"
date: "2012-05-02"
pages: 62
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "07ea29b70c7da70c"
---

<!-- page 1 -->

No. 20-281/2010-AS-I (Vol.-V)
Govt. of India
Ministry of Communications & IT
Department of Telecom
(Access Services Wing)
Dated: 02 .05.2012
To
The Secretary,
TRAI,
New Delhi.
Sub:

TRAI recommendations dated 16.04.2012 on Guidelines for Unified licence/class
licence and migration of existing licences.
Reference is invited to TRAI letter No. 903-2/2012-MS dated 16.4.2012 vide which

recommendations on the above subject were forwarded to Secretary, DoT.

Above said recommendations of TRAI have been examined and it has been felt, prima-·
facie, that on certain issues clarifications/reconsidered recommendations are required.

In

accordance with the provisions of Section 11 on the TRAI Act, 1997, recommendations of TRAI
are referred back, as per annexurc-1 containing DoT's comments against such recommendations
which require clarification/reconsidered recommendations.
Encls.: As above.

<.jfJvv-_JJCf

(A.K.Mittal~

Sr.DDG(AS)

iJ/ c

<!-- page 2 -->

DoT's Comments
on
The TRAI Recommendations dated 16.04.2012
Q!!

"Guidelines for Unified Licence/Class Licence

and
Migration of Existing Licences"

The para-wise Comments ofDoT are as below:
TRAl's Recommendations
I.

I A.

I

DoT's comments

Guidelines for Unified Licence (Appendix to the recommendation)
Unified Licence

1.

1.1

I

1.2
1.3

1.4

1.5

I Though the services under National Unified

' licence will cover the total country, it is noted
that TRAI has not specified the whether the
service area of National Unified licence shall
There shall be three levels of Unified Licence: National level, Service area level and
be one national service area or a summation
District level. The Applicant Company can apply either for National level Unified
of 22 service areas to keep consistency with
Licence or Service area level Unified Licence or District level Unified Licence. Only
service area UL. Accordingly whether the
Service level Unified Licence will be given for Metro areas of Delhi, Mumbai and
networks have to be single nationwide
Kolkata.
networks in a single SA or 22 networks under
For the purpose of the Unified Licence, 1he service areas shaii be as listed in Annexure ­
one licence.
l.
A company can apply for Unified Licence in more than one service area or district. For provision of access services it is ,
However, if a company desires to apply for Unified Licence in more than four districts recommended that administration of national '
in a service area, it has to apply for Service area level Unified Licence.
unified licence would be service area wise for
I
Subject to fulfilment of relevant eligibility conditions. Licence shall be issued on non ' all aspects including LF/SUC /PBG/FBG
exclusive basis, without any restriction on the number oflicences.
/roll-out/numbering plan etc.
Separate
In addition to a Unified Licence, TR.Al reserves the right to awa~d/allocate Licences to accounts will have to be maintained service

Framework

l.c Page I of61
~

<!-- page 3 -->

TRAI's Recommendations

1.6

DoT's comments

offer specific services like Mobile Number Portability (MNP) services and such other area wise for assessment and deduction etc.
TRAI has dealt with d"strict level licence
services as may be decided by TRAI from time to time.
t
fi _
d t.
It
At the time of applying for Unified Licence. no access spectrum will be given. A holder ,,
.
.
. .
.
.
b . 1r0 m para 2 . 1 o 2 . 15 o re1,ommen a ions.
of Umfied Licence, other than D1stnct level Umfied Licence. may separately o tam , is noted that the objective of the current
I exercise is unification of licences and district
spectrum as per the prevailing policy.
level licence which will be without spectrum
as recommended, hence DL would be
providing only ISP and fixed services and
may not serve the purpose of a unified
licence. Secondly, holder of such a licence is
allowed to work as MVNO as recommended
by TRAI in para 2.15. TRAI has already
made recommendations regarding MVNO as
a part of it's recommendations on
Infrastructure Policy which are under
consideration of the Government. Further in
the draft telecom policy 2012, there is a
proposal to delink licensing of network from
delivery of services. Services to be covered
under DL need to be indicated so that this
concept fit in to the proposed NSO/SDO
scheme seamlessly.
Moreover, TRAI in it's recommendation in
2010 had recommended to reintroduce
'C'
ISPs
and
later,
on
. category
reconsideration TRAI had recommended to
give District level UL in place of!SP licence.

!

1

: Govt. did not support the idea of District
I Licence. However, re-introduction of ISP cat
Page 2 of 61

<!-- page 4 -->

DoT's comments

TRAl's Recommendations

i 'C' licence was agreed by DoT in-principle.

I
j In view of the above, district level licence I
I

I may be considered after the policy on MVNO !

·. is finalised and after a view is taken about the I
I framework of network level licence and
I

I service level licence based on the NTP which )
f

I

may be finalised soon by the Government.

However, in order to facilitate the objective of j
rural broadband penetration, whether the I
scope of licences at district level be restricted
. to provide internet services by providing last
connectivity without assignment of ,
I mile
licenced
Access
spectrum.
However, I
backhaul spectrum if required shall be /
facilitated subject to availability. This licence !
may be renamed as per the character of I
services to be provided like Unified Licence- I
Last Mile Internet.
.

1

I

TRAI may provide guidelines/term
conditions for such licence.

&

Regarding para 1.2, it is seen from Annexure­
I that categorisation of service areas as A,B
and C has been abolished. However, it
appears that A,B, C categorisation needs to be
continued till atleast the Uniform Licence fee
regime is fully implemented which is
envisaged in two stages.
Second! , for service areas where ad· oinin
Page 3 of 61

I
!

<!-- page 5 -->

DoT's commenlts

TRAI's Recommendations

I geographies of adjoining states are already
. included in the UASL licence, for such
] geographies the USAL licence describes the
I limit as the local telephone exchange system
of such geographies. This has now been
recommended to be changed to municipal
, areas. It is noted that some of these areas are
administered by an authority and there is also
Ii a possiHility that local exchange systems may
i cover mbre area than the municipal limit.
·1

It
is
also
seen
that
from
Punjab service area, Panchkula tov.in has been
removed and made part of Haryana LSA.
Though Punchkula is a part of Haryana State,
it is a part of Punjab service area. This has
also been settled through judicial process.
Further, this would have impact on customer
roaming & tariff being territorial issues
among operators.

Three levels of licences shall also pose
challenges
for
implementing
M&A
guidelines. These issues are dealt in para 13. I .

I Further, it is noted that Digital Addressable
System (DAS) is being implemented by l&B
ministry in phased manner from July 2012.
I DAS may play an important role in broadband
.

1

~

Page4of61

I

<!-- page 6 -->

TRAI's Recommendations

,

DoT's comments

I penetration by using both way Set Top Boxes.
In what way, TRAis regulations/directions on
use of Set Top Boxes under DAS cable TV
system may complement the Unified Licence.
If required, suitable provisions may be
reflected in UL guidelines also.
As far as, inclusion of IP-I in UL is
concerned, it is to mention that while
announcing decision on UL framework on 15­
2-2012 (May 2010 recommendation of
TRAI), government had deferred inclusion of
IP-I in licence framework. It was noted that
the FD! limit of 100% currently available to
IP-I will come down to 74% impacting
adversely the investment in infrastructure. IP­
, I currently do not provide active
infrastructure. TRAI is requested to give their
reconsidered recommendations in this regard. ,
i

[ In Para 1.5, "TRAI" may be replaced by
j ''Licensor".
.
I

·1·

2.

Eligibility Conditions

2.1

The applicant must be an Indian company, registered under the Indian

TRAI may also specify the category of I
licence for MNPO.

}(' Page 5 of61

<!-- page 7 -->

DoT's comments

TRAl's Recommendations

Companies Act 1956.
2.2

Industrial Policy and Promotion and"
may be replaced by "relevant provisions
of FD! policy of the Government and·'.

The Applicant Company shall have to be in compliance with the relevant
provisions of FD! policy of the Government and such modifications to
the policy as may be issued from time to time. The relevant provisions
are placed at Annexure-Il.

2.3

FD! shall be subject to laws of India and not the laws of the foreigr1

1

country/ countries.
2.4

The
words
after
India
...... countries" may be deleted.

j.e.."And I
I

I
The Applicant Company shall have a minimum networth as well as paid : The current networth requirement for UASL I
up equity capital of Rs. 25 crore for National ievel Unified Licence, Rs 2.5 [ licence is Rs 100/50/30 Crs for category
A/B/C service areas. Therefore for a unified
crore for each Service area level Unified Licence and Rs. 25 lakh for each licence with all
service:s, the proposed
networth
requirement
is substantially lower. It
District level Unified Licence on the date of application and shali submit
, is however noted that spectrum has been
a certificate to this effect (provided by the Company Secretary/ Statutory delinked.
Auditors of the applicant company) along with the application. The
I

networth of promoters shall not be counted for determining the ::ietworth [ It is further noted that networth requirement
, for existing ISP licences is NIL and Rs 2.5Crs
of the company In case of acquiring Unified Licence in any other licence
for NLD/ILD licences. This will create issues
area, the Licensee shall maintain additional net-worth and paid up
[ in migration of existing licensees to UL. The
1 entry
barrier for new applicants will also :
J

JiZ_

Page 6 of 61

<!-- page 8 -->

DoT's comments

TRAl's Recommendations

equity as prescribed for that service area/ district also. The net worth
requirement for Unified Licence is summarised i:Jelmv ­

. become high in terms of networth and entry I
I fee.
•
I

Conversely, a lower networth requirement, as
recommended, for companies who want to
operate Access and other services under the
scope of UL, may not be desirable as licensee
should have a good financial strength to
sustain the requirements of operating such
business.

Table - Minimum Net-worth requirement for various Unified
Licences
·Type of
Licence

·I

~N~~nnnl
1

I ~~([fied

Net-worth and Paid up , Total Minimum Net­
equity requirement
worth and Paid up equity
required for more than
one Licence areas
I Rs 25 Crore
1

I

1 Licence
1

I Services
Rs 2.5 crore for each (Rs. in crore) 2.5 x Number
I area level service area.
of service areas for which

IUnceifiniecde

either LOI/ Licence have
been issued and applied
for
in
the
name
of
' applicant.
strict
Rs. 25 lakh for each I (Rs. in lakh) 25 x Number
level
district.
! of districts for which either
I Unified
j LOI/
Licence have been
I Licence
. issued and applied for m
.'--·~~~~~~~~~~~~~~--~~~'~t~h~e~n==a~m~e"--'o~f_a~p"-J.:.p~li~c~a=n~t~.~~I

I

1

The objective of growth in the sector requires

I that the entry barriers in respect of the

services requiring comparatively lesser
I investment than that for access services
should remain low.
I
I

\ It may be considered whether, this can be i

I resolved by having a framework of UL under
which there can be different eligibility for

I different bouquet of services with entry fee
1

·1

I

and networth requirement commensurate with \
the respective bouquet of services.
;

I In order to implement such regime, whether \
[ National/Service Area/District level licence

I are necessary or this could be achieved under

1

1.

I a single national licence where services and \
I geographical area are allowed to be added in I

¥ Page 7 of61

<!-- page 9 -->

TRAl's Recommendations

I

DoT's comments

] defined steps on "pay as you eat" basis.
1
[

However, unit for regulation of competition
needs to be indicated.

IRA! may clarify the above issues.

I

After the
words
statutory
auditors.
"countersigned by duly authorised director" [
mav be added.
1

Pr~visions of para 2.4 of Class License may [
I

also be included here.

'

3.
3.1

As national level licence is being introduced,
separate application forms for different types
Application Procedure
The Applicant Company shall pay a non refundabie processing fee of Rs. ' of unified licences will be required to be
I prescribed.
100,000 (Rs. One Lakh) for National level Unified Licence, Rs. 50,000
Since there is no Cap on the number of
licences which can be issued and for certain
services, backhaul spectrum may be required.
there will be a need to define a method of
receiving and processing applications so that
the principle of Natural Justice is followed.

(Rs. Fifty Thousand) for Service area level Unified Licence and Rs 15,000
(Rs. Fifteen Thousand) for District level Unified Licence.

3.2

The Applicant Company shall submit the application in the prescribed
Application form for each licence area separately.

It has been recommended that incomplete

3.3

Incomplete application is liable to be rejected and the processing fee will . applications is liable to be rejected . In normal
some mmor discrepancies may be 1
1 course
not be refunded.
there in the applications filed. There may be a ]
need to give some time to applicant to correct )
the
mistakes etc.
1
I

I

I

~

Page8 of61

<!-- page 10 -->

TRAl's Recommendations

3.4

DoT's comments

The complete application shall ordinarily be decided, within 60 days of
the submission of the application and the applicant company shall be
informed accordingly.

3.5

TRAI reserves the right to accept or reject any application without

ln para
. 3.5 the word TRAI may be replaced '
by Licensor.
:
I

assigning any reasons.

3.6

In case the applicant is found to be eligible for grant of Unified Licence,

Detailed application procedure may
worked out in consultation with TRAI.

be .
!

a Letter of Intent (LOI) will be issued. The applicant shall be required to
deposit Entry Fee and submit Bank Guarantee / other documents and
sign the licence agreement within a period as mentioned in the
letter(LOI) from the date of issue of the letter (LOI) failing which the offer
of grant of licence shall stand withdrawn at the expiry of permitted
period.
3.7

4.

Entry Fee

4.1

One time non refundable Entry Fee for Unified Licence shall be:

i The amount recommended for entry fee for ,

c/(? Page 9 of 61

<!-- page 11 -->

DoT's comments

TRAl's Recommendations

different types of unified licences herein are
I different than the earlier recommendation of
b. Rs. 1 (One) crore for each Service area level Unified Licence except
I TRAI which prescribed the foe as Rs 20 Crs
for Jammu & Kashmir and North East Service areas where Entry
for all India licence. Rs 2 Crs for Metros and
fee will be Rs. 50 (Fifty) lakh each.
[ category A Service Areas & Rs l Cr for
category B and Rs 0.5 Cr for category C
c.
Rs. 10 (Ten) lakh for each District level Unif;ed Licence.
areas. This recommendation was accepted in­
principle by the Government subject to final
While granting a National level or Service area level Unified Licence,
decision on TRAI recommendation on UL.
Entry fee already paid for the service area level licences or district level
licences will be adjusted on pro rata basis for the balance validity period It has been noted from the stakeholders
of such Licences at hand against the Entry Fee for the National level or comments quoted in para 2.23 of the
Service area level Unified Licence. However, where the sum of Entry Fee recommendations that some of them wanted
already paid exceeds the Entry Fee to be paid, there will be no refund of entry fee to be paid on "pay as you eat" basis.
In this regard the comments given above
the Entry Fee.
regarding bouquet of service under different
categories of UL may also be seen.

a.

Rs. 15 (Fifteen) crore for National level Unified Licence;

I

'

4.2

Dispensations pro\'ided in para 4.2 shall be
, applicable to those licencees who are already
holding service area UL.
I

I

I

', TRAI is requested to reconsider in view of the
above.

5.
5.1

Scope of the Licence
Subject to Clauses f and g of Clause 5.1 and Clause 5.2, Unified Licence
will be service and technology neutral and the Unified Licensee shall be
permitted to provide any telecom service, as defined below on a non-

The word "service neutrality" needs to be
removed as the services to be provided and
prohibited have been mentioned under the
scope of licence.

~·

Page10of61

<!-- page 12 -->

TRAl's Recommendations

DoT's comments

exclusive basis, anytime, anywhere, using any technology within its
licence area as prescribed below:
a.

Collection, carriage, transmission and deiivery of voice and/ or non­
voice messages over Licensee's network in the designated licence
area and includes provision of all types of access services. Unified
licensee can also provide Internet Telephony, Internet Services
including IPTV and Broadband Services including triple play i.e.
voice, video and data. The Licensee shall be free to enter an
agreement with other service provider in India or abroad for
providing roaming facility to its subscriber under full mobility
service unless advised / directed by TRAI other.vise.

b.

Unified Licensee can provide dark fibres, Righ;: of Way, duct space,
towers on lease / rent / sale basis to the licensees of telecom
services on mutually agreed terms and conditions. The Licensee

5. l(b) Sharing of active network should be
subject to guidelines and specific licence \
conditions. TRAI may recommend conditions
of active network sharing.
I

will also be allowed to install and share active ne:work limited to
antenna, feeder cable, Node B, Radio Access i\ietwo1k (RAN) and
transmission systems and to seek SACFA siting clearance for
erecting towers with or without agreement with licensed Service
~

Page 11 of 61

<!-- page 13 -->

DoT's comments

TRAI's Recommendations

Providers.
c. Unified Licensee can provide Voice mail, Audiotex, Videotex, UMS,
Radio paging and PMRTS.
5. l(d) 'v1.ay be modified as below:

d. Unified Licensee is permitted to provide leased circuit within its
licence area. Public network is not to be connected with leased
circuits/CUGs.

I

"Unified Licensee is permitted to I
provide leased circuit within its
licence
area.
Interconnection
with
PSTN/PLMN/lntemet Telephony Network is
I not
. permitted
with
leased I
CJrcu1ts/CUGs.··
]
1

e.

A Unified Licensee shall be permitted to offer any/ all services
covered under 'Class licence' and 'Licensing through Authorisation'
but not vice-versa.

5.1 (e ) A licensee will be permitted to hold
only one licence for overlapping services and
service areas . The same will apply to existing
licensees on migration. Substantial equity
(holding of 10% or more) restriction may
apply between the categories as mentioned in
para 13.1. As mentioned above, the licensee
can provide many services which require
separate licences. However it may be required
i to be indicated in the scope that the terms and
] conditions of such licences will become
] applicable to the licensee as detailed in I
I Unified License.
I
I

f. The Licensee cannot provide any other service which otherwise
require a separate licence.

I

g. The Licensee cannot provide broadcasting services, for which a

I 5.1 (g) Following may be added after the

J.'._

Page 12 of 61

<!-- page 14 -->

DoT's comments

TRAl's Recommendations

words DTH : "Or any other broadcasting
service".

separate licence / registration is required as per Cable TV Act 1995
and guidelines for DTH Licence issued by Ministry of Information

!

and Broadcasting.
5.2

The services which a Unified Licensee can offer will be as below:
a.

National level Unified Licence shall permit che Licensee to offer any
or all of the telecom services mentioned in Clause 5. l in any/ all
service areas; GMPCS, NLD and ILD services and Resale of !PLC.

b.

Service area level Unified Licence shall permit the Licensee to offer
any or all of the telecom services mentioned in Clause 5.1 except
National Long Distance (NLD), International Long Distance (ILD),
Global Mobile Personal Communication by Satellite (GMPCS)
services, Resale of !PLC and services covered under Class Licence.

c.

District level Unified Licence shall permit the Licensee to offer any
or all of the telecom services mentioned in Clause 5.1 in the district
for which licence is given. However, a District level Unified licensee
shall not be permitted to offer NLD, ILD, GMPCS, VSAT & Resale of
!PLC, INSAT-MSS and wireless access service. Also, these

I

! 5.2(c) Comments regarding district level '
1

licence may also be seen as in para J above.

I TRAI

'

d .
.
.
recommen auon
agamst
para
i 2.1 S(chapter-Il) " .... the district level service
I

Page 13 of61

<!-- page 15 -->

TRAI's Recommendations

Licensees would not be entitled for assignment of spectrum
resources for access services. District levei Unified Licence will not
be given for Metro areas of Delhi, Mumbai and Kolkata.

1

DoT's comments

I provider may also act as an MVNO ..... '· is
· contradictory to what is stated against 5.2(C)
of Appendix not permitting wireless access
service provisioning. TRAI is requested to
clarify.

(Note - The definitions of various services mentioned above are as given m
Annexure I)
6.
6.1

Ownership of Licensee Company
The Licensee shall ensure that all the conditions mentioned in Clause 2
(eligibility conditions) are maintained during the currency of the Unified
Licence.

6.2

The Licensee shall declare the Indian & Foreign equity holdings (both
direct and in-direct) in the Licensee Company and submit a compiiance

6.2 After the words stailutory auditors.
"countersigned by duly authorised director''
may be added.

report regarding compliance of FD! norms and security conditions on
1st day of January and 1st day of July of every year to TRAI. This is to
be certified by the Company Secretary or Statutory Auditor of the
Licensee Company.
7.

7.1

Duration of Licence
The validity period of a Unified Licence will be for a period of 20 years.

J\2-

Page 14 of 61

<!-- page 16 -->

TRAl's Recommendations

DoT's comments

8.

Renewal of Licence

8.1

Renewal - TRAI may renew, if deemed expedient, the period of Unified I The word "TRAI" wherever used in 8.1 and
Licence by a period of 10 years at one time upon the request of the·
Licensee on terms mutually agreed. The decision of TRAI shall be final
in this regard.

8.2

On renewal, Unified Licensee will be required :o pay a Renewal Fee

.

8.2 may be replaced by "Licensor"

which will be as notified by TRA.I.
9.
9.1

Suspension/ revocation/ termination/ Surrender of Licence
TRAI reserves the right to suspend the operation of this Licence in whole

The word "TRAI" wherever used in 9.1,9.2 i
and 9.3 may be replaced by "Licensor".

!

or in part, at any time, if, in its opinion, it is necessary or expedient to
do so in public interest or in the interest of the seci..:ri~y of the State or
for the proper conduct of the Teiegraph.
Provided that TRAI, if the situation so warrants, dispense with the issue
of notice prior to such suspension. The decision of the TRAI in this
regard shall be final and binding.
9.2

TRAI may, without prejudice to any other remedy available for the
breach of any conditions of licence, by a written notice of 60 Calendar

cpe Page 15 of 61

<!-- page 17 -->

DoT's comments

TRAl's Recommendations

days from the date of issue of such notice to the licensee at its
registered office, terminate this licence under any of the following
circumstances:
(i)

If the LICENSEE:

a)

fails to perform any obligation(s) under the licence including
timely payments of fee and other charges due to the
Government;

b)

fails to rectify, within the time prescribed, any
defect/ deficiency/ correction in service/ equipment as may be
pointed out by the TRAl/DoT;

(ii)

c)

fails to comply with FDI norms;

d)

goes into liquidation or is ordered to be wound up;
for non-compliance of any or all terms and conditions of the

. Para 9.2 (ii) and proviso below that are not
part of the existing licensing framework. It is
• felt that this may not be added now.
I
1·

licence.

I

Provided that the order terminating the Licence shall take effect only on

I

expiry of 60 calendar days from the date of issue of such order.

~

Pagel6of61

<!-- page 18 -->

DoT's comments

TRAl's Recommendations
9.3

Licensee may surrender the Licence, by giving notice of at least 60
Calendar days in advance. Unless the surrender notice is rejected by
TRAI within 30 days of the date of receipt of the no:ice, the effective date

[ 9.3This clause is different than the existing
I provision of clause 10.3 of the UAS Licence.
' We may modify it accordingly.
I

of surrender of Licence will be 61" Calendar day counted from the date
of receipt of such notice by TRAl.

10. Penalty
10.1 TRAI may impose financial penalty (as detailed below) based, for each
violation of the terms and conditions of licence agreement:

It is noted that the penalty has been reduced
, from Rs 50 Crs to a maximum of I 0 Crs and
cat_egorisation of major and minor violation as ,
I gmdmg prmc1ple has been provided.
·1·

1

1

No. of
times

Minor violation

1st

1 lakh

lOlakh

2nd

Slakh

50iakh

3rd

25lakh
·-------·--I-­

2.S crore

Major violation

-------+--------------·----------~------

4th
251akh
5 crore
!--------+----=~--- · - - - - - - - - - · - · - - 5th and
subsequent
violations

25lakL

~ 0 c:-orc

10.2 Before deciding the imposition any :Jenalty, proper opportunity will be

[ Under the UAS licence penalty for subscriber
verification violations is imposed on monthly
basis. In such cases applicability of first to
fifth violation may not apply.

1

In para I 0.4(ii) has an element of subjectivity
with respect to heavy revenue loss.
Similarly under para I 0.4(iii) it has been
recommended to impose penalty outside the
framework
of the T&C of the licence. This
I
appears to be non-implementable and legally
untenable.
Further the limit of penalty in the ex1stmg
licences has been defined separately m
different licences and are much lower m
I amount than the amount proposed.

1t'" Page

17 of61

<!-- page 19 -->

DoT's comments

TRAI's Recommendations

given to Licensee to present its case.

I

10.3 For categorising a violation as minor or major, the guiding principles
shall be
•

Whether the violation is committed delibera:ely or inadvertently;

I

As a result the limit of penalty has come
dovm drastically for large network operators,
while at the same time for licensees opting for
services like ISP/NLD/ILD etc, it has gone
up.
It is also noted that penalty of l" major

1 violation

is much

less than

5th

minor

•

Whether the violation is committed repeated violations;

i violation. Also l st serious violation with could

•

Whether the licensee is prompt in taking corrective action;

have large implications has not
addressed in the proposed scheme.

•

The amount of loss to the exchequer;

•

What kind of benefits were derived by licensee due to the
violation;

•

Whether the violation was restricted in a service area or was
across a number of service areas;

•

Whether the violation / breach carried out in its network by a
third party beyond the control of the operator;

•

Whether the violation has an impact on the end-user(s) and /or
other licensee(s) business.

I

·1

been

DoT is also looking into criterion for
imposition of penalty separately. Penalty
imposition principles given by TRAI may be
kept in view while finalising the criterion by
DoT.
Penalty should be SA wise. EMF & CAF I
penalties and any other similar penalties. if
any. shall continue to be decided separately
by DoT from time to time.
TRAI is requested to reconsider in view of the
above.

10.4 Notwithstanding the above, the following violations be always be
categorised as major violations;

~

Page 18 of61

<!-- page 20 -->

TRAl's Recommendations

DoT's comments

l------~~----~---~------------,-----:----:-----~~-+-----~-~~~-~~---~-Vio lation resulting in threat to the security of nation,

11

Violation resulting in heavy revenue losses to the Government.

m

Wilful and illegal conduct of the Licensee outside the framework of
terms and Conditions of the Licence.

I
L~~--~~~~~~~~~~~~~~~~~~~t---~~~~~~~~~1

!

Financial Conditions
11.
Fees payable
11. l Entry Fee - One time non refundable Entry Fee as detailed in Clause 4

11. l The comments already noted above may
be seen

of these guidelines.
11.2 Licence Fee - An annual Licence Fee as a percentage of Adjusted Gross

date of the Unified Licence, this Licence Fee shall be subject to

11.2 It is not clear whether for the national
level licence AGR is composite AGR for all
service areas.

minimum of 10% of the Entry Fee paid.

It is noted that due to allocation of resources

Revenue (AGR) shall be applicable. From the second year of the effective

like spectrum, numbering etc on service area
basis and also due to the fact that National
and service areas licence will coexist, the .
AGR should be on service area basis as per
the requirement ofUASL.
I

It is also necessary to mention Licence fee as

a percentage of AGR with component of
USOF contribution. It is presumed that
¥--Page 19 of61

<!-- page 21 -->

DoT's comments

TRAI's Recommendations

Uniform Licence fee would be applicable.
including USOF levy as may be prescribed by ,
Licensor from time to time.

11.3 The Fee/royalty payable towards Wireless Planning and

!

11.3 The title may be read as under:

I

Coordination Wing (WPC): In the event of a Unified Licensee being
' "The Fee/royalty/Spectrum Usage
.
..
.
.
Charge payable towards Wireless
given spectrum, WPC Charges shall be pavab1e
at such time and m such Pl ann1ng
.
"
an d Coor d"unat"ion w·1ng
manner as the WPC Wing of the DoT may prescribe from time to time.
(WPC):"

I

I
12.
Bank Guarantee
12.1 Each holder of a Unified Licence shall be required :o submit a Financial

bank Guarantee {FBG). The FBG shali ·::ie equivalent to the Licence Fee
payable for two quarters. The minimum annual Licence Fee is 10% of
the entry fee. Therefore, for new entrants, initiaily FBG shall be for an
amount of Rs. 75 {Seventy Five) lakh for National level Unified Licence,
Rs. 5 {Five) lakh for each Service area level Unified Licence except J&K
and North East Service area where the initial FBG will be 2.5 lakh each
and Rs. 50,000 {Fifty thousand) for each District level Unified Licence.

12.1 In the present licensing regime, PBG is
not linked to roll-out alone. Therefore I
PBGs are required to be prescribed. I
Further the FBG shall lbe equivalent to
the LF payable for two quarters and any
other dues.
I

The amounts PBG may be recommended
by IRA!. However, Presently amount of
FBG is 50/ 25/ 5 crores for A/B/C
service areas, which comes to 630 crores '
for all 22 SAs. Similarly PBG is 20/ 10/
2 crores (clause 21 ofUASL)
1

The amount of FBG shall be reviewed on six monthly basis by TRA! and
subsequently, the amount of FBG shall be equivalent to the estimated

¥

Page 20 of 61

<!-- page 22 -->

TRAl's Recommendations

DoT's comments

sum payable equivalent to Licence Fee for two quarters and other dues
not otherwise securitized and anv
additional amount as deemed fit bv
"
"
the TRAI/DoT.

13.
Merger of Unified Licences
13.1 Merger of Unified Licences may be permitted as per guidelines issued by

DoT from time to time.

13. 1
Merger
guidelines
as ,
applicable today are relevant for service
area level licences. In the proposed UL
regime there will be three categories of
licences ,i.e., National, Service area and .
District level licences. It may be difficult
to ensure level playing field if the
competition is to be maintained
separately under National and Service
area licence. Such a situation may also
not be desirable. Therefore it is for I
reconsideration that competition may be
maintained at Service area level and '
amended guidelines may be suitably ·
modified to cover National licence ,
holders.
,

1

For holding of licences and for the
purpose of M&A, it is proposed that
Substantial equity (holding of 10% or
more) restriction may apply between the
categories as mentioned below:

J;? Page 21 of61

<!-- page 23 -->

TRAl's Recommendations

DoT's comments
UL-UL
UL-CL
UL-Licence through Authorisation
CL-Licence through Authorisation

IRA! recommendations are sought for
M&A under UL regime vis-a-vis those
existing licencees who may not migrate
to UL

'
Same may be reflected in eligibility j
conditions
of
respective
licence
guidelines also (e.g. UL/CL/DL)
I
I

General Conditions

14. Change in the name of the Licensee Company shall be permitted in
accordance with the provisions under the Indian Companies Act, 1956.
15. The Licence shall be governed by the provision of Indian Telegraph Act, 1885,
Indian Wireless Telegraphy Act, 1933 and Telecom Regulatory Authority of

15. We may add the words "IT Act or any
other relevant act" at the end of the paragraph.

India Act, 1997 as modified or replaced from time to time.
16. The Licensee shall comply with any order, direction, determination o~
regulation as may be issued by TRAI from time to time.

16. We may add the word "'instructions .. aticr
"'direction" and replace "' IRAr· with ,
"Licensor/IRA!"'.

~ Page 22 of61

<!-- page 24 -->

TRAl's Recommendations

DoT's comments

17. The Licensee shall be responsible for, and is authorized to own, install, test

17.Following may be added at the end of para
·'complying to the security requirements as l
prescribed from time to time under the ·
respective licence agreement."

and commission all the applicable systems for providing the services.
18. The Licensee shall make its own arrangements for Rignt of Way (ROW).

I

19. Licensee shall make its own arrangements for all infrastructure involved in
providing the service and shall be solely responsible for installation,
networking, operation and commissioning of necessary equipment and

19. For franchisee /agents existing provisions .
may be incorporated.
·

systems, treatment of subscriber complaints, issue of biils to its subscribers,
collection of its component of revenue, attending to clair'.ls and damages
arising out of his operations.
20. The Licensee shall provide the details of the technology proposed to be
deployed for operation of the service. The technology should be based on
standards issued by ITU /TEC or any other International Standards

20. We may add the word "etc" at the end of!
the para and delete " ... bodies/industry" from ;
the second line.
·
'

Organization/ bodies/Industry. Unified Licensee is permitted to provide,
service by

utilizing any type of network equipmen:, including circuit

and/or packet switches that meet the relevant lnternationa'.
Telecommunication Union (ITU) /Telecommunication Engineering Center
(TEC) / International standardization bodies such as 3GPP/ 3GPP­

Page 23 of 61

<!-- page 25 -->

TRAI's Recommendations
I

DoT's comments

A_N_S_I_/_E_IA_/_T_IA_/_I_S_.---------------~--------·------1

l~--2/_E_T_S_I_/I_E_T_F_/

!

I
In case of provision of bandwidth by the Licensee through the satellite
121.
I
I

media, the Licensee shall abide by the prevalent Government orders,
directions or regulations on the subject like satellite communication poiicy,
V-SAT policy etc.
22. Sharing of active/passive infrastructure shall be as per the guidelines issued
22. We may replace the word 'TRAI" with
''Licensor".

by TRAI from time to time.
23. The Licensee shall adhere to the National Numbering plan, National

23. The paragraph may be modified as below:

Frequency Allocation Plan and any other plan issued by Department of
Telecommunications and technical standard as prescribed by TRAI, from
time to time.

"The Licensee shall adhere to the National
' Fundamental plans like National numbering
plan, Signalling plan, Routing plan etc along
with National Frequency Allocation Plan and
any other plan issued by Department of
Telecommunications and technical standard
as prescribed by DoT, from time to time."
I

I

. 24. The Licensee providing access service, shall provide independently or

'. 24. The last sentence of the para may be
i modified as below:

I"

While providing access to emergency i

J\'.7

Page 24 of 61

<!-- page 26 -->

DoT's comments

TRAl's Recommendations

ugh mutually agreed commercial arrangements with other Service
·iders, all public utility services including Toll F:-ee services namely
I

police, fire, ambulance or any other emergency number as may be specified
by the DoT /TRAI from time to time. While providing emergency services
such as police, fire, ambulance etc. it shall be ensured tI1at such calls shall

I
'

l services

I emergency response services
!services during disaster including police/Fire
etc as defined from time to time, it shall be
ensured that such calls shall be delivered to
the designated control room. as prescribed
! from time to time. of the
concerned ·
i authority."

be delivered to the control room of the concerned ai..::hority for the area from

i The licensee shall follow the standard •
i operating procedures as may be prescribed for

where call is originated.

I the disaster management /emergency response
1

services.

25. Interconnection
25.1 It shall be mandatory for the Unified Licensee to provide interconnection

Interconnection issue under National Unified
Licence scenario, co-existing with UL­
to all eligible Telecom Service Providers (eligibility shall be determined as restricted (SA) needs to be addressed with
respect to the issues such as calculation of
per the service provider's Licence agreement and TRA.I's
AGR, applicability of interconnect regulation
on NLD etc.
determination/orders/regulations issued from time to time) to ensure
that the calls are completed to ali destinations. TRAi may intervene in
the matter of interconnection between two service providers.

25.2 The interconnection with a telecom service provider shail have to be

Further, certain specific prov1s10ns of
respective licences may also be incorporated
in the UL guidelines. Some of such provisions
are listed in Annexure.

withdrawn, in case of termination of the licence of Ihe Telecom service
provider, within one hour or withi:~ such time as directed by the TRAI in
writing, after receiving intimation from the TRAI ir: :his regard.

~

Page 25 of61

<!-- page 27 -->

DoT's comments

TRAl's Recommendations

25.3 The terms and conditions of interconnection including, inter alia,
standard interfaces, points of interconnection arid technical aspects will
be subject to compliance of prevailing regulations, directions and
determinations issued by TRAI from time to time.
25.4 The charges for accessing other networks for inter-network calls shall be
based on mutual agreements between the service providers conforming
to the Orders/Regulations/Guidelines issued by the TRAI from time to
time.
26. Quality of service
26. l The Licensee shall operate and maintain the licensed Network
conforming to Quality of Service standards ::o be mutually agreed in
respect of Network- Network Interface subject to such other directions

. 26.1 This clause should be modified to retain
the broad provisions of Para 28. l of UASL as
below:
'I

"The Licensee shall ensure the quality oC
service as prescribed by the Licensor or
I TRAI. The Licensee shall adhere to such QoS
!
1.

as TRAI may give from time to time. Failure on part of Licensee or his
franchisee to adhere to the Qualitv of Service stipulations bv TRAI and

' standard and provide timely information as
required therein."
network to network interface standards of TEC mav be treated as breach ,
~

"

'I

of Licence terms.
27. Security Conditions
27.l The Licensee shall comply with the security conditions inter alia relating

27.1 The words "Subscriber verification" may
be added after the words " subscriber data" in I
the sixth line of the para.
I

Page 26 of61

<!-- page 28 -->

TRAl's Recommendations

DoT's comments

to inspection of the installation/ establishments, audit of networks,
security of the network, restriction on employment of foreign nationals,
transfer of information outside the country, remote access, monitoring
of networks, confidentiality of information relating to subscriber data
and any other condition imposed by DoT /TRAI from time to time.
B. Additional Guidelines for Spectrum assignment associated with Unified
Following issues arises:
Licence
Networth of promoters have not been '
28. The net worth requirement for those Unified Licensees w:10 may apply for
indicated under UL (Condition 2.4):
assignment of spectrum will be in addition to what is mentioned in Clause
Whether existing provisions of
2.3 above. The promoters of the Applicant Company shall have a combined
counting of Networth of only of those
promoters having atleast I 0% equity
net-worth of Rs. 100 crore/ Rs. 50 crore/ Rs. 30 crore '.or Category A, Band
holding is to be maintained or not.
C Service areas respectively. The Appiicant Company shall have a minimum
Whether networth requirements would
paid up equity capital equal to one-tenth of net-worth prescribed above and
be in three categories i.e. A/B/C.
I

shall submit a certificate to this effect (provided by the applicant's Company
Secretary) while applying for the spectrc.im.
I

29. Allocation of access spectrum will be ;nade service area-wise. In the event

Whether additional Networth is
required in case of MW/ backbone/
satellite
Spectrum/
PMRTS
assignment also;

!

a Licensee, or a single company/ legal person having substantial equity in

Networth requirement to be met :
before participation in Auction;

I

the Licensee company, has substantial equity of more than lO'Yo, directly

The additional Spectrum not defined;

I

~ldtrectly, tn any other Licensee i:-: :he same serv:ce acea, access

I
I

Categorisation to be based on National I
level, service Area level and J &Kl
1

1~- Page 27 of 61

'

<!-- page 29 -->

TRAl's Recommendations

spectrum can be bid for, by only one of such Licensee. In the event one of
such Licensee has already been allocated access spectrum, only such

DoT's comments

NE. Assam is not mentioned with N.E.
by TRAI.

Licensee will be entitled to bid for the additional spectrum in that service
area. In the event both the Licensees have been aliocated access spectrum,
only one of them will be entitled to bid for the access SDectrum.
Provided that this shall not be applicable to Licensees which were covered
by the Note under Clause 1.4 of the UAS licence conditions.
30. The Performance Bank Guarantee (PBG) and additional Financial Bank
Guarantee (FBG) shall be as prescribed at the time of assignment o'"
spectrum.

Para 30. Following may be added:
PBG & FBG shall be submitted before the
assignment of spectrum.

31. The Fees, charges and royalties for the use of spectrum and also for
possession of Wireless Telegraphy equipment shali be separately securitised
by furnishing FBG of an amount equivalent to the estimated sum payable
annually in the proforma given in licence agreement, to WPC, valid for a
period of one year, renewable from time to time till final clearance of aE such
dues.

132. The Renewal Fee discussed in Clause 8 above does not cover the vaiue of
Jt_

Page 28 of 61

<!-- page 30 -->

DoT's comments

TRAl's Recommendations
-----------------------~--------

-----------------------+-----------------­

spectrum, which shall be paid for separately.

33. There is provision of imposing Liquidated i
, Damages (LO) for not meeting the roll-out
33. Unified Licensees who will be assigned spectrum, will be required to comply i prescribed under the present U AS regime.
However no incentive/penalties are linked to
with roll out obligations as applicabie, with attendant incentives and penalty meeting the roll-out obligations in UAS
regime.
as linked to allotment of that particular spectrum block as may be specified
at the time of allotment of spectrum or as may be specified from time to time.
:i p ara ~"4 .
i

34. The Licensee shall pay spectrum usage charges in addition to the Licence
Fees on revenue share basis as notified separately from time to time by the
WPC Wing. For the limited purpose of levying spectrum charges, only the
revenue from the wireless services shall count towards AGR calculation. It

Presently for calculating SUC, the only
deduction from AGR is wireline revenue and
, not as proposed by TRAI. It may adversely
' impact the revenue from SUC. To avoid this,
existing definition of AGR may continue.

will continue to be determined on service area basis, 2,1~ci shall be levied only
in respect of those service areas, whe:-e the Licensee :iolds any access
spectrum.

TRAI
is
requested
to
reconsider
recommendations 28 to 34 in view of the
above.

35. For use of space segment and setting up of the Earth Station etc., the
Licensee shall directly coordinate with and obtain ciearance from Network
Operations and Control Centre (NOCC) under DoT, apart from obtaining
SACFA clearance. The clearance from other authorities as specified from
time to time shall also be obtained by the Licensee.

¢¥-- Page 29 of 61

<!-- page 31 -->

TRAl's Recommendations

II.

Guidelines for Class Licence

1.

Framework
1.1

DoT's comments

I .Definition of Class licence has not been
provided. For consideration of any new
Subject to fulfilment of relevant eligibility conditions, Class Licence shall service to be added in future. is felt necessary
to define class licence so that categorisation
be issued on non exclusive basis, without any restriction on the number
of services is carried out in a transparent and
of entrants in a licence area.
reasonable manner. Only two services namely
' VSAT and INSAT-MSS reporting service
have been designated to be part of Class
Class Licence will be issued only on National levei basis.
licence as per para 5.2 of this chapter.
;i

1.2

Also. while giving recommendations on
"Infrastructure
policy"
TRAI
had
recommended that IXPs shall also be licenced
under Class Licence.

I

'

Whether class licence as a policy should be
national licence, may also be recommended
by TRAI after class licence is defined.
Further. in view of comments on UL. if the
''Pay as you eat" concept
requires
consideration. whether in that situation. CL
may be dispense with as these are incremental ,
services being provided under CL.
1

I

I

4<- Page30of61

<!-- page 32 -->

TRAI's Recommendations

DoT's comments

Eligibiliity Conditions
2.1

The applicant must be an Indian Company, registered under the Indian
Companies Act 1956.

2.2

The Applicant Company shall have to be in compiiance with the
provisions applicable for existing Unified Access Service licence in the

2.2 to 2.3 As amended in the comments given
· in para 2.2 to 2.3 of Chapter I above for UL.
I

Consolidated FD! Policy 2011 issued by Department of Industrial Policy
and Promotion and such modifications to the policy as may be issued
from time to time. The relevant provisions are placed at Annexure-II.
2.3

FD! shall be subject to laws of India and not the laws of the foreign
country/ countries.

2.4

(a) The details of the equity holdings in the Applicant Company should
be disclosed by the company as follows:

I Name of

I Indian/ I Equity

[ Promoter/ Partner

I

!

Ne:

i

Wo:rth

I

Foreign

!

%

2.4(a) & (b) Any amendment required in the
table, may be incorporated while finalising
the application form.
However, networth column may not be
required.

l.

2.

I

lf2__ Page 31 of 61

<!-- page 33 -->

DoT's comments

TRAl's Recommendations

3.
(b) Details of equity holding of the Promoter I Partner Indian Companies
of the Applicant Company should be disclosed by the applicant
company, as follows:
SL

No.

Name of

! Indian/

Promoter/ Partner

''

1.

.

l Foreign

1

Equit

I
'

'V°lo

I

;

I

'

0

!

Worth
•

I
'
'

Net

!

;

2.
3.

I

I

'

'

i

•

I
'

Since there is no Cap on the number of I
licences which can be issued and for certain
services, backhaul spectrum may be required.
The Applicant Company shall pay a non refundable processing fee of Rs.
there will be a need to define a method of
1
25,000 (Rs. Twenty Five Thousand) for Class Licer'.ce.
receiving and processing applications so that
I the principle of Natural Justice is followed.
,

3. Application Procedure

i

I

3.1

1

1

3.2

The Applicant Company shall submit the application in duplicate in the
prescribed Application form.

3.3

Incomplete application is liable to be rejected and the processing fee will

It has been recommended that incomplete
applications is liable to be rejected . In normal
course some mmor discrepancies may be
there in the applications filled. There may be a
need to give some time to applicant to correct
the mistakes etc.
.1

J2_,

Page 32 of61

<!-- page 34 -->

TRAl's Recommendations

DoT's comments

not be refunded.
3.4

The application shall ordinarily be decided, within 60 days of the
submission of the application and the applicant company shall be
informed accordingly.

3.5

TRAI reserves the right to accept or reject any application without

In para 3.5 the word TRAI may be replaced
byDoT

ass1gn1ng any reasons.
3.6

In case the applicant is found to be eligible for grant of Class Licence, a

Detailed procedure may be worked out m
consultation with TRAI.

Letter of Intent (LOI) will be issued. The applicant shall be required to
deposit Entry Fee and submit Bank Guarantees / other documents and
sign the licence agreement within a period as mentioned in the
letter(LOI) from the date of issue of the letter (LOI) failing which the offer
of grant of licence shall stand withdrawn at the expiry of permitted
period.
[

3. 7

The Applicant Compa.ny will be required to pay one time non-refundable
~ntry Fee before s1gnmg the license agreement, basec on Letter of Intent

~-ol).

1

cA<­ Page 33 of 61

<!-- page 35 -->

TRAI's Recommendations

DoT's comments

4. Entry Fee
I

I

I

4.1

One time non refundable Entry Fee for each category of Class Licence
shall be Rs. 30 (Thirty) lakh.

I s. Scope of the Licence
i

5.1. Class Licence will be technology neutral and is granted to provide

designated service on a non-exclusive basis.
5.2. VSAT service and INSAT-MSS Reporting Service will be covered i..:nder
Class Licence.

However, TRAI reserves the right to include any other

service under Class Licence on recommendations of TRAI.
(Note - The definitions of various services mentioned above are as given in
Annexure III)

5.1 For declaring Class licence as technology [
neutral, it is desirable that the definition of [
class licence may be finalised first as .
mentioned in the comments given above.
[
5.2 VSAT service may be mentioned as
Commercial VSA T service as licences are
also given to captive CUG users for operating
VSA T networks.
Any licence or permission to be given by the
Licensor for Captive networks may be kept
beyond the scope of Unifi.ed licensing regime
as these are not public networks. The present
arrangements for such licences may continue.
TRAI had earlier recommended to include
PMRTS services under Class Licence (May
2010), which has now been recommended to
be under category of "Licence through
Authorisation" which is on fixed licence fee
basis. Para 6 of Chapter -Ill may also be [
I. seen.

~

Page 34 of61

<!-- page 36 -->

TRAl's Recommendations

DoT's comments
!
j
I

!

In second sentence, the word "TRAI" may be '
replaced by "Licensor".
·

6. Ownership of Licensee Company
6.1

The Licensee shall ensure that all the conditions mentioned in Clause 2

6.1 The word "Unified" may be replaced by •
"Class" in the last line.

(eligibility conditions) are maintained during the cu!Tency of the Unified
Licence.
6.2

The Licensee shall declare the Indian & Foreign equity holdings (both
direct and in-direct) in the Licensee company and submit a compliance
report regarding compliance of FD! norms and security conditions on

6.2 At the end of first sentence , the word
'"TRAI" may be replaced by 'DoT".In the
second sentence , After the words statutory
auditors, "countersigned by duly authorised
director" may be added.

1st day of January and 1st day o'. July to TRAI. This is to be certified by
the Company Secretary or Statutory Auditor of the Licensee Company.

; 7.

Duration of Licence
7 .1

The validity period of a Class Licence will be for a pe1iod of 20 years.

i 8. Renewal of Licence

i
8.1

Renewal ­ TRAI may renew, if deemed expedient, the period of Class
Licence by a period of 10 years at one time upon the request of the

c/'(./ Page 35 of 61

<!-- page 37 -->

DoT's comments

TRAl's Recommendations

I
i

Licensee on terms mutually agreed. The decision of TRAI shall be final

I

in regard to renewal of licence.

I
8.2

On renewal, Class Licensee

will be required to pay a Renewal
8.2 The word "TRAI ·' may be replaced with
"Licensor".

Fee which will be as notified by TRAI from time to time.
9. Suspension/revocation/termination/Surrender of Licence
9.1

TRAI reserves the right to suspend the operation of this Licence in
whole or in part, at any time, if, in the opinion of TRA!, it is necessary
or expedient to do so in public interest or in the interest of the
security of the State or for the proper conduct of the Telegraph.

j

9.1 to 9.3 may be amended after
reconsideration by TRAI based on comments
given against para 9.1 to 9.3 in respect of UL
in chapter I.

Provided that TRAI may, if the situation so warrants, dispense with
the issue of notice prior to such suspension. The decision of TRAI in
this regard shall be final and binding.
9.2

TRAJ may, without prejudice to any other remedy available for the
breach of any conditions of licence, by a v.Titten notice of 60 Calendar
days from the date of issue of such notice to the licensee at Its
registered office, terminate this licence under any of the following

JSZ_

Page 36 of 61

<!-- page 38 -->

TRAl's Recommendations

DoT's comments

circumstances:
(i)

If the LICENSEE:
a)

fails to perform any obligation(s) under the licence including
timely payments of fee and other charges due to the
Government;

b)

fails to rectify, within the time prescribed, any
defect/ deficiency/ correction in service/ equipment as may be
pointed out by the TRAI/DoT;

(ii)

c)

fails to comply with FD! norms;

d)

goes into liquidation or is ordered to be wound up;
on recommendation by TRAI for termination of licence for non­
compliance of any or all terms and conditions of the licence.

Provided that the order terminating the Licence shall take effect only
on expiry of 60 calendar days from the date of issue of such order.

9.3

Licensee may surrender the Licence, by giving notice of at least 60

#

Page 37 of 61

<!-- page 39 -->

DoT's comments

TRAl's Recommendations

Calendar days in advance. Unless the surrender notice is rejected by
TRAI within 30 days of the date of receipt of the notice, the effective
date of surrender of Licence will be 61 st Calendar day counted from
the date of receipt of such notice by TRAI.
10.

Penalty

The proposed penalty structure is same as
the structure proposed by TRAI for UL 1
and doesn't appear to be commensurate
with the gravity of violation and the type
of services to be provided under Unified
Licence and under the class licence. '
However, there is no provision for penalty
in VSA T and INSA T MSSR licences.

10. l TRAI may impose financial penalty, for violation of terms and
conditions of licence agreement.

1

No. of
times

Minor violation

Major violation

1st

1 lakh

lOlakh

2nd

5lakh

50lakh

3rd

25lakh

2.5 crore

4th

25lakh

i

i'

5 crore

5th and
subsequent
: 0 crore
25lakh
violations
10.2 Before deciding the imposition any penalty, proper opportunity will be

In para I 0.3, a segregation has apparently
been made between National Service area
of the class licence and Circle based area.
Clarity is required about the actual
imposition of penalty as per the proposed
prov1s1on.

Other comments same as in chapter -I for CL.

'

given to licensee to present its case.

TRAI
may
give
I recommendation.

their

Ji__

reconsidered I

Page 38 of 61

<!-- page 40 -->

TRAl's Recommendations

r
!

10.3

DoT's comments

For categorising a violation as minor or major, the guiding principles
shall be
•

Whether the violation is committed deliberateiy or inadvertently;

•

Whether the violation is committed repeated violations;

•

Whether the licensee is prompt in taking corrective action;

•

The amount of loss to the exchequer;

•

What kind of benefits were derived by licensee due to the
violation;

•

Whether the violation was restricted in a service area or was
across a number of service areas;

•

Whether the violation / breach carried out in its network by a
third party beyond the control of the operator;

•

Whether the violation has an impact on the end-user(s) and /or
other licensee(s) business.

10.4 Notwithstanding the above, the foliowing violations be always be
categorised as major violations;
Violation resulting in threat to the security of nation,
11

Violation resulting in heavy revenue losses to the Government

c/(; Page 39 of 61

<!-- page 41 -->

TRAl's Recommendations
111

DoT's comments

Wilful and illegal conduct of the Licensee outside the framework of
terms and Conditions of the Licence.

Financial Conditions
11. Fees payable
11.1

Entry Fee ­ One time non refundable Entry Fee as detailed in Clause 4.

11.2 Licence Fee ­ An annual Licence Fee as a percentage of Adjusted
Gross Revenue (AGR), as defined in the licence agreement shail be
applicable. From the second year of the effective date of the Unified

11.2-3 Same as amended para 11.2-3 of
• Chapter I of UL.

Licence, this Licence Fee shall be subject to minimum of 10% of the
Entry fee paid.

11.3 The Fee/royalty payable towards Wireless Planning and

Coordination Wing (WPC): In the event of a Unified Licensee being
given spectrum, WPC Charges shall be payable at such time and in
such manner as the WPC Wing of the DoT may prescribe from time to
time.

J7-

Page 40 of61

<!-- page 42 -->

DoT's comments

TRAl's Recommendations

[ 12. Bank Guarantee

I

It is noted that financial Bank guarantee for

12.1 Each holder of a Unified Licence shali be required to submit a

VSA T licence is Rs 30Lakh while the PBG is
Rs 50Lakh.

Financial bank Guarantee (FBG). The FBG) shali be equivalent to the

There is no mention of PBG in this para of the
recommendation.

Licence Fee payable for two quarters. The minimum annual Licence
Fee is 10% of the Entry Fee, therefore, for new entrants; initially FBG
shall be for an amount of Rs. 1.5 lakh. The amount of FBG shall be
reviewed on six monthly basis by TRAI and subsequently, the amount
of FBG shall be equivalent to the estimated sum payable equivalent to
Licence Fee for two quarters and other dues not otherwise securitized
and any additional amount as deemed fit by the TRAI/DoT.

113. Merger of Class Licences
!

13.1

13. I Currently there are no guidelines in
. respect of M &A , VSA T and INSAT MSSR
Merger of Class Licences may be permitted as per guidelines issued by and IXP Licences.

DoT from time to time.

j

I

TRAI may recommend such guidelines.

General Conditions
14. Change in the name of the Licensee Company shall be permitted in

~Page41of61

\!

<!-- page 43 -->

TRAl's Recommendations

DoT's comments

accordance with the provisions under the Indian Companies Act, : 956.
15. The Licence shall be governed by the provision of Indian Telegraph Act, 1885,

15. May be amended in the same manner as
per comments given in respect of Unified
I Licence.
1

Indian Wireless Telegraphy Act, 1933 and Telecom Regulatory Authority of
India Act, 1997 as modified or replaced from time to time.
16. The Licensee shall comply with any order, direction, determination or­

regulation as may be issued by TRAI from time to time.

16. May be amended in the same manner as
per comments given in respect of Unified
Licence
17. May be amended in the same manner as
per comments given in respect of Unified
Licence

17. The Licensee shall be responsible for, and is authorized to own, install, test

and commission all the Applicable system for providing the Services under
this Licence agreement.
18. The Licensee shall make its own arrangements for Right of Way (ROW).
19. The Licensee shall make its own arrangements for all infrastructures
involved in providing the service and shall be solely responsible for
installation, networking, operation and commissioning of necessary
equipment and systems, treatment of subscriber complaints, issue of bills to
its subscribers, collection of its component of revenue, attending to claims
and damages arising out of his operations.

¥2--- Page 42 of 61

<!-- page 44 -->

DoT's comments

TRAl's Recommendations

!---~~~~--~~~~~~~~~~~~~~~~~~~~~~~-·~~~~~~~~~-c-~~~~~~~~~~~~~~~~~---,

20. The Licensee shall provide the details of the technology proposed to be

20. May be amended in the same manner as :,

per comments given in respect of Unified ·
Licence

deployed for operation of the service. T'.-ic technology should be based on
standards issued by ITU /TEC or any other Internationai Standards
Organ[zation/ bodies/Industry. Class licensee is permitted to provide, service
by

utilizing any type of network equipment, including circuit and/ or packet

switches that meet the relevant International Telecommunication Union (ITU)
/Telecommunication Engineering Center (TEC) / Internatior.al
standardization bodies such as 3GPP / 3GPP-2/ ETSI/IETF /ANSI/ EIA/TIA/!S.
21. In case of provision of bandwidth by the Licensee through the satellite

media,. the Licensee shall abide by the prevalent Government orders,
directions or regulations on the subject Eke satellite communication policy,
V-SAT policy etc.
22. Sharing of active/passive infrastructure shall be as per the guideiines issued

by TRAI from time to time.

22. Currently there are no guidelines for :
' active/passive infrastructure sharing in respect !
of VSA T/MSS-R/IXP licences .The issues
involved in such sharing are yet to examined
in detail. Hence giving an indication of
possibility of sharing infrastructure many not
be appropriate at this stage.

1

I

The word "TRAI" ma

q}>L Page 43 of61

by

<!-- page 45 -->

DoT's comments

TRAl's Recommendations

"Licensor".

The Licensee shall adhere to the National Numbering plan, Nationai
Frequency Allocation Plan and any other plan issued by Department of
Telecommunications and technical standard as prescribed by TRAI, from
time to time.

23.No numbering resource allocation 1s
envisaged. This para may be amended as ,
below:
"The Licensee shall adhere to the National
Frequency Allocation Plan and any other plan
and technical standard as prescribed by DoT. ,
from time to time."
·

124. Interconnection
!

24. l

Eligibility for interconnection shall be determined as per the service
provider's Licence agreement and TRAI's
determination/orders/regulations issued from time to time. TRAI may
intervene in the matter of interconnection betv;een two service
providers.

24.2 The interconnection with a telecom service provider shall have to be
withdrawn, in case of termination of the licence of the Telecom service
provider, within one hour or within such time as directed bv the TRAI
in writing, after receiving intimation from the TRAI in this regard.
24.3 The terms and conditions of interconnection including inter alia

Page 44 of61

<!-- page 46 -->

TRAl's Recommendations

DoT's comments

standard interfaces, points of interconnection and technical aspects
will be as mutually agreed between the service providers, subject to
compliance of prevailing regulations, directions and determinations
issued by TRAI from time to time.
24-4 Interconnections restrictions applicable for VSAT network with other
networks:­
a.
b.

Interconnection with PSTN - Not permitted
Network of other VSATs - Interconnection shall be permitted
through the Hub on case to case basis, wherever the CUG nature
of the network is not violated.

c.

Terrestrial data lines leased by customers ofVSATs ­
Interconnection shall be permitted on case to case basis,

24.4.(a) May be modified as below:
''Interconnection with PSTN/PLMN /Internet
Telephony Network is not permitted."
24.4(b) Currently interconnectivity of CUG
networks on VSA T network with another
CUG network is not permitted. TRAI may be
requested to clarify the statement "Wherever
CUG nature of the network is not violated"
!NET may be deleted as this network no
longer exists.

wherever the CUG nature of the network is not ·,•ioiated.
d.

Terrestrial data lines of a public nature: - Interconnection shall be
permitted through the Hub, provided it is connected to a public
data network such as Internet/ !NET.

e.

Overseas office of the CUG for data transfer purposes:­

#-- Page 45 of 61

<!-- page 47 -->

TRAl's Recommendations

DoT's comments

Interconnection shall be permitted on a case to case basis subject
to the condition that the connection shouid be between the hub
and the server of the overseas office through a leased line passing
through an international gateway which can be monitored for
security purposes.
f.

WAN Operators:- Interconnection shall be permitted ore case to
case basis, wherever the CUG nature of the network is nm:
violated.

g.

Internet/INET :- The hub of VSAT Licensee shall be allowed to be
connected to an internet node of his choice through a lease line
taken from Telecom service provider who is authorised to sell
bandwidth/ leased line. Similar inter-connection of the Hub with
!NET is also permitted.

h.

Other media to provide for redundancy :- Switchover between a
terrestrial CUG network and a VSAT based CUG network
belonging to the same licensee shall be permitted for redundancy
purpose.

Page 46 of 61

<!-- page 48 -->

TRAl's Recommendations
1.

DoT's comments

Interconnection of CUGs :- Inter-connection between CUGs,
where the CUG nature of the network is not violated, will be
permitted on a case to case basis.

25. Quality of service

Before this para, a new para may be
considered for insertion as below:

25.1 The Licensee shall operate and maintain the licensed Network

'· While providing access to emergency
services I emergency response services
!services during disaster including police/Fire
etc as defined from time to time, it shall be
ensured that such calls shall be delivered to
the designated control room, as prescribed
concerned
from time to time, of the
authority."

conforming to Quality of Service standards to be mutually agreed in
respect of Network- Network Interface subject to such other directions
as TRAI may give from time to time. Failure on part of Licensee or his
franchisee to adhere to the Quality of Service stipulations by TRAI and
network to network interface standards of TEC may be treated as

The licensee shall follow the standard
operating procedures as may be prescribed for
the disaster management /emergency response
services..

breach of Licence terms.

26. Security Conditions
26.1 The Licensee shall comply with the security conditions relating to, inter
alia, inspection of the installation/ establishments, audit of networks,

I

:

security of the network, restriction on employment of foreign nationals,

c/(

Page 47 of61

<!-- page 49 -->

DoT's comments

TRAl's Recommendations

transfer of information outside the country, remote access, monitoring
of networks, confidentiality of information reiating to subscriber data
and any other condition imposed by the DoT,ITRAI from time to time.

III.
l.

Licensing through Authorisation
Subject to fulfilment of relevant eligibility conditions, Licence shall be

Eligibility conditions for licence through I
authorization need to be prescribed. TRAI '.
may provide eligibility criteria.
I

issued on non exclusive basis, without anv restriction on the number of
licences.
2.

The applicant must be an Indian company, registered under the Indian
Companies Act 1956.

3.

The Applicant Company shall pay a non refundable processing fee of
Rs. 15,000 (Rs. Fifteen Thousand).
i

) Amended para-4 may be as below:

4.

Complete application shall be decided, within 30 days of the
submission of the application and the applicant company shall be
informed accordingly.

'
1·

: ·'Application shall ordinarily be decided .
. within 30 days of the submission of the I
I completed application and the applicant
. company shall be informed accordingly.
[
I

I "TRAI'' may be replaced by DoT.

J? Page 48 of61

I

<!-- page 50 -->

TRAl's Recommendations

5.

DoT's comments

TRAI reserves the right to accept or reject any application without
assigning any reasons.

6.

The Licence will be service and technology neutral. Licensee shall be
permitted to offer Voice Mail Service, Audiotex, Videotex, Unified
Messaging Service and other value added services within its licence
area using the network of Unified Licensee on mutually agreed terms
and conditions. The Licensee shall be permitted to install dark fibers,
duct space and towers, subject to the condition that these shall not be

6. The services covered under authorization
are expected to be of different type than
envisaged under UL or CL requmng
individual licenses. It may also be possible
that each service type has its own
technological deployment.
Therefore, the
words "service and technological neutral''
i may not be required. Licence area may also
· be specified by TRAI.
Definition of Value Added Services to be
covered under authorization is requested from
TRAI.

used for activities relating to commercial telecom services. The
operation and tariff for the traffic passed through lJnified Licensee
network resources shall be as per the prevailing rules and regulations

The meanmg of "commercial
services'' is not clear.

of TRAI.

telecom

The word "TRAI" at the end of the para may
be replaced by TRAl/DoT.
In chapter -I of recommendations, TRAI has :
indicated PMRTS licence under this category. ·
However, in this para PMRTS is not included. !
It is assumed to be part of this para as it is not !
specified elsewhere.
Any new captive requirement may be covered
under provisions of para 314 of Vol -XII of
1
P&T manual.
I

I
'

¢{ Page 49 of61

<!-- page 51 -->

TRAI's Recommendations
7.

Licensee shall be required to pay an annual Licence Fee of Rs. 10,000
(Rs. Ten Thousand Only).

DoT's comments

7. While a Unified Licensee offering PMRTS
i will be charged licence fee on the basis of
: AGR, the fee for PMRTS under authorization
category remains fixed. Presently. PMRTS
licence fee is on % of AGR basis.
Two different dispensations for licence fee for
. same service is likely to create arbitrage.

8.

The Licensee shall make available, on demand, to the person
authorised by the TRAI/DoT, full access to their equipments/ network

· 8-10 "TRAI" may be replaced by "Licensor".

for technical scrutiny and for inspection, which can be visua;
inspection or an operational inspection.
9.

As and when required, the Licensee shall provide access of their
systems to the security agencies for monitoring purpose. The Licensee
shall be required to maintain call data records of all the specified calls
handled by the system and system log at specified periodicity. TRAI
reserves the right to call for these system logs on demand and also
inspect them at site.

10. TRAI reserves the right to revoke/terminate/suspend the Licence in

whole or in part, at any time, if, in the opfr1ion of the TRA!, it is

Page 50 of61

<!-- page 52 -->

TRAI's Recommendations

DoT's comments

necessary or expedient to do so in pubiic interest or in the interest of
the security of the State or for the proper conduct of the Telegraph.
11. Licensee may surrender the Licence, by giving notice of at least 30
Calendar days in advance.
12. The Licence shall be governed by the provision of Indian Telegraph Act,
1885, Indian Wireless Telegraphy Act, 1933 and Telecom Regulatory
Authority of India Act, 1997 as modified or replaced from time to time.

12.-13. "TRAI" in this paragraph wherever
used may be replaced by "Licensor''.
Accordingly, "TRAI Act J 997 or an amended
or modified statute" may be replaced by
"relevant laws"

13. The Licensee shall furnish to TRAJ, on demand, in the manner and as
per the time frame such documents, accounts, estimates, returns,
reports or other information in accordance with the :-ules/ orders as
may be prescribed from time to time. The Licensee snall also submit
information to TRAI as per any order or direction or regulation issued
from time to time under the provisions of TRAI Act, : 997 or an
amended or modified statute.
14. The Licensee shall comply with any order, direction, determination or
regulation as may be issued by TRAl from time w time.

14. We may add the word "Instructions" after
"determination". "TRAI" may be replaced by
"TRAVLicensor".

4"- Page 51 of61

I

<!-- page 53 -->

TRAI's Recommendations

IV.

1.

DoT's comments

Migration of Existing Licence to Unified Licence

On commg into force of the Unified Licence, aii the existing licences
issued under Section 4 of the Indian Telegraph Act 1885 shall stand
automatically converted to the Unified Licence. This will be the Unified
Licence (restricted). Necessary amendments shall be made bv TRAI

It is presumed that for each of the
category of licenses the name will be '
changed to Unified License (Restricted) I
suffixed with the name of the current
license. As an example USAL may be
called UL (Restricted)-UASL.
I

under intimation to the Licensee.
2.

On conversion, the validity of the Unified Licence (restricted) shall be
same as the validity of existing licence.

3.

The conditions of Unified Licence (restricted) shall be the same as
existing licence.

4.

Uniform licence fee has been proposed to '
be implemented in two steps. On
migration, in the first year of ULF. it
needs to be clarified whether the licence
fee shall be the ULF proposed in the first
year or as applicable in UL regime.

The services under such a licence will be restricted to the service(s) that
the Licensee could offer and to the service area(s) permitted under the
existing licence. In case an existing licensee after conversion to Unified
Licence (restricted) wishes to provide services permitted within the
scope of service under Unified Licence but which are not covered under
its old licence, then it will have to apply for Unified Licence.

cf2__

Page 52 of 61

<!-- page 54 -->

DoT's comments

TRAl's Recommendations

CS.

- - - - c - - · ·-----·

For convers10n to the Unified Licence (restricted), there shall be no
additional entry fee to be paid by the licensee.

6.

A holder of Unified Licence (restricted) shall have the option to apply for
and migrate to a Unified Licence.

7.

In

the

event a

holder of Unified

Licence

(restricted)

desires

to

expand/ alter the service(s) offered or service area(s) of operations, it shall
be required to migrate to Unified Licence and pay the prescribed entry
fee.
fllustration: A company 'A' has All-India licence for NLD and ILD, ISP (Category

8) and CMTS/UAS Licences for service areas 2 & 3 as given in the Table
below. After coming into force of Unified Licence framework, these
licences shall get converted to Unified Licences (restricted) i.e. the scope
of service of each new Unified Licence will continue to be the same as the
existing licence. However, if the Company wishes to provide any other
service permitted under Unified Licence, say ISP on all India basis or
access services in LSAs other than service areas 2&3, the:-1 it will have to
apply for migration to National level Unified Licence and will also have to
pay the prescribed entry fee and fulfil all eligibility conditions as given in ,
the Guidelines for Unified Licence.

r:Ji2- Page 53 of 61

<!-- page 55 -->

DoT's comments

TRAI's Recommendations

Unified Licences (restricted) - 6 licences
Licence

All

LSA-1

LSA-2

I LSA-3

I LSA-21 I LSA-22

'

I
I
I

India
i

'

!

CMTS/UASL

.,/

.,/

II

i

NLD

../

i

ILD

../

i

ISP

,/

I

.

,/

After migration to Unified Licence ­ 1 Unified Licence
Licence

'All India

CMTS/UASL
NLD
ILD
ISP
er Services defined in the scope
of Unifie Licence.
8.

In respect of 6 and 7 above, the Entry Fee already paid, in case of
NLD/ILD/UAS /CMTS licence only, will be adjusted on pro rata basis for

8. ft is noted that rebate for I 0 years
license period is equali to entry fee for
obtaining a 20 year service area license.
While as er ara 9 on mi ration to UL

¥'.----

Page 54 of 61

<!-- page 56 -->

DoT's comments

TRAl's Recommendations

the balance validity period of the existing Licence as per formula given in
the table below. However, in cases where the Ent:-y Fee already paid
exceeds the Entry Fee to be paid ::-iow for migrating :o Unified Licence,
there will be no refund of the Entry Fee.

Migration to

Rebate

ILD/NLD

National
level

Rs 12.5 lakh x No of years remammg for
existing NLD / ILD Licence validity.

UASL/ CMTS

Service area Rs
level

Type of
Existing
Licence

10

the validity of license is proposed to be 20 I
years.
For the sake of simplicity and proper
regulation of license periods, one of the
option is to keep the original licence
period unchanged on migration as in
UL(Restricted).
It will also help in ·
Refarming the spectrum at the time of
renewal as Refarming is linked to renewal i
of license.
'
I

lakl1, 5 lakh ar1d 2 " lakh for
Metro/Cat A, Cat B and Cat C service
areas respectively x No of years
remaining for existing UASL/CMTS
Licence validity.
-~

Further, looking at the migration of
CMTS licensees to UASL regime, even ;
after 10 years. both types of licences i
continue to exist today for various
reasons.
I

1

1

It needs to be kept in view that the
exercise of changing the names of the
licensees without migration to UL regime
may further add to confusion and some of '
the UL restricted may continue for next 20
years. (e.g. UL-Restricted-ISP)
·1

!

lakf:, 5 lakh anc 2.5 lakh for
Metro/Cat A, Cat B and Cat C service
areas respectively x No of years
rema1n1ng for existing UASL/CMTS
Licence validity subject to maximum
limit of Rs. 15 crore.
On migration to the Unified Licence, the validity of the l!cence shall be 20

UASL

9.

/CMTS National
111
level
vanous
service
area

Rs

10

years.
10. On expiry of the validity of the Unified Licence (restricted), the licensee

CK Page 55 of61

<!-- page 57 -->

DoT's comments

TRAI's Recommendations

shall be required to take a Unified Licence.
11. IP-I shall be covered under Unified Licence. "'he existing IP-I providers
would be required to take the Unified Licence as soon as the same comes
into being and the conditions in the Unifiec Licence will apply to IP-I
provider too. IP-I shall have to pay the prescribed entry fee to take the
Unified Licence. Only those IP-I companies '":--io either wants to provide
telecom

services

themselves

selling/ leasing/ renting

their

or

the

are

passive/ active

':>us:ness

infrastructure

·~o

of
other

telecom licensees would be required to take the Unified Licence. IP-I
companies, who are not engaged in activities relating to commercial
telecom

services,

would

be

required

to

::ake

'Licence

through

Authorisation'.

12. In the event a holder of Unified Licence (rest:-icted), having s;:iectrum,
obtains a Unified Licence, it will continue to retain the spectrum assigned
for the remaining validity period of the existing Licence. In case of 3G
/BWA spectrum holders, the spectrum assigned will be retained for the
period for which the spectrum blocks have been assigned. In both the
above cases, the Unified Licensees shall be allowed to provide all services
permitted under the Unified Licence, without however changing the

11. Two types of IP-I companies have
been indicated. The second type indicated
in the last sentence of the para indicates
that there will be IP-I companies who do
not provide commercial telecom services.
The commercial telecom services needs
clarification along with the scope of
category suggested.
Further. the decision of the Govt.
conveyed through press release dt. 15-2­
12 may also be kept in view.
Comments in para 1 of UL guidelines may
also be seen regarding TP-l.
TRAI may therefore requested to examine
the desirability of migration of IP-I to UL
regime.

12. We may add the following sentence
after ··...... channel plan of the allocated
spectrum··
"Upon completion of r<~maining period of
existing license, spectrum shall be
assigned based on the prevailing
guidelines regarding spectrum allocation
/reforming of spectrum.,.
TRAI may further clarify about making

~

Page 56 of 61

<!-- page 58 -->

~

TRAI's Recommendations

1~mnel plan of the allocated spectrum. The Licensee holding access
'

spectrum shall be required to maintain the net-wortr1 and paid up equity
as per existing licence, in case these are highe:- thar: the amount
prescribed in the Unified Licensing Regime.
Roll out obligations, if any, linked with the existing service providers shall i
remain applicable even after migration to Unified Licence Regime and shall '
be subject to changes/ modifications from time to time.

New para:

DoT's comments

process for liberalisation of the spectrum
won through auction for 3G and BW A.
Further BWA spectrum has been assigned
to ISPs and UASL operators where the
scope of licences is different.
Whether the scope of services to be
provided by such ISP and UASL who bid
for the spectrum under the relevant
prov1s10ns of NIN conditions of
respective Licences, on migration to UL,
would be limited to their original scope or
it would become uniform under proposed
UL guidelines.
Migration from a particular licence to UL
is a specific activity. TRAI may examine
whether separate guidelines for migration
from respective licence would be
required.

'~~~~~--~~~~~~~~~~~~~~~~--~~~~~~~~~~~~~~~-+-~~~~~~~~~~~~~~~~~__,

I,

Chapter V: Migration of Existing Licence to Class Licence

1.

On coming into force of the Class Licence, all the existing licences issued, ]We may add the word "commercial" before
' the word V-SAT.
under Section 4 of the Indian Telegraph Act 1885, issued for VSAT and

~Page 57 of 61

<!-- page 59 -->

TRAI's Recommendations

INSAT-MSS shall stand automatically
- converted to the Class Licence.

DoT's comments

·
''TRAI'' be rep laced by "L1ce:nsor".

This will be the Class Licence (restricted). I\ecessary amendments shall
be made by TRAI under intimation to the Licensee.
2. An existing Licensee, on migration to a Class Licence (restricted), will
continue to be governed by the same conditions and the validity period as

The observations here are same as against '
para-9 of Chapter -IV regarding validity of [
license after migration to Class license.
I

per the existing licence. It shall also be entitled to retain the spectrum

I

assigned, if any, for the validity period of the existing Licence.
3. The holder of a Class Licence (restricted) shall be entitled to migrate to a
Class Licence or a Unified Licence.
4.

On migration, the existing licensee will be required to pay Entry Fee as
prescribed for the Class Licence or Unified Licence. Entry Fee paid earlier
will be adjusted on pro rata basis for the balance validity period of the
existing Licences as per formula given in table below. However, in cases
where the Entry Fee already paid exceeds the Entry Fee to be paid now
for migrating to Class Licence or Unified Licence, there will be no refund
of the Entry Fee.

Page 58 of 61

<!-- page 60 -->

DoT's comments

TRAl's Recommendations
Type of Existing Licence

I Rebate

I

I
I

I
I

VSAT

'1

Rs 1.5 lakh x No o.f .years remaining for existing
Licence validity

5. On migration to the Class Licence, the validity of the licence shall be 20

years.
6. Roll out obligations, if any, linked with the existing service providers shall
remain applicable even after migration to Class Licence and shall be

I

1

i,

subject to changes/modifications from time to time.

Guidelines may also include some conditions which are indicatiYe of important conditions of Licence as is the case with existing
guidellines for UASL and other services.
TRAI is requested to provide their views/reco;isidered recommendations wherever certain observations/comments of DoT are indicated
against the TR.A.I recommendations.
Accordingly these recommendations are referred back to TRA! for reconsideration.

Page 59 of61

<!-- page 61 -->

Annexure
UL Guidelines- Specific Points to be incorporated in respect of 'l/LD I ILD I GMPCS Services

Ci\l!'CS
1.

Processing-fee of Rs 5 lakh (non-refundable) is being taken ''ith Applicmion O\\ing to different procedure of processing as detailed
below. (needs to be examined)
The Government announced the detailed guidelines on:" '\o\ctnbcr. 2001 to introduce GMPCS service (satellite Telephone Service) in
the country on non-exclusive basis subject to the clearance of specific proposal from security angle by an Inter-Ministerial Committee
consisting of Secretaries from Ministry of Home Affairs. 'v1inistr) of Defence. Deptt. of Space. Deptt. of Telecommunication. Cabinet
Secretariat(R) and Director, IB

3. One of the mandatory conditions of the GMPCS license agreement is regarding selling up of Land Earth Station (Gateway) in India. The
location of GMPCS gateway (land based satellite link station) outside India is :1ot rermitted in the licence agreement in view of the
following reasons:
(i) Possibility of monitoring of calls outside country by unauthorised agencies.
(ii) Non-availability of monitoring of calls in India hy security agencies.
4. Delivery of Service: The LICENSEE shall commission the Applicable S) sterns within one year from the effective date of the license.
5. Specific Security Conditions applv to GMPCS that need to he sc[Ktrateh mentioncd.(rclerence clause 41 of the GMPCS license).

Page 60 of 61

<!-- page 62 -->

NLD License
I. Inter-Circle traffic rrom one licensed sen ice area to another shall be routed through National Long Distance network.

2. The inter-circle traffic shall be handed O\er taker< U\cr to \LD net\\ork ;l[ the POP situated at the location ofNLD TAX in the licensed
service area.

ILD License
I. hir providing International Long Distance scnicc. the licensee shall establish at least one Gateway Switch alongwith requisite security
monitoring equi pmcnt within the prescribed period.

2. The Gateway station shall be set up only atier getting the permission or clearance from the Licensor. This is a time consuming process and can
t;1kc more than a month subject to submission of required information in complete form.
~. lhc Licensee shall follow the prescribed roming and ;rnmbering p!Jn and the international traftic shall be routed through the NLD and ILD

nct\\ork.

Page 61of61
