---
doc_id: "add513ebda14a6b6"
source_url: "https://steel.gov.in/sites/default/files/2025-04/Steel%20and%20Steel%20Products%20%28Quality%20Control%29%20Order%2C%202018.pdf"
ministry: "Steel (MoS)"
title: "Steel and Steel Products (Quality Control) Order, 2018.pdf"
date: "2025-04"
pages: 19
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "2b4505eda09b9ec9"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (ii)
PART II—Section 3—Sub-section (ii)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 3170]

ubZ fnYyh] lkseokj] vxLr 13] 2018@Jko.k 22] 1940

No. 3170]

NEW DELHI, MONDAY, AUGUST 13, 2018/SHRAVANA 22, 1940

इपात मं ालय
आदेश

नई दली, 13 अग त, 2018

का.आ. 3966
3966(अ)
66(अ).
(अ).—भारतीय मानक यूरो अिधिनयम, 2016 (2016 का 11) क धारा 16 ारा दत शिय का
उपयोग करते #ए तथा इ'पात और इ'पात उ)पाद (गुणव-ा िनयं/ण) आदेश, 2018, एवं 'टेनलेस 'टील उ)पाद (गुणव-ा
िनयं/ण) आदेश, 2018 का अिध5मण करके , िसवाए उन चीज़ को छोड़कर जो हो चुके है अथवा इस अिध5मण से पहले
करने से वंिचत रह गए है, क= >ीय सरकार यह मत रखते #ए @क सावAजिनक िहत म= ऐसा करना आवCयक है, भारतीय मानक
यूरो से परामशA करने के पDात िनEिलिखत आदेश करती है, नामशः1. संि शीषक,
ारंभ और अनु योग.– (1) इस आदेश को इ'पात और इ'पात उ)पाद (गुणव-ा िनयं/ण) आदेश,
2018 कहा जाएगा।

यह आदेश शासकय राजप/ म= इसके काशन क ितिथ से वृत होगा।
(3)
यह आदेश इ'पात और इ'पात उ)पाद पर लागू होगा ले@कन यहाँ िनधाAIरत कु छ भी ऐसे उ)पाद पर लागू
नहJ होगा, जो िनयाAत के िलए हK।
2. मानक क अनुपता.–इस तािलका के कॉलम (3) म= िविनNदO )येक उ)पाद उ तािलका के कॉलम (5) म= िनNदO
तारीख से कॉलम (2) म= िनNदO संबंिधत भारतीय मानक के अनुRप होगा।
3. मानक िचह का अिनवाय उपयोग .–भारतीय मानक यूरो ारा जारी लाईसेTस के तहत )येक इ'पात और इ'पात
उ)पाद म= मानक िचTह अं@कत होगा।
4.
माणन और वतन ािधकारी .– भारतीय मानक यूरो इस आदेश म= िनNदO इ'पात और इ'पात उ)पाद के संबंध
म= माणन एवं वतAन ािधकारी होगा।
5. उ$लंघन के िलए सजा.– जो भी Uि इस आदेश के @कसी ावधान का उVलंघ न करता है, वह अिधिनयम क धारा
29 के ावधान के अनुसार दंिडत @कया जाएगा।
(2)

4738 GI/2018

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY
6.

[PART II—SEC. 3(ii)]

भारतीय मानक म= संशोधन अथवा सुधार वृत होने क ितिथ - य@द तािलका म= िनNदO @कसी भारतीय मानक के
संदभA म= संशोधन अथवा सुधार @कया जाता है, तो इस आदेश के ावधान म= @कया गया संशोधन अथवा सुधार भी
यूरो ारा भारतीय मानक के संबंध म= अिधसूिचत क गई ितिथ से भावी होगा।
तािलका

भारतीय मानक का
*म सं. भारतीय मानक
शीषक
(1)
(2)
(3)
ि-'Zे'ड कं 5ट के
आईएस 1785
िलए [लेन हाडA-\ॉन
(भाग-1) :
इ'पात क तार के
1983
1.
िलए िविनद]शन; भाग
1 कोVड – \ान 'Zेस
Iरिल^ड तार
ि-'Zे'ड कं 5ट के
िलए [लेन हाडA-\ॉन
आईएस 1785
2.
इ'पात क तार ; \ान
(भाग-2) :
तार के Rप म= भाग 2
1983
3.

आईएस 6003
: 2010

4.

आईएस 6006
: 2014

आईएस
5.
13620 :
1993

6.

आईएस
14268 :
1995

7.
आईएस 277 :
2003

ि-'Zे'ड कं 5ट के
िलए इTड=Iटड तार हेतु
िविनद]शन
ि-'Zे'ड कं 5ट के
िलए अनकोIटड 'Zेस
Iरिल^ड 'Z=ड के िलए
िविनद]शन
_यूजन
बॉिTडड
इपो`सी
कोIटड Iरइनफोbसग
बासA-िविनद]शन
ि-'Zे'ड कं 5ट के
िलए अनकोIटड 'Zेस
Iरिल^ड
लो
Iरले`सेशन क सात
वायर ([लाइ) 'Z=ड के
िलए िविनद]शन
गेलवोनाईcड 'टील
शीdस ([लेन एवं
कोRगेटेड)- िविनद]शन

आईटीसी(
आईटीसी(एचएस)
एचएस)
(4)
72171010

भाव क
ितिथ
(5)
त)काल
भाव से

72179091
72179099

72171010

त)काल
भाव से

72179091
72179099

72171010
72179091

त)काल
भाव से

72179099

73121030

72142090

त)काल
भाव से
त)काल
भाव से

72159090

त)काल
भाव से
73121030

72104100
72104900
72123010

त)काल
भाव से

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

3
72123090

8.
आईएस 2002
: 2009

मeयवतf और उg

72085110

ताप

72085120

सेवाएं

िजसके

अंतगAत बॉयलर भी है,
के िलए दाब पा/ के
िलए 'टील [लेट
मeयम और िनE ताप
पर

9.

आईएस 2041
: 2009

उपयोग

: 2012
10.

िलए

पा/ के िलए
इ'पात [लेट िविनद]शन

72119011
72119090

72085220
72111300

72111300

72085110

72111420
72085120

योजन के िलए
इ'पात पुनब]Vलन के
िलए काबAन इ'पात

लूम और
िसVली - िविनद]शन
कं करीट पुनब]VVन के
िलए उg शि वाले
िवRिपत इ'पात छड़
आईएस 1786 :
और तार – िविनद]शन
2008
िबलेट,

नोट:-

यह

आदेश

8

एमएस से कम आकार

त)काल
भाव से

72111490
72119090

72085210
72085220

अवसंरचना

ढलवा िबलेट इनगोट,

11.

72111490
72085210

दाब

साधारण
आईएस 2830

के

72111420

त)काल
भाव से

72061090

त)काल
भाव से

72071190
72071290
72071920
72071990

त)काल
भाव से

72131090
72142090

के उg शि वाले
िवRिपत इ'पात छड़े
और तार के िलए लागू

आईएस 648 :
12.

2006

आईएस 3024 :
13.
2015

14.
आईएस

नहJ है।
पूणAतया @5यागत
कार क शीत
बेिVलत
गैरअिभके िT>त िवhुत
इ'पात शीट तथा पiी
- िविनद]शन
कण के अनुकूल िवhुत
इ'पात शीट तथा
पiी।
शीत बेिVलत गैर
अनुकूल िवhुत इ'पात

त)काल
भाव से
72251920
72261920

72251100
72261100

त)काल
भाव से
त)काल
भाव से

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY
15391 :
2003

शीट तथा 'Zीप-अधA
सं'कृ त कार िविनद]शन

[PART II—SEC. 3(ii)]

72251920
72261920
72091720
72091730
72091790

15.

आईएस 2062
: 2011

तj बेिVलत मeयम
तथा उg तTयता
अवसंरचना इ'पात।
नोट:-

यह

एमएम

से Tयून Uास

या

मोटाई

आदेश

और

6

72139090

72082730

72085230

72139990

72082740

72085240

72149990

72082790

72085290

72161000

72083610

72085310

72162100

72083620

72085320

72162200

72083630

72085330

72163100

72083640

72085340

72163200

72083690

72085390

72163300

72083710

72089000

72164000

72083720

72083930

72165000

72083730

72083940

72111300

72083740

72083990

72111410

72083790

72085110

72111420

72083810

72085120

72111430

72083820

72085130

72111440

72083830

72085140

72111450

72083840

72085190

72111460

72083890

72085210

72111490

72083910

72085220

72119012

72083920

72085230

72119090

72083930

72085240

72139190

72083940

72085290

72139990

72083990

72085310

72149190

72085110

72085320

72149990

72085120

72085330

72082510

72085130

72085340

50

एमएम x 50 एमएम
x 6 एमएम से कम के

अवसंरचना)मक
शलाका और छड़ के
िलए लागू नहJ है।

त)काल
भाव से

<!-- page 5 -->

¹Hkkx IIµ[k.M 3(ii)º

16.

Hkkjr dk jkti=k % vlk/kj.k

कॉन5ट IरइनफोसAम=ट
के िलए माइVड 'टील
भाग 1 : 1982

72082520

72085140

72085390

72082690

72085190

72089000

72082710

72085210

72082720

72085220

आईएस 432 :

और

17.

5

72279090

72139990

72283019

72149190

72283029

72149990

72286099

मीिडयम

टेनसाइल 'टील बॉसA
तथा हाडA-\ॉन 'टील
वायर: पाटA 1 माइVड
'टील और मीिडयम
टेनसाइल 'टील बॉसA
कॉन5ट
आईएस 432 :
IरइनफोसAम=ट के िलए
भाग 2 : 1982
माइVड 'टील और
मीिडयम

72139190

त)काल
भाव से

टे नसाइल

'टील बॉसA तथा हाडA\ॉन 'टील वायर: पाटA
2
हाडA-\ॉन 'टील

72159090

721710

72299040

721790

72299059

72299031

72299090

त)काल
भाव से

72299033

वायर
18.

आईएस 513
(भाग 1) :
2016

कोVड Iरlूcड काबAन
'टील शीdस तथा
'Zीप भाग 1 कोVड
फोbमग और \ॉइंग
उmेCय (छठा संशोधन)

720915

72255010

720916

72255020

720917

72259900

720918

72269210

720925

72269220

720926

72269920

720927

72269930

720928

72269940

72099000

72269952

721123

72269990

त)काल
भाव से

72119090
19.

आईएस 513
(भाग 2) :
2016

कोVड Iरlूcड लो
काबAन 'टील शीdस
तथा 'Zीप भाग 2 हाई
टेनसाइल
और
ब#-

720915

72255010

720916

72255020

720917

72259900

त)काल
भाव से

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

चरण 'टील (छठा
संशोधन)

[PART II—SEC. 3(ii)]

720918

72269210

720925

72269220

720926

72269920

720927

72269930

720928

72269940

72099000

72269952

721123

72269990

72119090
20.
आईएस 1079

हॉट रोVड काबAन
'टील शीट, [लेट और
'Zीप

: 2017

720825

72089000

720826

72111300

720827

721114

720836

721119

720837

72119090

720838

722530

720839

722540

720840

72259900

720852

722691

720853

722699

त)काल
भाव से

720854
21.

आईएस 1875
: 1992

फोbजग के िलए काबAन
'टील िबलेdस, लूoस,
'लै स और बॉसA

72071120

72149190

72071190

72149990

72071220

72159090

72071290

72249040

720719

72249091

72072010

72249099

72072090

72283029

त)काल
भाव से

72286099
22.

आईएस 2879
: 1998

मेटल आकA वैpVडग
इले`Zोqस के िलए
माइVड 'टील

72061090

72139910

72071190

72149990

72071290

72241000

72071920

72249091

72071990

72249099

त)काल
भाव से

<!-- page 7 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k
72132010

7
72279090

72139110
23.

आईएस 3502

'टील चेकडA [लेdस

: 2009

24.

आईएस 5872
: 1990

कोVड रोVड 'टील
'Zी[स
(बॉ`स
'टै्pपsस)

72081000

72259900

720840

72269130

721114

72269190

721190

72269910

72254019

72269990

721123

72262030

721129

72269210

721220

72269930

721230

72269952

721240

72269990

त)काल
भाव से

त)काल
भाव से

721250
25.
आईएस 5986
: 2017

फोbमग और _ल=pगग
उmेCय के िलए हॉट
रोVड 'टील शीट, [लेट
और 'Zीप

720825

720840

72111300

72254019

720826

720851

721114

72254020

720827

720852

721119

72254030

720836

720853

72119012

72259900

720837

720854

72119090

722691

720838

72089000

72253090

722699

720839
26.
आईएस 6240
: 2008

लो
ेशर
िल@t@फएबल गैस
िसिलिTडसA
के
िविनमाAण के िलए हॉट
रोVड 'टील [लेट (6
एमएम तक) शीट और

'Zीप

त)काल
भाव से

72254013

720825

720854

722540

720826

72089000

72259900

720827

721114

722691

720837

721119

722699

720838

72119090

720839

72253090

त)काल
भाव से

720852
720853
27.
आईएस 7283
: 1992

uाईट बॉसA के उ)पादन 721320
के िलए हॉट रोVड 721391
बॉसA और इंजीिनयvरग
अनुयोग के िलए 721399
मशीTड पाटA
72143000

72279090

72286091

72283021

72286092

72283022

72286093

72283023

72286099

त)काल
भाव से

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY
721491

[PART II—SEC. 3(ii)]

72283029

721499
72159090
28.
आईएस 7887
: 1992

29.

सामाTय इंजीिनयvरग
उmेCय के िलए
माइVड 'टील वायर

त)काल
भाव से

72139190
72139990
72279090

रॉड

वेिVडड wू स और
पाइप के िलए हॉट
आईएस 10748:
रोVड 'टील 'Zीप
2004

720825

721114

720826

721119

720827

72119090

720836

72253090

720837

72259900

720838

722691

720839

722699

त)काल
भाव से

72089000
30.
आईएस
11513 :

कोVड रोpलग उmेCय
के िलए हॉट रोVड
काबAन 'टील 'Zीप

2017

31.

720825

720837

720826

720838

720827

720839

720836

72089000

721114

72259900

721119

वेिVडड wू स और
पाईप के िलए हॉट
आईएस 15647
रोVड 'टील नैरो िवqद
: 2006
'Zीप

721190907
72253090

721114

722691

त)काल
भाव से

722699

त)काल
भाव से

721119
72119090

32.

आईएस 7904 :
1995*
(यह मानक 18

हाई काबAन 'टील
वायर रॉqस –
िविनद]शन

नवंबर 2018 के

बाद समाj हो
जाएगा।)

33.

आईएस 7904 :
2017

34.

हाई काबAन 'टील
वायर रॉqस –
िविनद]शन
गेलवनाइcड

'टील

कपड़ा उhोग के िलए काडA `लोpथग 20
वॉयर के िविनमाAण हेतु X xेड के अनुRप िसतंबर
72139990
उ)पाद (काबAन: 0.6-0.85% और 2018
मKगनीज 0.6-0.9%)
(ख) उपरो (क) के अलावा अTय उ)पाद के 20 जुलाई

72139190

(क)

िलए
72139190
72139990

2018
18
नवंबर,
2018

72107000

त)काल

<!-- page 9 -->

¹Hkkx IIµ[k.M 3(ii)º
आईएस 14246
: 2013

Hkkjr dk jkti=k % vlk/kj.k

शीdस और tॉयVस
को िनरं तर पहले प=ट
@कया गया

9

भाव से

72124000
72259900
72109090

अVयूिमिनयम

35.
आईएस 15965
: 2012

36.

आईएस
280:2006

अलॉय

pजक

त)काल
भाव से

72107000

मेटािलक

72124000

कोIटड 'टील 'Zीप
और शीट् ([लेन) को
पहले प=ट @कया गया
सामाTय इंजीिनयvरग
उmेCय के िलए
माइVड 'टील वायर

72259900
72109090
18

721710

@दसंबर

721720

2018

721730
37.

आईएस 1835
: 1976

38.

आईएस 3975:
1999

39.

आईएस 4368:
1967

40.

आईएस 4454
(भाग 1) :
2001

रोप के िलए राउzड
'टील वायर

आईएस 4454
(भाग 2) :
2001

72179099

721720

72299033

72179091

72299040

तार को बंद करने हेतु
लो काबAन गेVवेनाइcड
'टील वायसA, फॉमडA
वायसA और टे[स।
सामाTय इंजीिनयvरग
उmेCय हेतु फॉbजग के
िलए अलॉय 'टील
िबलेdस, लूoस और
'लै स।
मेकेिनकल p'sस हेतु 721710
'टील वायसA, भाग 1 721720
कोVड
\ाउन
अनअलॉयड 'टील 721730
वायर।

41.

721710

मेकेिनकल p'sस हेतु
'टील वायर, भाग 2:
ऑयल हाड]न और
टेपडA 'टील वायर।

72179099

18

@दसंबर
2018

18

721720

@दसंबर

721790

2018

72179090
18

72249091

@दसंबर

72249099

2018

72292000

72299032

72299011

72299033

72299012

72299040

72299016

72299090

721710
72179091

18

@दसंबर
2018

18

@दसंबर
2018

72179099
72299034

42.

आईएस 4824:
2006

टायर हेतु बीड वायर।

721710
721730
72179099

18

@दसंबर
2018

<!-- page 10 -->

10
43.

THE GAZETTE OF INDIA : EXTRAORDINARY
आईएस
11169
(भाग 1) :
1984

कोVड
शीषA/कोVड
िन~कासन अनुयोग
हेतु 'टीVस भाग-1
राउट काबAन और लो
अलॉय 'टीVस

[PART II—SEC. 3(ii)]

72132020

721710

72286012

72139120

72279040

72286099

72139920

72279090

18

@दसंबर
2018

72299040

72283020
72141080

72299090
72284000

72149990
44.

आईएस
11587 :
1986

अवसंरचना)मक
मौसम
ितरोधक
'टील।

7208

72254019

72269940

7209

72254020

72269951

7211

72254030

18

@दसंबर
2018

72269952

722550
7212

72269990
722691

72141090
72149190

722692
72269910

72149990

72269920

7216

72269930

72279090
722870

72253090
45.

आईएस
15103 :

अि ितरोधक 'टील
– िविनद]शन।

2002

7208

72253090

72269920

7209

72254019

72269930

7211

72254020

18

@दसंबर
2018

72269940

72254030
7212

72269951
722550

72141090
72149190
72149990

722691
722692
72269910

7216
46.

आईएस
15914 :
2011

वेिVडड गैस िसलेzडर
के िविनमाAण हेतु उg
टेनसाइल तीता वाले
_लैट रोVड 'टील [लेट

72269990
72279090
722870

720825

720853

722691

720826

720854

72269910

720827

(6 एमएम तक), शीट

और ि'Z[स।

72269952

7209

18

@दसंबर
2018

72269920

7211
72269930

720836
72253090
720837
720838

72254019
72254020

72269940
72269951

720839

72254030

72269952

720851

722550

72269990

720852
47.

आईएस

हॉट

िडप

72106100

18

<!-- page 11 -->

¹Hkkx IIµ[k.M 3(ii)º
15961 :
2012

48.

आईएस
15962 :
2012

Hkkjr dk jkti=k % vlk/kj.k

11

अVयूिमिनयम – pजक

72125090

अलॉय

72259900

2018

मेटैिलक

कोIटड 'टील ि'Zप
और शीट् ([लेन)।
सुदढ़
ृ

भूकंपीय

ितरोधक के साथ
अवसंरचना के िनमाAण
हेतु 'Z`चरल 'टील।

@दसंबर

72269990

720840

72119090

72269120

720851

72141090

72269130

720852

18

@दसंबर
2018

72149190

72269190

72149990
721113

722870
72255030

721114
7216

72259900
72269110

721119
49.

आईएस 6527
: 1995

50.

आईएस 6528

'टेनलेस 'टील वायर

आईएस 6603
: 2001

18

72230091

18

@दसंबर
2018

'टेनलेस 'टील वायर

: 1995

51.

722100

रॉड

'टेनलेस 'टील बार
और _लैट

72230092

@दसंबर

72230099

2018

722211

18

722219

@दसंबर

722220

2018

722230

52.

आईएस 5522
: 2014

53.

आईएस 6911
: 2017

54.

बतAन हेतु 'टेनलेस
'टील शीdस और
'Zीप - िविनद]शन
'टेनलेस 'टील [लेट,
शीट और 'Zीप –
िविनद]शन

आईएस
15997 :
2012

बतAन और रसोई म=
उपयोग हेतु लो िनकेल

ऑ'टेिनIटक 'टेनलेस
'टील, शीट और 'Zीप

72191300

721933

72199090

72191400

721934

72201290

721923

721935

72202090

721924

72199012

72209090

721932

72199013

7219

7220

-

72191300

72192490

72193590

72191400

72193220

72199012

72192320

72193290

72199013

72192390

72193320

72199090

72192421

72193390

72201290

72192422

72193420

72202090

72192423

72193490

72209090

72192429

72193520
[फा. सं.

त)काल
भाव से

त)काल
भाव से
त)काल
भाव से

1(5)/2016-टीडी]

िचका चौधरी गोिवल,, संयु सिचव

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF STEEL
ORDER
New Delhi, the 13th August, 2018

S.O. 3966(E).— In exercise of the powers conferred by section 16 of the Bureau of Indian Standards Act,
2016 (11 of 2016) and in the supersession of the Steel and Steel Products (Quality Control) Order, 2018 and Stainless
Steel Product (Quality Control) Order, 2018, except as respects things done or omitted to be done before such
supersession, the Central Government is of the opinion that it is necessary or expedient so to do in the public interest,
after consulting the Bureau hereby makes the following order, namely:1.

Short title, commencement and application. – (1) This order may be called the Steel and Steel Products (Quality
Control) Order, 2018.
(2) It shall come into force on the date of its publication in the Official Gazette.
(3) It shall apply to steel and steel products specified in column (3) of the table, but
to such products meant for export.

nothing herein shall apply

2.

Conformity to standards.- Every product specified in column (3) of the table shall conform to the corresponding
Indian Standards specified in column (2) of the said table with effect from the dates specified in column (5)
thereof.

3.

Compulsory use of Standard Mark.- Every Steel and Steel products specified in this order shall bear the
Standard Mark under a license from the Bureau.

4.

Certification and enforcement authority.- The Bureau shall be the certifying and enforcing authority in respect
of the steel and steel products specified in this order.

5.

Penalty for Contravention. - Any person who contravenes any of the provisions of this Order shall be punishable
under Section 29 of the Act.

6. Date of effect of amendment or revision in Indian Standards. - When any amendment or revision is made by the
Bureau to any of the Indian Standards specified in the table, such amendment or revision shall apply to this order
with effect from the date notified by the Bureau in this behalf.
TABLE
Sl.
No.
(1)

Indian
Standards
(2)

1.

IS 1785 (Part1) : 1983

2.

IS 1785 (Part2) : 1983

3.

IS 6003 : 2010

4.

5.

IS 6006 : 2014

IS 13620 : 1993

Title of Indian
Standards
(3)
Specification
for
plain
Hard-drawn
Steel Wire For Prestressed
Concrete;
Part 1 Cold - Drawn
Stress relieved Wire.
Plain
Hard-drawn
Steel Wire for Prestressed
Concrete;
Part 2 as Drawn
Wire.
Indented Wire for
Pre-stressed Concrete
- Specification
Uncoated
Stress
Relieved Strand For
Pre-stressed Concrete
– Specification.
Fusion

Bonded

ITC(HS)
(4)

Date of
implementation
(5)
With immediate
effect.

72171010
72179091
72179099

72171010
72179091
72179099
72171010
72179091
72179099
73121030

72142090

With immediate
effect.

With immediate
effect.
With immediate
effect.

With immediate

<!-- page 13 -->

¹Hkkx IIµ[k.M 3(ii)º

IS 14268 : 1995
6.

7.

8.

9.

10.

IS 277 : 2003

IS 2002 : 2009

IS 2041 : 2009

IS 2830 : 2012

IS 1786 : 2008

Hkkjr dk jkti=k % vlk/kj.k
Epoxy
Coated
Reinforcing Bars –
Specification.
Uncoated
Stress
Relieved
Low
Relaxation
Sevenwire (ply) Strand for
Pre-stressed Concrete
– Specification.
Galvanized
Steel
Sheets (Plain and
Corrugated)
–
Specification.
Steel
plates
for
pressure vessels for
intermediate and high
temperature service
including boilers.
Steel
Plates
for
Pressure
Vessels
Used at Moderate
and
Low
Temperature
–
Specification.
Carbon steel cast
billet ingots, billets,
blooms and slabs for
re-rolling into steel
for general structural
purposes
–
Specification.
High
strength
deformed steel bars
and
wires
for
concrete
reinforcementSpecification.

11.

IS 648 : 2006
12.

IS 3024 : 2015
13.
14.

Note: This order is
not applicable for
High
strength
deformed steel bars
and wires of sizes
less than 8 mm.
Cold rolled nonoriented
electrical
steel sheet and strip Fully processed typeSpecification.
Grain
Oriented
Electrical Steel Sheet
and Strip
Cold Rolled Non-

13

72159090

effect.

With immediate
effect.
73121030

72104100
72104900
72123010
72123090
72085110
72085120
72085210
72085220
72111300

With immediate
effect.

72111420
72111490
72119011
72119090

72085110
72085120
72085210
72085220

72111300
72111420
72111490
72119090

72061090
72071190
72071290
72071920
72071990

With immediate
effect.

With immediate
effect.

With immediate
effect.

With immediate
effect.

72131090
72142090

72251920
72261920

72251100
72261100

With immediate
effect.

With immediate
effect.
With immediate

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY
IS 15391 : 2003

15.

IS 2062 : 2011

Oriented Electrical
Steel Sheet and Strip
–
Semi-Processed
Type- Specification.
Hot rolled medium
and high tensile
structural steel.
Note: This order is
not applicable for
bars and rods of
diameter or thickness
less
than 6 mm and
structurals below
50 mm x 50 mm x 6
mm).

16.

17.

IS 432 : Part 1 :
1982

IS 432 : Part 2 :
1982

Mild
Steel
and
Medium Tensile Steel
Bars
and
Hard–
Drawn Steel Wire for
Concrete
Reinforcement: Part
1 Mild steel and
medium tensile steel
bars.
Mild
steel
and
Medium Tensile steel
bars
and
Hard–
Drawn Steel Wire for
Concrete
Reinforcement: Part
2 Hard-Drawn Steel

[PART II—SEC. 3(ii)]

72251920
72261920
72091720
72091730
72091790
72139090
72139990
72149990
72161000
72162100
72162200
72163100
72163200
72163300
72164000
72165000
72111300
72111410
72111420
72111430
72111440
72111450
72111460
72111490
72119012
72119090
72139190
72139990
72149190
72149990
72082510
72082520
72082690
72082710
72082720

720827 30
72082740
72082790
72083610
72083620
72083630
72083640
72083690
72083710
72083720
72083730
72083740
72083790
72083810
72083820
72083830
72083840
72083890
72083910
72083920
72083930
72083940
72083990
72085110
72085120
72085130
72085140
72085190
72085210
72085220

effect.

72085230
72085240
72085290
72085310
72085320
72085330
72085340
72085390
72089000
72083930
72083940
72083990
72085110
72085120
72085130
72085140
72085190
72085210
72085220
72085230
72085240
72085290
72085310
72085320
72085330
72085340
72085390
72089000

72139190
72139990
72149190
72149990
72159090

72279090
72283019
72283029
72286099

721710
721790
72299031
72299033

72299040
72299059
72299 090

With immediate
effect.

With immediate
effect.

With immediate
effect.

<!-- page 15 -->

¹Hkkx IIµ[k.M 3(ii)º
18.

IS 513 (Part 1)
: 2016

19..

IS 513 (Part 2)
: 2016

20.
IS 1079 : 2017

Hkkjr dk jkti=k % vlk/kj.k
Wire.
Cold reduced carbon
steel sheets and strip
Part 1 Cold Forming
and Drawing Purpose
(Sixth Revision).

Cold reduced low
carbon steel sheets
and strip Part 2 High
Tensile and Multiphase Steel (Sixth
Revision).

Hot Rolled Carbon
Steel Sheet, Plate and
Strip.

21.

IS 1875 : 1992

Carbon steel billets,
blooms, slabs and
bars for forgings.

22.

IS 2879 : 1998

Mild steel for metal
arc
welding
electrodes.

23.

IS 3502 : 2009

Steel
Plates.

Chequered

720915
720916
720917
720918
720925
720926
720927
720928
72099000
721123
72119090
720915
720916
720917
720918
720925
720926
720927
720928
72099000
721123
72119090
720825
720826
720827
720836
720837
720838
720839
720840
720852
720853
720854
72071120
72071190
72071220
72071290
720719
72072010
72072090
72061090
72071190
72071290
72071920
72071990
72132010
72139110
72081000
720840
721114
721190

15
72255010
72255020
72259900
72269210
72269220
72269920
72269930
72269940
72269952
72269990

With immediate
effect.

72255010
72255020
72259900
72269210
72269220
72269920
72269930
72269940
72269952
72269990

With immediate
effect.

72089000
72111300
721114
721119
72119090
722530
722540
72259900
722691
722699

With immediate
effect.

72149190
72149990
72159090
72249040
72249091
72249099
72283029
72286099
72139910
72149990
72241000
72249091
72249099
72279090

With
immediate effect.

72259900
72269130
72269190
72269910

With immediate
effect.

With immediate
effect.

<!-- page 16 -->

16

24.

THE GAZETTE OF INDIA : EXTRAORDINARY

IS 5872 : 1990

25.
IS 5986 : 2017

26.
IS 6240 : 2008

27.
IS 7283 : 1992

28.

Cold Rolled
Strips
Strappings).

Steel
(Box

Hot Rolled Steel
Sheet, Plate and Strip
for Forming and
Flanging purposes.

Hot Rolled Steel
Plate (up to 6 mm)
Sheet and Strip for
the Manufacture of
Low
Pressure
Liquefiable
Gas
Cylinders.
Hot Rolled bars for
production of bright
bars and machined
parts for engineering
applications.

72254019
721123
721129
721220
721230
721240
721250
720825
720840
720826
720851
720827
720852
720836
720853
720837
720854
720838
72089000
720839
720825
720854
720826
72089000
720827
721114
720837
721119
720838
72119090
720839
72253090
720852
720853
721320
72279090
721391
72283021
721399
72283022
72143000
72283023
721491
72283029
721499
72159090

IS 7887 : 1992

Mild steel wire rods
for
general
engineering purposes.

72139190
72139990
72279090

IS 10748: 2004

Hot Rolled Steel
Strip for Welded
Tubes and Pipes.

IS 11513 : 2017

Hot Rolled Carbon
Steel Strip For Cold
Rolling Purposes.

720825
720826
720827
720836
720837
720838
720839
72089000
720825
720837
720826
720838
720827
720839
720836
72089000

29.

30.

31.
IS 15647 : 2006

32.
IS 7904 : 1995*

Hot
rolled
steel
narrow width strip
for welded tubes and
pipes.
High Carbon Steel
Wire
Rods
–

[PART II—SEC. 3(ii)]
72269990
72262030
72269210
72269930
72269952
72269990

72111300
721114
721119
72119012
72119090
72253090
72254013
722540
72259900
722691
722699

72254019 With immediate
72254020
effect.
72254030
72259900
722691
722699

72286091
72286092
72286093
72286099

With immediate
effect.

With immediate
effect.

With immediate
effect.

721114
721119
72119090
72253090
72259900
722691
722699
721114
721119
721190907
72253090

With immediate
effect.

72259900 With immediate
722691
effect.
722699

721114
721119
72119090
72139190
72139990

With immediate
effect.

(a) Products conforming to grade X
(Carbon: 0.6 – 0.85% &

With immediate
effect.

20th September,

<!-- page 17 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

(*This standard Specification.
shall cease to
exist after 18th
November, 2918)

33.
IS 7904 : 2017
34.
IS 14246 : 2013

35.
IS 15965 : 2012

36.

IS 280:2006

37.

IS 1835 : 1976

38.

IS 3975: 1999

39.

IS 4368: 1967

40.

IS 4454
(part 1) : 2001

41.

IS 4454
(Part 2) : 2001

42.

IS 4824: 2006

43.

IS 11169
(Part 1) : 1984

44.

IS 11587 : 1986

Manganese 0.6 – 0.9%) for
manufacturing of Card Clothing
wire for textile industry.
(b) For products other than at (a)
above;
72139190
72139990

High Carbon Steel
Wire
Rods
–
Specification.
Continuously
prepainted
galvanized
steel sheets and coils.
Pre–painted
aluminium zinc alloy
metallic coated steel
strip
and
sheet
(plain).
Mild steel wire for
General Engineering
purposes.
Round steel wire for
ropes.
Low
carbon
Galvanized
steel
wires, formed wires
and
Tapes
for
armouring of cables.
Alloy Steel billets,
blooms and slabs for
forging for general
engineering purposes.
Steel
wires
for
mechanical springs,
Part 1 cold drawn
unalloyed steel wire.

721710
721720
721730
72179099

72132020
72139120
72139920
72141080
72149990
7208

2018

20th July, 2018
18th November,
2018

72107000
72124000
72259900
72109090
72107000
72124000
72259900
72109090

With immediate
effect.

721710
721720
721730

18th December,
2018

721710
721720
72179091

Steel
wire
for
mechanical springs
Part 2: oil hardened
and tempered steel
wire.
Bead Wires for Tyres
.
Steels
for
Cold
Heading/Cold
extrusion application
Part-1
Wrought carbon and
low alloy steels.
Structural Weather

17

With immediate
effect.

72179099
72299033
72299040

18th December,
2018

721720
721790
72179090

18th December,
2018

72249091
72249099

18th December,
2018

72292000
72299011
72299012
72299016

72299032
72299033
72299040
72299090

18th December,
2018.

721710
72179091
72179099
72299034

18th December,
2018

721710
721730
72179099
721710
72279040
72279090
72283020
72284000

18th December,
2018

72254019

72286012
72286099
72299040
72299090

18th December,
2018

72269940

18th December,

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY
resistant steel .

45.

IS 15103 : 2002

46.

IS 15914 : 2011

Fire resistant steel –
Specification.

High
Tensile
Strength Flat Rolled
Steel Plate (Up To 6
mm), Sheet and Strip
for the Manufacture
of
Welded
Gas
Cylinder.

47.

IS 15961 : 2012

Hot Dip aluminium –
Zinc alloy metallic
coated steel strip and
sheet (plain).

48.

IS 15962 : 2012

Structural Steel for
Building
for
Structures
with
improved
seismic
Resistance.

49.

IS 6527: 1995

50.

IS 6528 :1995

Stainless Steel Wire
Rod.
Stainless Steel Wires.

51.

IS 6603 : 2001

IS 5522 : 2014

Stainless steel sheets
and strips for utensils
Specification

IS 6911: 2017

Stainless steel plate,
sheet and strip -

72254020
72254030
722550
722691
722692
72269910
72269920
72269930

72269951
72269952
72269990
72279090
722870

2018

72253090
72254019
72254020
72254030
722550
722691
722692
72269910

72269920
72269930
72269940
72269951
72269952
72269990
72279090
722870
722691
72269910
72269920
72269930
72269940
72269951
72269952
72269990

18th December,
2018

720853
720854
7209
7211
72253090
72254019
72254020
72254030
722550

720840
720851
720852
721113
721114
7216
721119

72119090
72141090
72149190
72149990
72255030
72259900
72269110

72269120
72269130
72269190
722870

72191300
72191400
721923
721924
721932
7219

18th December,
2018

18th December,
2018
18th December,
2018

722100
72230091
72230092
72230099
722211
722219
722220
722230
721933
721934
721935
72199012
72199013
7220

18th December,
2018

18th December,
2018

72106100
72125090
72259900
72269990

Stainless Steel Bars
and Flats.

52.

53.

7209
7211
7212
72141090
72149190
72149990
7216
72253090
7208
7209
7211
7212
72141090
72149190
72149990
7216
720825
720826
720827
720836
720837
720838
720839
720851
720852

[PART II—SEC. 3(ii)]

18th December,
2018

72199090
72201290
72202090
72209090
-

With immediate
effect

With immediate
effect

<!-- page 19 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

19

Specification
54.

IS 15997: 2012
Low Nickel
Austenitic Stainless
Steel Sheet and Strip
For Utensils and
Kitchen Appliances –
Specification

72191300
72191400
72192320
72192390
72192421
72192422
72192423
72192429

72192490
72193220
72193290
72193320
72193390
72193420
72193490
72193520

72193590
72199012
72199013
72199090
72201290
72202090
72209090

With immediate
effect

Explanation: For the purpose of this notification, “ITC (HS) Codes” means the Indian Trades Classification
(Harmonized System) codes specified in column (4) of the table. The codes are generic and indicative in nature
and the applicability of this order will be limited to steel and steel products covered in Indian Standards.
[F. No. 1(5)/2016-TD]
RUCHIKA CHAUDHRY GOVIL, Jt. Secy.

RAKESH
SUKUL
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

Digitally signed by
RAKESH SUKUL
Date: 2018.08.20
11:13:24 +05'30'
