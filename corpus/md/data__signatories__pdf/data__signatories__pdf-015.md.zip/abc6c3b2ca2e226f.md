---
doc_id: "abc6c3b2ca2e226f"
source_url: "https://socialjustice.gov.in/public/ckeditor/upload/85741739961005.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "Scheme Guidelines for 2024-25 (English)"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7e46223148fba7df"
---

<!-- page 1 -->

Guidelines for the
‘Scheme of Free Coaching for SCs, OBCs and
beneficiaries of PM CARES Children Scheme’
Applicable from 2024-25
1. Background
a. The empowerment of the weaker sections has been a priority area for the
Government since independence. A number of schemes and programmes are being
implemented for assisting them so as to enhance their skills and capabilities for
ensuring rapid economic development and integration in the national main stream.
b. A scheme for providing free coaching to students belonging to Scheduled Castes
(SCs) was started during the 6th Five Year Plan. Similar schemes were also being
implemented to provide free coaching to students belonging to Other Backward
Classes (OBCs) and Minorities. With a view to ensure effective implementation and
monitoring and to assist the students in a better manner, the separate coaching
schemes for SCs, OBCs and Minorities were amalgamated and a combined Scheme,
namely, 'Coaching and Allied Assistance for Weaker Sections' including Scheduled
Castes, Other Backward Classes and Minorities was introduced with effect from
September,2001.
c. After creation of a separate Ministry to handle matters relating to the Minorities viz
the Ministry of Minority Affairs, the Scheme underwent further revision in April 2007
for removing the Minorities component from the ambit of the scheme and to
accommodate other changes deemed necessary at that point of time. The last
revision of the Scheme came into effect in 2023-24.
2. Objective
The objective of the Scheme is to provide coaching of good quality for
economically disadvantaged Scheduled Castes (SCs), Other Backward Classes
(OBCs), and beneficiaries of PM CARES Children Scheme (included from 2024-25)
to enable them to appear in competitive examinations for obtaining appropriate
jobs in Public/Private Sector and/or for securing admission in reputed technical
and professional higher education Institution.
3. Courses for Coaching
The courses for which the Coaching will be imparted shall be as follows:
a. Group A and B examinations conducted by the Union Public Service
Commission(UPSC), the Staff Selection Commission (SSC) and the various Railway
Recruitment Boards (RRBs);

<!-- page 2 -->

b. Group A and B examinations conducted by the State Public Service Commissions;
c. Oﬃcers’ Grade examinations conducted by Banks, Insurance Companies and
Public Sector Undertakings (PSUs);
e. Premier Entrance Examinations for admission in (i) Engineering (e.g. IIT-JEE), (ii)
Medical (eg. NEET), (iii) Professional courses like Management (e.g. CAT) and Law
(e.g. CLAT),and (iv) Any other such disciplines as Ministry may decide from time
to time.
f. Eligibility tests/examinations like SAT, GRE, GMAT, IELTS and TOEFL.
g. Entrance examination tests for CPL courses/National Defence Academy and
Combined Defence Services.

4. Category-wise Ratio of Candidates
3500 students will be selected under this scheme annually. The detailed
bifurcation of these slots is in para 7(e) of Scheme Guidelines.
5. Eligibility criteria for students
A.

For students belonging to SCs and OBCs Category:
a. Students belonging to SCs and OBCs, having total family income of Rs. 8.00 lakh
or less per annum from all sources will be eligible for beneﬁts under the Scheme.
b. SCs/OBCs candidate belonging to a Minority community may apply under the
similar scheme(s) of Ministry of Minority Affairs, or the State Govts., as the case
may be.
c. Income Certificate: Income declaration of self-employed parents/guardian should
be in the form of a certificate issued by a Revenue Officer not below the rank of
Tehsildar. Employed parents/guardians are required to obtain income certificate
from their employer and submit consolidated certificate from Revenue Officer
including any other additional source of income.

B.

For beneficiaries of PM CARES Children Scheme:
All beneficiaries of the PM CARES Children Scheme who have a certificate (with
beneficiary ID) issued by the Central Government confirming their status as
beneficiaries are eligible.There will be no income or caste-related restrictions for
such beneficiaries to avail of the benefits under this scheme

<!-- page 3 -->

6.

Other Mandatory Conditions:
a. The student should have a valid Aadhar number and a bank account
seeded therewith, allotted to him/her. At the time of application, if the
student does not have Aadhar number, he/ she can submit his/her EID
number. However, the payment shall be released only after obtaining the
Aadhar Number and shall be disbursed to the Aadhar seeded bank
account of the student only.
b. For the competitive exams for which the qualifying exam is class XII,
beneﬁts under the scheme will be available to a candidate only if the
candidate has passed class XII or is studying in class XII as on the date of
receiving the beneﬁt under the scheme. Student will be required to
declare the marks obtained by him/her in class X in the application form.
Students having less than 50% marks in their class X exam, shall not be
considered under the scheme.
c. Further, in case of competitive exams for which the qualifying exam is
Under
Graduate level, only students/candidates having completed the Un
der Graduate level course or studying in the ﬁnal year of the Under
Graduate course concerned at the time of receiving the beneﬁt under the
scheme shall be eligible. Student will be required to declare the marks
obtained by him/her in class XII in the application form. Students having
less than 50% marks in their class XII exam, shall not be considered under
the scheme.
d. Beneﬁt under the Scheme can be availed by a particular student not more
than twice, irrespective of the number of chances he/she may be entitled
to take in a particular competitive examination and irrespective of the
number of stages in the exam. The student will be required to provide a
declaration that he/she has not taken benefit more than twice under the
Scheme or any other similar coaching scheme run by the Central or State
Government
e. The candidate shall be precluded from availing beneﬁt under any other
coaching scheme of the Centre or State Government and will be required
to provide a declaration to this effect. A list of beneﬁciaries availing the
scheme will also be uploaded by DAF on the website of the Ministry and
to avoid possibility of the candidate availing beneﬁts of similar
coaching scheme simultaneously or more than twice, the same shall be
shared with all the empanelled Central Universities in the scheme.

<!-- page 4 -->

7.

Implementation of the scheme:
a. Implementing Agency : The Scheme will be implemented by Dr. Ambedkar
Foundation (DAF) through Central Universities empanelled under the Scheme.
b. Empanelment of Central Universities : All Central Universities willing and
capable of undertaking coaching for the indicated courses may apply
online/offline in suitable format to DAF. DAF shall scrutinize all such applications
and based on their fulfilling the criteria fixed by the Ministry, shall put up
complete applications for consideration of the Selection Committee. However,
the already empanelled Central Universities under Dr. Ambedkar Centre of
Excellence (DACE) Scheme of DAF, which have been running the classes in 202223, shall not require to apply in this manner. Their MoU can be renewed byDr.
Ambedkar Foundation by incorporating suitable provisions as per amended
scheme. The coaching centres run by the Central Universities shall be called Dr.
Ambedkar Centre of Excellence (DACE).
c. Selection Committee : The proposal for empanelment of new Central
Universities which were earlier not the part of Dr. Ambedkar Centre of
Excellence (DACE) will be considered by a Selection Committee which shall
recommend these Universities for selection based on availability of physical and
academic infrastructure and other requirements having bearing on
implementation of the scheme. The Central Universities willing to provide
coaching will be finally selected by Dr. Ambedkar Foundation based on
recommendations of the Selection Committee. The composition of the Selection
Committee will be as under :
i.
ii.
iii.
iv.
v.

Joint Secretary, SCD-B, MSJE
Financial Advisor, MSJE
Joint Secretary, DoHE
Director, DAF
Director/DS (SCD-1), MSJE

-

Chairperson
Member
Member
Member
Convener

d. Signing of MoU :The Central Universities approved for empanelment and the
Central Universities which have been earlier part of DACE shall sign MoU with Dr.
Ambedkar Foundation indicating, among other things, the slots allocated, courses to
be offered with slots per course, fee to be charged per student, duration of the
course, date of commencement and conclusion of the course etc.
e. Seats per Central University: Seats allotted to each Central University will be as
under:

<!-- page 5 -->

A. Total of such students will not exceed 100 (excluding the beneficiaries of PM
Cares Scheme) and the ratio of SC:OBC students would be 70:30. The percentage
of SC students shall not be less than 70%. In case of non- availability of adequate
number of candidates in the SC category, Dr. Ambedkar Foundation can relax
this ratio. However, in no case, a less than 50% SC students shall be permitted.
Also under each category, 30% of the slots shall be reserved for female
candidates. In case suﬃcient numbers of female candidates are not available
under any category, male candidates from the same category shall be considered
by Dr. Ambedkar Foundation.
B. All willing/eligible beneficiaries of PM CARES Children Scheme would be admitted
by the Central University irrespective of crossing the 100 slots allotted.
For the purpose of viability, one Central University shall not have less than a total of
50 students.
f. Courses per Central University : Not more than 4 courses indicated in para 3 of
these guidelines can be assigned to one Central University. For each course not less
than 25 students per course shall be permitted.
g. Mode of selection of students : The Central University shall issue suitable
advertisements inviting willing and eligible students to apply for the coaching. No
oﬄine applications will be entertained by the Central University from the students.
Only online applications complete in all respects, shall be considered for assistance.
All the incomplete applications will be summarily rejected. However, the rejected
candidates will have the option to apply in the subsequent years of
selection.Beneficiaries of PM CARES Children Scheme will be exempted from selection
procedure and all such eligible candidates who apply will be given admission for
coaching by respective Central University.
h. Preparation of merit list for SCs and OBCs : The empanelled Central Universities
shall shortlist SC and OBC students to be imparted coaching in the course(s) allocated
to the Central Universities fulfilling the eligibility conditions indicated in para 5 of the
scheme and also falling in the merit list prepared by the Central University after
following a procedure established by the concerned University itself for screening the
eligible candidates. Such procedure shall be pre-informed to Dr. Ambedkar
Foundation. However, there will be no merit list for the beneficiaries of PM CARES
Children Scheme.
i. Duration of the course : The duration of the course shall be as per Annexure-A of
these guidelines.

<!-- page 6 -->

j. Attendance of students : The Central Universities shall ensure recording of
Aadhar based biometric attendance of the students and shall share the same with
DAF on a monthly basis with specific mention of the students absenting themselves
for more than four days in a month. If any student is absenting himself/herself
without acceptable reason like medical or household emergency, his/her candidature
for the scholarship shall be cancelled.
k. Admissible payments : (i) Course fee as detailed in Annex- A of these guidelines
(ii) Stipend @ Rs. 4000 per month for full duration of the course not exceeding 12
months (iii) Rs. 15,000 as incentive to the successful students for coaching for
interview for all the students clearing the mains stage of Central Civil Services / State
Civil Services Exams for Class 1 and Class 2 posts.
l. Mode of payment : All the admissible payments shall be released to the students
through DBT in their Aadhar enabled bank accounts. The fee and stipend shall be
released in two installments of 50% each of the admissible amount. The first
installment shall be released immediately at commencement of course and the
second installment will be released after conclusion of more than 75% of the course
duration. The students will be required to remit the portion to the University fee
immediately and in any case not exceeding 15 days, to the Central Universities where
they are receiving coaching.
m. Commencement of coaching : The Central Universities shall commence the
coaching for the indicated course from the date indicated in the MoU signed
between them and Dr. Ambedkar Foundation. The Central Universities shall allow the
eligible students to join the coaching irrespective of the fact that they have received
the first installment from Dr. Ambedkar Foundation or not.
n.Enrollment of other students by the Central Universities : The empanelled
Central Universities shall be free to enroll students for coaching beyond the allocated
slots subject to availability of adequate infrastructure These students may be from SC,
ST, OBC, General or any other category and may charge the fee as fixed by the
Central Universities and for this, these Central Universities do not need any
permission from the Ministry. However, they may intimate the DAF about enrollment
of such students for record purpose. Dr. Ambedkar Foundation shall not release any
funds for these additional students, if any, enrolled by these Central Universities.
o.Shifting of students from one Central University to other : If the number of
students enrolled in a particular empanelled Central University is less than 50 at the
preliminary examination stage or unsustainable at the mains stage, the students from
such entity may be shifted to other entities with the consent of both the entities, and
that of the student concerned, with the approval of Dr. Ambedkar Foundation.

<!-- page 7 -->

p.Forwarding of proposal for release of funds : After shortlisting the candidates,
the Central University shall forward a list of all the shortlisted candidates with details
of their educational, caste, income, merit and bank related credentials to this Ministry
through DAF. Similarly, once 75% of the prescribed duration of the course is
completed, the Central Universities shall forward the details of all such students to
DAF who have been attending the classes regularly, with details of monthly
attendance sheet and shall forward the proposal for release of second installment of
balance fund. These proposals shall be considered in the Ministry for release of funds
in theCNA bank account of DAF. DAF shall release the amount in the account of
eligible students through DBT. The release of second installment of second and third
year shall depend upon successful fulfillment of performance criteria by the Central
University concerned, in the previous year, as prescribed in para 6(r) and Annexure-B
of these guidelines.
q. Responsibility of Central Universities about eligibility of students : While
forwarding the proposal for release of funds for first and second installments, the
Central Universities shall check the credentials relating to educational, caste, income,
Certificates of PM Cares beneficiaries etc. of the students coached by them from the
originals of such documents and certify that they are satisfied that these students are
genuine and eligible. If at any stage it is found out that any or all of such students
were not eligible on account of education, caste, annual family income etc., the
Central University coaching such student shall be solely responsible. No fee/stipend
shall be released in respect of such students and further if any payment has
previously released to such students before coming into knowledge of their
ineligibility for availing benefits under the scheme, the amount shall be recovered
from the University concerned with penalty, if any, decided by the Ministry.
r. Performance appraisal : At the time of seeking release of second installment in
the second year, the Central University shall require to forward the performance of
the students coached by it during the preceding year clearly indicating whether the
University has fulfilled the performance criteria fixed as prescribed in Annex-B of
these guidelines.
s. Renewal of MoU : The signed MoU shall be applicable for a period of three years
from the date of its signing. The empanelment can be renewed for a further period
of three years subject to fulfillment of performance criteria, willingness of the Central
University and other material factor(s).
8. Establishment of an Online Learning Management System :
DAF shall ensure to establish an Online Learning Management System for the purpose
of knowledge sharing as well as coordination among different Central
Universities. Such Management System shall also be utilised for verification of the

<!-- page 8 -->

faculty engaged, students enrolled, attendance, classes, mock tests, study material,
uploading of proposals etc. by the Central Universities. Further, this management
system will be utilised for uploading offline and online recorded lectures of the faculty
members for utilisation by other beneficiaries of the scheme enrolled in other Central
Universities through the mechanism of login and password. The expenditure to
establish the system may be borne from the 2% administrative changes available in
the scheme.
9.Performance, Monitoring and Coordination of the Scheme:
The Ministry shall monitor the implementation of the scheme in association with DAF
by keeping a regular watch and obtaining periodic reports from the Central
Universities. A physical verification of at least 25% of the students / central
universities chosen randomly through an algorithm shall be done annually by the
Ministry in association with DAF. The DAF shall prepare an Online Learning
Management System for the purpose monitoring and coordination of the scheme.
10. Administrative expenses :
2% of the funds available under the scheme shall be allocated as administrative
expenses and shall be used for creation of the learning management system, publicity
and awareness generation or any other activity requiredto run the scheme efficiently.
11. Furnishing of False Information
If

any

University/candidate

is

reported

to

havefurnished any false information/document having material bearing on the
release

of

funds

under

the

scheme

which

is

established as false, he/she/it will be liable for administrative and /or criminal
proceedings and action will be initiated for recovery of the amount released, with 15%
compound interest thereon.
*****

<!-- page 9 -->

Annexure-A
Maximum Fee and Minimum Duration under the Free Coaching Scheme for SC
and OBC students
S. Course
No.
1.
2.
3.
4.
5.
6.
7.

Civil Services
Exam by
UPSC/SPSCs
SSC/RRB
Banking/Insurance/
PSU/CLAT
JEE/NEET
IES
CAT /CMAT

GRE/GMAT/SAT/
IELTS/TOFEL
8. CA-CPT/GATE
9. CPL Courses
10. NDA/CDS

MaximumTotal Minimum and *maximum duration
Course Fee in of course in months
Rupees
Rs. 75,000/12 months
40,000
50,000

6 months - 9 months
6 months - 9 months

75,000

9months - 12 months

75,000
50,000
35,000

9months - 12 months
6months - 9 months
3 months - 6 months

75,000
30,000
20,000

9months - 12 months
6 months - 9 months
3 months - 4 months

*A minimum physical coaching of 16 hours per week will be mandatory for all the
above courses. Further, stipend shall be paid for the actual months of coaching or for
the maximum prescribed duration, whichever is less, even if the concerned Central
University has imparted coaching for a period beyond the maximum duration
prescribed.

<!-- page 10 -->

Annexure-B
Criteria for Review of Performance of the Empanelled University for Release of
Funds and Renewal of Empanelment Under Free Coaching Scheme
Sl.
N
o.

Competitive
Exam

1.

3.

Central Civil
Services and
State Civil
Services
SSC/RRB/Ban
king/IES/Insurance
/PSU
JEE

4.

GATE

5.

NEET

6.

CAT/CLAT

7.

CACPT

8.

GRE/GMAT/S
AT/TOEFL

Passing the test to secure admission in the At least 30% of the
CA course
students
imparted
training should pass the
test to join the course.
Scoring of at least 65 %of the total 10%
maximum marks for the exam

9.

NDA/CDS/CPL

Getting call for interview for these courses

2.

Success parameters

Criteria for release of
2nd installment of
funds and renewal for
Empanelment
Success rate as per cent
of batch size
Success in Prelims/Mains/final selection in 4%
any Central or State Civil Services

Final selection or even call for interview shall 16%
be considered for assessing success
Passing of Mains/final selection in B.Tech/BE 20%
course in case of JEE in any Engineering
college
with at least half of them crossing the final
cut off marks at which SC students were
selected in that year in any Govt. college.
Passing the test with required cut off to 10 %
secure admission in Post Graduate course in
any Govt college and/ or secure
employment in any PSU of the Central or
State Government through the exam
Admission in any Medical college in 14%
MBBS/BDS/B.Pharma course
with at least half of them crossing the final
cut off marks at which SC students were
selected in that year in any Govt. college.
Getting call for GD and interview from any 20%. At least 2% should
Govt. College for PGDM/MBA/L.L.B
be in Govt. college

10%
