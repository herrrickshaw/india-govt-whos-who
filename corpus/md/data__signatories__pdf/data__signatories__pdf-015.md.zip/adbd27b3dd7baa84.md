---
doc_id: "adbd27b3dd7baa84"
source_url: "https://powermin.gov.in/static/uploads/2025/07/d80f111249f6728d49b588c3494fb9df.pdf"
ministry: "Power"
title: "Electricity (Promoting Renewable Energy Through Green Energy Open Access) (Second Amendment) Rules, 2023"
date: "2023-03-23"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "dc3677e3aebb56a1"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-24052023-246016
xxxGIDHxxx
CG-DL-E-24052023-246016
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 309]
No. 309]

नई दिल्ली, मंगलिार, मई 23, 2023/ज्येष्ि 2, 1945
NEW DELHI, TUESDAY, MAY 23, 2023/JYAISHTHA 2, 1945

जिद्युत मंत्रालय
अजधसूचना
नई दिल्ली, 23 मई, 2023

सा.का.जन. 381(अ).—कें द्रीय सरकार, जिद्युत अजधजनयम, 2003 (2003 का 36) की धारा 176 की उप-धारा
(2) के खंड (य) के साथ पठित उप-धारा (1) द्वारा प्रित्त िजियों का प्रयोग करते हुए, जिद्युत (हठरत ऊिाा खुली पहुंच के
माध्यम से निीकरणीय ऊिाा का संिधान) जनयम, 2022 का, और संिोधन करने के जलए जनम्नजलजखत जनयम बनाती है,
अथाात:्
1. (1) इन जनयमों का संजिप्त नाम जिद्युत (हठरत ऊिाा खुली पहुंच के माध्यम से निीकरणीय ऊिाा का संिधान) (िूसरा
संिोधन) जनयम, 2023 है।
(2) ये रािपत्र में उनके प्रकािन की तारीख से प्रिृत्त होंगे।
2. जिद्युत (हठरत ऊिाा खुली पहुंच के माध्यम से निीकरणीय ऊिाा का संिधान) जनयम, 2022 (जिसे इसमें इसके पश्चात
उि जनयम कहा गया है) के , जनयम 2के , उप-जनयम (1) में, खंड (ख) के स्ट्थान पर,जनम्नजलजखत खंड रखा िाएगा,
अथाात:् —
(ख) "इकाई" से,कै जटिि उपभोिाओं के जसिाय, कोई ऐसा उपभोिा अजभप्रेत है जिसकी अनुबंजधत मांग या स्ट्िीकृ त भार
दकसी जितरण अनुज्ञजप्तधारी के एक ही जिद्युत खंड में जस्ट्थत ससंगल कनेक्िन के माध्यम से सौ दकलोिाि या उससे अजधक
है या बहुजिध कनेक्िनों के माध्यम से सौ दकलोिाि या उससे अजधक हैैः
3248 GI/2023

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

परं तु कै जटिि उपभोिाओं के मामले में कोई भार सीमा नहीं होगी;
3.उि जनयम के , जनयम 5के , उप जनयम (2) में, पहले परं तुक के स्ट्थान पर, जनम्नजलजखत परं तक
ु रखा िाएगा, अथाातैः"परं तु के िल िही उपभोिा जिनकीअनुबंजधत मांग या स्ट्िीकृ त भार दकसी जितरण अनुज्ञजप्तधारी के एक हीजिद्युतखंड में
जस्ट्थत ससंगल कनेक्िन के माध्यम से सौ दकलोिाि या उससे अजधक है या बहुजिधकनेक्िनों के माध्यम सेसौ दकलोिाि या
उससे अजधक है, िे हठरत ऊिाा खुली पहुुँच के माध्यम से जिद्युत लेने के पात्र होंगे तथाहठरत ऊिाा खुली पहुुँचके अधीन
जिद्युत लेने िाले कै जटिि उपभोिाओं के जलए जिद्युत आपूर्ता की कोई सीमा नहीं होगी:"
4.उि जनयम के , जनयम 9 के , उप जनयम (2) में, चौथे परं तुक के स्ट्थान पर, जनम्नजलजखत परं तक
ु रखा िाएगा, अथाातैः
“परं तु यह भी दक दिसंबर, 2032तक आरं भ की िा चुकी अपतिीय पिन पठरयोिनाओं से उत्पादित और खुली पहुुँच
उपभोिा को आपूर्ता की गई जिद्युत के मामले में अजतठरि अजधभार लागू नहीं होगा।”
[फा. सं. 23/09/2021-आरएंडआर]
पीयूष ससंह, संयि
ु सजचि,
ठिटपणैः मूल जनयम भारत के रािपत्र की संख्यासा.का.जन. 418 (अ), तारीख 6 िून, 2022 द्वारा प्रकाजित दकए गए थेऔर
अंजतम संिोधन अजधसूचना संख्या सा.का.जन. 59 (अ), तारीख 27 िनिरी, 2023 द्वारा दकया गया था।
MINISTRY OF POWER
NOTIFICATION
New Delhi, the 23rd May, 2023
G.S.R. 381(E).—In exercise of the powers conferred by sub-section (1) read with clause (z) of sub-section
(2) of section 176 of the Electricity Act, 2003 (36 of 2003), the Central Government hereby makes the following rules
further to amend the Electricity (Promoting Renewable Energy Through Green Energy Open Access) Rules, 2022,
namely: —
1. (1) These rules may be called the Electricity (Promoting Renewable Energy Through Green Energy Open Access)
(Second Amendment) Rules, 2023.
(2) They shall come into force on the date of their publication in the Official Gazette.
2.

In the Electricity (Promoting Renewable Energy Through Green Energy Open Access) Rules, 2022 (hereinafter

referred to as the said Rules), in rule 2, in sub-rule (1), for the clause (b), the following clause shall be substituted,
namely: —
(b) “entity” means any consumer who has contracted demand or sanctioned load of Hundred kW or more either
through single connection or through multiple connections aggregating Hundred kW or more located in same
electricity division of a distribution licensee, except for captive consumers:
Provided that in case of captive consumers, there shall not be any load limitation;
3.

In the said Rules, in rule 5, in sub-rule (2), for the first proviso, the following proviso shall be substituted,

namely:—
“Provided that only consumers who have contracted demand or sanctioned load of Hundred kW or more, either
through single connection or through multiple connections aggregating HundredkW or more located in same
electricity division of a distribution licensee, shall be eligible to take power through Green Energy Open Access and
there shall be no limit of supply of power for the captive consumers taking power under Green Energy Open Access:”

<!-- page 3 -->

[भाग II—खण्ड 3(i)]
4.

भारत का रािपत्र : असाधारण

3

In the said Rules, in rule 9, in sub-rule (2), for fourth proviso, the following proviso shall be substituted,

namely: —
“Provided also that additional surcharge shall not be applicable in case electricity produced from offshore wind
projects, which are commissioned upto December, 2032 and supplied to the Open Access Consumers.”
[F. No. 23/09/2021-R&R]
PIYUSH SINGH, Jt. Secy.

Note: The Principal Rules were published in the Gazette of India, vide number G.S.R. 418 (E), dated 6th June, 2022
and was last amended vide notification number G.S.R. 59 (E), dated 27 th January, 2023.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. MANOJ
VERMA
Digitally signed by MANOJ
KUMAR VERMA
Date: 2023.05.24 14:19:04 +05'30'
