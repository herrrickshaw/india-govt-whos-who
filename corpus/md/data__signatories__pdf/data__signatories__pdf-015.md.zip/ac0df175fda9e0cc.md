---
doc_id: "ac0df175fda9e0cc"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/494057796e9553bbda79b058419b49da.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification 17-07-2007"
date: "2025-07-02"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4323f9398b58b0fe"
---

<!-- page 1 -->

REGD. NO. D. L.-33004/99

fae i° qi-33004/99

JRd a Isi4i
@ke Gazette of 3ndia
3T4IE4RUT
EXTRAORDINARY
14TT II-@vg 3 -34-qvg (ii)
PART II-Section 3
S ub-section (ii)
if4et a yaifeia
PUBLISHED BY AUTHORITY
• 874]
No. 874]

fee-ft, naat, # 17, 2007/3141e 26, 1929
NEW DELHI, TUESDAY, JULY 17, 2007/ASADHA 26, 1929
aifu-q alt sen atq
( iilfra, iifa six waix fa«)

( PAM 31447)
anagr
" f<eeit, 16 erE, 2007
a,3T, 1169( 37).-9sJ4 4nit, 3dim (faana silt
faf1444) if4fa44, 1951 (1951 165) 41 4d 18 6Id
y<a vifaaui' qi yam ad g, "Plue faqavi an2ei, 2004
umua a fag fanfafaa Rei it #, ruia :
1 . (1) 5a met 4) ieifue fiqai (uua) anti,
2007 el @ I
(2) g um4a # sue y4iRiH I aiia d 336
gm I
2.

fue fadavi r2i, 2004 a1 14al A ,­

(1) i afue fafmqianeii a1 fae a m sit
sraftefa e qafua 4« 4 i, 4 i. 77 six
sud uafua yfafeqi yard fimiiaa
rei rum , arfa :
"78 Had sit fai4a gy a1ea yigaz feftas,
au fada, uwanu ism, Ee m<aa,
qi ya: w4 "I
[I • 4(2)/2007-4MM]
H. H. 44I«, 4«I wfqa

fequr : Hi sing?i 14Rd Ua9a N d. 1.311. 1105(37),
diia 11 3Maag7, 2004ded 34if*la fa,qi 141
n x 4Ra ua4a 4 yeifta f<aie 19 f4art,
i.311. 1371(31) gRI I< �
2005 �
qvilf4a f44i 141 41 I
3176 G1/2007

Tei u.

MINISTRY OF COMMERCE AND INDUSTRY
(Department of Industrial Policy and Promotion)
(PAPER SECTION)
ORDER
New Delhi, the 16th July, 2007
S.O. 1 169(E).-In exercise of the powers conferred
by Section 18 G of the Industries (Development and
Regulation) Act, 1951 (65 of 1951), the Central Government
hereby makes the following Order to amend the Newsprint
Control Order, 2004, namely :i
l. (]) This order may be called the Newsprint
Control (Amendment) Order, 2007.
(2) It shall come into force on :he date of its
' publication in the Official Gazette.
2. In the Newsprint Control Order, 2004, in the
Schedule,(1) in item 4 relating to the name of the Mill and
Location of the indigenous newsprint
manufacturers, afer S. No. 77 and the entries
relating thereto, the following shall be added,
namely :"78. M/s. Sri Vinayaka Paper Boards Private
Limited, Kanavaram Village, Rajanagaram
Mandal, East Godavari, in the State ofAndhra
Pradesh,"
[F. No. 4(2)/2007-Paper]
N. N. PRASAD, Jt. Secy.
Note : The principal order was published in the Gazette of
India vide No. S.O. 1105(E), dated 11th October,
2004, and subsequently amended vide Order
No. S.O. 1371(E), dated 19tn September, 2005
published in the Gazette of India.
s

Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
