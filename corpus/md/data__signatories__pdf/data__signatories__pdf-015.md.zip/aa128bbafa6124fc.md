---
doc_id: "aa128bbafa6124fc"
source_url: "https://www.texmin.gov.in/static/uploads/2025/07/7f6ed50782c85215b89b9d68e0b5f51c.pdf"
ministry: "Textiles (MoT)"
title: "Indias top ten import markets of textile and apparel products"
date: "2024-11-07"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8ef0f00326496147"
---

<!-- page 1 -->

India's Top Ten Import Markets of Textile & Apparel products
(including Handicraft)
S. No.
1
2
3
4
5
6
7
8
9
10

Country
CHINA P RP
BANGLADESH PR
USA
VIETNAM SOC REP
AUSTRALIA
BRAZIL
INDONESIA
THAILAND
MALAYSIA
UK
Rest of World
Total Textiles & Apparel Imports (including
Handicraft)

Import 2025-2026
Percentage Share
(in USD Million)
4333
964
701
529
477
407
331
225
204
187
1264

30.77%
8.52%
7.75%
5.21%
4.66%
4.10%
3.66%
2.50%
2.24%
2.08%
13.13%

9622

100%
Source: DGCI&S
