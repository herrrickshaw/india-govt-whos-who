---
doc_id: "abdfa684ff49cca2"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/408accb9b09429456d7281a297763a31.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification w.r.t Boilers Act, 2025"
date: "2025-06-30"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "1247388ebe88fcf7"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-01052025-262788
xxxGIDHxxx
CG-DL-E-01052025-262788
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं.

1900]

No. 1900]

नई दिल्ली, बुधवार, अप्रैल 30, 2025/वैिाख 10, 1947
NEW DELHI, WEDNESDAY, APRIL 30, 2025/VAISAKHA 10, 1947

वाजणज्य और उद्योग मंत्रालय
(उद्योग संवधधन और आंतररक व्यापार जवभाग)
अजधसूचना
नई दिल्ली, 30 अप्रैल, 2025
के न्द्रीय सरकार, बॉयलर अजधजनयम, 2025 (2025 का 12) की धारा 1 की उप-धारा (2)
द्वारा प्रित्त िजियों का प्रयोग करते हुए, 1 मई, 2025 को उस तारीख के रूप में जनयत करती है, जिसको उि अजधजनयम
के उपबंध लागू होंगे।
[फा.सं. पी-30012/1/2023-बॉयलर]
डॉ.संध्या भुल्लर, संयुि सजचव

2859 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF COMMERCE AND INDUSTRY
(DEPARTMENT FOR PROMOTION OF INDUSTRY AND INTERNAL TRADE)
NOTIFICATION
New Delhi, the 30th April, 2025
S.O. 1943(E).— In exercise of the powers conferred by sub-section (2) of section 1 of the

Boilers Act, 2025 (12 of 2025), the Central Government hereby appoints the 1st May, 2025 as the
date on which the provisions of the said Act shall come into force.

[F.No. P-30012/1/2023-Boiler]
Dr. SANDHYA BHULLAR, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
signed by GORAKHA NATH
and Published by the Controller of Publications, Delhi-110054. GORAKHA NATH YADAVA Digitally
YADAVA
Date: 2025.05.01 13:28:07 +05'30'
