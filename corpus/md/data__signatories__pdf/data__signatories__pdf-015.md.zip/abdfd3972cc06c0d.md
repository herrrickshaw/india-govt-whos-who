---
doc_id: "abdfd3972cc06c0d"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/9dd664c4438957d3178747f48bb48812.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment dated 16 June 2005 in para 6 of IP-I Registration Certificate"
date: "2005-06-16"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b3262e2035193f48"
---

<!-- page 1 -->

File No. 10-19/2005-BS-I
Government of India
Ministry of Communications & IT
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road ,
New Delhi – 110 001.
Dated : 16.06.2005.
To
All IP-I Registration holder
Subject: Amendment in para 6 of IP-I Registration Certificate.
The undersigned is directed to convey the approval of the
competent authority for amendment of para 6 of the IP-I Registration
Certificate as given below with immediate effect.
6.0
The Registered company can provide the infrastructure as stated above to any
licensee of Telegraph services Licensed under section 4 of the Indian Telegraph Act 1885.
The company shall, in no case, grant in any manner the infrastructure to any erstwhile
Licensee whose licence is either terminated or suspended or not in operation at given point
of time. In the event of any infrastructure allowed before hand, then the Registered
company shall be obliged to withdraw the grant of infrastructure and to disconnect or sever
connectivity immediately without loss of time and further, upon receipt of any reference
from the Licensor in this regard, disconnection shall be made effective within an hour of
receipt of such reference. On the question of disconnectivity the decision of the Director
General Telecom shall be final.
2.
Other terms and condition of the IP-I Registration Certificate shall remain
unchanged.

(Govind Singhal)
Director (BS-III)
Copy to :
1.
2.
3.
4.

Secretary ,TRAI
Sr. DDG(TEC)
DDG(LF)
All USAL/Cellular/NLD/ILD/ISP/IP-II/Licensee
