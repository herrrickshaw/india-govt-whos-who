---
doc_id: "adf8e9c8f7eed0bb"
source_url: "https://rural.gov.in/static/uploads/2024/05/OM_regarding_Disaster_Risk_Reduction_15022024_0-1.pdf"
ministry: "Rural Development (MoRD)"
title: "In-person Singapore Cooperation Programme on 'Introduction to Disaster Risk Reduction' from 8th July to 12th July, 2024 in Singapore"
date: "2024-05-06"
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "52af8b255beef2d5"
---

<!-- page 1 -->

F. No. U_1 1012/01/202OJC_part(1) (C. No. 377462)
Government of lndia
Ministry of Rural Developmenr
Department of Rural Development
(lC Section)
Krishr Bhawan, New Delhi

Dated 15.02.2024
OFFICE MEMORANMUM

subject: rn-person singapore cooperation programme on ,.rntroduction
to Disaster Risk
Reduction,, from 8th July to 12rh July, 2024 in Singapore _
reg,
The undersigned is directed to refer to the Training Circutar
No. 12l3lzo24-Bpc&I dated
from Department of Economic Affairs (copy encrosed) and
to say that the
Republic of singapore has invited nominations for rn-person
singapore cooperation programme
on "lntroduction to Disaster Risk Reduction" schedured to be
herd;rom arr,rrry to r ii; Lrii,'rooi',"
0_8 02 2024 received

Singapore.

2 The course is sponsored by Government of singapore and united Nations office for Disaster
Risk Reduction (UNDRR) under the singapore-UNDRR Joint
rraining programme, wifl provide
accommodation, rocar transport, medicar insurance and dairy
aflowance However, the nominated
candidate or his/ her nominating authority shafl have to bear
the cost of round trip air fare and
other travel related expenses
3.

The eligibre candidates shourd have the age of ress than 5g years
and compreted the Govt.
Service of 5 years Besides it may arso be taken into an account
that the participating officers
have performed two Foreign training programmes (FTps) of
duration of ress than one week in a

Calendar Year.

4. All lthe Divisionar Heads of DoRD are hereby requested to send the nominations (s) of the

suitable Mid to senior Lever officers invorved in disaster risk reduction policy
makinj and /or
national emergency pranning and management in the aftached proforma
(after dury p-rocessed
through administrative departments) as well as keeping in view of
the all eleqibilitv criteria ras
stated in the DEA training circurar), to enabre this Division before 2B,h Februa{,2oil
t" i"*"iJ
the same to Department of Economic Affairs, Ministry of Finance.

5. This issues with the approval of the Competent Authority.
Encl: as above.

N-4

q.r--.

(Latit Kumar )
Deputy Secretary to the Government of lndia
E-mail: talit.kr@nic.in

To,

All the Head of Programme Dtvisions, DoRD

Copy to:

. PPS to JS(|C).
2. Nlc is requested to upload the circular on the e-office portal of Department of Rural
1

Development.

<!-- page 2 -->

PDF.js viewer

7 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 3 -->

PDF.js viewer

8 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 4 -->

PDF.js viewer

9 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 5 -->

PDF.js viewer

10 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 6 -->

PDF.js viewer

11 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 7 -->

PDF.js viewer

12 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 8 -->

PDF.js viewer

13 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 9 -->

PDF.js viewer

14 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 10 -->

PDF.js viewer

15 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 11 -->

PDF.js viewer

16 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM

<!-- page 12 -->

PDF.js viewer

17 of 17

https://mord.eoffice.gov.in/efile/assets/pdfjs-2.16.105-dist/web/viewe...

15-Feb-24, 2:34 PM
