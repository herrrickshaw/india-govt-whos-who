---
doc_id: "a8cbc7d5b1f819ba"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/08/511a8133f2d5a511b4e6756173498abc.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Industrial Development Scheme Himalayan States (IDS), 2017 Himachal and Uttarakhand Notification Dated 23rd April 2018"
date: "2025-08-12"
pages: 13
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "5575e3bcdfe6ea32"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx I—[k.M 1
PART I—Section 1

izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 161]
No. 161]

ubZ fnYyh] cq/okj] ebZ 2] 2018@oS'kk[k 12] 1940
NEW DELHI, WEDNESDAY, MAY 2, 2018/VAISAKHA 12, 1940

वािणय और उोग मं ालय

औोिगक

(

नीित एवं

संवधन

िवभाग)
िवभाग)

अिधसूचना

नई दली, 23 अ ैल, 2018
भारत सरकार ारा औोगीकरण को बढ़ावा देने हेतु िहमाचल देश और
उ#राखंड रा'य) म* औोिगक इकाइय) के िलए औोिगक िवकास -क.म, 2017 क. घोषणा क. जाती है।
फा.

1.

सं. 2(2)/2018
2(2)/2018-एसपीएस.
एसपीएस.—

कम
कम शीषक :- इस -क.म को िहमाचल देश (एचपी) और उ#राखंड हेतु औोिगक िवकास -क.म, 2017 कहा
जाएगा।

इस -क.म म* िहमाचल देश और उ#राखंड रा'य) को कवर कया जाएगा।

2.

कवरे ज::-

3.

शुआत तथा अविध:- यह 01.04.2017 से लागू होगी तथा 31.03.2022 तक भावी रहेगी।

4.

पा ता:-

4.1

4.2
4.3

4.4

जब तक अ=यथा िविन>द?@ नहA कया जाये, िहमाचल देश एवं उBतराखंड रा'य) म* अवि-थत जैव- ौोिगक. तथा
10 मेगावाट तक जल िवुत उBपादन इकाइय) सिहत िविनमा?ण EेF तथा सेवा EेF क. सभी नयी औोिगक
इकाइयां और पया?G िव-तार करने वाली मौजूदा औोिगक इकाइयां इस -क.म के अंतग?त ोBसाहन) हेतु पाF ह)गी।
यह -क.म अनुबध
ं -I म* सूचीबH उोग) के संबंध म* लागू नहA होगी।
सभी पाF औोिगक इकाइयां इस -क.म के एक अथवा अिधक घटक) से लाभ ाJत करने क. पाF ह)गी, चाहे ऐसी
इकाइयां भारत सरकार क. अ=य -क.म) के अंतग?त लाभ ाG कर रही ह)।
सेवा EेF क. औोिगक ईकाई के िलए संयंF और मशीनरी म* भवन के िनमा?ण क. लागत और उस िवशेष सेवा
उोग के चालन हेतु बुिनयादी Kप से आवMयक वा-तिवक पNरसंपि#यां शािमल ह)गी लेकन इसम* भूिम और
उपभो'य, िड-पोजेबल अथवा राज-व भार वाली कोई अ=य मद शािमल नहA होगी।

2465 GI/2018

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

नयी औोिगक इकाइयां तथा Oयापक िव-तार वाली मौजूदा औोिगक इकाइयां इस योजना के तहत पाF ह)गी।
एक नई इकाई को िनPिलिखत शतQ को पूरा करना होगा: -

4.5

पहले से मौजूद कसी Sवसाय के िवभाजन अथवा पुनग?ठन से इसका िनमा?ण न Uआ हो।

(क)
(ख)

पहले कसी अ=य उVेMय के िलए उपयोग म* आने वाले संयंF या मशीनरी के कसी नई इकाई म* ह-तांतरण से
इसका िनमा?ण न Uआ हो।
यह अ=यF से िव-थािपत नहA क. गई ह) और/अथवा यह पहले से मौजूद ईकाई नहA होनी चािहए िजसे नया
नाम एवं -टाइल दया गया हो।

(ग)

प रभाषाएं

5

वािणियक उ$पादन
पादन क शुआत’ से ताBपय? है वािणि'यक पैमाने पर तैयार माल के िविनमा?ण क. शुKआत
िजसका पहले परीEण उBपादन हो चुका हो तथा सXपूण? संयंF एवं मशीनरी का सं-थापन हो चुका हो तथा उस
दन संयंF वािणि'यक माFा म* उBपाद) के िविनमा?ण के िलए हर कार से तैयार हो तथा िविनमा?ण हेतु
अपेिEत सम-त कYचे माल, उपभोग व-तुएं आद उपलZध ह) तथा यह क* [ीय उBपाद शुक/व-तु एवं सेवा कर
(जीएसटी) ािधकरण) के पास पंजीकरण क. तारीख के अनुसार ह)।

(क)

‘

(ख)

‘

'भावी कदम’ से आशय, िनXनिलिखत एक अथवा अिधक कदम) से है:a.

औोिगक इकाई के िलए जारी क. गई पूंजी का 10 ितशत अथवा इससे अिधक का भुगतान कया
जा चुका हो।

b.

फै ]^ी भवन के कसी िह-से का िनमा?ण हो चुका हो।

c.

औोिगक इकाई के िलए अपेिEत कसी संयंF अथवा मशीनरी के िलए फम? आड?र दया जा चुका हो।

(ग)

‘तैयार माल’
माल’

(घ)

‘

(ङ)

‘

(च)

का अथ? है व-तुत: कसी औोिगक इकाई ारा उBपादत वह माल िजसके िलए वह पंजीकृ त है।

औोिगक इकाई’ का अथ? है सरकार ारा िवभागीय Kप से संचािलत इकाई के अलावा कोई औोिगक उप`म
अथवा पाF सेवा EेF इकाई जो क व-तु और सेवा कर के तहत एक पंजीकृ त Sापार उम है।
िविनमाण काय’ का अथ? है ‘वह काय? जो िनजaव भौितक व-तु अथवा मद अथवा चीज म* पNरवत?न लाता है (i)
िजसके पNरणाम-वKप व-तु, मद अथवा चीज का एक नये तथा िविशbट व-तु अथवा मद अथवा चीज म*
काया=तरण होता है िजसका अलग नाम, गुण तथा इ-तेमाल होता है; अथवा (ii) िजससे एक अलग रासायिनक
िमcण अथवा िभ=न ढ़ांचे के साथ एक नयी तथा िविशbट व-तु, मद अथवा चीज का िनमा?ण होता है।’

यो+य सेवा .े इकाई' सेवा EेF म* एक उम है, िजसम* काफ. पूंजी Sय क. आवMयकता है और इसम* अBयिधक
रोजगार सृजन Eमता है।

'

नई औोिगक इकाई’का अथ? है वह औोिगक इकाई िजसने 01 अ ैल, 2017 को अथवा इसके बाद पर=तु 31
माच?, 2022 से पहले औोिगक ईकाई के Kप म* डीआईपीपी पोट?ल पर पंजीकरण कराया हो। ऐसी ईकाई को
पंजीकरण से 18 माह के भीतर वािणि'यक उBपादन/ चालन शुK करना होगा।

(छ)

‘

(ज)

'

मौजूदा औोिगक इकाई' का मतलब एक औोिगक इकाई िजसने 01.04.2017 से पहले Sावसाियक
उBपादन/ चालन शुK कर दया है।

पया2त िवतार’ का अथ? है - Eमता िव-तार/ आधुिनक.करण तथा पNरवत?न के योजन के िलए औोिगक इकाई
क. संयंF एवं मशीनरी म* ि-थर पूंजी िनवेश के मूय म* कम से कम 25% बढ़ोतरी।

(झ)

‘

(ञ)

‘

भौितक कायशील पूज
ं ी’ को फै ]^ी ारा लेखा वष? के अंितम दवस को अपने -वािमBव अथवा धाNरत अथवा
िनयंFणाधीन सम-त भौितक माल सूिचय) यथा सामिfयां, gधन एवं -नेहक, भंडारण आद िजसका इ-तेमाल
-वयं फै ]^ी ारा िविनhम?त उBपाद म* अथवा सं-करण हेतु अ=य को फै ]^ी ारा आपूNरत उBपाद म* इ-तेमाल
होता है, को शािमल करने के िलए पNरभािषत कया गया है। भौितक काय?शील पूंजी म* सामfी भंडार, gधन एवं
अ=य भंडार आद, िजसे -पbट तौर पर पुन: िब`. के िलए खरीदा गया हो, अH?-तैयार माल तथा अ=य) का

<!-- page 3 -->

¹Hkkx Iµ[k.M 1º

Hkkjr dk jkti=k % vlk/kj.k

3

गित पर काय? तथा फै ]^ी ारा बनाया गया माल जो लेखा वष? के अंत म* िब`. के िलए तैयार हो, शािमल है।
तथािप, इसम*
सं-करण हेतु अ=य) ारा फै ]^ी को आपूNरत सामfी भंडार, gधन, भंडार आद शािमल नहA है।
फै ]^ी ारा आपूNरत कYचे माल से अ=य) ारा संसािधत तैयार माल तथा उनके ारा धाNरत माल को शािमल
कया गया है तथा अ=य) ारा आपूNरत कYचे माल से फै ]^ी ारा संसािधत तैयार माल को शािमल नहA
कया गया है।

क3चा माल’
माल’ का अथ? है तैयार माल के िविनमा?ण म* कसी औोिगक इकाई ारा व-तुत: अपेिEत तथा इ-तेमाल
कया गया कYचा माल िजसके िलए अनुरोध कया गया है।

(ट)

(ठ)

‘

कायशील पूज
ं ी’ उपयु?]त पैरा (झ) म* यथापNरभािषत भौितक काय?शील पूंजी तथा ह-तगत नकदी तथा बjक म*
जमा तथा लेखा वष? के अंत म* देय रािश पर ाJय रािश के िनवल शेष क. कु ल रािश है।

‘

अ=य अ यु]त ओवर lाmट सुिवधा, समयाविध पर nयान दए िबना िमयादी जमा, ि-थर पNरसXपि#य)
के अज?न के िलए अिfम), ऋण) तथा -वािमय) एवं भागीदार) ारा उनके योजन एवं समयाविध पर nयान
दए िबना अिfम, Zयाज सिहत दीधा?विध ऋण) तथा िनवेश) को काय?शील पूंजी से बाहर रखा गया है।
तथािप,

(ड)

संयं और मशीनरी’ म* -थल पर -थािपत नए खरीदे गए औोिगक संयंF और मशीनरी शािमल ह)गे। अ=यF से
िव-थािपत/Nरसाइकल/Nरफhब?Mड संयंF और मशीनरी इस -क.म के तहत सहायता के पाF नहA हj। -क.म और
कसी िविनमा?ण ईकाई म* शािमल कए जाने वाले/हटाए जाने वाले घटक अनुबध
ं
– II म* दए गए हj। मशीनरी
क. खरीद सामा=य मूय पर खुले बाजार से क. जानी चािहए। यह सुिनिpत कया जाएगा क ]या यह खरीद
नजदीक. ाJय मूय `या का अनुसरण कए िबना कसी संबंिधत पE से क. गई है।

‘

पाF औोिगक इकाइय) को िनXनिलिखत ोBसाहन ितपूhत? आधार पर उपलZध कराए जाएंगे:

6
1.

ऋण ाJत करने के िलए क* [ीय पूंजी िनवेश ोBसाहन (सीसीआईआईएसी)

2.

क* [ीय Oयापक बीमा राजसहायता (सीसीआईआई)

एक उYचािधकार ाJत सिमित होगी िजसके अnयE सिचव, औोिगक नीित एवं संवध?न िवभाग ह)गे तथा इसम*
Oयय िवभाग के सिचव तथा नीित आयोग के ितिनिध तथा उस उोग के मामले से जुड़े भारत सरकार के संबिं धत
मंFालय)/िवभाग) तथा रा'य जहां पर इस -क.म के अंतग?त लाभाhथ?य) के चयन हेतु इ=सेNटव का दावा करने वाली लाभाथa
इकाई अवि-थत है, के संबिं धत मुrय सिचव/सिचव (उोग) शािमल ह)गे। ोBसाहन) के -ताव) क. जांच करते समय लागत
पहलू, पNरयोजना Oयवहाय?ता, बjक योsयता तथा
ोBसाहन दाता जोिखम पूंजी जैसे कारक) पर उिचत nयान दया जाएगा।
सूtम, लघु एवं मnयम उम (एमएसएमई) के अंतग?त आने वाली पाF औोिगक इकाइय) को ाथिमकता दी जाएगी।

6.1

ऋण 'ा2त करने के िलए क6 7ीय पूज
ं ी िनवेश 'ो$साहन (सीसीआईआईएसी)

6.2

6.2(क) िहमाचल देश और उ#राखंड रा'य) म* िविनमा?ण एवं सेवा EेF क. कहA पर भी अवि-थत सभी पाF नयी
औोिगक इकाइय) और पया?Jत िव-तार करने वाली िवमान औोिगक इकाइय) को ऋण के िलए (सीसीआईआई) 5
करोड़ Kपये क. ऊपरी सीमा के साथ संयंF एवं मशीनरी म* पाF िनवेश के 30% के िहसाब से क* [ीय पूंजी िनवेश
ोBसाहन दान कया जाएगा।
(ख) डीआईपीपी क. उYचािधकार ाJत सिमित ारा सहायता -ताव अनुमोदत कए जाने से पहले कसी
अनुसिू चत वािणि'यक बjक अथवा िवBतीय सं-था ारा पNरयोजना लागत का मूयांकन कया जाना अपेिEत होगा।
पNरयोजना Nरपोट? पर पूंजीगत Sय और मंजूरी पF तैयार होने के संबध
ं म* बjक के सEम ािधकारी ारा माणपF जारी
करने के आधार पर तथा संयंF एवं मशीनरी के काम शुK करने पर सXपूण? सहायता जारी कर दी जाएगी।

6.2

6.2 (ग) सरकार क. लागत के बढ़ने क. अव-था म* सहायता रािश बढ़ाने क. कोई ितबHता नहA है। पNरयोजना के
समय-पूव? बंद होने अथवा बीच म* ही छोड़े जाने क. अव-था म* सरकार ारा जारी क. गई सXपूण? सहायता को
डीआईपीपी को लौटाना होगा।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

क6 7ीय 8यापक बीमा राजसहायता (सीसीआईआई)
(सीसीआईआई)

6.3

(क) िहमाचल देश और उ#राखंड रा'य) म* कसी भी -थान पर अवि-थत सभी पाF नई औोिगक इकाइयां और
पया?Jत िव-तार करने वाली िवमान औोिगक इकाइयां वािणि'यक उBपादन शुK होने क. तारीख से 5 वष? क.
अिधकतम अविध के िलए भवन पNरसर) तथा संयंF एवं मशीनरी के बीमा पर 100% बीमा ीिमयम क. ितपूhत? हेतु
पाF ह)गी।

6.3

6.3 (ख) बीमा राजसहायता के योजनाथ?, औोिगक इकाई का अथ? है कोई उोग जो अिखल भारतीय अिx शुक के
अनुसार अिx नीित ‘ग’ म* शािमल है। यह नीित -तावक ारा घोिषत बाजार मूय पर बीमा कं पनी ारा जारी क.
जाएगी।

7.

अिनवाय अपे.ा

इस -क.म के अंतग?त यह अपेिEत है क इस -क.म के अंतग?त लाभ हेतु पाFता से पहले सभी पाF औोिगक इकाइय)
को इस -क.म के अंतग?त औोिगक नीित एवं संवध?न िवभाग, वािण'य एवं उोग मंFालय, भारत सरकार के पोट?ल के
जNरए पूव? पंजीकरण कराना होगा। इस संबंध म*, एक ऑनलाइन आवेदन `या िवकिसत क. जाएगी िजसके अंतग?त
आवेदक) को डीपीआर के साथ आवेदन जमा कराने ह)गे।

7.1

7.2 औोिगक नीित एवं संवध?न िवभाग िहमाचल देश और उ#राखंड हेतु औोिगक िवकास -क.म के िलए ऑनलाइन
पोट?ल के इ-तेमाल हेतु अलग से िव-तृत अनुदश
े
जारी करे गा।
पंजीकरण/िसHांतत: अनुमोदन के संबंध म* इस सिमित ारा िनण?य कया जाएगा जो अ=य बात) के साथ-साथ
औोिगक इकाई क. ाथिमक पाFता, बजट क. उपलZधता पर िवचार करेगी तथा इस -क.म के अंतग?त पंजीकरण हेतु
पाFता का िनण?य करेगी। कोई भी औोिगक इकाई िहमाचल देश और उ#राखंड हेतु औोिगक िवकास -क.म के अंतग?त
पंजीकरण अथवा लाभ) का दावा करने का हक नहA रख सके गी बशत{ क यह क* [ीय सरकार ारा िवशेष Kप से अनुमोदत
हो। राजसहायता के भुगतान म* िवलXब क. वजह को लेकर कसी कार के Zयाज का कसी इकाई ारा कोई दावा नहA
कया जा सकता। इस -क.म के लाभाथa को इस -क.म के शत? तथा िनबंधन का अनुपालन करने का एक शपथ-पF -तुत
7.3

करना होगा।

7.4 इन इकाइय) को अनुमोदन ाJत होने के 18 माह क. अविध म* वािणि'यक उBपादन शुK करना होगा।
िजन ईकाइय) ने 01.04.2017 को अथवा इसके बाद वािणि'यक उBपादन शुK कर दया है उ=ह* 30.09.2018 तक
डीआईपीपी म* पंजीकरण क. अनुमित होगी।

7.5

8.

नोडल एज6सी

8.1 िहमाचल देश रा'य औोिगक िवकास िनगम िलिमटेड (एचपीएसआईडीसी) और उ#राखंड रा'य औोिगक िवकास
िनगम `मश: िहमाचल देश और उ#राखंड रा'य) के िलए -क.म के िविभ=न संघटक) के अंतग?त ोBसाहन रािश के
संिवतरण हेतु एक नोडल एज*सी होगी। एचपीएसआईडीसी और एसआईडीसीयूएल पाF औोिगक इकाइय) के नािमत बjक
खात) म* के वल ई-^ांसफर के जNरए राजसहायता जारी करे गा।
9.

दाव: क जांच ';<या

डीआईपीपी म* पूंजीिनवेश ोBसाहन के अंतग?त ाJत राजसहायता के दाव) क. एक पंजीकृ त -वतंF लेखा-परीEा
एज*सी ारा पूव-? समीEा क. जाएगी। एचपीएसआईडीसी और एसआईडीसीयूएल ारा हर बार जारी कए गए दाव) के
10% क. लेखा परीEा पMचात जांच क. जाएगी। डीआईपीपी के मुrय लेखा िनयंFक,
Bयेक िवBतीय वष? म* जारी कए गए
राजसहायता दाव) के 20% क. लेखा परीEा कर*गे।

9.1

9.2

सरकार के पास इस -क.म के कसी भी भाग म* जनिहत म* संशोधन करने का अिधकार सुरिEत है।

इन िनण?य) को भावी बनाने के िलए भारत सरकार के सभी संबंिधत मंFालय)/िवभाग) ारा अपने संबंिधत
अिधिनयम)/िनयम)/अिधसूचना आद म* संशोधन करने तथा आवMयक अनुदेश जारी करने क. अपेEा होगी।
9.3

<!-- page 5 -->

¹Hkkx Iµ[k.M 1º
10.

Hkkjr dk jkti=k % vlk/kj.k

5

क6 7/राय सरकार/िव$तीय
तीय संथा>
था> के अिधकार

यद क* [ीय सरकार/रा'य सरकार/संबिं धत िवBतीय सं-था को इस बात क. पुि@ हो क कसी औोिगक इकाई ने
जाली सूचना देकर धोखे से राजसहायता ाJत क. है, अथवा यद यह इकाई वािणि'यक उBपादन के शुK होने के बाद 5 वष?
के भीतर उBपादन बंद कर देती है तो क* [ीय सरकार/रा'य सरकार/एचपीएसआईडीसी/एसआईडीसीयूएल उस इकाई को
सुनवाई का अवसर दान करने के बाद ऐसी इकाई को अनुदान अथवा राजसहायता लौटाने के िलए कह सकते हj। यह
राजसहायताएं िडिजटल भुगतान के जNरए जारी क. जाएंगी तथा एचपीएसआईडीसी/एसआईडीसीयूएल लाभाथa
औोिगक इकाइय) के संबंध म* डीबीटी िमशन ारा अपेिEत सभी सूचना एकिFत करे गा जो लाभाथa ईकाई के ािधकृ त
ह-ताEरकता? से इस संबंध म* एक शपथपF ले सकता है। -क.म क. सभी अपेEा को पूरा करने वाली लाभाथa ईकाई को
राजसहायता के िवतरण से पूव? औोिगक ईकाई और एचपीएसआईडीसी/एसआईडीसीयूएल के बीच एक Eितपूhत? बंध-पF
पर भी ह-ताEर कए जा सकते हj।
10.1

बूझ कर छु पाने अथवा तीसरे पE के जNरए धोखा करने अथवा गैर-िहमाचल देश/उ#राखंड
उBपादन के िलए दावे करने अथवा इसी कार के कदाचार करने पर औोिगक इकाई के भावी दावे जZत कर िलए जाएंगे
तथा पूव? म* दी गई सभी राजसहायता क. वसूली 15% वाhष?क Zयाज क. दर के साथ क. जाएगी।
10.2 दी गई सूचना को जान-

10.3 क* [ीय वािण'य एवं उोग मंFालय (औोिगक नीित एवं संवध?न िवभाग)/संबंिधत रा'य सरकार/िवBतीय सं-था के
पूव? अनुमोदन के िबना कसी औोिगक इकाई के -वामी को आंिशक अथवा समf राजसहायता ाJत करने के बाद कसी
औोिगक इकाई के कसी भाग अथवा सXपूण? औोिगक इकाई के -वािमBव को पNरवhत?त करने अथवा इकाई के आकार म*
बदलाव करने अथवा वािणि'यक उBपादन शुK करने के बाद 5 वष? क. अविध के अंदर इसके कु ल तय पूंजी िनवेश के बड़े
िह-से को बेचने क. अनुमित नहA होगी। ईकाई ारा -थल अथवा संपक? सूF म* कसी पNरवत?न के संबंध म* डीआईपीपी को
सूिचत करना भी अपेिEत है।
10.4 उन सभी इकाइय) को िजनको एचपीएसआईडीसी/एसआईडीसीयूएल ारा राजसहायता िवतNरत क. गई है, दए गए
आशय हेतु सामा=य िव#ीय िनयम, 2017 के पF 12 (ग) म* राजसहायता के इ-तेमाल का माण-पF औोिगक नीित एवं
संवध?न िवभाग को संबिं धत िवBतीय सं-था/रा'य सरकार ारा अंितम कMत/पूण? रािश ाJत होने क. तारीख से तीन माह
क. अविध के अंदर -तुत करना होगा।
राजसहायता ाJत करने के बाद, Bयेक औोिगक इकाई को औोिगक नीित एवं संवध?न िवभाग/संबिं धत रा'य
सरकार को उBपादन के बाद 5 वष? क. अविध के िलए उBपादन जारी रखने के संबंध म* वाhष?क गित Nरपोट? (एपीआर)
-तुत करनी होगी।
10.5

11.

िव-तृत दशािनद{श अलग से जारी कए जाएंग।े
डॉ वंदना कुमार,

'ितिलिप सूचना और आव?यक
आव?यक कार वाई के िलए 'ेिषत:
(i)
भारत सरकार के सभी मंFालय/िवभाग और नीित आयोग
(ii)
िहमाचल देश/उ#राखंड रा'य के मुrय सिचव।
(iii)
िहमाचल देश/उ#राखंड रा'य के सिचव (उोग)
(iv) िहमाचल
देश रा'य औोिगक िवकास िनगम िल. (एचपीएसआईडीसी), िशमला
(v)
उ#राखंड रा'य औोिगक िवकास िनगम (एसआईडीसीयूएल), देहरादून
'ित 'ेिषत:
(i)
मंिFमंडल सिचवालय
(ii)
धानमंFी काया?लय

संयु सिचव

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]
अनुबध
ं
- I

िनषेध-सूची

िहमाचल देश और उ#राखंड हेतु औोिगक िवकास -क.म, 2017 के अंतग?त िनXनिलिखत उोग लाभ) के िलए पाF नहA
ह)गे:
(i)

(ii)

क* [ीय उBपाद शुक अिधिनयम, 1985 (1986 का 5) क. थम अनुसूची के अnयाय 24 के अंतग?त आने वाले
सभी सामान जो तXबाकू तथा िनhम?त तXबाकू उBपाद) से संबंिधत हj।
क* [ीय उBपाद शुक अिधिनयम, 1985 (1986 का 5) क. थम अनुसूची के अnयाय 21 के अंतग?त आने वाले
पान मसाला

(iii)

पया?वरण एवं वन मंFालय क. अिधसूचना सं. एस.ओ.705(ई),दनांक 02.09.1999 तथा एस.ओ.698(ई),
दनांक 17.06.2003 के अंतग?त िविशbट Kप से उिलिखत के अनुसार 20 माइ`ोन से कम क. Jलाि-टक
थैिलयां।

(iv)

पे^ोिलयम अथवा गैस शोधशाला ारा उBपादत क* [ीय उBपाद शुक अिधिनयम,1985 (1986 का 5) क.
थम अनुसूची के अnयाय 27 के अंतग?त आने वाला सामान।
शोधशालाएं तथा 10 मेगावाट से अिधक िवुत उBपादन इकाइयां।

(v)

पौधरोपण,

(vi)

कोक (कै लसाइ=ड पे^ोिलयम कोक सिहत), mलाई ऐश, सीम*ट, -टील रोलंग िमल।

(vii)

(viii)

(ix)

(x)

पया?वरण संबंधी मानक) का अनुपालन नहA करने वाली अथवा पया?वरण एवं वन तथा जलवायु पNरवत?न
मंFालय अथवा रा'य पया?वरणीय भाव मूयांकन ािधकरण (एसईआईएए) अथवा संबिं धत क* [ीय दूषण
िनयंFण बोड?/रा'य दूषण िनयंFण बोड? से -थापना तथा चालन हेतु अपेिEत सहमित नहA लेने वाली
इकाइयां इस -क.म के अंतग?त राजसहायता हेतु पाF नहA ह)गी।
उYच क.मत के पैकेजंग तथा सं-करण को छोड़कर भंडारण के दौरान संरEण, साफ-सफाई, चालन, पैकं ग,
Nर-पैकं ग अथवा Nर-लैबलंग, छंटनी, खुदरा िब`. मूय म* पNरवत?न आद जैसे कम मूय संवध?न काय?कलाप)
क. अनुमित होगी।
सरकार ारा कभी भी आवMयक समझे जाने पर एक अलग अिधसूचना के माnयम से िनषेध सूची म* शािमल
कोई अ=य उोग/काय?। यह ऐसी अिधसूचना क. तारीख से भावी होगा।
गोड और गोड डोर ।
अनुबध
ं -II

क. िविनमाण .े म6 सीसीआईआईएसी के तहत संयं और मशीनरी के मूBय क गणना हेतु शािमल ;कए जाने वाले घटक:
(i)

(ii)
(iii)

(iv)

कर और शुक सिहत औोिगक संयंF और मशीनरी क. लागत अथा?त िविनमा?ण गितिविधय) को पूरा करने के िलए
उपयोग कए जाने वाले मुख उBपादन उपकरण क. लागत।
उBपादक उपकरण जैसे टूस, िजsस, डाई और मोड, इ=Mयोर*स ीिमयम आद क. कर और शुक सिहत लागत।
संयंF क. ओर जहां मीटर लगाया गया है, से तैयार व-तु के उBपादन/िड-पैच वाले -थान तक संयंF के चालन हेतु
आवMयक इलेि]^कल घटक (अथा?त एच.टी. मोटर, एल.टी. मोटर, ि-वच बोड?, पैनल, कैपेिसटर, Nरले, स>क? ट ेकर,
पैनल बोड?, ि-वच िगयर)।
आपूhत?कता? के पNरसर से इकाई के -थान तक संयंF और मशीनरी तथा उपकरण लाने के िलए भुगतान कया गया
मालभाड़ा।

(v)
(vi)

भुगतान कया गया ^ांिजट इंMयोर*स ीिमयम।
उस -थान तक माल को ढोने म* िनवेश क. गई रािश जहां क े माल के पNरवहन और तैयार माल के िवपणन के िलए
उसका उपयोग कया गया।

<!-- page 7 -->

¹Hkkx Iµ[k.M 1º

Hkkjr dk jkti=k % vlk/kj.k

7

ख. िविनमाण .े म6 सीसीआईआईएसी के तहत संयं और मशीनरी के मूBय क गणना हेतु िनFिलिखत घटक: को शािमल
नहG ;कया जाएगा:
(i)

माल चढ़ाने और उतारने का भाड़ा

(ii)

संयंF और मशीनरी के िलए शेड/भवन

(iii)

डीजी सेट,

(iv)

क े माल और अ=य उपभो'य भडार) सिहत काय?शील पूंजी

(v)

चालू करने संबंधी लागत

(vi)

कै पNटव पावर Jलांट

(vii)

भडारण उपकरण

(viii)

वजन तोलने का उपकरण (वे िज), योगशाला परीEण उपकरण

उBखनन/खनन संबंधी उपकरण, हjडलंग उपकरण, ऊपर क (iii) म* िजनका उलेख कया गया है, उ=ह*
छोड़कर अ=य इलेि]^कल घटक) जैसी िविवध िनयत पNरसंपि#यां

. िविनमाण .े म6 उ$थापन एवं थापना संबध
ं ी 'भार: क वीकायता

ग

उBथापन एवं -थापना संबंधी भार का भुगतान, वा-तिवक आधार पर कया जाएगा और औोिगक इकाई को ऋण दान
करने वाले िव#ीय सं-थान) क. मूयांकन NटJपणी म* िनधा?Nरत लागत तक सीिमत होगा।
MINISTRY OF COMMERCE & INDUSTRY
(Department of Industrial Policy & Promotion)
NOTIFICATION
New Delhi, the 23rd April, 2018
F. No. 2(2)/2018-SPS.—The Government of India is pleased to announce Industrial
Development Scheme for the States of Himachal Pradesh & Uttarakhand to boost industrialization.
1.
Scheme title: - The scheme will be called Industrial Development Scheme for Himachal
Pradesh (HP) & Uttarakhand, 2017.
2.

Coverage: - The scheme will cover the States of H.P & Uttarakhand.

3.
Commencement and duration: - It will be effective from 1.04.2017 and will remain in force
up to 31.03.2022.
4.

Eligibility:

4.1
Unless otherwise specified, all new industrial units and existing industrial units undertaking
substantial expansion in manufacturing sector and services sector including Bio-technology and
Hydel Power Generation Units upto 10 MW located in the states of H.P. & Uttarakhand will be
eligible for incentives under the scheme.
4.2

The scheme shall not be applicable to the industries listed in the Annexure – I.

4.3
All eligible industrial units will be entitled to benefits under one or more components of this
scheme, even if such units are getting benefits under other schemes of the Government of India.
4.4 Plant and Machinery for the service sector industrial unit shall include cost of construction of
building and all other durable physical assets basic to the running of that particular service industry
but exclude cost of land and consumables, disposables or any other item charged to revenue.
4.5
New industrial units and existing industrial units on substantial expansion shall be eligible
under the scheme. A new unit will be required to fulfil the following conditions:-

<!-- page 8 -->

8

5.

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

(a)

it is not formed by splitting up, or reconstruction of a business already in existence.

(b)

it is not formed by transfer to the new unit of plant or machinery previously used for
any other purpose.

(c)

it has not relocated from elsewhere and/or is not an existing unit reopened under a
new name and style.

Definitions
(a) Commencement of Commercial Production’ means starting of manufacture of finished
products on commercial scale which is preceded by trial production and installation of
complete plant and machinery and on that day the plant must be ready in all respects for
manufacture of finished products in commercial quantity and all raw materials, consumables,
etc. required for manufacture are available and as per date of registration with Central
Excise/Goods and Services Tax (GST) authorities.
(b) ‘Effective steps’ means one or more of the following steps:(i)

that 10% or more of the capital issued for the industrial unit has been paid up.

(ii) that any part of the factory building has been constructed.
(iii) that a firm order has been placed for any plant and machinery required for the industrial
unit.
(c) ‘Finished Goods’ means the goods actually produced by an industrial unit and for which it
is registered.
(d) ‘Industrial Unit’ means any industrial undertaking or eligible service sector unit, other than
that run departmentally by Government, which is a registered business enterprise under Goods &
Services Tax.
(e) ‘Manufacturing Activity’ means ‘an activity which brings about a change in non-living
physical object or article or thing (i) resulting in transformation of the object or article or thing into a
new and distinct object or article or thing having a different name, character and use; or (ii) bringing
into existence of a new and distinct object, article or thing with a different chemical composition or
integral structure’.
(f) ‘Eligible Service Sector Unit’ is an enterprise in the services sector that requires significant
capital expenditure and has significant employment generation potential.
(g) ‘New industrial unit’ means an industrial unit which registers itself on DIPP portal on or after
the first day of April, 2017 but not later than 31st day of March, 2022. Such units have to commence
commercial production/ operation within 18 months of registration.
(h) ‘Existing Industrial unit’ means an industrial unit which commences commercial production/
operation before 01.04.2017.
(i)
‘Substantial expansion’ means increase by not less than 25% in the value of fixed capital
investment in Plant & Machinery of an industrial unit for the purpose of expansion of capacity /
modernization and diversification.
(j)
‘Physical Working Capital’ is defined to include all physical inventories owned, held or
controlled by the factory as on the closing day of the accounting year such as the materials, fuels &
lubricants, stores etc., that enter into products manufactured by the factory itself or supplied by the
factory to other for processing. Physical working capital also includes the stock of materials, fuels &
stores etc., purchased expressly for re-sale, semi-finished goods and work in progress on account of
others and goods made by the factory which are ready for sale at the end of the accounting year.
However, it does not include the stock of the materials, fuels, stores etc. supplied by others to the
factory for processing. Finished goods processed by others from raw materials supplied by the

<!-- page 9 -->

¹Hkkx Iµ[k.M 1º

Hkkjr dk jkti=k % vlk/kj.k

9

factory and held by them are included and finished goods processed by the factory from raw
materials supplied by others are excluded.
(k)
‘Raw Material’ means any raw materials actually required and used by an industrial unit in
manufacturing of the finished goods for which it is requested.
(l)
‘Working Capital’ is the sum total of the physical working capital as defined in Para (j)
above and the cash deposits in hand and at bank and the net balance of amounts receivable over
amounts payable at the end of the accounting year.
Working capital, however, excludes unused overdraft facility, fixed deposits irrespective of
duration, advances for acquisition of fixed assets, loans and advances by proprietors and partners
irrespective of their purpose and duration, long term loans including interest thereon and
investments.
(m)
‘Plant and Machinery’ shall cover the cost of newly purchased industrial plant and
machinery as erected at site. Relocated / Recycled / Refurbished plant and machinery is not eligible
for assistance under the Scheme. Components to be included / excluded for the purpose of scheme
and for a manufacturing unit is at Annexure II. The purchase of machinery should be from open
market at normal market price. It will be ascertained whether the purchase has been made from a
Related Party without following an arms-length price discovery.
6.
The following incentives will be provided to eligible industrial units on reimbursement basis:
1. Central Capital Investment Incentive for access to credit (CCIIAC)
2. Central Comprehensive Insurance Incentive (CCII)
6.1
There will be an Empowered Committee chaired by Secretary, Department of Industrial
Policy and Promotion with Secretaries of D/o Expenditure, representative of NITI Aayog and
Secretary of the concerned Ministries/Departments of Government of India dealing with the subject
matter of that industry as its members as also the concerned Chief Secretary/Secretary (Industry) of
the State where the beneficiary unit claiming incentive is located for selection of beneficiaries under
the scheme. While examining the proposals for incentive, due consideration will be given to factors
like cost disadvantage, project viability, bankability, employment generation and promoters’ risk
capital. Preference will also be given to eligible industrial units under the Micro, Small and Medium
Enterprises (MSME).
6.2
Central Capital Investment Incentive for access to credit (CCIIAC)
6.2(a) All eligible new industrial units and existing industrial units on their substantial expansion in
the manufacturing and service sector located anywhere in the States of H.P. and Uttarakhand will be
provided Central Capital Investment Incentive for access to credit (CCIIAC) @ 30% of the
investment in plant and machinery with an upper limit of Rs.5.00 crore.
6.2(b) The project cost will need to be appraised by a Scheduled Commercial Bank or Financial
Institution before the proposal of assistance is approved by the Empowered Committee of DIPP.
Full assistance will be released on the basis of certificate issued by Competent Authority of the bank
that the capex on the project report and sanction thereof is in place and Plant & Machinery has been
put to use.
6.2(c) The government does not commit itself to increase in the scale of assistance in case of cost
escalation. In case the project is foreclosed or abandoned midway the entire assistance released by
government will be refunded to DIPP.
6.3
Central Comprehensive Insurance Incentive (CCII)
6.3(a) All eligible new industrial units and existing industrial units on their substantial expansion
located anywhere in the states of H.P & Uttarakhand will be eligible for reimbursement of 100%
insurance premium on insurance of building and Plant & Machinery for a maximum period of 5
years from the date of commencement of commercial production/ operation.

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

6.3(b) For the purpose of insurance incentive, ‘industrial unit’ shall mean any industry which is
included in Fire Policy ‘C’ as per All India Fire Tariffs. The policy shall be issued by the Insurance
Company on market valuation to be declared by the proposer.
7.

Mandatory requirement

7.1
This Scheme requires that all eligible industrial units would have to register under the Scheme
with Department of Industrial Policy and Promotion, Ministry of Commerce and Industry, Govt. of
India, through the DIPP portal prior to being eligible for any benefit under this scheme. In this
regard, an online application process shall be developed under which the applicants have to submit
applications along with the DPR.
7.2
The Department of Industrial Policy and Promotion would separately issue detailed
instructions for the use of online portal for Industrial Development Scheme for H.P & Uttarakhand
and registration of eligible units.
7.3
The final grant of registration/in-principle approval will be decided by the Committee, which
will, inter-alia, consider the prima-facie eligibility of the industrial unit, availability of budget and
decide the eligibility for registration under the Scheme. No Industrial unit will have the right to
register under Industrial Development Scheme for H.P & Uttarakhand or claim the benefits unless it
is specifically approved by the Central Government. No interest on account of delay in payment of
incentive can be claimed by the unit. The beneficiary of this scheme has to furnish an undertaking to
abide by the terms and conditions of the scheme.
7.4

The units should start commercial production within 18 months of approval.

7.5
Units which have commenced production on or after 1.4.2017 will be allowed to register with
DIPP upto 30.9.2018.
8.

Nodal agency

8.1
The Himachal Pradesh State Industrial Development Corporation Ltd.(HPSIDC) and State
Industrial Development Corporation of Uttarakhand (SIDCUL) will be the nodal agencies for
disbursal of incentives under various components of the Scheme for the States of H.P & Uttarakhand
respectively. HPSIDC and SIDCUL will release incentive only through e-transfer to designated bank
accounts of the eligible industrial units.
9.

Process of Scrutiny of claims

9.1
Incentive claims under Capital Investment Incentive received in DIPP will be pre-scrutinized
by a recognized independent audit agency. HPSIDC and SIDCUL will conduct post-audit of 10% of
claims released every time. The Chief Controller of Accounts of DIPP will also conduct post-audit
of 20% of incentive claims released in each financial year.
9.2

Government reserves the right to modify any part of the Scheme in public interest.

9.3
All concerned Ministries/Department of Government of India are required to amend their
respective Acts/ Rules/ Notification etc. and issue necessary instructions for giving effect to these
decisions.
10.

Rights of the Centre/State Government/Financial Institutions

10.1 If the Central Government/State Government/Financial Institution concerned is satisfied that
an industrial unit has obtained incentive(s) by misrepresenting an essential fact, furnishing of false

<!-- page 11 -->

¹Hkkx Iµ[k.M 1º

Hkkjr dk jkti=k % vlk/kj.k

11

information or if the unit goes out of commercial production/ operation within 5 years after
commencement of commercial production/ operation, the Central Government/ State Government /
HPSIDC/SIDCUL may ask the unit to refund the grant or incentive after giving an opportunity of
being heard to the unit. The incentive(s) will be released through digital payment and would collect
all information required by the DBT Mission in respect of beneficiary industrial uni
HPSIDC/SIDCUL may take an affidavit in this regard from authorized signatory of the beneficiary
unit. An indemnity bond may also be signed between the industrial unit and HPSIDC/SIDCUL prior
to disbursement of incentives, providing for undertaking on the part of the beneficiary unit to comply
with all the requirements of the scheme.
10.2 Concealment of input supplies or routing of third party or non-Himachal
Pradesh/Uttarakhand production for claims or malpractices of similar kinds will render the industrial
unit liable for forfeiture of further claims and recovery of all previous subsidies with interest @ 15%
per annum.
10.3 Without taking prior approval of the Union Ministry of Commerce & Industry (Department
of Industrial Policy and Promotion) /State Government/Financial Institution concerned, no owner of
an industrial unit after receiving a part or the whole of the incentive will be allowed to change the
ownership of the whole or any part of industrial unit or effect any substantial contraction or dispose
of a substantial part of its total fixed capital investment within a period of 5 years after its going into
commercial production. The unit will also be required to keep DIPP informed about change in
location or contact information.
10.4 In respect of all units to whom the incentive is disbursed by HPSIDC/SIDCUL, certificate of
utilization of the incentive(s) in Form 12(C) of General Financial Rules, 2017 for the purpose for
which it was given shall be furnished to the Department of Industrial Policy and Promotion by the
financial institution/State Government concerned, within a period of three months from the date of
receipt of the last installment/full amount.

10.5 After receiving the incentive(s), each industrial unit shall submit Annual Progress Report
(APR) to the Department of Industrial Policy and Promotion/ State Government concerned, about its
working for a period of 5 years after going into production.
11.

Detailed guidelines shall be issued separately.
Dr. VANDANA KUMAR, Jt. Secy.

Copy for information and necessary action to:
(i)

All Ministries/Departments of the Government of India and NITI Aayog.

(ii)

Chief Secretary of the State of Himachal Pradesh/Uttarakhand

(iii)

Secretary (Industries) of State of Himachal Pradesh/Uttarakhand.

(iv)

Himachal Pradesh State Industrial Development Corporation Ltd. (HPSIDC), Shimla.

(v)

State Industrial Development Corporation of Uttarakhand,Dehradun

Copy also to:
(i)

Cabinet Secretariat

(ii)

PMO

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

Annexure – I
Negative List:
The following industries will not be eligible for benefits under Industrial Development Scheme, for
H.P & Uttarakhand 2017:
(i)

All goods falling under Chapter 24 of the First Schedule to the Central Excise Tariff Act,
1985 (5 of 1986) which pertains to tobacco and manufactured tobacco substitutes.

(ii)

Pan Masala as covered under Chapter 21 of the First Schedule to the Central Excise Tariff
Act, 1985 (5 of 1986).

(iii)

Plastic carry bags of less than 20 micron as specified by Ministry of Environment and Forests
Notification No. S.O. 705 (E) dated 02.09.1999 and S.O. 698 (E) dated 17.6.2003.

(iv)

Goods falling under Chapter 27 of the First Schedule to the Central Excise Tariff Act, 1985
(5 of 1986) produced by Petroleum or Gas refineries.

(v)

Plantation, Refineries and Power generating Units above 10 MW.

(vi)

Coke (including Calcined Petroleum Coke), Fly Ash, Cement, Steel Rolling

(vii)

Units not complying with environment standards or not having applicable Environmental
Clearance from M/o Environment & Forests and Climate Change or State Environmental
Impact Assessments Authority (SEIAA) or not having requisite consent to establish and
operate from the concerned Central Pollution Control Board/State Pollution Control Board
also will not be eligible for incentive under the scheme.

(viii)

Low value addition activities like preservation during storage, cleaning, operations, packing,
repacking or re-labelling, sorting, alteration of retail sale price etc. take place excluding high
value packaging and processing.

(ix)

Any other industry/activity placed in negative list through a separate notification as and when
considered necessary by the Government. It will be effective from the date of such
notification.

(x)

Gold and gold dore.

Mills

Annexure-II
A.

Components to be included for computing the value of Plant and Machinery under
CCIIAC in the manufacturing sector :
(i)

Cost of Industrial Plant & Machinery including taxes and duties i.e. cost of mother
production equipment used for carrying out manufacturing activities.

(ii)

Cost of Productive equipment such as tools, jigs, dyes and moulds, insurance
premium etc. including taxes and duties.

(iii)

Electrical components necessary for plant operation on the plant side from where
meter is installed up to the point where finished goods is to be produced/ dispatched
(i.e. H.T. Motors, L.T. Motors, Switch Boards, Panels, Capacitors, Relay, Circuit
Breakers, Panel Boards, Switchgears).

(iv)

Freight charges paid for bringing Plant & Machinery and equipment from
the supplier’s premises to the location of the unit.

(v)
(iv)

Transit Insurance premium paid.
The amount invested in goods carriers to the extent they are actually
transport of raw materials and marketing of the finished products.

utilized for

<!-- page 13 -->

¹Hkkx Iµ[k.M 1º
B.

C.

Hkkjr dk jkti=k % vlk/kj.k

13

Components which will not be considered for computing the value of Plant &
Machinery under CCIIAC in the manufacturing sector :
(i)

Loading and unloading charges

(ii)

Sheds/ buildings for Plant & Machinery

(iii)

Miscellaneous fixed assets such as DG sets, Excavation/ Mining equipments, handling
equipments, electrical components other than those mentioned at A (iii) above.

(iv)

Working Capital including Raw Material and other consumable stores.

(v)

Commissioning cost

(vi)

Captive Power Plants

(vii)

Storage equipments

(viii)

Weigh bridge, Laboratory testing equipment.

Admissibility of erection and installation charges in the manufacturing sector
Erection and installation charges will be payable on actual basis and will be restricted to the
cost indicated in the Appraisal Note of the Financial Institutions which provided loan to the
industrial unit.

RAKESH
SUKUL
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

Digitally signed by
RAKESH SUKUL
Date: 2018.05.02
23:06:27 +05'30'
