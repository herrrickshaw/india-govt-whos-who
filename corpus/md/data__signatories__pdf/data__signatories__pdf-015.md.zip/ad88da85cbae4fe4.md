---
doc_id: "ad88da85cbae4fe4"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/c4139f0cc4cba233e64e292463874921.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Notice for inviting Stakeholders Comments on review of notified list under DoT PPP-MII order dated 21.10.2024"
date: "2025-04-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d0ad19630c60d649"
---

<!-- page 1 -->

18-10/2017-IP

I/3283002/2025

18-10/2017-IP
Government of India
Ministry of Communications
Department of Telecommunications
(Investment Promotion Division)
Dated the 3rd June, 2025
Notice for inviting Stakeholders’ Comments
The Department of Telecommunications (DoT) proposes to review its
PPP-MII order dated 21.10.2024, specifically the following aspects:

a. List of products notified under the Order.
b. Product wise Local Content Requirement including the ceiling of LC for
Design.
c. Conditions of inputs (including design) to be qualified as Local Content.
d. Criteria for calculating Local content for Software Products.
2.
Multiple reports (NITI Aayog, TRAI, MAIT, PLI companies etc.) indicate
that India’s limited component ecosystem poses challenges in achieving 5060% local content in electronic / telecom products. Recognizing this constraint,
the conditions for local content qualification also requires a review.
3.
Stakeholders are requested to provide their comments and suggestions
on the above. Any recommendations for the inclusion of new products or
exclusion of existing ones must be substantiated with detailed justiﬁcation
including veriﬁable data such as List of major manufacturers, Estimated local
content value (%), Annual production capacity, Domestic sales &
exports/imports (with figures), Sales to public sector entities etc.
4.
The comments / suggestion if any may be furnished within 30 days of
issue date of this notice. The comments are to be sent to email-id dirip.hqdot@nic.in and usip.hq-dot@nic.in.
Encl: As above
(Alok Ranjan)
Director (IP)
To,
Associations: VoICE, TEMA, TEPC, ICEA, COAI, MAIT
OEMs : Tejas, HFCL, VVDN, Nokia, Ericsson, Cisco
EMS Companies – Dixon, Syrma, Neolync, Jabil
PSUs: BSNL, TCIL, ITI, RailTel, PowerGrid, Coal India Ltd
Copy to: Director (IT), DoT HQ for uploading on the DoT website
