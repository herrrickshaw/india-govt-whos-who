---
doc_id: "acc81fa8ec6c7f62"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/7132dd7aaa0194a4ef5fd33cc00cedc8.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment in Recruitment Rules of Nursing Adviser, Assistant Director General (Nursing), Deputy Assistant Director General (Nursing) and Deputy Nursing Adviser"
date: "2022-08-07"
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f1d3911420cb96d4"
---

<!-- page 1 -->

No. A. I 20 I 4/02/2022-N/DGHS
Mi

oGffi il.#Ji.ffi werfare

"i,r,y (Nursing Division)

NirmanBhawan, New Delhi-l l00l I
Dated:01.07.2022

NOTIFICATION
This Ministry is exanrining a proposal tbr amendment to the Recruitment Rules lor
post of Nursing Adviser, Assistant Director General (Nursing), Deputy
Assistant
lhe
Dir^ecror General (Nursing) and Deputy Nursing Adviser in the DteI'6HS.
tnihis regard,
draft Recruitment Rules have been prepared and aplroved by the competent
Authority.

'

2.

Before taking up the proposal for amendment to the Recruitment Rules
with the
DoP&T,-UPSC and other agencies for finalizing the Recruitment Rures,
comments. irany are
invited liom all stakeholders in the nrarter wiihin a period of thirry
days
'ramitytiom the daie of
notification
the website
the
Ministry
Health
and
wettilre.--rle
_of
objections/suggestions received from the stakehorders within the
specified p".ioJ snat u.
considered by the Ministry as per rules/requirement.

in

of

Th::orments may be fumished to Nursing Division, Dte. GHS in Room No.
747_4,
A wing, Nirman Bhawan- New Derhi-l r00rt an-d the sort copy nray be senr
to nursi4g,
mohlw@gor.
1. .-..

in

*M

Deputy Direcror (Nursing)

<!-- page 2 -->

ITO BE PUBLISHED IN THE GAZATTEE OF INDIA, PART II, SECTION 3, SUB
SECTTON (i)l

GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILYWELFARE
Notification
New Delhi, the
2022.
G.S.R. No........................In exercise of the powers confened by the proviso to article 309 of the
Constitution and in supersession of the Directorate Geueral of Health Services (Nursing Officer)
Recruitment Rules, 1982; the Department of Family Planning (Nursing Adviser) Recnritment
Rules, 1977 except as respects thing; done or omitted to have been done before such supersession,
the President hereby makes the following rules regulating the method of recnritment to the post of
Nursing stream in the Directorate General of Health Seivices, Department of Health and
Department of Family Welfare in *1s lvlinistry of Health and Family Welfare, namely:-

1.

Short title and commencement. - (1) these rules may be called the Ministry of Health and
Family Welfare, (Nuning Stream), Recnritment Rules, 2022.
(2) They shall come into fotce on the date of their publication in the Official Gazeue.

2.

Number of post, classification, and. scale of pay- The number of said post, its classification
and the scale of pay attached thereto shall be as specified in g6lumns (2) to (4) of the
Schedule I, II, UI and IV annexed to these rules.

3.

Method of recruitment, age-limit and other qualifications etc. - Method of recnritrnent, agelimit, qualifications and other matters relating thereto shall be as specified in columns (5) to
(13) of the said Schedule.

4. Disqualifrcation. - No persons,(a) who has entered into or contracted a marriage with a person having a spouse living;

or

lraving a spouse living, has entered into or conrraced a marriage with any person,
__ _ Q) lYho,
shall be eligible for appointment to the said post:

.

Provided that the central Govemment may, if satisfied that such marriage is
permissible under the personal law applicablb to such person and the other pafty t; the
marriage and that there are other grounds for so doing, exempt such person fiom the
operation of this rule.

5. Power to relax. - where the Cenffal Govemment is of the opinion that it is necessary or
expedient so to do, it may, by order, for reasons to be recorded in writing relax any oi the
provisions ofthese rules with respect to any class or category ofpenons.

6. Saving. - Nothing in these rules shall affect reservation, relaxation of age-limit and other
concessions required to be provided for the Scheduled castes, the Scheduled rribes, Exservicemen and otler special categories of persons in accordance with the orders issued by the
central Govemment from time to time in this

regatd.

t

.

-

<!-- page 3 -->

Schedule-l
Name ofthe post

Numb€r ofpost

Classilication

(3)

(:2)

I

Nursing Adviser

Level in the pay matrix

I * (2022)

Whether selection
or non-selection
post
(5)
Not applicable

(1)

* Subject to variation

General Central
Civil Services

(Rs. I 4300-400- l 83 00)

dependent on workload.

Group'A'

(Rs. 37400- 67000) G.P. 8700 as

Gazetted. Non-

per 6'h cPc.

Ministerial

Age- limit lbr
direct rccruits
(6)
Not applicable

LEVEL- ll (Rs. 123100- 215900)

as per 7s CPC.

Educational and other
qualifi cations required for
direct recruits

Whether age and educational
qualifi cations prescribed for
direct recruits will apply in
the case of promotes

(7)

Period

Method of recruitment wheth by direct recruitment or by
promotion or by deputation/ absorption and percentage of
the vacanci€s to be filled by various methods

(e)

(81

Not applicable
I Not applicable
In case of recruitment by promotion/deputatiorvabsorption

of

probation if any

(10)

Not applicable
grades from

which promotion/ deputation/absorption to be made

By Deputation including short-term contract/Promotion.
Depanmental Promotion Circumstances
which
Committee exists, what
its Union Public Service
composition.
Commission
he

If a

in

is

consulted in

to

making

recruitment.
(

I. Deputation (lncluding short-term contractypromotion:

Oflicem under the Central Govemmenustate Govemmen/ Union

t2)

(13)

Not applicable.

Consultation with UPSC
necessary.

lerritories or auionomous organizations:-

(axi) holding analogous post on rcgular basis in the parent cadre or
departmenl; or

(ii) wilh 5 yea$' service in the grade rendered after appointrnent thereto
on a regular basis in Level -12 (Rs. 78800-209200) of the pay matrix or
equivalent in the parcnt cadre/department; or
(iii) with l0 years of service iD the gade rendered after appointrhent
thereto on a regular basis in Level -l I (tu. 67700-208700) bi tte fuy
matrix or equivalent in the parent cadre/Department; and

(b) possessing the following educational qualifications And experience;

(i) Master's Degree in Nursing from a recognized University/Institution or
equivalent;

(ii) l2^yeals' experience in Nursing /Teaching including Community
Health Services: and

(iii) Registered as nurse and midwife or equivalent with any State Nu6ing

Council
II. Assisrant Director Gcneral (Nusing) with 5 year's regular service in the

grade failing which with l0 year,s combined servici in the grade
of
Assistant Director General (Nursing) and Deputy Assistant birector
General (Nursing) / Deputy Nursing Adviser and poss€ssing Master,s
Degree.in Nursing fiom a recognized Univenity/lnstitution or equivalent
and registered as Nurse and midwife with any state Nursing Council shall
also be considered along with outsiders and in case he/she is selected for
appointnent to the pos1, the same shall be deemed to have been filled by
promotion.

(The Departmental Oflicers in the feeder category who are in the direct line

of promotion will not be oligible for consideration for appointment on
deputation. Similarly, deputationists shall not be eligib"le foi consideration
for appointmcnt by promotion.)

[Period of deputation/contract including period ofdeputation in another excadre post held immediately preceding this appointmeflt in the same or
some other organization/department of the Central Covemment shall not
exceed.5 years. The maximum age limit for appointment by deputation
(including short term cont act) shall be not exc;ding 56 yea$ a;
on the
closing date of receipt of applications.
lF. No. A. l20l

Under Secretary to the Govemment

<!-- page 4 -->

Schedule-II
Level in the pay matrix
direct recruits

(;eneral (Nursing)

t I (2022\

* Subject to va ation
dependent on workload.

General Central Civil
Services Group 'A'
Gaz€fted, Non-

(Rs. 15600-39100) c.P.

Ministerial

?600 as per

(Rs. t 2000-3?5- 16500)

4 CPC

LEVEL-12 (Rs. 78800Educational and other
qualifi cations required for
direct recruits

Whether age and educational
qualifi cations prescribed for
direct recruits will apply in

Method of recruitment whether by direct recruitment or by
promotion or by deputdion/ absorption and percentage of
the vacancies to be filled by various methods

In case of recruitment U,'- pffi

If a Departmental Promotion Committee

rvhich promoti<lnl deputatior/absorption to be made

exists, what is its composition.

Union Public Service

Commission to be
consulted in making
rccruitment.

Consultation with UPSC

Officers under the Central Govemment/State Govemment/Union

necessary.

terdtorievautonomous organi2ations:-

(aXi) holding analogous post on regular basis in *le parenr

cadre/
department; or
(ii) with 5 yeaN' service in the grade rendered after appointnent thereto
on a regular basis in Levet -l I (Rs. 67700-208700) oa the pay matrix
or
equivalent in the parent cadre or departmenr; or

(iii) with l0 years of service in the gade rendered after appoinhent

lhereto on a regular basis in Lelel -tO (Rs. 56100_177500) of the pay
matrix or equivalcnt in the parent cadre/Department; and
(b) Possessing the following educational qualifications

and experience.

(i)Master's Degree in Nursing fiom a recognized
Universitv/lnstitution
or equivalent; and
(ii).Must be a registered Nurse and Registercd
with any state Nursing Council;
(iiD- l0yea$' experience in Nursing/Teaching
Health Service:
Il.Dep_ul) Nursing Adviser /Deputy Assisranr Direcror General (Nursins
)

wilh 5 year's regular service in rhe $ade: failing \4hich i0 y;;:;
combined service in the grade of Deputy esstt] Oirector
Clne-l
(Nursing)/Deputy Nursing Ad!isel and Nursins
Ofllcer oossessino
Masler's Degree in Nursing from a recognized Univertirynnirirurion
o?
equivalent and registered Nurse and midwife or equivalent with
anj
State Nursing Council shall also be considered along with
outsiders anl
in case_he/she in selected for appointmenl lo the posl the same
shall be
deemed to have been filled by promotion.
(The Depaflmenlal officers in rhe leeder
categor) who are in lie direct
line of promotion-shall not be eligible for coniidiration fo. uppol"tn*i
on deputalion. Similarl). depurarionisrs shall nol be eiigible for
consideration for appoinlment by promotion.)

IPeriod of depuratiorL/conrracr inciuding period of depulation/contract in
another e\-cadre posr held immediarel) preceding t-his appointrnenr
in

the same or some other Orgarization/Departri"rr of'th" C"nt ui

Govemment shall ordinarily not exceed 4 years. Ihe maximum
age limit
for appointment by deputation (including short term contrac0
not exceeding 56 yea-rs as on fie closing ofreceipt otapplications.

;;i ;;

[F. No. A. l20l

ll

Under Secretary to the Govemment

<!-- page 5 -->

Schedule-lII

Director Geneml
(Nursing)

Level in the pay matrix

Age- limit for direct recruits

(Rs.10000-325- 15200)

Not exceeding 40 yeals

(Rs. 15600-39100) C.P. 6600
as oer 6'h cPC

1o 5 years in accordance with
the instructions or orders issued

(Relaxable for Go!t. servants up

direct recruits

LEVEL-I r {Rs. drm208700) as per 7'h CpC.
Whether age and educational
qualifi cations prescribed for
direct recruits will apply in

Method of r€cruitment whether by direct recruitment or
\
promotion or by deputatior/ absorption and percentage of
the vacancies to be filled by various methods

l) Master's Degree in
Nursing of a recognized

(i)Master's Degree in
Nursing ofa recognized

Deputation (including short+erm-ontracg/p6iotioiEffi
which by Direct Recruitment.

Educational and other
qualifi cations required for

University/lnstitute or

cquivalent;

ii)tvtust be registered Nurse
and Registered Midwife or

equivalent with any State

2 years for direct

recruit.

University/lnstitute or

by the Cenlral Govemment).

equivale ;

(ii)Must be registered Nume
and Registered Midwife or
equivalent with any State

Nursing Council;

Nursing Council;

Years' experience in
Nursing/Teaching
including cornmunitv

(iii)s Yea^' experience in
Nursing/Teaching including
community Health Services.

Health Services.

In case of recruiGent Ti

which promotion/ deputatiotabsorption to be made.

"lf a

Depanmentii--Fimotioi

Comminee exists, what is its
composition.

Circumstances in which

Union Public Service

Commission to be
consulrcd in making
recruitnent.

L D.prtation (tnclrding shAG

;;;;t/pro;;rio;

Offi cers under the Central Govemment/Stale Govemment/Union
territo es/autonomous organizations;_
(ax i) holding analogous post on regular

depanmenl; or
(

basis in the parent cadre or

ii) with 5 years' service in the grade rendered aier

a regutar basis in Level -9 t Rs. 53100_ 167g00)

equivalent in the parent cadre/Department; or

appointmenr therelo on
of rhe iay matrix or

(iii) With.8years' service in the grade rendered affer

appointment thereto

I regulal bTis in Levet -7 (Rs. 44900_t+ZlOot ordre ray marrii or'"
:lequl!alenl
in lhe parent cadre/Departnent;

Group 'A' Departmental Fromoiion
Committee (for confirmation of direct
recruits)
Joint Secretary, Depafiment of
Health -Chairman

(i)

(ii) Deputy Director General of
Health Services -Member

Deputation (including
short-term

contractl?romotion

Consultation wirh UpSC
is necessary.

(iii) Director/Deputy Secretarv
(Administration), Ministry oi
Health &rd Family WelfareMember.

and

(bl possessing lhe educational qualificarions
orrect recrutts under Col. 8

and experience prescribed for

IL Nursing

officer wilh 5 years regular service in lhe gade shall
also be
consroered atong *ilh the outsideE and in case
he/she is selected -i,
for
appointment to the post, the same shall be deemea
to f,ar" U"* nii"a
promotion.
(The Departmenral officers in the feeder calegory
who are in the direct line
sl. tt. nol be etigibte for consideration fo, uppoir*.ni'on
:l-e::'orio1.
depulatron. Similarl). depurationsls shall nor be eligible
toi consiaerarion
ror appotntmenr by promotion.)
[Period of deputatiorl/contract including period of deputatior/conhact in
another ex-cadre.posr held immediately preceding
rhisappoinrnenl ;;-th;
YT: o, :9r9 other Organizarion_/Deparrnent of rhe Cenrlal co!emmenr

nol exceed 3 years. The maximum age timir for
ll1,l, lrorTty
b)
depuration {inctuding shon rcrrn .onr*"t)'.t uti--b.
not
ilryii*.:,_
exceeorng J6 yeals as on the closing date ofreceipt

ofapplications.l

Under Secretary to the Govemment

<!-- page 6 -->

Level in the pay matrix

Depuq/ Nursing

t * (2022)

Adviser

* Subject to

Geneml Central Civil
Services Group 'A'

(Rs.10000-325-15200)

variation

Gazetted, Non-

(Rs. 15600-39100) G.P.
6600 as per 6d CPC
LEVEL-I I (Rs. 67700208700) as per 7h CPC.

dependent on

Ministerial

workload.

probation if any

requircd for direct recruits

educalional
qualifi cations prescribed
for direct recruits will
apply in the case of

Master's Degree in
Nursing of a recognized

Nursing ofa recognized

University/lnstitute or equivalent;

University/lnstitute or

Must be registered Nurse

and Registered Midwife or

2 y*rs for direct recruit.

(ii)Must be registered
Nurse and Registered

Nuning./Teaching including

Midwife or equivalent
with any Stare Nursing

community Health Services.

Council;

) 5 Years' experience in

servants up to 5 years in

accordance with the
instructions or orders
issued by the Central

Method of recruitment whether by direct

Deputation (including shon-rerm
contract)lPromotion failing which by Direct
Recruitment.

equivalent;

equivalent with any State Nursing
Council:

Not exceeding 40 years
(Rclaxable for Corr.

recruitment or by promotion or by deputatiorl/
absorplion and percenlage of the vacaocies lo
be filled by various methods

)

iv)

Not applicable

(iii)5 Years' experience

in Nursing/Teaching
including community
rn case.of recruitment by

Health Services.

@

promotion/ deputation/absorption to be made

tf a Departmental Tromoiiin

Circumstances in which

compositidn.

Commission to be
consulted in making

Committee existi what is its

Union Public Service

recrultment.

I Depuration (tncluding@

Group 'A'

Ofticers under the Central Govemmenustat€ Gov€mmenrunion
territorievautonomous organizations;-

(a)(i) holding analogous posl on regular
basis in the parenl cadre or
departrnent; or
(ii) with 5 years service in the grade rendered after
appointment thereto on a

regular basis in Level -9 (Rs. 53 100- 167800) of the pay
matrix
the parent cadre/Department; or

(iii) With 8.yea$' service in the grade rendered aft€r

oi"iUr"[iii,

appointment thereto on a

regular basis in Level -7 (Rs. ,U900-142400y of tfr" fay
.at.l* o.
the parenl cad re/Departmen t; and

;;;;;;;

Departmenlal

Promotion Committ€e (for

Deputation (including
short-term

confi rmation of direct recruits)

contract/Promotion

(i) Joint Secretary, Department
ofHealth -Chairman

(ii) Deputy Director General of
Health Services -Member

Consultation with UpSC
is necessary.

(iii) Director/Deputy Secretary
(Administration), Mhistry of
Health and Family WelfareMember.

{b) possessing the educarional qualificaLions and experience prescribed
for
orrect recrurts under Col.

I
\Ti"g officer with 5 years

regular service in lhe grade shall also be
1r:
consroered
atong with the oulsiders ard in case he/she is selected
for
appointment to the post, the same shall be deemed t" r,"r"
tii"a ty
promotion.
(The Departmental oflicers in thc feede. category
who are in the direct line of

t"_

11r.:ii- :l"ll nor

etigibte for coniidiration fo, tpoi";.;;';

.be
oepularron. Slmtlarl). deputationsts
shall nol be eligible for consideration for
appointment by promotion.)
[Period of deputation/contract including period of deputalior/contract in

another ex-cadrepost h€ld immedialely preceding

lhis appointmenl in th;;;;

or.some olher Organizalion/Departmenr of the Central
Govemment shall
orornaflty nol exceed .J )ears. The maximum age limil
for appointment
deputation
.(including short t€rm conrract) ,h"ll
on the closing date ofreceiDt ofaDDlicatrons

t?; ;;;;;;;ffi;;

bj

;

lF. No. A. l20l 4/02l202I\yDGHSl
ITndcr Sc.relaru f^ rhc (lnvcmmFnf

<!-- page 7 -->

Annexure-III
FORM TO BE FILLED BY THE MINISTRY/DEPARTMENT WHILE FORWARDING PROPOSALS TO THE
DEPARTMENT OF PERSONNEL & TRAINING AND THE UPSC FOR AMENDMENT IN APPROVED

nEcRutrMrxr RUI-ES (ls pER urH cpc )

l. (u) Nu-e ofthe port

Nursing Advisor

(U) tVame oftne V

Ministry of Healrh &

Family

Welfare,

Directorate General of

Health

Services,

3.

Not applicable

conveved.
Date of Notific"tio

original rules and subsequent amendments should Le enclosed,
referenced).

duly ilagged and

GSR No......dated t5.o5.t 926
GSR No.l56 dated 17.04.2004

Provisions in th€ appro"edleri-siog rules
No. ofPost(s)

(Gazetted, Non -Ministerial)

Rs. 14300400-18304

Pay Level-I3 in the

pay mahix

(Rs. 123 t00215900) as per 7e
CPC

As per 6e CpC (CCS
RP rules 200E), the pay

scales of Rs. 14300400-18300 has been

placed in the Pay Band-

4, Rs.37400-67000 +
GP of Rs. 87001
Subsequently as per 7s

CPC (CCS RP rules
2016) the pay scale
with GP Rs.8700/- has
been placed in pay
Level-13(Rs. I23100215900) of the pay
matrix.

Whether age &
educational

qualifications

prescribed for direct
recruits will apply in

Not Applicable

<!-- page 8 -->

l^

contracVpromotional

post and DR has not
been proposed as a

I

method ofrecruitment.

100% Deputation

Deputation including short term contracvpromotion

Recruitment, whether
by Direct Recruitment
or by promotion or by

including short term
contracvpromotion.

deputation /absorprion
and o/oage of the post
to be filled by various
methods.
In case of recruitment

by

promotion
/deputatior/absorption

grades from which
promotion/ deputation/
absorption to be made.

D e putat i on ( i nc lud i ng s hor t- te rm c onlr ac t) /pri nn t ion:

1. Officers under the Central Government/ State
Governments/ Union Territories/Autonomous.
(a) (i) Holding analogous post on regular basis in the
parent Cadre/ Department; or

(ii) with 5 years' service in the grade rendered after
appointment thereto on a regular basis in the pay Level_
12 ( Rs. 78800-209200L) ofthe pay matrix (pBi- with

Grade Pay fu 7600/-in the pre-revised scale ofpay) or
equivalent in the parent cadre/Department; or

(iii) with l0 years' service in the grade rendered after

appointment thereto on a regular basis in the pay LevelI I (Rs. 67700-208700/-) of the pay matrix (pti-3 viith
Grade Pay Rs._ 6600/- in the pre-revised scale ofpay)
or
equivalent in the parent cadre/Department; or
(b) Possessing following educational qualifications
and

expenence;

(i) Master s degree in Nursing from a recognize
Universiry/Institution or equivaleni

(ii) l2 years-exp€rience in Nursing/ Teaching including

Communiry Healrh Services: and

(iii) Registered as Nurses and Midwife or eouivalent

with any State Nursing Council;

I
|

Promotion

'- Direcror'General (Nursing) wirh year,s
II. Assistant
5

reguJar service in the grade failing which *ith

l0 year,s

General (Nursing) and Deputy Assistant Director

General

combined service in the grade of Assistant Director

(Nursing) and Depury Nursing Adviser

and possessin!
Masteas Degree in Nursing liom a recognizej
Universiry/lnsritution or equivalent and registeid
as
Nurse and midwife with any state Nursing CJuncil
shall

also be considered alongwirh outsiders and in
case he/she
is selected for appointment to the post, the same
shall be
deemed to have been filled by promotion.

(The Depanmenhl Offjcers in rhe feeder

category who

are in.the direct line ofpromotion will nor be

eiigi6t" fo,

consideration for appointment on deputationists ;hall

not

be eligible for consideration for appointment by

promotion.)

<!-- page 9 -->

[Period of deputation/contract including period of
deputation in another ex-cadre post held immediately
preceding this appointment in the same or some other
organizatior/department of the Central Government shall
not exceed 5 years. The maximum age limit for
appointment by deputation (including short term
contract) shall be not exceeding 56 years as on the
closing date of receipt ofapplications.]

If a DPC exists, what Not Applicable

Not Applicable

is its composition.

DOP&Tguidelines,DPC

is not needed for
recruitment on
Deputation including

short

term

contract/promotion.

Circumstances in
which U.P.S.C. is to

be consulted in
making recruitment.

Consultation *ith union
necessary.

publi.Ti*lii?or hi

No Change

As the method of
Recruitment is
Deputation ( including
short term

contract)/promotion,
consultation with UPSC

is necessary.

<!-- page 10 -->

Annexure-III

RECRUITMENT RULES (AS PER 7TH CPC )

1. (a) Name ofthe post

Assistant Director Ceneral ( Nursing)

(b) Name of the Ministry/Department

Ministry of Health &

Family

Welfare,

Directorate General of

z.
J.

Kererence No. tn whtch Commission,s Advice on Recruitment Rules
was
cqnveved.
rrare or Nonnca on ot the ortginat rules and subsequent amendments (copy

original rules and subsequent amendments should

ofthe

-be

referenced).

enclosed, duly flagged and

Health

Services,

Not applicable
GSR No......dated 15.05.1926
csR No.t56 dated 17.04.2004

4.

Column No.

Proyisions in the approved/exi-sting rules

Name ofthe Post

Assistant Director Gegeral (Nursiryj

No. ofPost(s)

I

Reasons for the

Assistant Director

r Evrrrurl proposeq
No Change

flenaEl /r\i,,..i-^\

Classification
(Gazetted, Non

I

Revised provisions

Scale ofPay

-Ministerial)

I\s. lzuuu-J /)-lo)uo

I

I

No Change

Class I

No Change

(Gazetted, .llon Ministerial)
Pay Level-I2 in the
pay matrix
(Rs. 78800-209200)
as per 76 CpC

As per 6s CPCJCCS
RP rules 2008) the pay
scales of Rs. 12000-

375-16500 has been
placed in the Pay Band-

3, Rs.15600-39100 +
GP of Rs. 7600/Subsequently as per 7'h

CPC (CCS RP rUICS
2016) the pay scate
with CP Rs.7600^ has
been placed in pav I
Level-12(Rs. 78300209200) of the pay
]
I

|

matrix
Whether Selection
post or Non-Selection

Not Apptt"abl"

Not Applicable

No Change

Not Applicable

No Change

Not Applicable

No Change

Not Applicable

No Change

Not Applicable

It is a Deputation

_p9!1.

Age limit for Direct
Recruits

Educational and other
qualifications required
for Direct Recruitment

Whether ag" &
educational

qualifications

prescribed for direct

recruits will apply in
the case ofpromotees.

)eriod of probation,

if

Not Aoolicable

I
I

<!-- page 11 -->

o
j{tY

including short term
confact/promotional

post and DR has not
been proposed as a
method ofrecruitment.

Recruitment. whether
by Direct Recruitment
or by promotion or by

100% Deputation

Deputatian including short term conBact/promotion

including shon term
contract/promotion.

deputation /absorption
and Yoage of the post
to be filled by various
methods.
In case of recruitment

by

promotion
/deputation/absorption
grades fiom which
promotion/ deputation/
absorption to be made.

D e put ql ion( i nclud i n g s hortte r m c ontract)/p, o, o t ion

Deputation (lncluding short-term contract)/promotioo:

Officers under the Central Governmenvstate
organizations:-

(a)(i) holding analogous post on regular basis in the
parent cadre/ deparnnenq or

(ii) with 5 years, service in the grade rendered after
appointment thereto on a regular basis in Level _l I (Rs.
67700-208700) of the pay matrix or equivalent in the

parent cadre or depanment; or

(iii) wilh l0 years ofservice in the grade rendered after
appointment thereto on a regular basis in Level _10 (Rs.
56100-177500) of the pay matrix or equivalent in the

parent cadre/Department; and

(b). Possessing the following educational qualifications
and experience.

(i)Master's- Degree in Nursing from a recognlzed
University/Institution or equivalenr;

(ii) Must be a registered Nurse and Registered Midwife
or.equivalent with any state Nursing Council;

(iii) l0 years.' experience in Nursirig/Teaching including

Community Health Servicei

II Deputy Nursing Adviser /Depury Assistanl Director
Ceneral (Nursing) with 5 year'i regular service in
the
grade; failing which l0 year,s combined service in
the

grade of Deputy Asstt. Director General

(Nursing)/Deputy Nursing Adviser and Nursing
Officer

-from

possessing Master,s Degree in Nursing
a
recognized University/Institution of equi-valent and
registered Nurse and midwife or equiva-lent with
any
State Nursing Council shall also be considered alon!
with outsiders and in case he/she in selected foi
appointment to the post, the same shall be deemed
to
have been filled by promotion.

(The Departmental officers in the feeder category
who
are in the. direct line of promotion stra not U-e eiiglble

for
..consideration for appointment on deputaiion.
Similarly. depuhtionists shall not be eligible for

<!-- page 12 -->

[Period of deputatior/contract including period of
deputatior/contract in another ex-cadre post held
immediately preceding this appoinrment in the same or
some other Organillon/Departrnent of the Central
Govemment shall ordinarily not exceed 4 years. Jhe
maximum age limit for appointment by deputation

(including short term contract) shall be not exceeding 56
years as on the closing ofreceipt ofapplications.

If a DPC exists, what
I

is its composition.

DOP&Tguidelines,DPC

is not needed for
recruitment on
Deputation including

short

term

contract/promotion.

Circumstances in
which U.P.S.C. is to

be

consulted in

making recruitment.

Consultation lrith UniorTubtiiTervice6-misilonT

As the method of
Recruitment is
Deputation ( including
short term

contract)/promotion
consultation with UpSC

<!-- page 13 -->

Annexure-III
DEPARTMENT OF PERSONNEL & TRAINING AND THE UPSC FOR AMENDMENT IN APPROVED
RECRUI.rwtENT RUlns (ls prn zrrr cpc I
I

(a) Name ofthe post

Deputy Assistant Director General
(Nursine)

(b) Name of the Ministry/Department

Ministry of Health &

Family

Welfare,

Directorate General of Health

z.

Services,

Kererence No. ln whlch Commission's Advice on Recruitment Rules was
conveved.

Not applicable

original rules and subsequent amendnients should Le enclosed, duly flagged

GSR No......dated 15.05. 1926
GSR No.l 56 dated 17 .04.2004

J. Dale or Nolncatlon ot the original rules and subsequent amendments (copy ofthe
referenced).

and

Provisions in the approved/exisling rules
Name ofthe Post

Deputy Assistant Director General

On the basis of
observation of

lNursin$

UPSC(copy enclosed) it

has been decided to
split the RR for DADG

No. of Post(s)

and DNA
(Gazetted, Non -Ministerial)
Rs. 10000-325-15200

Pay trvel-l I in the
pay matrix
(Rs. 67700-208700)
as per 7h CpC

As per 6' CPC, (CCS
RP rules 2008) the pay

scales of Rs. 10000-

325-15200 has been
placed in the Pay BandRs.15600-39100 +
GP
Rs. 6600/Subsequently as per id

3,

of

CPC (CCS RP rutes
2016) the pay scale
with GP Rs.6600/- has
been placed in pay

Level-l l(Rs. 67700-

208700) of the pay
matrix.

Age limit for Direct

Not exceeding 40 years

Educational and other

Essential:

qualifi cations required

Degree in Nursing from a recognized
flY*,:l's,.
University/Institulion or

for

Recruitment

Direct

equivale-nt;

(ii) Must te a registered Nurse and Regisrered Midwife

or.eq_uivalent with any state Nursing Council;
(iii) 5 years'. experience in Nursin!{eaching

Lommunity Health Service.

including

Not Change

<!-- page 14 -->

Note 1 :

Qualification are relaxable at the discretion ofthe UPSC
in case ofcandidates otherwise well qualified.
Note: 2

The qualification (s) regarding experience is/are

tlffiil, :: "l] T:{H: :i i:":,:il.';:rd,il'::

Whether age &
educational

qualifications

Scheduled Casts/Scheduled Tribes, il at any stage of
selection the Union Public Service Commission is of the
opinion that sumcient number of candidates from these
communities processing the requisite experience are not
likely to be available to fill up the vacancies reserved
for them.
Age: No
Educational Qualifications: yes

prescribed for direct
recruits will apply in
Two years for Direct Recruits

Recruitment, whether
by Direct Recruitment
or by promotion or by

Deputation(includingshortErm;;h"ctyp.o-.t.--o-otio"
tailing which b) Direct Recruitment

deputation /absorption
al],d Yoage of the post
to be filled by various

methods.
ln case of recruitmJnt-

bY

promotion
/deputatior/absor?tion

grades from which
promotior/
deputation/ absorption
to be made.

Deputation(including

thrr-Ern

"rnt

rcwrnotlon:

Depltation (Including short-term contract):

I Officers under the Central Govemment/State
Govemment{Jnion
tenitories/autonomous

organizations;-

(a)(i) holding analogous post on regular basis

parent cadre or department; or

in the

(ii) with 5 years'service in the grade rendered after

on a regular Uasis in r_evet _e
:t?::1ry1!1"r"to
lns.
pay
53100-167800)

of the

parent cadre/Department; or

matrix or equivalent in the

(iii) With 8 years'se'*ic. in the grade rendered

after

rhereto on a regular basis in Level -7 (Rs.
3qn,:lr:it
44900-1424001 of the pay marix or equivalent
in the
parent cadre/Department; and

(b) possessing the educational qualifications and'
experience prescribed for direct recruiis under

Col. 8

II. Nursing officer with 5 years regular service in the

grade shall also be considered along with

the outsiders

and in case he/she is selected fo, -uppoint*"niio
tt.
post, the same shall be deemed to have been
filled bv
promotion.

<!-- page 15 -->

(The Departmental officers in the feeder category who
are in the direct line of promotion shall not be eligible

for consideration for appointment on deputation.

Similarly, deputationsts shall not be eligible for
consideration for appointment by promotion.)

IPeriod of deputation/contract including period of

deputatior/contract in another ex-cadre post held

immediately preceding this appointment in the same or

some other Organization/Department of the Central
Govemmenl shall ordinarily not exceed "3 years. The
maximum age limit for appointment by deputation

lf a DPC exists, what

(including short term contract) shall be not exceeding 56
as on the closing date ofreceipt of

is its composition.

DOP&Tguidelines,DPC

is not needed for
recruitment on
Deputation including

short

term

contracvpromotion.

Circumstances in
which U.P.S.C. is to
be consulted in

Consultation with Union pu6lic Sen i"-e Com;issi,o" i"
necessary.

making recruitment.

As the method of
Recruitment is
Deputation ( including
short term

contract)/promotion
failing which by Direct
Recruitment,
consultation with UpSC

tb

<!-- page 16 -->

Annexure-III

RECRUITMENT RULES (AS PER TIII CPC )

I. (a) Name ofthe post

Deputy Nursing Advisor

(b) Name of the Ministry/Department

Ministry of Health &

Family

Welfare,

Directorate General of Health

z. r(ererence No. rn wnrch commlssion's Advice on Recruitment Rules was
conveved.
r. ualc or r\ouncauon oI..the ongtnal rules and subsequent

amendments (copy ofthe

original rules and subsequent amendments should-be enclosed, duly flagged
referenced).

and

Services,

Not applicable
GSR No......dated 15.05. 1926
GSR No.156 dared 17.04.2004

Provisions in the &pproved/existing rules
Name ofthe Post

On the basis of
observation of
UPSC(copy enclosed) it

has been decided to
split rhe RR for DADG
and DNA

No. ofPosr(s)

(Gazetted, Non -Ministerial)

Rs. 10000-325-t5200

Pay Level-l I in the
pay matrix
(Rs. 67700-208700)
as per 7d CpC

As per 6' CpC, (CCRP rules 2008) the pay

scales of Rs. 10000-

325-15200 has been
placed in the Pay Band-

3, Rs.15600-39100 +
GP of Rs. 6600/-.
Subsequently as per 7ft

CPC (CCS RP rules
2016) the pay scale
with GP Rs.6600/- has
been placed in pay

Level-l l(Rs. 67700-

208700) of rhe pay
matrix.
post or Non-Selection
Not exceeding 40 yeag
Educational and other

qualifications required
for Direct Recruitment

Degree in Nursing fiom a recognized
lilflastgr'1.
U ntversity/lnstitution or equivalenti
(ii) Must be a registered Nurse and Registered
Midwife

or.equivalent with any state Nursing Council;
(llr) 5 years'. experience in Nursing/Teaching
including
Community Health Service.

<!-- page 17 -->

Notel:
Qualification are relaxable at the discretion ofthe UpSC
in case ofcandidates otherwise well qualified.
Note: 2
The qualification (s) regarding experience is/are
relaxable at eh discretion ofthe Union public Servicd
Commission in the case ofcandidates betonging to
Scheduled Casts/Scheduled Tribes, if, at any stage of
selection the Union Public Service Commission is ofthe
opinion that sufficient number ofcandidates from these
communilies processing the requisite experience are not
Iikely to be available to fill up the vacancies reserved for

Whether age &
educational

qualifications

them.

Age: No
Educational Qualifications: Yes

prescribed For direct
recruits will apply in
Period of probation, if

Two years for Direct Recruits

It is a Deputation

any

including short term
contracvpromotional
post and DR has not
been proposed as a

Recruitment, whether
by Direct Recruitment
or by promotion or by

Deputation( including short term conGctypi orioi'

failing which by Direct Recruitment

deputation /absorption
and Yoage of the post
to be filled by various
methods.
In case of recruitment

by

promotion

/deputation /absorption

grades from which
promotion/
deputation/ absorption
to be made.

Depula t io n (inc luding t h o

"t-

te

r,

"ortrac

typ, o, o t i oi

Deputation (Including short-term contract):

I Officers under the Central Govemment/State
organizations;-

(a)(i) holding analogous post on regular basis in the
parent cadre or department; or

(ii) with 5 years,service in the grade rendered a.fter

1lqglntm€nt thereto on a regular basis in Level -9 (Rs.
53100-167800) of the pay matrix or equivalent in the
parent cadre/Departsnenl or

(iii) With 8 years' service in the grade rendered afler
a regular basis in Level -7 1Rs.
Tl9,-ntln:nt rherelo onpay
44900-142400) of the
matrix or equjvalenr in the

parent cadrelDepartment; and

(b) possessing the educational qualifications and

experience prescribed for direct recruits under Col. g

Il. Nursing officer with 5 years regular service in the
grade shall also be considered along with the outsiders
and in case helshe is selected for

method of recruitment.

No Change.

<!-- page 18 -->

post, the same shall be deemed to have been filled by

promotion.

(The Departonental officers in the feeder category who
are in the direct line of promotion shall not be eligible

for consideration for appoinlment on deputation.

Similarly, deputationsts shall not be eligible for
consideration for appointment by promotion.)

[Period of deputation/contract including period of
deputation/conhact in another ex<adre post held
immediately preceding this appointment in the same or
some othq Organization/Department of the Central
Govemment shall ordinarily not exceed 3 years. The
maximum age limit. for appointment by deputation

If a DPC exists, what
is its composition.

(including short term contract) shall be not exceeding 56
years as on the closins date ofreceiDt of applications:'l
Not Applicable
Not Applicable
DOP&Tguidelines,DPC

is not needed for
recruitment on
D€putation including

short

term

contract/promotion.

Circumstances in
which U.P.S.C. is to
be consulted in

Consultation with Union Public Service Commission is
necessary.

making recruitment.

No Change

As the method of
Recruitment is
Deputation ( including
short term

contract)/promotion
failing which by Direct
Recruitment,
consultation with UPSC

is necessary.

a
