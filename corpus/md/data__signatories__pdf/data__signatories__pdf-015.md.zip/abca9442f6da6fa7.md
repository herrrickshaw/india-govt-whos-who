---
doc_id: "abca9442f6da6fa7"
source_url: "https://www.dot.gov.in/static/uploads/2026/09/ba4e7ea089d530d11de297a3efe603ee.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Retirement on Superannuation of Director (CFA) BSNL- Shri Vivek Banzal"
date: "2026-09-25"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c48ae4a7b2bff058"
---

<!-- page 1 -->

No. E-1-4/2022-PSA
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road
New Delhi — 110 001
Dated 25 September 2026
Subject: Superannuation of Shri Vivek Banzal, Director (Consumer Fixed Access), Bharat
Sanchar Nigam Limited
Consequent upon attaining the age of superannuation, Shri Vivek Banzal, Director
(Consumer Fixed Access), Bharat Sanchar Nigam Limited will cease to be in service with effect
from the afternoon of 30.9.2026.
pic
se
(Amit Kundan)
Under Secretary to the Government of India
Tel.: 011 2303 6884
Email: admin2-dot@nic.in
Copy to:
1. Shri Vivek Banzal, Director (Consumer Fixed Access), Bharat Sanchar Nigam
Limited, Janpath, New Delhi — 110 001
2. Office of the Establishment Officer and Additional Secretary, Appointments
Committee of the Cabinet, Department of Personnel and Training, Kartavya Bhawan-
3, New Delhi—110 001
3. Secretary, Public Enterprises Selection Board, Public Enterprises Bhawan, Block No.
14, CGO Complex, Lodhi Road, New Delhi — 110 003
4. Private Secretary to Hon’ble Minister of Communications, Sanchar Bhawan, New
Delhi
5. Private Secretary to Hon’ble Minister of State for Communications, Sanchar Bhawan,
New Delhi
6. Principal Staff Officer to Secretary, Department of Telecommunications (DoT)
7. Principal Private Secretary to Member (Finance), DoT
8. Senior Principal Private Secretary to Additional Secretary (Telecommunications),
DoT
9. Company Secretary, Bharat Sanchar Nigam Limited, Janpath, New Delhi — 110 001
10. Senior Principal Private Secretary to Joint Secretary (Administration) / Joint Secretary
(Telecommunications) / Deputy Director General (Staff Unit), DoT
11. Chairman and Managing Directors, Mahanagar Telephone Nigam Limited /
Telecommunications Consultants India Limited / Bharat Sanchar Nigam Limited
12. Web Administrator for uploading on the website of Department
13. Deputy Director (Official Language), DoT, Sanchar Bhawan, New Delhi, with the
request to provide Hindi Translation of the order
14. Office order / Guard file
