---
doc_id: "ac7ab09a53fbf9e7"
source_url: "https://master-jalshakti-ddws.digifootprint.gov.in/static/uploads/2024/10/fe9c4b41b04c17a9ac87d067f3daeb6a.pdf"
ministry: "Department of Drinking Water and Sanitation (DDWS)"
title: "Work Allocation Order"
date: "2024-10-31"
pages: 18
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "10ba55c3ba257f51"
---

<!-- page 1 -->

. No. A-19011/21/2024-Admin (28107)
te Government of India
हु Ministry of Jal Shakti
Department of Drinking Water & Sanitation
KK
Pt. Deendayal ‘Antyodaya’ Bhawan,
CGO Complex, Lodhi Road,
New Delhi — 110003.
Dated : 315 October 2024,
OFFICE ORDER
In pursuance of Department of Personnel & Training’s Order No. 36/01/2024-
EO(SM-I) dated 16.08.2024, Shri Ashok Kumar K. Meena, IAS (OR:93) takes over as
Secretary, Department of Drinking Water & Sanitation in Pay Level — 17 (Rs. 2,25,000/-
fixed) with effect from the afternoon of 31.10.2024,
(jp Tint,
(Surojit Ghosh)
Deputy Secretary to the Govt. of India
011 2436 8774
Email : s,ghosh@pnic.in
To, :
1. Shri Ashok Kumar K. Meena, IAS(OR:93), Secretary, DD WS.
2. The Pay and Accounts Officer, DDWS.
3. Cash Section, DDWS. °
bo a
Copy to: we
1. PS to Hon’ble Minister, Jal Shakti.
2. PS to Hon’ble MoS, Jal Shalcti, D/o DWS.
3. PPS to Secretary, D/o DWS.
4. PPS to Secretary, D/o WR, RD & GR. .
5. Sr. PPS to AS & MD (JJM), DDWS.
6. PPS/PS to EA (Estt., Gen., Coord., & Parl)/ JS & MD (SBM) JS & FA /JS (JJM).
7. PS to DDG (Stat), DDWS.
8. Cabinet Secretariat (Ms, Mrunmai Joshi, Deputy Secretary), Rashtrapati Bhawan,
New Delhi.
. 9. The Chief Secretary, Government of Odisha, Bhubaneswar.
10. The Accountant General (A&E), Govt. of Odisha, Bhubaneswar.
11. Department of Personnel & Training [Kind Attn.: Ms. Sakshi Mittal, Director (SM-
Q], North Block, New Dethi — w.r.t. their communication mentioned above.
12. DDG, NIC, DDWS.
13. All officers & Staff, D/o DWS — through e-office Notice Board.
14. General Section/Vigilance, DD WS हा
15, Service Book of the Officer/ Guard File/ Issue Folder.
16. NIC, DD WS — for necessary action.

<!-- page 2 -->

No, A-19011/2/2025-Admin (28860)
- Government of India
- Ministry of Jal Shakti to. et
. Department of Drinking Water & Sanitation
has
Pt. Deendayal ‘Antyodaya’ Bhawan,
CGO Complex, Lodhi Road,
New Defhi— 110003.
Dated ; 7 January 2025,
OFTICE ORDER
4, #
. Tn pursuance of Department of Personnel & Training’s communication No. हि हि
36/02/2025-EO(SM-1) dated 03.01.2025, Shvi Kamal Kishore Soan, IAS (78:98), is . pet tee
appointed as Additional Secretary & Mission Director (MD), J al Jeevan Mission (JJM) in. .
करना the Department of Drinking Water & Sanitation, Ministry of Jal Shakti with effect from *
06.01.2025 (FN). ¢ ip AD है
(80० Ghosh)
Deputy Secretary to the Govt, of India
O11 2436 8774
Email : s.ghosh@uic.in
To, हे का ne F
{, Shri Kamal Kishore Soan, AS & MD (JM), DDWS.
2. The Pay and Accounts Officer, DDWS.
3, Cash Section, DDWS. हि
. Copy to:
११ #1. PS to Hon'ble Minister, Jal Shakti.
nt 2. PS to Hon’ble MoS, Jal Shakti, D/o DWS.
3. PPS to Secretary, D/o DWS.
j 4. Sv, PPS to AS & MD (JJM), DDWS. >» * :
हर 5. PPS/PS to BA (Estt., Gen., Coord., & Parl)/ 1S & शा) (8800)/18 & ४8 /78 670). "५ जा
6. PS to DDG (Stat). oe
Peetten enn 7, Cabinet Secretariat (Ms. Mrunmai Joshi, Deputy Secretary), Rashtrapati Bhawan,
New Delhi.
8. The Chief Secretary, Government of Jharkhand, Ranchi.
9, The Accountant General (A&E), Govt. of Jharkhand, Ranchi.
10, Depattinent of Personnel & Training {Kind Atin.: Ms, Sakshi Mittal, Dixector (SM-
J, North Block, New Delhi -~ w.t-t. their communication mentioned above.
11, Ministry of Labour & Employment [Shxi S. V. Ramana, Dy. Secy.], Shram Shakti
Bhawan, New Delhi — with the request to forward Service Book and LPC ix.0.
the officer, .
12, All officers & Staff, D/o DWS — through e-offive Notice Board. :
13, General/ Vigilance/ Coord./ Part. Section, DD WS “ 2 oF
14. Service Book/ Guard File/ Issue Folder, .
15. NIC, DDWS — for necessary action.
we
2 .
: हि ४...
coun गे Jy

<!-- page 3 -->

‘ No. A-11018/1/2015-Admin
Government of India
_ Ministry of Jal Shakti
Department of Drinking Water & Sanitation
gt Floor, P. Desndayal
‘Antodaya’ Bhawan, CGO Complex,
Lodhi Road, New Delhi ~ 110 003.
Dated: 10.03.2025.
/ OFFICE ORDER ;
In pursuance of CVC's OM no. 014-CVO-04 dated 06.03.2025, Shri
Kamal Kishore Soan, IAS (JH:1998), AS & MD (NJJM) is hereby designated
as the part-time Chief Vigilance Officer (CVO) of the Department of Drinking
Water and Sanitation initially for a period of 03 (three) years wet,
10.03.2025(FN). :
A . / oO
2. This issues with approval of the competent authority. तप
. (Surojit Ghosh)
Deputy Secretary to the Govt. of India
Tel: 011-2436 8774
e-mail: s.ghosh@nic.in
To,
. 4. Shri Kamal Kishore Soan, AS & MD (NJJM) & CVO, DDWS
2. PS to Hon'ble Minister (DDWS)
3. PS to Hon’ble MOS (DDWS)
4. PPS to Secretary (DDWS)
5. PS to EA (Gen., Estt., Coord. & Parl.\/DDG (Stat.)/ JS & FA, DDWS . : :
6. PPS fo JS & MD (SBM-G), DDWS :
7. PPS to JS (JJM), DDWS
8. All Other Officers (DDWS) through e-office Dashboard
. 9. Central Vigilance Commission, (Kind attn.: Anirban Biswas, Under
हल Secretary), Satarkta Bhawan, G.P.O, Complex, Block A, INA, New Delhi |
-110023. W.r-t-No. 014-CVO-04 dated 10.03.2025. :
10. शी ४ -With request to upload the order on the official website of

<!-- page 4 -->

| i
\ No. S-18012/4/2023-SBM-DD WS |
Government of India |
Ministry of Jal Shakti
i Department of Drinking Water and Sanitation
| (SBM Wing)
l Pt, Deendayal ‘Antyodaya Bhawan’
| CGO Complex, New Detbi :
i . Dated the 2" December, 2024.
|
\
OFFICE ORDER
i
|
| Subject: Work distribution among SBM Divisions
Revised work distribution among different Divisions/Sections of SBM-G, is attached for
information.
i 2, Sh. Abhas Jain, Asst. Adviser will support SBM-II, SBM-V and SBM-VI,
3. This issues with the approval of IS& MD, SBM. t
ye, है
i K 2 हे lay
| (Karanjit Singh)
Director (SBM)
| Copy to:
i 1, PPS to Sceretary, DWS
| 2, PPS to JS & MD (SBM-G)
| 3, All Director/DS, SBM Wing
| 4, All Sections of SBM Wing
5, US (Establishment), DDWS
|
i
|
1
| Page 1of8
|
i

<!-- page 5 -->

Revised Work Distribution in SBM-G (03/10/2024)
SECTION Work SUPPORTING
CONSULTANTS
SBM-I > SBM Budgetary matters -Allocation and release of funds to / 1. Bharat Rao- Monitoring
Ms. Kritika States/UTs of release and utilization
(Budget, | Kulhari, of funds/is® FC/
policy Deputy ® Extra Budgetary Resources (EBR) matters MGNREGS/PFMS/SNA
and Secretary > Correspondence with other Min/Depts. on the issues relating to | SPARSH/ SBK
capacity SBM policy/budget-Comments on EFC / Cabinet Notes of other
building) Min/Depts. 2. Meeta Jaruhar and
> PFMS implementation Junaid - AIP & NSSC
> DBT mechanism for IHHLs- Matters relating to end to end
digitization for IHHLs 3. Impact Studies /|
* Payment of NPCI’s DBT transaction charges Research papers — Aditi,
> Interna! Audit matters Aram, Jayant
> Budget announcements & PM announcements
>» SBM-G Policy matters (EFC, Cabinet Notes) & Guidelines} 4. Junaid ~ for budget
(amendments, clarifications) announcement & PM
> Coord. reg. 15th Finance Commission tied grants for sanitation & | announcement
E-Gramswaraj, GPDP/ BDP/ DDP
> MGNREGS including expenditure monitoring and liaising with} 5.Tokeer and Neeraj
MoRD Tiwari- Capacity building
> AIP preparation and meetings.
> PMU matters including WASHi or other development partner’s | 6.Meeta, Mritunjay
manpower support matters Chandra, Sridhar
> Capacity Building matters - coordination with programme division | Selvaraj, Junaid-Inter-
for preparation of training calendar for SPM-NIWAS and| ministerial /international
coordination with States for participation, support activities in | coordination and
States, Key Resource Centres (KRCs), WASH cells in SIRDs, SBM | convergence.
academy, documentation of best practices, etc.
Page 2 of 8

<!-- page 6 -->

नल नपनननतननतननननननननननन ललनतननननिकनननन नन  नतनननननन मत नल नम न नल एएएएएएएएएए7एस्‍न्‍तख./.).
> Special projects 7.Mritunjay Chandra,
> Inter-ministerial convergence matters Tokeer and Neeraj for
> International Co-operation including UNICEF, World Bank, BMGF, | SBM Academy &
WHO, etc. documentation of best

> Swachh Bharat Kosh practices
> SBK
> Impact Studies / Research Papers 8.Meeta, Asis, Aditi,
> Visian 2029/2047 Subashish, Neeraj,

Shivani-Vision 2029/2047

as weil as for Special

Projects

g. Bharat Rao - SBK

4a
Page 3 of 8

<!-- page 7 -->

snp ntsc LL A गए गए "7" ।ि 77.77 7+
SECTION OFFICER Work — SUPPORTING
CONSULTANTS
SBM-II Shri K. > SBM(G) MIS, Mobile app, dashboard, development of | 1. Russi Singh & Aram
{MIS Srinivasu, modules, server and related State specific issues, and | Tauheed-SSG and M&E
| and Deputy website development
M&E) Secretary 2. Rajnish Sharma - MIS &
> Technical Advisory Committee/ Other technical | Website Development
Committees/ Sub committee
> Rashtriya Swachhata Kendra (RSK) 3. Dr. Vishwaranjan and
Ravindra Bohra - RSK
| > Monitoring reg obtaining feedback by Consultants in
i ODF-Plus (Model) villages (by tele-calling) as weil as
social audit. 4. Aram Tauheed, Russi Singh
and Junaid- Review meetings
| > SSG under SBM(G) Phase-II
| » CAG Paras/PAC Paras 5. Russi, Junaid- Aspirational
| districts, Mission  Utkarsh,
~ ODF Plus monitoring and review meetings under | SAGY, Vibrant village
SBM(G) Phase-II-both of IMIS as well as interaction
with States. 6 Russi Singh and Junaid -
i For OOMF
| > Output Outcome Monitoring Framework (OOMF)
| x Programme implementation in Aspirational districts, 7. Meeta Jaruhar and Russi
SAGY villages and related Issues, Vibrant village Singh, Aram - Fieid Visits
programme
>» Review meetings and conferences
> Field visits
Page 4 of 8

<!-- page 8 -->

SECTION | OFFICER | | XT SUPPORTING CONSULTANTS
SBM-III | Ms. Swapna > Grey Water Management
Devireddy, > FSM 1. Asis and Bharat Rao~ INHLs/CSCs
(LWM & | Director “ . . ituniay Cl
FSM) >» IHHL s/CSC 2.Sridhar Selvaraj and Mritunjay Chandre—
>G a Ic maiter Surveys/Studies/Grand
> Grand Challenges Challenge
> Swachta Gi Leaf Rating (SGLR
7 Sw reen Lee ing ( ) 3.Shivani Sood, Jayant Srivastava and
> Matters relating to LIFE/WASH Piyush kumar- FSM/SGLR
>» IMP
4. Shivani, Jayant Srivastava and Piyush
dinati Ni i Gi
+ Coordination reg. Namami Gange Kumar- Grey Water Management
i > NAMASTE ५ ne
| . Asis, Sridh Ivaraj and Ajeet Singh -
| > RWPF / Light House Initiative (LHI)/CSR Sup is, Sridhar Selvaraj and Ajeet Singh
i
| |
| 6. Mritunjay, Sridhar Selvaraj~ Mission- |
i LIFE/WASH
|
7.. Ravindra Bohra- Namami Gange
8. NAMASTE - Shivani, Jayant |
9. RWPF/LHI/CSR — Meeta, Mritunjay, LHI
team given by ISC*
*(may use for other tasks also as decided
by Director)
Page 5 of 8

<!-- page 9 -->

SECTION OFFICER 1[_._._._._._...€.€.€[.[]]]] शकऋऋ___._. SC SUPPORTING CONSULTANTS
SBM-4 Shri Sanjay 1. Sridhar Selvaraj, Junaid and
Sinha, > SBM Coordination Mritunjay- Public Grievances and
(Coordina- | Director other coordination matter
tion > Parliamentary matters - Questions, Rule 377,
Special Mention, Assurances, etc. Standing |2. Neeraj, Taukeer and Mritunjay
/Consuitative Committees Chandra - Swachh Iconic Places
(SIP), Swachhata Action Plan (SIP),
> Monthly progress reports - DO letter for Cab | Swacchata Pakhwada
i Secy, PMO, MoJS, Cabinet decisions
i milestones, SGoS recommendations
> Public Grievances (PMOGPG, CPGRAMS, DDWS | 3.Junaid- for Parliamentary matters
PG, etc) and monthly reports/ state field
+ VIP/PMO/ President Sectt/ Cab Sec references | visits
> RTI Matters/RTI Appeal (including Appeals filed
before CIC) 4. PM GATI SHAKTI-Mritunjay
Chandra
> Court Cases/Legal matters
5. Junaid - Annual report
> Swachh Iconic Places (SIP)/Swachhata Action
Plan (SAP)/Swachhata Pakhnwada 6.Sridhar, Junaid - PM JANMAN
> SHS
!
> Annual Report
> E-Office
| > PM GATIShakti
> PM JANMAN
>_Review of UTs
Page 6 of 8

<!-- page 10 -->

scncrmeneurtuenrwonrinnnnios uti RR
SECTION [OFFICER | CW  शछाए SUPPORTING CONSULTANTS
SBM-5 Shri Karanjit
i Singh, Director > SWM 1.Baldev Bharti, Pankaj and
(SWM & Subashish- Circular Economy/Green
Gobardhan) > Matters relating to Circular Economy credit
. > Matters relating to Green Credit 2.Asis Sadhu, Ajeet Singh and Baldev
Bharti, Subashish- SWM
> GOBARdhan
3.Baldev Bharti, Pankaj Kumar,
> Menstrual Health Management Sucheta Deb and Subashish Parida-
Gobardhan
> E-waste, Industrial and C&D wa:
| ड़ aste, i talen waste 4.Sakshi Srivastava and Ajeet Singh-
Menstrual Health Management |
'
5.Baldev Bharti and Subashish - E-
| i waste, Industrial waste and C&D
i | waste i
1
Page 7 of 8
