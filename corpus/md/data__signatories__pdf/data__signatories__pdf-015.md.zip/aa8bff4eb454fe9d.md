---
doc_id: "aa8bff4eb454fe9d"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/ed0a97d813e56319aa523fd6a9abc932.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Industrial Park Notification"
date: "2025-07-03"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6f63a33ba13325ce"
---

<!-- page 1 -->

TO BE PUBLISHED IN THE GAZETTE OF INDIA
EXTRAORDINARY
PART-II, SECTION-3, SUB-SECTION (ii)

GOVERNMENT OF INDIA
MINISTRY OF COMMERCE AND INDUSTRY
(DEPARTMENT OF INDUSTRIAL POLICY AND PROMOTION)
****
New Delhi, the April 1, 2002

S.O.354(E).- In exercise of the powers conferred by clause (iii) of sub-section (4) of
section 80 IA of the Income-tax Act, 1961 (43 of 1961), the Central Government
hereby frames the following scheme for industrial parks, namely:1.

Short title and commencement.- (1) This scheme may be called Industrial Park

Scheme, 2002.
(2) It shall come into force on the date of its publication in the Official Gazette.
2. Definitions.- In this Scheme, unless the context otherwise requires.(a)

“Act” means Income Tax Act, 1961 (43 of 1961);

(b)

“allocable area” means, (i)

in the case of an industrial park referred to in sub-paragraph (b) of
paragraph 4, the net floor area available for allocation but excluding the
built up space used for providing common facilities;

(ii)

in any other case, the net area available for allocation for industrial,
commercial or residential purpose but excluding the areas used for
providing common facilities;

(c)

“common facilities" includes the facilities of air conditioning, roads (including

approach roads), water supply and sewerage, common effluent treatment facility,

1

<!-- page 2 -->

telecom network, generation and distribution of power used by two or more industrial
units in an industrial park;
(d)

“empowered committee” means a committee constituted under paragraph 7;

(e)

“form” means a form appended to this Scheme;

(f)

“infrastructure development” includes, roads (including approach roads), water

supply

and sewerage, common effluent treatment facility, telecom network,

generation and distribution of power, air conditioning and such other facilities as are
for common use for industrial activity which are identifiable and are provided on
commercial terms;
(g)

“paragraph” means paragraph of this Scheme;

(h)

"undertaking" means any undertaking which is engaged in the business of

developing, developing and operating or maintaining and operating an industrial park
notified by the Central Government in accordance with this scheme;
(i)

“unit” means any separate and distinct entity for the purpose of one or more

state or central tax laws.
3.

Period of operation of the scheme.- This scheme shall be applicable for any

undertaking which develops, develops and operates or maintains and operates an
Industrial Park for the period beginning on the 1st day of April, 1997 and ending on the
31st day of March, 2006. In a case, where an undertaking develops an Industrial Park
on or after the 1st day of April, 1999 and transfers the operation and maintenance of
such Industrial Park to another undertaking (transferee undertaking), the benefits shall
be allowed to such transferee undertaking for the remaining period in the ten
consecutive assessment years in a manner as if the operation and maintenance were not
so transferred to the transferee undertaking.

2

<!-- page 3 -->

4.

Objectives of the industrial park.- Any project, being an industrial park, shall

aim at setting up of (a)

an Industrial Model Town for development of industrial infrastructure

for carrying out integrated manufacturing activities including research and
development by providing plots or sheds and common facilities within its precints;
or
(b)

an industrial park for development of infrastructural facilities or built-up

space with common facilities in any area allotted or earmarked for the purposes of
industrial use specified in explanation to para 6 subclause (c); or
(c)

a Growth Centre under the Growth Centre Scheme of the Government

of India:
Provided that the scheme referred in this clause is implemented by an undertaking
and the Growth Centre is distinctly developed as a separate profit centre.
5.

Automatic approval.- (1) An undertaking shall make an application in the

Form-IPS-1 along with an affidavit certifying the details given in such application for
obtaining approval for setting up an industrial park.
(2)

An application under sub-paragraph (1) shall be made to the

Entrepreneurial Assistance Unit of the Secretariat for Industrial Assistance, Department
of Industrial Policy and Promotion in the Ministry of Commerce & Industry, Udyog
Bhawan, New Delhi-110011.
(3)

The Secretariat for Industrial Assistance referred to in sub-paragraph (2) shall,

upon receipt of application, give acknowledgement for receipt of such applications
along with, registration number allotted by such Secretariat.
(4)

Every application under sub-paragraph (1) shall be accompanied by a fee of six

thousand rupees payable by a demand draft drawn in favour of Pay and Accounts

3

<!-- page 4 -->

Officer, Department of Industrial Development payable at State Bank of India, Nirman
Bhawan Branch, New Delhi - 110011.
(5)

All applications made under sub-paragraph (1) and eligible for Automatic

approval in accordance with paragraph 6 shall be disposed of within fifteen days of
making of such application and the decision for such approval shall be communicated
to the applicant immediately on disposal of such application.
(6)

In case any application is not found eligible for Automatic approval in

accordance with paragraph 6, the decision regarding the same shall be immediately
communicated to the applicant.
6.

Criteria for automatic approval.- An undertaking which seeks approval under

paragraph 5, shall fulfil the following conditions, namely:(a)

The minimum area required to be developed for an Industrial Model Town shall
be 1000 acres:
Provided that minimum area for specified industrial park referred to in clause

(b) and (c) of paragraph 4 may vary depending upon their activities;
(b)

The project referred to in clauses (a), (b) and (c) of paragraph 4 shall have

provision for the location of minimum number of industrial units as follows:Table
Minimum Number of units to be provided in
the Industrial Model Town/Industrial
Park/Growth Centre
(1)
(2)
(i) Industrial Model Town referred to in
50 units;
clause (a) of paragraph 4.
Type of industrial park

(ii) industrial park referred to in clause (b)
of paragraph 4.
(iii) Growth Centre referred to in clause (c)
of paragraph 4.

4

30 units;
30 units;

<!-- page 5 -->

(c)

The minimum percentage of the area to be allocated for industrial use shall not

be less than sixty six percent of the total allocable area.
Explanation.- For the purpose of this clause, the Industrial use shall include any
activity defined in the National Industrial Classification 1987 Code issued by
Central Statistical Organisation, Department of Statistics, Ministry of Planning
and Programme Implementation, except the following:Section 0

Section 8 excluding Group 892, 893, 894, 895

Section 1

Section 9

Section 5

Section X

Section 7

Section XI;

excluding Division 75
(d)

The percentage of land to be earmarked for commercial use shall not be more

than ten per cent. of the allocable area;
(e)

In case of an Industrial Model Town, Industrial Park and Growth Centre, the

minimum investment on infrastructure development shall not be less than 50% of the
total project cost. In the case of an Industrial Park and Growth Centre which provides
built up space for industrial use, the minimum expenditure on infrastructure
development including cost of construction of industrial space, shall not be less than
60% of the total project cost;
(f)

No single unit referred to in column (2) of the Table given in the sub-paragraph

(b) of paragraph 6 shall occupy more than fifty per cent. of the allocable industrial area
of an industrial model town or industrial park or Growth Centre;
(g)

Every undertaking being an industrial park shall obtain approval for Foreign

Direct Investment or non resident Indian investment from the Foreign Investment

5

<!-- page 6 -->

Promotion Board or Reserve Bank of India, or any authority specified under any law
for the time being in force, as the case may be.
7

Non Automatic Approval.-

(1) All applications not eligible for Automatic

approval under paragraph 6 shall require the approval of the Empowered Committee,
constituted by the Central Government and all such applications shall be placed before
the Empowered Committee within fifteen days of receipt of applications.
(2)

The Empowered Committee shall consist of the following, namely:-

(a)

Secretary, Department of Industrial Policy and Promotion,

Chairman;

Government of India
(b)

Chairman, Central Board of Direct Taxes,

Member;

Government of India, or his representative
(c)

Secretary, Department of Urban Development,

Member;

Government of India, or his representative
(d)

A representative of the State Government to which the

Member;

project relates
(e)

Joint Secretary, Department of Industrial Policy

Member Secretary:

and Promotion, Government of India
Provided that the Empowered Committee may co-opt other Secretaries to the
Government of India and officials of financial institutions, banks and professional
experts from Industry and Commerce as Co-opted members of the Committee and such
co-opted members, however, shall not have any voting right.
(3)

The Empowered Committee shall consider each application on a case to case

basis, subject to its complying with the statutory requirements as prescribed by the
Ministry of Finance under the Income Tax Act, 1961, and other applicable statutory
rules/obligations.

The Committee will consider each case on its merit and grant

6

<!-- page 7 -->

approval subject to such other conditions as may be deemed fit by it. However, in all
cases of rejection of proposals, the applicants shall be afforded an opportunity of being
heard by the Committee and the orders shall be passed and communicated within
twelve weeks. The Committee may also periodically review implementation of the
approved proposals.
(4)

The Empowered Committee will hold meetings whenever necessary.

All

Industrial Model Town/Industrial Park/Growth Centre proposals received shall be
placed before the Committee within 15 days of receipt. The Committee, as far as
possible, would ensure that the Government decision on each proposal is
communicated to the applicant within six weeks. The Committee will adopt its own
mode and working procedure, keeping in view the requirement of each proposal.
8.

Withdrawal of approval.- The Central Government may withdraw the approval

given to an undertaking under this Scheme when such undertaking fails to comply with
any of the conditions of grant of approval:
Provided that before withdrawal of approval, the undertaking being industrial
park, shall be given an opportunity of being heard.
9.

General conditions.- (1)

In case the commencing of the Industrial Model

Town or Industrial Park or Growth Centre gets delayed by more than 1 year from the
date indicated in the application, fresh approval may have to be obtained to get the
benefits under the Act. This condition also applies to the existing approvals under the
Industrial Park Scheme, which envisages commissioning of the Parks, latest by March
31, 2002.
(2)

The tax benefits under the Act can be availed only after the number of units

indicated in the application, are located in the Industrial Park.

7

<!-- page 8 -->

(3)

The undertaking applying for approval shall undertake to continue to operate

the Industrial Model Town or Industrial Park or Growth Centre during the period in
which the benefits under the Act are to be availed.
(4)

In a case where an undertaking develops an industrial park on or after the 1st

day April, 1999 and transfers the operation and maintenance of such industrial park
(i.e., transferor undertaking) to another undertaking (i.e, the transferee undertaking), the
transferor and transferee shall jointly intimate to the Entrepreneurial Assistance Unit of
the Secretariat for Industrial Assistance, Department of Industrial Policy and
Promotion, Udyog Bhawan, New Delhi-11 along with a copy of the agreement
executed between the transferor and transferee undertaking for the aforesaid transfer.
Secretariat for Industrial Assistance shall on receipt of each such intimation issue a
communication to the applicants of having taken the intimation on record.
(5)

Every undertaking, which has been granted approval shall continue to furnish to

the Central Government on 1st January and 1st July of every year a report in the form
Number IPS-II during the period in which the benefits under the Act are to be availed.

[File No. 12(4)/2001-IP&ID]

(M.S. Srinivasan)
Joint Secretary to the Govt. of India

8

<!-- page 9 -->

FORM IPS - I
(See Paragraph 5 and 7)
Application Form for setting up Industrial Model Town/Industrial Park/Growth Centre

a.

Type of Application (Please √ the appropriate Boxes)
Automatic
Automatic
For Industrial Model Town

b.

For Industrial Park

c.

For Growth Centre

2.

(For Office Use Only)
Application No.

1.

Non-

Application Date

3.

Payment Details
Draft No. ____________________________
Amount (Rs.)
Draft Date
Drawn on
Payable at

3.I

________________________________ (Name of the Bank)
________________________________

Name and Address of the Undertaking (Indian/Foreign) in Full (Block Letters):
(a) Registered Address:
Name of the Undertaking _________________________________________
Postal Address _______________________________________________
Pin Code
______________________________________________
Tel. No. _______________
Telex ____________________
Fax No. _______________
Cable ____________________
E-mail _______________

9

<!-- page 10 -->

(b) Address for correspondence (if different from (a) above):
Name of the Undertaking ________________________________________
Postal Address ______________________________________________
Pin Code
______________________________________________
Tel. No. _______________
Telex ____________________
Fax No. _______________
Cable ____________________
E-mail _______________
II.

Registrar of Co. Registration No. __________________________________
(If Registered)

III.

Status of the Undertaking
(1)
Central Govt. Undertaking
(5) Joint Sector Undertaking
(2) State Govt. Undertaking
(6) Private Sector Undertaking
(3)
State Industrial Govt. Corp.
(7) Individual Promoter
(4)
Cooperative Undertaking
(8) Foreign/NRI/OCB company
(9) Foreign/NRI
individual
(10) Partnership Firm
(11) Registered Societies
(12) Any other (please
specify)

IV.

Particulars of persons proposed for holding more than 20% equity investment in
the scheme:
Name of the Undertaking ________________________________________

Postal Address ______________________________________________
Pin Code
______________________________________________
Tel. No. _________________
Telex
_________________________
Fax No. _________________
Cable
_________________________
E-mail _________________
Permanent Account No. _________________________________________
Percentage of proposed
equity investment

10

<!-- page 11 -->

4.I

Proposed location of the Industrial Model Town/Industrial Park/Growth
Centre
Address
________________________________________________
District________________________________________________
State
________________________________________________
Pin Code
_________________ Telephone
_________________
Fax
__________________
E-mail
_________________

II.

Proposed area of Industrial Model _______________________
Town/Industrial Park/Growth Centre.
(in Acres/Sq. Mtrs. specify)

III.

Proposed allocable area of Industrial _____________________
Model Town/Industrial Park/Growth Centre
(in Acres/Sq.Mtrs. specify)

IV.

Proposed activities (please specify
item codes as defined under
National Industrial Classification of all Economic Activity, (NIC), 1987)

V.

Proposed percentage of allocable area
earmarked for industrial use

VI.

Proposed percentage of allocable
area earmarked for commercial use

VII.

Proposed number of
industrial units

VIII.

(a) Total investment proposed
(Amount in Rupees)
(b) Proposed investment on
built up space for Industrial
use (if applicable) (Amount in Rupees)
(c) Proposed Investment on
Infrastructure Development
(including b) (Amount in Rupees)
(d) Percentage of (c) to (a)

11

<!-- page 12 -->

IX.

Total foreign equity proposed
(Amount in Rupees)

X.

*Expected/Actual Date of
commencement of Industrial
Model Town/Industrial Park/Growth Centre

*(The ‘Expected/Actual date of commencement of Industrial Model Town/Industrial
Park/Growth Centre’ denotes the date when all the infrastructural facilities for the
proposed number of industrial units have been provided. If the Park is proposed to be
developed in Phases, the detailed information on the same may be also suitably
mentioned alongwith the application.)

DECLARATION
I/We hereby undertake to continue to operate the Industrial Model
Town/Industrial Park during the period in which the benefits under Sub-Section 4(iii)
of the Section 80 IA of the Income Tax Act are to be availed.
I/We hereby certify that no single unit shall occupy more than fifty per cent. of
the allocable industrial area of an industrial model town or industrial park or Growth
Centre.
I/We hereby certify that the above statements are true and correct to the best of
my/our knowledge and belief.

___________________________
(Signature of Applicant)
Place: _________________
Date: _________________

___________________________
(Name in Block Letters)
___________________________
(Designation of the Signatory)

12

<!-- page 13 -->

List of Enclosures:
1.

_____________________

5.

____________________

2.

_____________________

6.

_____________________

3.

_____________________

7.

_____________________

4.

_____________________

8.

_____________________

13

<!-- page 14 -->

General Instructions
(This part contains information for the guidance of entrepreneurs and may be retained
by them; it need not accompany the application)
1.
All applications for Industrial Model Town/Industrial Park/Growth Centre
under the scheme notified by Ministry of Commerce & Industry are to be submitted in
Form IPS 1 to the Entrepreneurial Assistance Unit (EAU) of the Secretariat for
Industrial Assistance (SIA), Department of Industrial Policy & Promotion, Udyog
Bhavan, New Delhi-110011 alongwith an affidavit certifying the details given in the
application. Application for Automatic approval is to be submitted in duplicate & for
Non-Automatic approval in six sets.
2.
Application shall be necessarily accompanied by a Demand Draft for Rs.
6,000/- (Rupees Six thousand only) drawn in favour of “Pay and Accounts Officer,
Department of Industrial Development” payable at State Bank of India, Nirman
Bhawan Branch, New Delhi
3.

To be eligible for Automatic approval, the following conditions apply:

i) The minimum area required to be developed for an Industrial Model Town shall be
1000 acres, however, no such minimum acreage is specified for Industrial Park or
Growth Centre, the size of which will depend on the nature of the activity.
ii)
The project shall have provision for the location of minimum number of
industrial units as follows:Type
Minimum No. of units to be
provided for
1.
Industrial Model Town
50
2.
Industrial Park
30
3.
Growth Centre
30
(iii)The minimum percentage of the area to be allocated for industrial use shall not be
less than 66% of the total allocable area. The allocable area will mean –
(a)

(b)

in the case of an industrial park referred to in sub-paragraph (b) of
paragraph 4 and making available built up space, the net floor area
available for allocation which excludes the built up space used for
providing common facilities;
in any other case, the net area available for allocation for industrial,
commercial or residential purpose which excludes the areas used for
providing common facilities;

14

<!-- page 15 -->

iv)
Industrial use shall include any activity defined in the National Industrial
Classification 1987 Code except the following:Section 0
Section 8 excluding Group 892, 893, 894, 895
Section 1
Section 9
Section 5
Section X
Section 7
Section XI
excluding
Division 75
v)
The percentage of land, to be earmarked for commercial use shall not exceed
more than 10% of the allocable area.
vi)
In case of an Industrial Model Town and Industrial Park, the minimum
investment on infrastructure development shall not be less than 50% of total project
cost. In case of a project of Industrial Park, which provides built up space for industrial
use, the minimum expenditure on infrastructure development including cost of
construction of industrial space shall not be less than 60% of the total project cost.
vii)
Infrastructure development means air conditioning, roads (including approach
roads), water supply and sewerage, common effluent treatment facility, telecom
network, generation and distribution of power and such other facilities as are for
common use for industrial activity which are identifiable and are provided on
commercial terms;
viii) No single unit in any project shall occupy more than 50% of the allocable
industrial area of an Industrial Model Town/Industrial Park/Growth Centre. For this
purpose a unit means a separate taxable entity.
ix)
Approval of the Foreign Investment Promotion Board/Reserve Bank of India
for Foreign Direct Investment/Non Resident Indian investment, wherever necessary,
shall be taken separately as per the policy and procedures in force.

15

<!-- page 16 -->

IPS - II
[See paragraph 9(5)]
Name of the Undertaking :
Name of the persons holding more than 20% equity
investment in the Industrial Park
:
3.
Item(s) of industrial activities (Specify item codes as
defined under NIC code, 1987)
:
4.
Location of the Industrial Park
:
5.
Terms of approvals
S.No.
Proposed
Items
Actual
1.
2.

I
II

Capital outlay
project
Foreign equity

III

Area of the project

IV

Allocable area of the
project
Number of industrial units
in the project
%age of allocable area for
Industrial use
%age of allocable area for
commercial use
Expenditure on
infrastructure development
including investment on
built up space for
Industrial use

V
VI
VII
VIII

IX
6.

7.

8.

for

Reasons for variations

the

Date of commencement of
Industrial Park
If foreign equity investment is involved, whether approval of
FIPB/RBI taken. If yes, indicate amount and date. If not,
indicate reasons and likely date
:
Indicate briefly the effective steps taken towards
implementation e.g. installation of common facilities, No. of
units sold or leased, No. of units commencing the industrial
Specific problems, if any, being faced in implementation,
the reasons thereof and the agency/organisation concerned :

16

activity

:
