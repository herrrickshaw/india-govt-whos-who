---
doc_id: "a8fc7ef301db0f2a"
source_url: "https://mnre.gov.in/static/uploads/2025/08/c4183617596df064eed5ec50c5c73d52.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Final Statement of Expenditure (S.O.E.)"
date: "2025-10-21"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bbf3905095e61c4a"
---

<!-- page 1 -->

Annexure-XVIII

Final Statement Of Expenditure (S.O.E.)
1. MNRE Sanction Letter/ Order No and date of sanctioning the project:
2. Total Project Cost:
(Sanctioned/ Revised Project Cost, if applicable)
3. Date of Commencement of Project:
4. Date of Completion of Project:
5. Grant received in each year (financial year):
Sl.No. Year

1.

1st year

2.

2nd year

3.

3rd year

4.

4th year

5.

5th year
Grand Total

Amount
Received (Rs.)

Interest
Accrued
(Rs.)

Total Amount
(Rs.)
