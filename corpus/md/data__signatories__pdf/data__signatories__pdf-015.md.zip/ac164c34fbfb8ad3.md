---
doc_id: "ac164c34fbfb8ad3"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/c8dca29fb1b63a0b003f37169c81777e.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Extension of terms of two Sr. Panel Counsel one for High Court of Rajasthan at Jodhpur and other for AFT (CB) at Jodhpur: Order dated 22.02.2023"
date: "2023-02-22"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "3631e7a069070f43"
---

<!-- page 1 -->

F. No. J-11017/20/2022-Judicial
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi,
Dated the 22™ February, 2023
ORDER
With reference to this Department's Orders No. J-11017/1/2017-Judicial dated
22.03.2017 and No. J-11017/2/2017-Judicial dated 20.11.2018, the President is pleased
to extend the terms of following two Advocates, as shown in the table below, for another
term of three years with effect from the date mentioned against each under column-V of
the table, or until further orders, whichever is earlier:-
EXTENSION OF TERMS
Sl. | Name of Contact details Enrolment Date — from
No. | Advocate No. which term
$/Shri) extended
Rat SS 1 111 |
High Court of Rajasthan (PB) at Jodhpur
Senior Panel Counsel
4. | Mahesh Thanvi 8, Parvati nagar, R/118/1994
Circuit House Road,
Jodhpur, Rajasthan
Mob: 9414130386
Tel: 0291-2513030
Email:adv.m.thanvi@gmail.com
Armed Forces Tribunal (Circuit Bench) at Jodhpur
Senior Panel Counsel
2. | Dr. Yuvraj H. No. 2, Old Public Park, R/914/2006
Singh Raikabagh, Jodhpur, Rajasthan
Mob: 9784679198
Email:uvsingh42@gmail.com
2. The engagement and professional fee of the aforesaid advocate will be governed
by the terms and conditions contained in this Department's OM No. 26(1)/99-Judl. dated
24.09.1999 read with OM No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued
subsequently through various OMs especially the OM No. J-16/11/2017-Judicial dated :
08.02.2018 imposing certain restrictions on panel counsel. The aforesaid OMs are
available on the website of this Department i.e. www.legalaffairs.gov.in inside the tab
‘Judicial Section’ under heading ‘Circulars pertaining to litigations’.
3. Hindi version of this order will follow.
coals
(Vijay Kutgar Shania)
Joint Secretary & Legal Adviser
-10f2-

<!-- page 2 -->

ee
F. No. J-11017/12/2022-Judicial Dated the 22" February, 2023
Copy for information to:-

4. PS to Hon'ble MLJ/ Sr. PPS to Hon'ble MSLJ.

2. Sr. PPS to Law Secretary/PSO to AS (RSV)/PSO to AS (RM)/Sr. PPS to AS (ARR)/ Sr. PPS
to JS&LA (SA).

3. Shri Rajdeepak Rastogi, Addl. Solicitor General of India, High Court of Rajasthan.

4. Shri Mukesh Rajpurohit, Deputy Solicitor General of India, Rajasthan High Court at Jodhpur.

5. Shri B. S. Chhaba, Deputy Solicitor General of India, Rajasthan High Court at Jaipur.

6. The Registrar, High Court of Rajasthan (PB) at Jodhpur, Rajasthan.

7. The Registrar, Armed Forces Tribunal, Regional Bench at Jodhpur, Rajasthan.

8. The two Sr. Panel Counsel as mentioned above.

9. The Pay & Accounts Office, Department of Legal Affairs, New Delhi.

10. Hindi unit, Department of Legal Affairs for Hindi translation of the order.

11. One copy of this order is uploaded on website of this Department i.e. www.legalaffairs.gov.in
under tab ‘Judicial Section’ in the link ‘Orders related to empanelment of Advocates for Union of
India’.

12. Office/Spare copies. rel

“a1. 17००3
(Lakka Muneswara Rao)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dia@nic.in
-2 of 2-
