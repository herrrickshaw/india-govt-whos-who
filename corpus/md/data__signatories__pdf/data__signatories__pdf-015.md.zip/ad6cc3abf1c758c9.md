---
doc_id: "ad6cc3abf1c758c9"
source_url: "https://dsel-education.gov.in/static/uploads/2026/10/58c442f4aceff82459606efa70b6602a.pdf"
ministry: "Department of School Education and Literacy (DSEL)"
title: "DoSEL's Advisory dated 17.08.2026 regarding Safety and Security in residential schools/hostels, like KGBV, NSCBAV and Hostels under Pradhan Mantri Janjati Adivasi Nyaya Maha Abhiyan (PM JANMAN) & Dharti Aaba Janjatiya Gram Utkarsh Abhiyan (DA-JGUA)"
date: "2026-08-17"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "99c7a835d1a3573e"
---

<!-- page 1 -->

qRa Tn-.6rI

GOVERNMENT OF INDIA
UINISTRY OF EDUCATION
DEPARTMENT OF SCHOOL EDUCATION & LITERACY
KARTAVYA BHAVAN.2

frEr fitaq

ga frrqn.otrr qrerr6r farrm
i5-ira[ qal- 2

NEW DELHI.11O()O1

(dl! qri

Archana Sharma Awasthi
Additional Secretary
Email Id: as-ss I .ae Glp ov.in
Tel No.: 0l I -240 I 5087-88

r$ ffi-rrooor

iii=.rwaer
snmasra suttsta

'-=ll!

D.O. No. 2-ll2o26-Ss-tl

Aean Ltt-ry

I)ated: 1 7.08.2026

As you may be aware, recently, a few incidents ofsecurity lapses like snakebites, insect

bites, broken boundary wall etc. happened in residential schools. These incidents highlight the
need for continuous review and strengthening ofsafety and security arrangements in residential
schools/hostels, like Kasturba Gandhi Balika Vidyalayas(KGBV), Netaji Subhash Chandra
Bose Awasiy Vidyalaya(NSCBAV) and Hostels under Pradhan Mantri Janjati Adivasi Nyaya
Maha Abhiyan (PM JANMAN) & Dharti Aaba Janjatiya Gram Utkarsh Abhiyan (DA-JGUA).

2.

As the residential schools/hostels cater to girls and boys belonging to Socio-

Economically Disadvantaged Groups (SEDGs), the safety, security and overall well-being of
students residing in these institutions must remain a priority.

3.

In this regard, StatesfuTs are requested to take necessary lollowing preventive

measures for safety of students:-

Safe sleeping arrangements: All hostels should be provided with adequate and safe
bedding, including mattresses and beds/cots, for every student. Sleeping directly on the
floor should be strictly avoided.

Secure premises: Proper boundary walls/fencing and secure entry and exit
arrangements should be ensured around the residential school/hosteI premises.

Adequate ventilation and lighting: All dormitories, classrooms, toilets and other
residential areas should have adequate lighting and proper ventilation.
Round-the-clock security: Adequate security arrangements, including deployment of
security personnel on a round-the-clock basis, should be ensured, wherever required.
There should be no entry ofany unauthorised person.
Emergency contact and awareness information: Emergency contact numbers,
including those of the local Police Station, nearest Primary Health Centre
(PHC)/Hospital, Women Helpline and Ctrild Hetpline & other relevant safety and
awareness materials, should be prominently displayed at appropriate locations within
the hostel premises.

First-aid and medical assistance: Essential firsraid facilities, including necessary
medicines and supplies, should be readily available. Clear arrangements should also be
put in place for immediate medical assistance and transportation to the nearest health
facility in case of emergencies.

<!-- page 2 -->

-2-

'1.

Irurther, para 3(xiv) under heading Roles and Responsibilities

-s

StatesiL]'l-s are furthe'r rcquestcd to cnsurc trrat the ahovc

ol. SMC ol the
rcccntlv launchcd School Managcnrent Committces (SMC cuidclincs-2026
)
sratcs that the
S\'1( should nlonilor tl.tc condition and actiritics ofthcsc hostels. 'l'his includes
cnsurin,
ProPcl maintenancc. hygienc. sal'cty. ch ild-li.icnd 11, laciliries. and adherence,o p."...ii"i
ard standards. Thcrclbre. SM(is nray bc encouraged to rcview thc
above_,rentioned
'ulcs
prcr"cntive measures and pronrptlv cscalate the delicicncies
lirr corrective action.

',.asurcs

are rcviewed pcriodicallv and rrcccssary corrccti'c action is

n)attcr ntav bc accordcd priority in thc intcrest of the safety,

studcnls residing in rcsidcntial schools/hostels.

t"d.

sar-ety and sccurity
-fhe

taken promptry.

sccurity anrl well-being of

,
Yours sincercly.

M*=

(Archana Sha rma Awasthi)
Iir.

l. Additional Chicl Secrcrary/principal Sccrctary/ Secrerary ( l:iducation) of all
States/[J'fs

2. All SPD's ol States/[J'l's cducation Department
