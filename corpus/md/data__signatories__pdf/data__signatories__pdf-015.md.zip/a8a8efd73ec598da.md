---
doc_id: "a8a8efd73ec598da"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/4b87e1ff544950b4e4e0a4cf6504b649.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification -SpecialPackage - II (15.06.2012 -14.06.2017) -J&K"
date: "2025-06-25"
pages: 27
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "8875d6cdfc807ce8"
---

<!-- page 1 -->

‘ [भाग 1-- खण्ड 1] भारत का राजपत्र ; अम्राधारण lL
साहसिक एवं आरामदायक खेलों आदि के तहत सम्मेलन कक्ष, आडिटोरियम आदि जैसी अतिरिक्त मर्दों
को छोड़कर स्वीकार्य मदों की परिआषा।

अनुबंध-७५
Te स्तरीय समिति की संरचना
1. सचिव, उद्योग एवं वाणिज्य विभाग, जम्मू एवं कश्मीर अध्यक्ष
2. निदेशक, उद्योग एवं वाणिज्य, कश्मीर सदस्य सचिव
3. निर्देशक, उद्‌योग एंवं वाणिज्य, जम्मू .. संदस्य सचिव
4. निदेशक, लेखा एवं कोष सदस्य
5. प्रबंध निदेशक, जम्मू एवं काश्मीर विकास वित्त निगम सदस्य
6. वित्तीय सत्राहकार/सीएओ, आईएण्डसी विभाग सदस्य
7. औद्योगिक नीति एवं संवर्धन विभाग के नामिती सदस्य
8. प्रेसिडेल्ट, फेडरेशन चैम्बर आफ इंडस्ट्रीज सदस्य
9. अध्यक्ष, उद्योग परिसंघ, जम्मू सदस्य
“जैसा ज्ागू हो
अनुषंध-५
अधिकार प्राप्त समिति का गठन
1... सचिव, औदयोगिक नीति एवं संवर्धन विभाग .. .. अध्यक्ष है
2 सचिव, व्यय विभाग सदस्य
3... यौजना आयोग के प्रतिनिधि सदस्य
wt सच
4. दावेदार इकाई के औद्योगिक क्रियाकलाप से प्रशासनिक रुप से eg सदस्य
मंत्रालय के सचिव
5... अपर सचिव एवं वित्तीय सब्राहकार, औद्योगिक नीति एवं संवर्धन सदस्य
_ विभाग te
6. मुख्य सचिव/आयुक्‍्त (उद्योग), जम्मू एवं काश्मीर सदस्य
7... प्रबंध निदेशक, जम्मू और कश्मीर विकास वित्त निगम . सदस्य
४ 8... संयुक्त संचिव, औद्योगिक नीति एवं संवर्धन विभाग nt सदस्य सचिव
9. संबंधित वित्तीय संस्थान के राज्य प्रतिनिधि , सदस्य
10. मुख्य ज्ेखा नियंत्रक, औद्योगिक नीति एवं संवर्धन विभाग सदस्य
MINISTRY OF COMMERCE AND INDUSTRY“
(Department of Industrial Policy and Promotion)
है है NOTIFICATION
New Delhi, the 3" October,2013.

F.No.1(10)2012-SPS. The Government of India is pleased to thake the following scheme of Central Grant or

Subsidy for Industrial units im the Jammu & Kashmir as J&K Package-I with a view to accelerating the industrial
é development in the State.

|. Short Title:- This scheme may be called the Central Capital Investment Subsidy Scheme, 2012

2. Commencement and duration of the Scheme:-It will come into effect from the 15" June, 2012 and
remain in force upto and inclusive of 14,06.2017, :

3. Applicability of the Scheme:- The scheme is applicable to all new industrial units and existing industrial
Units on their substantial expansion in notified areas as per Annexure-I. and also to specified Thrust Industries outside
the notified areas as per Annexure-IT.

4. However an industrial unit in Textile sector in-Jammu & Kashmir would have the choice to apply for
subsidy either under “Sechnology Upgradation Fund Scheme” (TUFS) of Ministry of Textile or under the Special
Package administered by DIPP. हे

5. Extent of admissible subsidy : है

All new industrial units and existing industrial units on, their substantial expansion , would be eligible for
Capital Investment Subsidy @ 15% of investment of Plant & Machincry, subject to a ceiling of Rs. 30 lakhs. Micro,

<!-- page 2 -->

2 TIE GAZETTE OF INDIA: EXTRAORDINARY [Part b-Sie. i
Small and Medium enterprises would be eligible for Capital Investment Subsidy of 30% of the investment ७ plant &
machinery subject to a ceiling of Rs. 3.00 crore and Rs. 1.30 erore for manufacturing and service sector respectively

6. Eligibility period:—

The subsidy will be available for the duration of the scheme to such units which haye.pre repistered and
commence commercial production / operation prior to 14-06-2017. The unit should file its claim as pet prescribed
procedure at District Industry Centre concerned within one year from date of commencement of commercial production
/ operation

7. Definitions:-

(i) ‘New Industiial Unit” means'an industrial unit which commences commercial production‘operation on oF
after 15" June, 2012, oS

(ii) ‘Existing Industrial Unit’ means an industrial unit which has commenced commercialproduction /
operation before 15" June, 2012.

(iii) ‘Substantial Expansion’ means increase by not less than 25% in the value of fixed capital investment in .
plant and machinery of an industrial unjt for the purpose of expansion of capacity.

(iv) ‘Fixed Capital Investment’ means investment in plant and machinery for the purpose of this scheme.

(y) ‘Micro, Smal] and Medium Enterprises’ means enterprises as classified under sub-section (1) of section 7 .
‘of the Micro, Small and Medium Enterprises Development Act, 2006, as amended from time to time”

(wi) ‘Plant & Machinery’:In calculating the value of Plant & Machinery, the cost of industrial plant &
machinery’ at site will be taken into account. Further explanatory note is at Annexure-II,

8, The approval of claims of subsidy will be as follows:

i) ‘A State Level Committee headéd by Socrefary, Industry will approve claims for subsidy upto Bs.1.50
crore. The composition of the State Level Commitice is at Annexure-IV; and हर

id) For claims more than Rs.1.5 crore the SLC will recommend the proposal for consideration of the
Empowered Committee chaired by Secretary, Department of Industrial Policy & Promotion. The constitution of the
Empowered Committee is at Annexure-V.

iii) Broad guidelines for approval of the claims under para (3) above shall be notified by the Govt. of
India.

9, Negative list .

‘The industrial units which manufacture the under mentioned products, will net be eligible for benefit
under the Central-Capital Investment Subsidy Scheme, 2012:

@ Cigarettes/cigars of tobacco, manufactured tobacco and substitutes, distillation/brewing of alcoholic
drinks and manufacture of branded soft drinks and its concentrates.

(i) Weapon or ammunition. .

(ii) Pan Masala as covered under Chapter 21 of the First Schedule to the-Central Excise Tariff Act, 1985
(5 of 1986). . “,

(iv) Plastic Carry bags of less than 20 microns as specified by Ministry of Environment & Forests
Notification No. S.O. 705(E) dated 02-09-1999 and $.0.698(E) dated 17-06-2003.

10. Expenditure on second hand plant and machineryand plant and machinery where cash payment has
been made for procurement, would not be eligible for consideration of the subsidy.

Ii. A unit can avail subsidy only under a single scheme, either from the Central Government or from the
State Government. A unit seeking subsidy should certify that it has not obtained or applied for subsidy for thé same
purpose or activity from any other Ministry or Department of the Government of India or State Government,

12. Designated agency for disbursement of subsidy

jammu & Kashmir Development Finance Corporation (SKDFC) shall be the designated agency for
disbursement of Capital Investment Subsidy on the basis of the recommendation of the State Government. JKDFC shall
furnish the Utilization Certificate’ to Ministry of Commerce & Industry, Department of Industrial Policy & Promotion “
against the funds released for disbursement of subsidy to the eligible units, JKDFC shail release the subsidy to the
cligible industrial unit through ECS and RTGS system only.

13. Procedure for claiming Capital Investment Subsidy

‘The procedure for claiming subsidy under this scheme would be as follows:- २

i) Industrial units eligible for subsidy under the scheme will get themselves registered with the District
Industry Centre concemed prior tothe date of commencement of commercial production / operation

ii) In case of Bank financed units, the Bank shall certify the value of plant and machinery for the project as
per scheme guidelines.
है iii) tn case of self-financed units, the project would be appraised by IKDFC after registration by the unit
JKDPC would also certify the value of plant and machinery as per scheme guidelines

iv) Unit should submit their claim within one year from the date of commencement of commercial
production / operation. ‘The industrial units registered before 15-06-2012 under the erstwhile scheme of subsidies and
have filed the claims within one year of the date of commencement of commercial production / operation would be
cligible for subsidies under erstwhile scheme. Units which were registered after 15-06-2012 would be covered under
the present scheme. However, if such a unit has not registered with DIC (District Industry Centre) due to non-existence

<!-- page 3 -->

1भाग। - खण्ड || भारत का राजपन्न ; असाधारण 13
, of the package during the intervening period or not submitted claim within one year of the date of commencement of
हे commercial production / operation, the Unit can do so not later than 31% December, 2013,
14, Procedure for disbursement of Capital Investment Subsidy
The procedure for disbursement of Capital Investment Subsidy shall be as follows :-

(i) The State Level Committee should examine each case to decide the cligibility of the unit and the
quantum of subsidy,

Gi), _ The State Government shall ensure complete documentation in respect of claims approved by SLC
under the scheme before forwarding'the same to JKDEC. for disbursement.

(ii). If a unit is unable to complete documentation in respect of its claim approved by SLC within three
months of SLC meeting, the claim shall be put in abeyance and will be reconsidered in fis next meeting for final
decision.

7 (iv). JEDFC will undertake pre scrutiny of 10% claims before disbursement of subsidy.
“ @). While making payments, IKDEC will consider the principle of oldest claim of oldest S1.C first for
है disbursement of subsidy.

15. In respect of units financed by Financial Institution, the appraisal report of the Financial Institution
would be taken into account while computing the value of Plant & Machinery.

16. Rights of the Centre/State Government/Financial Institutions

If the Central Government/State Government/financial Institutions concerned is satisfied that the subsidy or
grant to an industrial unit fias been obtained by misrepresenting an essential fact, furnishing of false information or if
the unit goes out of commercial production / operation within 5 years after commencement, the unit would be liable to
refund the grant or subsidy after being given an opportunity of being heard.

17. No owner of an industrial unit after receiving a part or the whole of the grant or subsidy will be
allowed to change the location of the whole or any part of industrial unit or effect any substantial contraction or
disposal of @ substantial part of its total fixed capital investment within a period of 5 years after its going into
commercial production / operation without taking prior approval of the Ministry of Commerce & Industry, Department
of Industrial Policy and Promotion/State Government/Financial Institution concerned:

18. 100% physical verification of the actual establishment and working status of each of the units
availing subsidy under the scheme will be done by State Government through District Industries Centres. District
IndustriesCentres shall submit annual report to the Directorate of Industries and JKDFC about the functionality of the

- units, JKDFC shall thereafter submit annual. report to the Department of Industrial Policy and Promotion about the
functionality of the units availing subsidy under the scheme. After receiving the grant or subsidy, each industrial unit
shall also submit Annual Progress Report to the State Government with a copy to Jammu & Kashmir Development
Finance Corporation (JKDFC) about its working for a period of 5 years after going into commercial production /
‘operation. +

SHUBHRA SINGH, It. Secy.
हे * ANNEXURE-I
List of Existing Industrial Estates,
i popes MOSM NASO न ०७७ a
Sl.No. | Name of District _ | ‘Name of Industrial Estate हि |
01. Stinagar BAMK (Bagi Ali Mardan Khan
Zakura
Zainkote
; Khonmoh |
, — सदर eg eserceeg SURI eet
02. | Ganderbal शशि, 77777 7 momen
103. 7 Barzulla
[eb ta ee 1 ४ झऋ
| 04. ‘Ananinag | Ananinag |
| | Anchidora
| | = ee. /-. ०-० - |
| 05. | Kulgam | Kulgar . ron a
06. Pulwama * - | Pulwama |
| | Chatpora
| list रा af JOC Lassipora._
! o7- [आकाश | Gagran - |
U3s7o Gris —4

<!-- page 4 -->

if THE GAZETTE OF INDIA : EXTRAGRDINARY TPaat db -Sie
a8. 7 Baramulla 7 — ~~) Baramulla i
| | Sopore
| - | Food Park Doabgah i
| 0 | Bandipora ipsa nega eeceesbemenaass [Sumbal a
10. | Rupwara Branwara - —
; . f ie CHOLINE ०-. Sse a}
11 Leh Leh |
| Phyang
bee Sanaa दहन — 5 ‘
a Kargil Chanchik |
Poo hata ees canned
New Industrial Estates (Under Development) in Kashmir Division. ,
10, काश essai ee
यम mam maceresaes sheets = | ShestergamMchmoodaBaghDury | i
02 Pulwama TakiaRazak Shah Tral |
fe af Kl oa Rha 00 - |
jo Kulgam AshmujiKulgam
| MalwanKutlgam |
ae Kulgam Phase | ..हुहैु |
| od, Budgam Rangreth Phase-Ii
| cel ame arnyxoeircivE a Scien OPO arpa errata si mssemmey een
105 Kupwara Chotipora (Handwara) |
५ Rati ७-1 -->+
06. _ आज _ | Shopian | Alar शी? |
0. किक्षक्षाएब Bangi Pamgmarg se savoir |
108. Leh Phyang
Teepe et reef a et oe |
|i Tira (Chagrating) I
List of Industrial Estates
ne pe ee Hb Divison ee |
SLNo. [Name of District Name of Identified Estate  ऑन्‍न्‍ऑन्‍--+--
01. Jammu Digiana
| Jammu Cantt.
Gangyal
Birpur
Baribrahmnad EPIP Kartholi
— peace speci ence penn AUNMOOE Site i err gaa
| 02, = Samba |
| — == JGC Samba Phase ee eee es teed
| 03. Udhampur ° Udhampur |
| _| | ED BattalBallian  क्क्‍--+-- _|
198 Pp Reash ा+नीलनाल-न>+नल+-अ>>_+_> Recast (Grey a peerage ll
105 (बह है Kathua *
| * Hiranagar |
Billawar |
UD Govindsar |
te eects =e doa i coe | °
06 | Rajour, | Rhee नननग्मनानणण : scutsseintimtee
कि | Poonch | Poth न्‍ननियायजिणण: oe el
08. ___| Kishtwar Tr agp SAARI आय sr ——|
[09d फेक

<!-- page 5 -->

"fap ae 1] भारत का राजपत्र : अम्ाधारण is
है New Industrial Estates (Under Development) in Jammu Division
, | SENo | Name of District | | Name of industrial Estate” __]
Or Kathua. | Ghatti |
| | Govindsar Phase I-II j
| DambraBillawar |
| = so a nveon--|Hivanagar (ChakBulananda) om
02, Rajouri ThandiPani ( Silk Clustor) |
gf Lambert कि |
3. | dhampur Maal है रा
१4 | 1 Bet |
0 5 Reasi ३३ _LNimba |
06 निकाय Surankowe पलक
[07 | Samba 8 : _.L IGE Samba Phase-tti 7 - |
ANNEXURE ~IT
on Phrust Industries included under J&K Industrial Policy _ RL a
SENO, | Activity Industry 1 we |
I Food processing /Agro based Industries := |
| a. Sauces, Ketchup etc. |
b, Fruit juices and Fruit pulp |
} c. Jams, Jellies, Vegetable Juices, Puree, pickles |
i ete
: 4, Processing of fresh fruits, Fruit waxing,
i packing, grading.
i 8. Flour mills and Rice Mills. |
| SL. Spice grinding |
1 | & Pastewrization/Processing of milk and other |
| smerny =e woduets, 1 11 nittincince tink “ 8 os nell
2 | Leather processing and Leather goods, = |
3__| Tissue culture and Musitroom culture, Compost making , Dairy farming — |
f..__| Sill reeling, yarn and yarn spun from silk waste, Woven fabrics of sillcor silk waste. =
है -----—-| Wool and woven fabrics of wool, Manufacturing of woolen blanket. = |]
(8 | Woven fabries of eotton, 1 |
i? जज Floriculture, Processing of Aromatic and medicinal plant, Green house, i
ie a ~-| Computer hardware/Electronics (integrated circuit and micro assemblies),
1: sn ssn Sports goods and articles and equipment for general physical excroise. = |
10. | Auto ancillaries 3: |
fu. Exploration of minerals and minerals based industry. Gypsum, Plaster of Paris with कक
boards, Granite and Marble cutting and finishing, cutting and polishing of gems and mating of
| ah Es LONE tc न किक, fee |
: | 12. 3 tourism ;- Hotels, Houseboats, Resorts, Adventure and leisure sports, Amusement parks, |
fe eof Cable car, Guest houses, Le -—4
j 0 iandierafis and Handiooms, 57 i
114. नन-ञाप्पंशंणा धाशाध्णाए8, छः meme
is Packing industry :-items like adhesive tapes, strapping rolls, pet boitles, Card board corrugated
boxes, plastic container caps, HDPE bottles, drunas, barrels, cans, ROPP caps for botiles, Woven
ponent SKS, HDPE fabri,  / // हहहहतहतहतत ce
. 1. | Bottling of mineral water, रू  आघआऔख£/ —
} aE | Stationery items like note book, Pen, Pencils, Erasers, Sharpeners, Geometry bowss ete, -—|
18. Wood based industry :~ Manufacturing of plywood / Ply board / Core veneer / Pencil Blocks / |
a Slates/Joinery/Furniture/ Paneling 5 ssssosnsancl
ANNEXURE-INT
A. Components to be included for computing the value of Plant & Machinery:
i Cost of Industrial Plant & Machinery including taxes and duties i.e. cost of mother production equipment used
for carrying out manufacturing activities.
ii, Cost of Productive equipment such as tools, jigs, dyes and mouldsete including taxes and duties and insurance
premium,

<!-- page 6 -->

16 THE GAZETTE OF INDIA : EXTRAORDINARY {Pant fs
iii Electrical components necessary for plant operation on the plant side from where meter is installed up to the
point where finished goods is to be produced/dispatched (i.e. H.T. Motors, Ll Motors, Switch Boards. Panels,
Capacitors, Relay, Cirenit Breakers, Panel Boards, Switchgears).
iv Freight charges paidfor bringing Plant & Machinery and equipment from the supplier's premises to th
location of the unit. ~
y Transit Insurance premium paid
B. Components which will not be considered for computing the value of Plant and Machinery:
i Loading and unloading charges
ii Sheds/buildings for Plant & Machinery,
iii, Miscellaneous fixed assets such as DG sets, Excavation / Mining equipments, Handling equipments, clectrical
components other than those mentioned at A (iit) above.
iv, Working Capital including Raw Material and other consumable stores.
y, Commissioning cost.
vi. Captive Power Plants
vii Storage equipments .
viii, Weigh bridge, Laboratory testing equipment
ix, Erection and installation charges
PLANT & MACHINERY FOR A TYPICAL CEMENT PLANT
As Limestone crushing section
I, Limestone crusher

2. All crusher auxiliaries like feeder below limestone hopper, belt conveyor, dedustingequipments like cyclone &
bag filters, sereen etc.

3. Limestone stacker &Reclaimer with belt conveyor, Additive(s) crusher & belt conveyor (as required) feeding
to Raw Mill Hoppers है

B. Raw Material grinding section

1, Raw mill (Ball Mil/VRM/Roller Press & Ball Mill)

2. All raw mill auxiliaries like weigh feedér below hopper, separator, fans, bucket elevator, rotary air lock, air
slides, magnetic separator, metal detector, FK Pump, Fluxo Pump, dedustingequipments like cyclone, bag
filters, Bag house/ ESP (common for kiln & mill) with fan ete.

८. Raw meal extraction/kiln feed section |
1. All slide with blowers before & after raw meal silo, solid flow meter.

2. Kiln feed bucket elevator/airlift

D. Pyro processing section

1. Rotary kiln with preheater cyclones &caleintr.

2. All auxiliary equipments tike preheater fan, shell cooling fans, blowers, down comer duct and other ducts for
carrying hot gases, fresh air dampers etc.

3. Bummer for Kiln &Calciner, Gas analysers, Temperature & pressure measuring equipment ete.

4, Clinker Cooler.

. 5, Allcooler auxiliariesequipments like cooling fans, ESP &ESP fan, clinker crusher etc,

6. Clinker conveying equipment like Deep pan conveyor (DPC)

7. Coal crusher with all auxiliaries like bag filters, belt conveyor etc.

8, Staker&Reclaimer for Coal including belt conveyor feeding to coal hopper

9. Fuel Grinding Mil! (Ball Mill/ VRM) for Coal/petcoke/lignite/atternate fuels

10. All coal mill/Puel grinding mill auxiliaries including weigh feeder below raw coal hopper, separator, bucket

2 elevator, rotary air lock, air slides, bag house, bag house fan booster fan, belt conveyor & serew conveyor,

. _ inertisation system ete. This also includes system for other fuel alternate firel

KE. Cement grinding section छः

1. Cement mill (Bail Mill/VRM/Roller Press & Bal] Mill)

2, Cement Mill auxiliaries like weigh feeder below hopper, separator, bucket elevator, rolary air lock, air stides,
FK Pump, Fluxo Pump, solid flow meter, bag house, Bag house fan, conveyors. Material extraction gates
below Silo/ stockpile, Gypsum crusher, Pneumatic Handling system for Flyash’ Mechanical handling system
for slag ete.

के Packing Section
1. Packer & its auxiliaries such as belt conveyor, belt diverter, bucket elevator, screen etc.
2 Truck loader & Wagon loader (if applicable), Bulk Loading & Packaging arrangement.

<!-- page 7 -->

(भागा -- खण्ड |] भारत का गजपत्र : असाधारण 17
. 0. Others
|. Blowers, Pumps, compressors ete
2. Relt Coveyors (for all sections) -
3. De-dusting bag filters (across transfer points) with fans
4, Samplers
5. Hot Air Generator if'any
6. Electrical and Control & instrumentation equipment alongwith sofware for plant operation (plant PIC)
including HT & LT Motors, De Motors, hyristor Panels, SPRS System, Capacitors ete.
I, Exelusions:-
1. Workshop equipment
2. Laboratory equipments
3. Equipment for power distribution other than those at G (6) above
4. Equipment for water susply 4
5. Fire Fighting Equipment है
6, Mining machinery
7. D.G, Sets for Plant/captive power plant
8. Weigh Bridge, Railway Siding, Locomotives, Truck Tripplers ete
9. Plant Building (like crusher building, mill house ete,), Auxiliary building (like MCC rooms, compressor house
etc) and Non Plant Buildings (like Store, Administrative building, canteen etc.)
10. Storage Building like Silo, Hoppers, Stockpiles,
PLANT & MACHINERY FORA STEEL AND A ROLLING MILL (GECTION WISE)
A. MELTING MELTING SECTION
1. Induction Fumages & Electric Ate Fumaces with all electrical installations, gadgets, control panels, meters,
cables, busbars, emergency water system, main water cooling system etc
2. Casting Section: Ladles, oi! burners, gas purging system, ladle refining furnace, if any, vacuum degassing
units, if any; contintious casting unit with Motors, pumps, withdrawal system, DM water system, water
_ teatment plant, conveyor belts, ete. z
3. Auxiliary Equipmentsé& Cranes
4. Workshop Machines: *
. 5. Hlectrical Equipments (HT Motor, LT motor, Switch Board, Cap acitots, Relay. Circuit Breakers, Pariel
Boards, Switch Gears),
B. ROLLING MILLS
हे |. RHF (Re-heating Fuinance)- all items including Sheets, Refractory, Pusher Motors, Burners, Chimney,
recuperator, APCD etc. as defined in Plant & Machinery,
2. Roughing Stand including motors, repeaters (if any), mechanization (if any), bearings, cooling systems ete.
which are defined as Plant & Machi inery.
3. _ Intermediate stands (as above)
4. Finishing stands (as above) :
a 5. Quenching system (for TMT)
6. Shears, Pinch Roll
7. Cooling Bed Systems ‘
8 Crane
5. Workshop Machines (Lathe, Shapere, Drils, Grinders, Milling Machine, Templates, measuring equipments
like screw gauge, vernier etc.) :
10. Auxiliary equipments (included as Plant Machinery)
TL. Electrical equipments (Current transformers, circuit breakers, panel boards, motors, reactors, Relay pancls
switch gears, starters, digital meters, etc,)
4370 GE])3-S

<!-- page 8 -->

18 THE GAZETTE OF INDIA ; EXTRAORDINARY {Pari tS
12, Other material handling equipments (within the Rolling Mills furnace area for hot metal transfer) ~ (Conveyer
which lead to mechanization‘gutomation, chain pulley blocks ete.)
13. Water System equipments and towers- (Water settle tanks for removal of metallic contamination, off, grease,
cic, DM water plant, any. Water pumping units, water cooling power/system ete,
14, Coal Pulverizer system including Pipeline for delivery
Definition’6f Plant & Machinery for Eco-Tourism
(a) In the case of Houseboats, the entire houseboat project along with its fiting and furnishing shoald be
treated as plant and machinery.
(b) In the case of hotel, resorts and guest houses (Laddakh only) , the investment in plant and machinery 5 ‘
negligible in comparison to the cost of land and building. Therefore, building should also be included as
a part of plant and sachinery. Besides this, the items given at (c) below may be taken into account for
calculating the value of plant and machinery
(0) An illustrative list of plant and machinery/equipment is given below: हु
L. Filtration plant for swimming pool.
2. Water purification plant.
3, Tot water boiler and room heating equipment (fixed) ~
4. Water softening plant .
5. Fume extraction and ventilation plant.
6, Airconditioning plant
7. Cold Storage equipment.
8. Laundry equipment,
हे 9. Cooler and refrigeration equipment.
10. Bakery equipment
11. Sewage disposal plant
12, Electrical installations कं
13, ‘Tents for camping
, 14, Kitchen equipment, cooking range, dish washer, working table.
15. Fire- fighting equipment (fixed)
. 16, Telephone equipment/exchange.
17. Lifts
. 18. Safe deposit lockers
19, Tube wells along with pumping sets and lines within the
campus
30, Goods carrier exclusively needed for the titel. - -
21. Projectors and other equipment’s for conterence hall (fixed). :
22. Lighting equipment.
23, Adventure and water sports equipment’s,
d) For adventure & leisure sports, amusement/entertainment parks, cable car, ropeways and spa, the entire
ae cost of items and components (excluding land) essential for commissioning the project. Definition of
admissible items under adventure & leisure sports etc, exclude additionalities such as conference room,
auditorium etc.

<!-- page 9 -->

« भाग [--- खण्ड |] भारत का राजपत्र : असाधारण 19
ANNEXURE -IV
हु Composition of State Level Committee 5
1 Secretary, Department of Industry & है
है Commerce, J&K Chairman
2 Director, Industries and Commerce, Kashmir Member Seeretary*
3. Director, Industries and Commetce, Jammu Member Secretary*
4 Director, Accounts and Treasuries Member
5. MD, Jammu & Kashmir Development Member है
Finance Corporation
6 Financial Advisor/CAO, 1&C Department Member
fi Nominee of DIPP Member है
8. President, Federation Chamber of Industries, Member
Kashmir
9. Chairman, Federation of Industries, Jammu, Member
है *As applicable है
ANNEXURE-V
Composition of Empowered Committee
a Ts Secretary, DIPP Chairman
2, + Secretary, D/o Expenditure Member
By Representative of Planning Commission Member
4 Secretary of Ministry administratively
corcemed with the industrial activity of the
claimant unit Member
» 5... Addl, Secretary & Financial Advisor, DIPP Member
6. Chief Secretary/Commissioner (Industry) Member.
Jammu & Kashmir
7. MD, Jammu & Kashmir Development Member
Finance Corporation
oe Be Joint Secretary DIP ss > Sc ~-Member =
Seeretary
9. State representative of concerned Member
Financial (nstitution
10. Chie Controller of Accounts, DIPP Member

<!-- page 10 -->

: 26 THE GAZETTE OF INDIA : EXTRAORDINARY [PART I--Ste, 1]
NOTIFICATION
New Delhi, the 2rd October, 2013.

F.No.1(10)2012-SPS. The Government of India is pleased to notify the following scheme of Interest Subsidy
on Working Capital Loan for Industrial units in the state of Jammu & Kashmir as J&K Package-H with a view to
accelerating the industrial development in the state, .

1. Short Title:~ This scheme may be called the Central Interest Subsidy Scheme, 2012

2. Commencement and duration of the Scheme:-It will come into effect from the 15th June, 2012 and
remain in force upto and inclusive of 14.06.2017. हे

3. Applicability of the Scheme:-The scheme is applicable to ail new industrial units in notified areas as
~per Annexure-I and also to specificd Thrust Industries outside the notified areas as per Annexure-LL.‘New Industrial
Unit? means an industrial unit which commence commercial production/operation on or after Sth June 2012,

4. However an industrial unit in Textile sector in Jammu & Kashmir would have choiceto apply for on
subsidy either under “Technology Upgradation Fund Scheme” (TUFS) of Minisiry of Textile or under the Special
Package administered by DIPP, .

5. Extent of admissible subsidy:

All eligible industrial units in the state of Jammu & Kashmir shall be given an interest subsidy to the extent of
3% on the average of actual daily Working Capital loan given to them by the Scheduled Banks or Central/State
financial institutions, for a maximum period of five years, from the gate of commencement of commercial
production/operation provided that the claimant unit has not been declared as NPA (Non-Performing Asset)

6. Eligibility period: The subsidy will be available for the duration of the scheme to such industrial units,
Which have pre-registered and commence commercial production / operation before 14-06-2017, for a period of five
years from date of commencement of commercial production / operation. The unit should file its claim as. per
prescribed procedure at District Industry Centre concerned within one year from the date of commencement of
commercial production / operation,

7. A tnit can avail subsidy only under a single scheine, either from the Centéal Government or from the
State Government, A unit seeking subsidy should certify that it has not obtained or applied for subsidy for the same
Purpose or activity from any other Ministry or Department of the Government of India gr State Government

8. ‘The approval of the claims for subsidy will be as follows:

A State Level Committee headed by Secretary, Industry will approve claims for subsidy. The composition of
the State Level Committee is at Annexure-ITI.

9% — Negative list

The industrial units which manufacture the under nientioned products will not be eligible for

subsidyunder this Scheme,

(i) Cigarcttes/cigars of tobacco, manufactured tobacco and substitutes, distillation/brewing of alcoholic

a drinks and manufacture of branded soft drinks and its concentrates.

(ii) Weapon or ammunition,

(iii) Pan Masala as covered under Chapter 21 of the First Schedule to the Central Excise Variff Act, 1985
(5 of 1986).

z (iy) Plastic Carry bags of less than 20 microns as specified by Ministry of Environment. & Forests
Notification No. 8.0. 705(B) dated 02-09-1999 and 8.0.698(E) dated 17-06-2003.
के 10. Designated Agency for disbursement of Subsidy: Agency for disbursement of Subsidy:

Jammu Kashmir Development Finance Corporation (JDEC) shall be the designated agency for disbursement
of interest subsidy on the basis of the recommendation of the state Government. IKDFC will disburse subsidy through
ECS and RTGS system only.

गे 11.Procedure for claiming Interest Subsidy: है

Industrial units eligible for subsidy under the scheme will get themselves registered with the District Industry .
Centre ‘concerned prio? to the date of commencement of commercial production / aperation. The unit is required to
Submit a certificate from the lending agency as per the Annexure-IV at the time of claiming of the subsidy under the
scheme. The claim of subsidy shall be submitted by industrial units within one year of the date of commencement of
commercial production / operation, .

12. Procedure for disbursement of Interest Subsidy:

The State Level Committee would-examine each case'to decide whether it qualifies for the grant of subsidy
and also about the quantum of subsidy.

‘The subsidy will be disbursed to the unit by JKDFC on the recommendation of the State Level Committee

13, Rights of the Central/State Government/JKDFC:

If the Central Government/State Government/]KDFC is satisfied that the subsidy or granit to an industrial unit
has been obtained by misrepresentation of the essential facts, furnishing of false information or ifthe unit goes out of
commercial production/operation within 5 years after having availed the subsidy under the scheme, the Central
Government/State Government/JKDFC may ask the unit to refund the grant or subsidy after giving opportunity ta the
concerned to be heard.

14. No owner of an industrial unit will be allowed to change the location of the whole or any part of the
industrial unit or effect any substantial contraction or disposal of a substantial part of its total fixed capital investment
