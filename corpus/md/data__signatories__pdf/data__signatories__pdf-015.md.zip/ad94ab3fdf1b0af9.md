---
doc_id: "ad94ab3fdf1b0af9"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/300369cac93ae914541f315a6a8af3b2.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Notes 2"
date: "2005-03-03"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fe39e74953413e31"
---

<!-- page 1 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion
SIA (FC Division)

Press Note
Subject:

2 (2005)

Foreign Direct Investment (FDI) in townships, housing, built-up
infrastructure and construction-development projects

With a view to catalysing investment in townships, housing, built-up
infrastructure and construction-development projects as an instrument to
generate economic activity, create new employment opportunities and add to
the available housing stock and built-up infrastructure, the Government has
decided to allow FDI up to 100% under the automatic route in townships,
housing, built-up infrastructure and construction-development projects (which
would include, but not be restricted to, housing, commercial premises, hotels,
resorts, hospitals, educational institutions, recreational facilities, city and
regional level infrastructure), subject to the followingguidelines:
a.

Minimum area to be developed under each project would be as under:
i.

In case of development of serviced housing plots, a minimum
land area of 10 hectares

ii.

In case of construction-development projects, a minimum builtup area of 50,000 sq.mts

iii.

In case of a combination project, anyone

of the above two

conditions would suffice
b.

The investment would further be subject to the following conditions:
i.

Minimum capitalization of US$10 million for wholly owned
subsidiaries and US$ 5 million for joint ventures with Indian
partners. The funds would have to be brought in within six
months of commencement of business of the Company.

ii.

Original investment cannot be repatriated before a period of
three

years

from

completion

of minimum

capitalization.

However, the investor may be permitted to exit earlier with
prior approval of the Government through the FIPS.
c.

At least 50% of the project must be developed within a period of five
years from the date of obtaining all statutory clearances. The investor
would not be permitted to sell undeveloped plots.

<!-- page 2 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion
SIA (FC Division)

For the purpose of these guidelines, "undeveloped plots" will mean
where roads, water supply, street lighting, drainage, sewerage, and
other conveniences, as applicable under prescribed regulations, have
not been i~,,ade available

It will be necessary that the investor

provides this infrastructure and obtains the completion certificate from
the concerned local body/service agency before he would be allowed
to dispose of serviced housing plots.
d.

The project shall conform to the norms and standards, including land
use requirements and provision of community amenities and common
facilities, as laid down in the applicable building control regulations,
bye-laws,

rules,

and

other

regulations

of

the

State

Government!Municipal/Local B.odyconcerned.
e.

The investor shall be responsible for obtaining all necessary
approvals, including those of the building/layout plans, developing
internal and peripheral areas and other infrastructure facilities,
payment of development, external development and other charges
and complying with all other requirements as prescribed under
applicable rules/bye-Iaws/regulations of the

State Government!

Municipal/Local Body concerned.
f.

The State Government! Municipal/ Local Body concerned, which
approves the building / development plans, would monitor compliance
of the above conditions by the developer."

2.

Para (iv) of Press Note 4 (2001 Series), issued by the Government on

21.5.2001, and Press Note 3 (2002 Series), issued on 4.1.2002, stand
superceded.

'h.~
(Umesh Kumar)
Joint Secretary to the Government of India
No. 5(6)/2000-FC dated3..JMarch 2005

Copy forwarded to Press Information Officer, Press
Bureau, for giving wide publicity to the above Press Note.
j\

Information
