---
doc_id: "aadc9b4fbf1dcff2"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/3fed25a845a84b300e50c88d31a98c20.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Encouragement/Awareness to customers by ISPs for installation of end user filters (Parental Control Filters)"
date: "2017-03-27"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "756d250df9d5a21e"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi- 110 001
(Data Services Cell)
No. 813-07/25/2016-DS-II

Dated: 27/03/2017

To,

All Internet Service Providers
Subject: Encouragement/Awareness to customers by ISPs for installation of end

user filters (Parental Control Filters).
The explosion of information and communication technology has created
unprecedented opportunities for children and young people to communicate, connect, share,
learn, access information and express their opinions on matters that affect their lives and their
communities. But wider and more easily available access to the Internet and mobile
technology also poses significant-challenges to children's safety- both online and offline like
Child Abuse Material (CAM), bullying, etc.
2.
International Telecommunication Union (ITU) has recognised that' Child Online
Protection - in the era of the massively-available broadband Internet - is a critical issue that
urgently requires a global, coordinated response. Further, ITU & UNICEF has issued the
Guidelines for Industry on Child Online Protection aimed at establishing the foundation for
safer and more secure use of Internet-based services and associated technologies for today's
children and future generations. The Guidelines apply to the safety of children when using
Information and Communication Technologies (ICTs).
3.
ITU has mentioned that there are numbers of software programmes available which
can help screen out unwanted material or block unwanted contacts. Some of these child safety
and filtering programmes may be essentially free because they are part of a computer' s
operating system or they are provided as part of a package available from an ISP or TSP.
These technical tools should be used as part of a broader arsenal. Parental and/ or guardian
involvement is critical.
4.
Therefore, to reduce the risks of the digital revolution while enabling more children
and young people to reap its benefits, all ISPs are requested to make suitable arrangements to
spread awareness among their subscribers about the use of Parental Control Filters in the end
user machines through messages of email, invoices, SMS, websites, etc.

~~1
(S.K.Arya)
Director (DS-ll)
Ph-011 2303 6836
