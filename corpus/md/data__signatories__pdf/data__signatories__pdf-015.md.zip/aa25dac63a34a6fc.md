---
doc_id: "aa25dac63a34a6fc"
source_url: "https://dof.gov.in/static/uploads/2025/09/cf32fd24b6705530f8e4c96d15c767ec.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Recruitment Rules for the post of Joint Commissioner (Fisheries) in Department of Fisheries,2023"
date: "2023-08-01"
pages: 5
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "9f18260ce1455bb8"
---

<!-- page 1 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र: अगस्ट्त 5, 2023/श्रावण 14, 1945

521

their probation period for promotion to the next higher grade alongwith
their juniors who have already completed such qualifying or eligibility
service.
If Departmental Promotion Committee exist, what is its composition
12
Departmental Promotion Committee (for considering Departmental Confirmation Committee (for considering
promotion) consisting of: confirmation) consisting of: 1. Scientist ‘E’, Central Water and Power Research
1. Director, Central Water and Power Research Station,
Station, Pune- Chairman
Pune - Chairman
2. A Group ‘A’ officer from other Central Government
2. Scientist ‘E’, Central Water and Power Research
Department- Member
Station, Pune, - Member
3. ChiefAdministrative Officer, Central Water and Power 3. Under Secretary, In-charge E-II Section, Ministry of
Research Station, Pune - Member
Jal Shakti, Department of Water Resources, River
Development & Ganga Rejuvenation - Member
4. Chief Administrative Officer, Central Water and
Power Research Station, Pune
Member
Circumstances in which Union Public Service Commission is to be consulted in making recruitment
13
Consultation with Union Public Service Commission not necessary.
[F. No. A-12018/9/2021-E-II]
VINOD KUMAR GUPTA, Under Secy.

मत्स्ट्यपालन, पिुपालन और डेयरी मंत्रालय
(मत्स्ट्यपालन जवभाग)
नई दिल्ली, 1 अगस्ट्त, 2023
सा.का.जन. 90.—राष्ट्रपजत, संजविान के अनुच्छेि 309 के परंतुक द्वारा प्रित्त िजियों का प्रयोग करते,हुए और
पिुपालन, डेयरी और मत्स्ट्यपालन जवभाग, (मत्स्ट्यपालन प्रभाग, समूि‘क’, समूि‘ख’ और समूि ‘ग’ पि) भती जनयम, 2015
को ििां तक उनका संबंि संयुि आयुि (माजत्स्ट्यकी)से िैं उन बातों के जसवाय अजिक्ांत करते हुए जिन्िें ऐसे अजिक्मण से
पिले दकया गया िै या करने का लोप दकया गया िै, मत्स्ट्यपालन, पिुपालन और डेयरी मंत्रालय, मत्स्ट्यपालन जवभाग में
संयुि आयुि (माजत्स्ट्यकी), के पि पर भती की पद्धजत को जवजनयजमत करने के जलए जनम्नजलजखत जनयम बनाती िै, अथागत्:1. संजक्षप्त नाम और प्रारं भ: (1) इन जनयमों का संजक्षप्त नाम मत्स्ट्यपालन, पिुपालन और डेयरी मंत्रालय, मत्स्ट्यपालन
जवभाग, संयुि आयुि (माजत्स्ट्यकी) भती जनयम, 2023 िै।
(2) ये रािपत्र में उनके प्रकािन की तारीख को प्रवृत्त िोंगे।
2. पि संख्या, वगीकरण और वेतन मैररक्स का स्ट्तर: उि पि की संख्या, उसका वगीकरण और वेतन मैररक्स में स्ट्तर वि
िोगा, िो इन जनयमों से उपाबद्ध अनुसूची के स्ट्तंभ (2) सेस्ट्तंभ (4) में जवजनर्िगष्ट िैं।
3. भती की पद्धजत, आयु-सीमा, अिगताएं, आदि- भती की पद्धजत, आयु-सीमा, अिगताएं और उससे संबंजित अन्य बातें वे
िोंगी िो उि अनुसूची के स्ट्तंभ (5) से (13) में जवजनर्िगष्ट िैं।
4. जनरिगता - वि व्यजि(क) जिसने ऐसे व्यजि से जिसका पजत या जिसकी पत्नी िीजवत िै, जववाि दकया िै या जववाि की संजविा की िै;
(ख) जिसने अपने पजत या अपनी पत्नी के िीजवत रिते हुए दकसी व्यजि से जववाि दकया िै या जववाि की संजविा
की िै।
उि पि पर जनयुजि का पात्र निीं िोगा:

<!-- page 2 -->

522

THE GAZETTE OF INDIA : AUGUST 5, 2023/SHRAVANA 14, 1945

[PART II—SEC. 3(i)]

परं तु यदि कें रीय सरकार का यि समािान िो िाता िै दक ऐसा जववाि ऐसे व्यजि और जववाि के अन्य पक्षकार
को लागू स्ट्वीय जवजि के अिीन अनुज्ञेय िै और ऐसा करने के जलए अन्य आिार िैं तो वि दकसी व्यजि को इस जनयम के
प्रवतगन से छू ट िे सके गी।
5. जिजथल करने की िजि – ििां कें रीय सरकार की यि राय िै दक ऐसा करना आवश्यक या समीचीन िै, विां वि उसके
जलए िो कारण िैं, उन्िें लेखबद्ध करके , तथा संघ लोक सेवा आयोग से परामिग करके इन जनयमों के दकसी उपबंि को
दकसी भी वगग या प्रवगग के व्यजियों की बाबत, आिेि द्वारा जिजथल कर सके गी।
6. व्यावृजत्त – इन जनयमों की कोई बात, ऐसे आरक्षण, आयु-सीमा में छू ट और अन्य ररयायतों पर प्रभाव निीं डालेगी,
जिनका कें रीय सरकार द्वारा इस संबंि में समय-समय पर िारी दकए गए आिेिों के अनुसार अनुसूजचत िाजतयों,
अनुसूजचत िनिाजतयों, अन्य जपछड़े वगों, भूतपूवग सैजनकों और अन्य जविेष प्रवगग के व्यजियों के जलए उपबंि करना
अपेजक्षत िै।
अनुसच
ू ी
वेतन मैररक्स
का स्ट्तर

पि का नाम

पिों की संख्या

वगीकरण

(1)
1.
संयुि
आयुि
(माजत्स्ट्यकी)

(2)
01* (2023)
कायगभार के
आिार पर
पररवतगन दकया
िा सकता िै।

(3)
सािारण कें रीय सेवा,
समूि 'क', रािपजत्रत
अननुसजचवीय

(4)
वेतन मैररक्स
(12,3100
रु. 21,5900
रु.)में स्ट्तर13

क्या चयन पि िै
अथवा गैर-चयन
पि
(5)
चयन पि

आयुसीिी
भती िेतु
आयुसीमा
(6)
लागू निीं
िोता

सीिी भती िेतु
अपेजक्षत
िैजक्षक
और अन्य योग्यता

क्या सीिी भती के जलए
जनिागररत आयु और
िैजक्षक योग्यता प्रोन्नजत
वाले मामले में लागू
िोगी।

पररवीक्षा
अवजि, यदि
कोई िो।

भती की पद्धजत, सीिी भती द्वाराया प्रोन्नजत से
अथवा आमेलन द्वारा तथा जवजभन्न पद्धजतयों से
भरी िाने वाली ररजियों की प्रजतितता।

(7)

(8)

(9)

(10)

लागू निीं िोता

लागू निीं
िोता

प्रोन्नजत जिसके न िो सकने पर अल्पकाजलक
संजविा सजित प्रजतजनयुजि

लागू निीं िोता

प्रोन्नजत अथवा प्रजतजनयुजि अथवा आमेलन द्वारा भती के मामले में वे श्रेजणयां जिनसे प्रोन्नजत अथवा प्रजतजनयुजि अथवा
आमेलन दकया िाएगा।
(11)
पिोन्नजत :
उपायुि (मत्स्ट्यन बंिरगाि);
जनिेिक, कें रीय माजत्स्ट्यकी नाजवक और इं िीजनयररं ग प्रजिक्षण संस्ट्थान;
जनिेिक,कें रीय माजत्स्ट्यकी तटवती इं िीजनयररं ग संस्ट्थान;
जनिेिक, राष्ट्रीय माजत्स्ट्यकी पोस्ट्ट िावेस्ट्ट प्रौद्योजगकी और प्रजिक्षण संस्ट्थानमें वेतन मैररक्स स्ट्तर-12 (रु. 78800209200/-)में पांच वषग की जनयजमत सेवा।
रटप्पण 1: ििां ऐसे कजनष्ठ व्यजियों के संबंि में जिन्िोंने अपनी अिगक/ पात्रता सेवा पूरी कर ली िै, प्रोन्नजत के जलए
जवचार दकया िा रिा िो ििां उनसे ज्येष्ठ व्यजियों के संबंि में भी जवचार दकया िाएगा परं तु यि तब िबदक उसके

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र: अगस्ट्त 5, 2023/श्रावण 14, 1945

523

द्वारा की गई ऐसी अिगक/ पात्रता सेवा, अपेजक्षत अिगक/पात्रता के आिे से अजिक से या िो वषग से, इनमें से िो भी कम
िो, कम न िो और उन्िोंने अपने ऐसे कजनष्ठ व्यजियों सजित जिन्िोंने ऐसी अिगक /पात्रता सेवा पिले िी पूरी कर ली िै
अगली उच्चतर श्रेणी में प्रोन्नजत के जलए अपनी पररवीक्षा की अवजि सफलतापूवगक पूरी कर ली िो।
रटप्पण 2: प्रोन्नजत के जलए पात्रता सूची जनिागररत अिगता सेवा के अजिकाररयों द्वारा उनके संबजं ित ग्रेड या पि में पूरा
िोने की तारीख के संिभग में तैयार की िाएगी।
प्रजतजनयुजि (अल्पकाजलक अनुबि
ं सजित):
के न्रीय सरकार या राज्य सरकार या संघ राज्यक्षेत्र या कानूनी या स्ट्वायत्त संगठन या सावगिजनक क्षेत्र के उपक्म
यामान्यता प्राप्त जवश्वजवद्यालय या मान्यता प्राप्त अनुसंिान संस्ट्थान के अजिकारीः(क) (i)मूल संवगग या जवभाग में जनयजमत आिार पर अनुरूप पि िारण करना; या
(ii)मूल संवगग या जवभाग में वेतन मैररक्स स्ट्तर12(रु. 78800-209200/-) या समकक्ष पिों पर जनयजमत आिार पर
जनयुजि के पश्चात प्रिान की गई ग्रेड में पांच वषग की सेवा; और
(ख) जनम्नजलजखत िैक्षजणक योग्यता और अनुभव रखते िों:
(i) दकसी मान्यता प्राप्त जवश्वजवद्यालय या संस्ट्थान से माजत्स्ट्यकी में जविेषज्ञता के साथ प्राणी जवज्ञान में मास्ट्टर जडग्री
या माजत्स्ट्यकी जवज्ञान में मास्ट्टर या समुरी िीव जवज्ञान में मास्ट्टर या औद्योजगक माजत्स्ट्यकी जवज्ञान में मास्ट्टर या
िलकृ जष जवज्ञान में मास्ट्टर या माजत्स्ट्यकी जवज्ञान में मास्ट्टर;
(ii) के न्रीय सरकार या राज्य सरकार के जवभाग या संघ राज्य क्षेत्र प्रिासन या कानूनी या स्ट्वायत्त संगठन या पजब्लक
सेक्टर उपक्म या मान्यता प्राप्त जवश्वजवद्यालय या मान्यताप्राप्त अनुसंिान संस्ट्थान से प्रबंिन, नीजत और
योिना, जनमागण, और माजत्स्ट्यकी, व्यापार या माजत्स्ट्यकी स्ट्वास्ट््य से संबंजित जवकास स्ट्कीमों की मॉनीटरी सजित
माजत्स्ट्यकी (अंतिेिीय या समुरी या िलकृ जष) के क्षेत्र में अनुसि
ं ान या जवकास का िस वषग का अनुभव।
वांछनीय अिगताः दकसी मान्यता प्राप्त जवश्वजवद्यालय या संस्ट्थान से प्राणीिास्त्र में डॉक्टरे ट की जडग्री।
रटप्पण 3: पोषक प्रवगग के ऐसे जवभागीय अजिकारी, िो प्रोन्नजत की सीिी पंजि में िैं, प्रजतजनयुजि पर जनयुजि के जलए
जवचार दकए िाने के पात्र निीं िोंगे इसी प्रकार प्रजतजनयुि व्यजि प्रोन्नजत द्वारा जनयुजि के जलए जवचार दकए िाने के
पात्र निीं िोंगे।
रटप्पण 4: प्रजतजनयुजि की अवजि, जिसके अंतगगत कें रीय सरकार के उसी या दकसी अन्य संगठन/ जवभाग में इस
जनयुजि से ठीक पिले िाररत दकसी अन्य का डर बाह्य पि पर प्रजतजनयुजि की अवजि िै सािारणत या पााँच वषग से
अजिक निीं िोगी। प्रजतजनयुजि पर जनयुजि(जिसके अंतगगत अल्पकाजलक संजविा भी िै) के जलए अजिकतम आयु सीमा
आवेिन प्राप्त करने की अंजतम तारीख को छप्पन वषग से अजिक निीं िोगी।
यदि जवभागीय प्रोन्नजत सजमजत िै, तो उसकी
संरचना।

भती करने में दकन पररजस्ट्थजतयों में संघ लोक सेवा आयोग से
परामिग दकया िाएगा।

(12)

(13)

जवभागीय प्रोन्नजत सजमजत (प्रोन्नजत के जलए)
1. अध्यक्ष या सिस्ट्य यूपीएससी
अध्यक्ष

-

प्रजतजनयुजि पर अजिकारी की जनयुजि (जिसके अंतगगत
अल्पकाजलक संजविा भी िै) के जलए संघ लोक सेवा आयोग से
परामिग आवश्यक िै

2. संयुि सजचव (प्रिा.), मत्स्ट्यपालन जवभागसिस्ट्य
3. संयि
ु
सजचव, (मत्स्ट्यपालन), मत्स्ट्यपालन
जवभाग -सिस्ट्य
[फा. सं 12018/1/2022 प्रिा.I]
वी. नागानंि, अवर सजचव

<!-- page 4 -->

524

THE GAZETTE OF INDIA : AUGUST 5, 2023/SHRAVANA 14, 1945

[PART II—SEC. 3(i)]

MINISTRY OF FISHERIES, ANIMAL HUSBANDRY AND DAIRYING
(Department of Fisheries)
New Delhi, the 1st August, 2023
G.S.R. 90.— In exercise of the powers conferred by proviso to article 309 of the Constitution, and in
supersession of the Department of Animal Husbandry Dairying and Fisheries, (Fisheries Division, Group ‘A’, Group
‘B’ and Group ‘C’ Posts) Recruitment Rules, 2015 in so far as they relate to the Post of Joint Commissioner
(Fisheries), except as respects things done or omitted to be done before such supersession, the President hereby
makes the following rules regulating the method of recruitment to the post of Joint Commissioner (Fisheries) in the
Ministry of Fisheries, Animal Husbandry and Dairying, Department of Fisheries, namely:1. Short title and commencement.–(1) These rules may be called the Ministry of Fisheries, Animal Husbandry and
Dairying, Department of Fisheries, Joint Commissioner (Fisheries) Recruitment Rules, 2023.

(2) They shall come into force on the date of their publication in the Official Gazette.
2. Number of post, classification and level in the pay matrix.- The number of post, its classification and the level
in the pay matrix attached thereto shall be a specified in columns (2) to (4) of the Schedule.
3. Method of recruitment, age limit, other qualifications, etc.– The method of recruitment, age limit, qualifications
and other matters relating to the said post shall be as specified in columns (5) to (13) of the said Schedule.
4. Disqualification.– No person, (a) who has entered into or contracted a marriage with a person having a spouse living, or
(b) who, having a spouse living, has entered into or contracted a marriage with any person,
shall be eligible for appointment to the said post:
Provided that the Central Government may, if satisfied that such marriage is permissible under the personal
law applicable to such person and the other party to the marriage and that there are other grounds for so doing, exempt
any person from the operation of this rule.
5. Power to relax.– Where the Central Government is of the opinion that it is necessary or expedient so to do, it may,
by order and for reasons to be recorded in writing and in consultation with the Union Public Service Commission,
relax any of the provisions of these rules with respect to any class or category of persons.
6. Saving.– Nothing in these rules shall affect reservations, relaxation of age limit and other concessions required to
be provided for the Scheduled Castes, the Scheduled Tribes, Ex-servicemen and other special categories of persons
in accordance with the orders issued by the Central Government from time to time in this regard.
SCHEDULE
Name of
Post.

Number
of posts.

Classification

Level in
pay matrix.

(1)
Joint
Commissioner
(Fisheries).

(2)
01
(2023)
Subject to
variation
dependent on
workload.

(3)
General Central
Service,
Group “A”,
Gazetted, NonMinisterial.

(4)
Level-13
(Rs.1,23,1002,15,900)in the
pay matrix.

Educational and
other qualification
required for direct
recruits.
(7)
Not applicable.

Whether age and
educational qualification
prescribed for direct
recruits will apply in the
case of promotees.
(8)
Not applicable.

Period of
probation, if
any

(9)
Not
applicable.

Whether
selection post
or nonselection post.
(5)
Selection Post.

Aged-limit for
direct recruits.

(6)
Not applicable.

Method of recruitment: whether by
direct recruitment or by promotion
or by deputation/ absorption and
percentage of the vacancies to be
filled by various methods.
(10)
Promotion failing which Deputation
including short-term contract.

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

a.

i.

भारत का रािपत्र: अगस्ट्त 5, 2023/श्रावण 14, 1945

525

In case of recruitment by promotion or deputation/absorption, grades from which promotion or deputation
or absorption to be made.
(11)
Promotion :
Deputy Commissioner (Fishing Harbour);
Director, Central Institute of Fishing Nautical and Engineering Training;
Director, Central Institute of Coastal Engineering for Fisheries;
Director, National Institute of Fisheries Post Harvest Technology and Training
in Level-12 (Rs.78800- 209200/-) of pay matrix with five years of regular service in the grade.
Note 1: Where juniors who have completed their qualifying or eligibility service are being considered for
promotion, their seniors would also be considered provided they are not short of the requisite qualifying or
eligibility service by more than half of such qualifying or eligibility service or two years, whichever is less and
have successfully completed their probation period for promotion to the next higher grade along with their juniors
who have already completed such qualifying or eligibility service.
Note2: The eligibility list for promotion shall be prepared with reference to the date of completion by the officers
of the prescribed qualifying service in their respective grade or post.
Deputation (Including Short-Term Contract) :Officers of the Central Government or State Government or Union territory Administrations or Statutory or
Autonomous Organisations or Public Sector Undertakings or Recognised Universities or Recognised Research
Institutes:(i) holding analogous posts on regular basis in the parent cadre or Department; or
(ii) with five years service in the grade rendered after appointment there to on regular basis in posts in Level- 12
(Rs.78800- 209200/-) of pay matrix or equivalent in the parent cadre or department; and
(b) possessing the following educational qualifications and experience:(i) Masters degree in Zoology with specialisation in Fisheries; or M.F.Sc. or M.Sc. in Marine Biology or
M.Sc. in Industrial Fisheries or M.Sc. in Aquaculture or M.Sc. in Fisheries Science from a recognised University
or Institute.
(ii) ten years experience of research or development in the field of Fisheries (Inland or Marine or
Aquaculture) including management, policy and planning, formulation and monitoring of development Schemes
for fisheries and trade or fishery health related matter from a Central Government or State Government
Department or Union territory Administration or Statutory or Autonomous Organisation or Public Sector
Undertaking or recognised University or Recognised Research Institute.
Desirable Qualification: Doctorate degree in Zoology from a recognised University or Institute.
Note 3: The departmental officers in the feeder category who are in the direct line of promotion will not be eligible
for consideration for appointment on deputation. Similarly, deputationists shall not be eligible for consideration for
appointment by promotion.
Note 4: Period of deputation (including short-term contract) including period of deputation (including shorttermcontract) in another ex-cadre post held immediately preceding this appointment in the same or some other
organisation or Department of the Central Government shall ordinarily not to exceed five years. The maximum age
limits for appointment by deputation (including short-term contract) shall be not exceeding fifty-six years as on the
closing date of the receipt of applications).

If a Departmental Promotion Committee exists, what is its composition

(12)
Departmental Promotion Committee (for promotion):1. Chairman or Member, UPSC - Chairman
2. Joint Secretary (Admn.), Department of Fisheries - Member
3. Joint Secretary (Fisheries), Department of Fisheries - Member

Circumstances in which
Union Public Service
Commission to be
consulted in making
recruitment
(13)
Consultation with Union
Public Service Commission
is necessary for appointing
an officer on deputation
(including short-term
contract) basis.
[F. No. A-12018/1/2022 Admn I]
V. NAGANAND, Under Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH KUMAR
SRIVASTAVA
Date: 2023.08.08 15:58:04 +05'30'
