---
doc_id: "a9abcf9bfced1343"
source_url: "https://powermin.gov.in/static/uploads/2026/06/f89ac0cd4dec58a497aef0f15c653379.pdf"
ministry: "Power"
title: "Electricity Amendment Rules 2025"
date: "2025-09-19"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "d6228e66ed093920"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

xxxGIDHxxx

सी.जी.-डी.एल.-अ.-20092025-266274
xxxGIDExxx
CG-DL-E-20092025-266274
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 611]

नई दिल्ली, िुक्रिार, जसतम्बर 19, 2025/भाद्र 28, 1947
NEW DELHI, FRIDAY, SEPTEMBER 19, 2025/BHADRA 28, 1947

No. 611]

जिद्युत मंत्रालय
अजधसूचना
नई दिल्ली, 19 जसतम्बर, 2025
सा.का.जन. 688(अ).––कें द्रीय सरकार, जिद्युत अजधजनयम, 2003 (2003 का अजधजनयम 36) की धारा 176 द्वारा प्रित्त
िजियों का प्रयोग करते हुए जिद्युत जनयम, 2005 का और संिोधन करने के जलए जनम्नजलजखत जनयम बनाती है, अर्ाात् 1. संजिप्त नाम और प्रारं भ -(1) इन जनयमों का संजिप्त नाम जिद्युत (संिोधन) जनयम, 2025 है।
(2) ये रािपत्र में उनके प्रकािन की तारीख को प्रिृत्त होंगे।
2.

जिद्युत जनयम, 2005, के जनयम 18 में,-

(i) उप-जनयम (2), के स्ट्र्ान पर जनम्नजलजखत उप-जनयम रखा िाएगा, अर्ाात:् “(2) ऊिाा भंडारण प्रणाली का उपयोग या तो स्ट्ितंत्र ऊिाा भंडारण प्रणाली के रूप में या उत्पािन, पारे षण या जितरण के
भाग के रूप में दकया िाएगा।”
(ii) उप-जनयम (4) और (5), के स्ट्र्ान पर जनम्नजलजखत उप-जनयम रखे िाएंगे, अर्ाात्:“(4)(क) ऊिाा भंडारण प्रणाली का जिकास, स्ट्िाजमत्ि, पट्टा या संचालन दकसी उत्पािन कं पनी या दकसी पारे षण
अनुज्ञजप्तधारी या दकसी जितरण अनुज्ञजप्तधारी या दकसी उपभोिा या दकसी प्रणाली प्रचालक या दकसी स्ट्ितंत्र ऊिाा
भंडारण सेिा प्रिाता द्वारा दकया िाएगा।

6224 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(ख) दकसी उत्पािन स्ट्टेिन या दकसी पारे षण अनुज्ञजप्तधारी या दकसी जितरण अनुज्ञजप्तधारी या दकसी उपभोिा के
स्ट्िाजमत्ि और संचालन िाली तर्ा उनके सार् सह-अिजस्ट्र्त ऊिाा भंडारण प्रणाली की जिजधक प्राजस्ट्र्जत िही होगी िो
स्ट्िामी की है:
परं तु यदि ऐसी ऊिाा भंडारण प्रणाली उत्पािन स्ट्टेिन या जितरण अनुज्ञजप्तधारी या उपभोिा के सार् सह-अिजस्ट्र्त नहीं
है, ककं तु उसके स्ट्िाजमत्ि में है और उनके द्वारा प्रचाजलत है, तो जिजधक प्राजस्ट्र्जत तब भी िही होगी िो स्ट्िामी की है, ककं तु
समय-जनधाारण और प्रेषण तर्ा अन्य मामलों के प्रयोिन के जलए इसे एक पृर्क भंडारण तत्ि के समतुल्य माना िाएगा।
(5) ऊिाा भंडारण प्रणाली के जिकासकताा या स्ट्िामी के पास भंडारण िमता को पूणत
ा ः या आंजिक रूप से दकसी उपभोिा
को या उत्पािन या पारे षण या जितरण में लगी दकसी यूटटजलटी को या दकसी भार प्रेषण कें द्र को या दकसी अन्य व्यजि को
जिक्रय करने या पट्टे पर या दकराए पर िेने का जिकल्प होगा। ”
[फा. सं. 23/2/2022-आरएंडआर]
श्रीकांत नागुलापल्ली, अपर सजचि
टटप्पणी: मूल जनयम भारत के रािपत्र भाग II, खंड 3, उपखंड (i) में संखयांक सा.का.जन. 379(अ), तारीख 8 िून, 2005
द्वारा प्रकाजित दकए गए र्े और अंजतम बार संखयांक सा.का.जन. 181(अ), तारीख 12 माचा, 2024 द्वारा
संिोजधत दकए गए र्े।
MINISTRY OF POWER
NOTIFICATION
New Delhi, the 19th September, 2025
G.S.R. 688(E).––In exercise of the powers conferred by section 176 of the Electricity Act, 2003 (Act 36 of
2003), the Central Government hereby makes the following rules further to amend the Electricity Rules, 2005,
namely:1. Short title and commencement. - (1)

These rules may be called the Electricity (Amendment) Rules, 2025.

(2) They shall come into force on the date of their publication in the Official Gazette.
2.

In the Electricity Rules, 2005, in rule 18,-

(i) for sub-rule (2), the following sub-rules shall be substituted, namely:"(2) The Energy Storage System shall be utilised either as independent energy storage system or as part of generation,
transmission or distribution.”
(ii) for sub-rules (4) and (5), the following sub rules shall be substituted, namely:“(4)(a) The Energy Storage System may be developed, owned, leased or operated by a generating company or a
transmission licensee or a distribution licensee or a consumer or a system operator or an independent energy storage
service provider.
(b) The Energy Storage System owned and operated by and co-located with a generating station or a transmission
licensee or a distribution licensee or a consumer, shall have the same legal status as that of the owner:
Provided that if such an Energy Storage System is not co-located with, but owned and operated by, the generating
station or distribution licensee or consumer, the legal status shall still be that of the owner but for the purpose of
scheduling and dispatch and other matters it shall be treated at par with a separate storage element.
(5) The developer or owner of the Energy Storage System, shall have an option to sell or lease or rent out the storage
capacity in whole or in part to any consumer or utility engaged in generation or transmission or distribution or to a
Load Despatch Centre or any other person.”
[F. No. 23/2/2022-R&R]
SRIKANT NAGULAPALLI, Addl. Secy.
Note: The Principal rules were published in the Gazette of India Part II, Section 3, Sub-section(i), vide number G.S.R.
379(E), dated the 8th June, 2005 and were last amended vide number G.S.R 181(E), dated the
12th, March 2024.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH KUMAR
SRIVASTAVA
Date: 2025.09.20 16:35:53 +05'30'
