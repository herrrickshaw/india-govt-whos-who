---
doc_id: "a8bee2ceb1fe1a6f"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/6201d135455e90b9e97f4abefa251af3.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Broadband policy, 2004"
date: "2004-05-25"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "da85a2113fb90135"
---

<!-- page 1 -->

BROADBAND POLICY
2004
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 2 -->

Government of India
Ministry of Communications and Information Technology
Department of Telecommunications

open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 3 -->

BROADBAND POLICY 2004

Website: www.dot.gov.in
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 4 -->

BROADBAND POLICY 2004
Contents
Particulars

Page Nos.

PREAMBLE
BROADBAND CONNECTIVITY

1
2

ESTIMATED GROWTH

2

TECHNOLOGY OPTIONS FOR BROADBAND SERVICES

3

�

Various Access Technologies
� Optical Fibre Technologies

3
3

Digital Subscriber Lines (DSL) on copper loop
Cable TV Network

4
5

�
�
�

Satellite Media
Terrestrial Wireless
Future Technologies

5
7
7

�
�

�
�
open in browser PRO version

Quality of Service (QoS)
Simplification of SACFA / WPC Clearance

Are you a developer? Try out the HTML to PDF API

8
8
pdfcrowd.com

<!-- page 5 -->

OTHER ISSUES
� Bandwidth Availability
�
�
�

National Internet Exchange of India (NIXI)
Role of Other Agencies
Fiscal Issues

9
9
9
9
10

File No.813-07/03-LR
Government of India
Ministry of Communications & Information Technology
Department of Telecommunications

BROADBAND POLICY 2004
Preamble
Recognising the potential of ubiquitous Broadband service in growth of GDP and enhancement in quality of life
through societal applications including tele-education, tele-medicine, e-governance, entertainment as well as employment
generation by way of high speed access to information and web-based communication, Government have finalised a
policy to accelerate the growth of Broadband services.
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 6 -->

Demand for Broadband is primarily conditioned and driven by Internet and PC penetration. It is recognised that the
current level of Internet and Broadband access in the country is low as compared to many Asian countries. Penetration of
Broadband, Internet and Personal Computer (PC) in the country was 0.02%, 0.4% and 0.8% respectively at the end of
December, 2003. Currently, high speed Internet access is available at various speeds from 64 kilobits per second (kbps)
onwards and presently an always-on high speed Internet access at 128 kbps is considered as �Broadband�. There are
no uniform standards for Broadband connectivity and various countries follow various standards.
Government envision an accelerated growth in Internet penetration and PC as the success of Broadband would
largely be dependent on their spread. It has been decided that following shall be the framework of the policy.

1.0 Broadband connectivity:
Keeping in view the present status, Broadband connectivity is defined at present as
�An �always-on� data connection that is able to support interactive services including
Internet access and has the capability of the minimum download speed of 256 kilo bits per
second (kbps) to an individual subscriber from the Point Of Presence (POP) of the service
provider intending to provide Broadband service where multiple such individual Broadband
connections are aggregated and the subscriber is able to access these interactive services
including the Internet through this POP. The interactive services will exclude any services for
which a separate licence is specifically required, for example, real-time voice transmission,
except to the extent that it is presently permitted under ISP licence with Internet Telephony.�
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 7 -->

2.0

The estimated growth for Broadband and Internet subscribers in the country envisaged through various technologies

is as follows:
Year Ending

Internet Subscribers

Broadband Subscribers

2005

6 million

3 million

2007

18 million

9 million

2010

40 million

20 million

3.0 Technology Options for Broadband Services
The Broadband Policy Framework visualises creation of infrastructure through various access technologies which
can contribute to growth and can mutually coexist. Spread of infrastructure is a must for healthy competition and therefore it
would be the endeavour of the Government that the telecommunication infrastructure growth in the country is not
compromised in any manner.

3.1

Various access technologies, inter-alia, are:
(a) Optical Fibre Technologies
The fibre optics technology can provide nearly unlimited bandwidth potential and is steadily replacing copper
network specially in intra-city backbone networks. This is being deployed in commercial buildings and complexes
and some metros / big cities having high-density potential broadband subscribers. Hybrid Fibre Coaxial (HFC),
Fibre to the Curb (FTTC) and Fibre to the Home (FTTH) networks make use of fibre cabling into the last mile. The

open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 8 -->

fibre based models are future proof as they are able to provide huge amounts of bandwidth in the last mile as well
as provide a true IP and converged network that can deliver high quality voice, data and video.
There are more than 4.5 lakh route kms. of optical fibre laid by BSNL / MTNL and more than 1 lakh route kms laid by
private operators. The spread of the networks of private service providers have to play an important role in bringing
the fibre to homes as well as the rural areas and they are expected to focus on it.
With the increase in commercial availability of fibre technologies, the cost of fibre rollout is approaching the cost of
other wired networks. Spread of optical fibre networks shall be emphasised keeping in view the long-term
perspective.

(b)

Digital Subscriber Lines(DSL) on copper loop :

DSL has proved to be an important technology for provisioning of Broadband services through the copper loop. The
owners of copper loop have to be given a high priority because their role is critical as key drivers in the Broadband
service market using DSL.
Bharat Sanchar Nigam Limited (BSNL) and Mahanagar Telephone Nigam Limited (MTNL) as well as other access
providers are expected to aggressively use their copper loop infrastructure for providing Broadband services
through this technology.
Recognising that last mile copper loop is not a �bottleneck facility� for broadband services, access
providers shall be free to enter into mutually agreed commercial arrangements for utilization of available
copper loop for expansion of broadband services. The owner of local loop shall be free to decide the areas in
which investment is to be made to upgrade the infrastructure for Broadband services. The information regarding the
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 9 -->

areas in which Broadband services are being offered by a service provider shall be available in the public domain.
Further, use of brand-name being treated as a part of the value shall be permitted in such commercial
arrangements.
There are more than 40 million copper loops in the country available with BSNL and MTNL out of which 14 million
loops are in rural areas. Copper cable network of these operators is a combination of old and new cable and this
makes provisioning of Broadband on all the available copper loop technically unfit . Therefore, around 25-30% of
the remaining 26 million loops, i.e. approximately 7 million loops can be leveraged for broadband service by BSNL
and MTNL taking into account the condition / life of copper cable and demand potential.
Management of BSNL and MTNL has decided to provide 1.5 million connections by the end of 2005. The
corporate / work plan of these PSUs have been drawn up for this purpose. Thereafter, annual plan for expansion of
Broadband services by BSNL and MTNL will be determined in consultation with them. A quarterly review of their
performance by the Government in the Department of Telecommunications (DoT) shall be undertaken to evaluate
the achievement and redefine the future roadmap, if necessary.
It is hoped that other access service providers would also provide broadband connections using their copper in a
targeted manner. A constructive review of their performance shall also be undertaken.

(c) Cable TV Network
It is noted that cable TV connection as last mile infrastructure reaches more people than even the telephone copper
infrastructure and can be leveraged in providing cable operators a new business model while giving a stimulus to
Broadband penetration. Therefore, Cable TV network can be used as franchisee network of the service
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 10 -->

provider for provisioning Broadband services. However, all responsibilities for ensuring compliance of
terms & conditions of the licence shall vest with the Licensee. The terms of franchise agreement
between Licensee and his franchisee shall be settled mutually by negotiation between the two parties
involved.

(d) Satellite Media
Very Small Aperture Terminals (VSAT) and Direct-to-Home(DTH) services would be encouraged for
penetration of Broadband and Internet services with the added advantage to serve remote and
inaccessible areas.
It is the intention of the Government to make available transponder capacity for VSAT services at competitive rates
after taking into consideration the security requirements. Department of Space is already interacting with VSAT
service providers. Department of Telecommunications, in consultation with the concerned Ministries, will soon
propose measures in the direction of Open Sky Policy for VSAT operators. The role of Department of Space is
critical in such an endeavour.
VSAT service providers are permitted to transmit data upto 2Mbps instead of earlier limit of 512 kbps in a Closed
User Group domestic VSAT network. The increased data rate allows new applications like bulk data transfer for
software industry, high-speed backhaul links, in-house training using audio-visual etc. Reduction in antenna size
enables easy installation, lower space occupancy, lower cost of hardware etc. Accordingly, the antenna size has
been reduced to 1.2 metres and 2.4 metres for star network and mesh network respectively in extended C-band. In
Ku-band also, 1 metre diameter antenna in star network has been permitted. To keep pace with technological
advances, this shall be periodically reviewed.
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 11 -->

Commercial VSAT service providers having ISP licence shall be permitted use of same hub station and
remote station to provide Internet service directly to the subscribers. Further, this remote station shall be
permitted to be used as a distribution point to provide Internet services to multiple independent
subscribers. Necessary amendments in the licence agreement shall be carried out immediately.
DTH service providers shall be permitted to provide Receive Only Internet Service after obtaining ISP
licence from Department of Telecommunications. Further, ISP licensees shall be permitted to allow
customers for downloading data through DTH after obtaining necessary permission from the competent
authority. DTH Service providers will also be permitted to provide bidirectional Internet services after
obtaining VSAT and ISP licence from DoT.

(e) Terrestrial Wireless
Recognising that terrestrial wireless is another upcoming technology platform for Broadband, it has been decided
in principle to de-licence 2.40-2.48 GHz band for low-power outdoor use on non-protection, noninterference and non-exclusive basis. Necessary notification shall be issued. Further, notification
regarding delicensing 2.40-2.4835 MHz band for low power indoor permitting use of all technologies,
which inter-alia include those based on IEEE 802.11b and 802.11g standards, has been issued.
To accelerate penetration of Broadband and Internet, the 5.15-5.35 GHz band shall be de-licensed for the
indoor use of low power Wi-Fi systems. For outdoor use, the band 5.25-5.35 GHz shall be de-licensed in
consultation with DoS and delicensing in the band 5.15-5.25 GHz would be considered after the process
of vacation. Alternative spectrum bands which are not in high usage and could be deployed for Broadband
services, shall also be explored and identified.
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 12 -->

(f) Future Technologies
In the changing technology scenario, there is a possibility of new options being used for provisioning of Broadband
services. These technologies can also be utilised for provisioning of such services within the licensing framework of
the service provider and the spectrum management policy of DoT.

3.2

Quality of Service (QoS)

As per TRAI Act, 1997, TRAI has to prescribe QoS parameters. Government recognises that QoS parameters are
extremely important and have an impact on investment and roll-out decisions of operators. TRAI would be requested to
prescribe QoS parameters for provisioning of broadband service using various access technologies at an early date.

3.3

Simplification of SACFA / WPC clearance
The VSAT operators shall be allowed to start the installation process for VSAT terminals after a period of

one month of submitting all relevant documents to WPC for SACFA / WPC clearance wherever the total height
of such installation is less than 5 meters above the rooftop of an authorised building.
In the case of Receive Only VSAT terminals and DTH with Receive Only Internet, no SACFA / WPC
clearance will be required wherever the total height of such installation is less than 5 meters above the rooftop
of an authorised building.
Government have decided that the reference to WLL in IND49 of NFAP-2002 shall be deleted to promote
use of indigenously developed technologies. This would enable service providers, other than basic service
operators, to use the 1880-1900 MHz band for provision of various services under their licence.
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 13 -->

A transparent scheme is being outlined separately for time-bound frequency allocation, siting clearance
and wireless licensing by removing the cumbersome procedures, computerisation and by setting
predetermined standards.

4.0 Other Issues
4.1

Bandwidth availability including international bandwidth is a major driver for broadband services. In a competitive
environment, service providers are expected to take appropriate steps for making required bandwidth available in a time
bound manner within their licence framework. Cost of bandwidth constitutes a major cost component for Broadband
services. Government and TRAI would address this issue on priority. TRAI has already issued a consultation paper for
international bandwidth leased line cost and is expected to address the issue shortly.
Government have recently decided to reduce the licence fee for Infrastructure Provider category-II, who provides end
to end bandwidth, to 6% of Adjusted Gross Revenue (AGR). Further, the amount of bank guarantee for such service
provider has also been reduced to Rs.5 crores from Rs.100 crores.

4.2

National Internet Exchange of India (NIXI) has been set up by DIT, Government of India to ensure that Internet traffic,

originating and destined for India, should be routed within India. It is expected that NIXI will take appropriate steps for
increasing the utilization of such facilities.
open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 14 -->

4.3

Role of other Agencies

PCs, content and applications are important constituents for overall growth of Internet and Broadband services.
Broadband services will accelerate decentralised governance at Panchayat level.
The role of other facilitators such as electricity authorities, Departments of ITs of various State Governments,
Departments of Local Self Governments, Panchayats, Department of Health and Family Welfare, Department of Education
is very important to carry the advantage of Broadband services to the users particularly in rural areas.

4.4

Fiscal Issues

The Department of Telecommunications assigns a very high priority to indigenous manufacture of Broadband
related equipments. It shall endeavour to work closely with the concerned Ministries and Manufacturers� Associations so
that the equipments are available at an affordable price. The department is conscious of the fact that Broadband services
can reach the urban and rural consumers only if services are offered at affordable and easy terms. Department of
Telecommunications will work out a package in consultation with Ministry of Finance and related Departments as well as
concerned service providers to achieve this.
______

open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 15 -->

Government of lndia
Ministry of Conimunications & LT
Depart1nent or Te Iecon1111 unicalions
Sanchar Bhawan, 20 Ashoka Road
New Delhi-110 001
No.8 I 3-7103-LR

Dated: 13°1 Dece1nber. 2004

OFFICE MEMORANDUM
Subject:

Arnend1nent lo Broadband Policv 2004

The lol lowing amendn1ents to t he Broadband Policy 2004 are
hereby issued:
I.

Alter 2"d sub-para of para 3.3. the Collo\ving para is inserted.
na1nely:
Other wireless installations >vith antenna height less than 5 metres,
above the rooftop of an authorised bui lding, 1vi ll also not require
SACF A clearance for such antenna.

2.
open in browser PRO version

In para 3. 1(e), the phrase "2.40 - 2.4835 Ml tz•· is substituted wit h
..2.40 - 2.4835 Ollz,..

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com

<!-- page 16 -->

\~
..... _ 13/t""\.M
(Jayant

urnar)

Director(LR-rr)

open in browser PRO version

Are you a developer? Try out the HTML to PDF API

pdfcrowd.com
