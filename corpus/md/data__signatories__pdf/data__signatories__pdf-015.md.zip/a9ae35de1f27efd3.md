---
doc_id: "a9ae35de1f27efd3"
source_url: "https://www.dahd.gov.in/static/uploads/2025/08/50fa85e98a1cc25b0b71b51a906a69d2.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Recruitment to two vacant posts of Fodder Agronomist, Group A, Gazetted, Non-Ministerial in various Regional Fodder Stations by deputation(ISTC)/Absorption basis- regarding."
date: "2024-05-27"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8412ef6af5bcd0f3"
---

<!-- page 1 -->

frEg16'aRr EmailERr
No. Q-1401 2/l/201 7-Admin_6 IE4934

Trsg

ar{dE{.rK

rFFrcffia,cgcrfiddklqttdrrfic

AZ'aCllKa

qgqrr{$t{lsttfunrr

Amrlt[yls[61ssy

Ut||rSEr-6 (NLM Division)

iirf,to'trfi, atfrid,
fraiir: 20.05.202,1
To,

'1. All Secretaries to the Government of lndia
2. The Secretary, ICAR, Krishi Bhawan, New Delhi-1 10001
3. The Secretary, Department of Agriculture
(All State Government and Union Territories)
4. The Secretary, Department of Animal Husbandry
(All State Government and Union Territories)
5. The Registrar, All Agriculture Universities
6. The Director, All Recognized Research lnstitutions
7. The CMD, All Public Sector Undertakings
8. The Chairman, Statutory Organisations
9. The Chairman, Autonomous Bodies.

Subiect:

Recruitment to two (02) vacant posts of Fodder Agronomist, Group 'A', Gazetted,
Non-Ministerial in the Level-10 (Rs. 56100-1775001-) of the pay matrix in various
Regional Fodder Stations, subordinate offices under National Livestock Mission
(NLM) Division
this Department on Deputation (including short-term
contract)/absorption basis - regarding.

of

Sir/Madam,
I am directed to refer to this office letter of even number dated 13.02.2024, on the above
mentioned subject and to say that the last date of receiving of applications in respect of the two
(02) vacant posts of Fodder Agronomist, Group 'A', Gazetted, Non-Ministerial in various Regional
Fodder Stations to be filled on Deputation (including short-term contract)/absorption basis, which
was published in the Employment News daled 24 February- 1 March, 2024, has been extended
for another 60 days from the date of publication of the advertisement in the upcoming weekly
Employment News.

2.

The complete details including eligibility conditions as per notified RRs of this post was
given in the earlier letter dated '13.02.2024 and is enclosed herewith, which is also available on
the website of this Department i.e. dahd.nic.in.

3. Application in triplicate, in the enclosed Performa along with the complete up-todate CR dossiers (last five years) of officers who are willing to be considered and can be
spared in the event of their selection, may be sent to this Department. While forwarding
applications, it may be verified and certified that particulars furnished by the candidates are
correct and that no vigilance case is either pending or contemplated against them and their
integrity is beyond doubt. A statement on imposition of penalty during the last 10 years may also
be provided. A cadre clearance certificate in respect of candidate may also be fonrvarded to this
Department. Any application forwarded earlier in respect of any applicant needs not be forwarded
again.

<!-- page 2 -->

4.

Applications received after the due date or found incomplete will not be considered.
Applications should reach this Department through proper channel within 60 davs from the date
of publication of advertisement to the following address:
Ms. Anamika Nigam,
Under Secretary(Admin_6),
Department of Animal Husbandry and Dairying,
Right Stilt Floor, Chanderlok Building, Janpath, New Delhi-1 't0001
Email: anamikaedu@nic.in
Yours faithful ly,
Encl: as above

Anamika Nigam)
Under Secretary to the Government of lndia
Te!. No. 0'11-2331't033
Coov with enclos ures forwarded to:-

. Director (NlC), DAHD for uploading the same on the website of this Department.
2 . Guard file/ Spare Copies.
1

s

(Anamika Nigam)
Under Secretary to the Government of lndia
Tel. No. 011-23311033
