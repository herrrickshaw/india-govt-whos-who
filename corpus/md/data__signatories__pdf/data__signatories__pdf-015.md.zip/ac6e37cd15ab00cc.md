---
doc_id: "ac6e37cd15ab00cc"
source_url: "https://master-dopt.digifootprint.gov.in/static/uploads/2025/10/8cd435d30e6177f658a361d6c29bf2a2.pdf"
ministry: "Department of Personnel and Training (DoPT)"
title: "OM No. 49014/2/93Estt.(C)"
date: "1994-03-09"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "26a3ad1d8877cce7"
---

<!-- page 1 -->

Ministry of Personnel, Public Grievances and Pensions (Deptt. of Personnel and
Training)
OM No. 49014/2/93 Estt. ( C )
dated 9th March, 1994.
(XXII)
Subject: Grant of temporary status and regularisation of casual workers Admissibility of Interim Relief.
The undersigned is directed to refer to Department of Personnel & Training OM No.
51016/2/90-Estt. ( C) dated 10th September, 1993 on the subject noted above and to
say that references have been received from various Ministries/Departments seeking
clarification whether Interim Relief of Rs.100/-p.m. granted to Central Government
employees vide Ministry of Finance, Department of Expenditure OM No. 7 (26)/E.III/93
dated 27.9.93 would be admissible to casual employees who have been bestowed with
temporary status.
2. The matter has been considered in consultation with Ministry of Finance and it has
been decided that the Interim Relief at the rate of Rs. 100/- p.m. will be admissible to
casual employees with temporary status and also to casual employees who are entitled
to daily wages with reference to minimum of the pay scale for corresponding regular
Group ‘D’ official including DA, HRA and CCA or Pay plus DA. The casual employees
entitled to daily wages not linked to minimum of the pay scale plus DA for corresponding
regular Group ‘D’ employees or casual workers/contingent employees engaged on parttime basis shall not be entitled to Interim Relief.
3. The above decision is effective from 16.9.93.
Sd/V.NATARAJAN
Deputy Secretary to the Govt. of India.
