---
doc_id: "aa2efe2e96bd7adf"
source_url: "https://doj.gov.in/static/uploads/2025/09/d300a1d848b086db0c97a00cf7ef9ee4.pdf"
ministry: "Department of Justice (DoJ)"
title: "Corrigendum of Eleventh Meeting of Advisory Council of the National Mission for Justice Delivery and Legal Ref held on 19.02.2019"
date: "2019-02-19"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "8e4cc26c4cee49d2"
---

<!-- page 1 -->

Tae
File No. N- 17/11/2017-NM
Government of India
Ministry of Law and Justice
Department of Justice
nonce हैक जैफ कै
Jaisalmer House, 26 Mansingh Road,
New Delhi-110011
Dated: 05.03.2019
CORRIGENDUM
Subject:- Minutes of the Eleventh Meeting of the Advisory Council of the National Mission Council of the National Mission
for Justice Delivery and Legal Reforms held on 19.02.2019. 19.02.2019.
With reference to the Minutes of the Eleventh Meeting of the Advisory Council of the
National Mission for Justice Delivery and Legal Reforms held on 19.02.2019 circulated vide
letter of even no. dated 28.02.2019, it is requested that the contention of Shri Sanjeev S.
Kalgaonkar, Secretary General, Supreme Court in Para 9 of the Minutes may be read as per
column no. 2 below:-.
Shri Sanjeev S. Kalgaonkar
Out of 2.60 crore cases in| Out of 2.13 crore criminal cases in subordinate
subordinate courts, about 46% | courts, about 46% cases are pending for appearance
cases are pending for appearance | as per NJDG data. 23% more civil cases are relating
as per NJDG data. 23% more | to summoning. In addition, 50.42 lakhs cases are of
cases are relating to summoning. | petty offences. There is a need to take urgent steps
In addition, 50.42 lakhs cases are | in this regard in order to reduce pendency.
of petty offences. There is a need
to take urgent steps in this regard
in order to reduce pendency. «
८४६2 7
“~~ ee के
«5४ हि | f= ae
Nee Se ons ex aoe
va US
1 gd * न (Giridhar G.Pai)
ae ee : Director
\ WL Telefax: 23072145
le
En SS
JY Hon'ble Mi ister-of State, Ministry of Home Affairs, North Block, New Delhi.
2 Hon'ble Chairman, Department related Parliamentary Standing Committee on
Personnel, Public Grievance, Law and Justice, Rajya Sabha Secretariat, New Delhi.
34 Hon'ble Minister of Law & Courts, Andhra Pradesh, 1st Floor, Building-l, Velagapudi,
Hyderabad (A.P)
4 Ld. Attorney General for India, N-234-A, Greater Kailash-I, New Delhi.
5/4 Ld Solicitor General of India, Chamber No. 25A, Second Floor, Supreme Court, New
Delhi.
67 Prof. (Dr.) N. R. Madhava Menon, Rema Madhava, Maniyasseri Temple West,
jaravanthuruthu, P.O. Vaikom, Kottayam District, Kerala - 686608.
मद Legislative Department, Ministry of Law and Justice, 4th Floor, Shastri
hawan, New Delhi.
8 Rearetary, Department of Legal Affairs, Ministry of Law and Justice, 4th Floor, A- Wing,
Shastri Bhawan, New Delhi.

<!-- page 2 -->

s ’ 9.ecretary General, Supreme Court of India, Bhagwan Das Road, New Delhi.
6 irector, National Judicial Academy, P.O. Suraj Nagar, Bhopal-462044 (M.P)
> T@Chairman, Bar Council of India, 21, Rouse Avenue Institutional Area, New Delhi.
“Secretary, Department of Law and Justice, Parliamentary Affairs,
Civil Secretariat (Room No.G-7), Government of Jammu & Kashmir, Jammu.
19.9७ Commission of India, 4th Floor, B Wing, Lok Nayak Bhawan, Khan Market, New
Delhi. .
Copy to: 5
VPS to Hon'ble Minister of Law and Justice File . BS
LPS to Hon'ble Minister of State for Law and Justice + ie a \ »“
3. PSO to Secretary (Justice) KRG So oP ae
4, JS (Sh. Sadanand Vasant Date) fe .% था
5. JS (Sh. Rajinder Kumar Kashyap) Ny a? 4 ya
Jan (Ms. Sushma Taishete) x “ 9
“JS (Sh. Daniel Richards), Ministry of Home Affairs \ < yf
‘ x awe
(Giridhar G.Pai)
