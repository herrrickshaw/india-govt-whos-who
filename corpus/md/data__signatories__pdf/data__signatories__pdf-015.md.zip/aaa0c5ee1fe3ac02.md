---
doc_id: "aaa0c5ee1fe3ac02"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/8343a54f48f6b76c16e5810c971cb48d.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Safes, Safe Deposit Locker Cabinets and Key Locks (Quality Control) Order, 2023"
date: "2025-07-15"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "1b8cf7bd9fde0efa"
---

<!-- page 1 -->

रजजस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-12122023-250603
xxxGIDHxxx
CG-DL-E-12122023-250603
xxxGIDExxx
ऄसाधारण
EXTRAORDINARY
भाग II—खण्ड 3—ईप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 5064]
No. 5064]

नइ ददल्ली, मंगलवार, ददसम्बर 12, 2023/ऄग्रहायण 21, 1945
NEW DELHI, TUESDAY, DECEMBER 12, 2023/AGRAHAYANA 21, 1945

वाजणज्य और ईद्योग मंत्रालय
(ईद्योग संवधधन और अंतररक व्यापार जवभाग)
अदेि
नइ ददल्ली, 8 ददसम्बर, 2023
का.अ. 5293(ऄ) - भारतीय मानक ब्यूरो ऄजधजनयम, 2016 (2016 का 11) की धारा 16 द्वारा प्रदत्त िजियों
का प्रयोग करते हुए, कें द्र सरकार का, भारतीय मानक ब्यूरो के साथ परामिध करने के बाद यह मत है दक यह जनजहत मे
अवश्यक ऄथवा जहतकर है, ऄत: एत्द्द्वारा अदेि करती है, नामत:1. संजिप्त िीर्धक और प्रारं भ - (1) आस अदेि को सेफ, सेफ जडपोजजट लॉकर कै जबनेट और चाभी ताला (गुणवत्ता जनयंत्रण)
अदेि, 2023 कहा जाएगा।
(2) यह अदेि िासकीय राजपत्र में आस ऄजधसूचना के प्रकािन की तारीख से छह माह के बाद लागू होगा।
2. मानक का ऄनुपालन और मानक जचह्न का ऄजनवायध प्रयोग – ताजलका के कॉलम (1) में जवजनर्ददष्ट वस्ट्तुएं या सामान
ताजलका के कॉलम (2) में ईजल्लजखत तदनुरूपी भारतीय मानक के ऄनुरूप होंगे तथा ईनमें भारतीय मानक ब्यूरो
(ऄनुपालन मूल्यांकन) जवजनयम, 2018 की ऄनुसूची-II की स्ट्कीम-I के ऄनुसार भारतीय मानक ब्यूरो के लाआसेंस के तहत
मानक जचह्न लगा होगा।
बिते दक आस अदेि में से कु छ भी जनयाधत की जाने वाली स्वदेि में जवजनर्ममत वस्ट्तुओं या सामान पर लागू नहीं होगा।

7686 GI/2023

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

आसके ऄजतररि बिते दक सूक्ष्म ईद्यमों के जलए, जैसा दक सूक्ष्म, लघु और मध्यम ईद्यम जवकास ऄजधजनयम, 2006 (2006
का 27) की धारा 2 के क्रमिः खंड (ज) और (ड) में पररभाजर्त दकया गया है, यह अदेि आस ऄजधसूचना के प्रकािन की
तारीख से बारह माह की ऄवजध की समाजप्त तक लागू नहीं होगा।
आसके ऄजतररि बिते दक लघु ईद्यमों के जलए, जैसा दक सूक्ष्म, लघु और मध्यम ईद्यम जवकास ऄजधजनयम, 2006 (2006
का 27) की धारा 2 के क्रमिः खंड (ज) और (ड) में पररभाजर्त दकया गया है, यह अदेि आस ऄजधसूचना के प्रकािन की
तारीख से नौ माह की ऄवजध की समाजप्त तक लागू नहीं होगा।
3.
प्रमाणन और प्रवतधन प्राजधकरण – भारतीय मानक ब्यूरो, ताजलका के कॉलम (1) में जवजनर्ददष्ट वस्ट्तुओं या सामान
के जलए प्रमाणन और प्रवतधन प्राजधकरण होगा।
4.
ईल्लंघन के जलए पेनल्टी– आस अदेि के प्रावधानों का ईल्लंघन करने वाले व्यजि को भारतीय मानक ब्यूरो
ऄजधजनयम, 2016 के प्रावधानों के तहत दंजडत दकया जाएगा।
ताजलका
वस्ट्तु या सामान

भारतीय मानक

भारतीय मानक का िीर्धक

(1)

(2)

(3)

सेफ, सेफ जडपोजजट लॉकर
कै जबनेट और चाभी ताला

550 (भाग 1): 2014

सेफ

5244: 2020

सेफ जडपोजजट लॉकर कै जबनेट

17566: 2021

सुरिा ईपकरण हेतु चाभी ताला

नोट – आस ताजलका के प्रयोजन के जलए, भारतीय मानकों के संबंध में जारी संिोधनों सजहत ईनके नवीनतम संस्ट्करण,
जैसा दक भारतीय मानक ब्यूरो द्वारा समय-समय पर ऄजधसूजचत दकए गए हैं, लागू होंगे।
[फा.सं.पी-29026/23/2023– एलइअइ]
संजीव, संयुि सजचव

MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
ORDER
New Delhi, the 8th December,2023
S.O. 5293(E).—In exercise of the powers conferred by section 16 of the Bureau of Indian Standards Act,
2016 (11 of 2016), the Central Government, after consulting the Bureau of Indian Standards, is of the opinion that it is
necessary or expedient so to do in the public interest, hereby makes the following Order, namely:1. Short title and commencement.- (1) This Order may be called the Safes, Safe Deposit Locker Cabinets and key
locks (Quality Control) Order, 2023.
(2) It shall come into force on the expiry of six months from the date of publication of this notification in the
Official Gazette.
2.
Conformity to Standard and Compulsory use of Standard Mark.- Goods or articles specified in column (1)
of the Table below shall conform to the corresponding Indian Standard mentioned in column (2) of the said Table and
shall bear the Standard Mark under a license from the Bureau of Indian Standards as per Scheme-1 of Schedule-II to
the Bureau of Indian Standards (Conformity Assessment) Regulations, 2018:
Provided that nothing in this Order shall apply to goods or articles manufactured domestically for export:
Provided further that nothing in this Order shall apply to micro enterprises, as defined under clauses (h)
and (m), respectively of section 2 of the Micro, Small and Medium Enterprises Development Act, 2006 (27 of
2006), till the expiry of twelve months from the date of publication of this notification:

<!-- page 3 -->

[भाग II—खण्ड 3(ii)]

भारत का राजपत्र : ऄसाधारण

3

Provided further that nothing in this Order shall apply to small enterprises, as defined under clauses (h)
and (m), respectively of section 2 of the Micro, Small and Medium Enterprises Development Act, 2006 (27 of
2006), till the expiry of nine months from the date of publication of this notification:
3.
Certification and enforcement authority.- The Bureau of Indian Standards shall be the certifying and
enforcing authority for the goods or articles specified in the column (1) of the said Table.
4.
Penalty for Contravention.- Any person who contravenes the provisions of this Order shall be punishable
under the provisions of the Bureau of Indian Standards Act, 2016.
TABLE
Goods or articles

Indian Standard

Title of Indian Standard

(1)

(2)

(3)

Safes, safe deposit locker cabinets and
key locks

550 (Part 1): 2014

Safes

5244: 2020

Safe deposit locker cabinets

17566: 2021

Key locks for security equipment

Note.- For the purposes of this Table, the latest version of Indian Standards including the amendments thereof, as
notified by the Bureau of Indian Standards from time to time shall apply.
[F. No. P-29026/23/2023-LEI]
SANJIV, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed by AMIT
AMIT KUMAR KUMAR JAISWAL
Date: 2023.12.12
JAISWAL
22:20:23 +05'30'
