---
doc_id: "abf25f48bb3d5eb3"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/03/ccb1d0a26e7b1c9d436f1c1539b8d439.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 13.03.2026 : Regarding panel for Punjab & Haryana High Court , CAT & AFT Chandigarh & Dist. Patiala"
date: "2026-03-13"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d3cdd6a707b6fb49"
---

<!-- page 1 -->

No. J-11015/1/2026-Judicial/ E. 180422
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
2K OK
Shastri Bhawan, New Delhi,
Dated 13" March, 2026
ORDER
In continuation of this Department's earlier Orders with No. J-11017/23/2023-Judicial(4)
dated 07.10.2023 in respect of upgradation of panel of Shri Ashotosh Dhankar, Central
Government counsel for Punjab & Haryana High Court at Chandigarh, the President is pleased
to engage following Advocates for conducting Central Government litigation (except cases of
Taxation) before the Punjab & Haryana High Court at Chandigarh, the Central Administrative
Tribunal, Chandigarh Bench & Armed Force Tribunal, Chandigarh and District and Subordinate
Courts of Patiala District as mentioned in the LIST ‘A’, ‘B’ &‘C’ below, for a period of three years
from the date of this order or until further orders, whichever is earlier, consequently names of
upgraded Counsel, occurring in the aforesaid order dated 07.10.2023, stands deleted:
LIST ‘A’
High Court of Punjab and Haryana High Court
51. | Name Address Enroll No.
1. Rahul Khanna H. No. 17 Phase 3 Tricone City Village Hardaspur P/4576/2018
Patiala, 147001
M.: 9878790921
E.: Advrahul921@gmail.com
2. Ashutosh Dhankar Vide order No. J-11017/23/2023-Judicial P/5856/2018
(Upgradation) dated. 7th Oct. 2023 at Sr. No. 10 in List of Central
Government counsel
LIST ‘B’
Central Administrative Tribunal, Chandigarh Bench
and
Armed Force Tribunal, Chandigarh Bench
Sl. | Name Address Enroll No.
Senior Panel Counsel
a. Ms. Krishna Anmol 315, Ground Floor, Sector 35 A, Chandigarh D/3744/2010
Singh M: 9818282596
E.: adv.krishh@ gmail.com
es
YY
Page 1of2

<!-- page 2 -->

LIST‘C’
District & Subordinate Courts, Patiala
Sl. Name Address Enroll No.
Additional Standing Government Counsel
Ls Rahul Khanna H. No. 17, Phase 3, Tricone City Village Hardaspur P/4576/2018
Patiala, 147001
M.: 9878790921
E.: Advrahul921@gmail.com
2. The engagement and professional fee of the aforesaid advocates will be governed
by the terms and conditions contained in this Department’s O.M. No. 26(1)/1999-Judl.
dated 24.09.1999 (Table A and B) and O.M. No. 27(11)/99-Judl. dated 24.09.1999
(Table C) read with OM No. J-12011/6/2025-Judicial/E. 158060 dated 05.02.2026 &
instructions issued through various OMs, especially the OM No. J-16/11/2017-Judl.
dated 08.02.2018 imposing certain restriction on Panel Counsel. The aforesaid OMs are
available on the official website of this Department i.e. www.legalaffairs.gov.in in the
tab ‘Judicial Section’ under heading ‘Circulars pertaining to litigations’.
3. Hindi version of this order will follow. aie
Ys wi 5b
al
०४
(Dr. Krishan Mohan Arya)
Additional Legal Advisor
Copy (through mail) to:-

1. PS to MoS (IC) L8&J

2. PSO to Law Secretary/AS/JS in this Department.

3. PS to Attorney General of India/PS to Solicitor General of India.

4. Shri Satya Pal Jain, Addl. SGI, Punjab & Haryana High Court, Chandigarh.

5. Shri Jagjot Singh Lalli, Dy. SGI, Punjab and Haryana High Court, Chandigarh.

6. The Registrar, Punjab & Haryana High Court, Chandigarh.

7. The Registrar, CAT & AFT, Chandigarh Bench.

8. LIMBS team for ID generation.

9. To be uploaded on the website of this Department i.e., ‘www.legalaffairs.gov.in’ in the
tab ‘Judicial Section’ under the link ‘Orders related to empanelment of Advocates for Uol’
for the information of all order.

10. Hindi unit, Department of Legal Affairs for Hindi translation of the order.

11. Spare copies.

Reese
\>
(Ramesh Kairamkonda)
Section Officer (Judicial)
Phone: 011-23384945
Email: Judicial-dla@nic.in
Page 2 of 2
