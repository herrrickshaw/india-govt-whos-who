---
doc_id: "ab160a1fbbed1a9e"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/c4555f907c4fdfa4fb77dc8d49689b53.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of short code '14426' to Indian Council of Agricultural Research Department of Agriculture Research and Education"
date: "2021-07-30"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eb0f9acab9baacfc"
---

<!-- page 1 -->

Ii

,. ~

i'il....,,,.. I V - l f & . . V I • - ,.-..._,.

S&l ' V - l i • l \ - • t -

1 'i>•..,. _

.._ _ ......,/

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No.16.:.1/2017/AS-IlINol.I(Short Codes)/81/ i

cs

Dated: 60 /07/2021 ·

To,
All Acce~s Service Providers.
'

.

'

'

'

Subject: Allotment of short code ' 14426' to Indian· Council· of Agdcultutal Research,
Department of. Agriculture Researcl). and Education, 1\tlinistry o( Agriculture , and
Farmers Welfare for KiSan-Sarathi.
'
'
'

'

Sho1t co.de '14426' is allocated ~s IVRS based ICT mult'imedia advisory platfon'n for
agriculture named as Kisan-Sarathi to Indian Council of Agricultural Research, Department of
Agriculture Research and Education, Ministry of Agriculture and Faimers Welfare. The' sh01i
'code shall have.fbllowiltg features:
,.
·
.'
··
·' ·
·:
(i) Category'~'r: Se1vice (i.e. ~nandatb1y se1vice to b~ provid.ed by all the Access
Providers).
(ii) · Access'ibility: Un - Restricted. '
(iii) Metered Se1vice: Called Paity Pays .
(iv} The sh61t code shall be mapped on toll free number 1800-123-2175.
'

2.

,

I

I

All ~I.Fe requested to take necessaiy action.

.

.

'

Copy forwarded for information and necessary action., if any, to:
Secretaiy, TR.Al
CMD MTNL/ C1v.1D BSNL.
~Shri A.K. Singh,,Deputy Dii·ector General (Agricultural Extension), Indian Council of
Agricultural Research, Krishi Anusandhan Bha\van, Pusa, New Dellri-1ioo12 w.r.t. letter No.
Nil dated 23.07.2021 \Vith a requ est to appoint a nodal officer to implement the helplil1e. The
contact details are 011-25843277 and email id is ddg-extn.icar@gov.in. The Nodal officer
may contact Sr. DDG (LSA), LSA Unit, concerned States/UTs .
4. '
Dii·ector (P&N), 'DoT (HQ), (respective LSA field unit may be ·as'ked to. co-ordinate
\vith respective N od al '. Officers· and TSPs for implementation of Helplil1e, as and when
approached).
1.
A copy for upl oa~l on DoT \Vebsite.
1.

2.
