---
doc_id: "ac52835ee7c7adea"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/9dd00416655a252fba90396d18917c1d.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Extension of panel counsels of High Court of Manipur and its district and Subordinate Courts order dated 07.02.2024"
date: "2024-02-07"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "8f633c3e7044992c"
---

<!-- page 1 -->

F. No. J-11017/3/2024-Judicial (1)
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
hie
Shastri Bhawan, New Delhi,
Dated the 7" February, 2024
ORDER
The President is pleased to extend the terms of the panel counsel whose
names are occurring in this Department's Order No. J-11017/12/2018-Judicial dated
27.10.2020 for conducting Central Government litigations before the High Court of
Manipur and before various District & Subordinate Courts in the state of Manipur, ‘until
further orders’.
2 The engagement and professional fee of the aforesaid counsel will be governed
by the terms and conditions contained in this Department's O.M. No. 26(1)/99-Judl.
and No. 27(11)/99-Judl. both dated 24.09.1999 to be read separately with OM No.
26(1)/2014/Judl. dated 01.10.2015 & instructions issued subsequently through OMs
specially the OM No. J-16/11/2017-Judicial dated 08.02.2018 imposing certain
restrictions on panel counsel. The aforesaid OMs are available on the official website
of this Department i.e. www.legalaffairs.gov.in in the tab ‘Judicial Section’ under
heading ‘Circulars pertaining to litigations’.
3S Hindi version of this order will follow.
wo “
oy a
ot ‘a Anand)
Joint Secretary & Legal Adviser
Copy (through email) to:-
1. PS to Hon'ble MoS (I/C)L&J.
2. PSO to Law Secretary / Additional Secretaries in the main secretariat of Department of Legal
Affairs.
3. Shri Knomdram Samarjit Singh, Deputy Solicitors General of India, High Court Of Manipur.
4. The Registrar, High Court of Manipur
5. The Cash (LA) Section to continue the payment of retainership fee as admissible to the Standing
Government Counsel whose names are mentioned in the aforesaid order dated 27.10.2020 ‘until
further orders’.
6. The Pay & Accounts Office, Department of Legal Affairs, New Delhi
7. Toupload on the website of this Department i.e. www.legalatt legalaffairs.gov.in in the tab ‘Judicial Section’
under the link ‘Orders related to empanelment of Advocates for Union of India’.
8. Hindi unit, Department of Legal Affairs for Hindi translation of the order
9. Office/Spare copies.
|
हे (ea
or
(Kumar Gaurva)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
