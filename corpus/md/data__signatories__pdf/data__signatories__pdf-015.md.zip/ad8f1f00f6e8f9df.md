---
doc_id: "ad8f1f00f6e8f9df"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/09/454b59c90b2af8f62afcfcd0e451df13.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "O.M. No. Z-15015/6/2024-SAS-II/RD dated 09.07.2024 regarding inclusion of one (01) Rare Disease under Para 6.2 of National Polic"
date: "2024-07-09"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "319771a09ce208c5"
---

<!-- page 1 -->

f*tr#x'

z-'1 501 5i6i2024-SAS-t ti RD

Governmeni of lndia
Ministrv of Health & Familv Wel{are
Departm-ent
of Health & Faniilv Welfare
'
(Rare Disease Cell)'
Room No.501-D Wino
Nirman Bhawan. New Delhi
Dated: 09.A7.20,

a

OFFICE MEMORANDUM
Subiect: lnclusion of 01 Rare Diseases with cateoorization under Para 6.2 of
Nati'onal Policy for Rare Diseases {NPRD), 2021= reg.

fhe undersigped is^drrected-to_ refer to qqbjgct mqntioned abgve and to say
thQ!_in pursuant to?ara 6.2 and 6.3 of the Na{ional Policy for Raie Diieases
SlPRD.r, 2a.u._a1 fone) rare diseas-es.' ievLeweo ov-ttr6 deniar fdhnad
U-om[tltlQe lor Rare Diseases (CTCRDt. Directorate General of health Servrces
lDte.GHS) based on updated scientific data, hai beeh inCtuOed unoel-ine tottowjno
grolPF ol disorders identified and categorized by experts based on their cirnicall
expenence:
Group 1: Disorders amenable to one-time curative treatmenl:

a)
2.

Primary Hyperoxaluria (onty tor transplants).

.The financial. qssrstance to lhe patients suffering from the above 'edai"ano
mentioned
rare d.iseases shall be provided atrier tire provEro{s'oi ine-NTpnii
i.-ait bdnlrbl 5i-i=icEireiile' {io"Ebfi,?b inli

flri.13J[?:,-ii.1Sii.'fiii6A 5.fijo

3'
4.

This comes into effect from the date of issue ol this Office fulemorandum.
This issues with the approval of the Secretary

{H&FW).
Srgned by

$warnendu Singha

under secretary ro the'&y'ffi#t0,Bn$*.afi:a3
E m a ir:

To,

3 \ c a 6 -iqlilSrt""rTetarv' Departmenr

r*urn. l-,8, 3l,l;fr 3ffiJ,f; I

of Biotechnorogy, Ministry of science

and

\31o 3+ *8?fJ-t{^ltlt
i*r. 3r **,.+ii8 B33l3l3lil: Yj3:l{t31,,PsitrJa|,?fr:?!?,Fn?biigssibg',f,g,?,,n*,n
rndia;

r3g--r

counci,

f -y$€43.",":?SlsnnNew perhi: . _

,3 |.y.

- g,lfi?ryf.qi:djHEBS[ilBxlSi Fi.1i{Xfi3fiTfif,,j,,',1,,:l{ti1ey,?r,

;;j;l':ltffiffi'33
r3 rd\t "p"o'l}-* seci6iaiy]'ij'*purt*"nt of Hevenue,

Ministry of Finance.

10. Addfr

srareGove,n*E,it'jUilEnf

LTii,Jif??3,ri_#f,

I

$c-

flSy,?g,,5,;n

Governmenr of

i[;j,,

5t

<!-- page 2 -->

il?iiS'il,?'j,,li$if, [B?;$f#;5"ir"f

Et3]!'$3lfS'%iiJf'leiached)r

U nder secretarv

ffir

to tn" €['ilffiIfigHt?i?"kl

<!-- page 3 -->

Annexure
Details of 12 (Trvelve) Centres of Excellence
S. No.
1

\ame of Centre of Excellence
A.ll India Institute of Medical
Sciences. Ner,v Delhi

Name of Nodal Officer/ Email id/contact No.
Dr. Neerja Gupta. Associate Professor
Division of Genetics, Department of Pediatrics.

AIIMS. New Delhi,
Contact No. 9868397529
Maulana Azad Medical
College, Nerv Delhi

Sanjay Gandhi Post Graduate
lnstitute of Medical Sciences,

Dr. Seema Kapoor.
Division of Genetics, Department of Pediatrics,

MAMC, New Delhi
drseemakapoor(Esmail.com Contact No. 9868846606
Dr. Shubha Phadke, M D Professor & Head,

Department of Medical Genetics, Sanjay Gandhi Postgraduate Institute of

Lucknow

Medical Sciences, Lucknow, lndia-2260 1 4
pho ne : 9 839220 I g g . 9 | 5 22-249 4325 E-mail : shubharaophadke@ gmai l. c om

lost Graduate Institute of

)r. Ranjit Pal Singh Bhogal' Assistant Professor'

\,ledical Edr.rcation and

Deputy Medical Superintendent, Department of Hospital Administration,

Research, Chandigarh

lontact No. 7087002089 Email: majorbhogall984@gmail'com

Centre for DNA FingerPrinting

Dr. Ashwin Dalal, Head,

& Diagnostics with Nizam's
lnstitute of Medical Sciences,
Hyderabad

Diagnostics Division
Email: ashwindalal@gmail'com
Contact N o. 0 40 -27 2 | 6 | 47

King Edward Medical

Dr. Mamta Muranjan,

Hospital, Mumbai

Professor & In-charge of Genetic Clinic, KEM Hospital, Mumbai,
muranj anmamta@redi ffrnai l. com
Contact No. 022-24 1 07 0 I 417 50617 559

lnstitute of Post-Graduate
Vledical Education and

Prof Suchanda Mukherjee. HOD. Neonatology

Research, Kolkata

Email: drsmukherjeeT0@gmail.com

Center for Human

Dr. Sanjeeva GN, Associate Professor'

Genetics(CHG) with Indira

lndira Gandhi Institute of Child Health, Bengaluru
Mob: 9945657034 Email : sanju.gn26@gmail.com

Gandhi Hospital, Bengaluru

lontact No. 983 I 485596

lnstitute of Child Health and
Hospital for Children (ICH &
CH). Chennai

)r. Anuradha.

10

All India Institute of Medical
Sciences (AIIMS), Jodhpur

ll

lree Avittam Thirunal Hospital
'SAI). Government Medical

Dr. Kuldeep Singh, Professor & Head,
Department of Pediatrics, AIIMS, Jodhpur.
Contact: 0291-2833 l49l 8003996940 Email: kulpra@gmail.com
Dr. Sankar V.H., Professor of Pediatrics & Geneticist, SAI, Government

)

t2

\4.D,DCH. Phd.

Ylob 9 4443 40 1 66 Email : anuradha. iit@ gmail.com

MedicalCollege.

3o llege, Thiruvananthapuram

Email : sankarvh@gmail.com

A,ll tndia Institute of Medical

Dr. Bhavna Dhingra

Sciences, Bhopal

Professor.

Division of Genetics
Department of Pediatrics, AIIMS, Bhopal
Email : bhavna.pediatrics@aiimsbhopal.edu.in
