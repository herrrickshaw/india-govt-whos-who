---
doc_id: "acddd95da1b096e2"
source_url: "https://www.moes.gov.in/static/uploads/2025/07/1eab0dc16847f469978026735c62e852.pdf"
ministry: "Earth Sciences (MoES)"
title: "Guidelines for Outreach and Awareness Programme of Moes"
date: "2025-07-15"
pages: 8
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "75ca06eaa9215c3d"
---

<!-- page 1 -->

भारत सरकार
GOVERNMENT OF INDIA
पृथ्वी ववज्ञान मंत्रालय
MINISTRY OF EARTH SCIENCES
'पृथ्व
् ी्भवन', लोदी्रोड,
“Prithvi Bhwan”, Lodi Road
नई ददल्ली-110003
New Delhi 110003

PLEASE READ THE FOLLOWING TERMS AND
CONDITIONS CAREFULLY BEFORE APPLYING FOR
FINANCIAL SUPPORT,
ववत्तीय्सहायता्हेतु्आवेदन्देने्से्पूवव्कृ पया्वनम््नवलवखत्वनयम ्ववं्रततों ्को्च्‍् ी्तरह्से्प ल्ल। ्

संगोष्ठी, ववचार-गोष्ठी, कायवराला, सम्मेलन आदद के वलव मंत्रालय की वेबसाइट http//www.moes.gov.in
के माध्यम से चथवा मंत्रालय को सीधे हाडव्कॉपी्भेजकर आवेदन प्रस्तुत करने के वलव टटप्पणी
NOTES FOR SUBMISSION OF APPLICATION FOR SEMINARS, SYMPOSIA,
WORKSHOP, CONFERENCE ETC THROUGH EITHER INTERNET www//Moes. gov.in
OR BY POSTING THE HARD COPY TO THE MINISTRY DIRECTLY.
1. इसका उद्देश््य ववरेषज्ञ , वैज्ञावनक , पयाववरणववद , जनसाधारण और प्रयोक्ता समुदाय के बीच
पारस्पटरक संवाद के वलव वक मंच तैयार करना है, वजससे समुद्र और वायुमंडलीय ववज्ञान तथा प्रौद्योवगकी
की जानकारी का आदान-प्रदान हो सके तथा दकसान के वलव कृ वष-मौसम-ववज्ञान संबंधी सेवाओं और
जनता, सामावजक कायवक्रम आदद के वलव मौसम पैरामीटर आदद जैसी जानकारी प्रसाटरत की जा सके
The objective is to support the platforms for interaction between Experts, Scientists,
Environmentalists, General public and user communities to exchange the knowledge of
Ocean & Atmospheric Science and Technology, and to disseminate the information such as
Agro-Met services to farmers, weather parameters to people, societal Programmes etc.
2. प्रमुख क्षेत्र हैं: ध्रव
ु ीय ववज्ञान, समुद्री प्रेक्षण और सूचना सेवावं, समुद्र् प्रौद्योवगकी, तटीय् क्षेत्र् प्रबंधन,्
समुद्री् वनजीव् संसाधन, समुद्र से औषवध, जलवायु पटरवतवन, हहद महासागर म। चक्रवात, भूकंप, मौसम
पूवावनुमान और लोग के वलव सूचना, दकसान के वलव कृ वष संबंधी परामरी सूचना, गैस हाइड्रेट ववज्ञान ववं
प्रौद्योवगकी, समुद्री मोती कृ वष, गहरे समुद्र के समुद्री सजीव संसाधन, वनतलस्थ जीव और पाटरवस्थवतकी;
पनडु ब्बीनुमा यंत्र का ववकास, समुद्र से स्व्‍ जल, समुद्री ऊजाव तथा प्रौद्योवगदकयां, समुद्री स्व्‍ ता की
मॉनीटररग, समुद्री पयाववरण मॉडहलग, समुद्र वस्थवत पूवावनुमान, मंत्रालय के वतवमान सामावजक कायवक्रम,
सुनामी पूवव चेतावनी प्रणाली, काबवन् वन् और् पी चक्र, पुरा् जलवायु् चध््ययन,् समुद्र् स््तर् म।् पटरवतवन,्
काबवन् पृथककरण, जल चक्र-समुद्र से हवा और हवा से दिर भूवम पर आने-के दौरान होने वाली परस्पर
दक्रया, कृ वत्रम्बादल बनना तथा्चन््य
The Thrust Areas are Polar Sciences, Ocean Observation and Information Services, Ocean
Technology, Coastal Zone Management, Marine Non-Living Resources, Drug from Sea,
Climate Change, Cyclones in Indian Ocean, Earthquakes, Weather Forecasting and
Information to people, Agro Advisories to farmers, Gas Hydrates Science and Technology,
Marine Pearl Culture, Deep Sea Marine Living Resources, Benthos and Ecology;
Submersibles Development, Fresh water from Sea, Ocean Energy & Technologies, Sea

<!-- page 2 -->

Health Monitoring, Marine Environment modeling, Ocean State- Forecasting, On-going
Ministry‟s Societal programmes, Tsunami Early Warning System, Carbon , N and P Cycle,
Paleoclimatic studies. Sea level changes „ Carbon sequestration, Water Cycle-sea to air to
land interaction, cloud seeding and others.
3. सहायता्हेत्ु संस्थ
् ान्के ्संयोजक्तथा्प्रमुख्वारारा्वववधवत्प प्से् भरे् ए व्तथा्हस््ताक्षटरत्आवेदन्
पत्र् (हाडव् कॉपी)् को् उवचत् माध््यम् से् प्रभाग् प्रमुख,् आउटरीच कायवक्रम,् भारत् सरकार,् पृथ््वी् ववज्ञान्
मंत्रालय,्„पृथ््वी्भवन‟्लोदी्रोड़,्नई्ददल््ली-110003्को्वनम््नवलवखत्संबंवधत्दस््तावेों  ्के ्साथ्भेजा्
जा्सकता्है:-््
The application (Hard Copy) for seeking support dully filled and signed by the convener and
Head of the Institution, needs to be submitted through proper channel to Head of the
Division, Outreach Programme, Government of India, Ministry of Earth Sciences, “PRITHVI
BHWAN”, Lodi Road, New Delhi 110003 with the following relevant enclosures:
(क) पंजीकृ त सोसायटी, प्राइवेट कॉलेज /स््कूल , सरकारी सहायता प्राप्त कॉलेज , गैर-सरकारी संगठन ,
मान्यता प्राप्त ववश्वववद्यालय आदद के मामले म। वनम्नवलवखत प्रवतयां संलग्न की जावं : (i) पंजीकरण
प्रमाणपत्र, (ii) संगम चनु्‍ ेद/ज्ञापन (iii) उप-वववधयां (iv) सोसायटी आदद के वप ले 3 वषतों  के लेख के
लेखा-परीवक्षत वववरण (v) आय ववं व्यय आदद के स्रोत ववं पद्धवत (vi) वतवमान पदधाटरय की सूची्ववं्
बैलस
। ् रीट्खाता् (वप ले् तीन् वषतों ् की) (vii) सोसायटी के संगम ज्ञापन, वनयम ववं वववनयम की प्रवत
(viii)्वप ले् तीन्वषतों ् की्आयकर्वववरणी्(आईटीआरवस)्(पृथ्व
् ी्प्रणाली्ववज्ञान्से् संबवं धत्क्षेत्र ्म।्
आउटरीच्गवतवववधय ्म।् लगे् ए व्गैर-व््यावसावयक्वनकाय ्के ्वलव्लागू)्(ix) नीवत्आयोग्वारारा्जारी्
दकया्गया्Unique्आईडी्कोड्
(x)्पैन्काडव्की्कॉपी्(xi)्ईसीवस/आरटीजीवस्सूचना्बैंक्वारारा्सत्यावपत्होनी्चावहव
For Registered Society, Private Colleges / schools, Government aided Colleges, NonGovernment Organizations, Deemed University etc are required to enclose copies of: (i)
Registration Certificate, (ii) Articles/Memo of Association, (iii) By-Laws, (iv) Audited
Statement of Accounts and balance sheet of the Society etc for the last 3 years, (v)
Sources & Pattern of Income & Expenditure etc for the last 3 years (vi) list of present
office bearers, (vii) Memorandum of Association, copy of rules and regulation of the
society (viii) Income-Tex Returns (ITRs) for the last three years (applicable for nonprofessional bodies engaged in the outreach activities in related areas of Earth System
science), Niti Aayog unique ID code, PAN card copy, ECS/RTGS details duly endorsed
by bank (copy enclosed)
(ख) मान्यता् प्राप्त चनुसंधान संगठन ् वारारा आयोवजत दकव जाने वाले चंतरावष्ट्रीय सम्मेलन के मामले म।
वनम्नवलवखत प्रवतयां संलग्न की जावं : (i) प्ररासवनक मंत्रालय का चनुमोदन (ii) ववदेर मंत्रालय की क््लीयर। स
(iii) गृह मंत्रालय की क््लीयर। स
For International Conference being organized by recognized Research Organizations copies
to be enclosed are (i) Approval of Administrative Ministry, (ii) Clearance of Ministry of
External Affairs, (iii) Clearance of Ministry of Home Affairs
It may please be noted that established NGOs with good track record and which are involved
exclusively in scientific activities related to Earth System Science domain only shall be
considered for financial support by MoES.

<!-- page 3 -->

यह्नोट्दकया्जाव्दक्वप ली्उपलवब््धय ्वाले् तथा्चनन््य्प प्से् पृथ््वी्प्रणाली्ववज्ञान्के ्क्षेत्र्से् जुड़्े ए व्वैज्ञावनक्
कायवकलाप ्म।् रावमल्प्रवतव‍्ठत्गैर्सरकारी्संगठन ्को्ही्वमओईवस्वारारा्ववत्तीय्सहायता्देने् पर्ववचार्दकया्
जावगा ्

Upon completing the procedural formalities the final decision shall be communicated to you
In case no decision is conveyed before the commencement of event it may be assumed
that financial support is not sanctioned. No assumption on part of the applicant shall be
valid to consider the case for re-imbursement of expenditure after the event is over. In all
such cases organizers have to bear the expenses and no case for reimbursement shall be
entertained.
Canvassing in any form shall be a disqualification.
प्रदक्रया्संबंधी्औपचाटरकतावं्पूरी्होने्पर्आपको्चंवतम्वनणवय्के ्बारे ्म।्सूवचत्दकया्जावगा ्इव।ट्के ्
प्रारं भ् होने् से् पहले् वनणवय् की् सूचना् नहीं् ददव् जाने् की् दरा् म।् यह् माना् जाव् दक् ववत््तीय् सहायता्
स््वीकृ त्नहीं्की्गई्है ्इव।ट्के ्समापन्के ्उपरांत्व््यय्की्प्रवतपूर्तत्हेत्ु मामले् पर्ववचाराथव् आवेदक्के ्
दकसी्भी्दावे्को्वैध्नहीं्माना्जावगा ्ऐसे्सभी्मामल ्म।् आयोजक ्को्व््य य्वहन्करना्होगा्तथा्
प्रवतपूर्तत्हेतु् दकसी्भी्मामले् पर्स््वीकार्नहीं्दकया्जावगा ्चपने् पक्ष्म।् माहौल्बनाने् के ्दकसी्भी्
प्रयास्को्चयोग््यता्माना्जावगा ्
No correspondence / communication in this regard shall be entertained in between by MoES.
इस्बीच्वमओईवस्से्इस्संबंध्म।्कोई्भी्पत्राचार/संचार्नहीं्दकया्जाव
Application forms which are incomplete in any form or are not provided with the copies of
required documents / certificates / details (such as ; UCs, by-laws and other as mentioned at
para 3a) shall be summarily rejected by MoES and no correspondence shall be made
in this regard with the applicant. It is therefore reiterated that all applicant must read
guidelines carefully and comply with all terms and conditions before submitting the
application to MoES for financial support.
दकसी्भी्प प्म।् चपूणव् चथवा्आवश््यक्दस््तावेों  /प्रमाण्पत्र /वववरण ्की्प्रवतय ्(जैसा्दक्पैरा्3व्म।्
उवल््लवखत्यूसी,्उप-वववधयां्तथा्चन््य)्उपलब््ध्नहीं्करवाने्पर्वमओईवस्वारारा्आवेदन्तुरंत्रद्द्कर्
ददया्जावगा्और्इस्संबंध्म।् आवेदक्के ्साथ्कोई्पत्र-व््यवहार्नहीं्दकया्जावगा ्चत:्यह्दोहराया्
जाता् है् दक् आवेदक् ववत्तीय् सहायता् हेतु् वमओईवस् को् आवेदन् प्रस््तुत् करने् से् पूवव् ददरा-वनदेर ् को्
च्‍् ी्तरह्से्प ल्ले्तथा्सभी्वनयम ्तथा्रततों ्का्चनुपालन्कर। ्््
4. सिल्आवेदक ्को मंत्रालय वारारा सूचना भेजी जावगी तथा आगे के पत्राचार के वलव के वल मंत्रालय की
संदभव संख्या दी जाव इस् संबंध् म। मंत्रालय का वनणवय चंवतम होगा तथा आगे कोई पत्राचार नहीं दकया
जावगा
The successful applicants shall be informed by Ministry and the future correspondence
should contain the Ministry‟s reference no. only. The Ministry‟s decision is final and no
further correspondence will be entertained.
5. यदद आयोजक ने पहले भी पृथ्वी ववज्ञान मंत्रालय (पूव्व के महासागर ववकास ववभाग चथवा महासागर
ववकास मंत्रालय) से संगोष्ठी, ववचार-गोष्ठी आदद के वलव कोई चनुदान प्राप्त दकया है तो सभी उपयोवगता
प्रमाणपत्र (चार मूल प्रवतयां) तथा ववत्तपोषण स्रोत से ए ई कु ल आय ववं इन संगोवष्ठय पर्दकव गव व्यय
की प्रवतयां संलग्न की जावं साथ ही यदद कोई व्यय न की गई रेष रावर हो तो, उस चववध के बैंक ब्याज
सवहत यह रावर, आहरण ववं संववतरण चवधकारी, भारत सरकार, पृथ्वी ववज्ञान मंत्रालय, नई ददल्ली - 3

<!-- page 4 -->

के पक्ष म। आहटरत वडमांड ड्राफ्ट वारारा तत्काल वापस कर दी जाव चन्यथा आवेदन पत्र को पूरी तरह
चस्वीकृ त कर ददया जावगा
If the organizers received any grant for Seminars, Symposia etc earlier, from the Ministry of
Earth Sciences [earlier Department of Ocean Development or Ministry of Ocean
Development] the copies of all Utilization Certificates (four sets in original) and statement of
total income from all the funding sources and expenditure for these seminars should be
enclosed and unspent balance, if any, plus with bank interest for that period, should be
refunded by Demand Draft drawn in favor of Drawing and Disbursing Officer, Government
of India, Ministry of Earth Sciences, New Delhi-3, immediately otherwise the Application
will be rejected.
6. यदद संस्थान/ववश्वववद्यालय/संगठन ववं कोई पंजीकृ त सोसायटी/संघ चथवा कोई चन्य वनकाय संयुक्त
प प से कोई संगोष्ठी आयोवजत कर रहे हैं, तो उपयोवगता प्रमाणपत्र तथा कु ल आय ववं व्यय वववरण प्रस्तुत
करने का दावयत्व उस्प्रावधकारी्का्होगा्वजसे्वनवधयां्जारी्की्जा्रही्है ्तथावप, वनवधयां उवचत लेखा
रखने वाले मान्यता प्राप्त संगठन को ही जारी की जावगी
Wherever an Institute/ University/ Organization and a Registered Society/ Association or any
other body are jointly organizing a seminar, the responsibility of furnishing the Utilization
Certificate and Statement of Total Income and Expenditure will lie with the authority to
whom the funds are released. Funds will however be released to the recognized organization
only for proper accounting.
7(क) मंत्रालय के ्चवधदेर,्चाटवर, कायवकलाप के चंतगवत आने वाले समारोह को ही समथवन देने पर ववचार
दकया जावगा तथा वनम्न मद के वलव चनुदान ददया जावगा (i) युवा वैज्ञावनक (भारतीय) के वलव यात्रा
भत्ता/महंगाई भत्ता (ii) वटरष्ठ वैज्ञावनक (भारतीय) के वलव यात्रा भत्ता/महंगाई भत्ता (iii) सम्मेलन से पूवव
की घोषणावं, सारांर आदद को पवाना (iv) कायववावहय का प्रकारन (v) लेखन सामग्री (vi) सवचवालय
सहायता (vii) ववववध मद।
Support will be considered only for the events which will be with in the ambit of Ministry‟s
mandate, charter & activities, and the grant will be released to items (i) TA/DA for Young
Scientists (Indian), (ii) TA/DA for Senior Scientists (Indian), (iii) Pre-conference
Announcements, printing of abstracts etc, (iv) Publication of Proceedings, (v) Stationery, (vi)
Secretarial Assistance, (vi) Miscellaneous items.
(ख) इस मामले म।, आयोजक को इस आरय का प्रमाणपत्र प्रस्तुत करना होगा दक वे वनवध प्रदान करने वाली
दकसी चन्य सरकारी वज।सी से कोई धनरावर चनुदान प्राप्त नहीं कर। गे
In this case, organizers have to submit a certificate that they will not receive any funds/grants
from any other government agencies.
(ग) चन्य देर के वैज्ञावनक को चंतरावष्ट्रीय यात्रा चनुदान प्रदान करने का कोई प्रावधान नहीं है
There is no provision to provide international travel grant to other country Scientists
(घ) चन्य समारोह के वलव के वल उपयुवक्त 7 क (iii) चथवा 7 क (iv) मद के वलव पूणव चनुदान सहायता
प्रदान की जावगी
Grant to other events will be supported fully to items 7a (iii) or 7a (iv) of above only.
(ड.) आंवरक्वनवध्के ्मामल।्म।्,्यदद्दकसी्और्ववत्त्पोषण्वज।सी्से्कोई्चन््य्ववत्तीय्सहायता/समथवन्
और्वनवध्की्मात्रा्मांगी्गई्है,्तो्उसके ्बारे ्म।्चवश््य्बतावं ््

<!-- page 5 -->

In case of part fundings, it is necessary to indicate other funding agency if any financial
assistance/support & the quantum of funding sought.
8. समारोह पूणव होने की वतवथ से दो माह के भीतर प्रस्तुत दकव जाने वाले दस्तावेज हैं: (i) संलग्नक 1 म। ददव
गव प्रारुप म। उपयोवगता प्रमाणपत्र (4 मूल प्रवतयां) (ii) कायववावहय की 2 प्रवतयां (iii) इस समारोह के वलव
कु ल आय का ब्यौरा तथा व्यय का लेखा परीवक्षत वववरण (iv) वसिाटरर। तथा चनुवती कारव वाईयां (v) इस
समारोह से होने वाली चन्य उपलवब्धयां (vi) चन्य संलग्नक, यदद कोई ह
The documents to be submitted within two months from the date of completion of the event
are (i) The Utilization certificate (4 Original Copies) as per the format given in the enclosure1, (ii) 2- COPIES OF THE PROCEEDINGS, (iii) Total Income details for this event and
audited Statement of expenditure, (iv) Recommendations and follow-up actions, (v) other
achievements from this event, (vi) Other enclosures if any.
9. राष्ट्रीय/चंतराव‍र् ीय समारोह के मामले म। आवेदन पत्र कम से कम तीन्महीने् पूव्व राष्ट्रीय्संगोष्ठी्के ्
वलव्ववं्चंतरराष्ट्रीय्सम्मेलन्के ्वलव्चार्महीने्पूवव जमा करा ददया जाव
The application should be submitted in advance at least Three months for National event and
Four months for International event.
10.् वनधावटरत् िॉमेट् म।् पूणव् रुप् से् भरी् ए ई् ईसीवस/आरटीजीवस् सूचना् बैंक् वारारा् सत्यावपत् होनी्
चावहव ्यह्वक्चवनवायव् आवर्यकता्है् और्प्रस््ताव्के ्साथ्इस्दस््तावेज्के ्न्होने् पर्उस्पर्आगे्
ववचार्नहीं्दकया्जावगा ्
ECS/RTGS information as per the format provided should be duly completed and endorsed
by the bank. This is a mandatory requirement and proposal that do not contain this document
shall not be processed.
11. चगर्आपके ्संगठन्के ्पास्उपयोवगता्प्रमाण-पत्र्(यूसी)्लंवबत्पड़ा्है,्तो्जब्तक्उसका्वनपटान्
नहीं्हो्जाता्तब्तक्मंत्रालय्मंजूरी्आदेर/चनुदान्जारी्नहीं्करे गा ्
In case there is a pending Utilisation Certificate with your organization, release of Sanction
Order/Grant shall not be taken up by the Ministry until settlement.
12. यदद् राज््य् ववज्ञान् ववं् प्रौद्योवगकी् पटरषद् वारारा् काई् पंजीकरण/प्रमाणपत्र् जारी् दकया् गया् है् तो्
योजना्आयोग्वारारा्गैर्सरकारी्संगठन्के ्तहत्जारी्पंजीकरण्संख््या्प्रस््तुत्कर। ्
Please furnish registration number issued by the Planning Commission under NGO
Registration/Certificate, if any, issued by the State Council for Science & Technology.
13.

आपके ्संस्थ
् ान ्को्पूवव्म।्जारी्दकव्गव्चनुदान ्के ्सभी्लवम््बत्उपयोवगता्प्रमाण-पत्र्नेट्पर्

उपलब््ध् है् तथा् इन््ह्। आप् http://164.100.179/ucdemo1/report/pendingUCs.aspx पर् देख्
सकते्हैं ्
To view of all the pending UCs of earlier grants released to your Institutions is available in
net
and
to
view
the
same
please
visit
the
link
http://164.100.31.179/ucdemo1/Report/PendingUCs.aspx

<!-- page 6 -->

14. कोई्भी्प्रस््ताव्प्रस््तुत्करने से् पूवव् कृ पया्सुवनवश््चत्कर्ल।् दक्वनधावटरत्िॉमव् को्सब्प्रकार्से् भर्
ददया् गया् है,् ऐसा् करने् म।् चसिल् रहने् पर् आवेदन/प्रस््ताव् को् वनरस््त् कर् ददया् जावगा् तथा् पृथ्व
् ी्
ववज्ञान्मंत्रालय्वारारा्इस्बारे ्म।्कोई्सूचना्नहीं्दी्जावगी्
Before submitting any proposal kindly ensure that the prescribed form is filled-in in all
respect failing which the application of the proposal should cancelled and no communication
should be made by MoES.
15. सभी्वनजीओ्को्नीवत्आयोग्के ्पोटवल्पर्पंजीकृ त्दकया्जाना्चावहव्तथा्दकसी्भी्मंत्रालय्से्
चनुदान्प्राप््त्करने्हेतु्चपने्आवेदन-पत्र्प्रस््तुत्करने्से्पूवव्उन््ह।्चववारतीय्पहचान्संख््या्प्राप््त्कर्लेनी्
चावहव् ्वनजीओ्को्चववारतीय्पहचान्संख््या्प्रदान्करते् समय,्सभी्न््यावसय ्और्पदधारक ्के ्पेन्
और्आधार्नंबर्प्राप््त्कर्लेने् चावहव् ्चनुदान ्और्वनमुववक््तय ्हेतु् वनजीओ्के ्प्रस््ताव ्को्मंत्रालय ्
वारारा्के वल्इस्पोटवल्के ्माध््यम्से्ही्प्रोसेस्दकया्जाना्चावहव् ्
All NGOs must be registered at NITI Aayog portal and should obtain unique identifiers
before submitting their applications for grants from any Ministry. While giving unique
identifiers to NGOs, PAN and Aadhaar numbers of all trustees and office bearers should be
provided.

************

<!-- page 7 -->

Enclosure – 1

<!-- page 8 -->
