---
doc_id: "aa3cddabc2a5df3f"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/9003e84f04080c845eec969bd585447d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of short code 14453 to Investor Education and Protection Fund Authority IEPFA"
date: "2024-05-20"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "441125cc6ef6eed8"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
(Access Services Wing)
No. 16-01/2022-AS-III/ShortCode/5 2. Dated: 20.05.2024
To,
All Access Service Providers.
Subject: Allocation of short code ‘14453’ to Investor Education and Protection Fund
Authority (IEPFA)-regarding.
The undersigned is directed to convey the allocation of short code ‘14453’ to Investor
Education and Protection Fund Authority (IEPFA), Ministry of Corporate Affairs for
promoting awareness among investors, and protecting the interests of the investors, with the
following features: -
i. Category-I: Service (i.e. mandatory service to be provided by all the Access service
providers.
ii. | Accessibility: Un-restricted (to be accessible across India).
iii. | Metered service: Called Party Pays
iv. The short code will terminate at: - 1800 911 0050
v. Details of Nodal Person are given below: -
Name- Krishnamurari Rai
Contact Number:- 011-23441752
E-mail:- krishnamurari.rai@gov.in
2. All are requested to take necessary action.
3. This is issued with the approval of DDG (AS).
alk
ey
(Trilok Chandra)
Director (AS-III)
Ph 011-23372063
Copy forwarded for information and necessary action, if any, to:
iP Secretary, TRAI.
2. CMD MTNL/ BSNL.
3. Gaurav Gupta, Deputy Director, IEPF Authority, Ministry of Corporate Affairs,
Ground Floor, Jeevan Vihar Bullding 3, Sansad Marg, New Delhi -110001, with a request to
appoint a nodal officer. The nodal officer may contact Sr. DDG(LSA), LSA unit of concerned
states/UTs, in case of any difficulty.
4. Director (T), DGT HQ, DoT (respective LSA field may be asked to coordinate with
TSPs for implementation of helpline, as and when approached).
5. A copy for upload on DoT Website.
