---
doc_id: "aad540f8a51cac2c"
source_url: "https://master-dopt.digifootprint.gov.in/static/uploads/2025/08/aa0103f95163fdbe64ee3fd17d4aa767.pdf"
ministry: "Department of Personnel and Training (DoPT)"
title: "Modification in APAR for Recording Mandatory iGOT Karmayogi Courses -Issuance of Corrigendum."
date: "2025-08-20"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0ab98111a7e2d581"
---

<!-- page 1 -->

T-28/27/2025-iGOT

I/3043145/2025

No.T-28/27/2025-iGOT
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel & Training
Training Wing
*****
Block-IV, Old JNU Campus,
New Delhi -110067
Date:19th August, 2025
Corrigendum
Subject: Modiﬁcation in APAR for Recording Mandatory iGOT
Karmayogi Courses – Issuance of Corrigendum.
In continuation of this Department’s O.M. of even number dated
04.07.2025 on the subject cited above (copy enclosed), attention is
invited to Para 3(vii) thereof, which inter alia states that the information
regarding completion of mandatory iGOT Karmayogi courses will be
captured in a new sub-table under the existing “Training Programs
Attended” section in Part-1 of the APAR.
2.
It has now been decided that the said information as well as the
status of completion of the comprehensive assessment shall, instead, be
captured in the appropriate section of Part-2 (Self appraisal) of the
APAR.
3.
All Ministries/Departments/Organizations are, therefore,
requested to take note of this modiﬁcation and ensure necessary action
accordingly.
Encl: as stated.
(Shampa Ghosh)
Under Secretary to the Government of India
Tele: 26706377

To

(i) Secretaries to all the Ministries/Departments of the
Government of India
(ii) All Cadre Controlling Authorities
Copy to:
(i) Chief Secretaries of all State Governments /UT Administrations
(ii) PSO to Secretary (P)
(iii) Secretary, Capacity Building Commission
(iv) CEO, Karmayogi Bharat
(v) Director (IT), NIC
(vi) Deputy Secretary /Director AIS Division, DoPT
(vii) Deputy Secretary /Director, PP Division, DoPT

<!-- page 2 -->

No.T-28/27/2025-iGOT
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel & Training
Training Wing
*****
Block-IV, Old JNU Campus,
New Delhi -110067
Dated: 04 July, 2025
Office Memorandum
Subject: Mandatory Course Completion and Comprehensive Assessment on the iGOT
Karmayogi portal – reg.
The undersigned is directed to say that the National Programme for Civil Services
Capacity Building (NPCSCB) – Mission Karmayogi, approved by the Union Cabinet on 2nd
September 2020, aims to build a citizen-centric and future-ready civil service through a rolebased capacity building approach. Competency-driven capacity building in government
employees is being facilitated by way of the iGOT-Karmayogi digital learning platform. The
platform offers anytime, anywhere learning on key domain, behavioral, and functional
competencies.
2.

In order to further underscore the need for continuous, role-specific capacity building, it

has now been decided that all Central Government employees and officers of the All India
Services (AIS) will be required to complete prescribed courses on iGOT annually and that this
will also be reflected in their Annual Performance Appraisal Reports (APARs). The courses for
the Central Government employees and the officers of the All India Services (AIS) on
Central

Deputation

shall

be

prescribed

by

their

respective

Ministries/

Departments/Organisations (MDOs) and for all other officers of the AIS, the same shall be
prescribed by their respective Cadre Controlling Authorities (CCAs).
3.

Accordingly, the following instructions are hereby issued to all MDOs and the CCAs of

the AIS.

i. In the case of Central Government employees and the AIS officers under Central
Deputation, all MDOs of Government of India shall identify relevant courses on the iGOT

<!-- page 3 -->

Karmayogi Platform for employees at each level as the annual target. As an illustration, a
minimum of 6 courses could be selected for each of the following levels - MTS, SO/ASO
& equivalent, US & equivalent, DS/Director, JS and above.

ii. In the case of AIS officers not on Central Deputation and the CCS officers not working
with any MDO of the Govt of India, the CCAs shall identify relevant courses on the iGOT
Karmayogi Platform for employees at each level as the annual target.As an illustration, the
respective CCAs could select a minimum of 6 courses for each of the following levels upto 9 years of service, above 9 and upto 16 years of service, above 16 and upto 25 years
of service, 25 years and above of service.

iii. These courses shall be added by the MDO Admin/CCA as “Training Plan” for each of the
positions/designations/levels on the iGOT portal.

iv. Once the “Training Plans” get added, these courses will get reflected as targets in the “My
iGOT” section of iGOT profile of the respective users. This, however, will be possible only
once the employee has updated her/his profile on iGOT so as to correctly reflect her/his
current role/position/designation in the Ministry/Department/Organization the employee is
serving in. AIS officers serving in the states/UTs must update their iGOT profiles to
correctly reflect their service and batch such that they are mapped to the correct CCA and
level (based on years of service).

v. All employees shall complete at least 50% of the courses prescribed by the MDO/CCA for
the year.

vi. The status of course completion for mandated courses will be directly fetched from iGOT
and reflected in the Annual Performance Appraisal Reports (APARs) from the reporting
period 2025-26 (corresponding to the APAR cycle of 2026-27).
vii.

The information will be captured in a new sub-table under the existing “Training Programs
Attended” section in Part-I of the APAR.

4.

It has also been decided to roll out a Comprehensive Assessment Framework from the

reporting period 2025-26 (corresponding to the APAR cycle of 2026-27). As per the framework,
competency attainment will be evaluated through standalone assessments based on courses
identified by the MDOs (or the CCAs as the case may be) for employees at each level. All
central government employees and all officers of the AIS will have to pass the assessment

<!-- page 4 -->

mandated for them during the course of the reporting year and the successful completion of the
assessment will also be reported in the APAR by fetching relevant data from iGOT.
5.

All

MDOs

aforementioned

are

requested

to

ensure

strict

adherence

and

compliance

guidelines and to take active steps for their time-bound

with

implementation

the
in

accordance with the timelines specified in Annexure A. The respective CCAs are requested to
spearhead the implementation for AIS officers who are not on Central Deputation.

6.

Detailed instructions regarding the roll out of comprehensive assessment will be issued

separately. Necessary instructions regarding the modification of the APAR

form will also be

subsequently issued by the concerned CCAs.
(Uma Magesh)

Under Secretary to the Government of India
Tele: 26706310
To
(i) Sccretaries to all the Ministries/Departments of the Government of India
(i) All Cadre Controlling Authorities
Copy to:

(i) Chief Secretaries of all State Governments /UT Administrations
(ii) PSO to Secretary (P)
(iii) Secretary, Capacity Building Commission
(iv) CEO, Karmayogi Bharat

(v) Director (IT), NIC
(vi) Deputy Secretary /Director AIS Division, DoPT
(vii) Deputy Secretary /Director, PP Division, DoPT

<!-- page 5 -->

Annexure A
The following timelines shall be adhered to for the implementation of the guidelines outlined in
this Office Memorandum:

Sl. Items
No.

Deadline

1.

Orientation workshop for the heads of Capacity Building Units (AS/JS by 31.07.2025
level) of all Ministries/Departments and the Cadre Controlling AS/JS
of the AIS, along with hands on session for Dir/DS/US level officers
responsible for the implementation to guide them on the process of
uploading Annual Targets for employees at each level.

2.

Identification of relevant courses on iGOT Karmayogi portal for by 31.08.2025
employees at each level as the annual target by MDOs and CCAs and
their
addition
as
“Training
Plan”
for
each
role/position/designation/level on iGOT.

3.

Integration of SPARROW and iGOT enabling the status of course by 31.08.2025
completion for mandated courses to be directly fetched from iGOT and
reflected in the APARs.

4.

Creation of Question Banks for the Comprehensive Assessment by all by 15.10.2025
MDOs and CCAs.

5.

Comprehensive assessments for employees at each level to be made by 15.11.2025
live on iGOT.

6.

Employees to complete at least 50% of the courses prescribed by the by 31.03.2026
MDO/CCA for the year, and complete the prescribed Comprehensive
Assessment.
