---
doc_id: "abd6cbdffad57e03"
source_url: "https://www.dahd.gov.in/static/uploads/2026/10/8ed9cbb08b669ab7c31aa8421f97e1e8.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Notification S.O. 2666(E) dated 17th October, 2014"
date: "2024-10-17"
pages: 11
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "03dae2e4ce731bb9"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99
L.

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (ii)
PART II—Section 3—Sub-section (ii)

izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 2118 ]

ubZ fnYyh] 'kqØokj] vDrwcj 17] 2014@vkf'ou 25] 1936

No. 2118]

NEW DELHI, FRIDAY, OCTOBER 17, 2014/ASVINA 25,, 1936

BÉßEÉÊ−É àÉÆjÉÉãÉªÉ
({É¶ÉÖ{ÉÉãÉxÉ, bäªÉ®ÉÒ +ÉÉè® àÉiºªÉ{ÉÉãÉxÉ ÉÊ´É£ÉÉMÉ)

+ÉÉÊvÉºÉÚSÉxÉÉ

xÉ<Ç ÉÊnããÉÉÒ, 16 vDrwcj] 2014
BÉEÉ.+ÉÉ. 2666(+É).—BÉEäxpÉÒªÉ ºÉ®BÉEÉ®, {É¶ÉÖvÉxÉ +ÉÉªÉÉiÉ +ÉÉÊvÉÉÊxÉªÉàÉ, 1898 (1898 BÉEÉ 9) BÉEÉÒ vÉÉ®É 2 BÉEä JÉÆb (PÉ) +ÉÉè® vÉÉ®É 3BÉE
uÉ®É |ÉnkÉ ¶ÉÉÎBÉDiÉªÉÉå BÉEÉ |ÉªÉÉäMÉ BÉE®iÉä cÖA +ÉÉè® +ÉÉÊvÉºÉÚSÉxÉÉ BÉEÉ.+ÉÉ.655(+É), iÉÉ®ÉÒJÉ 7 VÉÖ
VÉÖãÉÉ<Ç, 2001 BÉEÉä =xÉ ¤ÉÉiÉÉå BÉEä ÉÊºÉ´ÉÉªÉ +ÉÉÊvÉµÉEÉÆiÉ BÉE®iÉä
cÖA, ÉÊVÉxcå AäºÉä +ÉÉÊvÉµÉEàÉhÉ ºÉä {ÉcãÉä ÉÊBÉEªÉÉ MÉªÉÉ cè ªÉÉ BÉE®xÉä BÉEÉ ãÉÉä{É ÉÊBÉEªÉÉ MÉªÉÉ cè, “{É¶ÉÖvÉxÉ =i{ÉÉn” +ÉÉè® ÉÊxÉàxÉÉÊãÉÉÊJÉiÉ AäºÉä =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ
BÉEä ÉÊãÉA º´ÉSUiÉÉ +ÉÉªÉÉiÉ {É®ÉÊàÉ] VÉÉ®ÉÒ BÉE®xÉä BÉEä |ÉÉÊµÉEªÉÉ +ÉÉÊvÉºÉÚÉÊSÉiÉ BÉE®iÉÉÒ cè :—
1.

“{É¶ÉÖvÉxÉ =i{ÉÉnÉå” ¶É¤n àÉå ÉÊxÉàxÉÉÊãÉÉÊJÉiÉ =i{ÉÉn ºÉÉÎààÉÉÊãÉiÉ cÉåMÉä, +ÉlÉÉÇiÉÂ :—
(i)) ºÉ£ÉÉÒ |ÉBÉEÉ® BÉEÉ àÉÉÆºÉ +ÉÉè® àÉÉÆºÉ =i{ÉÉn ÉÊVÉºÉBÉEä +ÉÆiÉMÉÇ
ÉMÉiÉ àÉUãÉÉÒ, ¶ÉÉÒÉÊiÉiÉ +ÉÉè® ÉÊcàÉ¶ÉÉÒÉÊiÉiÉ (|ÉEÉäVÉäxÉ) BÉÖEBÉDBÉÖE], £Éä½, ¤ÉBÉE®ÉÒ +ÉÉè® ºÉÖ+É®

BÉEÉ àÉÉÆºÉ ;
(ii)) BÉÖEBÉDBÉÖE], £Éä½, ¤ÉBÉE®ÉÒ +ÉÉè® ºÉÖ+É® BÉEä >óiÉBÉE ªÉÉ +ÉÆMÉ ;
(iii) +ÉÆbä +ÉÉè® +ÉÆbÉ SÉÚhÉÇ ;
(iv) nÖMvÉ +ÉÉè® nÖMvÉ =i{ÉÉn ;
(v)) MÉÉäBÉÖEãÉÉÒªÉ, £Éä½BÉÖEãÉÉÒªÉ +ÉÉè® ¤ÉBÉE®É BÉÖEãÉÉÒªÉ §ÉÚhÉ, +ÉÆb ªÉÉ ¶ÉÖµÉE ;
(vi)) {É¶ÉÖ àÉÚãÉ BÉEä {ÉÉãÉiÉÚ {É¶ÉÖ JÉÉtÉ =i{ÉÉn ;
(vii)) ºÉ£ÉÉÒ VÉãÉSÉ® {É¶ÉÖ+ÉÉäÆ BÉEä ÉÊVÉºÉBÉEä +ÉÆiÉMÉÇiÉ àÉUãÉÉÒ, µÉEº]äÉÊ¶ÉªÉxÉ +ÉÉè® àÉÉäãÉºBÉE £ÉÉÒ cè, +ÉÆ
+ÉÆbä +ÉÉè® ¤ÉÉÒVÉ ;
(viii)) ºÉÚ+É®, cÉìMÉ ªÉÉ ºÉÚBÉE® BÉEä BÉE½ä ¤ÉÉãÉ +ÉÉè® ¤ÉÉãÉ ; ºÉÚ+É®, cÉMÉ +ÉÉè® ºÉÚBÉE® BÉEä BÉE½ä ¤ÉÉãÉ +ÉÉè® ¤ÉÉãÉ BÉEÉ +É{ÉÉÊ¶É−] ; ¤ÉèãÉ BÉEä ¤ÉÉãÉ
+ÉÉè® +ÉxªÉ ¥É¶É ¤ÉxÉÉxÉä ´ÉÉãÉä ¤ÉÉãÉ, ªÉÉBÉE BÉEä {ÉÚÆU BÉEä ¤ÉÉãÉ ; ¥É¶É ¤ÉxÉÉxÉä ´ÉÉãÉä ¤ÉÉãÉ, BcäãÉ BÉEÉÒ cbÂbÉÒ BÉEä ¤ÉÉãÉ, cbÂbÉÒ +ÉÉè® cbÂbÉÒ =i{ÉÉn
ÉÊVÉºÉBÉEä +ÉÆiÉMÉÇiÉ ºÉÉÓMÉ BÉEÉ MÉÚnÉ, ÉÊ{ÉºÉÉÒ cÖ<Ç cÉÊbÂbªÉÉÆ, cbÂbÉÒ {ÉäªÉ, +ÉÉÎºlÉÉÊBÉE, ºÉÉÓMÉÉå BÉEÉ MÉÚnÉ +ÉÉè® =ºÉBÉEÉ
=ºÉBÉEÉ AäºÉÉ £ÉÉMÉ VÉÉä ÉÊ{ÉºÉÉ cÖ+ÉÉ xÉcÉÓ
cè, +ÉÉÎºlÉ SÉÚhÉÇ, JÉÖ® BÉEÉ SÉÚhÉÇ, ºÉÉÓMÉ BÉEÉ SÉÚhÉÇ, ºÉÉÓMÉÉå, JÉÖ®Éå, {ÉÆVÉÉå, xÉÉJÉÚxÉÉå +ÉÉè® SÉÉåSÉ +ÉÉÊ´ÉÉÊxÉÉÌàÉiÉ ªÉÉ ºÉÉvÉÉ®hÉ
ºÉÉ
iÉÉè® {É® iÉèªÉÉ® BÉEÉÒ MÉ<Ç

4131 GI/2014

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(ÉËBÉEiÉÖ +ÉÉBÉEÉ® àÉå xÉ BÉEÉ]ä MÉA) ; ÉÊc®hÉ BÉEä ¶ÉÉJÉÉªÉÖBÉDiÉ £ÉßÆMÉ ; +ÉÉBÉDºÉ MÉÉìãÉº]ÉäxÉ (¤ÉèãÉ BÉEä ÉÊ{ÉkÉ +É¶àÉ®ÉÒ) ; +ÉÉè®, ªÉlÉÉÉÎºlÉÉÊiÉ, MÉÉäBÉÖEãÉÉÒªÉ,
£Éä½, ¤ÉBÉE®ÉÒ, BÉÖEBÉDBÉÖE] +ÉÉè® ºÉÖ+É® iÉlÉÉ ÉÊBÉEºÉÉÒ +ÉxªÉ {É¶ÉÖ ºÉä +ÉÉÊ£É|ÉÉ{iÉ ÉÊcàÉ¶ÉÉÒÉÊiÉiÉ VÉ®ÉªÉÖxÉÉãÉ ({ãÉäºÉå]É) ;
(ix) {ÉÉÊFÉªÉÉå BÉEÉÒ BÉESSÉÉÒ i´ÉSÉÉ +ÉÉè® +ÉxªÉ +ÉÆMÉ, =xÉBÉEä {ÉÆJÉÉå ªÉÉ BÉEÉäàÉãÉ ÉÊ{ÉSU, {ÉÆJÉ +ÉÉè® {ÉÆJÉÉå BÉEä +ÉÆMÉ (ÉÊ¤ÉxÉÉ BÉE]É<Ç UÆ]É<Ç BÉEä ªÉÉ =ºÉBÉEä
ºÉÉlÉ) +ÉÉè® BÉEÉäàÉãÉ ÉÊ{ÉSU ;
(x) MÉÉäBÉÖEãÉÉÒªÉ (£ÉéºÉä ºÉÉÊciÉ) ªÉÉ +É¶´ÉÉÒªÉ {É¶ÉÖ+ÉÉäÆ, £Éä½ ªÉÉ àÉäàÉxÉä BÉEÉÒ BÉESSÉÉÒ JÉÉãÉ +ÉÉè® i´ÉSÉÉ, +ÉxªÉ BÉESSÉÉÒ JÉÉãÉ (¤ÉBÉEÉÊ®ªÉÉå, ºÉÖ+É® BÉEÉÒ
i´ÉSÉÉ), iÉÉVÉÉ ªÉÉ xÉàÉBÉEÉÒxÉ ¶ÉÖ−BÉE, SÉÚxÉÉ ãÉMÉÉ cÖ+ÉÉ, +ÉàãÉÉÒªÉ ªÉÉ +ÉxªÉlÉÉ ºÉÆ®ÉÊFÉiÉ ÉËBÉEiÉÖ ÉÊ¤ÉxÉÉ ÉÊºÉZÉÉA cÖA, SÉàÉÇ{ÉjÉ ¤ÉxÉÉA MÉA ®ÆMÉ +ÉÉè®
VªÉÉnÉ iÉèªÉÉ® ÉÊBÉEA MÉA ¤ÉÉãÉÉå ºÉÉÊciÉ ªÉÉ =ºÉBÉEä ¤ÉMÉè® ªÉÉ ®ÉåA ºÉÉÊciÉ ªÉÉ =ºÉBÉEä +ÉãÉMÉ BÉE®BÉEä ;
(xi) BÉESSÉÉÒ {ÉE® i´ÉSÉÉ ({ÉE® SÉàÉÇ BªÉÉ{ÉÉÉÊ®ªÉÉå BÉEä ={ÉªÉÉäMÉ BÉEä ÉÊãÉA ={ÉªÉÖBÉDiÉ ÉÊºÉ® {ÉÚÆU, {ÉÆVÉä +ÉÉè® ]ÖBÉE½ä iÉlÉÉ BÉEiÉ®xÉä ºÉÉÊciÉ) ;
(xii) {ÉÉÊFÉªÉÉå BÉEä {ÉÆJÉÉå ºÉä ¤ÉxÉÉÒ ¤ÉäbÉËàÉ]xÉ BÉEÉÒ ¶É]ãÉ BÉEÉìBÉE, {ÉÆJÉÉå BÉEÉ SÉÚhÉÇ +ÉÉè® {ÉÉ=b® ;
(xiii) MÉÉäBÉÖEãÉÉÒªÉ, ¤ÉBÉE®ÉÒ, £Éä½, PÉÉä½É, BÉÖEBÉDBÉÖE], ºÉÚ+É®, JÉ®MÉÉä¶É, àÉÚ−ÉBÉE, SÉÚcÉ, BÉÖEkÉÉ +ÉÉè® ÉÊ¤ÉããÉÉÒ VÉèºÉä {É¶ÉÖ+ÉÉäÆ BÉEÉ ºÉÉÒ®àÉ +ÉÉè® {ãÉÉVàÉÉ ;
(xiv) {É¶ÉÖ SÉÉ®É +ÉÉè® àÉUãÉÉÒ BÉEÉ £ÉÉäVÉxÉ ÉÊVÉxÉàÉå MÉÉäBÉÖEãÉÉÒªÉ, £Éä½BÉÖEãÉÉÒªÉ +ÉÉè® ¤ÉBÉE®ÉBÉÖEãÉÉÒªÉ nÖMvÉ +ÉÉè® nÖMvÉ =i{ÉÉn +ÉÆiÉÉÌ´É−] cÉå, àÉÉÆºÉ +ÉÉè®
àÉÉÆºÉ =i{ÉÉn, BÉÖEBÉDBÉÖE], ºÉÚ+É®, £Éä½ +ÉÉè® ¤ÉBÉE®ÉÒ BÉEä =kÉBÉE iÉlÉÉ àÉUãÉÉÒ =i{ÉÉn ;
(xv) PÉÉä½ä BÉEä ¤ÉÉãÉ iÉlÉÉ PÉÉä½ä BÉEä ¤ÉÉãÉÉå BÉEÉ +É{ÉÉÊ¶É−] SÉÉcä ´Éc ºÉcÉªÉBÉE ºÉÉàÉOÉÉÒ BÉEä ºÉÉlÉ ªÉÉ =ºÉBÉEä ¤ÉMÉè® {É¶iÉ BÉEä °ô{É àÉå ®JÉä MÉA cè
ªÉÉ xÉcÉÓ ;
(xvi) +ÉÉÊxÉÉÌàÉiÉ ªÉÉ ºÉÉvÉÉ®hÉ °ô{É ºÉä iÉèªÉÉ® ÉËBÉEiÉÖ +ÉxªÉlÉÉ +ÉÉÊxÉÉÌàÉiÉ àÉÚÆMÉÉ +ÉÉè® ´ÉèºÉÉÒ cÉÒ ºÉÉàÉOÉÉÒ +ÉÉÊxÉÉÌàÉiÉ ªÉÉ ºÉÉvÉÉ®hÉ °ô{É àÉå iÉèªÉÉ® ÉËBÉEiÉÖ
+ÉÉBÉEÉ® àÉå xÉ BÉEÉ]ä MÉA àÉÉäãÉºBÉE BÉEÉ JÉÉäãÉ, {É{É½ÉÒ ªÉÉ SÉàÉÉÇJÉÉ½É +ÉÉè® BÉE]ãÉ¤ÉÉäxÉ, =ºÉBÉEÉ {ÉÉ=b® +ÉÉè® +É{ÉÉÊ¶É−] ;
(xvii) +ÉÉè−ÉÉÊvÉªÉÉÆ (MÉÉäBÉÖEãÉÉÒªÉ ¶´ÉäiÉBÉE +ÉÉè® {É¶ÉÖàÉÚãÉ BÉEÉÒ +ÉÉè−ÉÉÊvÉ) +ÉÉè® xÉènÉÉÊxÉBÉE (ÉÊVÉºÉàÉå +ÉÆiÉVÉÉÒ´É |ÉªÉÉäVÉxÉ BÉEä ÉÊãÉA ®BÉDiÉ ªÉÉ ºÉÉÒ®àÉ
+ÉÆiÉÉÌ´É−] cÉä) ;
(xviii) ÉÊVÉãÉäÉÊ]xÉ ¶ÉÉÒ] (ÉÊVÉºÉBÉEä +ÉÆiÉMÉÇiÉ +ÉÉªÉiÉÉBÉEÉ® ªÉÉ ´ÉMÉÉÇBÉEÉ® ÉÊVÉãÉäÉÊ]xÉ £ÉÉÒ cè, SÉÉcä =ºÉBÉEÉÒ ºÉiÉc ÉÊxÉÉÌàÉiÉ) ªÉÉ ®ÆMÉÉÒxÉ cÉä ªÉÉ xÉ cÉä
+ÉÉè® ÉÊVÉãÉäÉÊ]xÉ BªÉÖi{ÉÉÉÊniÉ, +ÉÉ<ÉËVÉMÉ MãÉÉºÉ ; BÉEäºÉÉÒxÉ ¶ãÉä−ÉhÉ BÉEÉä UÉä½BÉE® {É¶ÉÖàÉÚãÉ BÉEä +ÉxªÉ ¶ãÉä−ÉhÉ ;
(xix) ÉÊ¤ÉxÉÉ ¤ÉÉãÉ BÉEä MÉÉäBÉÖEãÉÉÒªÉ (ÉÊVÉºÉàÉå £ÉéºÉ £ÉÉÒ cè) ªÉÉ +É¶´ÉÉÒªÉ {É¶ÉÖ+ÉÉäÆ BÉEÉÒ SÉàÉÇ ªÉÉ +ÉÉÊ£É¶É{iÉ JÉÉãÉ +ÉÉè® i´ÉSÉÉ SÉÉcä ÉÊ´É£ÉÉÉÊVÉiÉ cÉä ªÉÉ xÉ
cÉä ÉËBÉEiÉÖ +ÉÉMÉä +ÉÉè® iÉèªÉÉ® xÉ BÉEÉÒ MÉ<Ç *
(xx) +ÉãÉMÉ ÉÊBÉEA MÉA +ÉlÉ´ÉÉ xÉcÉÓ, {É® +ÉÉMÉä iÉèªÉÉ® xÉ ÉÊBÉEA MÉA, >ó{É® ÉÊ¤ÉxÉÉ >óxÉ ´ÉÉãÉä £Éä½ +ÉlÉ´ÉÉ àÉäàÉxÉä BÉEä ÉÊºÉZÉÉA +ÉlÉ´ÉÉ {É{É½ÉÒ ¤ÉxÉÉ<Ç
MÉ<Ç JÉÉãÉ A´ÉÆ i´ÉSÉÉ, +ÉãÉMÉ ÉÊBÉEA MÉA +ÉlÉ´ÉÉ xÉcÉÓ, {É® +ÉÉMÉä xÉ iÉèªÉÉ® ÉÊBÉEA MÉA >ó{É® ÉÊ¤ÉxÉÉ >óxÉ +ÉlÉ´ÉÉ ¤ÉÉãÉ ´ÉÉãÉä +ÉxªÉ {É¶ÉÖ+ÉÉäÆ BÉEä
ÉÊºÉZÉÉA +ÉlÉ´ÉÉ {É{É½ÉÒ ¤ÉxÉÉ<Ç MÉ<Ç JÉÉãÉ A´ÉÆ i´ÉSÉÉ (¤ÉBÉE®ÉÒ, ºÉÚ+É®, ºÉ®ÉÒºÉß{É +ÉÉÉÊn BÉEä) ;
(xxi) SÉàÉÇ {ÉjÉ ¤ÉxÉÉA MÉA SÉàÉ½ä ºÉÉÊciÉ, ÉÊºÉZÉÉxÉä +ÉlÉ´ÉÉ {É{É½ÉÒ ¤ÉxÉÉxÉä BÉEä ¤ÉÉn +ÉÉMÉä iÉèªÉÉ® MÉÉäBÉÖEãÉÉÒªÉ (£ÉéºÉ ºÉÉÊciÉ) +ÉlÉ´ÉÉ +É¶´ÉÉÒªÉ {É¶ÉÖ+ÉÉäÆ
ÉÊVÉxÉBÉEä >ó{É® ¤ÉÉãÉ xÉ cÉä, +ÉãÉMÉ ÉÊBÉEA MÉA +ÉlÉ´ÉÉ xÉcÉÓ, SÉàÉÇ {ÉjÉ ¤ÉxÉÉA MÉA SÉàÉ½ä ºÉÉÊciÉ, ÉÊºÉZÉÉxÉä +ÉlÉ´ÉÉ {É{É½ÉÒ ¤ÉxÉÉxÉä BÉEä ¤ÉÉn +ÉÉMÉä
iÉèªÉÉ® £Éä½ +ÉlÉ´ÉÉ àÉäàÉxÉä, ÉÊVÉºÉBÉEä >ó{É® >óxÉ xÉ cÉä, +ÉãÉMÉ ÉÊBÉEA MÉA +ÉlÉ´ÉÉ xÉcÉÓ, SÉàÉÇ {ÉjÉ ¤ÉxÉÉA MÉA SÉàÉ½ä ºÉÉÊciÉ ÉÊºÉZÉÉxÉä +ÉlÉ´ÉÉ {É{É½ÉÒ
¤ÉxÉÉxÉä BÉEä ¤ÉÉn +ÉÉMÉä iÉèªÉÉ® +ÉxªÉ {É¶ÉÖ+ÉÉäÆ ÉÊVÉxÉBÉEä >ó{É® >óxÉ +ÉlÉ´ÉÉ ¤ÉÉãÉ xÉ cÉä, +ÉãÉMÉ ÉÊBÉEA MÉA +ÉlÉ´ÉÉ xÉcÉÓ (¤ÉBÉE®ÉÒ, ºÉÚ+É®, ºÉ®ÉÒºÉß{É +ÉÉÉÊn
ºÉÉÊciÉ) ;
(xxii) ºÉÉÆ£É® (ÉÊVÉºÉàÉå ºÉÆªÉÉäVÉxÉ ºÉÉÆ£É® £ÉÉÒ cè) BÉEÉ SÉàÉ½É, {Éä]å] SÉàÉ½É iÉlÉÉ {Éä]å] ãÉäÉÊàÉxÉä¶ÉxÉªÉÖBÉDiÉ SÉàÉ½É, vÉÉiÉÖBÉßEiÉ SÉàÉ½É ;
(xxiii) {É]Â]ÉÒ àÉå, SÉÉn® +ÉlÉ´ÉÉ {ÉEÉÒiÉä àÉå SÉàÉ½É {ÉEÉ<¤É® BÉEä +ÉÉvÉÉ® {É® SÉàÉ½ä BÉEä ÉÊàÉgÉhÉ, SÉÉcä ®ÉäãÉ àÉå cÉä +ÉlÉ´ÉÉ xÉcÉÓ, {Éä+ÉÉË®MÉ iÉlÉÉ
SÉàÉ½ä BÉEä +ÉxªÉ +É{ÉÉÊ¶É−] +ÉlÉ´ÉÉ ÉÊàÉÉÊgÉiÉ SÉàÉ½ä, VÉÉä SÉàÉ½ä BÉEÉÒ ´ÉºiÉÖ+ÉÉäÆ, SÉàÉ½ä BÉEÉÒ ¤ÉÖBÉExÉÉÒ {ÉÉ=b® SÉÚhÉÇ BÉEä ÉÊ´ÉÉÊxÉàÉÉÇhÉ BÉEä ÉÊãÉA ={ÉªÉÖBÉDiÉ
xÉcÉÓ cè ;
(xxiv) +ÉºÉÆBÉEÉÊãÉiÉ ªÉÉ ºÉÆBÉEÉÊãÉiÉ (+ÉxªÉ ºÉÉàÉÉÊOÉªÉÉå BÉEÉä VÉÉä½BÉE® ªÉÉ ÉÊ¤ÉxÉÉ VÉÉä½ä) ÉÊºÉZÉÉA +ÉlÉ´ÉÉ |ÉºÉÉÉÊvÉiÉ ÉÊBÉEA MÉA {ÉE® BÉEÉÒ JÉÉãÉ (ÉÊºÉ®,
{ÉÚÆU, {ÉÆVÉä iÉlÉÉ +ÉxªÉ ]ÖBÉE½ä +ÉlÉ´ÉÉ ]ÖBÉE½ä ºÉÉÊciÉ) ;
(xxv) +ÉxÉvÉÖxÉä iÉlÉÉ MÉÆnä >óxÉ, +ÉxÉºÉÖãÉZÉä iÉlÉÉ MÉÆnä ¤ÉÉ®ÉÒBÉE iÉlÉÉ BÉE~Éä® {É¶ÉÖ ¤ÉÉãÉ, MÉÉ®xÉä]äb º]ÉìBÉE BÉEÉä UÉä½BÉE®, ºÉÚiÉ ºÉÉÊciÉ +É{ÉÉÊ¶É−]
+ÉlÉ´ÉÉ >óxÉ +ÉlÉ´ÉÉ ¤ÉÉ®ÉÒBÉE +ÉlÉ´ÉÉ BÉE~Éä® {É¶ÉÖ ¤ÉÉãÉ ;
(xxvi) ÉÊBÉEºÉÉÒ {É¶ÉÖ BÉEÉÒ {ÉªÉÉÇhÉBÉEÉÉÊ®iÉÉ +ÉÉè® ºÉVVÉÉ BÉEÉÒ BÉEÉä<Ç ´ÉºiÉÖ, ]ÅÆBÉE, ºÉÚ]BÉEäºÉ, ´ÉäÉÊxÉ]ÉÒ BÉEäºÉ, ¥ÉÉÒ{ÉEBÉEäºÉ, lÉèãÉÉÒ, {ÉÉ=SÉ, cÉlÉ BÉEÉ ¤ÉèMÉ
<iªÉÉÉÊn ;

<!-- page 3 -->

¹HkkxIIµ[k.M3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

(xxvii) àÉ¶ÉÉÒxÉ®ÉÒ +ÉlÉ´ÉÉ ªÉÉÆÉÊjÉBÉEÉÒ ={ÉBÉE®hÉÉå àÉå +ÉlÉ´ÉÉ +ÉxªÉ iÉBÉExÉÉÒBÉEÉÒ ={ÉªÉÉäMÉÉå BÉEä ÉÊãÉA SÉàÉÇ ºÉÆ¤ÉÆvÉÉÒ BÉE{É½Éå BÉEä ºÉÉàÉÉxÉ iÉlÉÉ ´ÉºjÉ
ºÉÆ¤ÉÆvÉÉÒ ´ÉºiÉÖAÆ, SÉàÉÇ BÉEä +ÉlÉ´ÉÉ ÉÊàÉÉÊgÉiÉ SÉàÉÇ, ABÉE |ÉBÉEÉ® BÉEä SÉàÉÇ ºÉÆ¤ÉÆvÉÉÒ ´ÉºiÉÖ +ÉlÉ´ÉÉ ÉÊàÉÉÊgÉiÉ ´ÉºiÉÖ ;
(xxviii) SÉàÉÇ +ÉlÉ´ÉÉ ÉÊàÉÉÊgÉiÉ SÉàÉÇ (º]Åä{É ´Éäã], BÉE´É®) ºÉÆ¤ÉÆvÉÉÒ +ÉxªÉ ºÉÉàÉÉxÉ, {ÉÉÊ®vÉÉxÉ ºÉÆ¤ÉÆvÉÉÒ ºÉÉàÉÉxÉ, {ÉEºÉÇÉÊBÉExÉ ºÉÆ¤ÉÆvÉÉÒ BÉE{É½Éå BÉEä ºÉÉàÉÉxÉ
iÉlÉÉ +ÉxªÉ ´ÉºiÉÖ ;
(xxix) MÉÉäãb ¤ÉÉÒ]® BÉEä SÉàÉÇ, ¤ãÉÉb®, ]åbxÉ ºÉÆ¤ÉÆvÉÉÒ ´ÉºiÉÖA,Æ {ÉÉÊ®nÉxÉ ºÉÆ¤ÉÆvÉÉÒ ´ÉºiÉÖAÆ, {ÉEºÉÉÒBÉExÉ ºÉÆ¤ÉÆvÉÉÒ BÉE{É½Éå BÉEä ºÉÉàÉÉxÉ +ÉÉè® +ÉxªÉ ´ÉºiÉÖAÆ,
BÉßEÉÊjÉàÉ {ÉE® iÉlÉÉ =xÉBÉEÉÒ ´ÉºiÉÖA ;
(xxx) >óxÉ +ÉlÉ´ÉÉ +ÉSUä +ÉlÉ´ÉÉ àÉÉä]ä {É¶ÉÖ ¤ÉÉãÉ BÉEä MÉÉ®xÉä]äb º]ÉBÉE, vÉÖxÉä +ÉlÉ´ÉÉ ºÉÉ{ÉE ÉÊBÉEA MÉA >óxÉ +ÉÉè® +ÉSUä +ÉlÉ´ÉÉ àÉÉä]ä {É¶ÉÖ ¤ÉÉãÉ
(+ÉÉÆÉÊ¶ÉBÉE °ô{É ºÉä ºÉÉ{ÉE ¤ÉÉãÉ) vÉÖxÉä cÖA >óxÉ BÉEÉÒ ºÉÚiÉ ÉÊVÉºÉä JÉÖn®É ÉÊ¤ÉµÉEÉÒ BÉEä ÉÊãÉA xÉcÉÓ ®JÉÉ MÉªÉÉ, +ÉSUä {É¶ÉÖ ¤ÉÉãÉ ºÉÆ¤ÉÆvÉÉÒ ºÉÚiÉ (vÉÖxÉä cÖA
+ÉlÉ´ÉÉ ºÉÉ{ÉE ÉÊBÉEA cÖA) ÉÊVÉºÉä JÉÖn®É ÉÊ¤ÉµÉEÉÒ BÉEä ÉÊãÉA xÉcÉÓ ®JÉÉ MÉªÉÉ, >óxÉ ºÉÆ¤ÉvÉÉÒ ºÉÚiÉ +ÉlÉ´ÉÉ +ÉSUä {É¶ÉÖ ¤ÉÉãÉ ÉÊVÉºÉä JÉÖnÉ® ÉÊ¤ÉµÉEÉÒ BÉEä ÉÊãÉA
®JÉÉ MÉªÉÉ, àÉÉä]ä {É¶ÉÖ ¤ÉÉãÉ +ÉlÉ´ÉÉ +É¶´É ¤ÉÉãÉ ºÉÆ¤ÉÆvÉÉÒ ºÉÚiÉ (ÉËMÉ{Éb +É¶´É ¤ÉÉãÉ ºÉÆ¤ÉÆvÉÉÒ ºÉÚiÉ ÉÊVÉºÉä JÉÖn®É ÉÊ¤ÉµÉEÉÒ BÉEä ÉÊãÉA ®JÉÉ xÉcÉÓ MÉªÉÉ cè,
BÉEä ºÉÉÊciÉ) vÉÖxÉä >óxÉ ºÉÆ¤ÉÆvÉÉÒ ¤ÉÖxÉä cÖA BÉE{É½ä +ÉlÉ´ÉÉ vÉÖxÉä cÖA +ÉSUä {É¶ÉÖ ¤ÉÉãÉ, ºÉÉ{ÉE >óxÉ +ÉlÉ´ÉÉ vÉÖxÉä cÖA +ÉSUä {É¶ÉÖ ¤ÉÉãÉ BÉEä ¤ÉÖxÉä cÖA BÉE{É½ä,
àÉÉä]ä {É¶ÉÖ ¤ÉÉãÉ +ÉlÉ´ÉÉ +É¶´É ¤ÉÉãÉ ºÉÆ¤ÉÆvÉÉÒ ¤ÉÖxÉä cÖA BÉE{É½ä *
2. <xÉ =i{ÉÉnÉå BÉEÉ +ÉÉªÉÉiÉ BÉEä´ÉãÉ <ºÉ +ÉÉÊvÉºÉÚSÉxÉÉ àÉå +ÉÉÊvÉBÉEÉÊlÉiÉ |ÉÉÊµÉEªÉÉ BÉEä +ÉxÉÖºÉÉ® <ºÉ ÉÊ´É£ÉÉMÉ uÉ®É VÉÉ®ÉÒ ÉÊBÉEªÉÉ VÉÉxÉä ´ÉÉãÉÉ º´ÉSUiÉÉ +ÉÉªÉÉiÉ
{É®ÉÊàÉ] BÉEä +ÉÉvÉÉ® {É® cÉÒ +ÉxÉÖYÉÉiÉ ÉÊBÉEªÉÉ VÉÉAMÉÉ *
3. ªÉc +ÉÉÊvÉºÉÚSÉxÉÉ ®ÉVÉ{ÉjÉ àÉå |ÉBÉEÉ¶ÉxÉ BÉEÉÒ iÉÉ®ÉÒJÉ BÉEÉä |É´ÉßkÉ cÉäMÉÉÒ *
+ÉxÉÖºÉÚSÉÉÒ
({Éè®É 2 näÉÊJÉA)
£ÉÉ®iÉ àÉå {É¶ÉÖ vÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ BÉEÉÒ |ÉÉÊµÉEªÉÉ
£ÉÉ®iÉ àÉå ºÉ£ÉÉÒ {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEÉ +ÉÉªÉÉiÉ ÉÊxÉàxÉÉÊãÉÉÊJÉiÉ ¶ÉiÉÉç BÉEä +ÉvÉÉÒxÉ ®ciÉä cÖA ÉÊBÉEªÉÉ VÉÉAMÉÉ, +ÉlÉÉÇiÉÂÂ :(1) BÉEÉä<Ç £ÉÉÒ {É¶ÉÖvÉxÉ =i{ÉÉn JÉÆb (3) BÉEä +ÉvÉÉÒxÉ VÉÉ®ÉÒ ÉÊ´ÉÉÊvÉàÉÉxªÉ º´ÉSUiÉÉ +ÉÉªÉÉiÉ {É®ÉÊàÉ] BÉEä ¤ÉMÉè® xÉcÉÓ ÉÊBÉEªÉÉ VÉÉAMÉÉ *
(2) £ÉÚÉÊàÉ àÉÉMÉÇ, ´ÉÉªÉÖ àÉÉMÉÇ ªÉÉ VÉãÉ àÉÉMÉÇ uÉ®É {ÉÉ®ä−ÉhÉÉå BÉEÉ +ÉÉªÉÉiÉ BÉE®xÉä BÉEä ÉÊãÉA ºÉ£ÉÉÒ +ÉÉ´ÉänxÉ |É°ô{É ‘BÉE’ ªÉÉ |ÉÉ°ô{É ‘JÉ’, VÉÉä £ÉÉÒ ºÉÖºÉÆMÉiÉ cÉå, àÉå
ÉÊBÉEA VÉÉAÆMÉä +ÉÉè® iÉÉÒxÉ |ÉÉÊiÉªÉÉå àÉå ºÉÆªÉÖBÉDiÉ ºÉÉÊSÉ´É, BªÉÉ{ÉÉ® |É£ÉÉMÉ, {É¶ÉÖ{ÉÉãÉxÉ, bäªÉ®ÉÒ +ÉÉè® àÉiºªÉBÉEÉÒ ÉÊ´É£ÉÉMÉ, BÉßEÉÊ−É àÉÆjÉÉãÉªÉ, £ÉÉ®iÉ ºÉ®BÉEÉ® BÉEÉä £ÉäVÉä
VÉÉAÆMÉä *
(3) (i) {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ BÉEä ÉÊãÉA º´ÉSUiÉÉ +ÉÉªÉÉiÉ {É®ÉÊàÉ] iÉ£ÉÉÒ VÉÉ®ÉÒ ÉÊBÉEªÉÉ VÉÉAMÉÉ ªÉÉÊn ÉÊ´ÉºiÉßiÉ +ÉÉªÉÉiÉ VÉÉäÉÊJÉàÉ ÉÊ´É¶ãÉä−ÉhÉ BÉE®xÉä BÉEä
{É¶SÉÉiÉÂÂ ºÉÆ¤ÉÆÉÊvÉiÉ |ÉÉÉÊvÉBÉEÉÉÊ®ªÉÉå BÉEÉ ªÉc ºÉàÉÉvÉÉxÉ cÉä VÉÉiÉÉ cè ÉÊBÉE {ÉÉ®ä−ÉhÉ àÉÉãÉ BÉEä +ÉÉªÉÉiÉ ºÉä <ºÉ nä¶É BÉEä {É¶ÉÖ +ÉÉè® àÉÉxÉ´É VÉxÉºÉÆJªÉÉ BÉEä
º´ÉÉºlªÉ {É® |ÉÉÊiÉBÉÚEãÉ |É£ÉÉ´É xÉcÉÓ {É½äMÉÉ *
(ii) +ÉÉªÉÉiÉ VÉÉäÉÊJÉàÉ ÉÊ´É¶ãÉä−ÉhÉ <ºÉ ÉÊ´É£ÉÉMÉ BÉEä ºÉÆ¤ÉÆÉÊvÉiÉ +ÉÉÊvÉBÉEÉÉÊ®ªÉÉå uÉ®É VÉÉäÉÊJÉàÉ ÉÊ´É¶ãÉä−ÉhÉ BÉEä +ÉÆiÉ®®É−]ÅÉÒªÉ °ô{É ºÉä àÉÉxªÉiÉÉ|ÉÉ{iÉ ÉÊºÉrÉÆiÉÉå
BÉEä +ÉÉvÉÉ® {É® ÉÊBÉEªÉÉ VÉÉAMÉÉ +ÉÉè® ÉÊ´É¶ãÉä−ÉhÉ ÉÊ´ÉÉÊxÉÉÌn−] =i{ÉÉn +ÉÉè® ÉÊxÉªÉÉÇiÉ BÉE®xÉä ´ÉÉãÉä nä¶É àÉå ®ÉäMÉ BÉEÉÒ ÉÊ´ÉtÉàÉÉxÉ ÉÎºlÉÉÊiÉ +ÉÉè® ºÉÉlÉ cÉÒ £ÉÉ®iÉ
àÉå ®ÉäMÉ BÉEÉÒ ÉÎºlÉÉÊiÉ BÉEä ºÉÆn£ÉÇ àÉå ÉÊBÉEªÉÉ VÉÉAMÉÉ *
(iii) ªÉÉÊn +ÉÉªÉÉiÉ VÉÉäÉÊJÉàÉ ÉÊ´É¶ãÉä−ÉhÉ BÉEä {ÉÉÊ®hÉÉàÉÉå ºÉä nÉÌ¶ÉiÉ cÉäiÉÉ cè ÉÊBÉE ÉÊ´ÉÉÊxÉÉÌn−] =i{ÉÉn BÉEÉä ãÉÉxÉä ºÉä ABÉE ªÉÉ +ÉÉÊvÉBÉE ÉÊ´ÉÉÊxÉÉÌn−] AäºÉä
®ÉäMÉÉå BÉEÉ +ÉÉxÉä BÉEÉ VÉÉäÉÊJÉàÉ cè VÉÉä nä¶É àÉå ÉÊ´ÉtÉàÉÉxÉ xÉcÉÓ cè +ÉÉè® ÉÊVÉºÉºÉä <ºÉ nä¶É BÉEÉÒ àÉÉxÉ´É +ÉÉè® {É¶ÉÖ VÉxÉºÉÆJªÉÉ BÉEä º´ÉÉºlªÉ +ÉÉè® ºÉÖ®FÉÉ
{É® |ÉÉÊiÉBÉÚEãÉ |É£ÉÉ´É {É½ ºÉBÉEiÉÉ cè, iÉÉä {É®ÉÊàÉ] VÉÉ®ÉÒ BÉE®xÉä BÉEä <ÆBÉEÉ® BÉE® ÉÊnªÉÉ VÉÉAMÉÉ *
(iv) +ÉÉªÉÉiÉ {É®ÉÊàÉ] àÉå AäºÉÉÒ ÉÊ´ÉÉÊxÉÉÌn−] ¶ÉiÉç +ÉÉÊvÉBÉEÉÊlÉiÉ BÉEÉÒ VÉÉAMÉÉÒ VÉÉä {ÉÉ®ä−ÉhÉ BÉEÉÒ ¤ÉÉ¤ÉiÉ, ÉÊVÉºÉBÉEä +ÉÆiÉMÉÇiÉ ãÉnÉ<Ç {ÉÚ´ÉÇ |ÉàÉÉhÉÉÒBÉE®hÉ +ÉÉè®
BÉE®ÆiÉÉÒxÉ VÉÉÆSÉ £ÉÉÒ cè, {ÉÚ®ÉÒ BÉEÉÒ VÉÉxÉÉÒ cÉäMÉÉÒ *
(v)

{É®ÉÊàÉ] ºÉä BÉE®ÆiÉÉÒxÉ ÉÊxÉ®ÉÒFÉhÉ, xÉàÉÚxÉÉ +ÉÉè® {É®ÉÒFÉhÉ BÉEä ºÉÆ¤ÉÆvÉ àÉå +ÉÉªÉÉiÉ {É¶SÉÉiÉÂÂ BÉEÉÒ +É{ÉäFÉÉ+ÉÉäÆ BÉEÉä £ÉÉÒ ÉÊ´ÉÉÊxÉÉÌn−] ÉÊBÉEªÉÉ VÉÉAMÉÉ *

(vi) º´ÉSUiÉÉ +ÉÉªÉÉiÉ {É®ÉÊàÉ], iÉÉ{É +ÉÉÊ£ÉÉÊµÉEÉÊªÉiÉ nÖMvÉ +ÉÉè® nÖMvÉ =i{ÉÉn, àÉUãÉÉÒ =i{ÉÉn, BÉÖEBÉDBÉÖE], ºÉÚ+É®, £Éä½ +ÉÉè® ¤ÉBÉE®ÉÒ BÉEä àÉÉÆºÉ =i{ÉÉn,
{ÉÉãÉiÉÚ {É¶ÉÖ +ÉÉcÉ®, |ÉºÉÆºBÉßEiÉ ºÉÚ+É® BÉEä BÉE½ä ¤ÉÉãÉ +ÉÉè® |ÉºÉÆºBÉßEiÉ {ÉÆJÉ VÉèºÉä |ÉºÉÆºBÉßEiÉ {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ cäiÉÖ ABÉE ´É−ÉÇ BÉEÉÒ +É´ÉÉÊvÉ BÉEä
ÉÊãÉA ÉÊ´ÉÉÊvÉàÉÉxªÉ cÉäMÉÉ *
{É®ÆiÉÖ +É|ÉºÉÆºBÉßEiÉ {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ BÉEä ÉÊãÉA VÉÉ®ÉÒ {É®ÉÊàÉ] BÉEÉÒ ÉÊ´ÉÉÊvÉàÉÉxªÉiÉÉ Uc àÉÉºÉ BÉEÉÒ cÉäMÉÉÒ ÉËBÉEiÉÖ BÉEäxpÉÒªÉ ºÉ®BÉEÉ® uÉ®É
+ÉÉªÉÉiÉBÉEiÉÉÇ BÉEä +ÉxÉÖ®ÉävÉ {É® +ÉÉè® ãÉäJÉ¤Ér ÉÊBÉEA VÉÉxÉä ´ÉÉãÉä BÉEÉ®hÉÉå ºÉä Uc àÉÉºÉ BÉEÉÒ +ÉÉè® +É´ÉÉÊvÉ BÉEä ÉÊãÉA ¤ÉfÃÉ<Ç VÉÉ ºÉBÉEäMÉÉÒ *
(vii) ={É®ÉäBÉDiÉ µÉEàÉ ºÉÆ. (xv) ºÉä (xxiv) {É® ºÉÚSÉÉÒ¤Ér {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä ÉÊãÉA º´ÉSUiÉÉ +ÉÉªÉÉiÉ {É®ÉÊàÉ] +É{ÉäÉÊFÉiÉ xÉcÉÓ cÉäMÉÉ * iÉlÉÉÉÊ{É
µÉEàÉ ºÉÆ. (xv) ºÉä (xxiv) {É® ={ÉnÉÌ¶ÉiÉ {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ BÉEÉä ÉÊnããÉÉÒ, àÉÖÆ¤É<Ç, SÉäxxÉ<Ç +ÉÉè® BÉEÉäãÉBÉEÉiÉÉ ÉÎºlÉiÉ {É¶ÉÖ BÉE®ÆiÉÉÒxÉ +ÉÉè®
|ÉàÉÉhÉÉÒBÉE®hÉ ºÉä´ÉÉ º]ä¶ÉxÉ BÉEä £ÉÉ®ºÉÉvÉBÉE +ÉÉÊvÉBÉEÉ®ÉÒ ªÉÉ {É¶ÉÖ{ÉÉãÉxÉ, bäªÉ®ÉÒ +ÉÉè® àÉiºªÉBÉEÉÒ ÉÊ´É£ÉÉMÉ uÉ®É ºÉàªÉBÉEÂÂ °ô{É ºÉä |ÉÉÉÊvÉBÉßEiÉ ÉÊBÉEºÉÉÒ +ÉxªÉ

3

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

{É¶ÉÖ ÉÊSÉÉÊBÉEiºÉÉ +ÉÉÊvÉBÉEÉ®ÉÒ ºÉä, àÉÉãÉ BÉEÉÒ VÉÉÆSÉ BÉE®xÉä BÉEä {É¶SÉÉiÉÂÂ |ÉÉ{iÉ +ÉxÉÉ{ÉÉÊkÉ |ÉàÉÉhÉ{ÉjÉ |ÉºiÉÖiÉ BÉE®xÉä BÉEä {É¶SÉÉiÉÂÂ ÉÊ´ÉÉÊxÉªÉÉÊàÉiÉ ÉÊBÉEªÉÉ
VÉÉAMÉÉ *
(viii) ªÉc +ÉÉè® ÉÊBÉE µÉEàÉ ºÉÆ. (xxv) ºÉä (xxx) {É® ={ÉnÉÌ¶ÉiÉ {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ BÉEä ÉÊãÉA xÉ iÉÉä º´ÉSUiÉÉ +ÉÉªÉÉiÉ {É®ÉÊàÉ] +ÉÉè® xÉ
cÉÒ ºÉÆ¤ÉÆÉÊvÉiÉ BÉE®ÆiÉÉÒxÉ +ÉÉÊvÉBÉEÉ®ÉÒ BÉEÉ +ÉxÉÉ{ÉÉÊkÉ |ÉàÉÉhÉ{ÉjÉ +É{ÉäÉÊFÉiÉ cÉäMÉÉ *
(4)

£ÉÉ®iÉ àÉå ºÉ£ÉÉÒ {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEÉ +ÉÉªÉÉiÉ ÉÊnããÉÉÒ, àÉÖÆ¤É<Ç, BÉEÉäãÉBÉEÉiÉÉ, SÉèxxÉ<Ç, ¤ÉÆMÉãÉÉè® +ÉÉè® cèn®É¤ÉÉn ÉÎºlÉiÉ ºÉàÉÖp{ÉkÉxÉÉå ªÉÉ ÉÊ´ÉàÉÉxÉ {ÉkÉxÉÉå
BÉEä àÉÉvªÉàÉ ºÉä ÉÊBÉEªÉÉ VÉÉAMÉÉ VÉcÉÆ {É¶ÉÖ BÉE®ÆiÉÉÒxÉ +ÉÉè® |ÉàÉÉhÉÉÒBÉE®hÉ ºÉä´ÉÉ º]ä¶ÉxÉ +É´ÉÉÎºlÉiÉ cé *
{É®ÆiÉÖ VÉãÉSÉ® =i{ÉÉnÉå, +ÉÆbÉå, ¤ÉÉÒVÉÉå BÉEÉ +ÉÉªÉÉiÉ ºÉ£ÉÉÒ VÉãÉSÉ® {É¶ÉÖ+ÉÉäÆ BÉEÉ ÉÊVÉºÉBÉEä +ÉÆiÉMÉÇiÉ àÉUãÉÉÒ, BÉE~Éä® {É{É½ÉÒ ´ÉÉãÉä VÉãÉSÉ®, àÉÉäãÉºBÉE
BÉEÉ +ÉÉªÉÉiÉ ÉÊ´É¶ÉÉJÉÉ{É]xÉàÉ +ÉÉè® BÉEÉäÉÎSSÉ ÉÎºlÉiÉ ºÉàÉÖp{ÉkÉxÉÉå ªÉÉ ÉÊ´ÉàÉÉxÉ{ÉkÉxÉÉå {É® £ÉÉÒ +ÉxÉÖYÉÉiÉ cÉäMÉÉ *
{É®ÆiÉÖ ªÉc +ÉÉè® ÉÊBÉE AäºÉä ÉÊ´ÉxÉ¶´É® àÉUãÉÉÒ ºÉä ºÉÆ¤ÉÆÉÊvÉiÉ àÉnÉå BÉEÉ +ÉÉªÉÉiÉ VÉÉä +ÉxªÉjÉ °ô{É ºÉä àÉÉxÉ´É ={ÉªÉÉäMÉ BÉEä ÉÊãÉA cé * ÉËBÉEiÉÖ |ÉVÉxÉxÉ
ªÉÉ ºÉÆ´ÉvÉÇxÉ |ÉªÉÉäVÉxÉÉå ºÉä ºÉÆ¤ÉÆÉÊvÉiÉ ¤ÉÉÒVÉ ºÉÉàÉOÉÉÒ BÉEÉä UÉä½BÉE® {Éä]ÅÉ{ÉÉäãÉ, ÉÊVÉãÉÉ 24 {É®MÉxÉÉ, {ÉÉÎ¶SÉàÉÉÒ ¤ÉÆMÉÉãÉ BÉEÉÒ £ÉÚÉÊàÉ {É® ºÉ½BÉE BÉEä àÉÉvªÉàÉ ºÉä
+ÉxÉÖYÉÉiÉ cÉäMÉÉ *

(5)

(i) |É´Éä¶É ºlÉÉxÉ {É® +ÉÉMÉàÉxÉ BÉEä ºÉàÉªÉ {É¶ÉÖ{ÉÉãÉxÉ, bäªÉ®ÉÒ +ÉÉè® àÉiºªÉBÉEÉÒ ÉÊ´É£ÉÉMÉ uÉ®É ºÉàÉªÉ-ºÉàÉªÉ {É® VÉÉ®ÉÒ ºÉÉvÉÉ®hÉ àÉÉMÉÇn¶ÉÇBÉE ÉÊºÉrÉÆiÉÉå +ÉÉè®
º´ÉSU +ÉÉªÉÉiÉ {É®ÉÊàÉ] àÉå +ÉÉÊvÉBÉEÉÊlÉiÉ ÉÊ´ÉÉÊxÉÉÌn−] ¶ÉiÉÉç BÉEä +ÉxÉÖºÉÉ®, VÉcÉÆ £ÉÉÒ +ÉÉ´É¶ªÉBÉE cÉä, {É¶ÉÖvÉxÉ =i{ÉÉn BÉEÉÒ {É¶ÉÖ BÉE®ÆiÉÉÒxÉ +ÉÉè®
|ÉàÉÉhÉÉÒBÉE®hÉ ºÉä´ÉÉ BÉEäxp BÉEä £ÉÉ®ºÉÉvÉBÉE +ÉÉÊvÉBÉEÉ®ÉÒ +ÉlÉ´ÉÉ {É¶ÉÖ{ÉÉãÉxÉ, bäªÉ®ÉÒ +ÉÉè® àÉiºªÉBÉEÉÒ ÉÊ´É£ÉÉMÉ uÉ®É ºÉàªÉBÉEÂÂ °ô{É ºÉä |ÉÉÉÊvÉBÉßEiÉ +ÉxªÉ
{É¶ÉÖÉÊSÉÉÊBÉEiºÉÉ +ÉÉÊvÉBÉEÉ®ÉÒ uÉ®É VÉÉÆSÉ BÉEÉÒ VÉÉAMÉÉÒ *
(ii) ÉÊxÉ®ÉÒFÉhÉ +ÉÉè® VÉÉÆSÉ, VÉcÉÆ BÉEcÉÓ +É{ÉäÉÊFÉiÉ cÉä, BÉEä {É¶SÉÉiÉÂÂ ºÉÆ¤ÉÆÉÊvÉiÉ BÉE®ÆiÉÉÒxÉ ªÉÉ {É¶ÉÖÉÊSÉÉÊBÉEiºÉÉ |ÉÉÉÊvÉBÉEÉ®ÉÒ £ÉÉ®iÉ àÉå {É¶ÉÖvÉxÉ =i{ÉÉn BÉEä |É´Éä¶É
BÉEä ÉÊãÉA BÉE®ÆiÉÉÒxÉ ºÉÆ¤ÉÆvÉÉÒ +ÉxÉÉ{ÉÉÊkÉ |ÉàÉÉhÉ {ÉjÉ |ÉnÉxÉ BÉE®äMÉÉ +ÉlÉ´ÉÉ, VÉxÉÉÊciÉ àÉå ªÉÉÊn +É{ÉäÉÊFÉiÉ cÉä, iÉÉä àÉÚãÉ nä¶É àÉå =ºÉä xÉ−] BÉE®xÉä ªÉÉ =ºÉBÉEÉÒ
´ÉÉ{ÉºÉÉÒ BÉEÉ +ÉÉnä¶É näMÉÉ *
(iii) VÉcÉÆ BÉEcÉÓ {É¶ÉÖvÉxÉ =i{ÉÉn BÉEä ¤ÉÉ® àÉå ÉÊ´ÉºÉÆµÉEàÉhÉ ªÉÉ BÉEÉä<Ç +ÉxªÉ ={ÉSÉÉ® +É{ÉäÉÊFÉiÉ ºÉàÉZÉÉ VÉÉiÉÉ cè ´ÉcÉÆ +ÉÉªÉÉiÉBÉEiÉÉÇ ºÉàªÉBÉEÂÂ °ô{É ºÉä
|ÉÉÉÊvÉBÉßEiÉ BÉE®ÆiÉÉÒxÉ ªÉÉ {É¶ÉÖÉÊSÉÉÊBÉEiºÉÉ +ÉÉÊvÉBÉEÉ®ÉÒ BÉEÉÒ näJÉ-®äJÉ àÉå {É¶ÉÖ{ÉÉãÉxÉ, bäªÉ®ÉÒ +ÉÉè® àÉiºªÉBÉEÉÒ ÉÊ´É£ÉÉMÉ uÉ®É +ÉxÉÖàÉÉäÉÊniÉ ÉÊBÉEºÉÉÒ +ÉÉÊ£ÉBÉE®hÉ BÉEä
àÉÉvªÉàÉ ºÉä +É{ÉxÉä º´ÉªÉÆ BÉEä ªÉÉ =ºÉBÉEä JÉSÉæ {É® {É®äÉÊ−ÉiÉ àÉÉãÉ BÉEÉä ÉÊ´ÉºÉÆµÉEàÉhÉ +ÉlÉ´ÉÉ +ÉxªÉ ={ÉSÉÉ® BÉEÉÒ BªÉ´ÉºlÉÉ BÉE®äMÉÉ *

(6)

+ÉÉªÉÉiÉBÉEiÉÉÇ BÉEÉ ªÉc nÉÉÊªÉi´É cÉäMÉÉ ÉÊBÉE ´Éc -

(BÉE)

{É¶ÉÖvÉxÉ =i{ÉÉn BÉEÉä ºÉÆ¤ÉÆÉÊvÉiÉ {É¶ÉÖ BÉE®ÆiÉÉÒxÉ +ÉÉè® |ÉàÉÉhÉÉÒBÉE®hÉ ºÉä´ÉÉ BÉEäxp àÉå ªÉÉ BÉE®ÆiÉÉÒxÉ ªÉÉ {É¶ÉÖÉÊSÉÉÊBÉEiºÉÉ +ÉÉÊvÉBÉEÉ®ÉÒ uÉ®É ªÉlÉÉÉÊxÉnäÉÊ¶ÉiÉ =ºÉBÉEÉÒ
+ÉÉä® ºÉä ºÉàªÉBÉEÂÂ °ô{É ºÉä |ÉÉÉÊvÉBÉßEiÉ ÉÊxÉ®ÉÒFÉhÉ, ÉÊ´ÉºÉÆµÉEàÉhÉ ªÉÉ ={ÉSÉÉ® +ÉlÉ´ÉÉ VÉÉÆSÉ ºÉÆ¤ÉÆvÉÉÒ ºlÉÉxÉ {É® ãÉÉA ;

(JÉ)

{É®äÉÊ−ÉiÉ àÉÉãÉ BÉEÉä JÉÉäãÉä, {ÉÖxÉ& {ÉèBÉE BÉE®ä +ÉÉè® {É¶ÉÖ BÉE®ÆiÉÉÒxÉ BÉEäxp àÉå ãÉÉnä ªÉÉ ´ÉcÉÒ =ºÉä JÉÉãÉÉÒ BÉE®ä iÉlÉÉ =ºÉ {É® àÉÖc® ãÉMÉÉA ; +ÉÉè®

(MÉ) ÉÊ´É£ÉÉMÉ uÉ®É ºÉàªÉBÉEÂÂ °ô{É ºÉä |ÉÉÉÊvÉBÉßEiÉ {É¶ÉÖ BÉE®ÆiÉÉÒxÉ ªÉÉ {É¶ÉÖÉÊSÉÉÊBÉEiºÉÉ +ÉÉÊvÉBÉEÉ®ÉÒ BÉEä ÉÊxÉnä¶ÉÉå BÉEä +ÉxÉÖºÉÉ® ÉÊxÉ®ÉÒFÉhÉ iÉlÉÉ ={ÉSÉÉ® ªÉÉ VÉÉÆSÉ BÉEä
¤ÉÉn =ºÉä c]ÉAÆ *
(7)

BÉEäxpÉÒªÉ ºÉ®BÉEÉ®, ãÉÉäBÉE ÉÊciÉ àÉå, ÉÊBÉEºÉÉÒ £ÉÉÒ {É¶ÉÖvÉxÉ =i{ÉÉn BÉEä +ÉÉªÉÉiÉ ºÉä ºÉÆ¤ÉÆÉÊvÉiÉ +ÉxÉÖàÉÉÊiÉ |ÉnÉxÉ BÉE®xÉä BÉEä ¤ÉÉ®ä àÉå +ÉxÉÖºÉÚSÉÉÒ BÉEä +ÉvÉÉÒxÉ
ÉÊ´ÉÉÊxÉÉÌn−] ÉÊBÉExcÉÓ ¶ÉiÉÉç ºÉä, UÚ] |ÉnÉxÉ BÉE® ºÉBÉEäMÉÉÒ *

|É°ô{É BÉE
BªÉÉÎBÉDiÉMÉiÉ ={É£ÉÉäMÉ BÉEä ÉÊãÉA {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ cäiÉÖ {É®ÉÊàÉ] BÉEä ÉÊãÉA +ÉÉ´ÉänxÉ
ºÉä´ÉÉ àÉå,
ºÉÆªÉÖBÉDiÉ ºÉÉÊSÉ´É,
BªÉÉ{ÉÉ® |É£ÉÉMÉ,
{É¶ÉÖ{ÉÉãÉxÉ +ÉÉè® bäªÉ®ÉÒ ÉÊ´É£ÉÉMÉ,
BÉßEÉÊ−É àÉÆjÉÉãÉªÉ,
£ÉÉ®iÉ ºÉ®BÉEÉ®, BÉßEÉÊ−É £É´ÉxÉ,
xÉ<Ç ÉÊnããÉÉÒ-110001
+ÉvÉÉäcºiÉÉFÉ®ÉÒ, xÉÉÒSÉä ÉÊnA MÉA ¤ªÉÉè®Éå BÉEä +ÉxÉÖºÉÉ® {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ BÉEÉä |ÉÉÉÊvÉBÉßEiÉ BÉE®xÉä ´ÉÉãÉä {É®ÉÊàÉ] BÉEä ÉÊãÉA +ÉÉ´ÉänxÉ BÉE®iÉÉ cè :-

(BÉßE{ÉªÉÉ º{É−] +ÉFÉ®Éå àÉå ÉÊãÉJÉå/]É<{É BÉE®å)

<!-- page 5 -->

¹HkkxIIµ[k.M3(ii)º

1.
2.
3.
4.
5.
6.
7.
8.
9.

Hkkjr dk jkti=k % vlk/kj.k

5

+ÉÉªÉÉiÉ ÉÊBÉEA VÉÉxÉä ´ÉÉãÉä {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEÉ xÉÉàÉ +ÉÉè® ºÉcÉÒ ÉÊ´É´É®hÉ :
{É®äÉÊ−ÉiÉ àÉÉãÉ BÉEÉ ÉÊ´É´É®hÉ iÉlÉÉ =ºÉBÉEÉÒ àÉÉjÉÉ :
{É®ä−ÉBÉE BÉEÉ xÉÉàÉ +ÉÉè® {ÉiÉÉ :
+ÉÉªÉÉiÉBÉEiÉÉÇ BÉEÉ xÉÉàÉ +ÉÉè® {ÉiÉÉ :
nä¶É +ÉÉè® ºlÉÉxÉ VÉcÉÆ ºÉä =i{ÉÉn ÉÊBÉEªÉÉ VÉÉiÉÉ cè :
nä¶É VÉcÉÆ ºÉä £ÉÉ®iÉ àÉå +ÉÉªÉÉiÉ ÉÊBÉEªÉÉ VÉÉiÉÉ cè :
VÉcÉVÉ {É® àÉÉãÉ SÉfÃÉxÉä ´ÉÉãÉä ÉÊ´Énä¶É {ÉkÉxÉ :
£ÉÉ®iÉ àÉå {É®ä−ÉhÉ àÉÉãÉ BÉEä +ÉÉMÉàÉxÉ BÉEÉÒ +ÉxÉÖàÉÉÉÊxÉiÉ ÉÊiÉÉÊlÉ :
£ÉÉ®iÉ àÉå |É´Éä¶É BÉEä ºlÉÉxÉ BÉEÉ xÉÉàÉ (ÉÊ´ÉàÉÉxÉ{ÉkÉxÉ/ ¤ÉÆn®MÉÉc / ºlÉãÉ =i{ÉÉn ¶ÉÖãBÉE BÉEäxp*)

PÉÉä−ÉhÉÉ :àÉé PÉÉä−ÉhÉÉ BÉE®iÉÉ cÚÆ ÉÊBÉE nÉÒ MÉ<Ç ºÉÚSÉxÉÉ àÉä®ä ºÉ´ÉÉækÉàÉ YÉÉxÉ +ÉÉè® ÉÊ´É¶´ÉÉºÉ àÉå ºÉcÉÒ cè *
àÉé <ºÉàÉå +ÉÉ´ÉäÉÊniÉ º´ÉSUiÉÉ +ÉÉªÉÉiÉ {É®ÉÊàÉ] àÉå ªÉlÉÉ ÉÊ´ÉÉÊxÉÉÌn−] ºÉ£ÉÉÒ BÉEÉMÉVÉ{ÉjÉÉå iÉlÉÉ |ÉàÉÉhÉ{ÉjÉÉå BÉEÉä, ªÉÉÊn BÉEÉä<Ç cÉå, |ÉºiÉÖiÉ BÉE®xÉä BÉEÉ
´ÉSÉxÉ näiÉÉ cÚÆ *
+ÉÉªÉÉiÉBÉEiÉÉÇ ªÉÉ =ºÉBÉEä |ÉÉÉÊvÉBÉßEiÉ +ÉÉÊ£ÉBÉEiÉÉÇ BÉEä cºiÉÉFÉ®
xÉÉàÉ :
bÉBÉE BÉEÉ {ÉiÉÉ :
ºlÉÉxÉ :iÉÉ®ÉÒJÉ :*VÉÉä ãÉÉMÉÚ xÉcÉÓ cÉä, =ºÉä BÉEÉ] nå *
|ÉÉ°ô{É JÉ
BªÉÉ{ÉÉ® +ÉÉè® ÉÊ´É{ÉhÉxÉ BÉEä ÉÊãÉA {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ cäiÉÖ {É®ÉÊàÉ] BÉEä ÉÊãÉA +ÉÉ´ÉänxÉ
ºÉä´ÉÉ àÉå,
ºÉÆªÉÖBÉDiÉ ºÉÉÊSÉ´É,
BªÉÉ{ÉÉ® |É£ÉÉMÉ,
{É¶ÉÖ{ÉÉãÉxÉ +ÉÉè® bäªÉ®ÉÒ ÉÊ´É£ÉÉMÉ,
BÉßEÉÊ−É àÉÆjÉÉãÉªÉ,
£ÉÉ®iÉ ºÉ®BÉEÉ®, BÉßEÉÊ−É £É´ÉxÉ,
xÉ<Ç ÉÊnããÉÉÒ-110001
+ÉvÉÉäcºiÉÉFÉ®ÉÒ, xÉÉÒSÉä ÉÊnA MÉA ¤ªÉÉè®ä BÉEä +ÉxÉÖºÉÉ® {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä +ÉÉªÉÉiÉ BÉEÉä |ÉÉÉÊvÉBÉßEiÉ BÉE®xÉä ´ÉÉãÉä {É®ÉÊàÉ] BÉEä ÉÊãÉA +ÉÉ´ÉänxÉ BÉE®iÉÉ cè :1.

+ÉÉªÉÉiÉBÉEiÉÉÇ BÉEÉ xÉÉàÉ +ÉÉè® {ÉiÉÉ

2.
µÉEàÉ
ºÉÆ.

1

£ÉÉ®iÉÉÒªÉ
BªÉÉ{ÉÉ®
´ÉMÉÉÔBÉE®hÉ =ºÉ {É¶ÉÖvÉxÉ BÉEä ¤ªÉÉè®ä ÉÊVÉºÉºÉä =ºÉä
(cÉàÉÉæxÉÉ<Vb |ÉhÉÉãÉÉÒ) BÉEä +ÉxÉÖºÉÉ® =i{ÉÉÉÊniÉ ÉÊBÉEªÉÉ MÉªÉÉ cè
{É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEÉ ºÉcÉÒ ÉÊ´É´É®hÉ
2

3

àÉÉjÉÉ
{ÉèBÉEä]Éå BÉEÉÒ
ºÉÆJªÉÉ

BÉÖEãÉ £ÉÉ®
+ÉÉªÉiÉxÉ

4(BÉE)

4(JÉ)

/

3. +ÉÉªÉÉiÉ BÉEÉÒ VÉÉxÉä ´ÉÉãÉÉÒ {É¶ÉÖvÉxÉ =i{ÉÉnÉå/ ºÉÉàÉOÉÉÒ BÉEÉÒ {ÉcSÉÉxÉ ºlÉÉÉÊ{ÉiÉ BÉE®xÉä ´ÉÉãÉä {É¶ÉÖvÉxÉ =i{ÉÉnÉå BÉEä =i{ÉÉnBÉE BÉEÉ BÉEè]äãÉÉìMÉ :
4. =i{ÉÉnBÉE BÉEÉ xÉÉàÉ +ÉÉè® {ÉiÉÉ :
5. {É®ä−ÉBÉE BÉEÉ xÉÉàÉ +ÉÉè® {ÉiÉÉ :
6. ´Éc nä¶É +ÉÉè® ºlÉÉxÉ VÉcÉÆ {É¶ÉÖvÉxÉ =i{ÉÉn BÉEÉ =i{ÉÉnxÉ ÉÊBÉEªÉÉ VÉÉiÉÉ cè :
7. ´Éc nä¶É VÉcÉÆ £ÉÉ®iÉ àÉå +ÉÉªÉÉiÉ ÉÊBÉEªÉÉ VÉÉiÉÉ cè :

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

8. VÉcÉVÉ {É® àÉÉãÉ SÉfÃÉxÉä ´ÉÉãÉÉ ÉÊ´Énä¶ÉÉÒ {ÉkÉxÉ
9. c´ÉÉ<Ç +ÉbÂbÉ/ ºÉàÉÖpÉÒ {ÉkÉxÉ/ ºlÉãÉ ºÉÉÒàÉÉ¶ÉÖãBÉE BÉEäxp BÉEÉ xÉÉàÉ (|É´Éä¶É ºlÉÉxÉ) :
PÉÉä−ÉhÉÉ :àÉé PÉÉä−ÉhÉÉ BÉE®iÉÉ cÚÆ ÉÊBÉE nÉÒ MÉ<Ç ºÉÚSÉxÉÉ àÉä®ä ºÉ´ÉÉækÉàÉ YÉÉxÉ +ÉÉè® ÉÊ´É¶´ÉÉºÉ àÉå ºÉcÉÒ cè *
àÉé =xÉ ¶ÉÉºÉBÉEÉÒªÉ nºiÉÉ´ÉäVÉÉå ªÉÉ |ÉàÉÉhÉ{ÉjÉ BÉEÉä, VÉÉä º´ÉSUiÉÉ +ÉÉªÉÉiÉ +ÉxÉÖàÉÉÊiÉ àÉå ÉÊ´ÉÉÊxÉÉÌn−] ÉÊBÉEªÉÉ VÉÉA, |ÉºiÉÖiÉ BÉE®xÉä BÉEÉ ´ÉSÉxÉ näiÉÉ cÚÆ *
+ÉÉªÉÉiÉBÉEiÉÉÇ ªÉÉ =ºÉBÉEä |ÉÉÉÊvÉBÉßEiÉ +ÉÉÊ£ÉBÉEiÉÉÇ BÉEä cºiÉÉFÉ®
xÉÉàÉ :
bÉBÉE BÉEÉ {ÉiÉÉ :
ºlÉÉxÉ :
iÉÉ®ÉÒJÉ :
[{ÉEÉ.ºÉÆ.110-2/2013-BªÉÉ{ÉÉ®]
®ÉVÉ¤ÉÉÒ® ÉËºÉc ®ÉhÉÉ, ºÉÆªÉÖBÉDiÉ ºÉÉÊSÉ´É
ÉÊ]{{ÉhÉ

: àÉÚãÉ +ÉÉÊvÉºÉÚSÉxÉÉ £ÉÉ®iÉ BÉEä ®ÉVÉ{ÉjÉ àÉå BÉEÉ.+ÉÉ.655(+É) iÉÉ®ÉÒJÉ 7 VÉÖãÉÉ<Ç, 2001 uÉ®É |ÉBÉEÉÉÊ¶ÉiÉ BÉEÉÒ MÉ<Ç lÉÉÒ +ÉÉè® +ÉÉÊvÉºÉÚSÉxÉÉ
ºÉÆ. BÉEÉ.+ÉÉ.351(+É) iÉÉ®ÉÒJÉ 8 {ÉE®´É®ÉÒ, 2013 uÉ®É =ºÉBÉEÉ +ÉÆÉÊiÉàÉ ºÉÆ¶ÉÉävÉxÉ ÉÊBÉEªÉÉ MÉªÉÉ lÉÉ *

MINISTRY OF AGRICULTURE
(Department of Animal Husbandry and Dairying and Fisheries)
NOTIFICATION
New Delhi, the 16th October, 2014
S.O. 2666(E).—In exercise of the powers conferred by clause (d) of section 2 and section 3A of the Live-stock
Importation Act, 1898 (9 of 1898) and in supersession of notification S.O. 655(E) dated the 07th July,2001, except as
respects things done or omitted to be done before such supersession, the Central Government hereby notifies the “livestock products” and procedure for the issue of sanitary import permit for import of such products as follows:1. The word “live-stock products” shall include the following products, namely:(i)
Meat and meat products of all kinds including fresh, chilled and frozen meat of poultry, sheep, goat and pig;
(ii) Tissue or organs of poultry, sheep, goat and pig;
(iii) Egg and egg powder;
(iv) Milk and milk products;
(v) Bovine, ovine and caprine embryos, ova or semen;
(vi) Pet food products of animal origin;
(vii) Eggs and seeds of all aquatic animals including fish, crustaceans and molluscs;
(viii) Bristles and hair of pigs hogs or boars; waste of pigs; hogs or boars bristles and hair; badge hair and other
brush making hair; yak tail hair; brush making hair; whale bone hair; Bones and bone products including horn
cores, crushed bones; Bone grist; ossein; horn cones and part thereof not crusted; bone meal; hoof meal; horn meal;
hornes, hooves, claws, nails and beaks unworked or simply prepared (but not cut to shape); antlers; ox gallstones;
and frozen placenta; obtained from bovine, sheep, goat, poultry and pig and any other animals as the case may be;
(ix) Raw skins and other parts of birds, with their feathers or down, feathers and parts of feathers (whether or not
trimmed edges) and down;
(x)Raw hides and skins of bovine (including buffalo) or equine animals, sheep or lamb, other raw skins (skins of
goats, swine), fresh or salted dried, limed, pickled, or otherwise preserved but not tanned, parchment-dressed or
further prepared, whether or not de-haired or split with wool on or split;

<!-- page 7 -->

¹HkkxIIµ[k.M3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

(xi) Raw furskins (including heads, tails, paws and other pieces or cuttings, suitable for furriers use);
(xii) Badminton shuttle cock, feather meal and powder made from birds feather;
(xiii) Serum; and plasma of animals like bovine, goat, sheep, horse, poultry, pig, rabbit, mice, rat, dog and cat;
(xiv) Animal feed and fish feed containing milk and milk products of bovine, ovine, caprine, meat and meat
products, tissues, organs of poultry, pig, sheep, goat, fish and fish products;
(xv) Horsehair and horsehair waste, whether or not put up as a layer with or without supporting material;
(xvi) Coral and similar materials, un-worked or simply prepared but not otherwise worked, shells of molluscs,
crustaceans or echinoderms and cuttle bone, un-worked or simply prepared but not cut to shape, powder and waste
thereof;
(xvii) Medicaments (bovine albumin and drug of animal origin) and diagnostics (containing blood or serum fractions
for in vitro application);
(xviii) Gelatine (including gelatine in rectangular or square) sheets, whether or not surface worked or coloured and
gelatine derivatives, isinglass; other glues of animal origin; excluding casein glues;
(xix) Tanned or curst hides and skins of bovine (including buffalo) or equine animals, without hair on, whether or
not split, but not further prepared;
(xx) Tanned or curst hides and skins of sheep or lamb without wool on, whether or not split, but not further
prepared, tanned or curst hides and skins of other animals, without wool or hair on, whether or not split, but not
further prepared (of goat, swine, reptile, etc.);
(xxi) Leather further prepared after tanning or crusting, including parchment dressed leather, of bovine (including
buffalo) or equine animals without hair on, whether or not split. Leather further prepared after tanning or crusting,
including parchment dressed leather, of sheep or lamb without wool on, whether or not split, leather further prepared
after tanning of crusting, including parchment dressed leather of other animals, without wool or hair on, whether or
not split (of goat, swine, reptile, etc.);
(xxii) Chamois (including combination chamois) leather, patent leather and patent laminated leather, metalised
leather;
(xxiii) Composition of leather with a basis of leather or leather fiber, in slabs, sheets or strips, whether or not in rolls,
parings and other waste of leather or of composition leather, not suitable for manufacture of leather articles, leather
dust powder and flour;
(xxiv) Tanned or dressed furskins (including head, tails, paws and other pieces or cuttings) unassembled, or
assembled (with or without the addition of other materials);
(xxv) Wool not carded or combed, fine or coarse animal hair not carded or combed, waste or wool or of fine or
coarse animal hair including yarn waste excluding gamete stock;
(xxvi) Saddlery and harness of any animal of any material, trunks, suitcases, vanity cases, brief cases, sachet,
pouches, hand bags etc.;
(xxvii) Articles of apparel and clothing accessories of leatheries, of leather or of composition leather, articles of
leather or of composition leather of a kind in machinery or mechanical appliances or for other technical uses;
(xxviii) Other articles of leather or of composition leather (straps, welt, covers) articles of apparel, clothing
accessories and other articles of furskin;

7

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(xxix) Articles of gut of gold beater’s skin, of bladders, of tendons, articles of apparel, clothing accessories and other
articles of furskin, artificial fur and articles thereof;
(xxx) Garneted stock of wool or of fine or coarse animal hair, wool and fine or coarse animal hair, carded or combed
(including combed wool in fragments), yarn of carded wool not put up for retail sale yarn of combed wool not put up
for retail sale, yarn of fine animal hair (carded or combed) not put up for retail sale, yarn of wool or of fine animal
hair put for retail sale, yarn of coarse animal hair or of horse hair (including gimped horsehair yarn whether or not put
up for retail sale), woven fabrics of carded wool or carded fine animal hair, woven fabrics of combed wool or carded
fine animal hair, woven fabrics of coarse animal hair or of horse hair.
2. The import of these products shall be allowed only against a sanitary import permit to be issued by this Department as
per the procedure laid down in the Schedule annexed to this notification.
3. This notification shall come into force on the date of its publication in the Official Gazette.
SCHEDULE
(see para 2)
Procedure for import of livestock products into India
All live-stock products shall be imported into India subject to the following conditions, namely:(1) No live-stock product shall be imported into India without a valid sanitary import permit issued under clause (3).
(2) All applications for a permit to import consignments by land, air or sea shall be made in either Form A or Form B,
whichever is relevant, and sent in triplicate to the Joint Secretary, Trade Division, Department of Animal Husbandry,
Dairying and Fisheries, Ministry of Agriculture, Government of India.
(3) (i) The sanitary import permit shall be issued for import of livestock products if, after a detailed import risk analysis,
the concerned authorities are satisfied that the import of the consignment will not adversely affect the health of the
animal and human populations of this country.
(ii) The import risk analysis shall be conducted by the concerned officers of the Department on the basis of
internationally recognised scientific principles of risk analysis and the analysis shall be conducted with reference to
the specific product and the disease situation prevailing in the exporting country vis-a-vis the disease situation in
India.
(iii) The issue of permits shall be refused if the results of the import risk analysis show that there is a risk of the
specific product bringing in one or more specific diseases, which are not prevalent in the country and which could
adversely affect the health and safety of the human and animal populations of this country.
(iv) The import permit shall lay down the specific conditions that will have to be fulfilled in respect of the
consignment, including pre-shipment certifications and quarantine checks.
(v) The permit shall also specify the post-import requirements with regard to quarantine inspections, sampling and
testing.
(vi) The Sanitary Import Permit shall be valid for a period of one year for import of processed livestock products
such as heat treated milk and milk products, fishery products, meat products of poultry, pig, sheep and goat, pet
food, processed pig bristles and processed feather.
Provided that validity of permit issued for import of unprocessed livestock products shall be valid for six months
but may be extended by the Central Government for a further period of six months, on request from the importer
and for reasons to be recorded in writing.
(vii) Sanitary Import Permit will not be required for the livestock products listed at sl. no. (XV) to (XXIV) above.
However, import of livestock products indicated at sl. no. (XV) to (XXIV) will be regulated against the production
of No Objection Certificate from the Officer-In-Charge of the Animal Quarantine and Certification Services
Stations located at Delhi, Mumbai, Chennai and Kolkata or any other veterinary officer duly authorized by the
Department of Animal Husbandry, Dairying and Fisheries after inspection of the goods.

<!-- page 9 -->

¹HkkxIIµ[k.M3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

9

(viii) Further, import of livestock products indicated at sl. No. (XXV) to (XXX) neither sanitary import permit nor
no objection certificate of the concerned Quarantine Officer will be required.
(4) All livestock products shall be imported into India through the seaports or airports located at Delhi, Mumbai,
Kolkata, Chennai, Bangalore and Hyderabad where the Animal Quarantine and Certification Services Stations are
located.
Provided that the import of aquatic products, eggs, seeds, of all aquatic animals including fish, crustaceans,
molluscs, the import shall also be allowed through the sea ports or airports located at Visakhapatnam and Kochi.
Provided further that in case of import of perishable fish items exclusively meant for human consumption but
excluding seed material for breeding or rearing purposes, the import shall be allowed to land at Petrapole, District
North 24 Paraganas, West Bengal, through land route.
(5) (i) On arrival at the entry point, the livestock product shall be inspected by the Officer-in-charge of the Animal
Quarantine and Certification Services Station or any other veterinary officer duly authorised by the Department of
Animal Husbandry, Dairying and Fisheries, wherever required, in accordance with the specific conditions laid
down in the sanitary import permit and with general guidelines issued by the Department of Animal Husbandry,
Dairying and Fisheries from time to time.
(ii) After inspection and testing, wherever required, the concerned quarantine or veterinary authority shall accord
quarantine clearance for the entry of the livestock product into India or, if required in public interest, order its
destruction or its return to the country of origin.
(iii) Wherever disinfection or any other treatment is considered necessary in respect of any livestock product, the
importer shall, on his own or at his cost through an agency approved by the Department of Animal Husbandry,
Dairying and Fisheries, arrange for disinfection or other treatment of the consignment, under the supervision of a duly
authorised quarantine or veterinary officer.
(6) It shall be the responsibility of the importer (a) to bring the livestock product to the concerned Animal Quarantine and Certification Services Station, or to the place
of inspection, disinfection or treatment or testing as directed by the Quarantine or veterinary officer duly authorized on
his behalf;
(b) to open, repack and load into or unload from the Animal Quarantine Station and seal the consignment; and
(c) to remove them after inspection and treatment or testing, according to the directions of the Quarantine or veterinary
officer duly authorized by the Department.

(7) The Central Government may, in public interest, relax any of the conditions specified under this Schedule relating to
the permit in relation to the import of any live-stock product.

FORM A
APPLICATION FOR PERMIT TO IMPORT LIVE-STOCK PRODUCTS FOR PERSONAL CONSUMPTION
To
The Joint Secretary
Trade Division,
Department of Animal Husbandry and Dairying,
Ministry of Agriculture,
Government of India
Krishi Bhawan,
New Delhi – 110001

The undersigned hereby applies for a permit authorizing the import of live-stock products as
per details given below —

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(Please write or type in block letters)
1. Name and exact description of live-stock products to be imported:
2. Description of the consignment and quantity:
3. Name and address of the consignor:
4. Name and address of the importer:
5. Country and locality in which produced:
6. Country from which imported into India:
7. Foreign port of shipment:
8. Approximate date of arrival of the consignment in India:
9. Name of (airport/seaport/land customs station*) point of entry in India:
DECLARATION
I declare that the information furnished is correct to the best of my knowledge and belief.
I undertake to produce all documents and certificates, if any, as specified in the sanitary
import permit applied for herein.

Signature of the importer or his authorized agent.
Name:
Postal address :
Place:
Date:
* strike out whichever is not applicable.
Form B
APPLICATION FOR PERMIT TO IMPORT LIVE-STOCK PRODUCTS FOR TRADING AND MARKETING
To
The Joint Secretary
Trade Division,
Department of Animal Husbandry and Dairying,
Ministry of Agriculture,
Government of India
Krishi Bhawan,
New Delhi – 110001

The undersigned hereby applies for a permit authorizing the import of live-stock products as
per details given below –
1. Name and address of the importer:
2.
S. No.

1

Exact description of livestock products
with Indian Trade Classification
(Harmonized System)

Details of livestock
from whom it is
produced

2

3

Quantity
Number of
packages

4(a)

Total
weight/volume

4(b)

3. Catalogue of livestock products producer establishing identity of the livestock products/ material to be imported:
4. Name and address of the producer:

<!-- page 11 -->

¹HkkxIIµ[k.M3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

11

5. Name and address of consignor:
6. Country and locality in which livestock products produced:
7. Country from which imported into India:
8. Foreign port of shipment:
9. Name of airport/seaport/land customs station (entry point);

Declaration:
I declare that the information furnished is correct to the best of my knowledge and belief. I undertake to produce any official
document or certificate as may be specified in the sanitary import permission.
Signature of the importer or his authorized agent
Name :
Postal address :
Place:
Date:
[F. No. 110-2/2013-Trade]
RAJBIR SINGH, Rana, Jt. Secy.
Note : The principal notification was published in the Gazette of India vide S.O. 655(E) dated the 7th July, 2001 and it was
last amended vide notification S.O. 351(E) dated the 8th February, 2013.

Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
