---
doc_id: "ac25005c0b2cacde"
source_url: "https://www.dahd.gov.in/static/uploads/2025/06/69c72c7f6f2b598a9be34832b5f550b6.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Amendment Notification S.O. 2825 (E), dated 14 July 2021 regarding import of pet dog or pet cat through Cochin"
date: "2021-07-16"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0421634e0a9f4294"
---

<!-- page 1 -->

F. No: 109-01/2012-Trade (Computer No: 17748)

l{r{dgrdR

Government of lndia
q7rf,q
q{qrfi 3irt
qRFI,
qNI
Dairying
Ministry of Fisheries, Animal Husbandry and

ffi

q{qril{ siRffiEttFI

Department oiAnimal Husbandry and Dairying

pErrfl{, r{frd-tto oot,

Krishi Bhawan, New Delhi-110 001'
frri6 / Dated the 16th JulY, 2021'

offi ce Memq ra ndum
2021 under the LiveSubject: - Notification S.o. 2825 (E-), dated 14th July'
stock lmPortation Act, 1898'reg'
Notification S-O

The undersigned is directed to enclose a copy of the
tmportation. Act, 18e8
zazs tljlo"i";';;i,i-jr[ ;ozi- unoer the Live-stockthe applicable baggage
a pet dog or pet cat as permitted under
lnternational Airport'
""tityiig'ihit
rules shall be allowed to [" i'po't"'O through Cochin
Cochin till 30th SePtember, 2021

Enclosure: As above.

1-4^ fiftvy.zr
igrrrnrntl

(Dr. Gagan Garg)

sdrfm.efrgffi@rqR)
Assistant Commissioner (Trade)
Email: gagan garg@nic in

Distribution:

-

All Regional

Certification Services'

Officers, Animal Quarantine
Officers
-O"fni- / Quarantine
/

I Mumbai / Bangaluru / Chennai / Kolkata

Hyderabad.
Copy for kind information to;

1) Secretary, Department of Commerce' Ministry of .Commerce

&

" i"dr;t*;, Udyog Bhawan, New Delhi Email: csofiice@nic'in
Ministry oi Externat Affairs' South Block' NerruJel-'1..'y:.t!^"
2)
-' Secretary,
,iir"rt io disseminate the information abroad Email: psfs@mea.gov.rn
.

3) Secretary, Ministry "i-C*if Aviation' Rajiv Gandhi Bhawan'

Block B'

secy moca@nic in
Safdarjung Airport Area, New Delhi-1 10003' Email:
Bhawan'
4) Director General, Directorate General of Foreign Trade' Udyog
New Delhi. Email: dgft@nic in
lndirect Taxes & Customs'
sl io-ini SlCretary (Cuitois), Central Board ofDelhi
Email: iscus@nic'in
blfrrtrnent of n"renu", North Block, New

-'

Contd....

<!-- page 2 -->

-2-

6)Commissioner,singleWindowProiect,CentralBoardoflndirectTaxes

Delhi-1 10
& Customs, Department of Revenui, Ministry of Finance' New
00'1. Email: mgt.valavan@nic.in
G.t"i"ry, Depirtment of Commerce, Udyog Bhawan' New

A D6rh/

oeini - I l0 001. E-mail : d2tpd-doc@nic.in
8)' Managing Director, Cochin lnte]national Airport'. Cochin- 683111
(feraia).-email: cial@vsnl.com, pro@cial'aero' dk@cial'aero
9) All AQCSs to disseminate the information'
rcil rlri, DAHD with a request to upload on the Department and AQCS's
website.
Copy also for kind information to;

,t)PStotheHon'bleMinisterforFisheries,AnimalHusbandryandDairying.
zi pi i" ine Hon'ute Minister of State for Fisheries, Animal Husbandry and
Dairying (SKB).
3) Sr. PPS to the Secretary, AHD.
4) PS to the JS (GNS).

<!-- page 3 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-14072021-228300
xxxGIDHxxx
CG-DL-E-14072021-228300
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 2620]
No. 2620]

नई ददल्ली, बुधिार, िुलाई 14, 2021/आिाढ़ 23, 1943
NEW DELHI, WEDNESDAY, JULY 14, 2021/ASHADHA 23, 1943

मत्सस्ट्यपालन, पिुपालन और डेयरी मंत्रालय
(पिुपालन और डेयरी जिभाग)
अजधसूचना
नई ददल्ली, 14 िुलाई, 2021
का.आ. 2825(अ).—कें द्रीय सरकार, पिुधन आयात अजधजनयम, 1898 (1898 का 9) की धारा 3 द्वारा प्रदत्सत
िज‍तयक का प्रय ग करते एए, ददनांक 11 िून, 2014 क भारत के रािपत्र, असाधारण, भाग-II, खण्ड 3, उप-खण्ड (ii) में
प्रकाजित भारत सरकार, कृ जि मंत्रालय, पिुपालन, डेयरी और मत्सस्ट्यपालन जिभाग सं्‍या का.आ. 1495(अ) की
अजधसूचना में जनम्नजलजखत और संि धन करती है, अथाात,्
उ‍त अजधसूचना की अनुसूची में, पैरा 1 में परं तुक के स्ट्थान पर जनम्नजलजखत परं तुक रखा िाएगा, अथाात:् ,“परं तु लागू सामान जनयमक के अधीन यथा अनुमत्सय पालतू कु त्सते या पालतू जबल्ली क 30 जसतंबर, 2021 तक
क चीन अंतरााष्‍टरीय हिाई अड्डे, क चीन के माध्यम से आयात की अनुज्ञा दी िाएगी।”
[फा. सं. 109-01/2012-व्यापार (ई-17748]
जगरिा नन्द ससह, संयु‍त सजचि
टिप्पण : मूल अजधसूचना भारत के रािपत्र, असाधारण, भाग-II, खण्ड-3, उप-खण्ड (ii) में तारीख 11 िून, 2014 की
अजधसूचना सं्‍या का.आ. 1495(अ) द्वारा प्रकाजित की गई थी और तत्सपश्चात् तारीख 06 निंबर, 2020 की
अजधसूचना सं्‍या का.आ. 4025 (अ) द्वारा संि जधत की गई थी।
3885 GI/2021

(1)

<!-- page 4 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF FISHERIES, ANIMAL HUSBANDRY AND DAIRYING
(Department of Animal Husbandry and Dairying)
NOTIFICATION
New Delhi, the 14th July, 2021
S.O. 2825(E).—In exercise of the powers conferred by section 3 of the Live-stock Importation
Act, 1898 (9 of 1898), the Central Government hereby makes the following further amendment in the
notification of the Government of India, in the Ministry of Agriculture, Department of Animal Husbandry,
Dairying and Fisheries, published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (ii),
vide number S.O. 1495 (E), dated the 11th June, 2014, namely:In the Schedule to the said notification, in paragraph 1, for the proviso, the following proviso shall
be substituted, namely:“Provided that a pet dog or pet cat as permitted under the applicable baggage rules shall be allowed
to be imported through Cochin International Airport, Cochin till 30th September, 2021.”.
[F. No. 109-01/2012-Trade (E-17748)]
GIRJA NAND SINGH, Jt. Secy.
Note : The principal notification was published in the Gazette of India, Extraordinary, Part II, Section 3,
Sub-section (ii), vide notification number S.O. 1495(E), dated 11th June, 2014 and subsequently
amended vide notification number S.O. 4025(E), dated the 6th November, 2020.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
signed by ALOK KUMAR
and Published by the Controller of Publications, Delhi-110054. ALOK KUMAR Digitally
Date: 2021.07.14 22:16:25 +05'30'
