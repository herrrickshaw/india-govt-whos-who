---
doc_id: "aaf69ae6baff5572"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/28509ebfc345c8d3d68966b4fa1317b9.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of ISP Authorizations under UL-VNO as on 30-09-2022"
date: "2022-09-30"
pages: 25
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "87fd9cef5f229f8e"
---

<!-- page 1 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

1

MFT Internet Pvt Ltd.

DS-11/352/2016-DS-III

B

Kolkata

2

MFT Internet Pvt Ltd.

DS-11/352/2016-DS-III

B

Bihar

3

Sistemos Information Technology Pvt
Ltd.

DS-11/280/2016-DS-III

B

4

Sistemos Information Technology Pvt
Ltd.

DS-11/280/2016-DS-III

5

Ometa Net Pvt Ltd.

DS-11/277/2016-DS-III

6

Ometa Net Pvt Ltd.

DS-11/277/2016-DS-III

7

Ometa Net Pvt Ltd.

DS-11/277/2016-DS-III

Authorized Person

Registered Office Address

Mr. Chandan Kumar
Singh
Mr. Chandan Kumar
Singh

No. 46/5, N.S. Road, Liluah, Howrah - 711
204, West Bengal.
No. 46/5, N.S. Road, Liluah, Howrah - 711
204, West Bengal.

Kolkata

Mr. Raktim Chatterjee,
Director

Purbachal, Tentultala, P.O.- R Gopalpur,
Kolkata, West Bengal -700 136

B

West Bengal

Mr. Raktim Chatterjee,
Director

C

Patiala

C

C

Contact No.
Mobile
9883306418
9883306418

Mail ID
admin@mathsformtech.c
om
admin@mathsformtech.c
om

Date of Signing UL

Effective Date

21-04-2017

21-04-2017

21-04-2017

21-04-2017

8336088561

raktim.chatterjee@gmail.
com

01-05-2017

01-05-2017

Purbachal, Tentultala, P.O.- R Gopalpur,
Kolkata, West Bengal -700 136

8336088561

raktim.chatterjee@gmail.
com

01-05-2017

01-05-2017

Mr. Dinesh Saini,
Director

Village Rampur Sainian, Tehsil Derabassi,
Distt. SAS Nagar, Punjab, PIN - 140 507

9915318469

dineshsaini619@gmail.c
om

03-05-2017

03-05-2017

Chandigarh

Mr. Dinesh Saini,
Director

Village Rampur Sainian, Tehsil Derabassi,
Distt. SAS Nagar, Punjab, PIN - 140 507

9915318469

dineshsaini619@gmail.c
om

03-05-2017

03-05-2017

Ambala

Mr. Dinesh Saini,
Director

Village Rampur Sainian, Tehsil Derabassi,
Distt. SAS Nagar, Punjab, PIN - 140 507

9915318469

dineshsaini619@gmail.c
om

03-05-2017

03-05-2017

Mr. Jainiti Prasad

No. 03, Top Floor, Plot No. 07, Vardhman
Jay Pee Plaza, MLU, Sector-4, Dwarka,
New Delhi - 110078

9555333948

jainiti.prasad@gmail.co
m

08-05-2017

08-05-2017

07-06-2017

07-06-2017

08-06-2017

08-06-2017

8

Powernet Communications Pvt Ltd.

DS-11/231/2016-DS-III

B

Delhi

9

Triple Play Broadband Service (India)
Pvt Ltd.

DS-11/98/2017-DS-III

B

Delhi

Mr. Jasvir Panwar

10

IPNET Communications Pvt Ltd.

DS-11/89/2017-DS-III

B

Delhi

Mr. Rahul Sharma

11

Doordrishti Network Pvt Ltd.

DS-11/92/2017-DS-III

B

Delhi

Mr. Ravinder Kumar

12

Softech Infosol Pvt Ltd.

DS-11/86/2017-DS-III

A

All India

Mr. Hardeep Sandhu

13

Kalchuri Consultancy Services Pvt
Ltd.

DS-11/351/2016-DS-III

B

Uttar Pradesh (East)

14

Esto Broadband Pvt Ltd.

DS-11/87/2017-DS-III

A

All India

238, Top Floor, Shahpur Jat, New Delhi 110 049.
H.No. 275, Masjid Moth, South Extension II, New Delhi - 110 049.
No. 162, T/F, L/S, Khirki Village, Malviya
Nagar, New Delhi -110 017.

23-06-2017

23-06-2017

Near Vishwakarma Chowk, Railway Road,
Gharaunda, Karnal - 132 114, Haryana.

9992222922

hardeepsandhug@gmail.
com

23-06-2017

23-06-2017

Mr. Ashish Rai

No. 239/1A, Rai Colony, Civil Lines,
Jhansi - 284001, Uttar Pradesh.

9451170582,
9453704804

30-06-2017

30-06-2017

Mr. Manish Kumar

Show Room No. 5, New Fauji Complex,
Sai Road, Baddi -173 205, H.P.

9218560000

info@estobroadband.in

04-07-2017

04-07-2017

9995802350

md@kingsbroadband.net
,
prathapchandrantvm@g
mail.com

10-07-2017

10-07-2017

8010009078

ashwani.naps@hotmail.c
om

10-07-2017

10-07-2017

9811458443

arun@logiceastern.co.in

12-07-2017

12-07-2017

8527027690

sanetwork2010@gmail.c
om

17-07-2017

17-07-2017

9255552025,
9034800010

deepak@sat.org.in

18-07-2017

18-07-2017

8130930729

gaurav@gssoft.in

27-07-2017

27-07-2017

9810001407

pramod.trivedi2011@gm
ail.com

16-08-2017

16-08-2017

deepak@gtel.in

16-08-2017

16-08-2017

ashish.singh@sitinetwork
s.com

18-08-2017

18-08-2017

05-09-2017

05-09-2017

Kings Broadband Pvt Ltd.

DS-11/348/2016-DS-III

A

All India

Mr. Prathapachandran R

16

Pimoony Broadband Services Pvt Ltd.

DS-11/79/2017-DS-III

B

Delhi

Mr. Ashawani Kumar

Khasra No. 146/1, Gali No. 3, Mukund
Vihar Part - II, New Delhi - 110 042.

DS-11/350/2016-DS-III

A

All India

18

S A Internet Solution Pvt Ltd.

DS-11/81/2017-DS-III

C

Ghaziabad

19

Sat International Pvt Ltd.

DS-11/224/2017-DS-III

A

All India

20

GSTECH Software Systems Pvt Ltd.

DS-11/85/2017-DS-III

A

All India

21

Navneeta Teleservices India Pvt Ltd.

DS-11/94/2017-DS-III

B

Delhi

No. F-127, West Vinod Nagar, Delhi - 110
Mr. Arun Kumar
092.
No. 404, Tower 'F', AVJ Heights, Zeta 1,
Mr. Satish Kumar Singh
Greater Noida - 201 310, UP.
No. 259, 2nd Floor, Sector 8, Part 2,
Mr. Deepak Kumar
Karnal - 132 001, Haryana.
No. 31, Govind Plaza, Boundary Road,
Mr. Gaurav Sharma
Meerut - 250 001, U.P.
Mr. Pramod Kumar
Trivedi

No. D-274/B-6, 2nd Floor, Krishna Park,
Devli Road, Khanpur, New Delhi -110062.

No. B-257, 1st Floor, B-Block, Indra
Mr. Deepak Batra
Nagar, Adarsh Nagar, Delhi -110 033.
Mr. Virender Singh
No. B-10, Lawrence Road, Industrial Area,
Thakur
New Delhi - 110 035.
C-43, 2nd Floor, DDA Shed, Okhla
Mr. Amit Vasudev Arora,
Industrial Area Phase 1, New Delhi Director
110020 .
No. 581/5, M.G. Road, Indore - 452 001,
Mr. Neelesh Chouhan
Madhya Pradesh.
Mandi Road, Surajgarh, District:
Mr. Amit Jangir
Jhunjhunu - 333029, Rajasthan.

22

Wi-Bro Solutions Pvt Ltd.

DS-11/80/2017-DS-III

A

All India

23

Siti Broadband Services Pvt Ltd.

DS-11/349/2016-DS-III

A

All India

24

NetNcr Technology Pvt Ltd.

DS-11/97/2017-DS-III

B

Delhi

25

Auspice Infratel Pvt Ltd.

DS-11/134/2017-DS-III

B

Rajasthan

26

Arichwal IT Services Pvt Ltd.

DS-11/136/2017-DS-III

B

Delhi

27

MNK Infoway Pvt Ltd.

DS-11/139/2017-DS-III

A

All India

Mr. Mohd Nazim Khan

28

Candor Infosolution Pvt Ltd.

DS-11/232/2017-DS-III

A

All India

auspice@auspice.in,
hi100nu@gmail.com

11-09-2017

11-09-2017

9352520725

network@aitspl.in

13-10-2017

13-10-2017

Shop No. 2, Gayak Mahd Rafiq Nagar,
Govandi, Mumbai - 400 043, Maharashtra.

9967972787

khannazim05@gmail.co
m

25-10-2017

25-10-2017

Mr. Kaushal Kumar

No. 7-A, Ber Sarai, Hauz Khas, New
Delhi - 110016.

9999841537

kaushal@candorsolution.
com

30-10-2017

30-10-2017

9100080100,
9676487799

vasanth@myguruonline.
net

02-11-2017

02-11-2017

9871288991

svdnetworks@gmail.com

17-11-2017

17-11-2017

9991266640

rohtashchauhan96@gma
il.com

11-12-2017

11-12-2017

9899833038

axntelnet@yahoo.co.in

11-12-2017

11-12-2017

8424042488

skynetdatacom@yahoo.c
om

11-12-2017

11-12-2017

8424042488

skynetdatacom@yahoo.c
om

11-12-2017

11-12-2017

9322451015,
9768016575

praksah@raeisp.com,
sachin@raeisp.com

12-12-2017

12-12-2017

9322451015,
9768016575

praksah@raeisp.com,
sachin@raeisp.com

12-12-2017

12-12-2017

9892681685

account@adtech.net.in,
girish@adtech.net.in

13-12-2017

13-12-2017

9892681685

account@adtech.net.in,
girish@adtech.net.in

13-12-2017

13-12-2017

9820366166

tanmaygala@yahoo.com

15-12-2017

15-12-2017

9820366166

tanmaygala@yahoo.com

15-12-2017

15-12-2017

29

Myguru Online India (P) Limited

DS-11/137/2017-DS-III

B

Andhra Pradesh

Mr. P Vasanth, Director

30

SVD Digital Networks Pvt Ltd.

DS-11/363/2017-DS-III

B

Delhi

Mr. Surender Dabas

B-51, T/F, MSV020296AAC, Masoodpur,
Vasant Kunj, New Delhi - 110 070.

Micronet IT Services Pvt Ltd.

DS-11/135/2017-DS-III

B

Haryana

32

NAS Internet Services Pvt Ltd.

DS-11/138/2017-DS-III

A

All India

33

Skynet Datacom Pvt Ltd.

DS-11/205/2017-DS-III

B

Mumbai

34

Skynet Datacom Pvt Ltd.

DS-11/205/2017-DS-III

B

Maharashtra

35

Rae Internet Service Provider Pvt Ltd.

DS-11/292/2017-DS-III

B

Maharashtra

36

Rae Internet Service Provider Pvt Ltd.

DS-11/292/2017-DS-III

B

Mumbai

37

Critel Technologies Pvt Ltd.

DS-11/323/2017-DS-III

B

Mumbai

38

Critel Technologies Pvt Ltd.

DS-11/323/2017-DS-III

B

Maharashtra

39

7 Star Cablenet Pvt Ltd.

DS-11/263/2017-DS-III

B

Mumbai

40

7 Star Cablenet Pvt Ltd.

DS-11/263/2017-DS-III

B

Mumbai

41

7 Star Cablenet Pvt Ltd.

DS-11/263/2017-DS-III

B

Goa

8860606961

9300080009

H. No. 59A-21/7-16A, Beside Sneha
Apartments, RR Gardens, Patamata,
Vijayawada - 520 010, Andhra Pradesh.

31

tripleplaynetwork@gmai
l.com
ipnetcommunication@ho
tmail.com
doordrishti@gmail.com

15

Mediant Broadband Pvt Ltd.

9910675230
9899894204

No. 209 (286), Ananda Bhawan, 4,
Balaramapuram Town, Trivandrum 695501, Kerala.

17

9810209191

Civil Hospital Road, Loharu, Bhiwani Mr. Rohtash, Director
127201, Haryana.
Booth No. 69, Sector-11, DLF Model
Mr. Anil Kumar
Town, Faridabad - 121 004, Haryana.
No. 702, SRA Building No. 02, Manal
Maruti CHS Ltd. Khandwala Compund,
Mr. Mahendra Ramdev
Near Datta Mandir, Vakol Bridge,
Yadav
Santacruz (East), Mumbai - 400 055,
Maharashtra.
No. 702, SRA Building No. 02, Manal
Maruti CHS Ltd. Khandwala Compund,
Mr. Mahendra Ramdev
Near Datta Mandir, Vakol Bridge,
Yadav
Santacruz (East), Mumbai - 400 055,
Maharashtra.
Office No. A-1301, Mukti Towers, Eastern
Mr. Prakash Ramdas
Express Highway, MHADA Layout,
Dumbre
Mulund East, Mumbai - 400081,
Maharashtra.
Office No. A-1301, Mukti Towers, Eastern
Mr. Prakash Ramdas
Express Highway, MHADA Layout,
Dumbre
Mulund East, Mumbai - 400081,
Maharashtra.
No. 201, Symphony Apartments, Kopri
Mr. Girish Manohar
Colony, Behind Anand Talkies, Thane
Chaphekar
(East) - 400 603, Maharashtra.
No. 201, Symphony Apartments, Kopri
Mr. Girish Manohar
Colony, Behind Anand Talkies, Thane
Chaphekar
(East) - 400 603, Maharashtra.
No. A/2, Juhu Sanskar Premises CHS Ltd.,
Mr. Tanmay Dhanji Gala
Juhu Church Road, Vile Parle (W),
Mumbai - 400 049, Maharashtra.
No. A/2, Juhu Sanskar Premises CHS Ltd.,
Mr. Tanmay Dhanji Gala
Juhu Church Road, Vile Parle (W),
Mumbai - 400 049, Maharashtra.
No. A/2, Juhu Sanskar Premises CHS Ltd.,
Mr. Tanmay Dhanji Gala
Juhu Church Road, Vile Parle (W),
Mumbai - 400 049, Maharashtra.

42

Al-Mairah Braodband Pvt Ltd.

DS-11/233/2017-DS-III

B

Mumbai

Mr. Mustafa Iqbal Shaikh

No. B-1201, Carribean Bldg, Sagar City,
Behind Khoja Jamaat Khana, Andheri
West, Mumbai - 400 058, Maharashtra.

43

Al-Mairah Braodband Pvt Ltd.

DS-11/233/2017-DS-III

B

Maharashtra

Mr. Mustafa Iqbal
Shaikh, Director

B-1201 Carribean, Sagar City, Behind
Khoj Jamaat Khana, Andheri West,
Mumbai- 400058

9820366166

tanmaygala@yahoo.com

15-12-2017

15-12-2017

9833900082

must4ever@gmail.com

18-12-2017

18-12-2017

9833900082

must4ever@gmail.com

18-12-2017

18-12-2017

<!-- page 2 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

44

Getway Broadband Pvt Ltd.

DS-11/361/2017-DS-III

B

Mumbai

45

Classic Internet and Cable Services
Pvt Ltd.

DS-11/305/2017-DS-III

B

Mumbai

46

47

48

S B Broadband Services Pvt Ltd.

Sysnet Broadband Services Pvt Ltd.

Twincity Communication Pvt Ltd.

DS-11/368/2017-DS-III

DS-11/387/2017-DS-III

DS-11/280/2017-DS-III

B

B

B

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

Room No. 10/A, Nemani Chawl, 1st Floor,
Mrs. Madhuri Suhas Naik Gandhi Road, Near Irani Hotel, Santacruz
(West), Mumbai - 400 054, Maharashtra.

9004755755

suhasnaik50@gmail.com

18-12-2017

18-12-2017

No. G-7, Lily Apartments, 'B' Wing, 255
Sharma Estate, S V Road, Jogeshwari
(West), Mumbai - 400 102, Maharashtra.

9892500089

jamshedyp@gmail.com

20-12-2017

20-12-2017

8792911860/ 62

rao.sbn.2013@gmail.co
m

20-12-2017

20-12-2017

Authorized Person

Mr. Jamshed Yusuf
Pathan

Karnataka

Mr. Naveen Rao

Mumbai

Abdul Hamid Razak,
Director

Gujarat

Registered Office Address

No. 60/61, Ground Floor, EWS, 63, Exp.
House, 4th Phase, 707 Group, Yelahanka
New Town, Bangalore - 560 064,
Karnataka.
Shop No. 13, Ground Floor,Aradhana
Bldg, Nr HDFC Bank, Station Road,
Jogeshwari East, Mumbai- 400060

9819352025

help_mysip@yahoo.com

01-01-2018

01-01-2018

Mr. Sanjaykumar Shah

202, HO. 3189, Sumati Tower,
Nagatalavadi Navsari - 396 445, Gujarat.

0261-7117702,
9825166274

info@twincitycpl.in

05-01-2018

05-01-2018

No. 510, Oshiwara Adarsh Nagar,
Gulmohar Society, New Link Road,
Oshiwara, Jogeshwari (West), Mumbai 400 102, Maharashtra.

65133999,
9833716888

uvaiskhan510@gmail.co
m

10-01-2018

10-01-2018

49

7 Sai Net Solutions Pvt Ltd.

DS-11/236/2017-DS-III

B

Mumbai

Mr. Uvais Zahid Khan

50

Pintwire Infomatics Pvt Ltd.

DS-11/345/2017-DS-III

B

Madhya Pradesh

Mr. Nitin Kumar
Agrawal

Flat No. 109, Sai Vihar, Shivanand Nagar,
Gudhiyari, Raipur - 492001, Chhattisgarh.

9074622255,
7714311555

nitin@pintwire.com,
info@pintwire.com

10-01-2018

10-01-2018

Mr. Davinder Kalra

No. 2728, Ward No. 15, Near Jain Mandir,
Kharar, SAS Nagar, Mohali - 140301,
Punjab.

0172-4801020

davinder@airtechinternet
.com

12-01-2018

12-01-2018

Mr. Maulik Patel

No. SF-113, City Mall-1, Navjivan Mill
Compound, Kalol - 382 721, Gujarat.

7878031831

maulikpatel93@hotmail.
com

24-01-2018

24-01-2018

Mumbai

Mr. 101/B, Shree Shubham CHS, Mahavir
Nagar, Dahaukar Wadi, Near HDFC
Mr. Hari Mannu Prajapati
Bank, Kandivali (W), Mumbai - 400 067,
Maharashtra.

9869352627

nehaprajapati884@gmail
.com

30-01-2018

30-01-2018

Mumbai

Vinay Kishore Nilly and
1/2 Vasant Jayram Keni Chawl, Ganesh
Varsha Kishore Nilly, Wadi, Chincholi Bunder, N L Road, Malad
Directors
(West), Mumbai- 400064

022-28816917

nillykishore@yahoo.com

01-02-2018

01-02-2018

All India

Naveen Tandon, Sanjiv
Bhagat and J K Khanna

13th Floor, 1305-1306, Mohan Dev
House, 13 Tolstoy Marg, New Delhi - 110
001.

011-42408775

sanjiv.bhagat@intl.att.co
m,
naveen.tandon@intl.att.c

07-02-2018

07-02-2018

Shop No. C-29, Ground Floor, Okaz
Shopping Centre, Millat Nagar, Andheri
(West), Mumbai - 400 053, Maharashgtra.

022-26394631,
9167579077

farhans60@yahoo.com

08-02-2018

08-02-2018

Shop No. C-29, Ground Floor, Okaz
Shopping Centre, Millat Nagar, Andheri
(West), Mumbai - 400 053, Maharashgtra.

022-26394631,
9167579077

farhans60@yahoo.com

08-02-2018

08-02-2018

12-02-2018

12-02-2018

07-03-2018

07-03-2018

51

52

53

Airtech Internet Solutions Pvt Ltd.

Hari Om Netsol Pvt Ltd.

Balajikrupa Braodband Pvt Ltd.

54

Varsha Datacom Services Pvt Ltd.

55

AT&T Global Network Services India
Pvt Ltd.

DS-11/142/2017-DS-III

DS-11/221/2017-DS-III

DS-11/274/2017-DS-III

DS-11/396/2017-DS-III

DS-11/364/2017-DS-III

A

B

B

B

A

All India

Gujarat

56

E I DOT Com Pvt Ltd.

DS-11/188/2017-DS-III

B

Mumbai

Mr. Farhan Mohd. Kasim
Khan, Director

57

E I DOT Com Pvt Ltd.

DS-11/188/2017-DS-III

B

Maharashtra

Mr. Farhan Mohd. Kasim
Khan, Director

58

BT Global Communications India Pvt
Ltd.

DS-11/83/2017-DS-III

A

All India

Mr. Anil Kumar Jha

59

Quantasoul Airologix Pvt Ltd.

DS-11/140/2017-DS-III

A

All India

Mr. Jigar Bhikalal
Sanghavi

60

HCIN Telecom Solutions Pvt Ltd.
(Formerly : La Pointe Telecom
Solutions Pvt Ltd.)

DS-11/90/2017-DS-III

A

All India

Mr. Khanish Juneja

61

Shrisai Shavenk Technologies Pvt Ltd.

DS-11/195/2017-DS-III

B

Mumbai

Mr. Venkhatesh
Veeramuthu Pillai

62

Mega Hertz Network Solutions Pvt
Ltd.

DS-11/308/2017-DS-III

B

Mumbai

Mr. Prashant Shet

63

Edgenet Broadband Services Pvt Ltd.

DS-11/409/2017-DS-III

B

Mumbai

Mr. Sunil Arjunsingh
Singh

64

Oxynet Telecommunications Pvt Ltd.

DS-11/424/2017-DS-III

B

Kolkata

Mr. Partha Pratim Das

65

J D Net Enterprises Pvt Ltd.

DS-11/275/2017-DS-III

B

Mumbai

Mr. Janardhan Kamlakar
Bhure

66

JTM Internet Pvt Ltd.

DS-11/435/2017-DS-III

B

Gujarat

Jinesh Shah, Director

67

Gowio Networks Pvt Ltd.

DS-11/282/2017-DS-III

B

Maharashtra

68

Jasnet Networks Pvt Ltd.

DS-11/352/2017-DS-III

B

Bihar

69

VNO Networks Pvt Ltd.

DS-11/373/2017-DS-III

B

Mumbai

11th Floor, Eros Corporate Tower, Opp.
011-47811111, 011International Trade Tower, Nehru Place,
anish.bhatnagar@bt.com
47811112
New Delhi - 110 019.
Survey No 888/807/810, FP-25-28T, 907,
Pinnacle, Prahlad Nagar Area, Opp. Royal 079-40021301/02,
dhaval@sanghviinfo.com
Arcade, AUDA, Garden, Ahmedabad 9825039318
380015, Gujarat.
No. 384, Ist Floor, Dr. Mukherjee Nagar,
Delhi - 110 009.
No. D/202 Link Palace, Saibaba Complex,
CIBA Road, Goregaon (E), Mumbai - 400
063, Maharashtra.
Bldg No. 35, B Wing, Flat No. 26, Shree
Swami Krupa CHS Ltd., J.P. Road,
Andheri (W), Mumbai - 400 053,
Maharashtra.
No. 808, MHB Colony, Adarsh Nagar,
New Link Road, Jogeshwari West,
Mumbai - 400 102, Maharashtra.
No. 6/3, M.N. Saha Road, Dumdum
Chatakol, P.S. Dumdum, Kolkata 700074, West Bengal.
Flat No. 102, Suraj Mandir CHS, 45-A
Gazdhar Scheme, North Avenue Road,
Santacruz West, Mumbai - 400 055,
Maharashtra.
A-403, Vatsalaya Heights, Opp. Green
Avenue, Adajan, Surat, Gujarat - 395 009.

S R No. 05, House No. 348, Pawar Vasti,
Kishor Jaywant Bhosale,
Keshav Nagar, Mundhwa, Pune - 411 036,
Director
Maharashtra.
No. 303, R.K. Niwas, Gola Road Mor,
Rupaspur, Danapur, Nr. Ishan International
Mr. Shivendu
Girls School, Basily Road, Patna - 801503,
Bihar.

0120-4353600

info@lapointe.in

08-03-2018

08-03-2018

022-2228416666,
9821991335

venkhateshvmp@gmail.c
om

14-03-2018

14-03-2018

022-66779997,
9820606334

prashant_shet@hotmail.c
om

19-03-2018

19-03-2018

9867902565

Sunil4urs@gmail.com

20-03-2018

20-03-2018

8444043399,
8697682327

info@cnetworld.in
partha@cnetworld.in

20-03-2018

20-03-2018

9892711532

jdcablenetwork1@gmail.
com

26-03-2018

26-03-2018

9824527379

director@jtminternet.co
m

04-04-2018

04-04-2018

020-26880590,
8484847171

kishorenetmax152@gma
il.com,
jamsheddy@gmail.com

05-04-2018

05-04-2018

8595242461

jasnetworks@gmail.com

05-04-2018

05-04-2018

02265615027,
9892560046

support@ahuranetworks.
com

10-04-2018

10-04-2018

13-04-2018

13-04-2018

23-04-2018

23-04-2018

25-05-2018

25-05-2018

29-05-2018

29-05-2018

31-05-2018

31-05-2018

31-05-2018

31-05-2018

01-06-2018

01-06-2018

05-06-2018

05-06-2018

Mr. Mehrangiz Oorvaksh
Natewala

Floor 1, Plot 275, Old Khan Building, Javji
Dadaji Marg, Chikhal Wadi, Grant Road,
Mumbai - 400 007, Maharashtra.

022-28283300,
9920003381,
9920003389

8850474832

70

Mayekar Broadband Pvt Ltd.

DS-11/447/2017-DS-III

B

Mumbai

Mr. Vimol Suresh
Mayekar

Room No. 1, Seva Sadan Chawl,
Rawalpada Santosh Nagar, Near Shukla
Compund, Dahisar East, Mumbai - 400
068.

71

LBS Infoway India Pvt Ltd.

DS-11/433/2017-DS-III

B

Mumbai

Mr. Mehul Lehru

Shop No. 6, Shantinath Darshan, Shanti
Park, Opp. St. Xaviers High School, Mira
Road East, Thane - 401 107, Maharashtra.

Mr. Atul Agarwal

No. 10/852, Malviya Nagar, Near Brain
Tower Hospital, Jaipur - 302 017,
Rajasthan.

9887022134

Mr. Ravinder Kumar

2nd Floor, Opp. Rampura, Jagadhri Road,
Yamuna Nagar - 135 001, Haryana.

9729090123,
9050001112

72

73

74

Dcs Internet Services Pvt Ltd.

Planet Wifi Pvt Ltd.

DS-11/57/2018-DS-III

DS-11/71/2018-DS-III

B

B

Rajasthan

Haryana

info@mayekarbroadband
.com,
vimol_mayekar@yahoo.
com,
infomail.lbsindia@gmail.
com,
info@londonbroadband.i
n
dcsispl@gmail.com,
atulagarwl12121@gmail
.com
info@planetwifi.net

Karishma Co-Op HSG Society, Plot No.
9822121312
Mr. Vijay Naraindas
426, Basement, Shop No. 3, OT Section,
9822432000 0251- vijay.vcn@gmail.com
Thakur
Ulhasnagar, Thane - 421 004,
2581312
Maharashtra.
Excel Plaza, 1/SH06, A Wing, CTS No.76,
info@bandwidthinfinity.
Mrs. Madhu Basu
76/1-3, IIT Market, Powai, Mumbai - 400
9324635173
com
076, Maharashtra.
Prabhakar Gupta,
RZ A-32, Block A,Nihal Vihar, Nangloi,
8447471267
prabhakar@ookla.co.in
Director
New Delhi - 110 041
H.No. 1163, Near Jeaka Bekari, Sai
Mr. Ratnakar Sadanand
ratnakarbhoir15@gmail.
Nagar, G.B.Road, Thane - 400615,
9004037200
Bhoir
com
Maharashtra.

A S Broadband Pvt Ltd.

DS-11/54/2018-DS-III

C

Kalyan

75

Bandwidth Infinity Pvt Ltd.

DS-11/49/2018-DS-III

B

Mumbai

76

ABPK Odigital Pvt Ltd. (Formerly :
Ookla Telecom Pvt Ltd.)

DS-11/72/2018-DS-III

B

Delhi

77

Prathamesh Broadband Pvt Ltd.

DS-11/124/2018-DS-III

B

Mumbai

78

Exnet Broadband Pvt Ltd.

DS-11/148/2018-DS-III

B

Delhi

Mr. Mahesh Kumar

No. 7/73, Khichripur, Delhi - 110 091.

011-22772013,
9540805040

sainetworks2013@gmail
.com

12-06-2018

12-06-2018

Mumbai

Mr. Jayprakash
Ramvilash Sharma

No. 254, 2nd Floor, Satra Plaza, Sector19D,Vashi, Navi Mumbai - 400 703,
Maharashtra.

9321009100

info@jlinkindia.com

13-06-2018

13-06-2018

79

J-Link Infotainment Pvt Ltd.

DS-11/137/2018-DS-III

B

<!-- page 3 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.
80

81

Name of Licensee
SNS Internet Services Pvt Ltd.

Live Line Network Technology Pvt
Ltd.

License No.
DS-11/8/2018-DS-III

DS-11/4/2018-DS-III

Category
B

B

Service Area
Delhi

Mumbai

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

Mr. Santosh Kumar

House No.319, KH. No.10, Ground Floor,
Main Road, Village Shalimar, Delhi - 110
088.

784005240

sanjay@snsinternet.com

13-06-2018

13-06-2018

Mr. Bhavesh Chityala

Room No. 113, 3/10, Bharatiya Kamla
Nagar, SP Road, Antop Hill, Wadala
(East), Mumbai - 400 037, Maharashtra.

7506502277

chityalabhavesh@gmail.
com

21-06-2018

21-06-2018

9920525307

info@way2air.com

21-06-2018

21-06-2018

9920525307

info@way2air.com

21-06-2018

21-06-2018

7738359355

b2hinfonet@gmail.com

22-06-2018

22-06-2018

022-65354888,
9920912424

info@vikingnetwork.in,
ashishmhdk@yahoo.com

26-06-2018

26-06-2018

8329730244

jprnetworks.in@gmail.co
m

29-06-2018

29-06-2018

8329730244

jprnetworks.in@gmail.co
m

29-06-2018

29-06-2018

9828112540

cbhardwaj007@gmail.co
m

29-06-2018

29-06-2018

03228-231374

skyberbraodband@gmail
.com

06-07-2018

06-07-2018

9892157745

athaniumesh@gmail.com

11-07-2018

11-07-2018

13-07-2018

13-07-2018

20-07-2018

20-07-2018

20-07-2018

20-07-2018

20-07-2018

20-07-2018

82

Way2Air Net Solution Pvt Ltd.

DS-11/415/2017-DS-III

C

Kalyan

Mr. Imranali Akbarali
Charolia

83

Way2Air Net Solution Pvt Ltd.

DS-11/415/2017-DS-III

B

Mumbai

Mr. Imranali Akbarali
Charolia

84

B2H Infonet Pvt Ltd.

DS-11/32/2018-DS-III

B

Mumbai

Mr. Deodatta R
Velhankar

85

Viking Network Pvt Ltd.

DS-11/31/2018-DS-III

B

Mumbai

Mr. Ashish Bhikuram
Mahadik

86

JPR Networks India Pvt Ltd.

DS-11/40/2018-DS-III

B

Himachal Pradesh

Mr. Rajat sharma

87

JPR Networks India Pvt Ltd.

DS-11/40/2018-DS-III

B

Punjab

Rajat sharma, Director

88

89

90

Royal Connect Solutions Pvt Ltd.

Skyber Broadband Service Pvt Ltd.

SBS Broadband and Cable Pvt Ltd.

DS-11/25/2018-DS-III

DS-11/119/2018-DS-III

DS-11/121/2018-DS-III

B

B

B

Rajasthan

Mr. Chetan Bhardwaj

West Bengal

Mr. Nemai Das

Mumbai

Mr. Umesh Kailash
Athani

No. H-8/102, Navyuwan CHS, Shrishti
Complex, Baba Saheb Ambedkar Road,
Sector 4, Mira Road (East), Thane - 400
107, Maharashtra.
No. H-8/102, Navyuwan CHS, Shrishti
Complex, Baba Saheb Ambedkar Road,
Sector 4, Mira Road (East), Thane - 400
107, Maharashtra.
Room No. 4, Behariji Chambers,
Ambedkar Road, Thane - 400 099,
Maharashtra.
No. C-907, Rehab Building, CTS No. 629,
Government Colony Road, Bandra East,
Mumbai - 400051, Maharashtra.
Ward No 5, PO: Bharolian Khurd, Post
Office Tehsil Una - 174 304, Himachal
Pradesh.
Ward No 5, PO Bharolian Khurd,Post
Office Tehsil UNA,Himachal Pradesh174304
Villa No. 35, Ananda Kailash Sarovar,
Patrakar Colony, Mansarovar, Jaipur - 302
020, Rajasthan.
Mecheda Bazar (Kakdihi Bazar), Mecheda,
Kolaghat, Purba Medinipur - 721 134,
West Bengal.
Room No. 8, 1st Floor, Mukund Narayan
Chawl, Pratap Nagar, Mumbai - 400 060,
Maharashtra.

kngdbroadband@gmail.c
om,
dharmveer.kushwah09@
gmail.com
ashish.dubey@fibernetin
dia.com,
nimisha.dubey@fiberneti
ndia.com
ashish.dubey@fibernetin
dia.com,
nimisha.dubey@fiberneti
ndia.com
ashish.dubey@fibernetin
dia.com,
nimisha.dubey@fiberneti
ndia.com

91

KNGD Broadband Pvt Ltd.

DS-11/146/2018-DS-III

B

Rajasthan

Mr. Dharmveer Singh

Shreeji Market, In Front of Janana
Hospital, Sikar - 332 001, Rajasthan.

92

Fibernet Solutions (OPC) Pvt Ltd.

DS-11/324/2017-DS-III

B

Madhya Pradesh

Nimisha Dubey, Director

73, Aradhana Nagar,Kootra
Sultanabad,Bhopal- 462003 (M.P.)

7489440888,
7000313122

93

Fibernet Solutions (OPC) Pvt Ltd.

DS-11/324/2017-DS-III

B

Maharashtra

Mrs. Nimisha Dubey

No. 73, Aradhana Nagar, Kotra,
Sultanabad, Bhopal - 462 003 (M.P.)

7489440888,
7000313122

94

Fibernet Solutions (OPC) Pvt Ltd.

DS-11/324/2017-DS-III

B

Mumbai

Mrs. Nimisha Dubey

No. 73, Aradhana Nagar, Kotra,
Sultanabad, Bhopal - 462 003 (M.P.)

7489440888,
7000313122

Mr. Kiran Uttam
Sontakke

Geeta Bhavan, Block No. 104, Navghar,
Vasai Road (West), Thane - 401 202,
Maharashtra.

7875338331

dynamic_solution@outlo
ok.com

23-07-2018

23-07-2018

9861211118

info@jinusnet.com

23-07-2018

23-07-2018

95

A2D Dynamic Pvt Ltd.

DS-11/63/2018-DS-III

C

Kalyan

9694453777

96

Jinus Net Pvt Ltd.

DS-11/448/2017-DS-III

B

Orissa

Mr. Jagannath Puri

Plot No. GA-123, BDA Phase 2, Niladri
Vihar, Chandrasekharpur, Khorda,
Bhubaneswar - 751 016, Orissa.

97

R N Broadband Online Pvt Ltd.

DS-11/130/2018-DS-III

B

Mumbai

Mr. Rahul Jacob Nirmal

Room No.1569, Near Samaj Mandir,
Elthanpada Digha, Airoli, Navi Mumbai,
Thane -400 708, Maharashtra.

9702555050,
9773331349

rahuljnirmal@gmail.com

25-07-2018

25-07-2018

9422116679,
9960281314

infonetwani@gmail.com

04-10-2018

04-10-2018

0744-6440000,
9214066666

ncorecreative@gmail.co
m,
rakeshbagla@gmail.com

26-10-2018

26-10-2018

9910827826

sunitamrai@gmail.com

27-11-2018

27-11-2018

9868231274

nirja0706@gmail.com

28-11-2018

28-11-2018

022-26732221,
9820360044

veerpointpvt.ltd@gmail.c
om,
vinodpardesi31@gmail.c
om

28-11-2018

28-11-2018

28-11-2018

28-11-2018

9158434839,
9766684806

gigalocommunication@y
ahoo.com

12-12-2018

12-12-2018

Unit No. 305, 3rd Floor Aero City, Asset
No. 7, Worldmark 3, Indira Gandhi
International Airport, New Delhi - 110037.

011-42818103,
9810074983

debashish.dey@intl.veriz
on.com

14-12-2018

14-12-2018

C-86, Aamra Vihar, Phase-3 Kolar Road,
Nayapura Bhopal- 462042 (M.P.)

9893567985,
7566617002,
07554701749

amit@winuxsolutions.in

17-12-2018

17-12-2018

9930217770

geracable@gmail.com

18-12-2018

18-12-2018

18-12-2018

18-12-2018

98

Modi Infonet Digital Network Pvt Ltd.

DS-11/21/2018-DS-III

B

Maharashtra

Shoyeb Z Khan

Block No 7, Shubham Hotel, Mangal
Karyalay Building, Wani Yavatmal - 445
304, Maharashtra.

99

Ncore Creative Technologies Pvt Ltd.

DS-11/122/2018-DS-III

B

Rajasthan

Mr. Rakesh Bagla

No. 47, Nai Dhan Mandi, Mukhya Dak
Ghar, Kota - 324 001, Rajasthan.

100

Ultra Internet Services Pvt Ltd.

DS-11/206/2018-DS-III

A

All India

Mrs. Sunita Yadav

101

Upnet Communications Pvt Ltd.

DS-11/244/2018-DS-III

B

Delhi

Mrs. Neeraja Singh,
Director

102

Veer Point Pvt Ltd.

DS-11/172/2018-DS-III

B

Mumbai

Mr. Vinod Devtadin
Pardesi

103

Weblink Infoways Pvt Ltd.

104

Gigalo Communication Pvt Ltd.

105

Verizon Communications India Pvt
Ltd.

106

107

108

Winux Communications Pvt Ltd.

Gera Cable Internet Service Pvt Ltd.

Sai Dwarawati Net Services Pvt Ltd.

DS-11/237/2018-DS-III

DS-11/155/2018-DS-III

DS-11/61/2018-DS-III

DS-11/67/2018-DS-III

DS-11/286/2018-DS-III

DS-11/283/2018-DS-III

B

B

A

B

B

B

Mumbai

Maharashtra

All India

Madhya Pradesh

Mumbai

Mumbai

H. No. 58-A, Radhey Shyam Park, Delhi 110051.
No. F. No. 1909, Block CG-2, GH-01/A,
(Capetown of Supertech Ltd.) Sector-74,
Noida, Gautam Buddha Nagar - 201 301,
Uttar Pradesh.
No. R. No. 4, Bldg. No. 7, Azad Nagar,
Veera Desai Road, Andheri West, Mumbai 400 058, Maharashtra.

Shop No. 2, Plot No. 186, Ratan Palace,
Garodia Nagar, Ghatkopar East, Mumbai 400 077, Maharashtra.
Plot No. 26, Pragati Colony, Opposite Sai
Niranjan Ramesh Pohane,
Mandir, Wardha Road Nagpur, PIN - 440
Director
015
Mr. Satish Jayant
Suvarna

Mr. Debasish Dey

Amit Upadhayay,
Director

Shop No. 9, Harjipatel Chawl, Opp. Tipco,
Mr. Abdul Ali Mohmmed
Rani Sati Marg, Malad East Mumbai Mistry
400 097, Maharashtra.
No. 39 2, Hiraji Desai Wadi, Turel
Mr. Jayendra Patil
Pakhadi, Jakiria Road, Malad (West),
Mumbai - 400 064, Maharashtra.

9594961900

jayendradpatil29@gmail.
com

9821888507

sunilp1970@yahoo.com

18-12-2018

18-12-2018

7500800082

amardeep.chauhan@cou
ntrylink.in,
amardeep.chauhan9@gm
ail.com

20-12-2018

20-12-2018

109

Shivkranti Internet Services Pvt Ltd.

DS-11/275/2018-DS-III

B

Mumbai

Mr. Sunil Rajaram
Pandey

Mr. 7/57, 1st Floor, S. I. H. Scheme, M. G.
Road, Opp. Azad Maidan, Goregaon
(West), Mumbai - 400 062, Maharashtra.

110

Countrylink Communication Pvt Ltd.

DS-11/210/2018-DS-III

B

Uttar Pradesh (West)

Mr. Amardeep

Lane No. E, Khasara No-202, Friends
Enclave, Shahnagar, Defence Colony,
Dehradun - 248001, Uttarakhand.

Mr. Jinesh Shah

No. A-403, Vatsalaya Heights, Opp. Green
Avenue, Adajan, Surat - 395 009, Gujarat.

9824527379

director@jtminternet.co
m

20-12-2018

20-12-2018

111

JTM Internet Pvt Ltd.

DS-11/435/2017-DS-III

B

Gujarat

112

JTM Internet Pvt Ltd.

DS-11/435/2017-DS-III

B

Maharashtra

Mr. Jinesh Shah

No. A-403, Vatsalaya Heights, Opp. Green
Avenue, Adajan, Surat - 395 009, Gujarat.

9824527379

director@jtminternet.co
m

20-12-2018

20-12-2018

113

Elxire Communications Limited

DS-11/236/2018-DS-III

A

All India

Mr. Raj Kumar Garg

No. SCF-65, 1st Floor, Sector 7-E,
Faridabad - 121 004, Haryana.

9811183131

rkgarg@elxireit.in

21-12-2018

21-12-2018

No. B-1705, Abrol Vastu Park, Off Link
Road, Near Uma Nagar, Malad West,
Mumbai - 400 064, Maharashtra.

9920055593

mrujesh@gmail.com

26-12-2018

26-12-2018

Shop No. 09, G/F, Block-C, Anand Vihar,
Delhi - 110 092.

9811107771

gudkitcable@yahoo.co.in

26-12-2018

26-12-2018

114

Hrishi Internet Services Pvt Ltd.

DS-11/287/2018-DS-III

B

Mumbai

Mr. Mrujesh Shashikant
Golatkar

115

Raftar Communications Pvt Ltd.

DS-11/245/2018-DS-III

B

Delhi

Mr. Rajeev Bhargava

<!-- page 4 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.
116

117

Name of Licensee
Vijay Network Services India Pvt Ltd.

Bapu Internet Services Pvt Ltd.

118

Ma Vaishno Devi Internet Pvt Ltd.

119

Shree Siddhivinayak Cable and
Internet Service Provider Pvt Ltd.

License No.
DS-11/66/2018-DS-III

DS-11/274/2018-DS-III

DS-11/288/2018-DS-III

Category
B

B

Service Area
Maharashtra

Mumbai

Authorized Person

Vizcon Digital Pvt Ltd.

121

Ashley Internet Services Pvt Ltd.

DS-11/273/2018-DS-III

DS-11/272/2018-DS-III

9833598208

27-12-2018

27-12-2018

No. 52, Ramachandra Lane, Off S.V.
Road, Opp. Allahabad Bank, Malad
(West), Mumbai - 400 064, Maharashtra.

9820055497

khetanrupesh90@gmail.
com

27-12-2018

27-12-2018

Mr. Gangaprasad
Gangaram Vemla

Shop No. &, Plot No. 27/28, Pushpa Park,
Siddhivinayak Chawl, Comm SRA Road
No. 2, Malad (East), Mumbai - 400 097.

9869249549

gvemla@yahoo.com

27-12-2018

27-12-2018

9820595705

vizcondigital@gmail.co
m

27-12-2018

27-12-2018

7666666334

ashley.martuvar@gmail.
com

28-12-2018

28-12-2018

9891138855

bitty@bittech.co.in

02-01-2019

02-01-2019

9831887932

asishchakraborty80@gm
ail.com

02-01-2019

02-01-2019

03-01-2019

03-01-2019

04-01-2019

13-04-2018

B

Mumbai

Mr. Ashish Lalaram
Agrawal

Kothari Wadi, 63-5, Tagore Park, SV
Road, Malad West, Mumbai - 400064,
Maharashtra.

B

Mumbai

Mr. Ashley Joseph
Martuvar

No. B-64 Bhagat Singh Nagar, No 1 Link
Road, Opp. Sejal Park, Goregaon West,
Mumbai - 400 104, Maharashtra.

DS-11/170/2018-DS-III

B

Delhi

Aatif Yusuf, Director

DS-11/211/2018-DS-III

B

Kolkata

Asish Chakraborty,
Director

B

Mumbai

Prop 817 A, Kanupriya Apartment, A-1,
UGF, Ward No. 6, Mehrauli, New Delhi 110 070.
B-21, Ganganagar, P.O. Kalikapur,
Kolkata - 700099.

Mr. Edwin John Ecreado

Flat No. 7, Sai Suraj, Sai Dharti Suraj
CHCL, Sai Baba Complex, Ciba Road,
Goregaon (East), Mumbai - 400 063.
022-28283300,
9920003381,
9920003389

info@mayekarbroadband
.com,
vimol_mayekar@yahoo.
com,

9004077079

vikrammore5@gmail.co
m

07-01-2019

07-01-2019

9269999666

pyramidinfo@gmail.com

07-01-2019

07-01-2019

07-01-2019

07-01-2019

125

Mayekar Broadband Pvt Ltd.

DS-11/447/2017-DS-III

B

Maharashtra

Mr. Vimol Suresh
Mayekar

Room No. 1, Seva Sadan Chawl,
Rawalpada, Santosh Nagar, Nr Shukla
Compound, Dahisar East, Mumbai - 400
068.

126

Mayuresh Broadband Pvt Ltd.

DS-11/171/2018-DS-III

B

Mumbai

Mr. Vikram Haridas
More

Shop No. 6, Sai Sadhana CHS, Plot No. 5,
Sector 10, New Panvel, Navi Mumbai,
Raigarh - 410 206, Maharashtra.

127

Speed 4 Net Technologies Pvt Ltd.

DS-11/213/2018-DS-III

B

Rajasthan

Mr. Kamal Meena

128

Trigart Internet Pvt Ltd.

DS-11/141/2018-DS-III

C

Kangra

Mr. Param Dev

AU Networks Pvt Ltd.

130

Daksha Net Vision Pvt Ltd.

131

Orange Business Services India
Network Pvt Ltd.

B-65, Shivpuri Airport, Shivpuri Colony,
Tehsil- Sanganer, Jaipur - 302 029,
Rajasthan.
VPO: Sidhpur, Near Norbulingka Institute,
Tehsil Dharamshala, Kangra - 176 057,
Himachal Pradesh.

B

Mumbai

Mr. Thangaraj Nadesan
Padayachi

Flat No. 17/13, 3rd Floor, Suvarnarekha,
NN CHS Ltd, Plot No. 6, NNP, Gen A K
Vaidya Marg, Goregaon (East), Mumbai 400 065, Maharashtra.

DS-11/277/2018-DS-III

B

Mumbai

Mr. Lalji Dhuda Boricha

Flat No. 2, Ground Floor, Bldg No. 4,
Krishna NN CHS Ltd, Plot No. 6, NNP,
Gen A K Vaidya Marg, Goregaon (East),
Mumbai - 400 065, Maharashtra.

228410176

sairaj927@gmail.com

09-01-2019

09-01-2019

DS-11/340/2017-DS-III

A

All India

Mr. Rajesh Balal

4th Floor, Tower 'A', Bldg No. 8, DLF
Cyber City, Gurgaon - 122 002, Haryana.

124-4358118

rajesh.ballal@orange.co
m

09-01-2019

09-01-2019

9821036934

amolparsekar46@gmail.
com

10-01-2019

10-01-2019

9820000321

kazimsayyed@yahoo.co
m

10-01-2019

10-01-2019

9869641070

bhushan.1660@rediffma
il.com

15-01-2019

15-01-2019

9848876974

admin@stpl.network

17-01-2019

17-01-2019

22-01-2019

22-01-2019

8772222405

airnetzharish@gmail.co
m

28-01-2019

28-01-2019

9920998455

kgt61181@gmail.com

28-01-2019

28-01-2019

7044344970,
9038565112

srijit.banerjee@sharktel.c
o, hello@sharktel.com

28-01-2019

28-01-2019

30-01-2019

30-01-2019

DS-11/276/2018-DS-III

132

3SBS Datacom Pvt Ltd.

DS-11/238/2018-DS-III

B

Maharashtra

Mr. Amol A. Parsekar

No. A-302, 3rd Floor, Plot 843, 'B' Wing,
Shiv Shakti SRA CHS, K D Marg, Dadar,
Mumbai - 400 028, Maharashtra.

133

Engross Network & Datacom Pvt Ltd.

DS-11/246/2018-DS-III

B

Mumbai

Mr. Kazim Ali Sayed

Room No. 04, Yunus Badruddin Chawl,
Azad Nagar, Paili Pada, Trombay,
Mumbai - 400088, Maharashtra.

134

Jetato Skynet Services Pvt Ltd.

135

Sudhana Telecommunications Pvt Ltd.

136

137

138

I O Network Pvt Ltd.

Airnetz Broadband Services Pvt Ltd.

Nandita Infocom Pvt Ltd.

26-12-2018

bapucablevideo@gmail.c
om

Mumbai

Bit Tech Broadband Pvt Ltd.

129

Effective Date

26-12-2018

B

Netstra Comunications Pvt Ltd.

DS-11/278/2018-DS-III

Date of Signing UL

mmsmed@gmail.com

Mumbai

123

Ecreado Network Solutions Pvt Ltd.

Mail ID

7666444888

B

122

124

Contact No.
Mobile

Mr. Rupesh Purushottam
Khetan

DS-11/289/2018-DS-III
120

Registered Office Address

No. C/1503, Runwal Heights, L.B.S Marg,
Mr. Vijay Kumar Mishra
Mulund West, Mumbai - 400 080,
Maharashtra.
Shop No. 2, Samarpan Bldg, Marve Road,
Mr. Narendra Desaji
Malad (West), Mumbai - 400 064,
Jadega
Maharashtra.

DS-11/271/2018-DS-III
DS-11/205/2018-DS-III

DS-11/224/2018-DS-III

DS-11/362/2018-DS-III

DS-11/285/2018-DS-III

B

Mumbai

Mr. Bhushan Anant Patil

C

Hyderabad

Mr. Dhana Babu
Bairisetty

C

C

B

Pune

No. 92/A AT-Kevni Dive, Bhiwandi,
Thane - 421302, Maharashtra.
H. No. 10-1-545/A. Nehru Nagar,
Marredpally, Secunderabad, Hyderabad 500 026, Telengana.

9892855649

aunetworkspvtltd@gmail
.com

09-01-2019

09-01-2019

Shop No. 1, Chandrama Residency, Near
Mr. Rahul Vitthal Wahile
Ganesh Mandir, Mohan Nagar,
Chinchwad, Pune - 411019, Maharashtra.

Chittoor

Mr. Yalla Harish

Mumbai

Mr. Kunal Gajendra
Tiwari

No. 3-82, 3rd Line, BTR Colony,
Mangalam, Tirupati, Chittoor - 517507,
Andhra Pradesh.
Room No. 6, Kashinath Patil Chawl, Opp.
Sapna Hotel, S.V. Road, Mumbai - 400
064, Maharashtra.
No. 55/4, SB Neogi Garden Lane,
Baranagar, Kolkata - 700 036, West
Bengal.
H. No. 92, Near Hinglin Mandir,
Nayamunda, Jagdalpur, Bastar - 494001,
Chhattisgarh.
Ground Floor, Prithvi Vandan CHS, NM
Joshi Marg, Bawla Masjid, Lower Parel,
Delisle Road, Mumbai - 400 013,
Maharashtra.
Upper Floor, Haji Karim & Sons,
Islampura, Kurar VLG, Malad (East), Near
Majjid Kurar, Mumbai - 400 097,
Maharashtra.

139

Sharktel Infocom Pvt Ltd.

DS-11/201/2018-DS-III

B

Kolkata

Mr. Srijit Banerjee

140

Fastx Broadband Pvt Ltd.

DS-11/387/2018-DS-III

C

Jagdalpur

Mr. Sanjay Gupta

141

Galvin Broadband (OPC) Pvt Ltd.

DS-11/208/2018-DS-III

B

Mumbai

Mr. Santosh Gopal
Puralkar

142

Ajab Media Vision Pvt Ltd.

DS-11/365/2018-DS-III

B

Mumbai

Mr. Ajit Kamala Singh

143

Ocean Leasedline Wala Pvt Ltd.

DS-11/279/2018-DS-III

B

Mumbai

Shop No. 2, Islamiya Market, Khairani Rd,
Mr. Asif Ali Mohd Munir
9664751613/02228
Near Ruby Geiyld Bank, Sakinaka Kurla,
Khan
525252
Mumbai - 400 072, Maharashtra.

144

Dstech Cyberspace Pvt Ltd.

DS-11/22/2018-DS-III

B

Uttar Pradesh (West)

145

146

Dstech Cyberspace Pvt Ltd.

Dstech Cyberspace Pvt Ltd.

DS-11/22/2018-DS-III

DS-11/22/2018-DS-III

B

B

Delhi

Haryana

Mr. Dipankar Batra

No. 295, Jamun Mohalla, Lal Kurti, Bada
Bazar, Meerut - 250 001, Uttar Pradesh.

Mr. Dipankar Batra

No. 295, Jamun Mohalla, Lal Kurti, Bada
Bazar, Meerut - 250 001, Uttar Pradesh.

Mr. Dipankar Batra

No. 295, Jamun Mohalla, Lal Kurti, Bada
Bazar, Meerut - 250 001, Uttar Pradesh.

147

Keshava Digital Network Pvt Ltd.

DS-11/366/2018-DS-III

B

Mumbai

Mrs. Anita Andhu Sali

148

Gorai 4Net Services Pvt Ltd.

DS-11/284/2018-DS-III

B

Mumbai

Mr. Manohar Vishnu
Bhatuse

149

Net-On Broadband Services Pvt Ltd.

DS-11/247/2017-DS-III

B

Uttar Pradesh (East)

Mr. Amit Agrawal

150

Visputes Internet Pvt Ltd.

DS-11/169/2018-DS-III

B

Mumbai

Mr. Arvind Vasant
Vispute

No. 2, Diwali Darshan, Mamletdarwadi
Road No. 5, Malad West, Mumbai - 400
064, Maharashtra.
No. D-3, Sahil CHS, Plot No. 104,
Borivali West, Goral Road, Mumbai 400091, Maharashtra.
H.No. 3/1327, Plot No. 172, Rampur,
Ramnagar, Varanasi - 221 008, Uttar
Pradesh.
R Yadav Chawl, Datta Tekdi, Majaswadi,
Majas Road, Jogeshwari (East), Mumbai 400 060, Maharashtra.

9930178148

spuralkar@gmail.com

07-02-2019

07-02-2019

9004076786

ajabmediavision@gmail.
com

08-02-2019

08-02-2019

info@oceannet.co.in

08-02-2019

08-02-2019

8755992232

datainfotech100@gmail.
com

11-02-2019

11-02-2019

8755992232

datainfotech100@gmail.
com

11-02-2019

11-02-2019

8755992232

datainfotech100@gmail.
com

11-02-2019

11-02-2019

9821164797

anitasali@ymail.com

11-02-2019

11-02-2019

9833366675

manoharbhatuse@ymail.
com

12-02-2019

12-02-2019

9889808888

netonbspl@gmail.com

12-02-2019

12-02-2019

9820333136

arvind_vispute@rediffm
ail.com

13-02-2019

13-02-2019

<!-- page 5 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

022-65354888

info@microscan.co.in,
shekhar@microscan.co.i
n

13-02-2019

13-02-2019

151

Vovinet Infotech Pvt Ltd.

DS-11/62/2018-DS-III

A

All India

Mr. Chandrashekhar
Balwant Mahant

No. 301-303, Everest Grande, Mahakali
Caves Road, MIDC,, Opp. Ahura Centre,
Andheri East, Mumbai - 400 093,
Maharashtra.

152

Sankrish Systems & Technologies Pvt
Ltd.

DS-11/405/2018-DS-III

B

Mumbai

Mr. Peter Vaz

Haware's Centurion Mall, Off. No. S07/21,
2nd Floor, Sector 19, Plot No. 88 to 91,
Nerul (East), Navi Mumbai, Thane - 400
706, Maharashtra.

7666540021

peter_vaz31@yahoo.com

15-02-2019

15-02-2019

153

Mantram Solutions Pvt Ltd.

DS-11/120/2018-DS-III

B

Bihar

Mr. Kumar Makrand

No. G-8/1, Shatabdi Enclave, Sector 49,
Barola, Noida - 201 301, Uttar Pradesh.

7033444499

mantraminfo@gmail.co
m,
bedi.mspl@gmail.com

20-02-2019

20-02-2019

Mumbai

Mr. Ashish Madhukant
Pabari

C- Wing, Ground Floor, Diamond Swati
Apt, Juju Lane, Andheri West, Mumbai 400 058, Maharashtra.

9892998687

aashish.pabari@gmail.co
m

20-02-2019

20-02-2019

Office No. 11, Neelkantha Villa, Plot No.
38, Sector 19, Kamothe, Navi Mumbai,
Raigarh - 410209, Maharashtra.

9702476055

jenil@3jglobalservices.c
om

25-02-2019

25-02-2019

9619885335

siddhantparab2112@gm
ail.com

25-02-2019

25-02-2019

154

Unisas Netserve Pvt Ltd.

DS-11/326/2018-DS-III

B

155

3J Global Services Pvt Ltd.

DS-11/357/2018-DS-III

B

Maharashtra

Mr. Jenil Selva Jose

156

Siddhant Broadband Pvt Ltd.

DS-11/402/2018-DS-III

B

Mumbai

Mr. Siddhant Parab

No. SH-3, SBI Bakul CHS Ltd, Saibaba
Mandir Marg, Borivali West, Mumbai 400 092, Maharashtra.
Kalyani Niwas 2, Gandhi Nagar, Kopari,
Near ATM, Thane East, Thane - 400603,
Maharashtra.

157

KKM Broadband Internet Pvt Ltd.

DS-11/346/2018-DS-III

B

Mumbai

Mr. Ajinkya Nair

8976133370

nairajinkya@kkmnet.net.
com,
nairajinkya@gmail.com

26-02-2019

26-02-2019

158

Vajrait Services Pvt Ltd.

DS-11/359/2018-DS-III

B

Delhi

Mr. Vikas Gupta

No. F-89A, 1st Floor, Vishwakarma
Colony, M.B. Road, New Delhi - 110 044.

8800135987

kumarvikasgupta@gmail
.com

27-02-2019

27-02-2019

Mr. Jignesh Jagdish
Gadani

No. A/1803, Snow Drop Bldg, Shubhjivan
Road, Opp. Silicon Apartment, Borivali
West, Mumbai - 400 103, Maharashtra.

8828131225

daanishbroadbandpvtltd
@gmail.com

28-02-2019

28-02-2019

159

Daanish Broadband Pvt Ltd.

DS-11/358/2018-DS-III

B

Mumbai

160

Zoram Internet Provider Pvt Ltd.

DS-11/93/2017-DS-III

B

Assam

Mr. Lalthakima

B-5D, Chanmari, Aizwal - 796 007.

9612163464

lalthakima@netsurfis.net

06-03-2019

06-03-2019

161

Kumar Cable Digital Network Pvt
Ltd.

DS-11/450/2018-DS-III

B

Delhi

Gaurav Kumar, Director

House No. 912, Ground Floor, BLK-WZ,
Village Naraina, Delhi, South West Delhi,
Delhi - 110028

9911345388

gaurav_honey9@yahoo.
com

02-05-2019

02-05-2019

9870218777

avid.khan@gmail.com

02-05-2019

02-05-2019

162

Passcom System and Services Pvt Ltd.

DS-11/397/2018-DS-III

B

Mumbai

G-43, Ground Floor, Cine Wonder Mall,
Avid Rauf Khan, Director Kapurbawadijunction , Ghodbunder Road,
Thane, Maharashtra - 400601

163

Passcom System and Services Pvt Ltd.

DS-11/397/2018-DS-III

B

Maharashtra

G-43, Ground Floor, Cine Wonder Mall,
Avid Rauf Khan, Director Kapurbawadijunction , Ghodbunder Road,
Thane, Maharashtra - 400601

9870218777

avid.khan@gmail.com

02-05-2019

02-05-2019

Maharashtra

H. No. 3953, Mehre Nagar, Dabki Road,
Akola Maharashtra - 444 001

8451064010

ganesh@aitcpl.com

03-05-2019

03-05-2019

317, 3rd floor Rishighandha, V. S. Marg,
Bhavesh Vinodbhai Darji,
Opp. Old Post Office, Virar East, Palghar,
Director
Mumbai City, Maharashtra - 401303

9699104446

bhavesh606@gmail.com

03-05-2019

03-05-2019

9953739924

nextiabroadband@gmail.
com

03-05-2019

03-05-2019

9953739924

nextiabroadband@gmail.
com

03-05-2019

03-05-2019

8004973268

11rahulmishra02@gmail
.com

07-05-2019

07-05-2019

8004973268

11rahulmishra02@gmail
.com

07-05-2019

07-05-2019

8004973268

11rahulmishra02@gmail
.com

07-05-2019

07-05-2019

8004973268

11rahulmishra02@gmail
.com

07-05-2019

07-05-2019

82222066500

gauravgit9@gmail.com

08-05-2019

08-05-2019

9833612122

manmeetsokhi@rediffma
il.com

08-05-2019

08-05-2019

2226301584

sunil@stnetwork.in

08-05-2019

08-05-2019

2226301584

sunil@stnetwork.in

08-05-2019

08-05-2019

2226301584

sunil@stnetwork.in

08-05-2019

08-05-2019

09-05-2019

09-05-2019

09-05-2019

09-05-2019

09-05-2019

09-05-2019

10-05-2019

10-05-2019

10-05-2019

10-05-2019

164

Antarjal IT Communication Pvt Ltd.

DS-11/466/2018-DS-III

B

Ganesh Wakode, Director

165

City Network Datacom Pvt Ltd.

DS-11/400/2018-DS-III

B

Mumbai

166

Nextia Broadband Pvt Ltd.

DS-11/408/2018-DS-III

B

Delhi

Vaibhav Vishnoi,
Director

14/447, Vasundhara, Ghaziabad, Uttar
Pradesh - 201 012
14/447, Vasundhara, Ghaziabad, Uttar
Pradesh - 201 012
H. No. 281, Chakbabura, Alimabad
Anshik, Police Station - Naini, The:
Karachhana, Allahabad - 211 009, Uttar
Pradesh.
H. No. 281, Chakbabura, Alimabad
Anshik, Police Station - Naini, The:
Karachhana, Allahabad - 211 009, Uttar
Pradesh.
H. No. 281, Chakbabura, Alimabad
Anshik, Police Station - Naini, The:
Karachhana, Allahabad - 211 009, Uttar
Pradesh.
H. No. 281, Chakbabura, Alimabad
Anshik, Police Station - Naini, The:
Karachhana, Allahabad - 211 009, Uttar
Pradesh.
No. 729, Balaji Mohalla, Parasram Chowk,
Model Town, Yamuna Nagar - 135 001,
Haryana.
No. 62, Ground Floor, Plot No. 424-B,
National Storage, Senapati Bapat Marg,
Mahim, Mumbai - 400 016, Maharashtra.

167

Nextia Broadband Pvt Ltd.

DS-11/408/2018-DS-III

B

Uttar Pradesh (West)

Vaibhav Vishnoi,
Director

168

Prayag Broadband Pvt Ltd.

DS-11/212/2018-DS-III

C

Allahabad

Mr. Rahul Mishra

169

Prayag Broadband Pvt Ltd.

DS-11/212/2018-DS-III

C

Mirzapur

Mr. Rahul Mishra

170

Prayag Broadband Pvt Ltd.

DS-11/212/2018-DS-III

C

Banda

Mr. Rahul Mishra

171

Prayag Broadband Pvt Ltd.

DS-11/212/2018-DS-III

C

Rewa

Mr. Rahul Mishra

172

Abronics Communications Pvt Ltd.

DS-11/323/2018-DS-III

B

Haryana

Mr. Gaurav Garg

173

Hienet Internet Services Pvt Ltd.

DS-11/478/2018-DS-III

B

Mumbai

Mrs. Tanu kaur Sokhi

No. 1, Krishna Kunj, Opp. Carnation
Building, Yari Cross Road, Versova,
Andheri (West), Mumbai - 400 061,
Maharashtra.
No. 1, Krishna Kunj, Opp. Carnation
Building, Yari Cross Road, Versova,
Andheri (West), Mumbai - 400 061,
Maharashtra.
No. 1, Krishna Kunj, Opp. Carnation
Building, Yari Cross Road, Versova,
Andheri (West), Mumbai - 400 061,
Maharashtra.
No. 67/38, Sector 67, Pratap Nagar,
Sanganer Jaipur - 302 033, Rajasthan.

174

S T Network Solutions Pvt Ltd.

DS-11/361/2018-DS-III

B

Mumbai

Mr. Sunil Krishna Salian

175

S T Network Solutions Pvt Ltd.

DS-11/361/2018-DS-III

B

Maharashtra

Mr. Sunil Krishna Salian

176

S T Network Solutions Pvt Ltd.

DS-11/361/2018-DS-III

B

Uttar Pradesh (East)

Mr. Sunil Krishna Salian

177

Bakliwal Telecom Services Pvt Ltd.

DS-11/472/2018-DS-III

C

Jaipur

Mr. Ankit Bakliwal

178

Racsann Technologies Pvt Ltd.

DS-11/474/2018-DS-III

B

Delhi

Mr. Shekhar Tomer

R- 72, East Vinod Nagar, Delhi - 110 091.

9818655436

No. 107, Gudekar Gruh, Room No. 5, S K
Bole Road, Dadar (West), Mumbai - 400
028, Maharashtra.

022-65723380,
9920902952

179

Sri Samarth Infobahn Pvt Ltd.

DS-11/157/2018-DS-III

B

Mumbai

Mr. Nandkumar Raut

180

Megahertz Internet Network Pvt Ltd.

DS-11/460/2018-DS-III

B

Uttar Pradesh (West)

Mr. Prince Kumar

181

S G Broadband Internet Pvt Ltd.

DS-11/350/2018-DS-III

B

Haryana

Mr. Vikram Singh

182

Skyhunt IT Park Pvt Ltd.

DS-11/457/2018-DS-III

B

Haryana

Mr. Deeraj Gandhi

183

Zoram Business Enterprise Pvt Ltd.

DS-11/93/2017-DS-III

B

North East

Mr. Lalthakima

184

Dynowave Technologies Pvt Ltd.

DS-11/482/2018-DS-III

B

Mumbai

Mr. Vivek Bhattacharya

185

Dynowave Technologies Pvt Ltd.

DS-11/482/2018-DS-III

B

Maharashtra

Mr. Vivek Bhattacharya

186

Wi-Sky Infracom Pvt Ltd.

DS-11/427/2018-DS-III

B

Kolkata

Mr. Manoj Kumar Sah

187

DIGIKING COMMUNICATIONS
Pvt Ltd.

DS-11/17/2019-DS-III

B

Kolkata

Mr. AMIT MANDAL

188

DIGIKING COMMUNICATIONS
Pvt Ltd.

DS-11/17/2019-DS-III

B

West Bengal

189

Flixtel Communication Pvt Ltd.

DS-11/458/2018-DS-III

B

Delhi

H. No. 13/8, Prem Nagar, Dehradun, 248
007, Uttarakhand.
Shop No 22, Parjapat Dharamsala,
Assandh, Karnal - 132 039, Haryana.
Near Mehta Park, Jawahar Nagar Camp,
Palwal - 121102, Haryana.
House No. B-5, Chanmari, Aizwal - 796
007, Mizoram.
R. No. 704, Satyam Plaza Building, Nr.
Old Guardian School, Dombivali, Thane 421 201, Maharashtra.
R. No. 704, Satyam Plaza Building, Nr.
Old Guardian School, Dombivali, Thane 421 201, Maharashtra.
No. 20, G.T. Road (New), Post: Rishra,
PS: Rishra, Hooghly - 712 248, West
Bengal.

9116141400

96909090
9253131629

bakliwaltelecom@gmail.
com
shekhar2373@gmail.co
m
nilu104in@yahoo.co.in,
nandkumarraut@yahoo.c
om
sharma_prince@hotmail.
com
shreeganeshbroadbandser
vice@gmail.com

9802101010

bunty0009@gmail.com

10-05-2019

10-05-2019

9612163464

lalthakima@netsurfis.net

10-05-2019

10-05-2019

9029019067

vivekab1979@gmail.co
m

13-05-2019

13-05-2019

9029019067

vivekab1979@gmail.co
m

13-05-2019

13-05-2019

9831135532

manoj.sh99@gmail.com

14-05-2019

14-05-2019

Plot No. GA-90, 1361, Raj Danga Road,
Kolkata - 700078, West Bengal.

8001000879

amit@digikingcommunic
ations.com

15-05-2019

15-05-2019

Mr. AMIT MANDAL

Plot No. GA-90, 1361, Raj Danga Road,
Kolkata - 700078, West Bengal.

8001000879

amit@digikingcommunic
ations.com

15-05-2019

15-05-2019

Mr. Himanshu

Kalaka (177), Rewari - 123401, Haryana.

9728728989

himanshu@flixtel.in

15-05-2019

15-05-2019

<!-- page 6 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

D. No. 14-19-73 (1,2), Shop No 437,438,
4the Floor, Sri Balaji Gold & Silver
Mr. Ponnuri Ravi Kumar
Market, Raja Ramamohan Rai Road,
Chirala, Prakasam - 523155, Andhra
Pradesh.
No. G-8, Bldg No. B-2, Plot No. M-6,
Sahil CHS, Daulat Nagar No. 3, Santacruz
Mr. Mehmood Said Khan
West, Relief Road, Mumbai - 400 054,
Maharashtra.

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

9246467809

ravi.ponnuri@gmail.com

15-05-2019

15-05-2019

9867101015

speednetbroadband@gm
ail.com

16-05-2019

16-05-2019

190

Renu Giga Fiber Pvt Ltd.

DS-11/464/2018-DS-III

B

Andhra Pradesh

191

Speednet Enterprises (OPC) Pvt Ltd.

DS-11/430/2018-DS-III

B

Mumbai

192

Technomex Infocom Systems Pvt Ltd.

DS-11/456/2018-DS-III

B

Mumbai

Mr. Rajdeep Shashikant
Pise

No. 8, 1st Floor, Plot No. 16, Prem
Bhuvan, D L Vaidya Road, Dadar West,
Mumbai - 400 028, Maharashtra.

9619338884

technomexinfo@gmail.c
om

16-05-2019

16-05-2019

193

Jmohit Cable Vision Pvt Ltd.

DS-11/403/2018-DS-III

B

Mumbai

Mr. Mohit Arunkumar
Joshi

Samla Palrav Chawl, Quarry Road, Near
Ramjibhai Patel Chawl, Malad East,
Mumbai - 4500 097, Maharashtra.

9969378542

mohitjoshi2503@gmail.c
om

20-05-2019

20-05-2019

194

Promptnet Broadband Pvt Ltd.

DS-11/356/2018-DS-III

B

Mumbai

No. B 201, 2nd Floor, Hafizi House CHS
Mr. Oese Suleman Jogiya Ltd, S V Road, Jogeshwari West, Mumbai 400 102, Maharashtra.

9699060399/
9223397242

hussainjogiya@gmail.co
m

20-05-2019

20-05-2019

9594080440

memon_shafi@rediffmai
l.com

29-05-2019

29-05-2019

29-05-2019

29-05-2019

195

196

Dreamnet Cable and Internet Pvt Ltd.

Patil ISP Services (OPC) Pvt Ltd.

DS-11/455/2018-DS-III

DS-11/319/2018-DS-III

B

B

Mumbai

Mr. Shafi Anwar
Kotharewala

Mumbai

Mr. Hemant Narayan
Patil

No. LG-26AB, The Mall Shopping Comp,
Station Road, Malad West, Mumbai - 400
064, Maharashtra.
Shop No. 6, Narayan Heritage CHS Ltd. ,
Link Road, Dahisar West, Mumbai - 400
068, Maharashtra.

9892622866

hemantnpatil9999@gmai
l.com

9819073130

dareinternet@gmail.com

03-06-2019

03-06-2019

197

Darer Internet Services Pvt Ltd.

DS-11/463/2018-DS-III

C

Kalyan

Shop No 3, Madhuban Society, Tirthdham,
Jitesh Phulwade, Director Coplex Aadharwadi Road, Kalyan West,
Thane, Maharashtra - 421301

198

Huc Internet Pvt Ltd.

DS-11/453/2018-DS-III

B

Mumbai

Uma Chandrashekara,
Director

Janta Colony, Gali No. 1 Lalji Pada,
Gandhi Nagar, New Link Rd Kandivali
West, Mumbai, Mumbai City, Maharashtra400067.

9967537777

umahebbale@gmail.com

03-06-2019

03-06-2019

Mumbai

Hilda Castelino High School, Gandhi
Roseline Albert Castelino Nagar, Lalji Pada, Kadivali(W), Mumbai,
Mumbai City, Maharashtra - 400 067

9967963211

roseline_castelino@yaho
o.com

03-06-2019

03-06-2019

06-06-2019

06-06-2019

199

200

Rita Infocom Pvt Ltd.

IOT Network and Solution Pvt Ltd.

DS-11/469/2018-DS-III

DS-11/407/2018-DS-III

B

B

Mumbai

Mr. Vighnesh Arvind
Naik

F-9/0:1, Sector 9, Ghansoli, Navi
Mumbai, Thane - 400701, Maharashtra.

9004867801

vighneshnaik53@gmail.c
om

9967301000

info@fastnetbroadband.i
n

10-06-2019

10-06-2019

bdhadam@gmail.com

11-06-2019

11-06-2019

201

Fastnet Wire & Wireless Solutions Pvt
Ltd.

DS-11/355/2018-DS-III

B

Mumbai

Mr. Ranjeet Sube Sing
Rajput

No. 68/69 Ground Floor, Umar Manzil, 5th
Road, Opposite Fish Market, Khar West,
Mumbai - 400052, Maharashtra.

202

Dhadam Hospitality & Sevices Pvt
Ltd.

DS-11/467/2018-DS-III

B

Mumbai

Mr. Balkrishan Ashok
Dhadam

No. 4, Maqbool Mansion, Hawa Hira
Mahal, Pushpa Park, Daftary Road, Malad
East, Mumbai - 400 097 Maharashtra.

9833256161

203

Hightel Digital India Pvt Ltd.

DS-11/243/2018-DS-III

B

Maharashtra

Mr. Premchand Sureshlal
Juni

No. 7-2-140, Itwara, Jawari Line Chouk,
Nanded - 431 604, Maharashtra.

8888826268

hiteldi@gmail.com

12-06-2019

12-06-2019

9962080909

md@ultroncommunicati
ons.in

12-06-2019

12-06-2019

9322215151

akshay_Sali@yahoo.in

13-06-2019

13-06-2019

02260026555,
8108572047

zaheer.1981@gmail.com

13-06-2019

13-06-2019

022-66870600,
9167254221

shekahr@microscan.co.i
n

25-06-2019

25-06-2019

7666636600

ganesh067@yahoo.com

25-06-2019

25-06-2019

02225041714,
9594698424

jadhav.vilas61@gmail.co
m

25-06-2019

25-06-2019

9717435556

manoj@zeonet.co.in

27-06-2019

27-06-2019

Old No. 25, New No. 44, Manavalan
Mr. Ajaydoss Josephdoss Street, Vetri Nagar Extension, Chennai 600 082, Tamilnadu.
No. B-3, Raviraj Apartment, 1st Floor, 3rd
Mr. Akshay Ashok Sali Mamletdar Wadi, Malad (West), Mumbai 400 064, Maharashtra.
Room NO 304, House No. 105, 3rd Floor,
Mr. ZAHEER ZAHOOR Chintamani Niwas, Govind Patel Road,
KHAN
Khar West, Mumbai - 400052,
Maharashtra.
No. A/301-303, Everest Grande, Mahakali
Mr. Chandrashekahar
Caves Road, MIDC, Opp. Ahura Center,
Mahant
Andheri (East), Mumbai - 400 093,
Maharashtra.
No. 602, Amartaru Sakha III, New
Mr. Ganesh Agarwal
Nagardas Road, Andheri (East), Mumbai 400 069, Maharashtra.
FLAT NO. 307-A, BLDG No. 18,
SAISIDDHI CHS, PREMIER AUTO
Mr. VILAS ANIL
COMPOUND, KIROL ROAD, KURLA
JADHAV
WEST, Mumbai - 400 070,
MAHARASHTRA.
No. F-123, Basement, Easyday Building,
Mr. Manoj Kumar
Opp. Punjab National Bank, Vikaspuri,
New Delhi - 110018.

204

Ultron Broadband Pvt Ltd.

DS-11/452/2018-DS-III

B

Tamil Nadu (Including
Chennai)

205

SVCN Services Pvt Ltd.

DS-11/404/2018-DS-III

B

Mumbai

206

ZK INTERNET SERVICE
PROVIDER Pvt Ltd.

DS-11/46/2019-DS-III

B

Mumbai

207

Microscan Orange Braodband Pvt Ltd.

DS-11/307/2017-DS-III

B

Mumbai

208

Raaghav Broadnet Services Pvt Ltd.

DS-11/354/2018-DS-III

B

Mumbai

209

VILAS INTERNET SERVICES Pvt
Ltd.

DS-11/54/2019-DS-III

B

Mumbai

210

AHM Digital Network Pvt Ltd.

DS-11/401/2018-DS-III

A

All India

211

Atma Malik 1313 Internet Services
Pvt Ltd.

DS-11/476/2018-DS-III

B

Mumbai

Mr. Santosh Ramchandra
More

No. C/36, Vakratunda CHS, Plot No. 515,
Sector 5, Charkop, Kandiwali West,
Mumbai - 400 067, Maharashtra.

9821127352

santosh_more67@yahoo.
com

27-06-2019

27-06-2019

212

ICN INTERNET SERVICES Pvt Ltd.

DS-11/51/2019-DS-III

C

Ghaziabad

Mr. ALOK SINGH

No. G-246, SECTOR-63, Gautam Buddha
Nagar, HCL NOIDA, NOIDA - 201 301,
UTTAR PRADESH.

01204535506,
9870293777

alok.singh@icninternet.c
om

27-06-2019

27-06-2019

9870485853

pravinklad@yahoo.com

27-06-2019

27-06-2019

09920207208,
09920207208

unitedstarsnetworks@gm
ail.com

28-06-2019

28-06-2019

9819436667

ajit_aryanshetty@yahoo.
com

28-06-2019

28-06-2019

8446944888

ankush@inspirenetworks
olution.com

19-07-2019

19-07-2019

02225002626,
09820155539

dnsskyinternet@gmail.co
m

26-07-2019

26-07-2019

9987091164

channeliii@hotmail.com

31-07-2019

31-07-2019

9417500606

info@digitax.co.in

21-08-2019

21-08-2019

9711547447

mayuranimation@gmail.
com

21-08-2019

21-08-2019

9005408090

dnetsolns@gmail.com

22-08-2019

22-08-2019

8271175708

bigdatabroadband@gmai
l.com

26-08-2019

26-08-2019

02225971392,
9920401020

ketan.gharat7778@gmai
l.com

27-08-2019

27-08-2019

213

SMPL Networks Pvt Ltd.

DS-11/367/2018-DS-III

B

Mumbai

214

UNITED STARS NETWORK Pvt
Ltd.

DS-11/19/2019-DS-III

B

Mumbai

215

V M Sattellite(OPC) Pvt Ltd.

DS-11/428/2018-DS-III

B

Mumbai

216

217

Inspireit Network Solutions Pvt Ltd.

DS-11/481/2018-DS-III

B

Maharashtra

DNS SKYLINK Pvt Ltd.

DS-11/20/2019-DS-III

B

218

Channel III Internet Pvt Ltd.

DS-11/470/2018-DS-III

B

Mumbai

219

Digitax India Communications Pvt
Ltd.

DS-11/42/2019-DS-III

B

Haryana

220

MSINFINITY ETHERNET
SOLUTIONS Pvt Ltd.

DS-11/48/2019-DS-III

B

Delhi

Mr. MAYUR KUMAR
CHAURASIA

221

DNet E Solutions Pvt Ltd.

DS-11/370/2018-DS-III

B

Uttar Pradesh (East)

Mr. Prashant Misra

222

BIG DATA BROADBAND Pvt Ltd.

DS-11/15/2019-DS-III

B

Bihar

Mr. PARTH

Mumbai

Mr. KETAN BANDHU
GHARAT

223

KGS NETWORKS Pvt Ltd.

DS-11/64/2019-DS-III

B

Mumbai

No. 2A, Jeevan Adhar Sangh Chawl,
Mr. Pravin Karsan Lad
Tejpal Scheme Road No. 5, Vile Parle
East, Mumbai - 400057, Maharashtra.
SHOP No. 2, Ground Floor, Plot No. 120,
Mr. MOHAMMED
AMINA KHATUN, KALPANA
ABBAS SHAIKH
CINEMA, MUMBAI - 400 008,
Maharashtra.
No. 6/B, Plot No. 167, Shakti Appartments
CHS Ltd, Cardinal Gracious Road,
Mr. Ajit Diwakar Shetty
Chakala, Andheri East, Mumbai - 400 099,
Maharashtra.
Flat No. B-1-1004, Survey No. 33/1,
Mr. Ankush Ashok
Miami Majestic Properties, Wadgaon
Salagaonkar
Khurd, Pune - 411 041, Maharashtra.
STALL No. 26, PADMA PRABHU, LBS
Mr. DATTARAM
MARG, NEAR SHREYAS CINEMA,
BABAN CHOUDHARI
MUMBAI.
No. 126, Hill Road, Off Somnath Lane,
Mr. Peter John Saldanha
Bandra (West), Mumbai - 400 050,
Maharashtra.
Mr. Pawanpreet Singh No. SCO 198, Opp. Sports Stadium, Sector
Dhaliwal
7C, Chandigarh - 160 019.
No. 9/4649, S/F, STREET NO. 3, AJIT
NAGAR, SUBHASH MOHALLA
GANDHI NAGAR, DELHI - 110 031.
No. 294/7, Asharaf Tola Bhag 3, Hardia 241 001, Uttar Pradesh.
Near Bank of Maharashtra, New Area,
Aurangabad - 824 101, BIHAR.
No. 501/1, SAI ICHHA NIWAS,
GHODBUNDER ROAD, WAGHBIL,
Thane - 400 615, MAHARASHTRA.

<!-- page 7 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

224

PANTI FTTH Pvt Ltd.

225

Acushnet Communication Pvt Ltd.

License No.

DS-11/65/2019-DS-III

DS-11/352/2018-DS-III

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

02225133858,
8779303565

nikhil_enterprises1966@
yahoo.co.in

27-08-2019

27-08-2019

7778962000

swadhinmehta09@gmail.
com

02-09-2019

02-09-2019

9920993212/02226 sanjaysaagar@gmail.co
321648
m

05-09-2019

05-09-2019

9725266770

laxmi.livevision@gmail.
com

06-09-2019

06-09-2019

9820000321

kazimsayyed@yahoo.co
m

23-09-2019

23-09-2019

8066958203

guruprasad@micronovai
mpex.com

23-09-2019

23-09-2019

8066958203

guruprasad@micronovai
mpex.com

23-09-2019

23-09-2019

8066958203

guruprasad@micronovai
mpex.com

23-09-2019

23-09-2019

09722216222,
9722216222

fastcomtelelink@gmail.c
om

24-09-2019

24-09-2019

24-09-2019

24-09-2019

25-09-2019

25-09-2019

26-09-2019

26-09-2019

05-11-2019

05-11-2019

05-11-2019

05-11-2019

20-02-2020

20-02-2020

B

Mumbai

Mr. MANOHAR
PADMAKAR PATIL

No. 349, RAKHAMAI BUNGLOW, OPP.
GARIB NAGAR, POKHARAN ROAD
NO. 1, Thane - 400615, Maharashtra.

B

Gujarat

Swadhin Gunvatrai
Mehta

Goverdhan Chamber, 2nd Floor, C/123,
Savarkundla, Amreli, Gujarat - 364515

226

Saagars Channel Pvt Ltd.

DS-11/324/2018-DS-III

B

Mumbai

Mr. Sanjay Shyam Sagar

227

Wincom Telelink Pvt Ltd.

DS-11/396/2018-DS-III

C

Bhuj

Mr. Mukesh Patel

228

Citicable Infomedia Pvt Ltd.

DS-11/247/2018-DS-III

B

Maharashtra

Mr. Kazim Ali Sayed

229

230

Micronova Telesystems Pvt Ltd.

Micronova Telesystems Pvt Ltd.

231

Micronova Telesystems Pvt Ltd.

232

FASTCOM TELELINK PRTVATE
LIMITED

DS-11/431/2018-DS-III

DS-11/431/2018-DS-III

DS-11/431/2018-DS-III

DS-11/93/2019-DS-III

B

B

B

C

Delhi

Mr. Raghanna
Guruprasad

Mumbai

Mr. Raghanna
Guruprasad

Tamil Nadu

Mr. Raghanna
Guruprasad

Nadiad

Mr. RAJATBHAI
UPENDRABHAI
PARIKH

233

LEROY NETWORKS AND
SERVICES Pvt Ltd.

DS-11/213/2017-DS-III

B

Mumbai

234

AEROLINK BROADBAND Pvt Ltd.

DS-11/94/2019-DS-III

C

Kalyan

235

Riyanka Internet Services Pvt Ltd.

DS-11/280/2018-DS-III

B

Mumbai

236

MICRONET IT SERVICES Pvt Ltd.

DS-11/119/2019-DS-III

B

Rajasthan

237

SHAILDHAR TELECOM
SERVICES Pvt Ltd.

DS-11/90/2019-DS-III

B

North East

238

YTEL BROADBAND Pvt Ltd.

DS-11/89/2019-DS-III

B

Delhi

239

S S FIBER NET OPTICAL
COMMUNICATION Pvt Ltd.

DS-11/123/2019-DS-III

C

Narnaul

702-A, OM Apartments, Sundervan
Complex, Andheri(West), Mumbai City,
Maharashtra - 400053
Shop No. 3, Plot No. 793A, W. 9B,
Gandhidham, Taluka Gandhidham,
Kachchh - 370 201, Gujarat.
Room No. 04, Yunus Badruddin Chawl,
Azad Nagar, Pailipada, Trombay, Mumbai 400088, Maharashtra.
No. 89/2, Gandhi Bazaar Main Road,
Basavangudi, Bangalore - 560 004,
Karnataka.
No. 89/2, Gandhi Bazaar Main Road,
Basavangudi, Bangalore - 560 004,
Karnataka.
No. 89/2, Gandhi Bazaar Main Road,
Basavangudi, Bangalore - 560 004,
Karnataka.
DEVNI POLE, KHAMBIIAT, Anand 388620, GUJARAT.

No. 1ST FLOOR, SHETH SATAR
CHAWL, STUDIO COMPOUND,
Mr. LAZARUS
09773180090,
lazarusdsouza@yahoo.co
BEHIND KALINA MASJID,
DSOUZA
9773180090
m
SANTACRUZ EAST, MUMBAI 400098, MAHARASHTRA.
Malpatta No. 3005826, Padmanabh Swami
08655332452,
aerolinkbroadband@gma
Mr. Amit Mahesh Desle
Road, Tembhode, PALGHAR, Thane 8668876952
il.com
401 404, MAHARASHTRA.
Room No. 5, Yadgar Apartment, Patel
Mr. Ashok Gabaji
Pakhadi Lane,Yari Road, Next to Tahir
riyankacabletitu2@gmail
9967414644
Satpute
Mutton Shop, Andheri(W) Vesava,
.com
Mumbai - 400 061, Maharashtra.
Civil Hospital Road, Loharu, Bhiwani - 01664297297,9991
ROHTASH, Director
rohtash@micronet.in
127 201, HARYANA.
266640
Mr. Shailendra Kumar
D-7/ 7238, Vasant Kunj, South West
01140190643,
info@shaildharSingh
Delhi, DELHI - 110 070.
9810273680
india.com
B-290, S/F, NEW ASHOK NAGAR,
PRADEEPJHA200@gm
PRADEEP KUMAR JHA
8586014214
DELHI -110 096.
ail.com
Mr. VIVEK SOTI

No. F-613, RIICO INDUSTRIAL AREA,
PHASE-1, BHIWADI, DISTT. ALWAR 301019, RAJASTHAN.

9587171209

viveksoti@gmail.com

24-02-2020

24-02-2020

9560075597

rohit@rocketwifi.co.in,
rohitdynamics@gmail.co
m,
amiya@rocketwifi.co.in

25-02-2020

25-02-2020

240

VORRUCKEN NETWORKS Pvt
Ltd.

DS-11/126/2019-DS-III

B

Assam

Mr. Rohit Kakati

No. A1, SWAGAT APARTMENT,
KARBI PATH, ZOO NARENGI ROAD,
BAMUNI MAIDAN, Kamrup - 781021,
ASSAM.

241

NET ON NEXT ERA
COMMUNICATIONS PVT LTD

DS-11/44/2019-DS-III

B

Delhi

ABHISHEK,
DIRECTOR

43 TOP FLOOR KRISHNA MARKET,
NEAR DURGESH AND SONS, Kalkaji
South Delhi,DELHI - 110 019

01141055933,
9213951291

INFO@ASSUREASSIS
TANCE.IN

02-03-2020

02-03-2020

9545013636

vdassociates36@gmail.c
om

03-03-2020

03-03-2020

242

CLOUDINSTA24 SERVICES Pvt
Ltd.

DS-11/125/2019-DS-III

C

Pune

Vipul Vikas Deshpande,
Director

Vidya Deshpande, Om Avishkar Society,
S. No. 123 Near MIT College, Paud Road,
Kothrud, Pune - 411 030,
MAHARASHTRA.

243

Ioeaccess Communications Pvt Ltd.

DS-11/320/2018-DS-III

C

Ernakulam

Vishnu Rajendran

GS2, HEAVENLY Plaza, Padamughal,
Kakkanad Ernakulam, Kerala - 682021

9656722244

work@accessioe.in

04-03-2020

04-03-2020

244

Telstra Telecommunications Pvt Ltd.

DS-11/113/2019-DS-III

A

All India

Anish Kohli, Director

Times Square, Unit-4, B Wing, 3rd Floor,
Andheri Kurla Road, Andheri East,
Mumbai - 400 059, MAHARASHTRA.

01166192000,
9810095444

Amit.keshari@team.telst
ra.com

05-03-2020

05-03-2020

245

RNET GIGAFIBER Pvt Ltd.

DS-11/146/2019-DS-III

B

MUMBAI

Mr. Kanakraj Vadivel
Swami

Room No.27, Kuppu Swami Chawl, Satya
Nagar, 90 Road Sakinaka, Kurla W,
Mumbai - 400072, MAHARASHTRA.

9619888921

rajcablenetwork@gmail.
com

05-08-2020

05-08-2020

246

DHUNI NETSOL Pvt Ltd.

DS-11/174/2019-DS-III

B

Gujarat

NAME: Hitpal Rajput,
Director

B-1111 Empire Business Hub, Sciencecity
Road, Sola, Ahmedabad, Gujarat
Ahmedabad GUJARAT 380060

9909510949

sandeep0189@yahoo.co
m

09-08-2020

09-08-2020

247

SRI BALAJI INTERNET Pvt Ltd.

DS-11/226/2019-DS-III

C

Nellore

Mr. Gopi Somisetty

No. 12-150, MEDPLUS UPSTAIRS,
HOSPITAL ROAD, GUDUR, NELLORE 524 101, Andhra Pradesh

9849899964

gopi9849899964@gmail
.com

10-08-2020

10-08-2020

9594361868

chandanw1974@gmail.c
om

11-08-2020

11-08-2020

9004866583

dattatraya.kate@gmail.c
om

11-08-2020

11-08-2020

9869784739

chandnicablevision@gm
ail.com

12-08-2020

12-08-2020

sundar@cfnet.in

14-08-2020

14-08-2020

17-08-2020

17-08-2020

17-08-2020

17-08-2020

248

EYE FASTNET SERVICE Pvt Ltd.

DS-11/151/2019/DS-III

B

249

SAMMY NETWORKS Pvt Ltd.

DS-11/149/2019/DS-III

B

250

VIVEK NETWORK Pvt Ltd.

DS-11/43/2019/DS-III

B

Cfiber Communications Pvt Ltd.

DS-11/353/2018-DS-III

B

DS-11/109/2019-DS-III

B

DS-11/185/2019-DS-III

B

251
252
253

254

COMMONBEE BROADBAND Pvt
Ltd.
KAVYA INTERNET SERVICES Pvt
Ltd.
EKOWEBTECH IT SERVICES Pvt
Ltd.

DS-11/228/2019-DS-III

B

No. 249B, Mezanine, 1st Floor, R.C.
Mr. CHANDAN
Barrack 21, Near Inlaks Hospital,
MUMBAI
GOPALDAS WADHWA
Chembur Colony, Chembur, Mumbai,
Maharashtra - 400 074.
No. 3D/2008, New Hind Mill Mahada
Mr. Dattatraya Anadrao
Colony, R.B. Marg, Ghodapdev, Tank
MUMBAI
Kate
Road, Mumbai - 400 033,
MAHARASHTRA.
House No. 07, Collector CHL, R K Mandir
Road, Kondivita Lane, Near Shivsena
MUMBAI
Mr. SUHAS G KELKAR
Office, Andheri East, Mumbai - 400 059,
Maharashtra.
Door No.26 (22), First Floor, Laporte
Tamil Nadu (including Chennai) Mr. K. Sundara Vadivel Street, Puducherry P.O., Pondicherry - 605
001.
No. WZ - 45, RAM NAGAR, NEW
DELHI
Manpreet Singh
DELHI - 110 018.
House No 2086, Ground Floor,Village
DELHI
KAPIL DEV
Alipur, Delhi - 110 036.

DELHI

Kaushal

255

SUN BROADBAND AND DATA
SERVICES Pvt Ltd.

DS-11/87/2019-DS-III

C

Raipur

SUDHIR DONGRE

256

A K INTERNET Pvt Ltd.

DS-11/148/2019-DS-III

B

MUMBAI

Prakash Sadashiv
Gaikwad

257

KREANSH NETSOL Pvt Ltd.

DS-11/213/2019-DS-III

B

MUMBAI

SAMEER SHIVLAL
CHOUDHARY

258

NEAM COMMUNICATIONS Pvt
Ltd.

DS-11/147/2019-DS-III

C

Pune

Mr. Sanjeev Ramesh
Mohan

No. 425A, SRS TOWER, NEAR MEWLA
MAHARAJPUR METRO STATION,
G.T. ROAD, FARIDABAD - 121 003,
HARYANA.
CG ELITE, TOP FLOOR - A, OPP.
MANDI GATE, RAM MANDIR RD,
PANDRI, RAIPUR - 492001,
CHHATTISGARH.
No. 4, Ground Floor, Plot No. 18/22,
Sabuwala Building, 15th Lane,
Kamathipura, Mumbai - 400 008,
MAHARASHTRA.
VIJAY BHUVAN, A.S MARG, IIT
POWAI, BEHIND POOJA BENGALI
SWEET, Mumbai - 400 076,
MAHARASHTRA.
Row House No. 131, Cloud 9, Kondhwa
Khurd, S. No. 46/1/3 AND 46/1/2, NIBM
Road, Pune - 411048, Maharashtra.

7867000996
7053489177
8447924809

manpreet.sanghera24@g
mail.com
kavyainternetservices@g
mail.com

8907107477

infotel.deepakgs@gmail.
com

18-08-2020

18-08-2020

9711613662

info4isp@gmail.com

19-08-2020

19-08-2020

9892414489

a.kinternet429@gmail.co
m

21-08-2020

21-08-2020

9320589333

dotnetsolutions0912@g
mail.com

21-08-2020

21-08-2020

9225546465

neamcommunications@g
mail.com

27-08-2020

27-08-2020

<!-- page 8 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

259

NEXTEL WIRELESS Pvt Ltd.

DS-11/143/2019-DS-III

C

Muzaffarpur

Mr. KUMAR SUJIT

260

VISHWAKARMA BROADBAND
Pvt Ltd.

DS-11/199/2019-DS-III

C

Pune

PRAVIN BALLADKAR

261

WCT SOLUTIONS Pvt Ltd.

DS-11/142/2019-DS-III

B

GUJARAT

Mr. DHAVALKUMAR
PUNJABHAI
BHARVAD

262

I-Soft Networks Pvt Ltd.

DS-11/351/2018-DS-III

B

MAHARASHTRA

Farook Gulam Shaikh

Nasik

Mr. Mohammad Shahid
Mohammad Yaqoob

Registered Office Address
Sonwati Colony, Dumra Road, Mahsaul
ufr, Rampur Lachmi, SITAMARHI - 843
302, Bihar.
FL No. 18, PL No. 75, SECTOR 3,
WOOD ROSE APPARTMENT,
INDRAYANI NAGAR, BHOSARI,
PUNE - 411039, MAHARASHTRA
FF 121, GAJANAND COMPLEX, OLD
PADARA ROAD, VADODARA - 390
020, GUJARAT.
Nancy Lake Homes Sr.No. 08, Katraj
Pune, Maharashtra -411046
S. No. 69, PLOT No. 57 ISLAMPURA
WARD, BEHIND APNI SIZING,
MALEGAON, Nashik - 423 203,
MAHARASHTRA.
Mr. 10/150 Khalasi Line, Gwaltoli,
Kanpur - 208 001, Uttar Pradesh.

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

8470017573

info@nextel.co.in

27-08-2020

27-08-2020

9422548854

Email Id:
balladkarpm@gmail.com

03-09-2020

03-09-2020

9711613662

Email Id:
info4isp@gmail.com

07-09-2020

07-09-2020

9923275007

shaikh.farook21@yahoo.
co.in

10-09-2020

10-09-2020

9226262082

shahidyaqoobzaptic@gm
ail.com

10-09-2020

10-09-2020

263

ZAPTIC Pvt Ltd.

DS-11/214/2019-DS-III

C

264

AARAADHANA INTERNET
SERVICES Pvt Ltd.

DS-11/173/2019/DS-III

B

UTTAR PRADESH (EAST)

Mr. Vijay Gupta

9336112650

acnonline18@gmail.com

11-09-2020

11-09-2020

265

Ashoka Netsol Pvt Ltd.

DS-11/434/2018-DS-III

B

UTTAR PRADESH (WEST)

Netrapal Singh,
DIRECTOR

H.no 738, Executive Apartment Bhawna,
Estate Near Nayati Hospital Sikandra,
Agra Uttar Pradesh - 282007

Contact No:
8938941234

NETRAPAL007@GMA
IL.COM

14-09-2020

14-09-2020

266

ANS BROADBAND SERVICES Pvt
Ltd.

DS-11/110/2019-DS-III

B

RAJASTHAN

MANISH KUMAR
ARORA

No. E-367, RANJEET NAGAR,
BHARATPUR - 321 001, RAJASTHAN.

7014727737

ANSBROADBAND@G
MAIL.COM

16-09-2020

16-09-2020

MAJID SULEMAN
MOTORWALA

No. 62, GREEN PARK - 1, KOSAMBA
ROAD, BHAGDAWADA, VALSAD 396 001, GUJARAT.

9727772547

majid.motorwala@yahoo
.com

16-09-2020

16-09-2020

9822375197

superimpex23@gmail.co
m

21-09-2020

21-09-2020

9820126824

hitzchannel@gmail.com

22-09-2020

22-09-2020

9048274020

brahmadattan@gmail.co
m

30-09-2020

30-09-2020

7977869939

jnstarsinternetnetwork@
gmail.com

30-09-2020

30-09-2020

9434540159

goyal.harikishan@gmail.
com

12-10-2020

12-10-2020

01143792000,
9313499695

ambikasharma616@gma
il.com

15-10-2020

15-10-2020

9818183089

mandeep_220n@rediffm
ail.com

15-10-2020

15-10-2020

9923113882

rkdigitalcable@gmail.co
m

15-10-2020

15-10-2020

7588319626

tellstarnetworks@gmail.c
om

15-10-2020

15-10-2020

9146456777

shindelokesh079@gmail.
com

15-10-2020

15-10-2020

zbiswas@ascsc.in

16-10-2020

16-10-2020

267

SPEEDOLINK DATA SOLUTION
Pvt Ltd.

DS-11/261/2019-DS-III

B

GUJARAT

268

BREITBAND TECHNOLOGIES Pvt
Ltd.

DS-11/175/2019-DS-III

C

Pune

269

Space Hitznetwork Pvt Ltd.

DS-11/399/2018-DS-III

B

MUMBAI

270

AMBITION NETWORK
SOLUTIONS INDIA Pvt Ltd.

DS-11/236/2019-DS-III

B

MAHARASHTRA

271

JNSTARS INTERNET NETWORK
Pvt Ltd.

DS-11/176/2019-DS-III

B

MUMBAI

272

MORE WIFI INTERNET Pvt Ltd.

273

AAACLOUD TELEPHONY Pvt Ltd. 206-13/DDG(T)/DLSA/2020-21

274

G V TELECOM Pvt Ltd.

275

GEGA BROADBAND SOLUTION
Pvt Ltd.

276

TELLSTAR NETWORKS Pvt Ltd.

DS-11/72/2020-DS-III

206-14/DDG(T)/DLSA/2020-21

DS-11/18/2020-DS-III

DS-11/17/2020-DS-III

No. SR 27/29, BEHIND VITTHAL
Mr. Mohan Gokhale
MANDIR, KARVE NAGAR, Pune - 411
052, MAHARASHTRA.
No. R-704, F-7, Rajendra Vihar, Khetwadi,
Mr. Pravin Patel
12th Lane, Girgoan, Mumbai - 400 004,
Maharashtra.
No. 214, MAHALAXMI METRO
Radhakrishnan Shyamala
SQUARE, JOGESHWARI LANE,
Manusudhan
LAXMI ROAD, BUDHWAR PETH,
PUNE - 411 002, Maharashtra.
MR. SHEHBAZ
HAFEEZ KHAN

C

Darjeeling (Siliguri)

Mr. Hari Kishan Goyal

A

All India

AKHIL KHERA

B

C

A

Delhi

NAVEEN TYAGI

Ratnagiri

FARIDA RAZZAK
KAZI

All India

PRASHANT
DATTATRAY
THAKARE

CHAWL NO 3, ROOM NO. 69, BHOLE
NAGAR, NEAR MIG COLONY, PIPE
ROAD, KURLA WEST Mumbai - 400
070, MAHARASHTRA.
G-Floor, Sikder Bhawan, 264-B, Jatin Das
Sarani, Ashram Para Darjeeling - 734 001,
West Bengal.
No. F-1/9, 2ND FLOOR, OKHLA
INDUSTRIAL AREA PHASE I, NEW
DELHI - 110 020.
KH No. 349/2 EXTN, LAL DORA, 2nd
Floor, MAIN
ROAD, BURARI, DELHI - 110 084.
H. No. 786, RK Mansion, Rajaprkar
Colony, Udyam Nagar, Ratnagiri 415612, Maharashtra.
No. F1, Sudaiv Apartments, 48, Kahire
Colony, Deopur Dhule - 424 002,
Maharashtra.
C/O SHAMRAO PARSHURAM
PAWAR, CTS 686 A, Guru Alankar, Shop
No. UGR-2, Guruwar Peth, Satara - 415
002, Maharashtra.
COLLEAGE PARA, AURANGABAD
P.O., Murshidabad, West Bengal - 742
201.

277

TLN COMMUNICATION Pvt Ltd.

DS-11/121/2019-DS-III

B

MAHARASHTRA

LOKESH SHINDE

278

A.S.C.S.C. DIGITAL Pvt Ltd.

DS-11/184/2019-DS-III

B

WEST BENGAL

ZIAUDDIN BISWAS

279

Exactel Cellular Pvt Ltd.

DS-11/63/2020-DS-III

B

Jammu & Kashmir

Vikram Singh

Ward No. 56, Khasra No. 251, Thakur
Complex, Near Janta Flour Mill, Gangyal,
Jammu - 180 010, Jammu & Kashmir.

7298970901

vikram_jammu@yahoo.c
om

19-10-2020

19-10-2020

Ratnesh Kumar

BUDHIJEEVI COLONY, ROAD NO 9,
NEAR 70 FEET, ANISHABAD, Patna 800 002, BIHAR.

8102936083

ratnesh98@gmail.com

21-10-2020

21-10-2020

Mr. Prashant G
Ghadigavkar

SH No. G-11, OM Sai Ram CHS Ltd. 11A, Saiwadi Sahar Road, Andheri East
Mumbai - 400 069, MAHARASHTRA.

9769590189

santoshnetwork2207@g
mail.com

22-10-2020

22-10-2020

Mr. Yogesh Dileep
Dusane

No. 29 YASHO DHAN COLONY,
WALWADI SHIWAR, DHULE - 424001,
Maharashtra.

9764441644

yogesh595@gmail.com

27-10-2020

27-10-2020

Mr. Sheetalprasad
Gulabcxhansd Gupta

HOUSE NO. B-3/002, BONSARI
VILLAGE, GANPATI PADA, TURBHE
Thane - 400 705, MAHARASHTRA.

7039000195

omcablenet2@gmail.com

27-10-2020

27-10-2020

Arun Kumar Singh

Behind Shivam Colour Lab, Hotel
GuruKripa, Jhansi - 284 003, Uttar
Pradesh.

9889401007

mabasafenetbroadband@
gmail.com

29-10-2020

29-10-2020

Mr. LAKHAN SINGH

4TH FLOOR, 195, SECTOR 9, U.I.T.,
BHIWADI, ALWAR - 301019, Rajasthan.

8003950505

bhanupratap_789@yaho
o.com

04-11-2020

04-11-2020

UTTAR PRADESH (WEST)

Mr. BHARAT SINGH

Chanda Complex, Mursan Gate,
HATHRAS, Uttar Pradesh - 204 101

9639393330

bharatnetworkisp@gmail
.com,bharat@bharatnetw
ork.in

05-11-2020

05-11-2020

A-11/203, GANGOTRI CHS, SECTOR18, NERUL, NAVI MUMBAI - 400 706,
Thane MAHARASHTRA.

9892932103

hanumant_lawand@yah
oo.co.in

06-11-2020

06-11-2020

A-11/203, GANGOTRI CHS, SECTOR18, NERUL, NAVI MUMBAI - 400 706,
Thane MAHARASHTRA.

9892932103

hanumant_lawand@yah
oo.co.in

06-11-2020

06-11-2020

8169933736

harsh@3sp.in

09-11-2020

09-11-2020

8169933736

harsh@3sp.in

09-11-2020

09-11-2020

9812961296

sbnkundli@gmail.com

10-11-2020

10-11-2020

9343770031

NAGARAJ@VELANK
ANIGROUPS.COM

10-11-2020

10-11-2020

9167041990

naresh_pangerkar@yaho
o.com

12-11-2020

12-11-2020

9440281452

gigabytefibernet@g
mail.com

18-11-2020

18-11-2020

280

281

282

RAJNET CARE Pvt Ltd.

SANTOSH CABLE NETWORK
AND DATA COM Pvt Ltd.
INFINITE BROADNET
SOLUTIONS Pvt Ltd.

283

O M INTERNET BROADBAND
SERVICE Pvt Ltd.

284

MABA SAFENET BROADBAND
SERVICES Pvt Ltd.

285

RIZEL G FIBER
NEXTGENBROADBAND
SOLUTIONS Pvt Ltd.

286

BHARAT DIGITAL NETWORK Pvt
Ltd.

DS-11/31/2020-DS-III

DS-11/229/2019-DS-III

DS-11/61/2020-DS-III

DS-11/37/2020-DS-III

DS-11/211/2019-DS-III

DS-11/124/2019-DS-III

DS-11/41/2019-DS-III

C

B

B

B

B

C

B

Patna

MUMBAI

MAHARASHTRA

MUMBAI

Uttar Pradesh (East)

Alwar

287

HIGH SPEED INFOMEDIA Pvt Ltd.

DS-11/65/2020-DS-III

B

Mumbai

HANUMANT
BALIRAM LAWAND

288

HIGH SPEED INFOMEDIA Pvt Ltd.

DS-11/65/2020-DS-III

C

Satara

HANUMANT
BALIRAM LAWAND

289

HYOSEC SOLUTIONS Pvt Ltd.

DS-11/201/2019-DS-III

B

Madhya Pradesh

Mr. HARSH LODHA

290

HYOSEC SOLUTIONS Pvt Ltd.

DS-11/201/2019-DS-III

B

North East

Mr. HARSH LODHA

291

292

HANUMAT NETWORKS Pvt Ltd.

VELANKANI TELECOM Pvt Ltd.

DS-11/35/2020-DS-III

DS-11/157/2019-DS-III

B

A

HARYANA

All India

293

SHARMILA ENTERPRISE Pvt Ltd.

DS-11/238/2019-DS-III

B

MUMBAI

294

GIGABYTE FIBERNET Pvt Ltd.

DS-11/263/2019-DS-III

C

Cuddapah

6A, Federation House, A Poddar Marg,
Opp. Metro Cinema, Mumbai - 400002,
Maharashtra.
6A, Federation House, A Poddar Marg,
Opp. Metro Cinema, Mumbai - 400002,
Maharashtra.

Mr. RAKESH KUMAR

Shop No. 1, First Floor, Dahiya Market,
Kundli, Sonepat - 131 029, Haryana.

Mr. H NAGARAJ

No.43, Electronics City Phase I, Hosur
Road, Bangalore - 560 100, Karnataka.

No. B-1103, Om Sai Tower, Santoshi Mata
Mr. VAIBHAV SUDHIR Road, Bhandare Wadi, Opp. Sai Temple,
SALVI
Dahisar West, Mumbai - 400 068,
Maharashtra.
G MADHU
SUDHANA
REDDY

D.No. 41-1446, SANKARAPURAM,
KADAPA - 516 004,
Andhra Pradesh.

<!-- page 9 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

No. 34-1-3/5, DODDIPTALATHOTA
STREET, Tanuku - 534211, West
Godavari Dist, Andhra Pradesh.

9701197779

kotasrikant@yahoo
.co.in

18-11-2020

18-11-2020

9886635117

balajifibernet4@gmail.co
m

19-11-2020

19-11-2020

295

VENKATA SAI INTERNET Pvt Ltd.

DS-11/212/2019-DS-III

C

Eluru

Kota Srikanth

296

BALAJI FIBRENET Pvt Ltd.

DS-11/270/2019-DS-III

B

Karnataka

Shyam Sunder Langote

297

SRI COMMUTECH Pvt Ltd.

DS-11/235/2019-DS-III

B

Karnataka

Mr. Dharmaraju Solasa

298

PREFIX INFOTECH Pvt Ltd.

DS-11/234/2019-DS-III

B

Delhi

Mr. Hemant

MPL 1-10-134, Floor II, Kallur Colony,
Station Road, Raichur - 584 101,
Karnataka.
Flat No. A-206, 2nd Floor, Prakruthi
Enclave, Shirdi Sai Layout, 2nd Main,
Medahalli, Virgonag, Bangalore - 560 049,
Karnataka.
PLOT NO. 42, Kh. No. 99/17, JAIN
NAGAR EXTN, BLK-D, KARALA, Delhi
- 110 081.
H NO.2-2-193, WEEKLY BAZAR,
JAGTIAL, Karimnagar, Telangana, india,
505327 Karimnagar TELANGANA
505327
No. 89/2, Gandhi Bazar Main Road,
Basavangudi Bangalore - 560 004,
KARNATAKA.

9986899916

dharma4304@gmail.co
m

20-11-2020

20-11-2020

01171859649,
9911544147

prefixinfotech2019@gm
ail.com

25-11-2020

25-11-2020

Contact No:
9030435143

Email Id: info@svnet.in

02-12-2020

02-12-2020

Contact No:
9899747425

guruprasad@micronovai
mpex.com

03-12-2020

23-09-2019

299

SVN GIGAFIBER Pvt Ltd.

DS-11/ 270/2019-DS-III

C

Karimnagar

RAPARTHI VINAY
KUMAR, DIRECTOR

300

MICRONOVA TELE SYSTEMS Pvt
Ltd.

DS-11/477/2018-DS-III

A

All India

Raghanna Guruprasad

Kannamwar Nagar 2, Near Building No
190A, Shivai Chowk, Vikhroli EAST,
Mumbai - 400 019, MAHARASHTRA.

9869630870

ankulsh792@gmail.com

08-12-2020

08-12-2020

301

PRONET Pvt Ltd.

DS-11/108/2019-DS-III

B

MUMBAI

Mr. ANKUR
KULSHRESTHA

302

DENSIS ONLINE Pvt Ltd.

DS-11/77/2020-DS-III

B

Andhra Pradesh

Mr. HANUMAPPA
PONNAM

H No. 3-4-391, Plot No. 6, Laxmi Nagar
Colony, West Marredpally, Secunderabad,
Hyderabad - 500 026, Telangana.

9985699911

densistelecom@gmail.co
m

09-12-2020

09-12-2020

9136128151

yashrajpatel83@gmail.c
om

21-12-2020

21-12-2020

303

Patel Internet Pvt Ltd.

DS-11/454/2018-DS-III

B

MUMBAI

Mr. Yash Raj Bharat
Patel

No. 601, Renis CHS Ltd, Link Road,
Chincholi Bunder, Opp. Greens Restaurant,
Malad West, Mumbai - 400 064,
Maharashtra.

304

JETONE FIBER Pvt Ltd.

DS-11/245/2021-DS-III

B

MUMBAI

NAME:MANOJ
BABULAL GAWLI
Designation:DIRECTOR

102, ANCHOR HOUSE, 33TH ROAD,
OLD KHAR, KHAR W, Mumbai City
MAHARASHTRA 400052

Contact No:
8788467865

Email Id:
moreyash665@gmail
.com

09-01-2021

09-01-2021

305

MAHALAXMI CYBERNETIC Pvt
Ltd.

DS-11/174/2020-DS-III

B

MUMBAI

NAME:HEROLD
GEORGE BORGES
Designation:DIRECTOR

104, PARAS PLAZA CHS LTD, NEAR
GOLDEN NEST, MIRA BHAINDER
ROAD, MIRA ROAD EAST Thane
MAHARASHTRA 401107

Contact No:
9769267199

Email Id:
jinish.kapadia@gmai
l.com

09-01-2021

09-01-2021

306

SKYNEE INTERNET SERVICE Pvt
Ltd.

DS-11/106/2020-DS-III

B

Mumbai

NAME:SHSHNAWAZ
SOHEB MEMON
Designation:DIRECTOR

SAYYED YUSUF TAILOR CHAWL,
SHAKTI NAGAR, NEAR UJALA
NAGAR BUILDING, OSHIWARA,
JOGESHWARI WEST Mumbai City
MAHARASHTRA 400102

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yah oo.co.in

25-01-2021

25-01-2021

307

TAIBA SUPER INTERNET Pvt Ltd.

DS-11/42/2020-DS-III

B

Mumbai

NAME:MOHAMMED
SALIM KODAI
MANIYAR
Designation:DIRECTOR

NG-97-1/2,AKBARLALA COMPOUND,
AZAD NAGAR, NEAR BABU CABLE
NETWORK, DVD ROAD NO. 4
GHATKOPAR WEST Mumbai City
MAHARASHTRA 400086

Contact No:
9223900000

Email Id:
maniyar1964@gmail.co
m

25-01-2021

25-01-2021

308

BHORER ALO CABLE AND
BROADBAND Pvt Ltd.

DS-11/231/2019-DS-III

B

KOLKATA

NAME:Lokesh Agarwal
Designation:Director

29/2C Chandranath Chatterjee Street
Kolkata WEST BENGAL 700025

Contact No:
9830077358

Email Id:
sales@bacbpl.com

27-01-2021

27-01-2021

SCO 402, 2nd floor, Mugal Canal Karnal
HARYANA 132001

Contact No:
9896000540

Email Id:
ajay@kwikzo.co.in

28-01-2021

28-01-2021

309

KWIKZO TELECOMM PVT LTD

DS-11/64/2020-DS-III

B

HIMACHAL PRADESH

NAME:AJAY
WADHWA
Designation:DIRECTOR

310

MANOJ INTERNET SERVICES Pvt
Ltd.

DS-11/43/2020-DS-III

C

Ghaziabad

NAME:Sanoj Kumar
Designation:Director

7-B, Lajjapuri, Hapur, GHAZIABAD,
Ghaziabad, Uttar Pradesh, India, 245101
Ghaziabad UTTAR PRADESH 245101

Contact No:
9536368559

Email Id:
manojinternetservices@g
mai l.com

29-01-2021

29-01-2021

Contact No:
9492757500

Email Id:
svcommunicationsongole
@g mail.com

29-01-2021

29-01-2021

311

VAYU ONLINE Pvt Ltd.

DS-11/149/2020-DS-III

C

Ongole

NAME:VENKATA RAO
KOLLA
Designation:DIRECTOR

NO. 12, SABARAGIRI COMPLEX,,
KURNOOL ROAD,, ONGOLE,
PRAKASAM, ANDHRA PRADESH,
INDIA, 523002 Prakasam ANDHRA
PRADESH 523002

312

GOLWAR COMMUNICATION Pvt
Ltd.

DS-11/36/2020-DS-III

B

MADHYA PRADESH

NAME:Pavan Patel
Designation:Director

H.NO.134, MADHUBAN VIHAR
COLONY BHEROPUR , BHOPAL
Bhopal MADHYA PRADESH 462001

Contact No:
7000219754

Email Id:
pavanpatel1610@gmail.
com

02-02-2021

02-02-2021

All India

NAME:Shaiju KR
Designation:Director

Ground Floor, No.1112, HAL 2nd Stage,
13th Cross, Indiranagar, BANGALORE
Bangalore Urban KARNATAKA 560038

Contact No:
9035076289

Email Id:
info@corsicancs.com

03-02-2021

03-02-2021

KARNATAKA

NAME:MALTESH
MABALE
Designation:Director

No 35 Ground Floor 4th Cross
Navyanagar, Jakkur Bangalore Bangalore
Bangalore Urban KARNATAKA 560064

Contact No:
7760101101

Email Id:
optonetbroadband@g
mail.com

08-02-2021

08-02-2021

C/O-BASUDAV GOBINDANAGAR
CHECHUA GOBINDANAGAR,
Paschim Medinipur WEST BENGAL
721146

Contact No:
9647880008

Email Id:
PSMS.INFO@GMA
IL.COM

08-02-2021

08-02-2021

313

314

CORSICA SOLUTIONS Pvt Ltd.

OPTO COMMUNICATIONS Pvt
Ltd.

DS-11/107/2020-DS-III

DS-11/60/2021-DS-III

A

B

315

PSNET SOLUTIONS Pvt Ltd.

DS-11/182/2020-DS-III

C

Kharagpur

NAME:SANTIGOPAL
METYA
Designation:Director

316

REMOTE ENGINEERS MANAGED
IT SERVICES Pvt Ltd.

NO. DS-11/145/2021-DS-III,
DATED 02/08/2021

B

MUMBAI

NAME:Moin Akhter
Designation:Director

62-A, Ground Floor, Main Road, Ghaffar
Manzil, Jamia Nagar, South Delhi, Delhi110025 South Delhi DELHI 110025

Contact No:
9911475585

Email Id:
moin.akh.khan@gma
il.com

08-02-2021

08-02-2021

317

Remote Engineers Managed IT
Services Pvt Ltd.

DS-11/145/2021-DS-III

B

Mumbai

Moin Akhter

62-A, GROUND FLOOR, MAIN ROAD,
GHAFFAR MANZIL, JAMIA NAGAR,
NEW DELHI - 110025

9911475585

MOIN.AKH.KHAN
@GMAIL.COM

08-02-2021

02.August.202 1

318

SISTEMOS INFORMATION
TECHNOLOGY Pvt Ltd.

DS-11/280/2016-DS-III

B

BIHAR

NAME:RAKTIM
CHATTERJEE
Designation:DIRECTOR

PURBACHAL, TENTULTALA P.O R.
GOPALPUR KOLKATA North 24
Parganas WEST BENGAL 700136

Contact No:
8336088561

Email Id:
raktimchatterjee@gmail.
com

15-02-2021

15-02-2021

319

PURAVI ELITE TECHNOLOGIES
Pvt Ltd.

DS-11/122/2021-DS-III

C

Mysore

NAME:Vinay Kumar R
Designation:Managing
Director

No. 778/A,4TH STAGE, TK LAYOUT
JAYANAGAR, HONGELAKSHMI
ARCADE, CHAMRAJA MOHALLA,
MYSORE, KARNATAKA, INDIA
570014 Mysore KARNATAKA 570014

Contact No:
9880845710

Email Id:
vkumar@ravgonet.in

08-03-2021

08-03-2021

320

SHAKYA IT VENTURES Pvt Ltd.

DS-11/268/2019-DS-III

C

Agra

NAME:Rupkishor
Designation:DIRECTOR

KHASRA NO. 330, HARJUPURA,
MAUJA BASAI TAJGANJ ,AGRA282001 Agra UTTAR PRADESH
282001

Contact No:
8650191400

Email Id:
devraj8430@gmail.c om

08-03-2021

08-03-2021

<!-- page 10 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

321

TCA NETWORKS PVT. LTD.

DS-11/74/2020-DS-III

C

Satna

NAME:SHARAD
YADAV
Designation:DIRECTOR

65/A/3/3, OPP. SAMARITAN
HOSPITAL, IP NAGAR PATERI Satna
MADHYA PRADESH 485001

Contact No:
9981695252

Email Id:
sharad.tca@gmail.com

22-03-2021

22-03-2021

322

EEXTRANET INTERNET PVT
LTD

DS-11/131/2020-DS-III

C

Mandla

NAME:SHIVAM RAJ
CHOURASIA
Designation:Director

Near State Bank Colony, Beside Airtel
Tower, Binjiya, Mandla MADHYA
PRADESH 481661
302 METRIX SURVEY NO 867 NR
DIVYABHASKAR PRESS SG
HIGHWAY PRAHLADNAGAR
AHMEDABAD GUJARAT
Ahmedabad GUJARAT 380015

Contact No:
9074484868

Email Id:
kamal.sahu0990@gmail.
com

23-03-2021

23-03-2021

Contact No:
9879759197

Email Id:
mukesh@dishawaves.co
m

30-03-2021

30-03-2021

323

DISHAWAVES INFOTECH Pvt Ltd.

DS-11/76/2020-DS-III

A

All India

NAME:MUKESHKUMA
R CHIMANLAL PATEL
Designation:DIRECTOR

324

FIRST MILE DIGITAL Pvt Ltd.

DS-11/112/2020-DS-III

B

Mumbai

RAJA B NADAR,
DIRECTOR

308, 3RD FLOOR, PLOT NO. 109C,
NIRMAL INDUSTRIAL ESTATE, SION
EAST Mumbai City MAHARASHTRA
400002

Contact No:
7977695850

Email Id:
firstmiledigital@gmail.c
om

02-04-2021

02-04-2021

325

FIRST MILE DIGITAL Pvt Ltd.

DS-11/112/2020-DS-III

B

Maharashtra

RAJA B NADAR,
DIRECTOR

308, 3RD FLOOR, PLOT NO. 109C,
NIRMAL INDUSTRIAL ESTATE, SION
EAST Mumbai City MAHARASHTRA
400002

Contact No:
7977695850

Email Id:
firstmiledigital@gmail.c
om

02-04-2021

02-04-2021

326

ADS ROYALNET
COMMUNICATION Pvt Ltd.

DS-11/48/2021-DS-III

B

MAHARASHTRA

NAME:Amol Shiras
Designation:Director

FLAT NO A-18-102 SERVEY NO 60/1A
61/2 61/3B BRAHMA AVENUE
KONDHWA KHURD Pune
MAHARASHTRA 411048

Contact No:
8975411675

Email Id:
amolshiras.24@gmai
l.com

08-04-2021

08-04-2021

327

WEBIZY TECHSOL PVT LTD

DS-11/73/2021-DS-III

C

Pen

NAME:DARSHAN
DATTATRAY
THAKUR
Designation:DIRECTOR

PL-11 A, SEC 11, SHOP NO. 7, NEW
PANVEL, PANVEL Raigad
MAHARASHTRA 410206

Contact No:
9321897696

Email Id:
darshant81@gmail.c om

08-04-2021

08-04-2021

328

FAST NET
TELECOMMUNICATIONS Pvt Ltd.

DS-11/115/2020-DS-III

B

HARYANA

NAME:ASHOK
KUMAR
Designation:DIRECTOR

VILLAGE SHAZADPUR, NEAR NEW
BUS STAND,TEHSIL
NARAINGARH,DISTT
AMBALA,VILLAGE SHAZADPUR
AMBALA Ambala HARYANA 134202

Contact No:
9050897408

Email Id:
omtelecom408@gmail.c
om

21-04-2021

21-04-2021

329

FAST NET
TELECOMMUNICATIONS Pvt Ltd.

DS-11/115/2020-DS-III

B

PUNJAB

NAME:ASHOK
KUMAR
Designation:DIRECTOR

VILLAGE SHAZADPUR, NEAR NEW
BUS STAND,TEHSIL
NARAINGARH,DISTT
AMBALA,VILLAGE SHAZADPUR
AMBALA Ambala HARYANA 134202

Contact No:
9050897408

Email Id:
omtelecom408@gmail.c
om

21-04-2021

21-04-2021

330

NIVID TELECOM INDIA Pvt Ltd.

DS-11/183/2020-DS-III

B

KARNATAKA

NAME:Shiva Kumar
Krishnappa
Designation:Director

No. 27, Sri Sai Residency Road,
KothanurDinne, J P Nagar, 8th Phase
Bangalore Urban KARNATAKA 560078

Contact No:
9845517658

Email Id:
shiva@nividtele.com

22-04-2021

22-04-2021

331

KWIKZO TELECOMM PVT LTD

DS-11/64/2020-DS-III

B

Haryana

NAME: Ajay Wadhwa,
Director

SCO-402, SECOND FLOOR, MUGAL
CANAL, KARNAL, HARYANA 132001

Contact No.
9896000540

email id of Authorised
signatory :
ajay@kwikzo.co.in

30-04-2021

28-01-2021

332

TSK GIGA FIBBER Pvt Ltd.

DS-11/105/2020-DS-III

C

Guntur

DOOR NO 8-3-24, WARD 20, AG
NAME:TATAVARTHI
COLLEGE
SAI KRISHNA
ROAD, BAPATLA, Guntur, Andhra
Designation:DIRECTOR Pradesh, India, 522101 Guntur ANDHRA
PRADESH 522101

Contact No:
8897677628

Email Id:
sksaik1992@gmail.com

01-05-2021

01-05-2021

333

DURONTO NETWORKS (OPC) Pvt
Ltd.

DS-11/71/2020-DS-III

C

Kota

NAME:SUKHVINDAR BARKAT NAGAR JHALAR BAWARHI
SINGH RANDHAWA
RAWATBHATA Chittorgarh
Designation:DIRECTOR
RAJASTHAN 323307

Contact No:
9462727600

Email Id:
durontonetworks@gmail.
co m

02-05-2021

02-05-2021

334

FUTURE INTERNET Pvt Ltd.

DS-11/127/2020-DS-III

B

Delhi

D-252A, AMBEDKAR COLONY
NAME:SHADAB ALI
CHATTERPUR NEW DELHI South West
Designation:DIRECTOR
Delhi DELHI 110074

Contact No:
8467010203

Email Id:
SHADAB.ALII@YAHO
O.I N

02-05-2021

02-05-2021

335

TOUCH NET INDIA Pvt Ltd.

DS-11/112/2019-DS-III

B

DELHI

NAME:HARBINDER
KUMAR
Designation:Director

B-142, T.F.B.P. MAYAPURI PHASE-I,
NEARDD MOTORS South West Delhi DELHI
110064

Contact No:
9891381118

Email Id:
touchnet@touchnetindia.
net

02-05-2021

02-05-2021

336

BALAJI INTERNET NETWORK
SERVICES Pvt Ltd.

DS-11/118/2020-DS-III

B

Mumbai

ROOM NO. 2, 1ST FLOOR, JAI
NAME:RUPENDRA BHAGWATI CHAWL, OPP. MILITARY
PRAKASH MIRAJKAR
CAMP OUT POST,
Designation:DIRECTOR
SANTACRUZ EAST Mumbai City
MAHARASHTRA 400029

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yah oo.co.in

03-05-2021

03-05-2021

337

DSOUZA INTERNET SERVICES
Pvt Ltd.

No: DS-11/67/ 2021-DS-III

B

MUMBAI

JANU BOYE SRA CHSL C-2309
NAME:DOLPHY
REHAB BUILD-1 NEAR SHANTARAM
ANTONY DSOUZA
TALAO OFF W E HIGHWAY MALAD
Designation:DIRECTOR
EAST MUMBAI Mumbai City
MAHARASHTRA 400097

Contact No:
9930722231

Email Id:
dolphyadsouza1969
@gmail.com

07-05-2021

07-05-2021

<!-- page 11 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

338

S T BROADBAND CABLE
SERVICE Pvt Ltd.

No: DS-11/12/2019-DS-III

B

MUMBAI

NAME:MOHAMMEAD
NADEEM SALIM
TAMBOLI
Designation:DIRCTOR

20/SHOP NO 02, KAMLA BHUVAN ,
STATION ROAD, KURLA WEST
MUMBAI Mumbai City
MAHARASHTRA 400070

Contact No:
9892075255

Email Id:
TAMBOLI.NADEE
M@GMAIL.COM

07-05-2021

07-05-2021

339

BILAL INTERNET SERVICES Pvt
Ltd.

No: DS-11/38/2021-DS-III

B

MUMBAI

NAME:KHAN
3, IBRAHIM CHUNAWALA PLOT, OPP
MOHAMMED ATAUL
BEST DEPOT, L. B. S. MARG,
MUSTAFA
KURLA WEST Mumbai City
Designation:DIRECTOR
MAHARASHTRA 400070

Contact No:
8779303565

Email Id:
nikhil_enterprises196
6@yahoo.co.in

08-05-2021

08-05-2021

340

VIBELINK INFOTECH Pvt Ltd.

DS-11/179/2020-DS-III

B

MUMBAI

NAME:ABDUL MAJED
SHAIKH
Designation:DIRECTOR

B-122, FLOOR LOFT-1, SHAIKH
MISREE DARGAH, HUTMENTS,
SHAIKH MISREE ROAD, ANTOP
HILL, Mumbai City MAHARASHTRA
400037

Contact No:
9867373785

Email Id:
abdulmajed876@gm
ail.com

08-05-2021

08-05-2021

341

IPNET BROADBAND NETWORK
Pvt Ltd.

DS-11/180/2020-DS-III

A

All India

NAME:PRATEEK
SHUKLA
Designation:DIRECTOR

K-575, Puliya Number 15, Yashoda
Nagar, Kanpur Kanpur Nagar UTTAR
PRADESH 208011

Contact No:
9810407430

Email Id:
ipnetbroadband@outlook
.co m

27-05-2021

27-05-2021

342

ACTIVEX TELEBROADBAND
SERVICES PVT LTD

DS-11/122/2020-DS-III

A

All India

Sandeep Karanwal

S2 Level, Upper Ground Floor, Block F,
International Trade Tower, Nehru Place,
New Delhi, 110019

01146705600,95
60 487940

sandeep.karanwal
@atctower.in

08-06-2021

08-06-2021

343

PLEX IT SERVICES Pvt Ltd.

DS-11/32/2020-DS-III

C

Rohtak

NAME:SACHIN SAINI
Designation:Director

NAI BASTI, GALI NO 1 HN 70,
BHIWANI Bhiwani HARYANA 127021

Contact No:
9468360460

Email Id:
sachin@plexbroadband.i
n

15-06-2021

15-06-2021

344

INFYNIX DATA SERVICES Pvt
Ltd.

DS-11/43/2021-DS-III

A

All India

Name:Ravi Kumar Karra, H.no: 720 Sector 14,Gurugram,HaryanaDesignation :Director
560095

Contact No:
08061165710

Email Id: infotel.deepak
gs@gmail.com

17-06-2021

17-06-2021

345

IT SPECTRUM MEDIA Pvt Ltd.

DS-11/61/2021-DS-III

A

All India

NAME:NANDA
DOOR NO.15/27,2ND CROSS
KUMAR GOVINDA
ROAD,MSREC ROAD, MATHIKERE
REDDY
P.O.,BANGALORE
Designation:DIRECTOR Bangalore Urban KARNATAKA 560054

Contact No:
7022288886

Email Id:
techsupport@itspectrum.
in

17-06-2021

17-06-2021

346

AIRPRO MEDIA (OPC) Pvt Ltd.

DS-11/121/2020-DS-III

C

Pathankot

C/O BALJIT SINGH, GHUMAN
NAME:JOBANPREET
MARKET,
SINGH
JALL ROAD, BATALA, gurdaspur,
Designation:MANAGER punjab, india, 143505 Gurdaspur PUNJAB
143505

Contact No:
9878304898

Email Id:
mediaairpro@gmail.com

18-06-2021

18-06-2021

347

AVS INTERNET AND DIGITAL
CABLE PROVIDER Pvt Ltd.

DS-11/187/2020-DS-III

B

Mumbai

NAME:SEETU SINGH
Designation:DIRECTOR

KAMALABAI PRATAP SINGH
CHAWL, ROOM NO. 11,1ST FLOOR,
TANAJI NAGAR, MALAD EAST
Mumbai City MAHARASHTRA 400097

Contact No:
8879094147

Email Id:
amitsinghvijay@gmail.c
om

18-06-2021

18-06-2021

348

BHR BROADBAND PVT LTD

DS-11/116/2020-DS-III

C

Chandigarh

NAME:Taranjit Singh
Designation:Director

HOUSE NO.4, RAIPUR KALAN
CHANDIGARH,chandigarh India
Chandigarh CHANDIGARH 160102

Contact No:
8872381158

Email Id:
singhtaranjit@hotmail.co
m

18-06-2021

18-06-2021

349

LAXN BROADBAND Pvt Ltd.

DS-11/266/2019-DS-III

C

Dehradun

NAME:Laxmi Prasad
Dangwal
Designation:DIRECTOR

C-19, Gayatri Complex, 36- Railway
Road, RISHIKESH, Dheradun,
Uttrakhand, India, 249201 Dehradun
UTTARAKHAND 249201

Contact No:
9212795443

Email Id:
laxmidangwal@yahoo.co
m

21-06-2021

21-06-2021

350

LINK4DATA
COMMUNICATIONS Pvt Ltd.

DS-11/142/2021-DS-III

C

Rohtak

NAME:SANDEEP
59 IMPROVMENT TRUST MARKET
KUMAR BHARDWAJ
BHIWANI Bhiwani HARYANA 127021
Designation:DIRECTOR

Contact No:
9896544555

Email Id:
link4data@yahoo.com

21-06-2021

21-06-2021

351

FISP NETWORK Pvt Ltd.

No: DS-11/37/2021-DS-III

B

Mumbai

NAME:SHOEB ABDUL
AZIZ ANSARI
Designation:DIRECTOR

SHOP NO. 2, GROUND FLOOR,
AHMADI TOWER, DR. ANSARI
ROAD, 1ST RABOLI, Thane
MAHARASHTRA 400601

Contact No:
8779303565

Email Id:
friendz.net2009@gmail.c
om

23-06-2021

23-06-2021

352

OUTOFBOX NETWORKS Pvt Ltd.

DS-11/126/2021-DS-III

B

KARNATAKA

NAME:Ajit Kumar S
Patil Designation:CEO

FOURTH FLOOR, ONENESS, CTS NO.
4837/2/2, 1ST CROSS, ST MAIN,
SADASHIV NAGAR, BELAGAVI
Belgaum KARNATAKA 590001

Contact No:
9379499565

Email Id:
ajit.patil@faast.in

29-06-2021

29-06-2021

353

PRSHREE NETWORKS Pvt Ltd.

DS-11/154/2021-DS-III

C

Aligarh

Ravindra Kumar Kaushal Behind Block
NAME:Roopesh Kaushal
office Kalwari Post Tehra Hathras Hathras
Designation:DIRECTOR
UTTAR PRADESH 204101

Contact No:
9690344069

Email Id:
roopesh.kaushal@gmail.
com

30-06-2021

30-06-2021

13-07-2021

13-07-2021

13-07-2021

13-07-2021

354

FALCONET INTERNET PVT LTD

DS-11/137/2021-DS-III

B

PUNJAB

NAME:Aman Kamboj
Designation:Director

1241 Sector 9 Ambala HARYANA
134003

Contact No:
9896796084

Email Id:
kamboj.aman@gmail
.com

355

FALCONET INTERNET PVT LTD

DS-11/137/2021-DS-III

B

HARYANA

NAME:Aman Kamboj
Designation:Director

1241 Sector 9 Ambala HARYANA
134003

Contact No:
9896796084

Email Id:
kamboj.aman@gmail
.com

<!-- page 12 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

1241 Sector 9 Ambala HARYANA
134003

Contact No:
9896796084

Email Id:
kamboj.aman@gmail
.com

13-07-2021

13-07-2021

356

FALCONET INTERNET PVT LTD

DS-11/137/2021-DS-III

C

Hamirpur

NAME:Aman Kamboj
Designation:Director

357

QWISTEL NETWORK SERVICE
Pvt Ltd.

DS-11/110/2020-DS-III

B

DELHI

NAME:VIJAY KUMAR
Designation:DIRECTOR

723, T.C, JAINA TOWAR-II, DISTRICT
CENTRE, JANAKPURI, NEW DELHI110058 West Delhi DELHI 110058

Contact No:
9711925738

Email Id:
VIJAYNETWORK2
@GMAIL.COM

15-07-2021

15-07-2021

358

QWISTEL NETWORK SERVICE
PVT. LTD

DS-11/110/2020-DS-III

B

DELHI

VIJAY KUMAR

723, T.C, Jaina towar-II, District Centre,
Janakpuri, new Delhi-110058

01140453673,97
11 925738

VIJAYNETWORK
2@GMAIL.COM

15-07-2021

15-07-2021

359

CLEAR TOUCH CONNECT
SOLUTIONS Pvt Ltd.

DS-11/69/2020-DS-III

B

Delhi

NAME:S VINITH
KUMAR
Designation:CHIEF
FINANCIAL OFFICER

SAI KRUPA, DP 30A, THIRD FLOOR,
SOUTH PHASE, THIRU VI KA
INDUSTRIAL ESTATE, GUINDY
Chennai TAMIL NADU 600032

Contact No:
8939879779

Email Id:
dot@cleartc1.com

16-07-2021

16-07-2021

360

CLEAR TOUCH CONNECT
SOLUTIONS Pvt Ltd.

DS-11/69/2020-DS-III

C

Chennai

NAME:S VINITH
KUMAR
Designation:CHIEF
FINANCIAL OFFICER

SAI KRUPA, DP 30A, THIRD FLOOR,
SOUTH PHASE, THIRU VI KA
INDUSTRIAL ESTATE, GUINDY
Chennai TAMIL NADU 600032

Contact No:
8939879779

Email Id:
dot@cleartc1.com

16-07-2021

16-07-2021

361

CLEAR TOUCH CONNECT
SOLUTIONS Pvt Ltd.

DS-11/69/2020-DS-III

C

Bangalore

NAME:S VINITH
KUMAR
Designation:CHIEF
FINANCIAL OFFICER

SAI KRUPA, DP 30A, THIRD FLOOR,
SOUTH PHASE, THIRU VI KA
INDUSTRIAL ESTATE, GUINDY
Chennai TAMIL NADU 600032

Contact No:
8939879779

Email Id:
dot@cleartc1.com

16-07-2021

16-07-2021

362

CLEAR TOUCH CONNECT
SOLUTIONS Pvt Ltd.

DS-11/69/2020-DS-III

C

Gurgaon

NAME:S VINITH
KUMAR
Designation:CHIEF
FINANCIAL OFFICER

SAI KRUPA, DP 30A, THIRD FLOOR,
SOUTH PHASE, THIRU VI KA
INDUSTRIAL ESTATE, GUINDY
Chennai TAMIL NADU 600032

Contact No:
8939879779

Email Id:
dot@cleartc1.com

16-07-2021

16-07-2021

363

CLEAR TOUCH CONNECT
SOLUTIONS Pvt Ltd.

DS-11/69/2020-DS-III

C

Hyderabad

NAME:S VINITH
KUMAR
Designation:CHIEF
FINANCIAL OFFICER

SAI KRUPA, DP 30A, THIRD FLOOR,
SOUTH PHASE, THIRU VI KA
INDUSTRIAL ESTATE, GUINDY
Chennai TAMIL NADU 600032

Contact No:
8939879779

Email Id:
dot@cleartc1.com

16-07-2021

16-07-2021

364

RISING INTERNET Pvt Ltd.

DS-11/72/2021-DS-III

B

MUMBAI

306, FLR 3RD, PLT 98/106,
NAME:SHAILESH
VIJAYSHREE BLDG, TATYA
SHANKAR DHEPE
GHARPURE MARG,, MUGBHAT
Designation:DIRECTOR KANDEWADI, GIRGAON Mumbai City
MAHARASHTRA 400004

Contact No:
8779303565

Email Id:
nitin_pawar1234@y
ahoo.co.in

16-07-2021

16-07-2021

365

SHYAM DATA & VOICE
SERVICES PVT LTD

DS-11/64/2021-DS-III

B

DELHI

DHEERAJ JOHARI

7-C, DDA JANTA FLAT PKT - A, NEAR
LIG FLATS, SARITA VIHAR, NEW
DELHI : South Delhi,DELHI,110076

00000000000,93
12 999989

Info@shyamdatavo
ice.com

16-07-2021

16-07-2021

366

VITEZA INFONET (OPC) Pvt Ltd.

DS-11/184/2020-DS-III

B

MUMBAI

NAME:PRAFULL
BHARAT PATIL
Designation:DIRECTOR

395, PRAFULL NIWAS, SURYA
NAGAR, OPP. SHAPTSHUNGI,
VITAVA KOLIWADA, KALWA Thane
MAHARASHTRA 400605

Contact No:
8779303565

Email Id:
prafull1490@gmail.c om

16-07-2021

16-07-2021

367

ASPIRARE COMMUNICATIONS
Pvt Ltd.

DS-11/105/2021-DS-III

A

All India

NAME:VIKAS KUMAR NO 17,1ST FLOOR,9TH MAIN, 17TH
JHA
CROSS, 7TH SECTOR,HSR LAYOUT
Designation:Director
Bangalore Urban KARNATAKA 560102

Contact No:
9821502456

Email Id:
aspirarecommunicati
ons@gmail.com

19-07-2021

19-07-2021

368

UDUPI FASTNET Pvt Ltd.

DS-11/267/2019-DS-III

B

KARNATAKA

NAME:GURURAJ
SUNDAR AMIN
Designation:DIRECTOR

DOOR NO.4-116L2, OPP.LAW
COLLEGE,KUNJIBETTU P.O.,UDUPI
Udupi KARNATAKA 576102

Contact No:
9611124969

Email Id:
fastguru09@gmail.co m

27-07-2021

27-07-2021

369

AXOMNET BROADBAND PVT.
LTD.

DS-11/13/2020-DS-III

C

Guwahati

PARIJAT
PURKAYASTHA,
DIRECTOR

5TH BYE LANE, APURBA PATH,
R.G.B. ROAD, CHANDMARI,
GUWAHATI, KAMRUP ASSAM
Kamrup ASSAM 781003

Contact No:
9954196606

Email Id:
ACCOUNTS@AXOMN
ET
.COM

03-08-2021

03-08-2021

370

CHANNEL 3 INFO MEDIA Pvt Ltd.

DS-11/241/2021-DS-III

B

MUMBAI

NAME:Ashfaque Yakub
Shaikh
Designation:DIRECTOR

103,HIGH RISE CHS LTD,LBS MARG,,
NEAR TAXIMENS
COLONY,KURLA WEST Mumbai City
MAHARASHTRA 400070

Contact No:
9221064688

Email Id:
channel3wv@gmail.c om

13-08-2021

13-08-2021

371

CHANNEL 3 INFO MEDIA Pvt Ltd.

DS-11/241/2021-DS-III

C

Pen

NAME:Ashfaque Yakub
Shaikh
Designation:DIRECTOR

103,HIGH RISE CHS LTD,LBS MARG,,
NEAR TAXIMENS
COLONY,KURLA WEST Mumbai City
MAHARASHTRA 400070

Contact No:
9221064688

Email Id:
channel3wv@gmail.c om

13-08-2021

13-08-2021

<!-- page 13 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

372

N4U Broadband Pvt Ltd.

DS-11/194/2021-DS-III

B

DELHI

ANKIT GUPTA

78-A, THIRD FLOOR,CHANDU PARK,
NEAR SAI BABA MANDIR, DELHI 110051

8,88,20,49,832

n4ubroadband@gm
ail.com

13-08-2021

13-08-2021

373

SATOR SQUARE VENTURES Pvt
Ltd.

DS-11/158/2021-DS-III

B

MUMBAI

NAME:SHEETAL
MHATRE
Designation:DIRECTOR

702 ZED GARDEN 1, EKSAR ROAD,
BORIVALI WEST, MUMBAI Mumbai
City MAHARASHTRA 400092

Contact No:
9820194753

Email Id:
vijayshahindia@gmai
l.com

13-08-2021

13-08-2021

374

SUNIMAN CABLE AND NET Pvt
Ltd.

DS-11/33/2021-DS-III

B

MAHARASHTRA

NAME:SHAILESH
PATIL
Designation:MANAGIN
G DIRECTOR

JAMUNA NIWAS NAVGHAR
VILLAGE NEAR DATTA MANDIR
BHAYENDER EAST Thane
MAHARASHTRA 401105

Contact No:
9821894028

Email Id:
SUNIMANCABLEA
NDNET@GMAIL.C
OM

13-08-2021

13-08-2021

375

SYBR NET SERVICES Pvt Ltd.

DS-11/111/2020-DS-III

B

MUMBAI

NAME:AFTAB ALAM
Designation:DIRECTOR

LXX 562-2/6, UDAY NAGAR,
SAKINAKA KURLA W, NEAR FISH
MARKET, Mumbai City
MAHARASHTRA 400072

Contact No:
8779303565

Email Id:
nikhil_enterprises196
6@yahoo.co.in

13-08-2021

13-08-2021

376

CABLECOM NETWORK Pvt Ltd.

DS-11/183/2019-DS-III

B

UTTAR PRADESH (EAST)

NAME:Subroto Roy
Designation:Director

2/302, Malhar Deluxe, Sahara Grace,
Jankipuram, Lucknow Lucknow UTTAR
PRADESH 226021

Contact No:
7007723494

Email Id:
cablecomnetworkpltd
@gmail.com

17-08-2021

17-08-2021

377

SPEEDPULSE DIGITAL
NETWORK Pvt Ltd.

DS-11/66/2021-DS-III

C

Indore

NAME:ADITYA
KHETAN
Designation:DIRECTOR

95 FH SCHEME NO.54,VIJAY
NAGAR, INDORE Madhya Pradesh
Indore MADHYA PRADESH 452010

Contact No:
8989922222

Email Id:
adityakhetan024@g
mail.com

17-08-2021

17-08-2021

378

INIC COMMUNICATIONS Pvt Ltd.

DS-11/120/2021- DS-III

B

MADHYA PRADESH

BLOCK 10, PLOT 21, NEHRU NAGAR
NAME:MANOJ GUPTA
EAST, BHILAI Durg CHHATTISGARH
Designation:Director
490020

Contact No:
9826092151

Email Id:
manoj@instalinks.net

18-08-2021

18-08-2021

379

AGILE NETLINK Pvt Ltd.

DS-11/44/2021-DS-III

B

RAJASTHAN

NAME:Shubham Sinha
Designation:Director

SHOP NO 552, 4TH FLOOR, SM
LODHA COMPLEX, COURT CIRCLE
Udaipur RAJASTHAN 313001

Contact No:
9660001818

Email Id:
netlinkinternetpvtltd
@gmail.com

19-08-2021

19-08-2021

380

PATHCOM COMMUNICATIONS
Pvt Ltd.

DS-11/71/2021-DS-III

B

KARNATAKA

NAME:Antony Jude
Designation:Director

669/F, 2nd floor, AMG Towers, 80 feet
Road, 1st Stage, 2nd Block, HBR Layout,
Bangalore Bangalore Urban
KARNATAKA 560043

Contact No:
9886115117

Email Id:
antonyjudeblr@gmail
.com

19-08-2021

19-08-2021

381

RAJASTHAN INTERNET HUB Pvt
Ltd.

DS-11/31/2021-DS-III

C

Ajmer

NAME:PUNIT
NEAR RAMDEO TEMPLE, GHOOGRA,
NAIWAL
AJMER, RAJASTHAN, INDIA 305023
Designation:DIRECTOR
Ajmer RAJASTHAN 305023

Contact No:
8955499997

Email Id:
punitchhipa@gmail.c om

19-08-2021

19-08-2021

382

SRI SAI COMMUNICATION AND
INTERNET Pvt Ltd.

DS-11/290/2021-DS-III

A

All India

NAME:PALLE
SRINIVAS
Designation:DIRECTOR

18-18-81/1/K, PRASHANTH NAGAR,
SIDDIPET, MEDAK, TELANGANA,
INDIA ,502103 Medak TELANGANA
502103

Contact No:
9599944516

Email Id:
pallesrinivas5029@g
mail.com

23-08-2021

23-08-2021

383

DEEPNET BROADBAND Pvt Ltd.

DS-11/296/2021-DS-III

B

MAHARASHTRA

NAME:BIPIN
RAMCHANDRA
PATANE
Designation:DIRECTOR

28/15 Bazarpeth Khed, Ratnagiri Khed,
Khed, Ratnagiri, Maharashtra, India
Ratnagiri MAHARASHTRA 415709

Contact No:
9422430062

Email Id:
patne.bipin@gmail.c om

31-08-2021

31-08-2021

384

SOLANKI FIBRE CONNECT Pvt
Ltd.

DS-11/155/2021-DS-III

B

MUMBAI

NAME:KIREET
PRADEEP SOLANK
Designation:Managing
Director

SHOP NO - B-5, HOUSE NO - 768,
MAHADEV APARTMENT, SECTOR13, KHARGHAR, PANVEL, Raigarh,
Maharashtra, India Raigad
MAHARASHTRA 410210

Contact No:
9022656969

Email Id:
fiberconnectsolanki@
gmail.com

31-08-2021

31-08-2021

385

WINBUILD SOLUTIONS Pvt Ltd.

DS-11/63/2021-DS-III

B

MUMBAI

NAME:ASIF IQBAL
SHAIKH
Designation:DIRECTOR

NEAR OLD JINSI POLICE STATION,
PLOT NO. 4-12-57, OLD BAIJIPURA,
AURANGABAD, MAHARASHTRA,
INDIA, 431001 Aurangabad
MAHARASHTRA 431001

Contact No:
9892623115

Email Id:
asif4umcp@gmail.co m

31-08-2021

31-08-2021

386

LINKIO FIBERNET Pvt Ltd.

DS-11/44/2020-DS-III

C

Allahabad

NAME:Kushal Kumar
Gupta
Designation:Director

18/14/2A, Lal Bahadur Shastri Marg, Civil
Lines, Allahabad, UP-211001 Allahabad
UTTAR PRADESH 211001

Contact No:
9711613662

Email Id:
isp.linkio@gmail.com

02-09-2021

02-09-2021

387

AIR24 NETWORK (OPC) Pvt Ltd.

DS-11/181/2020-DS-III

B

Mumbai

NAME:SAGAR
SHIVAJI RAUT
Designation:DIRECTOR

FL - B/104, GANGADHAR COMPLEX,
PLOT 03, SECTOR 07, KAMOTHE,
PANVEL Raigad
MAHARASHTRA 410206

Contact No:
8898507928

Email Id:
nikhil_enterprises1966@
yah oo.co.in

06-09-2021

06-09-2021

<!-- page 14 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

Contact No:
9096392999

Email Id:
info@syncnet.tech

06-09-2021

06-09-2021

388

SYNCNET TECHNOLOGIES Pvt
Ltd.

DS-11/271/2019-DS-III

C

Aurangabad

NAME:ZAFAR AHMED
MAZHAR AHMED
SHAIKH
Designation:DIRECTOR

Rashidpura, Plot No. 58, C/o Shaikh
Sajeda Begum, Shaikh Mazhar A.,
AURANGABAD, Aurangabad,
Maharshtra, India, 431001 Aurangabad
MAHARASHTRA 431001

389

COUNTRY ONLINE SERVICES Pvt
Ltd.

DS-11/219/2021-DS-III

B

ANDHRA PRADESH

NAME:Mohammed
Abdul Salam
Designation:Managing
Director

13-3-1109/1, Karwan Hyderabad
TELANGANA 500006

Contact No:
9700979200

Email Id:
salam1779@gmail.c om

13-09-2021

13-09-2021

390

MREZHI INTERNET Pvt Ltd.

DS-11/146/2020-DS-III

B

UTTAR PRADESH (WEST)

NAME:Vishal Kaushik
Designation:Director

343, VIKAS COLONY, RANIPUR
MORE, HARIDWAR Haridwar
UTTARAKHAND 249407

Contact No:
7060000090

Email Id:
vishalkaushik@mrez
hi.in

13-09-2021

13-09-2021

391

3 STAR INTERNET AND OTT
NETWORK Pvt Ltd.

DS-11/250/2021-DS-III

C

Vadodara

NAME:NIRA JAYESH
PANDYA
Designation:DIRECTOR

SHOP NO. 17, PANGHAT FLAT, NEAR
MATHURA NAGARI,
VADODARA Vadodara GUJARAT
390020

9820194753

Email Id:
vijayshahindia@gmai
l.com

14-09-2021

14-09-2021

392

SPEEDOBITS INTERNET Pvt Ltd.

DS-11/39/2021/-DS-III

C

Rajkot

NAME:GAURAV
JITENDRABHAI
MAJITHIYA
Designation:DIRECTOR

SHOP NO 201, SECOND FLOOR,
JASAL COMPLEX, NANAVATI
CHOWK, 150 FEET RING ROAD,
RAJKOT Rajkot GUJARAT 360007

Contact No:
9998979777

Email Id:
gaurav@speedobits.n et

14-09-2021

14-09-2021

393

ELYZIUM GLOBENET Pvt Ltd.

DS-11/218/2021-DS-III

A

All India

NAME:Apurva Malhotra
Kapoor
Designation:Director

Plot No 117, Udyog Kendra, Extn-II,
Ecotech-III Gautam Buddha
Nagar(NOIDA) UTTAR PRADESH
201310

Contact No:
9811856567

Email Id:
apurvamkapoor@gm
ail.com

15-09-2021

15-09-2021

394

ELYZIUM GLOBENET Pvt Ltd.

DS-11/218/2021-DS-III

A

All India

Apurva Malhotra Kapoor

Plot No 117, Udyog Kendra, Extn-II,
Ecotech-III : Gautam Buddha
Nagar(NOIDA),UTTAR
PRADESH,201310

09811856567,98
11 856567

apurvamkapoor@g
mail.com

15-09-2021

15-09-2021

395

CLOUDNET COMMUNICATIONS
PVT LTD

No: DS-11/52/2021-DS-III

B

MUMBAI

NAME:Ankit Desai
Designation:Director

202, P-Wing, Tex Centre, Chandivali Farm
Road, Andheri East Mumbai City
MAHARASHTRA 400072

Contact No:
8104993129

Email Id:
ankit.desai@cloudnetindia.com

16-09-2021

16-09-2021

396

LAKSHAY ISOLUTIONS INDIA
Pvt Ltd.

No: DS-11/51/2021-DS-III

B

MUMBAI

NAME:NARENDR
SINGH YADAV
Designation:DIRECTOR

9-11A, FLOOR 2, PLOT-11,
MACHINERY HOUSE, BURJORJEE
BHARUCHA MARG, KALA GHODA,
FORT MUMBAI Mumbai City
MAHARASHTRA 400023

Contact No:
9224205579

Email Id:
narendrsy@gmail.co m

16-09-2021

16-09-2021

397

RAJASTHAN INTERNET
SERVICES Pvt Ltd.

DS-11/147/2021-DS-III

B

RAJASTHAN

NAME:DHARVENDRA
KUMAR
Designation:DIRECTOR

A-200, JAWAHAR NAGAR,
BHARATPUR Rajasthan Bharatpur
RAJASTHAN 321001

Contact No:
9549627777

Email Id:
rajasthanispl@gmail.
com

16-09-2021

16-09-2021

398

COVENANT INFOTEL Pvt Ltd.

DS-11/177/2020-DS-III

B

GUJARAT

NAME:Alpesh Patel
Designation:Director

A-201,GANESH GREENS,CHENPUR
ROAD,NEW RANIP Ahmedabad
GUJARAT 382470

Contact No:
9033099881

Email Id:
sandeep.ku.pal@gma
il.com

17-09-2021

17-09-2021

399

VAIDIK NETSOL OPC PVT LTD

DS-11/271/2021/DS-III

B

GUJARAT

NAME:PANKAJKUMA
R BHIKHABHAI
E 204 Vibrant Homes, Nr Vraj Residency,
PATEL
Vill. Muthiya Ahmedabad GUJARAT
Designation:OPERATIO
382330
N HEAD

Contact No:
9377112288

Email Id:
VAIDIKNETSOL@
GMAIL.COM

17-09-2021

17-09-2021

400

Preffered itech care pvt ltd

DS-11/172/2020-DS-III

C

Almora

RITURAJ SINGH
WALDIA

PORTION OF LOT NO. 88, PLOT NO.
89 90 91 F/F, BLOCK B NANHEY
PARK UTTAM NAGAR, NEW DELHI 110 059.

09557000804,95
57 000804

PREFERREDITEC
HCAREPVTLTD
@GMAIL.COM

22-09-2021

22-09-2021

401

Preffered itech care pvt ltd

DS-11/172/2020-DS-III

C

Dehradun

RITURAJ SINGH
WALDIA

PORTION OF LOT NO. 88, PLOT NO.
89 90 91 F/F, BLOCK B NANHEY
PARK UTTAM NAGAR, NEW DELHI 110 059.

09557000804,95
57 000804

PREFERREDITEC
HCAREPVTLTD
@GMAIL.COM

22-09-2021

22-09-2021

402

CLOUDINSTA24 SERVICES Pvt
Ltd.

DS-11/125/2019-DS-III

B

Mumbai

Vipul Vikas Deshpande

Vidya Deshpande, Om Avishkar
Society,S.No. 123 Near MIT College ,
Paud Road, Kothrud, Pune - 411038

8530625626
9545013636

cispl.dot@cloudiinfra.com

23-09-2021

03-03-2020

403

CLOUDINSTA24 SERVICES Pvt
Ltd.

DS-11/125/2019-DS-III

C

Hyderabad

Vipul Vikas Deshpande

Vidya Deshpande, Om Avishkar
Society,S.No. 123 Near MIT College ,
Paud Road, Kothrud, Pune - 411038

8530625626
9545013636

cispl.dot@cloudiinfra.com

23-09-2021

03-03-2020

404

CLOUDINSTA24 SERVICES Pvt
Ltd.

DS-11/125/2019-DS-III

C

Indore

Vipul Vikas Deshpande

Vidya Deshpande, Om Avishkar
Society,S.No. 123 Near MIT College ,
Paud Road, Kothrud, Pune - 411038

8530625626
9545013636

cispl.dot@cloudiinfra.com

23-09-2021

03-03-2020

<!-- page 15 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

405

CLOUDINSTA24 SERVICES Pvt
Ltd.

DS-11/125/2019-DS-III

C

Bangalore

Vipul Vikas Deshpande

Vidya Deshpande, Om Avishkar
Society,S.No. 123 Near MIT College ,
Paud Road, Kothrud, Pune - 411038

8530625626
9545013636

cispl.dot@cloudiinfra.com

23-09-2021

03-03-2020

406

CLOUDINSTA24 SERVICES Pvt
Ltd.

DS-11/125/2019-DS-III

C

Gurgaon

Vipul Vikas Deshpande

Vidya Deshpande, Om Avishkar
Society,S.No. 123 Near MIT College ,
Paud Road, Kothrud, Pune - 411038

8530625626
9545013636

cispl.dot@cloudiinfra.com

23-09-2021

03-03-2020

407

CLOUDINSTA24 SERVICES Pvt
Ltd.

DS-11/125/2019-DS-III

C

Chennai

Vipul Vikas Deshpande

Vidya Deshpande, Om Avishkar
Society,S.No. 123 Near MIT College ,
Paud Road, Kothrud, Pune - 411038

8530625626
9545013636

cispl.dot@cloudiinfra.com

23-09-2021

03-03-2020

408

GATEWAY BROADBAND
SERVICES Pvt Ltd.

DS-11/270/2021-DS-III

C

Pen

NAME:GAJANAN
LAXMAN PALASKAR
Designation:DIRECTOR

HOUSE NO. 3115, 302, PALASKAR
SANKUL, TEP MATHERAN ROAD,,
POST - NERAL, KARJAT Raigad
MAHARASHTRA 410101

Contact No:
8655303555

Email Id:
gateway_enterprises
@outlook.com

23-09-2021

23-09-2021

409

LASANE INFRA Pvt Ltd.

DS-11/101/2021-DS-III

C

Bangalore

NAME:Raja Irwin
Vasugam
Designation:Managing
Director

1/15,MOUNT JOY ROAD BULL
TEMPLE ROAD CROSS HANUMANTA
NAGAR NEXT TO HALLI THINDI
BANGALORE
Bangalore KA 560019 IN Bangalore
Urban KARNATAKA 560019

Contact No:
9945271971

Email Id:
irvin@manageditsolu
tion.in

27-09-2021

27-09-2021

410

MAHAMAYA INTERNET
SERVICES Pvt Ltd.

DS-11/224/2021- DS-III

B

MADHYA PRADESH

NAME:RAJESH
HIG-1,D-01,Abhilasha Parisar, Behind
KUMAR
New Bus Stand, Bilaspur, Chattisgarh
MANCHANDANI
India Bilaspur CHHATTISGARH 495001
Designation:DIRECTOR

Contact No:
9522274451

Email Id:
rajesh@mahamayaint
ernet.com

27-09-2021

27-09-2021

411

DIGIANA SPEED NET Pvt Ltd.

DS-11/159/2021- DS-III

A

All India

NAME:Tejinderpal Singh
Ghumman
Designation:Director

49,50,51 Sampat Farms, 6th Cross Road,
Opp Agrawal Public School, Bicholi,
Mardana Indore MADHYA PRADESH
452016

Contact No:
7970001180

Email Id:
info@digiana.com

28-09-2021

28-09-2021

412

FEASABLE COMMUNICATIONS
Pvt Ltd.

DS-11/273/2021-DS-III

B

Tamil Nadu

NAME:Murali Krishna A
Designation:Director

S.No.169/4, P, No.76, GANDHI STREET,
JAWARLAL, NAGAR,
CHENNAI Tiruvallur TAMIL NADU
600052

Contact No:
9003216112

Email Id:
feasablecommunicati
ons@gmail.com

28-09-2021

28-09-2021

413

DOCKNET NETWORK PVT LTD

DS-11/106/2021-DS-III

B

MUMBAI

NAME:BHAVYA
BHUSHAN SARANG
Designation:DIRECTOR

SHOP NO.6 GRD FLOOR,
ANANDNATH INDUSRTY NR,
BHAWANISHANKAR BA, ADALJI
ROAD, TEMI NAKA, THANE
MAHARASTRA - 400601

Contact No:
7021492917

Email Id:
docknetnetwork@gm
ail.com

30-09-2021

30-09-2021

414

ORBITEDGE BROADBAND Pvt
Ltd.

DS-11/57/ 2021-DS-III

B

BIHAR

NAME: MUKESH
KUMAR RAY
Designation: DIRECTOR

AT-KUTRUCHAK, PO-BUDHWARA,
PS-GOVINDPUR,
NAWADA,BIHAR,805110

Contact
Email id:
No:06324295014,7 orbitedgebroadband@gm
004221958
ail.com

01-10-2021

01-10-2021

415

SAURASHTRA INFRATEL Pvt Ltd.

DS-11/295/2021-DS-III

B

GUJARAT

NAME:PARTHIV
GAUTAMBHAI
YADAV
Designation:Director

Capital Market 101, 22 Jagnath Plot
Rajkot GUJARAT 360001

Contact No:
9033885555

Email Id:
parthivyadav125@gmail
.com

01-10-2021

01-10-2021

416

GIGANET DIGITAL NET
SERVICES Pvt Ltd.

DS-11/114/2020-DS-III

B

Mumbai

NAME:SUVARNA T
AKHADE
Designation:DIRECTOR

I/604 SHANTI COMPLEX, SAKI VIHAR
ROAD, TUNGA VILLAGE, SHIVANI
NAGAR, POWAI Mumbai City
MAHARASHTRA 400072

Contact No:
7977695850

Email Id:
giganetdigitalnet@gmail.
com

03-10-2021

03-10-2021

417

AIT INTERNET SERVICES Pvt Ltd.

DS-11/336/2021-DS-III

A

All India

NAME:SHANMUGAPR NO 726, 1ST FLOOR ,38TH CROSS,
IYAN SADASIVAM 4TH T BLOCK, JAYANAGAR Bangalore
Designation:Director
Urban KARNATAKA 560041

Contact No:
9243443439

Email Id:
operations@aitinternetser
vices.com

04-10-2021

03-09-2020

418

DIGIFIBER Pvt Ltd.

DS-11/47/2021-DS-III

B

Mumbai

NAME:MAYUR
KAMLAKAR PAILKAR
Designation:DIRECTOR

SHOP NO. 3, GRD FLOOR, 14 A BLDG
GANGA, PANCHAVATI CHS,
BRINDAVAN SOCIETY Thane
MAHARASHTRA 400601

Contact No:
9930863999

Email Id:
pailkarmayur@gmail.co
m

05-10-2021

05-10-2021

<!-- page 16 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

A/104, PARASNATH DARSHAN,
NAME:MAYCOLL
KIROL ROAD, NR. STATE BANK OF
MAWIN PEREIRA
INDIA, VIDHYAVIHAR WEST Mumbai
Designation:DIRECTOR
City MAHARASHTRA 400086

Contact No:
9664651114

Email Id:
mawinethernet03@gmail
.com

05-10-2021

05-10-2021

NAME:MOHAMMED
SAAD HASHMI
Designation:Director

C/O SAYED FAZLE AMIN, WARD
NO.6 , PENSION LANE , BUXI
BAZAAR, CUTTACK, Cuttack, Orissa,
India Cuttack ORISSA 753001

Contact No:
9778107860

Email Id:
odinet.infocom@gmail.c
om

05-10-2021

05-10-2021

MUMBAI

NAME:Santosh Birbal
Gupta
Designation:Director

Shanti Bhuvan, G B Indulkar Marg, Vile
Parle Mumbai City MAHARASHTRA
400057

Contact No:
9930111328

Email Id:
santosh@ganeshinternet.
com

05-10-2021

05-10-2021

A

All India

NAME:RAKESH
KUMAR
Designation:DIRECTOR

SCO-135, Commercial Belt, Sector 17,
Huda, Jagadhri, Yamunanagar, Haryana,
India Yamunanagar HARYANA 135003

Contact No:
9050001112

Email Id:
rakesh.kumar@rpworld.c
o.in

07-10-2021

07-10-2021

DS-11/128/2021-DS-III

B

MUMBAI

NAME:Mukesh Chavda
Designation:DIRECTOR

Office No 33,4TH FLOOR, MULAJI
DEVASHI BUILDING, 116,KESHAVJI
NAIK ROAD, CHINCHBUNDER,
MUMBAI, Maharashtra Mumbai City
MAHARASHTRA 400009

Contact No:
9820923411

Email Id:
mkchavda@gmail.co m

08-10-2021

08-10-2021

VMPS INTERNET Pvt Ltd.

DS-11/147/2020-DS-III

B

UTTAR PRADESH (WEST)

NAME:Kapil Tyagi
Designation:DIRECTOR

C/o vidhya mitra, Vill-Simbhabli, NGH
Near State Bank, hapur, Ghaziabad Uttar
Pradesh - 245207

Contact No:
9760717278

Email Id:
vmpsinternetpvtltd@
gmail.com

08-10-2021

08-10-2021

425

YOUNG NETWORKS INDIA Pvt
Ltd.

DS-11/125/2021-DS-III

C

Agra

NAME:DEEPAK
SHOP NO B/1, BLOCK 31 BASEMENT,
KUMAR SHARMA
SANJAY PLACE, AGRA Agra UTTAR
Designation:DIRECTOR
PRADESH 282002

Contact No:
9927377779

Email Id:
youngit.agra@gmail.
com

09-10-2021

09-10-2021

426

REISNET BROADBAND Pvt Ltd.

DS-11/62/2021-DS-III

B

ORISSA

HARIHARA BHAWAN,PLOT
NAME:Sibananda Patra
NO211/3163,211/1433, HOUSE NO-114,
Designation:Founder and
GANDHI NAGAR, 2ND LANE,,
CEO
BERHAMPUR, Ganjam ORISSA 760001

Contact No:
8895172230

Email Id:
myreisnet@gmail.com

12-10-2021

12-10-2021

427

SANKRISH INFOCOM Pvt Ltd.

DS-11/49/2021-DS-III

B

Mumbai

NAME:PETER VAZ
Designation:DIRECTOR

C-65/101 MATOSHREE CHSL, SHANTI
PARK, BEHIND MADHAV TOWER,
MIRA ROAD EAST Thane
MAHARASHTRA 401107

Contact No:
9867169013

Email Id:
peter_vaz31@yahoo.com

13-10-2021

13-10-2021

428

VEGATAM NETWORK Pvt Ltd.

DS-11/74/ 2021-DS-III

B

Mumbai

NAME:RAJNEESH
MADAN MISHRA
Designation:DIRECTOR

FLAT NO. 001, LODHA LUXURIA
CLAREMONT, B WING, PARALISE
MAJIWAD Thane MAHARASHTRA
400601

Contact No:
9769972209

Email Id:
nilesh.bhor@vegatamnet
work.com

13-10-2021

13-10-2021

429

VEGATAM NETWORK Pvt Ltd.

DS-11/74/ 2021-DS-III

B

Maharashtra

NAME:RAJNEESH
MADAN MISHRA
Designation:DIRECTOR

Contact No:
9769972209

Email Id:
nilesh.bhor@vegatamnet
work.com

13-10-2021

13-10-2021

Contact No:
9129999999

Email Id:
wavenet.in@outlook.co
m

13-10-2021

13-10-2021

Contact No:
7503897545

Email Id:
info@genevaindia.com

18-10-2021

18-10-2021

S. No.

Name of Licensee

License No.

Category

Service Area

419

MAWIN CABLE NET Pvt Ltd.

DS-11/331/2021-DS-III

B

MUMBAI

420

ODINET INFOCOM Pvt Ltd.

DS-11/134/2021-DS-III

B

ORISSA

421

S.G.I.C. SERVICES Pvt Ltd.

DS-11/121/2021-DS-III

B

422

R.P WORLD WEBNET Pvt Ltd.

DS-11/294/2021-DS-III

423

GONET INTERNET SERVICES
SYSTEMS AND SOLUTIONS Pvt
Ltd.

424

Authorized Person

Registered Office Address

FLAT NO. 001, LODHA LUXURIA
CLAREMONT, B WING, PARALISE
MAJIWAD Thane MAHARASHTRA
400601
House Situated at 8 ,Bilaspur Himachal
NAME:AJAY SONI
Pradesh India Bilaspur HIMACHAL
Designation:MANAGER
PRADESH 174001
H/O-VISHAL KUMAR,S/O-V.N.SINGH
NAME:Rakesh Sharma
DOMANCHAK,EAST R.K,NAGAR
Designation:DIRECTOR
PATNA Patna BIHAR Patna BIHAR
800027

430

WAVENET INFRATEL Pvt Ltd.

DS-11/56/2021-DS-III

B

HIMACHAL PRADESH

431

GITELENET Pvt Ltd.

DS-11/35/2021-DS-III DATED
18.10.2021

A

All India

432

GEFO TELESERVICES INDIA Pvt
Ltd.

DS-11/309/2021-DS-III

B

KARNATAKA

NAME:SREEDHAR B C
Designation:DIRECTOR

C/O D.H.RADHA, BHUDHIHAL,
KASABA,NELAMANGALA Bangalore
Rural, Karnataka, India Bangalore Rural
KARNATAKA 562123

Contact No:
9606065557

Email Id:
sreedhargefoceo@mygef
o.in

20-10-2021

20-10-2021

433

10G TELECOM Pvt Ltd.

DS-11/274/2021-DS-III

B

MAHARASHTRA

NAME:Navnath
Shrimant Torane
Designation:DIRECTOR

164/1/A, FL NO 1406, WING U,
FOURTEENTH FLR, INDRADHANU
APPT, VISHNU MILL COMPOUND,
MARAAI CHOWK, SOLAPUR,
MAHARASHTRA, INDIA, Solapur
MAHARASHTRA 413001

9028563103

Email Id:
navnath_torane@yahoo.c
om

21-10-2021

21-10-2021

434

AOVATALK COMMUNICATIONS
Pvt Ltd.

DS-11/195/2021-DS-III

B

MUMBAI

A 202 Bldg No2 KD Paradise Mashacha
Pada Kashimira Mira Road E Opp Western
Hotel Mumbai Thane Thane
MAHARASHTRA 401107

Contact No:
9870688160

Email Id:
aovatalk@gmail.com

21-10-2021

21-10-2021

435

SPRINT TELECOM INDIA
PRIVATE LTD (STIPL)

DS-11/141/2021-DS-III

A

All India

810 Maker Chambers V 221 Nariman
Point Mumbai Mumbai City
MAHARASHTRA 400021

Contact No:
9980988826

Email Id: Uttama.rai@tmobile.com

21-10-2021

21-10-2021

Contact No:
9892096895

Email Id:
riddhi.mehta@synoptics.
co.in

21-10-2021

21-10-2021

Contact No:
9623378919

Email Id:
webnetkhed@gmail.com

21-10-2021

21-10-2021

Contact No:
7506069774

Email Id:
GANESHCHACHE@G
MAIL.COM

22-10-2021

22-10-2021

436

SYNOPTICS COMMUNICATION
SERVICES Pvt Ltd.

DS-11/182/2019-DS-III

A

All India

437

VIGHNAHARTA TELEINFRA Pvt
Ltd.

DS-11/244/2021-DS-III

C

Pune

438

DOMBIVLIKAR DOT NET Pvt Ltd.

DS-11/100/2021-DS-III

C

Kalyan

NAME:MAJID
ABDULREHMAN
DHUKKA
Designation:Director
NAME:Uttama Rai
Balakatta
Designation:Chief
Executive Officer and
Director

3rd floor A wing Interface Bldg No-16
NAME:JATIN SHAH
Mindspace Link Road Malad West
Designation:DIRECTOR Mumbai Mumbai City MAHARASHTRA
400064
SURVEY NO 6/1018, FLAT NO-2
NAME:RAHUL
RAIGAD BUILDING, BACCHAE PATIL
SUDAM SAWANT
COLONY RAJGURUNAGAR PUNEDesignation:DIRECTOR
410505
A/315 ARJUN NAGAR COMPLEX
NAME:GANESH
PATHARLI ROAD SHELKAR NALA
SITARAM CHACHE
DOMBIVLI EAST KALYAN Thane
Designation:DIRECTOR
MAHARASHTRA 421201

<!-- page 17 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

Contact No:
9990087979

Email Id:
enfinityinfotel@gmail.co
m

25-10-2021

25-10-2021

Contact No:
8010016745

Email Id:
internetjetway@gmail.co
m

25-10-2021

25-10-2021

439

ENFINITY INFOTEL PVT LTD

DS-11/65/2021-DS-III

B

DELHI

NAME:MANINDER
Designation:DIRECTOR

PLOT NO. 416/2, 4 TH FLOOR, NEAR
METRO PILLAR NO.127, MG ROAD,
GHITORNI South West Delhi DELHI
110030

440

JETWAY INTERNET SERVICES
Pvt Ltd.

DS-11/136/2021-DS-III

B

DELHI

NAME:ABHISHEK
YADAV
Designation:DIRECTOR

GZB 2C/344, VASUNDHARA,
GHAZIABAD Ghaziabad UTTAR
PRADESH 201012

441

INRI COMMUNICATIONS Pvt Ltd.

Ds-11/59/2021-Ds-III

C

Ongole

PLOT NO - 115, RAJIV GRUHAKALPA,
NAME:BELLAMKOND
1ST LINE, KOOPOLU ROAD, ONGOLE
A JOJAIAH
- PRAKASAM ANDHRA PRADESH Designation:DIRECTOR
523002

Contact No:
8522882226

Email Id:
shafi@inricpltd.com

28-10-2021

28-10-2021

442

AARCHI CABLE NETWORK AND
INTERNET SERVICE Pvt Ltd.

DS-11/192/2021-DS-III

B

MUMBAI

SHOP NO 11-E GORAI BSES RIENDS
NAME:AJAY
CHS PLOT NO 4 L T ROAD BORIVALI
MAHADIK
WEST MUMBAI Mumbai City
Designation:DIRECTOR
MAHARASHTRA 400092

Contact No:
9004967775

Email Id:
ajayvmahadik28@gmail.
com

29-10-2021

29-10-2021

443

G B INTERNET SERVICE Pvt Ltd.

DS-11/193/2021-DS-III

B

MUMBAI

NAME:HARISHBHAI
BIJALBHAI KHUMAN
Designation:DIRECTOR

228A, 2nd Floor, Mohid Heights CHS
Ltd., Lokhandwala Road, RTO Lane,
Andheri - W, MUMBAI, Mumbai City,
Maharashtra, India Mumbai City
MAHARASHTRA 400053

Contact No:
9819629948

Email Id:
harishcommunication03
@gmail.com

29-10-2021

29-10-2021

444

EROTH NETLINK SOLUTIONS
INDIA Pvt Ltd.

DS-11/293/2021-DS-III

B

MAHARASHTRA

Contact No:
9860418503

Email Id:
rupeshbanekar@outlook.
com

02-11-2021

02-11-2021

445

M NETPLUS COMMUNICATION
SERVICES Pvt Ltd.

DS-11/330/2021-DS-III

B

MAHARASHTRA

NAME:Syed Liyakat
Syed Ahmad
Designation:Director

58, Tawakal Layout, Near Raza Town,
Kamptee Road, Masara Toli, Nagpur
Nagpur MAHARASHTRA 441001

Contact No:
9850182274

Email Id:
mnetpluscommunication
@gmail.com

02-11-2021

02-11-2021

446

TREELINK NETWORK PVT LTD

DS-11/360/2021-DS-III

B

MAHARASHTRA

NAME:Abubakar Mustfa
Shaikh
Designation:DIRECTOR

OFFICE 103 WING-4, H AND M
ROYAL SN-18 19 P KONDHWA BK
Pune MAHARASHTRA 411048

Contact No:
8177927336

Email Id:
abshaikh4438@gmail.co
m

02-11-2021

02-11-2021

447

BPS COMMUNICATION AND
SERVICES Pvt Ltd.

DS-11/128/2020-DS-III

C

Muzaffarnagar

ROHIT KUMAR,
DIRECTOR

604 JAWAHAR COLONY NEW
MANDI Muzaffarnagar UTTAR
PRADESH 251001

Contact No:
9650507778

Email Id:
rohit@bpsnet.in

08-11-2021

08-11-2021

448

KOSHI BROADBAND
COMMUNICATIONS (OPC) PVT
LTD

DS-11/304/2021-DS-III

C

Katihar

NAME:SARANSH
AGARWAL
Designation:DIRECTOR

C/O KHARBRA KI KHABAR, LALIT
KR AGRAWAL, 1ST FLOOR
SONALIKA HOUSE BINODPUR,
KATHIHAR Katihar BIHAR 854105

Contact No:
9297979700

Email Id:
katihar@kbcnews.in

08-11-2021

08-11-2021

449

NET SATHI NETWORKS Pvt Ltd.
(OPC)

DS-11/75/2020-DS-III

B

UTTAR PRADESH (EAST)

NAME:Amar Kumar
Gupta
Designation:Managing
Director

Contact No:
9695405747

Email Id:
netsathinetworks@gmail.
com

09-11-2021

09-11-2021

All India

NAME:Hari Om
Designation:Director

Contact No:
9899747425

Email Id:
hariom@megatelnetwork
s.in

10-11-2021

10-11-2021

10-11-2021

10-11-2021

450

MEGATEL NETWORKS Pvt Ltd.

DS-11/265/2021-DS-III

A

NAME:Rupesh Sureshrao 606/2,, THILORI, TAHSIL-DARYAPUR,
Banekar
Amravati, Maharashtra, India Amravati
Designation:DIRECTOR
MAHARASHTRA 444803

H.No. 93, Ward No. 23, Maupakad Nagar,
Palika Parishad, Maharajganj, Uttar
Pradesh Maharajganj UTTAR PRADESH
273303
Plot No. B-233, F/F Camp No-4, Jwala
Puri, Nangloi, Pole No V091, Barat Ghar
West Delhi DELHI 110087

451

WAY2NET IT SERVICES Pvt Ltd.

DS-11/337/2021-DS-III

B

HARYANA

NAME:Ashok Kumar
Designation:DIRECTOR

H No 269 Gali No 3 Rajiv Colony
Bhiwani HARYANA 127021

Contact No:
9812998130

Email Id:
cable.bhiwani@gmail.co
m

452

FIBRE AIR SERVICES Pvt Ltd.

20-1208/2020 AS-I

A

All India

NAME:RAJESH
HOODA
Designation:DIRECTOR

SHOP NO 1 LANDMARK COMPLEX
MEDICAL MORE ROHTAK Rohtak
HARYANA 124001

Contact No:
9355290009

Email Id:
INFO@FIBREAIR.IN

11-11-2021

27-01-2021

453

NIVID TELECOM INDIA Pvt Ltd.

DS-11/183/2020-DS-III

B

Tamil Nadu

NAME:Shiva Kumar
Krishnappa
Designation:Director

No. 27, Sri Sai Residency Road,
KothanurDinne, J P Nagar, 8th Phase
Bangalore Urban KARNATAKA 560078

Contact No:
9845517658

Email Id:
shiva@nividtele.com

12-11-2021

22-04-2021

454

SIDDIQUI NET SOLUTIONS Pvt
Ltd.

DS-11/257/2021-DS-III

B

MUMBAI

NAME:MAJID MOHD
ABDUL SIDDIQUI
Designation:DIRECTOR

BUILDING R, GR FLOOR, FLAT NO. 2,
HANJAR NAGAR, PUMP HOUSE,
ANDHERI EAST Mumbai City
MAHARASHTRA 400093

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

16-11-2021

16-11-2021

Contact No:
8108599566

Email Id:
pramodnet9@gmail.com

16-11-2021

16-11-2021

455

WAY 2 INTERNET Pvt Ltd.

DS-11/140/2021-DS-III

B

MUMBAI

NAME:Pramod Anil patil
Designation:Director

32B Mun G Dhakal Patil House A
Sangitaratn Kesarinat Buva Bhaye Marg
Mumbai Mumbai City Mumbai City
MAHARASHTRA 400030

456

FIBREON NETWORK Pvt Ltd.

DS-11/334/2021-DS-III

B

MUMBAI

NAME:AKASH
JITENDRA SINGH
Designation:DIRECTOR

ROOM NO. 20, H INAMDAR CHAWLA, NETAJI SUBHASH NAGAR,
ASHALPHA, GHATKOPAR WEST
Mumbai City MAHARASHTRA 400084

Contact No:
7045328364

Email Id:
akshsngh2901@gmail.co
m

17-11-2021

17-11-2021

457

INTRO TELECOM Pvt Ltd.

DS-11/202/2019-DS-III

B

Mumbai

NAME:PARESH
PANDURANG
BHEKARE
Designation:DIRECTOR

54, TRANSIT CAMP, GOPI TANK
ROAD, KHOT GULLY, CITYLIGHT
CINEMA, MAHIM, MUMBAI Mumbai
City MAHARASHTRA 400016

Contact No:
9892339230

Email Id:
INTROTELECOMP@G
MAIL.COM

17-11-2021

17-11-2021

458

SHIV SHANKAR NETWORK Pvt
Ltd.

DS-11/191/2021-DS-III

B

MUMBAI

NAME:MR AHOK
BALU JADHAV
Designation:DIRECTOR

ROOM NO. 1, TUKARAM CHAWL,
KALINA, KOLIVERY VILLAGE,
SANTACRUZ EAST Mumbai City
MAHARASHTRA 400098

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

17-11-2021

17-11-2021

459

SHREE DATTA CABLE
INTERNET SERVICES Pvt Ltd.

DS-11/351/2021-DS-III

B

MUMBAI

NAME:VIKASH
SHANTARAM
GAVANKAR
Designation:DIRECTOR

ROOM NO. -73, BLDG. NO.-16A,
DURGA NAGAR, JV LINK ROAD,
JOGESHWARI EAST Mumbai City
MAHARASHTRA 400060

Contact No:
9167295733

Email Id:
vgavankar93@gmail.co
m

17-11-2021

17-11-2021

460

FAROHAR NETWORK Pvt Ltd.

DS-11/342/2021-DS-III

B

MUMBAI

FLAT 15, 3RD FLOOR, BLDG 19,
NAME:SHAHRUKH
PANTHAKI BAUG, NEAR
IRANI
HARGOVIND LANE, ANDHERI EAST
Designation:DIRECTOR
Mumbai City MAHARASHTRA 400069

Contact No:
8291243764

Email Id:
jassirani@yahoo.com

18-11-2021

18-11-2021

461

KOLIZ Pvt Ltd.

DS-11/53/2021-DS-III

B

Mumbai

NAME:GANANJAY N
RAGABHAGAT
Designation:Director

BNGL No1 Ragabhagat House Bazar
Gally BH Fish Market Versova Andheri
Mumbai City MAHARASHTRA 400061

Contact No:
9773022862

Email Id:
gananjay28@gmail.com

18-11-2021

18-11-2021

462

NSD INTERNET Pvt Ltd.

DS-11/30/2021-DS-III

B

Mumbai

BLOCK-7, SARITA BHUWAN, PLOT-5,
NAME:PRANAV
DESAI COLONY, MAMLEDARWADI,
DUSANE
MALAD WEST Mumbai City
Designation:DIRECTOR
MAHARASHTRA 400064

Contact No:
9820194753

Email Id:
vijayshahindia@gmail.co
m

18-11-2021

18-11-2021

<!-- page 18 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address
FLAT NO. 6, 2ND FLOOR,
SURYAJOYT APT., NEW D P ROAD,
KATRAP, BADLAPUR EAST Thane
MAHARASHTRA 421503

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

Contact No:
9325777000

Email Id:
rane.sameer008@gmail.c
om

18-11-2021

18-11-2021

463

RASAISHREE INTERNET Pvt Ltd.

DS-11/171/2020-DS-III

B

MAHARASHTRA

NAME:SAMEER
SURESH RANE
Designation:DIRECTOR

464

TRICHY CHANNEL NINE
CABLENET Pvt Ltd.

DS-11/99/2021-DS-III

B

Tamil Nadu

NAME:R Lakshmi
Narayanan
Designation:Managing
Director

1/3, SANKAR NAGAR, SRIRANGAM,
TIRUCHIRAPPALLI, TAMIL NADU 620006

Contact No:
9899747425

Email Id:
rlnswathi@yahoo.com

18-11-2021

18-11-2021

465

GAYATRI TELECOM Pvt Ltd.

DS-11/142/2020-DS-III

B

KOLKATA

NAME:Goutam Das
Designation:Managing
Director

89/3/1/a k.c.ash lan rishra Hooghly WEST
BENGAL 712248

Contact No:
8420963337

Email Id:
gtpl.goutam@gmail.com

23-11-2021

23-11-2021

466

KHATORE IT SOLUTIONS PVT
LTD

DS-11/124/2020-DS-III

C

Dhenkanal

NAME:Saket Khatore
Designation:Director

C/O Ajay Khatore 3B, Khatore Bagan,
Govt. Hospital Road, At- Barbil,
Kendujhar ORISSA 758035

Contact No:
7008700056

Email Id:
saket@naaraayani.com

23-11-2021

23-11-2021

467

AIRTECHZONE SERVICES INDIA
Pvt Ltd.

DS-11/73/2020-DS-III

C

Katihar

NAME:Ranvijay Rana
Designation:Director

2nd Floor, Kuber Plaza, Chitrawani Road,
Purnea, Purnia Purnia BIHAR 854301

Contact No:
9709506598

Email Id:
ranvijay@airtechzone.co
m

03-12-2021

03-12-2021

468

SIMTRON INFOWEB Pvt Ltd.

DS-11/188/2020-DS-III

B

UTTAR PRADESH (WEST)

NAME:MAMTA RANI
Designation:Director

IIND FLOOR, JANNAT BLOCK
SANDHU CENTRE Dehradun
UTTARAKHAND 248001

Contact No:
9319062680

Email Id:
kumarddn3@gmail.com

08-12-2021

08-12-2021

BIHAR

INAMUL HAQUE,
MANAGING
DIRECTOR

C/O- AMANUL HAQUE, HASHMIYA
COLONY PUGMIL, Hazaribagh
JHARKHAND 825301

Contact No:
9693544464

Email Id:
i.haque@ajwakaif.com

13-12-2021

13-12-2021

Contact No:
9969043786

Email Id:
vazalicia000@gmail.co
m

15-12-2021

15-12-2021

15-12-2021

15-12-2021

15-12-2021

15-12-2021

469

AJWA KAIF Pvt Ltd.

DS-11/282/2021-DS-III

B

470

AREA LINK NETWORKS Pvt Ltd.

DS-11/103/2021-DS-III

B

MUMBAI

NAME:ALICIA ROMEL
VAZ
Designation:DIRCTOR

2/A, FLOOR-1ST, READY MONEY
BUILDING, MIRZA GALIB MARG,
NAGPADA, MUMBAI CENTRAL,
MUMBAI Mumbai City
MAHARASHTRA 400008

471

SHEETALINTERNET SERVICES
Pvt Ltd.

DS-11/150/2021-DS-III

B

MUMBAI

NAME:Rakesh Yashwant
Choudhary
Designation:Director

LINK PALACE CHS, A3/517, P. G.
MARG, OPP TOYOTA SHOWROOM,
MALAD WEST Mumbai City
MAHARASHTRA 400064

Contact No:
8369108882

Email Id:
rakesh711019@gmail.co
m

472

WNET INTERNET Pvt Ltd.

DS-11/267/2021-DS-III

B

MUMBAI

NAME:Amit Vijaynath
Tiwari
Designation:Director

Room No. 301, 3rd Floor, Matruchhaya
Building, Poona Link Road, Katemanivali,
Kalyan East Thane MAHARASHTRA
421306

Contact No:
9820227846

Email Id:
amitvtiwari9@gmail.co
m

473

SIPLINK COMMUNICATIONS Pvt
Ltd.

DS-11/220/2021-DS-III

A

All India

NAME:Chandrasekaran
Arumugam
Designation:Director

NO.18/118 Sridharan Street, 8th street,
GKM Colony, Chennai TAMIL NADU
600082

Contact No:
9884655151

Email Id:
chandru@siplink.in

16-12-2021

16-12-2021

NAME:MAMTA
SHARMA
Designation:DIRECTOR

ATUL NIWAS, BADI BAZAR,
BHUSAGALI NEAR GOVARDHAN
AGENCY, MUNGER THANA
KOTAWALI, ZILA MUNGER, Munger
BIHAR - 811201.

Contact No:
8285004427

Email Id:
msharma@internetwala.c
o.in

20-12-2021

20-12-2021

NAME:Krushna Chandra
24, jinsi road jahangirabad bhopal Bhopal
Swain
MADHYA PRADESH 462008
Designation:Director

Contact No:
8889977550

Email Id: krishna@ntel.in

21-12-2021

21-12-2021

474

INTERNETWALA IT SERVICES
PVT LTD

DS-11/175/2020-DS-III

B

UTTAR PRADESH (WEST)

475

NYAK TECHNOLOGIES AND
TELESERVICES PVT LTD

DS-11/356/2021- DS-III

A

All India

476

OASIS SMART CONNECT Pvt Ltd.

DS-11/138/2021-DS-III

B

UTTAR PRADESH (WEST)

NAME:SUMIT KUMAR
Designation:DIRECTOR

19 CIVIL LINES, 2ND FLOOR, BATRA
COMPLEX,ROORKEE Haridwar
UTTARAKHAND 247667

Contact No:
9219765576

Email Id:
sumitisavailable@gmail.
com

22-12-2021

22-12-2021

477

TEJNET BROADBAND Pvt Ltd.

DS-11/148/2020-DS-III

B

UTTAR PRADESH (WEST)

NAME:SANJEEV
KUMAR AWASTHI
Designation:DIRECTOR

H.NO. -9-B-725 PHASE -2 BUDHI
VIHAR AVAS VIKAS MORADABAD,
UTTAR PRADESH - 244001

Contact No:
9411069053

Email Id:
tejnetbroadband@gmail.
com

23-12-2021

23-12-2021

478

NENCY CABLE PVT LTD

DS-11/301/2021-DS-III

C

Bhuj

NAME:SUNIL NARSHI
SORATHIYA
Designation:DIRECTOR

PLOT NO.9 AYODHYA NAGAR,
ANJAR Kutch GUJARAT 370110

Contact No:
9998652629

Email Id:
idealcomputer2001@gm
ail.com

28-12-2021

28-12-2021

479

MGI NETWORKS PVT LTD

DS-11/306/2021-DS-III

B

MUMBAI

NAME:Anish Mohan
Gupta
Designation:DIRECTOR

04,Sai paradise, GhanshyamGupte Road,
Dombivli WEST Thane
MAHARASHTRA 421202

Contact No:
8652227779

Email Id:
Anishmgupta73@gmail.
com

31-12-2021

31-12-2021

480

SHREE SWAMI SAMARTH
INTERNET AND CABLE Pvt Ltd.

DS-11/204/2021-DS-III

B

MUMBAI

NAME:Manisha Arvind
Jagtap
Designation:Director

55/D/1903, Saptarishi Towers CHSL.,
Near Bhoomi Mart, Bhoomi Park, Malad
West, Mumbai Mumbai City
MAHARASHTRA 400095

Contact No:
9004483842

Email Id:
shailesh.talkar@gmail.co
m

31-12-2021

31-12-2021

481

DV INFOCOM PRIVATE LIMITED

B

MAHARASHTRA

SWAMI KRUPA, FLAT NO. 201, SR.
NAME:VISHAL
NO 176/2B, SADGURU COLONY,
MANOHAR SATHE
WAKAD, PUNE Pune MAHARASHTRA
Designation:DIRECTOR
411057

Contact No:
9820194753

Email Id:
VIJAYSHAHINDIA@G
MAIL.COM

06-01-2022

06-01-2022

B

MAHARASHTRA

NAME:Shaikh Irfan
Ibrahim Patel
Designation:Managing
Director

Contact No:
9175396237

Email Id:
ipnetbroadbandpl@gmail
.com

06-01-2022

06-01-2022

B

Telecom circle/Metro Area

LOKESH KUMAR,
DIRECTOR

Contact No:
9999919096

Email Id:
support@qualitynet.in

07-01-2022

07-01-2022

UTTAR PRADESH (WEST)

LOKESH KUMAR,
DIRECTOR

Contact No:
9999919096

Email Id:
support@qualitynet.in

07-01-2022

07-01-2022

Contact No:
9920484759

Email Id:
anilw74@gmail.com

10-01-2022

10-01-2022

Contact No:
8424830421

Email Id:
mendonca.ruel@gmail.c
om

10-01-2022

10-01-2022

Contact No:
9891101375

Email Id:
amit.kumar1@awfis.com

10-01-2022

10-01-2022

18-01-2022

18-01-2022

18-01-2022

18-01-2022

DS-11/395/2021-DS-III

482

IPNET BROADBAND PRIVATE
LIMITED

House No.4, Patel Galli, Harsul,
Aurangabad Aurangabad
MAHARASHTRA 431001

DS-11/413/2021-DS-III
483

QUALITY BROADBAND
PRIVATE LIMITED

484

QUALITY BROADBAND
PRIVATE LIMITED

485

DS-11/185/2020-DS-III, DATED
07.01.2022
DS-11/185/2020-DS-III, DATED
07.01.2022

MAULI I NET PRIVATE LIMITED

B

B

MUMBAI

DS-11/350/2021-DS-III

486

JLR NETWORKS PRIVATE
LIMITED

487

AWLIV LIVING SOLUTIONS
PRIVATE LIMITED

488

OMSHARAN BROADBAND AND
CABLENET PRIVATE LIMITED

489

OMSHARAN BROADBAND AND
CABLENET PRIVATE LIMITED

DS-11/173/2020-DS-III DATED
10.01.2022

MUMBAI

NAME:RUEL JULIUS
MENDONCA
Designation:DIRECTOR
OF THE COMPANY

A

National Area

NAME:Amit Ramani
Designation:Director

B

MAHARASHTRA

OMKAR ASHOK
WAIKAR, DIRECTOR

B

MUMBAI

OMKAR ASHOK
WAIKAR, DIRECTOR

DS-11/150/2020-DS-III

DS-11/150/2020-DS-III

NAME:PRASAD
FLAT NO. 304, H. NO. 247/249,
SARJERAO YADAV SECTOR-6, SARSOLE VILLAGE, Thane
Designation:DIRECTOR
MAHARASHTRA 400706

B
DS-11/355/2021-DS-III

B/262 GALI NO-4 PREM VIHAR SHIV
VIHAR KARAWAL NAGER DELHI
East Delhi DELHI 110094
B/262 GALI NO-4 PREM VIHAR SHIV
VIHAR KARAWAL NAGER DELHI
East Delhi DELHI 110094

3C CHRISTIN DSOUZA HOUSE
KONDIVITA, RAM KRISHNA
MANDIR MARG, OPP PIDILITE,
ANDHERI EAST, Mumbai City
MAHARASHTRA 400059
C 28-29,Kissan Bhawan,Qutab
Institutional Area,New Delhi South West
Delhi DELHI 110016
SHOP NO. 4, PLOT NO. 200, SECTOR
21, NAVI MUMBAI Thane
MAHARASHTRA 400706
SHOP NO. 4, PLOT NO. 200, SECTOR
21, NAVI MUMBAI Thane
MAHARASHTRA 400706

Contact No:
9820194753
Contact No:
9820194753

Email Id:
omsharaninternet@yaho
o.com
Email Id:
omsharaninternet@yaho
o.com

<!-- page 19 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

490

Name of Licensee

License No.

ROBERTS NET SOLUTIONS
PRIVATE LIMITED

Category

Service Area

NETPOINT NETWORK PRIVATE
LIMITED

SHREEMAURYA INFOWAY
NETWORK PRIVATE LIMITED

ADITI NETWORK SOLUTIONS
PRIVATE LIMITED

MANASHREE INTERNET
SERVICE PRIVATE LIMITED

V NETCARE PRIVATE LIMITED

18-01-2022

18-01-2022

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

18-01-2022

18-01-2022

B

MUMBAI

NAME:BIPIN RAMESH SHOP NO. 11, TMC PUNARVASAN,
MOURYA
NR VARUN GARDEN, NAREND Thane
Designation:DIRECTOR
MAHARASHTRA 400610

Contact No:
9323191240

Email Id:
meenapandey251@yaho
o.com

19-01-2022

19-01-2022

B

MUMBAI

H. NO.-478, 3/5, CHANDRABHAGA
NAME:ARVIND
CHS, DILIP GUPTE NAGAR,
MANGA RATHOD
PARKSITE, VIKHROLI WEST Mumbai
Designation:DIRECTOR
City MAHARASHTRA 400079

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

19-01-2022

19-01-2022

C

MAHARASHTRA(KALYAN)

NAME:POONAM
MAHENDRA PATIL
Designation:DIRECTOR

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

19-01-2022

19-01-2022

GUJARAT

NAME:Mitesh
Jayantibhai Patel
Designation:Director

Contact No:
9426655866

Email Id:
mitesh@vnetcare.net

20-01-2022

20-01-2022

B

VARSHINI COMMUNICATIONS
PRIVATE LIMITED

Contact No:
9870322103

NORTH BLOCK, 2ND FLOOR, 71
NAME:AMAN ABDUL
KENJALKAR PREMISES, PATANKAR
ALIM KHAN
MARG, KURLA WEST Mumbai City
Designation:DIRECTOR
MAHARASHTRA 400070

DS-11/385/2021-DS-III

496

Effective Date

MUMBAI

DS-11/383/2021-DS-III
495

Date of Signing UL

B

DS-11/440/2021-DS-III
494

Mail ID

Email Id:
Vijaydcruz20@gmail.co
m

MUMBAI

DS-11/371/2021-DS-III

493

Contact No.
Mobile

B

DS-11/388/2021-DS-III
492

Registered Office Address

501 EKVIRA PRASAD PLOT NO.75
NAME:Vijay Stany D
M.G.ROAD, TILAK NAGAR ROAD
Cruz
NO.5 GOREGAON WEST, MUMBAI,
Designation:DIRECTOR Mumbai City, Maharashtra, India Mumbai
City MAHARASHTRA 400104

DS-11/357/2021-DS-III

491

Authorized Person

FLAT NO. 102, 1ST FLOOR,
DONGRIPADA, PONAM VASAI,
PALGHAR Thane MAHARASHTRA
401208
G F 26 SHIVSHAKTI COMPLEX
DEHGAM Gandhinagar Gandhinagar
GUJARAT 382305

C

NAME:BILLAMARNA
VASANTH VIHAR COMMUNITY
HALLI SRINIVASAIAH
CENTRE,SHOP NO.2 AWHO
KARNATAKA(BANGALORE
LAKSHMIVENKATES COLONY,BILLAMARANAHALLI,BET
)
H
AHALASUR BANGALORE Bangalore
Designation:DIRECTOR
Urban KARNATAKA 562157

Contact No:
9902977233

Email Id:
saidigitalsignature@gma
il.com

20-01-2022

20-01-2022

C

ANDHRA
PRADESH(VIJAYAWADA)

DOOR NO 8-28/1a, MUKKAPATI VARI
NAME:Vamsi Krishna
BAZAR, CHANDARLAPADU,
Mukkapati
KRISHNA, ANDHRA PRADESH, INDIA
Designation:DIRECTOR
Krishna ANDHRA PRADESH 521182

Contact No:
6309331331

Email Id:
vamsimukkapati@gmail.
com

21-01-2022

21-01-2022

B

WEST BENGAL

NAME:MINTU
BISWAS
Designation:DIRECTOR

PEGASUSWAVE PRIVATE
LIMITED,SANAT BISWAS, NATNA,
PATABUKA Nadia WEST BENGAL
741122

Contact No:
9910607263

Email Id:
mintu@pegasuswave.co
m

24-01-2022

24-01-2022

C

JORHAT

UDDIPAN DOWARAH,
DIRECTOR

C,O BHABESH CH. CHANGKAKOTY,
H. NO. 26, MILON NAGAR,
DIBRUGARH, ASSAM, INDIA 786001
Dibrugarh ASSAM 786001

Contact No:
9864299685

Email Id:
udowarah@gmail.com

24-01-2022

24-01-2022

C

TINSUKHIA (DIBRUGARH)

UDDIPAN DOWARAH,
DIRECTOR

C,O BHABESH CH. CHANGKAKOTY,
H. NO. 26, MILON NAGAR,
DIBRUGARH, ASSAM, INDIA 786001
Dibrugarh ASSAM 786001

Contact No:
9864299685

Email Id:
udowarah@gmail.com

24-01-2022

24-01-2022

C

KARNATAKA(BANGALORE
)

NAME:RANGAPPAN 5TH BLOCK, S-14, 2ND PLOT NO.S14,
AMUDA
20TH MAIN ROAD KORAMANGALA
Designation:DIRECTOR Bangalore Urban KARNATAKA 560095

Contact No:
8667710055

Email Id:
babuamuda@gmail.com

24-01-2022

24-01-2022

B

Telecom circle/Metro Area

6, ANAND APARTMENT, SANE
NAME:PRASHANT S
GURUJI NAGAR, LOKMANYA TILAK
CHAVAN
ROAD, MULUND EAST Mumbai City
Designation:DIRECTOR
MAHARASHTRA 400081

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

25-01-2022

25-01-2022

B

Telecom circle/Metro Area

NAME:HASNAIN
R NO A10 YAKUB CHL GANDHI
SIDDIQUI
NAGAR, KURLA NR BUS DEPO
Designation:DIRECTOR Mumbai City MAHARASHTRA 400024

Contact No:
7373734665

Email Id:
info@tolabroadband.com

25-01-2022

25-01-2022

C

ASSAM(SILCHAR)

HOUSE NO 101 AZAD HIND ROAD,
CHENGKURI ROAD, NEAR RAMANUJ
SCHOOL, SILCHAR, CACHAR,
ASSAM, INDIA, 788007 Cachar ASSAM
788007

Contact No:
7002791632

Email Id:
sumitnath86@gmail.com

27-01-2022

27-01-2022

B

DELHI

PLOT IN KH NO-463 SECOND FLOOR
NAME:DEVENDRA
R/SIDE, VILL MAHIPALPUR NEAR
KUMAR MISHRA
RAJENDER AOPOARMENT, DELHI,
Designation:DIRECTOR NEW DELHI, INDIA 110037 South West
Delhi DELHI 110037

Contact No:
9999787662

Email Id:
spectruminternet.del@g
mail.com

28-01-2022

28-01-2022

C

MAHARASHTRA(PUNE)

NAME:Nitin Sharnappa
Shinde
Designation:director

SR No.311/5, Sai Park Haveli, Uruli
Dewachi, Pune, Maharashtra Pune
MAHARASHTRA 412308

Contact No:
7428571121

Email Id:
info.anshauryainfocom@
gmail.com

28-01-2022

28-01-2022

C

MAHARASHTRA(AURANGA
BAD)

NAME:YOUNUS
MOHAMMAD ABED
MOHAMMAD KHAN
Designation:DIRECTOR

FLAT NO. 5, CTS NO. 10041,
NIZAMUDDIN ROAD BUKKAL GU
Aurangabad MAHARASHTRA 431001

Contact No:
9370200300

Email Id:
abn.isp@gmail.com

28-01-2022

28-01-2022

A

National Area

NAME:Heera Girish
Designation:CFO

129, 10th Cross, CMH Road, Indiranagar
Bangalore Urban KARNATAKA 560038

Contact No:
9845433658

Email Id:
devarjun.das@ibusnetwo
rks.com

31-01-2022

22-03-2021

GUJARAT

NAME:Rajesh
Bhikhabhai Patel
Designation:Managing
Director

B/308,Sunrise Comarcial Complex,
Lajamani chowk Mota varachha Surat
GUJARAT 394101

Contact No:
9925190064

Email Id:
rajuhet@gmail.com

02-02-2022

02-02-2022

Contact No:
9666662542

Email Id:
srinettfiber@gmail.com

02-02-2022

02-02-2022

DS-11/403/2021-DS-III

497

REDX NETWORKING
SOLUTIONS PRIVATE LIMITED

498

PEGASUSWAVE PRIVATE
LIMITED

Ds-11/404/2021-Ds-III

DS-11/148/2021-DS-III

499

POLY INFORMATICS PRIVATE
LIMITED
DS-11/311/2021-DS-III

500

POLY INFORMATICS PRIVATE
LIMITED
DS-11/311/2021-DS-III

501

MAIVW BROADBAND PVT LTD
DS-11/361/2021-DS-III

502

VOZVELO BROADBAND
PRIVATE LIMITED
No:DS-11/117/2020-DS-III

503

TOLA BROADBAND (OPC)
PRIVATE LIMITED
DS-11/125/2020-DS-III

504

BIC TRADE PRIVATE LIMITED

NAME:SUMIT NATH
Designation:DIRECTOR

DS-11/189/2020-DS-III

505

506

507

SPECTRUM WIFIINTERNET
WORLD INDIA PRIVATE
LIMITED

ANSHAURYA INFOCOM
PRIVATE LIMITED

DS-11/259/2021-DS-III, DATED
28.01.2022

DS-11/460/2021-DS-III

ABNSERVICES PVT LTD
DS-11/493/2021-DS-III

508

509

IBUS VIRTUAL NETWORK
SERVICES PRIVATE LIMITED

20-1194/2020 AS-I

UNIFY NETSOL PRIVATE
LIMITED

B
DS-11/111/2019-DS-III

510

SRI NETT PRIVATE LIMITED

511

SRI NETT PRIVATE LIMITED

ANDHRA PRADESH

B

TAMIL NADU

Subramanyam Bethu,
DIRECTOR

BIHAR(GAYA)

NAME:TEJ NARAYAN
SINGH
Designation:DIRECTOR

TAMIL NADU

NAME: Venkatesan
Designation: Managing
Director

Ds-11/494/2021-Ds-III
512

MAHADEV TELEVENTURES
PRIVATE LIMITED

C
DS-11/429/2021-DS-III

513

514

RAAGAV COMMUNICATIONS
PRIVATE LIMITED

B
DS-11/96/2021-DS-III

DATAWINGS TELEINFRA
PRIVATE LIMITED

Subramanyam Bethu,
DIRECTOR

B
Ds-11/494/2021-Ds-III

B

TAMIL NADU

NAME:PERIYASAMY
Designation:DIRECTOR

B

WEST BENGAL

NAME:AMIT KOHLI
Designation:DIRECTOR

GUJARAT

NAME:jayesh patel
Designation:DIRECTOR

DS-11/335/2021-DS-III
515

GOLCON TECHNOLOGIES
PRIVATE LIMITED

516

SOFTNET DIGITAL CABLE
PRIVATE LIMITED

DS-11/425/2021-DS-III DATED
04.02.2022

B
DS-11/436/2021-DS-III

8/160, Tirupathi Road, Puttur, Chittoor,
Andhra Pradesh Chittoor ANDHRA
PRADESH 517583
8/160, Tirupathi Road, Puttur, Chittoor,
Andhra Pradesh Chittoor ANDHRA
PRADESH 517583

Contact No:
9666662542

Email Id:
srinettfiber@gmail.com

02-02-2022

02-02-2022

KISHAN MARKET, LAKHAN MORE,
DAUDNAGAR Aurangabad BIHAR
824143

Contact No:
9873851918

Email Id:
iamtej@mexon.in

02-02-2022

02-02-2022

Raagav Communications Pvt Ltd

Contact No:
9043425255
9344234900

Email Id:
raagavcomsalem@yahoo
.com

03-02-2022

03-02-2022

Contact No:
8489204331

Email Id:
Info@datawingstel.in

04-02-2022

04-02-2022

Contact No:
9899503007

Email Id:
Smbcpl@gmail.com

04-02-2022

04-02-2022

Contact No:
9824390065

Email Id:
softnetunjha@gmail.com

04-02-2022

04-02-2022

DOOR.NO.3/115,
NARYIAMPALLIPUDUR,
KARUVALUR, ANNUR,
COIMBATORE Coimbatore TAMIL
NADU 641653
55, GROUND FLOOR COMUNITY
CENTRE EAST OF KAILASH DELHI,
South Delhi, India South Delhi DELHI
110065
F-4 shah budhalal shopping center,
Mehsana GUJARAT 384170

<!-- page 20 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

517

Name of Licensee

License No.

SPEEDPULSE FIBERNET
PRIVATE LIMITED

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

NAME:ANUPAM
PRADHAN
Designation:DIRECTOR

BL-A1, PLOT NO306/1800,VAISHNAVI PALACE,
PATIA, PS- CHANDRASEKHARPUR,
BHUBANESWAR Khordha ORISSA
751024

Contact No:
9986111457

Email Id:
pradhananupam@gmail.
com

04-02-2022

04-02-2022

GF-07, Tower-B, VATIKA
NAME:TARUN
MINDSCAPES,12/3, N.H-2, SARAI
KUMAR
KHWAJA, SECTOR-27D, FARIDABAD
Designation:DIRECTOR
Faridabad HARYANA 121003

Contact No:
8920217748

Email Id:
tkbhati@yahoo.com

09-02-2022

09-02-2022

NAME:GURUCHARAN
SINGH HORA
Designation:DIRECTOR

SHOP NO B27/7, Near Ashadeep
Hospital, New Rajendra Nagar Raipur
Raipur CHHATTISGARH 492001

Contact No:
9630311111

Email Id:
g.hora03@gmail.com

09-02-2022

09-02-2022

MUMBAI

NAME:NURESH
PRABHAKAR FUKE
Designation:DIRECTOR

NEHRU VIKAS MANDAL, BHARAT
NAGAR, OPP.- CHAWL NO. 52,
BANDRA EAST Mumbai City
MAHARASHTRA 400051

Contact No:
8655583500

Email Id:
nareshfuke@gmail.com

10-02-2022

10-02-2022

B

MAHARASHTRA

NAME:Rahul Bhaskar
Varal
Designation:Managing
Director

Servey No. 40 Digambar Nagar
WadgaonSheri Pune MAHARASHTRA
411014

Contact No:
9595143141

Email Id:
netforu3141@gmail.com

10-02-2022

10-02-2022

C

MAHARASHTRA(PEN)

NAME:ASHWINI AMIT
GURAV
Designation:DIRECTOR

148 B, DATTA MANDIR ROAD,
VESHI, TALUKA ALIBAUG, VESHI,
RAIGARH, MAHARASHTRA INDIA402201 Raigad MAHARASHTRA
402201

Contact No:
9881540094

Email Id:
ashgurav81@gmail.com

10-02-2022

10-02-2022

C

JAIPUR

NAME:Aparna Anant
Designation:Director

43-A PAWAN PUTRA COLONY
JAIPUR Jaipur RAJASTHAN 302034

Contact No:
9529469959

Email Id:
aparnaanant21@gmail.c
om

11-02-2022

11-02-2022

Contact No:
9609003636

Email Id:
inbox.optinet@gmail.co
m

11-02-2022

11-02-2022

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

11-02-2022

11-02-2022

Contact No:
9819727686

Email Id:
aartiachare707@gmail.c
om

11-02-2022

11-02-2022

Contact No:
9854060745

Email Id:
mithun@gignetit.com

14-02-2022

14-02-2022

Contact No:
9854060745

Email Id:
mithun@gignetit.com

14-02-2022

14-02-2022

Contact No:
9666652553

Email Id:
suchitha@myzoomfibers
olutions.com

21-02-2022

21-02-2022

Contact No:
9830077358

Email Id:
sales@bacbpl.com

22-02-2022

27-01-2021

Contact No:
8336921711

Email Id:
avijitpoddar126@gmail.
com

03-03-2022

03-03-2022

Contact No:
7982141102

Email Id:
info@evincenetwork.co
m

03-03-2022

03-03-2022

Category

Service Area

C

ORISSA(BHUBANESWAR
(PURI))

B

DELHI

A

National Area

DS-11/264/2021-DS-III

518

519

PLAYERNET TECHNOLOGIES
PRIVATE LIMITED

DS-11/384/2021-DS-III, DATED
09/02/2022

GRAND BROADBAND SERVICES
PRIVATE LIMITED
DS-11/391/2021-DS-III

520

NWT INTERNET SERVICES
PRIVATE LIMITED

B
DS-11/405/2021-DS-III

521

NET FOR U NETWORK PRIVATE
LIMITED
DS-11/485/2021-DS-III

522

ASHWIT BROADBAND (OPC)
PRIVATE LIMITED
DS-11/516/2021-DS-III

523

524

ASMITA INFOCOM PRIVATE
LIMITED

DS-11/123/2021-DS-III

OPTICOM NETWORKS PRIVATE
LIMITED

B

ORISSA

NAME:ABHISEK
DUTTA
Designation:DIRECTOR

VILL.-HASIMPUR, P.O.-KESHIARY,
KHARAGPUR, MIDNAPORE, WEST
BENGAL, INDIA 721133 Paschim
Medinipur WEST BENGAL 721133

B

MUMBAI

NAME:SHAHNAWAZ
SHAMSUDDIN KHAN
Designation:DIRECTOR

ROOM NO 1A-4A, RAZAKWADI
CHAWL, KHERWADI ROAD,
BANDRA EAST Mumbai City
MAHARASHTRA 400051

B

MUMBAI

NAME:AARTI ASHISH
ACHARE
Designation:DIRECTOR

B

ASSAM

DS-11/178/2020-DS-III

525

NAWAZ STAR SERVICES
PRIVATE LIMITED
DS-11/441/2021-DS-III

526

ACHARE BROADBAND (OPC)
PRIVATE LIMITED
DS-11/463/2021-DS-III

527

528

529

GIGNET IT SERVICES PRIVATE
LIMITED
GIGNET IT SERVICES PRIVATE
LIMITED

DS-11/347/2021-DS-III
B

NORTH EAST

DS-11/347/2021-DS-III

MYZOOM FIBER SOLUTIONS
(OPC) PRIVATE LIMITED

B

ANDHRA PRADESH

B

GUJARAT

DS-11/9/2022-DS-III
530

531

BHORER ALO CABLE AND
BROADBAND PRIVATE LIMITED

DS-11/231/2019-DS-III

CREATICK BROADBAND
PRIVATE LIMITED

EVINCE NETWORK PRIVATE
LIMITED

NSB NETWORKS PRIVATE
LIMITED

B

BIHAR

B

BIHAR

NAME:MOHAMMAD
NAUMAN ALAM
Designation:DIRECTOR

57 NH Road Ward No 16, Bus Stand
Araria, Bihar Araria BIHAR 854311

Contact No:
06453295760,
8907107477

Email Id:
nsc.nsb@gmail.com

03-03-2022

03-03-2022

B

WEST BENGAL

NAME:kousik kar
Designation:Director

SUBHADEEP BUILDING, ALAMPUR
ANDUL ROAD, NEW KOLORAH,
HOWRAH, Howrah, West Bengal, India,
711302 Howrah WEST BENGAL 711302

Contact No:
7428571121

Email Id:
stromnetbroadbandservic
es@gmail.com

04-03-2022

04-03-2022

B

KOLKATA

NAME:kousik kar
Designation:Director

SUBHADEEP BUILDING, ALAMPUR
ANDUL ROAD, NEW KOLORAH,
HOWRAH, Howrah, West Bengal, India,
711302 Howrah WEST BENGAL 711302

Contact No:
7428571121

Email Id:
stromnetbroadbandservic
es@gmail.com

04-03-2022

04-03-2022

C

BIHAR(DARBHANGA)

NAME:RAHUL RAJ
Designation:DIRECTOR

01, S/O RAM LALIT SHAH, R S TANK,
NAVTOLIYA LAHERIASARAI
Darbhanga BIHAR 846001

Contact No:
7991188301

Email Id:
rk9260@gmail.com

07-03-2022

07-03-2022

NAME:Khevendra Singh
Designation:Director

Suit No. 203-M, Ground Floor Building
No 2000, Doon Express Business Park,
Opp To Transport Nagar, Dehradun,
Uttrakhand Dehradun UTTARAKHAND
248002

Contact No:
9410100802

Email Id:
khevendra@linkwave.co.
in

08-03-2022

08-03-2022

SN 167/1, 46A. SANDI-PANI COLONY,
NAME:MAHESH
SHIRPUR, DHULE, Dhule, TRUE COPY
ARUN SHISODE
Maharashtra, India, 425405 Dhule
Designation:DIRECTOR
MAHARASHTRA 425405

Contact No:
9967329390

Email Id:
mahesh@chatsignal.in

08-03-2022

08-03-2022

DS-11/492/2021-DS-III

534

STROMNET BROADBAND
SERVICES PRIVATE LIMITED
DS-11/421/2021-DS-III

535

STROMNET BROADBAND
SERVICES PRIVATE LIMITED
DS-11/421/2021-DS-III

536

FUTURENET BROADBAND AND
INTERNET SERVICES PVT LTD
DS-11/511/2021-DS-III

537

LINKWAVE TECHNOLOGIES PVT
LTD

B

UTTAR PRADESH (WEST)

A

National Area

C

MAHARASHTRA(PUNE)

NAME:Swapnil
Krishnarao Deshmukh
Designation:Director

SECTOR NO. 1, PLOT NO A/2, HOUSE
NO14, SANKALP HSG SOC.,
INDRAYANI NAGAR PCNTDA,
BHOSARI, PUNE, MAHARASHTRA
Pune MAHARASHTRA 411026

Contact No:
8888807888

Email Id:
deshmukhswapnilk@gm
ail.com

08-03-2022

08-03-2022

B

MUMBAI

NAME:ABDUL AZIZ
ABDUL RAHIM KHAN
Designation:DIRECTOR

Shop No.101 Hi-Tech Premises Society
LIG, Colony Kurla West Nr. Vinoba
Bhave Nagar Mumbai City
MAHARASHTRA 400070

Contact No:
9619166146

Email Id:
ABDULAZIZ2526@G
MAIL.COM

09-03-2022

09-03-2022

B

MUMBAI

NAME:VISHAL
SHIRISH SAXENA
Designation:DIRECTOR

601-A, BLDG NO. 2, KOLDONGRI CHS
LTD, SAHAR ROAD, PARSI WADA,
ANDHERI EAST Mumbai City
MAHARASHTRA 400099

Contact No:
9892945787

Email Id:
yashsaxena46@gmail.co
m

09-03-2022

09-03-2022

B

Himachal Pradesh

NAME:MUNISH
KHANNA
Designation:DIRECTOR

FIRST FLOOR KHANNA BHAWAN,
NEAR MONAL PUBLIC SCHOOL,
SANJAULI, SHIMLA, HIMACHAL
PRADESH, INDIA 171006 Shimla
HIMACHAL PRADESH 171006

Contact No:
9218500185

Email Id:
munish.khanna185@yah
oo.in

09-03-2022

09-03-2022

B

TAMIL NADU

NAME:A JERALD
VIMAL
Designation:Director

15, Shiva Lodge Complex, Old
Agaraharam, Commercial Road, Ooty,
Nilgiris, Tamil Nadu Nilgiris TAMIL
NADU 643001

Contact No:
9899747425

Email Id:
jeraldvimal@gmail.com

11-03-2022

11-03-2022

DS-11/464/2021-DS-III

538

CHATSIGNAL PRIVATE LIMITED
DS-11/422/2021-DS-III

539

FTTH BROADBAND (OPC)
PRIVATE LIMITED
DS-11/500/2021-DS-III

540

BRIGHTNET INTERNET
SOLUTIONS (OPC) PRIVATE
LIMITED
DS-11/139/2021-DS-III

541

DBS INFOWAY INDIA PRIVATE
LIMITED
DS-11/312/2021-DS-III

542

CRYSTALCLEAR NETWORK
PRIVATE LIMITED
DS-11/504/2021-DS-III

543

VFIBERNET COMMUNICATION
TECHNOLOGIES PVT. LTD.
DS-11/146/2021-DS-III

29/2C Chandranath Chatterjee Street
Kolkata WEST BENGAL 700025

C/o, Nirod Bihari Biswas, VILL. 2No.
NAME:AVIJIT
Colony, P.O. Kantatala, SOUTH 24
PODDAR
PARGANA, Parganas South, West Bengal,
Designation:DIRECTOR India South 24 Parganas WEST BENGAL
743502
C/O- RANVIJAY RANA S/ONAME:RANVIJAY
NARAYAN YADAV, KOCHAILI
RANA
DAGARUA, BARSAUN, PURNEA
Designation:DIRECTOR
Purnia BIHAR 854326

WEST BENGAL

DS-11/10/2022-DS-III
533

NAME:Lokesh Agarwal
Designation:Director

B
DS-11/412/2021-DS-III

532

FLAT NO 1, PLOT NO 86 DHARAM
JIVAN C H S, SECTOR 6 KOPAR
KHAIRNE THANE NAVI MUMBAI
MUMBAI CITY MAHARASHTRA
INDIA- 400709 Thane MAHARASHTRA
400709
305E, 4th Floor, Maya Apartment, MRD
MITHUN ROUTH,
Road, New Guwahati Tiniali Kamrup
DIRECTOR
ASSAM 781020
305E, 4th Floor, Maya Apartment, MRD
MITHUN ROUTH,
Road, New Guwahati Tiniali Kamrup
DIRECTOR
ASSAM 781020
2-2-647/A/60, SAIBABA NAGAR
NAME:Suchitha Puskur
COLONY, BAGH AMBERPET,
Designation:Director
HYDERABAD Hyderabad TELANGANA
500013

<!-- page 21 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

544

Name of Licensee

License No.

SYNCEVO TECHNOLOGIES
PRIVATE LIMITED

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

Contact No:
8700177325

Email Id:
vikramsingh87@hotmail
.com

15-03-2022

15-03-2022

B

BIHAR

NAME:Vikram Kumar
Designation:DIRECTOR

351/A,ROAD NO.5 ASHOK NAGAR,,
RANCHI, RANCHI, JHARKHAND,
INDIA, Ranchi JHARKHAND 834002

B

KOLKATA

NAME:KIRANMOY
KUNTI
Designation:DIRECTOR

3/2 ADHAR DAS ROAD South 24
Parganas WEST BENGAL 700137

Contact No:
9674050957

Email Id:
futiontechnosolutionspvtl
td@gmail.com

16-03-2022

16-03-2022

KARNATAKA(BELGAUM)

NAME:SANTOSH
VIJAY CHAVAN
Designation:DIRECTOR

CST No. 3290/B Ground Floor, Shop
No.3, Kambar Complex, Hospeth Galli
Gokak Belgaum KARNATAKA 591307

Contact No:
7507838385

Email Id:
santosh@vvcnet.in

22-03-2022

22-03-2022

KERALA

NAME:Dhanajayan
Puthiyaveetil
Designation:Managing
Director

3rd floor, Door no 49/2040, MAS
BUILDING, VYTTILA Ernakulam
KERALA 682019

Contact No:
7034090000

Email Id:
tracksync2020@gmail.c
om

23-03-2022

23-03-2022

Contact No:
8812069145

Email Id:
unmbroadband@gmail.c
om

25-03-2022

25-03-2022

Contact No:
8812069145

Email Id:
unmbroadband@gmail.c
om

25-03-2022

25-03-2022

01143621199
,9899333883

vikas.sharma@singtel.co
m

DS-11/22/2022-DS-III
545

FUTION TECHNOSOLUTIONS
PVT LTD
DS-11/420/2021-DS-III

546

VVCNET SERVICES PVT LTD

C
DS-11/519/2021-DS-III

547

TRACKSYNC TECHNOLOGIES
PRIVATE LIMITED

B
DS-11/503/2021-DS-III

548

UNM BROADBAND SERVICE
PRIVATE LIMITED

C
DS-11/316/2021-DS-III

549

UNM BROADBAND SERVICE
PRIVATE LIMITED

C
DS-11/316/2021-DS-III

550

SINGTEL GLOBAL (INDIA)
PRIVATE LIMITED

551

Triway Communications Private
Limited

DS-11/338/2021-DS-III
30-03-2022

A

B

NO 1 SAIKIA MARKET, 1ST
MOHAMMAD MYNUL FLOOR,STATION ROAD, DULIAJAN,
JORHAT
HUSSAIN, DIRECTOR
Dibrugarh, Assam, India Dibrugarh
ASSAM 786602
NO 1 SAIKIA MARKET, 1ST
MOHAMMAD MYNUL FLOOR,STATION ROAD, DULIAJAN,
TINSUKHIA (DIBRUGARH)
HUSSAIN, DIRECTOR
Dibrugarh, Assam, India Dibrugarh
ASSAM 786602
1307, B Wing, 13th Floor, Statesman
Arjun Soota
National Area
House, 148, Barakhamba Road, Central
Director
Delhi-110001

30-03-2022

30-03-2022

Karnataka

NAME: S Anuradha
Designation: Director

No. 161, 4th cross, 1st Main, Prashanth
Extension, Whitefield, Bangalore- 560 066

Contact No:
9845095828

Email
Id:accounts@triwaycom
munications.co.in

30-03-2022

30-03-2022

NAME:ANTONY RAJA
MANI MAITHILY
MARY
Designation:DIRECTOR

Times Square 7/8th FLR CTS 349/349-1
WE Highway NR Sai Service, Andheri
East, Mumbai Mumbai City
MAHARASHTRA 400069

Contact No:
9787809301

Email Id:
marymaithily@gmail.co
m

01-04-2022

28-03-2022

NAME:Prasad Gajanan A-97, Dattaguru CHS, Sector-4 Sanpada,
Gondhalekar
NaviMumbai, Thane , Maharashtra ,
Designation:DIRECTOR India Thane MAHARASHTRA 400705

Contact No:
8983717047

Email Id:
prasad@wsonline.co.in

01-04-2022

01-04-2022

RAJASTHAN

NAME:OM PRAKASH
JAT
Designation:DIRECTOR

Contact No:
9785551677

Email Id:
omdevjat@gmail.com

04-04-2022

04-04-2022

ORISSA

NAME:ABHIJEET
PANDA
Designation:DIRECTOR

Contact No:
7377331433

Email Id:
abhijeet.panda@wiretel.i
n

04-04-2022

04-04-2022

UTTAR PRADESH (WEST)

NAME:ROHIT
CHOUDHERY
Designation:DIRECTOR

Contact No:
9410010227

Email Id:
ROHIT95JAAT@GMA
IL.COM

04-04-2022

04-04-2022

Contact No:
9040707871

Email Id:
r8brodnet@gmail.com

06-04-2022

06-04-2022

DS-11/27/2022-DS-III

552

NISS COMMUNICATION
PRIVATE LIMITED

20-1282/2021-AS-I

A

National Area

553

WORLDSKY ONLINE PRIVATE
LIMITED

DS-11/431/2021-DS-III

B

MUMBAI

554

555

556

PRO MULTILINK SERVICE (OPC)
PRIVATE LIMITED

EM-CYBERSPACE SERVICES
PRIVATE LIMITED

BHARAT OPTICAL FIBER
SERVICES PRIVATE LIMITED

DS-11/386/2021-DS-III

DS-II/563/2021-DS-III

DS-11/96/2022-DS-III

B

B

B

PLOT NO 262,VAIBHAV VIHAR,
HURDA, GULABPURA Bhilwara
RAJASTHAN 311022
B1 INDUSTRIAL ESTATE
RASULGARH BHUBANESWAR
Khordha Orissa India Khordha ORISSA
751010
33- VILL- KUBEE PO RAJABPUR,
AMROHA, JP NAGAR, JYOTIBA
PHULE NAGAR Amroha UTTAR
PRADESH 244236

557

R8BRODNET NETWORKS
PRIVATE LIMITED

DS-11/520/2021-DS-III

B

ORISSA

NAME:Jhumirani Mishra
Designation:Director

C/O- Kulamani Mishra, At-Nilachakra
Nagar, 2nd Gali, Ward No-8, Titilagarh,
Balangir Balangir ORISSA 767033

558

SND CABLE AND INTERNET
SERVICES PVT LTD

DS-11/222/2021-DS-III

C

MAHARASHTRA(KALYAN)

NAME:DHANRAJ
SHIVAJI PATIL
Designation:DIRECTOR

HNO. 1630/4 NEAR BHOPI BUILDING,
NEW BHOPIWADI AMBERNATH
WEST, AMBERNATH Thane
MAHARASHTRA 421501

Contact No:
9082259196

Email Id:
dhanp777@yahoo.com

06-04-2022

06-04-2022

559

JEEVAMRUTHAM
TELECOMMUNICATIONS
PRIVATE LIMITED

DS-11/462/2021-DS-III

C

TAMIL NADU
(TIRUNELVELLI)

NAME:Saravanan V
Designation:Authorized
Signatory

Flat No.2, 361, Avvai Shanmugam Salai,
Lloyds Road, Gopalapuram Chennai
TAMIL NADU 600086

Contact No:
9003030349

Email Id:
osp.admin@zohocorp.co
m

06-04-2022

06-04-2022

560

AIRMAX SOLUTION AND
INTERNET SERVICES PRIVATE
LIMITED

DS-11/542/2021-DS-III

B

UTTAR PRADESH (WEST)

C/O MANOJ SINGH RANA, PADIYAR
NAME:MANOJ SINGH
COMPLEX, NEAR UNIVERSITY
RANA
GATE, SRINAGAR, PAURIGARHWAL,
Designation:DIRECTOR
UTTARAKHAND- 246174 Pauri
UTTARAKHAND 246174

Contact No:
7428571121

Email Id:
contact.asispl@gmail.co
m

06-04-2022

06-04-2022

561

BLESS NETWORK PRIVATE
LIMITED

DS-11/541/2021-DS-III

B

MAHARASHTRA

NAME:SANJAY
Shop no.03, Plot no.106 Mahavir Darpan,
PADAJI NAIK
Behind Majjid, Sector-19, ULWE Raigad
Designation:DIRECTOR
MAHARASHTRA 410206

Contact No:
9372606719

Email Id:
blessnetwork1234@gmai
l.com

07-04-2022

07-04-2022

562

CHINTAMANI BROADBAND
SERVICES PRIVATE LIMITED

DS-11/479/2021-DS-III

C

MAHARASHTRA(PUNE)

S NO 74/ 8 AND 69 /7 JAY GANESH
NAME:SUKHADEV
NIWAS RAJANIGANDHA HSG SOC
HANUMANT LADKAT CHINCHWAD PUNE MAHARASHTRA
Designation:DIRECTOR INDIA 411033 Pune MAHARASHTRA
411033

Contact No:
8888101830

Email Id:
chintamanicbs@gmail.co
m

07-04-2022

07-04-2022

563

TELEMANTRRA SALES
CORPORATION PRIVATE
LIMITED

DS-11/544/2021-DS-III

B

MAHARASHTRA

Contact No:
7767005900

Email Id:
aamit.singh47@gmail.co
m

07-04-2022

07-04-2022

11-04-2022

11-04-2022

564

HAZE INTERNET SERVICES
PRIVATE LIMITED

DS-11/490/2021-DS-III

C

NAME:Amit Kumar
Singh
Designation:Managing
Director

UNIT NO 2/204 SECOND FLOOR
TURNING POINT 2 PLOT NO 8
SERVEY NO 206/3 CTS NO 101
LOHEGAON HAVELI Pune
MAHARASHTRA 411014

GUJARAT(VALSAD)

NAME:PRADEEP
TB-7, SOLITAIRE BUSINESS CENTRE,
HASTIMAL JAIN
SILVASSA ROAD, VAPI Valsad
Designation:AUTHORIS
GUJARAT 396191
ED SIGNATORY

Contact No:
9824678772

Email Id:
hazeinternet@gmail.com

565

Crystalclear Metwork Private Limited

DS-11/504/2021-DS-III

B

HIMACHAL PRADESH

Munish khanna

Khanna Bhawan , near munal public school
, Sanjauli Shimla 171006

9218500185

munish.khanna185@yah
oo.in

11.04.2022

11.04.2022

566

GOGETNET INDIA PRIVATE
LIMITED

DS-11/480/2021-DS-III

C

KARNATAKA(MYSORE)

NAME:DEBJYOTI
ROY
Designation:Director

No 346, 6th Main, 2nd Stage, Gokulam,
Mysuru Mysore KARNATAKA 570002

Contact No:
9916077877

Email Id:
admin@gogetnet.com

13-04-2022

13-04-2022

567

EKADANTA NETWORKS
PRIVATE LIMITED

No: DS-11/483/2021-DS-III

B

MUMBAI

NAME:AARTI VIJAY
37/1472 SAHYADRI CHS LTD FIRST
MANJREKAR
FLOOR DN NAGAR ANDHERI WEST
Designation:DIRECTOR Mumbai City MAHARASHTRA 400053

Contact No:
8291289690

Email Id:
nadimshaikh83@gmail.c
om

13-04-2022

13-04-2022

568

HELIOCAST PRIVATE LIMITED

No: DS-11/502/ 2021-DS-III

B

MUMBAI

NAME:PARTH
A/2, SILVER OAK CHS, BHATT LANE,
GHANSHYAM MEHTA
BORIVALI WEST Mumbai City
Designation:DIRECTOR
MAHARASHTRA 400092

Contact No:
9833114422

Email Id:
contact.arthnet@gmail.c
om

13-04-2022

13-04-2022

569

ATEBYTE DATA FIBER PRIVATE
LIMITED

DS-11/562/2021-DS-III

B

KARNATAKA

SIGMA ARCADE,203B,2ND
FLR,MARTHAHALLI,NEAR BRAND
FACTORY,HAL OLD AIRPORT
RD,BANGALORE,KARNATAKA,INDI
A,560037 Bangalore Urban
KARNATAKA 560037

Contact No:
8861375912

Email Id:
ATEBYTETECHNOLO
GIES@gmail.com

13-04-2022

13-04-2022

570

FLIX BROADBAND SERVICES
PRIVATE LIMITED

DS-11/59/2022-DS-III

C

Contact No:
7908390483

Email Id:
psb.flixnet@gmail.com

20-04-2022

20-04-2022

571

KAROBA BROADBAND SERVICE
PRIVATE LIMITED

DS-11/521/2021-DS-III

C

Contact No:
8390623666

Email Id:
shubhammhatre361@gm
ail.com

20-04-2022

20-04-2022

572

FASTTECH NET PRIVATE
LIMITED

DS-11/13/2022-DS-III

C

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

20-04-2022

20-04-2022

NAME:Preethi
Viswambaran
Designation:Director

Bhatia Sant Niwas , Near Saha Sweets ,
Gurudwara Road Benachity Durgapur
West Bengal 713213 Purba Bardhaman
WEST BENGAL 713213
189, OWALI VILLAGE, POST ANJUR,
NAME:SHUBHAM
BHIWANDI, THANE,
MAHARASHTRA(KALYAN)
SANJAY MHATRE
MAHARASHTRA, INDIA 421302 Thane
Designation:DIRECTOR
MAHARASHTRA 421302
SHOP NO. 106, SWASTIK PLATINUM,
NAME:KESHAV
MALANG RD, OPP TO RELAX
RAMKRISHNA
MAHARASHTRA(KALYAN)
GARDEN, NANDIWALI GAON,
CHIKANKAR
KALYAN Thane MAHARASHTRA
Designation:DIRECTOR
421306
ORISSA(DHENKANAL)

NAME:Parminder Singh
Bhatia
Designation:Director

<!-- page 22 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

D.NO. 3/207 ANGAPPA NAGAR,
MORATTUPALAYAM, UTHUKULI,
Erode, Tamil Nadu, India Erode TAMIL
NADU 638752

Contact No:
9443316158

Email Id:
layanetwork@gmail.com

22-04-2022

22-04-2022

573

LAYA NETWORK PRIVATE
LIMITED

DS-11/29/2022-DS-III

B

TAMIL NADU

NAME:RAMASAMY
KRISHNAMOORTHY
Designation:DIRECTOR

574

MEERA IT SOLUTIONS PRIVATE
LIMITED

DS-11/233/2019-DS-III

C

WEST
BENGAL(DARJEELING
(SILIGURI))

NAME:LALAN
KUMAR MAHATO
Designation:DIRECTOR

C14, 3rd FLOOR , SHELCON
PLAZA,OPP-M BAZAR, CITY
MALL,SEVOKE ROAD, SILIGURI
Darjeeling WEST BENGAL 734001

Contact No:
9733303333

Email Id:
wnzone15@gmail.com

25-04-2022

25-04-2022

575

PALTECH INFO SERVICES
PRIVATE LIMITED

DS-11/531/2021-DS-III

C

UTTAR PRADESH
(WEST)(AGRA)

NAME:Atul Pal
Designation:Director

B 40 BALAJI PURAM SHAHGANJ Agra
UTTAR PRADESH 282010

Contact No:
8868008128

Email Id:
atulpal2013@gmail.com

26-04-2022

26-04-2022

MADHYA PRADESH

NAME:SUDHA
SHUKLA
Designation:DIRECTOR

Contact No:
9818408182

Email Id:
dsts@doorsancharstspl.c
om

26-04-2022

26-04-2022

BIHAR

NAME:SUDHA
SHUKLA
Designation:DIRECTOR

Contact No:
9818408182

Email Id:
dsts@doorsancharstspl.c
om

26-04-2022

26-04-2022

UTTAR PRADESH (EAST)

NAME:SUDHA
SHUKLA
Designation:DIRECTOR

Contact No:
9818408182

Email Id:
dsts@doorsancharstspl.c
om

26-04-2022

26-04-2022

UTTAR PRADESH (WEST)

NAME:SUDHA
SHUKLA
Designation:DIRECTOR

Contact No:
9818408182

Email Id:
dsts@doorsancharstspl.c
om

26-04-2022

26-04-2022

DELHI

NAME:SUDHA
SHUKLA
Designation:DIRECTOR

C 570 Temp, Block-C,,Defence Colony
South Delhi DELHI 110024

Contact No:
9818408182

Email Id:
dsts@doorsancharstspl.c
om

26-04-2022

26-04-2022

NAME:Krishna
Kothandaraman
Designation:Vice
President and CTO

Hughes Communications India Pvt. Ltd., 1,
Shivji Marg, Westend Greens, NH-8 South
West Delhi DELHI 110037

Contact No:
9899020758

Email Id:
k.krishna@hughes.in

27-04-2022

19-07-2018

576

577

578

579

580

DOORSANCHAR STS TELECOM
SERVICES PRIVATE LIMITED

DOORSANCHAR STS TELECOM
SERVICES PRIVATE LIMITED

DOORSANCHAR STS TELECOM
SERVICES PRIVATE LIMITED

DOORSANCHAR STS TELECOM
SERVICES PRIVATE LIMITED

DOORSANCHAR STS TELECOM
SERVICES PRIVATE LIMITED

DS-11/47/2022-DS-III

DS-11/47/2022-DS-III

DS-11/47/2022-DS-III

DS-11/47/2022-DS-III

DS-11/47/2022-DS-III

B

B

B

B

B

C 570 Temp, Block-C,,Defence Colony
South Delhi DELHI 110024

C 570 Temp, Block-C,,Defence Colony
South Delhi DELHI 110024

C 570 Temp, Block-C,,Defence Colony
South Delhi DELHI 110024

C 570 Temp, Block-C,,Defence Colony
South Delhi DELHI 110024

581

HUGHES COMMUNICATIONS
INDIA PVT. LTD.

DS-14/1/2017-DS-I

A

National Area

582

SHIVSHAKTI WIFI PRIVATE
LIMITED

DS-11/529/2021-DS-III

C

GUJARAT(SURENDRANAG
AR)

NAME:VANRAJSINH CHAMUNDA PARK BEHIND DR MER
PRATAPSINH JADEJA
HOSPITAL LIMBDI Surendranagar
Designation:DIRECTOR
GUJARAT 363421

Contact No:
9687277717

Email Id:
vjadeja084@gmail.com

27-04-2022

27-04-2022

583

GSDN COMMUNICATION
PRIVATE LIMITED

DS-11/433/2021-DS-III

C

UTTAR PRADESH
(WEST)(GHAZIABAD)

NAME:SUNIL KUMAR
1463, PANNAPURI, HAPUR Ghaziabad
SHARMA
UTTAR PRADESH 245101
Designation:DIRECTOR

Contact No:
9927239512

Email Id:
gsdn.cpl@gmail.com

28-04-2022

28-04-2022

584

JTM INTERNET PRIVATE
LIMITED

DS-11/435/2017-DS-III

A

National Area

NAME:KAUSHIK
613,EMPIRE STATE BUILDING, RING
CHAUHAN
ROAD SURAT Surat Surat GJ 395002 IN
Designation:DIRECTOR
Surat GUJARAT 395002

Contact No:
9099941272

Email Id:
kaushik@optimaltele.net

28-04-2022

04-04-2018

Contact No:
9999309222

Email Id:
himanshudhawan@utkris
hthalaw.com

29-04-2022

29-04-2022

585

EMT COMMUNICATIONS PVT.
LTD.

DS-11/32/2022-DS-III

B

MADHYA PRADESH

SF 01 SECOND FLOOR MINAL
NAME:Rajneesh Kumar SHOPPING MALL JK ROAD MINAL
Shukla
RESIDENCY, BHOPAL, MADHYA
Designation:Director
PRADESH Bhopal MADHYA PRADESH
462023

586

ACCESS INFOCOM PRIVATE
LIMITED

DS-11/414/2021-DS-III

A

National Area

NAME:RAHAMATHUL
NO. 86/10, ANNA STREET,
LAH SHAKEEL
CHITLAPAKKAM, CHENNAI, TAMIL
AHAMED
NADU, INDIA 600064 Kanchipuram
Designation:DIRECTOR
TAMIL NADU 600064

Contact No:
9962074005

Email Id:
shakeel@access-sas.com

02-05-2022

02-05-2022

587

DIGITALVOIP PRIVATE LIMITED

DS-11/298/2021-DS-III

A

National Area

NAME:HARSH
NARAYAN JHA
Designation:DIRECTOR

2094L TOWER 1ST AVENUE, GAUR
CITY1, SECTOR4 GREATER NOIDA
WEST Gautam Buddha Nagar(NOIDA)
UTTAR PRADESH 201301

Contact No:
9718114873

Email Id:
harsh@aphnetworks.in

05-05-2022

05-05-2022

588

VS BROADBAND SERVICES
PRIVATE LIMITED

DS-11/382/2021-DS-III

C

UTTAR PRADESH
(WEST)(AGRA)

NAME:VISHAL SINGH
Designation:DIRECTOR

11 I/55 SHOBHA NAGAR, FOUNDRY
NAGAR RAMBAGH Agra UTTAR
PRADESH 282006

Contact No:
7088999946

Email Id:
VISHAL3N@GMAIL.C
OM

09-05-2022

09-05-2022

Contact No:
9513062345

Email Id:
benvarpvtltd@gmail.com

09-05-2022

09-05-2022

Contact No:
8530625626

Email Id:
cispl.dot@cloudiinfra.com

11-05-2022

03-03-2020

Contact No:
8530625626

Email Id:
cispl.dot@cloudiinfra.com

11-05-2022

03-03-2020

MAHARASHTRA(PUNE)

NAME:MANGESH
GH. NO. 623 INAMDAR VASTI,
SURESH SHITOLE
KOREGAON MUL, TAL. HAVELI, Pune
Designation:DIRECTOR
MAHARASHTRA 412202

Contact No:
9764203636

Email Id:
timmimultimedia8644@
gmail.com

11-05-2022

11-05-2022

Contact No:
7021542525

Email Id:
vdijith@gmail.com

12-05-2022

12-05-2022

589

BENVAR PRIVATE LIMITED

DS-11/60/2022-DS-III

A

National Area

NAME:HARSHITHA M
V
Designation:DIRECTOR

590

CLOUDINSTA24 SERVICES
PRIVATE LIMITED

DS-11/125/2019-DS-III

C

ORISSA(BHUBANESWAR
(PURI))

NAME:Vipul Vikas
Deshpande
Designation:Director

591

CLOUDINSTA24 SERVICES
PRIVATE LIMITED

DS-11/125/2019-DS-III

C

MAHARASHTRA(NAGPUR)

NAME:Vipul Vikas
Deshpande
Designation:Director

592

TIMMI MULTIMEDIA PRIVATE
LIMITED

DS-11/128/2022-DS-III

C

DOOR NO.109,BTM 4TH
STAGE,SECOND BLOCK,80 FEET
ROAD,BILEKAHALLI
P.O,BANGALORE Bangalore Urban
KARNATAKA 560076
Vidya Deshpande, Om Avishkar
Society,S.No. 123 Near MIT College ,
Paud Road,Kothrud Pune Pune
MAHARASHTRA 411038
Vidya Deshpande, Om Avishkar
Society,S.No. 123 Near MIT College ,
Paud Road,Kothrud Pune Pune
MAHARASHTRA 411038

593

STARBIX INFOCOM PRIVATE
LIMITED

DS-11/367/2021-DS-III

B

MUMBAI

SAI SANCHAR 1599/005 ROOM NO101 KOPARI, GAON SECTOR 26A
NAME:DIJITH
NEAR SAIBABA MANDIR VASHI,
SASHIDHARAN
THANE MUMBAI CITY
Designation:DIRECTOR
MAHARASHTRA INDIA- 400703 Thane
MAHARASHTRA 400703

594

GENIUS NETWORK PRIVATE
LIMITED

DS-11/477/2021-DS-III

B

MUMBAI

NAME:ABHIJEET
PLOT NO 83,SHOP NO 19, SECTOR 1 ,
DNYANESHWAR
KOPARKHAIRNE NAVI MUMBAI
BALSARAF
CITY MAHARASHTRA INDIA- 400709
Designation:DIRCETOR
Thane MAHARASHTRA 400709

Contact No:
9819377070

Email Id:
abhijeetbalsaraf46@gma
il.com

12-05-2022

12-05-2022

595

RDN BROADBAND SERVICE
PRIVATE LIMITED

DS-11/499/2021-DS-III

B

MUMBAI

NAME:DEEPAK
DINESH KUMAR
Designation:DIRECTOR

ROOM NO 01 VITTHAL NAGAR
NORTH AVENUE RD NR RESERVE
STAFF QURATERS SANTACRUZ
WEST MUMBAI Mumbai City Mumbai
City MAHARASHTRA 400054

Contact No:
7385252533

Email Id:
prasad007.ravi@gmail.c
om

12-05-2022

12-05-2022

596

K R BROADBAND SERVICES
PRIVATE LIMITED

DS-11/543/2021-DS-III

B

MAHARASHTRA

NAME:RAMESH
PRALHAD PAWAR
Designation:Director

R. NO. 3 PEDNEKAR CHAWL RAM
MANDIR ROAD, VERSOVA ANDHERI
WEST MUMBAI Mumbai City Mumbai
City MAHARASHTRA 400061

Contact No:
9967360635

Email Id:
ANDHERICA@GMAIL
.COM

12-05-2022

12-05-2022

597

IGEN NETWORKS PRIVATE
LIMITED

DS-11/476/2021-DS-III

B

UTTAR PRADESH (WEST)

NAME:Avdhesh Goyal
Designation:Director

Tilak Complex, 27 Tilak Road Dehradun
UTTARAKHAND 248001

Contact No:
9897918864

20-05-2022

20-05-2022

598

FALCONET INTERNET PVT LTD

DS-11/137/2021-DS-III

B

HIMACHAL PRADESH

NAME:Aman Kamboj
Designation:Director

1241 Sector 9 Ambala HARYANA
134003

Contact No:
9896796084

24-05-2022

13-07-2021

MUMBAI

NAME:BABUL
AHMED SHAIKH
Designation:DIRECTOR

PLOT NO. 26/T/9, ROAD NO. 12,
BAIGANWADI, GOVANDI, Mumbai
City MAHARASHTRA 400043

Contact No:
9699037111

Email Id:
babul2423@gmail.com

26-05-2022

26-05-2022

NAME:Fenil Kanti Gada
Designation:Director

A/01 Juhu Sanskar Premises CHS Ltd..
Juhu Church Road, Vile Parle West
Mumbai City MAHARASHTRA 400049

Contact No:
9820194753

Email Id:
vijayshahindia@gmail.co
m

26-05-2022

26-05-2022

599

600

BABUL NETWORK PRIVATE
LIMITED

DIRECT NET7 PRIVATE LIMITED

DS-11/501/2021-DS-III

DS-11/522/2021-DS-III

B

B

MAHARASHTRA

Email Id:
info@igennetworks.in
Email Id:
kamboj.aman@gmail.co
m

<!-- page 23 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

Contact No:
9820444129

Email Id:
ANDHERICA@GMAIL
.COM

27-05-2022

27-05-2022

601

SPEEDNET DIGITAL FTH (OPC)
PRIVATE LIMITED

DS-11/92/2022-DS-III

B

MAHARASHTRA

NAME:DEEPAK
1104, SAPTARISHI BUILDING NO 7,
NARAYANDAS
BEHIND INDIAN OIL NAGAR, CD
BADLANI
BARFIWALA ANDHERI WEST Mumbai
Designation:DIRECTOR
City MAHARASHTRA 400053

602

NETKLIKS COMMUNICATIONS
PRIVATE LIMITED

DS-11/130/2022-DS-III

B

ANDHRA PRADESH

NAME:Gorti Srinivasu
Designation:Director

Flat No 402, SS Towers, Ganesh Nagar
Morampudi, Rajahmundry East Godavari
ANDHRA PRADESH 533107

Contact No:
9885577768

Email Id:
gortisrinivas@gmail.com

27-05-2022

27-05-2022

603

RAJE PRACHAAR INTERNET
SERVICES PRIVATE LIMITED

DS-11/125/2022-DS-III

B

TAMIL NADU

NAME:SUNDARAM
SUJITHRA
Designation:DIRECTOR

NO 477,TNHB,KAKKALUR Tiruvallur
TAMIL NADU 602001

Contact No:
9384109969

Email Id:
ethiraj.rajendiran@prach
aar.net

30-05-2022

30-05-2022

604

SPARK TELECOMMUNICATION
PRIVATE LIMITED

DS-11/71/2022-DS-III

B

MUMBAI

NAME:SUNNYSAGAR
RAMJILAL
CHINDALIA
Designation:DIRECTOR

PLOT NO. PAP R-194 4-195 R-196 R197, RABALE MIDC, RABALE, NAVI
MUMBAI Thane MAHARASHTRA
400708

Contact No:
9819996607

Email Id:
SPARKTELECOMMU
NICATIONSERVICES
@GMAIL.COM

30-05-2022

30-05-2022

605

SPACE INTERNET PRIVATE
LIMITED

DS-11/28/2022-DS-III

B

MAHARASHTRA

2ND FLR KALYANGRAM CHSL B
NAME:YOGESH VELJI
ANDHERI WEST NR MERCHANTILE
SHAH
BANK V P ROAD MUMBAI Mumbai
Designation:DIRECTOR
City MAHARASHTRA 400058

Contact No:
9324208090

Email Id:
ANDHERICA@GMAIL
.COM

31-05-2022

31-05-2022

606

AYMAN INTERNET PRIVATE
LIMITED

DS-11/539/2021-DS-III

C

WEST BENGAL(SURI)

NAME:FARIDUDDIN
SEIKH
Designation:DIRECTOR

STALL-6, BLOCK-B, BOLPUR SUPER
MARKET, BOLPUR Birbhum WEST
BENGAL 731204

Contact No:
9609501922

Email Id:
aimaninternetbol@gmail.
com

31-05-2022

31-05-2022

607

GULZAR COMMUNICATION
PRIVATE LIMITED

DS-11/121/2022-DS-III

B

KOLKATA

NAME:SAJID
70, RABINDRA SARANI Kolkata WEST
JAHANGIR
BENGAL 700073
Designation:DIRECTOR

Contact No:
9831528636

Email Id:
gulzarcommunication20
12@gmail.com

31-05-2022

31-05-2022

608

B-TEL INTERNET PRIVATE
LIMITED

DS-11/126/2022-DS-III

B

KOLKATA

NAME:JIKRIYA
C/O JIKRIYA MALLICK, BARGACHIA,
MALLICK
SAKAL BAZAR Howrah WEST
Designation:DIRECTOR
BENGAL 711404

Contact No:
9830865222

Email Id: info@btel.co.in

02-06-2022

02-06-2021

WEST BENGAL

NAME:JIKRIYA
C/O JIKRIYA MALLICK, BARGACHIA,
MALLICK
SAKAL BAZAR Howrah WEST
Designation:DIRECTOR
BENGAL 711404

Contact No:
9830865222

Email Id: info@btel.co.in

02-06-2022

02-06-2021

Contact No:
9820194753

Email Id:
skytrackbroadband@gm
ail.com

03-06-2022

03-06-2022

609

B-TEL INTERNET PRIVATE
LIMITED

DS-11/126/2022-DS-III

B

610

SKYTRACK BROADBAND
PRIVATE LIMITED

DS-11/108/2020-DS-III

B

MUMBAI

R NO. 2, NAIR CHAWL, KAJU WADI, 2
NAME:NARESH
PARSI WADA, PARSI WADA, SAHAR
BABUBHAI PATEL
ROAD, ANDHERI EAST Mumbai City
Designation:DIRECTOR
MAHARASHTRA 400099

611

PRINCE NET SERVICES PRIVATE
LIMITED

DS-11/253/2021-DS-III

B

MUMBAI

NAME:NIRAJ
GARDEN VIEW CHS LTD,SHOP
SATISHCHANDRA
NO.2,C.S.ROAD,DAHISAR EAST
GUPTA
Mumbai City MAHARASHTRA 400068
Designation:DIRECTOR

Contact No:
7666264444

Email Id:
nsg034@gmail.com

03-06-2022

03-06-2022

612

JAGDAMBA BROADBAND (OPC)
PRIVATE LIMITED

DS-11/100/2022-DS-III

C

MAHARASHTRA(PEN)

NAME:RAJDATTA
MARUTI PATIL
Designation:DIRECTOR

HOUSE NO 208, VANASPATIWADI,
AT POST-WASHI TALUKA PEN
WASHI RAIGARH MAHARASHTRA
INDIA Raigad MAHARASHTRA 402107

Contact No:
9850906123

Email Id:
jagdambabroadband.opc
@gmail.com

07-06-2022

07-06-2022

613

SHYAM SPECTRA PRIVATE
LIMITED

20-1052/2019 AS-I

A

National Area

NAME:VINEET
NAYYAR
Designation:GENERAL
MANAGER
REGULATORY

A-60, NARAINA INDUSTRIAL AREA,
PHASE-I South West Delhi DELHI
110028

Contact No:
9818122310

Email Id:
regulatory@spectra.co

08-06-2022

30-06-2019

614

FRONTLINE INTERNET
SERVICES PRIVATE LIMITED

DS-11/554/2021-DS-III Dated
29/03/2022

C

ASSAM(TEZPUR)

NAME:AYEJAR
RAHMAN
Designation:DIRECTOR

C/O PROBODH
DEKA,KACHARIGAON, TEZPUR
Sonitpur ASSAM 784001

Contact No:
9577159508

Email Id:
info@frontlineinternetser
vices.com

10-06-2022

10-06-2022

615

SURABHI DIGITAL SOLUTIONS
PRIVATE LIMITED

DS-11/381/2021-DS-III

B

MAHARASHTRA

NAME:VISHAKHA
AMEY
SAHASRABUDHE
Designation:DIRECTOR

29, FLOOR-2, PLOT-205, PARESH
CHAMBER, LT DILIP GUPTE MARG,
SHIVAJI PARK, MAHIM Mumbai City
MAHARASHTRA 400016

Contact No:
7710036948

Email Id:
info@surabhinetworks.c
o.in

14-06-2022

14-06-2022

616

BALAJI INFO NETWORK
SOLUTIONS PRIVATE LIMITED

DS-11/393/2021-DS-III

B

MUMBAI

NAME:RAJKUMAR
MUTHIAH
Designation:DIRECTOR

FLAT NO 1-A, VASANT VIHAR, NR
LALLUBHAI, PARK, ADJ RAILWAY
LINE, ANDHERI WEST, MUMBAI
MAHARASHTRA INDIA-400058
Mumbai City MAHARASHTRA 400058

Contact No:
9987232385

Email Id:
rajkumarmuthiah@hotm
ail.com

14-06-2022

14-06-2022

617

SAIDEEP BROADBAND PRIVATE
LIMITED

DS-11/482/2021-DS-III

C

MAHARASHTRA(KALYAN)

NAME:URMILA
DINESH PAWSHE
Designation:DIRECTOR

Contact No:
9768162556

Email Id:
dineshpawshe7@gmail.c
om

15-06-2022

15-06-2022

618

HDN COMMUNICATIONS
PRIVATE LIMITED

DS-11/387/2021-DS-III

B

MAHARASHTRA

Contact No:
8655738003

Email Id:
ANDHERICA@GMAIL
.COM

16-06-2022

16-06-2022

619

ULTRANET BROADBAND
PRIVATE LIMITED

DS-11/491/2021-DS-III

C

MAHARASHTRA(KALYAN)

Contact No:
8898272121

Email Id:
ultranetbroadband5455
@gmail.com

16-06-2022

16-06-2022

620

FLASH INFOTAINMENT
PRIVATE LIMITED

DS-11/512/2021-DS-III

B

MUMBAI

Contact No:
8207867866

Email Id:
flashnetinfo21@gmail.co
m

16-06-2022

16-06-2022

621

NETSPEEDIO NETWORK AND
TECHNOLOGIES PRIVATE
LIMITED

DS-11/61/2022-DS-III

B

MUMBAI

Contact No:
8108838951

Email Id:
arargond123@gmail.co
m

16-06-2022

16-06-2022

622

SAINET GIGAFIBER SERVICES
PRIVATE LIMITED

DS-11/55/2022-DS-III

B

MUMBAI

NAME:PRAVIN
ANANT KUVESKAR
Designation:DIRECTOR

OFFICE-2, PLOT-190, JIVAJI
MANSION, DR. BABASAHEB
AMBEDKAR ROAD, DADAR EAST
Mumbai City MAHARASHTRA 400014

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

17-06-2022

17-06-2022

623

CIRROLOGIX TECHNOLOGIES
PRIVATE LIMITED

DS-11/153/2022-DS-III

A

National Area

NAME:M VASAN
Designation:MANAGER
FINANCE

J S TOWERS, L-32, 2ND A MAIN,
OUTER RING ROAD, AGARA H S R
LAYOUT, 6TH SECTOR Bangalore
Urban KARNATAKA 560102

Contact No:
7090018500

Email Id:
vasan.m@ipmomentum.i
n

21-06-2022

21-06-2022

624

RAPIDE NEXT PRIVATE LIMITED

11/286/2021-DS-III

B

UTTAR PRADESH (EAST)

Contact No:
8932094101

Email Id:
rapidenext@gmail.com

22-06-2022

22-06-2022

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

22-06-2022

22-06-2022

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

22-06-2022

05-08-2021

625

YUG INTERNET AND CABLE
PRIVATE LIMITED

DS-11/57/2022-DS-III

B

MUMBAI

626

BILAL INTERNET SERVICES
PRIVATE LIMITED

DS-11/38/2021-DS-III

B

MAHARASHTRA

1/1, PAWASHE CHAWL, HARI BHAU
PADA, KATEMANIVALI,
KOLSHEWADI, KALYAN, EAST
KALYAN, THANE, MAHARASHTRA,
INDIA 421306 Thane MAHARASHTRA
421306
2,3 B, BP Patil Chawl, Shri Krishna Ngr
NAME:NIKHIL
Nr Sachin Health Center, Kajupada,
RAJESH DALAL
Mumbai Mumbai City MAHARASHTRA
Designation:DIRECTOR
400066
NAME:ROSHAN
LALCHAND PAWSHE
Designation:DIRECTOR

Hari-Bhau Pada, R no. 1 , Katemanivali,
Kate, Kalyan East Thane Thane MH
421306 IN Thane MAHARASHTRA
421306

7, FLOOR-GRD, PLOT-60/62,
NAME:ALTAMASH
KAZURIWALA BUILDING,
MOHD KHURSHID
KAMBEKAR STREET, MINARA
KHAN
MASJID Mumbai City MAHARASHTRA
Designation:DIRECTOR
400003
403 PLOT NO SRA SCHEME,
NAME:Arun Hanslal
DEEWAN BLDG NO 2 CHEMBUR
Gond
Mumbai Mumbai City Mumbai City
Designation:Director
MAHARASHTRA 400074

HNO. 59, Mughalchak, Alinagar,
Mughalsarai Chandauli UTTAR
PRADESH 232101
S/O TULSIDAS MEGHRAJ TELI, KOLI
NAME:PRAMOD
WADA, EKSAR ROAD, BORIVALI
TULSIDAS TELE
WEST Mumbai City MAHARASHTRA
Designation:DIRECTOR
400092
NAME:Viplav Bhartiya
Designation:Director

NAME:KHAN
3, IBRAHIM CHUNAWALA PLOT, OPP
MOHAMMED ATAUL BEST DEPOT, L. B. S. MARG, KURLA
MUSTAFA
WEST Mumbai City MAHARASHTRA
Designation:DIRECTOR
400070

<!-- page 24 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address
MG 353 2/2, Shastri Nagar,, S G Barve
Road, Chembur, Mumbai City,
Maharashtra, India, Mumbai City
MAHARASHTRA 400071
1,GR FLOOR,PLOT 19,SHANTI
NIKETAN,LADY JAMSHEDJI
ROAD,MAHIM
CHURCH,MUMBAI,MUMBAI
CITY,MAHARASHTRA Mumbai City
MAHARASHTRA 400016

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

Contact No:
9920952727

Email Id:
mynetbroadband27@gm
ail.com

23-06-2022

23-06-2022

Contact No:
9699633023

Email Id:
shankar@jprdigital.in

23-06-2022

23-06-2022

627

MYNET BROADBAND SERVICES
PRIVATE LIMITED

DS-11/82/2022-DS-III

B

MUMBAI

NAME:KRISHNA
SITARAM
VISHWAKARMA
Designation:DIRCTOR

628

NEHA NETCOM PRIVATE
LIMITED

DS-11/95/2022-DS-III

B

MUMBAI

NAME:MR NISAR
AHMED KAZI
Designation:DIRECTOR

629

CVITEL NETWORK PRIVATE
LIMITED

DS-11/143/2022-DS-III

C

UTTAR PRADESH
(WEST)(GHAZIABAD)

NAME:ROHAN
RAWLLEY
Designation:DIRECTOR

8/374, SEC-3, RAJENDER NAGAR,
SAHIBABAD, Ghaziabad UTTAR
PRADESH 201005

Contact No:
9958027111

Email Id:
rohan.rawlley3636@gm
ail.com

23-06-2022

23-06-2022

630

AON NET PRIVATE LIMITED

DS-11/30/2022-DS-III

B

MUMBAI

NAME:SHAHID
HASAN TAMBE
Designation:DIRECTOR

109/10-A, CHAWL-109,
KURMURAWALA CHAWL, MATCH
FACTORY LANE, KURLA WEST
Mumbai City MAHARASHTRA 400070

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

24-06-2022

24-06-2022

631

BAKLIWAL TELECOM SERVICES
PRIVATE LIMITED

DS-11/472/2018-DS-III

B

RAJASTHAN

NAME:ANKIT
BAKLIWAL
Designation:DIRECTOR

67/38, SECTOR 67, PRATAP NAGAR,
SANGANER, JAIPUR, Jaipur,
RAJASTHAN, 302033

Contact No:
9116141400

Email Id:
bakliwaltelecom@gmail.
com

27-06-2022

09-05-2019

632

SIMPICA BROADNET PRIVATE
LIMITED

DS-11/171/2022-DS-III

B

MUMBAI

NAME:CHETAN
SHEKHAR PUJARI
Designation:DIRECTOR

ROOM NO. 11, MOHILI VILLAGE
KURLA, NEAR AISHA SADAN,
SAKINAKA Mumbai City
MAHARASHTRA 400072

Contact No:
8779303565

Email Id:
nikhil_enterprises1966@
yahoo.co.in

28-06-2022

28-06-2022

633

Velocity Broadband Pvt. Ltd.

DS-11/427/2021-DS-III

B

WEST BENGAL

NAME:Mithun Nath
Designation:CTO

Gosani Road, Ward No 8, Dinhata, Cooch
Behar, West Bengal,736135

Contact No:
8649817483

Email Id:
velocity.broadband21@g
mail.com

28-06-2022

28-06-2022

634

RP BROADBAND AND CABLE
NETWORK PRIVATE LIMITED

DS-11/509/2021-DS-III

B

MUMBAI

NAME:RAJENDRAKU 49A, Ground Floor, Plot 245/46A, Bhosale
MAR HUKUMCHAND
Marg, Worli Naka Junction, Mumbai,
ZINJOTER
Mumbai City, Maharashtra-400018
Designation:DIRECTOR Mumbai City MAHARASHTRA 400018

Contact No:
7428571121

Email Id:
rpbcnpl@gmail.com

29-06-2022

29-06-2022

635

NETVIGATOR BROADBAND
PRIVATE LIMITED

DS-11/8/2022-DS-III

B

MUMBAI

NAME:RUPESH
MURGAYA TEWAR
Designation:DIRECTOR

M S 6 214 CHEMBUR CAMP,
CHEMBUR , MUMBAI , Mumbai City
Maharashtra India-400071 Mumbai City
MAHARASHTRA 400071

Contact No:
9773346066

Email Id:
rupeshtewar@gmail.com

29-06-2022

29-06-2022

636

RACHIT BROADBAND PRIVATE
LIMITED

DS-11/94/2022-DS-III

B

UTTAR PRADESH (WEST)

NAME:Prateek Agarwal
Designation:Director

Contact No:
8859232323

Email Id:
proprietor@rachitbroadb
and.co.in

30-06-2022

30-06-2022

637

TECHNOMEX INFOCOM
SYSTEMS PVT LTD

DS-11/456/2018-DS-III

B

MAHARASHTRA

NAME:Rajdeep
Shashikant Pise
Designation:Director

Contact No:
9619338884

Email Id:
rajdeep@technomex.in

07-07-2022

16-05-2019

638

SAMMY VISION PRIVATE
LIMITED

DS-11/54/2022-DS-III

B

MUMBAI

NAME:MAYUR
MOHAN PATIL
Designation:Director

27 FLOOR-GRD, SANT JANABAI
MARKET 1ST X ROAD, GHODPADEO,
KALACHOWKY MUMBAI Mumbai City
Mumbai City MAHARASHTRA 400033

Contact No:
8149842231

Email Id:
siddhpatil6@gmail.com

07-07-2022

07-07-2022

639

SPACELINK INTERNET (OPC)
PRIVATE LIMITED

DS-11/144/2022-DS-III

B

MUMBAI

NAME:ANJANA VIPUL
SHAH
Designation:DIRECTOR

R-24, F-3RD, HARAWALA BUILDING,
LOHAR CHAWL, KANTILAL
SHARMA MARG, KALBADEVI,
Mumbai City MAHARASHTRA 400002

Contact No:
9820194753

Email Id:
vijayshahindia@gmail.co
m

08-07-2022

08-07-2022

640

NETFIX NETWORKS (OPC)
PRIVATE LIMITED

DS-11/170/2022-DS-III

B

MUMBAI

NAME:ABHISHEK
kUMAR PANDEY
Designation:DIRECTOR

Contact No:
9769540385

Email Id:
info@netfixnetworks.in

11-07-2022

11-07-2022

641

TANVI BROADBAND PRIVATE
LIMITED

DS-11/551/2021-DS-III

C

NAME:SIDDHANT
MAHARASHTRA(KALYAN) SHANTARAM KADAV
Designation:DIRECTOR

Contact No:
9665699639

Email Id:
kadav.siddhanth0@gmai
l.com

12-07-2022

12-07-2022

642

VIDHI NETSOL PRIVATE
LIMITED

DS-11/69/2022-DS-III

C

GUJARAT(AHMEDABAD)

NAME:TUSHAR
JAYANTILAL JOSHI
Designation:DIRECTOR

31-MILAN COMPLEX, NEAR SUKH
SAGAR SARKHEJ, AHMEDABAD
Ahmedabad GUJARAT 382210

Contact No:
9376819378

Email Id:
tjoshi234@gmail.com

19-07-2022

19-07-2022

C

TAMILNADU(TRICHY)

NAME:T.Karthikeyan,
Designation: Director

1/846, Raghavendra
Nagar,MIET,Trichy,Tamilnadu-620007

Contact No.
9894467467

Email Id:
race0866@gmail.com

20-07-2022

20-07-2022

RA 423, DURGA ABASAN,
NABAPALLY, SECTOR - IV,
SALTLAKE, KOLKATA, NEAR VIP
SWEETS

Contact No:
9501501847

Email Id:
sahajnetbpl@gmail.com

25-07-2022

25-07-2022

9721777799

vaibhavsinghrajawat@g
mail.com

26-07-2022

26-07-2022

643

Swibi Airnet Broadband Services Pvt
Ltd

H.No. 232,MOH. GUSSIAN ,
JAHANGIRABAD Bulandshahr UTTAR
PRADESH 203394
8TH FLOOR-1 PLOT NO.16 PREM
BHUVAN, DL VAIDYA ROAD DADAR
WEST MUMBAI Mumbai City
MAHARASHTRA 400028

D-19, FLOOR-GRD, D WING,
MAHALAXMI SRA, CHSL,
PANDURANG BUDHKAR MARG,
WORLI, MUMBAI, Mumbai City,
Maharashtra Mumbai City
MAHARASHTRA 400030
GROUND FLOOR SHOP NO 31, H
WING SAI GLORY SHAHAPUR,
VASHIND CT THANE,
MAHARASHTRA 421601 Thane
MAHARASHTRA 421601

DS-11/214/2022-DS-III

644

SAHAJNET BROADBAND
PRIVATE LIMITED

DS-11/238/2022-DS-III

B

KOLKATA

NAME: PRASHANTA
PATRA
Designation: Director

645

JKM Digital Services (OPC) Pvt Ltd

DS-11/523/2021-DS-III

C

ORAI SSA IN UP(East) LSA

Vaibhav Singh Rajawat

646

KHAIZEN TECHNOLOGIES
PRIVATE LIMITED

DS-11/244/2022-DS-III Dated
28/06/2022

C

ASSAM(GUWAHATI)

House No 13B, Bye Lane No-1, Manik
NAME:Sasanka Bordoloi
Nagar, Guwahati, Kamrup, Assam-781005
Designation:Director
Kamrup ASSAM 781005

Contact No:
7428571121

Email Id:
ispktpl@gmail.com

01-08-2022

01-08-2022

647

FIBRETEL INTERNET SERVICES
OPC PRIVATE LIMITED

DS-11/226/2022-DS-III Dated
10/06/2022

C

ASSAM(TINSUKHIA
(DIBRUGARH))

C/O MEENA DEVI VERMA,
NAME:SANDEEP
MILONPUR, M.R. ROAD, NALIAPOOL,
KUMAR VERMA
DIBRUGARH, ASSAM, INDIA 786001
Designation:DIRECTOR
Dibrugarh ASSAM 786001

Contact No:
7002782084

Email Id:
fibreteldib@gmail.com

02-08-2022

02-08-2022

648

SARASWATI INTERNET
SOLUTION PRIVATE LIMITED

DS-11/302/2021-DS-III

B

GUJARAT

NAME:ARVINDKUMA
R CHELABHAI
CHAUDHARY
Designation:DIRECTOR

7, ANMOL COMPLEX, ANMOL
SHOPPING CENTRE BUS STAND
ROAD, AT THARAD, THARAD,
BANAS KANTHA, GUJARAT- 385565
Banaskantha GUJARAT 385565

Contact No:
7428571121

Email Id:
saraswatiinternetsolution
@gmail.com

03-08-2022

03-08-2022

649

JCN INTERNET PRIVATE
LIMITED

DS-11/553/2021-DS-III

C

GUJARAT(VALSAD)

NAME:HARDIK
AVINASH RANA
Designation:DIRECTOR

PLOT NO. J 2 GIDC, UMBERGAM
GIDC, Valsad GUJARAT 396171

Contact No:
8141225553

Email Id:
hardik@jcnonline.in

03-08-2022

03-08-2022

ASSAM(SILCHAR)

NAME:REJAUL
KARIM LASKAR
Designation:DIRECTOR

Dhanehari PART-1 Po-Dhanehari DistCachar Cachar ASSAM 788013

Contact No:
7636969682

Email Id:
rklaskar79@gmail.com

04-08-2022

04-08-2022

650

ENTOUCH CORPORATE OPC PVT
LTD

DS-11/118/2022-DS-III Dated
22/03/2022

C

Shop no. 70 Club Market Patel Nagar,
Orai Jalaun UP-285001

651

CTRL S NLD SERVICES PRIVATE
LIMITED

DS-11/119/2022-DS-III

A

National Area

NAME:RAJANI
REDDY
PINNAPUREDDY
Designation:DIRECTOR

7th Floor, Pioneer Towers, Plot No. 16,
Software Layout Unit, Madhapur
Hyderabad TELANGANA 500081

Contact No:
7995086476

Email Id:
gopal.j@cloud4c.com

08-08-2022

08-08-2022

652

SUNRISE INTERNET PRIVATE
LIMITED

DS-11/243/2022-DS-III

B

HARYANA

NAME:SATISH SINGH
GALI NO 6 GULATI ROAD SAMLKHA
KUHAAR
Panipat HARYANA 132101
Designation:DIRECTOR

Contact No:
9812761000

Email Id:
SATISHKUHAAR2003
@GMAIL.COM

08-08-2022

08-08-2022

653

MOTHER MARY NETWORK
PRIVATE LIMITED

DS-11/120/2022-DS-III

B

MUMBAI

NAME:Paul Abirajan
Shetty
Designation:DIRECTOR

RM NO 3 JAIRAM KENI CHAWL NO 1
EKTA NAGAR MALAD WEST
BEHIND K G MITTAL COLLEGE
MUMBAI 400064 Mumbai City
MAHARASHTRA 400064

Contact No:
9167165037

Email Id:
mothermarynetwork@g
mail.com

10-08-2022

10-08-2022

<!-- page 25 -->

List of ISP Authorizations under UL-VNO as on 30.09.2022
S. No.

Name of Licensee

License No.

Category

Service Area

Authorized Person

Registered Office Address

Contact No.
Mobile

Mail ID

Date of Signing UL

Effective Date

1ST FLOOR, ARUN WEAR WAIDYA
ESTATE, OPP BLDG NO. 2, SAHYOG
NAGAR, KURLA WEST Mumbai City
MAHARASHTRA 400070

Contact No:
9167485212

Email Id:
kalamkarsahil@gmail.co
m

11-08-2022

11-08-2022

654

MASSNET SERVICES PRIVATE
LIMITED

DS-11/185/2022-DS-III

B

MAHARASHTRA

NAME:SAHIL SUNIL
KALAMKAR
Designation:DIRECTOR

655

MASSNET SERVICES PRIVATE
LIMITED

DS-11/185/2022-DS-III

B

MUMBAI

NAME:SAHIL SUNIL
KALAMKAR
Designation:DIRECTOR

1ST FLOOR, ARUN WEAR WAIDYA
ESTATE, OPP BLDG NO. 2, SAHYOG
NAGAR, KURLA WEST Mumbai City
MAHARASHTRA 400070

Contact No:
9167485212

Email Id:
kalamkarsahil@gmail.co
m

11-08-2022

11-08-2022

656

SHANTADEVI NETWORKS
PRIVATE LIMITED

DS-11/240/2022-DS-III

B

MUMBAI

NAME:KIRAN
KASHINATH SHINDE
Designation:DIRECTOR

SHOP NO 4, PLOT NO 121-122,
SECTOR 9, ULWE, NAVI MUMBAI,
PANVEL, THANE Raigad
MAHARASHTRA 410206

Contact No:
8850365139

Email Id:
kamleshshinde0@gmail.
com

11-08-2022

11-08-2022

Contact No:
9890352242

Email Id:
mitsolution1@gmail.com

17-08-2022

17-08-2022

Contact No:
9870030030

Email Id:
speedcominternetservices
@gmail.com

25-08-2022

25-08-2022

Contact No:
9900881079

Email Id:
karnetisp@gmail.com

25-08-2022

25-08-2022

657

MIT ONLINE (OPC) PRIVATE
LIMITED

DS-11/426/2021-DS-III

C

MAHARASHTRA(KALYAN)

NAME:Mahendra
Chaugule
Designation:Director
NAME:Deveshanand
Digambar Shirodkar
Designation:managing
director

07 GALA-4 1ST FLOOR,PADGHA
VILLAG Thane MAHARASHTRA
421302
SHOP NO 9, DATTA MANDIR
COMPOUND, YOGI NAGAR,
BORIVALI WEST. Mumbai City
MAHARASHTRA 400091
NO 2 TM RAMU ARCADE
PUTTASWAMAIAHNA, PALYA
SIRAGATE SATHYAMANGALA
ROAD, TUMAKURU Tumkur
KARNATAKA 572106

658

SPEEDCOM INTERNET
SERVICES PRIVATE LTD

DS-11/194/2022-DS-III

B

MUMBAI

659

KARNET SOLUTIONS (OPC)
PRIVATE LIMITED

DS-11/187/2022-DS-III

C

KARNATAKA(TUMKUR)

NAME:SANTHOSH
KUMAR H N
Designation:DIRECTOR

660

HYPERTECH BROADBAND
PRIVATE LIMITED

DS-11/173/2022-DS-III

B

MUMBAI

NAME:ANIKET
SADANAND KADAM
Designation:DIRECTOR

A-103,GOKUL NAGARI II A and B CHS
LTD,NR DATTANI PARK,WE
HIGHWAY,KANDIVALI
E,MUMBAI,BANDRA SUBURBAN
Mumbai City MAHARASHTRA 400101

Contact No:
9699633023

Email Id:
shrau1106@gmail.com

26-08-2022

26-08-2022

661

ALLIANT NETWORK
SOLUTIONS PRIVATE LIMITED

DS-11/137/2022-DS-III

A

National Area

NAME:Rakesh Ranjan
Designation:Director

A-4/403, SOMA HEIGHTS TREVNI
CHS LTD VASAI EAST GOKHIWARE
Thane MAHARASHTRA 401208

Contact No:
9168618612

Email Id:
rakesh.r@alliant.co.in

01-09-2022

01-09-2022

662

ULTRAVISION INFOSERVE PVT
LTD

DS-11/281/2022-DS-III

C

MAHARASHTRA(RATNAGI
RI)

NAME:RANJIT
RAVINDRA KADAM
Designation:DIRECTOR

H.NO. 1024 A/P KOSUMB, TALSANGAMESHWAR, RATNAGIRI
Ratnagiri MAHARASHTRA 415804

Contact No:
9004080434

Email Id:
ranjitamu@gmail.com

01-09-2022

01-09-2022

Contact No:
9867242727

Email Id:
abhijitrkadam@gmail.co
m

07-09-2022

07-09-2022

663

NETWAY INFOTECH PVT LTD

DS-11/188/2022-DS-III

B

MUMBAI

NAME:ABHIJIT
RAVINDRA KADAM
Designation:DIRECTOR

GROUND FLOOR SHIVSAI
APARTMENT KISAN NAGAR NO.3
WAGLE ESTATE Thane
MAHARASHTRA 400604

664

DFAB INTERNET SERVICES
PRIVATE LIMITED

DS-11/444/2021-DS-III

C

MAHARASHTRA(KALYAN)

NAME:Bhushan
Gurunath Mhatre
Designation:DIRECTOR

A-Wing, Shop No. 01 Shree Asthvinayak
Sankul, Thane Thane MAHARASHTRA
421301

Contact No:
8424011214

Email Id:
bhshnmhatre63@gmail.c
om

12-09-2022

12-09-2022

665

SAI MUSKAAN NET SOLUTION
PRIVATE LIMITED

DS-11/552/2021-DS-III

B

MUMBAI

NAME:SACHIN
NARAYAN GAVATE
Designation:DIRECTOR

FLAT NO. 602, NARAYAN PARK,
SURYANAGAR, VITAWA, KALWA,
Thane MAHARASHTRA 400605

Contact No:
9221525696

Email Id:
saimuskannetsolution@g
mail.com

12-09-2022

12-09-2022

666

SAI MUSKAAN NET SOLUTION
PRIVATE LIMITED

DS-11/552/2021-DS-III

C

MAHARASHTRA(PEN)

NAME:SACHIN
NARAYAN GAVATE
Designation:DIRECTOR

FLAT NO. 602, NARAYAN PARK,
SURYANAGAR, VITAWA, KALWA,
Thane MAHARASHTRA 400605

Contact No:
9221525696

Email Id:
saimuskannetsolution@g
mail.com

12-09-2022

12-09-2022

Contact No:
8951679407

Email Id:
Info@connect4sure.com

19-09-2022

19-09-2022

667

CONNECT4SURE
TECHNOLOGIES PRIVATE
LIMITED

DS-11/255/2022-DS-III

A

National Area

NAME:JACOB JOSEPH
MANAMEL
Designation:Director

KUMARA KRUPA NO. 16/17 1ST
CROSS GR HOME 1ST MAIN
MEENAKSHI LAYOUT,
RAYASANDRA Bangalore Urban
KARNATAKA 560099

668

WINNET BROADBAND PRIVATE
LIMITED

DS-11/212/2022-DS-III

C

WEST BENGAL(ASANSOL)

NAME:SOURAV DAS
Designation:DIRECTOR

C/O MANIK RAM DAS, GALSI, GALSI
Purba Bardhaman WEST BENGAL
713406

Contact No:
7865055276

Email Id:
winnetbroadband.official
@gmail.com

22-09-2022

22-09-2022

Contact No:
8830443875

Email Id:
vineshkini@gmail.com

26-09-2022

26-09-2022

669

ZENNET SERVICES PRIVATE
LIMITED

DS-11/327/2022-DS-III

C

MAHARASHTRA(KALYAN)

NAME:VINESH
RAMCHANDRA KINI
Designation:DIRECTOR

G/SHOP NO. 8, RUSHI VIHAR
COMPLEX, DHIVAR BLDG, VIRAR
EAST, PALGHAR Thane
MAHARASHTRA 401303

670

PING PLUS TECHNOLOGIES PVT
LTD

DS-11/239/2022-DS-III

B

WEST BENGAL

NAME:Subir Kumar
Mitra
Designation:Director

G-1, GROUND FLOOR, ANNAPURNA
APARTMENT SUKANTA NAGAR, PO MICHAEL NAGAR Madhyamgram North
24 Parganas WEST BENGAL 700133

Contact No:
9647820249

Email Id:
subirmitra59@yahoo.in

29-09-2022

29-09-2022

671

PING PLUS TECHNOLOGIES PVT
LTD

DS-11/239/2022-DS-III

B

KOLKATA

NAME:Subir Kumar
Mitra
Designation:Director

G-1, GROUND FLOOR, ANNAPURNA
APARTMENT SUKANTA NAGAR, PO MICHAEL NAGAR Madhyamgram North
24 Parganas WEST BENGAL 700133

Contact No:
9647820249

Email Id:
subirmitra59@yahoo.in

29-09-2022

29-09-2022

672

SPEEDLIGHT INFOTECH
PRIVATE LIMITED

DS-11/280/2022-DS-III

B

MUMBAI

NAME:ASLAM
SH-05,PL-09,SEC-20,PH-II TALOJA, SM
GANISAB
REALTY SM KU NAVI MUMBAI
MACHKURY
PANVEL Raigarh MH 410208 IN Raigad
Designation:DIRECTOR
MAHARASHTRA 410208

Contact No:
9004774388

Email Id:
speedlightinfoltd@gmail.
com

29-09-2022

29-09-2022
