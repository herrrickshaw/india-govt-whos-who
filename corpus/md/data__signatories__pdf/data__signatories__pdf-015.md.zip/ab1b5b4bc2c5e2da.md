---
doc_id: "ab1b5b4bc2c5e2da"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/d6008fd92dcd39ee7a1f43d87809852a.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Department for Promotion of Industry and Internal Trade, Multi Tasking Staff (Group C Posts) Recruitment (Amendment) Rules"
date: "2025-07-02"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "91d9c5e2411c8f21"
---

<!-- page 1 -->

[Hkkx II—[k.M 3(i)]

871

Hkkjr dk jkti=k % ebZ 27] 2017@T;s"B 6] 1939
(औ ोिगक नीित और संवधर्न िवभाग)
नई िदल्ली, 18 मई, 2017

सा.का.िन. 199.—रा पित, संिवधान के अनुच्छेद 309 के परन्तुक

ारा

दत्त शि य का

योग करते हुए

औ ोिगक नीित एवं संवधर्न िवभाग के बहुकायर् कमर्चारीवृंद (समूह ‘ग’ पद), भत िनयम, 2012 का संशोधन करने के िलए
एतद ारा िनम्निलिखत िनयम बनाते ह; अथार्त् :1.

(1) इन िनयम का संिक्ष नाम औ ोिगक नीित एवं संवधर्न िवभाग, बहुकायर् कमर्चारीवृंद (समूह ‘ग’ पद), भत
(संशोधन) िनयम, 2017 है।
(2) ये राजप म उनके काशन की तारीख को वृ ह गे।

2.

औ ोिगक नीित एवं संवधर्न िवभाग, बहुकायर् कमर्चारीवृंद (समूह ‘ग’ पद), भत िनयम, 2012 म;
(क) िनयम 2 के स्थान पर िनम्निलिखत िनयम रखा जाएगा, अथार्त:—
“2. पद की संख्या, वग करण और वेतन मैि क्स म स्तर.— पद की संख्या, उसका वग करण और वेतन
मैि क्स म स्तर वह होगा, जो इन िनयम से उपाब

अनुसूची के स्तंभ (2) से स्तंभ (4) म िविन दर् ह। ”;

(i) स्तंभ (4) म;
(क) स्तंभ शीषर् के स्थान पर िनम्निलिखत स्तंभ शीषर् रखा जाएगा, अथार्त :—
“वेतन मैि क्स म स्तर”;
(ख) िवि के स्थान पर िनम्निलिखत िवि रखी जाएगी, अथार्त:—
“वेतन मैि क्स म स्तर-1 (18000-56900 रुपए)”
[फा. सं. ए-12012/02/2016-स्था.-घ]
अनूप कु मार, अवर सिचव
िटप्प्ण: मूल िनयम भारत के राजप सं. सा.का.िन. 2, तारीख 31 िदसम्बर, 2012 ारा कािशत िकए गए थे।

(Department of Industrial Policy and Promotion)
New Delhi, the 18th May, 2017
G.S.R. 199.—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the President
hereby makes the following rules to amend the Department of Industrial Policy and Promotion, Multi Tasking Staff
(Group ‘C’ posts), Recruitment Rules, 2012, namely :—
1. (1) These rules may be called the Department of Industrial Policy and Promotion, Multi Tasking Staff (Group ‘C’
posts) Recruitment (Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2.
In the Department of Industrial Policy and Promotion, Multi Tasking Staff (Group ‘C’ posts) Recruitment
Rules, 2012;
(a) for rule 2, the following rule shall be substituted, namely:—
“2. Number of posts, classification and level in pay matrix.— The number of posts, its classification and level in the
pay matrix attached thereto shall be as specified in columns (2) to (4) of the Schedule annexed to these rules”;
(i) in column (4);
(A) for the column heading, the following column heading shall be substituted, namely:—
“Level in pay matrix”;

<!-- page 2 -->

872

THE GAZETTE OF INDIA : MAY 27, 2017/ JYAISTHA 6, 1939

[PART II—SEC. 3(i)]

(B) for the entry, the following entry shall be substituted, namely:—
“Level- 1 in pay matrix Rs. (18000-56900)”
[F. No. A-12012/02/2016-Estt.-D]
ANOOP KUMAR, Under Secy.
Note: The principal rules were published in the Gazette of India number G.S.R. 2, dated the 31st December, 2012.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
