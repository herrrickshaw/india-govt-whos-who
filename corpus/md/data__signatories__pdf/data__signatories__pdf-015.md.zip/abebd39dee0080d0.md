---
doc_id: "abebd39dee0080d0"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/636fb2a4d72bd079269a56bd51aef645.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Corrigendum for Pre Bid Meeting for SCALE RAPiD Unit"
date: "2025-07-04"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "505fa7d31870effb"
---

<!-- page 1 -->

P-60011/3/2023-S and BIC
Government of India
Ministry of Commerce and Industry
Department for Promotion of Industry and Internal Trade
SCALE
Vanijya Bhawan, New Delhi
Dated:~March, 2024
CORRIGENDUM
This is with reference to the RFP for Appointment of Consulting Agency for SCALE
RAPID Unit (Steering Committee for Advancing Local Value-Add and Exports Research
Analysis, Program Implementation, and Data Intelligence Unit) published by the
Department for Promotion of Industry and Internal Trade on 29.02.2024 on GeM Portal
(https://gem.gov.in) and on the website of DPIIT.
(GEM/2024/B/4712312 dated 29.02.2024)
2 In this regard, it is informed that due to exigency of work, pre-bid meeting for the
RFP on appointment of “Consulting Agency for SCALE RAPiD Unit’ scheduled for
11.03.2024 at 4.00 PM has now been rescheduled for 19.03.2024 at 4.00 PM in Room
No. 233 in Vanijya Bhawan, New Delhi.
3. All the interested bidders may like to attend the aforesaid meeting. It may be noted
that a maximum of two representatives of each Applicant shall be allowed to participate.
4. It is further requested that name, designation and contact details of the authorized
representatives may kindly be shared by 15'" March, 2024 at 04:00 P.M. with DPIIT at
scale-dpiit@gov.in.
5: Tentative Schedule for Selection Process, if revised, shall follow.
be
(Bejoy yal ‘
Director
Ph: 011-23038904
Email: dr.bejoyjohn@nic.in
To:
All Bidders
